# Publishing for clients, and the four defects only a client could find

Date: 2026-09-24
Scope: LivemoreBio distribution, installer, data-directory permissions, shell

## The blocker

The product repository is private, so `curl`ing the documented install URL
returned 404 for everyone outside the org — **including `install.sh` itself**.
There was a one-line installer that no prospective client could run.

## What was built

A separate public repository, `MannyAmah/livemorebio-dist`, holding the
installer, the channel manifest, the release archive, its checksum and the
guides. The installer resolves the manifest over plain HTTPS and verifies the
archive's SHA-256 before unpacking; `gh` is needed only when `LIVEMORE_REF`
asks for a repository ref, which remains the path for technical users.

`tools/public_distribution.py` decides what leaves the private repository. It
is an **exclude-list, not a pick-list**: a new source file ships by default,
because a product that silently omits code is worse than one that ships a
stray document. Recorded walkthroughs, deliverable decks, QA screenshots and
the authoring toolchain are excluded — 541 files, **107 MB → 6.1 MB**. The
repository is 260 MB; the runnable product is 15 MB of it.

The public archive still carries the whole test suite, so an installed copy
verifies itself exactly as we do: 6,566 tests collected, 6,515 passed.

## The four defects

Each was found by installing from the public URL and using the product as a
new client, not by reading code or running the suite.

**1. A client without Node.js could not install.** The installer runs the full
suite and refuses on failure; 95 tests called `node` directly instead of the
existing `require_node()`. Node was never a documented prerequisite.

**2. Installer fixtures inherited the caller's environment.** An exported
`LIVEMORE_SHA256` — exactly what an operator pinning a build has — made 29
tests verify a *fixture* archive against a *real* release checksum.

**3. One slow mirror discarded a whole install.** pip's `--retries` covers a
failed connection, not a body that stops arriving part-way through a large
wheel. Three client-shaped installs died this way. The fix retries the whole
command with backoff; pip's HTTP cache means a retry resumes.

**4. The data directory was created world-readable.** This is the serious one.
It holds the API token and both patch keys, and this product's PHI protection
*is* the POSIX mode on it. Two code paths created it with no mode at all, so
whichever ran first decided the permissions: an install that ran
`livemore models install` before `livemore start` left it `0755`.
`makedirs(mode=0o700)` was never sufficient either — the mode is masked by
umask and does nothing when the directory already exists.

Plus two first-run crashes: `livemore workspace` and the shell's pipeline
runner both let `urllib.error.HTTPError` escape as a traceback. In both cases
the traceback was *hiding a good answer* — a typed refusal that named exactly
what the operator should do.

## The lesson

Three sessions have now produced the same finding in different costumes:

- the launcher did not configure what the tests configured for themselves;
- the author's machine had Node when the client's did not;
- the author's data directory was created by a different code path than the
  client's.

**A green suite proves the code works given everything the author happens to
have.** It says nothing about a machine that has less, or that does things in
a different order. The only way to find these is to install the product the
way a client installs it and then use it.

Worth noting what the product got right each time: `check_atlas_presentation`
already refused with `NODE_NOT_AVAILABLE`; the perturb endpoint already
refused with `UNSUPPORTED_BIOLOGICAL_INTERVENTION` and named the supported
route. The refusals were correct. What failed was carrying them to the
operator.

## What to do next time

- Verify with the dependency removed **at the resolver**, not merely absent
  from `PATH`. `_toolchain` has hardcoded fallbacks and found Node anyway.
- A directory that holds keys gets its mode set on every path that can create
  it, and corrected on every path that can find it.
- When a boundary catches an exception from a service, ask what the operator
  can *do* with what it prints. A traceback is never that.
- Exercise install order permutations. `models install` before `start` is an
  ordinary thing for a client to do, and it was the difference between 0700
  and 0755.

See also: [[livemore-client-machine-assumptions]],
[[livemore-suite-green-launch-broken]], [[livemore-honest-refusal-pattern]]
