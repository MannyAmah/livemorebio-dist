"""Durable local storage and analysis exports for governed Cendos protocol runs."""
from __future__ import annotations

import csv
import io
import json
import hashlib
import os
from pathlib import Path
import re
from typing import Any
import uuid
import base64
from copy import deepcopy
from datetime import datetime, timezone
import sqlite3
import threading
import stat
from collections.abc import Callable
from collections.abc import Iterator
from contextlib import contextmanager


_RUN_ID = re.compile(r"^protocol-[a-f0-9]{32}$")
_HISTORY_LOCK = threading.Lock()
METABOLIC_PROTOCOL = "cendos.human-gem-oxygen-capacity.v1"
LOBELINE_PROTOCOL = "cendos.lobeline-vmat2-initial-rate.v1"
INSULIN_PROTOCOL = "cendos.exogenous-insulin-paired.v1"
BOTANICAL_PROTOCOL = "cendos.botanical-exposure-margin.v1"
_PROTOCOLS = {
    "cendos.metformin-cohort-comparison.v1": ("Metformin cohort comparison", "metformin-cohorts"),
    "cendos.garcinoic-acid-pxr.v1": ("Garcinoic acid PXR", "garcinoic-pxr"),
    METABOLIC_PROTOCOL: ("Human-GEM oxygen ATP capacity", "human-gem-oxygen-capacity"),
    LOBELINE_PROTOCOL: ("Lobeline VMAT2 nonhuman initial-rate assay", "lobeline-vmat2"),
    INSULIN_PROTOCOL: ("Exogenous insulin paired meal-bolus", "exogenous-insulin"),
    BOTANICAL_PROTOCOL: ("Botanical exposure versus active concentration", "botanical-exposure"),
}


def _current_source_record(protocol: str, request: dict | None = None) -> dict | None:
    """Current frozen source for protocols that retain a self-contained source record."""
    if protocol == LOBELINE_PROTOCOL:
        from .lobeline_vmat2 import source_record
        return source_record()
    if protocol == INSULIN_PROTOCOL:
        from .insulin_protocol import source_record
        return source_record()
    if protocol == BOTANICAL_PROTOCOL:
        from .botanical_programs import source_record
        return source_record((request or {}).get("program_id", ""))
    return None


_SOURCE_RECORD_PROTOCOLS = frozenset({LOBELINE_PROTOCOL, INSULIN_PROTOCOL, BOTANICAL_PROTOCOL})


def _hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _request_from_result(result: dict) -> dict:
    if isinstance(result.get("input"), dict):
        return deepcopy(result["input"])
    protocol = result.get("protocol_id")
    if protocol == "cendos.metformin-cohort-comparison.v1":
        return {"cohort_a_id": result["cohorts"][0]["cohort_id"],
                "cohort_b_id": result["cohorts"][1]["cohort_id"],
                "dose_mg": result["intervention"]["dose_mg"], "grams": result["intervention"]["ogtt_grams"]}
    if protocol == "cendos.garcinoic-acid-pxr.v1":
        return {"cohort_id": result["cohort"]["cohort_id"],
                "concentrations_um": [level["concentration_um"] for level in result["target_engagement"]]}
    raise ValueError("protocol has no supported rerun configuration")


def attach_run_inputs(result: dict, request: dict, cohorts: list[dict], *,
                      parent: dict | None = None, new_configuration: bool = False) -> dict:
    """Freeze authoritative inputs; cohorts are server-resolved records, never labels."""
    protocol = result.get("protocol_id")
    if protocol not in _PROTOCOLS:
        raise ValueError("unsupported protocol")
    # Derive drug quantities from the actual completed execution, not untrusted
    # extra body fields or a later active-twin read.
    normalized = _request_from_result(result)
    expected = ([normalized["cohort_a_id"], normalized["cohort_b_id"]]
                if protocol == "cendos.metformin-cohort-comparison.v1" else
                [normalized["cohort_id"]] if protocol == "cendos.garcinoic-acid-pxr.v1" else [])
    if [cohort.get("cohort_id") for cohort in cohorts] != expected:
        raise ValueError("source cohort identities do not match the executed configuration")
    output = deepcopy(result)
    output["input"] = normalized
    output["input_sha256"] = _hash(normalized)
    output["source_snapshots"] = [
        {"cohort_id": cohort["cohort_id"], "version": cohort.get("version"), "sha256": _hash(cohort)}
        for cohort in cohorts
    ]
    if parent:
        output.update(parent)
    return output


class ProtocolRunNotFound(LookupError):
    pass


class ProtocolRunStore:
    def __init__(self, directory: str | Path) -> None:
        self.directory = Path(directory)
        if self.directory.is_symlink():
            raise ValueError("protocol storage directory must not be a symbolic link")
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        if not self.directory.is_dir() or self.directory.stat().st_uid != os.getuid():
            raise ValueError("protocol storage ownership is invalid")
        try:
            self.directory.chmod(0o700)
        except OSError:
            pass

    def _path(self, run_id: str) -> Path:
        if not _RUN_ID.fullmatch(str(run_id)):
            raise ProtocolRunNotFound("protocol run was not found")
        return self.directory / f"{run_id}.json"

    def save(self, result: dict[str, Any]) -> dict[str, Any]:
        run_id = str(result.get("run_id", ""))
        path = self._path(run_id)
        if path.is_symlink() or (path.exists() and (not path.is_file() or path.stat().st_nlink != 1)):
            raise ValueError("protocol storage target is unsafe")
        temporary = self.directory / f".{run_id}.{uuid.uuid4().hex}.tmp"
        payload = json.dumps(result, sort_keys=True, separators=(",", ":"), allow_nan=False)
        descriptor = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            try:
                os.link(temporary, path)
            except FileExistsError:
                if path.read_text(encoding="utf-8") != payload:
                    raise ValueError("protocol run is immutable; execute a new run instead")
        finally:
            temporary.unlink(missing_ok=True)
        path.chmod(0o600)
        latest = self.directory / "latest"
        latest_tmp = self.directory / f".latest.{uuid.uuid4().hex}.tmp"
        try:
            latest_tmp.write_text(run_id, encoding="utf-8")
            latest_tmp.chmod(0o600)
            latest_tmp.replace(latest)
        finally:
            try:
                latest_tmp.unlink(missing_ok=True)
            except OSError:
                pass
        latest.chmod(0o600)
        self._index_record(result, hashlib.sha256(payload.encode()).hexdigest())
        return result

    def get(self, run_id: str) -> dict[str, Any]:
        path = self._path(run_id)
        try:
            info = path.stat()
            if (path.is_symlink() or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1
                    or info.st_uid != os.getuid() or info.st_size > 32_000_000):
                raise ValueError("protocol storage integrity check failed")
            raw = path.read_text(encoding="utf-8")
            result = json.loads(raw)
            if not isinstance(result, dict) or result.get("run_id") != run_id:
                raise ValueError("protocol storage identity does not match")
            if "protocol_id" in result and not isinstance(result["protocol_id"], str):
                raise ValueError("protocol storage protocol identity is invalid")
            index = self.directory / ".index.sqlite3"
            if index.exists():
                with self._index() as db:
                    saved = db.execute("SELECT digest FROM runs WHERE run_id=?", (run_id,)).fetchone()
                if saved and saved[0] != hashlib.sha256(raw.encode()).hexdigest():
                    raise ValueError("protocol storage digest does not match")
            return result
        except (FileNotFoundError, json.JSONDecodeError) as error:
            raise ProtocolRunNotFound("protocol run was not found") from error

    def latest(self) -> dict[str, Any]:
        try:
            path = self.directory / "latest"
            if path.is_symlink() or not path.is_file() or path.stat().st_size > 100:
                if not path.exists():
                    raise FileNotFoundError()
                raise ValueError("latest protocol pointer is invalid")
            run_id = path.read_text(encoding="utf-8").strip()
        except FileNotFoundError as error:
            raise ProtocolRunNotFound("no protocol has been executed") from error
        return self.get(run_id)

    @contextmanager
    def _index(self) -> Iterator[sqlite3.Connection]:
        path = self.directory / ".index.sqlite3"
        for candidate in (path, *(Path(str(path) + suffix) for suffix in ("-journal", "-wal", "-shm"))):
            try:
                info = candidate.lstat()
            except FileNotFoundError:
                # SQLite removes transaction sidecars during concurrent commits.
                # Inspect one snapshot so normal disappearance is not corruption.
                continue
            if (candidate != path and stat.S_ISREG(info.st_mode)
                    and info.st_uid == os.getuid() and info.st_nlink == 0):
                # APFS may finish lstat after the sidecar's final unlink. This
                # exception excludes the database, hardlinks and foreign files.
                continue
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                    or info.st_nlink != 1):
                raise ValueError("protocol index storage is unsafe")
        db = sqlite3.connect(path, timeout=5)
        try:
            with db:
                db.execute("CREATE TABLE IF NOT EXISTS runs(run_id TEXT PRIMARY KEY, executed_at TEXT NOT NULL, protocol_id TEXT NOT NULL, title TEXT NOT NULL, evidence_state TEXT, qualification_state TEXT, parent_run_id TEXT, digest TEXT NOT NULL)")
                db.execute("CREATE INDEX IF NOT EXISTS runs_order ON runs(executed_at DESC,run_id DESC)")
                path.chmod(0o600)
                yield db
        finally:
            db.close()

    def _index_record(self, result: dict, digest: str) -> None:
        candidate_protocol = result.get("protocol_id")
        protocol = candidate_protocol if isinstance(candidate_protocol, str) and candidate_protocol in _PROTOCOLS else "unsupported"
        title = _PROTOCOLS.get(protocol, ("Unsupported preserved protocol", ""))[0]
        try:
            stamp = datetime.fromisoformat(str(result.get("executed_at", "")).replace("Z", "+00:00"))
            if stamp.tzinfo is None:
                raise ValueError()
        except ValueError:
            stamp = datetime.fromtimestamp(self._path(result["run_id"]).stat().st_mtime, timezone.utc)
        executed = stamp.astimezone(timezone.utc).isoformat()
        evidence = result.get("evidence_state")
        if evidence not in {"MODELED_MECHANISTIC", "STRUCTURE_AND_IN_VITRO_BACKED_MODEL", "MODELED_TARGET_ENGAGEMENT", "MODELED_STEADY_STATE", "MODELED_INITIAL_RATE"}:
            evidence = "UNASSESSED"
        parent = result.get("parent_run_id")
        if not isinstance(parent, str) or not _RUN_ID.fullmatch(parent):
            parent = None
        with self._index() as db:
            db.execute("INSERT OR IGNORE INTO runs VALUES(?,?,?,?,?,?,?,?)", (
                result["run_id"], executed, protocol, title, evidence,
                "NOT_QUALIFIED", parent, digest))

    def _sync_index(self) -> None:
        # Legacy files are read once. Subsequent pages query only bounded public
        # summaries; patient/cohort names and member payloads never enter the index.
        with _HISTORY_LOCK:
            with self._index() as db:
                known = {row[0] for row in db.execute("SELECT run_id FROM runs")}
            for path in self.directory.glob("protocol-*.json"):
                if not _RUN_ID.fullmatch(path.stem) or path.stem in known:
                    continue
                result = self.get(path.stem)
                self._index_record(result, hashlib.sha256(path.read_bytes()).hexdigest())

    def history(self, *, limit: int = 20, cursor: str | None = None, q: str = "") -> dict:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 50:
            raise ValueError("history limit must be an integer from 1 to 50")
        if not isinstance(q, str) or len(q) > 120 or any(ord(char) < 32 for char in q):
            raise ValueError("history search requires bounded text")
        self._sync_index()
        query = q.strip()
        search = "%" + query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        search_sql = "(run_id LIKE ? ESCAPE '\\' OR title LIKE ? ESCAPE '\\' OR protocol_id LIKE ? ESCAPE '\\')"
        after = None
        with self._index() as db:
            if cursor:
                try:
                    if len(cursor) > 2048:
                        raise ValueError()
                    token = json.loads(base64.urlsafe_b64decode(cursor + "=" * (-len(cursor) % 4)))
                    anchor, after = token["anchor"], token["after"]
                    if (token["q"] != query or any(not isinstance(pair, list) or len(pair) != 2 or
                            not all(isinstance(item, str) and len(item) <= 100 for item in pair)
                            for pair in (anchor, after))):
                        raise ValueError()
                except (ValueError, KeyError, TypeError, UnicodeError) as error:
                    raise ValueError("history cursor is invalid for this search") from error
            else:
                row = db.execute(f"SELECT executed_at,run_id FROM runs WHERE {search_sql} ORDER BY executed_at DESC,run_id DESC LIMIT 1", (search, search, search)).fetchone()
                anchor = list(row) if row else ["", ""]
            params = [search, search, search, *anchor]
            where = search_sql + " AND (executed_at,run_id)<=(?,?)"
            total = db.execute("SELECT count(*) FROM runs WHERE " + where, params).fetchone()[0]
            if after:
                where += " AND (executed_at,run_id)<(?,?)"
                params.extend(after)
            rows = db.execute("SELECT run_id,executed_at,protocol_id,title,evidence_state,qualification_state,parent_run_id FROM runs WHERE " + where + " ORDER BY executed_at DESC,run_id DESC LIMIT ?", (*params, limit + 1)).fetchall()
        more = len(rows) > limit
        rows = rows[:limit]
        next_cursor = None
        if more:
            next_cursor = base64.urlsafe_b64encode(json.dumps({"anchor": anchor, "after": [rows[-1][1], rows[-1][0]], "q": query}, separators=(",", ":")).encode()).decode().rstrip("=")
        runs = [{"run_id": row[0], "created_at": row[1], "executed_at": row[1],
                 "protocol_id": row[2], "summary": row[3], "evidence_state": row[4],
                 "qualification_state": row[5], "parent_run_id": row[6]} for row in rows]
        return {"runs": runs, "pagination": {"limit": limit, "next_cursor": next_cursor, "has_more": more, "total": total}}

    def prepare_rerun(self, run_id: str, cohort_lookup: Callable | None = None) -> dict:
        result = self.get(run_id)
        protocol = result.get("protocol_id")
        if protocol not in _PROTOCOLS:
            raise ValueError("protocol has no supported rerun configuration")
        retained_assay_source = (protocol in _SOURCE_RECORD_PROTOCOLS and isinstance(result.get("source_record"), dict)
                                 and result.get("source_sha256") == _hash(result["source_record"]))
        exact = (isinstance(result.get("input"), dict) and result.get("input_sha256") == _hash(result["input"])
                 and (protocol == METABOLIC_PROTOCOL or retained_assay_source or bool(result.get("source_snapshots"))))
        warnings = [] if exact else ["Original complete source snapshots were not retained. Preparing a new configuration, not an exact reproduction."]
        return {"protocol_id": protocol, "parent_run_id": run_id, "parent_run_sha256": _hash(result),
                "request": _request_from_result(result), "endpoint": "/api/cendos/protocols/" + _PROTOCOLS[protocol][1],
                "warnings": warnings, "rerun_mode": "exact" if exact else "new_configuration"}

    def validate_rerun(self, parent_run_id: str, request: dict, cohort_lookup: Callable | None = None,
                       *, new_configuration: bool = False, expected_protocol_id: str | None = None) -> dict:
        if not isinstance(new_configuration, bool):
            raise ValueError("new_configuration acknowledgment must be boolean")
        prepared = self.prepare_rerun(parent_run_id)
        parent = self.get(parent_run_id)
        if expected_protocol_id is not None and parent.get("protocol_id") != expected_protocol_id:
            raise ValueError("parent protocol does not match requested protocol")
        changed = _hash(request) != _hash(prepared["request"])
        exact = prepared["rerun_mode"] == "exact" and not changed
        if not new_configuration and not exact:
            raise ValueError("configuration differs or original sources are unavailable; explicitly acknowledge a new configuration")
        if exact and parent["protocol_id"] == METABOLIC_PROTOCOL:
            from ..model_assets import verified_asset, ModelAssetError
            from ..engines.stoichiometry import StoichiometryError
            try:
                current = verified_asset("human-gem")
            except ModelAssetError as error:
                raise StoichiometryError("exact parent model is unavailable", "MODEL_UNAVAILABLE") from error
            if current["model_sha256"] != parent["model"]["model_sha256"]:
                if not new_configuration:
                    raise ValueError("exact parent model release is unavailable; explicitly prepare a new configuration")
                exact = False
        elif exact and parent["protocol_id"] in _SOURCE_RECORD_PROTOCOLS:
            current = _current_source_record(parent["protocol_id"], parent.get("input"))
            if current is None or _hash(current) != parent["source_sha256"]:
                if not new_configuration:
                    raise ValueError("parameter source changed; explicitly prepare a new configuration")
                exact = False
        elif exact:
            if cohort_lookup is None:
                raise ValueError("exact rerun requires authoritative cohort lookup")
            for source in parent["source_snapshots"]:
                current = cohort_lookup(source["cohort_id"])
                if _hash(current) != source["sha256"] or current.get("version") != source.get("version"):
                    if not new_configuration:
                        raise ValueError("cohort source changed; explicitly prepare a new configuration")
                    exact = False
        return {"parent_run_id": parent_run_id, "parent_run_sha256": prepared["parent_run_sha256"],
                "rerun_mode": "exact" if exact else "new_configuration", "reproducible_parent_configuration": exact}


def analysis_csv(result: dict[str, Any]) -> str:
    output = io.StringIO(newline="")
    if result.get("protocol_id") == "cendos.metformin-cohort-comparison.v1":
        fields = [
            "member_id", "cohort", "cohort_id", "stratum", "age", "sex",
            "baseline_glucose_mg_dL", "delta_mean_mg_dL", "delta_peak_mg_dL",
            "delta_iAUC_mg_dL_min", "decision", "oct1_lof_alleles",
            "oct1_transport", "renal_factor", "weight_kg", "modeled_auc_mg_h_L",
            "modeled_cmax_mg_L", "evidence_state", "qualification_state",
        ]
        writer = _SafeCSVWriter(output, fieldnames=fields)
        writer.writeheader()
        for cohort in result["cohorts"]:
            for member in cohort["members"]:
                writer.writerow({
                    "member_id": member["member_id"],
                    "cohort": cohort["name"],
                    "cohort_id": cohort["cohort_id"],
                    "stratum": cohort["stratum"],
                    "age": member["age"],
                    "sex": member["sex"],
                    "baseline_glucose_mg_dL": member["baseline_glucose_mg_dL"],
                    "delta_mean_mg_dL": member["delta_mean"],
                    "delta_peak_mg_dL": member["delta_peak"],
                    "delta_iAUC_mg_dL_min": member["delta_iAUC"],
                    "decision": member["decision"],
                    "oct1_lof_alleles": member["individualization"]["oct1_lof_alleles"],
                    "oct1_transport": member["individualization"]["oct1_transport"],
                    "renal_factor": member["individualization"]["renal_factor"],
                    "weight_kg": member["individualization"]["weight_kg"],
                    "modeled_auc_mg_h_L": member["pk"]["auc_mg_h_L"],
                    "modeled_cmax_mg_L": member["pk"]["cmax_mg_L"],
                    "evidence_state": result["evidence_state"],
                    "qualification_state": result["qualification_state"],
                })
    elif result.get("protocol_id") == "cendos.garcinoic-acid-pxr.v1":
        fields = [
            "member_id", "cohort", "concentration_um", "receptor_occupancy",
            "nr1i2_expression_factor", "relative_pxr_activation", "pdb_id",
            "evidence_state", "qualification_state",
        ]
        writer = _SafeCSVWriter(output, fieldnames=fields)
        writer.writeheader()
        for concentration in result.get("target_engagement", []):
            for member in concentration["members"]:
                writer.writerow({
                    "member_id": member["member_id"],
                    "cohort": result["cohort"]["name"],
                    "concentration_um": concentration["concentration_um"],
                    "receptor_occupancy": concentration["mean_occupancy"],
                    "nr1i2_expression_factor": member["nr1i2_expression_factor"],
                    "relative_pxr_activation": member["relative_pxr_activation"],
                    "pdb_id": result["structure"]["pdb_id"],
                    "evidence_state": result["evidence_state"],
                    "qualification_state": result["qualification_state"],
                })
    elif result.get("protocol_id") == METABOLIC_PROTOCOL:
        fields = ["condition_id", "role", "glucose_uptake_bound", "oxygen_uptake_bound",
                  "objective_flux", "actual_glucose_uptake", "actual_oxygen_uptake",
                  "solver_status", "mass_balance_residual", "bound_residual", "control_passed",
                  "unit", "model_sha256", "evidence_state", "qualification_state"]
        writer = _SafeCSVWriter(output, fieldnames=fields)
        writer.writeheader()
        for role, rows in (("condition", result["conditions"]), ("negative_control", result["controls"])):
            for row in rows:
                constraints = row.get("constraints", {})
                writer.writerow({"condition_id": row["condition_id"], "role": role,
                    "glucose_uptake_bound": constraints.get("glucose_uptake"),
                    "oxygen_uptake_bound": constraints.get("oxygen_uptake"),
                    **{key: row.get(key) for key in ("objective_flux", "actual_glucose_uptake",
                        "actual_oxygen_uptake", "solver_status", "mass_balance_residual", "bound_residual")},
                    "control_passed": row.get("passed"), "unit": result["unit"],
                    "model_sha256": result["model"]["model_sha256"],
                    "evidence_state": result["evidence_state"], "qualification_state": result["qualification_state"]})
    elif result.get("protocol_id") == INSULIN_PROTOCOL:
        fields = ["member_id", "weight_kg", "basal_u_per_h", "VG_L_per_kg", "VI_L_per_kg", "ke_per_min",
                  "arm", "baseline_glucose_mmol_L", "nadir_glucose_mmol_L", "t_nadir_min",
                  "peak_glucose_mmol_L", "t_peak_min", "end_glucose_mmol_L",
                  "peak_plasma_insulin_mU_L", "t_peak_insulin_min", "glucose_auc_mmol_L_min",
                  "minutes_below_3_9_mmol_L", "delta_glucose_auc_mmol_L_min", "delta_nadir_mmol_L",
                  "product_id", "bolus_units", "evidence_state", "qualification_state"]
        writer = _SafeCSVWriter(output, fieldnames=fields)
        writer.writeheader()
        shared = {"product_id": result["intervention"]["product"]["product_id"],
                  "bolus_units": result["intervention"]["bolus_units"],
                  "evidence_state": result["evidence_state"],
                  "qualification_state": result["qualification_state"]}
        for member in result["members"]:
            sampled = member["sampled_parameters"]
            for arm in ("control", "treated"):
                summary = member[arm]
                writer.writerow({**shared,
                    "member_id": member["member_id"], "weight_kg": member["weight_kg"],
                    "basal_u_per_h": member["basal_u_per_h"],
                    "VG_L_per_kg": sampled["VG"], "VI_L_per_kg": sampled["VI"], "ke_per_min": sampled["ke"],
                    "arm": arm,
                    "baseline_glucose_mmol_L": summary["baseline_glucose_mmol_L"],
                    "nadir_glucose_mmol_L": summary["nadir_glucose_mmol_L"],
                    "t_nadir_min": summary["t_nadir_min"],
                    "peak_glucose_mmol_L": summary["peak_glucose_mmol_L"],
                    "t_peak_min": summary["t_peak_min"],
                    "end_glucose_mmol_L": summary["end_glucose_mmol_L"],
                    "peak_plasma_insulin_mU_L": summary["peak_plasma_insulin_mU_L"],
                    "t_peak_insulin_min": summary["t_peak_insulin_min"],
                    "glucose_auc_mmol_L_min": summary["glucose_auc_mmol_L_min"],
                    "minutes_below_3_9_mmol_L": summary["minutes_below_3_9_mmol_L"],
                    "delta_glucose_auc_mmol_L_min": member["paired_difference"]["delta_glucose_auc_mmol_L_min"] if arm == "treated" else None,
                    "delta_nadir_mmol_L": member["paired_difference"]["delta_nadir_mmol_L"] if arm == "treated" else None,
                })
    elif result.get("protocol_id") == BOTANICAL_PROTOCOL:
        fields = ["program_id", "material_id", "species", "compound", "pubchem_cid", "dose_mg",
                  "route", "species_context", "member_id", "weight_kg",
                  "cmax_unbound_um", "auc_unbound_um_h", "t_peak_h", "active_low_um", "active_high_um",
                  "margin_to_active_low", "reaches_active_range", "human_exposure_admissible",
                  "evidence_state", "qualification_state"]
        writer = _SafeCSVWriter(output, fieldnames=fields)
        writer.writeheader()
        material = result["material"]
        shared = {"program_id": result["program"]["program_id"], "material_id": material["material_id"],
                  "species": material["species"], "compound": material["compound"],
                  "pubchem_cid": material.get("pubchem_cid"), "dose_mg": result["input"]["dose_mg"],
                  "route": result["input"]["route"], "species_context": result["pharmacokinetics"]["species"],
                  "active_low_um": (result.get("active_range_um") or [None, None])[0],
                  "active_high_um": (result.get("active_range_um") or [None, None])[1],
                  "human_exposure_admissible": result["human_exposure_admissible"],
                  "evidence_state": result["evidence_state"], "qualification_state": result["qualification_state"]}
        if not result["members"]:
            margin = result.get("margin") or {}
            writer.writerow({**shared, "member_id": "published-summary" if margin else None,
                             "cmax_unbound_um": margin.get("unbound_cmax_um"),
                             "margin_to_active_low": margin.get("margin_to_active_low"),
                             "reaches_active_range": (None if not margin
                                                      else margin["margin_to_active_low"] >= 1.0)})
        for member in result["members"]:
            writer.writerow({**shared, "member_id": member["member_id"], "weight_kg": member["weight_kg"],
                "cmax_unbound_um": member["cmax_unbound_um"], "auc_unbound_um_h": member["auc_unbound_um_h"],
                "t_peak_h": member["t_peak_h"], "margin_to_active_low": member["margin_to_active_low"],
                "reaches_active_range": member["reaches_active_range"]})
    elif result.get("protocol_id") == LOBELINE_PROTOCOL:
        fields = ["record_type", "condition_id", "inhibitor_um", "substrate_um", "initial_rate",
                  "control_rate", "rate_fraction", "apparent_km_um", "reported_apparent_km_um",
                  "difference_um", "unit", "source_sha256", "evidence_state", "qualification_state"]
        writer = _SafeCSVWriter(output, fieldnames=fields)
        writer.writeheader()
        shared = {key: result[key] for key in ("source_sha256", "evidence_state", "qualification_state")}
        for condition in result["conditions"]:
            for point in condition["points"]:
                writer.writerow({**shared, **point, "record_type": "modeled_initial_rate",
                    "condition_id": condition["condition_id"], "inhibitor_um": condition["inhibitor_um"],
                    "apparent_km_um": condition["apparent_km_um"], "unit": result["unit"]})
        comparator = result["benchmark_discrepancy"]
        writer.writerow({**shared, "record_type": "published_parameter_comparison",
            "inhibitor_um": comparator["inhibitor_um"], "apparent_km_um": comparator["predicted_apparent_km_um"],
            "reported_apparent_km_um": comparator["reported_apparent_km_um"],
            "difference_um": comparator["difference_um"], "unit": "uM"})
    else:
        raise ValueError("unsupported protocol analysis export")
    return output.getvalue()


class _SafeCSVWriter(csv.DictWriter):
    def writerow(self, rowdict: dict) -> object:
        # Excel-compatible exports must not execute caller-controlled labels.
        # Preserve numeric negative values; escape only untrusted string cells.
        safe = {key: ("'" + value if isinstance(value, str) and
                      (value.lstrip().startswith(("=", "+", "-", "@")) or
                       value.startswith(("\t", "\r", "\n"))) else value)
                for key, value in rowdict.items()}
        return super().writerow(safe)


def analysis_notebook(result: dict[str, Any]) -> dict[str, Any]:
    encoded = json.dumps(result, sort_keys=True, separators=(",", ":"), allow_nan=False)
    protocol_id = str(result.get("protocol_id", "unknown"))
    if protocol_id not in _PROTOCOLS:
        raise ValueError("unsupported protocol analysis export")
    if protocol_id == METABOLIC_PROTOCOL:
        return _metabolic_notebook(result, encoded)
    if protocol_id == LOBELINE_PROTOCOL:
        return _lobeline_notebook(result, encoded)
    if protocol_id == INSULIN_PROTOCOL:
        return _insulin_notebook(result, encoded)
    if protocol_id == BOTANICAL_PROTOCOL:
        return _botanical_notebook(result, encoded)
    notebook = {
        "cells": [
            {
                "cell_type": "markdown",
                "metadata": {},
                "source": [
                    "# LivemoreBio Cendos protocol analysis\n",
                    f"Protocol: `{protocol_id}`  \n",
                    f"Evidence: `{result.get('evidence_state')}` · Qualification: `{result.get('qualification_state')}`\n",
                    "\nModel output is not an observed or clinically validated human response.\n",
                    "Members come from explicit research priors, not enrolled trial participants. Between-member dispersion is not an empirical confidence interval.\n",
                    "A frozen prospective protocol and independent physical measurements are required to assess functional equivalence.\n",
                ],
            },
            {
                "cell_type": "code",
                "execution_count": None,
                "metadata": {},
                "outputs": [],
                "source": ["import json, hashlib\n", f"result = json.loads({encoded!r})\n",
                    "encoded = json.dumps(result, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()\n",
                    f"assert hashlib.sha256(encoded).hexdigest() == {hashlib.sha256(encoded.encode()).hexdigest()!r}\n",
                    "print('Frozen run verified:', result.get('run_id', 'not supplied'))\n",
                    "print('Evidence:', result['evidence_state'], '| Qualification:', result['qualification_state'])\n"],
            },
            {
                "cell_type": "code",
                "execution_count": None,
                "metadata": {},
                "outputs": [],
                "source": [
                    "# Inspect individualized rows without changing the frozen result.\n",
                    "if 'cohorts' in result:\n",
                    "    rows = [dict(row, cohort=cohort['name']) for cohort in result['cohorts'] for row in cohort['members']]\n",
                    "else:\n",
                    "    rows = [dict(row, concentration_um=level['concentration_um']) for level in result['target_engagement'] for row in level['members']]\n",
                    "len(rows), rows[:2]\n",
                ],
            },
        ],
        "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}},
        "nbformat": 4,
        "nbformat_minor": 5,
    }
    cells = notebook["cells"]
    cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
        "import matplotlib.pyplot as plt\n",
        "from IPython.display import display\n",
        "from statistics import mean, stdev\n",
        "if 'cohorts' in result:\n",
        "    fig, axes = plt.subplots(1, 2, figsize=(12, 4), constrained_layout=True)\n",
        "    for cohort in result['cohorts']:\n",
        "        members = cohort['members']\n",
        "        values = [m['delta_mean'] for m in members]\n",
        "        print(cohort['name'], 'n=', len(values), 'mean delta=', round(mean(values), 3), 'mg/dL', 'SD=', round(stdev(values), 3) if len(values)>1 else 'not estimable')\n",
        "        axes[0].scatter([m['baseline_glucose_mg_dL'] for m in members], values, label=cohort['name'], alpha=.8)\n",
        "        for member in members:\n",
        "            series = member.get('trajectory')\n",
        "            if series: axes[1].plot(series['t_min'], series['treated']['glucose'], alpha=.4)\n",
        "    axes[0].set(xlabel='Baseline glucose (mg/dL)', ylabel='Change in mean glucose (mg/dL)', title='Individual model response')\n",
        "    axes[0].legend(); axes[0].axhline(0, color='gray', linewidth=.7)\n",
        "    axes[1].set(xlabel='Biological time (min)', ylabel='Glucose (mg/dL)', title='Stored treated ODE trajectories')\n",
        "else:\n",
        "    fig, ax = plt.subplots(figsize=(9, 4), constrained_layout=True)\n",
        "    members = sorted({row['member_id'] for row in rows})\n",
        "    for member_id in members:\n",
        "        member_rows = sorted((r for r in rows if r['member_id']==member_id), key=lambda r:r['concentration_um'])\n",
        "        ax.plot([r['concentration_um'] for r in member_rows], [r['relative_pxr_activation'] for r in member_rows], marker='o', alpha=.7)\n",
        "    ax.set(xlabel='Assay concentration (µM)', ylabel='Relative PXR activation (dimensionless)', title='Static concentration response — not time kinetics')\n",
        "    if rows and all(row['concentration_um'] > 0 for row in rows): ax.set_xscale('log')\n",
        "    for level in result['target_engagement']:\n",
        "        values = [m['relative_pxr_activation'] for m in level['members']]\n",
        "        print(level['concentration_um'], 'µM:', 'members=',len(values), 'mean activation=',round(mean(values), 5))\n",
        "display(fig)\n",
    ]})
    cells.append({"cell_type": "markdown", "metadata": {}, "source": [
        "## Interpretation and next experiment\n",
        "The plots describe the frozen model execution. They do not establish causal effects in an independent assay, therapeutic potency, safety, or treatment-free resilience.\n",
        "For PXR, expression factors are assumed research priors; equilibrium activation is not CYP3A4 induction, whole-body pharmacokinetics, or clinical efficacy.\n",
        "For metformin, the pharmacodynamic mapping remains a heuristic research component. Numerical ODE integration does not validate that mapping.\n",
        "Freeze endpoint, units, tolerance rationale, sample/member mapping, material lot, method and controls in **Research** before collecting the physical counterpart. Import measurements with custody metadata, inspect residuals and failed QC, then seek independent scientific review.\n",
        "Do not change parameters or acceptance thresholds after viewing the result to force agreement.\n",
    ]})
    for index, cell in enumerate(cells):
        cell["id"] = f"analysis-{index}"
    return notebook


def _metabolic_notebook(result: dict, encoded: str) -> dict:
    cells = [
        {"cell_type": "markdown", "metadata": {}, "source": [
            "# Human-GEM oxygen-limited ATP capacity\n",
            "Frozen steady-state network capacity, not a person, measured cellular ATP concentration, kinetic response or physiological oxygen saturation.\n",
            "Glucose and oxygen uptake bounds are explicit experimental assumptions. Fluxes satisfy S·v=0 within the stored tolerance. Maximizing ATP maintenance is an analysis objective, not evidence that a physical cell chooses it.\n",
            "Evidence: MODELED_STEADY_STATE · NOT_QUALIFIED. Flux variability was not computed; individual optimal fluxes need not be unique.\n"]},
        {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
            "import json, hashlib\n", f"result = json.loads({encoded!r})\n",
            "encoded = json.dumps(result, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()\n",
            f"assert hashlib.sha256(encoded).hexdigest() == {hashlib.sha256(encoded.encode()).hexdigest()!r}\n",
            "print('Frozen run:', result['run_id'], '| Model:', result['model'])\n",
            "print('Solver:', result['solver'])\n",
            "for control in result['controls']: print('Negative control:', control)\n",
            "assert all(control['passed'] for control in result['controls'])\n"]},
        {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
            "import matplotlib.pyplot as plt\n",
        "from IPython.display import display\n",
            "rows = result['conditions']\n",
            "fig, ax = plt.subplots(figsize=(9, 4), constrained_layout=True)\n",
            "for row in rows:\n",
            "    print(row['condition_id'], row)\n",
            "    x = row['constraints']['oxygen_uptake']\n",
            "    ax.scatter(x, row['objective_flux'])\n",
            "    ax.annotate(row['condition_id'], (x, row['objective_flux']))\n",
            "ax.set(xlabel='Oxygen uptake bound (mmol/gDW/h)', ylabel='ATP maintenance capacity (mmol/gDW/h)', title='Explicit steady-state constraints — not a time course')\n",
            "display(fig)\n"]},
        {"cell_type": "markdown", "metadata": {}, "source": [
            "## Interpretation boundary\n",
            "The requested conditions are alternative network constraints, not independent human subjects or technical replicates. No confidence interval or treatment efficacy follows from their dispersion.\n",
            "A future physical comparison requires an independently reviewed cell/assay context, tissue and medium, dry-weight normalization, measurement method, sample identity, controls and tolerance rationale. Member-based clinical validation is unavailable for this protocol.\n",
            "No active twin, clinical profile, LIFE Patch state or model parameter was changed by this calculation.\n"]},
    ]
    for index, cell in enumerate(cells):
        cell["id"] = f"metabolic-analysis-{index}"
    return {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}}, "nbformat": 4, "nbformat_minor": 5}


def _lobeline_notebook(result: dict, encoded: str) -> dict:
    cells = [
        {"cell_type": "markdown", "metadata": {}, "source": [
            "# Lobeline–VMAT2 initial-rate assay analysis\n",
            "Rat striatal synaptic vesicles and lobeline hemisulfate: a stationary concentration relation, not a time course, a human cohort or an atomistic trajectory.\n",
            "MODELED_INITIAL_RATE · NOT_QUALIFIED. These conditions are not independent human measurements or independent laboratory replication.\n",
            "Source: Nickell et al. (2010), https://doi.org/10.1124/jpet.109.160275 (PMC2812121). Only minimal cited parameter facts and original analysis code are included.\n"]},
        {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
            "import json, hashlib, math\n", f"result = json.loads({encoded!r})\n",
            "def digest(value): return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()\n",
            f"assert digest(result) == {hashlib.sha256(encoded.encode()).hexdigest()!r}\n",
            "assert digest(result['source_record']) == result['source_sha256']\n",
            "assert digest(result['input']) == result['input_sha256']\n",
            "print('Frozen run verified:', result['run_id'])\n",
            "print('Source record digest (not article digest):', result['source_sha256'])\n"]},
        {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
            "# Independent arithmetic using only the frozen source parameters. No live model or service is invoked.\n",
            "parameters = result['source_record']['parameters']\n",
            "km, ki, vmax = parameters['km_um']['value'], parameters['ki_um']['value'], parameters['vmax']['value']\n",
            "for condition in result['conditions']:\n",
            "    apparent_km = km * (1 + condition['inhibitor_um'] / ki)\n",
            "    assert math.isclose(apparent_km, condition['apparent_km_um'], rel_tol=1e-12)\n",
            "    for point in condition['points']:\n",
            "        independent_rate = vmax * point['substrate_um'] / (apparent_km + point['substrate_um'])\n",
            "        assert math.isclose(independent_rate, point['initial_rate'], rel_tol=1e-12, abs_tol=1e-12)\n",
            "for control in result['controls']: print('Analytical control:', control)\n",
            "assert all(control['passed'] for control in result['controls'])\n",
            "comparison = result['source_record']['kinetic_comparator']\n",
            "predicted_km = km * (1 + comparison['inhibitor_um'] / ki)\n",
            "difference_um = predicted_km - comparison['apparent_km_um']\n",
            "assert math.isclose(difference_um, result['benchmark_discrepancy']['difference_um'], abs_tol=1e-12)\n",
            "assert result['benchmark_discrepancy']['parameters_refitted'] is False\n",
            "print('Predicted apparent Km:', predicted_km, 'uM; published:', comparison['apparent_km_um'], 'uM; difference:', difference_um, 'uM')\n",
            "print('Discrepancy retained; no fitting or statistical qualification.')\n"]},
        {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
            "import matplotlib.pyplot as plt\n",
        "from IPython.display import display\n",
            "fig, ax = plt.subplots(figsize=(9, 4), constrained_layout=True)\n",
            "for condition in result['conditions']:\n",
            "    points = condition['points']\n",
            "    ax.plot([p['substrate_um'] for p in points], [p['initial_rate'] for p in points], marker='o', label=f\"Lobeline {condition['inhibitor_um']:g} uM\")\n",
            "ax.set(xlabel='Nominal dopamine substrate concentration (uM)', ylabel='Initial uptake rate (pmol/min/mg protein)', title='Source-parameterized rat-vesicle initial-rate sensitivity')\n",
            "ax.legend(); display(fig)\n"]},
        {"cell_type": "markdown", "metadata": {}, "source": [
            "## Preserved contradiction and missing evidence\n",
            "The functional inhibition estimate and control kinetic parameters predict a different apparent Km from the same paper's lobeline kinetic summary. The output reports that difference without fitting it away.\n",
            "Reported SEM is neither individual human variation nor a predeclared acceptance tolerance. Raw replicates, covariance and an independent assay with prospectively specified acceptance criteria are missing. No statistical comparison, dose recommendation, therapeutic benefit or human-equivalence conclusion is supported.\n",
            "The concentration grid is not elapsed time. No human identity, LIFE Patch state, clinical profile or model parameter was changed. VMAT2 may be shown only as a reference mechanism diagram here, not measured atomistic movement.\n"]},
    ]
    for index, cell in enumerate(cells):
        cell["id"] = f"lobeline-analysis-{index}"
    return {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}}, "nbformat": 4, "nbformat_minor": 5}


def _insulin_notebook(result: dict, encoded: str) -> dict:
    cells = [
        {"cell_type": "markdown", "metadata": {}, "source": [
            "# Exogenous insulin, paired within-individual model runs\n",
            "Each member was simulated twice from an identical initial state: a control arm and a treated arm.\n",
            "MODELED_ONLY / NOT_QUALIFIED. No enrolled person was simulated, and nothing here is dosing guidance.\n",
            "The model has no endogenous insulin secretion, so it represents insulin-deficient physiology only.\n"]},
        {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
            "import json, hashlib\n", f"result = json.loads({encoded!r})\n",
            "def digest(value): return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()\n",
            f"assert digest(result) == {hashlib.sha256(encoded.encode()).hexdigest()!r}\n",
            "assert digest(result['input']) == result['input_sha256']\n",
            "assert digest(result['source_record']) == result['source_sha256']\n",
            "print('Frozen run verified:', result['run_id'])\n",
            "print('Parameter source:', result['source_record']['parameter_source'])\n",
            "for control in result['controls']: print('Control:', control)\n",
            "assert all(control['passed'] for control in result['controls'])\n"]},
        {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
            "import pandas as pd\n",
            "rows = [{'member_id': m['member_id'], 'weight_kg': m['weight_kg'],\n",
            "         **{f'control_{k}': v for k, v in m['control'].items()},\n",
            "         **{f'treated_{k}': v for k, v in m['treated'].items()},\n",
            "         **m['paired_difference']} for m in result['members']]\n",
            "frame = pd.DataFrame(rows)\n",
            "print(frame[['member_id','weight_kg','control_nadir_glucose_mmol_L','treated_nadir_glucose_mmol_L','delta_glucose_auc_mmol_L_min']].to_string(index=False))\n",
            "frame[['delta_glucose_auc_mmol_L_min','delta_nadir_mmol_L','delta_minutes_below_3_9']].describe()\n"]},
        {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
            "import matplotlib.pyplot as plt\n",
        "from IPython.display import display\n",
            "fig, axes = plt.subplots(1, 2, figsize=(12, 4), constrained_layout=True)\n",
            "for member in result['members']:\n",
            "    for arm, style in (('control', '--'), ('treated', '-')):\n",
            "        series = member['series'][arm]\n",
            "        axes[0].plot(series['t_min'], series['glucose_mmol_L'], style, alpha=.5)\n",
            "        axes[1].plot(series['t_min'], series['plasma_insulin_mU_L'], style, alpha=.5)\n",
            "axes[0].set(xlabel='Biological time (min)', ylabel='Glucose (mmol/L)', title='Dashed control, solid treated')\n",
            "axes[1].set(xlabel='Biological time (min)', ylabel='Plasma insulin (mU/L)', title='Modelled plasma insulin')\n",
            "display(fig)\n"]},
        {"cell_type": "markdown", "metadata": {}, "source": [
            "## What this does not establish\n",
            "Between-member spread here is sampling from a published parameter distribution, not measured human variability or a confidence interval.\n",
            "No member is a patient, no arm is a clinical comparison, and no result supports a dose for any person.\n",
            "Paired physical measurements under a prespecified protocol remain necessary before any equivalence claim.\n"]},
    ]
    for index, cell in enumerate(cells):
        cell["id"] = f"insulin-analysis-{index}"
    return {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}}, "nbformat": 4, "nbformat_minor": 5}


def _botanical_notebook(result: dict, encoded: str) -> dict:
    cells = [
        {"cell_type": "markdown", "metadata": {}, "source": [
            "# Botanical exposure versus measured active concentration\n",
            f"Program: `{result['program']['program_id']}` - {result['program']['question']}\n",
            "The question is whether exposure of the declared material reaches the concentration range at which the declared mechanism was measured.\n",
            "MODELED_ONLY / NOT_QUALIFIED. A margin below 1 is a negative result and is reported as such. A blocked program reports the missing measurement instead of a number.\n"]},
        {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
            "import json, hashlib\n", f"result = json.loads({encoded!r})\n",
            "def digest(value): return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()\n",
            f"assert digest(result) == {hashlib.sha256(encoded.encode()).hexdigest()!r}\n",
            "assert digest(result['input']) == result['input_sha256']\n",
            "assert digest(result['source_record']) == result['source_sha256']\n",
            "print('Outcome:', result['outcome'], result.get('reason_code') or '')\n",
            "print('Material:', result['material']['compound'], '|', result['material']['non_equivalence'])\n",
            "print('Exposure basis:', result.get('exposure_basis', 'modelled'))\n",
            "print('Active-range source:', result['active_range_source'])\n",
            "for control in result['controls']: print('Control:', control)\n",
            "assert all(control['passed'] for control in result['controls'])\n"]},
        {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
            "import pandas as pd\n",
            "frame = None\n",
            "if result['members']:\n",
            "    frame = pd.DataFrame([{k: v for k, v in m.items() if k not in ('series', 'disposition')} for m in result['members']])\n",
            "    columns = [c for c in ('member_id','weight_kg','cmax_unbound_um','auc_unbound_um_h','margin_to_active_low','reaches_active_range') if c in frame]\n",
            "    print(frame[columns].to_string(index=False))\n",
            "elif result.get('margin'):\n",
            "    print('Measured human exposure; no kinetic model was used.')\n",
            "    for key, value in result['margin'].items(): print(' ', key, '=', value)\n",
            "    print('Study:', result['published_exposure']['design'], '| participants:', result['published_exposure']['participants'])\n",
            "else:\n",
            "    print('No exposure computed.')\n",
            "    print('Reason:', result.get('reason_code'))\n",
            "    print('Missing measurement:', result.get('missing_measurement'))\n"]},
        {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
            "import matplotlib.pyplot as plt\n",
        "from IPython.display import display\n",
            "if result['members']:\n",
            "    fig, ax = plt.subplots(figsize=(10, 4), constrained_layout=True)\n",
            "    for member in result['members']:\n",
            "        ax.plot(member['series']['t_h'], member['series']['unbound_um'], alpha=.6)\n",
            "    if result['active_range_um']:\n",
            "        ax.axhspan(*result['active_range_um'], color='grey', alpha=.25, label='measured active range')\n",
            "        ax.legend()\n",
            "    ax.set(xlabel='Time (h)', ylabel='Unbound concentration (uM)', title='Modelled unbound exposure')\n",
            "    ax.set_yscale('log')\n",
            "    display(fig)\n",
            "elif result.get('margin'):\n",
            "    fig, ax = plt.subplots(figsize=(7, 4), constrained_layout=True)\n",
            "    low, high = result['active_range_um']\n",
            "    ax.axhspan(low, high, color='grey', alpha=.25, label='measured active range')\n",
            "    cmax = result['margin']['unbound_cmax_um']\n",
            "    se = cmax - cmax / max(result['margin']['margin_to_active_low'], 1e-9) * result['margin']['margin_at_one_standard_error_below_cmax']\n",
            "    ax.errorbar([0], [cmax], yerr=[[se], [se]], fmt='o', capsize=6, label='measured C-max (mean, 1 SE)')\n",
            "    ax.set(xticks=[], ylabel='Concentration (uM)', title='Measured human peak against the measured active range')\n",
            "    ax.legend(); display(fig)\n",
            "else:\n",
            "    print('Nothing to plot:', result['outcome'])\n"]},
        {"cell_type": "markdown", "metadata": {}, "source": [
            "## Transfer limits retained\n",
            "The pharmacokinetic values and the active range come from the sources named above, in the species and assay stated there.\n",
            "An in-vitro concentration is not a tissue concentration, a non-human parameter is not a human parameter, and plasma exposure is not brain exposure.\n",
            "A measured exposure belongs to the dose that was administered and is never scaled here to another dose.\n",
            "Reaching the active range supports designing a next experiment; it does not establish efficacy, safety or a human response.\n"]},
    ]
    for index, cell in enumerate(cells):
        cell["id"] = f"botanical-analysis-{index}"
    return {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}}, "nbformat": 4, "nbformat_minor": 5}



__all__ = [
    "ProtocolRunNotFound", "ProtocolRunStore", "analysis_csv", "analysis_notebook",
]
