"""Host toolchain resolution shared by tests, diagnostics and the doctor.

The delivered checkpoint hardcoded the Homebrew Node path, which made every
browser-harness test fail on any machine that is not the author's laptop. This
module resolves executables from the environment first and only then falls back
to well-known locations. It never invents an executable: a missing tool is
reported as missing so callers can skip or fail explicitly.
"""
from __future__ import annotations

from collections.abc import Iterator
import os
import shutil
import subprocess

NODE_ENV = "LIVEMORE_NODE"
PLAYWRIGHT_ENV = "LIVEMORE_PLAYWRIGHT_MODULE"
_NODE_FALLBACKS = ("/opt/homebrew/bin/node", "/usr/local/bin/node", "/usr/bin/node")
# Reached only when no Playwright was found. It is a sentinel that keeps
# `playwright_module()` total, never a location anything is expected at;
# `playwright_available()` reports False for it. It replaced an author
# home path, which had no meaning on a client machine and was published.
_PLAYWRIGHT_FALLBACK = "/nonexistent/livemore/playwright/index.js"


def node_executable() -> str | None:
    """Absolute path of a Node.js executable, or None when none is installed."""
    configured = os.environ.get(NODE_ENV, "").strip()
    if configured:
        return configured if os.access(configured, os.X_OK) else None
    found = shutil.which("node")
    if found:
        return os.path.realpath(found)
    for candidate in _NODE_FALLBACKS:
        if os.access(candidate, os.X_OK):
            return candidate
    return None


def _npm_global_root() -> str | None:
    """Where `npm install -g` puts modules, or None when npm is absent."""
    npm = shutil.which("npm")
    if not npm:
        return None
    try:
        result = subprocess.run([npm, "root", "-g"], capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.SubprocessError):
        return None
    root = result.stdout.strip()
    return root if result.returncode == 0 and root else None


def _module_roots() -> Iterator[str]:
    """Places a client's Playwright plausibly lives, most specific first."""
    yield os.path.join(os.getcwd(), "node_modules")
    yield os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "node_modules")
    # NODE_PATH is the standard way to point Node at a shared module tree.
    for entry in os.environ.get("NODE_PATH", "").split(os.pathsep):
        if entry.strip():
            yield entry.strip()
    root = _npm_global_root()
    if root:
        yield root


def playwright_module() -> str:
    """Playwright entry module used by the browser diagnostics.

    A client who ran `npm install playwright` or `npm install -g playwright`
    should not also have to set an environment variable, so the ordinary module
    locations are searched before falling back.

    The historical author path stays as the last fallback so retained diagnostic
    receipts remain reproducible; it is not a claim that the file exists.
    """
    configured = os.environ.get(PLAYWRIGHT_ENV, "").strip()
    if configured:
        return configured
    for base in _module_roots():
        candidate = os.path.join(base, "playwright", "index.js")
        if os.path.isfile(candidate):
            return candidate
    return _PLAYWRIGHT_FALLBACK


def playwright_available() -> bool:
    return os.path.isfile(playwright_module())

# The cardiac engine hosts O'Hara-Rudy through Myokit/CVODE, which compiles C at
# run time. That needs a compiler and the SUNDIALS headers, which are not Python
# packages and cannot be pinned in the lock.
CARDIAC_REQUIRES = ("a C compiler (gcc/clang)", "SUNDIALS headers: "
                    "`brew install sundials` or `apt install libsundials-dev`")


def _probe_cardiac() -> None:
    """Compile and step the smallest possible CVODE simulation."""
    import myokit

    model = myokit.parse_model("\n".join((
        "[[model]]", "membrane.V = -80",
        "[engine]", "time = 0 bind time",
        "[membrane]", "dot(V) = -0.1 * V", "")))
    myokit.Simulation(model).run(1.0)


def cardiac_simulation() -> dict[str, object]:
    """Whether real cardiac simulation can run here, and what is missing if not.

    Callers skip rather than fail: a client without SUNDIALS should still be
    able to install and use everything else, and be told plainly which engine
    is unavailable.
    """
    requires = "; ".join(CARDIAC_REQUIRES)
    try:
        _probe_cardiac()
    except Exception as error:  # noqa: BLE001 - any failure means unavailable
        detail = str(error).strip().splitlines()[0] if str(error).strip() else type(error).__name__
        return {"available": False, "requires": requires,
                "reason": f"Cardiac simulation needs a C compiler and SUNDIALS "
                          f"(libsundials-dev / brew install sundials): {detail}"}
    return {"available": True, "requires": requires, "reason": None}


def cardiac_available() -> bool:
    return bool(cardiac_simulation()["available"])
