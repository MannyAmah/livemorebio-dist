"""Identity of loaded source normalization code; never hashes a changed disk file.

This is a reproducibility gate, not proof of clinical validity. Only the reviewed
XPORT decoder release is accepted. Existing frozen records do not call this gate.
"""
from __future__ import annotations

import hashlib
import json
import sys
from types import CodeType, FunctionType, ModuleType
from typing import Any

import numpy as np
import pandas as pd
from pandas.io.sas import sas_xport

from . import population_records, population_sources


class PopulationIdentityError(ValueError):
    """Unknown or runtime-replaced normalization requires source review."""


def _portable_code(code: CodeType) -> CodeType:
    return code.replace(co_filename="<loaded-code>", co_consts=tuple(_portable_code(value) if isinstance(value, CodeType) else value for value in code.co_consts))


def _canonical_code(code: CodeType) -> dict[str, Any]:
    """A deterministic structural description of a code object.

    ``marshal.dumps`` was used here, and it is not canonical: it encodes object
    sharing as back-references, so two byte streams can differ while decoding to
    equal code objects. Running unrelated tests changed which strings were
    shared, the digest moved, and the gate refused a decoder that had not
    changed -- which stopped a client installing.

    Every field that defines what the code *does* is included, so a real change
    to the decoder still changes the digest. Only the byte-level encoding of
    sharing is dropped.
    """
    return {
        "argcount": code.co_argcount, "posonlyargcount": code.co_posonlyargcount,
        "kwonlyargcount": code.co_kwonlyargcount, "nlocals": code.co_nlocals,
        "stacksize": code.co_stacksize, "flags": code.co_flags,
        "code": code.co_code.hex(),
        "names": list(code.co_names), "varnames": list(code.co_varnames),
        "freevars": list(code.co_freevars), "cellvars": list(code.co_cellvars),
        "consts": [_canonical_const(value) for value in code.co_consts],
    }


def _canonical_const(value: Any) -> Any:
    if isinstance(value, CodeType):
        return {"__code__": _canonical_code(value)}
    if isinstance(value, tuple):
        return {"__tuple__": [_canonical_const(item) for item in value]}
    if isinstance(value, frozenset):
        return {"__frozenset__": sorted(repr(item) for item in value)}
    if isinstance(value, bytes):
        return {"__bytes__": value.hex()}
    if isinstance(value, bool) or value is None or isinstance(value, (str, int)):
        return value
    if isinstance(value, float):
        # repr keeps NaN and signed zero distinct, which json does not.
        return {"__float__": repr(value)}
    if isinstance(value, complex):
        return {"__complex__": repr(value)}
    return {"__repr__": repr(value)}


def _code_digest(code: CodeType) -> str:
    return hashlib.sha256(json.dumps(_canonical_code(code), sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def _module_identity(module: ModuleType) -> str:
    functions: dict[str, str] = {}
    for name, value in sorted(vars(module).items()):
        if isinstance(value, FunctionType) and value.__module__ == module.__name__:
            functions[name] = _code_digest(_portable_code(value.__code__))
        elif isinstance(value, type) and value.__module__ == module.__name__:
            for method_name, method in sorted(vars(value).items()):
                if isinstance(method, (classmethod, staticmethod)):
                    method = method.__func__
                if isinstance(method, FunctionType):
                    functions[name + "." + method_name] = _code_digest(_portable_code(method.__code__))
    return hashlib.sha256(json.dumps(functions, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _function_identity(function: FunctionType) -> str:
    description = {"code": _code_digest(_portable_code(function.__code__)),
                   "defaults": function.__defaults__, "keyword_defaults": function.__kwdefaults__}
    return hashlib.sha256(json.dumps(description, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _function_defaults(module: ModuleType) -> dict[str, Any]:
    result = {}
    for name, function in sorted(vars(module).items()):
        if isinstance(function, FunctionType) and function.__module__ == module.__name__:
            result[name] = [function.__defaults__, function.__kwdefaults__]
        elif isinstance(function, type) and function.__module__ == module.__name__:
            for method_name, method in sorted(vars(function).items()):
                if isinstance(method, (classmethod, staticmethod)):
                    method = method.__func__
                if isinstance(method, FunctionType):
                    result[name + "." + method_name] = [method.__defaults__, method.__kwdefaults__]
    # Copies remove mutable default-object aliases from the captured snapshot.
    return json.loads(json.dumps(result, sort_keys=True, allow_nan=False))


def _loaded_identity() -> dict[str, Any]:
    return {"release": "joint-public-reference-normalization-1", "python": f"{sys.version_info.major}.{sys.version_info.minor}",
            "pandas": pd.__version__, "numpy": np.__version__, "xport_code_sha256": _module_identity(sas_xport),
            "transport_code_sha256": _module_identity(population_sources), "normalizer_code_sha256": _module_identity(population_records),
            "read_sas_entrypoint_sha256": _function_identity(pd.read_sas),
            "defaults": {module.__name__: _function_defaults(module) for module in (sas_xport, population_sources, population_records)},
            "ordered_tables": list(population_records._TABLE_NAMES),
            "source_manifest_sha256": population_sources.manifest_hash(),
            "definitions": population_records.definitions()}


# Captured once from actual functions in memory, including the reviewed exact
# all-zero transport correction. A file edited after import cannot change this.
_LOADED = _loaded_identity()
_REVIEWED_DECODERS = {
    # The installed decoder inspected and exercised against the pinned 14-file
    # release in the source-admission decision; upgrades require a new review.
    # Restated on 2026-09-24 as a canonical structural digest. The reviewed
    # artefact is unchanged -- still pandas 2.3.3's XPORT decoder -- only the
    # digest function is now deterministic, because the previous marshal-based
    # one moved with interpreter string sharing and refused this same decoder.
    ("3.11", "2.3.3"): "1375f50f766febb4ca2019f152b672f3e08e03b7a6f457a5ff010dac5a229333",
}
_REVIEWED_ENTRYPOINTS = {
    ("3.11", "2.3.3"): "78577330ce1d57110d9c2ca2cae6c91095f9a56745ceb9dd68c6ece3fb261e12",
}


def _divergence(current: dict[str, Any]) -> str:
    """Name what diverged, so a refusal can be acted on.

    This gate protects a reviewed decoder, so it must stay closed. But a bare
    "requires review" leaves an operator — or a client whose install it just
    refused — with nowhere to start. Field names and version strings only; no
    hash contents beyond the field that differs.
    """
    key = (current["python"], current["pandas"])
    reasons = []
    drifted = sorted(name for name in set(current) | set(_LOADED)
                     if current.get(name) != _LOADED.get(name))
    if drifted:
        reasons.append("changed after import: " + ", ".join(drifted))
    if _REVIEWED_DECODERS.get(key) != current["xport_code_sha256"]:
        reasons.append(f"no reviewed decoder for python {key[0]} with pandas {key[1]}"
                       if key not in _REVIEWED_DECODERS else
                       "the installed decoder does not match the reviewed one")
    if _REVIEWED_ENTRYPOINTS.get(key) != current["read_sas_entrypoint_sha256"]:
        reasons.append(f"no reviewed read_sas entrypoint for python {key[0]} with pandas {key[1]}"
                       if key not in _REVIEWED_ENTRYPOINTS else
                       "the installed read_sas entrypoint does not match the reviewed one")
    return "; ".join(reasons) or "an unidentified difference"


def normalization_version() -> str:
    current = _loaded_identity()
    expected = _REVIEWED_DECODERS.get((current["python"], current["pandas"]))
    if (current != _LOADED or expected != current["xport_code_sha256"]
            or _REVIEWED_ENTRYPOINTS.get((current["python"], current["pandas"])) != current["read_sas_entrypoint_sha256"]):
        raise PopulationIdentityError(
            "The loaded population decoder or normalization implementation requires review "
            f"({_divergence(current)}).")
    digest = hashlib.sha256(json.dumps(_LOADED, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    return f"joint-public-reference-v1:python-{current['python']}:pandas-{current['pandas']}:numpy-{current['numpy']}:sha256-{digest}"
