# LivemoreBio contributor contract

The parent Livemore workspace rules apply. This is pharmaceutical research software,
not an established exact human replica or a substitute for physical experiments.

## Biological learning is a release prerequisite

Every human or agent changing biological behavior must read
`docs/BIOLOGICAL_MODEL_CHANGE_CONTRACT.md`, search `docs/solutions/`, and examine the
actual implemented equations and their primary sources before editing.

Each change requires a written biological rationale, source/counterevidence record,
state variables with units, scope and boundary conditions, person-specific parameter
provenance, identifiability/conservation checks, a falsification test, and independent
review. Reading a paper or retrieving an annotation is not model qualification.

Do not introduce generic positive effects for unknown chemicals, assign allele
frequencies from disease labels, translate target annotations into physiological
rates without an admitted mechanism, or animate uncomputed reactions. Missing
biology must fail explicitly. Learning proposals never mutate a live twin.

## Verification and worktree isolation

Write a plan before code and failing tests before behavior changes. Review code
independently and use the real browser for UI checks. Preserve prior worktrees.
Use `LIVEMORE_DATA_DIR` plus the documented endpoint overrides for an isolated
review stack; never reuse a real person's runtime state for demos. Fixtures are
always labeled technical, not observed physical data.

Do not put PHI, credentials, licensed datasets, local encryption keys or raw private
instrument files into source control, recordings, logs or third-party prompts.
The current single-operator local deployment is not a production PHI environment.

Changes ship through a feature PR, never a direct push to main. Capture lessons in
`docs/solutions/`; consult `docs/PHARMA_READINESS_AND_ROADMAP.md` before external claims.
