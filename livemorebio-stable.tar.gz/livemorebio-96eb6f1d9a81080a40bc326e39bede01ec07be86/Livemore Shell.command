#!/bin/zsh
# Double-click (or run from Terminal) → the LivemoreBio interactive pharma environment.
cd "$(dirname "$0")" || exit 1
clear
./.venv/bin/livemore start >/dev/null 2>&1
exec ./.venv/bin/livemore
