#!/bin/zsh
cd "$(dirname "$0")" || exit 1
clear
echo "Running the LivemoreBio test suite…"
./.venv/bin/python -m pytest -q
echo
echo "Done. Press Return to close."
read
