#!/bin/zsh
# Double-click → start LIFE :8851, Aegle :8850, Cendos :8852 and open the web console.
cd "$(dirname "$0")" || exit 1
clear
echo "Starting the LivemoreBio infrastructure (LIFE :8851 · Aegle :8850 · Cendos :8852)…"
./.venv/bin/livemore start
( sleep 2 && open "http://127.0.0.1:8850" ) &
echo
echo "Console: http://127.0.0.1:8850   (services keep running when this window closes)"
echo "Mutation token: run ./.venv/bin/livemore token and paste it once per browser tab."
echo "Stop with: ./.venv/bin/livemore stop   — or use 'Livemore Stop.command'."
echo "Press Return to close this window."
read
