#!/bin/zsh
cd "$(dirname "$0")" || exit 1
./.venv/bin/livemore stop
echo "Stopped. Press Return to close."
read
