# LivemoreBio

## September 10, 2026 — complete historical handoff

Start with the [complete product handoff](docs/handoff/2026-09-10/LIVEMORE_BIO_COMPLETE_HANDOFF.md)
for the original mandate, implementation history, source map, experiments,
failed attempts, tool decisions, remaining work, videos and technical deck.
The [publication receipt](docs/handoff/2026-09-10/PUBLICATION_RECEIPT.md)
records this private feature-branch research checkpoint and fresh verification.
Publication preserves work; it does **not** establish whole-human equivalence,
physical LIFE Patch validation, a completed Cendos wet lab or pharmaceutical
production readiness. Dated status statements below remain historical.

Core computational-biology infrastructure for biotech and drug development, built
toward a complete biological functional human-body replica. The product is three
connected systems: the LIFE measurement and device data plane, the Aegle
person-state and simulation plane, and the Cendos experiment and evidence plane.

The current release is not a complete living-human replica or clinical decision
system. It provides an all-system architecture contract plus executable,
model-only metabolic and cardiovascular contexts. Every other body system is
registered and reference-backed but refuses functional claims until an engine,
coupling, calibration, and context-specific validation actually exist.

## Status — whole-human contract, two modeled contexts

**September 9 recovery checkpoint — current worktree, not a published release.**
Start with the [current delivery review](docs/DELIVERY_REVIEW_2026-09-09.md),
[checkout-specific external tester guide](docs/EXTERNAL_TESTER_GUIDE_2026-09-09.md),
[recorded workflow evidence](docs/deliverables/2026-09-09-workflows/VIDEO_WALKTHROUGHS.md),
and [technical product deck](docs/deliverables/technical-product-deck/README.md).
The full product and six requested scientific programs are **not complete**.
The dated review distinguishes recovered software from blocked biological,
native-engine, physical-device and wet-lab qualification. Older descriptions,
videos and installer links below are preserved historical context; they are not
acceptance evidence or an installation path for this unmerged worktree.

September 8 additive review work: [measurement integrity and run-bound Biology guide](docs/MEASUREMENT_INTEGRITY_REVIEW_GUIDE.md)
documents the new `codex/measurement-integrity-atlas` branch, explicit v3/v2 sampling,
unavailable physical transfer mappings and the bounded nonhuman lobeline assay.
Its final verification and publication are pending. The earlier release and its
evidence below are preserved; their implicit Patch sampling/reconciliation examples
do not describe this correction candidate.

September 5 extended candidate: start with the tested-candidate installation and
operating steps in [the external tester guide](docs/EXTERNAL_TESTER_GUIDE.md),
[Human-GEM source and integrity contract](docs/HUMAN_GEM_MODEL_SOURCES.md),
[candidate verification evidence](docs/GENOME_MODEL_REVIEW_EVIDENCE.md), and
[the next-body/LIFE/physical-Cendos roadmap](docs/MULTISCALE_DEVELOPMENT_ROADMAP.md).
The preserved research workflows remain documented in [the research validation guide](docs/RESEARCH_VALIDATION_GUIDE.md),
[pharmaceutical readiness and roadmap](docs/PHARMA_READINESS_AND_ROADMAP.md), and
[the biological model change contract](docs/BIOLOGICAL_MODEL_CHANGE_CONTRACT.md).
The [earlier verification report](docs/RESEARCH_REVIEW_EVIDENCE.md) preserves the
previous candidate's 624-test/15-skip result; it is not this build's model readiness.
The old unsafe GEM-to-physiology loaders are retired, independent safety tests are
no longer hidden behind missing files, and the new full installer executes real
pinned Human-GEM tests. Watch the
[completed 6:58 plant and 8:10 metformin walkthroughs](docs/demo/research-validation/README.md)
with executed Jupyter notebooks and artifact hashes.
This branch is not a pharmaceutical production release. The main-branch installer below
does not include this candidate until its PR is reviewed and merged.

- **Whole-human capability manifest** — all 15 systems in the canonical anatomy
  ontology are exposed with independent maturity claims: registered,
  reference-backed, modeled, coupled, person-calibrated, context-validated,
  independently replicated, and device-connected. Architectural inclusion never
  promotes scientific maturity.
- **Pinned Human-GEM reference metabolism** — Human2 v2.0.0 provides 12,931 reactions,
  8,461 metabolites and 2,848 genes. Cendos executes explicit glucose/oxygen-limited
  ATP-capacity conditions and complete GPR-aware gene knockouts in an isolated GLPK
  worker. Negative controls, conservation/bound checks, source/software digests,
  directed reference annotations, CSV and executable notebooks travel with every run.
  This is steady-state reference-network computation, not person physiology or a new
  arbitrary-drug reaction engine. Recon3D remains commercially restricted.
- **Clean research workflow** — a fresh data directory has no twins, cohorts or runs,
  and starts with an unregistered healthy reference preview. Cendos opens Preparation;
  searchable/paged History supports recall and explicit parent-linked reruns without
  overwriting originals. Twin/cohort lists are paged and searchable. Biology data loads
  independently of graphics, with visible retry and unavailable-organ boundaries.
- **Metabolic engine** — executable **glucose–insulin** ODEs (reduced Bergman model,
  SciPy/LSODA). Output depends on explicitly recorded model parameters; diagnostic
  labels and gene associations no longer inject arbitrary physiological multipliers.
  Reproducing a numerical reference pattern is not human validation.
- **Cardiac engine** — the published **O'Hara–Rudy CiPA 2017** human ventricular
  myocyte (49 states) hosted natively via Myokit/CVODE from its CellML source.
  Physiologic AP: rest ≈ −88 mV, peak ≈ +41 mV, APD90 ≈ 268 ms. IKr block
  (drug or coupling) prolongs APD — the hERG/QT mechanism (50% block → +100 ms).
- **Cross-scale coupling** — explicit reduced-model coupling experiments connect
  metabolic and cardiac parameters. Their coupling laws require independent validation;
  they are not established individual human causal transfer functions.
- **Executable multiscale workspace** — the default Aegle surface binds formal
  all-system contracts to the first deep executable path: SLC22A1/OCT1 and drug
  exposure → hepatocyte/liver glucose output → endocrine dynamics → IKr,
  cardiomyocyte, ventricular tissue, heart, and whole-body readouts. Baseline and
  treated traces, biological time, person parameters, engine lineage, and evidence
  state travel together. Systems without executable models expose contracts and an
  explicit unavailable state rather than invented output.
- **Governed twin and cohort lifecycle** — `/twins` admits either a consented real-human
  profile with field-level EHR, laboratory, device, medication, genomic, lifestyle, and
  environmental provenance, or a non-person research twin generated server-side from a
  pinned population manifest and stratum. Missing real-human domains remain missing;
  caller-entered values cannot masquerade as reference data. `/cohorts` materializes and
  freezes heterogeneous member profiles, seeds, source lineage, and fingerprints. Exactly
  one twin is authoritative across Atlas, LIFE Patch, Cendos, terminal, and notebooks.
  Physical Patch pairing additionally requires an active consented real-human twin,
  B0/protocol metadata, current calibration, device attestation, and device uniqueness.
- **Patch-to-twin reconciliation** — physical and virtual v2 observations share one
  device contract. The workspace computes observed-versus-virtual residuals only
  when signal units and quality gates agree; it never silently updates model
  parameters or authorizes calibration.
- **Cendos translation gate** — frozen prediction/measurement counterparts are bound
  by subject, endpoint, unit, protocol, timing window, population, intervention, and
  dose. A passing tolerance creates a candidate validation event for EvidenceService
  review, not self-validation and never automatic calibration.
- **Cendos computational assay** — evaluate supported protocols against their frozen
  baseline without mutating a live twin. Metformin uses an individualized one-compartment
  PK path and declared heuristic PD assumptions. Unknown compounds and arbitrary
  user-entered plant benefit multipliers now fail closed.
- **Governed cohort protocols** — the first bounded workflows compare individualized
  metformin PK→PD→OGTT responses across two pinned metabolic strata and evaluate purified
  garcinoic-acid engagement of human PXR from the 6P2B co-crystal plus published Kd/EC50
  inputs. Each run is durable and run-scoped, exports CSV and a Jupyter notebook, and can
  be projected into Biology. Both remain modeled and not qualified until their required
  physical Cendos or human counterpart measurements pass the evidence gate.
- **Pharma cohort screen** — an explicit T2D-enriched synthetic cohort, OGTT assay,
  dose→exposure→effect metformin path, pinned ChEMBL resolution, per-run durable
  reports, and a local integrity record that binds the complete ranking.
- **Scientific adapter registry** — active retrieval paths, bounded health probes,
  license links, credential gates, and hard blocks for commercially restricted
  sources. Adapter readiness never upgrades scientific maturity.
- **Governed NAR/ELIXIR catalog** — a versioned metadata snapshot contains all 39
  current ELIXIR Core Data Resources and every discoverable entry on the official NAR
  alphabetical collection page. The NAR snapshot contains 2,594 summary-paper entries
  while preserving the collection's reported 2,173 independent-database count and its
  update/duplicate distinction. Runtime use requires the explicit lifecycle
  `cataloged → evaluated → configured → operational → workflow_wired →
  scientifically_qualified`; catalog-only sources are never queried by experiments.
- **Mechanistic acceptance tests pass.** _Not clinically validated; parameters are
  literature-typical, not cohort-fitted._

- **Research comparison workspace**, `/research` — freeze endpoint tolerances, member
  mappings and saved prediction hashes; admit raw measurement CSV with custody/QC;
  compare matched endpoints. Technical fixtures cannot become physical evidence, and
  no comparison authorizes calibration automatically.
- **Treatment-free resilience** — predeclare all five cure operations, individual healthy
  ranges, independent subjects, washout, post-washout follow-up and stress conditions.
  Evaluate admitted measurements with a one-sided confidence bound; missing evidence
  remains missing. This is an assessment contract, not a cure claim or therapy optimizer.
- **Continuous biological learning** — versioned proposals across eight biological scales
  record primary sources, counterevidence, applicability and tests. Proposals do not alter
  active twins or create a reinforcement-learning system by themselves.

- **LIFE Patch v2 closed loop** — one manifest, telemetry, quality, command, and receipt
  contract shared by the physical gateway and virtual patch. LIFE registers devices,
  rejects invalid/replayed data, journals admitted envelopes, forwards observations to
  Aegle, and exposes the same immutable references to Cendos. The B0 software target uses
  MAX86141 over SPI, AD5940 without redundant LMP91000, isolated authenticated pods, and
  QSPI storage. Telemetry updates observed state only; calibration requires released
  evidence authorization. Physical firmware and analytical equivalence remain pending.

## September 22, 2026 — fresh-machine installability and the six programs

Three defects made the previous checkpoint uninstallable or unverifiable away
from the author's laptop, and two made the six requested programs impossible to
execute at all. All five are fixed; see
[the continuation plan](docs/solutions/2026-09-22-real-systems-continuation-plan.md)
and [the lessons record](docs/solutions/2026-09-22-fresh-machine-and-six-program-lessons.md).

- The dependency lock pinned a libcellml release PyPI had withdrawn, so the
  one-line installer could not install anywhere.
- Twenty test modules hardcoded one machine's Node path, and the suite read the
  developer's private key files; on any other machine, or an empty home
  directory, hundreds of tests failed.
- The endocrine engine had no exogenous insulin input, and the botanical
  intervention path always raised.

Now: the exogenous-insulin engine is the published Hovorka system with
per-parameter source lineage, and all six programs execute from the terminal,
the SDK, the API and Jupyter. Programs whose sources are missing or mutually
inconsistent report exactly which measurement is absent instead of producing a
number. Executed evidence is in
[the September 22 deliverables](docs/deliverables/2026-09-22-six-programs/README.md).

**Validation status is unchanged: 0/6 validated in vivo.** Execution is not
validation, and nothing in these programs is dosing guidance.

```
livemore doctor            # fresh-machine readiness; exit 1 when a required check fails
livemore programs list     # the six programs and whether each can be executed
livemore programs run LBHR-030 --dose-mg 400
livemore notebook          # Jupyter Lab workspace with the SDK pre-wired
```

In the shell or a pipeline file:

```
program list
program show LBHR-129
program run LBHR-030 dose_mg=400 cohort=10 seed=1 output=run.json
insulin products
insulin run units=4 meal=60 cohort=12 seed=1
```

## Supported platforms

The product enforces local confidentiality of PHI-like state with POSIX file
semantics: 32 owner-only checks across the registry, execution store, evidence
store, protocol runs, model assets, anatomy cache and the LIFE Patch journal.

| Platform | Status |
|---|---|
| macOS, Linux | Supported natively; use the one-line installer |
| Windows via Docker Desktop | Supported; `docker compose up`, then http://127.0.0.1:8850 |
| Windows via WSL2 | Supported; use the one-line installer inside the distribution |
| Windows natively | Refused with guidance, because it cannot express the owner-only guarantees the product depends on |

`livemore doctor` reports the platform and exits non-zero when a required check
fails. The `Platforms` workflow builds the container image, starts the three
services and drives an insulin run, a botanical run and a blocked program
through the container API, so the client path is verified rather than assumed.
See [readiness, platforms and unblocking paths](docs/solutions/2026-09-22-readiness-platforms-and-unblocking-paths.md).

## Running it — terminal-launched infrastructure

LivemoreBio is infrastructure, not a web app. The three infrastructures run as independent
services that discover each other through a shared registry (`~/.livemore/registry.json`)
and cooperate in real time:

### Install with one command

The repository is private, so the installer uses your existing GitHub authorization.
Install [GitHub CLI](https://cli.github.com/), run `gh auth login` once, and make sure
`python3.11` is available. Then copy and run this single line:

```bash
bash -c 'set -euo pipefail; command -v gh >/dev/null || { echo "Install GitHub CLI first: https://cli.github.com" >&2; exit 1; }; gh auth status >/dev/null || { echo "Run: gh auth login" >&2; exit 1; }; c=$(gh api repos/MannyAmah/livemorebio/commits/main --jq .sha); f=$(mktemp); trap '\''rm -f "$f"'\'' EXIT; gh api "repos/MannyAmah/livemorebio/contents/install.sh?ref=$c" -H "Accept: application/vnd.github.raw+json" >"$f"; test -s "$f"; LIVEMORE_REF="$c" bash "$f"'
```

It downloads one pinned commit, installs the hash-locked scientific, server, notebook,
and test dependency set, runs the full test and compile gates, and makes `livemore`
available in new terminals. Each release is built while inactive and the `current`
pointer changes only after verification, so a failed update leaves the previous
installation working. Reused releases are checked against an external full-tree digest.

After installation:

```
livemore start all        # or: livemore start LIFE / Aegle / Cendos
livemore status           # live health of LIFE :8851, Aegle :8850, Cendos :8852
livemore models check human-gem  # extended candidate: verified model readiness, separate from HTTP health
livemore manifest         # all human systems + honest maturity and integration state
livemore workspace        # compact live multiscale projection from the running product
livemore sources --workflow reactions_metabolism  # only runtime-wired sources for this workflow
livemore open             # open the Aegle console in the browser
livemore attach           # operate the same live twin, cohorts, Patch, and assays in terminal
livemore stop all
```

The same manifest is available to scripts and notebooks through
`from livemorebio import whole_human_manifest` or `Platform().manifest()`, and
to services through `GET http://127.0.0.1:8850/api/system-manifest`.

- **LIFE** (:8851) — the population/reference substrate plus the LIFE Patch v2 device
  gateway (`/patch/devices`, `/patch/telemetry`, `/patch/virtual/sample`, `/patch/commands`).
- **Aegle** (:8850) — the living-twin console + reactive API; shows all three services live at the bottom.
- **Cendos** (:8852) — supported computational protocols and compound identity lookup.
  A database hit is not a batch composition, purity assay, bioavailability estimate or causal model;
  mixtures such as botanical extracts cannot be represented by an invented single molecule.

Start the stack with `livemore start all`, then run `livemore open`. The loopback browser
session authorizes itself through a same-origin bootstrap and an HttpOnly, SameSite=Strict
cookie; there is no token prompt. The launcher still generates an owner-only operator token
at `~/.livemore/api-token` for terminal/SDK and explicit API clients. `livemore token` is an
optional diagnostic/export command for `curl`, not a browser setup step or external account.
Read the full [launch guide](docs/LAUNCH_GUIDE.md) for installation, page-by-page
operation, Docker, terminal workflows, and troubleshooting. The
[closed-loop operating contract](docs/LIFE_PATCH_CLOSED_LOOP.md) documents the device,
telemetry, command, laboratory-counterpart, and scientific-reference interfaces.

For this unmerged extended candidate, use the **candidate** one-line installer in
the [external tester guide](docs/EXTERNAL_TESTER_GUIDE.md), not the main command
above. It includes verified Human-GEM assets and actual model-execution release
gates. Existing runtime records are preserved; blank state means a new data directory.

The console must be opened from **http://127.0.0.1:8850** (served by the running Aegle service),
never as a bare file — otherwise it can't reach the API. If it can't, the console now says so
in a red banner instead of sitting silently static.

## LIFE System — measured-human data plane and reference population

The LIFE System is the boundary where lawful measured-human data, external clinical
and laboratory sources, the virtual LIFE Patch, and eventually the physical LIFE
Patch enter Livemore. Its reference population uses curated anatomy, disease,
pathway, gene, and atlas records to create synthetic model inputs. Those inputs are
not a person's biology and synthetic output is not measured-human data.

Commercial reference sources are governed separately. KEGG requires recorded commercial
entitlement for this product and GeneCards requires a licensed API/export path; neither is
scraped or silently embedded. Their connectors fail closed and expose only an audit-safe
entitlement fingerprint. When configured, `GET /reference/genes/{symbol}` combines their
licensed gene records into hashed reference context without promoting any evidence claim.
The NAR database collection is a discovery index, not a blanket license for its linked
databases.

When physical LIFE Patch hardware is validated, its packets can use the same signal
schema. Cloud or Aegle commands may never bypass a physical device's local safety
controller.

Reference cohorts are heterogeneous prior-generated research inputs, not recruited humans
or measured individual records from NHANES/DPP. Diagnosis and gene annotations alone do not
establish quantitative physiology. Actual onboarding must preserve measured values, units,
identity, timing, lawful use and missingness; omitted fields remain explicitly reference-initialized.

`data origin` (synthetic-model vs measured observation) — **not** sensor "claim/trust" — is
the meaningful distinction; claim classes belong to the physical instrument alone.

## Knowledge graph, retrieval & clinical extraction

The substrate offers three interfaces with different operational maturity:

- **Graph** (`graph.py`) — the biology as a NetworkX property graph (Gene ↔ Disease ↔ Pathway ↔ Organ ↔ Drug): neighbours, subgraphs, and mechanistic paths (e.g. `TCF7L2 → Type 2 diabetes → pancreas`). Neo4j loading now uses explicit environment credentials and parameterized writes. Production still requires Enterprise-grade RBAC, backup/restore, and a live integration qualification; no default password exists.
- **Retrieval** (`retrieval.py`) — a numpy TF-IDF/cosine `SubstrateIndex`: natural-language queries ("insulin resistance") rank relevant diseases, genes, and pathways. TuringDB is an isolated evaluation candidate, not a production path; commercial clearance, durability, access control, and benchmarks remain hard gates.
- **Clinical extraction** (`extract.py`) — `ClinicalExtractor` grounds synthetic/non-PHI text in the local substrate. `OpenMedNER` uses the current local `openmed.deidentify(...) → openmed.analyze_text(...)` API when installed. PHI-like input fails closed unless local de-identification is operational. OpenMed is clinical intake, never the biological-reaction engine.

The catalog is queryable from the web (`/adapters`), API
(`GET /api/scientific-sources`), SDK (`Platform().scientific_sources(...)`), and
terminal (`livemore sources`). Refresh metadata from the authoritative pages with:

```bash
python3 tools/refresh_scientific_source_catalog.py
```

The refresh downloads metadata only; it never downloads a scientific dataset or advances
any source beyond `cataloged`.

## Simulation kernels installed and verified
libRoadRunner (SBML) · libSBML · libCellML (Physiome native format) · COPASI/BasiCO
· Myokit/CVODE (cardiac). These host published Physiome / BioModels / CellML organ
& cell models. LivemoreBio owns the cross-scale **state engine** and **coupling**
that bind implemented contexts into the evolving whole-human architecture.

## Architecture (direction)
LIFE System (DNA → RNA → protein → cell → organ → … → environment) → **Aegle**
twin (state engine + cross-scale coupler) → **Cendos** computational protocols and
physical counterpart intake → run-bound visualisation. Heavy engines (PhysiCell,
BioDynaMo, AlphaFold/ESM/Evo, SimVascular/OpenFOAM) are candidates, not evidence of
installed, wired or scientifically qualified functions in this release.

## Manual developer installation

The one-line installer above is the supported product path. Contributors who need an
editable checkout can still install manually:

    python3.11 -m venv .venv
    ./.venv/bin/python -m pip install --require-hashes -r requirements-python311.lock
    ./.venv/bin/python -m pip install --no-deps --no-build-isolation -e .
    ./.venv/bin/python -m pytest -q
    ./.venv/bin/python -m compileall livemorebio


## Launch the Aegle living console

    ./.venv/bin/livemore start all
    ./.venv/bin/livemore open
    # or double-click "Livemore Console.command"

Whole-body twin: the cardiac context executes the O'Hara–Rudy action-potential and
calcium model; the metabolic context executes its glucose–insulin equations; controls
apply declared model perturbations (hERG blocker / metformin / meal / lifestyle) and
recompute the connected state. These are executable model outputs, not observed human
reactions. Systems without an engine are marked *pending*, never faked.

The default `/` page is the merged Atlas workspace. Governed subject onboarding is at
`/twins`, cohort definition is at `/cohorts`, and the previous Aegle console remains at
`/legacy`. Biology, LIFE Patch, Cendos, and Adapters remain first-class linked surfaces.

The replacement detailed recordings and executed analysis notebooks are documented in
[the September 5 recording guide](docs/demo/research-validation/RECORDING_GUIDE.md).
They show software operation, not physical human reactions. The older short recordings below
are retained only as historical artifacts and are superseded for review:

- [governed workspace](docs/demo/livemorebio-governed-workspace-demo.mp4)
- [metformin across two individualized cohorts](docs/demo/livemorebio-metformin-two-cohorts-demo.mp4)
- [purified garcinoic acid → human PXR](docs/demo/livemorebio-garcinoic-acid-pxr-demo.mp4)

The protocol inputs, exact evidence boundaries, attached-file hashes, observed QA outcomes,
and interpretation guide are in
[docs/VALIDATION_AND_DEMO_GUIDE.md](docs/VALIDATION_AND_DEMO_GUIDE.md).

## Honest boundaries (no fakes)
Capital-intensive components — physical lab instruments, wet biology, GPU-scale
simulation — are built as real interfaces/repos, never stubbed as if running
locally. Auditable ≠ validated.

The current services are loopback-only research infrastructure. Mutation routes and
selected PHI-like reads require a local bearer token. Local patch journals, bus events,
and snapshots are encrypted with an owner-only AES-256-GCM key generated by the launcher.
The platform is not tenant-isolated and is not approved for production PHI or
partner-confidential inputs. Read-only screen reports are scoped to a unique run id;
evidence export is an authenticated lifecycle mutation.
