#!/bin/zsh
# Double-click → Jupyter Lab workspace with the LivemoreBio SDK pre-wired.
cd "$(dirname "$0")" || exit 1
clear
./.venv/bin/livemore start >/dev/null 2>&1
echo "Starting Jupyter Lab… keep this window open; Ctrl-C stops it."
exec ./.venv/bin/livemore notebook
