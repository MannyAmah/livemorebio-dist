#!/bin/zsh
# Double-click to launch the Aegle living-twin console.
cd "$(dirname "$0")"
lsof -ti tcp:8850 2>/dev/null | xargs kill -9 2>/dev/null
( sleep 2 && open "http://127.0.0.1:8850" ) &
exec ./.venv/bin/python -m livemorebio.aegle.server
