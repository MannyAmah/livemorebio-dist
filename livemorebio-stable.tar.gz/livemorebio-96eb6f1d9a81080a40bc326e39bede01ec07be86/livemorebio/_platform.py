"""Platform support contract.

LivemoreBio enforces local confidentiality of PHI-like state with POSIX file
semantics: owner-only directories and files (0700/0600), single-link regular
files, owner identity checks (``st_uid``) and advisory locks. Thirty-two such
gates exist across the registry, execution store, evidence store, protocol runs,
model assets, anatomy cache and LIFE Patch journal.

Windows does not express those guarantees the same way: ``st_uid`` is always 0,
``chmod`` only toggles a read-only bit, and there is no ``fcntl``. Running the
product natively on Windows would therefore mean disabling the checks that
protect local patient-like data, which is the opposite of the product's
contract. It is refused rather than silently weakened.

Supported ways to run on a Windows laptop, both of which keep every POSIX gate
intact because the product runs on Linux inside them:

* Docker Desktop, using the image and compose file in this repository;
* WSL2 with a Linux distribution, using the normal installer.
"""
from __future__ import annotations

import os
import platform
from typing import Any

POSIX = os.name == "posix"
CONTAINER_GUIDANCE = (
    "Run LivemoreBio in Docker Desktop (docker compose up) or in WSL2. Both keep the "
    "owner-only file protections that the product relies on for PHI-like local state."
)


def support() -> dict[str, Any]:
    return {
        "schema": "livemore.platform-support.v1",
        "system": platform.system(),
        "release": platform.release(),
        "python": platform.python_version(),
        "posix": POSIX,
        "supported_natively": POSIX,
        "reason": None if POSIX else (
            "Native Windows cannot express the owner-only file guarantees this product "
            "enforces for local PHI-like state (st_uid, 0700/0600 modes, fcntl locks)."),
        "guidance": None if POSIX else CONTAINER_GUIDANCE,
    }


class UnsupportedPlatformError(RuntimeError):
    """Raised when an operation needs POSIX file semantics that are unavailable."""


def require_posix(operation: str) -> None:
    if not POSIX:
        raise UnsupportedPlatformError(
            f"{operation} requires POSIX file protections. {CONTAINER_GUIDANCE}")
