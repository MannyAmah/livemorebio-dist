"""livemorebio.events — the versioned cross-system event vocabulary.

Every event published on the bus carries a versioned name
(``<pillar>.<subject>.<action>.v<N>`` per blueprint §16) so downstream
consumers — consoles, the SDK, pharma clients — can rely on a stable
contract. Renaming or changing an event's payload shape requires a new
version constant; existing versions are never repurposed.
"""
from __future__ import annotations

# Aegle — twin runtime
TWIN_UPDATED = "aegle.twin.updated.v1"          # payload: profile + engine params (Si/Gb/γ/Ib/Gt/SG/weight)
EXPERIMENT_RUN = "aegle.experiment.run.v1"      # payload: experiment id + decision summary
WORKSPACE_ACTION = "aegle.workspace.action.v1"   # payload: action id, kind, status, subject binding

# Cendos — in-silico assays
ASSAY_RUN = "cendos.assay.run.v1"               # payload: drug, subject, decision, delta_mean, delta_iAUC
CENDOS_MEASUREMENT_QUALIFIED = "cendos.measurement.qualified.v2"
CENDOS_QUALIFICATION_ASSESSED = "cendos.qualification.assessed.v1"

# LIFE — population / patch
PATCH_SAMPLE = "life.patch.sample.v1"           # payload: channel readings with provenance flags
PATCH_TELEMETRY_ADMITTED = "life.patch.telemetry-admitted.v2"
PATCH_COMMAND_ISSUED = "life.patch.command-issued.v2"

#: All published event names, for validation and documentation.
ALL = (TWIN_UPDATED, EXPERIMENT_RUN, WORKSPACE_ACTION, ASSAY_RUN, CENDOS_MEASUREMENT_QUALIFIED,
       CENDOS_QUALIFICATION_ASSESSED, PATCH_SAMPLE,
       PATCH_TELEMETRY_ADMITTED, PATCH_COMMAND_ISSUED)


def is_versioned(name: str) -> bool:
    """True if *name* follows the ``pillar.subject.action.vN`` convention."""
    parts = name.split(".")
    return len(parts) >= 3 and parts[-1].startswith("v") and parts[-1][1:].isdigit()
