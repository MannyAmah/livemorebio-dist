"""Public, PHI-free identity of source captured when this process starts.

This is source identity, not model qualification or a dependency attestation.
An edited checkout must be restarted before its cached identity changes.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import os
from pathlib import Path
import re
import subprocess
from uuid import uuid4

from . import __version__

_PACKAGE = Path(__file__).resolve().parent
_EXCLUDED = {"tests", "__pycache__", ".venv", "cache", "caches", ".cache"}
_ASSET_ROOTS = (
    ("aegle", "console"), ("anatomy", "ontology"), ("anatomy", "atlas"),
    ("discovery", "data"), ("life_system", "seed"),
    ("life_system", "reference", "seed"), ("scientific_sources", "data"),
)
_ASSET_SUFFIXES = {".js", ".css", ".html", ".json", ".csv", ".ts", ".cif"}


def source_fingerprint(package: Path) -> str | None:
    """Hash only packaged runtime code/reference assets, never mutable data stores."""
    digest = hashlib.sha256()
    count = 0
    try:
        for path in sorted(package.rglob("*")):
            relative = path.relative_to(package)
            if any(part in _EXCLUDED or part.startswith(".") for part in relative.parts):
                continue
            # rglob does not descend directory symlinks. Reject them before suffix
            # filtering so a linked executable subtree cannot disappear from identity.
            if path.is_symlink() and path.is_dir():
                return None
            asset = any(relative.parts[:len(root)] == root for root in _ASSET_ROOTS)
            if path.suffix != ".py" and not (asset and path.suffix in _ASSET_SUFFIXES):
                continue
            if path.is_symlink():
                return None
            if not path.is_file():
                continue
            # Length-delimited names and fixed-width content digests avoid ambiguous joins.
            name = relative.as_posix().encode("utf-8")
            content = hashlib.sha256()
            with path.open("rb") as stream:
                while block := stream.read(1024 * 1024):
                    content.update(block)
            digest.update(len(name).to_bytes(8, "big"))
            digest.update(name)
            digest.update(content.digest())
            count += 1
    except OSError:
        return None
    return digest.hexdigest() if count else None


def _commit(package: Path) -> str | None:
    root = package.parent
    # Wheels inside an unrelated Git checkout must not inherit that checkout's identity.
    if not (root / ".git").exists():
        return None
    env = {key: value for key, value in os.environ.items() if not key.startswith("GIT_")}
    try:
        options = dict(capture_output=True, text=True, timeout=2, check=True, env=env)
        top = subprocess.run(["git", "-C", str(root), "rev-parse", "--show-toplevel"], **options)
        if Path(top.stdout.strip()).resolve() != root.resolve():
            return None
        result = subprocess.run(["git", "-C", str(root), "rev-parse", "--verify", "HEAD"], **options)
        value = result.stdout.strip()
        return value if re.fullmatch(r"[0-9a-f]{40}", value) else None
    except (OSError, subprocess.SubprocessError, UnicodeError):
        return None


def capture_build(package: Path = _PACKAGE) -> dict[str, str | None]:
    """Capture explicitly; live service callers use the immutable startup copy below."""
    return {
        "schema": "livemore.build-identity.v1",
        "package_version": __version__,
        "source_kind": "checkout" if (package.parent / ".git").exists() else "installed_package",
        "commit": _commit(package),
        "source_sha256": source_fingerprint(package),
        "identity_scope": "startup_source",
        "started_at": datetime.now(timezone.utc).isoformat(),
        "process_instance": str(uuid4()),
    }


_STARTUP_IDENTITY = capture_build()


def build_identity() -> dict[str, str | None]:
    """Return a detached copy so a response consumer cannot rewrite startup identity."""
    return dict(_STARTUP_IDENTITY)


def public_service_health(payload: object, expected_service: str) -> dict:
    """Allowlist remote operational metadata; never relay arbitrary health data."""
    if not isinstance(payload, dict) or payload.get("service") != expected_service or payload.get("ok") is not True:
        return {"up": False, "reason": "invalid_service_health"}
    port = payload.get("port")
    result = {"up": True, "service": expected_service, "ok": True,
              "port": port if type(port) is int and 0 < port < 65536 else None}
    raw = payload.get("build")
    if not isinstance(raw, dict):
        result["build"] = None
        return result
    patterns = {
        "schema": r"livemore\.build-identity\.v1",
        "identity_scope": r"startup_source",
        "source_kind": r"checkout|installed_package",
        "commit": r"[0-9a-f]{40}",
        "source_sha256": r"[0-9a-f]{64}",
        "package_version": r"[0-9][0-9A-Za-z.+-]{0,63}",
        "process_instance": r"[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}",
        "started_at": r"[0-9]{4}(-[0-9]{2}){2}T[0-9]{2}(:[0-9]{2}){2}(\.[0-9]{1,6})?\+00:00",
    }
    result["build"] = {
        key: value if isinstance(value := raw.get(key), str) and re.fullmatch(pattern, value) else None
        for key, pattern in patterns.items()
    }
    return result
