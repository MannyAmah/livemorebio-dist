"""Pinned local execution transport and the explicit numerical probe operator.

No global bus, display arrays, physical-sensor transfer function or caller scalar
is used. The pure projection checks integrity; only the authenticated, build-bound
source client establishes where the frame came from. Neither is physical evidence.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime
import hashlib
import http.client
import logging
import ipaddress
from pathlib import Path
import re
import threading
from typing import Any, Callable
from urllib.parse import urlsplit

from ..aegle.execution_contract import ExecutionError, METABOLIC, digest, encoded, number
from ..aegle.execution_store import control_precondition
from ..strict_json import MAX_JSON_BYTES, parse_json_object
from .protocol import HARDWARE_TARGET
from .protocol_v3 import ManifestV3, TelemetryEnvelopeV3, _utc, _iso

_LOG = logging.getLogger("livemorebio.life.source")

OPERATOR_ID = "metabolic-plasma-glucose-identity-v1"
_HASH = r"[0-9a-f]{64}"
_ID = r"[0-9a-f]{32}"
_PROCESS = r"[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}"
# Identity belongs to this loaded implementation, never a later checkout edit.
# Product admission also checks its process startup/current package fingerprint.
_LOADED_OPERATOR_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def _match(value: Any, pattern: str) -> str:
    if type(value) is not str or re.fullmatch(pattern, value) is None:
        raise ExecutionError()
    return value


class ExecutionSourceClient:
    """Fixed trusted configuration, literal loopback only, no redirects/proxies.

    Transport injection is for isolated conformance tests, not public API input.
    Each response must repeat the expected source and original process identity.
    """
    def __init__(self, base_url: str, token: str, source_sha256: str, *,
                 transport: Callable | None = None) -> None:
        try:
            url = urlsplit(base_url)
            if (url.scheme not in {"http", "https"} or not ipaddress.ip_address(url.hostname).is_loopback
                    or url.username or url.password or url.path not in {"", "/"} or url.query or url.fragment):
                raise ValueError()
            self._host, self._port, self._secure = url.hostname, url.port, url.scheme == "https"
        except (ValueError, TypeError):
            raise ExecutionError() from None
        if type(token) is not str or not 8 <= len(token) <= 4096 or any(ord(char) < 32 or ord(char) > 126 for char in token):
            raise ExecutionError()
        self._token = token
        self.source_sha256 = _match(source_sha256, _HASH)
        self.process_instance: str | None = None
        self._transport = transport or self._http
        self._lock = threading.RLock()

    def _http(self, method: str, path: str, body: bytes | None) -> tuple[int, dict[str, str], bytes]:
        connection_type = http.client.HTTPSConnection if self._secure else http.client.HTTPConnection
        connection = connection_type(self._host, self._port, timeout=3.)
        try:
            connection.request(method, path, body=body, headers={"Authorization": "Bearer " + self._token,
                "Accept": "application/json", "Content-Type": "application/json", "Accept-Encoding": "identity"})
            response = connection.getresponse()
            # HTTPConnection neither consults proxy environment nor follows redirects.
            headers = {}
            for key, value in response.getheaders():
                key = key.lower()
                if key in headers:
                    raise ExecutionError("EXECUTION_UNAVAILABLE")
                headers[key] = value
            return response.status, headers, response.read(MAX_JSON_BYTES + 1)
        finally:
            connection.close()

    def _request(self, method: str, path: str, body: dict | None = None) -> dict[str, Any]:
        return self.request_response(method, path, body)[1]

    # Codes the source may forward verbatim. A refusal the operator can act on is
    # worth more than a generic one, but only fixed strings from this closed set
    # cross the boundary: never a message, a body or any other response content.
    _FORWARDED_CODES = frozenset({"PATCH_BINDING_REQUIRED", "MODEL_BINDING_REQUIRED",
                                  "MODEL_SOURCE_CHANGED", "EXECUTION_CONFLICT", "EXECUTION_QUOTA"})

    def _forwarded_code(self, headers: dict[str, str], raw: object) -> str:
        """Recover the peer's typed refusal, defaulting to EXECUTION_UNAVAILABLE."""
        if (self.source_sha256 != headers.get("x-livemore-source-sha256")
                or type(raw) is not bytes or len(raw) > MAX_JSON_BYTES):
            return "EXECUTION_UNAVAILABLE"
        try:
            code = parse_json_object(raw).get("code")
        except Exception:
            return "EXECUTION_UNAVAILABLE"
        return code if code in self._FORWARDED_CODES else "EXECUTION_UNAVAILABLE"

    def request_response(self, method: str, path: str, body: dict | None = None, *,
                         accepted_statuses: tuple[int, ...] = (200,)) -> tuple[int, dict[str, Any]]:
        """Internal fixed-route proxy seam; status permission is never user input."""
        if (type(accepted_statuses) is not tuple or not 1 <= len(accepted_statuses) <= 8
                or any(type(status) is not int or not 100 <= status <= 599 for status in accepted_statuses)
                or len(set(accepted_statuses)) != len(accepted_statuses)):
            raise ExecutionError()
        try:
            status, raw_headers, raw = self._transport(method, path, None if body is None else encoded(body, 16384))
            headers = {key.lower(): value for key, value in raw_headers.items()}
            if (status not in accepted_statuses or headers.get("x-livemore-source-sha256") != self.source_sha256
                    or headers.get("content-encoding", "identity") != "identity"
                    or type(raw) is not bytes or len(raw) > MAX_JSON_BYTES):
                # The caller only sees EXECUTION_UNAVAILABLE. Record which fixed
                # route was refused and why: route and status only, no payload.
                _LOG.error("source route %s %s refused: status=%r accepted=%r build_match=%r encoding=%r",
                           method, path, status, accepted_statuses,
                           headers.get("x-livemore-source-sha256") == self.source_sha256,
                           headers.get("content-encoding", "identity"))
                raise ExecutionError(self._forwarded_code(headers, raw))
            process = _match(headers.get("x-livemore-process-instance"), _PROCESS)
            result = parse_json_object(raw)
            encoded(result, MAX_JSON_BYTES)
            with self._lock:
                if self.process_instance not in {None, process}:
                    raise ExecutionError("EXECUTION_RESTART_REQUIRED")
                self.process_instance = process
            return status, result
        except ExecutionError:
            raise
        except Exception:
            raise ExecutionError("EXECUTION_UNAVAILABLE") from None

    def status(self, execution_id: str) -> dict[str, Any]:
        return self._request("GET", "/api/executions/" + _match(execution_id, _ID))

    def fetch(self, execution_id: str, *, after_frame: int, limit: int = 1) -> dict[str, Any]:
        if type(after_frame) is not int or not 0 <= after_frame <= 1_000_000_000 or type(limit) is not int or limit != 1:
            raise ExecutionError()
        return self._request("GET", f"/api/executions/{_match(execution_id, _ID)}/frames?after_frame={after_frame}&limit=1")

    def pause(self, execution_id: str, *, expected_revision: int | None = None,
              expected_control_revision: int | None = None, expected_source_generation: str) -> dict[str, Any]:
        field, revision = control_precondition(expected_revision=expected_revision,
                                               expected_control_revision=expected_control_revision)
        return self._request("POST", f"/api/executions/{_match(execution_id, _ID)}/pause", {
            "expected_" + field: revision, "expected_source_generation": expected_source_generation})

    def bind_consumer(self, execution_id: str, session_id: str, source_snapshot_hash: str, *,
                      expected_revision: int, expected_source_generation: str) -> dict[str, Any]:
        return self._request("POST", f"/api/executions/{_match(execution_id, _ID)}/consumer", {
            "session_id": _match(session_id, _ID), "source_snapshot_hash": _match(source_snapshot_hash, _HASH),
            "expected_revision": expected_revision, "expected_source_generation": expected_source_generation})

    def renew_consumer(self, execution_id: str, session_id: str, source_snapshot_hash: str, *,
                       expected_source_generation: str) -> dict[str, Any]:
        return self._request("POST", f"/api/executions/{_match(execution_id, _ID)}/consumer/renew", {
            "session_id": _match(session_id, _ID), "source_snapshot_hash": _match(source_snapshot_hash, _HASH),
            "expected_source_generation": expected_source_generation})

    def deliver_observation(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._request("POST", "/api/execution-observations", payload)


def numerical_probe_manifest(device_id: str) -> ManifestV3:
    return ManifestV3({"schema_version": "livemore.life-patch.manifest.v3", "protocol_version": "3.0",
        "device_id": device_id, "mode": "virtual", "hardware_revision": HARDWARE_TARGET,
        "configuration_id": "metabolic-numerical-probe-v1", "firmware_version": "virtual-execution-v1",
        "firmware_hash": _LOADED_OPERATOR_SHA256, "hardware_present": False,
        "capabilities": [{"signal": "glucose_mgdl", "unit": "mg/dL", "channel": "chem",
                          "provenance": "modeled", "cartridge_id": None}], "safe_commands": []})


def validate_frame(frame: dict[str, Any], execution: dict[str, Any]) -> float:
    """Return exact endpoint only after source/clock/quantity integrity checks."""
    try:
        encoded(frame)
        frozen = deepcopy(frame)
        retained_hash = frozen.pop("frame_hash")
        if retained_hash != digest(frozen):
            raise ValueError()
        if (frame["schema"] != "livemore.execution-frame.v1" or frame["authorship"] != "engine"
                or frame["evidence_class"] != "MODELED" or frame["independent_physical_validation"] is not False
                or execution["source_valid"] is not True or frame["engine_contract_id"] != METABOLIC
                or frame["native_unit"] != "min" or frame["numerical_domain_notes"]):
            raise ValueError()
        for field in ("execution_id", "source_snapshot_hash", "source_generation", "selection", "engine_contract_id"):
            if frame[field] != execution[field]:
                raise ValueError()
        if type(frame["frame_index"]) is not int or not 1 <= frame["frame_index"] <= execution["latest_frame"]:
            raise ValueError()
        start, end = number(frame["native_start"], 0, 840), number(frame["native_end"], 0, 840)
        if end <= start:
            raise ValueError()
        matches = [row for row in frame["series"] if row["quantity"] == "glucose_mgdl"]
        if len(matches) != 1:
            raise ValueError()
        trace = matches[0]
        if trace["unit"] != "mg/dL" or trace["compartment"] != "plasma":
            raise ValueError()
        times, values = trace["native_times"], trace["values"]
        if not 1 <= len(times) == len(values) <= 4096 or times[-1] != end:
            raise ValueError()
        previous = start
        for instant, value in zip(times, values):
            if number(instant, start, end) <= previous or number(value, 0, 1e12) <= 0:
                raise ValueError()
            previous = instant
        return values[-1]
    except Exception:
        raise ExecutionError("EXECUTION_CONFLICT") from None


def project_frame(frame: dict[str, Any], execution: dict[str, Any], manifest: ManifestV3, *,
                  session_id: str, sequence: int, captured_at: datetime, monotonic_s: float) -> TelemetryEnvelopeV3:
    glucose = validate_frame(frame, execution)
    _match(session_id, _ID)
    captured_at = _utc(captured_at, "captured_at")
    age = (captured_at - _utc(frame["generated_at"], "generated_at")).total_seconds()
    # This operator is explicitly same-host, with the original producer process
    # pinned by the source client. UTC rollback must not renew an old frame's age.
    monotonic_s = number(monotonic_s, 0, 1e12)
    monotonic_age = monotonic_s - number(frame["generated_monotonic_s"], 0, 1e12)
    if not 0 <= age <= 30 or not 0 <= monotonic_age <= 30:
        raise ExecutionError("EXECUTION_CONFLICT")
    if manifest.to_dict() != numerical_probe_manifest(manifest.device_id).to_dict():
        raise ExecutionError("EXECUTION_CONFLICT")
    instant = _iso(captured_at)
    return TelemetryEnvelopeV3({"schema_version": "livemore.life-patch.telemetry.v3", "protocol_version": "3.0",
        "envelope_id": f"virtual-{session_id}-{frame['frame_index']}", "device_id": manifest.device_id,
        "subject_id": execution["selection"]["subject_id"], "subject_pseudonymized": True,
        "sequence": sequence, "mode": "virtual", "manifest_hash": manifest.capability_hash,
        "firmware_hash": manifest.to_dict()["firmware_hash"], "captured_at": instant,
        "acquisition_start": instant, "acquisition_end": instant,
        "clock": {"session_id": session_id, "monotonic_start_s": monotonic_s,
                  "monotonic_end_s": monotonic_s, "utc_uncertainty_s": .01},
        "measurements": [{"measurement_id": f"glucose-{frame['frame_index']}", "signal": "glucose_mgdl",
            "unit": "mg/dL", "provenance": "modeled", "kind": "scalar", "value": glucose,
            "quality_status": "pass", "calibration_status": "not_applicable", "quality_flags": [],
            "context": {"endpoint": "glucose_mgdl", "biofluid": "plasma", "site": None, "compartment": "plasma",
                "assay_id": None, "cartridge_id": None, "calibration_id": None, "derivation_id": OPERATOR_ID},
            "model_context": {"prediction_id": f"execution-{frame['execution_id']}-frame-{frame['frame_index']}",
                "condition_id": execution["selection"]["condition_id"], "model_time_min": frame["native_end"],
                "model_id": METABOLIC, "mapping_id": OPERATOR_ID}}]})
