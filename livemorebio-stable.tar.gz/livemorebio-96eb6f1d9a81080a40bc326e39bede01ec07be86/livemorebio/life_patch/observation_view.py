"""Read-only source and freshness presentation; never a connection detector."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Mapping


RECENT_WITHIN_SECONDS = 60
_DISPLAY = {
    "glucose_mgdl": ("glucose", 70, 180), "hr_bpm": ("heart rate", 50, 110),
    "hrv_ms": ("HRV", 5, 80), "skin_temp_c": ("skin temperature", 30, 37),
    "spo2_pct": ("SpO₂", 90, 100), "lactate_mM": ("lactate", 0, 10),
    "sodium_mM": ("sodium", 20, 160), "potassium_mM": ("potassium", 1, 20),
}


def _utc(value: object) -> datetime | None:
    # Legacy relative numeric clocks are not UTC timestamps.
    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed.astimezone(timezone.utc) if parsed.tzinfo else None
    except ValueError:
        return None


def observation_channel(signal: str, item: Mapping[str, Any], *, now: datetime | None = None) -> dict[str, Any]:
    """Describe a last admitted sample without implying an active physical link.

    The 60-second policy is a UI recency threshold, not an assay-specific validity
    period or physiological time mapping. Physical QC/transfer gates are separate.
    """
    now = now or datetime.now(timezone.utc)
    name, lo, hi = _DISPLAY.get(signal, (signal, 0, 1))
    mode = item.get("mode")
    provenance = item.get("provenance")
    fixture = provenance == "technical_fixture" or item.get("source_data_class") == "technical_fixture"
    data_class = "inferred" if provenance == "inferred" else "technical_fixture" if fixture else (
        "virtual" if mode == "virtual" else "observed" if mode in {"physical", "external"} else "unknown"
    )
    prefix = {"virtual": "Virtual", "observed": "Observed", "unknown": "Unclassified",
              "technical_fixture": "Technical fixture", "inferred": "Inferred"}[data_class]
    captured = _utc(item.get("acquisition_end") or item.get("captured_at"))
    received = _utc(item.get("received_at"))
    age = (now - captured).total_seconds() if captured else None
    if data_class in {"virtual", "technical_fixture", "inferred"}:
        status = "recorded"
    elif captured is None or received is None:
        status = "timing_unknown"
    elif captured > received or received > now or age is not None and age < 0:
        status = "clock_uncertain"
    else:
        status = "recent" if age is not None and age <= RECENT_WITHIN_SECONDS else "stale"
    if item.get("quality_status") in {"reject", "fail"} or item.get("calibration_status") in {"failed", "fail"}:
        status = "quality_failed"
    clock = item.get("clock") or {}
    if not isinstance(clock, dict):
        clock = {}
    value = item.get("value") if item.get("kind", "scalar") == "scalar" else None
    return {
        "id": "observed_" + signal, "label": f"{prefix} {name}", "unit": item.get("unit", ""),
        "status": status, "data_class": data_class,
        "provenance": f"{mode or 'unknown'} · {provenance or 'lineage unavailable'} · "
                      f"quality {item.get('quality_status', 'not_assessed')} · "
                      f"calibration {item.get('calibration_status', 'not_assessed')}",
        "flat": value, "lo": lo, "hi": hi, "current": value,
        "captured_at": item.get("captured_at"), "received_at": item.get("received_at"),
        "age_seconds": age, "clock_uncertainty_seconds": clock.get("utc_uncertainty_s"),
        "envelope_id": item.get("envelope_id"), "source_hash": item.get("source_hash") or item.get("envelope_hash"),
        "measurement_id": item.get("measurement_id"), "context": item.get("context"),
        "model_context": item.get("model_context"), "connection_verified": False,
        "freshness_policy": {"recent_within_seconds": RECENT_WITHIN_SECONDS,
                             "scope": "display_recency_only_not_assay_validity"},
    }
