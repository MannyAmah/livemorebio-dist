"""Map admitted patch telemetry into evidence inputs.

These envelopes are baseline/model inputs.  They cannot become validation
outcomes merely because they came from a physical instrument.
"""
from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from ..evidence import (
    AssessmentStatus,
    CounterpartMeasurement,
    MeasurementEnvelope,
    MeasurementRole,
    SourceDataClass,
)
from ..evidence.errors import DomainValidationError
from .protocol import (
    CalibrationStatus,
    DeviceMode,
    QualityStatus,
    TelemetryEnvelope,
)
from .protocol_v3 import TelemetryEnvelopeV3, normalize_observations


def _quality(value: QualityStatus) -> AssessmentStatus:
    return {
        QualityStatus.PASS: AssessmentStatus.PASS,
        QualityStatus.DEGRADED: AssessmentStatus.PARTIAL,
        QualityStatus.REJECT: AssessmentStatus.FAIL,
    }[value]


def _calibration(value: CalibrationStatus) -> AssessmentStatus:
    return {
        CalibrationStatus.CURRENT: AssessmentStatus.PASS,
        CalibrationStatus.DUE: AssessmentStatus.PARTIAL,
        CalibrationStatus.FAILED: AssessmentStatus.FAIL,
        CalibrationStatus.NOT_APPLICABLE: AssessmentStatus.NOT_ASSESSED,
    }[value]


def to_evidence_measurements(
    envelope: TelemetryEnvelope | TelemetryEnvelopeV3,
    *,
    tenant_id: str,
    received_at: datetime,
    consent_scope: tuple[str, ...] = (),
    chain_of_custody: tuple[str, ...] = (),
) -> tuple[MeasurementEnvelope, ...]:
    source_class = (
        SourceDataClass.SYNTHETIC
        if envelope.mode is DeviceMode.VIRTUAL
        else SourceDataClass.REAL_HUMAN
    )
    if source_class is SourceDataClass.REAL_HUMAN and not consent_scope:
        raise DomainValidationError("real-human patch evidence requires explicit consent scope")
    if source_class is SourceDataClass.REAL_HUMAN and not chain_of_custody:
        raise DomainValidationError("real-human patch evidence requires explicit chain of custody")
    if isinstance(envelope, TelemetryEnvelopeV3):
        return _v3_evidence_measurements(
            envelope, tenant_id=tenant_id, received_at=received_at,
            consent_scope=consent_scope, chain_of_custody=chain_of_custody,
            source_class=source_class,
        )
    measurements = []
    for index, item in enumerate(envelope.measurements):
        payload = CounterpartMeasurement(
            endpoint=item.signal,
            value=Decimal(str(item.value)),
            unit=item.unit,
            source_data_class=source_class,
            measured_at=envelope.captured_at,
            quality_status=_quality(item.quality_status),
            calibration_status=_calibration(item.calibration_status),
            consent_scope=consent_scope,
            device_id=envelope.device_id,
            instrument_id=envelope.device_id,
            method=f"LIFE Patch protocol {envelope.protocol_version} {envelope.mode.value} telemetry",
            chain_of_custody=chain_of_custody,
        )
        measurements.append(MeasurementEnvelope(
            schema_version="livemore.measurement-envelope.v1",
            envelope_id=f"{envelope.envelope_id}-{index}",
            tenant_id=tenant_id,
            counterpart_id=envelope.subject_id,
            role=MeasurementRole.BASELINE_INPUT,
            subject_pseudonymized=True,
            sequence=envelope.sequence * 1000 + index,
            received_at=received_at,
            payload=payload,
        ))
    return tuple(measurements)


def _v3_evidence_measurements(
    envelope: TelemetryEnvelopeV3, *, tenant_id: str, received_at: datetime,
    consent_scope: tuple[str, ...], chain_of_custody: tuple[str, ...],
    source_class: SourceDataClass,
) -> tuple[MeasurementEnvelope, ...]:
    """Keep waveform/raw inputs linked to their source, not scalar counterparts."""
    quality = {"pass": AssessmentStatus.PASS, "degraded": AssessmentStatus.PARTIAL,
               "unknown": AssessmentStatus.NOT_ASSESSED}
    calibration = {"current": AssessmentStatus.PASS, "due": AssessmentStatus.PARTIAL,
                   "not_applicable": AssessmentStatus.NOT_ASSESSED,
                   "unknown": AssessmentStatus.NOT_ASSESSED}
    measurements = []
    for index, row in enumerate(normalize_observations(envelope, received_at=received_at).values()):
        if row["kind"] != "scalar" or row["provenance"] in {"raw", "inferred"}:
            continue
        # The opaque source binding is part of the evidence hash and resolves the
        # full immutable packet, including timing, algorithm and calibration IDs.
        source_binding = f"{envelope.envelope_hash}:{row['measurement_id']}"
        payload = CounterpartMeasurement(
            endpoint=row["signal"], value=Decimal(str(row["value"])), unit=row["unit"],
            source_data_class=source_class, measured_at=envelope.captured_at,
            quality_status=quality[row["quality_status"]],
            calibration_status=calibration[row["calibration_status"]],
            consent_scope=consent_scope, device_id=envelope.device_id,
            instrument_id=envelope.device_id,
            method=f"LIFE Patch v3 {row['provenance']} source {source_binding}",
            chain_of_custody=chain_of_custody,
        )
        measurements.append(MeasurementEnvelope(
            schema_version="livemore.measurement-envelope.v1",
            envelope_id=f"{envelope.envelope_id}-{index}", tenant_id=tenant_id,
            counterpart_id=envelope.subject_id, role=MeasurementRole.BASELINE_INPUT,
            subject_pseudonymized=True, sequence=envelope.sequence * 1000 + index,
            received_at=received_at, payload=payload,
        ))
    return tuple(measurements)
