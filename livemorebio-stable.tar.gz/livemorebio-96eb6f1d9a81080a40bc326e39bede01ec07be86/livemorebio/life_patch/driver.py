"""
livemorebio.life_patch.driver — ingested measurements -> twin parameters.

Parameter adjustment is POPULATION-anchored and individualised, NOT a validated
person calibration or per-person prediction:
measured fasting glucose sets basal glucose; mean glycemia scales insulin
sensitivity and basal insulin off the healthy reference; measured HR sets the
cardiac pacing cycle length. Honest by construction.
"""
from __future__ import annotations
from dataclasses import replace
from typing import List
from ..engines.metabolic.glucose_insulin import MetabolicProfile, HEALTHY


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


def calibrate_metabolic(template: MetabolicProfile, glucose_mgdl: List[float]) -> MetabolicProfile:
    fasting = min(glucose_mgdl)
    mean = sum(glucose_mgdl) / len(glucose_mgdl)
    Gb = _clamp(fasting, 70.0, 200.0)
    si_frac = _clamp(1.0 - (mean - 100.0) / 180.0, 0.30, 1.20)   # ↑ glycemia → ↓ Si
    Si = HEALTHY.Si * si_frac
    Ib = _clamp(HEALTHY.Ib * (1.0 + (mean - 100.0) / 150.0), 6.0, 25.0)
    Gt = _clamp(100.0 + (Gb - 90.0) * 0.5, 100.0, 130.0)
    return replace(template, name=template.name + " · measured-input adjusted",
                   Gb=Gb, Si=Si, Ib=Ib, Gt=Gt)


def hr_to_cl_ms(hr_bpm: float) -> float:
    return 60000.0 / _clamp(hr_bpm, 35.0, 200.0)
