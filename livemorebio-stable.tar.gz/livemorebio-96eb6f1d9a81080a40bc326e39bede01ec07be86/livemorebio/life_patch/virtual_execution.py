"""Explicit LIFE consumer lifecycle over immutable engine frames and exact outbox.

Native execution, admission and HTTP acknowledgment are separate operations. A
failure preserves the pending wire object, disables renewal and attempts a pause;
the producer-local lease handles an unreachable pause endpoint. No automatic
recovery, model calibration, source switching or changed-sequence retry occurs.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import logging
import threading
import time
from typing import Any, Callable

from ..aegle.execution_contract import ExecutionError, METABOLIC, encoded, validate_selection
from ..aegle.execution_store import check_control_precondition
from .execution_source import numerical_probe_manifest, project_frame, validate_frame, _match, _ID, _HASH, _PROCESS
from .gateway import LifePatchGateway
from .protocol_v3 import TelemetryEnvelopeV3, _iso, _utc
from .virtual_session_store import VirtualSessionStore

_LOG = logging.getLogger("livemorebio.life.virtual.session")
# Refusals a blocked session may report verbatim; anything else stays generic.
_DELIVERY_CODES = frozenset({"PATCH_BINDING_REQUIRED", "MODEL_BINDING_REQUIRED",
                             "MODEL_SOURCE_CHANGED", "EXECUTION_CONFLICT", "EXECUTION_QUOTA"})

_ACTIVE = {"waiting_for_engine", "streaming"}
_SOURCE_KEYS = ("execution_id", "source_snapshot_hash", "source_generation", "selection", "engine_contract_id")


class VirtualSessionManager:
    def __init__(self, store: VirtualSessionStore, gateway: LifePatchGateway, source_client: Any,
                 on_admitted: Callable[[dict[str, Any]], dict[str, Any]], *, run_background: bool = True,
                 clock: Callable[[], float] = time.monotonic,
                 now: Callable[[], datetime] = lambda: datetime.now(timezone.utc)) -> None:
        self.store, self.gateway, self.source = store, gateway, source_client
        self._on_admitted, self._clock, self._now = on_admitted, clock, now
        self._lock = threading.RLock()
        self._owners: dict[str, int] = {}
        self._busy: set[str] = set()
        self._renew_due: dict[str, float] = {}
        self._closed = False
        self._wake = threading.Event()
        self._thread = None
        if run_background:
            self._thread = threading.Thread(target=self._run, name="life-virtual-consumer", daemon=True)
            self._thread.start()

    def _open(self) -> None:
        if self._closed:
            raise ExecutionError("EXECUTION_CLOSED")

    def _save(self, record: dict[str, Any], changes: dict[str, Any], *, control_event: bool = False) -> dict[str, Any]:
        return self.store.update(record["session_id"], expected_revision=record["revision"], changes=changes,
                                 control_event=control_event)

    def _current(self, record: dict[str, Any]) -> dict[str, Any]:
        """Caller holds lock; controls and shutdown fence work across I/O gaps."""
        self._open()
        current = self.store.get(record["session_id"])
        if record["session_id"] not in self._owners or current["revision"] != record["revision"]:
            raise ExecutionError("EXECUTION_CONFLICT")
        return current

    def _verify(self, record: dict[str, Any], execution: dict[str, Any]) -> None:
        try:
            encoded(execution, 16384)
            if (execution["source_valid"] is not True or execution["engine_contract_id"] != METABOLIC
                    or execution["native_axis"]["unit"] != "min"
                    or self.source.process_instance != record["binding"]["peer_process"]):
                raise ValueError()
            for key in _SOURCE_KEYS:
                if record["binding"][key] != execution[key]:
                    raise ValueError()
            if type(execution["revision"]) is not int or type(execution["latest_frame"]) is not int or execution["latest_frame"] < record["last_frame"]:
                raise ValueError()
            if record["lease_bound"]:
                lease = execution["consumer_lease"]
                if (lease["required"] is not True or lease["session_id"] != record["session_id"]
                        or lease["state"] not in {"valid", "expired"}):
                    raise ValueError()
        except Exception:
            raise ExecutionError("EXECUTION_CONFLICT") from None

    def _public(self, record: dict[str, Any]) -> dict[str, Any]:
        result = {key: deepcopy(value) for key, value in record.items() if key not in {"request_hash", "pending", "receipt"}}
        result.update(has_pending=record["pending"] is not None,
            pending_envelope_hash=(record["pending"]["envelope"]["envelope_hash"] if record["pending"] else None),
            evidence_class="MODELED" if record["authorship"] == "engine" else "NOT_EXECUTED",
            hardware_present=False, independent_physical_validation=False,
            delivery_status=("pending" if record["pending"] is not None and record["state"] in _ACTIVE else
                             "blocked" if record["pending"] is not None else
                             "acknowledged" if record["last_forwarded"] else "not_delivered"))
        return result

    def start(self, execution_id: str, source_snapshot_hash: str, device_id: str, *,
              expected_selection: dict[str, Any], idempotency_key: str) -> dict[str, Any]:
        self._open()
        _match(execution_id, _ID)
        _match(source_snapshot_hash, _HASH)
        expected_selection = validate_selection(expected_selection)
        execution = self.source.status(execution_id)
        manifest = self.gateway.manifest(device_id)
        if (manifest is None or manifest.to_dict() != numerical_probe_manifest(device_id).to_dict()
                or execution["selection"] != expected_selection or execution["source_snapshot_hash"] != source_snapshot_hash):
            raise ExecutionError("EXECUTION_CONFLICT")
        binding = {key: deepcopy(execution[key]) for key in _SOURCE_KEYS} | {
            "device_id": device_id, "manifest_hash": manifest.capability_hash,
            "peer_process": _match(self.source.process_instance, _PROCESS)}
        record = self.store.create(binding, idempotency_key=idempotency_key)
        with self._lock:
            self._open()
            if record["session_id"] in self._owners:
                return self._public(record)
            if record["state"] not in _ACTIVE or record["lease_bound"]:
                raise ExecutionError("EXECUTION_CONFLICT")
            self._owners[record["session_id"]] = self.store.acquire_owner(record["session_id"])
            self._busy.add(record["session_id"])
        try:
            self._verify(record, execution)
            if execution["state"] not in {"prepared", "paused"}:
                raise ExecutionError("EXECUTION_CONFLICT")
            # Existing history is an explicit cursor anchor, not new acquisition.
            anchor = None
            if execution["latest_frame"]:
                page = self.source.fetch(execution_id, after_frame=execution["latest_frame"] - 1)
                self._verify(record, page["execution"])
                if len(page["frames"]) != 1 or page["frames"][0]["frame_index"] != execution["latest_frame"]:
                    raise ExecutionError("EXECUTION_CONFLICT")
                validate_frame(page["frames"][0], page["execution"])
                anchor = page["frames"][0]["frame_hash"]
            with self._lock:
                self._current(record)
                record = self._save(record, {"last_frame": execution["latest_frame"], "last_frame_hash": anchor})
            execution = self.source.bind_consumer(execution_id, record["session_id"], source_snapshot_hash,
                expected_revision=execution["revision"], expected_source_generation=binding["source_generation"])
            with self._lock:
                self._current(record)
                record = self._save(record, {"lease_bound": True, "producer": execution})
                self._verify(record, execution)
                self._renew_due[record["session_id"]] = self._clock() + 5.
                return self._public(record)
        except Exception as error:
            self._block(record["session_id"], error, expected_control_revision=record["control_revision"])
            raise ExecutionError("EXECUTION_UNAVAILABLE") from None
        finally:
            with self._lock:
                self._busy.discard(record["session_id"])

    def _pause_producer(self, record: dict[str, Any]) -> None:
        try:
            with self._lock:
                if self.store.get(record["session_id"])["control_revision"] != record["control_revision"]:
                    return
            execution = self.source.status(record["binding"]["execution_id"])
            self._verify(record, execution)
            with self._lock:
                if self.store.get(record["session_id"])["control_revision"] != record["control_revision"]:
                    return
                if execution["state"] == "running":
                    # Keep local intent serialized through this bounded request.
                    # The fixed-peer Aegle pause path never calls back into LIFE;
                    # releasing here would let a newer resume overtake the pause.
                    # Old peers retain their exact-record guard.
                    guard = ({"expected_control_revision": execution["control_revision"]}
                             if "control_revision" in execution else {"expected_revision": execution["revision"]})
                    self.source.pause(execution["execution_id"], **guard,
                                      expected_source_generation=execution["source_generation"])
        except Exception:
            # Local renewal is already cancelled; producer TTL remains the bound
            # if transport/source mismatch makes this best-effort pause impossible.
            return

    def _block(self, session_id: str, error: Exception, *, expected_control_revision: int) -> None:
        with self._lock:
            record = self.store.get(session_id)
            # A stale exception is not a new failure of the operator's later
            # decision. Do not cancel its renewal or issue a late remote pause.
            if (self._closed or record["control_revision"] != expected_control_revision
                    or record["state"] in {"stopped", "completed", "interrupted"}):
                return
            self._renew_due.pop(session_id, None)
            typed = isinstance(error, ExecutionError)
            if not typed:
                # A session that blocks on an untyped failure reports the generic
                # EXECUTION_UNAVAILABLE and would otherwise discard the cause.
                # The log carries the exception only, never session payload.
                _LOG.exception("virtual session blocked by an untyped failure")
            code = error.code if typed else "EXECUTION_UNAVAILABLE"
            record = self._save(record, {"state": "blocked", "failure_code": code})
        self._pause_producer(record)

    def _renew(self, record: dict[str, Any], *, force: bool = False) -> dict[str, Any]:
        if record["state"] not in _ACTIVE or record["pending"] is not None:
            return record
        if not force and self._clock() < self._renew_due.get(record["session_id"], float("inf")):
            return record
        binding = record["binding"]
        execution = self.source.renew_consumer(binding["execution_id"], record["session_id"], binding["source_snapshot_hash"],
                                             expected_source_generation=binding["source_generation"])
        self._verify(record, execution)
        with self._lock:
            current = self.store.get(record["session_id"])
            if current["revision"] != record["revision"] or current["state"] not in _ACTIVE:
                return current
            self._renew_due[record["session_id"]] = self._clock() + 5.
            return self._save(current, {"producer": execution})

    def _deliver_pending(self, record: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            record = self._current(record)
        pending = record["pending"]
        if pending is None:
            return record
        envelope = TelemetryEnvelopeV3(pending["envelope"])
        receipt = record["receipt"]
        if receipt is None:
            # This is explicit recovery only; ordinary ticks use their direct
            # gateway receipt rather than rescanning growing journal history.
            receipt = self.gateway.resolve_receipt(envelope.envelope_id, envelope.envelope_hash)
            if receipt is None:
                with self._lock:
                    self._current(record)
                    receipt = self.gateway.admit(envelope, received_at=self._now(), require_encrypted=True)
            with self._lock:
                current = self._current(record)
                if current["pending"] != pending:
                    raise ExecutionError("EXECUTION_CONFLICT")
                record = self._save(current, {"receipt": receipt, "last_admitted": pending["frame_index"]})
        if receipt["envelope_hash"] != envelope.envelope_hash or receipt["envelope_id"] != envelope.envelope_id:
            raise ExecutionError("EXECUTION_CONFLICT")
        response = self._on_admitted(deepcopy(receipt))
        if not isinstance(response, dict) or response.get("aegle", {}).get("status") != "delivered":
            # The delivery result already carries the peer's typed refusal. Keep
            # it so the blocked session names a cause the operator can act on
            # instead of a blanket "unavailable".
            reported = response.get("aegle", {}).get("code") if isinstance(response, dict) else None
            raise ExecutionError(reported if reported in _DELIVERY_CODES else "EXECUTION_UNAVAILABLE")
        with self._lock:
            current = self._current(record)
            if current["pending"] != pending:
                raise ExecutionError("EXECUTION_CONFLICT")
            return self._save(current, {"pending": None, "receipt": None,
                "last_frame": pending["frame_index"], "last_frame_hash": pending["frame_hash"],
                "last_admitted": pending["frame_index"], "last_forwarded": pending["frame_index"],
                "last_generated_at": pending["generated_at"], "last_captured_at": envelope.to_dict()["captured_at"],
                "last_acknowledged_at": _iso(self._now()), "native_time": pending["native_end"], "authorship": "engine"})

    def tick(self, session_id: str) -> None:
        with self._lock:
            self._open()
            record = self.store.get(session_id)
            if record["state"] not in _ACTIVE or session_id in self._busy:
                return
            if session_id not in self._owners:
                raise ExecutionError("EXECUTION_OWNED")
            self._busy.add(session_id)
        try:
            page = self.source.fetch(record["binding"]["execution_id"], after_frame=record["last_frame"])
            execution, frames = page["execution"], page["frames"]
            self._verify(record, execution)
            if (type(frames) is not list or len(frames) > 1 or type(page["next_after_frame"]) is not int
                    or page["next_after_frame"] != (frames[-1]["frame_index"] if frames else record["last_frame"])):
                raise ExecutionError("EXECUTION_CONFLICT")
            if execution["state"] not in {"prepared", "initializing", "running", "paused", "completed"}:
                raise ExecutionError("EXECUTION_CONFLICT")
            with self._lock:
                current = self.store.get(session_id)
                if current["revision"] != record["revision"] or current["state"] not in _ACTIVE:
                    return
                if record["pending"] is not None:
                    raise ExecutionError("EXECUTION_CONFLICT")
                if frames:
                    frame = frames[0]
                    if (frame["frame_index"] != record["last_frame"] + 1
                            or frame["previous_frame_hash"] != record["last_frame_hash"]):
                        raise ExecutionError("EXECUTION_CONFLICT")
                    manifest = self.gateway.manifest(record["binding"]["device_id"])
                    if manifest is None or manifest.capability_hash != record["binding"]["manifest_hash"]:
                        raise ExecutionError("EXECUTION_CONFLICT")
                    with self.gateway.transaction():
                        envelope = project_frame(frame, execution, manifest, session_id=session_id,
                            sequence=self.gateway.next_sequence(manifest.device_id), captured_at=self._now(), monotonic_s=self._clock())
                        pending = {"envelope": envelope.to_dict(), "frame_index": frame["frame_index"],
                            "frame_hash": frame["frame_hash"], "generated_at": frame["generated_at"], "native_end": frame["native_end"]}
                        record = self._save(current, {"pending": pending, "producer": execution})
                        receipt = self.gateway.admit(envelope, received_at=self._now(), require_encrypted=True)
                        record = self._save(record, {"receipt": receipt, "last_admitted": frame["frame_index"]})
                elif execution["latest_frame"] != record["last_frame"]:
                    raise ExecutionError("EXECUTION_CONFLICT")
                else:
                    record = self._save(current, {"producer": execution})
            if frames:
                record = self._deliver_pending(record)
            with self._lock:
                current = self.store.get(session_id)
                if current["state"] not in _ACTIVE:
                    return
                completed = execution["state"] == "completed" and current["last_frame"] == execution["latest_frame"]
                record = self._save(current, {"state": "completed" if completed else
                    "streaming" if execution["state"] == "running" and current["last_forwarded"] else "waiting_for_engine",
                    "failure_code": None})
            if completed:
                self._release(session_id)
            else:
                self._renew(record)
        except Exception as error:
            self._block(session_id, error, expected_control_revision=record["control_revision"])
        finally:
            with self._lock:
                self._busy.discard(session_id)

    def status(self, session_id: str) -> dict[str, Any]:
        with self._lock:
            self._open()
            record = self.store.get(session_id)
            if session_id not in self._owners and record["state"] not in {"stopped", "completed", "interrupted"}:
                try:
                    owner = self.store.acquire_owner(session_id)
                except ExecutionError as error:
                    if error.code != "EXECUTION_OWNED":
                        raise
                else:
                    try:
                        record = self._save(record, {"state": "interrupted", "failure_code": "EXECUTION_RESTART_REQUIRED"})
                    finally:
                        self.store.release_owner(owner)
            return self._public(record)

    def resume(self, session_id: str, *, expected_revision: int | None = None,
               expected_control_revision: int | None = None) -> dict[str, Any]:
        with self._lock:
            self._open()
            record = self.store.get(session_id)
            check_control_precondition(record, expected_revision=expected_revision,
                                       expected_control_revision=expected_control_revision)
            if record["state"] not in {"paused", "blocked", "interrupted"} or session_id in self._busy:
                raise ExecutionError("EXECUTION_CONFLICT")
            acquired = session_id not in self._owners
            if acquired:
                self._owners[session_id] = self.store.acquire_owner(session_id)
            try:
                # Recovery has been accepted but has not granted consumer
                # permission yet. Give that intent an epoch before any I/O.
                record = self._save(record, {"state": record["state"]}, control_event=True)
            except Exception:
                if acquired:
                    self.store.release_owner(self._owners.pop(session_id))
                raise
            self._busy.add(session_id)
        try:
            execution = self.source.status(record["binding"]["execution_id"])
            self._verify(record, execution)
            with self._lock:
                self._current(record)
            if not record["lease_bound"]:
                if execution.get("consumer_lease", {}).get("session_id") != session_id:
                    execution = self.source.bind_consumer(execution["execution_id"], session_id, record["binding"]["source_snapshot_hash"],
                        expected_revision=execution["revision"], expected_source_generation=record["binding"]["source_generation"])
                record = self._save(record, {"lease_bound": True})
                self._verify(record, execution)
            record = self._deliver_pending(record)
            with self._lock:
                current = self._current(record)
                if current["state"] in {"stopped", "completed"}:
                    raise ExecutionError("EXECUTION_CONFLICT")
                record = self._save(current, {"state": "waiting_for_engine", "failure_code": None, "producer": execution})
            record = self._renew(record, force=True)
            return self._public(record)
        except Exception as error:
            self._block(session_id, error, expected_control_revision=record["control_revision"])
            raise ExecutionError("EXECUTION_UNAVAILABLE") from None
        finally:
            with self._lock:
                self._busy.discard(session_id)

    def _control(self, session_id: str, expected_revision: int | None, state: str, *,
                 expected_control_revision: int | None = None) -> dict[str, Any]:
        with self._lock:
            self._open()
            record = self.store.get(session_id)
            check_control_precondition(record, expected_revision=expected_revision,
                                       expected_control_revision=expected_control_revision)
            if record["state"] in {"stopped", "completed"}:
                raise ExecutionError("EXECUTION_CONFLICT")
            acquired = session_id not in self._owners
            if acquired:
                self._owners[session_id] = self.store.acquire_owner(session_id)
            self._renew_due.pop(session_id, None)
            try:
                record = self._save(record, {"state": state}, control_event=True)
            except Exception:
                if acquired:
                    self.store.release_owner(self._owners.pop(session_id))
                raise
        self._pause_producer(record)
        if state == "stopped":
            self._release(session_id)
        return self._public(record)

    def pause(self, session_id: str, *, expected_revision: int | None = None,
              expected_control_revision: int | None = None) -> dict[str, Any]:
        return self._control(session_id, expected_revision, "paused", expected_control_revision=expected_control_revision)

    def stop(self, session_id: str, *, expected_revision: int | None = None,
             expected_control_revision: int | None = None) -> dict[str, Any]:
        return self._control(session_id, expected_revision, "stopped", expected_control_revision=expected_control_revision)

    def _release(self, session_id: str) -> None:
        with self._lock:
            self._renew_due.pop(session_id, None)
            owner = self._owners.pop(session_id, None)
        if owner is not None:
            self.store.release_owner(owner)

    def _run(self) -> None:
        while not self._wake.wait(.5):
            with self._lock:
                sessions = list(self._owners)
            for session_id in sessions:
                try:
                    self.tick(session_id)
                except ExecutionError:
                    # A storage failure cancels ownership/renewal even when the
                    # failure cannot be persisted. Next access is interrupted.
                    self._release(session_id)

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
            self._wake.set()
            self._renew_due.clear()
            sessions = list(self._owners)
        failure = None
        for session_id in sessions:
            try:
                with self._lock:
                    record = self.store.get(session_id)
                    if record["state"] not in {"stopped", "completed"}:
                        record = self._save(record, {"state": "interrupted", "failure_code": "EXECUTION_CLOSED"})
                self._pause_producer(record)
            except ExecutionError as error:
                failure = error
            finally:
                self._release(session_id)
        if self._thread is not None and self._thread is not threading.current_thread():
            self._thread.join(timeout=4.)
        if failure:
            raise failure
