"""Versioned physical/virtual LIFE Patch wire contract.

The virtual device and the physical gateway use the same manifests, telemetry
envelopes, validation rules, commands, and receipts.  A matching contract is a
software parity property; physical equivalence still requires firmware, device
calibration, analytical validation, and golden-packet conformance evidence.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
import hashlib
import json
import math
import re
import threading
from typing import TYPE_CHECKING, Callable, Mapping
import uuid

if TYPE_CHECKING:
    from .protocol_v3 import ManifestV3, TelemetryEnvelopeV3


PROTOCOL_SCHEMA = "livemore.life-patch.telemetry.v2"
MANIFEST_SCHEMA = "livemore.life-patch.manifest.v2"
PROTOCOL_VERSION = "2.0"
HARDWARE_TARGET = "B0-EVT-target"


def decode_manifest(payload: Mapping[str, object]) -> DeviceManifest | ManifestV3:
    """Dispatch exact wire versions without changing v2 constructors or hashes."""
    if not isinstance(payload, Mapping):
        raise ProtocolViolation("device manifest must be an object")
    version = (payload.get("schema_version"), payload.get("protocol_version"))
    if version == (MANIFEST_SCHEMA, PROTOCOL_VERSION):
        return DeviceManifest.from_dict(payload)
    if version == ("livemore.life-patch.manifest.v3", "3.0"):
        from .protocol_v3 import ManifestV3
        return ManifestV3.from_dict(payload)
    raise ProtocolViolation("unsupported LIFE Patch manifest version")


def decode_envelope(payload: Mapping[str, object]) -> TelemetryEnvelope | TelemetryEnvelopeV3:
    """Decode legacy or lineage-bearing telemetry without implicit conversion."""
    if not isinstance(payload, Mapping):
        raise ProtocolViolation("telemetry envelope must be an object")
    version = (payload.get("schema_version"), payload.get("protocol_version"))
    if version == (PROTOCOL_SCHEMA, PROTOCOL_VERSION):
        return TelemetryEnvelope.from_dict(payload)
    if version == ("livemore.life-patch.telemetry.v3", "3.0"):
        from .protocol_v3 import TelemetryEnvelopeV3
        return TelemetryEnvelopeV3.from_dict(payload)
    raise ProtocolViolation("unsupported LIFE Patch telemetry version")


class ProtocolViolation(ValueError):
    """The device record cannot be admitted to the governed stream."""


class DeviceMode(str, Enum):
    PHYSICAL = "physical"
    VIRTUAL = "virtual"
    EXTERNAL = "external"


class QualityStatus(str, Enum):
    PASS = "pass"
    DEGRADED = "degraded"
    REJECT = "reject"


class CalibrationStatus(str, Enum):
    CURRENT = "current"
    DUE = "due"
    FAILED = "failed"
    NOT_APPLICABLE = "not_applicable"


@dataclass(frozen=True)
class SignalContract:
    signal: str
    unit: str
    minimum: float
    maximum: float
    channel: str
    claim: str


SIGNALS: tuple[SignalContract, ...] = (
    SignalContract("ecg_mv", "mV", -20.0, 20.0, "ecg", "direct"),
    SignalContract("hr_bpm", "bpm", 20.0, 250.0, "ecg", "direct"),
    SignalContract("hrv_ms", "ms", 0.0, 500.0, "ecg", "direct"),
    SignalContract("ppg_au", "AU", -1_000_000.0, 1_000_000.0, "ppg", "estimated"),
    SignalContract("spo2_pct", "%", 50.0, 100.0, "ppg", "estimated"),
    SignalContract("ptt_ms", "ms", 20.0, 1000.0, "ppg", "estimated"),
    SignalContract("glucose_mgdl", "mg/dL", 20.0, 600.0, "chem", "session"),
    SignalContract("sodium_mM", "mmol/L", 1.0, 300.0, "chem", "session"),
    SignalContract("potassium_mM", "mmol/L", 0.1, 100.0, "chem", "session"),
    SignalContract("lactate_mM", "mmol/L", 0.0, 50.0, "chem", "session"),
    SignalContract("skin_temp_c", "Cel", 15.0, 45.0, "temp", "direct"),
    SignalContract("accel_g", "g", -32.0, 32.0, "imu", "direct"),
    SignalContract("steps", "count", 0.0, 1_000_000.0, "imu", "direct"),
)
SIGNAL_BY_ID = {item.signal: item for item in SIGNALS}

SAFE_COMMANDS = (
    "set_sampling_profile",
    "request_burst",
    "start_chemistry_session",
    "stop_chemistry_session",
    "request_quality_check",
    "request_calibration_check",
)
_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:@+\-]{0,199}")
_PSEUDONYMOUS_SUBJECT = re.compile(
    r"pseudonym-[A-Za-z0-9][A-Za-z0-9_.:@+\-]{0,189}"
)
_SHA256_HEX = re.compile(r"[0-9a-f]{64}")


def _identifier(value: object, field_name: str) -> str:
    normalized = str(value).strip()
    if _IDENTIFIER.fullmatch(normalized) is None:
        raise ProtocolViolation(
            f"{field_name} must be a 1-200 character opaque structured identifier"
        )
    return normalized


def _strict_bool(value: object, field_name: str) -> bool:
    if type(value) is not bool:
        raise ProtocolViolation(f"{field_name} must be a JSON boolean")
    return value


def pseudonymous_subject_id(value: object) -> str:
    """Require an explicit opaque pseudonym namespace, never a claimed boolean alone."""
    normalized = _identifier(value, "subject ID")
    if _PSEUDONYMOUS_SUBJECT.fullmatch(normalized) is None:
        raise ProtocolViolation(
            "subject ID must use the opaque pseudonym-<id> namespace"
        )
    return normalized


def _string_array(value: object, field_name: str) -> tuple[str, ...]:
    if not isinstance(value, (list, tuple)):
        raise ProtocolViolation(f"{field_name} must be an array")
    items = tuple(str(item).strip() for item in value)
    if any(not item or len(item) > 200 for item in items):
        raise ProtocolViolation(f"{field_name} entries must be non-empty and at most 200 characters")
    return items


def subject_snapshot_key(subject_id: str) -> str:
    """Return a non-identifying, path-safe key for a pseudonymous subject."""
    normalized = pseudonymous_subject_id(subject_id)
    digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
    return f"patch.subject.{digest}"


def envelope_snapshot_key(envelope_hash: str) -> str:
    """Return the immutable snapshot key for one admitted telemetry envelope."""
    normalized = str(envelope_hash).strip().lower()
    if _SHA256_HEX.fullmatch(normalized) is None:
        raise ProtocolViolation("envelope hash must be a SHA-256 hex digest")
    return f"patch.envelope.{normalized}"


def _timestamp(value: datetime, field_name: str) -> datetime:
    if value.tzinfo is None or value.utcoffset() is None:
        raise ProtocolViolation(f"{field_name} must include a timezone")
    return value.astimezone(timezone.utc)


def _canonical_hash(payload: object) -> str:
    def default(value: object) -> object:
        if isinstance(value, Enum):
            return value.value
        if isinstance(value, datetime):
            return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        raise TypeError(type(value).__name__)

    encoded = json.dumps(
        payload, default=default, sort_keys=True, separators=(",", ":"), allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _capabilities() -> tuple[str, ...]:
    return tuple(
        f"{item.channel}:{item.signal}:{item.unit}:{item.claim}" for item in SIGNALS
    ) + (
        "MAX30003:SPI",
        "MAX86141:SPI",
        "AD5940:SPI",
        "pod-i2c:isolated",
        "pod-auth:DS28C36",
        "storage:QSPI",
    )


@dataclass(frozen=True)
class DeviceManifest:
    device_id: str
    mode: DeviceMode
    hardware_revision: str
    firmware_version: str
    protocol_version: str = PROTOCOL_VERSION
    schema_version: str = MANIFEST_SCHEMA
    capabilities: tuple[str, ...] = field(default_factory=_capabilities)
    safe_commands: tuple[str, ...] = SAFE_COMMANDS
    hardware_present: bool = False

    def __post_init__(self) -> None:
        object.__setattr__(self, "device_id", _identifier(self.device_id, "device ID"))
        _strict_bool(self.hardware_present, "hardware_present")
        object.__setattr__(self, "hardware_revision", _identifier(
            self.hardware_revision, "hardware revision"
        ))
        object.__setattr__(self, "firmware_version", _identifier(
            self.firmware_version, "firmware version"
        ))
        object.__setattr__(self, "capabilities", tuple(self.capabilities))
        object.__setattr__(self, "safe_commands", tuple(self.safe_commands))
        if self.protocol_version != PROTOCOL_VERSION:
            raise ProtocolViolation("unsupported LIFE Patch protocol version")
        if self.schema_version != MANIFEST_SCHEMA:
            raise ProtocolViolation("unsupported LIFE Patch manifest schema")
        if self.mode is DeviceMode.VIRTUAL and self.hardware_present:
            raise ProtocolViolation("a virtual patch cannot claim physical hardware")
        if self.hardware_revision != HARDWARE_TARGET:
            raise ProtocolViolation("manifest hardware revision does not match the B0 contract")
        if self.capabilities != _capabilities():
            raise ProtocolViolation("manifest capabilities do not match the LIFE Patch v2 contract")
        if self.safe_commands != SAFE_COMMANDS:
            raise ProtocolViolation("manifest safe commands do not match the LIFE Patch v2 contract")

    @property
    def capability_hash(self) -> str:
        return _canonical_hash({
            "protocol_version": self.protocol_version,
            "hardware_revision": self.hardware_revision,
            "capabilities": self.capabilities,
            "safe_commands": self.safe_commands,
        })

    def to_dict(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "device_id": self.device_id,
            "mode": self.mode.value,
            "hardware_revision": self.hardware_revision,
            "firmware_version": self.firmware_version,
            "protocol_version": self.protocol_version,
            "capabilities": list(self.capabilities),
            "safe_commands": list(self.safe_commands),
            "hardware_present": self.hardware_present,
            "capability_hash": self.capability_hash,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, object]) -> "DeviceManifest":
        manifest = cls(
            schema_version=str(value.get("schema_version", "")),
            device_id=str(value.get("device_id", "")),
            mode=DeviceMode(str(value.get("mode", ""))),
            hardware_revision=str(value.get("hardware_revision", "")),
            firmware_version=str(value.get("firmware_version", "")),
            protocol_version=str(value.get("protocol_version", "")),
            capabilities=_string_array(value.get("capabilities", ()), "capabilities"),
            safe_commands=_string_array(value.get("safe_commands", ()), "safe_commands"),
            hardware_present=_strict_bool(value.get("hardware_present", False), "hardware_present"),
        )
        supplied_hash = str(value.get("capability_hash", ""))
        if supplied_hash and supplied_hash != manifest.capability_hash:
            raise ProtocolViolation("manifest capability hash does not match")
        return manifest


def manifest_for(device_id: str, mode: DeviceMode) -> DeviceManifest:
    """Return the B0 target contract; it is not a manufacturing attestation."""
    return DeviceManifest(
        device_id=device_id,
        mode=mode,
        hardware_revision=HARDWARE_TARGET,
        firmware_version="virtual-2.0" if mode is DeviceMode.VIRTUAL else "not-provisioned",
        hardware_present=False,
    )


@dataclass(frozen=True)
class TelemetryMeasurement:
    signal: str
    value: float
    unit: str
    claim: str
    quality_status: QualityStatus = QualityStatus.PASS
    calibration_status: CalibrationStatus = CalibrationStatus.CURRENT

    def __post_init__(self) -> None:
        contract = SIGNAL_BY_ID.get(self.signal)
        if contract is None:
            raise ProtocolViolation(f"unsupported signal: {self.signal}")
        if self.unit != contract.unit or self.claim != contract.claim:
            raise ProtocolViolation(f"signal contract mismatch for {self.signal}")
        if not math.isfinite(self.value):
            raise ProtocolViolation("telemetry values must be finite")
        if not contract.minimum <= self.value <= contract.maximum:
            raise ProtocolViolation(f"{self.signal} is outside the admissible instrument range")
        if self.quality_status is QualityStatus.REJECT:
            raise ProtocolViolation("rejected-quality telemetry cannot be admitted")
        if self.calibration_status is CalibrationStatus.FAILED:
            raise ProtocolViolation("failed-calibration telemetry cannot be admitted")

    def to_dict(self) -> dict:
        return {
            "signal": self.signal,
            "value": self.value,
            "unit": self.unit,
            "claim": self.claim,
            "quality_status": self.quality_status.value,
            "calibration_status": self.calibration_status.value,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, object]) -> "TelemetryMeasurement":
        return cls(
            signal=str(value.get("signal", "")),
            value=float(value.get("value", float("nan"))),
            unit=str(value.get("unit", "")),
            claim=str(value.get("claim", "")),
            quality_status=QualityStatus(str(value.get("quality_status", ""))),
            calibration_status=CalibrationStatus(str(value.get("calibration_status", ""))),
        )


def _measurement_from_dict(value: object) -> TelemetryMeasurement:
    if not isinstance(value, Mapping):
        raise ProtocolViolation("each measurement must be an object")
    return TelemetryMeasurement.from_dict(value)


@dataclass(frozen=True)
class TelemetryEnvelope:
    envelope_id: str
    device_id: str
    subject_id: str
    sequence: int
    captured_at: datetime
    mode: DeviceMode
    measurements: tuple[TelemetryMeasurement, ...]
    subject_pseudonymized: bool = True
    protocol_version: str = PROTOCOL_VERSION
    schema_version: str = PROTOCOL_SCHEMA
    envelope_hash: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "envelope_id", _identifier(self.envelope_id, "envelope ID"))
        object.__setattr__(self, "device_id", _identifier(self.device_id, "device ID"))
        object.__setattr__(self, "subject_id", pseudonymous_subject_id(self.subject_id))
        _strict_bool(self.subject_pseudonymized, "subject_pseudonymized")
        if not self.subject_pseudonymized:
            raise ProtocolViolation("LIFE Patch subjects must be pseudonymized before admission")
        if self.sequence < 0:
            raise ProtocolViolation("telemetry sequence must be non-negative")
        if not self.measurements:
            raise ProtocolViolation("telemetry envelope requires measurements")
        if self.protocol_version != PROTOCOL_VERSION or self.schema_version != PROTOCOL_SCHEMA:
            raise ProtocolViolation("unsupported telemetry contract version")
        object.__setattr__(self, "captured_at", _timestamp(self.captured_at, "captured_at"))
        object.__setattr__(self, "measurements", tuple(self.measurements))
        calculated = _canonical_hash(self._hash_payload())
        if self.envelope_hash and self.envelope_hash != calculated:
            raise ProtocolViolation("telemetry envelope hash does not match")
        object.__setattr__(self, "envelope_hash", calculated)

    def _hash_payload(self) -> dict:
        return {
            "schema_version": self.schema_version,
            "protocol_version": self.protocol_version,
            "envelope_id": self.envelope_id,
            "device_id": self.device_id,
            "subject_id": self.subject_id,
            "subject_pseudonymized": self.subject_pseudonymized,
            "sequence": self.sequence,
            "captured_at": self.captured_at,
            "mode": self.mode,
            "measurements": [item.to_dict() for item in self.measurements],
        }

    def to_dict(self) -> dict:
        payload = self._hash_payload()
        payload["captured_at"] = self.captured_at.isoformat().replace("+00:00", "Z")
        payload["mode"] = self.mode.value
        payload["envelope_hash"] = self.envelope_hash
        return payload

    @classmethod
    def from_dict(cls, value: Mapping[str, object]) -> "TelemetryEnvelope":
        raw_measurements = value.get("measurements", ())
        if not isinstance(raw_measurements, (list, tuple)):
            raise ProtocolViolation("measurements must be an array")
        captured = str(value.get("captured_at", "")).replace("Z", "+00:00")
        try:
            captured_at = datetime.fromisoformat(captured)
        except ValueError as error:
            raise ProtocolViolation("captured_at must be an ISO-8601 timestamp") from error
        return cls(
            schema_version=str(value.get("schema_version", "")),
            protocol_version=str(value.get("protocol_version", "")),
            envelope_id=str(value.get("envelope_id", "")),
            device_id=str(value.get("device_id", "")),
            subject_id=str(value.get("subject_id", "")),
            subject_pseudonymized=_strict_bool(
                value.get("subject_pseudonymized", False), "subject_pseudonymized"
            ),
            sequence=int(value.get("sequence", -1)),
            captured_at=captured_at,
            mode=DeviceMode(str(value.get("mode", ""))),
            measurements=tuple(_measurement_from_dict(item) for item in raw_measurements),
            envelope_hash=str(value.get("envelope_hash", "")),
        )


class VirtualLifePatch:
    def __init__(self, manifest: DeviceManifest, *, sequence: int = 0):
        if manifest.mode is not DeviceMode.VIRTUAL:
            raise ProtocolViolation("virtual patch requires a virtual manifest")
        self.manifest = manifest
        self._sequence = sequence

    def emit(
        self,
        subject_id: str,
        readings: Mapping[str, float],
        *,
        captured_at: datetime | None = None,
    ) -> TelemetryEnvelope:
        self._sequence += 1
        measurements = []
        for signal, value in readings.items():
            contract = SIGNAL_BY_ID.get(signal)
            if contract is None:
                raise ProtocolViolation(f"unsupported signal: {signal}")
            measurements.append(TelemetryMeasurement(
                signal=signal,
                value=float(value),
                unit=contract.unit,
                claim=contract.claim,
                calibration_status=CalibrationStatus.NOT_APPLICABLE,
            ))
        return TelemetryEnvelope(
            envelope_id=f"telemetry-{uuid.uuid4().hex}",
            device_id=self.manifest.device_id,
            subject_id=subject_id,
            subject_pseudonymized=True,
            sequence=self._sequence,
            captured_at=captured_at or datetime.now(timezone.utc),
            mode=DeviceMode.VIRTUAL,
            measurements=tuple(measurements),
        )


class PatchAdmissionController:
    """Validate integrity, freshness, manifest parity, and monotonically increasing sequence."""

    def __init__(
        self,
        *,
        now: Callable[[], datetime] | None = None,
        maximum_age: timedelta = timedelta(minutes=15),
    ):
        self._now = now or (lambda: datetime.now(timezone.utc))
        self._maximum_age = maximum_age
        self._last_sequence: dict[str, int] = {}
        self._lock = threading.RLock()

    def seed_sequence(self, device_id: str, sequence: int) -> None:
        """Restore the durable replay watermark when a gateway restarts."""
        with self._lock:
            self._last_sequence[device_id] = max(sequence, self._last_sequence.get(device_id, -1))

    def last_sequence(self, device_id: str) -> int:
        with self._lock:
            return self._last_sequence.get(device_id, -1)

    def admit(self, manifest: DeviceManifest, envelope: TelemetryEnvelope) -> TelemetryEnvelope:
        with self._lock:
            if manifest.device_id != envelope.device_id:
                raise ProtocolViolation("telemetry device does not match its manifest")
            if manifest.mode is not envelope.mode:
                raise ProtocolViolation("telemetry mode does not match its device manifest")
            if manifest.protocol_version != envelope.protocol_version:
                raise ProtocolViolation("manifest and telemetry protocol versions differ")
            now = _timestamp(self._now(), "admission time")
            if envelope.captured_at > now + timedelta(minutes=5):
                raise ProtocolViolation("telemetry timestamp is materially in the future")
            if now - envelope.captured_at > self._maximum_age:
                raise ProtocolViolation("telemetry is stale")
            previous = self._last_sequence.get(envelope.device_id, -1)
            if envelope.sequence <= previous:
                raise ProtocolViolation("telemetry sequence was replayed or reordered")
            self._last_sequence[envelope.device_id] = envelope.sequence
        return envelope


@dataclass(frozen=True)
class PatchCommand:
    command_id: str
    device_id: str
    command: str
    parameters: Mapping[str, object]
    issued_at: datetime
    expires_at: datetime

    def __post_init__(self) -> None:
        object.__setattr__(self, "command_id", _identifier(self.command_id, "command ID"))
        object.__setattr__(self, "device_id", _identifier(self.device_id, "device ID"))
        if self.command not in SAFE_COMMANDS:
            raise ProtocolViolation("command is outside the LIFE Patch safety allowlist")
        _validate_command_parameters(self.command, self.parameters)
        object.__setattr__(self, "issued_at", _timestamp(self.issued_at, "issued_at"))
        object.__setattr__(self, "expires_at", _timestamp(self.expires_at, "expires_at"))
        if self.expires_at <= self.issued_at:
            raise ProtocolViolation("command expiry must follow issuance")

    def to_dict(self) -> dict:
        return {
            "command_id": self.command_id,
            "device_id": self.device_id,
            "command": self.command,
            "parameters": dict(self.parameters),
            "issued_at": self.issued_at.isoformat().replace("+00:00", "Z"),
            "expires_at": self.expires_at.isoformat().replace("+00:00", "Z"),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, object]) -> "PatchCommand":
        parameters = value.get("parameters", {})
        if not isinstance(parameters, Mapping):
            raise ProtocolViolation("command parameters must be an object")
        return cls(
            command_id=str(value.get("command_id", "")),
            device_id=str(value.get("device_id", "")),
            command=str(value.get("command", "")),
            parameters=dict(parameters),
            issued_at=datetime.fromisoformat(str(value.get("issued_at", "")).replace("Z", "+00:00")),
            expires_at=datetime.fromisoformat(str(value.get("expires_at", "")).replace("Z", "+00:00")),
        )


@dataclass(frozen=True)
class CommandReceipt:
    command_id: str
    device_id: str
    status: str
    received_at: datetime
    detail: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(self, "command_id", _identifier(self.command_id, "command ID"))
        object.__setattr__(self, "device_id", _identifier(self.device_id, "device ID"))
        if self.status not in {"accepted", "completed", "rejected", "expired"}:
            raise ProtocolViolation("unsupported command receipt status")
        object.__setattr__(self, "received_at", _timestamp(self.received_at, "received_at"))

    def to_dict(self) -> dict:
        return {
            "command_id": self.command_id,
            "device_id": self.device_id,
            "status": self.status,
            "received_at": self.received_at.isoformat().replace("+00:00", "Z"),
            "detail": self.detail,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, object]) -> "CommandReceipt":
        return cls(
            command_id=str(value.get("command_id", "")),
            device_id=str(value.get("device_id", "")),
            status=str(value.get("status", "")),
            received_at=datetime.fromisoformat(str(value.get("received_at", "")).replace("Z", "+00:00")),
            detail=str(value.get("detail", "")),
        )


def _validate_command_parameters(command: str, parameters: Mapping[str, object]) -> None:
    keys = set(parameters)
    if command in {"request_quality_check", "request_calibration_check", "stop_chemistry_session"}:
        if keys:
            raise ProtocolViolation(f"{command} does not accept parameters")
        return
    if command == "set_sampling_profile":
        if keys != {"profile"} or parameters.get("profile") not in {"low_power", "balanced", "diagnostic"}:
            raise ProtocolViolation("sampling profile must be low_power, balanced, or diagnostic")
        return
    if command == "request_burst":
        if keys - {"duration_seconds", "channels"}:
            raise ProtocolViolation("request_burst contains unsupported parameters")
        try:
            duration = float(parameters.get("duration_seconds", 0))
        except (TypeError, ValueError) as error:
            raise ProtocolViolation("burst duration must be numeric") from error
        if not math.isfinite(duration) or not 1 <= duration <= 300:
            raise ProtocolViolation("burst duration must be between 1 and 300 seconds")
        channels = parameters.get("channels", ())
        if not isinstance(channels, (list, tuple)) or not channels:
            raise ProtocolViolation("request_burst requires one or more channels")
        allowed = {item.channel for item in SIGNALS}
        if any(str(channel) not in allowed for channel in channels):
            raise ProtocolViolation("request_burst includes an unsupported channel")
        return
    if command == "start_chemistry_session":
        if keys - {"duration_seconds", "analytes"}:
            raise ProtocolViolation("chemistry session contains unsupported parameters")
        try:
            duration = float(parameters.get("duration_seconds", 0))
        except (TypeError, ValueError) as error:
            raise ProtocolViolation("chemistry-session duration must be numeric") from error
        if not math.isfinite(duration) or not 10 <= duration <= 900:
            raise ProtocolViolation("chemistry-session duration must be between 10 and 900 seconds")
        analytes = parameters.get("analytes", ())
        allowed = {item.signal for item in SIGNALS if item.channel == "chem"}
        if not isinstance(analytes, (list, tuple)) or not analytes:
            raise ProtocolViolation("chemistry session requires analytes")
        if any(str(analyte) not in allowed for analyte in analytes):
            raise ProtocolViolation("chemistry session includes an unsupported analyte")


class PhysicalPatchGateway:
    """Decode provisioned firmware envelopes without pretending BLE exists locally."""

    def __init__(self, manifest: DeviceManifest):
        if manifest.mode is not DeviceMode.PHYSICAL:
            raise ProtocolViolation("physical gateway requires a physical manifest")
        if not manifest.hardware_present or manifest.firmware_version == "not-provisioned":
            raise ProtocolViolation("physical gateway requires a provisioned hardware manifest")
        self.manifest = manifest

    def decode_telemetry(self, payload: Mapping[str, object]) -> TelemetryEnvelope:
        envelope = TelemetryEnvelope.from_dict(payload)
        if envelope.mode is not DeviceMode.PHYSICAL:
            raise ProtocolViolation("physical gateway received non-physical telemetry")
        if envelope.device_id != self.manifest.device_id:
            raise ProtocolViolation("physical telemetry device does not match the gateway")
        return envelope

    def decode_receipt(self, payload: Mapping[str, object]) -> CommandReceipt:
        receipt = CommandReceipt.from_dict(payload)
        if receipt.device_id != self.manifest.device_id:
            raise ProtocolViolation("command receipt device does not match the gateway")
        return receipt
