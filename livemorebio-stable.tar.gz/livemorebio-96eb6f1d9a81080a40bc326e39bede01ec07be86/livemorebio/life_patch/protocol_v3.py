"""Additive LIFE wire contract with explicit lineage and separate acquisition clocks.

V2 objects and hashes are deliberately untouched. V3 records retain an immutable
canonical JSON copy; callers receive copies, never mutable hash-covered state.
This is software conformance, not firmware or physical-sensor qualification.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import math
from typing import Any, Mapping

from .protocol import (
    DeviceMode, HARDWARE_TARGET, ProtocolViolation, SAFE_COMMANDS, SIGNAL_BY_ID,
    TelemetryEnvelope, _canonical_hash, _identifier, _SHA256_HEX,
    pseudonymous_subject_id,
)


PROTOCOL_VERSION = "3.0"
MANIFEST_SCHEMA = "livemore.life-patch.manifest.v3"
PROTOCOL_SCHEMA = "livemore.life-patch.telemetry.v3"
MAX_PAYLOAD_BYTES = 262_144
MAX_MEASUREMENTS = 64  # Must remain below the existing evidence sequence stride, 1000.
MAX_WAVEFORM_SAMPLES = 4096
_PROVENANCE = {"raw", "calibrated", "derived", "inferred", "modeled", "technical_fixture"}
_VIRTUAL_PROVENANCE = {"modeled", "technical_fixture"}
_CONTEXT_KEYS = {
    "endpoint", "biofluid", "site", "compartment", "assay_id", "cartridge_id",
    "calibration_id", "derivation_id",
}


def _copy_json(value: Mapping[str, object]) -> dict[str, Any]:
    """Bound tree work before serialization, including unknown hostile fields."""
    pending = [(value, 0)]
    nodes = budget = 0
    while pending:
        item, depth = pending.pop()
        nodes += 1
        if nodes > 20_000 or depth > 8:
            raise ProtocolViolation("v3 payload exceeds structural limits")
        if isinstance(item, dict):
            if len(item) > 64:
                raise ProtocolViolation("v3 object exceeds field limit")
            for key, child in item.items():
                if type(key) is not str or len(key) > 100:
                    raise ProtocolViolation("v3 field names must be bounded strings")
                budget += len(key) * 4 + 4
                pending.append((child, depth + 1))
        elif isinstance(item, (list, tuple)):
            if len(item) > MAX_WAVEFORM_SAMPLES:
                raise ProtocolViolation("v3 array exceeds item limit")
            pending.extend((child, depth + 1) for child in item)
        elif type(item) is str:
            if len(item) > 1000:
                raise ProtocolViolation("v3 string exceeds length limit")
            budget += len(item) * 4 + 4
        elif item is None or type(item) is bool:
            budget += 5
        elif type(item) in (int, float):
            if abs(item) > 1e100 or not math.isfinite(item):
                raise ProtocolViolation("v3 numbers must be bounded and finite")
            budget += 32
        else:
            raise ProtocolViolation("v3 payload must contain JSON values")
        if budget > MAX_PAYLOAD_BYTES:
            raise ProtocolViolation("v3 payload exceeds byte limit")
    if not isinstance(value, dict):
        raise ProtocolViolation("v3 payload must be an object")
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
    if len(encoded.encode("utf-8")) > MAX_PAYLOAD_BYTES:
        raise ProtocolViolation("v3 payload exceeds byte limit")
    return json.loads(encoded)


def _fields(value: object, required: set[str], optional: set[str] | None = None) -> dict:
    if not isinstance(value, dict) or not required <= value.keys():
        raise ProtocolViolation("v3 object is missing required fields")
    if value.keys() - required - (optional or set()):
        raise ProtocolViolation("v3 object contains unsupported fields")
    return value


def _id(value: object, name: str) -> str:
    if type(value) is not str:
        raise ProtocolViolation(f"{name} must be a structured identifier")
    return _identifier(value, name)


def _digest(value: object, name: str) -> str:
    if type(value) is not str or not _SHA256_HEX.fullmatch(value):
        raise ProtocolViolation(f"{name} must be a SHA-256 hex digest")
    return value


def _number(value: object, name: str, minimum: float = -1e100, maximum: float = 1e100) -> float:
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ProtocolViolation(f"{name} must be a finite JSON number")
    if not minimum <= value <= maximum:
        raise ProtocolViolation(f"{name} is outside the contract bounds")
    return float(value)


def _utc(value: object, name: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00")) if type(value) is str else value
        if not isinstance(parsed, datetime) or parsed.tzinfo is None or parsed.utcoffset() is None:
            raise ValueError
        return parsed.astimezone(timezone.utc)
    except (ValueError, TypeError, OverflowError):
        raise ProtocolViolation(f"{name} must be a timezone-aware ISO-8601 timestamp") from None


def _iso(value: datetime) -> str:
    return value.isoformat().replace("+00:00", "Z")


def _mode(value: object) -> DeviceMode:
    try:
        return DeviceMode(value)
    except (ValueError, TypeError):
        raise ProtocolViolation("unsupported v3 device mode") from None


def _signal(value: dict, mode: DeviceMode) -> None:
    signal = value.get("signal")
    if type(signal) is not str or signal not in SIGNAL_BY_ID:
        raise ProtocolViolation("unsupported v3 signal")
    contract = SIGNAL_BY_ID[signal]
    if value.get("unit") != contract.unit:
        raise ProtocolViolation("v3 signal unit mismatch")
    provenance = value.get("provenance")
    if type(provenance) is not str or provenance not in _PROVENANCE:
        raise ProtocolViolation("unsupported v3 provenance")
    if (mode is DeviceMode.VIRTUAL) != (provenance in _VIRTUAL_PROVENANCE):
        raise ProtocolViolation("v3 provenance does not match device mode")
    if signal in {"hr_bpm", "hrv_ms", "steps", "spo2_pct", "ptt_ms"} and provenance in {"raw", "calibrated"}:
        raise ProtocolViolation("computed signal requires derived or inferred provenance")
    if contract.channel == "chem" and provenance == "raw":
        raise ProtocolViolation("chemistry concentration is not a raw instrument signal")


def _finish(payload: dict, field: str) -> str:
    supplied = payload.pop(field, None)
    calculated = _canonical_hash(payload)
    if supplied is not None and supplied != calculated:
        raise ProtocolViolation(f"v3 {field} does not match")
    payload[field] = calculated
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False)


@dataclass(frozen=True, init=False)
class ManifestV3:
    _json: str = field(repr=False)

    def __init__(self, payload: Mapping[str, object]):
        value = _copy_json(payload)
        _fields(value, {
            "schema_version", "protocol_version", "device_id", "mode", "hardware_revision",
            "configuration_id", "firmware_version", "firmware_hash", "hardware_present",
            "capabilities", "safe_commands",
        }, {"capability_hash"})
        if value["schema_version"] != MANIFEST_SCHEMA or value["protocol_version"] != PROTOCOL_VERSION:
            raise ProtocolViolation("unsupported v3 manifest version")
        mode = _mode(value["mode"])
        for key in ("device_id", "configuration_id", "firmware_version", "hardware_revision"):
            value[key] = _id(value[key], key)
        if value["hardware_revision"] != HARDWARE_TARGET:
            raise ProtocolViolation("v3 hardware target is unsupported")
        _digest(value["firmware_hash"], "firmware_hash")
        if type(value["hardware_present"]) is not bool:
            raise ProtocolViolation("hardware_present must be a JSON boolean")
        if mode is DeviceMode.VIRTUAL and value["hardware_present"]:
            raise ProtocolViolation("virtual devices cannot claim physical hardware")
        capabilities = value["capabilities"]
        if not isinstance(capabilities, list) or not 1 <= len(capabilities) <= MAX_MEASUREMENTS:
            raise ProtocolViolation("v3 manifest requires bounded capabilities")
        seen = set()
        for capability in capabilities:
            _fields(capability, {"signal", "unit", "channel", "provenance", "cartridge_id"})
            _signal(capability, mode)
            if capability["channel"] != SIGNAL_BY_ID[capability["signal"]].channel:
                raise ProtocolViolation("v3 capability channel mismatch")
            if capability["cartridge_id"] is not None:
                capability["cartridge_id"] = _id(capability["cartridge_id"], "cartridge_id")
            if capability["signal"] in seen:
                raise ProtocolViolation("duplicate v3 capability signal")
            seen.add(capability["signal"])
        commands = value["safe_commands"]
        if not isinstance(commands, list) or any(type(item) is not str for item in commands):
            raise ProtocolViolation("safe_commands must be an array of allowlisted commands")
        if len(set(commands)) != len(commands) or not set(commands) <= set(SAFE_COMMANDS):
            raise ProtocolViolation("v3 commands exceed safety allowlist")
        value["capabilities"] = sorted(capabilities, key=lambda item: item["signal"])
        value["safe_commands"] = sorted(commands)
        object.__setattr__(self, "_json", _finish(value, "capability_hash"))

    @classmethod
    def from_dict(cls, value: Mapping[str, object]) -> ManifestV3:
        return cls(value)

    def to_dict(self) -> dict:
        return json.loads(self._json)

    @property
    def device_id(self) -> str:
        return self.to_dict()["device_id"]

    @property
    def mode(self) -> DeviceMode:
        return DeviceMode(self.to_dict()["mode"])

    @property
    def hardware_revision(self) -> str:
        return self.to_dict()["hardware_revision"]

    @property
    def firmware_version(self) -> str:
        return self.to_dict()["firmware_version"]

    @property
    def hardware_present(self) -> bool:
        return self.to_dict()["hardware_present"]

    @property
    def capability_hash(self) -> str:
        return self.to_dict()["capability_hash"]

    @property
    def safe_commands(self) -> tuple[str, ...]:
        return tuple(self.to_dict()["safe_commands"])

    @property
    def firmware_hash(self) -> str:
        return self.to_dict()["firmware_hash"]

    @property
    def configuration_id(self) -> str:
        return self.to_dict()["configuration_id"]

    @property
    def capabilities(self) -> tuple[dict, ...]:
        return tuple(self.to_dict()["capabilities"])

    protocol_version = PROTOCOL_VERSION
    schema_version = MANIFEST_SCHEMA


def _measurement(value: dict, mode: DeviceMode, duration: float) -> None:
    _fields(value, {"measurement_id", "signal", "unit", "provenance", "kind",
                    "quality_status", "calibration_status", "quality_flags", "context"},
            {"value", "samples", "sample_period_s", "model_context"})
    value["measurement_id"] = _id(value["measurement_id"], "measurement_id")
    _signal(value, mode)
    if value["quality_status"] not in ("pass", "degraded", "unknown"):
        raise ProtocolViolation("rejected or unsupported v3 quality status")
    if value["calibration_status"] not in ("current", "due", "not_applicable", "unknown"):
        raise ProtocolViolation("failed or unsupported v3 calibration status")
    flags = value["quality_flags"]
    if not isinstance(flags, list) or len(flags) > 16:
        raise ProtocolViolation("v3 quality_flags must be a bounded array")
    flags = [_id(flag, "quality flag") for flag in flags]
    value["quality_flags"] = flags
    if len(set(flags)) != len(flags) or (flags and value["quality_status"] == "pass"):
        raise ProtocolViolation("quality flags cannot be duplicated or silently pass quality")
    context = _fields(value["context"], _CONTEXT_KEYS)
    for key, item in context.items():
        if item is not None:
            context[key] = _id(item, key)
    if context["endpoint"] != value["signal"]:
        raise ProtocolViolation("v3 endpoint does not match signal")
    if value["provenance"] == "calibrated" and not context["calibration_id"]:
        raise ProtocolViolation("calibrated measurements require calibration identity")
    if value["provenance"] in {"derived", "inferred"} and not context["derivation_id"]:
        raise ProtocolViolation("computed measurements require derivation identity")
    if "model_context" in value:
        model = _fields(value["model_context"], {
            "prediction_id", "condition_id", "model_time_min", "model_id", "mapping_id",
        })
        for key in ("prediction_id", "condition_id", "model_id", "mapping_id"):
            model[key] = _id(model[key], key)
        model["model_time_min"] = _number(model["model_time_min"], "model_time_min", 0, 1e9)
        if mode is not DeviceMode.VIRTUAL:
            raise ProtocolViolation("physical telemetry cannot assert a model clock binding")
    elif value["provenance"] == "modeled":
        raise ProtocolViolation("modeled output requires frozen model context")
    contract = SIGNAL_BY_ID[value["signal"]]
    if value["kind"] == "scalar":
        if "value" not in value or "samples" in value or "sample_period_s" in value:
            raise ProtocolViolation("scalar measurement requires only a scalar value")
        value["value"] = _number(value["value"], "measurement value", contract.minimum, contract.maximum)
    elif value["kind"] == "waveform":
        if "value" in value or "samples" not in value or "sample_period_s" not in value:
            raise ProtocolViolation("waveform requires samples and sample period, not a scalar")
        if value["provenance"] not in {"raw", "calibrated", "modeled", "technical_fixture"}:
            raise ProtocolViolation("waveform provenance is unsupported")
        samples = value["samples"]
        if not isinstance(samples, list) or not 1 <= len(samples) <= MAX_WAVEFORM_SAMPLES:
            raise ProtocolViolation("waveform sample count exceeds limits")
        value["samples"] = [_number(item, "waveform sample", contract.minimum, contract.maximum) for item in samples]
        period = _number(value["sample_period_s"], "sample_period_s", 1e-9, 86400)
        value["sample_period_s"] = period
        if not math.isclose((len(samples) - 1) * period, duration, abs_tol=1e-6, rel_tol=1e-6):
            raise ProtocolViolation("waveform sample timing does not match acquisition window")
    else:
        raise ProtocolViolation("unsupported v3 measurement kind")


@dataclass(frozen=True, init=False)
class TelemetryEnvelopeV3:
    _json: str = field(repr=False)

    def __init__(self, payload: Mapping[str, object]):
        value = _copy_json(payload)
        _fields(value, {
            "schema_version", "protocol_version", "envelope_id", "device_id", "subject_id",
            "subject_pseudonymized", "sequence", "mode", "manifest_hash", "firmware_hash",
            "captured_at", "acquisition_start", "acquisition_end", "clock", "measurements",
        }, {"envelope_hash"})
        if value["schema_version"] != PROTOCOL_SCHEMA or value["protocol_version"] != PROTOCOL_VERSION:
            raise ProtocolViolation("unsupported v3 telemetry version")
        mode = _mode(value["mode"])
        for key in ("envelope_id", "device_id"):
            value[key] = _id(value[key], key)
        value["subject_id"] = pseudonymous_subject_id(_id(value["subject_id"], "subject_id"))
        if value["subject_pseudonymized"] is not True:
            raise ProtocolViolation("subject_pseudonymized must be true")
        if type(value["sequence"]) is not int or not 0 <= value["sequence"] < 2**53 // 1000:
            raise ProtocolViolation("sequence must be a bounded non-negative JSON integer")
        for key in ("manifest_hash", "firmware_hash"):
            _digest(value[key], key)
        start = _utc(value["acquisition_start"], "acquisition_start")
        end = _utc(value["acquisition_end"], "acquisition_end")
        captured = _utc(value["captured_at"], "captured_at")
        if end < start or captured != end:
            raise ProtocolViolation("captured_at must equal the ordered acquisition window end")
        value.update(acquisition_start=_iso(start), acquisition_end=_iso(end), captured_at=_iso(captured))
        clock = _fields(value["clock"], {"session_id", "monotonic_start_s", "monotonic_end_s", "utc_uncertainty_s"})
        clock["session_id"] = _id(clock["session_id"], "clock session_id")
        for key in ("monotonic_start_s", "monotonic_end_s"):
            clock[key] = _number(clock[key], key, 0, 1e12)
        clock["utc_uncertainty_s"] = _number(clock["utc_uncertainty_s"], "utc_uncertainty_s", 0, 300)
        duration = (end - start).total_seconds()
        monotonic_duration = clock["monotonic_end_s"] - clock["monotonic_start_s"]
        if monotonic_duration < 0 or duration > 86400:
            raise ProtocolViolation("acquisition clock duration is invalid")
        if abs(monotonic_duration - duration) > 2 * clock["utc_uncertainty_s"] + 1e-6:
            raise ProtocolViolation("monotonic and UTC acquisition durations disagree")
        measurements = value["measurements"]
        if not isinstance(measurements, list) or not 1 <= len(measurements) <= MAX_MEASUREMENTS:
            raise ProtocolViolation("v3 telemetry requires bounded measurements")
        ids, signals = set(), set()
        for item in measurements:
            _measurement(item, mode, duration)
            if item["measurement_id"] in ids or item["signal"] in signals:
                raise ProtocolViolation("duplicate v3 measurement ID or signal")
            ids.add(item["measurement_id"])
            signals.add(item["signal"])
        object.__setattr__(self, "_json", _finish(value, "envelope_hash"))

    @classmethod
    def from_dict(cls, value: Mapping[str, object]) -> TelemetryEnvelopeV3:
        return cls(value)

    def to_dict(self) -> dict:
        return json.loads(self._json)

    @property
    def envelope_id(self) -> str:
        return self.to_dict()["envelope_id"]

    @property
    def device_id(self) -> str:
        return self.to_dict()["device_id"]

    @property
    def subject_id(self) -> str:
        return self.to_dict()["subject_id"]

    @property
    def sequence(self) -> int:
        return self.to_dict()["sequence"]

    @property
    def captured_at(self) -> datetime:
        return _utc(self.to_dict()["captured_at"], "captured_at")

    @property
    def mode(self) -> DeviceMode:
        return DeviceMode(self.to_dict()["mode"])

    @property
    def envelope_hash(self) -> str:
        return self.to_dict()["envelope_hash"]

    @property
    def measurements(self) -> tuple[dict, ...]:
        return tuple(self.to_dict()["measurements"])

    protocol_version = PROTOCOL_VERSION
    schema_version = PROTOCOL_SCHEMA


def validate_manifest_binding(manifest: ManifestV3, envelope: TelemetryEnvelopeV3) -> None:
    """Used only with a registered or independently LIFE-attested manifest."""
    source, packet = manifest.to_dict(), envelope.to_dict()
    if source["device_id"] != packet["device_id"] or source["mode"] != packet["mode"]:
        raise ProtocolViolation("v3 manifest device or mode mismatch")
    if source["capability_hash"] != packet["manifest_hash"]:
        raise ProtocolViolation("v3 manifest hash does not match envelope")
    if source["firmware_hash"] != packet["firmware_hash"]:
        raise ProtocolViolation("v3 firmware hash does not match registered manifest")
    if manifest.mode is not DeviceMode.VIRTUAL and (
        not manifest.hardware_present or manifest.firmware_version == "not-provisioned"
    ):
        raise ProtocolViolation("v3 physical/external manifest is not provisioned")
    capabilities = {item["signal"]: item for item in source["capabilities"]}
    for item in packet["measurements"]:
        capability = capabilities.get(item["signal"])
        if capability is None or any(capability[key] != item[key] for key in ("unit", "provenance")):
            raise ProtocolViolation("v3 measurement is outside registered capability")
        if capability["cartridge_id"] != item["context"]["cartridge_id"]:
            raise ProtocolViolation("v3 cartridge does not match registered capability")


def normalize_observations(
    envelope: TelemetryEnvelope | TelemetryEnvelopeV3, *, received_at: datetime | None = None,
) -> dict[str, dict[str, Any]]:
    """Project verified packets without upgrading missing lineage or evidence class.

    packet/hash -> observation metadata -> UI/alignment
                -> waveform reference (samples remain in immutable source packet)
    """
    received = _iso(_utc(received_at, "received_at")) if received_at is not None else None
    source = envelope.to_dict()
    mode = source["mode"]
    result = {}
    v3 = isinstance(envelope, TelemetryEnvelopeV3)
    for index, item in enumerate(source["measurements"]):
        row = {
            **item,
            "value": item.get("value"),
            "mode": mode,
            "source": f"life-patch-{mode}",
            "schema_version": source["schema_version"],
            "protocol_version": source["protocol_version"],
            "envelope_id": source["envelope_id"],
            "envelope_hash": source["envelope_hash"],
            "device_id": source["device_id"],
            "subject_id": source["subject_id"],
            "sequence": source["sequence"],
            "captured_at": source["captured_at"],
            "received_at": received,
            "measurement_id": item.get("measurement_id", f"{source['envelope_id']}-{index}"),
            "provenance": item.get("provenance", "legacy_unknown"),
            "context": item.get("context"),
            "model_context": item.get("model_context"),
            "clock": source.get("clock"),
            "acquisition_start": source.get("acquisition_start"),
            "acquisition_end": source.get("acquisition_end"),
            "firmware_hash": source.get("firmware_hash"),
            "manifest_hash": source.get("manifest_hash"),
            "quality_flags": item.get("quality_flags", []),
            "lineage_status": "explicit_v3" if v3 else "legacy_missing",
            "kind": item.get("kind", "scalar"),
        }
        if row["kind"] == "waveform":
            samples = row.pop("samples")
            row["source_block"] = {
                "envelope_hash": source["envelope_hash"],
                "measurement_id": item["measurement_id"], "sample_count": len(samples),
                "sample_period_s": item["sample_period_s"],
            }
        result[item["signal"]] = row
    return result
