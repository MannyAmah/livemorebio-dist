"""Structural registered binding only: no peer, consent token or admission authority.

Callers must separately obtain the fresh authenticated LIFE inspection and hold
the actual source/registry guards. All outputs are detached canonical JSON data.
"""
from __future__ import annotations

from datetime import datetime
import hashlib
import re
from typing import Any
from uuid import UUID

from .protocol_v3 import ManifestV3, _copy_json
from ..strict_json import MAX_SAFE_INTEGER

INPUT_SCHEMA = "livemore.registered-physical-binding-input.v1"
BINDING_SCHEMA = "livemore.patch-binding.physical.v3"
_REQUEST = frozenset({"device_id", "mode", "protocol_version", "expected_manifest_hash",
    "calibration_status", "calibration_reference", "attestation_reference", "expected_version"})
_INSPECTION = frozenset({"schema", "manifest", "manifest_hash", "life_process_instance",
    "life_store_id", "gateway_store_id", "source_sha256", "inspected_at", "request_id"})
_DERIVED = ("device_id", "mode", "protocol_version", "hardware_revision", "firmware_version",
            "firmware_hash", "configuration_id", "capabilities", "hardware_present")
_ENTRY = frozenset(_DERIVED) | {"schema", "manifest", "manifest_hash", "inspection", "calibration_status",
    "calibration_reference", "attestation_reference", "calibration_evidence_state",
    "hardware_validation_state", "qualification_state", "telemetry_admission", "bound_at",
    "subject_fingerprint", "consent_context"}


class PhysicalBindingError(ValueError):
    code = "INVALID_PATCH_BINDING"

    def __init__(self) -> None:
        super().__init__("Registered physical binding is invalid or unavailable; inspect before use.")


def _need(valid: bool) -> None:
    if not valid:
        raise PhysicalBindingError()


def _fields(value: Any, fields: frozenset[str] | set[str]) -> None:
    _need(type(value) is dict and set(value) == fields)


def _text(value: Any, maximum: int) -> str:
    _need(type(value) is str and 1 <= len(value) <= maximum and value == value.strip()
          and all(32 <= ord(c) <= 126 for c in value))
    return value


def _digest(value: Any) -> str:
    _need(type(value) is str and re.fullmatch(r"[0-9a-f]{64}", value) is not None)
    return value


def _uuid(value: Any) -> None:
    _text(value, 36)
    _need(str(UUID(value)) == value)


def _time(value: Any) -> None:
    _text(value, 64)
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    _need(parsed.tzinfo is not None and parsed.utcoffset() is not None)


def normalize_registered_binding(body: object, inspection: object, expected_version: int) -> dict[str, Any]:
    """Validate structure, not the origin or freshness of this internal input."""
    try:
        _fields(body, _REQUEST)
        _need(type(expected_version) is int and 1 <= expected_version < MAX_SAFE_INTEGER
              and type(body["expected_version"]) is int and body["expected_version"] == expected_version)
        _need(body["mode"] == "physical" and body["protocol_version"] == "3.0")
        device = _text(body["device_id"], 96)
        _need(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:@+\-]*", device) is not None)
        _digest(body["expected_manifest_hash"])
        _need(body["calibration_status"] == "current")
        _text(body["calibration_reference"], 256); _text(body["attestation_reference"], 256)
        _fields(inspection, _INSPECTION)
        _need(inspection["schema"] == "livemore.physical-manifest-inspection.v1")
        for key in ("life_process_instance", "life_store_id", "gateway_store_id", "request_id"):
            _uuid(inspection[key])
        _need(inspection["life_store_id"] != inspection["gateway_store_id"])
        _digest(inspection["source_sha256"]); _time(inspection["inspected_at"])
        peer = _copy_json(inspection)
        manifest = ManifestV3(peer["manifest"]).to_dict()
        _need(peer["manifest"].get("capability_hash") == manifest["capability_hash"]
              and manifest["device_id"] == device and manifest["mode"] == "physical"
              and manifest["hardware_present"] is True and manifest["firmware_version"] != "not-provisioned"
              and _digest(peer["manifest_hash"]) == manifest["capability_hash"] == body["expected_manifest_hash"])
        peer["manifest"] = manifest
        return {"schema": INPUT_SCHEMA, **body, "hardware_revision": manifest["hardware_revision"],
                "firmware_version": manifest["firmware_version"], "inspection": peer}
    except (ValueError, KeyError, TypeError, AttributeError, OverflowError, RecursionError):
        raise PhysicalBindingError() from None


def normalize_prepared_binding(value: object, expected_version: int) -> dict[str, Any]:
    try:
        _fields(value, _REQUEST | {"schema", "hardware_revision", "firmware_version", "inspection"})
        _need(value["schema"] == INPUT_SCHEMA)
        normalized = normalize_registered_binding({key: value[key] for key in _REQUEST},
                                                  value["inspection"], expected_version)
        _need(normalized == value)
        return normalized
    except (ValueError, KeyError, TypeError, AttributeError):
        raise PhysicalBindingError() from None


def registered_binding_entry(binding: dict[str, Any], record: dict[str, Any], timestamp: str) -> dict[str, Any]:
    """Registry owns person admission and the atomic physical-index mutation."""
    manifest = binding["inspection"]["manifest"]
    result = {key: manifest[key] for key in _DERIVED}
    result.update(schema=BINDING_SCHEMA, manifest=manifest, manifest_hash=manifest["capability_hash"],
        inspection=binding["inspection"], calibration_status="current",
        calibration_reference=binding["calibration_reference"], attestation_reference=binding["attestation_reference"],
        calibration_evidence_state="OPERATOR_DECLARED", hardware_validation_state="NOT_ESTABLISHED",
        qualification_state="PAIRING_RECORDED", telemetry_admission="PENDING_SIGNED_ENVELOPE",
        bound_at=timestamp, subject_fingerprint=hashlib.sha256(record["subject_id"].encode()).hexdigest(),
        consent_context={"subject_id": record["subject_id"], "consent_scope": record["consent_scope"],
                         "chain_of_custody": record["chain_of_custody"]})
    return validate_stored_binding(result)


def validate_stored_binding(value: object) -> dict[str, Any]:
    """Historical lineage validation; deliberately does not require current consent."""
    try:
        _fields(value, _ENTRY)
        entry = _copy_json(value)
        _need(entry["schema"] == BINDING_SCHEMA)
        _time(entry["bound_at"])
        context = entry["consent_context"]
        _fields(context, {"subject_id", "consent_scope", "chain_of_custody"})
        subject = _text(context["subject_id"], 200)
        _need(re.fullmatch(r"pseudonym-[A-Za-z0-9][A-Za-z0-9_.:@+\-]{0,189}", subject) is not None)
        _text(context["chain_of_custody"], 1000)
        scopes = context["consent_scope"]
        _need(type(scopes) is list and 1 <= len(scopes) <= 64 and "life_patch" in scopes)
        for scope in scopes: _text(scope, 100)
        body = {key: entry[key] for key in _REQUEST - {"expected_version", "expected_manifest_hash"}}
        # These reconstruction values are structural only, not a claimed binding revision.
        body.update(expected_version=1, expected_manifest_hash=entry["manifest_hash"])
        normalized = normalize_registered_binding(body, entry["inspection"], 1)
        manifest = normalized["inspection"]["manifest"]
        _need(entry["manifest"] == manifest and all(entry[key] == manifest[key] for key in _DERIVED))
        _need(type(entry["hardware_present"]) is bool)
        _need(entry["calibration_evidence_state"] == "OPERATOR_DECLARED"
              and entry["hardware_validation_state"] == "NOT_ESTABLISHED"
              and entry["qualification_state"] == "PAIRING_RECORDED"
              and entry["telemetry_admission"] == "PENDING_SIGNED_ENVELOPE"
              and entry["subject_fingerprint"] == hashlib.sha256(subject.encode()).hexdigest())
        return entry
    except (ValueError, KeyError, TypeError, AttributeError, OverflowError, RecursionError):
        raise PhysicalBindingError() from None


def require_registered_physical_v3_binding(record: object, *, device_id: str, subject_id: str,
        manifest_hash: str, firmware_hash: str, custody_reference: str) -> dict[str, Any]:
    """A record predicate, NOT fresh selection, admission, peer or index authority.

    The caller still needs an audited eligible-record/device-index snapshot and
    final source/consent confirmation. A retained matching object grants nothing.
    """
    try:
        _need(type(record) is dict and record.get("schema") == "livemore.twin-record.v1"
              and record.get("source_class") == "REAL_HUMAN" and record.get("lifecycle") == "ACTIVE"
              and type(record.get("version")) is int and 1 <= record["version"] <= MAX_SAFE_INTEGER
              and record.get("subject_id") == subject_id and record.get("chain_of_custody") == custody_reference)
        _text(device_id, 96); _text(subject_id, 200); _text(custody_reference, 1000)
        _digest(manifest_hash); _digest(firmware_hash)
        _need(type(record.get("consent_scope")) is list and "life_patch" in record["consent_scope"])
        bindings = record["patch_bindings"]
        _need(type(bindings) is list and len(bindings) <= 64)
        selected = [entry for entry in bindings if type(entry) is dict and entry.get("device_id") == device_id]
        _need(len(selected) == 1)
        entry = validate_stored_binding(selected[0])
        _need(entry["manifest_hash"] == manifest_hash and entry["firmware_hash"] == firmware_hash
              and entry["consent_context"] == {"subject_id": subject_id, "consent_scope": record["consent_scope"],
                                               "chain_of_custody": custody_reference})
        return entry
    except (ValueError, KeyError, TypeError, AttributeError, OverflowError):
        raise PhysicalBindingError() from None
