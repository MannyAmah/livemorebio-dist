"""
livemorebio.life_patch.packet — the ingestion contract.

A LifePatchPacket is the single, stable plug-point where a real human's data
enters LivemoreBio — whether from the physical patch (when it exists), an
external feed (CGM, Apple Health, EHR), or the synthetic stand-in stream.
`hardware_present=False` is the honest flag: until the patch is manufactured,
packets are synthetic or externally sourced, never real patch hardware.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List
from .sensors import CLAIM_OF, CHANNEL_OF


@dataclass
class Measurement:
    signal: str
    value: float
    t_s: float
    claim: str = ""
    source: str = "life-patch"

    def __post_init__(self):
        if not self.claim:
            self.claim = CLAIM_OF.get(self.signal, "estimated")

    @property
    def channel(self) -> str:
        return CHANNEL_OF.get(self.signal, "unknown")


@dataclass
class LifePatchPacket:
    subject_id: str
    t_s: float
    measurements: List[Measurement] = field(default_factory=list)
    source: str = "synthetic-from-engine"
    hardware_present: bool = False          # True only for real manufactured patch

    def by_signal(self, signal: str):
        vals = [m for m in self.measurements if m.signal == signal]
        return vals[-1] if vals else None

    def to_dict(self) -> dict:
        return dict(subject_id=self.subject_id, t_s=round(self.t_s, 2),
                    source=self.source, hardware_present=self.hardware_present,
                    measurements=[dict(signal=m.signal, value=round(m.value, 3),
                                       t_s=round(m.t_s, 2), claim=m.claim, source=m.source)
                                  for m in self.measurements])
