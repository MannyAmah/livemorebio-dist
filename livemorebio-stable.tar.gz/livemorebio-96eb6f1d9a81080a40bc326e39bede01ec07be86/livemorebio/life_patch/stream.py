"""
livemorebio.life_patch.stream — sources that produce LifePatchPackets.

Until the physical patch exists there are two honest sources:
  SyntheticPatchStream  — samples a living twin's engine state (the virtual
                          patch on the virtual human). hardware_present=False.
  ExternalSeriesStream  — legacy compatibility input (CGM glucose, HR).
                          This path does not establish physical provenance.
                          Governed observations use the versioned admission API;
                          no admission reclassifies a separately computed trace.
"""
from __future__ import annotations
from typing import List, Optional, Tuple
import numpy as np
from .packet import LifePatchPacket, Measurement


class SyntheticPatchStream:
    def __init__(self, twin):
        self.twin = twin

    def sample(self, n: int = 48) -> List[LifePatchPacket]:
        m = self.twin.metabolic
        t, g = m["t_min"], m["glucose"]
        hr = 60000.0 / float(getattr(self.twin, "cardiac_cl_ms", None) or 1000.0)
        idx = np.linspace(0, len(g) - 1, n).astype(int)
        out = []
        for i in idx:
            ts = float(t[i]) * 60.0
            out.append(LifePatchPacket(
                subject_id=self.twin.profile, t_s=ts,
                source="synthetic-from-engine", hardware_present=False,
                measurements=[
                    Measurement("glucose_mgdl", float(g[i]), ts, source="synthetic-from-engine"),
                    Measurement("hr_bpm", hr, ts, source="synthetic-from-engine"),
                ]))
        return out


class ExternalSeriesStream:
    """glucose / hr: list of (t_minutes, value). source e.g. 'cgm', 'apple-health'."""
    def __init__(self, subject_id: str,
                 glucose: Optional[List[Tuple[float, float]]] = None,
                 hr: Optional[List[Tuple[float, float]]] = None,
                 source: str = "cgm"):
        self.subject_id = subject_id
        self.glucose = glucose or []
        self.hr = hr or []
        self.source = source

    def packets(self) -> List[LifePatchPacket]:
        out = []
        for tm, val in self.glucose:
            out.append(LifePatchPacket(
                subject_id=self.subject_id, t_s=float(tm) * 60.0, source=self.source,
                hardware_present=False,
                measurements=[Measurement("glucose_mgdl", float(val), float(tm) * 60.0,
                                          claim="direct", source=self.source)]))
        for tm, val in self.hr:
            out.append(LifePatchPacket(
                subject_id=self.subject_id, t_s=float(tm) * 60.0, source=self.source,
                hardware_present=False,
                measurements=[Measurement("hr_bpm", float(val), float(tm) * 60.0,
                                          claim="direct", source=self.source)]))
        return out


# a canonical real-ish CGM day for demos (diabetic pattern), (minute, mg/dL)
SAMPLE_CGM_DIABETIC = [(0,142),(60,138),(120,196),(180,225),(240,201),(300,168),
                       (360,151),(420,238),(480,262),(540,229),(600,184),(660,247),
                       (720,271),(780,236),(840,190),(900,163),(960,150)]
SAMPLE_CGM_HEALTHY = [(0,92),(60,90),(120,131),(180,118),(240,101),(300,94),
                      (360,96),(420,139),(480,124),(540,104),(600,95),(660,142),
                      (720,129),(780,108),(840,98),(900,93),(960,91)]
