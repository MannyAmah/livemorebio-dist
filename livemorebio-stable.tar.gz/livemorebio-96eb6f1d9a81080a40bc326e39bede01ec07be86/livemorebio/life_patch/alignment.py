"""Frozen, explicit observation alignment. No patient calibration or clock guessing."""
from __future__ import annotations

from bisect import bisect_left
from dataclasses import dataclass
import math
from typing import Any, Mapping


def _number(value: object) -> bool:
    try:
        return type(value) in {int, float} and math.isfinite(value)
    except OverflowError:
        return False


@dataclass(frozen=True)
class FrozenPrediction:
    prediction_id: str
    subject_id: str
    condition_id: str
    endpoint: str
    unit: str
    compartment: str
    site: str
    model_id: str
    t_min: tuple[float, ...]
    values: tuple[float, ...]

    def __post_init__(self) -> None:
        for name in ("prediction_id", "subject_id", "condition_id", "endpoint", "unit", "compartment", "site", "model_id"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip() or len(value) > 200:
                raise ValueError("prediction identity and endpoint fields must be bounded strings")
        if (not 1 <= len(self.t_min) <= 10000 or len(self.t_min) != len(self.values)
                or not all(_number(value) for value in (*self.t_min, *self.values))
                or any(right <= left for left, right in zip(self.t_min, self.t_min[1:]))):
            raise ValueError("prediction requires finite paired values and a strictly increasing bounded time axis")
        # Detach caller-owned mutable sequences; the snapshot must remain frozen.
        object.__setattr__(self, "t_min", tuple(self.t_min))
        object.__setattr__(self, "values", tuple(self.values))


@dataclass(frozen=True)
class ObservationMapping:
    mapping_id: str
    prediction_id: str
    subject_id: str
    condition_id: str
    endpoint: str
    unit: str
    compartment: str
    biofluid: str
    site: str
    time_basis: str
    source_class: str


def align_observation(prediction: FrozenPrediction | None, observation: Mapping[str, Any],
                      mapping: ObservationMapping | None) -> dict[str, Any]:
    """Evaluate an admitted mapping against a frozen series, never a mutable twin.

    Only a technical identity mapping is executable in this revision. A physical
    sensor transfer/lag function needs independently measured, versioned evidence;
    labeling a mapping 'physical' does not enable it. This is intentionally closed.
    """
    result: dict[str, Any] = {
        "predicted": None, "residual": None, "status": "MAPPING_UNAVAILABLE",
        "reason": "no admitted clock and endpoint mapping",
        "model_parameters_updated": False, "calibration_authorized": False,
    }

    def unavailable(status: str, reason: str) -> dict[str, Any]:
        return {**result, "status": status, "reason": reason}

    if mapping is None:
        return result
    if prediction is None:
        return unavailable("PREDICTION_UNAVAILABLE", "frozen prediction is unavailable")
    if not (mapping.source_class == "technical_fixture" and mapping.time_basis == "model_minute"
            and observation.get("mode") == "virtual" and observation.get("provenance") == "technical_fixture"):
        return unavailable("TRANSFER_MODEL_UNAVAILABLE", "no released physical sensor transfer model; technical mappings cannot admit physical observations")
    context = observation.get("context")
    model_context = observation.get("model_context")
    if not isinstance(context, Mapping) or not isinstance(model_context, Mapping):
        return unavailable("TIMING_CONTEXT_UNAVAILABLE", "observation lacks explicit model and endpoint context")
    if any(getattr(mapping, key) != getattr(prediction, key) for key in (
            "prediction_id", "subject_id", "condition_id", "endpoint", "unit", "compartment", "site")):
        return unavailable("MAPPING_BINDING_MISMATCH", "mapping does not bind this frozen prediction")
    if (observation.get("subject_id") != prediction.subject_id or observation.get("unit") != prediction.unit
            or any(context.get(key) != getattr(mapping, key) for key in ("endpoint", "biofluid", "compartment", "site"))
            or model_context.get("prediction_id") != prediction.prediction_id
            or model_context.get("condition_id") != prediction.condition_id
            or model_context.get("model_id") != prediction.model_id
            or model_context.get("mapping_id") != mapping.mapping_id):
        return unavailable("OBSERVATION_BINDING_MISMATCH", "subject, endpoint, units, compartment, site or prediction identity differ")
    if observation.get("quality_status") != "pass" or observation.get("calibration_status") not in {"current", "not_applicable"}:
        return unavailable("FAILED_QUALITY_GATE", "alignment requires passing quality and applicable calibration state")
    at = model_context.get("model_time_min")
    value = observation.get("value")
    if not _number(at) or not _number(value):
        return unavailable("INVALID_NUMERICAL_INPUT", "finite scalar value and explicit model minute required")
    if not prediction.t_min[0] <= at <= prediction.t_min[-1]:
        return unavailable("OUTSIDE_PREDICTION_DOMAIN", "no extrapolation beyond the frozen model time domain")
    right = bisect_left(prediction.t_min, at)
    predicted = prediction.values[right]
    if prediction.t_min[right] != at:
        left = right - 1
        # Scale the time differences and use a convex sum: subtracting two
        # finite, opposite-sign extremes can otherwise overflow before division.
        scale = max(abs(at), abs(prediction.t_min[left]), abs(prediction.t_min[right]), 1.)
        span = prediction.t_min[right] / scale - prediction.t_min[left] / scale
        fraction = (at / scale - prediction.t_min[left] / scale) / span if span else float("nan")
        predicted = (1 - fraction) * prediction.values[left] + fraction * prediction.values[right]
    residual = value - predicted
    if not _number(predicted) or not _number(residual):
        return unavailable("INVALID_NUMERICAL_OUTPUT", "alignment exceeds finite numerical representation")
    return {**result, "predicted": predicted, "residual": residual,
            "status": "UNQUALIFIED_RESIDUAL", "prediction_id": prediction.prediction_id,
            "mapping_id": mapping.mapping_id, "model_time_min": at,
            "reason": "technical identity mapping only; not independent physical validation"}
