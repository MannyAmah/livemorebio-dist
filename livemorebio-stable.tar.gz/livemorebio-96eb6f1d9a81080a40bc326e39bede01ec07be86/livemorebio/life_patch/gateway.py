"""Durable local LIFE Patch admission journal and safe command broker."""
from __future__ import annotations

import base64
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
import fcntl
import json
import os
from pathlib import Path
import re
import stat
import threading
import tempfile
import time
import uuid

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .protocol import (
    CommandReceipt,
    DeviceMode,
    DeviceManifest,
    PatchAdmissionController,
    PatchCommand,
    TelemetryEnvelope,
    decode_envelope,
    decode_manifest,
    ProtocolViolation,
    SAFE_COMMANDS,
)
from .protocol_v3 import ManifestV3, TelemetryEnvelopeV3, validate_manifest_binding, _utc, _iso


DEFAULT_JOURNAL = os.path.expanduser("~/.livemore/patch-telemetry.jsonl")
_JOURNAL_AAD = b"livemore.life-patch.journal.v2"
# Journal bookkeeping, not fields of the hash-covered wire object. The repair
# tool must strip exactly the same set, so both read it from here.
JOURNAL_METADATA_FIELDS = frozenset({"admission", "admitted_at", "capability_hash",
                                     "evidence_references", "manifest", "received_at"})


class PatchJournalInvalid(ValueError):
    """A journal record the current protocol rejects; the operator can repair it."""

    code = "PATCH_JOURNAL_INVALID"

    def __init__(self, message: str, *, record_number: int | None = None,
                 record_count: int | None = None) -> None:
        super().__init__(message)
        self.record_number = record_number
        self.record_count = record_count


class LifePatchGateway:
    def __init__(self, journal_path: str | None = None):
        self.journal_path = Path(journal_path or os.environ.get("LIVEMORE_PATCH_JOURNAL", DEFAULT_JOURNAL))
        self.device_path = self.journal_path.with_suffix(".devices.json")
        self.command_path = self.journal_path.with_suffix(".commands.jsonl")
        self.lock_path = self.journal_path.with_suffix(".lock")
        self._lock = threading.RLock()
        self._transaction_depth = 0
        self._lock_timeout_seconds = 5.0
        self._admission = PatchAdmissionController()
        self._clock_watermarks: dict[str, dict] = {}
        self._retired_clock_sessions: dict[str, set[str]] = {}
        self._replay_offset = 0
        self._replay_identity: tuple[int, int] | None = None
        from ..security import patch_storage_key
        self._storage_key = patch_storage_key(create=False)
        self._manifests: dict[str, DeviceManifest | ManifestV3] = {}
        with self.transaction():
            pass

    def _load_manifests(self) -> dict[str, DeviceManifest | ManifestV3]:
        try:
            with self._open_store(self.device_path) as stream:
                raw = json.load(stream)
        except FileNotFoundError:
            return {}
        except (OSError, ValueError, TypeError):
            raise ValueError("patch manifest store cannot be loaded safely") from None
        if not isinstance(raw, dict):
            raise ValueError("patch manifest store must be an object")
        try:
            result = {key: decode_manifest(value) for key, value in raw.items()}
        except (ValueError, TypeError):
            raise ValueError("patch manifest store contains an unsupported record") from None
        if any(key != manifest.device_id for key, manifest in result.items()):
            raise ValueError("patch manifest store identity mismatch")
        return result

    def _seed_replay_state(self) -> None:
        """Refresh only appended bytes while the shared journal lock is held."""
        try:
            with self._open_store(self.journal_path) as stream:
                metadata = os.fstat(stream.fileno())
                identity = (metadata.st_dev, metadata.st_ino)
                if ((self._replay_identity is not None and identity != self._replay_identity)
                        or metadata.st_size < self._replay_offset):
                    raise ValueError("patch journal was replaced or truncated; operator repair is required")
                stream.seek(self._replay_offset)
                records = self._read_records(stream)
                position = stream.tell()
        except FileNotFoundError:
            if self._replay_identity is not None:
                raise ValueError("patch journal disappeared; operator repair is required") from None
            return
        except OSError:
            raise ValueError("patch journal cannot be read safely") from None
        # Validate the entire unread tail before publishing any in-memory state.
        metadata_fields = JOURNAL_METADATA_FIELDS
        envelopes = []
        for offset, record in enumerate(records, start=1):
            try:
                envelopes.append(decode_envelope({key: value for key, value in record.items()
                                                  if key not in metadata_fields}))
            except (KeyError, TypeError, ValueError) as error:
                # Fail closed, but name the record and the rule it breaks. The
                # reason is a protocol rule, never journal payload: a record
                # written under an earlier protocol can be rejected by a later
                # one, and the operator needs to know which line to repair.
                raise PatchJournalInvalid(
                    f"patch journal record {offset} of {len(records)} is invalid under the current "
                    f"protocol ({type(error).__name__}: {error}). Run "
                    "'livemore patch-journal quarantine' to set aside only the invalid records; "
                    "the journal is never rewritten automatically.",
                    record_number=offset, record_count=len(records)) from None
        for envelope in envelopes:
            if envelope.sequence > self._admission.last_sequence(envelope.device_id):
                self._admission.seed_sequence(envelope.device_id, envelope.sequence)
                if isinstance(envelope, TelemetryEnvelopeV3):
                    packet = envelope.to_dict()
                    self._commit_clock(envelope.device_id, {
                        **packet["clock"], "acquisition_end": packet["acquisition_end"],
                    })
        self._replay_identity, self._replay_offset = identity, position

    def _commit_clock(self, device_id: str, clock: dict) -> None:
        previous = self._clock_watermarks.get(device_id)
        if previous and previous["session_id"] != clock["session_id"]:
            self._retired_clock_sessions.setdefault(device_id, set()).add(previous["session_id"])
        self._clock_watermarks[device_id] = clock

    def register(self, manifest: DeviceManifest | ManifestV3) -> DeviceManifest | ManifestV3:
        with self.transaction():
            previous = self._manifests.get(manifest.device_id)
            if previous and (previous.capability_hash != manifest.capability_hash
                             or previous.mode is not manifest.mode):
                raise ValueError("device capability change requires a new device identity")
            self.device_path.parent.mkdir(parents=True, exist_ok=True)
            os.chmod(self.device_path.parent, 0o700)
            updated = {**self._manifests, manifest.device_id: manifest}
            payload = {key: value.to_dict() for key, value in sorted(updated.items())}
            descriptor, temp_name = tempfile.mkstemp(
                prefix=self.device_path.name + ".", suffix=".tmp", dir=self.device_path.parent,
            )
            try:
                with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
                    stream.write(json.dumps(payload, sort_keys=True, indent=2))
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(temp_name, self.device_path)
            finally:
                if os.path.exists(temp_name):
                    os.unlink(temp_name)
            os.chmod(self.device_path, 0o600)
            self._manifests = updated
        return manifest

    def manifest(self, device_id: str) -> DeviceManifest | ManifestV3 | None:
        with self.transaction():
            return self._manifests.get(device_id)

    def admit(
        self,
        envelope: TelemetryEnvelope | TelemetryEnvelopeV3,
        *,
        evidence_references: tuple[dict, ...] = (),
        received_at: datetime | None = None,
        require_encrypted: bool = False,
    ) -> dict:
        if type(require_encrypted) is not bool:
            raise ValueError("patch encryption requirement must be a boolean")
        with self.transaction():
            manifest = self.manifest(envelope.device_id)
            if manifest is None:
                raise ValueError("device must be registered before telemetry admission")
            if (manifest.mode is not DeviceMode.VIRTUAL or require_encrypted) and self._storage_key is None:
                raise ValueError(
                    "real-human patch telemetry requires LIVEMORE_PATCH_STORAGE_KEY encrypted storage"
                )
            clock = None
            receipt = None
            if isinstance(envelope, TelemetryEnvelopeV3):
                if not isinstance(manifest, ManifestV3):
                    raise ProtocolViolation("manifest and telemetry protocol versions differ")
                validate_manifest_binding(manifest, envelope)
                packet = envelope.to_dict()
                receipt = _utc(received_at if received_at is not None else self._admission._now(), "received_at")
                if envelope.captured_at > receipt:
                    raise ProtocolViolation("v3 acquisition time is later than actual receipt")
                clock = {**packet["clock"], "acquisition_end": packet["acquisition_end"]}
                previous_clock = self._clock_watermarks.get(envelope.device_id)
                if clock["session_id"] in self._retired_clock_sessions.get(envelope.device_id, set()):
                    raise ProtocolViolation("retired acquisition clock session cannot be reused")
                if previous_clock and (_utc(packet["acquisition_start"], "acquisition_start")
                                       < _utc(previous_clock["acquisition_end"], "acquisition_end")):
                    raise ProtocolViolation("acquisition windows overlap or were reordered across clock sessions")
                if previous_clock and previous_clock["session_id"] == clock["session_id"]:
                    elapsed = clock["monotonic_start_s"] - previous_clock["monotonic_end_s"]
                    utc_elapsed = (_utc(packet["acquisition_start"], "acquisition_start")
                                   - _utc(previous_clock["acquisition_end"], "acquisition_end")).total_seconds()
                    uncertainty = clock["utc_uncertainty_s"] + previous_clock["utc_uncertainty_s"]
                    if elapsed < 0 or abs(utc_elapsed - elapsed) > uncertainty + 1e-6:
                        raise ProtocolViolation("acquisition clock reset, overlap or UTC mapping discontinuity")
            # Validate with a disposable controller. A failed disk append must not
            # consume the durable sequence or poison retries in this process.
            candidate = PatchAdmissionController(
                now=self._admission._now, maximum_age=self._admission._maximum_age,
            )
            candidate.seed_sequence(envelope.device_id, self._admission.last_sequence(envelope.device_id))
            admitted = candidate.admit(manifest, envelope)
            record = {
                **admitted.to_dict(),
                "admission": "accepted",
                "admitted_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                "capability_hash": manifest.capability_hash,
                "evidence_references": list(evidence_references),
            }
            if isinstance(manifest, ManifestV3):
                record["manifest"] = manifest.to_dict()
                # The envelope includes this hash. Integration also binds it in
                # the LIFE admission signature, never trusting a caller manifest.
                record["manifest_hash"] = manifest.capability_hash
                record["received_at"] = _iso(receipt)
            self._append(
                self.journal_path, record,
                encrypt=manifest.mode is not DeviceMode.VIRTUAL or require_encrypted,
            )
            self._admission.seed_sequence(envelope.device_id, envelope.sequence)
            if clock is not None:
                self._commit_clock(envelope.device_id, clock)
        return record

    def resolve_receipt(self, envelope_id: str, payload_hash: str) -> dict | None:
        """Read an exact durable receipt without replaying or changing its clock.

        Rare uncertain-admission recovery scans with bounded memory. Continuous
        delivery uses its direct receipt/cursor, not this journal scan per tick.
        Existing journal AAD and every wire byte remain unchanged.
        """
        if (type(envelope_id) is not str or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}", envelope_id) is None
                or type(payload_hash) is not str or re.fullmatch(r"[0-9a-f]{64}", payload_hash) is None):
            raise ValueError("exact patch receipt identity is invalid")
        with self.transaction():
            found = None
            try:
                with self._open_store(self.journal_path) as stream:
                    while True:
                        line = stream.readline(2 * 1024 * 1024 + 1)
                        if not line:
                            break
                        if len(line) > 2 * 1024 * 1024 or not line.endswith(b"\n"):
                            raise ValueError()
                        raw = json.loads(line)
                        if not isinstance(raw, dict):
                            raise ValueError()
                        record = self._decrypt(raw)
                        if record.get("envelope_id") != envelope_id:
                            continue
                        if record.get("envelope_hash") != payload_hash or found is not None:
                            raise ValueError()
                        metadata = {"admission", "admitted_at", "capability_hash", "evidence_references", "manifest", "received_at"}
                        decoded = decode_envelope({key: value for key, value in record.items() if key not in metadata})
                        if decoded.envelope_hash != payload_hash or record.get("admission") != "accepted":
                            raise ValueError()
                        found = record
                return found
            except FileNotFoundError:
                return None
            except (OSError, ValueError, TypeError, KeyError, UnicodeError, InvalidTag):
                raise ValueError("exact patch receipt cannot be resolved safely") from None

    def telemetry(self, *, subject_id: str = "", limit: int = 100) -> list[dict]:
        with self.transaction():
            records = self._read_jsonl(self.journal_path)
            if subject_id:
                records = [row for row in records if row.get("subject_id") == subject_id]
            return records[-max(1, min(int(limit), 500)):]

    def latest(self, subject_id: str = "") -> dict | None:
        rows = self.telemetry(subject_id=subject_id, limit=1)
        return rows[-1] if rows else None

    def next_sequence(self, device_id: str) -> int:
        with self.transaction():
            return self._admission.last_sequence(device_id) + 1

    @contextmanager
    def transaction(self):
        """Serialize cooperating local POSIX writers; nested calls retain one lock.

        The lock belongs to the transaction, not the gateway lifetime. A second
        instance/process refreshes durable state before making any decision.
        This is not a distributed/network-filesystem coordination mechanism.
        """
        with self._lock:
            if self._transaction_depth:
                yield
                return
            with self._journal_lock():
                self._manifests = self._load_manifests()
                self._seed_replay_state()
                self._transaction_depth = 1
                try:
                    yield
                finally:
                    self._transaction_depth = 0

    @contextmanager
    def _journal_lock(self):
        try:
            self.lock_path.parent.mkdir(parents=True, exist_ok=True)
            os.chmod(self.lock_path.parent, 0o700)
            flags = os.O_RDWR | os.O_CREAT | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK
            descriptor = os.open(self.lock_path, flags, 0o600)
        except OSError:
            raise ValueError("patch journal lock cannot be opened safely") from None
        locked = False
        try:
            try:
                metadata = os.fstat(descriptor)
                if (not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1
                        or metadata.st_uid != os.getuid()):
                    raise ValueError("patch journal lock is unsafe")
                os.fchmod(descriptor, 0o600)
            except OSError:
                raise ValueError("patch journal lock cannot be checked safely") from None
            deadline = time.monotonic() + self._lock_timeout_seconds
            while True:
                try:
                    fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    locked = True
                    break
                except BlockingIOError:
                    if time.monotonic() >= deadline:
                        raise ValueError("patch journal is busy; retry the request") from None
                    time.sleep(0.01)
                except OSError:
                    raise ValueError("patch journal lock cannot be acquired safely") from None
            yield
        finally:
            try:
                if locked:
                    fcntl.flock(descriptor, fcntl.LOCK_UN)
            except OSError:
                raise ValueError("patch journal lock could not be released safely") from None
            finally:
                os.close(descriptor)

    def issue_command(
        self,
        *,
        device_id: str,
        command: str,
        parameters: dict,
        expires_in_seconds: int = 300,
        command_id: str = "",
    ) -> PatchCommand:
        with self.transaction():
            if not device_id.strip():
                raise ValueError("device ID is required")
            manifest = self.manifest(device_id)
            if manifest is None:
                raise ValueError("device must be registered before commands are issued")
            if command not in SAFE_COMMANDS:
                raise ProtocolViolation("command is outside the LIFE Patch safety allowlist")
            if (isinstance(manifest, ManifestV3)
                    and command not in manifest.safe_commands):
                raise ValueError("command is outside registered device capabilities")
            now = datetime.now(timezone.utc)
            item = PatchCommand(
                command_id=command_id or f"command-{uuid.uuid4().hex}",
                device_id=device_id,
                command=command,
                parameters=parameters,
                issued_at=now,
                expires_at=now + timedelta(seconds=max(1, min(expires_in_seconds, 3600))),
            )
            if isinstance(manifest, ManifestV3):
                capabilities = manifest.capabilities
                if command == "request_burst" and any(
                    channel not in {capability["channel"] for capability in capabilities}
                    for channel in item.parameters["channels"]
                ):
                    raise ProtocolViolation("burst channels exceed registered device capabilities")
                if command == "start_chemistry_session" and any(
                    analyte not in {capability["signal"] for capability in capabilities
                                    if capability["channel"] == "chem"}
                    for analyte in item.parameters["analytes"]
                ):
                    raise ProtocolViolation("chemistry analytes exceed registered device capabilities")
            if command_id:
                existing = next(
                    (row for row in self._read_jsonl(self.command_path)
                     if row.get("record_type") == "command" and row.get("command_id") == command_id),
                    None,
                )
                if existing is not None:
                    restored = PatchCommand.from_dict(existing)
                    if (restored.device_id != device_id or restored.command != command
                            or dict(restored.parameters) != parameters):
                        raise ValueError("command ID is already bound to a different request")
                    return restored
            self._append(self.command_path, {"record_type": "command", **item.to_dict()})
            return item

    def record_receipt(self, receipt: CommandReceipt) -> CommandReceipt:
        with self.transaction():
            command = next(
                (row for row in self._read_jsonl(self.command_path)
                 if row.get("record_type") == "command" and row.get("command_id") == receipt.command_id),
                None,
            )
            if command is None or command.get("device_id") != receipt.device_id:
                raise ValueError("command receipt does not match an issued command")
            self._append(self.command_path, {"record_type": "receipt", **receipt.to_dict()})
            return receipt

    def commands(self, *, device_id: str = "", limit: int = 100) -> list[dict]:
        with self.transaction():
            records = self._read_jsonl(self.command_path)
            if device_id:
                records = [row for row in records if row.get("device_id") == device_id]
            return records[-max(1, min(int(limit), 500)):]

    def _append(self, path: Path, record: dict, *, encrypt: bool = False) -> None:
        with self._lock:
            path.parent.mkdir(parents=True, exist_ok=True)
            os.chmod(path.parent, 0o700)
            stored = self._encrypt(record) if encrypt else record
            encoded = json.dumps(stored, sort_keys=True, separators=(",", ":"), allow_nan=False)
            with self._open_store(path, append=True) as stream:
                stream.write((encoded + "\n").encode("utf-8"))
                stream.flush()
                os.fsync(stream.fileno())

    @contextmanager
    def _open_store(self, path: Path, *, append: bool = False):
        """Reject final-component aliases that could bypass the shared lock."""
        flags = os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK
        flags |= (os.O_WRONLY | os.O_CREAT | os.O_APPEND) if append else os.O_RDONLY
        try:
            descriptor = os.open(path, flags, 0o600)
        except FileNotFoundError:
            raise
        except OSError:
            raise ValueError("patch journal store cannot be opened safely") from None
        try:
            metadata = os.fstat(descriptor)
            if (not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1
                    or metadata.st_uid != os.getuid()):
                raise ValueError("patch journal store is unsafe")
            stream = os.fdopen(descriptor, "ab" if append else "rb")
        except BaseException:
            os.close(descriptor)
            raise
        with stream:
            yield stream

    def _encrypt(self, record: dict) -> dict:
        if self._storage_key is None:
            raise ValueError("encrypted patch journal requires LIVEMORE_PATCH_STORAGE_KEY")
        nonce = os.urandom(12)
        plaintext = json.dumps(
            record, sort_keys=True, separators=(",", ":"), allow_nan=False,
        ).encode("utf-8")
        ciphertext = AESGCM(self._storage_key).encrypt(nonce, plaintext, _JOURNAL_AAD)
        return {
            "_livemore_encrypted": "AES-256-GCM",
            "nonce": base64.urlsafe_b64encode(nonce).decode("ascii"),
            "ciphertext": base64.urlsafe_b64encode(ciphertext).decode("ascii"),
        }

    def _decrypt(self, record: dict) -> dict:
        if record.get("_livemore_encrypted") != "AES-256-GCM":
            return record
        if self._storage_key is None:
            raise ValueError("encrypted patch journal requires LIVEMORE_PATCH_STORAGE_KEY")
        nonce = base64.urlsafe_b64decode(str(record["nonce"]).encode("ascii"))
        ciphertext = base64.urlsafe_b64decode(str(record["ciphertext"]).encode("ascii"))
        plaintext = AESGCM(self._storage_key).decrypt(nonce, ciphertext, _JOURNAL_AAD)
        value = json.loads(plaintext)
        if not isinstance(value, dict):
            raise ValueError("decrypted patch journal record must be an object")
        return value

    def _read_jsonl(self, path: Path) -> list[dict]:
        try:
            with self._open_store(path) as stream:
                return self._read_records(stream)
        except FileNotFoundError:
            return []
        except OSError:
            raise ValueError("patch journal cannot be read safely") from None

    def _read_records(self, stream) -> list[dict]:
        records: list[dict] = []
        try:
            for line in stream:
                if not line.endswith(b"\n"):
                    raise ValueError
                value = json.loads(line)
                if not isinstance(value, dict):
                    raise ValueError
                records.append(self._decrypt(value))
        except (ValueError, TypeError, KeyError, UnicodeError, InvalidTag):
            raise ValueError("patch journal contains an unreadable or incomplete record; operator repair is required") from None
        return records
