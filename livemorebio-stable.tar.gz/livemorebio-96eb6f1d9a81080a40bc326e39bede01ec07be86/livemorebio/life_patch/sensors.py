"""
livemorebio.life_patch.sensors
==============================
Software contract for the corrected LIFE Patch B0 EVT target sensor suite.
The physical patch is a separate hardware program (BOM/PCB/build guide) and is
NOT manufactured; this module encodes the signal schema each channel emits so
that real patch data and LIFE System synthetic-model data share one contract.

IMPORTANT — "claim classes" are a property of the PHYSICAL INSTRUMENT, describing
how much to trust a *real measured* reading. They apply only to measured-real
data arriving from hardware; they are NOT attached to LIFE System synthetic-model
streams, which are mechanistic ground truth. The meaningful distinction inside
the system is data ORIGIN (synthetic-model vs measured-real), not sensor trust.

Instrument claim classes (for measured-real data only):
  direct    — measured signal (ECG rhythm/HR, IMU motion, skin temp)
  estimated — instrument-derived, quality-gated (SpO2, PTT-based BP trend)
  session   — per-session electrochemistry, not continuous (sweat chemistry)
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List

CLAIM_DIRECT = "direct"
CLAIM_ESTIMATED = "estimated"
CLAIM_SESSION = "session"


@dataclass(frozen=True)
class SensorChannel:
    id: str
    device: str
    signals: List[str]
    sample_hz: float
    claim: str


CHANNELS = [
    SensorChannel("ecg",  "MAX30003 (18-bit ΔΣ)",       ["ecg_mv", "hr_bpm", "hrv_ms", "rhythm"],            512.0, CLAIM_DIRECT),
    SensorChannel("ppg",  "MAX86141 (3-λ optical, SPI)", ["ppg_au", "hr_bpm", "spo2_pct", "ptt_ms"],          100.0, CLAIM_ESTIMATED),
    SensorChannel("chem", "AD5940 (potentiostat/EIS)",   ["glucose_mgdl", "sodium_mM", "potassium_mM", "lactate_mM"], 0.1, CLAIM_SESSION),
    SensorChannel("imu",  "BMI270 + BMM150 (9-DoF)",     ["accel_g", "steps", "activity"],                     50.0, CLAIM_DIRECT),
    SensorChannel("temp", "MAX30208 (±0.1 °C)",          ["skin_temp_c"],                                       1.0, CLAIM_DIRECT),
]

# signal -> claim. A signal (e.g. hr_bpm) may appear on several channels with
# different claims; resolve to the STRONGEST available (ECG HR is direct even
# though PPG HR is only estimated).
_PRIORITY = {CLAIM_DIRECT: 3, CLAIM_ESTIMATED: 2, CLAIM_SESSION: 1}
CLAIM_OF = {}
for _ch in CHANNELS:
    for _sig in _ch.signals:
        if _sig not in CLAIM_OF or _PRIORITY[_ch.claim] > _PRIORITY[CLAIM_OF[_sig]]:
            CLAIM_OF[_sig] = _ch.claim
CHANNEL_OF = {sig: ch.id for ch in CHANNELS for sig in ch.signals}


def channel_summary() -> list:
    return [dict(id=c.id, device=c.device, signals=c.signals,
                 sample_hz=c.sample_hz, claim=c.claim) for c in CHANNELS]
