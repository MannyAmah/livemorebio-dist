"""Set aside only the journal records the current protocol rejects.

A journal written under an earlier protocol can contain records a later one
refuses. The gateway fails closed on the whole file, which is correct and also
leaves the operator with nothing but a blunt ``mv``: that discards every valid
record to escape one bad one. This module keeps the valid records.

Two properties matter more than convenience here:

* **Stored bytes are never re-encoded.** A kept record is copied verbatim, and a
  quarantined one is preserved as its original line text. Records may be
  AES-GCM sealed over a fixed AAD, so a re-serialized object is not the same
  record; nothing here decrypts into the sidecar.
* **The reason is a protocol rule, never payload.** The sidecar and the report
  carry the rule a record broke and its position, never its decrypted content.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import json
import os
from pathlib import Path
import stat
import time
from typing import Any

from .gateway import JOURNAL_METADATA_FIELDS, decode_envelope

REPORT_SCHEMA = "livemore.patch-journal-repair.v1"
QUARANTINE_SCHEMA = "livemore.patch-journal-quarantined-record.v1"
_MAX_LINE_BYTES = 2 * 1024 * 1024
_LOCK_TIMEOUT_SECONDS = 5.0


class JournalRepairError(ValueError):
    """The journal cannot be inspected or repaired safely."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _check_private_regular_file(descriptor: int) -> None:
    metadata = os.fstat(descriptor)
    if (not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1
            or metadata.st_uid != os.getuid()):
        raise JournalRepairError("patch journal store is unsafe")


@contextmanager
def _journal_lock(journal_path: Path):
    """Take the same exclusive lock the gateway takes, so no writer races us."""
    lock_path = journal_path.with_suffix(".lock")
    try:
        # Only a directory this tool creates gets its mode set. Chmodding one the
        # operator already has would fail on any parent they do not own, and
        # report a lock problem for what is really a path problem.
        if not lock_path.parent.exists():
            lock_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            os.chmod(lock_path.parent, 0o700)
        descriptor = os.open(lock_path, os.O_RDWR | os.O_CREAT | os.O_CLOEXEC
                             | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    except OSError:
        raise JournalRepairError("patch journal lock cannot be opened safely") from None
    locked = False
    try:
        _check_private_regular_file(descriptor)
        deadline = time.monotonic() + _LOCK_TIMEOUT_SECONDS
        while True:
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                locked = True
                break
            except OSError:
                if time.monotonic() >= deadline:
                    raise JournalRepairError(
                        "patch journal is locked by another process; stop the LIFE service "
                        "with 'livemore stop' before repairing the journal") from None
                time.sleep(0.05)
        yield
    finally:
        if locked:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
        os.close(descriptor)


def _read_lines(journal_path: Path) -> list[bytes]:
    try:
        descriptor = os.open(journal_path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    except FileNotFoundError:
        raise JournalRepairError(f"patch journal does not exist: {journal_path}") from None
    except OSError:
        raise JournalRepairError("patch journal cannot be opened safely") from None
    with os.fdopen(descriptor, "rb") as stream:
        _check_private_regular_file(stream.fileno())
        lines: list[bytes] = []
        while True:
            line = stream.readline(_MAX_LINE_BYTES + 1)
            if not line:
                return lines
            if len(line) > _MAX_LINE_BYTES or not line.endswith(b"\n"):
                raise JournalRepairError(
                    f"patch journal record {len(lines) + 1} is truncated or oversized; "
                    "this is a damaged file, not a protocol mismatch, and is not repaired here")
            lines.append(line)


def _storage_key():
    from ..security import patch_storage_key

    return patch_storage_key(create=False)


def _decrypt(record: dict[str, Any], key: bytes | None) -> dict[str, Any]:
    if record.get("_livemore_encrypted") != "AES-256-GCM":
        return record
    if key is None:
        raise ValueError("record is sealed and LIVEMORE_PATCH_STORAGE_KEY is not set")
    import base64

    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    from .gateway import _JOURNAL_AAD

    nonce = base64.urlsafe_b64decode(str(record["nonce"]).encode("ascii"))
    ciphertext = base64.urlsafe_b64decode(str(record["ciphertext"]).encode("ascii"))
    value = json.loads(AESGCM(key).decrypt(nonce, ciphertext, _JOURNAL_AAD))
    if not isinstance(value, dict):
        raise ValueError("decrypted record is not an object")
    return value


def _classify(line: bytes, key: bytes | None) -> tuple[bool, str | None]:
    """Decide one record exactly as the gateway's replay does. Reason is a rule."""
    try:
        stored = json.loads(line)
        if not isinstance(stored, dict):
            raise ValueError("record is not an object")
        record = _decrypt(stored, key)
        decode_envelope({key_: value for key_, value in record.items()
                         if key_ not in JOURNAL_METADATA_FIELDS})
    except Exception as error:  # noqa: BLE001 - every failure is a rejected record
        return False, f"{type(error).__name__}: {error}"
    return True, None


def _require_journal(path: Path) -> None:
    """Decide a missing journal before taking a lock, so the message is the real one."""
    if not path.exists():
        raise JournalRepairError(f"patch journal does not exist: {path}")


def inspect_journal(journal_path: str | os.PathLike[str]) -> dict[str, Any]:
    """Read-only: report which records the current protocol accepts."""
    path = Path(journal_path).expanduser()
    _require_journal(path)
    key = _storage_key()
    with _journal_lock(path):
        lines = _read_lines(path)
    invalid = []
    for number, line in enumerate(lines, start=1):
        valid, reason = _classify(line, key)
        if not valid:
            invalid.append({"record_number": number, "reason": reason})
    return {"schema": REPORT_SCHEMA, "journal": str(path), "inspected_at": _now(),
            "total_records": len(lines), "valid_records": len(lines) - len(invalid),
            "invalid_records": invalid, "repaired": False}


def _atomic_replace(path: Path, lines: list[bytes]) -> None:
    """Write the kept records verbatim, then replace in one rename."""
    temporary = path.with_name(path.name + ".repair-tmp")
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o600)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            for line in lines:
                stream.write(line)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    parent = os.open(path.parent, os.O_RDONLY | os.O_CLOEXEC)
    try:
        os.fsync(parent)
    finally:
        os.close(parent)


def quarantine_journal(journal_path: str | os.PathLike[str], *,
                       apply: bool = False) -> dict[str, Any]:
    """Move only the rejected records to a sidecar and keep the rest replayable.

    Without ``apply`` this changes nothing and reports what it would do.
    """
    path = Path(journal_path).expanduser()
    _require_journal(path)
    sidecar = path.with_name(path.name + ".quarantine.jsonl")
    key = _storage_key()
    with _journal_lock(path):
        lines = _read_lines(path)
        kept, removed = [], []
        for number, line in enumerate(lines, start=1):
            valid, reason = _classify(line, key)
            if valid:
                kept.append(line)
            else:
                removed.append({"record_number": number, "reason": reason, "line": line})
        report = {"schema": REPORT_SCHEMA, "journal": str(path), "inspected_at": _now(),
                  "total_records": len(lines), "valid_records": len(kept),
                  "invalid_records": [{"record_number": item["record_number"],
                                       "reason": item["reason"]} for item in removed],
                  "quarantine_file": str(sidecar) if removed else None,
                  "repaired": False}
        if not removed or not apply:
            return report
        # Append, never truncate: an earlier repair's records stay where they are.
        descriptor = os.open(sidecar, os.O_WRONLY | os.O_CREAT | os.O_APPEND
                             | os.O_CLOEXEC | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, "wb") as stream:
            _check_private_regular_file(stream.fileno())
            for item in removed:
                entry = {"schema": QUARANTINE_SCHEMA, "quarantined_at": _now(),
                         "source_journal": str(path), "source_record_number": item["record_number"],
                         "reason_code": "PATCH_JOURNAL_INVALID", "reason": item["reason"],
                         # The original line verbatim: sealed records stay sealed.
                         "record_line": item["line"].decode("utf-8", errors="surrogateescape")}
                stream.write((json.dumps(entry, sort_keys=True, separators=(",", ":"),
                                         allow_nan=False) + "\n").encode("utf-8",
                                                                         errors="surrogateescape"))
            stream.flush()
            os.fsync(stream.fileno())
        _atomic_replace(path, kept)
        report["repaired"] = True
        report["inspected_at"] = _now()
        return report
