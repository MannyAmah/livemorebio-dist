"""Private encrypted LIFE consumer state; one exact pending wire record per session."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import hmac
from pathlib import Path
import sqlite3
from typing import Any
import uuid

from ..aegle.execution_contract import ExecutionError, digest, encoded, text
from ..aegle.execution_store import (ExecutionStore, _AUDIT_OUTCOME_RESERVE,
                                    _TRANSITION_RESERVE, _execution_id, project_control_revision, utc_now)

_BINDING_FIELDS = {"execution_id", "source_snapshot_hash", "source_generation", "selection",
                   "engine_contract_id", "device_id", "manifest_hash", "peer_process"}
_CHANGES = {"state", "failure_code", "pending", "receipt", "last_frame", "last_frame_hash",
            "last_admitted", "last_forwarded", "last_generated_at", "last_captured_at",
            "native_time", "producer", "lease_bound", "authorship", "last_acknowledged_at"}
_STATES = {"waiting_for_engine", "streaming", "paused", "blocked", "interrupted", "stopped", "completed"}


class VirtualSessionStore(ExecutionStore):
    """Separate typed DB; inherited audit reservations include all session bytes.

    The quota covers encrypted payloads, not SQLite filesystem page overhead.
    No virtual session stores caller-selected trajectory arrays or plain PHI.
    """
    def __init__(self, path: Path, *, key: bytes, quota_bytes: int = 256 * 1024 * 1024) -> None:
        super().__init__(path, key=key, quota_bytes=quota_bytes, store_kind="virtual-session")
        with self._connection() as connection:
            connection.execute("CREATE TABLE IF NOT EXISTS virtual_sessions ("
                "id TEXT PRIMARY KEY, request_key TEXT UNIQUE NOT NULL, revision INTEGER NOT NULL,"
                "active_device_key TEXT UNIQUE, payload BLOB NOT NULL)")

    def _totals(self, connection: sqlite3.Connection) -> tuple[int, int, dict[str, int]]:
        total, count, usage = super()._totals(connection)
        own_bytes, own_count = connection.execute("SELECT COALESCE(SUM(length(payload)),0),COUNT(*) FROM virtual_sessions").fetchone()
        return total + own_bytes, count + own_count, usage

    def _key(self, prefix: str, value: str) -> str:
        return hmac.new(self.key, (prefix + ":" + value).encode(), hashlib.sha256).hexdigest()

    def _session(self, connection: sqlite3.Connection, session_id: str) -> dict[str, Any]:
        row = connection.execute("SELECT revision,active_device_key,payload FROM virtual_sessions WHERE id=?",
                                 (_execution_id(session_id),)).fetchone()
        if row is None:
            raise ExecutionError()
        record = self._decrypt(row[2], "virtual-session:" + session_id)
        expected_active = None if record["state"] in {"stopped", "completed"} else self._key("device", record["binding"]["device_id"])
        if record["session_id"] != session_id or record["revision"] != row[0] or row[1] != expected_active:
            raise ExecutionError("EXECUTION_STORAGE")
        return project_control_revision(record)

    def create(self, binding: dict[str, Any], *, idempotency_key: str) -> dict[str, Any]:
        if not isinstance(binding, dict) or set(binding) != _BINDING_FIELDS or not isinstance(binding["selection"], dict):
            raise ExecutionError()
        encoded(binding, 16384)
        _execution_id(binding["execution_id"])
        for field in _BINDING_FIELDS - {"selection"}:
            text(binding[field], 256)
        key = self._key("request", text(idempotency_key, 128))
        request_hash = digest(binding)
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute("SELECT id FROM virtual_sessions WHERE request_key=?", (key,)).fetchone()
            if existing is not None:
                record = self._session(connection, existing[0])
                if record["request_hash"] != request_hash:
                    raise ExecutionError("EXECUTION_CONFLICT")
                return record
            device_key = self._key("device", binding["device_id"])
            if connection.execute("SELECT 1 FROM virtual_sessions WHERE active_device_key=?", (device_key,)).fetchone():
                raise ExecutionError("EXECUTION_OWNED")
            session_id = uuid.uuid4().hex
            record = {"schema": "livemore.virtual-execution-session.v1", "session_id": session_id,
                "revision": 1, "control_revision": 1, "request_hash": request_hash, "binding": deepcopy(binding),
                "state": "waiting_for_engine", "failure_code": None, "pending": None, "receipt": None,
                "last_frame": 0, "last_frame_hash": None, "last_admitted": 0, "last_forwarded": 0,
                "last_generated_at": None, "last_captured_at": None, "last_acknowledged_at": None,
                "native_time": None, "authorship": "NOT_EXECUTED", "producer": None, "lease_bound": False,
                "created_at": utc_now(), "updated_at": utc_now()}
            payload = self._encrypt(record, "virtual-session:" + session_id)
            total, count, usage = self._totals(connection)
            reserved = (count + 1) * _TRANSITION_RESERVE + usage["pending"] * _AUDIT_OUTCOME_RESERVE
            if count >= 256 or total + len(payload) + reserved > self.quota_bytes:
                raise ExecutionError("EXECUTION_QUOTA")
            connection.execute("INSERT INTO virtual_sessions VALUES (?,?,?,?,?)", (session_id, key, 1, device_key, payload))
            connection.execute("COMMIT")
            return deepcopy(record)

    def get(self, session_id: str) -> dict[str, Any]:
        with self._connection() as connection:
            return deepcopy(self._session(connection, session_id))

    def update(self, session_id: str, *, expected_revision: int, changes: dict[str, Any],
               control_event: bool = False) -> dict[str, Any]:
        if (type(expected_revision) is not int or type(control_event) is not bool
                or not isinstance(changes, dict) or not changes or set(changes) - _CHANGES
                or ("state" in changes and changes["state"] not in _STATES)):
            raise ExecutionError()
        encoded(changes, 262144)
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            current = self._session(connection, session_id)
            if current["revision"] != expected_revision:
                raise ExecutionError("EXECUTION_CONFLICT")
            old_size = connection.execute("SELECT length(payload) FROM virtual_sessions WHERE id=?", (session_id,)).fetchone()[0]
            def phase(state: str) -> str:
                return "active" if state in {"waiting_for_engine", "streaming"} else state
            if (control_event or ("state" in changes and phase(changes["state"]) != phase(current["state"]))
                    or any(key in changes and changes[key] != current.get(key)
                           for key in ("failure_code", "lease_bound"))):
                current["control_revision"] += 1
            current.update(deepcopy(changes))
            current.update(revision=current["revision"] + 1, updated_at=utc_now())
            payload = self._encrypt(current, "virtual-session:" + session_id)
            total, count, usage = self._totals(connection)
            reserved = usage["pending"] * _AUDIT_OUTCOME_RESERVE
            if any(field in changes for field in {"pending", "receipt", "producer"}):
                reserved += count * _TRANSITION_RESERVE
            if total - old_size + len(payload) + reserved > self.quota_bytes:
                raise ExecutionError("EXECUTION_QUOTA")
            active = None if current["state"] in {"stopped", "completed"} else self._key("device", current["binding"]["device_id"])
            connection.execute("UPDATE virtual_sessions SET revision=?,active_device_key=?,payload=? WHERE id=?",
                               (current["revision"], active, payload, session_id))
            connection.execute("COMMIT")
            return deepcopy(current)
