"""LIFE Patch shared physical/virtual software contract."""

from .protocol import (
    DeviceManifest,
    DeviceMode,
    PatchAdmissionController,
    PatchCommand,
    PhysicalPatchGateway,
    ProtocolViolation,
    TelemetryEnvelope,
    TelemetryMeasurement,
    VirtualLifePatch,
    envelope_snapshot_key,
    manifest_for,
    pseudonymous_subject_id,
)

__all__ = [
    "DeviceManifest",
    "DeviceMode",
    "PatchAdmissionController",
    "PatchCommand",
    "PhysicalPatchGateway",
    "ProtocolViolation",
    "TelemetryEnvelope",
    "TelemetryMeasurement",
    "VirtualLifePatch",
    "envelope_snapshot_key",
    "manifest_for",
    "pseudonymous_subject_id",
]
