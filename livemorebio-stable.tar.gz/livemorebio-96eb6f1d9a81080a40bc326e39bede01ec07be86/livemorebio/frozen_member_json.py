"""Fixed frozen-member response admission, sharing the original strict validators."""
from __future__ import annotations

import json
from typing import Any


def parse_frozen_member_response(raw: str | bytes | bytearray) -> dict[str, Any]:
    """Keep the response-only 16 MiB budget; SDK owns frozen identity validation."""
    # Late imports preserve either module import order and the exact error class.
    # The decode envelope is deliberately separate: refactoring the fingerprinted
    # generic parser would invalidate already admitted Atlas artifacts again.
    from .strict_json import (
        StrictJSONError, _check_depth, _unique_object, _finite_float,
        _safe_integer, _reject_constant,
    )

    if not isinstance(raw, (str, bytes, bytearray)):
        raise StrictJSONError("JSON requires text")
    try:
        encoded = raw.encode("utf-8") if isinstance(raw, str) else raw
        if len(encoded) > 16 * 1024 * 1024:
            raise StrictJSONError("JSON input exceeds byte limit")
        text = encoded.decode("utf-8")
    except UnicodeError as error:
        raise StrictJSONError("JSON requires valid UTF-8 text") from error
    _check_depth(text)
    try:
        result = json.loads(text, object_pairs_hook=_unique_object, parse_float=_finite_float,
                            parse_int=_safe_integer, parse_constant=_reject_constant)
    except StrictJSONError:
        raise
    except (ValueError, RecursionError, OverflowError) as error:
        raise StrictJSONError("JSON requires valid syntax") from error
    if not isinstance(result, dict):
        raise StrictJSONError("JSON requires an object")
    return result
