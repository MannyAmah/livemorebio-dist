"""livemore — launch and orchestrate the LivemoreBio infrastructure.

The three infrastructures run as independent services that discover each other
through a shared registry and cooperate in real time:

    livemore start all        # or: livemore start LIFE / Aegle / Cendos
    livemore status
    livemore open             # open the Aegle console
    livemore stop all
"""
from __future__ import annotations
import argparse, json, os, secrets, signal, subprocess, sys, time, urllib.request
from . import registry as R

SERVICES = {
    "LIFE":   ("livemorebio.life_system.service", 8851),
    "Aegle":  ("livemorebio.aegle.server", 8850),
    "Cendos": ("livemorebio.cendos.service", 8852),
}
PYTHON = sys.executable
TOKEN_ENV = "LIVEMORE_API_TOKEN"
TOKEN_FILE = os.path.join(R.REG_DIR, "api-token")


def ensure_api_token() -> str:
    """Load or create the loopback mutation token with owner-only permissions."""
    configured = os.environ.get(TOKEN_ENV, "").strip()
    if configured:
        return configured
    os.makedirs(R.REG_DIR, mode=0o700, exist_ok=True)
    try:
        with open(TOKEN_FILE, encoding="utf-8") as token_file:
            token = token_file.read().strip()
    except FileNotFoundError:
        token = ""
    if not token:
        candidate = secrets.token_urlsafe(32)
        temporary = f"{TOKEN_FILE}.{os.getpid()}.{secrets.token_hex(8)}.tmp"
        descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as token_file:
                token_file.write(candidate + "\n")
                token_file.flush()
                os.fsync(token_file.fileno())
            try:
                os.link(temporary, TOKEN_FILE)
            except FileExistsError:
                pass
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        with open(TOKEN_FILE, encoding="utf-8") as token_file:
            token = token_file.read().strip()
        if not token:
            raise RuntimeError("mutation token initialization did not produce a token")
    os.chmod(TOKEN_FILE, 0o600)
    os.environ[TOKEN_ENV] = token
    return token


def _health(port):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=1.5) as r:
            return json.load(r)
    except Exception:
        return None


def _wait_for_services(names, *, timeout: float = 15.0) -> list[str]:
    """Wait for two consecutive health responses or the deadline."""
    pending = [name for name in names if name in SERVICES]
    consecutive = {name: 0 for name in pending}
    deadline = time.monotonic() + timeout
    while pending:
        for name in list(pending):
            if _health(SERVICES[name][1]):
                consecutive[name] += 1
                if consecutive[name] >= 2:
                    pending.remove(name)
            else:
                consecutive[name] = 0
        if not pending or time.monotonic() >= deadline:
            break
        time.sleep(0.2)
    return pending


def _wait_for_stopped_services(names, *, timeout: float = 10.0) -> list[str]:
    """Wait until terminated service ports stop answering health checks."""
    pending = [name for name in names if name in SERVICES]
    deadline = time.monotonic() + timeout
    while pending:
        pending = [name for name in pending if _health(SERVICES[name][1])]
        if not pending or time.monotonic() >= deadline:
            break
        time.sleep(0.2)
    return pending



# Stores that have no internal default: without explicit configuration the
# continuous LIFE/Aegle execution loop and virtual Patch sessions refuse to
# start. The launcher configures them under the private data directory, which
# is explicit configuration by the operator's own launcher, not a fallback to
# another running instance. An operator-supplied value is never overridden.
_LAUNCH_STORES = {
    "LIVEMORE_EXECUTION_STORE": ("executions", "state.sqlite3"),
    "LIVEMORE_VIRTUAL_EXECUTION_STORE": ("virtual-executions", "state.sqlite3"),
    "LIVEMORE_PATCH_JOURNAL": (None, "patch-telemetry.jsonl"),
}


def _service_environment() -> dict:
    """Child environment with private store paths and the local service URL."""
    environment = dict(os.environ)
    for name, (directory, filename) in _LAUNCH_STORES.items():
        if environment.get(name, "").strip():
            continue
        parent = os.path.join(R.REG_DIR, directory) if directory else R.REG_DIR
        os.makedirs(parent, mode=0o700, exist_ok=True)
        environment[name] = os.path.join(parent, filename)
    environment.setdefault("LIVEMORE_AEGLE_URL", f"http://127.0.0.1:{SERVICES['Aegle'][1]}")
    # Service output is redirected to a file, where Python block-buffers it. An
    # operator reading <name>.log during an incident would otherwise find it empty.
    environment["PYTHONUNBUFFERED"] = "1"
    return environment



def _service_command(module: str) -> list:
    """Run the service under its real module name, not as ``__main__``.

    ``python -m package.module`` executes the file as ``__main__``. Routers that
    do ``from . import server`` then import a second copy of the module, with a
    separate selected-state, model-source authority and execution manager. The
    two copies disagree, which surfaced as an unavailable model on the execution
    routes while the rest of the console reported the twin as ready.
    """
    return [PYTHON, "-B", "-c",
            "from importlib import import_module; import_module(%r).main()" % module]


def start(names):
    ensure_api_token()
    from .security import ensure_patch_security_keys
    ensure_patch_security_keys()
    names = list(SERVICES) if (not names or names == ["all"]) else names
    os.makedirs(R.REG_DIR, exist_ok=True)
    environment = _service_environment()
    expected = []
    for name in names:
        if name not in SERVICES:
            print(f"  unknown service: {name}"); continue
        expected.append(name)
        mod, port = SERVICES[name]
        if _health(port):
            print(f"  {name:7} already running on :{port}"); continue
        logf = os.path.join(R.REG_DIR, f"{name}.log")
        # A caller may be standing in an older checkout. Children must use the
        # same package as this launcher, without mutating a verified release's bytecode.
        package_root = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        with open(logf, "w") as log_file:
            p = subprocess.Popen(_service_command(mod), stdout=log_file,
                                 stderr=subprocess.STDOUT, start_new_session=True,
                                 cwd=package_root, env=environment)
        R.register(name, port, p.pid)
        print(f"  starting {name:7} on :{port}  (pid {p.pid}, log {logf})")
    pending = _wait_for_services(expected)
    status()
    if pending:
        print(f"  startup timeout: {', '.join(pending)} did not report healthy within 15 seconds")


def stop(names):
    reg = R.registry()
    names = list(reg) if (not names or names == ["all"]) else names
    stopped = []
    for name in names:
        info = reg.get(name)
        if not info:
            print(f"  {name} not in registry"); continue
        try:
            os.killpg(os.getpgid(info["pid"]), signal.SIGTERM)
        except Exception:
            try:
                os.kill(info["pid"], signal.SIGTERM)
            except Exception:
                pass
        R.unregister(name)
        stopped.append(name)
        print(f"  stopping {name}")
    pending = _wait_for_stopped_services(stopped)
    if pending:
        print(f"  shutdown timeout: {', '.join(pending)} still reported healthy after 10 seconds")
    for name in stopped:
        if name not in pending:
            print(f"  stopped {name}")


def patch_journal(action, journal, *, apply=False, as_json=False):
    """Report, and on request repair, a journal the current protocol rejects."""
    from .life_patch import journal_repair

    explicit = bool(journal or os.environ.get("LIVEMORE_PATCH_JOURNAL"))
    path = journal or os.environ.get("LIVEMORE_PATCH_JOURNAL") or os.path.join(R.REG_DIR, "patch-telemetry.jsonl")
    if not explicit and not os.path.exists(path):
        # No journal at the default path is a fresh install, not a fault. A path
        # the operator named is different: a typo must not report "healthy".
        message = "no patch journal yet; it is created when the first telemetry record is admitted."
        print(json.dumps({"schema": "livemore.patch-journal-repair.v1", "journal": str(path),
                          "total_records": 0, "valid_records": 0, "invalid_records": [],
                          "repaired": False, "note": message}, indent=2, sort_keys=True)
              if as_json else f"\n  patch journal  {path}\n  {message}\n")
        return 0
    try:
        report = (journal_repair.inspect_journal(path) if action == "verify"
                  else journal_repair.quarantine_journal(path, apply=apply))
    except journal_repair.JournalRepairError as error:
        if as_json:
            print(json.dumps({"schema": journal_repair.REPORT_SCHEMA, "journal": str(path),
                              "error": str(error)}, indent=2, sort_keys=True))
        else:
            print(f"  {error}")
        return 2
    if as_json:
        print(json.dumps(report, indent=2, sort_keys=True))
        return 1 if report["invalid_records"] and not report["repaired"] else 0
    invalid = report["invalid_records"]
    print(f"\n  patch journal  {report['journal']}")
    print("  " + "-" * 52)
    print(f"  {report['total_records']} records · {report['valid_records']} valid · {len(invalid)} rejected")
    for item in invalid:
        print(f"    record {item['record_number']}: {item['reason']}")
    if not invalid:
        print("  every record is readable under the current protocol.")
    elif report["repaired"]:
        print(f"\n  set aside {len(invalid)} record(s); {report['valid_records']} remain replayable.")
        print(f"  quarantined records kept verbatim in {report['quarantine_file']}")
    elif action == "quarantine":
        print(f"\n  nothing was changed. Re-run with --apply to set aside {len(invalid)} record(s)")
        print(f"  into {report['quarantine_file']}, keeping the other {report['valid_records']}.")
    else:
        print("\n  run 'livemore patch-journal quarantine' to see what a repair would do.")
    print()
    return 1 if invalid and not report["repaired"] else 0


def status():
    print("\n  LivemoreBio infrastructure")
    print("  " + "-" * 52)
    for name, (mod, port) in SERVICES.items():
        h = _health(port)
        state = "\033[32m● up  \033[0m" if h else "\033[90m○ down\033[0m"
        extra = ""
        if h and name == "LIFE":
            extra = f"{h.get('diseases','?')} diseases · {h.get('variants','?')} risk loci"
        if h and name == "Aegle":
            extra = f"twin: {h.get('profile','')}"
        if h and name == "Cendos":
            extra = "in-silico assays ready"
        print(f"  {state} {name:7} :{port}   {extra}")
    reg = R.registry()
    print("  " + "-" * 52)
    print(f"  registry: {R.REG}  ({len(reg)} registered)\n")


def open_console():
    if not _health(8850):
        print("  Aegle is not running — `livemore start Aegle` first."); return
    import webbrowser
    webbrowser.open("http://127.0.0.1:8850")
    print("  opened http://127.0.0.1:8850")


def _compose(action):
    """Containerized mode: `livemore up` / `livemore down` wrap docker compose
    against the repo's docker-compose.yml (three services + shared state volume).
    Single-box dev mode (`livemore start/stop`) is unchanged."""
    import shutil, subprocess
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    compose_file = os.path.join(root, "docker-compose.yml")
    if not os.path.exists(compose_file):
        print(f"  docker-compose.yml not found at {compose_file}"); return 1
    if not shutil.which("docker"):
        print("  docker is not installed or not on PATH — use `livemore start` for single-box mode."); return 1
    if action == "up":
        ensure_api_token()
        from .security import ensure_patch_security_keys
        ensure_patch_security_keys()
    cmd = ["docker", "compose", "-f", compose_file]
    cmd += ["up", "-d", "--build"] if action == "up" else ["down"]
    print("  $ " + " ".join(cmd))
    rc = subprocess.call(cmd)
    if rc == 0 and action == "up":
        print("  LIFE     http://127.0.0.1:8851  (/docs for OpenAPI)")
        print("  Aegle    http://127.0.0.1:8850  (/docs for OpenAPI)")
        print("  Cendos   http://127.0.0.1:8852  (/docs for OpenAPI)")
    return rc


def main():
    # New command families validate raw tokens themselves. argparse's error
    # output otherwise echoes a private first option before REMAINDER captures it.
    if len(sys.argv) > 1 and sys.argv[1] == "atlas" and sys.argv[2:] not in (["--help"], ["-h"]):
        from .sdk import Platform
        from .atlas_commands import run_atlas_command, safe_atlas_error
        from .atlas_client import AtlasClientError
        try:
            run_atlas_command(Platform(mode="attach"), sys.argv[1:])
        except AtlasClientError as error:
            print(safe_atlas_error(error))
            raise SystemExit(1) from None
        return
    if len(sys.argv) > 1 and sys.argv[1] in {"execution", "patch"} and sys.argv[2:] not in (["--help"], ["-h"]):
        from .sdk import Platform
        from .execution_commands import run_continuous_command, safe_error
        from .execution_client import ContinuousClientError
        try:
            run_continuous_command(Platform(mode="attach"), sys.argv[1:])
        except ContinuousClientError as error:
            print(safe_error(error))
            raise SystemExit(1) from None
        return
    ap = argparse.ArgumentParser(prog="livemore", description="LivemoreBio infrastructure control")
    sub = ap.add_subparsers(dest="cmd")
    atlas = sub.add_parser("atlas", help="attached reference anatomy status and installation", description=(
        "Attached reference-only anatomy. atlas status [json=true]; "
        "atlas install bp3d-4.0-20130619-surface-core-v1 [json=true]. "
        "Uses the running Aegle service; does not start a server or experiment."))
    atlas.add_argument("arguments", nargs=argparse.REMAINDER)
    for family in ("execution", "patch"):
        command = sub.add_parser(family, help="attached continuous commands; see livemore attach → help")
        command.add_argument("arguments", nargs=argparse.REMAINDER)
    sp = sub.add_parser("start"); sp.add_argument("services", nargs="*")
    st = sub.add_parser("stop"); st.add_argument("services", nargs="*")
    sub.add_parser("status"); sub.add_parser("open")
    sub.add_parser("token", help="print the local mutation token for the console prompt")
    sub.add_parser("manifest", help="print whole-human system capability and maturity JSON")
    models = sub.add_parser("models", help="install or verify pinned reference metabolic assets")
    models.add_argument("action", choices=("catalog", "install", "status", "check"))
    models.add_argument("model_id", nargs="?", default="human-gem")
    ws = sub.add_parser("workspace", help="print the live multiscale Atlas projection")
    ws.add_argument("--full", action="store_true", help="print the complete projection JSON")
    sources = sub.add_parser("sources", help="query governed scientific source lifecycle and routing")
    sources.add_argument("--workflow")
    sources.add_argument("--collection")
    sources.add_argument("--lifecycle")
    sources.add_argument("--limit", type=int, default=50)
    sources.add_argument("--offset", type=int, default=0)
    sources.add_argument("--attach", action="store_true", help="query the running Aegle service")
    sources.add_argument("--full", action="store_true", help="print complete bounded JSON response")
    doc = sub.add_parser("doctor", help="fresh-machine readiness report (exit 1 when a required check fails)")
    doc.add_argument("--json", action="store_true"); doc.add_argument("--network", action="store_true")
    nb = sub.add_parser("notebook", help="Jupyter Lab workspace with the SDK pre-wired")
    nb.add_argument("--dir", help="notebook directory (default: <data dir>/notebooks)")
    nb.add_argument("--no-browser", action="store_true"); nb.add_argument("--port", type=int, default=8888)
    pg = sub.add_parser("programs", help="insulin and botanical programs: list, or run one non-interactively")
    pg.add_argument("action", choices=("list", "run"), nargs="?", default="list")
    pg.add_argument("program_id", nargs="?")
    pg.add_argument("--dose-mg", type=float); pg.add_argument("--cohort", type=int); pg.add_argument("--seed", type=int)
    pg.add_argument("--attach", action="store_true"); pg.add_argument("--json", action="store_true")
    pj = sub.add_parser("patch-journal", help="inspect or repair the local LIFE Patch telemetry journal")
    pj.add_argument("action", choices=("verify", "quarantine"), nargs="?", default="verify")
    pj.add_argument("--journal", help="journal path (default: $LIVEMORE_PATCH_JOURNAL or <data dir>/patch-telemetry.jsonl)")
    pj.add_argument("--apply", action="store_true",
                    help="quarantine only: actually set the invalid records aside (default: report and change nothing)")
    pj.add_argument("--json", action="store_true")
    sub.add_parser("up", help="containerized platform via docker compose")
    sub.add_parser("down", help="stop the containerized platform")
    sh = sub.add_parser("shell", help="interactive Livemore environment")
    sh.add_argument("--attach", action="store_true", help="drive the live running platform")
    sub.add_parser("attach", help="interactive shell attached to the live platform")
    rn = sub.add_parser("run", help="run a pipeline file of Livemore commands")
    rn.add_argument("pipeline"); rn.add_argument("--attach", action="store_true")
    a = ap.parse_args()
    from ._platform import POSIX, CONTAINER_GUIDANCE
    if not POSIX and a.cmd not in (None, "doctor"):
        print("  LivemoreBio requires POSIX file protections for local PHI-like state.")
        print("  " + CONTAINER_GUIDANCE)
        print("  Run `livemore doctor` for the full report.")
        raise SystemExit(2)
    if a.cmd == "start":
        start(a.services)
    elif a.cmd == "stop":
        stop(a.services)
    elif a.cmd == "open":
        open_console()
    elif a.cmd == "status":
        status()
    elif a.cmd == "patch-journal":
        raise SystemExit(patch_journal(a.action, a.journal, apply=a.apply, as_json=a.json))
    elif a.cmd == "manifest":
        from .foundation import whole_human_manifest
        print(json.dumps(whole_human_manifest(), indent=2, sort_keys=True))
    elif a.cmd == "models":
        from . import model_assets
        try:
            if a.action == "catalog":
                result = model_assets.catalog()
            elif a.action == "install":
                result = model_assets.install(a.model_id)
            else:
                result = model_assets.status(a.model_id)
            print(json.dumps(result, indent=2, sort_keys=True))
            if a.action == "check" and not result.get("available"):
                raise SystemExit(1)
        except model_assets.ModelAssetError as error:
            print(json.dumps({"available": False, "code": error.code, "error": str(error)}))
            raise SystemExit(1)
    elif a.cmd == "workspace":
        from .sdk import Platform
        workspace = Platform(mode="attach").workspace()
        if a.full:
            print(json.dumps(workspace, indent=2, sort_keys=True))
        else:
            systems = workspace["multiscale"]["systems"]
            executed = sum(
                item["execution_status"] in {"EXECUTED", "PARTIAL"} for item in systems
            )
            # A selected record without an admitted model binding has no active
            # execution. That is a reportable state, not an error.
            active = workspace["multiscale"]["active_execution"] or {}
            availability = workspace.get("model_availability") or {}
            summary = {
                "subject": workspace["multiscale"]["subject"],
                "contracts": len(systems),
                "executed_systems": executed,
                "patch": workspace["twin"]["patch"],
                "release_claim": workspace["release_claim"],
                "model_state": availability.get("state"),
                "model_reason": availability.get("reason_code"),
                "selection_mode": availability.get("selection_mode"),
            }
            if active:
                summary.update({
                    "intervention": active.get("intervention"),
                    "active_nodes": len(active.get("nodes", [])),
                    "active_edges": len(active.get("edges", [])),
                })
            else:
                summary["active_execution"] = (
                    "none; the selected record has no admitted model binding, so no engine is executing")
            print(json.dumps(summary, indent=2, sort_keys=True))
    elif a.cmd == "sources":
        from .sdk import Platform
        report = Platform(mode="attach" if a.attach else "inprocess").scientific_sources(
            workflow=a.workflow,
            collection=a.collection,
            lifecycle=a.lifecycle,
            limit=a.limit,
            offset=a.offset,
        )
        if a.full:
            print(json.dumps(report, indent=2, sort_keys=True))
        else:
            print(json.dumps({
                "query": report["query"],
                "total": report["total"],
                "sources": [
                    {
                        "id": source["source_id"],
                        "name": source["name"],
                        "collection": source["collection"],
                        "lifecycle": source["lifecycle"],
                        "permitted_use": source["permitted_use"],
                    }
                    for source in report["sources"]
                ],
            }, indent=2, sort_keys=True))
    elif a.cmd == "doctor":
        from .doctor import main as doctor_main
        raise SystemExit(doctor_main((["--json"] if a.json else []) + (["--network"] if a.network else [])))
    elif a.cmd == "notebook":
        from .notebook import ensure_workspace
        directory = a.dir or os.path.join(R.REG_DIR, "notebooks")
        target = ensure_workspace(directory)
        print(f"  workspace notebook: {target}")
        command = [PYTHON, "-m", "jupyterlab", f"--notebook-dir={directory}", f"--port={a.port}", str(target)]
        if a.no_browser:
            command.append("--no-browser")
        try:
            os.execv(PYTHON, command)
        except OSError as error:
            print(f"  cannot start Jupyter Lab ({error}); install notebook extras: pip install -e '.[notebooks]'")
            raise SystemExit(1)
    elif a.cmd == "programs":
        from .sdk import Platform
        from .shell import run_command
        P = Platform(mode="attach" if a.attach else "inprocess")
        if a.action == "list" or not a.program_id:
            run_command(P, "program list")
        else:
            extra = " ".join(f"{k}={v}" for k, v in (("dose_mg", a.dose_mg), ("cohort", a.cohort), ("seed", a.seed)) if v is not None)
            verb = "insulin run" if a.program_id == "insulin" else f"program run {a.program_id}"
            run_command(P, f"{verb} {extra} {'json=true' if a.json else ''}")
    elif a.cmd == "token":
        print(ensure_api_token())
    elif a.cmd in ("up", "down"):
        sys.exit(_compose(a.cmd) or 0)
    elif a.cmd == "shell":
        from .shell import run_shell
        run_shell(mode="attach" if a.attach else "inprocess")
    elif a.cmd == "attach":
        from .shell import run_shell
        run_shell(mode="attach")
    elif a.cmd == "run":
        from .shell import Platform, run_pipeline
        from .execution_commands import safe_error
        from .execution_client import ContinuousClientError
        from .atlas_commands import safe_atlas_error
        from .atlas_client import AtlasClientError
        try:
            run_pipeline(Platform(mode="attach" if a.attach else "inprocess"), a.pipeline)
        except AtlasClientError as error:
            print(safe_atlas_error(error))
            raise SystemExit(1) from None
        except ContinuousClientError as error:
            print(safe_error(error))
            raise SystemExit(1) from None
    else:
        from .shell import run_shell    # bare `livemore` opens the interactive environment
        run_shell(mode="inprocess")


if __name__ == "__main__":
    main()
