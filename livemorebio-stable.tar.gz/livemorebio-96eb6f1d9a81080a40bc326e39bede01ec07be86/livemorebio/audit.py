"""livemorebio.audit — signed, reproducible audit records for platform pipelines.

Every SDK / CLI operation that produces a pharma-facing result emits a tamper-evident
audit record: a canonical hash of (action, inputs, seed, engine provenance, outputs) plus
an HMAC-SHA256 signature under a local key, timestamped and appended to an append-only log.
Anyone with the key can verify that a record — or a whole report — reproduces exactly.

Stdlib only (hashlib + hmac): no external crypto dependency, so it runs anywhere the
platform runs. This is what backs the "deterministic, reproducible, signed, mechanistically
grounded" auditability story for pharma.
"""
from __future__ import annotations
import fcntl
import hashlib
import hmac
import json
import os
import sys
import stat
import tempfile
import time
import uuid

from . import registry
LM_DIR = registry.REG_DIR
KEY_PATH = os.path.join(LM_DIR, "livemore-sign-hmac.key")
LOG_PATH = os.path.join(LM_DIR, "pipeline-audit.jsonl")
_LOCK_TIMEOUT_SECONDS = 1.0
_STRICT_RECORD_BYTES = 16 * 1024


class AuditError(RuntimeError):
    """Public callers must not expose local paths or underlying error text."""

    code = "AUDIT_UNAVAILABLE"

    def __init__(self) -> None:
        super().__init__("Audit recording is unavailable.")


def _regular_fd(path: str, flags: int) -> int:
    # NONBLOCK also prevents a substituted FIFO from hanging the first read.
    fd = os.open(path, flags | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise AuditError()
    except BaseException:
        os.close(fd)
        raise
    return fd


def _sync_directory(path: str) -> None:
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _ensure_directory() -> None:
    existed = os.path.isdir(LM_DIR)
    os.makedirs(LM_DIR, mode=0o700, exist_ok=True)
    if not existed:
        _sync_directory(os.path.dirname(os.path.abspath(LM_DIR)))


def _read_key() -> bytes:
    fd = _regular_fd(KEY_PATH, os.O_RDONLY)
    with os.fdopen(fd, "rb") as stream:
        material = stream.read().strip()
    # Preserve the old accepted normalization and longer HMAC key material.
    if len(material) < 32:
        raise AuditError()
    return material


def _key(*, create: bool = True) -> bytes:
    """Read without replacement; publish only a complete absent key atomically."""
    try:
        try:
            return _read_key()
        except FileNotFoundError:
            if not create:
                raise AuditError() from None
        try:
            log_fd = _regular_fd(LOG_PATH, os.O_RDONLY)
        except FileNotFoundError:
            pass
        else:
            try:
                if os.fstat(log_fd).st_size:
                    raise AuditError()
            finally:
                os.close(log_fd)
        for _ in range(32):
            material = os.urandom(32)
            if len(material) == 32 and material.strip() == material:
                break
        else:
            raise AuditError()
        _ensure_directory()
        fd, temporary = tempfile.mkstemp(prefix=".audit-key-", dir=LM_DIR)
        try:
            try:
                if os.write(fd, material) != len(material):
                    raise AuditError()
                os.fsync(fd)
            finally:
                os.close(fd)
            try:
                os.link(temporary, KEY_PATH)
            except FileExistsError:
                pass  # A complete concurrent winner is read below, never replaced.
        finally:
            os.unlink(temporary)
        _sync_directory(LM_DIR)
        return _read_key()
    except Exception:
        raise AuditError() from None


def _append(encoded: bytes) -> None:
    """Cooperating old/new callers serialize on the same log, not a new ledger."""
    _ensure_directory()
    fd = _regular_fd(LOG_PATH, os.O_RDWR | os.O_APPEND | os.O_CREAT)
    try:
        deadline = time.monotonic() + _LOCK_TIMEOUT_SECONDS
        while True:
            if time.monotonic() >= deadline:
                raise AuditError()
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                if time.monotonic() >= deadline:
                    raise AuditError()
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise AuditError() from None
                time.sleep(min(.01, max(0, deadline - time.monotonic())))
        key_stat, log_stat = os.stat(KEY_PATH, follow_symlinks=False), os.fstat(fd)
        if (key_stat.st_dev, key_stat.st_ino) == (log_stat.st_dev, log_stat.st_ino):
            raise AuditError()
        if os.fstat(fd).st_size:
            os.lseek(fd, -1, os.SEEK_END)
            if os.read(fd, 1) != b"\n":
                raise AuditError()
        # Never retry an uncertain partial append or edit its retained bytes.
        if os.write(fd, encoded) != len(encoded):
            raise AuditError()
        os.fsync(fd)
        _sync_directory(LM_DIR)
    finally:
        os.close(fd)  # Also releases the cooperative lock, even on failure.


def _strict_snapshot(action: str, inputs: dict, outputs: dict, prov: dict) -> dict:
    if (type(action) is not str or not 1 <= len(action) <= 96
            or any(not 32 <= ord(char) <= 126 for char in action)
            or any(type(value) is not dict for value in (inputs, outputs, prov))):
        raise AuditError()
    count = 0

    def check(value: object, depth: int = 0) -> None:
        nonlocal count
        count += 1
        if depth > 4 or count > 256:
            raise AuditError()
        if type(value) is dict:
            for key, child in value.items():
                if type(key) is not str:
                    raise AuditError()
                check(child, depth + 1)
        elif type(value) is list:
            for child in value:
                check(child, depth + 1)
        elif value is not None and type(value) not in (str, int, float, bool):
            raise AuditError()

    for value in (inputs, outputs, prov):
        check(value)
    metadata = {"action": action, "inputs": inputs, "outputs": outputs, "provenance": prov}
    encoded = json.dumps(metadata, allow_nan=False).encode("utf-8")
    if len(encoded) > _STRICT_RECORD_BYTES:
        raise AuditError()
    return json.loads(encoded)  # Detach before key/file I/O and signing.


def canonical(obj) -> str:
    """Deterministic JSON serialization (sorted keys, no whitespace) for hashing/signing."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str)


def content_hash(payload: dict) -> str:
    return hashlib.sha256(canonical(payload).encode("utf-8")).hexdigest()


def sign(payload: dict) -> str:
    return hmac.new(_key(), canonical(payload).encode("utf-8"), hashlib.sha256).hexdigest()


def provenance() -> dict:
    """Engine/environment stamp recorded with every run for reproducibility."""
    prov = {"platform": "LivemoreBio", "python": sys.version.split()[0]}
    try:
        import subprocess
        prov["git"] = subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=os.path.dirname(os.path.abspath(__file__)),
            stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        pass
    return prov


def result_fingerprint(action: str, inputs: dict, outputs: dict, prov: dict) -> str:
    """Timestamp-independent SHA-256 of the science: same action+inputs+outputs+provenance
    -> same fingerprint, regardless of when it ran. This is the reproducibility guarantee."""
    return content_hash({"action": action, "inputs": inputs, "outputs": outputs, "provenance": prov})


def record(action: str, inputs: dict, outputs: dict, prov: dict = None, log: bool = True,
           *, strict: bool = False) -> dict:
    """Opt-in durable recording; legacy append errors remain best-effort."""
    try:
        return _record(action, inputs, outputs, prov, log, strict=strict)
    except Exception:
        if strict is True:
            raise AuditError() from None
        raise


def _record(action: str, inputs: dict, outputs: dict, prov: dict, log: bool,
            *, strict: bool) -> dict:
    """Build a signed audit record and (by default) append it to the audit log.

    result_sha256 is the reproducible fingerprint (no timestamp); hmac_sha256 signs the
    fingerprint bound to the run timestamp, giving tamper-evidence + timestamping."""
    if type(strict) is not bool:
        raise AuditError()
    if strict:
        try:
            if log is not True:
                raise AuditError()
            metadata = _strict_snapshot(action, inputs, outputs, prov)
            action, inputs, outputs, prov = (metadata[key] for key in
                                             ("action", "inputs", "outputs", "provenance"))
        except Exception:
            raise AuditError() from None
    else:
        prov = prov if prov is not None else provenance()
    result_sha = result_fingerprint(action, inputs, outputs, prov)
    ts = round(time.time(), 3)
    rec = {"id": str(uuid.uuid4()), "alg": "HMAC-SHA256", "result_sha256": result_sha,
           "hmac_sha256": "0" * 64, "ts": ts,
           "action": action, "inputs": inputs, "outputs": outputs, "provenance": prov}
    if strict:
        try:
            if len((json.dumps(rec, allow_nan=False) + "\n").encode("utf-8")) > _STRICT_RECORD_BYTES:
                raise AuditError()
        except Exception:
            raise AuditError() from None
    rec["hmac_sha256"] = sign({"result_sha256": result_sha, "ts": ts})
    if log:
        try:
            _append((json.dumps(rec) + "\n").encode("utf-8"))
        except Exception:
            if strict:
                raise AuditError() from None
    return rec


def verify(rec: dict) -> bool:
    """Verify a record: the result matches its fingerprint AND the signature is valid."""
    try:
        result_sha = result_fingerprint(rec["action"], rec["inputs"], rec["outputs"], rec["provenance"])
        return (hmac.compare_digest(result_sha, rec.get("result_sha256", "")) and
                hmac.compare_digest(hmac.new(_key(create=False),
                                    canonical({"result_sha256": result_sha, "ts": rec.get("ts")}).encode("utf-8"),
                                    hashlib.sha256).hexdigest(),
                                    rec.get("hmac_sha256", "")))
    except Exception:
        return False
