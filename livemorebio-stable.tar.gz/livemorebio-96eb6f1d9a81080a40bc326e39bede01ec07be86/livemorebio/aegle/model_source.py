"""Single-process ownership of model inputs, separate from observation freshness.

Lock order is this authority before the execution manager. Manager callbacks must
never reacquire this authority or perform network requests while holding its lock.
"""
from __future__ import annotations

from collections.abc import Callable, Iterator
from contextlib import AbstractContextManager, contextmanager, nullcontext
from copy import deepcopy
from threading import RLock, get_ident
from typing import TypeVar
from uuid import uuid4

from .execution import DENY_ALL

T = TypeVar("T")


class SourceGenerationConflict(ValueError):
    code = "MODEL_SOURCE_CHANGED"

    def __init__(self) -> None:
        super().__init__("Model source changed; refresh and select it again")


class SourceSelectionUnconfirmed(ValueError):
    code = "SELECTION_COMMIT_UNCONFIRMED"

    def __init__(self) -> None:
        super().__init__("Selection storage outcome is unconfirmed; reconcile before numerical use.")


class ModelSourceAuthority:
    """Serialize source capture/change without treating measurements as model input."""

    def __init__(self, invalidate: Callable[[str, str], None] | None = None, *,
                 fence: Callable[[str | object], None] | None = None,
                 fence_guard: Callable[[], AbstractContextManager] | None = None) -> None:
        self._lock = RLock()
        self._generation = uuid4().hex
        self._invalidate = invalidate
        self._fence = fence
        self._fence_guard = fence_guard or nullcontext
        self._commit_owner = None
        self._commit_depth = 0

    @property
    def permitted_generation(self) -> str | object:
        """Internal manager-construction fence, including explicit deny-all."""
        with self._lock:
            return self._generation

    @property
    def generation(self) -> str:
        with self._lock:
            if self._generation is DENY_ALL:
                raise SourceSelectionUnconfirmed()
            return self._generation

    def capture(self, read: Callable[[], T], *, expected_generation: str | None = None) -> T:
        with self._lock:
            if self._generation is DENY_ALL:
                raise SourceSelectionUnconfirmed()
            if expected_generation is not None and expected_generation != self._generation:
                raise SourceGenerationConflict()
            return deepcopy(read())

    @contextmanager
    def mutation(self, reason: str, *, before: Callable[[], None] | None = None) -> Iterator[None]:
        if self._fence is None:
            # Preserve the explicit standalone callback contract. Product
            # construction always supplies its assignment-only memory fence.
            with self._lock:
                if before is not None:
                    before()
                if self._invalidate is not None:
                    self._invalidate(self._generation, reason)
                self._generation = uuid4().hex
                yield
            return
        previous = None
        try:
            with self._lock:
                if before is not None:
                    before()
                with self.commit_guard():
                    previous = self.generation
                    self.install_generation(uuid4().hex)
                yield
        finally:
            if previous is not None and self._invalidate is not None:
                self._invalidate(previous, reason)

    @contextmanager
    def commit_guard(self) -> Iterator[None]:
        """Hold authority → manager creation → manager across a short commit."""
        with self._lock:
            with self._fence_guard():
                self._commit_owner = get_ident()
                self._commit_depth += 1
                try:
                    yield
                finally:
                    self._commit_depth -= 1
                    if not self._commit_depth:
                        self._commit_owner = None

    def install_generation(self, generation: str | object) -> None:
        """Install precomputed authority after commit, or explicitly deny all."""
        if self._commit_owner != get_ident() or not self._commit_depth:
            raise RuntimeError("Source generation requires a coherent commit guard")
        if generation is not DENY_ALL and (type(generation) is not str or not generation.strip()):
            raise ValueError("Invalid source generation")
        if self._fence is not None:
            self._fence(generation)
        self._generation = generation

    @contextmanager
    def observation(self) -> Iterator[None]:
        with self._lock:
            yield

    def observe(self, attach: Callable[[], T]) -> T:
        with self.observation():
            return attach()
