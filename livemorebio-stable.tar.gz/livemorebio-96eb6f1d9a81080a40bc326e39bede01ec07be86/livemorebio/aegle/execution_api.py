"""One authenticated execution interface for browser, terminal and SDK clients."""
from __future__ import annotations

import asyncio
from copy import deepcopy
from collections.abc import Callable, Coroutine
import os
from pathlib import Path
import re
import threading
from typing import Any

from fastapi import APIRouter, Request
from fastapi.exception_handlers import http_exception_handler
from fastapi.responses import JSONResponse, Response
from fastapi.routing import APIRoute
from starlette.exceptions import HTTPException

from ..security import patch_storage_key, require_operator_auth
from ..strict_json import StrictJSONError, parse_json_object
from .execution_contract import CARDIAC, METABOLIC, ExecutionError, capture_source_payload, encoded, text
from .model_source import SourceGenerationConflict, SourceSelectionUnconfirmed
from .model_contexts import ModelContextError
import logging

_LOG = logging.getLogger("livemorebio.aegle.execution")

_creation_lock = threading.RLock()
_BODY_LIMIT = 16 * 1024
_PREPARE_FIELDS = {"engine_contract_id", "expected_source_generation", "expected_twin_id",
                   "expected_twin_version", "policy"}


class ExecutionRoute(APIRoute):
    def get_route_handler(self) -> Callable[[Request], Coroutine[Any, Any, Response]]:
        handler = super().get_route_handler()

        async def private(request: Request) -> Response:
            from ..build_info import build_identity

            try:
                require_operator_auth(request)
                response = await handler(request)
            except HTTPException as error:
                response = await http_exception_handler(request, error)
            response.headers["Cache-Control"] = "no-store"
            identity = build_identity()
            if identity["source_sha256"] is not None:
                response.headers["X-Livemore-Source-Sha256"] = identity["source_sha256"]
            response.headers["X-Livemore-Process-Instance"] = identity["process_instance"]
            return response

        return private


router = APIRouter(route_class=ExecutionRoute)


def _manager():
    from . import server
    from .execution import ExecutionManager
    from .execution_store import ExecutionStore

    with server._model_source_authority.observation(), _creation_lock:
        if server._execution_manager_instance is None:
            path = os.environ.get("LIVEMORE_EXECUTION_STORE", "").strip()
            if not path or not Path(path).is_absolute():
                raise ExecutionError("EXECUTION_UNAVAILABLE")
            try:
                key = patch_storage_key(create=False)
            except (OSError, RuntimeError, ValueError):
                raise ExecutionError("EXECUTION_UNAVAILABLE") from None
            if key is None:
                raise ExecutionError("EXECUTION_UNAVAILABLE")
            server._execution_manager_instance = ExecutionManager(
                ExecutionStore(Path(path), key=key),
                permitted_generation=server._model_source_authority.permitted_generation,
            )
        return server._execution_manager_instance


def shutdown_execution_manager() -> None:
    from . import server

    with _creation_lock:
        manager = server._execution_manager_instance
        if manager is not None:
            # Detach only after workers are closed; a concurrent source mutation
            # must not silently lose its invalidation callback during shutdown.
            manager.close()
            server._execution_manager_instance = None


def _check_runtime_identity() -> None:
    from ..build_info import build_identity, source_fingerprint

    current = source_fingerprint(Path(__file__).resolve().parents[1])
    if current is None or current != build_identity()["source_sha256"]:
        raise ExecutionError("EXECUTION_RESTART_REQUIRED")


def _source_selection() -> dict[str, Any]:
    """Caller holds the source-authority guard; preview is not a registry twin."""
    from . import server

    summary = server._state.get("subject")
    if not summary:
        raise ExecutionError("EXECUTION_SOURCE_REQUIRED")
    availability = server._model_availability()
    if availability["state"] != "READY":
        raise ModelContextError(availability["reason_code"])
    record = server._subject_registry().active_twin()
    if record is None or record.get("lifecycle") != "ACTIVE" or any(record.get(field) != summary.get(field) for field in
                             ("subject_id", "twin_id", "version", "source_class")):
        raise SourceGenerationConflict()
    from .model_contexts import model_availability
    retained = model_availability(record, source_generation=availability["source_generation"])
    if retained["state"] != "READY":
        raise ModelContextError(retained["reason_code"])
    return {"subject_id": record["subject_id"], "twin_id": record["twin_id"],
            "twin_version": record["version"], "cohort_id": None, "member_id": None,
            "run_id": None, "condition_id": "active-model-inputs", "stage": "prospective-execution",
            "source_data_class": record["source_class"]}


def _positive_version(value: Any) -> int:
    if type(value) is not int or not 1 <= value <= 1_000_000:
        raise ExecutionError()
    return value


def _control_guard(body: dict[str, Any], *, with_source: bool = False) -> dict[str, int]:
    """One explicit CAS domain; record revisions retain their legacy meaning."""
    source_fields = {"expected_source_generation"} if with_source else set()
    revision_fields = set(body) - source_fields
    if (revision_fields not in ({"expected_revision"}, {"expected_control_revision"})
            or not source_fields.issubset(body)):
        raise ExecutionError()
    field = next(iter(revision_fields))
    return {field: _positive_version(body[field])}


def _exact_fields(body: dict[str, Any], fields: set[str]) -> None:
    if set(body) != fields:
        raise ExecutionError()


async def _body(request: Request) -> dict[str, Any]:
    raw = bytearray()
    async for chunk in request.stream():
        if len(raw) + len(chunk) > _BODY_LIMIT:
            raise ExecutionError()
        raw.extend(chunk)
    try:
        result = parse_json_object(raw)
        encoded(result, _BODY_LIMIT)
        return result
    except StrictJSONError:
        raise ExecutionError() from None


def _failure(error: Exception, request_id: str | None = None) -> JSONResponse:
    code = error.code if isinstance(error, (ExecutionError, SourceGenerationConflict, ModelContextError, SourceSelectionUnconfirmed)) else "EXECUTION_STORAGE"
    status = 409 if isinstance(error, ModelContextError) or code in {"MODEL_SOURCE_CHANGED", "EXECUTION_CONFLICT", "EXECUTION_OWNED", "EXECUTION_SOURCE_REQUIRED"} else (
        422 if code == "EXECUTION_INVALID" else 503)
    messages = {"EXECUTION_UNAVAILABLE": "Continuous execution requires an explicitly configured private store and key.",
                "EXECUTION_RESTART_REQUIRED": "Source files changed after startup. Restart this build before preparing an execution.",
                "EXECUTION_SOURCE_REQUIRED": "Create and activate a registered twin before preparing an execution.",
                "MODEL_SOURCE_CHANGED": "Selected model source changed. Refresh and select it again."}
    headers = {"Cache-Control": "no-store"}
    if request_id is not None:
        headers["X-Livemore-Request-Id"] = request_id
    safe_message = str(error) if isinstance(error, (ModelContextError, SourceSelectionUnconfirmed)) else str(ExecutionError(code))
    return JSONResponse({"code": code, "error": messages.get(code, safe_message)},
                        status_code=status, headers=headers)


def _operate(action: str, operation: Callable[[Any], Any], *, execution_id: str | None = None,
             status: int = 200) -> JSONResponse:
    request_id = None
    manager = None
    try:
        if execution_id is not None and re.fullmatch(r"[0-9a-f]{32}", execution_id) is None:
            raise ExecutionError()
        manager = _manager()
        request_id = manager.store.begin_access(action, execution_id=execution_id)
        result = operation(manager)
    except Exception as error:
        typed = isinstance(error, (ExecutionError, SourceGenerationConflict, ModelContextError, SourceSelectionUnconfirmed))
        if not typed:
            # An untyped failure is reported to the caller as EXECUTION_STORAGE.
            # Without this record an operator sees "storage failed integrity
            # checks" for a fault that has nothing to do with storage. The log
            # carries the exception and traceback only, never request payload.
            _LOG.exception("unexpected failure in execution action %r", action)
        if request_id is not None:
            code = error.code if typed else "EXECUTION_STORAGE"
            try:
                manager.store.finish_access(request_id, code)
            except Exception:
                return _failure(ExecutionError("EXECUTION_STORAGE"), request_id)
        return _failure(error, request_id)
    try:
        manager.store.finish_access(request_id, "OK")
    except Exception:
        # The operation may have committed. Request identity and the preparation
        # idempotency key let callers inspect safely rather than fabricate a retry.
        return _failure(ExecutionError("EXECUTION_STORAGE"), request_id)
    return JSONResponse(result, status_code=status, headers={"Cache-Control": "no-store",
                        "X-Livemore-Request-Id": request_id})


def _prepare(manager, body: dict[str, Any], idempotency_key: str | None,
             parent_execution_id: str | None = None) -> dict[str, Any]:
    from . import server

    _exact_fields(body, _PREPARE_FIELDS | ({"expected_parent_revision"} if parent_execution_id else set()))
    contract = body["engine_contract_id"]
    if contract not in (METABOLIC, CARDIAC):
        raise ExecutionError()
    generation = text(body["expected_source_generation"])
    twin_id = text(body["expected_twin_id"])
    version = _positive_version(body["expected_twin_version"])
    key = text(idempotency_key, 128)
    _check_runtime_identity()

    def capture_and_admit():
        selection = _source_selection()
        if selection["twin_id"] != twin_id or selection["twin_version"] != version:
            raise SourceGenerationConflict()
        source = capture_source_payload(server._state["tw"], selection, generation, contract)
        if parent_execution_id is not None:
            return manager.fork_checkpoint(parent_execution_id, source, policy=body["policy"],
                idempotency_key=key, expected_parent_revision=_positive_version(body["expected_parent_revision"]))
        return manager.prepare(source, body["policy"], idempotency_key=key)

    return server._model_source_authority.capture(capture_and_admit, expected_generation=generation)


@router.get("/api/executions/capabilities")
def capabilities():
    from . import server

    def read(manager):
        def inspect():
            availability = server._model_availability()
            try:
                selected = _source_selection()
                reason = None
            except ModelContextError as error:
                selected, reason = None, error.code
                availability = {**availability, "state": "UNAVAILABLE", "reason_code": reason,
                                "selection_mode": "observations_only", "preparation_available": False}
            except ExecutionError as error:
                if error.code != "EXECUTION_SOURCE_REQUIRED":
                    raise
                selected, reason = None, error.code
            return {"preparation_available": selected is not None, "reason": reason,
                    "model_availability": availability,
                    "selection": selected, "source_generation": server._model_source_authority.generation,
                    "evidence_class": "MODELED", "independent_physical_validation": False,
                    "engine_contracts": [{"id": METABOLIC, "native_unit": "min", "maximum_native": 840.},
                                         {"id": CARDIAC, "native_unit": "ms", "maximum_native": 1_800_000.}],
                    "initialization": "Declared basal reference or explicitly linked full-state checkpoint; not present human wall-clock state."}
        return server._model_source_authority.capture(inspect)
    return _operate("capabilities", read)


@router.post("/api/executions")
async def prepare_execution(request: Request):
    try:
        body = await _body(request)
    except Exception as error:
        return _failure(error if isinstance(error, ExecutionError) else ExecutionError())
    return await asyncio.to_thread(_operate, "prepare", lambda manager: _prepare(manager, body,
        request.headers.get("Idempotency-Key")), status=201)


@router.get("/api/executions/{execution_id}")
def execution_status(execution_id: str):
    return _operate("status", lambda manager: manager.status(execution_id), execution_id=execution_id)


@router.get("/api/executions/{execution_id}/frames")
def execution_frames(execution_id: str, request: Request):
    def read(manager):
        query = request.query_params
        if set(query) - {"after_frame", "limit"} or any(len(query.getlist(key)) != 1 for key in query):
            raise ExecutionError()
        after, limit = query.get("after_frame", "0"), query.get("limit", "100")
        if not re.fullmatch(r"[0-9]{1,12}", after) or not re.fullmatch(r"[0-9]{1,3}", limit):
            raise ExecutionError()
        return manager.frames(execution_id, after_frame=int(after), limit=int(limit))
    return _operate("frames", read, execution_id=execution_id)


@router.post("/api/executions/{execution_id}/fork-checkpoint")
async def fork_execution(execution_id: str, request: Request):
    try:
        body = await _body(request)
    except Exception as error:
        return _failure(error if isinstance(error, ExecutionError) else ExecutionError())
    return await asyncio.to_thread(_operate, "fork_checkpoint", lambda manager: _prepare(manager, body,
        request.headers.get("Idempotency-Key"), execution_id), execution_id=execution_id, status=201)


@router.post("/api/executions/{execution_id}/consumer")
@router.post("/api/executions/{execution_id}/consumer/renew")
async def consumer_control(execution_id: str, request: Request):
    from . import server

    renew = request.url.path.endswith("/renew")
    try:
        body = await _body(request)
        _exact_fields(body, {"session_id", "source_snapshot_hash", "expected_source_generation"} |
                      (set() if renew else {"expected_revision"}))
        generation = text(body["expected_source_generation"])
        if not renew:
            _positive_version(body["expected_revision"])
    except Exception as error:
        return _failure(error if isinstance(error, ExecutionError) else ExecutionError())

    def apply(manager):
        _check_runtime_identity()
        def change():
            selection = _source_selection()
            state = manager.status(execution_id)
            if state["selection"] != selection:
                raise SourceGenerationConflict()
            options = {"expected_source_generation": generation}
            if not renew:
                options["expected_revision"] = body["expected_revision"]
            return getattr(manager, "renew_consumer" if renew else "bind_consumer")(
                execution_id, body["session_id"], body["source_snapshot_hash"], **options)
        return server._model_source_authority.capture(change, expected_generation=generation)
    return await asyncio.to_thread(_operate, "renew_consumer" if renew else "bind_consumer", apply,
                                   execution_id=execution_id)


@router.post("/api/execution-observations")
async def admit_observation(request: Request):
    from . import server
    from .execution_observations import admit_execution_observation
    from ..life_patch.protocol import ProtocolViolation

    try:
        body = await _body(request)
    except Exception as error:
        return _failure(error if isinstance(error, ExecutionError) else ExecutionError())

    def apply(manager):
        _check_runtime_identity()
        with server._model_source_authority.observation():
            selection = _source_selection()
            active = server._subject_registry().active_twin()
            try:
                return admit_execution_observation(manager, server._state["tw"], selection,
                    server._model_source_authority.generation, active.get("patch_bindings", []), body)
            except ProtocolViolation:
                raise ExecutionError() from None
    return await asyncio.to_thread(_operate, "admit_observation", apply)


@router.get("/api/executions/{execution_id}/observations")
def execution_observations(execution_id: str):
    from . import server

    def read(manager):
        with server._model_source_authority.observation():
            state = manager.status(execution_id)
            streams = [deepcopy(stream) for stream in getattr(server._state["tw"], "execution_observations", {}).values()
                       if stream["execution_id"] == execution_id
                       and stream["source_generation"] == server._model_source_authority.generation]
            return {"execution": state, "streams": streams,
                    "physical_observations_replaced": False, "model_parameters_updated": False}
    return _operate("observations", read, execution_id=execution_id)


@router.post("/api/executions/{execution_id}/{action}")
async def execution_control(execution_id: str, action: str, request: Request):
    from . import server

    try:
        if action not in {"start", "pause", "resume", "stop"}:
            raise ExecutionError()
        body = await _body(request)
        guard = _control_guard(body, with_source=True)
        generation = text(body["expected_source_generation"])
    except Exception as error:
        return _failure(error if isinstance(error, ExecutionError) else ExecutionError())

    def apply(manager):
        if action in {"start", "resume"}:
            _check_runtime_identity()
            server._model_source_authority.capture(lambda: None, expected_generation=generation)
        # Numerical initialization runs outside authority. A simultaneous source
        # mutation invalidates this tracked record and fences its late result.
        return getattr(manager, action)(execution_id, **guard,
                                        expected_source_generation=generation)
    return await asyncio.to_thread(_operate, action, apply, execution_id=execution_id)
