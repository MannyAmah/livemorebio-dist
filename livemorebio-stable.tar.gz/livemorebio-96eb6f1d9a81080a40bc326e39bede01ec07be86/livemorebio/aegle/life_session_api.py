"""Same-origin controls for the explicitly configured, source-checked LIFE peer."""
from __future__ import annotations

import asyncio
import os
import re
from typing import Any

from fastapi import APIRouter, Request

from .execution_api import ExecutionRoute, _body, _failure, _operate, _control_guard
from .execution_contract import ExecutionError, text
from ..build_info import build_identity
from ..life_patch.execution_source import ExecutionSourceClient
from ..security import TOKEN_ENV

router = APIRouter(route_class=ExecutionRoute)
_KNOWN_ERRORS = {"EXECUTION_INVALID", "EXECUTION_CONFLICT", "EXECUTION_OWNED", "EXECUTION_STORAGE",
                 "EXECUTION_QUOTA", "EXECUTION_SOLVER", "EXECUTION_CLOSED", "EXECUTION_UNAVAILABLE",
                 "EXECUTION_RESTART_REQUIRED"}


def _client() -> ExecutionSourceClient:
    base = os.environ.get("LIVEMORE_LIFE_URL", "").strip()
    token = os.environ.get(TOKEN_ENV, "").strip()
    if not base or not token:
        raise ExecutionError("EXECUTION_UNAVAILABLE")
    # Each explicit control can reach a restarted LIFE process. Its durable
    # session, revision and fixed Aegle producer binding govern recovery; the
    # proxy never renews a consumer or rewrites that binding on its own.
    return ExecutionSourceClient(base, token, build_identity()["source_sha256"])


def _forward(method: str, path: str, body: dict[str, Any] | None) -> dict[str, Any]:
    status, response = _client().request_response(method, path, body, accepted_statuses=(200, 409, 422, 503))
    if status != 200:
        code = response.get("code")
        raise ExecutionError(code if code in _KNOWN_ERRORS else "EXECUTION_UNAVAILABLE")
    return response


def _session(value: str) -> str:
    if re.fullmatch(r"[0-9a-f]{32}", value) is None:
        raise ExecutionError()
    return value


def _no_query(request: Request) -> None:
    if request.query_params:
        raise ExecutionError()


@router.get("/api/patch/virtual/sessions/capabilities")
async def capabilities(request: Request):
    try:
        _no_query(request)
    except ExecutionError as error:
        return _failure(error)
    return await asyncio.to_thread(_operate, "capabilities",
        lambda manager: _forward("GET", "/patch/virtual/sessions/capabilities", None))


@router.post("/api/patch/virtual/probe")
@router.post("/api/patch/virtual/sessions")
async def create(request: Request):
    probe = request.url.path.endswith("/probe")
    try:
        _no_query(request)
        body = await _body(request)
        expected = {"device_id"} if probe else {
            "execution_id", "source_snapshot_hash", "device_id", "expected_selection", "idempotency_key"}
        if set(body) != expected:
            raise ExecutionError()
        text(body["device_id"], 128)
        if not probe:
            _session(body["execution_id"])
            text(body["idempotency_key"], 128)
            if not isinstance(body["source_snapshot_hash"], str) or re.fullmatch(r"[0-9a-f]{64}", body["source_snapshot_hash"]) is None:
                raise ExecutionError()
    except Exception:
        return _failure(ExecutionError())
    path = "/patch/virtual/probe" if probe else "/patch/virtual/sessions"
    return await asyncio.to_thread(_operate, "register_probe" if probe else "start",
        lambda manager: _forward("POST", path, body))


@router.get("/api/patch/virtual/sessions/{session_id}")
async def status(session_id: str, request: Request):
    try:
        _no_query(request)
        _session(session_id)
    except ExecutionError as error:
        return _failure(error)
    return await asyncio.to_thread(_operate, "status",
        lambda manager: _forward("GET", "/patch/virtual/sessions/" + session_id, None))


@router.post("/api/patch/virtual/sessions/{session_id}/{action}")
async def control(session_id: str, action: str, request: Request):
    try:
        _no_query(request)
        _session(session_id)
        if action not in {"pause", "resume", "stop"}:
            raise ExecutionError()
        body = await _body(request)
        _control_guard(body)
    except Exception:
        return _failure(ExecutionError())
    return await asyncio.to_thread(_operate, action,
        lambda manager: _forward("POST", f"/patch/virtual/sessions/{session_id}/{action}", body))
