"""Private numerical worker protocol. Values travel in pipes, never argv/logs."""
from __future__ import annotations

import json
import os
from pathlib import Path
import selectors
import subprocess
import sys
import tempfile
import threading
import time
from typing import Any

from .execution_contract import ExecutionError, MAX_FRAME_BYTES, encoded


class IsolatedAdapter:
    """An owned interpreter isolates native compilation, failures and deadlines."""

    def __init__(self, source: dict[str, Any]) -> None:
        root = Path(__file__).resolve().parents[2]
        bootstrap = "import sys;sys.path.insert(0,sys.argv[1]);from livemorebio.aegle.execution_worker import main;main()"
        self._scratch = tempfile.TemporaryDirectory(prefix="livemore-native-execution-")
        scratch = Path(self._scratch.name)
        for name in ("home", "tmp", "cache"):
            (scratch / name).mkdir(mode=0o700)
        environment = {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin:/usr/local/bin",
                       "HOME": str(scratch / "home"), "TMPDIR": str(scratch / "tmp"),
                       "XDG_CACHE_HOME": str(scratch / "cache")}
        environment.update(OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
        self._lock = threading.Lock()
        self._buffer = bytearray()
        self._source = source
        self.runtime_identity = None
        try:
            self.process = subprocess.Popen([sys.executable, "-I", "-B", "-c", bootstrap, str(root)],
                cwd=root, env=environment, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL, close_fds=True, start_new_session=True)
        except Exception:
            self.close()
            raise ExecutionError("EXECUTION_SOLVER") from None

    def ensure_ready(self) -> None:
        # The manager registers this worker as owned before native compilation,
        # so Stop can terminate initialization instead of waiting for its deadline.
        if self.runtime_identity is None:
            configured = self._call({"operation": "configure", "source": self._source}, 45.)
            self.runtime_identity = configured["runtime_identity"]

    def _call(self, request: dict[str, Any], timeout: float) -> dict[str, Any]:
        with self._lock:
            try:
                if self.process.poll() is not None:
                    raise ExecutionError("EXECUTION_SOLVER")
                self.process.stdin.write(encoded(request) + b"\n")
                self.process.stdin.flush()
                deadline = time.monotonic() + timeout
                with selectors.DefaultSelector() as selector:
                    selector.register(self.process.stdout, selectors.EVENT_READ)
                    while b"\n" not in self._buffer:
                        remaining = deadline - time.monotonic()
                        if remaining <= 0 or not selector.select(remaining):
                            raise ExecutionError("EXECUTION_SOLVER")
                        block = os.read(self.process.stdout.fileno(), 65536)
                        if not block:
                            raise ExecutionError("EXECUTION_SOLVER")
                        self._buffer.extend(block)
                        if len(self._buffer) > MAX_FRAME_BYTES + 1:
                            raise ExecutionError("EXECUTION_SOLVER")
                line, _, rest = self._buffer.partition(b"\n")
                self._buffer = bytearray(rest)
                response = json.loads(line)
                if not isinstance(response, dict) or response.get("ok") is not True:
                    raise ExecutionError("EXECUTION_SOLVER")
                result = response.get("result")
                if not isinstance(result, dict):
                    raise ExecutionError("EXECUTION_SOLVER")
                return result
            except Exception:
                self._terminate()
                raise ExecutionError("EXECUTION_SOLVER") from None

    def initialize(self) -> dict[str, Any]:
        self.ensure_ready()
        return self._call({"operation": "initialize"}, 45.)

    def advance(self, checkpoint: dict[str, Any], native_end: float) -> dict[str, Any]:
        self.ensure_ready()
        return self._call({"operation": "advance", "checkpoint": checkpoint, "native_end": native_end}, 15.)

    def _terminate(self) -> None:
        process = getattr(self, "process", None)
        if process is None:
            return
        if process.poll() is None:
            # Includes compiler descendants belonging to this worker's session.
            import signal
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=1.)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait(timeout=2.)
        for stream in (process.stdin, process.stdout):
            if stream is not None:
                stream.close()

    def close(self) -> None:
        # No adapter mutex here: cancellation must interrupt an outstanding read.
        try:
            self._terminate()
        finally:
            scratch = getattr(self, "_scratch", None)
            if scratch is not None:
                scratch.cleanup()


def main() -> None:
    adapter = None
    try:
        while True:
            line = sys.stdin.buffer.readline(1024 * 1024 + 1)
            if not line:
                return
            if len(line) > 1024 * 1024 or not line.endswith(b"\n"):
                return
            try:
                request = json.loads(line)
                operation = request["operation"]
                if operation == "configure" and adapter is None and set(request) == {"operation", "source"}:
                    from .execution_adapters import MetabolicExecutionAdapter, CardiacExecutionAdapter
                    from .execution_contract import METABOLIC, CARDIAC
                    factory = {METABOLIC: MetabolicExecutionAdapter, CARDIAC: CardiacExecutionAdapter}[request["source"]["engine_contract_id"]]
                    adapter = factory(request["source"])
                    result = {"configured": True, "runtime_identity": adapter.runtime_identity}
                elif operation == "initialize" and adapter is not None and set(request) == {"operation"}:
                    result = adapter.initialize()
                elif operation == "advance" and adapter is not None and set(request) == {"operation", "checkpoint", "native_end"}:
                    result = adapter.advance(request["checkpoint"], request["native_end"])
                else:
                    raise ExecutionError()
                response = {"ok": True, "result": result}
            except Exception:
                # Never serialize solver exception messages or source values.
                response = {"ok": False, "code": "EXECUTION_SOLVER"}
            sys.stdout.buffer.write(encoded(response, MAX_FRAME_BYTES) + b"\n")
            sys.stdout.buffer.flush()
            if not response["ok"]:
                return
    finally:
        if adapter is not None:
            adapter.close()
