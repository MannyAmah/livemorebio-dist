"""Explicit clinical observation mapping and model initialization provenance."""
from __future__ import annotations

import math
from typing import Any

from ..engines.metabolic.glucose_insulin import MetabolicProfile
from .capture_time import normalize_capture_time


# Conversion factors map measured units to the engine's declared units. Insulin
# mass-to-molar conversion is deliberately absent because assay context matters.
_UNITS: dict[str, tuple[str, dict[str, float]]] = {
    "glucose_mgdl": ("mg/dL", {"mg/dL": 1.0, "mmol/L": 18.01559}),
    "fasting_glucose_mgdl": ("mg/dL", {"mg/dL": 1.0, "mmol/L": 18.01559}),
    "fasting_insulin_uU_ml": ("uU/mL", {"uU/mL": 1.0, "uIU/mL": 1.0, "mIU/L": 1.0}),
    "weight_kg": ("kg", {"kg": 1.0, "g": 0.001, "lb": 0.45359237}),
}
_BOUNDS = {"Si": (0.0, 1.0), "Gb": (0.0, 1000.0), "gamma": (0.0, 100.0),
           "Ib": (0.0, 10000.0), "Gt": (0.0, 1000.0), "SG": (0.0, 1.0),
           "weight_kg": (0.0, 700.0), "p2": (0.0, 1.0), "n": (0.0, 1.0),
           "ka": (0.0, 1.0), "f_bioavail": (0.0, 1.0), "vg_per_kg": (0.0, 20.0)}
MODEL_PARAMETER_NAMES = frozenset(_BOUNDS)
_PASS_QC = frozenset({"pass", "verified"})
_QUALITY_STATES = _PASS_QC | {"not_assessed", "unknown", "fail", "failed", "invalid", "rejected"}
_PARAMETER_UNITS = {
    "weight_kg": "kg", "Gb": "mg/dL", "Ib": "uU/mL", "SG": "1/min", "p2": "1/min",
    "Si": "mL/uU/min", "gamma": "uU/mL/min/(mg/dL)", "Gt": "mg/dL", "n": "1/min",
    "ka": "1/min", "f_bioavail": "1", "vg_per_kg": "dL/kg",
}


def normalize_observation(signal: str, observation: dict[str, Any]) -> dict[str, Any]:
    """Validate an admitted record; retain original units alongside normalized values."""
    result = dict(observation)
    result["captured_at"] = normalize_capture_time(result.get("captured_at"), field="clinical observation captured_at")
    quality = str(result.get("quality_status", "not_assessed")).lower()
    if quality not in _QUALITY_STATES:
        raise ValueError("clinical observation quality_status is unsupported")
    result["quality_status"] = quality
    if signal not in _UNITS:
        return result
    if quality in {"fail", "failed", "invalid", "rejected"}:
        raise ValueError("clinical observation quality did not pass")
    canonical_unit, conversions = _UNITS[signal]
    unit = str(result.get("unit", ""))
    if unit not in conversions:
        raise ValueError(f"clinical observation unit is incompatible with {signal}")
    value = float(result["value"])
    if not math.isfinite(value) or value <= 0:
        raise ValueError("clinical observation value must be finite and positive")
    result.setdefault("original_value", value)
    result.setdefault("original_unit", unit)
    result["value"] = value * conversions[unit]
    result["unit"] = canonical_unit
    result["mapping_eligible"] = quality in _PASS_QC
    return result


def validate_model_parameters(parameters: dict[str, float]) -> dict[str, float]:
    result: dict[str, float] = {}
    for field, raw in parameters.items():
        if field not in _BOUNDS:
            continue
        if isinstance(raw, bool):
            raise ValueError(f"model parameter {field} must be numeric, not boolean")
        try:
            value = float(raw)
        except (ValueError, TypeError) as error:
            raise ValueError(f"model parameter {field} must be numeric") from error
        low, high = _BOUNDS[field]
        if not math.isfinite(value) or value <= low or value > high:
            raise ValueError(f"model parameter {field} is outside the executable domain")
        result[field] = value
    return result


def validate_clinical_inputs(*, observations: dict[str, Any], model_parameters: dict[str, float],
                             source_class: str = "REAL_HUMAN", reference_source_id: str | None = None
                             ) -> tuple[dict[str, float], dict[str, dict[str, Any]]]:
    """Validate evidence conflicts without choosing or filling a biological model."""
    provenance: dict[str, dict[str, Any]] = {}
    values: dict[str, float] = {}
    aliases = {"fasting_glucose_mgdl": "Gb", "fasting_insulin_uU_ml": "Ib", "weight_kg": "weight_kg"}
    for signal, raw in observations.items():
        observation = normalize_observation(signal, raw)
        field = aliases.get(signal)
        # A random or postprandial glucose cannot establish a basal set point.
        if signal == "glucose_mgdl" and str(observation.get("sampling_context", "")).lower() == "fasting":
            field = "Gb"
        if field is None or not observation.get("mapping_eligible", False):
            continue
        if field in values and not math.isclose(values[field], observation["value"], rel_tol=1e-6):
            raise ValueError(f"conflicting observations require review for model parameter {field}")
        values[field] = observation["value"]
        provenance[field] = {
            "evidence_class": "MEASURED_CLINICAL", "source_id": observation["source"],
            "signal": signal, "unit": observation["unit"], "captured_at": observation["captured_at"],
            "quality_status": observation["quality_status"], "value": observation["value"],
            "reason": "initial observation mapping; not prospective model validation",
        }
    declared = validate_model_parameters(model_parameters)
    for field, value in declared.items():
        if field in values and not math.isclose(values[field], value, rel_tol=1e-6):
            raise ValueError(f"declared model parameter {field} conflicts with admitted measurement")
        if field in values:
            continue
        reference = source_class == "REFERENCE_GROUNDED_SYNTHETIC"
        values[field] = value
        provenance[field] = {
            "evidence_class": "REFERENCE_INITIALIZED" if reference else "USER_DECLARED_MODEL_PARAMETER",
            "source_id": reference_source_id or "admitted-model-parameters",
            "value": value, "unit": _PARAMETER_UNITS[field],
            "reason": "frozen research population parameter" if reference else "declared parameter; not a measured or fitted value",
        }
    values = validate_model_parameters(values)
    return values, provenance


def initialize_profile(human: Any) -> tuple[MetabolicProfile, dict[str, dict[str, Any]]]:
    """Only a server-resolved immutable context can supply numerical parameters."""
    from .model_contexts import ModelContextError, ResolvedModelContext

    context = getattr(human, "resolved_context", None)
    if type(context) is not ResolvedModelContext:
        raise ModelContextError("MODEL_BINDING_REQUIRED")
    context.require_human(human)
    return context.profile, context.parameter_provenance
