"""Joint public survey records for statistical research, not patient enrollment.

Selection preserves one participant's measured tuple. It never fits kinetics,
samples marginal distributions, assigns a disease type, or registers a device.
Raw linkage keys exist only during normalization and never leave this module.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
import hashlib
import hmac
import json
import math
from numbers import Real
from typing import Any

from . import population_sources as sources

SCREENED = "nhanes-2021-2023-screened-normal-glycemia-prescription-free-adults-v1"
ADULT_REFERENCE = "nhanes-2021-2023-joint-measured-adults-v1"
_TABLE_NAMES = ("DEMO_L", "BMX_L", "GLU_L", "INS_L", "GHB_L", "DIQ_L", "RXQ_RX_L")


class PopulationRecordError(ValueError):
    """Messages contain no participant values, linkage keys, or file paths."""


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


@dataclass(frozen=True)
class ReferencePopulation:
    # Immutable encoded records prevent a caller from modifying the source pool
    # through a member returned by a previous selection.
    records: tuple[bytes, ...] = field(repr=False)
    source_manifest_sha256: str


def definitions() -> dict[str, dict[str, Any]]:
    shared = {
        "version": 1, "age_years": {"minimum": 20, "maximum": 79},
        "required_measured_quantities": ["weight_kg", "fasting_glucose_mgdl", "fasting_insulin_uU_ml", "hba1c_percent"],
        "requires_positive_fasting_weight": True, "requires_positive_phlebotomy_weight": True,
        "insulin_censoring_allowed": False, "sampling": "whole_joint_records_without_replacement",
        "time_precision": "survey_cycle", "model_binding_available": False,
        "pregnancy_policy": "No negative pregnancy status is inferred. Explicit restriction requires a released negative result, including for persons whose status is not publicly released.",
    }
    return {
        ADULT_REFERENCE: {**shared, "name": "Joint measured adult research reference",
                          "screen": "No diabetes, prescription, or normal-glycemia exclusion; questionnaire answers do not determine diabetes type."},
        SCREENED: {**shared, "name": "Screened normal-glycemia, prescription-free adult research reference",
                   "screen": {"diabetes_questionnaire": "explicit_no", "prediabetes_questionnaire": "explicit_no",
                              "prescription_use_past_30_days": "explicit_no", "fasting_glucose_mgdl_lt": 100,
                              "hba1c_percent_lt": 5.7},
                   "threshold_source": "https://www.niddk.nih.gov/health-information/diabetes/overview/tests-diagnosis",
                   "limitation": "This screen is not a diagnosis or a claim of disease-free health. Prescription questions exclude prescription vitamins/minerals and do not release drug names."},
    }


def _number(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, Real):
        raise PopulationRecordError("A source field has an invalid numeric type")
    number = float(value)
    if math.isnan(number):
        return None  # SAS missingness remains missing; it is never a zero.
    if not math.isfinite(number):
        raise PopulationRecordError("A source field is not finite")
    return number


def _answer(value: float | None) -> str:
    return {1: "yes", 2: "no", 3: "borderline", 7: "refused", 9: "unknown"}.get(value, "not_released_or_skipped")


def _lineage(table: str, variable: str) -> dict[str, str]:
    artifacts = sources.source_manifest()["artifacts"]
    return {"source_id": sources.SOURCE_ID, "file": table + ".xpt", "variable": variable,
            "file_sha256": artifacts[table + ".xpt"]["sha256"],
            "codebook_sha256": artifacts[table + ".htm"]["sha256"]}


def _measurement(table: str, variable: str, value: float | None, unit: str, **extra: Any) -> dict[str, Any]:
    return {"value": value, "unit": unit, "evidence_state": "PUBLIC_REFERENCE_MEASUREMENT" if value is not None else "UNAVAILABLE",
            "lineage": _lineage(table, variable), **extra}


def normalize_joint_records(files: dict[str, bytes], *, fingerprint_key: bytes) -> ReferencePopulation:
    """Normalize only the complete exact-byte source package admitted by review.

    The caller supplies a private secret of at least 32 bytes. It must not use a
    public source identifier as that secret, or return the secret to clients.
    """
    sources.validate_source_files(files)
    tables = {artifact.filename[:-4]: sources._parse_xpt(artifact, files[artifact.filename]).to_dict("records")
              for artifact in sources.ARTIFACTS if artifact.columns}
    return _normalize_tables(tables, fingerprint_key=fingerprint_key)


def _normalize_tables(tables: dict[str, list[dict[str, Any]]], *, fingerprint_key: bytes) -> ReferencePopulation:
    """Internal normalization seam for authored tests, never an admission API."""
    if not isinstance(fingerprint_key, bytes) or len(fingerprint_key) < 32:
        raise PopulationRecordError("A private fingerprint key of at least 32 bytes is required")
    if set(tables) != set(_TABLE_NAMES):
        raise PopulationRecordError("All same-cycle source tables are required")
    indexed: dict[str, dict[int, dict[str, float | None]]] = {}
    for name in _TABLE_NAMES:
        rows: dict[int, dict[str, float | None]] = {}
        for raw in tables[name]:
            row = {key: _number(value) for key, value in raw.items()}
            key = row.get("SEQN")
            if key is None or key <= 0 or not key.is_integer() or int(key) in rows:
                raise PopulationRecordError("Source linkage keys must be present, positive, and unique")
            rows[int(key)] = row
        indexed[name] = rows
    demographic_keys = set(indexed["DEMO_L"])
    if any(set(rows) - demographic_keys for rows in indexed.values()):
        raise PopulationRecordError("A source table contains linkage keys outside the admitted demographic release")

    normalized: list[bytes] = []
    manifest_digest = sources.manifest_hash()
    for source_key, demo in indexed["DEMO_L"].items():
        if demo.get("SDDSRVYR") != 12:
            raise PopulationRecordError("The source survey cycle does not match the reviewed release")
        body, glucose, insulin, hba1c, diagnosis, prescriptions = (
            indexed[name].get(source_key, {}) for name in _TABLE_NAMES[1:])
        glucose_weight, insulin_weight = glucose.get("WTSAF2YR"), insulin.get("WTSAF2YR")
        if glucose_weight is not None and insulin_weight is not None and not math.isclose(glucose_weight, insulin_weight, rel_tol=1e-12, abs_tol=0):
            raise PopulationRecordError("Joint fasting subsample weights disagree")
        censor = insulin.get("LBDINLC")
        if censor not in (None, 0, 1):
            raise PopulationRecordError("Insulin censoring code is outside the reviewed schema")
        insulin_value = insulin.get("LBXIN") if censor == 0 else None
        hb_value = hba1c.get("LBXGH")
        if hb_value == 0:
            hb_value = None  # Codebook: zero means no laboratory result.
        fingerprint = hmac.new(fingerprint_key, f"{sources.SOURCE_ID}|{manifest_digest}|{source_key}".encode(), hashlib.sha256).hexdigest()
        record = {
            "schema": "livemore.joint-public-reference-member.v1", "reference_fingerprint": fingerprint,
            "source_id": sources.SOURCE_ID, "source_manifest_sha256": manifest_digest,
            "evidence_state": "PUBLIC_REFERENCE", "model_binding_available": False,
            "clinical_admission": False, "identity_linking": False, "physical_device_association": False,
            "time_context": {"precision": "survey_cycle", "cycle": "August 2021-August 2023",
                             "exam_period_code": demo.get("RIDEXMON"), "individual_collection_time_available": False},
            "demographics": {"age_years": demo.get("RIDAGEYR"), "age_topcoded": demo.get("RIDAGEYR") == 80,
                             "reported_sex": {1: "male", 2: "female"}.get(demo.get("RIAGENDR")),
                             "exam_status_code": demo.get("RIDSTATR"),
                             "pregnancy_status": {1: "positive", 2: "negative"}.get(demo.get("RIDEXPRG"), "not_documented_negative"),
                             "lineage": {name: _lineage("DEMO_L", variable) for name, variable in
                                         (("age_years", "RIDAGEYR"), ("reported_sex", "RIAGENDR"), ("pregnancy_status", "RIDEXPRG"))}},
            "measurements": {
                "weight_kg": _measurement("BMX_L", "BMXWT", body.get("BMXWT"), "kg", measurement_comment_code=body.get("BMIWT"), comment_lineage=_lineage("BMX_L", "BMIWT")),
                "height_cm": _measurement("BMX_L", "BMXHT", body.get("BMXHT"), "cm", measurement_comment_code=body.get("BMIHT"), comment_lineage=_lineage("BMX_L", "BMIHT")),
                "bmi_kg_m2": _measurement("BMX_L", "BMXBMI", body.get("BMXBMI"), "kg/m^2"),
                "fasting_glucose_mgdl": _measurement("GLU_L", "LBXGLU", glucose.get("LBXGLU"), "mg/dL"),
                "fasting_insulin_uU_ml": _measurement("INS_L", "LBXIN", insulin_value, "uU/mL",
                    censoring_code=censor, lower_detection_limit=0.5, source_fill_value=insulin.get("LBXIN") if censor == 1 else None,
                    source_fill_is_measurement=False, censoring_lineage=_lineage("INS_L", "LBDINLC")),
                "hba1c_percent": _measurement("GHB_L", "LBXGH", hb_value, "%"),
            },
            "survey_design": {"fasting_weight": glucose_weight if insulin_weight is not None else None,
                              "phlebotomy_weight": hba1c.get("WTPH2YR"), "stratum": demo.get("SDMVSTRA"), "psu": demo.get("SDMVPSU"),
                              "lineage": {name: _lineage(table, variable) for name, table, variable in
                                          (("fasting_weight", "GLU_L", "WTSAF2YR"), ("phlebotomy_weight", "GHB_L", "WTPH2YR"),
                                           ("stratum", "DEMO_L", "SDMVSTRA"), ("psu", "DEMO_L", "SDMVPSU"))},
                              "population_prevalence_estimate": False},
            "questionnaire": {name: {"answer": _answer(diagnosis.get(variable)), "lineage": _lineage("DIQ_L", variable)}
                              for name, variable in (("reported_diabetes", "DIQ010"), ("reported_prediabetes", "DIQ160"),
                                                     ("insulin_use", "DIQ050"), ("diabetes_pill_use", "DIQ070"))},
            "prescriptions": {"use_past_30_days": _answer(prescriptions.get("RXQ033")), "reported_count": prescriptions.get("RXQ050"),
                              "names_available": False, "lineage": _lineage("RXQ_RX_L", "RXQ033"),
                              "count_lineage": _lineage("RXQ_RX_L", "RXQ050"),
                              "scope": "Prescription vitamins/minerals excluded by source question; names, doses and durations not released"},
        }
        normalized.append(_canonical(record))
    return ReferencePopulation(tuple(normalized), manifest_digest)


def _exclusion_reasons(member: dict[str, Any], definition_id: str, require_nonpregnant: bool) -> list[str]:
    reasons = []
    demo, survey, measurements = member["demographics"], member["survey_design"], member["measurements"]
    age = demo["age_years"]
    if age is None or not 20 <= age <= 79:
        reasons.append("outside_defined_age_range")
    if demo["reported_sex"] is None:
        reasons.append("missing_reported_sex")
    if demo["exam_status_code"] != 2:
        reasons.append("not_examined")
    for quantity in definitions()[definition_id]["required_measured_quantities"]:
        value = measurements[quantity]["value"]
        if value is None or value <= 0:
            reasons.append("missing_" + quantity)
    for field, reason in (("fasting_weight", "invalid_fasting_weight"), ("phlebotomy_weight", "invalid_phlebotomy_weight")):
        if survey[field] is None or survey[field] <= 0:
            reasons.append(reason)
    censoring_code = measurements["fasting_insulin_uU_ml"]["censoring_code"]
    if censoring_code == 1:
        reasons.append("censored_fasting_insulin")
    elif censoring_code is None:
        reasons.append("insulin_detection_status_unavailable")
    if require_nonpregnant and demo["pregnancy_status"] != "negative":
        reasons.append("pregnancy_not_documented_negative")
    if definition_id == SCREENED:
        questionnaire = member["questionnaire"]
        for field in ("reported_diabetes", "reported_prediabetes"):
            answer = questionnaire[field]["answer"]
            if answer != "no":
                reasons.append(field if answer == "yes" else field + "_status_not_negative")
        if member["prescriptions"]["use_past_30_days"] != "no":
            reasons.append("prescription_status_not_negative")
        prescription_count = member["prescriptions"]["reported_count"]
        if member["prescriptions"]["use_past_30_days"] == "no" and prescription_count is not None and prescription_count > 0:
            reasons.append("inconsistent_prescription_count")
        if any(questionnaire[field]["answer"] == "yes" for field in ("insulin_use", "diabetes_pill_use")):
            reasons.append("reported_diabetes_medication_use")
        g, hb = measurements["fasting_glucose_mgdl"]["value"], measurements["hba1c_percent"]["value"]
        if (g is not None and g >= 100) or (hb is not None and hb >= 5.7):
            reasons.append("outside_normal_glycemia")
    return reasons


def select_reference_members(population: ReferencePopulation, definition_id: str, size: int, seed: int, *, require_nonpregnant: bool = False) -> dict[str, Any]:
    if definition_id not in definitions():
        raise PopulationRecordError("Unknown reviewed reference definition")
    if type(size) is not int or not 1 <= size <= 10000 or type(seed) is not int or not 0 <= seed <= 2**31 - 1 or type(require_nonpregnant) is not bool:
        raise PopulationRecordError("Selection requires a bounded integer size/seed and boolean pregnancy restriction")
    eligible = []
    exclusions: Counter[str] = Counter()
    for encoded in population.records:
        member = json.loads(encoded)
        reasons = _exclusion_reasons(member, definition_id, require_nonpregnant)
        if reasons:
            exclusions.update(reasons)
        else:
            eligible.append(member)
    if size > len(eligible):
        raise PopulationRecordError("Requested size exceeds eligible joint reference records; replacement sampling is not allowed")
    ordered = sorted(eligible, key=lambda member: hashlib.sha256(f"{seed}|{member['reference_fingerprint']}".encode()).digest())
    members = ordered[:size]
    definition = definitions()[definition_id]
    construction = {"source_manifest_sha256": population.source_manifest_sha256, "definition_id": definition_id,
                    "definition_sha256": hashlib.sha256(_canonical(definition)).hexdigest(), "size": size, "seed": seed,
                    "require_nonpregnant": require_nonpregnant,
                    "selected_fingerprints": [member["reference_fingerprint"] for member in members],
                    "normalized_member_sha256": [hashlib.sha256(_canonical(member)).hexdigest() for member in members]}
    return {"schema": "livemore.joint-public-reference-selection.v1", "source_id": sources.SOURCE_ID,
            "source_manifest_sha256": population.source_manifest_sha256, "definition_id": definition_id, "definition": definition,
            "definition_sha256": construction["definition_sha256"], "construction_sha256": hashlib.sha256(_canonical(construction)).hexdigest(),
            "size": size, "seed": seed, "require_nonpregnant": require_nonpregnant, "eligible_count": len(eligible),
            "source_record_count": len(population.records), "excluded_record_count": len(population.records) - len(eligible),
            "exclusion_counts": dict(sorted(exclusions.items())), "exclusion_counts_are_nonexclusive": True,
            "model_binding_available": False, "evidence_state": "PUBLIC_REFERENCE", "members": members,
            "selection_bias": "Complete jointly measured cases only; unweighted selection is not a representative population estimate. A documented-negative pregnancy restriction excludes unreleased status, including men and ages outside the released pregnancy range."}
