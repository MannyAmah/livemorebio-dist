"""Frozen descriptive cohorts; no physiological engines or enrollment side effects.

Private joint public records are encrypted and read from immutable storage.
Creating this record class does not bind it to a person, device, or model.
"""
from __future__ import annotations

import base64
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
from functools import wraps
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import time
from typing import Any, Callable, Iterator
import uuid

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from ..reference_cohort_contract import PUBLIC_REFERENCE_GENERATION, PUBLIC_REFERENCE_SCHEMA, PUBLIC_REFERENCE_MEMBER_SCHEMA
from ..strict_json import parse_json_object
from . import population_records as population
from . import population_sources as sources
from .subjects import SubjectRegistry

SOURCE_ID = sources.SOURCE_ID
_DRAFT_FIELDS = frozenset({"name", "indication", "source_id", "definition_id", "size", "seed", "require_nonpregnant", "accepted_use"})
_BINDINGS = ("source_manifest_sha256", "definition_sha256", "normalization_version", "construction_sha256")
_FLAGS = {"executable": False, "model_binding": None, "clinical_admission": False,
          "physical_device_association": False, "qualification_state": "NOT_QUALIFIED"}


class ReferenceCohortError(ValueError):
    def __init__(self, code: str, message: str, status: int = 422) -> None:
        super().__init__(message)
        self.code, self.status = code, status


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def _digest(value: Any) -> str:
    return hashlib.sha256(_canonical(value)).hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _safe_operation(function: Callable) -> Callable:
    @wraps(function)
    def safe(*args: Any, **kwargs: Any) -> Any:
        try:
            return function(*args, **kwargs)
        except ReferenceCohortError:
            raise
        except sources.PopulationSourceError as error:
            raise ReferenceCohortError(error.code, "Reviewed source data are unavailable; inspect source status.", 503) from None
        except population.PopulationRecordError:
            raise ReferenceCohortError("REFERENCE_SELECTION_UNAVAILABLE", "The requested selection is unavailable under the reviewed source definition.") from None
        except Exception:
            # Do not leak SQLite paths, member payloads, cryptography diagnostics,
            # labels or exceptions raised by filesystem/audit providers.
            raise ReferenceCohortError("REFERENCE_STORAGE_UNAVAILABLE", "Reference storage or its durable audit is unavailable.", 503) from None
    return safe


def reference_source_dir() -> Path:
    from ..registry import REG_DIR
    return Path(os.environ.get("LIVEMORE_POPULATION_SOURCE_DIR", str(Path(REG_DIR) / "population-sources"))).expanduser()


def normalization_version() -> str:
    from .population_identity import normalization_version as version
    return version()


def population_capability() -> dict[str, Any]:
    state = sources.source_status(reference_source_dir())
    return {"source_id": SOURCE_ID, "source_status": state, "definitions": population.definitions(),
            "generation_available": state.get("available", False), **_FLAGS,
            "scope": "descriptive_joint_public_records", "reason": "Descriptive source records require a separately qualified model binding before experimentation."}


def _draft(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != _DRAFT_FIELDS:
        raise ReferenceCohortError("INVALID_REFERENCE_DRAFT", "Supply exactly the documented reference-cohort draft fields.")
    result = dict(value)
    for label in ("name", "indication"):
        text = value[label]
        if not isinstance(text, str) or not 1 <= len(text.strip()) <= 100:
            raise ReferenceCohortError("INVALID_REFERENCE_DRAFT", "Name and indication must contain 1–100 characters.")
        result[label] = text.strip()
    if (any(not isinstance(value[field], str) for field in ("source_id", "definition_id", "accepted_use"))
            or value["source_id"] != SOURCE_ID or value["definition_id"] not in population.definitions()
            or value["accepted_use"] != "statistical_research"
            or type(value["size"]) is not int or not 1 <= value["size"] <= 1000
            or type(value["seed"]) is not int or not 0 <= value["seed"] <= 2**31 - 1
            or type(value["require_nonpregnant"]) is not bool):
        raise ReferenceCohortError("INVALID_REFERENCE_DRAFT", "Use a reviewed source/definition, statistical research acceptance, and bounded integer size/seed with a boolean restriction.")
    return result


def _private_paths(path: Path, *, create: bool = False) -> None:
    if not path.is_absolute():
        raise ValueError("absolute registry path required")
    parent = path.parent
    if create and not parent.exists() and not parent.is_symlink():
        parent.mkdir(parents=True, mode=0o700, exist_ok=True)
    info = parent.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o700:
        raise ValueError("private registry directory required")
    for candidate in (path, Path(str(path) + "-wal"), Path(str(path) + "-shm")):
        try:
            info = candidate.lstat()
        except FileNotFoundError:
            if candidate != path or not create:
                continue
            try:
                fd = os.open(candidate, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
                os.close(fd)
            except FileExistsError:
                pass  # A concurrent safe initializer may have won; inspect it.
            info = candidate.lstat()
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1):
            raise ValueError("private regular registry files required")


class _GuardedRegistry(SubjectRegistry):
    def _connect(self) -> sqlite3.Connection:
        _private_paths(self.path)
        connection = super()._connect()
        try:
            _private_paths(self.path)
        except Exception:
            connection.close()
            raise
        return connection


class ReferenceCohortService:
    @_safe_operation
    def __init__(self, path: str | Path, *, key: bytes, source_dir: str | Path) -> None:
        if not isinstance(key, bytes) or len(key) != 32:
            raise ValueError("private key required")
        self.path, self.source_dir = Path(path), Path(source_dir)
        _private_paths(self.path, create=True)
        self.registry = _GuardedRegistry(self.path, key=key)
        self._cipher = AESGCM(key)
        self.store_id: str | None = None
        with self._connection() as (con, _):
            # executescript implicitly commits; each DDL belongs to this checked
            # writer transaction, including initialization of the public namespace.
            con.execute("""
                CREATE TABLE IF NOT EXISTS public_reference_members(
                  cohort_id TEXT NOT NULL REFERENCES records(record_id),
                  member_id TEXT NOT NULL, ordinal INTEGER NOT NULL,
                  nonce BLOB NOT NULL, ciphertext BLOB NOT NULL,
                  PRIMARY KEY(cohort_id,member_id), UNIQUE(cohort_id,ordinal))
            """)
            con.execute("""
                CREATE TABLE IF NOT EXISTS public_reference_access(
                  event_id TEXT PRIMARY KEY, created_at TEXT NOT NULL,
                  nonce BLOB NOT NULL, ciphertext BLOB NOT NULL)
            """)
            con.execute("INSERT OR IGNORE INTO registry_state VALUES(?,?,?)", ("public_reference_store_id", str(uuid.uuid4()), _now()))
            self.store_id = con.execute("SELECT state_value FROM registry_state WHERE state_key=?", ("public_reference_store_id",)).fetchone()[0]
            uuid.UUID(self.store_id)
        self._keys = {domain: hmac.new(key, f"livemore.public-reference.v1|{self.store_id}|{domain}".encode(), hashlib.sha256).digest()
                      for domain in ("fingerprint", "preview", "cursor", "idempotency")}
        self.fingerprint_key = self._keys["fingerprint"]

    @contextmanager
    def _connection(self, *, expected_authority: str | None = None) -> Iterator[tuple[sqlite3.Connection, str]]:
        """Checked TX -> unlocked source work -> checked TX(same token + audit).

        This shares key/store authority, not the clinical access journal. No
        external source work belongs inside a yielded writer transaction.
        """
        con = self.registry._connect()
        failure: BaseException | None = None
        cleanup_failed = False
        try:
            con.execute("BEGIN IMMEDIATE")
            authority = self._check_authority(con, expected_authority)
            yield con, authority
            self._check_authority(con, authority)
            con.commit()
        except BaseException as error:
            failure = error
            try:
                con.rollback()
            except Exception:
                cleanup_failed = True
        finally:
            try:
                con.close()
            except Exception:
                cleanup_failed = True
        if cleanup_failed and (failure is None or isinstance(failure, ReferenceCohortError)):
            # A prepared response or ordinary domain error must not imply a
            # confirmed outcome when storage cleanup itself was unconfirmed.
            raise ReferenceCohortError("REFERENCE_STORAGE_UNAVAILABLE", "Reference storage or its durable audit is unavailable.", 503) from None
        if failure is not None:
            # Preserve the primary failure, never a raw secondary cleanup error.
            raise failure

    def _check_authority(self, con: sqlite3.Connection, expected: str | None) -> str:
        if not callable(self.registry.audit.authority_check):
            raise ValueError("registry authority unavailable")
        authority = self.registry.audit.check_authority(con)
        if not isinstance(authority, str) or not authority or (expected is not None and authority != expected):
            raise ValueError("registry authority changed or unavailable")
        if self.store_id is not None:
            row = con.execute("SELECT state_value FROM registry_state WHERE state_key=?", ("public_reference_store_id",)).fetchone()
            if row is None or row[0] != self.store_id:
                raise ValueError("reference namespace identity changed")
        return authority

    def _load_population(self) -> population.ReferencePopulation:
        return population.normalize_joint_records(sources.verified_source_files(self.source_dir), fingerprint_key=self.fingerprint_key)

    def _selection(self, draft: dict[str, Any]) -> dict[str, Any]:
        version = normalization_version()  # Refuse unknown decoders before reading rows.
        result = population.select_reference_members(self._load_population(), draft["definition_id"], draft["size"], draft["seed"], require_nonpregnant=draft["require_nonpregnant"])
        result["normalization_version"] = version
        return result

    def _seal(self, payload: dict[str, Any], *identity: str) -> tuple[bytes, bytes]:
        nonce = os.urandom(12)
        aad = _canonical(["livemore.public-reference.v1", self.store_id, *identity])
        return nonce, self._cipher.encrypt(nonce, _canonical(payload), aad)

    def _unseal(self, row: sqlite3.Row, *identity: str) -> dict[str, Any]:
        aad = _canonical(["livemore.public-reference.v1", self.store_id, *identity])
        return parse_json_object(self._cipher.decrypt(bytes(row["nonce"]), bytes(row["ciphertext"]), aad))

    def _audit(self, con: sqlite3.Connection, operation: str, kind: str, resource_id: str | None = None, *, result: str = "prepared_for_return", construction: str | None = None) -> None:
        event_id, now = "ref-access-" + uuid.uuid4().hex, _now()
        payload = {"operation": operation, "resource_kind": kind, "resource_id": resource_id,
                   "result": result, "source_id": SOURCE_ID, "construction_sha256": construction,
                   "actor": "authenticated_local_operator"}
        nonce, ciphertext = self._seal(payload, "audit", event_id)
        con.execute("INSERT INTO public_reference_access VALUES(?,?,?,?)", (event_id, now, nonce, ciphertext))

    def _token(self, payload: dict[str, Any], domain: str) -> str:
        raw = _canonical(payload)
        signature = hmac.new(self._keys[domain], raw, hashlib.sha256).digest()
        return base64.urlsafe_b64encode(raw + signature).decode().rstrip("=")

    def _untoken(self, value: Any, domain: str, fields: set[str], error_code: str) -> dict[str, Any]:
        try:
            if not isinstance(value, str) or not 40 <= len(value) <= 4096 or not re.fullmatch(r"[A-Za-z0-9_-]+", value):
                raise ValueError()
            decoded = base64.b64decode(value + "=" * (-len(value) % 4), altchars=b"-_", validate=True)
            raw, signature = decoded[:-32], decoded[-32:]
            if not hmac.compare_digest(hmac.new(self._keys[domain], raw, hashlib.sha256).digest(), signature):
                raise ValueError()
            payload = parse_json_object(raw)
            if set(payload) != fields or payload.get("version") != 1 or type(payload["version"]) is not int or payload.get("store_id") != self.store_id:
                raise ValueError()
            if self._token(payload, domain) != value:
                raise ValueError()
            return payload
        except Exception:
            raise ReferenceCohortError(error_code, "The reference token is invalid for this store or request.") from None

    @staticmethod
    def _summary(selection: dict[str, Any]) -> dict[str, Any]:
        result = {key: value for key, value in selection.items() if key != "members"}
        members = selection["members"]
        result.update(_FLAGS)
        result["summary_suppressed"] = len(members) < 5
        result["selected_summary"] = None
        if len(members) >= 5:
            quantities = {}
            for name in members[0]["measurements"]:
                values = [m["measurements"][name]["value"] for m in members if m["measurements"][name]["value"] is not None]
                quantities[name] = {"minimum": min(values) if values else None, "maximum": max(values) if values else None, "unit": members[0]["measurements"][name]["unit"], "available_count": len(values)}
            result["selected_summary"] = {"measurements": quantities, "age_years": {"minimum": min(m["demographics"]["age_years"] for m in members), "maximum": max(m["demographics"]["age_years"] for m in members)}, "reported_sex_counts": dict(Counter(m["demographics"]["reported_sex"] for m in members)), "disclosure_class": "authenticated_reference_data_not_anonymity_claim"}
        return result

    @_safe_operation
    def preview(self, body: Any) -> dict[str, Any]:
        draft = _draft(body)
        with self._connection() as (_, authority):
            pass
        selection = self._selection(draft)
        expires = int(time.time()) + 900
        token = {"version": 1, "store_id": self.store_id, "draft_sha256": _digest(draft), "expires_at_unix": expires, **{k: selection[k] for k in _BINDINGS}}
        result = {**self._summary(selection), "preview_token": self._token(token, "preview"), "expires_at_unix": expires}
        with self._connection(expected_authority=authority) as (con, _):
            self._audit(con, "preview", "selection", construction=selection["construction_sha256"])
        return result

    @staticmethod
    def _public(record: dict[str, Any]) -> dict[str, Any]:
        return {key: value for key, value in record.items() if key not in {"member_manifest", "request_identity_sha256", "idempotency_fingerprint"}}

    def _record(self, con: sqlite3.Connection, cohort_id: str) -> dict[str, Any]:
        row = con.execute("SELECT * FROM records WHERE record_id=? AND record_type='COHORT' AND source_class='PUBLIC_REFERENCE'", (cohort_id,)).fetchone()
        if row is None:
            raise ReferenceCohortError("REFERENCE_COHORT_NOT_FOUND", "Reference cohort not found.", 404)
        result = self.registry._open(row)
        if (result.get("schema") != PUBLIC_REFERENCE_SCHEMA or result.get("cohort_id") != cohort_id or result.get("source_class") != "PUBLIC_REFERENCE" or result.get("executable") is not False or result.get("model_binding") is not None):
            raise ValueError("cohort integrity failure")
        request_identity = _digest({"draft": result["draft"], **{key: result[key] for key in _BINDINGS}})
        if (request_identity != result["request_identity_sha256"] or request_identity != row["request_hash"]
                or result["idempotency_fingerprint"] != row["idempotency_key"]):
            raise ValueError("request index integrity failure")
        manifest = result["member_manifest"]
        if len(manifest) != result["size"] or [m["ordinal"] for m in manifest] != list(range(result["size"])) or len({m["member_id"] for m in manifest}) != result["size"]:
            raise ValueError("manifest integrity failure")
        construction = {"source_manifest_sha256": result["source_manifest_sha256"], "definition_id": result["definition_id"], "definition_sha256": result["definition_sha256"], "size": result["size"], "seed": result["seed"], "require_nonpregnant": result["require_nonpregnant"], "selected_fingerprints": [m["reference_fingerprint"] for m in manifest], "normalized_member_sha256": [m["normalized_member_sha256"] for m in manifest]}
        if _digest(construction) != result["construction_sha256"]:
            raise ValueError("construction integrity failure")
        count = con.execute("SELECT COUNT(*) FROM public_reference_members WHERE cohort_id=?", (cohort_id,)).fetchone()[0]
        if count != result["size"]:
            raise ValueError("incomplete frozen members")
        return result

    def _existing(self, con: sqlite3.Connection, key: str, request_hash: str) -> dict[str, Any] | None:
        row = con.execute("SELECT record_id,request_hash FROM records WHERE idempotency_key=?", (key,)).fetchone()
        if row is None:
            return None
        record = self._record(con, row["record_id"])
        if row["request_hash"] != request_hash:
            raise ReferenceCohortError("IDEMPOTENCY_CONFLICT", "Idempotency key was already used for a different reference request.", 409)
        self._audit(con, "create_replay", "cohort", record["cohort_id"], construction=record["construction_sha256"])
        return {**self._public(record), "idempotent_replay": True}

    def _write_member(self, con: sqlite3.Connection, cohort_id: str, member: dict[str, Any]) -> None:
        nonce, ciphertext = self._seal(member, "member", cohort_id, member["member_id"])
        con.execute("INSERT INTO public_reference_members VALUES(?,?,?,?,?)", (cohort_id, member["member_id"], member["ordinal"], nonce, ciphertext))

    @_safe_operation
    def create(self, body: Any, *, idempotency_key: str) -> dict[str, Any]:
        if not isinstance(body, dict) or set(body) != {"draft", "preview_token"}:
            raise ReferenceCohortError("INVALID_REFERENCE_CREATE", "Supply a draft and signed preview token.")
        draft = _draft(body["draft"])
        if not isinstance(idempotency_key, str) or not re.fullmatch(r"[A-Za-z0-9._:-]{1,128}", idempotency_key):
            raise ReferenceCohortError("INVALID_IDEMPOTENCY_KEY", "Supply an opaque Idempotency-Key of 1–128 supported ASCII characters.")
        token = self._untoken(body["preview_token"], "preview", {"version", "store_id", "draft_sha256", "expires_at_unix", *_BINDINGS}, "INVALID_REFERENCE_PREVIEW")
        if token["draft_sha256"] != _digest(draft):
            raise ReferenceCohortError("REFERENCE_PREVIEW_CHANGED", "The draft changed; preview the current selection again.", 409)
        if type(token["expires_at_unix"]) is not int or any(not isinstance(token[k], str) or not token[k] or len(token[k]) > 512 for k in _BINDINGS):
            raise ReferenceCohortError("INVALID_REFERENCE_PREVIEW", "The reference preview metadata is invalid.")
        request_hash = _digest({"draft": draft, **{k: token[k] for k in _BINDINGS}})
        key = "public-reference:" + hmac.new(self._keys["idempotency"], idempotency_key.encode(), hashlib.sha256).hexdigest()
        # Existing -> committed replay; absent -> unlocked source preparation
        # -> final writer transaction checked against this operation's token.
        with self._connection() as (con, authority):
            existing = self._existing(con, key, request_hash)
            if existing is not None:
                return existing
        if token["expires_at_unix"] <= time.time():
            raise ReferenceCohortError("REFERENCE_PREVIEW_EXPIRED", "The preview expired; preview the selection again.", 409)
        selection = self._selection(draft)
        if any(selection[k] != token[k] for k in _BINDINGS):
            raise ReferenceCohortError("REFERENCE_PREVIEW_CHANGED", "Source or normalization changed; preview the selection again.", 409)
        cohort_id, now = "reference-cohort-" + uuid.uuid4().hex, _now()
        members = [{"schema": PUBLIC_REFERENCE_MEMBER_SCHEMA, "source_class": "PUBLIC_REFERENCE", "member_id": "reference-member-" + uuid.uuid4().hex, "cohort_id": cohort_id, "ordinal": i, "reference": reference,
                    "normalized_member_sha256": _digest(reference), **{k: selection[k] for k in _BINDINGS}, **_FLAGS}
                   for i, reference in enumerate(selection["members"])]
        record = {**self._summary(selection), "schema": PUBLIC_REFERENCE_SCHEMA, "cohort_id": cohort_id, "name": draft["name"], "indication": draft["indication"], "draft": draft,
                  "request_identity_sha256": request_hash, "idempotency_fingerprint": key,
                  "source_class": "PUBLIC_REFERENCE", "generation_method": PUBLIC_REFERENCE_GENERATION, "lifecycle": "FROZEN", "version": 1,
                  "created_at": now, "updated_at": now, "creation_time_kind": "software_record_creation_not_collection_time",
                  "members_materialized": True, "members_included": False, "member_list_uri": f"/api/reference-cohorts/{cohort_id}/members",
                  "member_manifest": [{"member_id": m["member_id"], "ordinal": m["ordinal"], "normalized_member_sha256": m["normalized_member_sha256"], "reference_fingerprint": m["reference"]["reference_fingerprint"]} for m in members]}
        nonce, ciphertext = self.registry._seal(cohort_id, record)
        with self._connection(expected_authority=authority) as (con, _):
            existing = self._existing(con, key, request_hash)
            if existing is not None:
                return existing
            con.execute("INSERT INTO records VALUES(?,?,?,?,?,?,?,?,?,?,?)", (cohort_id, "COHORT", "PUBLIC_REFERENCE", "FROZEN", 1, key, request_hash, now, now, nonce, ciphertext))
            for member in members:
                self._write_member(con, cohort_id, member)
            self._audit(con, "create", "cohort", cohort_id, result="committed", construction=record["construction_sha256"])
        return {**self._public(record), "idempotent_replay": False}

    @_safe_operation
    def get_summary(self, cohort_id: str) -> dict[str, Any]:
        with self._connection() as (con, _):
            result = self._record(con, cohort_id)
            self._audit(con, "summary_read", "cohort", cohort_id, construction=result["construction_sha256"])
            return self._public(result)

    def _member(self, row: sqlite3.Row, record: dict[str, Any]) -> dict[str, Any]:
        member = self._unseal(row, "member", record["cohort_id"], row["member_id"])
        expected = record["member_manifest"][row["ordinal"]]
        if (member.get("schema") != PUBLIC_REFERENCE_MEMBER_SCHEMA or member.get("source_class") != "PUBLIC_REFERENCE"
                or any(member.get(key) != value for key, value in _FLAGS.items())
                or member["member_id"] != row["member_id"] or expected["member_id"] != row["member_id"] or member["ordinal"] != row["ordinal"]
                or member["cohort_id"] != record["cohort_id"] or _digest(member["reference"]) != expected["normalized_member_sha256"]
                or member["normalized_member_sha256"] != expected["normalized_member_sha256"]
                or member["reference"]["reference_fingerprint"] != expected["reference_fingerprint"]
                or any(member[k] != record[k] for k in _BINDINGS)):
            raise ValueError("member integrity failure")
        return member

    @_safe_operation
    def page_members(self, cohort_id: str, *, limit: int = 10, cursor: str | None = None) -> dict[str, Any]:
        if type(limit) is not int or not 1 <= limit <= 50:
            raise ReferenceCohortError("INVALID_REFERENCE_MEMBER_PAGE", "Member page size must be an integer from 1 to 50.")
        with self._connection() as (con, _):
            record = self._record(con, cohort_id)
            after = -1
            if cursor is not None:
                token = self._untoken(cursor, "cursor", {"version", "store_id", "cohort_id", "construction_sha256", "limit", "last_ordinal"}, "INVALID_REFERENCE_MEMBER_PAGE")
                if (token["cohort_id"] != cohort_id or token["construction_sha256"] != record["construction_sha256"] or type(token["limit"]) is not int or token["limit"] != limit
                        or type(token["last_ordinal"]) is not int or not 0 <= token["last_ordinal"] < record["size"] - 1):
                    raise ReferenceCohortError("INVALID_REFERENCE_MEMBER_PAGE", "The member cursor does not match this cohort page.")
                after = token["last_ordinal"]
            rows = con.execute("SELECT * FROM public_reference_members WHERE cohort_id=? AND ordinal>? ORDER BY ordinal LIMIT ?", (cohort_id, after, limit)).fetchall()
            expected_ordinals = list(range(after + 1, min(after + 1 + limit, record["size"])))
            if [r["ordinal"] for r in rows] != expected_ordinals:
                raise ValueError("member page incomplete")
            members = [self._member(row, record) for row in rows]
            more = after + len(rows) + 1 < record["size"]
            next_cursor = self._token({"version": 1, "store_id": self.store_id, "cohort_id": cohort_id, "construction_sha256": record["construction_sha256"], "limit": limit, "last_ordinal": rows[-1]["ordinal"]}, "cursor") if more else None
            self._audit(con, "member_page_read", "cohort", cohort_id, construction=record["construction_sha256"])
            return {"cohort_id": cohort_id, "members": members, "pagination": {"limit": limit, "next_cursor": next_cursor, "has_more": more, "total": record["size"]}}

    @_safe_operation
    def get_member(self, cohort_id: str, member_id: str) -> dict[str, Any]:
        with self._connection() as (con, _):
            record = self._record(con, cohort_id)
            row = con.execute("SELECT * FROM public_reference_members WHERE cohort_id=? AND member_id=?", (cohort_id, member_id)).fetchone()
            if row is None:
                raise ReferenceCohortError("REFERENCE_MEMBER_NOT_FOUND", "Reference member not found in this cohort.", 404)
            result = self._member(row, record)
            self._audit(con, "member_read", "member", member_id, construction=record["construction_sha256"])
            return result
