"""Engine-free projections for a selected descriptive clinical record."""
from __future__ import annotations

from copy import deepcopy
from typing import Any

from .observation_state import ObservationState


def unavailable_state(availability: dict, observed: ObservationState) -> dict[str, Any]:
    from .runtime import SYSTEMS

    absent = ("profile", "base", "profile_params", "pk_context", "parameter_provenance",
              "provenance", "intervention", "metabolic", "cardiac", "hepatic", "comparison")
    return {**{key: None for key in absent}, **observed.state(),
            "applied": [], "active_execution": None, "human": None,
            "model_availability": deepcopy(availability),
            "systems": [{**deepcopy(row), "status": "unavailable"} for row in SYSTEMS]}


def unavailable_multiscale(subject: dict, availability: dict) -> dict[str, Any]:
    from ..multiscale import whole_body_contracts

    return {
        "schema": "livemore.multiscale-state.v1",
        "subject": {"id": subject["subject_id"], "profile": None, "person_specific": True},
        "biological_time": {"axes": [], "rule": "No numerical model is available for this selection."},
        "hierarchy": ["Whole Body", "Cardiovascular", "Heart", "Ventricular Tissue",
                      "Cardiomyocyte", "Ion Channel", "Gene / Protein"],
        "systems": [{"system_id": row["system_id"], "name": row["name"], "contract": row,
                     "execution_status": "UNAVAILABLE", "state": {}, "engine_ids": [],
                     "unavailable_reason": availability["reason_code"]}
                    for row in whole_body_contracts()],
        "active_execution": None, "comparison": None,
        "patch_reconciliation": {"signals": [], "calibration_authorized": False,
                                  "reason": availability["reason_code"]},
    }


def unavailable_biology() -> dict[str, Any]:
    from ..engines.biology import biology_reference

    return {**biology_reference(),
            "twin": {"profile": None, "Si": None, "Gb": None, "gamma": None,
                     "human": None, "genome": {}, "conditions": []},
            "interventions": [], "last_intervention": None}
