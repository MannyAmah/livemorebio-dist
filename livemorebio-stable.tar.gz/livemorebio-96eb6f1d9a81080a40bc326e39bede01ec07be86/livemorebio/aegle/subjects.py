"""Encrypted, local subject and cohort lifecycle for the Aegle workbench.

Only opaque identifiers and lifecycle metadata are stored in plaintext indexes.
The payload, including labels, observations, conditions, and genome fields, is
encrypted with the same owner-controlled AES-256 key used for PHI-like local state.
"""
from __future__ import annotations

import hashlib
import base64
import hmac
import json
import math
import re
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
import sqlite3
from typing import Any, Literal
import uuid
from contextlib import closing, contextmanager

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from ..strict_json import MAX_SAFE_INTEGER

from .population import generate_members, heterogeneity_summary, normalize_reference_source
from .registry_audit import AuditReservation, RegistryAuditError
from .profile_sources import (
    build_profile_provenance,
    normalize_profile_sources,
    validate_environment,
    validate_medications,
)


_AAD = b"livemore.aegle.subject-registry.v1"
_SOURCE_CLASSES = frozenset({"REAL_HUMAN", "SYNTHETIC", "REFERENCE_GROUNDED_SYNTHETIC"})
_TWIN_FIELDS = ("source_class", "subject_id", "display_label", "consent_scope", "chain_of_custody", "demographics", "conditions", "medications", "genome", "lifestyle", "lifestyle_profile", "environment", "observations", "model_parameters", "profile_sources", "profile_coverage", "field_provenance", "reference_source", "reference_stratum", "reference_lineage", "generation_seed")
_COHORT_FIELDS = ("source_class", "name", "size", "seed", "indication", "member_twin_ids", "stratum", "reference_source")
_EVIDENCE_FIELDS = tuple(field for field in _TWIN_FIELDS if field not in {"display_label", "reference_source", "reference_stratum", "reference_lineage", "generation_seed"})
_RESERVED = frozenset({"model_binding", "creation_identity", "parameter_provenance", "schema", "twin_id", "cohort_id", "version", "lifecycle", "selection_mode", "patch_bindings", "created_at", "updated_at", "members", "execution_eligibility"})
_NORMALIZER = "livemore.real-human-descriptive.v1"


class SubjectRegistryError(ValueError):
    """A named, user-correctable subject lifecycle failure."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _bounded_string(value: object, field: str, *, maximum: int = 120) -> str:
    result = str(value or "").strip()
    if not result or len(result) > maximum:
        raise SubjectRegistryError("INVALID_TWIN_DATA", f"{field} must contain 1 to {maximum} characters")
    return result


def _bounded_list(value: object, field: str, *, maximum: int = 40) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or len(value) > maximum:
        raise SubjectRegistryError("INVALID_TWIN_DATA", f"{field} must be a list with at most {maximum} values")
    return [_bounded_string(item, field) for item in value]


def _finite(value: object, field: str, lower: float, upper: float) -> float:
    if isinstance(value, bool):
        raise SubjectRegistryError("INVALID_TWIN_DATA", f"{field} must be numeric, not boolean")
    try:
        number = float(value)
    except (TypeError, ValueError) as error:
        raise SubjectRegistryError("INVALID_TWIN_DATA", f"{field} must be numeric") from error
    if not math.isfinite(number) or number < lower or number > upper:
        raise SubjectRegistryError("INVALID_TWIN_DATA", f"{field} must be between {lower} and {upper}")
    return number


def _request_hash(payload: dict[str, Any]) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _intent(record_type: str, record: dict[str, Any]) -> dict[str, Any]:
    return {field: record[field] for field in (_TWIN_FIELDS if record_type == "TWIN" else _COHORT_FIELDS)}


def _creation_identity(record_type: str, payload: dict[str, Any], key: str | None) -> dict[str, Any]:
    return {"schema": "livemore.subject-creation-identity.v1", "normalizer_id": _NORMALIZER,
            "record_type": record_type, "request_sha256": _request_hash({"schema": "livemore.descriptive-creation-intent.v1", "normalizer_id": _NORMALIZER, "record_type": record_type, "payload": payload}),
            "idempotency_key_sha256": hashlib.sha256(b"livemore.subject-idempotency-key.v1\0" + key.encode()).hexdigest() if key else None}


def enforce_real_cohort_size(record: dict[str, Any]) -> None:
    if len(_canonical(record)) > 16_777_216:
        raise SubjectRegistryError("COHORT_PAYLOAD_TOO_LARGE", "The frozen cohort exceeds the local encrypted payload limit.")


def _validate_real_admission(record: dict[str, Any], *, research: bool = False) -> None:
    from ..reference_cohort_contract import is_public_reference
    from .clinical_parameters import validate_clinical_inputs

    try:
        if (record.get("schema") != "livemore.twin-record.v1" or record.get("source_class") != "REAL_HUMAN"
                or is_public_reference(record) or is_public_reference(record.get("reference"))
                or record.get("lifecycle") not in {"DATA_ADMITTED", "ACTIVE"}
                or type(record.get("version")) is not int or record["version"] < 1
                or not isinstance(record.get("subject_id"), str) or not record["subject_id"].startswith("pseudonym-")
                or not record.get("chain_of_custody") or not record.get("observations")
                or not isinstance(record.get("consent_scope"), list) or not record["consent_scope"]
                or (research and "cendos_validation" not in record["consent_scope"])):
            raise ValueError
        observations = _validate_observations(record["observations"])
        sources = record.get("profile_sources")
        if not isinstance(sources, list) or not sources:
            raise ValueError
        # Historical compatibility metadata remains readable, but cannot stand
        # in for source evidence when composing a newly enrolled research cohort.
        if any(source.get("quality_status") in {"fail", "failed", "invalid", "rejected", "revoked"} for source in sources):
            raise ValueError
        normalize_profile_sources(sources, source_class="REAL_HUMAN", chain_of_custody=record["chain_of_custody"], observations_present=True, error=SubjectRegistryError)
        validate_clinical_inputs(observations=observations, model_parameters=record["model_parameters"])
        _finite(record["demographics"]["age"], "age", 0, 120)
        _bounded_string(record["demographics"]["sex"], "sex", maximum=24)
        _canonical(record)
    except (ValueError, KeyError, TypeError, AttributeError) as error:
        raise SubjectRegistryError("COHORT_MEMBER_INELIGIBLE" if research else "SUBJECT_ADMISSION_REQUIRED", "The record lacks the required admitted source evidence and consent.") from error


@dataclass(frozen=True)
class PreparedObservationSelection:
    original_sha256: str
    _record_json: bytes

    @property
    def record(self) -> dict[str, Any]:
        return json.loads(self._record_json)


@dataclass(frozen=True, repr=False)
class _SelectionAuditOrigin:
    reservation: AuditReservation
    begin_row: tuple[str, int, bytes, bytes]


@dataclass(frozen=True, repr=False)
class CheckedActiveSelection:
    """Private audited capture; neither a public receipt nor mutation authority."""

    store_id: str
    authority_token: str
    request_id: str
    _rows: tuple[tuple[object, ...], ...]
    _pointer: tuple[str, str, str] | None
    _active_ids: tuple[str, ...]
    _record_json: bytes

    @property
    def record(self) -> dict[str, Any] | None:
        return json.loads(self._record_json)


@dataclass(frozen=True, repr=False)
class PreparedRegistryTransition:
    """Private snapshot, never an HTTP authorization token or plaintext repr."""

    kind: str
    store_id: str
    authority_token: str
    request_id: str
    target_id: str | None
    timestamp: str
    _rows: tuple[tuple[Any, ...], ...]
    _before_json: bytes
    _after_json: bytes
    _pointer_before: tuple[str, str, str] | None
    _pointer_after: tuple[str, str, str] | None
    _device_before: tuple[str, str, str] | None
    _device_after: tuple[str, str, str] | None
    _binding_json: bytes

    @property
    def record(self) -> dict[str, Any] | None:
        return json.loads(self._after_json).get(self.target_id)

    @property
    def target_before(self) -> dict[str, Any] | None:
        return json.loads(self._before_json).get(self.target_id)

    @property
    def active_before(self) -> dict[str, Any] | None:
        return json.loads(self._before_json).get(self._pointer_before[1]) if self._pointer_before else None

    @property
    def active_after(self) -> dict[str, Any] | None:
        if self._pointer_after is None:
            return None
        return {**json.loads(self._before_json), **json.loads(self._after_json)}.get(self._pointer_after[1])

    @property
    def selected(self) -> bool:
        return self.target_id is not None and self._pointer_before is not None and self.target_id == self._pointer_before[1]


def _transition_error(code: str = "REGISTRY_STORAGE_UNAVAILABLE") -> SubjectRegistryError:
    messages = {
        "REGISTRY_STORAGE_UNAVAILABLE": "Subject registry storage is unavailable; no successful transition is confirmed.",
        "TWIN_VERSION_CONFLICT": "The exact prepared subject selection changed; inspect the current record.",
        "INVALID_TWIN_DATA": "The internal transition preparation is invalid.",
        "INVALID_PATCH_BINDING": "Patch binding fields are invalid.",
        "INVALID_REQUEST_ID": "Access request identity must be a canonical UUID.",
        "SELECTION_COMMIT_UNCONFIRMED": "Selection commit or rollback cannot be confirmed; inspect authoritative state before further work.",
        "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED": "The selection was committed, but resource cleanup could not be confirmed; inspect before continuing.",
    }
    return SubjectRegistryError(code, messages[code])


def _transition_version(value: object, *, stored: bool = False) -> None:
    if type(value) is not int or not 1 <= value < MAX_SAFE_INTEGER:
        raise _transition_error("REGISTRY_STORAGE_UNAVAILABLE" if stored else "TWIN_VERSION_CONFLICT")


def _transition_read_version(value: object) -> None:
    # A previously committed terminal revision is readable, not incrementable.
    if type(value) is not int or not 1 <= value <= MAX_SAFE_INTEGER:
        raise _transition_error()


def _transition_request(value: object) -> str:
    try:
        if type(value) is not str or str(uuid.UUID(value)) != value:
            raise ValueError
    except ValueError as error:
        raise _transition_error("INVALID_REQUEST_ID") from error
    return value


def _transition_target(value: object) -> str:
    if type(value) is not str or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", value):
        raise _transition_error("INVALID_TWIN_DATA")
    return value


def _normalize_transition_binding(body: object, expected_version: int) -> dict[str, str]:
    fields = {"device_id", "mode", "protocol_version", "hardware_revision", "firmware_version", "calibration_status", "attestation_reference", "expected_version"}
    if type(body) is not dict or set(body) - fields:
        raise _transition_error("INVALID_PATCH_BINDING")
    if "expected_version" in body:
        _transition_version(body["expected_version"])
        if body["expected_version"] != expected_version:
            raise _transition_error("TWIN_VERSION_CONFLICT")
    if any(type(value) is not str for key, value in body.items() if key != "expected_version"):
        raise _transition_error("INVALID_PATCH_BINDING")
    mode = body.get("mode", "virtual").strip().lower()
    normalized = {
        "device_id": body.get("device_id", "").strip(), "mode": mode,
        "protocol_version": body.get("protocol_version", "2.0").strip(),
        "hardware_revision": body.get("hardware_revision", "B0-EVT-target").strip(),
        "firmware_version": body.get("firmware_version", "virtual-2.0" if mode == "virtual" else "").strip(),
        "calibration_status": body.get("calibration_status", "not_applicable" if mode != "physical" else "").strip().lower(),
        "attestation_reference": body.get("attestation_reference", "").strip(),
    }
    if not 1 <= len(normalized["device_id"]) <= 96 or mode not in {"physical", "virtual", "replay"} or normalized["protocol_version"] not in {"2.0", "3.0"}:
        raise _transition_error("INVALID_PATCH_BINDING")
    if any(len(value) > (256 if key == "attestation_reference" else 96) for key, value in normalized.items()):
        raise _transition_error("INVALID_PATCH_BINDING")
    if mode == "physical" and normalized["protocol_version"] == "3.0":
        # New physical-v3 pairing requires the internal fresh-inspection seam.
        raise _transition_error("INVALID_PATCH_BINDING")
    return normalized


def _activation_transition_admission(record: dict[str, Any]) -> None:
    from ..reference_cohort_contract import ensure_cohort_executable
    from .model_contexts import resolve_model_context
    if record.get("source_class") != "SYNTHETIC":
        resolve_model_context(record)
    ensure_cohort_executable(record)
    if record["source_class"] == "REAL_HUMAN":
        _validate_real_admission(record)
        if record.get("profile_coverage", {}).get("status") != "ADMITTED_COMPLETE":
            raise SubjectRegistryError("PROFILE_COVERAGE_INSUFFICIENT", "Real-human activation requires admitted core profile domains.")


def _transition_changes(kind: str, before: dict[str, dict[str, Any]], pointer: tuple | None,
                        device: tuple | None, target: str | None, binding: dict[str, Any] | None,
                        timestamp: str) -> tuple[dict[str, dict[str, Any]], tuple | None, tuple | None]:
    """Reconstruct the sole permitted edit; no model/profile construction here."""
    after: dict[str, dict[str, Any]] = {}
    selected = pointer[1] if pointer else None
    if kind in {"activate", "select_observations", "clear_for_preview"} and selected is not None and selected != target:
        original = before[selected]
        _transition_version(original["version"], stored=True)
        after[selected] = {**original, "lifecycle": "DATA_ADMITTED", "version": original["version"] + 1, "updated_at": timestamp}
    if kind == "clear_for_preview":
        return after, None, device
    original = before[target]
    _transition_version(original["version"], stored=True)
    changed = {**original, "version": original["version"] + 1, "updated_at": timestamp}
    if kind == "activate":
        _activation_transition_admission(original)
        changed.update(lifecycle="ACTIVE", selection_mode="model")
        pointer = ("active_twin_id", target, timestamp)
    elif kind == "select_observations":
        _validate_real_admission(original)
        changed.update(lifecycle="ACTIVE", selection_mode="observations_only")
        pointer = ("active_twin_id", target, timestamp)
    elif kind == "bind":
        if binding["mode"] == "physical":
            if original["source_class"] != "REAL_HUMAN":
                raise SubjectRegistryError("PHYSICAL_PATCH_REQUIRES_REAL_HUMAN", "Physical LIFE pairing requires an admitted real-human record.")
            if selected != target or original["lifecycle"] != "ACTIVE":
                raise SubjectRegistryError("PHYSICAL_PATCH_REQUIRES_ACTIVE_TWIN", "Select the admitted real-human record before physical LIFE pairing.")
            _validate_real_admission(original)
            for valid, code, message in (
                ("life_patch" in original["consent_scope"], "PHYSICAL_PATCH_CONSENT_REQUIRED", "Consent does not authorize LIFE Patch pairing."),
                (bool(binding["attestation_reference"]), "PHYSICAL_PATCH_ATTESTATION_REQUIRED", "Physical pairing requires an attestation reference."),
                (binding["hardware_revision"] == "B0-EVT-target", "PHYSICAL_PATCH_CONTRACT_MISMATCH", "Physical metadata must match the B0-EVT target contract."),
                (bool(binding["firmware_version"]), "PHYSICAL_PATCH_FIRMWARE_REQUIRED", "Physical pairing requires a firmware version."),
                (binding["calibration_status"] == "current", "PHYSICAL_PATCH_CALIBRATION_REQUIRED", "Physical calibration must be current before pairing."),
                (device is None or device[1] == target, "PATCH_BINDING_CONFLICT", "Physical LIFE Patch is already paired to another twin."),
            ):
                if not valid: raise SubjectRegistryError(code, message)
            device = (hashlib.sha256(binding["device_id"].encode()).hexdigest(), target, timestamp)
        physical = binding["mode"] == "physical"
        entry = {**binding, "attestation_reference": binding["attestation_reference"] or None,
                 "hardware_present": physical, "qualification_state": "PAIRING_RECORDED" if physical else "CONTRACT_BOUND",
                 "telemetry_admission": "PENDING_SIGNED_ENVELOPE" if physical else "VIRTUAL_ELIGIBLE",
                 "bound_at": timestamp, "subject_fingerprint": hashlib.sha256(original["subject_id"].encode()).hexdigest()}
        if binding.get("schema") == "livemore.registered-physical-binding-input.v1":
            from ..life_patch.physical_binding import registered_binding_entry
            entry = registered_binding_entry(binding, original, timestamp)
        changed["patch_bindings"] = [item for item in original["patch_bindings"] if item["device_id"] != binding["device_id"]] + [entry]
    else:
        raise _transition_error("INVALID_TWIN_DATA")
    after[target] = changed
    return after, pointer, device


def prepare_observation_selection(record: dict[str, Any], *, expected_version: int) -> PreparedObservationSelection:
    _transition_version(expected_version)
    if record.get("version") != expected_version:
        raise SubjectRegistryError("TWIN_VERSION_CONFLICT", "Twin version changed; inspect the current record.")
    _validate_real_admission(record)
    updated = {**record, "version": expected_version + 1, "lifecycle": "ACTIVE", "selection_mode": "observations_only", "updated_at": _now()}
    return PreparedObservationSelection(_request_hash(record), _canonical(updated))


def _member_snapshot(member: dict[str, Any]) -> dict[str, Any]:
    try:
        snapshot = member["snapshot"]
        if (set(member) != {"schema", "source_class", "twin_id", "record_version", "snapshot_sha256", "evidence_sha256", "snapshot"}
                or member["schema"] != "livemore.frozen-real-human-member.v1" or member["source_class"] != "REAL_HUMAN"
                or snapshot["source_class"] != "REAL_HUMAN" or member["twin_id"] != snapshot["twin_id"]
                or type(member["record_version"]) is not int or member["record_version"] < 1 or member["record_version"] != snapshot["version"]
                or member["snapshot_sha256"] != hashlib.sha256(b"livemore.real-human-member-snapshot.v1\0" + _canonical(snapshot)).hexdigest()
                or member["evidence_sha256"] != hashlib.sha256(b"livemore.real-human-member-evidence.v1\0" + _canonical({field: snapshot[field] for field in _EVIDENCE_FIELDS})).hexdigest()):
            raise ValueError
        return snapshot
    except (ValueError, TypeError, KeyError) as error:
        raise SubjectRegistryError("COHORT_SNAPSHOT_INVALID", "Frozen cohort evidence integrity failed.") from error


def project_cohort_summary(record: dict[str, Any]) -> dict[str, Any]:
    if record.get("source_class") != "REAL_HUMAN":
        return record
    reason = "MODEL_BINDING_REQUIRED" if record.get("members") else "COHORT_MEMBER_SNAPSHOT_REQUIRED"
    fields = ("schema", "cohort_id", "version", "lifecycle", "created_at", "updated_at", "name", "indication", "source_class", "size")
    return {**{field: record[field] for field in fields}, "execution_eligibility": {"state": "UNAVAILABLE", "reason_code": reason}}


def _validate_observations(value: object) -> dict[str, dict[str, Any]]:
    if value is None:
        return {}
    if not isinstance(value, dict) or len(value) > 100:
        raise SubjectRegistryError("INVALID_TWIN_DATA", "observations must be an object with at most 100 signals")
    result: dict[str, dict[str, Any]] = {}
    for raw_signal, raw_observation in value.items():
        signal = _bounded_string(raw_signal, "observation signal", maximum=80)
        if not isinstance(raw_observation, dict):
            raise SubjectRegistryError("INVALID_TWIN_DATA", f"observation {signal} must be an object")
        result[signal] = {
            "value": _finite(raw_observation.get("value"), f"{signal}.value", -1e12, 1e12),
            "unit": _bounded_string(raw_observation.get("unit"), f"{signal}.unit", maximum=40),
            "captured_at": _bounded_string(raw_observation.get("captured_at"), f"{signal}.captured_at", maximum=40),
            "source": _bounded_string(raw_observation.get("source"), f"{signal}.source", maximum=120),
            "quality_status": str(raw_observation.get("quality_status", "not_assessed"))[:40],
            "sampling_context": str(raw_observation.get("sampling_context", "unknown"))[:40],
        }
        from .clinical_parameters import normalize_observation

        try:
            result[signal] = normalize_observation(signal, result[signal])
        except ValueError as error:
            raise SubjectRegistryError("INVALID_CLINICAL_OBSERVATION", str(error)) from error
    return result


@dataclass(frozen=True)
class AdmittedHuman:
    """Person parameters admitted from a real-human bundle, without random filling."""

    id: str
    display_label: str
    age: int
    sex: str
    conditions: list[str]
    genome: dict[str, int]
    lifestyle: float
    observations: dict[str, dict[str, Any]]
    model_parameters: dict[str, float]
    source_class: str = "REAL_HUMAN"
    reference_source_id: str | None = None
    resolved_context: Any = None

    def label(self) -> str:
        return self.display_label

    def metabolic_profile(self, _knowledge_base: object):
        from .clinical_parameters import initialize_profile

        return initialize_profile(self)[0]

    def parameter_provenance(self) -> dict[str, dict[str, Any]]:
        from .clinical_parameters import initialize_profile

        return initialize_profile(self)[1]


class SubjectRegistry:
    """SQLite index plus AES-GCM encrypted JSON payloads."""

    def __init__(self, path: str | Path, *, key: bytes) -> None:
        if len(key) != 32:
            raise ValueError("subject registry key must contain exactly 32 bytes")
        self.path = Path(path)
        self.key = key
        from .registry_bootstrap import prepare_storage
        self._storage_identity = prepare_storage(self.path)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        from .registry_bootstrap import guard_storage
        guard_storage(self.path, expected=self._storage_identity)
        connection = sqlite3.connect(self.path, timeout=5.0)
        try:
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute("PRAGMA foreign_keys=ON")
            guard_storage(self.path, expected=self._storage_identity)
            return connection
        except BaseException:
            connection.close()
            raise

    def _initialize(self) -> None:
        from ..build_info import build_identity
        from .registry_bootstrap import RegistryBootstrap
        identity = build_identity()
        locking = RegistryBootstrap(path=self.path, data_key=self.key, store_id=str(uuid.uuid4()), process_instance=identity["process_instance"], source_sha256=identity["source_sha256"])
        with locking.locked():
            self._initialize_locked(identity)

    def _initialize_locked(self, identity: dict[str, Any]) -> None:
        # All commit boundaries below are explicit. A connection lost after an
        # acknowledged-on-disk commit must not be re-entered by __exit__ and
        # replace the result of exact durable-graph verification.
        with closing(self._connect()) as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS records(
                  record_id TEXT PRIMARY KEY,
                  record_type TEXT NOT NULL,
                  source_class TEXT NOT NULL,
                  lifecycle TEXT NOT NULL,
                  version INTEGER NOT NULL,
                  idempotency_key TEXT UNIQUE,
                  request_hash TEXT NOT NULL,
                  created_at TEXT NOT NULL,
                  updated_at TEXT NOT NULL,
                  nonce BLOB NOT NULL,
                  ciphertext BLOB NOT NULL
                );
                CREATE INDEX IF NOT EXISTS records_type_updated
                  ON records(record_type, updated_at DESC);
                CREATE INDEX IF NOT EXISTS records_type_created_id
                  ON records(record_type, created_at DESC, record_id DESC);
                CREATE TABLE IF NOT EXISTS registry_state(
                  state_key TEXT PRIMARY KEY,
                  state_value TEXT NOT NULL,
                  updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS physical_device_bindings(
                  device_fingerprint TEXT PRIMARY KEY,
                  twin_id TEXT NOT NULL,
                  bound_at TEXT NOT NULL,
                  FOREIGN KEY(twin_id) REFERENCES records(record_id) ON DELETE CASCADE
                );
                CREATE TABLE IF NOT EXISTS subject_identifiers(
                  subject_fingerprint TEXT PRIMARY KEY,
                  twin_id TEXT NOT NULL UNIQUE,
                  created_at TEXT NOT NULL,
                  FOREIGN KEY(twin_id) REFERENCES records(record_id) ON DELETE CASCADE
                );
                """
            )
            from .registry_audit import RegistryAudit
            from .registry_bootstrap import RegistryBootstrap
            connection.execute("INSERT OR IGNORE INTO registry_state VALUES('registry_store_id',?,?)", (str(uuid.uuid4()), _now()))
            store_id = connection.execute("SELECT state_value FROM registry_state WHERE state_key='registry_store_id'").fetchone()[0]
            self.audit = RegistryAudit(key=self.key, store_id=store_id, process_instance=identity["process_instance"], source_sha256=identity["source_sha256"])
            self.audit.initialize(connection)
            self.bootstrap = RegistryBootstrap(path=self.path, data_key=self.key, store_id=store_id, process_instance=identity["process_instance"], source_sha256=identity["source_sha256"])
            self.bootstrap.initialize_tables(connection)
            connection.commit()
            established = self._initialize_authority(connection)
            self.audit.authority_check = lambda conn: self.bootstrap.assert_authority(conn, self.audit)
        # A marked or already-audited reopen retains the original constructor's
        # migration checks, but never uses a provisional candidate-key BEGIN.
        if not established:
            with self._audited("inspect") as connection:
                self._migrate_subject_index(connection)

    def _check_migration_bounds(self, connection: sqlite3.Connection) -> None:
        from .registry_bootstrap import MAX_MIGRATION_BYTES, MAX_MIGRATION_TWINS, RegistryBootstrapError
        count, size = connection.execute("SELECT COUNT(*),COALESCE(SUM(LENGTH(ciphertext)),0) FROM records WHERE record_type='TWIN'").fetchone()
        if count > MAX_MIGRATION_TWINS or size > MAX_MIGRATION_BYTES:
            raise RegistryBootstrapError("MIGRATION_REVIEW_REQUIRED")

    def _migrate_subject_index(self, connection: sqlite3.Connection) -> None:
        self._check_migration_bounds(connection)
        for row in connection.execute("SELECT * FROM records WHERE record_type='TWIN' ORDER BY created_at,record_id"):
            record = self._open(row)
            fingerprint = self._fingerprint(record["subject_id"])
            bound = connection.execute("SELECT twin_id FROM subject_identifiers WHERE subject_fingerprint=?", (fingerprint,)).fetchone()
            if bound is not None and bound["twin_id"] != row["record_id"]:
                raise RuntimeError("subject registry contains duplicate pseudonymous subjects")
            connection.execute("INSERT OR IGNORE INTO subject_identifiers(subject_fingerprint,twin_id,created_at) VALUES(?,?,?)", (fingerprint, row["record_id"], row["created_at"]))

    def _initialize_authority(self, connection: sqlite3.Connection, *, adopt: bool = False) -> bool:
        from .registry_bootstrap import MAX_WITNESS_BYTES, RegistryBootstrapError, record_witness
        try:
            token = self.bootstrap.assert_authority(connection, self.audit)
        except RegistryBootstrapError as error:
            if error.code != "REGISTRY_BOOTSTRAP_REQUIRED":
                raise
            token = None
        if token is not None and (not adopt or token.startswith("proof:")):
            connection.commit()
            return False
        # Existing-audit adoption is explicit. Authenticate the old audit before
        # allocating a bootstrap key, attempt, or migration authority.
        if adopt and (token is None or not token.startswith("legacy:")):
            raise RegistryBootstrapError()
        self.bootstrap.ensure_identity(connection)
        self.bootstrap.complete_interrupted(connection)
        reservation = self.bootstrap.begin(connection, action="ADOPT_EXISTING_AUDIT" if adopt else "INITIALIZE")
        connection.commit()
        stage = "KEY_OR_RECORD_UNVERIFIABLE"
        attempted_commit = False
        proof_id = None
        try:
            connection.execute("BEGIN IMMEDIATE")
            self.bootstrap.ensure_identity(connection)
            if adopt:
                self.audit.verify_existing(connection)
                row = connection.execute("SELECT * FROM registry_audit ORDER BY sequence LIMIT 1").fetchone()
                witness, proof_kind = record_witness(row, audit=True), "EXISTING_AUDIT"
            else:
                self._check_migration_bounds(connection)
                row = connection.execute("SELECT * FROM records ORDER BY record_id LIMIT 1").fetchone()
                witness, proof_kind = None, "EMPTY_ESTABLISHMENT"
                if row is not None:
                    if len(row["ciphertext"]) > MAX_WITNESS_BYTES:
                        raise RegistryBootstrapError("MIGRATION_REVIEW_REQUIRED")
                    if not isinstance(self._open(row), dict):
                        raise RegistryBootstrapError()
                    witness, proof_kind = record_witness(row), "LEGACY_WITNESS"
                stage = "MIGRATION_FAILED"
                self._migrate_subject_index(connection)
            proof_id = self.bootstrap.establish(connection, reservation, proof_kind=proof_kind, witness=witness)
            attempted_commit = True
            connection.commit()
            return True
        except BaseException as original:
            try:
                pending_transaction = connection.in_transaction
            except Exception:
                pending_transaction = None
            if attempted_commit and pending_transaction is not True:
                # Never blindly replay a possibly committed initialization.
                try:
                    with closing(self._connect()) as check:
                        token = self.bootstrap.assert_authority(check, self.audit)
                        result = check.execute("SELECT result_event_id FROM registry_bootstrap_attempts WHERE begin_event_id=? AND request_id=?", (reservation["event_id"], reservation["request_id"])).fetchone()
                        if token.startswith(f"proof:{proof_id}:") and result and result[0]:
                            return True
                except Exception:
                    pass
                raise RegistryBootstrapError("BOOTSTRAP_COMMIT_UNCONFIRMED") from original
            try:
                connection.rollback()
            except Exception as error:
                raise RegistryBootstrapError("BOOTSTRAP_COMMIT_UNCONFIRMED") from error
            try:
                self.bootstrap.finish(connection, reservation, outcome_code=stage)
                connection.commit()
            except Exception:
                try:
                    connection.rollback()
                except Exception:
                    # Retain the original verification error and the durable
                    # unresolved BEGIN when its terminal storage is unavailable.
                    pass
            raise

    def adopt_audit_authority(self) -> None:
        """Explicit local adoption of an authentic existing normal audit, not repair."""
        with self.bootstrap.locked(), closing(self._connect()) as connection:
            self._initialize_authority(connection, adopt=True)

    def _seal(self, record_id: str, payload: dict[str, Any]) -> tuple[bytes, bytes]:
        nonce = uuid.uuid4().bytes[:12]
        plaintext = json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
        return nonce, AESGCM(self.key).encrypt(nonce, plaintext, _AAD + record_id.encode("utf-8"))

    @staticmethod
    def _fingerprint(value: str) -> str:
        return hashlib.sha256(value.encode("utf-8")).hexdigest()

    def _open(self, row: sqlite3.Row) -> dict[str, Any]:
        plaintext = AESGCM(self.key).decrypt(
            bytes(row["nonce"]), bytes(row["ciphertext"]), _AAD + str(row["record_id"]).encode("utf-8"),
        )
        record = json.loads(plaintext)
        if isinstance(record, dict) and isinstance(record.get("patch_bindings"), list):
            from ..life_patch.physical_binding import BINDING_SCHEMA, PhysicalBindingError, validate_stored_binding
            for binding in record["patch_bindings"]:
                if isinstance(binding, dict) and binding.get("schema") == BINDING_SCHEMA:
                    try:
                        validate_stored_binding(binding)
                    except PhysicalBindingError:
                        raise _transition_error() from None
        return record

    @contextmanager
    def _audited(self, action: str, record_id: str | None = None, *, schema: str = "livemore.subject-access-audit.v1", request_id: str | None = None):
        """Own one access transaction; a successful result commits with its write."""
        if request_id is None:
            request_id = str(uuid.uuid4())
        try:
            if not isinstance(request_id, str) or str(uuid.UUID(request_id)) != request_id:
                raise ValueError
        except ValueError as error:
            raise SubjectRegistryError("INVALID_REQUEST_ID", "Access request identity must be a canonical UUID.") from error
        connection = self._connect()
        reservation = None
        try:
            reservation = self.audit.begin(connection, request_id=request_id, action=action, opaque_record_id=record_id, schema=schema)
            connection.commit()
            connection.execute("BEGIN IMMEDIATE")
            self.audit.check_authority(connection, reservation)
            yield connection
            self.audit.finish(connection, reservation, outcome_code="SUCCESS")
            connection.commit()
        except BaseException:
            connection.rollback()
            if reservation is not None:
                try:
                    self.audit.finish(connection, reservation, outcome_code="ACCESS_FAILED")
                    connection.commit()
                except Exception:
                    # The immutable begin retains the reserved terminal; preserve
                    # the original error, and never return a successful access.
                    connection.rollback()
            raise
        finally:
            connection.close()

    def _match_real_retry(self, row: sqlite3.Row, payload: dict[str, Any], record_type: str,
                          key: str, expected_hash: str | None = None) -> dict[str, Any]:
        if row["record_type"] != record_type:
            raise SubjectRegistryError("IDEMPOTENCY_CONFLICT", "The key identifies a different request.")
        record = self._open(row)
        try:
            fields = _intent(record_type, record)
            ident = record.get("creation_identity")
            if (record.get("schema") != ("livemore.twin-record.v1" if record_type == "TWIN" else "livemore.cohort-record.v1")
                    or record.get("source_class") != "REAL_HUMAN"
                    or record.get("twin_id" if record_type == "TWIN" else "cohort_id") != row["record_id"]):
                raise ValueError
            if "creation_identity" in record:
                valid = _creation_identity(record_type, fields, key)
                if not isinstance(ident, dict) or ident.get("schema") != valid["schema"] or ident.get("normalizer_id") != _NORMALIZER or set(ident) != set(valid):
                    raise ValueError
                if ident != valid or row["request_hash"] != valid["request_sha256"] or row["idempotency_key"] != key:
                    raise SubjectRegistryError("IDEMPOTENCY_CONFLICT", "Stored request identity does not match the key.")
            else:
                historical = dict(fields)
                if record_type == "TWIN":
                    if not isinstance(record.get("parameter_provenance"), dict):
                        raise ValueError
                    historical["parameter_provenance"] = record["parameter_provenance"]
                if _request_hash(historical) != row["request_hash"]:
                    raise ValueError
            if _canonical(fields) != _canonical(payload) or (expected_hash is not None and expected_hash != row["request_hash"]):
                raise SubjectRegistryError("IDEMPOTENCY_CONFLICT", "The key identifies a different request.")
            return record
        except SubjectRegistryError:
            raise
        except (ValueError, KeyError, TypeError) as error:
            raise SubjectRegistryError("LEGACY_IDEMPOTENCY_UNVERIFIABLE", "The historical request identity cannot be verified without rewriting it.") from error

    def _real_idempotent(self, key: str | None, payload: dict[str, Any], record_type: str) -> dict[str, Any] | None:
        if not key:
            return None
        with self._audited("create_twin" if record_type == "TWIN" else "create_cohort") as connection:
            row = connection.execute("SELECT * FROM records WHERE idempotency_key=?", (key,)).fetchone()
            return self._match_real_retry(row, payload, record_type, key) if row else None

    def _idempotent(self, key: str | None, request_hash: str) -> dict[str, Any] | None:
        if not key:
            return None
        with self._audited("inspect") as connection:
            row = connection.execute(
                "SELECT * FROM records WHERE idempotency_key = ?", (key,),
            ).fetchone()
            if row is None:
                return None
            if row["request_hash"] != request_hash:
                raise SubjectRegistryError("IDEMPOTENCY_CONFLICT", "idempotency key was already used for a different request")
            return self._open(row)

    def create_twin(self, body: object, *, idempotency_key: str | None = None) -> dict[str, Any]:
        if not isinstance(body, dict):
            raise SubjectRegistryError("INVALID_TWIN_DATA", "request body must be a JSON object")
        source_class = str(body.get("source_class", "")).strip().upper()
        if source_class == "REAL_HUMAN" and _RESERVED.intersection(body):
            raise SubjectRegistryError("INVALID_TWIN_DATA", "The request contains server-owned fields.")
        if idempotency_key is not None and (not isinstance(idempotency_key, str) or not 1 <= len(idempotency_key) <= 200):
            raise SubjectRegistryError("INVALID_TWIN_DATA", "Invalid idempotency key.")
        if source_class not in _SOURCE_CLASSES:
            raise SubjectRegistryError(
                "INVALID_SOURCE_CLASS",
                "source_class must be REAL_HUMAN, SYNTHETIC, or REFERENCE_GROUNDED_SYNTHETIC",
            )
        subject_id = _bounded_string(body.get("subject_id"), "subject_id", maximum=96)
        if not subject_id.startswith("pseudonym-"):
            raise SubjectRegistryError("INVALID_SUBJECT_ID", "subject_id must use the opaque pseudonym- namespace")
        display_label = _bounded_string(body.get("display_label"), "display_label", maximum=80)
        reference_source: dict[str, Any] | None = None
        reference_stratum: str | None = None
        reference_lineage: dict[str, Any] | None = None
        generation_seed: int | None = None
        if source_class == "REFERENCE_GROUNDED_SYNTHETIC":
            reference_source = normalize_reference_source(body.get("reference_source"), error=SubjectRegistryError)
            reference_stratum = _bounded_string(body.get("stratum"), "stratum", maximum=100)
            generation_seed = int(_finite(body.get("seed", 0), "seed", 0, 2**31 - 1))
            member = generate_members(
                size=1,
                seed=generation_seed,
                stratum=reference_stratum,
                source=reference_source,
                error=SubjectRegistryError,
            )[0]
            body = {
                **body,
                "demographics": {"age": member["age"], "sex": member["sex"]},
                "conditions": member["conditions"],
                "genome": member["genome"],
                "lifestyle": member["lifestyle"],
                "model_parameters": member["model_parameters"],
                "observations": {},
                "medications": [],
                "environment": {},
            }
            reference_lineage = member["source_lineage"]
        consent_scope = _bounded_list(body.get("consent_scope"), "consent_scope")
        chain_of_custody = str(body.get("chain_of_custody", "")).strip()
        if len(chain_of_custody) > 256:
            raise SubjectRegistryError(
                "INVALID_TWIN_DATA", "chain_of_custody must contain at most 256 characters",
            )
        observations = _validate_observations(body.get("observations"))
        if source_class == "REAL_HUMAN":
            if not consent_scope:
                raise SubjectRegistryError("CONSENT_REQUIRED", "real-human twin requires explicit consent scope")
            if not chain_of_custody:
                raise SubjectRegistryError("CHAIN_OF_CUSTODY_REQUIRED", "real-human twin requires chain of custody")
            if not observations:
                raise SubjectRegistryError("TWIN_DATA_REQUIRED", "real-human twin requires admitted observations")
        demographics = body.get("demographics") or {}
        if not isinstance(demographics, dict):
            raise SubjectRegistryError("INVALID_TWIN_DATA", "demographics must be an object")
        if source_class == "REAL_HUMAN" and (
            demographics.get("age") is None or not str(demographics.get("sex", "")).strip()
        ):
            raise SubjectRegistryError(
                "PROFILE_COVERAGE_INSUFFICIENT",
                "real-human admission requires explicit age and sex; model defaults are not permitted",
            )
        age = int(_finite(demographics.get("age", 45), "age", 0, 120))
        sex = _bounded_string(demographics.get("sex", "U"), "sex", maximum=24)
        conditions = _bounded_list(body.get("conditions"), "conditions", maximum=30)
        raw_genome = body.get("genome") or {}
        if not isinstance(raw_genome, dict) or len(raw_genome) > 200:
            raise SubjectRegistryError("INVALID_TWIN_DATA", "genome must be an object with at most 200 entries")
        genome = {}
        for key, value in raw_genome.items():
            dose = _finite(value, "allele dose", 0, 2)
            if not dose.is_integer():
                raise SubjectRegistryError("INVALID_TWIN_DATA", "allele dose must be an integer")
            genome[_bounded_string(key, "genome key", maximum=80)] = int(dose)
        raw_lifestyle = body.get("lifestyle", 0.6)
        if isinstance(raw_lifestyle, dict):
            if len(raw_lifestyle) > 30:
                raise SubjectRegistryError("INVALID_TWIN_DATA", "lifestyle must contain at most 30 fields")
            lifestyle_profile = {
                _bounded_string(key, "lifestyle field", maximum=80): (
                    _finite(value, f"lifestyle.{key}", 0, 1)
                    if isinstance(value, (int, float)) and not isinstance(value, bool)
                    else _bounded_string(value, f"lifestyle.{key}", maximum=120)
                )
                for key, value in raw_lifestyle.items()
            }
            lifestyle = _finite(lifestyle_profile.get("activity_index"), "lifestyle.activity_index", 0, 1)
        else:
            lifestyle = _finite(raw_lifestyle, "lifestyle", 0, 1)
            lifestyle_profile = {"activity_index": lifestyle}
        medications = validate_medications(body.get("medications"), error=SubjectRegistryError)
        environment = validate_environment(body.get("environment"), error=SubjectRegistryError)
        profile_sources = normalize_profile_sources(
            body.get("profile_sources"),
            source_class=source_class,
            chain_of_custody=chain_of_custody,
            observations_present=bool(observations),
            error=SubjectRegistryError,
        )
        profile_coverage, field_provenance = build_profile_provenance(
            sources=profile_sources,
            conditions=conditions,
            medications=medications,
            observations=observations,
            genome=genome,
            admitted_domain_presence={
                "demographics": "demographics" in body,
                "conditions": "conditions" in body,
                "medications": "medications" in body,
                "labs": bool(observations),
                "physiology": bool(observations),
                "genomics": "genome" in body,
                "lifestyle": "lifestyle" in body,
                "environment": bool(environment),
            },
            source_class=source_class,
        )
        if source_class == "REFERENCE_GROUNDED_SYNTHETIC":
            profile_coverage = {
                "status": "REFERENCE_INITIALIZED",
                "domains": ["conditions", "demographics", "genomics", "lifestyle", "model_parameters"],
                "missing_core_domains": ["environment", "labs", "medications", "physiology"],
                "source_count": 1,
            }
            field_provenance = {
                field: {
                    "source_id": reference_source["source_id"],
                    "evidence_class": "REFERENCE_INITIALIZED",
                }
                for field in (
                    "demographics.age", "demographics.sex", "conditions", "genome",
                    "lifestyle", "model_parameters",
                )
            }
        raw_parameters = body.get("model_parameters") or {}
        if not isinstance(raw_parameters, dict):
            raise SubjectRegistryError("INVALID_TWIN_DATA", "model_parameters must be an object")
        from .clinical_parameters import MODEL_PARAMETER_NAMES, validate_model_parameters

        model_parameters = {
            str(key): _finite(value, f"model_parameters.{key}", -1e9, 1e9)
            for key, value in raw_parameters.items()
            if str(key) in MODEL_PARAMETER_NAMES
        }

        try:
            model_parameters = validate_model_parameters(model_parameters)
        except ValueError as error:
            raise SubjectRegistryError("INVALID_MODEL_PARAMETER", str(error)) from error
        normalized = {
            "source_class": source_class,
            "subject_id": subject_id,
            "display_label": display_label,
            "consent_scope": consent_scope,
            "chain_of_custody": chain_of_custody,
            "demographics": {"age": age, "sex": sex},
            "conditions": conditions,
            "medications": medications,
            "genome": genome,
            "lifestyle": lifestyle,
            "lifestyle_profile": lifestyle_profile,
            "environment": environment,
            "observations": observations,
            "model_parameters": model_parameters,
            "profile_sources": profile_sources,
            "profile_coverage": profile_coverage,
            "field_provenance": field_provenance,
            "reference_source": reference_source,
            "reference_stratum": reference_stratum,
            "reference_lineage": reference_lineage,
            "generation_seed": generation_seed,
        }
        if source_class == "REAL_HUMAN":
            from .clinical_parameters import validate_clinical_inputs
            try:
                validate_clinical_inputs(observations=observations, model_parameters=model_parameters)
            except ValueError as error:
                raise SubjectRegistryError("INVALID_MODEL_INITIALIZATION", str(error)) from error
            existing = self._real_idempotent(idempotency_key, normalized, "TWIN")
            if existing is not None:
                return existing
        elif source_class != "SYNTHETIC":
            try:
                normalized["parameter_provenance"] = self.admitted_human(normalized).parameter_provenance()
            except ValueError as error:
                raise SubjectRegistryError("INVALID_MODEL_INITIALIZATION", str(error)) from error
        identity = _creation_identity("TWIN", normalized, idempotency_key) if source_class == "REAL_HUMAN" else None
        request_hash = identity["request_sha256"] if identity else _request_hash(normalized)
        existing = None if identity else self._idempotent(idempotency_key, request_hash)
        if existing is not None:
            return existing
        created_at = _now()
        record = {
            "schema": "livemore.twin-record.v1",
            "twin_id": f"twin-{uuid.uuid4().hex}",
            **normalized,
            "lifecycle": "DATA_ADMITTED",
            "version": 1,
            "created_at": created_at,
            "updated_at": created_at,
            "patch_bindings": [],
        }
        if identity:
            record.update(creation_identity=identity, model_binding=None)
        return self._insert_or_existing("TWIN", record, request_hash, idempotency_key)

    def _insert(self, record_type: str, record: dict[str, Any], request_hash: str, idempotency_key: str | None) -> None:
        with self._audited("create_twin" if record_type == "TWIN" else "create_cohort") as connection:
            self._insert_connection(connection, record_type, record, request_hash, idempotency_key)

    def _insert_connection(self, connection: sqlite3.Connection, record_type: str, record: dict[str, Any], request_hash: str, idempotency_key: str | None) -> None:
        record_id = str(record["twin_id"] if record_type == "TWIN" else record["cohort_id"])
        nonce, ciphertext = self._seal(record_id, record)
        connection.execute(
                """INSERT INTO records(record_id, record_type, source_class, lifecycle,
                   version, idempotency_key, request_hash, created_at, updated_at, nonce, ciphertext)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (record_id, record_type, record["source_class"], record["lifecycle"],
                 record["version"], idempotency_key, request_hash, record["created_at"],
                 record["updated_at"], nonce, ciphertext),
            )
        if record_type == "TWIN":
            connection.execute(
                    """INSERT INTO subject_identifiers(subject_fingerprint, twin_id, created_at)
                       VALUES(?,?,?)""",
                    (self._fingerprint(record["subject_id"]), record_id, record["created_at"]),
                )

    def _subject_exists(self, subject_id: str) -> bool:
        with closing(self._connect()) as connection, connection:
            row = connection.execute(
                "SELECT 1 FROM subject_identifiers WHERE subject_fingerprint = ?",
                (self._fingerprint(subject_id),),
            ).fetchone()
        return row is not None

    def _insert_or_existing(
        self,
        record_type: str,
        record: dict[str, Any],
        request_hash: str,
        idempotency_key: str | None,
    ) -> dict[str, Any]:
        """Resolve concurrent retries to one record without hiding other database failures."""
        try:
            self._insert(record_type, record, request_hash, idempotency_key)
            return record
        except sqlite3.IntegrityError as error:
            if idempotency_key is not None:
                if record.get("source_class") == "REAL_HUMAN":
                    with self._audited("create_twin" if record_type == "TWIN" else "create_cohort") as connection:
                        row = connection.execute("SELECT * FROM records WHERE idempotency_key=?", (idempotency_key,)).fetchone()
                        existing = self._match_real_retry(row, _intent(record_type, record), record_type, idempotency_key, request_hash) if row else None
                else:
                    existing = self._idempotent(idempotency_key, request_hash)
                if existing is not None:
                    return existing
            if record_type == "TWIN" and self._subject_exists(record["subject_id"]):
                raise SubjectRegistryError(
                    "DUPLICATE_SUBJECT",
                    "subject_id is already bound to a governed twin; update that record instead",
                ) from error
            raise

    def _get(self, record_id: str, record_type: str) -> tuple[sqlite3.Row, dict[str, Any]]:
        with self._audited("inspect", record_id) as connection:
            row = connection.execute(
                "SELECT * FROM records WHERE record_id = ? AND record_type = ?", (record_id, record_type),
            ).fetchone()
            if row is None:
                raise SubjectRegistryError("RECORD_NOT_FOUND", f"{record_type.lower()} record was not found")
            return row, self._open(row)

    def get_twin(self, twin_id: str) -> dict[str, Any]:
        return self._get(twin_id, "TWIN")[1]

    def active_twin(self) -> dict[str, Any] | None:
        """Return the persisted authoritative Aegle subject, if one was activated."""
        return self.audited_active_twin()

    def _checked_active_twin(self, connection: sqlite3.Connection) -> dict[str, Any] | None:
        """Read only inside the caller's committed-BEGIN access transaction."""
        pointer = connection.execute(
            "SELECT state_value FROM registry_state WHERE state_key='active_twin_id'",
        ).fetchone()
        if pointer is None:
            return None
        # An inner join would conflate missing/corrupted targets with the
        # explicit absence that permits an unregistered reference preview.
        row = connection.execute(
            "SELECT * FROM records WHERE record_id=?", (pointer["state_value"],),
        ).fetchone()
        if row is None or row["record_type"] != "TWIN" or row["lifecycle"] != "ACTIVE":
            raise RuntimeError("Active subject storage is inconsistent")
        record = self._open(row)
        if (
            not isinstance(record, dict)
            or record.get("schema") != "livemore.twin-record.v1"
            or record.get("twin_id") != row["record_id"]
            or type(record.get("version")) is not int
            or record["version"] < 1
            or record["version"] != row["version"]
            or record.get("lifecycle") != "ACTIVE"
            or record.get("source_class") != row["source_class"]
        ):
            raise RuntimeError("Active subject storage is inconsistent")
        return record

    def audited_active_twin(self, *, action: str = "inspect", request_id: str | None = None,
                            _checked_snapshot: bool = False) -> dict[str, Any] | None | CheckedActiveSelection:
        if type(_checked_snapshot) is not bool:
            raise _transition_error("INVALID_TWIN_DATA")
        if _checked_snapshot:
            if type(action) is not str or action not in {"inspect", "reconcile_selection"}:
                raise _transition_error("INVALID_TWIN_DATA")
            return self._checked_selection_access(request_id=request_id, action=action)
        with self._audited(action, request_id=request_id) as connection:
            return self._checked_active_twin(connection)

    def confirm_active_selection(self, *, expected_record: dict[str, Any] | None, request_id: str,
                                  _expected_snapshot: CheckedActiveSelection | None = None) -> None:
        """Confirm an exact prepared selection without changing registry state.

        The authority owner holds its locks through this call and the subsequent
        precomputed memory assignments. Any audit/commit exception means no
        confirmation; this helper never repeats a selection or releases DENY_ALL.
        """
        if not isinstance(request_id, str):
            raise SubjectRegistryError("INVALID_REQUEST_ID", "Access request identity must be a canonical UUID.")
        try:
            if expected_record is not None and not isinstance(expected_record, dict):
                raise ValueError
            expected_bytes = _canonical(expected_record)
        except (ValueError, TypeError, OverflowError) as error:
            raise SubjectRegistryError("INVALID_RECONCILIATION_SNAPSHOT", "Expected selection must be a detached canonical record or null.") from error
        if _expected_snapshot is not None:
            self._validate_checked_selection(_expected_snapshot)
            if _expected_snapshot._record_json != expected_bytes:
                raise SubjectRegistryError("INVALID_RECONCILIATION_SNAPSHOT", "Expected selection must be a detached canonical record or null.")
            self._checked_selection_access(request_id=request_id, expected=_expected_snapshot)
            return
        with self._audited("reconcile_selection", request_id=request_id) as connection:
            actual = self._checked_active_twin(connection)
            if _canonical(actual) != expected_bytes:
                raise SubjectRegistryError("SELECTION_RECONCILIATION_CONFLICT", "The authoritative selection changed; no reconciliation was confirmed.")

    def _validate_checked_selection(self, expected: CheckedActiveSelection) -> None:
        """Validate immutable metadata only; never decrypt saved clinical rows."""
        try:
            if (type(expected) is not CheckedActiveSelection
                    or type(expected.store_id) is not str or expected.store_id != self.audit.store_id
                    or type(expected.authority_token) is not str or not expected.authority_token
                    or type(expected._rows) is not tuple or len(expected._rows) > 1
                    or type(expected._active_ids) is not tuple or len(expected._active_ids) > 1
                    or any(type(ident) is not str for ident in expected._active_ids)
                    or type(expected._record_json) is not bytes):
                raise ValueError
            _transition_request(expected.request_id)
            record = json.loads(expected._record_json)
            if _canonical(record) != expected._record_json:
                raise ValueError
            if record is None:
                if expected._rows or expected._pointer is not None or expected._active_ids:
                    raise ValueError
                return
            if type(record) is not dict or len(expected._rows) != 1:
                raise ValueError
            row = expected._rows[0]
            pointer = expected._pointer
            if (type(row) is not tuple or len(row) != 11
                    or any(type(row[index]) is not str for index in (0, 1, 2, 3, 6, 7, 8))
                    or (row[5] is not None and type(row[5]) is not str)
                    or any(type(row[index]) is not bytes for index in (9, 10))
                    or type(pointer) is not tuple or len(pointer) != 3
                    or any(type(value) is not str for value in pointer)
                    or pointer[0] != "active_twin_id" or pointer[1] != row[0]
                    or not 1 <= len(pointer[2]) <= 128
                    or expected._active_ids != (row[0],)):
                raise ValueError
            _transition_target(row[0])
            _transition_read_version(row[4])
            if (row[1] != "TWIN" or row[2] not in _SOURCE_CLASSES or row[3] != "ACTIVE"
                    or record.get("schema") != "livemore.twin-record.v1"
                    or record.get("twin_id") != row[0] or type(record.get("version")) is not int
                    or any(record.get(field) != row[index] for field, index in
                           (("source_class", 2), ("lifecycle", 3), ("version", 4), ("created_at", 7), ("updated_at", 8)))
                    or type(record.get("subject_id")) is not str or not record["subject_id"]
                    or type(record.get("patch_bindings")) is not list
                    or any(type(item) is not dict or type(item.get("device_id")) is not str
                           for item in record["patch_bindings"])):
                raise ValueError
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, OverflowError, RecursionError) as error:
            raise SubjectRegistryError("INVALID_RECONCILIATION_SNAPSHOT", "Expected selection must be a detached canonical record or null.") from error

    def _checked_selection_access(self, *, request_id: str, action: str = "inspect",
                                   expected: CheckedActiveSelection | None = None) -> CheckedActiveSelection:
        if type(action) is not str or action not in {"inspect", "reconcile_selection"}:
            raise _transition_error("INVALID_TWIN_DATA")
        request_id = _transition_request(request_id)
        if expected is not None:
            self._validate_checked_selection(expected)
        with self._selection_read_access(target_id=None, device_fingerprint=None, request_id=request_id,
                                         action=action if expected is None else "reconcile_selection",
                                         schema="livemore.subject-access-audit.v1") as (connection, token):
            # Adoption during preparation rejects before any protected decrypt.
            # Capture and confirmation may deliberately use different access UUIDs.
            if expected is not None and expected.authority_token != token:
                raise SubjectRegistryError("SELECTION_RECONCILIATION_CONFLICT", "The authoritative selection changed; no reconciliation was confirmed.")
            saved, records_json, pointer, _device = self._transition_snapshot(connection, None, None)
            record = json.loads(records_json).get(pointer[1]) if pointer else None
            result = CheckedActiveSelection(self.audit.store_id, token, request_id, saved, pointer,
                                             (pointer[1],) if pointer else (), _canonical(record))
            try:
                self._validate_checked_selection(result)
            except SubjectRegistryError as error:
                raise _transition_error() from error
            if expected is not None and (
                    result.store_id != expected.store_id or result._rows != expected._rows
                    or result._pointer != expected._pointer or result._active_ids != expected._active_ids
                    or result._record_json != expected._record_json):
                raise SubjectRegistryError("SELECTION_RECONCILIATION_CONFLICT", "The authoritative selection changed; no reconciliation was confirmed.")
        # The fixed owner completes its last-write checks, commit and close first.
        return result

    def list_twins(self) -> list[dict[str, Any]]:
        return self._list("TWIN")

    def list_cohorts(self) -> list[dict[str, Any]]:
        return self._list("COHORT")

    def page_records(
        self, record_type: str, *, limit: int = 25, cursor: str | None = None,
        q: str = "",
    ) -> dict[str, Any]:
        """Bounded local search. Labels stay encrypted; cursor never contains the query.

        Immutable creation ordering avoids moving records between pages on activation.
        Search scans at most 500 encrypted records per call and explicitly continues
        when that budget is reached, even if the current page has no matches.
        """
        if record_type not in {"TWIN", "COHORT"}:
            raise SubjectRegistryError("INVALID_PAGE", "unsupported record type")
        if type(limit) is not int or not 1 <= limit <= 50:
            raise SubjectRegistryError("INVALID_PAGE", "page size must be 1 to 50")
        if not isinstance(q, str) or len(q) > 120:
            raise SubjectRegistryError("INVALID_PAGE", "search must contain at most 120 characters")
        query = q.strip().casefold()
        digest = hashlib.sha256(query.encode()).hexdigest()
        before = self._page_cursor(cursor, record_type, digest) if cursor else None
        sql = "SELECT * FROM records WHERE record_type = ?"
        params: list[Any] = [record_type]
        if before:
            sql += " AND (created_at < ? OR (created_at = ? AND record_id < ?))"
            params.extend([before[0], before[0], before[1]])
        scan_limit = 500 if query else limit
        sql += " ORDER BY created_at DESC, record_id DESC LIMIT ?"
        params.append(scan_limit + 1)
        with self._audited("inspect") as connection:
            rows = connection.execute(sql, params).fetchall()
            total = None if query else connection.execute(
                "SELECT COUNT(*) FROM records WHERE record_type = ?", (record_type,),
            ).fetchone()[0]
            records: list[dict[str, Any]] = []
            last = before
            has_more = False
            for row in rows[:scan_limit]:
                record = self._open(row)
                fields = ("display_label", "name", "subject_id", "twin_id", "cohort_id",
                          "source_class", "stratum", "indication")
                matches = not query or any(query in str(record.get(field, "")).casefold() for field in fields)
                if matches and len(records) == limit:
                    has_more = True
                    break
                if matches:
                    records.append(record)
                last = (row["created_at"], row["record_id"])
            else:
                has_more = len(rows) > scan_limit
            next_cursor = self._make_page_cursor(record_type, digest, last) if has_more and last else None
            return {"records": records, "pagination": {
                "limit": limit, "total": total, "has_more": has_more,
                "next_cursor": next_cursor,
                "search_incomplete": bool(query and has_more and len(records) < limit),
            }}

    def _make_page_cursor(self, record_type: str, query_digest: str, before: tuple[str, str]) -> str:
        body = json.dumps([1, record_type, query_digest, list(before)], separators=(",", ":")).encode()
        signature = hmac.digest(self.key, b"subject-page-v1:" + body, "sha256")
        return base64.urlsafe_b64encode(body + signature).decode().rstrip("=")

    def _page_cursor(self, cursor: str, record_type: str, query_digest: str) -> tuple[str, str]:
        try:
            if not isinstance(cursor, str) or not 1 <= len(cursor) <= 1024:
                raise ValueError("invalid length")
            raw = base64.b64decode(cursor + "=" * (-len(cursor) % 4), altchars=b"-_", validate=True)
            body, signature = raw[:-32], raw[-32:]
            if not hmac.compare_digest(signature, hmac.digest(self.key, b"subject-page-v1:" + body, "sha256")):
                raise ValueError("invalid signature")
            value = json.loads(body)
            if (not isinstance(value, list) or len(value) != 4 or value[:3] != [1, record_type, query_digest]
                    or not isinstance(value[3], list) or len(value[3]) != 2
                    or any(not isinstance(item, str) or not 1 <= len(item) <= 100 for item in value[3])):
                raise ValueError("invalid context")
            return tuple(value[3])
        except (ValueError, TypeError, UnicodeError) as error:
            raise SubjectRegistryError("INVALID_PAGE", "page cursor is invalid; refresh the list") from error

    @staticmethod
    def _transition_topology(connection: sqlite3.Connection) -> tuple | None:
        pointer_row = connection.execute("SELECT * FROM registry_state WHERE state_key='active_twin_id'").fetchone()
        pointer = tuple(pointer_row) if pointer_row is not None else None
        active_ids = tuple(row[0] for row in connection.execute("SELECT record_id FROM records WHERE record_type='TWIN' AND lifecycle='ACTIVE' ORDER BY record_id LIMIT 2"))
        if active_ids != ((pointer[1],) if pointer else ()):
            raise _transition_error()
        return pointer

    def _transition_snapshot(self, connection: sqlite3.Connection, target: str | None,
                             device_fingerprint: str | None) -> tuple[tuple, bytes, tuple | None, tuple | None]:
        if not connection.in_transaction:
            raise _transition_error()
        pointer = self._transition_topology(connection)
        identities = sorted({ident for ident in (target, pointer[1] if pointer else None) if ident is not None})
        saved = []
        records = {}
        for ident in identities:
            row = connection.execute("SELECT * FROM records WHERE record_id=?", (ident,)).fetchone()
            if row is None:
                if pointer and pointer[1] == ident: raise _transition_error()
                raise SubjectRegistryError("RECORD_NOT_FOUND", "Twin record was not found.")
            _transition_read_version(row["version"])
            if row["record_type"] != "TWIN" or row["source_class"] not in _SOURCE_CLASSES or row["lifecycle"] not in {"ACTIVE", "DATA_ADMITTED"}:
                raise _transition_error()
            record = self._open(row)
            if (type(record) is not dict or record.get("schema") != "livemore.twin-record.v1"
                    or record.get("twin_id") != ident or type(record.get("version")) is not int
                    or any(record.get(field) != row[field] for field in ("version", "source_class", "lifecycle", "created_at", "updated_at"))
                    or type(record.get("subject_id")) is not str or not record["subject_id"]
                    or type(record.get("patch_bindings")) is not list
                    or any(type(item) is not dict or type(item.get("device_id")) is not str for item in record["patch_bindings"])):
                raise _transition_error()
            saved.append(tuple(row)); records[ident] = record
        device = connection.execute("SELECT * FROM physical_device_bindings WHERE device_fingerprint=?", (device_fingerprint,)).fetchone() if device_fingerprint else None
        return tuple(saved), _canonical(records), pointer, tuple(device) if device is not None else None

    def _prepare_transition(self, kind: str, target: str | None, expected_version: int | None,
                            binding: dict[str, Any] | None, request_id: str) -> PreparedRegistryTransition:
        request_id = _transition_request(request_id)
        fingerprint = self._fingerprint(binding["device_id"]) if binding else None
        physical = binding is not None and binding["mode"] == "physical"
        with self._selection_read_access(target_id=target, device_fingerprint=fingerprint,
                                         action="bind" if physical else "inspect",
                                         schema="livemore.physical-access-audit.v1" if physical else "livemore.subject-access-audit.v1",
                                         request_id=request_id) as (connection, token):
            saved, before_json, pointer, device = self._transition_snapshot(connection, target, fingerprint)
        # The caller may still hold source authority here. Preparation remains
        # purely structural even after this audited connection has closed.
        before = json.loads(before_json)
        if target is not None and before[target]["version"] != expected_version:
            raise _transition_error("TWIN_VERSION_CONFLICT")
        if kind == "activate": _activation_transition_admission(before[target])
        timestamp = _now()
        after, next_pointer, next_device = _transition_changes(kind, before, pointer, device, target, binding, timestamp)
        return PreparedRegistryTransition(kind, self.audit.store_id, token, request_id, target, timestamp,
                                          saved, before_json, _canonical(after), pointer, next_pointer,
                                          device, next_device, _canonical(binding))

    def prepare_activation(self, twin_id: str, *, expected_version: int, request_id: str) -> PreparedRegistryTransition:
        _transition_version(expected_version)
        return self._prepare_transition("activate", _transition_target(twin_id), expected_version, None, request_id)

    def prepare_observation_selection(self, twin_id: str, *, expected_version: int, request_id: str) -> PreparedRegistryTransition:
        _transition_version(expected_version)
        return self._prepare_transition("select_observations", _transition_target(twin_id), expected_version, None, request_id)

    def prepare_patch_binding(self, twin_id: str, body: object, *, expected_version: int, request_id: str) -> PreparedRegistryTransition:
        _transition_version(expected_version)
        binding = _normalize_transition_binding(body, expected_version)
        return self._prepare_transition("bind", _transition_target(twin_id), expected_version, binding, request_id)

    def prepare_registered_physical_v3_binding(self, twin_id: str, body: object, *, inspection: object,
                                             expected_version: int, request_id: str) -> PreparedRegistryTransition:
        """Internal structure only; the future route must own fresh peer inspection."""
        from ..life_patch.physical_binding import PhysicalBindingError, normalize_registered_binding
        _transition_version(expected_version)
        try:
            binding = normalize_registered_binding(body, inspection, expected_version)
        except PhysicalBindingError:
            raise _transition_error("INVALID_PATCH_BINDING") from None
        return self._prepare_transition("bind", _transition_target(twin_id), expected_version, binding, request_id)

    def prepare_preview_clear(self, *, request_id: str) -> PreparedRegistryTransition:
        return self._prepare_transition("clear_for_preview", None, None, None, request_id)

    def _validate_transition(self, prepared: PreparedRegistryTransition) -> tuple[dict, dict, dict | None]:
        try:
            if type(prepared) is not PreparedRegistryTransition or prepared.kind not in {"activate", "bind", "clear_for_preview", "select_observations"}:
                raise ValueError
            _transition_request(prepared.request_id)
            if prepared.store_id != self.audit.store_id or type(prepared.authority_token) is not str or not prepared.authority_token:
                raise ValueError
            if prepared.kind == "clear_for_preview":
                if prepared.target_id is not None: raise ValueError
            else:
                _transition_target(prepared.target_id)
            if type(prepared.timestamp) is not str or datetime.fromisoformat(prepared.timestamp.replace("Z", "+00:00")).isoformat().replace("+00:00", "Z") != prepared.timestamp:
                raise ValueError
            if not prepared.timestamp.endswith("Z"): raise ValueError
            if type(prepared._rows) is not tuple or len(prepared._rows) > 2:
                raise ValueError
            for row in prepared._rows:
                if type(row) is not tuple or len(row) != 11 or type(row[4]) is not int or any(type(row[i]) is not bytes for i in (9, 10)):
                    raise ValueError
            for row in (prepared._pointer_before, prepared._pointer_after, prepared._device_before, prepared._device_after):
                if row is not None and (type(row) is not tuple or len(row) != 3 or any(type(value) is not str for value in row)):
                    raise ValueError
            decoded = []
            for raw in (prepared._before_json, prepared._after_json, prepared._binding_json):
                if type(raw) is not bytes: raise ValueError
                value = json.loads(raw)
                if _canonical(value) != raw: raise ValueError
                decoded.append(value)
            before, after, binding = decoded
            if type(before) is not dict or type(after) is not dict or sorted(before) != sorted(row[0] for row in prepared._rows):
                raise ValueError
            if prepared.kind == "bind":
                if type(binding) is not dict:
                    raise ValueError
                version = before[prepared.target_id]["version"]
                if binding.get("schema") == "livemore.registered-physical-binding-input.v1":
                    from ..life_patch.physical_binding import normalize_prepared_binding
                    normalized = normalize_prepared_binding(binding, version)
                else:
                    normalized = _normalize_transition_binding(binding, version)
                if normalized != binding: raise ValueError
            elif binding is not None or prepared._device_before is not None or prepared._device_after is not None:
                raise ValueError
            actual_after, pointer, device = _transition_changes(prepared.kind, before, prepared._pointer_before,
                                                               prepared._device_before, prepared.target_id, binding, prepared.timestamp)
            if _canonical(actual_after) != prepared._after_json or pointer != prepared._pointer_after or device != prepared._device_after:
                raise ValueError
            return before, after, binding
        except (ValueError, KeyError, TypeError, AttributeError, OverflowError) as error:
            if isinstance(error, SubjectRegistryError): raise
            raise _transition_error("INVALID_TWIN_DATA") from error

    @staticmethod
    def _raw_transition_evidence(connection: sqlite3.Connection, ids: tuple[str, ...], fingerprint: str | None) -> tuple:
        record_rows = tuple(tuple(row) if row is not None else None for row in
                            (connection.execute("SELECT * FROM records WHERE record_id=?", (ident,)).fetchone() for ident in ids))
        pointer = connection.execute("SELECT * FROM registry_state WHERE state_key='active_twin_id'").fetchone()
        device = connection.execute("SELECT * FROM physical_device_bindings WHERE device_fingerprint=?", (fingerprint,)).fetchone() if fingerprint else None
        active = tuple(row[0] for row in connection.execute("SELECT record_id FROM records WHERE record_type='TWIN' AND lifecycle='ACTIVE' ORDER BY record_id LIMIT 2"))
        return record_rows, tuple(pointer) if pointer is not None else None, tuple(device) if device is not None else None, active

    def _selection_raw_baseline(self, connection: sqlite3.Connection, target_id: str | None,
                                device_fingerprint: str | None) -> tuple[tuple[str, ...], tuple]:
        """Protect the live selected row, not a former preparation's identity set."""
        if not connection.in_transaction:
            raise _transition_error()
        if target_id is not None:
            _transition_target(target_id)
        if device_fingerprint is not None and (type(device_fingerprint) is not str or not re.fullmatch(r"[0-9a-f]{64}", device_fingerprint)):
            raise _transition_error()
        pointer = connection.execute("SELECT * FROM registry_state WHERE state_key='active_twin_id'").fetchone()
        selected = None
        if pointer is not None:
            if (len(pointer) != 3 or pointer[0] != "active_twin_id"
                    or type(pointer[1]) is not str or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", pointer[1])
                    or type(pointer[2]) is not str or not 1 <= len(pointer[2]) <= 128):
                raise _transition_error()
            selected = pointer[1]
        ids = tuple(sorted({ident for ident in (target_id, selected) if ident is not None}))
        return ids, self._raw_transition_evidence(connection, ids, device_fingerprint)

    def _selection_audit_begin(self, connection: sqlite3.Connection, *, target_id: str | None,
                               device_fingerprint: str | None, request_id: str,
                               action: str, schema: str) -> _SelectionAuditOrigin:
        token = self.audit.check_authority(connection)
        if type(token) is not str or not token:
            raise RegistryAuditError()
        ids, baseline = self._selection_raw_baseline(connection, target_id, device_fingerprint)
        reservation = self.audit.begin(connection, request_id=request_id, action=action,
                                       opaque_record_id=target_id, schema=schema)
        row = connection.execute("SELECT * FROM registry_audit WHERE event_id=?", (reservation.event_id,)).fetchone()
        if row is None:
            raise RegistryAuditError()
        # begin() has just checked its encryption-origin tuple and reservation.
        # No intervening write/callback may replace that trusted evidence.
        origin = _SelectionAuditOrigin(reservation, tuple(row))
        if self._selection_audit_reenter(connection, origin) != token:
            raise RegistryAuditError()
        if self._raw_transition_evidence(connection, ids, device_fingerprint) != baseline:
            raise _transition_error()
        return origin

    def _selection_audit_reenter(self, connection: sqlite3.Connection,
                                 origin: _SelectionAuditOrigin) -> str:
        if type(origin) is not _SelectionAuditOrigin or type(origin.reservation) is not AuditReservation:
            raise RegistryAuditError()
        reservation = origin.reservation
        token = self.audit.check_authority(connection, reservation)
        if type(token) is not str or not token or origin.begin_row[0] != reservation.event_id:
            raise RegistryAuditError()
        self.audit._verify_row(connection, origin.begin_row)
        reserved = connection.execute("SELECT event_id,request_id FROM registry_audit_reservations WHERE event_id=? OR request_id=?", (reservation.event_id, reservation.request_id)).fetchall()
        if tuple(tuple(row) for row in reserved) != ((reservation.event_id, reservation.request_id),):
            raise RegistryAuditError()
        return token

    def _selection_audit_finish(self, connection: sqlite3.Connection, origin: _SelectionAuditOrigin,
                                *, outcome_code: str, expected_raw: tuple,
                                raw_ids: tuple[str, ...], device_fingerprint: str | None) -> tuple:
        self._selection_audit_reenter(connection, origin)
        if self._raw_transition_evidence(connection, raw_ids, device_fingerprint) != expected_raw:
            raise _transition_error()
        reservation = origin.reservation
        terminal_id = self.audit.finish(connection, reservation, outcome_code=outcome_code)
        if type(terminal_id) is not str or terminal_id == reservation.event_id:
            raise RegistryAuditError()
        terminal = connection.execute("SELECT * FROM registry_audit WHERE event_id=?", (terminal_id,)).fetchone()
        if terminal is None:
            raise RegistryAuditError()
        terminal = tuple(terminal)
        # finish() verified this terminal's origin after deleting the reservation.
        # Authority checks themselves precede the final audit/raw comparisons.
        self.audit.check_authority(connection, reservation)
        self.audit._verify_row(connection, origin.begin_row)
        self.audit._verify_row(connection, terminal)
        if connection.execute("SELECT 1 FROM registry_audit_reservations WHERE event_id=? OR request_id=?", (reservation.event_id, reservation.request_id)).fetchone():
            raise RegistryAuditError()
        if self._raw_transition_evidence(connection, raw_ids, device_fingerprint) != expected_raw:
            raise _transition_error()
        return origin.begin_row, terminal

    @contextmanager
    def _selection_read_access(self, *, target_id: str | None, device_fingerprint: str | None,
                               request_id: str, action: str, schema: str):
        """Fixed selection read owner; never a generic audited mutation runner."""
        _transition_request(request_id)
        connection = origin = None
        primary: BaseException | None = None
        try:
            connection = self._connect()
            origin = self._selection_audit_begin(connection, target_id=target_id,
                                                 device_fingerprint=device_fingerprint,
                                                 request_id=request_id, action=action, schema=schema)
            connection.commit()
            connection.execute("BEGIN IMMEDIATE")
            token = self._selection_audit_reenter(connection, origin)
            ids, baseline = self._selection_raw_baseline(connection, target_id, device_fingerprint)
            yield connection, token
            self._selection_audit_finish(connection, origin, outcome_code="SUCCESS",
                                         expected_raw=baseline, raw_ids=ids,
                                         device_fingerprint=device_fingerprint)
            connection.commit()
        except BaseException as error:
            primary = error
            rollback_ok = connection is None
            if connection is not None:
                try:
                    connection.rollback()
                    rollback_ok = connection.in_transaction is False
                except BaseException:
                    rollback_ok = False
            if not rollback_ok:
                primary = _transition_error("SELECTION_COMMIT_UNCONFIRMED")
            elif origin is not None:
                try:
                    self._selection_audit_reenter(connection, origin)
                    ids, baseline = self._selection_raw_baseline(connection, target_id, device_fingerprint)
                    self._selection_audit_finish(connection, origin, outcome_code="ACCESS_FAILED",
                                                 expected_raw=baseline, raw_ids=ids,
                                                 device_fingerprint=device_fingerprint)
                    connection.commit()
                except BaseException:
                    # A failed completion retains its pending origin. Never mask
                    # the first failure or publish an uncertain successful read.
                    try: connection.rollback()
                    except BaseException: pass
        finally:
            if connection is not None:
                try: connection.close()
                except BaseException:
                    if primary is None: primary = _transition_error()
        if isinstance(primary, (sqlite3.Error, OSError, json.JSONDecodeError)):
            raise _transition_error() from primary
        if primary is not None:
            raise primary

    def _confirm_transition_witness(self, ids: tuple[str, ...], fingerprint: str | None, evidence: tuple,
                                    audit_rows: tuple, begin_id: str, request_id: str) -> tuple[bool, bool]:
        """One consistent read-only ciphertext check; never decrypt or retry writes."""
        check = None
        matched = False
        cleanup_failed = False
        try:
            check = self._connect()
            check.execute("BEGIN")
            actual = self._raw_transition_evidence(check, ids, fingerprint)
            retained = tuple(tuple(row) if row is not None else None for row in
                             (check.execute("SELECT * FROM registry_audit WHERE event_id=?", (row[0],)).fetchone() for row in audit_rows))
            reserved = check.execute("SELECT * FROM registry_audit_reservations WHERE event_id=? OR request_id=?", (begin_id, request_id)).fetchall()
            matched = actual == evidence and retained == audit_rows and not reserved
        except BaseException:
            matched = False
        finally:
            if check is not None:
                try: check.close()
                except BaseException: cleanup_failed = True
        return matched, cleanup_failed

    def commit_prepared_transition(self, prepared: PreparedRegistryTransition) -> Literal["COMMITTED", "COMMITTED_CLEANUP_UNCONFIRMED"]:
        before, after, binding = self._validate_transition(prepared)
        fingerprint = self._fingerprint(binding["device_id"]) if binding else None
        ids = tuple(row[0] for row in prepared._rows)
        physical = binding is not None and binding["mode"] == "physical"
        action = "select_observations" if prepared.kind == "select_observations" else "bind" if physical else "inspect"
        connection = None
        reservation = None
        attempted = False
        confirmed = False
        cleanup_failed = False
        primary: BaseException | None = None
        evidence = audit_rows = None
        origin = None
        try:
            connection = self._connect()
            origin = self._selection_audit_begin(connection, target_id=prepared.target_id,
                                                 device_fingerprint=fingerprint,
                                                 request_id=prepared.request_id, action=action,
                                                 schema="livemore.physical-access-audit.v1" if physical else "livemore.subject-access-audit.v1")
            reservation = origin.reservation
            connection.commit()
            connection.execute("BEGIN IMMEDIATE")
            if self._selection_audit_reenter(connection, origin) != prepared.authority_token:
                raise RegistryAuditError()
            saved, raw, pointer, device = self._transition_snapshot(connection, prepared.target_id, fingerprint)
            if (saved, raw, pointer, device) != (prepared._rows, prepared._before_json, prepared._pointer_before, prepared._device_before):
                raise _transition_error("TWIN_VERSION_CONFLICT")
            # Derive expected SQL rows from the validated old rows, not a blind
            # post-write SELECT that could bless a trigger's unexpected edit.
            expected_rows = []
            for row in saved:
                if row[0] not in after:
                    expected_rows.append(row)
                    continue
                record = after[row[0]]
                nonce, ciphertext = self._seal(row[0], record)
                expected = (*row[:3], record["lifecycle"], record["version"], *row[5:8], record["updated_at"], nonce, ciphertext)
                changed = connection.execute("UPDATE records SET lifecycle=?,version=?,updated_at=?,nonce=?,ciphertext=? WHERE record_id=? AND version=?",
                                             (record["lifecycle"], record["version"], record["updated_at"], nonce, ciphertext, row[0], row[4]))
                if changed.rowcount != 1: raise _transition_error("TWIN_VERSION_CONFLICT")
                expected_rows.append(expected)
            if prepared._pointer_after != pointer:
                if prepared._pointer_after is None:
                    connection.execute("DELETE FROM registry_state WHERE state_key='active_twin_id'")
                else:
                    connection.execute("INSERT INTO registry_state VALUES(?,?,?) ON CONFLICT(state_key) DO UPDATE SET state_value=excluded.state_value,updated_at=excluded.updated_at", prepared._pointer_after)
            if physical:
                connection.execute("INSERT INTO physical_device_bindings VALUES(?,?,?) ON CONFLICT(device_fingerprint) DO UPDATE SET bound_at=excluded.bound_at", prepared._device_after)
            evidence = (tuple(expected_rows), prepared._pointer_after, prepared._device_after,
                        (prepared._pointer_after[1],) if prepared._pointer_after else ())
            audit_rows = self._selection_audit_finish(connection, origin, outcome_code="SUCCESS",
                                                      expected_raw=evidence, raw_ids=ids,
                                                      device_fingerprint=fingerprint)
            attempted = True
            connection.commit()
            confirmed = True
        except BaseException as error:
            primary = error
            try: pending = connection.in_transaction if connection is not None else False
            except BaseException: pending = None
            if attempted and pending is not True:
                confirmed, cleanup_failed = self._confirm_transition_witness(ids, fingerprint, evidence, audit_rows, reservation.event_id, prepared.request_id)
                if not confirmed: primary = _transition_error("SELECTION_COMMIT_UNCONFIRMED")
            else:
                rollback_ok = connection is None
                if connection is not None:
                    try:
                        connection.rollback()
                        rollback_ok = connection.in_transaction is False
                    except BaseException: rollback_ok = False
                if not rollback_ok:
                    primary = _transition_error("SELECTION_COMMIT_UNCONFIRMED")
                elif reservation is not None:
                    try:
                        # A fault that changed clinical state on SUCCESS may do
                        # so again on ACCESS_FAILED. Protect this fresh baseline
                        # under its writer lock without decrypting clinical data.
                        self._selection_audit_reenter(connection, origin)
                        failure_ids, failure_baseline = self._selection_raw_baseline(connection, prepared.target_id, fingerprint)
                        self._selection_audit_finish(connection, origin, outcome_code="ACCESS_FAILED",
                                                     expected_raw=failure_baseline, raw_ids=failure_ids,
                                                     device_fingerprint=fingerprint)
                        connection.commit()
                    except BaseException:
                        try: connection.rollback()
                        except BaseException: pass
        finally:
            if connection is not None:
                try: connection.close()
                except BaseException:
                    if confirmed: cleanup_failed = True
        if confirmed:
            return "COMMITTED_CLEANUP_UNCONFIRMED" if cleanup_failed else "COMMITTED"
        if isinstance(primary, (sqlite3.Error, OSError)):
            raise _transition_error() from primary
        if primary is not None: raise primary
        raise _transition_error()

    def clear_active_twin(self) -> None:
        """Explicit standalone preview clear, not another process's memory swap."""
        prepared = self.prepare_preview_clear(request_id=str(uuid.uuid4()))
        if self.commit_prepared_transition(prepared) == "COMMITTED_CLEANUP_UNCONFIRMED":
            raise _transition_error("SELECTION_COMMITTED_CLEANUP_UNCONFIRMED")

    def get_cohort(self, cohort_id: str) -> dict[str, Any]:
        return self._get(cohort_id, "COHORT")[1]

    def _list(self, record_type: str) -> list[dict[str, Any]]:
        with self._audited("inspect") as connection:
            rows = connection.execute(
                "SELECT * FROM records WHERE record_type = ? ORDER BY created_at DESC, record_id DESC", (record_type,),
            ).fetchall()
            return [self._open(row) for row in rows]

    def _replace(self, row: sqlite3.Row, record: dict[str, Any]) -> None:
        record_id = str(row["record_id"])
        nonce, ciphertext = self._seal(record_id, record)
        with closing(self._connect()) as connection, connection:
            updated = connection.execute(
                """UPDATE records SET lifecycle = ?, version = ?, updated_at = ?, nonce = ?, ciphertext = ?
                   WHERE record_id = ? AND version = ?""",
                (record["lifecycle"], record["version"], record["updated_at"], nonce, ciphertext,
                 record_id, row["version"]),
            )
            if updated.rowcount != 1:
                raise SubjectRegistryError("TWIN_VERSION_CONFLICT", "record changed before update completed")

    def activate_twin(self, twin_id: str, *, expected_version: int) -> dict[str, Any]:
        prepared = self.prepare_activation(twin_id, expected_version=expected_version, request_id=str(uuid.uuid4()))
        # Standalone compatibility admission is outside all locks owned by this
        # wrapper. Server callers perform candidate preparation separately.
        original = prepared.target_before
        if original["source_class"] != "SYNTHETIC":
            self.admitted_human(original).metabolic_profile(None)
        result = prepared.record
        if self.commit_prepared_transition(prepared) == "COMMITTED_CLEANUP_UNCONFIRMED":
            raise _transition_error("SELECTION_COMMITTED_CLEANUP_UNCONFIRMED")
        return result

    def select_observations(self, twin_id: str, *, expected_version: int,
                            prepared: PreparedObservationSelection | None = None,
                            request_id: str | None = None) -> dict[str, Any]:
        """Standalone compatibility through the same full prepared transition."""
        _transition_version(expected_version)
        if prepared is not None and type(prepared) is not PreparedObservationSelection:
            raise _transition_error("INVALID_TWIN_DATA")
        transition = self.prepare_observation_selection(twin_id, expected_version=expected_version,
                                                        request_id=str(uuid.uuid4()) if request_id is None else request_id)
        if prepared is not None:
            original = transition.target_before
            if type(prepared.original_sha256) is not str or prepared.original_sha256 != _request_hash(original):
                raise _transition_error("TWIN_VERSION_CONFLICT")
            try:
                if type(prepared._record_json) is not bytes:
                    raise ValueError
                result = prepared.record
                if type(result) is not dict or _canonical(result) != prepared._record_json:
                    raise ValueError
                # The legacy value binds only canonical target content. Fresh
                # preparation supplies the current rows, pointer and authority;
                # its timestamp must be replaced for every affected row together.
                timestamp = result["updated_at"]
                after, pointer, device = _transition_changes(
                    transition.kind, json.loads(transition._before_json), transition._pointer_before,
                    transition._device_before, transition.target_id, None, timestamp)
                if _canonical(after[twin_id]) != prepared._record_json:
                    raise ValueError
                transition = replace(transition, timestamp=timestamp, _after_json=_canonical(after),
                                     _pointer_after=pointer, _device_after=device)
            except (ValueError, KeyError, TypeError, OverflowError, RecursionError) as error:
                raise _transition_error("INVALID_TWIN_DATA") from error
        result = transition.record
        if self.commit_prepared_transition(transition) == "COMMITTED_CLEANUP_UNCONFIRMED":
            raise _transition_error("SELECTION_COMMITTED_CLEANUP_UNCONFIRMED")
        return result

    def bind_patch(self, twin_id: str, body: object, *, expected_version: int) -> dict[str, Any]:
        prepared = self.prepare_patch_binding(twin_id, body, expected_version=expected_version, request_id=str(uuid.uuid4()))
        result = prepared.record
        if self.commit_prepared_transition(prepared) == "COMMITTED_CLEANUP_UNCONFIRMED":
            raise _transition_error("SELECTION_COMMITTED_CLEANUP_UNCONFIRMED")
        return result

    def create_cohort(self, body: object, *, idempotency_key: str | None = None) -> dict[str, Any]:
        if not isinstance(body, dict):
            raise SubjectRegistryError("INVALID_COHORT_DATA", "request body must be a JSON object")
        source_class = str(body.get("source_class", "SYNTHETIC")).strip().upper()
        if source_class == "REAL_HUMAN":
            return self._create_real_cohort(body, idempotency_key=idempotency_key)
        if source_class not in _SOURCE_CLASSES:
            raise SubjectRegistryError(
                "INVALID_SOURCE_CLASS",
                "source_class must be REAL_HUMAN, SYNTHETIC, or REFERENCE_GROUNDED_SYNTHETIC",
            )
        name = _bounded_string(body.get("name"), "name", maximum=100)
        seed = int(_finite(body.get("seed", 0), "seed", 0, 2**31 - 1))
        indication = _bounded_string(body.get("indication", "unspecified"), "indication", maximum=100)
        member_twin_ids = _bounded_list(body.get("member_twin_ids"), "member_twin_ids", maximum=1000)
        if source_class == "REAL_HUMAN":
            if not member_twin_ids:
                raise SubjectRegistryError("COHORT_MEMBERS_REQUIRED", "real-human cohort requires admitted twin IDs")
            for twin_id in member_twin_ids:
                twin = self.get_twin(twin_id)
                if twin["source_class"] != "REAL_HUMAN" or twin["lifecycle"] != "ACTIVE":
                    raise SubjectRegistryError("COHORT_MEMBER_INELIGIBLE", "real-human cohort members must be active real-human twins")
            size = len(member_twin_ids)
        else:
            size = int(_finite(body.get("size", 50), "size", 1, 10000))
        reference_source: dict[str, str] | None = None
        stratum: str | None = None
        members: list[dict[str, Any]] = []
        heterogeneity: dict[str, Any] | None = None
        if source_class == "REFERENCE_GROUNDED_SYNTHETIC":
            reference_source = normalize_reference_source(body.get("reference_source"), error=SubjectRegistryError)
            stratum = _bounded_string(body.get("stratum"), "stratum", maximum=100)
            members = generate_members(
                size=size,
                seed=seed,
                stratum=stratum,
                source=reference_source,
                error=SubjectRegistryError,
            )
            heterogeneity = heterogeneity_summary(members)
        normalized = {
            "source_class": source_class,
            "name": name,
            "size": size,
            "seed": seed,
            "indication": indication,
            "member_twin_ids": member_twin_ids,
            "stratum": stratum,
            "reference_source": reference_source,
        }
        request_hash = _request_hash(normalized)
        existing = self._idempotent(idempotency_key, request_hash)
        if existing is not None:
            return existing
        fingerprints = [
            hashlib.sha256(f"{source_class}|{seed}|{indication}|{item}".encode("utf-8")).hexdigest()
            for item in (member_twin_ids if member_twin_ids else range(size))
        ]
        created_at = _now()
        record = {
            "schema": "livemore.cohort-record.v1",
            "cohort_id": f"cohort-{uuid.uuid4().hex}",
            **normalized,
            "member_fingerprints": fingerprints,
            "members": members,
            "heterogeneity": heterogeneity,
            "lifecycle": "FROZEN",
            "version": 1,
            "created_at": created_at,
            "updated_at": created_at,
        }
        return self._insert_or_existing("COHORT", record, request_hash, idempotency_key)

    def _create_real_cohort(self, body: dict[str, Any], *, idempotency_key: str | None) -> dict[str, Any]:
        if _RESERVED.intersection(body):
            raise SubjectRegistryError("INVALID_COHORT_DATA", "The request contains server-owned fields.")
        if idempotency_key is not None and (not isinstance(idempotency_key, str) or not 1 <= len(idempotency_key) <= 200):
            raise SubjectRegistryError("INVALID_COHORT_DATA", "Invalid idempotency key.")
        ids = body.get("member_twin_ids")
        if (not isinstance(ids, list) or not 1 <= len(ids) <= 1000
                or any(not isinstance(item, str) or not item.startswith("twin-") or item != item.strip() or len(item) > 120 for item in ids)
                or len(set(ids)) != len(ids)):
            raise SubjectRegistryError("COHORT_MEMBERS_REQUIRED", "A bounded roster of unique canonical twin IDs is required.")
        normalized = {"source_class": "REAL_HUMAN", "name": _bounded_string(body.get("name"), "name", maximum=100),
                      "size": len(ids), "seed": int(_finite(body.get("seed", 0), "seed", 0, 2**31 - 1)),
                      "indication": _bounded_string(body.get("indication", "unspecified"), "indication", maximum=100),
                      "member_twin_ids": list(ids), "stratum": None, "reference_source": None}
        identity = _creation_identity("COHORT", normalized, idempotency_key)
        with self._audited("create_cohort") as connection:
            if idempotency_key:
                previous = connection.execute("SELECT * FROM records WHERE idempotency_key=?", (idempotency_key,)).fetchone()
                if previous is not None:
                    return self._match_real_retry(previous, normalized, "COHORT", idempotency_key)
            members = []
            subjects = set()
            charged_bytes = 0
            for twin_id in ids:
                row = connection.execute("SELECT * FROM records WHERE record_id=? AND record_type='TWIN'", (twin_id,)).fetchone()
                if row is None:
                    raise SubjectRegistryError("COHORT_MEMBER_INELIGIBLE", "A cohort member is not admitted.")
                snapshot = self._open(row)
                _validate_real_admission(snapshot, research=True)
                if snapshot["twin_id"] != twin_id or snapshot["version"] != row["version"] or snapshot["source_class"] != row["source_class"] or snapshot["subject_id"] in subjects:
                    raise SubjectRegistryError("COHORT_MEMBER_INELIGIBLE", "Cohort member identity is inconsistent or repeated.")
                subjects.add(snapshot["subject_id"])
                raw = _canonical(snapshot)
                charged_bytes += len(raw)
                if charged_bytes > 16_777_216:
                    raise SubjectRegistryError("COHORT_PAYLOAD_TOO_LARGE", "The frozen cohort exceeds the local encrypted payload limit.")
                members.append({"schema": "livemore.frozen-real-human-member.v1", "source_class": "REAL_HUMAN",
                                "twin_id": twin_id, "record_version": snapshot["version"],
                                "snapshot_sha256": hashlib.sha256(b"livemore.real-human-member-snapshot.v1\0" + raw).hexdigest(),
                                "evidence_sha256": hashlib.sha256(b"livemore.real-human-member-evidence.v1\0" + _canonical({field: snapshot[field] for field in _EVIDENCE_FIELDS})).hexdigest(),
                                "snapshot": snapshot})
            now = _now()
            record = {"schema": "livemore.cohort-record.v1", "cohort_id": f"cohort-{uuid.uuid4().hex}", **normalized,
                      "member_fingerprints": [hashlib.sha256(f"REAL_HUMAN|{normalized['seed']}|{normalized['indication']}|{item}".encode()).hexdigest() for item in ids],
                      "members": members, "heterogeneity": None, "lifecycle": "FROZEN", "version": 1,
                      "created_at": now, "updated_at": now, "creation_identity": identity}
            enforce_real_cohort_size(record)
            self._insert_connection(connection, "COHORT", record, identity["request_sha256"], idempotency_key)
            return record

    def _frozen_cohort(self, connection: sqlite3.Connection, cohort_id: str) -> dict[str, Any]:
        row = connection.execute("SELECT * FROM records WHERE record_id=? AND record_type='COHORT'", (cohort_id,)).fetchone()
        if row is None:
            raise SubjectRegistryError("RECORD_NOT_FOUND", "Cohort record was not found.")
        record = self._open(row)
        if record.get("source_class") != "REAL_HUMAN" or record.get("cohort_id") != cohort_id or record.get("version") != row["version"]:
            raise SubjectRegistryError("INVALID_COHORT_DATA", "This member view requires a governed real-human cohort.")
        members = record.get("members")
        if not isinstance(members, list) or not members:
            raise SubjectRegistryError("COHORT_MEMBER_SNAPSHOT_REQUIRED", "Historical cohort has no frozen member snapshots.")
        if len(members) != record.get("size") or len(members) > 1000 or [member.get("twin_id") for member in members] != record.get("member_twin_ids"):
            raise SubjectRegistryError("COHORT_SNAPSHOT_INVALID", "Frozen cohort roster integrity failed.")
        for member in members:
            _member_snapshot(member)
        return record

    def page_cohort_members(self, cohort_id: str, *, limit: int = 10, cursor: str | None = None) -> dict[str, Any]:
        if type(limit) is not int or not 1 <= limit <= 50:
            raise SubjectRegistryError("INVALID_PAGE", "Member page size must be 1 to 50.")
        with self._audited("member_page", cohort_id) as connection:
            record = self._frozen_cohort(connection, cohort_id)
            binding = [1, cohort_id, record["version"], limit]
            position = 0
            if cursor is not None:
                try:
                    if not isinstance(cursor, str) or not 1 <= len(cursor) <= 1024:
                        raise ValueError
                    raw = base64.b64decode(cursor + "=" * (-len(cursor) % 4), altchars=b"-_", validate=True)
                    payload, signature = raw[:-32], raw[-32:]
                    if not hmac.compare_digest(signature, hmac.digest(self.key, b"real-cohort-member-page-v1\0" + payload, "sha256")):
                        raise ValueError
                    value = json.loads(payload)
                    if not isinstance(value, list) or len(value) != 5 or value[:4] != binding or type(value[4]) is not int or not 0 < value[4] < len(record["members"]):
                        raise ValueError
                    position = value[4]
                except (ValueError, TypeError, UnicodeError) as error:
                    raise SubjectRegistryError("INVALID_PAGE", "Member cursor is invalid; refresh the list.") from error
            selected = record["members"][position:position + limit]
            rows = [{"twin_id": item["twin_id"], "record_version": item["record_version"], "display_label": item["snapshot"]["display_label"], "source_class": "REAL_HUMAN", "execution_eligibility": {"state": "UNAVAILABLE", "reason_code": "MODEL_BINDING_REQUIRED"}} for item in selected]
            following = position + len(rows)
            more = following < len(record["members"])
            next_cursor = None
            if more:
                payload = _canonical([*binding, following])
                next_cursor = base64.urlsafe_b64encode(payload + hmac.digest(self.key, b"real-cohort-member-page-v1\0" + payload, "sha256")).decode().rstrip("=")
            return {"members": rows, "pagination": {"limit": limit, "total": record["size"], "has_more": more, "next_cursor": next_cursor}}

    def get_cohort_member(self, cohort_id: str, twin_id: str) -> dict[str, Any]:
        with self._audited("member_read", cohort_id) as connection:
            record = self._frozen_cohort(connection, cohort_id)
            for member in record["members"]:
                if member["twin_id"] == twin_id:
                    return member
            raise SubjectRegistryError("RECORD_NOT_FOUND", "Frozen cohort member was not found.")

    @staticmethod
    def admitted_human(record: dict[str, Any]) -> AdmittedHuman:
        from ..reference_cohort_contract import ensure_cohort_executable
        from .model_contexts import resolve_model_context

        if record.get("source_class") != "REAL_HUMAN":
            ensure_cohort_executable(record)
        context = resolve_model_context(record)
        ensure_cohort_executable(record)
        return AdmittedHuman(
            id=record["subject_id"], display_label=record["display_label"],
            age=int(record["demographics"]["age"]), sex=record["demographics"]["sex"],
            conditions=list(record["conditions"]), genome=dict(record["genome"]),
            lifestyle=float(record["lifestyle"]), observations=dict(record["observations"]),
            model_parameters=dict(record["model_parameters"]), source_class=record["source_class"],
            reference_source_id=(record.get("reference_source") or {}).get("source_id"),
            resolved_context=context,
        )

    @staticmethod
    def build_twin(record: dict[str, Any]):
        from ..reference_cohort_contract import ensure_cohort_executable
        from .model_contexts import resolve_model_context

        if record.get("source_class") != "REAL_HUMAN":
            ensure_cohort_executable(record)
        if record.get("source_class") != "SYNTHETIC":
            resolve_model_context(record)
        ensure_cohort_executable(record)
        from .runtime import AegleTwin

        demo = record["source_class"] == "SYNTHETIC"
        common = {
            "id": record["subject_id"],
            "age": int(record["demographics"]["age"]),
            "sex": record["demographics"]["sex"],
            "conditions": list(record["conditions"]),
            "genome": dict(record["genome"]),
            "lifestyle": float(record["lifestyle"]),
        }
        if demo:
            from ..life_system.synthetic_human import SyntheticHuman

            human = SyntheticHuman(**common)
        else:
            human = SubjectRegistry.admitted_human(record)
        return AegleTwin(human=human)


__all__ = ["AdmittedHuman", "SubjectRegistry", "SubjectRegistryError"]
