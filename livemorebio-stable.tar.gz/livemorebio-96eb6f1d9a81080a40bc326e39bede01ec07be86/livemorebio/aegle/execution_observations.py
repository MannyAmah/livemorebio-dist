"""Admit a LIFE-signed numerical probe without replacing physical observations."""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import re
from typing import Any

from ..life_patch.protocol_v3 import ManifestV3, TelemetryEnvelopeV3, normalize_observations, validate_manifest_binding
from ..security import verify_patch_admission
from .execution_contract import ExecutionError, METABOLIC, digest, encoded, number
from .execution_receipts import ExecutionReceiptLedger
from .model_source import SourceGenerationConflict

OPERATOR_ID = "metabolic-plasma-glucose-identity-v1"


def _utc(value: Any) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            raise ValueError()
        return parsed.astimezone(timezone.utc)
    except (AttributeError, TypeError, ValueError):
        raise ExecutionError() from None


def project_receipt(twin: Any, receipt: dict[str, Any]) -> dict[str, Any]:
    """Idempotent per-stream view; receipts remain the durable source of truth."""
    key = digest({field: receipt[field] for field in
                  ("execution_id", "source_snapshot_hash", "source_generation", "device_id", "operator_id")})
    retained = deepcopy(getattr(twin, "execution_observations", {}))
    if key not in retained and len(retained) >= 64:
        raise ExecutionError("EXECUTION_QUOTA")
    previous = retained.get(key)
    if previous is not None and previous["frame_index"] > receipt["frame_index"]:
        return previous
    envelope = TelemetryEnvelopeV3(receipt["envelope"])
    projection = {field: receipt[field] for field in ("execution_id", "source_snapshot_hash", "source_generation",
                  "frame_index", "frame_hash", "device_id", "operator_id", "envelope_id", "envelope_hash")}
    projection.update(observations=normalize_observations(envelope, received_at=_utc(receipt["admission"]["received_at"])),
                      evidence_class="MODELED", physical_equivalence_validated=False)
    retained[key] = projection
    twin.execution_observations = retained
    return deepcopy(projection)


def admit_execution_observation(manager: Any, twin: Any, selection: dict[str, Any], generation: str,
                                bindings: list[dict[str, Any]], body: dict[str, Any], *,
                                now: datetime | None = None) -> dict[str, Any]:
    """Caller must hold source authority throughout validation/persist/projection."""
    if not isinstance(body, dict) or set(body) != {"envelope", "manifest", "admission", "admission_signature"}:
        raise ExecutionError()
    encoded(body, 16 * 1024)
    admission, signature = body["admission"], body["admission_signature"]
    if (not isinstance(admission, dict) or not isinstance(signature, str)
            or re.fullmatch(r"[0-9a-f]{64}", signature) is None
            or not verify_patch_admission(admission, signature)):
        raise ExecutionError()
    envelope, manifest = TelemetryEnvelopeV3(body["envelope"]), ManifestV3(body["manifest"])
    packet = envelope.to_dict()
    validate_manifest_binding(manifest, envelope)
    if envelope.mode.value != "virtual" or envelope.subject_id != selection["subject_id"]:
        raise ExecutionError()
    if not any(item.get("device_id") == envelope.device_id and item.get("mode") == "virtual"
               and item.get("protocol_version") == "3.0" for item in bindings):
        # A missing binding is a prerequisite the operator can satisfy, not an
        # unspecified bad input. Name it so the refusal is actionable.
        raise ExecutionError("PATCH_BINDING_REQUIRED")
    expected_admission = {"admission": "accepted", "device_id": envelope.device_id, "mode": "virtual",
                          "envelope_hash": envelope.envelope_hash, "capability_hash": manifest.capability_hash,
                          "manifest_hash": manifest.capability_hash}
    if (set(admission) != set(expected_admission) | {"admitted_at", "received_at"}
            or any(admission[key] != value for key, value in expected_admission.items())):
        raise ExecutionError()
    if len(packet["measurements"]) != 1:
        raise ExecutionError()
    row = packet["measurements"][0]
    model = row.get("model_context", {})
    match = re.fullmatch(r"execution-([0-9a-f]{32})-frame-([1-9][0-9]{0,9})", str(model.get("prediction_id", "")))
    if match is None:
        raise ExecutionError()
    execution_id, index = match[1], int(match[2])
    record = manager.store.get(execution_id)
    if (record["source"]["source_generation"] != generation or not record["source_valid"]
            or record["source"]["selection"] != selection):
        raise SourceGenerationConflict()
    consumer = record.get("consumer_binding")
    if (not consumer or consumer["session_id"] != packet["clock"]["session_id"]
            or consumer["source_snapshot_hash"] != record["source"]["source_snapshot_hash"]
            or consumer["producer_instance"] != manager._producer_instance):
        raise ExecutionError()
    frames = manager.store.frames(execution_id, after_frame=index - 1, limit=1)
    if not frames or frames[0]["frame_index"] != index:
        raise ExecutionError()
    frame = frames[0]
    unhashed = deepcopy(frame)
    unhashed.pop("frame_hash")
    if (digest(unhashed) != frame["frame_hash"] or frame["authorship"] != "engine"
            or frame["evidence_class"] != "MODELED" or record["authorship"] != "engine"
            or frame["engine_contract_id"] != METABOLIC or frame["native_unit"] != "min"
            or frame["selection"] != selection or frame["source_generation"] != generation
            or frame["source_snapshot_hash"] != record["source"]["source_snapshot_hash"]
            or frame["numerical_domain_notes"]):
        raise ExecutionError()
    expected_model = {"prediction_id": model["prediction_id"], "condition_id": selection["condition_id"],
                      "model_time_min": frame["native_end"], "model_id": METABOLIC, "mapping_id": OPERATOR_ID}
    context = {"endpoint": "glucose_mgdl", "biofluid": "plasma", "compartment": "plasma", "site": None,
               "assay_id": None, "cartridge_id": None, "calibration_id": None, "derivation_id": OPERATOR_ID}
    trace = next((item for item in frame["series"] if item["quantity"] == "glucose_mgdl"), None)
    if (trace is None or trace["unit"] != "mg/dL" or trace["compartment"] != "plasma"
            or model != expected_model or row["context"] != context or row["value"] != trace["values"][-1]
            or row["signal"] != "glucose_mgdl" or row["unit"] != "mg/dL" or row["provenance"] != "modeled"
            or row["kind"] != "scalar" or row["quality_status"] != "pass"
            or row["quality_flags"] != [] or row["calibration_status"] != "not_applicable"
            or row["measurement_id"] != f"glucose-{index}"
            or envelope.envelope_id != f"virtual-{consumer['session_id']}-{index}"):
        raise ExecutionError()
    # LIFE owns device-global replay sequencing; execution identity is bound above.
    captured, received, admitted = envelope.captured_at, _utc(admission["received_at"]), _utc(admission["admitted_at"])
    current = now or datetime.now(timezone.utc)
    generated = _utc(frame["generated_at"])
    source_age_s = packet["clock"]["monotonic_start_s"] - number(frame.get("generated_monotonic_s"), 0., 1e12)
    if (not generated <= captured <= received <= current or not received <= admitted <= current
            or (captured - generated).total_seconds() > 30
            or not 0 <= source_age_s <= 30
            or packet["acquisition_start"] != packet["acquisition_end"]
            or packet["clock"]["monotonic_start_s"] != packet["clock"]["monotonic_end_s"]
            or packet["clock"]["utc_uncertainty_s"] != .01):
        raise ExecutionError()
    receipt = {"schema": "livemore.execution-observation-receipt.v1", "execution_id": execution_id,
               "frame_index": index, "frame_hash": frame["frame_hash"],
               "source_snapshot_hash": frame["source_snapshot_hash"], "source_generation": generation,
               "device_id": envelope.device_id, "operator_id": OPERATOR_ID,
               "envelope_id": envelope.envelope_id, "envelope_hash": envelope.envelope_hash,
               "manifest_hash": manifest.capability_hash, "envelope": packet,
               "manifest": manifest.to_dict(), "admission": deepcopy(admission)}
    ledger = ExecutionReceiptLedger(manager.store)
    existing = ledger.get(envelope.envelope_id)
    if existing is None and record["state"] not in {"running", "paused", "completed"}:
        raise ExecutionError("EXECUTION_CONFLICT")
    admitted_receipt = ledger.admit(receipt)
    latest = ledger.latest(execution_id, envelope.device_id, OPERATOR_ID)
    projected = project_receipt(twin, latest or admitted_receipt)
    return {"admission": "accepted", "projection": "applied", "execution_id": execution_id,
            "envelope_id": envelope.envelope_id, "envelope_hash": envelope.envelope_hash,
            "received_frame_index": index, "projected_frame_index": projected["frame_index"],
            "evidence_class": "MODELED", "physical_equivalence_validated": False}
