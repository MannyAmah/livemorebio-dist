"""Original capture-time admission; never substitutes ingestion/current time."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone


def normalize_capture_time(
    value: object, *, field: str = "captured_at", now: datetime | None = None,
) -> str:
    """Normalize a supplied instant, reporting only a caller-owned field label."""
    if not isinstance(value, str) or not value.strip() or len(value) > 80:
        raise ValueError(f"{field} must be bounded ISO-8601 text")
    try:
        captured = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        raise ValueError(f"{field} must be ISO-8601") from None
    if captured.tzinfo is None or captured.utcoffset() is None:
        raise ValueError(f"{field} must include a timezone")
    try:
        normalized = captured.astimezone(timezone.utc)
    except (ValueError, OverflowError):
        raise ValueError(f"{field} must be a representable ISO-8601 instant") from None
    current = datetime.now(timezone.utc) if now is None else now
    if current.tzinfo is None or current.utcoffset() is None:
        raise ValueError("admission clock must include a timezone")
    if normalized > current + timedelta(minutes=5):
        raise ValueError(f"{field} cannot be in the future")
    return normalized.isoformat().replace("+00:00", "Z")
