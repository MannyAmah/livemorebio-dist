"""Independent, bounded key-establishment audit for local subject registries.

A failed candidate data key cannot become the authority for later attempts.
The bootstrap key must be backed up with the database; neither key rotation nor
in-place recovery of an old poisoned audit is implemented here.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import tempfile
import time
from typing import Any, Iterator
from uuid import UUID, uuid4

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

MAX_EVENTS = 512
MAX_WITNESS_BYTES = 16_777_216 + 16
MAX_MIGRATION_TWINS = 10_000
MAX_MIGRATION_BYTES = 268_435_456
_PREFIX = "livemore.subject-registry."
_SCHEMAS = {
    "identity": _PREFIX + "bootstrap-identity.v1",
    "event": _PREFIX + "bootstrap-event.v1",
    "proof": _PREFIX + "key-proof.v1",
    "binding": _PREFIX + "proof-binding.v1",
}
_AAD = {key: value.encode() + b"\0" for key, value in _SCHEMAS.items()}
_AAD["event"] = b"livemore.subject-registry.bootstrap.v1\0"
_FIELDS = {
    "identity": frozenset("schema identity_id local_store_id created_at origin_process_instance origin_source_sha256".split()),
    "event": frozenset("schema event_id sequence event_type begin_event_id request_id action local_store_id started_at completed_at outcome_code origin_process_instance origin_source_sha256 completion_process_instance completion_source_sha256 proof_id proof_kind witness legacy_ledger".split()),
    "proof": frozenset("schema proof_id local_store_id challenge_id proof_kind bootstrap_identity_id bootstrap_request_id bootstrap_begin_event_id bootstrap_result_event_id established_at origin_process_instance origin_source_sha256 witness legacy_ledger".split()),
    "binding": frozenset("schema binding_id local_store_id bootstrap_identity_id proof_id proof_nonce_sha256 proof_ciphertext_sha256 bootstrap_request_id bootstrap_begin_event_id bootstrap_result_event_id established_at origin_process_instance origin_source_sha256".split()),
}
_KINDS = frozenset({"LEGACY_WITNESS", "EXISTING_AUDIT", "EMPTY_ESTABLISHMENT"})
_ACTIONS = frozenset({"INITIALIZE", "ADOPT_EXISTING_AUDIT"})
_OUTCOMES = frozenset({"SUCCESS", "KEY_OR_RECORD_UNVERIFIABLE", "MIGRATION_FAILED", "INTERRUPTED_OUTCOME_UNKNOWN"})


class RegistryBootstrapError(ValueError):
    def __init__(self, code: str = "REGISTRY_BOOTSTRAP_INVALID") -> None:
        self.code = code
        super().__init__("Registry key authority could not be confirmed; no successful access is established.")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _sha(value: bytes) -> str:
    if not isinstance(value, bytes):
        raise RegistryBootstrapError()
    return hashlib.sha256(value).hexdigest()


def _uuid(value: Any) -> str:
    if not isinstance(value, str):
        raise RegistryBootstrapError()
    try:
        if str(UUID(value)) != value:
            raise ValueError
    except ValueError as error:
        raise RegistryBootstrapError() from error
    return value


def _hash(value: Any) -> None:
    if not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise RegistryBootstrapError()


def _utc(value: Any) -> None:
    try:
        if not isinstance(value, str) or not value.endswith("Z") or len(value) > 32:
            raise ValueError
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.isoformat().replace("+00:00", "Z") != value:
            raise ValueError
    except ValueError as error:
        raise RegistryBootstrapError() from error


def _pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in items:
        if key in result:
            raise RegistryBootstrapError()
        result[key] = value
    return result


def _witness(value: Any, kind: str | None) -> None:
    if kind in {None, "EMPTY_ESTABLISHMENT"}:
        if value is not None:
            raise RegistryBootstrapError()
        return
    if not isinstance(value, dict) or set(value) != {"kind", "opaque_id", "index_sha256", "nonce_sha256", "ciphertext_sha256"}:
        raise RegistryBootstrapError()
    if value["kind"] != ("RECORD" if kind == "LEGACY_WITNESS" else "AUDIT_EVENT"):
        raise RegistryBootstrapError()
    if not isinstance(value["opaque_id"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", value["opaque_id"]):
        raise RegistryBootstrapError()
    for field in ("index_sha256", "nonce_sha256", "ciphertext_sha256"):
        _hash(value[field])


def _validate(value: Any, kind: str, store_id: str) -> dict[str, Any]:
    if not isinstance(value, dict) or set(value) != _FIELDS[kind] or value["schema"] != _SCHEMAS[kind] or value["local_store_id"] != store_id:
        raise RegistryBootstrapError()
    for name, item in value.items():
        if item is None:
            continue
        if name.endswith("_id") or name.endswith("_instance"):
            _uuid(item)
        elif name.endswith("_sha256"):
            _hash(item)
        elif name.endswith("_at"):
            _utc(item)
    for field in ("local_store_id", "origin_process_instance", "origin_source_sha256"):
        if value[field] is None:
            raise RegistryBootstrapError()
    if kind in {"event", "proof"}:
        proof_kind = value["proof_kind"]
        if proof_kind is not None and (not isinstance(proof_kind, str) or proof_kind not in _KINDS):
            raise RegistryBootstrapError()
        _witness(value["witness"], proof_kind)
        # No recovery authority exists: admitting a legacy-ledger exemption here
        # would silently enable the explicitly deferred poisoned-store workflow.
        if value["legacy_ledger"] is not None:
            raise RegistryBootstrapError("RECOVERY_REVIEW_REQUIRED")
    if kind == "event":
        if type(value["sequence"]) is not int or not 1 <= value["sequence"] <= MAX_EVENTS or value["action"] not in _ACTIONS:
            raise RegistryBootstrapError()
        if value["event_type"] == "BEGIN":
            if value["begin_event_id"] != value["event_id"] or any(value[field] is not None for field in ("completed_at", "outcome_code", "completion_process_instance", "completion_source_sha256", "proof_id", "proof_kind", "witness", "legacy_ledger")):
                raise RegistryBootstrapError()
        elif value["event_type"] == "RESULT":
            if value["outcome_code"] not in _OUTCOMES or any(value[field] is None for field in ("completed_at", "completion_process_instance", "completion_source_sha256")):
                raise RegistryBootstrapError()
            if value["outcome_code"] == "SUCCESS":
                if value["proof_id"] is None or value["proof_kind"] is None:
                    raise RegistryBootstrapError()
                expected_action = "ADOPT_EXISTING_AUDIT" if value["proof_kind"] == "EXISTING_AUDIT" else "INITIALIZE"
                if value["action"] != expected_action:
                    raise RegistryBootstrapError()
            elif any(value[field] is not None for field in ("proof_id", "proof_kind", "witness")):
                raise RegistryBootstrapError()
        else:
            raise RegistryBootstrapError()
        if any(value[field] is None for field in ("event_id", "begin_event_id", "request_id", "started_at")):
            raise RegistryBootstrapError()
    elif any(item is None for name, item in value.items() if name not in {"witness", "legacy_ledger"}):
        raise RegistryBootstrapError()
    return value


def _private_file(path: Path, *, missing: bool = False) -> os.stat_result | None:
    try:
        info = path.lstat()
    except FileNotFoundError:
        if missing:
            return None
        raise RegistryBootstrapError("REGISTRY_STORAGE_UNAVAILABLE") from None
    if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o600 or info.st_uid != os.getuid() or info.st_nlink != 1:
        raise RegistryBootstrapError("REGISTRY_STORAGE_UNAVAILABLE")
    return info


def guard_storage(path: Path, *, expected: tuple[int, int] | None = None) -> tuple[int, int]:
    try:
        directory = path.parent.lstat()
        if not stat.S_ISDIR(directory.st_mode) or stat.S_IMODE(directory.st_mode) != 0o700 or directory.st_uid != os.getuid():
            raise RegistryBootstrapError("REGISTRY_STORAGE_UNAVAILABLE")
        info = _private_file(path)
        for suffix in ("-wal", "-shm", "-journal", ".bootstrap-lock", ".bootstrap-key"):
            _private_file(path.with_name(path.name + suffix), missing=True)
        identity = (info.st_dev, info.st_ino)
        if expected is not None and identity != expected:
            raise RegistryBootstrapError("REGISTRY_STORAGE_UNAVAILABLE")
        return identity
    except OSError as error:
        raise RegistryBootstrapError("REGISTRY_STORAGE_UNAVAILABLE") from error


def prepare_storage(path: Path) -> tuple[int, int]:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    directory = path.parent.lstat()
    if not stat.S_ISDIR(directory.st_mode) or stat.S_IMODE(directory.st_mode) != 0o700 or directory.st_uid != os.getuid():
        raise RegistryBootstrapError("REGISTRY_STORAGE_UNAVAILABLE")
    try:
        descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    except FileExistsError:
        pass
    else:
        os.close(descriptor)
    return guard_storage(path)


class RegistryBootstrap:
    def __init__(self, *, path: Path, data_key: bytes, store_id: str,
                 process_instance: str, source_sha256: str) -> None:
        if not isinstance(data_key, bytes) or len(data_key) != 32:
            raise RegistryBootstrapError()
        _hash(source_sha256)
        self.path = Path(path)
        self._storage_identity = guard_storage(self.path)
        self.store_id = _uuid(store_id)
        self.process_instance = _uuid(process_instance)
        self.source_sha256 = source_sha256
        self._data_cipher = AESGCM(data_key)
        self._bootstrap_key: bytes | None = None

    @staticmethod
    def initialize_tables(connection: sqlite3.Connection) -> None:
        statements = (
            "CREATE TABLE IF NOT EXISTS registry_bootstrap_identity(singleton INTEGER PRIMARY KEY CHECK(singleton=1),identity_id TEXT NOT NULL UNIQUE,nonce BLOB NOT NULL,ciphertext BLOB NOT NULL)",
            "CREATE TABLE IF NOT EXISTS registry_bootstrap_events(event_id TEXT PRIMARY KEY,sequence INTEGER NOT NULL UNIQUE CHECK(sequence>0),nonce BLOB NOT NULL,ciphertext BLOB NOT NULL)",
            "CREATE TABLE IF NOT EXISTS registry_bootstrap_attempts(begin_event_id TEXT PRIMARY KEY REFERENCES registry_bootstrap_events(event_id),request_id TEXT NOT NULL UNIQUE,result_event_id TEXT UNIQUE REFERENCES registry_bootstrap_events(event_id))",
            "CREATE TABLE IF NOT EXISTS registry_data_key_proof(singleton INTEGER PRIMARY KEY CHECK(singleton=1),proof_id TEXT NOT NULL UNIQUE,nonce BLOB NOT NULL,ciphertext BLOB NOT NULL)",
            "CREATE TABLE IF NOT EXISTS registry_bootstrap_proof_binding(singleton INTEGER PRIMARY KEY CHECK(singleton=1),binding_id TEXT NOT NULL UNIQUE,proof_id TEXT NOT NULL UNIQUE REFERENCES registry_data_key_proof(proof_id),nonce BLOB NOT NULL,ciphertext BLOB NOT NULL)",
        )
        for statement in statements:
            connection.execute(statement)

    @contextmanager
    def locked(self) -> Iterator[None]:
        guard_storage(self.path, expected=self._storage_identity)
        lock = self.path.with_name(self.path.name + ".bootstrap-lock")
        try:
            descriptor = os.open(lock, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
        except OSError as error:
            raise RegistryBootstrapError("REGISTRY_STORAGE_UNAVAILABLE") from error
        acquired = False
        body_failed = True
        try:
            actual, named = os.fstat(descriptor), _private_file(lock)
            if (actual.st_dev, actual.st_ino) != (named.st_dev, named.st_ino):
                raise RegistryBootstrapError("REGISTRY_STORAGE_UNAVAILABLE")
            deadline = time.monotonic() + 5.0
            while True:
                try:
                    fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    acquired = True
                    break
                except BlockingIOError:
                    if time.monotonic() >= deadline:
                        raise RegistryBootstrapError("REGISTRY_BOOTSTRAP_BUSY") from None
                    time.sleep(0.01)
                except OSError as error:
                    raise RegistryBootstrapError("REGISTRY_STORAGE_UNAVAILABLE") from error
            guard_storage(self.path, expected=self._storage_identity)
            yield
            body_failed = False
        finally:
            try:
                if acquired:
                    try:
                        fcntl.flock(descriptor, fcntl.LOCK_UN)
                    except OSError as error:
                        if not body_failed:
                            raise RegistryBootstrapError("REGISTRY_STORAGE_UNAVAILABLE") from error
            finally:
                os.close(descriptor)

    @staticmethod
    def _writer(connection: sqlite3.Connection) -> None:
        if not connection.in_transaction:
            connection.execute("BEGIN IMMEDIATE")
        connection.execute("UPDATE registry_bootstrap_attempts SET request_id=request_id WHERE 0")

    def _preflight_shape(self, connection: sqlite3.Connection) -> None:
        """Reject malformed metadata before it can be mistaken for a legacy store.

        Structural consistency is not key authority. A proof/binding pair may
        exist before its RESULT inside establishment's transaction; only the
        authenticated ledger and complete proof check can authorize access.
        """
        try:
            self._writer(connection)
            present: list[bool] = []
            for table in ("registry_bootstrap_identity", "registry_data_key_proof", "registry_bootstrap_proof_binding"):
                rows = connection.execute(f"SELECT singleton FROM {table} LIMIT 2").fetchall()
                if len(rows) > 1 or (rows and (type(rows[0][0]) is not int or rows[0][0] != 1)):
                    raise RegistryBootstrapError()
                present.append(bool(rows))
            event_count = connection.execute(
                "SELECT COUNT(*) FROM (SELECT 1 FROM registry_bootstrap_events LIMIT ?)",
                (MAX_EVENTS + 1,),
            ).fetchone()[0]
            attempt_count = connection.execute(
                "SELECT COUNT(*) FROM (SELECT 1 FROM registry_bootstrap_attempts LIMIT ?)",
                (MAX_EVENTS // 2 + 1,),
            ).fetchone()[0]
            pending_count = connection.execute(
                "SELECT COUNT(*) FROM (SELECT 1 FROM registry_bootstrap_attempts WHERE result_event_id IS NULL LIMIT ?)",
                (MAX_EVENTS // 2 + 1,),
            ).fetchone()[0]
            identity, proof, binding = present
            if (event_count > MAX_EVENTS or attempt_count > MAX_EVENTS // 2
                    or event_count + pending_count > MAX_EVENTS
                    or (not identity and (proof or binding or event_count or attempt_count))
                    or proof != binding or bool(event_count) != bool(attempt_count)
                    or (proof and not event_count)):
                raise RegistryBootstrapError()
        except sqlite3.Error as error:
            raise RegistryBootstrapError() from error

    def _key(self, connection: sqlite3.Connection, *, create: bool = False) -> bytes:
        guard_storage(self.path, expected=self._storage_identity)
        path = self.path.with_name(self.path.name + ".bootstrap-key")
        metadata = sum(connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] for table in ("registry_bootstrap_identity", "registry_bootstrap_events", "registry_bootstrap_attempts", "registry_data_key_proof", "registry_bootstrap_proof_binding"))
        try:
            info = _private_file(path, missing=True)
            if info is None:
                if not create or metadata:
                    raise RegistryBootstrapError("REGISTRY_BOOTSTRAP_KEY_UNAVAILABLE")
                descriptor, temporary = tempfile.mkstemp(prefix=".registry-bootstrap-key-", dir=self.path.parent)
                try:
                    with os.fdopen(descriptor, "wb") as output:
                        output.write(os.urandom(32))
                        output.flush()
                        os.fsync(output.fileno())
                    try:
                        os.link(temporary, path, follow_symlinks=False)
                    except FileExistsError:
                        pass
                finally:
                    os.unlink(temporary)
                directory = os.open(self.path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
                try:
                    os.fsync(directory)
                finally:
                    os.close(directory)
                info = _private_file(path)
            descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            try:
                opened = os.fstat(descriptor)
                if (opened.st_dev, opened.st_ino) != (info.st_dev, info.st_ino):
                    raise RegistryBootstrapError("REGISTRY_BOOTSTRAP_KEY_UNAVAILABLE")
                key = os.read(descriptor, 33)
            finally:
                os.close(descriptor)
            if len(key) != 32 or (self._bootstrap_key is not None and key != self._bootstrap_key):
                raise RegistryBootstrapError("REGISTRY_BOOTSTRAP_KEY_UNAVAILABLE")
            self._bootstrap_key = key
            return key
        except (OSError, RegistryBootstrapError) as error:
            raise RegistryBootstrapError("REGISTRY_BOOTSTRAP_KEY_UNAVAILABLE") from error

    def _decode(self, kind: str, identifier: str, nonce: Any, ciphertext: Any, cipher: AESGCM) -> dict[str, Any]:
        try:
            _uuid(identifier)
            if not isinstance(nonce, bytes) or len(nonce) != 12 or not isinstance(ciphertext, bytes) or not 17 <= len(ciphertext) <= 4112:
                raise RegistryBootstrapError()
            raw = cipher.decrypt(nonce, ciphertext, _AAD[kind] + identifier.encode("ascii"))
            if len(raw) > 4096:
                raise RegistryBootstrapError()
            value = json.loads(raw.decode("utf-8"), object_pairs_hook=_pairs, parse_constant=lambda _: (_ for _ in ()).throw(RegistryBootstrapError()))
            return _validate(value, kind, self.store_id)
        except Exception as error:
            raise RegistryBootstrapError() from error

    def _encrypt(self, kind: str, identifier: str, value: dict[str, Any], cipher: AESGCM) -> tuple[bytes, bytes]:
        _validate(value, kind, self.store_id)
        raw = _canonical(value)
        if len(raw) > 4096:
            raise RegistryBootstrapError()
        nonce = os.urandom(12)
        return nonce, cipher.encrypt(nonce, raw, _AAD[kind] + identifier.encode("ascii"))

    def ensure_identity(self, connection: sqlite3.Connection) -> dict[str, Any]:
        self._preflight_shape(connection)
        cipher = AESGCM(self._key(connection, create=True))
        row = connection.execute("SELECT * FROM registry_bootstrap_identity WHERE singleton=1").fetchone()
        if row is None:
            if any(connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] for table in ("registry_bootstrap_events", "registry_bootstrap_attempts", "registry_data_key_proof", "registry_bootstrap_proof_binding")):
                raise RegistryBootstrapError()
            identity = {"schema": _SCHEMAS["identity"], "identity_id": str(uuid4()), "local_store_id": self.store_id, "created_at": _now(), "origin_process_instance": self.process_instance, "origin_source_sha256": self.source_sha256}
            nonce, encrypted = self._encrypt("identity", identity["identity_id"], identity, cipher)
            connection.execute("INSERT INTO registry_bootstrap_identity VALUES(1,?,?,?)", (identity["identity_id"], nonce, encrypted))
            return identity
        value = self._decode("identity", row["identity_id"], row["nonce"], row["ciphertext"], cipher)
        if value["identity_id"] != row["identity_id"]:
            raise RegistryBootstrapError()
        return value

    def _ledger(self, connection: sqlite3.Connection) -> dict[str, dict[str, Any]]:
        self._preflight_shape(connection)
        cipher = AESGCM(self._key(connection))
        rows = connection.execute("SELECT * FROM registry_bootstrap_events ORDER BY sequence LIMIT 513").fetchall()
        attempts = connection.execute("SELECT * FROM registry_bootstrap_attempts LIMIT 513").fetchall()
        if len(rows) > MAX_EVENTS or len(attempts) > MAX_EVENTS // 2:
            raise RegistryBootstrapError()
        values: dict[str, dict[str, Any]] = {}
        for expected, row in enumerate(rows, 1):
            value = self._decode("event", row["event_id"], row["nonce"], row["ciphertext"], cipher)
            if value["event_id"] != row["event_id"] or value["sequence"] != row["sequence"] or row["sequence"] != expected:
                raise RegistryBootstrapError()
            values[row["event_id"]] = value
        linked: set[str] = set()
        pending = 0
        for attempt in attempts:
            begin = values.get(attempt["begin_event_id"])
            if begin is None or begin["event_type"] != "BEGIN" or begin["request_id"] != attempt["request_id"]:
                raise RegistryBootstrapError()
            linked.add(begin["event_id"])
            if attempt["result_event_id"] is None:
                pending += 1
                continue
            result = values.get(attempt["result_event_id"])
            shared = ("begin_event_id", "request_id", "action", "local_store_id", "started_at", "origin_process_instance", "origin_source_sha256")
            if result is None or result["event_type"] != "RESULT" or result["sequence"] <= begin["sequence"] or any(result[field] != begin[field] for field in shared):
                raise RegistryBootstrapError()
            linked.add(result["event_id"])
        if linked != set(values) or len(rows) + pending > MAX_EVENTS:
            raise RegistryBootstrapError()
        return values

    def begin(self, connection: sqlite3.Connection, *, action: str) -> dict[str, Any]:
        if action not in _ACTIONS:
            raise RegistryBootstrapError()
        self.ensure_identity(connection)
        values = self._ledger(connection)
        pending = connection.execute("SELECT COUNT(*) FROM registry_bootstrap_attempts WHERE result_event_id IS NULL").fetchone()[0]
        if len(values) + pending + 2 > MAX_EVENTS:
            raise RegistryBootstrapError("REGISTRY_BOOTSTRAP_CAPACITY")
        event_id = str(uuid4())
        value = {"schema": _SCHEMAS["event"], "event_id": event_id, "sequence": len(values) + 1, "event_type": "BEGIN", "begin_event_id": event_id, "request_id": str(uuid4()), "action": action, "local_store_id": self.store_id, "started_at": _now(), "completed_at": None, "outcome_code": None, "origin_process_instance": self.process_instance, "origin_source_sha256": self.source_sha256, "completion_process_instance": None, "completion_source_sha256": None, "proof_id": None, "proof_kind": None, "witness": None, "legacy_ledger": None}
        nonce, encrypted = self._encrypt("event", event_id, value, AESGCM(self._key(connection)))
        connection.execute("INSERT INTO registry_bootstrap_events VALUES(?,?,?,?)", (event_id, value["sequence"], nonce, encrypted))
        connection.execute("INSERT INTO registry_bootstrap_attempts VALUES(?,?,NULL)", (event_id, value["request_id"]))
        return value

    def finish(self, connection: sqlite3.Connection, reservation: dict[str, Any], *, outcome_code: str,
               proof_id: str | None = None, proof_kind: str | None = None,
               witness: dict[str, Any] | None = None, result_id: str | None = None,
               completed_at: str | None = None) -> dict[str, Any]:
        self._writer(connection)
        values = self._ledger(connection)
        begin = values.get(reservation.get("event_id"))
        pending = connection.execute("SELECT result_event_id FROM registry_bootstrap_attempts WHERE begin_event_id=? AND request_id=?", (reservation.get("event_id"), reservation.get("request_id"))).fetchone()
        if begin != reservation or pending is None or pending[0] is not None:
            raise RegistryBootstrapError()
        result = {**begin, "event_id": result_id or str(uuid4()), "event_type": "RESULT", "sequence": len(values) + 1, "completed_at": completed_at or _now(), "outcome_code": outcome_code, "completion_process_instance": self.process_instance, "completion_source_sha256": self.source_sha256, "proof_id": proof_id, "proof_kind": proof_kind, "witness": witness}
        nonce, encrypted = self._encrypt("event", result["event_id"], result, AESGCM(self._key(connection)))
        connection.execute("INSERT INTO registry_bootstrap_events VALUES(?,?,?,?)", (result["event_id"], result["sequence"], nonce, encrypted))
        connection.execute("UPDATE registry_bootstrap_attempts SET result_event_id=? WHERE begin_event_id=? AND result_event_id IS NULL", (result["event_id"], begin["event_id"]))
        return result

    def complete_interrupted(self, connection: sqlite3.Connection) -> None:
        self.ensure_identity(connection)
        values = self._ledger(connection)
        for row in connection.execute("SELECT begin_event_id FROM registry_bootstrap_attempts WHERE result_event_id IS NULL").fetchall():
            self.finish(connection, values[row[0]], outcome_code="INTERRUPTED_OUTCOME_UNKNOWN")

    def assert_authority(self, connection: sqlite3.Connection, audit: Any) -> str:
        guard_storage(self.path, expected=self._storage_identity)
        self._preflight_shape(connection)
        store = connection.execute("SELECT state_value FROM registry_state WHERE state_key='registry_store_id'").fetchone()
        if store is None or store[0] != self.store_id:
            raise RegistryBootstrapError()
        proof_row = connection.execute("SELECT * FROM registry_data_key_proof WHERE singleton=1").fetchone()
        binding_row = connection.execute("SELECT * FROM registry_bootstrap_proof_binding WHERE singleton=1").fetchone()
        if (proof_row is None) != (binding_row is None):
            raise RegistryBootstrapError()
        if proof_row is None:
            # A valid identity and provisional attempts do not constitute proof.
            if connection.execute("SELECT COUNT(*) FROM registry_bootstrap_identity").fetchone()[0]:
                self.ensure_identity(connection)
                if any(value["outcome_code"] == "SUCCESS" for value in self._ledger(connection).values()):
                    raise RegistryBootstrapError()
            if audit.verify_existing(connection):
                row = connection.execute("SELECT nonce,ciphertext FROM registry_audit ORDER BY sequence LIMIT 1").fetchone()
                return "legacy:" + _sha(row[0] + row[1])
            raise RegistryBootstrapError("REGISTRY_BOOTSTRAP_REQUIRED")
        identity = self.ensure_identity(connection)
        binding = self._decode("binding", self.store_id, binding_row["nonce"], binding_row["ciphertext"], AESGCM(self._key(connection)))
        if (binding["binding_id"] != binding_row["binding_id"] or binding["proof_id"] != binding_row["proof_id"]
                or binding["proof_id"] != proof_row["proof_id"] or binding["proof_nonce_sha256"] != _sha(proof_row["nonce"])
                or binding["proof_ciphertext_sha256"] != _sha(proof_row["ciphertext"])):
            raise RegistryBootstrapError()
        proof = self._decode("proof", self.store_id, proof_row["nonce"], proof_row["ciphertext"], self._data_cipher)
        values = self._ledger(connection)
        result = values.get(proof["bootstrap_result_event_id"])
        begin = values.get(proof["bootstrap_begin_event_id"])
        shared = ("proof_id", "local_store_id", "bootstrap_identity_id", "bootstrap_request_id", "bootstrap_begin_event_id", "bootstrap_result_event_id", "established_at", "origin_process_instance", "origin_source_sha256")
        if any(proof[field] != binding[field] for field in shared) or proof["bootstrap_identity_id"] != identity["identity_id"]:
            raise RegistryBootstrapError()
        if begin is None or result is None or result["outcome_code"] != "SUCCESS" or result["begin_event_id"] != begin["event_id"]:
            raise RegistryBootstrapError()
        if (proof["bootstrap_request_id"] != result["request_id"] or proof["established_at"] != result["completed_at"]
                or proof["origin_process_instance"] != result["completion_process_instance"] or proof["origin_source_sha256"] != result["completion_source_sha256"]
                or any(proof[field] != result[field] for field in ("proof_id", "proof_kind", "witness", "legacy_ledger"))):
            raise RegistryBootstrapError()
        success = [value for value in values.values() if value["outcome_code"] == "SUCCESS"]
        if len(success) != 1 or success[0] != result:
            raise RegistryBootstrapError()
        return "proof:" + proof["proof_id"] + ":" + binding["proof_ciphertext_sha256"]

    def establish(self, connection: sqlite3.Connection, reservation: dict[str, Any], *, proof_kind: str, witness: dict[str, Any] | None) -> str:
        identity = self.ensure_identity(connection)
        result_id, proof_id, binding_id, completed = str(uuid4()), str(uuid4()), str(uuid4()), _now()
        shared = {"proof_id": proof_id, "local_store_id": self.store_id, "bootstrap_identity_id": identity["identity_id"], "bootstrap_request_id": reservation["request_id"], "bootstrap_begin_event_id": reservation["event_id"], "bootstrap_result_event_id": result_id, "established_at": completed, "origin_process_instance": self.process_instance, "origin_source_sha256": self.source_sha256}
        proof = {"schema": _SCHEMAS["proof"], **shared, "challenge_id": str(uuid4()), "proof_kind": proof_kind, "witness": witness, "legacy_ledger": None}
        nonce, encrypted = self._encrypt("proof", self.store_id, proof, self._data_cipher)
        binding = {"schema": _SCHEMAS["binding"], **shared, "binding_id": binding_id, "proof_nonce_sha256": _sha(nonce), "proof_ciphertext_sha256": _sha(encrypted)}
        bnonce, bencrypted = self._encrypt("binding", self.store_id, binding, AESGCM(self._key(connection)))
        connection.execute("INSERT INTO registry_data_key_proof VALUES(1,?,?,?)", (proof_id, nonce, encrypted))
        connection.execute("INSERT INTO registry_bootstrap_proof_binding VALUES(1,?,?,?,?)", (binding_id, proof_id, bnonce, bencrypted))
        self.finish(connection, reservation, outcome_code="SUCCESS", proof_id=proof_id, proof_kind=proof_kind, witness=witness, result_id=result_id, completed_at=completed)
        return proof_id


def record_witness(row: sqlite3.Row, *, audit: bool = False) -> dict[str, Any]:
    identity = row["event_id"] if audit else row["record_id"]
    fields = ("event_id", "sequence") if audit else ("record_id", "record_type", "version", "source_class", "lifecycle")
    return {"kind": "AUDIT_EVENT" if audit else "RECORD", "opaque_id": identity,
            "index_sha256": _sha(_canonical({field: row[field] if field in row.keys() else None for field in fields})),
            "nonce_sha256": _sha(row["nonce"]), "ciphertext_sha256": _sha(row["ciphertext"])}


def recover_unverified_audit(path: Any, *, data_key: Any) -> None:
    """No supported exclusion barrier exists for already-open older executables."""
    raise RegistryBootstrapError("RECOVERY_REVIEW_REQUIRED")
