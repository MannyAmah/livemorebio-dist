"""
livemorebio.aegle.runtime — the central twin the console renders.

AegleTwin executes reduced glucose-insulin and cardiac-cell models. The current
intervention workflow recomputes trajectories under changed parameters; these are
modeled responses with explicit initialization provenance. Patch observations are
stored separately and do not silently rewrite model parameters.

Unimplemented systems remain pending. Unknown compounds and unqualified
compound-to-GEM-to-physiology transformations fail before changing the twin.
"""
from __future__ import annotations
from dataclasses import asdict, replace
import hashlib
import numpy as np
from ..engines.metabolic.glucose_insulin import (
    MetabolicProfile, GlucoseInsulinModel, HEALTHY, T2D, summarize)
from ..engines.metabolic.interventions import metformin, plant_compound
from ..engines.cardiac.action_potential import CardiacCell
from ..engines.coupling.metabolic_cardiac import hyperglycemia_to_ikr_block
from .observation_state import ObservationState

SYSTEMS = [
    {"id": "cardiac",     "name": "Heart — ventricular myocyte", "engine": "O'Hara–Rudy CiPA 2017 (49-state)", "status": "alive"},
    {"id": "metabolic",   "name": "Metabolic axis — pancreas · liver · gut", "engine": "glucose–insulin ODE (Bergman)", "status": "alive"},
    {"id": "vascular",    "name": "Vasculature", "engine": None, "status": "pending"},
    {"id": "renal",       "name": "Kidney", "engine": None, "status": "pending"},
    {"id": "neural",      "name": "Brain", "engine": None, "status": "pending"},
    {"id": "immune",      "name": "Immune system", "engine": None, "status": "pending"},
    {"id": "respiratory", "name": "Lungs", "engine": None, "status": "pending"},
    {"id": "hepatic",     "name": "Liver — drug metabolism (PK)", "engine": "1-compartment oral PK (Bateman), individualized OCT1/renal/CYP", "status": "alive"},
]
DEFAULT_MEALS = [(0, 60), (300, 75), (660, 90)]


def _ds(a, n=220):
    a = np.asarray(a, dtype=float)
    idx = np.linspace(0, len(a) - 1, min(n, len(a))).astype(int)
    return np.round(a[idx], 4).tolist()


class AegleTwin(ObservationState):
    def __init__(self, base: str = "healthy", human=None):
        super().__init__()
        self.human = human
        if human is not None:
            self.base = "life_system"
            if hasattr(human, "parameter_provenance"):
                self.profile = human.metabolic_profile(None)
            else:
                from ..life_system.knowledge import get_kb

                self.profile = human.metabolic_profile(get_kb())
        else:
            if base not in ("healthy", "t2d", "type-2-diabetes"):
                raise ValueError("Unsupported twin template; choose healthy or type-2-diabetes")
            self.base = base
            self.profile = HEALTHY if base == "healthy" else T2D
        self._initial_profile_values = asdict(self.profile)
        self.meals = list(DEFAULT_MEALS)
        self.cardiac_drug_block = 0.0
        self.cardiac_cl_ms = None
        self.hr_measured = False
        self.provenance = {"glucose": "synthetic-model", "hr": "synthetic-model", "temp": "synthetic-model"}
        self.applied = []
        self.last_intervention = None
        self.pk_last = None                 # last hepatic-PK exposure profile (real engine output)
        self.heart = CardiacCell()
        self._recompute()
        initial = self._comparison_snapshot()
        self.comparison = {
            "intervention": "none",
            "baseline": initial,
            "treated": dict(initial),
        }

    def _recompute(self):
        from ..engines.cardiac.heart_rate import resting_heart_rate, hr_series, hrv_rmssd
        from ..life_patch.driver import hr_to_cl_ms
        self.metabolic = GlucoseInsulinModel(self.profile).simulate(hours=14, meals_g=self.meals)
        self.mean_glucose = float(self.metabolic["glucose"].mean())
        hg = hyperglycemia_to_ikr_block(self.mean_glucose)
        self.ikr_block = min(0.9, hg + self.cardiac_drug_block)
        # individualized resting HR from autonomic + metabolic state (real measured HR wins)
        if self.human is not None:
            age, life, conds = self.human.age, self.human.lifestyle, list(self.human.conditions)
        else:
            age, life = 50, 0.6
            conds = [] if self.base == "healthy" else ["type 2 diabetes"]
        if not self.hr_measured:
            self.resting_hr = resting_heart_rate(age, life, self.mean_glucose, self.profile.Si, conds)
            self.cardiac_cl_ms = hr_to_cl_ms(self.resting_hr)
        else:
            self.resting_hr = round(60000.0 / self.cardiac_cl_ms, 1)
        self.hr_series = hr_series(list(self.metabolic["t_min"]), list(self.metabolic["glucose"]), self.resting_hr)
        self.hr_vals = [h for _, h in self.hr_series]
        self.hrv_ms = hrv_rmssd(self.resting_hr, self.profile.Si, self.mean_glucose, conds)
        self.cardiac = self.heart.simulate(beats=6, ikr_block=self.ikr_block, cl_ms=self.cardiac_cl_ms)

    def _comparison_snapshot(self) -> dict:
        """Bounded engine outputs used for baseline-versus-treated comparison."""
        metabolic = self.metabolic
        cardiac = self.cardiac
        return {
            "mean_glucose_mg_dL": round(self.mean_glucose, 4),
            "glucose": _ds(metabolic["glucose"]),
            "insulin": _ds(metabolic["insulin"]),
            "t_min": _ds(metabolic["t_min"]),
            "heart_rate_bpm": round(self.resting_hr, 4),
            "hrv_ms": round(self.hrv_ms, 4),
            "apd90_ms": round(float(cardiac["apd90_ms"]), 4),
        }

    def ingest_patch(self, packets) -> dict:
        """Admit legacy packets as observations without rewriting model parameters.

        This compatibility path is retained for the demo streams.  Governed v2
        devices use :meth:`ingest_patch_envelope`.
        """
        src, hw, last_t = None, False, None
        latest = {}
        for pk in packets:
            src = pk.source
            hw = hw or pk.hardware_present
            last_t = pk.t_s
            for m in pk.measurements:
                latest[m.signal] = {
                    "value": float(m.value), "unit": _legacy_unit(m.signal),
                    "claim": m.claim, "captured_at": float(m.t_s),
                    "quality_status": "not_assessed", "calibration_status": "not_assessed",
                    "envelope_id": None,
                    "mode": "virtual", "provenance": "technical_fixture",
                    "source_data_class": "technical_fixture", "received_at": None,
                }
        measured = src not in (None, "synthetic-from-engine")
        self.observations.update(latest)
        # Observations never change the provenance of separately computed traces.
        if latest:
            self.applied.append(f"LIFE Patch observation · {src} ({len(latest)} signals)")
        self.patch = {
            "connected": bool(latest), "source": src,
            "mode": "physical" if hw else ("external" if measured else "virtual"),
            "hardware_present": hw, "protocol_version": "legacy-v1-demo",
            "sequence": last_t, "envelope_id": None, "device_id": None,
        }
        return self.state()

    def ingest_patch_envelope(self, envelope, *, received_at=None) -> dict:
        """Attach an admitted envelope without reclassifying or calibrating it."""
        return ObservationState.ingest_patch_envelope(self, envelope, received_at=received_at)

    def stimulate(self, kind: str, **p) -> dict:
        baseline = self._comparison_snapshot()
        if kind == "meal":
            self.meals = self.meals + [(int(p.get("minute", 0)), float(p.get("grams", 60)))]
            self.applied.append(f"meal {int(p.get('grams',60))} g")
        elif kind == "metabolic_drug":
            from ..engines import pharmacology as PH
            name = p.get("name", "metformin")
            if name == "metformin":
                from ..engines.hepatic_pk import pk_profile
                from types import SimpleNamespace

                dose = float(p.get("dose", 1.0))
                pk_human = SimpleNamespace(
                    age=getattr(self.human, "age", 50),
                    genome=getattr(self.human, "genome", {}),
                    weight_kg=self.profile.weight_kg,
                )
                self.pk_last = pk_profile("metformin", dose_mg=1000.0 * dose, human=pk_human)
                self.profile, why = PH.metformin(self.profile, self.human, dose, pk=self.pk_last)
            else:
                self.profile, why = PH.plant_compound(self.profile, self.human, name=name,
                                                      dose=float(p.get("dose", 1.0)))
            self.last_intervention = why
            self.applied.append(
                f"{name} → Si +{why['realized_Si_gain_pct']}% · Gb −{why['realized_Gb_drop_pct']}%")
        elif kind == "gem_drug":
            from ..engines.integrity import UnsupportedInterventionError

            raise UnsupportedInterventionError(
                "No qualified concentration-to-flux and flux-to-physiology model is available"
            )
        elif kind == "food":
            # Carbohydrate enters the existing meal equation. A constituent list
            # supplies no concentration or qualified phytochemical-effect model.
            from ..engines import foods as FD
            name = p.get("name", "moringa"); grams = float(p.get("grams", 100))
            if not np.isfinite(grams) or grams <= 0 or grams > 2000:
                raise ValueError("food grams must be finite and within (0, 2000]")
            food = FD.resolve_food(name)
            carb = (food.get("macros") or {}).get("carb_g")
            if carb is None or not np.isfinite(float(carb)) or float(carb) < 0:
                raise ValueError("food carbohydrate composition is unavailable")
            carb = float(carb)
            if carb:
                self.meals = self.meals + [(0, carb * grams / 100.0)]
            why = {"food": name, "grams": grams, "carb_load_g": round(carb * grams / 100.0, 1),
                   "macros": food["macros"], "evidence_state": "MODELED_NUTRIENT_EXPOSURE",
                   "phytochemical_effect": "NOT_ASSESSABLE",
                   "reason": "no qualified phytochemical dose-response translation",
                   "molecular_signature": [], "disease_signature": []}
            self.last_intervention = why
            self.applied.append(f"food: {name} ({int(grams)}g) · {why['carb_load_g']}g carbohydrate")
        elif kind == "factor":
            # non-food factor: physiological (stress/sleep/exercise) -> profile modifiers;
            # chemical/environmental (BPA, nicotine) -> molecular + disease signature.
            from ..engines import factors as FA
            name = p.get("name", "chronic stress"); intensity = float(p.get("intensity", 1.0))
            f = FA.resolve_factor(name)
            if f.get("kind") == "physiological":
                si_mult = 1 - intensity * (1 - f.get("si_mult", 1.0))
                gb_mult = 1 + intensity * (f.get("gb_mult", 1.0) - 1)
                self.profile = replace(self.profile, Si=self.profile.Si * si_mult, Gb=self.profile.Gb * gb_mult)
                why = {"source": "non-food factor", "factor": name, "kind": "physiological",
                       "mechanism": f.get("mechanism"),
                       "d_Si_pct": round((si_mult - 1) * 100, 1), "d_Gb_pct": round((gb_mult - 1) * 100, 1)}
                self.applied.append(f"factor: {name} → Si {why['d_Si_pct']}% · Gb {why['d_Gb_pct']}%")
            else:
                sig = FA.factor_disease_signature(name, top=6)
                genes = sorted({t["gene"] for t in f.get("targets", [])})
                why = {"source": "non-food factor", "food": name, "description": "environmental exposure",
                       "macros": {}, "carb_load_g": 0, "targets_in_metabolic_model": 0,
                       "molecular_signature": [{"compound": name, "targets": genes[:8]}] if genes else [],
                       "disease_signature": sig}
                self.applied.append(f"factor: {name} → {len(sig)} disease links")
            self.last_intervention = why
        elif kind == "cardiac_drug":
            self.cardiac_drug_block = float(p.get("ikr_block", 0.5))
            self.applied.append(f"hERG block {int(self.cardiac_drug_block*100)}%")
        elif kind == "lifestyle":
            self.profile = replace(self.profile,
                                   Si=self.profile.Si * (1 + float(p.get("si_delta", 0.0))),
                                   Gb=self.profile.Gb * (1 + float(p.get("gb_delta", 0.0))))
            self.applied.append("lifestyle/environment")
        elif kind == "reset":
            if self.human is not None:
                from ..life_system.knowledge import get_kb
                self.profile = self.human.metabolic_profile(get_kb())
            else:
                self.profile = HEALTHY if self.base == "healthy" else T2D
            self.meals = list(DEFAULT_MEALS); self.cardiac_drug_block = 0.0; self.applied = []
            self.last_intervention = None
            self.pk_last = None
            self.cardiac_cl_ms = None
            self.provenance = {"glucose": "synthetic-model", "hr": "synthetic-model", "temp": "synthetic-model"}
            self.patch = {"connected": False, "source": None, "mode": None,
                          "hardware_present": False, "protocol_version": None,
                          "sequence": None, "envelope_id": None, "device_id": None}
            self.observations = {}
        self._recompute()
        if kind == "reset":
            current = self._comparison_snapshot()
            self.comparison = {
                "intervention": "none", "baseline": current, "treated": dict(current),
            }
        else:
            intervention_name = kind
            if isinstance(self.last_intervention, dict):
                intervention_name = str(
                    self.last_intervention.get("drug")
                    or self.last_intervention.get("factor")
                    or self.last_intervention.get("food")
                    or kind
                )
            self.comparison = {
                "intervention": intervention_name,
                "baseline": baseline,
                "treated": self._comparison_snapshot(),
            }
        return self.state()

    def parameter_provenance(self) -> dict:
        if self.human is not None and hasattr(self.human, "parameter_provenance"):
            origins = self.human.parameter_provenance()
        else:
            origins = {
                key: {"value": value, "evidence_class": "MODEL_INITIALIZED",
                      "source_id": "legacy-model-prior", "person_fitted": False}
                for key, value in self._initial_profile_values.items() if key != "name"
            }
        result = {}
        for key, origin in origins.items():
            current = getattr(self.profile, key)
            changed = current != origin["value"]
            result[key] = {**origin, "initial_value": origin["value"], "value": current,
                           "initial_evidence_class": origin["evidence_class"],
                           "evidence_class": "MODEL_PARAMETER_CHANGE" if changed else origin["evidence_class"]}
        return result

    def state(self) -> dict:
        m, c = self.metabolic, self.cardiac
        p = self.profile
        from ..foundation import whole_human_manifest
        capability = whole_human_manifest()
        return {
            "profile": self.profile.name, "base": self.base, "applied": self.applied,
            # Retained model parameters support an authenticated frozen Cendos
            # capture and evidence reconstruction, not proof of human equivalence.
            "profile_params": asdict(p),
            "pk_context": {
                "age": getattr(self.human, "age", 50),
                "genome": dict(getattr(self.human, "genome", {})),
                "evidence_class": "DECLARED_PERSON_CONTEXT" if self.human else "REFERENCE_INITIALIZED",
            },
            "parameter_provenance": self.parameter_provenance(),
            "systems": SYSTEMS, "provenance": self.provenance, "patch": self.patch,
            "observations": self.observations,
            "capability": {
                "schema": capability["schema"],
                "current_release_claim": capability["current_release_claim"],
                "maturity": {
                    "person_calibrated": False,
                    "context_validated": False,
                    "independently_replicated": False,
                    "device_connected": False,
                    "packet_admitted": bool(self.patch.get("connected")),
                },
                "claim_rule": capability["claim_rule"],
            },
            "human": ({"id": self.human.id, "age": self.human.age, "sex": self.human.sex,
                       "conditions": self.human.conditions, "genome": self.human.genome,
                       "lifestyle": self.human.lifestyle} if self.human else None),
            "intervention": self.last_intervention,
            # hepatic PK: real engine output for the last dosed drug (None until a dose)
            "hepatic": ({k: self.pk_last[k] for k in
                         ("drug", "dose_mg", "model", "params", "individualization",
                          "cmax_mg_L", "tmax_h", "t_half_h", "auc_mg_h_L",
                          "exposure_ratio", "hepatic_exposure_ratio", "note")}
                        | {"t_h": self.pk_last["t_h"], "conc_mg_L": self.pk_last["conc_mg_L"]}
                        if self.pk_last else None),
            "metabolic": {"t_min": _ds(m["t_min"]), "glucose": _ds(m["glucose"]),
                          "insulin": _ds(m["insulin"]), "mean_glucose": round(self.mean_glucose, 1),
                          "summary": summarize(m)},
            "cardiac": {"t_ms": _ds(c["t"]), "v": _ds(c["v"]), "cai": _ds(c["cai"]),
                        "vrest": c["vrest"], "vpeak": c["vpeak"], "apd90_ms": c["apd90_ms"],
                        "cai_peak_uM": c["cai_peak_uM"], "ikr_block": round(self.ikr_block, 3),
                        "hr_bpm": round(self.resting_hr, 0), "hrv_ms": round(self.hrv_ms, 0),
                        "cl_ms": round(self.cardiac_cl_ms, 1),
                        "hr_series": [[round(float(tt), 1), round(float(hh), 1)]
                                      for tt, hh in zip(_ds(m["t_min"]), _ds(self.hr_vals))]},
        }


def _legacy_unit(signal: str) -> str:
    return {
        "glucose_mgdl": "mg/dL", "hr_bpm": "bpm", "hrv_ms": "ms",
        "skin_temp_c": "Cel", "spo2_pct": "%", "lactate_mM": "mmol/L",
        "sodium_mM": "mmol/L", "potassium_mM": "mmol/L", "ecg_mv": "mV",
    }.get(signal, "1")
