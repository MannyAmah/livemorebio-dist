"""Governed source metadata for person and reference-grounded twin profiles.

This module validates provenance. It does not make a source scientifically
qualified and it never upgrades model output into an observation.
"""
from __future__ import annotations

from typing import Any, Callable
from .capture_time import normalize_capture_time


PROFILE_SOURCE_KINDS = frozenset({
    "FHIR_R4", "LIFE_PATCH", "WEARABLE", "LAB", "GENOMIC",
    "MEDICATION", "LIFESTYLE", "ENVIRONMENT", "PATIENT_REPORTED",
    "REFERENCE_POPULATION", "LEGACY_ADMISSION",
})
PROFILE_DOMAINS = frozenset({
    "demographics", "conditions", "medical_history", "medications", "labs",
    "genomics", "physiology", "lifestyle", "environment", "allergies",
    "procedures", "family_history",
})
CORE_PROFILE_DOMAINS = frozenset({
    "demographics", "conditions", "medications", "labs", "physiology",
    "lifestyle", "environment", "genomics",
})
EXACT_LOCATION_KEYS = frozenset({
    "latitude", "longitude", "lat", "lon", "lng", "street", "address",
    "postal_address", "gps",
})


def _pick_source(sources: list[dict[str, Any]], domain: str) -> dict[str, Any] | None:
    return next((source for source in sources if domain in source["domains"]), None)


def normalize_profile_sources(
    value: object,
    *,
    source_class: str,
    chain_of_custody: str,
    observations_present: bool,
    error: Callable[[str, str], Exception],
) -> list[dict[str, Any]]:
    """Validate a bounded source ledger, with a compatibility source for v1 records."""
    if value is None:
        domains = ["demographics"]
        if observations_present:
            domains.extend(["labs", "physiology"])
        if source_class == "REAL_HUMAN":
            return [{
                "source_id": "legacy-admission",
                "kind": "LEGACY_ADMISSION",
                "system": "local_subject_registry",
                "release": "v1-compatibility",
                "captured_at": "not_provided",
                "provenance_uri": chain_of_custody or "urn:livemore:legacy-admission",
                "quality_status": "not_assessed",
                "domains": sorted(set(domains)),
            }]
        return []
    if not isinstance(value, list) or not value or len(value) > 50:
        raise error("PROFILE_SOURCE_INVALID", "profile_sources must contain 1 to 50 source records")
    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, item in enumerate(value):
        if not isinstance(item, dict):
            raise error("PROFILE_SOURCE_INVALID", f"profile_sources[{index}] must be an object")
        source_id = str(item.get("source_id", "")).strip()
        kind = str(item.get("kind", "")).strip().upper()
        system = str(item.get("system", "")).strip()
        release = str(item.get("release", "")).strip()
        try:
            captured_at = normalize_capture_time(item.get("captured_at"), field=f"profile_sources[{index}].captured_at")
        except ValueError as failure:
            raise error("PROFILE_SOURCE_INVALID", str(failure)) from None
        provenance_uri = str(item.get("provenance_uri", "")).strip()
        quality_status = str(item.get("quality_status", "not_assessed")).strip().lower()
        domains_value = item.get("domains")
        if not source_id or len(source_id) > 120 or source_id in seen:
            raise error("PROFILE_SOURCE_INVALID", f"profile_sources[{index}].source_id is missing, duplicate, or too long")
        if kind not in PROFILE_SOURCE_KINDS:
            raise error("PROFILE_SOURCE_INVALID", f"profile_sources[{index}].kind is unsupported")
        if any(not field or len(field) > 240 for field in (system, release, captured_at, provenance_uri)):
            raise error("PROFILE_SOURCE_INVALID", f"profile_sources[{index}] is missing bounded provenance metadata")
        if not isinstance(domains_value, list) or not domains_value or len(domains_value) > len(PROFILE_DOMAINS):
            raise error("PROFILE_SOURCE_INVALID", f"profile_sources[{index}].domains must be a non-empty list")
        domains = sorted({str(domain).strip().lower() for domain in domains_value})
        if any(domain not in PROFILE_DOMAINS for domain in domains):
            raise error("PROFILE_SOURCE_INVALID", f"profile_sources[{index}] declares an unsupported profile domain")
        seen.add(source_id)
        normalized.append({
            "source_id": source_id,
            "kind": kind,
            "system": system,
            "release": release,
            "captured_at": captured_at,
            "provenance_uri": provenance_uri,
            "quality_status": quality_status[:40],
            "domains": domains,
        })
    return normalized


def validate_environment(value: object, *, error: Callable[[str, str], Exception]) -> dict[str, str]:
    if value is None:
        return {}
    if not isinstance(value, dict) or len(value) > 20:
        raise error("INVALID_TWIN_DATA", "environment must be an object with at most 20 fields")
    lowered = {str(key).strip().lower() for key in value}
    if lowered & EXACT_LOCATION_KEYS:
        raise error(
            "EXACT_LOCATION_NOT_ADMITTED",
            "exact location is not admitted to the twin profile; provide a region-level exposure context",
        )
    result: dict[str, str] = {}
    for key, raw in value.items():
        name = str(key).strip()
        text = str(raw or "").strip()
        if not name or len(name) > 80 or not text or len(text) > 160:
            raise error("INVALID_TWIN_DATA", "environment fields must be non-empty bounded strings")
        result[name] = text
    return result


def validate_medications(value: object, *, error: Callable[[str, str], Exception]) -> list[dict[str, str]]:
    if value is None:
        return []
    if not isinstance(value, list) or len(value) > 100:
        raise error("INVALID_TWIN_DATA", "medications must be a list with at most 100 entries")
    result: list[dict[str, str]] = []
    for index, item in enumerate(value):
        if not isinstance(item, dict):
            raise error("INVALID_TWIN_DATA", f"medications[{index}] must be an object")
        name = str(item.get("name", "")).strip()
        status = str(item.get("status", "unknown")).strip()
        if not name or len(name) > 160 or not status or len(status) > 80:
            raise error("INVALID_TWIN_DATA", f"medications[{index}] has invalid name or status")
        result.append({"name": name, "status": status})
    return result


def build_profile_provenance(
    *,
    sources: list[dict[str, Any]],
    conditions: list[str],
    medications: list[dict[str, str]],
    observations: dict[str, dict[str, Any]],
    genome: dict[str, int],
    admitted_domain_presence: dict[str, bool],
    source_class: str,
) -> tuple[dict[str, Any], dict[str, dict[str, str]]]:
    declared_domains = {domain for source in sources for domain in source["domains"]}
    actual_domains = {domain for domain, present in admitted_domain_presence.items() if present}
    domains = sorted(declared_domains & actual_domains)
    coverage = {
        "status": "ADMITTED_COMPLETE" if CORE_PROFILE_DOMAINS.issubset(set(domains)) else "ADMITTED_PARTIAL",
        "domains": domains,
        "declared_domains": sorted(declared_domains),
        "actual_domains": sorted(actual_domains),
        "missing_core_domains": sorted(CORE_PROFILE_DOMAINS - set(domains)),
        "source_count": len(sources),
    }
    provenance: dict[str, dict[str, str]] = {}

    def bind(field: str, domain: str, evidence_class: str) -> None:
        source = _pick_source(sources, domain)
        if source is None:
            provenance[field] = {
                "source_id": "model-default" if source_class != "REAL_HUMAN" else "unresolved",
                "evidence_class": "MODEL_INITIALIZED" if source_class != "REAL_HUMAN" else "SOURCE_UNRESOLVED",
            }
        else:
            provenance[field] = {"source_id": source["source_id"], "evidence_class": evidence_class}

    bind("demographics.age", "demographics", "MEASURED_CLINICAL" if source_class == "REAL_HUMAN" else "REFERENCE_INITIALIZED")
    bind("demographics.sex", "demographics", "MEASURED_CLINICAL" if source_class == "REAL_HUMAN" else "REFERENCE_INITIALIZED")
    for index, _condition in enumerate(conditions):
        bind(f"conditions.{index}", "conditions", "MEASURED_CLINICAL" if source_class == "REAL_HUMAN" else "REFERENCE_INITIALIZED")
    for index, _medication in enumerate(medications):
        bind(f"medications.{index}.name", "medications", "MEASURED_CLINICAL" if source_class == "REAL_HUMAN" else "REFERENCE_INITIALIZED")
    for signal in observations:
        bind(f"observations.{signal}", "labs", "MEASURED_CLINICAL" if source_class == "REAL_HUMAN" else "REFERENCE_INITIALIZED")
    for key in genome:
        bind(f"genome.{key}", "genomics", "MEASURED_GENOMIC" if source_class == "REAL_HUMAN" else "REFERENCE_INITIALIZED")
    if admitted_domain_presence.get("lifestyle", False):
        bind("lifestyle", "lifestyle", "PATIENT_REPORTED" if source_class == "REAL_HUMAN" else "REFERENCE_INITIALIZED")
    if admitted_domain_presence.get("environment", False):
        bind("environment", "environment", "REFERENCE_CONTEXT")
    return coverage, provenance


__all__ = [
    "CORE_PROFILE_DOMAINS", "PROFILE_DOMAINS", "PROFILE_SOURCE_KINDS",
    "build_profile_provenance", "normalize_profile_sources", "validate_environment",
    "validate_medications",
]
