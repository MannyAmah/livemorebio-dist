"""Deterministic research-person generation from governed population anchors.

Generated members are synthetic. Public aggregate measurements and Livemore
model priors are recorded separately so no modeled parameter can masquerade as
a measured source variable or participant row.
"""
from __future__ import annotations

import hashlib
import math
import random
from typing import Any, Callable


STRATA = frozenset({
    "dpp-high-risk-metabolic",
    "nhanes-diagnosed-diabetes-older",
    "pxr-reference",
})

SUPPORTED_REFERENCE_SOURCES: dict[str, dict[str, Any]] = {
    "livemore-public-metabolic-reference-v1": {
        "provider": "CDC/NCHS and NIDDK Diabetes Prevention Program",
        "release": "NHANES August 2021-August 2023 + DPP baseline publication PMID 11092283",
        "provenance_uri": "https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?Cycle=2021-2023",
        "population": "Public aggregate anchors; no participant row is copied or persisted",
        "parameterization": "published/computed aggregate anchors plus bounded deterministic synthetic sampling",
        "supporting_sources": [
            "https://pubmed.ncbi.nlm.nih.gov/11092283/",
            "https://wwwn.cdc.gov/Nchs/Nhanes/2021-2022/GLU_L.htm",
            "https://wwwn.cdc.gov/Nchs/Nhanes/2021-2022/DEMO_L.htm",
        ],
    },
}


def normalize_reference_source(
    value: object, *, error: Callable[[str, str], Exception],
) -> dict[str, Any]:
    """Resolve a caller's source ID to immutable server-owned metadata."""
    if not isinstance(value, dict):
        raise error("REFERENCE_SOURCE_REQUIRED", "reference_source must be an object")
    role = str(value.get("role", "")).strip().lower()
    if role != "population_reference":
        raise error(
            "REFERENCE_SOURCE_ROLE_INVALID",
            "reference source must be population_reference; OpenMed is an intake processor, not a population dataset",
        )
    source_id = str(value.get("source_id", "")).strip()
    configured = SUPPORTED_REFERENCE_SOURCES.get(source_id)
    if configured is None:
        raise error(
            "REFERENCE_SOURCE_NOT_CONFIGURED",
            "reference source is not configured with a governed population parameterization",
        )
    for field in ("release", "provenance_uri", "population"):
        supplied = str(value.get(field, "")).strip()
        if supplied and supplied != configured[field]:
            raise error(
                "REFERENCE_SOURCE_METADATA_MISMATCH",
                f"reference_source.{field} must match the server-owned source manifest",
            )
    return {"role": role, "source_id": source_id, **configured}


def population_capabilities() -> dict[str, Any]:
    """Describe configured contexts without inventing new population parameters."""
    from copy import deepcopy

    source_id = "livemore-public-metabolic-reference-v1"
    contexts = {
        "dpp-high-risk-metabolic": ("DPP high metabolic risk", "high-metabolic-risk"),
        "nhanes-diagnosed-diabetes-older": ("NHANES older diagnosed diabetes", "type-2-diabetes"),
        "pxr-reference": ("Hepatic PXR research priors", "hepatic-pxr-research"),
    }
    return {
        "schema": "livemore.population-capabilities.v1",
        "default_template": "healthy", "default_indication": "unspecified",
        "templates": [
            {"id": "healthy", "label": "Healthy reference adult", "available": True,
             "source_class": "MODEL_REFERENCE", "scope": "Reduced metabolic and ventricular-cell models"},
            {"id": "type-2-diabetes", "label": "Type 2 diabetes reference", "available": True,
             "source_class": "MODEL_REFERENCE", "scope": "Reduced metabolic and ventricular-cell models"},
        ],
        "reference_source": {"role": "population_reference", "source_id": source_id,
                             **deepcopy(SUPPORTED_REFERENCE_SOURCES[source_id])},
        "reference_strata": [
            {"id": stratum, "label": contexts[stratum][0], "indication": contexts[stratum][1],
             "available": True, "source_class": "REFERENCE_GROUNDED_SYNTHETIC",
             "source_id": source_id, "qualification": "research_priors_not_individual_measurements"}
            for stratum in sorted(STRATA)
        ],
        "healthy_reference_cohort": {
            "available": False,
            "reason": "A healthy population generator with verified joint parameter constraints is not configured. A healthy reference template is not an observed healthy cohort.",
        },
        "free_indication_source_classes": ["SYNTHETIC", "REAL_HUMAN"],
    }


def _clip(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, value))


def _draw_sex(rng: random.Random, female_fraction: float) -> str:
    return "F" if rng.random() < female_fraction else "M"


def generate_members(
    *, size: int, seed: int, stratum: str, source: dict[str, Any],
    error: Callable[[str, str], Exception],
) -> list[dict[str, Any]]:
    if stratum not in STRATA:
        raise error("COHORT_GENERATION_FAILED", f"unsupported reference stratum {stratum!r}")
    rng = random.Random(seed)
    members: list[dict[str, Any]] = []
    for index in range(size):
        if stratum == "dpp-high-risk-metabolic":
            # DPP baseline aggregate: age 51±10.7, 67.7% women, BMI 34±6.7,
            # fasting glucose approximately 5.9-6.0 mmol/L. Weight, insulin,
            # transport, and ODE parameters below remain explicit model priors.
            age = int(round(_clip(rng.gauss(51.0, 10.7), 25, 85)))
            sex = _draw_sex(rng, 0.677)
            weight = round(_clip(rng.gauss(94.0, 16.0), 48, 155), 1)
            gb = round(_clip(rng.gauss(107.0, 7.5), 90, 125), 2)
            ib = round(_clip(rng.gauss(15.0, 4.0), 4, 32), 2)
            oct1 = rng.choices([0, 1, 2], weights=[0.78, 0.19, 0.03], k=1)[0]
            si_center, gamma_center, condition = 1.75e-4, 0.032, "high metabolic risk"
            measured_anchor = "DPP baseline aggregate, PMID 11092283"
        elif stratum == "nhanes-diagnosed-diabetes-older":
            # Livemore analysis of public NHANES August 2021-August 2023 rows:
            # age>=60, DIQ010=1, DID040>=30, DIQ050!=1 and complete fasting
            # examination weights/LBXGLU/LBXIN/BMXWT (unweighted n=199).
            age = int(round(_clip(rng.gauss(69.544, 6.796), 60, 80)))
            sex = _draw_sex(rng, 0.4306)
            weight = round(_clip(rng.gauss(87.828, 20.922), 48, 145), 1)
            gb = round(_clip(rng.gauss(140.84, 39.199), 90, 280), 2)
            ib = round(_clip(rng.gauss(13.817, 10.042), 3, 50), 2)
            oct1 = rng.choices([0, 1, 2], weights=[0.68, 0.26, 0.06], k=1)[0]
            si_center, gamma_center, condition = 1.18e-4, 0.026, "diagnosed diabetes"
            measured_anchor = "NHANES public weighted aggregate; Livemore selection v1; unweighted n=199"
        else:
            # PXR expression is not measured by NHANES. This transparent,
            # bounded research prior exposes response heterogeneity only.
            age = int(round(_clip(rng.gauss(49.0, 12.0), 24, 78)))
            sex = _draw_sex(rng, 0.5)
            weight = round(_clip(rng.gauss(78.0, 13.0), 48, 135), 1)
            gb = round(_clip(rng.gauss(98.0, 9.0), 80, 125), 2)
            ib = round(_clip(rng.gauss(10.0, 3.2), 4, 25), 2)
            oct1 = rng.choices([0, 1, 2], weights=[0.72, 0.23, 0.05], k=1)[0]
            si_center, gamma_center, condition = 2.15e-4, 0.04, ""
            measured_anchor = "none for NR1I2 expression; bounded Livemore research prior"

        si = round(_clip(rng.gauss(si_center, si_center * 0.16), 0.55e-4, 3.0e-4), 8)
        gamma = round(_clip(rng.gauss(gamma_center, 0.0045), 0.012, 0.055), 6)
        lifestyle = round(_clip(rng.gauss(0.48, 0.13), 0.12, 0.9), 3)
        nr1i2 = round(_clip(rng.gauss(1.0, 0.12), 0.7, 1.3), 3)
        digest = hashlib.sha256(
            f"{source['source_id']}|{source['release']}|{stratum}|{seed}|{index}".encode("utf-8")
        ).hexdigest()
        members.append({
            "member_id": f"reference-synthetic-{digest[:20]}",
            "source_class": "REFERENCE_GROUNDED_SYNTHETIC",
            "age": age,
            "sex": sex,
            "conditions": [condition] if condition else [],
            "genome": {"SLC22A1_lof": oct1, "CYP_reduced": rng.choice([0, 0, 0, 1])},
            "lifestyle": lifestyle,
            "model_parameters": {
                "Gb": gb,
                "Si": si,
                "gamma": gamma,
                "Ib": ib,
                "Gt": round(_clip(100 + (gb - 90) * 0.5, 100, 180), 2),
                "SG": round(_clip(rng.gauss(0.016, 0.002), 0.01, 0.022), 6),
                "weight_kg": weight,
                "NR1I2_expression_factor": nr1i2,
            },
            "source_lineage": {
                "source_id": source["source_id"],
                "release": source["release"],
                "stratum": stratum,
                "evidence_class": "REFERENCE_INITIALIZED",
                "generation": "deterministic synthetic sampling; not a source participant row",
                "measured_population_anchor": measured_anchor,
                "parameter_provenance": {
                    "age": "population aggregate anchor" if stratum != "pxr-reference" else "bounded model prior",
                    "sex": "population aggregate anchor" if stratum != "pxr-reference" else "bounded model prior",
                    "Gb": "population aggregate anchor" if stratum != "pxr-reference" else "bounded model prior",
                    "weight_kg": "population aggregate anchor" if stratum == "nhanes-diagnosed-diabetes-older" else "bounded model prior",
                    "Ib": "population aggregate anchor" if stratum == "nhanes-diagnosed-diabetes-older" else "bounded model prior",
                    "Si": "bounded mechanistic model prior",
                    "gamma": "bounded mechanistic model prior",
                    "SG": "bounded mechanistic model prior",
                    "Gt": "derived model initialization",
                    "SLC22A1_lof": "bounded genotype-frequency research prior",
                    "NR1I2_expression_factor": "bounded expression research prior; not measured by source",
                },
            },
        })
    if len({member["member_id"] for member in members}) != size:
        raise error("COHORT_GENERATION_FAILED", "member identity collision")
    if any(not math.isfinite(float(member["model_parameters"]["Gb"])) for member in members):
        raise error("COHORT_GENERATION_FAILED", "non-finite member parameter")
    return members


def heterogeneity_summary(members: list[dict[str, Any]]) -> dict[str, Any]:
    ages = [member["age"] for member in members]
    glucose = [member["model_parameters"]["Gb"] for member in members]
    return {
        "unique_profiles": len({
            (member["age"], member["sex"], member["model_parameters"]["Gb"],
             member["genome"].get("SLC22A1_lof", 0))
            for member in members
        }),
        "age_range": [min(ages), max(ages)] if ages else [],
        "baseline_glucose_range_mg_dL": [min(glucose), max(glucose)] if glucose else [],
        "sex_counts": {sex: sum(member["sex"] == sex for member in members) for sex in ("F", "M")},
        "oct1_lof_counts": {
            str(value): sum(member["genome"].get("SLC22A1_lof", 0) == value for member in members)
            for value in (0, 1, 2)
        },
    }


__all__ = [
    "STRATA", "SUPPORTED_REFERENCE_SOURCES", "generate_members",
    "heterogeneity_summary", "normalize_reference_source",
]
