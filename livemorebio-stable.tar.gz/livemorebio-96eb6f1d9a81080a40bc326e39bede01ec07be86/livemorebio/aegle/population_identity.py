"""Identity of loaded source normalization code; never hashes a changed disk file.

This is a reproducibility gate, not proof of clinical validity. Only the reviewed
XPORT decoder release is accepted. Existing frozen records do not call this gate.
"""
from __future__ import annotations

import hashlib
import json
import marshal
import sys
from types import CodeType, FunctionType, ModuleType
from typing import Any

import numpy as np
import pandas as pd
from pandas.io.sas import sas_xport

from . import population_records, population_sources


class PopulationIdentityError(ValueError):
    """Unknown or runtime-replaced normalization requires source review."""


def _portable_code(code: CodeType) -> CodeType:
    return code.replace(co_filename="<loaded-code>", co_consts=tuple(_portable_code(value) if isinstance(value, CodeType) else value for value in code.co_consts))


def _module_identity(module: ModuleType) -> str:
    functions: dict[str, str] = {}
    for name, value in sorted(vars(module).items()):
        if isinstance(value, FunctionType) and value.__module__ == module.__name__:
            functions[name] = hashlib.sha256(marshal.dumps(_portable_code(value.__code__))).hexdigest()
        elif isinstance(value, type) and value.__module__ == module.__name__:
            for method_name, method in sorted(vars(value).items()):
                if isinstance(method, (classmethod, staticmethod)):
                    method = method.__func__
                if isinstance(method, FunctionType):
                    functions[name + "." + method_name] = hashlib.sha256(marshal.dumps(_portable_code(method.__code__))).hexdigest()
    return hashlib.sha256(json.dumps(functions, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _function_identity(function: FunctionType) -> str:
    description = {"code": hashlib.sha256(marshal.dumps(_portable_code(function.__code__))).hexdigest(),
                   "defaults": function.__defaults__, "keyword_defaults": function.__kwdefaults__}
    return hashlib.sha256(json.dumps(description, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _function_defaults(module: ModuleType) -> dict[str, Any]:
    result = {}
    for name, function in sorted(vars(module).items()):
        if isinstance(function, FunctionType) and function.__module__ == module.__name__:
            result[name] = [function.__defaults__, function.__kwdefaults__]
        elif isinstance(function, type) and function.__module__ == module.__name__:
            for method_name, method in sorted(vars(function).items()):
                if isinstance(method, (classmethod, staticmethod)):
                    method = method.__func__
                if isinstance(method, FunctionType):
                    result[name + "." + method_name] = [method.__defaults__, method.__kwdefaults__]
    # Copies remove mutable default-object aliases from the captured snapshot.
    return json.loads(json.dumps(result, sort_keys=True, allow_nan=False))


def _loaded_identity() -> dict[str, Any]:
    return {"release": "joint-public-reference-normalization-1", "python": f"{sys.version_info.major}.{sys.version_info.minor}",
            "pandas": pd.__version__, "numpy": np.__version__, "xport_code_sha256": _module_identity(sas_xport),
            "transport_code_sha256": _module_identity(population_sources), "normalizer_code_sha256": _module_identity(population_records),
            "read_sas_entrypoint_sha256": _function_identity(pd.read_sas),
            "defaults": {module.__name__: _function_defaults(module) for module in (sas_xport, population_sources, population_records)},
            "ordered_tables": list(population_records._TABLE_NAMES),
            "source_manifest_sha256": population_sources.manifest_hash(),
            "definitions": population_records.definitions()}


# Captured once from actual functions in memory, including the reviewed exact
# all-zero transport correction. A file edited after import cannot change this.
_LOADED = _loaded_identity()
_REVIEWED_DECODERS = {
    # The installed decoder inspected and exercised against the pinned 14-file
    # release in the source-admission decision; upgrades require a new review.
    ("3.11", "2.3.3"): "4a5f466f92c5cdd27342e1481ea9ab70c3aa8cd2845e158e9b915c1f65c92e88",
}
_REVIEWED_ENTRYPOINTS = {
    ("3.11", "2.3.3"): "a022dba4eca6e486c8878f18fad52a33af6b65e4c42fa30cb7ccdd19e1628352",
}


def normalization_version() -> str:
    current = _loaded_identity()
    expected = _REVIEWED_DECODERS.get((current["python"], current["pandas"]))
    if (current != _LOADED or expected != current["xport_code_sha256"]
            or _REVIEWED_ENTRYPOINTS.get((current["python"], current["pandas"])) != current["read_sas_entrypoint_sha256"]):
        raise PopulationIdentityError("The loaded population decoder or normalization implementation requires review.")
    digest = hashlib.sha256(json.dumps(_LOADED, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    return f"joint-public-reference-v1:python-{current['python']}:pandas-{current['pandas']}:numpy-{current['numpy']}:sha256-{digest}"
