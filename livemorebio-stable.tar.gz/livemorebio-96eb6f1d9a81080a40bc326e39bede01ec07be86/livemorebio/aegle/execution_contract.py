"""Bounded, detached contracts for engine-authored numerical executions.

Hashes establish identity, not authority or biological validity. Only the runtime's
source-authority guard may admit a source; HTTP callers must never supply one.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import hashlib
from importlib.metadata import version
import json
import math
from pathlib import Path
import re
import sys
from typing import Any


class ExecutionError(ValueError):
    """Fixed, PHI-safe errors at every execution boundary."""

    def __init__(self, code: str = "EXECUTION_INVALID") -> None:
        self.code = code
        super().__init__({
            "EXECUTION_CONFLICT": "Execution revision or source changed.",
            "EXECUTION_OWNED": "Execution already has a local owner.",
            "EXECUTION_STORAGE": "Execution storage is unavailable or failed integrity checks.",
            "EXECUTION_QUOTA": "Execution storage quota reached; execution paused.",
            "EXECUTION_SOLVER": "Numerical execution failed; no candidate frame was admitted.",
            "EXECUTION_CLOSED": "Execution manager is closed.",
            "EXECUTION_CLEANUP_UNCONFIRMED": "Worker cleanup is unconfirmed; inspect status and explicitly stop it again.",
            "PATCH_BINDING_REQUIRED": "The device is not bound to the selected twin; bind it as a virtual patch before streaming.",
            "PATCH_JOURNAL_INVALID": "The patch telemetry journal holds a record the current protocol rejects; run 'livemore patch-journal verify'.",
        }.get(code, "Execution input or state is outside the admitted contract."))


METABOLIC = "metabolic-continuous-v1"
CARDIAC = "cardiac-continuous-v1"
CARDIAC_SHA256 = "ed127e6737611eb1469ea32db0b9d102f0780fc286a29ca88d11d8a868a94175"
METABOLIC_NAMES = ["glucose_mgdl", "insulin_action_per_min", "insulin_uU_ml"]
METABOLIC_UNITS = ["mg/dL", "1/min", "uU/mL"]
CARDIAC_NAMES = ("membrane.v CaMK.CaMKt intracellular_ions.nai intracellular_ions.nass "
    "intracellular_ions.ki intracellular_ions.kss intracellular_ions.cass intracellular_ions.cansr "
    "intracellular_ions.cajsr intracellular_ions.cai INa.m INa.hf INa.hs INa.j INa.hsp INa.jp "
    "INaL.mL INaL.hL INaL.hLp Ito.a Ito.iF Ito.iS Ito.ap Ito.iFp Ito.iSp ICaL.d ICaL.ff "
    "ICaL.fs ICaL.fcaf ICaL.fcas ICaL.jca ICaL.ffp ICaL.fcafp ICaL.nca IKr.IC1 IKr.IC2 "
    "IKr.C1 IKr.C2 IKr.O IKr.IO IKr.IObound IKr.Obound IKr.Cbound IKr.D IKs.xs1 IKs.xs2 "
    "IK1.xk1 ryr.Jrelnp ryr.Jrelp").split()
CARDIAC_UNITS = ["mV"] + ["mM"] * 9 + ["1"] * 39
CARDIAC_INITIAL = [-88.00190465, .0125840447, 7.268004498, 7.268089977, 144.6555918,
    144.6555651, .0000849, 1.619574538, 1.571234014, .000086, .007344121102,
    .6981071913, .6980895801, .6979908432, .4549485525, .6979245865, .0001882617273,
    .5008548855, .2693065357, .001001097687, .9995541745, .5865061736, .0005100862934,
    .9995541823, .6393399482, .00000000234, .9999999909, .9102412777, .9999999909,
    .9998046777, .9999738312, .9999999909, .9999999909, .002749414044, .999637,
    .0000683208, .0000000180145, .0000826619, .00015551, .0000567623, 0., 0., 0., 0.,
    .2707758025, .0001928503426, .9967597594, .00000025, .000000312]
MAX_JSON_BYTES = 1024 * 1024
MAX_FRAME_BYTES = 2 * 1024 * 1024
SELECTION_FIELDS = {"subject_id", "twin_id", "twin_version", "cohort_id", "member_id",
                    "run_id", "condition_id", "stage", "source_data_class"}


def number(value: Any, low: float, high: float) -> float:
    if type(value) not in (float, int) or not math.isfinite(value) or not low <= value <= high:
        raise ExecutionError()
    return float(value)


def text(value: Any, maximum: int = 160) -> str:
    if not isinstance(value, str) or not value or len(value) > maximum or value != value.strip():
        raise ExecutionError()
    if any(ord(c) < 32 for c in value):
        raise ExecutionError()
    return value


def encoded(value: Any, maximum: int = MAX_JSON_BYTES) -> bytes:
    # Bound nesting and collections before recursive JSON encoding.
    pending = [(value, 0)]
    count = 0
    while pending:
        item, depth = pending.pop()
        count += 1
        if depth > 16 or count > 100000:
            raise ExecutionError()
        if isinstance(item, dict):
            if any(not isinstance(key, str) or len(key) > 256 for key in item):
                raise ExecutionError()
            pending.extend((v, depth + 1) for v in item.values())
        elif isinstance(item, list):
            pending.extend((v, depth + 1) for v in item)
        elif type(item) not in (str, float, int, bool, type(None)):
            raise ExecutionError()
    try:
        result = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    except (TypeError, ValueError, OverflowError, RecursionError) as error:
        raise ExecutionError() from error
    if len(result) > maximum:
        raise ExecutionError()
    return result


def digest(value: Any) -> str:
    return hashlib.sha256(encoded(value)).hexdigest()


def seal_source(source: dict[str, Any]) -> dict[str, Any]:
    """Canonical snapshot identity, not an admission/signature mechanism."""
    body = deepcopy(source)
    body.pop("source_snapshot_hash", None)
    initial = body.get("initialization", {}).get("checkpoint")
    if isinstance(initial, dict):
        # Construction helper binds the initial vector to these captured inputs;
        # validate_source separately requires the exact admitted initial values.
        initial.update(model_identity_hash=digest(body["model_identity"]),
                       parameters_hash=digest(body["parameters"]), schedule_hash=digest(body["schedule"]))
    body["source_snapshot_hash"] = digest(body)
    return body


def checkpoint(source: dict[str, Any], native_time: float, values: list[float]) -> dict[str, Any]:
    cellular = source["engine_contract_id"] == CARDIAC
    return {"schema": "livemore.execution-checkpoint.v1", "native_time": native_time,
            "state_names": list(CARDIAC_NAMES if cellular else METABOLIC_NAMES),
            "state_units": list(CARDIAC_UNITS if cellular else METABOLIC_UNITS),
            "state_values": list(values), "engine_contract_id": source["engine_contract_id"],
            "model_identity_hash": digest(source["model_identity"]),
            "parameters_hash": digest(source["parameters"]), "schedule_hash": digest(source["schedule"])}


def validate_checkpoint(source: dict[str, Any], value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ExecutionError()
    expected = checkpoint(source, 0., [])
    if set(value) != set(expected) or any(value[key] != expected[key] for key in expected
                                         if key not in {"native_time", "state_values"}):
        raise ExecutionError()
    number(value["native_time"], 0, source["native_axis"]["maximum"])
    states = value["state_values"]
    if not isinstance(states, list) or len(states) != len(expected["state_names"]):
        raise ExecutionError()
    for state in states:
        number(state, -1e12, 1e12)
    if source["engine_contract_id"] == METABOLIC and (states[0] <= 0 or states[2] <= 0):
        raise ExecutionError()
    if source["engine_contract_id"] == CARDIAC:
        for index, tolerance in {2: 1e-4, 3: 1e-4, 4: 1e-4, 5: 1e-4,
                                 6: 2e-7, 7: 2e-6, 8: 2e-6, 9: 2e-7}.items():
            if states[index] < -tolerance:
                raise ExecutionError()
    return deepcopy(value)


def validate_policy(source: dict[str, Any], policy: Any) -> dict[str, float]:
    if not isinstance(policy, dict) or set(policy) != {"end_native", "frame_period_s", "time_scale"}:
        raise ExecutionError()
    return {"end_native": number(policy["end_native"], .000001, source["native_axis"]["maximum"]),
            "frame_period_s": number(policy["frame_period_s"], .1, 60),
            "time_scale": number(policy["time_scale"], .001, 3600)}


def validate_selection(selection: Any) -> dict[str, Any]:
    """One strict full-context shape for source capture and caller preconditions."""
    if not isinstance(selection, dict) or set(selection) != SELECTION_FIELDS:
        raise ExecutionError()
    for key in SELECTION_FIELDS - {"twin_version", "cohort_id", "member_id", "run_id"}:
        text(selection[key])
    for key in ("cohort_id", "member_id", "run_id"):
        if selection[key] is not None:
            text(selection[key])
    if type(selection["twin_version"]) is not int or not 1 <= selection["twin_version"] <= 1_000_000:
        raise ExecutionError()
    if selection["source_data_class"] not in {"SYNTHETIC", "REFERENCE_GROUNDED_SYNTHETIC", "REAL_HUMAN"}:
        raise ExecutionError()
    if (selection["cohort_id"] is None) != (selection["member_id"] is None):
        raise ExecutionError()
    return deepcopy(selection)


def validate_source(source: Any) -> dict[str, Any]:
    if not isinstance(source, dict) or set(source) != {"schema", "source_generation", "selection",
            "engine_contract_id", "model_identity", "parameters", "parameter_provenance",
            "initialization", "schedule", "native_axis", "source_snapshot_hash"}:
        raise ExecutionError()
    encoded(source)
    if source["schema"] != "livemore.execution-source.v1" or source != seal_source(source):
        raise ExecutionError()
    text(source["source_generation"])
    validate_selection(source["selection"])
    contract = source["engine_contract_id"]
    if contract not in (METABOLIC, CARDIAC):
        raise ExecutionError()
    expected_axis = {"unit": "min", "maximum": 840.} if contract == METABOLIC else {"unit": "ms", "maximum": 1_800_000.}
    if source["native_axis"] != expected_axis or not isinstance(source["parameter_provenance"], dict):
        raise ExecutionError()
    parameters = source["parameters"]
    if contract == METABOLIC:
        from .clinical_parameters import MODEL_PARAMETER_NAMES, validate_model_parameters

        if not isinstance(parameters, dict) or set(parameters) != MODEL_PARAMETER_NAMES | {"name"}:
            raise ExecutionError()
        text(parameters["name"], 256)
        for field in MODEL_PARAMETER_NAMES:
            number(parameters[field], 0, 1e12)
        try:
            validate_model_parameters(parameters)
        except ValueError as error:
            raise ExecutionError() from error
        schedule = source["schedule"]
        if not isinstance(schedule, list) or len(schedule) > 64:
            raise ExecutionError()
        previous = -1.
        for event in schedule:
            if not isinstance(event, list) or len(event) != 2:
                raise ExecutionError()
            instant, _ = number(event[0], 0, 840), number(event[1], 0, 500)
            if instant < previous:
                raise ExecutionError()
            previous = instant
        expected_initial = [parameters["Gb"], 0., parameters["Ib"]]
        expected_initialization = {"method": "captured_basal_reference", "checkpoint": checkpoint(source, 0., expected_initial)}
    else:
        if not isinstance(parameters, dict) or set(parameters) != {"ikr_block"}:
            raise ExecutionError()
        number(parameters["ikr_block"], 0, .9)
        if source["schedule"] != {"period_ms": 1000., "pulse_ms": .5, "offset_ms": 50.}:
            raise ExecutionError()
        expected_initialization = {"method": "pinned_cellml_then_reference_pacing", "prepace_cycles": 5,
                                   "checkpoint": checkpoint(source, 0., CARDIAC_INITIAL)}
    if source["initialization"] != expected_initialization:
        raise ExecutionError()
    validate_checkpoint(source, source["initialization"]["checkpoint"])
    return deepcopy(source)


def capture_source_payload(twin: Any, selection: dict[str, Any], source_generation: str,
                           engine_contract_id: str) -> dict[str, Any]:
    """Call inside ModelSourceAuthority.capture; no simulation or display/bus read."""
    if engine_contract_id not in (METABOLIC, CARDIAC):
        raise ExecutionError()
    package = Path(__file__).resolve().parents[1]
    mechanism = package / "engines" / ("metabolic/glucose_insulin.py" if engine_contract_id == METABOLIC
                                      else "cardiac/action_potential.py")
    try:
        dependencies = {name: version(name) for name in ("numpy", "scipy", "myokit")}
        if dependencies != {"numpy": "2.4.6", "scipy": "1.17.1", "myokit": "1.39.2"} or sys.version_info[:2] != (3, 11):
            raise ExecutionError()
        identity = {"mechanism_sha256": hashlib.sha256(mechanism.read_bytes()).hexdigest(),
                    "adapter_sha256": hashlib.sha256(Path(__file__).with_name("execution_adapters.py").read_bytes()).hexdigest(),
                    "contract_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    "python": "3.11", "dependencies": dependencies}
        source = {"schema": "livemore.execution-source.v1", "source_generation": source_generation,
                  "selection": deepcopy(selection), "engine_contract_id": engine_contract_id,
                  "model_identity": identity}
        if engine_contract_id == METABOLIC:
            provenance_reader = getattr(twin, "parameter_provenance", None)
            origins = provenance_reader() if callable(provenance_reader) else getattr(twin, "_parameter_provenance", {})
            source.update(parameters=asdict(twin.profile),
                          parameter_provenance=deepcopy(origins),
                          schedule=[list(event) for event in twin.meals], native_axis={"unit": "min", "maximum": 840.})
            source["initialization"] = {"method": "captured_basal_reference",
                "checkpoint": checkpoint(source, 0., [source["parameters"]["Gb"], 0., source["parameters"]["Ib"]])}
        else:
            model = package.parent / "models/cardiac/ohara_rudy_cipa_2017.cellml"
            if hashlib.sha256(model.read_bytes()).hexdigest() != CARDIAC_SHA256:
                raise ExecutionError()
            identity["cellml_sha256"] = CARDIAC_SHA256
            source.update(parameters={"ikr_block": getattr(twin, "cardiac_drug_block", 0.)},
                          parameter_provenance={"ikr_block": {"evidence_class": "DECLARED_MODEL_INTERVENTION",
                              "reason": "Explicit cell IKr block; excludes glucose-derived coupling."}},
                          schedule={"period_ms": 1000., "pulse_ms": .5, "offset_ms": 50.},
                          native_axis={"unit": "ms", "maximum": 1_800_000.})
            source["initialization"] = {"method": "pinned_cellml_then_reference_pacing", "prepace_cycles": 5,
                                        "checkpoint": checkpoint(source, 0., CARDIAC_INITIAL)}
        return validate_source(seal_source(source))
    except (OSError, TypeError, AttributeError, KeyError) as error:
        raise ExecutionError() from error
