"""Stateful numerical adapters; legacy simulate() paths are deliberately unchanged.

Production managers host these adapters in an owned, deadline-bounded worker.
Direct construction is for isolated numerical conformance tests, not HTTP input.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
from pathlib import Path
from typing import Any

from .execution_contract import (
    CARDIAC, CARDIAC_INITIAL, CARDIAC_NAMES, CARDIAC_SHA256, CARDIAC_UNITS, METABOLIC,
    ExecutionError, checkpoint, number, validate_checkpoint, validate_source,
)


def verify_runtime_identity(source: dict[str, Any]) -> None:
    from importlib.metadata import version
    import sys

    package = Path(__file__).resolve().parents[1]
    mechanism = package / "engines" / ("metabolic/glucose_insulin.py" if source["engine_contract_id"] == METABOLIC
                                      else "cardiac/action_potential.py")
    identity = source["model_identity"]
    try:
        checks = {"mechanism_sha256": hashlib.sha256(mechanism.read_bytes()).hexdigest(),
                  "adapter_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  "contract_sha256": hashlib.sha256(Path(__file__).with_name("execution_contract.py").read_bytes()).hexdigest(),
                  "python": ".".join(str(x) for x in sys.version_info[:2]),
                  "dependencies": {name: version(name) for name in ("numpy", "scipy", "myokit")}}
        if any(identity.get(key) != value for key, value in checks.items()):
            raise ExecutionError()
        if source["engine_contract_id"] == CARDIAC:
            if identity.get("cellml_sha256") != CARDIAC_SHA256 or hashlib.sha256(
                    (package.parent / "models/cardiac/ohara_rudy_cipa_2017.cellml").read_bytes()).hexdigest() != CARDIAC_SHA256:
                raise ExecutionError()
    except OSError as error:
        raise ExecutionError() from error


class MetabolicExecutionAdapter:
    """Continue the unchanged three-state RHS on its absolute minute clock."""

    def __init__(self, source: dict[str, Any], *, rtol: float = 1e-6, atol: float = 1e-8) -> None:
        self.source = validate_source(source)
        if self.source["engine_contract_id"] != METABOLIC:
            raise ExecutionError()
        verify_runtime_identity(self.source)
        from ..engines.metabolic.glucose_insulin import GlucoseInsulinModel, MetabolicProfile

        self.model = GlucoseInsulinModel(MetabolicProfile(**self.source["parameters"]))
        self.rtol, self.atol = rtol, atol
        self.runtime_identity = {"solver": "scipy.LSODA", "scipy_version": "1.17.1",
                                 "rtol": rtol, "atol": atol, "continuation": "full_state_interval_restart"}

    def initialize(self) -> dict[str, Any]:
        return deepcopy(self.source["initialization"]["checkpoint"])

    def advance(self, previous: dict[str, Any], native_end: float) -> dict[str, Any]:
        import numpy as np
        from scipy.integrate import solve_ivp

        previous = validate_checkpoint(self.source, previous)
        start = previous["native_time"]
        end = number(native_end, start, self.source["native_axis"]["maximum"])
        if end <= start:
            raise ExecutionError()
        states = previous["state_values"]
        # Force future appearance onsets to be solver boundaries: a stationary
        # LSODA history can otherwise step straight past a future meal.
        breaks = sorted({start, end, *(time for time, _ in self.source["schedule"] if start < time < end)})
        times: list[float] = []
        values: list[list[float]] = [[], [], []]
        for left, right in zip(breaks, breaks[1:]):
            # A fixed 0.25-minute grid makes interval comparisons phase-exact.
            grid = np.arange(np.floor(left * 4) + 1, np.ceil(right * 4), dtype=float) / 4
            grid = np.concatenate((grid[(grid > left) & (grid < right)], [right]))
            if len(times) + len(grid) > 4096:
                raise ExecutionError()
            solution = solve_ivp(self.model._rhs, (left, right), states, t_eval=grid,
                                 args=(self.source["schedule"],), method="LSODA",
                                 rtol=self.rtol, atol=self.atol)
            if not solution.success or solution.y.shape != (3, len(grid)) or not np.isfinite(solution.y).all():
                raise ExecutionError("EXECUTION_SOLVER")
            states = solution.y[:, -1].tolist()
            times.extend(solution.t.tolist())
            for index in range(3):
                values[index].extend(solution.y[index].tolist())
        candidate = checkpoint(self.source, end, states)
        validate_checkpoint(self.source, candidate)
        return {"checkpoint": candidate, "series": [
            {"quantity": quantity, "unit": unit, "compartment": compartment,
             "native_times": times.copy(), "values": trace}
            for quantity, unit, compartment, trace in zip(
                ("glucose_mgdl", "insulin_action_per_min", "insulin_uU_ml"),
                ("mg/dL", "1/min", "uU/mL"), ("plasma", "remote_insulin_action", "plasma"), values)]}

    def close(self) -> None:
        pass


class CardiacExecutionAdapter:
    """A paced ventricular cell, not ECG, whole-heart mechanics or an HR model."""

    def __init__(self, source: dict[str, Any], *, abs_tol: float = 1e-10, rel_tol: float = 1e-8) -> None:
        self.source = validate_source(source)
        if self.source["engine_contract_id"] != CARDIAC:
            raise ExecutionError()
        verify_runtime_identity(self.source)
        import myokit
        from ..engines.cardiac.action_potential import CardiacCell

        cell = CardiacCell()
        model = cell._m
        names = [v.qname() for v in model.states()]
        units = [str(v.unit()).strip("[]") for v in model.states()]
        initial = [v.eval() for v in model.initial_values()]
        if names != CARDIAC_NAMES or units != CARDIAC_UNITS or initial != CARDIAC_INITIAL:
            raise ExecutionError()
        model.get("IKr.ikr_scale").set_rhs(1. - self.source["parameters"]["ikr_block"])
        protocol = myokit.pacing.blocktrain(period=1000., duration=.5, offset=50., level=1.)
        self.simulation = myokit.Simulation(model, protocol)
        self.simulation.set_tolerance(abs_tol=abs_tol, rel_tol=rel_tol)
        native_version = myokit.Sundials.version()
        if not isinstance(native_version, str) or not native_version:
            raise ExecutionError("EXECUTION_SOLVER")
        self.runtime_identity = {"solver": "CVODE", "myokit_version": "1.39.2", "sundials_version": native_version,
                                 "abs_tol": abs_tol, "rel_tol": rel_tol,
                                 "continuation": "full_state_native_interval", "prepace_ms": 5000.}
        self._initial: dict[str, Any] | None = None

    def initialize(self) -> dict[str, Any]:
        if self._initial is None:
            self.simulation.pre(5000.)
            self._initial = checkpoint(self.source, 0., self.simulation.state())
            validate_checkpoint(self.source, self._initial)
        return deepcopy(self._initial)

    def advance(self, previous: dict[str, Any], native_end: float) -> dict[str, Any]:
        import numpy as np

        previous = validate_checkpoint(self.source, previous)
        start = previous["native_time"]
        end = number(native_end, start, self.source["native_axis"]["maximum"])
        if end <= start or end - start > 4096:
            raise ExecutionError()
        # Restoring every hidden state allows a discarded in-flight candidate to
        # be retried without inheriting its private, uncommitted solver state.
        self.simulation.set_state(previous["state_values"])
        self.simulation.set_time(start)
        times = np.arange(np.floor(start) + 1., end, 1.).tolist()
        data = self.simulation.run(end - start, log=["environment.time", "membrane.v", "intracellular_ions.cai"],
                                   log_times=times)
        candidate = checkpoint(self.source, end, self.simulation.state())
        validate_checkpoint(self.source, candidate)
        # CVODE excludes the run endpoint from logging; publish its exact state
        # explicitly, with no overlapping boundary sample in the next frame.
        series = []
        for quantity, unit, variable, index in (("membrane_voltage_mv", "mV", "membrane.v", 0),
                ("cytosolic_calcium_mm", "mM", "intracellular_ions.cai", 9)):
            series.append({"quantity": quantity, "unit": unit, "compartment": "ventricular_myocyte",
                           "native_times": times + [end],
                           "values": list(data[variable]) + [candidate["state_values"][index]]})
        return {"checkpoint": candidate, "series": series}

    def close(self) -> None:
        self.simulation = None
