"""Explicit, encrypted local execution storage and per-execution POSIX ownership.

Only random IDs, keyed request IDs, revisions and byte counts are indexed in
cleartext. Sources, model values, selections, checkpoints and frames are encrypted
even for synthetic subjects. No module import opens a store or loads a key.
"""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
import fcntl
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import threading
from typing import Any, Iterator
import uuid

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .execution_contract import (ExecutionError, MAX_FRAME_BYTES, digest, encoded,
                                 text, validate_checkpoint, validate_policy, validate_source)

_AUDIT_ACTIONS = {"capabilities", "prepare", "status", "frames", "start", "pause", "resume", "stop", "fork_checkpoint", "register_probe",
                  "bind_consumer", "renew_consumer", "observations", "admit_observation"}
_AUDIT_RESULTS = {"OK", "EXECUTION_INVALID", "EXECUTION_CONFLICT", "EXECUTION_OWNED", "EXECUTION_STORAGE",
                  "EXECUTION_QUOTA", "EXECUTION_SOLVER", "EXECUTION_CLOSED", "EXECUTION_RESTART_REQUIRED",
                  "EXECUTION_SOURCE_REQUIRED", "EXECUTION_UNAVAILABLE", "MODEL_SOURCE_CHANGED",
                  "EXECUTION_CLEANUP_UNCONFIRMED", "MODEL_BINDING_REQUIRED", "MODEL_CONTEXT_INVALID",
                  "MODEL_CONTEXT_UNSUPPORTED", "MODEL_CONTEXT_SOURCE_MISMATCH", "SELECTION_COMMIT_UNCONFIRMED",
                  "PATCH_BINDING_REQUIRED", "PATCH_JOURNAL_INVALID"}
_AUDIT_OUTCOME_RESERVE = 1024
_TRANSITION_RESERVE = 4096


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _execution_id(value: Any) -> str:
    if not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{32}", value) is None:
        raise ExecutionError()
    return value


def control_precondition(*, expected_revision: int | None = None,
                         expected_control_revision: int | None = None) -> tuple[str, int]:
    """Exactly one explicit guard; legacy whole-record revisions keep their meaning."""
    if (expected_revision is None) == (expected_control_revision is None):
        raise ExecutionError()
    field, value = (("revision", expected_revision) if expected_revision is not None
                    else ("control_revision", expected_control_revision))
    if type(value) is not int or not 1 <= value <= 1_000_000_000:
        raise ExecutionError()
    return field, value


def check_control_precondition(record: dict[str, Any], *, expected_revision: int | None = None,
                               expected_control_revision: int | None = None) -> None:
    field, value = control_precondition(expected_revision=expected_revision,
                                       expected_control_revision=expected_control_revision)
    if record[field] != value:
        raise ExecutionError("EXECUTION_CONFLICT")


def project_control_revision(record: dict[str, Any]) -> dict[str, Any]:
    """Old encrypted records migrate on their next normal write, never on read."""
    record.setdefault("control_revision", record["revision"])
    if (type(record["control_revision"]) is not int or type(record["revision"]) is not int
            or not 1 <= record["control_revision"] <= record["revision"]):
        raise ExecutionError("EXECUTION_STORAGE")
    return record


def _safe_file(path: Path, *, missing: bool = True) -> None:
    try:
        info = path.lstat()
    except FileNotFoundError:
        if missing:
            return
        raise ExecutionError("EXECUTION_STORAGE") from None
    except OSError as error:
        raise ExecutionError("EXECUTION_STORAGE") from error
    if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.getuid()
            or info.st_mode & 0o077):
        raise ExecutionError("EXECUTION_STORAGE")


class ExecutionStore:
    """Private-directory local SQLite store. Not an NFS/distributed lease service."""

    def __init__(self, path: Path, *, key: bytes, quota_bytes: int = 256 * 1024 * 1024,
                 store_kind: str = "execution") -> None:
        if not isinstance(key, bytes) or len(key) != 32 or type(quota_bytes) is not int or not 4096 <= quota_bytes <= 1024**3:
            raise ExecutionError()
        if type(store_kind) is not str or store_kind not in {"execution", "virtual-session"}:
            raise ExecutionError()
        self.path = Path(path).absolute()
        self.key, self.quota_bytes = key, quota_bytes
        self._lock = threading.RLock()
        try:
            self.path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            directory = self.path.parent.lstat()
            if (not stat.S_ISDIR(directory.st_mode) or directory.st_uid != os.getuid()
                    or directory.st_mode & 0o077):
                raise ExecutionError("EXECUTION_STORAGE")
            # Resolve parent aliases before deriving ownership lock names.
            self.path = self.path.parent.resolve(strict=True) / self.path.name
            _safe_file(self.path)
            try:
                descriptor = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_RDWR | os.O_NOFOLLOW, 0o600)
                created = True
            except FileExistsError:
                descriptor = os.open(self.path, os.O_RDWR | os.O_NOFOLLOW)
                created = False
            os.close(descriptor)
            with self._connection() as connection:
                connection.executescript("""
                    CREATE TABLE IF NOT EXISTS executions (
                        id TEXT PRIMARY KEY, request_key TEXT UNIQUE NOT NULL,
                        revision INTEGER NOT NULL, payload BLOB NOT NULL,
                        used_bytes INTEGER NOT NULL);
                    CREATE TABLE IF NOT EXISTS frames (
                        execution_id TEXT NOT NULL, frame INTEGER NOT NULL, payload BLOB NOT NULL,
                        PRIMARY KEY(execution_id, frame));
                    CREATE TABLE IF NOT EXISTS access_audit (
                        request_id TEXT PRIMARY KEY, request BLOB NOT NULL, outcome BLOB);
                    CREATE TABLE IF NOT EXISTS audit_usage (id INTEGER PRIMARY KEY, payload BLOB NOT NULL);
                    CREATE TABLE IF NOT EXISTS storage_kind (id INTEGER PRIMARY KEY, payload BLOB NOT NULL);
                    CREATE TABLE IF NOT EXISTS observation_receipts (
                        receipt_key TEXT PRIMARY KEY, binding_key TEXT UNIQUE NOT NULL,
                        series_key TEXT NOT NULL, frame_index INTEGER NOT NULL, payload BLOB NOT NULL);
                    CREATE INDEX IF NOT EXISTS observation_receipt_series
                        ON observation_receipts(series_key,frame_index);
                """)
                connection.execute("BEGIN IMMEDIATE")
                marker = connection.execute("SELECT payload FROM storage_kind WHERE id=1").fetchone()
                if marker is None:
                    if store_kind != "execution" and not created:
                        raise ExecutionError("EXECUTION_STORAGE")
                    connection.execute("INSERT INTO storage_kind VALUES (1,?)", (
                        self._encrypt({"kind": store_kind}, "storage-kind"),))
                elif self._decrypt(marker[0], "storage-kind") != {"kind": store_kind}:
                    raise ExecutionError("EXECUTION_STORAGE")
                connection.execute("INSERT OR IGNORE INTO audit_usage VALUES (1,?)", (
                    self._encrypt({"bytes": 0, "pending": 0}, "audit-usage"),))
                usage = self._audit_usage(connection)
                actual = connection.execute("SELECT COALESCE(SUM(length(request)+COALESCE(length(outcome),0)),0),"
                                            "COALESCE(SUM(outcome IS NULL),0) FROM access_audit").fetchone()
                if (usage["bytes"], usage["pending"]) != actual:
                    raise ExecutionError("EXECUTION_STORAGE")
                connection.execute("COMMIT")
        except (OSError, sqlite3.Error) as error:
            raise ExecutionError("EXECUTION_STORAGE") from error

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            for suffix in ("", "-wal", "-shm", "-journal"):
                _safe_file(Path(str(self.path) + suffix))
            try:
                connection = sqlite3.connect(self.path, timeout=3, isolation_level=None)
                try:
                    connection.execute("PRAGMA journal_mode=DELETE")
                    connection.execute("PRAGMA synchronous=FULL")
                    yield connection
                finally:
                    connection.close()
            except sqlite3.Error as error:
                raise ExecutionError("EXECUTION_STORAGE") from error

    def _encrypt(self, value: dict[str, Any], aad: str) -> bytes:
        plaintext = encoded(value, MAX_FRAME_BYTES)
        nonce = os.urandom(12)
        return nonce + AESGCM(self.key).encrypt(nonce, plaintext, ("livemore.execution.v1:" + aad).encode())

    def _decrypt(self, blob: bytes, aad: str) -> dict[str, Any]:
        try:
            if len(blob) > MAX_FRAME_BYTES + 64:
                raise ValueError()
            result = json.loads(AESGCM(self.key).decrypt(blob[:12], blob[12:], ("livemore.execution.v1:" + aad).encode()))
            if not isinstance(result, dict):
                raise ValueError()
            encoded(result, MAX_FRAME_BYTES)
            return result
        except Exception as error:
            raise ExecutionError("EXECUTION_STORAGE") from error

    def _read(self, connection: sqlite3.Connection, execution_id: str) -> dict[str, Any]:
        row = connection.execute("SELECT revision, payload FROM executions WHERE id=?", (execution_id,)).fetchone()
        if row is None:
            raise ExecutionError()
        result = self._decrypt(row[1], execution_id)
        if result.get("execution_id") != execution_id or result.get("revision") != row[0]:
            raise ExecutionError("EXECUTION_STORAGE")
        return project_control_revision(result)

    def _audit_usage(self, connection: sqlite3.Connection) -> dict[str, int]:
        row = connection.execute("SELECT payload FROM audit_usage WHERE id=1").fetchone()
        if row is None:
            raise ExecutionError("EXECUTION_STORAGE")
        usage = self._decrypt(row[0], "audit-usage")
        if set(usage) != {"bytes", "pending"} or any(type(v) is not int or v < 0 for v in usage.values()):
            raise ExecutionError("EXECUTION_STORAGE")
        return usage

    def _totals(self, connection: sqlite3.Connection) -> tuple[int, int, dict[str, int]]:
        used, count = connection.execute("SELECT COALESCE(SUM(used_bytes),0),COUNT(*) FROM executions").fetchone()
        receipts = connection.execute("SELECT COALESCE(SUM(length(payload)),0) FROM observation_receipts").fetchone()[0]
        usage = self._audit_usage(connection)
        return used + receipts + usage["bytes"], count, usage

    def begin_access(self, action: str, execution_id: str | None = None) -> str:
        """Durably record an authenticated attempt before reading or mutating data."""
        if type(action) is not str or action not in _AUDIT_ACTIONS:
            raise ExecutionError()
        if execution_id is not None:
            _execution_id(execution_id)
        request_id = uuid.uuid4().hex
        request = {"request_id": request_id, "timestamp": utc_now(), "action": action,
                   "execution_id": execution_id, "principal": "local-operator"}
        payload = self._encrypt(request, f"audit:{request_id}:request")
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            total, count, usage = self._totals(connection)
            reserved = count * _TRANSITION_RESERVE + (usage["pending"] + 1) * _AUDIT_OUTCOME_RESERVE
            if total + len(payload) + reserved > self.quota_bytes:
                raise ExecutionError("EXECUTION_QUOTA")
            connection.execute("INSERT INTO access_audit VALUES (?,?,NULL)", (request_id, payload))
            usage.update(bytes=usage["bytes"] + len(payload), pending=usage["pending"] + 1)
            connection.execute("UPDATE audit_usage SET payload=? WHERE id=1", (self._encrypt(usage, "audit-usage"),))
            connection.execute("COMMIT")
        return request_id

    def finish_access(self, request_id: str, result_code: str) -> None:
        """Use the bounded outcome space reserved by begin; never invent completion."""
        _execution_id(request_id)
        if type(result_code) is not str or result_code not in _AUDIT_RESULTS:
            raise ExecutionError()
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT request,outcome FROM access_audit WHERE request_id=?", (request_id,)).fetchone()
            if row is None:
                raise ExecutionError()
            self._decrypt(row[0], f"audit:{request_id}:request")
            if row[1] is not None:
                existing = self._decrypt(row[1], f"audit:{request_id}:outcome")
                if existing["result_code"] != result_code:
                    raise ExecutionError("EXECUTION_CONFLICT")
                return
            outcome = {"request_id": request_id, "timestamp": utc_now(), "result_code": result_code}
            payload = self._encrypt(outcome, f"audit:{request_id}:outcome")
            if len(payload) > _AUDIT_OUTCOME_RESERVE:
                raise ExecutionError("EXECUTION_STORAGE")
            total, _, usage = self._totals(connection)
            if usage["pending"] < 1 or total + len(payload) > self.quota_bytes:
                raise ExecutionError("EXECUTION_STORAGE")
            connection.execute("UPDATE access_audit SET outcome=? WHERE request_id=?", (payload, request_id))
            usage.update(bytes=usage["bytes"] + len(payload), pending=usage["pending"] - 1)
            connection.execute("UPDATE audit_usage SET payload=? WHERE id=1", (self._encrypt(usage, "audit-usage"),))
            connection.execute("COMMIT")

    def create(self, source: dict[str, Any], policy: dict[str, Any], *, idempotency_key: str,
               parent_execution_id: str | None = None, expected_parent_revision: int | None = None) -> dict[str, Any]:
        source = validate_source(source)
        policy = validate_policy(source, policy)
        key = hmac.new(self.key, text(idempotency_key, 128).encode(), hashlib.sha256).hexdigest()
        if (parent_execution_id is None) != (expected_parent_revision is None):
            raise ExecutionError()
        request_hash = digest({"source": source, "policy": policy, "parent_execution_id": parent_execution_id,
                               "expected_parent_revision": expected_parent_revision})
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute("SELECT id FROM executions WHERE request_key=?", (key,)).fetchone()
            if existing:
                record = self._read(connection, existing[0])
                if record["request_hash"] != request_hash:
                    raise ExecutionError("EXECUTION_CONFLICT")
                return record
            seed, parent_link = None, None
            if parent_execution_id is not None:
                parent = self._read(connection, _execution_id(parent_execution_id))
                parent_source = deepcopy(parent["source"])
                candidate_source = deepcopy(source)
                for body in (parent_source, candidate_source):
                    body.pop("source_generation")
                    body.pop("source_snapshot_hash")
                if (type(expected_parent_revision) is not int or parent["revision"] != expected_parent_revision
                        or parent["state"] not in {"paused", "stopped", "interrupted", "completed"}
                        or parent["checkpoint"] is None or parent_source != candidate_source):
                    raise ExecutionError("EXECUTION_CONFLICT")
                seed = validate_checkpoint(source, parent["checkpoint"])
                if seed["native_time"] >= policy["end_native"]:
                    raise ExecutionError()
                parent_link = {"execution_id": parent_execution_id, "revision": parent["revision"],
                               "source_snapshot_hash": parent["source"]["source_snapshot_hash"],
                               "frame_index": parent["latest_frame"], "frame_hash": parent["latest_frame_hash"],
                               "checkpoint_hash": digest(seed),
                               "restart_semantics": "full_state_checkpoint_fork_not_bit_identical_solver_history"}
            execution_id = uuid.uuid4().hex
            record = {"execution_id": execution_id, "revision": 1, "control_revision": 1, "state": "prepared",
                      "source": source, "policy": policy, "request_hash": request_hash,
                      "source_valid": True, "checkpoint": None, "latest_frame": 0, "latest_frame_hash": None,
                      "created_at": utc_now(), "updated_at": utc_now(), "failure_code": None,
                      "authorship": "uninitialized", "runtime_identity": None,
                      "initial_checkpoint": seed, "checkpoint_parent": parent_link}
            payload = self._encrypt(record, execution_id)
            total, count, usage = self._totals(connection)
            reserved = (count + 1) * _TRANSITION_RESERVE + usage["pending"] * _AUDIT_OUTCOME_RESERVE
            if count >= 256 or total + len(payload) + reserved > self.quota_bytes:
                raise ExecutionError("EXECUTION_QUOTA")
            connection.execute("INSERT INTO executions VALUES (?,?,?,?,?)", (execution_id, key, 1, payload, len(payload)))
            connection.execute("COMMIT")
            return deepcopy(record)

    def get(self, execution_id: str) -> dict[str, Any]:
        with self._connection() as connection:
            return self._read(connection, _execution_id(execution_id))

    def update(self, execution_id: str, *, expected_revision: int, changes: dict[str, Any],
               frame: dict[str, Any] | None = None, control_event: bool = False) -> dict[str, Any]:
        execution_id = _execution_id(execution_id)
        if type(expected_revision) is not int or type(control_event) is not bool or set(changes) - {
                "state", "source_valid", "checkpoint", "failure_code", "authorship", "runtime_identity", "consumer_binding"}:
            raise ExecutionError()
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            current = self._read(connection, execution_id)
            if current["revision"] != expected_revision:
                raise ExecutionError("EXECUTION_CONFLICT")
            if control_event or any(key in changes and changes[key] != current.get(key)
                                    for key in ("state", "source_valid", "failure_code", "consumer_binding")):
                current["control_revision"] += 1
            current.update(deepcopy(changes))
            current["revision"] += 1
            current["updated_at"] = utc_now()
            used, old_size = connection.execute("SELECT used_bytes,length(payload) FROM executions WHERE id=?", (execution_id,)).fetchone()
            frame_payload = None
            if frame is not None:
                if (frame.get("frame_index") != current["latest_frame"] + 1 or frame.get("execution_id") != execution_id
                        or frame.get("previous_frame_hash") != current["latest_frame_hash"]):
                    raise ExecutionError()
                current["latest_frame"] += 1
                current["latest_frame_hash"] = frame["frame_hash"]
                frame_payload = self._encrypt(frame, f"{execution_id}:frame:{current['latest_frame']}")
            payload = self._encrypt(current, execution_id)
            new_used = used - old_size + len(payload) + (len(frame_payload) if frame_payload else 0)
            total, count, usage = self._totals(connection)
            new_total = total - used + new_used
            reserved = usage["pending"] * _AUDIT_OUTCOME_RESERVE
            # Global payload quota is an approved enhancement over the initial
            # per-execution proposal. SQLite pages/journals add bounded overhead.
            if frame is not None:
                reserved += count * _TRANSITION_RESERVE
            if new_total + reserved > self.quota_bytes:
                raise ExecutionError("EXECUTION_QUOTA")
            if frame_payload is not None:
                connection.execute("INSERT INTO frames VALUES (?,?,?)", (execution_id, current["latest_frame"], frame_payload))
            connection.execute("UPDATE executions SET revision=?,payload=?,used_bytes=? WHERE id=?",
                               (current["revision"], payload, new_used, execution_id))
            connection.execute("COMMIT")
            return deepcopy(current)

    def frames(self, execution_id: str, *, after_frame: int, limit: int) -> list[dict[str, Any]]:
        execution_id = _execution_id(execution_id)
        if type(after_frame) is not int or after_frame < 0 or type(limit) is not int or not 1 <= limit <= 500:
            raise ExecutionError()
        with self._connection() as connection:
            self._read(connection, execution_id)
            rows = connection.execute("SELECT frame,payload FROM frames WHERE execution_id=? AND frame>? ORDER BY frame LIMIT ?",
                                      (execution_id, after_frame, limit))
            result, byte_count = [], 0
            for index, payload in rows:
                if byte_count + len(payload) > 8 * 1024 * 1024:
                    break
                result.append(self._decrypt(payload, f"{execution_id}:frame:{index}"))
                byte_count += len(payload)
            return result

    def acquire_owner(self, execution_id: str) -> int:
        """Hold this descriptor until manager shutdown/stop, including pauses."""
        path = self.path.with_name(self.path.name + ".owner-" + _execution_id(execution_id))
        _safe_file(path)
        descriptor: int | None = None
        try:
            descriptor = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
            info = os.fstat(descriptor)
            if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1 or info.st_mode & 0o077:
                raise ExecutionError("EXECUTION_STORAGE")
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return descriptor
        except BlockingIOError as error:
            raise ExecutionError("EXECUTION_OWNED") from error
        except OSError as error:
            raise ExecutionError("EXECUTION_STORAGE") from error
        finally:
            # A successful return transfers descriptor ownership to the manager.
            import sys
            if descriptor is not None and sys.exc_info()[0] is not None:
                os.close(descriptor)

    @staticmethod
    def release_owner(descriptor: int) -> None:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
        except OSError as error:
            raise ExecutionError("EXECUTION_STORAGE") from error
        finally:
            os.close(descriptor)
