"""Encrypted, idempotent receipts for exact committed execution frames.

This ledger establishes durable delivery identity, not device authenticity or
scientific qualification. Its caller must first validate the signed LIFE wire
contract and hold the current model-source observation guard.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import hmac
import re
from typing import Any

from .execution_contract import ExecutionError, encoded, text
from .execution_store import (ExecutionStore, _AUDIT_OUTCOME_RESERVE,
                              _TRANSITION_RESERVE, _execution_id)

_FIELDS = {"schema", "execution_id", "frame_index", "frame_hash", "source_snapshot_hash",
           "source_generation", "device_id", "operator_id", "envelope_id", "envelope_hash",
           "manifest_hash", "envelope", "manifest", "admission"}


class ExecutionReceiptLedger:
    def __init__(self, store: ExecutionStore) -> None:
        self.store = store

    def _key(self, purpose: str, parts: list[str | int]) -> str:
        return hmac.new(self.store.key, b"execution-receipt:" + purpose.encode() + b":" + encoded(parts),
                        hashlib.sha256).hexdigest()

    def _validate(self, value: Any) -> dict[str, Any]:
        if not isinstance(value, dict) or set(value) != _FIELDS:
            raise ExecutionError()
        encoded(value)
        if value["schema"] != "livemore.execution-observation-receipt.v1":
            raise ExecutionError()
        _execution_id(value["execution_id"])
        if type(value["frame_index"]) is not int or not 1 <= value["frame_index"] <= 1_000_000_000:
            raise ExecutionError()
        for field in ("frame_hash", "source_snapshot_hash", "envelope_hash", "manifest_hash"):
            if not isinstance(value[field], str) or re.fullmatch(r"[0-9a-f]{64}", value[field]) is None:
                raise ExecutionError()
        for field in ("source_generation", "device_id", "operator_id", "envelope_id"):
            text(value[field], 256)
        if any(not isinstance(value[field], dict) for field in ("envelope", "manifest", "admission")):
            raise ExecutionError()
        return deepcopy(value)

    def _unpack(self, row: tuple[Any, ...]) -> dict[str, Any]:
        key, binding_key, series_key, frame_index, payload = row
        value = self._validate(self.store._decrypt(payload, "receipt:" + key))
        series = [value["execution_id"], value["device_id"], value["operator_id"]]
        if (key != self._key("envelope", [value["envelope_id"]])
                or binding_key != self._key("binding", series + [value["frame_index"]])
                or series_key != self._key("series", series) or frame_index != value["frame_index"]):
            raise ExecutionError("EXECUTION_STORAGE")
        return value

    def admit(self, value: dict[str, Any]) -> dict[str, Any]:
        value = self._validate(value)
        key = self._key("envelope", [value["envelope_id"]])
        series = [value["execution_id"], value["device_id"], value["operator_id"]]
        binding_key = self._key("binding", series + [value["frame_index"]])
        series_key = self._key("series", series)
        with self.store._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            previous = connection.execute("SELECT * FROM observation_receipts WHERE receipt_key=?", (key,)).fetchone()
            if previous is not None:
                retained = self._unpack(previous)
                if encoded(retained) != encoded(value):
                    raise ExecutionError("EXECUTION_CONFLICT")
                return retained
            if connection.execute("SELECT 1 FROM observation_receipts WHERE binding_key=?", (binding_key,)).fetchone():
                raise ExecutionError("EXECUTION_CONFLICT")
            record = self.store._read(connection, value["execution_id"])
            if any(value[field] != record["source"][field] for field in ("source_snapshot_hash", "source_generation")):
                raise ExecutionError("EXECUTION_CONFLICT")
            row = connection.execute("SELECT payload FROM frames WHERE execution_id=? AND frame=?",
                                     (value["execution_id"], value["frame_index"])).fetchone()
            if row is None:
                raise ExecutionError()
            frame = self.store._decrypt(row[0], f"{value['execution_id']}:frame:{value['frame_index']}")
            if any(value[field] != frame[field] for field in ("execution_id", "frame_index", "frame_hash",
                                                              "source_snapshot_hash", "source_generation")):
                raise ExecutionError("EXECUTION_CONFLICT")
            payload = self.store._encrypt(value, "receipt:" + key)
            total, count, usage = self.store._totals(connection)
            reserved = count * _TRANSITION_RESERVE + usage["pending"] * _AUDIT_OUTCOME_RESERVE
            if total + len(payload) + reserved > self.store.quota_bytes:
                raise ExecutionError("EXECUTION_QUOTA")
            connection.execute("INSERT INTO observation_receipts VALUES (?,?,?,?,?)",
                               (key, binding_key, series_key, value["frame_index"], payload))
            connection.execute("COMMIT")
        return deepcopy(value)

    def get(self, envelope_id: str) -> dict[str, Any] | None:
        key = self._key("envelope", [text(envelope_id, 256)])
        with self.store._connection() as connection:
            row = connection.execute("SELECT * FROM observation_receipts WHERE receipt_key=?", (key,)).fetchone()
            return None if row is None else self._unpack(row)

    def latest(self, execution_id: str, device_id: str, operator_id: str) -> dict[str, Any] | None:
        series = [_execution_id(execution_id), text(device_id, 256), text(operator_id, 256)]
        key = self._key("series", series)
        with self.store._connection() as connection:
            row = connection.execute("SELECT * FROM observation_receipts WHERE series_key=? "
                                     "ORDER BY frame_index DESC LIMIT 1", (key,)).fetchone()
            if row is None:
                return None
            value = self._unpack(row)
            if [value[field] for field in ("execution_id", "device_id", "operator_id")] != series:
                raise ExecutionError("EXECUTION_STORAGE")
            return value
