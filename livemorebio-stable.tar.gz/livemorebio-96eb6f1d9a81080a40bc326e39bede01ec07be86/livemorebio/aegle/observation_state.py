"""Observation attachment shared by numerical and descriptive selections.

This holder executes no model, invents no measurements and performs no admission.
The caller must first validate identity, consent, device binding and custody.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
from typing import Any


class ObservationState:
    def __init__(self) -> None:
        self.patch: dict[str, Any] = {
            "connected": False, "source": None, "mode": None,
            "hardware_present": False, "protocol_version": None,
            "sequence": None, "envelope_id": None, "device_id": None,
        }
        self.observations: dict[str, Any] = {}
        self.execution_observations: dict[str, Any] = {}

    def ingest_patch_envelope(self, envelope: Any, *, received_at: Any = None) -> dict:
        from ..life_patch.protocol_v3 import normalize_observations

        # Each projection is exactly one envelope. A partial packet cannot
        # silently inherit another packet's subject, clocks or QC classifications.
        self.observations = normalize_observations(envelope, received_at=received_at)
        self.patch = {
            "connected": True, "source": f"life-patch-{envelope.mode.value}",
            "mode": envelope.mode.value, "hardware_present": envelope.mode.value == "physical",
            "protocol_version": envelope.protocol_version, "sequence": envelope.sequence,
            "envelope_id": envelope.envelope_id, "device_id": envelope.device_id,
            "subject_fingerprint": hashlib.sha256(envelope.subject_id.encode("utf-8")).hexdigest(),
        }
        return self.state()

    def state(self) -> dict[str, Any]:
        return {"patch": deepcopy(self.patch), "observations": deepcopy(self.observations)}
