"""Bounded encrypted access receipts in the subject registry's own transaction.

The caller owns commit/rollback. An outstanding begin permanently charges its
terminal slot until an authenticated completion consumes that reservation.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import json
import re
import sqlite3
from typing import Any, Callable
from uuid import UUID, uuid4

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

_AAD = b"livemore.subject-registry.audit.v1\0"
_ACTIONS = {
    "livemore.subject-access-audit.v1": frozenset({"inspect", "select_observations", "reconcile_selection", "create_twin", "create_cohort", "member_page", "member_read", "source_capture"}),
    "livemore.physical-access-audit.v1": frozenset({"inspect", "bind", "authorize", "admit", "receipt_read", "project", "retry", "acknowledge"}),
}
_OUTCOMES = frozenset({"SUCCESS", "ACCESS_FAILED"})


class RegistryAuditError(ValueError):
    code = "REGISTRY_AUDIT_UNAVAILABLE"

    def __init__(self) -> None:
        super().__init__("Subject access audit is unavailable; no successful access is confirmed.")


def _uuid(value: Any) -> str:
    if not isinstance(value, str):
        raise RegistryAuditError()
    try:
        if str(UUID(value)) != value:
            raise ValueError
    except ValueError as error:
        raise RegistryAuditError() from error
    return value


@dataclass(frozen=True)
class AuditReservation:
    event_id: str
    request_id: str
    authority_token: str | None = None


class RegistryAudit:
    def __init__(self, *, key: bytes, store_id: str, process_instance: str,
                 source_sha256: str, clock: Callable[[], str] | None = None) -> None:
        if len(key) != 32 or not isinstance(source_sha256, str) or not re.fullmatch(r"[0-9a-f]{64}", source_sha256):
            raise RegistryAuditError()
        self._cipher = AESGCM(key)
        self.store_id = _uuid(store_id)
        self.process_instance = _uuid(process_instance)
        self.source_sha256 = source_sha256
        self._clock = clock or (lambda: datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"))
        self.authority_check: Callable[[sqlite3.Connection], str] | None = None

    @staticmethod
    def initialize(connection: sqlite3.Connection) -> None:
        # Individual statements deliberately avoid executescript's implicit commit.
        connection.execute("CREATE TABLE IF NOT EXISTS registry_audit(event_id TEXT PRIMARY KEY, sequence INTEGER UNIQUE NOT NULL, nonce BLOB NOT NULL, ciphertext BLOB NOT NULL)")
        connection.execute("CREATE TABLE IF NOT EXISTS registry_audit_reservations(event_id TEXT PRIMARY KEY, request_id TEXT UNIQUE NOT NULL, FOREIGN KEY(event_id) REFERENCES registry_audit(event_id))")

    def verify_existing(self, connection: sqlite3.Connection) -> bool:
        """Authenticate existing audit/store identity before writing with this key.

        No clinical record is decrypted. False means no existing audit proof;
        it is not a claim that a legacy store's supplied key has been verified.
        """
        row = connection.execute("SELECT event_id,nonce,ciphertext FROM registry_audit ORDER BY sequence LIMIT 1").fetchone()
        if row is None:
            return False
        raw = self._cipher.decrypt(bytes(row[1]), bytes(row[2]), _AAD + row[0].encode("ascii"))
        payload = json.loads(raw)
        if len(raw) > 4096 or not isinstance(payload, dict) or payload.get("local_store_id") != self.store_id:
            raise RegistryAuditError()
        return True

    @staticmethod
    def _writer(connection: sqlite3.Connection) -> None:
        if not connection.in_transaction:
            connection.execute("BEGIN IMMEDIATE")
        # Also acquire the writer lock for callers already in a deferred txn.
        connection.execute("UPDATE registry_audit_reservations SET request_id=request_id WHERE 0")

    @staticmethod
    def _verify_row(connection: sqlite3.Connection, expected: tuple[str, int, bytes, bytes]) -> None:
        row = connection.execute("SELECT * FROM registry_audit WHERE event_id=?", (expected[0],)).fetchone()
        if row is None or tuple(row) != expected:
            raise RegistryAuditError()

    def _append_row(self, connection: sqlite3.Connection, payload: dict[str, Any]) -> tuple[str, int, bytes, bytes]:
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
        if len(raw) > 4096:
            raise RegistryAuditError()
        event_id = str(uuid4())
        nonce = uuid4().bytes[:12]
        encrypted = self._cipher.encrypt(nonce, raw, _AAD + event_id.encode("ascii"))
        sequence = connection.execute("SELECT COALESCE(MAX(sequence),0)+1 FROM registry_audit").fetchone()[0]
        # Retain trusted encryption-origin bytes, never adopt a trigger-modified
        # stored row as the expected witness for that same write.
        expected = (event_id, sequence, nonce, encrypted)
        connection.execute("INSERT INTO registry_audit VALUES(?,?,?,?)", expected)
        self._verify_row(connection, expected)
        return expected

    def _append(self, connection: sqlite3.Connection, payload: dict[str, Any]) -> str:
        return self._append_row(connection, payload)[0]

    def begin(self, connection: sqlite3.Connection, *, request_id: str, action: str,
              opaque_record_id: str | None, schema: str = "livemore.subject-access-audit.v1") -> AuditReservation:
        _uuid(request_id)
        if not isinstance(schema, str) or not isinstance(action, str) or action not in _ACTIONS.get(schema, ()):
            raise RegistryAuditError()
        if opaque_record_id is not None and (not isinstance(opaque_record_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", opaque_record_id)):
            raise RegistryAuditError()
        self._writer(connection)
        authority_token = self.check_authority(connection)
        events = connection.execute("SELECT COUNT(*) FROM registry_audit").fetchone()[0]
        reservations = connection.execute("SELECT COUNT(*) FROM registry_audit_reservations").fetchone()[0]
        if events + reservations + 2 > 10000:
            raise RegistryAuditError()
        payload = {"schema": schema, "request_id": request_id, "action": action,
                   "opaque_record_id": opaque_record_id, "started_at": self._clock(),
                   "completed_at": None, "outcome_code": None, "local_store_id": self.store_id,
                   "local_process_instance": self.process_instance, "source_sha256": self.source_sha256}
        expected = self._append_row(connection, payload)
        event_id = expected[0]
        connection.execute("INSERT INTO registry_audit_reservations VALUES(?,?)", (event_id, request_id))
        self._verify_row(connection, expected)
        reserved = connection.execute("SELECT event_id,request_id FROM registry_audit_reservations WHERE event_id=?", (event_id,)).fetchone()
        if reserved is None or tuple(reserved) != (event_id, request_id):
            raise RegistryAuditError()
        return AuditReservation(event_id, request_id, authority_token)

    def check_authority(self, connection: sqlite3.Connection, reservation: AuditReservation | None = None) -> str | None:
        """A trusted registry hook rechecks authority inside the writer transaction.

        The hook is optional only for standalone audit utilities, which cannot
        decrypt or mutate clinical registry records. No authority fields alter
        the frozen normal audit payload or AAD.
        """
        self._writer(connection)
        token = self.authority_check(connection) if self.authority_check is not None else None
        if reservation is not None and token != reservation.authority_token:
            raise RegistryAuditError()
        return token

    def _reserved_payload(self, connection: sqlite3.Connection, reservation: AuditReservation) -> dict[str, Any]:
        if type(reservation) is not AuditReservation:
            raise RegistryAuditError()
        row = connection.execute("SELECT a.nonce,a.ciphertext FROM registry_audit a JOIN registry_audit_reservations r ON r.event_id=a.event_id WHERE r.event_id=? AND r.request_id=?", (reservation.event_id, reservation.request_id)).fetchone()
        if row is None:
            raise RegistryAuditError()
        payload = json.loads(self._cipher.decrypt(bytes(row[0]), bytes(row[1]), _AAD + reservation.event_id.encode("ascii")))
        if (payload.get("request_id") != reservation.request_id or payload.get("local_store_id") != self.store_id
                or payload.get("completed_at") is not None or payload.get("outcome_code") is not None):
            raise RegistryAuditError()
        return payload

    def recover(self, connection: sqlite3.Connection, *, request_id: str) -> AuditReservation:
        """Resolve an incomplete local receipt after restart; never repeat its action."""
        _uuid(request_id)
        row = connection.execute("SELECT event_id FROM registry_audit_reservations WHERE request_id=?", (request_id,)).fetchone()
        if row is None:
            raise RegistryAuditError()
        reservation = AuditReservation(row[0], request_id, self.check_authority(connection))
        self._reserved_payload(connection, reservation)
        return reservation

    def finish(self, connection: sqlite3.Connection, reservation: AuditReservation, *, outcome_code: str) -> str:
        if not isinstance(outcome_code, str) or outcome_code not in _OUTCOMES:
            raise RegistryAuditError()
        self._writer(connection)
        self.check_authority(connection, reservation)
        payload = self._reserved_payload(connection, reservation)
        # The immutable begin retains its origin; this separate completion event
        # names the process that actually wrote it, including explicit recovery.
        payload.update(completed_at=self._clock(), outcome_code=outcome_code,
                       local_process_instance=self.process_instance, source_sha256=self.source_sha256)
        expected = self._append_row(connection, payload)
        connection.execute("DELETE FROM registry_audit_reservations WHERE event_id=? AND request_id=?", (reservation.event_id, reservation.request_id))
        self._verify_row(connection, expected)
        if connection.execute("SELECT 1 FROM registry_audit_reservations WHERE event_id=? OR request_id=?", (reservation.event_id, reservation.request_id)).fetchone():
            raise RegistryAuditError()
        return expected[0]
