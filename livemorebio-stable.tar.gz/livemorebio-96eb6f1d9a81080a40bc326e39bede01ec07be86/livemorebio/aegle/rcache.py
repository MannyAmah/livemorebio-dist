"""livemorebio.aegle.rcache — small disk-backed persistence cache for compound
resolution and preview payloads.

Why this exists: ChEMBL + Open Targets lookups are live and occasionally slow (ChEMBL's
EBI API can answer in >20 s, over the engine's request timeout). The engine's in-memory
lru_cache is lost on every restart, so each restart re-pays that latency and is exposed to
transient timeouts. This cache persists ONLY successful resolutions to disk, so a compound
that resolves once is served instantly and offline thereafter — surviving restarts.

Failures and timeouts are never persisted (that would poison future lookups). Writes are
atomic (temp file + os.replace). One JSON file per key under ~/.livemore/resolve_cache.
Invalidation is manual and intentional: delete the directory (or a single file), or pass
refresh=true on /api/resolve to force a live re-fetch and overwrite the entry.
"""
from __future__ import annotations
import json
import os
import tempfile
import hashlib

CACHE_DIR = os.path.expanduser(os.environ.get("LIVEMORE_RESOLVE_CACHE",
                                              "~/.livemore/resolve_cache"))


def _path(key: str) -> str:
    h = hashlib.sha1(key.strip().lower().encode("utf-8")).hexdigest()[:24]
    return os.path.join(CACHE_DIR, f"{h}.json")


def get(key: str):
    """Return the cached value for key, or None on miss / any read error."""
    try:
        with open(_path(key), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def put(key: str, value) -> bool:
    """Persist value under key atomically. Returns True on success, False otherwise.
    Never raises — caching is best-effort and must never break a live request."""
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=CACHE_DIR, suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(value, f)
        os.replace(tmp, _path(key))
        return True
    except Exception:
        try:
            if 'tmp' in dir() and os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        return False


def stats() -> dict:
    """Cheap introspection: how many entries are persisted."""
    try:
        n = len([f for f in os.listdir(CACHE_DIR) if f.endswith(".json")])
    except Exception:
        n = 0
    return {"dir": CACHE_DIR, "entries": n}
