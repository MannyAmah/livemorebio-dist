"""Authenticated descriptive cohort API, independent of live twin state."""
from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Any, Callable, Coroutine

from fastapi import APIRouter, Request
from fastapi.exception_handlers import http_exception_handler
from fastapi.responses import JSONResponse, Response
from fastapi.routing import APIRoute
from starlette.exceptions import HTTPException

from ..reference_cohort_contract import is_public_reference
from ..security import patch_storage_key, require_operator_auth
from ..strict_json import StrictJSONError, parse_json_object
from . import population_sources as sources
from . import population_records
from .reference_cohorts import ReferenceCohortError, ReferenceCohortService, reference_source_dir


class ReferenceRoute(APIRoute):
    def get_route_handler(self) -> Callable[[Request], Coroutine[Any, Any, Response]]:
        handler = super().get_route_handler()

        async def no_store(request: Request) -> Response:
            try:
                response = await handler(request)
            except HTTPException as error:
                response = await http_exception_handler(request, error)
            response.headers["Cache-Control"] = "no-store"
            return response
        return no_store


router = APIRouter(route_class=ReferenceRoute)


def service() -> ReferenceCohortService:
    from .. import registry
    key = patch_storage_key(create=True)
    if key is None:
        raise ReferenceCohortError("REFERENCE_STORAGE_UNAVAILABLE", "Reference encryption configuration is unavailable.", 503)
    path = os.environ.get("LIVEMORE_SUBJECT_REGISTRY", "").strip() or str(Path(registry.REG_DIR) / "subjects.sqlite3")
    return ReferenceCohortService(path, key=key, source_dir=reference_source_dir())


async def _body(request: Request) -> dict[str, Any]:
    raw = bytearray()
    async for chunk in request.stream():
        raw.extend(chunk)
        if len(raw) > 16 * 1024:
            raise ReferenceCohortError("INVALID_REFERENCE_JSON", "Reference request exceeds 16 KiB.")
    try:
        return parse_json_object(raw)
    except StrictJSONError as error:
        raise ReferenceCohortError("INVALID_REFERENCE_JSON", str(error)) from None


def failure(error: Exception) -> JSONResponse:
    if isinstance(error, ReferenceCohortError):
        return JSONResponse({"code": error.code, "error": str(error)}, status_code=error.status)
    if isinstance(error, sources.PopulationSourceError):
        return JSONResponse({"code": error.code, "error": "Reviewed source admission is unavailable; inspect source status."}, status_code=503)
    return JSONResponse({"code": "REFERENCE_STORAGE_UNAVAILABLE", "error": "Reference storage or its audit is unavailable."}, status_code=503)


def project_cohort_summary_for_api(record: dict[str, Any]) -> dict[str, Any]:
    """The legacy list/get route must call this before returning a new record.

    Re-read and audit authoritative encrypted state rather than trusting a
    caller-supplied projection or accidentally returning its member manifest.
    """
    if not is_public_reference(record):
        return record
    return service().get_summary(record["cohort_id"])


@router.get("/api/population-sources")
def source_catalog(request: Request):
    require_operator_auth(request)
    try:
        return {"sources": [{**sources.source_manifest(), "status": sources.source_status(reference_source_dir())}],
                "definitions": population_records.definitions(), "scope": "statistical_research_only",
                "executable": False, "clinical_admission": False, "physical_device_association": False}
    except Exception as error:
        return failure(error)


@router.post("/api/population-sources/{source_id}/install")
async def install(source_id: str, request: Request):
    require_operator_auth(request)
    try:
        payload = await _body(request)
        if source_id != sources.SOURCE_ID or payload != {"accepted_use": "statistical_research"}:
            raise ReferenceCohortError("INVALID_REFERENCE_SOURCE_USE", "Select the reviewed source and explicitly accept statistical research use.")
        return await asyncio.to_thread(sources.install_source, reference_source_dir(), accepted_use="statistical_research")
    except Exception as error:
        return failure(error)


@router.post("/api/reference-cohorts/preview")
async def preview(request: Request):
    require_operator_auth(request)
    try:
        payload = await _body(request)
        return await asyncio.to_thread(lambda: service().preview(payload))
    except Exception as error:
        return failure(error)


@router.post("/api/reference-cohorts")
async def create(request: Request):
    require_operator_auth(request)
    try:
        payload = await _body(request)
        result = await asyncio.to_thread(lambda: service().create(payload, idempotency_key=request.headers.get("Idempotency-Key", "")))
        return JSONResponse(result, status_code=200 if result["idempotent_replay"] else 201)
    except Exception as error:
        return failure(error)


@router.get("/api/reference-cohorts/{cohort_id}/members")
def members(cohort_id: str, request: Request, limit: str = "10", cursor: str | None = None):
    require_operator_auth(request)
    try:
        if not limit.isascii() or not limit.isdecimal() or not 1 <= len(limit) <= 2:
            raise ReferenceCohortError("INVALID_REFERENCE_MEMBER_PAGE", "Member page size must be an integer from 1 to 50.")
        return service().page_members(cohort_id, limit=int(limit), cursor=cursor)
    except Exception as error:
        return failure(error)


@router.get("/api/reference-cohorts/{cohort_id}/members/{member_id}")
def member(cohort_id: str, member_id: str, request: Request):
    require_operator_auth(request)
    try:
        return service().get_member(cohort_id, member_id)
    except Exception as error:
        return failure(error)
