"""Durable, run-scoped storage for synthetic cohort-screen artifacts."""
from __future__ import annotations

import json
import os
import re
import time
import uuid
from copy import deepcopy


SCHEMA = "livemore.screen-run.v1"
_RUN_ID = re.compile(r"^[0-9a-f]{32}$")


def run_dir() -> str:
    return os.environ.get(
        "LIVEMORE_SCREEN_RUN_DIR",
        os.path.expanduser("~/.livemore/screen-runs"),
    )


def _path(run_id: str) -> str | None:
    if not _RUN_ID.fullmatch(run_id or ""):
        return None
    return os.path.join(run_dir(), f"{run_id}.json")


def save(result: dict, request: dict) -> dict:
    """Persist one completed run atomically and return the response payload."""
    directory = run_dir()
    os.makedirs(directory, mode=0o700, exist_ok=True)
    try:
        os.chmod(directory, 0o700)
    except OSError:
        pass
    run_id = uuid.uuid4().hex
    response = deepcopy(result)
    response["run_id"] = run_id
    envelope = {
        "schema": SCHEMA,
        "run_id": run_id,
        "status": "completed",
        "created_at": round(time.time(), 3),
        "request": deepcopy(request),
        "result": response,
    }
    path = _path(run_id)
    tmp = os.path.join(directory, f".{run_id}.tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(envelope, handle, sort_keys=True, separators=(",", ":"))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    return response


def load(run_id: str) -> dict | None:
    path = _path(run_id)
    if path is None:
        return None
    try:
        with open(path, encoding="utf-8") as handle:
            envelope = json.load(handle)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None
    if envelope.get("schema") != SCHEMA or envelope.get("run_id") != run_id:
        return None
    return envelope
