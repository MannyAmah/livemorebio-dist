"""Legacy operator-submitted model-report drafts for the evidence-package system.

This interface does not authenticate execution, dataset lineage or a reviewer.
It cannot approve a protocol or lock a draft on an invented person's behalf.
Use the frozen research workflow for server-bound predictions and measurements.
"""
from __future__ import annotations

import os
import platform
import re
import subprocess
import threading
import uuid
from datetime import datetime, timezone
from decimal import Decimal

from ..evidence import (
    ContextOfUse,
    EvidenceService,
    EvidenceStore,
    NamedValue,
    PredictionRun,
    PredictionValue,
    ProtocolVersion,
    Provenance,
    ScenarioSnapshot,
)
from ..evidence.exporter import export_package
from ..evidence.policies import APPROVED_POLICIES

TENANT = "livemore-console"
from .. import registry
DB_PATH = os.environ.get("LIVEMORE_EVIDENCE_DB", os.path.join(registry.REG_DIR, "evidence.sqlite"))
EXPORT_DIR = os.environ.get("LIVEMORE_EVIDENCE_EXPORT_DIR", os.path.join(registry.REG_DIR, "evidence-exports"))
POLICY = APPROVED_POLICIES[("livemore-research-model-policy", "1.0.0")]

_lock = threading.Lock()
_service: EvidenceService | None = None


def service() -> EvidenceService:
    global _service
    with _lock:
        if _service is None:
            os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
            _service = EvidenceService(EvidenceStore(DB_PATH))
        return _service


def _code_version() -> str:
    """Record a clean checkout revision, or explicitly unpinned source identity."""
    try:
        source_directory = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        sha = subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=source_directory,
            stderr=subprocess.DEVNULL, timeout=3).decode().strip()
        if re.fullmatch(r"[0-9a-f]{40}", sha):
            changed = subprocess.check_output(
                ["git", "status", "--porcelain", "--untracked-files=normal", "--", "."],
                cwd=source_directory, stderr=subprocess.DEVNULL, timeout=3,
            ).decode().strip()
            if changed:
                return f"working-tree:git-{sha}"
            return f"git:{sha}"
    except Exception:
        pass
    return "unversioned-source:content-not-pinned"


def _environment_identity() -> str:
    """Truthful execution-environment identity (we are not asserting a container)."""
    if os.path.exists("/.dockerenv"):
        return "container:docker-unpinned"
    return f"process:python-{platform.python_version()}-{platform.system().lower()}-{platform.machine()}"


def _now() -> datetime:
    return datetime.now(timezone.utc)


# Real physiological units of the Bergman-model twin parameters, as documented
# in engines/metabolic/glucose_insulin.py (UCUM-style structured tokens).
_PARAM_UNITS = {
    "Gb": "mg/dL", "Ib": "uU/mL", "Gt": "mg/dL",
    "SG": "min-1", "p2": "min-1", "n": "min-1", "ka": "min-1",
    "Si": "mL.uU-1.min-1",              # (uU/mL)^-1 min^-1
    "gamma": "uU.mL-1.min-1.mg-1.dL",   # uU/mL/min per mg/dL
    "f_bioavail": "1", "vg_per_kg": "dL/kg", "weight_kg": "kg",
}


def create_from_run(run: dict) -> dict:
    """Create an unapproved model-report draft from operator-submitted values.

    The legacy payload is not proof of execution or independent review:
      compound, dose, subject (twin id), profile, twin_params {Si,Gb,gamma,...},
      endpoint readouts [{endpoint, value, unit}], decision, grams, hours,
      audit_fingerprint (unverified caller-supplied correlation reference).
    """
    if not isinstance(run, dict):
        raise ValueError("evidence report must be a JSON object")
    required = ("compound", "subject", "twin_params", "readouts")
    missing = [k for k in required if not run.get(k)]
    if missing:
        raise ValueError(f"run is missing required real-run fields: {missing}")

    compound = str(run["compound"])
    subject = str(run["subject"])
    dose = float(run.get("dose", 1.0))
    grams = float(run.get("grams", 75.0))
    hours = float(run.get("hours", 4.0))
    now = _now()
    pid = "evpkg-" + now.strftime("%Y%m%d%H%M%S") + "-" + uuid.uuid4().hex[:6]
    code_version = _code_version()
    # Working-tree builds remain visibly unpinned and cannot claim release identity.
    model_id = f"aegle-metabolic-bergman@{code_version}"
    dataset_id = "dataset-lineage:not-declared"

    context = ContextOfUse(
        context_id=f"cou-{pid}",
        question_of_interest=f"Does {compound} change the OGTT glucose response of twin {subject}?",
        intended_decision="Prioritize or deprioritize the compound for follow-up (hypothesis triage)",
        decision_owner_role="qualified_scientist",
        target_population="in-silico twin representing the configured subject",
        model_system="Aegle metabolic twin (Bergman glucose-insulin ODE)",
        model_influence="supportive",
        wrong_decision_consequence="misprioritized candidate in early screening",
        risk="low",
        impact="medium",
        limitations=("model-only hypothesis triage; not wet-lab or clinical evidence",),
        required_dimensions=POLICY.required_dimensions,
        policy_id=POLICY.policy_id,
        policy_hash=POLICY.canonical_hash,
    )
    protocol = ProtocolVersion(
        protocol_id=f"protocol-ogtt-{pid}",
        version="1.0.0",
        objective=f"Quantify the in-silico OGTT effect of {compound} on twin {subject}",
        hypothesis=f"{compound} at {dose:g}x reference dose changes the OGTT glucose exposure",
        candidate=compound,
        target="glucose-insulin axis",
        assay="in-silico OGTT",
        dose=f"{dose:g}x reference",
        duration=f"{hours:g} h",
        controls=("untreated baseline of the same twin",),
        endpoints=tuple(str(r["endpoint"]) for r in run["readouts"]),
        acceptance_criteria=("draft endpoint criteria require prospective independent review",),
        statistical_plan="paired within-twin baseline-vs-treated comparison",
        approval_status="draft",
        deviations=(),
        sop_references=("livemorebio.cendos.assays.ogtt_effect",),
    )
    inputs = tuple(
        NamedValue(k, Decimal(str(v)), _PARAM_UNITS.get(k, "unspecified"))
        for k, v in sorted(run["twin_params"].items())
        if isinstance(v, (int, float))
    )
    if not inputs:
        raise ValueError("twin_params carried no numeric engine parameters")
    snapshot = ScenarioSnapshot(
        snapshot_id=f"snapshot-{pid}",
        twin_id=subject,
        captured_at=now,
        measurement_ids=(),
        measurement_hashes=(),
        model_inputs=inputs,
        code_version=code_version,
        model_versions=(model_id,),
        dataset_versions=(dataset_id,),
    )
    def _unit_token(u: str) -> str:
        # structured-token form of a unit string ("mg/dL*min" -> "mg/dL.min")
        return (u or "1").replace("*", ".").replace(" ", ".")

    outputs = tuple(
        PredictionValue(
            endpoint=str(r["endpoint"]),
            value=Decimal(str(r["value"])),
            unit=_unit_token(str(r.get("unit", ""))),
            # point value only — no calibrated uncertainty method exists yet,
            # so the interval is the value itself and confidence is 0
            # (rendered as "not_assessed" in the exported report).
            lower=Decimal(str(r["value"])),
            upper=Decimal(str(r["value"])),
            confidence=Decimal("0"),
        )
        for r in run["readouts"]
    )
    from ..evidence import canonical_hash
    prediction = PredictionRun(
        prediction_id=f"prediction-{pid}",
        live_twin_id=subject,
        scenario_snapshot=snapshot,
        cendos_run_id=str(run.get("cendos_run_id", f"console-run-{pid}")),
        protocol_hash=canonical_hash(protocol),
        input_measurement_ids=(),
        model_versions=(model_id,),
        code_version=code_version,
        dataset_versions=(dataset_id,),
        container_digest=_environment_identity(),
        deterministic_seed=int(run.get("seed", 0)),
        outputs=outputs,
        assumptions=("operator-submitted engine parameters and numerical readouts",
                     "source dataset lineage is not declared; no source-content hash is asserted"),
        limitations=("model-only hypothesis triage; not wet-lab or clinical evidence",
                     "single-compartment glucose-insulin model",
                     "legacy report execution and prospective protocol approval are not independently verified"),
        actor_id=str(run.get("actor", "console-operator")),
        generated_at=now,
    )
    correlation = run.get("audit_fingerprint")
    derived_hashes = [snapshot.state_hash, prediction.input_hash]
    if correlation is not None and (not isinstance(correlation, str)
                                    or re.fullmatch(r"[0-9a-f]{64}", correlation) is None):
        raise ValueError("audit correlation reference must be a 64-character hexadecimal string")
    provenance = Provenance(
        source_ids=(f"twin:{subject}", f"assay:in-silico-ogtt:{compound}"),
        transformations=("Bergman glucose-insulin ODE baseline vs treated simulation",
                         "cendos.assays.ogtt_effect decision rule"),
        model_versions=(model_id,),
        code_commit=code_version,
        environment=_environment_identity(),
        content_hashes=tuple(dict.fromkeys(derived_hashes)),
        correlation_ids=(f"unverified-audit-ref:{correlation}",) if correlation else (),
    )
    package = service().create_model_only(
        tenant_id=TENANT,
        package_id=pid,
        use_case=f"in-silico OGTT triage — {compound} on {subject}",
        # Modeled packages must carry the registered safe outward claim; the
        # evidence layer replaces it with the exact state-specific safe claim.
        claim=(f"Model-only response of {re.sub(r'[^A-Za-z0-9_.:/%+-]', '-', compound)} "
               f"for {re.sub(r'[^A-Za-z0-9_.:/%+-]', '-', subject)}; "
               "research only and not validated for safety or efficacy"),
        policy=POLICY,
        context_of_use=context,
        protocol=protocol,
        prediction=prediction,
        provenance=provenance,
        created_by=str(run.get("actor", "console-operator")),
    )
    return summarize(package)


def summarize(p) -> dict:
    return {
        "package_id": p.package_id,
        "version": p.version,
        "claim": p.claim,
        "claim_state": p.claim_state.value,
        "lifecycle": p.lifecycle.value,
        "use_case": p.use_case,
        "created_at": p.created_at.isoformat(),
        "created_by": p.created_by,
        "content_hash": p.content_hash,
        "n_predictions": len(p.predictions),
        "n_measurements": len(p.measurements),
        "n_validations": len(p.validation_events),
    }


def detail(p) -> dict:
    """Full §33-tab detail: Claim / Protocol / Prediction / Measurements /
    Validation / Provenance — audit and export are separate endpoints."""
    d = summarize(p)
    d.update({
        "schema_version": p.schema_version,
        "tenant_id": p.tenant_id,
        "policy": {"policy_id": p.policy.policy_id, "version": p.policy.version,
                   "required_dimensions": [x.value for x in p.policy.required_dimensions],
                   "clinical_use": p.policy.clinical_use},
        "context_of_use": {
            "question_of_interest": p.context_of_use.question_of_interest,
            "intended_decision": p.context_of_use.intended_decision,
            "model_system": p.context_of_use.model_system,
            "model_influence": p.context_of_use.model_influence,
            "risk": p.context_of_use.risk, "impact": p.context_of_use.impact,
            "limitations": list(p.context_of_use.limitations),
        },
        "protocol": {
            "protocol_id": p.protocol.protocol_id, "version": p.protocol.version,
            "objective": p.protocol.objective, "hypothesis": p.protocol.hypothesis,
            "candidate": p.protocol.candidate, "assay": p.protocol.assay,
            "dose": p.protocol.dose, "duration": p.protocol.duration,
            "controls": list(p.protocol.controls), "endpoints": list(p.protocol.endpoints),
            "acceptance_criteria": list(p.protocol.acceptance_criteria),
            "statistical_plan": p.protocol.statistical_plan,
            "approval_status": p.protocol.approval_status,
        },
        "predictions": [{
            "prediction_id": pr.prediction_id,
            "outputs": [{"endpoint": o.endpoint, "value": str(o.value), "unit": o.unit,
                         "lower": (str(o.lower) if o.lower is not None else None),
                         "upper": (str(o.upper) if o.upper is not None else None)}
                        for o in pr.outputs],
            "model_versions": list(pr.model_versions),
            "code_version": pr.code_version,
            "container_digest": pr.container_digest,
            "deterministic_seed": pr.deterministic_seed,
            "assumptions": list(pr.assumptions), "limitations": list(pr.limitations),
            "generated_at": pr.generated_at.isoformat(),
            "input_hash": pr.input_hash,
            "twin_inputs": [{"name": v.name, "value": str(v.value), "unit": v.unit}
                            for v in pr.scenario_snapshot.model_inputs],
        } for pr in p.predictions],
        "measurements": [{
            "envelope_id": m.envelope_id, "role": m.role.value,
            "endpoint": m.payload.endpoint, "value": str(m.payload.value),
            "unit": m.payload.unit, "source_data_class": m.payload.source_data_class.value,
            "measured_at": m.payload.measured_at.isoformat(),
        } for m in p.measurements],
        "model_verifications": [{
            "verification_id": v.verification_id, "disposition": v.disposition.value,
            "scope": v.scope, "method": v.method, "verified_at": v.verified_at.isoformat(),
        } for v in p.model_verifications],
        "validation_events": [{
            "event_id": e.event_id, "dimension": e.dimension.value,
            "status": e.status.value, "summary": e.summary,
        } for e in p.validation_events],
        "validation_summary": [{"dimension": a.dimension.value, "status": a.status.value,
                                "basis": a.basis} for a in p.validation_summary],
        "provenance": {
            "source_ids": list(p.provenance.source_ids),
            "transformations": list(p.provenance.transformations),
            "model_versions": list(p.provenance.model_versions),
            "code_commit": p.provenance.code_commit,
            "environment": p.provenance.environment,
            "content_hashes": list(p.provenance.content_hashes),
            "correlation_ids": list(p.provenance.correlation_ids),
        },
    })
    return d


def export_zip(package_id: str) -> str:
    """Export an already locked package; never impersonate a reviewer to lock it."""
    svc = service()
    p = svc.get(TENANT, package_id)
    if p.lifecycle.value == "draft":
        raise ValueError("draft export requires independently authenticated review and lock; use the governed evidence workflow")
    os.makedirs(EXPORT_DIR, exist_ok=True)
    export = export_package(p, EXPORT_DIR)
    return str(export.archive_path)
