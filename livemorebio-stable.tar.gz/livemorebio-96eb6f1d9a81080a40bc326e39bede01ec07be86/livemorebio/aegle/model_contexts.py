"""Typed numerical availability; clinical descriptions never select a model.

Only the already shipped aggregate-prior compatibility context is resolved here.
No real-human model-binding registry or individual qualification is implemented.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from typing import Any

from ..engines.metabolic.glucose_insulin import MetabolicProfile
from ..reference_cohort_contract import is_public_reference
from .clinical_parameters import _PARAMETER_UNITS, validate_model_parameters
from .population import SUPPORTED_REFERENCE_SOURCES

_MESSAGES = {
    "MODEL_BINDING_REQUIRED": "A reviewed model-specific binding is required for numerical execution.",
    "MODEL_CONTEXT_INVALID": "The computational context is invalid.",
    "MODEL_CONTEXT_UNSUPPORTED": "This computational context is not supported.",
    "MODEL_CONTEXT_SOURCE_MISMATCH": "The computational context does not match its retained source.",
}
_SEVEN = frozenset({"Gb", "Si", "gamma", "Ib", "Gt", "SG", "weight_kg"})
_DEFAULTS = {"p2": 0.025, "n": 0.14, "ka": 0.020, "f_bioavail": 0.75, "vg_per_kg": 2.0}


class ModelContextError(ValueError):
    def __init__(self, code: str) -> None:
        self.code = code if code in _MESSAGES else "MODEL_CONTEXT_INVALID"
        super().__init__(_MESSAGES[self.code])


@dataclass(frozen=True)
class ResolvedModelContext:
    """JSON bytes freeze values/lineage; every mutable public value is detached."""
    _profile_json: bytes
    _provenance_json: bytes
    source_snapshot_sha256: str
    subject_id: str
    model_id: str = "livemore-legacy-metabolic-reference-v1"

    @property
    def profile(self) -> MetabolicProfile:
        return MetabolicProfile(**json.loads(self._profile_json))

    @property
    def parameter_provenance(self) -> dict[str, dict[str, Any]]:
        return json.loads(self._provenance_json)

    def require_human(self, human: Any) -> None:
        if (getattr(human, "source_class", None) != "REFERENCE_GROUNDED_SYNTHETIC"
                or getattr(human, "id", None) != self.subject_id
                or getattr(human, "reference_source_id", None) != "livemore-public-metabolic-reference-v1"):
            raise ModelContextError("MODEL_CONTEXT_SOURCE_MISMATCH")


def _encoded(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def resolve_model_context(record: dict[str, Any]) -> ResolvedModelContext:
    if not isinstance(record, dict):
        raise ModelContextError("MODEL_CONTEXT_INVALID")
    if is_public_reference(record) or is_public_reference(record.get("reference")):
        raise ModelContextError("MODEL_CONTEXT_INVALID")
    if record.get("schema") == "livemore.frozen-real-human-member.v1":
        # Snapshot integrity belongs to the registry; a wrapper never changes the
        # fact that no real-human binding is admitted in this implementation.
        if record.get("source_class") != "REAL_HUMAN":
            raise ModelContextError("MODEL_CONTEXT_INVALID")
        raise ModelContextError("MODEL_BINDING_REQUIRED")
    if record.get("source_class") == "REAL_HUMAN":
        binding = record.get("model_binding")
        if binding is None:
            raise ModelContextError("MODEL_BINDING_REQUIRED")
        raise ModelContextError("MODEL_CONTEXT_UNSUPPORTED" if isinstance(binding, dict) and binding else "MODEL_CONTEXT_INVALID")
    if record.get("source_class") != "REFERENCE_GROUNDED_SYNTHETIC":
        raise ModelContextError("MODEL_CONTEXT_UNSUPPORTED")
    stratum = record.get("reference_stratum")
    if not isinstance(stratum, str):
        raise ModelContextError("MODEL_CONTEXT_INVALID")
    if stratum not in {"dpp-high-risk-metabolic", "nhanes-diagnosed-diabetes-older", "pxr-reference"}:
        raise ModelContextError("MODEL_CONTEXT_UNSUPPORTED")
    source, lineage = record.get("reference_source"), record.get("reference_lineage")
    source_id = "livemore-public-metabolic-reference-v1"
    release = SUPPORTED_REFERENCE_SOURCES[source_id]["release"]
    if (not isinstance(source, dict) or not isinstance(lineage, dict)
            or source.get("role") != "population_reference" or source.get("source_id") != source_id
            or source.get("release") != release or lineage.get("source_id") != source_id
            or lineage.get("release") != release or lineage.get("stratum") != stratum):
        raise ModelContextError("MODEL_CONTEXT_SOURCE_MISMATCH")
    parameters = record.get("model_parameters")
    if not isinstance(parameters, dict) or set(parameters) != _SEVEN or record.get("observations") != {}:
        raise ModelContextError("MODEL_CONTEXT_INVALID")
    try:
        values = validate_model_parameters(parameters)
        name = record["display_label"]
        if not isinstance(name, str) or not 1 <= len(name) <= 80:
            raise ValueError
        profile = {"name": name, **values, **_DEFAULTS}
        legacy_default_source = "livemore:type-2-diabetes" if stratum == "nhanes-diagnosed-diabetes-older" else "livemore:healthy-adult"
        provenance = {field: {"evidence_class": "REFERENCE_INITIALIZED", "source_id": source_id if field in _SEVEN else legacy_default_source,
                              "value": value, "unit": _PARAMETER_UNITS[field],
                              "reason": "frozen research population parameter" if field in _SEVEN else "unmeasured engine parameter; literature-typical reference prior"}
                      for field, value in profile.items() if field != "name"}
        subject_id = record["subject_id"]
        if not isinstance(subject_id, str) or not subject_id.startswith("pseudonym-"):
            raise ValueError
        return ResolvedModelContext(_encoded(profile), _encoded(provenance), hashlib.sha256(_encoded(record)).hexdigest(), subject_id)
    except (ValueError, TypeError, KeyError) as error:
        raise ModelContextError("MODEL_CONTEXT_INVALID") from error


def model_availability(record: dict[str, Any] | None, *, source_generation: str,
                       selection_mode: str = "model") -> dict[str, Any]:
    reason = None
    if record is not None and (record.get("source_class") != "SYNTHETIC" or is_public_reference(record) or is_public_reference(record.get("reference"))):
        try:
            resolve_model_context(record)
        except ModelContextError as error:
            reason = error.code
    return {"schema": "livemore.model-availability.v1", "state": "UNAVAILABLE" if reason else "READY",
            "reason_code": reason, "selection_mode": "observations_only" if reason else ("reference_preview" if record is None else selection_mode),
            "twin_id": record.get("twin_id") if record else None,
            "twin_version": record["version"] if record else 0,
            "source_generation": source_generation, "preparation_available": reason is None}
