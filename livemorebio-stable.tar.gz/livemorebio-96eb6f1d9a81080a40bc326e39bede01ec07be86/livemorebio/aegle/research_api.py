"""Authenticated research routes shared by browser, SDK and terminal clients."""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
import sqlite3
from typing import Any, Callable, Coroutine

from fastapi import APIRouter, Request
from fastapi.exception_handlers import http_exception_handler
from fastapi.responses import HTMLResponse, JSONResponse, Response
from fastapi.routing import APIRoute
from starlette.exceptions import HTTPException

from ..research import ResearchError, ResearchService, ResearchStore, biology_curriculum
from ..security import require_operator_auth, patch_storage_key
from ..strict_json import MAX_JSON_BYTES, StrictJSONError, parse_json_object

class ResearchRoute(APIRoute):
    """Research metadata and authorization failures are never cacheable."""

    def get_route_handler(self) -> Callable[[Request], Coroutine[Any, Any, Response]]:
        handler = super().get_route_handler()

        async def no_store(request: Request) -> Response:
            try:
                response = await handler(request)
            except HTTPException as error:
                response = await http_exception_handler(request, error)
            response.headers["Cache-Control"] = "no-store"
            return response

        return no_store


router = APIRouter(route_class=ResearchRoute)


def service() -> ResearchService:
    from .. import registry
    path = os.getenv("LIVEMORE_RESEARCH_STORE", str(Path(registry.REG_DIR) / "research.sqlite3"))
    try:
        key = patch_storage_key(create=True)
    except RuntimeError as error:
        raise OSError("research encryption configuration is unavailable") from error
    if key is None:
        raise OSError("research encryption configuration is unavailable")
    return ResearchService(ResearchStore(Path(path), key=key))


async def body(request: Request) -> dict:
    raw = bytearray()
    async for chunk in request.stream():
        raw.extend(chunk)
        if len(raw) > MAX_JSON_BYTES:
            raise ResearchError("request exceeds 2 MB")
    try:
        return parse_json_object(raw)
    except StrictJSONError as error:
        raise ResearchError(str(error)) from error


def failure(error: Exception) -> JSONResponse:
    if isinstance(error, ResearchError):
        return JSONResponse({"error": str(error), "code": "RESEARCH_INPUT_INVALID"}, status_code=422)
    return JSONResponse({"error": "Research storage is temporarily unavailable", "code": "RESEARCH_STORAGE_UNAVAILABLE"}, status_code=503)


@router.get("/research", response_class=HTMLResponse)
def research_page():
    return HTMLResponse((Path(__file__).parent / "console" / "research.html").read_text(), headers={"Cache-Control": "no-store"})


@router.get("/api/research/overview")
def overview(request: Request):
    require_operator_auth(request)
    try:
        return {"records": service().store.list(), "curriculum": biology_curriculum(),
                "physical_validation": "No physical instrument authenticity or human equivalence has been established by this software."}
    except (ResearchError, sqlite3.Error, OSError) as error:
        return failure(error)


@router.get("/api/research/records/{record_id}")
def record(record_id: str, request: Request):
    require_operator_auth(request)
    try:
        result = service().store.get(record_id)
        # Raw data are available only through an explicit export request.
        return {k: v for k, v in result.items() if k != "raw_csv"}
    except (ResearchError, sqlite3.Error, OSError) as error:
        return failure(error)


@router.get("/api/research/records/{record_id}/export.json")
def export_record(record_id: str, request: Request):
    require_operator_auth(request)
    try:
        result = service().store.get(record_id)
        return Response(json.dumps(result, indent=2, allow_nan=False), media_type="application/json",
                        headers={"Content-Disposition": f'attachment; filename="{record_id}.json"', "Cache-Control": "no-store"})
    except (ResearchError, sqlite3.Error, OSError) as error:
        return failure(error)


@router.post("/api/research/studies", status_code=201)
async def freeze(request: Request):
    require_operator_auth(request)
    from .server import _protocol_run_store
    from ..cendos.protocol_runs import ProtocolRunNotFound
    try:
        payload = await body(request)
        def store_study() -> dict:
            run = _protocol_run_store().get(str(payload.pop("run_id", "")))
            return service().freeze(run, payload)
        return await asyncio.to_thread(store_study)
    except ProtocolRunNotFound:
        return failure(ResearchError("Select an existing frozen Cendos run"))
    except (ResearchError, sqlite3.Error, OSError) as error:
        return failure(error)


@router.post("/api/research/studies/{study_id}/measurements", status_code=201)
async def admit(study_id: str, request: Request):
    require_operator_auth(request)
    try:
        payload = await body(request)
        result = await asyncio.to_thread(lambda: service().admit_measurement(study_id, payload))
        return {k: v for k, v in result.items() if k != "raw_csv"}
    except (ResearchError, sqlite3.Error, OSError) as error:
        return failure(error)


@router.post("/api/research/studies/{study_id}/compare")
async def compare(study_id: str, request: Request):
    require_operator_auth(request)
    try:
        payload = await body(request)
        return await asyncio.to_thread(lambda: service().compare(study_id, payload.get("measurement_id")))
    except (ResearchError, sqlite3.Error, OSError) as error:
        return failure(error)


@router.post("/api/research/resilience", status_code=201)
async def resilience(request: Request):
    require_operator_auth(request)
    try:
        payload = await body(request)
        return await asyncio.to_thread(lambda: service().register_resilience(payload))
    except (ResearchError, sqlite3.Error, OSError) as error:
        return failure(error)


@router.post("/api/research/resilience/{protocol_id}/assess")
async def assess(protocol_id: str, request: Request):
    require_operator_auth(request)
    try:
        payload = await body(request)
        return await asyncio.to_thread(lambda: service().assess_resilience(protocol_id, payload.get("measurement_ids", [])))
    except (ResearchError, sqlite3.Error, OSError) as error:
        return failure(error)


@router.post("/api/research/learning", status_code=201)
async def learn(request: Request):
    require_operator_auth(request)
    try:
        payload = await body(request)
        return await asyncio.to_thread(lambda: service().record_learning(payload))
    except (ResearchError, sqlite3.Error, OSError) as error:
        return failure(error)


@router.get("/api/research/sources/{source}/{identifier}")
def reference_context(source: str, identifier: str, request: Request):
    require_operator_auth(request)
    from ..life_system.reference.sources import get_disease_context
    try:
        return JSONResponse(get_disease_context(source, identifier), headers={"Cache-Control": "no-store"})
    except ValueError:
        return failure(ResearchError("source or disease identifier is invalid"))
    except OSError as error:
        return failure(error)


@router.post("/api/research/sources/import", status_code=201)
async def import_reference(request: Request):
    require_operator_auth(request)
    from ..life_system.reference.sources import LicensedReferenceStore
    try:
        payload = await body(request)
        if not isinstance(payload.get("manifest"), dict) or not isinstance(payload.get("records"), list):
            raise ResearchError("reference import requires manifest object and records array")
        return await asyncio.to_thread(lambda: LicensedReferenceStore().import_records(payload["manifest"], payload["records"]))
    except ValueError:
        return failure(ResearchError("licensed release failed manifest, permission, expiry or integrity validation; review the local import guide"))
    except OSError as error:
        return failure(error)
