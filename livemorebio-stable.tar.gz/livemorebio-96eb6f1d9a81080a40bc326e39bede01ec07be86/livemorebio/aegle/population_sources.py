"""Pinned public statistical source admission. Never enrolls or identifies people.

All cache roots are explicit caller inputs. Import/status never downloads data.
Source files and returned verified bytes are sensitive local research inputs;
only source_status/source_manifest are suitable public metadata projections.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tempfile
import time
from typing import TYPE_CHECKING, Any, Iterator
import urllib.request

if TYPE_CHECKING:
    from pandas import DataFrame

SOURCE_ID = "nhanes-2021-2023-joint-public-v1"
BASE_URL = "https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/"
USE_URL = "https://www.cdc.gov/nchs/policy/data-user-agreement.html"


class PopulationSourceError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


@dataclass(frozen=True)
class SourceArtifact:
    filename: str
    url: str
    sha256: str
    size: int
    columns: tuple[str, ...] = ()
    rows: int = 0


# Observed official bytes, 2026-09-08. Updates require a new reviewed source version.
_TABLES = (
    ("DEMO_L", "ca4374a158b493b8b0163e1388da21d57a18d1b9cecff2aa4e2fa2bec494fe23", 2582160, 11933,
     "SEQN SDDSRVYR RIDSTATR RIAGENDR RIDAGEYR RIDAGEMN RIDRETH1 RIDRETH3 RIDEXMON RIDEXAGM DMQMILIZ DMDBORN4 DMDYRUSR DMDEDUC2 DMDMARTZ RIDEXPRG DMDHHSIZ DMDHRGND DMDHRAGZ DMDHREDZ DMDHRMAZ DMDHSEDZ WTINT2YR WTMEC2YR SDMVSTRA SDMVPSU INDFMPIR",
     "d85d99207a3f03345f1f16223537005bc85b9ea3a67e84c8f0543aaf89d43975", 88008),
    ("BMX_L", "44440c416d9ad709e8b1708a5975378ab4d5b18edc39eb5015c2ae7186500170", 1563200, 8860,
     "SEQN BMDSTATS BMXWT BMIWT BMXRECUM BMIRECUM BMXHEAD BMIHEAD BMXHT BMIHT BMXBMI BMDBMIC BMXLEG BMILEG BMXARML BMIARML BMXARMC BMIARMC BMXWAIST BMIWAIST BMXHIP BMIHIP",
     "1d10934773f995bf994cca2f3e1de1e7bd2901f79c519b3faa88c1e3d4eaa18c", 53617),
    ("GLU_L", "70f773ab37e3d8485341f32137e280e05b9279e5fe9b6f0362e4052d8fe9a201", 129200, 3996,
     "SEQN WTSAF2YR LBXGLU LBDGLUSI", "737169f95a63beb8fb4c7f44c596b31f2c6b0229637c1993d1d9ce2c0874c138", 21004),
    ("INS_L", "cdbf53b644805e5e67725c81ee32048dad3c06687689435b042a7a144cb9ec65", 161280, 3996,
     "SEQN WTSAF2YR LBXIN LBDINSI LBDINLC", "25996f3d615d5dfc58fd39283157f155807a63a772c3ef6060adb2e59c95ef71", 21258),
    ("GHB_L", "67aee0353160e2392dc0a33bece99b90764a630c76d82415ac4639105ad9dd03", 174000, 7199,
     "SEQN WTPH2YR LBXGH", "c65e1cec9596ff6b6db9719278400b82e25f30416653adc54ecf2c5cf96ccd53", 20158),
    ("DIQ_L", "9535a023673ae869afae19d842d8679e06f6a464606ac15900686b41ef05090f", 847600, 11744,
     "SEQN DIQ010 DID040 DIQ160 DIQ180 DIQ050 DID060 DIQ060U DIQ070", "cfc823723f5e37039b39108a614513d6c1f210f30f885a45d6a4ea07a718896a", 32437),
    ("RXQ_RX_L", "b801ca006aa8b505f597c4b28221e6f8c8b033781f214c16d45a114c5b564211", 287600, 11933,
     "SEQN RXQ033 RXQ050", "e5168fd63f837366a59f1bb4e5d027f29670038f2a9a219230b1dc0f9571c729", 14383),
)
ARTIFACTS = tuple(item for name, digest, size, rows, columns, doc_digest, doc_size in _TABLES for item in (
    SourceArtifact(name + ".xpt", BASE_URL + name + ".xpt", digest, size, tuple(columns.split()), rows),
    SourceArtifact(name + ".htm", BASE_URL + name + ".htm", doc_digest, doc_size),
))


def source_manifest() -> dict[str, Any]:
    return {"schema": "livemore.population-source.v1", "source_id": SOURCE_ID,
            "release": "NHANES August 2021-August 2023", "reviewed_at": "2026-09-08",
            "permitted_use": "statistical_research", "data_use_url": USE_URL,
            "identity_linking": False, "physical_device_association": False,
            "model_binding_available": False,
            "artifacts": {a.filename: {"url": a.url, "sha256": a.sha256,
                          "size_bytes": a.size, "columns": list(a.columns), "rows": a.rows}
                          for a in ARTIFACTS}}


def manifest_hash() -> str:
    return hashlib.sha256(json.dumps(source_manifest(), sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _safe_directory(path: Path, *, create: bool = False) -> None:
    if not path.is_absolute():
        raise PopulationSourceError("UNSAFE_SOURCE_CACHE", "Source cache requires an absolute private directory")
    if create and not path.exists() and not path.is_symlink():
        path.mkdir(parents=True, mode=0o700, exist_ok=True)
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) & 0o077:
        raise PopulationSourceError("UNSAFE_SOURCE_CACHE", "Source cache is not owner-private")


@contextmanager
def _lock(root: Path, *, exclusive: bool = False) -> Iterator[None]:
    flags = (os.O_RDWR | os.O_CREAT if exclusive else os.O_RDONLY) | os.O_NOFOLLOW
    fd = os.open(root / ".source.lock", flags, 0o600)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) & 0o077 or info.st_nlink != 1:
            raise PopulationSourceError("UNSAFE_SOURCE_CACHE", "Source lock is not owner-private")
        deadline = time.monotonic() + 2
        while True:
            try:
                fcntl.flock(fd, (fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH) | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise PopulationSourceError("SOURCE_BUSY", "Source admission is in progress") from None
                time.sleep(.025)
        yield
    finally:
        os.close(fd)


def _package(root: Path) -> Path:
    return root / (SOURCE_ID + "-" + manifest_hash()[:16])


def _read_private(path: Path, maximum: int) -> bytes:
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) & 0o077 or info.st_nlink != 1 or info.st_size > maximum:
            raise PopulationSourceError("UNSAFE_SOURCE_CACHE", "Source artifact is not a bounded owner-private file")
        return stream.read(maximum + 1)


def _restore_transport_zeros(table: DataFrame, data: bytes, fields: list[dict[str, Any]], *,
                             record_start: int, record_length: int) -> None:
    """Restore the exact all-zero IBM representation, never a numeric tolerance.

    SAS TS-140 pp20–21 checks both IBM words before exponent conversion. pandas
    2.3.3 omits that branch. Original bytes determine correction, so a legitimate
    tiny mantissa, SAS missing marker, or character zero bytes are untouched.
    """
    try:
        if (not isinstance(data, bytes) or type(record_start) is not int or record_start < 0 or
                type(record_length) is not int or record_length <= 0 or
                record_start + len(table) * record_length > len(data) or len(fields) != len(table.columns)):
            raise ValueError("bounds")
        layouts = []
        names = []
        offset = 0
        for field in fields:
            name = field["name"].decode("ascii")
            width, position, kind = field["field_length"], field["npos"], field["ntype"]
            if (type(width) is not int or width <= 0 or type(position) is not int or position != offset or
                    kind not in ("numeric", "char") or (kind == "numeric" and not 2 <= width <= 8)):
                raise ValueError("field")
            names.append(name)
            layouts.append((position, width, kind))
            offset += width
        if offset != record_length or len(set(names)) != len(names) or tuple(names) != tuple(table.columns):
            raise ValueError("alignment")
    except Exception:
        raise PopulationSourceError("INVALID_SOURCE_SCHEMA", "Transport field metadata or row boundaries are invalid") from None
    # Validate every layout before touching any decoded cell. Positional indexing
    # is deliberate: a DataFrame label need not equal its physical record number.
    for column, (position, width, kind) in enumerate(layouts):
        if kind != "numeric":
            continue
        zeros = []
        for row in range(len(table)):
            start = record_start + row * record_length + position
            if data[start:start + width] == bytes(width):
                zeros.append(row)
        if zeros:
            table.iloc[zeros, column] = 0.0


def _parse_xpt(artifact: SourceArtifact, data: bytes) -> DataFrame:
    if not data.startswith(b"HEADER RECORD*******LIBRARY HEADER RECORD!!!!!!!"):
        raise PopulationSourceError("INVALID_SOURCE_FORMAT", "Source is not SAS XPORT data")
    try:
        import pandas as pd
    except ImportError:
        raise PopulationSourceError("SOURCE_PARSER_UNAVAILABLE", "Install the reviewed pandas dependency before source admission") from None
    try:
        with pd.read_sas(io.BytesIO(data), format="xport", compression=None, iterator=True) as reader:
            table = reader.read()
            fields, record_start, record_length = reader.fields, reader.record_start, reader.record_length
        if tuple(table.columns) != artifact.columns or len(table) != artifact.rows:
            raise ValueError("schema")
        ids = table["SEQN"]
        if ids.isna().any() or not ids.is_unique or (ids <= 0).any() or (ids != ids.astype("int64")).any():
            raise ValueError("keys")
        _restore_transport_zeros(table, data, fields, record_start=record_start, record_length=record_length)
        return table
    except Exception:
        raise PopulationSourceError("INVALID_SOURCE_SCHEMA", "Source schema, row count or unique linkage keys do not match the reviewed release") from None


def _inspect_artifact(artifact: SourceArtifact, data: bytes) -> int:
    if artifact.columns:
        return len(_parse_xpt(artifact, data))
    name = artifact.filename.removesuffix(".htm").encode()
    if (b"<title>" + name + b"</title>" not in data or
            b"Data File: " + name + b".xpt" not in data or
            b"August 2021-August 2023 Data Documentation, Codebook, and Frequencies" not in data):
        raise PopulationSourceError("INVALID_SOURCE_FORMAT", "Source documentation does not match its reviewed codebook")
    return 0


def _verify_payload(artifact: SourceArtifact, data: bytes) -> None:
    if len(data) != artifact.size or hashlib.sha256(data).hexdigest() != artifact.sha256:
        raise PopulationSourceError("SOURCE_INTEGRITY_FAILURE", "Source artifact integrity does not match the frozen manifest")
    _inspect_artifact(artifact, data)


def validate_source_files(files: dict[str, bytes]) -> None:
    if set(files) != {a.filename for a in ARTIFACTS}:
        raise PopulationSourceError("SOURCE_INCOMPLETE", "The complete reviewed source package is required")
    for artifact in ARTIFACTS:
        _verify_payload(artifact, files[artifact.filename])


def _read_package(root: Path) -> dict[str, bytes]:
    package = _package(root)
    _safe_directory(package)
    receipt = _read_private(package / "receipt.json", 100000)
    expected = {"schema": "livemore.population-source-receipt.v1", "manifest_sha256": manifest_hash(), "accepted_use": "statistical_research"}
    if receipt != json.dumps(expected, sort_keys=True, separators=(",", ":")).encode():
        raise PopulationSourceError("SOURCE_INTEGRITY_FAILURE", "Source receipt does not match the frozen manifest")
    files = {a.filename: _read_private(package / a.filename, a.size) for a in ARTIFACTS}
    validate_source_files(files)
    return files


def verified_source_files(cache_root: str | Path) -> dict[str, bytes]:
    """Return private verified bytes, never paths or unchecked cached records."""
    root = Path(cache_root)
    try:
        _safe_directory(root)
        with _lock(root):
            return _read_package(root)
    except PopulationSourceError:
        raise
    except Exception:
        raise PopulationSourceError("SOURCE_UNAVAILABLE", "Verified reference source is unavailable") from None


def source_status(cache_root: str | Path) -> dict[str, Any]:
    root = Path(cache_root)
    metadata = {"source_id": SOURCE_ID, "manifest_sha256": manifest_hash(),
                "release": source_manifest()["release"], "available": False,
                "model_binding_available": False}
    try:
        if not root.is_absolute():
            raise PopulationSourceError("UNSAFE_SOURCE_CACHE", "Source cache requires an absolute private directory")
        if not root.exists() and not root.is_symlink():
            return {**metadata, "state": "missing"}
        _safe_directory(root)
        package = _package(root)
        if not (root / ".source.lock").exists() and not (root / ".source.lock").is_symlink():
            if not package.exists() and not package.is_symlink():
                return {**metadata, "state": "missing"}
        with _lock(root):
            if not package.exists() and not package.is_symlink():
                return {**metadata, "state": "missing"}
            _read_package(root)
        return {**metadata, "available": True, "state": "verified",
                "table_rows": {a.filename: a.rows for a in ARTIFACTS if a.columns}}
    except PopulationSourceError as error:
        state = {"UNSAFE_SOURCE_CACHE": "unsafe", "SOURCE_BUSY": "busy", "SOURCE_PARSER_UNAVAILABLE": "dependency_unavailable"}.get(error.code, "corrupt")
        return {**metadata, "state": state, "code": error.code, "reason": str(error)}
    except Exception:
        return {**metadata, "state": "corrupt", "reason": "Source package could not be verified"}


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *_args: Any, **_kwargs: Any) -> None:
        raise PopulationSourceError("SOURCE_DOWNLOAD_FAILED", "Unexpected source redirect requires review")


def _download(artifact: SourceArtifact) -> bytes:
    try:
        request = urllib.request.Request(artifact.url, headers={"User-Agent": "LivemoreBio-source-admission/1"})
        with urllib.request.build_opener(_NoRedirect()).open(request, timeout=60) as response:
            if response.status != 200 or response.geturl() != artifact.url:
                raise ValueError("response")
            if response.headers.get("Content-Length") and int(response.headers["Content-Length"]) != artifact.size:
                raise ValueError("length")
            return response.read(artifact.size + 1)
    except Exception:
        raise PopulationSourceError("SOURCE_DOWNLOAD_FAILED", "The pinned source download failed; existing admitted data is unchanged") from None


def install_source(cache_root: str | Path, *, accepted_use: str) -> dict[str, Any]:
    if accepted_use != "statistical_research":
        raise PopulationSourceError("SOURCE_USE_NOT_ACCEPTED", "Public reference data requires accepted statistical-research-only use")
    root = Path(cache_root)
    try:
        _safe_directory(root, create=True)
        with _lock(root, exclusive=True):
            target = _package(root)
            if target.exists() or target.is_symlink():
                _read_package(root)  # Never overwrite a changed prior admission.
            else:
                with tempfile.TemporaryDirectory(prefix=".source-stage-", dir=root) as temporary:
                    stage = Path(temporary)
                    for artifact in ARTIFACTS:
                        data = _download(artifact)
                        _verify_payload(artifact, data)
                        descriptor = os.open(stage / artifact.filename, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                        with os.fdopen(descriptor, "wb") as output:
                            output.write(data); output.flush(); os.fsync(output.fileno())
                    receipt = {"schema": "livemore.population-source-receipt.v1", "manifest_sha256": manifest_hash(), "accepted_use": accepted_use}
                    descriptor = os.open(stage / "receipt.json", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                    with os.fdopen(descriptor, "wb") as output:
                        output.write(json.dumps(receipt, sort_keys=True, separators=(",", ":")).encode()); output.flush(); os.fsync(output.fileno())
                    os.rename(stage, target)
        return source_status(root)
    except PopulationSourceError:
        raise
    except Exception:
        raise PopulationSourceError("SOURCE_ADMISSION_FAILED", "Source admission failed; existing admitted data is unchanged") from None
