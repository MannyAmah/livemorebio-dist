"""Aegle multiscale workspace projection and action lifecycle."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
import math
import uuid
from typing import Any

from ..multiscale import multiscale_state


class ActionStatus(str, Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


_TRANSITIONS = {
    ActionStatus.QUEUED: {ActionStatus.RUNNING, ActionStatus.FAILED},
    ActionStatus.RUNNING: {ActionStatus.COMPLETED, ActionStatus.FAILED},
    ActionStatus.COMPLETED: set(),
    ActionStatus.FAILED: set(),
}


def _finite_parameter(
    params: dict[str, Any], name: str, default: float, lower: float, upper: float,
) -> float:
    try:
        value = float(params.get(name, default))
    except (TypeError, ValueError) as error:
        raise ValueError(f"{name} must be numeric") from error
    if not math.isfinite(value) or value < lower or value > upper:
        raise ValueError(f"{name} must be finite and between {lower} and {upper}")
    return value


def validate_action_input(body: object) -> tuple[str, dict[str, Any]]:
    """Validate one workspace action for HTTP, SDK, CLI, and notebooks."""
    if not isinstance(body, dict):
        raise ValueError("request body must be a JSON object")
    kind = body.get("kind")
    params = body.get("params", {})
    if kind not in {"metabolic_drug", "meal", "cardiac_drug", "lifestyle", "reset"}:
        raise ValueError("unsupported workspace action")
    if not isinstance(params, dict):
        raise ValueError("params must be a JSON object")
    clean: dict[str, Any] = dict(params)
    if kind == "metabolic_drug":
        name = str(params.get("name", "metformin")).strip()
        if not name or len(name) > 80:
            raise ValueError("drug name must contain 1 to 80 characters")
        clean = {"name": name, "dose": _finite_parameter(params, "dose", 1.0, 0.001, 5.0)}
    elif kind == "meal":
        clean = {
            "grams": _finite_parameter(params, "grams", 60.0, 0.1, 500.0),
            "minute": int(_finite_parameter(params, "minute", 0.0, 0.0, 10080.0)),
        }
    elif kind == "cardiac_drug":
        clean = {"ikr_block": _finite_parameter(params, "ikr_block", 0.5, 0.0, 0.95)}
    elif kind == "lifestyle":
        clean = {
            "si_delta": _finite_parameter(params, "si_delta", 0.0, -0.95, 2.0),
            "gb_delta": _finite_parameter(params, "gb_delta", 0.0, -0.95, 2.0),
        }
    elif params:
        raise ValueError("reset does not accept parameters")
    return str(kind), clean


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass
class WorkspaceAction:
    kind: str
    subject_id: str
    parameters: dict[str, Any]
    action_id: str = field(default_factory=lambda: f"action-{uuid.uuid4().hex}")
    status: ActionStatus = ActionStatus.QUEUED
    created_at: str = field(default_factory=_now)
    updated_at: str = field(default_factory=_now)
    transitions: list[str] = field(default_factory=lambda: [ActionStatus.QUEUED.value])
    error_code: str | None = None
    evidence_refs: list[str] = field(default_factory=list)

    def transition(self, status: ActionStatus, *, error_code: str | None = None) -> None:
        if status not in _TRANSITIONS[self.status]:
            raise ValueError(f"invalid workspace action transition {self.status.value} -> {status.value}")
        self.status = status
        self.updated_at = _now()
        self.transitions.append(status.value)
        self.error_code = error_code

    def to_dict(self) -> dict[str, Any]:
        return {
            "action_id": self.action_id,
            "kind": self.kind,
            "subject_id": self.subject_id,
            "parameters": dict(self.parameters),
            "status": self.status.value,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "transitions": list(self.transitions),
            "error_code": self.error_code,
            "evidence_refs": list(self.evidence_refs),
        }


def preview_subject(base: str = "healthy") -> dict[str, Any]:
    """Reference initialization is not an admitted person or a stored twin."""
    return {
        "twin_id": None, "subject_id": None,
        "display_label": "Healthy reference preview" if base == "healthy" else f"{base} reference preview",
        "source_class": "REFERENCE_INITIALIZED", "lifecycle": "PREVIEW", "version": 0,
    }


def projection(
    twin: Any, actions: list[WorkspaceAction], subject: dict[str, Any] | None = None,
    *, snapshot: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a bounded, local-only read model for the A+B workspace."""
    from .. import bus, registry

    state = snapshot if snapshot is not None else twin.state()
    availability = state.get("model_availability")
    unavailable = availability is not None and availability["state"] == "UNAVAILABLE"
    registrations = registry.registry()
    qualified_measurement = bus.snapshot("cendos.latest-qualified-measurement")
    latest_qualification = bus.snapshot("cendos.latest-qualification")
    recent_events = bus.events(limit=12)
    products = {
        "aegle": {
            "connected": True,
            "role": "person_state_coupling_and_scenario_plane",
            "state": "OBSERVATIONS_ONLY" if unavailable else "EXECUTING",
            "href": "/",
        },
        "life": {
            "connected": "LIFE" in registrations,
            "registered": "LIFE" in registrations,
            "role": "measurement_and_device_data_plane",
            "state": "PACKET_ADMITTED_LINK_UNVERIFIED" if state["patch"]["connected"] else "AWAITING_TELEMETRY",
            "href": "/patch",
        },
        "cendos": {
            "connected": "Cendos" in registrations,
            "registered": "Cendos" in registrations,
            "role": "experiment_assay_evidence_and_verification_plane",
            "state": "QUALIFIED_MEASUREMENT_AVAILABLE" if qualified_measurement else "AWAITING_COUNTERPART",
            "href": "/cendos",
        },
        "biology": {
            "connected": True,
            "role": "multiscale_anatomy_and_mechanism_explorer",
            "state": "BOUND_TO_AEGLE",
            "href": "/biology",
        },
    }
    subject_projection = dict(subject or preview_subject(state.get("base", "healthy")))
    subject_projection.pop("observations", None)
    subject_projection.pop("genome", None)
    subject_projection.pop("chain_of_custody", None)
    if unavailable:
        from .clinical_views import unavailable_multiscale
        scales = unavailable_multiscale(subject_projection, availability)
    else:
        scales = multiscale_state(twin)
    return {
        "schema": "livemore.multiscale-workspace.v1",
        "generated_at": _now(),
        "release_claim": "modeled_context_specific_hypothesis_triage",
        "twin": state,
        "subject": subject_projection,
        "multiscale": scales,
        **({"model_availability": availability} if availability is not None else {}),
        "products": products,
        "cendos_translation": {
            "stages": [
                "digital_intervention",
                "multiscale_prediction",
                "counterpart_protocol",
                "qualified_measurement",
                "evidence_review",
                "context_release",
            ],
            "latest_qualified_measurement": qualified_measurement,
            "latest_qualification": latest_qualification,
            "calibration_authorized": False,
        },
        "actions": [item.to_dict() for item in actions[-30:]],
        "events": recent_events,
        "preserved_surfaces": ["/legacy", "/biology", "/patch", "/cendos", "/adapters"],
    }


__all__ = ["ActionStatus", "WorkspaceAction", "projection", "validate_action_input"]
