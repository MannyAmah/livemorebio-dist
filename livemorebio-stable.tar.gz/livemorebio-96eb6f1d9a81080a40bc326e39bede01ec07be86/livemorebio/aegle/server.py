"""Aegle server — serves the living-twin console and its reactive state API."""
from __future__ import annotations
import asyncio
from collections.abc import Callable
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import hmac
import json
import logging
import math
import os
import re
import secrets
import sqlite3
import threading
import urllib.error
import urllib.request
from types import ModuleType
from uuid import uuid4
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response, StreamingResponse
from .runtime import AegleTwin
from .model_source import ModelSourceAuthority, SourceGenerationConflict, SourceSelectionUnconfirmed
from .model_contexts import ModelContextError, model_availability
from .observation_state import ObservationState
from .workspace import ActionStatus, WorkspaceAction, validate_action_input, preview_subject
from .. import events
from ..build_info import build_identity
from ..security import (
    install_mutation_auth,
    require_operator_auth,
)

HERE = os.path.dirname(__file__)
logger = logging.getLogger(__name__)
app = FastAPI(title="Aegle — LivemoreBio living twin", version="0.0.1",
              description="Twin runtime + console. Readouts declare their data class and maturity; the local integrity audit is at /api/audit. OpenAPI at /openapi.json, docs at /docs.")
install_mutation_auth(app, session_document_paths=frozenset({
    "/", "/legacy", "/twins", "/cohorts", "/biology", "/patch", "/cendos", "/adapters", "/research",
}))
from .research_api import router as research_router
app.include_router(research_router)
from .execution_api import router as execution_router, shutdown_execution_manager
app.include_router(execution_router)
app.router.add_event_handler("shutdown", shutdown_execution_manager)
from .life_session_api import router as life_session_router
app.include_router(life_session_router)
from .reference_cohort_api import router as reference_cohort_router
app.include_router(reference_cohort_router)
_state = {
    "tw": None,
    "subject": None,
    "initialized": False,
    "observation_state": ObservationState(),
}
_patch_admission = None
_workspace_actions: list[WorkspaceAction] = []
_subject_registry_instance = None
_subject_registry_path = None
_protocol_run_store_instance = None
_protocol_run_store_path = None
_view_context_key = secrets.token_bytes(32)
_execution_manager_instance = None
_initialization_lock = threading.RLock()


def _invalidate_model_source(generation: str, reason: str) -> None:
    if _execution_manager_instance is not None:
        _execution_manager_instance.invalidate_source(generation, reason)


@contextmanager
def _model_fence_guard():
    from .execution_api import _creation_lock

    with _creation_lock:
        manager = _execution_manager_instance
        if manager is None:
            yield
        else:
            with manager._lock:
                yield


def _assign_model_fence(generation: str | object) -> None:
    if _execution_manager_instance is not None:
        _execution_manager_instance.set_source_generation(generation)


_model_source_authority = ModelSourceAuthority(
    _invalidate_model_source, fence=_assign_model_fence, fence_guard=_model_fence_guard,
)


@app.exception_handler(SourceSelectionUnconfirmed)
async def selection_unconfirmed_error(_request: Request, error: SourceSelectionUnconfirmed):
    return JSONResponse({"code": error.code, "error": str(error)}, status_code=503,
                        headers={"Cache-Control": "no-store"})


@app.exception_handler(SourceGenerationConflict)
async def source_generation_error(_request: Request, error: SourceGenerationConflict):
    return JSONResponse({"code": error.code, "error": str(error)}, status_code=409,
                        headers={"Cache-Control": "no-store", "X-Request-ID": str(uuid4())})


@app.exception_handler(ModelContextError)
async def model_context_error(_request: Request, error: ModelContextError):
    return JSONResponse({"code": error.code, "error": str(error)}, status_code=409,
                        headers={"Cache-Control": "no-store"})


def _model_availability() -> dict:
    generation = _model_source_authority.generation
    if _state["tw"] is None:
        # A caller may reach this before anything has restored the selected
        # state, in which case the key is simply absent. Report a fail-closed
        # availability rather than raising, which callers surfaced as an
        # unrelated storage failure.
        recorded = _state.get("model_availability")
        if recorded is None:
            recorded = {"schema": "livemore.model-availability.v1", "state": "UNAVAILABLE",
                        "reason_code": "MODEL_BINDING_REQUIRED", "selection_mode": "observations_only",
                        "twin_id": None, "twin_version": 0, "preparation_available": False}
        return {**recorded, "source_generation": generation}
    subject = _state.get("subject")
    return {"schema": "livemore.model-availability.v1", "state": "READY", "reason_code": None,
            "selection_mode": "model" if subject else "reference_preview",
            "twin_id": subject.get("twin_id") if subject else None,
            "twin_version": subject["version"] if subject else 0,
            "source_generation": generation, "preparation_available": True}


def _current_snapshot() -> dict:
    from .clinical_views import unavailable_state

    availability = _model_availability()
    twin = _state["tw"]
    if twin is None:
        return unavailable_state(availability, _state["observation_state"])
    return {**deepcopy(twin.state()), "model_availability": availability}


def _require_numerical_model() -> None:
    _ensure_selected_state()
    _assert_numerical_available()


def _assert_numerical_available() -> None:
    """Recheck under the source guard; never acquire the startup lock here."""
    availability = _model_availability()
    if availability["state"] != "READY":
        raise ModelContextError(availability["reason_code"])


def _require_matching_selected_record(record: dict | None) -> None:
    """Caller holds authority; a registry read cannot replace selected identity."""
    summary = _state.get("subject")
    if (not summary or record is None or record.get("lifecycle") != "ACTIVE"
            or any(record.get(field) != summary.get(field) for field in
                   ("twin_id", "subject_id", "source_class", "version"))):
        raise SourceGenerationConflict()


def _view_context_id(twin, snapshot: dict) -> str:
    """Opaque UI coherence token, not an identifier or scientific qualification."""
    payload = json.dumps([id(twin), snapshot], sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hmac.new(_view_context_key, payload.encode("utf-8"), hashlib.sha256).hexdigest()


class _RegistryKeyUnavailable(RuntimeError):
    """Preserve legacy storage catches while allowing narrow cohort errors."""


def _subject_registry():
    global _subject_registry_instance, _subject_registry_path
    from pathlib import Path
    from .. import registry
    from ..security import patch_storage_key
    from .subjects import SubjectRegistry

    path = os.environ.get("LIVEMORE_SUBJECT_REGISTRY", "").strip()
    if not path:
        path = os.path.join(registry.REG_DIR, "subjects.sqlite3")
    key = patch_storage_key(create=True)
    if key is None:
        raise _RegistryKeyUnavailable("subject registry encryption key is unavailable")
    if _subject_registry_instance is None or _subject_registry_path != path:
        _subject_registry_instance = SubjectRegistry(Path(path), key=key)
        _subject_registry_path = path
    return _subject_registry_instance


def _protocol_run_store():
    global _protocol_run_store_instance, _protocol_run_store_path
    from pathlib import Path
    from .. import registry
    from ..cendos.protocol_runs import ProtocolRunStore

    path = os.environ.get("LIVEMORE_PROTOCOL_RUNS", "").strip()
    if not path:
        path = os.path.join(registry.REG_DIR, "cendos-protocol-runs")
    if _protocol_run_store_instance is None or _protocol_run_store_path != path:
        _protocol_run_store_instance = ProtocolRunStore(Path(path))
        _protocol_run_store_path = path
    return _protocol_run_store_instance


def _subject_error(error):
    status = 404 if error.code == "RECORD_NOT_FOUND" else 409 if error.code in {
        "IDEMPOTENCY_CONFLICT", "TWIN_VERSION_CONFLICT", "PATCH_BINDING_CONFLICT", "DUPLICATE_SUBJECT",
    } else 422
    return JSONResponse({"error": str(error), "code": error.code}, status_code=status)


def _subject_summary(record: dict) -> dict:
    return {
        key: record[key] for key in (
            "twin_id", "subject_id", "display_label", "source_class", "lifecycle", "version",
        ) if key in record
    }


class _StartupRetirement:
    """Keep returned models and old payloads alive beyond the startup mutex."""

    def __init__(self) -> None:
        self.retained: list[object] = []
        self.generation: str | None = None
        self.snapshot: dict | None = None

    def finish(self) -> None:
        try:
            if self.generation is not None:
                try:
                    _invalidate_model_source(self.generation, "subject_restored")
                except Exception:
                    logger.warning("Aegle startup source cleanup is unconfirmed")
            if self.snapshot is not None:
                _snapshot_twin(self.snapshot)
        finally:
            self.retained.clear()


def _selected_state_initialized() -> bool:
    return _state.get("initialized", _state.get("tw") is not None or _state.get("subject") is not None)


def _restore_selected_state(retirement: _StartupRetirement) -> bool:
    """Caller owns only the initialization mutex during model construction."""
    global _state, _workspace_actions
    from .clinical_views import unavailable_state
    from .execution import DENY_ALL

    with _model_source_authority.observation():
        previous_generation = _model_source_authority.permitted_generation
        initialized = _selected_state_initialized()
    if previous_generation is DENY_ALL:
        with _model_source_authority.commit_guard():
            if (_model_source_authority.permitted_generation is DENY_ALL
                    and _selected_state_initialized() is initialized):
                _state["initialized"] = True
        return False

    # Allocate the fail-closed view before the final guard; uncertainty is not an
    # invented model-unavailability reason or evidence that no person is selected.
    failed_state = {"tw": None, "subject": None, "initialized": True,
                    "observation_state": ObservationState()}
    empty_actions: list[WorkspaceAction] = []
    try:
        registry = _subject_registry()
        with _model_source_authority.observation():
            if (_model_source_authority.permitted_generation != previous_generation
                    or _selected_state_initialized() is not initialized):
                return False
            captured = registry.audited_active_twin(action="inspect", request_id=str(uuid4()),
                                                    _checked_snapshot=True)
        record = captured.record
        generation = uuid4().hex
        availability = model_availability(record, source_generation=generation)
        candidate = None
        if availability["state"] == "READY":
            try:
                candidate = AegleTwin("healthy") if record is None else registry.build_twin(record)
                if candidate is None:
                    raise ValueError("Startup model construction returned no model")
            except ModelContextError as error:
                if record is None:
                    raise
                availability.update(state="UNAVAILABLE", reason_code=error.code,
                                    selection_mode="observations_only", preparation_available=False)
            if candidate is not None:
                retirement.retained.append(candidate)
        observed = ObservationState()
        snapshot = deepcopy(candidate.state()) if candidate is not None else unavailable_state(availability, observed)
        if (not isinstance(snapshot, dict) or "profile_params" not in snapshot
                or snapshot["profile_params"] is not None and not isinstance(snapshot["profile_params"], dict)):
            raise ValueError("Invalid prepared startup projection")
        snapshot["model_availability"] = deepcopy(availability)
        selected_state = {"tw": candidate, "subject": _subject_summary(record) if record else None,
                          "initialized": True, "observation_state": observed, "model_availability": availability}
        confirmation_id = str(uuid4())
        with _model_source_authority.commit_guard():
            if (_model_source_authority.permitted_generation != previous_generation
                    or _selected_state_initialized() is not initialized):
                return False
            retirement.retained.extend((_state, _workspace_actions))
            registry.confirm_active_selection(expected_record=record, request_id=confirmation_id,
                                              _expected_snapshot=captured)
            _model_source_authority.install_generation(generation)
            _state = selected_state
            _workspace_actions = empty_actions
            retirement.generation = previous_generation
            retirement.snapshot = snapshot
        return record is not None
    except Exception:
        with _model_source_authority.commit_guard():
            if (_model_source_authority.permitted_generation != previous_generation
                    or _selected_state_initialized() is not initialized):
                return False
            retirement.retained.extend((_state, _workspace_actions))
            _model_source_authority.install_generation(DENY_ALL)
            _state = failed_state
            _workspace_actions = empty_actions
            retirement.generation = previous_generation
        logger.error("Aegle active-subject restoration is unconfirmed")
        return False


def _restore_active_subject() -> bool:
    """Explicit checked restoration, including already-initialized callers."""
    retirement = _StartupRetirement()
    try:
        with _initialization_lock:
            return _restore_selected_state(retirement)
    finally:
        retirement.finish()


def _ensure_selected_state() -> None:
    """Restore once; only checked true absence permits a healthy reference."""
    retirement = _StartupRetirement()
    try:
        with _initialization_lock:
            if not _selected_state_initialized():
                _restore_selected_state(retirement)
    finally:
        retirement.finish()


@app.get("/", response_class=HTMLResponse)
def index():
    with open(os.path.join(HERE, "console", "workspace.html"), encoding="utf-8") as f:
        return HTMLResponse(f.read(), headers={"Cache-Control": "no-store, max-age=0"})


@app.get("/legacy", response_class=HTMLResponse)
def legacy_console():
    """Preserve the previous Aegle console during the workspace rollout."""
    with open(os.path.join(HERE, "console", "index.html"), encoding="utf-8") as f:
        return HTMLResponse(f.read(), headers={"Cache-Control": "no-store, max-age=0"})


@app.get("/twins", response_class=HTMLResponse)
def twins_console():
    with open(os.path.join(HERE, "console", "twins.html"), encoding="utf-8") as stream:
        return HTMLResponse(stream.read(), headers={"Cache-Control": "no-store, max-age=0"})


@app.get("/cohorts", response_class=HTMLResponse)
def cohorts_console():
    with open(os.path.join(HERE, "console", "cohorts.html"), encoding="utf-8") as stream:
        return HTMLResponse(stream.read(), headers={"Cache-Control": "no-store, max-age=0"})


@app.get("/health")
def health(req: Request):
    return {"service": "Aegle", "ok": True, "port": (req.scope.get("server") or (None, None))[1],
            "build": build_identity()}


@app.get("/api/build")
def api_build():
    return JSONResponse(build_identity(), headers={"Cache-Control": "no-store"})


@app.get("/api/session/bootstrap", status_code=410)
def bootstrap_local_session(req: Request):
    """Old tabs must navigate explicitly; never replay or bootstrap a request."""
    return JSONResponse(
        {"error": "Reopen this local console document to restore authorization."},
        status_code=410, headers={"Cache-Control": "no-store"},
    )


@app.get("/api/state")
def get_state(req: Request):
    require_operator_auth(req)
    _ensure_selected_state()
    with _model_source_authority.observation():
        twin = _state["tw"]
        # Detach nested lists/dicts from a concurrently changing runtime before hashing.
        snapshot = _current_snapshot()
        return JSONResponse({**snapshot, "context_id": _view_context_id(twin, snapshot)})


@app.get("/api/workspace")
def get_workspace(req: Request):
    """Authenticated cross-product read projection for the A+B workspace."""
    require_operator_auth(req)
    from .workspace import projection

    payload = _workspace_projection()
    return JSONResponse(payload, status_code=503 if payload.get("code") == "WORKSPACE_CONTEXT_CHANGED" else 200)


def _workspace_projection() -> dict:
    from .workspace import projection
    from ..life_patch.observation_view import observation_channel

    _ensure_selected_state()
    with _model_source_authority.observation():
        twin = _state["tw"]
        snapshot = _current_snapshot()
        before = _view_context_id(twin, snapshot)
        payload = projection(twin, _workspace_actions, _state.get("subject"), snapshot=snapshot)
        observations = snapshot.get("observations", {})
        channels = [observation_channel(signal, item) for signal, item in observations.items()]
        after = _view_context_id(twin, _current_snapshot())
        if before != after or twin is not _state["tw"]:
            return {"code": "WORKSPACE_CONTEXT_CHANGED", "error": "Biological state changed during inspection; retry."}
        return {**payload, "context_id": after, "observation_channels": channels}


@app.get("/api/workspace/stream")
async def stream_workspace(req: Request, once: bool = False):
    """Emit bounded read-only workspace projections as server-sent events."""
    require_operator_auth(req)
    from .workspace import projection

    async def generate():
        sequence = int(datetime.now(timezone.utc).timestamp() * 1000)
        while True:
            payload = _workspace_projection()
            encoded = json.dumps(payload, separators=(",", ":"), allow_nan=False)
            yield f"id: {sequence}\nevent: workspace\ndata: {encoded}\n\n"
            if once:
                return
            sequence += 1
            await asyncio.sleep(1.0)

    return StreamingResponse(generate(), media_type="text/event-stream", headers={
        "Cache-Control": "no-store", "X-Accel-Buffering": "no",
    })


@app.get("/api/twins")
def list_twins(req: Request, limit: int = 25, cursor: str | None = None, q: str = ""):
    require_operator_auth(req)
    _ensure_selected_state()
    from .subjects import SubjectRegistryError
    from .execution import DENY_ALL
    try:
        page = _subject_registry().page_records("TWIN", limit=limit, cursor=cursor, q=q)
        with _model_source_authority.observation():
            uncertain = _model_source_authority.permitted_generation is DENY_ALL
            active = None if uncertain else (_state.get("subject") or preview_subject(_current_snapshot()["base"]))
            return JSONResponse({"twins": page["records"], "pagination": page["pagination"],
                                 "active": active, "selection_status": "UNCONFIRMED" if uncertain else "CONFIRMED"},
                                headers={"Cache-Control": "no-store"})
    except SubjectRegistryError as error:
        return _subject_error(error)


@app.post("/api/twins", status_code=201)
async def create_twin(req: Request):
    from .subjects import SubjectRegistryError

    try:
        body = await req.json()
        result = _subject_registry().create_twin(
            body, idempotency_key=req.headers.get("Idempotency-Key"),
        )
        return JSONResponse(result, status_code=201)
    except (json.JSONDecodeError, TypeError):
        return JSONResponse({"error": "request body must be valid JSON", "code": "INVALID_TWIN_DATA"}, status_code=400)
    except SubjectRegistryError as error:
        return _subject_error(error)


@app.get("/api/twins/{twin_id}")
def get_twin(twin_id: str, req: Request):
    require_operator_auth(req)
    from .subjects import SubjectRegistryError

    try:
        return JSONResponse(_subject_registry().get_twin(twin_id))
    except SubjectRegistryError as error:
        return _subject_error(error)


@app.post("/api/twins/{twin_id}/activate")
async def activate_twin(twin_id: str, req: Request):
    global _state, _workspace_actions
    from .execution import DENY_ALL
    from .subjects import SubjectRegistryError
    from ..strict_json import MAX_SAFE_INTEGER

    require_operator_auth(req)
    request_id = str(uuid4())
    headers = {"Cache-Control": "no-store", "X-Request-ID": request_id}
    retired: list[object] = []
    try:
        body = await _selection_payload(req)
        if (set(body) != {"expected_version"} or type(body["expected_version"]) is not int
                or not 1 <= body["expected_version"] < MAX_SAFE_INTEGER):
            raise SubjectRegistryError("INVALID_TWIN_DATA", "Activation requires exactly one safely incrementable integer expected_version.")
        registry = _subject_registry()
        with _model_source_authority.observation():
            previous_generation = _model_source_authority.generation
            prepared = registry.prepare_activation(twin_id, expected_version=body["expected_version"],
                                                   request_id=request_id)
            active_before = prepared.active_before
            if _state.get("subject") is not None or active_before is not None:
                _require_matching_selected_record(active_before)

        record = prepared.record
        generation = uuid4().hex
        availability = model_availability(record, source_generation=generation)
        if availability["state"] != "READY":
            raise ModelContextError(availability["reason_code"])
        candidate = registry.build_twin(record)
        retired.append(candidate)
        snapshot = deepcopy(candidate.state())
        if (not isinstance(snapshot, dict) or "profile_params" not in snapshot
                or snapshot["profile_params"] is not None and not isinstance(snapshot["profile_params"], dict)):
            raise ValueError("Invalid prepared selection projection")
        snapshot["model_availability"] = deepcopy(availability)
        selected_state = {"tw": candidate, "subject": _subject_summary(record), "initialized": True,
                          "observation_state": ObservationState(), "model_availability": availability}
        empty_actions: list[WorkspaceAction] = []
        success = JSONResponse(record, headers=headers)
        uncertain = JSONResponse({"code": "SELECTION_COMMIT_UNCONFIRMED",
            "error": "Selection storage outcome is unconfirmed; reconcile before numerical use."},
            status_code=503, headers=headers)
        cleanup_failed = JSONResponse({"code": "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED",
            "error": "Selection committed, but resource cleanup is unconfirmed. Inspect before continuing."},
            status_code=503, headers=headers)
        outcome = "COMMITTED"
        with _model_source_authority.commit_guard():
            if _model_source_authority.generation != previous_generation:
                raise SourceGenerationConflict()
            if _state.get("subject") is not None or active_before is not None:
                _require_matching_selected_record(active_before)
            # Keep the previous model/action owners alive through the complete
            # commit interval, including the fail-closed uncertainty branch.
            retired.extend((_state, _workspace_actions))
            try:
                outcome = registry.commit_prepared_transition(prepared)
            except SubjectRegistryError as error:
                if error.code != "SELECTION_COMMIT_UNCONFIRMED":
                    raise
                outcome = "UNCONFIRMED"
            if outcome not in {"COMMITTED", "COMMITTED_CLEANUP_UNCONFIRMED"}:
                _model_source_authority.install_generation(DENY_ALL)
            else:
                _model_source_authority.install_generation(generation)
            _state = selected_state
            _workspace_actions = empty_actions

        try:
            _invalidate_model_source(previous_generation, "subject_changed")
        except Exception:
            if outcome == "COMMITTED":
                outcome = "COMMITTED_CLEANUP_UNCONFIRMED"
        if outcome not in {"COMMITTED", "COMMITTED_CLEANUP_UNCONFIRMED"}:
            return uncertain
        _snapshot_twin(snapshot)
        return success if outcome == "COMMITTED" else cleanup_failed
    except (ModelContextError, SourceGenerationConflict, SourceSelectionUnconfirmed):
        raise
    except SubjectRegistryError as error:
        response = (JSONResponse({"code": error.code, "error": str(error)}, status_code=503)
                    if error.code in {"REGISTRY_STORAGE_UNAVAILABLE", "REGISTRY_AUDIT_UNAVAILABLE",
                                      "SELECTION_COMMIT_UNCONFIRMED"}
                    else _subject_error(error))
        response.headers.update(headers)
        return response
    except Exception:
        return JSONResponse({"code": "REGISTRY_STORAGE_UNAVAILABLE",
            "error": "Selection could not be prepared or confirmed. Inspect current state before continuing."},
            status_code=503, headers=headers)
    finally:
        retired.clear()


@app.post("/api/twins/{twin_id}/select-observations")
async def select_twin_observations(twin_id: str, req: Request):
    """Select admitted evidence without inventing a numerical human context."""
    global _state, _workspace_actions
    from .clinical_views import unavailable_state
    from .execution import DENY_ALL
    from .subjects import SubjectRegistryError
    from ..strict_json import MAX_SAFE_INTEGER

    require_operator_auth(req)
    request_id = str(uuid4())
    headers = {"Cache-Control": "no-store", "X-Request-ID": request_id}
    retired: list[object] = []
    storage_error = JSONResponse({"code": "REGISTRY_STORAGE_UNAVAILABLE",
        "error": "Selection storage or its prepared view cannot be confirmed. Inspect current state before continuing."},
        status_code=503, headers=headers)
    try:
        body = await _selection_payload(req)
        if (set(body) != {"expected_version"} or type(body["expected_version"]) is not int
                or not 1 <= body["expected_version"] < MAX_SAFE_INTEGER):
            raise SubjectRegistryError("INVALID_TWIN_DATA", "Selection requires exactly one safely incrementable integer expected_version.")
        registry = _subject_registry()
        with _model_source_authority.observation():
            previous_generation = _model_source_authority.generation
            prepared = registry.prepare_observation_selection(twin_id,
                expected_version=body["expected_version"], request_id=request_id)
            active_before = prepared.active_before
            if _state.get("subject") is not None or active_before is not None:
                _require_matching_selected_record(active_before)

        record = prepared.record
        generation = uuid4().hex
        availability = model_availability(record, source_generation=generation, selection_mode="observations_only")
        if (record["source_class"] != "REAL_HUMAN" or availability["state"] != "UNAVAILABLE"
                or availability["selection_mode"] != "observations_only"
                or availability["preparation_available"] is not False):
            raise ValueError("Observation selection cannot provide numerical physiology")
        observed = ObservationState()
        snapshot = deepcopy(unavailable_state(availability, observed))
        absent = ("profile", "base", "profile_params", "pk_context", "parameter_provenance",
                  "provenance", "intervention", "metabolic", "cardiac", "hepatic", "comparison", "human")
        if (not isinstance(snapshot, dict) or any(key not in snapshot or snapshot[key] is not None for key in absent)
                or snapshot.get("model_availability") != availability or snapshot.get("applied") != []
                or snapshot.get("observations") != {} or snapshot.get("patch") != observed.state()["patch"]
                or "active_execution" not in snapshot or snapshot["active_execution"] is not None
                or snapshot.get("biological_time", {}).get("axes")):
            raise ValueError("Invalid prepared observation projection")
        # The acknowledgment omits snapshot quantities. Validate the entire own
        # projection before commit so an invalid bus payload cannot follow a write.
        JSONResponse(snapshot)
        selected_state = {"tw": None, "subject": _subject_summary(record), "initialized": True,
                          "observation_state": observed, "model_availability": availability}
        empty_actions: list[WorkspaceAction] = []
        success = JSONResponse({**record, "model_availability": availability}, headers=headers)
        uncertain = JSONResponse({"code": "SELECTION_COMMIT_UNCONFIRMED",
            "error": "Selection storage outcome is unconfirmed; reconcile before numerical use."},
            status_code=503, headers=headers)
        cleanup_failed = JSONResponse({"code": "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED",
            "error": "Selection committed, but resource cleanup is unconfirmed. Inspect before continuing."},
            status_code=503, headers=headers)
        outcome = "COMMITTED"
        with _model_source_authority.commit_guard():
            if _model_source_authority.generation != previous_generation:
                raise SourceGenerationConflict()
            if _state.get("subject") is not None or active_before is not None:
                _require_matching_selected_record(active_before)
            retired.extend((_state, _workspace_actions))
            try:
                outcome = registry.commit_prepared_transition(prepared)
            except SubjectRegistryError as error:
                if error.code != "SELECTION_COMMIT_UNCONFIRMED":
                    raise
                outcome = "UNCONFIRMED"
            if outcome not in {"COMMITTED", "COMMITTED_CLEANUP_UNCONFIRMED"}:
                _model_source_authority.install_generation(DENY_ALL)
            else:
                _model_source_authority.install_generation(generation)
                _state = selected_state
                _workspace_actions = empty_actions

        try:
            _invalidate_model_source(previous_generation, "subject_observations_selected")
        except Exception:
            if outcome == "COMMITTED":
                outcome = "COMMITTED_CLEANUP_UNCONFIRMED"
        if outcome not in {"COMMITTED", "COMMITTED_CLEANUP_UNCONFIRMED"}:
            return uncertain
        _snapshot_twin(snapshot)
        return success if outcome == "COMMITTED" else cleanup_failed
    except (SourceGenerationConflict, SourceSelectionUnconfirmed) as error:
        return JSONResponse({"code": error.code, "error": str(error)},
            status_code=409 if isinstance(error, SourceGenerationConflict) else 503, headers=headers)
    except SubjectRegistryError as error:
        statuses = {"INVALID_TWIN_DATA": 422, "INVALID_REQUEST_ID": 422,
            "SUBJECT_ADMISSION_REQUIRED": 422, "RECORD_NOT_FOUND": 404, "TWIN_VERSION_CONFLICT": 409,
            "SELECTION_COMMIT_UNCONFIRMED": 503, "REGISTRY_AUDIT_UNAVAILABLE": 503,
            "REGISTRY_STORAGE_UNAVAILABLE": 503}
        if error.code not in statuses:
            return storage_error
        return JSONResponse({"code": error.code,
            "error": "Selection request or storage confirmation is unavailable. Inspect current state before continuing."},
            status_code=statuses[error.code], headers=headers)
    except Exception:
        return storage_error
    finally:
        retired.clear()


@app.post("/api/twins/reconcile-selection")
async def reconcile_twin_selection(req: Request):
    """Recover authority from audited storage, never by repeating selection."""
    global _state, _workspace_actions
    from .clinical_views import unavailable_state
    from .execution import DENY_ALL
    from .subjects import SubjectRegistryError

    require_operator_auth(req)
    request_id = str(uuid4())
    headers = {"Cache-Control": "no-store", "X-Request-ID": request_id}
    retired: list[object] = []
    conflict = JSONResponse({"code": "SELECTION_RECONCILIATION_CONFLICT",
        "error": "Reconciliation requires an uncertain selection and unchanged authoritative evidence."},
        status_code=409, headers=headers)
    storage_error = JSONResponse({"code": "REGISTRY_STORAGE_UNAVAILABLE",
        "error": "Selection storage or audit cannot be confirmed. Numerical use remains blocked."},
        status_code=503, headers=headers)
    try:
        if await _selection_payload(req) != {} or req.query_params:
            raise SubjectRegistryError("INVALID_TWIN_DATA", "Reconciliation accepts only an empty JSON object.")
        with _model_source_authority.observation():
            if _model_source_authority.permitted_generation is not DENY_ALL:
                return conflict
        registry = _subject_registry()
        with _model_source_authority.observation():
            if _model_source_authority.permitted_generation is not DENY_ALL:
                return conflict
            # DENY_ALL is one sentinel, not a fresh uncertainty epoch. Retaining
            # the captured object also fences a DENY → recovery → DENY ABA race.
            captured_state = _state
            retired.extend((captured_state, _workspace_actions))
            captured = registry.audited_active_twin(action="reconcile_selection", request_id=request_id,
                                                   _checked_snapshot=True)
        record = captured.record
        generation = uuid4().hex
        availability = model_availability(record, source_generation=generation)
        candidate = None
        if availability["state"] == "READY":
            try:
                candidate = AegleTwin("healthy") if record is None else registry.build_twin(record)
                if candidate is None:
                    raise ValueError("Reconciliation returned no numerical model")
                retired.append(candidate)
            except ModelContextError as error:
                if record is None:
                    raise
                availability.update(state="UNAVAILABLE", reason_code=error.code,
                                    selection_mode="observations_only", preparation_available=False)
        observed = ObservationState()
        if candidate is not None:
            snapshot = deepcopy(candidate.state())
            if not isinstance(snapshot, dict) or not isinstance(snapshot.get("profile_params"), dict):
                raise ValueError("Invalid prepared numerical reconciliation projection")
            snapshot["model_availability"] = deepcopy(availability)
        else:
            snapshot = deepcopy(unavailable_state(availability, observed))
            absent = ("profile", "base", "profile_params", "pk_context", "parameter_provenance",
                      "provenance", "intervention", "metabolic", "cardiac", "hepatic", "comparison", "human")
            if (not isinstance(snapshot, dict) or any(key not in snapshot or snapshot[key] is not None for key in absent)
                    or availability["state"] != "UNAVAILABLE" or availability["selection_mode"] != "observations_only"
                    or snapshot.get("model_availability") != availability or snapshot.get("applied") != []
                    or snapshot.get("observations") != {} or snapshot.get("patch") != observed.state()["patch"]
                    or "active_execution" not in snapshot or snapshot["active_execution"] is not None
                    or snapshot.get("biological_time", {}).get("axes")):
                raise ValueError("Invalid prepared modeless reconciliation projection")
        JSONResponse(snapshot)
        selected_state = {"tw": candidate, "subject": _subject_summary(record) if record else None,
                          "initialized": True, "observation_state": observed,
                          "model_availability": availability}
        empty_actions: list[WorkspaceAction] = []
        success = JSONResponse({"selection_status": "CONFIRMED", "subject": selected_state["subject"],
            "model_availability": availability, "prior_execution_cleanup": "INSPECT_EXISTING_STATUS"}, headers=headers)
        with _model_source_authority.commit_guard():
            if (_model_source_authority.permitted_generation is not DENY_ALL
                    or _state is not captured_state):
                return conflict
            retired.extend((_state, _workspace_actions))
            registry.confirm_active_selection(expected_record=record, request_id=request_id,
                                              _expected_snapshot=captured)
            _model_source_authority.install_generation(generation)
            _state = selected_state
            _workspace_actions = empty_actions
        # Restored selection authority does not reopen, stop, or acknowledge any
        # previous execution; its ownership/cleanup state remains independently visible.
        _snapshot_twin(snapshot)
        return success
    except SubjectRegistryError as error:
        if error.code == "SELECTION_RECONCILIATION_CONFLICT":
            return conflict
        if error.code == "INVALID_TWIN_DATA":
            return JSONResponse({"code": error.code, "error": "Reconciliation accepts only an empty JSON object."},
                                status_code=422, headers=headers)
        if error.code in {"SELECTION_COMMIT_UNCONFIRMED", "REGISTRY_AUDIT_UNAVAILABLE"}:
            return JSONResponse({"code": error.code,
                "error": "Selection storage or audit cannot be confirmed. Numerical use remains blocked."},
                status_code=503, headers=headers)
        return storage_error
    except Exception:
        return storage_error
    finally:
        retired.clear()


async def _selection_payload(req: Request) -> dict:
    from ..strict_json import StrictJSONError, parse_json_object
    from .subjects import SubjectRegistryError

    raw = bytearray()
    async for chunk in req.stream():
        if len(raw) + len(chunk) > 16 * 1024:
            raise SubjectRegistryError("INVALID_TWIN_DATA", "Selection request exceeds its size limit.")
        raw.extend(chunk)
    try:
        return parse_json_object(raw, max_bytes=16 * 1024)
    except StrictJSONError:
        raise SubjectRegistryError("INVALID_TWIN_DATA", "Selection requires a valid, unambiguous JSON object.") from None


@app.post("/api/twins/{twin_id}/patches")
async def bind_twin_patch(twin_id: str, req: Request):
    global _state
    from .clinical_views import unavailable_state
    from .execution import DENY_ALL
    from .subjects import SubjectRegistryError, _normalize_transition_binding
    from ..strict_json import MAX_SAFE_INTEGER

    require_operator_auth(req)
    request_id = str(uuid4())
    headers = {"Cache-Control": "no-store", "X-Request-ID": request_id}
    retained: list[object] = []
    try:
        body = await _selection_payload(req)
        version = body.get("expected_version")
        if type(version) is not int or not 1 <= version < MAX_SAFE_INTEGER:
            raise SubjectRegistryError("INVALID_PATCH_BINDING", "Binding requires a safely incrementable integer expected_version.")
        _normalize_transition_binding(body, version)
        registry = _subject_registry()
        with _model_source_authority.observation():
            previous_generation = _model_source_authority.generation
            prepared = registry.prepare_patch_binding(twin_id, body, expected_version=version,
                                                      request_id=request_id)
            active_before = prepared.active_before
            if _state.get("subject") is not None or active_before is not None:
                _require_matching_selected_record(active_before)
            selected = prepared.selected
            if selected:
                source_state = _state
                live_twin = source_state["tw"]
                live_observed = source_state["observation_state"]
                retained.extend((source_state, _workspace_actions))
                # The modeless accessor refreshes generation; check the retained
                # identity first so that refresh cannot disguise stale metadata.
                if (live_twin is None
                        and source_state["model_availability"].get("source_generation") != previous_generation):
                    raise ValueError("Inconsistent binding availability")
                availability = deepcopy(_model_availability())
                if (set(availability) != {"schema", "state", "reason_code", "selection_mode",
                        "twin_id", "twin_version", "source_generation", "preparation_available"}
                        or availability["schema"] != "livemore.model-availability.v1"
                        or availability["twin_id"] != active_before["twin_id"]
                        or type(availability["twin_version"]) is not int
                        or availability["twin_version"] != active_before["version"]
                        or availability["source_generation"] != previous_generation
                        or availability["preparation_available"] is not (live_twin is not None)):
                    raise ValueError("Inconsistent binding availability")
                if live_twin is None:
                    reason = availability["reason_code"]
                    if (availability["state"] != "UNAVAILABLE" or availability["selection_mode"] != "observations_only"
                            or type(reason) is not str or ModelContextError(reason).code != reason):
                        raise ValueError("Inconsistent modeless binding availability")
                elif (availability["state"] != "READY" or availability["reason_code"] is not None
                      or availability["selection_mode"] != "model"):
                    raise ValueError("Inconsistent model binding availability")
                # Copy the admitted packet pair under its ingestion guard, without
                # calling the overridden numerical state method or refreshing time.
                observed_snapshot = ObservationState.state(live_twin if live_twin is not None else live_observed)

        record = prepared.record
        generation = uuid4().hex
        snapshot = None
        if selected:
            availability.update(twin_id=record["twin_id"], twin_version=record["version"],
                                source_generation=generation)
            selected_state = {**source_state, "subject": _subject_summary(record),
                              "model_availability": availability, "initialized": True}
            if live_twin is not None:
                snapshot = deepcopy(live_twin.state())
            else:
                projection_only = ObservationState()
                projection_only.patch = observed_snapshot["patch"]
                projection_only.observations = observed_snapshot["observations"]
                snapshot = unavailable_state(availability, projection_only)
            if (not isinstance(snapshot, dict) or "profile_params" not in snapshot
                    or snapshot["profile_params"] is not None and not isinstance(snapshot["profile_params"], dict)):
                raise ValueError("Invalid prepared binding projection")
            snapshot.update(observed_snapshot)
            snapshot["model_availability"] = deepcopy(availability)
            if "capability" in snapshot:
                capability = snapshot["capability"]
                if not isinstance(capability, dict) or not isinstance(capability.get("maturity"), dict):
                    raise ValueError("Invalid binding capability projection")
                if "packet_admitted" in capability["maturity"]:
                    capability["maturity"]["packet_admitted"] = bool(observed_snapshot["patch"].get("connected"))

        success = JSONResponse(record, headers=headers)
        uncertain = JSONResponse({"code": "SELECTION_COMMIT_UNCONFIRMED",
            "error": "Selection storage outcome is unconfirmed; reconcile before numerical use."},
            status_code=503, headers=headers)
        cleanup_failed = JSONResponse({"code": "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED",
            "error": "Selection committed, but resource cleanup is unconfirmed. Inspect before continuing."},
            status_code=503, headers=headers)
        with _model_source_authority.commit_guard():
            if _model_source_authority.generation != previous_generation:
                raise SourceGenerationConflict()
            if _state.get("subject") is not None or active_before is not None:
                _require_matching_selected_record(active_before)
            try:
                outcome = registry.commit_prepared_transition(prepared)
            except SubjectRegistryError as error:
                if error.code != "SELECTION_COMMIT_UNCONFIRMED":
                    raise
                outcome = "UNCONFIRMED"
            confirmed = outcome in {"COMMITTED", "COMMITTED_CLEANUP_UNCONFIRMED"}
            if not confirmed:
                _model_source_authority.install_generation(DENY_ALL)
            elif selected:
                _model_source_authority.install_generation(generation)
                _state = selected_state

        if selected or not confirmed:
            try:
                _invalidate_model_source(previous_generation, "device_binding_changed")
            except Exception:
                if confirmed:
                    outcome = "COMMITTED_CLEANUP_UNCONFIRMED"
        if not confirmed:
            return uncertain
        if selected:
            _snapshot_twin(snapshot)
        return success if outcome == "COMMITTED" else cleanup_failed
    except (SourceGenerationConflict, SourceSelectionUnconfirmed) as error:
        return JSONResponse({"code": error.code, "error": str(error)},
                            status_code=409 if isinstance(error, SourceGenerationConflict) else 503, headers=headers)
    except SubjectRegistryError as error:
        response = (JSONResponse({"code": error.code, "error": str(error)}, status_code=503)
                    if error.code in {"REGISTRY_STORAGE_UNAVAILABLE", "REGISTRY_AUDIT_UNAVAILABLE",
                                      "SELECTION_COMMIT_UNCONFIRMED"}
                    else _subject_error(error))
        response.headers.update(headers)
        return response
    except Exception:
        return JSONResponse({"code": "REGISTRY_STORAGE_UNAVAILABLE",
            "error": "Binding could not be prepared or confirmed. Inspect current state before continuing."},
            status_code=503, headers=headers)
    finally:
        retained.clear()


@app.get("/api/population-capabilities")
def api_population_capabilities(req: Request):
    require_operator_auth(req)
    from .population import population_capabilities
    from .reference_cohorts import population_capability

    return JSONResponse({**population_capabilities(), "public_reference": population_capability()},
                        headers={"Cache-Control": "no-store"})


@app.get("/api/cohorts")
def list_cohorts(req: Request, limit: int = 25, cursor: str | None = None, q: str = ""):
    require_operator_auth(req)
    from cryptography.exceptions import InvalidTag
    from .subjects import SubjectRegistryError, project_cohort_summary
    from .registry_audit import RegistryAuditError
    from .registry_bootstrap import RegistryBootstrapError
    from .reference_cohort_api import project_cohort_summary_for_api, failure
    from .reference_cohorts import ReferenceCohortError
    try:
        page = _subject_registry().page_records("COHORT", limit=limit, cursor=cursor, q=q)
        return JSONResponse({"cohorts": [project_cohort_summary(project_cohort_summary_for_api(row)) for row in page["records"]],
            "pagination": page["pagination"]}, headers={"Cache-Control": "no-store"})
    except ReferenceCohortError as error:
        response = failure(error)
        response.headers["Cache-Control"] = "no-store"
        return response
    except SubjectRegistryError as error:
        response = _subject_error(error)
        response.headers["Cache-Control"] = "no-store"
        return response
    except (RegistryBootstrapError, RegistryAuditError, _RegistryKeyUnavailable, sqlite3.Error, InvalidTag, OSError) as error:
        response = failure(error)
        response.headers["Cache-Control"] = "no-store"
        return response


@app.get("/api/cohorts/{cohort_id}")
def get_cohort(cohort_id: str, req: Request):
    require_operator_auth(req)
    from cryptography.exceptions import InvalidTag
    from .subjects import SubjectRegistryError, project_cohort_summary
    from .registry_audit import RegistryAuditError
    from .registry_bootstrap import RegistryBootstrapError
    from .reference_cohort_api import project_cohort_summary_for_api, failure
    from .reference_cohorts import ReferenceCohortError
    try:
        return JSONResponse(project_cohort_summary(project_cohort_summary_for_api(_subject_registry().get_cohort(cohort_id))),
                            headers={"Cache-Control": "no-store"})
    except ReferenceCohortError as error:
        response = failure(error)
        response.headers["Cache-Control"] = "no-store"
        return response
    except SubjectRegistryError as error:
        response = _subject_error(error)
        response.headers["Cache-Control"] = "no-store"
        return response
    except (RegistryBootstrapError, RegistryAuditError, _RegistryKeyUnavailable, sqlite3.Error, InvalidTag, OSError) as error:
        response = failure(error)
        response.headers["Cache-Control"] = "no-store"
        return response


@app.get("/api/cohorts/{cohort_id}/members")
def list_real_cohort_members(cohort_id: str, req: Request, limit: str = "10", cursor: str | None = None):
    require_operator_auth(req)
    from .subjects import SubjectRegistryError

    try:
        if (not re.fullmatch(r"[0-9]{1,2}", limit) or not 1 <= int(limit) <= 50
                or set(req.query_params) - {"limit", "cursor"}
                or len(req.query_params.multi_items()) != len(req.query_params)):
            raise SubjectRegistryError("INVALID_PAGE", "Use one member page size from 1 to 50 and an optional cursor.")
        value = _subject_registry().page_cohort_members(cohort_id, limit=int(limit), cursor=cursor)
        return JSONResponse(value, headers={"Cache-Control": "no-store"})
    except SubjectRegistryError as error:
        response = _subject_error(error)
        response.headers["Cache-Control"] = "no-store"
        return response


@app.get("/api/cohorts/{cohort_id}/members/{member_id}")
def get_real_cohort_member(cohort_id: str, member_id: str, req: Request):
    require_operator_auth(req)
    from .subjects import SubjectRegistryError

    try:
        value = _subject_registry().get_cohort_member(cohort_id, member_id)
        return JSONResponse(value, headers={"Cache-Control": "no-store"})
    except SubjectRegistryError as error:
        response = _subject_error(error)
        response.headers["Cache-Control"] = "no-store"
        return response


@app.post("/api/cohorts", status_code=201)
async def create_cohort(req: Request):
    from .subjects import SubjectRegistryError

    try:
        body = await req.json()
        result = _subject_registry().create_cohort(
            body, idempotency_key=req.headers.get("Idempotency-Key"),
        )
        return JSONResponse(result, status_code=201)
    except (json.JSONDecodeError, TypeError):
        return JSONResponse({"error": "request body must be valid JSON", "code": "INVALID_COHORT_DATA"}, status_code=400)
    except SubjectRegistryError as error:
        return _subject_error(error)


@app.post("/api/cendos/protocols/metformin-cohorts", status_code=201)
async def run_metformin_cohort_protocol(req: Request):
    from ..cendos.protocols import run_metformin_cohort_comparison
    from ..cendos.protocol_runs import attach_run_inputs, ProtocolRunNotFound
    from ..research import ResearchError
    from .research_api import body as read_body
    from .subjects import SubjectRegistryError

    try:
        body = await read_body(req)
        first = _subject_registry().get_cohort(str(body.get("cohort_a_id", "")))
        second = _subject_registry().get_cohort(str(body.get("cohort_b_id", "")))
        configuration = {"cohort_a_id": first["cohort_id"], "cohort_b_id": second["cohort_id"],
                         "dose_mg": _protocol_number(body.get("dose_mg", 1000), "dose_mg"),
                         "grams": _protocol_number(body.get("grams", 75), "grams")}
        parent = _rerun_parent(body, configuration, "cendos.metformin-cohort-comparison.v1")
        def execute():
            result = run_metformin_cohort_comparison(first, second, dose_mg=configuration["dose_mg"], grams=configuration["grams"])
            return _protocol_run_store().save(attach_run_inputs(result, configuration, [first, second], parent=parent))
        return JSONResponse(await asyncio.to_thread(execute), status_code=201)
    except SubjectRegistryError as error:
        return _subject_error(error)
    except (ResearchError, ProtocolRunNotFound, TypeError, ValueError, OSError, sqlite3.Error) as error:
        return _protocol_failure(error)


@app.post("/api/cendos/protocols/garcinoic-pxr", status_code=201)
async def run_garcinoic_pxr_protocol(req: Request):
    from ..cendos.protocols import run_garcinoic_acid_pxr
    from ..cendos.protocol_runs import attach_run_inputs, ProtocolRunNotFound
    from ..research import ResearchError
    from .research_api import body as read_body
    from .subjects import SubjectRegistryError

    try:
        body = await read_body(req)
        cohort = _subject_registry().get_cohort(str(body.get("cohort_id", "")))
        concentrations = body.get("concentrations_um", [0.05, 0.33, 1.3, 5.0])
        if not isinstance(concentrations, list):
            raise ValueError("concentrations_um must be an array")
        configuration = {"cohort_id": cohort["cohort_id"], "concentrations_um": [_protocol_number(value, "concentrations_um") for value in concentrations]}
        parent = _rerun_parent(body, configuration, "cendos.garcinoic-acid-pxr.v1")
        def execute():
            result = run_garcinoic_acid_pxr(cohort, concentrations_um=configuration["concentrations_um"])
            return _protocol_run_store().save(attach_run_inputs(result, configuration, [cohort], parent=parent))
        return JSONResponse(await asyncio.to_thread(execute), status_code=201)
    except SubjectRegistryError as error:
        return _subject_error(error)
    except (ResearchError, ProtocolRunNotFound, TypeError, ValueError, OSError, sqlite3.Error) as error:
        return _protocol_failure(error)


def _protocol_number(value: object, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{field} must be a finite JSON number")
    return float(value)


def _protocol_failure(error: Exception) -> JSONResponse:
    from ..cendos.protocol_runs import ProtocolRunNotFound
    from ..engines.stoichiometry import StoichiometryError
    from ..reference_cohort_contract import ReferenceModelBindingRequired
    if isinstance(error, ReferenceModelBindingRequired):
        return JSONResponse({"error": str(error), "code": error.code}, status_code=422)
    if isinstance(error, ProtocolRunNotFound):
        return JSONResponse({"error": "Protocol run was not found", "code": "PROTOCOL_NOT_FOUND"}, status_code=404)
    if isinstance(error, (OSError, sqlite3.Error)):
        logger.warning("Cendos storage unavailable (error_type=%s)", type(error).__name__)
        return JSONResponse({"error": "Protocol storage is temporarily unavailable", "code": "PROTOCOL_STORAGE_UNAVAILABLE"}, status_code=503)
    if isinstance(error, StoichiometryError):
        status = {"MODEL_BUSY": 409, "MODEL_UNAVAILABLE": 503,
                  "MODEL_EXECUTION_FAILED": 503, "MODEL_EXECUTION_TIMEOUT": 504}.get(error.code, 422)
        return JSONResponse({"error": str(error), "code": error.code}, status_code=status)
    return JSONResponse({"error": str(error), "code": "INVALID_PROTOCOL"}, status_code=422)


def _rerun_parent(body: dict, configuration: dict, protocol_id: str) -> dict | None:
    if type(body.get("new_configuration", False)) is not bool:
        raise ValueError("new_configuration must be boolean")
    if "parent_run_id" not in body:
        return None
    return _protocol_run_store().validate_rerun(
        body["parent_run_id"], configuration, lambda identity: _subject_registry().get_cohort(identity),
        new_configuration=body.get("new_configuration", False),
        expected_protocol_id=protocol_id,
    )


@app.get("/api/genome-models")
def genome_models(req: Request):
    require_operator_auth(req)
    from .. import model_assets
    from ..engines.stoichiometry import runtime_capabilities
    models = []
    runtime = runtime_capabilities()
    for entry in model_assets.catalog()["models"]:
        status = model_assets.status(entry["model_id"])
        models.append({**entry, "status": status,
                       "execution": runtime if entry["model_id"] == "human-gem" else {"available": False, "state": "restricted"}})
    return {"models": models, "scope": "reference_metabolism"}


@app.post("/api/cendos/protocols/human-gem-oxygen-capacity", status_code=201)
async def run_metabolic_protocol(req: Request):
    from .research_api import body as read_body
    from ..research import ResearchError
    from ..cendos.metabolic_protocol import run_human_gem_oxygen_capacity
    from ..cendos.protocol_runs import attach_run_inputs, ProtocolRunNotFound
    from ..engines.stoichiometry import validate_spec
    try:
        body = await read_body(req)
        configuration = validate_spec({k: v for k, v in body.items() if k not in {"parent_run_id", "new_configuration"}})
        parent = _rerun_parent(body, configuration, "cendos.human-gem-oxygen-capacity.v1")
        def execute():
            result = run_human_gem_oxygen_capacity(configuration)
            return _protocol_run_store().save(attach_run_inputs(result, configuration, [], parent=parent))
        return JSONResponse(await asyncio.to_thread(execute), status_code=201)
    except (ResearchError, ProtocolRunNotFound, TypeError, ValueError, OSError, sqlite3.Error) as error:
        return _protocol_failure(error)


@app.post("/api/cendos/protocols/lobeline-vmat2", status_code=201)
async def run_lobeline_protocol(req: Request):
    """Execute the same nonhuman assay kernel used by Cendos and the SDK."""
    from .research_api import body as read_body
    from ..research import ResearchError
    from ..cendos.lobeline_vmat2 import PROTOCOL_ID, validate_spec, run_lobeline_vmat2
    from ..cendos.protocol_runs import attach_run_inputs, ProtocolRunNotFound

    try:
        body = await read_body(req)
        configuration = validate_spec({k: v for k, v in body.items() if k not in {"parent_run_id", "new_configuration"}})
        parent = _rerun_parent(body, configuration, PROTOCOL_ID)

        def execute():
            result = run_lobeline_vmat2(configuration)
            return _protocol_run_store().save(attach_run_inputs(result, configuration, [], parent=parent))

        return JSONResponse(await asyncio.to_thread(execute), status_code=201)
    except (ResearchError, ProtocolRunNotFound, TypeError, ValueError, OSError, sqlite3.Error) as error:
        return _protocol_failure(error)


@app.get("/api/cendos/programs")
def cendos_program_catalog(req: Request):
    """Executability of the insulin program and the five botanical programs."""
    require_operator_auth(req)
    from ..cendos.botanical_programs import program_catalog
    from ..engines.metabolic.hovorka import product_catalog
    return JSONResponse({"insulin": product_catalog(), "botanical": program_catalog()},
                        headers={"Cache-Control": "no-store"})


def _six_program_failure(error: Exception) -> JSONResponse:
    code = getattr(error, "code", None)
    if code in {"INSULIN_PRODUCT_NOT_ADMITTED", "INSULIN_PRODUCT_UNKNOWN", "INSULIN_ROUTE_NOT_SUPPORTED_BY_PROTOCOL",
                "PROGRAM_NOT_FOUND", "ROUTE_NOT_ADMITTED", "INVALID_PROTOCOL", "COHORT_GENERATION_FAILED"}:
        return JSONResponse({"error": str(error), "code": code}, status_code=422)
    return _protocol_failure(error)


@app.post("/api/cendos/protocols/exogenous-insulin", status_code=201)
async def run_exogenous_insulin_protocol_route(req: Request):
    """Paired within-individual exogenous insulin model runs; never touches a live twin."""
    from .research_api import body as read_body
    from ..research import ResearchError
    from ..cendos.insulin_protocol import (PROTOCOL_ID, InsulinProtocolError, validate_spec,
                                           run_exogenous_insulin_protocol)
    from ..cendos.protocol_runs import attach_run_inputs, ProtocolRunNotFound
    try:
        body = await read_body(req)
        configuration = validate_spec({k: v for k, v in body.items() if k not in {"parent_run_id", "new_configuration"}})
        parent = _rerun_parent(body, configuration, PROTOCOL_ID)

        def execute():
            result = run_exogenous_insulin_protocol(configuration)
            return _protocol_run_store().save(attach_run_inputs(result, configuration, [], parent=parent))

        return JSONResponse(await asyncio.to_thread(execute), status_code=201)
    except InsulinProtocolError as error:
        return _six_program_failure(error)
    except (ResearchError, ProtocolRunNotFound, TypeError, ValueError, OSError, sqlite3.Error) as error:
        return _protocol_failure(error)


@app.post("/api/cendos/protocols/botanical-exposure", status_code=201)
async def run_botanical_exposure_route(req: Request):
    """Exposure versus measured active concentration for one declared botanical material."""
    from .research_api import body as read_body
    from ..research import ResearchError
    from ..cendos.botanical_programs import (PROTOCOL_ID, BotanicalProgramError, validate_spec,
                                             run_botanical_exposure_program)
    from ..cendos.protocol_runs import attach_run_inputs, ProtocolRunNotFound
    try:
        body = await read_body(req)
        configuration = validate_spec({k: v for k, v in body.items() if k not in {"parent_run_id", "new_configuration"}})
        parent = _rerun_parent(body, configuration, PROTOCOL_ID)

        def execute():
            result = run_botanical_exposure_program(configuration)
            return _protocol_run_store().save(attach_run_inputs(result, configuration, [], parent=parent))

        return JSONResponse(await asyncio.to_thread(execute), status_code=201)
    except BotanicalProgramError as error:
        return _six_program_failure(error)
    except (ResearchError, ProtocolRunNotFound, TypeError, ValueError, OSError, sqlite3.Error) as error:
        return _protocol_failure(error)


@app.get("/api/cendos/protocols/history")
def cendos_protocol_history(req: Request, limit: int = 20, cursor: str | None = None, q: str = ""):
    require_operator_auth(req)
    try:
        if not 1 <= limit <= 50:
            raise ValueError("history limit must be from 1 to 50")
        return _protocol_run_store().history(limit=limit, cursor=cursor, q=q)
    except (ValueError, OSError, sqlite3.Error) as error:
        return _protocol_failure(error)


@app.get("/api/cendos/protocols/{run_id}/prepare-rerun")
def prepare_cendos_protocol_rerun(run_id: str, req: Request):
    require_operator_auth(req)
    from ..cendos.protocol_runs import ProtocolRunNotFound
    try:
        return _protocol_run_store().prepare_rerun(run_id, lambda identity: _subject_registry().get_cohort(identity))
    except (ProtocolRunNotFound, ValueError, OSError, sqlite3.Error) as error:
        return _protocol_failure(error)


@app.get("/api/cendos/protocols/latest")
def latest_cendos_protocol(req: Request):
    from ..cendos.protocol_runs import ProtocolRunNotFound

    require_operator_auth(req)
    try:
        return JSONResponse(_protocol_run_store().latest())
    except (ProtocolRunNotFound, ValueError, OSError, sqlite3.Error) as error:
        return _protocol_failure(error)


@app.get("/api/cendos/protocols/{run_id}")
def get_cendos_protocol(run_id: str, req: Request):
    from ..cendos.protocol_runs import ProtocolRunNotFound

    require_operator_auth(req)
    try:
        return JSONResponse(_protocol_run_store().get(run_id))
    except (ProtocolRunNotFound, ValueError, OSError, sqlite3.Error) as error:
        return _protocol_failure(error)


@app.get("/api/cendos/protocols/{run_id}/analysis.csv")
def export_cendos_protocol_csv(run_id: str, req: Request):
    from ..cendos.protocol_runs import ProtocolRunNotFound, analysis_csv

    require_operator_auth(req)
    try:
        result = _protocol_run_store().get(run_id)
        content = analysis_csv(result)
    except (ProtocolRunNotFound, ValueError, OSError, sqlite3.Error) as error:
        return _protocol_failure(error)
    return Response(
        content,
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{run_id}-analysis.csv"'},
    )


@app.get("/api/cendos/protocols/{run_id}/analysis.ipynb")
def export_cendos_protocol_notebook(run_id: str, req: Request):
    from ..cendos.protocol_runs import ProtocolRunNotFound, analysis_notebook

    require_operator_auth(req)
    try:
        result = _protocol_run_store().get(run_id)
        content = analysis_notebook(result)
    except (ProtocolRunNotFound, ValueError, OSError, sqlite3.Error) as error:
        return _protocol_failure(error)
    return JSONResponse(
        content,
        media_type="application/x-ipynb+json",
        headers={"Content-Disposition": f'attachment; filename="{run_id}-analysis.ipynb"'},
    )


@app.post("/api/workspace/actions")
async def run_workspace_action(req: Request):
    """Execute one existing twin perturbation with a visible lifecycle."""
    _require_numerical_model()
    try:
        body = await req.json()
    except json.JSONDecodeError:
        return JSONResponse({"error": "request body must be valid JSON"}, status_code=400)
    try:
        kind, params = validate_action_input(body)
    except ValueError as error:
        return JSONResponse({"error": str(error), "code": "INVALID_WORKSPACE_ACTION"}, status_code=422)

    with _model_source_authority.mutation("model_changed", before=_assert_numerical_available):
        subject = (_state["tw"].human.id if _state["tw"].human else _state["tw"].profile.name)
        action = WorkspaceAction(kind=kind, subject_id=str(subject), parameters=params)
        _workspace_actions.append(action)
        action.transition(ActionStatus.RUNNING)
        try:
            state = _state["tw"].stimulate(kind, **params)
            _snapshot_twin(state)
            action.transition(ActionStatus.COMPLETED)
            from .. import bus

            bus.publish("Aegle", events.WORKSPACE_ACTION, {
                "action_id": action.action_id,
                "kind": action.kind,
                "status": action.status.value,
                "subject_id": action.subject_id,
            })
        except (ValueError, RuntimeError, ArithmeticError) as error:
            action.transition(ActionStatus.FAILED, error_code=getattr(error, "code", type(error).__name__))
            return JSONResponse({
                "error": ("No qualified executable mechanism exists for this intervention" if
                          action.error_code == "UNSUPPORTED_BIOLOGICAL_INTERVENTION" else
                          "biological action could not be completed"),
                "code": action.error_code,
                "action": action.to_dict(),
            }, status_code=422)

        from .workspace import projection

        return JSONResponse({
            "action": action.to_dict(),
            "workspace": projection(_state["tw"], _workspace_actions, _state.get("subject")),
        })


@app.post("/api/patch/telemetry", status_code=202)
async def ingest_patch_telemetry(req: Request):
    """Attach LIFE-admitted v2 telemetry as observation-only twin state."""
    global _patch_admission
    from ..life_patch.protocol import (
        PatchAdmissionController,
        ProtocolViolation,
        decode_envelope,
        decode_manifest,
        manifest_for,
    )
    from ..life_patch.protocol_v3 import ManifestV3, TelemetryEnvelopeV3, validate_manifest_binding
    from .research_api import body as strict_body
    from ..security import verify_patch_admission

    try:
        body = await strict_body(req)
        with _model_source_authority.observation():
            _model_source_authority.generation
            if not isinstance(body, dict):
                raise ProtocolViolation("telemetry body must be a JSON object")
            raw_envelope = body.get("envelope")
            admission = body.get("admission")
            signature = body.get("admission_signature")
            if not isinstance(raw_envelope, dict) or not isinstance(admission, dict):
                raise ProtocolViolation("Aegle accepts only LIFE-admitted telemetry records")
            if not isinstance(signature, str) or not verify_patch_admission(admission, signature):
                raise ProtocolViolation("LIFE admission signature is missing or invalid")
            envelope = decode_envelope(raw_envelope)
            active_record = _subject_registry().active_twin()
            if active_record is None:
                raise ProtocolViolation("telemetry requires an active governed twin")
            _require_matching_selected_record(active_record)
            if envelope.subject_id != active_record["subject_id"]:
                raise ProtocolViolation("telemetry subject does not match the active governed twin")
            binding = next(
                (
                    item for item in active_record.get("patch_bindings", [])
                    if item.get("device_id") == envelope.device_id
                    and item.get("mode") == envelope.mode.value
                ),
                None,
            )
            if binding is None:
                raise ProtocolViolation("telemetry device and mode are not bound to the active governed twin")
            if binding.get("protocol_version", "2.0") != envelope.protocol_version:
                raise ProtocolViolation("telemetry protocol does not match the subject's device binding")
            expected = {
                "admission": "accepted",
                "device_id": envelope.device_id,
                "mode": envelope.mode.value,
                "envelope_hash": envelope.envelope_hash,
            }
            if any(admission.get(key) != value for key, value in expected.items()):
                raise ProtocolViolation("LIFE admission does not match the telemetry envelope")
            if isinstance(envelope, TelemetryEnvelopeV3):
                if not isinstance(body.get("manifest"), dict):
                    raise ProtocolViolation("v3 requires a LIFE-attested registered manifest")
                expected_manifest = decode_manifest(body["manifest"])
                if not isinstance(expected_manifest, ManifestV3):
                    raise ProtocolViolation("v3 envelope requires a v3 registered manifest")
                if (admission.get("manifest_hash") != expected_manifest.capability_hash
                        or admission.get("capability_hash") != expected_manifest.capability_hash):
                    raise ProtocolViolation("LIFE admission does not bind the registered manifest hash")
                validate_manifest_binding(expected_manifest, envelope)
                received = admission.get("received_at")
                try:
                    received = datetime.fromisoformat(received.replace("Z", "+00:00"))
                    if received.tzinfo is None or not envelope.captured_at <= received <= datetime.now(timezone.utc):
                        raise ValueError
                except (AttributeError, TypeError, ValueError):
                    raise ProtocolViolation("LIFE receipt time is missing or inconsistent") from None
            else:
                expected_manifest = manifest_for(envelope.device_id, envelope.mode)
                if admission.get("capability_hash") != expected_manifest.capability_hash:
                    raise ProtocolViolation("LIFE admission capability hash does not match the v2 contract")
            if _patch_admission is None:
                _patch_admission = PatchAdmissionController()
            _patch_admission.admit(expected_manifest, envelope)
            holder = _state["tw"] if _state["tw"] is not None else _state["observation_state"]
            holder.ingest_patch_envelope(envelope, received_at=admission.get("received_at"))
            state = _current_snapshot()
            _snapshot_twin(state)
            return JSONResponse(state, status_code=202)
    except (SourceSelectionUnconfirmed, SourceGenerationConflict):
        raise
    except (ProtocolViolation, ValueError, TypeError) as error:
        return JSONResponse({"error": str(error)}, status_code=422)


@app.get("/api/system-manifest")
def api_system_manifest():
    """Read-only whole-human coverage and scientific-maturity contract."""
    from ..foundation import whole_human_manifest
    return JSONResponse(whole_human_manifest())


def _snapshot_twin(st=None):
    """Publish one coherent state and its own parameters to the cross-system bus.

    Best-effort publication is not authority to reconstruct a different selection
    or to qualify a Cendos result. Missing parameters must not borrow a live model.
    """
    try:
        from .. import bus
        st = st if st is not None else _current_snapshot()
        snap = dict(st)
        if "profile_params" not in snap or (
            snap["profile_params"] is not None and not isinstance(snap["profile_params"], dict)
        ):
            raise ValueError("Snapshot parameters are absent or malformed")
        bus.set_snapshot("twin", snap)
        bus.publish("Aegle", events.TWIN_UPDATED,
                    {"profile": st.get("profile"),
                     "last": (st.get("applied") or [None])[-1],
                     "mean_glucose": (st.get("metabolic") or {}).get("mean_glucose")})
    except Exception:
        logger.warning("Aegle cross-product snapshot publication failed")


def _pub(st):
    """Publish the live twin to the bus, then return it as JSON."""
    _snapshot_twin(st)
    return JSONResponse(st)


@app.on_event("startup")
def _startup_publish():
    _ensure_selected_state()


@app.post("/api/stimulate")
async def stimulate(req: Request):
    from .research_api import body as strict_json_object

    require_operator_auth(req)
    request_id = str(uuid4())
    headers = {"Cache-Control": "no-store", "X-Request-ID": request_id}
    try:
        body = await strict_json_object(req)
        kind = body.get("kind")
        params = body.get("params", {})
        if not isinstance(kind, str) or not kind.strip() or not isinstance(params, dict):
            raise ValueError("intervention requires a kind and a parameters object")
    except ValueError:
        return JSONResponse({"error": "Intervention requires a valid kind and parameters object.",
                             "code": "INVALID_INTERVENTION"}, status_code=422, headers=headers)
    if kind == "base":
        base = params.get("base", "healthy")
        if base not in ("healthy", "t2d", "type-2-diabetes"):
            return JSONResponse({"error": "base must be healthy, t2d, or type-2-diabetes",
                                 "code": "INVALID_INTERVENTION"}, status_code=422, headers=headers)
        return _publish_research_preview(lambda: (AegleTwin(base), None), request_id,
                                         input_code="INVALID_INTERVENTION")
    if kind == "life_system":
        mode = params.get("mode", "random")
        if not isinstance(mode, str) or mode not in {"random", "t2d_apoe4", "carrier", "custom"}:
            return JSONResponse({"error": "Choose a supported LIFE research preview mode.",
                                 "code": "INVALID_INTERVENTION"}, status_code=422, headers=headers)

        def candidate() -> tuple[AegleTwin, None]:
            from ..life_system.population import LifeSystem
            from ..life_system.synthetic_human import SyntheticHuman
            import random as _r

            if mode == "random":
                human = LifeSystem().generate(1, seed=_r.randint(0, 10 ** 6))[0]
            elif mode == "t2d_apoe4":
                human = SyntheticHuman("LMB-T2D", age=58, sex="F", conditions=["type 2 diabetes"],
                                       genome={"APOE4": 1, "TCF7L2": 1}, lifestyle=0.4)
            elif mode == "carrier":
                human = SyntheticHuman("LMB-CAR", age=46, sex="M",
                                       genome={"TCF7L2": 2, "PPARG_loss": 1}, lifestyle=0.6)
            else:
                human = SyntheticHuman(params.get("id", "LMB"), age=int(params.get("age", 50)),
                                       sex=params.get("sex", "F"), conditions=params.get("conditions", []),
                                       genome=params.get("genome", {}), lifestyle=float(params.get("lifestyle", 0.55)))
            return AegleTwin(human=human), None

        return _publish_research_preview(candidate, request_id, input_code="INVALID_INTERVENTION")
    _require_numerical_model()
    guard = (_model_source_authority.observation() if kind == "patch"
             else _model_source_authority.mutation("model_changed", before=_assert_numerical_available))
    with guard:
        if kind == "patch":
            _assert_numerical_available()
        return _apply_stimulus(kind, params)


def _apply_stimulus(kind: str, params: dict):
    if kind == "patch":
        from ..life_patch.stream import (SyntheticPatchStream, ExternalSeriesStream,
                                         SAMPLE_CGM_DIABETIC, SAMPLE_CGM_HEALTHY)
        tw = _state["tw"]
        mode = params.get("mode", "synthetic")
        if mode == "synthetic":
            packets = SyntheticPatchStream(tw).sample()
        elif mode == "cgm_diabetic":
            packets = ExternalSeriesStream("subject", glucose=SAMPLE_CGM_DIABETIC,
                                           hr=[(t, 88) for t, _ in SAMPLE_CGM_DIABETIC], source="cgm").packets()
        else:
            packets = ExternalSeriesStream("subject", glucose=SAMPLE_CGM_HEALTHY,
                                           hr=[(t, 62) for t, _ in SAMPLE_CGM_HEALTHY], source="cgm").packets()
        return _pub(tw.ingest_patch(packets))
    try:
        return _pub(_state["tw"].stimulate(kind, **params))
    except ValueError as error:
        return JSONResponse({"error": str(error), "code": getattr(error, "code", "INVALID_INTERVENTION")}, status_code=422)


def _publish_research_preview(factory: Callable[[], tuple[AegleTwin, dict | None]],
                              request_id: str, *, input_code: str) -> JSONResponse:
    """Replace a selected source only after its audited clear is confirmed."""
    global _state, _workspace_actions
    from .execution import DENY_ALL
    from .subjects import SubjectRegistryError

    headers = {"Cache-Control": "no-store", "X-Request-ID": request_id}
    retained: list[object] = []
    try:
        registry = _subject_registry()
        with _model_source_authority.observation():
            previous_generation = _model_source_authority.generation
            prepared = registry.prepare_preview_clear(request_id=request_id)
            active_before = prepared.active_before
            if _state.get("subject") is not None or active_before is not None:
                _require_matching_selected_record(active_before)

        try:
            candidate, extracted = factory()
        except (ValueError, TypeError):
            return JSONResponse({"code": input_code,
                "error": "Could not prepare the requested research preview."}, status_code=422, headers=headers)
        retained.append(candidate)
        snapshot = deepcopy(candidate.state())
        # Unlike an unavailable inspection view, a ready numerical preview
        # requires its own complete parameter dictionary for Cendos consumers.
        if not isinstance(snapshot, dict) or not isinstance(snapshot.get("profile_params"), dict):
            raise ValueError("Invalid prepared preview projection")
        if extracted is not None:
            snapshot["extracted"] = deepcopy(extracted)
        generation = uuid4().hex
        availability = model_availability(None, source_generation=generation)
        snapshot["model_availability"] = deepcopy(availability)
        selected_state = {"tw": candidate, "subject": None, "initialized": True,
                          "observation_state": ObservationState(), "model_availability": availability}
        empty_actions: list[WorkspaceAction] = []
        success = JSONResponse(snapshot, headers=headers)
        uncertain = JSONResponse({"code": "SELECTION_COMMIT_UNCONFIRMED",
            "error": "Selection storage outcome is unconfirmed; reconcile before numerical use."},
            status_code=503, headers=headers)
        cleanup_failed = JSONResponse({"code": "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED",
            "error": "Selection committed, but resource cleanup is unconfirmed. Inspect before continuing."},
            status_code=503, headers=headers)
        with _model_source_authority.commit_guard():
            if _model_source_authority.generation != previous_generation:
                raise SourceGenerationConflict()
            if _state.get("subject") is not None or active_before is not None:
                _require_matching_selected_record(active_before)
            retained.extend((_state, _workspace_actions))
            try:
                outcome = registry.commit_prepared_transition(prepared)
            except SubjectRegistryError as error:
                if error.code != "SELECTION_COMMIT_UNCONFIRMED":
                    raise
                outcome = "UNCONFIRMED"
            if outcome not in {"COMMITTED", "COMMITTED_CLEANUP_UNCONFIRMED"}:
                _model_source_authority.install_generation(DENY_ALL)
            else:
                _model_source_authority.install_generation(generation)
                _state = selected_state
                _workspace_actions = empty_actions

        try:
            _invalidate_model_source(previous_generation, "subject_changed")
        except Exception:
            if outcome == "COMMITTED":
                outcome = "COMMITTED_CLEANUP_UNCONFIRMED"
        if outcome not in {"COMMITTED", "COMMITTED_CLEANUP_UNCONFIRMED"}:
            return uncertain
        _snapshot_twin(snapshot)
        return success if outcome == "COMMITTED" else cleanup_failed
    except (SourceGenerationConflict, SourceSelectionUnconfirmed) as error:
        return JSONResponse({"code": error.code, "error": str(error)},
                            status_code=409 if isinstance(error, SourceGenerationConflict) else 503,
                            headers=headers)
    except SubjectRegistryError as error:
        response = (JSONResponse({"code": error.code, "error": str(error)}, status_code=503)
                    if error.code in {"REGISTRY_STORAGE_UNAVAILABLE", "REGISTRY_AUDIT_UNAVAILABLE",
                                      "SELECTION_COMMIT_UNCONFIRMED"}
                    else _subject_error(error))
        response.headers.update(headers)
        return response
    except Exception:
        return JSONResponse({"code": "REGISTRY_STORAGE_UNAVAILABLE",
            "error": "Preview could not be prepared or confirmed. Inspect current state before continuing."},
            status_code=503, headers=headers)
    finally:
        retained.clear()


def _ix():
    if "ix" not in _state:
        from ..life_system.retrieval import SubstrateIndex
        _state["ix"] = SubstrateIndex()
    return _state["ix"]


def _kg():
    if "kg" not in _state:
        from ..life_system.graph import KnowledgeGraph
        _state["kg"] = KnowledgeGraph()
    return _state["kg"]


@app.post("/api/ingest_note")
async def ingest_note(req: Request):
    from .research_api import body as strict_json_object

    require_operator_auth(req)
    request_id = str(uuid4())
    headers = {"Cache-Control": "no-store", "X-Request-ID": request_id}
    try:
        body = await strict_json_object(req)
        note = body.get("text", "")
        if not isinstance(note, str) or not note.strip():
            raise ValueError("note text is required")
    except (ValueError, TypeError):
        return JSONResponse({"error": "Could not create a note-based research preview", "code": "INVALID_NOTE"},
                            status_code=422, headers=headers)

    def candidate() -> tuple[AegleTwin, dict]:
        from ..life_system.extract import ClinicalExtractor

        human, info = ClinicalExtractor().to_synthetic_human(note, hid="LMB-NOTE")
        return AegleTwin(human=human), info

    return _publish_research_preview(candidate, request_id, input_code="INVALID_NOTE")


@app.get("/api/search")
def search(q: str = "", kind: str = ""):
    res = _ix().query(q, k=8, kind=kind or None)
    return JSONResponse({"query": q, "results": [{"kind": k, "name": n, "score": s} for k, n, s in res]})


@app.get("/api/graph")
def graph_stats():
    return JSONResponse({"stats": _kg().stats()})


@app.get("/api/services")
def services():
    """Poll the three LivemoreBio infrastructures (server-side, no CORS)."""
    import urllib.request, json as _j
    from ..build_info import public_service_health
    out = {}
    targets = (
        ("LIFE", os.environ.get("LIVEMORE_LIFE_URL", "").strip() or "http://127.0.0.1:8851"),
        ("Aegle", os.environ.get("LIVEMORE_AEGLE_URL", "").strip() or "http://127.0.0.1:8850"),
        ("Cendos", os.environ.get("LIVEMORE_CENDOS_URL", "").strip() or "http://127.0.0.1:8852"),
    )
    for name, base in targets:
        try:
            with urllib.request.urlopen(base.rstrip("/") + "/health", timeout=1) as r:
                raw = r.read(65537)
                if len(raw) > 65536:
                    raise ValueError("oversized service health")
                out[name] = public_service_health(_j.loads(raw), name)
        except (OSError, ValueError, UnicodeError, RecursionError):
            out[name] = {"up": False, "reason": "service_unavailable"}
    return JSONResponse(out, headers={"Cache-Control": "no-store"})


def main(host="127.0.0.1", port=8850):
    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="warning")


@app.post("/api/trajectory")
async def trajectory(req: Request):
    """Project disease emergence over years for the current grounded human under a
    sustained exposure pattern (diet, activity, recurring foods/drugs)."""
    _require_numerical_model()
    body = await req.json()
    from ..engines.trajectory import ExposurePattern, simulate_disease_trajectory
    def read_source():
        _assert_numerical_available()
        if _state.get("subject"):
            _require_matching_selected_record(_subject_registry().active_twin())
        return _model_source_authority.generation, _state["tw"].human

    generation, human = _model_source_authority.capture(read_source)
    if human is None:
        from types import SimpleNamespace
        human = SimpleNamespace(id="base", age=body.get("age", 40),
                                sex=body.get("sex", "M"), genome=body.get("genome", {}))
    exp = ExposurePattern(kcal_intake=float(body.get("kcal_intake", 2600)),
                          activity=float(body.get("activity", 0.4)),
                          foods=tuple(body.get("foods", [])), drugs=tuple(body.get("drugs", [])),
                          stress=float(body.get("stress", 0.0)), factors=tuple(body.get("factors", [])))
    def calculate():
        _model_source_authority.capture(lambda: None, expected_generation=generation)
        return simulate_disease_trajectory(human, exp, years=int(body.get("years", 15)))

    result = await asyncio.to_thread(calculate)
    return JSONResponse(_model_source_authority.capture(lambda: result, expected_generation=generation))


@app.post("/api/validate")
async def validate(req: Request):
    """Run a retrospective validation (DPP trial) and return the model-vs-trial comparison."""
    body = await req.json()
    from ..engines.validation import dpp_validation
    return JSONResponse(dpp_validation(n=int(body.get("n", 100)),
                                       years=int(body.get("years", 3)),
                                       seed=int(body.get("seed", 2))))


@app.get("/biology", response_class=HTMLResponse)
def biology_page():
    with open(os.path.join(HERE, "console", "biology.html"), encoding="utf-8") as f:
        return HTMLResponse(f.read(), headers={"Cache-Control": "no-store, max-age=0"})


@app.get("/api/biology/reference")
def api_biology_reference():
    from ..engines.biology import biology_reference

    return JSONResponse(biology_reference())


@app.get("/api/biology")
def api_biology(req: Request):
    """Authorized active-context parameters and explicitly bounded model readouts."""
    require_operator_auth(req)
    _ensure_selected_state()
    from ..engines.biology import biology_state
    with _model_source_authority.observation():
        twin = _state["tw"]
        before = _view_context_id(twin, _current_snapshot())
        if twin is None:
            from .clinical_views import unavailable_biology
            biology = unavailable_biology()
        else:
            biology = biology_state(twin)
        after = _view_context_id(twin, _current_snapshot())
        if before != after:
            return JSONResponse({"error": "Biology context changed; refresh to load a consistent view",
                                 "code": "BIOLOGY_CONTEXT_CHANGED"}, status_code=503)
        return JSONResponse({**biology, "context_id": after, "model_availability": _model_availability()})


@app.get("/api/structure")
async def api_structure(request: Request) -> Response:
    """Resolve an admitted reference identity, without remote first-hit discovery."""
    return await _molecular_reference_response(request)


@app.get("/api/molecular/structures/{coordinate_sha256}/coordinates")
async def molecular_coordinates(coordinate_sha256: str, request: Request) -> Response:
    """Return exact public coordinates, not the selected person's molecular state."""
    return await _molecular_reference_response(request, coordinate_sha256)


async def _molecular_reference_response(request: Request, digest: str | None = None) -> Response:
    headers = {**_atlas_response_headers(), "X-Content-Type-Options": "nosniff"}
    try:
        require_operator_auth(request)
    except HTTPException as error:
        return JSONResponse({"detail": error.detail}, status_code=error.status_code, headers=headers)

    operation = "metadata" if digest is None else "coordinates"
    asset_id = None
    outcome = "MOLECULAR_INVALID_REQUEST"
    response = JSONResponse({"code": outcome, "error": "Molecular reference request is invalid."},
                            status_code=422, headers=headers)

    async def empty_body() -> bool:
        async for chunk in request.stream():
            if chunk:
                return False
        return True

    try:
        raw_query = request.scope.get("query_string", b"")
        valid_shape = len(raw_query) <= 256 and request.headers.get("content-length", "0") == "0"
        query = request.query_params.multi_items() if valid_shape else []
        valid_shape = valid_shape and (query == [] if digest is not None else
                                       len(query) == 1 and query[0][0] == "gene")
        if valid_shape:
            try:
                valid_shape = await asyncio.wait_for(empty_body(), timeout=1)
            except TimeoutError:
                # Bound request-body admission without misclassifying source timeouts.
                valid_shape = False
        if valid_shape:
            from .. import molecular_reference as source

            try:
                if digest is None:
                    result = await asyncio.to_thread(source.lookup, query[0][1])
                    descriptor = result["reference"]
                    asset_id, outcome = result["pdb"], result["status"]
                    response = JSONResponse({**result,
                        "resolution": descriptor["resolution_angstrom"] if descriptor else None,
                        "method": descriptor["method"] if descriptor else None}, headers=headers)
                else:
                    raw, descriptor = await asyncio.to_thread(source.read_coordinates, digest)
                    asset_id, outcome = descriptor["pdb_id"], "REFERENCE_AVAILABLE"
                    response = Response(raw, media_type="chemical/x-cif", headers={
                        **headers, "X-Content-SHA256": descriptor["coordinate_sha256"],
                        "X-Livemore-Evidence-State": "REFERENCE_ONLY"})
            except source.MolecularReferenceError as error:
                statuses = {"MOLECULAR_INVALID_TARGET": 422, "MOLECULAR_NOT_FOUND": 404,
                            "MOLECULAR_SOURCE_UNAVAILABLE": 503}
                outcome = error.code if error.code in statuses else "MOLECULAR_SOURCE_UNAVAILABLE"
                response = JSONResponse({"code": outcome, "error": str(error)},
                                        status_code=statuses[outcome], headers=headers)
    except Exception:
        outcome = "MOLECULAR_SOURCE_UNAVAILABLE"
        response = JSONResponse({"code": outcome, "error": "Molecular reference is unavailable."},
                                status_code=503, headers=headers)

    # Construct the full response first, but release none of it without a durable
    # access event. Neither caller text nor a twin identifier enters this record.
    try:
        from .. import audit
        await asyncio.to_thread(audit.record, "molecular.reference.read",
            {"operation": operation, "asset_id": asset_id}, {"outcome": outcome},
            prov={"scope": "public_molecular_reference",
                  "source_sha256": headers.get("X-Livemore-Source-Sha256"),
                  "process_instance": headers["X-Livemore-Process-Instance"]}, strict=True)
    except Exception:
        return JSONResponse({"code": "MOLECULAR_AUDIT_UNAVAILABLE", "error": "Reference access audit is unavailable."},
                            status_code=503, headers=headers)
    return response


def _resolve_compound(name, refresh=False):
    """Resolve a compound to real targets: curated ChEMBL mechanism-of-action first, then
    measured bioactivity fallback. Retries once on a transient network timeout. Successful
    resolutions persist to disk (rcache) and are served instantly on later calls — surviving
    restarts and shielding the endpoint from ChEMBL latency. Failures/timeouts are never
    cached. refresh=True forces a live re-fetch and overwrites the cached entry.
    Returns (info, source). Lives in the server layer; the engines are untouched."""
    from . import rcache
    from ..engines import drug_targets as DT
    key = "resolve:" + name.strip().lower()
    if not refresh:
        hit = rcache.get(key)
        if hit and hit.get("info", {}).get("resolved"):
            return hit["info"], hit["source"]

    def _timed_out(d):
        e = str(d.get("error", "")).lower()
        return "timeout" in e or "timed out" in e
    info = DT.resolve_drug(name)
    if not info.get("resolved") and _timed_out(info):
        DT.resolve_drug.cache_clear()
        info = DT.resolve_drug(name)
    if info.get("resolved"):
        rcache.put(key, {"info": info, "source": "chembl-moa"})
        return info, "chembl-moa"
    bio = DT.resolve_bioactive(name)
    if not bio.get("resolved") and _timed_out(bio):
        DT.resolve_bioactive.cache_clear()
        bio = DT.resolve_bioactive(name)
    if bio.get("resolved"):
        rcache.put(key, {"info": bio, "source": "chembl-bioactivity"})
        return bio, "chembl-bioactivity"
    return info, "chembl-moa"


@app.get("/api/resolve")
def api_resolve(compound: str = "", refresh: bool = False):
    """Resolve ANY compound to real molecular targets (ChEMBL curated mechanism first,
    then measured bioactivity fallback), flag which targets sit in the genome-scale model,
    and attach the Open Targets disease signature. Live lookup — no compound is hand-coded.
    The full preview persists to disk (rcache); repeat lookups are instant and offline.
    Pass refresh=true to force a live re-fetch. This is the preview behind the experiment
    builder's command/search input."""
    from . import rcache
    from ..engines import metabolism as MB
    from ..engines.disease_links import exposure_disease_signature
    name = (compound or "").strip()
    if not name:
        return JSONResponse({"compound": "", "resolved": False, "targets": []})
    pkey = "preview:" + name.lower()
    if not refresh:
        hit = rcache.get(pkey)
        if hit:
            return JSONResponse({**hit, "cached": True})
    info, source = _resolve_compound(name, refresh=refresh)
    targets = info.get("targets", [])
    try:
        model = MB.load_recon3d()
        for t in targets:
            t["in_model"] = bool(MB._find_gene(model, t["gene"]))
    except Exception:
        for t in targets:
            t["in_model"] = False
    genes = [t["gene"] for t in targets]
    diseases = exposure_disease_signature(genes, top=6) if genes else []
    out = {"compound": name, "resolved": bool(info.get("resolved")),
           "chembl_id": info.get("chembl_id"), "source": source,
           "targets": targets,
           "n_in_model": sum(1 for t in targets if t.get("in_model")),
           "disease_signature": diseases, "error": info.get("error")}
    if out["resolved"]:
        rcache.put(pkey, out)
    return JSONResponse({**out, "cached": False})


@app.post("/api/experiment")
async def api_experiment(req: Request):
    """Reference target annotations cannot authorize a physiological intervention."""
    return JSONResponse({
        "error": "No qualified compound-to-physiology mapping exists for this legacy endpoint. Use a supported Cendos protocol; target lookup is reference evidence only.",
        "code": "UNSUPPORTED_BIOLOGICAL_INTERVENTION",
        "twin_modified": False,
        "supported_protocols": "/api/cendos/protocols",
    }, status_code=422)


@app.get("/api/vocab")
def api_vocab():
    """Real substrate vocabulary for the custom-human builder: clinical conditions and
    risk-locus variants derived from the knowledge base (Disease Ontology / Orphanet / KEGG /
    Reactome cross-links). Nothing hand-coded — the builder form is populated from the
    substrate, so any grounded human is constructed from real biology."""
    from ..life_system.knowledge import get_kb, _name_of
    kb = get_kb()
    conditions = sorted({_name_of(d) for d in kb.diseases if _name_of(d)})
    variants = sorted(g for g in kb.variants.keys() if g and g.strip())
    vmeta = {g: {"axes": list(kb.variants[g].get("axes", [])),
                 "diseases": list(kb.variants[g].get("diseases", []) or [])[:3]}
             for g in variants}
    return JSONResponse({"conditions": conditions, "variants": variants,
                         "variant_meta": vmeta,
                         "n_conditions": len(conditions), "n_variants": len(variants)})


@app.get("/patch", response_class=HTMLResponse)
def patch_page():
    with open(os.path.join(HERE, "console", "patch.html"), encoding="utf-8") as f:
        return HTMLResponse(f.read(), headers={"Cache-Control": "no-store, max-age=0"})


@app.post("/api/patch/virtual", status_code=202)
async def request_virtual_patch_sample(req: Request):
    """Forward explicit virtual telemetry, never infer a source from mutable state."""
    _require_numerical_model()
    from .research_api import body as strict_body
    try:
        body = await strict_body(req)
    except (ValueError, TypeError):
        return JSONResponse({"error": "invalid virtual patch body"}, status_code=422)
    if not isinstance(body, dict):
        return JSONResponse({"error": "virtual patch body must be a JSON object"}, status_code=400)
    def read_source():
        _assert_numerical_available()
        record = _subject_registry().active_twin()
        _require_matching_selected_record(record)
        return _model_source_authority.generation, record

    generation, active_record = _model_source_authority.capture(read_source)
    active_subject = active_record["subject_id"]
    supplied = body.get("envelope", body)
    if not isinstance(supplied, dict):
        return JSONResponse({"error": "invalid virtual envelope"}, status_code=422)
    supplied_subject = str(supplied.get("subject_id", "")).strip()
    if supplied_subject and supplied_subject != active_subject:
        return JSONResponse({
            "error": "virtual Patch subject does not match the active twin",
            "code": "PATCH_SUBJECT_BINDING_INVALID",
        }, status_code=409)
    virtual_bindings = [
        item for item in active_record.get("patch_bindings", [])
        if item.get("mode") == "virtual"
    ]
    supplied_device = str(supplied.get("device_id", "")).strip()
    if supplied_device:
        binding = next(
            (item for item in virtual_bindings if item.get("device_id") == supplied_device),
            None,
        )
        if binding is None:
            return JSONResponse({
                "error": "virtual Patch device is not bound to the active twin",
                "code": "PATCH_DEVICE_BINDING_INVALID",
            }, status_code=409)
    elif virtual_bindings:
        binding = virtual_bindings[-1]
    else:
        return JSONResponse({
            "error": "bind a virtual LIFE Patch to the active twin before requesting telemetry",
            "code": "PATCH_BINDING_REQUIRED",
        }, status_code=409)
    if "envelope" in body:
        if (supplied_subject != active_subject or supplied_device != binding["device_id"]
                or supplied.get("protocol_version") != binding.get("protocol_version", "2.0")
                or supplied.get("mode") != "virtual"):
            return JSONResponse({"error": "virtual envelope binding mismatch"}, status_code=409)
    else:
        if ("protocol_version" in body and body["protocol_version"] != binding.get("protocol_version", "2.0")):
            return JSONResponse({"error": "virtual sampling protocol differs from bound device"}, status_code=409)
        body["subject_id"] = active_subject
        body["device_id"] = binding["device_id"]
        body["protocol_version"] = binding.get("protocol_version", "2.0")

    try:
        def forward():
            _model_source_authority.capture(read_source, expected_generation=generation)
            return _forward_virtual_patch(body)

        status, payload = await asyncio.to_thread(forward)
        payload = _model_source_authority.capture(lambda: payload, expected_generation=generation)
        return JSONResponse(payload, status_code=status)
    except (SourceGenerationConflict, SourceSelectionUnconfirmed, ModelContextError):
        raise
    except Exception:
        return JSONResponse(
            {"error": "LIFE is unavailable", "hint": "start all services with `livemore start`"},
            status_code=502,
        )


def _forward_virtual_patch(body: dict) -> tuple[int, dict]:
    from .. import registry
    from ..security import authorization_headers

    base = (os.environ.get("LIVEMORE_LIFE_URL", "").strip()
            or registry.url_of("LIFE") or "http://127.0.0.1:8851")
    request = urllib.request.Request(
        base + "/patch/virtual/sample",
        data=json.dumps(body).encode("utf-8"),
        method="POST",
        headers={"Content-Type": "application/json", **authorization_headers()},
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            return response.status, json.loads(response.read())
    except urllib.error.HTTPError as error:
        return error.code, json.loads(error.read())


@app.get("/api/patch")
def api_patch(req: Request):
    """Inspect recorded model outputs and admitted measurements as separate classes."""
    require_operator_auth(req)
    _ensure_selected_state()
    from ..life_patch.observation_view import observation_channel
    with _model_source_authority.observation():
        tw = _state["tw"]
        st = _current_snapshot()
        subject = deepcopy(_state.get("subject"))
    unavailable = st["model_availability"]["state"] == "UNAVAILABLE"
    m, c = st["metabolic"] or {}, st["cardiac"] or {}
    patch = st.get("patch", {})
    observations = st.get("observations", {})
    t = m.get("t_min", [])

    def series(vals):
        return [[round(float(t[i]), 1), round(float(vals[i]), 2)] for i in range(min(len(t), len(vals)))]

    _hrser = c.get("hr_series") or []
    live = [] if unavailable else [
        {"id": "glucose", "label": "Modeled glucose", "unit": "mg/dL", "status": "recorded",
         "data_class": "modeled", "provenance": "synthetic-from-engine", "series": series(m["glucose"]), "lo": 70, "hi": 180,
         "current": round(float(m["glucose"][-1]), 1)},
        {"id": "insulin", "label": "Modeled insulin", "unit": "\u00b5U/mL", "status": "recorded",
         "data_class": "modeled", "provenance": "synthetic-from-engine", "series": series(m["insulin"]), "lo": 2, "hi": 25,
         "current": round(float(m["insulin"][-1]), 2)},
        {"id": "hr", "label": "Modeled heart rate", "unit": "bpm", "status": "recorded",
         "data_class": "modeled", "provenance": "synthetic-from-engine", "series": _hrser, "lo": 50, "hi": 110,
         "current": (_hrser[-1][1] if _hrser else c.get("hr_bpm"))},
        {"id": "hrv", "label": "Modeled HRV (RMSSD)", "unit": "ms", "status": "recorded",
         "data_class": "modeled", "provenance": "synthetic-from-engine", "flat": c.get("hrv_ms", 0),
         "lo": 5, "hi": 80, "current": c.get("hrv_ms", 0)},
    ]
    observed = [observation_channel(signal, item) for signal, item in observations.items()]
    live = observed + live
    # Drug plasma concentration — live only when the hepatic PK engine has a dose.
    pk = st.get("hepatic")
    if pk:
        day_min = float(t[-1]) if len(t) else 840.0
        pkser = [[round(h * 60.0, 1), c] for h, c in zip(pk["t_h"], pk["conc_mg_L"])
                 if h * 60.0 <= day_min]
        live.append({"id": "drug_plasma", "label": f"Drug plasma \u2014 {pk['drug']}",
                     "unit": "mg/L", "status": "recorded", "data_class": "modeled", "provenance": "synthetic-from-engine",
                     "series": pkser, "lo": 0, "hi": max(0.5, pk["cmax_mg_L"] * 1.2),
                     "current": (pkser[-1][1] if pkser else 0.0)})
    pending_spec = [
        ("skin_temp", "Skin temperature", "°C"),
        ("lactate", "Lactate", "mmol/L"), ("cortisol", "Cortisol", "\u00b5g/dL"),
        ("sodium", "Sodium (Na\u207a)", "mmol/L"), ("potassium", "Potassium (K\u207a)", "mmol/L"),
        ("chloride", "Chloride (Cl\u207b)", "mmol/L"), ("urea", "Urea", "mg/dL"),
        ("ammonium", "Ammonium (NH\u2084\u207a)", "\u00b5mol/L"), ("ethanol", "Ethanol", "mg/dL"),
        ("spo2", "SpO\u2082", "%"), ("motion", "Motion / activity", "g"),
    ]
    pending = [{"id": i, "label": l, "unit": u, "status": "pending", "data_class": "pending",
                "provenance": "engine pending"} for i, l, u in pending_spec]
    if not pk:
        pending.insert(0, {"id": "drug_plasma", "label": "Drug plasma (hepatic PK)",
                           "unit": "mg/L", "status": "pending", "data_class": "pending",
                           "provenance": "model binding required" if unavailable else "engine ready \u2014 no dose applied yet"})
    n_live = sum(channel["status"] == "live" for channel in live)
    n_nominal = sum(channel["status"] == "nominal" for channel in live)
    return JSONResponse({
        "profile": st["profile"],
        "subject": subject or st.get("human") or {"id": st["profile"]},
        "model_availability": st["model_availability"],
        "t_min": [round(float(x), 1) for x in t],
        "day_minutes": round(float(t[-1]), 0) if len(t) else None,
        "context_id": _view_context_id(tw, st),
        "time_basis": "observation_acquisition_clocks_only" if unavailable else "recorded_model_minutes_not_wall_clock",
        "connection_verified": False,
        "patch": patch, "hardware_present": bool(patch.get("hardware_present")),
        "channels": live + pending, "n_live": n_live, "n_nominal": n_nominal,
        "n_recorded": sum(channel["status"] == "recorded" for channel in live),
        "n_recent_observed": sum(channel["status"] == "recent" for channel in observed),
        "n_pending": len(pending),
        "contract": {
            "schema": "livemore.life-patch.telemetry.v3" if str(patch.get("protocol_version", "")).startswith("3.") else "livemore.life-patch.telemetry.v2",
            "hardware_target": "B0-EVT-target",
            "mode": patch.get("mode"),
            "protocol_version": patch.get("protocol_version"),
            "sequence": patch.get("sequence"),
            "envelope_id": patch.get("envelope_id"),
            "rule": "telemetry updates observed state; calibration requires released evidence authorization",
        },
        "applied": st.get("applied", []), "intervention": st.get("intervention"),
    })


@app.get("/api/events")
def api_events(req: Request, after: float = 0.0):
    require_operator_auth(req)
    """Poll the cross-system event bus — Aegle perturbations, Cendos assays, and any other
    service activity — so the console can show real-time cross-system state without polling
    each service. Returns real published events only."""
    import time as _t
    from .. import bus
    return JSONResponse({"events": bus.events(after_ts=float(after), limit=60), "now": _t.time()})


@app.get("/api/audit")
def api_audit(req: Request, limit: int = 50, action: str = ""):
    """List signed audit records from the append-only pipeline log, each verified
    against its timestamp-independent result fingerprint and HMAC signature.
    Clients (consoles, SDK, pharma reviewers) use this to confirm that reported
    results reproduce exactly. Returns real log records only — no log, no rows."""
    require_operator_auth(req)
    import json as _json
    from .. import audit as _audit
    try:
        with open(_audit.LOG_PATH, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except FileNotFoundError:
        lines = []
    records = []
    for line in lines[-max(1, min(int(limit), 500)):]:
        try:
            rec = _json.loads(line)
        except Exception:
            continue
        if action and rec.get("action") != action:
            continue
        records.append({
            "id": rec.get("id"), "ts": rec.get("ts"), "action": rec.get("action"),
            "result_sha256": rec.get("result_sha256"), "alg": rec.get("alg"),
            "verified": _audit.verify(rec),
        })
    records.reverse()
    return JSONResponse({"records": records, "count": len(records),
                         "log_path": _audit.LOG_PATH,
                         "note": "verified = fingerprint reproduces AND HMAC signature valid"})


@app.get("/api/audit/{record_id}")
def api_audit_record(record_id: str, req: Request):
    """Fetch one full audit record (inputs, outputs, provenance) with verification."""
    require_operator_auth(req)
    import json as _json
    from .. import audit as _audit
    try:
        with open(_audit.LOG_PATH, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    rec = _json.loads(line)
                except Exception:
                    continue
                if rec.get("id") == record_id:
                    rec["verified"] = _audit.verify(rec)
                    return JSONResponse(rec)
    except FileNotFoundError:
        pass
    return JSONResponse({"error": f"no audit record {record_id}"}, status_code=404)


@app.get("/cendos", response_class=HTMLResponse)
def cendos_page():
    with open(os.path.join(HERE, "console", "cendos.html"), encoding="utf-8") as f:
        return HTMLResponse(f.read(), headers={"Cache-Control": "no-store, max-age=0"})


@app.get("/adapters", response_class=HTMLResponse)
def adapters_page():
    with open(os.path.join(HERE, "console", "adapters.html"), encoding="utf-8") as f:
        return HTMLResponse(f.read(), headers={"Cache-Control": "no-store, max-age=0"})


def _cendos_url():
    try:
        from .. import registry
        return (os.environ.get("LIVEMORE_CENDOS_URL", "").strip()
                or registry.url_of("Cendos") or "http://127.0.0.1:8852")
    except Exception:
        return "http://127.0.0.1:8852"


def _capture_cendos_source(request_id: str) -> dict:
    from ..cendos.current_source import make_source_envelope
    from ..execution_client import ContinuousClientError

    def read():
        _assert_numerical_available()
        availability = _model_availability()
        summary = _state.get("subject")
        if summary is not None:
            record = _subject_registry().audited_active_twin(action="source_capture", request_id=request_id)
            _require_matching_selected_record(record)
            retained = model_availability(record, source_generation=availability["source_generation"])
            if retained["state"] != "READY":
                raise ModelContextError(retained["reason_code"])
        state = _state["tw"].state()
        snapshot = {key: state.get(key) for key in
                    ("profile", "profile_params", "pk_context", "parameter_provenance")}
        snapshot.update(subject=summary, model_availability=availability)
        try:
            return make_source_envelope(snapshot)
        except ContinuousClientError:
            raise ModelContextError("MODEL_CONTEXT_INVALID") from None

    return _model_source_authority.capture(read)


@app.get("/api/cendos/current-source")
async def cendos_current_source(req: Request):
    require_operator_auth(req)
    request_id = str(uuid4())
    headers = {"Cache-Control": "no-store", "X-Request-ID": request_id}
    if req.query_params:
        return JSONResponse({"code": "CLIENT_INVALID", "error": "Source capture accepts no query fields."}, status_code=422, headers=headers)
    async for chunk in req.stream():
        if chunk:
            return JSONResponse({"code": "CLIENT_INVALID", "error": "Source capture accepts no request body."}, status_code=422, headers=headers)
    try:
        _ensure_selected_state()
        return JSONResponse(_capture_cendos_source(request_id), headers=headers)
    except (ModelContextError, SourceGenerationConflict, SourceSelectionUnconfirmed) as error:
        return JSONResponse({"code": error.code, "error": str(error)},
                            status_code=503 if isinstance(error, SourceSelectionUnconfirmed) else 409, headers=headers)
    except Exception:
        return JSONResponse({"code": "REGISTRY_STORAGE_UNAVAILABLE", "error": "Current source storage or audit cannot be confirmed."},
                            status_code=503, headers=headers)


@app.post("/api/cendos/assay")
async def cendos_assay(req: Request):
    """Bind a Cendos calculation to this Aegle's authenticated source snapshot."""
    from ..cendos.current_source import source_guard, validate_source_envelope, source_failure_response
    from ..execution_client import ContinuousClientError
    from .research_api import body as strict_body

    require_operator_auth(req)
    _require_numerical_model()
    request_id = str(uuid4())
    try:
        payload = await strict_body(req)
    except Exception:
        return JSONResponse({"error": "request body must be valid JSON"}, status_code=400)
    if not isinstance(payload, dict) or "expected_source" in payload:
        return JSONResponse({"code": "CLIENT_INVALID", "error": "The proxy accepts assay inputs, not a caller-selected source."}, status_code=422)
    try:
        captured = _capture_cendos_source(request_id)
        guard = source_guard(captured)
        forwarded = {**payload, "expected_source": guard}

        def forward():
            _model_source_authority.capture(lambda: None, expected_generation=guard["source_generation"])
            if _capture_cendos_source(request_id) != captured:
                raise SourceGenerationConflict()
            return _forward_cendos_assay(forwarded)

        result = await asyncio.to_thread(forward)
        returned_source = validate_source_envelope(result.get("assayed_source"))
        _model_source_authority.capture(lambda: None, expected_generation=guard["source_generation"])
        if returned_source != captured or _capture_cendos_source(request_id) != captured:
            raise SourceGenerationConflict()
        return JSONResponse(result, headers={"Cache-Control": "no-store", "X-Request-ID": request_id})
    except (SourceGenerationConflict, SourceSelectionUnconfirmed, ModelContextError):
        raise
    except ContinuousClientError as error:
        return source_failure_response(error)
    except Exception:
        return JSONResponse({"code": "REGISTRY_STORAGE_UNAVAILABLE", "error": "Current assay source or service cannot be confirmed."},
                            status_code=503, headers={"Cache-Control": "no-store", "X-Request-ID": request_id})


def _forward_cendos_assay(body: dict) -> dict:
    from ..cendos.current_source import CurrentAssayClient
    return CurrentAssayClient().assay(body)


@app.get("/api/cendos/compound")
def cendos_compound(name: str = ""):
    import urllib.request
    import urllib.parse
    import json as _j
    url = _cendos_url() + "/compound?name=" + urllib.parse.quote(name)
    try:
        with urllib.request.urlopen(url, timeout=12) as r:
            return JSONResponse(_j.loads(r.read()))
    except Exception as e:
        return JSONResponse({"name": name, "resolved": False, "error": type(e).__name__},
                            status_code=502)


# ---------------------------------------------------------------------------
# Evidence packages (§33) — real model-only packages from actual experiment
# runs, bridged to the merged livemorebio.evidence system. Nothing synthetic
# is ever labeled as validation: claim state is derived by the policy engine.
# ---------------------------------------------------------------------------

@app.get("/api/evidence")
def api_evidence_list(req: Request):
    require_operator_auth(req)
    from . import evidence_api as ev
    try:
        packages = [ev.summarize(p) for p in ev.service().list(ev.TENANT)]
        packages.sort(key=lambda x: x["created_at"], reverse=True)
        return JSONResponse({"packages": packages, "count": len(packages),
                             "tenant": ev.TENANT})
    except Exception as e:
        return JSONResponse({"error": f"{type(e).__name__}: {e}"}, status_code=500)


@app.post("/api/evidence")
async def api_evidence_create(req: Request):
    """Retired browser intake cannot send unverified person data to plaintext storage."""
    # Do not read a potentially PHI-like body. The successor resolves a frozen
    # server run and stores admitted research evidence in the encrypted store.
    return JSONResponse({
        "error": "Legacy evidence intake is disabled; freeze a stored Cendos run in Research",
        "code": "LEGACY_EVIDENCE_INTAKE_DISABLED",
        "supported_workflow": "/api/research/studies",
    }, status_code=409)


@app.get("/api/evidence/{package_id}")
def api_evidence_detail(package_id: str, req: Request):
    require_operator_auth(req)
    from . import evidence_api as ev
    try:
        return JSONResponse(ev.detail(ev.service().get(ev.TENANT, package_id)))
    except KeyError:
        return JSONResponse({"error": f"no evidence package {package_id}"}, status_code=404)
    except Exception as e:
        msg = f"{type(e).__name__}: {e}"
        code = 404 if "not found" in str(e).lower() else 500
        return JSONResponse({"error": msg}, status_code=code)


@app.post("/api/evidence/{package_id}/export")
def api_evidence_export(package_id: str):
    """Export only an independently reviewed and locked evidence archive."""
    from fastapi.responses import FileResponse
    from . import evidence_api as ev
    from ..evidence.errors import NotFoundError
    private_headers = {"Cache-Control": "no-store"}
    try:
        zpath = ev.export_zip(package_id)
        return FileResponse(zpath, media_type="application/zip",
                            filename=os.path.basename(zpath), headers=private_headers)
    except (KeyError, NotFoundError):
        return JSONResponse({"error": "Evidence package not found"}, status_code=404, headers=private_headers)
    except ValueError:
        return JSONResponse({"error": "Independent evidence review is required before export",
                             "code": "EVIDENCE_REVIEW_REQUIRED"}, status_code=409, headers=private_headers)
    except Exception:
        return JSONResponse({"error": "Evidence export unavailable",
                             "code": "EVIDENCE_EXPORT_UNAVAILABLE"}, status_code=503, headers=private_headers)


# ---------------------------------------------------------------------------
# Real-anatomy meshes — cached HRA / BodyParts3D geometry with provenance.
# Served same-origin so the body view keeps working offline once warm.
# ---------------------------------------------------------------------------


@app.get("/favicon.ico")
def favicon():
    """Tiny inline SVG mark (biolume dot on teal) — keeps client consoles clean."""
    from fastapi.responses import Response
    svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">'
           '<rect width="16" height="16" rx="3" fill="#0a3d3a"/>'
           '<circle cx="8" cy="8" r="4" fill="#46d6c1"/></svg>')
    return Response(svg, media_type="image/svg+xml",
                    headers={"Cache-Control": "public, max-age=86400"})


@app.get("/api/anatomy/manifest")
def anatomy_manifest():
    """Catalog + cache status + provenance for every real-anatomy asset."""
    from ..anatomy import meshes as AM
    return JSONResponse({"assets": AM.manifest()})


_ATLAS_ASSET_KEYS = frozenset({
    "skin", "heart", "liver", "pancreas", "right-kidney", "left-kidney",
    "right-lung", "left-lung", "brain",
})
_ATLAS_PRIVATE_HEADERS = {"Cache-Control": "private, no-store"}


def _atlas_response_headers() -> dict[str, str]:
    """Tie reference replies to this process's startup code, never edited files."""
    from ..build_info import build_identity
    identity = build_identity()
    headers = dict(_ATLAS_PRIVATE_HEADERS)
    if identity["source_sha256"] is not None:
        headers["X-Livemore-Source-Sha256"] = identity["source_sha256"]
    headers["X-Livemore-Process-Instance"] = identity["process_instance"]
    return headers


def _atlas_reference_failure(error: Exception, atlas: ModuleType | None = None) -> JSONResponse:
    """Keep source/cache failures inspectable without echoing paths or input."""
    headers = _atlas_response_headers()
    if isinstance(error, HTTPException):
        return JSONResponse({"detail": error.detail}, status_code=error.status_code, headers=headers)
    if atlas is not None and isinstance(error, atlas.AtlasReferenceError):
        if error.retry_after is not None:
            headers["Retry-After"] = str(error.retry_after)
        return JSONResponse({"code": error.code, "error": str(error)},
                            status_code=error.status_code, headers=headers)
    logger.error("Atlas reference operation unavailable (error_type=%s)", type(error).__name__)
    return JSONResponse({"code": "ATLAS_UNAVAILABLE", "error": "Atlas reference is unavailable; inspect source status."},
                        status_code=503, headers=headers)


@app.get("/api/anatomy/atlas-reference")
def atlas_reference_status() -> JSONResponse:
    """Read reference readiness only; never acquire geometry or access a twin."""
    atlas = None
    try:
        from ..anatomy import atlas_reference as atlas
        return JSONResponse(atlas.status(), headers=_atlas_response_headers())
    except Exception as error:
        return _atlas_reference_failure(error, atlas)


@app.post("/api/anatomy/atlas-reference/install")
async def install_atlas_reference(request: Request) -> JSONResponse:
    """Explicit fixed-source installation; the installer owns its bounded lock."""
    require_operator_auth(request)
    from ..strict_json import StrictJSONError, parse_json_object

    atlas = None
    try:
        raw = bytearray()
        async for chunk in request.stream():
            if len(raw) + len(chunk) > 1024:
                raise StrictJSONError("Atlas installation request exceeds its byte limit")
            raw.extend(chunk)
        payload = parse_json_object(raw, max_bytes=1024)
        from ..anatomy import atlas_reference as atlas
        if payload != {"source_id": atlas.SOURCE_ID}:
            raise StrictJSONError("Select the fixed reviewed Atlas source only")
        # A disconnected caller must inspect status, not automatically repeat POST.
        # The source installer, not this thread wrapper, enforces conversion limits.
        result = await asyncio.to_thread(atlas.install, atlas.SOURCE_ID)
        return JSONResponse(result, headers=_atlas_response_headers())
    except StrictJSONError:
        return JSONResponse({"code": "ATLAS_INVALID_REQUEST", "error": "Provide only the reviewed source_id as bounded JSON."},
                            status_code=422, headers=_atlas_response_headers())
    except Exception as error:
        return _atlas_reference_failure(error, atlas)


@app.get("/assets/anatomy/atlas/{manifest_sha256}/{asset_key}.glb")
def atlas_reference_asset(manifest_sha256: str, asset_key: str, request: Request) -> Response:
    """Serve the same verified immutable bytes; internal distribution only."""
    atlas = None
    try:
        require_operator_auth(request)
        if not re.fullmatch(r"[0-9a-f]{64}", manifest_sha256) or asset_key not in _ATLAS_ASSET_KEYS:
            return JSONResponse({"code": "ATLAS_NOT_FOUND", "error": "Atlas reference asset not found."},
                                status_code=404, headers=_atlas_response_headers())
        from ..anatomy import atlas_reference as atlas
        content, metadata = atlas.read_asset(manifest_sha256, asset_key)
        digest = hashlib.sha256(content).hexdigest()
        if (metadata.get("manifest_sha256") != manifest_sha256 or metadata.get("asset_key") != asset_key
                or metadata.get("source_id") != atlas.SOURCE_ID or metadata.get("sha256") != digest
                or metadata.get("bytes") != len(content)):
            raise ValueError("Atlas byte/identity contract mismatch")
        return Response(content, media_type="model/gltf-binary", headers={
            **_atlas_response_headers(), "X-Content-Type-Options": "nosniff",
            "X-Content-SHA256": digest, "X-Atlas-Manifest-SHA256": manifest_sha256,
        })
    except Exception as error:
        return _atlas_reference_failure(error, atlas)


@app.get("/assets/anatomy/{key}.glb")
def anatomy_mesh(key: str):
    """Serve (acquiring on first request) the real-anatomy GLB for an organ.

    There is deliberately no fallback geometry: if the real mesh cannot be
    obtained the route reports the failure honestly instead of substituting.
    """
    from fastapi.responses import Response
    from ..anatomy import meshes as AM
    if key not in AM.CATALOG:
        return JSONResponse({"error": f"no anatomy asset {key!r}"}, status_code=404)
    try:
        content, prov = AM.read_asset(key)
    except Exception as error:
        acquiring = isinstance(error, TimeoutError)
        return JSONResponse(
            {"error": "Anatomy acquisition is in progress; retry shortly" if acquiring else "Anatomy asset is unavailable; retry acquisition",
             "code": "ANATOMY_ACQUIRING" if acquiring else "ANATOMY_UNAVAILABLE",
             "source": AM.CATALOG[key].get("url") or AM.CATALOG[key].get("archive")},
            status_code=503, headers={"Retry-After": "3"})
    return Response(content, media_type="model/gltf-binary",
                    headers={"Cache-Control": "public, max-age=86400",
                             "X-Anatomy-Source": prov["source"],
                             "X-Anatomy-License": prov["license"],
                             "X-Anatomy-Sha256": prov["sha256"]})


# ---------------------------------------------------------------------------
# Shared console assets — ES modules + design tokens under console/lib/
# ---------------------------------------------------------------------------

_LIB_MIME = {".js": "application/javascript; charset=utf-8",
             ".mjs": "application/javascript; charset=utf-8",
             ".css": "text/css; charset=utf-8",
             ".svg": "image/svg+xml", ".json": "application/json"}


@app.get("/lib/{asset:path}")
def console_lib(asset: str):
    from fastapi.responses import Response
    root = os.path.realpath(os.path.join(HERE, "console", "lib"))
    path = os.path.realpath(os.path.join(root, asset))
    if not path.startswith(root + os.sep) or not os.path.isfile(path):
        return JSONResponse({"error": f"no console asset {asset}"}, status_code=404)
    ext = os.path.splitext(path)[1].lower()
    with open(path, "rb") as f:
        return Response(f.read(), media_type=_LIB_MIME.get(ext, "application/octet-stream"),
                        headers={"Cache-Control": "no-store, max-age=0"})


# ---------------------------------------------------------------------------
# Cohort screen — the SDK pharma workflow exposed to the console (Screen panel).
# ---------------------------------------------------------------------------


@app.post("/api/screen")
async def api_screen(req: Request):
    """Run the deterministic cohort compound screen server-side via the in-process SDK
    (seeded cohort → per-twin PK-linked OGTT → ranked hypothesis result).
    Platform(mode="inprocess")
    builds its OWN isolated twin — the live console twin (_state["tw"]) is untouched.
    Phase 1 admits only an explicit T2D-enriched cohort + OGTT context. Every
    completed result is persisted under a unique run id; no process-global
    "last result" can leak across browser sessions."""
    try:
        body = await req.json()
    except Exception:
        return JSONResponse({"error": "request body must be valid JSON"}, status_code=400)
    if not isinstance(body, dict):
        return JSONResponse({"error": "request body must be a JSON object"}, status_code=400)
    raw_compound = body.get("compound", "")
    if not isinstance(raw_compound, str):
        return JSONResponse({"error": "compound must be a string"}, status_code=400)
    compound = raw_compound.strip()
    if not compound:
        return JSONResponse({"error": "missing compound"}, status_code=400)
    if len(compound) > 200:
        return JSONResponse({"error": "compound exceeds 200 characters"}, status_code=400)
    try:
        n = int(body.get("n", 30))
        seed = int(body.get("seed", 0))
        dose = float(body.get("dose", 1.0))
        grams = float(body.get("grams", 75.0))
        mode = str(body.get("mode", "auto"))
        indication = str(body.get("indication", "type-2-diabetes"))
        cohort = str(body.get("cohort", "t2d-enriched"))
        assay = str(body.get("assay", "ogtt"))
    except (TypeError, ValueError) as e:
        return JSONResponse({"error": f"bad parameter: {e}"}, status_code=400)
    if not (1 <= n <= 60):
        return JSONResponse({"error": f"n={n} out of range (1..60) — the screen is "
                                      "synchronous; larger cohorts belong in the SDK/CLI"},
                            status_code=400)
    if not math.isfinite(dose) or not (0 < dose <= 5):
        return JSONResponse({"error": "dose must be finite and within (0, 5]"}, status_code=400)
    if not math.isfinite(grams) or not (0 < grams <= 200):
        return JSONResponse({"error": "grams must be finite and within (0, 200]"}, status_code=400)
    if not (-2_147_483_648 <= seed <= 2_147_483_647):
        return JSONResponse({"error": "seed must fit a signed 32-bit integer"}, status_code=400)
    kw = {}
    parametric_requested = mode == "parametric" or (
        mode == "auto" and any(name in body for name in
                               ("si_boost", "gb_drop", "gamma_boost"))
    )
    if parametric_requested:
        try:
            kw = {"si_boost": float(body.get("si_boost", 0.30)),
                  "gb_drop": float(body.get("gb_drop", 0.06)),
                  "gamma_boost": float(body.get("gamma_boost", 0.10))}
        except (TypeError, ValueError) as e:
            return JSONResponse({"error": f"bad parameter: {e}"}, status_code=400)
        if any(not math.isfinite(value) or not (0 <= value <= 1) for value in kw.values()):
            return JSONResponse({"error": "parametric effect fractions must be within [0, 1]"},
                                status_code=400)
    from ..sdk import Platform
    try:
        result = await asyncio.to_thread(
            Platform(mode="inprocess").screen,
            compound, dose=dose, grams=grams, n=n, seed=seed, mode=mode,
            indication=indication, cohort=cohort, assay=assay, **kw,
        )
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=422)
    except RuntimeError as e:
        message = str(e)
        if "did not resolve" in message or "refusing to screen an unresolved compound" in message:
            return JSONResponse({"error": message}, status_code=422)
        return JSONResponse({"error": "screen engine unavailable"}, status_code=503)
    except Exception as e:
        return JSONResponse({"error": f"screen unavailable: {type(e).__name__}"}, status_code=503)
    from . import screen_runs
    return JSONResponse(screen_runs.save(result, {
        "compound": compound, "dose": dose, "grams": grams, "n": n,
        "seed": seed, "mode": mode, "indication": indication,
        "cohort": cohort, "assay": assay, **kw,
    }))


@app.get("/api/screen/report.md")
def api_screen_report_md():
    """Legacy endpoint intentionally retired; reports are run-scoped."""
    return JSONResponse(
        {"error": "report requires a run id: /api/screen/{run_id}/report.md"},
        status_code=410,
    )


@app.get("/api/screen/report.audit.json")
def api_screen_report_audit():
    """Legacy endpoint intentionally retired; integrity records are run-scoped."""
    return JSONResponse(
        {"error": "audit record requires a run id: /api/screen/{run_id}/report.audit.json"},
        status_code=410,
    )


@app.get("/api/screen/{run_id}/report.md")
def api_screen_run_report_md(run_id: str):
    from fastapi.responses import PlainTextResponse
    from . import screen_runs
    envelope = screen_runs.load(run_id)
    if envelope is None:
        return JSONResponse({"error": "screen run not found"}, status_code=404)
    from ..report import screen_report_md
    return PlainTextResponse(
        screen_report_md(envelope["result"]),
        media_type="text/markdown",
        headers={"Content-Disposition":
                 f'attachment; filename="livemore-screen-{run_id}.md"'},
    )


@app.get("/api/screen/{run_id}/report.audit.json")
def api_screen_run_report_audit(run_id: str):
    from . import screen_runs
    envelope = screen_runs.load(run_id)
    if envelope is None:
        return JSONResponse({"error": "screen run not found"}, status_code=404)
    return JSONResponse(
        envelope["result"]["audit"],
        headers={"Content-Disposition":
                 f'attachment; filename="livemore-screen-{run_id}.audit.json"'},
    )


@app.get("/api/adapters")
def api_adapters():
    """Operational adapter capability, license, and configuration state."""
    from ..adapters import registry
    return JSONResponse(registry(probe=False))


@app.get("/api/scientific-sources")
def api_scientific_sources(
    collection: str | None = None,
    workflow: str | None = None,
    lifecycle: str | None = None,
    limit: int = 50,
    offset: int = 0,
):
    """Bounded catalog projection; workflow queries return runtime-wired sources only."""
    from ..scientific_sources import Catalog
    from ..scientific_sources.graph_backends import backend_registry

    try:
        report = Catalog.load().report(
            collection=collection,
            workflow=workflow,
            lifecycle=lifecycle,
            limit=limit,
            offset=offset,
        )
    except ValueError as error:
        return JSONResponse(
            {"error": str(error), "code": "INVALID_SCIENTIFIC_SOURCE_QUERY"},
            status_code=422,
        )
    report["graph_backends"] = backend_registry()
    return JSONResponse(report)


@app.post("/api/adapters/probe")
def api_adapter_probe():
    """Bounded outbound adapter checks; mutation auth prevents anonymous egress abuse."""
    from ..adapters import registry
    return JSONResponse(registry(probe=True))


if __name__ == "__main__":
    main()
