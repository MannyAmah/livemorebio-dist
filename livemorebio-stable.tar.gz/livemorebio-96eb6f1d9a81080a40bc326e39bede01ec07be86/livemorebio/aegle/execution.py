"""Engine execution lifecycle with immutable source and late-result fencing.

Callers capture through ModelSourceAuthority before entering this manager. Lock
order is authority then manager; no callback into authority, HTTP or global bus is
performed here. This local owner is not a distributed execution service.

Product admission MUST perform capture plus prepare/fork under that same
authority guard. Start/resume must check its current generation before calling.
The manager alone is not a public source-admission authority. This lets it fence
tracked records without retaining unbounded tombstones for unrelated mutations.
"""
from __future__ import annotations

from copy import deepcopy
import re
import threading
import time
from typing import Any, Callable
import uuid

from .execution_contract import (CARDIAC, METABOLIC, ExecutionError, MAX_FRAME_BYTES,
    capture_source_payload, digest, encoded, number, text, validate_checkpoint,
    validate_policy, validate_source)
from .execution_store import ExecutionStore, check_control_precondition, utc_now


# None is reserved for standalone compatibility. Uncertain product commits must
# reject every source, including work that was already calculating.
DENY_ALL = object()


class ExecutionManager:
    def __init__(self, store: ExecutionStore, adapter_registry: dict[str, Callable] | None = None,
                 *, run_background: bool = True, clock: Callable[[], float] = time.monotonic,
                 permitted_generation: str | object | None = None) -> None:
        if permitted_generation is not None and permitted_generation is not DENY_ALL:
            text(permitted_generation)
        self.store = store
        self._registry = adapter_registry
        self._lock = threading.RLock()
        self._owners: dict[str, int] = {}
        self._adapters: dict[str, Any] = {}
        self._known: set[str] = set()
        self._generations: dict[str, str] = {}
        self._permitted_generation = permitted_generation
        self._constructing: set[str] = set()
        self._activating: set[str] = set()
        self._cleanup_pending: set[str] = set()
        self._closing: set[str] = set()
        self._adapter_closed: set[str] = set()
        self._busy: set[str] = set()
        self._next_due: dict[str, float] = {}
        self._clock = clock
        self._producer_instance = uuid.uuid4().hex
        self._consumer_leases: dict[str, dict[str, Any]] = {}
        self._closed = False
        self._wake = threading.Event()
        self._lease_wake = threading.Event()
        self._thread = None
        self._lease_thread = None
        if run_background:
            self._thread = threading.Thread(target=self._run, name="aegle-execution", daemon=True)
            self._thread.start()
            # Native work may occupy the scheduling thread. Expiry must still
            # fence and cancel that owned job while its numerical call is blocked.
            self._lease_thread = threading.Thread(target=self._run_leases, name="aegle-consumer-lease", daemon=True)
            self._lease_thread.start()

    def _open(self) -> None:
        if self._closed:
            raise ExecutionError("EXECUTION_CLOSED")

    def set_source_generation(self, generation: str | object) -> None:
        """Fence identity even after shutdown; this never reopens execution."""
        if generation is not DENY_ALL:
            text(generation)
        with self._lock:
            self._permitted_generation = generation
            self._next_due.clear()

    def _allows(self, generation: str) -> bool:
        return self._permitted_generation is None or self._permitted_generation == generation

    def _valid_source(self, record: dict[str, Any]) -> bool:
        return record["source_valid"] and self._allows(record["source"]["source_generation"])

    def _require_generation(self, generation: str) -> None:
        if not self._allows(generation):
            raise ExecutionError("EXECUTION_CONFLICT")

    def _require_cleanup_settled(self) -> None:
        if self._cleanup_pending:
            raise ExecutionError("EXECUTION_CLEANUP_UNCONFIRMED")

    def _track(self, record: dict[str, Any]) -> None:
        self._known.add(record["execution_id"])
        self._generations[record["execution_id"]] = record["source"]["source_generation"]

    def prepare(self, captured_payload: dict[str, Any], policy: dict[str, Any],
                idempotency_key: str) -> dict[str, Any]:
        source = validate_source(captured_payload)
        policy = validate_policy(source, policy)
        delta = policy["frame_period_s"] * policy["time_scale"] * (1000 if source["engine_contract_id"] == CARDIAC else 1 / 60)
        if source["engine_contract_id"] == CARDIAC and min(delta, policy["end_native"]) > 4000:
            raise ExecutionError()
        with self._lock:
            self._open()
            self._require_generation(source["source_generation"])
            record = self.store.create(source, policy, idempotency_key=idempotency_key)
            self._track(record)
            return self._status(record)

    def fork_checkpoint(self, parent_execution_id: str, captured_payload: dict[str, Any], *,
                        policy: dict[str, Any], idempotency_key: str, expected_parent_revision: int) -> dict[str, Any]:
        """Explicit full-state restart; only generation may differ from parent source."""
        source = validate_source(captured_payload)
        policy = validate_policy(source, policy)
        with self._lock:
            self._open()
            self._require_generation(source["source_generation"])
            record = self.store.create(source, policy, idempotency_key=idempotency_key,
                                       parent_execution_id=parent_execution_id, expected_parent_revision=expected_parent_revision)
            self._track(record)
            return self._status(record)

    def _check(self, record: dict[str, Any], revision: int | None, generation: str, *,
               control_revision: int | None = None) -> None:
        self._open()
        check_control_precondition(record, expected_revision=revision, expected_control_revision=control_revision)
        if (record["source"]["source_generation"] != generation
                or not self._valid_source(record)):
            raise ExecutionError("EXECUTION_CONFLICT")

    def _status(self, record: dict[str, Any]) -> dict[str, Any]:
        source = record["source"]
        return {key: deepcopy(record[key]) for key in ("execution_id", "revision", "control_revision", "state", "source_valid",
                "policy", "latest_frame", "created_at", "updated_at", "failure_code", "authorship",
                "runtime_identity", "checkpoint_parent")} | {
                "source_generation": source["source_generation"], "source_snapshot_hash": source["source_snapshot_hash"],
                "selection": deepcopy(source["selection"]), "engine_contract_id": source["engine_contract_id"],
                "native_axis": deepcopy(source["native_axis"]),
                "native_time": (record["checkpoint"] or record["initial_checkpoint"] or {"native_time": 0.})["native_time"],
                "evidence_class": {"engine": "MODELED", "technical_fixture": "TECHNICAL_FIXTURE"}.get(record["authorship"], "NOT_EXECUTED"),
                "consumer_lease": self._lease_status(record),
                "source_valid": self._valid_source(record),
                "failure_code": ("EXECUTION_CLEANUP_UNCONFIRMED" if record["execution_id"] in self._cleanup_pending
                                 else record["failure_code"]),
                "independent_physical_validation": False}

    def _lease_status(self, record: dict[str, Any]) -> dict[str, Any]:
        binding = record.get("consumer_binding")
        if binding is None:
            return {"required": False, "state": "unbound", "session_id": None, "remaining_s": None}
        lease = self._consumer_leases.get(record["execution_id"])
        if lease is None or binding["producer_instance"] != self._producer_instance:
            return {"required": True, "state": "restart_required", "session_id": binding["session_id"], "remaining_s": 0.}
        remaining = max(0., lease["deadline"] - self._clock())
        state = "source_invalid" if not self._valid_source(record) else ("valid" if remaining > 0 else "expired")
        return {"required": True, "state": state, "session_id": binding["session_id"],
                "remaining_s": remaining, "renewal_count": lease["renewal_count"]}

    def _require_lease(self, record: dict[str, Any]) -> None:
        if self._lease_status(record)["state"] not in {"unbound", "valid"}:
            raise ExecutionError("EXECUTION_CONFLICT")

    def _claim_transition(self, record: dict[str, Any], changes: dict[str, Any]) -> dict[str, Any]:
        execution_id = record["execution_id"]
        acquired = execution_id not in self._owners
        if acquired:
            self._owners[execution_id] = self.store.acquire_owner(execution_id)
        try:
            return self.store.update(execution_id, expected_revision=record["revision"], changes=changes)
        except Exception:
            if acquired:
                self.store.release_owner(self._owners.pop(execution_id))
            raise

    def bind_consumer(self, execution_id: str, session_id: str, source_snapshot_hash: str, *,
                      expected_revision: int, expected_source_generation: str) -> dict[str, Any]:
        if type(session_id) is not str or re.fullmatch(r"[0-9a-f]{32}", session_id) is None:
            raise ExecutionError()
        with self._lock:
            record = self.store.get(execution_id)
            self._check(record, expected_revision, expected_source_generation)
            if (record["state"] not in {"prepared", "paused"} or record.get("consumer_binding") is not None
                    or record["source"]["source_snapshot_hash"] != source_snapshot_hash):
                raise ExecutionError("EXECUTION_CONFLICT")
            binding = {"session_id": session_id, "source_snapshot_hash": source_snapshot_hash,
                       "producer_instance": self._producer_instance}
            record = self._claim_transition(record, {"consumer_binding": binding})
            self._consumer_leases[execution_id] = {"deadline": self._clock() + 30., "renewal_count": 0}
            self._track(record)
            return self._status(record)

    def renew_consumer(self, execution_id: str, session_id: str, source_snapshot_hash: str, *,
                       expected_source_generation: str) -> dict[str, Any]:
        # A late heartbeat cannot erase the expired interval before its ordinary
        # pause/revision fence has been applied, even if no poll observed expiry.
        self._check_leases()
        with self._lock:
            self._open()
            record = self.store.get(execution_id)
            binding = record.get("consumer_binding")
            if (binding is None or binding != {"session_id": session_id, "source_snapshot_hash": source_snapshot_hash,
                                               "producer_instance": self._producer_instance}
                    or execution_id not in self._consumer_leases or not self._valid_source(record)
                    or record["source"]["source_generation"] != expected_source_generation
                    or record["state"] not in {"prepared", "initializing", "running", "paused"}):
                raise ExecutionError("EXECUTION_CONFLICT")
            lease = self._consumer_leases[execution_id]
            lease.update(deadline=self._clock() + 30., renewal_count=lease["renewal_count"] + 1)
            return self._status(record)

    def _expire_record(self, record: dict[str, Any]) -> dict[str, Any]:
        if (record["state"] in {"running", "initializing"} and record.get("consumer_binding") is not None
                and self._lease_status(record)["state"] != "valid"):
            record = self.store.update(record["execution_id"], expected_revision=record["revision"], changes={
                "state": "paused", "failure_code": "EXECUTION_CONSUMER_EXPIRED"})
            self._next_due.pop(record["execution_id"], None)
        return record

    def _check_leases(self) -> None:
        cancelled = []
        storage_failed = []
        failure = None
        with self._lock:
            if self._closed:
                return
            for execution_id in self._busy | set(self._next_due):
                if execution_id in self._cleanup_pending:
                    continue  # Only explicit Stop may retry an unconfirmed close.
                try:
                    previous = self.store.get(execution_id)
                    current = self._expire_record(previous)
                except ExecutionError as error:
                    storage_failed.append(execution_id)
                    if execution_id in self._owners:
                        self._cleanup_pending.add(execution_id)
                    failure = error
                    continue
                if current["revision"] != previous["revision"]:
                    if execution_id in self._owners:
                        self._cleanup_pending.add(execution_id)
                    cancelled.append(execution_id)
        for execution_id in cancelled:
            try:
                self._release(execution_id, retain_owner=True)
            except ExecutionError as error:
                failure = error
        for execution_id in storage_failed:
            # Losing durable state access removes local ownership before any
            # candidate may commit; the next successful read recovers interrupted.
            try:
                self._release(execution_id)
            except ExecutionError as error:
                failure = error
        if failure is not None:
            raise failure

    def start(self, execution_id: str, *, expected_revision: int | None = None,
              expected_control_revision: int | None = None, expected_source_generation: str) -> dict[str, Any]:
        return self._activate(execution_id, expected_revision, expected_source_generation,
                              control_revision=expected_control_revision, from_pause=False)

    def _activate(self, execution_id: str, expected_revision: int | None, expected_source_generation: str, *,
                  from_pause: bool, control_revision: int | None = None) -> dict[str, Any]:
        with self._lock:
            record = self.store.get(execution_id)
            self._check(record, expected_revision, expected_source_generation, control_revision=control_revision)
            self._require_cleanup_settled()
            self._require_lease(record)
            if record["state"] != ("paused" if from_pause else "prepared") or execution_id in self._busy:
                raise ExecutionError("EXECUTION_CONFLICT")
            if any(self.store.get(item)["state"] in {"running", "initializing"} for item in self._owners):
                raise ExecutionError("EXECUTION_OWNED")
            self._track(record)
            record = self._claim_transition(record, {"state": "initializing"})
            self._busy.add(execution_id)
            self._constructing.add(execution_id)
            self._activating.add(execution_id)
        adapter = None
        activated = False
        constructor_cancelled = False
        try:
            if self._registry is None:
                from .execution_worker import IsolatedAdapter
                adapter = IsolatedAdapter(record["source"])
            else:
                adapter = self._registry[record["source"]["engine_contract_id"]](deepcopy(record["source"]))
            with self._lock:
                # Even a constructor completing after revocation must remain
                # owned until its returned handle has been safely closed.
                self._constructing.discard(execution_id)
                constructor_cancelled = execution_id in self._cleanup_pending
                self._adapters[execution_id] = adapter
                current = self.store.get(execution_id)
                if (self._closed or execution_id in self._cleanup_pending or execution_id in self._closing
                        or execution_id not in self._owners or current["revision"] != record["revision"]
                        or not self._valid_source(current)):
                    raise ExecutionError("EXECUTION_CONFLICT")
            if self._registry is None:
                adapter.ensure_ready()
            seed = record["checkpoint"] if from_pause else record["initial_checkpoint"]
            initial = validate_checkpoint(record["source"], seed or adapter.initialize())
            if initial["native_time"] != 0 and record["checkpoint_parent"] is None and not from_pause:
                raise ExecutionError()
            with self._lock:
                current = self._expire_record(self.store.get(execution_id))
                if (self._closed or execution_id in self._cleanup_pending or execution_id in self._closing
                        or execution_id not in self._owners or current["revision"] != record["revision"]
                        or not self._valid_source(current)):
                    raise ExecutionError("EXECUTION_CONFLICT")
                current = self.store.update(execution_id, expected_revision=current["revision"], changes={
                    "state": "running", "checkpoint": initial, "failure_code": None,
                    "authorship": "engine" if self._registry is None else "technical_fixture",
                    "runtime_identity": deepcopy(adapter.runtime_identity) if self._registry is None else {"solver": "technical_fixture"}})
                adapter = None
                activated = True
                self._next_due[execution_id] = self._clock() + current["policy"]["frame_period_s"]
                self._wake.set()
                return self._status(current)
        except Exception as error:
            with self._lock:
                try:
                    current = self.store.get(execution_id)
                    if current["state"] == "initializing" and self._valid_source(current):
                        self.store.update(execution_id, expected_revision=current["revision"], changes={
                            "state": "failed", "failure_code": "EXECUTION_SOLVER"})
                except ExecutionError:
                    pass  # The memory fence and owned cleanup do not need this write.
            raise ExecutionError(error.code if isinstance(error, ExecutionError) else "EXECUTION_SOLVER") from None
        finally:
            with self._lock:
                self._constructing.discard(execution_id)
            try:
                if not activated:
                    with self._lock:
                        try:
                            current = self.store.get(execution_id)
                            retain_paused_owner = current["state"] == "paused" and self._valid_source(current)
                        except ExecutionError:
                            retain_paused_owner = False
                        # Keep this lifecycle busy until final cleanup settles;
                        # an old finally must never select a replacement handle.
                        cleanup = execution_id not in self._cleanup_pending or constructor_cancelled or adapter is None
                    if cleanup:
                        self._release(execution_id, retain_owner=retain_paused_owner)
            finally:
                with self._lock:
                    self._busy.discard(execution_id)
                    self._activating.discard(execution_id)

    def _transition(self, execution_id: str, revision: int | None, generation: str, target: str, *,
                    control_revision: int | None = None) -> dict[str, Any]:
        with self._lock:
            record = self.store.get(execution_id)
            # A fenced execution may always be explicitly stopped using its old
            # recorded generation, but must never resume on a replacement source.
            if target in {"stopped", "paused"}:
                self._open()
                check_control_precondition(record, expected_revision=revision, expected_control_revision=control_revision)
                if record["source"]["source_generation"] != generation:
                    raise ExecutionError("EXECUTION_CONFLICT")
            else:
                self._check(record, revision, generation, control_revision=control_revision)
            allowed = {"paused": {"running"}, "running": {"paused"},
                       "stopped": {"prepared", "initializing", "running", "paused", "failed", "interrupted"}}
            cleanup_retry = (target == "stopped" and record["state"] in {"stopped", "completed"}
                             and execution_id in self._cleanup_pending and execution_id in self._owners)
            if execution_id in self._closing or (record["state"] not in allowed[target] and not cleanup_retry):
                raise ExecutionError("EXECUTION_CONFLICT")
            if target == "running" and (execution_id not in self._adapters or execution_id not in self._owners):
                raise ExecutionError("EXECUTION_CONFLICT")
            if target == "running" and any(item != execution_id and self.store.get(item)["state"] == "running" for item in self._owners):
                raise ExecutionError("EXECUTION_OWNED")
            if target == "running":
                if execution_id in self._activating:
                    raise ExecutionError("EXECUTION_CONFLICT")
                self._require_cleanup_settled()
                self._require_lease(record)
            changes = {"state": target}
            if target == "running":
                changes["failure_code"] = None
            # Another manager's revision is not authorization to control its
            # worker: acquire its kernel lock and roll back a failed new claim.
            if not cleanup_retry:
                record = self._claim_transition(record, changes)
            self._next_due.pop(execution_id, None)
            if target == "running":
                self._next_due[execution_id] = self._clock() + record["policy"]["frame_period_s"]
            self._wake.set()
        if target == "stopped":
            self._release(execution_id)
        with self._lock:
            return self._status(record)

    def pause(self, execution_id: str, *, expected_revision: int | None = None,
              expected_control_revision: int | None = None, expected_source_generation: str) -> dict[str, Any]:
        return self._transition(execution_id, expected_revision, expected_source_generation, "paused",
                                control_revision=expected_control_revision)

    def resume(self, execution_id: str, *, expected_revision: int | None = None,
               expected_control_revision: int | None = None, expected_source_generation: str) -> dict[str, Any]:
        with self._lock:
            reconstruct = execution_id not in self._adapters
        if reconstruct:
            return self._activate(execution_id, expected_revision, expected_source_generation,
                                  control_revision=expected_control_revision, from_pause=True)
        return self._transition(execution_id, expected_revision, expected_source_generation, "running",
                                control_revision=expected_control_revision)

    def stop(self, execution_id: str, *, expected_revision: int | None = None,
             expected_control_revision: int | None = None, expected_source_generation: str) -> dict[str, Any]:
        return self._transition(execution_id, expected_revision, expected_source_generation, "stopped",
                                control_revision=expected_control_revision)

    def status(self, execution_id: str) -> dict[str, Any]:
        self._check_leases()
        with self._lock:
            self._open()
            return self._status(self._recover_interrupted(execution_id))

    def _recover_interrupted(self, execution_id: str) -> dict[str, Any]:
        record = self.store.get(execution_id)
        if (self._valid_source(record) and execution_id not in self._owners
                and record["state"] in {"running", "initializing", "paused"}):
            try:
                owner = self.store.acquire_owner(execution_id)
            except ExecutionError as error:
                if error.code == "EXECUTION_OWNED":
                    return record
                raise
            try:
                record = self.store.get(execution_id)
                if record["state"] in {"running", "initializing", "paused"}:
                    record = self.store.update(execution_id, expected_revision=record["revision"], changes={
                        "state": "interrupted", "failure_code": "EXECUTION_OWNER_INTERRUPTED"})
            finally:
                self.store.release_owner(owner)
        return record

    def frames(self, execution_id: str, *, after_frame: int = 0, limit: int = 100) -> dict[str, Any]:
        self._check_leases()
        with self._lock:
            self._open()
            status = self._status(self._recover_interrupted(execution_id))
            frames = self.store.frames(execution_id, after_frame=after_frame, limit=limit)
            return {"execution": status, "frames": frames, "next_after_frame": frames[-1]["frame_index"] if frames else after_frame}

    def invalidate_source(self, old_generation: str, reason: str) -> None:
        text(old_generation)
        failure = None
        with self._lock:
            self._open()
            affected = [key for key, generation in self._generations.items() if generation == old_generation]
            for execution_id in affected:
                self._next_due.pop(execution_id, None)
                if execution_id in self._owners:
                    self._cleanup_pending.add(execution_id)
            for execution_id in self._known:
                try:
                    record = self.store.get(execution_id)
                    if record["source"]["source_generation"] != old_generation or not record["source_valid"]:
                        continue
                    changes = {"source_valid": False, "failure_code": "MODEL_SOURCE_CHANGED"}
                    if record["state"] in {"prepared", "initializing", "running", "paused"}:
                        changes["state"] = "paused"
                    self.store.update(execution_id, expected_revision=record["revision"], changes=changes)
                except ExecutionError as error:
                    failure = error
            self._wake.set()
        for execution_id in affected:
            try:
                self._release(execution_id)
            except ExecutionError:
                failure = ExecutionError("EXECUTION_CLEANUP_UNCONFIRMED")
        if failure is not None:
            raise failure

    def _frame(self, record: dict[str, Any], result: Any, native_end: float) -> dict[str, Any]:
        if not isinstance(result, dict) or set(result) != {"checkpoint", "series"}:
            raise ExecutionError("EXECUTION_SOLVER")
        source = record["source"]
        candidate = validate_checkpoint(source, result["checkpoint"])
        start = record["checkpoint"]["native_time"]
        if candidate["native_time"] != native_end:
            raise ExecutionError("EXECUTION_SOLVER")
        traces = result["series"]
        expected = ({"glucose_mgdl": ("mg/dL", "plasma"), "insulin_action_per_min": ("1/min", "remote_insulin_action"),
                     "insulin_uU_ml": ("uU/mL", "plasma")} if source["engine_contract_id"] == METABOLIC else
                    {"membrane_voltage_mv": ("mV", "ventricular_myocyte"), "cytosolic_calcium_mm": ("mM", "ventricular_myocyte")})
        if not isinstance(traces, list) or not 1 <= len(traces) <= len(expected):
            raise ExecutionError("EXECUTION_SOLVER")
        seen = set()
        domain_notes = []
        if source["engine_contract_id"] == CARDIAC and any(value < 0 for value in candidate["state_values"][2:10]):
            domain_notes.append("CHECKPOINT_SMALL_NEGATIVE_CONCENTRATION_NUMERICAL_UNCERTAINTY")
        state_indices = {"glucose_mgdl": 0, "insulin_action_per_min": 1, "insulin_uU_ml": 2,
                         "membrane_voltage_mv": 0, "cytosolic_calcium_mm": 9}
        for trace in traces:
            if not isinstance(trace, dict) or set(trace) != {"quantity", "unit", "compartment", "native_times", "values"}:
                raise ExecutionError("EXECUTION_SOLVER")
            quantity = trace["quantity"]
            if quantity in seen or quantity not in expected or (trace["unit"], trace["compartment"]) != expected[quantity]:
                raise ExecutionError("EXECUTION_SOLVER")
            seen.add(quantity)
            times, values = trace["native_times"], trace["values"]
            if not isinstance(times, list) or not isinstance(values, list) or not 1 <= len(times) == len(values) <= 4096:
                raise ExecutionError("EXECUTION_SOLVER")
            previous = start
            for instant, value in zip(times, values):
                instant = number(instant, start, native_end)
                number(value, -1e12, 1e12)
                if quantity in {"glucose_mgdl", "insulin_uU_ml"} and value <= 0:
                    raise ExecutionError("EXECUTION_SOLVER")
                if quantity == "cytosolic_calcium_mm" and value < 0:
                    if value < -2e-7:
                        raise ExecutionError("EXECUTION_SOLVER")
                    domain_notes.append("CALCIUM_SMALL_NEGATIVE_NUMERICAL_UNCERTAINTY")
                if instant <= previous:
                    raise ExecutionError("EXECUTION_SOLVER")
                previous = instant
            if times[-1] != native_end:
                raise ExecutionError("EXECUTION_SOLVER")
            if values[-1] != candidate["state_values"][state_indices[quantity]]:
                raise ExecutionError("EXECUTION_SOLVER")
        if self._registry is None and seen != set(expected):
            raise ExecutionError("EXECUTION_SOLVER")
        frame = {"schema": "livemore.execution-frame.v1", "execution_id": record["execution_id"],
                 "frame_index": record["latest_frame"] + 1, "source_snapshot_hash": source["source_snapshot_hash"],
                 "previous_frame_hash": record["latest_frame_hash"],
                 "checkpoint_parent": deepcopy(record["checkpoint_parent"]),
                 "source_generation": source["source_generation"], "selection": deepcopy(source["selection"]),
                 "engine_contract_id": source["engine_contract_id"], "model_identity": deepcopy(source["model_identity"]),
                 "runtime_identity": deepcopy(record["runtime_identity"]),
                 "native_unit": source["native_axis"]["unit"], "native_start": start, "native_end": native_end,
                 "generated_at": utc_now(), "generated_monotonic_s": number(self._clock(), 0, 1e12),
                 "authorship": record["authorship"],
                 "evidence_class": "MODELED" if self._registry is None else "TECHNICAL_FIXTURE",
                 "independent_physical_validation": False, "series": deepcopy(traces),
                 "numerical_domain_notes": sorted(set(domain_notes)),
                 "checkpoint_hash": digest(candidate)}
        frame["frame_hash"] = digest(frame)
        encoded(frame, MAX_FRAME_BYTES)
        return frame

    def advance_once(self, execution_id: str) -> dict[str, Any] | None:
        self._check_leases()
        with self._lock:
            self._open()
            record = self.store.get(execution_id)
            if not self._valid_source(record):
                if self._permitted_generation is None and record["state"] != "running":
                    return None  # Preserve standalone no-work polling semantics.
                raise ExecutionError("EXECUTION_CONFLICT")
            self._require_cleanup_settled()
            if record["state"] != "running" or execution_id in self._busy:
                return None
            if execution_id not in self._owners or execution_id not in self._adapters or not record["source_valid"]:
                raise ExecutionError("EXECUTION_CONFLICT")
            self._busy.add(execution_id)
            adapter = self._adapters[execution_id]
            policy = record["policy"]
            step = policy["frame_period_s"] * policy["time_scale"] * (1000 if record["source"]["engine_contract_id"] == CARDIAC else 1 / 60)
            native_end = min(record["checkpoint"]["native_time"] + step, policy["end_native"])
        try:
            result = adapter.advance(deepcopy(record["checkpoint"]), native_end)
            frame = self._frame(record, result, native_end)
            with self._lock:
                current = self._expire_record(self.store.get(execution_id))
                if (self._closed or execution_id in self._cleanup_pending or execution_id in self._closing
                        or execution_id not in self._owners or current["revision"] != record["revision"]
                        or not self._valid_source(current) or current["state"] != "running"):
                    return None
                current = self.store.update(execution_id, expected_revision=record["revision"], changes={
                    "checkpoint": result["checkpoint"], "state": "completed" if native_end == policy["end_native"] else "running"}, frame=frame)
                if current["state"] == "completed":
                    self._next_due.pop(execution_id, None)
                else:
                    self._next_due[execution_id] = self._clock() + policy["frame_period_s"]
                return deepcopy(frame)
        except Exception as error:
            with self._lock:
                current = self.store.get(execution_id)
                if current["revision"] == record["revision"] and current["state"] == "running" and self._valid_source(current):
                    quota = isinstance(error, ExecutionError) and error.code == "EXECUTION_QUOTA"
                    self.store.update(execution_id, expected_revision=current["revision"], changes={
                        "state": "paused" if quota else "failed",
                        "failure_code": "EXECUTION_QUOTA" if quota else "EXECUTION_SOLVER"})
                    self._next_due.pop(execution_id, None)
            return None
        finally:
            with self._lock:
                self._busy.discard(execution_id)
                terminal = self.store.get(execution_id)["state"] in {"completed", "failed", "stopped"}
                cleanup = execution_id not in self._cleanup_pending
            if terminal and cleanup:
                self._release(execution_id)

    def _run(self) -> None:
        while True:
            self._wake.wait(.05)
            self._wake.clear()
            try:
                self._check_leases()
            except ExecutionError:
                pass  # _check_leases has cancelled and fenced the affected owner.
            with self._lock:
                if self._closed:
                    return
                due = [key for key, instant in self._next_due.items() if instant <= self._clock()]
            for execution_id in due:
                try:
                    self.advance_once(execution_id)
                except ExecutionError:
                    # Failure is retained in encrypted record where possible;
                    # storage failures stop scheduling, never leak payload logs.
                    with self._lock:
                        self._next_due.pop(execution_id, None)

    def _run_leases(self) -> None:
        while not self._lease_wake.wait(.05):
            try:
                self._check_leases()
            except ExecutionError:
                pass  # Failure has already removed ownership and cancelled work.

    def _release(self, execution_id: str, *, retain_owner: bool = False) -> None:
        with self._lock:
            self._next_due.pop(execution_id, None)
            if execution_id in self._closing:
                raise ExecutionError("EXECUTION_CONFLICT")
            if execution_id in self._constructing:
                self._cleanup_pending.add(execution_id)
                raise ExecutionError("EXECUTION_CLEANUP_UNCONFIRMED")
            adapter = self._adapters.get(execution_id)
            owner = self._owners.get(execution_id)
            if adapter is None and owner is None:
                return
            self._closing.add(execution_id)
            self._cleanup_pending.add(execution_id)
            already_closed = execution_id in self._adapter_closed
        try:
            if adapter is not None and not already_closed:
                adapter.close()
                with self._lock:
                    self._adapter_closed.add(execution_id)
            if owner is not None and not retain_owner:
                self.store.release_owner(owner)
            with self._lock:
                self._adapters.pop(execution_id, None)
                self._adapter_closed.discard(execution_id)
                if not retain_owner:
                    self._owners.pop(execution_id, None)
                self._cleanup_pending.discard(execution_id)
        except Exception:
            # Do not hand ownership to another process until shutdown is
            # confirmed. Fixed metadata remains inspectable for explicit Stop.
            raise ExecutionError("EXECUTION_CLEANUP_UNCONFIRMED") from None
        finally:
            with self._lock:
                self._closing.discard(execution_id)

    def _awaited_cleanup(self, execution_id: str, timeout: float = 4.) -> bool:
        """True only when another thread's cleanup finished and was confirmed."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self._lock:
                if execution_id not in self._closing:
                    return (execution_id not in self._cleanup_pending
                            and execution_id not in self._owners)
            time.sleep(.01)
        return False

    def close(self) -> None:
        failure = None
        with self._lock:
            if self._closed and not self._owners:
                return
            self._closed = True
            self._wake.set()
            self._lease_wake.set()
            owned = list(self._owners)
            for execution_id in owned:
                try:
                    record = self.store.get(execution_id)
                    if record["state"] in {"running", "initializing", "paused"}:
                        self.store.update(execution_id, expected_revision=record["revision"], changes={
                            "state": "interrupted", "failure_code": "EXECUTION_OWNER_CLOSED"})
                except ExecutionError as error:
                    failure = error
        for execution_id in owned:
            try:
                self._release(execution_id)
            except ExecutionError as error:
                # Another thread may already be releasing this execution during
                # shutdown. That is cleanup in progress, not a control conflict,
                # so wait for it to confirm rather than reporting a failure.
                if error.code == "EXECUTION_CONFLICT" and self._awaited_cleanup(execution_id):
                    continue
                failure = error
        if self._thread is not None and self._thread is not threading.current_thread():
            self._thread.join(timeout=4.)
        if self._lease_thread is not None and self._lease_thread is not threading.current_thread():
            self._lease_thread.join(timeout=4.)
        if failure is not None:
            raise failure
