"""Owned phase group cleanup; no acquisition, conversion or publication.

The caller is the exclusive waiter for the Popen child. Its PID is held with
WNOWAIT until the owned group has no live members; never signal a reaped PID.
"""
from __future__ import annotations

import ctypes
import errno
import math
import os
import platform
import signal
import subprocess
import time
from typing import Any


class ProcessOwnershipError(RuntimeError):
    def __init__(self, code: str):
        if code not in {"PROCESS_WAIT_UNSUPPORTED", "PROCESS_OWNERSHIP_LOST", "PROCESS_GROUP_INSPECTION_FAILED",
                        "PROCESS_GROUP_TERMINATION_FAILED", "PROCESS_REAP_FAILED"}:
            raise ValueError("Unknown process ownership error")
        self.code = code
        super().__init__(code)


def _need(condition: bool, code: str) -> None:
    if not condition:
        raise ProcessOwnershipError(code)


class _SigInfo(ctypes.Structure):
    # Apple SDK arm64/x86_64 siginfo_t, checked before calling the ABI.
    _fields_ = [(name, ctypes.c_int) for name in ("signo", "error", "code", "pid")] + [
        ("uid", ctypes.c_uint), ("status", ctypes.c_int), ("address", ctypes.c_void_p),
        ("value", ctypes.c_uint64), ("band", ctypes.c_long), ("reserved", ctypes.c_ulong * 7)]


def _darwin_wait():
    try:
        _need(ctypes.sizeof(_SigInfo) == 104, "PROCESS_WAIT_UNSUPPORTED")
        function = ctypes.CDLL("/usr/lib/libSystem.B.dylib", use_errno=True).waitid
        function.argtypes = [ctypes.c_int, ctypes.c_uint, ctypes.POINTER(_SigInfo), ctypes.c_int]
        function.restype = ctypes.c_int
        return function
    except (OSError, AttributeError) as error:
        raise ProcessOwnershipError("PROCESS_WAIT_UNSUPPORTED") from error


def _darwin_group():
    try:
        function = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True).proc_listpgrppids
        function.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_int]
        function.restype = ctypes.c_int
        return function
    except (OSError, AttributeError) as error:
        raise ProcessOwnershipError("PROCESS_GROUP_INSPECTION_FAILED") from error


def ensure_supported() -> None:
    system = platform.system()
    _need(hasattr(os, "fork"), "PROCESS_WAIT_UNSUPPORTED")
    if system == "Darwin":
        _darwin_wait()
        _darwin_group()
    elif system == "Linux":
        _need(all(hasattr(os, key) for key in ("waitid", "P_PID", "WEXITED", "WNOHANG", "WNOWAIT")), "PROCESS_WAIT_UNSUPPORTED")
        _need(os.path.isdir("/proc"), "PROCESS_GROUP_INSPECTION_FAILED")
    else:
        raise ProcessOwnershipError("PROCESS_WAIT_UNSUPPORTED")


def waitable_child_exited(pid: int) -> bool:
    _need(type(pid) is int and pid > 0, "PROCESS_OWNERSHIP_LOST")
    try:
        if platform.system() == "Darwin":
            result = _SigInfo()
            # Apple sys/wait.h: P_PID=1, WEXITED|WNOHANG|WNOWAIT=4|1|32.
            _need(_darwin_wait()(1, pid, ctypes.byref(result), 37) == 0, "PROCESS_OWNERSHIP_LOST")
            _need(result.pid in {0, pid}, "PROCESS_OWNERSHIP_LOST")
            return result.pid == pid
        if platform.system() == "Linux":
            result = os.waitid(os.P_PID, pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
            _need(result is None or result.si_pid in {0, pid}, "PROCESS_OWNERSHIP_LOST")
            return result is not None and result.si_pid == pid
        raise ProcessOwnershipError("PROCESS_WAIT_UNSUPPORTED")
    except (OSError, AttributeError) as error:
        raise ProcessOwnershipError("PROCESS_OWNERSHIP_LOST") from error


def parse_linux_stat(raw: bytes | str, expected_pid: int) -> tuple[int, str]:
    try:
        _need(type(expected_pid) is int and expected_pid > 0, "PROCESS_GROUP_INSPECTION_FAILED")
        if isinstance(raw, str):
            raw = raw.encode("utf8")
        _need(isinstance(raw, bytes) and 0 < len(raw) <= 4096, "PROCESS_GROUP_INSPECTION_FAILED")
        # comm is opaque process-name bytes, not an ASCII command line. Only
        # the kernel's numeric membership fields require ASCII interpretation.
        prefix, separator, rest = raw.partition(b" (")
        ending = rest.rfind(b") ")
        _need(separator != b"" and prefix == str(expected_pid).encode("ascii") and ending >= 0, "PROCESS_GROUP_INSPECTION_FAILED")
        fields = rest[ending+2:].split()
        _need(len(fields) >= 3 and fields[0] in {b"R", b"S", b"D", b"Z", b"T", b"t", b"X", b"x", b"K", b"W", b"P", b"I"}, "PROCESS_GROUP_INSPECTION_FAILED")
        _need(fields[1].isdigit() and fields[2].isdigit(), "PROCESS_GROUP_INSPECTION_FAILED")
        group = int(fields[2])
        # Kernel threads can legitimately belong to group zero. The requested
        # owned group remains strictly positive, so these never become targets.
        return group, fields[0].decode("ascii")
    except (ValueError, TypeError, IndexError, UnicodeError) as error:
        raise ProcessOwnershipError("PROCESS_GROUP_INSPECTION_FAILED") from error


def active_group_members(pid: int) -> list[int]:
    """Only operational membership, never command lines or persisted process data."""
    _need(type(pid) is int and pid > 0, "PROCESS_OWNERSHIP_LOST")
    if platform.system() == "Darwin":
        buffer = (ctypes.c_int * 128)()
        ctypes.set_errno(0)
        count = _darwin_group()(pid, buffer, ctypes.sizeof(buffer))
        _need(0 <= count < len(buffer) and not (count == 0 and ctypes.get_errno()), "PROCESS_GROUP_INSPECTION_FAILED")
        # Darwin lists the held leader even though an exited child cannot run.
        return [member for member in buffer[:count] if member > 0 and (member != pid or not waitable_child_exited(pid))]
    _need(platform.system() == "Linux", "PROCESS_WAIT_UNSUPPORTED")
    result = []
    try:
        with os.scandir("/proc") as entries:
            count = 0
            for entry in entries:
                count += 1
                _need(count <= 65536, "PROCESS_GROUP_INSPECTION_FAILED")
                if not entry.name.isascii() or not entry.name.isdecimal():
                    continue
                try:
                    with open(entry.path + "/stat", "rb") as stream:
                        raw = stream.read(4097)
                except OSError as error:
                    if error.errno in {errno.ENOENT, errno.ESRCH}:
                        continue
                    raise
                group, state = parse_linux_stat(raw, int(entry.name))
                if group == pid and state not in {"Z", "X", "x"}:
                    result.append(int(entry.name))
        return result
    except (OSError, UnicodeError) as error:
        raise ProcessOwnershipError("PROCESS_GROUP_INSPECTION_FAILED") from error


def _guard_group(child: subprocess.Popen, deadline: float) -> None:
    _need(child.returncode is None, "PROCESS_OWNERSHIP_LOST")
    while not waitable_child_exited(child.pid):
        try:
            _need(os.getpgid(child.pid) == child.pid, "PROCESS_OWNERSHIP_LOST")
            return
        except ProcessLookupError:
            # Darwin can hide an exiting process from getpgid before waitid
            # exposes its waitable exit. WNOWAIT still recognizes our child.
            # Observe only, within the original cleanup budget; never signal
            # an uncertain number or reap merely to resolve this transition.
            _need(time.monotonic() < deadline, "PROCESS_OWNERSHIP_LOST")
            time.sleep(.002)
        except OSError as error:
            raise ProcessOwnershipError("PROCESS_OWNERSHIP_LOST") from error


def terminate_owned_group(child: subprocess.Popen, seconds: float = 5.) -> dict[str, Any]:
    _need(type(seconds) in {int, float} and math.isfinite(seconds) and 0 < seconds <= 5, "PROCESS_GROUP_TERMINATION_FAILED")
    deadline = time.monotonic()+seconds
    _guard_group(child, deadline)
    active = active_group_members(child.pid)
    descendants = any(member != child.pid for member in active)
    if active:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            # The guardian may already be killing this group on its own deadline.
            # This is not success: retain the anchor and prove whole-group exit
            # below, or fail boundedly without falsely reporting cleanup.
            pass
        except OSError as error:
            raise ProcessOwnershipError("PROCESS_GROUP_TERMINATION_FAILED") from error
    while active_group_members(child.pid) or not waitable_child_exited(child.pid):
        _need(time.monotonic() < deadline, "PROCESS_GROUP_TERMINATION_FAILED")
        time.sleep(.01)
    # Final reap is after verified group termination, never the polling primitive.
    try:
        code = child.wait(timeout=max(.01, deadline-time.monotonic()))
    except (OSError, subprocess.TimeoutExpired) as error:
        raise ProcessOwnershipError("PROCESS_REAP_FAILED") from error
    return {"reaped": True, "descendants": descendants, "exit_code": code}
