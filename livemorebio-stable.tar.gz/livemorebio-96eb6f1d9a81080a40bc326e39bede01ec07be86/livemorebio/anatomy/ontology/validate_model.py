#!/usr/bin/env python3
"""Dependency-free semantic checks for the Aegle seed model.

JSON Schema-aware tools should also validate against human-body.schema.json.
This script intentionally uses only Python's standard library so it runs in a
new Codespace without package installation.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "human-body-core.json"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def unique_ids(items: list[dict[str, Any]], label: str) -> set[str]:
    ids = [item.get("id") for item in items]
    require(all(isinstance(value, str) and value for value in ids), f"{label}: every item needs an id")
    require(len(ids) == len(set(ids)), f"{label}: duplicate ids detected")
    return set(ids)


def main() -> None:
    model = json.loads(MODEL_PATH.read_text(encoding="utf-8"))

    required_root = {
        "manifest",
        "scales",
        "biological_trait_model",
        "life_stages",
        "systems",
        "whole_body_processes",
        "couplings",
        "model_contract",
    }
    require(required_root.issubset(model), "Missing one or more required root sections")

    scale_ids = unique_ids(model["scales"], "scales")
    system_ids = unique_ids(model["systems"], "systems")
    unique_ids(model["life_stages"], "life_stages")
    unique_ids(model["whole_body_processes"], "whole_body_processes")
    unique_ids(model["couplings"], "couplings")

    orders = [item["order"] for item in model["scales"]]
    require(orders == sorted(orders), "scales must be ordered from smallest to largest")
    living_scales = [item["id"] for item in model["scales"] if item["is_living_unit"]]
    require(living_scales and living_scales[0] == "cell", "cell must be the smallest living unit")

    structure_ids: set[str] = set()
    for system in model["systems"]:
        require(system["structures"], f"{system['id']}: structures cannot be empty")
        require(system["processes"], f"{system['id']}: processes cannot be empty")
        for structure in system["structures"]:
            sid = structure["id"]
            require(sid not in structure_ids, f"duplicate structure id: {sid}")
            structure_ids.add(sid)

    for coupling in model["couplings"]:
        referenced = set(coupling["source_systems"] + coupling["target_systems"])
        missing = referenced - system_ids
        require(not missing, f"{coupling['id']}: unknown systems {sorted(missing)}")

    contract = model["model_contract"]
    for key in ("identity", "inputs", "outputs", "units", "time", "solver", "provenance", "validation"):
        require(key in contract, f"model_contract: missing {key}")

    require(len(scale_ids) >= 8, "expected a multiscale model with at least eight scales")
    require(len(system_ids) >= 12, "expected at least twelve biological systems")

    print("PASS: human-body-core.json is structurally and semantically valid")


if __name__ == "__main__":
    main()
