# Aegle: Building a Living Human from the Smallest Scale to the Whole Organism

## 1. What “the full human body” actually means

A living human is not a stack of independent organs and not a static anatomical
mesh. It is a continuously regulated, open biological system that exchanges
matter, energy, force, and information with its environment.

For Aegle, the computational object should be defined as:

\[
\text{Human Twin}(t)=
\text{reference structure}
+\text{individual anatomy}
+\text{parameters}
+\text{dynamic state}(t)
+\text{process models}
+\text{environment}
+\text{evidence and uncertainty}
\]

The atom is a practical lowest structural boundary for the general model. A
**cell is the smallest unit that is itself alive**. Smaller components are
essential to life but do not independently constitute a living human unit.

It is computationally and scientifically indefensible to claim that every atom
of a whole person can be simulated continuously. Relevant phenomena span from
subatomic interactions to a lifetime, and many human mechanisms are still
incompletely known. The build must therefore be a **federated,
adaptive-resolution model**:

- Atomistic and quantum calculations for small, bounded questions.
- Molecular reaction models for pathways and drug mechanisms.
- Cell models for state, signaling, metabolism, electrophysiology, and fate.
- Tissue models for spatial transport, mechanics, cell populations, and repair.
- Organ and whole-body reduced models for live simulation.
- Patient-data assimilation for hidden state and uncertainty.
- High-fidelity offline models that produce validated reduced-order surrogates.

This distinction is the foundation of scientific credibility. A visual model
may look complete while having no executable physiology. A mathematical model
may execute while representing only a tiny context. Aegle must label both.

## 2. Organizational hierarchy

| Level | What must be represented | Typical dynamics | Routine representation |
| --- | --- | --- | --- |
| Environment | Air, water, food, temperature, gravity, radiation, pathogens, drugs, activity, sleep, social and healthcare context | Exposure and behavior | Boundary conditions and events |
| Subatomic | Electrons, protons, neutrons, photons | Imaging, radiation interactions, electron transfer | Local quantum or Monte Carlo model |
| Atoms and ions | C, H, O, N, P, S; Na, K, Ca, Mg, Cl, Fe, bicarbonate, phosphate and trace elements | Bonding, charge, osmotic and electrochemical gradients | Amounts, concentrations and potentials |
| Small molecules | Water, gases, metabolites, transmitters, hormones, vitamins, cofactors, drugs and waste | Diffusion, binding, acid-base, redox and transport | Species pools and fields |
| Macromolecules | DNA, RNA, proteins, lipids, glycans and extracellular matrix | Information flow, catalysis, signaling and structure | Networks, abundance and state |
| Complexes and organelles | Membranes, channels, ribosomes, chromatin, nucleus, mitochondria, ER, Golgi, lysosomes, peroxisomes and cytoskeleton | Compartmentalized cellular work | Reaction and transport modules |
| Cell | Every relevant cell type and context-dependent state | Metabolism, excitability, secretion, contraction, migration, renewal and death | ODE, stochastic, agent, Boolean and flux models |
| Microenvironment | Matrix, interstitial fluid, vessels, nerves, immune cells and local gradients | Exchange, mechanics and cell-cell communication | Spatial fields and multicellular agents |
| Tissue | Epithelial, connective, muscle and nervous tissues plus organ-specific mixtures | Barrier, force, exchange, repair and remodeling | Continuum and multicellular models |
| Functional tissue unit | Nephron, hepatic lobule, alveolar unit, islet, crypt-villus, osteon, motor unit and similar modules | Reusable local organ function | Coupled mechanistic component |
| Organ | Multiple tissue units, vessels, lymphatics, nerves, ducts and boundaries | Integrated organ output and reserve | 0D/1D/3D or hybrid model |
| Organ system | Coupled organ networks | Transport, control, defense, movement and reproduction | Co-simulation federation |
| Organism | Person, behavior, development, cognition, adaptation and homeostasis | Whole-body survival and health trajectory | Hybrid state-space twin |

The primary external backbone should be the [NIH Human Reference Atlas](https://humanatlas.io/),
which links anatomical structures, cell types, biomarkers, and spatial reference
objects. [Uberon](https://obofoundry.org/ontology/uberon.html) and the human-specific
[Foundational Model of Anatomy](https://bime.uw.edu/research/foundational-model-of-anatomy/)
provide anatomical semantics; the [Cell Ontology](https://obofoundry.org/ontology/cl.html)
and [Human Cell Atlas](https://www.humancellatlas.org/) provide cellular semantics
and reference data.

## 3. The molecular foundation of human life

### 3.1 Matter and fluid

Most physiological simulation starts with conserved quantities, not with a
picture. Water is the dominant solvent. Ions establish osmolarity, membrane
voltage, excitability, contraction, secretion, and acid-base balance. Carbon,
oxygen, hydrogen, nitrogen, phosphorus, and sulfur form most biomolecules; trace
elements enable catalysis, gas transport, endocrine function, and structure.

Every material compartment must obey:

\[
\frac{dM_i}{dt}=\sum J_{i,\mathrm{in}}-\sum J_{i,\mathrm{out}}
+P_i-C_i
\]

where \(M_i\) is the amount of a substance, \(J\) is transport, \(P\) is
production, and \(C\) is consumption. The same bookkeeping principle applies
to charge, energy, and mechanical momentum.

### 3.2 Information and biological machinery

DNA stores inherited sequence information; chromatin and epigenetic state
control access. Transcription generates RNA, RNA processing changes its form,
and translation produces proteins. Proteins fold, assemble, move, catalyze,
signal, generate force, transport matter, and are degraded. Lipids provide
membranes, energy stores, and signals. Carbohydrates provide fuel, structure,
and molecular recognition. Glycans and extracellular matrix shape cell identity
and tissue mechanics.

A molecular model should not stop at “gene X affects protein Y.” It should
represent, where evidence permits:

1. Sequence or molecular identity.
2. Abundance and compartment.
3. Chemical and post-translational state.
4. Binding partners and reaction stoichiometry.
5. Synthesis, transport, and degradation.
6. Effect on cell state or flux.
7. Measurement method and uncertainty.
8. Validated context—cell type, tissue, life stage, dose, and time.

Use [ChEBI](https://obofoundry.org/ontology/chebi.html) for chemical entities,
[Gene Ontology](https://geneontology.org/docs/ontology-documentation/) for
cellular components, functions, and processes, Protein Ontology and UniProt for
proteins, HGNC/NCBI Gene for genes, and Reactome for curated human pathways.

## 4. The cell: smallest living human unit

A human cell is a bounded, regulated system capable of maintaining a distinct
internal environment, using energy, processing information, responding to
signals, repairing itself, and performing a specialized role. Many mature cells
do not divide, so cell division alone is not the definition of life.

Every modeled cell instance or population needs:

- Type, state, lineage, anatomical location, and life stage.
- Morphology, polarity, size, and membrane topology.
- Genome and relevant variants; epigenetic and transcriptional state.
- Receptors, channels, transporters, adhesion molecules, and markers.
- Metabolic fluxes, ATP, oxygen use, redox, pH, and ion balance.
- Secreted and absorbed substances.
- Electrophysiology and contractility when relevant.
- Cell cycle, differentiation, senescence, apoptosis, necrosis, and turnover.
- Interactions with vessels, nerves, matrix, microbes, and immune cells.
- Observable assays and latent variables.
- Provenance and confidence.

### 4.1 Major cell families

The maintained Cell Ontology should supply the exhaustive class list. Aegle's
top-level families are:

- Stem, progenitor, and germ cells.
- Epithelial and glandular cells.
- Endothelial cells and pericytes.
- Fibroblasts, stromal cells, and matrix-producing cells.
- Adipocytes.
- Skeletal, cardiac, and smooth-muscle cells.
- Neurons, glia, and sensory receptor cells.
- Erythrocytes, platelets, myeloid, lymphoid, and tissue-resident immune cells.
- Hepatocytes and other metabolic cells.
- Endocrine and exocrine secretory cells.
- Reproductive support cells and trophoblast lineages.

Cell “type” and “state” must remain separate. The same macrophage, endothelial
cell, fibroblast, or epithelial cell can occupy markedly different functional
states in normal tissue, injury, aging, infection, or cancer.

## 5. Tissues, microenvironments, and functional units

Classical tissue families are epithelial, connective, muscle, and nervous
tissue, but a functional organ module always includes more than its main cells.
Every organ-local functional unit should contain:

- Specialized parenchymal cells.
- Supporting stromal cells and extracellular matrix.
- Arterial inflow, capillary exchange, and venous drainage.
- Lymphatic drainage.
- Sensory, motor, and autonomic innervation.
- Resident and recruitable immune cells.
- Interstitial fluid and local chemical gradients.
- Duct or lumen when relevant.
- Mechanical boundaries and attachments.
- Stem/progenitor or repair niche.
- Microbial ecosystem where an external lumen is colonized.

Reusable functional units include the nephron, hepatic lobule/acinus,
alveolar-capillary unit, cardiac myofiber/conduction unit, intestinal
crypt-villus, pancreatic islet and acinus, osteon, motor unit, neurovascular
unit, lymphoid follicle, ovarian follicle, and seminiferous tubule.

Critical selective barriers include skin, intestinal epithelium,
alveolar-capillary membrane, glomerular filtration barrier, blood-brain barrier,
blood-retinal barrier, blood-testis barrier, and maternal-placental-fetal
barrier.

## 6. Complete system map

The machine-readable seed contains 15 system modules. The following table gives
their required scope.

| System | Required anatomy | Essential physiology |
| --- | --- | --- |
| Integumentary | Epidermis, dermis, hypodermis, hair, nails, sebaceous and sweat glands, cutaneous vessels/nerves/immune cells, mammary glands where present | Barrier, water conservation, sensation, thermoregulation, immunity, vitamin-D synthesis, wound healing, lactation when active |
| Skeletal/articular | Axial and appendicular skeleton, marrow spaces, cartilage, fibrous/cartilaginous/synovial joints, synovium, discs, menisci and ligaments | Support, protection, leverage, mineral exchange, hematopoietic niche, buffering, endocrine signaling and remodeling |
| Muscular/fascial | All named skeletal muscles, motor units, tendons, aponeuroses, entheses, bursae and fascia | Movement, posture, ventilation, joint stability, venous return, thermogenesis, glucose disposal and adaptation |
| Nervous | Brain, meninges, ventricles/CSF, spinal cord, cranial/spinal nerves, plexuses, ganglia, autonomic and enteric networks | Sensation, integration, cognition, consciousness correlates, emotion, language, memory, motor and autonomic control, sleep and plasticity |
| Special senses | Eyes and visual pathways; external/middle/inner ears and vestibular pathways; olfactory and gustatory organs | Phototransduction, optics, auditory and vestibular mechanotransduction, smell, taste and multisensory orientation |
| Endocrine | Hypothalamus/pituitary, pineal, thyroid, parathyroids, adrenals, pancreatic islets, gonads, placenta when present, and distributed endocrine tissues | Metabolism, stress, growth, circadian timing, fluid/mineral balance, and reproductive feedback axes |
| Cardiovascular | Heart chambers, valves, myocardium, conduction system, coronary circulation, pericardium, arteries, arterioles, capillaries, venules, veins and portal systems | Electrical activation, pumping, pressure/flow, exchange, autoregulation, heat and substance distribution |
| Blood/hematopoietic | Plasma, erythrocytes, leukocytes, platelets, marrow niches, coagulation, anticoagulation and fibrinolysis | Gas carriage, transport, buffering, hematopoiesis, hemostasis and cell trafficking |
| Lymphatic/immune | Marrow, thymus, spleen, nodes, tonsils, MALT, lymphatic vessels/ducts and distributed immune populations | Innate/adaptive defense, tolerance, surveillance, memory, inflammation/resolution, lymph return and intestinal lipid transport |
| Respiratory | Nose, sinuses, pharynx, larynx, trachea, bronchial tree, lungs, alveoli, pulmonary vessels, pleura, diaphragm and accessory pump | Ventilation, perfusion, gas diffusion, acid-base control, airway defense, mucociliary clearance, surfactant and phonation |
| Digestive/hepatobiliary | Oral cavity, teeth, tongue, salivary glands, pharynx, esophagus, stomach, small/large bowel, rectum/anus, liver, biliary tree, gallbladder, exocrine pancreas, mesentery and peritoneum | Ingestion, motility, secretion, digestion, absorption, portal processing, metabolism, storage, detoxification, bile handling and elimination |
| Urinary/renal | Renal cortex/medulla, nephrons, glomeruli, tubules, collecting system, renal vessels/JGA, ureters, bladder, urethra and sphincters | Filtration, transport, concentration, excretion, volume/electrolyte/osmolality/pH control, RAAS, EPO and vitamin-D activation |
| Reproductive | Typical female: ovaries, tubes, uterus, cervix, vagina, vulva and supports. Typical male: testes, epididymides, ducts, glands, prostate, penis and scrotum. Placenta, membranes and cord when pregnant | Gametogenesis, steroid production, sexual response, fertilization, implantation, menstrual physiology, gestation, fetal support, birth and lactation support |
| Microbiome | Gut, oral, skin, airway and urogenital communities, microbial genes/metabolites and phages | Colonization resistance, nutrient/xenobiotic transformation, immune education, barrier interaction and ecological dynamics |
| Interstitial/ECM interfaces | Extracellular matrix, basement membranes, interstitial fluid, fascia, serosal membranes/cavities and neurovascular sheaths | Mechanical continuity, compartmentalization, solute exchange, edema/clearance, lubrication, mechanotransduction and fibrosis |

Named bones, muscles, vessels, nerves, cells, and microscopic parts should be
imported from maintained ontologies and atlases; they should not be frozen into
a hand-written list that becomes obsolete. The seed JSON defines the integration
contract and major coverage groups.

## 7. Body-wide compartments that cross systems

These must be first-class objects rather than hidden inside one organ:

- Intracellular fluid.
- Plasma and cellular blood compartment.
- Interstitial fluid and lymph.
- Cerebrospinal, synovial, pleural, pericardial, peritoneal, ocular, amniotic,
  and other specialized fluids.
- Gastrointestinal, airway, urinary, and reproductive lumina.
- Vascular endothelium and microcirculation.
- Extracellular matrix, basement membranes, and fascia.
- Distributed immune, endocrine, and autonomic networks.
- Stem-cell renewal and tissue-turnover networks.
- Human-associated microbial ecosystems.
- Circadian, ultradian, cardiac, respiratory, digestive, and reproductive clocks.

## 8. Processes that make the integrated body living

Detailed processes should roll up to these root capabilities:

1. Boundary integrity and selective transport.
2. DNA maintenance and biological information flow.
3. Oxygen acquisition, delivery, and mitochondrial ATP production.
4. Nutrient acquisition, digestion, absorption, metabolism, and storage.
5. Circulation, perfusion, and microvascular exchange.
6. Water, electrolyte, osmolarity, volume, and acid-base regulation.
7. Waste conversion, detoxification, and excretion.
8. Thermoregulation.
9. Sensation, neural integration, motor action, cognition, and behavior.
10. Neural, endocrine, paracrine, autocrine, and intracellular signaling.
11. Immune defense, tolerance, surveillance, and microbiome containment.
12. Hemostasis, repair, regeneration, scarring, and remodeling.
13. Growth, differentiation, renewal, adaptation, senescence, and cell death.
14. Sleep, circadian organization, and recovery.
15. Gametogenesis, sexual physiology, reproduction, gestation, birth, and
    lactation.

Homeostasis is not a fixed equilibrium. It is active feedback and anticipatory
control that keeps essential variables within viable ranges while permitting
sleep, meals, exercise, stress, illness, pregnancy, and environmental change.

## 9. Essential intersystem loops

No system can be validated alone as “the human body.” At minimum, close these
loops:

| Loop | Coupled path |
| --- | --- |
| Oxygen and carbon dioxide | Respiratory pump ↔ alveoli ↔ blood/hemoglobin ↔ heart/vessels ↔ tissue diffusion ↔ mitochondria; kidney contributes acid-base compensation |
| Nutrient and energy | Gut ↔ portal circulation ↔ liver ↔ pancreas ↔ muscle/adipose/brain ↔ kidney and waste routes |
| Pressure and volume | Heart/vessels ↔ kidney ↔ sympathetic system ↔ RAAS, vasopressin and natriuretic peptides |
| Acid-base | Cellular acids/CO₂ ↔ blood buffers ↔ lungs ↔ kidneys |
| Glucose | Gut ↔ islets ↔ liver ↔ muscle/adipose ↔ brain ↔ autonomic/endocrine stress responses |
| Temperature | Hypothalamus ↔ skin blood flow/sweat ↔ muscle heat ↔ circulation ↔ environment and behavior |
| Calcium and bone | Gut ↔ vitamin D ↔ parathyroids ↔ kidney ↔ bone |
| Erythropoiesis | Tissue oxygen ↔ kidney EPO ↔ marrow ↔ erythrocytes ↔ lung/circulation |
| Hemostasis and repair | Endothelium ↔ platelets/coagulation ↔ immune cells ↔ matrix/stem cells ↔ perfusion/innervation/loading |
| Barrier and immune | Skin/gut/airway/urogenital barriers ↔ microbes ↔ lymphatics/marrow/spleen ↔ circulation |
| Movement | Brain/spinal cord ↔ peripheral nerves ↔ muscle ↔ bone/joints ↔ proprioception plus cardiorespiratory energy support |
| Reproductive | Hypothalamus ↔ pituitary ↔ gonads ↔ reproductive organs ↔ behavior |
| Maternal-fetal | Maternal circulation/respiration/kidney/metabolism/endocrine/immune ↔ placenta ↔ separate fetal twin |
| Circadian | Retinal light ↔ suprachiasmatic nucleus ↔ sleep, autonomic, endocrine, metabolic and immune clocks |

## 10. Male and female reference bodies without biological oversimplification

Typical male and typical female templates are necessary, but one binary flag is
not biologically adequate. Store these dimensions independently:

- Sex chromosome complement and relevant variants.
- Gonadal anatomy and function.
- Internal and external reproductive anatomy.
- Hormone concentrations, pulsatility, cyclicity, and exogenous exposure.
- Body composition and other measured sex-associated traits.
- Pubertal and reproductive stage.
- Menstrual, pregnancy, trimester, postpartum, lactation, perimenopause, and
  menopause state.
- Fertility and gamete-production state.
- Congenital anatomy, prior surgery, transplant, and organ absence.
- Gender identity and social context only where relevant to the person's care,
  kept distinct from mechanistic biological variables.

Most anatomy is shared. Some population parameter distributions differ, but a
patient measurement should supersede a population prior when scientifically
appropriate. A pregnancy is a coupled maternal–placental–fetal model; the fetus
is a separate developing organism, not merely another maternal organ.

## 11. Life-course model

Age cannot be a cosmetic slider because biological rules and normal ranges
change with development.

1. Gametogenesis and meiosis.
2. Fertilization and zygote.
3. Cleavage, morula, blastocyst, and implantation.
4. Gastrulation into ectoderm, mesoderm, and endoderm.
5. Neurulation and embryonic organogenesis.
6. Fetal growth, maturation, and placental exchange.
7. Birth transition: lung aeration, circulatory shunt changes, and thermal and
   metabolic adaptation.
8. Neonatal period and infancy.
9. Childhood growth, neural and immune maturation, dentition, and skeletal
   modeling.
10. Puberty and adolescence.
11. Adult maintenance, behavior, fertility, and biological rhythms.
12. Optional pregnancy, delivery, postpartum, and lactation states.
13. Perimenopause/menopause and variable reproductive aging.
14. Later-life remodeling, senescence, reduced reserve, and variable frailty.
15. Dying and death as loss of organism-level integration; some component cells
    can remain viable transiently after organism death.

## 12. Mathematical model families

No single equation explains every scale. A common hybrid contract can contain
continuous, algebraic, event, and observed state:

\[
\dot{x}_i=f_i(x_i,u_i,\theta_i,q_i,t)+w_i,\qquad
0=g_i(x_i,u_i,\theta_i,t)
\]

\[
q_i^+=H_i(q_i,x_i,e_i),\qquad
y_k=h(x(t_k),\theta)+v_k
\]

Here \(x\) is continuous state, \(q\) a discrete biological state, \(\theta\)
person parameters, \(u\) coupled inputs, \(e\) events, \(y\) observations, and
\(w,v\) process and measurement uncertainty.

| Problem | Model family | Representative form |
| --- | --- | --- |
| Reaction network | ODE/stochastic/SBML | \(\dot n=S v(n,\theta)+J\) |
| Enzyme rate | Kinetic law | \(v=V_{max}S/(K_m+S)\) |
| Membrane voltage | Electrophysiology | \(C_m\dot V=-\sum I_{ion}+I_{stim}\) |
| Tissue transport | Reaction-diffusion PDE | \(\partial_t c=\nabla\cdot(D\nabla c)+R(c)\) |
| Tissue mechanics | Finite element | \(\rho\ddot u=\nabla\cdot\sigma+f\) |
| Blood and airflow | 0D/1D/3D fluid | Pressure-flow networks or Navier–Stokes |
| Cell population | Agent/population balance | Birth, death, migration, differentiation |
| Organ compartment | ODE/DAE | Volume and mass balances |
| Musculoskeletal motion | Multibody and muscle | Force and moment balance |
| Drug disposition/effect | PBPK/PD | Perfusion/partition plus target effect |
| Incomplete mechanism | Constrained residual ML | \(\dot x=f_{mech}+r_\phi(x,u)\) |

Import published executable models instead of retyping equations. Use
[SBML](https://sbml.org/documents/specifications/) for reaction-centered models,
CellML and the [Physiome Model Repository](https://models.physiomeproject.org/)
for physiology, [BioModels](https://www.biomodels.org/) for published biological
models, [NeuroML](https://neuroml.org/) for neural models, and
[OpenSim](https://opensim.stanford.edu/) for musculoskeletal mechanics.

## 13. Common entity and model contracts

Every anatomy entity—from ion pool to organ—needs:

- Stable instance ID and external class IDs.
- `part_of`, `located_in`, `connected_to`, `adjacent_to`, `attached_to`,
  `supplied_by`, `drains_to`, `innervated_by`, `develops_from`, `produces`,
  `consumes`, `transports`, `regulates`, and `measured_by` relations.
- Patient-relative coordinate frame and parent-relative transform.
- Geometry, segmentation, material, and mechanical bindings where applicable.
- State variables with units, valid time, uncertainty, and epistemic status.
- Input/output ports for matter, energy, charge, force, and information.
- Process-model binding and applicability domain.
- Sex-trait, anatomy, life-stage, and disease applicability.
- Measurement mapping.
- Provenance, license, version, and validation status.

Every executable model needs:

- Identity, version, immutable digest, owner, and context of use.
- Inputs and outputs with semantic IDs, UCUM units, cadence, and range.
- Equations or algorithm, solver, tolerance, and random-seed policy.
- Initial conditions and state-transition semantics.
- Parameters, population priors, patient calibration, and identifiability.
- Assumptions, exclusions, and out-of-domain behavior.
- Unit, numerical, conservation, and regression tests.
- Calibration, internal validation, external validation, and uncertainty report.
- Source publication, repository accession, license, and code commit.

Every value in the interface must be labeled as one of: **measured, derived,
estimated, simulated, counterfactual, or reference**.

## 14. Aegle implementation architecture

```mermaid
flowchart TD
    A["Reference semantics and anatomy"] --> D["Patient twin graph"]
    B["FHIR, DICOM, omics and LIFE Patch"] --> D
    C["Versioned model registry"] --> E["Multirate co-simulation"]
    D --> E
    E --> F["State estimation and uncertainty"]
    F --> D
    E --> G["Evidence package"]
    E --> H["Render-state gateway"]
    H --> I["Unreal Engine client"]
```

The implementation has eight planes:

1. Semantic/reference plane.
2. Spatial anatomy and coordinate plane.
3. Patient-data and consent plane.
4. Versioned mechanistic-model plane.
5. Calibration and state-estimation plane.
6. Multirate co-simulation plane.
7. Evidence, verification, validation, and provenance plane.
8. Presentation plane.

Unreal is the presentation and interaction client. It must not become the
authoritative store or the only physiological solver.

### 14.1 Data standards

- [HL7 FHIR](https://hl7.org/fhir/) for electronic clinical exchange.
- [DICOM](https://www.dicomstandard.org/) for medical imaging and segmentations.
- [OMOP CDM](https://ohdsi.github.io/CommonDataModel/) for cohort and
  retrospective validation data.
- [GA4GH Phenopackets](https://www.ga4gh.org/product/phenopackets/) and VRS for
  phenotype/genomic exchange.
- Native scientific formats for omics, such as VCF/CRAM, h5ad, and mzML, with
  complete metadata.
- UCUM for units, LOINC for observations, and RxNorm or an appropriate governed
  medication terminology.

### 14.2 Spatial anatomy

Start with the NLM [Visible Human Project](https://www.nlm.nih.gov/research/visible/visible_human.html)
and Human Reference Atlas objects where licensing and fidelity fit. The Visible
Human male and female each represent one cadaver and are not population-normal
templates. Retain the original coordinate frame, every registration transform,
landmark error, segmentation version, provenance, and license.

In Unreal:

1. Create exactly one `ATwinBodyActor` root.
2. Parent skin, skeleton, organs, vessels, nerves, and anchors below that root.
3. Store local transforms, never independent world transforms for organs.
4. Attach rigid structures to verified anatomical anchors.
5. Bind lungs, liver, bowel, vessels, and other deformable structures to
   volumetric deformation cages rather than one rigid bone.
6. Drive respiratory motion as a coordinated rib–diaphragm–lung–heart–abdominal
   deformation field.
7. Move or rotate only the root for global repositioning.
8. Validate left/right, anterior/posterior, and superior/inferior landmarks
   before accepting an import.
9. Bind every mesh to a stable biological entity ID.
10. Keep physiology state separate from visual materials and animations.

### 14.3 Multirate execution

Different solvers need different time steps. Illustrative—not universal—ranges:

- Electrophysiology: microseconds to milliseconds.
- Cardiorespiratory mechanics: milliseconds.
- Autonomic control: tens to hundreds of milliseconds.
- Metabolism and endocrine control: seconds to minutes.
- Gene expression, immune response, and tissue turnover: minutes to days.
- Remodeling, development, tumor growth, and aging: hours to years.
- Unreal rendering: 30–60 frames per second by interpolation, independent of
  physiological solver cadence.

The scheduler needs exact event times, checkpoints, deterministic replay,
scenario branches, rollback, conservation checks, and explicit degradation when
a component is unavailable or outside its validity domain.

## 15. Patient personalization and uncertainty

Patient data reveal only a fraction of biological state. Personalization is an
estimation problem:

\[
p(x_t,\theta\mid y_{1:t})\propto p(y_t\mid x_t,\theta)
\int p(x_t\mid x_{t-1},\theta)
p(x_{t-1},\theta\mid y_{1:t-1})\,dx
\]

Parameter priority should be:

1. Direct patient measurement.
2. Patient-derived estimate.
3. Patient imaging-derived anatomy.
4. Life-stage and population distribution.
5. Literature default.

Retain distributions when a state or parameter is not identifiable. Sources of
uncertainty include measurement error, missingness, population transfer,
parameter uncertainty, model-form discrepancy, numerical error, and scenario
assumptions.

## 16. Evidence package and credibility labels

Every run should produce a first-class evidence package containing:

1. Question and context of use.
2. Protocol and intervention.
3. Patient input snapshot and consent/purpose constraints.
4. Model IDs, versions, hashes, equations, code, and licenses.
5. Parameter sources, priors, and calibration history.
6. Solver settings, tolerances, hardware, and random seeds.
7. Assumptions and excluded mechanisms.
8. Prespecified endpoints and uncertainty intervals.
9. Real-human counterpart measurements.
10. Verification, calibration, and validation results.
11. Sensitivity, identifiability, and uncertainty analyses.
12. Applicability and out-of-domain checks.
13. Conservation and numerical diagnostics.
14. Full provenance graph.
15. Human- and machine-readable exports.

Do not label the whole product simply “validated.” Use separate dimensions:

| Dimension | Levels |
| --- | --- |
| Structural | S0 absent; S1 reference; S2 landmark/segmentation checked; S3 patient-imaging derived |
| Functional | F0 decorative; F1 prescribed animation; F2 reduced mechanistic; F3 spatial high-fidelity |
| Personalized | P0 reference; P1 demographics; P2 patient observations; P3 longitudinal imaging/omics calibration |
| Validated | V0 unverified; V1 numerical/unit tests; V2 literature benchmark; V3 independent retrospective human; V4 prospective human; V5 qualified for a regulated intended use |

Thus a component may honestly be labeled `S3 / F2 / P2 / V3`.

## 17. Step-by-step construction program

### Phase 0 — Contracts and scientific spine

1. Adopt the JSON seed and schema in this package.
2. Add stable ontology IDs and a versioned crosswalk.
3. Create the entity, state-variable, port, model, experiment, and evidence
   schemas.
4. Enforce UCUM units and dimensional checks.
5. Define coordinate frames and round-trip tests.
6. Create one golden synthetic patient and one deterministic scenario.
7. Reject any output without provenance, epistemic status, and uncertainty.

Exit: no uncoded port, no ambiguous unit, deterministic replay passes, and every
output has a source.

### Phase 1 — Structurally complete reference bodies

1. Import common, typical female, and typical male anatomy.
2. Add skin, skeleton, named muscles, organs, major vessels, lymphatics, nerves,
   ducts, and reproductive anatomy.
3. Create a stable root, local transforms, attachments, deformation cages, and
   coordinate tests.
4. Crosswalk assets to HRA/Uberon/FMA/Cell Ontology.
5. Add level-of-detail, transparent, sectional, and organ-isolation views.
6. Record source and license for every asset.
7. Maintain an anatomy coverage ledger.

Exit: no displacement during body motion, orientation landmarks pass, every
asset has identity/provenance, and reference versus patient-derived anatomy is
visible.

### Phase 2 — Living baseline

Build reduced, closed-loop physiology in this order:

1. Fluid compartments and mass-balance engine.
2. Cardiovascular pressure, flow, heart, and regional perfusion.
3. Respiratory mechanics, gas exchange, and blood gases.
4. Renal volume, electrolytes, osmolality, and acid-base.
5. Glucose-insulin and whole-body energy balance.
6. Hepatic metabolism and PBPK framework.
7. Thermoregulation.
8. Autonomic and endocrine control.
9. Blood oxygen, carbon dioxide, and hematology.
10. Rest, meal, exercise, posture, sleep, and controlled perturbation scenarios.

Exit: mass and charge residuals close within tolerance, physiological benchmark
ranges are reproduced, coupled integration is stable, and uncertainty reaches
the displayed outputs.

### Phase 3 — Personalization

1. Add FHIR, DICOM, lab, medication, wearable, LIFE Patch, and exposure
   ingestion.
2. Preserve immutable source events.
3. Register patient imaging to reference anatomy with error metrics.
4. Estimate observable parameters and retain priors for the rest.
5. Perform identifiability and sensitivity analysis.
6. Calibrate on one time window and validate on a held-out window.
7. Distinguish measured, estimated, and simulated values in Unreal.

Exit: held-out prediction intervals have tested coverage and no unknown
parameter is shown as exact.

### Phase 4 — Disease verticals

Add one end-to-end disease module at a time. The best initial order for Aegle is:

1. Type 2 diabetes and metabolic syndrome.
2. Dyslipidemia, atherosclerosis, and cardiovascular disease.
3. Non-small-cell lung cancer.

Each vertical needs pathology, biomarkers, interventions, patient mappings,
mechanistic and statistical components, uncertainty, external validation, and
claim boundaries.

### Phase 5 — Cell and molecular zoom

1. Add organ functional-unit scenes.
2. Bind cell populations to HCA/HuBMAP reference data.
3. Import SBML/CellML pathway and cellular models.
4. Add tumor, immune, vascular, and stromal agent models where justified.
5. Couple PBPK exposure to local receptor/pathway effect.
6. Run molecular dynamics only for bounded offline questions.
7. Show molecule → cell → tissue → organ → measurable outcome explanation paths.

### Phase 6 — Prospective and regulatory credibility

1. Freeze context-of-use-specific versions.
2. Pre-register endpoints and validation protocols.
3. Validate independently and prospectively.
4. Test subgroup, sex-trait, ancestry, life-stage, and device/source performance.
5. Measure calibration, discrimination, uncertainty coverage, clinical utility,
   and failure modes.
6. Add controlled change management and post-deployment monitoring.
7. Make regulated claims only for separately qualified intended uses.

## 18. Testable meaning of complete

“Complete” is a coverage contract, not a claim of omniscience.

- **Structural:** every in-scope entity has semantic identity, containment,
  topology, and spatial binding.
- **Functional:** every entity has declared transformations, state, and ports.
- **Coupled:** no system is an isolated island.
- **Conserved:** material, charge, and energy balances close where applicable.
- **Temporal:** acute cycles, adaptation, development, and aging are represented.
- **Individual:** actual anatomy, sex traits, life stage, genotype, body
  composition, pregnancy, medications, and exposures parameterize the model.
- **Observable:** variables map to real measurements.
- **Evidenced:** equations and claims have provenance and applicability domains.
- **Validated:** predictions reproduce prespecified human counterpart outcomes.
- **Uncertain:** variability and unknown state are represented explicitly.

An Aegle coverage ledger should track each entity and process across semantics,
geometry, functional model, patient specificity, human validation, and Unreal
binding. Nothing should disappear behind the word “complete.”

## 19. Authoritative source stack

| Need | Primary source or standard |
| --- | --- |
| Spatial anatomy/cells/biomarkers | [NIH Human Reference Atlas](https://humanatlas.io/) and [HuBMAP](https://hubmapconsortium.org/) |
| Male/female cross-sectional anatomy | [NLM Visible Human Project](https://www.nlm.nih.gov/research/visible/visible_human.html) |
| Cell references | [Human Cell Atlas](https://www.humancellatlas.org/) and Cell Ontology |
| Peripheral nerve-organ maps | [NIH SPARC](https://sparc.science/) |
| Anatomy ontology | Uberon and FMA |
| Chemicals/processes/proteins | ChEBI, Gene Ontology, Protein Ontology, UniProt and Reactome |
| Physiological models | [Physiome Model Repository](https://models.physiomeproject.org/) and CellML |
| Biological reaction models | [SBML](https://sbml.org/documents/specifications/) and [BioModels](https://www.biomodels.org/) |
| Neural models | [NeuroML](https://neuroml.org/) |
| Musculoskeletal simulation | [OpenSim](https://opensim.stanford.edu/) |
| Clinical exchange | [HL7 FHIR](https://hl7.org/fhir/) |
| Medical imaging | [DICOM](https://www.dicomstandard.org/) |
| Cohort validation | [OMOP CDM](https://ohdsi.github.io/CommonDataModel/) |
| Phenotype/genomics | [GA4GH Phenopackets](https://www.ga4gh.org/product/phenopackets/) and VRS |

These sources are complementary. No single atlas, ontology, file format, model
repository, or 3D engine contains a complete functional living human.
