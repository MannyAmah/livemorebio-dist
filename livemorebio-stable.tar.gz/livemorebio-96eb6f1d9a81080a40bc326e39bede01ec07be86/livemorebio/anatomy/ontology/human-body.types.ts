export type AnatomyAvailability =
  | "shared"
  | "typically_female"
  | "typically_male"
  | "state_dependent"
  | "patient_specific";

export type EpistemicStatus =
  | "measured"
  | "derived"
  | "estimated"
  | "simulated"
  | "counterfactual"
  | "reference";

export type ValidationState =
  | "conceptual"
  | "implemented"
  | "verified"
  | "calibrated"
  | "internally validated"
  | "externally validated"
  | "prospectively validated"
  | "clinically qualified";

export interface NamedEntity {
  id: string;
  name: string;
  description?: string;
}

export interface Scale extends NamedEntity {
  order: number;
  is_living_unit: boolean;
  examples: string[];
  state_variables: string[];
  model_classes: string[];
}

export interface AnatomyStructure extends NamedEntity {
  kind: string;
  availability: AnatomyAvailability;
  parts?: string[];
  ontology_hints?: string[];
}

export interface BodySystem extends NamedEntity {
  structures: AnatomyStructure[];
  core_functions: string[];
  processes: string[];
  state_variables: string[];
  primary_time_scales?: string[];
}

export interface WholeBodyProcess extends NamedEntity {
  functions: string[];
  inputs: string[];
  outputs: string[];
  regulated_variables: string[];
  model_classes?: string[];
}

export interface SystemCoupling extends NamedEntity {
  source_systems: string[];
  target_systems: string[];
  exchanged_quantities: string[];
}

export interface AuthoritativeResource {
  name: string;
  purpose: string;
  url: string;
}

export interface HumanReferenceModel {
  manifest: {
    id: string;
    version: string;
    title: string;
    scope: string;
    intended_use: string[];
    limitations: string[];
  };
  scales: Scale[];
  biological_trait_model: Record<string, unknown>;
  life_stages: NamedEntity[];
  systems: BodySystem[];
  whole_body_processes: WholeBodyProcess[];
  couplings: SystemCoupling[];
  model_contract: Record<string, string[]>;
  authoritative_resources?: AuthoritativeResource[];
}

export interface QuantityValue {
  value: number;
  ucum_unit: string;
  uncertainty?: number;
  uncertainty_method?: string;
}

export interface TwinStateValue {
  twin_id: string;
  branch_id: string;
  entity_id: string;
  state_id: string;
  valid_time: string;
  recorded_time: string;
  quantity: QuantityValue;
  epistemic_status: EpistemicStatus;
  source_ref: string;
  model_ref?: string;
  quality_flags?: string[];
}

export interface ModelPort {
  id: string;
  semantic_id: string;
  direction: "input" | "output";
  exchange_kind: "matter" | "energy" | "charge" | "force" | "information";
  ucum_unit: string;
  cadence: string;
  allowed_range?: [number, number];
}

export interface ModelBinding {
  model_id: string;
  model_version: string;
  digest: string;
  context_of_use: string;
  validation_state: ValidationState;
  ports: ModelPort[];
  applicability: {
    life_stages: string[];
    trait_requirements?: string[];
    exclusions?: string[];
  };
}

export interface GeometryBinding {
  asset_id: string;
  entity_id: string;
  source_coordinate_frame: string;
  parent_anchor_id: string;
  local_transform_id: string;
  lod: number;
  patient_specific: boolean;
  registration_error_mm?: number;
  provenance_ref: string;
}

export interface EvidencePackage {
  run_id: string;
  context_of_use: string;
  protocol_ref: string;
  input_snapshot_ref: string;
  model_digests: string[];
  parameter_snapshot_ref: string;
  solver_snapshot_ref: string;
  assumptions: string[];
  excluded_mechanisms: string[];
  predicted_endpoints: string[];
  counterpart_measurement_refs: string[];
  verification_ref: string;
  validation_ref: string;
  sensitivity_ref: string;
  uncertainty_ref: string;
  applicability_result: "in_domain" | "borderline" | "out_of_domain";
  conservation_diagnostics_ref: string;
  provenance_graph_ref: string;
}
