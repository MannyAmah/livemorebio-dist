"""Fixed-source anatomical reference admission; never a physiological engine.

Catalog/status/read are network-free. Only explicit install may acquire source
bytes. An owned converter has no publication authority; the parent verifies all
arrays before atomically publishing the immutable manifest and active receipt.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import importlib.resources
import io
import json
import math
import os
from pathlib import Path
import re
import select
import signal
import stat
import subprocess
import sys
import threading
import time
from types import CodeType, FunctionType
from typing import Any, Iterator
import urllib.error
import urllib.request
import uuid
import zipfile

from ..strict_json import parse_json_object

SOURCE_ID = "bp3d-4.0-20130619-surface-core-v1"
DECLARATION_SHA256 = "e2df5ada0b3a983c69d409ce9e18cbc4c1568208cea49fc23f40a847b6bc57ad"
ASSET_KEYS = ("skin", "heart", "liver", "pancreas", "right-kidney", "left-kidney", "right-lung", "left-lung", "brain")
NETWORK_SECONDS = 600.
CONVERSION_SECONDS = 180.
MAX_MANIFEST_BYTES = 2 * 1024 * 1024
MAX_ARCHIVE_BYTES = 144 * 1024 * 1024
MAX_GLB_BYTES = 16 * 1024 * 1024
MAX_TOTAL_GLB_BYTES = 40 * 1024 * 1024
ARCHIVE_ENTRIES = 2234
ARCHIVE_UNCOMPRESSED_BYTES = 479605380
_HEX = re.compile(r"[0-9a-f]{64}\Z", re.ASCII)
_ERRORS = {
    "ATLAS_INVALID_ID": ("Unknown or invalid fixed Atlas identifier.", 422, None),
    "ATLAS_NOT_INSTALLED": ("The reference anatomy has not been installed.", 404, None),
    "ATLAS_NOT_FOUND": ("The requested immutable reference asset was not found.", 404, None),
    "ATLAS_ACQUIRING": ("Reference anatomy acquisition is already in progress.", 409, 3),
    "ATLAS_UNSAFE_CACHE": ("The reference cache does not satisfy private file safety requirements.", 503, None),
    "ATLAS_SOURCE_POLICY": ("The source request violates the fixed HTTPS source policy.", 503, None),
    "ATLAS_SOURCE_INTEGRITY": ("The reference source failed integrity verification.", 503, None),
    "ATLAS_CONVERSION_FAILED": ("The source-preserving reference conversion did not complete.", 503, None),
    "ATLAS_INTEGRITY_FAILED": ("The admitted reference asset failed integrity verification.", 503, None),
    "ATLAS_UNSUPPORTED_CONVERTER": ("This converter identity is not supported by the reference contract.", 503, None),
    "ATLAS_PUBLICATION_UNCONFIRMED": ("Reference publication could not be durably confirmed; inspect status before retrying.", 503, None),
}

# This stdlib-only entrypoint must protect the orphan *before* importing the
# application package. An import stall is inside the same absolute deadline.
_CHILD_BOOTSTRAP = """import os,sys,stat,math,time,signal,threading
phase=sys.argv[5]
maximum={'acquisition':600.,'conversion':180.}.get(phase)
deadline=float(sys.argv[7])
remaining=deadline-time.monotonic()
if maximum is None or not math.isfinite(deadline) or not 0<remaining<=maximum:os._exit(73)
lock_fd=int(sys.argv[3]);pipe_fd=int(sys.argv[4])
info=os.fstat(lock_fd)
if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_nlink!=1 or stat.S_IMODE(info.st_mode)!=0o600:os._exit(73)
if not stat.S_ISFIFO(os.fstat(pipe_fd).st_mode):os._exit(73)
signal.signal(signal.SIGALRM,signal.SIG_DFL)
signal.setitimer(signal.ITIMER_REAL,remaining)
def parent_liveness():
    try:
        while os.read(pipe_fd,1):pass
    finally:os._exit(74)
threading.Thread(target=parent_liveness,daemon=True).start()
sys.path.insert(0,sys.argv[1])
from livemorebio.anatomy.atlas_reference import _phase_main
_phase_main(int(sys.argv[2]),lock_fd,pipe_fd,phase,sys.argv[6],deadline,sys.argv[8],sys.argv[9])
"""

# No application import in this guardian. It remains the live group leader after
# worker completion, until the installer's held-waitable group cleanup finishes.
_GUARDIAN_BOOTSTRAP = """import os,sys,stat,math,time,signal,select
def end_group():
    if os.getpgrp()==os.getpid():os.killpg(os.getpgrp(),signal.SIGKILL)
    os._exit(73)
try:
    phase=sys.argv[5];maximum={'acquisition':600.,'conversion':180.}.get(phase)
    deadline=float(sys.argv[7]);remaining=deadline-time.monotonic()
    if maximum is None or not math.isfinite(deadline) or not 0<remaining<=maximum:end_group()
    root_fd=int(sys.argv[2]);lock_fd=int(sys.argv[3]);parent_fd=int(sys.argv[4]);result_fd=int(sys.argv[10])
    info=os.fstat(lock_fd);root=os.fstat(root_fd)
    if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_nlink!=1 or stat.S_IMODE(info.st_mode)!=0o600:end_group()
    if not stat.S_ISDIR(root.st_mode) or root.st_uid!=os.getuid() or stat.S_IMODE(root.st_mode)!=0o700:end_group()
    if not all(stat.S_ISFIFO(os.fstat(fd).st_mode) for fd in (parent_fd,result_fd)):end_group()
    if os.getpgrp()!=os.getpid():end_group()
    worker_read,worker_write=os.pipe()
    worker=os.fork()
    if worker==0:
        os.close(worker_write);os.close(parent_fd);os.close(result_fd)
        sys.argv[4]=str(worker_read)
        try:
            exec(_WORKER_BOOTSTRAP_,{'__name__':'__main__'})
            os._exit(0)
        except BaseException:os._exit(73)
    os.close(worker_read)
    while True:
        remaining=deadline-time.monotonic()
        if remaining<=0:end_group()
        if select.select([parent_fd],[],[],min(.025,remaining))[0]:
            if os.read(parent_fd,1)==b'':end_group()
            end_group()
        if worker is not None:
            waited,status=os.waitpid(worker,os.WNOHANG)
            if waited==worker:
                os.write(result_fd,b'S' if os.WIFEXITED(status) and os.WEXITSTATUS(status)==0 else b'F')
                os.close(result_fd);result_fd=-1
                os.close(worker_write);worker_write=-1
                worker=None
except BaseException:end_group()
"""


class AtlasReferenceError(RuntimeError):
    """Only fixed safe messages/statuses; never accepts a raw underlying error."""

    def __init__(self, code: str):
        if not isinstance(code, str) or code not in _ERRORS:
            raise ValueError("Unknown Atlas error category")
        self._code = code
        super().__init__(_ERRORS[code][0])

    @property
    def code(self) -> str:
        return self._code

    @property
    def status_code(self) -> int:
        return _ERRORS[self._code][1]

    @property
    def retry_after(self) -> int | None:
        return _ERRORS[self._code][2]

    def __str__(self) -> str:
        return _ERRORS[self._code][0]


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False).encode("ascii")


def _digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _declaration_bytes() -> bytes:
    return importlib.resources.files("livemorebio.anatomy").joinpath("atlas", SOURCE_ID + ".json").read_bytes()


def catalog() -> dict[str, Any]:
    try:
        raw = _declaration_bytes()
        if _digest(raw) != DECLARATION_SHA256:
            raise ValueError("declaration hash")
        result = parse_json_object(raw)
        if result["source_id"] != SOURCE_ID or result["schema"] != "livemore.atlas-source.v1":
            raise ValueError("declaration identity")
        return result
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY") from error


def _source_id(value: Any) -> None:
    if type(value) is not str or value != SOURCE_ID:
        raise AtlasReferenceError("ATLAS_INVALID_ID")


def _manifest_id(value: Any) -> None:
    if not isinstance(value, str) or not _HEX.fullmatch(value):
        raise AtlasReferenceError("ATLAS_INVALID_ID")


def _asset_key(value: Any) -> None:
    if type(value) is not str or value not in ASSET_KEYS:
        raise AtlasReferenceError("ATLAS_INVALID_ID")


def _safe_directory(info: os.stat_result, *, private: bool = True) -> None:
    unsafe_mode = stat.S_IMODE(info.st_mode) != 0o700 if private else bool(stat.S_IMODE(info.st_mode) & 0o022)
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or unsafe_mode:
        raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")


def _safe_file(info: os.stat_result) -> None:
    if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
            or info.st_nlink != 1 or stat.S_IMODE(info.st_mode) != 0o600):
        raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")


def _identity(info: os.stat_result) -> tuple[int, ...]:
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns,
            info.st_uid, info.st_mode, info.st_nlink)


def _path_parts(relative: str) -> list[str]:
    if not isinstance(relative, str):
        raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")
    parts = relative.split("/")
    if len(parts) > 8 or not all(re.fullmatch(r"[a-zA-Z0-9_.-]{1,100}", part, re.ASCII) and part not in (".", "..") for part in parts):
        raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")
    return parts


def _same_directory(first: os.stat_result, second: os.stat_result) -> bool:
    return (first.st_dev, first.st_ino, first.st_uid, first.st_mode) == (second.st_dev, second.st_ino, second.st_uid, second.st_mode)


def _validate_parent_path(parent: Path) -> None:
    # macOS supplies these root-owned aliases. No user-created cache ancestor
    # symlink acquires authority merely because resolve() finds an owned target.
    system_aliases = {"/var": "private/var", "/tmp": "private/tmp", "/etc": "private/etc"}
    for component in [*reversed(parent.parents), parent]:
        try:
            info = component.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) and not (
                info.st_uid == 0 and str(component) in system_aliases
                and os.readlink(component) in {system_aliases[str(component)], "/" + system_aliases[str(component)]}):
            raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")


class _Cache:
    """Descriptor-relative operations keep a checked root authoritative."""

    def __init__(self, *, create: bool = False):
        if os.name != "posix" or not hasattr(os, "O_NOFOLLOW"):
            raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")
        self.fd: int | None = None
        self.parent_fd: int | None = None
        parent = Path(os.environ.get("LIVEMORE_ANATOMY_DIR", str(Path.home() / ".livemore" / "anatomy")))
        if not parent.is_absolute():
            raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")
        self.parent_path = parent
        try:
            _validate_parent_path(parent)
            if create and not parent.exists():
                parent.mkdir(mode=0o700, parents=True)
            _safe_directory(parent.lstat(), private=False)
            parent_fd = os.open(parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                _safe_directory(os.fstat(parent_fd), private=False)
                if create:
                    try:
                        os.mkdir("atlas", 0o700, dir_fd=parent_fd)
                        os.fsync(parent_fd)
                    except FileExistsError:
                        pass
                self.fd = os.open("atlas", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent_fd)
                _safe_directory(os.fstat(self.fd))
                self.parent_fd = os.dup(parent_fd)
                self._assert_root()
            finally:
                os.close(parent_fd)
        except FileNotFoundError:
            self.close()
            if create:
                raise AtlasReferenceError("ATLAS_UNSAFE_CACHE") from None
        except (OSError, AtlasReferenceError) as error:
            self.close()
            if isinstance(error, AtlasReferenceError):
                raise
            raise AtlasReferenceError("ATLAS_UNSAFE_CACHE") from error

    def close(self) -> None:
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None
        if self.parent_fd is not None:
            os.close(self.parent_fd)
            self.parent_fd = None

    def _assert_root(self) -> None:
        if self.fd is None:
            raise AtlasReferenceError("ATLAS_NOT_INSTALLED")
        _safe_directory(os.fstat(self.fd))
        if self.parent_fd is None:
            return  # The converter receives the checked root FD, never a path.
        try:
            _validate_parent_path(self.parent_path)
            actual_parent = self.parent_path.lstat()
            _safe_directory(actual_parent, private=False)
            if (not _same_directory(actual_parent, os.fstat(self.parent_fd))
                    or not _same_directory(os.fstat(self.fd), os.stat("atlas", dir_fd=self.parent_fd, follow_symlinks=False))):
                raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")
        except OSError as error:
            raise AtlasReferenceError("ATLAS_UNSAFE_CACHE") from error

    def __enter__(self) -> "_Cache":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    @contextmanager
    def directory(self, relative: str | None = None, *, create: bool = False) -> Iterator[int]:
        self._assert_root()
        opened = [os.dup(self.fd)]
        anchors = []
        current = opened[0]
        try:
            for part in _path_parts(relative) if relative else []:
                if create:
                    try:
                        os.mkdir(part, 0o700, dir_fd=current)
                        os.fsync(current)
                    except FileExistsError:
                        pass
                try:
                    child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=current)
                except FileNotFoundError:
                    raise
                except OSError as error:
                    raise AtlasReferenceError("ATLAS_UNSAFE_CACHE") from error
                anchors.append((current, part, child))
                opened.append(child)
                current = child
                _safe_directory(os.fstat(current))
                if not _same_directory(os.fstat(child), os.stat(part, dir_fd=anchors[-1][0], follow_symlinks=False)):
                    raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")
            yield current
            self._assert_root()
            for parent_fd, part, child_fd in anchors:
                _safe_directory(os.fstat(child_fd))
                if not _same_directory(os.fstat(child_fd), os.stat(part, dir_fd=parent_fd, follow_symlinks=False)):
                    raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")
        finally:
            for descriptor in reversed(opened):
                os.close(descriptor)

    @contextmanager
    def file(self, relative: str) -> Iterator[Any]:
        parts = _path_parts(relative)
        with self.directory("/".join(parts[:-1]) or None) as parent:
            try:
                descriptor = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
            except FileNotFoundError:
                raise
            except OSError as error:
                raise AtlasReferenceError("ATLAS_UNSAFE_CACHE") from error
            try:
                before = os.fstat(descriptor)
                _safe_file(before)
                if _identity(before) != _identity(os.stat(parts[-1], dir_fd=parent, follow_symlinks=False)):
                    raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")
                with os.fdopen(descriptor, "rb", closefd=False) as stream:
                    yield stream
                if (_identity(before) != _identity(os.fstat(descriptor))
                        or _identity(before) != _identity(os.stat(parts[-1], dir_fd=parent, follow_symlinks=False))):
                    raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED")
            finally:
                os.close(descriptor)

    def read(self, relative: str, maximum: int) -> bytes:
        with self.file(relative) as stream:
            if os.fstat(stream.fileno()).st_size > maximum:
                raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED")
            raw = stream.read(maximum + 1)
            if len(raw) > maximum:
                raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED")
            return raw

    @contextmanager
    def output(self, relative: str) -> Iterator[Any]:
        parts = _path_parts(relative)
        with self.directory("/".join(parts[:-1]) or None, create=True) as parent:
            name = parts[-1]
            try:
                _safe_file(os.stat(name, dir_fd=parent, follow_symlinks=False))
            except FileNotFoundError:
                pass
            temporary = ".temporary-" + uuid.uuid4().hex
            descriptor = os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600, dir_fd=parent)
            published = False
            try:
                with os.fdopen(descriptor, "wb", closefd=False) as stream:
                    yield stream
                    stream.flush()
                    os.fsync(descriptor)
                try:
                    _safe_file(os.stat(name, dir_fd=parent, follow_symlinks=False))
                except FileNotFoundError:
                    pass
                os.rename(temporary, name, src_dir_fd=parent, dst_dir_fd=parent)
                published = True
                os.fsync(parent)
            finally:
                os.close(descriptor)
                if not published:
                    os.unlink(temporary, dir_fd=parent)

    def write(self, relative: str, raw: bytes) -> None:
        with self.output(relative) as stream:
            stream.write(raw)

    def acquiring(self) -> bool:
        """Inspect an existing lock only: status must never create cache files."""
        import fcntl
        try:
            with self.file(".install.lock") as stream:
                try:
                    fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    return True
                except OSError as error:
                    raise AtlasReferenceError("ATLAS_UNSAFE_CACHE") from error
                return False  # Closing this independent descriptor releases it.
        except FileNotFoundError:
            return False

    @contextmanager
    def lock(self) -> Iterator[int]:
        import fcntl
        with self.directory() as directory:
            try:
                descriptor = os.open(".install.lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600, dir_fd=directory)
            except OSError as error:
                raise AtlasReferenceError("ATLAS_UNSAFE_CACHE") from error
            try:
                _safe_file(os.fstat(descriptor))
                if _identity(os.fstat(descriptor)) != _identity(os.stat(".install.lock", dir_fd=directory, follow_symlinks=False)):
                    raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")
                try:
                    fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError as error:
                    raise AtlasReferenceError("ATLAS_ACQUIRING") from error
                except OSError as error:
                    raise AtlasReferenceError("ATLAS_UNSAFE_CACHE") from error
                yield descriptor
            finally:
                # A inherited child's shared open description must retain the
                # lock after parent death; never issue LOCK_UN here.
                os.close(descriptor)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args: Any, **kwargs: Any) -> None:
        raise AtlasReferenceError("ATLAS_SOURCE_POLICY")


def _validate_source_url(url: Any) -> None:
    allowed = {item["url"] for item in catalog()["source_files"]}
    if not isinstance(url, str) or url not in allowed or not url.startswith("https://"):
        raise AtlasReferenceError("ATLAS_SOURCE_POLICY")


def _open_source(url: str, timeout: float) -> Any:
    _validate_source_url(url)
    request = urllib.request.Request(url, headers={"User-Agent": "livemorebio-fixed-atlas/1"})
    return urllib.request.build_opener(_NoRedirect()).open(request, timeout=timeout)


def _source_file(item: dict[str, Any]) -> str:
    return "sources/" + item["sha256"] + "." + ("zip" if item["key"] == "archive" else "txt")


def _hash_stream(stream: Any, size: int) -> str:
    if os.fstat(stream.fileno()).st_size != size:
        raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")
    digest = hashlib.sha256()
    count = 0
    for chunk in iter(lambda: stream.read(256 * 1024), b""):
        count += len(chunk)
        if count > size:
            raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")
        digest.update(chunk)
    if count != size:
        raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")
    stream.seek(0)
    return digest.hexdigest()


def _acquire(cache: _Cache, item: dict[str, Any], deadline: float) -> None:
    destination = _source_file(item)
    try:
        with cache.file(destination) as stream:
            if _hash_stream(stream, item["bytes"]) != item["sha256"]:
                raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")
        return
    except FileNotFoundError:
        pass
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise AtlasReferenceError("ATLAS_SOURCE_POLICY")
    _validate_source_url(item["url"])
    try:
        with _open_source(item["url"], min(30., remaining)) as response, cache.output(destination) as output:
            if response.geturl() != item["url"] or getattr(response, "status", 200) != 200:
                raise AtlasReferenceError("ATLAS_SOURCE_POLICY")
            length = response.headers.get("Content-Length")
            if length is not None and (not str(length).isdigit() or int(length) != item["bytes"]):
                raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")
            count = 0
            digest = hashlib.sha256()
            while True:
                if time.monotonic() >= deadline:
                    raise AtlasReferenceError("ATLAS_SOURCE_POLICY")
                chunk = response.read(256 * 1024)
                if time.monotonic() >= deadline:
                    raise AtlasReferenceError("ATLAS_SOURCE_POLICY")
                if not chunk:
                    break
                count += len(chunk)
                if count > item["bytes"] or count > MAX_ARCHIVE_BYTES:
                    raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")
                digest.update(chunk)
                output.write(chunk)
            if count != item["bytes"] or digest.hexdigest() != item["sha256"]:
                raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")
    except AtlasReferenceError:
        raise
    except (OSError, ValueError, urllib.error.URLError) as error:
        raise AtlasReferenceError("ATLAS_SOURCE_POLICY") from error


def _acquire_sources(cache: _Cache, deadline: float) -> None:
    for item in catalog()["source_files"]:
        if time.monotonic() >= deadline:
            raise AtlasReferenceError("ATLAS_SOURCE_POLICY")
        _acquire(cache, item, deadline)


def _code_value(value: Any) -> Any:
    """Stable loaded semantics, excluding checkout paths and marshal ref flags."""
    if isinstance(value, CodeType):
        return {"bytecode": value.co_code.hex(), "constants": [_code_value(v) for v in value.co_consts],
                "names": value.co_names, "variables": value.co_varnames, "free": value.co_freevars,
                "cells": value.co_cellvars, "args": [value.co_argcount, value.co_posonlyargcount,
                    value.co_kwonlyargcount], "flags": value.co_flags, "exception_table": value.co_exceptiontable.hex()}
    if value is None or type(value) in (str, int, bool):
        return value
    if type(value) is float:
        return {"float": value.hex()}
    if isinstance(value, bytes):
        return {"bytes": value.hex()}
    if isinstance(value, (list, tuple)):
        return {type(value).__name__: [_code_value(v) for v in value]}
    if isinstance(value, (set, frozenset)):
        return {type(value).__name__: sorted((_code_value(v) for v in value), key=lambda v: _canonical(v))}
    if isinstance(value, dict) and all(isinstance(k, str) for k in value):
        return {k: _code_value(v) for k, v in sorted(value.items())}
    if value is Ellipsis:
        return {"singleton": "ellipsis"}
    raise ValueError("unsupported loaded converter constant")


def _function_identity(function: FunctionType) -> dict[str, Any]:
    return {"code": _code_value(function.__code__), "defaults": _code_value(function.__defaults__),
            "keyword_defaults": _code_value(function.__kwdefaults__)}


def _converter_identity() -> dict[str, Any]:
    from . import _atlas_geometry as geometry
    try:
        import numpy
        import trimesh
        from trimesh.exchange import gltf
        from .. import strict_json
        if trimesh.__version__ != "5.0.0":
            raise ValueError("unreviewed exporter version")
        functions = {name: _function_identity(function) for name, function in vars(geometry).items()
                     if isinstance(function, FunctionType) and function.__module__ == geometry.__name__}
        # Explicit entrypoints remain included when replaced by a test or runtime hook.
        for name in ("parse_obj", "convert_partition", "verify_partition", "_integer", "_decode", "_array", "_fields", "_node_matrix", "_zero_faces"):
            functions[name] = _function_identity(getattr(geometry, name))
        for name in ("export_glb", "_append_mesh", "_create_gltf_structure", "_build_views"):
            functions["trimesh." + name] = _function_identity(getattr(gltf, name))
        for name, function in vars(strict_json).items():
            if isinstance(function, FunctionType) and function.__module__ == strict_json.__name__:
                functions["strict_json." + name] = _function_identity(function)
        constants = {"headers": geometry._HEADERS, "id_pattern": geometry._ID.pattern,
                     "obj_limit": geometry.MAX_OBJ_BYTES, "glb_limit": geometry.MAX_GLB_BYTES,
                     "json_limit": geometry.MAX_JSON_BYTES}
        code = _canonical({"functions": functions, "constants": constants})
        return {"version": geometry.CONVERSION_VERSION, "python": sys.version.split()[0],
                "numpy": numpy.__version__, "trimesh": trimesh.__version__, "loaded_code_sha256": _digest(code),
                "options": {"process": False, "validate": False, "include_normals": True,
                            "unitize_normals": False, "draco": False},
                "root_matrix_column_major": geometry.ROOT_MATRIX.flatten(order="F").tolist()}
    except (ImportError, AttributeError, ValueError) as error:
        raise AtlasReferenceError("ATLAS_UNSUPPORTED_CONVERTER") from error


def _status_value(state: str, reason: str, manifest: dict[str, Any] | None = None,
                  manifest_sha256: str | None = None) -> dict[str, Any]:
    return {"schema": "livemore.atlas-reference-status.v1", "source_id": SOURCE_ID,
            "state": state, "available": state == "available", "manifest_sha256": manifest_sha256,
            "manifest": manifest, "reason": reason, "reference_geometry": True, "patient_registered": False}


def status() -> dict[str, Any]:
    catalog()
    try:
        with _Cache() as cache:
            if cache.fd is None:
                return _status_value("missing", "Reference anatomy has not been installed.")
            if cache.acquiring():
                return _status_value("acquiring", "Reference anatomy acquisition is already in progress.")
            manifest, digest = _read_manifest(cache)
            _verify_assets(cache, manifest, digest)
            return _status_value("available", "Reference-only geometry bytes are verified; renderer and physiology are separate.", manifest, digest)
    except (FileNotFoundError, AtlasReferenceError) as error:
        if isinstance(error, FileNotFoundError) or error.code == "ATLAS_NOT_INSTALLED":
            return _status_value("missing", "Reference anatomy has not been installed.")
        state = {"ATLAS_UNSAFE_CACHE": "unsafe_cache", "ATLAS_ACQUIRING": "acquiring",
                 "ATLAS_UNSUPPORTED_CONVERTER": "unsupported_converter"}.get(error.code, "corrupt")
        return _status_value(state, str(error))


def read_manifest(manifest_sha256: str | None = None) -> dict[str, Any]:
    if manifest_sha256 is not None:
        _manifest_id(manifest_sha256)
    with _Cache() as cache:
        try:
            manifest, digest = _read_manifest(cache, manifest_sha256)
            _verify_assets(cache, manifest, digest)
            return manifest
        except FileNotFoundError as error:
            raise AtlasReferenceError("ATLAS_NOT_INSTALLED" if manifest_sha256 is None else "ATLAS_NOT_FOUND") from error


def read_asset(manifest_sha256: str, asset_key: str) -> tuple[bytes, dict[str, Any]]:
    _manifest_id(manifest_sha256)
    _asset_key(asset_key)
    with _Cache() as cache:
        try:
            manifest, digest = _read_manifest(cache, manifest_sha256)
            result = _verify_assets(cache, manifest, digest, only=asset_key)
            raw, asset = result[asset_key]
            return raw, {"source_id": SOURCE_ID, "manifest_sha256": digest, "asset_key": asset_key,
                         "sha256": asset["sha256"], "bytes": len(raw), "license": "CC-BY-4.0",
                         "evidence_state": "REFERENCE_ONLY"}
        except FileNotFoundError as error:
            raise AtlasReferenceError("ATLAS_NOT_FOUND") from error


def _verify_maps(cache: _Cache, declaration: dict[str, Any]) -> None:
    for item in declaration["source_files"]:
        if item["key"] == "archive":
            continue
        raw = cache.read(_source_file(item), 8 * 1024 * 1024)
        if len(raw) != item["bytes"] or _digest(raw) != item["sha256"]:
            raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")
        try:
            rows = raw.decode("utf-8").splitlines()
            if not rows or rows[0] != "concept id\tname\telement file id":
                raise ValueError("map schema")
            requested = {g["fma"]: set() for g in declaration["groups"] if g["logic"] == item["key"]}
            for row in rows[1:]:
                columns = row.split("\t")
                if len(columns) != 3:
                    raise ValueError("map columns")
                if columns[0] in requested:
                    requested[columns[0]].add(columns[2])
            for group in declaration["groups"]:
                if group["logic"] == item["key"] and requested[group["fma"]] != set(group["element_ids"]):
                    raise ValueError("group membership")
        except (ValueError, UnicodeError, KeyError, TypeError) as error:
            raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY") from error


@contextmanager
def _archive(cache: _Cache, declaration: dict[str, Any]) -> Iterator[zipfile.ZipFile]:
    item = next(item for item in declaration["source_files"] if item["key"] == "archive")
    _verify_maps(cache, declaration)
    with cache.file(_source_file(item)) as stream:
        if _hash_stream(stream, item["bytes"]) != item["sha256"]:
            raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")
        try:
            with zipfile.ZipFile(stream) as archive:
                _validate_zip(archive, declaration)
                yield archive
        except (zipfile.BadZipFile, RuntimeError, ValueError, EOFError) as error:
            if isinstance(error, AtlasReferenceError):
                raise
            raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY") from error


def _validate_zip(archive: zipfile.ZipFile, declaration: dict[str, Any]) -> None:
    infos = archive.infolist()
    if len(infos) != ARCHIVE_ENTRIES or sum(i.file_size for i in infos) != ARCHIVE_UNCOMPRESSED_BYTES:
        raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")
    names: set[str] = set()
    for info in infos:
        mode = (info.external_attr >> 16) & 0o170000
        if (not re.fullmatch(r"isa_BP3D_4\.0_obj_99/FJ[0-9]+M?\.obj", info.filename, re.ASCII)
                or info.filename in names or info.is_dir() or info.flag_bits & 1
                or mode not in (0, stat.S_IFREG) or not 0 < info.file_size <= 32 * 1024 * 1024
                or info.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED)):
            raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")
        names.add(info.filename)
    for member in declaration["members"]:
        if member["archive_member"] not in names or archive.getinfo(member["archive_member"]).file_size != member["source_bytes"]:
            raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")


def _group_parts(archive: zipfile.ZipFile, group: dict[str, Any], declaration: dict[str, Any]) -> list[dict[str, Any]]:
    from ._atlas_geometry import parse_obj
    members = {m["element_id"]: m for m in declaration["members"]}
    result = []
    try:
        for element_id in sorted(group["element_ids"]):
            member = members[element_id]
            with archive.open(member["archive_member"]) as source:
                raw = source.read(member["source_bytes"] + 1)
            part = parse_obj(raw, member)
            part["memberships"] = [{"asset_key": candidate["asset_key"], "logic": candidate["logic"], "fma": candidate["fma"]}
                                   for candidate in declaration["groups"] if element_id in candidate["element_ids"]]
            if len(part["memberships"]) != 1:
                raise ValueError("initial disjoint source partition changed")
            result.append(part)
    except (KeyError, ValueError, OverflowError, UnicodeError, OSError) as error:
        raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY") from error
    return result


def _manifest_base(declaration: dict[str, Any], conversion: dict[str, Any]) -> dict[str, Any]:
    return {"schema": "livemore.atlas-reference.v1", "source_id": SOURCE_ID,
            "declaration_sha256": DECLARATION_SHA256, "evidence_state": "REFERENCE_ONLY",
            "patient_registered": False, "reference_kind": declaration["reference_kind"],
            "release": declaration["release"], "source_files": declaration["source_files"],
            "source_axes": declaration["source_axes"], "conversion": conversion,
            "groups": declaration["groups"], "members": declaration["members"],
            "rights": {"license": declaration["current_publisher_license"], "license_url": declaration["license_url"],
                       "attribution": declaration["attribution"], "historical_notice": declaration["retained_embedded_historical_notice"],
                       "change_notice": declaration["change_notice"], "publication": "internal_authorized_only"},
            "limitations": declaration["limitations"]}


def _read_manifest(cache: _Cache, digest: str | None = None) -> tuple[dict[str, Any], str]:
    if cache.fd is None:
        raise AtlasReferenceError("ATLAS_NOT_INSTALLED")
    pointer = None
    try:
        if digest is None:
            pointer = parse_json_object(cache.read("active.json", 4096))
            if set(pointer) != {"source_id", "manifest_sha256", "receipt_id"} or pointer["source_id"] != SOURCE_ID:
                raise ValueError("pointer identity")
            digest = pointer["manifest_sha256"]
        if not isinstance(digest, str) or not _HEX.fullmatch(digest):
            raise ValueError("stored manifest identity")
        receipt = parse_json_object(cache.read(f"receipts/{digest}.json", 4096))
        _validate_receipt(receipt, digest)
        if pointer is not None and pointer["receipt_id"] != receipt["receipt_id"]:
            raise ValueError("pointer receipt mismatch")
        raw = cache.read(f"artifacts/{digest}/manifest.json", MAX_MANIFEST_BYTES)
        if _digest(raw) != digest:
            raise ValueError("manifest digest")
        manifest = parse_json_object(raw)
        expected = _manifest_base(catalog(), _converter_identity())
        if _canonical(manifest.get("conversion")) != _canonical(expected["conversion"]):
            raise AtlasReferenceError("ATLAS_UNSUPPORTED_CONVERTER")
        if set(manifest) != {*expected, "assets"} or _canonical({k: manifest.get(k) for k in expected}) != _canonical(expected):
            raise ValueError("manifest source binding")
        assets = manifest["assets"]
        if (not isinstance(assets, list) or len(assets) != len(ASSET_KEYS)
                or [a.get("asset_key") for a in assets if isinstance(a, dict)] != list(ASSET_KEYS)):
            raise ValueError("manifest assets")
        if sum(a["bytes"] for a in assets) > MAX_TOTAL_GLB_BYTES:
            raise ValueError("total size")
        for asset in assets:
            if (set(asset) != {"asset_key", "sha256", "bytes", "audit"}
                    or type(asset["bytes"]) is not int or not 28 <= asset["bytes"] <= MAX_GLB_BYTES):
                raise ValueError("asset fields")
            if not isinstance(asset["sha256"], str) or not _HEX.fullmatch(asset["sha256"]):
                raise ValueError("stored asset identity")
        return manifest, digest
    except FileNotFoundError as error:
        if pointer is not None:
            raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED") from error
        raise
    except AtlasReferenceError:
        raise
    except (ValueError, KeyError, TypeError, OverflowError) as error:
        raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED") from error


def _verify_assets(cache: _Cache, manifest: dict[str, Any], digest: str,
                   *, only: str | None = None) -> dict[str, tuple[bytes, dict[str, Any]]]:
    try:
        return _verify_asset_arrays(cache, manifest, digest, only=only)
    except FileNotFoundError as error:
        raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED") from error


def _verify_asset_arrays(cache: _Cache, manifest: dict[str, Any], digest: str,
                         *, only: str | None = None) -> dict[str, tuple[bytes, dict[str, Any]]]:
    from ._atlas_geometry import verify_partition
    declaration = catalog()
    result = {}
    with _archive(cache, declaration) as archive:
        for group, asset in zip(declaration["groups"], manifest["assets"], strict=True):
            key = group["asset_key"]
            if only is not None and only != key:
                continue
            raw = cache.read(f"artifacts/{digest}/{key}.glb", MAX_GLB_BYTES)
            if len(raw) != asset["bytes"] or _digest(raw) != asset["sha256"]:
                raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED")
            parts = _group_parts(archive, group, declaration)
            try:
                audit = verify_partition(raw, key, parts)
                if _canonical(audit) != _canonical(asset["audit"]):
                    raise ValueError("audit differs")
            except (ValueError, KeyError, TypeError, IndexError, OverflowError) as error:
                raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED") from error
            result[key] = (raw, asset)
    return result


def _build_stage(cache: _Cache, stage: str, deadline: float | None = None) -> dict[str, Any]:
    from ._atlas_geometry import convert_partition, verify_partition
    declaration = catalog()
    manifest = _manifest_base(declaration, _converter_identity())
    assets = []
    with _archive(cache, declaration) as archive:
        for group in declaration["groups"]:
            if deadline is not None and time.monotonic() >= deadline:
                raise AtlasReferenceError("ATLAS_CONVERSION_FAILED")
            parts = _group_parts(archive, group, declaration)
            raw = convert_partition(group["asset_key"], parts)
            audit = verify_partition(raw, group["asset_key"], parts)
            assets.append({"asset_key": group["asset_key"], "sha256": _digest(raw), "bytes": len(raw), "audit": audit})
            if sum(a["bytes"] for a in assets) > MAX_TOTAL_GLB_BYTES:
                raise AtlasReferenceError("ATLAS_CONVERSION_FAILED")
            cache.write(f"{stage}/{group['asset_key']}.glb", raw)
    manifest["assets"] = assets
    cache.write(f"{stage}/manifest.json", _canonical(manifest))
    return manifest


def _validated_stage(cache: _Cache, stage: str) -> tuple[dict[str, Any], str]:
    from ._atlas_geometry import verify_partition
    raw = cache.read(stage + "/manifest.json", MAX_MANIFEST_BYTES)
    manifest = parse_json_object(raw)
    declaration = catalog()
    expected = _manifest_base(declaration, _converter_identity())
    if set(manifest) != {*expected, "assets"} or _canonical({k: manifest.get(k) for k in expected}) != _canonical(expected):
        raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED")
    if [a["asset_key"] for a in manifest["assets"]] != list(ASSET_KEYS):
        raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED")
    total = 0
    with _archive(cache, declaration) as archive:
        for group, asset in zip(declaration["groups"], manifest["assets"], strict=True):
            data = cache.read(f"{stage}/{group['asset_key']}.glb", MAX_GLB_BYTES)
            total += len(data)
            audit = verify_partition(data, group["asset_key"], _group_parts(archive, group, declaration))
            if set(asset) != {"asset_key", "sha256", "bytes", "audit"} or _canonical(asset) != _canonical({
                "asset_key": group["asset_key"], "sha256": _digest(data), "bytes": len(data), "audit": audit}):
                raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED")
    if total > MAX_TOTAL_GLB_BYTES:
        raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED")
    return manifest, _digest(raw)


def _child_lifetime(lock_fd: int, pipe_fd: int, seconds: float, *, phase: str = "conversion") -> None:
    """Retain inherited flock; independent OS timer is the native-call backstop."""
    maximum = {"acquisition": NETWORK_SECONDS, "conversion": CONVERSION_SECONDS}.get(phase)
    if (maximum is None or type(seconds) not in (int, float) or not math.isfinite(seconds)
            or not 0 < seconds <= maximum or threading.current_thread() is not threading.main_thread()):
        raise AtlasReferenceError("ATLAS_CONVERSION_FAILED")
    _safe_file(os.fstat(lock_fd))
    if not stat.S_ISFIFO(os.fstat(pipe_fd).st_mode):
        raise AtlasReferenceError("ATLAS_CONVERSION_FAILED")
    signal.signal(signal.SIGALRM, signal.SIG_DFL)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    def watch_parent() -> None:
        try:
            while os.read(pipe_fd, 1):
                pass
        finally:
            os._exit(74)
    threading.Thread(target=watch_parent, name="atlas-parent-liveness", daemon=True).start()


def _phase_main(root_fd: int, lock_fd: int, pipe_fd: int, phase: str, stage: str, deadline: float,
                expected_source_sha: str, expected_converter_sha: str) -> None:
    maximum = {"acquisition": NETWORK_SECONDS, "conversion": CONVERSION_SECONDS}.get(phase) if isinstance(phase, str) else None
    if maximum is None or type(deadline) not in (int, float) or not math.isfinite(deadline):
        raise AtlasReferenceError("ATLAS_SOURCE_POLICY")
    remaining = deadline - time.monotonic()
    if not 0 < remaining <= maximum:
        raise AtlasReferenceError("ATLAS_SOURCE_POLICY" if phase == "acquisition" else "ATLAS_CONVERSION_FAILED")
    _child_lifetime(lock_fd, pipe_fd, remaining, phase=phase)
    _safe_directory(os.fstat(root_fd))
    if catalog()["source_id"] != SOURCE_ID or expected_source_sha != DECLARATION_SHA256:
        raise AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")
    cache = object.__new__(_Cache)
    cache.fd = os.dup(root_fd)
    cache.parent_fd = None
    with cache:
        if phase == "acquisition":
            if stage != "" or expected_converter_sha != "":
                raise AtlasReferenceError("ATLAS_SOURCE_POLICY")
            _acquire_sources(cache, deadline)
        else:
            if not isinstance(stage, str) or not re.fullmatch(r"\.staging-[0-9a-f]{32}", stage, re.ASCII):
                raise AtlasReferenceError("ATLAS_CONVERSION_FAILED")
            if _digest(_canonical(_converter_identity())) != expected_converter_sha:
                raise AtlasReferenceError("ATLAS_UNSUPPORTED_CONVERTER")
            _build_stage(cache, stage, deadline)
        if time.monotonic() >= deadline:
            raise AtlasReferenceError("ATLAS_SOURCE_POLICY" if phase == "acquisition" else "ATLAS_CONVERSION_FAILED")


def _launch_conversion(cache: _Cache, lock_fd: int, stage: str) -> None:
    _launch_phase(cache, lock_fd, "conversion", stage)


def _launch_acquisition(cache: _Cache, lock_fd: int) -> None:
    _launch_phase(cache, lock_fd, "acquisition", "")


def _stop_child(child: subprocess.Popen) -> dict[str, Any]:
    from ._atlas_process import terminate_owned_group
    return terminate_owned_group(child)


def _launch_phase(cache: _Cache, lock_fd: int, phase: str, stage: str) -> None:
    from ._atlas_process import ProcessOwnershipError, ensure_supported
    if phase not in ("acquisition", "conversion"):
        raise AtlasReferenceError("ATLAS_SOURCE_POLICY")
    try:
        ensure_supported()
    except ProcessOwnershipError as error:
        raise AtlasReferenceError("ATLAS_UNSUPPORTED_CONVERTER") from error
    conversion = _digest(_canonical(_converter_identity())) if phase == "conversion" else ""
    seconds = NETWORK_SECONDS if phase == "acquisition" else CONVERSION_SECONDS
    failure = "ATLAS_SOURCE_POLICY" if phase == "acquisition" else "ATLAS_CONVERSION_FAILED"
    package_parent = str(Path(__file__).resolve().parents[2])
    read_pipe, write_pipe = os.pipe()
    result_read, result_write = -1, -1
    deadline = time.monotonic() + seconds
    child: subprocess.Popen | None = None
    result = b""
    cleanup: dict[str, Any] | None = None
    try:
        result_read, result_write = os.pipe()
        bootstrap = _GUARDIAN_BOOTSTRAP.replace("_WORKER_BOOTSTRAP_", repr(_CHILD_BOOTSTRAP))
        command = [sys.executable, "-I", "-B", "-c", bootstrap,
                   package_parent, str(cache.fd), str(lock_fd), str(read_pipe), phase, stage, str(deadline),
                   DECLARATION_SHA256, conversion, str(result_write)]
        child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 close_fds=True, pass_fds=(cache.fd, lock_fd, read_pipe, result_write), start_new_session=True,
                                 cwd=package_parent, env={"PATH": os.defpath, "LANG": "C.UTF-8",
                                                        "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1"})
        os.close(read_pipe)
        read_pipe = -1
        os.close(result_write)
        result_write = -1
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise AtlasReferenceError(failure)
            if not select.select([result_read], [], [], min(.05, remaining))[0]:
                continue
            block = os.read(result_read, 2)
            if not block:
                if result != b"S":
                    raise AtlasReferenceError(failure)
                break
            result += block
            if result not in (b"S", b"F"):
                raise AtlasReferenceError(failure)
    except OSError as error:
        raise AtlasReferenceError(failure) from error
    finally:
        try:
            if child is not None:
                try:
                    cleanup = _stop_child(child)
                except ProcessOwnershipError as error:
                    raise AtlasReferenceError(failure) from error
        finally:
            # Close parent liveness only after the guarded cleanup attempt. On
            # ownership failure this EOF still asks the live guardian to stop.
            for descriptor in (write_pipe, read_pipe, result_read, result_write):
                if descriptor >= 0:
                    os.close(descriptor)
    if cleanup is None or cleanup["descendants"] or time.monotonic() >= deadline:
        raise AtlasReferenceError(failure)


def _validate_receipt(receipt: Any, digest: str) -> dict[str, Any]:
    """One typed admission rule for existing reads and prospective publication."""
    try:
        if (not isinstance(receipt, dict)
                or set(receipt) != {"receipt_id", "source_id", "manifest_sha256", "started_at", "completed_at"}
                or receipt["source_id"] != SOURCE_ID or receipt["manifest_sha256"] != digest
                or not isinstance(digest, str) or not _HEX.fullmatch(digest)
                or not isinstance(receipt["receipt_id"], str) or not re.fullmatch(r"[0-9a-f]{32}", receipt["receipt_id"])
                or not all(isinstance(receipt[key], str) for key in ("started_at", "completed_at"))):
            raise ValueError("receipt identity")
        times = [datetime.fromisoformat(receipt[key]) for key in ("started_at", "completed_at")]
        if any(value.tzinfo is None or value.utcoffset() is None for value in times) or times[0] > times[1]:
            raise ValueError("receipt time interval")
        return receipt
    except (ValueError, KeyError, TypeError, OverflowError) as error:
        raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED") from error


def _publish(cache: _Cache, stage: str, digest: str, started_at: str) -> dict[str, Any]:
    # Validate both the current operation clock and any reused receipt before
    # changing the admitted pointer. UTC rollback cannot invalidate a prior
    # working installation merely because the new geometry bytes are sound.
    receipt = _validate_receipt({"receipt_id": uuid.uuid4().hex, "source_id": SOURCE_ID, "manifest_sha256": digest,
                                "started_at": started_at, "completed_at": datetime.now(timezone.utc).isoformat()}, digest)
    existing_receipt = False
    try:
        receipt = _validate_receipt(parse_json_object(cache.read(f"receipts/{digest}.json", 4096)), digest)
        existing_receipt = True
    except FileNotFoundError:
        pass
    with cache.directory(stage) as staged:
        os.fsync(staged)
    with cache.directory("artifacts", create=True) as artifacts, cache.directory() as root:
        try:
            os.stat(digest, dir_fd=artifacts, follow_symlinks=False)
        except FileNotFoundError:
            os.rename(stage, digest, src_dir_fd=root, dst_dir_fd=artifacts)
            os.fsync(artifacts)
            os.fsync(root)
        else:
            # Never overwrite an immutable digest directory, even if corrupt.
            with cache.directory("artifacts/" + digest):
                pass
            prior = cache.read(f"artifacts/{digest}/manifest.json", MAX_MANIFEST_BYTES)
            staged_manifest = cache.read(stage + "/manifest.json", MAX_MANIFEST_BYTES)
            if _digest(prior) != digest or prior != staged_manifest:
                raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED")
            # A matching manifest alone cannot rehabilitate altered GLB bytes.
            # Compare every immutable artifact against the independently verified
            # new staging bundle before writing any admission receipt/pointer.
            for key in ASSET_KEYS:
                if cache.read(f"artifacts/{digest}/{key}.glb", MAX_GLB_BYTES) != cache.read(f"{stage}/{key}.glb", MAX_GLB_BYTES):
                    raise AtlasReferenceError("ATLAS_INTEGRITY_FAILED")
    if not existing_receipt:
        cache.write(f"receipts/{digest}.json", _canonical(receipt))
    cache.write("active.json", _canonical({"source_id": SOURCE_ID, "manifest_sha256": digest, "receipt_id": receipt["receipt_id"]}))
    return receipt


def _discard_stage(cache: _Cache, stage: str) -> None:
    if not re.fullmatch(r"\.staging-[0-9a-f]{32}", stage, re.ASCII):
        raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")
    try:
        with cache.directory(stage) as directory:
            for name in os.listdir(directory):
                if name not in {*(key + ".glb" for key in ASSET_KEYS), "manifest.json"} and not re.fullmatch(r"\.temporary-[0-9a-f]{32}", name):
                    raise AtlasReferenceError("ATLAS_UNSAFE_CACHE")
                _safe_file(os.stat(name, dir_fd=directory, follow_symlinks=False))
                os.unlink(name, dir_fd=directory)
        with cache.directory() as root:
            os.rmdir(stage, dir_fd=root)
            os.fsync(root)
    except FileNotFoundError:
        pass


def install(source_id: str) -> dict[str, Any]:
    _source_id(source_id)
    declaration = catalog()
    _converter_identity()
    stage = ".staging-" + uuid.uuid4().hex
    started_at = datetime.now(timezone.utc).isoformat()
    with _Cache(create=True) as cache, cache.lock() as lock_fd:
        try:
            manifest, digest = _read_manifest(cache)
            _verify_assets(cache, manifest, digest)
            receipt = parse_json_object(cache.read(f"receipts/{digest}.json", 4096))
            # An explicit retry can finish a previous unconfirmed directory
            # commit; a read-only status cannot make this durability promise.
            try:
                for relative in (f"artifacts/{digest}", "artifacts", "receipts", None):
                    with cache.directory(relative) as descriptor:
                        os.fsync(descriptor)
            except OSError as error:
                raise AtlasReferenceError("ATLAS_PUBLICATION_UNCONFIRMED") from error
            return {**_status_value("available", "The exact reference installation was reused.", manifest, digest),
                    "receipt": receipt, "reused": True}
        except FileNotFoundError:
            pass
        except AtlasReferenceError as error:
            if error.code not in {"ATLAS_NOT_INSTALLED", "ATLAS_UNSUPPORTED_CONVERTER"}:
                raise
        free = os.fstatvfs(cache.fd)
        if free.f_bavail * free.f_frsize < 512 * 1024 * 1024:
            raise AtlasReferenceError("ATLAS_PUBLICATION_UNCONFIRMED")
        try:
            _launch_acquisition(cache, lock_fd)
            # Child success is not source admission: reread full pinned archive
            # and maps in the parent before the distinct conversion phase.
            with _archive(cache, declaration):
                pass
            with cache.directory(stage, create=True):
                pass
            _launch_conversion(cache, lock_fd, stage)
            manifest, digest = _validated_stage(cache, stage)
            receipt = _publish(cache, stage, digest, started_at)
            # A second independent read verifies publication, not a child claim.
            verified, _ = _read_manifest(cache, digest)
            _verify_assets(cache, verified, digest)
            return {**_status_value("available", "Reference-only geometry was admitted; rendering and physiology require separate checks.", manifest, digest),
                    "receipt": receipt, "reused": False}
        except AtlasReferenceError:
            raise
        except (OSError, ValueError, KeyError, TypeError, OverflowError) as error:
            raise AtlasReferenceError("ATLAS_PUBLICATION_UNCONFIRMED") from error
        finally:
            _discard_stage(cache, stage)


def main() -> int:
    parser = argparse.ArgumentParser(description="Fixed-source anatomical reference assets; no physiological execution")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("status")
    installer = subparsers.add_parser("install")
    installer.add_argument("source_id", choices=[SOURCE_ID])
    args = parser.parse_args()
    try:
        result = status() if args.command == "status" else install(args.source_id)
    except AtlasReferenceError as error:
        print(json.dumps({"code": error.code, "error": str(error)}))
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
