"""
livemorebio.anatomy.meshes — real-anatomy mesh acquisition and provenance.

Every mesh the platform renders is REAL anatomy from an authoritative source:

  * HuBMAP Human Reference Atlas (HRA) reference organs — CC-BY-4.0 GLBs,
    per-structure named scene-graph nodes, served from cdn.humanatlas.io.
  * BodyParts3D / The Database Center for Life Science — CC-BY-SA-2.1-JP
    per-structure FMA-mapped OBJ meshes (segmented from the TARO/HANAKO
    human MRI models), converted losslessly to GLB on acquisition.

No generated, approximated, or artist-invented geometry is ever admitted.
Each cached asset carries a provenance sidecar (source URL, license,
retrieval timestamp, SHA-256) so a rendered organ can prove where its
anatomy came from — the same discipline the evidence packages apply to
numbers, applied to geometry.

Assets cache under ``~/.livemore/anatomy`` (override: LIVEMORE_ANATOMY_DIR)
and are served same-origin by the Aegle service at /assets/anatomy/{key}.glb,
so consoles keep working offline once the cache is warm.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import stat
import struct
import tempfile
from contextlib import contextmanager
import time
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, BinaryIO, Iterator, Optional

HRA = "https://cdn.humanatlas.io/digital-objects/ref-organ"
BP3D_ARCHIVE = "https://dbarchive.biosciencedbc.jp/data/bodyparts3d/LATEST/isa_BP3D_4.0_obj_99.zip"
BP3D_ELEMENT_MAP = "https://dbarchive.biosciencedbc.jp/data/bodyparts3d/LATEST/isa_element_parts.txt"
MAX_GLB_BYTES = 256 * 1024 * 1024
MAX_GLB_JSON_BYTES = 8 * 1024 * 1024

HRA_LICENSE = {
    "source": "HuBMAP Human Reference Atlas (HRA) 3D reference organs",
    "license": "CC-BY-4.0",
    "attribution": "Human Reference Atlas, https://humanatlas.io — Börner et al.",
}
BP3D_LICENSE = {
    "source": "BodyParts3D, The Database Center for Life Science (DBCLS)",
    "license": "CC-BY-SA-2.1-JP",
    "attribution": "BodyParts3D, (c) The Database Center for Life Science "
                   "licensed under CC Attribution-Share Alike 2.1 Japan",
}

# ---------------------------------------------------------------------------
# The real-mesh catalog. Keys are the platform's organ ids (ORGAN_ATLAS ids).
# kind "hra-glb": direct GLB download. kind "bp3d-obj": FMA-identified OBJ
# structures extracted from the BodyParts3D archive and converted to one GLB.
# ---------------------------------------------------------------------------
CATALOG: dict[str, dict[str, Any]] = {
    "liver": {
        "kind": "hra-glb",
        "url": f"{HRA}/liver-female/v1.2/assets/3d-vh-f-liver.glb",
        "structure": "liver", "uberon": "UBERON:0002107", "fma": "FMA:7197",
        **HRA_LICENSE,
    },
    "pancreas": {
        "kind": "hra-glb",
        "url": f"{HRA}/pancreas-female/v1.3/assets/3d-vh-f-pancreas.glb",
        "structure": "pancreas", "uberon": "UBERON:0001264", "fma": "FMA:7198",
        **HRA_LICENSE,
    },
    "adipose": {
        "kind": "hra-glb",
        "url": f"{HRA}/adipose-female/v1.0/assets/3d-vh-f-adipose.glb",
        "structure": "adipose tissue", "uberon": "UBERON:0001013", "fma": "FMA:20110",
        **HRA_LICENSE,
    },
    "kidney": {
        "kind": "hra-glb",
        "url": f"{HRA}/kidney-female-left/v1.3/assets/3d-vh-f-kidney-l.glb",
        "structure": "kidney (left)", "uberon": "UBERON:0004538", "fma": "FMA:7203",
        **HRA_LICENSE,
    },
    "heart": {
        "kind": "hra-glb",
        "url": f"{HRA}/heart-female/v1.3/assets/3d-vh-f-heart.glb",
        "structure": "heart", "uberon": "UBERON:0000948", "fma": "FMA:7088",
        **HRA_LICENSE,
    },
    "brain": {
        "kind": "hra-glb",
        "url": f"{HRA}/brain-female/v1.4/assets/3d-allen-f-brain.glb",
        "structure": "brain (Allen reference)", "uberon": "UBERON:0000955", "fma": "FMA:50801",
        **HRA_LICENSE,
    },
    "muscle": {
        "kind": "bp3d-obj",
        # Real segmented skeletal muscle: the quadriceps components — the body's
        # largest insulin-stimulated glucose sink, which is exactly the biology
        # this organ node carries in the twin (driver: Si).
        "fma_parts": ["FMA22430", "FMA22431"],   # rectus femoris, vastus lateralis
        "part_names": ["rectus femoris", "vastus lateralis"],
        "structure": "skeletal muscle (quadriceps components)",
        "uberon": "UBERON:0001134", "fma": "FMA:9626",
        "archive": BP3D_ARCHIVE,
        **BP3D_LICENSE,
    },
}


def anatomy_dir() -> Path:
    d = Path(os.environ.get("LIVEMORE_ANATOMY_DIR",
                            os.path.expanduser("~/.livemore/anatomy")))
    d.mkdir(parents=True, exist_ok=True)
    info = d.lstat()
    if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid()
            or stat.S_IMODE(info.st_mode) & 0o022):
        raise ValueError("anatomy cache directory is not owner-controlled")
    return d


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with _read_cache_file(path) as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_provenance(key: str, glb: Path, entry: dict[str, Any],
                      extra: Optional[dict[str, Any]] = None) -> None:
    prov = {
        "key": key,
        "structure": entry["structure"],
        "uberon": entry["uberon"],
        "fma": entry["fma"],
        "source": entry["source"],
        "license": entry["license"],
        "attribution": entry["attribution"],
        "source_url": entry.get("url") or entry.get("archive"),
        "retrieved_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "sha256": _sha256(glb),
        "bytes": glb.stat().st_size,
    }
    if extra:
        prov.update(extra)
    sidecar = glb.with_suffix(".provenance.json")
    with _atomic_cache_output(sidecar) as output:
        output.write(json.dumps(prov, indent=2).encode("utf-8"))


def _download(url: str, dest: Path, timeout: int = 120) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": "livemorebio-anatomy/1.0"})
    with _atomic_cache_output(dest) as f:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            while chunk := r.read(1 << 20):
                f.write(chunk)
                if dest.suffix == ".glb" and f.tell() > MAX_GLB_BYTES:
                    raise ValueError("GLB exceeds anatomy admission size")


@contextmanager
def _atomic_cache_output(dest: Path) -> Iterator[BinaryIO]:
    """Publish only complete bytes; never reuse or follow a fixed temporary name."""
    _safe_cache_file(dest)
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(dir=dest.parent, prefix=f".{dest.name}.", suffix=".part", delete=False) as f:
            tmp = Path(f.name)
            yield f
            f.flush()
            os.fsync(f.fileno())
        if dest.suffix == ".glb":
            _validate_glb_file(tmp)
        _safe_cache_file(dest)
        os.replace(tmp, dest)
    finally:
        if tmp is not None:
            tmp.unlink(missing_ok=True)


def _safe_cache_file(path: Path) -> None:
    try:
        info = path.lstat()
    except FileNotFoundError:
        return
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.getuid():
        raise ValueError("anatomy cache entry is not a safe owner-controlled file")


@contextmanager
def _read_cache_file(path: Path) -> Iterator[BinaryIO]:
    _safe_cache_file(path)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.getuid():
            raise ValueError("anatomy cache entry is not a safe owner-controlled file")
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            yield stream
    finally:
        os.close(descriptor)


def _validate_glb_file(path: Path) -> None:
    """GLB 2 container admission, not proof of anatomically accurate geometry.

    Format: https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html#glb-file-format-specification
    Keep the binary and JSON lengths bounded before a browser receives them.
    """
    with _read_cache_file(path) as stream:
        size = os.fstat(stream.fileno()).st_size
        if not 20 <= size <= MAX_GLB_BYTES:
            raise ValueError("GLB length is invalid")
        magic, version, declared = struct.unpack("<4sII", stream.read(12))
        if magic != b"glTF" or version != 2 or declared != size:
            raise ValueError("GLB header is invalid")
        index, binary_seen = 0, False
        while stream.tell() < size:
            header = stream.read(8)
            if len(header) != 8:
                raise ValueError("GLB chunk header is incomplete")
            length, kind = struct.unpack("<I4s", header)
            if length % 4 or stream.tell() + length > size:
                raise ValueError("GLB chunk length is invalid")
            if index == 0:
                if kind != b"JSON" or not 1 <= length <= MAX_GLB_JSON_BYTES:
                    raise ValueError("GLB first chunk must be bounded JSON")
                try:
                    content = json.loads(stream.read(length))
                except (ValueError, UnicodeError, RecursionError) as error:
                    raise ValueError("GLB JSON is invalid") from error
                if not isinstance(content, dict) or not isinstance(content.get("asset"), dict) or content["asset"].get("version") != "2.0":
                    raise ValueError("GLB asset version is unsupported")
            else:
                if kind == b"JSON" or (kind == b"BIN\0" and (index != 1 or binary_seen)):
                    raise ValueError("GLB chunk order is invalid")
                binary_seen = binary_seen or kind == b"BIN\0"
                stream.seek(length, 1)
            index += 1


@contextmanager
def _asset_lock(key: str, *, timeout: float = 2.0) -> Iterator[None]:
    """Cross-process single acquisition with bounded waiting, inside the cache."""
    import fcntl

    if not isinstance(key, str) or re.fullmatch(r"[a-z][a-z0-9-]{0,63}", key) is None:
        raise ValueError("invalid anatomy cache key")
    path = anatomy_dir() / f".{key}.acquisition.lock"
    _safe_cache_file(path)
    descriptor = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.getuid():
            raise ValueError("anatomy acquisition lock is unsafe")
        end = time.monotonic() + timeout
        while True:
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= end:
                    raise TimeoutError("anatomy acquisition is already in progress") from None
                time.sleep(0.025)
        yield
    finally:
        os.close(descriptor)


def _verified_provenance(key: str, glb: Path, entry: dict[str, Any]) -> Optional[dict[str, Any]]:
    """Caller holds the acquisition lock while checking source and bytes together."""
    sidecar = glb.with_suffix(".provenance.json")
    for path in (glb, sidecar):
        _safe_cache_file(path)
    if not glb.exists() or not sidecar.exists():
        return None
    try:
        with _read_cache_file(sidecar) as stream:
            raw = stream.read(65537)
        if len(raw) > 65536:
            return None
        metadata = json.loads(raw)
        if not isinstance(metadata, dict):
            return None
        expected = {"key": key, "source": entry["source"], "license": entry["license"],
                    "source_url": entry.get("url") or entry.get("archive"),
                    "uberon": entry["uberon"], "fma": entry["fma"],
                    "structure": entry["structure"], "attribution": entry["attribution"]}
        if entry["kind"] == "bp3d-obj":
            expected.update(fma_parts=entry["fma_parts"], part_names=entry["part_names"],
                            conversion="OBJ->GLB via trimesh, geometry unmodified")
        _validate_glb_file(glb)
        valid = (all(metadata.get(field) == value for field, value in expected.items())
                and metadata.get("bytes") == glb.stat().st_size
                and metadata.get("sha256") == _sha256(glb))
        return metadata if valid else None
    except (OSError, ValueError, UnicodeError, RecursionError):
        return None  # Malformed or unreadable metadata is not provenance.


def _verified_cache(key: str, glb: Path, entry: dict[str, Any]) -> bool:
    return _verified_provenance(key, glb, entry) is not None


def _fetch_hra(key: str, entry: dict[str, Any], glb: Path) -> Path:
    _download(entry["url"], glb)
    _write_provenance(key, glb, entry)
    return glb


def _bp3d_zip_path() -> Path:
    return anatomy_dir() / "bp3d_isa_obj_99.zip"


def _ensure_bp3d_archive() -> Path:
    z = _bp3d_zip_path()
    with _asset_lock("bp3d-archive"):
        _safe_cache_file(z)
        if not z.exists():
            _download(BP3D_ARCHIVE, z, timeout=1800)
    return z


def _bp3d_elements_for(fma_ids: list[str]) -> dict[str, list[str]]:
    """FMA concept -> element-file ids (FJ####), from BP3D's published mapping.

    The mapping file is cached beside the archive; both sides of a mirrored
    structure (e.g. FJ1433 and FJ1433M) are real segmented geometry.
    """
    cache = anatomy_dir() / "bp3d_isa_element_parts.txt"
    with _asset_lock("bp3d-map"):
        _safe_cache_file(cache)
        if not cache.exists():
            _download(BP3D_ELEMENT_MAP, cache, timeout=120)
        with _read_cache_file(cache) as stream:
            raw = stream.read(8 * 1024 * 1024 + 1)
        if len(raw) > 8 * 1024 * 1024:
            raise ValueError("anatomy element map exceeds admission size")
    mapping: dict[str, list[str]] = {}
    for line in raw.decode("utf-8").splitlines()[1:]:
        cols = line.split("\t")
        if len(cols) >= 3 and cols[0] in fma_ids:
            mapping.setdefault(cols[0], []).append(cols[2].strip())
    return mapping


def _fetch_bp3d(key: str, entry: dict[str, Any], glb: Path) -> Path:
    """Extract the real FMA-identified OBJ structures and convert to one GLB.

    Geometry passes through unmodified (same vertices/faces); only the
    container format changes. trimesh is imported lazily so the platform
    has no hard dependency unless a BP3D asset is actually materialised.
    """
    import trimesh

    archive = _ensure_bp3d_archive()
    elements = _bp3d_elements_for(entry["fma_parts"])
    scene = trimesh.Scene()
    used: list[str] = []
    with zipfile.ZipFile(archive) as zf:
        names = {Path(n).stem: n for n in zf.namelist() if n.lower().endswith(".obj")}
        for fma in entry["fma_parts"]:
            fj_ids = elements.get(fma, [])
            members = [names[fj] for fj in fj_ids if fj in names]
            if not members:
                raise FileNotFoundError(
                    f"BodyParts3D archive has no OBJ for {fma} (organ {key!r}); "
                    "refusing to substitute geometry")
            for member in members:
                mesh = trimesh.load(io.BytesIO(zf.read(member)), file_type="obj")
                node = f"{fma}:{Path(member).stem}"
                scene.add_geometry(mesh, node_name=node, geom_name=node)
                used.append(member)
    with _atomic_cache_output(glb) as output:
        output.write(scene.export(file_type="glb"))
    _write_provenance(key, glb, entry, extra={
        "archive_members": used,
        "fma_parts": entry["fma_parts"],
        "part_names": entry["part_names"],
        "conversion": "OBJ->GLB via trimesh, geometry unmodified",
    })
    return glb


def mesh_path(key: str) -> Path:
    if key not in CATALOG:
        raise KeyError(key)
    return anatomy_dir() / f"{key}.glb"


def ensure_mesh(key: str) -> Path:
    """Return the cached real-anatomy GLB for *key*, acquiring it if absent.

    Raises KeyError for unknown keys and propagates acquisition errors —
    there is deliberately no fallback geometry.
    """
    entry = CATALOG[key]
    glb = mesh_path(key)
    with _asset_lock(key):
        return _ensure_mesh_locked(key, glb, entry)[0]


def _ensure_mesh_locked(key: str, glb: Path, entry: dict[str, Any]) -> tuple[Path, dict[str, Any]]:
    metadata = _verified_provenance(key, glb, entry)
    if metadata is None:
        if entry["kind"] == "hra-glb":
            _fetch_hra(key, entry, glb)
        elif entry["kind"] == "bp3d-obj":
            _fetch_bp3d(key, entry, glb)
        else:
            raise ValueError("unknown anatomy catalog kind")
        metadata = _verified_provenance(key, glb, entry)
    if metadata is None:
        raise ValueError("anatomy bytes and source metadata could not be verified")
    return glb, metadata


def read_asset(key: str) -> tuple[bytes, dict[str, Any]]:
    """Return exactly the bytes checked against this provenance in one transaction."""
    entry = CATALOG[key]
    glb = mesh_path(key)
    with _asset_lock(key):
        path, metadata = _ensure_mesh_locked(key, glb, entry)
        with _read_cache_file(path) as stream:
            content = stream.read(MAX_GLB_BYTES + 1)
        if (len(content) > MAX_GLB_BYTES or len(content) != metadata["bytes"]
                or hashlib.sha256(content).hexdigest() != metadata["sha256"]):
            raise ValueError("anatomy changed during verified read")
        return content, metadata


def provenance(key: str) -> Optional[dict[str, Any]]:
    glb = mesh_path(key)
    with _asset_lock(key):
        return _verified_provenance(key, glb, CATALOG[key])


def manifest() -> list[dict[str, Any]]:
    """Catalog + cache status + provenance for every real-anatomy asset."""
    out = []
    for key, entry in CATALOG.items():
        glb = mesh_path(key)
        cached, cached_provenance = False, None
        acquisition_state = "missing"
        try:
            with _asset_lock(key, timeout=0):
                cached_provenance = _verified_provenance(key, glb, entry)
                cached = cached_provenance is not None
                acquisition_state = "ready" if cached else "invalid" if glb.exists() else "missing"
        except TimeoutError:
            acquisition_state = "acquiring"
        except (OSError, ValueError):
            acquisition_state = "unavailable"
        row = {
            "key": key,
            "structure": entry["structure"],
            "uberon": entry["uberon"],
            "fma": entry["fma"],
            "source": entry["source"],
            "license": entry["license"],
            "kind": entry["kind"],
            "cached": cached,
            "acquisition_state": acquisition_state,
            "path": f"/assets/anatomy/{key}.glb",
        }
        if cached:
            row["provenance"] = cached_provenance
        out.append(row)
    return out


def prefetch(verbose: bool = True) -> list[Path]:
    """Warm the whole cache (used by ops / install; consoles fetch lazily)."""
    paths = []
    for key in CATALOG:
        if verbose:
            print(f"[anatomy] ensuring {key} …", flush=True)
        p = ensure_mesh(key)
        if verbose:
            print(f"[anatomy]   {p.name}: {p.stat().st_size:,} bytes", flush=True)
        paths.append(p)
    return paths


if __name__ == "__main__":  # python -m livemorebio.anatomy.meshes
    prefetch()
