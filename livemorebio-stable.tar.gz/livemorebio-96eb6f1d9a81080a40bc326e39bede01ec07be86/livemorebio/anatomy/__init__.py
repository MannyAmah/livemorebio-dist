"""Canonical human-body structure contract for LivemoreBio.

Merged from the Human-body-map package (audit §5, component 3). The
ontology in ``ontology/human-body-core.json`` is the single source of
truth for body structure across the platform: 11 physical scales
(subatomic → environment/population), 15 organ systems with structures,
processes and state variables, whole-body processes, cross-system
couplings, and the biological trait model. UBERON/FMA hints in the
structures bind this contract to real anatomical reference atlases and
to the anatomy explorer meshes.

Nothing in this module invents biology: it loads, indexes, and validates
the referenced ontology. Organ engines and the body view consume it as a
structure contract; live state always comes from the mechanistic engines.
"""

from .ontology import (
    BodyOntology,
    load_ontology,
    validate_ontology,
)

__all__ = ["BodyOntology", "load_ontology", "validate_ontology"]
