"""Restricted source-preserving reference geometry, never physiological motion.

Only the reviewed triangle OBJ grammar is supported. Export uses trimesh;
verification decodes GLB accessors independently and compares source arrays.
"""
from __future__ import annotations

import hashlib
import re
import struct
from typing import Any

import numpy as np

from ..strict_json import parse_json_object

MAX_OBJ_BYTES = 16 * 1024 * 1024
MAX_GLB_BYTES = 16 * 1024 * 1024
MAX_JSON_BYTES = 2 * 1024 * 1024
ROOT_MATRIX = np.array([[0.001, 0, 0, 0], [0, 0, 0.001, 0],
                        [0, -0.001, 0, 0], [0, 0, 0, 1]], dtype=np.float64)
CONVERSION_VERSION = "bp3d-preserve-arrays-v1"
_HEADERS = {"Compatibility version": "compatibility_version", "File ID": "element_id",
            "Representation ID": "representation_id", "Concept ID": "concept_id", "English name": "name"}
_ID = re.compile(r"FJ[0-9]+M?\Z", re.ASCII)


def _integer(value: Any, minimum: int = 0, maximum: int = 4_000_000) -> int:
    if type(value) is not int or not minimum <= value <= maximum:
        raise ValueError("invalid geometry integer")
    return value


def parse_obj(raw: bytes, member: dict[str, Any]) -> dict[str, Any]:
    """Keep original ordered positions, normals and triangles; never repair."""
    if (not isinstance(raw, bytes) or not 0 < len(raw) <= MAX_OBJ_BYTES
            or len(raw) != member.get("source_bytes")
            or hashlib.sha256(raw).hexdigest() != member.get("source_sha256")):
        raise ValueError("source bytes do not match declaration")
    if not isinstance(member.get("element_id"), str) or not _ID.fullmatch(member["element_id"]):
        raise ValueError("source identity is invalid")
    vertex_count = _integer(member.get("vertices"), 1, 200_000)
    face_count = _integer(member.get("triangles"), 1, 400_000)
    vertices = np.empty((vertex_count, 3), dtype=np.float64)
    normals = np.empty((vertex_count, 3), dtype=np.float64)
    faces = np.empty((face_count, 3), dtype=np.int64)
    counts = {"v": 0, "vn": 0, "f": 0, "g": 0, "usemtl": 0}
    headers: dict[str, str] = {}
    for line in raw.decode("ascii").splitlines():
        if len(line) > 1024:
            raise ValueError("source line exceeds bound")
        line = line.strip()
        if not line:
            continue
        if line.startswith("#"):
            text = line[1:].strip()
            key, separator, value = text.partition(":")
            key = key.strip()
            if separator and key in _HEADERS:
                if key in headers:
                    raise ValueError("duplicate source header")
                headers[key] = value.strip()
            continue
        tokens = line.split()
        kind = tokens[0]
        if kind not in counts:
            raise ValueError("unsupported source geometry directive")
        if kind in ("v", "vn"):
            if len(tokens) != 4 or counts[kind] >= vertex_count:
                raise ValueError("source vector count or shape is invalid")
            vector = [float(v) for v in tokens[1:]]
            if not all(np.isfinite(v) for v in vector):
                raise ValueError("source vector is nonfinite")
            (vertices if kind == "v" else normals)[counts[kind]] = vector
        elif kind == "f":
            if len(tokens) != 4 or counts[kind] >= face_count:
                raise ValueError("source face count or shape is invalid")
            indices = []
            for token in tokens[1:]:
                match = re.fullmatch(r"([1-9][0-9]*)//([1-9][0-9]*)", token, re.ASCII)
                if not match or match[1] != match[2] or not 1 <= int(match[1]) <= vertex_count:
                    raise ValueError("source face/normal index is invalid")
                indices.append(int(match[1]) - 1)
            faces[counts[kind]] = indices
        elif len(tokens) != 2 or counts[kind] != 0:
            raise ValueError("source group or material directive is invalid")
        counts[kind] += 1
    if counts != {"v": vertex_count, "vn": vertex_count, "f": face_count, "g": 1, "usemtl": 1}:
        raise ValueError("source geometry counts differ")
    for key, field in _HEADERS.items():
        if headers.get(key) != member.get(field):
            raise ValueError("source header differs from declaration")
    bounds = np.asarray(member.get("bounds_mm"), dtype=np.float64)
    if (bounds.shape != (2, 3) or not np.isfinite(bounds).all()
            or not np.array_equal(bounds, np.array([vertices.min(axis=0), vertices.max(axis=0)]))):
        raise ValueError("source bounds differ from declaration")
    lengths = np.linalg.norm(normals, axis=1)
    if not ((lengths > 0.99999) & (lengths < 1.00001)).all():
        raise ValueError("source normals are outside reviewed numerical domain")
    return {"element_id": member["element_id"], "member": dict(member),
            "vertices": vertices, "normals": normals, "faces": faces}


def convert_partition(asset_key: str, parts: list[dict[str, Any]]) -> bytes:
    """Use a standard exporter without its default geometry processing."""
    import trimesh
    from trimesh.exchange.gltf import export_glb

    scene = trimesh.Scene(base_frame="atlas-world")
    scene.graph.update(frame_to="bp3d-native", frame_from="atlas-world", matrix=ROOT_MATRIX.copy())
    for part in sorted(parts, key=lambda p: p["element_id"]):
        element_id = part["element_id"]
        mesh = trimesh.Trimesh(vertices=part["vertices"].copy(), faces=part["faces"].copy(),
                               vertex_normals=part["normals"].copy(), process=False, validate=False)
        mesh.metadata = {"element_id": element_id, "source_sha256": part["member"]["source_sha256"]}
        scene.add_geometry(mesh, node_name=f"bp3d:{element_id}", geom_name=f"bp3d-mesh:{element_id}",
                           parent_node_name="bp3d-native", transform=np.eye(4))
    data = export_glb(scene, include_normals=True, unitize_normals=False,
                      extension_draco=False, extension_webp=False)
    verify_partition(data, asset_key, parts)
    return data


def _strict_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate GLB JSON key")
        result[key] = value
    return result


def _decode(raw: bytes) -> tuple[dict[str, Any], bytes]:
    if not isinstance(raw, bytes) or not 28 <= len(raw) <= MAX_GLB_BYTES:
        raise ValueError("GLB length is invalid")
    magic, version, declared = struct.unpack_from("<4sII", raw)
    if (magic, version, declared) != (b"glTF", 2, len(raw)):
        raise ValueError("GLB header is invalid")
    size, kind = struct.unpack_from("<I4s", raw, 12)
    if kind != b"JSON" or size % 4 or not 1 <= size <= MAX_JSON_BYTES or 20 + size + 8 > len(raw):
        raise ValueError("GLB JSON bound is invalid")
    try:
        tree = parse_json_object(raw[20:20 + size], max_bytes=MAX_JSON_BYTES)
    except (UnicodeError, RecursionError) as error:
        raise ValueError("GLB JSON is invalid") from error
    bin_size, bin_kind = struct.unpack_from("<I4s", raw, 20 + size)
    if bin_kind != b"BIN\0" or bin_size % 4 or 28 + size + bin_size != len(raw):
        raise ValueError("GLB binary chunk is invalid")
    if not isinstance(tree, dict):
        raise ValueError("GLB tree is invalid")
    return tree, raw[28 + size:]


def _fields(obj: Any, allowed: set[str], required: set[str] = frozenset()) -> dict[str, Any]:
    if not isinstance(obj, dict) or not required <= obj.keys() or not obj.keys() <= allowed:
        raise ValueError("unsupported GLB fields")
    return obj


def _node_matrix(node: dict[str, Any]) -> np.ndarray:
    value = node.get("matrix", np.eye(4).flatten(order="F").tolist())
    if not isinstance(value, list) or len(value) != 16 or any(type(x) not in (int, float) for x in value):
        raise ValueError("invalid node matrix")
    matrix = np.asarray(value, dtype=np.float64).reshape((4, 4), order="F")
    if not np.isfinite(matrix).all():
        raise ValueError("nonfinite node matrix")
    return matrix


def _array(tree: dict[str, Any], binary: bytes, index: int, count: int,
           component_type: int, kind: str) -> np.ndarray:
    index = _integer(index, 0, len(tree["accessors"]) - 1)
    accessor = _fields(tree["accessors"][index],
                       {"bufferView", "byteOffset", "componentType", "count", "type", "min", "max"},
                       {"bufferView", "componentType", "count", "type"})
    if (type(accessor["count"]) is not int or accessor["count"] != count
            or type(accessor["componentType"]) is not int or accessor["componentType"] != component_type
            or accessor["type"] != kind):
        raise ValueError("accessor does not match source shape")
    view_index = _integer(accessor["bufferView"], 0, len(tree["bufferViews"]) - 1)
    view = _fields(tree["bufferViews"][view_index], {"buffer", "byteOffset", "byteLength", "target"}, {"buffer", "byteLength"})
    if type(view["buffer"]) is not int or view["buffer"] != 0:
        raise ValueError("invalid buffer authority")
    if "target" in view and (type(view["target"]) is not int or view["target"] != (34963 if kind == "SCALAR" else 34962)):
        raise ValueError("unsupported buffer target")
    offset = _integer(view.get("byteOffset", 0), 0, len(binary))
    size = _integer(view["byteLength"], 1, len(binary))
    accessor_offset = _integer(accessor.get("byteOffset", 0), 0, size)
    width = 3 if kind == "VEC3" else 1
    expected_size = count * width * 4
    if offset % 4 or accessor_offset % 4 or offset + size > len(binary) or accessor_offset + expected_size > size:
        raise ValueError("accessor range outside binary")
    dtype = "<f4" if component_type == 5126 else "<u4"
    values = np.frombuffer(binary, dtype=dtype, count=count * width, offset=offset + accessor_offset).reshape((count, width))
    if not np.isfinite(values).all():
        raise ValueError("nonfinite accessor")
    for field, actual in (("min", values.min(axis=0)), ("max", values.max(axis=0))):
        if field in accessor:
            if (not isinstance(accessor[field], list) or len(accessor[field]) != width
                    or any(type(value) not in (int, float) for value in accessor[field])):
                raise ValueError("accessor bounds require numeric components")
            declared = np.asarray(accessor[field], dtype=np.float64)
            if declared.shape != (width,) or not np.array_equal(declared, actual):
                raise ValueError("accessor bounds differ from bytes")
    return values


def _zero_faces(vertices: np.ndarray, faces: np.ndarray) -> np.ndarray:
    return np.all(np.cross(vertices[faces[:, 1]] - vertices[faces[:, 0]],
                           vertices[faces[:, 2]] - vertices[faces[:, 0]]) == 0, axis=1)


def verify_partition(raw: bytes, asset_key: str, parts: list[dict[str, Any]]) -> dict[str, Any]:
    """Verify the decoded graph and every source array independently of trimesh."""
    tree, binary = _decode(raw)
    _fields(tree, {"asset", "scene", "scenes", "nodes", "meshes", "accessors", "bufferViews", "buffers"},
            {"asset", "scene", "scenes", "nodes", "meshes", "accessors", "bufferViews", "buffers"})
    _fields(tree["asset"], {"version", "generator"}, {"version"})
    if tree["asset"]["version"] != "2.0" or type(tree["scene"]) is not int or tree["scene"] != 0:
        raise ValueError("unsupported GLB scene")
    if not all(isinstance(tree[x], list) for x in ("scenes", "nodes", "meshes", "accessors", "bufferViews", "buffers")):
        raise ValueError("invalid GLB collection")
    if tree["buffers"] != [{"byteLength": len(binary)}] or len(tree["scenes"]) != 1:
        raise ValueError("external or invalid GLB buffer")
    parts = sorted(parts, key=lambda p: p["element_id"])
    if (not parts or len(parts) > 489 or len({p["element_id"] for p in parts}) != len(parts)
            or len(tree["nodes"]) != len(parts) + 1 or len(tree["meshes"]) != len(parts)
            or not 1 <= len(tree["accessors"]) <= len(parts) * 3
            or not 1 <= len(tree["bufferViews"]) <= len(parts) * 3):
        raise ValueError("GLB geometry count differs from source")
    names: dict[str, tuple[int, dict[str, Any]]] = {}
    for index, node in enumerate(tree["nodes"]):
        _fields(node, {"name", "children", "matrix", "mesh"}, {"name"})
        if not isinstance(node["name"], str) or node["name"] in names:
            raise ValueError("invalid or duplicate GLB node")
        names[node["name"]] = (index, node)
    if set(names) != {"bp3d-native", *(f"bp3d:{p['element_id']}" for p in parts)}:
        raise ValueError("source node identity mismatch")
    native_index, native = names["bp3d-native"]
    scene = _fields(tree["scenes"][0], {"nodes"}, {"nodes"})
    if (not isinstance(scene["nodes"], list) or any(type(index) is not int for index in scene["nodes"])
            or not isinstance(native.get("children"), list) or any(type(index) is not int for index in native["children"])):
        raise ValueError("scene references require integer indices")
    if (tree["scenes"] != [{"nodes": [native_index]}]
            or not np.array_equal(_node_matrix(native), ROOT_MATRIX) or "mesh" in native):
        raise ValueError("GLB common coordinate conversion differs")
    expected_children = [names[f"bp3d:{p['element_id']}"][0] for p in parts]
    if native.get("children") != expected_children:
        raise ValueError("source element order or hierarchy differs")
    result: dict[str, Any] = {"asset_key": asset_key, "element_ids": [], "nodes": [], "vertices": 0, "triangles": 0,
                              "maximum_position_error_mm": 0., "maximum_world_error_m": 0., "maximum_normal_error": 0.,
                              "source_zero_area_triangles": 0, "introduced_zero_area_triangles": 0}
    used_meshes: set[int] = set()
    used_accessors: set[int] = set()
    native_min, world_min = np.full(3, np.inf), np.full(3, np.inf)
    native_max, world_max = np.full(3, -np.inf), np.full(3, -np.inf)
    for part in parts:
        element_id = part["element_id"]
        node_index, node = names[f"bp3d:{element_id}"]
        if "children" in node or not np.array_equal(_node_matrix(node), np.eye(4)):
            raise ValueError("element is independently transformed")
        mesh_index = _integer(node.get("mesh"), 0, len(tree["meshes"]) - 1)
        if mesh_index in used_meshes:
            raise ValueError("source node was cloned")
        used_meshes.add(mesh_index)
        mesh = _fields(tree["meshes"][mesh_index], {"name", "extras", "primitives"}, {"name", "primitives"})
        if (mesh["name"] != f"bp3d-mesh:{element_id}" or mesh.get("extras") != {
                "element_id": element_id, "source_sha256": part["member"]["source_sha256"]}
                or not isinstance(mesh["primitives"], list) or len(mesh["primitives"]) != 1):
            raise ValueError("source mesh identity differs")
        primitive = _fields(mesh["primitives"][0], {"attributes", "indices", "mode"}, {"attributes", "indices", "mode"})
        attributes = _fields(primitive["attributes"], {"POSITION", "NORMAL"}, {"POSITION", "NORMAL"})
        if type(primitive["mode"]) is not int or primitive["mode"] != 4:
            raise ValueError("unsupported primitive")
        vertices = _array(tree, binary, attributes["POSITION"], len(part["vertices"]), 5126, "VEC3").astype(np.float64)
        normals = _array(tree, binary, attributes["NORMAL"], len(part["normals"]), 5126, "VEC3").astype(np.float64)
        faces = _array(tree, binary, primitive["indices"], part["faces"].size, 5125, "SCALAR").reshape((-1, 3))
        used_accessors.update([attributes["POSITION"], attributes["NORMAL"], primitive["indices"]])
        position_error = float(np.abs(vertices - part["vertices"]).max())
        normal_error = float(np.abs(normals - part["normals"]).max())
        world_error = float(np.abs((vertices - part["vertices"]) @ ROOT_MATRIX[:3, :3].T).max())
        if (position_error > 1e-4 or normal_error > 1e-7 or world_error > 2e-7
                or not np.array_equal(faces, part["faces"])):
            raise ValueError("source geometry roundtrip failed")
        source_zero = _zero_faces(part["vertices"], part["faces"])
        encoded_zero = _zero_faces(vertices, faces)
        introduced = int(np.count_nonzero(encoded_zero & ~source_zero))
        if introduced or not np.array_equal(source_zero, encoded_zero):
            raise ValueError("conversion changed degenerate source triangles")
        result["element_ids"].append(element_id)
        world_vertices = vertices @ ROOT_MATRIX[:3, :3].T
        native_bounds = np.array([vertices.min(axis=0), vertices.max(axis=0)])
        world_bounds = np.array([world_vertices.min(axis=0), world_vertices.max(axis=0)])
        native_min, native_max = np.minimum(native_min, native_bounds[0]), np.maximum(native_max, native_bounds[1])
        world_min, world_max = np.minimum(world_min, world_bounds[0]), np.maximum(world_max, world_bounds[1])
        result["nodes"].append({"element_id": element_id, "node_name": node["name"], "node_index": node_index,
                                "mesh_name": mesh["name"], "mesh_index": mesh_index, "asset_key": asset_key,
                                "memberships": part.get("memberships", []), "native_bounds_mm": native_bounds.tolist(),
                                "world_bounds_m": world_bounds.tolist(),
                                "source_zero_area_triangle_indices": np.flatnonzero(source_zero).tolist()})
        result["vertices"] += len(vertices)
        result["triangles"] += len(faces)
        result["maximum_position_error_mm"] = max(result["maximum_position_error_mm"], position_error)
        result["maximum_normal_error"] = max(result["maximum_normal_error"], normal_error)
        result["maximum_world_error_m"] = max(result["maximum_world_error_m"], world_error)
        result["source_zero_area_triangles"] += int(source_zero.sum())
        result["introduced_zero_area_triangles"] += introduced
    if used_accessors != set(range(len(tree["accessors"]))):
        raise ValueError("unreferenced GLB accessor")
    used_views = {tree["accessors"][a]["bufferView"] for a in used_accessors}
    if used_views != set(range(len(tree["bufferViews"]))):
        raise ValueError("unreferenced GLB buffer view")
    ranges = sorted((view.get("byteOffset", 0), view.get("byteOffset", 0) + view["byteLength"])
                    for view in tree["bufferViews"])
    end = 0
    for start, next_end in ranges:
        if start != end:
            raise ValueError("overlapping or unreferenced GLB binary bytes")
        end = next_end
    if end != len(binary):
        raise ValueError("trailing unreferenced GLB binary bytes")
    result["native_bounds_mm"] = [native_min.tolist(), native_max.tolist()]
    result["world_bounds_m"] = [world_min.tolist(), world_max.tolist()]
    return result
