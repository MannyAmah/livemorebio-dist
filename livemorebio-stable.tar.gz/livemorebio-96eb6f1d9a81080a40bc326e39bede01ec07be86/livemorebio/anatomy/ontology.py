"""Loader/index/validator for the canonical human-body ontology.

The JSON contract lives in ``ontology/human-body-core.json`` (with its
JSON Schema in ``ontology/human-body.schema.json`` and TypeScript types
in ``ontology/human-body.types.ts``). This module is dependency-free by
design, mirroring the original ``validate_model.py`` checks so the same
semantic guarantees hold inside the platform.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Optional

_ONTOLOGY_DIR = Path(__file__).resolve().parent / "ontology"
CORE_PATH = _ONTOLOGY_DIR / "human-body-core.json"
SCHEMA_PATH = _ONTOLOGY_DIR / "human-body.schema.json"

_REQUIRED_ROOT = {
    "manifest",
    "scales",
    "biological_trait_model",
    "life_stages",
    "systems",
    "whole_body_processes",
    "couplings",
    "model_contract",
    "authoritative_resources",
}


class OntologyValidationError(ValueError):
    """Raised when the body ontology violates its semantic contract."""


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise OntologyValidationError(message)


def _unique_ids(items: list[dict[str, Any]], label: str) -> set[str]:
    ids = [item.get("id") for item in items]
    _require(
        all(isinstance(value, str) and value for value in ids),
        f"{label}: every item needs an id",
    )
    _require(len(ids) == len(set(ids)), f"{label}: duplicate ids detected")
    return set(ids)


def validate_ontology(model: Mapping[str, Any]) -> None:
    """Semantic checks ported from Human-body-map/validate_model.py."""
    missing = _REQUIRED_ROOT - set(model)
    _require(not missing, f"missing root sections: {sorted(missing)}")

    scale_ids = _unique_ids(model["scales"], "scales")
    system_ids = _unique_ids(model["systems"], "systems")
    _unique_ids(model["whole_body_processes"], "whole_body_processes")
    coupling_ids = _unique_ids(model["couplings"], "couplings")
    _require(len(scale_ids) >= 11, "expected at least 11 physical scales")
    _require(len(system_ids) >= 15, "expected at least 15 organ systems")
    _require(len(coupling_ids) >= 1, "expected cross-system couplings")

    for system in model["systems"]:
        for key in ("structures", "core_functions", "processes", "state_variables"):
            _require(
                isinstance(system.get(key), list) and system[key],
                f"system {system['id']}: {key} must be a non-empty list",
            )
        _unique_ids(system["structures"], f"system {system['id']} structures")

    for coupling in model["couplings"]:
        for key in ("source_systems", "target_systems"):
            for sid in coupling.get(key, []):
                _require(
                    sid in system_ids,
                    f"coupling {coupling['id']}: unknown system '{sid}' in {key}",
                )

    traits = model["biological_trait_model"]
    _require(
        isinstance(traits.get("independent_axes"), list) and traits["independent_axes"],
        "biological_trait_model.independent_axes must be a non-empty list",
    )


@dataclass(frozen=True)
class BodyOntology:
    """Indexed, validated view over the canonical body ontology."""

    raw: Mapping[str, Any]
    systems: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)
    structures: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)
    scales: tuple = ()
    couplings: tuple = ()

    @property
    def manifest(self) -> Mapping[str, Any]:
        return self.raw["manifest"]

    @property
    def trait_axes(self) -> list[Mapping[str, Any]]:
        return list(self.raw["biological_trait_model"]["independent_axes"])

    @property
    def whole_body_processes(self) -> list[Mapping[str, Any]]:
        return list(self.raw["whole_body_processes"])

    def system(self, system_id: str) -> Mapping[str, Any]:
        try:
            return self.systems[system_id]
        except KeyError:
            raise KeyError(f"unknown organ system: {system_id!r}") from None

    def structure(self, structure_id: str) -> Mapping[str, Any]:
        try:
            return self.structures[structure_id]
        except KeyError:
            raise KeyError(f"unknown structure: {structure_id!r}") from None

    def system_of(self, structure_id: str) -> str:
        return self.structure(structure_id)["_system"]

    def couplings_for(self, system_id: str) -> list[Mapping[str, Any]]:
        self.system(system_id)  # raise on unknown id
        return [
            c
            for c in self.couplings
            if system_id in c.get("source_systems", ())
            or system_id in c.get("target_systems", ())
        ]


def load_ontology(path: Optional[Path] = None, validate: bool = True) -> BodyOntology:
    """Load, optionally validate, and index the body ontology."""
    model = json.loads((path or CORE_PATH).read_text(encoding="utf-8"))
    if validate:
        validate_ontology(model)

    systems: dict[str, Mapping[str, Any]] = {}
    structures: dict[str, dict[str, Any]] = {}
    for system in model["systems"]:
        systems[system["id"]] = system
        for structure in system["structures"]:
            entry = dict(structure)
            entry["_system"] = system["id"]
            # A structure id may appear in more than one system (e.g. shared
            # organs); first registration wins, later ones are recorded.
            if structure["id"] in structures:
                existing = structures[structure["id"]]
                shared = list(existing.get("_also_in", []))
                shared.append(system["id"])
                existing["_also_in"] = shared
            else:
                structures[structure["id"]] = entry

    return BodyOntology(
        raw=model,
        systems=systems,
        structures=structures,
        scales=tuple(s["id"] for s in model["scales"]),
        couplings=tuple(model["couplings"]),
    )
