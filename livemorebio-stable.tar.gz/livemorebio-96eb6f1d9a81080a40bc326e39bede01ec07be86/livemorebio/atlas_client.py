"""Attached reference-asset controls; no geometry acquisition or physiology here."""
from __future__ import annotations

from datetime import datetime, timezone
import ipaddress
import json
import re
from typing import Any
import urllib.error
import urllib.parse
import urllib.request

from .strict_json import parse_json_object

SOURCE_ID = "bp3d-4.0-20130619-surface-core-v1"
MAX_RESPONSE_BYTES = 2 * 1024 * 1024
_PATH = "/api/anatomy/atlas-reference"
_STATES = {"missing", "acquiring", "available", "unsafe_cache", "unsupported_converter", "corrupt"}
_SERVER_ERRORS = {"ATLAS_INVALID_ID": 422, "ATLAS_INVALID_REQUEST": 422, "ATLAS_NOT_INSTALLED": 404,
    "ATLAS_NOT_FOUND": 404, "ATLAS_ACQUIRING": 409, "ATLAS_UNSAFE_CACHE": 503, "ATLAS_SOURCE_POLICY": 503,
    "ATLAS_SOURCE_INTEGRITY": 503, "ATLAS_CONVERSION_FAILED": 503, "ATLAS_INTEGRITY_FAILED": 503,
    "ATLAS_UNSUPPORTED_CONVERTER": 503, "ATLAS_PUBLICATION_UNCONFIRMED": 503}
_MESSAGES = {
    "ATLAS_CLIENT_INVALID": "Invalid Atlas command, source identifier or attached destination.",
    "ATLAS_CLIENT_ATTACH_REQUIRED": "Atlas controls require an attached platform; no local fallback is used.",
    "ATLAS_CLIENT_AUTH_REQUIRED": "Atlas controls require operator authentication on the attached service.",
    "ATLAS_CLIENT_UNCONFIRMED": "Installation is unconfirmed. Inspect Atlas status before considering another install; no automatic retry was made.",
    "ATLAS_CLIENT_TRANSPORT": "Atlas transport is unavailable; no usable status was received.",
    "ATLAS_CLIENT_RESPONSE": "Atlas response did not satisfy the reference-only identity contract.",
    "ATLAS_CLIENT_OUTPUT": "Atlas response was confirmed but terminal output failed; inspect status before another install.",
    "ATLAS_ACQUIRING": "Atlas installation is already in progress; inspect status.",
    "ATLAS_PUBLICATION_UNCONFIRMED": "Reference publication could not be durably confirmed; inspect status before another install.",
}


class AtlasClientError(ValueError):
    """Only fixed categories and validated correlation IDs cross this boundary."""
    def __init__(self, code: str = "ATLAS_CLIENT_INVALID", *, status: int | None = None,
                 request_id: str | None = None) -> None:
        self.code = code if type(code) is str and code in (_MESSAGES.keys() | _SERVER_ERRORS.keys()) else "ATLAS_CLIENT_RESPONSE"
        self.status = status if type(status) is int and 100 <= status <= 599 else None
        self.request_id = request_id if _hex(request_id, 32) else None
        super().__init__(_MESSAGES.get(self.code, "Atlas reference operation failed its source or cache gate; inspect the safe error code."))


def _hex(value: object, length: int = 64) -> bool:
    return type(value) is str and re.fullmatch(r"[0-9a-f]{" + str(length) + "}", value) is not None


def fixed_source_id(value: object) -> str:
    if type(value) is not str or value != SOURCE_ID:
        raise AtlasClientError()
    return value


def _valid_receipt(value: object, digest: str) -> bool:
    if (type(value) is not dict or set(value) != {"receipt_id", "source_id", "manifest_sha256", "started_at", "completed_at"}
            or not _hex(value["receipt_id"], 32) or value["source_id"] != SOURCE_ID or value["manifest_sha256"] != digest):
        return False
    try:
        times = []
        for key in ("started_at", "completed_at"):
            raw = value[key]
            if type(raw) is not str or not 1 <= len(raw) <= 80:
                return False
            parsed = datetime.fromisoformat(raw)
            if parsed.tzinfo is None or parsed.utcoffset() is None:
                return False
            times.append(parsed.astimezone(timezone.utc))
        return times[1] >= times[0]
    except (ValueError, OverflowError):
        return False


def validate_response(value: object, *, installation: bool = False) -> dict[str, Any]:
    """Validate identity, readiness and acknowledgment, not the server's geometry."""
    code = "ATLAS_CLIENT_UNCONFIRMED" if installation else "ATLAS_CLIENT_RESPONSE"
    if (type(value) is not dict or not {"manifest", "manifest_sha256"} <= value.keys()
            or value.get("schema") != "livemore.atlas-reference-status.v1"
            or value.get("source_id") != SOURCE_ID or type(value.get("state")) is not str
            or value["state"] not in _STATES or value.get("reference_geometry") is not True
            or value.get("patient_registered") is not False
            or value.get("available") is not (value["state"] == "available")):
        raise AtlasClientError(code)
    if value["available"]:
        manifest = value.get("manifest")
        if (not _hex(value.get("manifest_sha256")) or type(manifest) is not dict
                or manifest.get("schema") != "livemore.atlas-reference.v1" or manifest.get("source_id") != SOURCE_ID
                or manifest.get("patient_registered") is not False or manifest.get("evidence_state") != "REFERENCE_ONLY"):
            raise AtlasClientError(code)
    elif value.get("manifest") is not None or value.get("manifest_sha256") is not None:
        raise AtlasClientError(code)
    if installation and (not value["available"] or type(value.get("reused")) is not bool
                         or not _valid_receipt(value.get("receipt"), value["manifest_sha256"])):
        raise AtlasClientError(code)
    return value


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request: Any, fp: Any, code: int, message: str,
                         headers: Any, new_url: str) -> None:
        return None


class AtlasReferenceClient:
    """SDK mixin. Importing and attached construction do not create twins/stores."""
    def _atlas_require_attach(self) -> None:
        if self.mode != "attach":
            raise AtlasClientError("ATLAS_CLIENT_ATTACH_REQUIRED")

    def atlas_reference_status(self) -> dict[str, Any]:
        """Inspect the attached service without downloading or changing assets."""
        self._atlas_require_attach()
        return self._atlas_request(installation=False)

    def install_atlas_reference(self, source_id: str) -> dict[str, Any]:
        """Explicit once-only fixed-source install; inspect status if unconfirmed."""
        self._atlas_require_attach()
        fixed_source_id(source_id)
        return self._atlas_request(installation=True)

    def _atlas_request(self, *, installation: bool) -> dict[str, Any]:
        self._atlas_require_attach()
        self.last_atlas_response = {}
        response = None
        status = None
        dispatched = False
        unreadable = "ATLAS_CLIENT_UNCONFIRMED" if installation else "ATLAS_CLIENT_RESPONSE"
        try:
            try:
                base = self._url()
                if type(base) is not str or not 1 <= len(base) <= 2048 or any(ord(char) <= 32 or ord(char) == 127 for char in base):
                    raise ValueError()
                parsed = urllib.parse.urlsplit(base)
                port = parsed.port
                try:
                    loopback = ipaddress.ip_address(parsed.hostname).is_loopback
                except ValueError:
                    loopback = parsed.hostname == "localhost"
                if (parsed.scheme not in {"http", "https"} or not parsed.hostname
                        or parsed.username is not None or parsed.password is not None or parsed.query or parsed.fragment
                        or (parsed.scheme == "http" and not loopback) or (port is not None and not 1 <= port <= 65535)):
                    raise ValueError()
            except Exception:
                raise AtlasClientError() from None
            from .security import authorization_headers
            try:
                auth = authorization_headers()
            except Exception:
                raise AtlasClientError("ATLAS_CLIENT_AUTH_REQUIRED") from None
            raw = json.dumps({"source_id": SOURCE_ID}, separators=(",", ":")).encode() if installation else None
            request = urllib.request.Request(base.rstrip("/") + _PATH + ("/install" if installation else ""),
                data=raw, method="POST" if installation else "GET", headers={"Accept": "application/json",
                "Content-Type": "application/json", "Accept-Encoding": "identity", **auth})
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
            dispatched = True
            try:
                response = opener.open(request, timeout=900 if installation else 20)
            except urllib.error.HTTPError as error:
                response = error
            status = response.status
            for header, field, pattern in (
                ("X-Livemore-Request-Id", "request_id", r"[0-9a-f]{32}"),
                ("X-Livemore-Source-Sha256", "source_sha256", r"[0-9a-f]{64}"),
                ("X-Livemore-Process-Instance", "process_instance", r"[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}")):
                value = response.headers.get(header)
                if type(value) is str and re.fullmatch(pattern, value):
                    self.last_atlas_response[field] = value
            if response.headers.get("Content-Encoding", "identity") != "identity":
                raise AtlasClientError(unreadable)
            raw = response.read(MAX_RESPONSE_BYTES + 1)
            try:
                if type(raw) is not bytes:
                    raise ValueError()
                result = parse_json_object(raw, max_bytes=MAX_RESPONSE_BYTES)
            except ValueError:
                raise AtlasClientError(unreadable) from None
            if type(status) is not int or status != 200:
                code = result.get("code")
                if type(status) is int and type(code) is str and _SERVER_ERRORS.get(code) == status:
                    raise AtlasClientError(code)
                if status == 401 and result in ({"error": "authentication required"}, {"detail": "authentication required"}):
                    raise AtlasClientError("ATLAS_CLIENT_AUTH_REQUIRED")
                raise AtlasClientError(unreadable)
            return validate_response(result, installation=installation)
        except AtlasClientError as error:
            raise AtlasClientError(error.code, status=status, request_id=self.last_atlas_response.get("request_id")) from None
        except Exception:
            raise AtlasClientError("ATLAS_CLIENT_UNCONFIRMED" if installation and dispatched else "ATLAS_CLIENT_TRANSPORT",
                                   status=status, request_id=self.last_atlas_response.get("request_id")) from None
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    # A cleanup problem cannot reverse a received acknowledgment.
                    self.last_atlas_response["cleanup_code"] = "ATLAS_CLIENT_TRANSPORT"
