"""
livemorebio.life_system.population — the population of Synthetic Human Models.

LifeSystem generates diverse, biologically-grounded synthetic humans (real genome
variants + real disease biology). This is the foundation the real LIFE Patch data
streams into: millions of real humans interpreted against this model population.
"""
from __future__ import annotations
import random
from typing import List
from . import genome as G
from .knowledge import KnowledgeBase, get_kb, _name_of
from .synthetic_human import SyntheticHuman

# curated common variants (real AF + clean mechanistic effect) for population sampling
CURATED = ["LDLR_loss", "PCSK9_gain", "APOE4", "TCF7L2", "PPARG_loss",
           "TP53_mut", "KRAS_mut", "EGFR_mut", "CDKN2A_loss", "SIRT1_high",
           "SLC22A1_lof", "SLCO1B1_lof"]


class LifeSystem:
    def __init__(self, kb: KnowledgeBase = None):
        self.kb = kb or get_kb()

    def sample_genome(self, rng) -> dict:
        g = {}
        for vid in CURATED:
            m = G.VARIANTS.get(vid)
            if not m:
                continue
            dose = sum(1 for _ in range(2) if rng.random() < m["af"])
            if dose:
                g[vid] = dose
        return g

    def generate(self, n: int = 100, seed: int = 0) -> List[SyntheticHuman]:
        rng = random.Random(seed)
        names_axis = [(_name_of(d), d["axis"]) for d in self.kb.diseases]
        common = [na[0] for na in names_axis if na[1] in ("metabolic", "cardiovascular")]
        out = []
        for i in range(n):
            age = rng.randint(22, 82)
            sex = rng.choice(["F", "M"])
            lifestyle = round(rng.uniform(0.25, 0.9), 2)
            conds = []
            p_cond = 0.12 + max(0, (age - 40) / 200.0) + max(0, (0.55 - lifestyle)) * 0.4
            if common and rng.random() < min(0.75, p_cond):
                conds.append(rng.choice(common))
            out.append(SyntheticHuman(id=f"LMB{i:04d}", age=age, sex=sex, ancestry="EUR",
                                      lifestyle=lifestyle, conditions=conds,
                                      genome=self.sample_genome(rng)))
        return out
