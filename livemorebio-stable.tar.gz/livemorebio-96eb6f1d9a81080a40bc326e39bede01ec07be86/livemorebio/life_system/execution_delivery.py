"""Exact, source-pinned delivery of an already admitted numerical LIFE receipt."""
from __future__ import annotations

from copy import deepcopy
import re
from typing import Any

from ..aegle.execution_contract import ExecutionError, encoded
from ..life_patch.protocol_v3 import ManifestV3, TelemetryEnvelopeV3, validate_manifest_binding
from ..security import sign_patch_admission

_METADATA = {"admission", "admitted_at", "capability_hash", "evidence_references", "manifest", "received_at"}


def forward_execution_receipt(record: dict[str, Any], source_client: Any) -> dict[str, Any]:
    """No gateway re-admission, new time, global snapshot or fallback endpoint.

    The caller retains this exact encrypted outbox until this function reports a
    matching application acknowledgment. Transport failure alone cannot prove
    whether the remote operation committed, so retries preserve original bytes.
    """
    try:
        encoded(record, 16 * 1024)
        envelope = TelemetryEnvelopeV3({key: value for key, value in record.items() if key not in _METADATA})
        manifest = ManifestV3(record["manifest"])
        validate_manifest_binding(manifest, envelope)
        if record["admission"] != "accepted" or envelope.mode.value != "virtual":
            raise ExecutionError()
        packet = envelope.to_dict()
        if len(packet["measurements"]) != 1:
            raise ExecutionError()
        prediction = packet["measurements"][0].get("model_context", {}).get("prediction_id", "")
        match = re.fullmatch(r"execution-([0-9a-f]{32})-frame-([1-9][0-9]{0,9})", prediction)
        if match is None:
            raise ExecutionError()
        admission = {"admission": "accepted", "admitted_at": record["admitted_at"],
                     "received_at": record["received_at"], "device_id": envelope.device_id,
                     "mode": "virtual", "envelope_hash": envelope.envelope_hash,
                     "capability_hash": manifest.capability_hash, "manifest_hash": manifest.capability_hash}
        payload = {"envelope": packet, "manifest": manifest.to_dict(), "admission": admission,
                   "admission_signature": sign_patch_admission(admission)}
        result = source_client.deliver_observation(payload)
        expected = {"admission": "accepted", "projection": "applied", "execution_id": match[1],
                    "received_frame_index": int(match[2]), "envelope_id": envelope.envelope_id,
                    "envelope_hash": envelope.envelope_hash, "evidence_class": "MODELED",
                    "physical_equivalence_validated": False}
        if (not isinstance(result, dict) or any(result.get(key) != value for key, value in expected.items())
                or result.get("physical_equivalence_validated") is not False
                or type(result.get("received_frame_index")) is not int
                or type(result.get("projected_frame_index")) is not int
                or not int(match[2]) <= result["projected_frame_index"] <= 1_000_000_000):
            raise ExecutionError("EXECUTION_CONFLICT")
        return {"aegle": {"status": "delivered", "acknowledgment": deepcopy(result)}}
    except Exception as error:
        code = error.code if isinstance(error, ExecutionError) else "EXECUTION_UNAVAILABLE"
        return {"aegle": {"status": "pending", "code": code,
                          "reason": "Exact delivery is not acknowledged; original receipt must be retained."}}
