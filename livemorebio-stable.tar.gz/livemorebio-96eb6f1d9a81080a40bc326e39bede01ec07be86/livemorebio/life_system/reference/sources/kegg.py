"""KEGG REST adapter, fail-closed until commercial-use licensing is recorded."""
from __future__ import annotations
import re
import os
import threading
import time
import urllib.parse
import urllib.request
import urllib.error
from .base import Source
from .entitlements import kegg_entitlement, approved_kegg_base


_TRANSPORT_LOCK = threading.Lock()
_LAST_REQUEST = 0.0


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # A licensed bearer credential must never follow a vendor redirect.
        raise urllib.error.HTTPError(req.full_url, code, "redirect rejected", headers, fp)


class KEGG(Source):
    name = "kegg"
    base = ""

    def source_metadata(self) -> dict:
        entitlement = kegg_entitlement()
        return {
            "source": "KEGG",
            "evidence_class": "reference",
            "endpoint": approved_kegg_base(),
            "entitlement_fingerprint": entitlement.fingerprint,
            "configured": entitlement.configured,
        }

    def fetch(self, path, parse="json", params=None, base=None):
        entitlement = kegg_entitlement()
        endpoint = approved_kegg_base()
        if not entitlement.configured or endpoint is None:
            return None
        if base is not None and base != endpoint:
            return None
        if not isinstance(path, str) or path.startswith("/") or any(x in path for x in ("..", "?", "#", "\\")):
            raise ValueError("invalid KEGG request path")
        url = endpoint + path
        if params:
            url += "?" + urllib.parse.urlencode(params)
        cache_path = self._cache_path(url + "#" + str(entitlement.fingerprint))
        from .base import _parse
        if os.path.isfile(cache_path):
            with open(cache_path, encoding="utf-8") as handle:
                return _parse(handle.read(), parse)
        if self.offline:
            return None
        headers = {"User-Agent": "LivemoreBio licensed-reference-adapter", "Accept": "text/plain"}
        token = os.environ.get("LIVEMORE_KEGG_API_TOKEN", "").strip()
        if token:
            headers["Authorization"] = "Bearer " + token
        request = urllib.request.Request(url, headers=headers)
        global _LAST_REQUEST
        with _TRANSPORT_LOCK:
            wait = self.rate - (time.monotonic() - _LAST_REQUEST)
            if wait > 0:
                time.sleep(wait)
            _LAST_REQUEST = time.monotonic()
            try:
                with urllib.request.build_opener(_NoRedirect()).open(request, timeout=30) as response:
                    raw_bytes = response.read(5_000_001)
                if len(raw_bytes) > 5_000_000:
                    return None
                raw = raw_bytes.decode("utf-8")
            except (OSError, UnicodeError, ValueError):
                return None
        from pathlib import Path
        from .licensed_import import LicensedReferenceStore
        # Reuse owner-only atomic file writing; the cache remains entitlement-scoped.
        LicensedReferenceStore(self.cache_dir)._write(Path(cache_path), raw.encode("utf-8"))
        return _parse(raw, parse)

    def diseases(self):
        txt = self.fetch("list/disease", parse="text") or ""
        return [dict(id=l.split("\t")[0], name=l.split("\t")[1].split(";")[0])
                for l in txt.strip().splitlines() if "\t" in l]

    def human_pathways(self):
        txt = self.fetch("list/pathway/hsa", parse="text") or ""
        return [dict(id=l.split("\t")[0], name=l.split("\t")[1].split(" - ")[0])
                for l in txt.strip().splitlines() if "\t" in l]

    def gene(self, symbol: str) -> dict | None:
        """Resolve a human gene without promoting the result beyond reference context."""
        symbol = symbol.strip().upper()
        if re.fullmatch(r"[A-Z0-9][A-Z0-9_.-]{0,31}", symbol) is None:
            raise ValueError("gene symbol must be a compact HGNC-style symbol")
        txt = self.fetch(
            "find/genes/" + urllib.parse.quote(symbol, safe=""), parse="text"
        ) or ""
        hits = []
        for line in txt.strip().splitlines():
            if "\t" not in line:
                continue
            identifier, description = line.split("\t", 1)
            if not identifier.startswith("hsa:"):
                continue
            aliases = re.split(r"[,\s]+", description.split(";", 1)[0].upper())
            if symbol not in aliases:
                continue
            hits.append({
                "id": identifier,
                "description": description,
                "pathways": self.gene_pathways(identifier.removeprefix("hsa:")),
            })
        return {"symbol": symbol, "hits": hits} if hits else None

    def disease(self, hid):
        """Parse a KEGG disease flat file into fields incl. PATHWAY and GENE."""
        if re.fullmatch(r"H[0-9]{5}", str(hid)) is None:
            raise ValueError("invalid KEGG disease identifier")
        from .licensed_import import get_disease_context
        context = get_disease_context("kegg", hid)
        if context["status"] == "available":
            record = context["record"]
            return {"id": hid, "name": record["name"], "category": "",
                    "description": record["description"], "pathways": record["pathways"],
                    "genes": [{"symbol": gene, "hsa": None} for gene in record["genes"]],
                    "drugs": [], "source_context": context}
        txt = self.fetch(f"get/{hid}", parse="text") or ""
        out = {"id": hid, "name": "", "category": "", "description": "",
               "pathways": [], "genes": [], "drugs": []}
        field = None
        for line in txt.splitlines():
            key = line[:12].strip()
            val = line[12:].strip()
            field = key or field
            if field == "NAME" and key == "NAME":
                out["name"] = val.split(";")[0]
            elif field == "CATEGORY" and key == "CATEGORY":
                out["category"] = val
            elif field == "DESCRIPTION" and key == "DESCRIPTION":
                out["description"] = val
            elif field == "PATHWAY":
                p = (val or line[12:]).strip().split()
                if p and p[0].startswith("hsa"):
                    out["pathways"].append(p[0])
            elif field == "GENE":
                seg = (val or line[12:]).strip()
                if "[HSA:" in seg:
                    sym = seg.split("[")[0].split(")")[-1].strip()
                    hsa = seg.split("[HSA:")[1].split("]")[0].strip()
                    out["genes"].append({"symbol": sym, "hsa": hsa})
            elif field == "DRUG":
                out["drugs"].append((val or line[12:]).strip())
        return out

    def gene_pathways(self, hsa_id):
        txt = self.fetch(f"link/pathway/hsa:{hsa_id}", parse="text") or ""
        return [l.split("\t")[1].replace("path:", "") for l in txt.strip().splitlines() if "\t" in l]

    def find_drug(self, name):
        txt = self.fetch("find/drug/" + urllib.parse.quote(name, safe=""), parse="text") or ""
        return [dict(id=l.split("\t")[0], name=l.split("\t")[1])
                for l in txt.strip().splitlines() if "\t" in l]

    def drug_targets(self, did):
        txt = self.fetch(f"get/{did}", parse="text") or ""
        targets, pathways = [], []
        for line in txt.splitlines():
            if line[:12].strip() == "TARGET" or (line.startswith("            ") and "hsa" in line):
                if "[HSA:" in line:
                    targets.append(line.split("[HSA:")[1].split("]")[0])
                if "hsa" in line and "path:" in line:
                    pathways.append("hsa" + line.split("hsa")[1][:5])
        return dict(targets=targets, pathways=pathways)
