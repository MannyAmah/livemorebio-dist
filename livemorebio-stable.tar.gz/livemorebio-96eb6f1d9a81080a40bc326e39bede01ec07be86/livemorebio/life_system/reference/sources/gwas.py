"""
livemore.reference.sources.gwas — GWAS Catalog (EBI) effect sizes.

The reference knowledgebase says *which* genes a disease involves (real, from
KEGG/DO). This source supplies *how much* a risk allele actually shifts risk —
the published per-allele odds ratio — so the physiology effect weights become
GWAS-calibrated instead of flat heuristics.

Key-free REST: https://www.ebi.ac.uk/gwas/rest/api. For a gene we query its
canonical lead SNP and take the strongest (lowest-p) association's odds ratio.
"""
from __future__ import annotations
import math
from .base import Source

# Canonical GWAS lead SNPs per gene (well-established index variants). Real,
# published associations — the effect size is fetched live from the GWAS Catalog.
GENE_LEAD_SNP = {
    # --- type 2 diabetes / metabolic ---
    "TCF7L2": "rs7903146", "SLC30A8": "rs13266634", "KCNJ11": "rs5219",
    "PPARG": "rs1801282", "CDKAL1": "rs7754840", "HHEX": "rs1111875",
    "IGF2BP2": "rs4402960", "FTO": "rs9939609", "KCNQ1": "rs2237892",
    "WFS1": "rs10010131", "HNF1B": "rs4430796", "CDKN2B": "rs10811661",
    "THADA": "rs7578597", "NOTCH2": "rs10923931", "ADAMTS9": "rs4607103",
    # --- lipids / coronary artery disease ---
    "LDLR": "rs6511720", "APOB": "rs1367117", "PCSK9": "rs11591147",
    "APOE": "rs429358", "SORT1": "rs599839", "LPA": "rs10455872",
    "CETP": "rs3764261", "CDKN2A": "rs1333049", "MRAS": "rs9818870",
    # --- inflammatory / autoimmune ---
    "IL6R": "rs2228145", "PTPN22": "rs2476601", "IL23R": "rs11209026",
    "STAT4": "rs7574865", "TNFAIP3": "rs6920220", "SH2B3": "rs3184504",
    # --- neurodegenerative ---
    "SNCA": "rs356182", "MAPT": "rs17649553", "BDNF": "rs6265",
    "PINK1": "rs45530340", "LRRK2": "rs76904798",
}

# reference log-odds so a "moderate" locus (OR≈1.3) maps to weight ≈ 1.0
_REF_LNOR = math.log(1.30)


class GWAS(Source):
    name = "gwas"
    base = "https://www.ebi.ac.uk/gwas/rest/api"

    def snp_associations(self, rsid):
        d = self.fetch(f"/singleNucleotidePolymorphisms/{rsid}/associations", params={"size": 50})
        if not isinstance(d, dict):
            return []
        return (d.get("_embedded", {}) or {}).get("associations", []) or []

    def best_effect(self, rsid):
        """Strongest (lowest-p) association carrying an odds ratio for this SNP.
        Returns {or, ln_or, risk_freq, p, allele} or None."""
        best = None
        for a in self.snp_associations(rsid):
            orv = a.get("orPerCopyNum")
            if not orv or orv <= 0:
                continue
            p = float(a.get("pvalueMantissa") or 1) * (10 ** float(a.get("pvalueExponent") or 0))
            if best is None or p < best["p"]:
                allele = None
                loci = a.get("loci") or []
                if loci and loci[0].get("strongestRiskAlleles"):
                    allele = loci[0]["strongestRiskAlleles"][0].get("riskAlleleName")
                best = {"or": round(float(orv), 3), "ln_or": round(math.log(float(orv)), 4),
                        "risk_freq": a.get("riskFrequency"), "p": p, "allele": allele}
        return best

    def gene_effect(self, gene):
        """Real GWAS effect for a gene: its lead SNP's OR → a normalized weight
        (OR 1.30 → ~1.0; OR 1.54 → ~1.6; OR 1.10 → ~0.36). None if no lead SNP."""
        rs = GENE_LEAD_SNP.get(gene)
        if not rs:
            return None
        eff = self.best_effect(rs)
        if not eff:
            return {"gene": gene, "rsid": rs, "or": None, "weight": None, "source": "gwas-catalog"}
        weight = max(0.2, min(3.0, abs(eff["ln_or"]) / _REF_LNOR))
        af = None
        try:
            af = float(eff["risk_freq"]) if eff["risk_freq"] not in (None, "NR", "") else None
        except Exception:
            af = None
        return {"gene": gene, "rsid": rs, "or": eff["or"], "p": eff["p"],
                "weight": round(weight, 3), "risk_af": af, "allele": eff["allele"],
                "source": "gwas-catalog"}
