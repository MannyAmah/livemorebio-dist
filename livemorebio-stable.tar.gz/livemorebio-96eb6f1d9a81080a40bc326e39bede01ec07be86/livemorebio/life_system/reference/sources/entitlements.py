"""Fail-closed commercial source entitlement checks.

Entitlement values are operational secrets/records.  Callers receive only the
names of missing settings, never their values.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import os
import urllib.parse


ACKNOWLEDGED = "acknowledged"


@dataclass(frozen=True)
class EntitlementStatus:
    source: str
    configured: bool
    missing: tuple[str, ...]

    @property
    def fingerprint(self) -> str | None:
        if not self.configured:
            return None
        if self.source == "KEGG":
            values = tuple(os.environ.get(name, "") for name in (
                "LIVEMORE_KEGG_LICENSE_ID", "LIVEMORE_KEGG_API_BASE", "LIVEMORE_KEGG_APPROVED_HOST",
            ))
        else:
            values = (
                os.environ.get("LIVEMORE_GENECARDS_LICENSE_ID", ""),
                os.environ.get("LIVEMORE_GENECARDS_API_BASE", ""),
            )
        return "sha256:" + hashlib.sha256("\0".join(values).encode("utf-8")).hexdigest()

    @property
    def reason(self) -> str:
        if self.configured:
            return "commercial entitlement and access path recorded"
        return "set " + ", ".join(self.missing) + " after legal approval"


def commercial_entitlement(
    source: str,
    *,
    acknowledgment_env: str,
    required_env: tuple[str, ...],
) -> EntitlementStatus:
    missing: list[str] = []
    if os.environ.get(acknowledgment_env, "").strip().lower() != ACKNOWLEDGED:
        missing.append(acknowledgment_env)
    for name in required_env:
        if not os.environ.get(name, "").strip():
            missing.append(name)
    return EntitlementStatus(source=source, configured=not missing, missing=tuple(missing))


def kegg_entitlement() -> EntitlementStatus:
    status = commercial_entitlement(
        "KEGG",
        acknowledgment_env="LIVEMORE_KEGG_COMMERCIAL_LICENSE",
        required_env=("LIVEMORE_KEGG_LICENSE_ID", "LIVEMORE_KEGG_API_BASE", "LIVEMORE_KEGG_APPROVED_HOST"),
    )
    if status.configured and approved_kegg_base() is None:
        return EntitlementStatus("KEGG", False, ("vendor-approved HTTPS KEGG endpoint and matching host",))
    return status


def approved_kegg_base() -> str | None:
    """Require an exact operator-recorded vendor host; never use the academic API."""
    base = os.environ.get("LIVEMORE_KEGG_API_BASE", "").strip()
    approved = os.environ.get("LIVEMORE_KEGG_APPROVED_HOST", "").strip().lower()
    try:
        parsed = urllib.parse.urlsplit(base)
        host = parsed.hostname or ""
        port = parsed.port
    except ValueError:
        return None
    if (parsed.scheme != "https" or not host or host != approved or
            host == "rest.kegg.jp" or host.endswith(".rest.kegg.jp") or
            parsed.username or parsed.password or parsed.query or parsed.fragment or
            port not in (None, 443) or ".." in parsed.path or "\\" in base):
        return None
    return base.rstrip("/") + "/"


def genecards_entitlement() -> EntitlementStatus:
    return commercial_entitlement(
        "GeneCards",
        acknowledgment_env="LIVEMORE_GENECARDS_COMMERCIAL_LICENSE",
        required_env=(
            "LIVEMORE_GENECARDS_LICENSE_ID",
            "LIVEMORE_GENECARDS_API_BASE",
            "GENECARDS_API_TOKEN",
        ),
    )
