"""Human Reference Atlas (humanatlas.io / CCF) reference organs + cell types, and
Human Cell Atlas (Azul) catalogs. Both key-free. The anatomy/cell-type substrate."""
from __future__ import annotations
from .base import Source


class HRA(Source):
    name = "hra"
    base = "https://apps.humanatlas.io/api/"

    def reference_organs(self):
        d = self.fetch("v1/reference-organs") or []
        seen, out = set(), []
        for x in d if isinstance(d, list) else []:
            label = x.get("label") or x.get("representation_of")
            if label and label not in seen:
                seen.add(label); out.append(label)
        return out

    def cell_types(self, organ="heart"):
        # ASCT+B derived cell types for an organ (best-effort; falls back to seed)
        d = self.fetch("v1/asctb", params={"organ": organ}) or {}
        return d if isinstance(d, dict) else {}


class HCA(Source):
    name = "hca"
    base = "https://service.azul.data.humancellatlas.org/"

    def catalogs(self):
        d = self.fetch("index/catalogs") or {}
        return dict(default=d.get("default_catalog"), catalogs=list(d.get("catalogs", {})))

    def project_count(self):
        d = self.fetch("index/projects", params={"size": "1"}) or {}
        return d.get("pagination", {}).get("total")
