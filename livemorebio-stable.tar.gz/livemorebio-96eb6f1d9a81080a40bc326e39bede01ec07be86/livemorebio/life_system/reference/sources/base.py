"""
livemore.reference.sources.base — a cached REST source.

Every reference database (KEGG, Reactome, HPA, RCSB, Disease Ontology, Orphanet,
HRA, HCA) is wrapped as a Source. Calls hit the live API, cache to disk, and fall
back to bundled seed when offline. Individual adapters may additionally enforce
credential or commercial-license gates before this transport is reached.
"""
from __future__ import annotations
import hashlib
import json
import os
import tempfile
import time
import urllib.parse
import urllib.request

CACHE_DIR = os.environ.get("LIVEMORE_CACHE", os.path.expanduser("~/.livemore/refcache"))
_LAST = {"t": 0.0}


class Source:
    name = "source"
    base = ""
    rate = 0.34          # seconds between calls (be polite; KEGG asks ~3/s)

    def __init__(self, offline=False, cache_dir=CACHE_DIR):
        self.offline = offline
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, mode=0o700, exist_ok=True)
        os.chmod(cache_dir, 0o700)

    # ---- low-level fetch with cache + throttle -----------------------------
    def _cache_path(self, url):
        h = hashlib.sha1(url.encode()).hexdigest()[:16]
        return os.path.join(self.cache_dir, f"{self.name}_{h}.cache")

    def fetch(self, path, parse="json", params=None, base=None):
        url = (base or self.base) + path
        if params:
            url += "?" + urllib.parse.urlencode(params)
        cp = self._cache_path(url)
        if os.path.exists(cp):
            os.chmod(cp, 0o600)
            with open(cp, "r", encoding="utf-8") as cached:
                raw = cached.read()
            return _parse(raw, parse)
        if self.offline:
            return None
        dt = self.rate - (time.time() - _LAST["t"])
        if dt > 0:
            time.sleep(dt)
        _LAST["t"] = time.time()
        req = urllib.request.Request(url, headers={"User-Agent": "Livemore-HHDT/0.1 (research)"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                raw = r.read().decode("utf-8", "replace")
        except Exception as error:
            if parse != "json":
                return None
            public_url = urllib.parse.urlsplit(url)._replace(query="", fragment="").geturl()
            return {"_error": type(error).__name__, "_url": public_url}
        descriptor, temporary = tempfile.mkstemp(dir=self.cache_dir, prefix=".refcache-")
        try:
            os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, "w", encoding="utf-8") as cached:
                descriptor = -1
                cached.write(raw)
                cached.flush()
                os.fsync(cached.fileno())
            os.replace(temporary, cp)
        finally:
            if descriptor >= 0:
                os.close(descriptor)
            if os.path.exists(temporary):
                os.unlink(temporary)
        return _parse(raw, parse)


def _parse(raw, mode):
    if mode == "json":
        try:
            return json.loads(raw)
        except Exception:
            return {"_raw": raw}
    return raw  # text/tsv
