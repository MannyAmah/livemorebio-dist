"""GeneCards connector for a customer-licensed API gateway.

GeneCards does not expose an unrestricted public API for commercial product
integration.  This adapter therefore accepts only an explicitly configured,
HTTPS licensed endpoint and bearer credential.  It never scrapes website HTML.
"""
from __future__ import annotations

import json
import os
import re
import tempfile
import urllib.parse
import urllib.request

from .base import Source
from .entitlements import genecards_entitlement


class GeneCards(Source):
    name = "genecards"

    def source_metadata(self) -> dict:
        entitlement = genecards_entitlement()
        return {
            "source": "GeneCards",
            "evidence_class": "reference",
            "endpoint_configured": bool(os.environ.get("LIVEMORE_GENECARDS_API_BASE", "").strip()),
            "entitlement_fingerprint": entitlement.fingerprint,
            "configured": entitlement.configured,
        }

    def _configuration(self) -> tuple[str, str] | None:
        if not genecards_entitlement().configured:
            return None
        base = os.environ["LIVEMORE_GENECARDS_API_BASE"].strip()
        if not base.startswith("https://"):
            return None
        return base.rstrip("/") + "/", os.environ["GENECARDS_API_TOKEN"].strip()

    def gene(self, symbol: str) -> dict | None:
        """Return one licensed gene record, or ``None`` when access is gated/offline."""
        symbol = symbol.strip().upper()
        if not re.fullmatch(r"[A-Z0-9][A-Z0-9_.-]{0,31}", symbol):
            raise ValueError("gene symbol must be a compact HGNC-style symbol")
        config = self._configuration()
        if config is None:
            return None
        base, token = config
        url = base + "genes/" + urllib.parse.quote(symbol, safe="")
        cache_path = self._cache_path(url)
        try:
            with open(cache_path, encoding="utf-8") as cached:
                payload = json.load(cached)
                return payload if isinstance(payload, dict) else None
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            pass
        if self.offline:
            return None
        request = urllib.request.Request(
            url,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/json",
                "User-Agent": "LivemoreBio/0.0.1 licensed-connector",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except (OSError, ValueError, json.JSONDecodeError):
            return None
        if not isinstance(payload, dict):
            return None
        os.makedirs(os.path.dirname(cache_path), mode=0o700, exist_ok=True)
        os.chmod(os.path.dirname(cache_path), 0o700)
        descriptor, temporary = tempfile.mkstemp(
            dir=os.path.dirname(cache_path), prefix=".genecards-"
        )
        try:
            os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, "w", encoding="utf-8") as cached:
                descriptor = -1
                json.dump(payload, cached, separators=(",", ":"), sort_keys=True)
                cached.flush()
                os.fsync(cached.fileno())
            os.replace(temporary, cache_path)
        finally:
            if descriptor >= 0:
                os.close(descriptor)
            if os.path.exists(temporary):
                os.unlink(temporary)
        return payload
