"""Local, versioned disease-reference imports with recorded commercial permissions.

The normalized schema is Livemore's adapter contract, not a claim about a vendor's
export format. A vendor-specific transformer must preserve the original identifiers
and citations. A recorded license declaration is not independent legal verification.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
from typing import Any


SOURCES = frozenset({"kegg", "malacards"})
MANIFEST_SCHEMA = "livemore.licensed-reference-manifest.v1"
RECORD_SCHEMA = "livemore.disease-reference.v1"
MAX_BYTES = 5_000_000
MAX_RECORDS = 5000


def _canonical(value: Any) -> bytes:
    try:
        return json.dumps(value, sort_keys=True, separators=(",", ":"),
                          ensure_ascii=True, allow_nan=False).encode("utf-8")
    except (ValueError, TypeError) as error:
        raise ValueError("reference payload must contain finite JSON values") from error


def _sha(value: Any) -> str:
    return hashlib.sha256(_canonical(value)).hexdigest()


def _source(value: str) -> str:
    if not isinstance(value, str) or value not in SOURCES:
        raise ValueError("source must be kegg or malacards")
    return value


def _identifier(source: str, value: str) -> str:
    pattern = r"H[0-9]{5}" if source == "kegg" else r"[a-z0-9][a-z0-9_]{0,127}"
    if not isinstance(value, str) or not re.fullmatch(pattern, value):
        raise ValueError("disease identifier is invalid for this source")
    return value


def _text(value: Any, field: str, maximum: int = 256) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError(f"{field} must be a nonempty bounded string")
    return value


def _timestamp(value: Any, field: str) -> datetime:
    try:
        result = datetime.fromisoformat(_text(value, field).replace("Z", "+00:00"))
    except ValueError as error:
        raise ValueError(f"{field} must be an ISO timestamp with timezone") from error
    if result.tzinfo is None:
        raise ValueError(f"{field} requires a timezone")
    return result


def validate_release(manifest: dict, records: list[dict]) -> None:
    """Validate identity, explicit permissions, lifetime, normalized schema and digest."""
    if not isinstance(manifest, dict) or manifest.get("schema") != MANIFEST_SCHEMA:
        raise ValueError("unsupported reference manifest schema")
    if manifest.get("record_schema") != RECORD_SCHEMA:
        raise ValueError("unsupported disease reference schema")
    source = _source(manifest.get("source"))
    for field in ("release", "license_id", "approval_reference", "normalization_version"):
        _text(manifest.get(field), field)
    if not re.fullmatch(r"[a-f0-9]{64}", str(manifest.get("upstream_sha256", ""))):
        raise ValueError("upstream_sha256 must identify the original licensed export")
    acquired = _timestamp(manifest.get("acquired_at"), "acquired_at")
    expires = _timestamp(manifest.get("expires_at"), "expires_at")
    current_time = datetime.now(timezone.utc)
    if acquired > current_time:
        raise ValueError("reference acquisition cannot be in the future")
    if expires <= current_time or acquired >= expires:
        raise ValueError("reference permission has expired or has an invalid lifetime")
    permissions = manifest.get("permissions")
    fields = {"internal_research", "reference_lookup", "model_training", "redistribution"}
    if not isinstance(permissions, dict) or set(permissions) != fields:
        raise ValueError("all reference permission fields must be declared")
    if any(type(permissions[field]) is not bool for field in fields):
        raise ValueError("permission values must be boolean")
    if not permissions["internal_research"] or not permissions["reference_lookup"]:
        raise ValueError("internal research and reference lookup permission are required")
    if not isinstance(records, list) or not 1 <= len(records) <= MAX_RECORDS:
        raise ValueError("reference release requires 1 to 5000 disease records")
    if type(manifest.get("record_count")) is not int or manifest["record_count"] != len(records):
        raise ValueError("reference record count does not match")
    seen = set()
    for record in records:
        if not isinstance(record, dict):
            raise ValueError("disease reference record must be an object")
        if set(record) != {"id", "name", "description", "genes", "pathways", "identifiers", "citations"}:
            raise ValueError("disease reference record fields do not match the normalized schema")
        identifier = _identifier(source, record.get("id"))
        if identifier in seen:
            raise ValueError("duplicate source disease identifier")
        seen.add(identifier)
        _text(record.get("name"), "disease name", 512)
        description = record.get("description")
        if not isinstance(description, str) or len(description) > 20000:
            raise ValueError("description must be a bounded string")
        for field in ("genes", "pathways", "citations"):
            values = record.get(field)
            if not isinstance(values, list) or len(values) > 1000:
                raise ValueError(f"{field} must be a bounded array")
            for value in values:
                _text(value, field, 2048 if field == "citations" else 128)
        identifiers = record.get("identifiers")
        if not isinstance(identifiers, dict) or len(identifiers) > 50:
            raise ValueError("identifiers must be a bounded mapping")
        for key, value in identifiers.items():
            _text(key, "identifier namespace", 64)
            _text(value, "identifier value", 256)
    if not re.fullmatch(r"[a-f0-9]{64}", str(manifest.get("records_sha256", ""))):
        raise ValueError("records_sha256 must be a lowercase SHA-256 digest")
    if _sha(records) != manifest["records_sha256"]:
        raise ValueError("reference records failed digest verification")
    if len(_canonical({"manifest": manifest, "records": records})) > MAX_BYTES:
        raise ValueError("reference release exceeds the local import size limit")


def _metadata(manifest: dict, release_sha256: str) -> dict:
    return {
        key: manifest[key] for key in (
            "source", "release", "acquired_at", "expires_at", "record_schema",
            "record_count", "records_sha256", "permissions", "normalization_version", "upstream_sha256",
        )
    } | {
        "release_sha256": release_sha256,
        "entitlement_fingerprint": _sha({"license_id": manifest["license_id"],
                                         "approval_reference": manifest["approval_reference"]}),
        "permission_verification": "operator-recorded; vendor agreement required",
    }


class LicensedReferenceStore:
    """Local reference-only storage; no network or physiology-engine dependency."""

    def __init__(self, directory: str | Path | None = None) -> None:
        from .... import registry
        self.directory = Path(directory or os.environ.get(
            "LIVEMORE_LICENSED_REFERENCE_DIR", str(Path(registry.REG_DIR) / "licensed-references"),
        )).expanduser()
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.directory.chmod(0o700)

    def _write(self, path: Path, data: bytes) -> None:
        descriptor, temporary = tempfile.mkstemp(dir=self.directory, prefix=".reference-")
        try:
            os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, "wb") as handle:
                descriptor = -1
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, path)
        finally:
            if descriptor >= 0:
                os.close(descriptor)
            if os.path.exists(temporary):
                os.unlink(temporary)

    def import_records(self, manifest: dict, records: list[dict]) -> dict:
        validate_release(manifest, records)
        payload = {"manifest": manifest, "records": records}
        digest = _sha(payload)
        release_path = self.directory / f"{digest}.json"
        if not release_path.exists():
            self._write(release_path, _canonical(payload))
        elif release_path.read_bytes() != _canonical(payload):
            raise ValueError("existing reference release failed integrity verification")
        self._write(self.directory / f"{manifest['source']}.current", digest.encode("ascii"))
        return {"status": "imported", "release_sha256": digest,
                "source": _metadata(manifest, digest), "evidence_class": "reference"}

    def _load(self, source: str) -> tuple[dict, str]:
        _source(source)
        pointer = self.directory / f"{source}.current"
        if pointer.is_symlink() or pointer.stat().st_size > 64:
            raise ValueError("invalid reference release pointer")
        digest = pointer.read_text(encoding="ascii")
        if not re.fullmatch(r"[a-f0-9]{64}", digest):
            raise ValueError("invalid reference release pointer")
        path = self.directory / f"{digest}.json"
        if path.is_symlink() or path.stat().st_size > MAX_BYTES:
            raise ValueError("invalid reference release file")
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict) or _sha(payload) != digest:
            raise ValueError("reference release failed integrity verification")
        validate_release(payload.get("manifest"), payload.get("records"))
        if payload["manifest"]["source"] != source:
            raise ValueError("reference release source mismatch")
        return payload, digest

    def source_status(self, source: str) -> dict:
        _source(source)
        try:
            payload, digest = self._load(source)
        except FileNotFoundError:
            return {"source": source, "status": "unavailable",
                    "reason": "import a vendor-authorized disease release with a permission manifest"}
        except (ValueError, OSError, UnicodeError, KeyError, TypeError):
            return {"source": source, "status": "invalid",
                    "reason": "reference release failed schema, integrity, or permission checks"}
        return {"status": "available", **_metadata(payload["manifest"], digest)}

    def disease_context(self, source: str, identifier: str) -> dict:
        _source(source)
        _identifier(source, identifier)
        try:
            payload, digest = self._load(source)
        except FileNotFoundError:
            return {"source": source, "status": "unavailable",
                    "reason": "no licensed local disease release has been imported"}
        except (ValueError, OSError, UnicodeError, KeyError, TypeError):
            return {"source": source, "status": "invalid",
                    "reason": "reference release failed schema, integrity, or permission checks"}
        record = next((row for row in payload["records"] if row["id"] == identifier), None)
        result = {"schema": "livemore.disease-context.v1", "status": "available" if record else "not_found",
                  "source": _metadata(payload["manifest"], digest), "identifier": identifier,
                  "evidence_class": "reference", "physiology_effect": "none",
                  "qualification_state": "NOT_QUALIFIED"}
        if record is not None:
            result.update(record=record, record_sha256=_sha(record))
        return result


def get_disease_context(source: str, identifier: str, *, directory: str | Path | None = None) -> dict:
    """API/SDK entry point for exact, local reference lookup; caller enforces auth."""
    return LicensedReferenceStore(directory).disease_context(source, identifier)


__all__ = ["LicensedReferenceStore", "get_disease_context", "validate_release"]
