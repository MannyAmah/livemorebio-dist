"""Generate reference-informed synthetic participants for development and demos.

Each call samples a synthetic genotype from a curated association catalogue, then
uses heuristic formulas to derive model susceptibility, biomarker-like values, and
lifestyle fields. Source identifiers preserve provenance to reference resources,
but the generated records are not real people, patient data, cohort-fitted biology,
clinical baselines, or validated disease-risk estimates. ``RealHuman`` remains the
legacy class name for compatibility; instances created here are synthetic.
"""
from __future__ import annotations
import random
from .knowledgebase import KnowledgeBase, AXIS_EFFECT
from .realhuman import RealHuman

_REGISTERED = False


class PatientFactory:
    def __init__(self, kb: KnowledgeBase | None = None, seed=None):
        self.kb = kb or KnowledgeBase()
        self.rng = random.Random(seed)
        global _REGISTERED
        if not _REGISTERED:
            self.kb.register_into_engine()      # reference-only compatibility no-op
            _REGISTERED = True

    def create(self, pid, name=None, sex=None, age=None, ancestry=None, rng=None, seed=None):
        if seed is not None:
            rng = random.Random(seed)
        rng = rng or self.rng
        sex = sex or rng.choice(["F", "M"])
        age = float(age if age is not None else max(18, min(92, rng.gauss(52, 16))))
        ancestry = ancestry or rng.choice(["AFR", "EUR", "EAS", "SAS", "AMR"])

        # 1) sample a synthetic genotype from the reference association catalogue
        genome = {}
        for g, v in self.kb.variant_catalogue().items():
            frequency = v.get("af")
            if frequency is None:
                continue
            d = sum(1 for _ in range(2) if rng.random() < frequency)
            if d:
                genome[g] = d

        # 2) per-axis disease susceptibility from carried risk alleles
        axis_load = {a: 0.0 for a in AXIS_EFFECT}
        for g, dose in genome.items():
            v = self.kb.variant_catalogue()[g]
            for a in v["axes"]:
                axis_load[a] += dose * 0.5
        # normalise to ~0..1
        sus = {a: min(1.0, axis_load[a] / 6.0) for a in axis_load}

        # 3) heuristic biomarker-like baseline from model scores + demographics + noise
        age_f = (age - 40) / 50
        profile = dict(
            bmi=round(_clip(rng.gauss(24 + 8 * sus["metabolic"] + 1.5 * age_f, 3), 17, 46), 1),
            ldl=round(_clip(rng.gauss(105 + 70 * sus["cardiovascular"] + 10 * age_f, 22), 55, 300)),
            hdl=round(_clip(rng.gauss(55 - 14 * sus["metabolic"], 9), 25, 95)),
            hba1c=round(_clip(rng.gauss(5.3 + 2.2 * sus["metabolic"] + 0.3 * age_f, 0.5), 4.6, 12), 1),
            fasting_glucose=round(_clip(rng.gauss(88 + 55 * sus["metabolic"], 12), 70, 300)),
            systolic_bp=round(_clip(rng.gauss(116 + 28 * sus["cardiovascular"] + 8 * age_f, 10), 96, 200)),
            smoking_pack_years=round(max(0, rng.gauss(6 + 30 * sus["respiratory"] + 20 * sus["oncologic"] * rng.random(), 12))),
            inflammation=round(_clip(rng.gauss(0.24 + 0.45 * sus["inflammatory"] + 0.2 * sus["metabolic"], 0.1), 0, 1), 2),
            microbiome_quality=round(_clip(rng.gauss(0.62 - 0.2 * sus["inflammatory"], 0.16), 0, 1), 2),
            nutrition_quality=round(_clip(rng.gauss(0.6 - 0.15 * sus["metabolic"], 0.16), 0, 1), 2),
            activity_level=round(_clip(rng.gauss(0.55 - 0.15 * sus["metabolic"], 0.16), 0, 1), 2),
            sleep_quality=round(_clip(rng.gauss(0.62 - 0.1 * sus["neuro"], 0.15), 0, 1), 2),
            air_pollution=round(_clip(rng.gauss(0.25, 0.12), 0, 1), 2),
            alcohol=round(_clip(rng.gauss(0.2, 0.14), 0, 1), 2),
            medication_adherence=round(_clip(rng.gauss(0.7, 0.18), 0, 1), 2),
            compound_strength=0.0,
            stress=round(_clip(rng.gauss(0.3 + 0.2 * sus["inflammatory"], 0.12), 0, 1), 2),
        )

        # 3b) reference-informed PRS overlay; the phenotype mapping remains unvalidated
        from . import prs as PRS
        _bounds = dict(ldl=(55, 300), hba1c=(4.6, 12), fasting_glucose=(70, 300),
                       bmi=(17, 46), systolic_bp=(96, 200), inflammation=(0, 1))
        prs_z = PRS.scores(genome)
        for bm, off in PRS.biomarker_offsets(genome).items():
            if bm in profile:
                lo, hi = _bounds.get(bm, (None, None))
                val = profile[bm] + off
                profile[bm] = round(_clip(val, lo, hi) if lo is not None else val,
                                    1 if bm in ("bmi", "hba1c", "inflammation") else 0)

        h = RealHuman(pid, name=name or pid, age=age, sex=sex, profile=profile,
                      genome=genome, seed=rng.randint(0, 1 << 30))

        # 4) attach reference provenance for the synthetic generation inputs
        top = sorted(sus.items(), key=lambda kv: -kv[1])[:3]
        carried_diseases = {}
        for g in genome:
            for dz in self.kb.variant_catalogue()[g]["diseases"]:
                carried_diseases[dz] = carried_diseases.get(dz, 0) + 1
        h.reference = dict(
            evidence_class="synthetic_demonstration",
            clinical_validation="NOT_QUALIFIED",
            unknown_allele_frequency_policy="not sampled",
            physiology_source="legacy heuristic baseline; reference associations have no causal weights",
            ancestry=ancestry,
            susceptibility={a: round(s, 3) for a, s in sus.items()},
            polygenic_scores={a: z for a, z in prs_z.items() if abs(z) > 1e-6},
            top_axes=[a for a, _ in top],
            risk_alleles=len(genome),
            carried_disease_genes=dict(sorted(carried_diseases.items(), key=lambda kv: -kv[1])[:6]),
            organ_profile=self._organ_profile(sus),
            grounded_in=self.kb.summary()["sources"],
        )
        return h

    def _organ_profile(self, sus):
        """Map model susceptibility axes to heuristic organ-load scores."""
        organ = {o: 0.0 for o in self.kb.organs()}
        for axis, load in sus.items():
            for o in AXIS_EFFECT[axis][1]:
                if o in organ:
                    organ[o] = round(min(1.0, organ[o] + load * 0.6), 3)
        return organ

    def create_cohort(self, n, prefix="LP", seed=None):
        rng = random.Random(seed) if seed is not None else self.rng
        return [self.create(f"{prefix}-{i+1:04d}", rng=rng) for i in range(n)]


def _clip(x, lo, hi):
    return max(lo, min(hi, x))
