"""Illustrative parameter shifts for synthetic longitudinal model scenarios.

The named drugs and compounds are reference labels, while the coefficients below
are hard-coded, unvalidated demonstration assumptions. Applying one mutates only a
synthetic participant profile; it does not simulate pharmacology, predict treatment
response, represent administration to a person, or support a clinical decision.
"""
from __future__ import annotations

# Reference drug names -> illustrative, unvalidated model parameter shifts.
DRUG_EFFECTS = {
    "metformin":     dict(axis="metabolic",      hba1c=-0.9, fasting_glucose=-28, bmi=-0.5),
    "empagliflozin": dict(axis="metabolic",      hba1c=-0.7, fasting_glucose=-24, bmi=-1.2),
    "pioglitazone":  dict(axis="metabolic",      hba1c=-1.0, fasting_glucose=-30),
    "semaglutide":   dict(axis="metabolic",      hba1c=-1.4, fasting_glucose=-34, bmi=-4.0),
    "insulin":       dict(axis="metabolic",      hba1c=-1.6, fasting_glucose=-45),
    "atorvastatin":  dict(axis="cardiovascular", ldl=-70, hdl=+3),
    "lisinopril":    dict(axis="cardiovascular", systolic_bp=-14),
    "aspirin":       dict(axis="cardiovascular", inflammation=-0.05),
    "warfarin":      dict(axis="cardiovascular"),
    "imatinib":      dict(axis="oncologic",      inflammation=-0.03),
}
# Botanical/nutrition labels -> illustrative, unvalidated model parameter shifts.
COMPOUNDS = {
    "bitter_kola":  dict(inflammation=-0.12, compound_strength=+0.4),
    "resveratrol":  dict(inflammation=-0.08, compound_strength=+0.3),
    "moringa":      dict(inflammation=-0.06, nutrition_quality=+0.15, compound_strength=+0.25),
    "berberine":    dict(hba1c=-0.5, fasting_glucose=-15, compound_strength=+0.3),
    "omega3":       dict(inflammation=-0.05, ldl=-8),
}


def apply_treatment(human, drug, intensity=1.0):
    """Apply an illustrative coefficient set to a synthetic participant model."""
    e = DRUG_EFFECTS.get(drug.lower())
    if not e:
        return {
            "drug": drug,
            "applied": False,
            "note": "no illustrative model coefficients are configured",
        }
    adh = human.profile.get("medication_adherence", 0.7)
    scale = intensity * (0.4 + 0.6 * adh)
    changed = {}
    for k, dv in e.items():
        if k == "axis":
            continue
        cur = human.profile.get(k, 0.0)
        human.profile[k] = round(_bound(k, cur + dv * scale), 3)
        changed[k] = human.profile[k]
    human._refresh_state()
    return {"drug": drug, "axis": e["axis"], "applied": True, "changed": changed}


def apply_compound(human, compound, intensity=1.0):
    e = COMPOUNDS.get(compound.lower())
    if not e:
        return {"compound": compound, "applied": False}
    changed = {}
    for k, dv in e.items():
        cur = human.profile.get(k, 0.0)
        human.profile[k] = round(_bound(k, cur + dv * intensity), 3)
        changed[k] = human.profile[k]
    human._refresh_state()
    return {"compound": compound, "applied": True, "changed": changed}


def apply_lifestyle(human, **deltas):
    """Nudge lifestyle factors (activity, sleep, nutrition, alcohol, ...)."""
    changed = {}
    for k, dv in deltas.items():
        cur = human.profile.get(k, 0.5)
        human.profile[k] = round(_bound(k, cur + dv), 3)
        changed[k] = human.profile[k]
    human._refresh_state()
    return changed


def _bound(key, v):
    if key in ("hba1c",):
        return max(4.4, min(13, v))
    if key in ("ldl", "hdl", "fasting_glucose", "systolic_bp", "bmi", "smoking_pack_years"):
        return max(0, v)
    return max(0.0, min(1.0, v))
