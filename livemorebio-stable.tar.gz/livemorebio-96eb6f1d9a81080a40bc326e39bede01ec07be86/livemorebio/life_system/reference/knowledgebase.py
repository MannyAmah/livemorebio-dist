"""
livemore.reference.knowledgebase — the LIFE Patch reference database.

Exposes inherited reference annotations as genes ↔ diseases ↔ pathways ↔ organs.
An association does not specify a causal reaction, variant identity, or population
allele frequency. This layer never registers gene effects in the physiology engine.
Inherited seed entries have incomplete acquisition provenance and require source
review before pharmaceutical reuse; licensed imports use separate verified manifests.
"""
from __future__ import annotations
import json
import os
import urllib.parse

SEED = os.path.join(os.path.dirname(__file__), "seed")

# HRA reference organ label -> the 9 twin organs
ORGAN_MAP = {
    "heart": "heart", "blood vasculature": "vasculature", "lung": "lungs", "left lung": "lungs",
    "right lung": "lungs", "pancreas": "pancreas", "liver": "liver", "large intestine": "gut",
    "small intestine": "gut", "kidney": "kidneys", "left kidney": "kidneys",
    "right kidney": "kidneys", "brain": "brain", "spleen": "immune", "thymus": "immune",
    "lymph node": "immune", "bone marrow": "immune", "blood": "immune",
}

# Compatibility shape: reference category -> (no causal effects, suggested organs).
# Categories are navigation hints, not validated disease-to-organ effects.
AXIS_EFFECT = {
    "metabolic":      (dict(), ["pancreas", "liver", "gut"]),
    "cardiovascular": (dict(), ["heart", "vasculature"]),
    "oncologic":      (dict(), ["lungs", "gut", "immune"]),
    "neuro":          (dict(), ["brain"]),
    "inflammatory":   (dict(), ["immune", "gut"]),
    "respiratory":    (dict(), ["lungs"]),
    "renal":          (dict(),                                                   ["kidneys"]),
    "musculoskeletal":(dict(),                                                   ["immune"]),
    "unknown":        (dict(), []),
}


def _axis_of(disease):
    cat = (disease.get("category") or "").lower()
    nm = (disease.get("name") or disease.get("query") or "").lower()
    if "cancer" in nm or "carcinoma" in nm or "melanoma" in cat or "cancer" in cat or "melanoma" in nm:
        return "oncologic"
    if "cardiovascular" in cat or "coronary" in nm or "heart" in nm or "hypertension" in nm or "cholesterol" in nm:
        return "cardiovascular"
    if "endocrine" in cat or "metabolic" in cat or "diabetes" in nm or "obesity" in nm or "liver" in nm:
        return "metabolic"
    if "nervous" in cat or "alzheimer" in nm or "parkinson" in nm:
        return "neuro"
    if "immune" in cat or "arthritis" in nm or "bowel" in nm or "asthma" in nm:
        return "inflammatory"
    if "respiratory" in cat or "pulmonary" in nm or "copd" in nm:
        return "respiratory"
    if "kidney" in nm or "renal" in nm:
        return "renal"
    if "osteo" in nm or "muscul" in cat:
        return "musculoskeletal"
    return "unknown"


class KnowledgeBase:
    def __init__(self, offline=True):
        self.offline = offline
        self.diseases = _load("diseases.json", [])
        self.genes = _load("genes.json", {})
        self.pathways = _load("pathways.json", {})
        self.drugs = _load("drugs.json", [])
        self.structures = _load("structures.json", {})
        self.anatomy = _load("anatomy.json", {})
        self.meta = _load("meta.json", {})
        self._index()

    def _index(self):
        # disease -> axis + organs; gene -> diseases/axes
        self.gene_diseases = {}
        self.variants = {}
        for d in self.diseases:
            d["axis"] = _axis_of(d)
            d["organs"] = AXIS_EFFECT[d["axis"]][1]
            d["evidence_class"] = "reference"
            d["provenance_status"] = "inherited_seed_requires_review"
            self._register_disease(d)

    # ---- queries ------------------------------------------------------------
    def disease(self, name):
        n = str(name).strip().casefold()
        matches = [d for d in self.diseases if n and n in
                   {str(d.get("name", "")).strip().casefold(),
                    str(d.get("query", "")).strip().casefold()}]
        return matches[0] if len(matches) == 1 else None

    def gene(self, sym):
        g = dict(self.genes.get(sym, {"symbol": sym}))
        g["diseases"] = self.gene_diseases.get(sym, [])
        g["structure"] = self.structures.get(sym)
        return g

    def organs(self):
        seen = []
        for o in self.anatomy.get("hra_reference_organs", []):
            t = ORGAN_MAP.get(o.lower())
            if t and t not in seen:
                seen.append(t)
        return seen

    def variant_catalogue(self):
        """Legacy name for gene associations; no inferred genotype or causal effects."""
        return self.variants

    def register_into_engine(self):
        """Compatibility no-op: reference annotations cannot release biology models."""
        return 0


    # ---- on-demand resolution: ANY condition, not just the seed ------------
    def _live_sources(self):
        if not hasattr(self, "_kegg"):
            from .sources import KEGG, DiseaseOntology
            self._kegg = KEGG(offline=False)
            self._do = DiseaseOntology(offline=False)
        return self._kegg, self._do

    def resolve(self, name, live=True):
        """Resolve an exact reference name; unknown/ambiguous terms stay unresolved."""
        d = self.disease(name)
        if d:
            return d
        if not live or self.offline:
            return None
        kegg, do = self._live_sources()
        hits = kegg.fetch("find/disease/" + urllib.parse.quote(name), parse="text") or ""
        exact = [row.split("\t", 1)[0] for row in hits.splitlines() if "\t" in row
                 and name.casefold().strip() in [label.strip().casefold()
                                                for label in row.split("\t", 1)[1].split(";")]]
        hid = exact[0] if len(exact) == 1 else None
        matches = [row for row in do.search(name, rows=5)
                   if str(row.get("label", "")).strip().casefold() == name.strip().casefold()]
        dot = matches[0] if len(matches) == 1 else None
        if hid is None and dot is None:
            return None
        rec = {"query": name, "kegg": hid, "name": name.title(), "genes": [], "pathways": [], "description": ""}
        if hid:
            dd = kegg.disease(hid)
            rec.update(name=dd["name"] or name.title(), category=dd["category"],
                       description=(dd["description"] or "")[:400], pathways=dd["pathways"][:12],
                       genes=[g["symbol"] for g in dd["genes"]][:24])
        rec["doid"] = dot["doid"] if dot else None
        if dot and not rec["description"]:
            rec["description"] = dot.get("desc") or ""
        rec["evidence_class"] = "reference"
        rec["physiology_effect"] = "none"
        rec["axis"] = _axis_of(rec)
        rec["organs"] = AXIS_EFFECT[rec["axis"]][1]
        self.diseases.append(rec)
        self._register_disease(rec)
        return rec

    def _register_disease(self, d):
        """Index gene associations only; never infer causal effects or frequencies."""
        for g in d.get("genes", []):
            if not g:
                continue
            v = self.variants.setdefault(g, dict(gene=g, af=None, effect={}, axes=[], diseases=[],
                                                 evidence_class="reference", executable=False))
            name = d.get("name") or d.get("query")
            v["axes"] = sorted(set(v["axes"]) | {d["axis"]})
            v["diseases"] = sorted(set(v["diseases"]) | {name})
            self.gene_diseases[g] = sorted(set(self.gene_diseases.get(g, [])) | {name})

    def summary(self):
        return dict(diseases=len(self.diseases), genes=len(self.genes),
                    variants=len(self.variants),
                    reactome_pathways=len(self.pathways.get("reactome_top", [])),
                    kegg_pathways=len(self.pathways.get("kegg_human", {})),
                    drugs=len(self.drugs), organs=self.organs(),
                    sources=self.meta.get("sources", []),
                    evidence_class="reference", physiology_registration="disabled",
                    seed_provenance_status="inherited_seed_requires_review")

    # ---- live expansion -----------------------------------------------------
    def refresh(self, diseases=None):
        """Pull additional diseases from the live KEGG/DO APIs and merge."""
        from .build_seed import build  # re-run curated build (writes seed)
        build()
        self.__init__(offline=self.offline)
        return self.summary()


def _load(fn, default):
    p = os.path.join(SEED, fn)
    return json.load(open(p)) if os.path.exists(p) else default
