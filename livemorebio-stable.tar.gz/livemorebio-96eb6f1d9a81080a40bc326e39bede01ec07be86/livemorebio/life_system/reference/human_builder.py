"""
livemore.reference.human_builder — the generative human substrate.

This is synthetic research infrastructure (not a catalogue): describe a modeled
host in a sentence or structured spec, and build_human() assembles reference inputs by resolving each
named condition against the live reference databases (KEGG/Reactome/HPA/DO/…),
sampling risk-associated variants, and setting a plausible but unvalidated baseline. There is
no fixed set of humans or diseases; anything you can describe, you can instantiate.

    h = build_human(describe("a 58-year-old female heavy smoker with COPD and type 2 diabetes"))
    h = build_human(HumanSpec(age=44, sex="M", conditions=["familial hypercholesterolemia"]))
"""
from __future__ import annotations
import random
import re
from dataclasses import dataclass, field
from .knowledgebase import KnowledgeBase, AXIS_EFFECT
from .realhuman import RealHuman

# Legacy demonstration phenotype presets, not patient observations or causal biology.
# Unknown conditions and reference gene associations never create phenotype effects.
CONDITION_PHENOTYPE = {
    "type 2 diabetes":   dict(profile=dict(hba1c=8.1, fasting_glucose=158, bmi=31), force=["TCF7L2", "SLC30A8"]),
    "type 1 diabetes":   dict(profile=dict(hba1c=8.6, fasting_glucose=185), force=["HLA-DQB1", "INS"]),
    "prediabetes":       dict(profile=dict(hba1c=6.0, fasting_glucose=112)),
    "familial hypercholesterolemia": dict(profile=dict(ldl=245, hdl=42), force=["LDLR"]),
    "hypercholesterolemia": dict(profile=dict(ldl=192)),
    "hypertension":      dict(profile=dict(systolic_bp=152)),
    "obesity":           dict(profile=dict(bmi=35, inflammation=0.45), force=["FTO", "MC4R"]),
    "coronary artery disease": dict(profile=dict(ldl=172, systolic_bp=140), progression=dict(plaque=0.35)),
    "atherosclerosis":   dict(profile=dict(ldl=175), progression=dict(plaque=0.4)),
    "copd":              dict(profile=dict(smoking_pack_years=42, inflammation=0.55)),
    "chronic obstructive pulmonary": dict(profile=dict(smoking_pack_years=42, inflammation=0.55)),
    "nonalcoholic fatty liver": dict(profile=dict(bmi=33, inflammation=0.4)),
    "nafld":             dict(profile=dict(bmi=33, inflammation=0.4)),
    "asthma":            dict(profile=dict(inflammation=0.45)),
    "rheumatoid arthritis": dict(profile=dict(inflammation=0.6)),
    "inflammatory bowel disease": dict(profile=dict(inflammation=0.55, microbiome_quality=0.35)),
    "chronic kidney disease": dict(profile=dict(systolic_bp=145)),
    "metabolic syndrome": dict(profile=dict(bmi=33, hba1c=6.2, ldl=160, systolic_bp=140, hdl=38)),
    "lung cancer":       dict(profile=dict(smoking_pack_years=45), progression=dict(tumor=0.2), force=["KRAS", "TP53"]),
    "non-small cell lung cancer": dict(profile=dict(smoking_pack_years=45), progression=dict(tumor=0.2), force=["KRAS", "EGFR"]),
    "colorectal cancer": dict(progression=dict(tumor=0.18), force=["KRAS", "TP53"]),
    "breast cancer":     dict(progression=dict(tumor=0.15), force=["BRCA1", "BRCA2"]),
    "alzheimer":         dict(progression=dict(senescence=0.4), force=["APOE", "APP"]),
    "parkinson":         dict(progression=dict(senescence=0.35), force=["SNCA"]),
    "healthy":           dict(profile=dict(inflammation=0.16, activity_level=0.75, nutrition_quality=0.8)),
}


@dataclass
class HumanSpec:
    id: str = "H"
    name: str = ""
    age: float = 50.0
    sex: str = "F"
    ancestry: str = "EUR"
    conditions: list = field(default_factory=list)     # any names — resolved live
    genes: dict = field(default_factory=dict)          # explicit variant overrides {sym: dosage}
    lifestyle: dict = field(default_factory=dict)       # any factor overrides
    environment: dict = field(default_factory=dict)     # pollution, season, stressors, care_access
    random_background: float = 0.0                       # 0..1 extra sporadic variant load
    description: str = ""


# ------------------------------------------------------------------ describe()
_SEX = [(r"\b(female|woman|girl|f)\b", "F"), (r"\b(male|man|boy|m)\b", "M")]
_ANC = {"african": "AFR", "european": "EUR", "caucasian": "EUR", "asian": "EAS",
        "east asian": "EAS", "south asian": "SAS", "hispanic": "AMR", "latino": "AMR"}
_LIFE = {
    r"non[- ]?smoker": dict(smoking_pack_years=0),
    r"\bsmoker|smokes\b": dict(smoking_pack_years=22),
    r"heavy smoker|chain smok": dict(smoking_pack_years=48),
    r"sedentary|inactive|couch": dict(activity_level=0.25),
    r"athlete|very active|highly active": dict(activity_level=0.85),
    r"\bactive\b": dict(activity_level=0.7),
    r"poor diet|unhealthy diet|junk": dict(nutrition_quality=0.3),
    r"healthy diet|clean diet|mediterranean": dict(nutrition_quality=0.82),
    r"obese": dict(bmi=35), r"overweight": dict(bmi=29),
    r"heavy drink|alcoholic": dict(alcohol=0.7), r"drinks socially": dict(alcohol=0.35),
    r"stressed|high stress|burnout": dict(stress=0.7),
    r"poor sleep|insomnia|sleep[- ]deprived": dict(sleep_quality=0.3),
}
_ENV = {r"polluted|air pollution|smog": dict(air_pollution=0.7),
        r"rural|clean air": dict(air_pollution=0.1),
        r"low[- ]income|underserved|no insurance": dict(care_access=0.3)}


def describe(text, id="H", kb: KnowledgeBase | None = None) -> HumanSpec:
    """Parse a free-text description into a HumanSpec (rule-based, no LLM)."""
    t = " " + text.lower() + " "
    spec = HumanSpec(id=id, description=text)
    m = re.search(r"(\d{1,3})\s*[- ]?\s*(?:year|yr|yo|y/o|y\.o|aged)", t)
    if m:
        spec.age = float(m.group(1))
    for pat, val in _SEX:
        if re.search(pat, t):
            spec.sex = val
            break
    for k, v in _ANC.items():
        if k in t:
            spec.ancestry = v
            break
    for pat, delta in {**_LIFE}.items():
        if re.search(pat, t):
            spec.lifestyle.update(delta)
    for pat, delta in _ENV.items():
        if re.search(pat, t):
            spec.environment.update(delta)
    # conditions: known keywords + phrases after with/has/diagnosed/suffers from
    conds = []
    for name in CONDITION_PHENOTYPE:
        if name != "healthy" and re.search(r"\b" + re.escape(name), t):
            conds.append(name)
    _skip = ("smoker", "smokes", "diet", "active", "sedentary", "old", "year", "stress",
             "sleep", "drink", "obese", "overweight", "pollut", "income", "insurance", "city", "athlete")
    for m in re.finditer(r"(?:diagnosed with|suffers from|with|has|have)\s+([a-z0-9 ,\-']{3,70})", t):
        for part in re.split(r"\s+and\s+|\s*,\s*|\s+plus\s+", m.group(1)):
            part = part.strip(" .-'\t")
            if part.split()[:1] == ["in"]:
                continue
            if len(part) < 3 or any(w in part for w in _skip):
                continue
            if any(part in c or c in part for c in conds):
                continue
            conds.append(part)
    # drop any long phrase that contains a shorter captured condition
    conds = [c for c in conds if not any(o != c and o in c for o in conds)]
    spec.conditions = conds[:8]
    return spec


# ------------------------------------------------------------------ build_human()
class HumanBuilder:
    def __init__(self, kb: KnowledgeBase | None = None, seed=None):
        self.kb = kb or KnowledgeBase()
        self.rng = random.Random(seed)

    def build(self, spec: HumanSpec, rng=None) -> RealHuman:
        rng = rng or self.rng
        # healthy baseline
        profile = dict(bmi=24, ldl=100, hdl=55, hba1c=5.3, fasting_glucose=88, systolic_bp=116,
                       smoking_pack_years=0, inflammation=0.2, microbiome_quality=0.65,
                       nutrition_quality=0.65, activity_level=0.6, sleep_quality=0.65,
                       air_pollution=0.2, alcohol=0.15, medication_adherence=0.7,
                       compound_strength=0.0, stress=0.25)
        progression = dict(plaque=0.08, beta_mass=0.9, tumor=0.0, senescence=0.12, months=0.0)
        genome = dict(spec.genes)
        resolved = []

        # Existing demonstration presets remain explicit; reference genes are annotations.
        for cond in spec.conditions:
            d = self.kb.resolve(cond)
            if not d:
                continue
            resolved.append(dict(name=d["name"], kegg=d.get("kegg"), doid=d.get("doid"),
                                 axis=d["axis"], organs=d.get("organs", []),
                                 genes=d.get("genes", [])[:12]))
            pheno = _phenotype_for(cond)
            profile.update(pheno.get("profile", {}))
            for k, v in pheno.get("progression", {}).items():
                progression[k] = max(progression.get(k, 0), v)

        # optional sporadic background load (kept off by default for faithfulness)
        if spec.random_background > 0:
            for g, v in self.kb.variant_catalogue().items():
                frequency = v.get("af")
                if frequency is not None and g not in genome and rng.random() < frequency * spec.random_background:
                    genome[g] = 1

        # lifestyle + environment overrides
        profile.update({k: v for k, v in spec.lifestyle.items() if k in profile})
        env = dict(pollution=0.2, season="summer", stressors=0.2, care_access=0.8, food_security=0.8)
        env.update(spec.environment)
        if "air_pollution" in spec.environment:
            profile["air_pollution"] = spec.environment["air_pollution"]

        h = RealHuman(spec.id, name=spec.name or spec.id, age=spec.age, sex=spec.sex,
                      profile=profile, genome=genome, seed=rng.randint(0, 1 << 30))
        h.progression = progression       # carry disease progression into the twin later
        h.environment = env
        h.reference = dict(built_from="description" if spec.description else "spec",
                           evidence_class="synthetic_demonstration", clinical_validation="NOT_QUALIFIED",
                           phenotype_source="legacy explicit presets; not measured individual baselines",
                           reference_gene_policy="annotations only; no inferred carrier status",
                           description=spec.description, ancestry=spec.ancestry,
                           conditions=resolved, risk_alleles=len(genome),
                           grounded_in=self.kb.summary()["sources"])
        return h


def _phenotype_for(cond):
    c = cond.lower()
    for key, ph in CONDITION_PHENOTYPE.items():
        if key in c or c in key:
            return ph
    return {}


def build_human(spec, kb=None, seed=None):
    return HumanBuilder(kb=kb, seed=seed).build(spec)
