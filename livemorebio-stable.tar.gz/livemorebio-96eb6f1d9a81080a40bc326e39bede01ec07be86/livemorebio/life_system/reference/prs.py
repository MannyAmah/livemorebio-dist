"""
livemore.reference.prs — polygenic risk scores from real GWAS effect sizes.

The calibration layer gives per-locus effect weights (ln OR, from the GWAS
Catalog). This module aggregates them into a standardized per-axis polygenic
score and maps that score onto continuous biomarker offsets — so a person's
baseline LDL / HbA1c / glucose reflect their *whole genotype*, not one flat
per-allele bump.

PRS(axis) = Σ dosageᵢ·βᵢ , standardized by the panel's expected mean and variance
under Hardy-Weinberg (E=Σ2·afᵢ·βᵢ, Var=Σ2·afᵢ(1-afᵢ)·βᵢ²), so a random genotype
scores ~N(0,1). Biomarker offsets use literature-scaled per-SD magnitudes.

Honest scope: βᵢ and afᵢ are real (GWAS Catalog); the PRS→biomarker per-SD
magnitudes are literature-plausible constants, refined by cohort fitting. Somatic
cancer drivers (KRAS/TP53) carry no germline PRS.
"""
from __future__ import annotations
import math
from . import calibration as CAL

_PANEL = {"loaded": False, "axes": {}}

# per-SD biomarker shift for one axis-PRS SD (approx published PRS effect sizes)
_BIOMARKER_SHIFT = {
    "cardiovascular": {"ldl": 13.0, "systolic_bp": 3.0},   # ~13 mg/dL LDL / SD
    "metabolic":      {"hba1c": 0.24, "fasting_glucose": 6.5, "bmi": 0.6},
    "inflammatory":   {"inflammation": 0.05},
}


def _panel():
    """axis -> [(gene, beta=lnOR, af)] built from the calibrated variant catalogue."""
    if not _PANEL["loaded"]:
        from .knowledgebase import KnowledgeBase
        vc = KnowledgeBase().variant_catalogue()
        axes = {}
        for g, v in vc.items():
            info = CAL.info(g)
            if not info or not info.get("or") or info["or"] <= 0:
                continue
            beta = math.log(float(info["or"]))
            af = CAL.risk_af(g)
            # Unknown frequencies cannot be replaced by a population assumption.
            if af is None or not math.isfinite(float(af)) or not 0 < float(af) < 1:
                continue
            for a in v.get("axes", []):
                axes.setdefault(a, []).append((g, beta, float(af)))
        _PANEL["axes"] = axes
        _PANEL["loaded"] = True
    return _PANEL["axes"]


def axis_score(genome, axis):
    """Standardized polygenic z-score for one disease axis (0 = population mean)."""
    loci = _panel().get(axis, [])
    if any(gene not in genome for gene, _beta, _af in loci):
        raise ValueError("a polygenic score requires complete per-locus genotype coverage")
    raw = exp = var = 0.0
    for g, beta, af in loci:
        raw += float(genome.get(g, 0)) * beta
        exp += 2 * af * beta
        var += 2 * af * (1 - af) * beta * beta
    if var <= 0:
        return 0.0
    return (raw - exp) / math.sqrt(var)


def scores(genome):
    """All axis PRS z-scores for a genome."""
    return {a: round(axis_score(genome, a), 3) for a, loci in _panel().items()
            if all(gene in genome for gene, _beta, _af in loci)}


def biomarker_offsets(genome):
    """Continuous biomarker shifts implied by the genome's polygenic scores."""
    out = {}
    for axis, shifts in _BIOMARKER_SHIFT.items():
        if any(gene not in genome for gene, _beta, _af in _panel().get(axis, [])):
            continue
        z = axis_score(genome, axis)
        if not z:
            continue
        for bm, per_sd in shifts.items():
            out[bm] = round(out.get(bm, 0.0) + z * per_sd, 3)
    return out


def panel_summary():
    p = _panel()
    return {a: len(loci) for a, loci in p.items()}


def validate(n=3000, seed=17):
    """Internal validation: sample n random genotypes under HWE and confirm the
    standardization holds (PRS ~ N(0,1)) and that higher metabolic PRS tracks
    higher modelled metabolic burden. NOT clinical/prospective validation."""
    import random
    from .physiology import compute
    rng = random.Random(seed)
    panel = _panel()
    out = {}
    for axis, loci in panel.items():
        zs = []
        for _ in range(n):
            genome = {g: sum(1 for _ in range(2) if rng.random() < af) for g, _b, af in loci}
            zs.append(axis_score(genome, axis))
        mean = sum(zs) / len(zs)
        sd = (sum((z - mean) ** 2 for z in zs) / len(zs)) ** 0.5
        out[axis] = {"n_loci": len(loci), "prs_mean": round(mean, 3), "prs_sd": round(sd, 3)}
    # correlation: metabolic PRS vs modelled diabetes drive across sampled people
    loci = panel.get("metabolic", [])
    xs, ys = [], []
    for _ in range(n):
        genome = {g: sum(1 for _ in range(2) if rng.random() < af) for g, _b, af in loci}
        off = biomarker_offsets(genome)
        prof = dict(hba1c=5.6 + off.get("hba1c", 0), fasting_glucose=95 + off.get("fasting_glucose", 0),
                    bmi=26 + off.get("bmi", 0))
        st = compute(prof, genome, dict(plaque=0.1, beta_mass=0.85, tumor=0.0, senescence=0.15, months=0.0), 50)
        xs.append(axis_score(genome, "metabolic")); ys.append(st["drives"]["diabetes"])
    out["_corr_metabolicPRS_vs_diabetes"] = round(_pearson(xs, ys), 3)
    return out


def _pearson(x, y):
    n = len(x); mx = sum(x) / n; my = sum(y) / n
    cov = sum((a - mx) * (b - my) for a, b in zip(x, y))
    vx = sum((a - mx) ** 2 for a in x) ** 0.5
    vy = sum((b - my) ** 2 for b in y) ** 0.5
    return cov / (vx * vy) if vx and vy else 0.0
