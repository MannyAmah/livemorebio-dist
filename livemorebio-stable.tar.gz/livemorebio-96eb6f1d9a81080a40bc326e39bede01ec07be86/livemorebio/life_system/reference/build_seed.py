"""
Pull a curated but REAL reference slice from the live APIs and bundle it as the
offline seed. Run:  python -m livemore.reference.build_seed
KEGG disease codes are resolved dynamically (find/disease) so nothing is
hardcoded wrong. Re-run any time to expand coverage.
"""
from __future__ import annotations
import json
import os
from .sources import KEGG, Reactome, ProteinAtlas, RCSB, DiseaseOntology, HRA, HCA

SEED = os.path.join(os.path.dirname(__file__), "seed")

DISEASE_NAMES = [
    "type 2 diabetes", "type 1 diabetes", "coronary artery disease", "hypertension",
    "nonalcoholic fatty liver", "chronic obstructive pulmonary", "non-small cell lung cancer",
    "colorectal cancer", "Alzheimer disease", "Parkinson disease", "obesity",
    "rheumatoid arthritis", "asthma", "breast cancer", "melanoma", "heart failure",
    "hypercholesterolemia", "prostate cancer", "osteoporosis", "inflammatory bowel disease",
]
GENES = {  # symbol -> Ensembl (for HPA tissue expression)
    "INS": "ENSG00000254647", "LDLR": "ENSG00000130164", "PCSK9": "ENSG00000169174",
    "APOE": "ENSG00000130203", "TCF7L2": "ENSG00000148737", "PPARG": "ENSG00000132170",
    "TP53": "ENSG00000141510", "KRAS": "ENSG00000133703", "EGFR": "ENSG00000146648",
    "CDKN2A": "ENSG00000147889", "SIRT1": "ENSG00000096717", "IL6": "ENSG00000136244",
    "TNF": "ENSG00000232810", "CRP": "ENSG00000132693", "SLC30A8": "ENSG00000164756",
    "KCNJ11": "ENSG00000187486", "GCK": "ENSG00000106633", "HNF1A": "ENSG00000135100",
    "MC4R": "ENSG00000166603", "FTO": "ENSG00000140718", "BRCA1": "ENSG00000012048",
    "BRCA2": "ENSG00000139618", "APP": "ENSG00000142192", "SNCA": "ENSG00000145335",
    "LEP": "ENSG00000174697", "ADIPOQ": "ENSG00000181092", "NLRP3": "ENSG00000162711",
    "HMGCR": "ENSG00000113161", "AGT": "ENSG00000135744", "ACE": "ENSG00000159640",
}
DRUGS = ["metformin", "atorvastatin", "semaglutide", "lisinopril", "aspirin",
         "imatinib", "empagliflozin", "pioglitazone", "insulin", "warfarin"]
PDB = {"KRAS": "4OBE", "TP53": "1TUP", "EGFR": "1M17", "INS": "4INS", "LDLR": "1N7D"}


def build():
    os.makedirs(SEED, exist_ok=True)
    kegg, react, hpa = KEGG(), Reactome(), ProteinAtlas()
    rcsb, do, hra, hca = RCSB(), DiseaseOntology(), HRA(), HCA()

    print("· diseases (KEGG resolve + detail, DOID)…")
    diseases = []
    for nm in DISEASE_NAMES:
        hits = kegg.find_drug.__self__.fetch(f"find/disease/{nm.replace(' ', '%20')}", parse="text") or ""
        hid = hits.strip().splitlines()[0].split("\t")[0] if hits.strip() else None
        rec = {"query": nm, "kegg": hid}
        if hid:
            d = kegg.disease(hid)
            rec.update(name=d["name"], category=d["category"], description=d["description"][:400],
                       pathways=d["pathways"][:12], genes=[g["symbol"] for g in d["genes"]][:20],
                       gene_hsa={g["symbol"]: g["hsa"] for g in d["genes"][:20]})
        dot = do.search(nm, rows=1)
        rec["doid"] = dot[0]["doid"] if dot else None
        diseases.append(rec)
        print(f"    {nm:38s} {rec.get('kegg')}  {rec.get('doid')}  genes={len(rec.get('genes',[]))}")

    print("· genes (HPA tissue expression + disease involvement)…")
    genes = {}
    for sym, ens in GENES.items():
        g = hpa.gene(ens) or {"symbol": sym, "ensembl": ens}
        g["kegg_pathways"] = []
        genes[sym] = g
        print(f"    {sym:8s} {g.get('rna_tissue_specificity','?')}")

    print("· pathways (Reactome top + KEGG human)…")
    reactome_top = react.top_pathways()
    kegg_paths = {p["id"]: p["name"] for p in kegg.human_pathways()}
    print(f"    reactome_top={len(reactome_top)} kegg_human={len(kegg_paths)}")

    print("· drugs (KEGG resolve + name)…")
    drugs = []
    for nm in DRUGS:
        hits = kegg.find_drug(nm)
        if hits:
            drugs.append(dict(query=nm, kegg=hits[0]["id"], name=hits[0]["name"].split(";")[0]))
    print(f"    resolved {len(drugs)} drugs")

    print("· structures (RCSB PDB)…")
    structures = {sym: rcsb.entry(pid) for sym, pid in PDB.items()}

    print("· anatomy (HRA reference organs) + HCA catalogs…")
    organs = hra.reference_organs()
    hca_info = dict(catalogs=hca.catalogs(), projects=hca.project_count())

    _w("diseases.json", diseases)
    _w("genes.json", genes)
    _w("pathways.json", dict(reactome_top=reactome_top, kegg_human=kegg_paths))
    _w("drugs.json", drugs)
    _w("structures.json", structures)
    _w("anatomy.json", dict(hra_reference_organs=organs, hca=hca_info))
    _w("meta.json", dict(sources=["KEGG", "Reactome", "Human Protein Atlas", "RCSB PDB",
                                  "Disease Ontology (EBI OLS)", "Orphanet (Orphadata)",
                                  "Human Reference Atlas", "Human Cell Atlas"],
                         counts=dict(diseases=len(diseases), genes=len(genes),
                                     reactome_pathways=len(reactome_top), kegg_pathways=len(kegg_paths),
                                     drugs=len(drugs), organs=len(organs))))
    print("\nseed written to", SEED)


def _w(fn, obj):
    json.dump(obj, open(os.path.join(SEED, fn), "w"), indent=1)


if __name__ == "__main__":
    build()
