"""
livemore.realhuman — legacy-named synthetic participant model for LIFE Patch development.

A RealHuman is fully generic: an id, an arbitrary profile (any clinical/lifestyle
keys), an arbitrary genome (any variants), arbitrary registered signals, and a
mutable acute `state`. It wears a LifePatch that samples all its signals and
streams them out (two-way: the console can downlink commands). The physiology
engine derives the host's acute state from its profile so signals are coupled to
the body, but you may override or invent any signal.

This class never represents or ingests a real person. Its generated synthetic
stream is input to a paired modeled twin.
"""
from __future__ import annotations
import random
import time
from . import physiology as phys
from .signals import SignalSpec, SignalContext, default_montage


class RealHuman:
    def __init__(self, id, name="", age=50, sex="F", profile=None, genome=None,
                 signals=None, seed=None):
        self.id = id
        self.name = name or id
        self.age = float(age)
        self.sex = sex
        self.profile = dict(profile or {})
        self.genome = dict(genome or {})
        self.rng = random.Random(seed)
        self.state = {}                      # acute state for signal coupling
        self.signals = {}
        for s in (signals if signals is not None else default_montage()):
            self.signals[s.name] = s
        self.downlinks = []                  # commands received from the console
        self._refresh_state()

    # ---- generic model building --------------------------------------------
    def set(self, key, value):
        """Manipulate any field: profile.key, gene.VID, age, or state.key."""
        if "." in key:
            grp, k = key.split(".", 1)
            if grp == "gene":
                self.genome[k] = int(value); 
            elif grp == "state":
                self.state[k] = float(value)
            else:
                self.profile[k] = value
        elif key == "age":
            self.age = float(value)
        else:
            self.profile[key] = value
        self._refresh_state()
        return self

    def add_signal(self, spec: SignalSpec):
        """Register ANY new signal (the engine is not limited to a montage)."""
        self.signals[spec.name] = spec
        return self

    def _refresh_state(self):
        st = phys.compute(self.profile, self.genome, self.profile, self.age)
        self.state.update(stress=st["drives"]["realtime_stress"] or self.profile.get("stress", 0.3),
                          inflammation=st["inflammation"], lung_risk=st["drives"]["lung_cancer"],
                          activity=self.profile.get("activity_level", 0.4),
                          fed=self.state.get("fed", 0.3))

    # ---- the LIFE Patch device ---------------------------------------------
    def patch_sample(self) -> dict:
        ctx = SignalContext(self)
        ctx.t = time.time()
        # drift fed-state for realism (meal cycles)
        self.state["fed"] = max(0, min(1, self.state.get("fed", 0.3) + self.rng.gauss(0, 0.15)))
        reading = {"human_id": self.id, "device": "LIFE-Patch", "t": round(ctx.t, 2)}
        for name, spec in self.signals.items():
            reading[name] = round(spec.sample(ctx), 3)
        # a derived phase tag from glucose if present
        g = reading.get("glucose_isf")
        if g is not None:
            reading["phase"] = ("postprandial" if g > 160 else "fed" if g > 125 else
                                "fasted" if g > 100 else "autophagy")
        return reading

    def downlink(self, command, **kw):
        """Console -> patch command (two-way). e.g. trigger_sweat_assay."""
        self.downlinks.append({"command": command, "args": kw, "t": time.time()})
        if command == "trigger_sweat_assay":
            self.state["stress"] = min(1.0, self.state.get("stress", 0.3) + 0.05)
        return {"ack": command, "queued": len(self.downlinks)}

    def snapshot(self):
        return dict(id=self.id, name=self.name, age=self.age, sex=self.sex,
                    profile=dict(self.profile), genome=dict(self.genome),
                    signals=list(self.signals), state=dict(self.state))
