"""
livemore.reference.simulator — a synthetic longitudinal signal generator.

A generated host is not a static row: LivingHuman.tick(dt) advances simplified
state on two synthetic timescales. It does not reproduce how a real person's body changes.
  • acute (minutes–hours): circadian rhythm, meals, activity bouts, acute stress
    and environment drive glucose, HR, HRV, cortisol, temperature, metabolic phase;
  • chronic (days–months): disease progression, treatment response, and the slow
    accumulation of lifestyle/nutrition/environment shift the biomarker set-points
    and organ states.
The LIFE Patch samples the acute state every tick; the twin tracks it. Run it in
real time (async) or fast-forward days of physiology in a loop.
"""
from __future__ import annotations
import math
from . import physiology as phys


class Environment:
    def __init__(self, pollution=0.2, stressors=0.2, season="summer", care_access=0.8, food_security=0.8):
        self.pollution = pollution
        self.stressors = stressors
        self.season = season
        self.care_access = care_access
        self.food_security = food_security


class LivingHuman:
    def __init__(self, human, environment=None, meals=(7.5, 12.5, 19.0), clock_hour=7.0):
        self.h = human
        self.env = environment or Environment(**getattr(human, "environment", {}) if isinstance(getattr(human, "environment", {}), dict) else {})
        self.meals = meals
        self.t_hours = clock_hour
        self.days = 0.0
        self.h.state.setdefault("fed", 0.2)

    # ---- one step of life ---------------------------------------------------
    def tick(self, dt_hours=0.5):
        h, env = self.h, self.env
        self.t_hours = (self.t_hours + dt_hours) % 24
        self.days += dt_hours / 24.0
        hod = self.t_hours

        # circadian: cortisol peaks ~8am, temp dips ~4am, activity daytime
        circ_cort = 0.5 + 0.5 * math.cos((hod - 8) / 24 * 2 * math.pi)
        awake = 1.0 if 6.5 <= hod <= 22.5 else 0.0

        # meals -> fed state decays between meals (glucose excursions)
        near_meal = min((abs(hod - m) for m in self.meals), default=6)
        fed = max(0.0, 1.0 - near_meal / 3.0) * env.food_security
        self.h.state["fed"] = round(0.6 * self.h.state.get("fed", 0.2) + 0.4 * fed, 3)

        # activity bouts (daytime, scaled by the person's activity_level)
        act = awake * self.h.profile.get("activity_level", 0.5) * (0.6 + 0.4 * math.sin(hod / 24 * 2 * math.pi))
        self.h.state["activity"] = round(max(0, act), 3)

        # acute stress from environment + circadian + trait
        stress = min(1.0, 0.2 + 0.4 * env.stressors + 0.3 * circ_cort * self.h.profile.get("stress", 0.3))
        self.h.state["stress"] = round(stress, 3)

        # environment feeds inflammation acutely (pollution, season)
        seasonal = 0.05 if env.season in ("winter",) else 0.0
        base_inf = self.h.profile.get("inflammation", 0.3)
        self.h.state["inflammation"] = round(min(1.0, base_inf + 0.15 * env.pollution + seasonal + 0.1 * stress), 3)
        self.h.state["lung_risk"] = phys.compute(self.h.profile, self.h.genome, getattr(self.h, "progression", {}), self.h.age)["drives"]["lung_cancer"]

        # ---- chronic drift (accumulates slowly) ----
        # progression integrates; treatment/lifestyle already sit in profile.
        frac_month = dt_hours / (24 * 30)
        prog = getattr(self.h, "progression", None)
        if prog is not None and frac_month > 0:
            phys.step(self.h.profile, self.h.genome, prog, self.h.age, dt_months=frac_month)
            self.h.age += frac_month / 12.0
        # slow lifestyle/environment accumulation on set-points
        self._chronic_drift(frac_month, env)
        return self.snapshot()

    def _chronic_drift(self, fm, env):
        p = self.h.profile
        # poor nutrition + low activity slowly worsen metabolic markers; good ones improve
        nut, act = p.get("nutrition_quality", 0.6), p.get("activity_level", 0.5)
        drive = (0.5 - nut) + (0.5 - act)                 # >0 worsens
        p["hba1c"] = _b(p.get("hba1c", 5.5) + drive * 4 * fm, 4.4, 13)
        p["fasting_glucose"] = _b(p.get("fasting_glucose", 95) + drive * 120 * fm, 70, 320)
        p["bmi"] = _b(p.get("bmi", 25) + (0.4 - act) * 10 * fm, 16, 55)
        p["ldl"] = _b(p.get("ldl", 120) + (0.5 - nut) * 120 * fm - p.get("compound_strength", 0) * 20 * fm, 40, 320)
        # inflammation set-point relaxes toward a value driven by lifestyle+pollution
        target_inf = 0.15 + 0.3 * (1 - nut) + 0.2 * env.pollution + 0.15 * p.get("smoking_pack_years", 0) / 50
        p["inflammation"] = round(_b(p.get("inflammation", 0.3) + (target_inf - p.get("inflammation", 0.3)) * 6 * fm, 0, 1), 3)

    def snapshot(self):
        return dict(hour=round(self.t_hours, 1), days=round(self.days, 2),
                    fed=self.h.state.get("fed"), activity=self.h.state.get("activity"),
                    stress=self.h.state.get("stress"), inflammation=self.h.state.get("inflammation"),
                    hba1c=round(self.h.profile.get("hba1c", 0), 2), ldl=round(self.h.profile.get("ldl", 0)),
                    bmi=round(self.h.profile.get("bmi", 0), 1))

    def run(self, hours=24, dt_hours=0.5):
        return [self.tick(dt_hours) for _ in range(int(hours / dt_hours))]


def _b(v, lo, hi):
    return max(lo, min(hi, v))
