"""
livemore.physiology — the mechanistic multi-scale engine (the computational
organism). It maps a host's profile (clinical + lifestyle), genome, progression,
and acute realtime signals onto molecular/cellular drivers -> organs -> disease
drives -> biomarkers -> bio-age, and integrates progression over time.

It operates on plain dicts, so it runs for configured digital-twin or synthetic
experimental models. Where an external organ engine is
registered live (MICOM, openCARP, tdFBA, HumMod...), compute() routes that
sub-step to it via the integration registry; otherwise mechanistic stand-ins run.
Not clinically validated; coefficients are reasoned, not cohort-fitted.
"""
from __future__ import annotations
from . import genome as G

ORGANS = ["heart", "vasculature", "lungs", "pancreas", "liver", "gut", "kidneys", "brain", "immune"]
SYSTEM = dict(heart="cardiovascular", vasculature="cardiovascular", lungs="respiratory",
              pancreas="endocrine", liver="digestive", gut="digestive", kidneys="urinary",
              brain="nervous", immune="immune")

CLINICAL_DEFAULTS = dict(bmi=26, ldl=120, hdl=50, hba1c=5.6, fasting_glucose=95,
                         systolic_bp=122, smoking_pack_years=0)
LIFESTYLE_DEFAULTS = dict(inflammation=0.30, microbiome_quality=0.6, nutrition_quality=0.6,
                          activity_level=0.5, sleep_quality=0.6, air_pollution=0.2, alcohol=0.2,
                          medication_adherence=0.7, compound_strength=0.0)
PROGRESSION_DEFAULTS = dict(plaque=0.10, beta_mass=0.85, tumor=0.0, senescence=0.15, months=0.0)


def _c(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def compute(profile, genome, progression, age, realtime=None, integrations=None):
    cl = {**CLINICAL_DEFAULTS, **profile}
    ls = {**LIFESTYLE_DEFAULTS, **profile}
    pr = {**PROGRESSION_DEFAULTS, **progression}
    rt = realtime or {}

    eff_ldl = cl["ldl"] * (1 - G.effect_of(genome, "ldl_clearance"))
    age_load = _c((age - 35) / 45)
    obesity = _c((cl["bmi"] - 24) / 18)
    ldl_load = _c((eff_ldl - 100) / 130)
    a1c = _c((cl["hba1c"] - 5.7) / 4.3)
    glu = _c((cl["fasting_glucose"] - 99) / 160)
    bp = _c((cl["systolic_bp"] - 120) / 70)
    smk = _c(cl["smoking_pack_years"] / 45)

    inflammation = _c(0.50 * ls["inflammation"] + 0.13 * obesity + 0.09 * (1 - ls["sleep_quality"])
                      + 0.09 * (1 - ls["activity_level"]) + 0.08 * ls["air_pollution"]
                      + 0.06 * ls["alcohol"] + 0.10 * (1 - ls["microbiome_quality"]))
    protect = _c(0.30 * ls["medication_adherence"] + 0.22 * ls["activity_level"]
                 + 0.24 * ls["nutrition_quality"] + 0.14 * ls["compound_strength"]
                 + 0.08 * ls["microbiome_quality"] + max(0, G.effect_of(genome, "autophagy")) * 0.3)

    rts = 0.0
    if rt:
        rts = _c(0.25 * ((rt.get("heart_rate", 70) - 70) / 45)
                 + 0.25 * ((55 - rt.get("hrv", 50)) / 55)
                 + 0.2 * ((95 - rt.get("spo2", 97)) / 8)
                 + 0.2 * rt.get("stress_index", rt.get("eda", 0.3)) + 0.1 * rt.get("accel", 0.3))

    scfa, integration_execution = _scfa(ls, integrations)
    drivers = dict(
        ldl_oxidation=_c(ldl_load * (0.5 + inflammation)),
        foam_cell_load=_c(pr["plaque"]),
        insulin_secretion=_c(pr["beta_mass"] * (0.4 + glu) + G.effect_of(genome, "insulin_secretion")),
        insulin_sensitivity=_c(1 - 0.4 * obesity - 0.3 * inflammation + G.effect_of(genome, "insulin_sensitivity")),
        beta_cell_stress=_c(glu * 1.2 - 0.3 * ls["compound_strength"]),
        scfa_flux=scfa, il6_tnf=inflammation, nfkb_tone=_c(inflammation - 0.4 * scfa),
        mtor_ampk_balance=_c(0.5 + 0.4 * glu - 0.3 * ls["activity_level"]),
        autophagy_flux=_c(0.3 + 0.4 * ls["activity_level"] + G.effect_of(genome, "autophagy") - 0.4 * glu),
        p53_checkpoint=_c(1 + G.effect_of(genome, "apoptosis_checkpoint")),
        proliferation=_c(0.2 + G.effect_of(genome, "proliferation") + 0.3 * smk),
        senescence_signal=_c(pr["senescence"] + G.effect_of(genome, "senescence")),
    )

    diabetes = _c(0.42 * a1c + 0.24 * glu + 0.17 * obesity + 0.11 * inflammation - 0.18 * protect
                  + 0.18 * (1 - pr["beta_mass"]) + (1 - drivers["insulin_sensitivity"]) * 0.1)
    athero = _c(0.36 * ldl_load + 0.21 * bp + 0.17 * diabetes + 0.12 * smk + 0.10 * age_load
                - 0.16 * protect + 0.20 * pr["plaque"])
    lung = _c(0.40 * smk + 0.15 * age_load + 0.15 * inflammation + 0.10 * rts
              + 0.18 * drivers["proliferation"] - 0.06 * ls["compound_strength"] + 0.25 * pr["tumor"])
    aging = _c(0.28 * age_load + 0.19 * inflammation + 0.12 * diabetes + 0.11 * athero
               + 0.09 * (1 - ls["sleep_quality"]) + 0.09 * (1 - ls["activity_level"])
               + 0.14 * pr["senescence"] - 0.16 * ls["compound_strength"])

    rk = dict(
        heart=_c(0.50 * athero + 0.18 * bp + 0.16 * diabetes + 0.16 * rts),
        vasculature=_c(0.58 * athero + 0.20 * diabetes + 0.22 * inflammation),
        lungs=_c(0.68 * lung + 0.16 * smk + 0.16 * rts),
        pancreas=_c(0.7 * diabetes + 0.3 * (1 - pr["beta_mass"])),
        liver=_c(0.32 * obesity + 0.25 * diabetes + 0.20 * inflammation + 0.13 * (1 - ls["nutrition_quality"]) + 0.10 * ls["alcohol"]),
        gut=_c(0.30 * inflammation + 0.28 * (1 - ls["nutrition_quality"]) + 0.20 * diabetes + 0.22 * (1 - ls["microbiome_quality"])),
        kidneys=_c(0.34 * diabetes + 0.31 * bp + 0.18 * athero + 0.17 * age_load),
        brain=_c(0.27 * athero + 0.19 * diabetes + 0.20 * aging + 0.18 * (1 - ls["sleep_quality"]) + 0.16 * rts),
        immune=aging,
    )
    organs = {o: dict(name=o, system=SYSTEM[o], risk=round(rk[o], 3)) for o in ORGANS}
    global_risk = _c(0.24 * diabetes + 0.24 * athero + 0.20 * lung + 0.20 * aging + 0.12 * rts)
    bio_age = age + 18 * aging - 7 * protect + pr["months"] / 12
    biomarkers = dict(LDL_mg_dL=round(eff_ldl), HbA1c_percent=round(cl["hba1c"], 1),
                      Fasting_glucose_mg_dL=round(cl["fasting_glucose"]), Systolic_BP_mmHg=round(cl["systolic_bp"]),
                      CRP_mg_L=round(10 * inflammation, 1), ASCVD_plaque_index=round(100 * athero),
                      Senescence_burden=round(100 * aging), SCFA_butyrate_mmol=round(2 + scfa * 6, 1))
    return dict(drivers=drivers, organs=organs, inflammation=round(inflammation, 3),
                drives=dict(diabetes=diabetes, atherosclerosis=athero, lung_cancer=lung, aging=aging,
                            global_risk=global_risk, eff_ldl=eff_ldl, smoking_load=smk, realtime_stress=rts),
                biomarkers=biomarkers, bio_age=round(bio_age, 1), healthspan=round(100 * (1 - global_risk), 1),
                phase=rt.get("phase", "fed"),
                integration_execution={"micom": integration_execution})


def step(profile, genome, progression, age, dt_months=1.0, state=None, integrations=None):
    st = state or compute(profile, genome, progression, age, integrations=integrations)
    cl = {**CLINICAL_DEFAULTS, **profile}; ls = {**LIFESTYLE_DEFAULTS, **profile}
    pr = progression; d = st["drives"]
    ero = 0.020 * max(0, (cl["fasting_glucose"] - 150) / 120) + 0.010 * st["inflammation"]
    res = 0.006 * ls["activity_level"] + 0.006 * ls["medication_adherence"] + 0.004 * ls["compound_strength"]
    pr["beta_mass"] = _c(pr.get("beta_mass", 0.85) - (ero - res) * dt_months, 0.12, 1.0)
    grow = 0.012 * max(0, (d["eff_ldl"] - 100) / 120) * (0.5 + st["inflammation"])
    reg = 0.006 * ls["medication_adherence"] + 0.0015 * ls["compound_strength"]
    pr["plaque"] = _c(pr.get("plaque", 0.1) + (grow - reg) * dt_months)
    if d["smoking_load"] > 0.18 or G.effect_of(genome, "proliferation") > 0.2 or pr.get("tumor", 0) > 1e-3:
        tg = 0.018 * d["smoking_load"] * (0.5 + st["inflammation"]) + 0.010 * G.effect_of(genome, "proliferation")
        ts = 0.012 * st["drivers"]["p53_checkpoint"] * (0.6 + ls["activity_level"]) + 0.008 * ls["compound_strength"]
        pr["tumor"] = _c(pr.get("tumor", 0) + (tg - ts) * dt_months)
    sg = 0.006 * max(0, (age - 40) / 55) + 0.010 * st["inflammation"] + 0.004 * max(0, G.effect_of(genome, "senescence"))
    sc = 0.006 * ls["compound_strength"] + 0.004 * ls["sleep_quality"] + 0.004 * ls["activity_level"]
    pr["senescence"] = _c(pr.get("senescence", 0.15) + (sg - sc) * dt_months)
    pr["months"] = pr.get("months", 0) + dt_months
    return pr


def _scfa(ls, integrations):
    if integrations is not None:
        if hasattr(integrations, "maybe_with_trace"):
            r, trace = integrations.maybe_with_trace(
                "micom",
                microbiome_quality=ls["microbiome_quality"],
                nutrition_quality=ls["nutrition_quality"],
            )
        else:
            r = integrations.maybe(
                "micom",
                microbiome_quality=ls["microbiome_quality"],
                nutrition_quality=ls["nutrition_quality"],
            )
            trace = {
                "schema_version": "livemore.integration-execution.v1",
                "integration": "micom",
                "backend": "unreported",
                "adapter_version": "unreported",
                "model_version": "unreported",
                "solver": "unreported",
                "source_tag": "unreported",
                "failure_class": "none",
            }
        if r is not None:
            return _c(r.get("scfa_flux", 0.5)), trace
    return (
        round(
            _c(
                0.2
                + 0.8
                * ls["microbiome_quality"]
                * (0.4 + 0.6 * ls["nutrition_quality"])
            ),
            6,
        ),
        {
            "schema_version": "livemore.integration-execution.v1",
            "integration": "micom",
            "backend": "fallback",
            "adapter_version": "unavailable",
            "model_version": "livemore-mechanistic-scfa-v1",
            "solver": "none",
            "source_tag": "livemore-mechanistic-scfa",
            "failure_class": "none",
        },
    )
