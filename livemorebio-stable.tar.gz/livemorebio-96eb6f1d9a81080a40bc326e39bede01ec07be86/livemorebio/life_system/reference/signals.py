"""
livemore.signals — the generic signal engine. NOTHING is predefined.

A SignalSpec binds a name + unit to a generator function generator(ctx)->float,
where ctx exposes the host model's profile/genome/state. You can register ANY
signal (a wearable channel, a lab biomarker, a sweat metabolite, an imaging-
derived index, or an invented marker) on a host record or model, and it immediately
flows through the LIFE Patch stream, the bus, the console, and Jupyter.

A small library of ready-made generators is provided for convenience, but they
are just examples — `host.add_signal(SignalSpec(...))` accepts any callable.
"""
from __future__ import annotations
import math
import random
from dataclasses import dataclass
from typing import Callable


@dataclass
class SignalSpec:
    name: str
    unit: str = ""
    generator: Callable = None          # fn(ctx) -> float
    kind: str = "continuous"            # continuous | event | lab | imaging
    hz: float = 1.0                     # nominal sampling rate
    meta: dict = None

    def sample(self, ctx) -> float:
        v = self.generator(ctx) if self.generator else 0.0
        return v


class SignalContext:
    """Passed to generators: read profile/genome/state + a per-host RNG + clock."""
    def __init__(self, host):
        self.host = host
        self.rng = host.rng
        self.t = 0.0

    def p(self, key, default=0.0):
        return self.host.profile.get(key, default)

    def gene(self, vid):
        return self.host.genome.get(vid, 0) if hasattr(self.host, "genome") else 0

    def state(self, key, default=0.0):
        return getattr(self.host, "state", {}).get(key, default)


# ---- a library of example generators (extend or ignore freely) -------------
def gen_const(value, noise=0.0):
    return lambda c: value + (c.rng.gauss(0, noise) if noise else 0)

def gen_heart_rate(c):
    base = 62 + 26 * c.state("stress", c.p("stress", 0.3)) + 10 * c.state("activity", 0.3)
    return max(42, c.rng.gauss(base, 3))

def gen_hrv(c):
    return max(8, c.rng.gauss(58 - 34 * c.state("stress", c.p("stress", 0.3)), 6))

def gen_spo2(c):
    return max(85, min(100, c.rng.gauss(98 - 4 * c.state("lung_risk", 0.1), 0.8)))

def gen_glucose_isf(c):
    base = c.p("fasting_glucose", 95) * 0.95 + 22 * c.state("fed", 0.3)
    return max(60, c.rng.gauss(base, 12))

def gen_cortisol_sweat(c):
    return max(0, c.rng.gauss(8 + 18 * c.state("stress", c.p("stress", 0.3)), 2))

def gen_skin_temp(c):
    return round(c.rng.gauss(36.5 + 0.4 * c.state("inflammation", 0.3), 0.12), 2)

def gen_eda(c):
    return max(0, c.rng.gauss(0.3 + 0.5 * c.state("stress", 0.3), 0.06))

def gen_accel(c):
    return max(0, c.rng.gauss(c.state("activity", c.p("activity", 0.3)), 0.15))

def gen_respiration(c):
    return max(8, c.rng.gauss(14 + 5 * c.state("inflammation", 0.3), 1.0))

def gen_bp_systolic(c):
    return max(90, c.rng.gauss(c.p("systolic_bp", 120) + 12 * c.state("stress", 0.3), 4))

# a sensible default LIFE Patch montage — you can replace ANY of these
def default_montage():
    return [
        SignalSpec("heart_rate", "bpm", gen_heart_rate),
        SignalSpec("hrv", "ms", gen_hrv),
        SignalSpec("spo2", "%", gen_spo2),
        SignalSpec("respiratory_rate", "/min", gen_respiration),
        SignalSpec("skin_temp_c", "°C", gen_skin_temp),
        SignalSpec("eda", "µS", gen_eda),
        SignalSpec("accel", "g", gen_accel),
        SignalSpec("bp_systolic", "mmHg", gen_bp_systolic),
        SignalSpec("glucose_isf", "mg/dL", gen_glucose_isf, kind="lab", hz=0.2),
        SignalSpec("cortisol_sweat", "nmol/L", gen_cortisol_sweat, kind="lab", hz=0.1),
    ]
