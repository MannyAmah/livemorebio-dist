"""
livemore.reference.calibration — GWAS-Catalog effect-size weights.

The knowledgebase says which genes a disease involves (real, from KEGG/DO). This
module supplies the published per-allele effect magnitude (odds ratio → weight)
so the physiology effect sizes are GWAS-calibrated instead of flat heuristics.

Weights are bundled (seed/gwas.json, fetched from the GWAS Catalog) and can be
refreshed live via `python -m livemore.reference.build_seed` /
`livemore.reference.sources.gwas`. Genes without a GWAS lead SNP (e.g. somatic
cancer drivers KRAS/TP53/EGFR) keep weight 1.0 — mechanistic, not GWAS-fitted.
"""
from __future__ import annotations
import json
import os

_SEED = os.path.join(os.path.dirname(__file__), "seed", "gwas.json")
_CACHE = {"loaded": False, "effects": {}}


def _load():
    if _CACHE["loaded"]:
        return _CACHE["effects"]
    try:
        with open(_SEED) as f:
            _CACHE["effects"] = json.load(f).get("effects", {})
    except Exception:
        _CACHE["effects"] = {}
    _CACHE["loaded"] = True
    return _CACHE["effects"]


def weight(gene, default=1.0):
    """GWAS-derived effect multiplier for a gene (OR 1.30 → ~1.0). default if unknown."""
    e = _load().get(gene)
    if e and e.get("weight"):
        return float(e["weight"])
    return default


def risk_af(gene):
    """Real risk-allele frequency from the GWAS lead SNP, or None."""
    e = _load().get(gene)
    if e and e.get("risk_af") is not None:
        return float(e["risk_af"])
    return None


def info(gene):
    """Provenance: {rsid, or, weight, allele} for a gene, or None."""
    return _load().get(gene)


def summary():
    e = _load()
    return {"calibrated_genes": len(e), "source": "GWAS Catalog (EBI)",
            "reference_or": 1.30, "example": next(iter(e.items()), None)}
