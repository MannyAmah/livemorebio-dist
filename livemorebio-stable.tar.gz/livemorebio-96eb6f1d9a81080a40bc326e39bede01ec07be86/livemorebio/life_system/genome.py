"""
livemore.genome — genetic substrate. Variants carry mechanistic effect weights.
The catalogue is a starting library; you can register arbitrary variants at
runtime (genome.define(...)) so the engine is not limited to a fixed gene set.
"""
from __future__ import annotations
import random

VARIANTS = {
    "LDLR_loss":   dict(gene="LDLR",   af=0.02, effect=dict(ldl_clearance=-0.45)),
    "PCSK9_gain":  dict(gene="PCSK9",  af=0.03, effect=dict(ldl_clearance=-0.30)),
    "APOE4":       dict(gene="APOE",   af=0.14, effect=dict(ldl_clearance=-0.12, neuro_risk=0.15, senescence=0.10)),
    "TCF7L2":      dict(gene="TCF7L2", af=0.28, effect=dict(insulin_secretion=-0.12)),
    "PPARG_loss":  dict(gene="PPARG",  af=0.10, effect=dict(insulin_sensitivity=-0.15)),
    "TP53_mut":    dict(gene="TP53",   af=0.01, effect=dict(apoptosis_checkpoint=-0.70)),
    "KRAS_mut":    dict(gene="KRAS",   af=0.01, effect=dict(proliferation=0.50)),
    "EGFR_mut":    dict(gene="EGFR",   af=0.02, effect=dict(proliferation=0.40)),
    "CDKN2A_loss": dict(gene="CDKN2A", af=0.03, effect=dict(senescence=0.35, apoptosis_checkpoint=-0.30)),
    "SIRT1_high":  dict(gene="SIRT1",  af=0.15, effect=dict(autophagy=0.30, senescence=-0.30)),
    # --- pharmacogenomic variants: no disease-driver effect, but gate DRUG response ---
    "SLC22A1_lof": dict(gene="SLC22A1", af=0.22, effect=dict()),   # OCT1 reduced fn — gates metformin uptake
    "SLCO1B1_lof": dict(gene="SLCO1B1", af=0.15, effect=dict()),   # gates statin uptake / myopathy risk
}


def define(vid, gene, effect, af=0.05):
    """Register a brand-new variant at runtime (generic engine)."""
    VARIANTS[vid] = dict(gene=gene, af=af, effect=dict(effect))


def effect_of(genome: dict, key: str) -> float:
    total = 0.0
    for vid, dose in genome.items():
        if dose and vid in VARIANTS:
            total += VARIANTS[vid]["effect"].get(key, 0.0) * (dose / 2.0 + 0.5)
    return total


def random_genome(rng=None, force=None):
    rng = rng or random.Random()
    g = {}
    for vid, m in VARIANTS.items():
        d = sum(1 for _ in range(2) if rng.random() < m["af"])
        if d:
            g[vid] = d
    if force:
        g.update(force)
    return g
