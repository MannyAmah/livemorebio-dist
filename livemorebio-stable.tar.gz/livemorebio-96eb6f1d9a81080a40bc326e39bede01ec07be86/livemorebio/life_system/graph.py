"""
livemorebio.life_system.graph — the knowledge substrate as a property graph.

Builds a networkx graph of the real biology (Gene ↔ Disease ↔ Pathway ↔ Organ ↔
Drug) that is queryable in-process NOW, and can be exported/loaded into Neo4j when
a server is stood up. Nodes: "Kind:Name". Edges carry a `rel` type.
"""
from __future__ import annotations
import networkx as nx
from .knowledge import KnowledgeBase, get_kb, _name_of, _genes_of

# well-known indications for the seed drugs (curated; not fabricated from the seed)
DRUG_INDICATION = {
    "metformin": "type 2 diabetes", "insulin": "type 2 diabetes",
    "atorvastatin": "coronary artery disease", "simvastatin": "coronary artery disease",
    "aspirin": "coronary artery disease",
}


def _nid(kind, name):
    return f"{kind}:{name}"


class KnowledgeGraph:
    def __init__(self, kb: KnowledgeBase = None):
        self.kb = kb or get_kb()
        self.g = nx.Graph()
        self._build()

    def _add(self, kind, name, **attrs):
        nid = _nid(kind, name)
        if nid not in self.g:
            self.g.add_node(nid, kind=kind, name=name, **attrs)
        elif attrs:
            self.g.nodes[nid].update(attrs)
        return nid

    def _build(self):
        kb = self.kb
        for d in kb.diseases:
            dn = _name_of(d)
            dnode = self._add("Disease", dn, axis=d.get("axis"), doid=d.get("doid", ""))
            for organ in d.get("organs", []):
                self.g.add_edge(dnode, self._add("Organ", organ), rel="AFFECTS_ORGAN")
            for g in _genes_of(d):
                self.g.add_edge(self._add("Gene", g), dnode, rel="ASSOCIATED_WITH")
        for sym, meta in kb.genes.items():
            gnode = self._add("Gene", sym, ensembl=(meta or {}).get("ensembl", ""))
            for pw in (meta or {}).get("kegg_pathways", []) or []:
                pwname = pw if isinstance(pw, str) else (pw.get("name") or pw.get("id"))
                if pwname:
                    self.g.add_edge(gnode, self._add("Pathway", pwname, source="KEGG"), rel="IN_PATHWAY")
        for pw in kb.pathways.get("reactome_top", []):
            self._add("Pathway", pw["name"], source="Reactome", pid=pw["id"])
        for drug in kb.drugs:
            q = (drug.get("query") or drug.get("name", "")).lower().split()[0]
            dnode = self._add("Drug", drug.get("query") or drug.get("name"), kegg=drug.get("kegg", ""))
            ind = DRUG_INDICATION.get(q)
            if ind:
                self.g.add_edge(dnode, self._add("Disease", ind), rel="TREATS")

    # ---- queries -----------------------------------------------------------
    def stats(self):
        kinds = {}
        for _, k in self.g.nodes(data="kind"):
            kinds[k] = kinds.get(k, 0) + 1
        return {"nodes": self.g.number_of_nodes(), "edges": self.g.number_of_edges(), "by_kind": kinds}

    def neighbors(self, kind, name, of_kind=None):
        nid = _nid(kind, name)
        if nid not in self.g:
            return []
        out = []
        for nb in self.g.neighbors(nid):
            nd = self.g.nodes[nb]
            if of_kind is None or nd["kind"] == of_kind:
                out.append((nd["kind"], nd["name"], self.g.edges[nid, nb].get("rel")))
        return out

    def subgraph_for(self, kind, name, radius=1):
        nid = _nid(kind, name)
        if nid not in self.g:
            return nx.Graph()
        nodes = nx.ego_graph(self.g, nid, radius=radius)
        return nodes

    def path(self, kind_a, name_a, kind_b, name_b):
        a, b = _nid(kind_a, name_a), _nid(kind_b, name_b)
        if a not in self.g or b not in self.g:
            return None
        try:
            return nx.shortest_path(self.g, a, b)
        except nx.NetworkXNoPath:
            return None

    # ---- Neo4j production adapter -----------------------------------------
    def export_cypher(self):
        """Cypher MERGE statements to load this graph into Neo4j."""
        lines = []
        for nid, nd in self.g.nodes(data=True):
            props = ", ".join(f'{k}:"{str(v)}"' for k, v in nd.items() if k != "kind" and v != "")
            lines.append(f'MERGE (n:{nd["kind"]} {{name:"{nd["name"]}"{", " + props if props else ""}}});')
        for a, b, rel in self.g.edges(data="rel"):
            na, nb = self.g.nodes[a], self.g.nodes[b]
            lines.append(f'MATCH (a:{na["kind"]} {{name:"{na["name"]}"}}), '
                         f'(b:{nb["kind"]} {{name:"{nb["name"]}"}}) MERGE (a)-[:{rel}]->(b);')
        return lines

    def load_neo4j(self, uri=None, user=None, password=None, database=None):
        """Load with parameterized writes; credentials must be explicit or environment-backed."""
        import os
        from ..scientific_sources.graph_backends import Neo4jBackend

        backend = Neo4jBackend(
            uri=uri or os.environ.get("NEO4J_URI", ""),
            username=user or os.environ.get("NEO4J_USERNAME", ""),
            password=password or os.environ.get("NEO4J_PASSWORD", ""),
            database=database or os.environ.get("NEO4J_DATABASE") or None,
        )
        try:
            return backend.sync(self.g)
        except (OSError, RuntimeError) as error:
            raise RuntimeError(
                f"Neo4j backend unavailable at the configured URI ({type(error).__name__})"
            ) from error
