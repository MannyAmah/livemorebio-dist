"""
livemorebio.life_system.extract — clinical text → grounded Synthetic Human.

ClinicalExtractor uses the substrate's OWN real vocabulary (disease names, gene
symbols, drug names) to pull entities out of a clinical note and instantiate a
biologically-grounded SyntheticHuman. Runnable now, no ML download. OpenMedNER is
the optional local OpenMed intake path. PHI-like text is de-identified locally
before entity analysis and never falls back to the unqualified extractor.
"""
from __future__ import annotations
import re
from .knowledge import KnowledgeBase, get_kb, _name_of
from .synthetic_human import SyntheticHuman
from . import genome as G


class ClinicalExtractor:
    def __init__(self, kb: KnowledgeBase = None):
        self.kb = kb or get_kb()
        self.disease_terms = {}
        for d in self.kb.diseases:
            nm = _name_of(d)
            self.disease_terms[nm.lower()] = nm
            for alias in self._aliases(nm):
                self.disease_terms[alias] = nm
        self.gene_syms = {g.upper() for g in self.kb.genes if g} | {v for v in self.kb.variants if v}
        self.drug_terms = {(dr.get("query") or dr.get("name", "")).lower():
                           (dr.get("query") or dr.get("name")) for dr in self.kb.drugs}

    @staticmethod
    def _aliases(nm):
        n = nm.lower(); al = set()
        if "type 2 diabetes" in n or "type ii diabetes" in n:
            al |= {"t2dm", "t2d", "type 2 diabetes", "type ii diabetes", "diabetes mellitus type 2"}
        if "coronary" in n:
            al |= {"cad", "coronary artery disease", "coronary heart disease"}
        if "alzheimer" in n:
            al |= {"ad", "alzheimers", "alzheimer disease", "alzheimer's disease"}
        if "hypertension" in n:
            al |= {"htn", "high blood pressure"}
        return al

    def extract(self, text):
        low = " " + text.lower() + " "
        conds = []
        for term, nm in self.disease_terms.items():
            if re.search(r"\b" + re.escape(term) + r"\b", low) and nm not in conds:
                conds.append(nm)
        genes = sorted({g for g in self.gene_syms if re.search(r"\b" + re.escape(g) + r"\b", text)})
        drugs = sorted({nm for term, nm in self.drug_terms.items()
                        if re.search(r"\b" + re.escape(term) + r"\b", low)})
        m = re.search(r"\b(\d{1,3})\s*(?:yo|y/o|year[- ]?old|yr)", low) or re.search(r"\bage[:\s]+(\d{1,3})", low)
        age = int(m.group(1)) if m else None
        if re.search(r"\b(female|woman|girl)\b", low):
            sex = "F"
        elif re.search(r"\b(male|man|boy)\b", low):
            sex = "M"
        else:
            # clinical shorthand: age-adjacent M/F ("47 yo M", "58 y/o F", "47M") or "sex: M"
            ms = (re.search(r"\b\d{1,3}\s*(?:yo|y/o|y\.o\.|year[s]?[- ]?old|yr)?\s*[/,\- ]?\s*(m|f)\b", low)
                  or re.search(r"\bsex\s*[:=]?\s*(m|f)\b", low))
            sex = ms.group(1).upper() if ms else "F"
        return {"conditions": conds, "genes": genes, "drugs": drugs, "age": age, "sex": sex}

    def to_synthetic_human(self, text, hid="LMB-NOTE"):
        ex = self.extract(text)
        genome = {g: 1 for g in ex["genes"] if g in G.VARIANTS}
        h = SyntheticHuman(id=hid, age=ex["age"] or 50, sex=ex["sex"],
                           conditions=ex["conditions"], genome=genome)
        return h, ex


class OpenMedNER:
    """Local clinical intake through OpenMed's public Python API.

    ``client`` is injectable for air-gapped deployments and deterministic tests;
    otherwise the installed ``openmed`` package is imported lazily. This class is
    an intake adapter, not an executable-biology engine.
    """
    def __init__(self, model="disease_detection_superclinical", kb=None, client=None):
        self.model = model
        self.kb = kb or get_kb()
        self._client = client
        self._fallback = ClinicalExtractor(self.kb)

    @staticmethod
    def available():
        import importlib.util as u
        return bool(u.find_spec("openmed"))

    def client(self):
        if self._client is None:
            if not self.available():
                raise RuntimeError(
                    "OpenMed is not installed; install `openmed[hf]` and local model artifacts"
                )
            import openmed
            self._client = openmed
        return self._client

    def extract(self, text, *, contains_phi=False):
        if self._client is None and not self.available():
            if contains_phi:
                raise RuntimeError(
                    "PHI-like clinical intake requires operational local OpenMed de-identification"
                )
            return {"backend": "substrate-fallback", **self._fallback.extract(text)}
        client = self.client()
        analysis_text = text
        deidentified = False
        if contains_phi:
            deidentified_result = client.deidentify(text, method="mask")
            analysis_text = deidentified_result.deidentified_text
            deidentified = True
        result = client.analyze_text(analysis_text, model_name=self.model)
        entities = []
        for entity in result.entities:
            entities.append({
                "label": entity.label,
                "text": entity.text,
                "confidence": float(entity.confidence),
                "start": int(entity.start),
                "end": int(entity.end),
            })
        return {
            "backend": "openmed-local",
            "model": self.model,
            "deidentified": deidentified,
            "entities": entities,
        }
