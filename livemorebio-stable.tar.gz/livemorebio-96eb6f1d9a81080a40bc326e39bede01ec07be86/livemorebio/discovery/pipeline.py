"""
livemore.discovery.pipeline — the plant-compound discovery engine (Cendos flagship).

Breaks a plant into its real constituent compounds, resolves each against PubChem
(identity) and ChEMBL (drug-likeness/phase), predicts targets/pathways, matches
them to an Aegle disease module via the reference knowledgebase, scores leads, and
emits a hypothesis for the Aegle→Cendos loop. Grounds the multi-compound-formulation
thesis: not "moringa may help diabetes" but "these constituents hit these pathways
in this disease, prioritised, testable."
"""
from __future__ import annotations
from .sources import PubChem, ChEMBL
from ..life_system.reference.knowledgebase import KnowledgeBase, AXIS_EFFECT

# real constituent phytochemistry (literature-curated) + known target pathways.
PHYTO = {
    "moringa": [("quercetin", ["AMPK", "NF-kB", "insulin_signaling"], "metabolic"),
                ("kaempferol", ["NF-kB", "PPAR"], "inflammatory"),
                ("chlorogenic acid", ["glucose_absorption", "AMPK"], "metabolic"),
                ("beta-sitosterol", ["cholesterol_absorption"], "cardiovascular"),
                ("moringin", ["NF-kB", "Nrf2"], "inflammatory")],
    "bitter kola": [("kolaviron", ["Nrf2", "NF-kB", "oxidative_stress"], "inflammatory"),
                    ("quercetin", ["AMPK", "insulin_signaling"], "metabolic"),
                    ("epicatechin", ["eNOS", "vascular_function"], "cardiovascular")],
    "berberine plant": [("berberine", ["AMPK", "insulin_signaling", "gut_microbiome"], "metabolic")],
    "turmeric": [("curcumin", ["NF-kB", "STAT3", "Nrf2"], "inflammatory"),
                 ("curcumin", ["proliferation", "apoptosis"], "oncologic")],
}
# target family -> engine driver it modulates (for twin-level effect prediction)
TARGET_DRIVER = {
    "AMPK": "insulin_sensitivity", "insulin_signaling": "insulin_secretion",
    "glucose_absorption": "insulin_sensitivity", "PPAR": "insulin_sensitivity",
    "cholesterol_absorption": "ldl_clearance", "eNOS": "ldl_clearance",
    "vascular_function": "ldl_clearance", "NF-kB": "senescence", "Nrf2": "autophagy",
    "oxidative_stress": "senescence", "STAT3": "proliferation", "proliferation": "proliferation",
    "apoptosis": "apoptosis_checkpoint", "gut_microbiome": "insulin_sensitivity",
}


class DiscoveryEngine:
    def __init__(self, kb=None, online=True):
        self.kb = kb or KnowledgeBase()
        self.pc = PubChem(offline=not online)
        self.chembl = ChEMBL(offline=not online)

    def resolve_compound(self, name):
        """Real chemical identity + drug-likeness."""
        rec = {"name": name}
        pc = self.pc.compound(name)
        if pc:
            rec.update(cid=pc["cid"], formula=pc["formula"], mw=pc["mw"],
                       smiles=pc["smiles"], inchikey=pc["inchikey"])
        ch = self.chembl.molecule(name)
        if ch:
            rec.update(chembl_id=ch["chembl_id"], max_phase=ch["max_phase"], qed=ch.get("qed"))
        return rec

    def screen(self, plant, disease_axis="metabolic"):
        """Full pipeline: plant → compounds → targets → pathway/disease match → leads."""
        constituents = PHYTO.get(plant.lower(), [])
        leads = []
        for name, targets, axis in constituents:
            cid = self.resolve_compound(name)
            axis_match = 1.0 if axis == disease_axis else 0.3
            drivers = sorted({TARGET_DRIVER.get(t) for t in targets if TARGET_DRIVER.get(t)})
            # lead score: axis match × druggability(max_phase) × multi-target breadth
            phase = float(cid.get("max_phase") or 0) / 4.0
            score = round(axis_match * (0.5 + 0.5 * phase) * min(1.0, 0.4 + 0.2 * len(targets)), 3)
            leads.append(dict(compound=name, cid=cid.get("cid"), formula=cid.get("formula"),
                              chembl_id=cid.get("chembl_id"), max_phase=cid.get("max_phase"),
                              targets=targets, drivers=drivers, axis=axis,
                              lead_score=score))
        leads.sort(key=lambda x: -x["lead_score"])
        return dict(plant=plant, disease_axis=disease_axis, n_compounds=len(leads), leads=leads)

    def formulation_effect(self, plant, disease_axis="metabolic"):
        """Predict the multi-compound formulation's net driver modulation for the twin."""
        s = self.screen(plant, disease_axis)
        eff = {}
        for lead in s["leads"]:
            w = lead["lead_score"]
            for d in lead["drivers"]:
                # beneficial direction: reduce risk drivers
                sign = -1 if d in ("insulin_secretion", "insulin_sensitivity", "ldl_clearance") else -0.5
                eff[d] = round(eff.get(d, 0.0) + sign * 0.04 * w, 4)
        return dict(plant=plant, axis=disease_axis, net_driver_effect=eff, screen=s)

    def to_aegle_hypothesis(self, plant, twin_id, disease_module="metabolic"):
        """Emit an Aegle→Cendos hypothesis payload from the top leads."""
        s = self.screen(plant, disease_module)
        top = s["leads"][:3]
        pathways = sorted({t for l in top for t in l["targets"]})
        return dict(twin_id=twin_id, disease_module=disease_module,
                    hypothesis=f"multi-compound {plant} formulation may modulate {disease_module} via {', '.join(pathways[:4])}",
                    target_pathways=pathways, candidate_compounds=[l["compound"] for l in top],
                    recommended_model=f"{disease_module}_organoid",
                    recommended_assays=["viability", "pathway_reporter", "cytokine_panel"], priority="high")
