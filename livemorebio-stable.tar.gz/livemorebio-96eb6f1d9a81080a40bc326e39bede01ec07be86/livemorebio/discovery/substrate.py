"""Plant-medicine druggability substrate.

Merged from the Plant Medicine Drug Discovery Package (audit §5,
component 4). Loads the 193 machine-readable druggability profiles with
their E0–E9 evidence scale, scoring rubric, safety-flag register, and
monograph inventory. Every claim in a profile is labelled by evidence
class — book claims are hypotheses only, never treated as efficacy.

This substrate feeds the DiscoveryEngine (``pipeline.py``) and Cendos
assay design: profiles supply graded, referenced compound hypotheses;
PubChem/ChEMBL resolution supplies real chemical identity; the twin
supplies mechanistic context. The substrate itself asserts nothing it
cannot cite.
"""
from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Optional

_DATA = Path(__file__).resolve().parent / "data"
PROFILES_PATH = _DATA / "All_193_Druggability_Profiles.json"
SAFETY_PATH = _DATA / "Complete_Safety_Flag_Register.csv"
INVENTORY_PATH = _DATA / "Complete_Book_Monograph_Inventory.csv"

PRIORITY_TIERS = ("P1", "P2", "P3", "P4", "P5")


@dataclass(frozen=True)
class PlantSubstrate:
    """Indexed, read-only view over the plant druggability dataset."""

    meta: Mapping[str, Any]
    evidence_scale: Mapping[str, str]
    scoring_rubric: Mapping[str, Any]
    profiles: tuple
    by_id: Mapping[str, Mapping[str, Any]]
    safety_flags: tuple

    def __len__(self) -> int:
        return len(self.profiles)

    def profile(self, record_id: str) -> Mapping[str, Any]:
        try:
            return self.by_id[record_id]
        except KeyError:
            raise KeyError(f"unknown record_id: {record_id!r}") from None

    def by_name(self, name: str) -> Optional[Mapping[str, Any]]:
        needle = name.strip().lower()
        for p in self.profiles:
            if p["entry_name"].lower() == needle or needle in p.get(
                "taxon_as_printed", ""
            ).lower():
                return p
        return None

    def grade_of(self, record_id: str) -> str:
        """Whole-botanical evidence level (E0–E9) for a record."""
        return self.profile(record_id)["whole_evidence_level"]

    def tiered(self, tier: str) -> list[Mapping[str, Any]]:
        return [p for p in self.profiles if p.get("priority_tier") == tier]

    def search_targets(self, term: str) -> list[Mapping[str, Any]]:
        """Profiles whose stated targets/pathways mention *term*."""
        needle = term.strip().lower()
        hits = []
        for p in self.profiles:
            for t in p.get("known_or_hypothesized_molecular_targets_or_pathways", []):
                statement = t.get("target_or_pathway_statement", "")
                if needle in statement.lower():
                    hits.append(p)
                    break
        return hits

    def safety_for(self, record_id: str) -> list[Mapping[str, str]]:
        return [f for f in self.safety_flags if f.get("record_id") == record_id]

    def hard_stops(self) -> list[Mapping[str, Any]]:
        """Profiles whose whole-botanical route is safety-blocked."""
        return [p for p in self.profiles if p.get("whole_route_hard_stop")]

    def candidates_for_cendos(
        self, min_scaffold_score: int = 60, exclude_hard_stops: bool = True
    ) -> list[Mapping[str, Any]]:
        """Graded shortlist for Cendos assay design.

        Ranks by isolated-compound scaffold potential (the pharma-relevant
        axis), keeps the safety gate visible, and never silently drops the
        evidence level.
        """
        out = []
        for p in self.profiles:
            score = p.get("isolated_compound_scaffold_potential_score_0_100") or 0
            if score < min_scaffold_score:
                continue
            if exclude_hard_stops and p.get("whole_route_hard_stop"):
                continue
            out.append(p)
        out.sort(
            key=lambda p: p.get("isolated_compound_scaffold_potential_score_0_100") or 0,
            reverse=True,
        )
        return out


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def load_substrate(path: Optional[Path] = None) -> PlantSubstrate:
    doc = json.loads((path or PROFILES_PATH).read_text(encoding="utf-8"))
    profiles = tuple(doc["profiles"])
    if doc.get("record_count") != len(profiles):
        raise ValueError(
            f"profile count mismatch: manifest says {doc.get('record_count')}, "
            f"file has {len(profiles)}"
        )
    by_id = {p["record_id"]: p for p in profiles}
    if len(by_id) != len(profiles):
        raise ValueError("duplicate record_ids in druggability profiles")

    safety: Iterable[dict[str, str]] = ()
    if SAFETY_PATH.exists():
        safety = _read_csv(SAFETY_PATH)

    meta = {
        k: doc[k]
        for k in ("title", "version", "date", "record_count", "interpretation_warning")
        if k in doc
    }
    return PlantSubstrate(
        meta=meta,
        evidence_scale=doc["evidence_scale"],
        scoring_rubric=doc.get("scoring_rubric", {}),
        profiles=profiles,
        by_id=by_id,
        safety_flags=tuple(safety),
    )
