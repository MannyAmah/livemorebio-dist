# Scientific Framework for Medicinal-Plant and Natural-Product Combinations

**Scope:** A research and development framework for testing mixtures drawn from *The Lost Book of Herbal Remedies* (2019) and related medicinal-plant inventories. It covers plant-plant, extract-extract, fraction-fraction, extract-compound, and purified-compound combinations.

**Status:** Research framework, not clinical advice. The illustrative combinations in Section 14 are hypotheses for laboratory testing. They are not treatments, recipes, doses, or recommendations for human use. A traditional-use claim, an in-silico prediction, an antioxidant assay, or a synergistic cell-culture result is not evidence that a product treats or cures disease in people.

**Book-specific observation:** The attached book contains well over 150 named plants, mushrooms, and lichens plus household remedies. It also includes clearly hazardous taxa (for example, *Datura stramonium*, *Hyoscyamus niger*, *Veratrum viride*, *Gelsemium sempervirens*, and pyrrolizidine-alkaloid-containing plants). These should not enter ordinary whole-extract combination screening. A toxic plant may still contain a useful chemical scaffold, but that is an isolated-lead medicinal-chemistry program with containment and toxicology—not an herbal mixture program.

---

## 1. Central scientific rule

Do not ask only, “Are A and B synergistic?” Ask five separate questions:

1. **Combination activity:** Does A+B produce a larger or qualitatively better disease-relevant effect than A or B alone?
2. **Reference-model interaction:** Is the effect greater than the prespecified non-interaction expectation (Bliss, Loewe, HSA, ZIP, or another appropriate model)?
3. **Dose sparing or efficacy gain:** Does the pair lower the dose needed for a useful effect, increase maximum effect, delay resistance, or reduce toxicity?
4. **Exposure feasibility:** Can the active constituents reach the interacting concentrations, in the required ratio and sequence, at the target tissue?
5. **Net benefit-risk:** Is efficacy interaction favorable without a larger interaction in hepatotoxicity, cardiotoxicity, bleeding, sedation, immunotoxicity, genotoxicity, or drug-drug interaction risk?

“Synergy” answers only Question 2. A combination can score as synergistic while remaining weak, toxic, unachievable in vivo, irreproducible, or unnecessary. Conversely, an additive combination may be clinically valuable if it prevents resistance or permits lower toxicity.

## 2. Define what is being developed before screening

Select one product archetype at the start; changing it later changes the chemistry, pharmacology, CMC, and regulatory program.

| Product archetype | Unit being developed | Strength | Principal difficulty |
|---|---|---|---|
| Standardized multi-botanical drug | Two or more reproducibly manufactured extracts in a fixed ratio | Preserves emergent mixture effects | High chemical complexity and batch control burden |
| Single-botanical complex drug | One plant extract containing interacting constituents | Can retain natural intraplant synergy | Active contributors and acceptable fingerprint must be established |
| Enriched fractions | Defined chemical classes from one or more plants | Lower complexity, retains some mixture biology | Fraction boundaries and composition can drift at scale |
| Purified natural products | Chemically defined molecules | Conventional PK, target, dose, and CMC development | May lose mixture-enabled activity; isolation/synthesis may be costly |
| Hybrid combination | Standardized extract plus a purified compound or approved drug | Can pair multi-target biology with a precise anchor | Highest herb-drug interaction and contribution-of-components burden |

For a disease-treatment claim in the United States, plan for a drug-development path and early FDA interaction. FDA’s botanical-drug guidance addresses IND/NDA development, and 21 CFR 300.50 requires each component of a fixed combination to contribute to the claimed effect. A dietary-supplement label is not a substitute for demonstrating safety and efficacy.

## 3. Taxonomy of useful and harmful interactions

### 3.1 Pharmacodynamic mechanisms worth seeking

- **Vertical pathway blockade:** two nodes in one causal pathway, such as receptor plus downstream escape kinase.
- **Horizontal pathway blockade:** parallel disease modules, such as pathogen killing plus efflux-pump inhibition, or anti-adhesion plus antimicrobial action.
- **Resistance suppression:** one component prevents genetic, epigenetic, phenotypic, or microbial escape from the other.
- **Cell-state or microenvironment complementarity:** one component acts on the diseased cell and another on immune, stromal, vascular, or microbiome context.
- **Spatial complementarity:** components reach different compartments that jointly drive disease.
- **Temporal complementarity:** pretreatment with A sensitizes the system to B, while simultaneous dosing may not.
- **Toxicity sparing:** equal efficacy is achieved at lower component exposures, or one component specifically protects a normal tissue without protecting the disease process.

### 3.2 Interactions that must be classified separately

- **Pharmacokinetic interaction:** A increases B’s absorption or decreases its clearance. This can improve exposure but is not proof of pharmacodynamic synergy and can amplify toxicity.
- **Formulation interaction:** a carrier, extract, or excipient changes dissolution, stability, or permeability.
- **Assay artifact:** fluorescence quenching, redox cycling, colloidal aggregation, precipitation, detergent effects, or general membrane damage mimics activity.
- **Toxicity synergy:** two individually tolerable materials jointly cause organ or pathway toxicity.
- **Antagonism:** one component chemically destroys, binds, metabolizes, or functionally opposes another.

Every hit should receive one or more of these labels. Do not merge them into a single “synergy” score.

---

## 4. End-to-end experimental program

## Stage 0 — target product profile and hypothesis

Specify before any combination screen:

- indication and patient subgroup;
- prevention, adjunctive treatment, rescue treatment, or disease modification;
- route and target tissue;
- intended duration;
- desired efficacy gain, dose reduction, resistance prevention, or safety gain;
- maximum acceptable toxicity and interaction liabilities;
- benchmark standard of care and minimum clinically meaningful improvement;
- botanical drug, fraction, purified molecule, or fixed-dose combination path.

Write a causal hypothesis in this form:

> Constituent/fraction A modulates target/pathway X in cell type Y, while constituent/fraction B modulates complementary target/pathway Z. Their combination is predicted to produce endpoint E at lower unbound exposures than either alone, without increasing normal-cell or organ toxicity, because mechanism M prevents/overcomes process R.

The hypothesis must name the disease-relevant endpoint. “Antioxidant,” “anti-inflammatory,” “detoxifying,” and “immune boosting” are not adequate endpoints by themselves.

## Stage 1 — material identity and quality lock

No screening data are interpretable until the actual materials are defined. For every botanical, capture:

1. accepted Latin binomial and author citation;
2. synonym history and common names;
3. plant part, developmental stage, harvest season, geography, cultivation/collection conditions, and post-harvest handling;
4. authenticated voucher specimen deposited in an accessible herbarium or controlled reference collection;
5. macroscopic/microscopic identity and, where useful, DNA-based identity (DNA alone is insufficient for highly processed extracts);
6. extraction solvent, drug-to-extract ratio, time, temperature, pH, particle size, and drying method;
7. LC-UV/LC-HRMS and/or GC-MS fingerprint, quantitative NMR where appropriate, and multiple identity/active/analytical markers;
8. water activity, residual solvents, pesticides, heavy metals, microbes, mycotoxins, adulterants, and plant-specific toxins;
9. stability-indicating assay, packaging, storage, retest period, and retained samples;
10. independent confirmation of supplier certificate-of-analysis data;
11. batch-to-batch chemical fingerprint and bioassay-potency comparability.

For a multi-plant product, characterize **each ingredient and the final mixture**. Record actual marker concentrations after mixing; nominal mass ratios are not enough. Follow GACP for starting materials and GMP-compatible process controls. NCCIH’s Natural Product Integrity Policy explicitly asks for botanical identity, extraction solvent, fingerprint/markers, independent analysis, contaminants, batch reproducibility, stability, voucher specimens, and manufacturing details.

### Immediate material-exclusion flags

- unresolved species or plant-part identity;
- batch substitution or adulteration;
- variable or unbounded toxic constituent;
- genotoxic/carcinogenic structural alert without a defensible margin;
- unmanageable ecological/supply constraints;
- irreproducible fingerprint or potency;
- inability to quantify at least plausible exposure markers;
- whole extracts containing narrow-therapeutic-index neuroactive, cardiac, anticholinergic, or hepatotoxic alkaloids.

## Stage 2 — single-agent qualification

Test A and B alone before testing A+B.

1. **Primary disease-relevant assay:** full concentration-response, not one concentration.
2. **Orthogonal assay:** a different technology measuring the same biology to exclude platform artifacts.
3. **Counterscreens:** matched healthy cells, reporter interference, aggregation, nonspecific membrane injury, and vehicle controls.
4. **Parameters:** EC50/IC50, Hill slope, Emax, area under the concentration-response curve, onset/offset, cytotoxicity (CC50), and selectivity index.
5. **Exposure plausibility:** compare active free concentration with projected unbound plasma or target-tissue exposure, not total administered mass.
6. **Target engagement:** demonstrate binding or functional engagement where a target is claimed.
7. **Batch robustness:** repeat with at least three independently manufactured or sourced lots for complex extracts.

An inactive component may legitimately be an efflux inhibitor, sensitizer, or toxicity protector. However, its contribution must be demonstrable in a relevant combination assay and its own safety/exposure must still be acceptable.

## Stage 3 — combination discovery screen

Use a tiered design rather than immediately testing arbitrary folk ratios.

### 3.1 Pairwise checkerboard/matrix

- Start with a 6 x 6 or 8 x 8 full matrix, including zero-dose rows/columns.
- Use logarithmically spaced concentrations spanning inactive, partially active, and near-maximal regions; the exact range should be based on the single-agent curves and achievable exposure.
- Test extracts by mass concentration **and** report marker-equivalent concentrations; purified constituents should use molar units.
- Measure actual soluble concentration if precipitation, binding, or instability is plausible.
- Include vehicle, positive-control, assay-interference, and matched-normal-cell plates.
- Randomize plate position; balance DMSO/ethanol/other vehicle across all wells.
- Run at least three biologically independent experiments on different days. Technical wells do not replace biological replication.
- Prespecify the response scale, normalization, synergy models, dose region of interest, and statistical analysis.

NCATS uses matrix combination screening to narrow many candidate pairs and dose combinations before animal and human testing; this is the appropriate conceptual model for a large botanical inventory.

### 3.2 Fixed-ratio rays and isobolograms

After a matrix hit:

- choose ratios based on equi-effective doses (for example, EC50-normalized 1:1) plus off-center ratios such as 1:3 and 3:1;
- titrate total dose along each fixed-ratio ray;
- generate effect-specific isoboles at EC25/EC50/EC75 or other prespecified effect levels;
- calculate Chou-Talalay combination index across a range of affected fractions;
- repeat in both disease and matched-normal systems.

Natural-ratio testing is useful for reconstructing an extract but should not be the only ratio. The natural ratio may reflect plant biosynthesis rather than human therapeutic optimization.

### 3.3 Sequence and duration

Test at least:

- simultaneous A+B;
- A pretreatment followed by B;
- B pretreatment followed by A;
- pulsed versus continuous exposure;
- washout/recovery.

Sequence is essential for stress-response activators, immune modulators, epigenetic agents, antibiotics, and senescence/senolytic hypotheses.

## Stage 4 — response-surface and design-of-experiments optimization

For two components, fit the complete concentration-response surface. For three or more components, exhaustive grids rapidly become infeasible; use formal DOE.

### Two-component designs

- full factorial dose matrix for discovery;
- central composite or D-optimal design for local optimization;
- response-surface models with nonlinear single-agent terms and an interaction term;
- bootstrap or profile-likelihood confidence intervals over the surface.

### Three-or-more-component mixtures

Separate two variables that are often confounded:

1. **total dose**, and
2. **composition/ratio**, where fractions sum to one.

Use a simplex-lattice, simplex-centroid, or constrained D-optimal mixture design. Add total dose as a process variable. Fit linear, quadratic, and, only when supported, special-cubic mixture terms. Use lack-of-fit testing and independent confirmation points. Sequential Bayesian optimization can nominate the next most informative ratios while respecting safety limits.

Do not progress a five-plant formula merely because one high-dimensional ratio is active. Apply leave-one-component-out and component-substitution experiments to show that every included component contributes.

---

## 5. Interaction metrics: formulas, assumptions, and use

Let effect be fractional inhibition or other increasing beneficial response, scaled from 0 to 1. If viability is used, convert consistently or use the correct viability form. Mixing inhibition and viability scales reverses interpretations.

| Model | Non-interaction expectation | Best use | Important limitation |
|---|---|---|---|
| Bliss independence | \(E_{AB}=E_A+E_B-E_AE_B\) | Agents modeled as probabilistically independent | Independence is a model assumption, not proof of biological independence |
| Highest single agent (HSA) | \(E_{AB}=\max(E_A,E_B)\) | Tests whether the pair beats the better single agent at those doses | Permissive; improvement over HSA alone does not establish dose additivity |
| Loewe additivity | \(d_A/D_A(E)+d_B/D_B(E)=1\) | Agents with interpretable monotonic single-agent curves and shared effect scale | Difficult if one agent is inactive or curves have incompatible maxima/slopes |
| ZIP | Zero change in single-agent potency across the surface | Dense dose matrices and local synergy landscapes | Depends on reliable curve fitting; score is model- and data-quality-dependent |
| Chou-Talalay CI | Dose fractions needed for a fixed effect | Fixed-ratio dose-effect experiments | Assumptions and curve quality must be prespecified; one CI value is inadequate |
| MuSyC (additional) | Multidimensional Hill surface | Separates potency synergy from efficacy synergy | More parameters require sufficient matrix density and uncertainty reporting |

### 5.1 Bliss excess

\[
S_{Bliss}=E_{observed}-(E_A+E_B-E_AE_B)
\]

Positive values indicate effect above the Bliss expectation. For viability, the expected viability is \(V_A V_B\).

### 5.2 HSA excess

\[
S_{HSA}=E_{observed}-\max(E_A,E_B)
\]

This answers the clinically intuitive question, “Does the combination outperform the better component at the same component doses?” It should accompany, not replace, a dose-additivity model.

### 5.3 Loewe/additivity index

For observed effect \(E\), let \(D_A(E)\) and \(D_B(E)\) be the single-agent doses producing E. Then:

\[
L(E)=\frac{d_A}{D_A(E)}+\frac{d_B}{D_B(E)}
\]

- \(L<1\): less total dose than expected under dose additivity;
- \(L=1\): additive;
- \(L>1\): antagonistic.

Plot isoboles rather than reporting only a mean value.

### 5.4 Chou-Talalay

The median-effect relation is:

\[
\frac{f_a}{f_u}=\left(\frac{D}{D_m}\right)^m
\]

At a defined affected fraction, a common mutually exclusive form is:

\[
CI=\frac{D_1}{(D_x)_1}+\frac{D_2}{(D_x)_2}
\]

CI < 1, = 1, and > 1 are interpreted as synergy, additivity, and antagonism under the method. For nonexclusive mechanisms, the generalized equation may include a product term. Prespecify the assumption and report CI with uncertainty at multiple affected fractions (for example 0.25, 0.50, 0.75, and 0.90), not just at one convenient point.

### 5.5 Antimicrobial checkerboards

For MIC-based assays:

\[
FIC_A=\frac{MIC_{A,combo}}{MIC_{A,alone}},\quad FIC_B=\frac{MIC_{B,combo}}{MIC_{B,alone}},\quad FICI=FIC_A+FIC_B
\]

Conventional thresholds often use FICI <= 0.5 for synergy and >4 for antagonism, but these cutoffs are method-sensitive. Confirm with time-kill curves, viable counts, biofilm assays, resistance-frequency/passaging experiments, and multiple clinical isolates.

### 5.6 Consensus decision rule

There is no universally correct synergy model. Use all models that match the biological assumptions, but designate one primary model prospectively. A credible hit should generally have:

- improvement over HSA;
- agreement of at least two appropriate reference models in a contiguous, exposure-relevant dose region;
- confidence interval excluding non-interaction after multiplicity control;
- reproducibility across independent experiments, lots, and relevant biological models;
- meaningful combination sensitivity/absolute effect, not synergy score alone;
- no corresponding synergy in matched-normal-cell or organ-toxicity endpoints.

Numeric SynergyFinder cutoffs such as +/-10 are useful screening conventions, not biological laws and not transferable proof of clinical benefit.

---

## 6. Fractionation and deconvolution without destroying synergy

Classical bioactivity-guided fractionation can lose activity when interacting constituents are separated. Use **synergy-directed fractionation**.

### 6.1 Workflow

1. Generate an untargeted LC-HRMS/MS and NMR feature map of the active extract or mixture.
2. Fractionate orthogonally (for example, polarity first, then size or reversed-phase separation) while retaining a frozen reference of the parent material.
3. Test every fraction alone.
4. Test every fraction with a fixed sub-effective concentration of an “anchor” compound/fraction.
5. Recombine all fractions to confirm recovery of parent activity.
6. Perform subtraction experiments (all fractions minus fraction i) to find necessary components.
7. Perform add-back experiments to locate potentiators and antagonists.
8. Correlate chemical features with activity and interaction scores using biochemometrics/interaction metabolomics; correct for co-eluting features.
9. Isolate candidate features and establish structures using HRMS/MS, 1D/2D NMR, authentic standards, and stereochemical methods.
10. Reconstitute purified constituents at measured natural concentrations and at optimized ratios.
11. Compare reconstituted mixture versus parent extract using equivalence bounds, not only “not statistically different.”
12. Validate necessity with depletion and sufficiency with add-back; validate target mechanism with genetic or biochemical perturbation.

### 6.2 Positive methodological precedent

Junio and colleagues demonstrated synergy-directed fractionation in goldenseal: flavonoids with little standalone antibacterial activity enhanced berberine activity against *Staphylococcus aureus* through inhibition of the NorA efflux pump. This is a strong model for discovering “silent” potentiators that classical single-agent fractionation would discard.

### 6.3 Decide where to stop simplifying

Stop at the least complex composition that retains:

- reproducible efficacy;
- reproducible interaction surface;
- acceptable safety and PK;
- manufacturable specifications;
- defensible contribution of each retained component.

If two purified compounds fully reproduce the extract, develop the defined pair. If purified reconstruction loses a robust effect and a standardized fraction can be controlled, the fraction may be the better drug substance.

---

## 7. Proving multi-target mechanism

Network diagrams and docking predictions generate hypotheses; they do not prove target action. Use a causal ladder.

1. **Direct biochemical engagement:** binding, enzyme kinetics, receptor pharmacology.
2. **Cellular target engagement:** CETSA/thermal proteome profiling, NanoBRET, chemoproteomics, or occupancy assay.
3. **Perturbation:** CRISPR knockout/knockdown, resistant mutant, overexpression, pharmacologic comparator.
4. **Rescue:** restore the target/pathway and show loss or recovery of the combination effect.
5. **Temporal omics:** transcriptomics, proteomics, phosphoproteomics, metabolomics, and, where informative, single-cell analysis at early and late times.
6. **Pathway convergence:** show that A and B affect the predicted separate modules and that A+B produces the expected joint state.
7. **Human-relevant system:** primary cells, iPSC-derived cells, organoids, tissue slices, or microphysiological systems.
8. **In-vivo translation:** target engagement, exposure, efficacy, and safety in a model chosen for human relevance—not merely convenience.

For an aging claim, define a disease or validated functional context. Changes in SA-beta-gal, ROS, or a single “longevity gene” are insufficient. Use a panel that can include senescence burden, inflammatory secretome, autophagic flux, mitochondrial function, epigenetic/transcriptomic age measures, frailty/functional outcomes, and healthspan—while recognizing that only human trials establish human benefit.

---

## 8. Safety interaction program

Evaluate the combination in addition to each component. Additive exposure can create toxicity even when efficacy is synergistic.

### 8.1 Early screens

- matched normal human cells and multiple donors;
- hepatocyte viability, bile-acid transport, mitochondrial respiration, reactive metabolite formation, and cholestasis liability;
- renal proximal-tubule injury;
- cardiomyocyte electrophysiology and hERG/major ion-channel panel;
- CNS sedation/excitation and seizure liability when relevant;
- hemolysis and blood compatibility for parenteral products;
- Ames, micronucleus, and follow-up genotoxicity as appropriate;
- immunotoxicity/cytokine release and unintended immunosuppression;
- reproductive/developmental flags for intended population;
- local tolerance for topical, inhaled, or gastrointestinal delivery.

Calculate efficacy and toxicity surfaces separately. A useful pair should shift the efficacy surface favorably without an equal or larger left shift in the toxicity surface.

### 8.2 Pharmacodynamic interaction watchlist

- bleeding/antiplatelet/anticoagulant effects;
- sedation, respiratory depression, anticholinergic load, or serotonergic effects;
- QT prolongation/arrhythmia;
- hypoglycemia or hypotension;
- electrolyte/diuretic effects;
- immune stimulation or suppression;
- thyroid, estrogenic/antiestrogenic, androgenic, or glucocorticoid effects;
- hepatotoxicity or nephrotoxicity;
- duplicate salicylate/NSAID-like exposure.

### 8.3 Herb-drug interaction (HDI) testing

Follow the logic of ICH M12 for enzyme- and transporter-mediated interaction risk, adapted to complex botanicals. Screen individual components, the final combination, and major circulating metabolites for:

- reversible and time-dependent inhibition of CYP1A2, 2B6, 2C8, 2C9, 2C19, 2D6, and 3A;
- enzyme induction in primary human hepatocytes, including PXR/CAR-linked responses;
- relevant UGT pathways;
- P-gp, BCRP, OATP1B1/1B3, OAT1/3, OCT2, and MATE1/2-K where indicated;
- plasma protein binding and blood-to-plasma partitioning;
- microbiome-mediated activation/inactivation for glycosides and prodrugs.

High-risk concomitant medicines include warfarin and other anticoagulants, tacrolimus/cyclosporine, antiepileptics, antiarrhythmics, antiretrovirals, oncology drugs, transplant medicines, oral contraceptives, and other narrow-therapeutic-index agents. St. John’s wort is generally a poor systemic combination ingredient because hyperforin-mediated PXR activation can reduce exposure to many medicines.

---

## 9. PK interaction and exposure matching

### 9.1 Component ADME

For each putative active/marker constituent measure:

- kinetic and thermodynamic solubility;
- pKa, logD, chemical and plasma stability;
- permeability and efflux;
- microsomal and hepatocyte clearance;
- metabolite identification;
- protein binding;
- tissue distribution and target-site exposure;
- oral bioavailability and food effect when relevant.

### 9.2 Combination PK study

Use a four-condition design where feasible: A, B, A+B, and vehicle/control. Measure parent compounds and important active/toxic metabolites. Compare AUC, Cmax, Tmax, half-life, clearance, volume, urinary recovery, and tissue exposure. Add oral-versus-intravenous or portal-versus-systemic comparisons if needed to distinguish absorption from clearance effects.

### 9.3 Target-site ratio is the real ratio

The formulation ratio is not necessarily the biological ratio. A 1:1 capsule may become 20:1 in liver and 1:10 in brain. Progress only if the synergistic region overlaps the **unbound target-site exposure surface** for a meaningful duration.

Do not casually add piperine or another “bioenhancer.” Increasing exposure through CYP/P-gp inhibition can turn a weak product into an interaction hazard. If bioenhancement is intentional, treat the enhancer as an active combination component with its own contribution, PK, and safety program.

---

## 10. Formulation strategy

Choose the simplest formulation that delivers the required target-site ratio and duration.

### Options

- co-extract if extraction reproducibly captures interacting constituents;
- separately manufactured extracts blended to a controlled ratio;
- co-packaged dosage forms if independent titration or timing is required;
- fixed-dose formulation if ratio is stable across the intended population;
- local/topical delivery when systemic exposure is unnecessary or unsafe;
- modified release when temporal sequencing matters.

### Required studies

- chemical compatibility and degradation during mixing/storage;
- dissolution/release of each marker and active;
- supersaturation/precipitation under biorelevant conditions;
- excipient effects on assays, transporters, and gut microbiota;
- container-closure sorption and light/oxygen/moisture sensitivity;
- scale-up and process capability;
- food effect and alcohol-dose dumping where relevant;
- bridging when formulation changes bioavailability.

Nanoparticles, liposomes, phospholipid complexes, and amorphous dispersions can solve exposure problems, but they create a new product with different biodistribution and potentially different toxicology. “Improved bioavailability” is not automatically safer; NCCIH notes reported liver injury with some highly bioavailable curcumin products.

---

## 11. Quality-control specification for a combination lead

The release specification should contain four layers:

1. **Identity:** taxonomy, part, morphology/microscopy, appropriate genetic identity, and diagnostic chemical fingerprint.
2. **Composition:** quantitative active/relevant markers, component ratio, degradants, and fingerprint similarity.
3. **Purity/safety:** microbes, mycotoxins, pesticides, heavy metals, residual solvents, adulterants, and plant-specific toxins.
4. **Biological potency:** a validated, stability-indicating assay linked as closely as possible to mechanism.

Set prospective acceptance ranges from process knowledge, analytical method performance, pharmacology, and clinical lots—not from arbitrary “natural variability.” A mixture may pass chemical release but fail biological potency; both are needed when the active constituents are not fully known. EMA’s herbal-product specification guideline and NCCIH’s Product Integrity Policy are useful baselines.

---

## 12. Scalable computational prioritization across the book inventory

The goal is not to let an AI “invent cures.” The goal is to reduce a combinatorial search space, quantify uncertainty, and select the most informative experiments.

### 12.1 Build a provenance-first knowledge graph

Minimum node types:

- botanical taxon, synonym, plant part, preparation, extract, batch;
- compound/feature with structure identifiers and measured concentration;
- protein/target with direction of modulation;
- pathway, cell type, tissue/organ, disease, phenotype;
- assay, dose, exposure, toxicity, and evidence source;
- formulation and manufacturing process;
- pair/mixture, ratio, schedule, response surface, and interaction metric.

Every edge must retain citation, experimental system, dose, preparation, direction, and evidence level. Book claims enter as **traditional-use hypotheses**, never as confirmed target-disease edges.

### 12.2 Data sources

- reconcile plant names against authoritative taxonomies;
- use LOTUS for referenced natural-product structure-organism occurrence pairs;
- use PubChem and ChEMBL for structures and measured bioactivity;
- use Open Targets for target-disease evidence and tractability;
- use curated pathway resources for disease-module mapping;
- use EPA CompTox and primary toxicology sources for hazard signals;
- use clinical-trial registries, FDA/EMA documents, PubMed, and pharmacovigilance sources for human evidence and interactions.

Predicted plant constituents must be confirmed analytically in the actual batch. A compound reported once in a species is not necessarily present in the chosen part, geography, season, or extraction.

### 12.3 Evidence grading

Use two independent axes:

**Biological evidence**

- E5: replicated human efficacy with characterized product;
- E4: human target engagement, PK, or robust clinical biomarker;
- E3: replicated in-vivo efficacy with exposure/target engagement;
- E2: human primary-cell/organoid or multiple orthogonal cellular models;
- E1: biochemical, single-cell-line, or computational hypothesis only.

**Material confidence**

- M3: actual study batch quantified and fingerprinted;
- M2: same species/part/preparation documented, but batch not measured;
- M1: species-level occurrence or database prediction only.

A high biological score with M1 material confidence is not progression-ready.

### 12.4 Pair features

For each disease and candidate pair calculate:

- strength and direction of component evidence;
- overlap with genetically/clinically supported disease targets;
- complementary coverage of causal disease modules;
- resistance/escape pathway coverage;
- predicted target and tissue exposure overlap;
- ratio feasibility and formulation compatibility;
- chemical redundancy versus mechanistic complementarity;
- off-target/toxicity-pathway overlap;
- CYP/transporter and pharmacodynamic interaction risk;
- quality/manufacturing/supply feasibility;
- novelty and uncertainty.

Network proximity alone should not dominate: promiscuous polyphenols often appear impressive because they have many reported targets.

### 12.5 Hard gates plus multi-objective ranking

Apply hard exclusions first (identity failure, severe toxicity, impossible exposure, no reproducible material). Then rank the survivors on a Pareto frontier rather than hiding tradeoffs in one number.

An optional transparent ranking score for triage—not a validated probability of success—is:

\[
Priority=Q_{floor}[0.20D+0.15C+0.15X+0.10R+0.10B+0.10M+0.10N+0.10I]-[0.40T+0.35H+0.25U]
\]

Where:

- \(Q_{floor}=\min(Q_A,Q_B,Q_{mixture})\), the weakest material-quality score;
- D = disease evidence;
- C = mechanistic complementarity;
- X = exposure feasibility;
- R = ratio/schedule feasibility;
- B = expected benefit over best single agent;
- M = manufacturing/supply feasibility;
- N = novelty;
- I = expected information gain;
- T = toxicity liability;
- H = herb-drug interaction liability;
- U = uncertainty/domain-shift penalty.

Weights should be calibrated against internal outcomes and indication priorities. Safety remains a hard gate even if the numeric score is high.

### 12.6 Machine learning and active learning

1. Train baseline models on public combination datasets using chemical, target, disease/cell-state, and dose features.
2. Calibrate probability and uncertainty; botanical mixtures are out-of-domain relative to oncology drug-pair datasets.
3. Select an experimentally diverse first batch: top predictions, mechanistically diverse candidates, uncertain candidates with high information value, and negative controls.
4. Run dose matrices, not binary labels.
5. Retrain on the project’s own standardized-extract data.
6. Use Bayesian active learning to choose the next pairs and ratios.
7. Reserve a blinded external test set and prospectively validate hit rate.

A 2025 NCATS-led study provides a useful precedent: models trained on a small experimentally screened subset prioritized combinations from a much larger virtual space, followed by experimental validation. The lesson is “prediction -> matrix testing -> retraining,” not prediction alone.

### 12.7 Practical scaling for this book

For \(N\) normalized botanical entries, there are \(N(N-1)/2\) unordered plant pairs before considering parts, preparations, ratios, and compounds. Thus 150 entries produce 11,175 pairs and 180 entries produce 16,110. A practical funnel is:

1. remove hazardous/non-druggable whole extracts;
2. score identity and material availability;
3. map each plant to quantified compounds and credible disease modules;
4. select the top 10-20 single agents per indication;
5. enumerate pairs only within that indication;
6. prune redundant and unsafe pairs;
7. screen 50-200 diverse pairs in a low-resolution matrix;
8. retest the top 10-20 in full matrices;
9. deconvolve and validate 2-5 leads.

---

## 13. Stage-gated go/no-go criteria

These are suggested starting criteria; each program should prospectively adjust them to its target product profile. There is no universal extract-potency cutoff.

| Gate | Go criteria | No-go / hold criteria |
|---|---|---|
| Material | Authenticated species/part; reproducible preparation; fingerprint and markers; contaminants controlled; retained lot | Identity ambiguity, adulteration, uncontrolled toxin, irreproducible lot |
| Single agent | Monotonic reproducible response or a defined potentiator role; orthogonal confirmation; plausible exposure | Activity only at insoluble/cytotoxic concentration; assay interference; no exposure path |
| Matrix hit | Beats HSA; primary model significant; second appropriate model concordant in adjacent dose region; replicated | Isolated single well; model disagreement caused by poor fits; no absolute efficacy |
| Dose benefit | Example: >=3-fold total-dose reduction at a meaningful effect or >=20 percentage-point Emax gain, prospectively justified | Tiny statistical interaction without a clinically meaningful gain |
| Selectivity | Example starting target: >=10-fold efficacy-to-matched-normal-cell margin and no toxicity-surface synergy | Normal-cell/organ toxicity shifts as much as efficacy |
| Exposure | Active unbound concentrations and ratio achieved at target tissue for required duration | Synergy requires concentrations/ratios not achievable safely |
| Mechanism | At least one causal perturbation/rescue plus target engagement; contribution of each component | Docking/network narrative only; superfluous component |
| Robustness | Reproduced across >=3 independent experiments, >=3 lots for complex products, and relevant donors/isolates/models | Lot-, plate-, cell-line-, or operator-specific result |
| HDI | No unmanageable CYP/transporter or pharmacodynamic interaction at projected exposure | Time-dependent inhibition/induction or narrow-index interaction without mitigation |
| In vivo | Exposure, target engagement, efficacy, and tolerability align; combination outperforms components on intended benefit | Efficacy without exposure/engagement; weight loss or nonspecific sickness explains response |
| CMC | Scalable process, stable ratio, release assay, supply sustainability, acceptable cost | Active fraction cannot be reproduced or stabilized |
| Clinical POC | Combination benefit-risk exceeds components/SOC and each component contribution is demonstrated | AB not better than relevant component/control or safety negates benefit |

“Hold” is appropriate when uncertainty can be resolved by a defined experiment; “no-go” is appropriate when the target product profile cannot be met.

---

## 14. Illustrative book-derived combination hypotheses

All five examples below are research hypotheses. They were selected to demonstrate different interaction mechanisms and decision outcomes, not because they are proven treatments.

| Research-only hypothesis | Initial priority | First human-relevant model | Decision readout | Non-negotiable safety gate | Status |
|---|---|---|---|---|---|
| Goldenseal berberine + flavonoid efflux-inhibitor fraction | High for mechanism; moderate for translation | MRSA clinical isolates followed by keratinocyte/wound-biofilm and ex-vivo skin models | Exposure-relevant FICI/time-kill benefit, lower resistance emergence, and improved biofilm clearance over HSA | No keratinocyte/dermal-toxicity synergy; sensitization and systemic absorption acceptable; cultivated traceable supply | **Research hypothesis only; not a treatment** |
| Cranberry PAC fraction + bearberry arbutin fraction | Medium-low | UPEC in donor urine and human bladder organoids | Reduced epithelial adhesion and viable bacterial burden with meaningful arbutin dose sparing | No urothelial, renal, or genotoxicity signal; respect EMA kidney/pregnancy and <=1-week constraints | **Research hypothesis only; not a treatment** |
| Lion's mane erinacine/hericerin fraction + ashwagandha withanolide fraction | Exploratory | Human iPSC neuron-astrocyte-microglia stress model | Recovered network electrophysiology/synaptic function plus neurite phenotype, with causal pathway engagement | Demonstrable CNS exposure; no liver, thyroid, sedation, or neurotoxicity interaction | **Research hypothesis only; not an anti-aging treatment** |
| Silybin-defined milk-thistle fraction + defined curcumin formulation | Medium if formulation-specific safety passes | Multicellular human liver organoids and precision-cut liver slices | Reduced lipotoxic injury and fibrotic/inflammatory state with efficacy-selective dose sparing | No hepatotoxicity-surface synergy or bile/mitochondrial liability; formulation-specific DILI and HDI cleared | **Research hypothesis only; not a MASH treatment** |
| Willow/meadowsweet salicylates + garlic/feverfew platelet-active chemistry | No-go; negative-control value only | Human platelet/coagulation and gastric/renal safety systems before any efficacy work | Safety model should flag redundancy and harmful interaction | Any bleeding, gastric, renal, or anticoagulant-interaction amplification confirms no-go | **Research-only deliberate no-go comparator** |

### Hypothesis 1 — Goldenseal berberine + goldenseal flavonoid efflux-inhibitor fraction for localized *S. aureus* infection

**Proposed product:** topical, chemically standardized two-fraction product or purified berberine plus defined methoxylated flavonoid(s) from *Hydrastis canadensis*.

**Rationale:** Published synergy-directed fractionation identified sideroxylin, 8-desmethyl-sideroxylin, and 6-desmethyl-sideroxylin as potentiators of berberine against *S. aureus*, consistent with NorA efflux inhibition. A local route could avoid the poor systemic absorption and systemic interaction burden of oral goldenseal.

**Disease hypothesis:** efflux inhibition will lower the berberine concentration required to suppress susceptible and resistant *S. aureus* in wound/skin biofilm without increasing keratinocyte toxicity.

**Critical experiments:**

- checkerboards and time-kill curves across diverse MSSA/MRSA clinical isolates;
- NorA-overexpressing, knockout, and complemented strains;
- direct efflux assays and resistance-selection/passaging;
- planktonic, biofilm, keratinocyte co-culture, and ex-vivo human skin/wound models;
- reconstitution, depletion, and add-back of individual flavonoids;
- dermal penetration, local retention, sensitization, and phototoxicity;
- topical microbiome selectivity.

**Safety/feasibility caveats:** oral goldenseal has important medication-interaction and pregnancy/infant concerns, and wild goldenseal has sustainability constraints. This hypothesis therefore prioritizes cultivated, traceable material and local delivery. Do not infer clinical MRSA efficacy from the published in-vitro mechanism.

**Initial priority:** high for mechanistic validation; moderate for translation until local safety, formulation, and clinical-isolate data are favorable.

### Hypothesis 2 — Cranberry A-type proanthocyanidin fraction + bearberry arbutin-standardized fraction for lower urinary-tract infection

**Proposed product:** a short-duration, defined urinary-directed combination—not chronic self-treatment.

**Rationale:** cranberry constituents may reduce uropathogen adhesion, while bearberry supplies arbutin/hydroquinone-related urinary antimicrobial chemistry. Anti-adhesion plus killing could produce dose sparing and reduce biofilm establishment.

**Disease hypothesis:** the pair will reduce bladder epithelial attachment and bacterial burden at lower arbutin exposure than bearberry alone.

**Critical experiments:**

- quantify cranberry PACs by a validated method and bearberry hydroquinone derivatives as arbutin;
- UPEC checkerboards in artificial and donor urine, time-kill, adhesion, invasion, and biofilm assays;
- human bladder organoids/urothelial co-culture and urinary metabolite testing;
- compare parent extracts with actual urinary metabolites;
- four-arm PK/urinary recovery study before any efficacy trial;
- genotoxicity and kidney/urothelial toxicity of component and combination exposures;
- factorial clinical design only after safety and urinary exposure are established.

**Safety/feasibility caveats:** EMA’s bearberry monograph limits traditional use to adult women, contraindicates kidney disorders, does not recommend pregnancy/lactation, and limits duration to no more than one week. Therefore, a chronic recurrent-UTI-prevention product containing bearberry is a poor target. Failure to demonstrate arbutin dose sparing should be a no-go. Suspected UTI with fever, flank pain, pregnancy, systemic illness, or persistent symptoms requires standard clinical evaluation; this is not an antibiotic substitute.

**Initial priority:** medium-low; scientifically testable local-complementarity hypothesis but constrained by bearberry safety and duration.

### Hypothesis 3 — Erinacine/hericerin-defined lion’s mane fraction + withanolide-defined ashwagandha root fraction for stress-associated cognitive dysfunction

**Proposed product:** defined fractions, not generic mushroom and root powders.

**Rationale:** lion’s mane constituents have preclinical neurotrophic/neurite-outgrowth signals; ashwagandha extracts have small, heterogeneous human studies suggesting stress/cortisol/sleep effects. The hypothesis is neurotrophic support plus stress-axis/inflammatory modulation, not a generic “anti-aging” claim.

**Disease hypothesis:** in chronic stress-associated cognitive impairment, the pair will improve neuronal network function and stress-linked inflammatory phenotypes more than either component alone at exposure-feasible concentrations.

**Critical experiments:**

- distinguish fruiting body from mycelium and quantify erinacines/hericerins and withanolides;
- human iPSC neuron-astrocyte-microglia co-culture under glucocorticoid/inflammatory stress;
- neurite morphology, synaptic electrophysiology, network activity, NGF/Trk signaling, cytokines, and cell viability;
- CRISPR/pharmacologic interrogation of proposed neurotrophic pathways;
- BBB permeability, brain exposure, active metabolites, and sedative interaction testing;
- aged/chronic-stress animal model with exposure and target engagement;
- only then, a randomized factorial clinical proof-of-mechanism study with objective cognitive and sleep/stress measures.

**Safety/feasibility caveats:** human evidence for lion’s mane products is limited and product chemistry varies. NIH ODS notes that long-term ashwagandha safety is unknown and flags potential liver and thyroid effects and pregnancy/breastfeeding concerns. If CNS exposure or causal target engagement cannot be demonstrated, stop rather than relying on subjective outcomes.

**Initial priority:** exploratory; potentially relevant to healthspan but high translational uncertainty.

### Hypothesis 4 — Silybin-defined milk-thistle fraction + defined curcumin formulation for MASH/MASLD

**Proposed product:** a rationally formulated liver-directed pair with measured parent/metabolite exposure.

**Rationale:** the components have distinct but overlapping preclinical hepatocellular stress, inflammatory, and fibrotic hypotheses. The useful question is whether the pair improves human MASH-relevant phenotypes at lower exposures—not whether two “liver herbs” have additive antioxidant capacity.

**Disease hypothesis:** silybin plus curcumin will reduce lipotoxic hepatocyte injury and inflammatory/fibrotic signaling with dose sparing relative to either alone.

**Critical experiments:**

- human multicellular liver organoids and precision-cut liver slices under metabolic/lipotoxic stress;
- hepatocyte injury, stellate-cell activation, macrophage state, bile-acid transport, mitochondrial function, fibrosis markers, and transcriptomic state;
- full efficacy and hepatotoxicity response surfaces;
- formulation-specific PK, metabolites, bile exposure, and drug-interaction testing;
- causal pathway perturbation rather than broad antioxidant readouts;
- in-vivo MASH model with histology, exposure, and target engagement;
- factorial clinical study with histologic or validated disease endpoints if preclinical gates pass.

**Safety/feasibility caveats:** NCCIH reports conflicting/insufficient milk-thistle clinical evidence, including negative NCCIH-funded NASH work, and quality problems in commercial products. NCCIH also states that highly bioavailable curcumin formulations may harm the liver. That makes formulation-specific liver safety a first-order gate, not an afterthought. A negative monotherapy literature does not prove a combination will fail, but it raises the efficacy bar.

**Initial priority:** medium as a falsifiable formulation/mechanism program; low if based only on retail supplements or nonspecific biomarkers.

### Hypothesis 5 — White willow/meadowsweet salicylate chemistry + garlic/feverfew antiplatelet chemistry for pain or migraine: deliberate no-go comparator

**Proposed product:** none without compelling contrary evidence.

**Rationale for rejection:** the apparent appeal is overlapping anti-inflammatory/platelet biology. The likely result is pharmacologic redundancy with increased bleeding and gastrointestinal liability rather than a differentiated therapeutic window. This is an example of “synergy in harm.”

**Research use:** include analogous high-risk/redundant pairs as negative controls for the computational safety filter. If investigated at all, test platelet function, coagulation, gastric injury, renal effects, and CYP/transport interactions before efficacy optimization.

**Initial priority:** no-go for an oral fixed combination unless an unusually strong, exposure-supported dose-sparing benefit and a clearly superior safety margin are prospectively demonstrated.

---

## 15. Clinical translation and contribution of components

Preclinical synergy is not a substitute for clinical trial design.

### Phase 1 / clinical pharmacology

- characterize each component and combination;
- single- and multiple-ascending exposure as appropriate;
- food effect and formulation bridging;
- component-component PK interaction;
- ECG, liver, renal, hematologic, immune, and indication-specific monitoring;
- trigger formal clinical DDI studies based on ICH M12 risk assessment.

### Proof of concept

When ethical and feasible, use a 2 x 2 factorial design with A, B, A+B, and placebo/standard-of-care background. Demonstrate contribution of each component. Power any claim of clinical synergy for a prespecified statistical interaction on a clinically meaningful scale; “AB significant while A and B are not” is not an interaction test. Regulatory contribution can be demonstrated without proving mathematical synergy, but a superfluous component should not remain in the product.

### Confirmatory development

- confirm benefit-risk versus standard of care;
- prespecify subgroup and biomarker hypotheses;
- lock commercial manufacturing and compare clinical/commercial lots;
- monitor delayed organ toxicity and interactions;
- build pharmacovigilance and real-world interaction surveillance.

---

## 16. Minimum combination-experiment record

Each result should store:

- unique botanical/extract/fraction/compound IDs and batch IDs;
- full identity, preparation, fingerprint, and marker concentrations;
- assay protocol, cell/organism/strain/donor, passage, media, and endpoint;
- raw concentrations and actual measured soluble concentrations where relevant;
- route, sequence, timing, and ratio;
- raw and normalized responses with biological replicate identifiers;
- all single-agent curves;
- model equations, software/version, fit diagnostics, confidence intervals, multiplicity method;
- Bliss, HSA, Loewe, ZIP, CI/MuSyC outputs as applicable;
- absolute effect, CSS/AUC/Emax, selectivity, and toxicity surface;
- PK/target-tissue exposure comparison;
- decision, rationale, and next falsifying experiment;
- provenance and negative/null results.

Preserve raw data and code. A “synergy” label without the full response surface and single-agent curves is not reusable evidence.

---

## 17. Primary and official sources

### Regulatory, quality, and assay standards

1. U.S. FDA. **Botanical Drug Development: Guidance for Industry** (2016, current FDA page). <https://www.fda.gov/regulatory-information/search-fda-guidance-documents/botanical-drug-development-guidance-industry>
2. NIH/NCCIH. **NCCIH Policy: Natural Product Integrity** (official policy; includes requirements for each botanical and the final multi-herb mixture). <https://www.nccih.nih.gov/research/nccih-policy-natural-product-integrity>
3. EMA. **Guideline on specifications: test procedures and acceptance criteria for herbal substances, preparations, and medicinal products, Revision 3** (2022). <https://www.ema.europa.eu/en/specifications-test-procedures-acceptance-criteria-herbal-substances-herbal-preparations-herbal-medicinal-products-traditional-herbal-medicinal-products-scientific-guideline>
4. EMA. **Guideline on Good Agricultural and Collection Practice for starting materials of herbal origin, Revision 1** (2025). <https://www.ema.europa.eu/en/documents/scientific-guideline/guideline-good-agricultural-collection-practice-gacp-starting-materials-herbal-origin-revision-1_en.pdf>
5. U.S. FDA/ICH. **M12 Drug Interaction Studies** (final guidance; FDA page current May 2026). <https://www.fda.gov/regulatory-information/search-fda-guidance-documents/m12-drug-interaction-studies>
6. U.S. FDA. **Codevelopment of Two or More New Investigational Drugs for Use in Combination** (2013). <https://www.fda.gov/regulatory-information/search-fda-guidance-documents/codevelopment-two-or-more-new-investigational-drugs-use-combination>
7. Electronic Code of Federal Regulations. **21 CFR 300.50 Fixed-combination prescription drugs for humans.** <https://www.ecfr.gov/current/title-21/chapter-I/subchapter-D/part-300/subpart-B/section-300.50>
8. NIH/NCATS. **Matrix Combination Screening** (official program description, updated 2025). <https://ncats.nih.gov/research/research-activities/matrix>
9. NIH/NCATS. **Assay Guidance Manual**. <https://www.ncbi.nlm.nih.gov/books/NBK53196/>

### Combination methodology

10. Chou TC. **Drug Combination Studies and Their Synergy Quantification Using the Chou-Talalay Method.** *Cancer Research.* 2010;70:440-446. <https://pubmed.ncbi.nlm.nih.gov/20068163/>
11. Yadav B, Wennerberg K, Aittokallio T, Tang J. **Searching for Drug Synergy in Complex Dose-Response Landscapes Using an Interaction Potency Model.** *Computational and Structural Biotechnology Journal.* 2015;13:504-513. <https://doi.org/10.1016/j.csbj.2015.09.001>
12. Meyer CT et al. **Quantifying Drug Combination Synergy along Potency and Efficacy Axes.** *Cell Systems.* 2019;8:97-108.e16. <https://doi.org/10.1016/j.cels.2019.01.003>
13. Ianevski A et al. **SynergyFinder 3.0: an interactive analysis and consensus interpretation of multi-drug synergies across multiple samples.** *Nucleic Acids Research.* 2022;50:W739-W743. <https://academic.oup.com/nar/article/50/W1/W739/6586861>
14. Greco WR, Bravo G, Parsons JC. **The Search for Synergy: A Critical Review from a Response Surface Perspective.** *Pharmacological Reviews.* 1995;47:331-385. <https://pubmed.ncbi.nlm.nih.gov/7568331/>

### Natural-product deconvolution and computational prioritization

15. Junio HA et al. **Synergy-Directed Fractionation of Botanical Medicines: A Case Study with Goldenseal (*Hydrastis canadensis*).** *Journal of Natural Products.* 2011;74:1621-1629. <https://doi.org/10.1021/np200336g>
16. Vidar WS et al. **Interaction Metabolomics to Discover Synergists in Natural Product Mixtures.** *Journal of Natural Products.* 2023. <https://doi.org/10.1021/acs.jnatprod.2c00518>
17. Rutz A et al. **The LOTUS initiative for open knowledge management in natural products research.** *eLife.* 2022;11:e70780. <https://elifesciences.org/articles/70780>
18. Zdrazil B et al. **The ChEMBL Database in 2023: a drug discovery platform spanning multiple bioactivity data types and time periods.** *Nucleic Acids Research.* 2024;52:D1180-D1192. <https://academic.oup.com/nar/article/52/D1/D1180/7337608>
19. Buniello A et al. **Open Targets Platform: facilitating therapeutic hypotheses building in drug discovery.** *Nucleic Acids Research.* 2025;53:D1467-D1475. <https://academic.oup.com/nar/article/53/D1/D1467/7917960>
20. U.S. EPA. **CompTox Chemicals Dashboard** (official resource). <https://www.epa.gov/comptox-tools/comptox-chemicals-dashboard>
21. Pourmousa M et al. **AI-driven discovery of synergistic drug combinations against pancreatic cancer.** *Nature Communications.* 2025. <https://www.nature.com/articles/s41467-025-56818-6>

### Sources supporting the illustrative hypotheses and cautions

22. NIH/NCCIH. **Goldenseal: Usefulness and Safety.** <https://www.nccih.nih.gov/health/goldenseal>
23. EMA. **European Union herbal monograph on *Arctostaphylos uva-ursi* folium, Revision 2.** <https://www.ema.europa.eu/en/documents/herbal-monograph/final-european-union-herbal-monograph-arctostaphylos-uva-ursi-l-spreng-folium-revision-2_en.pdf>
24. NIH Office of Dietary Supplements. **Ashwagandha: Health Professional Fact Sheet** (2025). <https://ods.od.nih.gov/factsheets/Ashwagandha-HealthProfessional/>
25. Martinez-Marmol R et al. **Hericerin derivatives activates a pan-neurotrophic pathway in central hippocampal neurons converging to ERK1/2 signaling enhancing spatial memory.** *Journal of Neurochemistry.* 2023;165:791-808. <https://pubmed.ncbi.nlm.nih.gov/36660878/>
26. NIH/NCCIH. **Milk Thistle: Usefulness and Safety.** <https://www.nccih.nih.gov/health/milk-thistle>
27. NIH/NCCIH. **Turmeric: Usefulness and Safety.** <https://www.nccih.nih.gov/health/turmeric>
28. U.S. FDA. **Select Dietary Supplement Ingredients and Other Substances** (official page noting, among other items, comfrey pyrrolizidine alkaloids and ephedrine-alkaloid action). <https://www.fda.gov/food/dietary-supplements/information-select-dietary-supplement-ingredients-and-other-substances>

---

## Bottom line

The scientifically defensible path from traditional formula to new drug is:

> authenticate -> standardize -> qualify single agents -> map full dose-response surfaces -> separate PD, PK, formulation, and toxicity interactions -> deconvolve with subtraction/add-back -> prove causal mechanism -> demonstrate target-site exposure -> establish combination safety -> manufacture reproducibly -> show each component’s clinical contribution.

Traditional use is a valuable hypothesis generator and may improve prioritization. It does not waive any of these gates. The best invention program will preserve the book’s ethnobotanical signal while being willing to reject most claims, most arbitrary mixtures, and most apparent in-vitro synergies.
