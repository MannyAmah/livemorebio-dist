# Research and clinical safety audit of *The Lost Book of Remedies*

## Bottom line

This is a **screening audit for research governance**, not a validation of efficacy and not a guide to self-treatment. Every one of the 193 inventoried monographs was evaluated for the requested high-risk domains. The machine-readable file `book_safety_flags.csv` contains 443 issue rows covering 175 monographs; 369 rows are marked `hard_stop=TRUE`. The remaining 18 monographs merely had no trigger under this audit's selected high-risk rules. They are **not certified safe, effective, or druggable**.

The most important distinction is between a **source of chemical leads** and an acceptable crude medicine. A Critical/hard-stop finding usually stops the book's preparation, route, or clinical claim. It does not necessarily stop isolated-compound discovery. Mayapple is the clearest model: the crude plant is an unacceptable human test article, while purified podophyllotoxin chemistry has been a productive starting point for drug derivatives.

## Coverage and outputs

| Measure | Result |
|---|---:|
| Monographs audited | 193 |
| Monographs with one or more selected flags | 175 |
| Total issue rows | 443 |
| Critical rows | 174 |
| High rows | 242 |
| Medium rows | 27 |
| Hard-stop rows | 369 |

Each CSV row is keyed by `record_id` and includes the printed book page, 1-based PDF page, issue class/subclass, severity, hard-stop status and context, book evidence, external safety basis, source codes, and a research handling recommendation. Printed page *p* corresponds to 1-based PDF page *p+1* in this file.

| Issue class | Rows | What it means |
|---|---:|---|
| Care delay or unsupported serious-disease claim | 261 | A book claim could displace diagnosis, emergency response, preventive care, or established treatment. |
| Intrinsic toxicity | 58 | The whole plant/product or a constituent class has a material systemic, reproductive, neurologic, cardiac, hepatic, renal, genotoxic, or local-tissue hazard. |
| Hazardous route | 43 | Explicit ocular, otic, vaginal/mucosal, inhaled/smoked, or intranasal administration requires route-specific pharmaceutical development. |
| Identity and reproducibility | 42 | The heading is multi-species, broad, misspelled, synonymous, or otherwise not voucher-ready. |
| Drug interaction | 31 | High-confidence pharmacokinetic or pharmacodynamic interaction potential warrants dedicated screening. |
| Dangerous household product | 8 | A chemical, material, branded mixture, or microbiologically variable food is not an interchangeable botanical test article. |

## Severity and hard-stop semantics

- **Critical**: plausible death, irreversible injury, pregnancy/fetal harm, severe poisoning, major interaction, or a claim likely to replace emergency/essential care. Book-style human use is stopped.
- **High**: plausible serious injury, clinically important interaction, hazardous non-oral route, or a treatment claim for important disease. Advancement requires a formal control package.
- **Medium**: a meaningful research-quality or route risk that should be resolved before translation, but is not by itself a stop to laboratory discovery.
- **`hard_stop=TRUE`**: do not use the book preparation/claim in humans or as a substitute for care. It does **not** mean “discard every molecule”; it means any lead must be redefined as an authenticated, chemically controlled investigational article and re-enter development from the appropriate preclinical gate.

## Immediate high-risk clusters

### Toxic botanicals and constituent classes

Critical examples in the CSV include:

- **Tropane/antimuscarinic alkaloids:** henbane (LBHR-031, printed pp. 85–86) and thorn apple/Datura (LBHR-071, pp. 138–140). Datura poisoning can include delirium, arrhythmia, seizures, coma, and death; smoking does not make the exposure controlled. A modern program would isolate and quantify alkaloids and begin with formal neurocardiorespiratory toxicology, not crude dosing. [Datura review](https://pmc.ncbi.nlm.nih.gov/articles/PMC8389218/)
- **Potent cardiac/neurotoxic alkaloids:** false hellebore/Veratrum (LBHR-098, pp. 174–175), yellow jessamine/Gelsemium (LBHR-128, pp. 211–212), Indian tobacco/Lobelia (LBHR-105, pp. 184–185), and cardinal flower/Lobelia (LBHR-093, p. 169). [Veratrum review](https://pmc.ncbi.nlm.nih.gov/articles/PMC4217314/), [Gelsemium poisoning report](https://pubmed.ncbi.nlm.nih.gov/571907/)
- **Pyrrolizidine-alkaloid concern:** comfrey (LBHR-017), borage (LBHR-007), butterbur (LBHR-091), coltsfoot (LBHR-097), wild comfrey/hound's tongue (LBHR-122), plus other Boraginaceae/Asteraceae candidates requiring validated PA assays. FDA materials describe PA-associated illness and liver/lung injury, and separately identify comfrey as a PA concern. [FDA Bad Bug Book](https://www.fda.gov/files/food/published/Bad-Bug-Book-2nd-Edition-%28PDF%29.pdf), [FDA ingredient information](https://www.fda.gov/food/dietary-supplements/information-select-dietary-supplement-ingredients-and-other-substances)
- **Aristolochic-acid risk:** wild ginger/Asarum (LBHR-123, pp. 206–207). FDA identifies specified *Asarum* species among botanicals known or suspected to contain aristolochic acid, associated with irreversible renal injury and cancer risk. The research release criterion should be validated non-detection of aristolochic acids, not a common-name assumption. [FDA Import Alert 54-10](https://www.accessdata.fda.gov/cms_ia/importalert_141.html)
- **Cytotoxic/escharotic chemistry:** mayapple (LBHR-109, p. 189) and bloodroot (LBHR-089, pp. 164–165). These are discovery sources, not crude topical or systemic candidates; selectivity, genotoxicity, marrow/GI injury, and local tissue destruction are central. [Podophyllotoxin review](https://pubmed.ncbi.nlm.nih.gov/36586242/), [FDA warning on fraudulent cancer products](https://www.fda.gov/consumers/consumer-updates/products-claiming-cure-cancer-are-cruel-deception)
- **Concentrated salicylate, thujone, safrole, and cyanogenic hazards:** wintergreen oil (LBHR-126), wormwood/sage/cedar candidates, sassafras (LBHR-161), and elder/chokecherry candidates. These require constituent-specific lot release and exposure-margin work. [Methyl-salicylate toxicity](https://pubmed.ncbi.nlm.nih.gov/17239735/), [thujone toxicology](https://pubmed.ncbi.nlm.nih.gov/10725394/), [21 CFR §189.180 on safrole](https://www.ecfr.gov/current/title-21/chapter-I/subchapter-B/part-189/subpart-C/section-189.180)
- **Identity-driven poisoning risk:** Queen Anne's lace (LBHR-063, pp. 129–130) and osha (LBHR-111, pp. 191–193) require expert voucher authentication and explicit toxic-Apiaceae look-alike exclusion before chemistry. The book's contraceptive/pregnancy claim for Queen Anne's lace is independently a hard stop.
- **Other critical crude botanicals:** arnica, bleeding heart, blue cohosh, chaparral, horse chestnut, and western red cedar are detailed record-by-record in the CSV.

### Dangerous household products

The dedicated household entries flagged are activated charcoal (LBHR-183, p. 287), bleach (LBHR-184, p. 288), boric acid (LBHR-185, pp. 288–289), diatomaceous earth (LBHR-188, p. 292), Epsom salts (LBHR-189, pp. 292–293), Listerine (LBHR-190, p. 293), potassium permanganate (LBHR-191, pp. 293–294), and raw honey (LBHR-192, pp. 294–295).

Activated charcoal is a selective toxicology intervention rather than a general “detox”; a clinical position paper states that single-dose charcoal should not be administered routinely and highlights airway/aspiration concerns. Bleach and potassium permanganate are corrosive/oxidizing chemicals, not botanical leads. Brand-name mouthwash is a changeable multi-ingredient mixture. Raw honey is not interchangeable with a validated medical-grade wound product. [Activated-charcoal position paper](https://pubmed.ncbi.nlm.nih.gov/15822758/), [CDC chlorine facts](https://www.cdc.gov/chemical-emergencies/chemical-fact-sheets/chlorine.html), [PubChem sodium hypochlorite](https://pubchem.ncbi.nlm.nih.gov/compound/Sodium-Hypochlorite), [PubChem potassium permanganate](https://pubchem.ncbi.nlm.nih.gov/compound/Potassium-Permanganate)

### Hazardous routes found explicitly in the book

Route flags were based on administration language, not merely a disease or symptom word.

| Route | CSV route rows | Explicitly flagged records (printed pages) |
|---|---:|---|
| Ocular | 14 | LBHR-001 (45), 013 (60), 026 (78), 032 (88), 054 (118), 078 (149), 093 (169), 130 (216), 137 (225), 139 (228), 164 (258), 169 (265), 176 (278), 185 (288–289) |
| Otic | 3 | LBHR-005 (49), 052 (115), 185 (289) |
| Vaginal/mucosal | 8 | LBHR-080 (152), 085 (160), 100 (177), 102 (180), 165 (260), 176 (277–278), 185 (288), 191 (293) |
| Inhaled smoke | 7 | LBHR-052 (114–115), 069 (137), 071 (139), 084 (158), 105 (184), 110 (190), 111 (192) |
| Inhaled steam/volatile | 10 | LBHR-013 (60), 038 (95), 070 (138), 086 (161), 103 (182), 110 (190), 133 (219–220), 136 (224), 165 (260–261), 166 (262), 170 (266) |
| Intranasal powder | 1 | LBHR-118 (201) |

The inhaled steam/volatile row count is 10 even though 11 record appearances are listed because LBHR-110 has one combined route row whose evidence includes both smoke and steam claims and is classified as smoke. The CSV is the authoritative row-level representation.

Ophthalmic products must be sterile, and FDA also emphasizes particulate, container, manufacturing, and quality controls; boiling or calling a homemade wash “sterile” does not establish an ophthalmic drug product. Otic work needs tympanic-membrane safeguards. Vaginal/mucosal, intranasal, and inhaled work each require local-tolerance, dose-delivery, microbiological, and route-specific PK/toxicology packages. [FDA eye-drop safety](https://www.fda.gov/drugs/buying-using-medicine-safely/what-you-should-know-about-eye-drops), [FDA ophthalmic quality guidance](https://www.fda.gov/media/172937/download)

### Interaction-prone botanicals

Thirty-one high-confidence interaction rows are identified. The highest-priority are St. John's wort (LBHR-067, pp. 133–134) and goldenseal (LBHR-102, pp. 179–180). St. John's wort can alter exposure to many medicines, including life-saving drugs; goldenseal has evidence of CYP2D6/CYP3A4 inhibition. Other flagged pharmacodynamic families include salicylate/antiplatelet candidates, sedatives, glycemic agents, diuretics/electrolyte-altering herbs, uterotonic/endocrine herbs, and immunomodulators. [NCCIH St. John's wort](https://www.nccih.nih.gov/health/st-johns-wort), [NCCIH herb–drug interactions](https://www.nccih.nih.gov/health/providers/digest/herb-drug-interactions-science)

The CSV interaction flags are **screening priorities**, not final interaction labels. Advancement requires the exact extract/compound to be tested in CYP inhibition and time-dependent inhibition, induction, transporter panels, protein binding, reactive-metabolite work, and indication-specific pharmacodynamic combinations.

### Claims that could delay effective care

The book contains claims mapped to cancer/tumor (43 rows), serious infection (50), poisoning/envenomation (10), acute cardiovascular disease (5), chronic cardiovascular disease/hypertension (27), neurodegeneration/seizure (13), diabetes/glucose control (40), pregnancy/labor/hemorrhage (13), fertility/reproductive treatment (4), major bleeding (11), substance withdrawal (5), serious respiratory disease (23), and vision-threatening eye disease (17).

Traditional use is a source of hypotheses, not sufficient evidence for cure, treatment, or emergency management. Cancer complementary approaches should not replace or delay conventional care; suspected poisoning requires poison-center/emergency evaluation; infection claims require organism-specific susceptibility, selectivity, resistance, PK/PD, and in vivo evidence before any clinical inference. [NCCIH cancer guidance](https://www.nccih.nih.gov/health/cancer-and-complementary-health-approaches-what-you-need-to-know), [FDA cancer-fraud Q&A](https://www.fda.gov/consumers/health-fraud-scams/questions-and-answers-fda-alerts-companies-stop-illegal-sale-products-claiming-treat-cancer)

## Required research handling gates

1. **Identity gate:** accepted Latin binomial and author, plant part, voucher specimen, collection location/date, phenotype, DNA authentication where appropriate, contaminant and toxic-look-alike exclusion.
2. **Test-article gate:** controlled harvest and processing, extraction solvent/ratio, yield, chromatographic fingerprint, marker/active/toxin assays, residual solvents, pesticides, metals, microbes, mycotoxins, adulterants, and stability.
3. **Dereplication gate:** LC/GC-HRMS and NMR feature annotation; remove known assay interferers, aggregators, redox cyclers, fluorescent compounds, tannin-driven nonspecific hits, and already-known cytotoxins before claiming a novel mechanism.
4. **Mechanism gate:** orthogonal biochemical and cell assays; genetic perturbation/rescue; target engagement; concentration–response; time course; relevant cell type; counter-screens; free concentration and exposure realism.
5. **Route gate:** formulation, delivered dose, sterility/microbiology, pH/osmolality/particle size as applicable, local tolerance, deposition, absorption, and route-specific toxicokinetics.
6. **Safety gate:** broad cytotoxicity, genotoxicity, mitochondrial and ion-channel liabilities, liver/kidney/CNS/cardiovascular/reproductive signals, immunotoxicity, phototoxicity/sensitization, metabolite identification, and safety pharmacology.
7. **Interaction gate:** CYP/transporter panels plus pharmacodynamic combinations relevant to the proposed population; reconcile effects of the mixture versus isolated constituents.
8. **Translation gate:** disease-relevant in vivo or validated alternative models, blinded/randomized design, exposure-linked PK/PD, replication across authenticated batches, prespecified go/no-go criteria, and only then a regulated clinical protocol.

Mixtures require an additional design-of-experiments gate: checkerboard or response-surface testing over clinically attainable free concentrations, Bliss/Loewe/HSA/ZIP analyses as appropriate, dose-reduction and toxicity surfaces, batch fingerprinting, and confirmation that any apparent synergy survives orthogonal assays and PK constraints. A mixture is not more druggable merely because a crude combination gives a larger assay signal.

## False-positive and reliability audit

The claim and route mappings were deliberately tightened after a keyword audit:

- “Poison ivy/oak” is allergic contact dermatitis and is excluded from poisoning/envenomation mapping; snakebite, poisonous-mushroom ingestion, explicit poisoning, and similar emergency claims remain.
- “Aids in Digestion” is not the acronym AIDS; HIV/AIDS matching preserves acronym case.
- “Diabetic ulcers” does not by itself assert glucose lowering and is excluded from the diabetes-control class.
- Generic heart-health wording is not called acute cardiovascular disease. Acute mapping requires angina, heart attack, stroke, rapid heartbeat, or arrhythmia; hypertension/heart-disease claims are a separate class.
- Food-level advice to eat leeks during pregnancy is not treated as a replacement obstetric intervention.
- Generic wound “stop bleeding” claims are not labeled major bleeding. The major class requires internal bleeding, hemorrhage, heavy/excess menstrual bleeding, postpartum bleeding, or equivalent explicit evidence.
- Route detection requires administration language such as eye wash/drop, ear drop/canal, douche/suppository, smoke/steam inhalation, or snuff. Symptom phrases such as “vaginal dryness,” “nasal congestion,” or “helps breathe” do not establish a hazardous route.

The audit is intentionally conservative but is not a substitute for a monograph-by-monograph systematic toxicology review. Some `TOX_REVIEW`, `STANDARD_OF_CARE`, and `ROUTE_RISK` source codes denote triage conclusions that must be replaced by indication-, taxon-, extract-, and route-specific authoritative reviews before a development decision.

## Monographs without a selected audit trigger

No selected high-risk flag was generated for the following 18 records: LBHR-021 Dill; LBHR-034 Horseradish; LBHR-037 Lamb's Quarter; LBHR-042 Lemon Verbena; LBHR-044 Lovage; LBHR-046 Mallow; LBHR-048 Meadow Rue; LBHR-055 Peppermint; LBHR-068 Stinging Nettle; LBHR-092 California Buckwheat; LBHR-096 Club Moss; LBHR-106 Jewelweed; LBHR-120 Stone Root; LBHR-124 Wild Strawberries; LBHR-125 Wild Yam; LBHR-156 Quaking Aspen; LBHR-160 Salal; LBHR-179 Duckweed.

This list means only “no trigger under the chosen high-risk rules.” It does not establish safe dose, safe route, absence of interaction, efficacy, or suitability for human research. Each still requires the same identity, chemistry, contamination, pharmacology, and toxicology gates before advancement.
