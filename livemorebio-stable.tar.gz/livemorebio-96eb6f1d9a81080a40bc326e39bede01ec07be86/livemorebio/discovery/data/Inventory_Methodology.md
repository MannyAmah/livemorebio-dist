# Inventory methodology and extraction notes

## Scope and result

Source: *The Lost Book of Herbal Remedies* (`Lost_Book_Remedies_Com_newlnk 3.pdf`), 306 PDF pages. The inventory covers every dedicated remedy monograph in the printed-page range 44-296 (PDF pages 45-297). It does **not** treat the general harvesting/preparation chapters (printed pages 33-43) as remedy monographs. Recipe-only carriers and excipients such as water or alcohol remain visible in the JSON's extracted section text but are not promoted to independent remedy records.

The extraction found **193 unique monograph/remedy headings**, with no duplicate normalized headings:

| Book chapter | Records |
|---|---:|
| Backyard Plants | 79 |
| Forest, Scrublands, and Woodlands | 50 |
| Trees and Shrubs | 41 |
| Mushrooms and Lichens | 6 |
| Water-Loving Plants | 6 |
| Household Remedies | 11 |
| **Total** | **193** |

By material type, the inventory contains 176 plant monographs, 4 mushroom/fungus monographs, 2 lichen monographs, and 11 household-remedy monographs. The household chapter contains three plant-derived records (Cayenne Pepper, Cinnamon, and Turmeric/Curcumin) and eight non-plant/animal/mixed or processed records: Activated Charcoal, Bleach, Boric Acid, Diatomaceous Earth, Epsom Salts, Listerine, Potassium Permanganate, and Raw Honey.

## Extraction method

1. Read the PDF's embedded text layer with PyMuPDF; OCR was not required.
2. Located each remedy heading from its 18.96-20.04 point title typography, then checked the resulting sequence against all 193 table-of-contents entries. Start-page matching was exact for all records.
3. Preserved both printed book pages and 1-based PDF pages. In this file, PDF page number = printed book page + 1 throughout the remedy chapters.
4. Used italic versus nonitalic title runs to separate scientific names from common-name text. The JSON retains the original styled name runs so uncertain parsing can be audited.
5. Extracted bold medicinal-use headings and their associated text blocks. Formula, harvesting, identification, warning, dosage, and other-use headings were classified separately. The claim-section table contains **1,180** book-claim headings; these are transcriptions of claims, not validated indications.
6. Mechanically detected preparation forms, routes, and plant parts from explicit wording. These fields are discovery aids and should be checked against the accompanying claim text before use.
7. Captured introductory sentences containing alias cues such as “also known as” or “also called” (119 records contain such evidence). A manually curated field links 25 entries with potentially confusable names; these links do not assert that the organisms are synonyms.

## Text and layout issues

- The source has a good embedded text layer, but it is a two-column book with images. Line-wrap hyphenation and a few headings split across separate PDF text blocks required repair.
- Dill uses a slightly smaller 18.96 point title than the other monographs and was explicitly included.
- Some recipe tails and the next remedy title share one PDF text block; segmentation was performed at the styled title span rather than at the block boundary.
- Chapter-level mushroom extraction instructions on printed page 268 were excluded from the preceding Witch Hazel record.
- Scientific typography is not perfectly consistent. For example, the decorative initial “M” in *Moringa oleifera* is nonitalic in the PDF, and “spp.” is sometimes set outside the italic run. These were normalized in the convenience field while the raw style runs were retained.
- Exact prose is lightly normalized only for whitespace and line-break hyphenation. It has not been rewritten or medically interpreted.

## Ambiguous or research-critical names

Forty-two records carry at least one name/taxonomy flag. Important examples include:

- **Red Clover — “Trifolium pretense”**: likely a book typo for *Trifolium pratense*; verify against an authoritative taxonomic source.
- **Usnea Lichen**: no species is supplied.
- **Genus-level/multi-species headings**: Goldenrod (*Solidago* spp.), Violets (*Viola* spp. plus named species), Red Root (*Ceanothus* spp.), Solomon's Seal (*Polygonatum* spp.), Birch (*Betula* spp.), Juniper (*Juniperus* spp.), Wild Rose (*Rosa* spp.), and Cattails (*Typha* spp.).
- **Alternative or historical names in one heading**: Lady's Thumb, Fireweed, False Solomon's Seal, Bearberry, Cascara Sagrada, Oregon Grape, Devil's Club, Turkey Tail, and others. These must be resolved to an accepted taxon and voucher specimen before chemistry or pharmacology work.
- **Broad product names**: Aloe Vera, Cayenne Pepper, Cinnamon, and Turmeric/Curcumin are not sufficiently specific on their own for reproducible drug-discovery work.
- **Confusable common-name pairs/groups** are linked in the files, including Common Lungwort Plant vs Lungwort Lichen; Comfrey vs Wild Comfrey; Solomon's Seal vs False Solomon's Seal; Unicorn Root vs False Unicorn Root; Plantain vs Water Plantain; Sage vs White Sage; and blue/black vs red elderberry.

## Files

- `plant_medicine_inventory.csv`: one normalized row per monograph (193 rows).
- `plant_medicine_inventory.json`: full nested inventory, including title-style runs, alias evidence, extracted claim sections, pages, detected preparations/routes, and ambiguity flags.
- `plant_medicine_inventory_claim_sections.csv`: one row per extracted medicinal claim heading (1,180 rows), with concise page and preparation/route context.
- `build_inventory.py`: reproducible extraction script.

## Scientific-use warning

All “claimed uses” are claims made by the source book. They are not evidence of efficacy, safety, druggability, correct dose, correct identification, or regulatory acceptability. The inventory is a source map for subsequent taxonomic normalization, evidence review, chemical dereplication, and experimental prioritization.
