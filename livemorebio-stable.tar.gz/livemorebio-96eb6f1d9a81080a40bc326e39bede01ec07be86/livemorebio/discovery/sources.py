"""Real chemistry sources for the plant-compound discovery engine.
PubChem PUG-REST (compound identity) + ChEMBL (drug-likeness / development phase).
Both key-free, cached via the reference Source base. Target-activity endpoints are
wired api-ready; target *prediction* here uses curated phytopharmacology + pathway
matching (honest — labelled as literature evidence)."""
from __future__ import annotations
from ..life_system.reference.sources.base import Source


class PubChem(Source):
    name = "pubchem"
    base = "https://pubchem.ncbi.nlm.nih.gov/rest/pug/"

    def compound(self, name):
        d = self.fetch(f"compound/name/{name.replace(' ', '%20')}/property/"
                       "MolecularFormula,MolecularWeight,CanonicalSMILES,InChIKey/JSON")
        if not isinstance(d, dict) or "PropertyTable" not in d:
            return None
        p = d["PropertyTable"]["Properties"][0]
        return dict(name=name, cid=p.get("CID"), formula=p.get("MolecularFormula"),
                    mw=float(p.get("MolecularWeight", 0) or 0),
                    smiles=p.get("CanonicalSMILES") or p.get("ConnectivitySMILES"),
                    inchikey=p.get("InChIKey"))


class ChEMBL(Source):
    name = "chembl"
    base = "https://www.ebi.ac.uk/chembl/api/data/"

    def molecule(self, name):
        d = self.fetch("molecule/search", params={"q": name, "format": "json"})
        mols = (d or {}).get("molecules", [])
        if not mols:
            return None
        m = mols[0]
        return dict(chembl_id=m.get("molecule_chembl_id"), pref_name=m.get("pref_name"),
                    max_phase=m.get("max_phase"),
                    qed=(m.get("molecule_properties") or {}).get("qed_weighted"))

    def mechanisms(self, chembl_id):
        d = self.fetch("mechanism.json", params={"molecule_chembl_id": chembl_id})
        return [(x.get("mechanism_of_action"), x.get("target_chembl_id"))
                for x in (d or {}).get("mechanisms", [])]
