"""Bounded, isolated Human-GEM capacity calculations, never person physiology.

Solve S*v=0 with explicit exchange bounds while maximizing ATP maintenance.
An optimal capacity is not a measured ATP pool, a kinetic rate law, or proof that
a physical cell chooses this objective. No legacy gene-scaling bridge is used.
"""
from __future__ import annotations

from collections import defaultdict
from contextlib import redirect_stdout
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
import time
import stat
from typing import Any

ATP_OBJECTIVE = "MAR03964"
GLUCOSE_EXCHANGE = "MAR09034"
OXYGEN_EXCHANGE = "MAR09048"
UNIT = "mmol/gDW/h"
HARD_TIMEOUT_SECONDS = 120
SOLVER_TIMEOUT_SECONDS = 10
_EXECUTION_LOCK = threading.Lock()
_GENE = re.compile(r"ENSG[0-9]{11}")
_CONDITION = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}")


class StoichiometryError(ValueError):
    def __init__(self, message: str, code: str = "INVALID_CONSTRAINTS") -> None:
        super().__init__(message)
        self.code = code


def runtime_capabilities() -> dict:
    """Dependency readiness only: importing a solver does not qualify a model."""
    result = {"available": False, "solver": "GLPK", "cobra_version": None,
              "glpk_version": None, "reason": "Install the supported kernels extra.",
              "scope": "dependency_readiness_only"}
    try:
        import swiglpk
        import cobra
        result.update(available="glpk" in cobra.util.solver.solvers,
                      cobra_version=importlib.metadata.version("cobra"),
                      glpk_version=swiglpk.glp_version())
        result["reason"] = "GLPK dependency available; asset and calculation QC are separate gates."
    except (ImportError, importlib.metadata.PackageNotFoundError):
        pass
    return result


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def _bound(value: object, high: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise StoichiometryError("uptake bounds require finite numeric values")
    try:
        number = float(value)
    except OverflowError as error:
        raise StoichiometryError("uptake bound is outside the allowed range") from error
    if not math.isfinite(number) or not 0 <= number <= high:
        raise StoichiometryError("uptake bound is outside the allowed range")
    return number


def validate_spec(spec: object) -> dict:
    if not isinstance(spec, dict) or set(spec) - {"model_id", "conditions", "knockout_gene_ids"}:
        raise StoichiometryError("only model, explicit conditions and complete gene knockouts are supported")
    if spec.get("model_id", "human-gem") != "human-gem":
        raise StoichiometryError("only the pinned human-gem model is executable", "MODEL_UNAVAILABLE")
    conditions = spec.get("conditions")
    if not isinstance(conditions, list) or not 1 <= len(conditions) <= 6:
        raise StoichiometryError("provide one to six explicit conditions")
    normalized, seen = [], set()
    for condition in conditions:
        if not isinstance(condition, dict) or set(condition) != {"condition_id", "glucose_uptake", "oxygen_uptake"}:
            raise StoichiometryError("each condition requires only its identity and glucose/oxygen bounds")
        identity = condition["condition_id"]
        if (not isinstance(identity, str) or not _CONDITION.fullmatch(identity)
                or identity in seen or identity in {"control-closed-medium", "control-no-glucose"}):
            raise StoichiometryError("condition identities must be unique bounded identifiers")
        seen.add(identity)
        normalized.append({"condition_id": identity,
                           "glucose_uptake": _bound(condition["glucose_uptake"], 10),
                           "oxygen_uptake": _bound(condition["oxygen_uptake"], 1000)})
    genes = spec.get("knockout_gene_ids", [])
    if (not isinstance(genes, list) or len(genes) > 5
            or any(not isinstance(gene, str) or not _GENE.fullmatch(gene) for gene in genes)
            or len(set(genes)) != len(genes)):
        raise StoichiometryError("provide at most five unique exact Ensembl gene IDs for complete knockouts")
    return {"model_id": "human-gem", "conditions": normalized, "knockout_gene_ids": sorted(genes)}


def _solve_condition(model: Any, condition: dict, genes: list[str]) -> dict:
    with model:
        # Boundary reactions can encode production with either sign. Close the
        # producing direction, not just negative lower bounds or named exchanges.
        for reaction in model.boundary:
            coefficients = list(reaction.metabolites.values())
            if len(coefficients) != 1:
                raise StoichiometryError("ambiguous boundary reaction", "MODEL_QC_FAILED")
            if coefficients[0] < 0:
                reaction.bounds = max(0.0, reaction.lower_bound), max(0.0, reaction.upper_bound)
            else:
                reaction.bounds = min(0.0, reaction.lower_bound), min(0.0, reaction.upper_bound)
        for identity, capacity in ((GLUCOSE_EXCHANGE, condition["glucose_uptake"]),
                                   (OXYGEN_EXCHANGE, condition["oxygen_uptake"])):
            reaction = model.reactions.get_by_id(identity)
            coefficients = list(reaction.metabolites.values())
            if len(coefficients) != 1 or coefficients[0] != -1:
                raise StoichiometryError("pinned exchange direction does not match the protocol", "MODEL_QC_FAILED")
            reaction.lower_bound = -capacity
        for identity in genes:
            model.genes.get_by_id(identity).knock_out()
        model.objective = ATP_OBJECTIVE
        model.objective.direction = "max"
        solution = model.optimize()
        if solution.status != "optimal":
            raise StoichiometryError("solver did not return an optimal bounded result", "SOLVER_FAILED")
        objective = float(solution.objective_value)
        if not math.isfinite(objective):
            raise StoichiometryError("solver returned a nonfinite objective", "SOLVER_FAILED")
        residuals: dict[str, float] = defaultdict(float)
        bound_residual = 0.0
        fluxes = {}
        for reaction in model.reactions:
            flux = float(solution.fluxes[reaction.id])
            if not math.isfinite(flux):
                raise StoichiometryError("solver returned a nonfinite flux", "SOLVER_FAILED")
            fluxes[reaction.id] = flux
            bound_residual = max(bound_residual, reaction.lower_bound - flux, flux - reaction.upper_bound)
            for metabolite, coefficient in reaction.metabolites.items():
                residuals[metabolite.id] += coefficient * flux
        mass_residual = max((abs(value) for value in residuals.values()), default=0.0)
        if mass_residual > 1e-6 or bound_residual > 1e-6 or objective < -1e-6:
            raise StoichiometryError("stoichiometric or constraint residual failed tolerance", "MODEL_QC_FAILED")
        constraints = {**condition, "knockout_gene_ids": genes,
                       "objective": ATP_OBJECTIVE, "direction": "max",
                       "unlisted_uptake": "closed", "unit": UNIT}
        return {"condition_id": condition["condition_id"], "constraints": constraints,
                "constraints_sha256": canonical_hash(constraints), "solver_status": solution.status,
                "objective_flux": objective, "actual_glucose_uptake": max(0.0, -fluxes[GLUCOSE_EXCHANGE]),
                "actual_oxygen_uptake": max(0.0, -fluxes[OXYGEN_EXCHANGE]),
                "exchange_fluxes": [{"reaction_id": identity, "flux": fluxes[identity], "unit": UNIT}
                                    for identity in (GLUCOSE_EXCHANGE, OXYGEN_EXCHANGE)],
                "mass_balance_residual": mass_residual, "bound_residual": bound_residual,
                "fva_status": "not_computed", "flux_uniqueness": "not_established"}


def solve_model(model: Any, spec: dict) -> dict:
    """Internal solver contract. Caller owns the model; condition contexts restore it."""
    spec = validate_spec(spec)
    for identity in (ATP_OBJECTIVE, GLUCOSE_EXCHANGE, OXYGEN_EXCHANGE):
        if identity not in model.reactions:
            raise StoichiometryError("pinned reaction identity is missing", "MODEL_QC_FAILED")
    if any(identity not in model.genes for identity in spec["knockout_gene_ids"]):
        raise StoichiometryError("requested gene is not present in the pinned model")
    model.solver = "glpk"
    configuration = model.solver.configuration
    previous_timeout = configuration.timeout
    previous_feasibility = configuration.tolerances.feasibility
    previous_optimality = configuration._smcp.tol_dj
    configuration.timeout = SOLVER_TIMEOUT_SECONDS
    configuration.tolerances.feasibility = 1e-7
    # optlang exposes feasibility but not GLPK's simplex reduced-cost tolerance.
    # Preserve the native setting; the bounded worker uses the GLPK interface.
    configuration._smcp.tol_dj = 1e-7
    try:
        controls = []
        for condition in (
            {"condition_id": "control-closed-medium", "glucose_uptake": 0.0, "oxygen_uptake": 0.0},
            {"condition_id": "control-no-glucose", "glucose_uptake": 0.0, "oxygen_uptake": 1000.0},
        ):
            row = _solve_condition(model, condition, spec["knockout_gene_ids"])
            row["passed"] = abs(row["objective_flux"]) <= 1e-6
            if not row["passed"]:
                raise StoichiometryError("negative energy control failed", "MODEL_QC_FAILED")
            controls.append(row)
        rows = [_solve_condition(model, condition, spec["knockout_gene_ids"]) for condition in spec["conditions"]]
        import swiglpk
        import libsbml
        return {"conditions": rows, "controls": controls,
                "solver": {"name": "GLPK", "cobra_version": importlib.metadata.version("cobra"),
                           "glpk_version": swiglpk.glp_version(), "libsbml_version": libsbml.getLibSBMLDottedVersion(),
                           "optlang_version": importlib.metadata.version("optlang"),
                           "feasibility_tolerance": 1e-7, "optimality_tolerance": 1e-7, "residual_tolerance": 1e-6,
                           "optimization_timeout_seconds": SOLVER_TIMEOUT_SECONDS}}
    finally:
        configuration.timeout = previous_timeout
        configuration.tolerances.feasibility = previous_feasibility
        configuration._smcp.tol_dj = previous_optimality


def _worker(spec: dict) -> dict:
    from ..model_assets import verified_asset, annotation_rows
    import cobra

    asset = verified_asset("human-gem")
    model = cobra.io.read_sbml_model(asset["xml_path"])
    actual_counts = {"reactions": len(model.reactions), "metabolites": len(model.metabolites),
                     "genes": len(model.genes), "compartments": len(model.compartments)}
    manifest = asset["manifest"]
    if (actual_counts != manifest["expected_counts"] or manifest["flux_unit"] != "mmol_per_gDW_per_hr"
            or manifest["expected_ids"] != {"objective": ATP_OBJECTIVE, "glucose": GLUCOSE_EXCHANGE, "oxygen": OXYGEN_EXCHANGE}):
        raise StoichiometryError("parsed model does not match the pinned scientific contract", "MODEL_QC_FAILED")
    result = solve_model(model, spec)
    # Never serialize the private model cache path or caller environment.
    result["model"] = {key: asset[key] for key in ("model_id", "release", "commit", "model_sha256", "manifest_sha256", "license") if key in asset}
    result["model"]["counts"] = actual_counts
    selected = [model.reactions.get_by_id(identity) for identity in (ATP_OBJECTIVE, GLUCOSE_EXCHANGE, OXYGEN_EXCHANGE)]
    metabolite_ids = sorted({metabolite.id for reaction in selected for metabolite in reaction.metabolites})
    gene_ids = sorted(set(spec["knockout_gene_ids"]) | {gene.id for reaction in selected for gene in reaction.genes})
    result["reference_provenance"] = {
        "reactions": annotation_rows("reactions", [reaction.id for reaction in selected]),
        "metabolites": annotation_rows("metabolites", metabolite_ids),
        "genes": annotation_rows("genes", gene_ids) if gene_ids else {"rows": [], "evidence_class": "REFERENCE_MODEL_ANNOTATION"},
        "graph": {"evidence_class": "REFERENCE_STOICHIOMETRIC_STRUCTURE", "projection": "selected pinned reactions only",
                  "reactions": [{"reaction_id": reaction.id, "gene_reaction_rule": reaction.gene_reaction_rule,
                                 "stoichiometry": [{"metabolite_id": metabolite.id, "coefficient": coefficient,
                                                    "compartment": metabolite.compartment}
                                                   for metabolite, coefficient in reaction.metabolites.items()]}
                                for reaction in selected]},
        "use": "Reference cross-references are not measured reactions, physiological coefficients or automatic external graph writes.",
    }
    return result


def _process_lock() -> int:
    import fcntl
    from ..model_assets import execution_lock_path
    path = execution_lock_path()
    descriptor = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    info = os.fstat(descriptor)
    if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
            or info.st_nlink != 1 or stat.S_IMODE(info.st_mode) != 0o600):
        os.close(descriptor)
        raise StoichiometryError("model execution lock is unsafe", "MODEL_UNAVAILABLE")
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as error:
        os.close(descriptor)
        raise StoichiometryError("another metabolic model experiment is running", "MODEL_BUSY") from error
    except OSError:
        os.close(descriptor)
        raise
    return descriptor


def execute(spec: object) -> dict:
    from ..model_assets import ModelAssetError
    normalized = validate_spec(spec)
    if not _EXECUTION_LOCK.acquire(blocking=False):
        raise StoichiometryError("another metabolic model experiment is running", "MODEL_BUSY")
    started = time.monotonic()
    process = None
    lock_descriptor = None
    try:
        try:
            lock_descriptor = _process_lock()
        except (OSError, ValueError, ModelAssetError) as error:
            if isinstance(error, StoichiometryError):
                raise
            raise StoichiometryError("model execution storage is unavailable", "MODEL_UNAVAILABLE") from error
        process = subprocess.Popen([sys.executable, "-m", __name__, "--worker"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            cwd=Path(__file__).resolve().parents[2], env=dict(os.environ))
        try:
            output, _ = process.communicate(json.dumps(normalized, allow_nan=False).encode(), timeout=HARD_TIMEOUT_SECONDS)
        except subprocess.TimeoutExpired as error:
            process.kill()
            process.communicate()
            raise StoichiometryError("metabolic computation exceeded its hard deadline", "MODEL_EXECUTION_TIMEOUT") from error
        if len(output) > 2_000_000:
            raise StoichiometryError("metabolic result exceeds the bounded response", "MODEL_EXECUTION_FAILED")
        try:
            response = json.loads(output)
        except (ValueError, UnicodeError) as error:
            raise StoichiometryError("metabolic worker returned an invalid result", "MODEL_EXECUTION_FAILED") from error
        if process.returncode or not isinstance(response, dict) or "error" in response:
            code = response.get("code", "MODEL_EXECUTION_FAILED") if isinstance(response, dict) else "MODEL_EXECUTION_FAILED"
            allowed = {"INVALID_CONSTRAINTS", "MODEL_UNAVAILABLE", "MODEL_QC_FAILED", "SOLVER_FAILED"}
            raise StoichiometryError("metabolic worker could not complete the qualified calculation", code if code in allowed else "MODEL_EXECUTION_FAILED")
        response["elapsed_computation_seconds"] = round(time.monotonic() - started, 3)
        return response
    finally:
        if process is not None and process.poll() is None:
            process.kill()
            process.communicate()
        if lock_descriptor is not None:
            os.close(lock_descriptor)
        _EXECUTION_LOCK.release()


def _main() -> int:
    from ..strict_json import parse_json_object
    try:
        spec = validate_spec(parse_json_object(sys.stdin.buffer.read(2_000_001)))
        with redirect_stdout(sys.stderr):
            result = _worker(spec)
        sys.stdout.write(json.dumps(result, allow_nan=False, separators=(",", ":")))
        return 0
    except Exception as error:
        code = getattr(error, "code", "MODEL_EXECUTION_FAILED")
        if type(error).__name__ == "ModelAssetError":
            code = "MODEL_UNAVAILABLE"
        sys.stdout.write(json.dumps({"error": "metabolic calculation unavailable", "code": code}))
        return 1


if __name__ == "__main__":
    raise SystemExit(_main())
