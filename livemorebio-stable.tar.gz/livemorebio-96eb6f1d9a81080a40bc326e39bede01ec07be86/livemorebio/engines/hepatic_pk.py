"""
livemorebio.engines.hepatic_pk — individualized oral pharmacokinetics (dose → exposure).

The missing link in dose→exposure→effect (audit §6.1): a one-compartment oral PK
model with first-order absorption — the analytic Bateman solution, the standard
first PK model in clinical pharmacology — individualized by the twin's biology:

  - renal clearance: scaled by an age-derived renal-function factor (the same
    eGFR proxy pharmacology.py uses), dominant route for renally-cleared drugs
    such as metformin (excreted unchanged in urine; Graham et al.,
    Clin Pharmacokinet 2011).
  - hepatic uptake: OCT1 / SLC22A1 reduced-function alleles gate how much of
    the circulating drug actually reaches hepatocytes (Shu et al., J Clin
    Invest 2007) — so plasma exposure and hepatic (effect-site) exposure are
    reported SEPARATELY and honestly.
  - hepatic metabolism: for CYP-cleared compounds, a genotype-derived CYP
    activity factor scales intrinsic hepatic clearance (reduced-function
    alleles → lower clearance → higher plasma exposure).
  - body weight scales the distribution volume.

Units are explicit everywhere: dose [mg], concentrations [mg/L], time [h],
clearance [L/h], volume [L], AUC [mg·h/L]. Parameters are literature-informed
population-typical values, NOT fitted to an individual — this is mechanistic
hypothesis-triage PK, not clinical dosing guidance, and every result says so.
"""
from __future__ import annotations
import math

# ---------------------------------------------------------------------------
# Drug parameter library (population-typical oral PK, literature-informed).
#   F        reported oral bioavailability (fraction; contextual only when
#            apparent V/F and CL/F parameters are used)
#   ka_h     first-order absorption rate constant [1/h]
#   V_L     apparent distribution volume V/F for 70 kg [L]
#   CL_L_h  apparent clearance CL/F for a reference adult [L/h]
#   cleared_by   "renal" | "hepatic-cyp"  (which factor individualizes CL)
#   ref_dose_mg  reference single dose for exposure ratios
# Metformin: F≈0.55, negligible metabolism, renal excretion of unchanged drug,
# CL/F ≈ 68 L/h, V/F ≈ 300 L, plasma t1/2 ≈ 3 h (Graham 2011, Clin Pharmacokinet).
# ---------------------------------------------------------------------------
DRUGS = {
    "metformin": dict(F=0.55, ka_h=0.9, V_L=300.0, CL_L_h=68.0,
                      cleared_by="renal", ref_dose_mg=1000.0,
                      uptake_gene="SLC22A1_lof",
                      citation="Graham et al. 2011 Clin Pharmacokinet; Shu et al. 2007 J Clin Invest"),
}

# OCT1/SLC22A1 reduced-function alleles (0/1/2) → hepatic uptake fraction.
# Same gating pharmacology.py uses, so the platform speaks one number.
OCT1_TRANSPORT = (1.0, 0.60, 0.32)

# CYP reduced-function alleles (0/1/2) → intrinsic hepatic clearance factor.
CYP_ACTIVITY = (1.0, 0.60, 0.35)


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


def renal_factor(age: float) -> float:
    """Age-derived renal-function proxy (same shape as pharmacology.py)."""
    return _clamp(1.0 - max(0.0, age - 60.0) / 120.0, 0.6, 1.0)


def _bateman(t_h, dose_mg, F, ka, ke, V):
    """Analytic 1-compartment oral concentration [mg/L] at time t [h]."""
    if abs(ka - ke) < 1e-9:
        ke = ke * (1 + 1e-6)
    coef = (F * dose_mg * ka) / (V * (ka - ke))
    return coef * (math.exp(-ke * t_h) - math.exp(-ka * t_h))


def pk_profile(drug: str, dose_mg: float, human=None, hours: float = 24.0,
               n_points: int = 97) -> dict:
    """Dose → individualized exposure for the given human (or reference adult).

    Returns the full concentration-time series plus Cmax/Tmax/t1/2/AUC, the
    exposure ratio vs the reference adult at the drug's reference dose, and the
    hepatic (effect-site) exposure ratio after OCT1 gating. Honest model-only
    framing in `note`.
    """
    if not isinstance(drug, str) or not drug.strip():
        raise ValueError("drug must be a non-empty string")
    try:
        dose_mg = float(dose_mg)
        hours = float(hours)
        n_points = int(n_points)
    except (TypeError, ValueError) as exc:
        raise ValueError("dose_mg, hours, and n_points must be numeric") from exc
    if not math.isfinite(dose_mg) or dose_mg <= 0:
        raise ValueError("dose_mg must be finite and greater than zero")
    if not math.isfinite(hours) or hours <= 0:
        raise ValueError("hours must be finite and greater than zero")
    if n_points < 2 or n_points > 10_000:
        raise ValueError("n_points must be between 2 and 10000")

    key = drug.strip().lower()
    if key not in DRUGS:
        from .integrity import UnsupportedInterventionError

        raise UnsupportedInterventionError("No qualified compound-specific pharmacokinetic model is available")
    p = DRUGS[key]
    genome = getattr(human, "genome", {}) if human else {}
    try:
        age = float(getattr(human, "age", 50) if human else 50)
        weight = float(getattr(human, "weight_kg", 70.0) if human else 70.0)
    except (TypeError, ValueError) as exc:
        raise ValueError("age and weight_kg must be numeric") from exc
    if not math.isfinite(age):
        raise ValueError("age must be finite")
    if not math.isfinite(weight) or weight <= 0:
        raise ValueError("weight_kg must be finite and greater than zero")

    # --- individualized parameters -----------------------------------------
    rf = renal_factor(age)
    try:
        cyp_lof = int(genome.get("CYP_reduced", 0))
    except (TypeError, ValueError) as exc:
        raise ValueError("CYP_reduced allele count must be an integer") from exc
    cyp_lof = int(_clamp(cyp_lof, 0, 2))
    cyp = CYP_ACTIVITY[cyp_lof]
    if p["cleared_by"] == "renal":
        CL = p["CL_L_h"] * rf                       # renal impairment → lower CL
        clearance_factor = rf
    else:
        CL = p["CL_L_h"] * cyp                      # CYP LoF → lower hepatic CL
        clearance_factor = cyp
    V = p["V_L"] * (weight / 70.0)
    ka, F = p["ka_h"], p["F"]
    ke = CL / V                                     # elimination rate [1/h]

    # --- series + summary metrics ------------------------------------------
    ts = [hours * i / (n_points - 1) for i in range(n_points)]
    # V and CL are apparent oral parameters (V/F and CL/F), so applying F a
    # second time would understate absolute exposure. The Bateman/AUC equations
    # therefore use unit apparent bioavailability; F is reported as context.
    cs = [_bateman(t, dose_mg, 1.0, ka, ke, V) for t in ts]
    cmax = max(cs)
    tmax = ts[cs.index(cmax)]
    auc = dose_mg / CL                              # analytic AUC0-inf [mg·h/L]
    t_half = math.log(2) / ke

    # --- exposure ratios (vs reference adult at reference dose) ------------
    auc_ref = p["ref_dose_mg"] / p["CL_L_h"]
    exposure_ratio = auc / auc_ref
    try:
        oct1_lof = int(genome.get(p["uptake_gene"], 0)) if p.get("uptake_gene") else 0
    except (TypeError, ValueError) as exc:
        raise ValueError("OCT1 allele count must be an integer") from exc
    oct1_lof = int(_clamp(oct1_lof, 0, 2))
    transport = OCT1_TRANSPORT[oct1_lof]
    hepatic_exposure_ratio = exposure_ratio * transport

    return {
        "drug": key, "dose_mg": round(float(dose_mg), 1),
        "model": "1-compartment oral (Bateman), analytic",
        "params": {"reported_F": F, "ka_per_h": ka, "V_over_F_L": round(V, 1),
                   "CL_over_F_L_per_h": round(CL, 2), "ke_per_h": round(ke, 4),
                   "cleared_by": p["cleared_by"]},
        "individualization": {"age": age, "weight_kg": weight,
                              "renal_factor": round(rf, 3),
                              "cyp_reduced_alleles": cyp_lof,
                              "cyp_activity": round(cyp, 2),
                              "clearance_factor": round(clearance_factor, 3),
                              "oct1_lof_alleles": oct1_lof,
                              "oct1_transport": round(transport, 2)},
        "t_h": [round(t, 3) for t in ts],
        "conc_mg_L": [round(c, 4) for c in cs],
        "cmax_mg_L": round(cmax, 4), "tmax_h": round(tmax, 2),
        "t_half_h": round(t_half, 2), "auc_mg_h_L": round(auc, 2),
        "exposure_ratio": round(exposure_ratio, 3),
        "hepatic_exposure_ratio": round(hepatic_exposure_ratio, 3),
        "curated": key in DRUGS,
        "citation": p["citation"],
        "note": ("model-only individualized PK (literature-typical population "
                 "parameters, not fitted to this person; not dosing guidance)"),
    }
