"""
livemorebio.engines._cellml
===========================
Host any Physiome / CellML 2.0 model as a live ODE system inside LivemoreBio.

Pipeline (real libCellML 0.7 workflow):
    CellML text -> Parser -> Analyser -> Generator(Python profile)
                -> generated Python -> SciPy-integrated live model.

This is the substrate that lets LivemoreBio run published organ/cell models
(cardiac, renal, endocrine, ...) natively. We own the state engine and coupling;
the numerical model comes from the peer-reviewed CellML source.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional
import numpy as np
from scipy.integrate import solve_ivp
import libcellml as C


def _issues(obj) -> List[str]:
    out = []
    for i in range(obj.issueCount()):
        out.append(obj.issue(i).description())
    return out


@dataclass
class HostedCellMLModel:
    ns: dict
    state_names: List[str]
    name: str

    def _fresh(self):
        s = self.ns["create_states_array"]()
        r = self.ns["create_states_array"]()
        c = self.ns["create_constants_array"]()
        cc = self.ns["create_computed_constants_array"]()
        a = self.ns["create_algebraic_variables_array"]()
        self.ns["initialise_arrays"](s, r, c, cc, a)
        self.ns["compute_computed_constants"](0.0, s, r, c, cc, a)
        return s, r, c, cc, a

    def initial_states(self) -> np.ndarray:
        s, *_ = self._fresh()
        return np.array(s, dtype=float)

    def simulate(self, duration: float, dt: float = 0.1,
                 overrides: Optional[dict] = None, method: str = "LSODA") -> dict:
        s0, r, c, cc, a = self._fresh()
        if overrides:                       # override constants by index
            for idx, val in overrides.items():
                c[idx] = val
            self.ns["compute_computed_constants"](0.0, list(s0), r, c, cc, a)

        def rhs(t, y):
            rates = [0.0] * len(y)
            self.ns["compute_rates"](t, list(y), rates, c, cc, a)
            return rates

        t_eval = np.arange(0.0, duration + dt, dt)
        sol = solve_ivp(rhs, (0.0, duration), list(s0), t_eval=t_eval,
                        method=method, rtol=1e-6, atol=1e-8, max_step=1.0)
        if not sol.success:
            raise RuntimeError(f"CellML integration failed: {sol.message}")
        return dict(t=sol.t, y=sol.y, states={n: sol.y[i]
                    for i, n in enumerate(self.state_names)}, name=self.name)


def host_cellml(cellml_text: str) -> HostedCellMLModel:
    parser = C.Parser()
    model = parser.parseModel(cellml_text)
    if parser.errorCount():
        raise ValueError("CellML parse errors: " + "; ".join(_issues(parser)))
    analyser = C.Analyser()
    analyser.analyseModel(model)
    if analyser.errorCount():
        raise ValueError("CellML analyse errors: " + "; ".join(_issues(analyser)))
    am = analyser.analyserModel()
    gen = C.Generator()
    code = gen.implementationCode(am, C.GeneratorProfile(C.GeneratorProfile.Profile.PYTHON))
    ns: dict = {}
    exec(compile(code, "<cellml-generated>", "exec"), ns)
    names = []
    for i in range(am.stateCount()):
        try:
            names.append(am.state(i).variable().name())
        except Exception:
            names.append(f"state_{i}")
    return HostedCellMLModel(ns=ns, state_names=names, name=model.name())
