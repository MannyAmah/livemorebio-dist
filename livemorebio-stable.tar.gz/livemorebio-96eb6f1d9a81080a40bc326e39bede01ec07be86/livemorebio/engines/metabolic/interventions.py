"""Interventions applied to a metabolic profile for Cendos in-silico assays.
Effects are mechanism-directional (documented sign), magnitudes illustrative."""
from __future__ import annotations
from dataclasses import replace
from .glucose_insulin import MetabolicProfile


def metformin(profile: MetabolicProfile, dose: float = 1.0) -> MetabolicProfile:
    """Metformin: lowers hepatic glucose output (basal Gb) and improves insulin
    sensitivity (Si). Dose in [0,1] scales the effect."""
    return replace(profile, name=f"{profile.name}+metformin",
                   Gb=profile.Gb * (1 - 0.10 * dose),
                   Si=profile.Si * (1 + 0.30 * dose))


def plant_compound(profile: MetabolicProfile, name: str = "compound",
                   si_boost: float = 0.0, gb_drop: float = 0.0,
                   gamma_boost: float = 0.0) -> MetabolicProfile:
    """User-entered effect sliders do not qualify a biological intervention."""
    from ..integrity import UnsupportedInterventionError

    raise UnsupportedInterventionError(
        "No qualified plant-compound model is available; supplied benefit coefficients "
        "cannot establish a compound response"
    )
