"""Hovorka glucose-insulin system with an explicit exogenous insulin route.

Why this module exists
----------------------
The shipped endocrine engine (``glucose_insulin.py``, Bergman minimal model)
has no exogenous insulin input at all: insulin is a dependent state driven by
pancreatic secretion. The requested insulin program is therefore structurally
impossible on it, independent of the failed native OSP route. This module adds
the missing capability using a published, widely used compartmental model of
glucose regulation with subcutaneous insulin absorption.

Source of the structure and parameters
--------------------------------------
Hovorka R, Canonico V, Chassin LJ, et al. "Nonlinear model predictive control
of glucose concentration in subjects with type 1 diabetes." Physiol Meas
2004;25:905-920. doi:10.1088/0967-3334/25/4/010

Wilinska ME, Chassin LJ, Acerini CL, Allen JM, Dunger DB, Hovorka R.
"Simulation environment to evaluate closed-loop insulin delivery systems in
type 1 diabetes." J Diabetes Sci Technol 2010;4(1):132-144.
doi:10.1177/193229681000400117

Every parameter carries its value, unit and which of those two sources it came
from (see ``PARAMETER_PROVENANCE``). No parameter is tuned here to make any
result look better, and none is invented.

What this is not
----------------
A numerical model of a published population. It is not a person-specific
calibration, not a validated predictor for any individual, and not dosing
guidance. Individualization here means weight-scaled volumes plus explicitly
supplied, provenance-tagged parameter overrides; it does not make the twin that
person. Physical measurement remains the only route to equivalence claims.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Iterable, Sequence

import numpy as np
from scipy.integrate import solve_ivp

from ..integrity import UnsupportedInterventionError

HOVORKA_2004 = "hovorka-2004"
WILINSKA_2010 = "wilinska-2010"

_CITATIONS = {
    HOVORKA_2004: ("Hovorka R, Canonico V, Chassin LJ, et al. Physiol Meas "
                   "2004;25:905-920. doi:10.1088/0967-3334/25/4/010"),
    WILINSKA_2010: ("Wilinska ME, Chassin LJ, Acerini CL, Allen JM, Dunger DB, "
                    "Hovorka R. J Diabetes Sci Technol 2010;4(1):132-144. "
                    "doi:10.1177/193229681000400117"),
}

# Per-parameter unit and originating source. A parameter absent here cannot be
# set through the public builders.
PARAMETER_PROVENANCE: dict[str, dict[str, str]] = {
    "k12":     {"unit": "1/min", "quantity": "transfer rate, glucose compartment 2 to 1"},
    "ka1":     {"unit": "1/min", "quantity": "deactivation rate, insulin action on glucose transport"},
    "ka2":     {"unit": "1/min", "quantity": "deactivation rate, insulin action on glucose disposal"},
    "ka3":     {"unit": "1/min", "quantity": "deactivation rate, insulin action on endogenous production"},
    "SIT":     {"unit": "1/min per mU/L", "quantity": "insulin sensitivity of glucose transport"},
    "SID":     {"unit": "1/min per mU/L", "quantity": "insulin sensitivity of glucose disposal"},
    "SIE":     {"unit": "per mU/L", "quantity": "insulin sensitivity of endogenous glucose production"},
    "ke":      {"unit": "1/min", "quantity": "plasma insulin elimination rate"},
    "VI":      {"unit": "L/kg", "quantity": "insulin distribution volume per body weight"},
    "VG":      {"unit": "L/kg", "quantity": "glucose distribution volume per body weight"},
    "tmaxI":   {"unit": "min", "quantity": "time-to-maximum of subcutaneous insulin absorption"},
    "tmaxG":   {"unit": "min", "quantity": "time-to-maximum of gut glucose absorption"},
    "AG":      {"unit": "1", "quantity": "carbohydrate bioavailability"},
    "F01":     {"unit": "mmol/kg/min", "quantity": "non-insulin-dependent glucose flux"},
    "EGP0":    {"unit": "mmol/kg/min", "quantity": "endogenous glucose production at zero insulin"},
    "R_thr":   {"unit": "mmol/L", "quantity": "renal glucose clearance threshold"},
    "R_cl":    {"unit": "1/min", "quantity": "renal glucose clearance rate above threshold"},
    "weight_kg": {"unit": "kg", "quantity": "body weight"},
}

_SOURCE_VALUES: dict[str, dict[str, float]] = {
    # Hovorka 2004, Table 1 / model definition.
    HOVORKA_2004: {
        "k12": 0.066, "ka1": 0.006, "ka2": 0.06, "ka3": 0.03,
        "SIT": 51.2e-4, "SID": 8.2e-4, "SIE": 520e-4,
        "ke": 0.138, "VI": 0.12, "VG": 0.16,
        "tmaxI": 55.0, "tmaxG": 40.0, "AG": 0.8,
        "F01": 0.0097, "EGP0": 0.0161,
        "R_thr": 9.0, "R_cl": 0.003,
    },
    # Wilinska 2010 simulation environment: the eight parameters estimated from
    # clinical data there replace their Hovorka 2004 counterparts; parameters the
    # 2010 paper does not re-estimate are inherited and tagged as such.
    WILINSKA_2010: {
        "k12": 0.060, "SID": 5.05e-4, "SIE": 0.019, "SIT": 18.41e-4,
        "F01": 0.0111, "EGP0": 0.0169,
        "ka1": 0.006, "ka2": 0.06, "ka3": 0.03,
        "ke": 0.14, "VI": 0.12, "VG": 0.15,
        "tmaxI": 55.0, "tmaxG": 40.0, "AG": 0.8,
        "R_thr": 9.0, "R_cl": 0.01,
    },
}
_REESTIMATED_BY_WILINSKA = frozenset({"k12", "SID", "SIE", "SIT", "F01", "EGP0", "ke", "VG", "R_cl"})

MMOL_PER_L_TO_MG_PER_DL = 18.0156


class InsulinProductError(UnsupportedInterventionError):
    """Raised when a requested insulin product has no admitted absorption model."""

    def __init__(self, code: str, message: str) -> None:
        self.code = code
        super().__init__(message)


@dataclass(frozen=True)
class InsulinProduct:
    """An insulin material and route whose exposure model is explicitly declared."""
    product_id: str
    display_name: str
    route: str                 # "subcutaneous" | "intravenous"
    tmaxI_min: float | None    # None for intravenous: no absorption compartment
    source: str
    note: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "product_id": self.product_id, "display_name": self.display_name,
            "route": self.route, "tmaxI_min": self.tmaxI_min,
            "absorption_source": self.source, "note": self.note,
        }


# Admitted products. tmaxI for the rapid-acting analogue is the published
# absorption constant of the source model, not a manufacturer value, and the
# model was characterised with that class of preparation.
ADMITTED_PRODUCTS: dict[str, InsulinProduct] = {
    "rapid-acting-analogue-sc": InsulinProduct(
        "rapid-acting-analogue-sc", "Rapid-acting insulin analogue, subcutaneous",
        "subcutaneous", 55.0, _CITATIONS[HOVORKA_2004],
        "Absorption uses the source model's own two-compartment subcutaneous chain.",
    ),
    "regular-human-insulin-iv": InsulinProduct(
        "regular-human-insulin-iv", "Regular human insulin, intravenous infusion",
        "intravenous", None, _CITATIONS[HOVORKA_2004],
        "No absorption compartment; infusion enters the plasma compartment directly.",
    ),
}

# Products that exist clinically but have no admitted absorption model here.
# Requesting one is refused rather than approximated with the analogue's tmaxI.
DECLARED_NOT_ADMITTED: dict[str, str] = {
    "regular-human-insulin-sc": "Subcutaneous regular human insulin absorption differs from a rapid-acting analogue; no admitted source model.",
    "nph-insulin-sc": "Intermediate-acting suspension absorption is not represented by the source model.",
    "glargine-sc": "Long-acting analogue depot behaviour is not represented by the source model.",
    "degludec-sc": "Ultra-long-acting analogue depot behaviour is not represented by the source model.",
    "detemir-sc": "Long-acting analogue albumin binding is not represented by the source model.",
}


def resolve_product(product_id: str) -> InsulinProduct:
    if product_id in ADMITTED_PRODUCTS:
        return ADMITTED_PRODUCTS[product_id]
    if product_id in DECLARED_NOT_ADMITTED:
        raise InsulinProductError("INSULIN_PRODUCT_NOT_ADMITTED", DECLARED_NOT_ADMITTED[product_id])
    raise InsulinProductError("INSULIN_PRODUCT_UNKNOWN", f"Unknown insulin product identifier: {product_id!r}")


def product_catalog() -> dict[str, Any]:
    return {
        "schema": "livemore.insulin-products.v1",
        "admitted": [product.to_dict() for product in ADMITTED_PRODUCTS.values()],
        "declared_not_admitted": [
            {"product_id": key, "reason_code": "INSULIN_PRODUCT_NOT_ADMITTED", "reason": value}
            for key, value in DECLARED_NOT_ADMITTED.items()
        ],
    }


@dataclass(frozen=True)
class HovorkaParameters:
    """Model parameters with per-field lineage; construct through ``from_source``."""
    weight_kg: float
    k12: float
    ka1: float
    ka2: float
    ka3: float
    SIT: float
    SID: float
    SIE: float
    ke: float
    VI: float
    VG: float
    tmaxI: float
    tmaxG: float
    AG: float
    F01: float
    EGP0: float
    R_thr: float
    R_cl: float
    source: str = HOVORKA_2004
    lineage: tuple[tuple[str, str], ...] = ()

    @classmethod
    def from_source(cls, source: str = HOVORKA_2004, *, weight_kg: float = 70.0,
                    overrides: dict[str, float] | None = None,
                    override_provenance: dict[str, str] | None = None) -> "HovorkaParameters":
        if source not in _SOURCE_VALUES:
            raise ValueError(f"unknown parameter source {source!r}")
        if not np.isfinite(weight_kg) or not 1.0 <= weight_kg <= 400.0:
            raise ValueError("weight_kg must be finite and within 1-400 kg")
        values = dict(_SOURCE_VALUES[source])
        lineage: dict[str, str] = {}
        for name in values:
            if source == WILINSKA_2010 and name not in _REESTIMATED_BY_WILINSKA:
                lineage[name] = f"inherited from {HOVORKA_2004}: {_CITATIONS[HOVORKA_2004]}"
            else:
                lineage[name] = _CITATIONS[source]
        overrides = dict(overrides or {})
        provenance = dict(override_provenance or {})
        for name, value in overrides.items():
            if name not in PARAMETER_PROVENANCE or name == "weight_kg":
                raise ValueError(f"parameter {name!r} cannot be overridden")
            if name not in provenance or not str(provenance[name]).strip():
                raise ValueError(f"override of {name!r} requires an explicit provenance string")
            if not np.isfinite(value) or value <= 0:
                raise ValueError(f"override of {name!r} must be finite and positive")
            values[name] = float(value)
            lineage[name] = str(provenance[name]).strip()
        lineage["weight_kg"] = provenance.get("weight_kg", "supplied individual covariate")
        return cls(weight_kg=float(weight_kg), source=source,
                   lineage=tuple(sorted(lineage.items())), **values)

    @property
    def VI_L(self) -> float:
        return self.VI * self.weight_kg

    @property
    def VG_L(self) -> float:
        return self.VG * self.weight_kg

    def provenance(self) -> dict[str, dict[str, str]]:
        records = {}
        for name, citation in self.lineage:
            spec = PARAMETER_PROVENANCE.get(name, {})
            records[name] = {
                "value": getattr(self, name, None),
                "unit": spec.get("unit", ""),
                "quantity": spec.get("quantity", ""),
                "source": citation,
            }
        return records


@dataclass(frozen=True)
class InsulinDose:
    """One exogenous insulin administration.

    ``units`` are international units for a bolus; ``rate_u_per_h`` with
    ``duration_min`` describes an infusion. Exactly one form must be given.
    """
    start_min: float
    units: float | None = None
    rate_u_per_h: float | None = None
    duration_min: float | None = None

    def validate(self) -> None:
        if not np.isfinite(self.start_min) or self.start_min < 0:
            raise ValueError("dose start_min must be finite and non-negative")
        bolus = self.units is not None
        infusion = self.rate_u_per_h is not None
        if bolus == infusion:
            raise ValueError("supply exactly one of units or rate_u_per_h")
        if bolus:
            if not np.isfinite(self.units) or self.units < 0:
                raise ValueError("units must be finite and non-negative")
        else:
            if not np.isfinite(self.rate_u_per_h) or self.rate_u_per_h < 0:
                raise ValueError("rate_u_per_h must be finite and non-negative")
            if self.duration_min is None or not np.isfinite(self.duration_min) or self.duration_min <= 0:
                raise ValueError("an infusion requires a positive duration_min")


# 1 IU of insulin is 6000 pmol by the WHO/pharmacopoeial equivalence
# (1 mg = 28.8 IU for human insulin, molar mass 5808 g/mol). The model's insulin
# inputs are in mU/min, so a bolus in IU becomes 1000 mU.
MU_PER_UNIT = 1000.0


@dataclass
class HovorkaModel:
    parameters: HovorkaParameters = field(default_factory=HovorkaParameters.from_source)
    product: InsulinProduct = field(default_factory=lambda: ADMITTED_PRODUCTS["rapid-acting-analogue-sc"])

    # ---- inputs -----------------------------------------------------------
    def _insulin_rate(self, t: float, doses: Sequence[InsulinDose]) -> float:
        """Exogenous insulin input in mU/min at model time ``t``."""
        rate = 0.0
        for dose in doses:
            if dose.rate_u_per_h is not None:
                end = dose.start_min + float(dose.duration_min)
                if dose.start_min <= t < end:
                    rate += dose.rate_u_per_h * MU_PER_UNIT / 60.0
        return rate

    @staticmethod
    def _bolus_amount(dose: InsulinDose) -> float:
        return 0.0 if dose.units is None else dose.units * MU_PER_UNIT

    def _meal_flux(self, t: float, meals_g: Sequence[tuple[float, float]]) -> float:
        """Gut glucose appearance in mmol/min (source's gamma absorption)."""
        p = self.parameters
        flux = 0.0
        for start, grams in meals_g:
            dt = t - start
            if dt > 0.0:
                # grams carbohydrate -> mmol glucose (180.156 g/mol)
                dose_mmol = grams * 1000.0 / 180.156
                flux += dose_mmol * p.AG * dt * np.exp(-dt / p.tmaxG) / (p.tmaxG ** 2)
        return flux

    # ---- right-hand side --------------------------------------------------
    def _rhs(self, t, y, doses, meals_g):
        p = self.parameters
        Q1, Q2, S1, S2, I, x1, x2, x3, _eliminated = y
        G = Q1 / p.VG_L                                   # mmol/L
        F01 = p.F01 * p.weight_kg                         # mmol/min
        F01c = F01 if G >= 4.5 else F01 * G / 4.5
        FR = p.R_cl * (G - p.R_thr) * p.VG_L if G > p.R_thr else 0.0
        UG = self._meal_flux(t, meals_g)
        EGP = p.EGP0 * p.weight_kg * max(0.0, 1.0 - x3)   # mmol/min

        u = self._insulin_rate(t, doses)                  # mU/min
        if self.product.route == "subcutaneous":
            dS1 = u - S1 / p.tmaxI
            dS2 = S1 / p.tmaxI - S2 / p.tmaxI
            insulin_to_plasma = S2 / p.tmaxI
        else:
            dS1 = 0.0
            dS2 = 0.0
            insulin_to_plasma = u

        dI = insulin_to_plasma / p.VI_L - p.ke * I        # mU/L/min
        dQ1 = -F01c - x1 * Q1 + p.k12 * Q2 - FR + UG + EGP
        dQ2 = x1 * Q1 - (p.k12 + x2) * Q2
        dx1 = -p.ka1 * x1 + p.ka1 * p.SIT * I
        dx2 = -p.ka2 * x2 + p.ka2 * p.SID * I
        dx3 = -p.ka3 * x3 + p.ka3 * p.SIE * I
        dE = p.ke * I * p.VI_L                            # mU eliminated from plasma
        return (dQ1, dQ2, dS1, dS2, dI, dx1, dx2, dx3, dE)

    # ---- steady state -----------------------------------------------------
    def basal_steady_state(self, basal_u_per_h: float, *, minutes: float = 1440.0) -> dict[str, float]:
        """Integrate a constant basal infusion to a quasi-steady state."""
        doses = [InsulinDose(start_min=0.0, rate_u_per_h=basal_u_per_h, duration_min=minutes + 1.0)]
        for dose in doses:
            dose.validate()
        p = self.parameters
        y0 = (5.5 * p.VG_L, 5.5 * p.VG_L * 0.4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        solution = solve_ivp(self._rhs, (0.0, minutes), y0, args=(doses, ()),
                             method="LSODA", rtol=1e-8, atol=1e-10, dense_output=True)
        if not solution.success:
            raise RuntimeError(f"basal steady-state integration failed: {solution.message}")
        final = solution.y[:, -1]
        return {"Q1_mmol": float(final[0]), "Q2_mmol": float(final[1]),
                "S1_mU": float(final[2]), "S2_mU": float(final[3]),
                "plasma_insulin_mU_L": float(final[4]),
                "glucose_mmol_L": float(final[0] / p.VG_L),
                "x1": float(final[5]), "x2": float(final[6]), "x3": float(final[7])}

    def initial_state_from_basal(self, basal_u_per_h: float, *, minutes: float = 2880.0) -> list[float]:
        """Full state vector after a long basal infusion, with the eliminated counter reset."""
        doses = [InsulinDose(start_min=0.0, rate_u_per_h=basal_u_per_h, duration_min=minutes + 1.0)]
        p = self.parameters
        y0 = (5.5 * p.VG_L, 5.5 * p.VG_L * 0.4, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        solution = solve_ivp(self._rhs, (0.0, minutes), y0, args=(doses, ()),
                             method="LSODA", rtol=1e-8, atol=1e-10)
        if not solution.success:
            raise RuntimeError(f"basal initialisation failed: {solution.message}")
        state = [float(v) for v in solution.y[:, -1]]
        state[8] = 0.0
        return state

    # ---- simulation -------------------------------------------------------
    def simulate(self, *, hours: float = 6.0,
                 doses: Iterable[InsulinDose] = (),
                 meals_g: Sequence[tuple[float, float]] = (),
                 basal_u_per_h: float = 0.0,
                 initial_glucose_mmol_L: float = 5.5,
                 initial_state: Sequence[float] | None = None,
                 dt_min: float = 1.0) -> dict[str, Any]:
        """Integrate the system. Raises rather than clamping on invalid input."""
        p = self.parameters
        doses = list(doses)
        for dose in doses:
            dose.validate()
        if self.product.route == "intravenous" and any(d.units is not None for d in doses):
            raise InsulinProductError(
                "INSULIN_ROUTE_REQUIRES_INFUSION",
                "The intravenous route is modelled as an infusion; supply rate_u_per_h and duration_min.")
        if not np.isfinite(hours) or not 0 < hours <= 72:
            raise ValueError("hours must be finite and within (0, 72]")
        if not np.isfinite(initial_glucose_mmol_L) or not 1.0 <= initial_glucose_mmol_L <= 35.0:
            raise ValueError("initial_glucose_mmol_L must be finite and within 1-35 mmol/L")
        if basal_u_per_h < 0 or not np.isfinite(basal_u_per_h):
            raise ValueError("basal_u_per_h must be finite and non-negative")

        t_end = hours * 60.0
        if basal_u_per_h > 0:
            doses = doses + [InsulinDose(start_min=0.0, rate_u_per_h=basal_u_per_h,
                                         duration_min=t_end + 1.0)]
        # Bolus doses enter as instantaneous state increments at their start time,
        # so integration is segmented at every bolus instant.
        # A zero-unit bolus is no intervention: it must not alter integration segments.
        boluses = sorted((d for d in doses if d.units is not None and d.units > 0), key=lambda d: d.start_min)
        infusions = [d for d in doses if d.rate_u_per_h is not None]

        if initial_state is not None:
            y = [float(v) for v in initial_state]
            if len(y) != 9 or not all(np.isfinite(y)) or y[0] <= 0:
                raise ValueError("initial_state must be a finite 9-element state with positive glucose mass")
            y[8] = 0.0
        else:
            y = [initial_glucose_mmol_L * p.VG_L, initial_glucose_mmol_L * p.VG_L * 0.4,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        initial_insulin_mU = y[2] + y[3] + y[4] * p.VI_L
        times: list[np.ndarray] = []
        states: list[np.ndarray] = []
        breakpoints = [0.0] + [d.start_min for d in boluses if 0.0 < d.start_min < t_end] + [t_end]
        breakpoints = sorted(set(breakpoints))
        pending: dict[float, float] = {}
        for dose in boluses:            # several boluses may share one instant
            pending[dose.start_min] = pending.get(dose.start_min, 0.0) + self._bolus_amount(dose)
        for index in range(len(breakpoints) - 1):
            start, stop = breakpoints[index], breakpoints[index + 1]
            if start in pending:
                if self.product.route == "subcutaneous":
                    y[2] += pending[start]        # into the first SC depot
                else:
                    y[4] += pending[start] / p.VI_L
            grid = np.arange(start, stop + dt_min / 2.0, dt_min)
            if grid.size == 0 or grid[-1] < stop:
                grid = np.append(grid, stop)
            solution = solve_ivp(self._rhs, (start, stop), y, t_eval=grid,
                                 args=(infusions, tuple(meals_g)),
                                 method="LSODA", rtol=1e-8, atol=1e-10)
            if not solution.success:
                raise RuntimeError(f"integration failed: {solution.message}")
            times.append(solution.t if index == 0 else solution.t[1:])
            states.append(solution.y if index == 0 else solution.y[:, 1:])
            y = list(solution.y[:, -1])
        if t_end in pending and self.product.route == "subcutaneous":
            y[2] += pending[t_end]

        t = np.concatenate(times)
        Y = np.concatenate(states, axis=1)
        administered_mU = sum(self._bolus_amount(d) for d in boluses if d.start_min < t_end)
        for d in infusions:
            overlap = max(0.0, min(t_end, d.start_min + float(d.duration_min)) - d.start_min)
            administered_mU += d.rate_u_per_h * MU_PER_UNIT / 60.0 * overlap
        present_mU = float(Y[2, -1] + Y[3, -1] + Y[4, -1] * p.VI_L)
        eliminated_mU = float(Y[8, -1])
        balance_residual = (initial_insulin_mU + administered_mU) - (present_mU + eliminated_mU)
        scale = max(1.0, initial_insulin_mU + administered_mU)
        glucose_mmol = Y[0] / p.VG_L
        result = {
            "schema": "livemore.hovorka-execution.v1",
            "parameter_source": p.source,
            "citation": _CITATIONS[p.source],
            "product": self.product.to_dict(),
            "t_min": t,
            "glucose_mmol_L": glucose_mmol,
            "glucose_mg_dL": glucose_mmol * MMOL_PER_L_TO_MG_PER_DL,
            "plasma_insulin_mU_L": Y[4],
            "insulin_action_transport": Y[5],
            "insulin_action_disposal": Y[6],
            "insulin_action_egp": Y[7],
            "sc_depot_1_mU": Y[2],
            "sc_depot_2_mU": Y[3],
            "glucose_compartment_1_mmol": Y[0],
            "glucose_compartment_2_mmol": Y[1],
            "units": {"t_min": "min", "glucose_mmol_L": "mmol/L", "glucose_mg_dL": "mg/dL",
                      "plasma_insulin_mU_L": "mU/L", "sc_depot_1_mU": "mU", "sc_depot_2_mU": "mU",
                      "glucose_compartment_1_mmol": "mmol", "glucose_compartment_2_mmol": "mmol"},
            "parameter_provenance": p.provenance(),
            "insulin_mass_balance": {
                "initial_mU": round(initial_insulin_mU, 9), "administered_mU": round(administered_mU, 9),
                "present_end_mU": round(present_mU, 9), "eliminated_mU": round(eliminated_mU, 9),
                "relative_residual": float(abs(balance_residual) / scale),
            },
            "interpretation_limits": [
                "Numerical model output; not an observed measurement in any person.",
                "Not calibrated to an individual and not validated prospectively.",
                "Not dosing guidance and not a basis for any clinical decision.",
            ],
        }
        return result


def summarize(result: dict[str, Any]) -> dict[str, Any]:
    glucose = np.asarray(result["glucose_mmol_L"], dtype=float)
    insulin = np.asarray(result["plasma_insulin_mU_L"], dtype=float)
    t = np.asarray(result["t_min"], dtype=float)
    trapezoid = getattr(np, "trapezoid", None) or getattr(np, "trapz")
    return {
        "baseline_glucose_mmol_L": round(float(glucose[0]), 4),
        "nadir_glucose_mmol_L": round(float(glucose.min()), 4),
        "t_nadir_min": round(float(t[int(glucose.argmin())]), 2),
        "peak_glucose_mmol_L": round(float(glucose.max()), 4),
        "t_peak_min": round(float(t[int(glucose.argmax())]), 2),
        "end_glucose_mmol_L": round(float(glucose[-1]), 4),
        "peak_plasma_insulin_mU_L": round(float(insulin.max()), 4),
        "t_peak_insulin_min": round(float(t[int(insulin.argmax())]), 2),
        "glucose_auc_mmol_L_min": round(float(trapezoid(glucose, t)), 3),
        "minutes_below_3_9_mmol_L": round(float(np.sum(glucose < 3.9) * float(np.median(np.diff(t)) if t.size > 1 else 0.0)), 2),
    }
