"""
livemorebio.engines.metabolic.glucose_insulin
=============================================
An executable mechanistic glucose-insulin engine for the LivemoreBio metabolic column.

Not a risk heuristic. A closed-loop system of ODEs integrated numerically
(SciPy LSODA), built on the Bergman "minimal model" of glucose kinetics and
insulin action (Bergman et al., Am J Physiol 1979; J Clin Invest 1981), closed
with a first-order pancreatic secretion/clearance loop and an oral-glucose
(gamma / Bateman) rate-of-appearance model.

Glucose and insulin evolve in time and respond to meals, to insulin sensitivity
(Si) and to beta-cell responsivity (gamma) -- so a metabolically healthy adult
and a person with type-2 diabetes produce different modeled trajectories
from the same meal. This is the substrate that LIFE-Patch state parameterises,
that Cendos perturbs with drugs/compounds, and that the visualiser renders.

State (physiological units):  G glucose [mg/dL], X remote insulin action [1/min],
I plasma insulin [uU/mL].  Not clinically validated; parameters literature-typical.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Tuple, Optional
import numpy as np
from scipy.integrate import solve_ivp


@dataclass
class MetabolicProfile:
    """Per-person metabolic parameters -- what makes the twin *this* human."""
    name: str = "reference-adult"
    weight_kg: float = 70.0
    Gb: float = 90.0        # basal glucose [mg/dL]
    Ib: float = 9.0         # basal insulin [uU/mL]
    SG: float = 0.026       # glucose effectiveness (Bergman p1) [1/min]
    p2: float = 0.025       # remote insulin-action decay [1/min]
    Si: float = 5.0e-4      # insulin sensitivity [(uU/mL)^-1 min^-1]; p3 = Si*p2
    gamma: float = 0.12     # beta-cell responsivity [uU/mL/min per mg/dL]
    Gt: float = 100.0       # secretion threshold glucose [mg/dL]
    n: float = 0.14         # insulin clearance [1/min]
    ka: float = 0.020       # oral glucose absorption rate [1/min]
    f_bioavail: float = 0.75 # fraction of ingested carbohydrate reaching plasma
    vg_per_kg: float = 2.0  # glucose distribution volume [dL/kg]

    @property
    def p3(self) -> float:            # insulin action on glucose disposal
        return self.Si * self.p2

    @property
    def Vg_dL(self) -> float:         # glucose distribution volume [dL]
        return self.vg_per_kg * self.weight_kg


# Reference presets (illustrative, literature-typical -- NOT cohort-fitted).
HEALTHY = MetabolicProfile(name="healthy-adult")
T2D = MetabolicProfile(name="type-2-diabetes", Gb=135.0, Ib=15.0,
                       Si=1.5e-4, gamma=0.045, Gt=125.0, SG=0.013)


def meal_rate_of_appearance(t: float, meals, ka: float, f: float) -> float:
    """Oral glucose rate of appearance [mg/min] as a sum of gamma (Bateman) meals."""
    Ra = 0.0
    for tm_min, grams in meals:
        dt = t - tm_min
        if dt > 0.0:
            D = grams * 1000.0                       # g -> mg
            Ra += D * f * (ka * ka) * dt * np.exp(-ka * dt)
    return Ra


@dataclass
class GlucoseInsulinModel:
    profile: MetabolicProfile = field(default_factory=MetabolicProfile)

    def _rhs(self, t, y, meals):
        G, X, I = y
        p = self.profile
        Ra = meal_rate_of_appearance(t, meals, p.ka, p.f_bioavail) / p.Vg_dL  # mg/dL/min
        dG = -(p.SG + X) * G + p.SG * p.Gb + Ra
        dX = -p.p2 * X + p.p3 * (I - p.Ib)
        dI = p.gamma * max(0.0, G - p.Gt) - p.n * (I - p.Ib)
        return (dG, dX, dI)

    def simulate(self, hours: float = 4.0,
                 meals_g: Optional[List[Tuple[float, float]]] = None,
                 dt_min: float = 1.0) -> dict:
        """meals_g: [(minute, grams_carb), ...]; default a single 75 g OGTT at t=0."""
        meals = meals_g if meals_g is not None else [(0.0, 75.0)]
        p = self.profile
        t_end = hours * 60.0
        t_eval = np.arange(0.0, t_end + dt_min, dt_min)
        y0 = (p.Gb, 0.0, p.Ib)
        sol = solve_ivp(self._rhs, (0.0, t_end), y0, t_eval=t_eval,
                        args=(meals,), method="LSODA", rtol=1e-6, atol=1e-8)
        if not sol.success:
            raise RuntimeError(f"integration failed: {sol.message}")
        return dict(t_min=sol.t, glucose=sol.y[0], insulin_action=sol.y[1],
                    insulin=sol.y[2], profile=p.name, meals=meals)


def summarize(res: dict) -> dict:
    g, t = res["glucose"], res["t_min"]
    base = float(g[0])
    _trap = getattr(np, "trapezoid", getattr(np, "trapz", None))
    iauc = float(_trap(np.clip(g - base, 0.0, None), t))
    return dict(profile=res["profile"], baseline=round(base, 1),
                peak=round(float(g.max()), 1), t_peak_min=round(float(t[g.argmax()]), 1),
                mean=round(float(g.mean()), 1),
                insulin_peak=round(float(res["insulin"].max()), 1),
                end=round(float(g[-1]), 1), iAUC_mg_dL_min=round(iauc, 0))
