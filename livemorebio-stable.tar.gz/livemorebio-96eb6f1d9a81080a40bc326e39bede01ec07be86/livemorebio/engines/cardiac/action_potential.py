"""
livemorebio.engines.cardiac.action_potential
============================================
Human ventricular action potential engine — the published O'Hara-Rudy CiPA 2017
model (49 states), hosted natively via Myokit/CVODE from its CellML source. This
is real electrophysiology: a paced ventricular myocyte with Na/Ca/K currents and
CiPA dynamic hERG (IKr) drug binding.

`ikr_block` (0..1) reduces repolarising IKr -> APD prolongation. It is the single
knob used both for drug block (dofetilide-class hERG blockers, the CiPA use case)
and for the metabolic->cardiac coupling (chronic hyperglycemia lowers IKr).
Not clinically validated.
"""
from __future__ import annotations
import os
import numpy as np
import myokit
import myokit.formats

DEFAULT_MODEL = os.path.abspath(os.path.join(
    os.path.dirname(__file__), "..", "..", "..", "models", "cardiac",
    "ohara_rudy_cipa_2017.cellml"))


def _metrics(t, v):
    vr, vp = float(v.min()), float(v.max())
    thr = vp - 0.9 * (vp - vr)
    ab = t[v >= thr]
    apd90 = float(ab.max() - ab.min()) if len(ab) > 1 else float("nan")
    return dict(vrest=round(vr, 1), vpeak=round(vp, 1),
                amplitude=round(vp - vr, 1), apd90_ms=round(apd90, 0))


class CardiacCell:
    def __init__(self, model_path: str = DEFAULT_MODEL):
        m = myokit.formats.importer("cellml").model(model_path)
        mem = m.get("membrane")
        if not mem.has_variable("pace"):
            pace = mem.add_variable("pace")
            pace.set_unit(myokit.units.dimensionless)
            pace.set_rhs(0)
            pace.set_binding("pace")
        m.get("membrane.Istim").set_rhs("membrane.i_Stim_Amplitude * membrane.pace")
        ikr = m.get("IKr")
        if not ikr.has_variable("ikr_scale"):
            sc = ikr.add_variable("ikr_scale")
            sc.set_unit(myokit.units.dimensionless)
            sc.set_rhs(1.0)
        cur = m.get("IKr.IKr")
        cur.set_rhs(myokit.Multiply(cur.rhs(), myokit.Name(m.get("IKr.ikr_scale"))))
        self._m = m
        self._period = m.get("membrane.i_Stim_Period").eval()
        self._dur = m.get("membrane.i_Stim_PulseDuration").eval()

    def simulate(self, beats: int = 10, ikr_block: float = 0.0,
                 cl_ms: float = None, overrides: dict = None) -> dict:
        m = self._m
        cl = float(cl_ms or self._period)
        m.get("IKr.ikr_scale").set_rhs(float(max(0.0, 1.0 - ikr_block)))
        if overrides:
            for q, val in overrides.items():
                m.get(q).set_rhs(float(val))
        proto = myokit.pacing.blocktrain(period=cl, duration=self._dur, offset=50, level=1)
        sim = myokit.Simulation(m, proto)
        sim.pre(cl * max(0, beats - 1))
        d = sim.run(cl, log=["environment.time", "membrane.v", "intracellular_ions.cai"])
        t = np.array(d["environment.time"]); v = np.array(d["membrane.v"])
        cai = np.array(d["intracellular_ions.cai"])
        out = _metrics(t, v)
        out.update(t=t, v=v, cai=cai, cai_peak_uM=round(float(cai.max() * 1e3), 3),
                   ikr_block=round(float(ikr_block), 3), cl_ms=cl)
        return out
