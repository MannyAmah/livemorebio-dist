"""
livemorebio.engines.cardiac.heart_rate — mechanistic resting heart rate, intra-day
HR, and HR variability from the twin's autonomic/metabolic state.

Grounded in established cardiovascular physiology (reduced model for individualized
simulation, not a clinical HR predictor):

- Resting HR is the SA-node intrinsic rate net of autonomic balance (vagal vs
  sympathetic tone).
- Higher cardiorespiratory fitness -> greater vagal tone -> lower resting HR; low
  fitness -> higher resting HR.
- Insulin resistance and chronic hyperglycemia shift autonomic balance toward
  sympathetic predominance and cause cardiac autonomic dysfunction (diabetic cardiac
  autonomic neuropathy) -> higher resting HR and reduced HR variability.
- Certain conditions (heart failure, ischemic disease, COPD, hyperthyroidism) raise
  resting HR through compensatory / hypoxic / hypermetabolic drive.
- Across the day HR is modulated by a mild circadian envelope and by a postprandial
  sympathetic/insulin-mediated rise that tracks the glucose excursion above fasting.

The output paces the same O'Hara-Rudy myocyte the console beats, so the action
potential and Ca2+ transient reflect the individualized rate (rate-dependent
restitution) and the LIFE Patch streams the same real HR — no flat placeholder.
"""
from __future__ import annotations
import math
from typing import List, Sequence, Tuple

_HEALTHY_SI = 0.0005  # engines.metabolic.glucose_insulin.HEALTHY.Si reference


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


def resting_heart_rate(age: float, lifestyle: float, mean_glucose: float,
                       si: float, conditions: Sequence[str] = ()) -> float:
    """Individualized resting HR (bpm) from autonomic + metabolic state.
    lifestyle: 0 poor .. 1 excellent (fitness proxy). si: insulin sensitivity."""
    hr = 68.0
    hr -= (float(lifestyle) - 0.5) * 22.0                         # fitness / vagal tone: +-11
    hr += _clamp((float(mean_glucose) - 92.0) * 0.14, 0.0, 20.0)  # glycemia -> sympathetic
    ir = _clamp(_HEALTHY_SI / max(float(si), 1e-6), 1.0, 4.0)     # insulin resistance
    hr += (ir - 1.0) * 2.0                                        # +0..+6
    hr += (float(age) - 45.0) * 0.06                              # mild age term
    cl = " ".join(conditions).lower()
    if "heart failure" in cl:
        hr += 14.0
    if "coronary" in cl or "ischem" in cl:
        hr += 4.0
    if "obstructive pulmonary" in cl or "copd" in cl:
        hr += 6.0
    if "asthma" in cl:
        hr += 2.0
    if "hyperthyroid" in cl:
        hr += 12.0
    return round(_clamp(hr, 44.0, 135.0), 1)


def hr_series(t_min: Sequence[float], glucose: Sequence[float],
              resting_hr: float) -> List[Tuple[float, float]]:
    """Intra-day HR (bpm) over the simulated day: mild circadian envelope plus a
    postprandial rise that tracks the real glucose excursion above fasting."""
    if not len(t_min):
        return []
    g0 = float(min(glucose)) if len(glucose) else 90.0
    tmax = float(t_min[-1]) or 1.0
    out = []
    for i in range(min(len(t_min), len(glucose))):
        t = float(t_min[i])
        circ = 1.0 + 0.03 * math.sin(math.pi * t / tmax)          # gentle daytime rise
        postp = 0.12 * max(0.0, float(glucose[i]) - g0)           # sympathetic postprandial
        out.append((round(t, 1), round(_clamp(resting_hr * circ + postp, 40.0, 180.0), 1)))
    return out


def hrv_rmssd(resting_hr: float, si: float, mean_glucose: float,
              conditions: Sequence[str] = ()) -> float:
    """Resting HR variability (RMSSD, ms). Higher fitness (lower resting HR) -> higher
    HRV; hyperglycemia / autonomic dysfunction -> lower HRV (reduced in diabetes)."""
    base = 45.0
    hf = _clamp(1.0 + (65.0 - float(resting_hr)) * 0.02, 0.4, 1.6)
    gp = _clamp(1.0 - (float(mean_glucose) - 92.0) / 240.0, 0.35, 1.0)
    hrv = base * hf * gp
    cl = " ".join(conditions).lower()
    if "heart failure" in cl or "coronary" in cl or "ischem" in cl:
        hrv *= 0.7
    return round(_clamp(hrv, 6.0, 90.0), 0)
