"""
livemorebio.engines.trajectory — disease emergence over time.

Chronic disease is not a single-timepoint event; it emerges as sustained exposures
push a person's biology across thresholds. This simulates the established natural
history of type-2 diabetes as a dynamical system on the validated Bergman parameters:

    energy surplus -> adiposity -> insulin resistance (Si falls)
                   -> beta-cell compensation (gamma rises) then failure (glucotoxicity)
                   -> fasting hyperglycemia (Gb rises) -> prediabetes -> T2D

Individualized by genome (TCF7L2 -> beta-cell fragility; PPARG -> insulin resistance),
modulated by activity, protective foods/phytochemicals, and drugs (metformin). Glucose
at each step comes from the calibrated glucose-insulin ODE, and stages use ADA criteria.

Structure follows established physiology; the adiposity->IR rate is now cohort-fitted to the DPP trial (#4), other rates literature-informed.
"""
from __future__ import annotations
import math
from dataclasses import dataclass, field
from .metabolic.glucose_insulin import MetabolicProfile, GlucoseInsulinModel, summarize, HEALTHY

KCAL_PER_KG_FAT = 7700.0
# adiposity -> insulin-resistance coupling; calibrated so the DPP placebo cohort
# reproduces the observed ~29% 3-year diabetes incidence (retrospective validation #4).
IR_COUPLING = 1.22


@dataclass
class ExposurePattern:
    kcal_intake: float = 2200.0     # daily intake
    activity: float = 0.5           # 0 sedentary .. 1 very active
    foods: tuple = ()               # recurring protective foods (phytochemicals)
    drugs: tuple = ()               # recurring drugs (e.g. metformin)
    stress: float = 0.0             # chronic stress 0..1 (HPA/cortisol)
    factors: tuple = ()             # other non-food factors (sleep deprivation, exercise, alcohol...)


def _bmr(sex, weight_kg, height_cm, age):
    b = 10 * weight_kg + 6.25 * height_cm - 5 * age                 # Mifflin-St Jeor
    return b + 5 if str(sex).upper().startswith("M") else b - 161


def _genome_susceptibility(genome):
    g = genome or {}
    ir = 1.0 + 0.45 * g.get("PPARG_loss", 0) + 0.20 * g.get("APOE4", 0) + 0.15 * g.get("TCF7L2", 0)
    beta = 1.0 + 0.55 * g.get("TCF7L2", 0) + 0.30 * g.get("KCNJ11", 0) + 0.20 * g.get("PPARG_loss", 0)
    return ir, beta


def _protection(exposure):
    """Activity + protective foods/drugs slow progression (insulin-sensitising)."""
    p = 0.35 * exposure.activity
    # Food identities alone contain no exposure or qualified protective-effect model.
    if any(str(d).strip().lower() == "metformin" for d in (exposure.drugs or ())):
        p += 0.25
    return p


def _stage(fasting, two_hr, hba1c):
    if fasting >= 126 or two_hr >= 200 or hba1c >= 6.5:
        return "type-2-diabetes"
    if fasting >= 100 or two_hr >= 140 or hba1c >= 5.7:
        return "prediabetes"
    return "normal"


def simulate_disease_trajectory(human, exposure: ExposurePattern, years: int = 10,
                                weight_kg: float = None, height_cm: float = None) -> dict:
    genome = getattr(human, "genome", {}) or {}
    age0 = getattr(human, "age", 40)
    sex = getattr(human, "sex", "M")
    height_cm = height_cm or (175.0 if str(sex).upper().startswith("M") else 162.0)
    healthy_wt = 22.5 * (height_cm / 100.0) ** 2
    weight_kg = weight_kg or 25.0 * (height_cm / 100.0) ** 2       # start ~BMI 25
    ir_s, beta_s = _genome_susceptibility(genome)
    protect = _protection(exposure)
    from .factors import aggregate_physiological_modifiers
    fmod = aggregate_physiological_modifiers(exposure.stress, exposure.factors)
    eff_kcal = exposure.kcal_intake + fmod["kcal_add"]

    Si, gamma, Gb = HEALTHY.Si, HEALTHY.gamma, HEALTHY.Gb
    glucotoxic = 0.0
    traj, crossed = [], {}
    for month in range(years * 12 + 1):
        age = age0 + month / 12.0
        tdee = _bmr(sex, weight_kg, height_cm, age) * (1.2 + 0.5 * exposure.activity)
        # ~40% of surplus stored as fat (adaptive thermogenesis dissipates the rest)
        weight_kg = max(healthy_wt * 0.85,
                        weight_kg + (eff_kcal - tdee) * 30.4 / KCAL_PER_KG_FAT * 0.4)
        excess = max(0.0, (weight_kg - healthy_wt) / healthy_wt)

        target_Si = HEALTHY.Si * math.exp(-IR_COUPLING * excess * ir_s) * (1.0 + 0.6 * protect) * fmod["si_mult"]
        Si += 0.12 * (target_Si - Si)
        Si = min(Si, HEALTHY.Si)
        demand = HEALTHY.Si / max(Si, 1e-5)                        # how hard beta-cells must work

        prof = MetabolicProfile(Si=Si, gamma=gamma, Gb=Gb, Ib=HEALTHY.Ib, Gt=HEALTHY.Gt, SG=HEALTHY.SG)
        res = GlucoseInsulinModel(prof).simulate(hours=2.0)
        two_hr = float(res["glucose"][-1])
        mean_g = float(res["glucose"].mean())

        glucotoxic += max(0.0, mean_g - 140.0) / 1000.0 * beta_s * (1.0 - 0.5 * protect)
        gamma_target = HEALTHY.gamma * min(demand, 2.2) * math.exp(-0.9 * glucotoxic)
        gamma += 0.12 * (gamma_target - gamma)
        gamma = max(0.02, gamma)

        unmet = max(0.0, demand - (gamma / HEALTHY.gamma))         # beta-cells can't meet demand
        Gb = min(HEALTHY.Gb * fmod["gb_mult"] + 60.0 * unmet, 350.0)  # fasting hyperglycemia (capped)
        fasting = Gb
        two_hr = min(two_hr, 500.0)
        avg_g = 0.7 * fasting + 0.3 * two_hr                        # daily-average glucose (fasting-weighted)
        hba1c = (avg_g + 46.7) / 28.7                              # ADAG eAG -> HbA1c
        stage = _stage(fasting, two_hr, hba1c)
        if stage not in crossed:
            crossed[stage] = round(month / 12.0, 1)

        if month % 6 == 0:
            traj.append({"year": round(month / 12.0, 1), "weight_kg": round(weight_kg, 1),
                         "bmi": round(weight_kg / (height_cm / 100.0) ** 2, 1),
                         "Si": round(Si, 6), "gamma": round(gamma, 4),
                         "fasting_glucose": round(fasting, 1), "ogtt_2h": round(two_hr, 1),
                         "hba1c": round(hba1c, 2), "stage": stage})

    onset = crossed.get("type-2-diabetes")
    pre = crossed.get("prediabetes")
    return {"human": getattr(human, "id", "?"), "genome": genome,
            "exposure": {"kcal": exposure.kcal_intake, "activity": exposure.activity,
                         "foods": list(exposure.foods or ()), "drugs": list(exposure.drugs or ())},
            "ir_susceptibility": round(ir_s, 2), "betacell_susceptibility": round(beta_s, 2),
            "final_stage": traj[-1]["stage"], "prediabetes_onset_year": pre,
            "diabetes_onset_year": onset, "trajectory": traj}
