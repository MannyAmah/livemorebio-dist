"""
livemorebio.engines.disease_links — map any exposure's molecular targets to the
diseases they drive, via the Open Targets Platform (aggregated human genetics,
known drugs, pathways, expression and literature into scored gene-disease
associations). Database-driven and scalable: ANY food / drug / factor's targets
resolve to a ranked disease-relevance signature. No disease list is hand-coded.
"""
from __future__ import annotations
import json
import functools
import urllib.request

OT_API = "https://api.platform.opentargets.org/api/v4/graphql"


@functools.lru_cache(maxsize=8192)
def _symbol_to_ensembl(symbol):
    """Resolve ANY human gene symbol -> Ensembl ID. Human-GEM map first (offline, fast),
    then Open Targets gene search (comprehensive — covers non-metabolic genes too)."""
    if not symbol:
        return None
    from .genome_scale import _symbol_map
    sym2ensg, _ = _symbol_map()
    e = sym2ensg.get(symbol.upper())
    if e:
        return e
    q = 'query($q:String!){search(queryString:$q,entityNames:["target"]){hits{id entity}}}'
    try:
        hits = _ot_query(q, {"q": symbol}).get("data", {}).get("search", {}).get("hits", [])
        for h in hits:
            if h.get("entity") == "target":
                return h["id"]
    except Exception:
        pass
    return None


def _ot_query(query, variables=None):
    body = json.dumps({"query": query, "variables": variables or {}}).encode()
    req = urllib.request.Request(OT_API, data=body, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.load(r)


@functools.lru_cache(maxsize=2048)
def target_diseases(gene_symbol, size=8):
    """gene symbol -> ((disease_name, score, disease_id), ...) from Open Targets."""
    ensg = _symbol_to_ensembl(gene_symbol)
    if not ensg:
        return ()
    q = ("query($id:String!,$n:Int!){target(ensemblId:$id){"
         "associatedDiseases(page:{index:0,size:$n}){rows{score disease{id name}}}}}")
    try:
        d = _ot_query(q, {"id": ensg, "n": size}).get("data", {}).get("target")
        if not d:
            return ()
        return tuple((r["disease"]["name"], round(r["score"], 3), r["disease"]["id"])
                     for r in d["associatedDiseases"]["rows"])
    except Exception:
        return ()


def exposure_disease_signature(target_genes, top=8):
    """Aggregate scored disease associations across an exposure's target genes.
    Ranked by CONVERGENCE (how many of the exposure's targets point at the disease)
    then combined strength — so a disease hit by several targets outranks one strong
    single-gene link. Returns which diseases the exposure touches, how, and via which genes."""
    agg = {}
    for g in set(target_genes):
        for name, score, did in target_diseases(g):
            e = agg.setdefault(did, {"disease": name, "scores": [], "via": set()})
            e["scores"].append(score)
            e["via"].add(g)
    rows = []
    for v in agg.values():
        rows.append({"disease": v["disease"], "score": round(max(v["scores"]), 3),
                     "combined": round(min(1.0, sum(v["scores"])), 3),
                     "n_targets": len(v["via"]), "via": sorted(v["via"])})
    rows.sort(key=lambda r: (-r["n_targets"], -r["combined"]))
    return rows[:top]
