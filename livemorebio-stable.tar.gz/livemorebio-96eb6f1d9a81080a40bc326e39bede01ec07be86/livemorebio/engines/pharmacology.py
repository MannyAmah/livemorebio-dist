"""
livemorebio.engines.pharmacology — individualized drug response.

The bounded metformin hypothesis model varies exposure and response by inputs:
  - pharmacogenomics: transporter/enzyme genotype gates drug exposure
  - baseline state: how much room the person has to improve (headroom)
  - organ function: renal/hepatic clearance
Its exposure-to-parameter gains are fixed research assumptions, not independently
validated causal magnitudes. Each call returns (modified_profile, why). Generic
plant effects remain unavailable without a compound-specific execution contract.
"""
from __future__ import annotations
from dataclasses import replace
from .metabolic.glucose_insulin import MetabolicProfile, HEALTHY


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


def _genome(human):
    return getattr(human, "genome", {}) if human else {}


def _age(human):
    return getattr(human, "age", 50) if human else 50


def _headroom(profile):
    """0..1 — how insulin-resistant vs the healthy reference (more room to benefit)."""
    return _clamp((HEALTHY.Si - profile.Si) / HEALTHY.Si, 0.0, 1.0)


def metformin(profile: MetabolicProfile, human=None, dose: float = 1.0, pk: dict = None):
    """dose → exposure → effect. Exposure comes from the hepatic PK engine
    (1-compartment oral, individualized OCT1 / renal / weight): the drug's
    hepatic (effect-site) exposure ratio IS the potency — no separate hand-set
    gates, so PK and pharmacodynamics speak one number."""
    from .hepatic_pk import pk_profile
    if pk is None:
        from types import SimpleNamespace

        # The frozen executable profile is authoritative for body weight even
        # when the admitted person's demographic wrapper has no weight attribute.
        pk_human = SimpleNamespace(age=_age(human), genome=_genome(human), weight_kg=profile.weight_kg)
        pk = pk_profile("metformin", dose_mg=1000.0 * dose, human=pk_human)
    ind = pk["individualization"]
    oct1_lof, transport, renal = ind["oct1_lof_alleles"], ind["oct1_transport"], ind["renal_factor"]
    resistance = _headroom(profile)
    potency = pk["hepatic_exposure_ratio"]          # dose × renal exposure × OCT1 uptake
    headroom = 0.45 + 0.55 * resistance
    d_si = 0.34 * potency * headroom
    d_gb = 0.12 * potency * headroom
    new = replace(profile, name=f"{profile.name}+metformin",
                  Si=profile.Si * (1 + d_si), Gb=profile.Gb * (1 - d_gb),
                  Ib=profile.Ib * (1 + 0.08 * potency))
    why = dict(drug="metformin", dose=round(dose, 2), dose_mg=pk["dose_mg"],
               mechanism="AMPK↑ → hepatic glucose output↓; hepatic uptake gated by OCT1/SLC22A1",
               oct1_lof_alleles=oct1_lof, oct1_transport=round(transport, 2),
               baseline_resistance=round(resistance, 2), renal_factor=round(renal, 2),
               pk=dict(auc_mg_h_L=pk["auc_mg_h_L"], cmax_mg_L=pk["cmax_mg_L"],
                       t_half_h=pk["t_half_h"], exposure_ratio=pk["exposure_ratio"],
                       hepatic_exposure_ratio=pk["hepatic_exposure_ratio"]),
               realized_Si_gain_pct=round(d_si * 100, 1), realized_Gb_drop_pct=round(d_gb * 100, 1))
    return new, why


def plant_compound(profile: MetabolicProfile, human=None, name: str = "compound",
                   targets: dict = None, dose: float = 1.0):
    """Reject the retired generic benefit path; named Cendos protocols are separate."""
    from .integrity import UnsupportedInterventionError

    raise UnsupportedInterventionError(
        "No qualified compound-to-physiology model is available; use a registered "
        "compound-specific Cendos protocol or admit experimental evidence"
    )
