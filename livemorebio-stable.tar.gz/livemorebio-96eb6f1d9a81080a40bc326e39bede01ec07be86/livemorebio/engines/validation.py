"""
livemorebio.engines.validation — retrospective validation against landmark trials.

The credibility keystone: a documented clinical result must reproduce end-to-end on
the platform. We calibrate ONLY the placebo baseline, then the intervention effects
must EMERGE from the mechanism (disease-emergence trajectory + individualized drug /
lifestyle), not be tuned per arm.

Diabetes Prevention Program (DPP, NEJM 2002; NCT00038727): 3,234 prediabetic adults
(mean age 51, BMI 34), 3 arms — placebo, metformin 850 mg BID, intensive lifestyle
(7% weight loss + 150 min/week activity). 3-year cumulative diabetes incidence:
placebo 28.9%, metformin 21.7%, lifestyle 14.4%; relative risk reduction vs placebo:
metformin 31%, lifestyle 58%.
"""
from __future__ import annotations
import random
from types import SimpleNamespace
from .trajectory import ExposurePattern, simulate_disease_trajectory

DPP_TARGET = {"placebo": 28.9, "metformin": 21.7, "lifestyle": 14.4,
              "rrr_metformin": 31.0, "rrr_lifestyle": 58.0}

# T2D risk variants sampled into the cohort (population-realistic)
_RISK_VARIANTS = [("TCF7L2", 0.30), ("PPARG_loss", 0.12), ("APOE4", 0.14), ("KCNJ11", 0.35)]


def dpp_cohort(n, seed=0):
    """A prediabetic, overweight, middle-aged cohort matching DPP baseline."""
    rng = random.Random(seed)
    people = []
    for i in range(n):
        sex = "F" if rng.random() < 0.68 else "M"                    # 68% women
        age = int(rng.gauss(51, 7))
        height = rng.gauss(175 if sex == "M" else 162, 7)
        bmi = max(27.0, rng.gauss(34.0, 5.0))                        # overweight/obese, prediabetic
        genome = {}
        for sym, af in _RISK_VARIANTS:
            d = sum(1 for _ in range(2) if rng.random() < af)
            if d:
                genome[sym] = d
        people.append(SimpleNamespace(id=f"DPP{i:04d}", age=age, sex=sex,
                                      height_cm=height, bmi=bmi, genome=genome,
                                      lifestyle=0.3, conditions=["prediabetes"]))
    return people


def _weight(p):
    return p.bmi * (p.height_cm / 100.0) ** 2


def _maintenance_kcal(p):
    # Mifflin-St Jeor at ~sedentary (their habitual state)
    b = 10 * _weight(p) + 6.25 * p.height_cm - 5 * p.age
    b += 5 if p.sex == "M" else -161
    return b * 1.35


def _arms(p):
    maint = _maintenance_kcal(p)
    return {
        # placebo: habitual sedentary, weight-stable prediabetic (maintenance)
        "placebo": ExposurePattern(kcal_intake=maint, activity=0.25),
        # metformin: same habits + the drug (effect emerges from the drug path)
        "metformin": ExposurePattern(kcal_intake=maint, activity=0.25, drugs=("metformin",)),
        # intensive lifestyle: +activity, modest deficit for ~7% loss (real-world adherence, not perfect)
        "lifestyle": ExposurePattern(kcal_intake=maint - 120, activity=0.48),
    }


def dpp_validation(n=200, years=3, seed=0):
    cohort = dpp_cohort(n, seed)
    incidence = {"placebo": 0, "metformin": 0, "lifestyle": 0}
    for p in cohort:
        arms = _arms(p)
        for arm, exposure in arms.items():
            traj = simulate_disease_trajectory(p, exposure, years=years,
                                               weight_kg=_weight(p), height_cm=p.height_cm)
            onset = traj["diabetes_onset_year"]
            if onset is not None and onset <= years:
                incidence[arm] += 1
    pct = {a: round(100 * c / n, 1) for a, c in incidence.items()}
    rrr = {"metformin": round(100 * (pct["placebo"] - pct["metformin"]) / pct["placebo"], 1) if pct["placebo"] else 0,
           "lifestyle": round(100 * (pct["placebo"] - pct["lifestyle"]) / pct["placebo"], 1) if pct["placebo"] else 0}
    return {"n": n, "years": years, "incidence_pct": pct, "rrr_pct": rrr,
            "dpp_target": DPP_TARGET,
            "ordering_correct": pct["lifestyle"] < pct["metformin"] < pct["placebo"]}
