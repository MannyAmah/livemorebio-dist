"""
livemorebio.engines.factors — non-food factors as exposures on the shared model.

Completes multi-factor disease causation: genes + food + drugs + STRESS + LIFESTYLE +
ENVIRONMENT, all flowing through one framework. Two kinds:

  CHEMICAL / environmental (BPA, nicotine, phthalates, pollutants): resolved to molecular
  targets via ChEMBL bioactivity -> GEM constraints + Open Targets disease signature —
  the same path foods/drugs use (organic chemicals; heavy metals would need CTD).

  PHYSIOLOGICAL (stress, sleep, exercise, alcohol): act through hormonal / physiological
  axes -> mechanistic modifiers on the glucose-insulin parameters (Si, Gb) and energy
  balance. Grounded in established physiology; magnitudes literature-informed, not fitted.
"""
from __future__ import annotations

# factor -> per-unit-intensity physiological modifiers + named mechanism.
# si_mult<1 = insulin resistance; gb_mult>1 = higher hepatic glucose; kcal_add = net energy shift.
PHYSIOLOGICAL_FACTORS = {
    "chronic stress": {
        "mechanism": "HPA axis → cortisol → glucocorticoid receptor (NR3C1) → gluconeogenesis ↑, "
                     "insulin sensitivity ↓, visceral adiposity ↑",
        "si_mult": 0.82, "gb_mult": 1.15, "kcal_add": 150.0,
        "gene_targets": {"PCK1": 1.4, "G6PC": 1.4}},
    "sleep deprivation": {
        "mechanism": "circadian disruption → insulin resistance; ghrelin ↑ (appetite)",
        "si_mult": 0.87, "gb_mult": 1.05, "kcal_add": 250.0},
    "sedentary": {
        "mechanism": "low AMPK / GLUT4 → reduced insulin sensitivity and expenditure",
        "si_mult": 0.90, "gb_mult": 1.02, "kcal_add": 0.0},
    "regular exercise": {
        "mechanism": "AMPK activation, GLUT4 translocation → improved insulin sensitivity",
        "si_mult": 1.22, "gb_mult": 0.94, "kcal_add": -100.0},
    "chronic alcohol": {
        "mechanism": "hepatic ethanol metabolism → steatosis, dysregulated gluconeogenesis",
        "si_mult": 0.90, "gb_mult": 1.10, "kcal_add": 300.0},
    "smoking": {
        "mechanism": "nicotine/PAHs → insulin resistance, systemic inflammation, vascular injury",
        "si_mult": 0.90, "gb_mult": 1.05, "kcal_add": 0.0},
}


def resolve_factor(name: str) -> dict:
    """A physiological factor -> mechanistic modifiers; otherwise a chemical/environmental
    exposure -> molecular targets via ChEMBL bioactivity."""
    key = (name or "").strip().lower()
    if key in PHYSIOLOGICAL_FACTORS:
        return {"name": name, "kind": "physiological", "resolved": True, **PHYSIOLOGICAL_FACTORS[key]}
    from .drug_targets import resolve_bioactive
    r = resolve_bioactive(name)
    return {"name": name, "kind": "chemical", "resolved": r.get("resolved", False),
            "chembl_id": r.get("chembl_id"), "targets": r.get("targets", [])}


def factor_disease_signature(name: str, top: int = 6):
    """Chemical factor -> its Open Targets disease signature (BPA -> cancer, etc.)."""
    f = resolve_factor(name)
    if f["kind"] != "chemical" or not f.get("targets"):
        return []
    from .disease_links import exposure_disease_signature
    return exposure_disease_signature([t["gene"] for t in f["targets"]], top=top)


def aggregate_physiological_modifiers(stress: float = 0.0, factors=()) -> dict:
    """Combine stress (0-1) + named physiological factors into net Si/Gb/kcal modifiers."""
    si_mult, gb_mult, kcal_add = 1.0, 1.0, 0.0
    items = []
    if stress and stress > 0:
        f = PHYSIOLOGICAL_FACTORS["chronic stress"]
        si_mult *= 1 - stress * (1 - f["si_mult"])
        gb_mult *= 1 + stress * (f["gb_mult"] - 1)
        kcal_add += stress * f["kcal_add"]
        items.append(f"chronic stress×{stress:.1f}")
    for name in factors or ():
        f = resolve_factor(name)
        if f.get("kind") == "physiological":
            si_mult *= f.get("si_mult", 1.0)
            gb_mult *= f.get("gb_mult", 1.0)
            kcal_add += f.get("kcal_add", 0.0)
            items.append(name)
    return {"si_mult": round(si_mult, 3), "gb_mult": round(gb_mult, 3),
            "kcal_add": round(kcal_add, 0), "applied": items}
