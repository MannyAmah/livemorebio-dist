"""Resolve ChEMBL molecular targets as reference associations.

Binding and mechanism records are retained for research. They do not automatically
set inhibition direction, quantitative flux constraints or human response.
"""
from __future__ import annotations
import json
import os
import functools
import urllib.request
import urllib.parse

CHEMBL = "https://www.ebi.ac.uk/chembl/api/data"

# Compatibility name for the retired action-label-to-flux conversion.
ACTION_SCALE = {}  # Retained import name; action labels establish no quantitative scale.


def _get(url):
    with urllib.request.urlopen(url, timeout=12) as r:
        return json.load(r)


@functools.lru_cache(maxsize=1024)
def _target_genes(target_chembl_id):
    if not target_chembl_id:
        return ()
    try:
        t = _get(f"{CHEMBL}/target/{target_chembl_id}.json")
    except Exception:
        return ()
    genes = []
    for comp in t.get("target_components", []):
        for syn in comp.get("target_component_synonyms", []):
            if syn.get("syn_type") == "GENE_SYMBOL":
                genes.append(syn["component_synonym"])
    return tuple(sorted(set(genes)))


@functools.lru_cache(maxsize=512)
def resolve_drug(name):
    """name -> {name, chembl_id, resolved, targets:[{gene, action, moa, scale}]}"""
    q = urllib.parse.quote(name.strip().lower())
    try:
        mol = _get(f"{CHEMBL}/molecule.json?pref_name__iexact={q}")
        hits = mol.get("molecules", [])
        if not hits:
            mol = _get(f"{CHEMBL}/molecule/search.json?q={q}")
            hits = mol.get("molecules", [])
        if not hits:
            return {"name": name, "resolved": False, "targets": []}
        cid = hits[0]["molecule_chembl_id"]
        mech = _get(f"{CHEMBL}/mechanism.json?parent_molecule_chembl_id={cid}")
        targets = []
        for m in mech.get("mechanisms", []):
            action = (m.get("action_type") or "").upper()
            for gene in _target_genes(m.get("target_chembl_id")):
                targets.append({"gene": gene, "action": m.get("action_type"),
                                "moa": m.get("mechanism_of_action"),
                                "scale": None, "execution_status": "REFERENCE_ONLY"})
        # de-dup by gene
        seen, uniq = set(), []
        for t in targets:
            if t["gene"] not in seen:
                seen.add(t["gene"]); uniq.append(t)
        return {"name": name, "chembl_id": cid, "resolved": bool(uniq), "targets": uniq,
                "execution_status": "REFERENCE_ONLY",
                "reason": "mechanism labels do not establish concentration-dependent physiological effects"}
    except Exception as e:
        return {"name": name, "resolved": False, "targets": [], "error": f"{type(e).__name__}: {e}"}


@functools.lru_cache(maxsize=512)
def resolve_bioactive(name, max_targets=10, potency_nm=1000):
    """Resolve a compound to targets via ChEMBL BIOACTIVITY (measured IC50/Ki/EC50),
    for natural/phytochemical compounds that lack a curated mechanism-of-action.
    Targets ranked by number of potent (<= potency_nm) measurements. Real data."""
    q = urllib.parse.quote(name.strip().lower())
    try:
        mol = _get(f"{CHEMBL}/molecule.json?pref_name__iexact={q}")
        hits = mol.get("molecules", [])
        if not hits:
            mol = _get(f"{CHEMBL}/molecule/search.json?q={q}")
            hits = mol.get("molecules", [])
        if not hits:
            return {"name": name, "resolved": False, "targets": []}
        cid = hits[0]["molecule_chembl_id"]
        act = _get(f"{CHEMBL}/activity.json?molecule_chembl_id={cid}"
                   f"&standard_type__in=IC50,Ki,Kd,EC50&limit=300")
        counts = {}
        for a in act.get("activities", []):
            v, u, t = a.get("standard_value"), a.get("standard_units"), a.get("target_chembl_id")
            if t and v and u == "nM":
                try:
                    if float(v) <= potency_nm:
                        counts[t] = counts.get(t, 0) + 1
                except (TypeError, ValueError):
                    pass
        targets, seen = [], set()
        for t in sorted(counts, key=lambda k: -counts[k])[:max_targets]:
            for gene in _target_genes(t):
                if gene not in seen:
                    seen.add(gene)
                    targets.append({"gene": gene, "action": "UNKNOWN", "scale": None,
                                    "target": t, "n_measurements": counts[t],
                                    "execution_status": "REFERENCE_ONLY"})
        return {"name": name, "chembl_id": cid, "resolved": bool(targets), "targets": targets,
                "execution_status": "REFERENCE_ONLY",
                "reason": "binding and activity records do not establish a shared direction or physiological effect"}
    except Exception as e:
        return {"name": name, "resolved": False, "targets": [], "error": f"{type(e).__name__}: {e}"}
