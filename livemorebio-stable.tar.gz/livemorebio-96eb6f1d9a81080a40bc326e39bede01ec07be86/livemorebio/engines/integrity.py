"""Shared failure for an intervention without an executable evidence contract."""
from __future__ import annotations


class UnsupportedInterventionError(ValueError):
    """Reference association or user-supplied effects cannot establish drug response."""

    code = "UNSUPPORTED_BIOLOGICAL_INTERVENTION"

    def __init__(self, reason: str = "No qualified compound-to-physiology model is available") -> None:
        super().__init__(reason)
