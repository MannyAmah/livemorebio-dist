"""
livemorebio.engines.foods — foods as multi-factor exposures on the human model.

Food lookup returns macronutrient composition and constituent references.
The runtime can apply carbohydrate content through its existing meal equation.
Phytochemical associations remain reference-only: constituent identity alone
cannot supply concentrations, enzyme constraints or human therapeutic effects.
"""
from __future__ import annotations
import json
import urllib.request
import urllib.parse
import functools
import os

FDC = "https://api.nal.usda.gov/fdc/v1/foods/search"

# Curated ethnobotanical phytochemistry (food -> characteristic bioactive compounds).
# Extensible; each compound is resolved to real targets via ChEMBL at run time.
PHYTOCHEMICALS = {
    "bitter kola": ["kolaviron", "quercetin"],
    "garcinia kola": ["kolaviron"],
    "moringa": ["quercetin", "kaempferol", "chlorogenic acid"],
    "turmeric": ["curcumin"],
    "green tea": ["epigallocatechin gallate"],
    "ginger": ["gingerol"],
    "garlic": ["allicin"],
    "soybean": ["genistein"],
}


def _get(url):
    with urllib.request.urlopen(url, timeout=12) as r:
        return json.load(r)


# Curated macros (per 100 g) for key ethnobotanicals — fallback when USDA is
# unavailable/rate-limited. USDA FoodData Central provides the general (~million-food)
# coverage; an explicit ``USDA_API_KEY`` enables the governed live retrieval path.
CURATED_MACROS = {
    "moringa": {"kcal": 64.0, "protein_g": 9.4, "fat_g": 1.4, "carb_g": 8.3},
    "bitter kola": {"kcal": 149.0, "protein_g": 2.0, "fat_g": 1.0, "carb_g": 34.0},
    "garcinia kola": {"kcal": 149.0, "protein_g": 2.0, "fat_g": 1.0, "carb_g": 34.0},
    "turmeric": {"kcal": 312.0, "protein_g": 9.7, "fat_g": 3.2, "carb_g": 67.1},
    "green tea": {"kcal": 1.0, "protein_g": 0.2, "fat_g": 0.0, "carb_g": 0.0},
    "ginger": {"kcal": 80.0, "protein_g": 1.8, "fat_g": 0.8, "carb_g": 18.0},
    "garlic": {"kcal": 149.0, "protein_g": 6.4, "fat_g": 0.5, "carb_g": 33.0},
    "soybean": {"kcal": 446.0, "protein_g": 36.5, "fat_g": 19.9, "carb_g": 30.2},
}


def _usda_macros(name):
    key = os.environ.get("USDA_API_KEY", "").strip()
    if not key:
        return None, {}
    q = urllib.parse.urlencode({"query": name, "pageSize": 3,
                                "dataType": "Foundation,SR Legacy", "api_key": key})
    q_fallback = urllib.parse.urlencode({"query": name, "pageSize": 1, "api_key": key})
    for url in (f"{FDC}?{q}", f"{FDC}?{q_fallback}"):
        try:
            foods = _get(url).get("foods", [])
        except Exception:
            foods = []
        if foods:
            f = foods[0]
            wanted = {"Carbohydrate, by difference": "carb_g", "Total lipid (fat)": "fat_g",
                      "Protein": "protein_g", "Energy": "kcal"}
            macros = {wanted[n["nutrientName"]]: n.get("value")
                      for n in f.get("foodNutrients", []) if n.get("nutrientName") in wanted}
            if macros:
                return f.get("description"), macros
    return None, {}


@functools.lru_cache(maxsize=512)
def resolve_food(name: str) -> dict:
    """name -> {description, macros per 100 g, phytochemicals}. Phytochemicals (curated +
    ChEMBL bioactivity) are always available; macros from USDA FoodData Central with a
    curated fallback for key ethnobotanicals."""
    phyto = PHYTOCHEMICALS.get(name.lower(), [])
    desc, macros = _usda_macros(name)
    if not macros:
        macros = CURATED_MACROS.get(name.lower(), {})
        desc = desc or (name if macros else None)
    return {"name": name, "description": desc, "resolved": bool(macros or phyto),
            "macros": macros, "phytochemicals": phyto}


def phytochemical_targets(food: dict) -> list:
    """Resolve a food's phytochemicals to molecular targets (ChEMBL), like drugs."""
    from .drug_targets import resolve_bioactive as _resolve
    out = []
    for compound in food.get("phytochemicals", []):
        info = _resolve(compound)
        if info.get("resolved"):
            out.append({"compound": compound, "chembl_id": info.get("chembl_id"),
                        "targets": info.get("targets", [])})
    return out
