"""Retired Recon3D compatibility surface; commercial execution is blocked.

Historical helpers are preserved for migration but cannot load a model or apply
generic gene scaling. They did not establish a patient-specific physiological
operating point or qualify drug effects. The current supported network analysis
is the separately pinned Human-GEM steady-state capacity protocol, whose results
remain unqualified model calculations rather than observations.
"""
from __future__ import annotations
import os
import functools
import cobra

MODEL_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "models", "Recon3D.xml"))
GLUCOSE_EX = "EX_glc__D_e"
O2_EX = "EX_o2_e"
ATP_MAINTENANCE = "ATPM"
# defined aerobic minimal medium: glucose is the sole carbon source; inorganics open
_INORGANIC = ["h2o", "pi", "h", "co2", "nh4", "so4", "na1", "k", "cl", "ca2", "fe2", "fe3", "mg2", "o2", "hco3"]


@functools.lru_cache(maxsize=1)
def load_recon3d():
    """Local file presence is neither permission nor scientific qualification."""
    from .integrity import UnsupportedInterventionError
    raise UnsupportedInterventionError("Legacy Recon3D execution is retired; commercial execution is not authorized")


def _apply_minimal_medium(model, glucose=1.0, oxygen=True):
    """Glucose sole carbon source; close free-supply sinks/demands; inorganics open."""
    present = {r.id for r in model.reactions if r.boundary}
    med = {f"EX_{i}_e": 1000.0 for i in _INORGANIC if f"EX_{i}_e" in present}
    med[GLUCOSE_EX] = glucose
    if not oxygen:
        med.pop(O2_EX, None)
    model.medium = med
    for r in model.reactions:
        if r.id.startswith(("SK_", "sink_", "DM_")):
            r.lower_bound = 0.0            # sinks may remove byproducts, not supply substrate
    model.objective = ATP_MAINTENANCE


def _find_gene(model, symbol):
    s = (symbol or "").upper().split("_")[0]
    for g in model.genes:
        if (g.name or "").upper() == s or g.id.upper().split(".")[0] == s:
            return g
    for g in model.genes:
        ann = g.annotation or {}
        for v in ann.values():
            vals = v if isinstance(v, list) else [v]
            if any(isinstance(x, str) and x.upper() == s for x in vals):
                return g
    return None


def _scale_gene(model, gene, scale):
    from .integrity import UnsupportedInterventionError
    raise UnsupportedInterventionError("Legacy gene scaling is retired; no qualified variant-to-flux mapping exists")


def atp_yield(gene_perturbations: dict = None, genome: dict = None, oxygen=True) -> float:
    """Max ATP per unit glucose under a person's genome + drug/food perturbations.
    gene_perturbations {symbol: scale}; genome {symbol_lof: dose}. Returns ATP/glucose."""
    model = load_recon3d()
    with model:
        _apply_minimal_medium(model, oxygen=oxygen)
        for sym, dose in (genome or {}).items():
            g = _find_gene(model, sym)
            if g:
                _scale_gene(model, g, max(0.0, 1.0 - 0.5 * min(int(dose), 2)))
        for sym, scale in (gene_perturbations or {}).items():
            g = _find_gene(model, sym)
            if g:
                _scale_gene(model, g, float(scale))
        return round(model.optimize().objective_value, 2)


def validate_calibration() -> dict:
    """QC: EGC-free (no-substrate ATP=0) AND textbook yields (aerobic 32, anaerobic 2)."""
    model = load_recon3d()
    with model:
        for r in model.reactions:
            if r.boundary:
                r.lower_bound = 0.0
        model.objective = ATP_MAINTENANCE
        free = round(model.optimize().objective_value, 3)
    aer = atp_yield(oxygen=True)
    ana = atp_yield(oxygen=False)
    return {"model": "Recon3D", "free_atp_no_substrate": free,
            "aerobic_atp_per_glucose": aer, "anaerobic_atp_per_glucose": ana,
            "egc_free": abs(free) < 1e-6, "energetics_valid": 28 <= aer <= 34 and 1.5 <= ana <= 3.5}


def drug_atp_response(drug_name: str, genome: dict = None, dose: float = 1.0) -> dict:
    """A target association alone cannot set enzyme inhibition or ATP response."""
    from .integrity import UnsupportedInterventionError

    raise UnsupportedInterventionError("No qualified drug concentration-to-ATP-flux model is available")


# ---------------------------------------------------------------------------
# Metabolic capacities — the individualized bridge to the physiological engines.
# The genome-scale model computes, per person, two quantities that parameterize
# the Bergman glucose-insulin ODE: oxidative ATP capacity (mitochondrial function
# -> insulin sensitivity) and gluconeogenic capacity (hepatic glucose output).
# ---------------------------------------------------------------------------
def gluconeogenic_capacity(gene_perturbations: dict = None, genome: dict = None) -> float:
    """Max glucose the liver can synthesise from lactate (gluconeogenesis). Metformin
    and OXPHOS variants lower it -> the mechanism behind fasting-glucose control."""
    model = load_recon3d()
    present = {r.id for r in model.reactions if r.boundary}
    with model:
        med = {f"EX_{i}_e": 1000.0 for i in _INORGANIC if f"EX_{i}_e" in present}
        if "EX_lac__L_e" in present:
            med["EX_lac__L_e"] = 10.0
        model.medium = med
        for r in model.reactions:
            if r.id.startswith(("SK_", "sink_", "DM_")):
                r.lower_bound = 0.0
        model.reactions.get_by_id(GLUCOSE_EX).lower_bound = 0.0     # no glucose uptake
        for sym, dose in (genome or {}).items():
            g = _find_gene(model, sym)
            if g:
                _scale_gene(model, g, max(0.0, 1.0 - 0.5 * min(int(dose), 2)))
        for sym, scale in (gene_perturbations or {}).items():
            g = _find_gene(model, sym)
            if g:
                _scale_gene(model, g, float(scale))
        model.objective = GLUCOSE_EX                                 # maximise glucose OUT
        return round(model.optimize().objective_value, 3)


@functools.lru_cache(maxsize=512)
def _capacities_cached(genome_key: tuple, pert_key: tuple) -> tuple:
    genome = dict(genome_key) or None
    pert = dict(pert_key) or None
    return (atp_yield(pert, genome), gluconeogenic_capacity(pert, genome))


def metabolic_capacities(genome: dict = None, gene_perturbations: dict = None) -> dict:
    gk = tuple(sorted((genome or {}).items()))
    pk = tuple(sorted((gene_perturbations or {}).items()))
    o, g = _capacities_cached(gk, pk)
    return {"oxidative_atp": o, "gluconeogenic": g}


@functools.lru_cache(maxsize=1)
def reference_capacities() -> tuple:
    c = metabolic_capacities()
    return (c["oxidative_atp"], c["gluconeogenic"])


def substrate_atp_yield(exchange_id: str, amount: float = 1.0) -> float:
    """ATP per molecule of a given fuel, aerobic — validates multi-substrate energetics
    (glucose ~32, palmitate ~113, amino acids ~15-22). Foods provide these fuels."""
    model = load_recon3d()
    present = {r.id for r in model.reactions if r.boundary}
    with model:
        med = {f"EX_{i}_e": 1000.0 for i in _INORGANIC if f"EX_{i}_e" in present}
        model.medium = med
        for r in model.reactions:
            if r.id.startswith(("SK_", "sink_", "DM_")):
                r.lower_bound = 0.0
        model.reactions.get_by_id(GLUCOSE_EX).lower_bound = 0.0
        if exchange_id in present:
            model.reactions.get_by_id(exchange_id).lower_bound = -amount
        model.objective = ATP_MAINTENANCE
        return round(model.optimize().objective_value / amount, 1)


# ---------------------------------------------------------------------------
# Physiological operating point (#3.4). Instead of a theoretical MAX capacity
# (which saturates), pin the model to a realistic operating point — limited
# substrate + a fixed ATP-maintenance demand drawn from the PERSON (activity,
# state) — so a drug/food effect emerges from that individual's biology and
# varies across people. Nothing hard-coded.
# ---------------------------------------------------------------------------
def physiological_gluconeogenesis(genome: dict = None, gene_perturbations: dict = None,
                                  atp_demand: float = 20.0, substrate: float = 10.0) -> float:
    """Gluconeogenic flux at a physiological operating point (limited lactate + fixed ATP
    demand). Individualized by genome, diet (substrate) and demand (activity/state)."""
    model = load_recon3d()
    present = {r.id for r in model.reactions if r.boundary}
    with model:
        med = {f"EX_{i}_e": 1000.0 for i in _INORGANIC if f"EX_{i}_e" in present}
        if "EX_lac__L_e" in present:
            med["EX_lac__L_e"] = substrate
        model.medium = med
        for r in model.reactions:
            if r.id.startswith(("SK_", "sink_", "DM_")):
                r.lower_bound = 0.0
        model.reactions.get_by_id(GLUCOSE_EX).lower_bound = 0.0
        model.reactions.get_by_id(ATP_MAINTENANCE).lower_bound = float(atp_demand)
        for sym, dose in (genome or {}).items():
            g = _find_gene(model, sym)
            if g:
                _scale_gene(model, g, max(0.0, 1.0 - 0.5 * min(int(dose), 2)))
        for sym, scale in (gene_perturbations or {}).items():
            g = _find_gene(model, sym)
            if g:
                _scale_gene(model, g, max(0.0, float(scale)))
        model.objective = GLUCOSE_EX
        s = model.optimize()
        return round(s.objective_value, 3) if s.status == "optimal" else 0.0


def operating_point(human) -> tuple:
    """Lifestyle and disease labels do not determine measured substrate fluxes."""
    from .integrity import UnsupportedInterventionError
    raise UnsupportedInterventionError("Legacy physiological operating point is retired; no qualified person-to-flux mapping exists")


# ---------------------------------------------------------------------------
# Target-matched disease-pathway readouts (closing #3). Phytochemical/drug/factor
# targets often act off the glucose axis; here we quantify their effect on the
# disease-relevant metabolic product they control (cholesterol->CVD, urate->gout,
# sorbitol/polyol->diabetic complications, lipogenesis->NAFLD). The model correctly
# shows clean effects for committed enzymes (HMGCR, XDH) and redundancy-buffering
# for others (AKR1B1) — real biology, not hand-coded.
# ---------------------------------------------------------------------------
METABOLIC_DISEASE_PATHWAYS = {
    "HMGCR":  {"product": "chsterol_c", "pathway": "cholesterol synthesis", "disease": "cardiovascular"},
    "XDH":    {"product": "urate_c",    "pathway": "purine catabolism / urate", "disease": "gout / hyperuricemia"},
    "AKR1B1": {"product": "sbt__D_c",   "pathway": "polyol / sorbitol", "disease": "diabetic complications"},
    "FASN":   {"product": "hdca_c",     "pathway": "de novo lipogenesis", "disease": "NAFLD / obesity"},
}


def _product_flux(met_id, genome=None, gene_perturbations=None):
    model = load_recon3d()
    present = {r.id for r in model.reactions if r.boundary}
    with model:
        med = {f"EX_{i}_e": 1000.0 for i in _INORGANIC if f"EX_{i}_e" in present}
        med[GLUCOSE_EX] = 1.0                        # glucose sole carbon
        model.medium = med
        for r in model.reactions:
            if r.id.startswith(("SK_", "sink_", "DM_")):
                r.lower_bound = 0.0
        for sym, dose in (genome or {}).items():
            g = _find_gene(model, sym)
            if g:
                _scale_gene(model, g, max(0.0, 1.0 - 0.5 * min(int(dose), 2)))
        for sym, scale in (gene_perturbations or {}).items():
            g = _find_gene(model, sym)
            if g:
                if float(scale) <= 0.3:              # strong inhibitor -> GPR-aware knockout
                    g.knock_out()
                else:
                    _scale_gene(model, g, max(0.0, float(scale)))
        try:
            met = model.metabolites.get_by_id(met_id)
        except KeyError:
            return None
        dm = model.add_boundary(met, type="demand", reaction_id="DM_lm_pathway")
        model.objective = dm.id
        s = model.optimize()
        return round(s.objective_value, 3) if s.status == "optimal" else 0.0


def target_pathway_effects(target_genes, genome=None, gene_perturbations=None):
    """For an exposure's targets that control a disease-relevant metabolic pathway, the
    change in that pathway's product flux — the target-matched quantitative readout."""
    out = []
    for gene in set(target_genes):
        info = METABOLIC_DISEASE_PATHWAYS.get(gene)
        if not info:
            continue
        base = _product_flux(info["product"], genome, None)
        treated = _product_flux(info["product"], genome, gene_perturbations)
        if base is None:
            continue
        pct = round(100 * (treated - base) / base, 1) if base else 0.0
        out.append({"gene": gene, "pathway": info["pathway"], "disease": info["disease"],
                    "flux_change_pct": pct, "buffered": abs(pct) < 1.0})
    return out
