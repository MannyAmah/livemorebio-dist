"""Reference anatomy with explicit model-parameter and unavailable-function labels.

An anatomical mesh or a pathway annotation does not execute that organ's physiology.
The reduced metabolic model exposes its actual parameters; it does not supply renal,
neural, adipocyte, GLUT4 transport or molecular-exocytosis dynamics. Cardiac traces
are separately computed by the ventricular-cell engine and are not whole-heart mechanics.
"""
from __future__ import annotations

# Body-system binding into the canonical human-body ontology
# (livemorebio/anatomy/ontology/human-body-core.json system ids).
ORGAN_SYSTEM = {
    "liver": "digestive_hepatobiliary",
    "pancreas": "endocrine",
    "muscle": "muscular",
    "adipose": "endocrine",
    "kidney": "urinary",
    "heart": "cardiovascular",
    "brain": "nervous",
}


# Metabolic organs: real mesh + role + Recon3D pathways + molecular targets + the twin
# parameter that drives their live state + a representative cell (cellular scale).
ORGAN_ATLAS = {
    "liver": {
        "name": "Liver", "mesh": "/assets/anatomy/liver.glb",
        "role": "hepatic glucose output, cholesterol & lipid synthesis, drug metabolism",
        "pathways": ["gluconeogenesis", "cholesterol synthesis", "de novo lipogenesis"],
        "targets": ["PCK1", "G6PC", "HMGCR", "FASN"], "driver": "Gb", "pos": [0.0, 0.2, 0.0],
        "cell": {"type": "Hepatocyte", "process": "gluconeogenesis · glycogen · de novo lipogenesis", "render": "export"}},
    "pancreas": {
        "name": "Pancreas (β-cells)", "mesh": "/assets/anatomy/pancreas.glb",
        "role": "insulin secretion — β-cell responsivity to glucose",
        "pathways": ["insulin secretion", "glucose sensing"],
        "targets": ["INS", "KCNJ11", "ABCC8", "GCK"], "driver": "gamma", "pos": [-0.3, 0.1, -0.1],
        "cell": {"type": "Pancreatic β-cell", "process": "glucose-stimulated insulin secretion (granule exocytosis)", "render": "secrete"}},
    "muscle": {
        "name": "Skeletal muscle", "mesh": "/assets/anatomy/muscle.glb",
        "role": "insulin-stimulated glucose uptake (largest glucose sink)",
        "pathways": ["glucose uptake (GLUT4)", "glycolysis", "oxidative phosphorylation"],
        "targets": ["SLC2A4", "AMPK", "PPARGC1A"], "driver": "Si", "pos": [0.5, -0.3, 0.0],
        "cell": {"type": "Skeletal myocyte", "process": "insulin-stimulated GLUT4 glucose uptake", "render": "uptake"}},
    "adipose": {
        "name": "Adipose tissue", "mesh": "/assets/anatomy/adipose.glb",
        "role": "lipid storage, adipokine signalling — drives insulin resistance when excess",
        "pathways": ["lipid storage", "lipolysis", "adipokine signalling"],
        "targets": ["PPARG", "LEP", "ADIPOQ"], "driver": "adiposity", "pos": [0.0, -0.5, 0.2],
        "cell": {"type": "Adipocyte", "process": "lipid storage · lipolysis · adipokine signalling", "render": "droplet"}},
    "kidney": {
        "name": "Kidney", "mesh": "/assets/anatomy/kidney.glb",
        "role": "glucose reabsorption (SGLT2), drug clearance",
        "pathways": ["glucose reabsorption", "renal clearance"],
        "targets": ["SLC5A2", "SLC22A1"], "driver": "renal", "pos": [-0.4, -0.4, -0.3],
        "cell": {"type": "Proximal tubule cell", "process": "SGLT2-mediated glucose reabsorption", "render": "uptake"}},
    "heart": {
        "name": "Heart", "mesh": "/assets/anatomy/heart.glb",
        "role": "cardiac electrophysiology — hERG/IKr repolarization (drug safety)",
        "pathways": ["cardiac action potential", "IKr / hERG repolarization"],
        "targets": ["KCNH2", "SCN5A", "CACNA1C"], "driver": "cardiac", "pos": [-0.05, 0.55, 0.15],
        "cell": {"type": "Ventricular cardiomyocyte", "process": "O'Hara–Rudy action potential · Ca²⁺ transient", "render": "cardiac"}},
    "brain": {
        "name": "Brain", "mesh": "/assets/anatomy/brain.glb",
        "role": "obligate glucose consumer; neurodegeneration risk axis",
        "pathways": ["glucose consumption", "neuroinflammation"],
        "targets": ["APP", "GLUT1"], "driver": "glucose", "pos": [-0.1, 1.05, 0.0],
        "cell": {"type": "Neuron", "process": "obligate glucose consumption", "render": "uptake"}},
}

HEALTHY = {"Si": 5.0e-4, "gamma": 0.12, "Gb": 90.0}


def biology_reference() -> dict:
    """Detached anatomical metadata for saved runs, without any active subject."""
    from copy import deepcopy
    from ..anatomy.meshes import CATALOG

    organs = []
    for organ_id, meta in ORGAN_ATLAS.items():
        mesh = CATALOG.get(organ_id, {})
        organs.append({
            "id": organ_id,
            **deepcopy({key: meta[key] for key in ("name", "mesh", "role", "pathways", "targets", "pos")}),
            "anatomy": {
                "structure": mesh.get("structure"), "uberon": mesh.get("uberon"),
                "fma": mesh.get("fma"), "mesh_source": mesh.get("source"),
                "mesh_license": mesh.get("license"), "system": ORGAN_SYSTEM.get(organ_id),
            },
            "status": "reference", "evidence_state": "REFERENCE_ONLY",
            "metric": None, "value": None, "ratio": None, "unit": None,
            "cell": {
                **deepcopy(meta["cell"]), "activity": None, "quantities": [],
                "evidence_state": "REFERENCE_ONLY",
                "note": "Reference anatomy and cell identity only; executing quantities require the selected run's own compartment and mechanism mapping.",
            },
        })
    return {"schema": "livemore.biology-reference.v1", "reference_geometry": True,
            "evidence_state": "REFERENCE_ONLY", "organs": organs}


def _status(driver, profile, cardiac_block=0.0):
    """Report a model parameter, never infer organ function from a proxy."""
    Si, Gb, gamma = profile.Si, profile.Gb, profile.gamma
    if driver == "Gb":
        result = {"metric": "Basal glucose parameter (Gb)", "value": round(Gb, 1),
                  "ratio": round(Gb / HEALTHY["Gb"], 2), "unit": "mg/dL"}
    elif driver == "gamma":
        result = {"metric": "Reduced-model responsivity parameter (γ)", "value": round(gamma, 4),
                  "ratio": round(gamma / HEALTHY["gamma"], 2), "unit": "(uU/mL/min)/(mg/dL)"}
    elif driver == "Si":
        result = {"metric": "Whole-body insulin sensitivity parameter (Si)", "value": round(Si, 6),
                  "ratio": round(Si / HEALTHY["Si"], 2), "unit": "(uU/mL)^-1 min^-1"}
    elif driver == "cardiac":
        result = {"metric": "Ventricular-cell IKr block input", "value": round(cardiac_block, 2),
                  "ratio": None, "unit": "fraction"}
    else:
        return {"metric": "Organ function not implemented", "value": None, "ratio": None,
                "unit": None, "status": "unavailable", "evidence_state": "REFERENCE_ONLY",
                "worse_is_high": None}
    return {**result, "status": "parameter", "evidence_state": "MODEL_PARAMETER", "worse_is_high": None}


def _cell(meta, profile):
    """Preserve cell references without inventing kinetic output from scalar priors."""
    render = meta["cell"]["render"]
    if render == "cardiac":
        note = "Computed O'Hara–Rudy ventricular-cell action potential and calcium trace, not a physical measurement or whole-heart mechanics."
        evidence = "MODELED_BIOPHYSICAL"
    else:
        note = "Reference cell/process only. Cellular transport and reaction kinetics are not executed in this view; reduced whole-body parameters cannot supply them."
        evidence = "REFERENCE_ONLY"
    return {"type": meta["cell"]["type"], "process": meta["cell"]["process"], "render": render,
            "activity": None, "quantities": [], "note": note, "evidence_state": evidence}


def biology_state(twin) -> dict:
    """The full multi-scale biological state for the current twin — a view onto the simulation."""
    from ..anatomy.meshes import CATALOG as MESH_CATALOG
    profile = twin.profile
    cardiac_block = getattr(twin, "cardiac_drug_block", 0.0)
    pk = getattr(twin, "pk_last", None)
    organs = []
    for oid, meta in ORGAN_ATLAS.items():
        st = _status(meta["driver"], profile, cardiac_block)
        mesh_entry = MESH_CATALOG.get(oid, {})
        anatomy = {"structure": mesh_entry.get("structure"),
                   "uberon": mesh_entry.get("uberon"), "fma": mesh_entry.get("fma"),
                   "mesh_source": mesh_entry.get("source"),
                   "mesh_license": mesh_entry.get("license"),
                   "system": ORGAN_SYSTEM.get(oid)}
        organ = {"id": oid, "name": meta["name"], "mesh": meta["mesh"], "role": meta["role"],
                 "pathways": meta["pathways"], "targets": meta["targets"], "pos": meta["pos"],
                 "anatomy": anatomy, "cell": _cell(meta, profile), **st}
        if oid == "liver" and pk:
            # hepatic PK engine output — the liver is actively handling a dosed drug
            organ["pk"] = {"drug": pk["drug"], "dose_mg": pk["dose_mg"],
                           "cmax_mg_L": pk["cmax_mg_L"], "auc_mg_h_L": pk["auc_mg_h_L"],
                           "t_half_h": pk["t_half_h"],
                           "hepatic_exposure_ratio": pk["hepatic_exposure_ratio"]}
        organs.append(organ)
    human = getattr(twin, "human", None)
    return {
        "organs": organs,
        "twin": {"profile": profile.name,
                 "Si": round(profile.Si, 6), "Gb": round(profile.Gb, 1), "gamma": round(profile.gamma, 4),
                 "human": getattr(human, "id", None),
                 "genome": getattr(human, "genome", {}) if human else {},
                 "conditions": getattr(human, "conditions", []) if human else []},
        "interventions": list(getattr(twin, "applied", []))[-6:],
        "last_intervention": getattr(twin, "last_intervention", None),
    }
