"""Retired unverified Human-GEM compatibility surface.

Historical helpers below are unreachable through the fail-closed loader. Their
unqualified gene-to-bound scaling is not a supported biological model. The
separate ``stoichiometry`` worker executes the pinned source with explicit medium,
complete GPR-aware knockouts, numerical controls and bounded runtime; it never
converts a target association into patient physiology.
"""
from __future__ import annotations
import os
import functools
import cobra

MODEL_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "models", "Human-GEM.xml"))


@functools.lru_cache(maxsize=1)
def load_human_gem():
    """Retired unverified file alias; only the pinned worker may execute assets."""
    from .integrity import UnsupportedInterventionError
    raise UnsupportedInterventionError("Legacy genome-scale execution is retired; use the explicit pinned Human-GEM capacity protocol")


GENES_TSV = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "models", "Human-GEM_genes.tsv"))


@functools.lru_cache(maxsize=1)
def _symbol_map():
    """symbol(UPPER) -> ENSG and ENSG -> symbol, from Human-GEM genes.tsv."""
    sym2ensg, ensg2sym = {}, {}
    try:
        with open(GENES_TSV, encoding="utf-8") as f:
            header = f.readline().rstrip("\n").split("\t")
            hi = [h.strip('"') for h in header]
            gi, si = hi.index("genes"), hi.index("geneSymbols")
            for line in f:
                cols = [c.strip('"') for c in line.rstrip("\n").split("\t")]
                ensg = cols[gi]
                for sym in cols[si].split(";"):
                    if sym:
                        sym2ensg[sym.upper()] = ensg
                if cols[si]:
                    ensg2sym[ensg] = cols[si].split(";")[0]
    except Exception:
        pass
    return sym2ensg, ensg2sym


def symbol_of(gene):
    _, ensg2sym = _symbol_map()
    return ensg2sym.get(gene.id, gene.name or gene.id)


def find_gene(model, symbol):
    s = (symbol or "").upper().split("_")[0]
    sym2ensg, _ = _symbol_map()
    ensg = sym2ensg.get(s)
    if ensg:
        try:
            return model.genes.get_by_id(ensg)
        except KeyError:
            pass
    for g in model.genes:
        if g.id.upper() == s or (g.name or "").upper() == s:
            return g
    return None


def _scale_gene_reactions(gene, scale):
    from .integrity import UnsupportedInterventionError
    raise UnsupportedInterventionError("Legacy gene scaling is retired; complete exact GPR-aware knockouts require the pinned capacity protocol")


def simulate(genome: dict = None, perturbations: dict = None, objective: str = None) -> dict:
    """Run FBA under a person's genome + a set of perturbations.
    Returns objective flux and status. Uses a cobra context so nothing persists."""
    model = load_human_gem()
    applied = {"genome": [], "perturbations": []}
    with model:
        if objective:
            model.objective = objective
        for sym, dose in (genome or {}).items():
            if str(sym).lower().endswith("lof") or str(sym).lower().endswith("_lof"):
                g = find_gene(model, sym)
                if g:
                    _scale_gene_reactions(g, max(0.0, 1.0 - 0.5 * min(int(dose), 2)))
                    applied["genome"].append(g.name or g.id)
        for sym, scale in (perturbations or {}).items():
            g = find_gene(model, sym)
            if g:
                _scale_gene_reactions(g, float(scale))
                applied["perturbations"].append(f"{g.name or g.id}×{scale}")
        sol = model.optimize()
        return {"objective": round(sol.objective_value, 4), "status": sol.status, "applied": applied}


def model_info() -> dict:
    m = load_human_gem()
    return {"model": "Human-GEM", "reactions": len(m.reactions), "genes": len(m.genes),
            "metabolites": len(m.metabolites), "compartments": len(m.compartments)}


def drug_response(genome: dict = None, drug_name: str = None, dose: float = 1.0) -> dict:
    """Drug associations need a qualified concentration-to-flux model before execution."""
    from .integrity import UnsupportedInterventionError

    raise UnsupportedInterventionError("No qualified drug concentration-to-GEM-flux model is available")


# ---------------------------------------------------------------------------
# Calibration / QC — energy-generating-cycle (EGC) detection.
# Historical partial-medium QC is retired. The pinned v2.0.0 protocol checks
# complete producing-boundary closure and does not assume a free-ATP artifact.
# ---------------------------------------------------------------------------
ATP_MAINTENANCE_RXN = "MAR03964"   # ATP + H2O -> ADP + Pi + H+
GLUCOSE_UPTAKE_RXN = "MAR09034"
O2_UPTAKE_RXN = "MAR09048"


def _close_carbon_uptake(model):
    for rid in list(model.medium):
        r = model.reactions.get_by_id(rid)
        if any("C" in (met.formula or "") and (met.formula or "") not in ("CO2", "CO3", "HCO3")
               for met in r.metabolites):
            r.lower_bound = 0.0


def check_energy_cycles() -> dict:
    """Max ATP-maintenance flux with ZERO carbon input. A correct model gives 0;
    a positive value means free-ATP energy-generating cycles are present."""
    model = load_human_gem()
    with model:
        _close_carbon_uptake(model)
        model.reactions.get_by_id(GLUCOSE_UPTAKE_RXN).lower_bound = 0.0
        model.objective = ATP_MAINTENANCE_RXN
        free_atp = model.optimize().objective_value
    return {"free_atp_no_substrate": round(free_atp, 3),
            "energy_readout_valid": abs(free_atp) < 1e-6,
            "note": "ATP/energy yields are only trustworthy when energy_readout_valid is True"}
