"""Guard the unqualified bridge from optimized GEM flux to human physiology.

Reaction/constraint calculations remain available in ``engines.metabolism``.
Optimized capacity alone cannot establish a glucose set point, insulin sensitivity
or compound response. These entry points await reviewed translation models.
"""
from __future__ import annotations
from .. import metabolism as MB


def personalize_profile(profile, genome: dict = None, strength: float = 0.5):
    """A GEM capacity needs a qualified translation before altering a person parameter."""
    from ..integrity import UnsupportedInterventionError

    raise UnsupportedInterventionError("No qualified GEM-capacity-to-person-parameter translation is available")


def gem_drug_effect(profile, genome: dict, drug_perturbations: dict, dose: float = 1.0, human=None):
    """Target associations cannot establish dose-dependent whole-body effects."""
    from ..integrity import UnsupportedInterventionError

    raise UnsupportedInterventionError("No qualified concentration-to-flux and flux-to-physiology model is available")


def food_effect(profile, genome: dict, food: dict, dose: float = 1.0):
    """Constituent identities alone cannot parameterize phytochemical effects."""
    from ..integrity import UnsupportedInterventionError

    raise UnsupportedInterventionError("No qualified phytochemical concentration-to-flux or physiology model is available")
