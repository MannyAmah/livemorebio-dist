"""
Cross-scale coupling: metabolic state -> cardiac electrophysiology.

Chronic hyperglycemia reduces repolarising IKr, prolonging ventricular APD/QT
(documented direction; magnitude illustrative, not cohort-fitted). This is the
kind of cross-scale link LivemoreBio owns: two independently-real engines
(glucose-insulin ODEs; O'Hara-Rudy myocyte) bound into one living human.
"""
from __future__ import annotations
from ..metabolic.glucose_insulin import GlucoseInsulinModel, MetabolicProfile
from ..cardiac.action_potential import CardiacCell


CLAIM_STATE = "HYPOTHESIS_UNSOURCED"
SLOPE_PROVENANCE = {
    "quantity": "fractional IKr reduction per mg/dL of mean glucose above 100 mg/dL",
    "value": 0.0035,
    "unit": "1 per mg/dL",
    "source": None,
    "status": CLAIM_STATE,
    "note": ("The direction (chronic hyperglycemia reduces repolarising IKr and prolongs APD) is "
             "documented. This slope and its 0.45 ceiling have no admitted source, were not fitted to "
             "any measurement, and must not be read as a calibrated magnitude."),
}


def hyperglycemia_to_ikr_block(mean_glucose_mg_dL: float) -> float:
    excess = max(0.0, mean_glucose_mg_dL - 100.0)
    return min(0.45, 0.0035 * excess)


class MetabolicCardiacTwin:
    def __init__(self, metabolic_profile: MetabolicProfile, cardiac: CardiacCell = None):
        self.metabolic_profile = metabolic_profile
        self.met = GlucoseInsulinModel(metabolic_profile)
        self.heart = cardiac or CardiacCell()

    def run(self, meals_g, day_hours: float = 14.0, beats: int = 6) -> dict:
        r = self.met.simulate(hours=day_hours, meals_g=meals_g)
        mg = float(r["glucose"].mean())
        block = hyperglycemia_to_ikr_block(mg)
        ap = self.heart.simulate(beats=beats, ikr_block=block)
        return dict(profile=self.metabolic_profile.name, mean_glucose=round(mg, 1),
                    coupling_claim_state=CLAIM_STATE, coupling_provenance=dict(SLOPE_PROVENANCE),
                    ikr_block=round(block, 3), apd90_ms=ap["apd90_ms"],
                    vrest=ap["vrest"], vpeak=ap["vpeak"])
