"""Strict attached-only command family shared by direct CLI, REPL and pipelines."""
from __future__ import annotations

import json
import os
import re
import shlex
import stat
import sys
from typing import Any, BinaryIO, Callable

from .execution_client import ContinuousClientError, MAX_REQUEST_BYTES, MAX_RESPONSE_BYTES, integer
from .strict_json import parse_json_object

_ACTIONS = {"capabilities", "prepare", "status", "frames", "observations", "start", "pause", "resume", "stop", "fork", "probe"}
_META = {"execution_id", "session_id", "revision", "control_revision", "state", "source_snapshot_hash", "source_generation",
    "source_data_class", "engine_contract_id", "source_valid", "authorship", "evidence_class", "latest_frame",
    "native_time", "frame_index", "frame_hash", "generated_at", "generated_monotonic_s", "failure_code",
    "last_frame", "last_admitted", "last_forwarded", "last_frame_hash", "delivery_status", "has_pending",
    "pending_envelope_hash", "last_acquired_at", "last_received_at", "last_admitted_at", "last_forwarded_at",
    "last_generated_at", "last_captured_at", "last_acknowledged_at", "preparation_available", "reason",
    "hardware_present", "independent_physical_validation", "lease_bound", "next_after_frame", "device_id",
    "capability_hash", "protocol_version", "firmware_version", "firmware_hash", "mode", "available"}


def continuous_line(line: str) -> bool:
    """Recognize before legacy coercion, including malformed quoted new commands."""
    try:
        parts = shlex.split(line)
        if parts and (parts[0].lower() == "execution" or [item.lower() for item in parts[:2]] == ["patch", "virtual"]):
            return True
    except ValueError:
        pass
    return re.match(r"^\s*(?:execution(?:\s|$)|patch\s+virtual(?:\s|$))", line, re.IGNORECASE) is not None


def continuous_echo(line: str) -> str:
    try:
        parts = shlex.split(line)
        virtual = parts[:2] == ["patch", "virtual"]
        action = parts[2 if virtual else 1]
        if action in _ACTIONS:
            return ("patch virtual " if virtual else "execution ") + action
    except (ValueError, IndexError):
        pass
    return "continuous command"


def safe_error(error: ContinuousClientError) -> str:
    request = f" request_id={error.request_id}" if error.request_id else ""
    return f"{error.code}{request}: {error}"


def _options(tokens: list[str]) -> tuple[list[str], dict[str, str]]:
    positional, options = [], {}
    for token in tokens:
        if "=" in token:
            name, value = token.split("=", 1)
            if not name or not value or name in options:
                raise ContinuousClientError()
            options[name] = value
        else:
            positional.append(token)
    return positional, options


def _integer(value: str, minimum: int = 1, maximum: int = 1_000_000) -> int:
    if re.fullmatch(r"[0-9]{1,10}", value) is None:
        raise ContinuousClientError()
    return integer(int(value), minimum, maximum)


def _load(path: str, stdin: BinaryIO | None) -> dict[str, Any]:
    try:
        if path == "-":
            stream = stdin if stdin is not None else sys.stdin.buffer
            raw = stream.read(MAX_REQUEST_BYTES + 1)
        else:
            # Nonblocking prevents a named pipe from hanging a bounded command.
            descriptor = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
            with os.fdopen(descriptor, "rb") as stream:
                if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
                    raise ValueError()
                raw = stream.read(MAX_REQUEST_BYTES + 1)
        return parse_json_object(raw, max_bytes=MAX_REQUEST_BYTES)
    except Exception:
        raise ContinuousClientError() from None


def _compact(result: dict[str, Any]) -> dict[str, Any]:
    """Only declared metadata: no arbitrary model values, parameters or selection IDs."""
    compact = {key: value for key, value in result.items() if key in _META and
               (value is None or type(value) in {str, bool, int, float})}
    for name, fields in {"native_axis": {"unit", "maximum"},
            "consumer_lease": {"required", "state", "remaining_s", "session_id"},
            "native_interval": {"start", "end", "unit"},
            "selection": {"source_data_class"}}.items():
        if isinstance(result.get(name), dict):
            compact[name] = {key: value for key, value in result[name].items() if key in fields and
                             (value is None or type(value) in {str, bool, int, float})}
    for name in ("execution", "producer", "binding"):
        if isinstance(result.get(name), dict):
            compact[name] = _compact(result[name])
    if isinstance(result.get("frames"), list):
        compact["frames"] = [_compact(frame) for frame in result["frames"] if isinstance(frame, dict)]
    return compact


def _display(result: dict[str, Any], options: dict[str, str], out: Callable[[str], Any], *, request_id: str | None = None) -> None:
    try:
        raw = json.dumps(result, allow_nan=False, ensure_ascii=True, separators=(",", ":")).encode()
        checked = parse_json_object(raw, max_bytes=MAX_RESPONSE_BYTES)
    except Exception:
        raise ContinuousClientError("CLIENT_RESPONSE") from None
    if "output" in options:
        try:
            descriptor = os.open(options["output"], os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(descriptor, "wb") as stream:
                os.fchmod(stream.fileno(), 0o600)
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
        except Exception:
            # The server action is already confirmed. A local export failure
            # must not erase its acknowledgment or suggest retrying the action.
            out(json.dumps(_compact(checked), ensure_ascii=True, sort_keys=True))
            raise ContinuousClientError("CLIENT_OUTPUT", request_id=request_id) from None
        out("Private JSON output created; modeled data is not physical validation.")
    out(json.dumps(checked if options.get("json") == "true" else _compact(checked), ensure_ascii=True, sort_keys=True))


def run_continuous_command(platform: Any, tokens: list[str], *, out: Callable[[str], Any] = print,
                           stdin: BinaryIO | None = None) -> dict[str, Any]:
    if getattr(platform, "mode", None) != "attach":
        raise ContinuousClientError("CLIENT_ATTACH_REQUIRED")
    if (not isinstance(tokens, list) or not 2 <= len(tokens) <= 20 or
            any(type(item) is not str or len(item) > MAX_REQUEST_BYTES for item in tokens)):
        raise ContinuousClientError()
    virtual = tokens[:2] == ["patch", "virtual"]
    prefix = 2 if virtual else 1
    if (not virtual and tokens[0] != "execution") or len(tokens) <= prefix:
        raise ContinuousClientError()
    action = tokens[prefix]
    pos, options = _options(tokens[prefix + 1:])
    # (positional count, required options, optional options)
    specifications = ({"capabilities": (0, set(), set()), "probe": (0, {"device"}, set()),
        "start": (1, set(), set()), "status": (1, set(), set()),
        **{item: (1, set(), {"revision", "control_revision"}) for item in ("pause", "resume", "stop")}} if virtual else
        {"capabilities": (0, set(), set()), "prepare": (1, {"key"}, set()), "fork": (2, {"key"}, set()),
         "status": (1, set(), set()), "observations": (1, set(), set()), "frames": (1, set(), {"after", "limit"}),
         **{item: (1, {"generation"}, {"revision", "control_revision"}) for item in ("start", "pause", "resume", "stop")}})
    if action not in specifications:
        raise ContinuousClientError()
    count, required, optional = specifications[action]
    if len(pos) != count or not required <= options.keys() or options.keys() - required - optional - {"json", "output"}:
        raise ContinuousClientError()
    if "json" in options and options["json"] not in {"true", "false"}:
        raise ContinuousClientError()
    if action == "capabilities":
        result = platform.virtual_patch_capabilities() if virtual else platform.execution_capabilities()
    elif virtual and action == "probe":
        result = platform.register_virtual_probe(options["device"])
    elif virtual and action == "start":
        result = platform.start_virtual_session(_load(pos[0], stdin))
    elif not virtual and action in {"prepare", "fork"}:
        body = _load(pos[-1], stdin)
        result = (platform.prepare_execution(body, idempotency_key=options["key"]) if action == "prepare" else
                  platform.fork_execution_checkpoint(pos[0], body, idempotency_key=options["key"]))
    elif action in {"start", "pause", "resume", "stop"}:
        guards = options.keys() & {"revision", "control_revision"}
        if len(guards) != 1:
            raise ContinuousClientError()
        guard = next(iter(guards))
        kwargs = {"expected_" + guard: _integer(options[guard])}
        if not virtual:
            kwargs["expected_source_generation"] = options["generation"]
        result = getattr(platform, action + ("_virtual_session" if virtual else "_execution"))(pos[0], **kwargs)
    elif action == "frames":
        result = platform.execution_frames(pos[0], after_frame=_integer(options.get("after", "0"), 0, 1_000_000_000),
                                           limit=_integer(options.get("limit", "100"), 1, 500))
    elif action == "observations":
        result = platform.execution_observations(pos[0])
    else:
        result = platform.virtual_session_status(pos[0]) if virtual else platform.execution_status(pos[0])
    metadata = getattr(platform, "last_continuous_response", None)
    _display(result, options, out, request_id=metadata.get("request_id") if isinstance(metadata, dict) else None)
    if isinstance(metadata, dict) and metadata.get("cleanup_code") == "CLIENT_TRANSPORT":
        print("CLIENT_TRANSPORT: Response cleanup reported a failure; the displayed acknowledgment is unchanged.", file=sys.stderr)
    return result
