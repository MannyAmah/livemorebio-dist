"""One strict attached Atlas command family for CLI, REPL and pipelines."""
from __future__ import annotations

import json
import re
import shlex
import sys
from typing import Any, Callable

from .atlas_client import AtlasClientError, MAX_RESPONSE_BYTES, fixed_source_id, validate_response
from .strict_json import parse_json_object


def atlas_line(line: str) -> bool:
    try:
        parts = shlex.split(line)
        if parts and parts[0].lower() == "atlas":
            return True
    except ValueError:
        pass
    return re.match(r"^\s*atlas(?:\s|$)", line, re.IGNORECASE) is not None


def atlas_echo(line: str) -> str:
    try:
        parts = shlex.split(line)
        if len(parts) >= 2 and parts[1] in {"status", "install"}:
            return "atlas " + parts[1]
    except ValueError:
        pass
    return "atlas command"


def safe_atlas_error(error: AtlasClientError) -> str:
    request = f" request_id={error.request_id}" if error.request_id else ""
    return f"{error.code}{request}: {error}"


def run_atlas_command(platform: Any, tokens: list[str], *,
                      out: Callable[[str], Any] = print) -> dict[str, Any]:
    if getattr(platform, "mode", None) != "attach":
        raise AtlasClientError("ATLAS_CLIENT_ATTACH_REQUIRED")
    if (type(tokens) is not list or not 2 <= len(tokens) <= 4
            or any(type(item) is not str or not 1 <= len(item) <= 128 for item in tokens)
            or tokens[0] != "atlas" or tokens[1] not in {"status", "install"}):
        raise AtlasClientError()
    parts = list(tokens[2:])
    full = False
    if parts and parts[-1] in {"json=true", "json=false"}:
        full = parts.pop() == "json=true"
    installation = tokens[1] == "install"
    if len(parts) != int(installation):
        raise AtlasClientError()
    if installation:
        fixed_source_id(parts[0])
    result = platform.install_atlas_reference(parts[0]) if installation else platform.atlas_reference_status()
    try:
        # Recheck bounded metadata for alternate Platform implementations too.
        checked = parse_json_object(json.dumps(result, allow_nan=False, ensure_ascii=True).encode(),
                                    max_bytes=MAX_RESPONSE_BYTES)
        validate_response(checked, installation=installation)
    except Exception:
        raise AtlasClientError("ATLAS_CLIENT_UNCONFIRMED" if installation else "ATLAS_CLIENT_RESPONSE") from None
    compact = {key: checked[key] for key in ("source_id", "state", "available", "manifest_sha256",
                                           "reference_geometry", "patient_registered")}
    if installation:
        compact.update({"receipt": checked["receipt"], "reused": checked["reused"]})
    try:
        out(json.dumps(checked if full else compact, ensure_ascii=True, sort_keys=True))
    except Exception:
        raise AtlasClientError("ATLAS_CLIENT_OUTPUT") from None
    metadata = getattr(platform, "last_atlas_response", {})
    if type(metadata) is dict and metadata.get("cleanup_code") == "ATLAS_CLIENT_TRANSPORT":
        try:
            print("ATLAS_CLIENT_TRANSPORT: Response confirmed; connection cleanup was incomplete.", file=sys.stderr)
        except Exception:
            raise AtlasClientError("ATLAS_CLIENT_OUTPUT") from None
    return result
