"""Explicit failures raised by the Livemore evidence bounded context."""


class EvidenceError(Exception):
    """Base class for evidence-domain failures."""


class DomainValidationError(EvidenceError, ValueError):
    """A domain record violates an invariant."""


class NotFoundError(EvidenceError, LookupError):
    """A tenant-scoped evidence resource does not exist."""


class ConflictError(EvidenceError):
    """A duplicate ID, stale revision, or idempotency conflict occurred."""


class ImmutablePackageError(ConflictError):
    """A caller attempted to mutate a non-draft evidence package."""


class InvalidTransitionError(ConflictError):
    """The requested lifecycle transition is not permitted."""


class StaleExportError(ConflictError):
    """An export snapshot or its lineage changed before registration."""


class IntegrityError(EvidenceError):
    """Stored or exported evidence failed a cryptographic integrity check."""


class SigningConfigurationError(IntegrityError):
    """Evidence export cannot establish its required issuer-signing identity."""


class CalibrationDeniedError(EvidenceError):
    """Evidence does not satisfy the calibration authorization gate."""
