"""Policy-enforcing application service for evidence packages."""
from __future__ import annotations

import os
import re
import uuid
from dataclasses import replace
from datetime import datetime, timedelta
from decimal import Decimal
from pathlib import Path
from typing import Optional

from .canonical import canonical_hash
from .calibration import CALIBRATION_PARAMETERS
from .errors import (
    CalibrationDeniedError,
    ConflictError,
    DomainValidationError,
    ImmutablePackageError,
    IntegrityError,
    InvalidTransitionError,
    StaleExportError,
)
from .exporter import (
    ExportPlan,
    export_artifact_lock,
    export_package,
    plan_export,
    quarantine_export,
)
from .models import (
    AssessmentStatus,
    CalibrationAuthorization,
    ClaimState,
    ContextOfUse,
    EvidenceExport,
    EvidencePackageVersion,
    LifecycleStatus,
    MeasurementEnvelope,
    MeasurementRole,
    ModelVerificationRecord,
    PolicyVersion,
    PredictionRun,
    ProtocolVersion,
    Provenance,
    SourceDataClass,
    ValidationDimension,
    ValidationEvent,
    VisualizationManifest,
    normalize_identity,
    validation_analysis_hash,
    utc_now,
)
from .policies import require_approved_policy
from .store import EvidenceStore


_DURATION_PATTERN = re.compile(
    r"^\s*(\d+(?:\.\d+)?)\s*(ms|s|sec(?:ond)?s?|min(?:ute)?s?|h|hours?|d|days?)\s*$",
    re.IGNORECASE,
)
_IMMUTABLE_CODE_ID = re.compile(
    r"^(?:git:)?[0-9a-f]{40,64}$|^sha256:[0-9a-f]{64}$"
)
_IMMUTABLE_CONTAINER_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")
_IMMUTABLE_ARTIFACT_ID = re.compile(
    r"^(?:[A-Za-z0-9_.:/+\-]+@)?sha256:[0-9a-f]{64}$"
)
_ABSOLUTE_ERROR_PATTERN = re.compile(
    r"^\s*absolute_error\s*<=\s*(\d+(?:\.\d+)?)\s*(.*?)\s*$",
    re.IGNORECASE,
)
_DURATION_SECONDS = {
    "ms": Decimal("0.001"),
    "s": Decimal("1"),
    "sec": Decimal("1"),
    "second": Decimal("1"),
    "seconds": Decimal("1"),
    "min": Decimal("60"),
    "minute": Decimal("60"),
    "minutes": Decimal("60"),
    "h": Decimal("3600"),
    "hour": Decimal("3600"),
    "hours": Decimal("3600"),
    "d": Decimal("86400"),
    "day": Decimal("86400"),
    "days": Decimal("86400"),
}


def _duration_seconds(value: str) -> Decimal:
    match = _DURATION_PATTERN.fullmatch(value)
    if match is None:
        raise DomainValidationError(f"unsupported validation time window: {value}")
    return Decimal(match.group(1)) * _DURATION_SECONDS[match.group(2).lower()]


def _evaluate_absolute_error(
    event: ValidationEvent,
    predicted_value: Decimal,
    measured_value: Decimal,
) -> tuple[Decimal, bool]:
    if event.metric_name != "absolute_error":
        raise DomainValidationError("unsupported validation metric; absolute_error is required")
    match = _ABSOLUTE_ERROR_PATTERN.fullmatch(event.acceptance_criterion)
    if match is None:
        raise DomainValidationError("unsupported validation acceptance criterion")
    threshold = Decimal(match.group(1))
    criterion_unit = match.group(2).strip()
    if criterion_unit and criterion_unit != event.unit:
        raise DomainValidationError("validation criterion unit does not match the endpoint unit")
    metric_value = abs(predicted_value - measured_value)
    return metric_value, metric_value <= threshold


class EvidenceService:
    """The sole mutation and policy boundary for evidence package state."""

    def __init__(
        self,
        store: EvidenceStore,
        *,
        unsafe_test_only_allow_non_synthetic: bool = False,
        unsafe_test_only_allow_preloaded_verification: bool = False,
    ):
        if self._is_production() and (
            unsafe_test_only_allow_non_synthetic
            or unsafe_test_only_allow_preloaded_verification
        ):
            raise DomainValidationError(
                "unsafe test-only evidence bypasses are forbidden in production"
            )
        self.store = store
        self._allow_non_synthetic = unsafe_test_only_allow_non_synthetic
        self._allow_preloaded_verification = unsafe_test_only_allow_preloaded_verification

    def close(self) -> None:
        self.store.close()

    def create(
        self,
        package: EvidencePackageVersion,
        *,
        actor: str,
        verification_actor: Optional[str] = None,
        protocol_approval_actor: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        _allow_automated_contract_attestation: bool = False,
    ) -> EvidencePackageVersion:
        actor = normalize_identity(actor, "actor")
        if verification_actor is not None:
            verification_actor = normalize_identity(verification_actor, "verification_actor")
        if protocol_approval_actor is not None:
            protocol_approval_actor = normalize_identity(
                protocol_approval_actor, "protocol_approval_actor"
            )
        if package.lifecycle is not LifecycleStatus.DRAFT or package.revision != 0:
            raise DomainValidationError("new evidence package must be a revision-zero draft")
        if package.version != 1 or package.previous_version_id is not None:
            raise DomainValidationError(
                "new evidence package must be a root version; use create_revision for lineage"
            )
        if package.content_hash:
            raise DomainValidationError("new evidence draft cannot provide a content hash")
        if any(
            value is not None
            for value in (
                package.locked_at,
                package.released_at,
                package.retracted_at,
                package.superseded_at,
                package.lifecycle_reason,
            )
        ):
            raise DomainValidationError(
                "new evidence draft cannot preload lifecycle metadata"
            )
        if actor != package.created_by:
            raise DomainValidationError("create actor must match package creator")
        if package.created_at > utc_now() + timedelta(minutes=5):
            raise DomainValidationError("evidence package creation timestamp is materially in the future")
        require_approved_policy(package.policy)
        if package.protocol.approval_status == "approved":
            if protocol_approval_actor != package.protocol.approved_by:
                raise DomainValidationError(
                    "approved protocol requires its authenticated approval actor"
                )
            model_actors = {prediction.actor_id for prediction in package.predictions}
            if package.protocol.approved_by in {package.created_by, *model_actors}:
                raise DomainValidationError(
                    "protocol approval requires separation from package and model authors"
                )
        self._require_data_capability(package)
        if package.validation_events:
            raise DomainValidationError(
                "new evidence packages cannot preload validation events; append them through review"
            )
        if any(
            measurement.role is MeasurementRole.COUNTERPART_OUTCOME
            for measurement in package.measurements
        ):
            raise DomainValidationError(
                "new evidence packages cannot preload counterpart outcomes; append them after "
                "the prediction package is durably frozen"
            )
        if package.model_verifications:
            if (
                not self._allow_preloaded_verification
                and not _allow_automated_contract_attestation
            ):
                raise DomainValidationError(
                    "preloaded model verification is disabled; use the attestation service"
                )
            if not verification_actor or any(
                item.verifier_id != verification_actor for item in package.model_verifications
            ):
                raise DomainValidationError(
                    "preloaded model verification requires the authenticated verification actor"
                )
            if any(item.verified_at > utc_now() + timedelta(minutes=5) for item in package.model_verifications):
                raise DomainValidationError("model verification timestamp is materially in the future")
            if _allow_automated_contract_attestation:
                if len(package.model_verifications) != 1:
                    raise DomainValidationError(
                        "atomic model creation requires exactly one contract attestation"
                    )
                verification = package.model_verifications[0]
                prediction = next(
                    (
                        item
                        for item in package.predictions
                        if item.prediction_id == verification.prediction_id
                    ),
                    None,
                )
                if prediction is None or verification != self._contract_attestation(
                    package,
                    prediction,
                    verified_at=verification.verified_at,
                ):
                    raise DomainValidationError(
                        "atomic model creation contains an invalid contract attestation"
                    )
        return self.store.create(
            package,
            actor=actor,
            verification_actor=verification_actor,
            idempotency_key=idempotency_key,
        )

    def create_with_model_contract_attestation(
        self,
        package: EvidencePackageVersion,
        *,
        actor: str,
        prediction_id: str,
        protocol_approval_actor: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> EvidencePackageVersion:
        """Atomically create a model package and its deterministic contract attestation."""

        if package.model_verifications:
            raise DomainValidationError(
                "atomic model creation requires an unattested candidate package"
            )
        prediction = next(
            (item for item in package.predictions if item.prediction_id == prediction_id),
            None,
        )
        if prediction is None:
            raise DomainValidationError("model attestation references an unknown prediction")
        attestation = self._contract_attestation(
            package,
            prediction,
            verified_at=package.created_at,
        )
        attested = replace(
            package,
            model_verifications=(attestation,),
            provenance=replace(
                package.provenance,
                content_hashes=package.provenance.content_hashes
                + (attestation.prediction_hash,)
                + attestation.evidence_hashes,
            ),
        )
        return self.create(
            attested,
            actor=actor,
            verification_actor=attestation.verifier_id,
            protocol_approval_actor=protocol_approval_actor,
            idempotency_key=idempotency_key,
            _allow_automated_contract_attestation=True,
        )

    def create_model_only(
        self,
        *,
        tenant_id: str,
        package_id: str,
        use_case: str,
        claim: str,
        policy: PolicyVersion,
        context_of_use: ContextOfUse,
        protocol: ProtocolVersion,
        prediction: PredictionRun,
        provenance: Provenance,
        visualization_manifest: Optional[VisualizationManifest] = None,
        created_by: str,
        created_at: Optional[datetime] = None,
        protocol_approval_actor: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> EvidencePackageVersion:
        """Create a modeled package without mislabeling synthetic data as validation."""
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        package_id = normalize_identity(package_id, "package_id")
        created_by = normalize_identity(created_by, "created_by")
        if protocol_approval_actor is not None:
            protocol_approval_actor = normalize_identity(
                protocol_approval_actor, "protocol_approval_actor"
            )
        manifest = visualization_manifest or VisualizationManifest(
            manifest_id=f"visualization-{package_id}",
            anatomy_asset_ids=(),
            coordinate_system="unspecified",
            asset_version="unassigned",
            asset_license="unassigned",
            mappings=(),
        )
        package = EvidencePackageVersion(
            package_id=package_id,
            schema_version="livemore.evidence-package.v2",
            tenant_id=tenant_id,
            version=1,
            previous_version_id=None,
            use_case=use_case,
            claim=claim,
            policy=policy,
            context_of_use=context_of_use,
            protocol=protocol,
            predictions=(prediction,),
            measurements=(),
            model_verifications=(),
            validation_events=(),
            provenance=provenance,
            visualization_manifest=manifest,
            created_at=created_at or utc_now(),
            created_by=created_by,
        )
        return self.create_with_model_contract_attestation(
            package,
            actor=created_by,
            prediction_id=prediction.prediction_id,
            protocol_approval_actor=protocol_approval_actor,
            idempotency_key=idempotency_key,
        )

    def get(self, tenant_id: str, package_id: str) -> EvidencePackageVersion:
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        package_id = normalize_identity(package_id, "package_id")
        package = self.store.get(tenant_id, package_id)
        self._require_data_capability(package)
        return package

    def list(self, tenant_id: str) -> tuple[EvidencePackageVersion, ...]:
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        packages = self.store.list(tenant_id)
        for package in packages:
            self._require_data_capability(package)
        return packages

    def add_model_verification(
        self,
        tenant_id: str,
        package_id: str,
        verification: ModelVerificationRecord,
        *,
        actor: str,
        expected_revision: int,
        idempotency_key: Optional[str] = None,
    ) -> EvidencePackageVersion:
        actor = normalize_identity(actor, "actor")
        package = self.get(tenant_id, package_id)
        self._require_draft(package)
        self._require_active_ancestry(package)
        require_approved_policy(package.policy)
        if actor != verification.verifier_id:
            raise DomainValidationError("model-verification actor must match the recorded verifier")
        if verification.verified_at > utc_now() + timedelta(minutes=5):
            raise DomainValidationError("model verification timestamp is materially in the future")
        if any(
            item.verification_id == verification.verification_id
            or item.prediction_id == verification.prediction_id
            for item in package.model_verifications
        ):
            raise ConflictError("prediction already has a model-verification record")
        prediction = next(
            (item for item in package.predictions if item.prediction_id == verification.prediction_id),
            None,
        )
        if prediction is None:
            raise DomainValidationError("model verification references an unknown prediction")
        if verification.verifier_id in {package.created_by, prediction.actor_id}:
            raise DomainValidationError("model verification requires verifier separation of duties")
        if (
            verification.policy_id != package.policy.policy_id
            or verification.policy_hash != package.policy.canonical_hash
        ):
            raise DomainValidationError("model verification policy binding does not match package policy")
        updated = replace(
            package,
            model_verifications=package.model_verifications + (verification,),
            provenance=replace(
                package.provenance,
                content_hashes=package.provenance.content_hashes
                + (verification.prediction_hash,)
                + verification.evidence_hashes,
            ),
            revision=package.revision + 1,
        )
        return self.store.update(
            updated,
            expected_revision=expected_revision,
            actor=actor,
            action="model_verification.added",
            detail={"verification_id": verification.verification_id},
            idempotency_key=idempotency_key,
        )

    def attest_model_contract(
        self,
        tenant_id: str,
        package_id: str,
        *,
        prediction_id: str,
        expected_revision: int,
        idempotency_key: Optional[str] = None,
    ) -> EvidencePackageVersion:
        """Record a bound automated software attestation, not independent validation."""
        package = self.get(tenant_id, package_id)
        prediction = next(
            (item for item in package.predictions if item.prediction_id == prediction_id),
            None,
        )
        if prediction is None:
            raise DomainValidationError("model attestation references an unknown prediction")
        attestation = self._contract_attestation(
            package,
            prediction,
            verified_at=utc_now(),
        )
        return self.add_model_verification(
            tenant_id,
            package_id,
            attestation,
            actor=attestation.verifier_id,
            expected_revision=expected_revision,
            idempotency_key=idempotency_key,
        )

    @staticmethod
    def _contract_attestation(
        package: EvidencePackageVersion,
        prediction: PredictionRun,
        *,
        verified_at: datetime,
    ) -> ModelVerificationRecord:
        prediction_hash = canonical_hash(prediction)
        evidence_hash = canonical_hash(
            {
                "schema_version": "livemore.model-contract-attestation.v1",
                "prediction_hash": prediction_hash,
                "protocol_hash": prediction.protocol_hash,
                "checks": (
                    "schema_valid",
                    "protocol_bound",
                    "deterministic_seed_recorded",
                    "finite_interval_consistent_outputs",
                ),
            }
        )
        return ModelVerificationRecord(
            verification_id=f"model-attestation-{prediction_hash[:32]}",
            prediction_id=prediction.prediction_id,
            prediction_hash=prediction_hash,
            disposition=AssessmentStatus.PASS,
            scope=(
                "automated schema, protocol-binding, deterministic-input, and finite "
                "interval-consistency checks only; not endpoint-bound validation and not "
                "independent, biological, or clinical verification"
            ),
            method="livemore-model-contract-attestation-v1",
            evidence_hashes=(evidence_hash,),
            verifier_id="livemore-contract-attestor",
            verifier_role="automated_software_attestation",
            verified_at=verified_at,
            policy_id=package.policy.policy_id,
            policy_hash=package.policy.canonical_hash,
        )

    def add_measurement(
        self,
        tenant_id: str,
        package_id: str,
        measurement: MeasurementEnvelope,
        *,
        actor: str,
        expected_revision: int,
        idempotency_key: Optional[str] = None,
    ) -> EvidencePackageVersion:
        actor = normalize_identity(actor, "actor")
        package = self.get(tenant_id, package_id)
        self._require_draft(package)
        self._require_data_capability(package)
        self._require_measurement_capability(package, measurement)
        if (
            measurement.payload.measured_at > utc_now() + timedelta(minutes=5)
            or measurement.received_at > utc_now() + timedelta(minutes=5)
        ):
            raise DomainValidationError(
                "measurement collection or receipt timestamp is materially in the future"
            )
        if measurement.tenant_id != tenant_id:
            raise DomainValidationError("measurement tenant does not match request tenant")
        if any(item.envelope_id == measurement.envelope_id for item in package.measurements):
            raise ConflictError("measurement envelope ID already exists")
        if measurement.role is MeasurementRole.COUNTERPART_OUTCOME:
            prediction_frozen_at = self._package_creation_audit_time(tenant_id, package_id)
            if measurement.payload.measured_at <= prediction_frozen_at:
                raise DomainValidationError(
                    "counterpart outcome must be measured after the signed package-creation "
                    "audit event froze the prediction"
                )
        updated = replace(
            package,
            measurements=package.measurements + (measurement,),
            provenance=replace(
                package.provenance,
                content_hashes=package.provenance.content_hashes + (measurement.source_hash,),
            ),
            revision=package.revision + 1,
        )
        return self.store.update(
            updated,
            expected_revision=expected_revision,
            actor=actor,
            action="measurement.added",
            detail={"measurement_envelope_id": measurement.envelope_id},
            idempotency_key=idempotency_key,
        )

    def add_validation(
        self,
        tenant_id: str,
        package_id: str,
        event: ValidationEvent,
        *,
        actor: str,
        expected_revision: int,
        idempotency_key: Optional[str] = None,
    ) -> EvidencePackageVersion:
        actor = normalize_identity(actor, "actor")
        package = self.get(tenant_id, package_id)
        self._require_draft(package)
        self._require_data_capability(package)
        if actor != event.reviewer_id:
            raise DomainValidationError("validation actor must match the recorded reviewer")
        if event.reviewed_at > utc_now() + timedelta(minutes=5):
            raise DomainValidationError("validation review timestamp is materially in the future")
        if event.dimension is ValidationDimension.EXTERNAL_REPLICATION:
            raise DomainValidationError(
                "external replication intake is disabled until an independent-site registry is configured"
            )
        if any(item.event_id == event.event_id for item in package.validation_events):
            raise ConflictError("validation event ID already exists")
        prediction = next(
            (item for item in package.predictions if item.prediction_id == event.prediction_id), None
        )
        measurement = next(
            (item for item in package.measurements if item.envelope_id == event.measurement_envelope_id),
            None,
        )
        if prediction is None or measurement is None:
            raise DomainValidationError("validation references an unknown prediction or measurement")
        if event.reviewer_id in {package.created_by, prediction.actor_id}:
            raise DomainValidationError("validation requires reviewer separation of duties")
        if event.policy_id != package.policy.policy_id or event.policy_hash != package.policy.canonical_hash:
            raise DomainValidationError("validation policy binding does not match package policy")
        if package.protocol.approval_status != "approved" or package.protocol.approved_at is None:
            raise DomainValidationError("counterpart validation requires a pre-approved protocol")
        if event.endpoint not in package.protocol.endpoints:
            raise DomainValidationError("validation endpoint is not declared by the bound protocol")
        if event.acceptance_criterion not in package.protocol.acceptance_criteria:
            raise DomainValidationError("validation criterion was not pre-specified by the protocol")
        predicted = next((item for item in prediction.outputs if item.endpoint == event.endpoint), None)
        if predicted is None or predicted.unit != event.unit:
            raise DomainValidationError("validation endpoint or unit does not match prediction")
        if measurement.payload.endpoint != event.endpoint or measurement.payload.unit != event.unit:
            raise DomainValidationError("validation endpoint or unit does not match measurement")
        if event.source_data_class is not measurement.payload.source_data_class:
            raise DomainValidationError("validation data class does not match measurement")
        if measurement.envelope_id in prediction.input_measurement_ids:
            raise DomainValidationError("prediction input measurements cannot validate their own output")
        if measurement.payload.measured_at <= prediction.generated_at:
            raise DomainValidationError("counterpart outcome must be collected after prediction freeze")
        expected_window = _duration_seconds(package.protocol.duration)
        recorded_window = _duration_seconds(event.time_window)
        observed_window = Decimal(
            str((measurement.payload.measured_at - prediction.generated_at).total_seconds())
        )
        computed_time_compatible = (
            expected_window == recorded_window
            and abs(observed_window - expected_window) <= Decimal("1")
        )
        if not event.endpoint_compatible or not event.unit_compatible:
            raise DomainValidationError("validation endpoint and unit compatibility must be true")
        if event.time_window_compatible != computed_time_compatible or not computed_time_compatible:
            raise DomainValidationError("validation time window does not match protocol and timestamps")
        if measurement.payload.quality_status is not AssessmentStatus.PASS:
            raise DomainValidationError("measurement quality control did not pass")
        if measurement.payload.calibration_status is not AssessmentStatus.PASS:
            raise DomainValidationError("measurement calibration did not pass")
        if not event.quality_passed:
            raise DomainValidationError("validation quality flag does not match the measurement record")
        metric_value, criterion_passed = _evaluate_absolute_error(
            event,
            predicted.value,
            measurement.payload.value,
        )
        computed_disposition = (
            AssessmentStatus.PASS if criterion_passed else AssessmentStatus.FAIL
        )
        if event.metric_value != metric_value:
            raise DomainValidationError("validation metric value does not match bound prediction and outcome")
        if event.protocol_criterion_passed != criterion_passed:
            raise DomainValidationError("validation criterion disposition does not match the computed metric")
        if event.disposition is not computed_disposition:
            raise DomainValidationError("validation disposition does not match the computed metric")
        if event.analysis_hash != validation_analysis_hash(prediction, measurement, event):
            raise DomainValidationError("validation analysis hash does not match bound evidence")
        updated = replace(
            package,
            validation_events=package.validation_events + (event,),
            provenance=replace(
                package.provenance,
                content_hashes=package.provenance.content_hashes + (event.analysis_hash,),
            ),
            revision=package.revision + 1,
        )
        return self.store.update(
            updated,
            expected_revision=expected_revision,
            actor=actor,
            action="validation.added",
            detail={"validation_event_id": event.event_id},
            idempotency_key=idempotency_key,
        )

    def lock(
        self,
        tenant_id: str,
        package_id: str,
        *,
        actor: str,
        expected_revision: int,
        idempotency_key: Optional[str] = None,
    ) -> EvidencePackageVersion:
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        package_id = normalize_identity(package_id, "package_id")
        actor = normalize_identity(actor, "actor")
        request_hash = canonical_hash(
            {
                "package_id": package_id,
                "expected_revision": expected_revision,
                "actor": actor,
            }
        )
        replay = self.store.idempotent_package(
            tenant_id, "package.locked", idempotency_key,
            expected_resource_id=package_id, request_hash=request_hash,
        )
        if replay is not None:
            return replay
        package = self.get(tenant_id, package_id)
        self._require_draft(package)
        self._require_active_ancestry(package)
        require_approved_policy(package.policy)
        self._require_independent_actor(package, actor, "lock")
        if self._is_production():
            self._require_immutable_build_identity(package)
        if package.predictions and package.claim_state is ClaimState.SYNTHETIC:
            raise DomainValidationError(
                "every prediction requires a passing independent model-verification record before lock"
            )
        calculated_hash = package.calculated_content_hash()
        locked = replace(
            package,
            lifecycle=LifecycleStatus.LOCKED,
            revision=package.revision + 1,
            content_hash=calculated_hash,
            locked_at=utc_now(),
            lifecycle_reason="integrity-locked by a separate actor",
        )
        if locked.calculated_content_hash() != calculated_hash:
            raise IntegrityError("evidence content changed while locking")
        return self.store.update(
            locked,
            expected_revision=expected_revision,
            actor=actor,
            action="package.locked",
            idempotency_key=idempotency_key,
            idempotency_request_hash=request_hash,
        )

    def release(
        self,
        tenant_id: str,
        package_id: str,
        *,
        actor: str,
        expected_revision: int,
        idempotency_key: Optional[str] = None,
    ) -> EvidencePackageVersion:
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        package_id = normalize_identity(package_id, "package_id")
        actor = normalize_identity(actor, "actor")
        request_hash = canonical_hash(
            {
                "package_id": package_id,
                "expected_revision": expected_revision,
                "actor": actor,
            }
        )
        replay = self.store.idempotent_package(
            tenant_id, "package.released", idempotency_key,
            expected_resource_id=package_id, request_hash=request_hash,
        )
        if replay is not None:
            return replay
        package = self.get(tenant_id, package_id)
        if package.lifecycle is not LifecycleStatus.LOCKED:
            raise InvalidTransitionError("only a locked package can be released")
        self._require_active_ancestry(package)
        if package.previous_version_id:
            predecessor = self.get(tenant_id, package.previous_version_id)
            if predecessor.lifecycle is not LifecycleStatus.RELEASED:
                raise InvalidTransitionError(
                    "replacement evidence requires its predecessor to remain released"
                )
            if not self.verify(tenant_id, predecessor.package_id):
                raise IntegrityError("replacement evidence predecessor failed integrity verification")
        require_approved_policy(package.policy)
        self._require_independent_actor(package, actor, "release")
        self._require_immutable_build_identity(package)
        if not self.verify(tenant_id, package_id):
            raise IntegrityError("evidence package failed integrity verification")
        released = replace(
            package,
            lifecycle=LifecycleStatus.RELEASED,
            revision=package.revision + 1,
            released_at=utc_now(),
            lifecycle_reason="released after integrity and release checks",
        )
        return self.store.release(
            released,
            expected_revision=expected_revision,
            actor=actor,
            idempotency_key=idempotency_key,
            idempotency_request_hash=request_hash,
        )

    def retract(
        self,
        tenant_id: str,
        package_id: str,
        *,
        actor: str,
        reason: str,
        expected_revision: int,
        idempotency_key: Optional[str] = None,
    ) -> EvidencePackageVersion:
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        package_id = normalize_identity(package_id, "package_id")
        actor = normalize_identity(actor, "actor")
        reason = normalize_identity(reason, "retraction reason")
        request_hash = canonical_hash(
            {
                "package_id": package_id,
                "expected_revision": expected_revision,
                "actor": actor,
                "reason": reason,
            }
        )
        replay = self.store.idempotent_package(
            tenant_id,
            "package.retracted",
            idempotency_key,
            expected_resource_id=package_id,
            request_hash=request_hash,
        )
        if replay is not None:
            return replay
        package = self.get(tenant_id, package_id)
        if package.lifecycle not in {LifecycleStatus.RELEASED, LifecycleStatus.SUPERSEDED}:
            raise InvalidTransitionError("only a released or superseded package can be retracted")
        if (
            package.lifecycle is LifecycleStatus.SUPERSEDED
            and self._has_non_retracted_descendant(tenant_id, package.package_id)
        ):
            raise InvalidTransitionError(
                "cannot retract a superseded ancestor while a descendant remains active"
            )
        self._require_independent_actor(package, actor, "retract")
        if not reason:
            raise DomainValidationError("retraction reason is required")
        retracted = replace(
            package,
            lifecycle=LifecycleStatus.RETRACTED,
            revision=package.revision + 1,
            retracted_at=utc_now(),
            lifecycle_reason=reason,
        )
        return self.store.update(
            retracted,
            expected_revision=expected_revision,
            actor=actor,
            action="package.retracted",
            detail={"reason_code": "recorded"},
            idempotency_key=idempotency_key,
            idempotency_request_hash=request_hash,
        )

    def create_revision(
        self,
        tenant_id: str,
        package_id: str,
        *,
        new_package_id: str,
        actor: str,
        expected_revision: int,
        idempotency_key: Optional[str] = None,
    ) -> EvidencePackageVersion:
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        package_id = normalize_identity(package_id, "package_id")
        new_package_id = normalize_identity(new_package_id, "new_package_id")
        actor = normalize_identity(actor, "actor")
        source = self.get(tenant_id, package_id)
        if source.lifecycle is not LifecycleStatus.RELEASED:
            raise InvalidTransitionError("revision source must be released")
        revision = replace(
            source,
            package_id=new_package_id,
            version=source.version + 1,
            previous_version_id=source.package_id,
            lifecycle=LifecycleStatus.DRAFT,
            revision=0,
            content_hash="",
            locked_at=None,
            released_at=None,
            retracted_at=None,
            superseded_at=None,
            lifecycle_reason=None,
            created_at=utc_now(),
            created_by=actor,
        )
        return self.store.create_revision(
            tenant_id,
            package_id,
            revision,
            expected_revision=expected_revision,
            actor=actor,
            idempotency_key=idempotency_key,
        )

    def verify(self, tenant_id: str, package_id: str) -> bool:
        package = self.get(tenant_id, package_id)
        if package.lifecycle is LifecycleStatus.DRAFT or not package.content_hash:
            return False
        try:
            self._require_active_ancestry(package)
        except InvalidTransitionError:
            return False
        return self.store.verify_content(
            package.tenant_id,
            package.package_id,
        ) and self.store.verify_audit_chain(package.tenant_id)

    def export(
        self,
        tenant_id: str,
        package_id: str,
        output_dir: str | Path,
        *,
        actor: str,
        idempotency_key: Optional[str] = None,
    ) -> EvidenceExport:
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        package_id = normalize_identity(package_id, "package_id")
        actor = normalize_identity(actor, "actor")
        package = self.get(tenant_id, package_id)
        if package.lifecycle is LifecycleStatus.DRAFT:
            raise InvalidTransitionError("draft evidence cannot be exported")
        self._require_active_ancestry(package)
        self._require_data_capability(package)
        if self._is_production():
            self._require_immutable_build_identity(package)
        if not self.verify(tenant_id, package_id):
            raise IntegrityError("evidence package failed integrity verification")
        expected_payload_sha256 = canonical_hash(package)
        export_plan = plan_export(package, output_dir)
        planned_directory = export_plan.final_dir
        with export_artifact_lock(planned_directory):
            return self._export_under_artifact_lock(
                package=package,
                output_dir=output_dir,
                actor=actor,
                idempotency_key=idempotency_key,
                expected_payload_sha256=expected_payload_sha256,
                planned_directory=planned_directory,
                export_plan=export_plan,
            )

    def _export_under_artifact_lock(
        self,
        *,
        package: EvidencePackageVersion,
        output_dir: str | Path,
        actor: str,
        idempotency_key: Optional[str],
        expected_payload_sha256: str,
        planned_directory: Path,
        export_plan: ExportPlan,
    ) -> EvidenceExport:
        export_request_hash = canonical_hash(
            {
                "package_id": package.package_id,
                "content_hash": package.content_hash,
                "directory": str(planned_directory),
                "expected_revision": package.revision,
                "expected_lifecycle": package.lifecycle.value,
                "expected_payload_sha256": expected_payload_sha256,
            }
        )
        replay = self.store.idempotent_package(
            package.tenant_id,
            "package.exported",
            idempotency_key,
            expected_resource_id=package.package_id,
            request_hash=export_request_hash,
        )
        audit_reference = self.store.audit_proof_reference(
            package.tenant_id, package.package_id
        )
        result = export_package(
            package,
            output_dir,
            evidence_audit_proof_reference=audit_reference,
            plan=export_plan,
        )
        if Path(result.directory) != planned_directory:
            if result.published_new:
                quarantine_export(result)
            raise IntegrityError("evidence export published outside its locked plan")
        if replay is not None:
            return result
        try:
            self.store.save_export(
                package.tenant_id,
                package.package_id,
                package.content_hash,
                result.archive_sha256,
                str(result.directory),
                expected_revision=package.revision,
                expected_lifecycle=package.lifecycle,
                expected_payload_sha256=expected_payload_sha256,
                actor=actor,
                idempotency_key=idempotency_key,
                idempotency_request_hash=export_request_hash,
            )
        except StaleExportError:
            try:
                registered = self.store.is_export_registered(
                    package.tenant_id,
                    package.package_id,
                    package.content_hash,
                    result.archive_sha256,
                    str(result.directory),
                )
            except Exception:
                registered = False
            try:
                if not registered:
                    quarantine_export(result, force=True)
            except Exception as quarantine_error:
                raise IntegrityError(
                    "stale evidence export could not be quarantined"
                ) from quarantine_error
            raise
        except ConflictError:
            try:
                registered = self.store.is_export_registered(
                    package.tenant_id,
                    package.package_id,
                    package.content_hash,
                    result.archive_sha256,
                    str(result.directory),
                )
            except Exception:
                registered = False
            try:
                if not registered:
                    quarantine_export(result, force=True)
            except Exception as quarantine_error:
                raise IntegrityError(
                    "conflicting evidence export could not be quarantined"
                ) from quarantine_error
            raise
        return result

    def issue_calibration_authorization(
        self,
        tenant_id: str,
        package_id: str,
        cendos_run_id: str,
        parameter_scope: tuple[str, ...],
        *,
        actor: str,
        reviewer_id: str,
        idempotency_key: Optional[str] = None,
    ) -> CalibrationAuthorization:
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        package_id = normalize_identity(package_id, "package_id")
        actor = normalize_identity(actor, "actor")
        reviewer_id = normalize_identity(reviewer_id, "reviewer_id")
        package = self.get(tenant_id, package_id)
        require_approved_policy(package.policy)
        if package.lifecycle is not LifecycleStatus.RELEASED:
            raise CalibrationDeniedError("calibration requires the active released evidence package")
        try:
            self._require_active_ancestry(package)
        except InvalidTransitionError as exc:
            raise CalibrationDeniedError("calibration evidence lineage is no longer active") from exc
        if not self.verify(tenant_id, package_id):
            raise CalibrationDeniedError("evidence package failed integrity verification")
        if package.claim_state not in {
            ClaimState.CALIBRATED,
            ClaimState.VALIDATED,
            ClaimState.REPLICATED,
        }:
            raise CalibrationDeniedError("evidence policy did not open the calibration gate")
        validation_status = {
            assessment.dimension: assessment.status
            for assessment in package.validation_summary
        }
        if any(
            validation_status.get(dimension) is not AssessmentStatus.PASS
            for dimension in package.policy.required_dimensions
        ):
            raise CalibrationDeniedError(
                "every policy-required dimension must pass before calibration authorization"
            )
        prediction = next(
            (item for item in package.predictions if item.cendos_run_id == cendos_run_id), None
        )
        if prediction is None:
            raise CalibrationDeniedError("Cendos run is not bound to this evidence package")
        if actor != reviewer_id:
            raise CalibrationDeniedError("authorization actor must match reviewer")
        if reviewer_id in {package.created_by, prediction.actor_id}:
            raise CalibrationDeniedError("calibration authorization requires separation of duties")
        scope = tuple(parameter_scope)
        if not scope or len(scope) != len(set(scope)):
            raise CalibrationDeniedError("authorization scope is empty or contains duplicates")
        outputs = {item.endpoint: item for item in prediction.outputs}
        for parameter in scope:
            spec = CALIBRATION_PARAMETERS.get(parameter)
            output = outputs.get(parameter)
            if spec is None or output is None:
                raise CalibrationDeniedError(
                    "authorization scope contains an unsupported or unbound parameter"
                )
            if output.unit != spec.unit or not spec.minimum <= output.value <= spec.maximum:
                raise CalibrationDeniedError(
                    "authorization output unit or range violates the calibration registry"
                )
        eligible_events = tuple(
            event
            for event in package.validation_events
            if event.prediction_id == prediction.prediction_id
            and event.disposition is AssessmentStatus.PASS
            and event.source_data_class in {SourceDataClass.REAL_HUMAN, SourceDataClass.QUALIFIED_LAB}
            and event.endpoint_compatible
            and event.unit_compatible
            and event.time_window_compatible
            and event.quality_passed
            and event.protocol_criterion_passed
            and event.reviewer_id != prediction.actor_id
            and event.dimension is not ValidationDimension.REGULATORY_DETERMINATION
        )
        if not eligible_events:
            raise CalibrationDeniedError("no eligible measured validation event exists")
        failed_endpoints = {
            event.endpoint
            for event in package.validation_events
            if event.prediction_id == prediction.prediction_id
            and event.endpoint in scope
            and (
                event.disposition is AssessmentStatus.FAIL
                or not event.protocol_criterion_passed
            )
        }
        if failed_endpoints:
            raise CalibrationDeniedError("a required calibration endpoint has failed validation")
        eligible_endpoints = {event.endpoint for event in eligible_events}
        if not set(scope).issubset(eligible_endpoints):
            raise CalibrationDeniedError(
                "every calibration parameter requires an eligible validation event for that endpoint"
            )
        authorization = CalibrationAuthorization(
            authorization_id=f"calibration-auth-{uuid.uuid4().hex}",
            tenant_id=tenant_id,
            package_id=package_id,
            package_content_hash=package.content_hash,
            cendos_run_id=cendos_run_id,
            live_twin_id=prediction.live_twin_id,
            validation_event_ids=tuple(event.event_id for event in eligible_events),
            parameter_scope=scope,
            reviewer_id=reviewer_id,
            authorized_at=utc_now(),
            policy_id=package.policy.policy_id,
            policy_hash=package.policy.canonical_hash,
        )
        try:
            return self.store.create_authorization(
                authorization,
                actor=actor,
                idempotency_key=idempotency_key,
            )
        except IntegrityError as exc:
            raise CalibrationDeniedError(
                "calibration authorization package changed before authorization"
            ) from exc

    def consume_calibration_authorization(
        self,
        tenant_id: str,
        authorization: CalibrationAuthorization,
        *,
        cendos_run_id: str,
        live_twin_id: str,
        actor: str,
    ) -> CalibrationAuthorization:
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        actor = normalize_identity(actor, "actor")
        if not isinstance(authorization, CalibrationAuthorization):
            raise CalibrationDeniedError("typed stored calibration authorization is required")
        if (
            authorization.tenant_id != tenant_id
            or authorization.cendos_run_id != cendos_run_id
            or authorization.live_twin_id != live_twin_id
        ):
            raise CalibrationDeniedError("calibration authorization tenant, run, or twin does not match")
        try:
            stored = self.store.get_authorization(tenant_id, authorization.authorization_id)
        except Exception as exc:
            raise CalibrationDeniedError("calibration authorization is not stored") from exc
        if stored != authorization:
            raise CalibrationDeniedError("calibration authorization does not match stored record")
        if stored.consumed:
            raise CalibrationDeniedError("calibration authorization has already been consumed")
        package = self.get(tenant_id, stored.package_id)
        try:
            require_approved_policy(package.policy)
        except DomainValidationError as exc:
            raise CalibrationDeniedError(
                "calibration authorization policy is no longer approved"
            ) from exc
        if package.lifecycle is not LifecycleStatus.RELEASED:
            raise CalibrationDeniedError(
                "calibration authorization is invalid because the package is not the active release"
            )
        try:
            self._require_active_ancestry(package)
        except InvalidTransitionError as exc:
            raise CalibrationDeniedError("calibration evidence lineage is no longer active") from exc
        if not self.verify(tenant_id, stored.package_id):
            raise CalibrationDeniedError("evidence package failed integrity verification")
        if package.content_hash != stored.package_content_hash:
            raise CalibrationDeniedError("calibration authorization package hash does not match")
        if not any(
            item.cendos_run_id == cendos_run_id and item.live_twin_id == live_twin_id
            for item in package.predictions
        ):
            raise CalibrationDeniedError("calibration authorization run no longer matches")
        current_event_ids = {event.event_id for event in package.validation_events}
        if not set(stored.validation_event_ids).issubset(current_event_ids):
            raise CalibrationDeniedError("calibration authorization validation events no longer match")
        if stored.policy_id != package.policy.policy_id or stored.policy_hash != package.policy.canonical_hash:
            raise CalibrationDeniedError("calibration authorization policy no longer matches")
        consumed = replace(stored, consumed=True, consumed_at=utc_now())
        try:
            return self.store.consume_authorization(consumed, actor=actor)
        except (ConflictError, IntegrityError) as exc:
            raise CalibrationDeniedError(
                "calibration authorization is stale, altered, or already consumed"
            ) from exc

    @staticmethod
    def _require_draft(package: EvidencePackageVersion) -> None:
        if package.lifecycle is not LifecycleStatus.DRAFT:
            raise ImmutablePackageError("locked evidence is immutable; create a revision")

    def _package_creation_audit_time(self, tenant_id: str, package_id: str) -> datetime:
        created_event = next(
            (
                event
                for event in self.store.audit_events(tenant_id, package_id)
                if event["action"] in {"package.created", "package.revision_created"}
            ),
            None,
        )
        if created_event is None:
            raise IntegrityError("evidence package has no signed creation audit event")
        return datetime.fromisoformat(str(created_event["occurred_at"]).replace("Z", "+00:00"))

    def _has_non_retracted_descendant(self, tenant_id: str, package_id: str) -> bool:
        children: dict[str, list[EvidencePackageVersion]] = {}
        for candidate in self.list(tenant_id):
            if candidate.previous_version_id:
                children.setdefault(candidate.previous_version_id, []).append(candidate)
        pending = list(children.get(package_id, ()))
        while pending:
            descendant = pending.pop()
            if descendant.lifecycle is LifecycleStatus.RETRACTED:
                continue
            if descendant.lifecycle in {
                LifecycleStatus.RELEASED,
                LifecycleStatus.SUPERSEDED,
            }:
                return True
            pending.extend(children.get(descendant.package_id, ()))
        return False

    def _require_active_ancestry(self, package: EvidencePackageVersion) -> None:
        """Reject an orphaned branch or any branch terminated by a retraction."""

        previous_id = package.previous_version_id
        first = True
        seen = {package.package_id}
        while previous_id is not None:
            if previous_id in seen:
                raise InvalidTransitionError("evidence lineage contains a cycle")
            seen.add(previous_id)
            ancestor = self.get(package.tenant_id, previous_id)
            if ancestor.lifecycle is LifecycleStatus.RETRACTED:
                raise InvalidTransitionError(
                    "evidence lineage was terminated by an ancestor retraction"
                )
            if first:
                expected_parent = (
                    LifecycleStatus.RELEASED
                    if package.lifecycle in {LifecycleStatus.DRAFT, LifecycleStatus.LOCKED}
                    else LifecycleStatus.SUPERSEDED
                )
                if ancestor.lifecycle is not expected_parent:
                    raise InvalidTransitionError(
                        "evidence package is not on the current replacement branch"
                    )
                first = False
            previous_id = ancestor.previous_version_id

    @staticmethod
    def _is_production() -> bool:
        return os.getenv("LIVEMORE_ENVIRONMENT", "development").strip().lower() in {
            "prod",
            "production",
        }

    @staticmethod
    def _require_immutable_build_identity(package: EvidencePackageVersion) -> None:
        if _IMMUTABLE_CODE_ID.fullmatch(package.provenance.code_commit) is None:
            raise DomainValidationError(
                "release-grade evidence requires an immutable provenance code commit"
            )
        for prediction in package.predictions:
            if _IMMUTABLE_CODE_ID.fullmatch(prediction.scenario_snapshot.code_version) is None:
                raise DomainValidationError(
                    "release-grade evidence requires an immutable scenario code version"
                )
            if _IMMUTABLE_CODE_ID.fullmatch(prediction.code_version) is None:
                raise DomainValidationError(
                    "release-grade evidence requires an immutable prediction code version"
                )
            if _IMMUTABLE_CONTAINER_DIGEST.fullmatch(prediction.container_digest) is None:
                raise DomainValidationError(
                    "release-grade evidence requires an immutable execution image digest"
                )
            for identity_type, identities in (
                ("scenario model", prediction.scenario_snapshot.model_versions),
                ("scenario dataset", prediction.scenario_snapshot.dataset_versions),
                ("prediction model", prediction.model_versions),
                ("prediction dataset", prediction.dataset_versions),
            ):
                for identity in identities:
                    normalized = identity.strip()
                    if _IMMUTABLE_ARTIFACT_ID.fullmatch(normalized) is None:
                        raise DomainValidationError(
                            f"release-grade evidence requires a content-addressed {identity_type} version"
                        )

    def _require_measurement_capability(
        self,
        package: EvidencePackageVersion,
        measurement: MeasurementEnvelope,
    ) -> None:
        if measurement.payload.source_data_class not in {
            SourceDataClass.REAL_HUMAN,
            SourceDataClass.QUALIFIED_LAB,
        }:
            return
        if not self._allow_non_synthetic:
            raise DomainValidationError(
                "real-human and qualified-lab data are blocked in the local plaintext runtime"
            )
        if not measurement.subject_pseudonymized:
            raise DomainValidationError("non-synthetic measurement subject must be pseudonymized")
        required_purpose = "clinical" if package.policy.clinical_use else "research"
        if required_purpose not in measurement.payload.consent_scope:
            raise DomainValidationError(
                f"measurement consent scope does not permit {required_purpose} use"
            )

    def _require_data_capability(self, package: EvidencePackageVersion) -> None:
        for measurement in package.measurements:
            self._require_measurement_capability(package, measurement)

    @staticmethod
    def _require_independent_actor(
        package: EvidencePackageVersion, actor: str, action: str
    ) -> None:
        model_actors = {prediction.actor_id for prediction in package.predictions}
        if actor == package.created_by or actor in model_actors:
            raise DomainValidationError(f"{action} requires separation of duties")
