"""Exact canonical bytes and hashes for immutable evidence payloads."""
from __future__ import annotations

import hashlib
import json
import math
import unicodedata
from dataclasses import fields, is_dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from enum import Enum
from pathlib import Path
from typing import Any, Mapping

from .errors import DomainValidationError


LIFECYCLE_METADATA_FIELDS = frozenset(
    {
        "content_hash",
        "lifecycle",
        "revision",
        "locked_at",
        "released_at",
        "retracted_at",
        "superseded_at",
        "lifecycle_reason",
        "claim_state",
        "validation_summary",
    }
)


def canonical_decimal(value: Decimal) -> str:
    """Return the fixed-point canonical representation for evidence numbers."""
    if not isinstance(value, Decimal):
        try:
            value = Decimal(str(value))
        except (InvalidOperation, ValueError) as exc:
            raise DomainValidationError("invalid decimal value") from exc
    if not value.is_finite():
        raise DomainValidationError("NaN and infinity are not valid evidence values")
    if value == 0:
        return "0.0"
    rendered = format(value, "f")
    if "." in rendered:
        rendered = rendered.rstrip("0").rstrip(".")
    if "." not in rendered:
        rendered += ".0"
    if rendered.startswith("-0") and Decimal(rendered) == 0:
        return "0.0"
    return rendered


def canonical_timestamp(value: datetime) -> str:
    """Render an aware timestamp in UTC with exactly millisecond precision."""
    if value.tzinfo is None or value.utcoffset() is None:
        raise DomainValidationError("evidence timestamps must be timezone-aware")
    value = value.astimezone(timezone.utc)
    milliseconds = value.microsecond // 1000
    return value.strftime("%Y-%m-%dT%H:%M:%S") + f".{milliseconds:03d}Z"


def to_primitive(value: Any) -> Any:
    """Convert supported domain values into the canonical JSON data model."""
    if is_dataclass(value) and not isinstance(value, type):
        return {field.name: to_primitive(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, Enum):
        return to_primitive(value.value)
    if isinstance(value, datetime):
        return canonical_timestamp(value)
    if isinstance(value, Decimal):
        return canonical_decimal(value)
    if isinstance(value, Path):
        return unicodedata.normalize("NFC", str(value))
    if isinstance(value, str):
        return unicodedata.normalize("NFC", value)
    if value is None or isinstance(value, (bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise DomainValidationError("NaN and infinity are not valid evidence values")
        return canonical_decimal(Decimal(str(value)))
    if isinstance(value, Mapping):
        normalized: dict[str, Any] = {}
        for raw_key, raw_value in value.items():
            if not isinstance(raw_key, str):
                raise DomainValidationError("canonical JSON object keys must be strings")
            key = unicodedata.normalize("NFC", raw_key)
            if key in normalized:
                raise DomainValidationError("Unicode normalization produced a duplicate object key")
            normalized[key] = to_primitive(raw_value)
        return normalized
    if isinstance(value, (tuple, list)):
        return [to_primitive(item) for item in value]
    if isinstance(value, (set, frozenset)):
        normalized_items = [to_primitive(item) for item in value]
        return sorted(normalized_items, key=canonical_json_bytes)
    raise DomainValidationError(f"unsupported canonical evidence type: {type(value).__name__}")


def canonical_json_bytes(value: Any) -> bytes:
    """Serialize exact UTF-8 canonical JSON bytes."""
    try:
        rendered = json.dumps(
            to_primitive(value),
            sort_keys=True,
            ensure_ascii=False,
            separators=(",", ":"),
            allow_nan=False,
        )
    except (TypeError, ValueError) as exc:
        raise DomainValidationError("value cannot be represented as canonical JSON") from exc
    return rendered.encode("utf-8")


def sha256_hex(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def canonical_hash(value: Any) -> str:
    return sha256_hex(canonical_json_bytes(value))


def content_payload(package: Any) -> dict[str, Any]:
    """Return a package payload with only operational lifecycle metadata removed."""
    primitive = to_primitive(package)
    if not isinstance(primitive, dict):
        raise DomainValidationError("evidence package must be an object")
    return {key: value for key, value in primitive.items() if key not in LIFECYCLE_METADATA_FIELDS}


def content_hash(package: Any) -> str:
    """Hash the evidence content, excluding its own hash and lifecycle metadata."""
    return sha256_hex(canonical_json_bytes(content_payload(package)))
