"""Tenant-scoped SQLite persistence with optimistic writes and audit chaining."""
from __future__ import annotations

import base64
import binascii
import hashlib
import json
import hmac
import os
import sqlite3
import stat
import uuid
from contextlib import contextmanager
from dataclasses import replace
from pathlib import Path
from typing import Any, Iterator, Mapping, Optional

from .canonical import canonical_hash, canonical_json_bytes, content_hash as calculate_content_hash, sha256_hex
from .errors import (
    ConflictError,
    DomainValidationError,
    IntegrityError,
    NotFoundError,
    StaleExportError,
)
from .models import (
    CalibrationAuthorization,
    EvidencePackageVersion,
    LifecycleStatus,
    calibration_authorization_from_dict,
    evidence_package_from_dict,
    normalize_identity,
    utc_now,
)
from .policies import require_approved_policy


_PACKAGE_PAYLOAD_SHA256 = "package_payload_sha256"
_PACKAGE_REVISION = "package_revision"
_AUTHORIZATION_PAYLOAD_SHA256 = "authorization_payload_sha256"


def _ensure_private_directory(path: Path) -> None:
    """Create a private leaf directory without chmod-ing an operator-owned parent."""
    try:
        path.mkdir(parents=True, exist_ok=False, mode=0o700)
    except FileExistsError:
        if not path.is_dir():
            raise NotADirectoryError(str(path))
    else:
        os.chmod(path, 0o700)


SCHEMA = """
CREATE TABLE IF NOT EXISTS evidence_packages (
    tenant_id TEXT NOT NULL,
    package_id TEXT NOT NULL,
    version INTEGER NOT NULL,
    previous_version_id TEXT,
    lifecycle TEXT NOT NULL,
    revision INTEGER NOT NULL,
    content_hash TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (tenant_id, package_id),
    UNIQUE (tenant_id, previous_version_id, version),
    FOREIGN KEY (tenant_id, previous_version_id)
        REFERENCES evidence_packages (tenant_id, package_id)
);

CREATE TABLE IF NOT EXISTS evidence_audit_events (
    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id TEXT NOT NULL UNIQUE,
    tenant_id TEXT NOT NULL,
    package_id TEXT NOT NULL,
    action TEXT NOT NULL,
    actor TEXT NOT NULL,
    occurred_at TEXT NOT NULL,
    detail_json TEXT NOT NULL,
    previous_event_hash TEXT NOT NULL,
    event_hash TEXT NOT NULL UNIQUE,
    key_version TEXT NOT NULL,
    event_signature TEXT NOT NULL,
    FOREIGN KEY (tenant_id, package_id)
        REFERENCES evidence_packages (tenant_id, package_id)
);

CREATE INDEX IF NOT EXISTS evidence_audit_tenant_sequence
    ON evidence_audit_events (tenant_id, sequence);

CREATE TABLE IF NOT EXISTS evidence_exports (
    tenant_id TEXT NOT NULL,
    package_id TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    archive_sha256 TEXT NOT NULL,
    directory TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (tenant_id, package_id, content_hash, archive_sha256),
    FOREIGN KEY (tenant_id, package_id)
        REFERENCES evidence_packages (tenant_id, package_id)
);

CREATE TABLE IF NOT EXISTS calibration_authorizations (
    tenant_id TEXT NOT NULL,
    authorization_id TEXT NOT NULL,
    package_id TEXT NOT NULL,
    cendos_run_id TEXT NOT NULL,
    consumed INTEGER NOT NULL DEFAULT 0 CHECK (consumed IN (0, 1)),
    payload_json TEXT NOT NULL,
    payload_sha256 TEXT NOT NULL,
    PRIMARY KEY (tenant_id, authorization_id),
    FOREIGN KEY (tenant_id, package_id)
        REFERENCES evidence_packages (tenant_id, package_id)
);

CREATE TABLE IF NOT EXISTS evidence_idempotency (
    tenant_id TEXT NOT NULL,
    operation TEXT NOT NULL,
    idempotency_key TEXT NOT NULL,
    resource_id TEXT NOT NULL,
    request_hash TEXT NOT NULL,
    result_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (tenant_id, operation, idempotency_key)
);
"""


class EvidenceStore:
    """Local evidence store. Production PHI requires a managed encrypted store."""

    def __init__(
        self,
        path: str | Path,
        busy_timeout_ms: int = 5000,
        *,
        audit_signing_key: Optional[bytes | str] = None,
        audit_key_version: Optional[str] = None,
        audit_verification_keys: Optional[Mapping[str, bytes | str]] = None,
        require_external_audit_key: bool = False,
    ):
        self.path = Path(path).expanduser()
        self.audit_key_path = self.path.with_name(self.path.name + ".audit.key")
        self.busy_timeout_ms = int(busy_timeout_ms)
        if self.busy_timeout_ms < 1:
            raise ValueError("busy_timeout_ms must be positive")
        _ensure_private_directory(self.path.parent)
        configured_key = audit_signing_key or os.getenv(
            "LIVEMORE_EVIDENCE_AUDIT_HMAC_KEY"
        )
        environment = os.getenv("LIVEMORE_ENVIRONMENT", "").strip().lower()
        if configured_key is None and (
            require_external_audit_key or environment in {"prod", "production"}
        ):
            raise ValueError(
                "production evidence audit signing requires an externally managed HMAC key"
            )
        if configured_key is None:
            self.audit_key_version = audit_key_version or "local-file-v1"
            self._audit_signing_key = self._load_or_create_local_audit_key()
        else:
            self.audit_key_version = (
                audit_key_version
                or os.getenv("LIVEMORE_EVIDENCE_AUDIT_KEY_VERSION")
                or "configured-v1"
            )
            self._audit_signing_key = self._decode_audit_key(configured_key)
        self.audit_key_version = self.audit_key_version.strip()
        if not self.audit_key_version:
            raise ValueError("evidence audit key version is required")
        self._audit_verification_keys: dict[str, bytes] = {}
        environment_keyring: Mapping[str, bytes | str] = {}
        raw_environment_keyring = os.getenv(
            "LIVEMORE_EVIDENCE_AUDIT_HMAC_VERIFICATION_KEYS", ""
        ).strip()
        if raw_environment_keyring:
            def reject_duplicate_versions(
                pairs: list[tuple[str, Any]],
            ) -> dict[str, Any]:
                keyring: dict[str, Any] = {}
                for version, key in pairs:
                    if version in keyring:
                        raise ValueError(
                            "evidence audit verification keyring contains a duplicate "
                            "key version"
                        )
                    keyring[version] = key
                return keyring

            try:
                parsed_keyring = json.loads(
                    raw_environment_keyring,
                    object_pairs_hook=reject_duplicate_versions,
                )
            except json.JSONDecodeError as exc:
                raise ValueError(
                    "LIVEMORE_EVIDENCE_AUDIT_HMAC_VERIFICATION_KEYS must be valid JSON"
                ) from exc
            if not isinstance(parsed_keyring, dict):
                raise ValueError(
                    "LIVEMORE_EVIDENCE_AUDIT_HMAC_VERIFICATION_KEYS must map key versions to keys"
                )
            if any(not isinstance(key, str) for key in parsed_keyring.values()):
                raise ValueError("evidence audit verification keys must be JSON strings")
            environment_keyring = parsed_keyring
        for keyring in (environment_keyring, dict(audit_verification_keys or {})):
            for version, key in keyring.items():
                normalized_version = str(version).strip()
                if not normalized_version:
                    raise ValueError("evidence audit verification key version is required")
                decoded_key = self._decode_audit_key(key)
                existing_key = self._audit_verification_keys.get(normalized_version)
                if existing_key is not None and not hmac.compare_digest(
                    existing_key,
                    decoded_key,
                ):
                    raise ValueError(
                        "evidence audit verification key version maps to different key material"
                    )
                self._audit_verification_keys[normalized_version] = decoded_key
        existing_current = self._audit_verification_keys.get(self.audit_key_version)
        if existing_current is not None and not hmac.compare_digest(
            existing_current,
            self._audit_signing_key,
        ):
            raise ValueError("current audit key version maps to a different verification key")
        self._audit_verification_keys[self.audit_key_version] = self._audit_signing_key
        connection = self._connect()
        try:
            connection.executescript(SCHEMA)
            columns = {
                row[1] for row in connection.execute("PRAGMA table_info(evidence_idempotency)")
            }
            if "request_hash" not in columns:
                connection.execute(
                    "ALTER TABLE evidence_idempotency ADD COLUMN request_hash TEXT NOT NULL DEFAULT ''"
                )
            authorization_columns = {
                row[1]
                for row in connection.execute(
                    "PRAGMA table_info(calibration_authorizations)"
                )
            }
            if "payload_sha256" not in authorization_columns:
                connection.execute(
                    "ALTER TABLE calibration_authorizations "
                    "ADD COLUMN payload_sha256 TEXT NOT NULL DEFAULT ''"
                )
            audit_columns = {
                row[1]
                for row in connection.execute(
                    "PRAGMA table_info(evidence_audit_events)"
                )
            }
            if "key_version" not in audit_columns:
                connection.execute(
                    "ALTER TABLE evidence_audit_events "
                    "ADD COLUMN key_version TEXT NOT NULL DEFAULT ''"
                )
            if "event_signature" not in audit_columns:
                connection.execute(
                    "ALTER TABLE evidence_audit_events "
                    "ADD COLUMN event_signature TEXT NOT NULL DEFAULT ''"
                )
            connection.commit()
        finally:
            connection.close()
        os.chmod(self.path, 0o600)

    def close(self) -> None:
        """Close hook retained for dependency-injected runtime symmetry."""

    @staticmethod
    def _decode_audit_key(value: bytes | str) -> bytes:
        if isinstance(value, bytes):
            key = value
        else:
            encoded = str(value).strip()
            try:
                if encoded.startswith("base64:"):
                    key = base64.b64decode(encoded.removeprefix("base64:"), validate=True)
                elif encoded.startswith("hex:"):
                    key = bytes.fromhex(encoded.removeprefix("hex:"))
                else:
                    key = encoded.encode("utf-8")
            except (binascii.Error, ValueError) as exc:
                raise ValueError("evidence audit signing key encoding is invalid") from exc
        if len(key) < 32:
            raise ValueError("evidence audit signing key must contain at least 32 bytes")
        return key

    def _load_or_create_local_audit_key(self) -> bytes:
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
        try:
            descriptor = os.open(self.audit_key_path, flags)
        except FileNotFoundError:
            key = os.urandom(32)
            create_flags = (
                os.O_WRONLY
                | os.O_CREAT
                | os.O_EXCL
                | getattr(os, "O_NOFOLLOW", 0)
            )
            try:
                descriptor = os.open(self.audit_key_path, create_flags, 0o600)
            except FileExistsError:
                descriptor = os.open(self.audit_key_path, flags)
            else:
                try:
                    os.fchmod(descriptor, 0o600)
                    with os.fdopen(descriptor, "wb", closefd=False) as handle:
                        handle.write(key)
                        handle.flush()
                        os.fsync(handle.fileno())
                finally:
                    os.close(descriptor)
                return key
        try:
            if not stat.S_ISREG(os.fstat(descriptor).st_mode):
                raise IntegrityError("local evidence audit key must be a regular file")
            os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, "rb", closefd=False) as handle:
                key = handle.read()
        finally:
            os.close(descriptor)
        if len(key) != 32:
            raise IntegrityError("local evidence audit key file has an invalid length")
        return key

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(
            str(self.path),
            timeout=self.busy_timeout_ms / 1000,
            isolation_level=None,
        )
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute(f"PRAGMA busy_timeout = {self.busy_timeout_ms}")
        connection.execute("PRAGMA journal_mode = WAL")
        connection.execute("PRAGMA synchronous = FULL")
        return connection

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def pragma(self, name: str) -> int | str:
        if name not in {"foreign_keys", "busy_timeout", "journal_mode", "synchronous"}:
            raise ValueError("unsupported pragma")
        connection = self._connect()
        try:
            row = connection.execute(f"PRAGMA {name}").fetchone()
            return row[0]
        finally:
            connection.close()

    def create(
        self,
        package: EvidencePackageVersion,
        *,
        actor: str,
        verification_actor: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> EvidencePackageVersion:
        if package.version != 1 or package.previous_version_id is not None:
            raise DomainValidationError(
                "new evidence package must be a root version; use create_revision for lineage"
            )
        request_hash = canonical_hash(
            {"package": package, "actor": actor, "verification_actor": verification_actor}
        )
        with self.transaction() as connection:
            existing_id = self._idempotent_resource(
                connection, package.tenant_id, "package.create", idempotency_key,
                expected_resource_id=package.package_id, request_hash=request_hash,
            )
            if existing_id:
                return self._get(connection, package.tenant_id, existing_id)
            if not self._verify_audit_chain(connection, package.tenant_id):
                raise IntegrityError(
                    "evidence audit chain failed integrity verification"
                )
            try:
                self._insert_package(connection, package)
            except sqlite3.IntegrityError as exc:
                raise ConflictError("evidence package ID or version already exists") from exc
            self._append_audit(
                connection,
                package.tenant_id,
                package.package_id,
                "package.created",
                actor,
                self._package_state_detail(package),
            )
            for verification in package.model_verifications:
                self._append_audit(
                    connection,
                    package.tenant_id,
                    package.package_id,
                    "model_verification.added",
                    verification_actor or verification.verifier_id,
                    {"verification_id": verification.verification_id},
                )
            self._record_idempotency(
                connection,
                package.tenant_id,
                "package.create",
                idempotency_key,
                package.package_id,
                request_hash,
                package.content_hash or "draft",
            )
            return package

    def get(self, tenant_id: str, package_id: str) -> EvidencePackageVersion:
        connection = self._connect()
        try:
            connection.execute("BEGIN")
            return self._get(connection, tenant_id, package_id)
        finally:
            connection.close()

    def list(self, tenant_id: str) -> tuple[EvidencePackageVersion, ...]:
        connection = self._connect()
        try:
            connection.execute("BEGIN")
            rows = connection.execute(
                "SELECT package_id FROM evidence_packages WHERE tenant_id=? "
                "ORDER BY created_at, package_id",
                (tenant_id,),
            ).fetchall()
            return tuple(
                self._get(connection, tenant_id, row["package_id"])
                for row in rows
            )
        finally:
            connection.close()

    def verify_content(self, tenant_id: str, package_id: str) -> bool:
        """Verify exact stored canonical content without normalizing through model decoding."""
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        package_id = normalize_identity(package_id, "package_id")
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT lifecycle,revision,content_hash,payload_json FROM evidence_packages "
                "WHERE tenant_id=? AND package_id=?",
                (tenant_id, package_id),
            ).fetchone()
            if row is None:
                raise NotFoundError("evidence package not found")
            data = json.loads(row["payload_json"])
            embedded_hash = str(data.get("content_hash") or "")
            stored_hash = str(row["content_hash"] or "")
            if (
                str(data.get("lifecycle")) != str(row["lifecycle"])
                or int(data.get("revision", -1)) != int(row["revision"])
            ):
                return False
            if not embedded_hash or not hmac.compare_digest(embedded_hash, stored_hash):
                return False
            calculated = calculate_content_hash(data)
            return hmac.compare_digest(calculated, stored_hash)
        finally:
            connection.close()

    def idempotent_package(
        self,
        tenant_id: str,
        operation: str,
        idempotency_key: Optional[str],
        *,
        expected_resource_id: str,
        request_hash: str,
    ) -> Optional[EvidencePackageVersion]:
        if not idempotency_key:
            return None
        connection = self._connect()
        try:
            package_id = self._idempotent_resource(
                connection, tenant_id, operation, idempotency_key,
                expected_resource_id=expected_resource_id, request_hash=request_hash,
            )
            return self._get(connection, tenant_id, package_id) if package_id else None
        finally:
            connection.close()

    def update(
        self,
        package: EvidencePackageVersion,
        *,
        expected_revision: int,
        actor: str,
        action: str,
        detail: Optional[Mapping[str, Any]] = None,
        idempotency_key: Optional[str] = None,
        idempotency_request_hash: Optional[str] = None,
    ) -> EvidencePackageVersion:
        request_hash = idempotency_request_hash or canonical_hash(
            {
                "package": package,
                "expected_revision": expected_revision,
                "actor": actor,
                "action": action,
                "detail": dict(detail or {}),
            }
        )
        with self.transaction() as connection:
            existing_id = self._idempotent_resource(
                connection, package.tenant_id, action, idempotency_key,
                expected_resource_id=package.package_id, request_hash=request_hash,
            )
            if existing_id:
                return self._get(connection, package.tenant_id, existing_id)
            current = self._get(connection, package.tenant_id, package.package_id)
            if current.revision != expected_revision:
                raise ConflictError(
                    f"stale evidence revision: expected {expected_revision}, current {current.revision}"
                )
            if package.revision != expected_revision + 1:
                raise ConflictError("updated package revision must increment exactly once")
            if action == "package.locked":
                self._assert_active_ancestry(connection, current)
            if (
                action == "package.retracted"
                and current.lifecycle is LifecycleStatus.SUPERSEDED
                and self._has_non_retracted_descendant(
                    connection,
                    package.tenant_id,
                    package.package_id,
                )
            ):
                raise ConflictError(
                    "cannot retract a superseded ancestor while a descendant remains active"
                )
            cursor = connection.execute(
                "UPDATE evidence_packages SET lifecycle=?, revision=?, content_hash=?, payload_json=? "
                "WHERE tenant_id=? AND package_id=? AND revision=?",
                (
                    package.lifecycle.value,
                    package.revision,
                    package.content_hash,
                    self._encode_package(package),
                    package.tenant_id,
                    package.package_id,
                    expected_revision,
                ),
            )
            if cursor.rowcount != 1:
                raise ConflictError("concurrent evidence update detected")
            self._append_audit(
                connection,
                package.tenant_id,
                package.package_id,
                action,
                actor,
                self._package_state_detail(package, detail),
            )
            self._record_idempotency(
                connection,
                package.tenant_id,
                action,
                idempotency_key,
                package.package_id,
                request_hash,
                package.content_hash or "draft",
            )
            return package

    def create_revision(
        self,
        source_tenant_id: str,
        source_package_id: str,
        revision: EvidencePackageVersion,
        *,
        expected_revision: int,
        actor: str,
        idempotency_key: Optional[str] = None,
    ) -> EvidencePackageVersion:
        request_hash = canonical_hash(
            {
                "source_package_id": source_package_id,
                "revision": revision,
                "expected_revision": expected_revision,
                "actor": actor,
            }
        )
        with self.transaction() as connection:
            existing_id = self._idempotent_resource(
                connection, source_tenant_id, "package.revision_created", idempotency_key,
                expected_resource_id=revision.package_id, request_hash=request_hash,
            )
            if existing_id:
                return self._get(connection, source_tenant_id, existing_id)
            source = self._get(connection, source_tenant_id, source_package_id)
            if source.revision != expected_revision:
                raise ConflictError(
                    f"stale evidence revision: expected {expected_revision}, current {source.revision}"
                )
            try:
                self._insert_package(connection, revision)
            except sqlite3.IntegrityError as exc:
                raise ConflictError("replacement evidence package ID or version already exists") from exc
            self._append_audit(
                connection,
                revision.tenant_id,
                revision.package_id,
                "package.revision_created",
                actor,
                self._package_state_detail(
                    revision,
                    {"previous_version_id": source.package_id},
                ),
            )
            self._record_idempotency(
                connection,
                revision.tenant_id,
                "package.revision_created",
                idempotency_key,
                revision.package_id,
                request_hash,
                "draft",
            )
            return revision

    def release(
        self,
        package: EvidencePackageVersion,
        *,
        expected_revision: int,
        actor: str,
        idempotency_key: Optional[str] = None,
        idempotency_request_hash: Optional[str] = None,
    ) -> EvidencePackageVersion:
        """Release a package and atomically supersede its active predecessor."""
        request_hash = idempotency_request_hash or canonical_hash(
            {"package": package, "expected_revision": expected_revision, "actor": actor}
        )
        with self.transaction() as connection:
            existing_id = self._idempotent_resource(
                connection, package.tenant_id, "package.released", idempotency_key,
                expected_resource_id=package.package_id, request_hash=request_hash,
            )
            if existing_id:
                return self._get(connection, package.tenant_id, existing_id)
            current = self._get(connection, package.tenant_id, package.package_id)
            if current.revision != expected_revision:
                raise ConflictError(
                    f"stale evidence revision: expected {expected_revision}, current {current.revision}"
                )
            self._assert_active_ancestry(connection, current)
            previous = None
            if package.previous_version_id:
                previous = self._get(
                    connection,
                    package.tenant_id,
                    package.previous_version_id,
                )
                if previous.lifecycle is not LifecycleStatus.RELEASED:
                    raise ConflictError(
                        "replacement evidence predecessor is no longer released"
                    )
            cursor = connection.execute(
                "UPDATE evidence_packages SET lifecycle=?, revision=?, content_hash=?, payload_json=? "
                "WHERE tenant_id=? AND package_id=? AND revision=?",
                (
                    package.lifecycle.value,
                    package.revision,
                    package.content_hash,
                    self._encode_package(package),
                    package.tenant_id,
                    package.package_id,
                    expected_revision,
                ),
            )
            if cursor.rowcount != 1:
                raise ConflictError("concurrent evidence release detected")
            self._append_audit(
                connection,
                package.tenant_id,
                package.package_id,
                "package.released",
                actor,
                self._package_state_detail(package),
            )
            if package.previous_version_id:
                assert previous is not None
                superseded = replace(
                    previous,
                    lifecycle=LifecycleStatus.SUPERSEDED,
                    revision=previous.revision + 1,
                    superseded_at=package.released_at,
                    lifecycle_reason=f"superseded by {package.package_id}",
                )
                previous_cursor = connection.execute(
                    "UPDATE evidence_packages SET lifecycle=?, revision=?, payload_json=? "
                    "WHERE tenant_id=? AND package_id=? AND revision=? AND lifecycle=?",
                    (
                        superseded.lifecycle.value,
                        superseded.revision,
                        self._encode_package(superseded),
                        superseded.tenant_id,
                        superseded.package_id,
                        previous.revision,
                        LifecycleStatus.RELEASED.value,
                    ),
                )
                if previous_cursor.rowcount != 1:
                    raise ConflictError("replacement evidence predecessor changed concurrently")
                self._append_audit(
                    connection,
                    previous.tenant_id,
                    previous.package_id,
                    "package.superseded",
                    actor,
                    self._package_state_detail(
                        superseded,
                        {"replacement_package_id": package.package_id},
                    ),
                )
            self._record_idempotency(
                connection,
                package.tenant_id,
                "package.released",
                idempotency_key,
                package.package_id,
                request_hash,
                package.content_hash,
            )
            return package

    def save_export(
        self,
        tenant_id: str,
        package_id: str,
        content_hash: str,
        archive_sha256: str,
        directory: str,
        *,
        expected_revision: int,
        expected_lifecycle: LifecycleStatus,
        expected_payload_sha256: str,
        actor: str,
        idempotency_key: Optional[str] = None,
        idempotency_request_hash: Optional[str] = None,
    ) -> None:
        request_hash = idempotency_request_hash or canonical_hash(
            {
                "package_id": package_id,
                "content_hash": content_hash,
                "directory": directory,
                "expected_revision": expected_revision,
                "expected_lifecycle": expected_lifecycle.value,
                "expected_payload_sha256": expected_payload_sha256,
            }
        )
        with self.transaction() as connection:
            current = self._get(connection, tenant_id, package_id)
            try:
                self._assert_active_ancestry(connection, current)
            except IntegrityError as exc:
                raise StaleExportError(
                    "evidence lineage changed before export registration"
                ) from exc
            if (
                current.revision != expected_revision
                or current.lifecycle is not expected_lifecycle
                or not hmac.compare_digest(current.content_hash, content_hash)
                or not hmac.compare_digest(
                    canonical_hash(current), expected_payload_sha256
                )
            ):
                raise StaleExportError(
                    "evidence package changed before export registration"
                )
            existing_id = self._idempotent_resource(
                connection, tenant_id, "package.exported", idempotency_key,
                expected_resource_id=package_id, request_hash=request_hash,
            )
            if existing_id:
                if existing_id != package_id:
                    raise ConflictError("export idempotency key belongs to another package")
                return
            existing_export = connection.execute(
                "SELECT directory FROM evidence_exports WHERE tenant_id=? AND package_id=? "
                "AND content_hash=? AND archive_sha256=?",
                (tenant_id, package_id, content_hash, archive_sha256),
            ).fetchone()
            if existing_export is not None:
                registered_directory = str(existing_export["directory"])
                if not hmac.compare_digest(registered_directory, directory):
                    raise ConflictError(
                        "signed evidence archive is already registered at another directory"
                    )
                self._record_idempotency(
                    connection,
                    tenant_id,
                    "package.exported",
                    idempotency_key,
                    package_id,
                    request_hash,
                    archive_sha256,
                )
                return
            connection.execute(
                "INSERT INTO evidence_exports "
                "(tenant_id,package_id,content_hash,archive_sha256,directory,created_at) "
                "VALUES(?,?,?,?,?,?)",
                (
                    tenant_id,
                    package_id,
                    content_hash,
                    archive_sha256,
                    directory,
                    self._timestamp(),
                ),
            )
            self._append_audit(
                connection,
                tenant_id,
                package_id,
                "package.exported",
                actor,
                {"archive_sha256": archive_sha256},
            )
            self._record_idempotency(
                connection,
                tenant_id,
                "package.exported",
                idempotency_key,
                package_id,
                request_hash,
                archive_sha256,
            )

    def is_export_registered(
        self,
        tenant_id: str,
        package_id: str,
        content_hash: str,
        archive_sha256: str,
        directory: str,
    ) -> bool:
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        package_id = normalize_identity(package_id, "package_id")
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT directory FROM evidence_exports WHERE tenant_id=? AND package_id=? "
                "AND content_hash=? AND archive_sha256=?",
                (tenant_id, package_id, content_hash, archive_sha256),
            ).fetchone()
            return row is not None and hmac.compare_digest(str(row["directory"]), directory)
        finally:
            connection.close()

    def create_authorization(
        self,
        authorization: CalibrationAuthorization,
        *,
        actor: str,
        idempotency_key: Optional[str] = None,
    ) -> CalibrationAuthorization:
        request_hash = canonical_hash(
            {
                "package_id": authorization.package_id,
                "package_content_hash": authorization.package_content_hash,
                "cendos_run_id": authorization.cendos_run_id,
                "live_twin_id": authorization.live_twin_id,
                "validation_event_ids": authorization.validation_event_ids,
                "parameter_scope": authorization.parameter_scope,
                "reviewer_id": authorization.reviewer_id,
                "policy_id": authorization.policy_id,
                "policy_hash": authorization.policy_hash,
            }
        )
        with self.transaction() as connection:
            existing_id = self._idempotent_resource(
                connection,
                authorization.tenant_id,
                "calibration.authorized",
                idempotency_key,
                expected_resource_id=None,
                request_hash=request_hash,
            )
            if existing_id:
                existing = self._get_authorization(
                    connection,
                    authorization.tenant_id,
                    existing_id,
                )
                self._validate_authorization_package(connection, existing)
                return existing
            self._validate_authorization_package(connection, authorization)
            payload_json = canonical_json_bytes(authorization).decode("utf-8")
            payload_sha256 = sha256_hex(payload_json.encode("utf-8"))
            try:
                connection.execute(
                    "INSERT INTO calibration_authorizations "
                    "(tenant_id,authorization_id,package_id,cendos_run_id,consumed,payload_json,payload_sha256) "
                    "VALUES(?,?,?,?,?,?,?)",
                    (
                        authorization.tenant_id,
                        authorization.authorization_id,
                        authorization.package_id,
                        authorization.cendos_run_id,
                        int(authorization.consumed),
                        payload_json,
                        payload_sha256,
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise ConflictError("calibration authorization already exists") from exc
            self._append_audit(
                connection,
                authorization.tenant_id,
                authorization.package_id,
                "calibration.authorized",
                actor,
                {
                    "authorization_id": authorization.authorization_id,
                    _AUTHORIZATION_PAYLOAD_SHA256: payload_sha256,
                },
            )
            self._record_idempotency(
                connection,
                authorization.tenant_id,
                "calibration.authorized",
                idempotency_key,
                authorization.authorization_id,
                request_hash,
                authorization.package_content_hash,
            )
            return authorization

    def get_authorization(self, tenant_id: str, authorization_id: str) -> CalibrationAuthorization:
        connection = self._connect()
        try:
            return self._get_authorization(connection, tenant_id, authorization_id)
        finally:
            connection.close()

    def consume_authorization(
        self,
        authorization: CalibrationAuthorization,
        *,
        actor: str,
    ) -> CalibrationAuthorization:
        with self.transaction() as connection:
            current = self._get_authorization(
                connection, authorization.tenant_id, authorization.authorization_id
            )
            if current != replace(
                authorization,
                consumed=False,
                consumed_at=None,
            ):
                raise IntegrityError(
                    "calibration authorization does not match the stored record"
                )
            if current.consumed:
                raise ConflictError("calibration authorization has already been consumed")
            if not authorization.consumed or authorization.consumed_at is None:
                raise IntegrityError("consumed authorization state is required")
            self._validate_authorization_package(connection, current)
            payload_json = canonical_json_bytes(authorization).decode("utf-8")
            payload_sha256 = sha256_hex(payload_json.encode("utf-8"))
            cursor = connection.execute(
                "UPDATE calibration_authorizations "
                "SET consumed=1,payload_json=?,payload_sha256=? "
                "WHERE tenant_id=? AND authorization_id=? AND consumed=0",
                (
                    payload_json,
                    payload_sha256,
                    authorization.tenant_id,
                    authorization.authorization_id,
                ),
            )
            if cursor.rowcount != 1:
                raise ConflictError("calibration authorization was consumed concurrently")
            self._append_audit(
                connection,
                authorization.tenant_id,
                authorization.package_id,
                "calibration.consumed",
                actor,
                {
                    "authorization_id": authorization.authorization_id,
                    _AUTHORIZATION_PAYLOAD_SHA256: payload_sha256,
                },
            )
            return authorization

    def audit_events(self, tenant_id: str, package_id: Optional[str] = None) -> tuple[dict[str, Any], ...]:
        connection = self._connect()
        try:
            connection.execute("BEGIN")
            if not self._verify_audit_chain(connection, tenant_id):
                raise IntegrityError("evidence audit chain failed integrity verification")
            if package_id is None:
                rows = connection.execute(
                    "SELECT * FROM evidence_audit_events WHERE tenant_id=? ORDER BY sequence",
                    (tenant_id,),
                ).fetchall()
            else:
                rows = connection.execute(
                    "SELECT * FROM evidence_audit_events WHERE tenant_id=? AND package_id=? ORDER BY sequence",
                    (tenant_id, package_id),
                ).fetchall()
            return tuple(self._audit_row(row) for row in rows)
        finally:
            connection.close()

    def audit_proof_reference(
        self,
        tenant_id: str,
        package_id: str,
    ) -> dict[str, Any]:
        """Return the stable signed-audit event bound to the current package revision."""

        connection = self._connect()
        try:
            package = self._get(connection, tenant_id, package_id)
            tenant_id = package.tenant_id
            package_id = package.package_id
            payload_sha256 = sha256_hex(canonical_json_bytes(package))
            rows = connection.execute(
                "SELECT * FROM evidence_audit_events "
                "WHERE tenant_id=? AND package_id=? ORDER BY sequence",
                (tenant_id, package_id),
            ).fetchall()
            matched: Optional[sqlite3.Row] = None
            for row in rows:
                detail = json.loads(row["detail_json"])
                if (
                    detail.get(_PACKAGE_PAYLOAD_SHA256) == payload_sha256
                    and int(detail.get(_PACKAGE_REVISION, -1)) == package.revision
                ):
                    matched = row
            if matched is None:
                raise IntegrityError(
                    "current evidence revision has no matching signed audit event"
                )
            detail = json.loads(matched["detail_json"])
            return {
                "schema_version": "livemore.evidence-audit-proof-reference.v1",
                "status": "available",
                "package_id": package.package_id,
                "package_revision": package.revision,
                "package_payload_sha256": payload_sha256,
                "audit_event_id": matched["event_id"],
                "audit_event_sequence": int(matched["sequence"]),
                "audit_action": matched["action"],
                "audit_occurred_at": matched["occurred_at"],
                "audit_previous_event_hash": matched["previous_event_hash"],
                "audit_event_hash": matched["event_hash"],
                "audit_key_version": matched["key_version"],
                "audit_event_signature": matched["event_signature"],
                "audit_payload_key_version": detail.get("audit_key_version"),
            }
        finally:
            connection.close()

    def verify_audit_chain(self, tenant_id: str) -> bool:
        connection = self._connect()
        try:
            return self._verify_audit_chain(connection, tenant_id)
        finally:
            connection.close()

    def _insert_package(self, connection: sqlite3.Connection, package: EvidencePackageVersion) -> None:
        connection.execute(
            "INSERT INTO evidence_packages "
            "(tenant_id,package_id,version,previous_version_id,lifecycle,revision,content_hash,payload_json,created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (
                package.tenant_id,
                package.package_id,
                package.version,
                package.previous_version_id,
                package.lifecycle.value,
                package.revision,
                package.content_hash,
                self._encode_package(package),
                self._timestamp(package.created_at),
            ),
        )

    @staticmethod
    def _has_non_retracted_descendant(
        connection: sqlite3.Connection,
        tenant_id: str,
        package_id: str,
    ) -> bool:
        rows = connection.execute(
            "SELECT package_id,previous_version_id,lifecycle FROM evidence_packages "
            "WHERE tenant_id=?",
            (tenant_id,),
        ).fetchall()
        children: dict[str, list[sqlite3.Row]] = {}
        for row in rows:
            previous_id = row["previous_version_id"]
            if previous_id:
                children.setdefault(str(previous_id), []).append(row)
        pending = list(children.get(package_id, ()))
        while pending:
            descendant = pending.pop()
            lifecycle = str(descendant["lifecycle"])
            if lifecycle == LifecycleStatus.RETRACTED.value:
                continue
            if lifecycle in {
                LifecycleStatus.RELEASED.value,
                LifecycleStatus.SUPERSEDED.value,
            }:
                return True
            pending.extend(children.get(str(descendant["package_id"]), ()))
        return False

    def _assert_active_ancestry(
        self,
        connection: sqlite3.Connection,
        package: EvidencePackageVersion,
    ) -> None:
        previous_id = package.previous_version_id
        first = True
        seen = {package.package_id}
        while previous_id is not None:
            if previous_id in seen:
                raise IntegrityError("evidence lineage contains a cycle")
            seen.add(previous_id)
            ancestor = self._get(connection, package.tenant_id, previous_id)
            if ancestor.lifecycle is LifecycleStatus.RETRACTED:
                raise IntegrityError(
                    "evidence lineage was terminated by an ancestor retraction"
                )
            if first:
                expected_parent = (
                    LifecycleStatus.RELEASED
                    if package.lifecycle in {LifecycleStatus.DRAFT, LifecycleStatus.LOCKED}
                    else LifecycleStatus.SUPERSEDED
                )
                if ancestor.lifecycle is not expected_parent:
                    raise IntegrityError(
                        "evidence package is not on the current replacement branch"
                    )
                first = False
            previous_id = ancestor.previous_version_id

    def _get(
        self, connection: sqlite3.Connection, tenant_id: str, package_id: str
    ) -> EvidencePackageVersion:
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        package_id = normalize_identity(package_id, "package_id")
        row = connection.execute(
            "SELECT lifecycle,revision,content_hash,payload_json FROM evidence_packages "
            "WHERE tenant_id=? AND package_id=?",
            (tenant_id, package_id),
        ).fetchone()
        if row is None:
            raise NotFoundError("evidence package not found")
        payload_json = str(row["payload_json"])
        if not self._verify_audit_chain(connection, tenant_id):
            raise IntegrityError("evidence audit chain failed integrity verification")
        expected_payload_hash, expected_revision = self._audit_package_state(
            connection,
            tenant_id,
            package_id,
        )
        payload_hash = sha256_hex(payload_json.encode("utf-8"))
        if (
            expected_payload_hash is None
            or not hmac.compare_digest(expected_payload_hash, payload_hash)
            or expected_revision != int(row["revision"])
        ):
            raise IntegrityError(
                "evidence payload does not match its audited revision state"
            )
        try:
            payload_data = json.loads(payload_json)
        except (TypeError, ValueError) as exc:
            raise IntegrityError("evidence payload is not valid JSON") from exc
        package = evidence_package_from_dict(payload_data)
        if (
            package.lifecycle.value != row["lifecycle"]
            or package.revision != row["revision"]
            or package.content_hash != row["content_hash"]
        ):
            raise IntegrityError("evidence lifecycle projection does not match stored columns")
        expected_lifecycle = self._audit_lifecycle(connection, tenant_id, package_id)
        if expected_lifecycle is not None and package.lifecycle.value != expected_lifecycle:
            raise IntegrityError("evidence lifecycle projection does not match the audit chain")
        if package.lifecycle is not LifecycleStatus.DRAFT:
            calculated = calculate_content_hash(payload_data)
            if not hmac.compare_digest(calculated, package.content_hash):
                raise IntegrityError("evidence content hash does not match stored payload")
        return package

    @staticmethod
    def _audit_lifecycle(
        connection: sqlite3.Connection,
        tenant_id: str,
        package_id: str,
    ) -> Optional[str]:
        rows = connection.execute(
            "SELECT action FROM evidence_audit_events "
            "WHERE tenant_id=? AND package_id=? ORDER BY sequence",
            (tenant_id, package_id),
        ).fetchall()
        lifecycle = None
        transitions = {
            "package.created": "draft",
            "package.revision_created": "draft",
            "package.locked": "locked",
            "package.released": "released",
            "package.superseded": "superseded",
            "package.retracted": "retracted",
        }
        for row in rows:
            lifecycle = transitions.get(row["action"], lifecycle)
        return lifecycle

    @staticmethod
    def _audit_package_state(
        connection: sqlite3.Connection,
        tenant_id: str,
        package_id: str,
    ) -> tuple[Optional[str], Optional[int]]:
        rows = connection.execute(
            "SELECT detail_json FROM evidence_audit_events "
            "WHERE tenant_id=? AND package_id=? ORDER BY sequence",
            (tenant_id, package_id),
        ).fetchall()
        payload_hash: Optional[str] = None
        revision: Optional[int] = None
        for row in rows:
            detail = json.loads(row["detail_json"])
            if _PACKAGE_PAYLOAD_SHA256 in detail:
                payload_hash = str(detail[_PACKAGE_PAYLOAD_SHA256])
                revision = int(detail[_PACKAGE_REVISION])
        return payload_hash, revision

    @staticmethod
    def _audit_authorization_state(
        connection: sqlite3.Connection,
        tenant_id: str,
        authorization_id: str,
    ) -> Optional[str]:
        rows = connection.execute(
            "SELECT detail_json FROM evidence_audit_events "
            "WHERE tenant_id=? AND action IN ('calibration.authorized','calibration.consumed') "
            "ORDER BY sequence",
            (tenant_id,),
        ).fetchall()
        payload_hash: Optional[str] = None
        for row in rows:
            detail = json.loads(row["detail_json"])
            if detail.get("authorization_id") == authorization_id:
                value = detail.get(_AUTHORIZATION_PAYLOAD_SHA256)
                payload_hash = str(value) if value else None
        return payload_hash

    def _verify_audit_chain(
        self,
        connection: sqlite3.Connection,
        tenant_id: str,
    ) -> bool:
        rows = connection.execute(
            "SELECT * FROM evidence_audit_events WHERE tenant_id=? ORDER BY sequence",
            (tenant_id,),
        ).fetchall()
        if not rows:
            package_exists = connection.execute(
                "SELECT 1 FROM evidence_packages WHERE tenant_id=? LIMIT 1",
                (tenant_id,),
            ).fetchone()
            return package_exists is None
        previous = "0" * 64
        for row in rows:
            if row["previous_event_hash"] != previous:
                return False
            key_version = str(row["key_version"] or "")
            verification_key = self._audit_verification_keys.get(key_version)
            if verification_key is None or not row["event_signature"]:
                return False
            event_payload = self._audit_hash_payload(row)
            payload_bytes = canonical_json_bytes(event_payload)
            calculated = sha256_hex(payload_bytes)
            if not hmac.compare_digest(calculated, str(row["event_hash"])):
                return False
            signature = hmac.new(
                verification_key,
                payload_bytes,
                hashlib.sha256,
            ).hexdigest()
            if not hmac.compare_digest(signature, str(row["event_signature"])):
                return False
            previous = calculated
        return True

    @classmethod
    def _package_state_detail(
        cls,
        package: EvidencePackageVersion,
        detail: Optional[Mapping[str, Any]] = None,
    ) -> dict[str, Any]:
        payload_json = cls._encode_package(package)
        result = dict(detail or {})
        result[_PACKAGE_PAYLOAD_SHA256] = sha256_hex(payload_json.encode("utf-8"))
        result[_PACKAGE_REVISION] = package.revision
        return result

    def _validate_authorization_package(
        self,
        connection: sqlite3.Connection,
        authorization: CalibrationAuthorization,
    ) -> EvidencePackageVersion:
        package = self._get(
            connection,
            authorization.tenant_id,
            authorization.package_id,
        )
        if package.lifecycle is not LifecycleStatus.RELEASED:
            raise IntegrityError(
                "calibration authorization requires the active released package"
            )
        if package.released_at is None or authorization.authorized_at < package.released_at:
            raise IntegrityError(
                "calibration authorization cannot precede evidence release"
            )
        self._assert_active_ancestry(connection, package)
        try:
            require_approved_policy(package.policy)
        except DomainValidationError as exc:
            raise IntegrityError("calibration authorization policy is no longer approved") from exc
        if not hmac.compare_digest(
            package.content_hash,
            authorization.package_content_hash,
        ):
            raise IntegrityError("calibration authorization package hash mismatch")
        if (
            authorization.policy_id != package.policy.policy_id
            or authorization.policy_hash != package.policy.canonical_hash
        ):
            raise IntegrityError("calibration authorization policy mismatch")
        prediction = next(
            (
                item
                for item in package.predictions
                if item.cendos_run_id == authorization.cendos_run_id
                and item.live_twin_id == authorization.live_twin_id
            ),
            None,
        )
        if prediction is None:
            raise IntegrityError("calibration authorization run or twin mismatch")
        event_ids = {event.event_id for event in package.validation_events}
        if not set(authorization.validation_event_ids).issubset(event_ids):
            raise IntegrityError("calibration authorization validation events mismatch")
        return package

    def _get_authorization(
        self, connection: sqlite3.Connection, tenant_id: str, authorization_id: str
    ) -> CalibrationAuthorization:
        row = connection.execute(
            "SELECT tenant_id,authorization_id,package_id,cendos_run_id,consumed,"
            "payload_json,payload_sha256 FROM calibration_authorizations "
            "WHERE tenant_id=? AND authorization_id=?",
            (tenant_id, authorization_id),
        ).fetchone()
        if row is None:
            raise NotFoundError("calibration authorization not found")
        payload_json = str(row["payload_json"])
        payload_sha256 = sha256_hex(payload_json.encode("utf-8"))
        if not row["payload_sha256"] or not hmac.compare_digest(
            str(row["payload_sha256"]), payload_sha256
        ):
            raise IntegrityError("calibration authorization payload hash mismatch")
        authorization = calibration_authorization_from_dict(json.loads(payload_json))
        if (
            authorization.tenant_id != row["tenant_id"]
            or authorization.authorization_id != row["authorization_id"]
            or authorization.package_id != row["package_id"]
            or authorization.cendos_run_id != row["cendos_run_id"]
            or int(authorization.consumed) != int(row["consumed"])
        ):
            raise IntegrityError(
                "calibration authorization projection does not match stored columns"
            )
        if not self._verify_audit_chain(connection, tenant_id):
            raise IntegrityError("evidence audit chain failed integrity verification")
        expected_hash = self._audit_authorization_state(
            connection,
            tenant_id,
            authorization_id,
        )
        if expected_hash is None or not hmac.compare_digest(expected_hash, payload_sha256):
            raise IntegrityError(
                "calibration authorization does not match its audited state"
            )
        return authorization

    @staticmethod
    def _encode_package(package: EvidencePackageVersion) -> str:
        return canonical_json_bytes(package).decode("utf-8")

    @staticmethod
    def _decode_package(payload: str) -> EvidencePackageVersion:
        return evidence_package_from_dict(json.loads(payload))

    def _append_audit(
        self,
        connection: sqlite3.Connection,
        tenant_id: str,
        package_id: str,
        action: str,
        actor: str,
        detail: Optional[Mapping[str, Any]] = None,
    ) -> None:
        previous_row = connection.execute(
            "SELECT event_hash FROM evidence_audit_events WHERE tenant_id=? ORDER BY sequence DESC LIMIT 1",
            (tenant_id,),
        ).fetchone()
        previous_hash = previous_row["event_hash"] if previous_row else "0" * 64
        event_id = f"audit-{uuid.uuid4().hex}"
        occurred_at = self._timestamp()
        safe_detail = dict(detail or {})
        safe_detail["audit_key_version"] = self.audit_key_version
        payload = {
            "event_id": event_id,
            "tenant_id": tenant_id,
            "package_id": package_id,
            "action": action,
            "actor": actor,
            "occurred_at": occurred_at,
            "detail": safe_detail,
            "previous_event_hash": previous_hash,
            "key_version": self.audit_key_version,
        }
        payload_bytes = canonical_json_bytes(payload)
        event_hash = sha256_hex(payload_bytes)
        event_signature = hmac.new(
            self._audit_signing_key,
            payload_bytes,
            hashlib.sha256,
        ).hexdigest()
        connection.execute(
            "INSERT INTO evidence_audit_events "
            "(event_id,tenant_id,package_id,action,actor,occurred_at,detail_json,"
            "previous_event_hash,event_hash,key_version,event_signature) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (
                event_id,
                tenant_id,
                package_id,
                action,
                actor,
                occurred_at,
                canonical_json_bytes(safe_detail).decode("utf-8"),
                previous_hash,
                event_hash,
                self.audit_key_version,
                event_signature,
            ),
        )

    @staticmethod
    def _audit_hash_payload(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "event_id": row["event_id"],
            "tenant_id": row["tenant_id"],
            "package_id": row["package_id"],
            "action": row["action"],
            "actor": row["actor"],
            "occurred_at": row["occurred_at"],
            "detail": json.loads(row["detail_json"]),
            "previous_event_hash": row["previous_event_hash"],
            "key_version": row["key_version"],
        }

    @staticmethod
    def _audit_row(row: sqlite3.Row) -> dict[str, Any]:
        result = dict(row)
        result["detail"] = json.loads(result.pop("detail_json"))
        return result

    @staticmethod
    def _timestamp(value: Optional[Any] = None) -> str:
        from .canonical import canonical_timestamp

        return canonical_timestamp(value or utc_now())

    @staticmethod
    def _idempotent_resource(
        connection: sqlite3.Connection,
        tenant_id: str,
        operation: str,
        idempotency_key: Optional[str],
        *,
        expected_resource_id: Optional[str],
        request_hash: str,
    ) -> Optional[str]:
        if not idempotency_key:
            return None
        tenant_id = normalize_identity(tenant_id, "tenant_id")
        if expected_resource_id is not None:
            expected_resource_id = normalize_identity(
                expected_resource_id, "expected_resource_id"
            )
        row = connection.execute(
            "SELECT resource_id,request_hash FROM evidence_idempotency "
            "WHERE tenant_id=? AND operation=? AND idempotency_key=?",
            (tenant_id, operation, idempotency_key),
        ).fetchone()
        if row is None:
            return None
        if (expected_resource_id is not None and row["resource_id"] != expected_resource_id) or not hmac.compare_digest(
            str(row["request_hash"]), request_hash
        ):
            raise ConflictError("idempotency key was reused for a different request")
        return row["resource_id"]

    def _record_idempotency(
        self,
        connection: sqlite3.Connection,
        tenant_id: str,
        operation: str,
        idempotency_key: Optional[str],
        resource_id: str,
        request_hash: str,
        result_hash: str,
    ) -> None:
        if not idempotency_key:
            return
        try:
            connection.execute(
                "INSERT INTO evidence_idempotency "
                "(tenant_id,operation,idempotency_key,resource_id,request_hash,result_hash,created_at) "
                "VALUES(?,?,?,?,?,?,?)",
                (
                    tenant_id, operation, idempotency_key, resource_id,
                    request_hash, result_hash, self._timestamp(),
                ),
            )
        except sqlite3.IntegrityError as exc:
            raise ConflictError("idempotency key was already used") from exc
