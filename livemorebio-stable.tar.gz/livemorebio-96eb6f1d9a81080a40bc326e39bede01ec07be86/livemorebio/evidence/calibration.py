"""Shared typed registry for evidence-authorized twin calibration parameters."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from types import MappingProxyType


@dataclass(frozen=True)
class CalibrationParameterSpec:
    container: str
    unit: str
    minimum: Decimal
    maximum: Decimal


CALIBRATION_PARAMETERS = MappingProxyType(
    {
        "hba1c": CalibrationParameterSpec("profile", "%", Decimal("0"), Decimal("20")),
        "ldl": CalibrationParameterSpec(
            "profile", "mg/dL", Decimal("0"), Decimal("500")
        ),
        "inflammation": CalibrationParameterSpec(
            "profile", "fraction", Decimal("0"), Decimal("1")
        ),
        "compound_strength": CalibrationParameterSpec(
            "profile", "fraction", Decimal("0"), Decimal("1")
        ),
        "plaque": CalibrationParameterSpec(
            "progression", "fraction", Decimal("0"), Decimal("1")
        ),
        "tumor": CalibrationParameterSpec(
            "progression", "fraction", Decimal("0"), Decimal("1")
        ),
        "senescence": CalibrationParameterSpec(
            "progression", "fraction", Decimal("0"), Decimal("1")
        ),
    }
)
