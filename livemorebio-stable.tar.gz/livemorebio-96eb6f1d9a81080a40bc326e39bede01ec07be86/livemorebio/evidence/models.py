"""Immutable, policy-bound records for Livemore evidence packages."""
from __future__ import annotations

import hmac
import json
import re
import unicodedata
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from enum import Enum
from typing import Any, Iterable, Mapping, Optional

from .canonical import canonical_hash, canonical_json_bytes, content_hash
from .errors import DomainValidationError, IntegrityError


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _required(value: str, field_name: str) -> str:
    # Canonical JSON is NFC-normalized. Normalize the in-memory domain value at
    # construction time as well so database keys and signed payloads cannot
    # disagree about the identity of the same Unicode string.
    value = unicodedata.normalize("NFC", str(value)).strip()
    if not value:
        raise DomainValidationError(f"{field_name} is required")
    if any(ord(character) < 32 or ord(character) == 127 for character in value) or any(
        character in value for character in ("\u2028", "\u2029")
    ):
        raise DomainValidationError(f"{field_name} contains control characters")
    return value


def normalize_identity(value: str, field_name: str = "identity") -> str:
    """Return the same NFC identity representation used by signed domain records."""

    return _required(value, field_name)


def _tuple(value: Iterable[Any]) -> tuple[Any, ...]:
    return tuple(value)


def _identity_tuple(values: Iterable[str], field_name: str) -> tuple[str, ...]:
    normalized = tuple(_required(value, field_name) for value in values)
    if len(normalized) != len(set(normalized)):
        raise DomainValidationError(f"{field_name} values must be unique")
    return normalized


def _decimal(value: Decimal | str | int, field_name: str) -> Decimal:
    try:
        result = value if isinstance(value, Decimal) else Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise DomainValidationError(f"{field_name} must be a decimal") from exc
    if not result.is_finite():
        raise DomainValidationError(f"{field_name} cannot be NaN or infinity")
    return result


def _timestamp(value: datetime, field_name: str) -> datetime:
    if value.tzinfo is None or value.utcoffset() is None:
        raise DomainValidationError(f"{field_name} must be timezone-aware")
    normalized = value.astimezone(timezone.utc)
    return normalized.replace(microsecond=(normalized.microsecond // 1000) * 1000)


def _sha256(value: str, field_name: str) -> str:
    normalized = _required(value, field_name).lower()
    if len(normalized) != 64 or any(character not in "0123456789abcdef" for character in normalized):
        raise DomainValidationError(f"{field_name} must be a SHA-256 hex digest")
    return normalized


class SourceDataClass(str, Enum):
    SYNTHETIC = "synthetic"
    REAL_HUMAN = "real_human"
    QUALIFIED_LAB = "qualified_lab"
    INFERRED = "inferred"
    MODELED = "modeled"


class MeasurementRole(str, Enum):
    BASELINE_INPUT = "baseline_input"
    COUNTERPART_OUTCOME = "counterpart_outcome"


class AssessmentStatus(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    PARTIAL = "partial"
    NOT_ASSESSED = "not_assessed"


class ValidationDimension(str, Enum):
    SOFTWARE_VERIFICATION = "software_verification"
    DEVICE_ANALYTICAL_VALIDITY = "device_analytical_validity"
    ASSAY_VALIDITY = "assay_validity"
    MODEL_VERIFICATION = "model_verification"
    BIOLOGICAL_CONCORDANCE = "biological_concordance"
    CLINICAL_APPLICABILITY = "clinical_applicability"
    EXTERNAL_REPLICATION = "external_replication"
    REGULATORY_DETERMINATION = "regulatory_determination"


class ClaimState(str, Enum):
    SYNTHETIC = "synthetic"
    MODELED = "modeled"
    CALIBRATED = "calibrated"
    VALIDATED = "validated"
    REPLICATED = "replicated"


SAFE_OUTWARD_CLAIMS = {
    ClaimState.SYNTHETIC: (
        "Synthetic research record; not validated for safety, efficacy, clinical use, "
        "or regulatory decisions."
    ),
    ClaimState.MODELED: (
        "Model-only research output; not validated for safety, efficacy, clinical use, "
        "or regulatory decisions."
    ),
    ClaimState.CALIBRATED: (
        "Calibrated research output for the recorded context only; not validated for "
        "safety, efficacy, clinical use, or regulatory decisions."
    ),
    ClaimState.VALIDATED: (
        "Validated only for the recorded context of use; this does not establish safety, "
        "efficacy, clinical utility, or regulatory acceptance."
    ),
    ClaimState.REPLICATED: (
        "Externally replicated only for the recorded context of use; this does not "
        "establish safety, efficacy, clinical utility, or regulatory acceptance."
    ),
}


def _validate_narrative(value: str, field_name: str) -> str:
    """Validate stored-only free text; it is never used as an outward claim.

    Semantic safety is enforced structurally at export: outward claims come
    from ``SAFE_OUTWARD_CLAIMS`` and other free text is omitted from Markdown
    and FHIR narratives. Keyword blacklists are bypassable and also reject
    accurate negated limitations, so this boundary enforces controls and size.
    """

    value = _required(value, field_name)
    if len(value) > 4096:
        raise DomainValidationError(f"{field_name} exceeds the stored narrative length limit")
    return value


def _narrative_tuple(values: Iterable[str], field_name: str) -> tuple[str, ...]:
    return tuple(_validate_narrative(value, field_name) for value in values)


def _structured_token(value: str, field_name: str) -> str:
    """Require a machine-readable token for fields rendered in outward tables."""

    value = _required(value, field_name)
    if not re.fullmatch(r"[A-Za-z0-9%][A-Za-z0-9_.:/%+\-]{0,127}", value):
        raise DomainValidationError(f"{field_name} must be a structured token")
    return value


@dataclass(frozen=True)
class ValidationAssessment:
    dimension: ValidationDimension
    status: AssessmentStatus
    basis: str


class LifecycleStatus(str, Enum):
    DRAFT = "draft"
    LOCKED = "locked"
    RELEASED = "released"
    RETRACTED = "retracted"
    SUPERSEDED = "superseded"


def _validate_outward_claim(claim: str, state: ClaimState) -> str:
    """Validate legacy claim input, then return the exact state-specific safe claim."""

    claim = _validate_narrative(claim, "claim")
    if claim not in SAFE_OUTWARD_CLAIMS.values() and state in {
        ClaimState.SYNTHETIC,
        ClaimState.MODELED,
    }:
        structured_token = r"[A-Za-z0-9%][A-Za-z0-9_.:/%+\-]{0,127}"
        legacy_fixture = re.fullmatch(
            rf"Model-only (?:{structured_token} ){{1,8}}response for research; not validated",
            claim,
        )
        legacy_runtime = re.fullmatch(
            rf"Model-only response of {structured_token} for {structured_token}; "
            r"research only and not validated for safety or efficacy",
            claim,
        )
        if legacy_fixture is None and legacy_runtime is None:
            raise DomainValidationError(
                "synthetic and modeled claims must use a registered safe claim template"
            )
    return SAFE_OUTWARD_CLAIMS[state]


@dataclass(frozen=True)
class PolicyVersion:
    policy_id: str
    version: str
    effective_at: datetime
    required_dimensions: tuple[ValidationDimension, ...]
    clinical_use: bool = False
    canonical_hash: str = field(init=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "policy_id", _required(self.policy_id, "policy_id"))
        object.__setattr__(self, "version", _required(self.version, "version"))
        object.__setattr__(self, "effective_at", _timestamp(self.effective_at, "effective_at"))
        object.__setattr__(self, "required_dimensions", _tuple(self.required_dimensions))
        if self.clinical_use and ValidationDimension.CLINICAL_APPLICABILITY not in self.required_dimensions:
            raise DomainValidationError("clinical-use policy must require clinical applicability")
        payload = {
            "policy_id": self.policy_id,
            "version": self.version,
            "effective_at": self.effective_at,
            "required_dimensions": self.required_dimensions,
            "clinical_use": self.clinical_use,
        }
        object.__setattr__(self, "canonical_hash", canonical_hash(payload))


@dataclass(frozen=True)
class ContextOfUse:
    context_id: str
    question_of_interest: str
    intended_decision: str
    decision_owner_role: str
    target_population: str
    model_system: str
    model_influence: str
    wrong_decision_consequence: str
    risk: str
    impact: str
    limitations: tuple[str, ...]
    required_dimensions: tuple[ValidationDimension, ...]
    policy_id: str
    policy_hash: str

    def __post_init__(self) -> None:
        for name in ("context_id", "policy_id", "policy_hash"):
            object.__setattr__(self, name, _required(getattr(self, name), name))
        for name in (
            "question_of_interest",
            "intended_decision",
            "target_population",
            "model_system",
            "model_influence",
            "wrong_decision_consequence",
            "risk",
            "impact",
        ):
            object.__setattr__(self, name, _validate_narrative(getattr(self, name), name))
        object.__setattr__(
            self,
            "decision_owner_role",
            _structured_token(self.decision_owner_role, "decision_owner_role"),
        )
        object.__setattr__(
            self,
            "limitations",
            _narrative_tuple(self.limitations, "context limitation"),
        )
        object.__setattr__(self, "required_dimensions", _tuple(self.required_dimensions))


@dataclass(frozen=True)
class ProtocolVersion:
    protocol_id: str
    version: str
    objective: str
    hypothesis: str
    candidate: str
    target: str
    assay: str
    dose: str
    duration: str
    controls: tuple[str, ...]
    endpoints: tuple[str, ...]
    acceptance_criteria: tuple[str, ...]
    statistical_plan: str
    approval_status: str
    approved_at: Optional[datetime] = None
    approved_by: Optional[str] = None
    approval_role: Optional[str] = None
    approval_reference: Optional[str] = None
    deviations: tuple[str, ...] = ()
    sop_references: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        for name in ("protocol_id", "version", "approval_status"):
            object.__setattr__(self, name, _required(getattr(self, name), name))
        for name in (
            "objective",
            "hypothesis",
            "candidate",
            "target",
            "assay",
            "dose",
            "duration",
            "statistical_plan",
        ):
            object.__setattr__(self, name, _validate_narrative(getattr(self, name), name))
        for name in (
            "controls",
            "endpoints",
            "acceptance_criteria",
            "deviations",
            "sop_references",
        ):
            object.__setattr__(
                self,
                name,
                _narrative_tuple(getattr(self, name), f"protocol {name}"),
            )
        if len(self.endpoints) != len(set(self.endpoints)):
            raise DomainValidationError("protocol endpoints must be unique")
        if len(self.acceptance_criteria) != len(set(self.acceptance_criteria)):
            raise DomainValidationError("protocol acceptance criteria must be unique")
        if self.approved_at is not None:
            object.__setattr__(self, "approved_at", _timestamp(self.approved_at, "approved_at"))
        if self.approval_status == "approved":
            if (
                self.approved_at is None
                or not self.approved_by
                or not self.approval_role
                or not self.approval_reference
            ):
                raise DomainValidationError(
                    "approved protocol requires timestamp, approver, role, and approval reference"
                )
            object.__setattr__(self, "approved_by", _required(self.approved_by, "approved_by"))
            object.__setattr__(self, "approval_role", _required(self.approval_role, "approval_role"))
            object.__setattr__(
                self,
                "approval_reference",
                _required(self.approval_reference, "approval_reference"),
            )
        elif any((self.approved_at, self.approved_by, self.approval_role, self.approval_reference)):
            raise DomainValidationError(
                "non-approved protocol cannot carry approval authority fields"
            )
        if not self.endpoints or not self.acceptance_criteria:
            raise DomainValidationError("protocol endpoints and acceptance criteria are required")


@dataclass(frozen=True)
class NamedValue:
    name: str
    value: Decimal
    unit: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "name", _structured_token(self.name, "name"))
        object.__setattr__(self, "value", _decimal(self.value, "value"))
        object.__setattr__(self, "unit", _structured_token(self.unit, "unit"))


@dataclass(frozen=True)
class CounterpartMeasurement:
    endpoint: str
    value: Decimal
    unit: str
    source_data_class: SourceDataClass
    measured_at: datetime
    quality_status: AssessmentStatus
    calibration_status: AssessmentStatus
    consent_scope: tuple[str, ...]
    device_id: str
    instrument_id: str
    method: str
    chain_of_custody: tuple[str, ...]

    def __post_init__(self) -> None:
        for name in ("device_id", "instrument_id"):
            object.__setattr__(self, name, _required(getattr(self, name), name))
        for name in ("endpoint", "unit"):
            object.__setattr__(self, name, _structured_token(getattr(self, name), name))
        object.__setattr__(self, "method", _validate_narrative(self.method, "method"))
        object.__setattr__(self, "value", _decimal(self.value, "value"))
        object.__setattr__(self, "measured_at", _timestamp(self.measured_at, "measured_at"))
        object.__setattr__(
            self,
            "consent_scope",
            _narrative_tuple(self.consent_scope, "consent scope"),
        )
        object.__setattr__(
            self,
            "chain_of_custody",
            _narrative_tuple(self.chain_of_custody, "chain of custody"),
        )


@dataclass(frozen=True)
class MeasurementEnvelope:
    schema_version: str
    envelope_id: str
    tenant_id: str
    counterpart_id: str
    role: MeasurementRole
    subject_pseudonymized: bool
    sequence: int
    received_at: datetime
    payload: CounterpartMeasurement
    source_hash: str = ""

    def __post_init__(self) -> None:
        for name in ("schema_version", "envelope_id", "tenant_id", "counterpart_id"):
            object.__setattr__(self, name, _required(getattr(self, name), name))
        if self.sequence < 0:
            raise DomainValidationError("measurement sequence must be non-negative")
        object.__setattr__(self, "received_at", _timestamp(self.received_at, "received_at"))
        if self.received_at < self.payload.measured_at:
            raise DomainValidationError("measurement cannot be received before it was measured")
        calculated_hash = canonical_hash(
            {
                "schema_version": self.schema_version,
                "envelope_id": self.envelope_id,
                "tenant_id": self.tenant_id,
                "counterpart_id": self.counterpart_id,
                "role": self.role,
                "subject_pseudonymized": self.subject_pseudonymized,
                "sequence": self.sequence,
                "received_at": self.received_at,
                "payload": self.payload,
            }
        )
        if self.source_hash and not hmac.compare_digest(self.source_hash, calculated_hash):
            raise IntegrityError("measurement source hash does not match its payload")
        if self.payload.source_data_class in {
            SourceDataClass.REAL_HUMAN,
            SourceDataClass.QUALIFIED_LAB,
        }:
            if not self.payload.consent_scope:
                raise DomainValidationError("non-synthetic measurements require explicit consent scope")
            if not self.subject_pseudonymized:
                raise DomainValidationError("non-synthetic measurement subjects must be pseudonymized")
        object.__setattr__(self, "source_hash", calculated_hash)


@dataclass(frozen=True)
class ScenarioSnapshot:
    snapshot_id: str
    twin_id: str
    captured_at: datetime
    measurement_ids: tuple[str, ...]
    measurement_hashes: tuple[str, ...]
    model_inputs: tuple[NamedValue, ...]
    code_version: str
    model_versions: tuple[str, ...]
    dataset_versions: tuple[str, ...]
    model_state_json: str = ""
    model_state_hash: str = ""
    state_hash: str = ""

    def __post_init__(self) -> None:
        for name in ("snapshot_id", "twin_id", "code_version"):
            object.__setattr__(self, name, _required(getattr(self, name), name))
        for name in (
            "measurement_ids",
            "measurement_hashes",
            "model_inputs",
            "model_versions",
            "dataset_versions",
        ):
            object.__setattr__(self, name, _tuple(getattr(self, name)))
        object.__setattr__(
            self,
            "model_versions",
            _identity_tuple(self.model_versions, "scenario model version"),
        )
        object.__setattr__(
            self,
            "dataset_versions",
            _identity_tuple(self.dataset_versions, "scenario dataset version"),
        )
        object.__setattr__(
            self,
            "measurement_hashes",
            tuple(_sha256(value, "scenario measurement hash") for value in self.measurement_hashes),
        )
        object.__setattr__(self, "captured_at", _timestamp(self.captured_at, "captured_at"))
        if not self.model_versions:
            raise DomainValidationError("scenario snapshot requires a model version")
        if not self.model_inputs:
            raise DomainValidationError("scenario snapshot requires reconstructive model inputs")
        model_input_names = tuple(model_input.name for model_input in self.model_inputs)
        if len(model_input_names) != len(set(model_input_names)):
            raise DomainValidationError("scenario model-input names must be unique")
        if not self.dataset_versions:
            raise DomainValidationError("scenario snapshot requires dataset versions")
        unresolved = {"unknown", "unknown-local", "unassigned", "none", "n/a"}
        if self.code_version.strip().lower() in unresolved:
            raise DomainValidationError("scenario snapshot requires a resolvable code version")
        if len(self.measurement_ids) != len(self.measurement_hashes):
            raise DomainValidationError("scenario measurement IDs and hashes must have equal length")
        if len(set(self.measurement_ids)) != len(self.measurement_ids):
            raise DomainValidationError("scenario measurement IDs must be unique")
        model_state_json = str(self.model_state_json)
        model_state_hash = str(self.model_state_hash)
        if bool(model_state_json) != bool(model_state_hash):
            raise DomainValidationError(
                "scenario model-state JSON and hash must be provided together"
            )
        if model_state_json:
            if len(model_state_json.encode("utf-8")) > 1_000_000:
                raise DomainValidationError("scenario model-state JSON exceeds 1 MB")

            def reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
                value: dict[str, Any] = {}
                for key, item in pairs:
                    if key in value:
                        raise DomainValidationError(
                            "scenario model-state JSON contains a duplicate key"
                        )
                    value[key] = item
                return value

            def reject_non_finite_number(_value: str) -> None:
                raise DomainValidationError(
                    "scenario model-state JSON contains a non-finite number"
                )

            try:
                parsed_state = json.loads(
                    model_state_json,
                    object_pairs_hook=reject_duplicate_keys,
                    parse_constant=reject_non_finite_number,
                )
            except json.JSONDecodeError as error:
                raise DomainValidationError(
                    "scenario model-state JSON is invalid"
                ) from error
            if not isinstance(parsed_state, dict):
                raise DomainValidationError("scenario model-state JSON must be an object")
            canonical_state_json = canonical_json_bytes(parsed_state).decode("utf-8")
            if not hmac.compare_digest(model_state_json, canonical_state_json):
                raise DomainValidationError(
                    "scenario model-state JSON must use canonical encoding"
                )
            calculated_model_state_hash = canonical_hash(parsed_state)
            normalized_model_state_hash = _sha256(
                model_state_hash,
                "scenario model-state hash",
            )
            if not hmac.compare_digest(
                normalized_model_state_hash,
                calculated_model_state_hash,
            ):
                raise IntegrityError(
                    "scenario model-state hash does not match its canonical state"
                )
            object.__setattr__(self, "model_state_json", canonical_state_json)
            object.__setattr__(
                self,
                "model_state_hash",
                calculated_model_state_hash,
            )
        payload = {
            "snapshot_id": self.snapshot_id,
            "twin_id": self.twin_id,
            "captured_at": self.captured_at,
            "measurement_ids": self.measurement_ids,
            "measurement_hashes": self.measurement_hashes,
            "model_inputs": self.model_inputs,
            "code_version": self.code_version,
            "model_versions": self.model_versions,
            "dataset_versions": self.dataset_versions,
            "model_state_json": self.model_state_json,
            "model_state_hash": self.model_state_hash,
        }
        calculated_hash = canonical_hash(payload)
        if self.state_hash and not hmac.compare_digest(self.state_hash, calculated_hash):
            raise IntegrityError("scenario state hash does not match its payload")
        object.__setattr__(self, "state_hash", calculated_hash)


@dataclass(frozen=True)
class PredictionValue:
    endpoint: str
    value: Decimal
    unit: str
    lower: Decimal
    upper: Decimal
    confidence: Decimal

    def __post_init__(self) -> None:
        object.__setattr__(self, "endpoint", _structured_token(self.endpoint, "endpoint"))
        object.__setattr__(self, "unit", _structured_token(self.unit, "unit"))
        for name in ("value", "lower", "upper", "confidence"):
            object.__setattr__(self, name, _decimal(getattr(self, name), name))
        if self.lower > self.upper:
            raise DomainValidationError("prediction interval lower bound exceeds upper bound")
        if not self.lower <= self.value <= self.upper:
            raise DomainValidationError("prediction value must lie inside its recorded interval")
        if not Decimal("0") <= self.confidence <= Decimal("1"):
            raise DomainValidationError("prediction confidence must be between 0 and 1")


@dataclass(frozen=True)
class PredictionRun:
    prediction_id: str
    live_twin_id: str
    scenario_snapshot: ScenarioSnapshot
    cendos_run_id: str
    protocol_hash: str
    input_measurement_ids: tuple[str, ...]
    model_versions: tuple[str, ...]
    code_version: str
    dataset_versions: tuple[str, ...]
    container_digest: str
    deterministic_seed: int
    outputs: tuple[PredictionValue, ...]
    assumptions: tuple[str, ...]
    limitations: tuple[str, ...]
    actor_id: str
    generated_at: datetime
    input_hash: str = ""

    def __post_init__(self) -> None:
        for name in (
            "prediction_id", "live_twin_id", "cendos_run_id", "code_version", "container_digest",
            "actor_id",
        ):
            object.__setattr__(self, name, _required(getattr(self, name), name))
        object.__setattr__(self, "protocol_hash", _sha256(self.protocol_hash, "protocol_hash"))
        for name in (
            "input_measurement_ids", "model_versions", "dataset_versions", "outputs", "assumptions",
            "limitations",
        ):
            object.__setattr__(self, name, _tuple(getattr(self, name)))
        object.__setattr__(
            self,
            "model_versions",
            _identity_tuple(self.model_versions, "prediction model version"),
        )
        object.__setattr__(
            self,
            "dataset_versions",
            _identity_tuple(self.dataset_versions, "prediction dataset version"),
        )
        object.__setattr__(
            self,
            "assumptions",
            _narrative_tuple(self.assumptions, "prediction assumption"),
        )
        object.__setattr__(
            self,
            "limitations",
            _narrative_tuple(self.limitations, "prediction limitation"),
        )
        if not self.outputs or not self.model_versions or not self.dataset_versions:
            raise DomainValidationError(
                "prediction outputs, model versions, and dataset versions are required"
            )
        if len(self.input_measurement_ids) != len(set(self.input_measurement_ids)):
            raise DomainValidationError("prediction input measurement IDs must be unique")
        unresolved = {"unknown", "unknown-local", "unassigned", "none", "n/a"}
        if self.code_version.strip().lower() in unresolved:
            raise DomainValidationError("prediction requires a resolvable code version")
        if self.container_digest.strip().lower() in unresolved:
            raise DomainValidationError("prediction requires a recorded execution environment identity")
        output_keys = tuple((output.endpoint, output.unit) for output in self.outputs)
        if len(output_keys) != len(set(output_keys)):
            raise DomainValidationError("prediction endpoint and unit pairs must be unique")
        object.__setattr__(self, "generated_at", _timestamp(self.generated_at, "generated_at"))
        if self.scenario_snapshot.twin_id != self.live_twin_id:
            raise DomainValidationError("prediction twin does not match scenario snapshot twin")
        if self.generated_at < self.scenario_snapshot.captured_at:
            raise DomainValidationError("prediction cannot predate its scenario snapshot")
        payload = {
            "scenario_snapshot_id": self.scenario_snapshot.snapshot_id,
            "scenario_state_hash": self.scenario_snapshot.state_hash,
            "protocol_hash": self.protocol_hash,
            "input_measurement_ids": self.input_measurement_ids,
            "model_versions": self.model_versions,
            "code_version": self.code_version,
            "dataset_versions": self.dataset_versions,
            "container_digest": self.container_digest,
            "deterministic_seed": self.deterministic_seed,
        }
        calculated_hash = canonical_hash(payload)
        if self.input_hash and not hmac.compare_digest(self.input_hash, calculated_hash):
            raise IntegrityError("prediction input hash does not match its payload")
        object.__setattr__(self, "input_hash", calculated_hash)


@dataclass(frozen=True)
class ModelVerificationRecord:
    """Bound software verification or attestation, never biological validity."""

    verification_id: str
    prediction_id: str
    prediction_hash: str
    disposition: AssessmentStatus
    scope: str
    method: str
    evidence_hashes: tuple[str, ...]
    verifier_id: str
    verifier_role: str
    verified_at: datetime
    policy_id: str
    policy_hash: str

    def __post_init__(self) -> None:
        for name in (
            "verification_id",
            "prediction_id",
            "verifier_id",
            "policy_id",
            "policy_hash",
        ):
            object.__setattr__(self, name, _required(getattr(self, name), name))
        for name in ("scope", "method"):
            object.__setattr__(self, name, _validate_narrative(getattr(self, name), name))
        object.__setattr__(
            self,
            "verifier_role",
            _structured_token(self.verifier_role, "verifier_role"),
        )
        object.__setattr__(
            self,
            "evidence_hashes",
            tuple(_sha256(value, "verification evidence hash") for value in self.evidence_hashes),
        )
        object.__setattr__(self, "prediction_hash", _sha256(self.prediction_hash, "prediction_hash"))
        object.__setattr__(self, "verified_at", _timestamp(self.verified_at, "verified_at"))
        if self.disposition is AssessmentStatus.PASS and not self.evidence_hashes:
            raise DomainValidationError("passing model verification requires evidence hashes")


@dataclass(frozen=True)
class ValidationEvent:
    event_id: str
    prediction_id: str
    measurement_envelope_id: str
    dimension: ValidationDimension
    endpoint: str
    unit: str
    time_window: str
    acceptance_criterion: str
    metric_name: str
    metric_value: Decimal
    disposition: AssessmentStatus
    endpoint_compatible: bool
    unit_compatible: bool
    time_window_compatible: bool
    quality_passed: bool
    protocol_criterion_passed: bool
    source_data_class: SourceDataClass
    reviewer_id: str
    reviewer_role: str
    reviewed_at: datetime
    policy_id: str
    policy_hash: str
    analysis_hash: str
    independent: bool = False
    independent_site: Optional[str] = None

    def __post_init__(self) -> None:
        for name in (
            "event_id", "prediction_id", "measurement_envelope_id", "reviewer_id", "policy_id",
            "policy_hash",
        ):
            object.__setattr__(self, name, _required(getattr(self, name), name))
        for name in (
            "time_window",
            "acceptance_criterion",
        ):
            object.__setattr__(self, name, _validate_narrative(getattr(self, name), name))
        for name in ("endpoint", "unit", "metric_name", "reviewer_role"):
            object.__setattr__(self, name, _structured_token(getattr(self, name), name))
        if self.independent_site is not None:
            object.__setattr__(
                self,
                "independent_site",
                _validate_narrative(self.independent_site, "independent_site"),
            )
        object.__setattr__(self, "metric_value", _decimal(self.metric_value, "metric_value"))
        object.__setattr__(self, "reviewed_at", _timestamp(self.reviewed_at, "reviewed_at"))
        object.__setattr__(self, "analysis_hash", _sha256(self.analysis_hash, "analysis_hash"))
        if self.dimension not in {
            ValidationDimension.BIOLOGICAL_CONCORDANCE,
            ValidationDimension.EXTERNAL_REPLICATION,
        }:
            raise DomainValidationError(
                "counterpart validation events support biological concordance or external replication only"
            )
        if self.dimension is ValidationDimension.EXTERNAL_REPLICATION and not self.independent:
            raise DomainValidationError("external replication requires an independent site or method")
        if self.independent and not self.independent_site:
            raise DomainValidationError("independent validation requires an independent site or method")


def validation_analysis_hash(
    prediction: PredictionRun,
    measurement: MeasurementEnvelope,
    event: ValidationEvent,
) -> str:
    return canonical_hash(
        {
            "schema_version": "livemore.validation-analysis.v1",
            "prediction_hash": canonical_hash(prediction),
            "measurement_source_hash": measurement.source_hash,
            "dimension": event.dimension,
            "endpoint": event.endpoint,
            "unit": event.unit,
            "time_window": event.time_window,
            "acceptance_criterion": event.acceptance_criterion,
            "metric_name": event.metric_name,
            "metric_value": event.metric_value,
            "disposition": event.disposition,
            "protocol_criterion_passed": event.protocol_criterion_passed,
        }
    )


@dataclass(frozen=True)
class Provenance:
    source_ids: tuple[str, ...]
    transformations: tuple[str, ...]
    model_versions: tuple[str, ...]
    code_commit: str
    environment: str
    content_hashes: tuple[str, ...]
    correlation_ids: tuple[str, ...]

    def __post_init__(self) -> None:
        object.__setattr__(self, "code_commit", _required(self.code_commit, "code_commit"))
        object.__setattr__(self, "environment", _required(self.environment, "environment"))
        object.__setattr__(
            self,
            "source_ids",
            _identity_tuple(self.source_ids, "provenance source ID"),
        )
        object.__setattr__(
            self,
            "transformations",
            _narrative_tuple(self.transformations, "provenance transformation"),
        )
        object.__setattr__(
            self,
            "model_versions",
            _identity_tuple(self.model_versions, "provenance model version"),
        )
        object.__setattr__(
            self,
            "content_hashes",
            tuple(_sha256(value, "provenance content hash") for value in self.content_hashes),
        )
        object.__setattr__(
            self,
            "correlation_ids",
            _identity_tuple(self.correlation_ids, "provenance correlation ID"),
        )


@dataclass(frozen=True)
class VisualizationMapping:
    """A rendering instruction whose evidence fields are package-validated.

    ``evidence_ref`` may name a measurement envelope, a single-output
    prediction, or a prediction output explicitly as
    ``<prediction_id>/output/<endpoint>``.  The package validator, not the
    caller, determines the corresponding endpoint, data class, and unit.
    """

    target_id: str
    variable: str
    evidence_ref: str
    data_class: str
    unit: str

    def __post_init__(self) -> None:
        for name in ("target_id", "variable", "evidence_ref", "unit"):
            object.__setattr__(self, name, _required(getattr(self, name), name))
        try:
            data_class = SourceDataClass(
                _required(self.data_class, "data_class")
            ).value
        except (TypeError, ValueError) as exc:
            raise DomainValidationError(
                "visualization data_class must be a registered source data class"
            ) from exc
        object.__setattr__(self, "data_class", data_class)


@dataclass(frozen=True)
class VisualizationManifest:
    manifest_id: str
    anatomy_asset_ids: tuple[str, ...]
    coordinate_system: str
    asset_version: str
    asset_license: str
    mappings: tuple[VisualizationMapping, ...]

    def __post_init__(self) -> None:
        for name in ("manifest_id", "coordinate_system", "asset_version", "asset_license"):
            object.__setattr__(self, name, _required(getattr(self, name), name))
        anatomy_asset_ids = tuple(
            _required(asset_id, "anatomy asset ID") for asset_id in self.anatomy_asset_ids
        )
        mappings = _tuple(self.mappings)
        if len(anatomy_asset_ids) != len(set(anatomy_asset_ids)):
            raise DomainValidationError("visualization anatomy asset IDs must be unique")
        if any(mapping.target_id not in anatomy_asset_ids for mapping in mappings):
            raise DomainValidationError(
                "visualization mapping target is not declared by the anatomy manifest"
            )
        object.__setattr__(self, "anatomy_asset_ids", anatomy_asset_ids)
        object.__setattr__(self, "mappings", mappings)


def _validate_visualization_evidence_bindings(
    manifest: VisualizationManifest,
    predictions: Mapping[str, PredictionRun],
    measurements: Mapping[str, MeasurementEnvelope],
) -> None:
    """Bind every visualization instruction to one unambiguous evidence value."""

    for mapping in manifest.mappings:
        bindings: list[tuple[str, SourceDataClass, str]] = []
        prediction = predictions.get(mapping.evidence_ref)
        if prediction is not None:
            if len(prediction.outputs) != 1:
                raise DomainValidationError(
                    "visualization prediction reference is ambiguous; reference a specific output"
                )
            output = prediction.outputs[0]
            bindings.append((output.endpoint, SourceDataClass.MODELED, output.unit))

        for candidate in predictions.values():
            for output in candidate.outputs:
                output_reference = (
                    f"{candidate.prediction_id}/output/{output.endpoint}"
                )
                if mapping.evidence_ref == output_reference:
                    bindings.append(
                        (output.endpoint, SourceDataClass.MODELED, output.unit)
                    )

        measurement = measurements.get(mapping.evidence_ref)
        if measurement is not None:
            bindings.append(
                (
                    measurement.payload.endpoint,
                    measurement.payload.source_data_class,
                    measurement.payload.unit,
                )
            )

        if not bindings:
            raise DomainValidationError(
                "visualization mapping references unknown package evidence"
            )
        if len(bindings) != 1:
            raise DomainValidationError(
                "visualization mapping evidence reference is ambiguous"
            )
        expected_endpoint, expected_data_class, expected_unit = bindings[0]
        if mapping.variable != expected_endpoint:
            raise DomainValidationError(
                "visualization mapping variable does not match referenced evidence endpoint"
            )
        if mapping.data_class != expected_data_class.value:
            raise DomainValidationError(
                "visualization mapping data class does not match referenced evidence"
            )
        if mapping.unit != expected_unit:
            raise DomainValidationError(
                "visualization mapping unit does not match referenced evidence"
            )


@dataclass(frozen=True)
class CalibrationAuthorization:
    authorization_id: str
    tenant_id: str
    package_id: str
    package_content_hash: str
    cendos_run_id: str
    live_twin_id: str
    validation_event_ids: tuple[str, ...]
    parameter_scope: tuple[str, ...]
    reviewer_id: str
    authorized_at: datetime
    policy_id: str
    policy_hash: str
    consumed: bool = False
    consumed_at: Optional[datetime] = None

    def __post_init__(self) -> None:
        for name in (
            "authorization_id", "tenant_id", "package_id", "package_content_hash", "cendos_run_id",
            "live_twin_id", "reviewer_id", "policy_id", "policy_hash",
        ):
            object.__setattr__(self, name, _required(getattr(self, name), name))
        object.__setattr__(self, "validation_event_ids", _tuple(self.validation_event_ids))
        object.__setattr__(self, "parameter_scope", _tuple(self.parameter_scope))
        object.__setattr__(self, "authorized_at", _timestamp(self.authorized_at, "authorized_at"))
        if self.consumed_at is not None:
            object.__setattr__(self, "consumed_at", _timestamp(self.consumed_at, "consumed_at"))
        if not self.validation_event_ids or not self.parameter_scope:
            raise DomainValidationError("authorization requires validation events and parameter scope")
        if self.consumed != (self.consumed_at is not None):
            raise DomainValidationError("authorization consumption state is inconsistent")
        if self.consumed_at is not None and self.consumed_at < self.authorized_at:
            raise DomainValidationError("authorization cannot be consumed before it is authorized")


def _eligible_event(event: ValidationEvent) -> bool:
    return (
        event.disposition is AssessmentStatus.PASS
        and _usable_counterpart_event(event)
        and event.protocol_criterion_passed
    )


def _usable_counterpart_event(event: ValidationEvent) -> bool:
    return (
        event.source_data_class in {SourceDataClass.REAL_HUMAN, SourceDataClass.QUALIFIED_LAB}
        and event.endpoint_compatible
        and event.unit_compatible
        and event.time_window_compatible
        and event.quality_passed
        and (
            event.dimension is not ValidationDimension.EXTERNAL_REPLICATION
            or event.independent
        )
    )


def _expected_validation_keys(
    predictions: tuple[PredictionRun, ...],
    measurements: tuple[MeasurementEnvelope, ...],
) -> set[tuple[str, str, str, str]]:
    """Require assessment of every declared output and every matching withheld outcome."""
    expected: set[tuple[str, str, str, str]] = set()
    for prediction in predictions:
        for output in prediction.outputs:
            outcomes = tuple(
                measurement
                for measurement in measurements
                if measurement.role is MeasurementRole.COUNTERPART_OUTCOME
                and measurement.counterpart_id == prediction.live_twin_id
                and measurement.payload.endpoint == output.endpoint
                and measurement.payload.unit == output.unit
                and measurement.payload.measured_at > prediction.generated_at
            )
            if outcomes:
                expected.update(
                    (
                        prediction.prediction_id,
                        output.endpoint,
                        output.unit,
                        measurement.envelope_id,
                    )
                    for measurement in outcomes
                )
            else:
                expected.add(
                    (prediction.prediction_id, output.endpoint, output.unit, "<missing-outcome>")
                )
    return expected


def compute_validation_summary(
    predictions: tuple[PredictionRun, ...],
    measurements: tuple[MeasurementEnvelope, ...],
    model_verifications: tuple[ModelVerificationRecord, ...],
    events: tuple[ValidationEvent, ...],
) -> tuple[ValidationAssessment, ...]:
    """Report every assessment dimension, including missing and ineligible evidence."""
    verification_by_prediction = {
        verification.prediction_id: verification for verification in model_verifications
    }
    model_records = tuple(
        verification_by_prediction.get(prediction.prediction_id) for prediction in predictions
    )
    if not predictions or any(record is None for record in model_records):
        model_status = AssessmentStatus.NOT_ASSESSED
        model_basis = "one or more predictions lack a model-verification record"
    elif any(record.disposition is AssessmentStatus.FAIL for record in model_records if record):
        model_status = AssessmentStatus.FAIL
        model_basis = "at least one model-verification record failed"
    elif all(record.disposition is AssessmentStatus.PASS for record in model_records if record):
        model_status = AssessmentStatus.PASS
        model_basis = "all predictions have bound passing model-verification attestations"
    else:
        model_status = AssessmentStatus.PARTIAL
        model_basis = "model verification is incomplete or partial"

    summary: list[ValidationAssessment] = []
    expected_keys = _expected_validation_keys(predictions, measurements)
    for dimension in ValidationDimension:
        if dimension is ValidationDimension.MODEL_VERIFICATION:
            summary.append(ValidationAssessment(dimension, model_status, model_basis))
            continue
        dimension_events = tuple(event for event in events if event.dimension is dimension)
        usable_events = tuple(event for event in dimension_events if _usable_counterpart_event(event))
        failed_keys = {
            (
                event.prediction_id,
                event.endpoint,
                event.unit,
                event.measurement_envelope_id,
            )
            for event in usable_events
            if event.disposition is AssessmentStatus.FAIL
            or not event.protocol_criterion_passed
        }
        passed_keys = {
            (
                event.prediction_id,
                event.endpoint,
                event.unit,
                event.measurement_envelope_id,
            )
            for event in usable_events
            if _eligible_event(event)
        }
        if failed_keys:
            status = AssessmentStatus.FAIL
            basis = "at least one usable prediction/endpoint assessment failed"
        elif expected_keys and expected_keys.issubset(passed_keys):
            status = AssessmentStatus.PASS
            basis = "every prediction endpoint and matching withheld outcome was assessed"
        elif dimension_events:
            status = AssessmentStatus.PARTIAL
            basis = "prediction/endpoint coverage is incomplete or not promotion-eligible"
        else:
            status = AssessmentStatus.NOT_ASSESSED
            basis = "no assessment record"
        summary.append(ValidationAssessment(dimension, status, basis))
    return tuple(summary)


def compute_claim_state(
    predictions: tuple[PredictionRun, ...],
    measurements: tuple[MeasurementEnvelope, ...],
    model_verifications: tuple[ModelVerificationRecord, ...],
    events: tuple[ValidationEvent, ...],
    required_dimensions: tuple[ValidationDimension, ...],
) -> ClaimState:
    """Conservatively derive the outward claim state; callers cannot assign it."""
    if not predictions:
        return ClaimState.SYNTHETIC
    passed_verifications = {
        verification.prediction_id
        for verification in model_verifications
        if verification.disposition is AssessmentStatus.PASS
    }
    if any(prediction.prediction_id not in passed_verifications for prediction in predictions):
        return ClaimState.SYNTHETIC
    state = ClaimState.MODELED
    summary = {
        assessment.dimension: assessment.status
        for assessment in compute_validation_summary(
            predictions,
            measurements,
            model_verifications,
            events,
        )
    }
    required = set(required_dimensions)
    if any(summary.get(dimension) is AssessmentStatus.FAIL for dimension in required):
        return state
    counterpart_complete = (
        summary.get(ValidationDimension.BIOLOGICAL_CONCORDANCE) is AssessmentStatus.PASS
        or summary.get(ValidationDimension.EXTERNAL_REPLICATION) is AssessmentStatus.PASS
    )
    if not counterpart_complete:
        return state
    state = ClaimState.CALIBRATED
    validated_floor = {
        ValidationDimension.MODEL_VERIFICATION,
        ValidationDimension.DEVICE_ANALYTICAL_VALIDITY,
        ValidationDimension.ASSAY_VALIDITY,
        ValidationDimension.BIOLOGICAL_CONCORDANCE,
        ValidationDimension.CLINICAL_APPLICABILITY,
    }
    if (
        required
        and all(summary.get(dimension) is AssessmentStatus.PASS for dimension in required)
        and all(
            summary.get(dimension) is AssessmentStatus.PASS
            for dimension in validated_floor
        )
    ):
        state = ClaimState.VALIDATED
    if (
        state is ClaimState.VALIDATED
        and summary.get(ValidationDimension.EXTERNAL_REPLICATION) is AssessmentStatus.PASS
    ):
        state = ClaimState.REPLICATED
    return state


@dataclass(frozen=True)
class EvidencePackageVersion:
    package_id: str
    schema_version: str
    tenant_id: str
    version: int
    use_case: str
    claim: str
    policy: PolicyVersion
    context_of_use: ContextOfUse
    protocol: ProtocolVersion
    predictions: tuple[PredictionRun, ...]
    measurements: tuple[MeasurementEnvelope, ...]
    model_verifications: tuple[ModelVerificationRecord, ...]
    validation_events: tuple[ValidationEvent, ...]
    provenance: Provenance
    visualization_manifest: VisualizationManifest
    created_at: datetime
    created_by: str
    previous_version_id: Optional[str] = None
    lifecycle: LifecycleStatus = LifecycleStatus.DRAFT
    revision: int = 0
    content_hash: str = ""
    locked_at: Optional[datetime] = None
    released_at: Optional[datetime] = None
    retracted_at: Optional[datetime] = None
    superseded_at: Optional[datetime] = None
    lifecycle_reason: Optional[str] = None
    claim_state: ClaimState = field(init=False)
    validation_summary: tuple[ValidationAssessment, ...] = field(init=False)

    def __post_init__(self) -> None:
        for name in (
            "package_id",
            "schema_version",
            "tenant_id",
            "use_case",
            "claim",
            "created_by",
        ):
            object.__setattr__(self, name, _required(getattr(self, name), name))
        if self.schema_version != "livemore.evidence-package.v2":
            raise DomainValidationError("unsupported evidence package schema version")
        for name in ("predictions", "measurements", "model_verifications", "validation_events"):
            object.__setattr__(self, name, _tuple(getattr(self, name)))
        object.__setattr__(self, "created_at", _timestamp(self.created_at, "created_at"))
        for name in ("locked_at", "released_at", "retracted_at", "superseded_at"):
            value = getattr(self, name)
            if value is not None:
                object.__setattr__(self, name, _timestamp(value, name))
        lifecycle_timestamps = {
            "locked_at": self.locked_at,
            "released_at": self.released_at,
            "retracted_at": self.retracted_at,
            "superseded_at": self.superseded_at,
        }
        if self.lifecycle is LifecycleStatus.DRAFT:
            if any(value is not None for value in lifecycle_timestamps.values()):
                raise DomainValidationError("draft package cannot preload lifecycle timestamps")
            if self.lifecycle_reason is not None:
                raise DomainValidationError("draft package cannot preload a lifecycle reason")
        else:
            if not self.content_hash:
                raise DomainValidationError("non-draft package requires a content hash")
            object.__setattr__(
                self,
                "lifecycle_reason",
                _required(self.lifecycle_reason or "", "lifecycle_reason"),
            )
            if self.locked_at is None:
                raise DomainValidationError("non-draft package requires locked_at")
            if self.locked_at < self.created_at:
                raise DomainValidationError("locked_at cannot precede package creation")
            latest_evidence_time = max(
                (
                    self.created_at,
                    *(measurement.received_at for measurement in self.measurements),
                    *(verification.verified_at for verification in self.model_verifications),
                    *(event.reviewed_at for event in self.validation_events),
                )
            )
            if self.locked_at < latest_evidence_time:
                raise DomainValidationError(
                    "locked_at cannot precede evidence receipt, verification, or review"
                )
            if self.lifecycle is LifecycleStatus.LOCKED:
                if any(
                    lifecycle_timestamps[name] is not None
                    for name in ("released_at", "retracted_at", "superseded_at")
                ):
                    raise DomainValidationError("locked package has invalid later lifecycle timestamps")
            else:
                if self.released_at is None:
                    raise DomainValidationError("released lifecycle requires released_at")
                if self.released_at < self.locked_at:
                    raise DomainValidationError("released_at cannot precede locked_at")
                if self.lifecycle is LifecycleStatus.RELEASED:
                    if self.retracted_at is not None or self.superseded_at is not None:
                        raise DomainValidationError(
                            "released package has invalid terminal lifecycle timestamps"
                        )
                elif self.lifecycle is LifecycleStatus.SUPERSEDED:
                    if self.superseded_at is None or self.retracted_at is not None:
                        raise DomainValidationError(
                            "superseded package requires only a superseded terminal timestamp"
                        )
                    if self.superseded_at < self.released_at:
                        raise DomainValidationError("superseded_at cannot precede released_at")
                elif self.lifecycle is LifecycleStatus.RETRACTED:
                    if self.retracted_at is None:
                        raise DomainValidationError("retracted package requires retracted_at")
                    if (
                        self.superseded_at is not None
                        and self.superseded_at < self.released_at
                    ):
                        raise DomainValidationError(
                            "superseded_at cannot precede released_at"
                        )
                    prior_terminal = self.superseded_at or self.released_at
                    if self.retracted_at < prior_terminal:
                        raise DomainValidationError(
                            "retracted_at cannot precede the prior lifecycle transition"
                        )
                else:
                    raise DomainValidationError("unsupported evidence package lifecycle")
        if self.version < 1 or self.revision < 0:
            raise DomainValidationError("package version must be positive and revision non-negative")
        if self.context_of_use.policy_id != self.policy.policy_id:
            raise DomainValidationError("context of use policy ID does not match embedded policy")
        if self.context_of_use.policy_hash != self.policy.canonical_hash:
            raise DomainValidationError("context of use policy hash does not match embedded policy")
        if tuple(self.context_of_use.required_dimensions) != tuple(self.policy.required_dimensions):
            raise DomainValidationError("context of use dimensions do not match embedded policy")
        if self.policy.effective_at > self.created_at:
            raise DomainValidationError("evidence policy was not effective at package creation")
        if (
            self.protocol.approval_status == "approved"
            and self.protocol.approved_at is not None
            and self.policy.effective_at > self.protocol.approved_at
        ):
            raise DomainValidationError("evidence policy was not effective at protocol approval")
        if (
            self.protocol.approval_status == "approved"
            and self.protocol.approved_at is not None
            and self.protocol.approved_at > self.created_at
        ):
            raise DomainValidationError("protocol approval cannot occur after package creation")
        if any(
            self.policy.effective_at > prediction.generated_at
            for prediction in self.predictions
        ):
            raise DomainValidationError("evidence policy was not effective at prediction generation")
        if any(
            self.policy.effective_at > prediction.scenario_snapshot.captured_at
            for prediction in self.predictions
        ):
            raise DomainValidationError("evidence policy was not effective at scenario capture")
        if any(
            self.policy.effective_at > verification.verified_at
            for verification in self.model_verifications
        ):
            raise DomainValidationError("evidence policy was not effective at model verification")
        if any(
            self.policy.effective_at > event.reviewed_at
            for event in self.validation_events
        ):
            raise DomainValidationError("evidence policy was not effective at validation review")
        if any(
            prediction.scenario_snapshot.captured_at > self.created_at
            for prediction in self.predictions
        ):
            raise DomainValidationError("scenario capture cannot occur after package creation")
        if any(prediction.generated_at > self.created_at for prediction in self.predictions):
            raise DomainValidationError("prediction generation cannot occur after package creation")
        if any(
            measurement.role is MeasurementRole.BASELINE_INPUT
            and measurement.received_at > self.created_at
            for measurement in self.measurements
        ):
            raise DomainValidationError("baseline measurement receipt cannot occur after package creation")
        measurement_by_id = {measurement.envelope_id: measurement for measurement in self.measurements}
        prediction_by_id = {prediction.prediction_id: prediction for prediction in self.predictions}
        if len(measurement_by_id) != len(self.measurements):
            raise DomainValidationError("measurement envelope IDs must be unique")
        if len(prediction_by_id) != len(self.predictions):
            raise DomainValidationError("prediction IDs must be unique")
        if any(measurement.tenant_id != self.tenant_id for measurement in self.measurements):
            raise DomainValidationError("measurement tenant does not match evidence package tenant")
        referenced_model_versions = {
            version
            for prediction in self.predictions
            for version in (
                *prediction.scenario_snapshot.model_versions,
                *prediction.model_versions,
            )
        }
        if set(self.provenance.model_versions) != referenced_model_versions:
            raise DomainValidationError(
                "provenance model versions must exactly cover scenario and prediction models"
            )
        _validate_visualization_evidence_bindings(
            self.visualization_manifest,
            prediction_by_id,
            measurement_by_id,
        )
        known_measurement_ids = set(measurement_by_id)
        for prediction in self.predictions:
            snapshot = prediction.scenario_snapshot
            if not hmac.compare_digest(prediction.protocol_hash, canonical_hash(self.protocol)):
                raise DomainValidationError("prediction protocol hash does not match the bound protocol")
            if (
                self.protocol.approved_at is not None
                and self.protocol.approved_at > prediction.generated_at
            ):
                raise DomainValidationError("prediction was generated before protocol approval")
            if any(output.endpoint not in self.protocol.endpoints for output in prediction.outputs):
                raise DomainValidationError("prediction output is not declared by the bound protocol")
            snapshot_ids = set(snapshot.measurement_ids)
            input_ids = set(prediction.input_measurement_ids)
            if not snapshot_ids.issubset(known_measurement_ids):
                raise DomainValidationError("scenario snapshot references an unknown measurement")
            for measurement_id, expected_hash in zip(
                snapshot.measurement_ids,
                snapshot.measurement_hashes,
            ):
                scenario_measurement = measurement_by_id[measurement_id]
                if not hmac.compare_digest(
                    scenario_measurement.source_hash,
                    expected_hash,
                ):
                    raise DomainValidationError(
                        "scenario snapshot measurement hash does not match the evidence envelope"
                    )
                if scenario_measurement.payload.measured_at > snapshot.captured_at:
                    raise DomainValidationError(
                        "scenario snapshot includes a measurement collected after capture"
                    )
                if scenario_measurement.received_at > snapshot.captured_at:
                    raise DomainValidationError(
                        "scenario snapshot includes a measurement received after capture"
                    )
            if not input_ids.issubset(snapshot_ids):
                raise DomainValidationError("prediction inputs must be present in its scenario snapshot")
            for measurement_id in input_ids:
                measurement = measurement_by_id[measurement_id]
                if measurement.role is not MeasurementRole.BASELINE_INPUT:
                    raise DomainValidationError("prediction inputs must use baseline-input measurements")
                if measurement.counterpart_id != prediction.live_twin_id:
                    raise DomainValidationError("prediction input counterpart does not match the live twin")
                if measurement.payload.measured_at > snapshot.captured_at:
                    raise DomainValidationError("scenario snapshot predates an input measurement")
                input_names = {
                    measurement.payload.endpoint.lower(),
                    f"baseline_{measurement.payload.endpoint.lower()}",
                }
                if not any(
                    model_input.name.lower() in input_names
                    and model_input.value == measurement.payload.value
                    and model_input.unit == measurement.payload.unit
                    for model_input in snapshot.model_inputs
                ):
                    raise DomainValidationError(
                        "baseline measurement is not traceably represented in scenario model inputs"
                    )
        required_hashes = {
            measurement.source_hash for measurement in self.measurements
        } | {
            prediction.scenario_snapshot.state_hash for prediction in self.predictions
        } | {
            prediction.input_hash for prediction in self.predictions
        } | {
            evidence_hash
            for verification in self.model_verifications
            for evidence_hash in verification.evidence_hashes
        } | {
            verification.prediction_hash for verification in self.model_verifications
        } | {
            event.analysis_hash for event in self.validation_events
        }
        if not required_hashes.issubset(set(self.provenance.content_hashes)):
            raise DomainValidationError("provenance is missing one or more derived content hashes")
        verification_ids: set[str] = set()
        verified_prediction_ids: set[str] = set()
        for verification in self.model_verifications:
            if verification.verification_id in verification_ids:
                raise DomainValidationError("model verification IDs must be unique")
            if verification.prediction_id in verified_prediction_ids:
                raise DomainValidationError("a prediction can have only one model verification record")
            verification_ids.add(verification.verification_id)
            verified_prediction_ids.add(verification.prediction_id)
            prediction = prediction_by_id.get(verification.prediction_id)
            if prediction is None:
                raise DomainValidationError("model verification references an unknown prediction")
            if not hmac.compare_digest(
                verification.prediction_hash,
                canonical_hash(prediction),
            ):
                raise DomainValidationError(
                    "model verification prediction hash does not match the exact prediction artifact"
                )
            if (
                verification.policy_id != self.policy.policy_id
                or verification.policy_hash != self.policy.canonical_hash
            ):
                raise DomainValidationError("model verification policy binding does not match package policy")
            if verification.verifier_id in {self.created_by, prediction.actor_id}:
                raise DomainValidationError("model verification requires verifier separation of duties")
            if verification.verified_at < prediction.generated_at:
                raise DomainValidationError("model verification cannot predate its prediction")

        event_ids: set[str] = set()
        assessed_measurements: set[tuple[str, str]] = set()
        for event in self.validation_events:
            if event.event_id in event_ids:
                raise DomainValidationError("validation event IDs must be unique")
            event_ids.add(event.event_id)
            assessment_key = (event.prediction_id, event.measurement_envelope_id)
            if assessment_key in assessed_measurements:
                raise DomainValidationError(
                    "one counterpart measurement cannot be reused across validation events"
                )
            assessed_measurements.add(assessment_key)
            prediction = prediction_by_id.get(event.prediction_id)
            measurement = measurement_by_id.get(event.measurement_envelope_id)
            if prediction is None or measurement is None:
                raise DomainValidationError("validation event references an unknown prediction or measurement")
            if event.policy_id != self.policy.policy_id or event.policy_hash != self.policy.canonical_hash:
                raise DomainValidationError("validation event policy binding does not match package policy")
            if event.source_data_class is not measurement.payload.source_data_class:
                raise DomainValidationError("validation event data class does not match measurement envelope")
            if measurement.role is not MeasurementRole.COUNTERPART_OUTCOME:
                raise DomainValidationError("validation requires a withheld counterpart-outcome measurement")
            if measurement.envelope_id in prediction.input_measurement_ids:
                raise DomainValidationError("prediction inputs cannot validate the same prediction")
            if measurement.counterpart_id != prediction.live_twin_id:
                raise DomainValidationError("validation counterpart does not match the prediction twin")
            if measurement.payload.measured_at <= prediction.generated_at:
                raise DomainValidationError("validation outcome must be collected after prediction freeze")
            if event.reviewed_at < measurement.received_at:
                raise DomainValidationError("validation review cannot predate outcome receipt")
            if event.endpoint not in self.protocol.endpoints:
                raise DomainValidationError("validation endpoint is not declared by the protocol")
            predicted = next(
                (
                    output
                    for output in prediction.outputs
                    if output.endpoint == event.endpoint and output.unit == event.unit
                ),
                None,
            )
            if predicted is None:
                raise DomainValidationError("validation endpoint or unit does not match prediction")
            if (
                measurement.payload.endpoint != event.endpoint
                or measurement.payload.unit != event.unit
            ):
                raise DomainValidationError("validation endpoint or unit does not match measurement")
            if event.acceptance_criterion not in self.protocol.acceptance_criteria:
                raise DomainValidationError("validation criterion was not pre-specified by the protocol")
            if event.reviewer_id in {self.created_by, prediction.actor_id}:
                raise DomainValidationError("validation requires reviewer separation of duties")
            if event.quality_passed and (
                measurement.payload.quality_status is not AssessmentStatus.PASS
                or measurement.payload.calibration_status is not AssessmentStatus.PASS
            ):
                raise DomainValidationError("validation claims quality passed for an ineligible measurement")
            if not hmac.compare_digest(
                event.analysis_hash,
                validation_analysis_hash(prediction, measurement, event),
            ):
                raise DomainValidationError("validation analysis hash does not match bound evidence")
        state = compute_claim_state(
            self.predictions,
            self.measurements,
            self.model_verifications,
            self.validation_events,
            self.policy.required_dimensions,
        )
        object.__setattr__(self, "claim_state", state)
        object.__setattr__(self, "claim", _validate_outward_claim(self.claim, state))
        object.__setattr__(
            self,
            "validation_summary",
            compute_validation_summary(
                self.predictions,
                self.measurements,
                self.model_verifications,
                self.validation_events,
            ),
        )
        if self.lifecycle is LifecycleStatus.DRAFT and self.content_hash:
            raise DomainValidationError("draft package cannot carry a locked content hash")
        if self.lifecycle is not LifecycleStatus.DRAFT and not self.content_hash:
            raise DomainValidationError("non-draft package requires a content hash")

    def calculated_content_hash(self) -> str:
        return content_hash(self)


@dataclass(frozen=True)
class EvidenceExport:
    directory: Any
    archive_path: Any
    detached_hash_path: Any
    manifest_path: Any
    archive_sha256: str
    artifact_hashes: tuple[tuple[str, str], ...]
    published_new: bool = False


def _parse_timestamp(value: Optional[str]) -> Optional[datetime]:
    if value is None:
        return None
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    return datetime.fromisoformat(value)


def evidence_package_from_dict(data: Mapping[str, Any]) -> EvidencePackageVersion:
    """Rehydrate a package written by the canonical serializer."""
    schema_version = data.get("schema_version")
    if schema_version != "livemore.evidence-package.v2":
        raise DomainValidationError(
            "legacy evidence package requires an explicit offline migration to schema v2"
        )
    policy_data = data["policy"]
    policy = PolicyVersion(
        policy_id=policy_data["policy_id"],
        version=policy_data["version"],
        effective_at=_parse_timestamp(policy_data["effective_at"]),  # type: ignore[arg-type]
        required_dimensions=tuple(ValidationDimension(item) for item in policy_data["required_dimensions"]),
        clinical_use=bool(policy_data["clinical_use"]),
    )
    context_data = data["context_of_use"]
    context = ContextOfUse(
        context_id=context_data["context_id"],
        question_of_interest=context_data["question_of_interest"],
        intended_decision=context_data["intended_decision"],
        decision_owner_role=context_data["decision_owner_role"],
        target_population=context_data["target_population"],
        model_system=context_data["model_system"],
        model_influence=context_data["model_influence"],
        wrong_decision_consequence=context_data["wrong_decision_consequence"],
        risk=context_data["risk"],
        impact=context_data["impact"],
        limitations=tuple(context_data["limitations"]),
        required_dimensions=tuple(ValidationDimension(item) for item in context_data["required_dimensions"]),
        policy_id=context_data["policy_id"],
        policy_hash=context_data["policy_hash"],
    )
    protocol_data = data["protocol"]
    protocol = ProtocolVersion(
        protocol_id=protocol_data["protocol_id"], version=protocol_data["version"],
        objective=protocol_data["objective"], hypothesis=protocol_data["hypothesis"],
        candidate=protocol_data["candidate"], target=protocol_data["target"], assay=protocol_data["assay"],
        dose=protocol_data["dose"], duration=protocol_data["duration"],
        controls=tuple(protocol_data["controls"]), endpoints=tuple(protocol_data["endpoints"]),
        acceptance_criteria=tuple(protocol_data["acceptance_criteria"]),
        statistical_plan=protocol_data["statistical_plan"], approval_status=protocol_data["approval_status"],
        approved_at=_parse_timestamp(protocol_data.get("approved_at")),
        approved_by=protocol_data.get("approved_by"),
        approval_role=protocol_data.get("approval_role"),
        approval_reference=protocol_data.get("approval_reference"),
        deviations=tuple(protocol_data["deviations"]), sop_references=tuple(protocol_data["sop_references"]),
    )

    measurements: list[MeasurementEnvelope] = []
    for item in data["measurements"]:
        payload = item["payload"]
        measurements.append(
            MeasurementEnvelope(
                schema_version=item["schema_version"], envelope_id=item["envelope_id"],
                tenant_id=item["tenant_id"], counterpart_id=item["counterpart_id"],
                role=MeasurementRole(item["role"]),
                subject_pseudonymized=bool(item["subject_pseudonymized"]),
                sequence=int(item["sequence"]), received_at=_parse_timestamp(item["received_at"]),  # type: ignore[arg-type]
                payload=CounterpartMeasurement(
                    endpoint=payload["endpoint"], value=Decimal(payload["value"]), unit=payload["unit"],
                    source_data_class=SourceDataClass(payload["source_data_class"]),
                    measured_at=_parse_timestamp(payload["measured_at"]),  # type: ignore[arg-type]
                    quality_status=AssessmentStatus(payload["quality_status"]),
                    calibration_status=AssessmentStatus(payload["calibration_status"]),
                    consent_scope=tuple(payload["consent_scope"]), device_id=payload["device_id"],
                    instrument_id=payload["instrument_id"], method=payload["method"],
                    chain_of_custody=tuple(payload["chain_of_custody"]),
                ),
                source_hash=item["source_hash"],
            )
        )

    predictions: list[PredictionRun] = []
    for item in data["predictions"]:
        snap = item["scenario_snapshot"]
        snapshot = ScenarioSnapshot(
            snapshot_id=snap["snapshot_id"], twin_id=snap["twin_id"],
            captured_at=_parse_timestamp(snap["captured_at"]),  # type: ignore[arg-type]
            measurement_ids=tuple(snap["measurement_ids"]),
            measurement_hashes=tuple(snap.get("measurement_hashes", ())),
            model_inputs=tuple(
                NamedValue(value["name"], Decimal(value["value"]), value["unit"])
                for value in snap["model_inputs"]
            ),
            code_version=snap["code_version"], model_versions=tuple(snap["model_versions"]),
            dataset_versions=tuple(snap["dataset_versions"]),
            model_state_json=snap.get("model_state_json", ""),
            model_state_hash=snap.get("model_state_hash", ""),
            state_hash=snap["state_hash"],
        )
        predictions.append(
            PredictionRun(
                prediction_id=item["prediction_id"], live_twin_id=item["live_twin_id"],
                scenario_snapshot=snapshot, cendos_run_id=item["cendos_run_id"],
                protocol_hash=item["protocol_hash"],
                input_measurement_ids=tuple(item["input_measurement_ids"]),
                model_versions=tuple(item["model_versions"]), code_version=item["code_version"],
                dataset_versions=tuple(item["dataset_versions"]), container_digest=item["container_digest"],
                deterministic_seed=int(item["deterministic_seed"]),
                outputs=tuple(
                    PredictionValue(
                        endpoint=value["endpoint"], value=Decimal(value["value"]), unit=value["unit"],
                        lower=Decimal(value["lower"]), upper=Decimal(value["upper"]),
                        confidence=Decimal(value["confidence"]),
                    )
                    for value in item["outputs"]
                ),
                assumptions=tuple(item["assumptions"]), limitations=tuple(item["limitations"]),
                actor_id=item["actor_id"], generated_at=_parse_timestamp(item["generated_at"]),  # type: ignore[arg-type]
                input_hash=item["input_hash"],
            )
        )

    model_verifications = tuple(
        ModelVerificationRecord(
            verification_id=item["verification_id"],
            prediction_id=item["prediction_id"],
            prediction_hash=item["prediction_hash"],
            disposition=AssessmentStatus(item["disposition"]),
            scope=item["scope"],
            method=item["method"],
            evidence_hashes=tuple(item["evidence_hashes"]),
            verifier_id=item["verifier_id"],
            verifier_role=item["verifier_role"],
            verified_at=_parse_timestamp(item["verified_at"]),  # type: ignore[arg-type]
            policy_id=item["policy_id"],
            policy_hash=item["policy_hash"],
        )
        for item in data.get("model_verifications", ())
    )

    events = tuple(
        ValidationEvent(
            event_id=item["event_id"], prediction_id=item["prediction_id"],
            measurement_envelope_id=item["measurement_envelope_id"], dimension=ValidationDimension(item["dimension"]),
            endpoint=item["endpoint"], unit=item["unit"], time_window=item["time_window"],
            acceptance_criterion=item["acceptance_criterion"], metric_name=item["metric_name"],
            metric_value=Decimal(item["metric_value"]), disposition=AssessmentStatus(item["disposition"]),
            endpoint_compatible=bool(item["endpoint_compatible"]), unit_compatible=bool(item["unit_compatible"]),
            time_window_compatible=bool(item["time_window_compatible"]), quality_passed=bool(item["quality_passed"]),
            protocol_criterion_passed=bool(item["protocol_criterion_passed"]),
            source_data_class=SourceDataClass(item["source_data_class"]), reviewer_id=item["reviewer_id"],
            reviewer_role=item["reviewer_role"], reviewed_at=_parse_timestamp(item["reviewed_at"]),  # type: ignore[arg-type]
            policy_id=item["policy_id"], policy_hash=item["policy_hash"],
            analysis_hash=item["analysis_hash"], independent=bool(item["independent"]),
            independent_site=item.get("independent_site"),
        )
        for item in data["validation_events"]
    )
    provenance_data = data["provenance"]
    provenance = Provenance(
        source_ids=tuple(provenance_data["source_ids"]), transformations=tuple(provenance_data["transformations"]),
        model_versions=tuple(provenance_data["model_versions"]), code_commit=provenance_data["code_commit"],
        environment=provenance_data["environment"], content_hashes=tuple(provenance_data["content_hashes"]),
        correlation_ids=tuple(provenance_data["correlation_ids"]),
    )
    manifest_data = data["visualization_manifest"]
    manifest = VisualizationManifest(
        manifest_id=manifest_data["manifest_id"], anatomy_asset_ids=tuple(manifest_data["anatomy_asset_ids"]),
        coordinate_system=manifest_data["coordinate_system"], asset_version=manifest_data["asset_version"],
        asset_license=manifest_data["asset_license"],
        mappings=tuple(VisualizationMapping(**item) for item in manifest_data["mappings"]),
    )
    return EvidencePackageVersion(
        package_id=data["package_id"], schema_version=str(schema_version),
        tenant_id=data["tenant_id"], version=int(data["version"]),
        previous_version_id=data.get("previous_version_id"), use_case=data["use_case"], claim=data["claim"],
        policy=policy, context_of_use=context, protocol=protocol, predictions=tuple(predictions),
        measurements=tuple(measurements), model_verifications=model_verifications,
        validation_events=events, provenance=provenance,
        visualization_manifest=manifest, created_at=_parse_timestamp(data["created_at"]),  # type: ignore[arg-type]
        created_by=data["created_by"], lifecycle=LifecycleStatus(data["lifecycle"]),
        revision=int(data["revision"]), content_hash=data["content_hash"],
        locked_at=_parse_timestamp(data.get("locked_at")), released_at=_parse_timestamp(data.get("released_at")),
        retracted_at=_parse_timestamp(data.get("retracted_at")),
        superseded_at=_parse_timestamp(data.get("superseded_at")), lifecycle_reason=data.get("lifecycle_reason"),
    )


def calibration_authorization_from_dict(data: Mapping[str, Any]) -> CalibrationAuthorization:
    return CalibrationAuthorization(
        authorization_id=data["authorization_id"], tenant_id=data["tenant_id"], package_id=data["package_id"],
        package_content_hash=data["package_content_hash"], cendos_run_id=data["cendos_run_id"],
        live_twin_id=data["live_twin_id"],
        validation_event_ids=tuple(data["validation_event_ids"]), parameter_scope=tuple(data["parameter_scope"]),
        reviewer_id=data["reviewer_id"], authorized_at=_parse_timestamp(data["authorized_at"]),  # type: ignore[arg-type]
        policy_id=data["policy_id"], policy_hash=data["policy_hash"], consumed=bool(data["consumed"]),
        consumed_at=_parse_timestamp(data.get("consumed_at")),
    )
