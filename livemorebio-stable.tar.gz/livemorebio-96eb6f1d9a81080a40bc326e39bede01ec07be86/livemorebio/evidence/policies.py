"""Code-reviewed policy registry for evidence claim promotion."""
from __future__ import annotations

from datetime import datetime, timezone
from types import MappingProxyType

from .errors import DomainValidationError
from .models import PolicyVersion, ValidationDimension


def _policy(
    policy_id: str,
    version: str,
    effective_at: datetime,
    required_dimensions: tuple[ValidationDimension, ...],
) -> PolicyVersion:
    return PolicyVersion(
        policy_id=policy_id,
        version=version,
        effective_at=effective_at,
        required_dimensions=required_dimensions,
        clinical_use=False,
    )


_POLICIES = (
    _policy(
        "livemore-research-model-policy",
        "1.0.0",
        datetime(2026, 7, 9, tzinfo=timezone.utc),
        (
            ValidationDimension.MODEL_VERIFICATION,
            ValidationDimension.BIOLOGICAL_CONCORDANCE,
        ),
    ),
    _policy(
        "policy-pharma-discovery",
        "1.0.0",
        datetime(2026, 7, 8, 16, 17, 18, 123000, tzinfo=timezone.utc),
        (
            ValidationDimension.MODEL_VERIFICATION,
            ValidationDimension.DEVICE_ANALYTICAL_VALIDITY,
            ValidationDimension.ASSAY_VALIDITY,
            ValidationDimension.BIOLOGICAL_CONCORDANCE,
        ),
    ),
)

APPROVED_POLICIES = MappingProxyType(
    {(policy.policy_id, policy.version): policy for policy in _POLICIES}
)


def require_approved_policy(policy: PolicyVersion) -> None:
    approved = APPROVED_POLICIES.get((policy.policy_id, policy.version))
    if approved is None or approved.canonical_hash != policy.canonical_hash:
        raise DomainValidationError(
            "evidence policy ID, version, and hash are not in the approved policy registry"
        )
