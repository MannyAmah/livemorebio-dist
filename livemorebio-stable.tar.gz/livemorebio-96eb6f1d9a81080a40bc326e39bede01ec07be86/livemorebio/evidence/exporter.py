"""Deterministic, content-addressed evidence exports."""
from __future__ import annotations

import base64
import csv
import errno
import hashlib
import html
import io
import os
import re
import shutil
import tempfile
import uuid
import zipfile
import stat
import threading
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

try:
    import fcntl
except ImportError:  # pragma: no cover - POSIX production environments provide fcntl.
    fcntl = None  # type: ignore[assignment]

from .canonical import canonical_json_bytes, canonical_timestamp, sha256_hex
from .errors import IntegrityError
from .models import EvidenceExport, EvidencePackageVersion
from .signing import IssuerSigner, SIGNED_ARTIFACT_NAMES


ARTIFACT_NAMES = SIGNED_ARTIFACT_NAMES
_EXPORT_LOCKS_GUARD = threading.Lock()
_EXPORT_LOCKS: dict[str, threading.RLock] = {}


@dataclass(frozen=True)
class ExportPlan:
    root: Path
    signer: IssuerSigner
    final_dir: Path


def export_package(
    package: EvidencePackageVersion,
    output_dir: str | Path,
    *,
    evidence_audit_proof_reference: Mapping[str, object] | None = None,
    plan: ExportPlan | None = None,
) -> EvidenceExport:
    """Publish one deterministic export directory using an atomic directory rename."""
    context = plan or plan_export(package, output_dir)
    expected_root = _canonical_existing_export_root(output_dir)
    if context.root != expected_root:
        raise IntegrityError("evidence export plan does not match the requested output root")
    root, signer, final_dir = context.root, context.signer, context.final_dir
    audit_reference = _audit_reference(evidence_audit_proof_reference)
    if final_dir.exists():
        return _load_existing_export(package, final_dir, signer, audit_reference)

    temporary = Path(tempfile.mkdtemp(prefix=".tmp-", dir=str(root)))
    published_new = False
    archive_name = f"{_safe_name(package.package_id)}.zip"
    try:
        artifacts, manifest_bytes, archive_bytes, archive_hash = _expected_export_bytes(
            package,
            signer,
            audit_reference,
        )
        artifact_hashes = {
            name: sha256_hex(data) for name, data in artifacts.items()
        }
        for name in sorted(artifacts):
            _write_file(temporary / name, artifacts[name])
        _write_file(temporary / "manifest.json", manifest_bytes)
        archive_path = temporary / archive_name
        _write_file(archive_path, archive_bytes)
        _write_file(temporary / f"{archive_name}.sha256", (archive_hash + "\n").encode("ascii"))
        _fsync_directory(temporary)
        try:
            os.replace(temporary, final_dir)
            published_new = True
        except OSError as error:
            if error.errno not in {errno.EEXIST, errno.ENOTEMPTY}:
                raise
            shutil.rmtree(temporary)
            return _load_existing_export(package, final_dir, signer, audit_reference)
        _fsync_directory(root)
    except Exception:
        if temporary.exists():
            shutil.rmtree(temporary)
        raise
    return _export_result(
        final_dir,
        archive_name,
        artifact_hashes,
        archive_hash,
        published_new=published_new,
    )


def planned_export_directory(
    package: EvidencePackageVersion,
    output_dir: str | Path,
) -> Path:
    """Prepare signing identity and return the exact deterministic publication path."""

    return plan_export(package, output_dir).final_dir


def plan_export(
    package: EvidencePackageVersion,
    output_dir: str | Path,
) -> ExportPlan:
    """Freeze the signer and deterministic directory used for one export attempt."""

    return _export_context(package, output_dir)


@contextmanager
def export_artifact_lock(final_dir: Path):
    """Serialize publication, registration, and cleanup for one deterministic path."""

    key = str(final_dir.resolve(strict=False))
    with _EXPORT_LOCKS_GUARD:
        thread_lock = _EXPORT_LOCKS.setdefault(key, threading.RLock())
    with thread_lock:
        lock_path = final_dir.parent / f".{final_dir.name}.lock"
        flags = os.O_RDWR | os.O_CREAT | getattr(os, "O_CLOEXEC", 0)
        flags |= getattr(os, "O_NOFOLLOW", 0)
        descriptor = os.open(lock_path, flags, 0o600)
        try:
            metadata = os.fstat(descriptor)
            if not stat.S_ISREG(metadata.st_mode):
                raise IntegrityError("evidence export lock is not a regular file")
            if fcntl is not None:
                fcntl.flock(descriptor, fcntl.LOCK_EX)
            yield
        finally:
            if fcntl is not None:
                fcntl.flock(descriptor, fcntl.LOCK_UN)
            os.close(descriptor)


def _export_context(
    package: EvidencePackageVersion,
    output_dir: str | Path,
) -> ExportPlan:
    requested_root = Path(output_dir).expanduser()
    created = False
    try:
        requested_root.mkdir(parents=True, exist_ok=False, mode=0o700)
        created = True
    except FileExistsError:
        if not requested_root.is_dir():
            raise IntegrityError("evidence export root exists but is not a directory")
    try:
        root = requested_root.resolve(strict=True)
    except (OSError, RuntimeError) as error:
        raise IntegrityError("evidence export root cannot be resolved safely") from error
    if not root.is_dir():
        raise IntegrityError("evidence export root is not a directory")
    if created:
        try:
            os.chmod(root, 0o700)
        except OSError:
            pass
    signer = IssuerSigner.load(root)
    final_dir = root / (
        f"{_safe_name(package.package_id)}-{package.content_hash[:16]}-"
        f"r{package.revision}-{package.lifecycle.value}-"
        f"sp{signer.signing_profile_hash}"
    )
    return ExportPlan(root=root, signer=signer, final_dir=final_dir)


def _canonical_existing_export_root(output_dir: str | Path) -> Path:
    requested_root = Path(output_dir).expanduser()
    try:
        root = requested_root.resolve(strict=True)
    except (OSError, RuntimeError) as error:
        raise IntegrityError("evidence export root cannot be resolved safely") from error
    if not root.is_dir():
        raise IntegrityError("evidence export root is not a directory")
    return root


def quarantine_export(result: EvidenceExport, *, force: bool = False) -> Path | None:
    """Atomically hide a newly-published export that lost its database CAS race."""

    if not result.published_new and not force:
        return None
    directory = Path(result.directory)
    if not directory.exists():
        return None
    if directory.is_symlink() or not directory.is_dir():
        raise IntegrityError("refusing to quarantine an invalid evidence export path")
    quarantined = directory.parent / f".stale-{directory.name}-{uuid.uuid4().hex}"
    os.replace(directory, quarantined)
    _fsync_directory(directory.parent)
    return quarantined


def _load_existing_export(
    package: EvidencePackageVersion,
    final_dir: Path,
    signer: IssuerSigner,
    audit_reference: Mapping[str, object],
) -> EvidenceExport:
    archive_name = f"{_safe_name(package.package_id)}.zip"
    manifest_path = final_dir / "manifest.json"
    archive_path = final_dir / archive_name
    detached_path = final_dir / f"{archive_name}.sha256"
    expected_artifacts, expected_manifest, expected_archive, expected_archive_hash = (
        _expected_export_bytes(package, signer, audit_reference)
    )
    expected_artifact_hashes = {
        name: sha256_hex(data) for name, data in expected_artifacts.items()
    }
    expected_names = set(expected_artifacts) | {
        "manifest.json",
        archive_name,
        f"{archive_name}.sha256",
    }
    try:
        if {entry.name for entry in final_dir.iterdir()} != expected_names:
            raise IntegrityError("existing evidence export has an unexpected artifact set")
        manifest_bytes = manifest_path.read_bytes()
        detached_bytes = detached_path.read_bytes()
        archive_bytes = archive_path.read_bytes()
    except OSError as exc:
        raise IntegrityError("existing evidence export is incomplete") from exc
    if manifest_bytes != expected_manifest:
        raise IntegrityError("existing evidence export manifest differs from derived content")
    for name, expected_bytes in expected_artifacts.items():
        path = final_dir / name
        if not path.is_file() or path.read_bytes() != expected_bytes:
            raise IntegrityError(
                f"existing evidence export artifact differs from derived content: {name}"
            )
    if (
        archive_bytes != expected_archive
        or detached_bytes != (expected_archive_hash + "\n").encode("ascii")
    ):
        raise IntegrityError("existing evidence archive differs from derived content")
    return _export_result(
        final_dir,
        archive_name,
        expected_artifact_hashes,
        expected_archive_hash,
    )


def _expected_export_bytes(
    package: EvidencePackageVersion,
    signer: IssuerSigner,
    audit_reference: Mapping[str, object],
) -> tuple[dict[str, bytes], bytes, bytes, str]:
    evidence_bytes = canonical_json_bytes(package)
    artifacts = {
        "evidence.json": evidence_bytes,
        "fhir-draft.json": canonical_json_bytes(_fhir_draft(package, evidence_bytes)),
        "measurements.csv": _measurement_csv(package),
        "report.md": _markdown_report(package),
    }
    artifact_hashes = {
        name: sha256_hex(data) for name, data in artifacts.items()
    }
    unsigned_manifest = {
        "schema_version": "livemore.evidence-export-manifest.v2",
        "issuer": signer.issuer_metadata(),
        "package": {
            "package_id": package.package_id,
            "package_content_hash": package.content_hash,
            "evidence_sha256": sha256_hex(evidence_bytes),
            "computed_claim_state": package.claim_state.value,
            "lifecycle": package.lifecycle.value,
            "revision": package.revision,
        },
        "evidence_audit_proof_reference": dict(audit_reference),
        "artifacts": artifact_hashes,
    }
    manifest = {
        **unsigned_manifest,
        "signature": {
            "algorithm": "Ed25519",
            "value": signer.sign(canonical_json_bytes(unsigned_manifest)),
        },
    }
    manifest_bytes = canonical_json_bytes(manifest)
    archive_bytes = _archive_bytes({**artifacts, "manifest.json": manifest_bytes})
    return artifacts, manifest_bytes, archive_bytes, sha256_hex(archive_bytes)


def _audit_reference(
    value: Mapping[str, object] | None,
) -> dict[str, object]:
    if value is None:
        return {
            "schema_version": "livemore.evidence-audit-proof-reference.v1",
            "status": "not_available",
            "reason": "exporter invoked without an evidence-store audit reference",
        }
    reference = dict(value)
    if reference.get("schema_version") != "livemore.evidence-audit-proof-reference.v1":
        raise IntegrityError("evidence audit proof reference schema is invalid")
    if reference.get("status") not in {"available", "not_available"}:
        raise IntegrityError("evidence audit proof reference status is invalid")
    return reference


def _export_result(
    directory: Path,
    archive_name: str,
    artifact_hashes: Mapping[str, str],
    archive_hash: str,
    *,
    published_new: bool = False,
) -> EvidenceExport:
    return EvidenceExport(
        directory=directory,
        archive_path=directory / archive_name,
        detached_hash_path=directory / f"{archive_name}.sha256",
        manifest_path=directory / "manifest.json",
        archive_sha256=archive_hash,
        artifact_hashes=tuple(sorted(artifact_hashes.items())),
        published_new=published_new,
    )


def _write_file(path: Path, data: bytes) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "wb", closefd=False) as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
    finally:
        os.close(descriptor)
    os.chmod(path, 0o600)


def _archive_bytes(entries: Mapping[str, bytes]) -> bytes:
    output = io.BytesIO()
    with zipfile.ZipFile(
        output,
        "w",
        compression=zipfile.ZIP_STORED,
        allowZip64=True,
    ) as archive:
        for name in sorted(entries):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.compress_type = zipfile.ZIP_STORED
            info.external_attr = (0o100600 & 0xFFFF) << 16
            info.flag_bits = 0
            archive.writestr(info, entries[name])
    return output.getvalue()


def _spreadsheet_safe_cell(value: object) -> str:
    """Encode CSV cells so spreadsheet applications do not execute formulas.

    A leading apostrophe is the conventional spreadsheet text marker. The
    canonical value remains unchanged in evidence.json; this transformation is
    limited to the human-convenience CSV projection.
    """

    rendered = str(value)
    if rendered.startswith(("=", "+", "-", "@")):
        return "'" + rendered
    return rendered


def _measurement_csv(package: EvidencePackageVersion) -> bytes:
    output = io.StringIO(newline="")
    fieldnames = (
        "package_id",
        "envelope_id",
        "counterpart_id",
        "endpoint",
        "value",
        "unit",
        "source_data_class",
        "measured_at",
        "quality_status",
        "calibration_status",
        "source_hash",
    )
    writer = csv.DictWriter(
        output,
        fieldnames=fieldnames,
        delimiter=",",
        quotechar='"',
        quoting=csv.QUOTE_ALL,
        lineterminator="\n",
    )
    writer.writeheader()
    from .canonical import canonical_decimal

    for envelope in sorted(package.measurements, key=lambda item: item.envelope_id):
        payload = envelope.payload
        row = {
                "package_id": package.package_id,
                "envelope_id": envelope.envelope_id,
                "counterpart_id": envelope.counterpart_id,
                "endpoint": payload.endpoint,
                "value": canonical_decimal(payload.value),
                "unit": payload.unit,
                "source_data_class": payload.source_data_class.value,
                "measured_at": canonical_timestamp(payload.measured_at),
                "quality_status": payload.quality_status.value,
                "calibration_status": payload.calibration_status.value,
                "source_hash": envelope.source_hash,
            }
        writer.writerow({name: _spreadsheet_safe_cell(value) for name, value in row.items()})
    return output.getvalue().encode("utf-8")


def _md(value: object) -> str:
    """Escape untrusted evidence text for Markdown paragraphs and table cells."""

    escaped = str(value).replace("\\", "\\\\")
    escaped = html.escape(escaped, quote=False)
    for character in ("`", "*", "_", "[", "]", "#", "|"):
        escaped = escaped.replace(character, "\\" + character)
    return escaped


def _markdown_report(package: EvidencePackageVersion) -> bytes:
    predictions = "\n".join(
        f"| {_md(output.endpoint)} | {_md(output.value)} | {_md(output.unit)} | "
        f"{_md(output.lower)}–{_md(output.upper)} | {_md(output.confidence)} | "
        f"{'not_assessed' if output.confidence == 0 else 'recorded_model_value_not_calibrated'} |"
        for prediction in package.predictions
        for output in prediction.outputs
    ) or "| — | — | — | — | — | not_assessed |"
    measurements = "\n".join(
        f"| {_md(measurement.payload.endpoint)} | {_md(measurement.payload.value)} | "
        f"{_md(measurement.payload.unit)} | "
        f"{_md(measurement.payload.source_data_class.value)} | "
        f"{_md(measurement.payload.quality_status.value)} |"
        for measurement in sorted(package.measurements, key=lambda item: item.envelope_id)
    ) or "| — | — | — | — | — |"
    events = "\n".join(
        f"| {_md(event.dimension.value)} | {_md(event.metric_name)} | "
        f"{_md(event.metric_value)} | {_md(event.disposition.value)} | "
        f"{_md(event.reviewer_role)} |"
        for event in sorted(package.validation_events, key=lambda item: item.event_id)
    ) or "| — | — | — | — | — |"
    model_verifications = "\n".join(
        f"| {_md(record.prediction_id)} | {_md(record.disposition.value)} |"
        for record in sorted(package.model_verifications, key=lambda item: item.verification_id)
    ) or "| — | not_assessed |"
    validation_summary = "\n".join(
        f"| {_md(assessment.dimension.value)} | {_md(assessment.status.value)} | "
        f"{_md(assessment.basis)} |"
        for assessment in package.validation_summary
    )
    text = f"""# Livemore Evidence Package

- Package: {_md(package.package_id)}
- Version: {_md(package.version)}
- Lifecycle: {_md(package.lifecycle.value)}
- Computed claim state: {_md(package.claim_state.value)}
- Content hash: {_md(package.content_hash)}
- Context of use: {_md(package.context_of_use.context_id)}
- Protocol: {_md(package.protocol.protocol_id)} version {_md(package.protocol.version)}

## Claim

{_md(package.claim)}

The complete context-of-use record is retained in signed `evidence.json`. Free-text
context narratives are intentionally not rendered as outward claims in this report.

CSV convention: cells beginning with `=`, `+`, `-`, or `@` are prefixed with an
apostrophe in `measurements.csv` to prevent spreadsheet formula execution. Canonical
values remain unchanged in signed `evidence.json`.

## Predictions

| Endpoint | Predicted | Unit | Interval | Confidence | Uncertainty status |
|---|---:|---|---|---:|---|
{predictions}

`not_assessed` means the interval is only the recorded point value. A nonzero recorded
model confidence is not represented here as calibrated uncertainty unless a separately
governed uncertainty method and validation record are added to the evidence schema.

## Counterpart measurements

| Endpoint | Measured | Unit | Data class | QC |
|---|---:|---|---|---|
{measurements}

## Model verification

| Prediction | Disposition |
|---|---|
{model_verifications}

Model verification records a bounded software disposition only. Its full scope and
method remain in signed `evidence.json`; they are not outward claims. Model verification
does not establish biological concordance, clinical applicability, or regulatory acceptance.

## Validation summary

| Dimension | Status | Basis |
|---|---|---|
{validation_summary}

## Validation events

| Dimension | Metric | Value | Disposition | Reviewer role |
|---|---|---:|---|---|
{events}

## Limitations

Free-text limitations are retained in signed `evidence.json` and intentionally omitted
from this outward narrative. The canonical claim above governs interpretation.

This package records Livemore evidence in a bounded context. It does not itself establish regulatory acceptance, replace animal studies, or authorize a clinical decision.
"""
    return text.encode("utf-8")


def _fhir_draft(package: EvidencePackageVersion, evidence_bytes: bytes) -> dict:
    attachment_hash = base64.b64encode(hashlib.sha1(evidence_bytes).digest()).decode("ascii")
    package_id = _fhir_id(package.package_id)
    document_status = {
        "retracted": "entered-in-error",
        "superseded": "superseded",
    }.get(package.lifecycle.value, "current")
    return {
        "resourceType": "Bundle",
        "id": _fhir_id(f"bundle-{package.package_id}"),
        "type": "collection",
        "timestamp": canonical_timestamp(package.locked_at or package.created_at),
        "meta": {
            "tag": [
                {
                    "system": "https://livemore.ai/fhir/conformance-status",
                    "code": "draft-not-validated",
                    "display": "Draft mapping; no FHIR conformance claim",
                }
            ]
        },
        "identifier": {
            "system": "https://livemore.ai/evidence-package",
            "value": package.package_id,
        },
        "entry": [
            {
                "fullUrl": f"https://livemore.ai/fhir/DocumentReference/{package_id}",
                "resource": {
                    "resourceType": "DocumentReference",
                    "id": package_id,
                    "status": document_status,
                    "meta": {
                        "tag": [
                            {
                                "system": "https://livemore.ai/fhir/evidence-claim-state",
                                "code": package.claim_state.value,
                                "display": "Bounded model-evidence state; not a study-registration status",
                            }
                        ]
                    },
                    "description": package.claim,
                    "content": [
                        {
                            "attachment": {
                                "contentType": "application/json",
                                "title": "Livemore evidence package attachment",
                                "hash": attachment_hash,
                                "size": len(evidence_bytes),
                                "data": base64.b64encode(evidence_bytes).decode("ascii"),
                                "extension": [
                                    {
                                        "url": "https://livemore.ai/fhir/StructureDefinition/package-sha256",
                                        "valueString": package.content_hash,
                                    }
                                ],
                            }
                        }
                    ],
                },
            },
        ],
    }


def _fhir_id(value: str) -> str:
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"https://livemore.ai/fhir-id/{value}"))


def _safe_name(value: str) -> str:
    normalized = re.sub(r"[^A-Za-z0-9_.-]", "-", value).strip(".-")
    return normalized or hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]


def _fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
