"""Cendos translation-gate assessment for frozen prediction counterparts.

This produces a candidate validation assessment.  It never changes the twin,
promotes an evidence-package claim, or authorizes calibration.  Those mutations
remain exclusive to ``EvidenceService`` and its separation-of-duties policy.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import math
from typing import Any


class QualificationInputError(ValueError):
    """Raised when a qualification request cannot be represented safely."""


def _identity(value: str, name: str) -> str:
    normalized = str(value).strip()
    if not normalized:
        raise QualificationInputError(f"{name} is required")
    if len(normalized) > 200:
        raise QualificationInputError(f"{name} exceeds 200 characters")
    if any(ord(character) < 32 for character in normalized):
        raise QualificationInputError(f"{name} contains control characters")
    return normalized


def _finite(value: Any, name: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as error:
        raise QualificationInputError(f"{name} must be numeric") from error
    if not math.isfinite(number):
        raise QualificationInputError(f"{name} must be finite")
    return number


def _time(value: datetime, name: str) -> datetime:
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise QualificationInputError(f"{name} must be timezone-aware")
    return value.astimezone(timezone.utc)


def assess_counterpart(
    *,
    prediction_id: str,
    measurement_id: str,
    protocol_id: str,
    subject_id: str,
    prediction_subject_id: str,
    endpoint: str,
    prediction_endpoint: str,
    predicted_value: float,
    measured_value: float,
    unit: str,
    prediction_unit: str,
    tolerance: float,
    generated_at: datetime,
    measured_at: datetime,
    expected_window_seconds: float,
    quality_status: str,
    calibration_status: str,
    population: str,
    intervention: str,
    dose: str,
) -> dict[str, Any]:
    """Assess whether a counterpart is eligible for evidence review.

    A criterion result is meaningful only after all identity, endpoint, unit,
    temporal, and instrument gates pass.
    """
    prediction_id = _identity(prediction_id, "prediction_id")
    measurement_id = _identity(measurement_id, "measurement_id")
    protocol_id = _identity(protocol_id, "protocol_id")
    subject_id = _identity(subject_id, "subject_id")
    prediction_subject_id = _identity(prediction_subject_id, "prediction_subject_id")
    endpoint = _identity(endpoint, "endpoint")
    prediction_endpoint = _identity(prediction_endpoint, "prediction_endpoint")
    unit = _identity(unit, "unit")
    prediction_unit = _identity(prediction_unit, "prediction_unit")
    population = _identity(population, "population")
    intervention = _identity(intervention, "intervention")
    dose = _identity(dose, "dose")
    predicted_value = _finite(predicted_value, "predicted_value")
    measured_value = _finite(measured_value, "measured_value")
    tolerance = _finite(tolerance, "tolerance")
    expected_window_seconds = _finite(expected_window_seconds, "expected_window_seconds")
    generated_at = _time(generated_at, "generated_at")
    measured_at = _time(measured_at, "measured_at")
    if tolerance < 0:
        raise QualificationInputError("tolerance must be greater than or equal to zero")
    if expected_window_seconds <= 0:
        raise QualificationInputError("expected_window_seconds must be greater than zero")

    reasons: list[str] = []
    if subject_id != prediction_subject_id:
        reasons.append("subject_binding_mismatch")
    if endpoint != prediction_endpoint:
        reasons.append("endpoint_binding_mismatch")
    if unit != prediction_unit:
        reasons.append("unit_binding_mismatch")
    observed_window = (measured_at - generated_at).total_seconds()
    if observed_window <= 0:
        reasons.append("measurement_does_not_follow_prediction_freeze")
    elif abs(observed_window - expected_window_seconds) > 1.0:
        reasons.append("time_window_mismatch")
    if str(quality_status).lower() != "pass":
        reasons.append("measurement_quality_not_passed")
    if str(calibration_status).lower() not in {"pass", "current"}:
        reasons.append("instrument_calibration_not_current")

    absolute_error = abs(predicted_value - measured_value)
    if reasons:
        status = "NOT_ASSESSABLE"
    else:
        status = "CRITERION_MET" if absolute_error <= tolerance else "CRITERION_NOT_MET"
    normalized_error = None
    if tolerance > 0:
        normalized_error = absolute_error / tolerance
    elif absolute_error == 0:
        normalized_error = 0.0

    canonical = {
        "prediction_id": prediction_id,
        "measurement_id": measurement_id,
        "protocol_id": protocol_id,
        "subject_id": subject_id,
        "endpoint": endpoint,
        "predicted_value": predicted_value,
        "measured_value": measured_value,
        "unit": unit,
        "tolerance": tolerance,
        "generated_at": generated_at.isoformat(),
        "measured_at": measured_at.isoformat(),
        "population": population,
        "intervention": intervention,
        "dose": dose,
    }
    digest = hashlib.sha256(
        json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return {
        "schema": "livemore.cendos-counterpart-qualification.v1",
        "qualification_id": f"qualification-{digest[:24]}",
        "prediction_id": prediction_id,
        "measurement_id": measurement_id,
        "protocol_id": protocol_id,
        "status": status,
        "reasons": reasons,
        "endpoint": endpoint,
        "predicted_value": predicted_value,
        "measured_value": measured_value,
        "unit": unit,
        "absolute_error": round(absolute_error, 12),
        "tolerance": tolerance,
        "normalized_error": round(normalized_error, 12) if normalized_error is not None else None,
        "time_window_seconds": observed_window,
        "context": {
            "population": population,
            "intervention": intervention,
            "dose": dose,
            "endpoint": endpoint,
        },
        "evidence_effect": "candidate_validation_event",
        "calibration_authorized": False,
        "next_gate": "evidence_service_validation_review",
    }


__all__ = ["QualificationInputError", "assess_counterpart"]
