"""Bounded frozen Aegle inputs; a notification cache is never assay authority."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import fields
import hashlib
import json
import math
import os
import re
from typing import Any

from ..aegle.clinical_parameters import validate_model_parameters
from ..engines.metabolic.glucose_insulin import MetabolicProfile
from ..execution_client import ContinuousClientError, ContinuousExecutionClient, identifier
from ..strict_json import parse_json_object

SCHEMA = "livemore.cendos-current-source.v1"
MAX_SOURCE_BYTES = 2_000_000
_SNAPSHOT_FIELDS = {"profile", "profile_params", "pk_context", "parameter_provenance", "subject", "model_availability"}
_AVAILABILITY_FIELDS = {"schema", "state", "reason_code", "selection_mode", "twin_id", "twin_version", "source_generation", "preparation_available"}
_SUBJECT_FIELDS = {"twin_id", "subject_id", "display_label", "source_class", "lifecycle", "version"}
_GUARD_FIELDS = {"source_generation", "twin_id", "twin_version", "snapshot_sha256"}
_HASH = re.compile(r"[0-9a-f]{64}")
_UUID = re.compile(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}")


def canonical(value: dict[str, Any]) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def _text(value: Any, maximum: int) -> bool:
    return isinstance(value, str) and 0 < len(value) <= maximum and value == value.strip() and all(ord(char) >= 32 for char in value)


def validate_source_envelope(value: Any) -> dict[str, Any]:
    """Validate exact identity and existing parameter domains, never qualify biology."""
    try:
        encoded = canonical(value)
        if len(encoded) > MAX_SOURCE_BYTES:
            raise ValueError
        result = parse_json_object(encoded)
        if set(result) != {"schema", "snapshot", "snapshot_sha256"} or result["schema"] != SCHEMA:
            raise ValueError
        snapshot = result["snapshot"]
        if not isinstance(snapshot, dict) or set(snapshot) != _SNAPSHOT_FIELDS:
            raise ValueError
        digest = result["snapshot_sha256"]
        if not isinstance(digest, str) or not _HASH.fullmatch(digest) or hashlib.sha256(canonical(snapshot)).hexdigest() != digest:
            raise ValueError
        availability = snapshot["model_availability"]
        if (not isinstance(availability, dict) or set(availability) != _AVAILABILITY_FIELDS
                or availability["schema"] != "livemore.model-availability.v1"
                or availability["state"] != "READY" or availability["reason_code"] is not None
                or availability["preparation_available"] is not True):
            raise ValueError
        identifier(availability["source_generation"])
        subject = snapshot["subject"]
        if subject is None:
            if (availability["selection_mode"] != "reference_preview" or availability["twin_id"] is not None
                    or type(availability["twin_version"]) is not int or availability["twin_version"] != 0):
                raise ValueError
        else:
            if (not isinstance(subject, dict) or set(subject) != _SUBJECT_FIELDS
                    or subject["source_class"] not in {"SYNTHETIC", "REFERENCE_GROUNDED_SYNTHETIC"}
                    or subject["lifecycle"] != "ACTIVE" or type(subject["version"]) is not int
                    or subject["version"] < 1 or not _text(subject["subject_id"], 96)
                    or not _text(subject["display_label"], 80)
                    or availability["selection_mode"] != "model"
                    or type(availability["twin_version"]) is not int
                    or availability["twin_version"] != subject["version"]
                    or availability["twin_id"] != subject["twin_id"]):
                raise ValueError
            identifier(subject["twin_id"])
        parameters = snapshot["profile_params"]
        if (not isinstance(parameters, dict) or set(parameters) != {field.name for field in fields(MetabolicProfile)}
                or not _text(snapshot["profile"], 80) or parameters["name"] != snapshot["profile"]):
            raise ValueError
        validate_model_parameters({key: item for key, item in parameters.items() if key != "name"})
        pk = snapshot["pk_context"]
        if (not isinstance(pk, dict) or set(pk) != {"age", "genome", "evidence_class"}
                or pk["evidence_class"] not in {"REFERENCE_INITIALIZED", "DECLARED_PERSON_CONTEXT"}
                or type(pk["age"]) not in {int, float} or not math.isfinite(pk["age"]) or not 0 < pk["age"] <= 120
                or not isinstance(pk["genome"], dict)
                or any(not isinstance(key, str) or type(item) is not int or not 0 <= item <= 2 for key, item in pk["genome"].items())
                or not isinstance(snapshot["parameter_provenance"], dict)):
            raise ValueError
        return result
    except (ValueError, TypeError, KeyError, OverflowError, RecursionError):
        raise ContinuousClientError("CLIENT_RESPONSE") from None


def make_source_envelope(snapshot: dict[str, Any]) -> dict[str, Any]:
    detached = deepcopy(snapshot)
    try:
        value = {"schema": SCHEMA, "snapshot": detached, "snapshot_sha256": hashlib.sha256(canonical(detached)).hexdigest()}
    except (ValueError, TypeError, OverflowError, RecursionError):
        raise ContinuousClientError("CLIENT_RESPONSE") from None
    return validate_source_envelope(value)


def source_guard(envelope: dict[str, Any]) -> dict[str, Any]:
    value = validate_source_envelope(envelope)
    availability = value["snapshot"]["model_availability"]
    return {key: availability[key] for key in ("source_generation", "twin_id", "twin_version")} | {"snapshot_sha256": value["snapshot_sha256"]}


def validate_source_guard(value: Any) -> dict[str, Any]:
    try:
        if not isinstance(value, dict) or set(value) != _GUARD_FIELDS:
            raise ValueError
        identifier(value["source_generation"])
        if type(value["twin_version"]) is not int or not 0 <= value["twin_version"] <= 2 ** 53 - 1:
            raise ValueError
        if value["twin_id"] is None:
            if value["twin_version"] != 0:
                raise ValueError
        else:
            identifier(value["twin_id"])
            if value["twin_version"] < 1:
                raise ValueError
        if not isinstance(value["snapshot_sha256"], str) or not _HASH.fullmatch(value["snapshot_sha256"]):
            raise ValueError
        return deepcopy(value)
    except (TypeError, ValueError, KeyError):
        raise ContinuousClientError("CLIENT_INVALID", status=422) from None


class CurrentSourceClient(ContinuousExecutionClient):
    mode = "attach"

    def _url(self) -> str:
        from .. import registry
        return os.environ.get("LIVEMORE_AEGLE_URL", "").strip() or registry.url_of("Aegle") or "http://127.0.0.1:8850"

    def read_source(self) -> dict[str, Any]:
        value = self._continuous_request("GET", "/api/cendos/current-source", timeout=10, expected_status=200)
        request_id = self.last_continuous_response.get("request_id")
        if not isinstance(request_id, str) or not _UUID.fullmatch(request_id):
            raise ContinuousClientError("CLIENT_RESPONSE")
        try:
            return validate_source_envelope(value)
        except ContinuousClientError:
            raise ContinuousClientError("CLIENT_RESPONSE", request_id=request_id) from None


class CurrentAssayClient(ContinuousExecutionClient):
    mode = "attach"

    def _url(self) -> str:
        from .. import registry
        return os.environ.get("LIVEMORE_CENDOS_URL", "").strip() or registry.url_of("Cendos") or "http://127.0.0.1:8852"

    def assay(self, body: dict[str, Any]) -> dict[str, Any]:
        return self._continuous_request("POST", "/assay/current", body, timeout=25)


def source_failure_response(error: ContinuousClientError):
    from fastapi.responses import JSONResponse

    status = (409 if error.code in {"MODEL_BINDING_REQUIRED", "MODEL_CONTEXT_INVALID", "MODEL_CONTEXT_UNSUPPORTED",
                                    "MODEL_CONTEXT_SOURCE_MISMATCH", "MODEL_SOURCE_CHANGED"}
              else 422 if error.code == "CLIENT_INVALID" else 503)
    headers = {"Cache-Control": "no-store"}
    if error.request_id:
        headers["X-Request-ID"] = error.request_id
    return JSONResponse({"code": error.code, "error": str(error)}, status_code=status, headers=headers)
