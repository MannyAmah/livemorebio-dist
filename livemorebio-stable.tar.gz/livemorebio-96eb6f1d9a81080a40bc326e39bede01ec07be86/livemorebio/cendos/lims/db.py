"""
livemore.cendos_os.db — durable persistence for the Cendos Lab OS.

Real SQLite (stdlib, zero deps): everything the lab touches is a persisted,
barcoded, auditable object. Postgres/Supabase is a drop-in swap for scale — the
schema and access layer are written to port cleanly. This is the doc's #1
(persistence) + the LIMS entity model + audit/e-signature tables.
"""
from __future__ import annotations
import json
import os
import sqlite3
import time

DEFAULT_DB = os.environ.get("CENDOS_DB", os.path.expanduser("~/.livemore/cendos.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS donors(
  id TEXT PRIMARY KEY, sex TEXT, ancestry TEXT, dob TEXT, created TEXT, meta TEXT);
CREATE TABLE IF NOT EXISTS consents(
  id TEXT PRIMARY KEY, donor_id TEXT, scope TEXT, irb_protocol TEXT, signed_at TEXT, meta TEXT);
CREATE TABLE IF NOT EXISTS twins(
  id TEXT PRIMARY KEY, human_id TEXT, kind TEXT, data_class TEXT, version TEXT,
  disease_module TEXT, created TEXT, meta TEXT);
CREATE TABLE IF NOT EXISTS biospecimens(
  id TEXT PRIMARY KEY, donor_id TEXT, type TEXT, collected_at TEXT, storage TEXT,
  chain_of_custody TEXT, meta TEXT);
CREATE TABLE IF NOT EXISTS organoids(
  id TEXT PRIMARY KEY, biospecimen_id TEXT, twin_id TEXT, organoid_type TEXT,
  mutation_context TEXT, passage INTEGER, culture_status TEXT, qc_status TEXT,
  linked_aegle_model TEXT, created TEXT, meta TEXT);
CREATE TABLE IF NOT EXISTS plates(
  id TEXT PRIMARY KEY, experiment_id TEXT, rows INTEGER, cols INTEGER, layout TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS wells(
  id TEXT PRIMARY KEY, plate_id TEXT, row INTEGER, col INTEGER, organoid_id TEXT,
  compound_id TEXT, dose REAL, role TEXT);
CREATE TABLE IF NOT EXISTS plant_sources(
  id TEXT PRIMARY KEY, species TEXT, common_name TEXT, part TEXT, authentication TEXT,
  created TEXT, meta TEXT);
CREATE TABLE IF NOT EXISTS extraction_batches(
  id TEXT PRIMARY KEY, plant_source_id TEXT, solvent TEXT, method TEXT, yield_mg REAL,
  created TEXT, meta TEXT);
CREATE TABLE IF NOT EXISTS compounds(
  id TEXT PRIMARY KEY, name TEXT, source TEXT, pubchem_cid TEXT, chembl_id TEXT,
  formula TEXT, mw REAL, smiles TEXT, inchikey TEXT, extraction_batch_id TEXT, meta TEXT);
CREATE TABLE IF NOT EXISTS compound_annotations(
  id TEXT PRIMARY KEY, compound_id TEXT, target TEXT, pathway TEXT, disease TEXT,
  score REAL, evidence_type TEXT, meta TEXT);
CREATE TABLE IF NOT EXISTS protocols(
  id TEXT PRIMARY KEY, name TEXT, version TEXT, sop TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS experiments(
  id TEXT PRIMARY KEY, twin_id TEXT, disease_module TEXT, hypothesis TEXT, protocol_id TEXT,
  status TEXT, created TEXT, meta TEXT);
CREATE TABLE IF NOT EXISTS experiment_runs(
  id TEXT PRIMARY KEY, experiment_id TEXT, plate_id TEXT, model TEXT, started TEXT,
  finished TEXT, result TEXT);
CREATE TABLE IF NOT EXISTS instruments(
  id TEXT PRIMARY KEY, name TEXT, kind TEXT, status TEXT);
CREATE TABLE IF NOT EXISTS results(
  id TEXT PRIMARY KEY, experiment_run_id TEXT, readout TEXT, value REAL, unit TEXT,
  evidence_type TEXT, imported_from TEXT, created TEXT, meta TEXT);
CREATE TABLE IF NOT EXISTS qc_events(
  id TEXT PRIMARY KEY, object_id TEXT, object_type TEXT, status TEXT, note TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS model_predictions(
  id TEXT PRIMARY KEY, twin_id TEXT, prediction TEXT, value REAL, confidence REAL,
  evidence_card TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS calibration_events(
  id TEXT PRIMARY KEY, twin_id TEXT, experiment_id TEXT, direction TEXT, payload TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS audit_logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT, action TEXT, object_id TEXT,
  object_type TEXT, detail TEXT, ts TEXT);
CREATE TABLE IF NOT EXISTS electronic_signatures(
  id TEXT PRIMARY KEY, object_id TEXT, object_type TEXT, signer TEXT, meaning TEXT,
  hash TEXT, signed_at TEXT);
"""


class DB:
    def __init__(self, path=None):
        path = path or os.environ.get("CENDOS_DB") or DEFAULT_DB
        os.makedirs(os.path.dirname(path), exist_ok=True) if os.path.dirname(path) else None
        self.path = path
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def insert(self, table, **cols):
        cols.setdefault("meta", "{}") if "meta" in _colnames(self.conn, table) else None
        keys = ",".join(cols)
        qs = ",".join("?" * len(cols))
        self.conn.execute(f"INSERT OR REPLACE INTO {table}({keys}) VALUES({qs})", list(cols.values()))
        self.conn.commit()
        return cols.get("id")

    def get(self, table, id):
        r = self.conn.execute(f"SELECT * FROM {table} WHERE id=?", (id,)).fetchone()
        return dict(r) if r else None

    def query(self, table, **where):
        sql = f"SELECT * FROM {table}"
        vals = []
        if where:
            sql += " WHERE " + " AND ".join(f"{k}=?" for k in where)
            vals = list(where.values())
        return [dict(r) for r in self.conn.execute(sql, vals).fetchall()]

    def count(self, table):
        return self.conn.execute(f"SELECT COUNT(*) c FROM {table}").fetchone()["c"]

    def log(self, actor, action, object_id="", object_type="", detail=""):
        self.conn.execute(
            "INSERT INTO audit_logs(actor,action,object_id,object_type,detail,ts) VALUES(?,?,?,?,?,?)",
            (actor, action, object_id, object_type, detail, time.strftime("%Y-%m-%dT%H:%M:%S")))
        self.conn.commit()

    def tables(self):
        return [r["name"] for r in self.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]


def _colnames(conn, table):
    return [r["name"] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]
