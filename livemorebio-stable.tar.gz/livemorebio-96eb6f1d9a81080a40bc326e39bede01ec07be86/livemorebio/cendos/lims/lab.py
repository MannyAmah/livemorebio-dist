"""
livemorebio.cendos.lims.lab — the Cendos Lab OS operating layer.

Every physical object (donor → biospecimen → organoid → plate/well → result) is
registered, barcoded, QC'd, and linked to its Aegle twin, with an audit trail and
electronic signatures. The Aegle↔Cendos link is bidirectional and first-class:
Aegle sends a hypothesis and Cendos returns governed measurements.  No result
updates a live twin without the evidence service's explicit authorization gate.
"""
from __future__ import annotations
import json
import time
from .db import DB
from .records import new_id, Evidence


class CendosLabOS:
    def __init__(self, db=None, actor="cendos"):
        self.db = db or DB()
        self.actor = actor

    # ---- specimen & biobank (System 2) -------------------------------------
    def register_donor(self, sex="F", ancestry="EUR", dob="", **meta):
        did = new_id("DONOR")
        self.db.insert("donors", id=did, sex=sex, ancestry=ancestry, dob=dob,
                       created=_now(), meta=json.dumps(meta))
        self.db.log(self.actor, "register_donor", did, "donor")
        return did

    def add_consent(self, donor_id, scope="research_use_only", irb_protocol="PENDING"):
        cid = new_id("CONSENT")
        self.db.insert("consents", id=cid, donor_id=donor_id, scope=scope,
                       irb_protocol=irb_protocol, signed_at=_now(), meta="{}")
        self.db.log(self.actor, "consent", cid, "consent", scope)
        return cid

    def register_biospecimen(self, donor_id, type="blood", storage="LN2-A"):
        bid = new_id("BIO")
        self.db.insert("biospecimens", id=bid, donor_id=donor_id, type=type,
                       collected_at=_now(), storage=storage,
                       chain_of_custody=json.dumps([{"at": _now(), "by": self.actor, "loc": storage}]),
                       meta="{}")
        self.db.log(self.actor, "accession_biospecimen", bid, "biospecimen")
        return bid

    # ---- organoids (System 4) ----------------------------------------------
    def create_organoid(self, biospecimen_id, organoid_type, twin_id="",
                        mutation_context=None, passage=0, linked_aegle_model=""):
        oid = new_id("ORG")
        self.db.insert("organoids", id=oid, biospecimen_id=biospecimen_id, twin_id=twin_id,
                       organoid_type=organoid_type,
                       mutation_context=json.dumps(mutation_context or []),
                       passage=passage, culture_status="active", qc_status="pending",
                       linked_aegle_model=linked_aegle_model, created=_now(), meta="{}")
        self.db.log(self.actor, "create_organoid", oid, "organoid", organoid_type)
        return oid

    def qc(self, object_id, object_type, status="passed", note=""):
        qid = new_id("QC")
        self.db.insert("qc_events", id=qid, object_id=object_id, object_type=object_type,
                       status=status, note=note, created=_now())
        if object_type == "organoid":
            o = self.db.get("organoids", object_id)
            if o:
                self.db.insert("organoids", **{**o, "qc_status": status})
        self.db.log(self.actor, "qc", object_id, object_type, status)
        return qid

    # ---- plant sources, extraction, compounds (System 3) -------------------
    def register_plant_source(self, species, common_name="", part="leaf", authentication="voucher-pending"):
        pid = new_id("PLANT")
        self.db.insert("plant_sources", id=pid, species=species, common_name=common_name,
                       part=part, authentication=authentication, created=_now(), meta="{}")
        self.db.log(self.actor, "register_plant", pid, "plant_source", species)
        return pid

    def create_extraction_batch(self, plant_source_id, solvent="ethanol", method="maceration", yield_mg=0.0):
        eid = new_id("EXT")
        self.db.insert("extraction_batches", id=eid, plant_source_id=plant_source_id,
                       solvent=solvent, method=method, yield_mg=yield_mg, created=_now(), meta="{}")
        self.db.log(self.actor, "extraction", eid, "extraction_batch")
        return eid

    def register_compound(self, name, source="synthetic", pubchem_cid="", chembl_id="",
                         formula="", mw=0.0, smiles="", inchikey="", extraction_batch_id=""):
        cid = new_id("CMP")
        self.db.insert("compounds", id=cid, name=name, source=source, pubchem_cid=str(pubchem_cid),
                       chembl_id=chembl_id, formula=formula, mw=mw, smiles=smiles,
                       inchikey=inchikey, extraction_batch_id=extraction_batch_id, meta="{}")
        self.db.log(self.actor, "register_compound", cid, "compound", name)
        return cid

    def annotate_compound(self, compound_id, target="", pathway="", disease="", score=0.0,
                         evidence_type=Evidence.LITERATURE):
        aid = new_id("ANN")
        self.db.insert("compound_annotations", id=aid, compound_id=compound_id, target=target,
                       pathway=pathway, disease=disease, score=score, evidence_type=evidence_type, meta="{}")
        return aid

    # ---- experiments & plates (System 1) -----------------------------------
    def create_protocol(self, name, version="v0", sop=""):
        pid = new_id("PROTO")
        self.db.insert("protocols", id=pid, name=name, version=version, sop=sop, created=_now())
        return pid

    def design_experiment(self, twin_id, disease_module, hypothesis, protocol_id=""):
        eid = new_id("CEN-EXP")
        self.db.insert("experiments", id=eid, twin_id=twin_id, disease_module=disease_module,
                       hypothesis=hypothesis, protocol_id=protocol_id, status="designed",
                       created=_now(), meta="{}")
        self.db.log(self.actor, "design_experiment", eid, "experiment", disease_module)
        return eid

    def build_plate(self, experiment_id, rows=8, cols=12, wells=None):
        pid = new_id("PLATE")
        self.db.insert("plates", id=pid, experiment_id=experiment_id, rows=rows, cols=cols,
                       layout=json.dumps(wells or []), created=_now())
        for w in (wells or []):
            self.db.insert("wells", id=new_id("WELL"), plate_id=pid, row=w.get("row", 0),
                           col=w.get("col", 0), organoid_id=w.get("organoid_id", ""),
                           compound_id=w.get("compound_id", ""), dose=w.get("dose", 0.0),
                           role=w.get("role", "sample"))
        return pid

    def run_experiment(self, experiment_id, baseline=None, treated=None, grams=75.0,
                       hours=4.0, plate_id="", model="in_silico"):
        """Execute the real in-silico Cendos OGTT assay and persist the run + readouts.

        ``baseline``/``treated`` are mechanistic MetabolicProfile objects
        (Bergman glucose–insulin engine). The persisted readouts are the
        assay's real outputs (delta_mean mg/dL, delta_iAUC mg/dL·min,
        rel_mean fraction) — model-only hypothesis triage, flagged as such.
        """
        rid = new_id("RUN")
        result = {}
        if baseline is not None and treated is not None:
            from ..assays import ogtt_effect
            result = ogtt_effect(baseline, treated, grams=grams, hours=hours)
        self.db.insert("experiment_runs", id=rid, experiment_id=experiment_id, plate_id=plate_id,
                       model=model, started=_now(), finished=_now(), result=json.dumps(result))
        for readout, unit in (("delta_mean", "mg/dL"), ("delta_iAUC", "mg/dL*min"),
                              ("rel_mean", "fraction")):
            if readout in result and result[readout] is not None:
                self.db.insert("results", id=new_id("RES"), experiment_run_id=rid, readout=readout,
                               value=float(result[readout]), unit=unit,
                               evidence_type=Evidence.EXPERIMENT, imported_from=model,
                               created=_now(), meta=json.dumps({"decision": result.get("decision"),
                                                                "note": result.get("note")}))
        exp = self.db.get("experiments", experiment_id)
        if exp:
            self.db.insert("experiments", **{**exp, "status": "run"})
        self.db.log(self.actor, "run_experiment", rid, "experiment_run", model)
        return rid, result

    def record_run(self, experiment_id, result, model="in_silico", plate_id=""):
        """Persist an already-computed experiment result (run + readouts)."""
        rid = new_id("RUN")
        self.db.insert("experiment_runs", id=rid, experiment_id=experiment_id, plate_id=plate_id,
                       model=model, started=_now(), finished=_now(), result=json.dumps(result))
        for k in ("efficacy", "toxicity"):
            if k in result and result[k] is not None:
                self.db.insert("results", id=new_id("RES"), experiment_run_id=rid, readout=k,
                               value=float(result[k]), unit="fraction",
                               evidence_type=Evidence.EXPERIMENT, imported_from=model,
                               created=_now(), meta="{}")
        exp = self.db.get("experiments", experiment_id)
        if exp:
            self.db.insert("experiments", **{**exp, "status": "run"})
        self.db.log(self.actor, "record_run", rid, "experiment_run", model)
        return rid

    def import_result(self, experiment_run_id, readout, value, unit="", evidence_type=Evidence.MEASURED,
                     imported_from="instrument"):
        rid = new_id("RES")
        self.db.insert("results", id=rid, experiment_run_id=experiment_run_id, readout=readout,
                       value=value, unit=unit, evidence_type=evidence_type,
                       imported_from=imported_from, created=_now(), meta="{}")
        self.db.log(self.actor, "import_result", rid, "result", readout)
        return rid

    # ---- Aegle ↔ Cendos calibration contract (System / Section 7) ----------
    def hypothesis_from_aegle(self, twin_id, disease_module, hypothesis, target_pathways,
                             candidate_compounds, recommended_model, recommended_assays, priority="high"):
        """Aegle → Cendos: persist a hypothesis and open an experiment."""
        payload = dict(twin_id=twin_id, disease_module=disease_module, hypothesis=hypothesis,
                       target_pathways=target_pathways, candidate_compounds=candidate_compounds,
                       recommended_model=recommended_model, recommended_assays=recommended_assays,
                       priority=priority)
        ce = new_id("CAL")
        self.db.insert("calibration_events", id=ce, twin_id=twin_id, experiment_id="",
                       direction="aegle->cendos", payload=json.dumps(payload), created=_now())
        exp = self.design_experiment(twin_id, disease_module, hypothesis)
        self.db.log(self.actor, "aegle_hypothesis", exp, "experiment", disease_module)
        return dict(calibration_event=ce, experiment_id=exp, payload=payload)

    def calibration_to_aegle(self, twin_id, experiment_id, observed_effect, model_update,
                            recommendation="repeat_with_dose_response", evidence_strength="early_in_vitro"):
        """Refuse the legacy direct-update path.

        Callers must add qualified counterpart measurements and validation
        events to an evidence package, then use ``EvidenceService.authorize_calibration``.
        """
        from ...evidence import CalibrationDeniedError

        raise CalibrationDeniedError(
            "Cendos cannot directly update Aegle; evidence authorization is required"
        )

    def experiment_history(self, twin_id):
        return self.db.query("experiments", twin_id=twin_id)

    def sign(self, object_id, object_type, signer, meaning="reviewed"):
        import hashlib
        sid = new_id("SIG")
        h = hashlib.sha256(f"{object_id}{signer}{_now()}".encode()).hexdigest()[:16]
        self.db.insert("electronic_signatures", id=sid, object_id=object_id, object_type=object_type,
                       signer=signer, meaning=meaning, hash=h, signed_at=_now())
        self.db.log(signer, "esign", object_id, object_type, meaning)
        return sid

    def inventory(self):
        return {t: self.db.count(t) for t in ("donors", "biospecimens", "organoids", "plant_sources",
                "extraction_batches", "compounds", "compound_annotations", "experiments",
                "experiment_runs", "results", "calibration_events", "qc_events",
                "electronic_signatures", "audit_logs")}


def _now():
    return time.strftime("%Y-%m-%dT%H:%M:%S")
