"""Initial-rate sensitivity at a rat-vesicle assay interface, not human biology.

An original implementation of competitive Michaelis–Menten transport using a
minimal cited numerical record. No article, figure, author software, patient
data, kinetic trajectory or physiological coupling is included.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import math
from typing import Any
import uuid


PROTOCOL_ID = "cendos.lobeline-vmat2-initial-rate.v1"
MATERIAL_ID = "lobeline-hemisulfate"
CONTEXT_ID = "rat-striatal-synaptic-vesicles"
UNIT = "pmol/min/mg protein"
EQUATION = "v = Vmax * S / (Km * (1 + I / Ki) + S)"
_KM = 0.11
_VMAX = 46.7
_KI = 0.47
_SOURCE = {
    "schema": "livemore.cendos.parameter-source.v1",
    "record_id": "nickell-2010-vmat2-lobeline-extraction-v1",
    "extraction_version": "2026-09-08.1",
    "publication": {
        "title": "Lobelane Inhibits Methamphetamine-Evoked Dopamine Release via Inhibition of the Vesicular Monoamine Transporter-2",
        "authors": "Nickell et al.", "year": 2010,
        "doi": "10.1124/jpet.109.160275",
        "url": "https://doi.org/10.1124/jpet.109.160275",
        "pmcid": "PMC2812121",
        "location": "Methods: materials and vesicular dopamine uptake; Results: inhibition of dopamine uptake into rat striatal synaptic vesicles, Figure 5 and kinetic-analysis paragraph",
    },
    "rights": {
        "included": "Minimal cited numerical facts and original equation implementation only",
        "excluded": "Article text, figures, full tables, supplementary files and author software are not redistributed",
        "article_redistribution_license": "NOT_ESTABLISHED",
    },
    "context": {
        "material_id": MATERIAL_ID, "assay_material": "lobeline hemisulfate",
        "concentration_basis": "reported nominal assay concentration; not measured free human exposure",
        "context_id": CONTEXT_ID, "species": "rat", "tissue": "striatum",
        "preparation": "isolated synaptic vesicles", "target": "VMAT2",
        "target_identifier_context": "vesicular monoamine transporter 2, not a supplied atomistic structure",
        "endpoint": "specific dopamine uptake rate per mg protein",
        "incubation_duration_min": 8,
        "measurement_basis": "radiotracer uptake assay endpoint normalized per minute; not a measured instantaneous trajectory",
    },
    "parameters": {
        "km_um": {"value": _KM, "unit": "uM", "reported_sem": .0081,
                  "role": "control kinetic fit", "evidence": "PUBLISHED_PARAMETER_SUMMARY"},
        "vmax": {"value": _VMAX, "unit": UNIT, "reported_sem": 7.92,
                 "role": "control kinetic fit", "evidence": "PUBLISHED_PARAMETER_SUMMARY"},
        "ki_um": {"value": _KI, "unit": "uM", "reported_sem": None,
                  "role": "functional uptake inhibition estimate, not binding affinity",
                  "evidence": "PUBLISHED_PARAMETER_SUMMARY"},
    },
    "kinetic_comparator": {
        "inhibitor_um": .25, "apparent_km_um": .29, "apparent_km_sem_um": .064,
        "vmax": 50.2, "vmax_sem": 7.80, "evidence": "PUBLISHED_PARAMETER_SUMMARY",
        "independence": "separate kinetic analysis in the same paper; not an independent laboratory replication",
        "raw_replicates": None, "parameter_covariance": None, "acceptance_criterion": None,
    },
    "model": {
        "id": "competitive-initial-rate", "version": "1", "equation": EQUATION,
        "assumptions": ["Competitive inhibition changes apparent Km while preserving the model Vmax.",
                        "A stationary initial-rate assay relation is evaluated, not substrate depletion or transport time kinetics.",
                        "Source parameter estimates are reused without fitting; their cross-assay inconsistency is retained."],
        "domain": {"substrate_um": [0.001, 5.0], "inhibitor_um": [0.0, .25],
                   "zero_substrate": "analytic negative control only",
                   "inhibitor_domain_basis": "sensitivity within control-to-published-kinetic-condition interval, not a validated exposure range"},
    },
}


class LobelineProtocolError(ValueError):
    """A bounded public error; request data are not echoed."""

    code = "INVALID_LOBELINE_SPECIFICATION"


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode("utf-8")).hexdigest()


def source_record() -> dict[str, Any]:
    """Return detached source facts, not a claimed digest of the original article."""
    return deepcopy(_SOURCE)


def _number(value: object) -> float:
    if type(value) not in (float, int):
        raise LobelineProtocolError("concentrations require finite numbers, not booleans or strings")
    try:
        number = float(value)
    except (OverflowError, ValueError) as error:
        raise LobelineProtocolError("concentration is outside the numerical domain") from error
    if not math.isfinite(number) or not 0 <= number <= 1e12:
        raise LobelineProtocolError("concentration is outside the numerical domain")
    return number


def initial_rate(substrate_um: float, inhibitor_um: float) -> float:
    """Evaluate the analytic relation; public runs impose a narrower assay domain."""
    substrate, inhibitor = _number(substrate_um), _number(inhibitor_um)
    return _VMAX * substrate / (_KM * (1.0 + inhibitor / _KI) + substrate)


def validate_spec(value: object) -> dict[str, Any]:
    required = {"material_id", "context_id", "concentration_unit",
                "substrate_concentrations", "inhibitor_concentrations"}
    if not isinstance(value, dict) or set(value) != required:
        raise LobelineProtocolError("supply only material, assay context, units and both concentration arrays")
    if value["material_id"] != MATERIAL_ID or value["context_id"] != CONTEXT_ID:
        raise LobelineProtocolError("only the source lobeline material and nonhuman vesicle context are supported")
    if not isinstance(value["concentration_unit"], str) or value["concentration_unit"] not in {"uM", "nM"}:
        raise LobelineProtocolError("concentration unit must be uM or nM")
    divisor = 1000.0 if value["concentration_unit"] == "nM" else 1.0
    normalized: dict[str, list[float]] = {}
    for field, maximum in (("substrate_concentrations", 200), ("inhibitor_concentrations", 8)):
        raw = value[field]
        if not isinstance(raw, list) or not 2 <= len(raw) <= maximum:
            raise LobelineProtocolError("concentration arrays require bounded distinct conditions")
        numbers = [_number(item) / divisor for item in raw]
        if len(set(numbers)) != len(numbers):
            raise LobelineProtocolError("duplicate concentration conditions are not independent observations")
        normalized[field] = sorted(numbers)
    substrate, inhibitor = normalized["substrate_concentrations"], normalized["inhibitor_concentrations"]
    if any(number != 0 and not .001 <= number <= 5.0 for number in substrate):
        raise LobelineProtocolError("substrate must be 0.001 to 5 uM, or zero for the analytic control")
    if any(number > .25 for number in inhibitor) or 0.0 not in inhibitor or .25 not in inhibitor:
        raise LobelineProtocolError("include control 0 and reference 0.25 uM within that inhibitor interval")
    return {"material_id": MATERIAL_ID, "context_id": CONTEXT_ID,
            "concentration_unit": "uM", **normalized}


def run_lobeline_vmat2(spec: object) -> dict[str, Any]:
    """Freeze one deterministic concentration-axis calculation; no twin is consulted."""
    normalized = validate_spec(spec)
    source = source_record()
    conditions = []
    for index, inhibitor in enumerate(normalized["inhibitor_concentrations"]):
        points = []
        for substrate in normalized["substrate_concentrations"]:
            rate = initial_rate(substrate, inhibitor)
            control = initial_rate(substrate, 0)
            points.append({"substrate_um": substrate, "initial_rate": rate,
                           "control_rate": control, "rate_fraction": rate / control if control else None})
        conditions.append({"condition_id": f"lobeline-condition-{index + 1}",
                           "inhibitor_um": inhibitor, "apparent_km_um": _KM * (1 + inhibitor / _KI),
                           "points": points})
    comparator = source["kinetic_comparator"]
    predicted_km = _KM * (1 + comparator["inhibitor_um"] / _KI)
    controls = [
        {"control_id": "zero_substrate", "value": initial_rate(0, .25), "expected": 0.0,
         "passed": initial_rate(0, .25) == 0},
        {"control_id": "uninhibited_half_maximum", "value": initial_rate(_KM, 0), "expected": _VMAX / 2,
         "passed": math.isclose(initial_rate(_KM, 0), _VMAX / 2, rel_tol=1e-12)},
        {"control_id": "nonnegative_and_vmax_bounded", "passed": all(
            0 <= point["initial_rate"] <= _VMAX for row in conditions for point in row["points"])},
    ]
    return {
        "schema": "livemore.cendos-protocol-result.v1", "protocol_id": PROTOCOL_ID,
        "run_id": "protocol-" + uuid.uuid4().hex,
        "executed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "input": normalized, "input_sha256": canonical_hash(normalized),
        "source_record": source, "source_sha256": canonical_hash(source),
        "source_hash_semantics": "digest of this minimal extracted parameter/model record, not the original article",
        "endpoint": "initial_dopamine_uptake_rate", "unit": UNIT,
        "native_axis": {"quantity": "substrate_concentration", "unit": "uM", "time_evolution": False},
        "conditions": conditions, "controls": controls,
        "benchmark_discrepancy": {
            "comparator": "same-paper published kinetic summary, not independent qualification data",
            "inhibitor_um": comparator["inhibitor_um"], "predicted_apparent_km_um": predicted_km,
            "reported_apparent_km_um": comparator["apparent_km_um"],
            "reported_apparent_km_sem_um": comparator["apparent_km_sem_um"],
            "difference_um": predicted_km - comparator["apparent_km_um"],
            "parameters_refitted": False, "status": "UNQUALIFIED_DISCREPANCY",
            "statistical_assessment": "UNAVAILABLE_WITHOUT_RAW_DATA_AND_PRESPECIFIED_CRITERION",
        },
        "scope": "nonhuman_assay_reference", "evidence_state": "MODELED_INITIAL_RATE",
        "qualification_state": "NOT_QUALIFIED", "calibration_authorized": False,
        "live_twin_modified": False, "physical_validation": "UNAVAILABLE",
        "claims_allowed": ["source-parameterized competitive transport sensitivity", "visible cross-assay parameter discrepancy"],
        "claims_prohibited": ["human or personalized response", "whole-plant effect", "clinical benefit", "atomistic dynamics", "time-course transport", "physical observation"],
        "limitations": ["Conditions are not people, independent specimens or technical replicates.",
                        "Parameter SEM is not a person-specific distribution or a validation tolerance.",
                        "Raw replicate data and parameter covariance are unavailable; no statistical qualification is computed.",
                        "Concentration is nominal assay concentration; salt-to-free-base mass conversion and human exposure are not modeled.",
                        "Only a stationary initial-rate relation is computed; vesicle energetics, depletion, efflux and full cellular biology are absent."],
    }
