"""A frozen generic-network capacity experiment, not an individual human assay."""
from datetime import datetime, timezone
import uuid

from ..engines import stoichiometry

PROTOCOL_ID = "cendos.human-gem-oxygen-capacity.v1"


def run_human_gem_oxygen_capacity(spec: dict) -> dict:
    normalized = stoichiometry.validate_spec(spec)
    output = stoichiometry.execute(normalized)
    return {
        "schema": "livemore.cendos-protocol-result.v1", "protocol_id": PROTOCOL_ID,
        "run_id": "protocol-" + uuid.uuid4().hex,
        "executed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "input": normalized, "input_sha256": stoichiometry.canonical_hash(normalized),
        "endpoint": "atp_maintenance_capacity", "unit": stoichiometry.UNIT,
        "model": output["model"], "conditions": output["conditions"], "controls": output["controls"],
        "solver": output["solver"], "elapsed_computation_seconds": output.get("elapsed_computation_seconds"),
        "reference_provenance": output.get("reference_provenance", {}),
        "scope": "generic_human_reference_network",
        "evidence_state": "MODELED_STEADY_STATE", "qualification_state": "NOT_QUALIFIED",
        "physical_validation": "UNAVAILABLE_PENDING_CELL_ASSAY_CONTEXT",
        "calibration_authorized": False,
        "scientific_contract": {
            "equations": "S*v=0; lower_bounds<=v<=upper_bounds; maximize ATP maintenance flux",
            "objective_reaction": stoichiometry.ATP_OBJECTIVE,
            "exchange_reactions": {"glucose": stoichiometry.GLUCOSE_EXCHANGE, "oxygen": stoichiometry.OXYGEN_EXCHANGE},
            "boundary_policy": "only requested glucose and oxygen uptake; all other producing boundaries closed",
            "intervention_policy": "exact complete GPR-aware gene knockouts only",
            "time": "steady-state comparison; no time evolution computed",
            "individualization": "none; conditions describe one generic network, not people",
        },
        "claims_allowed": ["conditional stoichiometric ATP capacity", "numerical conservation and constraint checks"],
        "claims_prohibited": ["measured human response", "ATP concentration", "unique flux prediction",
                              "drug efficacy", "patient-specific physiology", "clinical validation"],
        "limitations": ["The maximizing objective is an explicit research assumption, not evidence of a cell's operating state.",
                        "Selected fluxes are one optimal solution; FVA and kinetic evolution were not computed.",
                        "Physical comparison requires a separately reviewed cell/assay context and normalization."],
    }
