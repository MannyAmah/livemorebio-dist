"""Qualified Cendos wet-lab counterpart measurements for evidence review."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal

from ..evidence import (
    AssessmentStatus,
    CounterpartMeasurement,
    MeasurementEnvelope,
    MeasurementRole,
    SourceDataClass,
)
from ..evidence.errors import DomainValidationError


@dataclass(frozen=True)
class LabResult:
    result_id: str
    subject_id: str
    endpoint: str
    value: float
    unit: str
    measured_at: datetime
    received_at: datetime
    instrument_id: str
    method: str
    quality_status: AssessmentStatus
    calibration_status: AssessmentStatus
    chain_of_custody: tuple[str, ...]
    consent_scope: tuple[str, ...]


def to_evidence_measurement(
    result: LabResult,
    *,
    tenant_id: str,
    sequence: int,
) -> MeasurementEnvelope:
    """Create a counterpart outcome; policy review still decides validation."""
    from ..life_patch.protocol import pseudonymous_subject_id

    subject_id = pseudonymous_subject_id(result.subject_id)
    if result.quality_status is not AssessmentStatus.PASS:
        raise DomainValidationError("qualified lab counterpart requires passing QC")
    if result.calibration_status is not AssessmentStatus.PASS:
        raise DomainValidationError("qualified lab counterpart requires current instrument calibration")
    if not result.chain_of_custody:
        raise DomainValidationError("qualified lab counterpart requires chain of custody")
    if not result.consent_scope:
        raise DomainValidationError("qualified lab counterpart requires explicit consent scope")
    payload = CounterpartMeasurement(
        endpoint=result.endpoint,
        value=Decimal(str(result.value)),
        unit=result.unit,
        source_data_class=SourceDataClass.QUALIFIED_LAB,
        measured_at=result.measured_at,
        quality_status=result.quality_status,
        calibration_status=result.calibration_status,
        consent_scope=result.consent_scope,
        device_id="cendos-wet-lab",
        instrument_id=result.instrument_id,
        method=result.method,
        chain_of_custody=result.chain_of_custody,
    )
    return MeasurementEnvelope(
        schema_version="livemore.measurement-envelope.v1",
        envelope_id=result.result_id,
        tenant_id=tenant_id,
        counterpart_id=subject_id,
        role=MeasurementRole.COUNTERPART_OUTCOME,
        subject_pseudonymized=True,
        sequence=sequence,
        received_at=result.received_at,
        payload=payload,
    )
