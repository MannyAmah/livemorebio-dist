"""Executable exposure-margin programs for the five requested botanical candidates.

The question each program answers
---------------------------------
Does the modelled unbound exposure of a declared material, at a declared dose
and route, reach the concentration range at which that material's declared
mechanism was actually measured?

That is a standard preclinical exposure-margin calculation. It is the smallest
question that is both executable from published sources and capable of a
negative answer. A margin below 1 is a real negative result and is reported as
such. Reaching the range supports designing the next experiment; it does not
establish efficacy, safety, or any human response.

Honesty rules enforced in code
------------------------------
* A purified marker compound is never treated as equivalent to an extract, a
  different plant part, or a salt or metabolite mixture. Each material record
  states its non-equivalence explicitly.
* A program with no admitted pharmacokinetic source cannot produce an exposure
  number. It returns ``EXPOSURE_SOURCE_NOT_ADMITTED`` and names the missing
  measurement. It is not approximated from a related compound.
* A program with no admitted active-concentration source computes exposure but
  refuses to compute a margin, returning ``ACTIVE_RANGE_NOT_ADMITTED``.
* Non-human pharmacokinetics never silently become human exposure. The species
  is carried on every row and ``human_exposure_admissible`` is false unless the
  source is a human study.

None of these programs is validated in vivo. Their status is unchanged by a
successful execution here.
"""
from __future__ import annotations

import hashlib
import json
import math
import random
import uuid
from datetime import datetime, timezone
from typing import Any

import numpy as np

PROTOCOL_ID = "cendos.botanical-exposure-margin.v1"
_ALLOMETRIC_EXPONENT = 0.75
_ALLOMETRY_NOTE = ("Clearance scaled between body weights with the conventional 0.75 allometric "
                   "exponent; this is a modelling convention, not a measurement in the target species.")


class BotanicalProgramError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        self.code = code
        super().__init__(message)


# --------------------------------------------------------------------------
# Program definitions. Every numeric value carries the source it came from.
# --------------------------------------------------------------------------
PROGRAMS: dict[str, dict[str, Any]] = {
    "LBHR-172": {
        "program_id": "LBHR-172",
        "entry_name": "Lion's Mane Mushroom",
        "question": ("Does oral erinacine A exposure from an erinacine-enriched mycelium preparation reach "
                     "a concentration at which an erinacine A mechanism has been measured?"),
        "material": {
            "material_id": "erinacine-A",
            "species": "Hericium erinaceus",
            "compound": "Erinacine A",
            "pubchem_cid": 10410568,
            "non_equivalence": ("Erinacine-enriched mycelium is not purified erinacine A, and neither is "
                                "equivalent to fruiting-body hericenone preparations."),
        },
        "pharmacokinetics": {
            "admitted": True,
            "species": "rat (Sprague-Dawley, male)",
            "model": "one-compartment first-order oral absorption",
            "reference_weight_kg": 0.29,
            "dose_basis": "50 mg/kg erinacine A equivalent delivered as mycelium extract",
            "bioavailability_F": 0.2439,
            "t_half_h": 491.22 / 60.0,
            "t_max_h": 360.0 / 60.0,
            "cmax_mg_per_L": 1.40,
            "fraction_unbound": 0.84,
            "molar_mass_g_per_mol": 432.5,
            "source": ("Tsai PC, Wu YK, Hu JH, et al. Molecules 2021;26(15):4510. "
                       "doi:10.3390/molecules26154510"),
            "derivation": ("Absorption and elimination rate constants derived from the published t-max and "
                           "half-life by the standard one-compartment relations; apparent volume derived from "
                           "the published C-max at the published dose. No parameter was fitted to any output "
                           "produced by this platform."),
            "caveats": ["Multiple plasma peaks were reported, which a one-compartment model cannot reproduce.",
                        "Brain concentrations were measured separately and are not predicted by this model."],
        },
        "active_range": {
            "admitted": False,
            "reason_code": "ACTIVE_RANGE_NOT_ADMITTED",
            "missing": ("A measured concentration-response for an erinacine A mechanism in a relevant human "
                        "neuronal or glial context. Published in vivo dose levels are not concentrations."),
        },
        "transfer_limits": [
            "Rat pharmacokinetics are not human pharmacokinetics.",
            "Plasma exposure is not brain exposure, even where brain penetration was demonstrated.",
        ],
    },
    "LBHR-129": {
        "program_id": "LBHR-129",
        "entry_name": "Yerba Santa",
        "question": ("Does sterubin exposure reach the concentration range at which its neuroprotective and "
                     "anti-inflammatory activity was measured in cells?"),
        "material": {
            "material_id": "sterubin",
            "species": "Eriodictyon californicum",
            "compound": "Sterubin",
            "pubchem_cid": 1268276,
            "non_equivalence": ("Yerba santa extract is not purified sterubin; sterubin is also not "
                                "interchangeable with the co-occurring flavanones eriodictyol or "
                                "homoeriodictyol, which differ in potency."),
        },
        "pharmacokinetics": {
            "admitted": False,
            "reason_code": "EXPOSURE_SOURCE_NOT_ADMITTED",
            "missing": ("A pharmacokinetic study of sterubin reporting clearance and volume, or C-max, t-max "
                        "and half-life, in any species, plus its unbound fraction. Without these, no exposure "
                        "can be computed and no margin can be claimed."),
            "species": None,
        },
        "active_range": {
            "admitted": True,
            "low_um": 1.0,
            "high_um": 5.0,
            "assay": ("HT22 mouse hippocampal cells (oxytosis, energy loss), MC65 human cells (intracellular "
                      "amyloid beta toxicity) and BV-2 microglia (lipopolysaccharide-induced mediators)"),
            "basis": ("Half-maximal effect concentrations below 5 micromolar across the reported assays, with "
                      "anti-inflammatory effects at 1 to 2 micromolar that shift above 10 micromolar when Nrf2 "
                      "is knocked down"),
            "source": ("Fischer W, Currais A, Liang Z, Pinto AFM, Maher P. Redox Biol 2019;21:101089. "
                       "doi:10.1016/j.redox.2018.101089"),
        },
        "transfer_limits": [
            "Immortalised cell lines are not human neurons or human microglia.",
            "A culture medium concentration is not a tissue concentration.",
        ],
    },
    "LBHR-062": {
        "program_id": "LBHR-062",
        "entry_name": "Rosemary",
        "question": ("Does carnosic acid exposure reach the concentration range at which its Keap1-Nrf2 "
                     "mechanism was measured?"),
        "material": {
            "material_id": "carnosic-acid",
            "species": "Rosmarinus officinalis (Salvia rosmarinus)",
            "compound": "Carnosic acid",
            "pubchem_cid": 65126,
            "non_equivalence": ("Rosemary extract is a mixture in which carnosic acid content varies by clonal "
                                "line and preparation; carnosic acid is also not carnosol or rosmarinic acid, "
                                "and it converts to carnosol under oxidation."),
        },
        "pharmacokinetics": {
            "admitted": False,
            "reason_code": "EXPOSURE_SOURCE_NOT_ADMITTED",
            "missing": ("Clearance and volume, or C-max with t-max and half-life, for carnosic acid. The "
                        "available rat study reports an oral bioavailability of about 40 percent over 360 "
                        "minutes but not the disposition parameters an exposure model requires. A single-"
                        "volunteer human assay method paper does not supply an admitted population parameter "
                        "set either."),
            "species": None,
            "partial_evidence": {
                "bioavailability_F": 0.401,
                "species": "rat",
                "source": ("Doolaege EHA, Raes K, De Vos F, Verhe R, De Smet S. Plant Foods Hum Nutr "
                           "2011;66(2):196-202. doi:10.1007/s11130-011-0233-5"),
            },
        },
        "active_range": {
            "admitted": False,
            "reason_code": "ACTIVE_RANGE_NOT_ADMITTED",
            "missing": ("A concentration-response for carnosic-acid-driven Keap1-Nrf2 activation with a "
                        "stated half-maximal concentration in a defined cell system. The mechanism is "
                        "documented qualitatively, including the requirement for both the free carboxylic "
                        "acid and the catechol hydroxyls, but the retained sources do not fix a usable "
                        "concentration range."),
            "mechanism_source": ("Satoh T, Izumi M, Inukai Y, et al. Neurosci Lett 2008;434(3):260-265. "
                                 "doi:10.1016/j.neulet.2008.01.079"),
        },
        "transfer_limits": [
            "A cell-free half-maximal concentration and a whole-blood value are not interchangeable.",
            "Any neural claim additionally requires central nervous system exposure evidence.",
        ],
    },
    "LBHR-030": {
        "program_id": "LBHR-030",
        "entry_name": "Greater Burdock",
        "question": ("Does oral arctigenin exposure reach the concentration range at which its AMP-activated "
                     "protein kinase activation and mitochondrial complex I inhibition were measured?"),
        "material": {
            "material_id": "arctigenin",
            "species": "Arctium lappa",
            "compound": "Arctigenin",
            "pubchem_cid": 64981,
            "non_equivalence": ("Arctiin is a precursor that is deglycosylated to arctigenin and is not the "
                                "same intervention; burdock fruit powder and an enriched extract are not "
                                "purified arctigenin. Arctigenin is extensively glucuronidated, and the "
                                "glucuronide is reported as inactive unless cleaved."),
        },
        "pharmacokinetics": {
            "admitted": True,
            "species": "piglet",
            "model": "one-compartment first-order oral absorption",
            "reference_weight_kg": 30.0,
            "dose_basis": "1 g/kg Fructus arctii powder by gavage",
            "clearance_L_per_h_per_kg": 0.076,
            "volume_L_per_kg": 1.680,
            "absorption_t_half_h": 0.274,
            "bioavailability_F": 1.0,
            "fraction_unbound": 0.05,
            "molar_mass_g_per_mol": 372.4,
            "source": ("He B, Zhang HJ, Yang W, et al. Front Vet Sci 2019;6:235. "
                       "doi:10.3389/fvets.2019.00235"),
            "unbound_source": ("Han XY, Wang W, Tan RQ, Dou DQ. Zhongguo Zhong Yao Za Zhi 2013;38(3):416-419. "
                               "PMID:23668024 (plasma protein binding about 95 to 98 percent in rat and human "
                               "plasma; the unbound fraction used here is the upper-bound five percent)"),
            "derivation": ("Apparent clearance and volume are the published oral values, so the reported "
                           "exposure is dose over apparent clearance and includes the unmeasured absorbed "
                           "fraction. Because bioavailability was not separated, F is carried as 1 and the "
                           "resulting exposure is an upper bound, not a best estimate."),
            "caveats": ["Piglet disposition is not human disposition.",
                        "A very long terminal phase was reported that a one-compartment model does not capture."],
        },
        "active_range": {
            "admitted": True,
            "low_um": 1.0,
            "high_um": 20.0,
            "assay": ("H9C2 and differentiated C2C12 muscle cells for AMP-activated protein kinase "
                      "phosphorylation, and PANC-1 cells for oxygen-consumption inhibition"),
            "basis": ("Dose-dependent AMP-activated protein kinase phosphorylation over 0 to 40 micromolar "
                      "with downstream gene induction at 10 to 40 micromolar, and clear inhibition of oxygen "
                      "consumption rate at 1 micromolar"),
            "source": ("Tang X, Zhuang J, Chen J, et al. PLoS One 2011;6(8):e24224. "
                       "doi:10.1371/journal.pone.0024224; Fujioka R, Mochizuki N, Ikeda M, et al. PLoS One "
                       "2018;13(5):e0198219. doi:10.1371/journal.pone.0198219"),
        },
        "transfer_limits": [
            "Complex I inhibition can coexist with energetic injury; reaching the range is not a benefit claim.",
            "Muscle and tumour cell lines are not human tissue, and a medium concentration is not a "
            "mitochondrial-site concentration.",
        ],
    },
    "LBHR-135": {
        "program_id": "LBHR-135",
        "entry_name": "Bilberry",
        "question": ("Does the parent anthocyanin cyanidin-3-glucoside itself reach the concentration range "
                     "at which anthocyanin activity was measured in human endothelial cells?"),
        "material": {
            "material_id": "cyanidin-3-glucoside",
            "species": "Vaccinium myrtillus",
            "compound": "Cyanidin-3-glucoside",
            "pubchem_cid": 441667,
            "non_equivalence": ("A bilberry batch is not purified cyanidin-3-glucoside; the flavylium cation "
                                "is not the chloride salt and not the mixture of pH-dependent species. The "
                                "parent compound degrades rapidly and much of the measured activity is "
                                "attributed to its metabolites, which this program does not model."),
        },
        "pharmacokinetics": {
            "admitted": True,
            "species": "human (eight healthy male participants)",
            "model": "one-compartment first-order oral absorption, parent compound only",
            "reference_weight_kg": 70.0,
            "dose_basis": "500 mg oral bolus of isotopically labelled cyanidin-3-glucoside",
            "t_half_h": 0.4,
            "t_max_h": 1.8,
            "cmax_nmol_per_L": 141.0,
            "fraction_unbound": 1.0,
            "molar_mass_g_per_mol": 449.2,
            "bioavailability_F": 1.0,
            "source": ("de Ferrars RM, Czank C, Zhang Q, et al. Br J Pharmacol 2014;171(13):3268-3282. "
                       "doi:10.1111/bph.12676; Czank C, Cassidy A, Zhang Q, et al. Am J Clin Nutr "
                       "2013;97(5):995-1003. doi:10.3945/ajcn.112.049247"),
            "derivation": ("Rate constants derived from the published t-max and half-life; the apparent "
                           "volume is derived from the published serum C-max at the published dose, so F is "
                           "carried as 1 and the volume is apparent. An unbound fraction of 1 is an explicit "
                           "upper-bound assumption because no protein-binding value was admitted."),
            "caveats": ["Only the parent compound is modelled; the abundant phenolic metabolites are not.",
                        "Relative bioavailability of about 12 percent was reported for the label, not for the "
                        "intact parent compound."],
        },
        "published_exposure": {
            "admitted": True,
            "species": "human (eight healthy male participants)",
            "design": "single 500 mg oral bolus of isotopically labelled cyanidin-3-glucoside",
            "participants": 8,
            "dose_mg": 500.0,
            "analyte": "parent cyanidin-3-glucoside in serum",
            "cmax_um": 0.141,
            "cmax_standard_error_um": 0.070,
            "auc_um_h": 0.279,
            "auc_standard_error_um_h": 0.170,
            "t_max_h": 1.8,
            "fraction_unbound_assumed": 1.0,
            "source": ("de Ferrars RM, Czank C, Zhang Q, et al. Br J Pharmacol 2014;171(13):3268-3282. "
                       "doi:10.1111/bph.12676 (Table 2); dose from Czank C, Cassidy A, Zhang Q, et al. "
                       "Am J Clin Nutr 2013;97(5):995-1003. doi:10.3945/ajcn.112.049247"),
            "caveats": [
                "Measured values apply only to the dose the study administered; they are not scaled.",
                "A 500 mg bolus of the purified compound is not a dietary bilberry intake.",
                "Parent compound only. The cited endothelial activity is largely attributed to metabolites.",
                "Eight male participants; the reported dispersion is a standard error, not a tolerance.",
                "An unbound fraction of 1 is an upper-bound assumption; no protein binding value was admitted.",
            ],
        },
        "active_range": {
            "admitted": True,
            "low_um": 0.1,
            "high_um": 2.0,
            "assay": ("human umbilical vein endothelial cells and human endothelial cells exposed to "
                      "circulating anthocyanins and their gut metabolites"),
            "basis": ("Activity on monocyte adhesion and on adhesion-molecule and interleukin-6 production at "
                      "concentrations from about 0.1 to 2 micromolar, including signatures tested ten-fold "
                      "below mean observed serum levels"),
            "source": ("Krga I, Monfoulet LE, Konic-Ristic A, et al. Arch Biochem Biophys 2016;599:51-59. "
                       "doi:10.1016/j.abb.2016.02.006; Warner EF, Smith MJ, Zhang Q, et al. Mol Nutr Food Res "
                       "2017;61(9):1700053. doi:10.1002/mnfr.201700053"),
            "caveat": ("The cited endothelial activity was produced by metabolite signatures as well as parent "
                       "anthocyanins. A parent-only margin therefore understates the exposure that the "
                       "measured activity actually corresponds to."),
        },
        "transfer_limits": [
            "Endothelial cell culture is not vascular tissue in a person.",
            "A parent-compound margin cannot be transferred to metabolite-driven activity.",
        ],
    },
}

_WEIGHT_DISTRIBUTION = {
    "family": "normal", "mean": 74.9, "sd": 14.4, "bounds": [40.0, 150.0],
    "source": ("Wilinska ME, Chassin LJ, Acerini CL, Allen JM, Dunger DB, Hovorka R. "
               "J Diabetes Sci Technol 2010;4(1):132-144. doi:10.1177/193229681000400117"),
    "note": "Body-weight spread only; it carries no metabolic or disease phenotype into this program.",
}


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode()).hexdigest()


def source_consistency(pk: dict[str, Any]) -> dict[str, Any]:
    """Check that published summary parameters can coexist under the declared model.

    For one-compartment first-order oral kinetics, t-max = ln(ka/ke)/(ka-ke),
    which is strictly below 1/ke whenever the reported half-life is the
    elimination half-life. A source reporting a longer t-max cannot be
    represented without reinterpreting its parameters, so it is refused rather
    than fitted.
    """
    if not pk.get("admitted"):
        return {"checked": False, "consistent": None, "reason": "no admitted pharmacokinetic source"}
    if "t_max_h" not in pk or "t_half_h" not in pk:
        return {"checked": True, "consistent": True,
                "reason": "disposition given directly as clearance and volume"}
    ke = math.log(2.0) / float(pk["t_half_h"])
    limit = 1.0 / ke
    t_max = float(pk["t_max_h"])
    consistent = t_max < limit
    return {
        "checked": True, "consistent": consistent,
        "published_t_max_h": t_max, "published_t_half_h": float(pk["t_half_h"]),
        "maximum_t_max_for_this_half_life_h": round(limit, 6),
        "reason": ("published t-max is attainable under one-compartment first-order kinetics" if consistent else
                   "published t-max exceeds the maximum attainable with the published elimination half-life "
                   "under one-compartment first-order kinetics; the reported half-life may describe a "
                   "different phase, or absorption may be rate-limiting. Resolving this needs the source's "
                   "individual concentration-time data, not a fit to this platform's output."),
    }


def program_catalog() -> dict[str, Any]:
    """Every program with its executability, so a caller never has to guess."""
    entries = []
    for program in PROGRAMS.values():
        pk = program["pharmacokinetics"]
        active = program["active_range"]
        consistency = source_consistency(pk)
        measured = program.get("published_exposure", {})
        if measured.get("admitted") and active["admitted"]:
            state, reason = "MARGIN_FROM_PUBLISHED_EXPOSURE", None
        elif not pk["admitted"]:
            state, reason = "EXPOSURE_NOT_COMPUTABLE", pk["reason_code"]
        elif consistency["consistent"] is False:
            state, reason = "EXPOSURE_NOT_COMPUTABLE", "SOURCE_PARAMETERS_INCONSISTENT"
        elif not active["admitted"]:
            state, reason = "EXPOSURE_ONLY", active["reason_code"]
        else:
            state, reason = "MARGIN_COMPUTABLE", None
        entries.append({
            "program_id": program["program_id"], "entry_name": program["entry_name"],
            "compound": program["material"]["compound"], "question": program["question"],
            "executability": state, "reason_code": reason,
            "pharmacokinetic_species": measured.get("species") or pk.get("species"),
            "human_exposure_admissible": bool(
                str(measured.get("species", "")).startswith("human")
                or (pk.get("admitted") and str(pk.get("species", "")).startswith("human"))),
        })
    return {"schema": "livemore.botanical-programs.v1", "programs": entries,
            "validation_status": "0 of 5 validated in vivo; execution here does not change that"}


def source_record(program_id: str) -> dict[str, Any]:
    program = PROGRAMS.get(str(program_id))
    if program is None:
        raise BotanicalProgramError("PROGRAM_NOT_FOUND", f"unknown program identifier: {program_id!r}")
    return {"schema": "livemore.botanical-program-sources.v1", "program": program,
            "weight_distribution": _WEIGHT_DISTRIBUTION, "allometry": _ALLOMETRY_NOTE}


def _number(body: dict, key: str, default: float, low: float, high: float) -> float:
    value = body.get(key, default)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise BotanicalProgramError("INVALID_PROTOCOL", f"{key} must be a number")
    value = float(value)
    if not math.isfinite(value) or not low <= value <= high:
        raise BotanicalProgramError("INVALID_PROTOCOL", f"{key} must be within [{low}, {high}]")
    return value


def validate_spec(body: Any) -> dict[str, Any]:
    if not isinstance(body, dict):
        raise BotanicalProgramError("INVALID_PROTOCOL", "specification must be an object")
    allowed = {"program_id", "dose_mg", "route", "cohort_size", "seed", "hours", "label"}
    unknown = set(body) - allowed
    if unknown:
        raise BotanicalProgramError("INVALID_PROTOCOL", f"unknown fields: {sorted(unknown)}")
    program_id = body.get("program_id")
    if not isinstance(program_id, str) or program_id not in PROGRAMS:
        raise BotanicalProgramError("PROGRAM_NOT_FOUND",
                                    f"program_id must be one of {sorted(PROGRAMS)}")
    route = body.get("route", "oral")
    if route != "oral":
        raise BotanicalProgramError("ROUTE_NOT_ADMITTED",
                                    "Only the oral route has an admitted exposure model in these programs.")
    cohort_size, seed = body.get("cohort_size", 10), body.get("seed", 0)
    for key, value, low, high in (("cohort_size", cohort_size, 1, 200), ("seed", seed, 0, 2**31 - 1)):
        if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
            raise BotanicalProgramError("INVALID_PROTOCOL", f"{key} must be an integer within range")
    label = body.get("label", "")
    if not isinstance(label, str) or len(label) > 120:
        raise BotanicalProgramError("INVALID_PROTOCOL", "label must be a string of at most 120 characters")
    return {"program_id": program_id, "route": route, "cohort_size": cohort_size, "seed": seed,
            "dose_mg": _number(body, "dose_mg", 100.0, 0.0, 5000.0),
            "hours": _number(body, "hours", 24.0, 1.0, 168.0), "label": label}


def _derive_disposition(pk: dict[str, Any], weight_kg: float) -> dict[str, float]:
    """Absorption and elimination constants plus apparent volume, from the source form."""
    reference = float(pk["reference_weight_kg"])
    if "clearance_L_per_h_per_kg" in pk:
        clearance = pk["clearance_L_per_h_per_kg"] * reference * (weight_kg / reference) ** _ALLOMETRIC_EXPONENT
        volume = pk["volume_L_per_kg"] * weight_kg
        ke = clearance / volume
        ka = math.log(2.0) / float(pk["absorption_t_half_h"])
    else:
        ke = math.log(2.0) / float(pk["t_half_h"])
        ka = _absorption_from_tmax(float(pk["t_max_h"]), ke)
        molar = float(pk["molar_mass_g_per_mol"])
        if "cmax_mg_per_L" in pk:
            cmax_mg_per_L = float(pk["cmax_mg_per_L"])
        else:
            cmax_mg_per_L = float(pk["cmax_nmol_per_L"]) * 1e-9 * molar * 1e3
        dose_mg = float(pk.get("dose_mg_at_reference") or _reference_dose_mg(pk))
        shape = (ka / (ka - ke)) * (math.exp(-ke * float(pk["t_max_h"])) - math.exp(-ka * float(pk["t_max_h"])))
        volume_reference = float(pk["bioavailability_F"]) * dose_mg * shape / cmax_mg_per_L
        volume = volume_reference * (weight_kg / reference)
        clearance = ke * volume
    return {"ka_per_h": ka, "ke_per_h": ke, "volume_L": volume, "clearance_L_per_h": clearance}


def _reference_dose_mg(pk: dict[str, Any]) -> float:
    basis = str(pk["dose_basis"])
    if basis.startswith("50 mg/kg"):
        return 50.0 * float(pk["reference_weight_kg"])
    if basis.startswith("500 mg"):
        return 500.0
    raise BotanicalProgramError("EXPOSURE_SOURCE_NOT_ADMITTED",
                                "the source dose basis could not be converted to milligrams")


def _absorption_from_tmax(t_max_h: float, ke: float) -> float:
    """Solve t_max = ln(ka/ke)/(ka-ke) for ka by bisection; ka > ke by construction."""
    low, high = ke * 1.000001, ke * 1e6

    def implied(ka: float) -> float:
        return math.log(ka / ke) / (ka - ke) - t_max_h

    if implied(low) < 0:
        raise BotanicalProgramError("EXPOSURE_SOURCE_NOT_ADMITTED",
                                    "the published t-max is not attainable with the published half-life")
    for _ in range(300):
        middle = math.sqrt(low * high)
        if implied(middle) > 0:
            low = middle
        else:
            high = middle
    return math.sqrt(low * high)


def _draw_weight(rng: random.Random) -> float:
    low, high = _WEIGHT_DISTRIBUTION["bounds"]
    for _ in range(1000):
        value = rng.gauss(_WEIGHT_DISTRIBUTION["mean"], _WEIGHT_DISTRIBUTION["sd"])
        if low <= value <= high:
            return value
    raise BotanicalProgramError("COHORT_GENERATION_FAILED", "weight bounds rejected every draw")


def run_botanical_exposure_program(spec: dict[str, Any]) -> dict[str, Any]:
    program = PROGRAMS[spec["program_id"]]
    pk = program["pharmacokinetics"]
    active = program["active_range"]
    record = source_record(spec["program_id"])
    base = {
        "schema": "livemore.cendos-protocol-result.v1",
        "protocol_id": PROTOCOL_ID,
        "run_id": "protocol-" + uuid.uuid4().hex,
        "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "input": spec, "input_sha256": canonical_hash(spec),
        "source_record": record, "source_sha256": canonical_hash(record),
        "program": {"program_id": program["program_id"], "entry_name": program["entry_name"],
                    "question": program["question"]},
        "material": program["material"],
        "transfer_limits": program["transfer_limits"],
        "evidence_state": "MODELED_ONLY",
        "qualification_state": "NOT_QUALIFIED",
        "calibration_authorized": False,
        "in_vivo_validation": "NOT_VALIDATED",
    }

    consistency = source_consistency(pk)
    base["source_consistency"] = consistency
    measured = program.get("published_exposure", {})
    if measured.get("admitted") and active["admitted"]:
        return _published_exposure_result(base, spec, program, measured, active)
    if pk["admitted"] and consistency["consistent"] is False:
        return {**base, "outcome": "EXPOSURE_NOT_COMPUTABLE", "reason_code": "SOURCE_PARAMETERS_INCONSISTENT",
                "missing_measurement": consistency["reason"],
                "pharmacokinetics": pk,
                "active_range_um": [active["low_um"], active["high_um"]] if active["admitted"] else None,
                "active_range_source": active.get("source"),
                "human_exposure_admissible": False, "members": [],
                "controls": [{"control": "inconsistent published parameters are refused, not fitted",
                              "passed": True}],
                "interpretation_limits": [
                    "The published summary parameters cannot all hold under the declared exposure model.",
                    "No parameter was adjusted to force agreement; the program is blocked on source data.",
                ]}
    if not pk["admitted"]:
        return {**base, "outcome": "EXPOSURE_NOT_COMPUTABLE", "reason_code": pk["reason_code"],
                "missing_measurement": pk["missing"],
                "pharmacokinetics": pk, "active_range_um": None, "active_range_source": None,
                "human_exposure_admissible": False, "members": [],
                "controls": [{"control": "no exposure number is emitted without an admitted source",
                              "passed": True}],
                "interpretation_limits": [
                    "This program cannot be executed numerically until the named measurement exists.",
                    "No exposure was approximated from a related compound or a different species.",
                ]}

    rng = random.Random(f"{PROTOCOL_ID}|{spec['program_id']}|{spec['seed']}")
    molar = float(pk["molar_mass_g_per_mol"])
    fu = float(pk["fraction_unbound"])
    bioavailability = float(pk["bioavailability_F"])
    hours = spec["hours"]
    grid = np.linspace(0.0, hours, int(hours * 12) + 1)
    trapezoid = getattr(np, "trapezoid", None) or getattr(np, "trapz")

    members, controls = [], []
    worst_auc_error = 0.0
    for index in range(spec["cohort_size"]):
        weight = _draw_weight(rng)
        disposition = _derive_disposition(pk, weight)
        ka, ke = disposition["ka_per_h"], disposition["ke_per_h"]
        volume = disposition["volume_L"]
        dose_mg = spec["dose_mg"]
        amplitude = bioavailability * dose_mg / volume * ka / (ka - ke)
        total_mg_per_L = amplitude * (np.exp(-ke * grid) - np.exp(-ka * grid))
        total_um = total_mg_per_L / molar * 1000.0
        unbound_um = total_um * fu
        auc_um_h = float(trapezoid(unbound_um, grid))
        # Analytical control: the numerically integrated total-concentration area
        # must match dose over apparent clearance once absorption is complete.
        analytic_auc = bioavailability * dose_mg / disposition["clearance_L_per_h"] / molar * 1000.0
        # Independent fine grid for the control, plus the exact remaining area
        # beyond the horizon for both exponential terms.
        step = min(1.0 / (40.0 * max(ka, ke)), 1.0 / 60.0)
        fine = np.arange(0.0, hours + step / 2.0, step)
        fine_total_um = amplitude * (np.exp(-ke * fine) - np.exp(-ka * fine)) / molar * 1000.0
        numeric_total_auc = float(trapezoid(fine_total_um, fine))
        tail = amplitude / molar * 1000.0 * (math.exp(-ke * fine[-1]) / ke - math.exp(-ka * fine[-1]) / ka)
        error = abs(numeric_total_auc + tail - analytic_auc) / max(analytic_auc, 1e-12)
        worst_auc_error = max(worst_auc_error, error)
        peak = int(np.argmax(unbound_um))
        member = {
            "member_id": f"{spec['program_id'].lower()}-{spec['seed']}-{index:03d}",
            "weight_kg": round(weight, 3),
            "disposition": {key: round(value, 9) for key, value in disposition.items()},
            "cmax_unbound_um": round(float(unbound_um[peak]), 9),
            "t_peak_h": round(float(grid[peak]), 4),
            "auc_unbound_um_h": round(auc_um_h, 9),
            "series": {"t_h": [round(float(v), 4) for v in grid[::6]],
                       "unbound_um": [round(float(v), 9) for v in unbound_um[::6]]},
        }
        if active["admitted"]:
            low = float(active["low_um"])
            member["margin_to_active_low"] = round(float(unbound_um[peak]) / low, 6)
            member["reaches_active_range"] = bool(float(unbound_um[peak]) >= low)
        else:
            member["margin_to_active_low"] = None
            member["reaches_active_range"] = None
        members.append(member)

    controls.append({"control": "numerically integrated exposure matches dose over apparent clearance",
                     "worst_relative_error": worst_auc_error, "passed": worst_auc_error < 1e-4})
    zero = run_zero_dose_check(spec)
    controls.append(zero)

    human = str(pk.get("species", "")).startswith("human")
    if not active["admitted"]:
        outcome, reason = "EXPOSURE_ONLY", active["reason_code"]
    else:
        reached = sum(1 for member in members if member["reaches_active_range"])
        outcome = "REACHES_MEASURED_ACTIVE_RANGE" if reached == len(members) else (
            "PARTIALLY_REACHES_MEASURED_ACTIVE_RANGE" if reached else "BELOW_MEASURED_ACTIVE_RANGE")
        reason = None

    margins = [m["margin_to_active_low"] for m in members if m["margin_to_active_low"] is not None]
    return {
        **base,
        "outcome": outcome, "reason_code": reason,
        "pharmacokinetics": pk,
        "active_range_um": [active["low_um"], active["high_um"]] if active["admitted"] else None,
        "active_range_source": active.get("source"),
        "active_range_missing": None if active["admitted"] else active["missing"],
        "human_exposure_admissible": human,
        "members": members,
        "summary": {
            "member_count": len(members),
            "median_cmax_unbound_um": round(float(np.median([m["cmax_unbound_um"] for m in members])), 9),
            "median_auc_unbound_um_h": round(float(np.median([m["auc_unbound_um_h"] for m in members])), 9),
            "median_margin_to_active_low": round(float(np.median(margins)), 6) if margins else None,
            "members_reaching_active_range": sum(1 for m in members if m["reaches_active_range"]) if margins else None,
        },
        "controls": controls,
        "interpretation_limits": [
            "Modelled exposure of one declared material, not a measurement in any person.",
            "The active range is the concentration range of the cited assay, not a human tissue concentration.",
            f"Pharmacokinetic species: {pk.get('species')}. Human exposure admissible: {human}.",
            "A margin at or above 1 supports designing a next experiment; it is not efficacy or safety.",
            "This program remains not validated in vivo.",
        ],
    }


def _published_exposure_result(base: dict[str, Any], spec: dict[str, Any], program: dict[str, Any],
                               measured: dict[str, Any], active: dict[str, Any]) -> dict[str, Any]:
    """Margin computed from measured human values, with no kinetic model at all.

    A measured peak concentration belongs to the dose that was administered.
    Scaling it to another dose would require exactly the model this program does
    not have, so a different dose is refused rather than extrapolated.
    """
    published_dose = float(measured["dose_mg"])
    if abs(spec["dose_mg"] - published_dose) > 1e-9:
        return {**base, "outcome": "EXPOSURE_NOT_COMPUTABLE",
                "reason_code": "DOSE_NOT_MEASURED_AT_THIS_LEVEL",
                "missing_measurement": (
                    f"Measured human exposure exists only for the {published_dose:g} mg dose in the cited "
                    f"study. Requesting {spec['dose_mg']:g} mg would require scaling a measured peak "
                    "concentration through a kinetic model, which this program does not have."),
                "published_exposure": measured, "pharmacokinetics": program["pharmacokinetics"],
                "active_range_um": [active["low_um"], active["high_um"]],
                "active_range_source": active.get("source"),
                "human_exposure_admissible": True, "members": [],
                "controls": [{"control": "a measured exposure is never scaled to an unmeasured dose",
                              "passed": True}],
                "interpretation_limits": [
                    "Run this program at the dose the cited study administered to obtain a margin.",
                ]}

    fu = float(measured["fraction_unbound_assumed"])
    low, high = float(active["low_um"]), float(active["high_um"])
    cmax = float(measured["cmax_um"]) * fu
    cmax_se = float(measured["cmax_standard_error_um"]) * fu
    conservative = max(0.0, cmax - cmax_se)
    margin, lower_margin = cmax / low, conservative / low
    molar = float(program["pharmacokinetics"]["molar_mass_g_per_mol"])
    dose_umol = published_dose / molar * 1000.0
    apparent_clearance = dose_umol / float(measured["auc_um_h"])   # L/h, upper bound at F unknown
    outcome = ("REACHES_MEASURED_ACTIVE_RANGE" if margin >= 1.0 else "BELOW_MEASURED_ACTIVE_RANGE")
    return {
        **base,
        "outcome": outcome, "reason_code": None,
        "exposure_basis": "measured_human_summary_statistics",
        "published_exposure": measured,
        "pharmacokinetics": program["pharmacokinetics"],
        "active_range_um": [low, high], "active_range_source": active.get("source"),
        "human_exposure_admissible": True,
        "members": [],
        "margin": {
            "unbound_cmax_um": round(cmax, 6),
            "margin_to_active_low": round(margin, 4),
            "margin_at_one_standard_error_below_cmax": round(lower_margin, 4),
            "robust_to_one_standard_error": bool(lower_margin >= 1.0),
            "apparent_clearance_L_per_h": round(apparent_clearance, 1),
        },
        "controls": [
            {"control": "measured exposure is used only at the dose administered in the study",
             "passed": True},
            {"control": "dose over reported exposure yields a finite positive apparent clearance",
             "apparent_clearance_L_per_h": round(apparent_clearance, 1),
             "passed": bool(math.isfinite(apparent_clearance) and apparent_clearance > 0)},
        ],
        "interpretation_limits": [
            "Exposure here is measured in people, not modelled; the comparison range is still in vitro.",
            "The margin is computed against the low end of the cited active range.",
            *measured["caveats"],
            "Reaching the range supports designing the next experiment; it is not efficacy or safety.",
            "This program remains not validated in vivo.",
        ],
    }


def run_zero_dose_check(spec: dict[str, Any]) -> dict[str, Any]:
    """A zero dose must produce exactly zero exposure through the same code path."""
    program = PROGRAMS[spec["program_id"]]
    pk = program["pharmacokinetics"]
    disposition = _derive_disposition(pk, float(pk["reference_weight_kg"]))
    ka, ke = disposition["ka_per_h"], disposition["ke_per_h"]
    molar, fu = float(pk["molar_mass_g_per_mol"]), float(pk["fraction_unbound"])
    grid = np.linspace(0.0, spec["hours"], int(spec["hours"] * 12) + 1)
    amplitude = float(pk["bioavailability_F"]) * 0.0 / disposition["volume_L"] * ka / (ka - ke)
    unbound = amplitude * (np.exp(-ke * grid) - np.exp(-ka * grid)) / molar * 1000.0 * fu
    trapezoid = getattr(np, "trapezoid", None) or getattr(np, "trapz")
    peak, area = float(np.max(np.abs(unbound))), abs(float(trapezoid(unbound, grid)))
    return {"control": "zero dose yields exactly zero exposure through the same code path",
            "max_abs_unbound_um": peak, "abs_auc_um_h": area,
            "passed": bool(peak == 0.0 and area == 0.0)}


__all__ = ["PROTOCOL_ID", "PROGRAMS", "BotanicalProgramError", "program_catalog", "source_record",
           "validate_spec", "run_botanical_exposure_program", "canonical_hash"]
