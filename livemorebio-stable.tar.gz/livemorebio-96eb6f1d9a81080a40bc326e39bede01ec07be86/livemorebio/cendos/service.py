"""Cendos Lab service — in-silico assays + compound analysis on the twins."""
from __future__ import annotations
from datetime import datetime
import logging
import math
import os
import asyncio
import sqlite3

from fastapi import FastAPI, HTTPException, Request
from ..build_info import build_identity
from fastapi.responses import JSONResponse, Response
from .assays import ogtt_effect
from ..engines.metabolic.glucose_insulin import HEALTHY, T2D
from ..engines import pharmacology
from ..engines.integrity import UnsupportedInterventionError
from .. import events
from ..security import install_mutation_auth, require_operator_auth

app = FastAPI(title="Cendos Lab — LivemoreBio", version="0.0.1",
              description="In-silico assay service (model-only hypothesis triage; never wet-lab or clinical evidence). OpenAPI contract at /openapi.json, docs at /docs.")
install_mutation_auth(app)
logger = logging.getLogger(__name__)
_protocol_store_instance = None
_protocol_store_path = None


def _protocol_store():
    global _protocol_store_instance, _protocol_store_path
    from pathlib import Path
    from .. import registry
    from .protocol_runs import ProtocolRunStore

    path = os.environ.get("LIVEMORE_PROTOCOL_RUNS", "").strip()
    if not path:
        path = os.path.join(registry.REG_DIR, "cendos-protocol-runs")
    if _protocol_store_instance is None or _protocol_store_path != path:
        _protocol_store_instance = ProtocolRunStore(Path(path))
        _protocol_store_path = path
    return _protocol_store_instance


def _iso_timestamp(value: object, field_name: str) -> datetime:
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError as error:
        raise HTTPException(status_code=422, detail=f"{field_name} must be ISO-8601") from error


@app.post("/evidence/lab-results", status_code=201)
async def qualify_lab_result(req: Request):
    """Qualify a wet-lab result as a hashed counterpart measurement, not validation."""
    from .. import bus
    from ..evidence import AssessmentStatus, to_primitive
    from ..evidence.errors import DomainValidationError
    from .counterparts import LabResult, to_evidence_measurement

    body = await _json_object(req)
    try:
        if type(body.get("subject_pseudonymized")) is not bool:
            raise DomainValidationError("subject_pseudonymized must be a JSON boolean")
        if body["subject_pseudonymized"] is not True:
            raise DomainValidationError("qualified lab subjects must be pseudonymized")
        from ..life_patch.protocol import pseudonymous_subject_id

        result = LabResult(
            result_id=_text(body, "result_id", ""),
            subject_id=pseudonymous_subject_id(body.get("subject_id", "")),
            endpoint=_text(body, "endpoint", ""),
            value=float(body.get("value")),
            unit=_text(body, "unit", ""),
            measured_at=_iso_timestamp(body.get("measured_at"), "measured_at"),
            received_at=_iso_timestamp(body.get("received_at"), "received_at"),
            instrument_id=_text(body, "instrument_id", ""),
            method=_text(body, "method", ""),
            quality_status=AssessmentStatus(str(body.get("quality_status", "not_assessed"))),
            calibration_status=AssessmentStatus(str(body.get("calibration_status", "not_assessed"))),
            chain_of_custody=_string_tuple(body, "chain_of_custody"),
            consent_scope=_string_tuple(body, "consent_scope"),
        )
        measurement = to_evidence_measurement(
            result, tenant_id="livemore", sequence=int(body.get("sequence", 0)),
        )
    except (DomainValidationError, ValueError, TypeError) as error:
        return JSONResponse({"error": str(error)}, status_code=422)
    serialized = to_primitive(measurement)
    snapshot = {
        "envelope_id": measurement.envelope_id,
        "source_hash": measurement.source_hash,
        "counterpart_id": measurement.counterpart_id,
        "endpoint": measurement.payload.endpoint,
        "measured_at": serialized["payload"]["measured_at"],
        "validation_status": "not_assessed",
    }
    bus.set_snapshot("cendos.latest-qualified-measurement", snapshot)
    bus.publish("Cendos", events.CENDOS_MEASUREMENT_QUALIFIED, snapshot)
    return JSONResponse({
        "measurement": serialized,
        "validation_status": "not_assessed",
        "next_gate": "attach to a frozen evidence package, review, then authorize calibration",
    }, status_code=201)


@app.post("/qualification/assess")
async def assess_qualification(req: Request):
    """Assess a frozen prediction/measurement pair before evidence review."""
    from .. import bus
    from .qualification import QualificationInputError, assess_counterpart

    body = await _json_object(req)
    try:
        result = assess_counterpart(
            prediction_id=_text(body, "prediction_id", ""),
            measurement_id=_text(body, "measurement_id", ""),
            protocol_id=_text(body, "protocol_id", ""),
            subject_id=_text(body, "subject_id", ""),
            prediction_subject_id=_text(body, "prediction_subject_id", ""),
            endpoint=_text(body, "endpoint", ""),
            prediction_endpoint=_text(body, "prediction_endpoint", ""),
            predicted_value=_number(body, "predicted_value", 0.0, lower=-1e15, upper=1e15,
                                    inclusive_lower=True),
            measured_value=_number(body, "measured_value", 0.0, lower=-1e15, upper=1e15,
                                   inclusive_lower=True),
            unit=_text(body, "unit", ""),
            prediction_unit=_text(body, "prediction_unit", ""),
            tolerance=_number(body, "tolerance", 0.0, lower=0.0, upper=1e15,
                              inclusive_lower=True),
            generated_at=_iso_timestamp(body.get("generated_at"), "generated_at"),
            measured_at=_iso_timestamp(body.get("measured_at"), "measured_at"),
            expected_window_seconds=_number(
                body, "expected_window_seconds", 0.0, lower=0.0, upper=315576000.0,
            ),
            quality_status=_text(body, "quality_status", ""),
            calibration_status=_text(body, "calibration_status", ""),
            population=_text(body, "population", ""),
            intervention=_text(body, "intervention", ""),
            dose=_text(body, "dose", ""),
        )
    except (QualificationInputError, ValueError, TypeError) as error:
        return JSONResponse({"error": str(error)}, status_code=422)
    bus.set_snapshot("cendos.latest-qualification", result)
    bus.publish("Cendos", events.CENDOS_QUALIFICATION_ASSESSED, {
        "qualification_id": result["qualification_id"],
        "prediction_id": result["prediction_id"],
        "measurement_id": result["measurement_id"],
        "status": result["status"],
        "endpoint": result["endpoint"],
        "calibration_authorized": False,
    })
    return JSONResponse(result)


@app.get("/patch/latest")
def latest_admitted_patch_telemetry(
    req: Request,
    subject_id: str,
    envelope_hash: str,
):
    """Read the LIFE-admitted observation available for protocol-bound lab work."""
    from .. import bus
    from ..life_patch.protocol import (
        ProtocolViolation,
        envelope_snapshot_key,
        pseudonymous_subject_id,
    )

    require_operator_auth(req)
    try:
        normalized_subject = pseudonymous_subject_id(subject_id)
        key = envelope_snapshot_key(envelope_hash)
    except ProtocolViolation as error:
        return JSONResponse({"error": str(error)}, status_code=422)
    telemetry = bus.snapshot(key)
    if telemetry is None:
        return JSONResponse({"error": "no admitted LIFE Patch telemetry"}, status_code=404)
    if telemetry.get("admission") != "accepted":
        return JSONResponse({"error": "patch snapshot is not admitted"}, status_code=409)
    if telemetry.get("subject_id") != normalized_subject:
        return JSONResponse({"error": "patch subject binding does not match"}, status_code=409)
    if telemetry.get("envelope_hash") != envelope_hash:
        return JSONResponse({"error": "patch envelope binding does not match"}, status_code=409)
    return JSONResponse({
        "telemetry": telemetry,
        "use": "baseline/protocol context only; not validation evidence by itself",
    })


async def _json_object(req: Request) -> dict:
    from ..strict_json import parse_json_object
    try:
        data = bytearray()
        async for part in req.stream():
            if len(data) + len(part) > 2_000_000:
                raise ValueError("request too large")
            data.extend(part)
        body = parse_json_object(bytes(data))
    except (ValueError, UnicodeError) as exc:
        raise HTTPException(status_code=400, detail="request body must be valid JSON") from exc
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="request body must be a JSON object")
    return body


def _text(body: dict, name: str, default: str) -> str:
    value = body.get(name, default)
    if not isinstance(value, str) or not value.strip():
        raise HTTPException(status_code=400, detail=f"{name} must be a non-empty string")
    value = value.strip()
    if len(value) > 200:
        raise HTTPException(status_code=400, detail=f"{name} exceeds 200 characters")
    return value


def _string_tuple(body: dict, name: str) -> tuple[str, ...]:
    value = body.get(name, ())
    if not isinstance(value, (list, tuple)):
        raise HTTPException(status_code=400, detail=f"{name} must be an array")
    items = tuple(str(item).strip() for item in value)
    if any(not item or len(item) > 200 for item in items):
        raise HTTPException(
            status_code=400,
            detail=f"{name} entries must be non-empty and at most 200 characters",
        )
    return items


def _number(body: dict, name: str, default: float, *, lower: float, upper: float,
            inclusive_lower: bool = False) -> float:
    try:
        value = float(body.get(name, default))
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=f"{name} must be numeric") from exc
    lower_ok = value >= lower if inclusive_lower else value > lower
    if not math.isfinite(value) or not lower_ok or value > upper:
        bracket = "[" if inclusive_lower else "("
        raise HTTPException(status_code=400,
                            detail=f"{name} must be finite and within {bracket}{lower}, {upper}]")
    return value


def _assay_inputs(body: dict) -> tuple[str, float, float, dict[str, float]]:
    drug = _text(body, "drug", "metformin")
    dose = _number(body, "dose", 1.0, lower=0, upper=5)
    grams = _number(body, "grams", 75.0, lower=0, upper=200)
    effects = {}  # Generic effect coefficients are no longer executable inputs.
    return drug, dose, grams, effects


@app.get("/health")
def health(req: Request):
    return {"service": "Cendos", "ok": True, "port": (req.scope.get("server") or (None, None))[1],
            "build": build_identity()}


@app.post("/protocols/metformin-cohorts", status_code=201)
async def protocol_metformin_cohorts(req: Request):
    from .protocols import run_metformin_cohort_comparison
    from .protocol_runs import attach_run_inputs
    from ..reference_cohort_contract import ReferenceModelBindingRequired

    body = await _json_object(req)
    try:
        for name in ("dose_mg", "grams"):
            if name in body and (isinstance(body[name], bool) or not isinstance(body[name], (int, float))):
                raise ValueError("protocol quantities require numeric values, not booleans or strings")
        result = run_metformin_cohort_comparison(
            body.get("cohort_a"), body.get("cohort_b"),
            dose_mg=float(body.get("dose_mg", 1000)), grams=float(body.get("grams", 75)),
        )
        result = attach_run_inputs(result, body, [body["cohort_a"], body["cohort_b"]])
    except (TypeError, ValueError) as error:
        return JSONResponse({"error": str(error), "code": error.code if isinstance(error, ReferenceModelBindingRequired)
                             else "INVALID_PROTOCOL"}, status_code=422)
    return JSONResponse(_protocol_store().save(result), status_code=201)


@app.post("/protocols/garcinoic-pxr", status_code=201)
async def protocol_garcinoic_pxr(req: Request):
    from .protocols import run_garcinoic_acid_pxr
    from .protocol_runs import attach_run_inputs
    from ..reference_cohort_contract import ReferenceModelBindingRequired

    body = await _json_object(req)
    try:
        concentrations = body.get("concentrations_um", [0.05, 0.33, 1.3, 5.0])
        if not isinstance(concentrations, list) or any(isinstance(value, bool) or
                not isinstance(value, (int, float)) for value in concentrations):
            raise ValueError("concentrations require numeric values, not booleans or strings")
        result = run_garcinoic_acid_pxr(
            body.get("cohort"),
            concentrations_um=concentrations,
        )
        result = attach_run_inputs(result, body, [body["cohort"]])
    except (TypeError, ValueError) as error:
        return JSONResponse({"error": str(error), "code": error.code if isinstance(error, ReferenceModelBindingRequired)
                             else "INVALID_PROTOCOL"}, status_code=422)
    return JSONResponse(_protocol_store().save(result), status_code=201)


@app.post("/protocols/human-gem-oxygen-capacity", status_code=201)
async def protocol_human_gem_oxygen_capacity(req: Request):
    from .metabolic_protocol import run_human_gem_oxygen_capacity, PROTOCOL_ID
    from .protocol_runs import ProtocolRunNotFound
    from ..engines.stoichiometry import validate_spec, StoichiometryError
    from ..model_assets import ModelAssetError

    require_operator_auth(req)
    body = await _json_object(req)
    parent_id = body.pop("parent_run_id", None)
    acknowledgment = body.pop("new_configuration", False)
    try:
        if not isinstance(acknowledgment, bool):
            raise ValueError("new configuration acknowledgment must be boolean")
        normalized = validate_spec(body)
        store = _protocol_store()
        parent = None
        if parent_id is not None:
            if store.get(parent_id).get("protocol_id") != PROTOCOL_ID:
                raise ValueError("parent protocol does not match requested protocol")
            parent = await asyncio.to_thread(store.validate_rerun, parent_id, normalized,
                                             new_configuration=acknowledgment)
        result = await asyncio.to_thread(run_human_gem_oxygen_capacity, normalized)
        if parent:
            result.update(parent)
        await asyncio.to_thread(store.save, result)
        return JSONResponse(result, status_code=201)
    except ProtocolRunNotFound:
        return JSONResponse({"error": "parent protocol was not found", "code": "PROTOCOL_NOT_FOUND"}, status_code=404)
    except StoichiometryError as error:
        status = {"MODEL_BUSY": 409, "MODEL_EXECUTION_TIMEOUT": 504, "MODEL_UNAVAILABLE": 503,
                  "MODEL_EXECUTION_FAILED": 503, "SOLVER_FAILED": 422, "MODEL_QC_FAILED": 422}.get(error.code, 422)
        return JSONResponse({"error": "Metabolic calculation unavailable; inspect input, model readiness and numerical gates.", "code": error.code}, status_code=status)
    except ModelAssetError:
        return JSONResponse({"error": "Verified model assets are unavailable", "code": "MODEL_UNAVAILABLE"}, status_code=503)
    except (OSError, sqlite3.Error):
        return JSONResponse({"error": "Protocol storage is temporarily unavailable", "code": "PROTOCOL_STORAGE_UNAVAILABLE"}, status_code=503)
    except (ValueError, TypeError):
        return JSONResponse({"error": "Protocol configuration or parent integrity check failed", "code": "INVALID_PROTOCOL"}, status_code=422)


@app.get("/programs")
def six_program_catalog(req: Request):
    """Executability of the insulin program and the five botanical programs."""
    require_operator_auth(req)
    from .botanical_programs import program_catalog
    from ..engines.metabolic.hovorka import product_catalog
    return JSONResponse({"insulin": product_catalog(), "botanical": program_catalog()},
                        headers={"Cache-Control": "no-store"})


async def _run_source_record_protocol(req: Request, *, protocol_id: str, validate, execute, error_type):
    from .protocol_runs import ProtocolRunNotFound
    require_operator_auth(req)
    body = await _json_object(req)
    parent_id = body.pop("parent_run_id", None)
    acknowledgment = body.pop("new_configuration", False)
    try:
        if not isinstance(acknowledgment, bool):
            raise ValueError("new configuration acknowledgment must be boolean")
        normalized = validate(body)
        store = _protocol_store()
        parent = None
        if parent_id is not None:
            parent = await asyncio.to_thread(store.validate_rerun, parent_id, normalized,
                new_configuration=acknowledgment, expected_protocol_id=protocol_id)
        result = await asyncio.to_thread(execute, normalized)
        if parent:
            result.update(parent)
        await asyncio.to_thread(store.save, result)
        return JSONResponse(result, status_code=201, headers={"Cache-Control": "no-store"})
    except ProtocolRunNotFound:
        return JSONResponse({"error": "Parent protocol was not found", "code": "PROTOCOL_NOT_FOUND"}, status_code=404)
    except error_type as error:
        return JSONResponse({"error": str(error), "code": error.code}, status_code=422)
    except (OSError, sqlite3.Error):
        return JSONResponse({"error": "Protocol storage is temporarily unavailable", "code": "PROTOCOL_STORAGE_UNAVAILABLE"}, status_code=503)
    except (ValueError, TypeError, KeyError):
        return JSONResponse({"error": "Protocol configuration or parent integrity check failed", "code": "INVALID_PROTOCOL"}, status_code=422)


@app.post("/protocols/exogenous-insulin", status_code=201)
async def protocol_exogenous_insulin(req: Request):
    from .insulin_protocol import PROTOCOL_ID, InsulinProtocolError, validate_spec, run_exogenous_insulin_protocol
    return await _run_source_record_protocol(req, protocol_id=PROTOCOL_ID, validate=validate_spec,
                                             execute=run_exogenous_insulin_protocol, error_type=InsulinProtocolError)


@app.post("/protocols/botanical-exposure", status_code=201)
async def protocol_botanical_exposure(req: Request):
    from .botanical_programs import PROTOCOL_ID, BotanicalProgramError, validate_spec, run_botanical_exposure_program
    return await _run_source_record_protocol(req, protocol_id=PROTOCOL_ID, validate=validate_spec,
                                             execute=run_botanical_exposure_program, error_type=BotanicalProgramError)


@app.post("/protocols/lobeline-vmat2", status_code=201)
async def protocol_lobeline_vmat2(req: Request):
    from .lobeline_vmat2 import run_lobeline_vmat2, validate_spec, PROTOCOL_ID, LobelineProtocolError
    from .protocol_runs import ProtocolRunNotFound

    require_operator_auth(req)
    body = await _json_object(req)
    parent_id = body.pop("parent_run_id", None)
    acknowledgment = body.pop("new_configuration", False)
    try:
        if not isinstance(acknowledgment, bool):
            raise ValueError("new configuration acknowledgment must be boolean")
        normalized = validate_spec(body)
        store = _protocol_store()
        parent = None
        if parent_id is not None:
            parent = await asyncio.to_thread(store.validate_rerun, parent_id, normalized,
                new_configuration=acknowledgment, expected_protocol_id=PROTOCOL_ID)
        result = run_lobeline_vmat2(normalized)
        if parent:
            result.update(parent)
        await asyncio.to_thread(store.save, result)
        return JSONResponse(result, status_code=201, headers={"Cache-Control": "no-store"})
    except ProtocolRunNotFound:
        return JSONResponse({"error": "Parent protocol was not found", "code": "PROTOCOL_NOT_FOUND"}, status_code=404)
    except LobelineProtocolError as error:
        return JSONResponse({"error": str(error), "code": error.code}, status_code=422)
    except (OSError, sqlite3.Error):
        return JSONResponse({"error": "Protocol storage is temporarily unavailable", "code": "PROTOCOL_STORAGE_UNAVAILABLE"}, status_code=503)
    except (ValueError, TypeError, KeyError):
        return JSONResponse({"error": "Protocol configuration or parent integrity check failed", "code": "INVALID_PROTOCOL"}, status_code=422)


@app.get("/protocols/history")
def protocol_history(req: Request, limit: int = 20, cursor: str | None = None, q: str = ""):
    require_operator_auth(req)
    try:
        return JSONResponse(_protocol_store().history(limit=limit, cursor=cursor, q=q))
    except ValueError:
        return JSONResponse({"error": "History query or storage integrity check failed", "code": "INVALID_HISTORY"}, status_code=422)


@app.get("/protocols/latest")
def protocol_latest(req: Request):
    from .protocol_runs import ProtocolRunNotFound

    require_operator_auth(req)
    try:
        return JSONResponse(_protocol_store().latest())
    except ProtocolRunNotFound as error:
        return JSONResponse({"error": str(error), "code": "PROTOCOL_NOT_FOUND"}, status_code=404)


@app.get("/protocols/{run_id}/prepare-rerun")
def protocol_prepare_rerun(run_id: str, req: Request):
    from .protocol_runs import ProtocolRunNotFound
    require_operator_auth(req)
    try:
        return JSONResponse(_protocol_store().prepare_rerun(run_id))
    except ProtocolRunNotFound:
        return JSONResponse({"error": "Protocol run was not found", "code": "PROTOCOL_NOT_FOUND"}, status_code=404)
    except (ValueError, KeyError, TypeError):
        return JSONResponse({"error": "Preserved protocol has no supported rerun configuration", "code": "INVALID_PROTOCOL"}, status_code=422)


def _protocol_export(run_id: str, req: Request, *, notebook: bool) -> Response:
    from .protocol_runs import ProtocolRunNotFound, analysis_csv, analysis_notebook
    require_operator_auth(req)
    try:
        result = _protocol_store().get(run_id)
        if notebook:
            return JSONResponse(analysis_notebook(result), headers={"Cache-Control": "no-store"})
        return Response(analysis_csv(result), media_type="text/csv", headers={"Cache-Control": "no-store"})
    except ProtocolRunNotFound:
        return JSONResponse({"error": "Protocol run was not found", "code": "PROTOCOL_NOT_FOUND"}, status_code=404)
    except (ValueError, KeyError, TypeError):
        return JSONResponse({"error": "Preserved protocol cannot be exported", "code": "INVALID_PROTOCOL"}, status_code=422)
    except (OSError, sqlite3.Error):
        return JSONResponse({"error": "Protocol storage is temporarily unavailable", "code": "PROTOCOL_STORAGE_UNAVAILABLE"}, status_code=503)


@app.get("/protocols/{run_id}/analysis.csv")
def protocol_analysis_csv(run_id: str, req: Request):
    return _protocol_export(run_id, req, notebook=False)


@app.get("/protocols/{run_id}/analysis.ipynb")
def protocol_analysis_notebook(run_id: str, req: Request):
    return _protocol_export(run_id, req, notebook=True)


@app.get("/protocols/{run_id}")
def protocol_recall(run_id: str, req: Request):
    from .protocol_runs import ProtocolRunNotFound
    require_operator_auth(req)
    try:
        return JSONResponse(_protocol_store().get(run_id))
    except ProtocolRunNotFound:
        return JSONResponse({"error": "Protocol run was not found", "code": "PROTOCOL_NOT_FOUND"}, status_code=404)
    except ValueError:
        return JSONResponse({"error": "Protocol storage integrity check failed", "code": "INVALID_PROTOCOL"}, status_code=422)


@app.post("/assay/ogtt")
async def assay_ogtt(req: Request):
    b = await _json_object(req)
    base_name = _text(b, "base", "t2d")
    if base_name not in {"t2d", "healthy"}:
        raise HTTPException(status_code=400, detail="base must be 't2d' or 'healthy'")
    base = T2D if base_name == "t2d" else HEALTHY
    drug, dose, grams, effects = _assay_inputs(b)
    if drug != "metformin":
        error = UnsupportedInterventionError()
        return JSONResponse({"error": str(error), "code": error.code}, status_code=422)
    treated, treatment = pharmacology.metformin(base, None, dose)
    res = ogtt_effect(base, treated, grams=grams)
    res["intervention"] = drug
    res["treatment"] = treatment
    res["pk"] = treatment.get("pk")
    return res


@app.get("/compound")
def compound(name: str):
    """Resolve a named compound against PubChem (real). Plants resolve to
    constituents — phytochemistry integration is the next step."""
    import urllib.request, urllib.parse, json as _j
    url = ("https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/"
           + urllib.parse.quote(name) + "/property/MolecularFormula,MolecularWeight,IUPACName/JSON")
    try:
        with urllib.request.urlopen(url, timeout=6) as r:
            d = _j.load(r)["PropertyTable"]["Properties"][0]
        return {"name": name, "resolved": True, "formula": d.get("MolecularFormula"),
                "mw": d.get("MolecularWeight"), "iupac": d.get("IUPACName"), "source": "PubChem"}
    except Exception as e:
        return {"name": name, "resolved": False,
                "note": f"not a single PubChem compound — plants resolve to constituents "
                        f"(phytochemistry integration pending) [{type(e).__name__}]"}


@app.post("/assay/current")
async def assay_current(req: Request):
    """Run the retained reference assay on authenticated, frozen Aegle inputs."""
    from dataclasses import asdict, fields
    from types import SimpleNamespace
    from ..aegle.clinical_parameters import validate_model_parameters
    from ..engines.metabolic.glucose_insulin import MetabolicProfile
    from .. import bus
    from ..execution_client import ContinuousClientError
    from .current_source import source_guard, validate_source_envelope, validate_source_guard
    b = await _json_object(req)
    drug, dose, grams, effects = _assay_inputs(b)
    if drug != "metformin":
        error = UnsupportedInterventionError()
        return JSONResponse({"error": str(error), "code": error.code}, status_code=422)
    try:
        expected = validate_source_guard(b["expected_source"]) if "expected_source" in b else None
        source = validate_source_envelope(await asyncio.to_thread(_read_current_source))
        guard = source_guard(source)
        if expected is not None and expected != guard:
            raise ContinuousClientError("MODEL_SOURCE_CHANGED", status=409)
    except ContinuousClientError as error:
        return _current_source_failure(error)
    snap = source["snapshot"]
    pp = snap.get("profile_params")
    if not pp:
        return JSONResponse({"error": "no executable authenticated source is available",
                             "code": "ACTIVE_TWIN_REQUIRED"}, status_code=409)
    try:
        expected_fields = {field.name for field in fields(MetabolicProfile)}
        if not isinstance(pp, dict) or set(pp) != expected_fields:
            raise ValueError("complete metabolic profile parameters are required")
        subject = snap.get("profile")
        if not isinstance(subject, str) or not subject.strip() or subject != pp["name"]:
            raise ValueError("snapshot profile identity is missing or inconsistent")
        values = validate_model_parameters({key: value for key, value in pp.items() if key != "name"})
        base = MetabolicProfile(name=subject, **values)
        pk_context = snap.get("pk_context")
        if (not isinstance(pk_context, dict) or set(pk_context) != {"age", "genome", "evidence_class"}
                or pk_context["evidence_class"] not in {"REFERENCE_INITIALIZED", "DECLARED_PERSON_CONTEXT"}):
            raise ValueError("explicit pharmacokinetic input provenance is required")
        age = pk_context["age"]
        genome = pk_context["genome"]
        if isinstance(age, bool) or not math.isfinite(float(age)) or not 0 < float(age) <= 120:
            raise ValueError("snapshot age is outside the executable domain")
        if (not isinstance(genome, dict)
                or any(not isinstance(key, str) or type(value) is not int or not 0 <= value <= 2
                       for key, value in genome.items())):
            raise ValueError("snapshot genotype context is invalid")
        human = SimpleNamespace(genome=dict(genome), age=float(age), weight_kg=base.weight_kg)
    except (TypeError, ValueError) as error:
        return JSONResponse({"error": str(error), "code": "ACTIVE_TWIN_SNAPSHOT_INVALID"}, status_code=422)
    twin_source = "Aegle authenticated frozen source"
    treated, treatment = pharmacology.metformin(base, human, dose)
    res = ogtt_effect(base, treated, grams=grams)
    try:
        confirmed = validate_source_envelope(await asyncio.to_thread(_read_current_source))
        if confirmed != source:
            raise ContinuousClientError("MODEL_SOURCE_CHANGED", status=409)
    except ContinuousClientError as error:
        return _current_source_failure(error)
    res["intervention"] = drug
    res["subject"] = subject
    res["twin_source"] = twin_source
    res["assayed_profile_params"] = asdict(base)
    res["assayed_pk_context"] = dict(pk_context)
    res["assayed_source"] = source
    res["treatment"] = treatment
    res["pk"] = treatment.get("pk")
    try:
        bus.publish("Cendos", events.ASSAY_RUN,
                    {"drug": drug, "subject": subject, "decision": res["decision"],
                     "delta_mean": res["delta_mean"], "delta_iAUC": res["delta_iAUC"],
                     "source_identity": guard})
    except Exception as error:
        logger.warning(
            "Cendos assay event publication failed (error_type=%s)",
            type(error).__name__,
        )
    return res


def _read_current_source() -> dict:
    from .current_source import CurrentSourceClient
    return CurrentSourceClient().read_source()


def _current_source_failure(error) -> JSONResponse:
    from .current_source import source_failure_response
    return source_failure_response(error)


def main(host="127.0.0.1", port=8852):
    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="warning")


if __name__ == "__main__":
    main()
