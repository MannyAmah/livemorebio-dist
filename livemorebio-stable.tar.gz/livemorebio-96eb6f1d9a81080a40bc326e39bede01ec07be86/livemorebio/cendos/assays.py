"""
livemorebio.cendos.assays — in-silico assays.

Cendos perturbs a *living* twin with a drug/compound and reports the modeled
effect against that same twin's untreated baseline. Model-only: this is a
hypothesis-triage result, not a wet-lab measurement or a clinical outcome.
"""
from __future__ import annotations
from ..engines.metabolic.glucose_insulin import GlucoseInsulinModel, summarize, MetabolicProfile


def ogtt_effect(baseline: MetabolicProfile, treated: MetabolicProfile,
                grams: float = 75.0, hours: float = 4.0, *, include_series: bool = False) -> dict:
    baseline_series = GlucoseInsulinModel(baseline).simulate(hours=hours, meals_g=[(0.0, grams)])
    treated_series = GlucoseInsulinModel(treated).simulate(hours=hours, meals_g=[(0.0, grams)])
    b, t = summarize(baseline_series), summarize(treated_series)
    d_iauc = round(t["iAUC_mg_dL_min"] - b["iAUC_mg_dL_min"], 0)
    d_mean = round(t["mean"] - b["mean"], 1)
    rel_mean = d_mean / b["mean"] if b["mean"] else 0.0        # total glycemic exposure
    decision = "EFFECT" if rel_mean <= -0.05 else ("WEAK" if rel_mean < -0.01 else "NO_EFFECT")
    result = dict(baseline=b, treated=t, delta_peak=round(t["peak"] - b["peak"], 1),
                delta_mean=d_mean, rel_mean=round(rel_mean, 3), delta_iAUC=d_iauc,
                decision=decision,
                note="model-only in-silico assay; not wet-lab or clinical evidence")
    if include_series:
        # Visualization and analysis must use the same integration as the summary.
        result["trajectory"] = {
            "t_min": baseline_series["t_min"].tolist(),
            "baseline": {key: baseline_series[key].tolist() for key in ("glucose", "insulin", "insulin_action")},
            "treated": {key: treated_series[key].tolist() for key in ("glucose", "insulin", "insulin_action")},
            "units": {"glucose": "mg/dL", "insulin": "uU/mL", "insulin_action": "1/min", "t_min": "min"},
            "evidence_state": "MODELED_MECHANISTIC",
        }
    return result
