"""Governed Cendos protocols over individualized, reference-grounded cohorts.

These functions execute mechanistic equations and structure-backed target models.
Their outputs remain modeled until the named experimental counterpart qualifies
them for a population, intervention, dose, and endpoint.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import math
from statistics import fmean
from typing import Any
import uuid

from .assays import ogtt_effect
from ..engines.metabolic.glucose_insulin import MetabolicProfile
from ..engines.pharmacology import metformin


_SUPPORTED_COHORT_CLASS = "REFERENCE_GROUNDED_SYNTHETIC"
_METFORMIN_STRATA = frozenset({"dpp-high-risk-metabolic", "nhanes-diagnosed-diabetes-older"})
_PXR_STRATA = frozenset({"pxr-reference"})


@dataclass(frozen=True)
class _ProtocolHuman:
    age: int
    weight_kg: float
    genome: dict[str, int]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _require_reference_cohort(
    cohort: object, *, allowed_strata: frozenset[str], protocol_name: str,
) -> dict[str, Any]:
    from ..reference_cohort_contract import ensure_cohort_executable
    ensure_cohort_executable(cohort)
    if not isinstance(cohort, dict) or cohort.get("source_class") != _SUPPORTED_COHORT_CLASS:
        raise ValueError("protocol requires a REFERENCE_GROUNDED_SYNTHETIC cohort")
    members = cohort.get("members")
    if not isinstance(members, list) or not members:
        raise ValueError("protocol cohort has no materialized individualized members")
    if cohort.get("stratum") not in allowed_strata:
        allowed = ", ".join(sorted(allowed_strata))
        raise ValueError(f"{protocol_name} requires one of these qualified research strata: {allowed}")
    return cohort


def _profile(member: dict[str, Any]) -> MetabolicProfile:
    parameters = member["model_parameters"]
    return MetabolicProfile(
        name=member["member_id"],
        weight_kg=float(parameters["weight_kg"]),
        Gb=float(parameters["Gb"]),
        Ib=float(parameters["Ib"]),
        SG=float(parameters["SG"]),
        Si=float(parameters["Si"]),
        gamma=float(parameters["gamma"]),
        Gt=float(parameters["Gt"]),
    )


def _summary(rows: list[dict[str, Any]]) -> dict[str, float | int | list[float]]:
    deltas = [float(row["delta_mean"]) for row in rows]
    transports = [float(row["individualization"]["oct1_transport"]) for row in rows]
    return {
        "member_count": len(rows),
        "mean_delta_glucose_mg_dL": round(fmean(deltas), 2),
        "delta_glucose_range_mg_dL": [round(min(deltas), 2), round(max(deltas), 2)],
        "mean_oct1_transport": round(fmean(transports), 3),
        "effect_count": sum(row["decision"] == "EFFECT" for row in rows),
    }


def run_metformin_cohort_comparison(
    cohort_a: dict[str, Any],
    cohort_b: dict[str, Any],
    *,
    dose_mg: float = 1000.0,
    grams: float = 75.0,
) -> dict[str, Any]:
    """Execute individualized PK→PD→OGTT trajectories for two frozen cohorts."""
    cohort_a = _require_reference_cohort(
        cohort_a, allowed_strata=_METFORMIN_STRATA, protocol_name="metformin protocol",
    )
    cohort_b = _require_reference_cohort(
        cohort_b, allowed_strata=_METFORMIN_STRATA, protocol_name="metformin protocol",
    )
    dose_mg = float(dose_mg)
    grams = float(grams)
    if not math.isfinite(dose_mg) or dose_mg <= 0 or dose_mg > 3000:
        raise ValueError("dose_mg must be finite and between 0 and 3000")
    if not math.isfinite(grams) or grams <= 0 or grams > 150:
        raise ValueError("grams must be finite and between 0 and 150")

    groups: list[dict[str, Any]] = []
    for cohort in (cohort_a, cohort_b):
        rows: list[dict[str, Any]] = []
        for member in cohort["members"]:
            baseline = _profile(member)
            human = _ProtocolHuman(
                age=int(member["age"]),
                weight_kg=float(member["model_parameters"]["weight_kg"]),
                genome=dict(member["genome"]),
            )
            treated, mechanism = metformin(
                baseline,
                human=human,
                dose=dose_mg / 1000.0,
            )
            effect = ogtt_effect(baseline, treated, grams=grams, include_series=True)
            rows.append({
                "member_id": member["member_id"],
                "age": member["age"],
                "sex": member["sex"],
                "baseline_glucose_mg_dL": baseline.Gb,
                "baseline": effect["baseline"],
                "treated": effect["treated"],
                "delta_peak": effect["delta_peak"],
                "delta_mean": effect["delta_mean"],
                "delta_iAUC": effect["delta_iAUC"],
                "trajectory": effect["trajectory"],
                "decision": effect["decision"],
                "individualization": {
                    "oct1_lof_alleles": mechanism["oct1_lof_alleles"],
                    "oct1_transport": mechanism["oct1_transport"],
                    "renal_factor": mechanism["renal_factor"],
                    "weight_kg": human.weight_kg,
                },
                "pk": mechanism["pk"],
                "mechanism": mechanism["mechanism"],
                "source_lineage": member["source_lineage"],
            })
        groups.append({
            "cohort_id": cohort["cohort_id"],
            "name": cohort["name"],
            "stratum": cohort["stratum"],
            "reference_source": cohort["reference_source"],
            "summary": _summary(rows),
            "members": rows,
        })

    return {
        "schema": "livemore.cendos-protocol-result.v1",
        "protocol_id": "cendos.metformin-cohort-comparison.v1",
        "run_id": f"protocol-{uuid.uuid4().hex}",
        "executed_at": _now(),
        "intervention": {"compound": "metformin", "dose_mg": dose_mg, "ogtt_grams": grams},
        "mechanism_chain": [
            "oral dose", "individualized renal clearance", "OCT1/SLC22A1 hepatic uptake",
            "AMPK-linked hepatic glucose output reduction", "glucose-insulin ODE response",
        ],
        "cohorts": groups,
        "evidence_state": "MODELED_MECHANISTIC",
        "qualification_state": "NOT_QUALIFIED",
        "claims_allowed": ["individualized mechanistic hypothesis", "prospective Cendos protocol design"],
        "claims_prohibited": ["observed human response", "clinical efficacy", "dosing guidance"],
        "required_counterpart": "qualified exposure, OGTT, and biomarker measurements under an approved protocol",
    }


def run_garcinoic_acid_pxr(
    cohort: dict[str, Any],
    *,
    concentrations_um: list[float],
) -> dict[str, Any]:
    """Execute structure-pinned PXR binding/activation hypotheses by concentration."""
    cohort = _require_reference_cohort(
        cohort, allowed_strata=_PXR_STRATA, protocol_name="garcinoic-acid PXR protocol",
    )
    if not isinstance(concentrations_um, list) or not concentrations_um or len(concentrations_um) > 50:
        raise ValueError("concentrations_um must contain 1 to 50 values")
    concentrations = [float(value) for value in concentrations_um]
    if any(not math.isfinite(value) or value <= 0 or value > 1000 for value in concentrations):
        raise ValueError("concentrations_um values must be finite and between 0 and 1000")
    if len(set(concentrations)) != len(concentrations):
        raise ValueError("concentrations_um must not contain duplicates")
    concentrations = sorted(concentrations)
    kd_um = 0.33
    ec50_um = 1.3
    target_rows: list[dict[str, Any]] = []
    for concentration in concentrations:
        occupancy = concentration / (kd_um + concentration)
        intrinsic_activation = concentration / (ec50_um + concentration)
        member_responses = [
            {
                "member_id": member["member_id"],
                "nr1i2_expression_factor": member["model_parameters"]["NR1I2_expression_factor"],
                "relative_pxr_activation": round(
                    intrinsic_activation * member["model_parameters"]["NR1I2_expression_factor"], 4
                ),
            }
            for member in cohort["members"]
        ]
        activation_values = [row["relative_pxr_activation"] for row in member_responses]
        target_rows.append({
            "concentration_um": concentration,
            "mean_occupancy": round(occupancy, 4),
            "intrinsic_activation": round(intrinsic_activation, 4),
            "mean_relative_activation": round(fmean(activation_values), 4),
            "relative_activation_range": [round(min(activation_values), 4), round(max(activation_values), 4)],
            "members": member_responses,
        })

    return {
        "schema": "livemore.cendos-protocol-result.v1",
        "protocol_id": "cendos.garcinoic-acid-pxr.v1",
        "run_id": f"protocol-{uuid.uuid4().hex}",
        "executed_at": _now(),
        "compound": {
            "name": "garcinoic acid",
            "form": "purified garcinoic acid",
            "botanical_context": "Garcinia kola constituent; whole-seed exposure is not represented",
        },
        "cohort": {
            "cohort_id": cohort["cohort_id"],
            "name": cohort["name"],
            "reference_source": cohort["reference_source"],
            "member_count": len(cohort["members"]),
        },
        "structure": {
            "pdb_id": "6P2B",
            "title": "Tethered human PXR-LBD/SRC-1p bound to garcinoic acid",
            "contact_count_4a": 18,
            "key_contacts": [
                {"residue": "HIS407", "atom": "NE2", "ligand_atom": "O10", "distance_angstrom": 2.43},
                {"residue": "SER247", "atom": "OG", "ligand_atom": "O09", "distance_angstrom": 2.661},
            ],
            "structure_claim": "direct crystallographic binding context",
        },
        "binding": {
            "target": "human PXR / NR1I2",
            "kd_um": kd_um,
            "ec50_um": ec50_um,
            "evidence": "published in-vitro binding and reporter measurements; not human exposure",
        },
        "target_engagement": target_rows,
        "downstream": {
            "cyp3a4_fold_induction": {
                "status": "NOT_QUANTIFIED",
                "reason": "no qualified concentration-to-human-hepatic-induction translation or human PK is admitted",
            },
        },
        "evidence_state": "STRUCTURE_AND_IN_VITRO_BACKED_MODEL",
        "qualification_state": "NOT_QUALIFIED",
        "claims_allowed": ["PXR target-engagement hypothesis", "dose-range selection for a Cendos assay"],
        "claims_prohibited": ["systemic exposure", "CYP3A4 induction magnitude", "human efficacy", "clinical safety"],
        "required_counterpart": "purified-compound identity, concentration, PXR reporter, CYP3A4 assay, and exposure measurements",
    }


__all__ = ["run_garcinoic_acid_pxr", "run_metformin_cohort_comparison"]
