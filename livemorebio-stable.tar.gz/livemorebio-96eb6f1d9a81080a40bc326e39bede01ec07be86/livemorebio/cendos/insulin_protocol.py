"""Cendos exogenous-insulin protocol (register row R33).

Design
------
Each cohort member is simulated twice from the *same* individual state: a
control arm (meal, no bolus) and a treated arm (meal plus the declared insulin
bolus). The reported effect is therefore a within-individual paired difference,
never a comparison between two unrelated members.

Individual variation comes only from parameters with published inter-subject
distributions in the Wilinska 2010 simulation environment (body weight, glucose
and insulin distribution volumes, insulin elimination). Every sampled value is
stored with its distribution and seed. Parameters without a published
distribution stay at the source value, stated as such.

Applicability
-------------
The Hovorka model has no endogenous insulin secretion. It represents
insulin-deficient physiology (the type 1 diabetes population it was built for).
It is not applicable to people with preserved beta-cell function, and results
must not be read as such.

This protocol calculates model responses. It does not recommend, and must not
be used to choose, any dose for any person.
"""
from __future__ import annotations

import hashlib
import json
import math
import random
import uuid
from datetime import datetime, timezone
from typing import Any

import numpy as np

from ..engines.metabolic.hovorka import (
    WILINSKA_2010, HovorkaModel, HovorkaParameters, InsulinDose, InsulinProductError,
    product_catalog, resolve_product, summarize,
)

PROTOCOL_ID = "cendos.exogenous-insulin-paired.v1"

_POPULATION_SOURCE = {
    "citation": ("Wilinska ME, Chassin LJ, Acerini CL, Allen JM, Dunger DB, Hovorka R. "
                 "J Diabetes Sci Technol 2010;4(1):132-144. doi:10.1177/193229681000400117"),
    "population": "type 1 diabetes virtual population (18 subjects in the source)",
    "distributions": {
        "weight_kg": {"family": "normal", "mean": 74.9, "sd": 14.4, "bounds": [40.0, 150.0]},
        "VG": {"family": "lognormal", "log_mean": math.log(0.15), "log_sd": 0.23, "bounds": [0.05, 0.40]},
        "VI": {"family": "normal", "mean": 0.12, "sd": 0.012, "bounds": [0.06, 0.20]},
        "ke": {"family": "normal", "mean": 0.14, "sd": 0.035, "bounds": [0.03, 0.40]},
    },
    "fixed_at_source_value": ["k12", "ka1", "ka2", "ka3", "SIT", "SID", "SIE",
                              "tmaxI", "tmaxG", "AG", "F01", "EGP0", "R_thr", "R_cl"],
}
_MAX_REJECTIONS = 1000


class InsulinProtocolError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        self.code = code
        super().__init__(message)


def _canonical(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode()).hexdigest()


def source_record() -> dict[str, Any]:
    """Frozen record of every source this protocol depends on."""
    params = HovorkaParameters.from_source(WILINSKA_2010)
    return {
        "schema": "livemore.insulin-protocol-sources.v1",
        "model": "Hovorka glucose-insulin system with subcutaneous absorption",
        "parameter_source": WILINSKA_2010,
        "parameters": params.provenance(),
        "population": _POPULATION_SOURCE,
        "products": product_catalog(),
    }


def _number(body: dict, key: str, default: float, low: float, high: float) -> float:
    value = body.get(key, default)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise InsulinProtocolError("INVALID_PROTOCOL", f"{key} must be a number")
    value = float(value)
    if not math.isfinite(value) or not low <= value <= high:
        raise InsulinProtocolError("INVALID_PROTOCOL", f"{key} must be within [{low}, {high}]")
    return value


def validate_spec(body: Any) -> dict[str, Any]:
    if not isinstance(body, dict):
        raise InsulinProtocolError("INVALID_PROTOCOL", "specification must be an object")
    allowed = {"product_id", "cohort_size", "seed", "bolus_units", "bolus_time_min", "meal_g",
               "meal_time_min", "basal_u_per_kg_h", "hours", "label"}
    unknown = set(body) - allowed
    if unknown:
        raise InsulinProtocolError("INVALID_PROTOCOL", f"unknown fields: {sorted(unknown)}")
    product_id = body.get("product_id", "rapid-acting-analogue-sc")
    if not isinstance(product_id, str):
        raise InsulinProtocolError("INVALID_PROTOCOL", "product_id must be a string")
    try:
        product = resolve_product(product_id)
    except InsulinProductError as error:
        raise InsulinProtocolError(error.code, str(error)) from error
    if product.route != "subcutaneous":
        raise InsulinProtocolError("INSULIN_ROUTE_NOT_SUPPORTED_BY_PROTOCOL",
                                   "The paired meal-bolus protocol is defined for subcutaneous products only.")
    cohort_size = body.get("cohort_size", 12)
    seed = body.get("seed", 0)
    for key, value, high in (("cohort_size", cohort_size, 200), ("seed", seed, 2**31 - 1)):
        if isinstance(value, bool) or not isinstance(value, int) or not (1 if key == "cohort_size" else 0) <= value <= high:
            raise InsulinProtocolError("INVALID_PROTOCOL", f"{key} must be an integer within range")
    label = body.get("label", "")
    if not isinstance(label, str) or len(label) > 120:
        raise InsulinProtocolError("INVALID_PROTOCOL", "label must be a string of at most 120 characters")
    spec = {
        "product_id": product_id,
        "cohort_size": cohort_size,
        "seed": seed,
        "bolus_units": _number(body, "bolus_units", 4.0, 0.0, 25.0),
        "bolus_time_min": _number(body, "bolus_time_min", 30.0, 0.0, 600.0),
        "meal_g": _number(body, "meal_g", 60.0, 0.0, 150.0),
        "meal_time_min": _number(body, "meal_time_min", 30.0, 0.0, 600.0),
        "basal_u_per_kg_h": _number(body, "basal_u_per_kg_h", 0.006, 0.0, 0.05),
        "hours": _number(body, "hours", 8.0, 1.0, 24.0),
        "label": label,
    }
    if spec["bolus_time_min"] >= spec["hours"] * 60 or spec["meal_time_min"] >= spec["hours"] * 60:
        raise InsulinProtocolError("INVALID_PROTOCOL", "bolus and meal must occur within the simulated horizon")
    return spec


def _draw(rng: random.Random, spec: dict[str, Any]) -> tuple[float, int]:
    low, high = spec["bounds"]
    for attempt in range(_MAX_REJECTIONS):
        if spec["family"] == "normal":
            value = rng.gauss(spec["mean"], spec["sd"])
        else:
            value = math.exp(rng.gauss(spec["log_mean"], spec["log_sd"]))
        if low <= value <= high:
            return value, attempt
    raise InsulinProtocolError("COHORT_GENERATION_FAILED", "distribution bounds rejected every draw")


def generate_cohort(size: int, seed: int) -> list[dict[str, Any]]:
    rng = random.Random(f"{PROTOCOL_ID}|{seed}")
    members = []
    for index in range(size):
        sampled, rejections = {}, {}
        for name, spec in _POPULATION_SOURCE["distributions"].items():
            sampled[name], rejections[name] = _draw(rng, spec)
        members.append({
            "member_id": f"insulin-ref-{seed}-{index:03d}",
            "sampled_parameters": {key: round(value, 9) for key, value in sampled.items()},
            "rejected_draws": rejections,
            "source_class": "REFERENCE_GROUNDED_SYNTHETIC",
            "enrolled_person": False,
        })
    return members


def _series(result: dict[str, Any], step: int = 5) -> dict[str, list[float]]:
    t = result["t_min"]
    index = np.arange(0, len(t), step)
    return {
        "t_min": [round(float(v), 3) for v in t[index]],
        "glucose_mmol_L": [round(float(v), 6) for v in result["glucose_mmol_L"][index]],
        "plasma_insulin_mU_L": [round(float(v), 6) for v in result["plasma_insulin_mU_L"][index]],
    }


def run_exogenous_insulin_protocol(spec: dict[str, Any]) -> dict[str, Any]:
    product = resolve_product(spec["product_id"])
    cohort = generate_cohort(spec["cohort_size"], spec["seed"])
    rows = []
    worst_balance = 0.0
    for member in cohort:
        sampled = member["sampled_parameters"]
        weight = sampled["weight_kg"]
        overrides = {key: sampled[key] for key in ("VG", "VI", "ke")}
        provenance = {key: f"sampled from published distribution: {_POPULATION_SOURCE['citation']}" for key in overrides}
        provenance["weight_kg"] = f"sampled from published distribution: {_POPULATION_SOURCE['citation']}"
        params = HovorkaParameters.from_source(WILINSKA_2010, weight_kg=weight, overrides=overrides,
                                               override_provenance=provenance)
        model = HovorkaModel(parameters=params, product=product)
        basal = spec["basal_u_per_kg_h"] * weight
        state = model.initial_state_from_basal(basal)
        meals = [(spec["meal_time_min"], spec["meal_g"])] if spec["meal_g"] > 0 else []
        control = model.simulate(hours=spec["hours"], meals_g=meals, basal_u_per_h=basal, initial_state=state)
        treated = model.simulate(hours=spec["hours"], meals_g=meals, basal_u_per_h=basal, initial_state=state,
                                 doses=[InsulinDose(start_min=spec["bolus_time_min"], units=spec["bolus_units"])])
        c, t = summarize(control), summarize(treated)
        worst_balance = max(worst_balance, control["insulin_mass_balance"]["relative_residual"],
                            treated["insulin_mass_balance"]["relative_residual"])
        rows.append({
            "member_id": member["member_id"],
            "weight_kg": round(weight, 3),
            "basal_u_per_h": round(basal, 6),
            "sampled_parameters": sampled,
            "baseline_glucose_mmol_L": c["baseline_glucose_mmol_L"],
            "control": c,
            "treated": t,
            "paired_difference": {
                "delta_glucose_auc_mmol_L_min": round(t["glucose_auc_mmol_L_min"] - c["glucose_auc_mmol_L_min"], 3),
                "delta_nadir_mmol_L": round(t["nadir_glucose_mmol_L"] - c["nadir_glucose_mmol_L"], 4),
                "delta_peak_mmol_L": round(t["peak_glucose_mmol_L"] - c["peak_glucose_mmol_L"], 4),
                "delta_minutes_below_3_9": round(t["minutes_below_3_9_mmol_L"] - c["minutes_below_3_9_mmol_L"], 2),
            },
            "series": {"control": _series(control), "treated": _series(treated)},
        })

    deltas = [row["paired_difference"]["delta_glucose_auc_mmol_L_min"] for row in rows]
    below = [row["treated"]["minutes_below_3_9_mmol_L"] for row in rows]
    zero_control = _zero_dose_control(spec, product)
    record = source_record()
    return {
        "schema": "livemore.cendos-protocol-result.v1",
        "protocol_id": PROTOCOL_ID,
        "run_id": "protocol-" + uuid.uuid4().hex,
        "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "input": spec, "input_sha256": canonical_hash(spec),
        "source_record": record, "source_sha256": canonical_hash(record),
        "intervention": {"product": product.to_dict(), "bolus_units": spec["bolus_units"],
                         "bolus_time_min": spec["bolus_time_min"]},
        "design": "within-individual paired control and treated arms from an identical initial state",
        "applicability": ("Insulin-deficient physiology only: the model has no endogenous insulin secretion. "
                          "Not applicable to preserved beta-cell function."),
        "members": rows,
        "summary": {
            "member_count": len(rows),
            "mean_delta_glucose_auc_mmol_L_min": round(float(np.mean(deltas)), 3),
            "delta_glucose_auc_range": [round(float(min(deltas)), 3), round(float(max(deltas)), 3)],
            "members_with_any_time_below_3_9_treated": int(sum(value > 0 for value in below)),
        },
        "controls": [
            zero_control,
            {"control": "insulin mass balance across every simulated arm",
             "worst_relative_residual": worst_balance, "passed": worst_balance < 1e-6},
        ],
        "evidence_state": "MODELED_ONLY",
        "qualification_state": "NOT_QUALIFIED",
        "calibration_authorized": False,
        "interpretation_limits": [
            "Model calculation over a published virtual population; no enrolled person was simulated.",
            "Members differ only in sampled weight, glucose and insulin volumes and insulin elimination.",
            "Not a validated prediction for any individual and not dosing guidance.",
            "Independent physical measurements are required before any equivalence claim.",
        ],
    }


def _zero_dose_control(spec: dict[str, Any], product) -> dict[str, Any]:
    params = HovorkaParameters.from_source(WILINSKA_2010)
    model = HovorkaModel(parameters=params, product=product)
    basal = spec["basal_u_per_kg_h"] * params.weight_kg
    state = model.initial_state_from_basal(basal)
    meals = [(spec["meal_time_min"], spec["meal_g"])] if spec["meal_g"] > 0 else []
    a = model.simulate(hours=spec["hours"], meals_g=meals, basal_u_per_h=basal, initial_state=state)
    b = model.simulate(hours=spec["hours"], meals_g=meals, basal_u_per_h=basal, initial_state=state,
                       doses=[InsulinDose(start_min=spec["bolus_time_min"], units=0.0)])
    identical = bool(np.array_equal(a["glucose_mmol_L"], b["glucose_mmol_L"]))
    return {"control": "zero-unit bolus reproduces the no-bolus arm exactly", "passed": identical}


__all__ = ["PROTOCOL_ID", "InsulinProtocolError", "generate_cohort", "run_exogenous_insulin_protocol",
           "source_record", "validate_spec", "canonical_hash"]
