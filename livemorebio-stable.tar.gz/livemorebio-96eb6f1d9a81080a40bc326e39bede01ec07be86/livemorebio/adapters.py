"""Governed registry for scientific data adapters.

Adapter availability is an operational fact, not scientific validation.  Open
sources may be enabled and health-probed. Restricted sources are represented so
the UI can explain the gate, but the code deliberately makes no network request.
"""
from __future__ import annotations

import os
import hashlib
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from copy import deepcopy

from .life_system.reference.sources.entitlements import (
    genecards_entitlement,
    kegg_entitlement,
)


SCHEMA = "livemore.scientific-adapters.v1"
_PROBE_RESULTS: dict[str, tuple[float, str]] = {}
_PROBE_TTL_SECONDS = 300

_ADAPTERS = (
    {"id": "chembl", "name": "ChEMBL", "capabilities": ["compound_identity", "mechanism", "bioactivity"],
     "license": "CC BY-SA 3.0 data", "access": "open", "enabled": True,
     "license_url": "https://chembl.gitbook.io/chembl-interface-documentation/about",
     "integration": "active", "used_by": ["cohort_screen", "discovery_pipeline"],
     "probe_url": "https://www.ebi.ac.uk/chembl/api/data/status.json"},
    {"id": "pubchem", "name": "PubChem PUG REST", "capabilities": ["compound_identity", "properties"],
     "license": "US government public resource", "access": "open", "enabled": True,
     "license_url": "https://www.ncbi.nlm.nih.gov/home/about/policies/",
     "integration": "active", "used_by": ["cendos_compound_resolution", "discovery_pipeline"],
     "probe_url": "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/metformin/cids/JSON"},
    {"id": "opentargets", "name": "Open Targets Platform", "capabilities": ["target_disease_evidence"],
     "license": "open platform terms", "access": "open", "enabled": True,
     "license_url": "https://platform.opentargets.org/licence",
     "integration": "active", "used_by": ["disease_target_resolution"],
     "probe_url": "https://api.platform.opentargets.org/api/v4/graphql"},
    {"id": "uniprot", "name": "UniProt", "capabilities": ["protein_identity", "cross_references"],
     "license": "CC BY 4.0", "access": "open", "enabled": True,
     "license_url": "https://www.uniprot.org/help/license",
     "integration": "active", "used_by": ["biology_structure_resolution"],
     "probe_url": "https://rest.uniprot.org/uniprotkb/P04637.json"},
    {"id": "rcsb", "name": "RCSB PDB", "capabilities": ["macromolecular_structure"],
     "license": "CC0", "access": "open", "enabled": True,
     "license_url": "https://www.rcsb.org/pages/policies",
     "integration": "active", "used_by": ["biology_structure_resolution", "reference_graph"],
     "probe_url": "https://data.rcsb.org/rest/v1/core/entry/1HWK"},
    {"id": "reactome", "name": "Reactome", "capabilities": ["pathways", "reactions"],
     "license": "CC0", "access": "open", "enabled": True,
     "license_url": "https://reactome.org/license",
     "integration": "active", "used_by": ["biological_reference_graph"],
     "probe_url": "https://reactome.org/ContentService/data/database/version"},
    {"id": "gwas_catalog", "name": "GWAS Catalog", "capabilities": ["variant_trait_evidence"],
     "license": "EMBL-EBI terms", "access": "open", "enabled": True,
     "license_url": "https://www.ebi.ac.uk/about/terms-of-use/",
     "integration": "active", "used_by": ["reference_calibration", "polygenic_risk"],
     "probe_url": "https://www.ebi.ac.uk/gwas/rest/api/studies?size=1"},
    {"id": "ols", "name": "EBI Ontology Lookup Service", "capabilities": ["ontology_terms"],
     "license": "source-ontology licenses", "access": "open", "enabled": True,
     "license_url": "https://www.ebi.ac.uk/about/terms-of-use/",
     "integration": "active", "used_by": ["reference_ontology"],
     "probe_url": "https://www.ebi.ac.uk/ols4/api/ontologies"},
    {"id": "human_reference_atlas", "name": "HuBMAP Human Reference Atlas", "capabilities": ["anatomy_assets"],
     "license": "CC BY 4.0 assets", "access": "open", "enabled": True,
     "license_url": "https://humanatlas.io/",
     "integration": "active", "used_by": ["biology_anatomy"],
     "probe_url": "https://apps.humanatlas.io/api/"},
    {"id": "usda_fdc", "name": "USDA FoodData Central", "capabilities": ["food_composition"],
     "license": "US government public data", "access": "api_key", "enabled": False,
     "license_url": "https://fdc.nal.usda.gov/data-documentation.html",
     "integration": "credential_gated", "used_by": ["food_composition_resolution"],
     "credential_env": "USDA_API_KEY", "probe_url": "https://api.nal.usda.gov/fdc/v1/foods/search"},
    {"id": "kegg", "name": "KEGG", "capabilities": ["pathways", "genes", "reactions"],
     "license": "commercial use requires an organizational license", "access": "restricted", "enabled": False,
     "license_url": "https://www.kegg.jp/kegg/legal.html",
     "integration": "license_gated", "used_by": ["biological_reference_graph", "cendos_evidence_context"],
     "reason": "blocked until Livemore records commercial-use licensing"},
    {"id": "genecards", "name": "GeneCards", "capabilities": ["gene_disease_aggregation"],
     "license": "licensed resource", "access": "restricted", "enabled": False,
     "license_url": "https://www.genecards.org/Guide/LegalNotice",
     "integration": "license_gated", "used_by": ["biological_reference_graph", "cendos_evidence_context"],
     "reason": "blocked until Livemore records licensed API/data access"},
    {"id": "malacards", "name": "MalaCards", "capabilities": ["disease_reference", "gene_disease_aggregation"],
     "license": "vendor-authorized commercial reference access", "access": "restricted", "enabled": False,
     "license_url": "https://www.lifemapsc.com/terms-of-use/",
     "integration": "license_gated", "used_by": ["research_disease_context"],
     "reason": "requires a permitted, current licensed local release"},
    {"id": "rosalind", "name": "Rosalind Workbench", "capabilities": ["governed_external_analysis"],
     "license": "connector-controlled", "access": "external_handoff", "enabled": False,
     "integration": "external_handoff", "used_by": [],
     "reason": "available as a governed external workbench handoff, not an in-process data source"},
)


def _probe_url(url: str, timeout: float) -> str:
    request = urllib.request.Request(url, headers={"User-Agent": "LivemoreBio/0.0.1 research"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return "ready" if 200 <= response.status < 300 else "degraded"
    except Exception:
        return "degraded"


def statuses(*, probe: bool = False, timeout: float = 2.0) -> list[dict]:
    rows = []
    probe_targets: dict[int, str] = {}
    cache_keys: dict[int, str] = {}
    for declared in _ADAPTERS:
        row = deepcopy(declared)
        credential = row.get("credential_env")
        if row["access"] == "restricted":
            from .life_system.reference.sources import LicensedReferenceStore
            local = LicensedReferenceStore().source_status(row["id"]) if row["id"] in {"kegg", "malacards"} else {}
            entitlement = (kegg_entitlement() if row["id"] == "kegg" else
                           genecards_entitlement() if row["id"] == "genecards" else None)
            configured = bool(entitlement and entitlement.configured)
            admitted = local.get("status") == "available"
            row["enabled"] = admitted or configured
            row["status"] = "ready" if admitted else "configured" if configured else "blocked"
            row["integration"] = "local_reference_lookup" if admitted else "transport_unverified" if configured else "license_gated"
            row["reason"] = ("Current licensed release passed local integrity and permission checks; reference facts only" if admitted else
                             "Transport configured but not operationally verified" if configured else
                             entitlement.reason if entitlement else "No current permitted MalaCards release is installed")
            row["scientific_qualification"] = "NOT_QUALIFIED"
            if entitlement and entitlement.fingerprint:
                row["entitlement_fingerprint"] = entitlement.fingerprint
        elif row["access"] == "external_handoff":
            row["status"] = "external"
        elif credential:
            value = os.environ.get(credential, "").strip()
            if not value:
                row["status"] = "disabled"
                row["reason"] = f"set {credential} to enable"
            else:
                row["enabled"] = True
                if probe:
                    from urllib.parse import urlencode
                    url = row["probe_url"] + "?" + urlencode(
                        {"query": "turmeric", "pageSize": 1, "api_key": value})
                    row["status"] = "probing"
                    probe_targets[len(rows)] = url
                else:
                    row["status"] = "configured"
        elif row["enabled"]:
            row["status"] = "probing" if probe else "configured"
            if probe:
                probe_targets[len(rows)] = row["probe_url"]
        else:
            row["status"] = "disabled"
        if row["enabled"] and row["access"] in {"open", "api_key"}:
            # Successful bounded probes qualify reachability for five minutes only.
            # Credential/config changes never inherit another transport's result.
            cache_identity = "\0".join((row["id"], row.get("probe_url", ""),
                                         os.environ.get(credential, "") if credential else ""))
            key = hashlib.sha256(cache_identity.encode()).hexdigest()
            cache_keys[len(rows)] = key
            cached = _PROBE_RESULTS.get(key)
            if not probe and cached and time.monotonic() - cached[0] < _PROBE_TTL_SECONDS:
                row["status"] = cached[1]
                row["probe_evidence"] = "bounded endpoint response within 5 minutes; not scientific qualification"
        row.pop("probe_url", None)
        rows.append(row)
    if probe_targets:
        with ThreadPoolExecutor(max_workers=min(8, len(probe_targets))) as executor:
            futures = {
                executor.submit(_probe_url, url, timeout): index
                for index, url in probe_targets.items()
            }
            for future in as_completed(futures):
                index = futures[future]
                rows[index]["status"] = future.result()
                _PROBE_RESULTS[cache_keys[index]] = (time.monotonic(), rows[index]["status"])
                rows[index]["probe_evidence"] = "bounded endpoint response; not scientific qualification"
    return rows


def registry(*, probe: bool = False) -> dict:
    rows = statuses(probe=probe)
    return {
        "schema": SCHEMA,
        "note": "enabled means a governed retrieval path is available; readiness never promotes model or evidence maturity",
        "adapters": rows,
        "counts": {state: sum(1 for row in rows if row["status"] == state)
                   for state in ("ready", "degraded", "disabled", "blocked", "external")},
    }
