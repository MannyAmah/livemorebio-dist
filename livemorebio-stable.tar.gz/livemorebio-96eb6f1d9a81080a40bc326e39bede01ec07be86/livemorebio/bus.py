"""livemorebio.bus — cross-system event bus + shared state for LivemoreBio.

A file-backed pub/sub layer so the three services (LIFE, Aegle, Cendos) share one
living context: Aegle publishes the current twin snapshot and perturbation events;
Cendos reads that snapshot to assay the SAME twin and publishes assay results; any
client polls the event log to reflect cross-system activity in real time.

Honest and simple by design: an append-only JSONL event log plus per-key JSON
snapshots under ~/.livemore. Only real engine state and real events ever flow
through the bus — nothing here fabricates data.

Scaling beyond one host (NATS for services, MQTT at the LIFE Patch edge) is a
documented, deliberate upgrade path — see docs/BUS_UPGRADE_PATH.md. The event
vocabulary in livemorebio.events is the stable contract across transports.
"""
from __future__ import annotations
import base64
import json
import os
import time
import tempfile

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from . import registry
BUS_DIR = registry.REG_DIR
EVENTS = os.path.join(BUS_DIR, "events.jsonl")
SNAP_DIR = os.path.join(BUS_DIR, "snapshots")
_MAX_EVENTS = 500
_ENCRYPTED_FIELD = "_livemore_encrypted"
_AAD = b"livemore.local-bus.v1"


def _private_directory(path):
    os.makedirs(path, mode=0o700, exist_ok=True)
    os.chmod(path, 0o700)


def _protect(value):
    from .security import patch_storage_key

    key = patch_storage_key(create=False)
    if key is None:
        return value
    nonce = os.urandom(12)
    plaintext = json.dumps(
        value, sort_keys=True, separators=(",", ":"), allow_nan=False,
    ).encode("utf-8")
    ciphertext = AESGCM(key).encrypt(nonce, plaintext, _AAD)
    return {
        _ENCRYPTED_FIELD: "AES-256-GCM",
        "nonce": base64.urlsafe_b64encode(nonce).decode("ascii"),
        "ciphertext": base64.urlsafe_b64encode(ciphertext).decode("ascii"),
    }


def _unprotect(value):
    if not isinstance(value, dict) or value.get(_ENCRYPTED_FIELD) != "AES-256-GCM":
        return value
    from .security import patch_storage_key

    key = patch_storage_key(create=False)
    if key is None:
        raise RuntimeError("encrypted Livemore state requires LIVEMORE_PATCH_STORAGE_KEY")
    nonce = base64.urlsafe_b64decode(str(value["nonce"]).encode("ascii"))
    ciphertext = base64.urlsafe_b64decode(str(value["ciphertext"]).encode("ascii"))
    plaintext = AESGCM(key).decrypt(nonce, ciphertext, _AAD)
    return json.loads(plaintext)


def _atomic_write(path, text):
    _private_directory(os.path.dirname(path))
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, path)
    except Exception:
        try:
            os.path.exists(tmp) and os.remove(tmp)
        except Exception:
            pass


def publish(source, type, payload=None):
    """Append a real event to the bus. Returns the event dict."""
    _private_directory(BUS_DIR)
    ev = {"ts": time.time(), "source": source, "type": type, "payload": payload or {}}
    try:
        descriptor = os.open(EVENTS, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        with os.fdopen(descriptor, "a", encoding="utf-8") as f:
            f.write(json.dumps(_protect(ev), separators=(",", ":")) + "\n")
        _trim()
    except Exception:
        pass
    return ev


def _trim():
    try:
        with open(EVENTS, encoding="utf-8") as f:
            lines = f.readlines()
        if len(lines) > _MAX_EVENTS:
            _atomic_write(EVENTS, "".join(lines[-_MAX_EVENTS:]))
    except Exception:
        pass


def events(after_ts=0.0, limit=100):
    """Return real events with ts strictly greater than after_ts (oldest first)."""
    out = []
    try:
        with open(EVENTS, encoding="utf-8") as f:
            for line in f:
                try:
                    ev = _unprotect(json.loads(line))
                except Exception:
                    continue
                if float(ev.get("ts", 0)) > float(after_ts):
                    out.append(ev)
    except Exception:
        pass
    return out[-limit:]


def set_snapshot(key, value):
    """Publish the current shared state for a key (e.g. the live twin)."""
    _atomic_write(
        os.path.join(SNAP_DIR, key + ".json"),
        json.dumps(_protect(value), separators=(",", ":")),
    )


def snapshot(key):
    """Read the current shared state for a key, or None."""
    try:
        with open(os.path.join(SNAP_DIR, key + ".json"), encoding="utf-8") as f:
            return _unprotect(json.load(f))
    except Exception:
        return None
