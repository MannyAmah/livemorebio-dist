"""``livemore doctor``: fresh-machine readiness report with honest exit status.

Required checks decide the exit code. Optional checks are reported but never
turn a working installation into a failure. Secret values are never printed;
only presence and file permissions are reported.
"""
from __future__ import annotations

import importlib
import json
import os
import stat
import sys
import urllib.request
from typing import Any

REQUIRED_MODULES = ("numpy", "scipy", "cryptography", "networkx", "fastapi", "uvicorn")
KERNEL_MODULES = ("myokit", "cobra", "libsbml", "libcellml", "roadrunner", "basico")
NOTEBOOK_MODULES = ("jupyterlab", "pandas", "matplotlib", "nbformat", "nbclient")
PROBES = {
    "pubchem": "https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/2244/property/MolecularWeight/JSON",
    "uniprot": "https://rest.uniprot.org/uniprotkb/P04637.json?fields=accession",
    "chembl": "https://www.ebi.ac.uk/chembl/api/data/status.json",
    "rcsb": "https://data.rcsb.org/rest/v1/core/entry/1HWK",
}


def _module(name: str) -> dict[str, Any]:
    try:
        module = importlib.import_module(name)
    except Exception as error:  # noqa: BLE001 - any import failure is a diagnostic result
        return {"name": name, "ok": False, "detail": type(error).__name__}
    return {"name": name, "ok": True, "detail": str(getattr(module, "__version__", "installed"))}


def _data_dir() -> dict[str, Any]:
    from . import registry
    path = registry.REG_DIR
    record: dict[str, Any] = {"path": path, "exists": os.path.isdir(path)}
    if record["exists"]:
        mode = stat.S_IMODE(os.stat(path).st_mode)
        record["mode"] = oct(mode)
        record["private"] = mode & 0o077 == 0
        record["keys_present"] = {name: os.path.exists(os.path.join(path, name))
                                  for name in ("api-token", "patch-storage.key", "patch-admission.key")}
    return record


def _services() -> list[dict[str, Any]]:
    from .cli import SERVICES, _health
    return [{"service": name, "port": port, "healthy": bool(_health(port))}
            for name, (_, port) in SERVICES.items()]


def _probe(url: str) -> bool:
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "livemore-doctor"}),
                                    timeout=6) as response:
            return 200 <= response.status < 400
    except Exception:  # noqa: BLE001
        return False


def report(*, network: bool = False) -> dict[str, Any]:
    from ._platform import support as platform_support
    from ._toolchain import node_executable, playwright_available, playwright_module
    from . import model_assets
    python_ok = sys.version_info >= (3, 11)
    required = [_module(name) for name in REQUIRED_MODULES]
    try:
        human_gem = model_assets.status("human-gem")
    except Exception as error:  # noqa: BLE001
        human_gem = {"available": False, "code": type(error).__name__}
    try:
        from .engines.metabolic.hovorka import HovorkaModel, InsulinDose
        HovorkaModel().simulate(hours=1, doses=[InsulinDose(start_min=0, units=1.0)])
        insulin_engine = {"ok": True}
    except Exception as error:  # noqa: BLE001
        insulin_engine = {"ok": False, "detail": type(error).__name__}
    platform_state = platform_support()
    result = {
        "schema": "livemore.doctor.v1",
        "platform": platform_state,
        "python": {"version": sys.version.split()[0], "ok": python_ok, "executable": sys.executable},
        "required_modules": required,
        "kernel_modules": [_module(name) for name in KERNEL_MODULES],
        "notebook_modules": [_module(name) for name in NOTEBOOK_MODULES],
        "insulin_engine": insulin_engine,
        "human_gem_assets": {"available": bool(human_gem.get("available")), "code": human_gem.get("code")},
        "node": {"path": node_executable(), "ok": node_executable() is not None},
        "playwright": {"module": playwright_module(), "ok": playwright_available()},
        "data_dir": _data_dir(),
        "services": _services(),
        "network": {name: _probe(url) for name, url in PROBES.items()} if network else "not checked (use --network)",
    }
    result["required_ok"] = (platform_state["supported_natively"] and python_ok
                             and all(item["ok"] for item in required) and insulin_engine["ok"])
    return result


def render(result: dict[str, Any]) -> str:
    def mark(ok):
        return "OK  " if ok else "FAIL" if ok is False else "--  "
    lines = ["LivemoreBio doctor", ""]
    state = result.get("platform", {})
    lines.append(f"{mark(state.get('supported_natively'))} platform {state.get('system')} {state.get('release')}")
    if not state.get("supported_natively", True):
        lines.append(f"     {state.get('reason')}")
        lines.append(f"     {state.get('guidance')}")
    lines.append(f"{mark(result['python']['ok'])} python {result['python']['version']}  ({result['python']['executable']})")
    for group in ("required_modules", "kernel_modules", "notebook_modules"):
        label = group.replace("_", " ")
        for item in result[group]:
            required = group == "required_modules"
            lines.append(f"{mark(item['ok']) if required or item['ok'] else 'WARN'} {label:17} {item['name']:12} {item['detail']}")
    lines.append(f"{mark(result['insulin_engine']['ok'])} insulin engine smoke run")
    lines.append(f"{'OK  ' if result['human_gem_assets']['available'] else 'WARN'} Human-GEM assets "
                 f"({'installed' if result['human_gem_assets']['available'] else 'run: livemore models install human-gem'})")
    lines.append(f"{'OK  ' if result['node']['ok'] else 'WARN'} node {result['node']['path'] or 'not found (browser-harness tests skip)'}")
    lines.append(f"{'OK  ' if result['playwright']['ok'] else 'WARN'} playwright {result['playwright']['module']}")
    data = result["data_dir"]
    if data["exists"]:
        lines.append(f"{'OK  ' if data['private'] else 'WARN'} data dir {data['path']} mode {data['mode']}")
        for name, present in data["keys_present"].items():
            lines.append(f"{'OK  ' if present else '--  '}   {name} {'present' if present else 'absent (created on first start)'}")
    else:
        lines.append(f"--   data dir {data['path']} not created yet (created by `livemore start`)")
    for service in result["services"]:
        lines.append(f"{'OK  ' if service['healthy'] else '--  '} service {service['service']:7} :{service['port']} "
                     f"{'healthy' if service['healthy'] else 'not running'}")
    if isinstance(result["network"], dict):
        for name, ok in result["network"].items():
            lines.append(f"{'OK  ' if ok else 'WARN'} reachable {name}")
    else:
        lines.append(f"--   network {result['network']}")
    lines.append("")
    lines.append("READY" if result["required_ok"] else "NOT READY: fix the FAIL lines above")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    import argparse
    parser = argparse.ArgumentParser(prog="livemore doctor")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--network", action="store_true", help="probe public scientific APIs")
    args = parser.parse_args(argv)
    result = report(network=args.network)
    print(json.dumps(result, indent=2, sort_keys=True) if args.json else render(result))
    return 0 if result["required_ok"] else 1
