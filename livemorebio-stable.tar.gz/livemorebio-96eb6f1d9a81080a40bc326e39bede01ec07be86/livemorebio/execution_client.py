"""Attached-only client primitives; scientific and access authority stays server-side."""
from __future__ import annotations

import ipaddress
import json
import math
import re
from typing import Any
import urllib.error
import urllib.parse
import urllib.request

from .strict_json import parse_frozen_member_response, parse_json_object

MAX_REQUEST_BYTES = 16 * 1024
MAX_RESEARCH_PREVIEW_REQUEST_BYTES = 2_000_000
MAX_RESPONSE_BYTES = 8 * 1024 * 1024
MAX_FROZEN_MEMBER_RESPONSE_BYTES = 16 * 1024 * 1024
_UUID_PATTERN = r"[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}"
_REQUEST_ID_PATTERN = r"(?:[0-9a-f]{32}|" + _UUID_PATTERN + r")"
_PREPARE = {"engine_contract_id", "expected_source_generation", "expected_twin_id", "expected_twin_version", "policy"}
_CODES = {"EXECUTION_INVALID", "EXECUTION_CONFLICT", "EXECUTION_OWNED", "EXECUTION_STORAGE", "EXECUTION_QUOTA",
    "EXECUTION_SOLVER", "EXECUTION_CLOSED", "EXECUTION_RESTART_REQUIRED", "EXECUTION_SOURCE_REQUIRED",
    "EXECUTION_UNAVAILABLE", "MODEL_SOURCE_CHANGED", "CLIENT_INVALID", "CLIENT_ATTACH_REQUIRED", "CLIENT_AUTH_REQUIRED",
    "CLIENT_UNCONFIRMED", "CLIENT_TRANSPORT", "CLIENT_RESPONSE", "CLIENT_OUTPUT",
    "EXECUTION_CLEANUP_UNCONFIRMED", "MODEL_BINDING_REQUIRED", "PATCH_BINDING_REQUIRED", "PATCH_JOURNAL_INVALID", "MODEL_CONTEXT_INVALID",
    "MODEL_CONTEXT_UNSUPPORTED", "MODEL_CONTEXT_SOURCE_MISMATCH", "SELECTION_COMMIT_UNCONFIRMED",
    "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED", "RECORD_NOT_FOUND", "TWIN_VERSION_CONFLICT",
    "INVALID_TWIN_DATA", "INVALID_PAGE", "INVALID_COHORT_DATA", "COHORT_MEMBER_SNAPSHOT_REQUIRED",
    "COHORT_SNAPSHOT_INVALID", "SUBJECT_ADMISSION_REQUIRED", "INVALID_REQUEST_ID",
    "SELECTION_RECONCILIATION_CONFLICT", "REGISTRY_STORAGE_UNAVAILABLE", "INVALID_NOTE", "INVALID_INTERVENTION"}


class ContinuousClientError(ValueError):
    def __init__(self, code: str = "CLIENT_INVALID", *, status: int | None = None, request_id: str | None = None) -> None:
        self.code = code if code in _CODES else "CLIENT_RESPONSE"
        self.status = status if type(status) is int and 100 <= status <= 599 else None
        self.request_id = request_id if type(request_id) is str and re.fullmatch(_REQUEST_ID_PATTERN, request_id) else None
        message = {"CLIENT_ATTACH_REQUIRED": "Continuous commands require an attached platform; no offline fallback is available.",
            "CLIENT_AUTH_REQUIRED": "Attached continuous commands require local operator authentication.",
            "CLIENT_UNCONFIRMED": "Operation not confirmed; inspect the known execution/session before retrying.",
            "EXECUTION_STORAGE": "Storage or audit confirmation is incomplete; the operation may have committed. Inspect the known execution/session before retrying.",
            "EXECUTION_CLEANUP_UNCONFIRMED": "Prior execution cleanup is unconfirmed. Inspect its status before an explicit cleanup retry.",
            "SELECTION_COMMIT_UNCONFIRMED": "Selection storage outcome is unconfirmed. Inspect authoritative state; do not repeat selection automatically.",
            "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED": "Selection committed but prior execution cleanup is unconfirmed. Inspect the selected record and execution status.",
            "CLIENT_OUTPUT": "Server response confirmed; private output could not be completed. No existing file was overwritten."}.get(
                self.code, "Continuous operation rejected or unavailable; inspect its safe status code.")
        super().__init__(message)


def identifier(value: Any, *, opaque: bool = False) -> str:
    pattern = r"[0-9a-f]{32}" if opaque else r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}"
    if type(value) is not str or re.fullmatch(pattern, value) is None:
        raise ContinuousClientError()
    return value


def _is_frozen_member_read(method: str, path: str, body: dict | None, status: int) -> bool:
    if method != "GET" or body is not None or type(status) is not int or status != 200 or type(path) is not str:
        return False
    match = re.fullmatch(r"/api/cohorts/([^/]+)/members/([^/]+)", path)
    if match is None:
        return False
    try:
        for segment in match.groups():
            decoded = identifier(urllib.parse.unquote(segment, errors="strict"))
            if urllib.parse.quote(decoded, safe="") != segment:
                return False
    except ValueError:
        return False
    return True


def integer(value: Any, minimum: int = 1, maximum: int = 1_000_000) -> int:
    if type(value) is not int or not minimum <= value <= maximum:
        raise ContinuousClientError()
    return value


def control_guard(revision: int | None, control_revision: int | None) -> dict[str, int]:
    """Choose an explicit intent guard; never read or infer a fresher revision."""
    if (revision is None) == (control_revision is None):
        raise ContinuousClientError()
    if control_revision is not None:
        return {"expected_control_revision": integer(control_revision)}
    return {"expected_revision": integer(revision)}


def request_key(value: Any) -> str:
    if (type(value) is not str or not 1 <= len(value) <= 128 or value != value.strip()
            or any(ord(char) < 32 or ord(char) > 126 for char in value)):
        raise ContinuousClientError()
    return value


def payload_copy(value: Any, fields: set[str]) -> dict[str, Any]:
    try:
        if not isinstance(value, dict) or set(value) != fields:
            raise ValueError()
        return parse_json_object(json.dumps(value, allow_nan=False).encode(), max_bytes=MAX_REQUEST_BYTES)
    except Exception:
        raise ContinuousClientError() from None


def _research_preview_body(path: str, body: Any) -> dict[str, Any]:
    """This named compatibility exception cannot widen ordinary mutation requests."""
    ancestors: set[int] = set()
    def domain(value: Any, depth: int = 0) -> None:
        if value is None or type(value) in {str, bool}:
            return
        if type(value) is int and abs(value) <= 2**53 - 1:
            return
        if type(value) is float and math.isfinite(value):
            return
        if type(value) not in {dict, list} or depth >= 64 or id(value) in ancestors:
            raise ContinuousClientError()
        ancestors.add(id(value))
        try:
            if type(value) is dict:
                if any(type(key) is not str for key in value):
                    raise ContinuousClientError()
                for item in value.values():
                    domain(item, depth + 1)
            else:
                for item in value:
                    domain(item, depth + 1)
        finally:
            ancestors.remove(id(value))
    try:
        domain(body)
        raw = json.dumps(body, allow_nan=False, separators=(",", ":")).encode()
        result = parse_json_object(raw, max_bytes=MAX_RESEARCH_PREVIEW_REQUEST_BYTES)
        if path == "/api/ingest_note":
            if set(result) != {"text"} or type(result["text"]) is not str or not result["text"].strip():
                raise ContinuousClientError()
        elif path == "/api/stimulate":
            if set(result) != {"kind", "params"} or type(result["params"]) is not dict:
                raise ContinuousClientError()
            kind, params = result["kind"], result["params"]
            if kind == "base":
                if params.get("base", "healthy") not in ("healthy", "t2d", "type-2-diabetes"):
                    raise ContinuousClientError()
            elif kind == "life_system":
                if params.get("mode", "random") not in ("random", "t2d_apoe4", "carrier", "custom"):
                    raise ContinuousClientError()
            else:
                raise ContinuousClientError()
        else:
            raise ContinuousClientError()
        return result
    except (ValueError, TypeError, OverflowError, RecursionError):
        raise ContinuousClientError() from None


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, new_url):
        return None


class ContinuousExecutionClient:
    """Mixin for Platform; importing it never creates a model, token or store."""
    def _continuous_require_attach(self) -> None:
        if self.mode != "attach":
            raise ContinuousClientError("CLIENT_ATTACH_REQUIRED")

    def _continuous_request(self, method: str, path: str, body: dict | None = None, *,
                            idempotency_key: str | None = None, timeout: float = 20,
                            expected_status: int | None = None) -> dict[str, Any]:
        return self._request_json(method, path, body, idempotency_key=idempotency_key,
            timeout=timeout, expected_status=expected_status, request_limit=MAX_REQUEST_BYTES)

    def _research_preview_request(self, path: str, body: dict, *, timeout: float = 60) -> dict[str, Any]:
        self._continuous_require_attach()
        self.last_continuous_response = {}
        value = _research_preview_body(path, body)
        return self._request_json("POST", path, value, timeout=timeout, expected_status=200,
                                 request_limit=MAX_RESEARCH_PREVIEW_REQUEST_BYTES)

    def _request_json(self, method: str, path: str, body: dict | None = None, *,
                      idempotency_key: str | None = None, timeout: float = 20,
                      expected_status: int | None = None, request_limit: int) -> dict[str, Any]:
        self._continuous_require_attach()
        self.last_continuous_response = {}
        if type(request_limit) is not int or request_limit not in {MAX_REQUEST_BYTES, MAX_RESEARCH_PREVIEW_REQUEST_BYTES}:
            raise ContinuousClientError()
        if request_limit != MAX_REQUEST_BYTES:
            if method != "POST" or idempotency_key is not None:
                raise ContinuousClientError()
            body = _research_preview_body(path, body)
        if expected_status is not None and (type(expected_status) is not int or expected_status not in {200, 201}):
            raise ContinuousClientError()
        response = None
        status = None
        unreadable_code = "CLIENT_UNCONFIRMED" if method == "POST" else "CLIENT_RESPONSE"
        try:
            base = self._url()
            parsed = urllib.parse.urlsplit(base)
            try:
                loopback = ipaddress.ip_address(parsed.hostname).is_loopback
            except ValueError:
                loopback = parsed.hostname == "localhost"
            if (parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password
                    or parsed.query or parsed.fragment or (parsed.scheme == "http" and not loopback)):
                raise ContinuousClientError()
            from .security import authorization_headers
            try:
                auth = authorization_headers()
            except Exception:
                raise ContinuousClientError("CLIENT_AUTH_REQUIRED") from None
            headers = {"Content-Type": "application/json", "Accept": "application/json", "Accept-Encoding": "identity", **auth}
            if idempotency_key is not None:
                headers["Idempotency-Key"] = request_key(idempotency_key)
            raw = None if body is None else json.dumps(body, allow_nan=False, separators=(",", ":")).encode()
            if raw is not None and len(raw) > request_limit:
                raise ContinuousClientError()
            request = urllib.request.Request(base.rstrip("/") + path, data=raw, method=method, headers=headers)
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect())
            try:
                response = opener.open(request, timeout=timeout)
            except urllib.error.HTTPError as error:
                response = error
            status = response.status
            metadata = {}
            for header, field, pattern in (
                ("X-Livemore-Request-Id", "request_id", r"[0-9a-f]{32}"),
                ("X-Request-ID", "request_id", _UUID_PATTERN),
                ("X-Livemore-Source-Sha256", "source_sha256", r"[0-9a-f]{64}"),
                ("X-Livemore-Process-Instance", "process_instance", r"[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}")):
                value = response.headers.get(header)
                if type(value) is str and re.fullmatch(pattern, value):
                    metadata[field] = value
            self.last_continuous_response = metadata
            if response.headers.get("Content-Encoding", "identity") != "identity":
                raise ContinuousClientError(unreadable_code, status=status, request_id=metadata.get("request_id"))
            frozen_member = (_is_frozen_member_read(method, path, body, status)
                             and urllib.parse.urlsplit(request.full_url).path == path)
            limit = MAX_FROZEN_MEMBER_RESPONSE_BYTES if frozen_member else MAX_RESPONSE_BYTES
            raw = response.read(limit + 1)
            if type(raw) is not bytes or len(raw) > limit:
                raise ContinuousClientError(unreadable_code, status=status, request_id=metadata.get("request_id"))
            try:
                result = parse_frozen_member_response(raw) if frozen_member else parse_json_object(raw, max_bytes=MAX_RESPONSE_BYTES)
            except ValueError:
                raise ContinuousClientError(unreadable_code, status=status, request_id=metadata.get("request_id")) from None
            if status not in {200, 201}:
                code = "CLIENT_AUTH_REQUIRED" if status in {401, 403} else result.get("code", "CLIENT_RESPONSE")
                raise ContinuousClientError(code if type(code) is str else "CLIENT_RESPONSE", status=status, request_id=metadata.get("request_id"))
            if expected_status is not None and status != expected_status:
                raise ContinuousClientError(unreadable_code, status=status, request_id=metadata.get("request_id"))
            return result
        except ContinuousClientError:
            raise
        except Exception:
            raise ContinuousClientError("CLIENT_UNCONFIRMED" if method == "POST" else "CLIENT_TRANSPORT",
                status=status, request_id=self.last_continuous_response.get("request_id")) from None
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    # Cleanup cannot erase a confirmed acknowledgment or mask the
                    # original failure. Expose only a fixed separate diagnostic.
                    self.last_continuous_response["cleanup_code"] = "CLIENT_TRANSPORT"

    def execution_capabilities(self) -> dict:
        self._continuous_require_attach()
        return self._continuous_request("GET", "/api/executions/capabilities")

    def _prepare_body(self, payload: dict, *, fork: bool = False) -> dict:
        self._continuous_require_attach()
        value = payload_copy(payload, _PREPARE | ({"expected_parent_revision"} if fork else set()))
        for field in ("engine_contract_id", "expected_source_generation", "expected_twin_id"):
            identifier(value[field])
        integer(value["expected_twin_version"])
        if fork:
            integer(value["expected_parent_revision"])
        policy = value["policy"]
        if not isinstance(policy, dict) or set(policy) != {"end_native", "frame_period_s", "time_scale"}:
            raise ContinuousClientError()
        for number in policy.values():
            if type(number) not in {int, float} or not math.isfinite(number) or number <= 0:
                raise ContinuousClientError()
        return value

    def prepare_execution(self, payload: dict, *, idempotency_key: str) -> dict:
        value = self._prepare_body(payload)
        return self._continuous_request("POST", "/api/executions", value, idempotency_key=request_key(idempotency_key))

    def fork_execution_checkpoint(self, execution_id: str, payload: dict, *, idempotency_key: str) -> dict:
        value = self._prepare_body(payload, fork=True)
        return self._continuous_request("POST", f"/api/executions/{identifier(execution_id, opaque=True)}/fork-checkpoint", value,
                                        idempotency_key=request_key(idempotency_key))

    def execution_status(self, execution_id: str) -> dict:
        self._continuous_require_attach()
        return self._continuous_request("GET", f"/api/executions/{identifier(execution_id, opaque=True)}")

    def execution_frames(self, execution_id: str, *, after_frame: int = 0, limit: int = 100) -> dict:
        self._continuous_require_attach()
        query = urllib.parse.urlencode({"after_frame": integer(after_frame, 0, 1_000_000_000), "limit": integer(limit, 1, 500)})
        return self._continuous_request("GET", f"/api/executions/{identifier(execution_id, opaque=True)}/frames?{query}")

    def execution_observations(self, execution_id: str) -> dict:
        self._continuous_require_attach()
        return self._continuous_request("GET", f"/api/executions/{identifier(execution_id, opaque=True)}/observations")

    def _execution_control(self, action: str, execution_id: str, revision: int | None,
                           generation: str, control_revision: int | None = None) -> dict:
        self._continuous_require_attach()
        return self._continuous_request("POST", f"/api/executions/{identifier(execution_id, opaque=True)}/{action}",
            {**control_guard(revision, control_revision), "expected_source_generation": identifier(generation)},
            timeout=60 if action in {"start", "resume"} else 20)

    def start_execution(self, execution_id: str, *, expected_revision: int | None = None,
                        expected_control_revision: int | None = None, expected_source_generation: str) -> dict:
        return self._execution_control("start", execution_id, expected_revision, expected_source_generation, expected_control_revision)

    def pause_execution(self, execution_id: str, *, expected_revision: int | None = None,
                        expected_control_revision: int | None = None, expected_source_generation: str) -> dict:
        return self._execution_control("pause", execution_id, expected_revision, expected_source_generation, expected_control_revision)

    def resume_execution(self, execution_id: str, *, expected_revision: int | None = None,
                         expected_control_revision: int | None = None, expected_source_generation: str) -> dict:
        return self._execution_control("resume", execution_id, expected_revision, expected_source_generation, expected_control_revision)

    def stop_execution(self, execution_id: str, *, expected_revision: int | None = None,
                       expected_control_revision: int | None = None, expected_source_generation: str) -> dict:
        return self._execution_control("stop", execution_id, expected_revision, expected_source_generation, expected_control_revision)

    def virtual_patch_capabilities(self) -> dict:
        self._continuous_require_attach()
        return self._continuous_request("GET", "/api/patch/virtual/sessions/capabilities")

    def register_virtual_probe(self, device_id: str) -> dict:
        self._continuous_require_attach()
        return self._continuous_request("POST", "/api/patch/virtual/probe", {"device_id": identifier(device_id)})

    def start_virtual_session(self, payload: dict) -> dict:
        self._continuous_require_attach()
        value = payload_copy(payload, {"execution_id", "source_snapshot_hash", "device_id", "expected_selection", "idempotency_key"})
        identifier(value["execution_id"], opaque=True)
        identifier(value["device_id"])
        request_key(value["idempotency_key"])
        if type(value["source_snapshot_hash"]) is not str or not re.fullmatch(r"[0-9a-f]{64}", value["source_snapshot_hash"]):
            raise ContinuousClientError()
        from .aegle.execution_contract import validate_selection
        try:
            validate_selection(value["expected_selection"])
        except ValueError:
            raise ContinuousClientError() from None
        return self._continuous_request("POST", "/api/patch/virtual/sessions", value)

    def virtual_session_status(self, session_id: str) -> dict:
        self._continuous_require_attach()
        return self._continuous_request("GET", f"/api/patch/virtual/sessions/{identifier(session_id, opaque=True)}")

    def _virtual_control(self, action: str, session_id: str, revision: int | None,
                         control_revision: int | None = None) -> dict:
        self._continuous_require_attach()
        return self._continuous_request("POST", f"/api/patch/virtual/sessions/{identifier(session_id, opaque=True)}/{action}",
                                        control_guard(revision, control_revision))

    def pause_virtual_session(self, session_id: str, *, expected_revision: int | None = None,
                              expected_control_revision: int | None = None) -> dict:
        return self._virtual_control("pause", session_id, expected_revision, expected_control_revision)

    def resume_virtual_session(self, session_id: str, *, expected_revision: int | None = None,
                               expected_control_revision: int | None = None) -> dict:
        return self._virtual_control("resume", session_id, expected_revision, expected_control_revision)

    def stop_virtual_session(self, session_id: str, *, expected_revision: int | None = None,
                             expected_control_revision: int | None = None) -> dict:
        return self._virtual_control("stop", session_id, expected_revision, expected_control_revision)
