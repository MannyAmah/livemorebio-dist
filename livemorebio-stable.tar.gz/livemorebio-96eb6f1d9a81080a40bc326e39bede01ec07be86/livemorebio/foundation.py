"""Whole-human capability contract for LIFE, Aegle, and Cendos.

The anatomy ontology defines what belongs in a human. This module declares what
Livemore can currently do with each system. Keeping those concerns separate is
intentional: architectural coverage must never be mistaken for model maturity.

Every call returns a fresh JSON-compatible value. A notebook, API caller, or
plugin can annotate its local copy without mutating the platform's claims.
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any

from .anatomy import load_ontology
from .life_patch.sensors import channel_summary


MATURITY_CLAIMS = (
    "registered",
    "reference_backed",
    "modeled",
    "coupled",
    "person_calibrated",
    "context_validated",
    "independently_replicated",
    "device_connected",
)


_EXECUTABLE_SYSTEMS: dict[str, dict[str, Any]] = {
    "cardiovascular": {
        "models": [
            {
                "id": "ohara-rudy-cipa-2017",
                "scope": "ventricular_cell_electrophysiology",
                "endpoints": ["action_potential", "calcium_transient", "apd90_ms"],
                "claim_state": "MODELED_ONLY",
            },
            {
                "id": "livemore-heart-rate",
                "scope": "resting_rate_pacing_and_hrv",
                "endpoints": ["hr_bpm", "hrv_ms", "cycle_length_ms"],
                "claim_state": "MODELED_ONLY",
            },
        ],
        "couplings": [{"id": "metabolic_cardiac_hyperglycemia_to_ikr", "claim_state": "HYPOTHESIS_UNSOURCED",
                       "limitation": "coupling magnitude has no admitted source"}],
    },
    "endocrine": {
        "models": [
            {
                "id": "bergman-glucose-insulin",
                "scope": "glucose_insulin_regulation",
                "endpoints": ["glucose", "insulin", "ogtt", "glycemic_exposure"],
                "claim_state": "MODELED_ONLY",
            }
        ],
        "couplings": [{"id": "metabolic_cardiac_hyperglycemia_to_ikr", "claim_state": "HYPOTHESIS_UNSOURCED",
                       "limitation": "coupling magnitude has no admitted source"}],
    },
}


_PARTIAL_CAPABILITIES: dict[str, list[dict[str, str]]] = {
    "digestive_hepatobiliary": [
        {
            "id": "oral-one-compartment-hepatic-pk",
            "scope": "drug_exposure_component_only",
            "qualification": "does_not_constitute_a_digestive_or_hepatic_system_model",
        }
    ],
    "urinary": [
        {
            "id": "renal-covariate-for-metformin-clearance",
            "scope": "pk_covariate_only",
            "qualification": "does_not_constitute_a_renal_physiology_model",
        }
    ],
}


_PRODUCTS: dict[str, Any] = {
    "LIFE": {
        "role": "measurement_and_device_data_plane",
        "current_release_claim": "software_contract_and_research_hardware_package",
        "sensor_schema_source": "legacy_rev_a_1_research_package",
        "sensor_schema_status": "requires_reconciliation_before_hardware_or_human_use",
        "patches": {
            "physical": {
                "hardware_validated": False,
                "human_use_released": False,
                "local_safety_controller_required": True,
                "cloud_may_bypass_local_safety": False,
                "data_contract": "LifePatchPacket",
            },
            "virtual": {
                "mountable_on_twin": True,
                "uses_same_signal_schema": True,
                "may_claim_physical_measurement": False,
                "purpose": "simulation_debugging_replay_and_device_contract_testing",
            },
        },
        "sensor_channels": channel_summary(),
    },
    "Aegle": {
        "role": "person_state_coupling_and_scenario_plane",
        "scenario_policy": "isolated_from_live_twin",
        "scenario_isolation_status": "required_not_yet_enforced_on_all_routes",
        "predictions_may_self_calibrate": False,
        "current_release_claim": "context_specific_model_only_hypothesis_triage",
    },
    "Cendos": {
        "role": "experiment_assay_evidence_and_verification_plane",
        "claim_policy": "returned_artifacts_required",
        "wet_lab_execution_claimed": False,
        "workbenches": {
            "jupyter": {
                "integration": "local_python_sdk",
                "execution_reported": True,
            },
            "rosalind": {
                "integration": "external_governed_artifact_handoff",
                "adapter_implemented": False,
                "execution_reported": False,
                "required_return_provenance": [
                    "task_identity",
                    "input_artifact_hashes",
                    "tool_and_model_versions",
                    "parameters",
                    "output_artifact_hashes",
                    "execution_timestamp",
                ],
            },
        },
    },
}


_REFERENCE_ADAPTERS = [
    {
        "id": "physiome_model_repository",
        "role": "physiological_model_intake_candidate",
        "access": "supported_export_or_api_required",
        "license": "model_specific_review_required",
        "enabled": False,
    },
    {
        "id": "synthetic_sciences_openscience",
        "role": "optional_local_cendos_workbench",
        "access": "apache_2_0_source",
        "privacy": "research_trajectory_upload_must_be_disabled_for_restricted_data",
        "enabled": False,
    },
    {
        "id": "genecards",
        "role": "gene_disease_reference_candidate",
        "access": "licensed_api_or_data_agreement_required",
        "license": "commercial_terms_required",
        "enabled": False,
    },
    {
        "id": "kegg",
        "role": "pathway_orthology_reaction_disease_drug_reference_candidate",
        "access": "commercial_license_required",
        "license": "non_academic_commercial",
        "enabled": False,
    },
    {
        "id": "human_anatomy_and_physiology_org",
        "role": "educational_coverage_cross_check_only",
        "access": "web_reference",
        "license": "not_approved_for_embedded_scientific_parameters",
        "enabled": False,
    },
    {
        "id": "nar_database_summary_collection",
        "role": "specialist_database_discovery_index",
        "access": "index_only",
        "license": "each_linked_database_requires_separate_review",
        "discovery_review_completed": True,
        "enabled": False,
    },
]


def _system_capability(
    system: dict[str, Any],
    coupling_ids: list[str],
    reference_basis_id: str,
    reference_backed: bool,
) -> dict[str, Any]:
    executable = _EXECUTABLE_SYSTEMS.get(system["id"])
    modeled = executable is not None
    maturity = {
        "registered": True,
        "reference_backed": reference_backed,
        "modeled": modeled,
        "coupled": modeled and bool(executable["couplings"]),
        "person_calibrated": False,
        "context_validated": False,
        "independently_replicated": False,
        "device_connected": False,
    }
    return {
        "id": system["id"],
        "name": system["name"],
        "ontology": {
            "reference_basis_id": reference_basis_id,
            "structures": [structure["id"] for structure in system["structures"]],
            "core_functions": list(system["core_functions"]),
            "processes": list(system["processes"]),
            "state_variables": list(system["state_variables"]),
            "couplings": coupling_ids,
        },
        "maturity": maturity,
        "functional_claim": "MODELED_CONTEXT_ONLY" if modeled else "UNAVAILABLE",
        "models": deepcopy(executable["models"]) if executable else [],
        "implemented_couplings": list(executable["couplings"]) if executable else [],
        "partial_capabilities": deepcopy(_PARTIAL_CAPABILITIES.get(system["id"], [])),
        "refusal_reason": None if modeled else "no_executable_system_model_in_current_release",
    }


def whole_human_manifest() -> dict[str, Any]:
    """Return the current all-system capability and product integration contract."""
    ontology = load_ontology()
    reference_basis_id = (
        f"{ontology.manifest['id']}@{ontology.manifest['version']}"
    )
    authoritative_resources = deepcopy(ontology.raw["authoritative_resources"])
    systems = []
    for system_id, system in ontology.systems.items():
        coupling_ids = [coupling["id"] for coupling in ontology.couplings_for(system_id)]
        systems.append(
            _system_capability(
                dict(system),
                coupling_ids,
                reference_basis_id,
                bool(authoritative_resources),
            )
        )

    maturity_counts = {
        f"{claim}_systems": sum(system["maturity"][claim] for system in systems)
        for claim in MATURITY_CLAIMS
    }
    return {
        "schema": "livemore.whole-human-capability-manifest",
        "schema_version": "1.0.0",
        "product": "Livemore Whole-Human Foundation",
        "north_star": "complete_biological_functional_human_body_replica",
        "current_release_claim": "evidence_governed_context_specific_modeling_infrastructure",
        "maturity_claims": list(MATURITY_CLAIMS),
        "claim_rule": "architectural_inclusion_does_not_imply_functional_or_clinical_maturity",
        "maturity_semantics": {
            "reference_backed": "architecture_registration_has_a_declared_reference_basis",
            "modeled": "at_least_one_bounded_model_context_exists_not_full_system_coverage",
            "coupled": "at_least_one_declared_runtime_coupling_exists_not_all_ontology_couplings",
            "person_calibrated": "model_parameters_calibrated_to_lawful_person_specific_evidence",
            "context_validated": "validated_only_for_the_named_context_of_use",
            "independently_replicated": "replicated_by_an_independent_team_or_environment",
            "device_connected": "verified_physical_device_data_contract_and_transport",
        },
        "reference_basis": {
            "id": reference_basis_id,
            "scope": "ontology_and_architectural_registration_only",
            "authoritative_resources": authoritative_resources,
        },
        "coverage": {
            "ontology_systems": len(ontology.systems),
            **maturity_counts,
        },
        "systems": systems,
        "products": deepcopy(_PRODUCTS),
        "reference_adapters": deepcopy(_REFERENCE_ADAPTERS),
        "interfaces": {
            "terminal": "livemore manifest",
            "python": "livemorebio.whole_human_manifest",
            "sdk": "Platform.manifest",
            "http": "GET /api/system-manifest",
            "jupyter": "from livemorebio import whole_human_manifest",
        },
    }


__all__ = ["MATURITY_CLAIMS", "whole_human_manifest"]
