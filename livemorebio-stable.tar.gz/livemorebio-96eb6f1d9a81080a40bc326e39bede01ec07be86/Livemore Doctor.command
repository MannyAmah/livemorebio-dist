#!/bin/zsh
# Environment + infrastructure readiness for the current LivemoreBio product.
cd "$(dirname "$0")" || exit 1
clear
[ -x ./.venv/bin/livemore ] || { echo "✗ .venv missing — see README.md"; read; exit 1; }
./.venv/bin/livemore doctor --network
echo "Full test suite: use 'Livemore Test.command'. Press Return to close."
read
