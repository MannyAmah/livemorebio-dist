# Beard conversion and technical native-worker verification

2026-09-08. **Maker evidence for independent review, not product activation or
physiological numerical acceptance.** The approved scope is steps 1–3 of the
[unit-preserving plan](solutions/2026-09-08-beard-unit-preserving-execution-followup.md).
The [rejected Myokit import](BEARD_MITOCHONDRIAL_SOURCE_IMPORT.md) is preserved.

## Outcome

The exact Beard CellML source is converted to CellML 2.0, dimensionally analysed
with **zero analyser issues**, and compiled into generated-C **text**, retaining
all declared dimensions, equations, initial values and variable equivalences.
The generated Beard C was **not compiled, loaded or evaluated**. There were
**zero Beard `computeRates` calls and zero physiological advances**.

A separate fixed technical worker compiles and executes only two explicitly
analytic test models. Real CVODE results pass their preregistered mathematical
error checks. This tests the callback/solver/resource machinery, not the human
body, mitochondrial biology, arctigenin potency, individualization or physical
equivalence. R10/R34 and the five full-individual programs remain open.

## Source, conversion and state identity

Original source: [PMR pinned Beard model](https://models.physiomeproject.org/workspace/beard_2005/@@rawfile/8ec69b34c31cd1cbb53580d1853841bb333de78e/beard_2005.cellml).
Original SHA-256:
`4a4f931592df0e77a92c79447bf6d8947c7325f721a74b4d336d370abaaf3981`.
Daniel A. Beard (2005), CellML curation David Nickerson and PMR contributors;
[CC BY 3.0](https://creativecommons.org/licenses/by/3.0/).

The admission check covers 47 components, 339 variable declarations, 28 unit
definitions, 65 equations, 226 mapping edges across 160 connections, 66 literal
initial values and all 19 states. Constants are not inferred or rewritten.
The exact author artifact retains disabled AK and the previously documented
water-fraction/capacitance discrepancies with the paper correction.

Only enumerated format changes are admitted: CellML namespace, cmeta IDs,
public-interface syntax, connection syntax/order, `liter` → `litre`, legacy base
units to empty irreducible units, and formatting whitespace. Original metadata,
RDF and documentation remain in the archive, even though the 2.0 printer omits
their XML elements. Ordered MathML including numeric-exponent tails is checked.
Every analyser issue, including a warning, blocks generation. Negative controls
challenge sums, logarithms, derivatives and mismatched connected dimensions.

`cell`, `cytoplasm` and `mitochondria` remain separate irreducible dimensions,
pairwise incompatible and incompatible with dimensionless. This follows
[CellML 2 §3.3](https://www.cellml.org/cellml/2.0#interpretation-of-units-elements).
The source's `molar_per_cyto` definition uses `mitochondria^-1`; the definition
is retained, not reinterpreted from its suggestive name.

Complete native state mapping below is **static code-generation evidence**.
All time units are seconds; initial-value strings are unchanged source strings.
The analyser reorders the source, so all 339 observer aliases are resolved by
qualified IDs and actual equivalence classes, not source order or bare names.
No hidden unit scale is accepted for an alias.

| Generated index | Source state ID | Native unit | Literal initial value |
| --- | --- | --- | --- |
| 0 | dH_x_dt.H_x | molar | 6.30957344480193e-8 |
| 1 | dPsi_dt.dPsi | millivolt | 160 |
| 2 | dPi_x_dt.Pi_x | molar | 0.001 |
| 3 | dNADH_x_dt.NADH_x | molar | 0.0015 |
| 4 | dQH2_dt.QH2 | molar | 8e-4 |
| 5 | dCred_dt.Cred | molar | 0.001 |
| 6 | dO2_dt.O2 | molar | 2.6e-5 |
| 7 | dATP_mx_dt.ATP_mx | molar | 0 |
| 8 | dADP_mx_dt.ADP_mx | molar | 0 |
| 9 | dATP_x_dt.ATP_x | molar | 0 |
| 10 | dMg_x_dt.Mg_x | molar | 0.005 |
| 11 | dADP_x_dt.ADP_x | molar | 0.01 |
| 12 | dATP_mi_dt.ATP_mi | molar | 0 |
| 13 | dATP_i_dt.ATP_i | molar | 0 |
| 14 | dADP_mi_dt.ADP_mi | molar | 0 |
| 15 | dADP_i_dt.ADP_i | molar | 0 |
| 16 | dAMP_i_dt.AMP_i | molar | 0 |
| 17 | dPi_i_dt.Pi_i | molar | 0.001 |
| 18 | dK_x_dt.K_x | molar | 0.14 |

Converted CellML SHA-256:
`5b2ffa7a1e8bae8be173fc9e8e84cd88bdfc02efcfd00c28cf222b0af633a40c`.
Generated Beard C SHA-256:
`3af10f8a848e6077f6059186fc1b34a9895e89f9f9c47f80669001ccfbc9795a`.

Full source, conversion, unit definitions, 339-slot observer map and generated
code are retained in the private archive:
`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-beard-conversion-830r2ice/`.
`artifact.json` SHA-256:
`86c077d19eea7d8e333c3db035eec5b0e04ffd0a6428fa6fca2a14b9a11a939e`.
The directory is 0700; six files are 0600. It contains attribution and original
source bytes, but **no binary**. Temporary artifacts should be copied into a
reviewed evidence-retention location before relying on long-term availability.

## Actual native technical results

Both models are fixed source fixtures in `tools/beard_conversion.py`, not
biological patient states. The formal custom dimension named `cell` exercises
unit preservation; it does not make these synthetic quantities physical cells.

- `technical_decay_v1`: x′ = −k x; x(0)=2; k=0.5 s⁻¹.
- `technical_pool_v1`: the same x, y′=k x; y(0)=3; observer total=x+y.

No equation is retyped inside the C callback. It calls libCellML's generated
initialization, computed-constant, rate and observer functions. The C harness
rejects more than two states and nontechnical identities. The Python dispatcher
rejects Beard, arctigenin, paths and arbitrary inputs before creating files or
launching a compiler. There is no dose, patient, source-code or model-path input.

CVODE BDF, relative tolerance 1e-9, absolute tolerance 1e-11, native outputs at
0:0.25:10 seconds. Preregistered technical acceptance: each state absolute
error ≤2e-7 against the analytic formula, and pool-total error ≤5e-10. These
limits were written in tests before the first native execution and did not
change after seeing results. They are not biological or clinical tolerances.

| Result | Decay | Two-pool |
| --- | ---: | ---: |
| Maximum absolute x error | 1.2347249667143956e-8 | 1.802718596621844e-8 |
| Maximum absolute y error | Not applicable | 1.802718507804002e-8 |
| Maximum pool-total error | Not applicable | 5.329070518200751e-15 |
| Generated RHS evaluations, including output checks | 253 | 237 |
| Native elapsed seconds | 0.280272 | 0.200615 |
| Compile elapsed seconds | 0.235526 | 0.155192 |
| Native self-reported peak RSS bytes | 7,405,568 | 7,356,416 |
| Supervisor samples | 21 | 15 |
| Maximum observed sample gap seconds | 0.015492 | 0.015290 |

Actual results and native binaries are retained, not reconstructed from graphs:

- Decay: `/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-beard-technical-s61r8c1p/result.json`.
  Result SHA `67d03e301a471a15fef345140938675e1983a03e554706d763238a92036eef50`;
  binary SHA `7ce26d516a5a9832caef60d82671433e5d6c87b90a2ce9371523891090fdd759`.
- Pool: `/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-beard-technical-0np2kaw4/result.json`.
  Result SHA `a1e01d19fd616620c978d8854612f12466d4cd847b4aff1ea63307a4f7b36f85`;
  binary SHA `0075362d147426d938e02cfcc90b00c061a77c4d5e460399d5f8bcc7aa38ad46`.

Wrapper C SHA:
`427139375707d6f4ddf9e94b552957199d0572989d044ded861a77003f122f06`.
No native numerical result is claimed for the Beard archive.

## Runtime and failure evidence

libCellML 0.7.0 official ARM wheel SHA
`c83b6fdc5a5bed192f11c8184903cf5e08aa561ab981f17029911ce48ddb120c`;
the exact aggregate of its 64 package files is checked before/after use.
SUNDIALS 7.8.0 and five directly selected dylib hashes remain pinned to the
reviewed local binaries. All 17 entries in the transitive linked-library
inventory are recorded; OS shared-cache libraries are explicitly identified by
OS build rather than pretending to hash absent filesystem dylibs.

Actual Apple clang 21.0.0 compiler SHA
`7def90dd8829726686213a747fc5bff1583df933dae5edc55d755479e0bfe00a`.
SUNDIALS header inventory SHA
`3fc5ec8fd50843bc6f70bd7d966ae2e8a2c7f125de462e1ee5ef3501e8735f6a`.
The result records compiler flags, explicit SDK path/settings hash, native
Mach-O UUID, linked libraries, wrapper hash and OS build `25E253`. There is no
operational dependency installation or production runtime change.

The first launches exposed real setup errors, all retained:

1. A 128 MiB generic file-check ceiling rejected the installed 141,373,024-byte
   compiler; compiler inspection now uses bounded streaming hashing with its own
   512 MiB file ceiling, not whole-file allocation.
2. Scrubbed environment plus direct compiler invocation did not find SDK
   headers. The command now supplies the official Xcode SDK explicitly.
3. The MPI-enabled SUNDIALS build needed explicit MPI linkage despite using
   serial vectors. The pre-existing MPI dependency is fingerprinted.
4. macOS rejected the proposed 1 GiB `RLIMIT_AS` setter before generated code
   ran. The separately reviewed amendment replaced that unsupported claim with
   sampled resident protection. The failed launch was not relabeled a pass.

Memory enforcement is **sampled soft protection, not hard isolation**:
`proc_pid_rusage`/RUSAGE_INFO_V2, exact reviewed 160-byte Apple ABI, a 1 GiB RSS
termination threshold, 10 ms requested sampling, actual gaps and observed
overshoot recorded. Native PID/start/image identity must remain bound to the
owned child. Sampling failures while alive stop it. No estimated-RSS fallback.
See [Apple's native structure](https://developer.apple.com/documentation/kernel/rusage_info_v2).

Hard core-file prohibition, native CPU 5 s and file-size limit accompany wall
and output supervision. No Python `preexec_fn` runs inside a multithreaded
parent. The native C worker applies its hard limits before callbacks; the
compiler's fixed isolated launcher applies its own core/file limits before
executing the fixed compile command. The worker is **not an untrusted-code
sandbox**. Process-group failure cleanup targets only its own new session and
reaps the leader; cleanup failures remain visible and do not erase the original
error. Repeated interrupts cannot interrupt owned cleanup.

Actual tests cover invalid callback quantities, output overflow, timeout,
cancellation, exceeded RSS, sampler failure, changed process start/image and
normal cleanup. A structural regression injects process-group termination
failure to prove original-deadline preservation and separate cleanup reporting;
it is not presented as an observed OS permission failure. No external service
was stopped. An additional partial-stream-open failure verifies descriptor
closure.

## Reproduce in the reviewed ARM environment

From the feature worktree, using the independently checked Python environment:

```bash
LIVEMORE_TEST_BEARD_NATIVE=1 \
LIVEMORE_TEST_BEARD_SOURCE=/tmp/livemore-arctigenin-source.BCaB9w/beard_2005.cellml \
/Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B \
  tools/run_review_tests.py -q -p no:cacheprovider \
  livemorebio/tests/test_beard_source_contract.py \
  livemorebio/tests/test_beard_conversion.py \
  livemorebio/tests/test_beard_native_worker.py
```

Observed final maker packet: **63 passed in 13.92 s**. Tests were written before
the implementation, with observed missing-module failures, then specific unit,
runtime, compiler, resource and cleanup failures retained during development.
Default tests do not opt into these platform-specific native checks; a skipped
check is not claimed as native validation. Missing or different runtimes fail
closed when the checks are explicitly requested.

Source-only archive command, no compile or solve:

```bash
python -B tools/beard_conversion.py --archive /path/to/the/pinned/beard_2005.cellml
```

Explicit technical fixture commands, never patient/physiological experiments:

```bash
python -B tools/beard_native_worker.py technical_decay_v1
python -B tools/beard_native_worker.py technical_pool_v1
```

## Gates still open

Independent maker-external review of this packet; a separately authorized
Beard numerical manifest; actual native transfer of all 19 initial states;
source physiological domain/conservation checks; source-variant resolution and
quantitative reference reproduction. Static state mapping does not prove native
physiological initialization. Human tissue translation, arctigenin free-exposure
and target-activity mapping, whole-person coupling, wet-lab measurement and
human qualification remain unimplemented/unpassed. No pretty trajectory fills
those evidence gaps.

Compounded lessons: check analyser warnings, not only errors; compare semantic
equivalence edges rather than printer order; explicit SDK/MPI/runtime identities
matter even with installed packages; demonstrate a platform resource limit
before claiming it. Preserve rejected attempts beside the successful technical
test, with their different scientific meanings.

## Independent-review corrections and superseding maker packet

The first 63-test packet was independently reproduced (14.39 s), but **was not
accepted as sufficient**. The reviewer found three P2 defects: descendants could
survive an exited leader; evidence-write errors could mask the original failure;
and binary linkage was recorded without checking inventory membership. The root
approved a narrow red-first correction in the existing plan. All original
artifacts and failed attempts above remain retained.

The six initial new regressions failed before the corrections, including an
actual fixed technical fork whose leader exits with status 7 while its descendant
sleeps in the invocation's private group. The corrected worker now:

1. Observes its own child with Darwin `waitid(P_PID, ..., WEXITED | WNOHANG |
   WNOWAIT)` and holds that unreaped child until group cleanup finishes. This
   reserves the leader PID, preventing an unrelated group from reusing it before
   a signal. A failed ownership check never signals the numeric group. Only the
   invocation's group is enumerated with `proc_listpgrppids`; unrelated process
   data is neither enumerated nor logged. A live leader and surviving descendants
   are terminated before final leader reaping. The result separately records
   active members before cleanup, no live members before reap, signal, reaping
   and cleanup failure. This is for fixed reviewed commands, **not containment
   of arbitrary code that deliberately escapes its process group**.
2. Preserves the original `NativeError` when `failure.json` cannot be written,
   including partial writes. `evidence_persistence=failed_or_partial` is a
   separate bounded field exposed by the controlled CLI failure. No raw storage
   exception is printed; an absent/partial evidence file is not called durable.
3. Resolves each direct Mach-O dependency, requires its resolved path and hash
   to match the captured library inventory, and rejects unresolved loader aliases
   or unknown/changed dependencies **before** native launch. The real binaries
   have seven verified direct entries. A compile-only regression proves a
   rejected linkage does not proceed to a callback.

The actual cleanup investigation found two platform details, tested rather than
guessed: `proc_listpgrppids` returns a **PID count**, unlike the byte count from
`proc_listpids`; and Darwin includes the deliberately held zombie leader in that
group listing even though it can no longer run. The worker excludes only this
proven waitable leader from the live-member check, verifies termination, then
reaps it last. Native declarations match the active Apple SDK's 104-byte
`siginfo_t`. Library/symbol/inspection failures produce bounded failure codes.
[Apple libproc implementation](https://github.com/apple-oss-distributions/xnu/blob/main/libsyscall/wrappers/libproc/libproc.c),
[Apple wait declarations](https://github.com/apple-oss-distributions/xnu/blob/main/bsd/sys/wait.h),
[Apple signal declarations](https://github.com/apple-oss-distributions/xnu/blob/main/bsd/sys/signal.h).

**Superseding maker result: 74 passed in 15.07 s**, with both source and native
technical opt-ins. This includes actual generated analytic solutions, actual
descendant cleanup, injected ownership loss and evidence/linkage failures. It
still requires the independent reviewer to grade the corrections. The Python
worker SHA-256 is
`e0e80716e3bfa4fb6bdf74499036c575501dfb3877c2085cab09842580c4d1c9`.
No C wrapper, model constant, unit, source byte, numerical tolerance or approved
resource limit changed.

Fresh standalone technical evidence (not Beard physiology):

| Quantity | Decay | Two-pool |
| --- | ---: | ---: |
| Maximum absolute x error | 1.2347249667143956e-8 | 1.802718596621844e-8 |
| Maximum absolute y error | Not applicable | 1.802718507804002e-8 |
| Maximum pool-total error | Not applicable | 5.329070518200751e-15 |
| Generated RHS calls | 253 | 237 |
| Supervised elapsed seconds | 0.204969 | 0.207725 |
| Peak sampled resident bytes | 7,454,720 | 7,438,336 |
| Sample count / maximum gap seconds | 16 / 0.015336 | 15 / 0.015386 |
| Observed memory-threshold overshoot bytes | 0 | 0 |

- Decay result: `/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-beard-technical-06akhk2q/result.json`;
  SHA `e5d1dcd73f8aafe6c9c75dd8136c1262caec1dc66e8830bd3c27ffeae561b9e1`.
- Pool result: `/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-beard-technical-ifshotj2/result.json`;
  SHA `a8d6c8a5de108a9059dea0b49194b4652e3d4dcc7a52f1ee960ba06568d90c54`.

Both binaries have exactly the previously recorded binary hashes. Both fresh
results report no live group members before leader reaping, reaping complete,
no cleanup error and seven resolved direct dependencies. **Beard compilation,
Beard RHS evaluations and physiological advances remain zero.**

Compounded lesson: reaping a parent is not descendant cleanup. Keep an ownership
anchor until the group is verified stopped, and distinguish a held zombie from
an executable process. Recording linkage and error artifacts is not enforcement:
validate the former before launch and preserve the primary error if the latter
cannot be persisted.
