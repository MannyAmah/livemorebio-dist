# LIFE Patch — Build Package

> **SUPERSEDED HISTORICAL ARTIFACT · DO NOT BUILD OR USE ON PEOPLE.**
> The original A.1 content below is preserved for traceability, not engineering
> authority. It contains incorrect MAX86141 I²C wiring, DS28E18 authentication
> claims, AD5940 supply guidance and unverified human-wear/test instructions.
> Follow the current [B0 EVT software/engineering boundary](../LIFE_PATCH_CLOSED_LOOP.md)
> and [development/release gates](../MULTISCALE_DEVELOPMENT_ROADMAP.md).
> A reviewed schematic, firmware, electrical/biocompatibility safety evidence and
> applicable human-research approvals are required before any human-use build.
> This warning supersedes every “release,” procurement, wiring, wear or validation
> instruction retained below. No fabrication or human-use release is supplied here.

**Livemore Health & Biosciences**
**Project:** LIFE Patch · P0 Prototype → A.1 Production Target
**Package contents:** BOM · Wiring tables · Build instructions · Test procedures
**Rev:** A.1 · Status: Engineering release, pre-DVT

---

## 0. How to use this package

This document is the **printable companion** to the interactive schematic package (`life_patch_schematics.html`). The HTML file contains the visual schematics, PCB layout, and 3D render. This markdown file contains everything you need to actually build and verify the prototype — suitable for printing, annotating, and pinning above a workbench.

**Use it in this order:**
1. Read §1 to understand what you're building.
2. Procure everything in §2 (BOM) — allow 2–3 weeks for specialty items.
3. Follow §3 (wiring tables) and §4 (build phases) step-by-step.
4. Use §5 (test procedures) to verify each phase before advancing.
5. Log your measurements in §6 (validation record).

---

## 1. What you are building

The **LIFE Patch P0 prototype** is a bench-top validation build of the Livemore Health biosensing platform. It uses off-the-shelf breakout boards wired to an Arduino Nano 33 BLE Rev2 carrier — not a custom PCB. This lets you validate the sensing stack, firmware, and digital-twin data pipeline before committing to PCB fabrication and full NRE.

**What P0 demonstrates:**
- Continuous ECG, PPG, motion, and skin temperature acquisition
- On-demand sweat chemistry via LMP91000 potentiostat
- Bioimpedance (EDA) via AD5940
- Pod interface with cryptographic authentication (DS28E18)
- BLE 5.0 telemetry to the Livemore mobile app
- Battery-powered operation with USB charging

**What P0 does NOT demonstrate:**
- Final form factor (the prototype is a breadboard, not a wearable)
- Long-term wear adhesion
- Regulatory-grade signal quality (lab validation only)
- Production-grade reliability or sealing

Migration to the A.1 production board (covered in §7) happens after P0 validation passes.

---

## 2. Bill of Materials

### 2.1 Integrated Circuits

| Ref Des | Part Number | Description | Package | Qty | Unit $ | Ext $ |
|---|---|---|---|---|---|---|
| U1 | nRF52840-QIAA-R | Bluetooth 5 SoC · Cortex-M4F · 1 MB flash (prototype: use Nano 33 BLE Rev2 module) | aQFN-73 | 1 | 8.25 | 8.25 |
| U2 | MAX30003CTI+T | Single-lead ECG AFE · 18-bit ΔΣ | WLP-30 | 1 | 4.95 | 4.95 |
| U3 | MAX86141ENP+T | Optical PPG/SpO₂ AFE · 4-ch | WLP-20 | 1 | 5.85 | 5.85 |
| U4 | AD5940BCPZ-RL7 | Precision impedance + electrochem AFE | LFCSP-48 | 1 | 9.80 | 9.80 |
| U5 | LMP91000SD/NOPB | Configurable potentiostat AFE | WSON-14 | 1 | 3.20 | 3.20 |
| U6 | (on Nano module) | BMI270 IMU + BMM150 magnetometer | LGA | 1 | 3.90 | 3.90 |
| U7 | MAX30208CLB+T | ±0.1 °C digital temperature sensor | WLP-8 | 1 | 1.35 | 1.35 |
| U8 | BQ25120ARGER | Battery charger + buck + LDO + load switch | WCSP-16 | 1 | 2.80 | 2.80 |
| U9 | DS28E18Q+T | 1-Wire SHA-256 authenticator + I²C bridge | SOT23-6 | 1 | 1.10 | 1.10 |
| U10 | TMUX1208PWR | 8:1 analog mux · low charge injection | TSSOP-16 | 1 | 0.95 | 0.95 |
| U11 | TPS61093DRCR | Synchronous boost · 5V/100mA · low-Iq | SON-10 | 1 | 1.65 | 1.65 |
| U12 | TPS22918DBVR | Load switch · 2A · with QOD | SOT23-6 | 1 | 0.38 | 0.38 |
| | | | **ICs subtotal** | | | **44.18** |

### 2.2 Passives

**Resistors (all 0402 unless noted, 1% tolerance):**
| Ref | Value | Qty | Purpose |
|---|---|---|---|
| R1, R2 | 100 Ω | 2 | ECG ESD current limit |
| R3, R4 | 10 MΩ | 2 | ECG input bias to mid-rail |
| R5 | 10 kΩ | 1 | CS pull-up |
| R30–R31, R60–R61, R90–R92 | 4.7 kΩ | 7 | I²C and 1-Wire pull-ups |
| R80 | 10 kΩ | 1 | Battery NTC divider top |
| RT1 (0603 NTC) | 10 kΩ @ 25 °C | 1 | Battery temperature |
| R81 / R82 | 180 kΩ / 30 kΩ | 2 | Boost feedback divider |
| R60-SIG | 1 kΩ | 2 | EDA electrode current limit |

**Capacitors (all X7R/X5R/C0G, 0402 unless noted):**
| Ref | Value | Qty | Purpose |
|---|---|---|---|
| C1, C2 | 4.7 nF X7R | 2 | ECG antialias |
| C3, C4, C6, C7 | 10–22 pF C0G | 4 | Crystal load + internal filter |
| C8, C11, C20, C23, C40, C42, C45, C46, C60, C62, C90 | 100 nF X7R | 15 | Decoupling |
| C9, C21, C41, C61 | 1 µF X7R | 6 | Bulk decoupling |
| C10, C22, C80, C81 | 10 µF X5R (0603) | 6 | Power rail bulk |
| C82 | 22 µF X5R (0603) | 2 | SYS rail output |
| C83 | 4.7 µF X5R | 1 | LDO output |
| C24 | 22 pF C0G | 1 | PD noise shunt |
| C43, C44 | 18 pF C0G | 2 | 32 MHz crystal load |
| C84, C85 | 10 µF / 22 µF (0603) | 2 | Boost converter |

**Inductors & Ferrites:**
| Ref | Value | Package | Purpose |
|---|---|---|---|
| L1 | 2.2 µH, 1.1 A sat | 0806 | Buck converter |
| L2 | 4.7 µH, 0.7 A sat | 1210 | Boost converter |
| FB1, FB2 | 120 Ω @ 100 MHz | 0402 | EMI on ECG inputs |
| F1 | 0.25 A PTC | 0603 | Battery protection |

**Protection diodes:**
| Ref | Part | Purpose |
|---|---|---|
| D1, D2, D80 | PESD5V0S1UB | TVS on USB and ECG inputs |
| D60 | PESD5V0S1UB | TVS on EDA electrodes |

**Passives subtotal: ≈ $4.60**

### 2.3 Optical

| Ref | Part | Description | Qty |
|---|---|---|---|
| D10 | APG1608CGC-F01 | 525 nm green LED | 1 |
| D11 | APG1608SURC-F01 | 660 nm red LED | 1 |
| D12 | APT3216F3C | 880 nm IR LED | 1 |
| D13 | VEMD8080 | Si photodiode · 540–1100 nm | 1 |

**Optical subtotal: ≈ $1.60**

### 2.4 Frequency References

| Ref | Part | Spec |
|---|---|---|
| Y1 | ABS07-32.768KHZ-T | 32.768 kHz · 12.5 pF · ±20 ppm |
| Y2 | ABM8G-32.000MHZ-18-2-T3 | 32 MHz · 18 pF · ±20 ppm |

### 2.5 Connectors

| Ref | Part | Function |
|---|---|---|
| J1 | USB4085-GF-A | USB Type-C · mid-mount |
| J2 | FH35C-10S-0.3SHW | SWD flex · 0.3 mm pitch |
| J3 | M50-3500545 | ECG electrode header |
| J4 | KP5-M-010-BLK | Cartridge interface · 5-pin gold |
| J5 | 0827-0-15-20-82-14-11-0 | Pogo dock · 5 × 2 mm |
| J6 | M50-3500345 | EDA electrode header |
| SW1 | EVQ-Q2F01W | User tact switch |

**Connectors subtotal: ≈ $7.00**

### 2.6 Mechanical & Patch Build

| Item | Part | Description |
|---|---|---|
| BT1 | LP401230-IS-3 | 120 mAh LiPo with protection IC |
| M1, M2 | N52-5x3 (opposing poles) | Alignment magnets |
| E1, E2 | 3M 2560 | Ag/AgCl electrode snaps |
| HSG-A | Custom TPU 65A | Overmold shell (Protolabs) |
| ADH-A | 3M 1776T | Medical adhesive ring, 7-day wear |
| OPT-W | Silicone 70A | Optical window, 3 mm thick |
| BOARD | 4L flex-rigid PCB | 64 × 36 mm, ENIG finish |

**Mechanical subtotal: ≈ $11.40**

### 2.7 Grand Total

**Core assembly (1 unit, 1k qty prices): ≈ $42.80**

Consumables (cartridges, pods) are priced separately per-use and are not included in the core BOM.

---

## 3. Wiring tables (prototype)

This is the connection reference for the breakout-board prototype. Follow it exactly. Nano 33 BLE Rev2 pin numbers match the Arduino silkscreen.

### 3.1 Power distribution

| From | To | Wire | Notes |
|---|---|---|---|
| BQ25120A `3V3_OUT` | Nano `3V3` | Red 28 AWG | Primary MCU rail |
| BQ25120A `3V3_OUT` | All sensor VDD | Red 28 AWG | Star from PMIC |
| BQ25120A `1V8_OUT` | AD5940 `IOVDD` | Red/white | Critical — do not exceed 2.0 V |
| TPS61093 `VOUT` | MAX86141 `VLED` | Red | 5 V only when BOOST_EN=high |
| All `GND` | Nano `GND` | Black | Single star point |

### 3.2 I²C0 bus

All I²C devices share SDA (Nano A4) and SCL (Nano A5) with one set of 4.7 kΩ pull-ups to 3V3 placed near the Nano.

| Device | Address | Stub length target |
|---|---|---|
| MAX30208 (temp) | 0x50 | < 4 cm |
| MAX86141 (PPG) | 0xC4 | < 4 cm |
| LMP91000 (chem) | 0x48 | < 4 cm |
| BQ25120A (PMIC) | 0x6A | < 4 cm |
| DS28E18 (auth) | via 1-Wire, NOT I²C | — |

### 3.3 SPI0 bus

| Nano pin | Signal | To |
|---|---|---|
| D13 | SCK | MAX30003 SCK + AD5940 SCK |
| D12 | MISO | MAX30003 MISO + AD5940 MISO |
| D11 | MOSI | MAX30003 MOSI + AD5940 MOSI |
| D10 | CS_ECG | MAX30003 CS only |
| D9 | CS_CHEM | AD5940 CS only |

### 3.4 Interrupt lines

| Nano pin | Signal | Source |
|---|---|---|
| D8 | INT_ECG | MAX30003 INT1B |
| D7 | INT_PPG | MAX86141 INT |
| D6 | INT_CHEM | AD5940 INT0 |
| D2 | INT_IMU | BMI270 INT1 (internal to Nano — no external wiring) |

### 3.5 Pod & auxiliary

| Nano pin | Signal | Function |
|---|---|---|
| D5 | OW_POD | 1-Wire authentication |
| D4 | POD_PWR_EN | Load switch control |
| D3 | BOOST_EN | 5V_LED rail enable |
| A0 | BATT_MON | ADC: battery voltage (via /2 divider) |
| A1 | CART_TEMP | ADC: cartridge NTC |
| A2–A3, A6 | MUX_A0–A2 | Chemistry channel select |
| A7 | MUX_EN | Chemistry mux enable |

---

## 4. Build phases

Follow each phase in order. **Do not advance until the phase's verification passes.** The build takes 6–8 hours for an experienced technician and often longer if this is your first time with the AD5940.

### Phase P0 — Power and MCU (≈ 1.5 h)

**Goal:** All three supply rails stable, Nano boots and blinks.

1. **Prepare the PMIC eval board.** Remove the factory `VDD_LDO ↔ 3V3` jumper. Move JP3 to the `1V8` position. Confirm with the BQ25120A datasheet before continuing. *Skipping this step will damage the AD5940 IOVDD pin.*
2. **Seat the Nano 33 BLE Rev2** on the breadboard straddling the center channel. Verify every pin is fully seated — loose pins cause phantom I²C faults.
3. **Solder the 120 mAh LiPo to the PMIC's BAT+ / BAT− terminals.** Check polarity with a multimeter before and after. *Reversed LiPo connections can vent the cell within seconds.*
4. **Route 3V3 from PMIC `3V3_OUT` to the Nano's 3V3 pin** (red 28 AWG). Do NOT connect to VIN or +5V.
5. **Route common ground** from PMIC GND to Nano GND (black 28 AWG). All subsequent GND connections star from the Nano.
6. **Verify 1V8 rail.** With an oscilloscope on the `1V8_OUT` test point, expect 1.80 V ±2 %, < 10 mV p-p ripple at the buck switching frequency.
7. **Verify 5V_LED boost** by temporarily pulling `BOOST_EN` to 3V3. Expect 4.95–5.05 V DC, < 40 mV ripple. Return `BOOST_EN` to ground.
8. **Flash the stock Arduino Blink sketch.** The orange LED should blink at 1 Hz.

> **PHASE P0 COMPLETE** when all rails are within spec and the Nano blinks.

### Phase P1 — Digital sensors (≈ 1.5 h)

**Goal:** All I²C devices acknowledge, temperature and PPG produce plausible data.

1. **Install I²C pull-ups.** 4.7 kΩ from SDA to 3V3, 4.7 kΩ from SCL to 3V3, placed within 2 cm of the Nano. One pair is enough regardless of device count.
2. **Wire the MAX30208 breakout:** SDA→A4, SCL→A5, VDD→3V3, GND→GND. Leave A0/A1 floating (default address 0x50).
3. **Wire the MAX86141 breakout:** same I²C pair, plus `VLED`→5V_LED rail, `INT`→D7.
4. **Wire the BQ25120A I²C lines** (SDA/SCL) to the shared bus.
5. **Upload the I²C scanner sketch.** Open Serial Monitor at 115200 baud. Expect 0x50, 0xC4, 0x6A. Any missing address means that device's VDD, pull-ups, or stub length is wrong.
6. **Read temperature.** Use MAX30208 library; verify room-temp reading and rise on finger contact.
7. **Read PMIC status.** Read register 0x09. `CHRG_STAT` should reflect actual charger state.
8. **Configure and read PPG.** MAX86141 library, green-only at 25 Hz, 50 µA LED. Place finger over optical window; verify heart-rate-scale periodicity (40–100 BPM) in Serial Plotter.

> **PHASE P1 COMPLETE** when all three I²C devices report plausible data.

### Phase P2 — Analog front-ends (≈ 2.5 h)

**Goal:** Clean ECG waveform from body, AD5940 chip ID reads correctly, LMP91000 dummy cell works.

1. **Wire SPI0 bus.** SCK→D13, MISO→D12, MOSI→D11. Keep wires under 5 cm — SPI ringing is severe otherwise. Route SPI bundle AWAY from ECG inputs.
2. **Connect MAX30003:** CS→D10, INT→D8, 3V3, GND. Leave ECG+/ECG− open for now.
3. **Verify ECG SPI.** Read register 0x0F (INFO). Expect `0x5x` where x is the silicon revision.
4. **Connect ECG electrodes.** Use 3M 2560 snaps. One below left clavicle, one on right lower rib. Shielded twisted pair, < 1 m. *Wash your hands first — skin oils ruin contact quality.*
5. **Capture ECG waveform.** Stream FIFO to Serial Plotter at 500 Hz. Sit still, breathe slowly. Expect clean Lead-I-ish trace with P, QRS, T complexes. QRS amplitude > 200 LSB, noise floor < 30 LSB.
6. **Wire AD5940 SPI:** CS→D9, INT→D6. Also wire the 1V8 rail to IOVDD. *Double-check IOVDD before powering — 3V3 on IOVDD causes latch-up.*
7. **Read AD5940 chip ID.** Register 0x400 (ADIID) must return `0x4144`.
8. **Run AD5940 ECG self-test example** (from Analog Devices ad5940lib). Verify PASS in serial output.
9. **Wire LMP91000.** SDA/SCL shared with main I²C (check 0x48 free). `MENB`→A7. Expose WE/RE/CE on screw terminals.
10. **Test LMP91000 with dummy cell.** Build a 1 MΩ + 0.1 µF dummy RC+CE. Apply a bias via LMP91000; verify current matches `I = V_bias / 1 MΩ` within 5 %.

> **PHASE P2 COMPLETE** when ECG shows a clean cardiac waveform and both AD5940 and LMP91000 respond correctly.

### Phase P3 — Integration and soak (≈ 48 h, mostly unattended)

**Goal:** All sensors run together without interfering. 48-hour soak passes without crashes or electrode dropouts.

1. **Add pogo breakout and DS28E18.** POD_PWR → load switch output, OW→D5, POD_SDA/SCL via shared I²C.
2. **Implement authentication.** Firmware asserts POD_PWR_EN, waits 50 ms, challenges DS28E18, verifies HMAC, and either holds or drops POD_PWR_EN.
3. **Enable all sensors simultaneously.** ECG 500 Hz, PPG every 100 ms, temp 1 Hz, IMU 50 Hz, chemistry session every 5 min. Compare each channel's noise to its solo-tested baseline — new noise means a coupling problem. *If PPG enable introduces ECG noise, the 5V_LED rail is coupling into ECG analog. Add bulk caps and re-route the LED return.*
4. **Enable BLE advertisement.** Use ArduinoBLE library. Advertise a service exposing HR, temp, battery voltage. Connect with phone scanner; verify ≥ 1 Hz updates.
5. **Measure total current.** Insert precision ammeter in series with battery. Expect < 1 mA average over 60 s with all sensors at nominal duty cycle.
6. **Log to flash/SD for 48 hours.** Instrument firmware to log every reading. Wear the patch. Use a separate SPI bus for SD if using one.
7. **Post-soak analysis.** Pull log, plot every channel, look for: electrode dropouts, BLE disconnects, watchdog resets, anomalous temp trends. Log in §6.

> **PHASE P3 COMPLETE** when a 48-hour soak passes with no crashes and < 2 electrode dropouts per 24 h.

---

## 5. Test procedures

### 5.1 ECG signal quality

**Setup:** subject supine, electrodes applied for > 2 min, breathing normally.

**Acceptance criteria:**
- QRS amplitude ≥ 500 LSB peak-to-peak
- Baseline wander < 100 LSB over 10 s
- 60 Hz interference < 40 LSB after notch filter
- R-R interval stability: CV < 0.12 in normal sinus rhythm

**Measurement:** record 60 s, compute above metrics in Python. Compare R-R to a reference 12-lead ECG (if available) or a clinical-grade Polar H10.

### 5.2 PPG signal quality

**Setup:** finger over optical window, steady pressure, room at 20–25 °C.

**Acceptance criteria:**
- DC level: 10 k–50 k LSB (green channel)
- AC amplitude: ≥ 200 LSB
- AC/DC ratio (perfusion index): 1–5 %
- Motion artifact: visible but within < 20 % baseline excursion

**Measurement:** streaming plotter, then cross-correlation of PPG peaks with ECG QRS — correlation ≥ 0.95 indicates a valid pulse train.

### 5.3 Chemistry dummy-cell test

**Setup:** 1 MΩ resistor as dummy cell between WE and CE, 0.1 µF between WE and GND, RE jumpered to CE.

**Procedure:**
1. Configure LMP91000 for 3-lead amperometric mode, gain 35 kΩ, bias 100 mV.
2. Read `I = V_WE / 1 MΩ` = 100 nA expected.
3. Vary bias from 50 mV to 400 mV; verify linearity (R² > 0.99).

### 5.4 Power budget verification

**Setup:** precision ammeter (Joulescope or equivalent) in series with battery.

**Modes to measure:**
| Mode | Target | Duration |
|---|---|---|
| Deep sleep (ECG off) | < 50 µA | 60 s |
| Idle with BLE adv 1 Hz | < 300 µA | 120 s |
| ECG continuous 500 Hz | < 800 µA | 120 s |
| Full active (all sensors) | < 1.5 mA | 120 s |
| PPG burst (100 ms) | peak < 80 mA | 100 ms |

If any mode exceeds 1.5× the target, stop and investigate before proceeding.

---

## 6. Validation record (template)

Print and fill in during build:

```
Build date: _____________  Operator: _____________  Serial: P0-___

Phase P0 — Power & MCU
[ ] Jumpers set correctly           [ ] 3V3 rail = _____ V (target 3.30 ± 0.05)
[ ] 1V8 rail = _____ V              [ ] 1V8 ripple = _____ mV p-p
[ ] 5V_LED = _____ V                [ ] Nano blinks

Phase P1 — Digital sensors
[ ] I²C scan: 0x50 [ ]  0xC4 [ ]  0x6A [ ]
[ ] Temp reading = _____ °C         [ ] PPG HR = _____ BPM

Phase P2 — Analog AFE
[ ] MAX30003 INFO = 0x____          [ ] AD5940 ADIID = 0x____
[ ] ECG QRS amplitude = _____ LSB   [ ] ECG noise floor = _____ LSB
[ ] LMP91000 dummy cell = _____ nA (target 100 nA @ 100 mV)

Phase P3 — Integration
[ ] All sensors simultaneous: no new noise
[ ] BLE advertisement visible within _____ s
[ ] Avg current = _____ mA over 60 s
[ ] 48-h soak: crashes = _____, dropouts = _____

Sign-off: _____________________  Date: _________
```

---

## 7. Migration to A.1 production board

Once P0 is validated, the same firmware should port to the A.1 production PCB with minimal changes:

1. **Pin mapping** is 1:1 — the production schematic uses the same signal names. The Nano module is simply replaced by a bare nRF52840 (or EFR32BG24) with identical SPI0/I²C0 assignments.
2. **Firmware porting** requires only changing the HAL initialization from Arduino/mbed to Zephyr or the Nordic SDK. All sensor drivers are portable.
3. **PCB-level differences from the prototype:**
   - All breakout boards consolidated into a 64 × 36 mm flex-rigid board (see Sheet 10)
   - BQ25120A replaces the eval board
   - Direct footprints for all sensors in their proper patch positions
   - Electrodes integrated into the bottom layer copper (Ag/AgCl finish)
   - Optical window in the TPU overmold over the PPG area
   - Pogo connector on the edge for pod docking
4. **DVT validation** repeats Phase 5 test procedures on the production board, plus adds:
   - Drop test (1.2 m onto hardwood, 6 drops)
   - Sweat ingress test (IPX4)
   - 7-day wear test on 5 subjects
   - Thermal cycling (0 °C to 45 °C, 50 cycles)

---

## 8. Appendix — Common build failures and fixes

| Symptom | Likely cause | Fix |
|---|---|---|
| I²C scanner finds nothing | Pull-ups missing or SDA/SCL swapped | Install 4.7 kΩ to 3V3; check wiring |
| ECG is clean but upside-down | ECG+ and ECG− swapped | Invert in firmware or swap electrodes |
| ECG has 60 Hz interference | Ground loop or unshielded cable | Single-point ground at Nano; shielded twisted pair |
| PPG saturates immediately | Ambient light leak | Cover optical window; improve overmold wall |
| PPG shows nothing with finger | LED current too low or wrong wavelength | Increase to 50 µA green, verify VLED = 5 V |
| AD5940 reads all 0xFFFF | SPI mode or speed wrong | Use SPI mode 0, max 8 MHz during bring-up |
| AD5940 locks up after ~30 s | IOVDD > 2.0 V | Verify 1V8 rail; check BQ25120A jumper |
| BLE advertisement not visible | Arduino core version or antenna keepout | Update ArduinoBLE ≥ 1.3.0; check for metal near antenna |
| Battery drains in minutes | Boost rail stuck on, or sensor stuck in active | Check BOOST_EN state; implement proper sleep modes |
| Chemistry reads drift fast | Electrode not pre-conditioned | Run 5-min burn-in with reference solution before session |

---

*End of LIFE Patch Build Package · Rev A.1 · Livemore Health & Biosciences*
