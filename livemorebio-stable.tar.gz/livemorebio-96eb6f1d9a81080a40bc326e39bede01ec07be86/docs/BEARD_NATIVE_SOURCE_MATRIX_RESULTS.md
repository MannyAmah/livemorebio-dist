# Beard pinned-source native matrix: numerical acceptance FAILED

2026-09-08. This is the retained outcome of the **single authorized attempt**,
not a passed scientific release. All six native branches completed and passed
their local source-expression/domain/conservation checks, but the preregistered
B0↔B1 convergence comparison failed. No retry, parameter change, alternate solver,
post-hoc tolerance relaxation, participant binding or product activation occurred.

## Exact scope and authority

Root read and approved the complete private driver before invocation. The
[implementation review record](BEARD_NATIVE_SOURCE_IMPLEMENTATION_REVIEW.md)
contains the original and corrected candidate hashes, independent review and
one-off authorization method. The immutable
[numerical preregistration](solutions/2026-09-08-beard-native-source-preregistration.md)
remains SHA-256 `95351a1e380178725ab38731d8e9dc63b57ebd4a1ae507dad17d3884e28167e7`.

The driver ran from a fresh `-I -B` CPython 3.11.15 process with sanitized
environment. It verified source/code/loaded-module paths, the libCellML 0.7.0
package and native SUNDIALS 7.8.0/compiler/library/SDK identity before enabling
the two gates **only in that process**. The once-only driver exited with code 1
after **61.9873 s**, reporting the full matrix as `FAILED`. Its gates were reset
in `finally`; the reviewed on-disk defaults remain false and their hashes are
unchanged. Execution began at approximately 13:20:55 UTC.

This is the exact [PMR Beard source](https://models.physiomeproject.org/workspace/beard_2005/@@rawfile/8ec69b34c31cd1cbb53580d1853841bb333de78e/beard_2005.cellml),
commit `8ec69b34c31cd1cbb53580d1853841bb333de78e`, SHA-256
`4a4f931592df0e77a92c79447bf6d8947c7325f721a74b4d336d370abaaf3981`.
It is an isolated mitochondrial reference model, not a whole human or an
arctigenin model. PMR defaults, including their differences from the paper's
correction, were preserved. See the [original paper](https://doi.org/10.1371/journal.pcbi.0010036)
and [published correction](https://doi.org/10.1371/journal.pcbi.0020008).
Original source, license attribution, unit definitions, complete variable mapping,
generated source and runtime metadata are retained with each native artifact.

## Native execution and local checks

| Branch | Recorded samples | Recorded output interval | Local checks | Generated RHS calls | CVODE steps |
| --- | ---: | --- | --- | ---: | ---: |
| I0a | Initialization only | t=0; no RHS | Passed | 0 | 0 |
| I0b | 1 | t=0 RHS/observations | Passed | 1 | 0 |
| B0 | 3,001 | 0–300 s | Passed | 4,093 | 633 |
| B1 | 3,001 | 0–300 s | Passed | 4,876 | 1,149 |
| R1 | 3,001 | 0–300 s | Passed | 4,876 | 1,149 |
| K1 | 1,501 | 150–300 s | Passed | 1,529 | 6 |

The checks retained all 19 states, 19 rates and 34 algebraic quantities on the
complete prescribed grids, literal/computed initialization, exact state/constant
restart and per-row independent original-MathML comparison. All branches reported
zero source/domain/conservation failures and zero retained-output uncertainty.
This is local numerical consistency—not full matrix acceptance or experimental
validation.

The five intermembrane nucleotide states and their rates remain the exact
default zero subspace. This execution therefore does **not** demonstrate an ATP
export experiment, arctigenin potency, exposure-response or human biology.

## Cross-run acceptance

| Comparison | Values compared | Failing identity/time pairs | Largest normalized discrepancy | Result |
| --- | ---: | ---: | ---: | --- |
| B0↔B1 | 159,053 | 552 | 724.5410 | **FAILED** |
| R1↔B1 | 159,053 | 0 | 0 | Passed; retained trajectories identical |
| K1↔B1 | 79,553 | 0 | 0.000478175 | Passed |

Normalization is exactly the preregistered per-unit floor plus
`1e-6 * max(abs(a), abs(b))`; a value above 1 fails. The worst failure was
`ATP_synthesis_flux.J_F1` at **4.3 s**: absolute difference
**7.670583092450408e-7 mol/(s·L mitochondrial volume)** against an allowed
**1.0586816735397868e-9** in the same units. No threshold was changed afterward.

All 19 states passed B0↔B1's state thresholds; the maximum normalized state
discrepancy was 0.893812813. The 552 failures were among ten derived algebraic
quantities. Thus checking only state trajectories would have missed this failure.
The retained output-expression agreement at each state does not establish that
the two numerical trajectories agree to the required output accuracy.

| B0↔B1 failing quantity | Count | First–last failing time (s) | Maximum normalized discrepancy |
| --- | ---: | --- | ---: |
| ATP synthesis flux `J_F1` | 227 | 0.1–46.1 | 724.5410 |
| Potassium/hydrogen flux `J_KH` | 41 | 0.1–6.5 | 13.8861 |
| Mg–ATP matrix binding flux `J_MgATPx` | 122 | 0.3–35.4 | 7.0450 |
| Mg–ADP matrix binding flux `J_MgADPx` | 141 | 0.3–35.4 | 8.8991 |
| Oxidized ubiquinone `Q` | 2 | 0.5–0.6 | 1.1228 |
| Complex-I electron flux `J_C1` | 7 | 0.5–4.3 | 1.7161 |
| Phosphate substrate flux `J_Pi2` | 3 | 2.3–4.9 | 1.8543 |
| Phosphate/hydrogen cotransporter flux `J_Pi1` | 3 | 2.3–4.9 | 1.8503 |
| Oxidized NAD `NAD_x` | 3 | 3.1–3.3 | 1.1763 |
| Free matrix ATP `ATP_fx` | 3 | 10.4–10.6 | 1.0338 |

The matrix JSON caps individual failure details at 100 but retains full counts
and per-identity maxima. The complete distribution above was recalculated from
the retained native arrays using plain arithmetic, without evaluating source
expressions or rerunning a model. Independent recomputation subsequently confirmed
these counts and maxima; see the review record below.

## Resources and cleanup

| Branch | Native CPU (s) | Supervised elapsed (s) | Sampled peak RSS (bytes) | Valid RSS samples | Maximum sample gap (ms) |
| --- | ---: | ---: | ---: | ---: | ---: |
| I0a | 0.100360 | 0.699654 | 7,340,032 | 50 | 16.082 |
| I0b | 0.111430 | 0.451695 | 7,438,336 | 32 | 16.799 |
| B0 | 0.232826 | 0.615205 | 7,536,640 | 43 | 16.753 |
| B1 | 0.199099 | 0.563201 | 7,569,408 | 41 | 16.434 |
| R1 | 0.236351 | 0.602915 | 7,553,024 | 44 | 16.138 |
| K1 | 0.148585 | 0.517176 | 7,520,256 | 35 | 21.337 |

The 1 GiB threshold is **sampled soft RSS protection**, not hard memory isolation.
Requested sampling was 10 ms; actual gaps are reported above. All observed RSS
overshoots were zero. Native self-reported peak RSS is separately retained and
does not replace the sampled measurements. All native and compiler children were
reaped; every native owned process group was confirmed without live members before
reaping; all cleanup codes were null. A subsequent read-only process check found
none of the recorded driver/native PIDs still present. No cleanup signal was sent
to another process.

B0/B1/R1 recorded 27/61/61 CVODE error-test failures respectively, with zero
nonlinear failures. These internal rejected steps are preserved, not hidden.
Trial negative counts were 25/43/43/2 for B0/B1/R1/K1; all retained-output negative
counts were zero. These are solver-trial diagnostics, not physical negative
concentrations or measurements.

Recorded output endpoints are not the solver's internal terminal time. The
retained CVODE internal times were B0 **326.8695761038659 s**, B1/R1
**304.4972327375455 s**, and K1 **581.3497381826858 s**. These internal overshoots
are permitted by the preregistered normal-mode interpolation contract; the
requested output grids still end at 300 s. They are explicitly retained and are
not treated as a new failure or silently relabeled as 300 s. Compiler receipts
contain **zero RSS samples**. Compiler child cleanup was verified, but the native
RSS table does not imply measured compiler RSS protection.

## Retained evidence

Private root: `/private/tmp/livemore-beard-once.bi8ASk/`.
Total retained size at report time: **30,373,320 bytes**. Nothing was deleted.

| Artifact | SHA-256 |
| --- | --- |
| Driver | `b285989aa6a9ec1f981786493a0e3a0bf6095d8d82e67078ad2ec8c1bcf84e64` |
| Authorization receipt | `64a88dac59779c04d3becb0a0666006c6625a6b0846d765a88b00f25c725018f` |
| Admission | `a34527d1f0f7549653e8a6c6cf40c6ef51fbf407d6db30e4eeacf2c103c918a8` |
| One-shot execution marker | `1272d0b3711fc4a8b26aca312481f8c2b5e82ffa91ffcea4dad3f4452cea91b6` |
| Driver result | `caf0c6eaa118bcbbd622917cbdd9130c274011081e8545fd1a8771e47f07b9cc` |
| `livemore-beard-matrix-o81womfv/matrix.json` | `c05c31168f01a9a51eaedb8a69053c2846c11891120a2e52ecb53aaf5b4ed6c9` |

| Branch artifact directory | Native output SHA-256 |
| --- | --- |
| I0a: `livemore-beard-source-11r_zyjj` | `8b33ea2f7ef7307e5e760760bc106326c004530393da23938478cc38821b66b7` |
| I0b: `livemore-beard-source-44b_3fjz` | `0c4c362527148ee033f7c772df239476203c2577a920ad4306adf5a2d0a534d4` |
| B0: `livemore-beard-source-qwmhonfa` | `a3b3b4b285eb9917212430cb7c0f6ce292dc3104ab93eb7a26c762c1be3c4c83` |
| B1: `livemore-beard-source-i8txi_56` | `7ab07ea42259b00d8c455c85785ac4876f2e20f1c649a582243a9b6b311ce997` |
| R1: `livemore-beard-source-1euwkpm5` | `b7734ec0983cbba4bc0d5d204f860dac468e5b09766e7177814be3fa25d045b7` |
| K1: `livemore-beard-source-srftvtqt` | `4720e9803942f9a4bdb22110e4404e4cbabb7a719321551e26be140ed15eb8b6` |

Compiled baseline/I0/R1 binary SHA:
`d964c514a0c7fe8bea2b1ba5de66812f1bebc1ef6d236cc496c57c21e35b3524`.
K1's separately compiled checkpoint-bound binary SHA:
`0948aab9643ad3daa57f33b6d0854d8a6fbc9ee25e743af9bc16bc2a6e28dabd`.
Each directory retains the source/header/checkpoint, original/converted CellML,
attribution, binary/linkage, raw stdout/stderr, preparation, native result,
analysis and process supervision records. These are local source-model artifacts,
not clinical data or consented human measurements.

## Decision and next permitted work

The approved numerical matrix **failed**. Product activation and compound/person
mapping remain closed. Preserve this attempt as failed evidence. An independent
reviewer has recomputed the complete comparisons and inspected the source
identities, resource receipts and zero-subspace result from retained files.
Any later numerical investigation needs a new explicit preregistration and
approval; this report does not authorize a tighter solve or redefine acceptance.

This advances the required mitochondrial mechanism's execution evidence while
leaving its numerical release gate open. It does not complete the arctigenin/Burdock
program, whole-individual model, external exposure mapping, wet-lab comparison or
human qualification. Those dependencies remain required.

The subsequent [read-only output-convergence diagnosis](solutions/2026-09-08-beard-output-convergence-diagnosis.md)
accounts for the failed outputs using retained state differences and proposes a
separately reviewed numerical experiment. It does not change this failed verdict
or authorize another execution.

## Independent retained-evidence review

The independent reviewer recomputed every comparison count and per-identity
maximum from the retained arrays and confirmed the same overall failed verdict.
They also checked raw/source/artifact/runtime/protocol/binary hashes, all 10,505
finite recorded rows, literal initialization, the exact checkpoint state/constants,
pool/domain and zero-subspace checks. They performed no source-expression
evaluation or solve. Their wording correction distinguishing recorded output
intervals from internal CVODE times, and compiler versus native RSS sampling, is
incorporated above. This review confirms the recorded failure, not a release pass.
