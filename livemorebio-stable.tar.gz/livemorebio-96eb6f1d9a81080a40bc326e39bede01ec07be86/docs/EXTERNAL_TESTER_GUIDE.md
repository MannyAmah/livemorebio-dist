# LivemoreBio external tester guide

For the September 8 additive, still-in-review branch, use the
[measurement integrity review guide](MEASUREMENT_INTEGRITY_REVIEW_GUIDE.md).
It contains separate local launch steps and the new sampling/assay boundaries.
The installer and verification results below select the preserved September 5
candidate, not uncommitted September 8 work.

September 5, 2026 · `codex/genome-models-clean-workflows` research candidate.

This guide is for an authorized tester using **non-person research data** on a
local Mac or Linux computer. It is not a clinical deployment guide. Livemore is
being developed toward functionally equivalent multiscale human biology; this
candidate does not reproduce an entire person or establish clinical validity.

The three connected products are Aegle (twin state and visualization), LIFE
(reference and device-data contracts), and Cendos (experiments and evidence).
Installing reference models does not install physical hardware, wet-lab instruments,
production graph services, licensed databases, or a source of real patient records.

## 1. Install the right candidate with one command

Prerequisites: Python **3.11**, Bash, `tar`, and [GitHub CLI](https://cli.github.com/).
The repository is private: the owner must grant your GitHub account access to
`MannyAmah/livemorebio`, then you run `gh auth login` once. An invitation is required;
there is no public npm/PyPI package or token-bearing public download URL.
The preserved Myokit cardiac engine requires a C compiler and SUNDIALS development
libraries. On macOS, install Apple's Command Line Tools (`xcode-select --install`)
and `brew install sundials`; on Ubuntu, install `build-essential` and
`libsundials-dev` using the system package manager. These are host prerequisites,
not Python packages, and the product installer does not silently run privileged
system changes. Node.js is needed for the JavaScript-controller regression checks;
Playwright/Chrome/FFmpeg are needed only to reproduce browser QA or recordings.
Allow several GB
of disk space and memory for dependencies and the isolated model worker; initial
Human-GEM parsing used about 1.3 GB peak process memory on the development Mac.

Copy this entire line into Terminal. It resolves this candidate branch once and
uses that exact commit for both installer and product source:

```bash
bash -c 'set -euo pipefail; command -v gh >/dev/null || { echo "Install GitHub CLI first: https://cli.github.com" >&2; exit 1; }; gh auth status >/dev/null || { echo "Run: gh auth login" >&2; exit 1; }; c=$(gh api repos/MannyAmah/livemorebio/commits/codex/genome-models-clean-workflows --jq .sha); f=$(mktemp); trap '\''rm -f "$f"'\'' EXIT; gh api "repos/MannyAmah/livemorebio/contents/install.sh?ref=$c" -H "Accept: application/vnd.github.raw+json" >"$f"; test -s "$f"; LIVEMORE_REF="$c" bash "$f"'
```

The older main-branch command in the general launch guide deliberately stays a
main release command. It does **not** select this unmerged candidate. Record the
commit printed by the candidate installer when reporting a problem.

The full installer installs hash-locked dependencies, downloads eight pinned
Human-GEM v2.0.0 files, verifies their size and SHA256, runs tests including actual
model execution, compiles Python, and only then activates the verified release.
It also verifies model execution when upgrading a previously installed base-only
copy of the same commit. A failed download or test does not replace the current
release. Model-source failures are not treated as successful full installations.
Tests run in a separate private verification directory, printed by the installer
and retained for diagnosis. They do not seed your operational audit history,
subjects, cohorts or experiments. The verified reference-model cache is shared;
verification credentials and mutable records are not.

Open a new terminal after success, then run:

```bash
livemore --help
livemore models check human-gem
livemore start all
livemore status
livemore open
```

Expected: Aegle at `http://127.0.0.1:8850`, LIFE at `:8851`, Cendos at `:8852`.
The browser authorizes its loopback session automatically. **You do not need to
generate or paste an API token.** The launcher privately creates the token used by
the attached terminal and SDK. Do not show tokens in recordings or issue reports.

`livemore models status human-gem` reports readiness as JSON; `check` additionally
exits nonzero if the verified model is missing or corrupt. `livemore models catalog`
shows the exact source, version, hashes and restrictions. Nothing downloads during
ordinary status checks or scientific runs.

### Existing installation or separate evaluation

An update preserves saved subjects, experiments and keys. A new installation on a
computer with an existing `~/.livemore` directory is **not** an empty workspace.
Do not delete that directory to get an empty screen.

For a separate installed evaluation, prepare distinct private locations before
running the same installer line, and keep these exports in every evaluation shell:

```bash
export LIVEMORE_EVALUATION_ROOT="$(mktemp -d /tmp/livemore-evaluation.XXXXXX)"
export LIVEMORE_INSTALL_DIR="$LIVEMORE_EVALUATION_ROOT/product"
export LIVEMORE_BIN_DIR="$LIVEMORE_EVALUATION_ROOT/bin"
export LIVEMORE_DATA_DIR="$LIVEMORE_EVALUATION_ROOT/data"
export LIVEMORE_MODEL_DIR="$LIVEMORE_DATA_DIR/models"
export PATH="$LIVEMORE_BIN_DIR:$PATH"
printf 'Evaluation root: %s\n' "$LIVEMORE_EVALUATION_ROOT"
```

Save the printed directory privately if you want to reuse it; `/tmp` is temporary,
not a backup location. Run the candidate installer line above with these exports.
For this **separate evaluation**, do not use the normal `livemore start all` block:
it uses fixed 8850–8852 ports, and older store-specific environment settings can
override the general data root. Instead launch the installed review runner, which
replaces all mutable store paths and local credentials, on three unused ports:

```bash
PYTHONDONTWRITEBYTECODE=1 "$LIVEMORE_INSTALL_DIR/current/source/.venv/bin/python" -B "$LIVEMORE_INSTALL_DIR/current/source/tools/run_review_stack.py" --data-dir "$LIVEMORE_DATA_DIR" --base-port 8880
```

Keep that terminal running. Open `http://127.0.0.1:8880` for Aegle; LIFE and Cendos
use 8881 and 8882. In a second evaluation shell, retain the same installation/data
exports and use the saved root path, **not another `mktemp`**, then:

```bash
unset LIVEMORE_API_TOKEN
export LIVEMORE_MODEL_DIR="$LIVEMORE_DATA_DIR/models"
export LIVEMORE_AEGLE_URL=http://127.0.0.1:8880
export LIVEMORE_LIFE_URL=http://127.0.0.1:8881
export LIVEMORE_CENDOS_URL=http://127.0.0.1:8882
livemore attach
```

The attached client reads the private token from that data root; do not reuse or
print another deployment's token. Stop only the foreground evaluation runner with
Ctrl+C. The installed user deployment and its existing records remain untouched.

For a deliberately **base-only** installation, export
`LIVEMORE_INSTALL_MODELS=none` before installation. It still installs the locked
dependency set but skips the Human-GEM download/execution gate. Cendos reports the
metabolic model unavailable. This is not a full offline installation: package and
private repository downloads still require access. To add the model later:

```bash
livemore models install human-gem
livemore models check human-gem
```

## 2. Understand the blank first-run state

A fresh data directory has **zero stored twins, zero cohorts, and zero Cendos
protocol runs**. The Atlas displays a **Healthy reference preview** so the user
can inspect available functions. This preview is not an admitted person, not a
saved twin, and not a hidden demonstration experiment.

- **Twins:** an empty saved-record list and explicit creation/onboarding form.
- **Cohorts:** an empty list and an explicit cohort-definition form.
- **Cendos:** blank **Preparation**, with no previously executed result selected.
- **History:** empty until you execute a protocol.
- **Biology:** the current preview/active-twin context unless a specific run link
  is opened. Data cards remain available if graphics cannot load.

Existing installs restore the previously active saved subject. Healthy-first
startup never overwrites an admitted person's profile or an older experiment.
Built-in reference assets and historical example recordings in the source tree
are not imported into your runtime History.

## 3. Which twins and cohorts can be created?

| Choice | What it actually means | Current use |
|---|---|---|
| Healthy reference preview | Literature-typical reduced-model initialization; no subject identity | Explore Atlas/Biology and supported reduced metabolic/cardiac calculations |
| `dpp-high-risk-metabolic` | Heterogeneous non-person profiles generated from pinned aggregate anchors and declared priors | One side of the metformin cohort comparison |
| `nhanes-diagnosed-diabetes-older` | Older diabetes-enriched non-person profiles with recorded parameters | Other side of the metformin comparison |
| `pxr-reference` | PXR research-expression priors, not a validated healthy clinical population | Purified garcinoic-acid/PXR concentration comparison |
| Consented real-human bundle | Explicitly admitted, provenance-bearing observations and missingness | Onboarding/identity/device-contract evaluation only within an approved deployment |

There is **not yet a general healthy-population cohort manifest**. The default
healthy preview must not be mistaken for one. Research strata are not copies of
individual DPP or NHANES participants. OpenMed is a local clinical extraction and
de-identification SDK, not a patient database. No tool supplies an individual's
unobserved genome, organs, medication history or environmental exposures.

### Create and switch research twins

1. Open **Twins**. Keep the non-person research source class.
2. Enter a label, explicitly select a documented stratum, and enter a seed. The
   stratum begins unselected so T2D is never silently chosen for you.
3. Click **Create admitted twin**. Inspect the saved source, seed, missingness and
   member profile. The server generates the profile from its pinned manifest;
   the form cannot label arbitrary values as observations.
4. Click **Activate** on the intended record. Atlas, Biology and attached clients
   resolve that active identity. Create a second record with another seed, then
   activate it to verify switching. Older records remain saved.
5. Bind a **virtual** LIFE Patch for contract tests. It yields modeled sensor
   projections, not physical measurements or clinical-equivalence evidence.

Use Search and 10/25/50-row page controls to find records. Search stays local.
A long encrypted registry may show **Continue search** while scanning another
bounded segment; that is not a claim that no older matching record exists.

### Create cohorts

Open **Cohorts**, choose a name, explicit stratum, size and seed, then create.
Inspect varied frozen members and their source fingerprints. Reusing the same
source/stratum/seed reproduces those priors; changing a seed does not create new
empirical people. Two cohorts with the same members are not independent trials.
Lists are searchable and paged. Real-human membership requires admitted eligible
records and never silently fills missing members with synthetic profiles.

### Real-human onboarding and LIFE Patch

Do not enter real clinical information into this external-test candidate. The
current deployment is local/single-operator, not tenant-isolated or approved for
production PHI. The admission contract supports pseudonymous identity, consent and
purpose, source records, timestamps, units and field provenance for EHR/labs,
medications, wearables/Patch, genomics, lifestyle and environment. Missing domains
remain missing or explicitly reference-initialized, never measured by assumption.

Physical Patch pairing requires the matching admitted identity, B0/protocol
metadata, attestation and current calibration. Pairing metadata is not firmware,
verified hardware, a human-use release, or proof of authentic sensor measurements.
Physical observations and virtual projections are compared only under compatible
channel/unit/time/quality contracts. Neither may silently calibrate the live twin.

## 4. First experiment: oxygen-limited ATP capacity

This is the newly executable Human-GEM protocol. It does **not** require a cohort:
conditions apply to one generic human reference metabolic network, not people.

1. Open **Cendos Lab → Preparation**. Verify Human-GEM says verified/available.
2. Locate **Human-GEM** oxygen/ATP capacity. Set glucose uptake cap to `1` and
   oxygen uptake caps to `0, 2, 10`. Leave complete gene knockouts empty.
3. Read the units: `mmol/gDW/h`, millimoles per gram dry weight per hour. These are
   exchange-flux constraints, not blood concentrations, oxygen saturation or doses.
4. Click **Run** once. The page shows execution in progress while an isolated
   worker loads the actual pinned XML and solves each condition plus two controls.
5. Inspect ATP-maintenance objective flux, **actual** glucose/oxygen uptake, solver
   status, mass-balance residual and bound residual. The cap need not be attained.
6. Both closed-medium and no-glucose negative controls must pass. A failure blocks
   a successful result; it must never be replaced with an assumed zero or a result
   from another model.
7. Click **Visualize this run in Biology**. Select each recorded condition. Bars
   and tables show the saved solution, not a generated kinetic animation.
8. Expand model/software/provenance. Inspect the pinned source, hashes, objective,
   selected directed reaction/stoichiometry/GPR references and constraint records.

Development characterization produced approximately `2`, `12`, `31.5` ATP flux
for those conditions with actual oxygen uptake `0`, `2`, `6`. These are reproducible
computational characterization values, **not a physiological expectation for a
patient**. The solver computes them; the UI does not inject expected results.

### A different perturbation: complete ATP5F1B knockout

Prepare a new Human-GEM run with glucose `1`, oxygen `0, 6`, and the exact stable
gene ID `ENSG00000110955` in the complete-knockout field. This is a **complete
GPR-aware gene knockout**, not a measured human variant or an inferred 50% allele
effect. The development network gave ATP capacities approximately `2`, `4`, versus
`2`, `31.5` without that knockout. These are separately computed condition sets.
There is no claim that an actual person with a gene variant has either response.

The maximum is six conditions and five exact complete gene IDs. Glucose caps are
0–10; oxygen caps are 0–1000. Unknown genes, arbitrary drugs, caller model URLs,
fractional gene activities and nonfinite inputs reject. The worker has a 120-second
hard limit, and concurrent callers receive **busy**, not an unbounded queue.

The mathematical contract is `S·v = 0`, lower/upper flux bounds and maximization
of `MAR03964` ATP maintenance. Only the declared glucose/oxygen uptake is allowed;
unlisted producing boundaries are closed. An optimum is a capacity under these
assumptions, not proof that a living cell operates at that optimum. FVA is not
computed, so selected fluxes need not be unique. No tissue-specific kinetics,
ATP concentration, drug efficacy or person-level coupling is inferred.

## 5. Preserved cohort experiments

**Metformin:** create one cohort from each eligible metabolic stratum, select
both in Cendos, and explicitly enter dose and oral-glucose challenge. Inspect every
member and the cohort summary. This protocol uses reduced glucose/insulin equations
and declared PK/PD assumptions. It is not now driven by Human-GEM, and its
heuristic concentration-to-effect mapping remains unqualified.

**Purified garcinoic acid → PXR:** choose a `pxr-reference` cohort and enter a
free-concentration series, for example `0.05, 0.33, 1.3, 5`. Inspect individual
prior-dependent binding/reporter values. This uses pinned structure/in-vitro
inputs; it does not represent a whole herb, botanical lot, downstream CYP3A4
kinetics, systemic safety, efficacy or clinical outcome.

Unknown compounds must remain unavailable until their own mechanism, quantitative
parameters, material identity and context have been admitted. Installing a network
or finding a database annotation does not supply a valid arbitrary-drug response.

## 6. What biological time and baseline/treated mean

| Surface | Meaning | What it is not |
|---|---|---|
| Atlas trajectory playback | Selects elapsed modeled time relative to the recorded challenge/intervention T0 | Wall-clock patient monitoring or advancing a real person's biology |
| Run-specific metformin Biology | Replays the stored baseline and treated samples for the selected member | A new calculation on each slider movement or measured treatment response |
| PXR Biology | Selects static recorded concentration-response points | Reaction kinetics or elapsed biological time |
| Human-GEM Biology | Selects independent steady-state conditions; no time axis | A developing whole body or dynamic ATP concentration |
| Physical LIFE telemetry | A timestamped admitted sensor observation, when actual hardware/data exist | The same evidence class as virtual or replay channels |

**Baseline vs treated** compares the same saved individual's model under the same
challenge, with versus without the specified intervention. It is not a comparison
between two unrelated people, nor an observed pre/post clinical trial. The
individual-response display selects that member's recorded endpoints. Cohort
summaries aggregate those modeled members and do not establish clinical confidence.

## 7. Preparation, History, recall and rerun

- Opening Cendos always starts in **Preparation**, without auto-recalling the last
  run. **New experiment** clears the current form/result view, not saved records.
- **History** contains paged summaries. Search by run ID or protocol title/type.
  It does not search patient names or open every private member record.
- **Recall** loads the exact saved run and exports. It does not execute anything.
- **Prepare rerun** restores the original configuration and parent identity,
  then returns to Preparation. It still does not execute anything.
- Click the protocol's **Run** button to execute. A new immutable run ID records
  parent ID/hash and reproducibility mode. The original remains unchanged.
- Changed inputs or older incomplete source snapshots require an explicit
  **new configuration** acknowledgment. They are not labeled exact reproduction.
  A parent from a different protocol is rejected even with that acknowledgment.
- Exact reruns require the original model and source cohort identities/versions.
  Missing or corrupt sources cannot silently fall back to the active twin.

## 8. Export and analyze the actual run in Jupyter

From the selected result or Biology page, download **analysis CSV** and **Jupyter
notebook**. The export is bound to that run ID, including its constraints, source
digests, controls and output. Save it in a private analysis directory.

Start Jupyter using the installed candidate's Python, not an unrelated system
Python. For a default installation:

```bash
"$HOME/.local/share/livemorebio/current/source/.venv/bin/python" -m jupyterlab --no-browser --ServerApp.ip=127.0.0.1
```

For a custom installation, replace that executable with
`$LIVEMORE_INSTALL_DIR/current/source/.venv/bin/python`. Open the locally printed
Jupyter URL privately, navigate to the downloaded notebook, and use **Run → Run
All Cells**, then Save. Do not share the Jupyter token or expose its port publicly.
The notebook checks its embedded frozen-run digest and computes tables/plots.
It analyzes the frozen output; it does not silently rerun Human-GEM or calibrate
the live twin. A checksum proves consistency, not physical validity or authenticity
against a malicious operator. Retain upstream attribution when sharing derived work.

## 9. Operate these workflows from the terminal or Python

With the intended normal or isolated stack running and its environment configured,
enter `livemore attach`:

```text
models
twin list limit=10
cohort list limit=10
protocol history limit=10
protocol history q=Human-GEM limit=10
protocol show protocol-REPLACE_WITH_RETURNED_ID
protocol prepare protocol-REPLACE_WITH_RETURNED_ID
protocol metabolic ./oxygen-capacity.json
protocol rerun protocol-REPLACE_WITH_RETURNED_ID
protocol export protocol-REPLACE_WITH_RETURNED_ID notebook=./analysis.ipynb
quit
```

Use exact IDs returned by your run, not the illustrative strings above. Notebook
export refuses to overwrite an existing file. `protocol rerun` is an execution
command; `protocol prepare` is read-only. For a deliberately changed/legacy
configuration, use `new_configuration=true` on rerun and retain that provenance.
Use `help` in the shell for the complete existing patient, cohort, Patch, assay,
screen, report, research and evidence commands.

Example `oxygen-capacity.json` (create this text file in your editor):

```json
{
  "model_id": "human-gem",
  "conditions": [
    {"condition_id": "glucose_only", "glucose_uptake": 1, "oxygen_uptake": 0},
    {"condition_id": "oxygen_available", "glucose_uptake": 1, "oxygen_uptake": 6}
  ],
  "knockout_gene_ids": []
}
```

The same governed surface is available to a notebook or script:

```python
from livemorebio.sdk import Platform

p = Platform(mode="attach")
readiness = p.genome_models()
page = p.protocol_history(limit=10, q="Human-GEM")
result = p.run_metabolic_protocol({
    "model_id": "human-gem",
    "conditions": [
        {"condition_id": "glucose_only", "glucose_uptake": 1, "oxygen_uptake": 0},
        {"condition_id": "oxygen_available", "glucose_uptake": 1, "oxygen_uptake": 6},
    ],
    "knockout_gene_ids": [],
})
saved = p.get_protocol(result["run_id"])
prepared = p.prepare_protocol_rerun(result["run_id"])  # Read-only.
# Explicit new computation, if intended:
# child = p.execute_prepared_rerun(prepared)
```

`Platform()` without `mode="attach"` is an isolated reduced-model shell, not the
governed running service. Model/history/subject commands require attached mode.
The SDK ignores untrusted endpoint URLs in prepared objects and chooses a fixed
local protocol route. Keep credentials in protected environment/key files.

### Developer review on separate ports

From this source checkout and its installed dependency environment:

```bash
PYTHONDONTWRITEBYTECODE=1 python -B tools/run_review_stack.py --base-port 8870
```

It prints a new private data directory and serves 8870/8871/8872 without modifying
the installed 8850 stack. In a separate shell set `LIVEMORE_DATA_DIR` to that
printed directory, explicitly set `LIVEMORE_MODEL_DIR="$LIVEMORE_DATA_DIR/models"`,
and install Human-GEM there with the same candidate Python. A previous model-root
export does not automatically follow a changed data root.
The runner uses its own protected credentials and store paths. To restart with
the same records, use `--data-dir /absolute/printed/directory --base-port 8870`.
Stop only this foreground runner with Ctrl+C. The runner rejects occupied or
installed-service ports before writing data.

For an attached SDK in that environment also export
`LIVEMORE_AEGLE_URL=http://127.0.0.1:8870`,
`LIVEMORE_LIFE_URL=http://127.0.0.1:8871`, and
`LIVEMORE_CENDOS_URL=http://127.0.0.1:8872`, and `unset LIVEMORE_API_TOKEN` so it
loads this runner's private token file. Do not point it at another deployment's
registry. Using a prefix on one command does not configure subsequent shells.

## 9b. The six requested programs (September 22, 2026)

Check readiness before anything else. The command exits non-zero when a
**required** check fails, so it is safe to use in a script:

```bash
livemore doctor            # add --network to probe the public scientific APIs
```

List the programs and what each can actually do:

```bash
livemore programs list
```

You will see three different states, and the difference matters:

| State | Meaning |
|---|---|
| `MARGIN_COMPUTABLE` | Exposure and an active range are both admitted, so a margin is computed. |
| `EXPOSURE_ONLY` | Exposure is computable, but no measured active concentration range is admitted, so no margin is claimed. |
| `EXPOSURE_NOT_COMPUTABLE` | No admitted pharmacokinetic source, or published parameters that contradict each other. The run reports the missing measurement and emits no numbers. |

Run one program, from the terminal, the shell, or the Cendos Lab panel:

```bash
livemore programs run LBHR-030 --dose-mg 400 --cohort 10
livemore attach            # then: program run LBHR-030 dose_mg=400 output=run.json
```

Exogenous insulin runs a paired within-individual design: every member is
simulated twice from an identical initial state, control and treated. Products
without an admitted absorption model are refused by identifier:

```
insulin products
insulin run units=4 meal=60 cohort=12 seed=1
```

Each result carries its own analytical controls (a zero-dose arm that must
reproduce the untreated arm exactly, plus a conservation identity). Check them
before reading any number. Export with `protocol export <run_id> notebook=...`,
or open the workspace directly:

```bash
livemore notebook
```

**What none of this establishes.** These are model calculations. The insulin
model has no endogenous insulin secretion, so it represents insulin-deficient
physiology only. The six programs remain 0/6 validated in vivo, and nothing in
them is dosing guidance. If a program refuses, that refusal is the result.

## 10. Sources and integration boundaries

[Human-GEM source/integrity documentation](HUMAN_GEM_MODEL_SOURCES.md) contains
the pinned eight-file manifest, license, attribution and verification procedure.
Its selected reference projection preserves reaction IDs, signed stoichiometry,
compartments, gene-protein-reaction logic and upstream annotation links. This is
not a newly deployed Neo4j or TuringDB service. Existing backend/licensed-source
gates remain explicit; no external graph service is required to solve this protocol.

**Recon3D could be downloaded and parsed during source evaluation, but is not
enabled or redistributed.** The inspected official model embeds CC-BY-NC-ND 4.0,
which does not authorize this commercial product's use. A separate rights review
and execution contract are required. There is no checkbox or environment bypass.
Human-GEM is enabled under its retained CC-BY-4.0 conditions.

KEGG, GeneCards and MalaCards reference access still requires an authorized source
and the existing entitlement/import gates. A cross-reference in a Human-GEM TSV
is not permission to scrape a database or import a disease score as causal biology.
See [licensed integration](LICENSED_REFERENCE_INTEGRATION.md) and the
[LIFE closed-loop contract](LIFE_PATCH_CLOSED_LOOP.md).

## 11. Troubleshooting and reporting

| Symptom | Action |
|---|---|
| `livemore: invalid choice: models` or `token` | Run `type -a livemore`; an older command is first on PATH. Use `$LIVEMORE_BIN_DIR/livemore` for a custom evaluation, or `$HOME/.local/bin/livemore` only for the default installation. Never delete unrelated commands. |
| GitHub 404/authorization failure | Confirm your account was invited to the private repository and `gh auth status` succeeds. Do not paste a PAT into the install command. |
| `python3.11` missing | Install Python 3.11 before retrying; Python 3.12/3.13 is not this lock's tested environment. |
| Model missing | Run `livemore models install human-gem` with the **same** model/data root used by the services. |
| Corrupt model or unsafe permissions | Preserve the suspect cache; choose a new private model root and install there. Do not edit hashes, suppress checks or delete evidence. |
| `MODEL_BUSY` | Wait for the active computation, then explicitly retry. Do not repeatedly click Run. |
| `MODEL_EXECUTION_TIMEOUT` | Reduce the requested conditions, inspect resources, retain the safe error category and retry deliberately. No success result was fabricated. |
| Biology graphics unavailable | Check WebGL/hardware acceleration. Data cards and retry remain usable without graphics. A failed run ID must not fall back to unrelated anatomy. |
| Browser 401 | Use the exact loopback product URL, not `file://`; reload to bootstrap the local session. |
| Old results visible | Open **New experiment** to clear only the current view. Saved records belong in History; installation does not erase them. |
| Port occupied | Stop only the product you intend using its launcher, or choose three unused review-runner ports. Never broad-kill Python processes. |

Report: installed commit, OS/Python, page/command, exact reproduction steps, safe
error code and expected/actual behavior. Redact identities, clinical values,
credentials, local private paths and confidential material. Include reference-only
screenshots when safe. Do not upload real-person records for troubleshooting.

## 12. Acceptance and next development

Test the empty state, create/switch two reference twins, create eligible cohorts,
page/search records, execute the ATP-capacity protocol, inspect controls/provenance,
recall without execution, explicitly rerun without overwriting, and Run All in the
downloaded notebook. Inspect LIFE/Research to confirm no physical measurement or
calibration was created by a model run. Passing these steps proves the tested
software workflow, not a complete human replica.

The Human-GEM protocol cannot yet enter the person-based physical comparison
workflow: it needs a reviewed cell/assay context with matching **flux** measurements.
The metabolic/cardiac reduced models also need independent population-specific
validation. Other systems remain registered contracts until their engines and
coupling tests exist. Physical Patch firmware, analytical sensor performance,
wet-lab instrument connectivity and production security qualification remain work.

See [the multiscale development roadmap](MULTISCALE_DEVELOPMENT_ROADMAP.md) and
[candidate verification evidence](GENOME_MODEL_REVIEW_EVIDENCE.md) for release
boundaries, actual checks, and the next cell/tissue/organ, Cendos and LIFE builds.
