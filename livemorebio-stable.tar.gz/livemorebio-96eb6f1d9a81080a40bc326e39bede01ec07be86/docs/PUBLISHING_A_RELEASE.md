# Publishing a release clients can install from a bare URL

The repository is private, so nothing under `github.com/MannyAmah/livemorebio`
can be fetched by someone without repository access — including `install.sh`
itself. A client running the documented one-liner against a GitHub raw URL gets
a 404, not a product.

The installer therefore has two paths:

| Path | Fetches from | Needs a GitHub account |
|---|---|---|
| **Published release** (default) | your distribution host, over HTTPS | **no** |
| Repository ref (`LIVEMORE_REF=...`) | GitHub API via `gh` | yes |

The second is for us. The first is for clients, and it needs four files hosted
somewhere public.

## Build the artefacts

```bash
python tools/build_release.py --output dist/
```

This packages a **commit**, not your working tree, so a published artefact
always corresponds to something reviewable. It prints the commit and the
SHA-256, and writes:

```
dist/
  install.sh                          the installer
  stable.json                         channel manifest: commit + checksum
  livemorebio-<commit>.tar.gz         the immutable archive
  livemorebio-<commit>.tar.gz.sha256
  livemorebio-stable.tar.gz           a copy under the channel name
  livemorebio-stable.tar.gz.sha256
```

About 107 MB. Recorded walkthrough media is excluded from the archive via
`.gitattributes` `export-ignore` — it is an internal deliverable and nothing in
`livemorebio/` reads it. Without that exclusion the archive is 254 MB.

## Host them

Upload the contents of `dist/` so they are readable at one HTTPS base. Any
static host works; the installer only does plain `GET`s.

The default base compiled into the installer is:

```
https://raw.githubusercontent.com/MannyAmah/livemorebio-dist/main
```

Use that and clients need no configuration at all. Any other host works if you
tell clients to set `LIVEMORE_DIST_BASE`, so prefer the default.

Requirements for the host:

- **HTTPS with a publicly trusted certificate.** The installer refuses
  anything that is not `https://`, and downloads code from this origin.
- **No authentication**, or the whole point is lost.
- Correct `Content-Type` is not required; the installer does not read it.

Examples: an S3 bucket behind CloudFront, a Cloudflare R2 bucket with a public
domain, GitHub Pages on a *public* repository, or a path on the existing
marketing site.

## Then a client runs

```bash
curl -fsSL https://raw.githubusercontent.com/MannyAmah/livemorebio-dist/main/install.sh | bash
```

## Publish the checksum separately

The manifest travels the same path as the archive it describes, so a host
compromise could rewrite both. Send the SHA-256 to clients through a different
channel — the contract, an email, the data room — and have them pin it:

```bash
curl -fsSL https://raw.githubusercontent.com/MannyAmah/livemorebio-dist/main/install.sh \
  | LIVEMORE_SHA256=<checksum> bash
```

A mismatch refuses the install. An out-of-band checksum that disagrees with the
manifest is treated as an attack, not a stale manifest.

## Updating

Rebuild from the new commit and re-upload. `stable.json` and
`livemorebio-stable.tar.gz` change; previous `livemorebio-<commit>.tar.gz`
files are immutable and can stay, which lets a client pin an exact build
indefinitely.

## What is deliberately not automated

Nothing here uploads or signs. Publishing is the step where a private
repository becomes public bytes, and it should stay a decision someone makes on
purpose rather than a side effect of a build script.

If you later want signatures rather than checksums, the natural addition is a
detached signature over `stable.json` and a public key shipped with the
installer, so the manifest is verified rather than merely fetched.
