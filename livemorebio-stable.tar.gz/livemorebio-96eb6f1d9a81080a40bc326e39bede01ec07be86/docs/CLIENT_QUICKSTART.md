# Client quickstart: run LivemoreBio on any laptop

Two supported paths. The container path works the same on Windows, macOS and
Linux, and it is the one verified on every change by the `Platforms` workflow.

## A. Container (recommended for Windows and for evaluators)

Requires Docker Desktop, and access to this private repository.

```bash
git clone https://github.com/MannyAmah/livemorebio.git
cd livemorebio
export LIVEMORE_API_TOKEN=$(openssl rand -hex 32)
export LIVEMORE_PATCH_STORAGE_KEY=$(openssl rand -base64 32 | tr '+/' '-_')
export LIVEMORE_PATCH_ADMISSION_HMAC_KEY=$(openssl rand -base64 32 | tr '+/' '-_')
docker compose up -d
```

On Windows PowerShell, generate the three values with any random-hex tool and
`$env:LIVEMORE_API_TOKEN="..."` before `docker compose up -d`.

Then open <http://127.0.0.1:8850> for the console, and check the services:

```bash
curl -fsS http://127.0.0.1:8850/health
curl -fsS -H "Authorization: Bearer $LIVEMORE_API_TOKEN" http://127.0.0.1:8850/api/cendos/programs
```

Run the six programs through the API:

```bash
auth="Authorization: Bearer $LIVEMORE_API_TOKEN"

# paired exogenous insulin arms
curl -fsS -X POST -H "$auth" -H 'Content-Type: application/json' \
  -d '{"cohort_size":8,"seed":1,"bolus_units":4,"meal_g":60}' \
  http://127.0.0.1:8850/api/cendos/protocols/exogenous-insulin

# botanical exposure margin
curl -fsS -X POST -H "$auth" -H 'Content-Type: application/json' \
  -d '{"program_id":"LBHR-030","dose_mg":400,"cohort_size":10}' \
  http://127.0.0.1:8850/api/cendos/protocols/botanical-exposure

# a program that is blocked, and says exactly what is missing
curl -fsS -X POST -H "$auth" -H 'Content-Type: application/json' \
  -d '{"program_id":"LBHR-129"}' \
  http://127.0.0.1:8850/api/cendos/protocols/botanical-exposure
```

Stop with `docker compose down`. Add `-v` to discard the state volume.

## B. Native install (macOS, Linux, or WSL2 on Windows)

Requires `python3.11`, the GitHub CLI authorised once with `gh auth login`, and
repository access. Use the one-line installer in the README, then:

```bash
livemore doctor          # readiness; exits non-zero when a required check fails
livemore start           # LIFE :8851, Aegle :8850, Cendos :8852
livemore open            # the console
livemore programs list   # the six programs and whether each can be executed
livemore notebook        # Jupyter workspace with the SDK pre-wired
```

Native Windows is refused deliberately: the product protects local PHI-like
state with owner-only POSIX file permissions that Windows cannot express. Use
path A or WSL2.

## What an evaluator should look at first

1. `livemore programs list`, or `GET /api/cendos/programs`. Three states appear:
   a margin can be computed, exposure only, or blocked with the missing
   measurement named. The refusals are the point, not a gap in the demo.
2. Any protocol result's `controls` block. A zero-dose arm must reproduce the
   untreated arm exactly, and a conservation identity must hold.
3. `evidence_state`, `qualification_state` and `interpretation_limits` on every
   result. Everything here is `MODELED_ONLY` and `NOT_QUALIFIED`.

## What this is not

Not a medical device, not clinical decision support, and not dosing guidance.
The six requested programs remain 0/6 validated in vivo. Physical LIFE Patch
measurements and the Cendos wet lab do not exist yet, so no result here is a
measurement in a person.
