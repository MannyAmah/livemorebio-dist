# Biological learning and model-change contract

Version 1 · 2026-09-05 · applies to every human and agent contributor.

## Objective

Engineer progressively measured functional equivalence across the whole human
biology hierarchy. The acceptance standard is prediction error, coverage and
robustness against independent measurements within a declared context. The standard
is not a realistic picture, a disease label, a pathway lookup or agreement between
two modules sharing the same assumptions.

An executable digital model calculates state transitions. Actual chemical reactions
require physical molecules; physical-device equivalence requires physical hardware
and paired measurements. No software test changes these categories.

## Required understanding, from atoms to the organism

| Scale | Required understanding before modifying a module | Examples of checks |
|---|---|---|
| Atomic | Charge, bonding, energy, quantum versus classical resolution | Charge/conservation rules; force-field limits; protonation context |
| Chemical | Stoichiometry, thermodynamics, kinetics, stereochemistry, solvent and mixtures | Mass balance, units, equilibrium/kinetic distinction, compound identity |
| Molecular | Binding, enzymes, transporters, signaling, compartment concentrations | Free versus total exposure, kinetic parameters, target specificity |
| Genetic | Variants, regulation, transcription, translation, epigenetic state | Identifier mapping, tissue context, linkage and penetrance limits |
| Cellular | Cell identity, metabolism, electrophysiology, division, death, immune memory | Conservation, viability, cell-state applicability, observable readouts |
| Tissue | Cell populations, extracellular matrix, mechanics, diffusion, vasculature | Geometry, boundary flux, scale transitions, spatial resolution |
| Organ | Function, reserve, feedback, injury, repair and failure | Organ-specific endpoint benchmarks, coupled inlet/outlet consistency |
| Whole body | Homeostasis, development, aging, circadian variation and environment | Cross-system feedback, time-scale compatibility, stress response |

The API curriculum at `/api/research/overview` records these requirements. None is
marked completed merely because literature was read. The proposed-model-change
ledger at `/research` binds each contribution to a claim, sources, counterevidence,
test plan and applicability boundary.

## The release packet

Every behavior-changing contribution must supply:

1. A precise question and context of use: species, tissue, age range, disease state,
   intervention, exposure range, duration and endpoint.
2. Primary evidence and contradictory evidence. Record publication, dataset release,
   exact table/figure/method, lawful access, raw-file digest and extraction version.
3. State variables, biological units, compartments, initial/boundary conditions,
   inputs/outputs and all equations or learned-component definitions.
4. Anatomical and molecular identifiers, mapping uncertainty and ownership of each
   cross-scale interface. Do not count an identifier match as causal evidence.
5. Parameter lineage: measured, fitted, literature-derived, assumed research prior
   or unavailable. Preserve missingness. A transcript is not automatically a flux;
   an association is not an effect size; a docking pose is not potency.
6. Individualization rationale. A person-specific parameter must come from admitted
   observations or explicitly documented reference initialization. Validate relevant
   covariance, subgroup coverage and uncertainty before claiming representative cohorts.
7. Measurement mapping to the physical LIFE Patch, laboratory assay or clinical
   reference. Record sensor/assay identity, units, calibration, timing, QC and custody.
8. Intervention model with dose/exposure, mechanism, compartment and applicability.
   Unknown interventions must reject without changing state, not inherit a generic
   beneficial response.
9. Numerical and scientific tests: dimensions, conservation, positivity, convergence,
   stability, sensitivity, parameter identifiability and independent held-out endpoints.
10. Failure criteria specified before viewing validation data, including meaningful
    negative controls, out-of-distribution cases and contradictory outcomes.
11. Independent scientific and code review, versioned release identity, rollback,
    license review and approved claim boundaries.

## Continuous learning loop

```text
New source or physical discrepancy
             ↓
Versioned proposal with counterevidence
             ↓
Source extraction and applicability review
             ↓
Candidate equation / parameter / learned component
             ↓
Offline development data → frozen candidate
             ↓
Independent withheld tests and uncertainty assessment
             ↓
Scientific + software release review
             ↓
Versioned release within its qualified context
```

The current implementation records proposals only. It does not yet implement
reviewer signatures or a production model registry. Automatic active-twin updates
are prohibited. Reading more papers is not reinforcement learning. Any future RL
component needs explicit environment, action space, reward, constraints, offline
evaluation, out-of-distribution tests and controlled release; the twin cannot use its
own generated rewards or outcomes as independent evidence of human equivalence.

## Five-operation cure hypothesis

Treat the founder's objective as a research specification, not an established cure
definition for every disease. Define disease region ΩD and person/age-contextual
healthy region ΩH using measurable endpoints and detection limits. The intervention
objective can minimize toxicity, burden and intervention count only after those
quantities, tradeoffs and constraints are explicitly defined.

Required operations are driver extinction, pathological-memory assessment, tissue
repair, homeostasis and treatment-free resilience. An operation may be declared
nonapplicable only with a rationale; resilience cannot be waived. An absent assay is
not equivalent to absence of a reservoir, clone, pathological seed or damaged tissue.

The implemented evaluator uses a frozen independent-subject roster, individual
healthy ranges, post-washout follow-up and prespecified stress challenges. All
applicable endpoint × stress cells must be present. Repeated samples do not inflate
the number of independent subjects. A one-sided 95% Wilson lower bound is compared
with p*. This assumes independent subjects and complete follow-up; finite observation
cannot establish lifetime resilience or permanent cure. Protocol design and assay
adequacy still require independent domain review.

## Stop conditions

- Missing mechanism: report unsupported, do not substitute a generic effect.
- Missing physical measurements: report awaiting measurements, do not generate them.
- Missing measured-person profile: record reference initialization or unavailable,
  not a biologically complete person.
- Unknown source permission: do not scrape, train on or redistribute the data.
- Unqualified hardware: do not issue human-use or therapeutic commands.
- Failed tolerance or QC: preserve failure and its raw evidence; no post-hoc threshold
  changes or silent self-calibration.
