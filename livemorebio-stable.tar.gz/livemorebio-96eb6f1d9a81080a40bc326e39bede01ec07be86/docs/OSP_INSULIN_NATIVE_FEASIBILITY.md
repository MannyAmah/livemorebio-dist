# OSP insulin: isolated native feasibility, not product readiness

2026-09-08. Parent approval: Stage A of the
[OSP insulin subplan](solutions/2026-09-08-osp-insulin-reference-subplan.md).
This report records observed software execution against public source data.
No personal data, LIFE commands, product database, global package installation,
shell-profile change, source commit or publication was performed.

## Outcome

**Native execution is feasible on this ARM64 Mac.** R4.6.1, .NET8.0.30,
rSharp1.2.2 and ospsuite12.4.3 loaded and solved both an official smoke model
and the historical glucose–insulin source model. A private original translation
of source case2 performed initialization, IV insulin and zero-dose control.

This does **not** complete R33 or the whole-body/personalized requirements.
The independent recipe review, numerical-convergence protocol, author-runtime
equivalence, individual parameter identification, physical qualification, secure
product worker, UI/CLI wiring and videos are still open. The five botanical
programs remain active in the [source record](OSP_INSULIN_AND_CANDIDATE_SOURCES.md).

## Private runtime, exact provenance and failures

Private root: `/tmp/livemore-osp-native.mUlZwx`.
Source-only root: `/tmp/livemore-osp-source.fmi3LG`.
These retained temporary directories are review artifacts, not install commands
or durable release locations. Host: macOS26.4.1 ARM64. Approximate retained disk
use:965MiB overall, including385MiB R packages and75MiB .NET runtime.

| Component | Verified artifact / behavior |
|---|---|
| R4.6.1 | Official [ARM64 package](https://cran.r-project.org/bin/macosx/sonoma-arm64/base/R-4.6.1-arm64.pkg). SHA256 `67f6eea4ced4ce48f0a0d4fa3a1cac43d1859a05a88993ee3dff7c52e7edbc4b`; published SHA1 also matched. `pkgutil --check-signature` reported trusted notarized Developer ID Installer Simon Urbanek(VZLD955F6P), signed2026-06-25. |
| Private R extraction | `pkgutil --expand-full`, no installer scripts executed. The shell wrapper initially ignored R_HOME and returned `/Library/Frameworks/R.framework/Resources`. Only the private wrapper was changed to private R_HOME/share/include/doc and scoped DYLD_LIBRARY_PATH. Original wrapper retained as `R-wrapper.original`; native binaries unchanged. No admin or global framework required for this probe. |
| .NET8.0.30 | Official [osx-arm64 runtime](https://builds.dotnet.microsoft.com/dotnet/Runtime/8.0.30/dotnet-runtime-8.0.30-osx-arm64.tar.gz); upstream SHA512 matched. SHA256 `a2825f1fd3b04671b5df67375cbeff4655603e45ef999b540d92050bdac565a3`. Private host reports8.0.30, ARM64, commit a83db3e0eb, no SDK. Scoped PATH/DOTNET_ROOT only. |
| ospsuite12.4.3 | Official archive SHA256 `9637b9fa76714abf9206395d7ed6602919ee6a1e7e215fa363db8c4a1841c19e` matched. Native ARM64 solver libraries used, not x64 emulation. |
| rSharp1.2.2 binary failure | Official `.tgz` SHA256 matched `654401ba1b9b3701e2d3449a535fa367bacc02dadc44eefc0283d834b0d7c338`, but both Python gzip/zlib and `gzip -t` rejected corrupt compressed data. It was retained, not installed or silently relabeled. |
| rSharp1.2.2 source route | [Pinned source](https://github.com/Open-Systems-Pharmacology/rSharp/tree/3a8686e70c700437b451a01216ad4fb2990e432c) archive SHA256 `bbf43970ae2ec2d89977422c9e9543fddf524da8e15acba5628a2ed6971a8be4`. Installed privately with its supplied native ARM64 bridge after reading install/load code. No arbitrary downloaded installer script executed. `dotnetAvailable()` was explicitly true. |
| Other OSP packages | ospsuite.utils1.11.1, tlf1.6.2, ospsuite.plots1.3.0; pinned released sources/artifact hashes retained. Plots installed from its pinned pure-R source. |
| CRAN dependencies |66 package versions resolved before download; each binary MD5 matched the captured CRAN index, then locally recorded SHA256. `cran-dependency-lock.csv`, `installed-r-packages.csv`, and `native-artifact-manifest.csv` retain actual provenance. No moving package resolution during solve. |

R/Open Systems Pharmacology/rSharp GPL notices and the OSP clarifying addendum
were inspected. Private execution is not blocked merely because these are
copyleft packages; redistribution/combined-product obligations require a separate
review. A subprocess boundary does not itself waive licence obligations.
Reference spreadsheets' redistribution rights remain separate; they were not
bundled into the product. .NET8 support ends2026-11-10 according to
[official metadata](https://builds.dotnet.microsoft.com/dotnet/release-metadata/8.0/releases.json).
This is not an indefinite production runtime commitment.

## Native model loading: the important format distinction

Modern `ospsuite::loadSimulation()` expects high-level PKML. With
`GIM_Healthy.xml`, it returned an explicit old-PKML conversion error requesting
OSP8. That is not a missing-kinetics problem and must not be hidden as readiness.

The file is low-level SimModel XML version4. The official
[SimModel implementation](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/0969102edb524f73e980de729b165bbb55956f14/src/OSPSuite.SimModel/Simulation.cs)
exposes `LoadFromXMLFile`/`LoadFromXMLString`, `FinalizeSimulation`,
`RunSimulation`, native times, values and warning/tolerance status. Those exact
methods were exercised through the supplied .NET assembly after explicit
`rSharp::loadAssembly`. An initial unqualified assembly lookup failed; explicit
loading resolved it. No XML version spoofing or model conversion was used.

Native runtime artifact digests:

| Artifact | SHA256 |
|---|---|
| OSPSuite.SimModel.dll | `4c14eb2824397a1577e7c689984e4b9e9ea1b4297e6e480824681f19d199e520` |
| libOSPSuite.SimModelNative.dylib | `d3ca3467fa7886898e76c47a81df031dfa5403e3497448611c3cb0d71c120bd4` |
| libOSPSuite.SimModelSolver_CVODES.dylib | `19453818ef70c4b722f7aba518660927ac005e9b89ba8621598ec0038d99e257` |

The smoke `simple.pkml` returned actual finite amount/time series in4.49s wall
with294,240,256bytes maximum RSS. Unmodified GIM low-level native execution
returned301 times spanning0–300min in2.98s, maximum RSS435,585,024bytes. Neither
smoke result alone is insulin-protocol acceptance.

## Faithful case2 preparation and model semantics

The [pinned author MATLAB recipe](https://github.com/Open-Systems-Pharmacology/Glucose-Insulin-Model/blob/17a7f8eaac8d6c3e3f49d0a6e0fe6101e4bc3e18/GIM_simulations.m)
was read, never executed. Private original R files `gim_recipe.R`,
`test_gim_recipe.R`, and `run_gim_case2.R` translate only case2 for evaluation:

1. Apply empty Global and37-row Healthy workbook sheets; verify exact parameter
   paths and explicitly declared units. Apply source `initExact=1`, `S_I=0.9`.
2. Disable the eight applications explicitly enumerated by the author recipe.
3. Run native initialization0–1000min on the source1-min grid. Retain all1100
   state outputs for inspection; changing `persistable` affects storage only.
4. Transfer1073 independent state final values by exact entity ID. Preserve all27
   `initialValueFormulaId` dependencies, all reaction/formula definitions and
   source solver settings. Never reset formula-defined administered amounts to
   zero during transfer.
5. Apply source dose `0.04*7e-9*5808*1e-3`kg/kg, three-minute IVITT starting0,
   and solve0–200min. This uses historical7nmol/IU and5808g/mol exactly;
   it is not an administration recommendation or a modern formulation assertion.
6. Repeat from the same initialized state with zero dose as a numerical control.

**Correction to the earlier source reading:** IVITT administers the source's
`Insulin` molecule and is observed in its `Insulin|Plasma` pool, which includes
endogenous insulin. The separate `Insulin Ex` observer remains zero in this case.
It must not be presented as separately tracked exogenous insulin exposure.
The source `Organism|Weight` is formula-derived from source tissue volumes; the
recipe's local73kg variable does not authorize changing that geometry or making
individualized weight claims.

Contract tests were written before the recipe implementation and first failed
because the implementation did not exist. The private prototype then exposed
an R nested-assignment error, corrected to explicit `xml_set_text`. Decimal
transport tests initially demanded bit equality; inspected differences were
binary64-rounding scale, so the serialization assertion now uses four machine
epsilons pointwise (not a physiological tolerance). Tests now pass for paths,
units, unchanged formulas, dependency preservation, missing/nonfinite states,
application activity, grids, exact source conversion within transport precision,
and zero-dose input. These are not independent scientific validation tests.

## Measured native execution results

Full three-solve process:10.79s wall,9.30s user,0.66s system,
936,034,304bytes maximum RSS, no swap. Watchdog120s, one process. Solver times
were1.048s initialization,2.057s IVITT and0.501s zero-dose; loading/export adds
overhead. Every solve reported zero warnings, no tolerance reduction,
absolute tolerance1e-9 and relative tolerance1e-4. No tighter-tolerance
convergence acceptance has yet been performed.

| Output | Actual computed/reference comparison | Interpretation |
|---|---|---|
| Glucose | Baseline4.412023mmol/L; computed minimum2.570984mmol/L at33min | Computed source-case response, not newly measured human data. |
| Insulin | Computed peak3708.75pmol/L on1-min grid | Shared Insulin pool; not an independently tracked exogenous fraction or exact continuous-time maximum. |
| Zero-dose glucose | Range4.412020–4.412608mmol/L | Small remaining drift observed; no post-hoc clinical/stationarity threshold declared. |
| Glucose reference residual | RMSE0.3725864mmol/L, MAE0.3467297,11 points | Source-distributed digitized reference data; not held-out individual validation. |
| Insulin reference residual | RMSE220.5551pmol/L, MAE142.3676,12 points | Same limitation; source output linearly interpolated only for comparison. |

Source glucose µmol/L was divided by1000; insulin µmol/L multiplied by1e6.
No fitted parameter or invented endpoint was added to improve agreement. The
[source README](https://github.com/Open-Systems-Pharmacology/Glucose-Insulin-Model/blob/17a7f8eaac8d6c3e3f49d0a6e0fe6101e4bc3e18/README.md)
identifies the reference points as extracted from
[Sorensen1985](https://dspace.mit.edu/handle/1721.1/15234), and cautions that its
examples may not represent best possible performance. A numeric author-prediction
golden trace was not supplied. These residuals do not establish equivalence to
the historical runtime or an acceptable clinical prediction error.

## Review artifacts and remaining acceptance

All paths below are relative to the retained private runtime root, not the repo:

| Artifact | SHA256 |
|---|---|
| gim-case2-feasibility.json | `86172e10aa567fbe257268da539d1ef4f50f92d998b17c04b4e44df3164ca193` |
| gim-case2-ivitt.csv | `91e3ad6a9b633b1226eb79ebb2eea09c17f93d1fac7ccaecbff560f9ac5b19c0` |
| gim-case2-zero-dose-control.csv | `74e5d8105d2984a9376d630121f24df08fba7f087ea0984685b82bcc00dac283` |
| gim-steady-state.csv | `0db6f85680519b70d716ea595a4cc6e5f8784cecdceed69751355551ab865db5` |
| cran-dependency-lock.csv | `b89aabde41803970f608ac18fc5fb9a53c9e5a8d9c0c5e56e511b48dd5ca0ccd` |

The same directory retains solver JSON, glucose/insulin reference residual CSVs,
installed package versions, per-artifact SHA256 manifest, private scripts and
the corrupt official rSharp binary. No artifacts were deleted. Original source
hashes remain unchanged.

Next approval packet: independently review the exact recipe and native boundary;
prespecify and run tighter-tolerance/full-state convergence and initialization
checks; resolve a source-author golden/old-runtime comparison if available;
confirm reference-data rights and formulation context; then review a bounded
production worker/asset installer. No uncontrolled solver or biological
reparameterization should be added to obtain an attractive curve.

Durable lesson: an old high-level loader error is not proof that the source
ODE cannot execute. Match file schema to the correct native interface, verify
source semantics at the actual administration edge, and separate execution,
numerical equivalence, measurement agreement and human qualification.
