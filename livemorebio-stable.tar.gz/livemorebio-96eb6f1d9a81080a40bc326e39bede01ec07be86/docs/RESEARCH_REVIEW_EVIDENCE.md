# Research review: evidence and release boundaries

2026-09-05 · `codex/research-validation` · based on interface candidate `0db2a4d`.

Historical evidence for the preserved candidate. The additive Human-GEM build has
its own [verification report](GENOME_MODEL_REVIEW_EVIDENCE.md); its tested model
installation supersedes the missing-file readiness description here without
rewriting these original test results.

## Decision

This is a local, single-operator research candidate, not a pharmaceutical production,
human-use, hardware or clinically validated release. The review repaired concrete
scientific-integrity and workflow defects. It did not establish an exact human
replica or perform a physical experiment. Stronger claims remain blocked by the
missing evidence listed in the [readiness roadmap](PHARMA_READINESS_AND_ROADMAP.md).

## What changed and how it was checked

| Change | Evidence and adverse-path coverage |
|---|---|
| Individual profile fidelity | Full metabolic profile survives subject activation, Aegle state, bus snapshot and Cendos admission. Incomplete/mismatched snapshot or PK context rejects; clinical unit, timestamp and QC mappings are tested. |
| Unsupported biology | Unknown compound defaults, generic plant benefit, annotation-to-causal-effect and unqualified GEM-to-physiology mappings fail closed. A rejected intervention cannot change the twin. Existing metformin heuristics remain explicitly unqualified. |
| Run-bound visualization | Atlas is separate from detailed organ geometry. Time selection projects stored glucose samples. Biology member/condition controls read the selected immutable run, not whichever twin is currently active. Static PXR data do not animate fabricated kinetics. |
| Physical counterpart | Server-resolved frozen prediction; encrypted raw measurement bytes and custody; exact units, specimen/member identity, replicate/QC checks; residuals and missing/incomplete data. Technical fixtures cannot qualify biology. |
| Treatment-free resilience | Five operations, subject-specific healthy ranges, independent subject roster, stress timing, washout and post-washout follow-up; repeated rows cannot inflate independent successes. Missing data and failed criteria cannot authorize a cure claim. |
| Biological learning | Eight-scale curriculum and contributor change contract; immutable proposals require sources, counterevidence, applicability and independent test plan. No automatic active-model training or calibration. |
| Licensed disease references | KEGG/MalaCards exact-ID release lookup with hashes, expiry and explicit permissions; commercial transport rejects academic host and unsafe credential forwarding. Missing access reports unavailable. |
| Browser/CLI/SDK parity | Same Research operations and strict JSON boundaries. Duplicate decoded keys, unsafe integer literals, nonfinite values, excess nesting and oversized inputs reject. |
| Evidence exports | Missing archive 404, unapproved draft 409, integrity/storage failure 503; safe error detail and no-store. No fabricated reviewer, dataset digest or approval. |
| Review isolation | Separate service ports, local data/keys, Patch journal, screens, LIMS and cache/signing paths; unsafe existing directory/secret reuse rejects. See the [isolation lesson](solutions/2026-09-05-review-stack-isolation.md) for the startup incident. |

## Automated verification

The final full-suite result and build digest are recorded in the verification
addendum below. Tests were executed with Python 3.11 and the existing managed
dependency environment, with this worktree first on `PYTHONPATH`. This is not a
claim that every optional scientific dependency was installed from a clean machine.

Fifteen native-model tests require absent `Recon3D.xml` or `Human-GEM.xml` assets.
Those paths cannot be reported as verified. Three deprecation warnings concern
Starlette/httpx TestClient and FastAPI startup events. Numerical test agreement is
software evidence; it does not validate the physiological coefficients against people.

Line/branch coverage was not measured: the coverage package was unavailable. The
table above is an assertion/behavior map, not a claim of 100% code or biological coverage.

## Independent review and real-browser QA

Separate reviewers examined scientific admission/profile integrity, source licensing,
UI behavior, strict parsing, immutable exports and review-stack isolation. Findings
were repaired with regressions. This bounded independent review is not a penetration
test, full regulatory audit or independent clinical scientific qualification.

The [independent browser report](solutions/2026-09-05-research-independent-browser-qa.md)
walks the Research tabs, pending-measurement state, proposal and unavailable-source
paths, desktop and mobile layouts. Two UI issues—overlapping ledger and distant
errors—were corrected and retested. Root verification additionally exercised:

- Atlas playback: recorded glucose changed from 135 at time 0 to 150.6 at time 245;
  pause stopped the display. These are stored model samples, not human measurements.
- Heart-tree focus, provenance disclosure and the explicit no-observations state.
- Duplicate specimen mapping: submitting `{"sample-1":"member-a","sample-1":"member-b"}`
  displayed an inline error and issued zero POST requests. No study was saved.
- Research resilience at 390×844: correct selected panel and no horizontal overflow.

Screenshots: [Atlas](screenshots/research-validation/atlas-final.png),
[evidence disclosure](screenshots/research-validation/atlas-evidence-final.png),
[rejected duplicate mapping](screenshots/research-validation/duplicate-mapping-rejected.png),
[mobile resilience](screenshots/research-validation/research-resilience-mobile.png).

## Detailed demonstrations and analysis

Both videos are native browser capture, H.264 transcode only, with live captions
and visible typing/clicks. No slides, speed changes or manufactured reactions.

| Workflow | Duration | Recorded data |
|---|---:|---|
| Purified garcinoic acid / PXR | 6:58 | 8 prior-generated members; 4 concentrations; individual readouts and static response plot |
| Metformin comparison | 8:10 | Two separately seeded 6-member metabolic strata; individual stored glucose trajectories |

Both downloaded CSV/notebook files through the product, executed all 3 code cells
in real Jupyter kernels, verified the frozen-run hash and saved outputs without
errors. The physical counterpart form remains an unsubmitted draft: no specimen,
instrument result or positive validation outcome was invented. The recordings use
research-prior members, not individual NHANES/DPP participant records or real patients.

See the [recording evidence index](demo/research-validation/README.md) for videos,
exact run IDs, durations, interaction counts, chapters, CSVs, executed notebooks and
SHA-256 digests. Root inspected the recorder implementation and frames extracted
from both final MP4s. The first failed plant take is explicitly excluded, not passed
off as a completed demonstration.

## Plan completion and remaining gates

The written [build plan](solutions/2026-09-05-research-validation-build-plan.md)
preceded implementation. Its software repair, comparison/resilience/learning,
source-access, simplified UI, terminal, recording and documentation work is present.
The strongest objective—functional equivalence with real human biology—is not complete.

Not performed: new physical Cendos measurements; human enrollment or device trials;
whole-body atomistic modeling; prospective clinical qualification; taurine response
execution; production graph/SSO/multitenancy/load/security qualification. No source
catalog entry, passing numerical criterion or video upgrades those states.

Taurine was evaluated against primary evidence and counterevidence in the
[taurine review](TAURINE_EVIDENCE_REVIEW.md). A specific response engine was not
invented from review prose. KEGG/MalaCards adapters are implemented but no authorized
vendor release was supplied, so live scientific use remains unavailable.

No production deployment or merge is part of this candidate. The original services
on 8850–8852 remain the existing release; the candidate uses 8860–8862. No Hermes
monitor is created because no staged release/endpoint was deployed for that handoff.
Compound Engineering and gbrain were unavailable; lessons were written locally in
`docs/solutions/`, not described as executed unavailable skills or synchronized memory.

## Verification addendum

After the last isolation and typed-export-error fixes:

- `python -m pytest -q -rs`: **624 passed, 15 skipped, 44 subtests passed**, 3 warnings,
  119.60 seconds. The skips comprise 8 Recon3D and 7 Human-GEM tests; no skipped path
  is represented as passed.
- `python -m compileall -q livemorebio tools/run_review_stack.py`: passed.
- Node syntax checks for the recorder, Research UI and strict JSON module: passed.
- `git diff --check`: passed.
- Wheel build (no dependency resolution/build isolation): passed. Artifact
  `livemorebio-0.0.1-py3-none-any.whl`, 1,059,278 bytes,
  SHA-256 `1fa75c6266032b5ba57ee562cce98c4e9aeeb7512dfe3297c0e6d8ca26286ba2`.
- Wheel installed with `--no-deps --target` into a fresh temporary directory:
  import resolved to that directory, all 16 packaged seed JSON files parsed,
  Research HTML/JS/CSS resources were present and strict parsing executed.
  Dependencies still came from the managed environment; this is not a clean-machine
  optional-kernel installation test.
- Final review-stack restart preserved both recorded runs. Attached SDK overview
  succeeded. Live HTTP checks confirmed unauthenticated Research 401/no-store,
  retired evidence intake 409, missing export 404/no-store, and explicitly
  unavailable KEGG/MalaCards releases.

The repository has no `VERSION` release file; its package version remains 0.0.1.
No release tag or production version bump is implied by the research candidate.
