# External tester guide — September 9 checkout

This is an authorized, local **research-software evaluation**, using public
reference data and clearly labeled non-person research inputs. Do not enter
patient information, clinical records, partner-confidential experiments, or real
device measurements. This deployment is not approved for production PHI, human
use, clinical decisions, dosing, or treatment control.

This guide describes the supplied September 9 working checkout. It is **not a
published release or a commit-pinned remote installer**. The older main and
September 5 installer commands select different source; do not use them to obtain
this checkout. The owner must supply the reviewed source snapshot and its final
identity/verification receipt. A branch name or `git rev-parse HEAD` alone does
not identify uncommitted files. No new published installer is claimed here.

## 1. What is available, and what is not

| Surface | What a tester can inspect or execute | Boundary |
|---|---|---|
| Atlas | Whole-body reference anatomy and nine selectable reference layers on the reviewed host | Anatomy is not an individualized whole-human physiological simulation; a cold source acquisition can be unavailable |
| Ordinary Biology | Seven organ views, model-specific quantities, and molecular-reference inspection; the local hERG structure reached READY in owner QA | Missing organ functions remain unavailable; structures/target annotations do not establish a drug response |
| Molecular inspector | Seven pinned reference structures and a locally served 3Dmol viewer, with attribution and source identity | Local molecular assets do not make all Atlas geometry, every database, or the whole product offline |
| Twins | Explicit research-model creation/activation and provenance-bearing record contracts | A healthy preview is not a registered person; descriptive records without a model binding cannot execute |
| Cohorts | Frozen prior-generated research profiles; separately, joint public-source measurement tuples | Public-reference cohorts are descriptive, not enrolled humans or executable physiology |
| LIFE → Aegle | Explicitly prepared metabolic numerical producer, virtual LIFE admission, and Aegle acknowledgment | Modeled plasma glucose only in this continuous LIFE path; no physical sensor-transfer model or ECG |
| Cendos Human-GEM | Actual pinned reference-network steady-state ATP-capacity computation, controls, immutable results and exports | Generic network, not a person's ATP level, time evolution, drug efficacy, or human validation |
| Other bounded Cendos protocols | Existing metformin cohort, purified garcinoic-acid/PXR, and nonhuman lobeline/VMAT2 calculations | Different assumptions and evidence classes; none qualifies the six requested scientific programs |
| Research/evidence | Frozen comparisons, provenance, explicit missingness, and independent-review contracts | A tolerance pass or software signature is not independent physical validation or automatic calibration |
| Direct OSP/.NET replacement | Built worker/parent and offline fake/serialization/ownership evidence; the first actual packet stopped at PRE_XML with `INSPECTOR_AMBIGUOUS_ROW` | Native technical qualification is incomplete; no XML ACK, numerical observation or qualified insulin engine. Not a tester launch path |

The whole-human manifest separately reports registration, reference support,
modeling, coupling, person calibration, context validation, independent
replication, and physical device connection. Architectural inclusion is not
functional maturity. Inspect `/api/system-manifest` on the running Aegle origin;
do not infer maturity from how complete the anatomy looks.

The six original programs remain **insulin, LBHR-172, LBHR-129, LBHR-062,
LBHR-030 and LBHR-135: 0/6 validated** at this handoff checkpoint. A Human-GEM,
metformin, PXR, lobeline, or numerical-method demonstration is not a substitute.

## 2. Prepare the exact supplied checkout

Use a local macOS or Linux machine with Python **3.11**, a browser with WebGL,
and several GB of available memory/disk for scientific dependencies and reference
models. The reviewed host used Python 3.11.15. Windows is not qualified by this
guide. Host architecture and native-library availability can still block a fresh
machine; do not work around a failure by dropping dependencies or changing pins.

The Myokit/CVODE cardiac path needs a working C compiler and SUNDIALS development
headers/libraries. These are host prerequisites, not silently installed by this
checkout. Node.js is needed for JavaScript regression tests, not for serving the
bundled molecular viewer. Jupyter is included in the lock for notebook analysis.
Browser-automation tools and recording tools are optional QA equipment, not
requirements for ordinary use. The OSP/.NET toolchain is not part of these user
installation steps.

From the owner-supplied source directory, create a **new** environment. Replace
the first path with that supplied directory. If `.venv-tester` already exists,
use a different new name consistently; do not overwrite an existing installation.

```sh
cd /path/to/owner-supplied-livemore-checkout
python3.11 -m venv .venv-tester
./.venv-tester/bin/python -m pip install --require-hashes -r requirements-python311.lock
./.venv-tester/bin/python -m pip install --no-deps --no-build-isolation -e .
./.venv-tester/bin/python -m pip check
```

The checked-in lock includes scientific, server, notebook, and test dependencies,
including `trimesh==5.0.0`. Keep `--require-hashes`; do not replace the lock with
an unpinned `pip install` workaround. These installation commands can download
packages. They are not an offline-install claim or a new-machine installation
receipt. Stop and report the first installation error before launching.

Keep this shell in the checkout for the commands below. An editable installation
follows later file changes, so the owner must freeze source during a recorded
evaluation. Do not mix an old `livemore` executable elsewhere on PATH with this
checkout's Python.

## 3. Choose fresh or persistent isolated data

### Quick blank evaluation

```sh
./.venv-tester/bin/python -B tools/run_review_stack.py --base-port 8868
```

Omitting `--data-dir` makes a new private temporary data directory and new local
credentials. The launcher prints **Isolated review data: …**. Save that path
privately if you want to revisit the same records; temporary directories are not
durable backups. This fresh launch has no installed Human-GEM assets yet. To add
them, use that printed directory as the data path in the next section, rather
than creating another temporary root accidentally.

### Persistent evaluation, including Human-GEM

Create a new owner-only directory outside the source tree. This example creates
one under your home directory and does not touch `~/.livemore`:

```sh
umask 077
export LIVEMORE_REVIEW_DATA="$(mktemp -d "${HOME}/Livemore-review.XXXXXX")"
export LIVEMORE_MODEL_DIR="$LIVEMORE_REVIEW_DATA/models"
printf 'Keep this private evaluation path: %s\n' "$LIVEMORE_REVIEW_DATA"
```

The data directory must belong to the current user and have permissions `0700`.
Do not point it at another person's directory or use a symlink. The launcher
checks its known stores, credentials, and companion files and refuses unsafe
types/permissions rather than silently fixing or replacing them.

Install the optional Human-GEM reference package explicitly before starting the
stack when possible:

```sh
./.venv-tester/bin/python -B -m livemorebio.model_assets install human-gem
./.venv-tester/bin/python -B -m livemorebio.model_assets check human-gem
```

This downloads eight pinned Human2 v2.0.0 source/notice files, approximately
45.8 MB, and verifies their sizes, SHA-256 values, and installation receipt.
The exact source contract and hashes are in
[Human-GEM model sources](HUMAN_GEM_MODEL_SOURCES.md). `check` is a read-only
integrity check and exits nonzero when missing/corrupt; `status` reports JSON but
can exit successfully with `available: false`. Neither proves a solver ran.
Ordinary scientific runs do not silently install a missing model or fall back
to another model. Recon3D remains commercially restricted and disabled.

Then start all three isolated services:

```sh
./.venv-tester/bin/python -B tools/run_review_stack.py --base-port 8868 --data-dir "$LIVEMORE_REVIEW_DATA"
```

Keep this terminal running and open **http://127.0.0.1:8868**. The internal LIFE
and Cendos peers use ports 8869 and 8870. Use the Aegle navigation for the browser
workflows; do not open the HTML files directly. All three ports must be unused.
If occupied, choose another unused consecutive triple with `--base-port`; the
launcher deliberately refuses the installed-service ports 8850–8852.

The loopback browser establishes its same-origin authenticated session without
a token prompt. The launcher generates private operator and encryption
credentials; **do not generate, paste, print, record, or send these tokens**.
This local authentication is not multi-tenant production security. Keep the
services on loopback; no public tunnel or `0.0.0.0` exposure is part of this test.

In a later shell, set `LIVEMORE_REVIEW_DATA` to the exact saved directory and
`LIVEMORE_MODEL_DIR` to its `models` child before checking/installing model assets.
The launcher itself explicitly scopes service model caches and mutable stores
under its selected data directory. A different terminal's environment does not
change services already running.

### Owner's already-running September 9 review instance

The owner-reported review launch uses the following existing local paths. This
is a record for maintainers, **not portable tester setup**, and must not be
started again while that instance is running:

```sh
cd /Users/emman/Livemore/.worktrees/full-scope-recovery
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python tools/run_review_stack.py --base-port 8868 --data-dir /private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-rqo3olua
```

Root's current restarted runtime source identity is
`326dcfaf1c8ebf51b0e5bfe5dc37d2186452b698ad5ebb4a934fd0e694c72190`
(receipt `49fd2c`, reported startup `17:07:47.855810`). This includes the narrow
Atlas declared-group search correction, accepted in root's actual browser:
`heart` returned 83 real members with the first 30 shown, exact FJ2417 retained
its PART-OF FMA7088 source card, and clearing restored the search help.
Earlier screenshots and Video A retain their own `69a8c90e…` or `da7673ba…`
identity; Video A's original zero-result `heart` query is not edited out.
Earlier `compileall` (`07b205`) and `git diff --check` (`e066df`) passed before
the legacy correction. The post-legacy, **pre-Atlas** full `-rs` repeat passed
(`7c4a53`). The current post-Atlas full regression completed (`a1c8cc`):
**6,416 passed, 44 skipped, 5 deselected, 5 warnings, 95 subtests passed in
402.88 seconds**. Supported Videos A and B are complete and narrowly
media-accepted by root; whole-product visual acceptance remains open. See the
[dated final receipt](solutions/2026-09-09-final-browser-and-regression-receipt.md).

## 4. Verify the blank-state and navigation contract

For a new data directory, expect no saved twins, cohorts, or experiment History.
The healthy **reference preview** is an unregistered numerical/reference context,
not a hidden admitted human or a previous experiment. Loading reference assets
does not seed operational History. Existing persistent data is intentionally not
blank and must not be reset just to match a screenshot.

Visit these paths from the same Aegle origin:

| Page | First check |
|---|---|
| `/` — Atlas | Current selection/provenance is visible; layers load or state why unavailable |
| `/twins` | No silently selected research stratum; saved records and active authority are distinct |
| `/cohorts` | Research-model and joint-public-record modes stay separate |
| `/biology` | Ordinary selected context; no different twin substituted when the model is unavailable |
| `/patch` | Preparation is explicit; entering the page does not start a producer or LIFE consumer |
| `/cendos` | Blank protocol selector; choose one of four preserved protocols to reveal its form. No automatic recall or execution |
| `/research` | Evidence and learning operations retain their non-clinical limits |
| `/adapters` | Catalog, configured, operational, wired and scientifically qualified are separate states |

Development tracker/timer surfaces are **off** for this workflow. Product source
timestamps, native model time, freshness displays and explicitly started service
computation remain meaningful; “timer off” does not disable resource/cleanup
limits or pause a running biological-model execution.

## 5. Research twins, source-linked cohorts and Biology

1. In **Twins**, choose a non-person research model context explicitly, supply a
   label and seed, and create the record. Inspect full provenance and missingness.
2. Activate that exact record. Confirm the active identity on Atlas/Biology and
   LIFE preparation. A template label alone must not create measured physiology.
3. In **Cohorts**, choose a supported research context, seed and size, then freeze
   the definition. Members and source fingerprints must remain inspectable.
4. **Joint public-source records** is a different mode: explicitly install the
   reviewed public source if unavailable, accept its statistical-use boundary,
   preview selection, then freeze it. This is an explicit network/data action,
   not an automatic source on page entry. Never identify or link participants.
5. Inspect source-linked tuples and their missingness. These descriptive records
   cannot activate a twin, bind a physical Patch, or run Cendos without their own
   qualified model binding. Changing the indication or stratum is not a binding.
6. In **Biology**, select an organ and available molecular target. Inspect the
   structure/source identifier, attribution, and reference-only boundary. hERG
   uses pinned structure `5VA2`; rendering it is not a QT prediction.

Owner QA froze a five-record selection from 384 eligible joint NHANES records
and inspected three hepatic research-prior profiles. These are particular
review records, not automatically created defaults, enrollment counts, validated
healthy controls, or new individual physiology. Anatomy geometry and empirical
reference records must never supply missing dynamic model parameters by guess.

The molecular viewer is served locally from the supplied checkout, including its
notices. Atom counts and source hashes describe exact reference coordinates, not
simulation results. A failed structure should show an unavailable/retry state;
close it and retain the failure report rather than switching targets and calling
the failed target successful. Atlas geometry has separate source/cache readiness.

## 6. Continuous modeled execution → LIFE → Aegle

Use a registered, active, executable **non-person research twin**, not the
unregistered preview or a descriptive reference cohort. On **LIFE Patch**:

1. Open **Prepare an execution** and choose **Read selected source**. Check twin
   ID/version and source generation before any mutation.
2. Select the metabolic engine. To match recorded Video A's two-model-minute
   exercise, use native horizon `2` **minutes**, wall/model rate `1` **model second per
   wall second**, and frame period `1` **wall second**. Initialization and host
   load are additional; this is not a guaranteed two-minute completion deadline.
3. Click **1. Register numerical probe**, then **2. Bind probe to twin**. Binding
   changes registry version; the current source must be read after that change.
4. Click **3. Prepare frozen execution**, then **4. Bind LIFE session**. A prepared
   execution must not yet claim computed samples or acknowledged measurements.
5. Click **Start producer** once. Inspect the separate model-computation, LIFE
   admission, and Aegle-receipt states. Success requires committed model frames,
   actual admission, and acknowledgment—not merely an advancing graph.
6. Follow **Inspect in Biology** to the fixed execution/session. The displayed
   values are committed native samples with source hashes and timestamps.
7. Exercise pause/resume deliberately. Producer and LIFE consumer have separate
   controls: resuming LIFE does not start the producer. Hiding the browser pauses
   view polling, not explicitly started services.
8. Stop explicitly when finished, or observe completion. Keep the execution and
   session IDs privately. Reopen through the fixed-ID reader or **Read committed
   history**; this is read-only and does not resume computation.

Owner QA observed **121/121 committed frames with LIFE/Aegle acknowledgment**;
Video A retains a two-model-minute run, including pause at frame 34 and resume.
The [chapter guide](deliverables/2026-09-09-workflows/VIDEO_WALKTHROUGHS.md)
records its exact execution/session/source identities. That is a bounded software transport observation,
not physical-device equivalence, an insulin-treatment experiment, or a universal
frame-count guarantee. The current virtual path projects model plasma glucose;
it does not synthesize an interstitial sensor, ECG, physical calibration, or
unmeasured signals. Cardiac native state is ventricular-cell voltage/calcium and
has no LIFE projection here.

If source selection/version changes, expect the older execution to become
invalid/paused and its retained frames to be historical. New start/resume work
must reject; no different source may take over the old execution. Keep the
original history and prepare a separate execution only after inspecting the new
source. Opening a page or recalling History must never bypass this boundary.

## 7. First Cendos run: actual Human-GEM ATP capacity

The four bounded protocol families remain separate. The blank single-protocol
selector is implemented and independently source/test accepted: **81 passed**
in root's repeat (`4b6199`). One selected form is shown; New returns to a blank
choice and preparing a rerun restores the exact original protocol. Root then
accepted all four selector views, History → exact Human-GEM rerun preparation
with restored media/locked protocol, New → blank, and mobile blank/selected form
at 390×844. No protocol was executed for those selector checks. Video A is
delivered; the separate Cendos Video B also has an uncut original, MP4 and
actual-video chapters, accepted as bounded workflow evidence.
Opening Cendos or preparing inputs does not execute an experiment.

1. Open **Cendos Lab → Preparation**. In **Experiment protocol**, choose
   **Human-GEM · oxygen-capacity experiment**. Its **Human-GEM · oxygen-limited
   ATP capacity** form appears. If model or solver readiness is unavailable,
   stop and check installation status. An HTTP-healthy server is not model readiness.
2. Set glucose uptake cap `1`, oxygen caps `0, 1, 10`, and leave complete gene
   knockouts empty. Units are **mmol/gDW/h**, not blood glucose, oxygen saturation,
   milligrams of drug, or ATP concentration. No cohort is required.
3. Select **Run oxygen-capacity experiment** once. Wait for the worker result;
   do not submit repeated runs while busy. The model worker has its own bounded
   execution limit and does not turn a timeout into an assumed solution.
4. Inspect each solved condition, actual uptake, ATP-maintenance objective flux,
   solver status, mass-balance/bound residuals, and both negative controls.
5. Inspect provenance: pinned Human2 v2.0.0, model/software identities, directed
   stoichiometry and GPR annotations, and the declared objective/medium.
6. Download **analysis CSV** and **Jupyter notebook** from that result. Open
   **Visualize this run in Biology** and select recorded conditions. This is a
   stored steady-state result, not kinetic animation or another live-twin run.

The owner's actual September 9 computation for these inputs produced ATP
capacities approximately **2, 7, 31.5**, with the two negative controls **0**.
These are observed outputs of that pinned reference-network calculation, not
patient targets or results the UI is allowed to insert. Different inputs require
their own result. The protocol enforces stoichiometric steady state and bounded
fluxes; it does not establish unique internal fluxes, tissue kinetics, cell ATP
concentration, individual genome effects, drug response, or clinical validity.

The later recorded Cendos run is distinct:
`protocol-7ccfdf28cdca4a738cb4dbfa5ed7e857` used glucose cap **0.5** and oxygen
caps **0, 0.5, 5**, and returned ATP capacities **1, 3.5, 15.75** with actual
oxygen uptake **0, 0.5, 3**, respectively; both negative controls were **0,
passed** (root receipt `af7c9f`). Root inspected Biology conditions 0/1/2 and
provenance, then exact History → locked rerun preparation → New blank. These
are completed workflow observations. The delivered Video B retains this run;
the earlier run's exports do not contain this new result.

Complete knockout inputs accept exact model gene IDs and complete GPR-aware
knockouts, not a disease name, arbitrary drug, inferred variant activity, or
default fractional allele effect. Unsupported inputs must refuse explicitly.

Other named protocols keep their own limits:

- **Metformin cohorts:** reduced glucose–insulin/PK/PD hypotheses with recorded
  assumptions and frozen cohorts, not a Human-GEM or insulin-program substitute.
- **Purified garcinoic acid → PXR:** concentration-response/reference binding
  context, not a whole botanical mixture, liver kinetics, systemic benefit or
  safety finding.
- **Lobeline → VMAT2:** source-pinned initial-rate calculation in isolated rat
  striatal synaptic vesicles. It preserves the reported apparent-Km discrepancy
  rather than refitting it away. It is not a human/twin/cohort or LBHR validation.

## 8. History, reruns, exports and the meaning of time

**History → Recall** reads the immutable selected result. **Prepare rerun**
restores its configuration and parent identity but does not execute it. An
explicit Run creates a new result; the original remains unchanged. Inputs or
source differences require a new-configuration acknowledgment and must not be
labeled exact reproduction. **New experiment** clears the current view, not
stored twins, cohorts, or results. Ordinary page entry must not auto-recall or
resume a saved experiment.

| Time/value shown | Meaning |
|---|---|
| Continuous metabolic native time | Minutes in the selected model's declared initial/checkpoint context |
| Continuous cardiac native time | Milliseconds of ventricular-cell simulation, not a clinical ECG |
| Wall/model rate | Model seconds per wall second; a presentation/execution policy, not measured patient time |
| Generated/captured/acknowledged timestamps | Separate original producer, LIFE, and Aegle events; a refresh must not replace them with “now” |
| Recorded model playback | Selection of already stored model samples, not new physical acquisition |
| Baseline/treated | The same frozen model/member under the declared challenge without/with intervention, not unrelated people or an observed trial |
| Human-GEM, PXR and lobeline conditions | Independent steady-state/concentration/initial-rate conditions; no elapsed-time physiology is inferred |

Jupyter can be launched from this checkout's environment with
`./.venv-tester/bin/python -m jupyterlab --no-browser --ServerApp.ip=127.0.0.1`.
Review a downloaded notebook before running its cells. Exports and reanalysis
remain tied to their saved run and do not authorize live-twin calibration.
Do not paste Jupyter access URLs/tokens or private data into issue reports.

The owner retained the exact [Human-GEM notebook and CSV](deliverables/2026-09-09-workflows/human-gem-qa-export-receipt.md)
and actually executed the reviewed notebook (`43aacd`). The separate executed
copy preserves the original cell sources and contains the saved-result plot;
it does not rerun or independently qualify the solver. Three earlier automated
browser-download attempts were canceled. Authenticated HTTP retrieval succeeded,
but that does not turn the browser-download action into a pass.

For the later recorded run, the [export and source receipt](deliverables/2026-09-09-workflows/human-gem-recorded-export-receipt.md)
remains separate. After reviewing every cell (`40032b`), root used Jupyter Save
As and Run All Cells (`d1596a`) on a [separate executed copy](deliverables/2026-09-09-workflows/human-gem-recorded-analysis.executed.ipynb).
Execution counts1/2, the stored-result plot and no cell errors were observed
(`4ca89d`, `e37c7f`, final plot `922cc9`). Jupyter subsequently autosaved the
original-name file's kernel metadata, changing its bytes to SHA256
`50d74a84e395a886110cfd2600866c8f550f5343f9f1b21add46aac77eab6eea`.
That file is preserved, not overwritten. Root reacquired the exact HTTP response
under a [new immutable-original filename](deliverables/2026-09-09-workflows/human-gem-recorded-analysis.http-original.ipynb),
SHA256 `44444ad9ef40956cc3b20dff8de0158445bd9936b04737ea1b642c5f7988045f`
(`7ad6f1`). Full JSON comparison (`911eca`) confirms the original-name file
differs only in kernel display-name/language metadata: all cell sources,
outputs, execution counts, IDs and cell metadata remain equal. Do not call the
original-name path continuously byte-unchanged. The
executed-copy SHA256 is
`d1ac911784d59316b5109dd6e25a5172593130571a213e962846af87b7b1e55f`
(root `1bb5a5`). This verifies and plots stored results; it is not a new solver
execution or independent biological qualification. Video B's separate media
review is complete and does not grant broader scientific acceptance.

## 9. Stop, resume and preserve data

First stop any active producer/LIFE session through its explicit controls when
possible, then press **Ctrl+C in the foreground review-launcher terminal**.
The launcher terminates and waits for its owned service children, escalating
only for a child that does not settle within its shutdown bounds. Do not use
broad process-kill commands or `livemore stop all` against a separate installed
deployment.

To revisit saved records, relaunch with the **same** `--data-dir`. Starting
without it creates another blank review root; it does not erase the earlier one.
Reopening stored History does not resume computation. An interrupted execution
may remain interrupted and must not silently claim completion or restart itself.

For backup, stop the evaluation first and use an approved private backup method
to preserve the **whole data directory**, including encryption/signing keys,
databases, journals, immutable run files, and receipts, with owner-only access.
The keys are sensitive and necessary to read encrypted records. Do not post the
directory, copy only one live SQLite file, or delete keys to “reset” the app.
Restore into a separate private directory and check it before use; a tested
production disaster-recovery procedure is not claimed by this guide.

If you need a clean screen, use a new isolated directory. If assets or records
are corrupt, preserve them and the failure; do not delete/recreate them in place,
alter hashes, or substitute another model to manufacture a pass.

## 10. Troubleshooting and a useful tester report

| Symptom | Safe next step |
|---|---|
| Port already occupied | Keep the existing service intact; choose another unused consecutive triple and its matching Aegle URL |
| Wrong/old UI | Confirm checkout and Python paths; close the old origin and open the printed review URL. Do not infer source identity from a branch label |
| Authorization/session error | Check the same loopback origin and launcher health; reload its normal bootstrap. Never paste a token or disable auth |
| Missing Human-GEM | Check `LIVEMORE_MODEL_DIR` against the launched data root; explicitly install/check the pinned model there |
| Model integrity/download error | Preserve the exact typed error and package; report it. Do not remove hash/size checks or silently choose another source |
| Native compiler/library error | Report host/Python architecture and the failing dependency; do not describe the cardiac/native engine as ready |
| No execution source / binding required | Register and activate an eligible research-model record. A preview or descriptive reference population is not eligible |
| Source changed / stale execution | Inspect retained History; new work requires a new frozen source. Do not resume the old execution against another twin |
| Structure/anatomy unavailable | Retain the target/source ID and visible error. Numerical/reference cards may still be inspectable; a rendering failure is not a pass |
| Cendos busy/failed/timeout | Wait for the current bounded attempt to settle and retain its result. Do not launch a retry loop or reinterpret a failed result as successful |
| Physical-v3 controls unavailable | Expected current boundary: complete registered-lineage physical onboarding is not supplied by this form; no API/SDK bypass is promised |

A report should contain: owner-supplied snapshot identity; OS/architecture and
Python version; page path; exact non-sensitive steps/inputs; expected and observed
behavior; visible typed error; whether the data root was fresh or reused; and
the relevant opaque run/execution ID in the approved private channel. Screenshots
must exclude credentials, private filesystem/user details, personal records and
unrelated browser tabs. Include failed controls and missing data, not only the
best-looking graph. Never send the private runtime directory itself by default.

## 11. Evidence at this checkpoint, not a release certificate

Owner-reported actual QA includes nine Atlas layers, seven ordinary Biology
organs, local hERG READY, the 121/121-frame LIFE/Aegle exercise, and the Human-GEM
result above. The 24-slide
[technical product brief](deliverables/technical-product-deck/README.md) is a
dated communication artifact, not scientific qualification.

Root's completed pre-legacy-correction non-network regression (`305bb1`) had
**6,396 passed, 44 skipped, 5 deselected, 5 warnings, and 95 subtests passed in
399.57 seconds**. This is a completed broad checkpoint, not a claim that skipped
native/source opt-ins or network cases passed. The earlier **6,338 passed,
9 failed, 43 skipped, 5 deselected** sweep remains historical. Its nine
test-fixture/contract corrections passed **243/243** before this broad repeat.
The molecular vendor-bundle wheel correction also passed its real wheel test
and independent source review. Root's `pip check` found no broken requirements
(`15ffd6`); pre-correction `compileall` and diff-check receipts passed (`07b205`,
`e066df`). These checks do not remove the stated scientific and native blockers.

The `305bb1` run retained only the aggregate summary, not an individual `-rs`
skip ledger. Its exact 44-case attribution is therefore **unverified**. Source
declares explicit Beard source/conversion/native, continuous-cardiac,
pinned-genome-model, official-download and retained fake-worker-byte opt-ins,
plus conditional interpreter/platform and Node/pandas/FastAPI availability
skips. These are source-declared possibilities, not an observed per-reason
breakdown. No tests were rerun for this documentation audit.

Root's subsequent full `-rs` repeat (`7c4a53`) completed after the legacy
correction and before the Atlas search correction: **6,404 passed, 44 skipped, 5 deselected, 5 warnings, and 95 subtests
passed in 405.85 seconds**. This result has an actual skip ledger, retained by
root in the [final receipt](solutions/2026-09-09-final-browser-and-regression-receipt.md).
Its exact 44 skipped cases are:

| Reason in the completed pre-Atlas run | Cases |
|---|---:|
| Beard explicit source/conversion/native opt-ins: conversion 13, MathML 4, native worker 13, source contract 1, source execution 1 |32|
| Continuous cardiac native opt-in |2|
| Official model-download opt-in |1|
| Retained fake-worker stdout not explicitly selected: six observation tests and one parent-envelope test |7|
| Pinned stoichiometry integration opt-in |2|
| **Total skipped, not passed** |**44**|

The five deselections remain separate from these skips. Installing Human-GEM
assets does not enable every integration opt-in. The retained fake-worker cases
check technical bytes, not solver qualification. This software regression does
not establish that all native engines or the six scientific programs work.
The final current-source `326dcfaf…` full repeat (`a1c8cc`, session81481) then
completed: **6,416 passed, 44 skipped, 5 deselected, 5 warnings, 95 subtests
passed in402.88 seconds**. Its actual `-rs` ledger has the same exact44-case
reason/count breakdown shown above. The additional12 Atlas cases are included
in6416, not separately added again. The exact final command and ledger are in
the final receipt. This is software regression, not all-native or scientific
qualification; the earlier6404 result remains the pre-Atlas checkpoint.

The [secondary-page browser audit](solutions/2026-09-09-secondary-pages-browser-review.md)
checked Research's four sections and Knowledge on the earlier startup build.
Its legacy `ALIVE/live/REAL STATE` wording and incorrect Atlas highlight were
subsequently corrected in seven source lines. Root independently repeated
**155 tests** (`c93fb6`) and accepted the actual desktop/More/mobile correction
on `da7673ba…`: model wording and only Advanced console active at `/legacy`.
This closes those reported defects, not broad legacy UI qualification. Sources/LIFE
Data/V&V were not discoverable through the earlier observed More menu
and were not guessed or claimed tested. The mobile Research content fit, but
full navigation/accessibility/responsive acceptance was not established.

The [first direct .NET native result](solutions/2026-09-09-direct-dotnet-native-first-result-review.md)
is **FAILED / INSPECTOR_AMBIGUOUS_ROW** at PRE_XML. Worker and inspector settled;
S01 received no ACK and S02–S17 did not run. The retained map-format/admission
and managed-loading questions require a complete reviewed correction, not an
allowlist patch/retry loop. Model admission remains false. This does not complete
the native engine, insulin, or any of the six programs.

Root's final Cendos browser checks passed on `69a8c90e…`: all four protocols,
exact rerun preparation (`3c4593`), New → blank (`61eb91`), and mobile
Human-GEM selection (`235477`; document width 380, viewport 390, `f682c8`).
Cendos page errors were empty (`1d2f4b`); the shared console contained earlier
Jupyter debug messages, so no globally clean-console claim is made. Root viewed
the three retained Cendos screenshots. They and the three corrected legacy
screenshots are retained byte-for-byte in the
[final browser/regression receipt](solutions/2026-09-09-final-browser-and-regression-receipt.md).
The uncut [Video A MP4 and chapter guide](deliverables/2026-09-09-workflows/VIDEO_WALKTHROUGHS.md)
are delivered: 9:11.1, both original and derivative fully decoded, with exact
model/stream/source boundaries. Root also viewed the three representative MP4
frames. [Video B](deliverables/2026-09-09-workflows/02-human-gem-cendos-analysis.mp4)
is also delivered: 7:14.7, original WebM preserved, one MP4 transcode, both fully
decoded; root inspected three MP4 frames and accepted the scoped media evidence
(`28e630`). Its chapters retain the brief earlier-QA notebook transition and
inactive Run menu, not edited out. Final whole-product visual acceptance,
R40's six scientific-program recordings and R41 acceptance remain open.
Publication / reviewed feature PR (**R50**) is **NOT DONE**. Earlier failed native/browser evidence
is not relabeled, and none of the six scientific-program validations is done.

Final bounded operations checks: root verified all three review-service health
responses on source `326dcfaf…` (`05cff7`, `542c3c`, `89640d`), left the isolated
review stack on ports8868–8870 **running**, closed its owned browser (`9e966b`),
and stopped owned Jupyter; no listener remained on Jupyter8873 or tracker8865
(`327817`). Current `compileall` (`5b840f`) and diff-check (`9d556d`) passed.
These are service/artifact checks, separate from the completed final
full-suite result and still-open scientific gates. The additive README handoff pointers
also received independent read-only review, including59 link checks; no
publication or installed-release claim follows.

For an authorized software verification on a tester machine after setup:

```sh
LIVEMORE_TEST_MODEL_DIR="$LIVEMORE_REVIEW_DATA/models" ./.venv-tester/bin/python tools/run_review_tests.py -q -rs -p no:cacheprovider -m 'not network' --maxfail=10 livemorebio/tests
```

The runner creates separate private test stores rather than contaminating the
evaluation's subjects, experiments or credentials; the explicitly supplied model
cache is used for model-readiness tests. The `-rs` option above is for a future
authorized run to retain individual skip reasons; checkpoint `305bb1` did not
use it. Save the complete summary including failures, skips and reasons. A passing software suite is not a human/physical
validation result. Do not run tests concurrently with a recorded evaluation or
native qualification on the same host without coordination.

### Guide verification and limitation

The author read the actual launcher, dependency declarations/lock, asset-manager
CLI, isolation tests, capability manifest, execution controls and current Cendos
forms. Read-only CLI help confirmed both documented argument shapes on Python
3.11.15. The unchanged launcher-isolation suite passed **22 tests in 0.58s**
(`4dad43`), using isolated stores, without starting a review stack. No fresh
dependency install, model download, native solver, browser, or new service launch
was performed to author this guide. Owner QA observations are attributed above;
the guide itself is not independent repetition of those runs. The final status
update used read-only receipt/source review only, with no tests, collection,
notebook/model execution or browser operation during root's recording work.
