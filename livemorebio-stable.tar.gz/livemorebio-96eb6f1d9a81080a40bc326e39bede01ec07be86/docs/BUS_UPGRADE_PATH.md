# Event bus — current design and the NATS/MQTT upgrade path

Status: **documentation only.** The file-backed bus is the shipped design; the
broker upgrade described here is deliberately *not* built yet. It becomes
warranted when any trigger in §3 fires.

## 1 · What ships today

`livemorebio/bus.py` is a file-backed pub/sub layer under `~/.livemore/`:

- `events.jsonl` — append-only event log, trimmed to the last 500 events.
  Each event is `{ts, source, type, payload}`, and `type` follows the versioned
  vocabulary in `livemorebio/events.py` (`pillar.subject.action.vN`, blueprint §16).
- `snapshots/<key>.json` — per-key shared state (e.g. the current twin snapshot),
  written atomically (`tempfile` + `os.replace`) so readers never see torn writes.
- Consumers *poll*: the consoles and the SDK read the tail of the log over the
  services' HTTP APIs; Cendos reads the twin snapshot to assay the same twin
  Aegle is running.

In Docker (`docker-compose.yml`) all three services mount the shared
`livemore-state` volume, so the same file bus spans containers unchanged.

Why this is the right v1: single-box and single-volume deployments are the only
supported topologies today; the bus has zero operational dependencies, survives service
restarts, and its append-only shape matches the platform's audit-first posture. When the
launcher configures the storage key, event and snapshot records are AES-256-GCM envelopes;
inspect them through authenticated service APIs rather than treating the files as plaintext.

## 2 · What a broker adds, and which one

| concern | file bus today | with a broker |
|---|---|---|
| delivery | poll (~seconds latency) | push (ms latency) |
| topology | one host / one shared volume | multi-host, cloud, devices |
| fan-out | every consumer re-reads the log | per-subscriber streams |
| history | last 500 events | configurable retention/replay |
| backpressure | none needed at current volume | flow control built in |

**NATS (with JetStream) is the intended service-to-service upgrade.** Subjects
map 1:1 onto the existing versioned event names (`aegle.twin.updated.v1` is
already a valid NATS subject), JetStream gives the durable, replayable log that
`events.jsonl` provides today, and a single small binary keeps the
zero-heavy-ops character of the platform.

**MQTT enters only at the hardware edge.** The LIFE Patch (docs/hardware/) is a
constrained wearable device; MQTT 3.1.1/5 over TLS is the field standard there.
The patch publishes to an MQTT ingress topic and a thin bridge republishes onto
the NATS subject `life.patch.telemetry-admitted.v2` — MQTT at the device edge, NATS inside
the platform. MQTT is *not* used between LIFE/Aegle/Cendos.

## 3 · Triggers that justify building it

Build the broker layer when the first of these becomes real, and not before:

1. services must run on **more than one host** (no shared volume possible);
2. **physical LIFE Patch units** stream telemetry from outside the box;
3. a consumer needs **sub-second push** (live console streaming at scale);
4. event volume outgrows the 500-event trim window in normal operation.

LIFE Patch v2 already has transport-neutral payloads and a durable telemetry journal.
The current single-host route journals first, immediately forwards to Aegle, and publishes
`life.patch.telemetry-admitted.v2`; Cendos reads the same admitted snapshot. A forwarding
failure leaves telemetry durably journaled rather than losing it. Automatic replay/drain is
still pending and must be added before a distributed or intermittently connected deployment.

## 4 · Migration plan (when triggered)

The event vocabulary is the contract; the transport is an implementation detail.
That is the point of `livemorebio/events.py`.

1. Keep `bus.publish(source, type, payload)` / `bus.tail()` / snapshot API as the
   only surface the services touch. Introduce a transport switch
   (`LIVEMORE_BUS=file|nats`, default `file`) inside `bus.py` — no call-site changes.
2. NATS mode: `publish()` → JetStream publish on the subject equal to the
   versioned event name; `tail()` → ephemeral consumer over the stream;
   snapshots → NATS KV bucket (same per-key semantics as `snapshots/`).
3. Mirror every published event into `events.jsonl` for one release (dual-write)
   so audit tooling and the consoles keep working while consumers migrate.
4. Add the MQTT→NATS bridge only alongside real patch hardware; the bridge
   validates payloads against the `life.patch.telemetry-admitted.v2` contract before
   republishing (provenance flags preserved).
5. Compose: add a `nats` service to `docker-compose.yml`; the `livemore-state`
   volume remains for audit logs, signing keys, and the LIMS/evidence SQLite
   stores — those are not bus concerns and do not move.

Invariants that survive the migration: versioned event names are never
repurposed (new shape ⇒ new `vN`); only real engine state flows on the bus;
pharma-facing result pipelines still emit their local HMAC `livemorebio.audit`
integrity record independent of transport. Governed evidence-package signing is
a separate lifecycle.
