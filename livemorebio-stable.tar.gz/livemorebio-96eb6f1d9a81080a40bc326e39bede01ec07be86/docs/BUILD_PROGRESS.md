# Build progress board

**Disabled at the user's request on 2026-09-09.** The owned server was stopped,
port8865 has no listener, and all three tracker tabs were closed. Saved progress,
source and evidence are preserved. Do not restart it unless the user asks.

The local build tracker used `http://127.0.0.1:8865/`. It is separate from the
Livemore product so development status does not clutter Aegle, Biology, Cendos or
LIFE. It reads no participant, experiment, device or credential stores.

For an explicitly requested future restart, use the recovery checkout:

```bash
python3 /Users/emman/Livemore/.worktrees/full-scope-recovery/tools/build_tracker.py --port 8865
```

This uses Python's standard library; it does not need an installation or API token.
Stop that terminal with Control-C. It stops the tracker only, not Livemore. If the
port is already occupied, first open the link above; do not kill an unknown process.
Use a different `--port` if another known application owns that port.

## How to read it

- Calendar elapsed starts at 2026-09-09 12:57:59 UTC, the start of this tracked
  phase. It is not historical project time, active agent time, an estimate to
  completion, or biological time. It continues while the page is open.
- Last saved update and its age show how current the manually published progress
  is. Five minutes without an update is explicitly marked overdue. The board
  does not monitor agents and cannot prove they are still working.
- Current work identifies the checkpoint's review/build lanes. Verified increments
  are separately tested changes, not automatically completed broad requirements.
  Remaining work includes partial implementations and external blockers.
- The complete R01–R51 table is read directly from the September 8 approved master
  register. Only ACCEPTED closes a requirement. A row marked OPEN can contain
  substantial implemented work; see its related workstream for that distinction.
- Six experiment walkthroughs (R40) and the separate ecosystem demo (R41) are
  tracked separately. None is considered accepted merely because a video exists.
- A stopped turn is saved as Paused between turns. Neither the running timer nor
  the local web server implies that an AI agent continues building in the background.

## Updating and preserving progress

The build owner edits `tools/build_tracker/progress.json`, increments `revision`,
and records an actual UTC `updated_at`. Keep the phase start unchanged. Use
`working` only during an active build turn and `paused` at handoff. The board polls
saved progress every five seconds; updates do not require refreshing the page.
No browser control changes product data or marks work done.

Keep public engineering summaries only. Never add participant profiles, private
instrument files, credentials, restricted model content or secrets to this board.
On an invalid/missing progress source, the board reports unavailable and retains
the last good checkpoint. Do not call that cached checkpoint current.

Verification command from a development environment with pytest and Node:

```bash
python3 -B -m pytest -q -p no:cacheprovider livemorebio/tests/test_build_tracker.py
```

This verifies the tracker, not the biological infrastructure. Product validation
and release requirements remain in the full-scope register.

## Latest verified increments

- Navigation-first local session restoration: independently repeated 66 tests
  and ordinary navigation through all nine product pages. Detailed scope and
  remaining UI findings: [browser results](solutions/2026-09-09-navigation-first-browser-results.md).
- LIFE valid empty selection and read-timeout guidance: independently repeated
  34 tests, then fresh desktop/mobile source-read and explicit-reopen checks.
  No preparation gate was relaxed. [Evidence](solutions/2026-09-09-life-empty-selection-correction.md).
- Tracker: 14 tests independently repeated; extended 15-case suite subsequently
  passed, plus actual desktop/mobile interaction and saved-update checks.

The direct .NET scientific worker is a separate partial build. Compiling and
controlled fake tests do not make its parent/native connection operational or
establish human equivalence. Its live entry remains disabled while qualification
is incomplete. The full scope, six experiments and seventh ecosystem recording
remain on the board; no release has been published.
