# OSP declared-source graph: independent retained-evidence review

2026-09-08. Independent reviewer: `release_redteam`; root authored the nonfinite
amendment and second static invocation. **Accepted as complete declared-XML graph
evidence for the pinned source. No numerical or biological admission.** No
source-to-report mismatch or remaining blocker to that bounded static claim was
found. The earlier finite-literal static FAILED receipt and original Stage B
numerical FAILED result remain unchanged.

This review read the complete result note, approved static proposal/addenda,
relevant implementation source, and retained source/domain audit. It then checked
the actual report against the original XML and three original domain ledgers
using a separately authored standard-library checker. It did **not** import or
invoke `osp_source_admission`, create a third source-admission report, evaluate
an equation, construct/import an OSP/native runtime, open an execution gate,
run a solver, contact the network, or access an operational store. No product,
source XML, old result, scientific criterion or runtime file was edited.

## Exact evidence and reproducible method

The reviewed report is
[retained report.json](/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-osp-static-review-4s3eumay/osp-source-admission-v1-3819ef03ab124bc7a9bd220255755526/report.json).

| Artifact | Independently verified identity |
|---|---|
| Retained report | 31,567,123 bytes; SHA256 `7bf6f4a9c125d26338bd08d39ae1b9656a0d125fa18bccd3dc79a8dfb033fac6` |
| Canonical report content, excluding its own digest | `d78c4e8fa3c8112495b4196a28a7e77620e59752a597367c6cdf225d5cbf0b54` |
| [Original XML](/tmp/livemore-osp-source.fmi3LG/GIM_Healthy.xml) | 7,477,881 bytes; `e78bb23d39ce7138f46bb876a54b43becb79bbf833e50c0cd7006f2a80eac3cb` |
| Reviewed generator, read but never imported | `f6b5d2daf5d90c5b6949ae35f2089fd75a12b2b935e060b7ac96ce8ead321821` |
| Reviewed generator tests, not rerun in this evidence audit | `80f373e9234e3c73dc0c9dce14aee420f3c4e135e4560bfbcc16bd0972ed157c` |
| [Independent read-only checker](/tmp/livemore-osp-independent-graph.wYvKBp/verify_retained.py) | `9fb445cceb5b2f43c5e2171805a4bbc1407336acb11b5e832a554aa3f46be155` |

Exact final checker invocation:

```text
/Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B /tmp/livemore-osp-independent-graph.wYvKBp/verify_retained.py
```

The first checker pass completed in 3.162 seconds. A final read-only pass, adding
explicit all-27 pair/table/flag and all-15 reference-unit assertions, completed in
2.880 seconds with exit 0. These are evidence-audit durations, not native-model
performance evidence. The checker uses a 60-second alarm, rejects duplicate JSON
keys/nonfinite JSON constants, pins inputs before parsing, and installs an audit
hook refusing socket/subprocess/exec/spawn/native-library loading. Its final
module check confirms no generator, product or model modules were imported.
It prints bounded audit summaries, not a new model report. Temporary evidence
paths are retained local artifacts, not an archival-retention guarantee.

The independent method constructs XML positions and parent links directly from
the original element tree. It compares complete node dictionaries and complete
typed edge occurrence dictionaries, not only counts. It separately recomputes
reachability, first-discovery predecessor indices, shortest depths and all output
sets from the source-matched edges. Thus a correct digest of an incorrect graph,
a missing duplicate-target occurrence, a reversed edge, or a disconnected
predecessor cycle would not pass this check.

## Source-to-report accounting

All 113,891 XML elements were counted, maximum element depth 5, with the exact
namespace/version/path delimiter preserved. All 28,683 graph nodes match:
28,636 direct definitions, 39 assignment nodes, seven solver-setting nodes and
one explicit builtin Time node. Complete attributes, source IDs, entity IDs,
names/paths, units, literal strings, source locations, ScaleFactor, formula text
and SHA256, table points and flags match the source. No numeric coercion of NaN
or other source literal was used.

Every one of the 64,564 source-derived typed edge occurrences matches its report
dictionary, including owner, ordinal, alias, XML location and both typed endpoints.
No referenced ID overwrites a definition, and no endpoint is missing.

| Edge kind | Exact occurrences |
|---|---:|
| Declared reference, including 277 builtin Time references | 50,446 |
| Parameter formula | 8,536 |
| State RHS | 3,917 |
| Observer formula | 1,475 |
| Event condition | 33 |
| Event to assignment | 39 |
| Replacement formula to assignment | 39 |
| Assignment to target | 39 |
| Initial formula to state | 27 |
| Table binding | 3 |
| Offset binding | 3 |
| Solver binding | 7 |

The seven solver references and literal output interval match. All three tables
retain their exact 326/326/31 point rows, `useDerivedValues=1` and every
`restartSolver=0`; all six exact Table/Offset links match. All 33 events retain
`oneTime=1`; the 39 assignments retain 23 mode-0 and 16 mode-1 declarations.
The 15 explicitly negative-disallowed states remain `negativeValuesAllowed=0`;
the other 1,085 states keep that attribute absent. These checks preserve declared
structure, not native interpretations of those flags.

## Roots, traversal direction and witnesses

All three pinned domain-ledger hashes match. Their negative record/unique-entity
counts remain I2 14,025/26, T2 2,840/15 and C2 2,814/14. The union contains exactly
27 unique source V entities; its canonical sorted-ID digest is
`dac7a910d23a22ce193566f7497e5b8e0687c62f1ad07b2e9dedfb8511e42d81`.

All 104 independently identified root-role records match: 54 initializer-role
records, 27 negative-state roots, 15 restoration roots and eight context roots.
This means 77 forward possible-influence traversals and 27 reverse initializer
dependency traversals, not 104 distinct source nodes.

For **every** traversal, reached node/edge counts and sorted-set digests, all
predecessor entries, reached state-RHS targets, event/assignment nodes, assignment
targets and leaf records match the independent recomputation. All 488,255
non-root predecessor entries have the proper edge orientation and a parent at
exactly one smaller shortest-path depth. This proves each retained forest path
terminates at its own root. The longest witness contains 94 nodes, below 30,000.
Aggregate visited root/node pairs are 488,359; examined root/edge pairs are
792,972, within the unchanged 4,000,000/10,000,000 bounds.

Reverse traversals use only reference, parameter-formula, observer-formula,
initial-formula, table-binding and offset-binding edges. RHS and event writes
are excluded from initialization dependencies. Each of the following exact
V/formula pairs has its own reverse record; **all 27** explicitly have an empty
`unresolved_source_inputs` list:

```text
3376/3393   3593/3608   3792/3820   3972/3996   4174/4185
4355/4381   4549/4570   4753/4764   4941/4950   5134/5144
5322/5333   5518/5523   28279/28280 28302/28303 28325/28326
28347/28348 28369/28370 28392/28393 28415/28416 28438/28439
28461/28462 28484/28485 28507/28508 28530/28531 28553/28554
28591/28592 28614/28615
```

These closures have 5–43 nodes, 4–42 edges and 2–20 explicit leaves. Empty lists
mean none of the 56 specifically unresolved P declarations occurs in these
declared reverse closures. They do **not** establish native initializer ordering,
event/reset behavior, implicit runtime dependencies, finite downstream values,
all-state continuation or an executable model's complete numeric inputs.

## Nonfinite declarations and 17 assertion witnesses

All 56 original P.value strings `NaN`, IDs, units, source locations, classification
tags and their complete direct outgoing occurrence lists match the XML. Exactly
28 declarations have consumers, totaling 98 declared reference occurrences;
the other 28 have no outgoing declared edge. The canonical sorted ID digest is
`9ac9d5010ab0ca2748efcb88f5b60ff470e41c56196e174f957a57d2f634d999`.
No missingness value, benign-placeholder conclusion or numerical failure cause
is inferred. The report correctly keeps `numeric_input_completeness=false` and
`SOURCE_NONFINITE_LITERAL_UNRESOLVED` alongside the other three semantic flags.

All 17 conditional/non-admitting assertion witness pins match actual source:

- Fifteen exact restoration formula/state pairs are genuine direct RHS links.
  Every formula has identical original text SHA256
  `8999b9c94a6f2aa2356acb4552d4e4f12d9cc89381c78f7777818f33b6356b56`.
  Each destination state declares µmol and ScaleFactor 1; each formula references
  nine quantities declaring µmol/l and P786 `S_I`, literal 1 with no declared unit.
  The source expression itself has no explicit volume/time factor. The dimensional
  concern remains conditional on the unestablished `S_I` convention; no missing
  coefficient or intended repair is supplied by this audit.
- P10743 declares PTP as µmol, literal 1, and is the actual `PTP` reference in
  F11294/F11307. Their exact formula strings and all graph reference units match.
  A normalized-activity interpretation is not proved by the numerical literal 1.
- V10939/V10970/V10978 all declare µmol. The exact F10947/F10985 `f_2` references
  and F11158/F11160/F11161 multiplier references bind those states as recorded.
  Their annotation/convention issue is retained, not silently normalized.

The graph embeds formula text, hashes and metadata for the two latter witness
groups; their assertion rows do not contain separate formula-hash fields. The
independent full-node comparison verifies those embedded pins. This is not a
symbolic unit checker or proof of biological domains. Every assertion retains
`admitting=false` and its original conditional/unverified classification.

## Preservation and next necessary evidence

Thirteen pinned files had identical content hash, size and mtime before/after:
source XML; actual report; generator/test; original collector/native wrapper/
analysis/preregistration; three domain ledgers; old numerical summary; and the
453-byte first static FAILED receipt. The on-disk gate remains false. Historical
claims about the authorized caller's process-local gate closure belong to its
retained execution evidence, not a retrospective observation made by this audit.

The accepted result closes the declared-XML graph completeness gap. The next
scientifically necessary steps remain evidence decisions, not equation edits:

1. Establish exact native/author semantics for `oneTime`, both `useAsValue`
   modes, table interpolation/offsets, `useDerivedValues`, `restartSolver`, Time
   units, initialization and reset/continuation ordering. Declared links alone
   cannot resolve branch execution or implicit dependencies.
2. Determine the publisher/runtime meaning and actual use of the 56 NaN
   declarations. Preserve raw inputs and provenance; do not replace them with
   zero, plausible values or a new candidate source merely to obtain execution.
3. Resolve exact-ID domain/unit intent for all 15 restoration laws, PTP and
   hepatic multipliers, glycogen and salivary bookkeeping versus finite pools.
   An author-supported semantic mapping or new source-backed model contract is
   required; terminal reachability or a convenient label is insufficient.
4. Keep the original numerical failure and common-initialization attribution gap.
   Any new diagnostic needs a separately approved prospective matrix; a tighter
   solver or shared I2 initialization cannot repair source-domain uncertainty or
   retroactively pass the original benchmark.
5. Individualized insulin still needs formulation/potency/route/time and person-
   specific physiology plus independently held-out measurements. This historical
   reference graph supplies none of that qualification.

No new source acquisition, author contact, model correction, native execution or
experiment is authorized by this review. R33 exogenous insulin, erinacine A,
sterubin, carnosic acid, arctigenin and cyanidin 3-glucoside remain six separate
required, unqualified whole-individual programs; requested videos remain 0/6.
R01–R51 and other full-scope recovery requirements are not reduced.

**Lesson:** a graph can be independently complete while numerical inputs and
scientific interpretation remain incomplete. Verify source occurrence identity
and witness direction, then state exactly what an empty dependency set excludes.
