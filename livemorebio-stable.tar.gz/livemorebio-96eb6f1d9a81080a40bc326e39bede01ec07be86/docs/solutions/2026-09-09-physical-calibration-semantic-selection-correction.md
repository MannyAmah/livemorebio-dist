# Physical calibration semantic selection: explicit harness boundary

## Retained failure and diagnosis

This is a pre-code amendment approved by root after the second failed native
attempt, not permission to retry a browser. The investigation skill was applied
to both complete receipts, both original PNGs, the product submit handler, and
the actual harness. No browser, service, model, network or store was used in
diagnosis. Context7/gbrain/CE remain unavailable; installed primary library code
was read directly. No global skill state was changed.

Session77688, `/private/tmp/livemore-legacy-preview-aq_vroym`, failed D1 with
UNEXPECTED_REQUEST. D0 and blank native invalidity passed. The first
click→c→Enter sequence attempted one POST, blocked before forwarding; actual
mutations0. Choice observations were not reached. The failure image shows
Current and network-error feedback. Enter was therefore not a safe popup-only
commit in this observed interaction. The retained evidence does not establish
whether c alone committed the value, or every native popup transition.

| Original evidence | SHA256 |
|---|---|
| browser-result.json | `42c18871912079f880561d7d997f0af9e4d131de4657c072491422cd88f0ba3f` |
| supervision.json | `3fba6b649d8498c167efc2257a3f74baf9e462f69e65b760ecf14c53537264d1` |
| physical-desktop-open.png | `dd6265d358ffc298b5841f519d69182d54b1ed1347535d40e714a1316a5cd56d` |
| failure-D1-context-1.png | `215974adb105cf5549410eeb401892276f09ba561895b1311af1ed5bcf66ff7d` |

Page-1 cleanup remains UNCONFIRMED3002.3435ms. Later context/browser cleanup
settled; supervisor records all four children reaped, ten descendants absent,
no listeners. Root independently checked the14 PIDs/ports. These later facts do
not rewrite the earlier page-close result. Both failed attempts remain failed;
mobile is NOT_RUN. The new desktop-open image independently confirms only the
empty-strip and shortened-placeholder presentation corrections.

## Root-approved correction, before implementation

Change only the physical scenario in the existing two harness scripts and its
dedicated test. No product, CSS, controller, protocol-v2, registry or device edit.
The legacy default scenario, accepted16 images, budgets and allowlists remain.

Use the installed public `locator.selectOption({value}, {timeout:10000})` on the
actual `#physical-calibration` select, without force, after explicit real locator
focus. Values are the fixed existing Current/Due/Current desktop and
Current/Due/Failed mobile sequence. No click/typeahead/Enter choice sequence,
no direct value assignment, evaluate mutation, synthetic app event, retry,
popup work-around or new timer. This is semantic browser-form coverage, NOT
native popup-key selection acceptance. Native popup-key coverage remains open.

Pinned upstream evidence, read as local source only:

- `playwright-core/lib/client/locator.js:252` forwards strict selectOption.
- `lib/client/frame.js:345` returns the selected option array.
- `lib/server/dom.js:468–495` checks visibility/enabled unless force is used.
- `types/types.d.ts:14213–14302` documents exact value selection, returned array,
  actionability and input/change events.
- `lib/generated/injectedScriptSource.js` sets selected options and dispatches
  input/change. It is a library-mediated DOM selection, not an OS keyboard event
  or independent native popup proof. Product source remains unchanged.

All paths are under the installed
`/Users/emman/.agents/skills/gstack/node_modules/playwright-core/`.

Keep real blank submit and native validity, actual Due/Failed submit buttons,
Current non-submission, focus, Escape return and reopen reset. Same9 observations,
six choices, four screenshots, all POSTs blocked. Require unchanged invalid and
submit counters around each selection. The returned library value AND observed
actual value must both match; malformed return is retained as safe OTHER before
failure. Retain original immutable image/receipt evidence on failure.

Replace the misleading receipt `keyboard_choices` with `selected_values` and
declare `selection_method: PLAYWRIGHT_SELECT_OPTION` plus
`native_popup_keyboard: NOT_ACCEPTED`. Keep six `choice_checks`, adding only the
sanitized `returned_value` enum. CJS and Python admission both require the new
exact evidence and existing count/focus/source/cleanup guards. Old native
receipts are not migrated or retroactively admitted.

## Red-first verification and ownership

Update the existing workflow double to reproduce Enter submitting rather than
inventing popup commitment. Its documented selection seam returns the actual
selected array; key-based choice is a failure. The actual runner double must
implement only exact locator/options selection, not a separate successful path.
Retain unknown/uncommitted value, unexpected submit, focus loss, noPOST,
source/context, image coupling and cleanup negatives. Add malformed-return and
wrong/missing-method admission cases. Persist bounded evidence before assertions.
These authored tests verify orchestration, never native control behavior.

Use the existing isolated45s CJS/ESM Node-only refusal wrapper. Preserve all321
existing cases by approved semantic fixture migration, with additive boundary
tests only. Freeze hashes and RED/GREEN receipts for root independent review.
No actual browser run by the maker. A later explicitly authorized source-pinned
four-image semantic run is still required; the six-program/full-product and
full physical-v3 contracts remain open.

## Lesson

A fake popup state machine can make an incorrect native-input assumption pass
twice. Use the documented option-selection API for semantic form verification,
label that evidence honestly, and keep actual keyboard-popup verification a
separate unresolved claim. A blocked attempted POST is a failed test, not a
successful zero-mutation interaction.

## Frozen implementation and maker evidence

The84-case RED retained **12 failed /72 passed in6.38s**, private root suffix
`4fjl2b4z`, session69793 closed exit1; unexpected I/O0, Node71, Git0.
The shared workflow explicitly raised ENTER_SUBMITTED. The actual runner's
Enter path generated a blocked POST and UNEXPECTED_REQUEST, matching the
retained interaction boundary. Later cleanup/choice fault cases were masked by
that earlier failure, not independent demonstrations of their eventual branch.
The old keyboard-only receipt was accepted by the old CJS admitter. Valid new
semantic receipts were correctly red before the schema expectations changed.
Negative semantic metadata cases already passing at RED were masked by the old
missing-key mismatch; they became meaningful only with the valid GREEN control.

After the bounded correction: **84 passed in6.53s**, `woltln3d`, session7388
closed exit0; I/O0, Node72, Git0. The complete preservation matrix passed
**329 in32.96s**, `_46o9bk3`, session99200 closed exit0; I/O0, Node282, refused
Git1. No test process remains. This is authored technical evidence, not browser
or native option-selection acceptance.

329 = the original321 plus3 actual-runner malformed selection-return cases and
5 dual-admitter method/return/claim cases. Every preexisting case remains; only
the explicitly approved semantic workflow/runner/receipt fixtures were migrated.
The original174 legacy harness tests and71 product/recovery/intake tests are
unchanged. The actual runner must use exact locator/value/options and both
returned and observed values; malformed arrays are reduced to OTHER without
private text. Original failure evidence, action limits and POST blocking remain.

Changed-source review map:

- CJS227–230 checks both values; 274–300 contains the unchanged physical flow
  with supported option selection and explicit non-keyboard receipt admission;
  524–533 performs the actual locator operation and retains safe evidence.
- Python393–411 requires exact six typed records, the supported method and the
  explicit NOT_ACCEPTED native-popup claim. No supervisor/cleanup change.
- Dedicated physical test is315 lines. Same actual shared flow/runner exercised;
  no new test framework or actual Playwright import occurs in offline tests.

| Frozen file | SHA256 |
|---|---|
| tools/check_legacy_preview_browser.cjs | `3e9763a82d715fe5eab26c307d5f005197abac9ced2b0f9552d43200b0f2d829` |
| tools/check_legacy_preview_browser.py | `9b072ef1534f1d7fa4fd1a124f4d654d449ce3ed726030d891b5bc1bd2a4f198` |
| livemorebio/tests/test_physical_calibration_browser_harness.py | `bec75adb2baee435160f42c02070c6db3305c82f542b84670c940b694b4ce933` |
| unchanged twins.html | `69afbfb72fdbed33444667941a5ea2a4ff1555d23dbccf64da9e40c88d27200e` |
| unchanged lib/subjects.css | `4a4a8d5d209fe10e4026679202ef39a85e188d3c3fb29a07233c5d415db8fb21` |
| unchanged lib/subjects.js | `b35b6aa4e1277eef95ac128ff64f93d874cfb589d3d992c7554927f1f001e95a` |
| unchanged test_physical_pairing_calibration_ui.py | `fd9ef80a15a7d86bbfad0f7821c3f750b6cfd977e93b57653fa815dd013354c9` |

Independent reproduction uses the exact private45s CJS/ESM refusal-wrapper
command already recorded in
`2026-09-09-physical-calibration-native-commit-correction.md`, section
“Exact independent repeat”, with the identical seven test-file arguments. It
now selects329 cases. The isolated Python is
`/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python`; only exact authored Node
evaluation children are permitted. No browser/native/HTTP/operational stores.

Await root independent source/test review and separate actual-run authorization.
The maker has launched no browser. Desktop and390px semantic validation, populated
local rejection feedback and all four actual images are still pending. Native
popup-key selection remains NOT_ACCEPTED even if a later semantic run passes.

## Independent review and one fresh semantic-run decision

Root read the complete160-line report,315-line dedicated test and every changed
CJS/Python admission and workflow section. Independent exact preservation
repeat:329 PASS33.51s, session84228, private sjc1lz8z, I/O0/Node282/refused Git1.
No product change is included. Returned values and actual observed values/focus/
invalid/submit counts are required together; sanitized failure evidence survives.

Authorize one fresh source-pinned four-image semantic physical-calibration run
after the coordinated runtime freeze. Retain desktop/mobile originals, all nine
checks, six selections and complete source/cleanup receipts. All POSTs remain
blocked; there is no real participant, real device or biological execution.
Native validity and local rejection are tested; OS popup-key behavior remains
NOT_ACCEPTED. Both earlier failed native roots remain failed, untouched.

## Actual semantic browser result — bounded pass

Fresh session68982, `/private/tmp/livemore-legacy-preview-haagy7pu`, completed
in8.896793417s with no primary, cleanup or evidence failure. Runtime source
bd31cec7605d8004d442fb7b1b865f5e258d83c2a89de529857feb5ae57ba126 matches
all three private services before/after. Original browser receipt SHA256
08050dfea801c95ac895260b5e96d326b0cd0404a8d161064836762ecb65cb97.

All nine observations and six exact semantic choices passed. Blank calibration
raises native invalidity without submit; Due/Failed show associated local
rejection; Current selection does not submit; Escape returns focus and reopening
clears declarations. POST attempts0, actual mutations0, actual state reads4,
auth bootstraps2. All five browser cleanup operations settled; four direct
children reaped,14 descendants absent. Root independently checked all18 PIDs
and8910–8912 listeners absent. No real participant/device/model was involved.

Root read both complete receipts and viewed all four original PNGs. Desktop
and390px mobile placeholder, selection and rejection copy are legible, without
horizontal overflow or hidden target feedback. Mobile rejection is a scrolled
dialog viewport, not proof of every scroll position or whole-product design.
This is semantic form/native-validity acceptance only, not native popup-key
acceptance, physical-v3 onboarding, biological equivalence or a six-program demo.

| Original image | SHA256 |
|---|---|
| physical-desktop-open.png | dd6265d358ffc298b5841f519d69182d54b1ed1347535d40e714a1316a5cd56d |
| physical-desktop-rejected.png | 0ab30275435f44a9eefb4f4460d7802f6f5b9a568baff741ddc3f2c54f13fec5 |
| physical-mobile-open.png | df164ac774ff273ba10004d4898f7f9675a8c9aba87835f3cd2b528092160173 |
| physical-mobile-rejected.png | 07d533a93dfa726e418795eff34e47fde89cd9b768ef93f6f907080b4875a22a |

## Independent retained-original QA review

The independent reviewer read both complete original receipts, individually
viewed all four unmodified PNGs and independently rehashed them and the receipts.
Browser receipt `08050dfe…` and all four image hashes above match; supervision
SHA256 is `ddec7c1960a51f6e30747ddd79df07c8e598f44a39b5721085852cb0353fea88`.
No additional browser or OS query was performed for this review.

No actionable blocker was found for the declared semantic form slice. The
desktop and390px initial views show a legible unselected “Choose status…” and no
empty orange feedback bar. The Due desktop and Failed mobile views visibly
retain the selected value, calibration focus and readable local rejection.
Receipt evidence agrees with the nine observations, six supported selections,
zero POSTs and five settled browser cleanup operations. The recorded process/
listener absence is retained supervisor/root evidence, not a new reviewer probe.

The mobile rejection screenshot has scrolled its dialog contents: the top close
control/header are partly outside the dialog's internal viewport, while the
calibration and rejection targets remain readable. This is not full-dialog or
all-scroll-position acceptance. Native popup-key selection remains NOT_ACCEPTED;
pairing success, physical-v3 onboarding, hardware/clinical validation and the
larger product matrix remain separate gates. Both earlier failed roots and their
page-close uncertainty are preserved without reclassification.
