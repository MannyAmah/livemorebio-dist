# Legacy current-feedback browser harness — frozen implementation review

Date: 2026-09-09. Maker: ui_audit. This is harness-only technical evidence,
not actual browser, physiological or whole-product acceptance.

## Approved scope and ownership

Implements the seven-checkpoint/two-image extension appended to
`2026-09-09-legacy-current-feedback-correction.md`, approved by root after
independent product review. Only the existing Python/CJS harness, its two
preserved fixture files and one new dedicated test file changed. No page,
controller, cache, coordinate, vendor, model, registry or service source changed.
No actual browser, HTTP, listener, service, native or numerical process ran.

The original D0–M2 seven cases and four exact authored POST deliveries remain.
Their original14 image names are an ordered subsequence. Exactly
`desktop-cardiac` after desktop-later-winner and `mobile-cardiac` before
mobile-error are added, yielding16 images. The stock writer retains the same
AUTHORED UI ONLY captions. Original five banner rows and all original schedule,
cookie, source, health, request, response-body and cleanup checks remain.

Nonimage bounds remain startup45s, browser180s (159s work plus21s cleanup
reservation), outer350s, action10s, held fresh-read2s, requests256, POSTs4,
4MiB per PNG and64MiB total evidence. There is no new provider request, route,
fixture, timer, hold or transport-completion wait.

## Implementation

The real serialized `readFeedbackSnapshot` reads only the three fixed label
nodes and the retained banner node. It exports observed category
computed/pending/unavailable/OTHER, fixed-copy/class/title predicates,
identity/hidden/empty predicates and bounded geometry, never arbitrary text,
input or clinical state. The original six clearing predicates remain in its
same evaluation and same two-RAF wait at pending/unknown checkpoints.

All seven rows are retained before their assertion. The Python and CJS
admitters require their exact order, modes, info-versus-hidden expectation,
viewport and true predicates. The three clearing checkpoints additionally
require all and only the original six true flags: empty objects, missing
flags, false flags or unknown replacements cannot stand in for clearing.

Only the two computed heading captures request geometry admission. A fixed
serialized scroll aligns the existing cardiac heading below the measured
sticky navigation, with instant native scrolling and no DOM/CSS mutation.
All three label rectangles must fit completely, be finite and positive, and
be below the nav, with no horizontal overflow. A native hit is taken in a
real inline text fragment instead of potential wrapped bounding-box whitespace.
The image path does not scroll again. Image feedback ID, viewport, scroll
and first-label bounds are bound to the admitted row in both final readers.

A failed checkpoint retains its snapshot, active case failure and original
failure-image/NOT_RUN/cleanup bookkeeping. No failed current-feedback case
can continue to a later authored POST. The original early-action/lateness/
owned cleanup guards are unchanged.

## Red / green receipts

1. Initial new27 RED: **27 failed in2.07s**, private suffix `9xa2ra4e`,
   exec session67077, exit1; external I/O0, Node21, Git0. Missing reader/
   admitters and old14-image admission are the expected failures. Negative
   helper tests first require a valid snapshot, so a missing helper cannot
   masquerade as a successful rejection.
2. Initial combined GREEN: **150 passed in11.21s**, private `4r0nwfzg`,
   session42944, exit0; external I/O0, Node101, Git-refusal1.
3. Final receipt review added four REDs for missing/empty/false/extra original
   clearing flags at each of the three fixed checkpoints. **4 failed,
   27 deselected in0.48s**, private `0zuc9chz`, direct exec exit1; I/O0,
   Node4, Git0. Existing browser work already asserted clearing; the defect
   was final admission not independently requiring the retained flags.
4. Frozen final matrix: **154 passed in12.88s**, private `_n8zm9bn`,
   session61678, exit0; external I/O0, Node117, Git-refusal1.
   This is the preserved123 prior harness cases plus31 new cases.

No fixture-error retry occurred. The original fixtures gained only the
new fixed labels/standard geometry, updated16 image count/metadata and the
new product's pending/unknown banner-clearing behavior. The existing
banner-replaced fault remains scheduled at the same post-refresh check;
its expected BANNER_LAYOUT_FAILED and every prior failure/cleanup assertion
remain unchanged. The actual serialized reader and deterministic scroll
function run in the authored VM, and the mounted tests run the existing
full `run` function, not a rewritten control-flow stand-in.

## Frozen SHA256 identities

- Python harness (577 lines):
  `028674b0356f4b56376ceceb27b32ea530c14f9aaab73aee05828bac60823047`
- CJS harness (448 lines):
  `13b2ad7101e748bca543b8fc58a5547cd23d15749ac5d9dbe0339f9343483507`
- `test_legacy_preview_browser_harness.py`:
  `896045af52165af134f57c19f2e93fb2335520b0169b43f221bd2190c12238c7`
- `test_legacy_banner_browser_harness.py`:
  `8aac85655e5b9c55042011c917034e62b7333596756468dd5cfcca0dcd081076`
- New `test_legacy_current_feedback_browser_harness.py` (159 lines):
  `100584c32492a1d7f67305fab5c6e62c44d2a201b28efbedbe9ea1372fed3959`

Prior harness candidates remain attributable: Python
`70dd914c8ca134f6b100f91d132ec5096f84a1350f786370a5764a6277369532`,
CJS `aa64de305933b9bf500078784f44190e7999be0fe084b5a477a611bdf7454fc1`.
Product index remains
`224f600cef4d652989028fe8d499aa3271e9576222fbf4330e5eafd5b5f3f074`;
molecular inspector remains
`00266652ee37295650a7012676aafb2e91bfeaf03289f804937fb4b1e909c0aa`.

## Exact independent repeat

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`.
This permits only the fixed Node/-eval test subprocess shape, refusing
external network and any other subprocess. Python3.11.15, Node26.0.0.
No test imports Playwright or launches a service.

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - livemorebio/tests/test_legacy_current_feedback_browser_harness.py livemorebio/tests/test_legacy_preview_browser_harness.py livemorebio/tests/test_legacy_banner_browser_harness.py <<'PY'
import os,socket,subprocess,sys,urllib.request,ctypes,signal
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1';os.environ['PYTHONDONTWRITEBYTECODE']='1'
signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1;permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=line',*sys.argv[1:]])
print('Refusal counts:',counts,flush=True);signal.alarm(0)
raise SystemExit(status)

PY
```

## Remaining gate and durable lesson

Maker evidence is ready for independent root review. A separately authorized
source-frozen ordinary16-image browser run and personal visual inspection
remain required. Earlier actual14-image evidence stays unchanged and cannot
prove the newer labels. Molecular adapter/build/consumer and the larger
Atlas/full-product gates remain separate and open.

Lesson: a proof attached to an image must be admitted as well as recorded.
The new fixed row ledger checks feedback ownership and copy; the three
old clear operations retain their six predicates in that same bounded
evaluation. This avoids both a misleading screenshot-count pass and an
extra timing window around the deliberate two-second hold.

## Independent review and one actual run decision

Root reviewed the complete final harness and test sources and independently
repeated the three-file suite:154 passed in14.21s, session39846, private root
suffix p8k6jsfj. Refusal counters: unexpected I/O0, permitted Node117,
expected Git refusal1. Final Python/CJS/product-index hashes match the freeze
above. This accepts the harness for its narrow UI purpose, not biological output.

Root authorizes one ordinary16-image run of this unchanged harness with source
`f9f7b4384cba70ea6080b631c1ca33c7e8b2bda8c3c0797d527858e234520fed`.
Use only its isolated stores, guarded services and authored response cases;
retain any failure and independently inspect all originals before acceptance.
No six-program execution, hardware interaction or installed-state change is
authorized by this UI check. Product/runtime files remain frozen during the run.
