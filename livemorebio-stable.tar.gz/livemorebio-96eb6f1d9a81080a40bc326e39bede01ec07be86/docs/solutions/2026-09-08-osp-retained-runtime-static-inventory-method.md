# OSP static inventory: exact read-only method

2026-09-08. Reproducibility source for the companion JSON inventory, not a collector,
launcher or test. This code was run only by the named Python interpreter for file
bytes and metadata. It loads no R/managed/native/product code and writes no file.
Its stdout was retained through apply_patch. No network, subprocess or model API
is called. Fixed runtime roots, 128 MiB per-file hash cap; system subcache reads
are explicitly 4 KiB metadata only, not content attestation. The inventory JSON
was formatted with each top-level array member on one line after collection.

Interpreter: `/Users/emman/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B`.
Read with the companion mapping report and root's scope/implementation gates.

```python
from pathlib import Path
import hashlib, json, os, re, struct, plistlib, stat
ROOT=Path('/tmp/livemore-osp-native.mUlZwx')
RH=ROOT/'r-unpacked/R-fw.pkg/Payload/R.framework/Versions/4.6/Resources'
REAL=ROOT.resolve(strict=True)
def dcf(p):
    d={}; k=None
    for s in p.read_text().splitlines():
        if s[:1].isspace():
            if k:d[k]+=' '+s.strip()
        elif ':' in s:k,v=s.split(':',1);d[k]=v.strip()
    return d
catalog={}
for base in (RH/'library', ROOT/'r-library'):
    for p in sorted(base.iterdir()):
        if (p/'DESCRIPTION').is_file():catalog[p.name]=(p,dcf(p/'DESCRIPTION'))
seed=['base','methods','utils','stats','graphics','grDevices','datasets','ospsuite','jsonlite']
seen=set(); todo=seed[:]; packages=[]
while todo:
    n=todo.pop()
    if n in seen:continue
    assert n in catalog,n
    seen.add(n); p,d=catalog[n]; deps=[]
    for f in ('Depends','Imports'):
        for spec in d.get(f,'').split(','):
            dep=re.sub(r'\s*\(.*','',spec).strip()
            if dep and dep!='R':deps.append(dep);todo.append(dep)
    packages.append({'name':n,'version':d['Version'],'path':str(p.relative_to(ROOT)),'declared_dependencies':sorted(set(deps))})
def stable(p,limit=134217728):
    logical=p.absolute(); resolved=p.resolve(strict=True)
    assert resolved.is_relative_to(REAL) or str(logical) in OSFILES
    st=resolved.stat(); assert stat.S_ISREG(st.st_mode) and st.st_size<=limit
    h=hashlib.sha256()
    with resolved.open('rb') as f:
        fst=os.fstat(f.fileno()); assert (fst.st_dev,fst.st_ino,fst.st_size,fst.st_mtime_ns)==(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
        while b:=f.read(1048576):h.update(b)
        aft=os.fstat(f.fileno())
    assert (aft.st_dev,aft.st_ino,aft.st_size,aft.st_mtime_ns)==(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
    assert logical.resolve(strict=True)==resolved
    now=resolved.stat()
    assert (now.st_dev,now.st_ino,now.st_size,now.st_mtime_ns)==(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)
    return st.st_size,h.hexdigest(),str(resolved),{'device':st.st_dev,'inode':st.st_ino,'mtime_ns':st.st_mtime_ns,'mode':stat.S_IMODE(st.st_mode)}
def image(p):
    with p.open('rb') as f:b=f.read(65536)
    offset=0
    if b[:4] in (b'\xca\xfe\xba\xbe',b'\xca\xfe\xba\xbf'):
        fat64=b[:4]==b'\xca\xfe\xba\xbf';n=struct.unpack_from('>I',b,4)[0];assert n<16
        rows=[struct.unpack_from('>IIQQII' if fat64 else '>IIIII',b,8+i*(32 if fat64 else 20)) for i in range(n)]
        arm=[x for x in rows if x[0]==0x100000c]
        if not arm:return 'FOREIGN_IMAGE',None
        offset=arm[0][2]
        with p.open('rb') as f:f.seek(offset);b=f.read(65536)
    if b[:4]==b'\xcf\xfa\xed\xfe':
        _,cpu,sub,ft,n,sz,flags,res=struct.unpack_from('<8I',b,0)
        if cpu!=0x100000c or ft not in (2,6,8):return 'FOREIGN_OR_DEBUG_IMAGE',None
        assert n<4096 and sz<65504
        dep=[];rp=[];ident=None;pos=32
        for _ in range(n):
            cmd,size=struct.unpack_from('<II',b,pos);assert size>=8 and pos+size<=len(b)
            if cmd in (0xc,0xd,0x80000018,0x8000001f,0x80000023,0x8000001c):
                q=struct.unpack_from('<I',b,pos+8)[0]
                val=b[pos+q:pos+size].split(b'\0')[0].decode()
                if cmd==0xd:ident=val
                elif cmd==0x8000001c:rp.append(val)
                else:dep.append({'command':hex(cmd),'path':val})
            pos+=size
        return 'NATIVE_ARM64',{'cpu_subtype':sub,'filetype':ft,'install_name':ident,'rpaths':rp,'dependencies':dep}
    if b[:2]==b'MZ':
        pe=struct.unpack_from('<I',b,60)[0];assert pe+256<=len(b) and b[pe:pe+4]==b'PE\0\0'
        opt=pe+24;magic=struct.unpack_from('<H',b,opt)[0]
        assert magic in (0x10b,0x20b)
        count=struct.unpack_from('<I',b,opt+(92 if magic==0x10b else 108))[0]
        cli=struct.unpack_from('<II',b,opt+(96 if magic==0x10b else 112)+14*8) if count>14 else (0,0)
        return ('MANAGED_PE' if all(cli) else 'FOREIGN_IMAGE'),None
    if b[:4]==b'\x7fELF':return 'FOREIGN_IMAGE',None
    return 'DATA',None
selected={}
for n in sorted(seen):
    p,d=catalog[n]
    for name in ('DESCRIPTION','NAMESPACE'):
        if (p/name).is_file():selected[p/name]='R_PACKAGE_METADATA'
    for sub in ('R','Meta','data','libs','lib'):
        base=p/sub
        if base.is_dir():
            for q in sorted(base.rglob('*')):
                if q.is_file() and not any(x.endswith('.dSYM') for x in q.parts):
                    selected[q]='R_CODE_OR_DATA' if sub in ('R','data') else 'R_PACKAGE_METADATA' if sub=='Meta' else 'PACKAGE_RUNTIME'
for q in sorted((RH/'etc').iterdir()):
    if q.is_file():selected[q]='R_LOADER_CONFIGURATION'
for sub in ('lib','modules'):
    for q in sorted((RH/sub).iterdir()):
        if q.is_file():selected[q]='R_RUNTIME'
for q in [RH/'bin/exec/R',RH/'bin/R',ROOT/'dotnet/dotnet',ROOT/'dotnet/LICENSE.txt',ROOT/'dotnet/ThirdPartyNotices.txt']:
    if q.is_file():selected[q]='LAUNCHER_OR_RUNTIME_METADATA'
for base in [ROOT/'dotnet/host/fxr/8.0.30',ROOT/'dotnet/shared/Microsoft.NETCore.App/8.0.30']:
    for q in sorted(base.iterdir()):
        if q.is_file():selected[q]='DOTNET_RUNTIME'
# Evidence sources are pinned as documents/code bytes, never executed by this inventory.
rs=ROOT/'packages/rSharp-3a8686e70c700437b451a01216ad4fb2990e432c'
for rel in ('R/zzz.R','R/rSharp-env.R','R/utilities-assembly.R','R/utilities-net-object.R','R/net-object.R','shared/rSharp.cpp','shared/ClrFacade/InternalReflectionHelper.cs','shared/ClrFacade/ClrFacade.cs'):
    p=rs/rel
    if p.is_file():selected[p]='SOURCE_EVIDENCE_ONLY'
for rel in ('doc/manual/R-lang.html','doc/manual/R-ints.html','doc/manual/R-exts.html','doc/manual/fullrefman.pdf','include/Rinternals.h'):
    selected[RH/rel]='SOURCE_EVIDENCE_ONLY'
for name in ('native-artifact-manifest.csv','cran-dependency-lock.csv','installed-r-packages.csv'):
    selected[ROOT/name]='HISTORICAL_METADATA'
CACHE=Path('/System/Volumes/Preboot/Cryptexes/OS/System/Library/dyld')
OSFILES={str(p) for p in [Path('/System/Library/CoreServices/SystemVersion.plist'),Path('/usr/lib/dyld'),Path('/usr/bin/vmmap'),Path('/bin/ps'),Path('/bin/sh'),Path('/usr/share/man/man1/vmmap.1'),CACHE/'dyld_shared_cache_arm64e',CACHE/'dyld_shared_cache_arm64e.map']}
files=[];excluded=[];loads=[]
for p,role in sorted(selected.items(),key=lambda x:str(x[0])):
    assert p.resolve(strict=True).is_relative_to(REAL)
    kind,details=image(p) if role in ('PACKAGE_RUNTIME','R_RUNTIME','DOTNET_RUNTIME','LAUNCHER_OR_RUNTIME_METADATA') else ('DATA',None)
    rel=str(p.relative_to(ROOT))
    if kind.startswith('FOREIGN') or p.name in ('cairo.so','R_X11.so','R_de.so'):
        excluded.append({'path':rel,'reason':'NON_ARM64_OR_DEBUG' if kind.startswith('FOREIGN') else 'OPTIONAL_X11_DEPENDENCY_NOT_ADMITTED'})
        continue
    size,sha,resolved,identity=stable(p)
    item={'path':rel,'bytes':size,'sha256':sha,'role':role,'image_kind':kind,'file_identity':identity}
    canonical=str(Path(resolved).relative_to(REAL))
    if canonical!=rel:item['resolved_relative_path']=canonical
    files.append(item)
    if details:loads.append({'path':rel,**details})
osrows=[]
for s in sorted(OSFILES):
    p=Path(s);size,sha,resolved,identity=stable(p)
    osrows.append({'path':s,'resolved_path':resolved,'bytes':size,'sha256':sha,'file_identity':identity})
subcaches=[]
for p in sorted(CACHE.glob('dyld_shared_cache_arm64e*')):
    if p.name.endswith(('.map','.atlas')) or p.name=='dyld_shared_cache_arm64e':continue
    st=p.stat()
    with p.open('rb') as f:head=f.read(4096)
    subcaches.append({'path':str(p),'bytes':st.st_size,'mtime_ns':st.st_mtime_ns,'header_4096_sha256':hashlib.sha256(head).hexdigest(),'full_file_sha256':None})
mapbytes=(CACHE/'dyld_shared_cache_arm64e.map').read_text()
systempaths=sorted(set(x for x in mapbytes.splitlines() if x.startswith('/')))
outside=[]
for row in loads:
    for dep in row['dependencies']:
        s=dep['path']
        if s.startswith('/') and not s.startswith('/Library/Frameworks/R.framework/') and s not in systempaths:
            outside.append({'image':row['path'],'dependency':s})
out={'schema':'OSP_RETAINED_STATIC_INVENTORY_V1','scope':'STATIC_CANDIDATES_NOT_LOADED_IMAGES','runtime_root':str(ROOT),'resolved_runtime_root':str(REAL),'package_seeds':seed,'packages':sorted(packages,key=lambda x:x['name']),'files':files,'excluded_images':excluded,'native_load_commands':loads,'system_identity':{'plist':plistlib.loads(Path('/System/Library/CoreServices/SystemVersion.plist').read_bytes()),'files':osrows,'subcache_metadata_not_content_proof':subcaches,'map_image_count':len(systempaths)},'outside_retained_or_cached_static_dependencies':outside,'counts':{'packages':len(packages),'files':len(files),'bytes':sum(x['bytes'] for x in files),'native_images':sum(x['image_kind']=='NATIVE_ARM64' for x in files),'managed_images':sum(x['image_kind']=='MANAGED_PE' for x in files),'excluded_images':len(excluded)}}
print(json.dumps(out,separators=(',',':'),sort_keys=True))
```
