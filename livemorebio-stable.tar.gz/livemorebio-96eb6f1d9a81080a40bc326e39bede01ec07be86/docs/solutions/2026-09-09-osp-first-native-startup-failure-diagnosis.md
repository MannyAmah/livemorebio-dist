# Independent diagnosis of the first retained-byte OSP startup failure

2026-09-09. Read-only review by release_redteam. The authorized once-only
technical packet remains **FAILED**. No retry, native probe, model admission,
process-policy relaxation or scientific conclusion follows from this review.

## Evidence personally checked

Consumed control root: `/private/tmp/livemore-osp-native-once.CA533x`.
Packet root: its `tmp/livemore-osp-semantic-n6yhhp1f` directory.
The independent stdlib-only read/hash/JSON comparison completed with exit 0,
tool completion `706b67`. It did not import the supervisor or run an OS/native
probe. The actual invocation was root's completion `51d74d`, exit 1.

| Retained file | Bytes where checked | SHA256 |
|---|---:|---|
| `authorization.json` | control record | `654fdd6aa1f5a387e1a96a1ef801284cbb2612225ece28629c0d19bc8f255c66` |
| `once.json` | control record | `85b543bbd9c362d557a4c93eb0a04cc337ffef18476b1c8a4b771b62c6a518dc` |
| `completion.json` | control record | `676bb4d83299f22561d5a57d7c253586e98c88e60780f0498bb02c37616fc78b` |
| packet `result.json` | 4341 | `9ddea114d4a1732c8548812848e86da685dfa61714e4ac9b5b52f404fc55c808` |
| packet `admission.json` | 719 | `df7faaa56eaf58d883b0a617d091a0f52c921ee2f4c28e35d74e5c14ba2ec0fd` |
| `S01/result.json` | 2797 | `cf2c09529f68ba1298670781308fb2e777b1f227acbb3663be7a22a7b0258865` |
| `S01/configuration.json` | 3971 | `587f53009b3c664f9944c061eec2a914dda8b25a891f6ad8e194aa5561cf94e9` |
| `S01/stdout.bin` and `S01/stderr.bin` | 0 each | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |

The authorization and once records have equal parsed objects, not equal byte
encodings. Completion links exactly to the original packet root/hash. The
standalone S01 result equals the embedded case. Admission and configuration
identities/limits match the packet. The six regular, single-link packet files
total 11,828 bytes. Both stream hashes and EOF/zero-byte claims match originals.

The configuration's S01 XML is 3006 bytes with SHA256
`91e2b7c347c487faa152116a59d87c02eda48bbf7aff48af43764550e344bb81`.
Its prescribed `run_calls=2` is configuration, not evidence of two actual Runs.
All 17 case IDs/order are retained; S02–S17 are NOT_RUN. No request/ACK,
inspector, image, comparison, observation or collector-cleanup file was emitted.

## Actual terminal and ownership evidence

The wrapper records FAILED/PACKET_REJECTED, source preservation CONFIRMED,
and no secondary wrapper evidence errors. Elapsed-before-completion was
0.9386914169881493 s; the earlier packet interval was 0.9270700829802081 s.
The S01 worker interval was 0.15487508301157504 s.

S01's primary is UNEXPECTED_DESCENDANT. Secondary evidence codes are
PROCESS_ARGUMENTS and PROCESS_FAILED. Its only retained process observation
equals its leader identity: PID 38453, parent 38444, group 38453, start
`11386585800880`, image UUID `25d12ac5a71b3920a2336237861f59cf`.
The retained resolved path and argv identify the pinned direct R executable,
`--vanilla --slave -f` the frozen collector, and this exact configuration.
One admitted resource sample records 32768 bytes RSS and 47519 CPU ns; maximum
sample gap is 0.11976049997610971 s. These are not a complete rejected-group trace.

Worker cleanup records SETTLED, TERM, exit -15, no KILL, group empty before
reap, no cleanup error, and 0.018630000005941838 s cleanup. Unresolved-child is
false. Root separately checked exact PIDs 38444/38453 absent (completion
`401301`, exit 1/no rows). That is root's observation, not an independent new
OS probe or a retrospectively reconstructed descendant list.

## Source-established cause and unrecoverable evidence gap

Reviewed supervisor SHA256
`8f8c1f66be57f0466a4481fc5cc1b095e6ed47a3e01564f850ae9cf0aa17b79a`
and collector SHA256
`3ba6559b723cfe85c66bca47aac0abfbaac8e395c430bd7360105dc6f67625f7`.
The bounded sampling, classification, callback, cleanup and case admission
paths were read directly; no module was imported to execute them.

1. `tools/osp_semantic_supervisor.py:694–703` samples the owned group, then
   calls `_check_processes` **before** appending any new rows to retained
   observations. A completely sampled but rejected rowset is therefore lost.
   A sampling failure within the list comprehension also loses the partial set.
2. `_check_processes:648` raises UNEXPECTED_DESCENDANT on a nonleader when
   the startup window is inactive, the parent is absent from the sampled group,
   the group exceeds three rows, or this is an inspector. This was an R worker,
   not an inspector. The receipt cannot establish the failed row's PID, path,
   argv, parent or group size.
3. Source inference: no admitted STARTUP_BEGIN exists; `startup_active:773–774`
   remains false before that admitted barrier. Therefore any nonleader reaching
   this policy before STARTUP_BEGIN is prohibited, independently of its command.
   The primary establishes that a nonleader reached this policy, but does not
   establish whether it was dotnet, a shell, another R startup child, or something
   else. The collector delegates its fixed dotnet command only after the startup
   request/ACK. No request file survived in this packet.
4. Cleanup sampling at 730–739 can append PROCESS_ARGUMENTS after the primary.
   The relevant sampling/sysctl/argument-parser path has no retained failing PID
   or exact substage, so this does not prove permission/SIP failure. It can neither
   identify the rejected child nor establish that the same row failed twice.
5. `_admit_process:756` raises PROCESS_FAILED because the primary is non-null.
   This is a cascading admission refusal, not a second independently diagnosed
   operating-system failure.

The immediate failure is process admission, not the earlier vmmap timeout or
unused-row parser failure. There is no support for changing vmmap timing,
allowlisting a guessed command, opening all R descendants, or attributing SIP.
The seven-condition OS preflight never promised complete R startup topology.

## Smallest proposed next decision, not implementation authorization

Approve a narrow evidence-retention amendment before considering another actual
packet: retain bounded successfully sampled rows as **unadmitted candidates**
before policy classification, plus fixed phase/failed-PID/sampling-stage metadata
for partial sampling failure. Preserve the existing exact-owned group scope,
row/string/history/disk limits and prohibition on environment-tail capture.
Do not count rejected rows as accepted samples or weaken any refusal predicate.
Use authored tests for rejected full sets, partial sampling, history bounds and
cleanup failure; keep all existing process, deadline and cleanup assertions.

After written approval, red-first implementation and independent review, root
may decide whether a separate fresh once-only technical startup/packet attempt
is justified. This review does not authorize it. Current CA533x, its consumed
marker, original O1 failure and all numerical/model gates remain unchanged.

Lesson: fail-closed classification and diagnosable evidence are separate duties.
Retaining only accepted identities prevents later explanation of exactly why an
otherwise correctly rejected attempt stopped. Raw facts must be retained with
their rejected status, never promoted to permission or scientific evidence.
