# OSP fixed semantic fixtures: implementation-only review packet

2026-09-08. Maker: `release_redteam`. **Pending independent full code review.**
Only invented technical XML, written output hypotheses and strict observation
validation are implemented. No R, managed/native library, source equation,
formula evaluator, compiler, solver, service or child probe was executed.
No observed native arrays or final technical acceptance receipt exist.

## Approved scope and exact new files

Read in full before implementation: the biological model-change contract, the
[retained-native proposal](2026-09-08-osp-retained-native-technical-probe-proposal.md),
and [version-bound source map](2026-09-08-osp-native-semantics-source-map.md).
Root reapproved the technical-only boundary and separately approved the missing
seventh solver setting before XML authoring. The proposal's final mapping
amendment SHA256 is
`0d477233d6555b5b694b2541512833d14b3c41a8d32ecaa5880a3d537278dcd0`.

| New implementation/test file | SHA256 |
|---|---|
| `tools/osp_semantic_probes.py` | `12585d9bed93cd2a5625ec1cd625287406a22d475b49c34ba931109630ea82d7` |
| `livemorebio/tests/test_osp_semantic_probes.py` | `5c4d29106391b97f429d1f66969e3262c8d35395678b11947d94d74a08951b09` |

The implementation is 407 lines. No old implementation or test was edited. In
particular, the existing source-admission tool remains SHA256
`f6b5d2daf5d90c5b6949ae35f2089fd75a12b2b935e060b7ac96ce8ead321821`
and old native collector remains
`6a16df63980de72b06c39b21b200de10a7bd04f54405a06c7bf5512a64dc1f37`.
The old numerical FAILED, first static FAILED and accepted declared graph results
are neither altered nor reclassified. All six programs and R01–R51 remain in scope.

## Implemented interfaces, not a runner

- `protocol()` returns a detached fixed declaration, including 17 process slots,
  16 prescribed Run calls, byte pins, source hypotheses and false admission flags.
- `fixture(case_id)` returns a detached manifest plus exact authored XML bytes.
  Only the exact strings S01 through S17 are accepted. There are no arbitrary
  parameters, XML/expression CLI arguments, environment override or run function.
- `validate_fixture(case_id, raw_xml)` requires exact byte equality to that fixed
  fixture before any use. It does not parse external XML. Therefore the four
  prescribed malformed fixtures are not a generic validation bypass: changed
  whitespace, declarations, references or malformed payloads all reject.
- `compare_observation(case_id, raw_json, expected_identity=...)` validates a
  **collector claim** against the fixed observation sub-schema. It does not
  authenticate that any native API was called. Its comparison labels are MATCH,
  DISAGREEMENT and EXPECTED_REJECTION, not final packet acceptance. Every return
  explicitly sets execution_verified, cleanup_verified and model_admission false.

Protocol SHA256, computed over canonical JSON excluding its own digest:
`5eb866376a2b121109066dbb11edad2eba701b3b85c8fe474ae1aa02b8e505e7`.
The manifest includes every XML definition identity, requested grid, named output,
oracle, allowance, fixed setting and fixture hash. XML itself retains all ordered
alias references and assignments. Aliases are local to each formula; definition
IDs and quantity entity IDs are unique. Parameter IDs are distinct from their
observer readout IDs. No physiological source subset was extracted.

`native_source_attestation=UNVERIFIED`, historical_author_runtime=UNKNOWN and
RESTART_TRACE_UNOBSERVABLE persist. The five principal native/managed pins are
declared, but loaded_manifest_complete=false: a hash supplied to this pure
validator is not proof of a complete loaded-image inventory.

## Pinned primary-source mapping checks

The prior source map did not retain local C++ source files. Root explicitly
authorized read-only retrieval of the fixed official commit pages needed for
mapping. `/browse` was read fully; its already recorded startup exit137 was not
retried or repaired. The approved primary-page retrieval fallback was used, with
no source archive, runtime, package or asset download. Context7, gbrain and CE
tools were not callable; this durable note records the available fallback.

All links below refer to SimModel commit
`395dccf72a310b0485e63928741703045a1b40aa`, not a proved native binary build.

- [GlobalConstants.cpp](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/GlobalConstants.cpp)
  establishes version4, namespace, Time ID0 and the exact event/assignment,
  species, table/offset and output tag spellings.
- [DESolverProperties.cpp](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/DESolverProperties.cpp)
  requires seven constant-parameter references. The root-approved UseJacobian=1
  completes the original six settings. H0/HMin/HMax are labeled tau, AbsTol u,
  and relative tolerance, step count and Jacobian selector dimensionless. These
  are authored software-test labels, not native dimensional validation.
- [DESolver.cpp](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/DESolver.cpp)
  initializes CVODES internally; its XML loader does not select it from the name
  attribute. XML includes name=CVODES as a declaration, not claimed native
  readback. Saved outputs and switches have the ordering used by the hypotheses.
- [Species.cpp](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/Species.cpp)
  maps ScaleFactor, initialValueFormulaId, RHSFormulaList and
  negativeValuesAllowed. All states are persisted; only S06 x has scale10.
  S15's negative-allowed flags are explicit. No physiological domain exemption
  follows from a flag in an invented fixture.
- [Quantity.cpp](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/Quantity.cpp)
  supports literal/formula alternatives and rejects their simultaneous presence;
  this supplies S03/S04 hypotheses without selecting a precedence.
- [OutputSchema.cpp](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/OutputSchema.cpp)
  gives Uniform intervals with exact start/end/count. The fixed G and H intervals
  use exactly representable half-integer times, with no interpolation or extra
  requested save points introduced by this layer.
- [TableFormula.cpp](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/TableFormula.cpp)
  and [TableFormulaWithOffset.cpp](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/TableFormulaWithOffset.cpp)
  map point lists, derived/restart flags and quantity—not formula—Table/Offset
  references. Both table declarations serialize the shared T point list; S16/17
  use their specified invalid T lists. Restart candidate lists are hypotheses,
  never observations of actual restart calls.
- [Simulation.cs](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModel/Simulation.cs)
  names FinalizeSimulation, SimulationTimes, ValuesFor, RunStatistics and
  SolverWarnings. [SimulationOptions.cs](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModel/SimulationOptions.cs)
  exposes the two options the future collector must set and read back:
  AutoReduceTolerances=false and StopOnWarnings=true. This layer only records
  their required values; it does not set or read a managed property.

## Frozen serialized XML identities

These are generated authored inputs, **not native results**. They were inspected
and hashed only in memory under the same process/network refusal wrapper. The
largest fixture is5,190bytes/89XMLnodes, below64KiB/1,024nodes/depth16. Tests also
bound states4, observers8, parameters32 and formulas64 and check all typed links.

| Case | XML bytes | Nodes | Run calls | SHA256 |
|---|---:|---:|---:|---|
| S01 | 3006 | 52 | 2 | `91e2b7c347c487faa152116a59d87c02eda48bbf7aff48af43764550e344bb81` |
| S02 | 3006 | 52 | 1 | `06091640b26de9c65ed84f381bf3ad767cc8b29fb04ecee3205f87f5fbb27b78` |
| S03 | 3117 | 55 | 0 | `3344540b2a2bdbdcdac5c1c7f14dc7eba2bacf5237da248c184dc40b500656e8` |
| S04 | 3016 | 52 | 0 | `fcbc4bca35a0ff93a874ad2d52a2fd9edcc6be59f0566ceb124b0713e42593aa` |
| S05 | 3578 | 63 | 1 | `1dc5c8b5dc9e58447e262ccb12f0da14a6dd3d2c4440fa208b199ac03d8d005b` |
| S06 | 3204 | 59 | 1 | `fd296eca0627c72e1a546bcb41d0a69a6f0fa5aec052ef1c67526d243071fc78` |
| S07 | 2919 | 54 | 2 | `0486f4c7d891ee6130bd008b5a4359954fd752f38086376e8dd879e680d6ee1f` |
| S08 | 2919 | 54 | 2 | `2dc9d15a035ed3f4dfee731172f893c8c6d99cc35674066f1875c4263dc1f547` |
| S09 | 3655 | 66 | 1 | `d0da9303d3ba55fcac96815523afa351d0bc414f2a6ff30e70b473e3dd231e62` |
| S10 | 3655 | 66 | 1 | `308a510c08a6edc2ff23783a1bf2ee49842c27d636079b89abe3ea2f16408614` |
| S11 | 3862 | 71 | 1 | `e23315e7d61a854abb1a9f9149f2169a98f48c35ee93bae03c10b0bbeb8ef561` |
| S12 | 3862 | 71 | 1 | `b50d094c71a3f5ef05525941d13afa00af2eb42369bbfaf6c2bf2d3d062ac8d1` |
| S13 | 5190 | 89 | 1 | `cb2b646f0a12c754521f2ff2d5420932f7aece82644d080eb1207cdafc5c595a` |
| S14 | 5190 | 89 | 1 | `2e91242e4b4a876f71f07bdcebc128489bf54f0fd1c47300a20ec139d9370792` |
| S15 | 3290 | 58 | 1 | `957e2c6d9d4aa2cec9475dfc7047c4624fa17f1b1e0238c040a26c9f9b8e6ab0` |
| S16 | 5034 | 85 | 0 | `b8bfaf05a2f8dae958dfef6f594eb49dc2c13c84e96125e32e8e63885971edf0` |
| S17 | 4956 | 83 | 0 | `a45b477acbf677d9d58d144878c1a9dd438d29251fd0cbc224a4ade2edfe516f` |

S01/02, S07/08, S09/10, S11/12 and S13/14 have direct XML comparison tests:
normalizing only their case identity and reverting the one prescribed distinction
restores exactly the paired XML. In particular, S12 only reverses EventList
siblings; it does not incidentally rebind their condition formula identities.

## Observation sub-schema and what it proves

The strict sub-schema is `osp-retained-native-semantics.observation.v1`, separate
from the future complete `osp-retained-native-semantics.v1` receipt. Exact keys:
schema, case_id, fixture_sha256, protocol_sha256, identity,
native_source_attestation, stage, run_calls, runs. Expected identity has exactly
driver_sha256, collector_sha256 and runtime_manifest_sha256; each must be a
lowercase64-character digest supplied by the future trusted orchestration layer.

Positive claims require COLLECTED, exact planned call count, ordered ordinal,
requested grid, full ordered output ID list, and unchanged tolerances with zero
warnings. Each output contains id, values, native_count and native_constant.
Only an explicitly marked one-value native constant can expand. The returned
normalization preserves original native_values/count/marker as well as expanded
values. Repeats compare native vector shape and IEEE754 double bytes, including
signed zero, not rounded JSON text or only tolerance-based values.

For S15, all four state/state-observer t0 values must be present and finite, but
their oracle entries are null because the proposal does not assert their initial
export timing. They are retained, not replaced by expected zeros. Post-step x
requires exact numeric zero; z/literal use1e-13. Other analytic outputs use1e-6,
direct observer values1e-12, and Time exactly. Failed finite comparisons retain
bounded output/index disagreement records. Invalid identity, shape, grid or
statistics raises a fixed ProbeError; the caller must retain the raw bytes even
when validation fails. No raw native exception or arbitrary path is echoed.

Negative claims permit only LoadFromXMLString or FinalizeSimulation with zero
Run calls and an empty runs array. Their fixture output declarations are metadata
for the authored inputs, not permission to fabricate successful native arrays.
Stage claims alone do not establish why a native API rejected; actual trace,
identity, primary diagnostic, resource and cleanup evidence remain future work.

Input JSON is at most256KiB, depth16 and8,192 visited values; duplicate keys,
invalid UTF8, nonfinite values, booleans masquerading as numbers, unknown keys,
wrong IDs, missing rows, extra times and unreviewed digests reject. There is no
generic shared-parser budget change. The final16MiB/64MiB packet/disk budgets and
30s/600s process clocks are **not implemented** in this fixture-only increment.

## Red/green evidence and complete offline repeat

- Before the implementation existed: **108 setup errors**, each missing the new
  module, in0.17s. Private root `livemore-research-review-ohjd8xsq`.
- Initial implementation:108passed0.19s.
- Stronger structural tests:27failed/128passed0.42s. Twenty-three failing cases
  exposed three defects:5parameter/readout entity collisions,17incorrect solver
  unit labels and1changed raw repeat shape hidden by expansion. Four other
  failures were an overly narrow test tag suffix excluding TableFormulaWithOffset;
  those assertions were corrected to the exact three allowed formula tags.
- After those corrections:155passed0.24s.
- Exact paired XML regression:1failed/194passed0.33s because event construction
  order also rebound identical constant-condition IDs. Preserving construction
  and reversing only siblings fixed it:195passed0.31s.
- One final hash-freeze coverage test was added, without claiming a new red.
- First complete freeze repeat:331passed,2deselected,0.52s. Final source inspection
  then moved two already-executed assertions into their correctly named test
  functions (signed-zero into repeat-bits, S15 z-zero into tiny-values), with no
  assertion or runtime behavior removed. **Final:331passed,2deselected,0.63s**.
  This includes196new tests and135existing
  authored static/arithmetic tests. The two inherited native_watchdog tests that
  launch Python children were explicitly excluded before collection/execution.
  No unexpected network/child/dlopen attempt occurred. No native check is counted.

Final private test root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-1__tqwq7`.
The preceding0.52s repeat used the same prefix with leaf
`livemore-research-review-7jk3b8c3`.
Only isolated harness directories/credentials were prepared; no operational store
was used. The in-memory fixture identity listing used a separate private root
ending `livemore-research-review-0nq4crxa` and the same refusal barriers.

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```sh
PYTHONDONTWRITEBYTECODE=1 /Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B - <<'PY'
import os, sys, signal, socket, subprocess, urllib.request, multiprocessing.process
from tools.run_review_stack import prepare_review_environment
root, env = prepare_review_environment(inherited={k:v for k,v in os.environ.items()
    if k in ('PATH','HOME','TMPDIR','LANG','LC_ALL')})
env.update(PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
os.environ.clear(); os.environ.update(env)
def deny(*a, **kw):
    raise AssertionError('Unexpected network or child in fixture tests')
for owner, names in ((socket, ('socket','create_connection','getaddrinfo')),
                     (subprocess, ('Popen','run','call','check_output')),
                     (urllib.request, ('urlopen',)),
                     (multiprocessing.process.BaseProcess, ('start',))):
    for name in names:
        setattr(owner, name, deny)
def audit(event, args):
    if event in ('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn',
                 'os.exec','ctypes.dlopen'):
        deny()
sys.addaudithook(audit)
signal.alarm(60)
print('Private test root:', root, flush=True)
import pytest
raise SystemExit(pytest.main(['-q','-p','no:cacheprovider','--tb=short',
    'livemorebio/tests/test_osp_semantic_probes.py',
    'livemorebio/tests/test_osp_source_admission.py',
    'livemorebio/tests/test_osp_stage_b.py',
    'livemorebio/tests/test_osp_stage_b_analysis.py',
    '-k','not native_watchdog']))
PY
```

## Remaining gates and lesson

This packet needs an independent full code/test grade. It does not clear a
collector, supervisor, private driver, native runtime inventory or execution.
Those later increments must preserve the proposal's process ownership, resource,
failure-retention and once-only authorization rules and independently establish
native-constant marker observability. No pre-reviewed JSON can substitute for
native data. No source-expected matching result supplies native build attestation,
historical equivalence, GIM admission, compound efficacy or person qualification.

The implementation lesson is to test the **actual serialized distinction**, not
only a label or output oracle: a factory can preserve the intended arithmetic yet
accidentally change identities when reversing declarations. Raw native vector
shape similarly must survive normalization if a same-object repeat is to be
meaningfully compared. These are software-test integrity improvements only.
