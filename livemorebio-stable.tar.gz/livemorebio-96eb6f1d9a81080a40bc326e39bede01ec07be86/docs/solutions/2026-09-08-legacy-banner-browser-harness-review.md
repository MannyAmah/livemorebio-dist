# Legacy banner: bounded browser-harness extension

2026-09-09. **Maker packet frozen for independent review; no actual browser run.**
Written approval and pre-code precisions are appended to
`2026-09-08-legacy-banner-flow-correction.md`. This is harness implementation,
not the independent grade of the banner product change recorded in that plan.
No product, model, registry, coordinate, cache or dependency install/build changed.

## Frozen files

| File | SHA256 |
| --- | --- |
| tools/check_legacy_preview_browser.py,529 lines | `70dd914c8ca134f6b100f91d132ec5096f84a1350f786370a5764a6277369532` |
| tools/check_legacy_preview_browser.cjs,382 lines | `aa64de305933b9bf500078784f44190e7999be0fe084b5a477a611bdf7454fc1` |
| livemorebio/tests/test_legacy_preview_browser_harness.py,689 lines | `67a1126c26069e10fffd2556819c4f536513721329baf5a54a6d22bb797d9c9f` |
| livemorebio/tests/test_legacy_banner_browser_harness.py,99 lines | `0c7c973f47fc536c87289f444b866f7523e540b55e881676b7fb010cfdec9c2d` |
| Unchanged product index.html | `16f39c7f5d5c20cacf8de066132a552baa993b0bd740ea44e94e4fb061a5ee94` |
| Unchanged product banner tests | `2638a8a3e4f9224143ecf723ddc8cf330a731f482d8f1d860ceda65906f3aef4` |

Previous harness hashes remain recorded in the D0 diagnostic report, and the
accepted original12-image actual recovery run remains immutable. The new14-image
requirement is prospective; no historical receipt or screenshot was rewritten.

## Exact changes and retained bounds

The Python change is only the14-image name/count admission and fixed banner-row
validation. Startup, private fixture, service process supervision and cleanup are
unchanged. CJS inserts desktop-error after desktop-modeless and mobile-error
before mobile-note-before; all original12 names remain an ordered subsequence.
All seven original delivery cases, four exact authored POSTs, one fresh GET per
POST,256-request accounting, fixture values/source hash, original model
tripwires,180-second browser/350-second parent budgets,4-MiB per-image and64-MiB
overall evidence limits are preserved. The maximum request count remains256;
no new HTTP route or request is introduced for the banner checks.

After each actual modeless baseline, an existing-page elementHandle retains the
banner node. All reads execute the exact serialized `readBannerSnapshot` function
against that handle, checking the current singleton's identity. Page/context
cleanup releases it, including failure and late-action completion. No global
patient object, HTML rewrite, extra page, module interception or browser state
marker was introduced.

The error uses the visible existing Compound/empty-input validation. Before a
keyboard Enter, the harness records hidden/empty banner, selected Compound,
empty input and enabled run button. It focuses that button, invokes Enter once,
then requires unchanged focus and both scheduled/request POST counters. The
actual product branch returns before runVia on this input. No parameter, model,
trial or chemical invocation is permitted by the check.

Five ordered metadata rows cover desktop-info, desktop-error, desktop-cleared,
mobile-error and mobile-info. Raw geometric/boolean evidence is assigned before
assertions, including failed input/focus/placement checks. Error outcomes remain
fixed categories with no text/clinical payload logging. Existing first-failure
capture/NOT_RUN accounting and cleanup are unchanged.

For visible checks, scroll the existing nav and window to0,0 before reading
rectangles and capturing. Require whole banner below nav and inside viewport,
normal static/wrapping styles, correct info/error attributes, banner center
hit-test and every visible direct nav-link clipped-center hit-test. Offscreen
links have visible=false/hit=null; they are not claimed accessible or tested.
Complete keyboard/200%/all-link navigation remains open. The existing info image
slots now target nav/top so that navigation and banner are visible together.
The two new error images use the same positioning. Original other captures are
unchanged. Root must visually inspect actual images, not infer PASS from metadata.

The public installed Playwright source was read before using elementHandle:
`client/locator.js:158` resolves the strict attached element; inherited
`client/jsHandle.js:39` serializes the supplied function/argument for evaluation.
The installed tree is `/Users/emman/.agents/skills/gstack/node_modules/playwright-core/lib/`.
No package, real Playwright browser or service was executed for this source check.

## Red, interim and final receipts

| Stage | Result | Private review-root suffix | Node / unexpected I/O / optional Git |
| --- | --- | --- | --- |
| New24 cases before harness changes |24 failed,2.24s |024wh8lv |18 /0 /0 |
| First implementation preservation |66 failed,56 passed,7.04s |xgsd49e6 |66 /0 /1 |
| Syntax correction |122 passed,7.87s |3io2iyxa |66 /0 /1 |
| Extra banner-occlusion guard before fix |1 failed,0.18s |s29p6bo8 |1 /0 /0 |
| Final new25 + original98 + product6 |**129 passed,8.39s** |7ii93dv1 |71 /0 /1 |

The first implementation had an authored `visible:` instead of `visible=` in a
const declaration; Node imports failed before the66 JS tests could run. This was
a harness syntax defect, corrected in the implementation without changing test
expectations. The extra guard demonstrated that nav geometry alone cannot prove
the banner is not covered; the same read now records its actual center hit-test.
Neither intermediate failure is biological or real-browser evidence.

Inherited fixture changes are only12→14 count/name expectations, fixed banner
receipt fields for parent positives and standard fake elementHandle/evaluate/
focus/keyboard behavior. Every prior auth/source/HTTP/error/timeout/disposal/
state assertion remains. The shared mounted runner executes real h.run plus the
same serialized DOM reader; standalone DOM negatives test overlap, clipping,
wrong singleton, fixed positioning, nonwrapping text, unexpected text, overflow,
NaN and banner/nav occlusion. Positive fixtures establish function availability
before negative assertions; missing functions cannot satisfy them. Completion
guards remain active for every asynchronous Node test.

### Exact independent repeat

Use the complete frozen command in
`2026-09-08-legacy-preview-d0-diagnostic-implementation-review.md`, with the
sanitized prepare_review_environment line from the banner plan, plugin autoload
and bytecode disabled, default SIGALRM45 seconds, and replace only pytest's file
selection with these three exact files:

```python
status=pytest.main(['-q','-p','no:cacheprovider','--tb=short',
 'livemorebio/tests/test_legacy_banner_flow.py',
 'livemorebio/tests/test_legacy_banner_browser_harness.py',
 'livemorebio/tests/test_legacy_preview_browser_harness.py'])
```

Interpreter `/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B -`, worktree
`/Users/emman/Livemore/.worktrees/full-scope-recovery`. Exact authored
`/opt/homebrew/bin/node --eval` only, with the existing injected network/process
refusals; Python socket/DNS/urllib/ctypes/unrelated process operations refused.
The final exec session19498 completed exit0. No tests or children remain active.

No actual launch is authorized by this report. Independent source/test review,
new product-source fingerprint and root's once-only execution decision are next.
The12 prior actual images and unresolved scientific labels/whole-product gates
are preserved. Molecular acquisition/install/build did not advance in this lane.

Lesson: checking navigation does not establish banner visibility. Retain both
hit-test facts and negative evidence before accepting a normal-flow screenshot.

## Root independent review, September 9

The root read the complete new harness report, all new banner tests, the changed
browser and parent admission sections and mounted/receipt fixture changes.
All four frozen harness/test hashes match those above. Original twelve images,
seven cases, four authored intercepted POST deliveries, fixed GET schedule and
owned-resource cleanup remain; two real validation-error images and five banner
state checks are added without a new product mutation or numerical experiment.
Visible clipped navigation links are checked, not falsely graded as all mobile
links or full accessibility. The negative overlap/replaced-node/input/focus/POST
cases are deliberate test data, not actual browser evidence.

Independent bounded repeat: **129 passed in 8.92 seconds**, private review root
suffix `u3f4er_g`, session61818 exit0. Python/Node network, native loading and
unrelated children were refused; unexpected I/O0, authorized Node71, Git refusal1.
This clears the changed harness for a separately pinned once-only actual check
after current runtime edits freeze. It does not yet accept the banner rendering,
whole product, molecular viewer, biological reactions or any experiment video.

### Once-only actual banner authorization

Runtime is now frozen at source fingerprint
`f755a2aab6883e40cd0e384b24d2b1e7ddca20719e5d1ba5873d3322fbbb83aa`.
The root authorizes one run of the unchanged frozen supervisor with that exact
`--expected-source`, existing private fixture isolation and14-image schedule.
This follows independent harness/product/audit source review and preserves the
earlier12 actual screenshots. Root must inspect all14 new original images and
the cleanup/delivery receipt before making any visual acceptance claim. No
actual experiment, existing operational store or installed release is in scope.
