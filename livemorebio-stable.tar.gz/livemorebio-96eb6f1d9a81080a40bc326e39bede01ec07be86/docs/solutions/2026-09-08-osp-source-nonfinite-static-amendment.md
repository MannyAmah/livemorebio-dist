# OSP declared missing literals: retained failure and static-only amendment

2026-09-08. **Pre-code proposal; independent review required.** This does not
alter the insulin model, numerical tolerances, original Stage B FAILED verdict,
or the six required experiments. It corrects a source-inspection assumption.

## Actual once-only result, retained unchanged

After root read all 631 implementation lines and all 407 tests, the independent
technical run passed 90 tests in 0.15 seconds. The separately authorized static
invocation then returned **FAILED / STATIC_LITERAL** at
`Simulation/ParameterList[4]/P[10566]`. No formula/native evaluation occurred.

Retained report:
`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-osp-static-review-ycyhzqor/osp-source-admission-v1-5203c09d1c3a454797f980bb4c2ed20d/report.json`.
It is 453 bytes, SHA256
`270165bd9646aeff5347816325695eacc7763faa2d2d7250223cd0dda19d7418`.
The gate was closed again in finally; its on-disk value never changed. Source,
three ledgers, implementation/tests and old numerical files retained their hashes.
Socket/DNS/urllib/subprocess entry points were refused; a 60-second alarm bounded
the invocation, which finished in under one second without a timeout.

Root's subsequent read-only inspection of the original pinned XML found the
failing declaration is P26258, Hexokinase Molecular weight, unit `kg/µmol`, exact
source value `NaN`. It has three declared formula consumers, so its absence is
not safely dismissed from its name. A whole-file literal inventory found exactly
56 `NaN` values, all on P value attributes; no other inspected value/x/y field
used NaN, Infinity, -Infinity, INF or -INF. Twenty-eight of these parameters have
direct declared formula consumers and 28 do not. Direct-consumer absence is not
proof of biological irrelevance or permission to remove a parameter.

Exact missing parameter IDs, in original source order:

```text
26258 26352 26353 26354 26389 26483 26484 26485
26544 26638 26639 26640 26689 26783 26784 26785
26829 26923 26924 26925 26970 27064 27065 27066
27109 27203 27204 27205 27240 27334 27335 27336
27387 27481 27482 27483 27518 27612 27613 27614
27663 27757 27758 27759 27802 27896 27897 27898
27941 28035 28036 28037 28072 28166 28167 28168
```

The four recurring source labels are Molecular weight, Lipophilicity, Fraction
unbound (plasma), and Solubility at reference pH. These are missing source inputs,
not measured values, authored defaults, or mathematical zeros. The original
finite-literal contract rejects them as designed. Its failed report must remain
unchanged; a subsequent static diagnostic is separately versioned evidence.

## Proposed smallest correction to inspection, not biology

1. Preserve the strict numeric validator and default technical entry unchanged:
   nonfinite values, expressions and malformed literals still fail. Add a private
   parser/build option carrying an exact frozen set of missing P IDs. Only the
   pinned entry passes the 56-ID set after exact source hash/length verification.
   Tiny authored internal tests may exercise this option explicitly without
   receiving pinned source identity or model admission.
2. The sole permitted exception is literal string `NaN` in `P.value` for these
   exact IDs. No variable, table coordinate, solver/output setting, scale factor,
   Infinity spelling, numeric overflow, or different ID is exempt. Require the
   encountered exception set to equal the supplied set; do not quietly accept a
   source variant in which values have been filled or moved.
3. Keep the source attributes and string `NaN` exactly. Tag each affected P node
   `value_status="SOURCE_NONFINITE_LITERAL_UNRESOLVED"`; never call float on it,
   coerce it to null/zero, impute it, or exclude its outgoing references. Retain an
   explicit top-level missing-literal inventory with IDs, raw literals, source
   locations, declared units and direct declared consumers.
4. Add `SOURCE_NONFINITE_LITERAL_UNRESOLVED` to successful pinned report semantic
   flags alongside the three existing event/table/time uncertainties. Every
   successful static report still has `model_admission=false`. The declared-XML
   graph may be complete; numerical input completeness is explicitly false.
5. For each existing reverse initializer traversal, list affected missing-input
   nodes actually reached, including an empty list when none are reached. This
   is a declared-dependency statement, not a claim that other quantities, events
   or biological contexts are unaffected. Keep all existing root roles and all
   graph edges; do not add 56 traversals or increase any finite budget.
6. All failures retain FAILED without a partial COMPLETE graph. Keep the original
   failed report and all old source/numerical files untouched. No package/runtime
   wiring, equation execution, native worker, new dependency, data acquisition,
   tolerance relaxation or model activation belongs to this packet.

## Red tests and independent acceptance

Add tiny authored internal parser fixtures proving: an exact admitted missing P
is preserved as a string with its consumers; nested initializer dependencies
retain its unresolved classification; absent/moved/wrong-ID exception rejects;
every non-P/non-NaN/Infinity/overflow case still rejects; the public technical
entry remains strict; default on-disk gates remain false; report JSON contains
no IEEE nonfinite numbers; source identities and original FAILED receipt remain
exact. Require the exceptional ID set's shape to be strict and bounded, and reject
an unexpected known-ID numeric replacement rather than silently dropping it.

Independent source review must compare the 56-ID set, source locations and
reference consumers directly with the XML, not trust only maker fixtures. After
implementation and tests are independently reviewed, a new one-shot static run
may be separately approved. It must retain a different report and its own source
hash; no automatic retry or rewriting the first failure.

## Durable lesson

Source-structure completeness and numeric-input completeness are separate. A
static graph inspector must expose a publisher's missing numeric declarations
without inventing values, and its reports must never confer execution authority.

## Independent source review and root pre-code precision

The independent reviewer checked the exact XML and retained FAILED receipt without
importing the generator or running any model. All56 IDs match source order; their
canonical ordered JSON list hash is
`9ac9d5010ab0ca2748efcb88f5b60ff470e41c56196e174f957a57d2f634d999`.
The28 referenced declarations have98 R occurrences (42 molecular-weight,56
lipophilicity); no other recognized reference kind targets these56 parameters.

Root accepts all three review precisions before code:

- Exact write set is the existing static tool and dedicated test, plus this
  amendment/implementation report. Preserve `_number` and `inspect_technical`
  signature/default semantics. The private exception option is exactly a
  frozenset of canonical positive string IDs, at most56; no coercion/iterators.
- Exceptional reports explicitly set `numeric_input_completeness=false`, retain
  the versioned exception policy, unresolved node/leaf classification and all27
  reverse-initializer lists (including empty lists). Default technical reports
  keep their original three semantic flags. All graph references, aliases,
  ordinals and repeated occurrences remain unchanged.
- Here, “missing” means **unresolved source nonfinite declaration**. It does not
  establish the publisher's intended missing-data semantics, nor prove that these
  declarations caused the earlier numerical failure. The source string remains
  `NaN`; no scientific value or source correction is inferred.

Red-first implementation is approved within these boundaries. Its independent
maker-separated review and separate one-shot report approval remain mandatory.

## Root implementation packet, frozen for independent review

The private option is now implemented with the exact approved exception set,
unchanged default numeric validator/public technical entry, unresolved declaration
inventory retaining every direct edge occurrence, and per-reverse-role unresolved
input lists. Pinned success explicitly reports numeric input incompleteness and
the policy version. On-disk and current process gates remain closed. No new
pinned report or native model was run during implementation.

RED: **27 failed,91 passed in0.19s**, private root ending
`livemore-research-review-mhn0vkqp`, before the implementation changes. The failures
were absent private-option/metadata interfaces; the existing90 and new public
strictness check passed. GREEN: **118 passed in0.23s**. Two additional coverage
tests check all27 reverse roles and nested parameter/table-offset dependency;
final **120 passed in0.18s**, private root ending
`livemore-research-review-agj4jl2w`. The dedicated fixture retains its network and
subprocess refusal. These tiny authored fixtures execute no source equations.

Frozen implementation SHA256:
`f6b5d2daf5d90c5b6949ae35f2089fd75a12b2b935e060b7ac96ce8ead321821`.
Frozen dedicated test SHA256:
`80f373e9234e3c73dc0c9dce14aee420f3c4e135e4560bfbcc16bd0972ed157c`.
The original453-byte FAILED report still hashes to270165bd… in a separate direct
read-only check; its path is not added as a hardcoded dependency/skipped test for
external installations. Original numeric-source preservation checks still pass.

Root is the maker of this amendment. An independent reviewer must grade it before
any separately approved source-report invocation; maker GREEN is not clearance.

## Independent implementation clearance and second static invocation

The independent reviewer fully read all674 tool lines,519 test lines and this
amendment, and traced the added status consumers. An isolated repeat passed
**120 tests in0.17s**, no skips, private root ending
`livemore-research-review-uxklme3y`, with process-level network/child refusal,
fixture refusal and native/model import guards. Seven extra authored probes in
`livemore-research-review-_519i8al` proved NaN is never passed to float, graph
edges/settings and unaffected nodes match the finite technical baseline, and
nonfinite scale/output settings, duplicate exceptional IDs and mixed bindings
still reject. Tool/test hashes stayed exact; the gate remained closed. No
actionable implementation blocker was found.

Root now authorizes exactly one new static-only invocation using those frozen
hashes, the same original XML and three pinned ledgers, and a different new
owner-private output directory. Use the prior60-second alarm and network/child
refusal caller, changing only the reviewed implementation/test hashes. No formula,
native or biological execution. Preserve the first FAILED receipt and all old
numerical/source evidence. On-disk gate stays false and the process-local gate
closes in finally. This is a new diagnostic under the explicit unresolved-literal
policy, not a retry of the original finite-literal claim or permission to change
the source. Independently inspect its actual graph/result before stronger claims.
