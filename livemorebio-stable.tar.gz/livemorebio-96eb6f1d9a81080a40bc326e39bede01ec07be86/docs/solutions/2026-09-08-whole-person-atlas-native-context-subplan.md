# Whole-person Atlas with exact native-source context

Date: 2026-09-08. Parent: full-scope recovery R21/R22/R24/R25/R26/R27/R46, with R03/R23/R30/R37/R47 dependencies.
Status: **proposed for root and independent review; no implementation authorized by this document alone**.
Ownership and API/asset admission below must be agreed before code. Existing routes, body/organ inspection, cohorts, experiments, LIFE controls, evidence and stored records are preserved.

## Problem and selected approach

The approved A+B layout calls for an intact whole-person Atlas in A's experiment workspace. The current Atlas uses a procedural orientation SVG. Biology now renders genuine reference organ meshes, but its explorer deliberately normalizes and spaces each organ independently. Mounting that explorer in Atlas would repeat the rejected organ montage, not satisfy the approved whole-person view.

Keep the current design and services. Add a separate coordinate-preserving whole-person renderer and an exact-source Atlas view controller. Reuse the packaged graphics dependencies, cold-cache safety, typed numerical frame inspection, recorded protocol projections and build identity. Keep Biology as the deeper organ/cell/molecular workspace.

Rejected alternatives:

1. Move existing `createAnatomyExplorer` into Atlas. It normalizes each organ to a target box and applies `o.pos * SPREAD`; mixed HRA/Allen/BP3D sources have no shared registration contract.
2. Scale or pulse a heart from voltage, glucose or a diagnosis. None supplies a cardiac deformation field. This would manufacture a spatial result.
3. Replace the body with an image, generic particles or only charts. It would not provide the requested interactive anatomical inspection.
4. Rewrite all product pages or implement option C. The user approved A+B and preservation, not a new visual direction.

This packet does not change physiological equations, kinetic parameters, evidence classes or patient state. It supplies truthful interactive anatomy and state inspection. Actual spatial tissue mechanics, cell organelles and molecular trajectories remain required open work; lack of those outputs must not be disguised as fulfillment.

## Design source and visual roles

Root must visually inspect these before approval:

- `/Users/emman/.gstack/projects/MannyAmah-livemorebio/designs/multiscale-human-workspace-20260830/approved-merged.png`
- Sibling `variant-A.png`, `variant-B.png`, `approved.json`, `feedback.json`.
- `/Users/emman/.gstack/projects/MannyAmah-livemorebio/20260908-revb-and-visual-reference-review.md` for the four directly inspected Human Atlas/Ozempic Cascade/Membrane Atlas/Cell Atlas clips.
- `2026-09-08-all-page-visual-acceptance-inventory.md` for all five retained post IDs and the still-unmapped MdrBwl post. Only Derya is excluded.

Keep the green product header and Atlas tab, left multiscale column, body-centered main area, biological time under the body, paired plots and compact experiment/evidence panels from A+B. Use progressive disclosure for secondary controls rather than filling the initial viewport with every form.

Atlas controls: rotate/pan/zoom, home, anatomical system/layer visibility, search, selected-structure isolation, labels, section axis/depth, source-context selector, exact quantity selector and the appropriate time/condition control. A selected structure has a compact reference/source card and an explicit deeper Biology link. Camera and layer actions change only the view.

Biology retains detailed process/stage/organ/cell/molecular inspection with the same source key. Atlas always returns to an assembled whole person; isolated/exploded inspection is a deliberate temporary view with a visible return action, never the default assembly.

The mockup's example clinical values, observed points, uncertainty bands and calibration badges are not evidence. Every displayed quantity and badge must be supplied by the selected admitted record or remain unavailable.

## Existing source findings

| Seam | Reuse | Constraint |
|---|---|---|
| `console/lib/anatomy_loader.js`, `anatomy_vendor*`, `anatomy_requests.js` | Locally packaged Three/GLTF/OrbitControls and bounded same-origin asset loading | Verify loaded module hashes; preserve retry cancellation and no remote executable dependency. |
| `console/lib/anatomy.js` | Picking/camera/section/disposal patterns only | Do not reuse its `normalize()` and `addOrgan()` placement for assembled Atlas. Existing inspector behavior stays unchanged. |
| `anatomy/meshes.py` | Owner-controlled cache, atomic GLB publication, provenance and bounded acquisition locks | Existing catalog has seven reference structures from mixed sources. It is not a registered whole-body assembly. |
| Existing BP3D archive/map acquisition | Candidate common-source coordinate set and FMA component identities | Current muscle conversion retains native vertices but source frame, scale, release, full-body coverage and redistribution obligations must be independently verified before Atlas admission. |
| `lib/biological_projection.js` | Frozen workspace context, protocol member/stage/quantity and observation-source validation | Never coerce protocol condition to biological time or treat a coherence token as validation. |
| `lib/execution_view_state.js` | Exact selection, frame chain, source generation, native times/units and bounded numerical window | Contains scalar compartment series, not geometry displacements. Retain source-invalid/offline/hidden behavior and independent control revision. |
| `lib/continuous_execution.js` | Fixed-context links and lifecycle control patterns | Do not embed a second polling owner or mutate producer/session from a camera action. |

## Gate A: admit one coherent reference anatomy

Preferred candidate: the existing BodyParts3D single-release OBJ distribution and its published component mapping, reviewed as one coordinate system. Current code points at `isa_BP3D_4.0_obj_99.zip` through a mutable `LATEST` URL. A URL or cache-side SHA alone is not a sufficient frozen assembly manifest.

Before implementation activates an Atlas asset, the asset owner must:

1. Read primary source metadata/license and freeze the release, archive bytes/hash, component map/hash, coordinate frame, axis convention, units and conversion behavior. Do not infer millimeters, sex, posture or handedness from a screenshot.
2. Select the exact whole-person surface/support and organ/vascular component IDs from that source mapping. Record whether each component is included, excluded, missing or unsupported. Do not guess skin or vessel IDs. Preserve upstream attribution and derivative/share-alike obligations; geometry redistribution is not assumed to license unrelated product code.
3. Prove all selected structures use the common source coordinates. Keep per-component vertices and transforms unchanged. Apply only one documented root coordinate/unit transform to the entire assembly. No per-organ centering, fitted scale or hand placement.
4. Independently check front/side/back landmark registration, left/right, inferior/superior, enclosure and relative organ placement. Compare source-native bounding boxes and representative vertices before/after conversion. Geometry conversion correctness is distinct from clinical anatomical accuracy.
5. Produce a versioned `livemore.atlas-reference.v1` manifest with model/release/source IDs, coordinate frame/unit, root transform, component/node IDs and FMA/UBERON mappings, component bounds/hash, asset hash/size, license/attribution and explicit `REFERENCE_ONLY`/`patient_registered:false`.
6. Keep it in the isolated anatomy asset cache under a manifest-addressed name. No raw archive or licensed corpus in source control. API status/manifest expose no local paths. Installation is an explicit same-source action with atomic publication, bounded archive/member sizes, safe zip members, no symlink/hardlink following, single acquisition lock and honest failure.
7. Freeze a measured renderer budget after inspecting the candidate's real bytes/triangles. Use same-coordinate source-authorized lower-detail geometry or declared progressive loading if needed; do not silently decimate clinically relevant structures or call missing layers complete. Initial whole-person coherence is a required visual gate even when deeper layers load later.

If the preferred source lacks a coherent whole-person surface or sufficient registration metadata, report the exact gap and submit a separately sourced complete-assembly alternative for review. Do not splice independent HRA organs into this frame or fall back to the old SVG and call Gate A complete.

Proposed backend routes, subject to root approval:

- `GET /api/anatomy/atlas-reference`: static manifest/readiness only, no person state.
- `GET /assets/anatomy/atlas/<manifest-sha>/<asset-name>.glb`: immutable admitted same-origin asset, selected only from the manifest allowlist.
- Reuse an existing deliberate acquisition entry point if it can express this manifest; otherwise propose a protected explicit install route before adding it. No user-supplied download URL.

This plan does not yet assert the exact component IDs, coordinate unit, complete registration, final license permission or asset budget. Those are Gate A evidence, not guessed constants to be filled during rendering.

## Gate B: one source selection shared across Atlas and Biology

Introduce a small pure `AtlasSourceState` discriminated contract. The selected view is one of the following, never an implicit blend:

| Mode | Identity | Source and axis | Allowed inspection |
|---|---|---|---|
| Reference preview | Explicit preview context, no admitted person ID | Static anatomical manifest; no device stream | Intact reference geometry and source descriptions, no invented baseline physiology |
| Current twin snapshot | Authenticated workspace `context_id` plus source class/subject metadata | Existing `/api/workspace`; exact recorded trajectory if present | Recorded systemic glucose/insulin, typed multiscale state and independently sourced Patch metadata |
| Frozen human protocol | Exact `run_id`, cohort/member, protocol, stage and condition | Existing saved metformin `t_min` + glucose/insulin/insulin_action pairs, or PXR concentration conditions | Same saved individual's recorded quantities; no unrelated active-twin API lookup |
| Continuous execution | Exact `execution_id`, optional bound `session_id`, immutable selection/source hash/generation | Existing committed frame API and verified LIFE status | Native metabolic G/X/I or cardiac voltage/Ca quantities with original clocks and evidence class |
| Nonhuman/reference assay | Exact Human-GEM or lobeline run | Steady-state condition or stationary substrate/inhibitor axis | Link to its separate Biology assay workspace; never map it onto a person as physiological response |

URL proposal: `/` accepts explicit mutually exclusive `execution_id`/`session_id`, `run_id`/member/condition/stage, or existing workspace `context_id`. The default remains the current safe preview/current twin experience. Unknown, repeated, malformed or ambiguous source selectors fail visibly without falling through to active twin data. Resolve exact parameter names with existing Biology URL handlers before coding.

All numeric cards, tree selection, plotted points, body overlay, time/condition controls, device status, evidence drawer and deeper link consume one validated immutable view selection. Source switches abort old fetches, discard callbacks from the previous generation and reset source-dependent time/member selection. Retain camera preferences only where the same anatomical manifest permits them.

For continuous source mode, reuse or extract the pure existing frame-poll controller so only one owner polls that selected execution per page. Do not mount the full Patch controller as a hidden producer of state. Keep polling bounded, hidden tabs paused and last good frames historical after failure. Control mutations remain explicit on their owning surface; Atlas navigation never starts a producer or consumer.

For saved runs, member/condition changes are read-only. No rerun, cohort activation or model mutation occurs. Selection and source digest go into the link to Biology and its return to Atlas. Browser back/forward and reload must restore the same selected context or an explicit unavailable state.

## Gate C: separate spatial state from scalar quantities

Current native contracts provide:

- Metabolic: `glucose_mgdl` in plasma, `insulin_uU_ml` in plasma, `insulin_action_per_min` in the reduced remote insulin-action compartment; native minutes.
- Cardiac: `membrane_voltage_mv` and `cytosolic_calcium_mm` in a ventricular myocyte; native milliseconds.
- Saved metformin: paired recorded systemic glucose/insulin/insulin-action quantities where units are present.
- PXR: member-specific modeled reporter response over recorded concentrations, not an atom-coordinate or downstream transcription trajectory.

These do not supply tissue deformation, organ strain, blood-velocity fields, spatial concentration fields, molecular coordinates, respiration or body posture dynamics. No waveform, sine clock or scalar-to-scale heuristic may move the anatomical body as though it did.

Permitted state-driven display now: actual sampled scalar values with units and original source clock; a clearly labeled nonspatial compartment marker/legend; selected anatomical structure highlighting; an exact plot cursor; historical/current/quality status. A systemic plasma value cannot be colored onto an entire organ as measured local concentration. Cardiac cell voltage belongs to the ventricular-cell detail, not a whole-heart contraction.

An anatomical layer tint can indicate **selection or declared coverage**, not diagnosis/function. Data overlays must name the quantity, compartment, operator, range and evidence class and explain any visual normalization. No physiological color threshold may be invented to improve appearance.

Actual spatial motion is admitted only through a separately reviewed typed field/transform record: exact geometry manifest/node/vertex identity, source run/frame hash, native time/unit, spatial unit/frame, rest/reference geometry, displacement/velocity semantics, model version and validity/uncertainty. Validate finite shapes, correspondence, bounds and coordinate transform before applying. A generic transform channel alone does not implement or qualify a biomechanical engine.

Do not write that future spatial engine in this UI packet. Keep the missing mechanics and multiscale programs in the parent ledger. The visible Atlas will be interactive and native-state-linked, while accurately distinguishing reference geometry from executing spatial biology.

## Controls, errors and responsive acceptance

- Preserve A's intervention/lifecycle/paired plots/evidence surfaces. Source mode determines whether an existing action is applicable; explain unavailable actions rather than leaving dead controls or silently changing source.
- Whole-body home returns to complete registered reference coordinates; system filtering/search/isolate and clip/label controls have visible reversible outcomes and accessible state.
- A tree branch must use typed anatomical/mechanistic relationships. The approved cardiovascular path can reach ventricular tissue/cardiomyocyte/IKr/KCNH2 reference context. SLC22A1/OCT1 belongs to its separate hepatic/metformin branch, not a fabricated downstream child of IKr. Identifier presence is not a causal-rate model.
- Clock controls distinguish native continuous following, recorded playback and stationary conditions. No playback button for a stationary assay; no real-time label on recorded data. Original LIFE capture and ACK ages are not reset by polling.
- Details panes remain scroll-bounded and keyboard reachable. At 390 px, whole-person viewport and primary source/time controls precede advanced/evidence disclosure; no horizontal overflow or offscreen action feedback.
- Renderer missing/GPU context lost/cache acquiring/integrity failure/auth loss/source mismatch/empty data each has a specific visible state. Retain valid numeric data if geometry fails, but a charts-only fallback does not pass the anatomical acceptance gate.
- Camera movement is user navigation, not biological movement. Respect reduced-motion and do not run decorative transformations while idle or hidden.

## Proposed ownership and implementation sequence

1. Root/source owner: Gate A source and license/coordinate review, new narrowly scoped `anatomy/atlas_reference.py` plus manifest/asset routes and private-cache isolation tests. Avoid concurrent edits to root-owned `server.py` or established `meshes.py`.
2. UI owner after approval: new `console/lib/atlas_reference_scene.js` (coordinate-preserving render/picking/layers) and `atlas_source_state.js` (pure selection/projection). Reuse local dependency and request helpers without changing Biology's inspector layout.
3. UI owner and root explicit handoff: `workspace.html`, `lib/workspace.js/css`, `biological_projection.js`, minimal exact Atlas-return links in `biology.html`/protocol/continuous consumers. Root currently owns workspace build-identity changes; no parallel edits there.
4. Tests first: dedicated source/renderer/unit/context tests, preserved UI regression suite, actual browser harness with visible controls and exact source/build proof. Source owner does not grade asset/source admission; UI maker does not grade rendered acceptance.
5. Root independently runs real current-source browser on the isolated stack, reviews screenshots side-by-side with the approved merged image, records fail/pass per control and mode, and updates the all-page inventory. No old operational store or service is borrowed.

## Red-first test and evidence matrix

| Test family | Required failure before implementation and acceptance after |
|---|---|
| Asset identity | Missing mixed-source registration, changed archive/map/hash, wrong units/axes, absent component, unsafe path/external URI, malformed/oversized GLB and partial publication reject. Existing seven-organs catalog cannot masquerade as an assembly. |
| Coordinate preservation | Compare source-native landmark/vertex relationships and bounds after conversion. Rendering applies one root transform only; test that per-organ normalize/SPREAD/hand placement is absent from Atlas. Real browser front/side/back screenshots show an intact coherent body. |
| Source binding | Snapshot versus saved run versus execution conflict; wrong member/session/hash/generation, delayed source switch, duplicate query, browser back and reload. No active fallback in fixed-source modes. |
| Native series | Exact units/time/sample, constant values advancing time, null/partial data, malformed/nonfinite series, no stored-time invention, no cross-compartment overlay. No deformation calls from scalar traces. |
| Controls | Search/layer/isolate/home/clip/labels, linked multiscale path and evidence view visibly act; no biological API writes from camera/selection actions; retry retains view state and cancels old acquisition. |
| Continuous lifecycle | Exact source following, pause/disconnect/stale/hide/return, original clocks, independent control versus record revisions. Reuse the corrected shared lifecycle tests; never patch a failed click with automatic POST retry. |
| Responsive/rendered | Actual Chrome/SwiftShader WebGL reported as software rendering, plus an independently available hardware-GPU environment if claiming hardware support. Test 1440/1280/768/390, keyboard/zoom/reduced motion; no fallback-only acceptance. |
| Preservation | All nine existing pages, Cendos blank preparation/history/rerun, subject/cohort switching, v3 admission, physical evidence boundaries, notebooks/exports and installed build identity remain intact. |

Proposed evidence location: `docs/screenshots/full-scope-recovery/atlas/attempt-N/`, immutable attempt directories with metadata-only receipts and safe explicitly technical screenshots. Capture initial whole person, reference layers, selected organ→cell navigation, source switch, native/recorded/condition modes, unchanged state, error/recovery and mobile. Record geometry source/manifests and numerical source separately.

## Approval questions for root, not assumed decisions

1. Accept Gate A's single-source BP3D candidate investigation and a separate coordinate-preserving renderer, with no anatomy activation before source/frame/rights proof?
2. Approve the static manifest/immutable asset route shape and ownership, or name an existing approved complete assembly that should replace the candidate?
3. Confirm exact source URL parameters and the shared polling owner extraction before workspace edits, preserving full default/saved/execution behavior?

No additional user taste decision is needed: A+B remains the approved design. Any proposal to remove an accepted control or replace whole-person anatomy with a lesser artifact would require explicit user direction. Until all parent obligations are fulfilled, this packet must not be called the complete living-human product or full visual acceptance.
