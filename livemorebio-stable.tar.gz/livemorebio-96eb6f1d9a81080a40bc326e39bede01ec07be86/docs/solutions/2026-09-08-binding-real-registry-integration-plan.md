# Binding: actual encrypted registry-to-publication integration

2026-09-08. Proposal only; root review is required before test authoring. Read the
complete master recovery plan, confirmed-binding plan and implementation review,
actual binding route/prepared registry/commit-witness paths, and the checked
startup integration fixture. R01–R51 and all six programs remain unchanged.
No test, request, model, service, operational-store or browser was run for this
proposal. Local source/document reading is the fallback for unavailable gbrain,
context7 and sequential-thinking tools.

## Exact boundary and write set

After approval, create only
`livemorebio/tests/test_checked_binding_registry_integration.py`. No runtime or
existing test edit. This verifies the already independently cleared binding
route at server SHA256
`3d521a029bccf5d9069a4e78806d40fbf895aca3b3cf6b6f370ad9500645676d`.
The current 35 authored boundary cases, 28 existing binding cases and original
RED results remain evidence; this is additional wiring coverage, not a replacement.

Use the same private ASGI-compatible environment as the startup integration:
actual server registry getter with tmp_path and the public fixed test key;
actual SubjectRegistry initialization, encryption, authority, preparation,
commit, exact lost-ACK witness and audit methods; actual ModelSourceAuthority,
assignment-only fence and no-background ExecutionManager. No lifespan/startup
handler is entered. Seed only authored technical rows using the existing seed,
rows, events and replacement helpers. Import their functions, never the
registry-only socket-denying autouse fixture.

Preinstall a coherent selected in-memory source matching the authored ACTIVE
record. Its READY twin is an inert holder with explicit patch/observations and
authored state/parameters; its modeless twin is None with actual typed availability
and ObservationState. All numerical/clinical constructors, build_twin and adapters
remain tripwires. Retain real `_snapshot_twin` with only its two file-backed bus
sinks replaced by recording functions. The execution store is a no-I/O sentinel
with no owners, adapters or worker. Do not reuse the permissive prepared/outcome
registry doubles from the 35-case module.

## Thirteen proposed cases

| Cases | Actual transaction and required result |
|---|---|
| 1 | Selected SYNTHETIC / READY, virtual binding: real version n→n+1 and encrypted binding; 200, new coherent source fence/summary, same live holders and attributed snapshot. |
| 2 | Selected unbound REAL_HUMAN / UNAVAILABLE, physical **metadata-only** binding using the existing authored physical_body and consent fixture: actual device index plus physical audit schema; 200, still modeless with the same reason, no model construction. Receipt remains PAIRING_RECORDED / PENDING_SIGNED_ENVELOPE, not hardware validation or telemetry admission. |
| 3 | Unselected DATA_ADMITTED virtual target with a different ACTIVE source: only target changes; active ciphertext/pointer/state/fence/holders remain exact, no projection or bus publication. |
| 4–5 | During selected unlocked state projection, independently edit the target's authenticated payload at the same version, or only the active-pointer timestamp. Real final helper rejects 409 TWIN_VERSION_CONFLICT. Preserve the deliberate external edit and old memory/fence; no binding snapshot or additional mutation. |
| 6 | Final mutation commit raises before committing, actual rollback succeeds: fixed 503 REGISTRY_STORAGE_UNAVAILABLE, old rows and memory/fence exact, failed-access terminal retained; no publication. |
| 7 | Final mutation commit persists then loses its acknowledgment: exact real witness confirms once, 200 and n+1 publication. No repeated UPDATE/reseal, one route request and one final mutation attempt. |
| 8–9 | Persisted final commit loses ACK and its terminal audit ciphertext is deliberately altered, selected and unselected targets separately: real witness cannot confirm; fixed 503 SELECTION_COMMIT_UNCONFIRMED and both authority/manager DENY_ALL, no speculative snapshot. Preserve the actual durable binding and damaged evidence; do not label this rollback. |
| 10 | Final mutation commit fails while still transactional and rollback acknowledgment also fails: fixed uncertainty and DENY_ALL, including after actual close rolls the transaction back. A later observed rollback cannot retroactively confirm what the route did not know. |
| 11–12 | Actual final mutation commit succeeds, connection close completes then raises, selected and unselected separately: fixed 503 SELECTION_COMMITTED_CLEANUP_UNCONFIRMED; selected retains new coherent fence and publishes its explicit snapshot; unselected leaves active state/fence untouched. |
| 13 | Unauthorized binding request: 401 before actual preparation, no new audit/record/index bytes or source change; static access remains possible without startup. |

Physical case 2 exercises only the existing local metadata policy and encrypted
index/audit wiring. No real device, attestation verification, signed packet,
watermark, gateway or physiological output is supplied or claimed. All other
cases use virtual metadata. Native persisted-model lifecycle, v2/v3 normalization,
real packet admission and browser/terminal binding acceptance remain separate.

## Fault injection without replacing the protected decisions

Success/interference cases retain the actual `_connect` too. Interference uses
an independent private SQLite writer after preparation has closed, while all
source/creation/manager locks are unowned. Capture the changed raw rows before
allowing final confirmation; never patch the final helper to manufacture conflict.

For cases 6–12 only, a small delegating connection wrapper around the **original**
registry `_connect` injects commit/rollback/close acknowledgment faults. The real
path guards, SQLite connection, WAL/foreign-key setup and SQL remain in use.
Arm faults only on the connection that actually executes the fixed binding
`UPDATE records`, not the preparation audit's second commit or a global ordinal.
Record bounded phase/call counts. Its ordinary operations delegate unchanged;
`in_transaction` is the actual connection property. A failed rollback can be
injected before delegation, followed by a real close to avoid leaking a private
transaction. A close-ACK fault delegates close first and then raises once.

The lost-ACK branch calls real commit once before raising. For cases 8–9 only,
an independent private connection then changes the exact newly retained terminal
row. Preserve its original raw tuple and changed tuple; do not decrypt corrupted
bytes or substitute a generic witness result. The real read-only witness chooses
the outcome. No prepare/commit/audit/encryption/witness method is patched. This
tests acknowledged storage outcomes, not process death, disk failure or fsync.

## Cross-boundary assertions

- Freeze actual method identities before/after: prepare_patch_binding,
  commit_prepared_transition, `_selection_read_access`, phase begin/reenter/finish,
  `_transition_snapshot`, `_confirm_transition_witness`, `_open`, `_seal`, audit
  begin/finish/check_authority and the shared snapshot helper. Only the explicitly
  listed connection fault seam and sinks may differ in their cases.
- In the inert selected state callback, assert completed real preparation audit
  and closed preparation connection before projection; no source/creation/manager
  lock. For successful bus delivery, both access pairs are durable before output;
  all locks are unowned and manager generation agrees with installed availability.
- Audit events correlate to the response UUID. Normal success is preparation
  BEGIN/SUCCESS then mutation BEGIN/SUCCESS; confirmed rollback/interference ends
  ACCESS_FAILED. Each pair has its own BEGIN identity/reservation, same request
  UUID, exact action/schema/store/opaque target and no clinical fields. Preserve
  the old audit prefix byte-for-byte. Do not treat aggregate audit counts as
  fresh independent proof of every decrypt boundary; the actual checked methods
  are retained and their dedicated audit-order tests remain required.
- Compare raw records, pointer, subject identifiers and device index before/after.
  Only the bound target's prescribed version/update/ciphertext changes; every
  unrelated row and immutable creation/idempotency field stays exact. Independently
  decrypt only authored fixture data to compare the saved result with the 200 body
  or expected committed binding after 503. Do not call another public getter and
  silently contaminate the route's audit accounting.
- Assert no pending reservations after settled successful/failed access; explicitly
  preserve the pending reservation in the unconfirmed rollback case. Never repair
  intentionally damaged evidence. Unknown outcomes retain live inspection holders
  behind DENY_ALL; state/current-source/numerical access fails closed without
  executing a model. Distinguish store cleanup ACK from execution-owner cleanup.

After root approval, run only this new module in the documented private45-second
wrapper: bytecode/cache/auto-plugins disabled; socket connect/connect_ex/bind/listen,
DNS, urllib, child/native and model construction refused; internal TestClient
socketpair allowed. Report original result, exact test/source hashes and zero
unexpected I/O. Any actual integration defect returns to root before runtime
correction. No commit, broader test selection or whole-product claim follows.

## Root approval before test code

Root read all119 proposal lines and the actual prepared registry, binding route
and startup integration fixture. Approved exactly the13 cases above, one new test
file and its private45-second run. Runtime and existing tests remain frozen;
intentionally damaged rows/audits must remain intact and no extra public getter
may contaminate route audit accounting. Final identity checks retain the actual
prepare/commit, selection read/phase helpers, transition snapshot/witness,
encryption `_open`/`_seal`, audit begin/finish/check_authority, authority/fence and
shared snapshot implementations. Connection fault delegation, inert model state
and recording bus sinks are the only authored seams. Root will independently
read and repeat the finished packet; the test author will not grade its own work.

Root approved one observation precision before the run: success/interference
cases keep actual `_connect`; completed preparation audit plus an independent
BEGIN IMMEDIATE/rollback proves the preparation writer lock is released, not an
observed close syscall. Dedicated helper tests retain the close obligation.
Only the approved fault wrappers directly count delegated closes. No extra seam
is added to manufacture a stronger close-observation claim.
