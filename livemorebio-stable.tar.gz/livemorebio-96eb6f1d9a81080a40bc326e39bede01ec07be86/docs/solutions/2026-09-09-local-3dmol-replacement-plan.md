# Local 3Dmol molecular delivery replacement

2026-09-09. Finite renderer-adapter replacement under the user's instruction to
replace the repeatedly failed delivery path. No biological equation, structure
admission, mutation or source-identity change. Root owns actual browser QA.

## Fixed artifact and source findings

Use the official published `3dmol@2.5.5` package, not a floating CDN URL or a
local rebuild. Registry tarball SHA-512 is
`92a347a2e1aaab761f5b9f35ef8b5d111be6d1761398fd2d6af40a3aa230d68b9cd8e27b7a9917105aed1245575747250594f665edb11d10bfab15f4bb4a8277`,
matching published SRI. Its self-contained `build/3Dmol.es6-min.js` is 543,928
bytes, SHA-256 `95513f6494717cc82fb2ba4d264f29b7ef189a31d4ece36a38d1f9666bf6d427`.
Npm gitHead is `a7812cead387b92ed12b606c249aa14238f9b343`; do not equate it with
the differently pointed Git tag. No install scripts or rebuild were executed.

Upstream LICENSE is BSD-3-Clause with retained GLmol MIT option, Three.js and
jQuery MIT notices. The matching unminified bundle identifies iobuffer,
netcdfjs, pako, upng-js and nested pako, plus an MIT FXAA shader via
Molstar/Rendu. Retain their applicable notices alongside unchanged bundle and
upstream LICENSE; the generated 120-byte banner alone is not the license.
No active remote download API, surface worker, trajectory, animation, callback
string evaluation or autoload element is used. Root independently reviews the
finite notices before delivery acceptance.

Primary sources: https://registry.npmjs.org/3dmol/2.5.5,
https://3dmol.org/doc/, and source included in that exact npm tarball.

## Minimal implementation

1. Add a narrow local adapter and fixed `srcdoc` child document containing only
   authored markup and a fixed same-origin module URL, never source text or
   untrusted metadata interpolated as markup. 3Dmol exposes `clear`
   but no public viewer-dispose method; the adapter owns a same-origin frame,
   clears resources, explicitly loses its canvas context when available, then
   removes the frame. Removing the document retires its upstream window/body
   handlers and observers. No postMessage protocol or parallel owner framework.
   The existing inspector continues to own deadline, abort, epoch, source hash,
   body completion and cleanup acknowledgement. Existing Molstar adapter branch
   remains intact for its existing injected consumers/tests, not as CDN fallback.
2. Use only the loader-verified original CIF text and descriptor. Exact published
   CIF parser ignores per-row model number: admit only the existing single-model
   descriptor `[1]`, selected model 1/index 0, validate parsed atom count against
   `atom_site_rows`, reject any other model topology. Do not silently merge an
   ensemble. No automatic biological assembly expansion, variant remapping,
   coordinate replacement, or inferred physiological effect.
3. Render actual coordinates with cartoon/stick choices, fit, atom selection
   labels and two-atom distance in angstroms. Show deposited author residue/chain
   labels as such, not canonical UniProt numbering. Static reference provenance
   stays in the existing inspector; 5VA2 is a deposited asymmetric chain, not
   the physiological tetramer and not a human-specific molecular state.
4. Implement the already reviewed ordinary Biology switch: persistent local
   inspector host, captured context/detail/organ/connected trigger validation,
   synchronous context invalidation before STATE publication, no eager renderer,
   same-context refresh preservation, changed-organ/overview close, explicit
   READY-to-UNAVAILABLE close once, fixed failures and pagehide fence. Keep cells,
   anatomy and all existing targets unchanged. No remote Molstar fallback.

## RED-first verification and ownership

Before runtime changes add tests for real pinned CIF parsing/counts, unsupported
model refusal, adapter lifecycle/abort/cleanup, real inspector adapter branch,
and ordinary caller identity/reconciliation. Retain old tests and extend only
their actual import seam. Offline Node/controller tests are not WebGL proof.
Root then independently reviews and uses the actual ordinary page, plus shared
fixed/frozen contexts, keyboard, close/reopen, source label and distance controls.

Owned implementation: ordinary `biology.html`, `molecular_inspector.js`, new
`molecular_3dmol*` local adapter/document/CSS, vendor directory and affected UI
tests. Root owns catalog/server/package-data wiring. Fixed `srcdoc` avoids an
HTML MIME route change. No server/browser/biological/native/model run in this maker lane.
