# Confirmed LIFE binding: frozen implementation packet

2026-09-08. Maker: root. Independent implementation review is pending. This is
the next route family in the approved full recovery, not a new device policy or
model implementation. No R01–R51 requirement is closed and all six experiment
recordings remain outstanding.

## Reviewed plan and exact runtime change

Root read the complete binding refinement and both independent appendices, the
actual registry normalization/prepared/commit interface, authority and current
availability/snapshot consumers, governed observation ingestion, and all524 lines
of the independent test author's new packet before implementation.

Only `server.bind_twin_patch` changed in this increment. Its complete strict body
and safely incrementable version are validated before dependency acquisition.
The existing pure binding normalizer preserves defaults and physical policy.
Registry preparation and exact four-field active-source agreement occur under
source authority; numerical construction does not occur at all.

Selected binding captures actual model availability, rejecting inconsistent
identity/readiness rather than deriving new readiness from a source record.
Because the modeless accessor refreshes generation, its raw cached generation
is checked first. The live-model path retains its derived current availability
so ordinary stimulus generation changes do not falsely reject an older cache.
The existing typed startup-unavailability reason is retained.

The base `ObservationState.state` method captures one detached packet/measurement
pair under its ingestion guard. It does not call the overridden numerical state
method. Numerical projection and a modeless projection-only holder run outside
all source/creation/manager guards; their observation fields are replaced from
that captured pair. Existing packet-admitted flags use that same pair, with no
new maturity claims or refreshed clocks. Malformed own parameters or existing
capability structures reject before commit. The installed live twin, observation
holder and actions are never replaced by the detached publication snapshot.

Final generation/source rechecks precede the actual prepared registry commit.
Confirmed selected binding installs only its prepared state shell and source
generation. Confirmed unselected binding leaves active memory/fence untouched.
Unknown completion installs DENY_ALL and retains the prior live holders behind
that denial without publishing speculative identity. Cleanup is after the guard;
confirmed binding survives cleanup failure and closed-manager ownership remains
retained. Only confirmed selected binding publishes its explicit prepared snapshot,
never the shared helper's implicit current-state fallback. Responses carry the
same request UUID throughout local failure/commit handling.

No changes to registry/audit/bootstrap, model equations/parameters, observation
normalization, physical transport, shared snapshot helper, UI, SDK or device
qualification. The only existing test fixture edit was independently authored:
the minimal ready twin now has explicit empty patch/observations attributes.

## Frozen identities

| File | SHA256 |
|---|---|
| server.py | 3d521a029bccf5d9069a4e78806d40fbf895aca3b3cf6b6f370ad9500645676d |
| test_confirmed_binding_publication.py | 3859aaf9b6ff8535268182ac0fd3bb95574a119bfa87f95b63ef64cd0212c4c6 |
| test_committed_source_transitions.py | 896837d1fde3eaa1b0861b04445f9e2ca25fb0612a20e4ac5d9f22cda11e65c6 |
| confirmed-binding-publication-plan.md | 1a0b1bb48ef19a997b01366ba77eb95b372f9e4bf389944dc7bfeeb5f193efc2 |

## Technical evidence, not biological qualification

All invocations use the established private45-second ASGI-compatible refusal
wrapper: no network/DNS/listeners/child/native work; internal TestClient socketpair
allowed; numerical constructors refused; authored records only. Each run below
recorded zero unexpected I/O/process attempts and one refused optional Git lookup.
The three existing FastAPI/Starlette deprecation warnings remain unchanged.

| Selection | Result | Private suffix |
|---|---|---|
| Existing binding baseline, before runtime edit | 25FAIL,4PASS,25DESELECT /1.57s | j2qdtzy7 |
| New35 authored cases, before runtime edit (test author) | 35FAIL /10.80s | 5fd0yav1 |
| Activation baseline after fixture-only augmentation | 31PASS,41DESELECT /1.49s | dajuezjx |
| New35 after root implementation | 35PASS /1.50s | m13fbb6j |
| Existing binding selection after implementation | 29PASS,25DESELECT /1.60s | 781feerx |
| Startup69 plus real-registry integration10 | 79PASS /2.78s | 74d89qu4 |

The existing binding selector is `patches or binding` in
`test_committed_source_transitions.py` and `test_legacy_transition_admission.py`:
28 binding cases plus one previously green different-target activation case.
The new RED cases first failed at the old lock boundary; their later assertions
were not individually reached by that old implementation. Green exercises actual
source/fence guards, base observation copying and snapshot helper with record-only
bus sinks. The closed-manager owner is an authored Python sentinel, not an OS
lock/native worker or a claim of physical telemetry admission.

For independent repeats, use the existing activation report's isolated wrapper:
new test module without `-k`; the above two modules with `-k 'patches or binding'`;
the exact activation31 selector; and startup69 plus the real-registry10 module.
Do not broaden collection to native model tests or services. `git diff --check`
passed. The preserved full UI matrix is not rerun or accepted by these checks.

## Remaining work and compound lesson

Independent code review/repeats, actual registry-to-binding integration, browser
and terminal binding acceptance remain. Preview, observation-only selection and
reconciliation migration are still open; so are complete UI/biology/LIFE/Cendos
workflows, six programs, recordings, guides, deck and release gates. No commit,
push, PR, installed pointer, running service or operational store was changed.

Lesson: source identity and observation freshness are different. A binding can
preserve a live holder yet publish mismatched packet metadata if its observation
fields are read across a concurrent update. Capture one coherent observational
sample, preserve its timestamps and publish a detached attributed snapshot while
leaving later observations in the actual live holder. Reviewed local plans and
this durable lesson remain the fallback for unavailable CE/gbrain tools.

## Independent frozen-route grade — source_research

2026-09-08. **CLEAR in this bounded binding publication increment.** No remaining
actionable defect was found in the reviewed route. This does not close an R01–R51
item, qualify a physical device or numerical model, or replace actual binding
integration/browser/terminal acceptance. Original RED receipts remain preserved.

Read the entire report and approved refinement, the full changed route, all524
new test lines, existing binding/strict-admission assertions, and the actual pure
normalizer, prepared-record properties, authority/creation/manager fence, retained
closed-manager invalidation/shutdown, current availability, observation holder,
governed telemetry normalization and explicit snapshot helper. The new startup
real-registry test module and its independent report were also read before the
preservation repeat. No runtime or test source was edited during this grade.

### Independent repeats

Used the documented45-second ASGI-compatible wrapper and pinned fresh-venv Python
in four separate private processes. Bytecode/cache/automatic plugins remained
disabled; network, DNS, listeners, urllib, subprocess/native work and actual model
constructors were refused. TestClient's internal socketpair remained allowed.
Every process exited0, cancelled its alarm and reported zero unexpected I/O plus
one exact refused optional Git metadata lookup.

| Packet | Independent result | Private review suffix |
|---|---|---|
| New binding module | 35PASS,3 existing warnings /1.45s | bijg0f01 |
| Existing `patches or binding` selection | 29PASS,25DESELECT,3 existing warnings /1.38s | bus39vt1 |
| Exact activation preservation selector | 31PASS,41DESELECT,3 existing warnings /1.29s | b1vku_54 |
| Exact startup69 plus checked-registry integration10 | 79PASS,3 existing warnings /1.93s | znhxecmr |

Selections and refusal machinery are exactly those specified above and in the
activation/startup reports. Deselections are not counted as passes, and overlapping
preservation packets are not a new distinct-case total. No child/native worker,
browser, service or operational store was used; the ten startup integration cases
use real SQLite/encryption/audits only on their authored private databases.

### Source mechanisms verified

- Strict bounded duplicate-rejecting parsing, exact incrementable version and
  existing pure string normalization occur before the registry getter. Local
  failures, conflicts and acknowledgment alternatives preserve the route UUID and
  no-store headers without raw exception details.
- Initial and final four-field source agreement plus generation recheck precede
  the exact prepared commit. Storage-selected versus unselected status comes
  from the prepared topology, not an independent memory-ID shortcut.
- A modeless raw generation is checked before the accessor can refresh it. The
  strict captured availability retains its actual typed reason/mode/readiness,
  not a new structural READY inference. Live-model metadata remains derived from
  the current source; no model construction or recalibration occurs.
- The exact base observation method captures only patch/observations while the
  authority guard excludes governed ingestion. Outside-lock projection overrides
  both fields and the existing packet-admitted flag from that one detached
  sample. New sample B remains in the original installed holder while published
  sample A retains its copied values/timestamps. The tests establish this copy
  contract using authored rows, not actual v2/v3 packet admission or normalization.
- Confirmed selected state and assignment-only fence are visible at the original
  committing guard's exit. Confirmed rollback and unselected success/close failure
  preserve active state. Unknown completion, including an unselected binding,
  installs DENY_ALL and sends no speculative snapshot or automatic retry.
- Old state/actions remain retained through publication and are released outside
  locks. Captured old-generation invalidation and best-effort explicit snapshot
  publication are outside authority/creation/manager guards. A later winner keeps
  its state while the older operation publishes only its own detached parameters
  and availability. A closed manager is neither reopened nor silently detached;
  its unresolved ownership survives until the explicit successful cleanup retry.

After the four repeats, all frozen values in the table matched exactly, including
server `3d521a029bccf5d9069a4e78806d40fbf895aca3b3cf6b6f370ad9500645676d`,
new tests `3859aaf9b6ff8535268182ac0fd3bb95574a119bfa87f95b63ef64cd0212c4c6`
and existing fixture `896837d1fde3eaa1b0861b04445f9e2ca25fb0612a20e4ac5d9f22cda11e65c6`.
The separately cleared execution/subjects/audit and startup-integration hashes
also matched `2caafc14…`, `0a8eaee9…`, `b21f01fd…` and `cfdea590…` respectively.

Next required evidence is actual prepared-registry-to-binding integration with
authored private records, followed by independently authorized user-facing
acceptance. Older preview/observation/reconciliation families remain open. The
lesson is that coherent copied evidence and preserved live holders are distinct
requirements; neither requires moving numerical projection into the source lock.
