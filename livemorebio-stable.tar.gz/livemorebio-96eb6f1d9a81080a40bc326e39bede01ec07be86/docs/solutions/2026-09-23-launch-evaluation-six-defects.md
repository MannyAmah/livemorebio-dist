# Launching the existing system surfaced six defects that no test could see

Date: 2026-09-23
Scope: LivemoreBio Aegle / LIFE / Cendos, evaluation launch of the current build

## What happened

The full suite was green and `livemore doctor` reported READY, yet launching the
stack the way an operator launches it and walking the console broke in six
distinct places. Every one lived in the gap between "the code is correct" and
"the product runs": process wiring, environment, and error propagation.

## The six defects

1. **`livemore workspace` crashed** on a record with no admitted model binding.
   `active_execution` is legitimately `None`; the formatter indexed it anyway.
   *No admitted binding is a reportable state, not an error.*

2. **Continuous execution was unavailable in a normal launch.** The launcher
   never set `LIVEMORE_EXECUTION_STORE`, `LIVEMORE_VIRTUAL_EXECUTION_STORE` or
   `LIVEMORE_PATCH_JOURNAL`, so the services refused work that the test harness
   always configured for itself. Tests supplied the very thing that was missing.

3. **Split module state.** The launcher ran services as `python -m pkg.mod`, so
   the file executed as `__main__`. Routers doing `from . import server` then
   imported a *second copy* with its own selected state and model authority.
   `/api/state` answered READY while `/api/executions/capabilities` answered
   UNAVAILABLE — the same process disagreeing with itself.

4. **`EXECUTION_STORAGE` masked a `KeyError`.** `_model_availability()` read a
   key that exists only after selected state is restored. Storage was healthy;
   the operator was told to inspect storage.

5. **Service log files stayed empty** while the services ran, because their
   output was block-buffered into a file. During an incident the operator's
   first move — read the log — returned nothing.

6. **The closed loop blocked with an unactionable code.** A virtual probe must
   be bound to the twin in Aegle *before* streaming. Unbound, the session
   blocked with `EXECUTION_UNAVAILABLE`, and the real reason was discarded at
   three separate hops.

## The lesson

Defects 4 and 6 are the same mistake twice: **a typed refusal was replaced by a
generic one at a boundary.** Each hop caught a specific exception and re-raised
a blanket code, so a prerequisite the operator could have satisfied in one call
arrived as "unavailable". The fix is not more logging — it is to carry the code
across the boundary from a closed allow-list of fixed strings, never a message
or a body, so nothing leaks while the reason survives.

Defects 2 and 3 are the same mistake in the other direction: **the test harness
was doing work the product does not do.** Any environment a test constructs for
itself is an environment the launcher must construct too, or the suite is
testing a system that never ships.

## What to do next time

- Launch the product the way an operator launches it, before believing a
  green suite. A passing test proves the code path works given the harness's
  setup; it says nothing about whether the launcher performs that setup.
- When a boundary catches an exception, ask what the caller can *do* with the
  code it emits. `EXECUTION_UNAVAILABLE` is an answer of last resort.
- A service whose log file is empty is not quiet; it is unobservable.

See also: [[livemore-honest-refusal-pattern]], [[livemore-six-program-status]]

---

## Addendum, same day: the client could not install at all

Two further defects, both found by acting as a client rather than as the author.

**The repository is private, so the documented install command returned 404 for
everyone outside the org** — including `install.sh` itself, which was fetched
from a GitHub raw URL. The product had a one-line installer that no prospective
client could run. The installer now resolves a published channel manifest over
plain HTTPS and verifies the archive's SHA-256 before unpacking; `gh` is needed
only when `LIVEMORE_REF` asks for a repository ref.

**A client without Node.js could not install.** The installer runs the full
suite and refuses on any failure. Ninety-five tests called `node` directly —
`assert shutil.which("node")`, or `subprocess.run(["node", ...])` — even though
`_toolchain.node_executable()` and `tests/_node.require_node()` already existed
to skip when it is absent. Node was never a documented prerequisite, and the
product does not need it at runtime.

The lesson is the same one in a third costume: **the author's machine has
things the client's does not.** A green suite proves the code works given
everything the author happens to have installed. Node was on this machine, on
CI, and in every previous verification run, so nothing ever failed.

Worth noting what worked: `tools/check_atlas_presentation.py` already refused
with a typed `NODE_NOT_AVAILABLE` rather than crashing. The product handled the
missing dependency honestly; only the tests assumed it.

### What to do next time

- Verify with the dependency *removed*, not merely unused. Stripping `node`
  from `PATH` was not enough — `_toolchain` has hardcoded fallback paths and
  found it anyway. The real test was forcing the resolver to report none.
- A prerequisite that is not in the install guide must not be able to fail the
  install. If a test needs a tool the client was never asked to install, that
  test skips.
- When a helper exists for exactly this (`require_node`), drift toward the raw
  call is the defect. Fourteen files had grown their own.

### Verified

A client-shaped install now completes end to end: bare URL over HTTPS, `gh`
absent from `PATH`, Node removed at the resolver, checksum pinned out of band.

```
Resolving the published stable release...
Archive checksum verified.
5609 passed, 955 skipped, 0 failed
Installation complete.
```

`livemore doctor` reports `READY`, and the programs produce the same numbers as
the development checkout — insulin ΔAUC −1700.421 with 1 of 12 below 3.9, and
bilberry at the studied dose reaching its active range at margin 1.41 while
reporting `robust_to_one_standard_error: false`.

Three attempts before it failed at dependency download, on a large wheel, with
PyPI answering at roughly 367 KB/s. That was the network here, not the product:
the installer refused each time and left the previous release untouched, which
is the behaviour it is supposed to have. It is worth separating the two, because
a failing install that refuses cleanly is not the same kind of event as one that
half-completes — and only the second is a defect.
