# Molecular inspector: dependency, licensing and request-graph review

Date: 2026-09-08. **Read-only source review, not packaging or browser acceptance.**
Scope is section A of the
[remaining Atlas proposal](2026-09-08-atlas-remaining-dependency-visual-proposal.md).
No package, font or structure was acquired, installed or vendored. No product
service, participant query, model or browser QA was run. The gstack browse binary
was attempted for the official source page and exited 137 without output; primary
source pages were then read through the available web tool. Context7/gbrain were
not callable. The old Atlas failure and unrun gates remain unchanged.

## Decision

Keep the molecular inspector. A same-origin structure-only Molstar build is
feasible in principle, but **the distributable artifact is not yet admitted**.
Removing the CDN tags without replacing their functionality is not completion;
copying just `molstar.js` and MIT LICENSE also does not establish dependency or
network closure. Prefer existing system-font fallback for the first correction.
Font packaging can follow with separately pinned binaries and notices.

## 1. What exists locally

The product references Molstar 4.4.0 remotely. No Molstar package or font binary
was found in this worktree, `/Users/emman/Livemore/node_modules/molstar`, or the
known gstack Node dependency directory. The bounded npm cache-index search also
found no Molstar entry. This is not a claim to have searched all private folders
or browser caches. The installed structure-viewer plugin is a different artifact,
not an admitted source for redistribution into Livemore; none was copied.

Hashes measured from the current local files:

| Relative file | SHA-256 |
| --- | --- |
| `livemorebio/aegle/console/biology.html` | `8bbc7c9fc3f57790b9866559162514372ebfbc03c840c5c47a1432e1543163cc` |
| `livemorebio/aegle/console/lib/design.css` | `815cce7fdc339be9dcf196c64e7a892cdc156eca168b47a64662e6ed36c3fd82` |
| `livemorebio/aegle/console/lib/protocol_biology.js` | `0b59d25e6e6109420b4138d5d787ee765185e335ccd8e38d028873a36579a1a8` |
| `livemorebio/aegle/console/lib/continuous_execution.js` | `868563126ccf48222c499c731cf576f7006111b465a09d5c6add768d97261aab` |
| `livemorebio/aegle/console/lib/anatomy_loader.js` | `7406f75e45cff609630e058d79256e5085fcdbfec9b65ca299601f0f97451777` |
| `livemorebio/life_system/reference/sources/rcsb.py` | `a94af6a96103b771ae7bf08a6ac636c4dbac757ba324fd422a5e9fdb3c6c3c95` |
| `livemorebio/life_system/reference/seed/structures.json` | `ea1ec2b2b63beb0a799f2e2c65d5813cbc48128873a04a9cfbc86ad43309b572` |
| `pyproject.toml` | `63b6fb41972dfd143eb8415d1cb7354ebecb2f4cdde3115c3eef320214cc779f` |

These identify inspected application files, **not** downloaded Molstar or font
bytes. No upstream tarball/SRI, compiled JS/CSS, transitive lockfile, emitted image,
font or notice hash was measured. Root is changing unrelated server code, so line
numbers there are descriptive, not a frozen server release identity.

## 2. Actual request graph from current source

| Entry/action | Browser request path | Additional behavior |
| --- | --- | --- |
| Every `/biology` document, including `run_id` and `execution_id` | Google Fonts CSS; jsDelivr Molstar 4.4.0 CSS; local design/continuous CSS and local JS | External styles load before the mode branch. Google Fonts can resolve further font requests; exact served font files were not fetched. |
| Ordinary current-context Biology | `/api/biology`; local anatomy loader/vendor; same-origin `/assets/anatomy/*.glb` | Context checks and bounded graphics retries already exist. Opening the cardiac cell also requests `/api/state`. |
| Saved-run Biology | `/api/cendos/protocols/{run_id}`; reference anatomy request for supported run anatomy; local modules/meshes | Ordinary live-context block does not run. Molecular references are currently textual; no shared clickable molecular inspector is mounted in this branch. |
| Fixed-execution Biology | execution status/frames and optional LIFE-session APIs; `/api/biology/reference`; local modules/meshes | No active-twin fallback. Molecular references are text inside the reference inspector, not the ordinary `_mol` function. |
| Shared chrome | `/api/session/bootstrap`, `/api/build`, `/api/services` | Same-origin browser traffic. Services health polling can itself make configured server-side peer requests. |
| Ordinary molecular target click | `/api/structure?gene=...`, then lazy jsDelivr `molstar.js`, then `viewer.loadPdb` | The local response contains a PDB ID, not structure bytes. The viewer selects its own provider request. |

The ordinary `_mol` controller has no AbortController, request token or selected
target/context fence. A late result can create a viewer after Close or overwrite
a newer target. It does not check the structure response HTTP status before JSON.
Its error branch renders a raw exception message. Those are source findings,
not browser-reproduced failures in this review. A replacement shared controller
needs explicit lifecycle tests rather than inheriting this implementation.

### The server adapter is not currently a governed local structure store

`server.py::api_structure` performs two sequential requests: UniProt search,
then PDBe `best_structures`. It takes the first accession and first structure.
It has per-open 12-second timeouts but no explicit response byte limits, total
deadline, redirect restriction, content hash/cache manifest, authenticated access
or encrypted access audit. `gene` has no bounded curated-identifier admission;
URL encoding does not prevent it from changing UniProt query semantics. Its
error response exposes exception text and collapses failure into `pdb:null`.
It neither downloads nor serves a coordinate file. The separate RCSB adapter
also returns metadata only. Neither should be advertised as ready for a protected
local structure-byte route.

The seed's INS record is **4INS, titled pig insulin**, not a guaranteed human
structure. The current target list also includes family/alias labels such as
AMPK and GLUT1. Do not silently turn these into a unique human gene, chain or
patient molecule. Preserve exact source organism, entity/chain, construct,
coverage, experimental method and missing regions with any selected structure.

## 3. Verified Molstar pin and executable API facts

The upstream 4.4.0 release points to commit
`2b2dfd924589edce7b129e123323c87a4623bdb8`. Its package includes `lib/` and
`build/viewer/`; it declares ranges for dependencies, not a complete reproducible
resolved bundle. [Release](https://github.com/molstar/molstar/releases/tag/v4.4.0),
[commit](https://github.com/molstar/molstar/commit/2b2dfd924589edce7b129e123323c87a4623bdb8),
[package](https://github.com/molstar/molstar/blob/v4.4.0/package.json).

The pinned API supports `Viewer.create`, `loadStructureFromUrl`,
`loadStructureFromData(data, format, options)` and `dispose`. The data method
passes supplied data to the parser without resolving a PDB ID. Viewer defaults
enable all extension entries, remote-state UI and other optional features.
`extensions:[]`, `layoutShowRemoteState:false` and `volumeStreamingDisabled:true`
are real options, but they do not prove that the compiled dependency graph or
every default behavior is offline.
[Pinned Viewer API](https://github.com/molstar/molstar/blob/2b2dfd924589edce7b129e123323c87a4623bdb8/src/apps/viewer/app.ts).

The default PDB provider is PDBe. `loadPdb` therefore resolves its default binary
coordinate variant through `https://www.ebi.ac.uk/pdbe/entry-files/download/{id}.bcif`.
State-server and volume-server defaults are separate external origins. Local
structure data and explicit disabled features are preferable to an implicit
provider URL. [Configuration](https://github.com/molstar/molstar/blob/v4.4.0/src/mol-plugin/config.ts),
[download action](https://github.com/molstar/molstar/blob/v4.4.0/src/mol-plugin-state/actions/structure.ts).

### Licensing and emitted assets, not merely the top-level label

- Molstar's MIT license permits commercial redistribution with its copyright
  and permission notice retained. It is not a license for third-party datasets.
  [Exact release license](https://github.com/molstar/molstar/blob/v4.4.0/LICENSE).
- The viewer statically imports the MP4 extension, which imports
  `h264-mp4-encoder`. Its upstream wrapper is MIT, but its author identifies a
  public-domain encoder and **MPL 1.1 libmp4v2** underneath, with embedded WASM.
  Do not call a full redistributed bundle MIT-only; verify actual resolved
  versions, retained notices and any corresponding-source obligation. Disabling
  the feature at runtime does not remove distributed bytes.
  [Pinned import](https://github.com/molstar/molstar/blob/2b2dfd924589edce7b129e123323c87a4623bdb8/src/extensions/mp4-export/encoder.ts),
  [encoder author documentation](https://github.com/TrevorSundberg/h264-mp4-encoder).
- The viewer entry also emits HTML/favicon, CSS and potentially image files.
  Webpack sets relative asset paths and hashed image names. The backgrounds
  extension imports cell and skybox images; its source comments identify the
  cell image as public-domain and the skybox generator, not a full independent
  redistribution review of every output. Check actual emitted artifacts before
  admission. [Entry](https://github.com/molstar/molstar/blob/v4.4.0/src/apps/viewer/index.ts),
  [webpack](https://github.com/molstar/molstar/blob/v4.4.0/webpack.config.common.js),
  [backgrounds](https://github.com/molstar/molstar/blob/v4.4.0/src/extensions/backgrounds/index.ts).
- The skin uses a system-font stack and includes normalize.css 3.0.3 with its MIT
  notice. It does not require Livemore's Google Fonts request.
  [Base skin](https://github.com/molstar/molstar/blob/v4.4.0/src/mol-plugin-ui/skin/base/base.scss),
  [normalization notice](https://github.com/molstar/molstar/blob/v4.4.0/src/mol-plugin-ui/skin/base/normalize.scss).

**Not verified:** actual npm archive integrity, exact transitive package versions,
every bundled notice/image/embedded-WASM license, byte sizes, CSP compatibility,
WebGL performance or runtime network closure. Package acquisition and build are
separate approval steps, not implied by this review.

## 4. Fonts and public structure rights

The page already declares `Geist,sans-serif`, `Fraunces,serif` and
`JetBrains Mono,monospace`; design.css additionally supplies installed-system
fallbacks. Removing only the remote font stylesheet can therefore retain those
declared fallbacks without copying any font. Text metrics will differ by OS;
desktop/mobile enlarged-text acceptance must measure the actual result.

Current primary font notices identify all three under SIL OFL 1.1. Later local
bundling must retain each copyright/license, pin exact font files/axes/weights,
and review reserved-name requirements before any modification or conversion.
The mutable Google CSS URL is not an exact binary release pin. No font bytes or
hashes were admitted here. [Fraunces](https://github.com/google/fonts/blob/main/ofl/fraunces/OFL.txt),
[Geist](https://github.com/google/fonts/blob/main/ofl/geist/OFL.txt),
[JetBrains Mono](https://github.com/JetBrains/JetBrainsMono/blob/master/OFL.txt).

The PDB archive data files are available under CC0; original structure-author
attribution is encouraged. That does not erase provenance, experimental scope
or quality limitations. [wwPDB usage policy](https://www.wwpdb.org/about/usage-policies).
UniProt and PDBe mapping/annotation terms require their own retained source
review if the new route continues using those services. UniProt's license page
returned only its JS fallback in this run; no new license finding is claimed
from that inaccessible body.

## 5. Proposed next increment and stop gates

1. **Approve an isolated acquisition/build review**, not immediate vendoring:
   fixed upstream commit/package integrity, resolved lockfile, SBOM/notices,
   output manifest with SHA-256/size for every included file. Prefer a small
   structure-only entry, omitting MP4/background/remote-import extensions at
   build time while retaining rotation, zoom, selection and structural inspection.
   Keep reference coordinate inspection separate from biological motion.
2. **Root-owned protected structure route:** allow only reviewed public target
   mappings or immutable admitted structure IDs, never arbitrary URLs or patient
   fields. Specify byte/time/redirect/host/format/atom bounds before code; freeze
   metadata and coordinate bytes together, with original source/revision/hash,
   chain/entity/taxon and evidence class. Require local auth, no-store access
   responses, safe errors and appropriate audit. A missing mapping is unavailable,
   not an automatic alternate species or predicted structure.
3. **Browser-owned bounded fetch:** fetch only that local route, verify the
   response identity/hash/format, then pass exact admitted data to the parser.
   Do not use `loadPdb`, arbitrary snapshots or MVS URLs that can resolve further
   resources. Restrict the plugin's action/behavior surface and preserve the
   same-origin firewall. Close/new-target/context change invalidates pending
   publication and disposes any late-created viewer; retry is explicit.
4. **Wheel completeness:** current package-data covers only flat `.js`/`.css`
   under `console/lib`. New nested vendor assets, licenses/manifests or fonts
   need explicit package inclusion and installed-wheel route/hash tests. A dev
   checkout rendering is not proof that an installed product contains them.
5. **Independent acceptance:** block every external request across ordinary,
   run-bound and execution-bound entry/target/close/retry cycles; assert local
   requests finish or fail distinctly. Test unavailable/corrupt/oversize assets,
   out-of-order targets, close-during-load, no stale viewer, no live-twin borrowing,
   five disposal cycles and keyboard/mobile/font-fallback layout. Saved/execution
   molecule inspection is new wiring, not already supplied by `_mol`.

Lesson: source-hosted assets, remotely resolved data and optional viewer features
are three different dependency surfaces. Pinning a library version addresses
none of their complete closure by itself. **DONE_WITH_CONCERNS:** actionable
source review completed; licensing artifact admission and behavior QA remain open.
