# Transition-owned audit phases — minimal shared correction proposal

2026-09-08. **Pre-code; root approval required.** This responds to the three
[independently reproduced blockers](2026-09-08-committed-registry-audit-phase-independent-review.md).
The frozen subjects/audit/tests and all older reports remain unchanged. No new
transaction framework, cryptographic ledger, source eligibility, schema, model,
service or experiment is proposed.

Read in full the new
[startup checked-selection interface](2026-09-08-startup-checked-selection-interface-proposal.md).
Its immutable checked type, explicit internal keywords, exact final confirmation,
generation/initialized supersession and outside-lock construction are compatible
with this correction. Its steps1–2 need the BEGIN raw-preservation and re-entry
reservation checks below; its step4/failure path should call the same primitives,
not duplicate a weaker audited read.

## Exact ownership and bounded raw scope

Keep this code in `SubjectRegistry` in `subjects.py`. Existing corrected
`RegistryAudit.begin`, `check_authority`, `_verify_row` and `finish` are reused;
no normal audit payload/AAD/key/quota/public return change is needed.

Define one private immutable, non-repr origin value:

```python
@dataclass(frozen=True, repr=False)
class _SelectionAuditOrigin:
    reservation: AuditReservation
    begin_row: tuple[str, int, bytes, bytes]
```

The row is captured immediately after the corrected `audit.begin` has verified
its encryption-origin bytes and exact reservation, under the same writer with
no intervening write/callback. It is never reconstructed after committing BEGIN.
This is transient internal evidence, not a caller token or durable receipt.

Use a fixed scope `(target_id, device_fingerprint)`, each None or the existing
strictly validated identifier/digest. Startup uses `(None, None)`. Preparation
and mutation use the requested target and only the requested binding fingerprint.
No arbitrary SQL/table names, supplied callbacks or unbounded ID list.

A fresh raw audit baseline consists of:

- the exact active pointer tuple, including absence/timestamp;
- sorted union of the explicit target and the pointer's current target, at most
  two IDs; exact full raw SQL rows for those IDs, with missing rows represented;
- that one device-index row or its absence;
- the ordered TWIN ACTIVE IDs with existing LIMIT2 behavior.

Reuse `_raw_transition_evidence` for the fixed-ID reread. The baseline retains its
own IDs so comparison does not silently adopt a new pointer target after an audit
write. Capture the live pointer under the writer before deriving those IDs. Do
not decrypt clinical records to form this baseline, log it or export it. Apply
existing identifier/storage bounds; malformed pointer metadata fails closed,
without attempting an unrestricted record lookup. No clinical-table scan or new
index scan is introduced.

This is a bounded relevant-state preservation check, not detection of arbitrary
changes to every unrelated row/table in a corrupt SQLite file. It covers the
same selected/target/device/topology scope the operation is about. An expected
mutation SUCCESS uses the already independently constructed intended after-state
for every prepared row, not a fresh post-write baseline.

## Proposed three private primitives

Names may be adopted as written; freeze any materially different semantics before
code. They accept only the trusted connection owned by their fixed caller.

```python
def _selection_audit_begin(self, connection, *, target_id, device_fingerprint,
                           request_id, action, schema) -> _SelectionAuditOrigin: ...

def _selection_audit_reenter(self, connection,
                            origin: _SelectionAuditOrigin) -> str: ...

def _selection_audit_finish(self, connection, origin: _SelectionAuditOrigin,
                           *, outcome_code: str, expected_raw: tuple,
                           raw_ids: tuple[str, ...],
                           device_fingerprint: str | None) -> tuple: ...
```

These helpers do **not** independently commit or close. Their fixed owners retain
the returned origin/witness before immediately calling `commit`, so lost-ACK
handling still has its evidence. No write/callback is permitted between each
helper's final check and that commit. Existing owner-specific success, rollback,
uncertainty and cleanup semantics remain explicit rather than being hidden in a
generic callback runner.

### `_selection_audit_begin`: preserve the first durable audit transaction

1. Acquire BEGIN IMMEDIATE/the existing writer fence and check registry authority
   before raw preflight. A nonempty production authority token is mandatory.
2. Capture the fresh bounded raw baseline before the first BEGIN-event write.
   This permits encrypted/raw metadata preflight only; no protected clinical
   decryption may precede acknowledged durable BEGIN.
3. Call the existing corrected `audit.begin` with fixed allowlisted metadata.
   Capture its verified original event row and exact returned reservation.
4. Verify original BEGIN bytes, exact reservation pair, current reservation
   authority and the unchanged raw baseline after all event/reservation writes.
   Run the raw comparison last after any authority check. Return the origin.
5. The owner immediately commits. Only an acknowledged commit permits re-entry
   and protected access. A failed/lost BEGIN acknowledgment never admits a read
   or mutation; retain the original exception/transaction state for safe rollback
   and, only if appropriate, one reserved failure completion. Do not retry BEGIN.

An audit-only transaction has no authorized clinical/index change. An unexpected
side effect is rolled back before its first commit, not discovered after it has
already become durable. An unconfirmed rollback cannot be called preserved.

### `_selection_audit_reenter`: exact receipt before any protected access

Acquire the writer after the acknowledged BEGIN commit. Check authority against
the origin reservation, the exact original BEGIN tuple, and the exact
`(event_id, request_id)` reservation. Require both to remain present and unchanged.
Perform these checks before `_transition_snapshot`, `_open`, any intended
clinical mutation or caller yield. Deleted/substituted reservation and altered
BEGIN reject without decryption. Return the checked nonempty authority token.
The mutation caller additionally compares it with prepared authority as today;
checked startup confirmation compares it with captured authority.

No window without the SQLite writer exists between these checks and the read.
Legitimate intervening changes before writer acquisition are not undone: capture
mode may inspect the new state, while expected-snapshot/mutation mode conflicts.

### `_selection_audit_finish`: one exact last-write boundary

The owner supplies `expected_raw` from either a fresh pre-audit/read baseline
(audit-only transaction) or the validated intended after-state (mutation SUCCESS).
Before terminal work, require intact origin/reservation/authority and the expected
raw state. Call existing `audit.finish`, whose return is backed by its retained
encryption-origin tuple and reservation-delete check. Then:

- check current authority still equals origin authority;
- verify original BEGIN unchanged, exact verified terminal row/identity and
  reservation absence by both event and request;
- recompare the supplied raw state after every terminal/reservation/authority
  check, immediately before the owner's commit.

Return the two verified original/terminal rows for the existing mutation lost-ACK
witness. Do not invent a mutable last-event cache, trust a merely decryptable
replacement event, or recapture expected clinical state after the writes.
No protected clinical decryption occurs inside this primitive.

## One fixed read-only owner for preparation and checked startup

Add a private `_selection_read_access(...)` context manager taking only the fixed
scope plus the existing allowlisted action/schema/request metadata, and yielding
`(connection, checked_authority_token)` after acknowledged BEGIN and exact
re-entry. This is not a public/general mutation callback API. Its only callers
are the three `_prepare_transition` branches and the proposed checked startup
capture/confirmation path. No HTTP field can select it or supply executable work.

Before yielding, retain the fresh raw read baseline. The fixed caller may perform
the bounded `_transition_snapshot` and pure checked-snapshot comparisons only.
No model/profile/constructor/network/cleanup or clinical write is allowed. On
normal return, `_selection_audit_finish(..., SUCCESS, expected_raw=read_baseline)`
checks both caller and terminal side effects, followed immediately by commit.
Capture/prepared values return only after acknowledged terminal commit and close.

On error, confirm rollback first. If rollback is uncertain, do not start another
writer or label the clinical state preserved. Otherwise, if the committed origin
and exact reservation remain usable, reacquire writer/authority/origin, capture a
**fresh** raw baseline for the current target/current selected row/device/topology,
and use the same finish primitive with ACCESS_FAILED. Its commit is allowed only
after unchanged-state/origin/terminal checks. Failed failure-completion rolls back
without masking the primary error or pretending its reservation was consumed.
It may never use the old preparation/read baseline after releasing the writer.

This owner does not return an uncertain successful read. BEGIN/terminal commit
ACK loss, failed rollback or close authorizes no new capture/startup publication.
Use existing fixed audit/bootstrap/storage/selection-uncertainty codes with safe
messages. No plain exception may expose raw state or paths. The startup caller
keeps its generation/initialized guard so a stale failing starter cannot poison
a winning operator selection.

Leave `_audited` and existing unchecked callers unchanged. The correction is an
explicit caller migration to the private read-only owner, not a global behavioral
change to observation selection, reconciliation, cohorts or other registry APIs.
The proposed `_checked_selection_access` retains its exact checked-type validation
and confirmation logic inside this owner; it does not reimplement its audit phases.

## Mutation owner integration and phase coverage

`commit_prepared_transition` keeps its existing exact prepared validation,
clinical writer, intended after-state, single lost-ACK witness and cleanup result.
Replace its manual first BEGIN with the begin primitive and its re-entry checks
with the exact re-entry primitive. Use finish with the intended after-state for
SUCCESS and a newly captured baseline for its reserved ACCESS_FAILED attempt.
No constructor, generation publication or retirement moves into registry locks.

| Durable transaction | Required raw expectation |
|---|---|
| Preparation/checked-read BEGIN | Fresh unchanged live baseline before BEGIN writes |
| Preparation/checked-read SUCCESS | Baseline before the fixed protected-read body |
| Preparation/checked-read ACCESS_FAILED | Fresh baseline after confirmed rollback and new writer acquisition |
| Mutation BEGIN | Fresh unchanged live baseline before BEGIN writes |
| Mutation SUCCESS | Independently constructed complete intended after-state |
| Mutation ACCESS_FAILED | Fresh baseline after confirmed rollback and new writer acquisition |

For all read/mutation re-entry points, exact BEGIN **and** reservation precede
protected decryption. No later finish check substitutes for that admission check.
Unknown mutation durability retains DENY_ALL/inspect-required behavior; confirmed
mutation plus close failure remains COMMITTED_CLEANUP_UNCONFIRMED. A read-only
startup close failure remains nonpublication, not a successful capture.

## Red-first packet and limits

Preserve the current114 dedicated passes and all original terminal tests. Add:

1. The three exact independent reproductions, including `_open` count/trap for
   reservation removal; add wrong-request substitution, not deletion alone.
2. Triggers installed **before preparation**, affecting BEGIN and SUCCESS;
   exercise both audit-event and reservation INSERT/DELETE side effects.
3. Preparation failure plus ACCESS_FAILED side effect: old raw state preserved,
   no successful preparation, primary retained, reservation not falsely consumed.
4. Same target, demotion/current-selected row, pointer absence/timestamp, relevant
   device row and extra ACTIVE identity probes within the bounded scope.
5. Legitimate intervening record/pointer change before a failed-access writer:
   fresh baseline preserves that change; no comparison to or restoration of stale
   prepared state. No extra clinical decrypt during audit-only failure handling.
6. BEGIN/reservation changes after the durable commit reject before `_open`, in
   both new read owner and mutation owner; intact control reaches the real read.
7. Ordinary commit, lost mutation ACK, confirmed rollback, uncertain rollback,
   terminal/BEGIN ACK loss, close failure and primary-error preservation remain.
8. Startup true absence, orphan/multiple ACTIVE rejection, exact-row/authority
   confirmation and default-signature preservation use this owner, with the
   additional named matrix in the startup proposal. No actual model is needed.
9. Tripwires: socket construction/connect/DNS/urllib; subprocess plus direct
   multiprocessing entry and low-level fork/exec/spawn. Exclude the four named
   real-process bootstrap cases from this no-child review; any future OS run is
   a separate authorization and separately reported result.

Runtime write set after approval: only `subjects.py` private primitives/new read
owner and these explicit transition callers; `registry_audit.py` only if a small
private verification reuse is genuinely necessary and frozen before code.
Tests: existing `test_committed_registry_transitions.py` plus the already proposed
`test_checked_startup_selection.py` when startup implementation is authorized.
Root owns server publication/startup changes. No unrelated audited-call migration,
bootstrap adoption, profile/source equation, physical-v3, SDK/UI, OSP/Atlas change.

This proposal is not approval, implementation or acceptance. Root must read and
freeze it, makers author reds, and an independent reviewer grade the correction.
R01–R51 and the six programs are unchanged. Local prior-art/review lessons supply
the durable record; unavailable CE/gbrain tools were not claimed.
