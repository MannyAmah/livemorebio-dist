# R33 insulin: next source-admission increment after failed Stage B

2026-09-08. **Proposal only; no implementation or new execution authorized.**
This continues the existing exogenous-insulin program. It does not replace it
with a botanical, metformin, an isolated receptor assay or a glucose-only model.

## 1. Decision and preserved work

There is no presently demonstrated local importer, dose-conversion or comparison
bug whose correction would admit this insulin model. The next justified increment
is a **static, exact-ID source-contract packet**, completing the previously
unfinished event/initialization dependency audit. It must expose unresolved
dimensions and biological domains, not silently repair equations or pass v1.

This proposal incorporates, rather than repeats, the completed
[source diagnosis and 15-tissue audit](2026-09-08-osp-failed-benchmark-source-correction-review.md),
[native feasibility](../OSP_INSULIN_NATIVE_FEASIBILITY.md),
[frozen numerical preregistration](2026-09-08-osp-stage-b-numerical-benchmark.md)
and [failed Stage B results, including independent retained-array grading](../OSP_INSULIN_STAGE_B_RESULTS.md).
The original 15-run matrix and its negative-domain failures remain **FAILED**.
An installed native runtime is already demonstrated; another installation is not
the next scientific dependency.

## 2. What is established, and what is not a correction

| Question | Retained evidence | Consequence |
|---|---|---|
| I2/T2/C2 convergence | I1/I2 and C1/C2 pass; I0/I2, T1/T2, T0/T2 and C0/C2 fail. B2 is the comparison reference, not a candidate tested against an independently tighter run. | Do not call I2/T2/C2 converged merely because they completed without warnings. |
| State import | All 1073 independent values pass native t=0 transport. Of 27 formula initializations, only rectal liquid volume and the IVITT depot differ from I-final, with source explanations. | No evidence supports overwriting the 27 formulas or calling this complete 1100-state continuation. |
| Hepatic negatives | Original V11063 Glycogen starts at -12,639,308.8716699 µmol; V10939 b_N starts at -0.131815269016201 µmol. | Tightening numerical tolerances cannot remove a negative source initializer. Clamping changes the model. |
| Receptor units/domain | All 15 End-IR-en restoration terms add a concentration difference to an amount derivative with scale 1 and no explicit volume/time factor; PTP annotations create another dimensional concern. | Adding an arbitrary volume or turnover constant to F11299 is not a source-supported correction, and would leave analogous terms unresolved. |
| Different negative-state roles | Glycogen and SalivaGland insulin have no downstream RHS in the audited formula/parameter graph; b_N and End-IR-en do feed differential states. | Terminal signed-balance hypotheses cannot justify a blanket negative-state exemption or disposal of regulatory feedback. Event closure is still incomplete. |
| Exogenous exposure identity | The author case2 administers into shared `Insulin`; the separate `Insulin Ex` pool is not an administered-fraction tracer for this case. | Preserve that source-specific meaning. A plotted `Insulin Ex` curve cannot establish the injected formulation's exposure. |

The author recipe and native transformation retain the source-specific dose and
initialization rules. Current code/source hashes match the collection pins. The
existing tests cover transport, formula identity, recipe allowlists, units,
maximum-error comparisons, warning/tolerance rejection and source immutability.
This review did not rerun them. No new proven implementation defect is asserted.

### Numerical attribution remains unresolved

The unchanged scaled error is
`abs(a-b) / (1e-9 + 1e-4 * max(abs(a),abs(b)))`, in each quantity's native unit.
B1/B2 requires maximum <=1; B0/B2 requires <=10. Existing maxima are:

| Comparison | Maximum / failed points | Worst retained identity and time |
|---|---:|---|
| I0/I2 | 12.744436450096137 / 1 | Liver End-IR-en, `XfNRmePAdUqtWi-MaZANDw`, 3 min |
| I1/I2 | 0.6023419061936085 / 0 | Pass under the frozen gate |
| T1/T2 | 1.2636435516609532 / 1 | Pancreatic plasma insulin, `EXZ493VVFEqEEahV5kMP2A`, 60 min |
| T0/T2 | 73.19593842827959 / 197 | Pancreatic interstitial insulin, `uQEziranAU6S9in1qDdkEA`, 34 min |
| C0/C2 | 17.87138582145385 / 364 | Descending-colon luminal glucose, `H_CPLNsyEkmr2dPALCa7rQ`, 200 min |
| C1/C2 | 0.31742579229669105 / 0 | Pass under the frozen gate |

Root already independently recomputed these comparisons from retained arrays.
This continuation only inspected their worst rows and corresponding initial
values. The scaled t=0 differences for the four failing comparisons' worst
identities are respectively 0, 0.0030377480137690313, 1.9936281198563055 and
0.7676766703224758. These values localize growth of discrepancy; they do not
attribute it to one equation or integration setting. Every T/C branch uses its
corresponding I-branch snapshot, so initialization and subsequent integration
differ together. Exact T2 repeat and dense-output agreement do not separate them.

Retained I2/T2/C2 negative ledgers contain 26/15/14 distinct identities and
14,025/2,840/2,814 negative records, respectively; the union is 27 identities.
These are saved numerical values, not measurements. None receives a new domain
classification in this proposal.

## 3. Smallest next executable packet: static source admission only

**Prerequisite:** root and an independent reviewer approve this scope before new
parser/tests are authored. Use only pinned local source and retained JSON. No R,
.NET, solver, formula evaluator, event execution, model registration or network.
New diagnostic artifacts must be separate from all v1 files.

1. **Freeze the structural inventory and roots.** Preserve 1100 states, their
   1073 literal/27 formula initializations, declared units and original IDs.
   Roots are all 27 retained negative-state identities, all 15 End-IR-en
   restoration derivatives, the PTP/target-volume references and the hepatic
   response multipliers already identified in the prior audit. Resolve definitions
   from their direct XML lists; never let an RHS ID reference replace a definition.
2. **Complete event and initialization closure.** The pinned source has 33 events
   and 39 assignments: 16 marked `useAsValue=1` and 23 marked `useAsValue=0`.
   For example, event 14925 uses condition F14928 and assigns F14929 to V3376,
   F14930 to P3385 and F14931 to P3399. The latter two are not marked value-only.
   Preserve condition, target, replacement formula, mode and one-time flag.
   Build typed *possible-dependency* edges through every assignment and all 27
   initial formulas, in addition to ordinary formula/parameter/RHS edges. Do not
   infer whether an event fires, or treat a possible edge as an actual trajectory.
   Confirm mode semantics against retained native source/API evidence before a
   stronger interpretation; unknown modes remain unsupported, never ignored.
3. **Emit a non-admitting dimensional/domain ledger.** For each root, retain
   exact formula text/hash, aliases, literal units, downstream paths and affected
   events. Distinguish declared physical dimensions from an unproved normalized
   activity convention. Missing units must remain unknown, not silently become
   dimensionless. Show the 15 restoration concentration-versus-amount/time
   conflicts and PTP/hepatic multiplier conflicts explicitly. Proposed signed
   counters, transformed feedback and physical pools remain separate unresolved
   categories until exact source evidence supports each classification.
4. **Red-first structural tests and independent grading.** Technical fixtures
   cover a state referenced only through an event condition, event replacement
   of a parameter formula, an initialization-only path, namespace/definition
   collisions, duplicate IDs, absent references, unknown assignment modes,
   cycles and missing units. A cycle is retained as a graph property, not
   followed recursively without a bound or mistaken for an acyclic formula.
   Gate the pinned inventory and complete edge accounting. Failure must identify
   the exact source construct; no partial graph may be labeled complete.

This can resolve the **local completeness gap in the diagnostic contract**.
It cannot supply the missing biological constants or make a source unit typo's
intended correction unique. Static graph closure may disprove a terminal-counter
hypothesis; even a confirmed terminal role does not certify author intent or
retroactively pass the original domain gate.

## 4. Source decisions required before any biological repair

| Decision | Exact evidence still needed | Failure/stop condition |
|---|---|---|
| All 15 receptor restoration laws | Intended receptor pool, concentration-to-amount/time convention, synthesis/degradation or restoration rate law, initialized admissible states, and normalized-versus-amount interpretation of PTP/S_I. | No unique source-supported mapping: retain dimensional/domain failure; do not borrow a constant from another tissue or rat receptor model. |
| Hepatic regulation versus stored glycogen | Exact-ID domains/units for V10939, V10970 and V10978; whether V11063 is signed net balance or finite storage. A finite pool additionally needs initial storage and source-backed synthesis/depletion/precursor laws. | A renamed or signed chart variable is not repaired glycogen physiology; no replacement equation without parameters and independent review. |
| Salivary donor and oral net counters | Complete event closure and exact source declaration of bookkeeping versus finite amount. A finite gland needs replenishment/transport and matched exposure data. | No signed exemption based only on a terminal graph or name. |
| Native source replication | Original author-runtime/solver identity and all-state case2 reference export, events/reset semantics and unit conventions. Prior review found no published corrected XML; this turn made no fresh remote check. | Current-runtime repeatability alone cannot distinguish an inherited source defect from historical implementation conventions. |
| R33 individualized exogenous insulin | Exact formulation/potency and route/rate/timing, individual physiology and clearance context, paired exposure/glucose measurements and untouched validation data with provenance/uncertainty. | Generic clinical priors and this historical reference subject cannot stand in for missing individual inputs. |

Prepare these as internal exact-ID evidence questions; external contact,
supplement acquisition or alternate-source execution requires separate authority.
Source/runtime licensing already reviewed for isolated evaluation does not confer
rights to redistribute every reference dataset or a new model variant.

## 5. Conditional future numerical diagnostic, not an execution approval

If separately approved after the source-admission review, a new preregistration
may isolate T/C integration using **one frozen I2 independent-state snapshot**
across the existing B0/B1/B2 settings. Preserve all 27 formula reinitializations,
source case2/control inputs, full-state/unit/output grids and existing error
thresholds. Recheck actual native t=0 after import; unexplained differences stop
the diagnostic. Comparing those runs can distinguish common-initialization
behavior from the original end-to-end comparison, not prove biological truth.

This conditional diagnostic does not establish B2 accuracy, repair I0/I2 or remove
negative source states. A production numerical candidate would require its own
prospective candidate/reference identity and independently approved tighter
reference/comparison matrix. No precision, step-size or acceptance limit is chosen
here to obtain a pass. Source maximum step 60 min is a configured limit, not
evidence that a particular internal step occurred. Existing output agreement
cannot identify a unique integration/interpolation cause.

## Evidence pins and scope of this continuation

| Evidence | SHA256 |
|---|---|
| [Original XML](/tmp/livemore-osp-source.fmi3LG/GIM_Healthy.xml) | `e78bb23d39ce7138f46bb876a54b43becb79bbf833e50c0cd7006f2a80eac3cb` |
| [Author MATLAB recipe](/tmp/livemore-osp-source.fmi3LG/GIM_simulations.m) | `6cd652d8d2c23bceb5ed715625e614edc66fb0d46065c74c058a5e8560f0c2f0` |
| [Retained R recipe](/tmp/livemore-osp-native.mUlZwx/gim_recipe.R) | `68f0ab3f91e33a59fabc06c6169948ba8cf1bf78b927065105ab2704a3946de7` |
| [Frozen preregistration](2026-09-08-osp-stage-b-numerical-benchmark.md) | `91fe2f3d517878eecb1014023ac414287a8ff0c4dca9b6490f57611db669806d` |
| [Collection manifest](/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-osp-stage-b-81u4w4wd/manifest.json) | `1453aefe48b46a5e0ae9bceff931e21a45c590c6101309f1bad412b280344e58` |
| [Comparison summary](/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-osp-stage-b-81u4w4wd/analysis-v1/summary.json) | `84c7b70cd357e5032b1ba5726cac0fa0ff20e7e4b7ccb4585a27090b1213768e` |
| [C2 domain ledger](/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-osp-stage-b-81u4w4wd/analysis-v1/C2-domain.json) | `01af4abb74c354c4e1b94d2c3c299fcc6ee35f84b352c0ff2a64cfe76b9d0b4e` |
| [Collector](../../tools/osp_stage_b.py) | `a1bb8ac68aa746066f6ecdf9b45e27f77384465c1a114bc250eea96f35e1e0cc` |
| [Native wrapper](../../tools/osp_stage_b_native.R) | `6a16df63980de72b06c39b21b200de10a7bd04f54405a06c7bf5512a64dc1f37` |
| [Analysis](../../tools/osp_stage_b_analysis.py) | `baa13b3c8dac922c4e87896af2bce9d9892072ddd5a62249a774a021ebafab15` |

The investigation skill guided source-first diagnosis; fresh reproduction/fix
phases were outside this task. Only existing text/XML/JSON and small retained-row
arithmetic were inspected. No equation evaluation, test run, native worker,
download, contact, code change, old-output rewrite or operational access occurred.
Temporary evidence paths are not an archival-retention guarantee. This proposal
awaits independent review; numerical/model/product gates remain unchanged.

**Lesson:** a complete formula graph is not a complete model dependency graph
when events can replace formulas. Diagnose that gap before treating a negative
readout as harmless bookkeeping. R33 exogenous insulin and the five separate
programs—erinacine A, sterubin, carnosic acid, arctigenin and cyanidin
3-glucoside—remain active and unqualified as whole-individual experiments.

## Pre-code addendum: exact static packet, not executable model admission

This addendum resolves the independent review's structural-completeness gaps.
It supersedes any narrower interpretation of §3. **Still proposal only.** Its
maximum successful claim is `STATIC_GRAPH_COMPLETE` for **declared XML references**
together with `EVENT_SEMANTICS_UNVERIFIED`. It does not certify equation semantics,
biological domains, event execution, numerical acceptance or model admission.
The preceding 175-line proposal was reviewed at SHA256
`dc0b1081b33709cfd9e43a807ba3592f8d5b16cb6f590f57fb5f52a86b63b353`;
this is an appended contract, not a changed Stage B result or criterion.

### A. New-only ownership and immutable inputs

Proposed implementation files are exactly `tools/osp_source_admission.py` and
`livemorebio/tests/test_osp_source_admission.py`. No package/runtime integration,
new dependency or edit to `osp_stage_b.py`, its native R wrapper, analysis,
preregistration, source XML, recipe or retained v1 arrays/reports. Those hashes in
the evidence table remain preservation gates, not source material to rewrite.

The one permitted source input is the XML hash above, 7,477,881 bytes, namespace
`http://www.systems-biology.com`, root `Simulation`, version `4`, path delimiter
`|`. The source graph may only use this exact source; small authored technical
XML fixtures have a separate test-only entry point and cannot receive this
source's identity or model-admission status. Read the three pinned domain ledgers
only to bind the negative-root set; do not reclassify their values or rerun analysis.

Output is a new owner-private `osp-source-admission-v1-<unique>/report.json`, schema
`livemore.osp-source-admission.v1`, never an existing results directory. It retains
input/source and implementation hashes, explicit static-only scope, inventory,
root bindings, typed graph, reachability records, conditional dimensional
assertions, unresolved semantic flags and a fixed failure record. Deterministic
content is canonical UTF-8 JSON (`sort_keys=True`, compact separators,
`ensure_ascii=True`, `allow_nan=False`); its SHA excludes only run timestamps,
output location and its own digest. Source literals remain strings, not rewritten
numeric expressions. Preserve evidence on failure; no overwrite/retry-to-pass.

### B. Pinned inventory and mandatory independent roots

| Source structure | Exact required inventory |
|---|---|
| Direct definitions | Observer 1475; Event 33; Formula 14027; Variable 1100; Parameter 12001; no duplicate defining IDs |
| Formula subclasses | ExplicitFormula 14021; TableFormula 3; TableFormulaWithOffset 3 |
| Declared references | 50,446 `R` occurrences, including 277 exact `id="0", alias="Time"`; 3917 RHSFormula references |
| Values and initializers | P: 8536 formula bindings / 3465 literal values; V: 1073 literal values / 27 formula bindings |
| Events | 33 conditions and 39 assignments; all `oneTime="1"`; 23 `useAsValue="0"`, 16 `useAsValue="1"` |
| Tables | F28335/F28357: 326 points each; F28579: 31 points; 683 total; all `useDerivedValues="1"`, all point `restartSolver="0"` |
| Table-with-offset bindings | F28346: Table P28334 / Offset P28338; F28368: P28356 / P28360; F28590: P28578 / P28582 |
| Other source structure | Seven solver references; one literal output interval; 113,891 XML element nodes in total |

All 27 initializer pairs below are **independent roots**, even when unreachable
from a negative-state root. IDs are source strings; a pair must resolve to exactly
one V definition and its exact original formula definition:

```text
(3376,3393) (3593,3608) (3792,3820) (3972,3996) (4174,4185)
(4355,4381) (4549,4570) (4753,4764) (4941,4950) (5134,5144)
(5322,5333) (5518,5523) (28279,28280) (28302,28303) (28325,28326)
(28347,28348) (28369,28370) (28392,28393) (28415,28416) (28438,28439)
(28461,28462) (28484,28485) (28507,28508) (28530,28531) (28553,28554)
(28591,28592) (28614,28615)
```

The 27 negative entity IDs are the union of I2/T2/C2 `negatives[].id`. Its sorted
JSON array under the canonical settings above has SHA256
`dac7a910d23a22ce193566f7497e5b8e0687c62f1ad07b2e9dedfb8511e42d81`.
I2/T2 ledger hashes are respectively `7302921e7cf899603678868800b182e1f2d36841f69f3952a309a55970d377ba`
and `879da88776d8ad07751b9e82dc8d6cb3baac3b671c3c56d94fff81c1aed49797`;
C2 is pinned above. Every entity ID must bind uniquely to the source V ID.

Other mandatory roots are the 15 `(RHS formula, V)` pairs already independently
listed in the retained audit: `(790,723) (1278,1217) (1915,1854) (2374,2313)
(2825,2764) (3292,3231) (6123,6062) (6634,6573) (8755,8694) (11299,11238)
(11753,11692) (12355,12294) (12907,12846) (13465,13404) (13914,13853)`.
The contextual quantity roots are P786, P10741, P10743, P11208, P10986 and
V10939/V10970/V10978. Preserve overlapping root roles; do not drop one category
because its node was already visited for another root.

### C. Graph schema and finite coverage

Nodes retain typed identity, source ID/entity ID where declared, source location,
raw name/path/unit, literal value or formula binding, and original flags.
Retain V ScaleFactor, `negativeValuesAllowed` (15 explicitly `0`, others absent),
and persistability/variation flags without converting them into biological policy.
Definitions are indexed only from their direct lists. Reference ID nodes in RHS,
Table, Offset or Solver must never overwrite a definition.

Edges retain `kind`, `from`, `to`, original owner ID, occurrence ordinal and alias
where present. Preserve duplicate-target occurrences with different aliases;
duplicate aliases within one ExplicitFormula are errors. Sort deterministically,
but keep source ordinals for event assignments and table points. Required edge
kinds are quantity/builtin-to-explicit-formula references; formula-to-parameter;
formula-to-observer; initial-formula-to-state; RHS-formula-to-state;
condition-formula-to-event; event-to-assignment; replacement-formula-to-assignment;
assignment-to-target; table-parameter/offset-parameter-to-offset-formula; and
solver-quantity-to-solver-setting. Each derived edge cites its original XML field.
Literal output settings and all table point `x/y/restartSolver` strings are retained
as metadata, never interpolated or differentiated.

Builtin `0/Time` is one explicit leaf with `unit=null` and `TIME_UNIT_UNVERIFIED`.
Only that exact ID/alias pair bypasses ordinary definition resolution. Every other
missing reference, even on an unrelated source branch, prevents completeness.
Table inputs/offsets are declared links; no implicit time edge or interpolation
law is invented. The graph describes exported dependencies and **possible** event
influence, not event firing, ordering, simultaneity, latching or ongoing evaluation.

Use iterative visited-set traversal with deterministic adjacency order, retaining
cycles. Do not enumerate all simple paths. For each root, record complete reachable
node/edge counts and sorted-set digests, all reached state-RHS and event/assignment
targets, and a deterministic predecessor forest sufficient to reconstruct one
shortest witness to every reached target. The forest is a witness representation,
not a claim that other paths do not exist. All-27 initializer roots must each have
their own traversal result; no intersection-only completeness check.

Fixed limits: XML <=8 MiB; depth <=32; <=125,000 XML nodes; <=30,000 graph nodes;
<=75,000 typed edge occurrences; <=128 root roles; <=4,000,000 aggregate visited
root/node pairs and <=10,000,000 examined root/edge pairs; any reconstructed witness
<=30,000 nodes, stopping on repeated nodes; final canonical JSON <=128 MiB.
Read each domain ledger at <=8 MiB and <=100,000 negative rows. The report must be
size-checked before final publication. Limit breaches stop with `STATIC_LIMIT`,
not truncated `STATIC_GRAPH_COMPLETE`. These are engineering bounds, not scientific
tolerances. No all-path expansion or unbounded recursive traversal is permitted.

Reject DTD/entity declarations before parsing; use strict UTF-8 and the exact
namespace. Unknown element, attribute, parent/child shape, definition kind or
reference location is `STATIC_UNSUPPORTED`. Unsupported flag literals outside
`0`/`1`, duplicate IDs/aliases, missing required fields/references, ambiguous
value/formula definitions, malformed numeric literals and inventory/root drift
are fixed failures with bounded source location. Pinned production flag sets must
also equal the inventory above. Do not infer missing units or missing flags.
Every fail outcome has `graph_status="FAILED"`; never emit a partial COMPLETE.

### D. Non-admitting assertion ledger and red-test gates

The dimensional ledger is **not a new symbolic engine**. It mechanically binds the
already reviewed exact-ID assertions to source formula text, aliases, declared
units, constants and graph paths. Each row has source witnesses, explicit
assumptions, observed declared-unit conflict/unknown, and `admitting=false`.
For example, the restoration concentration-versus-amount/time assertion is
conditional on S_I being dimensionless; that convention itself is unverified.
PTP/hepatic multiplier conflicts remain separate. No equation evaluation,
simplification, differentiation, numerical boundary probing or unit coercion.

No retained implementation evidence currently establishes `oneTime`, `useAsValue`,
`useDerivedValues`, `restartSolver` or table interpolation semantics. Preserve
those literals and report `EVENT_SEMANTICS_UNVERIFIED` plus
`TABLE_SEMANTICS_UNVERIFIED`. The strongest accepted output is complete static
structure with these unresolved flags and `model_admission=false`, never a repaired
source, signed-state exemption, executable insulin program or physical validation.

Required red tests add to §3: all three formula subclasses and six Table/Offset
links; exact builtin Time handling; point/flag literal preservation; all 27 root
pairs independently present; event-condition-only influence and both assignment
modes as unverified structure; duplicate alias/definition collisions; unknown
tags/attributes/modes and nonbuiltin missing references; cycles and every finite
budget; source/ledger/pinned-root drift; no partial or oversized COMPLETE report;
deterministic output; old-file byte preservation; import/evaluator/native/network
tripwires. Independent review must verify inventory, roots and graph accounting
from the original source, not only trust maker tests. Any stronger event/source
claim or native diagnostic remains a separate evidence and approval gate.

### E. Final independent traversal precision and root implementation clearance

The independent reviewer cleared the bounded packet subject to distinguishing
edge direction. Root accepts this precision: the graph's input→consumer edges
support **downstream possible influence**, not upstream initialization inputs.
Retain that downstream role for negative/restoration/context roots. For each of
all27 initializer formulas, also emit a separately named
`upstream_initialization_dependencies` traversal in reverse edge direction.
Its allowed incoming kinds are declared references, formula→parameter/observer,
table/offset bindings and initial-formula→state. Literal parameter/state and
builtin inputs are explicit leaves. Incoming RHS and event-assignment writes
are NOT initialization laws and must not enter this traversal. Broader possible
event influence stays a separate downstream record, with unverified semantics.
Keep root-role identity and deterministic witness orientation explicit; test
an initialization input visible only by this reverse walk and an event/RHS
write that must not be misclassified. Existing aggregate bounds cover these
additional27 roles; do not silently raise them or truncate outputs.

Root read the original175-line proposal and complete appended contract. The
independent reviewer checked its source counts/pins and final specification.
**New-only parser/tests implementation is approved**, with red-first evidence
and independent implementation review before one pinned static report run.
No formula/native execution, original-result edits, model admission, experiment
or automatic source acquisition is authorized by this clearance.
