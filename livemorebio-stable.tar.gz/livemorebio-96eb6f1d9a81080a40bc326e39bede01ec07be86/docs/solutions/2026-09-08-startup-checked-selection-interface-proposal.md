# Startup checked selection — exact private capture proposal

2026-09-08. Read-only pre-code proposal for root and independent review. No helper,
server, tests, service, browser or registry data was changed. This refines the
already approved startup clause in the committed-source transition plan/interface;
it is not a fourth mutation and does not clear the blocked registry implementation.

## Read source and the actual gap

Read current `_transition_snapshot`, `_transition_topology`, `audited_active_twin`,
`confirm_active_selection`, `_audited`, audit begin/finish/check_authority,
`_restore_active_subject`, `_ensure_selected_state`, ModelSourceAuthority and the
approved startup/initialization exception in the transition interface.

`_checked_active_twin` currently returns None immediately for a missing pointer,
without checking orphan ACTIVE rows. `confirm_active_selection` compares decoded
canonical record content only: it omits raw ciphertext/index bytes, pointer
timestamp and registry authority adoption identity. `_audited` completes its
terminal audit after the caller's comparison, so merely changing the reader in
its body would leave a final-write trigger window. Initial construction is also
followed by no exact final storage confirmation or generation/initialized check.

The existing `_transition_snapshot(connection, None, None)` already gives a bounded
0-or-1 active-record read set, complete authenticated/index-coherent row, complete
pointer tuple and exact allowed ACTIVE topology. Reuse that reader, not an inner
join, full clinical-table scan, version-only lookup or caller-created digest.

## Exact proposed type and callable seams

In `subjects.py`, add one private-use immutable `CheckedActiveSelection`,
`@dataclass(frozen=True, repr=False)`. No HTTP serialization, logging, public
receipt, pickle, process-global last-read value or persistent schema:

```python
class CheckedActiveSelection:
    store_id: str
    authority_token: str
    request_id: str                 # canonical capture access UUID
    _rows: tuple[tuple[object, ...], ...]  # exactly zero or one full SQL row
    _pointer: tuple[str, str, str] | None  # key, value, updated_at, unchanged
    _active_ids: tuple[str, ...]    # () or exactly the pointer target
    _record_json: bytes            # canonical authenticated record, or b'null'

    @property
    def record(self) -> dict | None: ...   # a fresh detached decode each time
```

Keep the original public defaults and existing callers. Add only internal checked
keywords to the existing methods, so no caller has to infer a new result shape:

```python
def audited_active_twin(self, *, action: str = 'inspect',
                       request_id: str | None = None,
                       _checked_snapshot: bool = False
                       ) -> dict | None | CheckedActiveSelection: ...

def confirm_active_selection(self, *, expected_record: dict | None,
                             request_id: str,
                             _expected_snapshot: CheckedActiveSelection | None = None
                             ) -> None: ...
```

`_checked_snapshot` must be an actual bool. The true branch is restricted to
`action='inspect'` and requires an explicit canonical server-created request UUID;
it returns the capture object only after completed audited access. Default false
keeps the existing return shape. A provided `_expected_snapshot` must have exactly
the new type; its detached record must canonical-match `expected_record` before
I/O. The confirming UUID is explicitly supplied by the server; retain the existing
operation correlation convention, including reuse within one completed access
workflow where permitted by current audit semantics. No HTTP
query/body parameter selects these internal modes.

Both checked branches use one fixed private `_checked_selection_access(*,
request_id: str, expected: CheckedActiveSelection | None = None)` helper, with
None meaning capture and an object containing b'null' meaning confirm true absence.
This is a fixed audited read implementation, not a generic transaction callback
or mutation-kind dispatcher. Existing unchecked observation/reconciliation
callers remain explicit follow-ups; adding this branch does not grade them fixed.

Validate every private field, canonical bytes and strict scalar types. The saved
row must obey the existing row shape and match its authenticated record fields;
absence requires all of rows/pointer/active_ids empty and record exactly null.
Reject a foreign store, missing/changed authority token, malformed tuple, bool
numeric field, incoherent pointer, altered detached record or forged type. Capture
does not invent a new clinical timestamp: retain the exact pointer/row timestamps.

## Fixed audited-read completion boundary

The helper uses the existing private-storage guards, corrected RegistryAudit
primitives and safe connection lifecycle, not the old `_audited` body alone:

1. Validate arguments without clinical I/O. Own one connection. Append/verify the
   existing BEGIN event and exact reservation pair, then obtain its acknowledged
   durable commit before any protected record decrypt. Preserve existing quotas,
   AAD, action vocabulary, store/process/source identities and no-PHI errors.
2. Enter BEGIN IMMEDIATE. Recheck audit authority against the reservation. Capture
   its exact nonempty authority token plus store identity, then call the existing
   `_transition_snapshot(connection, None, None)`. Derive the strict active_ids
   evidence from that checked topology. At most one clinical row is decrypted.
3. For confirmation, compare every frozen field, including full row bytes,
   ciphertext, SQL indexes, canonical record, pointer timestamp, active_ids and
   authority token. Content changes at an unchanged version still conflict.
4. Finish SUCCESS with the independently corrected append-origin audit witness.
   **After all terminal INSERT/reservation DELETE writes**, recheck current
   authority, complete raw active row/pointer/ACTIVE topology, original BEGIN,
   terminal identity and reservation absence against the captured intended read
   evidence. No write occurs between this check and the audit transaction commit.
   Avoid a second clinical decrypt: the unchanged full authenticated raw row is
   sufficient for this post-finish check.
5. Return a capture or successful confirmation only after terminal commit and
   connection close both return successfully. A BEGIN/terminal commit lost ACK,
   rollback uncertainty or close error authorizes no startup publication. This
   checked read does not need a mutation retry or a new durable-outcome witness;
   the caller conservatively remains unavailable and can explicitly reconcile.

Use the existing fixed reconciliation conflict error for an exact-snapshot
mismatch and existing typed audit/bootstrap/storage failures for those boundaries;
do not expose paths or snapshots. Preserve the primary failure if failure-audit
completion also fails. As in the registry correction plan, any ACCESS_FAILED
attempt needs its fresh bounded raw baseline rechecked after its last audit write
so a trigger cannot turn an access failure into a clinical mutation. Reuse the
corrected fixed mechanism; do not introduce a weaker duplicate cleanup path.

Only normal metadata-only audit rows/reservations are written. No TWIN ciphertext,
version, hash, lifecycle, clinical observation, pointer timestamp, physical index,
bootstrap adoption, cohort or model-binding record is changed or repaired.

## Server ownership and publication sequence

Keep the approved initialization-only mutex exception: it serializes starters,
but no authority, manager-creation, manager or registry lock spans candidate/model
construction or state/response projection. Capture original source generation
and initialized state under authority and obtain the checked registry read under
that same source ownership. Retain the capture, not just its detached record.

Build the candidate and all projections outside the prohibited locks. A true
absence permits only the already supported explicit healthy reference preview;
a captured unbound/unsupported human produces the existing typed unavailable
view with no numerical constructor. An inconsistent/unknown selection permits
neither. No profile defaults are used to repair an unsupported restored subject.

In the existing final commit guard (authority → manager creation → manager),
first compare original generation and initialized state. If a later operator
selection won, do not confirm, publish, invalidate, or install DENY_ALL over that
new selection. Hold the unused candidate for retirement outside all locks.
Otherwise call exact checked confirmation, then assign only the already prepared
source generation/state/fence under the same guard. An audit/storage failure while
this starter still owns the source installs the approved DENY_ALL state, not a
healthy fallback or a fatal exception that disables static/history/onboarding.

There is no SQLite write lock held after the final audited read returns. An
external process can subsequently change the registry; do not claim a global
cross-process atomic memory/storage transaction. The check proves the read at
the completed audit boundary, while current source generation checks remain
responsible for in-process consumers and later authority changes.

Hold old state/actions and unpublished candidates in an explicit retire holder.
Only after the initialization mutex and all commit/registry locks are released
may finalizers, adapter cleanup, execution invalidation or best-effort publication
run. Exact old-generation retirement and late-startup supersession remain required
acceptance tests, not incidental cleanup claims.

## Named red matrix before any implementation

New dedicated `test_checked_startup_selection.py`, authored private stores only:

- `test_checked_capture_returns_detached_full_row_pointer_and_authority`;
- `test_checked_absence_requires_no_pointer_and_no_active_rows`;
- `test_checked_read_rejects_dangling_inactive_or_multiple_active_topology`;
- `test_confirmation_rejects_each_sql_field_ciphertext_or_pointer_timestamp_change`;
- `test_confirmation_rejects_same_version_payload_change_and_authority_adoption`;
- `test_absence_to_selected_and_selected_to_absence_never_confirm`;
- `test_foreign_or_malformed_capture_rejected_before_protected_read`;
- `test_begin_reservation_and_terminal_triggers_cannot_change_confirmed_readset`;
- `test_failed_access_terminal_cannot_persist_late_clinical_side_effect`;
- `test_begin_commit_terminal_commit_rollback_and_close_errors_never_confirm`;
- `test_audit_is_durable_before_decrypt_and_failure_never_returns_capture`;
- `test_checked_startup_does_not_rewrite_registry_records_or_indexes`;
- `test_default_audited_active_and_confirm_signatures_keep_existing_callers`.

Root server tests must additionally prove supported/absent/observation-only paths,
candidate failure, generation and initialized supersession during construction,
late storage failure not poisoning a winning operator, no constructor or projection
under prohibited locks, exact old-generation invalidation and finalizer release
outside every lock. Use no real model/HTTP/browser and preserve source/audit/clinical
fixtures. This document proposes these tests; none were authored or run here.

## Review decision requested

Approve the exact private capture and optional checked branches, including their
post-terminal read-set check, before either maker writes code. The blocked registry
terminal correction must pass independent review first. The current publication
parameter correction is separate and does not depend on this interface. Local
prior-art docs are the durable record; unavailable CE/gbrain tools were not invoked.

## Root and independent pre-code refinements

Root read all194 original lines. The independent release reviewer read this
proposal with the later audit-phase correction and cleared the private checked
interface conditional on those shared primitives. The earlier BEGIN/reservation
and every audit-commit preservation boundaries apply here too; no duplicate weaker
read owner is authorized. The stored-version amendment separately permits an
authenticated exact stored MAX_SAFE_INTEGER without permitting another increment.

For server startup, capture ownership before the fallible registry dependency
lookup, not only before the first clinical read. Any untyped dependency/read/
candidate/projection/confirmation Exception fails closed only if both the original
permitted generation and initialized state still match under the final guard.
Install DENY_ALL and initialized=True without inventing a ModelContext reason,
healthy fallback or fatal startup RuntimeError. Existing unconfirmed-source
responses protect numerical/state consumers. Do not catch post-publication
cleanup as a preparation failure or poison a successfully installed source.

Typed ModelContextError may produce the existing allowed modeless state only for
an exact-confirmed present record; an absent-preview construction failure cannot
be relabeled as an unbound person. An operator that wins during preparation always
keeps its generation, state and resources. No final storage confirmation or late
invalidation is permitted after recognizing that supersession.

`_ensure_selected_state` calls restore once and does not add its own healthy
fallback: restore handles confirmed absence completely. Its private compatibility
return may continue describing record presence, but cannot trigger a second
constructor. The retirement holder must be owned outside the initialization-only
mutex and passed through restoration, so returned unused candidates and replaced
state/actions are not released when restore returns while that mutex is held.
This concerns objects returned to and owned by startup, not a promise about
unreachable intermediate objects inside an arbitrary constructor's implementation.

These refinements approve startup RED authoring and the private checked-interface
direction. Registry audit-phase and inclusive-read corrections remain separately
implemented/reviewed before the checked reader and server runtime are connected.

## Root server RED evidence

The separate authored `test_checked_startup_publication.py` now defines24 cases
without a real record store, patient, model, numerical execution or network.
The first21 cases failed in1.87s (private root `livemore-research-review-2haux_w3`);
the complete24 failed in1.15s (`livemore-research-review-jff9gqvq`). Both outer
processes finished, each recorded zero network/child attempts and one exact
optional Git metadata lookup refused into its existing fallback. Three existing
framework deprecation warnings were retained. The original unchecked active_twin
call is explicitly rejected, rather than allowed by a permissive substitute.

The matrix exercises present, true-absence and observation-only publication;
dependency/read/availability/constructor/state/confirmation failures; later
operator wins during each preparation stage with or without a late exception;
initialized-only supersession at unchanged generation; cleanup failure after a
confirmed publication; typed ModelContextError for present versus absent input;
and an unused returned candidate's weak-reference finalizer after every source,
creation, manager and initialization lock has been released. Final confirmation
must use the exact checked capture object, and the same guard's exit checks the
complete new state before any of its three locks are released. Static route and
fixed503 tests cover fail-closed accessibility without exposing the authored error.

These are expected REDs awaiting the approved checked-registry dependency and
server implementation, not skipped tests, product failure acceptance or clinical
validation. The actual checked capture shape and field tampering are separately
tested against authored SQLite by the registry owner. Existing35 source/preview,
two retirement and34 strict legacy-boundary cases remain required.

Independent fixture review then identified two coverage gaps: the exact guard's
exit did not assert every new state field, and only an unused candidate's
retirement was observed. Root strengthened that same guard with model,
availability/generation/identity, new empty observation state and cleared actions;
added a separate weak-reference probe whose old model/action payloads are owned
only by the server; and retained the original unused-candidate test. The25-case
packet remained RED in1.16s, private `livemore-research-review-caz1bsf1`, zero
unexpected I/O/process attempts and one optional Git refusal. A subsequent
assertion also requires a new actions container at guard exit; its next execution
is pending. These fixture corrections are not runtime fixes or green evidence.

The complete final25-case fixture (SHA256
`27a0deffe161aa0ded187a3fefa92d3d373f5db9c538dfce730b9e618a8fd723`)
was then independently re-read by the source reviewer, who confirmed both fixture
gaps resolved without another material test-design blocker. Root repeated it:
**25failed in1.20s**, private `livemore-research-review-5i93bukz`, zero unexpected
I/O/process attempts and one refused optional Git lookup; outer process exited1.
This executes the final actions-container identity assertion. The runtime has
not yet been changed for this checked-startup increment.

## Root implementation mechanics before server code

The audit-phase and stored-MAX increments now both have independent clearance.
The checked reader is the next separate dependency; server runtime is connected
only after its independent grade. Keep the current private direct
`_restore_active_subject()` callable: it may explicitly restore a previously
initialized state, but must capture that exact initialized value and generation
and respect any later change. Ordinary `_ensure_selected_state()` remains the
idempotent startup entry and never forces such restoration.

Use a small private retirement holder owned outside the initialization mutex.
It retains returned candidates, replaced state/actions, the old generation and
an optional fully prepared publication snapshot. No generic cleanup/transaction
framework, new model authority API, native handle or new close method is needed.
The direct compatibility wrapper and ordinary ensure entry both finish this
holder after the initialization mutex; failure to invalidate/publish is safely
reported without changing a confirmed selection. Hold references before swaps,
including error-state swaps, so retirement cannot run at assignment time.

Prepare the full candidate state (or existing modeless projection), availability,
new ObservationState, summary and empty actions before final confirmation. Check
the snapshot has its own dictionary-or-null profile_params before confirmation;
the existing best-effort bus publisher must not hide a preparation defect after
storage has already been accepted. Startup's event handler delegates to ensure
without an additional implicit snapshot of a possibly unconfirmed source.

If source authority is already DENY_ALL, do not read/build/confirm a new model;
leave recovery to explicit reconciliation. Mark startup initialized under the
same ownership guard so static routes remain usable without repeated attempts.
No fallback or fabricated availability reason is introduced. Fixed phase-only
logging excludes arbitrary exception class names/messages and subject data.

Two inherited direct-call tests require semantic preservation, not omission:
the real-model restored-subject test remains an integration obligation outside
the inert packet; the old fatal-startup expectation must become a fail-closed
authority/static-access expectation. Add direct-call, denied-entry, invalid-
projection and one-publication event-handler fixtures before this implementation.
These details do not expand any physiological scope or authorize a live service.

The independent release reviewer cleared these mechanics with two precisions:
the already-DENY branch assigns initialized=True under commit_guard without
reinstalling/invalidation or a generation getter, and publication failures must
also use fixed logging in the shared _snapshot_twin helper. The new private-
exception-name logging regression reproduced **1failed/8preserved in1.28s**,
private `livemore-research-review-98aqwbdq`; the log correction is still pending.

The direct compatibility fixture now checks the exact initialized bool captured
before the fallible registry getter instead of assuming False. Root's expanded
32-case startup packet was repeated with ASGI-compatible process/network/constructor
tripwires: **32failed in1.18s**, private `livemore-research-review-4ws2i15h`, zero
unexpected I/O/process attempts, one refused optional Git lookup. The registry-
only autouse fixture forbids even internal Unix socketpairs; it is intentionally
not reused for ASGI. Connect/DNS/bind/listen/urllib, low-level process launch,
clinical compilers and actual AegleTwin/MetabolicProfile constructors remain
refused in the replacement inert invocation. None of these are green startup
claims. The exact corrected invocation is retained in the activation increment's
review report and differs only in its test-file selection.
