# Continuous execution and LIFE: CLI/SDK parity proposal

Date: 2026-09-08. Status: **ROOT REVIEWED AND APPROVED before implementation.**
Parents: [full R01–R51 plan](2026-09-08-full-scope-recovery-plan.md),
[execution API](2026-09-08-continuous-execution-api-subplan.md),
[LIFE execution](2026-09-08-life-continuous-virtual-execution-subplan.md).
This packet contributes to R04/R12/R37/R45/R47/R48; it closes none of those
requirements independently. No CLI, SDK, shared shell or service code was changed
while preparing it. The engineering-plan review skill informed this proposal.
gbrain/context7/sequential-thinking discovery returned no available tools; the
existing source, strict-JSON utility and approved solution records are the fallback.

## 1. Existing source and preservation boundary

`livemorebio/cli.py` is the installed `livemore` entry point. It already exposes
`livemore attach` and `livemore run <pipeline> --attach`, both delegating to
`shell.py` and `Platform` in `sdk.py`. Governed twin/cohort/protocol methods already
refuse in-process execution. The old `virtual_patch_sample()` is a separate v2
fixture path; it must not be relabeled or reused as continuous engine acquisition.
The default in-process constructor currently initializes a legacy healthy model;
preserving it does not mean the new commands may invoke it as a fallback.

The inspected `_get`/`_post` helpers use authenticated urllib requests but unbounded
response reads and ordinary JSON parsing. `shell._parse` coerces strings and
silently replaces duplicate keys. That is unsuitable for exact generation/hash/
idempotency identity or strict new control bodies. Existing protocol client tests
in `test_model_workflow_clients.py` must remain green. Prior isolation lessons in
`2026-09-05-review-stack-isolation.md` apply to every executable verification.

## 2. Smallest complete implementation

Add an attached-only continuous client mixin/helper module and a small command
dispatcher shared by the existing REPL, pipeline runner and two new top-level
CLI groups. Do not duplicate server lifecycle logic, run local solvers from these
commands, start/stop infrastructure automatically, renew leases from a terminal
heartbeat, choose a replacement twin or fabricate values when services are down.

Every new `Platform` method refuses `mode!='attach'` before any additional HTTP,
model or store work. Existing in-process methods/constructor behavior stays
unchanged. SDK methods return the actual response data; the server retains
source-authority, encrypted access audit, revision, idempotency and evidence
decisions. No new local `audit.record` call copies biological results into a
second log. Correct the SDK module's blanket identical-modes/every-call-signed
description to name this attached-only, server-audited family accurately.

### Proposed exact parity matrix

The CLI column is valid inside `livemore attach` or a `.lmr` pipeline; prefix
`livemore ` for the equivalent direct command. Direct commands always attach.

| Operation | Proposed Platform method | Shared CLI syntax | Authenticated Aegle route |
|---|---|---|---|
| Source/contracts | `execution_capabilities()` | `execution capabilities` | GET `/api/executions/capabilities` |
| Prepare frozen source | `prepare_execution(payload, idempotency_key=...)` | `execution prepare <request.json> key=<opaque>` | POST `/api/executions`, Idempotency-Key header |
| Inspect lifecycle | `execution_status(id)` | `execution status <id>` | GET `/api/executions/{id}` |
| Read native frames | `execution_frames(id, after_frame=0, limit=100)` | `execution frames <id> after=0 limit=100` | GET `/api/executions/{id}/frames` |
| Inspect admitted counterpart | `execution_observations(id)` | `execution observations <id>` | GET `/api/executions/{id}/observations` |
| Start/pause/resume/stop producer | `start/pause/resume/stop_execution(id, expected_revision=..., expected_source_generation=...)` | `execution <start\|pause\|resume\|stop> <id> revision=<n> generation=<id>` | POST `/api/executions/{id}/{action}` |
| Explicit full-checkpoint fork | `fork_execution_checkpoint(id, payload, idempotency_key=...)` | `execution fork <id> <request.json> key=<opaque>` | POST `/api/executions/{id}/fork-checkpoint` |
| Probe/operator capabilities | `virtual_patch_capabilities()` | `patch virtual capabilities` | GET `/api/patch/virtual/sessions/capabilities` |
| Register exact numerical probe | `register_virtual_probe(device_id)` | `patch virtual probe device=<id>` | POST `/api/patch/virtual/probe`, body `{device_id}` |
| Bind/start LIFE consumer | `start_virtual_session(payload)` | `patch virtual start <request.json>` | POST `/api/patch/virtual/sessions` |
| Inspect consumer/delivery | `virtual_session_status(id)` | `patch virtual status <id>` | GET `/api/patch/virtual/sessions/{id}` |
| Pause/resume/stop consumer | `pause/resume/stop_virtual_session(id, expected_revision=...)` | `patch virtual <pause\|resume\|stop> <id> revision=<n>` | POST `/api/patch/virtual/sessions/{id}/{action}` |

No new public SDK convenience method exposes the service-owned `/consumer/renew`
or signed observation submission route. LIFE owns renewal eligibility and delivery;
an independent CLI heartbeat would defeat outage/backpressure pause semantics.
The old `patch sample` remains explicitly a legacy fixture command.

## 3. Payload, transport and error contract

- Preparation and fork files contain exactly the existing API fields: engine
  contract, expected source generation, expected twin ID/version, policy; fork
  additionally has expected parent revision. No injected state vector/results.
- Session start contains exactly `execution_id`, `source_snapshot_hash`,
  `device_id`, `expected_selection`, `idempotency_key`. Controls contain only
  their exact revision/generation preconditions. Preserve all explicit nulls in
  the full selection. Do not refresh a conflicting version and retry a mutation.
- Preserve generation/hash/device/key strings as strings. Parse only declared
  numeric fields strictly; reject unknown/duplicate CLI options, booleans-as-
  integers, nonfinite numbers, malformed quoting, positional overflow and unknown
  actions before HTTP. Do not route new commands through `_coerce`.
- Load request files through bounded binary reads and strict duplicate-key JSON,
  at the existing 16-KiB API request limit. Support stdin `-` for private scripted
  input. Do not put clinical data, tokens or full JSON in command-line arguments.
  Do not echo request file contents, paths or arbitrary command arguments on error.
- Reuse `Platform._url()` and `security.authorization_headers()` for configured
  Aegle attachment, but add a scoped bounded transport for this new family rather
  than silently changing every historical SDK call. Reject redirects, userinfo,
  query/fragment in the base URL and insecure non-loopback HTTP. Disable implicit
  proxy environment for this local workflow. Never take a URL from a response or
  request file. A configured remote HTTPS mode would require separate deployment/
  PHI approval; this packet's executed acceptance remains isolated local services.
- Preserve the server's existing response bytes and fields, with no source/evidence
  reclassification. Cap response reads at 8 MiB (server frame-page bound), use
  strict JSON and validate basic expected response shape. Proposed minimal shared
  utility change: `parse_json_object(..., max_bytes=...)` with a validated bounded
  override up to 8 MiB; its existing 2,000,000-byte default and every default caller
  remain unchanged. Independently review this small shared seam before editing.
- Use a 60-second client deadline for start/resume native initialization (server
  worker initialization remains 45 seconds); 20 seconds for other operations.
  Never extend producer lease or scientific time to match a client timeout.
- Retain PHI-free response metadata (request ID, source hash, process instance)
  separately on the client/typed exception; do not insert fields into hashed
  frames. Fixed `ContinuousClientError` code/status/request_id only, no response
  body, URL credentials, HTML, payload or raw traceback in terminal errors.
- Lost mutation response is **unconfirmed**, not failed/nonexistent. Expose its
  request ID when available and tell the caller to inspect the known execution/
  session or reuse the exact preparation idempotency key. Do not automatically
  retry start, advance, bind, change sequence or create a replacement execution.

## 4. User workflow and display

1. Attach using the existing environment/local token mechanism; never print the
   token in examples. Inspect build/source/capabilities and an actual admitted twin.
2. Register the exact virtual probe, then bind that manifest to the twin with the
   existing governed `bind_patch` API/`twin patch` command. Supply v3 protocol and
   returned firmware/manifest identifiers, not the legacy shell v2 defaults.
   Binding must precede source capture because the registry version changes.
3. Read execution capabilities again; explicitly prepare with those expected
   IDs/version/generation and chosen native horizon/speed. Preparation does not solve.
4. Start the LIFE session using the prepared ID/hash/full selection. It must report
   waiting/NOT_EXECUTED with no manufactured sample before the producer starts.
5. Read the producer's current revision after lease binding, then explicitly start
   it. Inspect bounded frames/observations and the consumer's actual acknowledgments.
6. Pause/resume each lifecycle explicitly; resolve pending delivery and renew
   consumer permission before producer Resume. No paired command claims atomicity
   across the two services. On source switch stop/inspect the old source and prepare
   a new exact source; on producer restart offer the explicit checkpoint-fork path.

Default terminal output is compact metadata: IDs, revisions, source hash/class,
native unit/time, frame cursor, evidence/authorship, source-validity, lease state,
pending/admitted/acknowledged status and original generated/acquisition/receipt
times. It must visibly distinguish source pause, transport failure, old sample age
and completed domain. Do not label membrane voltage ECG or modeled plasma glucose
as measured ISF. Full bounded JSON/value inspection is explicit (`json=true`),
and optional `output=<new-file>` uses exclusive creation, mode0600, no overwrite.
No automatic plaintext export or rolling client history of biological values.

For new command families, pipelines echo only the action name, not the original
line/file path/key. A failed new command stops the pipeline with nonzero status;
interactive mode shows the safe error and remains usable. Preserve existing
unrelated pipeline semantics rather than refactoring the whole shell incidentally.

## 5. Red-first test and evidence packet

| Group | Required evidence before acceptance |
|---|---|
| SDK contracts | Every matrix row has exact verb/path/body/query/header tests; payloads remain unmodified; IDs encoded/validated; attach-only rejection produces no fallback HTTP or model work. |
| Transport/error privacy | Missing/wrong auth; timeout/lost response; redirect; oversized/chunked/deep/duplicate/nonfinite JSON; malicious error text never echoed; request ID retained; default strict-JSON limit unchanged. |
| Shared parser | REPL/direct/pipeline call the same SDK method with identical typed payload. Reject duplicate/unknown options and malformed quotes; preserve leading-zero opaque keys; explicit revisions only; private file/stdin and exclusive output tests. |
| Control semantics | Prepare is not start; consumer-before-producer/no-frame case; no automatic revision refresh, lease renewal, mutation retry, source switch or re-admission after error; pipeline stops safely. |
| Real local workflow | From a private review environment, actual SDK prepare→LIFE session→native metabolic start→two distinct committed frames→matching admitted observations→pause/recovery→stop. Assert all execution/source/frame IDs and both clocks agree, profile/source hash unchanged, zero physical qualification. |
| CLI and notebook | Repeat key lifecycle actions through the installed entry point from outside checkout, retaining shared IDs with the browser. Execute a short analysis notebook via attached SDK; show typed native quantity/unit and actual response metadata, no manufactured values. |
| Preservation | Existing `test_model_workflow_clients.py`, SDK/workspace/subject/protocol/shell/isolation tests stay green. No operational stores, installed current pointer, service restarts or biological contracts changed by unit tests. |

The API/browser owner still grades the end-to-end experience; the client maker
does not self-accept it. This is workflow parity, not new scientific validation,
completion of R01–R51, or a replacement for the full detailed guide/demo/deck.

## 6. Ownership and order

1. Root reviews this proposal and confirms capability/probe response fields and
   request limits; hand off `sdk.py`, `shell.py`, `cli.py` explicitly before edits.
2. Client owner: new `execution_client.py` / `execution_commands.py` and dedicated
   tests first, then minimal Platform inheritance/delegation and command/help hooks.
   Root retains API, auth policy, infrastructure and live-service ownership.
3. The strict-JSON byte-limit override is a separately reviewed tiny shared edit,
   with default-preservation tests; no concurrent owner writes it.
4. Independent review challenges auth, parsing, pending-request semantics and PHI
   output. Only then run actual local CLI/SDK/browser/notebook parity using the
   prepared review stack, not an installed operational store.
5. Update the review guide with tested executable snippets and capture a solution
   lesson. Preserve old detailed documentation and mark all unexecuted gates open.

Root read the complete proposal and `strict_json.py`, approved the attached-only
family and bounded byte-limit override, and handed off the named client/shell/CLI
files before implementation. Confirmed route above; probe returns200 with the full
ManifestV3 and session operations return200 with the public session record. No
new dependency, global installation or service operation is authorized by this
client implementation handoff.

## 7. Maker implementation checkpoint — not independent acceptance

The approved client/command modules and minimal SDK/shell/CLI hooks are now written.
Initial SDK tests failed for missing methods; 28 shared-command tests failed before
the dispatcher/hooks existed. Additional red probes exposed stale prior request
metadata after transport failure, raw response-close exceptions, quoted command
bypass of the legacy parser boundary, missing original session clock metadata in
compact output, and untyped idempotency keys. Those specific probes now pass.

Root separately approved a small full-selection correction: factor the existing
source-contract selection validator without changing its schema, and apply it in
LIFE session start before source I/O or persistence. Six red cases covered boolean/
float twin versions, unknown fields and noncanonical missing cohort/member links.
The SDK reuses this same full-context validator rather than creating a shortened
parallel identity contract. No v2/v3 wire canonical bytes or numerical equations
were edited in this packet.

Maker command (isolated stores, no service lifecycle or native solver operation):

```text
python -B tools/run_review_tests.py -q -p no:cacheprovider \
  livemorebio/tests/test_execution_commands.py \
  livemorebio/tests/test_execution_clients.py \
  livemorebio/tests/test_model_workflow_clients.py \
  livemorebio/tests/test_virtual_execution.py \
  livemorebio/tests/test_continuous_execution.py \
  livemorebio/tests/test_review_isolation.py --tb=short
154 passed in 2.98 s
```

Independent review has been requested; it has not yet graded this client packet.
Actual attached SDK/CLI/native service/browser/notebook parity and the wider R01–R51
acceptance remain open. These tests use private technical records, not measurements
from a person or proof of physical-device equivalence.

### Compounded client-boundary lesson

Opaque preconditions must cross every interface without generic type coercion.
Python equality is not a strict identity-schema check (`True == 1 == 1.0`), and
shlex-quoted command names can bypass a prefix-only dispatcher. Validate full
selection types before I/O, recognize the actual tokenized family before routing
to legacy parsing, and retain exact idempotency strings. A failed request must
clear prior response metadata and remain unconfirmed without automatic mutation
retry. Original generation, acquisition and acknowledgment clocks must survive
compact display independently of biological quantity values. Exports are explicit
new private files, never a background log or overwrite.

The `/ce:compound` and gbrain tools are unavailable in this session's discovered
tool catalog; this durable solution entry records the fallback lesson, not a claim
that those unavailable tools ran.

### Independent-review corrections under recheck

The independent reviewer confirmed the unreadable-POST ambiguity and identified
two additional cases: response cleanup could mask a confirmed acknowledgment or
more specific error, and output-file failure could hide an already confirmed
server action. Red regressions were added before each correction. A validated
current request ID now survives unreadable responses; POST response uncertainty
is explicit. Cleanup records only a separate fixed diagnostic without replacing
the acknowledgment/error; CLI cleanup warnings use stderr so explicit JSON stays
parseable. Export failure emits compact acknowledgment metadata and retains the
request ID, then reports that the server response is confirmed but private export
failed. It does not expose quantities or overwrite an existing file.

The reviewer also traced `EXECUTION_STORAGE` to a possible post-operation audit
failure. The original server code is preserved, with explicit may-have-committed
wording and an inspect-before-retry instruction. A separate red CLI privacy test
proved that argparse could echo an unknown first option; only the new command
families now enter the strict parser before argparse's diagnostic path.

After these changes the same six-suite command above passed **162 tests in 2.90 s**.
An additional isolated preservation run covering `test_clean_workflows.py`,
`test_subject_lifecycle.py`, `test_model_workflow_api.py` and
`test_research_workflow.py` passed **84 tests, 3 existing deprecation warnings in
17.48 s**. These are separate runs, not an invented aggregate full-product result.
Independent recheck is still pending at this entry; live workflow gates remain open.
