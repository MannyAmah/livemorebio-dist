# Single-skin diagnostic: once-only execution checkpoint

2026-09-08. Root authorizes exactly one invocation of the already reviewed
`skin-terminal` mode. This authorization implements the approved terminal-cause
supplement; it does not authorize a renderer change, repeated presentation case,
full-load retry, physiology run or experiment. If the case does not reproduce,
stop and review its result. Preserve every earlier failed transport receipt.

## Preconditions verified

- Root read the full terminal supplement, metadata-delivery correction, final
  observer implementation and complete566-line supervisor. UI owner performed
  read-only runtime/path/pin inspection. No operational service or old private
  store is reused. The supervisor creates a fresh observation-only authored
  selection, explicitly not a participant, in its private output directory.
- Root independently passed241 offline tests in17.58s (`iwsu4fbx`); independent
  source reviewer also passed241 in17.50s (`qqw9uyen`). Both recorded zero
  unexpected I/O, one refused optional Git lookup and172 authored Node children.
  Actual current-source startup constructor denial is included and green.
- Source reviewer found no actionable blocker in the final ACK/source packet.
  The positive delivery barrier waits for all acknowledgments; a negative
  acknowledgment reports evidence failure even with a pending original load.
  Neither case replaces or retries the original native request.
- Current package fingerprint is
  `b1ff46168943d61cff3da6d5f411abb66f003e82b2c5271910cd945c3fde1f6c`.
  Runtime remains frozen; tests and docs are excluded from this fingerprint.

## Exact frozen inputs

| Input | SHA256 |
|---|---|
| server.py | 3d521a029bccf5d9069a4e78806d40fbf895aca3b3cf6b6f370ad9500645676d |
| check_atlas_request_diagnostic.cjs | 91cd052b2284d5e47c6196076b59750e29ff14d563109de7d2ec7b28ae39f7fa |
| check_atlas_presentation.py | 77982780e71188b633ade499e0f7d744e823a8f6a14a84de79ebad03e722ea76 |
| unchanged ordinary presentation CJS | 23b38f60e2ebee4e306ba6331f35bc10c13e0fa9a8da18e1970c3d7ee06803ac |
| original product reader | 7ad7c023571614635d196cc5b0638d195ae46b166ce4602be16eb87e4cf4b9bc |

From `/Users/emman/Livemore/.worktrees/full-scope-recovery`, run only:

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B tools/check_atlas_presentation.py --check skin-terminal --output-parent /var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T
```

The supervisor must refuse occupied8910–8912 ports, verify all16 preserved
Atlas cache files and fixed manifest/receipt, use fresh identities/credentials,
and retain the existing45-second startup,90+5+5-second Node and105-second outer
Node bounds. Only one skin request, two original modules and the private blank
document are permitted. No geometry parsing, numerical model or screenshot.

## Completion rule

Read both diagnostic and supervision JSON in full. Confirm exact source/service/
selection identities, original promise/fetch/terminal observations, three stage
statuses, all owned children/descendants gone, strict LISTEN absence and unchanged
cache hashes/sizes/mtimes. Never read credentials into the report. Retain private
logs without presenting their contents unless a scoped sanitized diagnosis needs
them. Collection success remains separate from transport success, and
`acceptance_pass` remains false. The cause needs independent interpretation before
any next action. No automatic retry or retrospective upgrade of old evidence.

## Root execution receipt — one invocation, retained failure

The authorized invocation ran once, session15879, output child
`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-atlas-presentation-zpg7lltg`.
It exited1. Root read the complete diagnostic and supervision JSON. Diagnostic
SHA256 is `cf0ae732f0acd833cbae91c1858d0bf3c60c39d36673b7c9349089a5c51f9fb6`;
supervision SHA256 is `5e7e72104ff4c46d920fac2caf99127043ff9c24b2d79f11da07b35af875bc5e`.

All three collection stages reached PASS, but collection_pass remains false
because owned Node cleanup reported CLEANUP_UNCONFIRMED. Transport is FAILED:
both Playwright and native CDP report ERR_ABORTED; CDP canceled=true, with no
blocked/CORS reason supplied. The unchanged reader's original promise resolved
exactly4,901,056 verified bytes. Factory1, fetch1, dispose0, internal concurrency0;
initially_aborted=false and no signal abort observed. The one resource-timing
row has the exact encoded/decoded body size. Counts are exactly one document,
one original request module, one contract module and one skin GET. No renderer,
controller, GLB parser or biological model participated in this stripped-down case.
These observations narrow the failure boundary but do not prove cancel() caused it.

The original diagnostic remains CLEANUP_UNCONFIRMED, not retrospectively changed.
The outer supervisor reaped all4 direct children, found all12 retained browser
descendants gone, reported strict NO_LISTENERS and settled query cleanup, and
verified all16 retained cache hashes/sizes/mtimes unchanged. Root independently
repeated the bounded LISTEN inspection with the same absence result and queried
exactly the16 retained PIDs: no processes remained. Source/package and harness
hashes also remain exactly those pinned above. No operational service was touched.

Independent cause/evidence review is requested. No repeat is authorized. The
per-resource reason for the Node cleanup uncertainty was not captured, so it
must not be guessed or silently waived. Runtime source freeze may now release
for the independently approved next product correction; the failed diagnostic
and its original source identities stay immutable.
