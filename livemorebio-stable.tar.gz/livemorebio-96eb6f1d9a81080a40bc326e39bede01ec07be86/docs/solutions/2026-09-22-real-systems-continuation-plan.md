# Real-systems continuation: installer acceptance, native insulin program, six-program execution framework, terminal and Jupyter parity

Date: 2026-09-22. Branch: `codex/real-systems-continuation`, parented on
`codex/full-scope-recovery` at `0cfdd85`. Author: Claude Fable 5.1 for Emmanuel Amah.
Status: IMPLEMENTED for the rows listed in section 6; see that section for
exactly what was and was not achieved. Written before implementation per Iron Law 1. The R01–R51
register in `2026-09-08-full-scope-recovery-plan.md` remains the authoritative
obligation list; this plan advances specific rows and does not replace it.

## 1. Anomalies found in the evaluation of the delivered checkpoint

| # | Anomaly | Evidence | Consequence |
|---|---|---|---|
| A1 | `requirements-python311.lock` pins `libcellml==0.7.0`, which PyPI no longer serves (HTTP 404; only 0.7.1 exists). | `pip install --require-hashes` fails before installing anything. | The one-line installer and CI cannot install on any fresh machine today. The "6,416 passed" regression cannot be reproduced from the lock. |
| A2 | 20 test modules hardcode `/opt/homebrew/bin/node`. | PR #8 Installer CI, ubuntu leg: 988 failures, all `FileNotFoundError: /opt/homebrew/bin/node`. | The regression count is a macOS-only number. Linux acceptance was never possible. |
| A3 | Two Linux-only genuine failures: `test_server_restores_persisted_authoritative_subject` (restore returns False) and `test_workspace_stream_has_monotonic_event_ids_and_no_state_mutation` (`RuntimeError: Caught handled exception, but response already started`). | Same CI log. | Startup restore and SSE streaming have platform-dependent behaviour that is untested on the platform the installer targets. |
| A4 | The only endocrine engine is the Bergman minimal model (`glucose_insulin.py`). It has no exogenous insulin input, no subcutaneous absorption and no insulin product identity. | Source read. | The insulin program (R33) is structurally impossible on the shipped engine, independent of the OSP failure. The OSP route was the only attempt, and it failed on source-domain grounds (negative glycogen in the original XML). |
| A5 | `interventions.plant_compound` raises `UnsupportedInterventionError` unconditionally. | Source read. | No botanical program has any execution path. 0/6 is a structural zero, not a data gap. |
| A6 | `metabolic_cardiac.hyperglycemia_to_ikr_block` uses an unsourced slope (0.0035 per mg/dL). | Source read; docstring says "illustrative". | A coupling with an invented magnitude is exposed as `claim_state: MODELED`. It must carry an explicit `HYPOTHESIS_UNSOURCED` flag or a source. |
| A7 | Launchers and docs disagree on ports: CLI defaults 8850–8852, the handoff review stack used 8868–8870, `Livemore Doctor.command` probes 8850–8852. | Source read. | Operator confusion; doctor must derive ports from the same table as `start`. |
| A8 | No `livemore doctor`, no `livemore notebook`; Jupyter is reachable only by a double-click launcher that opens one fixed notebook. | CLI subparser list. | Terminal and notebook parity (R45, R37) is not met. |
| A9 | Native OSP/.NET/R toolchains are absent on this machine (`dotnet`, `R` not found). | `which`. | The OSP native route cannot be exercised here at all. |

## 2. Decisions

D1. **Installer acceptance first.** Repin `libcellml` to 0.7.1 using PyPI's published
sha256 digests for every wheel; replace the hardcoded node path with a shared
`livemorebio/tests/_node.py` resolver (`shutil.which("node")`, then the Homebrew path)
that skips with an explicit reason when Node is absent; diagnose and fix A3 from the
code paths, then let the PR's ubuntu/macOS CI matrix be the fresh-machine check.

D2. **Insulin program: native, published, individualizable model replaces the OSP route.**
Implement the Hovorka 2004 glucose–insulin system with subcutaneous insulin absorption
(Hovorka R et al., *Physiol Meas* 2004;25:905–920) in pure NumPy/SciPy as
`livemorebio/engines/metabolic/hovorka.py`. Every parameter carries its published
value, unit and source. Individualization uses body weight and the published
inter-subject parameter distributions (Wilinska ME et al., *J Diabetes Sci Technol*
2010;4:132–144). Insulin product identity is a first-class input: subcutaneous
rapid-acting analogue (the Hovorka `t_max,I` = 55 min absorption), and intravenous
bolus/infusion as a separate route with no absorption compartment. Regular human
insulin and intermediate/long-acting products are declared but NOT executable until a
sourced absorption model is admitted; a request for them returns
`INSULIN_PRODUCT_NOT_ADMITTED`, never a guess. The OSP GlucoseInsulin route stays in
the record as FAILED; it is not deleted and not retried here (A9).

D3. **Five botanical programs: an executable exposure-versus-active-concentration
framework, not invented efficacy.** For each LBHR program the executable question is
the one the handoff's own gap table asks: *does the modeled unbound exposure of the
declared material, at a declared dose and route, reach the concentration range at which
the declared mechanism was measured in vitro?* That is a standard preclinical
exposure-margin calculation. Each program manifest declares: material (purified
compound vs extract, with explicit non-equivalence), PubChem identity resolved live and
cached with provenance, an oral PK model with sourced parameters and the species they
came from, a concentration–response relation with the assay and source it came from,
endpoints, controls (zero dose; vehicle), and the transfer limits that block any human
claim (species, BBB, in-vitro-to-in-vivo). Where no human PK exists the run executes
at the nonhuman scale and reports `HUMAN_EXPOSURE_NOT_ADMISSIBLE`. Null outcomes are
expected and reported. The validation status of all six programs stays
`UNVALIDATED_IN_VIVO`; this plan moves them from "no execution path" to "executed,
sourced, reproducible, honestly bounded".

D4. **Individualized cross-system coupling, bounded.** Add an `Individual` covariate
layer (weight, sex, age, eGFR class, hepatic-function class) used consistently by the
Hovorka model (weight-scaled volumes), the botanical PK engine (allometric clearance
scaling with the 0.75 exponent and eGFR-proportional renal fraction, both sourced), and
the existing cardiac coupling. Flag A6 as `HYPOTHESIS_UNSOURCED` rather than silently
keep it.

D5. **Terminal.** Add `livemore doctor` (interpreter, dependencies, kernels, node,
model assets, ports from the service table, data-dir isolation, adapter reachability),
`livemore notebook` (Jupyter Lab with the SDK and an index notebook, optional
`--attach`), `program list|show|run|export` and `insulin ...` in the shell and pipeline
runner, persistent readline history and tab completion for verbs.

D6. **Jupyter.** `livemorebio/notebook.py` helper exposing `connect()`, `runs()`,
`run_frame()` and `plot_run()`; generated notebooks for the insulin program and for
the five botanical programs, executed end-to-end by a test through nbclient so every
cell is proven to run; export of new run types through the existing
`analysis_notebook` route.

D7. **Physical scope stays physical.** LIFE Patch hardware, Cendos wet lab, human
measurements, BAA-covered PHI intake and clinical qualification are not software
deliverables and are not claimed. Nothing in this plan changes their status.

## 3. Register rows advanced

R43/R44 (installer, clean install), R33 (insulin), R34–R36 (five programs: identity,
materials, full experiment packages), R37 (preparation→Cendos→Biology→Jupyter),
R45 (terminal/SDK/notebook parity), R48 (red-before-green regression tests),
R07/R18 partially (individual covariate layer), R13 (blocker ledger updated).
R40/R41 (videos), R32/R39 (physical) and R50 (release) remain OPEN.

## 4. Test plan (red first)

- Lock: a test that parses the lock and asserts every pinned version resolves on PyPI
  is a network test; instead assert the lock has no `libcellml==0.7.0` and that
  `pip install --dry-run --require-hashes` succeeds in CI.
- Node resolver: unit test that the resolver returns an executable or skips.
- Hovorka: positivity of all states; basal steady state under basal infusion within
  tolerance; monotone dose–response of glucose nadir; rapid-acting analogue plasma
  insulin peaks after the published `t_max,I`; zero-dose control equals no-insulin run
  exactly; determinism; individual weight scaling changes volumes and nothing else;
  non-admitted product refused with the exact code.
- Programs: manifest schema; identity resolution uses cache when offline; PK
  conservation (dose = absorbed + unabsorbed + eliminated within 1e-6); zero-dose
  control yields zero engagement; species flag propagates to the result; result
  freezes into `ProtocolRunStore` with inputs hash; CSV and notebook export execute.
- Terminal: `doctor` exit codes; shell `program`/`insulin` verbs through `run_command`;
  pipeline file runs.
- Notebook: nbclient executes generated notebooks headlessly.
- Regression: full `pytest -q` in the corrected environment; CI matrix on the PR.

## 5. Out of scope in this increment

OSP native admission (toolchains absent, source-domain failures unresolved), Human-GEM
tissue extraction, Unreal/MetaHuman, physical Rev B corrections, six recorded videos.


## 6. Outcome, recorded after implementation

### Achieved and verified

| Item | Evidence |
|---|---|
| A1 lock repinned; installer completes | Isolated-home run of `install.sh` pinned to this branch: download, hashed install, Human-GEM assets, full suite, compile, activation. Exit 0. |
| A2 portable Node; A3 fresh-home isolation | Full suite with an empty `HOME`: 54 failures before, 0 after (6,475 passed, 44 skipped). Linux result pending on the pull request. |
| A4 exogenous insulin engine | `livemorebio/engines/metabolic/hovorka.py`, 15 behavioural tests, exact mass balance, refusal codes for non-admitted products. |
| A5 botanical execution path | Five programs execute or refuse with exact codes; two analytical controls per run. |
| A8 terminal and notebook parity | `livemore doctor`, `livemore notebook`, `livemore programs`, shell `program`/`insulin` verbs, SDK methods, executed workspace notebook. |
| Locale and umask defects | `-X utf8` in installer verification; explicit chmod in the permission test. |

### Six-program status

Insulin executes as a paired within-individual design. Arctigenin yields a
computed margin below the measured active range at 400 mg. Erinacine A yields
exposure only. Sterubin, carnosic acid and cyanidin-3-glucoside are blocked with
named missing measurements or a published-parameter inconsistency.

**All six remain 0/6 validated in vivo.** That status cannot change without
physical measurements, which are outside software.

### Corrected assessment

A7 was not a defect. The isolated review stack runs on an explicit `--base-port`
range precisely so it cannot collide with the operating services on 8850-8852,
and the tester guide documents it that way. No change was made.

### Not achieved in this increment

A6 (the unsourced cardiac coupling slope is still exposed as `MODELED`, not yet
flagged `HYPOTHESIS_UNSOURCED`), A7 (ports still differ between the CLI table and
the review stack documentation), A9 (OSP native toolchains absent on this host),
D4's individual covariate layer beyond weight and volumes, the Cendos console UI
for the new protocols, R40/R41 recordings, and all physical LIFE Patch and wet-lab
obligations. R50 release acceptance remains open.
