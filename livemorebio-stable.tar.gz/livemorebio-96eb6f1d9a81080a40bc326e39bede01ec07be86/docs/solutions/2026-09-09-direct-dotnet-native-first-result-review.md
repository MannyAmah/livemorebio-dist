# Direct .NET first native packet: independent failed-result review

2026-09-09. Data/source-only review of the sole authorized packet in
`/private/tmp/livemore-osp-direct-native.73ZSdz/run`. No worker, inspector,
browser, test, solver, retry or product edit was performed by this reviewer.

## Verdict and preserved evidence

**FAILED / INSPECTOR_AMBIGUOUS_ROW remains the actual result.** S01 reached
PRE_XML, but received no ACK. No observation, FINAL or COMPLETE exists;
S02–S17 are NOT_RUN. `model_admission=false`, native-source attestation
UNVERIFIED and historical-author runtime UNKNOWN remain unchanged. This is
neither a numerical failure nor a qualified native scientific packet.

Independent read-only receipts `4ac39c`, `eeaf85` and `75870a` establish:

- All ten retained files were read and hashed; total retained size is385,040B.
- All198 package-file hashes, lengths and exact integer identities, eight source
  pins, ten directory identities and the complete package-file set match.
- Authorization SHA is
  `5bce65a5e25ecf5295b245d6ec0c5585af630cdac69aef23e36d6853fb085fdd`,
  mode0600; its JSON is exactly equal to the consumed `once.json` content.
- Packet identity matches the single PRE_XML frame. Its two managed snapshots
  are equal, each with14 unique paths. The3805 frame bytes and trailing newline
  match the retained3806B stdout. Case JSON equals packet S01 apart from the
  case-file reference. Every referenced stream/process/sidecar hash and size
  agrees with its original file; both processes report EOF without overflow.
- All model/packet/case/resource limits remain the authorized values.

The first audit command used a packet-relative rather than case-relative path
for its final case-file comparison and stopped with FileNotFoundError after
the printed pin/stream checks. `eeaf85` corrected only this reviewer path and
completed the exact case comparison; it is not a product or evidence defect.

| Original file | Bytes | SHA256 |
|---|---:|---|
| result.json |2187|`80847adcad309b58056195c6ee26451fa6b9ee51c6db66dd6a839e083dc84b77`|
| S01/case-result.json |511|`41dde82bdbee922b387ccc6ca5672d0e9b227895767b2d16087fee0eb75f59f2`|
| worker process.json |2396|`f330e1a5517d3a2a70bbba1d4b5d921458f4eff95702f63a024a076f076aa1f6`|
| worker stdout.bin |3806|`974ab3e7f97a92779c0b1b2516f7847b06fcbf9173e0fa71811fab4ff5bd5d2f`|
| failure sidecar |353|`76f0e6fc6e675e0b7ac9cb5aee67a6dcb77c1dcc5ba72d7c12832b2266f787ce`|
| PRE_XML/process.json |1723|`35f2a7c2cba8a1d00b839b6c443bec0b442f2a37fd7ad7e8970777b931e37f32`|
| PRE_XML/stdout.bin |373204|`9e56abe04f2b8ec73eedc08c8b0978bda8664298c77fa6a72616f80edbc413aa`|

Both stderr files are empty with the standard empty SHA256. The case and worker
receipts have empty evidence-error lists. The failure sidecar says UNADMITTED,
UNOBSERVED, zero rows, no failed PID; it does not identify a rejected process.
The actual parser input survives completely in the inspector stdout.

## Ownership and cleanup

Worker93171 has exact declared dotnet/DLL argv, PPID93162 and PGID93171;
inspector93181 has exact `/usr/bin/vmmap -w 93171`, PPID93162 and PGID93181.
Each receipt retains only its leader identity, with no accepted descendants.
Worker:29 samples, maximum gap0.125476167s, peak RSS48,381,952B; inspector:
17 samples, gap0.127385375s, peak RSS40,206,336B. No sampled overshoot appears.

Inspector finished exit0 in2.011913541s without TERM/KILL. Worker stopped with
TERM, no KILL, observed exit143 in3.136608833s. Both cleanup receipts are
SETTLED, error-null and empty-before-reap. Packet elapsed3.543017750s. This
inspection was within3s; it is not the historical1.5s timeout or evidence of SIP
refusal. Sampling remains sampled evidence, not hard memory isolation.

Root separately reports present-state postcheck `76625e`: exact ps for93162,
93171 and93181 returned header only/exit1. That observation belongs to root;
this reviewer did not perform process sampling or reinterpret it retroactively.

## Exact primary cause

The complete2305-line retained map contains exactly one row rejected by the
existing unused-row grammar/semantic checks, line1575:

```text
unused __DATA               1ef8e8000-1ef8eaa00    [   10K     0K     0K    10K] rw-/rw- SM=COW          on dirty page  unused /System/Library/Frameworks/CoreSpotlight.framework/Versions/A/CoreSpotlight
```

It passes the anchored unused grammar and increasing-address check in
`tools/osp_semantic_supervisor.py:388–390`, but fails397–399: named canonical
system-path annotations are allowed only for `__DATA_DIRTY`; `__DATA` requires
the literal `system shared lib __DATA`. This is a concrete representation gap.
An unused annotation must never become positive loaded-image evidence.

The pinned Apple vmmap manual was read directly as source (SHA
`cdd8195c81895d2dd261717aa73056e94546969ee4f887aed37888be3baaa18a`).
It documents wide full-path output, region purposes and distinct current/max
permissions. It does not specify this exact unused annotation grammar; the
exact retained row is the direct evidence for that form.

## Why a one-row patch is insufficient

Independent complete path accounting agrees with the child source review:

| Ordinary positive-path category | Rows | Unique paths |
|---|---:|---:|
| Exact frozen shared-cache map |1776|351|
| Canonical package paths |63|24|
| Exact `/tmp` spelling of this package |38|9|
| Other mapped-file rows |2|2|
| Total |1879|386|

The frozen cache-map hash was independently checked against
`22fb14ddcf854e3d828696b9b34b11f247b74ae456468bfc700b8cc20b14365b`;
it contains3643 names. All nine actual `/tmp` paths resolve to their exact
`/private/tmp` package counterpart with the same file identity; they are not
additional libraries. Nevertheless the current lexical admission at
`tools/osp_dotnet_worker.py:415` rejects them.

The two other original rows are line68, a Logging `.plist-cache` mapped file
with `r--/r-- SM=COW`, and line181, `/usr/share/icu/icudt78l.dat` with
`r--/r-x SM=ALI`. Neither is in the package or frozen cache-image list. Their
contents were not opened. In particular ICU's maximum permission includes x;
its extension and current read-only permission alone do not establish a safe
data-only classification. These are prospective admission refusals, not the
recorded primary failure.

Finally `MIN_MANAGED` currently requires `OSPSuite.Utility.dll` at PRE_XML,
but neither actual snapshot includes it. `NativeSimulation.Inventory()` only
lists already loaded assemblies. Its explicit OSPSuiteException catch sites
are in Load/Finalize, after PRE_XML. File presence/pinning does not prove
assembly loading. This later MANAGED_REQUIRED refusal would also remain after
map fixes; no final-stage observation exists to establish later loading.

## Decision-ready alternatives — no implementation authorization

**Do not recommend piecemeal allowance changes followed by native retries.**

Preferred: one direct-parent-specific typed region/admission correction,
leaving the consumed historical supervisor and evidence untouched. Preserve
raw bytes, region kind, address interval, current/max permissions, share mode
and original/canonical path. Use one finite classification:

1. Exact unused annotations: constrained grammar, including the observed named
   `__DATA` form; retained as unused and excluded from positive image proof.
2. Image/managed candidates: all must satisfy exact package identity/hash or
   the existing frozen system-cache contract. The one exact `/tmp` alias may
   resolve only into this pinned canonical package with equal identity and
   a declared relative path; no generic resolve/prefix trust or provenance load.
3. Non-image mappings: retain distinctly, never count toward required images.
   An exact non-executable `mapped file` row can be described as a non-code
   mapping, not silently asserted safe or admitted code. The ICU max-x mapping
   requires a separately reviewed source-backed resource/format and exact pin
   decision; until then it remains unresolved/fatal. No auto-learned allowlist,
   random cache-file hash chasing, or exclusion based only on file extension.
4. Managed closure versus loaded evidence: retain every package principal pin
   and validate every observed assembly. Specify source-justified phase minima
   independently of dependency-file presence; do not force-load Utility merely
   to produce an apparently reassuring inventory. A phase-minimum change needs
   explicit approval and tests; absence at an unobserved phase is not proven.

Cost: a small typed direct-parent parser/admission interface and portable
regressions for the entire retained corpus's row classes, alias attacks,
unexpected executable/managed paths, provenance, malformed rows and phase
minima. The original full corpus remains a separately explicit forensic input.
The two resource semantics and precise phase minima must be settled before
another immutable package or once authorization. Keep17 cases/16 Runs,
all scientific oracles and budgets unchanged. Unknown row classes fail once;
they do not silently acquire permission.

Alternative: structured OS image enumeration replacing text parsing while
retaining independent parent verification. This removes text-format ambiguity
but introduces a new OS ownership/ABI/read-memory interface and its validation;
it is higher cost and not authorized by the present correction. A self-reported
managed list alone cannot replace independent native-image proof. Neither
alternative currently justifies a new native run.

## Insulin gates even if all17 technical cases eventually pass

The [declared source graph](2026-09-08-osp-declared-source-graph-results.md)
and [source-admission proposal](2026-09-08-osp-insulin-next-source-admission-proposal.md)
remain the scientific next-step evidence, not another runtime installation:

- Resolve all15 receptor restoration concentration-versus-amount/time laws,
  PTP/S_I conventions, hepatic feedback/pool domains and signed-counter intent
  from exact source evidence; do not invent constants or clamp negatives.
- Resolve56 original NaN declarations and their98 references, original time
  units, and model-specific event/table/initialization interpretation. The
  complete declared graph and empty27 reverse initializer lists do not make
  downstream numeric inputs complete or prove publisher intent.
- Original Stage B still fails I0/I2, T1/T2, T0/T2 and C0/C2 convergence gates
  and negative-domain checks. A tighter-reference preregistration/common
  initialization diagnostic needs separate review; no tolerance relaxation.
- Historical author runtime/solver and all-state reference equivalence remain
  unknown. Technical fixture success cannot attest native source equivalence.
- Individual exogenous insulin requires exact formulation/potency, route,
  rate/timing, individual clearance/physiology, measured paired exposure/glucose
  and untouched validation data. Shared source Insulin is not an administered-
  fraction tracer. No whole-human replication or clinical validation follows.

All six programs remain required: insulin and LBHR172/129/062/030/135.
This failed technical attempt replaces or completes none of them.

**Lesson:** a pinned dependency closure, a mapped-file list and a loaded-code
inventory are different evidence types. Define their full boundary together
before using another actual packet as an incremental parser discovery loop.
