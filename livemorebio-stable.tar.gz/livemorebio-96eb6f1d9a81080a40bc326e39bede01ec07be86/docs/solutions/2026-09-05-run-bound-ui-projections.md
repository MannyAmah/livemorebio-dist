# Run-bound UI projections and progressive disclosure

## Failure mode

The Atlas time slider previously changed only a label. Biological motion used fixed CSS or random particle timing, and a selected Cendos experiment was displayed above the separately active twin's organ state. This made an interactive view look more scientifically connected than its data path justified. The evidence panel also toggled a class with no collapsing style.

## Implemented boundary

- Atlas selects exact stored `t_min`, glucose, and insulin samples. It shades the existing whole-body illustration from the selected glucose value; static anatomy is identified explicitly. Missing values remain unavailable. Playback selects saved samples and stops at the final sample, when hidden, or when the workspace stream becomes stale.
- The primary workspace shows Atlas, a whole-body state view, and research actions. Advanced twin controls use native disclosure; evidence uses an accessible, genuinely hidden drawer. All core product routes remain accessible.
- `/biology?run_id=…` is an isolated projection of that frozen run. It never requests the active twin's `/api/biology`, including invalid and missing-run failures. The active anatomy explorer remains at `/biology` without a run identifier.
- Metformin uses stored, member-specific baseline and treated ODE trajectories when present. Legacy endpoint-only runs explicitly have no time controls.
- Garcinoic-acid/PXR selects a recorded member and concentration. It displays concentration-response points without interpolation or time kinetics. Reference occupancy, expression priors, and modeled activation remain separate from unmeasured downstream response.
- Removed fixed organ pulsing, autonomous CSS physiology animations, and random cell particles. A cardiac cell trace may play its stored voltage/calcium values; that is recorded-model playback, not observation.

## Recorder contract

Preserved Atlas IDs: `#time-slider`, `#time-play`, `#advanced-controls`, `#evidence-open`, `#evidence-close`, `#timeline-glucose`, `#timeline-insulin`. Evidence deep links `/#evidence-panel` open the drawer.

Frozen-run controls: `#protocol-member`, `#protocol-context`, `#protocol-member-readout`, `#protocol-plot`, `#protocol-values`, `#protocol-kinetics`. Metformin adds `#protocol-time-slider`, `#protocol-time-play`, `#protocol-time-readout`, `#protocol-cohort-plot`. PXR instead uses `#protocol-concentration` and intentionally has no time controls.

The video should record preparation and actual clicks before showing these projections. Pause on source provenance, member differences, the selected run identity, unavailable endpoints, the exported analysis, and comparison requirements. A moving cursor or plot is not evidence of human-equivalent physiology.

## Implementation QA (not independent acceptance)

On the isolated local service at port 8860:

- Created clearly named UI-check DPP, NHANES, and PXR reference cohorts, three members each. No real-human data or active-twin changes were used.
- Metformin run `protocol-b1329b46045d4777b226c5ea9b9c6d9e`: selecting the final recorded sample showed 240 min, glucose 137.57 mg/dL and insulin 25.19 µU/mL for the first NHANES member. Switching member changed the mean response and reset recorded time to zero. Playback advanced actual saved values.
- PXR run `protocol-0840aa065227413382b77746ea80bc41`: switching member and concentration changed the readout, selected point, and table row consistently. The selected third member at 5 µM showed activation 0.8302 with expression prior 1.046. No time controls or active-biology requests existed.
- Invalid experiment IDs displayed an error with the active anatomy hidden and no `/api/biology` request.
- Atlas evidence open/Escape close and deep linking worked. Exact sample selection changed the numerical readouts; no autonomous CSS animations were running.
- At 390 px, Atlas, Cohorts, and PXR had no document-level horizontal overflow. Navigation and the atlas path retain their own horizontal scrolling.
- Six focused unit/route regressions passed; JavaScript syntax and `git diff --check` passed. Independent review and final recording acceptance remain release gates.

## Durable lesson

Treat every visualization as a typed, provenance-bound projection: run → member → condition or recorded time → available variables. Do not infer missing dynamics from an attractive animation. A failed run lookup must fail closed, never substitute unrelated live state. Keep software-function verification distinct from biological qualification.
