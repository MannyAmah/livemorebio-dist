# Readiness, platform strategy, what the software actually computes, and how each blocked item gets unblocked

Date: 2026-09-22. Written for the founder and for an incoming engineering or
scientific lead. Every claim here is either backed by an execution receipt in
this repository or is explicitly marked as a plan.

## 1. What is functional and ready today

"Ready" below means: a person other than the author can install it on a
supported machine and use it, and its behaviour is covered by tests that pass
from an empty home directory.

| Capability | State | Evidence |
|---|---|---|
| One-line installer, pinned commit, hashed lock | Ready | Isolated-home install to exit 0, full suite inside the installer |
| Terminal: `livemore` shell, pipelines, `doctor`, `programs`, `notebook` | Ready | `test_terminal_and_notebook_parity.py`, `test_cli` cases |
| Python SDK (`Platform`), in-process and attached | Ready | SDK methods exercised by protocol and API tests |
| Jupyter workspace and per-run exported notebooks | Ready | Notebooks executed headlessly in tests and in the deliverables |
| Three services (Aegle 8850, LIFE 8851, Cendos 8852) with local token auth | Ready | Health checks, HTTP contract tests |
| Console: Atlas, Twins, Cohorts, Cendos Lab, Biology, LIFE Patch, Research | Ready for the shipped workflows | Browser QA; console UI tests |
| Exogenous insulin engine (Hovorka) and paired protocol | Ready as a research model | 16 engine tests, mass balance, zero-dose control |
| Botanical exposure programs, 3 of 5 executable | Ready as a research model | Margin and exposure runs, analytical controls |
| Botanical programs, 2 of 5 blocked | Correctly refusing | Typed refusals with the missing measurement named |
| Human-GEM steady-state capacity (pinned 2.0.0) | Ready | Verified assets, solver runs, negative controls |
| Cardiac ventricular cell (O'Hara-Rudy via Myokit) | Ready as a research model | Kernel installed and exercised |
| Metabolic-cardiac coupling | Executable but labelled `HYPOTHESIS_UNSOURCED` | Magnitude has no admitted source |
| Immutable protocol runs, exact rerun, CSV and notebook export | Ready | Storage, rerun-lineage and export tests |
| Local tamper-evidence: audit log, signing, evidence store | Ready as local integrity only | Not a qualified electronic signature |
| LIFE Patch virtual counterpart and session admission | Ready as software only | Emits declared numerical channels, not sensor readings |

Not ready, and not claimed: the physical LIFE Patch, the physical Cendos wet
lab, real-person onboarding with PHI, multi-user hosting and tenancy, clinical
or regulatory qualification, and validated individual prediction for any
program. The six requested programs remain 0/6 validated in vivo.

## 2. Platform: why POSIX, and what a business client actually runs

### Why it is POSIX today

This was not a product decision; it is an inherited consequence of enforcing
local confidentiality with POSIX file semantics. The product gates PHI-like
local state on owner-only directories and files (0700/0600), single-link regular
files, `st_uid` ownership equality, and `fcntl` advisory locks. There are 32
such checks across the registry, execution store, evidence store, protocol runs,
model assets, anatomy cache and the LIFE Patch journal.

Windows cannot express those guarantees: `st_uid` is always 0, `chmod` only
toggles a read-only bit, and there is no `fcntl`. Porting natively would mean
deleting or weakening the 32 checks that exist specifically to protect local
patient-like data. That is a security regression dressed as a feature, so the
product now refuses native Windows with a clear message instead.

### What a client on a Windows laptop does

Both supported paths run the product on Linux, so every protection stays intact:

1. **Docker Desktop.** `docker compose up`, then open `http://127.0.0.1:8850`.
   The `Platforms` workflow builds the image, starts the three services, and
   drives an insulin run, a botanical run and a blocked program through the
   container API on every relevant change, so this path is proven, not assumed.
2. **WSL2.** A Linux distribution inside Windows, then the normal one-line
   installer.

`livemore doctor` states the platform, and operational commands exit 2 with the
supported path named rather than failing somewhere deep in a file check.

### If native Windows becomes a requirement

It is a scoped project, not a port: replace the 32 ownership and mode checks
with a Windows ACL equivalent (owner SID plus explicit DACL verification),
replace `fcntl` locks with `msvcrt`/`LockFileEx`, replace hardlink-based atomic
publication, add a PowerShell installer, and extend CI to windows-latest as a
first-class gate. The security review must cover the ACL equivalence, because
that is where the guarantee actually lives.

### For a demonstration to a client who will not install anything

A single-tenant hosted instance is the third option, and it is currently
blocked by product gaps rather than by hosting: the services authenticate with a
single local operator token over loopback, with no user accounts, tenancy or
per-tenant isolation. That is the work item, not the VM.

## 3. Why the outputs are computed rather than "real reactions"

This deserves a precise answer, because "simulation" hides three very different
things.

1. **Scripted appearance.** An animation or a predetermined outcome. This is
   never acceptable here, and the integrity work removed the places where it had
   crept in (generic compound benefit multipliers, gene-to-organ scaling).
2. **Curve fitting.** Fitting parameters until the output matches the desired
   answer. Also refused: the bilberry program is blocked precisely because
   fitting would have hidden a contradiction in the published parameters.
3. **Mechanistic computation.** Numerically solving equations that encode a
   mechanism and its conservation laws. This is what the platform does:
   * insulin: a compartmental system of ordinary differential equations with
     subcutaneous absorption, insulin action and glucose kinetics, with insulin
     mass balance checked to 1e-6 on every run;
   * cardiac: ion-current equations for a ventricular myocyte;
   * metabolism: a stoichiometric network solved under mass balance, `S·v = 0`,
     with declared bounds and negative controls;
   * exposure: compartmental pharmacokinetics with a dose-clearance identity
     checked numerically on every run.

A real chemical reaction is a physical event. No software observes one; software
computes a model of one. Even a first-principles quantum-chemistry calculation
is a model with its own approximations. So the honest ceiling for software is:
compute the mechanism, check conservation, expose the assumptions, and predict
something that a physical experiment can falsify.

That ceiling is not a small thing, and it is exactly what regulators accept when
it is done properly: a model is qualified for a specific **context of use**, with
a prespecified validation dataset and prospective, held-out predictions. The
platform is built to support that path: frozen inputs, immutable runs, declared
tolerances, and controls that travel with the result. What it cannot do, at any
level of engineering effort, is turn a calculation into a measurement.

Getting real reactions and real perturbations therefore requires the two
physical products that remain unbuilt: the Cendos wet lab and the LIFE Patch.

## 4. Clear paths to unblock each item

Ordered by how quickly each converts into a result. Times are engineering and
vendor estimates, not commitments.

### 4.1 Bilberry, LBHR-135 — unblocked on 2026-09-22, without new data

The blocker was treated as missing data, but the cited human study reports the
parent compound's peak concentration and total exposure directly. An
exposure-margin question does not need a kinetic model when the exposure itself
was measured, so the program now has a measured-exposure route alongside the
modelled one.

Result at the dose the study administered:

| Quantity | Value |
|---|---|
| Measured peak concentration | 0.141 µM |
| Active range from the cited assays | 0.1 to 2 µM |
| Margin to the active floor | 1.41 |
| Margin one standard error below the peak | 0.71 |
| Robust to one standard error | No |

So the parent compound reaches the low end of the measured active range on the
mean, and falls below it within one standard error. That is a real and useful
answer, and it is weaker than "reaches the range" alone would suggest.

Two guards ship with it. The contradiction in the published summary parameters
is still recorded and still blocks the modelled route, rather than being fitted
away. And a measured exposure is never scaled: requesting any dose other than
the one administered returns `DOSE_NOT_MEASURED_AT_THIS_LEVEL`, because scaling
a measured peak would need exactly the model this program does not have.

Still open for this program: the metabolites, which is where the cited
endothelial activity mostly sits, and a dietary-intake dose rather than a
500 mg bolus of the purified compound.

### 4.2 Yerba santa, LBHR-129 and rosemary, LBHR-062 — blocked on exposure

*Missing:* clearance and volume, or C-max with t-max and half-life, plus an
unbound fraction. Rosemary additionally lacks a concentration-response.
*Paths:*
- A standard in vitro ADME panel at a contract lab: logD, plasma protein
  binding, microsomal and hepatocyte stability, Caco-2 permeability. Typical
  turnaround is weeks at modest cost. Those inputs parameterise an
  in-vitro-to-in-vivo extrapolation or a physiologically based model, which
  produces the exposure the program needs.
- A rodent pharmacokinetic study for a directly measured profile. Longer and
  more expensive, and it is animal work with its own approvals.
- For rosemary, an antioxidant-response-element reporter assay with an
  eight-point concentration curve to fix the active range.
*Unblocks:* both margins, and the same panel is reusable for any future
botanical, so the second program costs far less than the first.

### 4.3 Lion's mane, LBHR-172 — exposure exists, activity range does not

*Missing:* a measured concentration-response for an erinacine A mechanism in a
relevant neuronal or glial context. Published in vivo doses are not
concentrations.
*Path:* a neurotrophic-factor induction assay in the relevant cell type with a
concentration series, then the existing exposure model yields a margin directly.

### 4.4 Insulin — executable, not validated

*Missing:* product-specific pharmacokinetics and pharmacodynamics, individual
calibration, and held-out validation.
*Path:* define the context of use (for example, meal-bolus response in
insulin-deficient adults), assemble a published clamp or meal-test validation
set, predict prospectively without refitting, and report the error distribution.
That is the step that converts "executes" into "qualified for this use".

### 4.5 Native OSP engine

*Missing:* the .NET and R toolchains are absent on this machine, and the earlier
attempt failed on source-domain grounds, including negative compartment amounts
in the original model file.
*Path:* provision the toolchains in a container, reproduce the failure, then
resolve the source semantics with the model authors. Note that a successful
launch would still face the original convergence and domain failures, so this is
sequenced after the items above.

### 4.6 Physical LIFE Patch

*Path, in order:* correct the Rev B errata and re-review; build firmware and the
gateway; manufacture research units under controls; bench-verify each channel
and its transfer function; biocompatibility and electrical safety; then paired
measurements on consenting people under ethics approval. Nothing here is
software, and no software result substitutes for it.

### 4.7 Physical Cendos wet lab

*Path:* facility and instruments; a laboratory information system with sample,
reagent-lot and chain-of-custody records; validated assays with acceptance
criteria declared before the run; then the physical counterpart of a modelled
result, compared against predeclared tolerances.

### 4.8 Production posture for real patient data

*Path:* user accounts and tenancy, per-tenant isolation, reviewer identity and
signing, encryption and key management, audit retention, disaster recovery, and
a business associate agreement with every processor that touches PHI. Until this
exists, the product is a single-operator local research tool, and the
documentation says so.

## 5. Recommended sequence

1. ~~Digitise the bilberry profile.~~ Done a simpler way: the measured human
   peak and exposure were already published, so the program now answers from
   measured values. See 4.1.
2. Commission the in vitro ADME panel for sterubin and carnosic acid, plus the
   two concentration-response assays. Weeks, unblocks three programs.
3. Define the insulin context of use and assemble its validation set.
4. Decide the client-facing path: container demo now, or fund tenancy and
   hosting for a shared instance.
5. Sequence the physical programs, which set the real timeline for anything
   described as preclinical or clinical.
