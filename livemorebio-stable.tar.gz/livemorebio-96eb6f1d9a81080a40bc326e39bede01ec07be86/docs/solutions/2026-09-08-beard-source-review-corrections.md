# Beard source admission and failure-evidence corrections

Date: 2026-09-08. Status: implemented; independent re-review pending. This is a
software integrity correction, not a physiological or arctigenin result.

## Prior art and scope

The approved [source preregistration](2026-09-08-beard-native-source-preregistration.md)
remains unchanged at SHA-256
`95351a1e380178725ab38731d8e9dc63b57ebd4a1ae507dad17d3884e28167e7`.
The [implementation review record](../BEARD_NATIVE_SOURCE_IMPLEMENTATION_REVIEW.md)
retains both original and corrected candidate hashes, root's written pre-code
scope, test evidence and reproduction instructions. No numerical threshold or
source default changed. Both source execution gates remain false.

## Independently found failure modes

1. A truncated JSON diagnostic could replace a known nonzero native exit with a
   parser failure and erase retained supervision/cleanup evidence.
2. Redox sums could agree while a partner was slightly negative. The generic
   concentration uncertainty band did not satisfy the strict source-domain gate.
3. MathML errors carried an identity at origin but lost it during orchestration;
   row time, native unit and analysis stage were not consistently retained.
4. A scientific source hash mismatch was incorrectly treated as technical input.
   Adding a newline to the pinned source could bypass its evaluation review lock.

## Corrections and regression evidence

Native failure remains primary; diagnostic parsing is secondary and the raw
output hash is retained. Both partners in all three redox pairs must be
nonnegative. Qualified expression identity, native unit, quantity kind, time in
seconds and initialization/output-analysis stage survive normalization. Explicit
technical admission accepts only the named bounded scalar-dependency fixture,
with fixed state/variable/unit/connection schema—not arbitrary unpinned models.

The four-finding regression packet first produced 26 failures while the original
62 tests passed. Corrected combined tests: 154 passed, 13 explicit opt-in skips,
2.83 s. Static source checks and the previously reviewed rejected Myokit parser
path were included; no Beard C compilation, initialization, RHS or solve occurred.
Native I0a/I0b/B0/B1/R1/K1 remain NOT_RUN pending independent review and approval.

## Reusable lesson

Source mismatch is a rejection state, not a testing privilege. A secondary
diagnostic must not overwrite independently established failure evidence. A
conservation identity and an admissible biological domain are different gates.
Test error context across the complete execution path, not only the point where
the error originated. Review gates cannot be waived by passing software fixtures.

The requested Compound Engineering/gbrain tools were unavailable in the enabled
tool inventory; this scoped durable record is the local fallback. It does not
represent a separate external review or a completed scientific program.

## Subsequent once-only execution outcome

Independent re-review cleared the four software corrections. Root then read and
approved a hash-bound private driver for one exact native matrix attempt, without
changing on-disk gates. The attempt completed but the full numerical acceptance
failed: 552 B0↔B1 algebraic identity/time discrepancies, despite all 19 state
trajectories passing their own comparison limits. R1 repeat and K1 restart passed.
The [retained results report](../BEARD_NATIVE_SOURCE_MATRIX_RESULTS.md) records
source identity, resources, cleanup and immutable failure evidence.

Additional lesson: solver/state accuracy does not automatically establish accuracy
of derived biological fluxes. Preserve a failed full-output comparison even when
the states and local expression checks pass. A successful compiler/solver path is
useful progress, not permission to relax the independently specified output gate.
