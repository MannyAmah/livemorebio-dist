# Legacy research-preview client recovery — maker implementation receipt

2026-09-08. Bounded client implementation, **not independent acceptance or browser
qualification**. Root approved the complete written plan before code, including
its explicit reopen, pre-stringify JSON domain and callback-failure refinements.
Plan: `2026-09-08-legacy-preview-client-recovery-plan.md`, SHA256
`5b3872d67fb2abf6ec59fa9042ef174f2ab45fd69c89e586b84cd2007b3a6632`.
The only wording correction to the original proposal clarifies that the old SDK
audit stored a **note-presence boolean**, not note text; demographic/genome inputs
and numerical outputs were logged, while raw note text leaked through pipeline
echo. Root was notified. No earlier audit bytes or audit.py were changed.

## Scope and frozen files

Only the approved six runtime files and two new test modules were changed.
Paths in the table are under `livemorebio/`.

| File | SHA256 |
| --- | --- |
| aegle/console/index.html | `93c65024d14f20abd420fd228ce876fcf624b97d0a9a4050b9c2f2b97c4a7b3f` |
| aegle/console/lib/legacy_preview_recovery.js | `b0573137df31aaafca829eae60534374a1201d7eec63e183043345193187a7f4` |
| aegle/console/lib/selection_reconciliation.js | `ade4d421f9e4f8bcf462dae3a327008d1f0e70136f98c6c6cb39964a4e301b00` |
| sdk.py | `2c8e7529e168e562d7957e28547dfe981d050f6f0d2fb0222e5b7a1efac29af3` |
| shell.py | `1d4882c3902f6be37a5dc7a059687c0e711f10d4508db5361de42a96422de661` |
| execution_client.py | `85613eedd3601db8ad3babd62340ad8e6ec9ca3a12c091a6e090aacfd909cb90` |
| tests/test_legacy_preview_recovery_clients.py | `6e7d5108c0b6cb95e596490bcfdba8f167df3983c476c13a2dd7961ca1c3b0f9` |
| tests/test_legacy_preview_recovery_ui.py | `f1c5f72008e3eb006222e56b9beb62773973da77bd2405357cb1000decd1690f` |

The new owner is177 lines; dedicated Python test files are312 and346 lines.
Original six-file source pins are preserved in the approved plan. No existing
test file was edited: no stale `patient._post` fixture required migration in the
exercised preservation packet. Other methods' `_post` fixtures and assertions
remain intact. Terminal `run_command(patient)` retains its historical **None**
return; an early authored test incorrectly expected a dictionary and was fixed
to assert the actual printed summary and unchanged return contract.

Unchanged supporting pins:

- biological_projection.js:
  `b38498f48bc5677e601e1f9a340ad9e6074ef3db1925356ed273db76b63d3c37`.
- auth.js:
  `4e5130f476ce0a3a3a0d0096986985cbdd2ecbf7131afbe3e89d7a7430996bf3`.
- workspace.js:
  `1bb39afbda46a04ada6763dc9997ae023ee964ae7b9b76c0c67069386a1242f5`.
- Root-owned server during the87-case preview preservation:
  `cedcf801a9ede06cbddcc2de75a495068a0970c6785e68f8e5d9664e67c52f18`.

## Implemented contract

The legacy page has one local epoch/operation owner. It distinguishes submitted
preview ACK, fresh current-state read, unknown authority and prior cleanup.
Base/LIFE/note submit one bounded POST and at most one separate state GET; an ACK
never installs itself as current state. Matching-generation extraction may be
displayed with that fresh read, without merging it into a later winner. Fixed
notices and current UUIDs survive rendering. UNKNOWN permission cannot invoke
preview or numerical actions; confirmed modeless selection permits explicit
research preview but not numerical actions.

All existing numerical state writers acquire/check the same ticket without
changing their endpoint, body or model calculations. Failure revokes current
permission, invalidates the epoch and clears current presentation; an obsolete
ticket cannot release or clear a newer operation. Pending current reads also
deny programmatic numerical acquisition. Pagehide invalidates/disposes; explicit
reopen performs one fresh read and does not reinstall handlers or replay a body.
The actual late-biology path checks this epoch before touching current DOM.

Clear detaches S and LASTRUN before best-effort DOM work, clears current charts,
metrics, warning/provenance classes, human/note/organ/patch summaries and body
activity, while retaining reference structure and frozen EXPERIMENTS history.
Input choices and recovery navigation remain. Callback errors use fixed notices,
never raw exception strings; failed pre-submit clearing cannot dispatch a POST.

The named browser request uses existing authenticated strict transport and
expected200, no redirect following, fixed60s POST/20s GET absolute deadlines
through body/parse admission and2,000,000-byte strict JSON bounds. JSON data is
validated before stringify, rejecting nonfinite/coercible values, accessors,
custom prototypes, cycles and excess depth. Ordinary finite JSON is preserved.

Attached SDK patient uses only the named preview transport with the approved
2,000,000-byte request exception. Ordinary16KiB requests,8MiB responses and the
exact frozen-member16MiB response/parser exception are preserved. Its60s urllib
timeout remains a blocking/socket timeout, not a total wall-clock deadline.
Preview identity, own parameters and required summary fields are admitted before
summary creation; no local model/extractor/registry fallback or automatic GET.
Local audit receives only fixed family/outcome/current UUID metadata. Observable
audit or close failure remains a separate warning without erasing a valid ACK.

Terminal patient success remains the existing summary, explicitly labeled as
this acknowledged research preview, not a current registered person. Pipeline
echo is redacted, including malformed quoted tails; typed failures stop the
pipeline without subsequent commands, and the REPL offers state/list/explicit
reconciliation and separate cleanup inspection. Existing in-process behavior,
unrelated commands and audit.py are unchanged.

## Retained RED and intermediate evidence

All roots below have prefix
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-`.
Counts are individual runs, not additive unique coverage.

- Initial tests frozen before runtime edits: clients
  `27de79c9f2bee2a6693738692b0a07bbbc1fcf8c2e24ccc368c5f6ce12483ef3`,
  UI `1be6c23b09283bccc147b348c88feb6468f98448d559f809994227ab02ccd8d4`.
  **138 failed,5.24s**, `afvbgntu`,69 authored Node calls, no unexpected I/O.
  Many UI assertions were prospective behind the missing module; this is not138
  independently demonstrated product defects.
- First implemented repeat: **127 passed/11 failed,7.85s**, `hkb4n0gm`.
  Test equality assumptions rejected valid null-prototype copies, and actual
  controller fixtures crossed JS realms. Tests now compare JSON values and
  execute the real owner/controller in one VM realm. Production JSON-domain
  checks were not weakened to accept foreign/custom prototypes or getters.
- **137 passed/1 failed,7.80s**, `c1qrv8ae`: late-biology test erroneously shared
  its deferred response with the legitimate new request.
- **150 passed/7 failed,9.45s**, `oxti4w9p`: six newly authored deadline scripts
  had unmatched braces, and one legitimate new biology callback was not settled
  before comparison. Readable fixture code and separate request completion fixed
  those test defects; no deadline or parser limit was changed.
- Root's actual numerical handler finding reproduced **159 passed/2 failed,
  10.17s**, `cfceq6jj`: real stim/runVia plus actual render failure left owner
  READY permission after S cleared. Root approved ticket-checked
  failNumericalAction. Two stale-response/finally controls already passed.
  After correction: **161 passed,10.00s**, `d7wlo638`.
- Actual animation-clear probe: **1 failed/1 passed**, `p87wy5jz` (0.35s), then
  strengthened joint assertion `i7a7rjfk` (0.40s). Clear targeted o-metab instead
  of actual o-metabolic and CSS transform instead of the cardiac SVG attribute;
  both retained old activity. Exact targets were corrected, no animation math.
  Actual bfcache lifecycle control passed. **163 passed,10.73s**, `2_mv_p_x`.
- A final programmatic pending-read probe failed once in0.24s, `oega1_hb`.
  Numerical acquisition now refuses an owned current read; explicit preview
  overlap still invalidates the earlier read without retransmission.

Every run above recorded unexpected I/O0. Authored Node counts and stderr contain
technical fixture values only; no operational input or secret was used.

## Final verification

| Packet | Actual result | Private suffix | I/O receipt |
| --- | --- | --- | --- |
| Final dedicated164 + preservation370 + frozen-member98 | **632 passed,32.06s**, exit0 | `hxuvwy55` | Node186; unexpected0; optional Git refused1 |
| Prior standalone preservation370 | 370 passed,17.14s | `g7pyof7g` | Node98; unexpected0; Git0 |
| Prior standalone frozen-member98 | 98 passed,4.93s | `e9gy3cn5` | Node0; unexpected0; Git1 |
| Inert preview70 + retained15 + retirement2 | **87 passed,3 existing warnings,1.83s** | `hrsbsg25` | unexpected0; Git1 |
| Clean-workflow non-model subset | **13 passed,3 deselected,2.17s** | `03miogi2` | unexpected0; Git1 |

The632 repeat includes actual response byte/depth/duplicate/nonfinite/UTF-8 rules,
transport read/deadline/encoding/close failures, safe current UUID behavior, exact
16MiB private frozen-member registry→JSONResponse→SDK preservation, existing
selection/clinical availability UI/SDK/terminal, execution clients/commands,
model-workflow clients and clean UI. All inputs are authored technical fixtures.
It uses186 bounded offline Node invocations, not a real browser. The dedicated
set includes11 actual legacy controller scenarios, not just source strings.

The87 and13 packets reuse the exact45-second private ASGI wrapper from
`2026-09-08-binding-real-registry-integration-review.md` §Exact bounded repeat:
replace only its pytest selection with the three preview files
`test_confirmed_preview_publication.py`,
`test_committed_preview_transitions.py`,
`test_source_retirement_lock_boundary.py`; for13 select
`test_clean_workflows.py` and the following exact -k expression:

`not test_local_sdk_starts_healthy and not test_http_registry_pages_and_healthy_empty_start and not test_preview_transition_clears_persisted_identity_but_invalid_base_preserves_it`

Those **three original tests remain unrun**, not migrated, weakened or counted
as passes: they construct real AegleTwin (and the SDK default constructs/solves).
Root explicitly excluded them from this no-model unit gate. The wrapper retains
constructor/compiler/network/process traps, allows only internal TestClient
socketpair and authored private SQLite, and starts no service or native model.
No existing test source changed. These overlapping packets are not broad release
acceptance. Scoped `git diff --check` passed.

## Exact632 repeat command

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`.
The45-second whole-run deadline and12/15-second existing per-Node bounds remain.
Only fixed Node eval shapes are permitted; Python/Node network and process APIs
are refused except those authored Node children. This is bounded offline testing,
not a hard OS sandbox claim.

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os,sys,socket,urllib.request,subprocess,signal,ctypes,multiprocessing.process
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment();os.environ.update(env)
print('Private root:',root,flush=True)
counts={'node':0,'git_refused':0,'unexpected':0};permit=False
def deny(*a,**k):
 counts['unexpected']+=1
 raise AssertionError('NETWORK_OR_PROCESS_REFUSED')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
multiprocessing.process.BaseProcess.start=deny
original_run=subprocess.run;original_popen=subprocess.Popen
prefix='const deny=()=>{throw Error("NETWORK_OR_PROCESS_REFUSED")};globalThis.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=await import(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m.default?.[n]==="function")m.default[n]=deny;}const net=await import("node:net");net.default.Socket.prototype.connect=deny;\n'
cjs_prefix='const deny=()=>{throw Error("NETWORK_OR_PROCESS_REFUSED")};globalThis.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):
 if permit:return original_popen(*a,**k)
 return deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and len(cmd)==4 and cmd[0]=='/opt/homebrew/bin/node' and cmd[1]=='--input-type=module' and cmd[2] in ('-e','--eval'):
  counts['node']+=1;permit=True
  try:return original_run([*cmd[:3],prefix+cmd[3]],*a,**k)
  finally:permit=False
 if isinstance(cmd,list) and len(cmd)==3 and cmd[0]=='/opt/homebrew/bin/node' and cmd[1] in ('-e','--eval'):
  counts['node']+=1;permit=True
  try:return original_run([*cmd[:2],cjs_prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1;raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
def audit(event,args):
 if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system','ctypes.dlopen'} or event=='subprocess.Popen' and not permit:deny()
sys.addaudithook(audit)
def alarm(*a):raise TimeoutError('REVIEW_45_SECOND_BOUND')
signal.signal(signal.SIGALRM,alarm);signal.alarm(45)
import pytest
try:
 result=pytest.main(['-q','-p','no:cacheprovider','--tb=line', '--disable-warnings','livemorebio/tests/test_legacy_preview_recovery_clients.py','livemorebio/tests/test_legacy_preview_recovery_ui.py','livemorebio/tests/test_frozen_member_response_limits.py','livemorebio/tests/test_selection_reconciliation_ui.py','livemorebio/tests/test_selection_reconciliation_clients.py','livemorebio/tests/test_clinical_sdk_terminal.py','livemorebio/tests/test_clinical_model_availability_ui.py','livemorebio/tests/test_execution_clients.py','livemorebio/tests/test_model_workflow_clients.py','livemorebio/tests/test_clean_workflow_ui.py','livemorebio/tests/test_execution_commands.py'])
finally:
 signal.alarm(0);print('Refusal receipts:',counts,flush=True)
raise SystemExit(result)
PY
```

## Independent and real-user acceptance still required

Source and tests are frozen for maker-external review. No independent acceptance
has been claimed by this maker. Real authenticated desktop/mobile legacy browser
QA, screenshots, normal rendering/layout/accessibility, actual event timing and
navigation to current Twins/LIFE/Cendos cleanup remain separately required under
the approved plan. The VM exercises actual handlers and selected DOM/canvas
interfaces; it cannot qualify actual rendering, bfcache behavior or network timing.
No live attached CLI/SDK smoke, service startup, hardware command, participant
record, scientific input change or native solve occurred.

R01–R51 and all six requested scientific programs remain open. Prior failed Atlas
and insulin results are not upgraded by client tests. No source retrieval,
installation, commit, push, PR or installed-pointer change was performed.

Durable lesson: clearing a displayed value is insufficient if another handler
retains permission to install it again. Keep operation facts, current-read
permission, current DOM and cleanup separate, revoke all current numerical writers
on failure, and test the real selector/attribute and asynchronous owner—not merely
a schematic state machine. The requested CE/gbrain/context7 tools were unavailable
in active tool discovery; this local solutions receipt records the lesson without
claiming an unavailable workflow or independent review ran.

## Root independent client gate — 2026-09-08

Root reviewed the complete approved plan and final177-line owner, both new test
modules, actual legacy clear/render/numerical-writer integration, shared strict
selection transport, attached SDK summary/transport and terminal changes. All
eight frozen hashes in this receipt were independently verified unchanged.

Independent repeat: **632 passed in32.30s**, exit0, private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-g07r4qz1`.
The exact command above was used with one additional isolation preamble inserted
before setting the pytest environment: retain only PATH, HOME, TMPDIR, LANG and
LC_ALL from the inherited environment, clear it, then apply the private review
environment as written. No token or operational setting was printed or carried
into the repeat. Same45-second whole-run bound; Node186, unexpected I/O0,
optional Git refusal1. The test process completed.

**CLEAR for this bounded client contract.** No unresolved critical finding was
found in this review. This is independent source/offline-handler acceptance, not
actual-browser, installation, attached-service or scientific acceptance. The
three previously excluded real-model clean-workflow tests remain outstanding.
The separately planned real-user legacy browser gate must still run and its
screenshots must be visually inspected. Current-state recovery does not qualify
any of the six biological programs or close any full-product obligation.

Full-product privacy follow-up (R45/R47/R50): the intentionally unchanged
in-process SDK patient path still calls patient.set with demographic/genome
inputs and numerical summary output. Its attached counterpart is corrected by
this packet, but the old local path must receive a separately reviewed
metadata-only audit correction before a PHI-capable release. Do not use real
participant input in that path or treat this narrow CLEAR as privacy acceptance
for all SDK modes. No original audit file was inspected or rewritten here.

Subsequent correction: the specific in-process patient.set payload is now fixed
and independently cleared under `2026-09-08-local-preview-audit-minimization-plan.md`.
The original SDK pin/table above remains the historical client-gate identity;
the new SDK pin is022e850ee3c85e35cd64be4bf27910d84a777e35a068c949511a20658feee0b8.
All frontend pins are unchanged. The three new tests and original632 preservation
passes are separately attributed in that receipt; they do not establish
application-wide privacy compliance or a new biological result.
