# Wheel model-asset diagnostic

Status: reproduced packaging gap, not a verified failure of the separate managed
source-archive installer. R43/R44/R45 remain open. No package source was changed
by this diagnostic and no operational installation was replaced.

## Actual evidence

A private source snapshot was built offline with the existing setuptools backend,
`pip wheel --no-deps --no-build-isolation --no-index`. The resulting wheel was
installed without dependencies into a new private target, then imported with
Python isolated mode from outside every source checkout.

- Artifact: `/tmp/livemore-wheel-audit.jzHnO4/wheels/livemorebio-0.0.1-py3-none-any.whl`.
- SHA-256: `afb55679b66a5cafebdd2f269a2482bd9f1f03bbdc89df32067a174b1b3acf87`.
- Installed module was verified to originate from the new target.
- The wheel contains **zero CellML members**.
- `engines.cardiac.action_potential.DEFAULT_MODEL` points outside the installed
  package to a nonexistent `models/cardiac/ohara_rudy_cipa_2017.cellml`.
- No biological solver was executed. This tested packaging and file resolution,
  not a cardiac numerical response.

The managed one-line installer currently installs an exact full source archive in
editable mode, which carries a different asset layout. This wheel result must not
be misreported as proof that its managed archive install failed. That installation
still requires its own clean candidate test and external-user guide verification.
The audit wheel predates later in-flight UI/auth changes and is not a release artifact.

## Preservation and next gate

Keep the existing checked source model unchanged. A packaging correction needs an
explicit source/rights manifest, installed-resource lookup, source-checkout
compatibility and an outside-checkout regression; merely copying a model beside
an installed package during testing would hide the defect.

The inspected [PMR model metadata](https://models.cellml.org/e/5a0/ohara_rudy_cipa_v1_2017.cellml/cmeta)
does not specify a license. The model's documentation attributes the schematic
under CC BY, which is not enough to infer the license for the entire CellML
artifact. The separate [Chaste CellML repository](https://github.com/Chaste/cellml)
describes copied/annotated models; Chaste's engine license cannot automatically
be substituted for each model's rights. The live browser metadata request
returned403; the indexed metadata view reported unspecified terms. Exact source
identity and redistribution terms require further verification before adding a
new bundled-model distribution path. No model or existing capability was removed.
