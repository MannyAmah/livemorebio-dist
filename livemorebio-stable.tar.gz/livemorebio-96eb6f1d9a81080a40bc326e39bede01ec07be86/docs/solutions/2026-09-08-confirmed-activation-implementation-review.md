# Confirmed numerical activation — frozen maker increment

2026-09-08. Implements only the already approved activation family in the
committed-source transition plan/interface. Startup, binding, preview and
observation-selection/reconciliation remain separate required work. R01–R51 and
the six requested programs are unchanged; no experiment or browser ran here.

## Scope and exact identities

The registry audit-phase and stored-MAX increments were independently cleared
before this server integration. No registry/audit/model authority/scientific
source file was edited by this increment. The only runtime edit is server.py's
activate_twin function, using the reviewed prepare_activation and
commit_prepared_transition helpers. Current server SHA256:
`3eefe11f60c43dbc95ce4808ea5c85a45ac378326d49d430ac005c5bdd7e56d8`.

Tests:
- test_committed_source_transitions.py:
  `5461ee171a0b7015222d382fe1156c094c80892f9ef506983e7eeb5dacb856c8`
- test_legacy_transition_admission.py:
  `f671712434ca9d0f7ea050a01b2589d550913eadfb2c38e9c49fe05d5e308abb`
- test_clinical_source_races.py:
  `e9a8b186be55129f582f05723cf77a771395514fdb990cdc50f12022e235d20e`
- unchanged test_source_retirement_lock_boundary.py:
  `cc39635b694350e2e695e6046fe68103d3e386c2ef7af16ab36904ba556e331f`

The projected-state doubles now provide their own profile_params. The two
inherited precondition cases use prepare_* conflicts and require no constructor
or commit, instead of assuming a constructor before a rejected write. The four
typed ModelContext failures preserve their exact codes, old state/generation
and no-commit assertion, using a distinct prospective SYNTHETIC record plus the
current active record. The independent release reviewer read and cleared these
fixture migrations before runtime code. These are authored software inputs, not
participants, numerical models or measurements.

## Behavior

Strict authenticated duplicate-safe16KiB admission rejects unknown keys and
nonincrementable/noninteger versions before any registry access. Preparation and
source-generation capture occur under authority only; current memory and the
prepared active record must agree. The model, complete detached snapshot,
availability, new observation/action holders and responses are prepared outside
authority/creation/manager locks. The snapshot must carry its own dictionary-or-
null profile_params; neither missing data nor an unavailable person is repaired.

Final commit rechecks generation and selected identity in the same existing
authority→creation→manager guard. Confirmed rollback preserves state/generation.
Unknown outcome installs DENY_ALL; confirmed commit installs the precomputed
state and generation before any guard releases. Old state/actions and candidate
references are retained through this interval. Old-generation invalidation and
best-effort prepared-snapshot publication happen afterward, followed by retirement
outside locks. Confirmed resource-cleanup failure retains the committed identity
and returns the existing inspect-required503; no write is retried.

## Actual RED/GREEN and test-harness correction

The initial31-failure invocation at private5romx5h5 was a **harness failure, not
product RED**: importing the registry autouse plugin forbade socket construction,
which also prevented TestClient's private Unix socketpair. Its resulting asyncio
cleanup warnings are retained, not interpreted as product behavior.

The corrected inert invocation removes that registry-only plugin. Its local
autouse fixture retains the same clinical compiler/template prohibitions and
explicitly forbids AegleTwin and MetabolicProfile constructors. Process-wide
connect/connect_ex/DNS/create_connection/bind/listen/urllib and low-level
fork/exec/spawn/subprocess refusals remain. Only the exact optional Git metadata
lookup is refused into its existing OSError fallback. Internal socketpairs are
allowed; there is still no socket listener, network request or real model.

Before runtime implementation: **20failed,11passed,41deselected in1.65s**,
private `livemore-research-review-1khu41ec`.
After implementation: **31passed,41deselected in1.51s**,
private `livemore-research-review-6gr5sftr`.
Both completed with zero unexpected I/O/process attempts and one refused optional
Git lookup. Three existing framework warnings remained. The41 excluded cases are
other route families, not passing evidence and not removed from the full task.

The same corrected inert invocation also reproduced **32 startup failures in
1.18s**, private `livemore-research-review-4ws2i15h`, before any startup runtime
edit. This avoids treating a future socketpair refusal as a passing failure-path
check.

## Exact repeat

Run from the recovery worktree; the following creates only a fresh isolated
technical environment and invokes no real service, browser, device or model.

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os, sys, signal, socket, subprocess, urllib.request, multiprocessing.process
from tools.run_review_stack import prepare_review_environment
root, env = prepare_review_environment(inherited={k: os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ})
os.environ.clear(); os.environ.update(env)
os.environ['PYTHONDONTWRITEBYTECODE']='1'; os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
blocked=[]; metadata=[]
def deny(*a, **k):
    blocked.append('unexpected'); raise AssertionError('Review forbids network and child/native work')
def process(command, *a, **k):
    if command == ['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
        metadata.append('refused'); raise OSError('Authored unavailable Git metadata')
    return deny()
def audit(event, args):
    if event in {'os.fork','os.forkpty','os.posix_spawn','os.exec','subprocess.Popen','socket.connect','socket.getaddrinfo'}: deny()
sys.addaudithook(audit); multiprocessing.process.BaseProcess.start=deny
socket.socket.bind=deny; socket.socket.listen=deny; socket.socket.connect=deny; socket.socket.connect_ex=deny; socket.getaddrinfo=deny; socket.create_connection=deny
urllib.request.urlopen=deny; urllib.request.OpenerDirector.open=deny; subprocess.Popen=process
import pytest
class InertReview:
    @pytest.fixture(autouse=True)
    def no_models(self, monkeypatch):
        from livemorebio.tests.clinical_registry_fixtures import forbid_compilation
        from livemorebio.aegle.runtime import AegleTwin
        from livemorebio.engines.metabolic.glucose_insulin import MetabolicProfile
        forbid_compilation(monkeypatch)
        monkeypatch.setattr(AegleTwin, '__init__', deny)
        monkeypatch.setattr(MetabolicProfile, '__init__', deny)
signal.alarm(45)
print('PRIVATE_REVIEW_ROOT', root, flush=True)
rc=pytest.main(['-q','-p','no:cacheprovider','livemorebio/tests/test_committed_source_transitions.py','livemorebio/tests/test_legacy_transition_admission.py','livemorebio/tests/test_source_retirement_lock_boundary.py','livemorebio/tests/test_clinical_source_races.py','-k','activation or (source_publication and activate) or (replaced_model and activate) or (legacy and activate)','--tb=no'], plugins=[InertReview()])
print('REVIEW_IO_COUNTS',len(blocked),len(metadata))
signal.alarm(0)
raise SystemExit(rc)
PY
```

## Acceptance and lesson

Maker tests only. Independent full-function/consumer review and repeat are next,
then broader preservation and actual browser/terminal acceptance. No actual
registry-to-server end-to-end activation or pharmaceutical readiness is claimed
by authored ASGI tests alone. No commit/push/PR or installed-pointer change.

Lesson: a committed identity and its executable state must become visible under
one ownership guard; a successful read before construction cannot establish that
the later write matched it. Also separate network exclusion from in-process ASGI
socketpair mechanics so test infrastructure does not masquerade as product RED.

## Independent activation-only review and blocking reproduction

2026-09-08, release reviewer. **DONE_WITH_CONCERNS: integration is blocked by one
reproduced P1.** This does not alter the maker's frozen source or passing result.
The review skill's concurrency/data-safety and consumer-completeness checks were
applied to this bounded function and its real collaborators. Its unrelated
network, auto-fix, global review-log and additional-process workflows were not
performed under the explicit read-only assignment. No CE/gbrain run is claimed.

Read the approved transition plan/interface, this complete maker report, the
entire activation function, strict body admission, source authority/fence,
prepared registry commit outcome handling, real manager shutdown/close/setter,
state/list consumers and operation-specific UI acknowledgment contract. Read the
four named authored test files and verified the frozen server/test hashes.

Repeated the exact31-case command above in a fresh isolated environment:
**31 passed,41 deselected,3 existing warnings in1.48s**, private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-9chca_g3`.
The outer process exited0, with zero unexpected I/O/process attempts and one
refused optional Git metadata lookup. Internal TestClient socketpairs were
permitted; socket bind/listen/connect/connect_ex/DNS, urllib, actual child launch
and numerical constructors remained refused. The41 exclusions remain ungraded
other-family cases, not passing evidence.

### P1: a retained closed manager can reject the fence after durable commit

Confidence10/10 for the authored boundary reproduction. At server.py476 the
registry reports COMMITTED. At484, install_generation invokes the real manager's
set_source_generation, whose execution.py78 `_open()` check can still raise
EXECUTION_CLOSED. Authority/state assignment therefore never completes; the
generic server catch at505–508 returns REGISTRY_STORAGE_UNAVAILABLE while the old
generation remains permitted. The same setter is also used by the uncertainty
branch. Its "assignment-only" description does not make it non-throwing.

This state is reachable through the real shutdown lifecycle: manager.close sets
`_closed=True` before cleanup; shutdown_execution_manager detaches the manager
only after close succeeds. A cleanup failure deliberately retains that closed
manager and its ownership. It must not be silently dropped or reopened to solve
this source-commit defect.

Root explicitly approved a single additional no-I/O reproduction. It used the
real no-background ExecutionManager, actual shutdown helper, ModelSourceAuthority,
activation route and state route. The store/registry and candidate are authored
doubles; no SQLite registry, adapter, native model, OS owner lock or descendant
was created. The retained owner is one Python sentinel, not a file descriptor.

Exact observed sequence:

1. Authored store/release failures made real shutdown return
   EXECUTION_CLEANUP_UNCONFIRMED and retain the now-closed manager.
2. Activation prepared the authored record, received an inert candidate, and
   received the registry double's COMMITTED acknowledgment.
3. Response was503 REGISTRY_STORAGE_UNAVAILABLE. Old state identity and permitted
   generation were unchanged; DENY_ALL was not installed.
4. A subsequent actual in-process GET /api/state returned200 with AUTHORED_OLD.
   The private probe exited1 at its explicit preservation-contract assertion.

Retained private artifacts, with no source edit:

| Artifact | SHA256 |
|---|---|
| `/tmp/livemore-activation-fence-review.JqbxX4/reproduce.py` | `a2b2265d094844487ff2b22f9e4210d7b3baf100df7e70edc2747b723a96dac7` |
| `/tmp/livemore-activation-fence-review.JqbxX4/result.json` | `9924074d60333d7a0aa0f15ac28bf1071f94f9ba07d91ea3543e4c019e6beac4` |

The probe's generated technical environment was
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-hnpy0rzl`.
It observed zero unexpected I/O/process attempts, one refused optional Git lookup,
zero native adapters, and the same frozen server SHA3eefe11f… above. This proves a
software commit/publication contract failure, not an actual patient database
mutation or a real OS-cleanup result. Do not rerun against the same exclusive
result path or overwrite this failure receipt.

### Required next correction and preserved boundaries

Root must approve a narrow correction before runtime edits. At minimum, prove
the captured manager can accept the assignment before allowing a registry commit,
under the same creation/manager guard that excludes concurrent close. Preserve
closed-manager ownership and explicit cleanup; no setter bypass, owner detachment,
automatic write retry or reopened numerical manager is justified by this finding.
Add closed-before-entry and closure-during-candidate-preparation RED cases, and
cover confirmed/uncertain outcome paths without allowing a post-commit fence
exception to leave the old source available. The existing31 cases must remain
green; other route families and checked startup remain separately graded work.

Safe additional preservation candidates after correction are the inert current-
source race cases already read in test_clinical_source_races.py and the eight
prepared-snapshot parameter tests. Real-model restored-subject tests, native
watchdogs, actual registry/server activation and browser/terminal acceptance need
their separately authorized runs. None was executed in this independent grade.

Lesson: preallocating JSON and holding commit locks is insufficient when a final
"assignment-only" collaborator still has a lifecycle rejection path. Exercise the
retained failed-cleanup state with the real setter, not only a permissive fence
double, before grading the final commit interval.
