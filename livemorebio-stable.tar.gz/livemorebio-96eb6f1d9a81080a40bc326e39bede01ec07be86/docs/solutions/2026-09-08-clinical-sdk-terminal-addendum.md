# Clinical SDK / terminal parity addendum

Pre-code addendum to the approved clinical-context availability amendment.
Ownership: UI agent edits `sdk.py`, `shell.py` and dedicated tests only. Root
retains API routes, shared safe request transport, error categories and registry.
No browser, service, real record or numerical model is operated in this packet.

## Additive method / command contract

| SDK method | Shell command | One protected server operation |
| --- | --- | --- |
| `select_twin_observations(twin_id, *, expected_version)` | `twin select-observations <id> version=<n>` | POST `/api/twins/{id}/select-observations`, body exactly `expected_version` |
| `list_cohort_members(cohort_id, *, limit=10, cursor=None)` | `cohort members <id> [limit=10] [cursor=...]` | GET `/api/cohorts/{id}/members` with one bounded page |
| `get_cohort_member(cohort_id, member_id)` | `cohort member <cohort_id> <member_id>` | GET `/api/cohorts/{id}/members/{member_id}` |

All methods require `Platform(mode='attach')`. No local registry construction,
clinical parsing, automatic fallback, model activation or numerical solve occurs.
Selection is submitted once with the caller's exact revision; there is no
automatic refresh-to-new-version, POST retry or idempotency-key invention.

Identifiers must be bounded nonempty ASCII identifiers and encoded as individual
path segments. Revisions are real positive integers (not bool/float/string) within
the JavaScript-safe integer range shared with the browser. Page limit is an exact
integer 1–50, default 10. Cursor is an unchanged URL-safe opaque string, 1–1024
characters, or omitted; the client does not decode, rebind or coerce it. The shell
parses these options before the permissive legacy coercion and rejects duplicate,
unknown, missing or malformed options before transport. No `json=true` clinical
record dump is added by these commands.

## Existing transport seam and root-owned dependency

Use inherited `_continuous_request` for the new attached paths, preserving its
bounded JSON parsing, no proxy/redirect, authentication, response cleanup, fixed
error messages and once-only mutation behavior. Do not use legacy `_get/_post`,
which do not provide those error and response-uncertainty guarantees.

Root is extending this existing shared transport to retain canonical UUID
`X-Request-ID` selection-operation metadata, alongside existing 32-hex
`X-Livemore-Request-Id` compatibility. New fixed codes must preserve
`SELECTION_COMMIT_UNCONFIRMED`,
`SELECTION_COMMITTED_CLEANUP_UNCONFIRMED`, relevant model/registry/audit categories,
and HTTP status/request identity without exposing raw server error text.
This agent does not edit `execution_client.py` or invent a second HTTP stack.

The SDK returns the bounded structured clinical record only to its explicit
caller. It validates selection acknowledgment identity and typed observations-only
availability before treating a 200 response as confirmed; a malformed mutation
acknowledgment remains unconfirmed with its safe correlation metadata. Frozen
member pages and detail validate their documented shape/identity without deriving
a model binding. Validation is not independent scientific qualification.

On a committed-but-cleanup-unconfirmed outcome, SDK/terminal preserve the exact
typed error and operation UUID. No automatic read obscures that original outcome.
The fixed message directs an explicit current-state inspection/owned execution
cleanup, not resubmission of selection. The UI's separately approved re-read
behavior remains unchanged.

## Terminal disclosure boundary

Shell/pipeline output is allowlisted metadata: source class, record version,
descriptive/execution eligibility, page counts/cursor and frozen integrity hashes.
Opaque record handles needed for the next explicit member command are retained;
names, display labels, external subject IDs, demographics, observations, medical
history, notes, medications, consent/custody payloads and full snapshot JSON are
never automatically printed. No raw server error text is displayed.

Pipeline echo for the three new command families prints the family/action only,
not caller arguments or cursor. Existing `cohort list` supports compact REAL
summaries without requiring `seed`; existing synthetic seed output is preserved.
List/read commands do not create a cohort or execute an experiment.

## Red-first and review gates

1. Missing-method/command tests first; exact routes/methods/body, default/max page,
   opaque cursor preservation and no in-process fallback.
2. Invalid booleans/floats/negative/oversized revisions and limits, malformed IDs,
   duplicate/unknown options and malformed cursor never reach transport.
3. Selection timeout/read/JSON/status uncertainty calls transport once, retains
   fixed code and canonical operation UUID, and never logs authored private text.
4. Malformed/mismatched selection acknowledgment and frozen member wrappers are
   rejected; a requested page does not fetch member detail or follow cursors.
5. Shell list handles REAL compact records with no seed, while synthetic list
   remains unchanged. Output/echo tests inject technical secret/PHI-like sentinels
   into every excluded field and assert they are absent.
6. Reuse independent shared transport regression tests; do not weaken them for
   these new routes. Source and test freeze precedes independent review. Actual
   terminal/HTTP parity against a fresh technical stack requires root authority.

This closes only SDK/terminal access to the descriptive lifecycle. It does not
make an unbound real-human cohort computationally executable or qualify any
clinical/botanical experiment.

## Implementation checkpoint and lesson

Root read and approved the pre-code document at
`d4b4c458fafda735b877b87a1e620c72839b6ef26b20d63bb56529785840f51f`.
The first dedicated matrix returned **50 failed / 5 passed** before methods or
commands were implemented. The existing shared transport remained root-owned.

The three methods and command families now use that transport; selection remains
exactly one POST and preserves canonical operation UUIDs and fixed uncertainty
codes. Boundaries reject malformed acknowledgments, wrong frozen identities,
invalid page/cursor/revisions and unknown or duplicate command options. Explicit
member inspection returns the original bounded snapshot to the SDK caller but
prints only metadata in the shell. No source, numerical state or registry is
constructed by these methods.

Additional red cases exposed two acknowledgment-domain gaps (a cohort-only reason
accepted as model availability, and control characters in source generation)
and command-echo gaps for quoted command words, including an unterminated later
argument. These were corrected before the final checkpoint. Echo recognition is
now privacy-conservative even when full command parsing fails; command execution
still rejects malformed syntax before any SDK operation.

Final bounded matrix: **393 passed in 0.39 seconds**, including 69 dedicated
clinical parity cases plus existing execution/Atlas transports, commands,
control-revision clients and model-workflow clients. Scoped whitespace checks
passed. No real HTTP service, browser, participant data or numerical solve was
used; transport tests use authored responses through the actual request code.

Lesson: redaction must precede permissive parsing, and must still work on malformed
commands. A response status is not a valid selection acknowledgment unless the
exact requested identity/revision and observations-only contract match. Preserve
typed uncertainty rather than recovering by repeating the selection mutation.

Independent source review and an authorized actual terminal/API exercise remain
pending. The CE compound command is unavailable in this session; this is the
durable local lesson record, not a claim that an unavailable tool ran.

## Independent correction packet (approved before code)

The original 393-test checkpoint is not final acceptance. Independent review
found three bounded SDK/terminal defects, and root authorized red-first fixes:

1. Observation selection commits revision `n+1`; request `expected_version=n`
   must remain unchanged. Confirm only the same twin with record and availability
   revisions exactly `n+1`, including a test using the real preparation helper.
   Unchanged or later revisions remain unconfirmed after one POST, with no GET.
2. The actual observation-only state has `metabolic:null`, `cardiac:null` and
   `human:null`. SDK state/summary must retain typed availability and selected
   identity without constructing a model or replacing absent quantities with
   zero. Explicit SDK state retains original observations/Patch data; the compact
   summary and terminal never automatically dump these payloads. Missing or
   contradictory availability is an error, not an empty ready state. Preserve
   existing supported legacy output. Attached shell startup and `show` remain
   usable with unavailable computation; operational errors still propagate.
   Root separately approved the same branch for `show workspace`, whose
   `active_execution` is null. Print availability metadata rather than invented
   zero node/edge/executed counts; leave the ready workspace output unchanged.
3. Shell words can combine quoted and unquoted segments. Parse the first two
   command words independently for privacy classification even when a later
   argument has an unmatched quote. Full command execution still rejects that
   malformed line. A malformed unclassifiable pipeline line must not echo its
   arguments. No permissive regex may expose the raw tail.

No server, registry, runtime, numerical model, browser or service changes are
part of these corrections. Independent reviewer continues adjacent inspection.

### Corrected source checkpoint

The independent P1 was confirmed against the real preparation and availability
helpers: request revision 2 returns committed revision 3. The earlier success
fixture repeated the implementation's incorrect unchanged-revision assumption;
the initial 393 passing tests did not establish this boundary. Preserve that
failed candidate as history: SDK SHA
`0f2be4cf894016d92a59ed272245d162aa647d78175cf534f3969bca9532ab1d`,
test SHA `be33d5dc5f82189086bd1e044fa9734f11968208d759907dc6696585e5d5005a`.

The combined correction tests produced **17 failed / 74 passed in 1.04 s**
before implementation. The independently approved `show workspace` null-execution
case then produced **1 failed / 2 ready-shape preservation passes** before its
fix. The corrected matrix now has **430 passed in 18.16 s**, including **94
dedicated clinical SDK/terminal tests**, existing execution/Atlas client and
command tests, revision clients, model workflows and multiscale preservation.
Three existing FastAPI/Starlette deprecation warnings remain. Scoped whitespace
checks passed. These are isolated unit/API-fixture checks, not live HTTP/browser
or biological validation.

An intermediate broader matrix also included the root-owned API test file while
the root reconciliation feature was deliberately red: **452 passed / 7 failed**.
The seven failures were uncertain-selection listing/telemetry and five unimplemented
reconciliation route cases. They are not removed, treated as passes or repaired by
this lane; root was notified with the exact test names. They are outside this
corrected SDK source checkpoint.

SDK state now preserves original availability, observations and Patch projection
for its explicit caller; summary and terminal retain only bounded metadata and
nullable numerical summary fields. They neither infer a healthy model nor copy
observations into legacy audit summaries. Ready legacy summary values and shape
without new fields are unchanged. Typed ready previews and selected ready models
have separate preservation fixtures. Operational failures are not swallowed.

Compounded lesson: test a mutation acknowledgment against the actual producer's
commit transition, not a hand-written mirror of the consumer assumption. Privacy
classification must use the shell's actual word grammar and survive errors later
in a line. Null model fields are an intentional availability state, not a reason
to create substitute physiology or terminate descriptive intake access.

Independent re-review and authorized live terminal exercise remain required.

### Response-correlation correction

Independent follow-up found that `_summary` validation reused
`last_continuous_response` even though `state()` uses a legacy read which does
not capture response headers. Root authorized a correlation-only correction.
Two no-I/O regressions first failed: after a successful selection, malformed
state/direct-summary validation carried that earlier selection's operation UUID.

Validation errors now default to no correlation. Only the three operations that
have just completed `_continuous_request` explicitly retain its current metadata.
The previous operation record is not deleted or rewritten, and valid selection
acknowledgments/uncertain mutation responses keep their own request identity.
No additional request, parser, transport, server or model change was made.

Red: **2 failed / 94 deselected in 0.76 s**. Corrected focused and preserved client
matrix: **420 passed in 1.18 s**, including **96 dedicated clinical cases**.
Scoped whitespace check passed. The lesson is operation-local provenance:
cached request metadata must never be attached to a different read merely
because both errors use the same formatter.
