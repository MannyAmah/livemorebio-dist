# Offline npm monitor failure: retained evidence and bounded correction

2026-09-09. Read-only diagnosis; no npm, Node, native process probe, build,
network request or consumed-input edit. The investigate workflow separates the
recorded outcome from a source-supported but unconfirmed exit-race hypothesis.
This document proposes private launcher/tests only, then separate exact-run
authorization. It does not upgrade the original failed run.

## Retained facts

Consumed root: `/private/tmp/livemore-molecular-offline-install.a8XyYr`.
`result.json` is 47,094 bytes, SHA256
`edcf38092c1da24614010f80e400c3159ef24297d28ee20e9a052c53a3c9afbe`.
Its exact helper is `8ac417f6d9704fa320e7934ff28466a054589c386fe4aebbbc913325239007cb`.
Root ran that authorization once; final status is `SUPERVISOR_FAILURE`, phase
`CACHE_ADD_11`. Eleven earlier commands have no primary error. Command 11 has
the generic primary error, an admitted initial Node identity for PID16752,
exit0, both empty SHA256-verified streams, and no stream-evidence error.
All twelve command cleanups say `SETTLED`, no TERM/KILL, and group empty before
reap. Last cleanup took0.01674049999564886s; last invocation0.5557565000490285s.
Aggregate child work plus cleanup was11.673819083021954s. Disk receipt records
87 samples, maximum42,135,909 bytes/6,014 entries, maximum gap0.2724195410264656s,
zero observed overshoot, explicitly sampled soft protection. Inputs preserved.

Independent data-only check, with30s alarm and socket/process/ctypes refusal:
cache content is exactly archive indexes0–383, all384 size/SHA256/SHA512 checks
matching the admitted originals,22,039,072 bytes. Indexes384–426 are absent;
none of the present digests is invalid. This includes all32 arguments of the
twelfth command. No `node_modules` exists; commands12–14 and ci did not run.
The eleven retained npm logs each end in exit0/info ok. Latest log
`logs/2026-09-09T05_48_51_110Z-debug-0.log` is12,857 bytes, SHA256
`649a6c8989e97668d43dabf1a409547891d47c1eba8e84239051fd84f10ca647`.
This establishes retained cache bytes and child success, not whole install
success, permanent cache durability or the precise original exception.

## Exact source gap and uncertainty

`install-once.py` monitoring checks WNOWAIT, then `owner.live()`, then
`owner.prove()` without stabilizing an unavailable observation. The private
`prove()` checks WNOWAIT again, then reads two libproc identity samples. A child
can exit after a false WNOWAIT observation and before a live metadata read.
`PROCESS_UNOBSERVED`/an OS lookup failure immediately reaches the outer catch,
which replaces every non-private-Failure exception with `SUPERVISOR_FAILURE`.
The exact failed stage/code/class is therefore irrecoverable from this receipt.

Inherited `Owned.cleanup` already uses a bounded observation-only proof loop,
then requires proved empty group plus held waitable child before reap. Its
settled16.7ms result is consistent with an exit transition. Prior actual Darwin
false-WNOWAIT/ESRCH/false-WNOWAIT evidence is retained in
`2026-09-08-atlas-cache-review-corrections.md:94–109`. That is supporting prior
evidence, not proof this npm failure had that exact syscall sequence. An
unrelated unexpected Python/OS exception remains possible. No raw traceback
was retained, so do not rename the original failure to a proven race.

## Proposed smallest private correction

Use a new0700 sibling root; preserve every byte under the consumed root and all
original archive/canonical/toolchain roots. Keep the same427 originals,14 fixed
cache-add batches and one ci, original flags, identity-only sampler, owner
cleanup and unresolved slot. Prefer a fresh empty cache seeded from the same
427 local originals: this avoids a new cache-index migration/trust mechanism.
This is a separately approved attempt, never an automatic retry of the old run.

Only the active monitoring observation block gets bounded stabilization, at
most1 second within the existing command/aggregate work deadline. It can retry
only unavailable live metadata (`PROCESS_UNOBSERVED`, `GROUP_UNOBSERVED`, or
OS ESRCH), with the exact held Popen/returncode prerequisite still required.
Each retry drains bounded streams, checks the existing disk/output/time budgets,
and waits10ms. No signal, reap, new child or refreshed initial identity occurs
while observation is uncertain. Re-observe the same held child. A waitable exit
can proceed only to the unchanged cleanup protocol; a live recovery still needs
the original exact PID/PPID/PGID/start/UUID/path and descendant checks.

Actual identity mismatch, inconsistent two-sample identity (`PROCESS_CHANGED`),
already-reaped child, unexpected descendant, malformed ABI, non-ESRCH OS error,
deadline/output failure or other exception remains an immediate failed run.
Permanent unavailable observation stops after the bounded window. Cleanup may
settle separately, but does not erase that primary failure. Unknown cleanup
still occupies the slot and prevents the next command. No global OSP change.

Add fixed diagnostic fields to every failed invocation: last active stage from
`OPEN_STREAMS`, `SPAWN`, `INITIAL_IDENTITY`, `DRAIN`, `BUDGET`, `WAITABLE`,
`GROUP`, `IDENTITY`, `PAUSE`; bounded classification from the exact known
supervision-code whitelist, fixed exception-class category and optional ESRCH
indicator. Unknown exceptions remain `SUPERVISOR_FAILURE` with class `OTHER`.
Retain transient count/first-last elapsed/final observation outcome, not raw
exception messages, paths, argv memory or environment. Immutable launched argv
and existing stream hashes/exit/cleanup remain separate. Keep the256KiB terminal
reserve and total512MiB/2MiB stream/16MiB log bounds unchanged.

## RED-first acceptance before any new actual command

Mount the actual private invoke/owner paths using authored in-memory child/ABI
fixtures; refuse all real socket/process/ctypes/signal calls. Preserve38 prior
tests, except the historical no-authorization assertion must target the new
unconsumed fixture root rather than pretend the old run never happened.

1. WNOWAIT false, live group present, identity unavailable, WNOWAIT false,
   then held exit: no premature primary failure, no signal, empty-before-reap.
2. Unavailable group observation then exact live recovery preserves original
   identity and continues; explicit changed six-field identities never recover.
3. Permanent unavailability stops within the unchanged window and preserves
   fixed originating stage/code; no uncertain signal/reap or next command.
4. A proved exit with an unexpected surviving descendant still fails/cleans its
   owned group under the existing protocol, never passes merely on exit0.
5. Fixed diagnostic tests for each transient category and unknown exception;
   bounded messages cannot disclose authored secret-like exception strings.
6. Deadline/output/disk failure during observation retains that primary and
   original stream/cleanup evidence. No iteration can extend the work budget.

Freeze new source/diff/tests/plan and exact unchanged npm input inventory for
root independent review. No new actual child before its separate authorization.
Actual postflight remains every installed file/427 placements verified against
original bytes, not just npm exit0. Rights, build and browser gates stay open.

## Later build inputs: source-only handoff, not execution authority

Retained canonical root `/private/tmp/livemore-molecular-canonical.9plldc`:

| Input | Bytes | SHA256 |
|---|---:|---|
|entry.js|868|24ad4a5a52229b0f852d2aa67e8bd404fb370bd79b0b3cbeb97d2516141b214a|
|spec.js|3739|49f9b841e1cd144767d734e5520dfabaf95b9234c2cbc6ae4e52110441bf2b35|
|webpack.config.cjs|938|331c71c6dffb146b7915565ce067633ee5d78f09e37530ab358ce3a8e9d04427|

The current config explicitly enables assets/modules/reasons but `all:false`
disables nested/dependent/orphan modules by default, confirmed from retained
webpack5.92.1 `package/lib/stats/DefaultStatsPresetPlugin.js:129–134,169,178,195`
(source SHA25665111aef9bdf4118753043238171ddfb313a505ebb90cef919f5694f979cad44).
Before two later clean builds, propose stats-only explicit `nestedModules:true`,
`dependentModules:true`, `orphanModules:true`, `chunks:true`, `chunkModules:true`,
`chunkRelations:true`, `ids:true`, `moduleAssets:true`, `relatedAssets:true`.
No bundling/selection behavior changes. Each exact command will use pinned Node,
the installed `node_modules/webpack/bin/webpack.js`, explicit config and
`--json=<private stats path>`, supported by webpack-cli5.1.4 source777–790.
Two clean roots/120s bounds, actual emitted module/asset closure, forbidden
codec/full-viewer/worker/lazy chunks/fonts/WASM, exact notices and equal output
hashes remain required. Stats alone is not emitted-byte or rights clearance.
