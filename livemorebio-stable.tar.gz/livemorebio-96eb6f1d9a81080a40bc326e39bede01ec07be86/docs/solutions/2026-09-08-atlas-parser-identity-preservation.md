# Preserve admitted Atlas identity while retaining frozen-member responses

Written before code; independent pre-code review required. This is a correction
to R01/R03/R12/R22/R47/R48, not permission to weaken source admission or replace
the preserved anatomy. No new publisher acquisition or conversion is needed.

## Evidence and decision

Browser preparation exposed a real cross-feature regression. `_converter_identity`
fingerprints every locally defined strict_json function; `_read_manifest` compares
that identity with the immutable producer manifest before permitting use. The
later fixed16MiB frozen-member response change factored parse_json_object into
`_parse_object` and added a named response entrypoint. Though generic behavior
was preserved, the function identities changed and the old anatomy is rejected.

Independent read-only diagnosis found exact prior parser source in
`/tmp/livemore-network-source.ouSnkU/livemorebio/strict_json.py` and the retained
wheel audit, SHA-256
`6af73cc557bdb3a18bda10bc114148ef7e25f711410fd1d263e11279ea01c8e1`.
Replacing only the strict-parser identities in isolated arithmetic reproduces the
persisted loaded-code hash exactly:

- admitted `e7532a863d945fabb296753e9aa8b5b6187f9609fb6dff518255053b1783e5f8`;
- current `f7be5f9d28addfedec3c85fb7264f86358ad8abdf536e695f9e2417ec00e0595`.

The root read that entire prior source, current source, converter/consumer paths
and the complete prior frozen-member budget amendment. All six former local
function identities can be preserved exactly while keeping the new fixed response
capability outside the converter namespace. No geometry code or bytes differ.

Office-hours/CEO alternatives: reconversion is unnecessary for an unrelated
response-budget refactor; a historical-converter allowlist or new producer/
consumer compatibility subsystem is a larger trust change. Select the smallest
preservation fix: restore exact generic parser semantics and isolate the newer
fixed-response entrypoint. This explicitly amends the earlier shared-core design,
not its semantic/transport requirements. Root has informed the user of the
confirmed regression and preservation correction.

## Exact implementation contract

1. Restore `strict_json.parse_json_object` exactly from the verified prior source
   and remove only its new `_parse_object` implementation. Do not change the five
   existing strict validator helpers, constants, exception class, generic2,000,000
   default, public8MiB ceiling, validation order or safe error text.
2. Move the fixed `parse_frozen_member_response(raw)` entrypoint to a new small
   `frozen_member_json.py`. No configurable max argument. It retains the exact
   existing16MiB response-only byte limit checked before UTF-8 decode, object-only
   root and safe syntax errors. It reuses the five unchanged strict validators
   for depth/duplicate keys/finite floats/safe integers/constants; do not fork
   permissive number/depth rules or change frozen identity validation.
3. Preserve existing imports with a bottom-of-module imported alias in strict_json.
   The function's __module__ remains frozen_member_json, so it is not represented
   as a local converter function. No dynamic __module__/function-code manipulation.
   Avoid initialization cycles: import shared validator names inside the fixed
   response function at call time, after module initialization. Importing either
   module first must work without network/storage/model dependencies.
4. The small fixed-response decode envelope necessarily repeats the original
   dispatch/error envelope; document why the fingerprinted generic function is
   deliberately not refactored. Strict validation itself stays shared. No SDK,
   execution-client route matcher, byte budget, server schema or semantic admission
   change. Existing frozen-member callers still use the same symbol/contract.
5. No edits to converter identity, manifest comparison, source whitelist, receipt,
   cache metadata, source bytes, GLBs, geometry validators or package dependency
   versions. A successful current identity check must equal the old persisted
   identity naturally. Do not monkeypatch production identity to get a pass.

## Red-first and verification

- Add a stable, repository-contained identity regression using the documented
  SHA of each admitted function identity or the combined six-function value;
  compute expected pins from the retained verified bytes before code. Do not
  require ephemeral source files in ordinary CI. Current pre-fix code must fail.
- Generic default2MB, override8MiB, forbidden16MiB override; fixed response16MiB
  exact boundary/+1; all duplicate/depth64/65/UTF-8/finite/safe-integer/object-only
  rules, missing/extra arguments and public error behavior unchanged.
- Both module import orders and old `from strict_json import` alias work. No
  import-time filesystem/network/numerical execution introduced.
- Run full frozen-member byte/route/SDK semantic packet and strict research JSON
  parity, all Atlas geometry/cache/worker/client packets, preserved source-fencing
  packet and selected clinical SDK tests. Record precise skips/bounds separately.
- Read-only check with the exact prior interpreter/dependency versions that actual
  `_converter_identity()` equals the persisted manifest. Read the admitted manifest
  through the normal path against the retained private reference cache, snapshot
  and compare cache files before/after. No acquisition/conversion fallback. This
  is read-only reuse verification, not a new source install or renderer receipt.

Maker owns only strict_json.py, new frozen_member_json.py, new identity regression
tests and necessary import-order tests; no runtime/server/controller/geometry
edits. Independent reviewer checks source and reruns before any browser start.
Root retains overall ownership and updates the original budget amendment with
this correction and evidence. Other full-scope work remains unchanged.

## Pre-code verification precisions — root and independent clearance

Assert exactly the six original local function names, their retained defaults,
and canonical loaded-code identities. The combined pin is
`9c25469074d3de640723909ce1aa7448319e554bba69934d9d28f1c13c365e41`,
derived from the hash-verified retained source under Python 3.11.15. These are
explicitly interpreter-scoped pins, not claims of portable Python bytecode.
Semantic/import tests remain independent on other supported versions. Changing
a generic validator must still change the real converter identity.

Fresh processes test both module import orders, exact alias object identity,
the response function's true module, and the same `StrictJSONError` class.
The full fixed-16-MiB route and semantic-negative matrix remains unchanged.
A wheel built only in private staging must include the new module and expose
the same alias outside the checkout without network or import-time model work.

Actual reuse verification uses normal `_Cache`/`_read_manifest`, with acquisition
and conversion entry points denied, comparing content hashes, sizes, and mtimes
before and after. It may not install, reconvert, repair, or rewrite anything.
This is read-only reuse, not publisher admission or rendered acceptance.

## Lesson

A general-purpose shared module was also a fingerprinted scientific dependency.
A behavior-preserving refactor can therefore invalidate a separately admitted
artifact. Test both the explicit new feature and compatibility with real retained
artifacts; preserve fingerprinted contracts or qualify their replacement explicitly.
Do not erase source lineage or turn integrity checks off to conceal the regression.
