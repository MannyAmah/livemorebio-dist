# Legacy research-preview client recovery — pre-code contract

2026-09-08. Proposal only, following the full-scope recovery plan and the approved
confirmed-preview publication plan, including its final test-author/code appendix.
No source or test changes, model construction, browser/service access or tests
were performed for this proposal. Root owns the producer and must approve the
complete client packet before implementation; its author cannot grade it.

Keep the current A+B workspace, Twins/cohort workflows, biology, calculations and
all six requested programs unchanged. These three legacy preview consumers are
required compatibility work, not new patient admission or scientific validation.

## 1. Existing seams and demonstrated source defects

Package paths below are under this worktree's `livemorebio/`. Line numbers describe
the inspected source, not a promise that concurrently owned server lines remain unchanged.

| Consumer | Actual source seam | Required correction |
| --- | --- | --- |
| `/legacy` base | `aegle/console/index.html:341` toggles the selected button before POST and assigns every JSON response to `S` | A 503 error body is not a state; no optimistic current-source claim or stuck busy state |
| LIFE/note preview | Same file `stim:329`, `ingestNote:334`, `buildHuman:528` | Allow explicit `life_system` from confirmed modeless selection, retain numerical-action denial; replace generic raw-exception notices |
| Attached SDK | `sdk.py:421–452` calls legacy `_post:110` then `_summary:485` | Use strict one-request transport and mutation acknowledgment validation, retaining typed503 and current request identity |
| Terminal | `shell.py:340`, `run_shell:621`, `run_pipeline:605`; `cli.py:350` | Existing REPL/pipeline typed catches do not catch urllib HTTPError; no traceback, replay or local-mode fallback |

The page has five assignments to `S`: load, shared stim, note, base and runVia.
`paintBody:558` independently fetches biology; its optional context comparison
cannot invalidate every old callback, particularly absent context IDs. Animation
loops at700/712 keep reading `S`; clearing DOM without detaching it is insufficient.
`render:586` can partially mutate DOM before failing. Its modeless branch already
clears many numerical fields but not the old note extraction. Existing history
(`EXPERIMENTS`) is separate from the current `LASTRUN` export pointer.

`selection_reconciliation.js` already supplies bounded strict transport, current
UUID parsing and an epoch-based distinction between operation acknowledgment and
subsequent authoritative read. Reuse those primitives, not its Twins DOM mount.
`biological_projection.js:modelAvailability` validates the typed availability
shape; it does not validate the legacy numerical state. Python equivalents are
`_state_availability_valid` and `_summary`, which likewise need a narrow preview
admission check before an empty object can become a successful null summary.

`auth.js` already establishes a bounded HttpOnly same-origin session, respects
caller cancellation and never replays a POST after401. Do not replace it or read
tokens into JavaScript. `_continuous_request` already rejects redirects/proxies,
bounds and strictly parses JSON, preserves current correlation and keeps response
close failure separate from a confirmed acknowledgment.

Two directly related disclosure seams also need correction: attached `patient`
currently sends a note-presence boolean, demographic/genome inputs and numerical outputs to
`audit.record`, whose JSONL payload is plaintext (`audit.py:95–110`); pipeline echo
prints the entire `patient` line, including note text, before execution. Root explicitly approved their
metadata-only/redacted correction as part of this proposal's scope. Do not change
audit.py, old audit bytes, in-process audit behavior or unrelated commands.

## 2. One POST outcome is not current selection or completed cleanup

Use these distinct facts; never infer one from another:

| Observed result | Operation fact retained | Current-view action |
| --- | --- | --- |
| Exact200 + valid preview + current canonical UUID | ACKNOWLEDGED research-preview result | One subsequent `/api/state` GET decides current display, including a later winner |
| `SELECTION_COMMITTED_CLEANUP_UNCONFIRMED`503 | COMMITTED; prior execution cleanup UNCONFIRMED | Inspect current state and existing execution status; never resend preview |
| `SELECTION_COMMIT_UNCONFIRMED`503 | UNKNOWN durable outcome, server may hold DENY_ALL | Clear current presentation; explicit Twins reconciliation is the recovery path |
| transport/body/shape/UUID/201 failure after dispatch | ACK_UNCONFIRMED, not rollback | Preserve safe correlation if actually received; inspect, never repeat automatically |
| fixed input/auth/conflict rejection | REJECTED request | Keep inputs; a fresh read may establish the prior or later source, not cached state |
| `REGISTRY_STORAGE_UNAVAILABLE` or unknown operational error | Storage/operation not confirmed; do not guess commit phase | Same inspect-only path; never translate to an empty or healthy subject |

Recognize fixed `INVALID_INTERVENTION`, `INVALID_NOTE`, `MODEL_SOURCE_CHANGED`,
existing typed model/selection/storage codes and auth401/403. Never print raw
server `error`, exception text, URL, request payload or an unknown supplied code.
Unknown503 is not upgraded to either COMMITTED or confirmed rollback. All mutation
correlation comes from this response's canonical UUID, never old metadata or a
client-generated substitute. A malformed200 stays unconfirmed even when a later
GET establishes a usable current state. A successful SDK call is its own preview
result, not a fresh current-source claim.

## 3. Minimal browser owner and bounded transport reuse

Add `console/lib/legacy_preview_recovery.js`, imported by index.html without
converting existing inline onclick globals or changing the layout. Until its
owner is initialized, request functions remain disabled, not legacy fallbacks.

Proposed owner interface: `createLegacyPreviewRecovery({request, clearCurrent,
publishCurrent, publishNotice, setBusy})` returns `submitPreview(path, body)`,
`refreshCurrent()`, `captureEpoch()`, `isCurrent(ticket)`, `beginNumericalAction()`,
`finishNumericalAction(ticket)` and `dispose()`. This is the one legacy-page owner,
not a generic transaction framework. Tickets contain only local monotonic counters,
not clinical state. Busy acquisition is synchronous before the first await.
Repeated clicks/keyboard/programmatic submissions during an operation do nothing.

`submitPreview` accepts only POST `/api/stimulate` with `kind` base/life_system and
object params, or `/api/ingest_note` with a nonempty string text. Preserve all
existing base aliases, LIFE modes/defaults/custom conversions and note text; no
new clinical interpretation. Snapshot the body before await and strictly serialize
finite JSON up to **2,000,000 UTF-8 bytes**, rejecting, never truncating it.

Reuse `selectionRequest` and the existing strict parser. Its only shared changes
are the three fixed error codes above and optional `expectedStatus` accepting
only undefined/200/201, checked before transport; default behavior is unchanged.
Legacy preview POST and state GET request exact200. The legacy request adapter
passes `redirect:'error'` to the existing authenticated window.fetch; no second
HTTP stack, redirect following, status reconstruction or credential storage.
Apply the existing absolute60s POST and20s GET deadlines through body admission,
2,000,000-byte response cap, strict UTF-8/duplicate/nonfinite/depth64 parser and
bounded reader/timer cleanup. Request/body failure is safe and never retried.

On preview start, advance the owner epoch, invalidate older read/biology tickets,
detach `S`, clear current numerical/evidence DOM and the current LASTRUN handle,
then send exactly one POST. Keep form inputs, selected conditions/variants,
existing history entries and explicit navigation intact. No optimistic base
highlight. Disable all numerical mutation/replay controls while current state is
unknown, pending or modeless; getters must guard too, not just button attributes.
Confirmed modeless state permits the three explicit preview actions. UNKNOWN
authority does not: offer read/reconciliation navigation, never a healthy bypass.

After any dispatched preview settles, if the owner remains live, perform at most
one fresh state GET. It is a separate current-state read, not a preview retry or
automatic reconciliation. A later explicit Refresh is one additional GET. Retain
the operation notice independently so render cannot erase unknown/cleanup facts.
If auth is unavailable, do not create a login/POST retry loop. If disposed/pagehide,
cancel owned reads, invalidate tickets and issue no follow-up. On bfcache return
require one fresh GET; never resend a saved body. No browser storage is added.

Wire all five existing S writers and paintBody to this owner. Numerical actions
keep their current endpoint/body/math but take the same busy permission and check
the ticket before assignment/logging/render/finally. A stale callback cannot
publish, clear another operation's busy state, change a base button, append a
current run, or paint previous-person quantities. Source-generation equality is
an opaque comparison, never ordering. A final GET can still become outdated after
its own read; this is last-observed state, not continuous cross-tab coherence.

Fresh state must pass typed availability plus the existing renderer's required
structural fields before publication. For READY: require nonempty profile/base,
object profile_params with name and the 12 finite numerical fields emitted by
runtime.state (`weight_kg,Gb,Ib,SG,p2,Si,gamma,Gt,n,ka,f_bioavail,vg_per_kg`),
systems rows, finite equal-length nonempty metabolic t/glucose/
insulin and cardiac t/v/cai vectors, and the displayed numeric summaries; do not
invent defaults, clamp values, fit parameters or add physiological thresholds.
For modeless: require the exact null numerical fields/applied-empty/active-null
shape emitted by clinical_views.unavailable_state and object patch/observations.
Permit additional producer fields; reject an error/code payload as state. Use the
existing typed validator for identity/reason/mode and require safe version/handle
fields at this consumer boundary without modifying the shared model validator.

A preview ACK additionally requires READY/reference_preview, null twin_id,
version0, preparation_available true and a canonical current UUID. Its own
profile_params are mandatory; never borrow parameters from the fresh GET. The
browser renders only the fresh GET, not the ACK as current state. Note extraction
may be shown separately as this acknowledged preview's extraction only if that
GET has the same source_generation; otherwise clear it. Never merge stale
extracted metadata into the winning state or label it admitted clinical evidence.

Clear current charts, animated cell/trace/body fills, metrics, warning/provenance
styles, systems' alive claims, chips, human/organ/note summaries and current patch
status on pending/invalid/failed read and again on partial render failure. Keep
the reference illustration and frozen history. Existing frame loops remain but
cannot repaint when S is null. Put a persistent text-only notice and Refresh/
Twins/LIFE/Cendos History links beside existing controls; no redesign or new CSS
system. No invented execution ID, auto Stop, Resume, restart or cleanup claim.

## 4. Attached SDK and terminal

Add a named `_research_preview_request(path, body, *, timeout=60)` transport entry.
It admits only the two fixed paths/body families above and uses the exact
**2,000,000-byte request cap**. Root explicitly approved this compatibility
exception: the server already admits2MB, whereas the continuous default is16KiB.
Factor only the existing transport implementation behind the two named wrappers;
keep `_continuous_request`'s signature/default behavior and every default16KiB
request,8MiB response and canonical16MiB frozen-member exception unchanged. No
caller-supplied arbitrary cap or generic public override. Reject malformed path,
kind or mode before network. Same strict parser, no proxies/redirects/auth changes.
The60s urllib timeout is a socket/blocking timeout, **not** a total wall deadline.

Only attached `Platform.patient` switches from `_post` to this named entry, with
exact200 expected. Leave `_post` and its other callers unchanged. Validate the
preview ACK's availability, mandatory own parameters and summary shape before
calling `_summary`; malformed output raises CLIENT_UNCONFIRMED with this response's
UUID. Preserve successful SDK return fields/values and caller inputs unchanged.
No automatic GET, source replay, local extractor/model import or in-process
fallback. Explicit `Platform.state()` and `reconcile_twin_selection()` already
provide inspection and intentional recovery. A response-close failure preserves
the ACK and existing fixed cleanup_code metadata, never replaces it with rollback.

For attached preview only, replace raw `patient.set` audit arguments with fixed
metadata: action research_preview.request, family base/life_system/note,
outcome ACKNOWLEDGED, current verified request UUID; no note/conditions/genome,
subject/display IDs, parameter/quantity values, raw response or payload hash.
Do not log success on dispatch/validation failure. This local receipt is not the
server's authoritative access audit or a scientific fingerprint. No new local
key/store policy; old records and in-process audit paths remain untouched. If a
local metadata-audit operation fails after a valid ACK, preserve the ACK and add
a fixed CLIENT_AUDIT_UNCONFIRMED metadata marker, not a second request or false
server failure. No raw exception is retained. This marker is not a new server code.
The existing audit helper swallows append errors internally: its return cannot
prove local persistence. The marker covers observable failure only; neither the
new metadata attempt nor absence of a marker certifies durable audit completion.
Changing that legacy audit mechanism is not included in this client packet.

The attached terminal prints typed fixed errors and current UUID through the
existing handler, adding fixed preview guidance: `show state`, `twin list`, and
only when uncertainty persists explicit `twin reconcile-selection`; prior cleanup
is separately inspected with existing execution/LIFE commands. A successful
patient result keeps its numerical summary but is introduced as an acknowledged
research-preview result, not a current registered person. Warn safely on response
close/local-receipt uncertainty without erasing the confirmed result. Do not erase
earlier terminal output; label it historical, not currently authoritative.

Redact pipeline echo for every patient prefix, including partially quoted command
words and malformed tails, to `patient` only. Parse a malformed patient command
with the existing strict shlex path before legacy fallback, yielding a fixed
CLIENT_INVALID without dispatch or raw text. Preserve valid patient aliases,
arguments and defaults. REPL errors remain usable; pipelines stop nonzero through
the existing ContinuousClientError catch, before subsequent commands. The SDK
method must never manufacture a success summary after HTTPError. No implicit
switch from attach to inprocess, startup service launch or persistent command log.

## 5. Red-first, independent acceptance and actual QA

Proposed dedicated files: `test_legacy_preview_recovery_ui.py` and
`test_legacy_preview_recovery_clients.py`. No tests are authored or run here.

- For each base/LIFE/note path: exact one POST/body, preserved aliases/defaults,
  READY and modeless entry, DENY_ALL rejection, valid200, input422/auth401/403,
  source409, both known503 kinds, unknown503, network/read timeout and malformed200.
- Actual strict transport: absent/stale/invalid UUID,201, duplicate/nonfinite JSON,
  wrong availability/selected identity/null parameters, request exactly2MB/+1,
  browser response2MB/+1, SDK8MiB/+1, encoding/redirect rejection, failed close
  preserving ACK, unchanged16KiB defaults and16MiB frozen-member detail rules.
- Mount the actual legacy controller with real selectors: old numerical and note
  DOM seeded, frame callback after clear, partial-render exception, delayed load/
  biology/runVia responses, double click and programmatic action, operation epoch
  and busy-finally races, dispose/bfcache and response parsing after deadline.
- Acknowledged preview followed by a different current winner; cleanup503 followed
  by valid current preview; unknown/lost ACK followed by valid or denied GET. Keep
  both facts, never reinstall an ACK, infer a person from null or resend POST.
  Preserve input text/choices and existing fixed History, clear current export
  handle, retain explicit inspection/cleanup controls and no auto recovery POST.
- Real attached patient/transport/REPL/pipeline paths with intercepted responses:
  no `_post`, local constructor, source/registry or real network fallback; only
  metadata enters local audit and redacted echo, including malformed quoted tails.
  Audit failure and close failure never mask a confirmed result. No stale UUID,
  success audit on error, raw PHI-like sentinel, response body or traceback output.
- Preserve selection-reconciliation UI/clients, clinical model-availability UI and
  SDK/terminal tests, strict JSON/execution-client/frozen-member limits, legacy
  model-workflow clients, clean UI/workflows and preview producer regressions.
  Existing fake `_post` fixtures must not accidentally reach the new real transport:
  replace only stale seams, retain their original assertions and use socket/DNS/
  urllib/process/model tripwires. No broad test skips or numerical/native runs.

After implementation freeze, independent source/fixture review and isolated tests
must pass before root-authorized real-browser QA on a fresh private technical
stack. Use authored-only READY/modeless/uncertain records and inert candidate
factories; do not submit real notes, create participants or run physiology merely
to test recovery. Exercise desktop and390px legacy page with normal cookie auth,
keyboard submission, actual controls/screenshots, each new503, one intercepted
lost ACK, later winner, Refresh and explicit navigation to existing Twins recovery
and History. Retain exact POST/GET counts and request UUID evidence without input
or response payload logs. Verify current A+B routes remain intact. Separate exact
private CLI/SDK smoke cases require approval; no live backend fallback in unit QA.

## 6. Ownership, pins and pending gate

Proposed runtime write set only: index.html, new legacy_preview_recovery.js,
selection_reconciliation.js (bounded transport additions), sdk.py, shell.py and
execution_client.py (named request entry/safe codes). Root retains server,
registry, execution, scientific models, authority and all current workspace/
subjects UI files. No new dependency, asset, browser runtime or test harness
installation. Confirm no overlapping owner before edits.

Inspected SHA256 pins:

| File | SHA256 |
| --- | --- |
| index.html | `dcd95dea8bb84c5e357cf7907584d49e34c894877656176a5e504e94b1a24f5a` |
| sdk.py | `353c07d2c91cd620892db08d36985204e0e1befe2da1fba72f8b95053373e7f7` |
| shell.py | `4f10b51407fbeefaa631955ef1b64d8c7033a6e6a53b906abb831c19a01abdf1` |
| execution_client.py | `88da31ed4d542281b04cb33a074379703d836ea0cb9d29fc1d362688c6d71b78` |
| selection_reconciliation.js | `d7a6486fb12fd27cc865ce5385d988f5da41efaec26b81cdde3919cff85684a2` |
| biological_projection.js | `b38498f48bc5677e601e1f9a340ad9e6074ef3db1925356ed273db76b63d3c37` |
| auth.js | `4e5130f476ce0a3a3a0d0096986985cbdd2ecbf7131afbe3e89d7a7430996bf3` |
| preview producer plan after RED appendix | `4d4aae3d965559df395e4f356680d981326a9cf08d0e670e8d68875ba14493d3` |

Root approved the2MB request exception and metadata-only audit/redacted echo
direction, **not implementation of this full document yet**. Re-read the final
frozen producer response contracts before code; conflict requires a written
amendment, not permissive client defaults. This plan follows engineering-review
reuse/failure analysis and records the lesson in solutions: distinguish submitted
result, last-observed current state, authority uncertainty and cleanup outcome at
every consumer. R01–R51, prior failed Atlas runs and failed insulin benchmarks
remain unchanged. No endpoint delivery, scientific acceptance or release is claimed.

## Independent pre-code review — root

Root read the entire289-line proposal and the actual shared browser transport,
attached transport, SDK patient/summary, clinical unavailable-state projection,
legacy state writers/renderer and terminal parsing/echo seams. The maker has not
implemented this packet. The minimum-diff reuse and narrow write ownership above
are approved, with these implementation/test precisions:

1. The public owner interface must include an explicit `reopen()` for bfcache
   return. `dispose()` invalidates and aborts current work; `refreshCurrent()` on
   a disposed owner cannot silently resurrect it. Reopen performs one fresh GET,
   resets no historical operation into a replay and reinstalls no duplicate event
   handlers. Test repeated pagehide/pageshow and a late pre-disposal callback.
2. Validate the request's JSON data domain before serialization. JSON.stringify
   alone silently converts nonfinite numbers to null and drops undefined/function
   values; a serialize-then-parse check cannot detect that loss. Reject unsupported
   values/cycles before any POST, retain ordinary finite JSON exactly, and apply
   the named byte cap to the bytes actually sent. The optional shared expected
   status must be validated before any transport; unrelated defaults remain exact.
3. UI callback failure must not strand the owner busy or permit a POST after a
   failed pre-submit clear. A rendering failure detaches S again and leaves safe
   inspection controls usable; catch only to a fixed notice, not a raw exception
   or success. Add callback-failure and stale-finally assertions to the existing
   owner tests. Preserve existing physical/reference provenance classes.
4. Keep the fixed audit warning separate from the confirmed server result, and
   retain the explicit limitation that the old audit helper swallows persistence
   errors. Do not broaden this into an audit.py rewrite or claim durable receipt
   confirmation from its return value.

Proceed red-first in the stated six runtime files and two dedicated test modules;
modify existing fixtures only where the obsolete `_post` seam otherwise escapes
to a real transport, preserving their semantic assertions. No overlapping writer
owns these six files. Root's producer is frozen for independent review and is not
part of this write set. No native execution, real service, browser or operational
data use is authorized by the unit implementation gate. Independent maker-external
review and a separately bounded real-browser acceptance remain required.
