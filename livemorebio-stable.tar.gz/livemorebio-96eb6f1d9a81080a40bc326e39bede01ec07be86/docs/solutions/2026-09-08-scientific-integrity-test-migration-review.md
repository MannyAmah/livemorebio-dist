# Clinical test-boundary migration: maker packet

2026-09-08. Independent review pending. Authority: root approved the exact
111-line migration proposal SHA-256
`fad6df73256362077ac203639a432d42e2cacba1835f1125c00d5bfa7ae59c55`, including
the seven formerly passing but masked validation cases. No runtime code, source
parameters, binding admission or numerical criteria changed.

## Preserved invariants

- The original 7 mmol/L observation, 180 mg/dL random glucose, 150 mg/dL
  unassessed observation, weight 80 and all original malformed inputs remain.
  Pure normalization/conflict checks now exercise their units, timestamps, QC,
  candidate values and provenance directly. Each unbound-human call separately
  requires the exact `MODEL_BINDING_REQUIRED` reason; it cannot replace a unit,
  QC or parameter-domain assertion through a broad ValueError.
- All 12 executable legacy-reference values retain source, unit and evidence
  class; the seven source parameters and five reference defaults remain distinct.
  The two four-member DPP/NHANES and 12-value golden hashes are unchanged.
- REAL admission preserves normalized and original observations, field/source
  provenance, custody and the descriptive creation identity across encrypted
  reload. No generated executable provenance or inferred Si is added.
- All five custom declarations (`p2=.031`, `n=.19`, `ka=.027`,
  `f_bioavail=.68`, `vg_per_kg=2.4`) survive create/get/reopen. Rejected numerical
  activation leaves ciphertext, record version and absent active selection
  unchanged.
- The two legacy physical-pairing fixtures now use explicit observation selection,
  remain ACTIVE/unbound/observations-only, preserve device exclusivity and source
  evidence, and prohibit numerical constructors, device commands and peer HTTP.
  Protocol 2.0 metadata and `PENDING_SIGNED_ENVELOPE` remain; this is not proof of
  hardware, protocol-v3 integration or a physical measurement.
- Shell fixtures retain the same SDK arguments, versions, keys and cohort
  strata. Confirmed selection displays the opaque twin ID, not its pseudonym or
  label. A retained active object without selection confirmation stays unconfirmed.

## Red/green and one fixture limitation

Before test edits, the exact mapped set reproduced **9 failed / 7 passed /
32 deselected**, 1 existing warning, **1.35 s** in private isolated root
`livemore-research-review-nzs9iige`. The seven passes were the previously masked
ValueError cases, not independent validation success.

First migrated focused run: **1 failed / 15 passed**, 1.51 s. The optional
observation-selection step attempted on the five-declaration fixture correctly
rejected its original `LEGACY_ADMISSION` source timestamp `not_provided` with
`SUBJECT_ADMISSION_REQUIRED`. The approved proposal made that step optional.
It was removed instead of inventing new provenance or weakening eligibility.
The original input remains exact; encrypted retention and rejected activation
still prove the intended five-field invariant. Dedicated physical fixtures
already have explicit source ledgers and exercise observation selection.

Final intended packet: **94 passed**, 3 existing warnings, **2.92 s** in
`livemore-research-review-2j3qeitr`, using the managed Python and
`tools/run_review_tests.py -q -p no:cacheprovider` on:

- complete `test_scientific_integrity.py`;
- complete pure `test_clinical_context_contract.py`;
- only the two mapped physical-pairing and one mapped shell tests in
  `test_subject_lifecycle.py`.

An earlier broader selection also ran the entire pre-existing subject-lifecycle
file: **107 passed**, 3 warnings, **8.12 s**, root
`livemore-research-review-8ed5wdub`. That included its unchanged local synthetic
AegleTwin restoration/activation cases; it is **not** numerical-constructor-free
evidence. This broader-than-intended selection was reported to root, and the
proper scoped packet was rerun above. No live service, browser, operational
store, participant or physical device was accessed. Existing scientific-integrity
math remains in its original tests; no new scientific model execution was added.

## Frozen lineage

The seven root-owned Cendos preservation cases and their no-peer-network fixture
were not edited by this migration. Before changing this test file, independent
Cendos review confirmed its frozen SHA
`5c497e243c2d2debe4ef4537c67f35591e66466efec89f8e77c1e3e63b8d8d6d` and reran all
74 dedicated plus seven preservation cases. See the separate Cendos review.

| Changed test file | New SHA-256 |
| --- | --- |
| `livemorebio/tests/test_scientific_integrity.py` | `4c8e926cb65aed31bc755bd25ea22a29584edb4adf655814321c857ce88c1be0` |
| `livemorebio/tests/test_subject_lifecycle.py` | `007b71137591f44064b07cba2649888a137ad1928b7f8c70b0cbcc608efb87d9` |

The frozen registry bootstrap/audit/subjects hashes remain unchanged. Their
separately discovered malformed-graph review findings remain open; this test
migration neither repairs nor waives them. R01–R51 and clinical binding/physical
qualification are not accepted by these software assertions.

Lesson: after an earlier fail-closed guard is added, broad exception assertions
can turn scientific validation tests into vacuous passes. Exercise the original
validator directly and test authorization separately. The existing local
solutions workflow retains this lesson; no unavailable CE invocation is claimed.

## Root independent review

Root read the complete migration proposal/report and the two test-file diffs,
separating prior Cendos/Atlas changes from this test-only migration. The original
unit, QC, timestamp, parameter-domain and five-field preservation assertions
are now exercised at their appropriate boundaries; an early binding rejection
cannot satisfy them. The original incomplete source fixture was not altered to
make optional observation selection pass. No actionable bounded migration
finding remains.

Independent intended-scope rerun: **94 passed, 3 existing warnings, 2.88 s** in
private root `livemore-research-review-xfmqpjo_`. The main process refused DNS,
socket connections and connection creation; Cendos tests retained both urllib
tripwires. This includes the original local scientific-integrity math, not a new
native worker, participant, device or live service. Only the three named lifecycle
cases were selected, not the broader lifecycle file. Runtime/qualification and
the separately open registry, selection, browser and six-program gates are not
accepted by this test migration.
