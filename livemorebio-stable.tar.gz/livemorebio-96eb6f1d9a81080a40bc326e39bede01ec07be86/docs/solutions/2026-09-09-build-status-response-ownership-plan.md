# Build-status response ownership correction

Written before implementation, 2026-09-09. Approved scope: preserve and restore
the existing connected Aegle/LIFE/Cendos UI, with error recovery tested. No
biological equations, data, selection, authentication or geometry changes.

## Source investigation and pre-code review

Actual Biology diagnostic 1xHVWj remains FAILED. It observed bootstrap HTTP 204
then ERR_ABORTED, and two build HTTP 503 responses without terminal events at
cutoff. These are observations, not established causes. Root and independent
reviewer read auth.js, build_identity.js and the private fixture. There is no
evidence supporting a production authentication change. The fixture's forbidden
Content-Length header on HTTP 204 is a separate fidelity defect, not an established
explanation of the bootstrap failure. Preserve the consumed fixture and receipts.

The source proves an independently correctable ownership defect:
mountBuildIdentity throws on a non-OK response before reading its body;
Promise.all can then reject while its sibling request is still pending; the
monitor finally clears the deadline/controller. This abandons response work.
The same monitor calls read synchronously outside its rejection path.

Independent pre-code review by release_redteam accepted the following small
correction. This is not a new request framework or a waiver of browser failures.

## Implementation boundary

Only livemorebio/aegle/console/lib/build_identity.js and its dedicated tests.
Retain existing labels, service/build matching, URLs, credentials, polling interval
and eight-second deadline. Capture each flight's own controller and timer.

1. Defer each of the two fixed fetch jobs through a promise so a synchronous
   dispatch error cannot prevent the sibling from being owned. Read each JSON
   body even on a non-OK status; do not expose error content to the UI or logs.
2. Await both jobs with allSettled before returning results or the fixed generic
   unavailable error. The existing deadline bounds a stalled body or peer.
   Missing/malformed responses fail closed, not as a matching build.
3. Deferred monitor reads must catch synchronous failures and must not dispatch
   after disposal. Each flight owns its own deadline/controller; old settlement
   must not clear a newer flight or schedule another poll. Timeout/disposal abort
   only their owned flight, suppressing late updates.

## Verification

Add failing tests first, execute the actual mounted read against authored fetch
responses and deterministic timers, then make the minimum correction. Preserve
all existing formatting and monitor assertions. Cover both successes, non-OK
JSON/null/malformed/absent responses, pending companion/body, timeout, disposal
before dispatch, synchronous read/fetch exceptions, deduplication and late
settlement across flights. No network, browser or model executes in these tests.
Root reads the exact delta; independent reviewer grades code and repeats tests.
An eventual fresh browser acceptance is separate and must retain original
failure evidence. Do not mutate or retry the consumed 1xHVWj runner here.

Learning: settling a promise after response headers does not prove the response
body or companion work has settled. Keep ownership through body completion,
failure, cancellation and cleanup. This is software behavior, not validation
of any biological model or human-equivalence claim.

Primary references checked during investigation: WHATWG Fetch sections on
[null-body status](https://fetch.spec.whatwg.org/#null-body-status),
[body consumption](https://fetch.spec.whatwg.org/#body-mixin) and
[garbage collection](https://fetch.spec.whatwg.org/#garbage-collection);
[RFC 9110 section 8.6](https://www.rfc-editor.org/rfc/rfc9110.html#section-8.6).
Context7 was unavailable after discovery. The reviewer additionally traced the
matching Chromium 153.0.8010.36 fetch-manager/resource-loader sources. Their
no-store body buffering/EOF paths support an unread-body hypothesis, not a
measurement of this run's internal browser state. Do not add body consumption
to the null-body bootstrap response or infer garbage collection was observed.

## Private browser-fixture correction, separate from product code

Before any fresh browser run, prepare one new private copy of the existing
1xHVWj checker and its unchanged six-stage workflow. Preserve the consumed
original. Correct only response framing: HTTP 204 has no Content-Length and no
body; all other responses retain exact byte length, existing content type/cache/
security headers and body. Add RED-first emitted-header/body tests for both
204 routes and for the existing 200/503 routes. Do not fabricate a session cookie
or make this unauthenticated fixture stand in for authentication acceptance.

Retain the original 33 Node and 10 Python tests and all strict request evidence,
limits, cleanup and failure predicates. Pin the current separately reviewed
build_identity.js only after its implementation freezes; other existing input
pins remain unchanged. Root reads the exact fixture delta and independently
repeats tests before deciding one browser invocation. No browser/native run is
authorized by preparation; no new observer/framework/body interception or retry
loop is permitted. Overall failure cannot be waived even if six stages pass.

### Private framing maker checkpoint: input pin still pending

Fresh private copy: `/private/tmp/livemore-biology-response-framing.twZXX0`.
Only one handler line became two: conditional Content-Length for non-204,
and argument-free `end()` for 204. All other handler, payload, workflow,
request ledger, counters, failure predicates, deadlines and cleanup bytes
are unchanged. No cookie or response/body interception was added.

RED `2f166f` ran against the exact original checker hash
`4f4dc97b123fc246a789b804769f4be6030e590e29c844d0690a794617425510`:
the two 204 tests failed on emitted Content-Length/body arguments; 37 Node
tests passed. Python was not reached because the Node result failed.
After the minimal correction, GREEN `80ec06` and repeat `3e3539` each passed
39 Node + 10 Python tests (0.276 s and 0.323 s tool wall time). No skips,
actual browser, service, model/native or network execution occurred. The
unchanged refusal wrapper permits only its one fixed inert Node test child.
RED/GREEN/repeat used identical test bytes.

The six additive cases inspect emitted `writeHead`/`end` arguments for both
204 routes and `/biology`, `/api/services`, `/api/biology`, `/api/build`.
The non-204 assertions retain the exact header set, MIME, UTF-8 byte length,
body bytes and request/read accounting. Original 33 Node tests remain an exact
byte prefix; all three Python files remain byte-identical to consumed 1xHVWj.
Data-only reversal/check `8b1247` proves the exact two-line-only checker delta
and matches the other 28 existing input rows by bytes/mtime/hash.

Private checkpoint SHA-256 values:

```text
check.cjs
92f8218fbafa4b6b2e154029426437e97c82ebed5cf4d2eb3b6cc3bdf77f142c
test-check.cjs
838df5e5e83463f44051b54c732bb32aa1eb1fdd0eef939dabafa769aa452d64
check.py (unchanged)
3ca5d4f9750874b6636bc8534f5aa62c478b66fcec16d4fdb1a01a188dc50e5b
test-check.py (unchanged)
34054a1ca04951856715ad7424b694fdd39a5da4a2a20048bd928d6557362ef9
run-inert.py (unchanged)
e3094923a9309c49f817d670ecf276870ee428d8a3cd57bcab67e4f3243cf75e
source-tests.diff
a17e03bb9f677e349077c28cd169a8935e6f789252348088c8484d8d68148c3b
red.txt
1ef8e73d6f94434e41eb29dcfd336fd07126687ed389ac9e8815a9bfb35e6cbc
green.txt
318a76a7ca94a4769deaf4d10ce4a2d0ae93f5d42a09ef1410fbfb423e747102
repeat.txt
25a795145c6ed342f426dbd02a7ca55addb096528b3bd237c63794ce310fd495
```

Exact inert repeat:

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-biology-response-framing.twZXX0/run-inert.py
```

`inputs.before.json` and `harness-pins.before.json` are unchanged archival
copies only. Final `inputs.json`, `harness-pins.json` and `run` are deliberately
absent pending root's separately reviewed build_identity.js hash. No current
build pin is frozen by this checkpoint; no actual invocation is authorized.
Root still grades this fixture independently. The forbidden old 204 framing is
a proved fixture defect, not a proved cause of the original browser failure.

## Root fixture grade and one actual browser decision

Root read the full exact handler/test delta (`9455b1`), all six added tests,
the unchanged parent supervisor (`dd786a`) and complete final manifest delta
(`04f8c6`). Independent inert repeat `7a4763` passed 39 Node + 10 Python cases
in 0.284 s. Independent product review separately cleared 101 tests; counts
are not added into a whole-product total. Data-only root check `5a48e7` matched
all 29 source and six harness rows, only the approved build source changed,
other 28 rows unchanged, new run directory absent.

Authorize one invocation of the frozen twZXX0 checker using pinned Python:
`/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-biology-response-framing.twZXX0/check.py --run-once`.
Inputs SHA 50636f71592ac7321716c2dc0675e472297d16d2b3e6333decb3516425db9bf6;
harness SHA a08a3480f6a41e29b2fa3c5140cadf02f2f3993c83b5591f58e9a5c1128bc5ad.
The previous browser and native run have settled and exact owned PIDs are absent.
No concurrent native/browser job, operational store/service change, authentication
waiver, request-failure exception or retry of a consumed root is permitted.
Inspect all six original images, request evidence and cleanup after this run.
A pass is only the stated graphics-disabled recovery/response workflow, not
full-Biology, human validation, a six-program video or release authorization.

## Actual browser result: response ownership improved; overall FAILED

Once-only actual `a82e8f` / `f6b8c1`, exit 1, retained at
`/private/tmp/livemore-biology-response-framing.twZXX0/run`, elapsed 21.455207208 s.
All six stages passed; zero page errors and zero unexpected console errors.
The original request ledger now has 32 requests, 31 FINISHED, one FAILED and
zero pending at cutoff. Both `/api/build` 503 responses (25 and 29) FINISHED,
unlike the earlier retained missing terminals. This supports the narrow mounted
response-ownership correction; it does not turn the old failures into passes.

Bootstrap request 15 still received 204 and then `net::ERR_ABORTED` at
4336.22625 ms, 0.533459 ms after its response callback and before owned close
at 20707.080541 ms. Correcting the fixture framing did not eliminate this
failure. Its cause remains unproven. Do not add arbitrary auth changes, classify
it as successful, or run another unchanged attempt.

Root read the complete request/event ledger, receipts and all six original PNGs.
Current images retain visible stale-warning/retry, explicit closure after context
change and no automatic cell reopening on recovery. Desktop heading wrap and
mobile scrollable navigation remain visible. Graphics are deliberately disabled;
this is not a whole-body preview or acceptance of the unfinished 3D Biology.

- Raw, 27,538 bytes: `31abfbdc9b4def3de6ce02f492f45c4cfd1e345804f435fb4d1f2a6798a8c548`.
- Supervision, 33,113 bytes: `526cbfca487d6aa77fb8953e4c7f3ac9452768a248e0f5cfbe0117490711351b`.

All 29 source/six harness pins unchanged; all four owned closes settled. Leader
62054 reaped; no remaining descendants or listeners. Root exact-PID postcheck
`1d1a76` found none of 62054, 62058, 62060, 62072, 62085, 62086, 62087, 62088,
62094, 62097, 62098, 62120. Independent data-only review requested. No further
browser attempt or release is authorized by this failed result.

Independent data audit `cce53c` subsequently matched all 35 pins, 21 visited
source receipts, all six original PNG identities/dimensions, exact raw/embedded
receipt equality and all 96 request events. The 32 request/response/terminal
triples contain exactly 31 FINISHED and one FAILED, with no pending records.
Read-route/status accounting and 244,277 served bytes agree. Images total
1,624,094 bytes; all retained evidence totals 1,684,811 bytes, exactly reconciling
the pre-supervision total plus its 33,113-byte receipt. Cleanup records and root's
separate PID postcheck are consistent. This confirms evidence integrity, not a
successful overall run or a cause for the bootstrap failure.

Continuation boundary: preserve this reviewed correction and all failed receipts.
Next work must investigate session-bootstrap cancellation and the separate OSP
scratch/evidence-file boundary. The investigation workflow's repeated-failure
stop applies before further execution attempts; request explicit direction.
Full 3D Biology, A+B visual acceptance, the six named experiment recordings,
whole-product validation and publication remain open in the master register.

### Final private manifest freeze

Root independently read the fixture delta/new tests (`9455b1`) and unchanged
wrapper (`dd786a`); its repeat `7a4763` passed 39 Node + 10 Python cases in
0.284 s. Root then supplied the independently graded product hash
`2bbd8fc2b2b50dbeebd1edc47fde42fd1c25fd89a7073178ac43393c30d94e1f`
after product review `f9b442`/`d378ed` passed 101 in 9.27 s. That separate
root instruction authorized completing the final private manifests, not a run.

The final `inputs.json` changes only the build_identity.js row's bytes, decimal
mtime_ns and SHA-256: 5423 bytes, `1788954934732739976`, and the approved hash.
Other 28 source/runtime/helper rows are exactly equal to consumed 1xHVWj,
including fixed page SHA `510bae8d67cd3bdb703a2d02b06da35805e7311942c65b7c984618fd1ba18f1f`.
`harness-pins.json` binds the same six fixed filenames in the fresh root using
their final byte lengths, exact decimal mtime_ns values and hashes. All five
checker/test/wrapper hashes remain identical to the prior framing checkpoint.

Data-only verification `91de42` matched all 29 input rows and six harness rows,
confirmed only that one input-row change, and confirmed `run` absent. Its
following diff commands returned the expected difference status; all preceding
verification assertions succeeded. The original 1xHVWj browser/supervision
receipts still hash to `1c6c42fade7be1e52d2a2a442a22d37960942aa33bb236c2270870c013b7ff60`
and `bf9731420e557fc18975b23d53acf33dd0f59307f04833fe9f203d94ff12e7eb`,
both FAILED. No additional tests, source changes or actual invocation occurred
while preparing these manifests.

Final manifest SHA-256 values:

```text
inputs.json
50636f71592ac7321716c2dc0675e472297d16d2b3e6333decb3516425db9bf6
harness-pins.json
a08a3480f6a41e29b2fa3c5140cadf02f2f3993c83b5591f58e9a5c1128bc5ad
```

`manifest.diff` and `final-verification.txt` retain the exact change and read-only
result in `/private/tmp/livemore-biology-response-framing.twZXX0`.
All inputs and harness files are frozen for root's final manifest review.
The exact prospective command below remains unexecuted and requires a separate
root actual-run decision:

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-biology-response-framing.twZXX0/check.py --run-once
```

## Independent product review and repeat

Release-redteam independently read the full approved product contract, the
113-line module, all 214 lines of dedicated tests, and the real shell/workspace
mount callers. The review skill's concurrency and consumer checks were applied
within the read-only product boundary; no Git, automatic fixes or browser steps
were performed. A separate read-only reviewer also found no source blocker.

**Narrow verdict: CLEAR for the response-ownership correction.** Both fixed
fetch jobs are deferred independently, JSON reads remain owned on non-OK
responses, and allSettled retains the sibling until completion or the monitor's
existing timeout. Synchronous read/fetch failures enter the fixed unavailable
path. The deadline, controller and cleanup are captured per flight; disposal
and late old settlement cannot update or cancel a newer flight. The inherited
formatting, call-count, update and disposal assertions remain; the added
`await flush()` waits for the deliberately deferred dispatch, not a relaxed
assertion. No extra product or test edits were made by this reviewer.

The independent six-file repeat passed **101 tests in 9.27 seconds**, with
**97 Node children, zero unexpected I/O and zero Git attempts**, no skips:
launch `f9b442`, session `61844`, completion `d378ed`, private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-y_2096ep`.
This independently repeats 17 dedicated tests plus the 84-test existing
Biology preservation slice, not the separate private framing checker.

Before and after the repeat, both frozen hashes matched:

```text
build_identity.js
2bbd8fc2b2b50dbeebd1edc47fde42fd1c25fd89a7073178ac43393c30d94e1f
test_build_identity_ui.py
b43c667de1d75c31ccd1bfb67cc7d241cb99188c0a2c53290ad97d9a587eda8d
```

Exact independent command, from the fixed worktree (root confirmed the narrow
`-e`/`--eval` alias allowance against the maker's stored invocation):

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os,signal,socket,subprocess,sys,urllib.request,ctypes
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('OFFLINE_DEADLINE')));signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and len(cmd)==4 and cmd[:2]==['/opt/homebrew/bin/node','--input-type=module'] and cmd[2] in ('-e','--eval'):
  counts['node']+=1
  permit=True
  try:return run0([*cmd[:3],'import {createRequire as scopedRequire} from "node:module";const require=scopedRequire(import.meta.url);\n'+prefix+cmd[3]],*a,**k)
  finally:permit=False
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1
  permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=line','livemorebio/tests/test_build_identity_ui.py','livemorebio/tests/test_biology_context_reconciliation_ui.py','livemorebio/tests/test_clean_workflow_ui.py','livemorebio/tests/test_protocol_inspection_ui.py','livemorebio/tests/test_ui_biological_projection.py','livemorebio/tests/test_clinical_model_availability_ui.py'])
print('Refusal counts:',counts,flush=True)
raise SystemExit(status)
PY
```

Limits: these are actual module/monitor mounts with authored responses and
timers, not real browser transport. Arbitrary external `read` implementations
that ignore AbortSignal are not promised to terminate by this API; the mounted
production path uses native fetch/body reads. Original PHua9I and 1xHVWj
failures remain FAILED. This review neither establishes the cause of the
bootstrap abort nor proves browser acceptance, authentication or biological
qualification. A fresh actual-run decision remains separate.
