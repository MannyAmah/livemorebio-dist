# Atlas cache review: admission ordering and owned process-group lifetime

Date: 2026-09-08. Parent: `2026-09-08-atlas-reference-conversion-renderer-packet.md` and its hard-acquisition-deadline amendment.

Status: root authorized the lock/receipt corrections. The process architecture below is a **pre-code amendment for root and independent review**, not implementation or publisher admission.

## Reproduced findings and bounded cache correction

The independent reviewer ran all 136 prior technical tests and found three uncovered failures. Renderer work is paused at its red-tests-only boundary.

1. A symlink `.install.lock` or a non-contention `flock` failure escapes as raw `OSError` before the install normalization block. Normalize opening/locking failures to the fixed `ATLAS_UNSAFE_CACHE` error; retain `ATLAS_ACQUIRING` only for actual contention. Do not acquire any source, chmod unsafe paths, or expose the original path.
2. `_publish` changes `active.json` before applying the full receipt rule used by later reads. A completion UTC earlier than the operation start, or an existing receipt with the right source/digest but malformed ID/schema/times, can replace a valid old pointer with an unreadable candidate. One shared typed receipt validator must run before publication, for the prospective operation and any reused receipt. Keep exact five-field schema, fixed source, exact digest, 32-hex receipt ID, timezone-aware strings and ordered times. Preserve the prior pointer on failure. Monotonic resource deadlines do not repair a rolled-back UTC evidence interval.
3. `Popen.wait/poll` reaps the phase leader before verifying its process group. An independently reproduced technical fork left a descendant holding the inherited install lock. A reaped PID is not an ownership anchor and must never be used in a later blind `killpg`.

Red state for 1–2: nine failing tests and two existing source/digest preservation passes. After correction the complete cache file has 48 passing tests. These use only tiny explicitly technical source triangles; no actual publisher acquisition or anatomical acceptance.

## Process correction: preserve the full owned-group contract

Do not silently narrow the old orphan claim to a single worker. Add a small stdlib-only guardian inside the exact owned process group, with one fixed phase worker. It does not import Livemore, NumPy, trimesh, networking code or a caller-selected module. It performs no reference/cache publication.

```text
installer P                         exclusive owner/waiter of G
  | root FD + shared flock FD
  | P→G liveness pipe (P owns the only writer)
  | G→P completion pipe (one fixed bounded result byte)
  v
guardian G = session/group leader   PID remains live/waitable until group cleanup
  | stdlib-only; no heavy imports; fixed fork before any phase import
  | inherits private root/lock, closes unused pipe ends
  | G→W liveness pipe (G owns the only writer)
  v
phase worker W, same process group  acquisition OR conversion, never both
  | retains shared lock; original absolute phase deadline
  | default OS SIGALRM + parent-EOF guard before any package import
  v
any fixed-worker descendants        remain in G's owned process group
```

The guardian shares the existing absolute 600 s acquisition or 180 s conversion deadline; no startup/import/child/result resets it. `os.fork` is performed only by the new single-threaded isolated guardian interpreter, never by the multithreaded product API process. The parent still starts only one phase at a time. There are two cooperating child processes for that phase, not two source operations.

### Guardian behavior and explicit failure model

- Validate phase, absolute deadline, root/lock/pipe descriptors and fixed arguments in stdlib before fork. Close the completion reader in G and writer in P. The result is a single allowlisted success/failure byte, no output/log payload, path or biological data.
- After fork the worker closes G's parent-liveness and completion descriptors, receives only the cache root, shared lock and its own liveness reader, and executes the current pre-import deadline bootstrap. It cannot keep a parent-liveness writer alive accidentally. The guardian closes the worker's liveness reader.
- G uses nonblocking/select-based pipe monitoring plus `waitpid(W, WNOHANG)` for only its own worker. It has no heavy native calls or external network waits. The worker's default OS timer remains the independent native-call backstop. The guardian's monitor is responsible for whole-group cleanup, rather than claiming a Python signal handler is an OS-enforced group timer.
- On W completion, G reports exactly one bounded result byte, closes that result writer, and **stays alive** until P disposes the owned group. P treats the byte only as execution completion, not source/geometry admission. Any descendant still running at W completion is terminated before P independently verifies or publishes artifacts.
- On P EOF or the original deadline, G calls `killpg(getpgrp(), SIGKILL)` while it is itself the live group leader. It terminates its own group including W and any in-group descendants; there is no stale numeric PID lookup. A stopped G resumes the same deadline/EOF logic; the shared inherited lock prevents another installer while any owned process remains alive. A stopped process is not claimed to terminate until the OS permits it to run or an external owner sends SIGKILL.
- If G crashes/exits unexpectedly while P lives, P's held-waitable group cleanup below still runs. If G itself is forcibly killed **and P is also lost**, only W's existing EOF/default OS backstops remain. This simultaneous guardian/installer destruction is an explicit failure boundary; do not call this an adversarial sandbox, guaranteed cleanup of escaped sessions, or hardware/biological validation. Inherited lock descriptors fail closed against overlap, but arbitrary malicious descendants that close/escape the contract are not contained. Full process containment would require separately reviewed OS facilities.

### Parent ownership and verification before reaping

- A new dedicated `_atlas_process.py` provides only stdlib process observation/cleanup. P is the exclusive waiter for its `Popen` guardian. Never call `poll`, `wait`, communicate or a `Popen` context-manager exit until ownership-protected group cleanup is finished.
- Observe P's exact child with `waitid(P_PID, ..., WEXITED|WNOHANG|WNOWAIT)`. This holds the guardian PID even if it exits unexpectedly, preventing an unrelated process group from reusing that number. A live leader must also have `getpgid(pid)==pid`. Failure to prove ownership is a fixed error, never a signal to the unproven group.
- Darwin: reuse the independently reviewed Apple SDK 104-byte `siginfo_t`/waitid and `proc_listpgrppids` semantics from the Beard lesson. The latter returns a PID count, not bytes. Enumerate only the owned group, exclude a proven waitable zombie leader from live-member checks, reject a full/truncated result buffer.
- Linux: use `os.waitid` with `WNOWAIT`. Inspect bounded `/proc/<pid>/stat` process metadata only to identify this exact group; parse the final closing parenthesis safely, bound bytes/entry count, ignore processes that disappear during the read, and fail closed on other inspection errors. Do not expose, persist or log unrelated process metadata. Zombie members have closed FDs and are not executable. Test parsing with spaces/parentheses and malformed/truncated records. No shell `ps` command or subprocess recursion.
- Reject unsupported platforms/inspection facilities before launching a phase. This is an explicit support boundary, not silent unbounded fallback. Darwin runtime is available here; Linux branches require platform tests/CI, not a fabricated local Linux acceptance claim.
- On any result, deadline, parent exception or guardian death, prove ownership, signal only its group if live members remain, and verify no live members within a separate bounded 5 s cleanup budget before reaping G last. No automatic source retry. A cleanup failure remains a safe typed failure; publication is impossible. Keep locks/FDs until this cleanup attempt concludes. Do not report success merely because the group signal was sent.
- On normal worker completion plus surviving descendants, cleanup may succeed but the phase must fail if an unexpected active descendant was found; no worker that returned while helper work remained is admitted as a completed source conversion.

## Red-first process acceptance matrix

1. Tiny actual technical worker forks a sleeping descendant and exits with code 0 or 7. Both remain under G's group; cleanup proves no live members and lock availability only afterward. No publisher bytes are involved.
2. A worker succeeds without descendants; the exact completion byte is accepted only after group cleanup, and parent verification remains unchanged.
3. Kill P during a stalled phase import and while a sleeping descendant holds the shared lock. G ends the whole group; stop/resume G first to demonstrate the retained-lock orphan interval. No active pointer/receipt appears.
4. Worker blocked on the existing DNS/header/drip stand-ins exceeds the shortened absolute deadline. Guardian, worker and inherited-lock descendants terminate; no timers restart after fork or result.
5. Kill G unexpectedly while P lives; P uses its unreaped ownership anchor to dispose W's group. Inject ownership loss and prove no group signal; reject malformed completion/EOF, duplicate or overlong result, spawn/fork failure and missing inspection support.
6. Assert all inherited descriptor ends and clean environment values, no stdout/stderr/secret channel, and no guardian cache/network/publication authority. Failed spawn closes both new pipe pairs.
7. Preserve all source/cache/geometry/route tests and the recorded red results. Add Linux parser/ownership contract tests and run actual Darwin descendant/parent-death cases. Actual publisher conversion remains a separate approval checkpoint.

## Prior art reviewed

`tools/beard_native_worker.py` held-waitable helpers and supervisor; `docs/BEARD_UNIT_PRESERVING_TECHNICAL_VERIFICATION.md` independent-review correction and compounding lesson; `docs/solutions/2026-09-08-beard-unit-preserving-execution-followup.md` cleanup contract. This amendment reuses the ownership principle without importing Beard's physiological code or silently making Atlas Darwin-only.

## Authorized implementation and investigation checkpoint

Root and independent reviewer fully read and approved the amendment at SHA
`b3a86c60ccbbef0f791ad27d3501e6f6ed086b615ac642c152d0502f44c5a66f` before lifecycle implementation. The initial process helper tests were ten missing-module failures. Two real technical exited-worker/fork cases then reproduced the old launcher defect (zero-exit success with surviving descendant; nonzero-exit failure with lock still held) before the guardian correction.

The implementation uses the exact G-group/W-worker arrangement above. The new
`_atlas_process.py` contains no model/source/cache code. The guardian bootstrap is
an inline fixed stdlib entrypoint, with worker source embedded from the existing
reviewed bootstrap, not a `-m livemorebio` startup. W retains only its own
guardian-liveness reader, root FD and shared lock; real FD inspection tests check
that no result or guardian-writer endpoint survives into its phase import.

Two inherited mock tests initially failed after this protocol change because
their fake child supplied neither a completion byte nor the unreaped returncode
contract. They were replaced with an actual no-op technical worker under the
production guardian and an explicit proved-empty-before-reap assertion. They
still exercise environment/FD/no-publication and cleanup behavior; no assertion
was replaced with a skipped mount or a comment/string match.

The repeated deadline matrix exposed a second macOS exit transition. The
`/investigate` workflow paused speculative changes, traced only own-process
metadata and reproduced five failures in twelve shortened runs with the same
exact sequence: `waitid WNOWAIT = not exited`, `getpgid = ESRCH (errno 3)`, then
`waitid WNOWAIT = not exited`. The process was still this installer's unreaped
child; macOS had hidden its process-group lookup before making its exit waitable.
An immediate second check incorrectly classified that transient as lost
ownership. This was distinct from the earlier killpg/PermissionError transition.

The corrected guard performs bounded observation-only checks inside the same
five-second cleanup budget, until the owned group or held-waitable child is
proven. It sends no signal while uncertain, never reaps to resolve uncertainty,
and still rejects a permanent unresolved transition or actual ownership loss.
A deterministic transient regression failed before this correction; the
permanent-uncertainty no-signal/no-reap assertion passed and remains retained.
The process/worker matrix then passed **59 tests**, including twelve actual
shortened deadlines. No arbitrary delay, timeout widening or source retry was
used to hide the race. Whole-lane and independent acceptance follow separately.

This is technical process-boundary evidence only. Actual publisher acquisition,
decoded source admission, rendered Atlas acceptance and full biological scope
remain unfulfilled gates, not claims made by the guardian.

### Independent Linux scanner portability correction

The reviewer independently passed the 218-test source/API matrix against the
frozen helper SHA `bb4b387938f4c4e25a644a1bf4d342e8da40e40b75c3fbeb20546c147f77d07d`
and source/cache SHA `58ab81e85b0da2fc337d105cc6f49caccc80bed06c9800449af9eaad15dc8382`.
They then reproduced two Linux scanner failures with technical `/proc` stand-ins:
an unrelated kernel thread has a valid process group of zero; an unrelated
process name can contain non-ASCII bytes. Neither should prevent determining
membership of the strictly positive owned group. Root authorized this bounded
correction without changing the guardian lifetime or source-admission contract.

Before the fix, five new assertions failed: two full-scanner valid-record cases
and three invalid owned targets (zero, boolean, negative) that reached enumeration.
Five preservation assertions already passed: denied reads, malformed records,
non-ASCII numeric fields and oversized records reject; a disappeared entry is
ignored. The scanner now reads bounded binary records, ignores opaque command-name
bytes, and parses only ASCII digit membership fields. An unrelated group zero is
never the owned target; invalid targets fail before any OS enumeration. No process
names, identifiers or source rows are logged. These mocked Linux-path tests run
on macOS and are not a claim of actual Linux OS acceptance. The Darwin technical
process lifetime matrix and full source/API regression remain required.
