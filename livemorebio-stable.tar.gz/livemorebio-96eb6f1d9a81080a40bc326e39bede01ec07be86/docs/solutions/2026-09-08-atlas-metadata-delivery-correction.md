# Atlas diagnostic metadata-delivery barrier

2026-09-08. Proposed correction to the already approved one-skin harness, not a
product renderer or physiology change. Independent plan review precedes code.
Actual browser/service/asset execution remains unauthorized until frozen review.

Root read the full147-line maker report,535-line diagnostic script,388-line new
tests and supervisor changes. The offline runner delivers its binding callback
synchronously, but real browser bindings use separate asynchronous delivery and
acknowledgment promises. Root requested only an authored reproduction. The maker's
five probes in private `1ootgf8l` confirmed premature FUNCTIONAL_UNAVAILABLE when
valid metadata is delayed, and false collection PASS if only the final metadata
delivery rejects after an earlier RESOLVED snapshot. No real browser occurrence
or asset-transfer cause is established by those probes.

## Proposed smallest correction

Keep native fetch and original reader-load promises exactly unchanged and keep
`startSkinBrowser` returning its original task. Introduce an explicit separate,
bounded observer-delivery completion signal for the fixed private browser program.
It tracks every metadata emit acknowledgment (bounded to the existing eight-row
maximum), including the final emit after original load completion. Delivery
failures must not be swallowed into a collection PASS or misclassified as an
asset-load failure. No response/stream interception or second asset GET is allowed.

The browser evaluation may await the original task's outcome and this separate
delivery signal; this does not replace the promise returned by the reader or
fetch observer. Return only a fixed closed outcome (load succeeded boolean plus
metadata delivered boolean), never arbitrary error text. The Node runner checks
the delivery outcome before classifying the actual load. Failed delivery is the
fixed DIAGNOSTIC_OBSERVER_FAILED; successful delivery with rejected original load
remains the existing functional failure. Terminal metadata must not be discarded
merely because evaluate/Playwright/CDP completed before its delivery.

All setup, native completion, acknowledgment waits and final identity checks share
the existing90-second budget. Unsettled delivery reaches that same deadline with
partial metadata frozen before cleanup. No new timer, poll/refetch, page reload,
reader alteration, acceptance meaning or original presentation change. Preserve
five-second combined cleanup, five-second evidence writing and105-second outer
ceiling. Final `acceptance_pass` remains false.

## Red-first verification and review

Add explicit delayed-all, delayed-terminal, rejected-all, rejected-terminal and
rejected-final delivery cases to the authored runner. Include a never-settling
delivery to prove the existing deadline/partial-evidence/cleanup behavior. Keep
one original load/fetch promise identity and one skin request assertions. Do not
hide the defect by making the stand-in synchronous or ignoring the final emit.

Verify all previous209 offline cases and independent frozen source hashes,
including the unchanged product reader and ordinary presentation script. No real
browser, listener, service, cache mutation, downloaded asset or numerical worker
is authorized by these tests. Record original failures and implementation limits.
Root requested the reproduction and writes this proposal; an independent reviewer
must examine the exact intended observer-lifecycle seam before implementation.

## Independent pre-code assessment — source_research

2026-09-08. **The bounded design is clear with the following explicit lifecycle
and test requirements incorporated.** This is source/test-design review, not an
implementation grade or permission to run a browser. No tests, browser, network,
service, native worker or asset request were run by this reviewer. The complete
535-line diagnostic,388-line skin tests, original diagnostic tests,147-line maker
report and unchanged product reader were read. The engineering-plan review skill
was used for scope, ownership, failure coverage and deadline review; unavailable
CE/gbrain tools are not claimed as invoked.

### Evidence and smallest owner interface

At `check_atlas_request_diagnostic.cjs:274–288`, `publish` drops rejected emit
promises, while the terminal side observer returns the original load task. At
`:310–312`, the serialized program awaits only that task and emits a boolean.
At `:428–434`, the runner can therefore inspect an earlier or absent application
snapshot before outstanding binding acknowledgments settle. These are the exact
seams behind the two reported offline failures; no transfer cause is inferred.

One narrow local owner is sufficient; no generic observer framework or new
product state is needed. A concrete compatible internal shape is
`createSkinMetadataDelivery(emit) -> {send(value), fail(), seal(), settled}`,
where `settled` yields only a boolean. Pass that owner instead of the bare emit
callback at the existing private `startSkinBrowser` seam. Its return must remain
the exact original task, not an async wrapper or chained promise. The serialized
browser orchestration separately observes that task and `settled`. These are
private harness interfaces; native fetch, `wrapRequestFactory` and the product
reader contract do not change.

- `send` invokes the binding immediately, records every acknowledgment and
  attaches both fulfillment/rejection handlers immediately. Synchronous throws,
  rejected acknowledgments and an attempted ninth emission are sticky observer
  failures. A later successful snapshot never clears failure. No raw error,
  Response or buffer is retained by this owner.
- Positive delivery completion requires **sealed AND every registered emit
  acknowledged successfully**. Seeing pending count zero before final emission
  must not settle it. A known failure may settle false early, but all already
  issued acknowledgment promises remain handled; that is failure, never an
  assertion that pending delivery completed.
- On either original task outcome, the existing terminal observer publishes its
  final snapshot, removes the signal listener and then seals in a `finally`
  path. Snapshot/emission/disposal failure marks the owner failed. Sealing must
  happen even on those failures; it cannot erase the original task outcome.
  Preserve the current ordering in which the load observer updates RESOLVED or
  REJECTED before this final snapshot. No observer `requests.dispose()` call,
  fetch cancellation, refetch or load retry is introduced.
- Treat emission after seal as failure, not a silently ignored successful
  delivery. Preserve existing strict Node metadata sequence validation; different
  ACK settlement order alone must not lose any earlier outstanding emit. There
  is no requirement to reorder or repair invalid callback delivery sequences.

### Orchestration, failure precedence and deadlines

Use a closed result with exactly the two boolean fields `load_succeeded` and
`metadata_delivered`. Validate the result shape/types, not truthiness; malformed
outcome is `DIAGNOSTIC_OBSERVER_FAILED`. Check/raise delivery failure in the
evaluation-result branch **before** waiting for all other observation promises,
so a rejected final emit plus an outstanding CDP/Playwright terminal cannot
silently become a functional failure or wait unnecessarily for the full deadline.
This can remain inside the existing `Promise.all` by validating that member's
result before it fulfills. After successful delivery, retain the original load
failure and existing metadata/source checks and final identity fence.

A pending ACK alone consumes the existing shared90-second clock, not a fresh
delivery timeout. Deadline handling retains only metadata actually admitted by
Node before the existing freeze callback, then starts existing cleanup. Late
bindings cannot rewrite frozen evidence. Retain90/5/5/105 bounds, three collection
stages and `acceptance_pass:false`. This correction makes no new assertion that
CDP FINISHED or FAILED agrees with the application or proves transport cause.

### Required retained offline regressions

Keep the requested delayed-all/delayed-terminal, rejected-all/rejected-terminal/
rejected-final and never-ACK cases. Add precise assertions that earlier ACKs
cannot be skipped when the final ACK arrives first; synchronous emit failure,
eight-row overflow and original-load rejection retain fixed outcomes without
unhandled child rejection; known delivery failure wins while another terminal
observer is held; and deadline freeze precedes close with no late evidence
mutation. Continue asserting one exact fetch/load promise, one skin GET and zero
reader/body/cancel/dispose substitution. No new real I/O is needed for these cases.

The existing runner fixture at `test_atlas_skin_terminal_diagnostic.py:337–338`
directly calls `startSkinBrowser` and returns `true`; it does not execute the
serialized orchestration it claims to stand in for. Update that seam to execute
the actual browser-program orchestration with authored imports, or one exact
shared orchestration function used by both the serialized program and fixture.
Merely changing the stand-in to wait on a new promise would not prove production
wiring. Preserve the original209 cases and retain their earlier results rather
than describing the correction as an actual browser observation.

Reviewed frozen SHA256 values:

| File | SHA256 |
| --- | --- |
| `tools/check_atlas_request_diagnostic.cjs` | `2846b11ff8f25975bfe6e92c410598e5eb13c80f1c2866cd2343d33aa52fdb68` |
| `livemorebio/tests/test_atlas_skin_terminal_diagnostic.py` | `ccf81632fe7c5e1850ba9436a3e3f853798fe27010f539779505115e5b1f8df3` |
| `livemorebio/tests/test_atlas_request_diagnostic.py` | `674f885cbbec89f3fa992ccea81c69dcc51326b443efbf363cea5530bf79f084` |
| `tools/check_atlas_presentation.cjs` | `23b38f60e2ebee4e306ba6331f35bc10c13e0fa9a8da18e1970c3d7ee06803ac` |
| `livemorebio/aegle/console/lib/atlas_reference_requests.js` | `7ad7c023571614635d196cc5b0638d195ae46b166ce4602be16eb87e4cf4b9bc` |

The local lesson is that an observation channel has its own completion boundary:
an unchanged original promise is necessary for noninterference, but does not
prove that all evidence about that promise has been delivered. This appendix is
the bounded compound record. Root must read these precisions before authorizing
the maker; the subsequent frozen implementation still needs independent review.
