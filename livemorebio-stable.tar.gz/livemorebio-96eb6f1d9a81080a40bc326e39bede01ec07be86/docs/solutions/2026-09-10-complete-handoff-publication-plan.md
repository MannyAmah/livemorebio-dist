# Historical handoff and source publication plan

Date: 2026-09-10. User explicitly requests the full history, implementation and
failure account, product/source files and commit/push of the latest work.

## Scope and authority

This is a documentation, preservation and source-checkpoint task. It does not
authorize new biological experiments, changed model outputs, deletion of prior
work, production deployment or declaring unqualified biology complete. The new
explicit publication request permits a research checkpoint on a feature branch
and draft pull request, while the earlier full-product acceptance requirements
remain open. No direct main push, force-push or automatic merge.

The founder's objective must remain prominent: a full living biological human
replica, every twin individualized; a purpose-built physical LIFE Patch and its
virtual hardware/software counterpart; and a physical Cendos wet lab connected
to the twin infrastructure. No scripted outcomes, invented observations or
substitution of reference pictures for functional biology. This is the target
specification, not a claim that current software has achieved it.

## Work sequence

1. Read governing instructions, preserved plans/evidence, original user scope,
   git history, and relevant source. Reconcile rather than rewrite old receipts.
2. Independently audit experiment history, implementation/source inventory and
   publication risks in parallel. Record unavailable sources and uncertainties.
3. Write a master handoff with linked appendices: products/logic, chronology,
   resources/tools, rejected/deferred tools, all identified experiments/failures,
   current capabilities/gaps, reproduction and next steps.
4. Generate an exact file/source inventory and a local full-code source archive
   from the eventual committed tree. Do not include secrets, private participant
   data, runtime stores, build caches or unapproved restricted third-party assets.
   Index external supplied files separately without asserting redistribution rights.
5. Independently review the handoff for omissions and claims; verify links,
   inventory completeness, current-source regression and git hygiene. Preserve
   skipped/failed evidence as such. No new product functionality is planned.
6. Commit scoped existing recovery code/tests, evidence and handoff in coherent
   chunks, push the feature branch and create/update a draft PR. Record exact
   commits and exclusions. Do not bump a product release or imply readiness.

## Acceptance

Deliver the handoff and all appendices, exact accessible code/source location,
videos/deck/guides, actual GitHub result and a transparent list of missing or
restricted material. Historical intent, implemented code, observed execution,
scientific qualification and physical validation must remain distinguishable.

## Workflow availability

Documentation and shipping skills selected. Local docs/solutions searched first.
The current tool inventory has no gbrain, sequential-thinking or Compound
Engineering invocation tools; record equivalent local review/lesson artifacts,
not invented successful calls. No new biological behavior or UI design is made.
