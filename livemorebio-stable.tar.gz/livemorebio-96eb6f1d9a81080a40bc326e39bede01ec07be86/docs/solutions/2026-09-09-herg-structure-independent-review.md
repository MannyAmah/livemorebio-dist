# Independent hERG static-reference review

2026-09-09. **CLEAR for the bounded catalog/coordinate addition only.** No
blocking source, identity, preservation or reader finding. This does not qualify
the alternate viewer, a tetramer reconstruction, channel execution, ligand
effects, individual variants or a clinical model. No runtime file was edited by
the reviewer and no browser, service, network, solver or biological model ran.

## Source and preservation

Read the complete admission plan, 102-line reader, new 46-line test, existing
210-line reader tests and 189-line route tests; inspected the actual route,
descriptor-validation and consumer boundaries. The review checklist was used
within the explicitly read-only assignment, not as permission to modify or
ship the work. CE/gbrain were unavailable; no such tool execution is claimed.

The package `5VA2.cif` is exactly the retained original: 493,914 bytes, SHA256
`734a6214f786327140ceb33a7bfd8dde0fbda3382862f6fb2c709e1b45bf3e7e`.
The source staging root is `/tmp/livemore-herg-source.6dcBBG`:

| Original | SHA256 |
|---|---|
| `entry.json` | `188687ef74819909701fa3ce9b7c40b85738e3484debde0d962979be5c1e7d3c` |
| `entity.json` | `692d0ffde4d1bd5ed7c26301a9c262cfa150e489ea62ac703286b4a22ce8c7dc` |

Independent static source counting by the review child, cross-checked against
the original entry metadata, establishes 4,394 atom-site rows, zero H/D rows,
one model numbered 1, and one label/auth chain A:A. There are 825 deposited
construct sequence rows, 558 distinct modeled label residues and 267 unobserved
residues. This is an engineered human KCNH2/hERG construct associated with
UniProt Q12809, not the complete protein. Source taxonomy is Homo sapiens/9606;
the source identifies `truncation hERGTs`, human HEK293S GnTI- expression and an
11-residue expression tag. The method, 3.8 Å resolution and revision 1.4 dated
2024-03-13 match the retained originals. No source data were reacquired.

The source's inconsistent numbering is **not reconciled**:

- `_entity.pdbx_fragment` says 1–140, 381–870, 1006–1159.
- `_struct_ref_seq` uses database spans 1–140, 351–870, 1006–1159;
  sample spans 1–140, 141–660, 661–814; author spans 1–350, 351–870,
  871–1024. The unusual first author span is present in the original, not a
  catalog invention.
- The retained augmented SIFTS entry instead gives one 814-residue alignment
  from entity position 1 to reference position 1. It is not admitted as a
  variant/residue-equivalence map. The catalog leaves `sifts_alignments` empty,
  preserves deposited spans and all 11 expression-tag differences, and marks
  `UNRECONCILED_SOURCE_NAMESPACES` with an explicit limitation.

The raw CIF contains assembly operators for a tetramer. The admitted descriptor
selects deposited model 1/index 0 with **no assembly expansion**. Its wording
does not confuse the one-chain coordinate file with a complete channel.
CC0 is scoped to original archive coordinates, not all augmented annotations.

Compared with `/tmp/livemore-molecular-metadata.nBet7P/catalog.json`, all six
existing structure descriptors are deeply equal and all six original CIFs are
byte-identical. The only changed target is KCNH2; all 27 target keys remain.
The only other top-level change is the declared catalog revision. In-memory
inverse-delta hash checks (not fabricated retained originals) show:

- Reversing only the reader's catalog digest/length recovers historical SHA
  `b1f8533211b63eaa74ca279fd475ad4aab701a3ad30090892e382572a6cf7296`.
- Reversing the four explicit inherited test additions/count updates recovers
  `0cdb3b0de52f9179ab8ae0bfa88b2d4b9473add18aef1451d8fdc2c3c06d09ad`.

Thus the verifier and original test meanings were preserved. Missing/corrupt/
oversized/linked catalog or coordinates still fail closed; unknown and
ambiguous targets still do not initiate discovery. Package-data patterns cover
the added CIF. No installed-wheel or new API integration execution is claimed.

## Independent repeat

Tool receipt `8c4bc4`, exit 0, private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-0v308nq4`:

```text
51 passed in 0.26s
REVIEW_IO_COUNTS {'unexpected_io': 0, 'git_refused': 1}
```

The optional Git metadata lookup was refused, not executed. This is the
maker's exact two-file selection with additional private-environment, deadline,
network, dynamic-library and process refusals. Complete repeat command, from
the full-scope-recovery worktree:

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os, signal, socket, subprocess, sys, urllib.request, ctypes
from tools.run_review_stack import prepare_review_environment
root, env = prepare_review_environment(inherited={k: os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ})
os.environ.clear(); os.environ.update(env); os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError('OFFLINE_DEADLINE'))); signal.alarm(45)
import pytest
counts={'unexpected_io':0, 'git_refused':0}
def deny(*a, **k):
 counts['unexpected_io'] += 1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.socket.bind=socket.socket.listen=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
expected_git=['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']
def run(cmd,*a,**k):
 if cmd==expected_git:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run; subprocess.Popen=deny
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system','subprocess.Popen','ctypes.dlopen'} else None)
print('PRIVATE_REVIEW_ROOT',root,flush=True)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=short','livemorebio/tests/test_herg_structure_reference.py','livemorebio/tests/test_molecular_reference.py'])
print('REVIEW_IO_COUNTS',counts,flush=True)
raise SystemExit(status)
PY
```

Frozen reviewed identities:

| File | SHA256 |
|---|---|
| `molecular_reference.py` | `4a9309988ab62a5b479a13dcf00c56b72980d92303dc29e43d2564dcabeca15c` |
| `catalog.json` (67,867 bytes) | `1ce5cd1c67a9bf33d2f2b2f2942adb02b1608743186074279262fac110584032` |
| `test_herg_structure_reference.py` | `4bc65bf28fa23f81b14ef8a5548e5bdfe688f0bc88eef2a35ee1e4c7f32ceaf6` |
| `test_molecular_reference.py` | `18421250beca34e718964d6b370facfd514d3ab7de84db3c1a7a60395beca22b` |

The maker's earlier two failing tests and 51-pass receipt remain separate
historical evidence. This clearance changes no scientific, hardware or viewer
gate. Lesson: admitting an exact useful structure need not invent a complete
protein, assembly, numbering equivalence or executable biological mechanism.
