# Molecular dependency notices — independent assigned-slice review

2026-09-09. Read-only original-notice review for the local Biology viewer
dependency gate. No archive/package code, install, build, browser, service,
native program or network request was executed. No retained input was modified.
This is technical notice evidence, not emitted-bundle or legal clearance.

## Exact coverage and method

Reviewed exactly rights-index `review_index` **36–196 and198–223 inclusive**:
187 unique original notice blobs,205,934 bytes,385 source-notice mappings across
384 distinct package/version pairs. The difference is Molstar's separate full
license and bundled-comment notice. Source_research separately owns0–35 and197,
missing-notice/native/npm and remaining archive/build questions.

Retained root: `/private/tmp/livemore-molecular-archives-final.dKZYOa`.

| Input | SHA256 |
|---|---|
| rights-index.json | 320d17cc559495ac40c287cc1955221616031a2f75a79f12b90b8ed4e16a9846 |
| mit-review-groups.json | 2c3ca9e7c0cb9bc1b64e9b6a0ead9c565b3c934590f62eff92001668c46b466c |

Independently read every selected original blob and verified its exact byte
length and SHA against rights-index. Verified that each original equals the
retained variable header plus its exact common suffix, with no whitespace,
newline, case, punctuation or Unicode normalization. Every group suffix SHA
was recomputed. Group membership is disjoint and exactly covers the assigned
187 indexes; all187 header hashes/group bindings match the originals.

Personally read the full original representative notice for each of31 groups:
36,37,38,39,41,42,43,44,46,58,61,66,67,69,76,80,83,84,86,97,104,106,109,113,
117,141,152,163,164,183,223. Then read all187 variable headers and every mapped
package/version/member attribution, including those sharing one original hash.
The input mappings retain exact affected packages and versions; this review
does not substitute the group's representative package for its other members.

The comparison artifacts' labels were not used as evidence of license content.
For example, group27/index163 has an empty header and its entire comment-only
notice as body; it is **not** a full MIT grant merely because the group file
is called mit-review-groups.

## Conditions and differences

The186 other original notices include the MIT permission grant, retention of
the copyright and permission notice in copies/substantial portions, and the
warranty/liability disclaimer. The30 full-license body variants preserve that
condition. Most differences are line wrapping, LF/CRLF, indentation, quoting,
final newline or punctuation. Keep the exact original notices and each
distinct attribution rather than replacing them with one generic MIT label.

Specific evidence that must survive packaging:

| Review index | Package/member | Evidence and consequence |
|---|---|---|
| 163 | molstar4.4.0, build/viewer/molstar.js.LICENSE.txt | Abbreviated safe-buffer comment and four React-family comments referring to their source-tree LICENSE. It contains no complete permission condition/disclaimer. This file alone does not establish distribution notice completeness or the exact old bundle's component versions. |
| 150 | react18.3.1, react-dom18.3.1, scheduler0.23.2, jest-worker27.5.1 LICENSE | Full MIT notice with Facebook, Inc. and affiliates copyright is retained. Its presence does not attest that the prebuilt Molstar bundle contains these exact versions. |
| 195 | safe-buffer5.2.1 LICENSE | Full Feross Aboukhadijeh MIT notice is retained; same version-identity limitation applies to the old bundle. |
| 164 | molstar4.4.0 LICENSE | Full MIT notice, copyright2017–now Mol* contributors. Do not replace the third-party notices with this Molstar-only attribution. |
| 152 | json-parse-even-better-errors2.3.1 LICENSE.md | Retain both Kat Marchán and npm, Inc. copyrights, plus the appended statement identifying the better-json-errors fork and its MIT terms. No additional restriction was found in that appended text. |
| 169 | neo-async2.6.2 LICENSE | Retain Suguru Motegi2014–2018 and the Async.js/Caolan McMahon attribution, not only the first copyright line. |
| 44 | acorn8.18.0 LICENSE | Copyright is to various contributors and explicitly references AUTHORS. Preserve that notice and its authorship association; this slice did not inspect the separate AUTHORS member. |
| 123 | h264-mp4-encoder1.0.12 LICENSE.md | Full Trevor Sundberg2020 MIT notice is present. It does not resolve embedded/native encoder or MP4-library notices; those remain the separately assigned review, not a MIT-only conclusion. |
| 116 | fsevents2.3.3 LICENSE | Full Philipp Dunkel/Ben Noordhuis/Elan Shankar/Paul Miller MIT notice is present. This is not permission to load its native artifact or a native/build attestation. |
| 185 | range-parser1.2.1 LICENSE | Original Douglas Christopher Wilson email lacks its closing angle bracket. Preserve the original; do not silently rewrite attribution during grouping. |
| 222 | wildcard2.0.1 LICENSE | Original attribution includes literal HTML entities around the email. Preserve original text; a rendered representation must not lose it. |

Other multi-author/year/version variations were read, including Microsoft
Corporation type-package notices, JS Foundation/contributors, distinct debug2/4
copyrights, distinct ms2.0.0 Zeit and2.1.3 Vercel notices, and all Titus Wormer,
Inspect JS, ECMAScript Shims, Jordan Harband and source-specific attributions.
The retained index and header map bind their full exact text to all affected
packages; no authors were dropped by this review's common-body comparison.

Exact exception original hashes:

- 163: b25a1f014ffbc8707b53a424392a5729b4adc6cb5911925359f6bad765504003.
- 152: 50627796eb4236cd05674e71d090e594447995225b7d94cd59e57c25fa3a0217.
- 169: 811238ba7d85f6fe6b820703a32f92705bcf77bc352ddc3476783491c64a129a.
- 123: 05f71440b962f294ffdced18c6e77437f59c7bd7cdf0bf69dc1ec0c918065cae.

## Reproducible read-only byte check

This verifies the retained comparison's exact coverage, not interpretation of
the license terms. The original representative bodies and variable headers
were separately read in this review's tool outputs.

```python
import hashlib, json
from pathlib import Path
root = Path('/private/tmp/livemore-molecular-archives-final.dKZYOa')
index = json.loads((root / 'rights-index.json').read_bytes())
groups = json.loads((root / 'mit-review-groups.json').read_bytes())
notices = {n['review_index']: n for n in index['notices']}
headers = {h['index']: h for h in groups['headers']}
selected = set(range(36, 197)) | set(range(198, 224))
covered, total, sources = [], 0, []
assert len(headers) == len(groups['headers']) == 187
for group in groups['groups']:
    body = group['body'].encode('utf8')
    assert hashlib.sha256(body).hexdigest() == group['sha256']
    for i in group['members']:
        assert i in selected
        n, h = notices[i], headers[i]
        path = Path(n['path'])
        assert path.is_relative_to(root)
        raw = path.read_bytes()
        assert len(raw) == n['bytes']
        assert hashlib.sha256(raw).hexdigest() == n['sha256']
        assert h['header'].encode('utf8') + body == raw
        assert h['group'] == group['group']
        assert h['full_sha256'] == n['sha256']
        covered.append(i)
        total += len(raw)
        sources.extend(n['sources'])
assert len(covered) == len(set(covered)) == 187 and set(covered) == selected
assert total == 205934 and len(sources) == 385
assert len({(s['name'], s['version']) for s in sources}) == 384
```

The first exploratory comparison assumed a header field named review_index
instead of index; a second assumed every body began with the permission phrase
and stopped at163. Both read-only attempts failed visibly before coverage could
be claimed. The final reconstruction method above explicitly handles the full
comment-only163 original and passed without normalization or skipped entries.

## Bounded disposition

Assigned notice-text review is complete with the conditions above. No new
restriction beyond the full MIT notice retention condition was found in the
186 full notices, but163 cannot close old-bundle redistribution completeness.
No npm install/build or emitted dependency graph was inspected here. Keep the
remaining notice/native/npm and emitted-asset identity gates open until their
separate evidence is reviewed. This report does not clear a whole dependency
archive merely from its package.json label or authorize packaging execution.

Lesson: exact common-body comparison is a legitimate way to avoid repeatedly
reading identical text only when every variable attribution and the complete
remaining body are retained and independently bound to the original bytes.
Abbreviated bundled comments are not interchangeable with a full license.
