# Closed-manager source fence correction

Status: proposed, independent engineering review required before implementation.
Scope: R01–R51 recovery continuation; this corrects the activation P1 without
changing scientific equations, data, source rights, experiments, or UI design.

## Reproduced failure

The independent activation report retains a failing real-manager/no-I/O probe.
A failed explicit shutdown retains a closed manager and its unresolved owner.
Activation receives a committed registry acknowledgment, then the manager's
source-fence setter rejects the assignment because the manager is closed. The old
state and generation remain visible despite the acknowledged different selection.
The 31 passing activation tests did not cover this real collaborator lifecycle.

## Decision proposed for independent review

Separate source-fence bookkeeping from permission to execute. Make the existing
`ExecutionManager.set_source_generation` honor its documented assignment-only
contract even when that manager is closed. Keep generation validation, its lock,
the permitted-generation assignment, and schedule clearing. Remove only the
execution-open prerequisite from this bookkeeping operation. No manager is
reopened; no owner is detached; no cleanup is bypassed or treated as successful.
All prepare/start/resume/advance/observation and ownership checks stay unchanged.

The same authority → creation → manager guard continues to exclude concurrent
manager replacement and source changes during commit/publication. This is not a
new unguarded setter or a fallback swallowing an exception. Both a confirmed new
generation and DENY_ALL must be assignable to a retained closed manager. The
manager remains closed before and after either assignment. Post-publication
invalidation can still report cleanup unconfirmed, retaining the explicit 503
cleanup response and ownership for a subsequent explicit shutdown retry.

Alternative considered: preflight `_open()` under the final commit guard. This
can reject activation before its database write, but does not supply the needed
deny-all bookkeeping after an independent uncertain read/startup failure. It also
conflates source identity with permission to run a closed executor. An actual
execution admission check still belongs on execution, where it already exists.
If independent review rejects the proposed separation, revise this plan before
runtime changes; do not silently adopt another behavior.

## Red-first verification

Use the real no-background manager and actual authority/server collaborators;
authored stores/registry/candidate only, no model execution or native work.

1. Reproduce a retained failed shutdown before activation and during candidate
   preparation. Test committed, committed-cleanup-unconfirmed, and commit-uncertain
   acknowledgments. New identity must be coherent for confirmed outcomes; DENY_ALL
   must block state/numerical access for uncertain outcomes. No old-state exposure
   after a commit. No retries, owner detachment, or reopening.
2. Test assignment of a valid generation and DENY_ALL on closed managers while all
   store and adapter methods are traps. The method must make no I/O, preserve
   owners/adapters/cleanup flags, clear scheduling, and retain `_closed=True`.
3. Preserve strict invalid-value refusal and closed producer rejection. Explicit
   shutdown retry must remain the only way to complete retained shutdown cleanup.
4. Preserve the existing activation 31-case packet and separately repeat relevant
   source-fence/cleanup/authority tests with only authored adapters. Any test that
   actually launches a native worker remains outside this inert verification.

Inspect callbacks/destructors around assignments; do not introduce arbitrary
callback cleanup under authority/creation/manager locks. Source generations are
validated scalar strings or the singleton DENY_ALL; scheduled deadlines are
internal scalar values. Manager state/owner/adapter collections are not replaced.

## Acceptance and non-claims

Independent implementation review and exact test repeat are mandatory. This is a
software ownership correction, not human-equivalence validation, a completed
experiment, whole-product acceptance, a release, or a reason to omit other work.
Keep the original failure receipt immutable. Capture outcome and lesson here.

## Independent engineering-plan clearance

2026-09-08, `source_research`. **Approve the bounded plan above for red-first
implementation**, not runtime acceptance. The engineering-plan review skill was
applied to architecture, code boundaries, failure coverage and performance.
Read the complete proposal and independent activation P1 append, real
ExecutionManager setter/close/prepare/fork/start/resume/advance/late-result and
consumer paths, ModelSourceAuthority and the server creation/commit guards.
No runtime edit, test run, service or native invocation occurred in this review.

Existing code already supplies the three-lock commit guard, generation checks,
closed execution admission, late-result rejection and retained cleanup ownership.
Reusing those mechanisms and removing only the setter's `_open()` is the smallest
complete correction. It does not reopen `_closed`, release owners/adapters or
change successful shutdown requirements. No new service, callback framework,
distribution artifact or numerical behavior is needed. Preflight-only activation
rejection cannot satisfy the independent startup DENY_ALL obligation.

Required startup test precision, in addition to the activation matrix:

```text
retained closed manager (before entry / during unlocked preparation)
  + uncertain checked startup read
  -> same final guard: authority DENY_ALL + manager DENY_ALL
  -> initialized fail-closed state; static app available
  -> state/numerical/current-source observation access blocked
  -> no old-source or healthy fallback, reopening or owner detachment
```

Preserve the winning operator when generation/initialized ownership changes.
Confirmed activation must retain coherent new identity even if subsequent
`invalidate_source` rejects a closed manager and produces the existing explicit
cleanup-unconfirmed503. Failed cleanup remains pending for an explicit shutdown
retry. The setter-only I/O traps must not invent a new pre-I/O rejection ordering
for unrelated methods: start/bind currently read the store before their closed
check, while still refusing execution. This review does not claim every direct
observation helper independently checks `_closed`; product observation admission
also relies on its existing caller-owned current source authority.

Architecture/code/performance review found no further material blocker in this
scope. The diagram above identifies the required cross-collaborator regression;
the proposed real-manager tests are necessary because permissive fence doubles
missed the original P1. Implementation remains sequential in the same source
ownership lane; no additional parallel runtime maker is appropriate.

Not in scope: reopening/cleanup redesign, changing native/store admission,
repairing unrelated unchecked callers, clinical or model qualification, browser
acceptance or release. Independent implementation review and the named inert
preservation repeat remain mandatory. The lesson is to keep deny-all identity
bookkeeping available when execution has irreversibly closed, without weakening
the separate proof required to release its resources.
