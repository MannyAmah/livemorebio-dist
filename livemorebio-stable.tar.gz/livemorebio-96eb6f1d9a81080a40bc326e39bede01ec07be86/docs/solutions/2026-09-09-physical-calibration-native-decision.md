# Physical calibration form: exact native browser decision

Root read the complete269-line harness plan/report, all262 new test lines and
all changed CJS/Python paths. Independent combined239 tests passed20.33s,
session98858/privatew50n7b05, unexpected I/O0/Node196/refused Git1. Pre/post
hashes match Python4edfbf6898609aa35f234944074b0671df24306f2ad2a177eca7a3bd1c9f946c,
CJS7a4838e9144fdf6efc5c5ceba93943a03bea3030ad884aeafcb749232e4870fb,
test0ff2b47372178540ee42a15db2409e25dbd813b69824446a8b726e2afea22c5c.
The two additional legacy static imports preserve the actual current import
closure; they do not permit vendor or coordinate requests in this check.

Authorize one fresh owned physical-calibration browser invocation at package
source1e3516cbd12ac304e3f47b4325ae39f46ad969c7336abcd72bfb8ecbfcd1d99f.
Use only the prepared isolated three services/technical record, exact four-image
desktop/mobile flow and zero-POST route guard. No existing installed service,
old store, real participant or physical hardware is used or changed. All original
failed and accepted legacy runs remain preserved. Do not automatically retry a
failure or describe this as complete physical-v3 or biological validation.

Native focus, validity, visible feedback and all four original screenshots must
be inspected after the run. Technical test success alone is not visual acceptance.

## Actual result — first attempt failed D1

Session30942 /private/tmp/livemore-legacy-preview-mgjbj3fk exited1 in11.418255s.
Root read both complete receipts and inspected desktop-open and failure-D1
originals. D0 passed; native blank validation focused calibration with invalid1,
submit0. The first keyboard choice remained OTHER/blank; D1 failed, M0/M1 NOT_RUN.
No POST or actual mutation occurred. This is neither four-image acceptance nor
physical calibration validation. The native dropdown commit assumption requires
correction; the blank feedback strip and clipped placeholder are separate visible
defects. Original failed receipts/images remain unchanged.

Browser receipt page-close was UNCONFIRMED after3002.584ms; subsequent context
and browser close settled. Supervisor reaped all four children and observed all
nine descendants absent/no listeners. Root's separate targeted process inspection
confirmed all13 PIDs absent and no listeners on8910–8912. Later cleanup evidence
does not rewrite the original page-close uncertainty.
