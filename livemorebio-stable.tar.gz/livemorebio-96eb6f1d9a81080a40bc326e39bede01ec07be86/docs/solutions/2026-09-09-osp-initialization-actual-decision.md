# OSP initialization successor: one technical execution decision

Root decision, 2026-09-09, before execution. Continue the approved R01–R51 plan;
this does not authorize a scientific insulin experiment or publication.

Root read the entire predecessor launcher, exact successor delta, all 37 new
tests, the two inherited-fixture changes and the refusal wrapper. Independent
repeat `778099` passed all 109 tests in 0.90 s, unexpected I/O zero. The underlying
initialization-contract source was separately cleared by 656 independent offline
passes. Final data-only check `5c302d` matched all 22 listed source, runtime,
launcher/test and preserved predecessor hashes. Its 12 non-checksum listing lines
were not checksum inputs; none of the listed hashes failed.

The latest browser run has closed: all four owned closes settled, leader 57345
reaped, no listeners/remaining descendants. Root exact-PID postcheck `9f6560`
found none of its twelve owned PIDs. No concurrent browser or native run is
authorized during this packet.

Authorize exactly one invocation of the frozen launcher
`/private/tmp/livemore-osp-native-once-initialization.oWpRO1/run_packet_once.py`,
SHA-256 `58fe279b9a5ce21fc1f2b8fdbb06391ecf7065b7952146738bc3a48a27d6a8bf`,
using the fully resolved isolated command in the successor plan. Bind the seven
pinned inputs and launcher in one canonical OSP_NATIVE_ONCE_AUTH_V1 file. Keep
S01–S17, 16 Run calls, first-failure stop, 30-second worker/600-second packet
limits and all other existing resource/ownership limits unchanged. Never retry
this consumed root. Source gates remain false; only this launcher's scoped
in-memory gates may be true during the invocation and are restored afterward.

Historical Yc5Y4i OS evidence is accepted only for unchanged native ABI,
ownership and cleanup mechanisms. It is NOT a fresh OS preflight, NOT evidence
for the new initializer, and its obsolete unchanged-classifier rationale is not
adopted. The new initializer is supported by current source/offline review and
must still pass actual handoff inspection. Do not invoke the old preflight driver.

After execution, inspect the original packet, reached/not-run cases, ready/ACK
handoffs, pending paths, exact input preservation, returned/on-disk agreement and
owned cleanup. Obtain independent data-only review. A technical pass would not
qualify source physiology or establish equivalence to a human. Preserve any
failure unchanged. No production services, participant stores, physical device
commands, clinical actions, commit, push or publication are in scope.

## Actual result and independent data review: FAILED

Invocation `a17b43`, terminal result `312ced`, exit 1. Completion elapsed
1.400588958 s; packet elapsed 1.389117500 s. Original packet:
`/private/tmp/livemore-osp-native-once-initialization.oWpRO1/tmp/livemore-osp-semantic-qj_2vx9i`.

S01 acknowledged initialization-ready and initialization-ACK, and completed
STARTUP_BEGIN / STARTUP_END around `dotnet --list-runtimes` with status zero.
It then FAILED with EVIDENCE_FILE_TYPE; no PRE_XML, comparison, observation or
collector-cleanup receipt was reached. S02–S17 are NOT_RUN. This does not establish
completed CLR initialization or a biological response. Model admission is false.

Root read the original packet and both handoffs; data-only independent review
`21b143` checked exact schemas, bytes, file identities, request/ACK pairs, streams,
admission/configuration identities, original/embedded S01 equality and all 22
frozen hashes. No pending handoff aliases remain. Root rehashed originals:

- Completion: `eba7c0c4b1561b0b24753e4c44452ec633e0912fd5e7dfb537a30a15a756a430`.
- Packet: `fc7e59e26396f94bc880b9f9ff4376c6e32ac570777c5a102d7b56e4326ab66f`.
- Ready, 255 bytes: `dc30e8b8e9f68cf429f7892f0b4eaf17ac0745b63d5c4bdfb028f91c455489f1`.
- ACK, 275 bytes: `e4d601b15eff8d9ec7f4339172410dba7550680cf9c4ba8ea41acc44c8a79d89`.

Cleanup settled, TERM sent, no KILL, exit 143, group empty before reap. Root
postcheck `9fd150` found none of PIDs 58038, 58047, 58054, 58055. Sources and both
historical failed packets are unchanged. No retry was performed.

## Investigation and escalation boundary

The directory walker accepts directories recursively; its failure predicate
rejects a leaf that is not a regular file. The actual rejected leaf's path/type
was not retained. After cleanup the 17-entry packet tree contains 16,978 regular
file bytes and no special leaf. A transient runtime scratch entry or entry-type
race is a hypothesis, not a proven cause. No socket, directory or library is
retroactively named as the culprit, and no file-type protection is relaxed.

This is the third failed native path. Under the investigation workflow, further
native attempts stop pending explicit user direction. The recommendation is to
review the scratch/evidence boundary and retain bounded rejected-entry metadata
before any further attempt, not to keep trying the same packet. Other approved
product corrections can proceed independently. All six experiment recordings
remain open; this packet is not an experiment recording or scientific pass.
