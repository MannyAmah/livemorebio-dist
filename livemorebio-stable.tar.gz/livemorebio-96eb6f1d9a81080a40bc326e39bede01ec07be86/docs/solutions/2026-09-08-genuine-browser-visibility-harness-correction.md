# Genuine browser visibility: harness correction

2026-09-08. Pre-code proposal following an independent `/investigate` pass.
Root review/approval is required before implementation. Scope is the owned
engineering browser harness and its tests only, not product visibility logic,
services, physiological behavior or a new release claim.

## Symptom and causal evidence

Root's continuous acceptance attempts 2 (headless) and 3 (headed) reached the
hidden/visible stage after successful pause/resume but timed out waiting for
`document.hidden`. Preserve both failure receipts and screenshots unchanged.
Those failures are not evidence that the product's visibility handler failed:
the automation browser did not produce the required native visibility change.

The installed Playwright main-frame initialization explicitly sends
`Emulation.setFocusEmulationEnabled({enabled: true})` from its own CDP session
at `playwright-core/lib/server/chromium/crPage.js:412`.

Independent proof used fresh, owned headed Chrome and two `about:blank` pages.
No product page, control, store, user browser/profile, shared gstack state,
document-property override or manually dispatched event was used. Each launched
browser was closed in an outer `finally` block.

| Probe | Actual observation |
| --- | --- |
| Default Playwright; bring second page forward | Both pages visible and focused; both belong to native window 700469764. |
| Set focus emulation false on separate `newCDPSession` sessions, retain both sessions, then switch tabs | Focus tracks the front tab, but both documents remain visible and emit no visibility events. Separate-session detachment is not the cause. |
| Set focus emulation false on Playwright's original session for both pages, then bring second page forward | First page: hidden=true, visibility=hidden, focus=false. Second: hidden=false, visibility=visible, focus=true. |
| Bring first page forward again | First becomes visible/focused; second becomes hidden/unfocused. All recorded visibilitychange events have `isTrusted=true`. |

The successful original-session probe produced the following read-only result:

```json
{"front":"second","first":{"hidden":true,"visibility":"hidden","focus":false},"second":{"hidden":false,"visibility":"visible","focus":true},"visibility_events_trusted":true}
{"front":"first","first":{"hidden":false,"visibility":"visible","focus":true},"second":{"hidden":true,"visibility":"hidden","focus":false},"visibility_events_trusted":true}
```

Raw stdout is retained in the investigation tool transcript (successful probe
chunk `26ed2c`), not claimed as a separately saved local log. One earlier probe
used the wrong private property `_delegate`, threw TypeError before sending the
command, and closed its owned browser. Reading the installed source established
the correct property, `delegate`. This was a diagnostic accessor error, not a
third failed visibility hypothesis or a product failure.

Conclusion: the original Playwright session's emulation must be disabled.
Changing only a separate session affects focus but does not remove the original
session's visibility override. No launch-flag removal or native window trick is
needed for the proved headed configuration.

## Exact observed runtime and adapter

- Node: `/opt/homebrew/bin/node`.
- Playwright entry: `/Users/emman/.agents/skills/gstack/node_modules/playwright/index.js`.
- `playwright` and `playwright-core`: **1.58.2**, both checked independently.
- Installed Chrome bundle version: **152.0.7977.76**. The proof used
  `channel: 'chrome', headless: false` with the existing SwiftShader flags.
- `playwright-core/lib/server/chromium/crPage.js` SHA-256:
  `08f14f9abc4bde5b36a0679889de05e8c3c0ebbf7e15c3bafc3639830e01c174`.
- `playwright-core/lib/inProcessFactory.js` SHA-256:
  `406a2ce0e50bf6c695a0fa018ac3dec505b60836710bbab797e11730c51917cc`.

The observed original-session access path is:

```javascript
const implementation = page._connection.toImpl(page);
const session = implementation.delegate._mainFrameSession._client;
await session.send('Emulation.setFocusEmulationEnabled', {enabled: false});
```

This is an internal testing API, not a supported product dependency. Do not
export it to console code, change installed Playwright files, or assume future
versions preserve it. Pin both package versions and source-file hashes before
launch; require the expected object/function shape, the page's exact owned
context/browser, and `implementation.delegate._page === implementation` before
sending. Missing/mismatched pins, unsupported in-process mapping or a rejected
command stop the harness before any product mutation. Never fall back to a
new CDP session, forced visibility value or fake event.

## Smallest correction and acceptance packet

1. Add a narrowly named helper in `tools/check_continuous_browser.cjs`, with no
   product imports or edits. Resolve pins relative to the explicit loaded module;
   validate package/source bytes before launching the existing owned browser.
   Keep the current outer browser-finally ownership and build/process fences.
   Use headed mode for this acceptance because that is the independently proved
   native-window configuration; headless visibility acceptance remains unproved.
2. Before navigating to product pages or issuing any product mutation, create
   two owned blank pages and disable only their original-session focus override
   with `enabled:false`. Install listeners that merely record browser-generated
   visibility events. Switch tabs via `bringToFront`, require hidden and visible
   states plus trusted events in both directions within a bounded deadline, and
   leave the primary page visible. Assert both pages are in the same native
   window. Close the spare page in `finally`. No document.hidden override,
   `dispatchEvent`, lifecycle-state emulation or synthetic event is permitted.
3. Disable the same override for the later owned spare tab used by the actual
   continuous hidden-stage check. Check the primary page's original session
   again after navigation. Preserve existing assertions: hidden view stops frame
   polling; independently running producer/LIFE services continue; returning
   visible refreshes the same source. Do not weaken deadlines or count preflight
   as evidence that the active continuous workflow passed.
4. Record package/source pins, actual browser version, native visibility states,
   trusted-event counts and preflight outcome in the new attempt receipt. Do not
   log cookie/token values or clinical data. Preserve attempts 1–3 and use a new
   output directory for the corrected workflow.
5. Red-first harness tests must reject either version/hash mismatch before
   launch, wrong owned context, missing private API shape, command failure,
   missing/untrusted transition events and visibility timeout before the first
   product mutation. Prove `false` is the only emulation command payload, the
   original session is used, and owned pages/browser close on every failure.
   Retain all existing build identity, ID capture, control revision and cleanup
   tests. Then independently repeat the real blank-page preflight and the full
   current-source continuous browser workflow; unit mocks are not its acceptance.

No harness or product implementation was changed by this investigation. The
root cause is demonstrated; correction, independent grading and the successful
full workflow remain pending. The reusable lesson is to distinguish focus from
visibility and to inspect the session that owns an automation override before
changing application logic or manufacturing browser events.

## Root correction record

Root read and approved this packet before implementation. Three new guard tests
failed before the helper existed (five preservation tests passed). After the
narrow harness correction, **8 tests passed in 0.62 s**. The hidden-state waits
use timer polling because request-frame callbacks may be suspended in a genuinely
hidden document. This changes observation scheduling, not browser visibility.
Version/hash checks precede browser launch; the native two-tab preflight precedes
any product navigation. No product code or installed browser library changed.
Independent helper/preflight review and a new complete workflow attempt are
still required; attempts 1–3 remain failed and preserved.

Independent UI reviewer subsequently read the complete implementation/tests and
owning browser-session source. Eight tests passed in 0.59 s. Its owned headed
Chrome 152.0.7977.76 preflight produced trusted hidden/visible transitions in
both directions, one native window and zero network requests; spare page and
browser closed. Separate orchestration probes rejected all four pin mismatches
and headed=false before launch or directory creation, and rejected preflight
timeout after only two blank-page navigations with no product calls or owned
record IDs. Root accepted this bounded correction and launched full attempt 4
against the unchanged three-service source fingerprint 462b8cd44633cfad….
