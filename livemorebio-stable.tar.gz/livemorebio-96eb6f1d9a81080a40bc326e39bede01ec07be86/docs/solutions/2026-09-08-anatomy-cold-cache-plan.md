# Anatomy cold-cache acquisition correction

Part of R03/R22/R43/R46/R48; full recovery scope is unchanged.

Actual isolated-browser inspection fetched six HRA meshes, then the 136 MiB
BodyParts3D archive for the quadriceps. The seventh mesh became available after
several minutes. Current code gives concurrent page requests the same `.part`
and provenance `.tmp` filenames without an acquisition lock; simultaneous first
loads can overwrite or remove another request's temporary file. Cached files are
also trusted without comparing the declared digest. Fix these cache mechanics,
not the scientific geometry or its identity.

Plan: red concurrent-acquisition, corrupt-cache and safe-error tests; one bounded
per-asset acquisition lock plus a separate archive lock; private unique download
temporaries; atomic final publication; validate cached digest and catalog binding.
An acquiring asset returns a retryable response rather than starting another
136 MiB download. Preserve the old valid cache on download failure. Never erase
the cache, substitute geometry, expose exception paths, or claim a partially
downloaded mesh is ready. Keep the existing source licences and provenance.

Acceptance: cold and warm rendered seven-mesh browser paths, explicit pending/
failure/retry behavior; two concurrent requests make one acquisition; interrupted
download keeps the previous final file; corrupt metadata/bytes cannot pass ready;
the new lock paths stay inside the already isolated anatomy directory. Root owns
backend changes; UI lane owns displayed loading counts/retry. Independent review
and full installer acceptance remain required.

## Independent bounded review, 2026-09-08

Reviewer: source-research lane; implementation owner: root. Read-only review of
`meshes.py`, its new acquisition tests, anatomy response routes and their UI
consumers. The 15-test acquisition suite independently passed in a fresh
`prepare_review_environment` directory. No operational cache or service was changed.

Five actionable findings were returned and accepted by root for correction:

1. **P1, confidence 10/10:** route acquisition, provenance verification and byte
   serving occur in separate transactions. A changed-file regression returned
   HTTP 200 with unverified bytes and an empty digest; a provenance lock timeout
   escaped as HTTP 500. Require one locked verified-byte/provenance response and
   a complete sanitized exception boundary.
2. **P2, confidence 10/10:** catalog binding omits the BP3D part definition.
   Changing requested `fma_parts` still admitted the old geometry. Bind the full
   geometry identity and retained attribution, not only the organ's generic FMA.
3. **P2, confidence 10/10:** a zero-byte successful response was published and
   reported ready. Validate the actual container before publication/readiness;
   a digest of malformed bytes is not evidence of a usable mesh.
4. **P2, confidence 10/10:** an owner-owned chmod0777 cache directory was accepted.
   Reject group/other-writable cache roots so other local users cannot replace
   cache/lock names. No need to pretend public anatomical geometry is secret.
5. **P2, confidence 9/10:** active and saved Biology display acquisition-in-progress
   rejections as unavailable rather than pending. Preserve the backend's bounded
   retry semantics and distinguish actual failure. UI owner notified directly.

Correction verification is PENDING; the initial green tests did not cover these
cases. No fresh cold/warm browser pass is claimed by this review. The large
archive was not downloaded again. Warm serving also hashed each file twice and
then read it; the proposed single locked response can avoid that redundant work.
Synchronous FastAPI route handlers avoid directly blocking the async event loop.

Lesson: atomic download publication is insufficient if the serving route later
reopens unverified bytes, or if cache metadata does not bind the complete source
selection. Test the final HTTP boundary, not only the acquisition helper.

### Independent correction verification

All five findings above were rechecked after their fixes. The independent
acquisition/mesh/retry/restoration packet passed **57 tests in 5.15 seconds**,
with three existing dependency/lifecycle deprecation warnings. Fresh isolated
review storage was used; no operational cache or service was changed.

The HTTP boundary now obtains bytes and metadata under one acquisition lock,
checks the returned byte digest again, and sanitizes the complete operation.
BP3D part IDs/names/conversion and retained attribution bind the cache identity.
Bounded GLB 2 container validation runs before publication and cached admission;
it is not proof of anatomical accuracy. Group/other-writable cache directories
are rejected. Active/saved consumers retry only `ANATOMY_ACQUIRING`, respect
Retry-After, cancel stale contexts, deduplicate requests and bound waiting to
five minutes; real errors remain errors. Graphics retry restores the selected
isolation, section and label settings.

No actionable issue remains in this bounded correction review. These tests do
not replace the owner's fresh cold/warm rendered-browser acceptance, which is
tracked separately. No large archive was downloaded again by this reviewer.
