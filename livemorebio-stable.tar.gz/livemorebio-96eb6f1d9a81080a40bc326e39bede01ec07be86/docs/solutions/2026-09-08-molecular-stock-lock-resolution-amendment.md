# Molecular inputs: one stock npm lock-only resolution

2026-09-08. **Awaiting root approval of the exact invocation; NOT RUN.**
This transparently replaces the metadata-only/request-interception sections of
[the preparation report](2026-09-08-molecular-build-input-preparation.md).
Root rejected the proposed38-case custom npm interception layer as disproportionate.
It will not be implemented. The original report and all seven private prepared
files remain frozen and attributable, including their old NOT_AUTHORIZED label.
This amendment governs the proposed new run; it is not a silent relabeling of it.

## Revised operation boundary

Use installed stock npm11.12.1 on Node26.0.0, with the exact identities recorded
in the preparation report. Resolve the existing private manifest once to a real
lockfile. Explicitly permit **local retained Molstar manifest extraction** and
incidental registry archive reads/extraction that npm requires to inspect package
metadata, bundled dependencies or shrinkwraps. Do not execute dependency code,
lifecycle scripts, native builds, webpack, Sass, tests or a browser. No package
installation/materialized application node_modules, vendoring or product changes.
The six scientific candidate coordinate files remain unacquired and unchanged.

The official registry is configured; it is **not** an origin/redirect firewall.
Stock npm's30-second fetch timeout and fetch-retries0 are retained. These do not
provide an exact once-only URL ledger, per-file byte bound or prevent all
higher-level metadata fallback. There is no custom network shim. No claim is
made that post-resolution validation prevented an earlier request. Only one
whole resolver invocation is authorized after root approval, with no rerun,
changed pins or relaxed peer constraints following failure.

## Exact command, environment and deadline

Working directory: `/tmp/livemore-molecular-build-plan.4ej8oR` (mode0700).
Recheck the seven prepared-file hashes, retained Molstar archive hash, Node/npm
launcher/package/config hashes, and absence of lock/cache/node_modules first.
Create only private0700 `tmp`, `cache`, `logs` and `resolution-receipt` directories
inside this owned root; retain output files mode0600. Existing inputs are not edited.

```sh
/usr/bin/env -i \
  PATH=/opt/homebrew/Cellar/node/26.0.0/bin:/usr/bin:/bin \
  TMPDIR=/tmp/livemore-molecular-build-plan.4ej8oR/tmp \
  LANG=C LC_ALL=C \
  /opt/homebrew/Cellar/node/26.0.0/bin/node \
  /opt/homebrew/lib/node_modules/npm/bin/npm-cli.js install \
  --prefix=/tmp/livemore-molecular-build-plan.4ej8oR \
  --userconfig=/tmp/livemore-molecular-build-plan.4ej8oR/user.npmrc \
  --globalconfig=/tmp/livemore-molecular-build-plan.4ej8oR/global.npmrc \
  --cache=/tmp/livemore-molecular-build-plan.4ej8oR/cache \
  --logs-dir=/tmp/livemore-molecular-build-plan.4ej8oR/logs \
  --registry=https://registry.npmjs.org/ \
  --package-lock-only --lockfile-version=3 --ignore-scripts \
  --allow-git=none --audit=false --fund=false --update-notifier=false \
  --fetch-retries=0 --fetch-timeout=30000 --maxsockets=1 \
  --strict-ssl=true --strict-peer-deps --bin-links=false --workspaces=false
```

Run that argv under standard Python subprocess timeout handling, not a resolver
wrapper/preload: one Popen with `start_new_session=True`, stdin DEVNULL, stdout/
stderr to private receipt files, and the explicit env above. Set one monotonic
120-second overall window **before launch**, allocate at most115seconds to npm,
and reserve the final5seconds for termination/reaping. On timeout, terminate the
owned session while its leader remains held/unreaped, escalate if necessary,
then reap it within the remaining budget. Do not signal a reaped/reused PID or
an unrelated process. A missing exit/cleanup acknowledgment is
`CLEANUP_UNCONFIRMED`, not success. No request retries or second process invocation.
The stdout/stderr file handles close independently of receipt-write success.
Retained-file inventory/post-resolution review is read-only follow-up, outside
the bounded network-bearing child operation; it does not extend npm's deadline.

No HOME override, secrets, inherited proxy, NODE_OPTIONS or user npm config is
passed. The inspected built-in npmrc only sets a prefix, overridden explicitly.
`ignore-scripts`, `allow-git=none`, lock-only and the disabled audit/fund/update
options are supported by the installed source. The command is not npm run/test
and does not invoke the Molstar manifest's scripts. Tools themselves execute;
dependency/lifecycle code does not receive authorization.

## Retained result and mandatory lock inspection

Record start/end/elapsed, exact argv and input/tool hashes, own PID and exit
status, timeout/cleanup outcome, private log hashes, lock presence/size/SHA256,
cache file count/actual bytes and node_modules absence. Keep incomplete lock,
cache and error evidence on failure. Do not dump logs, environment, credentials
or arbitrary upstream error strings into the product or public report. A failed
run remains failed even if a partial lock exists. Do not delete the evidence.

Before any subsequent installation/build, inspect the complete resulting lock:

- Exact root direct pins match the prepared manifest; lockfileVersion3; no
  unexpected workspace/link/root dependency. Molstar's only local source is the
  retained exact archive, with matching integrity; no second source substitutes.
- Every other resolved dependency has an official HTTPS npm-registry artifact
  URL and usable integrity. Flag Git, external HTTP/HTTPS, local paths, missing
  integrity, unexpected aliases or source changes; no install/build follows a
  failed source check. Such checks are admission of the **next** step, not proof
  of the previous request graph. Retained npm logs are inspected for unexpected
  origins/redirect evidence where available; absent logs do not prove absence.
- Count distinct selected name/version pairs, requiring at most384 before the
  next step. This is explicitly a post-resolution admission limit, not a limit
  that npm enforces during dependency exploration. Inventory incidental archive
  and extraction/cache bytes as observed, without inventing per-file bounds.
- Inventory exact dependency licenses, bundles/shrinkwraps and hasInstallScript
  flags. Missing/ambiguous licenses or native/lifecycle requirements remain
  explicit blockers to artifact admission. A lockfile license label is not the
  full redistribution notice/source review. No codec dependency becomes approved
  for the emitted bundle merely because npm resolved it privately.

Root reviews the receipt, complete lock and findings before authorizing any
install or build. The structure-only entry/spec, public-component lifecycle,
all three consumer contexts and every current target remain unchanged. This is
a proportionate build-tool boundary amendment, not a change to the scientific
programs, molecular evidence claims or R03/R23/R24 requirements.

## Root decision

Root read all111 lines, exact prior argv and package manifest. Approve this
one stock lock-only invocation with the written private environment,115s work /
120s total budget and mandatory post-resolution review. The rejected custom
interception layer must not be implemented. Its previous stricter metadata-only
constraint is explicitly superseded, not claimed to be enforced by npm flags.
All seven prepared files remain unchanged. No dependency install/build follows
until root reviews the retained result. This is not a scientific execution gate.

Separate source-lane update: root has since acquired the six approved original
mmCIF files in its distinct private metadata directory, described in
`2026-09-08-molecular-reference-source-admission.md`; no product coordinates or
mapping have been installed. This does not alter this npm command or its inputs.
