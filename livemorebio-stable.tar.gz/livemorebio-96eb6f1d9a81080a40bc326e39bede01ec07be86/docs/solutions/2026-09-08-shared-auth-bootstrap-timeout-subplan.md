# Bound the existing browser session bootstrap

Date: 2026-09-08. Status: **Root approved before implementation; maker packet
implemented, independent source review and real-browser acceptance pending.**
Parent: [continuous UI binding](2026-09-08-continuous-lifecycle-ui-binding-plan.md)
and the approved full R01–R51 recovery plan. This is a small control/error-boundary
correction, not a new login system, authorization relaxation, or full-product gate.

## Evidence and preserved contract

Independent read of `livemorebio/aegle/console/lib/auth.js` found that the wrapped
fetch awaits `ensureLocalSession()` before calling the underlying request. The
bootstrap's own native fetch has no signal or timeout. Consequently, aborting a
request while bootstrap is pending cannot settle that caller: the signal reaches
native fetch only after bootstrap returns. This can leave the continuous UI busy
even after its nominal 15-second read or 60-second initialization deadline.

Prior art was read in
`2026-08-30-governed-twin-onboarding-and-live-workspace.md` and the existing
`test_loopback_bootstrap_replaces_manual_token_prompt_but_keeps_mutation_auth`.
The existing short-lived, same-origin, loopback-only HttpOnly/SameSite cookie
contract stays unchanged. The bearer token never enters JavaScript, browser
storage, URLs, error text, or logs. CLI/SDK authentication stays unchanged.
Available-tool discovery has no gbrain/Compound Engineering/context7 endpoint;
the repository contract and existing native Web API usage are the local fallback.

## Approved smallest complete design

Retain the current IIFE, captured `nativeFetch`, `window.fetch` wrapper, and
`window.lmbEnsureLocalSession()` public name/Promise<boolean> behavior. Add only
small internal helpers for a shared bootstrap flight and an individual caller's
abort-aware wait. No third-party dependency, worker, global polling, or persistent
storage is introduced.

1. A flight owns its promise, AbortController and timer. Cache a fulfilled flight
   as today. Concurrent same-origin callers share one flight. The flight has a
   fixed **10,000 ms bootstrap deadline**, separate from caller and native-engine
   deadlines. This is a prospective responsiveness bound, not a measured SLA.
2. Race bootstrap completion against that owned deadline. On timeout, reject all
   current waiters with fixed `LOCAL_SESSION_UNAVAILABLE`, abort the native
   bootstrap, and clear the cache only if it still points at that exact flight.
   Clear the timer on normal success/failure too. A late old completion must not
   overwrite or invalidate a newer successful flight, even in a test transport
   that ignores cancellation.
3. A caller that has already aborted rejects immediately with a fixed AbortError
   before creating bootstrap or sending the intended API request. A caller that
   aborts while waiting detaches promptly from the shared promise. It must not
   cancel bootstrap for other callers. Remove each caller's abort listener after
   settlement. With zero interested callers, the still-owned flight can finish
   or hit its own fixed deadline; no unbounded orphan wait is created.
4. Resolve the effective caller signal using native fetch precedence:
   `init.signal` when explicitly supplied, otherwise a Request input's signal.
   Forward the original Request/body/method/headers and native signal semantics;
   do not consume or reconstruct request bodies. An abort never causes a retry.
5. Only a same-origin request that used the still-current flight may invalidate
   it on a 401. Do not replay the failed request. The next explicit request can
   start a new bootstrap. An older flight's late failure/401 must not discard a
   newer cached session. A cross-origin response must not reset local bootstrap.
6. Cross-origin fetch behavior remains native and unmodified. The explicit
   `/api/session/bootstrap` bypass avoids recursive wrapping. Same-origin API
   requests continue to receive `credentials: 'same-origin'`; no new token/header
   mechanism or redirect/auth policy is invented here.
7. Bootstrap failure uses fixed local error text/code without reading or echoing
   arbitrary response bodies, status text, URL credentials, or raw exceptions.
   Do not print diagnostics or change caller response JSON. Timeouts are not
   claims that a submitted downstream mutation failed: while waiting for
   bootstrap, that caller's downstream native fetch has not been dispatched.

The continuous UI already cancels old read generations across controls and uses
60 seconds for start/resume. This correction makes its abort meaningful during
session setup without changing numerical horizons, producer leases, or service
lifecycle. It does not restart or auto-resume anything.

## Red-first regression packet

New dedicated `livemorebio/tests/test_browser_session_bootstrap.py` executes the
actual `auth.js` in an isolated Node VM with fake native fetch and deterministic
timers. No browser/service restart, token read, network request, or operational
store is needed for these tests. Each regression asserts the exact downstream
request count as well as promise settlement and absence of sensitive output.

| Case | Required assertion |
|---|---|
| Caller abort during stalled bootstrap | Caller rejects promptly as AbortError; downstream API is never dispatched; current bootstrap is not canceled by that caller. |
| Two waiters, one canceled | One shared bootstrap; canceled waiter never dispatches; other waiter succeeds and dispatches once. |
| Already-aborted signal | No bootstrap and no downstream API request. |
| Shared bootstrap timeout | Exact owned 10,000 ms timer rejects waiters and aborts native bootstrap; cache resets; a later explicit caller creates one new flight. |
| Late old success/failure | Completing a timed-out old native request cannot poison a newer successful flight or clear its cache. |
| 401 ownership | One explicit request returns its original 401 without replay; only its current local flight is invalidated; an older/cross-origin 401 does not reset the newer local flight. |
| Request signal and init override | Request's signal works when not overridden; explicit init signal takes precedence; original request/body/method/headers remain intact. |
| Failure privacy | Malicious bootstrap body and raw network exception are not read/echoed; fixed safe code/message only; no credential/browser-storage access. |
| Resource cleanup | Success, failure and cancellation detach waiter listeners; owned timers clear; losing promises have rejection handlers. |
| Legacy behavior | Repeated healthy requests share/cache success; external fetch bypasses session setup; direct bootstrap never recurses; exported ensure helper retains its result contract. |

Run the dedicated packet together with the existing subject/session authorization,
continuous UI, shared shell/build-identity UI, and review-isolation regressions in
the prepared private test environment. Record actual counts only after completion.
Root independently reviews this maker's diff and grades the red regressions.
Real-browser recovery is a separate root-owned acceptance step, not inferred from
VM tests. No unrelated older UI harness assertion is weakened to pass this work.

## Ownership, approval, and completion

- Proposed maker ownership: only `console/lib/auth.js`, its dedicated new test,
  and this solution record after approval. No server security, cookie issuance,
  runtime, service launcher, numerical model, or installed-state edits.
- Root reads this complete proposal before any implementation. After approval:
  capture true red tests, implement the minimal helpers, run scoped regressions,
  then hand the stable packet back for independent review and real-browser QA.
- Do not publish, commit, push, or call the correction complete based on the
  proposal. Full R01–R51, physical verification, and wider release gates stay open.

## Maker evidence (not independent acceptance)

Root read the complete proposal and existing `auth.js`, then explicitly approved
the narrow design before any implementation. Ownership stayed within `auth.js`,
the new dedicated test, and this record. No server, cookie policy, installed
state, or service lifecycle changed.

The dedicated VM packet produced **17 failed, 4 passed in 2.21 s** against the
unchanged source. Failures reproduced pending callers after abort/timeout,
older/foreign 401 cache invalidation, unsafe response-body/network error text,
and missing timer/listener ownership. The four existing behavior checks passed.
After the small shared-flight and caller-wait helpers, the same packet produced
**21 passed in 2.11 s**. The Request checks explicitly cover an absent signal,
`undefined` (native inherited Request signal), `null` (explicitly disabled), and
a distinct overriding signal. Native Request identity/body remains unchanged.
Fake transport deliberately ignores abort to test late native completions.
These are deterministic no-network tests, not measured ten-second browser timing
or completed browser recovery. Root must independently grade the maker's diff.

The dedicated packet plus subject/session authorization, continuous UI,
build-identity UI, clean-workflow UI and review isolation produced **78 passed,
3 existing deprecation warnings in 10.79 s** through `tools/run_review_tests.py`
with `-B -p no:cacheprovider`. Test stores were private temporary directories.
`git diff --check` passed. No native model solve or service operation was run.

## Lesson retained from reproduced failure

A timeout on an inner HTTP request does not bound an outer authentication wait.
Shared setup work needs its own deadline, while each waiting caller needs
independent cancellation. Cache ownership must be checked before clearing shared
state, otherwise a late failure can invalidate a newer successful session. This
lesson is now backed by the recorded red/green packet; independent and browser
evidence remain separate gates. Compound Engineering is unavailable in this
session, so this repository solution record is the explicit local fallback, not
a claim that `/ce:compound` ran.
