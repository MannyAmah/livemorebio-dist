# Reference-cohort shared authority: implementation candidate

2026-09-08. **Maker evidence, awaiting independent implementation review.**
This is the bounded database-authority integration approved in
`2026-09-08-reference-cohort-registry-authority-plan.md`, not clinical, source,
model, browser or full-product acceptance. Root and the independent UI reviewer
cleared the pre-code plan; root separately cleared the shared bootstrap shape
correction before authorizing this implementation.

## Frozen ownership and changes

Only the service and its new dedicated tests were edited, plus this report:

| File | SHA-256 |
| --- | --- |
| `livemorebio/aegle/reference_cohorts.py` | `f365a818959a88016087d8d6aa6129acbc9a7dfe22be18d255a6be6a38ed9183` |
| `livemorebio/tests/test_reference_cohort_authority.py` | `b95f028d6ed7574122edbe7127b237abd0275e63d581d5d694f8a464aa245bff` |

The service is443 lines; the dedicated test file is498 lines/80 collected cases.
Shared registry/bootstrap/audit, server, source normalization, population rules,
UI and numerical code were not edited in this lane. Root owns the plan's narrow
legacy cohort-list/detail error adapter and its separate tests.

The single internal connection helper now acquires BEGIN IMMEDIATE, requires the
trusted shared authority hook, authenticates on that exact writer connection,
and checks the cached public store namespace. It yields the checked connection
and nonempty authority token, checks both identities again, then commits before
any caller can return. It never substitutes an unrelated connection's check.

Initialization performs the two unchanged table definitions using separate DDL
statements inside that transaction; executescript's implicit commit is removed.
The initializer inserts/reads the same existing public store UUID and derives the
same HMAC/AAD domains. No schema, ciphertext or access-event rewrite is added.

Preview has an initial checked transaction, unlocked source selection, and a
final checked transaction using the original operation token. New create uses
the same token across its existing two phases. Exact committed idempotent replay
still returns before expiry or source loading, after its replay audit commits.
Summary, page and member reads all authenticate before decrypting or auditing.
Fresh operations may accept an actually adopted current proof; a request spanning
that adoption cannot silently mix its earlier and later authority.

Rollback and close are attempted independently. A secondary cleanup diagnostic
does not replace the original storage failure. An unconfirmed cleanup cannot
return prepared data or a misleading ordinary domain response; public failures
remain fixed REFERENCE_STORAGE_UNAVAILABLE/503. Interruptions retain their
original BaseException after owned cleanup. No automatic retry or committed/
rolled-back claim is inferred from an unavailable response.

## Red/green record

All commands used the managed interpreter with `-B tools/run_review_tests.py`,
`-q -p no:cacheprovider`, private authored fixtures and no operational stores.
The new test module traps urllib peer access and AegleTwin construction. Its
population rows come only from the existing authored `test_population_records`
tables. It does not fetch NHANES or other participant data.

1. A first test-only setup run had53 import errors: the tripwire named a
   nonexistent `aegle.twin` module. Corrected to the actual `aegle.runtime`
   constructor; also corrected new fixture SQL names to the existing schema.
   This setup failure is not counted as the product RED evidence.
2. Before the service change,53 cases produced **42 failures,11 passes in2.21s**.
   Retained isolated root: `livemore-research-review-hva5mpaj`. Failures showed
   missing authority before source/decryption, accepted changed proof/store
   metadata, accepted between-phase adoption, DDL transaction bypass, and
   unnoticed injected commit acknowledgment failure.
3. The service correction yielded **53 passed in2.87s** in
   `livemore-research-review-ffd40uhz`.
4. Added final-check, DDL, final-preview, cleanup and contention coverage. A
  111-case run had2 failed assertions/109 passes: the DDL fixture had incorrectly
   included the inherited registry constructor's earlier committed access audit
   in its rollback expectation. The test now snapshots after that constructor
   and proves its audit remains, while all later public DDL rolls back. Runtime
   behavior and scientific assertions were not changed to make that test pass.
5. Final preservation command:

```text
/Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B tools/run_review_tests.py -q -p no:cacheprovider livemorebio/tests/test_reference_cohort_authority.py livemorebio/tests/test_reference_cohort_lifecycle.py livemorebio/tests/test_reference_cohort_api.py livemorebio/tests/test_population_records.py livemorebio/tests/test_population_identity.py --tb=short
```

**162 passed, one existing Starlette test-client deprecation warning,5.25s.**
Isolated root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-qb0v6vji`.
This includes all80 new authority cases. No test was skipped. The unchanged
reference API suite uses in-process ASGI, not a live service or socket.

## What the new tests establish

- Exact connection/ordering for initialization and all read/write phases, with
 16 checks for the eight transactions in the traced preview/create/page/replay/
  summary/detail workflow. Missing hooks and None/empty/non-string tokens reject.
- Six operations each reject five actual malformed-storage changes: proof bytes,
  public namespace, registry ID, orphan bootstrap metadata, duplicate singleton.
  No protected source work, decrypt or new journal row precedes that rejection.
- Actual wrong-key constructor leaves every existing table's bytes unchanged;
  the correct key still reads the frozen cohort afterward.
- Two real SQLite connections coordinate adoption during unlocked selection
  using bounded events. Both preview and create reject crossing the change;
  fresh later operations authenticate and work. Two same-key create operations
  rendezvous outside locks and produce one frozen cohort/member set with separate
  committed-create and replay journal events.
- The source loader successfully obtains a second BEGIN IMMEDIATE at timeout0,
  proving it is outside the first operation's writer lock. Exact expired replay
  never loads source. The production timeout remains5s; the busy test replaces
  only its private test connection with timeout0 to avoid a timing-based test.
- Injected second-DDL, member and audit failures roll back that operation's new
  rows. Twelve final-check cases change authority/namespace inside the writer
  transaction and prove the end check rejects and rolls back all changes.
- Actual SQLite commit followed by an injected lost acknowledgment produces
  fixed unavailable, retaining the complete committed record. Only an explicit
  same-key retry recovers it after expiry/source unavailability, with one new
  replay event, no duplicate cohort/member and unchanged original ciphertext.
- Read/preview commit or close failure does not return prepared data. The final
  preview phase is separately exercised, including precommit rollback versus
  actual commit/close acknowledgment loss. Cleanup fault cases preserve primary
  ordinary errors/interruption and prevent false404 when cleanup is uncertain.
- Caller draft mutation during unlocked selection does not alter the detached
  request identity; mutation of a returned summary does not alter stored bytes.
  Existing record/member ciphertext, schemas, source/member identity and separate
  public journal fields remain unchanged. Direct reference operations add no
  shared clinical BEGIN/RESULT events.

## Limits and handoff

These are cooperating local SQLite writer guarantees. They do not fence
pre-barrier old software, arbitrary same-user SQL/key access, or unsupported
in-place poisoned-store recovery. Private corruption probes are storage-integrity
fixtures, not evidence of a remote exploit. No new public identity, model binding,
clinical eligibility, active-person transition or device claim is introduced.

The root-owned legacy list/detail adapter must be independently reviewed with
this service integration. The maker requests independent source read and rerun;
passing this packet is not its own acceptance. No browser, source acquisition,
native model, operational registry, hardware, commit or publication was used.

## Independent root review

Root read all443 service lines and498 dedicated-test lines, the original reviewed
plan and this complete maker report. Both frozen hashes above match. The checked
connection covers constructor DDL, both source phases, replay and direct reads;
the final check, cleanup and unchanged separate journal agree with the approved
scope. No actionable bounded implementation defect was found.

Independent run in fresh private root `livemore-research-review-3waof6iu`:
**287 passed,3 existing deprecation warnings,6.61s**. This combines the maker's162
cases with root's51 cohort adapter cases and74 preserved Cendos source/transport
cases. Unlike the maker wrapper, this independent invocation explicitly refused
socket connect/connect_ex, DNS/getaddrinfo/gethostbyname/gethostbyname_ex,
create_connection and both urllib entry points before pytest. It used
`/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B`, the same review-environment
preparation and `-q --tb=line -p no:cacheprovider`. No live socket, startup,
operational store or public participant source was used. Runtime/tests unchanged.

The narrow root cohort error adapter also passed separate independent UI review
(157 checks); that review did not grade this reference writer. This root review
clears only the frozen reference authority implementation. It does not clear
committed active-source transitions, browser workflows or full R01–R51 acceptance.

## Compounded lesson (retained)

An encrypted service sharing a database must share transaction-local key/store
authority even when it correctly keeps a distinct access journal. Conversely,
that journal must not be silently replaced by clinical audit events. Two-phase
source work needs an operation-local authority fence, not a permanent cached
token that locks out later legitimate adoption or an unguarded second phase.
Rollback tests must also separate earlier independently committed access evidence
from the later transaction that failed; otherwise they encourage erasing audit
history to satisfy an incorrect all-or-nothing expectation.
