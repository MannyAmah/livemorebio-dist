# September 9 final regression and browser receipt

This is a bounded engineering receipt, not whole-product or human-equivalence
acceptance. Existing installed services and operational stores were not replaced.
The review stack uses private, non-PHI data and loopback ports 8868–8870.

## Full regression before the final legacy wording correction

Root command, in the full-scope-recovery worktree:

```sh
LIVEMORE_TEST_MODEL_DIR=/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-rqo3olua/models /tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python tools/run_review_tests.py -q -p no:cacheprovider -m 'not network' --maxfail=10 livemorebio/tests
```

Final receipt `305bb1`: **6,396 passed, 44 skipped, five deselected, 95 subtests
passed, five warnings, 399.57 seconds**. The initial command did not retain a
per-case skip ledger. Do not infer individual skip reasons from the aggregate.
Warnings concern inherited FastAPI/Starlette deprecations and noninteractive
Matplotlib display in two notebook tests. This is not a live external-source,
physical-device, wet-lab or clinical validation run.

Root `git diff --check` passed (`e066df`) and `compileall -q livemorebio tools`
passed (`07b205`). These receipts precede a separately reviewed seven-line
legacy display/navigation correction; the final targeted/full results follow.

## Cendos selector: independent actual browser

Root reviewed the maker's exact before/after source and repeated the independent
81-case guarded preservation packet (`4b6199`), then visited the actual served
page under startup source `69a8c90e231251a0c0645f0d9eac6d834d1e18b46e1fda93826101d60f7ec87a`.

- Fresh Preparation showed an empty protocol choice, no preselected experiment.
- Individually selected Human-GEM, metformin, garcinoic-acid/PXR and lobeline.
  Only the chosen form appeared. No assay was executed during this check.
- Metformin correctly refused descriptive public records without model binding;
  PXR offered the existing frozen hepatic research cohort, not its individual
  members as a long protocol-selector list.
- History → Prepare rerun restored the exact Human-GEM result
  `protocol-8b959f7161ac4d959d29c88737ab2384`, including the three saved media
  conditions, and locked protocol switching (`3c4593`). It did not execute.
- New experiment cleared that preparation (`61eb91`), without deleting History;
  selecting Human-GEM again worked (`235477`).
- At 390×844, the blank and selected forms were readable; document width380
  stayed within viewport390 (`f682c8`). This is not all-device acceptance.
- Page errors were empty (`1d2f4b`). Shared-session console output retained
  earlier Jupyter debug entries; no claim of a clean global console is made.

Original root screenshots, personally viewed:
`/tmp/livemore-cendos-final-rerun.png`,
`/tmp/livemore-cendos-final-mobile-blank.png`, and
`/tmp/livemore-cendos-final-mobile-protocol.png`.

## Other root review

Root read the complete independent secondary-page report and viewed all nine
original screenshots, including settled Knowledge and legacy. Research's four
tabs and Knowledge rendered; legacy claim wording remained an explicit defect
at that checkpoint. The screenshot showing five Atlas layers was an intermediate
load: the same visit settled to nine of nine, with the source-only anatomy
boundary visible (`d1853e`), not a persistent five-layer failure.

The molecular root acceptance separately records verified local hERG viewing,
two exact source-coordinate atoms, the independently checked21.715473Å distance,
selection cleanup and Escape teardown. It is static structure inspection, not
evidence of a biological interaction or a patient's molecular geometry.

## Lesson and acceptance boundary

Use actual settled UI state and exact startup source, not a Git commit alone or
an intermediate loading screenshot. Regression totals, browser behavior,
numerical reference correctness, independent measurements and release approval
are separate evidence. The six requested insulin/botanical programs, physical
LIFE/Cendos validation, full-person qualification and R50 remain open.

## Final legacy correction: root review and actual browser acceptance

This append supersedes only the unresolved legacy copy/highlight finding above.
Root read the exact seven-line source delta (`9eb0b3`, `729c4f`), eight added
cases and entire guarded wrapper (`e383f6`). Independent repeat `c93fb6`:
**155 passed in17.64s**, Node150, unexpected I/O0. The
[correction plan and preserved RED/GREEN](2026-09-09-legacy-claim-navigation-correction-plan.md)
retain the original source, tests and maker receipt.

Final restarted API identity (`47e0cc`) reports source
`da7673ba12df8ba68407efe12308e057f5f879381bb1e6bb5e64d6c658238169`
and startup `16:49:10.349787`. Root's actual desktop (`241955`), More menu
(`b96169`), exact active-anchor check (`8ec332`) and mobile (`02d3cc`) were
personally viewed. Local heading is Advanced console; organ/system labels say
model, the calculated trace boundary remains, and only More → Advanced console
is active at `/legacy`, not Atlas. This is **narrow copy/navigation acceptance**,
not whole-legacy, every-mobile-control, numerical or physical qualification.
Other drawings, controls and semantics were outside the seven-line correction.

### Durable original screenshot copies

On root's instruction, the documentation editor copied each original `/tmp`
PNG into [`docs/screenshots/final-review-2026-09-09/`](../screenshots/final-review-2026-09-09/),
with its original basename and no re-encoding or replacement. All six matching
original/copy SHA256 pairs were read back (`c23c4e`), dimensions inspected,
and every copied image viewed. Original temporary files remain untouched.

Cendos images retain their preceding `69a8c90e…` startup identity; the later
legacy images belong to `da7673ba…`. The shared folder does not relabel all
captures as one running build. Desktop is1600×1000, mobile390×844.

| Original basename and retained copy | Bytes | SHA256 |
|---|---:|---|
| [livemore-cendos-final-rerun.png](../screenshots/final-review-2026-09-09/livemore-cendos-final-rerun.png) |191562|`6c02f12c36bc33ad13b5cf72ac32c676f61c17a3c52960797a9540c67b24f6fa`|
| [livemore-cendos-final-mobile-blank.png](../screenshots/final-review-2026-09-09/livemore-cendos-final-mobile-blank.png) |85148|`f587275626d61a9e75289a484a010fafd615cca6a9c62667ed9883520ba0e4de`|
| [livemore-cendos-final-mobile-protocol.png](../screenshots/final-review-2026-09-09/livemore-cendos-final-mobile-protocol.png) |97616|`5b891894318a5cc2832517928df05865b8e26b3934d84d0f4b718c8a431880f7`|
| [livemore-legacy-corrected.png](../screenshots/final-review-2026-09-09/livemore-legacy-corrected.png) |218556|`7390df33c7b44b98cb22e6892a15124c1de35c9e6dfb038b077b9acd38cb38b7`|
| [livemore-legacy-corrected-nav.png](../screenshots/final-review-2026-09-09/livemore-legacy-corrected-nav.png) |214543|`ddeefa27c5360371c82d3ba6c4f3b2e7e37e2b61e52cec9f75835486e28f6d47`|
| [livemore-legacy-corrected-mobile.png](../screenshots/final-review-2026-09-09/livemore-legacy-corrected-mobile.png) |60404|`db0d4f218c19b7154c4f17063a64ba7e0d9ab1de13985db423bdbb3cd5ff45f0`|

## Completed post-legacy, pre-Atlas full regression

The previously pending session6324 completed as root receipt `7c4a53`:
**6,404 passed, 44 skipped, five deselected, five warnings, 95 subtests passed
in405.85s**. Root used the same isolated review runner and approved Human-GEM
model directory as above, with `-rs` to retain actual skip reasons. This result
belongs to source before the later Atlas declared-group search correction; it
is not a completed broad repeat for `326dcfaf…`.

Root supplied the following exact accounting from that run's actual `-rs`
summary. It totals44 skipped cases; it is not inferred from source markers or
retroactively assigned to the earlier aggregate-only `305bb1` run.

| Recorded skip reason/group | Cases |
|---|---:|
| Beard conversion opt-in |13|
| Beard MathML opt-in |4|
| Beard native-worker opt-in |13|
| Beard source-contract opt-in |1|
| Beard source-execution opt-in |1|
| Continuous cardiac opt-in |2|
| Official model-download opt-in |1|
| Retained fake-worker stdout not selected: observation/unittest cases |6|
| Retained fake-worker stdout not selected: parent-envelope case |1|
| Pinned stoichiometry opt-in |2|
| **Total skipped, not passed** |**44**|

The Beard subtotal is32 and retained fake-worker subtotal7. Five deselections
remain separate. No unobserved exact per-test path/line attribution is invented
from these group counts. These opt-ins do not become passes because model assets
are installed, another test passes, or a video renders. In particular this does
not qualify every native engine, physical observations or the six programs.

## Later Atlas correction and current source

The [declared-group search correction](2026-09-09-atlas-declared-group-search-correction-plan.md)
has separately preserved RED/GREEN and root independent48-case acceptance
(`0fda26`,7.96s,Node47,unexpected I/O0). Root then restarted the review stack:
source `326dcfaf1c8ebf51b0e5bfe5dc37d2186452b698ad5ebb4a934fd0e694c72190`,
receipt `49fd2c`, startup `17:07:47.855810`.

Root reports actual, personally viewed browser acceptance on that source:
`heart` yielded83 declared real elements, displaying the first30 (`b6e25c`);
selecting exact FJ2417 retained PART-OF FMA7088 (`cd13ba`); clearing restored
help and exact lookup worked (`461892`). No new geometry or patient-specific
anatomy is inferred. The earlier zero-result query remains visible in uncut
Video A on its original `da7673ba…` source.

## Supported Video A: completed media handoff

[Original WebM](../deliverables/2026-09-09-workflows/01-aegle-life-biology.webm),
[viewing MP4](../deliverables/2026-09-09-workflows/01-aegle-life-biology.mp4) and
[actual-video chapter/source guide](../deliverables/2026-09-09-workflows/VIDEO_WALKTHROUGHS.md)
are retained. Original source identity is `da7673ba…`; operator stop `c4587e`.
Both files are551.1s,1600×1000,10fps,5511frames,without audio. The media editor
made one H.264/yuv420p/fast-start derivative with no cuts, overlays or respeeding;
strict full decoding succeeded for both. Representative review covered29 source
frames and3 MP4 frames, not every frame manually. Exact full hashes and media
receipts are in the chapter guide. The original WebM remains unchanged.
Root subsequently viewed all three representative MP4 stills:00:30 Atlas,
06:00 paused producer/frame34/ACK34, and09:00 saved AP/calcium replay boundary.

The recording retains the new seed57 research twin, separate five-profile
seed73 research cohort and descriptive public-reference inspection. Its exact
numerical execution is `2ec248a480734096a5313efdd1d392d9`, LIFE session
`4601ce933272426f962952a6000dc677`, source generation
`995379413070413f8a3f0de360b65937`. Producer pause/frame34, resume and final
**121 frames/121 acknowledgments** are visible. Native horizon2min, pacing
1 model second/wall second and1-second frame period are distinct from video time.
Final displayed model values are glucose80.2103mg/dL, insulin9.22µU/mL and
insulin action0 1/min. Execution Biology shows7/7 reference organs, local static
5VA2, and later a **separate** saved O’Hara–Rudy AP/calcium replay in ordinary
Biology. This is not coupled multiscale physiology or physical LIFE validation.

## Recorded Cendos result and executed analysis

On the later `326dcfaf…` source, root actually ran
`protocol-7ccfdf28cdca4a738cb4dbfa5ed7e857`: glucose cap0.5, oxygen caps0/0.5/5.
ATP-capacity outputs were approximately1/3.5/15.75mmol/gDW/h, with actual oxygen
uptake0/0.5/3; both negative controls were0 and passed (`af7c9f`). This is a
separate generic Human-GEM steady-state computation, not the earlier
`protocol-8b959f7161ac4d959d29c88737ab2384` result or a patient ATP prediction.

Root reports actual Biology conditions0/1/2 and provenance inspection (`718476`,
`2f2965`, `4682e5`), exact History search (`fa596e`) → locked rerun preparation
(`2834df`) → New blank (`4ed603`). Rerun preparation did not execute another run.
The [recorded-run export receipt](../deliverables/2026-09-09-workflows/human-gem-recorded-export-receipt.md)
retains exact authenticated original notebook/CSV/result bytes and completed
cell-source inspection. Its canonical source-result SHA256 is
`a231a17516ef0145249ef70185dcb34b17d8e491065a20048d490e3e08345746`.
The retrieval did not execute the notebook/model or qualify browser-anchor
downloads. Root separately read every notebook cell (`40032b`), used Jupyter
Save As → Run All Cells (`d1596a`), observed execution counts1/2 and no cell
errors (`4ca89d`, `e37c7f`), and personally viewed the final stored-result plot
(`922cc9`). The initial HTTP notebook had SHA256
`44444ad9ef40956cc3b20dff8de0158445bd9936b04737ea1b642c5f7988045f`, but
Jupyter later autosaved its kernel metadata after root's initial readback.
The original-name file is now16632B, SHA256
`50d74a84e395a886110cfd2600866c8f550f5343f9f1b21add46aac77eab6eea`.
It was preserved as-is, not overwritten or claimed continuously byte-unchanged.
Root's bounded authenticated GET (`7ad6f1`) exclusively retained a
[new HTTP-original copy](../deliverables/2026-09-09-workflows/human-gem-recorded-analysis.http-original.ipynb),
16041B with the exact original `44444ad9…` hash. Full read-only JSON diff
(`911eca`) establishes only `kernelspec.display_name` and added `language_info`
metadata differences; all four cells, complete sources, IDs, metadata, outputs
and execution counts are equal. The original-name notebook has no cell outputs
and null execution counts; all cell sources also equal the executed copy
(`389a60`). The export receipt preserves its historical initial retrieval pins
and adds this later readback distinction.
The [separate executed copy](../deliverables/2026-09-09-workflows/human-gem-recorded-analysis.executed.ipynb)
has SHA256 `d1ac911784d59316b5109dd6e25a5172593130571a213e962846af87b7b1e55f`
(root readback `1bb5a5`). It verifies and plots the stored result; it does not
rerun or independently qualify the model. Video B capture stopped (`c9a502`);
its completed media handoff follows below.

## Remaining final outputs and acceptance boundaries

Root's current post-Atlas full regression completed as `a1c8cc`, detailed below.
Supported A/B recordings are
complete and scoped media-accepted, but whole-product visual acceptance remains
open; supported A/B recordings do
not close R40's six scientific-program walkthroughs or R41 full-product acceptance.
All six programs remain0/6 validated. Publication/reviewed feature PR **R50 is
NOT DONE**. The failed direct-native PRE_XML packet remains failed and is not
made operational by software tests or these unrelated workflows.

This reconciliation used read-only plans/receipts and existing media evidence;
no tests, browser, process sampling, model or product-source edits were performed.
Root retains independent ownership of actual runs and final acceptance.

## Current operations and documentation checks

Root verified the three isolated service health responses with current source
`326dcfaf1c8ebf51b0e5bfe5dc37d2186452b698ad5ebb4a934fd0e694c72190`
(`05cff7`, `542c3c`, `89640d`). The review stack at8868–8870 is intentionally
left **RUNNING**. Root closed its owned browser (`9e966b`) and stopped its owned
Jupyter; the exact listener check found no listener on Jupyter8873 or disabled
tracker8865 (`327817`). These bounded checks do not assert that every unrelated
process stopped, or that the review stack is a production deployment.

Current root `compileall` passed (`5b840f`) and `git diff --check` passed
(`9d556d`). The11-line additive README guide/deck/video pointer update received
independent read-only review, including59 checked links. Final full-suite
session81481 was still running when these operations receipts arrived; its
subsequent completed `a1c8cc` result is recorded below. In-progress polling was
not counted as a pass.
Scientific and R50 publication boundaries above remain unchanged.

## Supported Video B: completed media handoff and root review

[Original WebM](../deliverables/2026-09-09-workflows/02-human-gem-cendos-analysis.webm),
[MP4](../deliverables/2026-09-09-workflows/02-human-gem-cendos-analysis.mp4) and
[chapter/source guide](../deliverables/2026-09-09-workflows/VIDEO_WALKTHROUGHS.md)
retain the actual `326dcfaf…` Cendos/Jupyter capture. Duration434.7s,1600×1000,
10fps,4347frames,no audio. The media editor made one H.264/yuv420p/fast-start
derivative (`44890f`), confirmed `moov` before `mdat` (`d0c533`), and fully
decoded both formats with strict error refusal (`f75eb2`,exit0).22 source frames
and3 MP4 frames were viewed; not every frame was manually inspected.

| Video B file | Bytes | SHA256 |
|---|---:|---|
| Original WebM |7096886|`235e1035fd229a52af7d7de86eef05f63928aaec7ff2d53f3c6e81e66b4d96d8`|
| MP4 |13902299|`cf25ffbb369080cf8759322d615f4814ae0684f5f64a9c6880aadf6566b381a3`|

Root personally viewed the three B MP4 review frames and accepted A/B as bounded
uncut workflow/media evidence (`28e630`), not R40/R41 or whole-product acceptance.
The original includes the brief earlier-QA notebook transition and unsuccessful
inactive Run-menu attempt before the recorded-run copy is successfully executed.
The chapter guide explains both; neither is cut or relabeled. Jupyter is a
separate application displaying the exact saved `7ccf…` result, not part of
the Aegle runtime-source hash. No model/product change occurred in media work.

## Eight retained post-Atlas screenshots

Root copied these exact originals without overwrite (`ecc544`, hash receipt
`668e6b`). This documentation editor reread all eight original/copy SHA256 pairs
(`28f9cf`); every pair matches. Original `/tmp` files remain. Root personally
viewed all source captures. The seven Atlas/Cendos images belong to `326dcfaf…`;
the plot is the separately owned Jupyter app showing the executed `7ccf…`
notebook. Copying into one folder does not merge those evidence identities.

| Retained screenshot | Bytes | SHA256 |
|---|---:|---|
| [Atlas heart83](../screenshots/final-review-2026-09-09/livemore-final-atlas-heart83.png) |144558|`77677b53dfb08cc4b46c8bd9bf68cdd5d4a83b4a94dae6fa01b7b5c382ffbed6`|
| [Atlas clear/help](../screenshots/final-review-2026-09-09/livemore-final-atlas-clear.png) |134801|`108ed1ba6b1999c4106532f0acb5e897c330fffd638c5d81ff613755c172f8d6`|
| [Atlas exact constituent](../screenshots/final-review-2026-09-09/livemore-final-atlas-exact.png) |134318|`c45c26e30a72ef6ec4013ba9efd3253ad7d242eed6bfbf807f531dbab4065ac0`|
| [Cendos result](../screenshots/final-review-2026-09-09/livemore-record-b-result.png) |232695|`f3bebe13a2af9f23cd37e65e7586698eb1578857936bf02da2aac2b4ff4f5350`|
| [Biology zero-oxygen condition](../screenshots/final-review-2026-09-09/livemore-record-b-biology-zero.png) |190069|`094d57fe70f8c8821c52d6a46770720446f01720bca3995567ccae867685f96c`|
| [Biology provenance](../screenshots/final-review-2026-09-09/livemore-record-b-biology-provenance.png) |156112|`190bb472a14b64d223afa353a009bc3ca4c089e7e293ebfc697fb84ad1336de6`|
| [Exact rerun preparation](../screenshots/final-review-2026-09-09/livemore-record-b-rerun.png) |191150|`0422c46bf685bdaaae341be085d56de716a3a51698899ac3a5d9dc752abf33fe`|
| [Executed saved-result plot](../screenshots/final-review-2026-09-09/livemore-record-b-plot-visible.png) |246415|`abb1a916a30f6da04cd0b123d9466e3e9acb747369256852678a671bdf70c963`|

## Final current-source full regression: completed

Root final receipt **`a1c8cc`**, session81481, command receipt `e8a4ac`:
**6,416 passed, 44 skipped, five deselected, five warnings, 95 subtests passed
in402.88 seconds**. Source is
`326dcfaf1c8ebf51b0e5bfe5dc37d2186452b698ad5ebb4a934fd0e694c72190`.
This follows completed model/recording work, with isolated test stores (reported
suffix `4a9sq5by`) and the same approved Human-GEM model cache. It does not
overwrite the earlier `305bb1` or post-legacy/pre-Atlas `7c4a53` checkpoints.
The12 new Atlas cases are included in6416, not separately added afterward.

Exact root command from `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```sh
LIVEMORE_TEST_MODEL_DIR=/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-rqo3olua/models /tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python tools/run_review_tests.py -q -rs -p no:cacheprovider -m 'not network' --maxfail=5 livemorebio/tests
```

Root read and supplied the following path/line/count ledger from the actual
`a1c8cc` `-rs` output. `line:count` gives the reported skip location and the
number of cases attributed there; repeated parametrizations are not invented
individual test names. Reason labels below are categories, not purported
word-for-word quotations of pytest's messages.

| Reported path | Reported line:count | Reason category | Total |
|---|---|---|---:|
| `livemorebio/tests/test_beard_conversion.py` | `33:1, 50:5, 66:4, 94:1, 102:1, 126:1` | Beard conversion opt-in |13|
| `livemorebio/tests/test_beard_mathml.py` | `93:1, 126:2, 134:1` | Beard MathML opt-in |4|
| `livemorebio/tests/test_beard_native_worker.py` | `50:2, 87:3, 102:1, 118:1, 127:4, 249:1, 265:1` | Beard native-worker opt-in |13|
| `livemorebio/tests/test_beard_source_contract.py` | `105:1` | Beard source-contract opt-in |1|
| `livemorebio/tests/test_beard_source_execution.py` | `39:1` | Beard source-execution opt-in |1|
| `livemorebio/tests/test_execution_numerics.py` | `68:2` | Continuous cardiac opt-in |2|
| `livemorebio/tests/test_model_assets.py` | `363:1` | Official model-download opt-in |1|
| `../../../../../tmp/livemore-fresh-venv.lSTVr3/.venv/lib/python3.11/site-packages/_pytest/unittest.py` | `523:6` | Retained fake-worker stdout not selected |6|
| `livemorebio/tests/test_osp_dotnet_parent.py` | `206:1` | Retained fake-worker stdout not selected |1|
| `livemorebio/tests/test_stoichiometry_integration.py` | `38:1, 54:1` | Pinned stoichiometry opt-in |2|
| **Total skipped, not passed** | | |**44**|

The reason/count breakdown matches the preceding pre-Atlas run:32 Beard,
2 continuous cardiac,1 official download,7 retained fake-worker stdout and
2 pinned stoichiometry. Five deselections and five warnings remain separate.
This is a completed software regression result, not successful execution of
every native engine, physical testing, scientific qualification or release
approval. Direct-native PRE_XML remains failed; the six programs remain0/6
validated, R40/R41 remain unaccepted as full-scope requirements, and **R50 is
NOT DONE**. No test was rerun by the documentation editor to record this ledger.
