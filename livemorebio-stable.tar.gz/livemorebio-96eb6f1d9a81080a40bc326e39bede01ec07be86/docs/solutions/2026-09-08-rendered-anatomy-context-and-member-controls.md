# Rendered anatomy, frozen context, and bounded member controls

Status: implemented first-packet UI correction; independent review and clean-checkpoint formal QA remain release gates. This does not close the full R01–R51 program or establish human-equivalent physiology.

## Failure modes and corrections

1. A canvas and a successful data response did not prove rendered anatomy. The old active view depended on external Three.js modules, while the saved-run view intentionally omitted geometry. The existing Three.js 0.160.0 renderer and loaders are now reproducibly bundled locally with the complete MIT license and source/output hashes. `anatomy_loader.js` keeps graphics errors independent of numerical data and supports explicit retry. Source GLBs are unchanged HRA/BodyParts3D assets, not replacement illustrations.
2. A saved experiment must not borrow the currently active twin's organ values. `run_anatomy.js` joins a pure reference-only catalog to the exact frozen run/member/cohort/native-axis/quantity/source record. Model glucose, insulin and remote insulin action remain systemic reduced-model quantities shown alongside anatomy, not organ concentrations or mechanical movement. PXR retains concentration semantics. Nonhuman lobeline and the steady-state Human-GEM network do not acquire human anatomy.
3. Cached organ-label sprites retained their old metadata even after the organ mesh updated. A red-first regression now requires `applyState` to replace the sprite's context as well as its texture and mesh metadata. Late asset callbacks and disposed renderers cannot replace current selection.
4. Rendering every frozen member into one full-ID selector made large cohorts unusable. The selected member now remains explicit outside a searchable, cohort-filtered, 10/25/50-row picker. Searching or changing pages does not change the selection. Cendos separately pages its individual result table and offers an explicit compatible-cohort selection instead of silently choosing the first two records.
5. Population forms duplicated server knowledge and hardcoded diabetes. They now consume `/api/population-capabilities`, derive research indication from the selected supported stratum, and permit a generic indication for consented real-person cohorts. Real-person age/conditions/genotype/lifestyle fields no longer contain invented defaults. A capability failure disables creation with a retry; an unconfigured healthy population generator is visible as unavailable. Listing a healthy reduced-model reference template does not create a source-grounded healthy population.
6. A mobile width assertion initially passed while the canvas actually extended beyond the viewport: the document's overflow handling hid the error from `documentElement.scrollWidth`. Visual inspection caught the clipped anatomy. The regression now checks the settled canvas and selector bounding rectangles, and the grid uses zero-minimum tracks and children so the intrinsic canvas width cannot hold the old desktop width.

## Executed evidence

Isolated source: `full-scope-recovery`, preserved base `83994425`; URL `http://127.0.0.1:8910`, LIFE8911/Cendos8912. No original8850/8890 data or services were changed.

The browser preparation created two explicitly named TECHNICAL reference-grounded cohorts, two members each: DPP high-risk seed17 and older diagnosed-diabetes seed29. Their explicit metformin regression run is `protocol-c92bddc586004e63b4f03c15c9744d56`. These are aggregate/prior-derived numerical fixture records, not physical measurements, clinical cohorts, insulin experiments, or one of the requested final research demos.

- 43 targeted Python/Node UI regressions passed after the mobile correction; the browser regression also covers that correction directly.
- Actual installed Chrome, ANGLE SwiftShader **software WebGL**, rendered seven source organs and 959,711 triangles in the active view. This is not a hardware-GPU benchmark or biological qualification.
- Saved member selection, insulin-action quantity and exact sample21 remained coherent. No active `/api/state` or `/api/biology` request occurred during saved-run inspection.
- The active cardiac cell retained its context-bound recorded model voltage/calcium display. Saved metabolic runs explicitly do not borrow that trace.
- Blocking the local graphics bundle left the numerical data available and displayed the actual error; Retry restored seven actual meshes. An unknown run displayed no active-twin fallback.
- A standalone technical 10,000-member workload rendered the initial 25 rows in approximately3.6ms on this test machine; maximum visible member rows is50 (plus a disabled selection prompt). Search/no-match/paging preserved the selected ID. It made no registry or experiment writes and is not a biological run.
- Capability503/retry, generic real-person indication, explicit compatible-cohort choice, History and New experiment were exercised with zero page JavaScript errors.

Evidence files are under `docs/screenshots/full-scope-recovery/anatomy/`. The `browser-evidence.json` and `member-evidence.json` files record the concrete checks; screenshots must be considered with the evidence classes shown on them.

Reproduce against the isolated technical run with `tools/check_anatomy_browser.cjs` and `tools/check_member_browser.cjs`. Supply `LIVEMORE_PLAYWRIGHT_MODULE`, `LIVEMORE_BROWSER_BASE`, `LIVEMORE_BROWSER_RUN_ID` (anatomy only), and `LIVEMORE_BROWSER_OUTPUT`. The scripts read existing records; they do not create subjects or experiments.

## Remaining work and lesson

Cold BodyParts3D muscle acquisition required roughly four minutes because the source is a whole OBJ archive; the UI reports loaded/total and pending source assets, then genuine failure if acquisition fails. Installation/readiness and acquisition concurrency remain backend review items. The local graphics package does not make every anatomical asset available before its source is acquired.

Reference cell/pathway/target annotations in a saved metabolic run are not a cell-coordinate trajectory, receptor-signaling mechanism or patient-specific scan. This packet does not add those missing biological engines, a registered whole-body reconstruction, healthy population generation, device hardware qualification, or physical wet-lab validation. Existing molecular structure resolution is a separate reference-data path.

Lesson: verify rendered source geometry and every context-bearing interaction, not just API status or the presence of a canvas. For responsive graphics, test actual settled element bounds as well as document width. For frozen scientific results, geometry can be cached, but identity, quantities, units, evidence class and provenance must always move together.

Compound Engineering and gbrain tooling were unavailable in this session; this durable local lesson is the explicit fallback, not a claim those tools ran.

## Independent-review correction: pending acquisition and Retry state

Root's UI review identified that a new renderer did not restore the section axis,
depth, labels or isolation still shown in the controls. The source reviewer
separately identified that concurrent acquisition's retryable503 was presented
as a permanent asset failure. Ten new tests first failed before these corrections.

`anatomy_requests.js` now deduplicates one pending request per exact same-origin
catalog URL, retries only `503 / ANATOMY_ACQUIRING`, and honors `Retry-After`
(seconds or HTTP date). Automatic waiting is bounded to five minutes and101
attempts, whichever ends first; a Retry-After beyond the remaining budget is
not shortened. A context change or disposal aborts requests/waits; late parsing
cannot install old-context geometry. Exhaustion remains “still acquiring,” with
explicit manual Retry, not a claim that the original mesh does not exist.

`anatomy_view_state.js` reapplies the visible controls to the actual new renderer,
including selections changed while dependencies load. Original GLBs are parsed
with the already pinned GLTFLoader, whose exact local source interface was read.
No graphics library upgrade or generated replacement mesh was used.

The independent parent restarted its8910–8912 stack. With explicit approval, the
test briefly held only that stack's heart acquisition lock without editing asset
bytes. Two real Chrome pages (active Biology and the existing technical saved
run) received genuine503 responses with Retry-After3, showed6/7 plus pending, and
then rendered7/7 after release. A separately labeled browser-injected true asset
failure tested manual Retry. Active sectionx/depth0.7/labels-off/heart isolation
and saved sectionx/depth0.65/heart isolation survived. Saved run/member IDs stayed
unchanged. Navigating away canceled a pending retry; no later request fired.

The targeted current selection is30 passing tests across anatomy retry/restoration,
member picker, population capability UI and compact Cendos tests. Browser evidence
is `anatomy/retry/retry-browser-evidence.json`, with four inspected screenshots
beside it. Environment remains installed Chrome with ANGLE SwiftShader software
WebGL. There were zero page JavaScript errors and no biological/registry writes.
This is targeted exploratory acceptance, not clean-checkpoint formal QA or full
R01–R51 completion. Root's independent review of the corrections remains required.

Lesson: an acquiring response needs a bounded lifecycle, not an unavailable label;
restoring UI values is insufficient unless the new renderer uses those values.
