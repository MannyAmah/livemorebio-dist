# Atlas ordinary-presentation harness correction — maker checkpoint

2026-09-08. Implementation-only checkpoint, pending independent review. No real
listener query, browser, service, model, publisher acquisition or cache write was
performed. This does not grant ordinary visual or full-product acceptance.

## Approved scope and frozen files

Read the complete 382-line `2026-09-08-atlas-post-presentation-correction-proposal.md`
(SHA `edac44b44d680c8da55b6051f6b98c74cf1a0c49ea798f39d1548b4ab7181cdb`),
both existing scripts, all inherited harness tests and the source agent's new
authored REDs before implementation. Only these implementation/test files changed:

| File | SHA-256 |
| --- | --- |
| `tools/check_atlas_presentation.py` | `95c2d4c25ad45dfcae109f9348d0600d5b78aa7046b537b43a84acc40ef4afcf` |
| `tools/check_atlas_presentation.cjs` | `8a1d71bc950044206797665655c0836df3b46c41f7625ecfebf879a22518f667` |
| `livemorebio/tests/test_atlas_presentation_correction_harness.py` | `9c6451f474d8c22d6d9ae1357733574520985ac47a187502901dd02257555a55` |

The inherited test module is unchanged, SHA
`90e9fa7f981c36070d1e4ffad5af45723fa26e89f0c29f31e618a5a1d1ae171c`.
All four product Atlas files retain their separately frozen hashes. Registry,
audit, server, parser, SDK, old acceptance harnesses and retained evidence were
not edited in this lane.

## Implemented contracts

- Startup still uses the original conservative `free_ports()` bind check.
  Finalization instead records `owned_listeners_absent`: true only for exit1 with
  both streams exactly empty; false only for a complete fixed LISTEN grammar;
  null for every ambiguity, diagnostic, timeout, malformed field or cleanup error.
  Old `owned_ports_released` evidence is neither rewritten nor reinterpreted.
- The one fixed lsof child has a three-second monotonic observation/read/wait
  budget, bounded 64KiB stdout and 8KiB stderr while reading, then exact-handle
  TERM/wait2s and KILL/wait2s if needed. Its locale/environment, flags and target
  ports are fixed. No listener or unrelated process is signaled. No stdout,
  stderr or exception text is retained; only fixed categories and admitted
  PID/fd/numeric-address/port/LISTEN metadata survive.
- The parser enforces LF delimiters, complete p/f groups, canonical positive PIDs,
  canonical descriptor numbers with an optional access suffix, descriptor
  uniqueness even across suffix changes, one TCP/address/ST field, numeric
  IPv4/IPv6/wildcard endpoints, and only canonical QR/QS extras. All other fields,
  arrows, zones, ports, duplicate fields and incomplete records fail closed.
- Child/descendant cleanup, cache verification, listener inspection and evidence
  persistence remain independent finalization attempts. The 190-second Node wait
  is not described as a whole Python-supervisor deadline.
- The initial ledger names 20 cases and 33 image paths: 15 unchanged ordinary
  viewport/canvas pairs plus three inspector viewport poses. Canvas captures use
  ordinary `page.screenshot({clip})` in viewport CSS coordinates, never element
  screenshots, fullPage, captureBeyondViewport, CSS injection or composition.
- Each image retains before/after canvas, viewport, scroll, chrome, selection and
  source-inspector metadata. Clip readiness, finite bounds, viewport containment,
  sticky/fixed-chrome occlusion and geometry stability fail closed. If a second
  image fails, the first saved image remains; if post-image inspection fails,
  `image_written` records the saved bytes without claiming a successful capture.
- Inspector metadata labels DOM text as non-pixel transcription, records visible
  viewport intersection and chrome overlap, and separately marks full article
  and identity-header visibility. Oversized/occluded articles remain explicitly
  partial. The actual first text-line Range provides the identity rectangle.
- Return verifies empty list selection, cleared cue, disabled Frame/Isolate and
  retained search query/options. Group boxes retain source keys/text and original
  inline leader endpoints; checks include 8px containment, 6px cross-group and
  selected-label separation, stable source order and bounded leader mapping.
  Snapshot sorting follows source order, not asynchronous mesh DOM arrival order.
- Existing source/process/context/read allowlists, no-redirect metadata reads,
  same-camera control sequence, 156s work / 4s failure capture / 15s resource close /
  5s evidence / 5s config / 190s parent bounds remain unchanged.

## Red-first and offline evidence

1. Independently repeated the inherited new tests: **51 failed, 9 passed in1.77s**.
   The nine malformed-clip assertions passed merely because the helper did not
   exist. They now require a valid control and exact typed rejection first.
2. Initial integration: **84 passed**. Added actual DOM snapshot and explicit
   33-image ledger controls: **2 RED**, then green. Added a malformed vertical-tab
   field delimiter: **1 RED / 5 controls passed**, then exact-LF parsing fixed it.
   Added ready-to-error between image snapshots: **1 RED**, then retained failure.
3. A strengthened all-command refusal run produced **1 failed / 91 passed**:
   import-time build metadata attempted its existing read-only Git rev-parse.
   The refusal prevented that subprocess. This was a test isolation boundary,
   not a product defect. The final command stubs exactly that Git command as a
   failed Git lookup, preserving the existing optional commit=None behavior.
   It does not alter source fingerprints, startup assertions or runtime code.
4. Final isolated matrix: **93 passed, 2 existing FastAPI deprecation warnings,
   4.52s**. Private root:
   `/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-dqlj34vp`.
   Exec session7638 finished exit0. Python socket/DNS/urllib refusals and Node
   networking/child-process refusals were active. Only exact Node `-e` authored
   tests ran; lsof/Popen/selector/read tests used explicit stand-ins. No process
   remains running from this checkpoint.

Exact repeat from the worktree (no browser or OS listener exercise):

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os, socket, urllib.request, subprocess, pytest
from tools.run_review_stack import prepare_review_environment
root, env = prepare_review_environment()
os.environ.update(env)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
print('Private test root:', root)
def deny(*args, **kwargs):
    raise AssertionError('NETWORK_OR_OS_PROBE_REFUSED')
socket.socket.connect = socket.socket.connect_ex = deny
socket.create_connection = socket.getaddrinfo = deny
urllib.request.urlopen = urllib.request.OpenerDirector.open = deny
original = subprocess.run
prefix = '''const denied=()=>{throw Error("NETWORK_OR_OS_PROBE_REFUSED")};
global.fetch=denied;
for(const key of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){
 const m=require(key);
 for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])
  if(typeof m[n]==="function")m[n]=denied;
}
require("node:net").Socket.prototype.connect=denied;
'''
def run(command, *args, **kwargs):
    if isinstance(command, list) and command[:2] == ['/opt/homebrew/bin/node', '-e']:
        return original([*command[:2], prefix + command[2], *command[3:]], *args, **kwargs)
    if command == ['git', '-C', '/Users/emman/Livemore/.worktrees/full-scope-recovery', 'rev-parse', '--show-toplevel']:
        raise subprocess.CalledProcessError(1, command)
    return deny()
subprocess.run = run
raise SystemExit(pytest.main(['-q', '-p', 'no:cacheprovider', '--tb=short',
 'livemorebio/tests/test_atlas_presentation_correction_harness.py',
 'livemorebio/tests/test_atlas_presentation_harness.py']))
PY
```

## Retained limits and lesson

The previous ordinary run still has its original 17 assertions/30 PNGs and raw
supervisor cleanup failure. The full Atlas matrix remains **28 PASS / 3 FAIL /
25 NOT_RUN**; ERR_ABORTED transport/performance findings are unresolved. No
`response.finished()`, response body read, refetch, geometry substitution or
scientific computation was introduced. The planned labels screenshot follows
Return, so it does not prove simultaneous selected-cue/group rendering. Technical
tests cover that obstacle; browser evidence remains a separate reviewed gate.

Lesson: a cleanup bind is not a LISTEN observation, and a saved screenshot is not
proof that its intended region was visible. Preserve strict tri-state process
evidence and per-image geometry independently. Local durable docs are the compound
record; connected CE/gbrain tools were unavailable, so no tool invocation or
independent acceptance is claimed.

## Root independent technical repeat and follow-up — append-only

Root independently repeated the frozen 93-case packet: **93 passed in5.29s**,
private root ending `livemore-research-review-55sq5mwc`, with30 exact Node/-e
subprocesses and parent/Node network/process refusal guards. No actual listener,
browser or model probe occurred. This is an independent technical repeat, not
ordinary visual acceptance. The implementation checkpoint above remains
attributable to its original report SHA
`3b67250770d7681fd2d35dc884c3f934e7f89d03cadbf30fa7210dcd9fddde8a` and
the three frozen source/test hashes in its table; those files have not changed.

Root's acceptance-fidelity question identified an additional bookkeeping gap:
empty visible labels bypass geometric iteration while the complete named list
and placed/omitted footer are only retained, not reconciled. The maker's requested
read-only source inspection confirmed it without a probe. Root requested the
narrow pre-code `2026-09-08-atlas-callout-bookkeeping-harness-amendment.md`.
No correction is implemented by this appended record. Valid offscreen/space
omissions, including zero visible callouts, must remain permitted. The original
ordinary/full Atlas failures and outstanding independent browser gates remain.

## Bookkeeping correction — appended maker freeze

Root read/approved the complete115-line bookkeeping amendment, including a raw
control-count precision before code. Amended approved plan SHA:
`e09e82bcbf3a6527c6268883592be975ba4b57832561a4c8cefae852a95f840e`.
Only CJS and its dedicated correction test changed; Python listener/source/cache/
product files and the inherited harness test remain unchanged.

| Updated file | SHA-256 |
| --- | --- |
| `tools/check_atlas_presentation.cjs` | `23b38f60e2ebee4e306ba6331f35bc10c13e0fa9a8da18e1970c3d7ee06803ac` |
| `livemorebio/tests/test_atlas_presentation_correction_harness.py` | `5ec5f0ec1a034620d942e91b7a8d5afbfc54b614d3bb5c533c4cfd6180072692` |

RED: **39 failed / 68 deselected in4.23s** under the report's Python and Node
refusal command, restricted to `bookkeeping or suppression or actual_dom_snapshot`;
private root ending `livemore-research-review-y8b21q9d`. No implementation existed
when those failures were captured. An earlier identical authored-only run without
the full refusal wrapper had39 failures too; the guarded repeat is the isolation
evidence. No live endpoint or OS listener was probed in either run.

Implemented one fixed-shape checker. It reconciles the nine exact ordered names,
placed keys, visible overlays and complete footer counts; records untruncated
list/control counts; validates actual labels checkbox, visibility and nine keyed
control states; and applies existing off→section→isolation precedence. Per-image
pre/post checks include inspector captures and preserve original image/metadata on
failure. All-outside, all-space and all-invalid zero-visible states are explicitly
positive tests. No requirement that all nine overlays be visible was added.

GREEN: **131 passed, 2 existing FastAPI warnings in9.69s** using the exact two-module
repeat command already printed above. Private root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-2eh2y88j`.
Session16635 finished exit0. The inherited93 tests remain;38 additional cases and
one expanded actual-DOM test cover the bookkeeping delta. Its actual DOM fixture
now reads checkboxes/counts from the snapshot function and proves a tenth list or
control is retained as raw count10 despite the bounded first-nine text projection.

No browser, service, lsof, numerical model, publisher acquisition or admitted-cache
operation was executed. The20-case/33-image ledger, camera/asset/control sequence,
all prior budgets and outstanding acceptance gates are unchanged. This appended
maker checkpoint requires root and independent source review before any run.

## Root bookkeeping review — appended independent result

Root read the complete115-line pre-code amendment, final checker/snapshot/capture
integration, added tests, expanded DOM controls and maker report. Independently
repeated both complete modules: **131 passed in9.00s**, two existing warnings,
private `livemore-research-review-2woie8hq`. Only68 exact authored Node/-e children
were admitted; one exact optional Git metadata command was refused into its
existing fallback. Parent low-level fork/exec/spawn/connection/DNS refusal,
multiprocessing refusal and Node network/child-process refusal were active.
No listener, browser or model ran. Runtime edits were briefly held for this run.

The bookkeeping correction is technically cleared at CJS SHA256
`23b38f60e2ebee4e306ba6331f35bc10c13e0fa9a8da18e1970c3d7ee06803ac`
and test SHA256
`5ec5f0ec1a034620d942e91b7a8d5afbfc54b614d3bb5c533c4cfd6180072692`.
Valid zero-visible states remain accepted only with consistent recorded omissions.
This clears the bounded harness review, not the actual33-image/browser gate,
earlier full-matrix failures, multiscale execution or any experiment recording.

## Retained 33-image review — appended visual observations

`ui_audit` personally opened every original PNG from the once-only root-run
directory `/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-atlas-presentation-hsfd6dss`.
No screenshots were regenerated, edited or composited; no browser, listener,
service, model, registry or cache was operated during this review. Root separately
viewed all33 images and is the independent product reviewer; this author made
parts of the presentation/harness packet, so this appended image review is not
an independent maker-code clearance or a full product acceptance.

Evidence identities:

- `presentation.json`: SHA256
  `f9e5080872a84fa2a9da48d9f21b4521591bebba5c9568b0c7c89fdd2e1c90d4`.
- `supervision.json`: SHA256
  `2c63980d63c9ef7d79f863ef9ac02dc62c52eeb2c073722cd598fba983e5567a`.
- Startup/final source: `bdbcc43b5712459b8a1d09cecdc817e1fc378447df6230d929cd111281cd4de6`;
  Aegle process `7fd9eb6b-e1b1-4074-b42a-df3110dbd6d4`, LIFE
  `e55269fd-1b72-4cdd-9cb6-473938412eb1`, Cendos
  `dcb5380f-a453-43e9-abe7-0366bb151753` agree across the two receipts.
- Context `2a6aa9fe504c3ad10b5bdf993e3207a6e649fdab654ea595891d6542434a002d`,
  source generation `9583206b10c5443da6875a077b61f1da`, authored nonparticipant
  observation-only fixture version2. `REAL_HUMAN` is the exercised software
  classification, not a real participant or an admitted numerical profile.
- Retained manifest `8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a`
  and original receipt `083b2f038e74476ebfcef07e4a22f7c2` remain unchanged.

The complete viewed inventory is the receipt's33 `planned_images`: viewport and
canvas for desktop whole-person (2), FJ1895 assembled/isolated/restored plus its
inspector (7), FJ2629 assembled/isolated/restored plus its inspector (7), desktop
section/section-off/Return/reference-labels (8), and mobile FJ2629
assembled/isolated/restored/inspector plus full-body (9). All33 are saved, and
all33 recorded before/after DOM states and callout bookkeeping are equal. The
20-case ledger records20 PASS; this observation does not independently establish
every lower-level assertion merely from its PASS label.

Observed presentation findings:

1. Desktop and390px views show a coherent intact whole-person reference body,
   with distinct reference-only/unavailable-model wording. No numeric physiology
   is supplied by these pictures. The installed Chrome153.0.8010.36 /
   Playwright1.58.2 environment is SwiftShader software WebGL, not hardware-GPU
   performance evidence.
2. The same-camera FJ1895 and FJ2629 triples preserve placement and scale across
   assembled → isolated → restored, with solid isolated surfaces and restored
   source-extent corners/identity. The prior alternating selection mosaic is not
   visible in these selected views. This does not prove absence at other cameras
   or remove the source's overlapping anatomy. Desktop canvas bounds remain
   `(228,254.9453125,858,490)`; mobile triples remain
   `(23,201.796875,334,440)`.
3. The x-section visibly cuts the reference surface and suppresses the extent
   cue; Section off restores it. Return produces the full body and removes the
   cue. Retained DOM evidence shows both desktop/mobile `selected` and result
   value empty, Frame/Isolate disabled, while query `FJ2629` and its one option
   remain. The search list is below the paired canvas capture, so this last
   property is a retained-DOM check, not a claim that its pixels are in that PNG.
4. The reference-label pair visibly contains all nine readable names with no
   overlapping boxes. The ordered list, nine unique loaded controls, nine placed
   keys and footer `9 ... placed · 0 omitted` agree. This was one desktop
   full-body view after Return: there is no simultaneous selected-cue/group-label
   or mobile-label capture, and no requirement for nine visible labels at every
   possible camera is inferred.
5. Both desktop source metadata cards and the mobile FJ2629 card are fully
   readable: source identity/FMA/part-of, counts, native bounds, wrapped SHA and
   the source-extent-not-contour limitation. Their raw coverage fields report
   full article/identity visibility with no chrome occlusion, matching the PNGs.
   The earlier selected dropdown sits behind the desktop sticky navigation when
   scrolled to the card. Therefore these are metadata-card captures, not proof
   that the entire controls/selection panel is visible simultaneously. The
   canvas-only images contain no sticky-header overlay; ordinary viewport
   captures retain page chrome rather than rewriting it.
6. At390px the scene, status/scope text, source cue, button row and metadata card
   fit the shown width; long hashes wrap. The full body including feet remains
   in the canvas. Recorded document width380 is below viewport390. This is not
   an all-page/mobile navigation or zoom acceptance claim.

The raw supervision report has no primary failure: four owned children reaped,
all12 tracked browser descendants absent, page/context/browser cleanup SETTLED,
and the fixed listener query reports NO_LISTENERS with cleanup SETTLED. All16
retained-cache entries have identical size, SHA and mtime before/after. These are
reviewed run receipts, not a newly repeated OS query by this reviewer.

No new actionable defect was found in these bounded presentation images.
Transport remains explicitly **UNRESOLVED**: skin, heart, liver, right-kidney and
brain each retain ERR_ABORTED, despite nine-layer graphical readiness. Zero page
errors is not a network/performance pass. `full_acceptance=false` remains; the
older28 PASS /3 FAIL /25 NOT_RUN matrix and six required experiment recordings
are not closed or rewritten by this ordinary presentation result.

## Root independent rendered acceptance of the narrow correction

Root independently opened all33 original images, including all three metadata
cards, after the fixed browser run completed. The whole-person assembly is
distinct from the deeper Biology view; isolated and restored source geometry,
section-on/off visibility, Return selection clearing and nine separated labels
are visibly confirmed within the recorded desktop/mobile poses. All displayed
metadata cards are readable. Root concurs with the above limits on the earlier
dropdown behind sticky navigation and on simultaneous/full-page coverage.

Root read both raw receipts: source bdbcc43b... was stable through final-identity;
the four owned children were reaped, twelve tracked descendants absent, owned
listeners absent, and retained-cache bytes/hash/mtime unchanged. No output was
retrospectively changed to obtain exit0. The registry runtime freeze was released
only after those retained cleanup/identity checks were read.

This accepts the specified presentation correction, not all Atlas transport,
all-page UI, clinical behavior or any experiment. The five interrupted requests
remain a diagnostic obligation; full_acceptance stays false. The existing actual
interaction videos required by R40/R41 are still outstanding.
