# Beard: unit-preserving execution route

2026-09-08. **Proposal, not approval to solve or enable a product protocol.**
This follows the [arctigenin mechanism plan](2026-09-08-arctigenin-mitochondrial-source-plan.md)
and preserves the rejected [Myokit import](../BEARD_MITOCHONDRIAL_SOURCE_IMPORT.md).
R10/R34, the full arctigenin program, the other four programs and insulin remain
open. This work changes no physiological model, running service or operational
package environment.

## Decision

Use **libCellML 0.7.0 → explicitly checked CellML 2.0 representation → generated
C → a bounded CVODE 7.8.0 worker** as the next candidate. Its parser and generator
already run on this ARM Mac. Native headers/libraries are present. No new global
framework, Python version or GUI installation is necessary for this route.

This is a source-derived execution artifact, not unchanged CellML 1.0 bytes.
Retain the original file, conversion manifest, complete units/equations and
original attribution alongside generated code. A floating-point solver does not
carry dimensions on each number; mandatory dimensional analysis and an exact
unit-bearing I/O contract must surround it. **Never feed a unit-stripped model
to Myokit and describe that as equivalent.**

The alternative libOpenCOR route has native ARM packages, but introduces an
additional Python/runtime/dependency variant. It is not needed to establish the
first checked callback and must not silently replace the selected generator.

## Actual read-only feasibility evidence

Input remains the exact CC BY 3.0 PMR artifact:

- Commit `8ec69b34c31cd1cbb53580d1853841bb333de78e`.
- SHA-256 `4a4f931592df0e77a92c79447bf6d8947c7325f721a74b4d336d370abaaf3981`.
- [Pinned source](https://models.physiomeproject.org/workspace/beard_2005/@@rawfile/8ec69b34c31cd1cbb53580d1853841bb333de78e/beard_2005.cellml).

The existing Python 3.11 ARM environment contains libCellML 0.7.0. A downloaded
official CPython 3.11 macOS 14 ARM wheel, 1,821,276 bytes, matched its published
SHA-256 `c83b6fdc5a5bed192f11c8184903cf5e08aa561ab981f17029911ce48ddb120c`.
All 64 package files under `libcellml/` matched the installed files byte-for-byte.
This verifies package bytes against the official distribution, not an independent
publisher signature. [Wheel metadata](https://pypi.org/pypi/libcellml/0.7.0/json),
[release](https://github.com/cellml/libcellml/releases/tag/v0.7.0).

`Parser(False)` converted the original source in memory; no importer/network
resolution was called. `Validator.validateModel` and `Analyser.analyseModel`
were then invoked. Result:

| Check | Observed result |
| --- | --- |
| Parser errors / warnings / messages | 0 / 0 / 6 |
| Validator issues | 0 |
| Analyser issues | 0 |
| Analysed type | ODE |
| States / constants / computed constants / algebraic variables | 19 / 47 / 12 / 34 |
| Equations / components / unit definitions / declared variables | 65 / 47 / 28 / 339 |
| Variable-mapping edges | 226, distributed across 160 source connection elements |
| Conversion, validation and analysis elapsed | 0.870298 s in one retained process |
| Process peak RSS | 40,108,032 bytes on macOS, including runtime imports |
| Generated C | 20,580 bytes; generator reported 0 issues |
| Native compilation / RHS evaluations / physiological solves | **0 / 0 / 0** |

The six parser messages disclose the version conversion, omitted documentation
and RDF, and three ignored legacy `base_units` attributes. These are not blindly
waived: CellML 2 represents each source base unit as an empty named `<units>`
element. All three remain `isBaseUnit()==True`, pairwise incompatible, and
incompatible with `dimensionless`. This follows the explicit irreducible-unit
definition in [CellML 2 §3.3](https://www.cellml.org/cellml/2.0#interpretation-of-units-elements)
and the [libCellML Units API](https://raw.githubusercontent.com/cellml/libcellml/v0.7.0/src/api/libcellml/units.h).

An independent ElementTree inventory comparison in the probe found:

- Identical component IDs and all 339 variable names, unit references and literal
  initial-value strings.
- Identical ordered MathML expression trees after namespace and formatting-only
  whitespace normalization, including `cn` units and exponent-tail text.
- Identical 226 undirected qualified variable-mapping edges.
- Identical 28 unit definitions after two explicit format rules: legacy
  `base_units="yes"` becomes an empty irreducible units element; the standard
  `liter` alias becomes `litre` in three definitions. All exponents, prefixes,
  multipliers and other references are retained. The source's unexpectedly named
  `molar_per_cyto` actually includes `mitochondria^-1`; preserve its **definition**
  and do not silently reinterpret its name as cytoplasmic volume.

In-memory CellML 2 serialization SHA-256:
`5b2ffa7a1e8bae8be173fc9e8e84cd88bdfc02efcfd00c28cf222b0af633a40c`
(98,162 bytes). Generated C SHA-256:
`3af10f8a848e6077f6059186fc1b34a9895e89f9f9c47f80669001ccfbc9795a`.
Neither generated artifact was executed or admitted to a product store.

Two deliberately invalid **technical** models independently challenged unit
analysis: assigning `cytoplasm` to `cell`, and taking `ln(cell)`. Both produced
analyser unit issues. Important: the first still had **0 errors, 1 warning and
type `algebraic`**. Therefore checking only `errorCount` or model type is not an
acceptable admission gate. Require zero analyser issues, including warnings.

Two early inspection snippets used outdated property names (`model` and
`variableCount`) and stopped with AttributeError after parsing. The final probe
used the installed 0.7.0 `analyserModel`, `constantCount`, `computedConstantCount`
and `algebraicVariableCount` API. This was an inspection-script mismatch, not a
source solve failure. No numerical outcome was discarded.

## Runtime comparison and pins

| Route | Actual support and limitation | Decision |
| --- | --- | --- |
| libCellML 0.7.0 + CVODE 7.8.0 | Exact source parses, preserves three custom bases, validates/analyzes and generates C on ARM. libCellML is not itself an integrator. A small reviewed C callback/worker is still required. | First candidate. |
| libOpenCOR 1.20260803.0 | Official ARM macOS 14 wheels exist for CPython 3.12–3.14, not the current 3.11 environment. Native C++ shared archives also exist. Source parses 1.x with non-strict libCellML and constructs CVODE tasks. Exact Beard runtime not installed/tested here. | Later comparison candidate, not a shortcut around our unit gate. |
| OpenCOR 0.8.3 desktop | Legacy CellML API and Python simulation interface support 1.x workflows; this release explicitly builds macOS `x86_64`, not native ARM. Exact source custom-unit acceptance was not tested here. | Not selected; Rosetta/legacy GUI adds dependencies without solving the proven parser route. |
| Myokit 1.39.2 | Actual import discarded the three custom bases. | Remains rejected. |
| Hand-rewritten unit/ODE translation | Could retain formal dimensions but increases implementation and review burden. No handwritten replacement reaction equations are needed with the successful libCellML route. | Do not choose unless the generated route fails a documented gate. |

Pinned source commits:

- libCellML 0.7.0: `ac6ed5c348418e273e428a28ec156c0b14ec106b`.
- libOpenCOR 1.20260803.0: `423a252b3cfcbbbfb8b3bf2eaacd6e1c24b025f2`.
- OpenCOR 0.8.3: `8fbe2dbbc2ddb563c20ad73d41e8620e108d086a`.

libOpenCOR's pinned build manifest advertises libCellML 0.6.3 while its source
build path references the author's `6c970b7` fork/tag. Do not assume it contains
the independently checked 0.7.0 package. It also bundles SUNDIALS 7.7.0, not the
installed 7.8.0 candidate. Its runtime only checks analyser error counts before
generation; our warning-inclusive gate must remain outside it.
[libOpenCOR package pin](https://raw.githubusercontent.com/opencor/libopencor/v1.20260803.0/src/3rdparty/libCellML/CMakeLists.txt),
[SUNDIALS pin](https://raw.githubusercontent.com/opencor/libopencor/v1.20260803.0/src/3rdparty/SUNDIALS/CMakeLists.txt),
[parser/runtime entry](https://raw.githubusercontent.com/opencor/libopencor/v1.20260803.0/src/support/cellml/cellmlfile.cpp),
[code generation](https://raw.githubusercontent.com/opencor/libopencor/v1.20260803.0/src/support/cellml/cellmlfileruntime.cpp).

Official libOpenCOR CPython 3.12 ARM wheel is 38,319,066 bytes, SHA-256
`9e757766703bd0a9b90a7bcf5e4b1b3716bdc2f842b2ad7aae7fa45c8c86fc12`.
It was inspected through metadata, **not downloaded or installed**. Neither
Python 3.12/3.13 nor CMake was found on current PATH; `/usr/bin/clang` is present.
An unlocated runtime is not proof that none exists elsewhere.
[Package metadata](https://pypi.org/pypi/libopencor/1.20260803.0/json),
[official release assets](https://github.com/opencor/libopencor/releases/tag/v1.20260803.0),
[legacy architecture declaration](https://github.com/opencor/opencor/blob/v0.8.3/CMakeLists.txt).

The existing `/opt/homebrew/include/sundials/sundials_config.h` declares 7.8.0.
The installed core/CVODE/serial-vector/dense-matrix/dense-linear-solver dylibs are
ARM64. These are observed local fingerprints, not portable distribution pins:

| Dylib under `/opt/homebrew/lib/` | SHA-256 |
| --- | --- |
| libsundials_core.dylib | c5aadbfe1538e8f2f313fb972ee4e7a70300ec93ab14ef12abeee03bfa704336 |
| libsundials_cvode.dylib | 1b4874a197c8786797c45a3c7660baea5589785272733feb845d05737854d4c7 |
| libsundials_nvecserial.dylib | 74a3a56077f77297369c06a0018e74c0c2b21edafde0b980f9563c03693489bf |
| libsundials_sunmatrixdense.dylib | a9ff4db6e085316b11a0c9f45ce4ffc2fa34f93255192dc6ea7a5a83703708c6 |
| libsundials_sunlinsoldense.dylib | 8524b8f183b4e1bc1a98bf371b8c35a9245fb3b4b8fe4dcc5decfb5ae140298a |

The candidate may read those installed dependencies, not alter or upgrade them.
At compilation and launch, record resolved binary paths/hashes, header identity,
compiler version/flags and all linked libraries. Missing/mismatched dependencies
fail closed. Distribution later requires a separately reviewed portable package.

## Permission and provenance

libCellML and libOpenCOR are Apache 2.0; SUNDIALS 7.8.0 is BSD 3-Clause. These are
not noncommercial-only packages. Preserve their license/notice obligations and
the model's separate CC BY 3.0 authorship/change attribution. The downloaded
libCellML wheel contained no separately named license file, so a redistributed
runtime bundle must include the verified upstream license, not assume the wheel
already fulfills all packaging notices. libOpenCOR additionally bundles libraries
including LGPL components; evaluate actual distribution obligations before
shipping that alternative. No participant-data permission follows from any of
these software licenses.
[libCellML license](https://github.com/cellml/libcellml/blob/v0.7.0/LICENSE),
[libOpenCOR license](https://opencor.ws/libopencor/licensing.html),
[SUNDIALS license](https://raw.githubusercontent.com/LLNL/sundials/v7.8.0/LICENSE),
[libOpenCOR dependency notices](https://opencor.ws/libopencor/developer/thirdPartyLibraries.html).

Only public small source/header/license files and the 1.8 MB wheel were downloaded
to `/tmp/livemore-beard-units.13K8iX`. No operational install occurred.

## Next bounded implementation proposal

1. **Red conversion-contract tests first.** Extend the existing source audit
   without removing the rejected-Myokit result. Require exact source/library
   pins, 28 unit definitions, the three irreducible dimensions, 339 declarations,
   all 65 MathML equations and 226 mapping edges. Enumerate every permitted
   1.0→2.0 change, including interfaces/metadata; keep original RDF/documentation
   in the provenance envelope. Round-trip strict 2.0 parsing must be issue-free.
   Unexpected parser messages, unit warnings, scaling changes, imports, missing
   identities or conversions stop this route.
2. **Independent dimensional and code-generation review.** Turn the read-only
   inventory comparisons into regressions, including invalid custom-unit sums,
   logarithms, derivatives and wrong connection units. Analyser warnings block
   admission even if code generation would succeed. Bind generated C to the
   exact source/conversion/generator hashes and a complete formal unit map.
   Resolve states by qualified variable identity/equivalence, never document
   order: the analyser reordered the 19 states. Generator output is numeric code,
   not a replacement for the unit-bearing source artifact.
3. **Native wrapper, technical fixtures only until reviewed.** A private worker
   uses generated `initialiseArrays`, computed-constant and `computeRates`
   callbacks with CVODE BDF, serial vectors and dense linear algebra. Do not
   retype reaction laws or recompute author constants elsewhere. Every native
   return code, allocation and generated quantity is checked. Verify the wrapper
   against a separately declared analytic technical ODE, invalid callback,
   timeout/cancellation and cleanup tests. Tests must prove complete 19-state
   initial-value transfer and observer mapping before any physiological advance.
   [Generator API](https://raw.githubusercontent.com/cellml/libcellml/v0.7.0/src/api/libcellml/generator.h),
   [CVODE 7.8 usage contract](https://sundials.readthedocs.io/en/v7.8.0/cvode/Usage/index.html).
4. **Separate numerical authorization.** Retain the original proposal's
   two-tolerance 0–300 s matrix, tight repeat and 150 s checkpoint comparison,
   comparison floors, conservation/domain checks and 120 s/1 GiB/64 MiB per-worker
   limits. Before running, lock the exact wrapper/compiler/solver/source
   manifest and independently review initialization, sampling, checkpoint and
   logarithm-domain handling. No clipping, parameter fitting or post-hoc
   tolerance relaxation. Record all failures. No arbitrary source imports,
   callbacks or downloaded script execution; only the pinned local model.

Successful dimensional conversion and numerical convergence will still **not**
resolve disabled AK, water-fraction and capacitance variants versus the paper's
correction. They qualify only the pinned PMR implementation's numerical
execution. Original figure-replication conditions/reference arrays, source-variant
resolution, arctigenin free-exposure/activity mapping, human tissue coupling,
individualization and physical validation remain separate unpassed gates.

## Acceptance and lesson

Current result: **a unit-preserving parser/code-generation path is demonstrated;
native physiological execution remains unperformed and unaccepted.** Request
approval for steps 1–3 as a bounded source/technical-worker increment, not the
physiological matrix or product activation.

Compounded lesson: warnings with superficially similar wording can have different
semantics. Myokit replaced custom dimensions with dimensionless units; libCellML
removed a legacy attribute while preserving the equivalent irreducible units.
Prove the resulting representation and its negative controls. Conversely,
libCellML can classify and generate a model despite unit warnings, so a successful
type/code-generation check alone is insufficient.

## Technical-worker resource clarification, approved for fixed fixtures

Steps 1–3 were approved by the parent reviewer; step 4 remains locked. During
red-first technical-wrapper construction, the current macOS ARM Python process
rejected `setrlimit(RLIMIT_AS, (1073741824, 1073741824))` with
`ValueError: current limit exceeds maximum limit`. An independent isolated
resource-setter probe reproduced this while core/file/CPU limits succeeded. The
native child did not reach a generated callback. Preserve this failed launch.
This is a platform/resource-assumption failure, not evidence against a biological
model. Do not silently catch the failure and advertise an applied address-space
limit.

Proposed amendment applies **only to the two fixed analytic technical fixtures**:

- Replace the unsupported address-space claim with a **sampled 1 GiB resident
  memory termination threshold**, using macOS `proc_pid_rusage`, flavor
  `RUSAGE_INFO_V2`, from `/usr/lib/libproc.dylib`. Read `ri_resident_size` in bytes;
  capture `ri_proc_start_abstime` and `ri_uuid` on first admission, then require
  identical process/image identity on every sample. Only the Popen-owned PID is
  queried. Read failure while the owned child is alive, unsupported OS/ABI,
  unavailable library, zero/changed start identity or invalid sample fails closed.
  No `ps`, guessed values or omitted-check fallback.
- The exact native declarations are in the active Apple SDK `libproc.h:111` and
  `sys/resource.h`'s `rusage_info_v2` (16-byte UUID followed by 18 unsigned 64-bit
  fields). Bind and check that 160-byte ABI; test the helper against the current
  owned process, without reading or logging any other process's data. Primary
  reference: [Apple rusage_info_v2](https://developer.apple.com/documentation/kernel/rusage_info_v2)
  and [Apple XNU resource declarations](https://github.com/apple-oss-distributions/xnu/blob/main/bsd/sys/resource.h).
- Request sampling at 10 ms; record actual maximum sample gap, sample count,
  peak sampled resident bytes and observed bytes above the threshold when
  terminating. OS scheduling can produce larger gaps and transient overshoot.
  This is **sampled soft protection, not instantaneous/hard memory isolation**.
  A future physiological/untrusted-model worker still requires separate review.
- Keep hard CPU 5 s, core-file prohibition, bounded stdout/stderr 64 KiB, native
  wall deadline, and a private 0700 workspace with 0600 artifacts. The fixed
  technical worker has no network/file/model-input API. Compile has a separate
  30 s deadline and 64 MiB file bound, not a claimed 1 GiB address-space cap.
- On cancellation, deadline, memory, identity, sampling, output or callback
  failure, stop the process group created exclusively for that owned invocation
  and reap its leader; preserve original failure evidence. Record ownership,
  termination and actual cleanup results, not a success flag inferred from a
  requested signal. Check the process-group kill path in regression tests; no
  external service/process termination. Interrupt handling must also clean up.
- Preregister red tests for exceeded RSS, changed PID/start/image identity,
  sampler error, real technical timeout/cancellation and checked native results.
  Neither successful fixture tests nor this amendment authorize Beard
  `computeRates`, physiological time advance, parameter changes or dose mapping.

Two earlier compile-only failures are also retained: direct compiler invocation
with a scrubbed environment needed the explicit Xcode SDK; the installed
MPI-enabled SUNDIALS headers expose `MPI_COMM_NULL`, requiring the already
fingerprinted MPI library even with serial vectors. The corrected command now
records the SDK identity and MPI linkage. No global dependencies were changed.

The parent reviewer read lines 231–284 and approved this clarification for the
two fixed analytic fixtures, not Beard callbacks or arbitrary models. The
red-first implementation and actual native results are recorded in
[technical verification](../BEARD_UNIT_PRESERVING_TECHNICAL_VERIFICATION.md).
Final maker test packet: 63 passed in 13.92 s. Independent implementation review
is pending; step 4 and all product activation remain locked.

### Independent worker review: required corrections before acceptance

Independent reviewer ran the 63-test opt-in analytic/source packet (14.39 s)
without Beard compilation or callbacks and identified three P2 defects. Root
reviewed the named code and approves the following narrow red-first corrections
to the technical worker, its dedicated tests and evidence document only:

1. A reaped/exited group leader cannot be used as proof its subprocesses exited.
   Track the invocation-owned process group and verify/terminate its surviving
   descendants on failure, including compiler children. Do not signal an
   unrelated reused group or enumerate/log unrelated process data. Preserve the
   original failure separately from uncertain/failed cleanup. Include an actual
   fixed technical child/descendant case, not just a mocked successful kill.
2. A failed `failure.json` write must not replace the original `NativeError`.
   Retain its original code/details and report evidence-persistence failure as
   a separate bounded field; the CLI must still return a controlled failure.
   Red test the injected storage failure and missing/partial evidence outcome.
3. Validate the compiled binary's direct dependencies against the captured
   resolved transitive library inventory before any native launch. Reject an
   unreviewed path, unresolved loader alias or different library identity.
   Merely recording `otool` output is not enforcement. Add negative linkage
   controls and retain the real fixed-analytic execution checks.

No change to CellML source, constants, numerical limits or fixture-only dispatch
is authorized. Step 4 remains locked pending separate preregistration and
independent acceptance. Maker evidence must be superseded by a new reviewed
packet without erasing the initial findings or failed attempts.
