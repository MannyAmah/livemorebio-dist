# Beard precision v2: locked implementation review packet

Date: 2026-09-08. **Candidate code only; independent implementation review pending.
No v2 C compilation, native initialization, source-expression evaluation or solve
has occurred.** No product route, participant mapping or compound-dose model added.

## Authority and frozen evidence

Root and the independent reviewer read and cleared the complete numerical
[v2 preregistration](2026-09-08-beard-native-precision-v2-preregistration.md), SHA
`68ff48a84ce6ca51828dbc2034322ada2c51ac4875b53a6fb8f1f6b4685ea758`.
Root then authorized **red-first implementation only** in new
`tools/beard_precision_*` files and dedicated tests. A separate code/runtime/driver
review and explicit once-only execution decision remain required. This document
records that implementation authority; it does not enable execution itself.

V1 protocol, wrapper, source, evaluator, result arrays, failed matrix and
diagnosis remain unchanged. The v1 B0/B1 discrepancy is not reclassified. New
precision settings cannot establish physical accuracy, arctigenin potency,
ATP export under the invariant-zero boundary or individual-human applicability.
All six required experimental programs remain active, not completed by this work.

## Candidate layout and exact scope

| File | Role |
|---|---|
| `tools/beard_precision_analysis.py` | Frozen seven-branch table; H3 candidate; five acceptance comparisons and three historical diagnostics; exact complete grids, per-quantity counts and unchanged floors; per-output solver-clock/configuration checks. |
| `tools/beard_precision_execution.py` | False-by-default new gate, source/runtime/reused-code pins, fixed dispatch, historical B1 hash validation, H3 checkpoint freezing, bounded native supervision, fail-stop orchestration and retained evidence. |
| `tools/beard_precision_worker.c` | Uncompiled new wrapper; unchanged source/domain checking functions; approved precision/hmax settings, actual configuration return codes, per-output internal-time/last-step/order/count diagnostics, full-state/constant checkpoint checks before first RHS. |
| `livemorebio/tests/test_beard_precision_analysis.py` | Software-array and clock-policy tests; no model source/evaluator/native calls. |
| `livemorebio/tests/test_beard_precision_execution.py` | Static wrapper/source preservation, locked entrypoints, mocked process/failure scheduling, exact parser/checkpoint and evidence tests. Technical records are not model results. |

The new wrapper's `SourceData`, identity checks, initialization-output routine,
domain checks and generated-rate callback functions are byte-identical to the
frozen source wrapper. A test checks that entire shared region. Source-generated C
and source equations are not copied into a new biological implementation. Native
settings differ only as preregistered. The two-state technical wrapper retains
its `STATE_COUNT > 2` rejection and is not repurposed to run this model.

The new orchestration reuses the exact frozen original-MathML evaluator,
conversion/admission, per-unit expression/conservation analysis and reviewed
process-ownership/library primitives. Its source-specific supervisor is copied
with the v2 mode/gate/binary names; original worker files are untouched. The
loaded module/path/runtime identity is still a required later one-off driver
check, not a claim made by merely rereading a mutable checkout.

### Fixed execution contract, currently locked

`run_matrix(raw, *, historical_result, historical_stdout, cancel=None)` accepts the
exact pinned source bytes and exact retained B1 evidence bytes, not arbitrary
solver settings/modes, source paths, participants or interventions. It is blocked
before file creation unless both the new precision gate and the independent
source evaluator gate are enabled in a separately authorized process. Importing
this module leaves its gate, v1's gate and the evaluator gate false. No CLI/env
override or product integration exists.

Candidate H3, repeat R3 and H3→K3 restart are fixed before results. K3 requires
H3's complete clean local admission; uncertainty cannot supply its checkpoint.
The checkpoint freezes all19 states,47 constants,12 computed constants, units,
source/protocol/runtime identity, full parent input and original H3 raw hash.
The native wrapper verifies restored state/constants before the first RHS; the
parser/analysis verifies the exact first recorded states/rates/algebraics afterward.
This restores state, not CVODE multistep history.

Each successful output includes requested time separately from sampled CVODE
internal time and last accepted step/order/count. Initial output explicitly says
`not_advanced`. Actual setter/getter success codes are required. The final summary
must agree with the last sample. Recorded statistics do not constitute a log of
every internal accepted step. Compiler wall/file/core protections are retained;
compiler RSS/hard CPU protection is not claimed. Native RSS remains sampled soft
protection, not a hard1GiB isolation boundary.

Native/source/domain/resource/cleanup failures stop later invocations and mark
their dependencies. A numerical difference between otherwise admitted branches
does not alter the fixed remaining schedule; matrix acceptance still fails.
No retry, post-hoc tolerance change or candidate selection is implemented.
Historical B1 comparisons are required diagnostics only, not acceptance against
the old failed precision regime.

## Red/green evidence and checks actually performed

1. New analysis tests were written first and produced24 missing-module errors;
   after implementation,24 passed. They include a software fixture with all states
   equal but one small net flux failing its original output gate.
2. New execution tests first produced13 missing-module errors. A whitespace-only
   shared-code-region mismatch was corrected in the new wrapper, preserving the
   original file exactly.
3. Five further red checks exposed absent failure-record handling and an
   initialization-only parser accepting claimed CVODE work. New v2 failure records
   now retain the original error identity/time/unit/stage, observed raw hash and
   process/cleanup evidence. I2a requires zero RHS/solver work; I2b exactly one
   source call and no solver advance. No source was executed to test these claims.
4. Added full3001-row technical parsing, exact checkpoint/detachment/tamper tests,
   all seven fail-stop locations, fixed-H3 scheduling despite comparison failure,
   uncertain-H3 restart blocking and mocked process-identity/cleanup checks.
5. Dedicated v2 packet: **60 passed in1.16s**. Combined new and preserved source,
   evaluator, conversion and worker packet: **195 passed,32 explicitly gated tests
   skipped in1.14s**. No native/conversion/source-data opt-in was enabled. Skip
   counts are not passes, and this is not native acceptance.
6. A separate fresh `-I -B` read-only Python process verified exact retained B1
   result/stdout hashes and reparsed its3001 rows through the original parser.
   It reported `diagnostic_only`, v1 matrix `FAILED`, and all three gates false.
   It did not load/evaluate a source expression or invoke a compiler/solver.

Tests ran through `tools/run_review_tests.py` using the managed Python3.11 runtime
and fresh isolated test stores. No operational dataset, service, enrolled person,
physical device or credential was read or modified. The passing packet is a
maker's test report, **not** independent grading or permission to execute v2.

## Frozen candidate hashes

| Artifact | SHA-256 |
|---|---|
| Precision analysis | `4e0a85fcba44192c4a0c345bb59f740ee6ebceaa76a37a17f4bd23de998863a6` |
| Precision execution | `40baaacb0053bc510a9f1657ce4c8fa97e1a9d2553b31104155ceb59c30ac17b` |
| Precision C wrapper | `7624b4e43be9c7512fc3f4b8de8bcfe912219f64209abc7d74f63cdfd1a2fffc` |
| Analysis tests | `ddb61731f478b950fec604bbc77c219fcd9d228c85eb1c140a4d333876421638` |
| Execution tests | `21eec4fe181d0a118cba2b09a9217a43ea89771a680a0328476f1b5b70d4ce67` |
| Retained B1 result bytes | `517b660902e58c8ccd4c564eb79fa9c0ed583cabdcfb0a56ece7fcd834bf9516` |
| Retained B1 stdout bytes | `7ab07ea42259b00d8c455c85785ac4876f2e20f1c649a582243a9b6b311ce997` |

The eight reused file hashes are explicit in `REUSED_HASHES` and checked by the
candidate tests; source/runtime/protocol pins remain those in the approved v2
preregistration. No binary hash is available: **no v2 binary has been compiled**.

## Independent review handoff and remaining gates

Reviewer should challenge candidate/repeat/parent fidelity, complete-grid and
unchanged per-unit gates, success versus uncertainty/missingness, exact source
and constant preservation, actual setter/getter return-code handling, normal-mode
clock semantics, stale-code/library detection, process lifetime/cancellation and
failure evidence. Inspect the whole wrapper and orchestration, not only tests.

Pending: independent code review; any red-first corrections and refreshed hashes;
private once-only driver with exact loaded code/source/runtime checks; root read
and execution authorization; actual fixed native matrix; independent raw-array and
resource review. Until then no v2 numerical result exists.

Lesson: an old solver setting, a preserved failure and a new prospective precision
method are separate evidence identities. Preserve the failure and frozen output
criteria; do not turn a candidate implementation or mock-process pass into a
scientific result.

## Supervisor correction candidate — independent re-review pending

The original candidate above remains preserved as review history. Independent
review reproduced two engineering P2s: the Darwin false/ESRCH/false exit transition
could lead to premature reaping without group proof, including the inherited
compiler path; a supervision exception could leave partial raw evidence and exit
status unbound in the failure receipt. The numerical contract was not changed.

Root read and approved the
[v2-only supervisor amendment](2026-09-08-beard-precision-supervisor-correction-amendment.md),
including a capacity-one unresolved-child anchor and rejection of every later
compiler/native/matrix entry before file creation. Root authorized red-first
**static/mocked implementation only**, not an actual child, compiler, source
evaluator or native invocation. Those restrictions remain in force.

The corrected precision execution module now has a shared private supervisor for
both exact fixed-command constructors. Compiler launch no longer reaches frozen
`native._invoke`; v1 files remain unchanged. Cleanup uses one3s budget for
observation-only proof stabilization, group inspection/termination and final reap.
The child stays unreaped while ownership is uncertain. Persistent uncertainty
retains one in-process anchor, reports failed cleanup and blocks later entries;
it does not claim that an uninspectable child stopped or survives Python exit.
A later one-off driver must treat that condition as nonzero `UNRESOLVED_CHILD`.

All process outcomes now carry observed-or-unavailable exit status and bounded,
hash-only stdout/stderr receipts. Whole-file, oversized-prefix, missing, unsafe,
changed and read-failure states are distinct. Only the original owner-only regular
single-link file identity is read; successful parsing receives exactly those full
verified stdout bytes. Compiler RSS stays explicitly unmeasured. Native RSS stays
sampled-soft, not a hard memory-isolation claim. Original safe failure details are
retained separately from cleanup, signal-restoration and evidence-read failures.

Correction evidence actually obtained:

- First new mocked packet:16 red failures. The native exit-transition fixture
  specifically observed old cleanup attempting reap before its mocked descendants
  were cleared; another native fixture exposed absent exit/hash receipt fields.
- The first correction passed its16 tests. Extended failure checks then found a
  pre-spawn metadata-error descriptor leak (red), which was corrected.
- Further red tests found that a secondary descriptor-close failure could mask
  the metadata error and a signal-handler restoration failure could bypass the
  receipt and second handler. Both are corrected. A separate compiler-argument
  test initially expected the wrong existing linker order; that test expectation
  was corrected to the preserved `sundials_core`-first order, not the command.
-34 dedicated supervisor tests now cover both stage policies, finite proof
  stabilization, never-signal/reap under uncertainty, second direct-entry blocking,
  complete/prefix/unsafe/missing/changed output, native failure categories,
  compiler argv/environment, exact success bytes and original-error preservation.
- Combined precision plus preserved source/evaluator/conversion/native-worker
  packet: **229 passed,32 explicit opt-in skips in1.26s** using the isolated managed
  review-test runner. No actual child/descendant, C compiler or physiological
  callback was executed. Actual OS behavior beyond mocked primitives still needs
  the separately authorized validation stage; these tests do not establish it.

Refreshed correction candidate identities (original hashes above are not erased):

| Artifact | SHA-256 |
|---|---|
| Precision execution | `45e7442b9e9872a2a62a67c47c0f7b77d1ae170c5ea0e9bd986ab187d251853d` |
| Existing execution tests, corrected old-guard assertion | `bec693e7d0eee76a456b06255aa1655c1b58a047ddc1cbb0f87e216aea6a03b7` |
| New supervisor tests | `45bc2c78a0cad9366ff53c6b2d80a918b9723191be77d13e10291a5d5dc08a9c` |
| Unchanged precision analysis | `4e0a85fcba44192c4a0c345bb59f740ee6ebceaa76a37a17f4bd23de998863a6` |
| Unchanged precision C wrapper | `7624b4e43be9c7512fc3f4b8de8bcfe912219f64209abc7d74f63cdfd1a2fffc` |

Every original reused file hash still passes the frozen-file test. Precision,
v1 execution and source-evaluation gates remain false on disk. No numerical v2
result or binary exists. This is the maker's correction report, pending independent
re-review and a separate runtime/once-only-driver execution decision.

Lesson: failure evidence is part of the experiment contract. An uncertain process
identity must not be resolved by reaping away the proof; a secondary evidence or
cleanup failure must not replace the original scientific/engineering outcome.
