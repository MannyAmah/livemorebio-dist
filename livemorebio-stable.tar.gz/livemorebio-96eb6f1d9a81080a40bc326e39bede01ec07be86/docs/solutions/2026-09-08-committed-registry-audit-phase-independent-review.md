# Independent registry regrade — earlier audit phases remain blocked

2026-09-08. Reviewer: release_redteam, independent of the registry maker.
**Blocked for integration.** No runtime or test source was edited during this
review. The prior maker reports, original independent findings and frozen failed
candidate remain unchanged. These are authored technical SQLite fault fixtures,
not findings of corruption in an operational registry.

## Exact checkpoint and review scope

Read the full [terminal correction plan](2026-09-08-committed-registry-terminal-correction.md),
[original independent findings](2026-09-08-committed-registry-transitions-independent-findings.md),
[original maker report](2026-09-08-committed-registry-transitions-implementation-review.md),
[corrected maker report](2026-09-08-committed-registry-terminal-correction-implementation-review.md),
committed-source interface, complete audit module, transition helpers/wrappers,
their existing `_audited` dependency, and all dedicated registry tests.

The following frozen hashes matched before and after the review:

| File | SHA-256 |
|---|---|
| `livemorebio/aegle/subjects.py` | `3778a837877b57623112549884a379930c348987942d83d1ed6d2e53d29dd51a` |
| `livemorebio/aegle/registry_audit.py` | `b21f01fdf1c79604c5565fee0f7d94d3b0bd11967b199bc97ec8a193de045e4e` |
| `livemorebio/tests/test_committed_registry_transitions.py` | `f3cb3a549b4e0c99ffb6096c838468399c19249047407201ca444195ce01b22e` |

Verified corrections: trusted append-origin audit bytes survive reservation
effects; mutation SUCCESS is followed by a complete intended-state comparison;
its failed-access completion protects a fresh raw baseline; structural preparation
does not construct a profile under authority; the standalone wrapper retains its
outside-lock admission. Those fixes are real but do not cover the earlier durable
audit commits below.

Separately, the root's source/preview test-only guard-exit refinement is sound:
`mark_committed` retains the actual guard-instance identity; that instance checks
complete publication before releasing authority, creation and manager locks.
Both registry stubs mark nonrollback outcomes. This is fixture-fidelity review,
not acceptance of server implementation.

## Independent test evidence and process limitation

Interpreter:
`/Users/emman/.local/share/livemorebio/current/source/.venv/bin/python`.
Worktree: `/Users/emman/Livemore/.worktrees/full-scope-recovery`.

The **corrected, permitted run passed388 / deselected4 in20.65s**, with one existing
Starlette warning. Private root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-t3m2om3o`.
It used the maker's seven files and four named lifecycle nodes, excluding the four
`real_process` bootstrap cases. Zero unexpected I/O/process attempts reached the
reviewer's barriers; one optional Git metadata lookup was refused into the
existing unavailable-metadata fallback. No actual Git child ran in this repeat.

Do not describe this as an independent392-pass run. The first direct-stdin repeat
used private root `livemore-research-review-lb2k338x`, reached failures, then its
60-second alarm ended the interpreter with exit142 before a pytest summary.
Inspection identified four inherited tests using
`multiprocessing.get_context('spawn')`, which bypasses a `subprocess.Popen`
monkeypatch. This first attempt is **not a no-child result**: its barriers did not
exclude those Python child launches. The tests contain bounded termination/join
cleanup, but this reviewer did not retain independent PID/start identities or
post-run process-absence evidence. No retrospective cleanup claim is made.
The limitation was immediately disclosed to root; no generic process cleanup or
operational-service action was attempted. These were bootstrap fixture children,
not native physiology workers.

The four excluded cases are the two parameterizations each of:

- `test_real_process_concurrent_candidates_create_only_one_authority`;
- `test_real_process_crash_preserves_orphan_key_or_pending_attempt`.

The final run added `BaseProcess.start` refusal and a low-level process audit hook.
This is the exact repeat setup and selection; it is retained for reproducibility,
not authorization to run a new experiment:

```python
import os, signal, socket, subprocess, urllib.request, sys
import multiprocessing.process
from tools.run_review_stack import prepare_review_environment

root, env = prepare_review_environment(inherited={
    k: os.environ[k] for k in ('PATH', 'HOME', 'TMPDIR', 'LANG', 'LC_ALL')
    if k in os.environ
})
os.environ.clear()
os.environ.update(env)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
blocked, metadata = [], []

def deny(*args, **kwargs):
    blocked.append('unexpected')
    raise AssertionError('Independent registry review forbids network/native/process work')

def process(command, *args, **kwargs):
    if command == ['git', '-C',
                   '/Users/emman/Livemore/.worktrees/full-scope-recovery',
                   'rev-parse', '--show-toplevel']:
        metadata.append('refused optional Git metadata')
        raise OSError('Authored unavailable Git metadata')
    return deny()

def audit(event, args):
    if event in {'os.fork', 'os.forkpty', 'os.posix_spawn', 'os.exec',
                 'subprocess.Popen'}:
        deny()

sys.addaudithook(audit)
multiprocessing.process.BaseProcess.start = deny
socket.socket.connect = deny
socket.getaddrinfo = deny
socket.create_connection = deny
urllib.request.urlopen = deny
urllib.request.OpenerDirector.open = deny
subprocess.Popen = process
import pytest
signal.alarm(60)
files = [
    'test_committed_registry_transitions.py',
    'test_subject_registry_audit_contract.py',
    'test_registry_bootstrap_contract.py',
    'test_registry_bootstrap_shape.py',
    'test_clinical_descriptive_registry.py',
    'test_real_cohort_contract.py',
    'test_selection_reconciliation_registry.py',
]
nodes = [
    'test_virtual_patch_binding_retains_admitted_protocol_version',
    'test_only_authoritative_twin_remains_active',
    'test_physical_patch_pairing_requires_active_consented_human_and_attestation',
    'test_active_twin_survives_registry_restart_and_physical_device_cannot_double_pair',
]
rc = pytest.main([
    '-q', '-p', 'no:cacheprovider', '-p',
    'livemorebio.tests.test_committed_registry_transitions',
    '-k', 'not real_process',
    *[f'livemorebio/tests/{f}' for f in files],
    *[f'livemorebio/tests/test_subject_lifecycle.py::{n}' for n in nodes],
    '--tb=short',
])
print('REVIEW_IO_COUNTS', {
    'unexpected': len(blocked), 'optional_git_refused': len(metadata),
})
raise SystemExit(rc)
```

## P1 — preparation's terminal audit can persist a clinical side effect

Confidence10/10. `subjects.py:1157–1162` reads through `_audited`; its
`subjects.py:624–625` terminal write/commit occurs after the snapshot without an
unchanged-state check. Install a private trigger before calling preparation:

```sql
CREATE TRIGGER authored_phase_fault AFTER INSERT ON registry_audit
WHEN EXISTS (SELECT 1 FROM registry_audit_reservations)
BEGIN UPDATE records SET version=999; END
```

The BEGIN insert has no reservation yet, so the trigger changes only the
preparation completion in this one-record fixture. Actual retained output:

```json
{"after_version":999,"before_version":1,"case":"prepare_terminal_record","clinical_unchanged":false,"outcome":"RETURNED_PREPARATION"}
```

This violates preparation's read-only contract and can leave storage changed even
if the server subsequently rejects candidate construction. This is about the new
preparation caller, not a claim that unrelated existing audited APIs were covered
by the previous correction.

## P1 — mutation BEGIN can commit a side effect before its later rejection

Confidence10/10. `subjects.py:1278–1284` commits BEGIN before comparing the
prepared record set. Install the same trigger after successful preparation, but
use `WHEN NOT EXISTS (SELECT 1 FROM registry_audit_reservations)`. This changes the
new mutation BEGIN without corrupting its audit bytes or reservation. Actual:

```json
{"after_version":999,"before_version":1,"case":"commit_begin_record","clinical_unchanged":false,"outcome":"REGISTRY_STORAGE_UNAVAILABLE"}
```

The mutation transaction detects the indexed/plaintext mismatch and rolls back,
but the earlier BEGIN transaction already persisted version999. A fixed rejection
therefore cannot be represented as preserving the original selected source.

Both probes above ran once in fresh separate fixture databases under:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-iy2qef6g`.
The actual common operations were:

```python
from pathlib import Path
from contextlib import closing
from livemorebio.tests.test_committed_registry_transitions import (
    SubjectRegistry, KEY, seed, prepare, rows, no_network_or_models,
)
# Both cases used one fresh prepare_review_environment, network/process refusal,
# and no_network_or_models.__wrapped__(pytest.MonkeyPatch()) before this body.
for case in ['prepare_terminal_record', 'commit_begin_record']:
    registry = SubjectRegistry(Path(root) / (case + '.sqlite3'), key=KEY)
    target = seed(registry)
    before = rows(registry)
    if case == 'commit_begin_record':
        prepared = prepare(registry, 'activate', target)
    condition = 'EXISTS' if case == 'prepare_terminal_record' else 'NOT EXISTS'
    with closing(registry._connect()) as connection, connection:
        connection.execute(
            'CREATE TRIGGER authored_phase_fault AFTER INSERT ON registry_audit '
            'WHEN ' + condition + ' (SELECT 1 FROM registry_audit_reservations) '
            'BEGIN UPDATE records SET version=999; END')
    # Call prepare(...) for the first case, commit_prepared_transition(prepared)
    # for the second; retain only safe outcome/version/unchanged metadata.
```

Here `KEY` names the existing authored test fixture constant, not an operational
credential. The two cases shared the one private review environment, not a
database. The SQL statements and resulting metadata above are the executed
reproductions; this document did not rerun them.

## P2 — exact reservation is not rechecked before protected decryption

Confidence10/10. At `subjects.py:1285–1292`, the reacquired writer checks authority
and the original BEGIN bytes, but not its exact remaining reservation. A fresh
technical connection subclass deleted the reservation after acknowledging the
first commit, using a second connection before the mutation writer was acquired:

```python
class ChangeReservation(sqlite3.Connection):
    commits = 0
    def commit(self):
        self.commits += 1
        super().commit()
        if self.commits == 1:
            with closing(sqlite3.connect(registry.path)) as external, external:
                external.execute('DELETE FROM registry_audit_reservations')

def connect():
    connection = sqlite3.connect(registry.path, factory=ChangeReservation)
    connection.row_factory = sqlite3.Row
    return connection

# Installed after preparation on this fixture's registry._connect only.
# The _open wrapper counted calls and delegated to the original authored decrypt.
```

Actual output:

```json
{"case":"reservation_deleted_between_begin_and_protected_read","clinical_unchanged":true,"outcome":"REGISTRY_AUDIT_UNAVAILABLE","protected_decrypt_count":1}
```

Private root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-raz30apb`.
This probe included the additional low-level process barriers. No mutation was
confirmed, but the protected read happened after its reserved completion ceased
to exist. The verification must precede `_transition_snapshot`/`_open`, not wait
until `finish`.

## Required next gate and lesson

The separate [audit-phase correction proposal](2026-09-08-committed-registry-audit-phase-correction-proposal.md)
specifies shared bounded primitives for transition preparation, mutation and
checked startup reads. It requires root review before implementation; this
report grants no code, browser, service or experiment authorization.

No participant data, source equations, model inputs, numerical gate, OSP report,
Atlas cache or six-program identity was modified. R01–R51 remain unchanged.
Lesson: audit writes are writes at every durable phase, not only mutation SUCCESS.
An intact BEGIN row alone does not prove that its completion is still reserved.
The review checklist informed the independent read; unavailable gbrain/CE tools
were not invoked or claimed.
