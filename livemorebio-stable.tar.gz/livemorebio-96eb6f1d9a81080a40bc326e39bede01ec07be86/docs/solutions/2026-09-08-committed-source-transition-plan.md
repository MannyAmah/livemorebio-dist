# Committed-only legacy source transitions

Date: 2026-09-08. Status: root has read all268 lines and cleared the bounded
architecture and red-test plan; exact internal helper interface remains to be
agreed before implementation. Existing frozen packets remain under review.
Author: independent source reviewer; authorship is not approval of this plan.
This document authorizes no runtime edit, model execution, service operation,
registry access, device operation or release.

## Scope and prior decisions

Finish the existing source-authority migration for numerical twin activation,
Patch binding, explicit reference-preview replacement and startup restoration.
Reuse the committed-selection design in section 11 of the
[clinical availability amendment](2026-09-08-clinical-context-availability-amendment.md)
and the [reconciliation contract](2026-09-08-selection-reconciliation-contract.md).
The [full R01–R51 register](2026-09-08-full-scope-recovery-plan.md) remains active,
including insulin plus five candidate programs, complete workflows and visual
acceptance. This packet principally supports R01, R15, R16, R30, R31 and R45–R48;
it does not substitute for those requirements or close them by test count.

Local prior art also includes the clinical-context dispatch plan, execution
cleanup race tests, current-source Cendos plan, and
[registry bootstrap proposal](2026-09-08-legacy-registry-audit-bootstrap-proposal.md).
The engineering-plan review skill informed the dependency and failure matrix.
gbrain, sequential-thinking and Compound Engineering tools were not callable in
this review context; no remote-memory or CE run is claimed.

## Source findings motivating this packet

These are source-traced hazards, not newly executed reproductions:

| Current seam | Consequence to expose with a red test |
|---|---|
| `server.activate_twin` builds from a preflight record, then calls version-only registry activation inside `authority.mutation()` | A same-version authenticated edit can pair old candidate parameters with newly committed identity; a rejected transaction already rotated generation. |
| `SubjectRegistry._audited` can raise around commit acknowledgment | Legacy callers do not reliably distinguish rollback, confirmed commit and uncertain commit; memory and SQLite can disagree. |
| `server.bind_twin_patch` nests `mutation()` inside `observation()` | Invalidation/adapter cleanup can run while the outer authority lock remains held; `int(expected_version)` also admits numeric aliases. |
| `base`/`life_system` preview branches construct inside the authority scope, then clear the active registry pointer | Expensive numerical construction holds a shared lock, and a failed clear can still fence the old source. Note preview has the same storage boundary even though construction is outside the lock. |
| `_restore_active_subject` and the absent-selection startup preview do not finally confirm their first read | Pointer/version/content changes during construction can publish a stale restored person or an unjustified preview. |

The four-field active-identity checks in read/telemetry consumers remain useful,
but cannot prove that a candidate was built from the exact committed record.
This packet adds that missing write-side proof; it does not weaken those checks.

## Smallest shared contract

Keep the existing routes and success payloads. Add a narrowly typed internal
prepared-transition value and registry commit helper for the three fixed write
kinds: activate, bind, clear-for-preview. Do not build a generic transaction
framework, introduce a second registry or accept a transition kind/hash from HTTP.
Startup is a checked read, not a fourth registry mutation. Existing standalone
registry callers retain their signatures through wrappers, but those wrappers
must use the same validation and commit-outcome rules, not an unsafe legacy path.

The detached preparation contains the complete canonical authenticated target
record when applicable, the checked active-pointer state and record, the exact
rows/indexes the operation may change, expected generation, exact resulting
record(s), frozen timestamp and server-owned request UUID. Capture source identity
under authority before construction. A missing pointer is an explicit value;
a present missing/inactive/incoherent target is an error, never equivalent to None.
Validate record/index coherence and the allowed ACTIVE topology. Do not silently
repair additional ACTIVE rows or demote rows that were absent from preparation.

The final comparison is exact canonical content plus relevant SQL identity/index
fields, not Python's bool/int equality, an ID/version tuple or a caller digest.
Use strict canonical JSON and detached immutable bytes/values; reject mutation of
the prepared result or its expected inputs. No plaintext clinical snapshot, hash
or prepared value is added to logs, public errors or an unencrypted receipt.
Only the actual intended rows are rewritten on success; legacy unrelated
ciphertext, record hashes, AAD, idempotency keys and saved histories stay intact.

### Admission and precomputation

1. Authenticate and parse the complete bounded, duplicate-rejecting body before
   source capture. Activation accepts exactly `expected_version`; binding keeps
   its existing documented field set and semantic policy. Both HTTP and direct
   registry entry points require `type(expected_version) is int` and value >= 1.
   Reject bool, float, string, null, duplicate and unknown fields before writes.
   Keep existing preview modes; malformed input does not advance generation.
2. Obtain audited, detached registry evidence and a coherent current generation.
   Confirm the current in-memory subject and checked registry selection agree
   in all four identity fields before preparing a replacement; a known mismatch
   is not permission to overwrite either side. Resolve through the existing
   uncertainty/reconciliation contract. Startup has no prior confirmed subject.
   Validate the source-specific model context and existing admission/consent
   rules. All new authority-dependent writes reject DENY_ALL; only the existing
   explicit reconciliation operation can resolve it. Never bypass uncertainty
   by selecting a convenient healthy preview.
3. Outside authority, manager, manager-creation and registry transaction locks,
   construct a candidate if needed and prepare its full state, availability,
   summary, empty actions/observations where appropriate, next generation and
   success/error responses. `AegleTwin.__init__` executes models today; describing
   this as a cheap metadata constructor would be false. Never call it, its
   recomputation, or `candidate.state()` in the final commit interval.
4. Do not publish, mutate the old model or launch a continuous execution while
   preparing. Candidate failure leaves the old source unchanged. Current
   AegleTwin/CardiacCell have no explicit close API: do not invent one or claim
   process cleanup from dropping Python references. Any actually owned adapter
   handle is disposed through its existing reviewed lifecycle outside locks.

### Final transaction and publication

```text
strict admission -> audited immutable inputs + current generation
                         |
                construct/project outside locks
                         |
 authority -> creation lock if needed -> manager -> registry writer transaction
  recheck generation + authority token + exact pointer/records/write set
  apply only prepared changes + reserved success audit -> confirm DB commit
       | confirmed rollback       | uncertain           | confirmed commit
       | keep old source          | DENY_ALL             | assign prepared state
       |                          |                      | + permitted generation
       +--------------------------+----------------------+  release all locks
                     old-generation invalidation/owned cleanup if fenced
                                  -> fixed acknowledgment / inspect-required
```

Use `ModelSourceAuthority.commit_guard()`, not `mutation()`, for this family.
Final registry access uses the existing reserved, encrypted BEGIN/result audit:
BEGIN is durable before clinical decryption; the final writer transaction checks
the captured audit authority token before decryption or mutation and checks it
again at completion. Reuse the established audit schema/actions and UUID
correlation; any necessary allowlist addition needs review, not a parallel log.
The terminal reservation must survive quota pressure/crash without fabricating
completion. A failed access may retain its audit while writing no clinical rows.

Under the final writer transaction, compare the entire prepared evidence and
existing admission conditions, not just expected_version. A source generation
change or exact-record mismatch conflicts before writes. Compute the intended
target version increment, demotion, binding index and pointer result once; the
stored result must equal the precomputed result used for candidate attribution
and acknowledgment. Sealing and SQLite writes occur here; native work does not.

On confirmed commit, assign the precomputed permitted generation, authority,
state, availability and actions while the manager/authority locks still exclude
in-flight initialization/frame publication. Do not perform serialization,
network/bus I/O, durable execution-store invalidation or adapter close between
the registry acknowledgment and these assignments. Transfer old state references
to a local retire holder first so a finalizer is not implicitly invoked by the
last reference being dropped inside the commit locks.

After all locks are released, invalidate only the captured old generation and
perform existing bounded owned cleanup. No late cleanup/finalizer may clear the
new selection, close a new worker, restore the old generation or release ownership
without confirmed cleanup. Bus publication is best effort after the fence; current
Cendos source capture and physical observation admission keep their independent
authority checks. Concurrent later transitions may supersede the acknowledged
record; the response confirms this operation, not perpetual current selection.

## Per-route preservation

| Operation | Confirmed publication |
|---|---|
| Numerical `/api/twins/{id}/activate` | Candidate built from the exact preflight record; final committed record has the planned lifecycle/version. Install its fresh numerical state and empty prior-person observation/action view. Unsupported context remains an explicit model-context rejection, not healthy activation. |
| Selected twin `/api/twins/{id}/patches` | Preserve the existing model object/parameters and admitted observations. Publish only the confirmed binding/version/availability identity with a fresh source generation; no constructor or self-calibration. Physical binding requires the authoritative pointer and full record to identify this selected REAL_HUMAN, not lifecycle alone. |
| Unselected twin binding | Confirmed binding or confirmed rejection leaves active generation/model/frames/ownership unchanged. Existing mode/consent/device-uniqueness policies remain; no device command or telemetry is emitted. |
| Explicit base, LIFE System and note previews | Prepare the existing reference/synthetic candidate and response outside locks, then atomically confirm and clear/demote the exact old selection. On success install subject=None with explicit preview attribution, fresh generation, cleared prior-person observations/actions. Note extraction is not governed human onboarding or a third-party PHI authorization. |
| Startup restore or truly absent-pointer preview | Prepare outside locks, then use audited exact active-selection confirmation and commit guard before memory publication. No registry selection/version/ciphertext rewrite. Recheck initialized/current generation so a concurrent operator selection wins. Unsupported restored humans stay inspectable with tw=None and explicit unavailability. |

Startup storage/key/audit failure is operational uncertainty, not a missing model
binding or proof of no active person. Keep authority DENY_ALL and the static app,
auth, descriptive onboarding and independently available audited History usable;
do not crash the whole UI or manufacture a preview. A real absent-pointer outcome
still requires final confirmation after candidate preparation. Startup must not
reconstruct an old executable source from an uncertain transaction on restart.

Ordinary meal/drug actions retain their separately reviewed mutation semantics;
this is not permission to refactor all stimulus behavior or change any mechanism,
parameter, unit, time axis, default trajectory, wire bytes or observation claim.

## Outcome and recovery rules

- **Confirmed rollback/precondition failure:** old state, generation, producer
  admission, retained frames and ownership are exactly preserved. Return existing
  fixed validation/conflict codes or `REGISTRY_STORAGE_UNAVAILABLE`, with current
  request UUID/private no-store headers. A failed audit record is not a clinical
  mutation. Discard speculative candidate/response objects outside the locks.
- **Confirmed commit, later cleanup/storage failure:** retain the committed new
  identity and fence. Use the existing fixed
  `SELECTION_COMMITTED_CLEANUP_UNCONFIRMED` contract; History and explicit Stop
  cleanup remain accessible. No automatic retry, rollback or old physiology.
- **Commit or rollback acknowledgment uncertain:** transaction-ended is not proof
  of rollback. Only an exact read of this attempt's retained row/index changes and
  terminal audit bytes/identity captured before the attempted commit can establish
  commit. They must belong to the same transaction; matching the current record
  version or a historical SUCCESS alone is insufficient. This is a bounded
  ciphertext/metadata confirmation, not unaudited clinical decryption, and adds
  no new audit payload field or persistent receipt table. Never repeat the write to find
  out. Otherwise install DENY_ALL under the same manager guard and return
  `SELECTION_COMMIT_UNCONFIRMED`. Speculative identity cannot be exposed as active.
  The existing explicit reconcile-selection route authoritatively rereads; it
  does not retry activation/binding or reconstruct an unconfirmed preview.

The proposed conservative rule applies DENY_ALL to any uncertain mutation in
this family, including an unselected binding whose completion cannot be proved.
It does not fence a confirmed unselected binding or confirmed rollback. No new
binding-specific recovery database/API is proposed. Authenticated observation-only
selection remains independent of numerical readiness, but person-dependent
physical admission stays blocked during selection uncertainty before watermarks.

## Bootstrap and supported-writer dependency

Coordinate with the registry/bootstrap owner before touching `subjects.py` or
`registry_audit.py`. The proposed/current maker seam is
`registry.audit.check_authority(connection, reservation=None) -> str | None`.
Its trusted hook checks the bootstrap proof/binding inside the writer transaction;
the reservation token binds the authority captured at BEGIN, without changing
normal audit ciphertext/AAD. A product writer cannot use standalone unbound mode.

`ReferenceCohortService` uses the same database but currently opens direct registry
connections. Its initialization, preview audit, both creation/idempotency phases,
summary/member-page/member-detail transactions must acquire the writer transaction
and invoke the same authority check before `_record`/`registry._open`, member
`_unseal`, audit or writes. A check before the transaction is insufficient.
Its existing access-audit obligations also remain; a token check is not an access
receipt. This supported-writer integration is an explicit unimplemented dependency
owned by the registry/reference-cohort lane, not a completed property of this plan.

Bootstrap adoption/recovery policy, wrong-key first-access behavior and unsupported
old-writer quiescence remain governed by the separate reviewed bootstrap packet.
No service stopping, recovery bypass or key/record rewrite is authorized here.
Do not claim a process-local authority lock synchronizes arbitrary external SQL
writers or makes memory and SQLite a distributed atomic transaction.

## Red-first acceptance packet

Use new isolated technical fixtures; no participant store, native solver, HTTP
service, browser or device is needed for the first red unit/ASGI packet. Trap
constructors and native methods so accidental real evaluation fails the test.

| Test group | Required assertions before green |
|---|---|
| Admission | Strict direct/HTTP versions including bool/float/string/null/duplicates; malformed binding/activation rejects before registry writes, constructor or generation change; auth and current request UUID preserved. |
| Full evidence | Pause after preparation, change target content at the same version, active pointer, demotion row or bootstrap authority; exact conflict, no candidate publication or automatic retry. Mutating caller-owned/prepared dictionaries cannot alter the committed result. |
| Rollback | Inject validation, audit reserve, seal/write and confirmed commit rollback failures in activate/bind/preview; exact old state/generation/frames/OS ownership preserved, failed audit bounded. |
| Commit uncertainty | Commit then raise, fail exact recovery read; DENY_ALL immediately rejects prepare/start/resume/renew and late initialize/frame commit. Current views cannot advertise old/candidate ready identity; physical replay watermark untouched. Reconcile confirms whichever record actually committed. |
| Cleanup | Successful commit followed by first/later invalidation get/update or close failure retains new identity, fixed outcome and cleanup owner. Block old cleanup while a later transition succeeds; no late assignment or close of its worker. |
| Lock interval | Constructor, candidate state projection, adapter close and old-state destructor assert no authority/creation/manager/registry commit lock held. Include the old nested active-binding case and manager-factory race. Only assignments follow confirmed DB commit under the guard. |
| Binding | Exact record+pointer agreement for physical binding; same device uniqueness and unchanged wire hashes. Selected version bump invalidates old execution while preserving model/observations; confirmed unselected binding does not. Lost HTTP acknowledgment leaves the committed binding intact and the client uncertain, with no implicit POST retry or fabricated original acknowledgment from a later GET. |
| Startup/preview | Existing unsupported human, genuine absent pointer, malformed/present-missing target, storage/audit failure, and pointer/content change during constructor. No fallback or stale publication; concurrent initialization/selection publishes once; restored rows/ciphertexts remain unchanged. |
| Supported writers | Already-open ReferenceCohortService across authority adoption/change cannot decrypt/write with stale authority. Exact same-connection ordering includes initialization/implicit preview audit and both create phases. Wrong-key and quota behavior remain fail closed. |
| Preservation | Existing selection/reconciliation, clinical SDK/UI, source races, continuous lifecycle/cleanup, signed v2/v3/physical observation, Cendos and frozen-cohort tests remain meaningful. No numerical fixture/hashes or old audit AAD changed. |

## Ownership, sequence and review gates

1. Root reviews this plan and resolves the conservative uncertain-binding policy.
   Registry owner freezes bootstrap/helper signatures and assigns the supported
   ReferenceCohortService writer integration before overlapping edits.
2. Root owns new transition tests/server integration; registry owner owns prepared
   record/final transaction/outcome tests and helper. Agree exact internal types
   before either edits the shared registry. Reuse model_source/execution contracts;
   change them only if a new failing test proves an approved seam insufficient.
3. Capture actual red results, implement by route family, then independently
   review full functions/consumers and run isolated regression packets. Measure
   constructor exclusion and bounded registry lock time without inventing an
   arbitrary latency success threshold or benchmarking unapproved biology.
4. After source freeze/root approval, independent real-browser and attached
   terminal QA must cover activation, selected binding, explicit preview, restart,
   unavailable History and safe reconciliation using technical data. Preserve
   old failed evidence; no release acceptance from technical unit counts.

Lesson to retain: read-side source checks cannot repair a candidate/commit
mismatch, and a generation fence is not a substitute for distinguishing rollback
from commit uncertainty. Preserve confirmed work, fence unknown authority, and
perform cleanup after ownership has been safely transferred outside commit locks.

Implementation and acceptance are pending. No full-product, six-program,
biological-equivalence, physical-device or registry-recovery claim follows from
this source-only plan.

## Root review decision

The confirmed-rollback/commit/uncertain distinction and outside-lock construction
and cleanup are approved. The conservative uncertain-unselected-binding policy
is accepted: unknown durable mutation outcome is fenced until explicit audited
reconciliation, while a confirmed unselected binding never changes generation.
This does not grant new authority to bind a physical device or initialize a REAL
model. Exact positive versions also remain within the existing strict safe-JSON
integer range; HTTP/direct callers must not disagree through coercion.

Do not overlap the frozen bootstrap, Cendos or client candidate while its
independent reviewer is reading/running it. Red tests may be added in a new
test-only file now; runtime work waits for those reviews and a written helper
signature/write-set agreement. Only the selected ACTIVE row and intended target
may be prepared/resealed; inconsistent additional ACTIVE topology must reject,
not trigger an unbounded all-record repair under commit locks. Startup final
confirmation is a read and may not rewrite a cohort, selection or twin version.

The separate ReferenceCohortService supported-writer check must receive its own
bounded owner/change/test assignment against the frozen bootstrap interface.
No broad `_audited` redesign, new permanent transaction log, source-equation
change, operational recovery or installed-service transition is authorized here.

## Root first red packet — strict boundary only

Before helper implementation, add only
`livemorebio/tests/test_legacy_transition_admission.py`. Reuse the existing
authored observation-only ASGI fixture, without startup/lifespan or a real model.
For activation and Patch binding, malformed/ambiguous bodies must reject before
the registry getter, constructor, generation assignment, cleanup or publication.
Cover unknown fields, duplicate keys, non-object/missing body, bool/float/string/
null/nonpositive/unsafe integer versions, valid UTF-8 and finite strict numbers.
An unauthorized control must reject before this same boundary. Expected outcomes
are existing400/422 validation or401/403 auth, not a new public error vocabulary.
Install tripwires at the registry getter and all numerical/publication paths.
Record current failures; no xfail/deselection or runtime fix before the helper
contract is agreed. This small packet does not claim full transaction tests.

First RED result: **16 failed,14 passed,3 existing warnings in1.51s** in private
root `livemore-research-review-ohax3aoh`. Every failure hit the registry/execution
boundary tripwire; there was no actual storage/model operation. All eight
invalid binding versions reached the registry getter (evaluated before the
current int coercion), while activation already rejected seven and accepted the
unsafe integer. Unknown fields, duplicate keys and nonfinite extra values
reached both routes; missing binding version also reached storage. Nonobject,
invalidUTF8 and unauthorized controls rejected. The ASGI middleware expanded
tripwire failures into verbose exception groups; the failure cause and counts
are retained, not treated as unexpected biological or runtime execution.
Runtime/source transition behavior is still unchanged and these tests remain
red pending the reviewed correction; no waiver/xfail was introduced.

Two additional, already planned confirmed-precondition reproductions use only
an authored inert candidate and a registry stub raising TWIN_VERSION_CONFLICT
before any write. Both return409 yet rotate the selected source generation:
**2 failed,30 deselected in1.30s**, private root
`livemore-research-review-031yyp7r`. The focused deselection is recorded, not a
full-suite claim. This invocation used the isolated runner without an added
socket-refusal hook; the ASGI fixture has no service/lifespan or real registry,
and its constructor/publication tripwires exclude numerical execution.
The file now contains32 cases. Exact transaction implementation remains pending.

The approved safely incrementable upper bound is now explicitly covered too:
`MAX_SAFE_INTEGER` itself, as well as the first unsafe integer, must reject.
The complete34-case red packet ran with socket, DNS and urllib refusal in private
root `livemore-research-review-cnrhxmnn`: **20 failed,14 passed,3 existing warnings
in1.61s**. Eighteen failures reached the installed boundary tripwire, and the
two confirmed precondition failures changed the selected generation. No actual
registry, model, service or browser ran. These expected failures remain ordinary
failing tests, not xfails or a passing release result. Middleware exception-group
formatting ignores the intended concise traceback setting; use `--tb=no` for
subsequent known-red count checks without dropping assertions or failure IDs.

## Root second red packet — prepared source publication

The approved separate server test file now adds authored ASGI stubs for the exact
prepared registry interface while its real implementation is independently built.
No production registry or numerical constructor runs. Cover activation and selected
binding across confirmed commit, confirmed rollback, unknown commit, preparation
failure, final close uncertainty and adapter cleanup failure; unselected virtual
binding must retain source/state/actions; selected binding retains observations
admitted during preparation; failed or superseded candidate construction must not
commit. Manager/creation/authority lock assertions distinguish preparation,
construction, final commit, cleanup and publication. These are expected-red tests,
not evidence that server integration exists. Startup/preview and remaining finalizer
races are still separate required cases, not silently counted by this packet.

Initial second packet RED: **18 failed,3 existing warnings in1.45s**, private
root `livemore-research-review-d2b_rc9s`, with socket/DNS/urllib refusal. The
current server still calls legacy registry methods/locked getters rather than
the authored prepared-interface stub. This is an expected unimplemented seam,
not an operational store failure. No new model or service was run; the real
registry helper remains in its separate implementation lane.

Independent review of the second red packet found four test-fidelity gaps before
server implementation. Correct the successful numerical fixtures to authored
SYNTHETIC metadata with a coherent READY availability at the final authority's
generation; add a separate REAL_HUMAN observation-only binding that remains
modeless/UNAVAILABLE. Require authority-only preparation and unlocked model state
projection, with the activation prepare/build/project/commit sequence explicit.
Retain the actual old model and observation objects, copied old subject/availability
values and original action contents so in-place precommit mutation cannot evade
identity-only assertions. Check invalidation names the original generation, not
merely that one cleanup call happened. All fixtures remain technical software
cases and do not execute a physiological model or admit a physical measurement.
Startup, preview and retired-finalizer cases remain pending; these corrections
do not silently count them or clear the independently rejected registry helper.

Corrected second packet remains RED as expected: **19 failed,3 existing warnings
in1.47s**, private root `livemore-research-review-i1yh8nul`, with socket connect,
DNS, connection-helper and urllib refusals. This includes the added modeless
binding case. The server still uses the old interface; no implementation or
passing product claim follows from this fixture correction.

## Root third red packet — explicit unregistered preview transitions

Add a separate preview test file while the registry correction is independently
implemented. Exercise all three existing dispatch paths: a named base preview,
a LIFE-generated research preview and a note-derived research preview. Use only
authored constructor/extractor/registry doubles; never invoke an actual model,
clinical extractor or data provider. This preserves the original dispatch scope,
not a new preview mode or a substitute requested experiment.

Each explicit preview must prepare the audited clear under authority only,
construct and project its candidate outside authority/manager/creation locks,
and confirm that clear before installing a new unregistered identity. Cover
confirmed commit, confirmed rollback, commit uncertainty and confirmed cleanup
uncertainty. Preserve old subject/model/actions/observations and generation on
rejection; on confirmed replacement initialize a fresh observation holder and
empty action list, never attach the old selected human's observations to a
preview. Exact old-generation invalidation and all publication happen after the
locks. A generation change during candidate preparation rejects before commit.
Keep candidate failures and input validation explicit in later boundary tests;
do not label startup, hardware admission or note extraction scientifically tested.

The next independent fixture review caught a remaining shape mismatch: the
SYNTHETIC technical record used a dictionary for lifestyle, while the real build
boundary consumes a scalar. Corrected it to the authored scalar0.5 and require
the inert builder to receive exactly the prepared after-record with that scalar.
No actual model is constructed to test this software boundary.

The initial combined source/preview red packet produced **34 failed,3 existing
warnings in1.80s**, private `livemore-research-review-l3g1wxgr`, with the same
connection/DNS/urllib refusals. Independent review then strengthened cleanup-entry
checks: the committed identity, exact availability, new generation and correct
model/observation/action holders must already be installed before invalidation;
uncertainty must already be DENY_ALL. Successful activation must discard an old
authored observation sentinel and action container. Add different-target activation
with prepared.selected=false and correct ACTIVE after-record; that property is a
binding-selection discriminator, not permission to skip activation publication.
The prepared stub's active_after now follows the operation kind as well as the
prior target selection. These remain ordinary expected-red tests before server
implementation, not skipped or waived acceptance.

The reviewer also identified the atomic-publication boundary itself: checking
cleanup entry alone could permit releasing the original commit guard before
installing the new state. The authored fence-guard wrapper now identifies the
exact guard whose registry stub committed (or returned uncertainty) and asserts
the complete installed state/fence before that guard releases any of its three
locks. Unselected confirmed binding instead proves unchanged original state.
The wrapper delegates to the actual lock guard; it does not replace the source
authority or manufacture execution behavior.

With the exact original-guard exit assertion included, all35 source/preview cases
remain RED against the unchanged server: **35 failed,3 existing warnings in2.03s**,
private `livemore-research-review-5lqsqevf`, with connection/DNS/urllib refusals.
The source and preview test files are frozen for independent final fidelity review.

## Root connected-publication preservation finding

The existing runtime state already contains its own `profile_params`, but
`_snapshot_twin(st)` overwrites them from the mutable currently selected twin.
Once candidate state is correctly precomputed outside commit locks, a later
selection between commit and best-effort publication could therefore mix one
snapshot with another model's parameters. Add an authored bus-only red test:
supplied parameters (including explicit null for modeless views) must stay with
that snapshot, and missing parameters must fail closed rather than borrowing
the current model. Preserve `_snapshot_twin`'s best-effort/sanitized-failure
contract and event vocabulary. Do not change Cendos's independent authority
checks, add a new bus, or treat bus delivery as durable clinical validation.

Independent pre-code review accepted this minimal correction and requested
malformed-parameter refusals, exact event assertions, and real `_current_snapshot`
ready/null projections using inert authored state doubles. The expanded8-case
packet produced **7 failed,1 passed in1.51s** before implementation, private
`livemore-research-review-a2xig11g`. An earlier repeat was8 setup errors because
its blanket process refusal also rejected optional import-time Git metadata; that
was not product RED evidence. The corrected repeat explicitly refused that exact
metadata command into its existing missing-commit fallback and retained low-level
process/network refusal. The source fix only stops borrowing current-twin profile
parameters and refuses missing/non-dict/non-null parameters before bus writes;
the existing sanitized best-effort logging and event payload are unchanged.

The minimal fix then passed all8 authored projection/publication cases in1.86s,
private `livemore-research-review-oef4govv`, with the same refusal boundaries and
three existing framework warnings. Independent post-code review is requested;
this does not clear the35 source/preview RED cases, startup, actual Cendos
consumption, or a cross-process publication race beyond coherent parameters.

Independent reviewer then read the method, actual producer shapes and all eight
tests, and repeated **8 passed in1.31s** (`livemore-research-review-9cnpldel`),
with existing warnings and network/low-level process refusals. The narrow method
is cleared: lines1103–1126 SHA256
`73dd2fb409f985848aa82568164c0290b05745c4235713d151d7420e93be3355`;
test file SHA256
`7653c73d518e5646cb1de832b2e15aed730cb93754386cc64a1896ccd6e09821`.
No broader source-transition or startup acceptance follows from this clearance.

The already approved retirement clause now has a separate two-route authored
regression packet (`test_source_retirement_lock_boundary.py`). Weak finalization
callbacks record lock ownership when the old model/action lose their last owner;
they perform no native cleanup and hold no reference to the observed objects.
The fixtures retain compatibility stubs for both old and prepared registry paths
so the existing wrong finalization interval, not a missing mock method, is exposed.
Activation and explicit base preview must retire both replaced objects outside
authority, creation, manager and initialization locks. The broad35-case fixture
keeps strong references for preservation assertions and cannot prove this clause
on its own. No actual model, device, store or network is exercised.

The retirement packet reproduced **2 failures in1.41s**, three existing warnings,
private `livemore-research-review-4ke7t9a4`: old-model/action release occurs while
source authority is owned, and the base-preview path also retains the old action
instead of retiring it. Independent fixture lifetime inspection cleared the
weak-reference setup and compatibility stubs. These remain required REDs until
the approved source-transition implementation, not reasons to delete old actions
or change operational state outside a confirmed transition.
