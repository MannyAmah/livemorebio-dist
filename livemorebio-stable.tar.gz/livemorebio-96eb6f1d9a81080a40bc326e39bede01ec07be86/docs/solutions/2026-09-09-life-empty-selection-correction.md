# LIFE: valid empty selection is not a failed mutation

Date: 2026-09-09. Scope: R04/R16/R29/R45/R48 within the existing recovery plan.
Status: approved for red-first correction after independent source diagnosis.

## Problem and office-hours decision

The ordinary fresh product at 8868 shows a healthy unregistered reference preview.
Opening LIFE, before any action, reports "Selected source availability is
inconsistent" and gives uncertain-mutation/fixed-session instructions. There is
no registered twin, execution or attempted mutation to recover. This was observed
after the navigation-first change passed independent 66-case review. It is a
distinct pre-existing source-contract mismatch, not an authentication failure.

The numerical preview can be READY while preparation of an execution is forbidden
without a registered source. Treating these two capabilities as identical is the
bug. Do not create an implicit twin, loosen registered-source admission, or hide a
malformed source. The user already approved correction of these product failures.

## Scope-holding CEO and engineering review

Choose an exact valid empty-state branch in the existing capability consumer.
Do not change API model availability, selection authority, consent, registration,
execution or observation contracts. One runtime file: console/lib/continuous_execution.js.
Dedicated tests and this evidence document may be added; no dependency or redesign.

Independent diagnosis: startup_origin traced server.py115–124 ->
execution_api.py99–105,244–250 -> continuous_execution.js62–66,131. The API
correctly returns top-level false/EXECUTION_SOURCE_REQUIRED/null selection with a
READY/reference_preview nested availability. Existing validation already requires
the nested preview to have null twin, version0 and true preparation availability.

Required exact predicate: after normal nested validation, source generations must
match. A READY/reference_preview is accepted only if top-level preparation is
strict false, reason is exactly EXECUTION_SOURCE_REQUIRED, and selection is null.
All other states retain equality checks. A fake selection, wrong/missing reason,
true preparation, mismatched generation or malformed nested value still rejects.

Use the existing "No registered active source. Create and activate a twin before
preparation" guidance and Twins link. Keep probe registration, binding, execution
preparation and LIFE session binding disabled. No producer or sample starts.

Capability reads get source-read failure guidance, not the generic action helper's
uncertain-mutation suffix. Scope this only to automatic capability discovery and
explicit Read selected source. Preserve existing mutation failure/replay handling
and fixed-history behavior. Do not conflate a read retry with mutation replay.

## Verification and rollout

1. Red-first test with the real API-shaped empty-reference response under inert
   scientific constructors; mounted UI must show useful guidance, no alert and no
   POST. Do not fabricate data or a source to pass.
2. Reject the exact malformed near-neighbors above. Preserve registered,
   observations-only and fixed-history tests and all mutation refusal semantics.
3. Independent source/test review, then restart only the owned isolated review
   stack before browser verification. No old-runtime/new-static combination.
4. Real browser: fresh LIFE empty state, read selected source and explicit
   document reopen. No probe/twin/session/experiment creation; screenshot evidence.

Any error stays visible. This correction does not make physical LIFE operational
or qualify a person's physiology. Old screenshots, error evidence and source
pins stay retained. Rollback is owner-reviewed source restoration, not a reset of
the dirty recovery worktree. R01–R51 remain open to their full acceptance gates.

## Maker implementation receipt

The approved correction changed one runtime file and added one dedicated test
file. Independent root review and fresh browser verification remain required.

- Runtime: `livemorebio/aegle/console/lib/continuous_execution.js`.
  SHA-256 before: `1aa54708c795987fb2fbd4d01e25757778d713ef45aaaea103f6f0befa6c15b6`.
  SHA-256 after: `0840d5bf39b2ff76897e26726ee46a8fd1c6edd6cc3dd1df2ff102af3b02e15a`.
- New tests: `livemorebio/tests/test_life_empty_selection_ui.py`.
  SHA-256: `f980a673cda5f600e1bdf8a07faecd7655494a9cc3a6c1dcfe65fec0619a6cf8`.
- Exact runtime delta: add the validated READY/reference_preview branch with
  false preparation, null selection and exact EXECUTION_SOURCE_REQUIRED reason;
  retain generation agreement and other-state equality. Add an optional failure
  guidance argument whose default is byte-for-byte the previous mutation warning.
  Override it only at automatic discovery and explicit Read selected source.
- No API, nested model-availability, registered-source admission, source capture,
  fixed-history, auth or biological contract was changed.

Original tool receipts:

| Phase | Receipt | Result | Guard counts |
| --- | --- | --- | --- |
| First RED, original runtime | 95d2fc | 4 failed, 12 passed, 2.85s | unexpected I/O0, Node16, Git-refused1 |
| First GREEN | 2b0636 | 16 passed, 2.73s | unexpected I/O0, Node16, Git-refused1 |
| New + existing history/controller preservation | d8a198 | 31 passed, 4.03s | unexpected I/O0, Node30, Git-refused1 |

The four RED failures were valid preview rejection, invalid true preparation
acceptance, and wrong automatic/manual read-failure guidance. Two new test regex
string deprecations were corrected using raw strings, without changing assertions.
GREEN retains two existing FastAPI on_event deprecations.

The dedicated fixture calls the real capabilities projection, source-selection
guard and server availability projection with an inert model-presence sentinel.
It bypasses only the operation's store/audit wrapper. The run constructs no model,
reads no registry, captures no source, runs no application lifespan and opens no
server. Mounted JS receives the resulting actual API-shaped value. It covers
the useful empty state, disabled preparation/probe/session controls, two GETs and
zero POSTs, ten malformed near-neighbors, both source-read failures, valid
registered/observations-only controls and unchanged mutation failure/no-replay.

The preservation command reuses the navigation test guard. The only additional
child form is the existing execution-view test's Node module-eval invocation with
its exact fixed source-module URI argument. No arbitrary process or network child
is permitted.

### Exact independent 31-case repeat

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`.

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os,signal,socket,subprocess,sys,urllib.request,ctypes
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('OFFLINE_DEADLINE')));signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.socket.bind=socket.socket.listen=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and (len(cmd)==4 or len(cmd)==5 and cmd[4]=='file:///Users/emman/Livemore/.worktrees/full-scope-recovery/livemorebio/aegle/console/lib/execution_view_state.js') and cmd[:2]==['/opt/homebrew/bin/node','--input-type=module'] and cmd[2] in ('-e','--eval'):
  counts['node']+=1;permit=True
  try:return run0([*cmd[:3],'import {createRequire as scopedRequire} from "node:module";const require=scopedRequire(import.meta.url);'+prefix+cmd[3],*cmd[4:]],*a,**k)
  finally:permit=False
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1;permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
class NoModels:
 @pytest.fixture(autouse=True)
 def prevent(self,monkeypatch):
  from livemorebio.tests.clinical_registry_fixtures import forbid_compilation
  from livemorebio.aegle.runtime import AegleTwin, MetabolicProfile
  forbid_compilation(monkeypatch)
  monkeypatch.setattr(AegleTwin,'__init__',deny)
  monkeypatch.setattr(MetabolicProfile,'__init__',deny)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=line','livemorebio/tests/test_life_empty_selection_ui.py','livemorebio/tests/test_clinical_execution_ui.py','livemorebio/tests/test_execution_view_ui.py'],plugins=[NoModels()])
print('Refusal counts:',counts,flush=True)
raise SystemExit(status)
PY
```

### Lesson

Model availability and workflow preparation admission are separate claims. A
ready unregistered reference must remain usable without becoming a registered
execution source. Validate the explicit boundary tuple instead of equating the
two flags or weakening either producer contract.

## Approved follow-up: read aborts must not imply an uncertain mutation

Independent root and release-redteam review found a second wording boundary in
`requestJSON`: its AbortError branch applies an uncertain-mutation warning to
every method, including both capability GET reads. The earlier 31-case receipt
and source pins above remain historical evidence, not coverage of this boundary.

Decision recorded before follow-up tests or runtime edits: add mounted automatic
and explicit capability GET AbortError regressions and a POST AbortError
preservation case. Only narrow the existing AbortError message by exact method:
GET receives "Read request was canceled or timed out."; every non-GET retains
"Request was canceled or timed out. Outcome is not confirmed; inspect before
retrying a mutation." exactly. The two capability-read action sites retain their
existing read guidance. Do not change timers, abort propagation, replay policy,
request ownership, mutation actions, admission or biological contracts.

Repeat the existing guarded dedicated and preservation suites after genuine RED,
then hand off final pins for independent review before root's fresh browser QA.

### Follow-up maker receipt

The approved method distinction changed only the existing AbortError catch line.
Tests added two capability-read abort cases (automatic and explicit) and one
POST abort case. All prior assertions remain. The mounted authored fetch now
permits an authored error name; production fetch, timers and retry behavior are
unchanged. GET tests require the exact read message, visible error, disabled
preparation controls, enabled explicit read and no mutation/replay. The POST test
requires the entire former message exactly and only one POST.

| Phase | Receipt | Result | Guard counts |
| --- | --- | --- | --- |
| Follow-up RED, earlier runtime pin | 61827c | 2 failed, 17 passed, 3.23s | unexpected I/O0, Node19, Git-refused1 |
| Follow-up GREEN | d6dbff | 19 passed, 3.09s | unexpected I/O0, Node19, Git-refused1 |
| Final history/controller preservation | f6a4c4 | 34 passed, 3.75s | unexpected I/O0, Node33, Git-refused1 |

The two RED failures were exactly the GET abort messages. The new POST abort
regression and the earlier 16 cases passed before the one-line correction.
Both GREEN runs retain only the two existing FastAPI on_event deprecations.

Final runtime SHA-256:
`935149329199cb47039a0e575bcf20a39e1651bb7898efb6cc18f323cba608c3`.
Final dedicated test SHA-256:
`d311b82cf019b2ebaf67f53a6cf06ae05e9e8c8b0b73e7d8102bd136c4d2a56b`.
The exact command in **Exact independent 31-case repeat** is unchanged and now
discovers 34 cases. Its guards and allowed child invocation forms are unchanged.
Prior receipts and hashes above remain historical. Independent review and fresh
browser QA are still required; these are maker test results, not acceptance.

Additional lesson: operation-specific recovery guidance must cover both the
outer action handler and the request helper's error translation. Testing only
ordinary Error values does not exercise AbortError's distinct message branch.

## Independent acceptance of this narrow correction

Release-redteam repeated the unchanged guarded command against final pins:
**34 passed in 4.59 seconds**, two existing warnings, unexpected I/O0, Node33,
Git-refused1 (`f22923` -> `a26cef`). Its independent inverse-delta checks recovered
the preceding runtime and test hashes (`3f7aed`). Source/test review returned
CLEAR for the separate browser check, not whole-product acceptance.

Root then started the ordinary, unmodified review launcher with fresh stores:

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B tools/run_review_stack.py --base-port 8868
```

Session30221, launcher73787, children73796/73797/73798. Private root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-14u5gnj_`.
Actual health identity (`70ac96`): startup2026-09-09T14:00:12.522304+00:00,
instance7033d412-8d88-4849-866c-3a552002224d,
startup sourceSHA256 `ebc64bcd9f9591a428dd10d369eef8fd313224357a9b1a7f1fc2b68239215ab2`.
No old-runtime/new-static combination, injected credentials, mocked response,
borrowed participant store or OSP/native-worker execution.

Actual in-app browser tab4 opened `/patch` normally. Checks completed:

- The healthy unregistered reference shows the correct onboarding guidance and
  a status message rather than the previous inconsistency alert.
- Register probe, bind probe, prepare execution and bind LIFE session remain
  disabled. Read selected source is enabled and succeeds without creating data.
- Explicit Reopen local session reloads the same document; the correct empty
  state survives. Nothing is automatically replayed.
- Selecting the ventricular-cell engine updates native horizon/rate and unit/
  capability guidance; all four preparation gates remain disabled, and another
  explicit source read succeeds. No prepared execution or frame exists.
- DOM widths1280/1270 and360/350 (viewport/document) show no horizontal overflow
  in these tested states. Browser warning/error log is empty.
- Three original JPEG captures in `docs/screenshots/life-empty-selection/`:
  desktop, mobile and mobile-controls. Root personally inspected all three.
  Mobile controls stack vertically and remain visible/readable; these images
  are UI evidence, not experiment videos or biological validation.

The launcher computed the normal shipped healthy-reference numerical preview
during startup. No participant, registered twin, cohort, device, execution,
experiment or physical observation was created. Timeout branches were tested
with controlled AbortError unit cases, not an injected live-browser failure.

After exact PID/parent/command inspection (`e545eb`), root terminated only the
owned launcher73787. All three children completed normal shutdown and the session
exited0 (`975846`). Subsequent exact-PID inspection found none of these processes.
The private evidence/stores and old installed product were preserved.

This closes the narrowly defined valid-empty-state and read-guidance defect.
Full R04/R16/R29/R45/R48 acceptance remains open, including continuous execution,
participant/device association, physical admission and full connected workflows.
