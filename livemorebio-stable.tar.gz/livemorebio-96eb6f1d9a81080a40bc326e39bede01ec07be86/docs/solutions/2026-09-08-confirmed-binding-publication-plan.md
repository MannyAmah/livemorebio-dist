# Confirmed binding: bounded server publication refinement

2026-09-08. Root requested and approved writing this refinement to the existing
committed-source plan/interface. **Independent pre-code review is required before
the new test seam or runtime implementation.** Root owns the server; this author
performed read-only source review and wrote only this document. R01–R51 and the
six programs are unchanged. No browser, model, service, device or store operation
was performed for this review.

## Exact next increment and retained evidence

Change only `server.bind_twin_patch` and its dedicated authored regression tests.
Reuse the already implemented `SubjectRegistry.prepare_patch_binding`,
`commit_prepared_transition`, pure `_normalize_transition_binding`, actual source
authority and existing assignment-only manager fence. No registry, audit,
bootstrap, source-equation, SDK, UI, transport or device-policy change is needed.

Current `server.py:745–770` still parses through `req.json`, coerces the version
with `int`, determines selection from memory twin_id alone, and nests `mutation`
under `observation`. `ModelSourceAuthority.mutation` installs a generation before
yielding. Its final invalidation therefore also runs while the route's outer
authority lock remains owned. A rejected binding can fence the old source before
any committed binding exists. A selected confirmed binding updates only the
subject summary, leaving stored model availability stale. The current registry
wrapper now uses the exact prepared helper but raises a fixed exception on
confirmed-close uncertainty, before this old server path installs the result.

Root's just-completed inert baseline selected `patches or binding` in
`test_committed_source_transitions.py` plus `test_legacy_transition_admission.py`:
**25 failed, 4 passed, 25 deselected in 1.57 s**, private root ending `j2qdtzy7`,
zero unexpected I/O and one refused optional Git lookup. The 29 selected cases
are 28 binding cases plus one already-green different-target activation test
whose name contains `binding_selected_flag`. This author did not run that test
process. Preserve this RED record and all earlier failed receipts.

## Strict admission and preparation

1. Explicit operator authentication, fresh server UUID and private no-store
   headers precede control work. Read `_selection_payload` once: existing 16 KiB,
   strict object, duplicate/nonfinite/UTF-8 rejection. Require an explicit exact
   integer `1 <= expected_version < MAX_SAFE_INTEGER` before the registry getter.
   Permit only the existing eight fields: `device_id`, `mode`,
   `protocol_version`, `hardware_revision`, `firmware_version`,
   `calibration_status`, `attestation_reference`, `expected_version`.
2. Call the existing pure `_normalize_transition_binding(body, expected_version)`
   before obtaining the registry. Preserve its string defaults, normalization,
   bounds and rejection semantics; it performs no source/storage work. The
   prepared helper still independently validates the body. No new physical
   qualification or cross-mode device-index release policy is introduced.
3. Obtain the registry dependency outside authority. Under authority only,
   capture the current generation and call `prepare_patch_binding` with this
   UUID. Reject DENY_ALL. Compare `prepared.active_before` with the in-memory
   selected source in all four existing fields, including explicit absence.
   Use `prepared.selected`, derived from checked storage topology, not a separate
   memory-ID shortcut to decide whether the binding changes selected identity.
4. For a selected binding, retain references to the actual live twin (possibly
   None), ObservationState and action container. Capture the current actual
   `_model_availability()` metadata under that same authority. No model is
   reconstructed, and no observation or action container is cloned for live use.

## Availability is preserved, not recalculated into readiness

Root explicitly accepted this precision after source review. Binding changes
neither numerical inputs nor the reason a selected model is unavailable.
Preserve the captured availability `state`, `reason_code`, `selection_mode` and
`preparation_available`; update only the confirmed twin ID/version and the new
source generation. Retain the existing schema and strict scalar shape.

In particular, startup can retain a typed constructor failure as `tw=None` plus
UNAVAILABLE even when the record's structural context alone would resolve READY.
Calling `model_availability(prepared.record)` afresh would incorrectly advertise
readiness without constructing a model. It must not replace that existing reason.
Reject internally inconsistent current readiness (including READY with no live
model) before commit, using the existing fixed preparation/storage failure
contract; do not fabricate a ModelContext reason or silently repair the state.

## Precomputed explicit publication; live holders stay live

Outside authority, manager-creation, manager and registry locks, prepare the
detached confirmed record, summary, availability, new state shell, generation
and fixed success/uncertainty/cleanup responses. The selected state shell retains
the exact live twin, observation and action references captured above. Observation
packets admitted during preparation must survive the binding publication.

For selected bindings only, prepare one explicit bus snapshot outside those
locks: `deepcopy(live_twin.state())` for a live model, or a detached result of
`unavailable_state(new_availability, live_observation_state)` for a modeless view.
Require a dictionary with its own dictionary-or-null `profile_params`, using the
same precommit projection requirement as activation/startup. Add the precomputed
new availability. Missing/malformed projection rejects before any registry commit.
Do not call a numerical model constructor, `build_twin`, or a model state method
for the modeless case. Do not assign the detached observation snapshot back into
the live ObservationState or model.

After a confirmed selected commit, publish only this explicit snapshot through
`_snapshot_twin(snapshot)` outside all locks. It is the prepared state associated
with this acknowledged binding, not a guarantee of the latest observation or of
remaining the selected source forever. Preserve original measurement timestamps;
binding must not refresh them. A later operator selection cannot make the shared
helper borrow the later model's parameters. Best-effort bus delivery is not the
operation acknowledgment or authority for Cendos/physical admission.

Do not call `_snapshot_twin()` without an argument: its current fallback invokes
`_current_snapshot()` without an encompassing authority read and can mix separately
read availability and twin state. Do not silently change that shared helper or
add another authority-held model-state read in this increment. No snapshot is
published for an unselected binding, rejected binding or unknown commit.

## Final commit and outcomes

Under the existing `commit_guard` (authority → creation → manager), recheck the
captured generation and four-field active-source agreement before invoking the
actual `commit_prepared_transition(prepared)`. Its exact rows, pointer, device
index, authority token and durable audit witness remain the registry's job.

- Confirmed rejection/rollback: retain state, availability, generation, live
  holders, ownership and frames exactly; no invalidation or publication.
- Confirmed selected commit: assign the prepared identity/availability/state shell
  and fresh permitted generation under that same original guard. Preserve live
  twin/ObservationState/actions objects. Hold old state references for retirement
  outside all locks; no destructor, serialization or execution-store work belongs
  between registry acknowledgment and memory publication.
- Confirmed unselected commit: no active state/generation swap, no invalidation,
  no model projection, no bus publication. A confirmed close failure still
  returns the existing cleanup-unconfirmed 503 without changing active source.
- Unknown commit/rollback, including unselected binding: install DENY_ALL under
  the guard. Retain the live holders for inspection; do not advertise speculative
  binding identity as confirmed. Return SELECTION_COMMIT_UNCONFIRMED. Never POST
  or commit again to discover the outcome.

After guard release, invalidate exactly the captured old generation only when
a new selected fence or DENY_ALL was installed. Cleanup failure cannot undo a
confirmed binding or revive the old source. Preserve the fixed
SELECTION_COMMITTED_CLEANUP_UNCONFIRMED response and explicit cleanup ownership.
Confirmed selected publication may still send its explicit snapshot after this
failure. UUID/error/no-store behavior follows the existing activation contract.

## Test delta before implementation

Retain the existing 28 binding cases, their exact original-guard exit assertions,
live-holder checks and the already-green activation preservation case. Add narrow
authored tests, with no runtime-model, service, socket or operational store:

- Confirmed unselected versus uncertain unselected: only uncertainty fences;
  neither publishes a speculative target snapshot.
- Each four-field active mismatch at preparation and final entry rejects before
  commit. A generation change during unlocked projection similarly rejects.
- Missing or malformed own `profile_params` fails before commit; valid ready
  and explicit-null modeless projections preserve the exact source fields.
- Selected typed-startup UNAVAILABLE remains modeless with the same reason/mode/
  preparation flag after the version/generation update; incoherent READY/None
  rejects rather than reclassifying or constructing a model.
- An observation admitted after detached snapshot preparation but before the
  final guard survives in the same live holder. Use the pre-entry seam of the
  existing delegating guard fixture, not a fabricated physical packet or a
  callback pretending admission can occur inside a held source lock.
- A later source replacement after commit but before bus delivery does not
  alter the explicit prepared snapshot, its parameters or availability, and is
  never overwritten by the older operation. Keep the new winner installed.
- Retained closed-manager confirmed/uncertain binding uses the corrected real
  fence without reopening or detaching owners; explicit cleanup stays separate.

For bus assertions use the real `_snapshot_twin` with record-only sinks where
useful. Do not replace the helper with a permissive mock that hides argument or
parameter borrowing. Run the established private ASGI-compatible refusal wrapper;
internal socketpair is allowed, network/child/native work is not. Capture real
RED results before root implementation, then independently grade the frozen
runtime slice. This document does not report those additional tests as authored.

## Remaining families remain open

Preview branches (`stimulate`/`_apply_stimulus` base and LIFE System, `ingest_note`)
still use eager mutation fencing and legacy clear dispatch. Their 15 prepared
preview cases plus the base retirement case remain separate obligations.
Observation selection still has a weaker target/pointer-only lost-ACK witness,
an unbounded ACTIVE demotion loop and no retire holder. Reconciliation still uses
the unchecked/default active-read and canonical-only confirmation branches,
without the new raw pointer/authority witness or complete precommit projection.
These are explicitly retained follow-ups in the parent interface, not repaired
by binding, activation or startup verification. No such route is changed here.

## Independent pre-code assessment — source_research

2026-09-08. **Clear for the bounded red-first implementation described above.**
Read the complete180-line refinement at SHA256
`08cf5a5426edc2dd28e0e15f1b999a8f3fdbc600d3419ceb5ca505b65ce32b4d`,
the committed interface and relevant parent refinements, and actual normalizer,
prepared properties, binding route, current-availability/snapshot, modeless
projection and authority/commit-guard seams. No runtime/test edit, test execution,
network, browser, native model or registry operation was performed.

The existing pure normalizer can run before dependency acquisition without a new
policy. The prepared helper independently retains exact storage admission; the
source guard supplies generation/memory agreement, not a substitute registry
check. Captured live holders plus an outside-lock detached publication satisfy the
two different obligations: preserve newly admitted observations in memory, while
publishing the acknowledged binding's own snapshot without borrowing a later
selection's parameters. No shared `_snapshot_twin` change is needed.

Make the stated rejection of inconsistent availability explicit in the technical
tests: before replacing identity fields, its twin_id/version must match the
checked active record and its source_generation the captured generation. Preserve
the valid captured reason/mode/readiness, including a typed startup failure on a
structurally READY record; reject mismatched metadata rather than relabel it.
Keep all exact guard-exit and rollback assertions. A confirmed unselected close
failure still leaves active memory/fence untouched; uncertain selected or
unselected completion installs DENY_ALL without publishing a speculative target.

The already closed manager permits assignment-only fencing, not execution or
ownership release. Keep that real-manager coverage and the unlocked cleanup /
later-winner publication tests. The proposed increment therefore has no remaining
pre-code blocker; frozen runtime and new RED/green evidence still require an
independent implementation grade. Preview and older observation/reconciliation
families remain open exactly as listed above.

## Coherent observation sample — approved bounded refinement

Root and `source_research` independently traced `runtime.state`,
`ObservationState.ingest_patch_envelope/state`, the authority-held telemetry route
and shared v2/v3 normalization. Governed ingestion replaces observations then
patch under authority, without rotating generation. Unlocked numerical/modeless
projection can otherwise mix those two packet views even when live holders are
correctly preserved. Root approves this narrow refinement before implementation:

1. During the initial authority-held capture, select the actual live twin when
   present, otherwise the actual descriptive observation holder. Call exactly
   `ObservationState.state(holder)` through the base class, capturing one detached
   patch/observations pair. This executes only the lightweight deep copy, never
   the overridden numerical `AegleTwin.state()` or a constructor.
2. Keep numerical projection outside all guards. Replace its patch and
   observations with this captured pair. If it exposes the existing
   `capability.maturity.packet_admitted` field, derive that field only from the
   same captured patch's connected flag; do not add capability claims to a
   modeless projection or alter other maturity fields. Malformed existing
   capability structure is a precommit projection failure, not a silent repair.
3. For the modeless projection, construct a projection-only `ObservationState`
   outside guards, populate it from the captured pair and pass that detached
   holder to `unavailable_state`. Never reread the live holder for this snapshot
   or install the projection holder into live state. New observations received
   meanwhile remain in the original live holder after binding.
4. Preserve every copied row, clock, QC and provenance field verbatim. Governed
   v2/v3 ingestion changes only observations and patch, not model provenance or
   applied history. Older v2 rows retain `legacy_unknown`, `legacy_missing` and
   null lineage/clock fields; no re-normalization, relabeling, recency refresh or
   new capture timestamp is introduced. The separate legacy demo stimulus is
   generation-fenced and does not justify broadening this change.

Required technical regression: capture complete authored sample A under authority,
then admit complete sample B after release/during projection, without changing
generation. The bus snapshot must retain A's pair, clocks and packet-admitted flag,
while the installed live holder retains B unchanged. Cover ready/modeless and
disconnected A→connected B, plus exact v2 missing-lineage preservation. Exercise
the real snapshot sink as planned. The existing minimal ready-twin stand-in must
gain explicit patch/observations fields, not a permissive runtime fallback.
No generic helper, model/ObservationState implementation, ingestion route or
scientific semantics is changed by this binding-only refinement.
