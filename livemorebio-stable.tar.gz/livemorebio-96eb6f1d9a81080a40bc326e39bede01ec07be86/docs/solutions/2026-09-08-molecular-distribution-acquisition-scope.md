# Molecular inspector: isolated distribution inspection

2026-09-08. R03/R12/R14/R23/R24/R46 continuation, not a replacement feature.
Root read the full200-line molecular-inspector dependency review and the master
R01–R51 register. The existing remote Molstar inspector remains preserved. This
bounded source-artifact inspection advances its same-origin replacement without
editing product files during the separately frozen browser-recovery check.

## Decision and boundary

Inspect the exact already-selected upstream `molstar@4.4.0` distribution, not an
upgrade or a replacement renderer. The purpose is to learn the actual archive
layout, declared dependencies, license/notice coverage, included MP4/WASM/image
bytes and structure-only build inputs. Metadata is not redistribution approval.
No patient, clinical, molecular-coordinate or experimental data will be sent.
No package scripts, installation, build, imported package code, native library,
browser, service or model may execute. No shared npm cache or project dependency
tree may be modified. No vendor code enters the product in this increment.

Read official package metadata for exact4.4.0 and bind the archive URL/SRI to it.
If the package identity/version/host/size cannot be established, stop before
acquisition and report what is missing. Fetch at most one archive from that
metadata's official npm registry host into a new0700 private inspection root.
Use bounded HTTPS reads (metadata1MiB, archive32MiB, each30s, no redirects or
automatic retry); reject mismatching digest, archive size or version. Preserve
failed artifacts without installation. Do not claim successful acquisition from
metadata alone. Reading official upstream source pages is allowed for exact
license and entry-point mapping; no current-master substitution.

Inventory the archive as data, with no extracted-path execution. If extraction is
needed, first reject absolute/parent-escaping/link/device entries and cap at
300MiB declared uncompressed bytes and25,000 regular files. Prefer reading only
the package manifest, notices, build configurations and specific entry/dependency
source entries directly from the archive. Retain a canonical file-name/size/hash
inventory if feasible within these bounds. Do not copy images or codecs into
Livemore and do not download reference videos as a display workaround.

## Acceptance and handoff

Report exact source/version/archive identity, actual observed license/dependency
gaps and the smallest structure-only build path supported by that source. Reuse
existing Molstar controls; no custom molecular engine, universal plugin framework
or new interface design is proposed. The upstream MIT label cannot stand in for
all bundled third-party obligations. Distinguish source entries from emitted
bundle contents and a feasible build from an executed build.

All download/metadata outcomes and bounded failures remain explicit. Independent
review of the retained inventory must precede any separate build/vendor decision.
This authorizes only read-only metadata plus the one private source-distribution
acquisition; no installed release, product source, store, experiment, cohort,
service, browser check or R01–R51 completion state changes.

## Retained metadata failure and one diagnostic read

The first metadata/HEAD phase stopped with AssertionError before creating a
verified compressed-size receipt. Root read the complete retained acquisition
helper, metadata and failure receipt in privateuCgWWp. Exact4.4.0 identity,
upstream commit, SRI,5,282 files and34,003,049 unpacked bytes are available; the
failure does not establish which HEAD field differed. No archive GET occurred.

Root authorizes one metadata-only HEAD of the exact metadata-declared archive
URL, under15s total, without redirects/proxies/retries. Retain only fixed safe
status, URL-match boolean, Content-Length/Encoding/Type and elapsed time. Preserve
the earlier failure and do not rerun its acquisition helper or download the
archive in this diagnostic. Root will review the actual field-level evidence
before using the still-unspent single archive allowance or amending size admission.

## Bounded streaming admission in place of an unavailable HEAD length

The separately approved HEAD returned200 with the exact URL, no Content-Length,
no Content-Encoding and application/octet-stream in0.107214s. Root read its
original fixed safe receipt. Missing length is not an archive-integrity failure.
No archive bytes have yet been fetched; the original metadata failure is retained.

Approve the original single archive GET using the retained exact-version URL and
SHA512 SRI, with the original32MiB actual-body cap and30s absolute deadline. A
Content-Length, if supplied, must be positive, within cap and match actual bytes;
its absence is permitted only because the streaming byte counter enforces the
same fixed cap. Reject redirects, non-200, nonidentity content encoding, excess
bytes, incomplete transport, nonmatching SHA512/SHA1, timeout or write failure.
Record actual transferred length and computed digest; never manufacture an
advertised size or rewrite the first failed metadata receipt as verified.

Use a separately named private acquisition helper/receipt so original evidence
remains intact. Do not rerun metadata/HEAD or retry an archive failure. No scripts,
package import, install or build. On successful integrity verification, the
previously approved bounded read-as-data archive inventory may proceed. All
uncompressed/file-count/path/link restrictions remain unchanged.
