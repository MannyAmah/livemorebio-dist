# Evidence export must preserve typed missing-resource errors

Date: 2026-09-05

## Investigation

The suite expected an authenticated missing legacy archive request to return 404,
but received 503. Reproducing the request against a fresh temporary evidence store
with an explicit technical signing key produced the same result. It was not stale
data, a broken key, or environment leakage.

`EvidenceStore.get` raises the domain `NotFoundError`, which inherits `LookupError`,
not `KeyError`. The archive HTTP handler caught only `KeyError`, so missing evidence
fell into the generic unavailable response. Its former string-based error matching
had hidden that exception-contract mismatch.

## Repair

The `api_evidence_export` handler explicitly catches `NotFoundError` alongside its
existing `KeyError` compatibility catch. Integrity/storage exceptions still return
503; draft-review failures still return 409. The repair does not approve or lock
packages, weaken integrity verification, or bypass authentication.

Regression tests additionally found missing cache headers on archive responses.
Only this handler was changed to mark successful archives and handled errors
`Cache-Control: no-store`. Other legacy endpoints are outside this repair's scope.

## Verification

- Red: the original missing-export test failed with 503 using an isolated empty
  store, without accessing the operator's database.
- Green: 41 tests passed across `test_phase1_screen_launch.py` and
  `test_legacy_evidence_integrity.py`, with three existing dependency-deprecation
  warnings.
- Failure matrix: missing domain/key lookup 404, unreviewed draft 409, integrity
  and storage failures 503, with no private exception details echoed.
- Archive transport 200 and error responses are non-cacheable.
- GET remains 405, unauthorized POST remains 401, and a missing package does not
  create evidence records. The full-suite rerun belongs to the main integration
  review after the remaining lanes finish.

## Durable lesson

Catch the declared domain error type, not a guessed built-in or message substring.
Keep absence separate from failed trust verification. Endpoint regression tests
should use isolated stores and assert safe response bodies as well as status codes.
