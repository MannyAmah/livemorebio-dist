# Molecular actual A/B pair: independent retained-output review

2026-09-09. Bounded output/repeatability/source-membership review is CLEAR.
This does not approve public redistribution, NOTICE assembly, browser/CSP
behavior, installed wheel delivery, three-consumer wiring or clinical claims.
The original QkgKLS FILE_BOUND and FJiuBt ASSET_GRAPH failures stay unchanged.

## Scope and method

Root executed the separately authorized pair, session1789, in
`/private/tmp/livemore-molecular-leaf-parser.IviiqA`. The independent reviewer
read the complete result, both inspection receipts and all four stream files;
strictly parsed both complete actual stats and the prior FJiuBt stats as data;
compared each actual asset byte-for-byte; and checked source/notice identities.
No build/package/Node/browser/service/model or released owner module was run
or imported during this review. The reviewer made no changes to either consumed
build root, installed tree or product source. The review skill/checklist guided
scope and evidence checks; its execution/autofix stages were outside authority.

The final stdlib-only data check used a30s alarm and audit refusal for sockets,
subprocess, ctypes, fork/spawn/system and signals to processes. It completed
in0.869879833s with0 unexpected I/O. Its before/after identities cover1,230
read files by size/SHA256/mode/mtime, including all1,155 mapped package sources,
the21 frozen build-input rows, receipts and applicable original notice blobs.
No original file was rewritten. A separate exact read-only `ps -p` query found
no PID30973,30993 or31015, exit1 with empty output. No old owner import was used.

New private report data only:
`/private/tmp/livemore-molecular-pair-review.B01PC9` (0700; files0600).

| Artifact | SHA256 |
|---|---|
| IviiqA/result.json | fbbe521d9f08eff73908903f0289287598130315efbb305ddcb13431cbafd8a2 |
| A/stats.json | a358557ac8f76e0180c96b916d0998d53ad91e10ed0a87efb85353738629e6cd |
| B/stats.json | a41ee67d668ba4c86893d86a70365de41031cce6be093d38a64a4e8f29eb8eb4 |
| A/output-inspection.json | dbc3078a26054e7b24e5b764d313c41120f85c882f21dc1dd57761fe06c816d4 |
| B/output-inspection.json | fca0ca08f94be6590ea902e558e5fbd8cda79f55a592479cfa5c1f6415e5369c |
| B01PC9/source-members.json | 107c117dfb057f35fb1ab4af0896e7a5702fe02976d7826f7a6deadee8daa7d9 |
| B01PC9/review-data.json | 417ed70fdcf4c71de959edef54a4a807bee2e97ffe876aec86b38aebad18f7cb |

## Actual command, cleanup and output evidence

The retained status is BUILT_REQUIRES_CLOSURE_AND_RIGHTS_REVIEW. Both exact stock
webpack command lines match their fixed A/B roots, both exit0/SETTLED with
empty-before-reap true and no TERM/KILL, no primary/failure/stream error.
Invocations took15.262568833s and15.555226000s. Both119-byte stderr files contain
only webpack-cli's successful stats-path notice; both stdout files are empty.
Their sizes/hashes and both inspection hashes match the parent receipt.

The same authority object appears in AUTHORIZE and result; its helper, plan
and input hashes match current bytes. Every21-row input pin agrees, and the
retained final inputs_preserved is true. A/B sampled disk receipts have no
overshoot, max sampling gaps0.1133/0.1175s; this is explicitly SAMPLED_SOFT,
not a hard kernel resource bound. Recorded inspection total0.116898792s.

Exactly three regular assets occur in each output directory. Each is
byte-identical between A and B and to FJiuBt's earlier retained output:

| Asset | Bytes | SHA256 |
|---|---:|---|
| structure.js | 2,940,473 | 6993c2c9f356d31dcb325a5423507450da9cdbda035cdc85315727447fba7ced |
| structure.css | 69,902 | ec90bcaa8610dc104656bc57effede3d6e1b954c2386dcaee985a88b8799c089 |
| structure.js.LICENSE.txt | 971 | bc83aaff43d3ef9301331bbfeaacc4d2d8549dfc9029f786bd6abdd32363b020 |

All are below the unchanged caps. A/B stats are7,659,593/7,615,979B, below32MiB;
their differing raw identifiers/stats bytes are not falsely called identical.
The recursive asset list includes the nested license and the two empty-object
leaves. Declared sizes and the exact recursively collected set match disk.
Both stats have0 errors and the same three webpack performance warnings: JS
exceeds the recommended244KiB, the main entrypoint is2.87MiB, and webpack offers
code-splitting advice. These warnings are retained, not a measured browser
performance pass or a direction to alter the frozen build contract.

## Complete emitted/orphan membership

Each complete main tree has1,361 roots,2,503 occurrences and1,359 unique module
identifiers. Its1,163 emitted identifiers exactly equal the separate chunk
tree's1,163 identifiers across21 roots. One concatenated aggregate carries
effective chunk792 into its children; nested children are not treated as
orphans just because their own chunks array is empty.

Combined trees contain3,666 records:2,326 emitted occurrences and1,340 orphan
occurrences. Full ordered record hashes independently reproduce the launcher's
inspection receipts: A27faa67a…; Bbe6fc299…. All filtered markers across the
complete parsed objects are exact integer zero where present. No graph rows
were dropped to reach these counts; duplicate occurrences are retained.

The emitted set maps to1,155 unique installed package files in59 exact package/
version pairs, four webpack runtime identifiers, and four local records:
entry, spec, the approved binding-description adapter and concatenated entry
aggregate. The extra local formatter compared with QkgKLS is the approved
source change, not a new third-party dependency. No identifier is unmapped.

All1,155 file paths and hashes are exactly equal between A/B/FJiuBt and the
frozen installed inventory. The943 Molstar files include all86 source-comment
blocks retained by the broader embedded-source review, with identical full-file
hash/size. The old63-block count was a narrower keyword scan, not an exhaustive
origin count. No new package/source family was discovered. No emitted member
matches the fixed full-viewer/MP4/h264/background/MVS/Zenodo exclusions; known
WASM/h264 byte signatures are absent in the actual JS. These finite checks do
not prove every possible encoded payload or runtime request absent.

## Rights-map bookkeeping corrections, not new dependency drift

Two initial data assertions exposed errors in the older prose rather than the
actual outputs; their failures were not erased or presented as passed checks:

1. Prior `2026-09-09-molecular-build-stats-closure-diagnosis.md` lists
   micromark-util-sanitize-uri2.1.0. The canonical lock, installed package.json,
   FJiuBt/current source and rights-index entry275 all say **2.0.1**. Its existing
   full notice remains index85, SHA dd108188…. Other58 version/count pairs agree.
2. Exact59-pair matching in rights-index gives **27** unique full package notice
   blobs after excluding old-viewer163. Webpack runtime index79 adds one, giving
   **28 total**, not28 package blobs plus webpack. No notice body is missing.

The corrected machine source-members receipt includes the exact59-pair counts,
per-file hashes and notice-index mapping; source_research has these pins for
the separate assembly task. All27 package bodies plus webpack's full notice
were size/hash checked. This is association/integrity evidence, not a new legal
judgment. CAS's intermediate Shadertoy grant and the fastapprox JS-port license
limit remain explicit in the existing rights report; SMAA, ColorBrewer,
Apache-derived and local adaptation conditions are not replaced by package MIT
labels or the971B minifier comments.

## Decision and remaining gates

No blocker found for this finite actual-pair output and source-membership gate.
Do not interpret this as vendor/rights approval or actual WebGL/CSP performance
acceptance. NOTICE assembly and independent inspection, the private actual
adapter check, ordinary/frozen/execution consumer verification and wheel delivery
remain required. No biological experiment, participant or hardware was involved;
all six requested programs and the broader product/physical-v3 scope remain.

Lesson: key attribution assembly from the actual locked source membership and
original notice identities, not a prose version/count table. Preserve the
correction explicitly while keeping historic failed-build evidence untouched.
