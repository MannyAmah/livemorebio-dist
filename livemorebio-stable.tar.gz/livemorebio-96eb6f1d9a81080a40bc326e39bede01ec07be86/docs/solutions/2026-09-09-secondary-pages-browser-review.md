# Secondary-page browser review — bounded result

Date: 2026-09-09. Independent browser operator: `osp_evidence_review`.
Scope approved by root: read-only Research sections and secondary destinations
discovered through ordinary navigation, desktop plus one mobile capture. This is
**not full-product acceptance or a scientific qualification report**.

## Identity and method

- Base `http://127.0.0.1:8868`; separate agent-browser session
  `livemore-pages-review`. Root's `livemore-completion` was never controlled.
- Agent-browser skill and command reference read; this was the known alternative
  to the previously failed gstack browser. No tool installation or repair.
- The rendered build detail reported startup source fingerprint
  `57c32b990db3cac823ed4012a8a9d4fd861683cf2106df8adb44631c0ddf5a9e`,
  abbreviated commit `83994425`, and matching Aegle/LIFE/Cendos startup source.
  The commit alone is not the running source identity. No OS/service PID probes
  were made; this records the UI's identity report, not an independent full
  source-manifest comparison. Root owns the isolated stack and subsequent restart.
- Opened `/research`; clicked all four Research section buttons; opened More →
  Knowledge → More → Advanced console; returned via the observed Research link.
  Captures are actual native browser PNGs, not generated or re-encoded images.
- Ordinary fresh-session bootstrap succeeded. No credentials, cookie values,
  auth state or participant data were entered, saved or exported. No form was
  submitted, experiment executed, external disease lookup performed, source
  uploaded, health probe run, or model/registry/source changed.
- Actual legacy display read the existing generic hepatic research workflow
  fixture. It was not a real-person admission or a new modeled experiment.
- No Cendos, Atlas, Biology or LIFE core audit; root owns those surfaces. Cendos
  was being edited during this audit and deliberately not visited.

## Results

| Surface / action | Bounded result | Evidence and limits |
| --- | --- | --- |
| Research: Prediction & measurement | PASS — read-only render | Blank counterpart/measurement forms, explicit immutable-study boundary, no run selected, independent measurement still awaited. No loading/auth error after settlement. No measurement workflow exercised. |
| Research: Treatment-free resilience | PASS — tab/render | Correct selected button and new content; replacement protocol is explicitly an example, not clinical criteria. No protocol registered or assessment run. |
| Research: Scientific learning | PASS — tab/render | Proposal fields and eight-scale evidence contract visible; no silent live-twin rewrite claimed. No proposal submitted. |
| Research: Disease references | PASS — tab/render | KEGG/MalaCards controls and local licensed-release limitation visible. No lookup/import or rights validation performed. |
| More → Knowledge `/adapters` | PASS — navigation and settled catalog render | Initial loading state settled to 2,633 catalog entries, five evaluated, nine configured, zero operational/workflow-wired/scientifically-qualified. Configured/blocked/disabled/external states visible. Counts are UI observations, not a claim of operational source access. Health-probe button untouched. |
| More → Advanced console `/legacy` | PASS — navigation/current read; FAIL — claim clarity | Initial unavailable trace became explicitly COMPUTED with the existing calculated trace. The same settled view still displays `ALIVE`, `AP · Ca²⁺ live`, and `LIVING ORGANS · REAL STATE`; see finding below. No builder, screen, reset, source switch or device action used. |
| Research at 390×844 | PARTIAL — visible content fits | Main-content overflow check found no elements outside the viewport; document width 380, viewport 390. Heading, tabs, labels and form column fit. The top navigation is horizontally scrollable and several destinations are offscreen initially. Horizontal navigation interaction, lower-form completion and full responsive acceptance were not tested. |
| Sources / LIFE Data / V&V | UNVERIFIED — not discovered | On Research, Knowledge and legacy the actual More menu contained Knowledge, Advanced console and API, not these three named destinations. This is a discoverability gap in this path, not proof the capabilities are absent everywhere. No guessed URL was opened. |
| API documentation | UNVERIFIED | The observed `/docs` link was not followed; this was not an API execution audit. |
| Console and page errors | PASS — bounded observation | `console` and `errors` were empty after the four Research tabs, Knowledge navigation, settled legacy and final Research return. No browser request interception or exhaustive network ledger was used. |

### Concrete retained finding: legacy scientific-state wording

The settled legacy page labels the trace `Calculated response / COMPUTED`, but
its adjacent organ/system cards still say `ALIVE` and `AP · Ca²⁺ live`. Together
with `LIVING ORGANS · REAL STATE`, those labels can imply living or continuously
measured physiology where this visit only read an existing numerical result.
The footer's model-only limitation does not remove the contradictory local
labels. This is the previously retained legacy-claim issue reproduced on this
startup build, not a newly demonstrated solver failure. Keep it open; a narrow
copy correction should retain the actual calculated readout and source boundary.
The primary header also highlights Atlas while the URL is `/legacy`; navigation
works, but this is not an accurate destination highlight.

## Original screenshots

All nine were personally viewed in this review. Desktop images are 1440×1000;
`research-mobile.png` is 390×844. They are viewport captures, not full-page
acceptance of controls below the fold. Loading captures are retained separately
from settled captures and are not misreported as persistent failures.

Directory: [`docs/screenshots/secondary-pages-2026-09-09`](../screenshots/secondary-pages-2026-09-09/).

| Original file | SHA256 |
| --- | --- |
| [research-prediction.png](../screenshots/secondary-pages-2026-09-09/research-prediction.png) | `acc11bb8aef9985e68953799338c266aaecb86b267c4a339089a6a50fda14e72` |
| [research-resilience.png](../screenshots/secondary-pages-2026-09-09/research-resilience.png) | `5341182405fd89d2c175a7188dd82f3d43d6a06550359ac1f1359b1106db2cca` |
| [research-learning.png](../screenshots/secondary-pages-2026-09-09/research-learning.png) | `99c51744a6bb3566e50ef4524feec6303053c12a1ff237289c3ccdc147106f68` |
| [research-references.png](../screenshots/secondary-pages-2026-09-09/research-references.png) | `d64c3feff1385d88071bf299210099767640aaabdbbb061e05c9a28d3a46440f` |
| [knowledge.png](../screenshots/secondary-pages-2026-09-09/knowledge.png) — loading | `6eb622611300ae0d64a4cfffb7cf9ae4d54f5efd1154e2da1653485fb2f5e20a` |
| [knowledge-settled.png](../screenshots/secondary-pages-2026-09-09/knowledge-settled.png) | `ee346c4088ca0fe727a8edd73e395058acaf38cecf0f9ac876a073d5b97d41ec` |
| [legacy.png](../screenshots/secondary-pages-2026-09-09/legacy.png) — loading | `e15d93e2788c38914d2ec4a83545bbb4bef2bfb9c039909235affb5cf0848c74` |
| [legacy-settled.png](../screenshots/secondary-pages-2026-09-09/legacy-settled.png) | `a422be948099403e4fe9170a0afc77d6c704d9a184cd87bc5f3688c6f33fc583` |
| [research-mobile.png](../screenshots/secondary-pages-2026-09-09/research-mobile.png) | `facddff8f20b0608ce74fbb046d739e920b715d4e63a2cad9132403ed849fc06` |

## Cleanup, exclusions and lesson

The named review browser closed successfully (`f20fe2`) before root's planned
service restart. No root browser or application service was closed. Subsequent
planned restarts are not failures of this completed visit. No tests, native
engine execution, product source/runtime edit, or external write occurred.

This does not cover keyboard/screen-reader/zoom behavior, every viewport,
mutation validation, physical measurements, licensed-source installation,
scientific learning review, source qualification, or historical page parity.
R40/R41 and full-product acceptance remain open. Root reviews these original
screenshots and this report; this agent does not approve its own implementation.

Lesson: settled successful navigation is compatible with a claim-clarity defect
and incomplete page discovery. Preserve those independent outcomes instead of
turning a short smoke check into a whole-product pass. This entry is the local
compounding record; CE tooling was unavailable.
