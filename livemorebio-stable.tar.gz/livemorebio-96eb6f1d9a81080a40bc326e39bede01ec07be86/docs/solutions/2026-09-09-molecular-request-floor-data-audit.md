# Molecular request-floor actual: independent retained-data audit

2026-09-09. Data-only review of
`/private/tmp/livemore-molecular-request-floor.USnuJu/run`, separately recorded
to avoid overlapping the root actual receipt in
[the correction/decision](2026-09-09-molecular-request-floor-correction.md).

**Overall FAILED remains authoritative.** Audit assertions `8c922a` exited0:
retained evidence is internally consistent; it does not pass the browser task.
The checker was not imported or run, no tests/browser/probes/native/model/network
activity occurred, and no original file or image was changed. The stdlib data
reader denied writes, child/process/network creation and native-library loading.
This new document is the sole file edit. Root's image inspection and exact
21-PID absence check `99aed7` remain separate observations, not repeated here.

## Originals, pins, images and bounds

The full browser object embedded in supervision canonically equals the
standalone original. It remains FAILED/TRANSPORT_OBSERVATION_FAILED with
transport failure TRANSPORT_CDP_FAILED; supervision remains FAILED, exit1,
browser_admitted false, elapsed42.1764504169696s. Four stages and11 planned
captures are PASS, with zero page/console/CSP errors. These successes do not
waive request failures.

| Original | Bytes | SHA256 |
|---|---:|---|
| browser-result.json |259724| `ba75972e2a48ccfdcaf321d8d0bcb52f874a3acc8032a824cdab56e513f5e12f` |
| supervision.json |280204| `6f5f2e5fa952cf037c9c81f1a686d55cdbb6317eb47b59a5889c273bd1a8af76` |
| stdout |74| `71a9e357abb1da507a7e147bffebca508f09b5e0a9df927d906221bd6108cd56` |
| stderr |0| `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |

Both USnuJu and `/private/tmp/livemore-molecular-clock-evidence.W8cBUx`
pass all22 input +8 harness entries by complete SHA256, size and exact integer
mtime_ns, with stable before/open/after identities and bounded no-follow reads.
These are30 listed checks per root,28 distinct paths because the two page files
appear in both manifests. Five unchanged files match byte-for-byte. The current
checker/test/manifests, RED source, RED/GREEN outputs and complete diff match
their frozen hashes. W8cBUx's original259800B browser hash3a048e6b and
279933B supervision hash0b013508 remain exact; its embedded equality and FAILED
status are preserved. Neither the older clock failure nor older cancellations
are reclassified.

All12 original PNGs match their complete recorded hashes/counts and PNG-header
dimensions, including failure.png (not covered by the11 planned captures).
This is binary integrity/dimension inspection, not a new visual verdict.

| Original image | Bytes | Dimensions | SHA256 |
|---|---:|---|---|
| desktop-4obe.png | 172191 | 1440×1000 | `ee5325cbf6dee516c6f89c86ff9c31996ac3834ea352d87ca5870df87a7a5f72` |
| desktop-help.png | 151191 | 1440×1000 | `5353729778d3f680513778667c1e01e0bf9ccacbd6dcf7f6ef77d217355666ee` |
| desktop-distance.png | 177576 | 1440×1000 | `d65515e59f855e7d11206959ec90aa21fbf3e907e09f6a65c1829880fb8a9f9c` |
| desktop-1tup.png | 186291 | 1440×1000 | `85f44a0e1e859b90a8d509fedf04dd190058abb9a9fef7ee7b96f77db6bbd4f6` |
| desktop-1m17.png | 171653 | 1440×1000 | `2472b054be5cdd2f14a7cf3943d9dc2b1cf59bfbe59854c11d13daa5f963ffcf` |
| desktop-1n7d.png | 182834 | 1440×1000 | `aee829150ebea3b3d846188fcddca8cfe4f861f15a8bc817a6c9d807b5b06222` |
| desktop-6p2b.png | 201874 | 1440×1000 | `e664f48ca0723a0db6abb059bda57d7894b7e2d697ac6a50722e32cae901fdce` |
| desktop-4ins-pig.png | 133835 | 1440×1000 | `3a394e401b3ed9e4a07f206bd09a7dcc2171fefa84cd7a218fcf76011fd4b99d` |
| desktop-ins-unavailable.png | 51522 | 1440×1000 | `79247aa68e85d03f8da71c91f25ee99a4d87ec116d71f11b84ca62a067529289` |
| mobile-4obe.png | 79950 | 390×844 | `f3b2fe1e5c7f5f4a34001ce6e1305d604574ae4b7324ed6a20df3ea4e2d1f998` |
| mobile-provenance.png | 97280 | 390×844 | `03877bf3c1a1c3b9b1b8bf743085c9c383bce1e3b4e9129932c8146a36ff8275` |
| failure.png | 41455 | 390×844 | `d534fd733547a3985913e92b51f3dfae3703879b8f5b820103fccbb1c08c5511` |

Planned images total1,606,197B; including failure.png,1,647,652B. The run tree
has18 entries/16 files and2 directories. Evidence before supervision is1,907,450B,
exactly the recorded count; adding the280,204B supervision gives2,187,654B,
within64MiB. There are29 server reads/requests and10,296,699 served bytes,
within128 requests/32MiB; read lengths sum exactly to served_bytes.
Transport compact JSON is49,099B, below256KiB, with the unchanged71,680B
cutoff reservation. No clock-retention overflow or CLOCK_REJECTED event exists.

## Exact transport facts, without cross-plane substitution

Every CDP identity has exactly REQUEST, RESPONSE, then one FINISHED or FAILED.
There are35 identities/105 events:29 NETWORK and6 DATA_NON_NETWORK;32 FINISHED
and3 FAILED. Independent decimal parsing of the original JSON verifies all35
triples are finite/nonnegative and both response and terminal are at or after
their own immutable request origin. In25 FINISHED network triples, terminal
time is before its own response time but after its own request; no values were
sorted, rounded, clamped or replaced to reach this conclusion.

All29 NETWORK identities form an exact page/route/occurrence bijection across
CDP, server and Playwright. Each of29 server identities has REQUEST,
RESPONSE_FINISH and RESPONSE_CLOSE; both response events have complete request
and writable_finished true, and after_cutoff false. Playwright has29 identities/
58 events:26 FINISHED and3 FAILED. The original request_terminals likewise
retain26 finished and3 failed, with those three exact rows in network_failures.

The failed rows below are all desktop coordinate route occurrence1; target
mapping is checked against the retained source/provenance asset_path, not
guessed from ordinal. Times are original own-CDP protocol seconds.

| Target | CDP/server/Playwright ordinals | REQUEST | RESPONSE | FAILED |
|---|---|---:|---:|---:|
| KRAS /4OBE |8/8/8|481429.928196|481429.931711|481429.932568|
| TP53 /1TUP |14/11/11|481445.177077|481445.182055|481445.182452|
| EGFR /1M17 |16/13/13|481448.302832|481448.31002|481448.310389|

Each RESPONSE is200; each CDP FAILED is ERR_ABORTED, canceled true,
blocked_reason null, encoded_data_length null. The corresponding Playwright
identity is FAILED and the original terminal row also retains ERR_ABORTED
(KRAS stageD0, TP53/EGFR stageD2). The same occurrence's server identity is
FINISHED with both response completion flags true. This is the declared
PAGE_ROUTE_OCCURRENCE_ONLY correspondence, not shared native request-ID proof,
proof that a browser consumed the complete body, or grounds to replace FAILED
with the server's result. The observations do not yet identify cancellation's
causal owner.

Both immutable cutoffs have empty pending lists in all three planes and
detach SETTLED: desktop at37502.023209ms with20 correlation rows, mobile at
41489.775834ms with9. All three failure sequences precede the earliest owned
cleanup start37501.190292ms; final cleanup begins41459.003749999996ms.
No missing terminal is reconstructed from later cleanup. Empty pending means
all requests have terminal states, not that all terminal states succeeded.

## Recorded cleanup and conclusion

All eight recorded closes are SETTLED: desktop CDP/page/context, mobile
CDP/page/context, browser and server. Supervision records Node48802 reaped,
20 tracked descendants, none remaining, both listener checks NO_LISTENERS,
and cleanup_confirmed true without cleanup/evidence failure. Root separately
reported all21 exact recorded PIDs absent in99aed7; no liveness probe was made
by this auditor.

The request-origin correction retained real cancellation evidence and did not
turn rendered output into PASS. No source change, retry, ordinary Biology
integration, scientific qualification, release or recording is authorized by
this data audit. Both molecular failures and the paused native lane remain
unchanged.
