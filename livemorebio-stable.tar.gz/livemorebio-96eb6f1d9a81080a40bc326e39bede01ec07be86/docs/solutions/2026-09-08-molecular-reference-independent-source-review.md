# Six molecular references — independent original-data review

Verdict: **CLEAR for retained original-coordinate integrity and the stated
reference-only scope.** This is not admission of a finished catalog/API/viewer,
human equivalence, binding effect, molecular dynamics or any requested experiment.
The two numbering precisions below are required in the descriptor, not grounds
to replace or modify the original files.

Reviewed the complete source-admission receipt (SHA
`0593ec6f25a5aecacb7dc6dec4e2e2f905c29e8b839a5b4d035d402a0caaa0e4`),
parent structure-only plan §3 (plan SHA
`5b3e5f1b66f9b571988f8474f2b6397fea0d070df9ce335daacf2bf2f1200b43`),
the checker, selected original CIF fields, six entry JSONs and nine entity JSONs.
The RCSB skill's source-presentation rules were used; no new queries were made.

## Independent repeat and exact scope

Private originals: `/tmp/livemore-molecular-metadata.nBet7P/`.
Checker `inspect_mmcif.py` SHA:
`8d93c6dd06af514f1bf2534519874aae6372d50d78fb86c10dedf2006717564f`.
Retained `coordinate-inspection.json` SHA:
`acfd020938507cd799c5bd9d07e4b08dc5272188c0d9e27a06f6f8535cbba6cf`.
Exact Biopython1.88 MMCIF2Dict reader SHA:
`0b418606f5fea90a4841f54b9415ebd7351677f0a670c55e9c4ec4aaf72a3d8a`.

Ran the unchanged checker once with managed Python `-I -B`, a cleared environment
containing only PATH/LANG, its original30-second SIGALRM, and an additional
write/network/process/ctypes/model-import refusal audit hook. Captured stdout in
memory and compared all six complete structure objects to the retained JSON:
**exact equality**, excluding only elapsed time. Total0.444360792s;
checker0.436491458s; refused/unexpected operations0. Only Bio and Bio.File were
loaded from Biopython; no Bio.PDB package/model, NumPy, solver or product import.
No new artifact was written by that invocation and no original was changed.

All six source-admission SHA256/byte claims, latest revision/date agreement,
model IDs `[1]`, equal atom-column lengths, unique atom row IDs and finite x/y/z
checks passed. Counts reproduced exactly:

| Original | Bytes | Atom-site rows | H/D rows |
| --- | ---: | ---: | ---: |
| 4OBE | 888328 | 5725 | 2632 |
| 1TUP | 698225 | 5828 | 0 |
| 1M17 | 307709 | 2560 | 0 |
| 4INS | 186101 | 1182 | 0 |
| 1N7D | 652947 | 4956 | 0 |
| 6P2B | 556174 | 4914 | 18 |

These are atom-site rows, not unique chemical atoms or a coordinate-quality
validation. The checker is a dictionary/identity inspection, not an mmCIF schema,
bond, occupancy, missing-residue, assembly or physiological validator. It prints
chain/entity/source evidence but does not resolve sequence-number namespaces.

## Identity and construct conclusions

- 4OBE: source-declared human KRAS/P01116,169 aligned residues plus a leading
  expression-tag glycine per chain. GDP-bound fragment; E.coli is expression
  host, not the target species. [Original record](https://www.rcsb.org/structure/4OBE).
- 1TUP: protein entity3,219-residue sample (P04637 reference94–312), author
  chainsA/B/C = labelC/D/E. Synthetic DNA entity1 is labelA/authorE and entity2
  labelB/authorF. Select explicit entity + label/author namespace, never a bare
  ambiguous chain letter. [Original record](https://www.rcsb.org/structure/1TUP).
- **1M17 numbering precision:** author671–998 is sample6–333 and P00533
  reference695–1022; five cloning-artifact residues precede it. Original
  [CIF fields](/tmp/livemore-molecular-metadata.nBet7P/1M17.cif:1326) and retained
  entity JSON's SIFTS mapping agree on reference695, length328. Do not label
  author671–998 as UniProt numbering. [Original record](https://www.rcsb.org/structure/1M17).
- 4INS: both polymer entities are source-declared **Sus scrofa9823/P01315**,
 21/30 residues, label/author chainsA/C and B/D respectively. It is a related
  pig reference, not an admitted human INS structure. The source fields are
  [explicit](/tmp/livemore-molecular-metadata.nBet7P/4INS.cif:391).
- 1N7D: human LDLR extracellular699-residue construct, P01130 reference22–720;
  engineered N494Q/N636Q in author numbering correspond to reference515/657.
  Neither intact membrane receptor nor mutation-free native coordinates.
  [Exact mutations](/tmp/livemore-molecular-metadata.nBet7P/1N7D.cif:2568).
- **6P2B source-mapping distinction:** deposited
  [CIF](/tmp/livemore-molecular-metadata.nBet7P/6P2B.cif:572) explicitly records
  O75469-7; sample12–316 maps to source database169–473 and author130–434.
  Retained `6P2B.entity-1.json` instead has `rcsb_polymer_entity_align` with
  `provenance_source=SIFTS`, accessionO75469, entity start12, length305,
  reference start130 (thus130–434). Preserve both exact provenance/numbering
  assertions and mark their relationship **unreconciled/reference-only**;
  no inferred canonical full-PXR mapping. That entity JSON's SHA is
  `5d4242623d6b6734c249edcd146f6319e6cd065efde4ecfa23ce753bad5526c9`.
  The deposited title is tethered PXR-LBD/SRC-1p with **garcinoic acid**;39
  expression-tag-annotated residues per chain remain at sample1–11/317–344.
  Do not turn this into garcinol/arctigenin response evidence or a whole-cell model.
  [Original record](https://www.rcsb.org/structure/6P2B).

## Rights and remaining boundary

The source receipt's archive-data CC0 attribution boundary is appropriate;
it is **not** a blanket license for the augmented API responses. The retained
entity JSONs actually include DrugBank, ChEMBL, Pharos, Pfam and UniProt-provenance
annotation/target/cofactor fields. Keep those raw originals private; export only
the reviewed source-identifying fields/attribution and original coordinate bytes,
not third-party descriptive/clinical/pharmacology prose under a CC0 label.
This is a source-boundary check against retained evidence, not a new legal-policy
lookup or comprehensive third-party licensing determination.

No blocker to retaining these six immutable references within the approved scope.
Catalog must still expose human INS unavailability, ambiguous/unmapped targets,
all21 target obligations, construct/numbering/missingness limitations and explicit
REFERENCE_ONLY status. No coordinate substitution, data acquisition, runtime/API
edit, browser or biological execution occurred. Earlier failed scientific matrices
and remaining product acceptance obligations are unchanged.

## Independent catalog and reader admission — September 9

**CLEAR, limited to the fixed six-reference catalog, stdlib reader and narrow
package/fingerprint changes.** This does not admit API delivery, an installed
wheel, a rendered inspector, all-target coverage or any biological experiment.

Read all 2,050 catalog lines. Independently confirmed **60,294 UTF-8 bytes**
(60,290 Unicode characters), SHA256
`89a15b12f2dbe5aac1edc53885b525c72863b3bb915a6c3e81a044f74ed67360`.
The earlier 60,290-byte handoff was a character/byte-count error; catalog bytes
and hash did not change. The fixed reader now uses the correct byte length.

One bounded stdlib-only, read-only comparison checked the catalog against the
already retained inspection JSON, six original coordinate byte hashes and the
selected raw entry/entity JSONs. All 60 scalar identity/count/title/method/
resolution/author checks, every chain tuple, revision, citation, sequence-
difference row and all nine entity description/type/length/species/accession/
SIFTS objects matched exactly. Strict JSON loading rejected duplicate keys and
nonfinite constants. A 30-second alarm and write/network/process/ctypes refusal
hook bounded that comparison. It did **not** rerun the CIF parser, evaluate a
formula, acquire data or modify originals. Deposited sequence mappings were
checked against the exact source fields and prior namespace review above.

The catalog resolves the previous required precisions:

- PXR preserves deposited O75469-7/database169–473 separately from SIFTS
  O75469/reference130–434 and explicitly marks `UNRECONCILED_SOURCE_NAMESPACES`.
  Neither is relabeled as canonical full-PXR coordinates.
- EGFR author671–998 and database695–1022 remain separate; LDLR author494/636
  substitutions retain reference515/657 and engineered ASN→GLN identities.
- Human INS remains unavailable; both pig entities retain taxon9823/P01315 and
  appear only under the related reference. Bare author and label chain IDs are
  not merged. All 27 exact target keys remain, including ambiguous AMPK/GLUT1.
- Only reviewed source-identifying fields, citations and coordinates are
  admitted. The archive-only CC0 scope is explicit; no DrugBank/clinical/
  pharmacology prose from the augmented API responses is copied into the catalog.

Read the complete reader and test module, full `build_info.py`, and package-data
configuration. The new reader has fixed admitted filenames/digests, validates
caller target/digest syntax before asset access, verifies encoded bytes before
decoding/returning, bounds reads, refuses linked/nonregular direct files and
returns detached descriptors. Unknown/ambiguous targets do not trigger discovery.
The added `.cif` fingerprint suffix stays within existing asset roots; the package
configuration adds only `data/molecular/*.json` and `data/molecular/*.cif` patterns.
The present packaged catalog and all six CIFs match the retained originals.

Frozen reviewed source identities:

| File | SHA256 |
| --- | --- |
| `livemorebio/molecular_reference.py` | `b1f8533211b63eaa74ca279fd475ad4aab701a3ad30090892e382572a6cf7296` |
| `livemorebio/tests/test_molecular_reference.py` | `0cdb3b0de52f9179ab8ae0bfa88b2d4b9473add18aef1451d8fdc2c3c06d09ad` |
| `livemorebio/build_info.py` | `35e7882a3eb0b8bf7771392ed0f0addc8fcf8a15baea9276940f423b7b6dc593` |
| `pyproject.toml` | `98e37956ab8e6ae6841e0e140a0c73270db296646457fa66ef2017b25af1b979` |

Independent repeat: **47 passed in 0.21s**, process exit0, private review root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-oltmb16d`.
Used the established legacy harness refusal wrapper with only the pytest target
changed to `livemorebio/tests/test_molecular_reference.py`, explicit 45-second
SIGALRM, managed interpreter `-B`, reduced inherited environment and private
test directories. Unexpected I/O **0**, authored Node processes **0**, exact
optional Git lookup refused **1**. All frozen hashes remained unchanged.

The zip-resource test exercises the real Traversable branch but is not a built/
installed-wheel test. This grade does not cover the proposed strict audit path,
routes, authentication, UI/controller integration or browser cleanup. All prior
failed scientific results, six requested programs and open acceptance rows are
unchanged. No catalog, coordinate or runtime source was edited by this reviewer.
