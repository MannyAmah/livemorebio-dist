# Legacy preview D0: retained failure and bounded diagnostic proposal

Status: **proposal only**. No new request, service, browser, native execution,
test run or implementation edit. Investigate skill: source-first diagnosis;
the actual cause remains unknown, so no behavioral fix or larger retry is proposed.

## What the retained run establishes

Evidence root:
`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-legacy-preview-upv6333e`.

- `browser-result.json` SHA-256:
  `0505db6786cf15d28ddb1e756cebe2d3d59fab9b237fd1d22e32984895e82048`.
- `supervision.json` SHA-256:
  `78be1737f6075b77f342ed5957d6d7421db05bebcb20a1223395850075ed8cfb`.
- Three services reached exact source `d0311baf…`; no service failure/tripwire
  receipt appeared before or after cleanup. Their pre-cleanup poll results were null.
- Browser D0 is `FAIL/BROWSER_CHECK_FAILED`; all six later cases are `NOT_RUN`.
  Eighteen allowlisted GETs, including `/api/state`, were recorded; one bootstrap
  204 was observed, zero modeless state bodies were admitted, zero POSTs were sent.
  There is no `cookie_checks` field or image. This places the failure before cookie
  admission, but **zero admitted states does not mean zero HTTP responses**.
- All four direct children were reaped; eleven recorded descendants were absent.
  Listener query was `NO_LISTENERS/SETTLED`. Elapsed time was 17.74806404102128 s.
  The original run remains FAILED. No rendered acceptance is inferred.

## Concrete information loss, not a proven transport cause

Frozen `tools/check_legacy_preview_browser.cjs:124–125` changes any rejected
action to `BROWSER_CHECK_FAILED` unless `error.message` is exactly
`ACTION_TIMEOUT`. Installed Playwright's `TimeoutError` instead uses
`name="TimeoutError"` and a descriptive message. Thus the framework timeout and
the harness timer race can produce different retained labels for the same timed
operation. Other navigation/body/route rejections lose their operation and class.

Installed source under
`/Users/emman/.agents/skills/gstack/node_modules/playwright-core/lib/`:

- `client/errors.js:30–34,55–68`, SHA
  `13ec20bbf18461690043785515025bd3d3bfff8b51afcbf8c4e06dffbc014347`:
  exact timeout class and protocol error reconstruction.
- `client/network.js:546–547`, SHA
  `385cd7a58fea3cf46d82533b7c041eee41c903cf9179a810da11f4953df4d9e3`:
  `Response.body()` awaits the response channel; a rejection reaches `action()`.
- `client/frame.js:102–105`: navigation passes its configured timeout to the
  channel. The existing harness supplies 10 seconds, not a larger navigation budget.

The actual pre-cookie candidates include navigation, route continuation or actual
state-body rejection. A response-body failure inside the observer can set the
generic fault before its outer catch labels `ACTUAL_AUTH_STATE_INVALID`. No saved
operation/class/status distinguishes these. The source does **not** justify blaming
auth, a server 500, modeless admission, Chrome transport or a DOM timeout.

Actual product `index.html:370–379,814–820` awaits initial current-state handling
before mounting Evidence; that handler catches failed reads. Consequently the
recorded `/api/evidence` request does not establish successful state admission.
Product `server.py:397–405` returns an authenticated JSON state; no special streaming
behavior or new request is needed for this diagnostic.

## Proposed harness-only diagnostic increment

Own only the same CJS and dedicated harness tests, plus Python parent admission
only if needed to admit the new fixed optional diagnostic fields. No product,
client, service, model, route, fixture-value or acceptance-threshold changes.

1. Give each existing asynchronous action a fixed literal operation label.
   Freeze labels: `ALLOCATE_BROWSER`, `ALLOCATE_CONTEXT`, `ALLOCATE_PAGE`,
   `SETUP_BINDING`, `SETUP_SCRIPT`, `SETUP_ROUTES`, `NAVIGATE`, `ROUTE_CONTINUE`,
   `ROUTE_FULFILL`, `ROUTE_ABORT`, `RESPONSE_BODY`, `AUTH_RESPONSE`, `STATE_PARSE`,
   `STATE_ADMISSION`, `COOKIE_READ`, `DOM_WAIT`, `DOM_EVALUATE`, `DOM_ACTION`,
   `SCREENSHOT`, `SERVICE_HEALTH`, `SERVICE_BODY`, `POLL`, `HOLD`, `CLEANUP`,
   `FINAL_EVIDENCE`, `UNKNOWN`. Each concurrent operation carries its own label and
   starting case/context; do not infer its origin from a shared last-action variable.
2. Retain at most one `first_failure` object with exact keys `case`, `context`,
   `operation`, `error_class`, `code`. Class is one of `TimeoutError`,
   `TargetClosedError`, `TypeError`, `RangeError`, `SyntaxError`, `Error`, `OTHER`.
   Read only allowlisted class identity/name; no arbitrary names, messages, stack,
   selectors, URLs, request bodies, response bodies, tokens or cookie values.
   Recognized Playwright timeout and the existing harness action timeout both map
   to `ACTION_TIMEOUT`, without changing any timer. Preserve the original first
   failure across observer, route-abort, screenshot and cleanup failures.
3. Attach bounded response metadata to the existing allowlisted request record,
   using the original request object's identity: HTTP status (100–599 or null),
   body stage (`NOT_READ`, `READING`, `READ`, `FAILED`, `NOT_REQUIRED`) and modeless
   admission (`null`, true, false). No second GET/body read, body hash or payload
   persistence. Reuse the existing maximum 256 records. Record only fixed D0
   check booleans for navigation completion, modeless admission, cookie admission,
   profile match and service checks. Unknown/unreached stays false, not PASS.
4. On failure, use the originally allowed failure-image allowance: **at most one**
   ordinary full-viewport screenshot of the current authored private page, before
   cleanup, with no click, scroll, evaluate, reload, input or other user action.
   Attempt only if browser/context/page ownership is recorded and still confirmed,
   the page is locally open and no allocation remains unresolved. Otherwise record
   an explicit fixed skip status. Capture is bounded at 2 seconds, at most 4 MiB,
   still inside 180 seconds and 64 MiB. It never changes the primary failure.
   Name derives only from fixed case/context; record its actual bytes/hash/viewport,
   and fixed caption that it is failure evidence, not visual acceptance. Keep it
   in `failure_images`, separate from the twelve planned images. No synthesized
   image, retry capture or attempt on another page/context.
5. Keep the 159-second work bound and 21-second cleanup reserve. At final stop
   there are at most three owned browser/context/page resources (desktop resources
   close before mobile allocation); 2-second failure capture + 3-second drain +
   9-second owned closes + 3-second observers fit that reserve. All existing action,
   held-GET, parent, request, POST and image limits remain unchanged. Failure capture
   is an explicit diagnostic-only exception to the stopped owner's no-new-action
   rule, never a continuation of the test sequence.

## Required offline REDs and next decision

Before implementation, use the existing mounted inert runner to reject navigation
and actual state-body promises with native-shaped TimeoutError/Error instances
containing private sentinels. Demonstrate the present generic mask and absent
phase/status evidence. Cover first-error preservation under concurrent failures,
HTTP non-200 metadata, screenshot success/timeout/size failure, and unresolved
ownership skipping capture. No real browser, services or network for these tests.
Retain all 84 current tests; do not turn this into another scenario matrix.

Freeze code/tests/receipts for root's independent grade. Only then may root decide
one further actual run. If new fixed evidence shows a product, transport or DOM
defect, stop and propose that exact correction; do not silently change the modeled
state, parser, auth, timeout or allowlist. Both prior actual failures stay intact.

## Root pre-code decision

Root read the full proposal and original CJS action/response/catch paths. Approve
this harness-only diagnostic correction and targeted offline REDs. No inferred
product fix or automatic rerun. Use the existing fixed request objects and one
body read; capture the exception's safe category at its origin before a generic
outer catch overwrites it. Failure screenshot remains diagnostic-only, at the
current viewport with confirmed ownership, and cannot change primary failure or
the normal12-image acceptance. Keep the test set focused on these concrete gaps,
not a new general browser framework. Freeze for independent source/test review.
