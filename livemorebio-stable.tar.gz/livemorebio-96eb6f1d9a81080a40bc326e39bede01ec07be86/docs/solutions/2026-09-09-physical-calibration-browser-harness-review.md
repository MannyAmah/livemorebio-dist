# Native calibration dialog: bounded harness increment

## Approved scope before implementation

Root approved the four-image, zero-POST scenario proposed in
`2026-09-09-physical-pairing-calibration-correction.md` after independently reading
the two product files and repeating69 tests (11.87s, `28dg0y0y`, session9318,
external I/O0, Node67). Product files are now frozen. This packet owns only
`tools/check_legacy_preview_browser.py`, its `.cjs`, a new dedicated
`livemorebio/tests/test_physical_calibration_browser_harness.py`, and this report.
No browser/service launch is authorized by harness implementation approval.

The complete existing Python/CJS harness and gstack browse instructions were
read. Browse is used for its ordinary inspection/input/screenshot discipline;
this spawned offline preparation does not run CLI setup, telemetry, installation
or a browser. The existing approved pinned gstack Playwright/owned Chrome path
is preserved. Missing Context7/gbrain/CE tools remain unavailable; no new library
is introduced. Original retained failures and accepted legacy16 images remain.

## Exact reuse and separation

Add one fixed CLI scenario `physical-calibration`; omitted scenario retains the
existing legacy workflow, schema, four authored POST deliveries, seven cases and
16 ordered images. No legacy fixture, tolerance or expected screenshot changes.
The physical scenario reuses the same private0700 environment, empty authored
modeless registry, constructor-denying three services, fixed8910–12 free checks,
startup45s, browser180s, request256/action10s/evidence64MiB ceilings, outer
supervision and exact owned cleanup. It does not run the legacy scenario first.

The fresh technical registry fixture need not acquire `life_patch` consent: this
is a zero-write dialog check, not permission to bind hardware. Do not change its
consent, observations, naming or reference defaults. The actual current record
must be the exact fixture ID/version, ACTIVE/REAL_HUMAN and observations-only;
the actual state must remain UNAVAILABLE/MODEL_BINDING_REQUIRED with null model
and physiology. Compare this before and after each owned context using fixed
protected same-origin GETs. All three startup/process/source identities match.

Use an optional fixed scenario value in the private config and a distinct
`livemore.physical-calibration-browser-result.v1` result with four cases `D0`,
`D1`, `M0`, `M1`. Python receipt admission dispatches only on the supervisor's
chosen scenario, never on an untrusted receipt's claim. Config validation rejects
unknown/non-string scenarios before allocating a browser. No-argument/default
legacy behavior remains unchanged.

## Requests and observations

Physical browser routes allow only `/twins`, `/favicon.ico`, the exact existing
Twins static dependency closure, `/api/session/bootstrap`, `/api/build`,
`/api/services`, `/api/state`, `/api/population-capabilities` and
`/api/twins?limit=10`. The known Google font stylesheet may be blocked as in the
existing harness; no font request is forwarded externally. Every POST and all
other routes fail closed before forwarding. No response or module is rewritten,
and no request body is collected. Fixed API context reads use exact200,
`maxRedirects:0`, existing bounded body admission and the same action budget.

A page-owned handle may retain only two synchronous event counters for the
physical form: native `invalid` (capture) and `submit`. Listeners observe, never
prevent/dispatch events or change form values. No global patient/clinical state
hook, binding-delivery promise, injected submission or DOM content rewrite.
The context's close removes these listeners; ordinary successful context close
can explicitly dispose the handle first. Persist only fixed booleans, known
calibration/focus enums, counts and measured geometry, never authored input text
or raw state/error payloads. Capture partial evidence before assertions.

## Fixed native workflow and screenshots

Desktop1280×900, then a fresh390×844 browser context:

1. `D0`: ordinary Twins page and exact record, native click Pair physical Patch.
   Device focus, blank required select, readonly2.0/B0, warning copy. Screenshot
   `physical-desktop-open` targets the upper declaration paragraph.
2. `D1`: fill only fixed clearly authored device/firmware/attestation text. Native
   click submit with blank select: exactly one invalid event, no submit event,
   valueMissing and calibration focus. Focus calibration and native ArrowDown
   twice (Current then Due), requiring those observed values without retries.
   Native submit: one submit event, still zero POST, fixed local rejection,
   accessible association and calibration focus. Screenshot
   `physical-desktop-rejected`. ArrowUp selects Current, never submit it. Escape
   closes dialog and returns focus to the opener; reopen via that actual button,
   verify blank/cleared fields/feedback/device focus. Close before context cleanup.
3. `M0`: fresh context/current identity, ordinary open and upper warning copy.
   Screenshot `physical-mobile-open`.
4. `M1`: same blank native validation. Native ArrowDown three times requires
   Current, Due, Failed in order. Native submit yields one submit event, visible
   fixed local feedback and zero POST. Screenshot `physical-mobile-rejected`.
   Escape/reopen verifies blank/reset/device focus, then close and exact final
   identity check. There is no positive pairing POST or actual device record.

Fixed observations are desktop-open, desktop-blank, desktop-due,
desktop-current, desktop-reopen, mobile-open, mobile-blank, mobile-failed and
mobile-reopen. Do not treat missing rows as PASS. Every case is PASS/FAIL/NOT_RUN,
and failure retains the active case plus existing bounded owned failure image.
Screenshots use ordinary viewport rendering, no annotation, hiding or CSS edits.

Use native `scrollIntoView` on the actual upper paragraph or lower feedback as
needed. Geometry targets must be fully within both the viewport and the visible
dialog interior, hit-test to themselves/descendants, and show no horizontal page
or dialog overflow. The upper image does not claim the entire tall form fits;
the lower image must include the calibration control and complete feedback.
Store the same checked target/viewport/scroll metadata with the image; Python
admission verifies four original PNG hashes/sizes/dimensions and row coupling.

## Red-first verification and freeze

Dedicated inert tests cover exact scenario dispatch/default preservation;
zero-POST/unknown route rejection; real serialized DOM-reader predicates and
geometry including mobile internal scrolling; native count/focus/value/reset
negatives; fixed workflow key order/no Current submit; four-image/row admission
and corrupt/missing receipts. Use authored browser doubles only, never Playwright
launch. Retain all174 existing harness tests unchanged. Root independently reads
and repeats the frozen packet before any real run. Actual screenshots still need
independent visual inspection; a technical green is not native acceptance.

## Root-approved preservation refinement before final freeze

The first complete239 repeat retained238 PASS and1 FAIL in19.88s,
private`g21xz_0i`, session83549 closed exit1, unexpected I/O0, Node196,
refused Git1. All65 physical cases passed. The unchanged inherited
`test_trusted_static_import_closure_contains_no_graphics_vendor` failed because
root's concurrent current-product `execution_anatomy.js` now statically imports
`molecular_inspector.js`, which imports `molecular_loader.js`. The legacy static
allowlist omitted these two app-owned, import-safe modules.

Root explicitly approved adding exactly these two filenames to the existing
legacy `STATIC` list before repeating239. No vendor/coordinate endpoint or
physical allowlist is added; neither module opens a viewer at import. This is a
current-source dependency-closure correction, not expanded physical coverage or
a change to the original174 tests,16 images, four POSTs or legacy scenarios.
The failed source-integration repeat remains attributable to the pre-refinement
CJS SHA256 `8d2532181c90e5a79daf84e281a50e52feb1272bc3ccdfde35c434fa1b05fcf9`.

## Implementation and retained test evidence

Implementation is frozen for independent review, not native browser acceptance.
Only the two existing harness files and the new dedicated test were changed.
Product calibration, registry, v2 payload, services, device stores, dependencies
and numerical models were not edited or executed by this packet.

Exact review map in the frozen source:

- CJS lines14–18: approved legacy static dependency closure only; lines23–27 and
  58–70: separate physical constants and GET-only routing.
- CJS214–294: synchronous form observer, serialized safe DOM predicates,
  dual geometry/semantic gates, fixed native workflow, four-case receipt.
- CJS312–321: optional exact scenario validation; 357–435: exact current source,
  actual protected reads, scoped routing, bootstrap and owned observer setup.
- CJS449–463 and489–494: original screenshot bytes plus physical row coupling
  and bounded failure capture; 509–531: physical hooks into existing ownership;
  565–590: fixed failure/cleanup/admission dispatch and exports.
- Python45–52: physical names/reads; 349–436: physical-only receipt/image
  admission; 439–444: supervisor-selected dispatch; 544,602–603 and636–638:
  optional CLI/config/main routing. Existing default limits remain unchanged.
- New test file:262 lines,65 cases. The final63 lines exercise the actual
  `run()` orchestration with an inert Playwright-module substitute and reject
  invalid direct scenarios before package loading. No actual browser launches.

| Retained stage | Result | Private suffix / session | Refusal counts |
|---|---|---|---|
| Initial37, before implementation |29 FAIL /8 PASS,3.18s|`c2vzbm3o` /9614|I/O0, Node37, Git0|
| Initial37 implementation |37 PASS,3.17s|`v0h3d4_l` /49380|I/O0, Node37, Git0|
| Expanded55 receipt negatives |2 FAIL /53 PASS,3.87s|`q3h3hgz8` /95692|I/O0, Node44, Git0|
| Image boolean numeric alias |1 FAIL /55 deselected,0.11s|`_l207hqt`, direct closed exec|I/O0, Node0, Git0|
| Expanded65 runner fixture |1 FAIL /64 PASS,4.72s|`yf5qlngc` /69651|I/O0, Node53, Git0|
| First239 preservation |1 FAIL /238 PASS,19.88s|`g21xz_0i` /83549|I/O0, Node196, Git1|
| Final239 after authorized closure correction |239 PASS,20.36s|`lct3ia23` /76935|I/O0, Node196, Git1|

All listed sessions ended; no browser, service, native model or package process
was launched. The expanded55 REDs exposed acceptance of a wrong GET category and
a boolean cookie-context index. The separate image RED exposed Python equality
aliasing a boolean image x coordinate to numeric1. The corresponding typed
receipt checks were tightened without changing native workflows.

The65 runner failure was an authored test-template mistake, not a product
finding: broad replacement of `MODE` also rewrote the expected string
`ACTUAL_MODELESS_REQUIRED`. Replacement is now anchored to the exact declaration
`const mode=MODE,`; every source/failure/partial-evidence assertion remains.
The first239 failure and its narrow authorized correction are recorded above.

The new65 cover9 allowed reads,9 denied mutation/unknown routes, valid dual
admission,16 contradictory DOM/geometry rows, default preservation, exact key
sequence/no Current submit,6 actual serialized observer checks,13 strict
receipt/image cases,5 actual inert-runner failure/lifecycle paths and4 invalid
direct scenario cases. Technical PNG-header fixtures test admission, not visible
pixels or native validity. Focus, native select behavior and dialog rendering
still require the separately authorized real browser and independent inspection.

### Frozen SHA256 identities

| File | SHA256 |
|---|---|
| tools/check_legacy_preview_browser.py | `4edfbf6898609aa35f234944074b0671df24306f2ad2a177eca7a3bd1c9f946c` |
| tools/check_legacy_preview_browser.cjs | `7a4838e9144fdf6efc5c5ceba93943a03bea3030ad884aeafcb749232e4870fb` |
| livemorebio/tests/test_physical_calibration_browser_harness.py | `0ff2b47372178540ee42a15db2409e25dbd813b69824446a8b726e2afea22c5c` |
| unchanged test_legacy_preview_browser_harness.py | `896045af52165af134f57c19f2e93fb2335520b0169b43f221bd2190c12238c7` |
| unchanged test_legacy_banner_browser_harness.py | `8aac85655e5b9c55042011c917034e62b7333596756468dd5cfcca0dcd081076` |
| unchanged test_legacy_current_feedback_browser_harness.py | `9108af494d6713548aa0eba118a3f7131a383c35423a2898bc148e3480c466f3` |

### Exact isolated repeat command

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`. The45s wrapper
allows only exact authored Node `--eval` children, with parent and child
network/process refusal. It is bounded test instrumentation, not an OS sandbox.
The one exact Git-metadata attempt is refused, not forwarded.

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - \
  livemorebio/tests/test_physical_calibration_browser_harness.py \
  livemorebio/tests/test_legacy_preview_browser_harness.py \
  livemorebio/tests/test_legacy_banner_browser_harness.py \
  livemorebio/tests/test_legacy_current_feedback_browser_harness.py <<'PY'
import os,socket,subprocess,sys,urllib.request,ctypes,signal
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1';os.environ['PYTHONDONTWRITEBYTECODE']='1'
signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1;permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=line',*sys.argv[1:]])
print('Refusal counts:',counts,flush=True);signal.alarm(0)
raise SystemExit(status)

PY
```

### Compounded lesson and remaining gates

Native browser checks need both actual form-validity behavior and visible local
feedback; authored DOM objects cannot establish those. Receipt admission must
validate primitive types before comparing corresponding geometry/counters.
The ordinary page's static import closure can change without opening its
optional viewer; preserve that closure without authorizing dynamic vendor or
coordinate requests.

This packet does not retire the accepted original16 screenshots or claim a
rerun of them. Root must independently review/repeat before launching the fixed
four-image physical scenario and inspecting every original image. Full physical
v3 registered manifests, authorization, durable receipts, SDK/CLI, hardware and
measured validation remain separate required work; all original product and
scientific-program scope remains active.

## Root independent technical repeat

Root reports full changed-source/test read and an independent239 PASS in20.33s,
private`w50n7b05`, session98858, unexpected I/O0, Node196, refused Git1. Pre/post
Python`4edfbf…`, CJS`7a4838…`, test`0ff2b4…` matched the frozen identities above.
Root confirmed the only legacy closure change is the two app-owned static names.
Runtime and harness are now frozen for root's separately controlled four-image,
zero-POST actual run. No actual result or visual acceptance is claimed here.
