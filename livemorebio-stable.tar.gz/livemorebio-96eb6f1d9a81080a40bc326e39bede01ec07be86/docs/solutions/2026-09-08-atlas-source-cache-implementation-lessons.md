# Atlas source/cache implementation: pre-admission lessons

Date: 2026-09-08. Scope: approved source/cache lane A only. The complete renderer,
physiological state binding and R01–R51 obligations remain active. No actual
publisher acquisition or conversion was run during this implementation packet.

## What exists at the review checkpoint

- A SHA-pinned packaged declaration retaining all 489 source members and nine
  disjoint group sets from the independently reviewed source candidate.
- Strict source OBJ parsing and trimesh 5.0.0 conversion without processing,
  repairing, welding, decimation or normal normalization.
- Independent GLB decoding checks every native position, source normal,
  triangle/index, exact ID/node hierarchy and common once-only meter transform.
  The audit preserves original source-degenerate face indices and exposes
  per-node/group native/world bounds and membership relations.
- Read-only, network-free readiness/asset access; exact fixed-source install;
  private descriptor-relative storage; immutable artifacts and separate durable
  receipts/pointer with directory fsync ordering and explicit reconciliation.
- Two sequential owned phases, acquisition 600 seconds and conversion 180
  seconds. A stdlib-only bootstrap arms the absolute deadline and parent-loss
  guard before importing Livemore. Each orphan keeps the inherited lock until
  exit. No phase can count its own output as admitted geometry.

These are engineering implementation claims, not independent acceptance, actual
source conversion, rendered geometry, patient registration or physiological
qualification. All integration fixtures use nine explicitly technical triangles,
never publisher geometry or patient records. Temporary worker tests do not start
or mutate product services.

## Red-first record

Initial missing-module tests were red before implementation. The initial
parser/catalog/technical-roundtrip packet reached 62 passing cases. Subsequent
cache tests began with **10 failures / 13 passes**, identifying acquisition status,
unsafe-file handling, missing-component corruption, total-deadline admission,
same-digest artifact corruption and converter identity issues. They were fixed
and retained as regression tests.

The next strict-GLB/process packet began with **5 failures / 38 passes**:
nonfinite/deep JSON, unsupported buffer targets, trailing unreferenced BIN bytes,
and unrelated inherited environment credentials. The next storage packet began
with **3 failures / 33 passes** for replaced root descriptors, potentially blocking
nonregular-file opens and reused-install directory durability reconciliation.
Two additional red assertions added explicit source membership/bounds and retained
source-degenerate face-index audit data.

The reviewed hard-acquisition amendment began with **11 failures / 3 preserved
process-test passes**. Actual owned subprocess checks now cover blocked-operation
stand-ins, absolute deadlines, parent EOF, an intentionally stopped orphan, and
a killed parent while application import is genuinely stalled by a technical
import hook. These are deliberately shortened engineering tests, not external
network-performance claims.

Independent geometry review found boolean node references could alias integer
indices through Python equality. Both reported cases plus boolean accessor bounds
were reproduced as **3 failing tests** before strict type checks. A related
staging-metadata boolean/number alias was separately reproduced red and fixed
using canonical typed comparisons.

A full run then exposed a real race between OS-timer termination and process-group
cleanup on macOS. The owned group could disappear before waitpid observed exit;
cleanup raised rather than reaping the child. A deterministic failing regression
was added before implementing exact-child reap handling. There is no blanket
exception suppression or retry of acquisition/publication.

## Durable rules

1. A download finishing after a deadline must be rejected, but that alone does
   not enforce bounded resource use. Protect the whole acquisition/import phase
   with an owned process deadline, not a timeout on a thread that keeps running.
2. Inherited file locks must remain held by an orphan until it exits. Never
   explicitly unlock or replace the shared lock file during cleanup.
3. A matching manifest cannot rehabilitate corrupted same-digest geometry.
   Compare all immutable bytes to independently verified staging before writing
   a new receipt or active pointer.
4. A ready pointer with missing source/receipt/asset means corruption, not a fresh
   install. Do not silently reacquire or rewrite it during status/read.
5. Python numeric/container equality does not establish JSON type identity.
   Validate index/numeric domains and compare typed canonical metadata.
6. `marshal.dumps(code)` alone is not a stable portable runtime identity: checkout
   paths and reference/intern flags can change serialized bytes around execution.
   Bind explicit loaded bytecode/constants/defaults and relevant parser/exporter
   settings without reading later disk contents or storing filesystem paths.
7. A source-native/common-coordinate body is still reference geometry. No scalar
   cardiac/metabolic value is a measured spatial deformation field.

CE/gbrain tools were unavailable in this session; this document records the
compounding work without claiming an unavailable tool invocation. Ruff was not
installed in the selected interpreter; no dependency installation was performed.
The packet still requires root and independent full source review, followed by
explicit actual-source execution and separate rendered acceptance.

## Independent full-review correction checkpoint

The reviewer independently reproduced 136 passing tests, but did **not** accept
the initial cache/process packet. Three P2 gaps were demonstrated using only
technical files/processes: raw lock-opening/locking exceptions, invalid receipt
promotion before complete validation, and descendants surviving a reaped phase
leader. Preserve this initial result; passing tests did not cover those contracts.

Lock and receipt regressions started at **9 failed / 2 passed**, then the full
cache file reached **48 passed**. Unsafe lock failures are now fixed safe errors
before source access. One shared receipt rule validates the prospective operation
and any reused receipt before immutable publication or active-pointer replacement;
clock rollback cannot destroy the previous active selection.

The process correction is written separately in
`2026-09-08-atlas-cache-review-corrections.md` and remains at its pre-code review
gate. The earlier exact-child reap fix is insufficient for descendant cleanup;
it must not be cited as proof of the full process-group/orphan contract. Hold an
unreaped ownership anchor until group termination is verified, and keep a
stdlib-only guardian separate from import/native work when protecting parent-loss
cleanup. Exact worker exit is not exact group exit. No actual publisher bytes
have been acquired or converted under this candidate.

The guardian correction was subsequently approved before implementation. See the
cache-review amendment's superseding implementation/investigation checkpoint.
The actual shortened deadline tests found a Darwin interval where `getpgid`
returns ESRCH before WNOWAIT exposes the owned child's exit. An immediate second
check is not enough. Keep the ownership anchor and observe within the existing
cleanup budget without signalling an uncertain group; then prove all group
members stopped before reaping. Deterministic transient/permanent tests plus
twelve real shortened deadlines now cover that distinction. The process/worker
matrix is 59 passing tests at this checkpoint, not yet an independent acceptance.
