# Registry terminal correction — frozen maker evidence

2026-09-08. **Ready for independent re-review, not accepted by its maker.** This
implements the root/independently approved
[terminal correction](2026-09-08-committed-registry-terminal-correction.md).
The [original maker report](2026-09-08-committed-registry-transitions-implementation-review.md)
and [independent blocking findings](2026-09-08-committed-registry-transitions-independent-findings.md)
are preserved unchanged. Their earlier passing tests do not negate those defects.

## Frozen files

| File | SHA-256 |
|---|---|
| `livemorebio/aegle/subjects.py` | `3778a837877b57623112549884a379930c348987942d83d1ed6d2e53d29dd51a` |
| `livemorebio/aegle/registry_audit.py` | `b21f01fdf1c79604c5565fee0f7d94d3b0bd11967b199bc97ec8a193de045e4e` |
| `livemorebio/tests/test_committed_registry_transitions.py` | `f3cb3a549b4e0c99ffb6096c838468399c19249047407201ca444195ce01b22e` |

Only these three owned runtime/test files changed. The new report/approved
proposal document the correction; no old report or scientific evidence was
rewritten. Atlas harness implementation was transferred to the UI owner before
this work. No browser, HTTP, listener query, service, native model or operational
record was used.

## Correction boundaries

The private audit `_append_row` forms an immutable exact ID/sequence/nonce/
ciphertext tuple from its canonical authenticated payload **before insertion**.
It verifies stored bytes against that origin tuple. BEGIN retains the origin
through reservation insertion and then verifies both the event and exact reserved
event/request pair. Completion retains its origin through reservation deletion,
then verifies the terminal bytes and reservation absence. Public `begin` and
`finish` return contracts, payloads, AAD, encryption and quotas are unchanged;
there is no parallel durable receipt or mutable last-event cache.

The transition helper repeats its full expected record/index/pointer/ACTIVE
check after completion and before commit. Original BEGIN, verified terminal and
reservation absence remain bound to the same writer transaction and subsequent
single read-only lost-ACK witness. A failed terminal side effect cannot be
silently repeated during ACCESS_FAILED: that completion obtains the writer lock
and authority, captures a fresh bounded raw relevant-state baseline, then checks
it after its writes. Unexpected changes roll back; the primary error and pending
reservation remain. It does not decrypt clinical data or retry the mutation.

Activation preparation is now strictly structural, including when called through
the real authority guard. The standalone wrapper preserves its non-SYNTHETIC
profile admission after preparation and before commit, with no locks owned by
the wrapper. Server candidate/model construction remains root-owned outside its
authority guard. No REAL_HUMAN binding or clinical-to-parameter shortcut is added.

## Red/green evidence

The expanded packet first produced **18 failed / 96 passed in4.44s**, including
the exact independent trigger cases, reservation and BEGIN graph faults,
different-but-authentic terminal metadata, and the authority-held profile entry.
Private root: `livemore-research-review-kl8h_v4l`.

The first device-side-effect fixture was rejected by its foreign-key constraint,
so it did not exercise the missing last-write check. The authored mutation was
corrected to alter the valid device `bound_at` column instead: **1 failed /
113 deselected in0.91s** before implementation, root
`livemore-research-review-kbgzp8y3`. No product constraint was relaxed.

After correction: **114 owned tests passed in4.34s**, root
`livemore-research-review-pbka7kxv`. Expanded complete preservation, including all
original seven-file cases and the four named legacy lifecycle/pairing cases:
**392 passed in21.55s**, one existing Starlette deprecation warning, root
`livemore-research-review-ec6hoamu`. All processes finished.

From `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```sh
/Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B tools/run_review_tests.py -q -p no:cacheprovider -p livemorebio.tests.test_committed_registry_transitions livemorebio/tests/test_committed_registry_transitions.py livemorebio/tests/test_subject_registry_audit_contract.py livemorebio/tests/test_registry_bootstrap_contract.py livemorebio/tests/test_registry_bootstrap_shape.py livemorebio/tests/test_clinical_descriptive_registry.py livemorebio/tests/test_real_cohort_contract.py livemorebio/tests/test_selection_reconciliation_registry.py livemorebio/tests/test_subject_lifecycle.py::test_virtual_patch_binding_retains_admitted_protocol_version livemorebio/tests/test_subject_lifecycle.py::test_only_authoritative_twin_remains_active livemorebio/tests/test_subject_lifecycle.py::test_physical_patch_pairing_requires_active_consented_human_and_attestation livemorebio/tests/test_subject_lifecycle.py::test_active_twin_survives_registry_restart_and_physical_device_cannot_double_pair --tb=short
```

The selected test module is also the global socket-construction/DNS/helper,
urllib, subprocess and numerical/profile-construction refusal plugin. Tests
deliberately substitute harmless candidate objects only where checking unlocked
ordering; no physiology is executed. All stores are fresh authored fixtures.

## Limits and lesson

Independent regrading remains required. These corrections do not accept server
publication, startup, old observation selection/reconciliation, arbitrary other
audited-read mutation protection, physical qualification or browser behavior.
No source equations, model inputs, numerical gates or six-program identities
changed. The original failed insulin benchmark is still failed; the static OSP
packet remains uninvoked.

Lesson: an expected audit witness must originate before its write, and both
SUCCESS and failure-completion writes must be followed by the appropriate exact
state check. A closed database connection is not proof that an outer authority
lock is released. These boundaries are now executable technical tests, not a
claim of clinical or whole-human equivalence.
