# Atlas source-preserving selection and view-state correction

Written before code. Status: exact plan proposed for independent review.
R21–R27/R46 remain open; no new browser attempt is authorized by this document.
Root has read the complete remaining-dependency proposal, all42 retained ordinary
screenshots, the complete pancreas-overlap diagnosis and current148-line scene,
174-line controller, CSS and applicable tests. The retained Atlas result remains
28 PASS /3 FAIL /25 NOT_RUN. This correction is not its replacement receipt.

## Office-hours / CEO decision

The defect is selection presentation, not corrupted coordinates. Native source
FJ1895 and FJ2629 share334 exact positions and93 exact triangle-coordinate sets,
and have6,619 strict native crossing pairs. Selected-only teal exposes surfaces
which overlap by construction. Deleting, welding, moving or depth-offsetting
elements would change or obscure the admitted source and is rejected. A full
silhouette postprocessing pipeline is unnecessary and adds GPU resources for a
simple exact-ID selection task. Choose unchanged assembled fills plus a labeled
screen-space extent cue; retain explicit single-element isolation.

The current status also confuses loaded resources with visible pixels. Separate
loading status from current view settings; do not infer pixel visibility from
the number of loaded partitions or renderer draw calls. Unrelated molecular
dependencies, label collisions, transport/performance and capture failures remain
separate open corrections. No visual style redesign, source acquisition or
biological mechanism is introduced by this packet.

## Exact engineering contract

Owned runtime files: `atlas_reference_scene.js`, `atlas_reference.js`,
`atlas_reference.css`, plus a small pure `atlas_reference_presentation.js` helper.
Owned tests: a new focused presentation packet and only necessary fixture
capabilities in existing scene/controller tests. No converter, manifest, asset,
vendor, server, source/runtime-identity or numerical code changes.

1. Assembled material fills remain the existing group colors regardless of the
   selected element. Only explicit `isolated === true` and exact selected ID uses
   teal. Preserve opacity, transparency, depth write/test, clipping, side settings,
   draw order, transforms and every geometry array. Never toggle unrelated mesh
   visibility merely to make a selected mesh prominent. Existing explicit isolate
   behavior and automatic selected-group enabling remain unchanged.
2. Add one DOM overlay inside the canvas host, outside the label host and never
   in the THREE scene. It is pointer-events:none and aria-hidden; the existing
   live selected-identity inspector supplies accessible identity. It has corner
   brackets and exact `FJ` ID; text calls it a **source extent**, not a contour,
   observed physiology or proof of camera visibility. No GPU mesh, material,
   render target, model displacement or free-running render loop is added.
3. Obtain the selected object's world bounding box from the admitted loaded mesh.
   Project all8 box corners with the existing camera on demand. Pure helper
   accepts exactly8 finite `{x,y,z,depth}` values (NDC coordinates plus positive
   forward camera-space depth), camera near/far and viewport dimensions, clamps
   the rectangle to an8px inset, rejects empty rectangles and bounds output to the
   viewport. If any corner is behind/intersects the camera near plane, suppress
   the cue rather than invent a front-facing extent. Do not call the projected
   box an anatomical contour or claim occlusion testing. Reject viewports with
   either dimension<=16, any corner at/before near, extents wholly at/beyond far
   or fully outside the viewport, and zero projected area. A second pure helper
   bounds the separately measured ID label to the same8px viewport inset; suppress
   the label if it cannot fit rather than overflow or change anatomy framing.
4. Suppress the cue on no selection, unloaded/hidden selected object, context loss,
   disposal, hidden document and **any active section plane**. Sectioning may cut
   source surfaces in complex ways; this small packet does not invent a clipped
   anatomical contour or scan all triangles to claim pixel visibility. The
   inspector explicitly explains this conditional behavior and points to Section
   off / Frame selected / Isolate / Return to whole person. The full visible
   geometry and existing section controls remain available and unchanged.
5. Camera changes, resize, selection, group toggles, isolation/return and existing
   requestDraw events update/hide the cue. Context-loss handler hides immediately;
   scene `visible()` hides immediately when document.hidden, otherwise requests a
   demand draw. A frame pending before hide is canceled and its handle cleared
   immediately. The controller calls it for both visibility transitions, without
   changing its existing asset cancellation/resume fences. No scheduled frames
   while hidden and no render loop while idle. Disposal removes the owned DOM.
6. Loading messages say `N /9 reference layers loaded`, not drawn. Keep their
   pending/partial/ready/error/unavailable state taxonomy and exact source gates.
   Add a separate, wrapping view-state sentence derived from current view and
   loaded membership: N layers enabled (or exact isolated ID), loaded count,
   and Section off/active. Never call this visible/rendered anatomy. When all
   loaded layers are disabled, explicitly say that and offer Return to whole
   person. While a section is active say a cut can leave an empty view and explain
   Section off/Return. Do not overwrite renderer failure with a healthy view-state
   message; hide the view-state sentence when scene is not operational or its
   current message state is error/unavailable/paused/pending. The existing ready()
   can remain true after a failed refresh retaining geometry; do not use it alone
   for this new sentence. Restore after successful source/load recovery only.
   Isolated selection whose layer is unloaded or disabled gets that exact
   pending/empty-setting description, not an implied displayed-element claim.
7. The existing selected-identity text retains name/FJ/FMA/relations/counts/bounds/
   source hash and reference-only limitations. Append concise cue/isolation/section
   explanation without deleting provenance. Selection is still the exact source
   ID, never an alias of a neighboring pancreas representation.
8. Make long installation acknowledgment text wrap within the existing host;
   content/status and no-automatic-POST semantics stay unchanged. This is a small
   presentation guard, not a claim that the still-unrun390px case passed.

Pure helper uses browser-independent arithmetic and no third-party library API.
Renderer integration reuses the pinned local THREE Box3/Vector3/projection APIs
already in this source; no dependency is installed. Context7/gbrain/CE are not
callable in this session (tool search checked); existing primary dependency audit
and local pinned API code are the fallback. No remote patient/reference query.

## Required red-before-green tests

- Two distinct coincident/intersecting authored mesh IDs: selection preserves all
  position/index/normal arrays and world matrices; assembled fills/depth/visibility
  unchanged; exact selected ID still emitted. Explicit isolate applies teal only
  there and Return removes it. Retain all loaded meshes and resource counts.
- Pure extent projection: ordinary and coincident corners, partly/fully outside,
  wholly/partly behind near plane, nonfinite/malformed values, zero viewport,
  tiny/390/768/1440 viewports, degenerate extent, deterministic clamped output.
  No oversized overlay or misleading full-canvas fallback.
- Actual scene with pinned THREE arithmetic and a non-GPU technical renderer:
  cue created once; demand update on selection/camera/resize; suppression on
  layer hidden, section active, hidden document, context loss, late parse and
  disposal. Source geometry and raycast target membership stay untouched.
- Actual controller: loaded counts distinct from enabled and isolated state;
  disabled-all, section-on/off, source failure, retry, missing source and manifest
  changes retain correct feedback and controls. Installation acknowledgment text
  and earlier readiness semantics remain preserved.
- Run all preserved Atlas contract/loader/renderer/client tests under isolated
  review. Record exact counts, hashes and any changed fixture assumptions.

Independent source review follows implementation before a new browser is opened.
The later ordinary browser acceptance must compare assembled/isolated at the
same retained camera and include small-screen cue/text placement. It must retain
the source/renderer/resource/transport/performance and all14 fault obligations.
No maker self-grading or screenshot-only claim closes this packet.

## Compounding and residual work

Selection emphasis must respect overlapping source representations. A screen-space
extent is presentation state, not a new anatomical fact. Loaded, enabled, isolated,
sectioned and pixel-visible are different states and must not share one success
label. Pure arithmetic tests establish layout bounds, not GPU visual quality.

This does not implement label collision layout, local molecular dependencies,
native physiology, physical LIFE-v3, committed source transitions, the six
experiment programs or their videos. Those original tasks remain on R01–R51.

## Independent pre-code review and frozen interfaces

Independent reviewer accepted this minimal direction with two precisions now
incorporated above: depth/near/far plus label bounds, and failure-state gating
separate from retained-geometry readiness. It also required immediate cancellation
of a pending hidden-view frame. Root accepts these before implementation. Required
RED additions: finite behind-camera projection; near equality/crossing; wholly
far extent; long label/tiny rectangle; available→failed refresh→recovery;
isolate→disable/re-enable selected layer; pending frame→hide cancellation.

Parallel ownership after this exact plan approval:

- Source helper maker: new `atlas_reference_presentation.js` only, exporting
  `projectedSourceExtent(corners,width,height,near,far)` returning
  `{x,y,width,height}|null`, and
  `boundedExtentLabel(extent,labelWidth,labelHeight,width,height)` returning
  `{x,y}|null`. Label anchor prefers extent.x/y, clamped to viewport inset.
  Both are pure, fail closed, do not mutate inputs, accept no optional unbounded
  configuration. New `test_atlas_extent_projection.py` owns arithmetic tests.
- UI maker: `atlas_reference.js` controller only, new
  `test_atlas_view_status.py`. Existing test fixture capability edits only if
  strictly necessary and recorded. Calls scene.visible() in both transitions,
  preserves old control/source gates, separate view sentence with explicit
  failure gating, loaded wording and retained selected identity explanation.
- Root: `atlas_reference_scene.js`, CSS and new scene tests. Uses the helper
  interface above and preserves all source geometry/material/selection contracts.
- Independent reviewer does not write implementation; frozen packet must be
  reviewed and tested before any later ordinary browser acceptance.

### Label measurement refinement, before final correction

Independent review flagged that an absolutely positioned label may shrink to fit
at its previous inline position, then grow after its new anchor is assigned.
Root's additional authored layout-sensitive test reproduces inset overflow
(1 failed,12 deselected,1.03s); it is not an actual browser-layout result.
Approved correction within the existing measured-label bound: reset label left
and top to the neutral8px inset before measuring, then assign the independently
bounded anchor. This gives the measurement the full already-bounded width budget.
No geometry, viewport, camera, font, text or clipping changes. Recheck the focused
and preserved packet; keep the actual narrow browser-layout gate open.
