# Research workflow: independent browser QA

Status: DONE for the requested Research UI scope after independent retest. Both reported UI defects were corrected by the implementation owner and verified below. This is a software-interface check, not biological qualification.

| Field | Value |
|---|---|
| Date | 2026-09-05 |
| URL | http://127.0.0.1:8860/research |
| Branch | codex/research-validation, uncommitted working tree |
| Scope | Four Research tabs, frozen PXR study, absent measurements, learning proposals, unavailable disease references, desktop/mobile layout |
| Browser | Local Chromium through agent-browser, isolated session |
| Framework | Existing vanilla JavaScript console, authenticated API |
| Independence | Tester did not implement Research page or research backend |
| Data | Clearly labeled reference-cohort software checks; no physical measurement uploads |

## Results

| Check | Result |
|---|---|
| All four tabs visibly select and reveal only their section | Pass |
| Saved PXR run deep link loads exact run and three frozen members | Pass |
| Freeze with explicit nonclinical tolerance, UI-check method/material, specimen mapping | Pass |
| No-measurement comparison | AWAITING MEASUREMENTS; live calibration not authorized |
| Resilience placeholder protocol submission | Rejected, no protocol created; visible, focused inline alert verified after fix |
| Scientific-learning proposal | PROPOSED; interface states biological model has not changed |
| KEGG and MalaCards lookup | Unavailable, no licensed local release imported; no manufactured reference record |
| 390 × 844 viewport | No document overflow across all four tabs; primary navigation scrolls within its own container |
| Browser JavaScript/console errors | Zero observed during listed interactions |

Saved software-only records:

- Frozen study `research-18193524b13d410ba7801d8edff59981` from PXR run `protocol-0840aa065227413382b77746ea80bc41`. Title explicitly states no physical specimen collected. Absolute tolerance 0.1 is labeled a software acceptance criterion, not a clinical or biological criterion.
- Learning proposal `research-86c23dfc2f15479eadacbed03e3c473c`, labeled UI-check provenance work, not a new scientific finding.

## Original findings, both verified fixed

### RQA-001: Comparison card covers the ledger while scrolling

Severity: medium. Category: visual.

1. Open Prediction & measurement on a 1440 × 1000 viewport with a saved study and comparison result.
2. Scroll down through the freeze form.
3. The comparison card remains fixed at the top and covers the ledger heading, refresh control, and first record.

Reproduced twice. At the captured position, the card occupies y=16–686 while the ledger occupies y=425–834. Those two elements overlap in the same right column.

Before: [visible separate cards](../screenshots/research-validation/research-ledger-overlap.png).
After: [scrolled overlap](../screenshots/research-validation/research-ledger-overlap-scrolled.png).

### RQA-002: Form errors can be outside the viewport with no local feedback

Severity: medium. Category: UX.

1. Open Treatment-free resilience.
2. Leave the clearly marked template unchanged and scroll to Register immutable resilience protocol.
3. Click Register. The server is not called, and the template is correctly rejected.
4. At the click position, the interface shows no explanation. The error only appears in the page-level status above the viewport; the local result remains empty.

Reproduced twice. In the capture the status top was y=-127.55. A user who does not scroll back up can interpret the button as doing nothing.

Evidence: [before submission](../screenshots/research-validation/research-error-before.png), [after submission](../screenshots/research-validation/research-error-after.png), [error found above the form](../screenshots/research-validation/research-resilience-blocked.png).

## Evidence captures

- [Freeze preparation](../screenshots/research-validation/research-freeze-preparation.png)
- [Missing measurement gate](../screenshots/research-validation/research-missing-measurements.png)
- [Proposed learning record](../screenshots/research-validation/research-learning-proposed.png)
- [Unavailable references](../screenshots/research-validation/research-references-unavailable.png)
- [Mobile comparison](../screenshots/research-validation/research-comparison-mobile.png)
- [Mobile references](../screenshots/research-validation/research-references-mobile.png)

## Scoped health and release limits

Initial scoped UI score: 98/100 using the QA rubric: visual 92, UX 92, other observed categories 100. Two medium findings, no critical/high finding in the covered flows. A numeric score does not make these issues acceptable or establish broader platform readiness.

No Research source edits were made by this tester. Both findings were returned to the implementation owner. Measurement file admission, biological qualification, valid disease-specific resilience criteria, instrument authenticity, and clinical transfer were not demonstrated by this check. Real physical measurements were deliberately not fabricated.

## Independent fix verification

Retested on the same local service and saved software-check study after the owner updated the UI:

- RQA-001 verified fixed. The comparison card now scrolls in document flow. At the reproduced desktop scroll position, its bottom was y=409.56 and the ledger began at y=431.56, preserving a 22 px gap. Ledger heading, refresh control, and both saved records were visible. [After-fix desktop screenshot](../screenshots/research-validation/research-ledger-fixed.png).
- RQA-002 verified fixed. Submitting the unchanged resilience template created one inline alert directly below the submitting form, scrolled it into view, and moved focus to the alert. At 1440 × 1000 the alert occupied y=535.45–558.55. At 390 × 844 it occupied y=398.42–444.61 with no document overflow. Repeating the submission did not accumulate duplicate alerts. [After-fix desktop screenshot](../screenshots/research-validation/research-error-fixed.png), [after-fix mobile screenshot](../screenshots/research-validation/research-error-fixed-mobile.png).
- Missing-measurement comparison still returned AWAITING MEASUREMENTS and denied live-twin calibration.
- Zero page exceptions or console errors observed during the retest. No new measurements or research records were created.

Final scoped UI score: 100/100 against the observed checklist, with zero unresolved findings in this bounded Research UI pass. This score is not a whole-platform audit, scientific-validation score, or release authorization.
