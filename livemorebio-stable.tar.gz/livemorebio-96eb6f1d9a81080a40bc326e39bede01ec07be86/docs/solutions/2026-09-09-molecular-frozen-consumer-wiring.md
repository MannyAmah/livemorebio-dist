# Saved-experiment molecular reference wiring

Pre-code continuation of the approved three-consumer controller plan. This
preserves legacy experiments; it does not substitute them for the six requested
scientific programs. The built vendor, ordinary Biology switch and full browser
matrix remain pending. No experimental execution is authorized by this slice.

## Decision and scope review

Reuse the existing runAnatomyProjection, run anatomy controls and common owned
molecular inspector. One runtime file: console/lib/run_anatomy.js. One dedicated
Node-handler test file. Do not change protocol endpoints, saved results, numerical
quantities, replay speed, member picker, current-twin selection or physical data.
No third-party library API is added. The Context7/gbrain/CE tool inventory is
unavailable; actual existing source and docs/solutions supplied local prior art.

The current saved view lists target names without actionable molecular controls.
Add actual target buttons and an inspector host outside recreated detail content.
Bind each opening to detached run/protocol/cohort/member/condition, selected stage,
recorded axis and frozen structure identity. Include JSON tuple encoding to avoid
delimiter aliasing. A PXR NR1I2 reference passes the run's exact recorded PDB ID;
other organ targets remain separate reference lookups, never a substitute target
for the run. If the frozen PXR identity is absent/malformed, reject that opening
locally; do not silently remove the identity check. Non-PXR references pass no
invented PDB. No /api/state or experiment mutation request is introduced.

On a changed accepted selection or organ, invalidate/close the old reference
before enabling the new contextual opening. Old detached button handlers must
not act on a later member. The common inspector synchronously invalidates its
epoch in setContext/close; use its own cleanup contract rather than another
plugin owner. Late failed tasks cannot overwrite newer feedback. A same-selection
graphics retry does not destroy a still-current reference. Invalid inspection
must retire molecular context, not leave an old reference labeled current.

Clone initial/subsequent caller-owned inspection before async work so a later
caller mutation cannot relabel a pending geometry or molecular join. Preserve
runAnatomyProjection's existing detached fields and add only the selected stage.
Disposal retires once, observes cleanup rejections, and attempts molecular cleanup
even if geometry cleanup throws. Fixed error text only; no raw private details.

## Red-first acceptance inventory

Mount actual run consumer with inert renderer/inspector seams. Cases cover lazy
mount/buttons, exact target and frozen PDB, unknown target, missing/malformed PXR
identity, immutable input, member/stage/time change, stale retained handlers,
organ selection, graphics retry/control preservation, invalid replacement,
open/close/dispose errors and geometry-dispose failure. Independent source review
and repeat follow the maker checks. Existing anatomy/protocol tests remain
unchanged; model/renderer/network execution is not needed for these handler tests.

All R01–R51 remain active. Functional reference access is not a cell-reaction
trajectory, measured human equivalence or an acceptable experiment video.

## Maker evidence; independent review pending

Original18 handler cases failed1.98s (35842/wzgil8yj): target controls were absent.
Implementation18 passed1.85s (86006/sl2un6p4). A new immediate post-selection
click exposed deferred setContext:18 passed/1 failed1.90s (19030/_y3lfg09).
Calling the common owner synchronously corrected it:19 passed1.95s
(65391/k52v6n5j). Existing anatomy/protocol/controller preservation then144 passed
16.56s (39986/6fjzujnz). Four extra pending-input/non-PXR/cleanup cases brought
the final packet to148 passed17.08s (85855/hhg4xth7), Node149, unexpected I/O0.
All are authored UI seams; no coordinate-renderer, native biological engine,
server/browser or operational store was started. Legacy test assertions remain.
The separate reviewer is inspecting/repeating the23 new cases. No product
rendering acceptance or installed-source switch follows from maker results.

## Independent review — scoped source/handler clearance

The non-maker reviewer fully read this plan, the complete consumer and 23 tests,
the common inspector, authentication fetch setup, reference loader, actual
protocol_biology parent and protocolInspection producer. Runtime SHA256 remains
`445ef425fa952772bb93d5f898b8f8ea751b789527a3f2cca07ff14a4d8a4e85`;
test SHA256 remains
`4d092e22cb6d218d0e84fb67588cb52cc13ca5824cabd999fc7869091aa39633`.

Independent repeat: **23 passed in 2.35 s**, private review root suffix
`hmyzhns3`, session `38889`, closed exit 0. The 45-second isolated wrapper allowed
only the exact Node `--eval` test child with injected network/process refusals;
Python socket/DNS/urllib/native-loader/process refusals remained active. Receipt:
unexpected I/O 0, Node 23, refused Git 0. No browser, server, numerical model,
coordinate acquisition or operational store was used. No implementation or test
file was edited by the reviewer.

No actionable blocker found in this delta. Context invalidation is synchronous
before replacement handlers run; run/member/stage/native-axis/PDB identity is
detached and tuple-bound, stale buttons and late failures are fenced, exact
recorded PXR identity is required, and other reference targets do not replace it.
Disposal still attempts molecular retirement after geometry cleanup failure.
An invalid inspection is also caught by the actual parent, which disposes and
removes the view; it does not leave the old retry control current.

This clears the bounded source and authored-handler packet, not rendered
molecular acceptance, installed vendor availability, a prototype-viewer switch,
or the full three-consumer browser matrix. Existing metformin/garcinoic-acid
history is preserved, not evidence for the six requested experiments. All wider
product and scientific gates remain open.
