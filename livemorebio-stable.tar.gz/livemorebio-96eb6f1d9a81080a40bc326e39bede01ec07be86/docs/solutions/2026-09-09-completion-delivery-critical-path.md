# Completion delivery critical path

Approved continuation: Emmanuel requested completion, evidence, recordings and the
previously omitted technical product deck on 2026-09-09. The existing reviewed
R01–R51 recovery plan remains the scope of record; this plan neither closes nor
deletes any requirement. The timer/tracker stays disabled.

## Parallel work and acceptance

1. Scientific engine owner completes the fixed direct-.NET parent/worker
   connection, RED-first. Root reviews the source and tests before one bounded
   native qualification. This is a prerequisite, not insulin or human validation.
2. Connected-workflow owner corrects ordinary Cendos preparation/history action
   ownership and investigates registered-twin Biology/LIFE behavior. No fabricated
   healthy cohorts, overwritten stores or substitute botanical programs.
3. Deck owner delivers an editable 22–24-slide technical deck, source notes and
   rendered slides. Root inspects the rendered deck independently. Conceptual
   LIFE hardware images are not fabrication evidence.
4. Root verifies the supported normal UI path on an isolated three-service stack,
   prepares genuine browser recordings, checks installation/CLI evidence, and
   writes a short current tester guide without replacing the historical guide.

## Concrete decision rules

- Preserve the original source, tests, services and experiments. Private review
  stores start empty and are never borrowed from a real person or old experiment.
- A model registry or protocol button is not a completed scientific execution.
  Every displayed time trace must bind to its actual calculated/observed source.
- The exact six experiment programs remain insulin, erinacine A, sterubin,
  carnosic acid, arctigenin and cyanidin-3-glucoside. Missing mechanisms or exposure
  data are explicit blockers; old metformin/lobeline recordings do not satisfy them.
- A reference population can contain measured joint attributes while lacking
  identified individual kinetics. Do not bypass that distinction for a demo.
- New corrections need a failing test, passing regression and independent review.
  Real browser operation and video review follow source freeze, not inert tests.
- Use finite diagnostics and a genuinely different alternative after repeated
  failures; do not relax scientific thresholds or describe an unexecuted test as
  passing. Do not repeatedly launch an unqualified native candidate.
- No main push, public installer claim, release or scientific equivalence claim
  while its respective acceptance gate remains unfulfilled.

## Packaging finding retained

The existing wheel lacks the cardiac CellML artifact. The managed source-archive
installer is a different path and must be tested separately. Official PMR source
metadata was rechecked on 2026-09-09 and still leaves that artifact's terms
unspecified. The FDA CiPA C implementation has an explicit source notice, but is
not a silently interchangeable CellML artifact or a drop-in numerical replacement.
Do not hide the packaging gap by bundling a new unreviewed model.

Sources: [PMR exact model](https://models.cellml.org/e/5a0/ohara_rudy_cipa_v1_2017.cellml/source_text),
[FDA CiPA source](https://github.com/FDA/CiPA/blob/master/AP_simulation/models/newordherg_qNet.c).
