# Observation selection and checked reconciliation: registry implementation

2026-09-08. Maker packet, not independent acceptance. Root approved the complete
architecture, independent addendum, 62-case inventory and corrected RED before
runtime authoring. This lane owns subjects.py and the named registry tests only.
Server, UI/SDK, audit encryption/bootstrap, source authority, execution manager,
all biological programs and operational data are outside this increment.

Read with the
[approved publication plan](2026-09-08-observation-reconciliation-committed-publication-plan.md),
[exact inventory](2026-09-08-observation-reconciliation-registry-test-inventory.md)
and [original/corrected RED receipt](2026-09-08-observation-registry-red-receipt.md).
The original failures remain retained; no source/model qualification or full
product availability follows from these authored registry tests.

## Implemented boundary

`SubjectRegistry.prepare_observation_selection` validates the safely incrementable
exact request version, target and canonical UUID before storage. It captures the
same full bounded target/selected rows, pointer timestamp, ACTIVE topology and
bootstrap authority through the existing `_selection_read_access`. The fourth
fixed kind is select_observations; preparation is inspect, mutation BEGIN/result
is select_observations under the unchanged subject-access schema.

`_transition_changes` adds only the REAL_HUMAN observation transformation. It
demotes at most one distinct selected row, increments the target once, sets
ACTIVE/observations_only, and uses the same timestamp for target/demotion/pointer.
Every mutated revision must be below MAX; read-only checked capture stays
inclusive at MAX. No activation admission, model constructor, physical index or
unrelated clinical write is introduced. `_validate_transition` independently
reconstructs the fourth transformation with canonical typed equality.

The existing fixed audit phase, reservation re-entry, last-write raw comparisons,
rollback handling and exact read-only commit witness are unchanged. Only this
kind's mutation action is selected at the call site. Exact lost-ACK acceptance
still requires both audit rows, reservation absence, all affected/untouched
captured rows, pointer, device scope and ACTIVE topology. Close failure after a
confirmed commit still yields COMMITTED_CLEANUP_UNCONFIRMED; no new retry exists.

The public direct select_observations wrapper now uses that same full preparation
and commit; the prior unbounded ACTIVE-row loop and target-only ACK witness are
removed. An optional legacy PreparedObservationSelection retains its public
type/signature. Fresh audited preparation provides the current raw authority;
the legacy digest must match the exact target. Canonical byte validation rejects
float/bool aliases and extra edits. Reconstructing every affected row/pointer
with the legacy timestamp preserves the valid legacy result without mixing old
and fresh timestamps. Existing canonical UTC validation runs before mutation.
Confirmed cleanup uncertainty is surfaced through the existing fixed typed code.
The pure standalone preparation remains detached/no-I/O with a safely
incrementable version guard; it is not represented as raw store authority.

Checked capture accepts exactly type(str) values inspect and reconcile_selection.
The private helper validates the same allowlist before I/O; final confirmation
always uses reconcile_selection. Default checked startup remains inspect, while
the default unchecked dict-returning path remains unchanged. Checked rows,
pointer, topology, token validation and no-return-on-audit/close-uncertainty are
reused rather than duplicated.

## Retained execution history and fixture corrections

1. Original frozen test 0d64a367…: 53 failed / 9 passed in 2.31 s. Three valid
   direct cases failed in a test assertion that omitted registry_store_id from
   the expected full registry_state table. They were explicitly not product RED.
2. Root approved retaining all non-active state tuples and replacing only the
   pointer tuple. Corrected test e64845fb…: 53 failed / 9 passed in 2.19 s. The
   three cases then reached the missing four-event audit contract. These RED
   results and exact reusable command are fully retained in the linked receipt.
3. First runtime repeat: 61 passed / 1 failed in 2.88 s, private
   `livemore-research-review-yzjwyanx`. The orphan-pointer fixture incorrectly
   deleted the entire registry_state table, including store identity; bootstrap
   correctly rejected that different corruption before the intended topology
   check. Root approved adding only WHERE state_key='active_twin_id'. All original
   row/pointer invariance assertions remain; no runtime workaround was made.
4. The corrected exact 62 passed in 2.72 s, private
   `livemore-research-review-eqlbbqg8`, at subjects b5306edc… and test4bb6115a….
5. First 62+616 foundation repeat: 677 passed / 1 failed / 4 real_process
   deselected, one existing FastAPI/Starlette warning, 28.80 s. Private
   `livemore-research-review-cdv9b7i3`. The inherited lost-ACK fixture did not arm
   for the prepared owner's parameterized pointer INSERT. Its original failure
   is retained, and the exact proposed test-only migration is appended to the
   inventory. No mutation retry or source adjustment is justified by this miss.

Every run used fresh private review stores and the same socket/process/native
refusals, printed zero unexpected attempts and one exact optional Git metadata
refusal. All test processes completed. No browser, service, real HTTP, R/compiler,
solver, native physiology or operational registry ran. The private test data and
deliberately damaged audit/witness outcomes were not repaired after failures.

## Named inherited migrations

The checked-startup forbidden-action fixture replaces only newly allowed
reconcile_selection with select_observations and retains all three before-I/O
cases. The existing selection audit-failure rollback test now verifies the
prescribed actual target/demoted revisions before injecting its SUCCESS failure,
and asserts exactly one mutation-phase fault. It no longer fails falsely during
the newly added preparation audit. All original rollback/pointer assertions stay.

Root subsequently approved the discovered lost-ACK detector migration. It keeps
the original literal detector and additionally recognizes only the exact prepared
pointer INSERT and active_twin_id first parameter. Actual arm, commit-then-raise
and denied recovery-connection counters must each equal one. Existing fixed
uncertainty and retained version2 assertions remain. No other inherited fixture
change was made; the runtime stayed unchanged through both preservation runs.

## Lesson and remaining gates

When a compatibility wrapper gains a durable preparation phase, tests must prove
which phase they fault. A passing early failure is not proof of mutation rollback,
and an unarmed SQL-literal detector is not proof of ACK handling. Likewise, tests
for pointer absence must preserve immutable store identity to exercise the
intended topology check. Exact intermediate failures and corrections are part of
the evidence, not noise to discard.

The complete bounded final preservation result, hashes and reusable command are
recorded below. Root must independently review/repeat this maker packet.
Actual registry-to-route integration, ordinary browser/terminal acceptance, four
excluded process obligations, and all six scientific programs remain separate
required work; no whole-product or biological claim is made here.

## Final frozen files and actual preservation receipt

After root approved the third fixture migration, the exact 62+616 packet passed:
**678 passed, 4 explicitly deselected, 1 existing warning in 29.16 s**, exit 0.
The existing warning is the FastAPI/Starlette TestClient httpx deprecation emitted
on module collection; no ASGI client or live service was run in this packet.
Final private root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-ds1k2q57`.
The final tool chunk is `82b179`; printed counters were `REVIEW_IO_COUNTS 0 1`.
All test processes completed before this freeze. The 62 dedicated tests, including
full witness/failure-phase assertions previously blocked by the missing method,
are included in the final 678. This is maker evidence pending root review.

| Frozen file | SHA256 |
|---|---|
| subjects.py, only runtime edited by this lane | b5306edc2045fd98e943f9fefc124872996563c3c955fece4ec7aebb718d6441 |
| test_observation_committed_registry.py, 62 cases / 630 lines | 4bb6115aa8c0458fd4b6d9ec71bdc349f4ad36325887c45ec59531d903af220a |
| test_checked_startup_selection.py, mapped action migration only | 79c956b637912d4b90148efd62272a72af12515585daa161613bd1a133cb8569 |
| test_clinical_descriptive_registry.py, two mapped fault migrations | 04eed584be6876a64d9e4ca5ac707b696c8c3448a0abd81efd2ce52665f59d1f |
| registry_audit.py, unchanged | b21f01fdf1c79604c5565fee0f7d94d3b0bd11967b199bc97ec8a193de045e4e |
| registry_bootstrap.py, unchanged | 83d00d6ac21515bc6925e09e9f70c93489c3a77fca1a3a44d01fae27e1714455 |
| test_committed_registry_transitions.py, unchanged foundation/plugin | 1985dc98faa36b6ac7914e921cc817cd9afd50cd2526c456d502f621c53e9e03 |

The original subjects source was 0a8eaee99b653a1b1823a1434c2e5ff1a2d468dc9659677cb426b33f6389b465.
This lane never edited server.py. The root-owned server moved independently from
cedcf801… (original RED) to observed878e5855… during implementation; this packet
does not grade or freeze root's server changes.

The four excluded cases are the two parameterizations of each bootstrap
`test_real_process_concurrent_candidates_create_only_one_authority` and
`test_real_process_crash_preserves_orphan_key_or_pending_attempt`. They are not
reported as newly passed. No exclusion applies to the 62 new cases or any other
part of the declared 616-case foundation.

## Exact final protected repeat command

From `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os, sys, signal, socket, subprocess, urllib.request, multiprocessing.process
from tools.run_review_stack import prepare_review_environment
review_root, env = prepare_review_environment(inherited={k: os.environ[k] for k in
    ('PATH', 'HOME', 'TMPDIR', 'LANG', 'LC_ALL') if k in os.environ})
os.environ.clear(); os.environ.update(env)
os.environ.update(PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
blocked, metadata = [], []
def deny(*args, **kwargs):
    blocked.append('unexpected')
    raise AssertionError('Registry review forbids network/child/native work')
def process(command, *args, **kwargs):
    if command == ['git', '-C', '/Users/emman/Livemore/.worktrees/full-scope-recovery', 'rev-parse', '--show-toplevel']:
        metadata.append('refused')
        raise OSError('Authored unavailable Git metadata')
    return deny()
def audit(event, args):
    if event in {'os.fork', 'os.forkpty', 'os.posix_spawn', 'os.exec', 'subprocess.Popen', 'socket.__new__', 'socket.connect', 'socket.getaddrinfo'}:
        deny()
sys.addaudithook(audit)
multiprocessing.process.BaseProcess.start = deny
socket.socket.connect = deny
socket.getaddrinfo = socket.create_connection = deny
urllib.request.urlopen = urllib.request.OpenerDirector.open = deny
subprocess.Popen = process
import pytest
signal.alarm(60)
print('PRIVATE_REVIEW_ROOT', review_root, flush=True)
files = ['test_observation_committed_registry.py', 'test_checked_startup_selection.py',
         'test_committed_registry_transitions.py', 'test_subject_registry_audit_contract.py',
         'test_registry_bootstrap_contract.py', 'test_registry_bootstrap_shape.py',
         'test_clinical_descriptive_registry.py', 'test_real_cohort_contract.py',
         'test_selection_reconciliation_registry.py']
nodes = ['test_virtual_patch_binding_retains_admitted_protocol_version',
         'test_only_authoritative_twin_remains_active',
         'test_physical_patch_pairing_requires_active_consented_human_and_attestation',
         'test_active_twin_survives_registry_restart_and_physical_device_cannot_double_pair']
rc = pytest.main(['-q', '-p', 'no:cacheprovider', '-p',
    'livemorebio.tests.test_committed_registry_transitions',
    *[f'livemorebio/tests/{f}' for f in files],
    *[f'livemorebio/tests/test_subject_lifecycle.py::{n}' for n in nodes],
    '-k', 'not real_process', '--tb=short'])
print('REVIEW_IO_COUNTS', len(blocked), len(metadata), flush=True)
signal.alarm(0)
raise SystemExit(rc)
PY
```

The existing registry plugin enforces clinical/profile/compiler exclusions for
the entire selected packet. The new test additionally traps actual AegleTwin and
MetabolicProfile constructors. AES encryption/decryption and private SQLite are
deliberately real; physiological initialization and process execution are not.
No source fixture, original failure receipt or intentionally damaged evidence
was rewritten to present a cleaner outcome.

## Root independent registry gate

Root reviewed the changed fourth-transition preparation/reconstruction/commit
action, direct compatibility wrapper and checked reconciliation action paths;
the complete630-line dedicated test; and all three approved inherited fixture
migrations. The frozen runtime, new test, inherited tests and unchanged audit/
bootstrap hashes were independently verified against the table above.

Using the exact final protected command above, root independently obtained
**678 passed, 4 deselected, 1 existing warning in29.45s**, exit0, private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-v958ecsh`.
REVIEW_IO_COUNTS was0 1. The test process completed. No constructor, network,
native process, service, operational record or earlier failed evidence was used.

**CLEAR for this bounded registry contract.** No unresolved critical source
finding was found in the reviewed increment. The four excluded real-process
obligations remain open. Actual encrypted-registry-to-new-route wiring is the
next separate integration gate; browser, full product and biological qualification
remain open. This acceptance cannot be used to mark those obligations passed.
