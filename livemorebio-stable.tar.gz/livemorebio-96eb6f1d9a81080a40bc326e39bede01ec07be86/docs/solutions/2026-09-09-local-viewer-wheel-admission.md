# Local molecular viewer distribution correction

Root found during independent integration inspection that the current package
data declares only console/lib/*.js and *.css. The newly reviewed nested 3Dmol
bundle and its required license notices would therefore be absent from a clean
wheel even though the source checkout works.

Before changing packaging, add installed-wheel assertions for the exact unchanged
bundle SHA and all three notice files. Confirm failure. Add only the fixed
versioned vendor-directory pattern; do not broadly include caches, experiments,
models or other user files. Repeat the real wheel build and outside-checkout
runtime test. Existing seven CIF/source tests and source-missing Atlas behavior
must stay intact. Independent review must examine this two-file delta.
