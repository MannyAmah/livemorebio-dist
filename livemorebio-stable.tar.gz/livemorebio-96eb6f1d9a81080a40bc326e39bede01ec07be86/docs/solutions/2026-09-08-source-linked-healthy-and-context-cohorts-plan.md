# Source-linked healthy and context-specific cohorts

Date: 2026-09-08. Status: **PROPOSED — independent approval required before implementation.**
Parent: [full-scope recovery, R05/R15/R17/R18/R19](2026-09-08-full-scope-recovery-plan.md).
This document is the only change authorized by this planning task. No source data
was downloaded, no cohort was created, and no physiology or API was changed.

## Decision and acceptance boundary

Implement a new, versioned **empirical reference-cohort construction path** using
linked participant-level public measurements. Preserve measured tuples from the
same survey record instead of reconstructing a joint population from independent
marginal means, assumed allele frequencies or disease labels. Keep an explicit
healthy-reference template for initial inspection, but do not count a template
or an unavailable capability notice as a working healthy cohort generator.

The first population is a **screened, normal-glycemia, prescription-free adult
reference subset** of NHANES August 2021–August 2023. Its short UI heading may be
“Healthy reference,” but the full screening definition and limitations must be
adjacent and persistent: these are public-data-derived research models, not
enrolled people, not proven disease-free humans, and not a representative sample
of every age, geography or disease. Non-T2D research contexts are first-class;
neither their eligibility nor their model binding contains an implicit T2D default.

Two independent gates must pass:

1. **Population construction:** actual linked measurements, reproducible eligibility,
   joint record preservation, missingness, source permissions and protected storage.
2. **Executable context:** a reviewed model/parameter binding with explicit observed,
   reference-initialized, derived and unavailable inputs. A population record does
   not supply its person's unmeasured kinetic parameters or validate drug response.

R05/R15/R17/R18/R19 remain open until source construction, supported execution,
browser/CLI lifecycle and independent acceptance are connected. Insulin and five
botanical programs retain their own scientific gates; this plan does not replace
them with a generic metabolic experiment.

## Existing code and concrete gaps

| Current seam | Reuse and required correction |
|---|---|
| `aegle/population.py::normalize_reference_source`, `generate_members`, `population_capabilities` | Reuse server-owned source identity and capability routing. Existing DPP/NHANES/PXR generation is aggregate-anchored research priors, not joint participant data. Age, weight, glucose, insulin, Si, gamma and genotypes are independently drawn. Preserve old generator version for historical reproducibility; new source-linked cohorts must not call it. |
| `aegle/subjects.py::create_twin/create_cohort` | Reuse AES-GCM payload storage, opaque indexes, idempotency, immutable cohort records, pagination and activation version checks. Current reference creation only accepts the old generator. Generic SYNTHETIC cohorts contain fingerprints but no materialized biological members. Add a versioned construction record and immutable model bindings without migrating or rewriting old cohorts. |
| `aegle/clinical_parameters.py::initialize_profile` | Current `"diabetes" in condition_text` selects T2D even for type 1 or diabetes insipidus. Replace new-construction dispatch with explicit model-template IDs and capability validation. Do not reinterpret text as physiology. Existing measurement mapping requires precise clinical timestamps and labels values `MEASURED_CLINICAL`; survey-cycle reference measurements need a separate mapping and must not fabricate capture dates. |
| `engines/metabolic/glucose_insulin.py::MetabolicProfile` | Existing healthy and T2D reduced glucose–insulin equations accept weight, Gb, Ib, SG, p2, Si, gamma, Gt, n, ka, bioavailability and distribution volume. Only a small subset is measured by NHANES. Retain original equations; reviewed source-to-parameter binding is a separate artifact. |
| `engines/hepatic_pk.py::pk_profile/renal_factor`; `engines/pharmacology.py::metformin` | Age-derived clearance and default zero reduced-function alleles are reference assumptions, not measured renal function or genotype. The metformin effect mapping is not an executable AMPK network. Do not admit a new source-linked cohort into this pathway by supplying missing alleles or calling age an eGFR measurement. A separate explicit reference-assumption mode may be reviewed; missing required mechanistic inputs otherwise block execution. |
| `cendos/protocols.py::_require_reference_cohort/_profile` | Existing metformin accepts only DPP/older-diabetes strata; PXR accepts its own research prior. Replace new-protocol eligibility with model/context/parameter requirements, not a blanket addition to these sets. Legacy frozen protocols keep their original semantics and hashes. |
| `sdk.py::cohort`; `life_system/population.py::LifeSystem.generate`; shell `cohort <n>` | A second legacy path samples age, sex, ancestry, condition labels and independent variant frequencies outside the governed registry. Keep explicitly labeled compatibility behavior for historical callers, never treat it as source-linked. New named SDK/shell commands must go through the same registry and capability contracts as the UI. |
| `console/lib/population_forms.js`, `subjects.js`, `twins.html`, `cohorts.html`, `cendos.html` | Reuse generic capabilities, compact cohort/member controls, persistent selection and existing history. Current accurate “healthy generator unavailable” remains until the new source and construction path are operational. UI and API eligibility must agree. |

Prior art: [August 31 admission plan](2026-08-31-evidence-grounded-twins-and-cendos-experiments-plan.md)
already distinguishes real-person data from reference priors and correctly states
OpenMed is an intake processor, not a patient dataset. The new path improves the
joint evidence, not the evidence label of old records. gbrain/context7/sequential
thinking and CE commands were searched for but unavailable in this session;
local prior plans, source inspection and primary-source browsing are the fallback.

## Primary source review and acquisition decision

All sources below were inspected through the browse skill on 2026-09-08. Only
public documentation was read. Eligible joint sample size and empirical
correlations are **not yet known** because participant files were not downloaded.

The [official cycle catalog](https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?Cycle=2021-2023)
provides separate linked data files. Existing `population.py` links under
`/Nchs/Nhanes/2021-2022/GLU_L.htm` currently return a CDC not-found document with
HTTP 200. Acquisition must validate content/schema, not only HTTP status. Use
the catalog's current `/Nchs/Data/Nhanes/Public/2021/DataFiles/` URLs; pin exact
download/codebook bytes and hashes only after approval, never invent digests.

| Source | Actual useful evidence and boundary |
|---|---|
| [DEMO_L](https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/DEMO_L.htm) | `SEQN`, release code, age, reported sex, survey design, exam period and limited pregnancy status. Age 80 means 80+, not exactly 80. Public pregnancy status is released only for women 20–44; missing outside that band is not proof of nonpregnancy. Retain censoring/time precision. |
| [GLU_L](https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GLU_L.htm) | `LBXGLU` mg/dL, `WTSAF2YR`, `SEQN`. Valid fasting-weight records represent 8 to less than 24 hours fasting; zero-weight rows can still contain glucose. Design-based estimates require fasting subsample weights, strata and PSU, plus assessment of item nonresponse. |
| [INS_L](https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/INS_L.htm) | Same-participant `LBXIN` µU/mL, `LBDINLC` censoring and fasting weight. Positive weight does not guarantee an insulin result. Preserve below-detection status; the source fill value is not an exact measured insulin concentration. |
| [DIQ_L](https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/DIQ_L.htm) | Reported diagnosed diabetes/prediabetes, insulin and diabetes-pill questions with explicit skips. Skipped insulin questions for nondiabetic respondents are not independent negative answers. Diagnosis age and no insulin use do not prove type 2 diabetes. |
| [RXQ_RX_L](https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/RXQ_RX_L.htm) | `RXQ033` reports prescription use in the previous month and `RXQ050` counts it. This cycle did **not** collect names, durations or indications. It cannot support individualized drug–drug interactions or a complete medication list. |
| [Laboratory catalog](https://wwwn.cdc.gov/nchs/nhanes/search/datapage.aspx?Component=Laboratory&Cycle=2021-2023) and [examination catalog](https://wwwn.cdc.gov/nchs/nhanes/search/datapage.aspx?Component=Examination&Cycle=2021-2023) | Verified published files include GHB_L, BIOPRO_L, ALB_CR_L, BMX_L and BPXO_L. Before their fields enter eligibility or parameter mapping, read each exact codebook/method and lock variables, units, censoring and release date. Their listing alone is not a completed importer. |

The [NCHS data-use agreement](https://www.cdc.gov/nchs/policy/data-user-agreement.html)
limits use to statistical reporting/analysis, prohibits identifying people and
prohibits linking to individually identifiable records. Scope this source to
statistical computational research. Do not onboard, contact, infer the identity
of, attach a physical LIFE Patch to, or merge EHRs with a source participant.
Commercial-product availability is not blanket permission for every use; source
policy review and recorded acceptance precede activation of this adapter.

Use one cycle initially. Do not casually pool pre-pandemic and later cycles,
cross-link people between cycles, or infer longitudinal change from cross-sectional
records. Detailed-medication use cases need a separately reviewed older-cycle or
authorized clinical source; an absent name is never filled from a likely drug.
All of Us/UK Biobank remain controlled-access programs, not substitutes to export
without approval. OpenMed/HPA/GTEx do not fill missing individual health records.

## Cohort definitions: operational and explicit

Freeze definitions as data plus a reviewed predicate, not arbitrary executable
user code. First importer stages:

1. Validate one-to-one joins on `(source_release, SEQN)` for core files; duplicates,
   cross-cycle keys or conflicts fail admission. If a later source has repeated
   medication/sample rows, preserve its proper cardinality instead of multiplying
   people during a join. Match fasting weights across GLU/INS.
2. Create normalized **reference measurements**, with original variable/value/unit,
   missing/censored/skipped state, assay/method, temporal precision, file hash and
   source-row fingerprint. Exact collection timestamps are unavailable in these
   public files; retain cycle/exam period, never today's timestamp as acquisition.
3. Produce exclusion counts and reason codes, including required missingness. No
   mean imputation, zeros for missing tests, Gaussian tails or sampled genotypes.
   Clinical plausibility rejects impossible parser/unit results; do not clip an
   extreme but valid source value into a healthier or more convenient value.

Proposed initial definitions for independent scientific review:

- `nhanes-2021-2023-screened-normal-glycemia-v1`: adults 20–79 with complete required
  joint measurements, valid fasting eligibility, no reported diagnosed diabetes
  or prediabetes, no reported prescription use, and fasting glucose <100 mg/dL
  plus HbA1c <5.7%. These two cutoffs are the normal-glycemia ranges in
  [NIDDK's diagnostic reference](https://www.niddk.nih.gov/health-information/diabetes/overview/tests-diagnosis),
  used here only as a research inclusion predicate. A single survey examination
  does not establish lifelong health. Sex/pregnancy applicability must remain
  explicit: source-unknown pregnancy is not silently “negative.” Initial
  nonpregnant-model experiments exclude unknown pregnancy where that status is
  required, rather than infer it from a demographic category. This may reduce
  eligible female age coverage and must be visible.
- `nhanes-2021-2023-adult-measured-reference-v1`: broader adults with the same joint
  source integrity; retain actual condition/medication answers and uncertainty.
  This is for descriptive/coverage work and protocol-specific selection, not an
  assertion that every record can run every model. Current untyped diabetes
  records stay untyped; no T2D inference from age or treatment.
- Additional supported-context definitions are frozen filters over admitted
  source facts, or cohorts of already admitted consented people. Neurodegeneration,
  specific genotype, tissue expression and botanical-response contexts remain
  unavailable until the relevant source and executable binding exist. Labels
  and arbitrary indication text do not supply them.

BMI/body size, blood pressure, renal/liver measurements and recorded comorbidities
remain individual attributes, not reasons to silently change a member's disease
state. A later broader “screened healthy” definition must name every additional
measurement/exclusion and its source; this first definition is not whole-body
health clearance. Do not restrict body size merely to make outcomes look normal.

## Preserve joint variation without inventing people

Initial sampling is deterministic selection **without replacement** from eligible
source rows, retaining each entire measured tuple. Store source manifest hash,
predicate version, seed, deterministic ordering algorithm and selected fingerprints.
No stochastic perturbation is applied to age, weight, glucose, insulin or genes.
For `n > eligible_count`, return `INSUFFICIENT_ELIGIBLE_REFERENCE_ROWS`, not repeated
people with new identities. A later empirical bootstrap is a separately reviewed
statistical mode with repeated-source groups and effective sample size visible;
it does not create additional independently measured participants.

Default row selection supports reproducible **source-sample experiments**, not
US prevalence claims. Retain original survey weights/design alongside records.
Population-estimate exports need the correct design-based method and an explicit
missingness/domain analysis. Do not select with survey weights and then reapply
those weights as if the selection design were unchanged. Do not claim random
source-row selection is a national clinical-trial cohort.

Stable member IDs are opaque local research IDs. Keep the private row mapping
encrypted; public projections use keyed fingerprints instead of enumerable
`SEQN` hashes. No raw participant records in git, operational logs or third-party
prompts. Synthetic technical fixtures remain the automated-test/browser-demo
default; approved statistical demonstrations of public records are explicitly
separated and contain no identifying enrichment.

## Parameter binding and experiment eligibility

Introduce an immutable `model_binding` rather than relabel reference measurements
as engine truth. It contains model/source versions, applicability, parameter
values/units, derivation or reference-bundle hash, missing requirements, observation
mapping and evidence class for every parameter. A source glucose or insulin value
may be an initial-state constraint; treating it as a basal equilibrium set point
requires a reviewed mapping and remains an initialization assumption.

| Data or parameter | Initial treatment |
|---|---|
| Age, reported sex, weight, linked fasting glucose/insulin | Preserve measured/source-reported tuple and uncertainty; map only approved engine fields. Age 80+ and unknown pregnancy remain explicit rather than converted into convenient exact inputs. |
| HbA1c, BP, renal/liver tests, medications, lifestyle | Preserve source evidence and missingness. Display and filter when reviewed; do not silently convert to unsupported organ state or kinetics. Measurement at one time is not a dynamic trajectory. |
| SG, p2, Si, gamma, Gt, n, absorption/distribution parameters | Not identified by one fasting glucose/insulin pair. A reviewed named healthy reference bundle can support **reference-initialized mechanistic exploration**, with uncertainty/applicability shown. It cannot be called each participant's measured or fitted physiology. If a protocol requires individual identification, it needs admissible dynamic data and a separately reviewed calibration/holdout procedure. No direct HOMA-to-Bergman-Si substitution. |
| SLC22A1/CYP variants, NR1I2 expression, organ flows/volumes, BBB transport | Unknown unless sourced for the applicable model. Do not sample alleles from population frequency, assume allele count zero means measured wild type, infer ancestry/genotype from race, or manufacture patient-specific receptor factors. |

For the existing reduced metabolic engine, binding validation must check finite
values, units, joint initial-state consistency, accepted model domain and a
control trajectory before admitting an intervention. Numerical stability is a
software check, not clinical validation. Freeze actual reference assumptions in
results and expose which source attributes were **not used** by the model.

R18 tests must establish that a changed supported input reaches the solver and
that unchanged inputs are not secretly randomized. They must **not require**
every pair of people to show a different response or force a favorable effect.
Equal, negligible, adverse and unknown outcomes remain valid possibilities.

### Insulin and five botanical dependency matrix

| Program | Reusable cohort evidence | Still required before individualized execution |
|---|---|---|
| OSP injectable insulin | Screening attributes and linked baseline observations can define a relevant reference study population. | Follow [OSP source subplan](2026-09-08-osp-insulin-reference-subplan.md). Native feasibility currently reproduces one source case, not arbitrary person parameterization. Model tissue geometry/weight, initial equilibrium, insulin sensitivity, clearance and formulation mapping need reviewed identification/binding; NHANES fasting pairs do not provide all of them. |
| Erinacine A / Lion's Mane | Descriptive age/comorbidity context only where actually present. | Material-specific exposure, BBB, neural/glial state and neurotrophic mechanism with applicable donor/person data. No dementia assignment from age. |
| Sterubin / Yerba Santa | Same reference registry and metadata, not individual neuronal Nrf2 parameters. | Human neuron/glia context, exposure and kinetic binding; a HepG2 reference Nrf2 model cannot automatically become a participant's brain. |
| Carnosic acid / Rosemary | Source blood/clinical context may support study selection. | Assay-specific eicosanoid response, drug exposure, target abundance and CNS coupling; no whole-blood donor identity fabricated from NHANES. |
| Arctigenin / Burdock | Metabolic/body-size context and source observations where useful. | Mitochondrial initial state, compound-specific inhibition, tissue exposure and gut conversion; a reference mitochondrial model is not a personal tissue measurement. |
| Cyanidin-3-glucoside / Bilberry | A screened reference adult population can define a future study population. | Unambiguous dose/formulation, joint PK random-effect covariance or linked subject-level PK data, parent/metabolite kinetics and vascular/retinal coupling. Do not sample ambiguous marginal random effects to claim individualized exposure. |

The [five-program packet](2026-09-08-five-program-mechanism-measurement-plan.md)
retains the exact source and counterevidence for these limits. Nonhuman assays
(including lobeline vesicles) remain separate assay contexts without human cohort
selection. Human-GEM steady-state reference capacity likewise does not acquire
person-level whole-body kinetics from this importer.

## Proposed contracts and implementation sequence

Additive, reviewed contracts; final field names must be agreed before code:

1. `population_sources.py` + source manifest/data dictionary under package data:
   fixed allowlisted source URLs, expected file type/schema, release, max sizes,
   hashes, source-use restrictions and parser version. Explicit install/status
   workflow; no public-data network fetch on cohort submit. Owner-only cache,
   locking and atomic publish; all environment paths join review-stack isolation.
2. `population_records.py` for same-release normalization, join, missingness and
   frozen eligibility. Store normalized reference measurements separately from
   clinical/patch observations. No precise clinical timestamps or device receipts
   invented to satisfy existing normalizers. Parse XPT as data, no source scripts.
3. Extend `population.py` with a new source ID and `generation_method`:
   `empirical-joint-record-selection-v1`. Keep `REFERENCE_GROUNDED_SYNTHETIC` as the
   existing research-model class for compatibility, with explicit `reference_kind`
   `PUBLIC_PARTICIPANT_MEASUREMENTS`. This is neither REAL_HUMAN enrollment nor a
   live observation source. Update capability schema additively to return per-source
   availability, definitions, eligible counts, model-binding readiness and reasons.
4. Extend `subjects.py` construction and immutable `model_binding`/member evidence.
   Cohort request retains existing name/size/seed/source/stratum fields; new source
   ID selects the reviewed path. A new optional `model_binding_id` is server-owned,
   not a payload of arbitrary priors. Idempotency includes manifest, predicate and
   binding hashes. Member promotion to an inspectable twin uses the exact frozen
   record, not regeneration or a fabricated enrolled-person ID. Physical-device
   association and real-human consent paths remain prohibited for public records.
5. `clinical_parameters.py`/new `model_bindings.py`: explicit template, no substring
   inference. New constructions reject unsupported type1/other physiology, while
   still storing descriptive reference profiles. Source observations, assumed
   initialization and modeled quantities remain separate evidence classes. Read
   old records without rewriting them; old reruns retain an explicit legacy mode.
6. Protocol eligibility resolves a frozen binding and member snapshot, not disease
   text. Add a non-mutating preparation/compatibility response listing consumed,
   reference-initialized and missing parameters. Execution rechecks exact source
   hashes and limits. Real-human cohort IDs also require a frozen versioned profile
   snapshot at experiment admission; mutable active twin data is not a run input.
7. SDK/CLI/UI all use these same contracts. Add named source status/install and
   cohort preview/create/inspect commands; no new shorthand calls legacy
   `LifeSystem.generate`. Existing `cohort <n>` remains visibly legacy compatibility,
   not silently upgraded and not accepted as source-linked experiment input.

UI flow: choose **reference data vs admitted real people** → choose source and
screened context → inspect exact eligibility/available count/missing requirements
→ choose size/seed and reviewed model binding → preview → explicit freeze/create.
Default context is healthy-reference, never T2D. Until source admission succeeds,
the choice explains its missing dependency and cannot create an empty or fake
cohort. Source and parameter evidence remain in the existing member drawer.
Protocol cards show eligibility independently of whether a cohort exists. Keep
compact selection, pagination, History recall/rerun and A+B layout unchanged.

## Red-first test and review matrix

| Test family | Required failure before implementation; acceptance after correction |
|---|---|
| Source integrity | HTTP200 HTML masquerading as XPT, wrong release/hash, missing/renamed column, oversize, truncated file, unsafe path and concurrent install all fail without publishing readiness. |
| Joint preservation | A tiny authored technical fixture with intentionally correlated columns proves each resulting tuple exists in one source row; independent shuffling/drawing cannot pass. Conflicting duplicate IDs and many-to-many joins fail. |
| Missingness/eligibility | Insulin absent despite positive fasting weight; zero-weight glucose; below-LOD fill; questionnaire skip/refusal/unknown; pregnancy unknown; top-coded age; wrong units and conflicting answers get distinct reasons. Boundary cutoffs are frozen and testable. |
| Reproducibility | Same source/predicate/seed/size gives exact same frozen tuple set; hash/version change changes construction identity. No replacement; size above eligible count errors. Same idempotency key with changed construction errors; old source snapshots remain untouched. |
| Model binding | `type1`, `diabetes insipidus`, free text and unsupported templates cannot select T2D. Missing Si/genotype/clearance does not get measured status or zero allele defaults. Unit/assay/time precision, joint state and consumed-parameter lineage are verified. |
| Physiology coupling | No new equations in cohort code; frozen input reaches intended engine. Baseline and treated share one member initialization. No forced response diversity, benefit, invented trajectory or source-data self-calibration. Source reproducibility is separate from experimental qualification. |
| Lifecycle/API | Auth/no-store, PHI-safe failures, encrypted payloads, source policy restriction, exact snapshot promotion, switch/context invalidation, pagination, immutable histories, restart and old API compatibility. Public records cannot bind physical devices or be relabeled REAL_HUMAN. |
| SDK/terminal | Source availability, preview/create/inspect and errors match API/UI. Legacy `cohort <n>` cannot bypass governed protocol admission; ambiguous shorthand is not used in guides or requested scientific recordings. |
| Browser | Fresh empty install → explicit source readiness → screened healthy cohort → member provenance → correct twin/run → Cendos eligibility. Missing source, insufficient rows, non-T2D context, unsupported mechanism, retry, double-submit and large lists visibly work. Real rendered Biology and selected context remain intact. |
| Statistics/privacy | Preserve original weights/design and exclusion counts, no incorrect double weighting or cohort-as-national-estimate claim. Logs/indexes/screenshots omit direct source rows and secrets; no cross-linking with identifying data. |

New tests should be split into `test_population_records.py`,
`test_population_bindings.py`, `test_reference_cohort_lifecycle.py` and focused
browser/CLI cases, while retaining `test_subject_lifecycle.py`,
`test_reference_capabilities.py`, `test_population_capabilities_ui.py`,
`test_cendos_compact_members.py`, protocol integrity and review-isolation coverage.
Use authored synthetic fixtures for red/green parsing and joint constraints;
the official source acquisition/eligibility audit is an explicit network test
after approval, not an assertion derived from fixture counts.

## Review gates, active dependencies and lesson

Before implementation: independently approve the proposed source-use scope,
screening definition, age/pregnancy coverage, exact model-binding policy and
additive API contract. Before first source activation: verify all used codebooks,
source artifact hashes, actual eligible count and retained joint distribution;
record exclusions without exporting participant rows. Before an experiment:
pass the specific mechanism's parameter, numerical and applicability gate.
Before acceptance: independent source/code review, connected browser/CLI proof,
updated guides and R05/R15/R17/R18/R19 evidence linked to the master register.

No dataset access, sample count, source licence clearance, clinical qualification
or individualized botanical/insulin capability is claimed by this document.
Missing person kinetic data, joint PK effects, modern insulin formulation mapping,
neural/BBB and other organ mechanisms remain active dependencies—not requirements
removed from scope. A source-linked healthy cohort is a necessary concrete build,
not an acceptable substitute for those missing mechanisms.

Compounded planning lesson: a newer dataset can lose medication detail, a valid
HTTP response can contain a missing-page document, and a positive fasting weight
can coexist with an absent insulin measurement. Source-linked physiology must
preserve these facts before a model interprets the data. More rows and more
realistic-looking random numbers do not repair missing biological information.

## Descriptive lifecycle amendment (2026-09-08, pre-code review)

The source normalization core has now passed independent review. The next
additive registry/API/UI/terminal packet is specified in the
[descriptive reference-cohort lifecycle amendment](2026-09-08-descriptive-reference-cohort-lifecycle-amendment.md),
including private cache resolution, frozen encrypted member storage, preview
coherence, idempotent creation, bounded inspection, and explicit execution gates.
This amendment requires its own independent written review before implementation.
It does not activate the internal nine-parameter assumption bundle or remove the
required individualized executable contexts from the open requirements.
