# OSP retained startup facts: prospective once-only technical successor

2026-09-09. Source review and proposal only. No successor control root, launcher,
authorization, marker or output directory has been created. No supervisor or
launcher was imported/executed, and no OS, R, CLR, vmmap, browser or model run
occurred for this proposal. A separate root preparation decision and then an
exact, hash-bound execution decision remain necessary.

## Proposed decision and prerequisites

After root accepts the [evidence-retention amendment](2026-09-09-osp-rejected-process-evidence-plan.md),
prepare one fresh private instance of the already reviewed once-only launcher.
Change only its fixed `HERE` binding and supervisor pin, retaining its source
shape and constraints. Freeze the new resolved path, launcher hash and exact
`env -i` / pinned Python `-I -B` command for independent review before creating
authorization or making a call. The consumed CA533x root is never reused.

Root reports independent source/preservation check `554f25`: the classifier is
exact and all 19 original module assignments remain. Maker verification is
553 PASS, two native watchdog cases excluded, zero unexpected I/O. Root reports
independent repeat `61995d`: 553 PASS in 1.65 s, zero unexpected I/O, with its
receipt appended to the amendment. This proposal supplies no self-approval for
the maker's supervisor correction and grants no execution authority.

If separately authorized afterward, invoke the unchanged `run_packet()` exactly
once. Its first failure must still stop the packet. The purpose is to retain
observed startup rejection facts if that failure recurs; that is not a new
success criterion. UNEXPECTED_DESCENDANT or a sampling failure still means
FAILED and nonzero launcher exit, even when the diagnostic sidecar is complete.
Do not infer the former descendant's identity, alter the startup window,
allowlist an observed candidate, or add preliminary R/CLR/helper probes.

This is not a startup-only runner. If the startup refusal does not recur, the
unchanged schedule may reach all S01–S17: at most 17 R workers and 16 prescribed
Run calls, with vector `[2,1,0,0,1,1,2,2,1,1,1,1,1,1,1,0,0]`. Each reached
worker may use its existing bounded startup helper topology and two inspectors.
The future actual decision must expressly cover that existing complete technical
schedule; do not quietly replace it with an S01-only protocol or a new probe.
No insulin/GIM experiment, compound admission, live-twin calibration or scientific
program gate follows. Model admission remains false, native source attestation
UNVERIFIED, and historical author runtime UNKNOWN.

## Input bindings rechecked by read-only hashes

Fixed checkout: `/Users/emman/Livemore/.worktrees/full-scope-recovery`.
Read-only hash completion `46a3ad` verified:

| Input | SHA256 |
|---|---|
| `tools/osp_semantic_supervisor.py` | `af735907d6eeb1ab4d158cc9a365d61e4af6f71d8c2e3b70afe4631b5b398dd6` |
| `tools/osp_semantic_probes.R` | `3ba6559b723cfe85c66bca47aac0abfbaac8e395c430bd7360105dc6f67625f7` |
| `tools/osp_semantic_probes.py` | `12585d9bed93cd2a5625ec1cd625287406a22d475b49c34ba931109630ea82d7` |
| `docs/solutions/2026-09-08-osp-retained-runtime-static-inventory-v2.json` | `d09b1f5dcb15d6d612b8b5301c2bb5f6a4c7f174b8e08eeff1df24b087c94be2` |
| `/private/tmp/livemore-osp-os-preflight-v2.Yc5Y4i/preflight-result.json` | `b579c9a1563b4309fa2127955faa2da16ada105051f1773865834f0e44f04b43` |
| `/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11` | `e3938f2a272dafdc33f3dd12b093dfc85354629476cb97a7d7d4a7201b8482dd` |

Protocol digest remains
`5eb866376a2b121109066dbb11edad2eba701b3b85c8fe474ae1aa02b8e505e7`.
The prospective launcher hash is deliberately absent until its fresh path and
source exist and are reviewed. The original launcher is still
`bb03511e1f4a89bb878aa807083869ebd75f692c7a1cc266b5c8a45397eb9de5`.
Its old supervisor pin is incompatible with the updated source and correctly
refuses it before import/marker creation. Do not edit that consumed launcher.

The historical O1–O7 OS receipt remains evidence for its original source/run,
not an assertion that the updated supervisor has undergone a fresh OS preflight.
The sampler interfaces, process classifier and ownership cleanup functions are
unchanged except fixed sampler-stage annotation; the execution amendment adds
retention/reservation and preserves resource checks after rejection. Root must
explicitly accept the limited historical OS evidence plus independent offline
review for this prospective technical decision. No new OS preflight is implied
or authorized here.

## Launcher and sidecar compatibility findings

Read the complete original 231-line launcher (`d28ce5`) and its schema/readback
tests and reviewed decision. No sidecar-induced launcher schema change is needed:

- Authorization uses exact canonical `OSP_NATIVE_ONCE_AUTH_V1` equality. Keep
  its seven identity fields, exact cases/Run vector/protocol/limits, boolean
  authorized true and model_admission false. Update the supervisor hash and
  recomputed fresh launcher hash only; adding a sidecar-policy field would
  correctly fail AUTHORIZATION. The supervisor hash already binds that policy.
- Packet admission checks the unchanged top-level schema, exact returned/on-disk
  equality, identity, limits, claims and 17 ordered successful cases. It imposes
  no exact per-case key set, so additive `process_failures` references fit. A
  failed case still fails PACKET_REJECTED/PACKET_CASES; no diagnostic waiver.
- The launcher reads `result.json`; it does not traverse or verify sidecars.
  There is no filename whitelist to amend. The producer's case/tree traversal
  already counts arbitrary regular files, so the new fixed sidecars and pending
  files are counted. The shared reservation includes six final plus six possible
  pending names inside 4 MiB/256 entries; no writer or tree limit is enlarged.
- A normally completed sidecar is regular, 0600, and single-link after the atomic
  pending unlink. A failed unlink may preserve both hardlink names. That remains
  a recorded write failure, not a valid completed reference. The launcher's
  single-link `read_file` helper must not be relaxed to admit it. An independent
  bounded forensic read may record those actual failed artifacts and metadata
  separately, without deleting a name or relabelling the write COMPLETE.
- Compact references fit the existing structures without embedding candidate
  rows. Inherited 256 KiB inspector/1 MiB case/16 MiB packet write failures remain
  possible; sidecars preserve available facts independently. If `run_packet()`
  throws without returning a root, the launcher still records no returned root.
  Do not invent one or claim no tree exists; any bounded follow-up inventory is
  confined to the exact fresh control root's TMPDIR and reported separately.

Before a future actual decision, the fresh launcher needs an inert repeat of its
existing 45 cases plus additive authored checks: new supervisor/self pins;
additive per-execution references survive exact readback; a failed packet with
sidecars stays FAILED; a missing/failed-write sidecar cannot become success; and
no fixed-six-file assumption enters the independent evidence review. Do not
modify the consumed launcher's tests or execute a native fixture for this check.

## Unchanged execution and review boundary

Reuse 0700 private control/home/tmp/cache paths and 0600 exclusive, no-follow
authorization/once/completion writes. The once marker is permanent on every
outcome. Source pins are checked before import and again on all post-marker
outcomes. Both source gates initially remain false; only the separately approved
private process may set them in memory for one call and restore them afterward.

Preserve packet/completion 600 s, worker 30 s including cleanup, CPU soft 20/hard
21 s, sampled group RSS 3 GiB, sampling target 0.1 s/max gap 0.5 s, inspector
3 s including 0.5 s cleanup, 3 s worker cleanup reserve, the 6 s inspector-start
check and 35 s minimum packet time before another worker. Retain all original
stream, observation, result, tree and entry limits. No uncertain group may be
signalled and no unresolved slot may be reset. No retry follows failure.

Post-run review, if a later run is authorized, must retain the terminal exit and
completion separately from the raw packet. Inspect only reached cases and their
work/cleanup sidecars, including PRE_XML/FINAL inspectors where present. Check
reference bytes/hash, bounded JSON, phase/code/stage, sample and retention states,
enumerated/sampled/retained/omitted counts and unchanged accepted observations.
Missing records, partial capture, overflow or write failure must remain explicit.
Candidates are observations, never authorization or validated biological data.
Verify recorded owned identities/cleanup using the separately authorized bounded
read-only checks; an unrecorded child cannot be reconstructed from an assumption.

CA533x preservation was rehashed in `46a3ad`: authorization
`654fdd6aa1f5a387e1a96a1ef801284cbb2612225ece28629c0d19bc8f255c66`,
once marker `85b543bbd9c362d557a4c93eb0a04cc337ffef18476b1c8a4b771b62c6a518dc`,
completion `676bb4d83299f22561d5a57d7c253586e98c88e60780f0498bb02c37616fc78b`,
and packet `9ddea114d4a1732c8548812848e86da685dfa61714e4ac9b5b52f404fc55c808`.
Its S01 UNEXPECTED_DESCENDANT remains FAILED, S02–S17 remain NOT_RUN, and the
rejected descendant remains unidentified. No successor is launched by this text.

## Root preparation decision — inert only

Root read the complete proposal and original 231-line launcher (`4d4869`), and
accepts a fresh private preparation using only the new HERE path and independently
cleared supervisor hash. Preserve the original launcher, consumed marker,
authorization, completion and packet. The current browser attempt has finished
and its owned processes are absent; no source hold conflicts with this preparation.

Prepare the copied launcher and existing tests plus the specified additive
authored sidecar/readback/refusal checks. Keep its exact input/gate/schedule/
ownership/resource limits, and use the same inert network/native/process refusal
wrapper. Do not expand the launcher into a second sidecar validation framework:
sidecar inspection is a separately bounded post-run read, not a successful
packet claim inferred from a filename. Record exactly which boundary the new
tests exercise and preserve earlier failure evidence.

No authorization file, once marker, actual HOME/TMPDIR/cache, native invocation
or OS sampling is authorized by this preparation. Freeze the final launcher,
test source, exact path and complete inert result for root's independent grade.
Only then may root separately decide whether to authorize the original complete
17-case technical schedule. The historical OS preflight remains historical;
it must not be described as a new preflight of the amended supervisor.

## Maker preparation receipt — frozen, still no actual authority

Prepared only the approved inert successor in private 0700 root
`/private/tmp/livemore-osp-native-once-evidence.qUfcQ6`. Read-only inventory
`f0809c` confirms seven regular single-link 0600 files, no directories below
the control root, and no actual authorization, once, completion, home, tmp or
cache. No native/OS/browser/network call or real supervisor import occurred.
The private tests import the inert launcher and use authored mounted inputs,
fake clocks and a fake supervisor; their temporary control artifacts are confined
to fresh `prepare_review_environment` fixtures outside this actual control root.

The complete source diff `158940` contains exactly two substitutions: the new
fixed HERE path and the already independently cleared supervisor hash. All
231 source lines, six input bindings apart from that one hash, schema, gates,
17 cases/16 Run schedule, ownership rules and limits otherwise remain unchanged.
The complete copied 319-line existing test file differs only in its SOURCE path.
No consumed source/test/receipt or product implementation was edited.

| Frozen private file | SHA256 |
|---|---|
| `run_packet_once.py` | `4e3663b182f901a9d82df03ba39d8aa30f7d140205bc36167069e0a7a2b6e2df` |
| `test_packet_once.py` | `3f17121f6ea1add190594b8b41af150cc9b8ca0f4a4b9807b89af72932425d81` |
| `test_packet_once_evidence.py` | `8dccbf05286c563579e7080ffd76cbd909204da0c5fb7f2f69b8b8d756ac2f2d` |
| `repeat-offline.sh` | `f7450d02183efcd5c603d29c81a7b397e9683066463e6f76e96a2342f7f161c8` |
| `red.txt` | `56400568260981fba6a20441aa027bd780fe6c6e0bfb86204ccb28f6289dbfae` |
| `green.txt` | `472cdab0a8d36008ca6b83de7472d1a55802d91a2ba4a8c51b22e6d98213d6db` |
| `reviewed-delta.diff` | `59675784bf55a2e56139c498b425883a136e69647edaa6eaf0583bbd7fdb0679` |

Hashes were recorded by `6513ba`. The RED and GREEN text files retain the complete
respective tool output, not invented or abbreviated console logs.

### Exact RED/GREEN and limitations

Before the two substitutions, the copied original launcher produced **4 failed,
68 passed**, zero unexpected I/O (`2e2c74`, 0.50 s). An unchanged RED repeat
`a7a726` produced the same 4/68 in 0.56 s and is retained in `red.txt`.
The four failures establish fresh HERE, new supervisor pin, exact two-substitution
source identity and refusal of the old launcher identity. The latter cannot
refuse the old hash while the source copy is still byte-identical to the old
launcher. All 45 inherited tests passed during RED.

After only those two substitutions, the exact same tests produced **72 passed
in 0.64 s**, zero unexpected I/O (`466798`), retained in `green.txt`. No assertion
or test source changed between RED and GREEN. The 27 additive cases cover:

- fixed successor/source identity and byte-preservation of the original tests;
- stale supervisor/launcher authorization refusal, exact authorization schema,
  and self-hash binding using six authored synthetic inputs;
- empty worker and nested inspector references surviving exact successful
  returned/on-disk readback without changing the case/Run schedule;
- worker/PRE_XML/FINAL failed receipts with complete, partial, absent or failed
  atomic sidecar writes, all retaining FAILED, the original case failure and
  NOT_RUN tail; diagnostic files are not rewritten or removed;
- mutated returned reference hashes rejected by exact packet readback, including
  failed packets; existing bounded-reader refusal of absent, hardlinked or
  oversized sidecar-shaped artifacts.

The missing/failed-write cases explicitly begin with a FAILED authored producer
packet. They prove diagnostics cannot rescue that failure, not that the unchanged
launcher independently validates sidecars inside a fabricated successful packet.
It still trusts the hash-bound producer and reads only result.json. The direct
reader cases exercise its existing file primitive, not a new traversal policy.
Authored candidate identities are invented technical fixtures and provide no
identity evidence about CA533x. No actual OS or runtime behavior is inferred.

Exact independent offline repeat, from the fixed worktree:

```bash
/bin/sh /private/tmp/livemore-osp-native-once-evidence.qUfcQ6/repeat-offline.sh
```

The original 19-line refusal wrapper is retained with only the copied test path
and additive test selection changed. It uses the existing review-environment
helper, disabled pytest plugin autoload/cache, a 45 s alarm, and denial of network,
subprocess/fork/exec/spawn and further ctypes loads. It does not run the source's
main entrypoint or load the real supervisor. Root must independently grade/repeat
the frozen source and tests; these maker results do not approve actual execution.

### Fully resolved prospective command — NOT AUTHORIZED

Only a separate root decision after independent grade can create the exact
canonical authorization object or execute the following command. Its seven
identity hashes use the six unchanged/current input pins above and new
launcher_sha256 `4e3663b182f901a9d82df03ba39d8aa30f7d140205bc36167069e0a7a2b6e2df`.
Keep the original authorization schema/protocol/cases/Run vector/limits and
model_admission false; do not add a sidecar-policy field or reuse CA533x authority.

```bash
env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C PYTHONDONTWRITEBYTECODE=1 \
 HOME=/private/tmp/livemore-osp-native-once-evidence.qUfcQ6/home \
 TMPDIR=/private/tmp/livemore-osp-native-once-evidence.qUfcQ6/tmp \
 XDG_CACHE_HOME=/private/tmp/livemore-osp-native-once-evidence.qUfcQ6/cache \
 /Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -I -B - <<'PY'
import hashlib,os,stat
from pathlib import Path
os.umask(0o077)
path=Path('/private/tmp/livemore-osp-native-once-evidence.qUfcQ6/run_packet_once.py')
fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
with os.fdopen(fd,'rb') as stream:
 info=os.fstat(stream.fileno())
 if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:raise RuntimeError('LAUNCHER_IDENTITY')
 raw=stream.read(1024*1024+1)
if len(raw)>1024*1024 or hashlib.sha256(raw).hexdigest()!='4e3663b182f901a9d82df03ba39d8aa30f7d140205bc36167069e0a7a2b6e2df':
 raise RuntimeError('LAUNCHER_CHANGED')
exec(compile(raw,str(path),'exec'),{'__name__':'__main__','__file__':str(path)})
PY
```

Post-preparation read-only hashes `3c9b8f` confirm the original CA533x launcher,
test, authorization, marker, completion and failed packet exactly match their
previous hashes; all six bound inputs and the frozen 29-case supervisor test
source also remain exact. CA533x is still FAILED/UNEXPECTED_DESCENDANT with no
recovered descendant identity. Historical OS evidence remains historical; native
source attestation UNVERIFIED, historical runtime UNKNOWN, model admission false.

Lesson retained: additive diagnostic references may fit an existing receipt
schema without extending its admission guarantee. Test and report the precise
boundary: exact readback and persistent failure are not sidecar validation or
scientific qualification.

## Independent root preparation grade

Root read the complete launcher, complete original 45-case test source, all
27 additive cases, the exact refusal wrapper, full maker receipt and source/test
diffs (`4d4869`, `a2d17e`, `218503`, `655710`, `9abf70`). No critical issue
was found within the proposed preparation. Only the fixed root and supervisor
pin changed in the launcher; the copied original tests differ only by SOURCE.
The additive test boundary is correctly limited to readback and failure
preservation, not sidecar validation of a fabricated successful producer result.

Root's independent exact wrapper invocation **`f29d3c`** passed **72 cases in
0.45 s**, zero unexpected I/O, in private review root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-r70hbdu3`.
No actual supervisor/native execution occurred. Read-only `6c0f6f` independently
verified the three frozen source/test hashes, exact two-substitution source,
original test preservation, all six regular unaliased input pins, original four
CA533x control/packet hashes, private 0700 root and absent actual artifacts.

The preparation is independently clear. This grade alone grants no execution;
the separate root actual decision must state its complete technical schedule,
historical OS-evidence limit, source hold and fixed post-run inspection boundary.
