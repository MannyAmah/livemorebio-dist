# Beard native source execution: proposed step-4 preregistration

2026-09-08. **PROPOSAL ONLY — no approval to compile or evaluate Beard.**
The approved steps 1–3 remain limited to source conversion and two analytic
technical fixtures. This document does not extend that authority. Root must
independently approve this numerical protocol and its implementation manifest
before any Beard initialization callback, rate evaluation or time advance.

This continues [the unit-preserving route](2026-09-08-beard-unit-preserving-execution-followup.md)
and [the arctigenin dependency plan](2026-09-08-arctigenin-mitochondrial-source-plan.md).
It preserves the rejected Myokit import, all failed technical attempts, the
failed insulin benchmark and the full five-program/individualized-human scope.
No compound, participant, cohort, LIFE channel, product route or running model
is admitted by this proposed reference-mechanism experiment.

## 1. Exact question and source variant

Question: **Can the unchanged pinned PMR implementation be initialized and
numerically advanced with its dimensions, identities and source equations intact,
with convergence, domain and conservation checks passing the fixed gates below?**
Not: does arctigenin work, is a person healthy, or does this reproduce a physical
human response? No arctigenin concentration, activity multiplier, oxygen sweep,
fitted parameter, treatment outcome or desired-response target is in the matrix.

| Identity | Fixed value |
| --- | --- |
| Source commit | `8ec69b34c31cd1cbb53580d1853841bb333de78e` |
| Original CellML SHA-256 | `4a4f931592df0e77a92c79447bf6d8947c7325f721a74b4d336d370abaaf3981` |
| Converted CellML 2 SHA-256 | `5b2ffa7a1e8bae8be173fc9e8e84cd88bdfc02efcfd00c28cf222b0af633a40c` |
| Generated C SHA-256 | `3af10f8a848e6077f6059186fc1b34a9895e89f9f9c47f80669001ccfbc9795a` |
| Generator | libCellML 0.7.0, exact package-file manifest already checked |
| Native candidate | ARM64, SUNDIALS 7.8.0, Apple clang 21.0.0, reviewed SDK/library manifest |
| Evidence class | `MODELED_REFERENCE_MECHANISM`; numerical acceptance reported separately |
| License | Model CC BY 3.0; generator Apache 2.0; SUNDIALS BSD 3-Clause |

[Pinned original source](https://models.physiomeproject.org/workspace/beard_2005/@@rawfile/8ec69b34c31cd1cbb53580d1853841bb333de78e/beard_2005.cellml),
[curation and attribution](https://models.physiomeproject.org/exposure/959a4da5d8a0638f4b36adf5800f4fc0/beard_2005.cellml/view).
Retain Daniel A. Beard, David Nickerson/PMR curation credit, original metadata,
license and the complete format-conversion change record.

This is explicitly the **PMR default variant**, not the corrected-paper variant.
Keep `x_AK=0`, `W_x=0.651384`, `W_i=0.072376` and source capacitance
`6.756756756756757e-6` in their exact native units. Their discrepancies versus
the correction remain unresolved. No variable-name interpretation may override
its actual dimension: in particular `molar_per_cyto` retains its source
`mitochondria^-1` factor. The three irreducible dimensions are not dimensionless.

Original source conditions remain buffer Pi_e=0.000125 M, external ATP/ADP/AMP=0,
Mg_tot=0.005 M, pH_e=7.1, K_e=0.15 M, RT=2.4734 kJ/mol,
F=0.096484 kJ/(mol·mV), NADtot=0.00297 M, Qtot=0.00135 M and Ctot=0.0027 M.
These are source defaults, not measured participant parameters. **All** remaining
constants and initial values must be read from the pinned source, not a partial
table in this document. Source permission does not provide human data consent.

## 2. Before any native source call

1. Independently accept the three corrected technical-worker findings and its
   [superseding evidence](../BEARD_UNIT_PRESERVING_TECHNICAL_VERIFICATION.md).
2. Freeze this protocol's hash before code, then write failing contract,
   analysis and failure-path tests before implementation. Reviewer approves
   the actual new wrapper/analysis/runtime/source manifest **before execution**.
3. Re-run exact conversion admission: zero analyser issues of any severity;
   47 components, 339 declarations, 28 unit definitions, 65 equations,
   226 equivalence edges, 66 literal initial values and 19 states. Preserve all
   parser conversion messages under their existing explicit allowlist.
4. Match all native/runtime/header/compiler/SDK/linkage hashes. A changed runtime
   is a new candidate requiring review, not an automatically accepted upgrade.
   Preserve the source-specific manifest; reject arbitrary source paths/contents,
   parameters, identifiers, callbacks or command strings.

The current technical C wrapper deliberately rejects more than two states. Do
not weaken that fixture-only guard. A separate, narrowly pinned source wrapper
and command under `tools/beard_*` must have its own source identity, no patient or
compound API and no product import side effect. Compilation itself requires the
separate execution approval; this proposal creates no binary.

## 3. Native initialization and observation contract

First proposed native stage `I0` is **initialization-only**, not an integrator
call. Preserve its output even if it fails. It has two explicit subgates:

- `I0a`: call generated `initialiseArrays` and computed-constant initialization;
  **do not call computeRates yet**. Compare all 19 state slots by qualified ID to
  the original source literal values, and all 47 constant slots to their source
  literals. Require exact binary64 values from those same literal strings;
  never compare shortened printed decimals. Resolve the 66 initial values
  through their actual equivalence classes. No default zero filling can stand
  in for a missing initialization. Record all 12 computed constants, their source
  expressions and units; independently recompute them from source MathML.
- `I0b`, only after `I0a` passes: evaluate native rates/observers at exactly t=0,
  retain all 19 rates and 34 algebraic slots, and check the source expression
  domains and finite results. This is a **Beard RHS evaluation** and must be
  counted even though it does not advance time. Check its arrays against the
  independent, lazy-branch MathML evaluator described below. A domain failure
  stops the candidate; do not initialize at epsilon time to hide it.

All native state/time/observer slots are fixed by the existing manifest's
qualified-ID/equivalence map, never by bare name or source XML order. All 339
aliases must map to the correct 19 state, 47 constant, 12 computed-constant,
34 algebraic or single time slot, with equivalent native dimensions and no
hidden scale factor. A mapping/type/index/unit mismatch blocks execution.

The complete 19-state table is retained in the technical report. In generated
order its initial values are H_x=6.30957344480193e-8 M, dPsi=160 mV, Pi_x=0.001 M,
NADH_x=0.0015 M, QH2=0.0008 M, Cred=0.001 M, O2=0.000026 M, ATP_mx=0,
ADP_mx=0, ATP_x=0, Mg_x=0.005 M, ADP_x=0.01 M, ATP_mi=0, ATP_i=0,
ADP_mi=0, ADP_i=0, AMP_i=0, Pi_i=0.001 M and K_x=0.14 M. All unspecified
concentration units in that sentence are M. Time is **seconds**, not minutes.

`x` means matrix, `i` intermembrane space, `e` external buffer; nucleotide `m`
means Mg-bound. Nucleotide state totals already contain bound forms: do not add
the bound state a second time when computing adenylate conservation. Source
oxygen has derivative exactly zero. This protocol cannot show blood oxygen
delivery, systemic oxygen depletion or a live person's breathing.

## 4. Proposed native matrix and exact sampling

All runs use the same unmodified initial source, constants and boundary inputs.
CVODE BDF, serial vectors, dense linear solver and default Newton iteration;
binary64 throughout. No event, stimulation, dosing, external forcing or fitting.

| Run | Native interval | RTOL | ATOL | Purpose |
| --- | --- | ---: | ---: | --- |
| B0 | 0–300 s | 1e-7 | 1e-11 | First prospective baseline |
| B1 | 0–300 s | 1e-9 | 1e-13 | Tighter independent solve |
| R1 | 0–300 s | 1e-9 | 1e-13 | Fresh-process repeat of B1 |
| K1 | 150–300 s | 1e-9 | 1e-13 | Full-state restart from frozen B1 t=150 |

ATOL is the exact scalar native solver setting proposed previously: the numeric
value is applied to each state's native unit (M or mV), **not one biological
error tolerance shared across those dimensions**. Assessment uses separate unit
floors below. Record the actual API settings; do not reinterpret ATOL as a
clinical noise level. [CVODE tolerance and restart contract](https://sundials.readthedocs.io/en/v7.8.0/cvode/Usage/index.html).

Record all 19 states, 19 evaluated rates and 34 algebraic quantities on exactly
`time_index/10` seconds, with integer indices 0…3000 for B0/B1/R1 and 1500…3000
for K1. Include every endpoint and no duplicate time or identity. Require native
returned time to match the requested binary64 time. Do not compare intersections
that silently discard missing samples. Constants/computed constants are retained
once per run with hashes and checked unchanged after each output evaluation.

CVODE normal-mode output can be interpolated from accepted internal steps; the
0.1 s output grid is **not** a claim of 0.1 s native internal stepping. Record
step counts, RHS calls, nonlinear/error-test failures, solver return codes and
internal terminal time. Fail on non-success returns; no silent fallback solver.
Set the per-output work bound to 10,000 internal steps, total generated RHS
evaluations to 1,000,000, and keep other step/order limits at their pinned
runtime defaults. These are prospective engineering bounds, not physiological
parameters. Any required change produces a new reviewed protocol version.

K1 deep-copies B1's exact t=150 output states, all constants and source/runtime
identity into an immutable checkpoint, then starts a **fresh solver**. Validate
all 19 restored states before the first callback; generated initialization must
not overwrite them. Computed constants may only be recomputed from identical
constants and must match B1. This is a **state restart**, not restoration of
CVODE's multistep internal history; it is not expected to be bitwise identical
to uninterrupted solver internals. K1's starting row must exactly equal the
checkpoint; its subsequent outputs must pass the fixed comparison gates.

I0 must pass before any advance. Independent baseline branches may still run
after a B0/B1 numerical failure to document the fixed matrix, without changing
settings. K1 is `BLOCKED_DEPENDENCY`, not passed/skipped-as-success, if B1 lacks
a complete admitted checkpoint. Never select a different restart time afterward.

## 5. Preregistered numerical, source and domain gates

For B0↔B1, R1↔B1 and K1↔B1 on their **complete expected grids**, require every
state and all 34 algebraic quantities to satisfy:

`abs(a-b) <= floor(unit, identity) + 1e-6 * max(abs(a), abs(b))`.

| Quantity | Absolute comparison floor |
| --- | ---: |
| H_x concentration | 1e-12 M |
| Other concentrations, including free/bound and redox observers | 1e-10 M |
| Potentials (dPsi, Psi_x, Psi_i) | 1e-4 mV |
| Fluxes | 1e-9 mol/(s·L mitochondrial volume) |
| Free-energy algebraic quantities | 1e-8 kJ/mol |

The first four floors preserve the original numerical proposal. The free-energy
floor is an explicit prospective addition to assess **all** algebraic outputs,
not a threshold selected from unseen Beard results. No RMSE/average can replace
the per-identity/time maximum. Rates are retained for equation and conservation
checks; they are not silently assigned concentration units.

Independent analysis must read the raw retained arrays, not the worker's own
pass flag. A bounded original-MathML evaluator, implemented/tested separately
from libCellML generated C, evaluates the exact dependency graph with lazy
piecewise branches and no integration. Challenge it first with technical
operator/branch/domain/connection cases. At I0 and every output, compare all
source-computed constants, algebraic values and rates against native slots:
relative tolerance 1e-10, with absolute floors of 1e-14 M for H, 1e-12 M for other
concentrations, 1e-8 mV, 1e-11 mol/(s·L mitochondrial volume), 1e-10 kJ/mol;
for a rate use its corresponding state floor **per second**. These tighter
checks assess source-expression execution at identical states, not solver
convergence or experimental accuracy. The only other computed-constant unit is
`l_water_per_l_mito` for W_x and W_i: its absolute expression-comparison floor
is 1e-12 in that **same tagged source unit**, not dimensionless. Computed H_e/H_i
use the H floor; K_i, k_dHPi, k_dHatp, k_dHadp, Mg_i, ADP_me, ADP_fe and Mg_e use
the other-concentration floor. These enumerate all 12 computed constants.
An unexpected/uncovered dimension blocks analysis, never falls back to
dimensionless. The 47 literal constants already require exact binary64 equality.

At each generated RHS evaluation and output:

- Require finite time, all states and every computed native quantity/rate.
  Report source ID, native unit, stage and time of failure. A trial Newton/RHS
  state is marked `solver_trial`, never presented as an accepted trajectory.
- Retain/count every negative concentration. Below the relevant negative floor
  (H −1e-12 M, other concentrations −1e-10 M) fails this candidate. Values inside
  the small-negative band remain flagged numerical uncertainty, not physically
  valid concentrations, and are never clamped. If all other gates pass but any
  such output exists, status is `NUMERICAL_PASS_WITH_UNCERTAINTY`, not an
  unqualified domain/physical pass. Trial-only flags remain separately reported.
- Active logarithm arguments must be **strictly positive**, irrespective of the
  small-negative reporting floor. Check denominators, active square-root domains
  and finite exponentials as written. A numerical domain violation is an
  unrecoverable callback failure in this first candidate, not an instruction to
  rewrite the equation or retry at a smaller invented positive concentration.
- Respect the actual source ANT piecewise guard: `ADP_fi > 1e-12 M OR
  ATP_fi > 1e-12 M`. At the source's zero intermembrane nucleotide initial state,
  the inactive branch is exactly zero. Do **not** eagerly evaluate its guarded
  fraction and incorrectly declare that inactive division undefined.
- Hydrogen/potassium leak expressions contain denominators
  `exp(F*dPsi/RT)-1`. No Taylor-limit formula is supplied by the source; an
  actually zero denominator fails. A zero capacity multiplier does not authorize
  masking another factor's NaN. Keep this source ambiguity visible.
- Mg-bound ATP/ADP must not exceed their corresponding totals by more than
  1e-10 M. Report smaller violations as uncertainty. Check derived free pools
  with the same negativity rules. Do not double-count bound amounts.

### Conservation and open-system checks

Independently verify these relations using qualified aliases connected to the
same original quantities, and test perturbations that must fail each check:

- `ATP_x + ADP_x = 0.01 M` at every output, absolute deviation ≤1e-10 M.
- `Mg_x + ATP_mx + ADP_mx = 0.005 M`, absolute deviation ≤1e-10 M.
- O2 remains its original binary64 0.000026 M; its evaluated derivative is zero.
- `NAD_x + NADH_x = NADtot`, `Q + QH2 = Qtot`, `Cox + Cred = Ctot`, each within
  1e-12 M. These are **algebraic reconstruction/domain identities**, not three
  independently measured conserved trajectories; require nonnegative partners.
- The intermembrane nucleotide pool is **open**: the source implies
  `W_i * (dATP_i/dt + dADP_i/dt + dAMP_i/dt) = J_ATP + J_ADP + J_AMP`.
  ANT and AK cancel internally. Assess this instantaneous balance with the
  flux-expression floor above; do not falsely demand a constant intermembrane
  total or use a coarse trapezoidal integral as exact conservation evidence.

**Independently reviewed zero-subspace specialization:** this exact run has
external ATP_e=ADP_e=AMP_e=0 and all five intermembrane nucleotide states
ATP_i, ADP_i, AMP_i, ATP_mi and ADP_mi initially zero. The source's transport,
binding and guarded ANT terms therefore leave that nucleotide subspace
invariant at zero. Prove the corresponding exact symbolic specialization before
native execution; test it again against retained native rates/outputs, requiring
those five state values and their rates to remain exactly zero. In this variant,
the general open-pool balance specializes to zero exchange, not observed ATP
export. Do not seed those states, change an external nucleotide boundary, activate
AK or alter the guard to obtain a more visually interesting response. Numerical
drift from this exact invariant is a failed check, not an arctigenin response.

Do not claim full cellular energy/phosphate conservation, ROS generation,
whole-organ mechanics or homeostasis from these limited identities. No
steady-state criterion is part of this initial matrix: reaching 300 s alone
does not establish steady state or a physiological endpoint.

## 6. Proposed resource and failure policy — approval required

The previous 1 GiB hard-address-space assumption failed on this Mac. Approval
for sampled protection of **technical fixtures does not carry forward** to this
source worker. Proposed explicit step-4 policy: reviewed fixed source only,
120 s wall time per native run, hard CPU limit 60 s, core files disabled,
64 MiB per stdout/stderr/file bound, 1 GiB **sampled soft RSS termination
threshold**, 10 ms requested sampling and actual gap/peak/overshoot recorded.
No claim of instantaneous hard memory isolation or arbitrary-code sandboxing.
Compiler remains separately bounded to 30 s and reviewed fixed inputs.

Use the corrected owned-PID/start/image checks and held-waitable group cleanup;
sampling/ownership/library failure stops, with no fallback estimate. Signals,
deadline, resource breach, invalid callbacks and failed native cleanup preserve
the original failure plus separate cleanup/evidence-persistence status. One
private fresh directory per attempt; no operational stores, external requests,
inherited tokens, participant files, global installs or background services.

Retain original/conversion/generated source and new wrapper/compiler/binary/link
hashes, protocol hash, exact settings, initial/checkpoint manifests, complete
arrays, source evaluator/analysis code hashes, warnings, numerical metrics and
all failed attempts. Failure summaries must name each tested gate and missing
dependency; unexecuted cells remain `NOT_RUN` or `BLOCKED_DEPENDENCY`. Bounded
partial arrays may be retained as diagnostic evidence, never a completed run.
Private temporary storage is not a long-term evidence-retention guarantee.

If any threshold, equation, parameter, source variant, solver, initialization or
boundary condition must change, preserve v1 failure and propose v2 **before**
running it. No outcome-driven tolerance relaxation, refitting, silent clipping
or replacement with a different successful model.

## 7. Independent acceptance and next gates

Expected implementer deliverable, only after approval: red-first new wrapper and
source-analysis tests; an independently reviewed implementation manifest; then
I0 and the four fixed native runs with raw artifacts and independent recomputation.
The maker does not grade the maker. A second reviewer must examine source/time/
unit/alias identity, initialization, active branches, complete-grid comparisons,
checkpoint semantics, conservation and resource failures before acceptance.

Passing would establish only **numerically checked execution of this pinned
reference implementation**. Original author recipe/arrays or reviewed figure
extraction, resolution of the corrected-paper variant, and source replication
remain separate gates. The paper's steady-state parameterization is not a
validated transient kinetic benchmark. [Beard 2005](https://doi.org/10.1371/journal.pcbi.0010036),
[2006 correction](https://doi.org/10.1371/journal.pcbi.0020008).

Arctigenin CID64981 remains a reference material identity, not a free mitochondrial
exposure or complex-I activity law. Required whole-individual work still includes
batch characterization, gut/liver/metabolite PK, tissue exposure and demand,
AMPK/signaling, injury/repair, circulation/endocrine coupling, measured specimen
validation and personalized applicability. No human LIFE observation transfer
mapping is admitted here. No mitochondrial time series completes that program.

**Status at authorship:** document only; zero Beard binaries, initialization
callbacks, RHS evaluations or advances. The resource policy, additional
per-unit expression floors and exact wrapper/analysis implementation remain
prospective review items. No product activation follows this document.

Root and the independent scientific reviewer approved **implementation only**
after the zero-subspace clarification above. New source-worker/evaluator/analysis
code and tests must be independently reviewed before actual Beard compilation,
initialization, RHS evaluation or solves. The fixed technical wrapper's two-state
guard remains unchanged. A protocol hash is frozen outside this document to
avoid a self-referential hash; any further semantic change requires a new review.

Compounded lesson: source initialization, numerical source execution, published
recipe replication, compound exposure-response and physical human equivalence
are distinct gates. A conserved algebraic complement is not independent
experimental evidence, and an open compartment is not a constant-total pool.
