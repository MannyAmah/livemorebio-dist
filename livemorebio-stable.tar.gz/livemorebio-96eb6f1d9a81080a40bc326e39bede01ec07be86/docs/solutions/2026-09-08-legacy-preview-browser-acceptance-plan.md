# Legacy preview recovery: minimal real-browser acceptance proposal

2026-09-08. **Plan only.** No harness code, service, browser, network, registry,
native model or runtime write occurred. The six client runtime files remain frozen
at the pins in `2026-09-08-legacy-preview-client-recovery-implementation-review.md`.
Root owns approval, scheduling and independent rendered grading.

## Purpose and evidence boundary

Show that an operator can use the actual legacy controls, see old current values
cleared after uncertainty, read the operation outcome, refresh and reach existing
Twins/LIFE/Cendos inspection. Do not repeat the 164-case unit matrix in a browser.
The 632 offline passes and 87 inert producer passes remain separate evidence.

Two viewports only: **1440×1000 desktop and 390×844 mobile**. One owned Chrome
process, one fresh page/context for each viewport, one fixed sequential schedule.
No performance benchmark, GPU/ANGLE change, Atlas/3D route, asset acquisition,
scientific experiment, physical device or live attached SDK smoke.

The real page/auth/static modules run unchanged. READY states and preview failures
are explicitly **authored UI-response fixtures**, not computed or registered
biology. Put the fixture disclaimer in the existing fixture profile/name fields
and every report/image caption, not a DOM/CSS overlay. Screenshoted legacy model
wording does not establish that these authored arrays came from an engine.

## Reuse, auth and isolation

Read prior art: review-stack-isolation; ordinary Atlas presentation proposal;
current `tools/run_review_stack.py`; owned presentation supervisor's bounded
cleanup/identity primitives; the existing small member-browser route-interception
pattern; the approved preview client plan and its implementation receipt.

Use `prepare_review_environment(..., inherited=<small explicit OS allowlist>,
base_port=8910)` with a **new 0700 root and fresh credentials**. All stores/caches,
bus, audit, model, evidence and source paths stay inside it. Unlike the Atlas
wrapper, **no retained anatomy override or cache reuse**. Confirm 8910–8912 are
free immediately before launch; an occupied/unknown result stops, never kills or
switches to an installed service. Root must reserve these ports for this run.

Prepare one new, clearly labeled software-only REAL_HUMAN-shaped fixture using
the existing `human_payload(condition="")` shape and ordinary
`create_twin → select_observations` before startup. Use newly generated review
keys, never an old test/operational store or fixed fixture key. Require ACTIVE,
UNAVAILABLE/MODEL_BINDING_REQUIRED, observations_only and tw=None. This is schema
testing, not participant admission or a clinical record. The normal three service
modules then start with no access logs and bounded graceful shutdown.

No numerical candidate is needed: browser interception supplies the small READY
UI fixture. Install startup/model-constructor tripwires in the approved private
launcher, not product source, before services can instantiate any engine; the
real modeless startup must still pass. A tripwire hit stops the run. If a reviewed
launcher cannot enforce this without changing production semantics, return for
review rather than run an empty stack, which constructs a healthy model.

Use the existing gstack-installed Playwright module at
`/Users/emman/.agents/skills/gstack/node_modules/playwright/index.js`, installed
Chrome, fresh contexts and no persistent profile. Reuse the approved isolated
Playwright route rather than invoking the compiled/source browse launcher with
its known legacy shared-state cleanup hazard. No installation or launcher repair.
No WebGL/SwiftShader flags, tracing, video or browser performance instrumentation.

Let the page's unchanged auth.js perform its actual
`GET /api/session/bootstrap`; do not intercept it, inject bearer headers, set
cookies manually or save cookie values. Before response fixtures are enabled,
require an actual successful authenticated modeless `GET /api/state` and matching
service/source pins. Inspect only cookie **attributes/count**, never its value,
and record booleans for HttpOnly/same-origin/session establishment. Bootstrap is
the existing bounded automatic local-cookie flow, not a login form or token entry.

## Minimal fault adapter, not a new transport

New-only proposed files, after approval:
`tools/check_legacy_preview_browser.py`,
`tools/check_legacy_preview_browser.cjs`, and
`livemorebio/tests/test_legacy_preview_browser_harness.py`.
Reuse import-safe environment, health/build validation, PID/start ownership,
exact-child cleanup and strict listener-query helpers. Never call the Atlas main,
cache or browser workload. No product test hooks or generic scenario endpoint.

The CJS adapter is a fixed in-memory, sequential response schedule using existing
Playwright route interception. Admit exact method/path/body family before
fulfillment. Four preview POSTs total are intercepted; **zero mutation requests
reach the actual services**. Reject every other POST/PUT/PATCH/DELETE. No automatic
preview retry, reconciliation POST, numerical execution or fake backend commit.
This tests delivery/recovery at the browser boundary; durable commit behavior
remains covered by the separately reviewed actual-registry/producer packets.

Use the small authored `preview()` state shape already in dedicated unit fixtures,
with explicit A/B/C profile labels and opaque scenario generations; freeze its
literal fixture bytes before execution. Generate no additional clinical values.
Only these responses may be fulfilled: exact preview POSTs, scheduled legacy
state GETs, minimal matching legacy biology output and, during the recovery
navigation case, the fixed UNCONFIRMED Twins listing. Other approved reads reach
the actual modeless services. Record each response as FIXTURE or ACTUAL.

For the lost-ACK case, mark only an in-memory technical delivery event and abort
the one browser POST. Label it SIMULATED_ACK_LOSS, never evidence of a committed
backend transaction. Both 503 forms use existing fixed codes and distinct canonical
UUIDs. Do not replace window.fetch, owner functions, timers, rendering, DOM, CSS,
native promises or event handlers. No page.setContent or direct state assignment.

Before code freeze, enumerate the finite static-module/read dependency allowlist
for /legacy, /twins, /patch and /cendos. Permit only those three owned origins,
normal metadata/inspection reads and declared fixture responses; reject arbitrary
URLs, source installs, external APIs, assets and Atlas paths. Known Google-font
requests are blocked and reported as fallback context, not retried or vendored.
An unexpected request fails the run rather than expanding the allowlist live.

## Fixed operator sequence and 12 planned images

Use actual visible locators after inspecting the current page. Fill fields and
click/keyboard-activate controls, never call inline handlers or dispatch synthetic
events. Ordinary scrolling is allowed. Take viewport screenshots at relevant
controls/status, not hidden DOM claims or forced layout changes.

| Step | Actual operator action and expected visible result | Images |
| --- | --- | --- |
| D0 | Open /legacy with normal cookie auth and real modeless state. Numerical actions disabled; explicit preview and inspection available. | desktop-modeless |
| D1 | Explicit Refresh reads authored READY A. Click Healthy once. Hold only its follow-up state GET, bounded to 2s, to view pending cleared charts/identity. Release to C although ACK described B. Show only C as current; one POST and one follow-up GET, no optimistic B highlight. | desktop-pending, desktop-later-winner |
| D2 | Click the existing LIFE carrier preview once. Return 503 SELECTION_COMMITTED_CLEANUP_UNCONFIRMED, then fresh GET C. Keep committed/cleanup notice and current UUID after rendering; no repeated POST. | desktop-cleanup |
| D3 | Select Note, type the fixed authored-only text, Tab to its submit button and press Enter. Abort that one POST as simulated ACK loss; its follow-up GET returns 503 SELECTION_COMMIT_UNCONFIRMED. Old numbers/note/current export clear and cannot repaint; inputs/history remain, no busy trap. | desktop-note-before, desktop-unknown |
| D4 | From the notice, click Twins and inspect fixed UNCONFIRMED selection/reconciliation affordance, without invoking it. Return using browser Back, requiring one fresh current read (record real pageshow.persisted, not assumed bfcache). Then follow LIFE inspection and Cendos, click History. No prepare/start/stop/run or other mutation. | desktop-twins-recovery, desktop-life-inspection, desktop-history |
| M1 | Fresh 390px context, real auth/modeless baseline, explicit Refresh to authored A. Use Note and actual keyboard/button submit; 503 SELECTION_COMMIT_UNCONFIRMED and denied follow-up GET. Notice/UUID wrap readably, numerical controls remain disabled and no stale activity returns. | mobile-note-before, mobile-unknown |
| M2 | Click Refresh once; return modeless. Modeless preview controls recover, numerical actions remain disabled, prior unknown-operation notice remains. Inputs and existing navigation remain usable. | mobile-refreshed |

This is **four preview submissions**, not a cross-product of inputs/errors.
Fixed History can be checked as unchanged if present; do not seed an experiment
merely to produce history. Empty Cendos History is a valid navigation result, not
an experiment completion. Unit tests retain the frozen-history mutation checks.

Before/after each action record safe status checks: expected current profile
fixture marker or no-current marker, disabled controls, absence of prior fixture
readouts/notes, canvas cleared/not repainting after two actual animation frames,
cardiac transform/metabolic color, visible recovery text, no horizontal overflow
or occluded target. Read DOM for assertions only; report booleans, not raw arrays.
Root separately views all 12 images. No UI fix is applied during this run.

## Bounds, receipts and stop rules

Freeze package/harness/fixture/Playwright/Chrome identities before launch. Verify
all three service source/process/start identities before browser work, after each
viewport and at final cleanup; distinguish the real unchanged modeless selection
from the deliberately different fixture generations. Do not relabel source drift.

Limits: startup 45s; browser schedule 180s; individual navigation/read/action 10s;
the one held response 2s; 256 total browser requests; four intercepted POSTs;
12 planned screenshots plus at most 2 failure screenshots; 64MiB total evidence.
Keep production 20/60s request deadlines unchanged. Global supervision 350s,
including bounded cleanup, not a longer retry window. Any timeout, unexpected
request, extra POST, raw-data leak, source drift or failed assertion stops new
actions immediately. Remaining cases are NOT_RUN. No automatic rerun.

Retain only fixed scenario/outcome/check booleans, method plus allowlisted path
category, status, canonical request UUID, durations/counts, source/runtime/file
hashes, screenshot hashes/dimensions/viewport/scroll metadata and fixed console
error categories. Never retain request/response bodies, notes, cookie/header
values, browser storage, network traces, credentials or arbitrary exception text.
All screenshots contain only authored fixtures. Missing evidence is failure,
not a silent reduced image count.

Always attempt each owned page/context/browser close independently, with its own
bounded status receipt; do not collapse all into one unexplained cleanup error.
Then reuse exact Popen termination/reap limits (10s TERM/5s KILL per child) and
PID/start descendant verification. Use the reviewed tri-state listener query
(3s query/2s TERM/2s KILL); unknown is UNCONFIRMED, never no-listeners.
Only signal exact proven owned processes. Preserve the primary failure separately
from cleanup/evidence failure and retain all private files. No arbitrary process
stop, cache deletion or audit rewrite. Cleanup uncertainty prevents PASS.

## Approval and grading gate

Before execution: independently review the tiny harness/fixture mapping and its
offline safety tests (counts, real-auth bypass rejection, timeout/late response,
source drift, unrelated mutation denial, per-resource cleanup/evidence failure).
Do not regenerate the 164 unit scenarios. Root separately authorizes one fixed
actual run only after final client review and source freeze coordination.

The /browse and /qa skills, taxonomy and report template were read fully. Their
user-flow, responsive, screenshot and explicit failure-evidence rules inform this
plan. No skill browser-launch, auto-fix, commit, telemetry or setup step ran:
the explicit plan-only/no-execution scope takes precedence. The unavailable
gbrain/CE providers were not claimed as used; local prior solutions are cited.

Result labels must separate HARNESS/DELIVERY, VISIBLE_UI and CLEANUP. A passing
harness cannot self-grade screenshots. Browser findings return to a written
bounded correction, not inline source repair. Full product/scientific/Atlas
acceptance remains open.

## Root pre-code review

Root read the complete188-line proposal against the frozen client receipt and
the real legacy navigation/controls and private-stack launcher. Approved the
three new-only harness/test files and the fixed12-image/four-submission matrix.
This is approval to implement and offline-test the harness, **not approval to
launch it yet**. Keep the delivery fixtures visibly described as authored
software tests; they are not any of the six required experiments or their
recordings. Do not claim their supplied READY arrays are computed biology.

Before freeze, enumerate exact approved reads/static dependencies and every
normal-service initialization path. Install constructor/solver tripwires before
startup, without altering the production routes or auth. If these cannot leave
all three real services modeless, report the concrete gap rather than enabling a
numerical fallback. Freeze the actual package/service and client source hashes.
The one held read must remain bounded to2s, including an unsuccessful screenshot;
do not extend it during execution to manufacture a pending image. Retain a
missing/raced image as failure. Explicit original per-resource cleanup receipts
are required; no Atlas/skin diagnostic or prior accepted presentation rerun is
authorized. Root will independently inspect the harness and its offline evidence
before authorizing a single actual run and reserving8910–8912.

### Single Cendos inspection dependency refinement

Before harness execution, the maker found that the History page automatically
reads GET /api/genome-models, whose actual capability handler calls the installed
GLPK version function. Root read both that handler/runtime-capability path and
the Cendos readiness consumer. For this no-native UI-delivery gate only, permit
one additional fixed FIXTURE unavailable catalog for that exact GET during D4
Cendos navigation. Its human-gem status/execution must both be unavailable, with
a fixed authored-browser-fixture reason, not a claim about the actual installed
model. Freeze the full literal response, count/tag it separately and never send
the request onward. No model install, solve, alternative query, new product hook
or additional mutation is authorized. Other allowlist changes still require
review. This fixture cannot count as Human-GEM integration verification.
