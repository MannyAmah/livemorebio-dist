# Molecular layout: separate once-only actual decision

2026-09-09. The independent reviewer cleared the three product files and fresh
private harness after full source review. Exact related product repeat153 passed
in18.70s, c5c5ac/session22242/private3pyyv_ga, unexpected I/O0. The private harness
repeat46 Node plus6 Python passed (a4aeb2). All22 input/eight private pins matched;
the reused supervisor, page and Python tests remain byte-identical. Reversing
only the approved product deltas reproduces the old controller/CSS hashes.

Root separately verified all30 byte pins and absence of the exclusive run
directory (913c8d exit0). Accept this narrow implementation review, not actual
graphics or scientific validation. The original WoWI5H failure remains intact.

Authorize exactly one actual invocation:

```
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-molecular-layout-browser.LygJpf/check.py --run-once
```

Frozen CJS SHA f7b477d44cf8ddd8fecff855d18a9653894369528f15310b9652d201da71f4ce;
inputs SHA6498c3f95ddf53a635e57badaebb1eb7d9ce695cfaedb38edb9d318e4b46bd9a;
harness manifest SHAa7036010c1ad955d4acce018b8484151263cb6877205fc2f17fada84ac07d5d3.
The unchanged Python supervisor is1dd4a2c22483f01c54ba45a53b9812d03f0c35bfe4b0dd80de9181903ac0a168.

Keep all four stages/11 original images/six exact public structures, explicit
pig4INS versus unavailable human INS, fixed local origin and resource/time
bounds. No ordinary app, old store, participant, operational device, native
scientific model or public distribution runs. Do not alter the source while
the once-only check is active. No canceled request is a pass. No automatic
retry follows failure. Root must inspect original captures, retained timing,
control/source assertions and exact owned cleanup before accepting any result.

All six experimental recordings and full R01–R51 product acceptance remain open.
This prospective decision will receive its actual outcome separately.

## Actual outcome and narrow checker correction proposal

Actual session11476/completion6abaa1 exited1 in20.290577584s. The consumed
LygJpf run is FAILED/MEASUREMENT_UNAVAILABLE at D1. D0 passed: original4OBE
READY,989×478px canvas, unobscured status and scope. Root inspected both
original desktop/help images; controls now sit inside the stage rather than
covering provenance/status. This accepts only those observed desktop facts.

The present-residue clicks yielded two real selection-history entries. Retained
wrapper indices1/2 correspond to visible M/T labels, not PDB author numbering.
The actual displayed measurement string is `5.82 Å | THR 3 — MET 2`. Pinned
upstream label.js defaults to U+212B ANGSTROM SIGN and computes a rounded
distance between loci centers; the harness incorrectly accepts only U+00C5.
Thus a genuine rendered geometric measurement was rejected by the checker.
It is not a chemical reaction or a patient-specific distance measurement.

All9 request terminals were finished in D0, zero failed terminals. This does
not retroactively explain or erase WoWI5H's ERR_ABORTED. D2/mobile and nine
planned images remain NOT_RUN. Failure-image capture was unavailable again.
All four owned closes settled; Node39608 was reaped and11 recorded descendants
were absent. Both listener checks were clear. Root's separate exact12-PID check
also returned no rows (2a478b exit1). All22 input/eight harness pins match.

Original browser result SHAfa994fc6a9b314e2230de352dce1eef036496a9bb7078b1191b0846c39620d17;
supervision SHA f82cdb0f9bade43ad0f8bccb1a831628a467ceff80a7e7fada017ff0b17af03e.
Desktop PNG SHA1ca590ae2f186b46ca8c54fa22de9820f7acde7972d3b4608264964b3d613849;
Help PNG SHAe9c05439fe30804c8ae379ae5b84525252df7f777ae7c6d4e3cdcb3c4efc874a.

Propose only a fresh private successor's unit parser: normalize the displayed
string to Unicode NFC before the existing finite-number/angstrom assertion,
retaining the unmodified original text in evidence. Add RED tests against the
actual U+212B string, U+00C5 and decomposed canonical form, with wrong-unit,
nonfinite and absent-number rejection. Do not change any measurement, numeric
tolerance, product/source/bundle file, selector, transport or deadline. Preserve
the entire11-image workflow and all prior52 checks. Independent review is required
before this narrow change and before one separately authorized fresh browser run.
No consumed file is to be edited or reused.

Independent pre-code review cleared the NFC correction and identified a precise
additional checker defect: the unanchored expression accepts `1e309 Å` by its
suffix309 and can accept Å/s. Root accepts an anchored leading fixed-decimal
token with exact angstrom/end-or-pipe boundary and explicit finite conversion.
Add overflow digits, exponent, NaN, Infinity and wrong-unit negatives. This
strengthens the same displayed-distance assertion without changing numerical
tolerances or scientific behavior. Independent receipt review1a77ba confirmed
actual U+212B, two history entries, nine finished requests and four settled
closes. Root's independent original-expression reproduction be7684 confirms
canonical normalization recovers5.82 without changing the original string.

## Separate successor actual decision

Independent unit-parser source review is clear. The exact65 offline repeat
passed (f0d0fe exit0:59 Node188.162ms,6 Python0.021s), all30 pins and the
unchanged three product files verified. Root accepts only this checker review.

Authorize one fresh actual invocation, with no product or source change:

```
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-molecular-unit-browser.kCPxWp/check.py --run-once
```

CJS0024e5c455835e52d28973e7aa217a88bede81a1e7348c7b34f79a9e0963d225;
inputsf709a6416eac39a92e63abaf53fb372d6b7db5937defcfbfc04eb97aa7f6c989;
harness pinse74237d6af0e698157d75e8543499570bc01155bf4fbb3509a7f1ed5fecde697.
All earlier source, security, time, image and cleanup conditions remain unchanged.
The two prior actual failures remain intact and no automatic retry is authorized.

## Actual successor outcome — interactions pass, transport remains failed

The authorized kCPxWp invocation completed with exit 1 (session 40895,
completion c1fdac), in 46.675947084 s. All four stages and all 11 original
captures passed. The overall result remains FAILED because the first D0 KRAS
coordinate request retained ERR_ABORTED at 3755.837334 ms. This precedes D1
(11555.940167 ms), the first explicit page retirement (41949.869709 ms), and
final cleanup (45948.171542 ms). The cause is not established by that chronology.

Root has visually inspected all 11 original images. The corrected controls stay
inside the desktop and portrait stages; initial source/status text is readable.
Desktop canvas is 989×478 and mobile is 350×240. Mobile provenance is reachable
by scrolling; its later offscreen canvas/status are not claimed simultaneously
visible. The actual source-geometry distance `5.82 Å | THR 3 — MET 2` was created
and deleted through controls. Eight close cycles restored focus and removed the
plugin, including mobile Escape. These are reference-viewer interactions, not
biological reaction or individualized-model validation.

All six deposited structures retained their exact source metadata. Pig 4INS
remained explicitly separate from unavailable human INS; the latter caused zero
coordinate requests and no replacement geometry. All 29 GETs have terminal rows:
28 finished, one failed. No page errors, console errors or CSP violations were
retained. All six owned resource closes settled, Node 40215 was reaped, and the
16 recorded descendants and listeners were absent. Root's exact 17-PID check
ae101f returned no rows (exit 1).

Root recomputed the two original receipt hashes (c10686): browser-result.json
`7896893ea9252b15ff92619d8ae22e799db58dabd711c168339bef3e53823358`;
supervision.json
`ca11f09cd56c3ea11f5ee454d8d26ec3fb251b526dd5cc7eb0ff2c5e6097db03`.
Independent data-only review f85f38 verified all 11 image byte/hash/dimension
records, 30 frozen pins, complete source descriptors, request multiplicities and
cleanup ledger. See `2026-09-09-molecular-unit-browser-independent-result.md`.
Root read that review in full. The independent reviewer did not grade appearance;
the separate original-image inspection above is root's observation.

No failure is waived, no consumed root is reusable, and this result does not
authorize another browser attempt. The live Biology consumer switch, complete
product acceptance, all R01–R51 requirements and six experiment recordings remain
open. A source-based transport investigation must precede any proposed next
diagnostic or product change.
