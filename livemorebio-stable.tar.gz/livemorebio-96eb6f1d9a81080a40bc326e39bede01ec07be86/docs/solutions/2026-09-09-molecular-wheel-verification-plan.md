# Molecular reference wheel verification

Root plan before execution. This extends the existing outside-checkout wheel
regression only; it is not the clean managed installer acceptance or cardiac
model packaging correction. The prior documented CellML rights/path gap remains.

1. Take one private snapshot of the18MiB source package, pyproject, README and
   LICENSE while runtime writes are paused. No old package/build/cache is touched.
2. Build that snapshot with the existing Python3.11/setuptools backend, offline
   (`PIP_NO_INDEX=1`, no dependencies/build isolation), into private output only.
3. Run the existing wheel regression from that snapshot with fresh private
   review paths. Check original manifest/Atlas requirements plus the added fixed
   catalog/six original CIF files. Its isolated outside-checkout subprocess must
   resolve the installed reader, verify all six hashes and27 targets, retain
   pig INS as related-only, and import no numerical solver.
4. Retain wheel hash, exact result and private paths. The package/data-only test
   must not run an experiment, acquire a source, install dependencies or mutate
   the active release. Overall invocation has a120-second bound; original managed
   install/native model/full-product validation remain explicitly untested here.

The existing test is reused rather than creating another packaging harness. Its
wheel build occurs in the copied snapshot to prevent setuptools metadata/build
outputs from modifying the shared worktree. The original runtime data test was
read in full; its new molecular checks are not counted passed before execution.

## Maker execution receipt, September 9

Private snapshot`/tmp/livemore-molecular-wheel.IKsy3D/source` matched source
fingerprint`f755a2aab6883e40cd0e384b24d2b1e7ddca20719e5d1ba5873d3322fbbb83aa`
before building. Existing test ran from that copy with private review paths,
PIP_NO_INDEX, disabled pip configuration/version checks and private cache.
Calls were one wheel build and three isolated imports, bounded by120 seconds
overall/per-call remaining time. **1 passed in2.20s**, session46323 exit0.
The actual new wheel is
`/tmp/livemore-molecular-wheel.IKsy3D/pytest/test_installed_wheel_can_load_0/wheel/livemorebio-0.0.1-py3-none-any.whl`,
SHA256`efe567076516c17e2533021143344b1682981c564323c5b8ecd47d557454ed08`.
The test extracted this locally built wheel to a new private target and imported
from that target; it did not invoke pip install or install dependencies. Existing
manifest/Atlas assertions plus six coordinate hashes/27 mappings passed, without
numerical modules in the molecular importer. No solver or service was launched.

This is a maker result pending independent review, not clean external-user
installer acceptance. No changes to the managed installed release, source
checkouts other than the authored test/package declarations, old caches or
operational stores. No cardiac model file was silently bundled to conceal its
separate documented rights/path gap. The snapshot predates new unwired molecular
controller files; it is not a final release artifact.

## Independent retained-source/artifact review, September 9

Source-research reviewed the complete132-line wheel test and this plan/receipt,
without rebuilding, extracting, importing the package, running npm, fetching a
source or launching a service/model. Snapshot and current test bytes match:
SHA256`15355c6381d5b97155874663825791c405a4b5619ad2bb39b4c83c6c31dc85b7`.
The molecular addition checks exact wheel member presence, installed-reader path,
all six coordinate hashes against the catalog,27 target mappings, related-only
pig insulin and absence of the named numerical modules. The original whole-human
manifest and absent-Atlas assertions remain intact.

Independent data-only checks found the retained3,030,875-byte wheel has the exact
reported SHA256`efe567076516c17e2533021143344b1682981c564323c5b8ecd47d557454ed08`.
ZIP member names are unique and its complete CRC test passes. The reader, catalog
and six CIF byte streams are identical across the wheel, source snapshot and
previously extracted isolated target. Reader SHA is the independently reviewed
`b1f8533211b63eaa74ca279fd475ad4aab701a3ad30090892e382572a6cf7296`;
the60,294-byte catalog retains SHA`89a15b12f2dbe5aac1edc53885b525c72863b3bb915a6c3e81a044f74ed67360`.
All six CIF hashes match their admitted catalog descriptors. INS remains without
a human structure mapping and lists4INS only as related reference. A separate
read-only reproduction of the documented source-hash algorithm matches the
reported f755a2a… snapshot identity; no package import was required.

Scoped verdict: no blocker found in the added molecular packaging assertions or
retained molecular bytes. The reported1PASS/2.20s is the maker execution receipt,
not an independently repeated test count: the subprocess outputs are captured
by the test, not separately retained as stdout receipts in this private tree.
This review did not rerun those imports. The clean installer/dependency workflow,
final controller-inclusive wheel, browser behavior and scientific qualification
remain outside this evidence. No earlier packaging/source-rights gap is cleared.
