# Committed source transitions — proposed internal interface

2026-09-08. Read-only source review and interface proposal; **not implementation
approval**. This specializes the approved
[committed-transition plan](2026-09-08-committed-source-transition-plan.md), not
R01–R51 or the six experiment programs. No constructor, registry operation,
service, model, browser or operational store ran during this review.

## Existing seams and exact gaps

`ModelSourceAuthority.commit_guard()` already provides authority → manager
creation → manager locking; `install_generation()` already supports a precomputed
generation or DENY_ALL. Neither needs a new transaction framework. Existing
`RegistryAudit.begin/check_authority/finish` supplies encrypted reserved access
audits and the bootstrap authority fence on the same SQLite connection.

Do not use `_audited` as the new mutation owner: its unconditional exception
rollback/failure completion does not classify a lost commit acknowledgment.
Use it for a successful, audited preparation read only. The explicit transaction
shape in `select_observations` is useful prior art, but its recovery check proves
only the target ciphertext and pointer, not demotion rows or its terminal audit.
Its all-ACTIVE demotion loop is also not the bounded topology contract below.
Do not copy those two weaknesses into the three new route families.

## Minimal types and callable boundary

Keep the pure frozen types in `subjects.py` beside
`PreparedObservationSelection`; no new general-purpose transaction module is
needed. Suggested signatures:

```python
@dataclass(frozen=True, repr=False)
class PreparedRegistryTransition:
    # Internal kind: exactly activate, bind, or clear_for_preview.
    # Private immutable bytes/tuples only; no mutable dict or public hash token.
    ...

SubjectRegistry.prepare_activation(
    twin_id: str, *, expected_version: int, request_id: str,
) -> PreparedRegistryTransition

SubjectRegistry.prepare_patch_binding(
    twin_id: str, body: object, *, expected_version: int, request_id: str,
) -> PreparedRegistryTransition

SubjectRegistry.prepare_preview_clear(
    *, request_id: str,
) -> PreparedRegistryTransition

SubjectRegistry.commit_prepared_transition(
    prepared: PreparedRegistryTransition,
) -> Literal["COMMITTED", "COMMITTED_CLEANUP_UNCONFIRMED"]
```

The prepared value contains the registry store ID, nonempty checked bootstrap
authority token, operation/request UUID, frozen timestamp, exact before/after
record bytes, exact relevant SQL row metadata, pointer before/after and the
one relevant device-index row before/after. It exposes detached record values
only through decoding properties; no automatic plaintext repr/logging. The
expected source generation belongs to the server's separate prepared publication
value, not the registry or HTTP input.

Preparation is an audited read of one coherent writer-transaction snapshot. It
then computes the allowed transformation after that read has committed and its
connection has closed. It may not construct an AegleTwin or run a numerical
profile. Source-context and admission checks that execute profile construction
must run outside the final transaction and all source/manager locks. Exact input
comparison at commit ensures those checks still describe the same record.

The commit helper accepts only the exact internal type and independently checks
that its after-records are the allowed transformation of its before-records with
the frozen timestamp. A frozen Python dataclass is not by itself authorization:
do not trust a forged prepared result merely because its type is correct.

Keep the public/direct registry signatures `activate_twin`, `bind_patch` and
`clear_active_twin` as thin prepare/validate/commit wrappers with their existing
return shapes. They use the same strict versions, topology and transaction
outcome classifier. Direct standalone registry writes do not claim to synchronize
an unrelated server process's model memory.

## Bounded read set, topology and write set

Read the active pointer including its `updated_at`, then the TWIN ACTIVE IDs with
an ordered LIMIT 2 query. Pointer absence requires zero ACTIVE twins. A present
pointer requires exactly that one ACTIVE TWIN and a coherent authenticated record;
a present missing/non-TWIN/inactive target is an error. A second ACTIVE TWIN is a
conflict/integrity failure, not permission to decrypt/reseal an unbounded set.

At most the selected record and intended target may be decrypted/prepared.
For each, bind all SQL columns (`record_id`, `record_type`, `source_class`,
`lifecycle`, `version`, `idempotency_key`, `request_hash`, `created_at`,
`updated_at`, nonce and ciphertext) plus canonical authenticated content. Recheck
both at final commit. This rejects same-version content edits and unexpected
resealing instead of silently using a stale candidate. Untouched indexes and
legacy creation/idempotency fields remain byte-for-byte unchanged.

| Family | Exact clinical/index changes |
|---|---|
| Activation | Target becomes ACTIVE with next version, frozen updated_at and explicit `selection_mode="model"`; if a different selected twin exists, only it becomes DATA_ADMITTED with one version increment. Upsert the one active pointer. No binding/subject-identifier/cohort writes. |
| Selected binding | Replace only this device's entry in target patch_bindings, increment target version once, preserve lifecycle/model fields and selection mode. Physical mode checks/upserts only that device's existing fingerprint row. Pointer and unrelated records remain unchanged. |
| Unselected binding | Same target/index write rules; physical binding requires the pointer to identify this REAL_HUMAN target, so physical unselected binding rejects. Confirmed virtual/replay binding does not change active source generation or model memory. |
| Clear for preview | If selected, demote only that record once and delete only active_twin_id. If truly absent, no clinical row is written; its audited successful absence still permits the explicitly requested preview transition. |

Freeze direct/HTTP version admission as exact int, positive and safely
incrementable: `1 <= expected_version < MAX_SAFE_INTEGER`. A value at the maximum
cannot produce a safe next version. Stored row and plaintext versions must also
be exact coherent integers. Reject numeric aliases before preparation or writes.

Binding input uses its existing documented fields only: device_id, mode,
protocol_version, hardware_revision, firmware_version, calibration_status,
attestation_reference and HTTP expected_version. Preserve documented defaults
and case normalization for strings. A direct body's optional expected_version,
if present, must equal its separately supplied strict keyword; never coerce it.
No new physical qualification, device command, index release or replay policy is
introduced. In particular, existing cross-mode/index-retention behavior needs an
explicit preservation decision, not an incidental DELETE added by this helper.

## Final commit and exact acknowledgment witness

The server initializes its registry dependency before taking the source guard.
After reading the complete strict body, capture generation plus preparation under
authority, then release it for candidate/profile/state/response precomputation.
Selected binding performs no model construction and keeps the actual live model,
observation-state and action objects; cloning an earlier observation snapshot
would discard packets admitted during preparation without a generation change.

Inside `commit_guard`, reject DENY_ALL, generation change or in-memory/registry
four-field disagreement. The commit helper then:

1. Uses the existing durable audit BEGIN and reserved terminal slot. Rechecks
   the prepared authority token against the new reservation, not merely BEGIN
   versus completion within this attempt.
2. Opens BEGIN IMMEDIATE, checks the same reservation authority before clinical
   decrypt/write, compares the whole read set/topology, validates exact planned
   changes and writes only the rows above.
3. Finishes SUCCESS in that transaction and captures an immutable commit witness
   before calling commit. No new persistent receipt or audit payload field.

The smallest audit API addition is for `RegistryAudit.finish(...)` to return the
terminal event ID already returned internally by `_append`. Existing callers
ignore that return. Preserve its signature inputs, encryption/AAD, reservation
accounting and failure behavior. The mutation helper can then retain the exact
BEGIN and terminal event rows (IDs, sequences, nonce/ciphertext), reservation
absence, every expected changed/unchanged relevant record row, pointer and device
index state. The witness is private transient memory, not a clinical export.

A confirmed commit returns the prepared outcome. If commit acknowledgment is
lost after the transaction ended, one consistent read-only SQLite transaction
containing the exact witness check may establish
that complete write; target version, target ciphertext alone or any historical
SUCCESS is insufficient. Do not decrypt clinical records, write a new receipt or
retry the operation during this check. Missing witness, failed read or uncertain
rollback produces fixed SELECTION_COMMIT_UNCONFIRMED. A confirmed rollback keeps
the old source intact; its failed access audit remains allowed and bounded.

Preallocate return/response alternatives. A final connection-close failure must
not replace an already confirmed durable outcome with a presumed rollback:
retain COMMITTED_CLEANUP_UNCONFIRMED and publish the committed identity before
returning the existing inspect-required result. Preserve the primary error on
failed paths. Its fixed safe message must describe resource cleanup generally,
not falsely attribute a connection-close failure to a native execution. Test this
explicitly rather than relying on a finally return/raise.

Under the same guard, assign the precomputed generation/state only after confirmed
commit; install DENY_ALL for uncertainty. Hold old state/action references in a
retire holder before assignment, and release them only after every lock. Perform
execution invalidation, adapter cleanup and best-effort publication outside the
guard. On confirmed unselected binding, perform neither source swap nor execution
invalidation. Arbitrary external writers are not synchronized by the Python lock.

## Startup and scope decisions to resolve before code

Startup is a checked read, not a fourth mutation. Reuse the checked snapshot
reader and existing audited confirmation, extended internally only as needed to
compare the exact pointer/index/topology evidence, including true absence. Its
final audit failure authorizes no publication; no ciphertext/version rewrite.
Unsupported restored humans retain explicit unavailability; storage uncertainty
sets DENY_ALL, not a healthy preview and not a fatal static-app startup exception.

The existing `_initialization_lock` spans model construction. The approved plan
explicitly excluded authority/manager/registry locks, while the latest assignment
says construction outside locks. Root must freeze this distinction: either retain
the initialization-only mutex as an explicit exception, or claim initialization
briefly then release it for construction and finally compare an ownership token
plus generation/initialized state. Do not introduce unbounded duplicate startup
constructors or wait while holding authority/manager locks. A later operator
selection must win over a stale starter.

Numerical activation's explicit model selection mode and safely incrementable
upper version bound above are necessary contract refinements for approval, not
silent maker choices. Observation-only selection/reconciliation are existing
separate families: their current weaker commit witness/all-ACTIVE loop must not
be represented as fixed by this legacy packet. If root extends their reuse of
the new exact reader/witness, approve and test that narrow follow-up explicitly.

## Proposed ownership and red packet

- Registry owner: `subjects.py` preparation/commit/wrappers; the additive terminal
  ID return in `registry_audit.py`; new `test_committed_registry_transitions.py`.
- Root: server activation, selected/unselected binding, base/LIFE/note preview
  dispatch and startup publication; new `test_committed_source_transitions.py`;
  preserve the already authored `test_legacy_transition_admission.py` reds.
- Leave model_source.py/execution.py, bootstrap, reference-cohort service, Cendos,
  SDK/UI, wire bytes, scientific sources and all v1 evidence unchanged unless a
  separately reviewed failing case establishes a required narrow seam.

Red cases must cover exact read-set changes at constant version, all pointer/ACTIVE
topologies, token adoption between preparation and commit, next-version overflow,
forged prepared results, each individual row/index/terminal-audit witness missing
after lost ACK, confirmed rollback versus unknown commit, final-close failures,
selected binding preserving a newly admitted observation, no native method under
commit locks, old-state finalizer outside locks and late startup cancellation.
Run isolated authored fixtures with constructor/network tripwires. These tests
prove software contracts only; ordinary browser/terminal acceptance remains later.

## Root interface review decisions

Root read all212 lines and the actual current activation, binding, preview,
startup, availability and audit-consumer seams. Accept the three fixed prepared
methods/commit helper, bounded exact read/write sets, safely incrementable
versions, explicit activation `selection_mode=model`, and additive terminal-ID
return as the intended interface. Cross-mode physical-index retention is
preserved; no DELETE/reassignment policy is introduced. Selected binding keeps
live model/observation/actions objects and only changes confirmed identity.

Retain the existing initialization-only mutex as an **explicit exception** to
the outside-lock construction rule. It serializes competing startup constructors;
no authority/manager/creation/registry lock may be held during construction or
projection. Final confirmation still checks generation and initialized state so
an operator selection wins over a stale starter. This is not permission to hold
the initialization mutex during adapter cleanup, network I/O or publication.
On storage uncertainty, keep static routes/auth available, install DENY_ALL and
prevent fallback construction; do not fabricate a model-availability reason or
a healthy record for an unknown selection.

The current observation-selection/reconciliation witness and ACTIVE-topology
weaknesses remain explicit follow-up obligations under R15/R31/R47. They require
their own reviewed reuse/tests once the exact reader/witness exists. No claim
that this legacy packet already corrects them is authorized.

Runtime implementation is sequenced after the frozen ordinary Atlas check to
avoid source drift during visual evidence. First registry helper packet can
proceed in its own assigned lane after that freeze is released, red-first and
independently graded; server integration follows the exact helper tests. This
entry is not authorization to edit during the UI freeze or operate old stores.
