# OSP unused-row parser correction: frozen maker packet

2026-09-09. Root approved **decision A only** in the fully read
[parser amendment](2026-09-09-osp-vmmap-unused-region-parser-amendment.md), SHA256
`98c4d08f4cacb9b559847d33f59feabcb27fba5acc8fab092e206b6812e58589`.
This implements that narrow negative-row correction. Decision B is not
implemented or approved here. No OS/native/model/browser/service was run; no
automatic retry or scientific/preflight acceptance is added.

## Exact frozen write set

| File | Lines / bytes | SHA256 |
|---|---:|---|
| `tools/osp_semantic_supervisor.py` |946 /48084|`d2ac1bac780fbbeec7ad759994068104db8cb1eb70c95a3b3180696999117235`|
| `livemorebio/tests/test_osp_vmmap_format_contract.py` |129 /6412|`84690c262cb392b3a85e2b4e3bedc25924bf3e4e637e6675074c24c7a9146c41`|

The only runtime change is lines318–344 inside `vmmap_paths`. The previous single
`for line in text.splitlines():` was replaced with a bounded unused-row branch.
Reconstructing precisely that original loop in memory produces46357 bytes and
the exact original full-file SHA256
`cdb00a1acb5b08b3f7d8aff0f3977f746b5a506ed4f97355b56dd34bf2d2a476`.
Thus no other function, limit, gate, native call, cleanup or image-admission byte
changed. No inherited test or consumed private helper/worker/driver was edited.

The positive return API, ordinary-row regex, ambiguity fallback, UTF8/PID/input
bound and2048-positive-path bound remain. Only exact unused __DATA_DIRTY system
annotations, or the observed pathless __TEXT/__DATA annotations, can be excluded.
Their address interval must be ascending, four size tokens are lexically bounded
(1–16 digits, optional1–3 decimal digits, optional K/M/G), protection/sharing and
annotation words are fixed. Path-bearing unused rows require control-free
absolute `/System/Library/` or `/usr/lib/` paths, at most4096 characters, with no
truncation/wildcards/empty or dot components. Other reserved unused-region forms
raise the existing INSPECTOR_AMBIGUOUS_ROW; they cannot fall through as positive
paths or be silently ignored.

Keeping line endings for unused-row validation prevents a Unicode line separator
from truncating a malformed annotation into an apparently valid exclusion.
Ordinary rows then use the original split-line treatment. The summary's
`unused but dirty shlib __DATA` row is not mistaken for a region. All-unused
input still raises INSPECTOR_EMPTY. No extra return schema or manifest was added;
the original raw inspector stream retains every excluded annotation.

## Actual RED and GREEN evidence

All runs used the private45s wrapper below with child/network/ctypes refusal.
The original RED used the unchanged cdb00… source and only the new test file.

| Private root suffix | Actual result | Evidence |
|---|---|---|
| `q_7nenai` | **28 failed /34 passed,0.47s**, exit1; I/O0 | All18 actual rejected rows and the whole original report fail; authored valid exclusions fail; malformed unused forms expose prior fallthrough; all-unused error classification remains old. No fixture errors were reclassified. |
| `uxr3pu8t` | **62 passed,0.10s**, exit0; I/O0 | Same unchanged tests, corrected parser only. |
| `s4iyhir6` | **502 passed /2 deselected,1.54s**, exit0; I/O0 | New62 plus original440 offline preservation. The two native_watchdog exclusions are not passes. |

Roots are under
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-`.
Original RED output is retained, not replaced by the green result.

The exact322954-byte original corpus still has SHA256
`0559751779f8c0c98bd1ef1ea40001bf5a92ae70027fd790d5ada845cbcd96c1`.
The corrected parser returns351 sorted unique ordinary paths. Compact UTF8 JSON
of that exact list has SHA256
`e63c2901f8f4ab5a79838d3ffcdd1ef0656fd72d9384c6b780cb57ead4425b35`.
None of the17 distinct unused-only paths is in that result. Individual tests
also exercise each of the18 rejected original rows. Missing/changed private
corpus fails the tests; they neither download another corpus nor silently skip.

Other tests cover exact pathless forms, horizontal field spacing, summary,
missing markers, unknown region/protection/sharing, malformed/equal/reversed or
oversized address intervals, invalid metric shapes, non-system/relative/dot/
truncated/control-bearing paths, all-unused emptiness and original PID/UTF8/size
and ordinary ambiguity refusals. These are parser and authored-transport tests,
not a new live vmmap collection, runtime-image attestation or numerical solve.

## Exact independent preservation command

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```bash
PYTHONDONTWRITEBYTECODE=1 /Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B - <<'PY'
import os,sys,signal,socket,subprocess,urllib.request,multiprocessing.process
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:v for k,v in os.environ.items() if k in ('PATH','HOME','TMPDIR','LANG','LC_ALL')})
env.update(PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1');os.environ.clear();os.environ.update(env)
counts={'unexpected_io':0}
def deny(*a,**kw):
 counts['unexpected_io']+=1
 raise AssertionError('Unexpected network, native load, or child in offline OS-preflight tests')
for owner,names in ((socket,('socket','create_connection','getaddrinfo')),(subprocess,('Popen','run','call','check_output')),(urllib.request,('urlopen',)),(multiprocessing.process.BaseProcess,('start',))):
 for name in names:setattr(owner,name,deny)
def hook(event,args):
 if event in ('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.exec','ctypes.dlopen'):deny()
sys.addaudithook(hook);signal.alarm(45);print('Private test root:',root,flush=True)
import pytest
code=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(root/'pytest'),'--tb=short','livemorebio/tests/test_osp_vmmap_format_contract.py','livemorebio/tests/test_osp_semantic_supervisor.py','livemorebio/tests/test_osp_semantic_probes.py','livemorebio/tests/test_osp_source_admission.py','livemorebio/tests/test_osp_stage_b.py','livemorebio/tests/test_osp_stage_b_analysis.py','-k','not native_watchdog'])
print('Refusals:',counts,flush=True);signal.alarm(0)
raise SystemExit(code or bool(counts['unexpected_io']))
PY
```

For the exact original/new-file repeat, select only
`livemorebio/tests/test_osp_vmmap_format_contract.py` and omit the -k pair.
The wrapper otherwise stays unchanged.

## Preserved failures and next independent gate

The original O1 remains FAILED, hash
`1bbb6d3290bbf6bcc0869341d0447f8c02aefd333ef2a9eef6397013cd45446c`.
The later diagnostic remains FAILED, hash
`4c437eaafca75f57a4063f71309d71a5ea1ef148d63dd9cde6e5ce97ce9e1112`.
Neither actual consumed private packet was rerun, patched or regraded. Their
old source-hash checks remain old; this new supervisor is not silently substituted
into those executed packets. No authorization/marker is created here.

Inspector2s, worker30s, packet600s and both production gatesfalse are explicitly
asserted unchanged. Pure12585d9b… and R3ba6559b… source hashes still match. The
maker requests independent full source/test review and repeat, not permission
to run a child. Any engineering-budget change or new OS-preflight packet remains
root's separate decision.

Lesson compounded from the investigation workflow: safe parsing must distinguish
negative unused-region annotations from positive mapped-image evidence. Failing
closed on unknown reserved forms prevents a format repair from quietly adding
dependencies or changing scientific authority. Original failed runs stay failed
even when their retained bytes later become parseable by a reviewed revision.

## Root independent review

Root read the complete changed parser and all129 new test lines, plus this report
and the pre-code amendment. Independent guarded preservation passed502 with two
native exclusions in1.64s, privatewo1hldgf/session23682 exit0, unexpected I/O0.
This accepts only the negative-row parser correction. No OS/native run was made.
The proposed timing change remains separate and is held until the current private
npm input materialization settles, because its input inventory pins this source.

Before release, separate retained-machine forensic checks from portable fixture
tests: the new corpus/receipt tests currently require private temporary paths.
They are useful local evidence, not an external tester/CI-ready dependency. Do
not solve this by silently skipping missing evidence on an external installation.
