# Observation/reconciliation registry: frozen test inventory proposal

2026-09-08. **Inventory only; root approval required before test code.** This
specializes the architecture-approved observation/reconciliation publication plan
and its independent addendum. No test, registry operation, numerical constructor,
service, browser or network request ran while preparing this inventory. Current
subjects.py is `0a8eaee99b653a1b1823a1434c2e5ff1a2d468dc9659677cb426b33f6389b465`;
server is `cedcf801a9ede06cbddcc2de75a495068a0970c6785e68f8e5d9664e67c52f18`.
The server is root-owned and outside this implementation lane. All six scientific
programs and R01–R51 remain required; these tests do not qualify physiology.

## Exact files, reuse and staging

New file: `livemorebio/tests/test_observation_committed_registry.py`, **62 cases**
below. After RED review/approval, runtime ownership is only
`livemorebio/aegle/subjects.py`: one fourth fixed transition, its direct wrapper
compatibility, and checked capture's two-action admission. RegistryAudit payload,
encryption, bootstrap, authority/manager, UI/SDK and server remain unchanged.
No new framework, generic callback transaction, action from HTTP or weaker writer.

Reuse authored `KEY`, `CAPTURED`, canonical/legacy record/replace helpers from
clinical_registry_fixtures; seed/rows/events/trigger patterns and registry-only
no-network/no-model fixture from test_committed_registry_transitions; checked
capture/confirmation, same-key authority-adoption fixture and raw reservation
assertion patterns from test_checked_startup_selection. No ASGI fixture is imported.
Fresh private SQLite only. Never import/run the four real_process bootstrap cases.

Preserve actual prepare/commit/phase owner/checked reader/encryption/witness on
normal cases. Delegated callbacks may record actual `_open`/`_seal` calls and their
durable phase metadata, not replace their values. Fault cases retain real SQLite
and use bounded delegating connection/trigger seams from the reviewed foundation.
For mutation ACK/close faults, arm from actual target/demotion UPDATE or pointer
write, not an ordinal that could strike the newly added preparation audit. Keep
the original guarded `_connect` under a delegating wrapper where applicable.
No clinical plaintext/key logging; preserve deliberately altered private bytes.

## Exact 62-case matrix

| IDs | Count | Required case and assertions |
|---|---:|---|
| A1–A3 | 3 | REAL_HUMAN observation selection with different ACTIVE source, same target already ACTIVE, and true absence. Exact1/2-row transformation, one target increment, at most one demotion, preserved payload/indexes/creation facts, frozen pointer timestamp, modeless selection mode. Preparation audit inspect then mutation select_observations, each BEGIN/result with same UUID and distinct event IDs. |
| A4 | 1 | Full prepared value is immutable/detached and pure after its audited read: exact bounded rows/pointer/token, target and active snapshots, no clinical write or constructor; inherited `_audited` is trapped so the fixed phase owner is required. Record durable BEGIN before each of at most two opens and completed preparation before returning. |
| B1–B5 | 5 | Invalid expected versions True,1.0,0,MAX_SAFE_INTEGER,MAX_SAFE_INTEGER+1 reject before storage through new method and direct wrapper. Exercise the pure helper's safely incrementable domain too, without I/O. Existing broader coercion matrix remains preservation. |
| B6–B7 | 2 | SYNTHETIC and REFERENCE_GROUNDED_SYNTHETIC targets reject observation-only admission without invoking numerical admission; audit the read, no clinical changes. |
| B8–B9 | 2 | Orphan ACTIVE row/no pointer and second ACTIVE row reject without unbounded decrypt/repair. Existing missing/inactive/wrong-type/index-corruption permutations remain foundation tests. |
| B10 | 1 | Different selected row at stored MAX cannot be demoted; preserve target/pointer/old row, even with a valid target request version. |
| B11 | 1 | Target at MAX-1 selects to exact integer MAX; a subsequent mutation at MAX rejects. No unsafe successor or rounding. |
| B12 | 1 | Malformed request UUID rejected before `_connect`; existing full UUID invalid-value matrix remains preserved. |
| C1–C3 | 3 | After full preparation, independently change target authenticated payload at same version, old selected payload at same version, or pointer timestamp. Final actual commit conflicts before mutation and preserves the external edit. |
| C4 | 1 | Legitimate same-key bootstrap adoption after preparation rejects stale authority before protected commit decryption; fresh operation may capture new authority. |
| C5–C7 | 3 | Forged full prepared after-values: extra target evidence edit, incorrect demotion timestamp/field, and boolean/numeric alias. Independent canonical transformation validation rejects before mutation, not just dataclass type/equality. |
| D1 | 1 | Exact persisted final commit with lost ACK confirms once with actual witness, without resealing/repeating the two-row transition. Audit actions remain inspect then select_observations. |
| D2–D8 | 7 | Independently disturb each witness class after persisted ACK loss: target row, demoted row, pointer timestamp, mutation BEGIN, terminal, reservation absence, ACTIVE topology. Every case remains SELECTION_COMMIT_UNCONFIRMED; preserve actual durable edits and damaged evidence. |
| D9–D10 | 2 | Confirmed rollback retains original clinical state plus failed select_observations audit; unconfirmed rollback retains the primary uncertainty/pending reservation even if real close later rolls back. |
| D11–D12 | 2 | Confirmed close ACK failure with normal commit and with exact lost-ACK witness yields COMMITTED_CLEANUP_UNCONFIRMED, never rollback or repeated write. |
| D13–D15 | 3 | New mutation action still uses full phase protection: reservation deleted after durable BEGIN rejects before decrypt; terminal trigger changing the demoted row rolls back; failure completion protects a newly live selected row introduced by the independent writer after rollback, without extra clinical decrypt. Keep raw before/after and pending evidence. |
| E1–E3 | 3 | Direct compatibility: valid legacy preparation with different selected source and supplied UUID; same-target legacy preparation with generated UUID; no supplied preparation/default UUID. Preserve valid legacy timestamp and exact returned target; use that same timestamp for every demotion/pointer. New full audited capture supplies current raw authority. |
| E4–E8 | 5 | Legacy prepared forgeries: successor version as2.0, mapping_eligible True replaced by1, extra evidence change, invalid timestamp, malformed original digest. Canonical typed comparison rejects clinical mutation, not merely Python dict equality. |
| E9 | 1 | A legitimate old pure preparation followed by a same-version authenticated target edit rejects the stale digest after fresh audited capture; preserve that edit. Existing advanced-version stale test remains preservation. |
| E10 | 1 | Pure standalone preparation stays side-effect-free and detached with its existing return type; it is not presented as a raw ciphertext/pointer authority capture. |
| E11 | 1 | Direct wrapper routes through actual fourth-kind commit and turns confirmed storage-close failure into the existing typed committed-cleanup exception, not a successful dict or presumed rollback. |
| F1–F3 | 3 | Checked reconcile_selection capture/confirmation for SYNTHETIC at stored MAX, REAL_HUMAN at stored MAX, and true absence. Same UUID, two distinct reconcile_selection access pairs, exact clinical/index bytes unchanged; inclusive MAX is readable, never incremented. |
| F4–F8 | 5 | Checked action invalid None,list,bool,str-subclass and fixed disallowed select_observations rejected before access. Require exact str plus inspect/reconcile_selection, no general audit-action forwarding. |
| F9 | 1 | Default checked startup capture remains inspect; confirmation remains reconcile_selection. Existing default dict signatures/false flag and startup tests remain preservation. |
| F10–F11 | 2 | Capture with new reconcile_selection action then pointer-timestamp change or authority adoption: actual checked confirmation conflicts, no clinical mutation or recovery return. |
| F12–F13 | 2 | New-action checked capture loses terminal commit ACK after actual audit commit, or close ACK after actual close: no returned checked capture, fixed safe storage error, original clinical bytes. Existing full before/after ACK matrix remains foundation. |

Totals: A4 + B12 + C7 + D15 + E11 + F13 = **62**. Do not silently expand the
matrix to every input × source × fault combination. No actual model build is
permitted for any source class. Callback counters and bounds must assert the
intended phase was reached; an earlier rejection is not evidence of later safety.

## Two explicitly requested inherited-test migrations

These are required preservation fixes, not permission to delete old tests. They
need root's explicit approval alongside the new-file inventory:

1. In `test_checked_startup_selection.py`, the existing three-value forbidden-
   action parameter list includes reconcile_selection. Replace **only** that now-
   allowed value with select_observations and rename the inspect-only test to the
   reviewed-action allowlist. Keep all three before-I/O rejection assertions and
   counts. The now-valid value receives positive F1–F3 coverage; do not skip it.
2. In `test_clinical_descriptive_registry.py`,
   `test_selection_success_audit_failure_rolls_back_both_subjects` currently faults
   every SUCCESS audit. A new direct-wrapper preparation would make that test pass
   before any mutation. Arm its existing failure only when its actual writer
   transaction contains the prescribed updated target and demoted old row;
   assert exactly one such mutation-phase failure. Retain all original exception,
   raw rollback and selected-pointer assertions. No ordinal-based preparation hit.

The original expectation was that the old lost-commit test already armed on
pointer INSERT/UPDATE and needed no change. The actual preservation run disproved
that expectation; see the retained discovery and approved correction below.
No other inherited test edit is proposed. Unexpected preservation failures must
be reported and their actual phase reviewed before any fixture changes.

## RED expectations, preservation and execution gates

Before runtime code, run only the new62 cases once at the pinned subjects source.
The fourth method is absent, so many failures should be missing-contract RED;
checked reconciliation action is currently refused. Some strict admission/direct
legacy/default-action controls may already pass. Report actual fail/pass/setup
counts and the earliest reached boundary; do not call all62 new behavior or claim
later fault assertions executed when setup stopped. Preserve the original result.
Make the two mapped inherited-test changes only at the reviewed implementation/
preservation stage, not to manufacture an initial baseline failure.

After root reviews RED and authorizes implementation, repeat the same62, then the
exact previously reviewed616-case foundation from the checked-selection report:
checked startup selection, committed registry transitions, audit contract,
bootstrap contract/shape, clinical descriptive registry, real cohort contract,
legacy reconciliation registry, and its four explicitly listed inert lifecycle
nodes. Keep the four real_process cases excluded and identified, not passed.
The two mapped migrations preserve foundation case count; combined expected
selection is678 with4 explicit exclusions, subject to actual collection evidence.

Use the existing private registry-only wrapper with OS audit-hook refusal for
socket construction/connect/DNS, fork/exec/spawn/Popen and multiprocessing start;
urllib refusal, no compilation/physiology and no auto-loaded plugins/bytecode/
pytest cache. Use the pinned fresh Python already used by root and a60-second
alarm for each registry-only packet. No ASGI socketpair is required here. Capture
private root, exit/time, frozen hashes and zero unexpected I/O; refuse optional
exact Git metadata into its existing fallback. Do not run services or benchmarks.

Root independently reads/repeats the frozen registry implementation; its maker
does not grade it. UI owns the separate ASGI test inventory and root owns server
publication. Actual encrypted-registry→route and ordinary UI/terminal acceptance
remain subsequent scoped gates, not inferred from this registry packet.

## Root inventory approval

Root read all126 original lines against the approved architecture and reviewed
the two mapped inherited-test seams. The62-case new-file RED stage is approved.
The two inherited migrations are approved only after the retained initial RED,
at the implementation/preservation stage: replace the newly allowed action with
the specified disallowed action, and keep the audit-failure test aimed at the
actual mutation rather than the preceding preparation. No other inherited test
change is authorized. Report unexpected failures before adjusting fixtures.
Runtime authoring still follows review of the frozen RED evidence; no browser,
native worker, service or operational store is authorized by this inventory.

## Preservation discovery: proposed exact lost-ACK fixture migration

The first implementation foundation run reached 677 passed, 1 failed and 4
explicit real_process exclusions. The retained failure is
`test_uncertain_selection_commit_is_distinct_from_rollback`: its pointer-write
detector requires the literal active_twin_id in the SQL statement. The reused
prepared owner binds that key in its exact three-parameter registry_state INSERT,
so the detector did not arm and no lost acknowledgment was injected. The earlier
claim above that this inherited test needed no migration was incorrect.

Pending root approval, preserve the old literal form and additionally match only
the prepared owner's exact pointer INSERT statement and parameters[0] equal to
active_twin_id. Count exactly one pointer write, one commit-then-raise fault and
one denied witness connection; keep the existing uncertainty code and retained
version2 assertions. This changes only the test's fault placement, not the
subject writer, outcome classifier or audit semantics. Preserve the original
failure and do not apply this third inherited migration without approval.

Root subsequently read the discovery and approved exactly this third migration:
keep the old literal detector and additionally match the exact prepared-owner
parameterized INSERT with the active_twin_id first parameter. Assert the arm,
persisted mutation commit and denied recovery-read counters are each one; preserve
the existing uncertainty code and version2/no-repeat behavior. No runtime change
or other inherited-fixture expansion is authorized by that approval.
