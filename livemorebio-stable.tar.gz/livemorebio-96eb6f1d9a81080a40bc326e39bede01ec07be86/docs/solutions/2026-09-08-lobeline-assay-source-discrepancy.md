# Lesson: retain source-parameter inconsistency at the assay boundary

The approved correction-first plan selected one executable nonhuman assay rather
than inventing plant-to-human kinetics. Lobeline–VMAT2 exposes a useful failure
mode: published functional Ki and control Km predict a different apparent Km from
the same publication's inhibitor kinetic analysis.

## Decision

Implement the original competitive initial-rate equation and freeze the minimal
source/model record alongside every result. Keep nominal assay concentration as
the native axis. Preserve the numerical discrepancy and explicitly missing raw
replicates/covariance/acceptance criteria. Do not refit the parameter, sample SEM as
human variability, or animate the concentration grid as elapsed time.

## Reusable rule

Matching a publication's mechanism classification is not equivalent to reproducing
all of its quantitative estimates. A mismatch belongs in the executable output,
not just a disclaimer. Scientific qualification must remain unavailable until a
separately governed physical comparison exists.

## Implementation and tests

The new module is independent of live twin/runtime state. The schema excludes
patients, cohorts and unknown fields, normalizes explicit nM/uM inputs, rejects
coercion and out-of-domain conditions, and retains material/preparation identity.
History binds original inputs and source digest. An exact rerun refuses source
changes; acknowledged new configurations retain immutable parent lineage.
CSV and executable notebook use the same frozen result. The notebook independently
recomputes the equation and discrepancy without calling the live platform.

Red tests demonstrated missing equation module, workflow dispatch and terminal
commands before implementation. The focused equation/workflow/client suite passed
46 checks. The combined focused plus existing protocol/research regression suite
passed 141 checks. Independent review and full browser QA are separate release gates owned
by the root task, not implied by these unit-test results.

The Compound Engineering tool and gbrain are unavailable; this durable local entry
is the fallback capture, not a claim that those tools ran.

See [scientific contract and usage](../LOBELINE_VMAT2_PROTOCOL.md) and
[approved build plan](2026-09-08-measurement-integrity-atlas-build-plan.md).
