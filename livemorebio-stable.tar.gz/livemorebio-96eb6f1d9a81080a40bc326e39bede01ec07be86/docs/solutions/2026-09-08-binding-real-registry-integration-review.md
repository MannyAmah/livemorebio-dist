# Actual registry-to-binding wiring: test-author handoff

2026-09-08. **Maker evidence only; independent root review remains required.**
The approved13-case plan was read and root approval appended before test code.
Created only `test_checked_binding_registry_integration.py`; no runtime or frozen
test was edited. This does not close R01–R51, qualify hardware/physiology, replace
browser/terminal acceptance or advance the six experiment programs.

## First actual result and frozen source

**13 passed, 3 existing warnings in2.17s**, exit0. Private review environment:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-e5irt5nx`.
Unexpected network/child/model attempts: **0**. Optional exact Git metadata lookup
was refused once. No service, native model, browser, external HTTP or operational
store was used. TestClient's internal socketpair and authored private SQLite were
the only local integration facilities. The alarm was cancelled after completion.

These are new integration checks against the already corrected binding route,
not a new RED→runtime-change claim. Preserve the original25 binding failures and
35 authored boundary failures in the earlier packet. No failing integration
result or discovered runtime defect was concealed or corrected in this packet.

| File | SHA256 |
|---|---|
| new test,434 lines | 4e9b8a45ac614bc5db8f9134e7f152b9e1964a9c8b14c48c7190fc5437b01489 |
| server.py | 3d521a029bccf5d9069a4e78806d40fbf895aca3b3cf6b6f370ad9500645676d |
| subjects.py | 0a8eaee99b653a1b1823a1434c2e5ff1a2d468dc9659677cb426b33f6389b465 |
| registry_audit.py | b21f01fdf1c79604c5565fee0f7d94d3b0bd11967b199bc97ec8a193de045e4e |
| execution.py | 2caafc14925604e3ad3e194c3c668a7cf41eb83eb5fea3afa619bf897c277aac |
| approved plan plus root precision | 2ac63155d5bf08e0037ff96a5966bae24488b51ebd9f9beb35647db110785379 |

## What the actual tests exercise

The actual registry getter creates the private encrypted store with the public
test key. Real prepared records, phase audit, encryption, commit and exact
read-only acknowledgment witness produce every result. Protected method
identities are asserted before and after each test. The real source authority,
no-background manager and shared snapshot helper remain in use. Only inert model
state and record-only bus sinks stand in for numerical/file-backed consumers.
The execution store has no owners, adapters or background worker.

The13 cases cover READY virtual, modeless physical metadata-only and unselected
virtual success; two real external same-version/pointer changes; confirmed
rollback; exact lost-ACK confirmation; damaged terminal selected/unselected;
unconfirmed rollback; confirmed-close acknowledgment selected/unselected; and
unauthorized admission. Physical metadata retains PAIRING_RECORDED and
PENDING_SIGNED_ENVELOPE. There is no signed telemetry, attestation/hardware
verification, calibration, watermark or clinical qualification claim.

Fault cases delegate to original guarded `_connect` and real SQLite, arming only
after the binding's actual target UPDATE, never a preparation-audit commit ordinal.
They count one mutation attempt and one target UPDATE. Lost ACK invokes real
commit before raising; real witness checks decide confirmation. Damaged terminal
rows are not repaired or decrypted after corruption. Unknown rollback leaves its
pending mutation BEGIN/reservation intact even after close actually rolls back;
the route correctly remains uncertain. Close-ACK faults perform the real close
before raising. No process-kill, fsync, power-loss or OS ownership claim follows.

Audit checks preserve the raw old prefix and correlate each new event with the
response UUID, exact target/schema/action/store and bounded fixed fields. Saved
fixture records are decrypted independently with the actual AAD rather than an
extra public getter that would add unrelated access events. Raw unrelated rows,
pointer, identifier index and creation/idempotency fields remain unchanged except
for the explicitly selected interference or physical-index write. Source/fence,
holder identity, snapshot and fail-closed API assertions are connected to these
actual retained outcomes, not stubbed commit labels.

Root-approved observation qualification: success/interference cases retain the
actual `_connect`. Completed preparation audit plus independent BEGIN IMMEDIATE /
rollback confirms release of its writer lock, **not an observed close syscall**.
Dedicated helper tests retain the close contract; fault wrappers directly count
their delegated closes. Audit counts are not claimed as a new independent proof
of every decryption boundary. Existing exact phase-order tests remain relevant.

## Exact bounded repeat

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os, sys, signal, socket, subprocess, urllib.request, multiprocessing.process
from tools.run_review_stack import prepare_review_environment
review_root, env = prepare_review_environment(inherited={k: os.environ[k] for k in
    ('PATH', 'HOME', 'TMPDIR', 'LANG', 'LC_ALL') if k in os.environ})
os.environ.clear(); os.environ.update(env)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
blocked, metadata = [], []
def deny(*args, **kwargs):
    blocked.append('unexpected')
    raise AssertionError('Review forbids network and child/native work')
def process(command, *args, **kwargs):
    if command == ['git', '-C', '/Users/emman/Livemore/.worktrees/full-scope-recovery',
                   'rev-parse', '--show-toplevel']:
        metadata.append('refused')
        raise OSError('Authored unavailable Git metadata')
    return deny()
def audit(event, args):
    if event in {'os.fork', 'os.forkpty', 'os.posix_spawn', 'os.exec',
                 'subprocess.Popen', 'socket.connect', 'socket.getaddrinfo'}:
        deny()
sys.addaudithook(audit)
multiprocessing.process.BaseProcess.start = deny
for name in ('bind', 'listen', 'connect', 'connect_ex'):
    setattr(socket.socket, name, deny)
socket.getaddrinfo = socket.create_connection = deny
urllib.request.urlopen = urllib.request.OpenerDirector.open = deny
subprocess.Popen = process
import pytest
class InertReview:
    @pytest.fixture(autouse=True)
    def no_models(self, monkeypatch):
        from livemorebio.tests.clinical_registry_fixtures import forbid_compilation
        from livemorebio.aegle.runtime import AegleTwin
        from livemorebio.engines.metabolic.glucose_insulin import MetabolicProfile
        forbid_compilation(monkeypatch)
        monkeypatch.setattr(AegleTwin, '__init__', deny)
        monkeypatch.setattr(MetabolicProfile, '__init__', deny)
signal.alarm(45)
print('PRIVATE_REVIEW_ROOT', review_root, flush=True)
rc = pytest.main(['-q', '-p', 'no:cacheprovider', '--tb=line',
    'livemorebio/tests/test_checked_binding_registry_integration.py'], plugins=[InertReview()])
print('REVIEW_IO_COUNTS', len(blocked), len(metadata), flush=True)
signal.alarm(0)
raise SystemExit(rc)
PY
```

Compound lesson: distinguish the real durable outcome from the operation's
knowledge of it. A real binding can be durable while the exact audit witness is
damaged, and a later real close can roll back while the route never received a
trustworthy rollback acknowledgment. Integration assertions must preserve both
the raw store evidence and the conservative source fence, without relabeling
uncertainty as success or confirmed rollback.

## Root independent grade

Root read the complete approved plan, all434 new test lines, source transaction
and publication boundaries, and this full maker report. No actionable defect
was found in this bounded integration increment. Root's independent repeat of
the exact13 tests passed in2.20s,3 existing deprecation warnings, private suffix
`p6nzjyya`, exit0. The45-second isolated ASGI wrapper refused all unexpected
network/child/model work:0 attempts, one exact refused optional Git lookup.

The actual prepared-registry-to-binding integration boundary is CLEAR. This
does not imply native model, signed device, browser or terminal acceptance.
The original method identities are checked by each fixture; final test/source
hashes remain those above. All uncertain/damaged-store assertions were retained
without repair. The user-facing pairing and independent physical qualification
requirements remain open, as do preview/observation-selection/reconciliation and
the complete R01–R51 recovery register.
