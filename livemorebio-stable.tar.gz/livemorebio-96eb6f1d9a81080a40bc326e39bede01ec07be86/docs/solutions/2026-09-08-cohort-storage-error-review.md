# Cohort storage-error adapter — implementation and review

Status: maker verification and bounded independent review complete. This is a narrow
part of R15/R20/R47/R48, not full product acceptance. Plan: the final addendum in
`2026-09-08-reference-cohort-registry-authority-plan.md`, reviewed before code.

## Change and preserved behavior

The legacy cohort list/detail routes now return the existing fixed
`REFERENCE_STORAGE_UNAVAILABLE` 503 response, with `Cache-Control: no-store`, for
bootstrap/audit/key-unavailability/SQLite/decryption/OS failures. This includes a
late public-cohort projection failure: no partial successful list escapes.
Authentication still precedes registry access. Typed domain404/409/422 responses
are preserved and explicitly no-store; unexpected programming failures remain500.

`_subject_registry()` uses private `_RegistryKeyUnavailable(RuntimeError)` for
its known missing-key failure, retaining the exact fixed message and former catch
hierarchy. Independent pre-code review identified why `RegistryBootstrapError`
would be wrong here: it inherits ValueError and older consumers could misclassify
storage failure as invalid payload. A regression test proves RuntimeError, not
ValueError, and observation selection's existing503 behavior.

No key recovery, schema migration, source selection, model binding, cohort
eligibility, numerical constructor or physical-device behavior is changed. Other
server changes inherited from this recovery build are preserved, including the
independently reviewed Cendos current-source fencing. Reference-cohort transaction
authority is a separate concurrent implementation lane.

## Red/green evidence

All commands used the isolated review runner and authored temporary stores, with
socket connect/connect_ex, DNS/create_connection and both urllib entry points
refused in the new packet. Numerical constructors are prohibited. ASGI clients do
not start lifespan handlers. No running service, existing registry or person data
was used.

- Initial42 tests: **32 failed,10 passed**,1.45s; private root
  `livemore-research-review-nxyneo7y`.
- Added type-hierarchy regression: **1 failed,42 deselected**,1.34s; private root
  `livemore-research-review-7zzbs7t_`.
- First corrected43 plus preserved74 Cendos checks: **117 passed**,3 warnings,
  1.86s; private root `livemore-research-review-ypl4qosd`.
- Final51 plus74 Cendos plus32 scientific-integrity checks: **157 passed**,
  3 warnings,3.59s; private root `livemore-research-review-85jfnm35`.

Final command, from this worktree:

```text
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B tools/run_review_tests.py livemorebio/tests/test_cohort_storage_errors.py livemorebio/tests/test_cendos_current_source.py livemorebio/tests/test_cendos_source_transport.py livemorebio/tests/test_scientific_integrity.py -q --tb=line -p no:cacheprovider
```

The final51 include30 acquisition/read/late-projection storage cases,2 auth-order
cases,6 SubjectRegistryError status cases,2 unavailable-key cases,1 hierarchy and
observation-selection case,2 unexpected-programming-error cases,2 actual private
registry corruption cases, and6 ReferenceCohortError status cases. The actual
corruption cases preserve record ciphertext, audit and key bytes and prohibit
decryption. Deprecation warnings concern FastAPI startup and TestClient APIs, not
failed assertions. `git diff --check` is clean.

Frozen SHA-256:

| File | SHA-256 |
|---|---|
| livemorebio/aegle/server.py | 5bebe9ad9a7a038f53f90ff9bc9d778f863bfc796ecf4c312081c620670e56e7 |
| livemorebio/tests/test_cohort_storage_errors.py | 5f47252c5c2ca08656a2920cbe7d6ab6f9cfa1c38abb93253ea80f52860b050f |

## Limits and lesson

This does not prove browser behavior, six experiment execution, healthy human
equivalence or product release readiness. Remaining transition, LIFE and Atlas
work is retained in the master register. No commit/push/deployment occurred.

Lesson: an error adapter is part of the public contract, but its internal base
class also matters. A more specific-looking error can unintentionally enter an
older ValueError payload handler. Test both inheritance and every affected public
classification, then verify that partial collection projection cannot appear as
successful data.

## Independent review — 2026-09-08

The independent reviewer read the approved adjacent-adapter addendum, this report,
the complete51-case test module, both route bodies, the existing failure adapters,
and the key-error consumers. Both frozen SHA-256 values above matched before and
after review. The narrow change retains RuntimeError compatibility without entering
ValueError payload handlers; authentication occurs before registry access; the
complete list projection must succeed before a response is constructed. Storage
failures use the fixed503/no-store response, domain404/409/422 retain their types,
and unexpected programming exceptions are not reclassified as storage failures.

Independent execution of the same four-module packet: **157 passed,3 warnings in
3.10s**, using the installed Python3.11 interpreter with a fresh
`prepare_review_environment()` root, `PYTHONDONTWRITEBYTECODE=1`, `-B`, and
`-p no:cacheprovider`. Retained private root:
`livemore-research-review-y8gr4ujp`. Socket connect/connect_ex, DNS,
create_connection, urllib.urlopen and urllib.build_opener were refused before
test collection except each test's explicit in-memory transport interception.
The51 adapter cases additionally prohibit numerical constructors and do not enter
ASGI lifespan. No browser, running service, native solver, operational store or
real participant data was used.

The actual authored-corruption cases passed for both routes: retained registry
authority damage rejected access before decryption and preserved record,
audit and key bytes. No actionable blocker was found in this bounded adapter.
This is not acceptance of the separate reference-cohort transaction-authority
implementation, source transitions, browser workflows or broader product scope.
