# Atlas terminal failure: retained evidence and smallest next check

2026-09-08. **Proposal only.** No source, harness, browser, service, cache or
test execution is authorized by this document. The full Atlas matrix remains
**28 PASS / 3 FAIL / 25 NOT_RUN**. The later ordinary presentation result does
not replace that matrix or resolve its transport/performance failures.

## Recovered evidence

The full diagnostic amendment, attempt-2 results, remaining dependency proposal,
original request reader/loader and diagnostic consumers were read. Local pinned
Playwright 1.58.2 client, Chromium network adapter and protocol declarations were
inspected without a browser or HTTP request. No available gbrain/CE tool was
found; neither is claimed as invoked.

| Retained artifact | Exact SHA256 / result |
| --- | --- |
| `docs/screenshots/full-scope-recovery/atlas/diagnostic-1-gLkFxF/browser/atlas-request-diagnostic.json` | `9c44a713a51a8de0b5a11bc09b60cb31946644954235c0204bcca81a67297b02`, deadline, not acceptance |
| `docs/screenshots/full-scope-recovery/atlas/attempt-2-FRpGPo/browser/atlas-browser-evidence.json` | `ee03891e48e1416ddc7a84a29a1435b8ce6aeaae9dfc00b5cdf7ca492846f69b`, overall FAILED |
| Current `atlas_reference_requests.js` | `7ad7c023571614635d196cc5b0638d195ae46b166ce4602be16eb87e4cf4b9bc`, exactly the diagnostic's original reader |
| Existing `tools/check_atlas_request_diagnostic.cjs` | `5d94aa9460bdae62ac7ec77fe4a81cb7e0d036f46d483083858d5f65bca318cd`, unchanged |

Diagnostic 1 recorded one factory, zero dispose calls, nine original promises
resolving exactly 24,779,652 bytes, maximum two internal application loads, and
skin resolution 34.1 ms before internal starts. All nine response/header checks
passed. Skin, heart, liver, right lung and brain nevertheless emitted
`ERR_ABORTED`; their completion-promise waits reached the 90-second deadline.

The current ordinary receipt is
`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-atlas-presentation-hsfd6dss/presentation.json`,
SHA `f9e5080872a84fa2a9da48d9f21b4521591bebba5c9568b0c7c89fdd2e1c90d4`.
It retains five failures: skin, heart, liver, **right kidney**, brain. Right lung
is not in this newer failure list. Its source is `bdbcc43b5712459b8a1d09cecdc817e1fc378447df6230d929cd111281cd4de6`,
Chrome 153.0.8010.36 / Playwright 1.58.2 / SwiftShader. The manifest and original
installation receipt are unchanged. Nine loaded layers, 20 presentation cases
and settled cleanup do not upgrade these failed terminal events to success.
This variation also does not support a fixed failing-asset or byte-size rule.

## What is established, and what is not

1. The old collector's indefinite wait is explained. Pinned
   `client/browserContext.js::_onRequestFailed` records failure/end timing but
   does not settle `Response._finishedPromise`; `_onRequestFinished` does.
   `client/network.js::finished` waits on that promise or target close. Waiting
   for it before resource collection prevented collection from being reached.
2. Failure-side `request.timing().responseEnd` is populated from the terminal
   failure timestamp by `crNetworkManager.js::_onLoadingFailed`. It is **not**
   evidence of successful transfer/body completion. Missing sizes remain null.
3. The original loader resolves only after EOF, exact length, reader cleanup,
   SHA verification, and final disposed/abort checks. Its `finally` clears the
   timer and removes the controller before fulfillment. Combined with nine
   resolutions and dispose count zero, diagnostic 1 does not support controller
   disposal or the 30-second timeout as the cause of those failed loads.
4. The reader unconditionally calls `reader.cancel()` after EOF. Its presence
   alone is not proof that it aborts a completed browser transfer. The current
   technical fake reader increments a cancel counter after done; that fixture
   cannot establish native browser stream cancellation semantics.
5. Existing artifacts lack reader/abort lifecycle and raw protocol canceled /
   blocked fields. They do not establish whether the remaining failure belongs
   to reader cleanup, browser networking/interception, or a scheduling-dependent
   boundary. No reader fix, cancellation removal, threshold change or successful
   transport classification is justified yet.

## Proposed single discriminating microcase, not another full load diagnostic

Reuse the existing diagnostic module's source/hash checks, fixed asset metadata,
safe collector, same-promise application observer and 90-second total budget /
five-second owned cleanup. Do not repeat its nine-layer workspace load or any
completed presentation cases. After independent code review and explicit run
authorization, perform **one skin GET** using the exact unchanged reader on an
owned blank diagnostic document. Skin is the common failed first load across
the retained attempts. The single case removes the scene, controller, internal
worker competition and GPU work from the request under examination.

The private fixed diagnostic-document route is fulfilled once by the harness,
not added to the product. It imports only the normal original request module
and its fixed contract dependency from the source-pinned service. No product
module rewrite, fetch/reader prototype patch, response substitution, source-byte
copy, GLB parsing, extra model, or clinical state access. The original factory's
existing `fetchImpl` option may attach a bounded read-only abort listener to its
provided signal and must return the **same native fetch promise**. It must not
wrap/replace the Response, stream, reader, byte chunks, or cancel implementation.

Add only the missing observer fields: first signal-abort timestamp/boolean;
existing original-promise result; read-only Chromium `Network.loadingFinished`
or `Network.loadingFailed` for the one exact asset, including original monotonic
timestamp, safe error enum, `canceled`, safe blocked/CORS enum, resource type,
and encodedDataLength only when actually supplied. Map its protocol request ID
from the exact fixed URL to local sequence 1; never retain arbitrary headers,
URLs, cookies, initiator stack, body bytes or unrelated protocol events. No CDP
Fetch commands or interception changes are introduced.

The collector must settle on either finished or failed and then collect the
already-created fixed `PerformanceResourceTiming` row, without waiting on
`response.finished()`, reading a body, or refetching. Missing/duplicate rows,
unsettled terminal events or disagreeing observers remain explicit uncertainty.
Use the same fixed route firewall; no CDN exception or redirect following.

Interpretation is preregistered:

- Original buffer resolves, no abort, protocol FAILED: reproduces below the
  Atlas controller/renderer; narrows the next investigation to the unchanged
  reader/browser/interception boundary, **not proof that cancel caused it**.
- Actual signal abort before fulfillment: records a cancellation branch to
  explain before any production change; no timeout/cancel success claim.
- Protocol FINISHED but Playwright FAILED: observer/adapter disagreement remains
  explicit and becomes the next source-level target.
- Both finish: this one stripped-down case did not reproduce. It cannot clear
  the old failure or authorize repeated sampling. Stop and review the narrower
  workload difference, rather than rerun automatically.

Before implementation, root must approve this small extension and its exact
fresh stack/source/process setup. Reuse the ordinary supervisor's fresh private
observation-only technical fixture and preserved public Atlas directory if a
service is needed; never revive/write an old private registry or install assets.
All preflight/final identity, no-mutation, cache and owned cleanup gates remain.
No graphical screenshot or warm-performance acceptance is claimed by this case.

Red-first guards must prove one asset GET, exact module/route and no unknown
requests; native promise identity and no extra reader calls; terminal failure
settles without `response.finished`; no missing metric becomes zero; bounded
CDP mapping/sanitization/listener disposal; partial evidence before deadline;
late allocation cleanup and no further case after any identity/cleanup failure.
No actual microcase, test or source edit has been run in this read-only review.

## Exact harness amendment submitted for root review

Root approved red-first harness-only implementation in principle, with this
setup/entrypoint/budget refinement written before code. It remains pending root
read of these details. No actual invocation is authorized. Baselines are the
existing diagnostic SHA `5d94aa9460bdae62ac7ec77fe4a81cb7e0d036f46d483083858d5f65bca318cd`
and ordinary Python supervisor SHA `95c2d4c25ad45dfcae109f9348d0600d5b78aa7046b537b43a84acc40ef4afcf`.

### Files and invocation

- Add a closed choice to `tools/check_atlas_presentation.py`:
  `--check presentation|skin-terminal`, default `presentation`. It chooses only
  two fixed checked-in Node entrypoints, never a user-supplied command/module.
- Presentation mode keeps its current config, command, 190-second Node ceiling,
  20 cases, 33 captures, result labels and supervision semantics unchanged.
- Skin mode launches the existing `tools/check_atlas_request_diagnostic.cjs`
  with `--skin-config <new-private-root>/browser-config.json`. It records
  `check_kind: skin-terminal`, diagnostic-only scope and `full_acceptance:false`.
  It does not run the old no-argument nine-layer diagnostic. That old entrypoint
  and exported test defaults retain their pinned c9 behavior and original
  failure history, but are not authorized for execution here.
- Add dedicated tests in `test_atlas_skin_terminal_diagnostic.py`; extend only
  relevant existing diagnostic/supervisor tests where preserving old defaults
  requires it. No presentation CJS, source module, renderer, server, parser,
  registry, launcher or vendor edits are included.

The proposed eventual root command is the pinned Python interpreter with
`tools/check_atlas_presentation.py --check skin-terminal --output-parent <existing-absolute-private-parent>`.
This is an interface description, not a run instruction or permission to run.

### Private setup and identity

Both modes reuse the existing supervisor's free-port check on 8910–8912,
unique owner-private output/data root, fresh credentials, authored software-only
REAL_HUMAN-shaped observation selection, three normal service modules and fixed
preserved public anatomy directory. The fixture is still explicitly not a
participant, version 2, UNAVAILABLE/MODEL_BINDING_REQUIRED, observations-only.
There is no default healthy constructor, experiment, borrowing of old private
stores, old process reuse, installer or conversion. Keep the actual setup/startup
constructor-denial regression; a source change that invalidates it blocks a run.

Use the normal current source fingerprint, all three actual process identities
and start times, fresh fixture identity, context hash and source generation, not
the old diagnostic's c9 constants. Normal source/health checks plus all 16 cache
hashes/sizes/mtimes are retained before/after. The original manifest and receipt
remain fixed. The request module must still hash to `7ad7c023...` in full as
recorded above before any browser launch and after collection.

Reuse the presentation CJS's import-safe config/workspace/Atlas validators and
the existing build validator, without invoking its main function. Private
config validation requires regular single-link owner-private file and parent,
an exact mode marker and unchanged fixed base/manifest/receipt/fixture contract.
Reject missing, foreign, malformed or presentation-mode config before launch.
Add optional validated identity parameters to the existing diagnostic collector
and resource mapper only where they currently close over old PIN; old callers
retain their exact defaults. Do not mutate the shared PIN object.

### Browser/document/request sequence

1. Start the one monotonic observation budget; validate config and local hashes;
   verify the installed gstack Playwright package/Chrome runtime pins. Launch
   only its own headed Chrome/SwiftShader instance and fresh context, no shared
   browser/profile. Register owned allocations before awaiting completion.
2. Install a fixed firewall under the same budget. Run the existing native
   blank-tab visibility preflight. Perform exactly one fixed bootstrap GET
   requiring 204; fixed identity metadata GETs require 200 and `maxRedirects:0`.
   The API request helper has its own endpoint whitelist because context.route
   does not cover APIRequestContext. No response body outside metadata JSON is
   read by Node.
3. Fence build/services/observation-only workspace/Atlas status before asset
   work. Select only skin's exact manifest row: 4,901,056 bytes and digest
   `e8a0c3f0897783fdb2c9bad9fe020c287ae8913a45f88bd7cd4ae47e8b628f0a`.
4. Navigate to one fixed harness-only document at
   `/__atlas_request_probe__/skin-terminal-v1`, fulfilled once with recorded
   static HTML/hash, restrictive same-origin CSP and a non-network empty icon.
   It never imports the workspace shell, controller or scene. Permit only this
   exact document, `/lib/atlas_reference_requests.js`, its
   `/lib/atlas_reference_contract.js` dependency, and the one exact skin GLB URL.
   Fixed metadata reads occur only through the checked API helper. Reject other
   methods, queries, redirects, origins, modules or a second skin request.
5. Attach request/response/terminal listeners and a private read-only CDP session
   before the load. Only `Network.enable` and event observation are used; no
   Fetch-domain command, response rewriting, body read or network setting change.
   Import the original module normally and call its factory/load once. The
   existing same-promise application tracker wraps that load without changing
   its promise/value/error identity.
6. The supplied fetchImpl validates the exact GET/options, attaches one abort
   listener to its actual signal and returns exactly the native fetch promise.
   It does not introduce an async return wrapper, access/replace a Response or
   stream, call another read/cancel, or change the source's 30-second timeout.
7. Wait for application settlement and either terminal event, then collect the
   single existing resource-timing entry and repeat source/context fences. A
   failed terminal is a collected failure, never a successful transfer. No
   `response.finished()`, `request.sizes()` wait, body fallback, additional load,
   idle sleep, internal-layer run, controls or screenshots occur.

### Bounds, terminal evidence and cleanup

The new Node branch has one **90,000 ms** observation deadline beginning at
entry, before config I/O, local source checks or browser acquisition. Every
awaited setup, route registration, metadata read, visibility operation, CDP
allocation/enable, load/terminal/resource collection and final fence consumes
the same remaining budget and checks it again after settlement. No fresh
per-phase 90-second clock or unbounded recorder promise is introduced.

Keep the existing **5,000 ms combined owned cleanup** bound, including late
allocations, pending original load, CDP detach and page/context/browser closure.
Add a separate **5,000 ms evidence-write bound**, replacing the old unbounded
write only in this new branch. Thus its Node contract is 90+5+5 seconds; the
supervisor's skin-mode ceiling is **105 seconds**, including Node setup/import
overhead. Presentation's 190-second ceiling is unchanged. Python's existing
45-second startup bound, separately scoped pre-start source/cache inventory and
existing child cleanup/listener-query bounds are unchanged; this is not a claim
of a new whole-Python wall-clock ceiling.

Pre-register `source-preflight`, `single-skin-observation`, and `final-fence` as
PASS/FAIL/NOT_RUN collection stages, with `acceptance_pass:false` permanently.
Keep a separate `transport_outcome` of FINISHED/FAILED/UNAVAILABLE and the fixed
safe cause fields; a collection-stage PASS cannot erase `FAILED/ERR_ABORTED`.
CDP records map only the exact allowed URL to local sequence 1. Preserve null
for absent canceled/blocked/CORS/size fields, validate finite native timestamps,
reject duplicate/mismatched terminal identities and cap all observer storage.
Raw protocol errors, headers, IDs and unrelated events are not written.

Freeze partial stage/request/application metadata before deadline cancellation.
Late events cannot change finalized evidence. Dispose listeners and abort
observer references; detach the owned CDP session and close owned page/context/
browser even after failed config/body parsing, route setup or collection. A
late allocation remains owned; any unconfirmed drain/close is a hard failure.
The supervisor retains its exact descendant-identity checks, fixed tri-state
LISTEN query and independent cache verification, never PID-only cleanup or
bind-as-teardown evidence. Early invalid config emits only a fixed safe failure;
its outer supervision receipt remains the evidence rather than writing to an
untrusted output path.

Red-first tests cover the new closed dispatch/default preservation, config and
dynamic identity mismatch before launch, fresh nonnumerical setup, exact one
native promise/GET, the one-document/module/asset firewall, duplicate events,
terminal failure with permanently unresolved response.finished, missing resource
row, finite clock/enum/null handling, observer rejection safety, late allocation,
stalled CDP/route/write and full pending-stage/cleanup accounting. Test execution
must use authored doubles/private stores with parent plus Node network/process
tripwires; no real listener query, browser, service or asset GET before separate
independent frozen-code review and explicit once-only run approval.
