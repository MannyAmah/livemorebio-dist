# Legacy calculated-state copy and destination highlight

2026-09-09. Proposed correction only; root approval required before runtime or
test edits. Source-only review follows the independently observed
[secondary-page findings](2026-09-09-secondary-pages-browser-review.md).
This is not a page redesign, product rename or new biological state contract.

## Exact intended changes

Only `livemorebio/aegle/console/index.html` and `lib/shell.js` may change.

| Source site | Current | Proposed |
|---|---|---|
| index.html:135, local page heading | `Aegle · Living Human Twin` | `Aegle · Advanced console` |
| index.html:641, organ readout heading | `living organs · real state` | `organ model readouts` |
| index.html:647, cardiac quantity fallback | `AP · Ca²⁺ live` | `AP · Ca²⁺ model` |
| index.html:686, displayed system tag | `ALIVE` when existing status is `alive` | `MODEL` for that same branch; `PENDING` unchanged |
| index.html:325, final explanatory sentence | `“Pending” systems have no engine yet and are never shown as alive.` | `“Pending” systems have no engine yet.` |
| index.html:842, shell call | `mountShell("/", "Aegle — living twin")` | `mountShell("/legacy", "Aegle — advanced console")` |
| shell.js:27, existing More → Advanced console anchor | no active class | `class: active === "/legacy" ? "active" : ""` |

These are display strings and one exact navigation-state mapping. `alive` is
currently the runtime's static engine-presence label (`aegle/runtime.py:24–31`),
not a measured-liveness claim. Preserve that internal value and existing CSS
classes, comparisons, engine names, pending behavior and all numerical state.
The new MODEL tag does not certify a current trace or physical validation.

Preserve the existing guarded cardiac labels: Calculated response / computed /
calculated beat; pending and unavailable must remain exactly as implemented.
Do not change quantity value/unit formatting, organ membership, color/animation,
provenance, observation or History behavior, source/epoch checks, requests,
auth/session code, controls, API/engine contracts or any other page's name.

The existing shell active-link CSS already applies inside More. Keep the same
seven top-level links, More structure and three destinations. `/legacy` must
highlight its existing Advanced console link, never Atlas. Other pages retain
their current exact active matching. No new link, pathname inference, menu
auto-opening, style change or shared navigation refactor is needed.

## Red-first test packet and independent acceptance

After approval add only
`livemorebio/tests/test_legacy_claim_navigation_ui.py`, eight authored cases:

1. Initial local heading/footer copy matches the replacements and retains the
   original model-only/not-clinically-validated caveats.
2. Mount the actual `render()` with authored READY state containing both alive
   and pending systems. Assert MODEL/PENDING, unchanged names/engines, arrays,
   numeric metrics and source-state identity. No biological constructor.
3. Mount actual `paintBody()` with a current owner/context and heart lacking a
   quantity: model heading/fallback, no living/real-state/live claim.
4. Same actual function with a quantity: preserve its exact value/unit instead
   of replacing it with fallback copy; original state remains untouched.
5–7. Mount actual `mountShell()` for `/legacy`, `/`, `/biology`, with inert DOM,
   footer/build mounts only. Assert exactly the expected active anchor and
   unchanged complete href/name list; no real polling, requests or services.
8. Verify the actual legacy module calls `/legacy` and the local subtitle,
   linking the isolated shell assertion to the served page rather than merely
   demonstrating a possible argument.

Reuse existing inert Node launcher and actual-function extraction conventions.
Do not create a new browser harness or alter any inherited assertion. Record
RED before these seven runtime-line edits; then repeat the new eight cases plus
`test_legacy_banner_flow.py`, `test_legacy_preview_recovery_ui.py` and
`test_clinical_model_availability_ui.py` under the existing private/refusal
wrapper. The old suites retain pending, unavailable, source-race, no-replay and
actual calculated-label coverage. Any unexpected migration needs separate review.

Root or another non-maker independently reviews/repeats the frozen packet.
Root owns a later actual browser visit: settled `/legacy`, current/calculated
labels, More active destination and Atlas no longer highlighted, plus mobile
fit if this longer tag wraps. No experiment or source mutation is needed.
Until that visit, claim only offline copy/navigation correctness, not UI or
full-product acceptance. Existing failed screenshots remain historical evidence.

## Review and lesson

The review checklist constrained this proposal to actual reported source sites.
A separate source-only reviewer independently confirmed the two-site navigation
fix and existing CSS applicability. Gbrain/CE tools are unavailable; this document
is the local decision/compounding record, not a fabricated tool completion.
No source, test, browser or numerical execution was performed in this proposal.

Lesson: a truthful trace label does not correct contradictory neighboring labels;
page-local model wording must agree without rewriting the backend status enum.

## Root approval and maker freeze

Root fully read the plan and exact source, then explicitly approved the seven
display/navigation lines and eight new cases plus the three preservation files.
The implementation followed that approval. Correct actual line numbers for the
initial h1/footer sites are134/323 (the preliminary table was off by1/2); the
other sites are unchanged. No additional behavior or source file was edited.

Original complete page/shell bytes were copied before the first RED run to
`/private/tmp/livemore-legacy-claim-correction.3gKmj6/index.before.html` and
`shell.before.js`. After-images are `index.after.html` and `shell.after.js` in
that same private directory. Independent `diff -u` output `63527c` shows exactly
six changed lines in the page and one in the shell. No inherited test migration
was needed. New tests are102 lines, eight cases; their bytes are unchanged from
RED through GREEN.

| Stage | Retained tool evidence | Result |
|---|---|---|
| New cases before runtime change | `7c311a`, private suffix0qbkudfj |6 failed,2 passed,0.76s; Node6, unexpected I/O0, Git0 |
| All eight plus three approved preservation files | `fe6d0b` / session54623 / completion`b38d76`, suffixkb7tl5qf |155 passed,17.64s; Node150, unexpected I/O0, Git0 |

The two original passes are Atlas/Biology navigation preservation. All six RED
failures hit the intended old copy or missing legacy highlighting, not fixture
setup. GREEN includes all eight new cases, with no skip/deselection. Authored
values exercise actual render, paintBody and mountShell functions; footer/build
mounts and drawing dependencies are inert. No actual model, browser, service,
participant record, scientific inference or operational store was exercised.

| Frozen file | SHA256 |
|---|---|
| index.before.html |`224f600cef4d652989028fe8d499aa3271e9576222fbf4330e5eafd5b5f3f074`|
| index.after.html / current index.html |`e49f5387b6e58258f7bc9c18750c83ee305593b8b3275e529fc037348894bcc9`|
| shell.before.js |`3febdfb6b4771e7969a584ef506f937f3cf17ab88d571e38a4102b7e88e5cc95`|
| shell.after.js / current shell.js |`833f6bf7e5ebf8b68c02acde5ff310a746d53bea67c12fcb4a8c9851b2019928`|
| test_legacy_claim_navigation_ui.py |`e3776bbc1c22cd26f43af0e30950de4c8c513149104f6244cbc0104c918132b4`|
| repeat-offline.py |`26166de650a6e7b4bbe0b09a0268f800c6c75f5ae88ebd0dff335e393d46e57e`|

Exact repeat, from `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```sh
PYTHONPATH=/Users/emman/Livemore/.worktrees/full-scope-recovery /tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B /private/tmp/livemore-legacy-claim-correction.3gKmj6/repeat-offline.py
```

The original RED used the same command with `--new-only`. The retained wrapper
copies the documented existing CJS/ESM Node-eval allowlist and network/process/
dlopen refusals,45s deadline, plugin/cache/bytecode disablement and private
environment, with only the selected four test files changed. It uses the already
approved PATH/HOME/TMPDIR/LANG/LC_ALL inherited-environment allowlist. Reading
its49 lines provides the entire reproducible invocation; it does not start a
browser or biological engine. PYTHONPATH is used only to locate the worktree
helper before the environment is replaced.

Maker result: offline implementation complete, independent grading and actual
browser acceptance still pending. Root owns both next steps; this receipt is
not a self-approved UI release and does not close broader product/science work.

## Root independent acceptance, appended September 9

Root read the complete exact seven-line source delta (`9eb0b3`, `729c4f`),
the eight new cases and the whole refusal wrapper (`e383f6`). Its independent
repeat (`c93fb6`) passed **155 tests in 17.64s**, Node150, unexpected I/O0.
This is a separate repeat from the maker's155 above.

Root then restarted the isolated review stack. API identity receipt `47e0cc`
reported startup `16:49:10.349787` and source fingerprint
`da7673ba12df8ba68407efe12308e057f5f879381bb1e6bb5e64d6c658238169`.
Root personally viewed the actual settled desktop (`241955`), open More menu
(`b96169`), exact active-link check (`8ec332`, only Advanced console at
`/legacy`) and mobile (`02d3cc`). The changed local heading, model labels and
correct destination highlight were present; Atlas was no longer highlighted.
Root accepts **this narrow reported copy/navigation correction**. Numerical
semantics, broad legacy usability, all mobile/keyboard controls and physical or
clinical qualification are not accepted by this visit.

The three original PNGs and the preceding Cendos captures were preserved without
re-encoding in `docs/screenshots/final-review-2026-09-09/`; source/copy SHA256
pairs match. Exact paths, sizes, dimensions and hashes are in the
[final browser/regression receipt](2026-09-09-final-browser-and-regression-receipt.md).
The documentation editor viewed these retained images but did not run another
browser, test, process probe or model. Historical failed screenshots and the
maker's pending-acceptance statement remain above as their original checkpoints.

The final full `-rs` regression is running under root's ownership; its result
and exact skip ledger are pending. Videos and full-product acceptance remain
separate. No source is changed by this appended acceptance record.
