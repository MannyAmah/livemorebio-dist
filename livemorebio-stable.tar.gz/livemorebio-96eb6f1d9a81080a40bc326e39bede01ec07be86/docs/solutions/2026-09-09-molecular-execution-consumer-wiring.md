# Molecular inspection in a fixed execution — pre-code increment

This implements the execution consumer in §4 of the approved structure-only
molecular plan. Ordinary Biology and saved-run consumers remain required; this
increment does not replace them or any of the six experiment programs. The
current installed product, old stores, numerical mechanisms and viewer vendor
remain unchanged. The local API/loader/owned inspector have already been reviewed.

## Existing source and bounded decision

`execution_anatomy.js` receives an already admitted execution from the continuous
execution owner. It captures execution_id, source_snapshot_hash and twin_id for
its anatomy but displays molecular targets only as text. Use the same immutable
identity for the existing molecular inspector; do not fetch an active person or
map systemic values onto coordinates. Keep the current reference anatomy,
sectioning, labels, organ selection, graphics retry and error flows.

Write ownership: root owns only `console/lib/execution_anatomy.js`, new
`tests/test_molecular_consumer_bindings.py` and this report for this increment.
No change to the shared inspector, loader, vendor, scientific source or other
consumer. The broad architecture and source reuse were reviewed in the parent
plan; no new renderer or general state layer is introduced.

1. Add an inspector host outside the collapsible organ detail. Mount the existing
   local inspector lazily on the first target click. Its context is kind execution,
   mode EXECUTION_REFERENCE, key JSON of the three captured identity strings.
2. Convert every existing organ target into a type=button with an escaped label
   and exact captured key. Bind direct handlers after detail rendering. Unknown
   targets still reach the governed catalog and show its unavailable mapping;
   do not substitute an available target. Do not inject source HTML.
3. Changing the organ closes old molecular inspection before showing new targets.
   Graphics retry within the same organ/execution preserves molecular identity.
   A click after disposal does nothing. Disposing anatomy disposes its owned
   inspector; any rejected close/dispose promise is observed with fixed feedback,
   never a raw error. No numerical endpoint or execution control is invoked.
4. Preserve all current organ/geometry rendering and source API behavior. Loading
   a reference does not advance biological time or assert molecular dynamics.

## Red-first and independent acceptance

Mount the actual execution module in a small authored DOM with the imported
anatomy and inspector dependencies replaced only at their external seams. Record
calls and assert lazy mounting, all exact target keys, immutable execution context,
organ-switch close, same-source retry, once-only disposal, stale-click refusal,
visible fixed errors and no active-state/experiment requests. Use settlement
guards and bounded Node invocation. These are controller tests, not proof of
actual coordinate rendering or browser focus/visibility.

The product worktree may contain the additive wiring while the local vendor build
is pending, but it is not accepted or published as usable until actual vendor
admission and three-context browser acceptance. The old ordinary viewer is not
removed by this increment. Preserve existing execution/inspection regression
tests. Request independent source and repeat-test review; maker cannot accept its
own change. The final real-browser molecular matrix in the parent plan remains
required, including native selection/measurement, mobile, context changes and
local-only network behavior.

Lesson to retain: execution-level molecular inspection owns the frozen source
identity even if the caller later receives another frame or changes active twin.
Reference coordinates remain separate from the numerical state they help explain.

## Maker evidence; independent review pending

Original actual-source RED:11 failed/1 passed1.54s, privateb3wy7nht,
session38141 exit1, unexpected I/O0/Node12. After the additive consumer change,
the unchanged12 tests pass1.13s, privateidsawpbl, session76414 exit0, I/O0/Node12.
The controller uses an additional local message generation fence so a late
rejection from an old target cannot overwrite the current target's feedback.

Frozen candidate execution_anatomy.js SHA256
`1f30bc3d8ce7b9a446adc80145b9b7227051036bc28622e77f0fc6188c0b508a`;
new tests SHA256
`15730a29cb1aa37da5b8ccb865a3637c5361d7f1b6792220ccd1b1d44b9fbdf2`.
The API request remains only /api/biology/reference in these authored consumer
tests; source loading/rendering belongs to the separately tested real inspector.
Vendor/CSS page admission and real-browser acceptance remain pending. No claim
that the new target buttons yet have an accepted live coordinate scene.

## Independent boundary findings — correction plan before code

The independent reviewer repeated12 unchanged cases (1.11s, privatebevomk2_,
I/O0/Node12), then found two uncovered integration branches. First, a synchronous
geometry disposal throw occurs before molecular disposal is scheduled. Second,
the continuous page's global button/input/select sweep overwrites disabled states
owned by nested anatomy and molecular components on every status update. These
findings prevent acceptance; passing the isolated consumer cases is insufficient.

Bounded correction adds only `lib/continuous_execution.js` to root's write set:
capture the parent's control elements once, directly after its initial markup
and before any nested component is mounted. Existing busy logic then updates that
owned set, leaving all specialized engine/LIFE admission rules unchanged. No new
control framework, permissions or numerical behavior. Geometry cleanup failure
must not skip molecular cleanup; retain fixed, explicit uncertainty rather than
throwing before the second owner's cleanup is attempted. Both rejected async
cleanup and late messages remain observed. Independent authored branch probes
must fail first; preserve the original12 and the final real-browser requirement.

## Independent boundary acceptance

Root read the independent review and all four added actual-caller regression
tests, then repeated the exact combined packet:16 passed in1.63s, session79373,
privatep2smk7kt, unexpected I/O0/Node16/Git0. Corrected execution consumer
6a4b203d… and parent1aa54708… are accepted for this narrow controller boundary.
The review's first fixture-expectation failure remains recorded, not regraded.
Coordinate rendering, vendor/CSS admission and the three-context real-browser
matrix are still required. This does not close Biology or any experiment video.
