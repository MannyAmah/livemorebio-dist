# OSP vmmap: retained unused-region diagnosis and proposed correction

2026-09-09. **Read-only diagnosis and pre-code proposal.** No parser, supervisor,
test, private driver, budget, source identity or old evidence was changed. No
vmmap/OS-preflight/R/CLR/native/model/browser run was performed in this review.
Root must approve the two decisions below before implementation.

## Actual outcome, preserved without regrading

The separately authorized diagnostic exited1. Its result is
`/private/tmp/livemore-osp-vmmap-diagnostic.3D8Ode/diagnostic-result.json`,5761 bytes,
SHA256 `4c437eaafca75f57a4063f71309d71a5ea1ef148d63dd9cde6e5ce97ce9e1112`.
It remains **FAILED / UNRESOLVED_OR_EVIDENCE_FAILURE**. Root reported complete
driver elapsed1.93142s; the original receipt explicitly labels its1.929814959s
as before final write. Neither value is a scientific/preflight pass.

The inspector15512 completed normally, exit0, no TERM/KILL, original primarynull,
complete elapsed1.806087500s and cleanup0.001037417s. It produced322954 stdout
bytes, zero stderr,17 samples, maximum sample gap0.114915500s and peak group
RSS39239680 bytes. Its output reached the strict parser and failed there.

The worker15511 retained primary `INSPECTOR_AMBIGUOUS_ROW`, then received owned
TERM and exited-15. Complete elapsed1.858758042s, cleanup0.018957750s,17 samples,
maximum gap0.114753791s, peak group RSS17022976 bytes. Both receipts say SETTLED,
empty-before-reap, no stream/evidence/cleanup errors. No ACK exists and the
final unresolved-child flag is false. These are retained ownership observations,
not a new current OS-process inspection by this reviewer.

## Independent original-byte and identity checks

All paths below are relative to the diagnostic directory. Both process JSON
objects equal their nested final-receipt objects. Every original stream has
EOF, no overflow, observed length equal to retained length, and independently
recomputed file hash equal to both original hash fields.

| Original file | Bytes | SHA256 |
|---|---:|---|
| `authorization.json` |668|`a26a9eef790703dc0311172942241515acb1bbdb38266b51bed497632dde853e`|
| `once.json` |667|`a353011f4e95918b16748bd14fc97bfc8b249b5840a2d6ba98b625a19ad24388`|
| `evidence/ready.json` |173|`09d58bbdf613cd6c481b4f33ad812e88f478329f2dae4f55e69c93407cb20d7e`|
| `evidence/process.json` |2120|`650a3125c332ace5929be143b40d378f50df0c5a66d2ab04c856ff66594c2005`|
| `evidence/inspector/process.json` |1440|`c59e3330afb766f6620426f4b3ef5271daf5f5ccdf0fddb08f091bbfd9545cb3`|
| `evidence/stdout.bin` |25|`9b85d209c2fe6467d713ead67751e588a83ae19bf11ee322e4f4bfb35875993e`|
| `evidence/stderr.bin` |8|`d2899ec1b86671b253f49a4b7780fbbe645e9aa41871cbe5ea5fa0b2415c28c8`|
| `evidence/inspector/stdout.bin` |322954|`0559751779f8c0c98bd1ef1ea40001bf5a92ae70027fd790d5ada845cbcd96c1`|
| `evidence/inspector/stderr.bin` |0|`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`|

Authorization, once and final embedded authorization have equal strict JSON
values; their original different byte representations remain intact. READY has
the exact supervisor hash, diagnosticVM1, sequence1 and PID15511. Worker streams
are exactly `OSP_VM_DIAGNOSTIC_WORKER\n` and `os-only\n`.
Each initial identity agrees with its retained later identity observation on
PID/PGID/parent/start/image UUID/path/argv. Starts are11153578245951 for worker and
11153578893092 for inspector. Only those two identities occur in the combined
observation list. The17 sample counts/resource summaries are not17 retained raw
sample rows; no stronger sampling claim is made.

Whole current file bytes358182 equal reported pre-final bytes352421 plus final
receipt5761. Setup before worker was0.058621334s; READY followed worker clock
start by0.026904916s, leaving14.973095084s before the worker deadline, exceeding
the13s inspector admission reserve.

Driver/worker/tests remain respectively7bd6d24b…, c19a69d3…,7617fe11… as in the
[frozen implementation packet](2026-09-09-osp-owned-vmmap-diagnostic-implementation-review.md).
Supervisor remains `cdb00a1acb5b08b3f7d8aff0f3977f746b5a506ed4f97355b56dd34bf2d2a476`.
Pure12585d9b… and R3ba6559b… hashes also match. Original O1 result remains
`1bbb6d3290bbf6bcc0869341d0447f8c02aefd333ef2a9eef6397013cd45446c`, FAILED.

## Exact parser cause and full retained row accounting

`tools/osp_semantic_supervisor.py:310–326` accepts a region whose absolute path
immediately follows the sharing-mode field. It then rejects address-bearing
path rows that did not match. The actual first rejection is stdout line1374:

```text
unused __DATA_DIRTY         1f20d5d48-1f20d6678    [  2352   2352   2352     0K] rw-/rw- SM=COW          on dirty page  unused /System/Library/PrivateFrameworks/LanguageModeling.framework/Versions/A/LanguageModeling
```

The complete1932-line output has1777 ordinary path-bearing rows and351 unique
ordinary paths. Eighteen rows hit the original ambiguity predicate; all have the
same `unused __DATA_DIRTY … on dirty page  unused /absolute/path` structure:

| Line | Address interval | Annotated unused path suffix |
|---:|---|---|
|1374|`1f20d5d48-1f20d6678`|`LanguageModeling.framework/Versions/A/LanguageModeling`|
|1390|`1f20e1ec0-1f20e1ef8`|`/usr/lib/libsandbox.1.dylib`|
|1392|`1f20e1f00-1f20e4000`|`AppKit.framework/Versions/C/AppKit`|
|1393|`1f20fc000-1f20fcac0`|`AppKit.framework/Versions/C/AppKit`|
|1394|`1f20fcac0-1f20ff4f0`|`UIFoundation.framework/Versions/A/UIFoundation`|
|1408|`1f21117e0-1f21123b0`|`ApplicationServices.framework/Versions/A/Frameworks/HIServices.framework/Versions/A/HIServices`|
|1409|`1f21123b0-1f21123e8`|`WirelessDiagnostics.framework/Versions/A/Libraries/libAWDSupport.dylib`|
|1410|`1f21123e8-1f21125a8`|`WirelessDiagnostics.framework/Versions/A/Libraries/libprotobuf.dylib`|
|1411|`1f21125a8-1f21125d8`|`WirelessDiagnostics.framework/Versions/A/Libraries/libprotobuf-lite.dylib`|
|1413|`1f21125e0-1f2112820`|`WirelessDiagnostics.framework/Versions/A/WirelessDiagnostics`|
|1414|`1f2112820-1f2112ad8`|`Montreal.framework/Versions/A/Montreal`|
|1415|`1f2112ad8-1f2113268`|`NLP.framework/Versions/A/NLP`|
|1519|`1f21ac000-1f21ac440`|`MediaToolbox.framework/Versions/A/MediaToolbox`|
|1522|`1f21c7a70-1f21c8000`|`IMFoundation.framework/Versions/A/IMFoundation`|
|1542|`1f2248000-1f22483d8`|`SAObjects.framework/Versions/A/SAObjects`|
|1546|`1f2248dd0-1f224a4a0`|`Rapport.framework/Versions/A/Rapport`|
|1547|`1f224a4a0-1f224c000`|`EmbeddedAcousticRecognition.framework/Versions/A/EmbeddedAcousticRecognition`|
|1836|`29ee63b70-29ee64000`|`/usr/lib/updaters/libSEUpdater.dylib`|

Full originals, including all path prefixes and numeric columns, remain in the
hash-pinned stdout at those exact lines. SHA256 of compact UTF8 JSON
`[[line_number, full_line], …]` for these18 rows is
`f9aeb448f78bf134a2d5679ff0d7af088805d88f8145c15340d3a51f13115d6e`.
These paths have17 unique values and **zero overlap with the351 ordinary paths**.
Treating them as ordinary paths would add17 unsupported positive image entries.

There are24 further pathless unused region annotations at lines586,588,1010,
1082,1102,1109,1116,1129,1345,1347,1353,1357,1361,1366,1375,1384,1388,1391,
1401,1404,1412,1416,1828,1830. Those have `unused __TEXT` or `unused __DATA` plus
`on dirty page  unused system shared lib __DATA`. The tool's summary at1924
explicitly counts42 unused-but-dirty shared-library data regions. Its summary
line is not a43rd region and must not be parsed as one.

## Primary evidence and meaning limits

The fully read installed Apple manual `/usr/share/man/man1/vmmap.1`,8048 bytes,
SHA256 `cdd8195c81895d2dd261717aa73056e94546969ee4f887aed37888be3baaa18a`,
documents region address/size/permissions/share/purpose columns, -w full paths,
and default filtering versus -allSplitLibs. It explains that shared-cache VM
presence and actual process use are not interchangeable. It does not specify
this exact new annotation grammar. The actual pinned tool's report-format2.4
output and explicit unused/summary labels are the direct format witnesses.
The conservative inference is to withhold positive image evidence for these
explicitly unused annotations, not to identify them as loaded dependencies.

This new result demonstrates a parser-format failure after successful tool
completion. It is not a timeout, permission or SIP failure. It does not establish
R-image closure, native/source equivalence, numerical correctness or any of the
six required scientific programs.

## Proposed decision A: minimal fail-closed parser correction

Keep `vmmap_paths(raw,pid)->list[str]`, UTF8/PID/512KiB/2048-positive-path bounds,
ordinary-row extraction, downstream image admission and full raw retention.
Before ordinary path extraction, recognize only a fully matched unused-region
annotation. No catch-all `.* /path` or blanket `unused` line skip.

For path-bearing annotations require the observed `unused __DATA_DIRTY` prefix,
valid ascending1–16-digit hexadecimal interval, exactly four bounded nonnegative
size tokens with optional supported binary units, `rw-/rw- SM=COW`, exact
`on dirty page  unused`, and one control-free, non-truncated absolute system path
under `/System/Library/` or `/usr/lib/`. Horizontal spacing may vary; field
order/keywords may not. Return no positive path for this row. Do not admit an
arbitrary runtime/private path through an unused-system exception.

Recognize the24 pathless examples only as the corresponding exact __TEXT/__DATA
annotation with the observed valid region fields and exact `unused system
shared lib __DATA` detail. Other `unused __…` region shapes, missing/reordered
annotations, unknown prefixes or path-looking mapped rows stay fatal. Ordinary
summary/non-region text keeps its previous treatment. An all-unused report is
still INSPECTOR_EMPTY. Raw evidence, not a new manifest/schema, retains excluded
rows. Existing positive path API and unrelated caller contracts do not change.

Write set after approval: only the small parser block in
`tools/osp_semantic_supervisor.py`, one new
`livemorebio/tests/test_osp_vmmap_format_contract.py`, and review evidence. Pure
fixture/R/private executed drivers and old tests/receipts stay untouched.
Tests first: all18 retained rejected rows plus complete hash-pinned corpus RED;
authored ordinary+unused exclusion; pathless/summary preservation; all-unused
empty; missing either unused marker; wrong region/perms/share; malformed/reversed
range or metric count; non-system/private path; control/truncated/relative path;
unknown annotation; wrong PID/invalid UTF8/oversize preservation. Full-corpus
post-fix expected ordinary set is exactly351, with none of the17 unused-only
paths. Tests import the parser inertly under network/child/ctypes refusals.

## Proposed decision B: explicit engineering budget, separately approved

The clean complete inspector took1.806087500s,0.306087500s more than the old1.5s
work window. Subtracting recorded cleanup gives1.805050083s, still not the exact
internal tool completion instant. This single observation supports revisiting
the old cutoff; it is not a latency distribution or proof that all larger
native-process inspections will fit.

Recommend a prospective **3s complete inspector /2.5s work**, preserving the
existing.5s inspector cleanup reserve. This adds finite headroom over the clean
observation without importing this diagnostic's10s bound into production. Keep
worker30s/packet600s, CPU/RSS/output/sample limits and all scientific criteria.
Before an inspector, require at least6s in its owning worker deadline:3s for
inspection plus unchanged3s worker cleanup. A late barrier must fail before
spawn, not extend its parent clock. Current source has inspector2s in LIMITS
and literals at `_CaseCallback` launch/admission; a reviewed change must bind
all three to the same fixed value and test exact nested deadlines/no-spawn.

Do not patch or rerun either executed private packet. After independent parser
and prospective-budget review, prepare a newly identified/pinned OS-preflight
packet retaining all seven conditions, nine direct children plus one descendant,
two O1 barriers and original whole60s ceiling. Its O3 timed-out inspector case
must exercise the newly proposed3s ceiling, not silently retain the old2s test.
The exact new schedule/source hashes/authorization need review before a launch.
The old O1 FAILED and current diagnostic FAILED remain historical outcomes.
No numerical run follows automatically from any OS-only result.

## Method and compounded lesson

Used the investigation skill's source/retained-evidence workflow. No gbrain or
sequential-thinking tool was available. The authorized read-only scope excluded
skill environment changes, telemetry, implementation and live reproduction.
Read all source/receipt objects; independent stdlib-only analysis recomputed
byte/hash/identity links and applied the exact existing two regex predicates to
every retained line. No generator/native API was imported or invoked.

An OS mapping report can contain explicitly unused shared-cache annotations
alongside positive image rows. Relaxing a regex until a report passes would
change its evidence meaning. First classify the observed negative annotations,
preserve unknown-format refusal, and review latency as a separate engineering
decision. This diagnosis is complete; implementation and actual acceptance are
not yet performed.

## Decision B implementation plan, approved root scope before code

2026-09-09 continuation. Root explicitly approved this prospective engineering
increment after both failed OS-only receipts remained preserved. Current
supervisor baseline is d2ac1bac780fbbeec7ad759994068104db8cb1eb70c95a3b3180696999117235.
The completed molecular build no longer holds that file as an active input.
This decision authorizes offline code/tests only, not an OS/native launch or a
new seven-condition preflight packet.

Exact runtime write set: `tools/osp_semantic_supervisor.py` only. Change the
fixed `LIMITS['inspector_s']` from2.0 to3.0. In both PRE_XML and FINAL handling,
after the existing owner proof, capture monotonic time once. Before creating
the inspector directory or calling `_execute`, require at least
`LIMITS['inspector_s'] + 3.0` seconds remaining in the existing parent deadline.
Exactly6.0 seconds is admitted; any shorter remainder raises the existing
`WORKER_DEADLINE`, without an inspector directory/stream/receipt/ACK or launch.
The3.0 extra seconds are the unchanged worker cleanup reserve, not new work.
Use that captured time plus `LIMITS['inspector_s']` as the inspector's complete
deadline, so directory/setup cost is inside the same allowance. Pass the same
fixed limit to `_admit_process`, removing the two old2.0 literals.

Do not change `_execute`'s existing0.5-second inspector or3.0-second worker
cleanup subtraction,30-second worker,600-second packet, CPU/RSS/stream/disk/
sample limits, ownership/admission/parser rules,17 fixtures/16 Run calls,
collector source or closed execution/preflight flags. Do not modify consumed
private drivers, original manifests, authorizations or result files. The
single1.806-second observed inspection is an engineering input, not a latency
distribution, runtime-image admission or a scientific success.

Red-first new file: `livemorebio/tests/test_osp_inspector_budget.py`.
Use the real `_CaseCallback`, `Barriers`, file writer, parser and process-receipt
admission with authored requests/streams/owner, fake monotonic clock and a
replaced `_execute` only at the actual process boundary. Cover both image
phases: exact6 and larger remaining budgets,2.5/3.0-second settled success,
3.0+epsilon receipt rejection/no ACK, late5.999999/3/0 remainders with exact
unchanged input-file set/no execute, and owner-proof time consumption crossing
the6-second threshold. Assert exact argv/env/deadline, outer sampling callback,
retained inspector receipt/stream bytes and identity checks. Two separate
authored `_execute` control-flow cases preserve the actual2.5/27-second work
cutoffs and original complete cleanup deadlines without any OS API calls.
Also pin the entire fixed LIMITS dictionary and both closed flags.

Only inherited timing migrations: the portability test's inspector LIMITS
literal2→3, and the mounted callback's exact launch-deadline literal2→3 at
`test_osp_semantic_supervisor.py:386` (four existing fault variants). Preserve
all surrounding assertions; `_admit_process`'s standalone caller-supplied2.0
fault example is not changed. The latter mounted assertion was discovered
during this source read and reported to root before implementation.

Retain the initial new-test RED before runtime changes, then new-test GREEN
and the prior complete offline OSP preservation packet, with the two actual
native_watchdog tests explicitly excluded. Include the separate20-case retained
forensic check without rewriting originals. Use the existing private45-second
wrapper with network, child process and ctypes refusal. No gbrain/context7/
sequential-thinking or CE tool is callable in this session; this bounded
approved plan, source-only API inspection and final evidence/lesson are the
available workflow, not a claim to have invoked unavailable tools. Root is the
independent implementation grader; maker tests alone cannot open the next gate.
