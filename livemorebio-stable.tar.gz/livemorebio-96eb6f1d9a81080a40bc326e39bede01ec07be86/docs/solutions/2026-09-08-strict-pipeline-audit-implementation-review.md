# Strict public-reference audit — implementation review packet

## Scope and frozen files

Root approved the source-reviewed amendment in
`2026-09-08-molecular-reference-source-admission.md` before implementation.
This maker changed only `livemorebio/audit.py`, the new dedicated test file and
the approved documentation. Root owns molecular API routes; no route, registry,
client, scientific model or retained OSP file was edited here.

- `livemorebio/audit.py`,283 lines, SHA256
  `b82e241accdf6646f58d93171b5f3e2b173f64e7206aff3e52a7f7f6f799312c`.
- `livemorebio/tests/test_strict_pipeline_audit.py`,394 lines,63 cases, SHA256
  `d9201697109258a11e714f9caf1807b441e00bb2455a71df9e60f59b8e2c3593`.
- Unchanged76-case attached-client preservation file
  `test_legacy_preview_recovery_clients.py`, SHA256
  `6e7d5108c0b6cb95e596490bcfdba8f167df3983c476c13a2dd7961ca1c3b0f9`.

Original audit source before this increment was
`1a38682455eabf376bcb4ae4c340150d5e2b90b5fddf6af12663a16b648ad23d`.
The maker does not independently grade this packet. Root must read the complete
source/tests and repeat the exact isolated command below before clearance.

## Exact behavior and preservation

Only `record` gains keyword-only `strict=False`; its five positional parameters
and defaults remain. Canonical JSON, fingerprint input, timestamp rounding,
record fields, HMAC input and algorithm stay unchanged. Legacy append failures
still return the signed receipt without claiming strict durability. Existing
key corruption no longer causes destructive replacement through either caller.

Shared key handling preserves existing accepted `raw.strip()` material with
length at least32, including an authored8192-byte compatibility witness. Raw
bytes and modification time are not changed. Missing/unreadable/short keys
cannot be silently replaced. Verification reads only; it never generates a
key. Missing key with nonempty log fails. New32-byte raw random keys are sampled
at most32 times until strip-stable, written and fsynced to a0600 temporary file,
then published using a no-overwrite link and directory sync. Concurrent creators
read the completed winner. Original invalid bytes and ambiguous failure states
are retained; there is no repair or migration.

Both default and strict appenders use the opened log's nonblocking flock with
the same one-second monotonic acquisition budget, checked before and after
acquisition. No separate lock file/store is introduced. The critical section
rejects a nonempty non-newline tail and exact key/log device+inode alias before
appending, then makes one `os.write`, checks its full length, fsyncs, syncs the
directory and closes. Short write, sync or close failure cannot produce strict
success. No uncertain append is retried, truncated or repaired. An intact
receipt can therefore remain after a reported sync/close failure; that is
retained uncertainty, not a successful API response or permission to rerun.

Key/log symlinks and nonregular files reject; FIFO opens use NONBLOCK. Unrelated
hard-linked historical keys remain accepted. There is no historical log scan:
the existing log inspection is its size and at most one final byte. The
cooperative lock does not claim exclusion of old binaries or arbitrary external
writers, power-loss simulation, remote-filesystem guarantees or a production
PHI security assessment. New key publication is fsynced; existing keys are read
unchanged, not retroactively proven to have been durably provisioned by an old
writer. This packet implements the current local POSIX recorder, not Windows
locking support or a new cross-platform framework.

Strict mode requires `log is True`, explicit dictionary provenance, exact dict
inputs/outputs, a printable bounded action string and JSON-built-in values.
Depth is at most4, nodes at most256 and the final encoded record including
newline at most16KiB. Finite JSON serialization and detachment occur before
key/file access. The root's route allowlist is responsible for excluding caller,
subject and coordinate contents; a generic recorder cannot infer privacy from
arbitrary strings. Explicit provenance avoids the optional legacy Git lookup.
Every strict exception, including clock/UUID/hash failures, maps to fixed
`AuditError`, code `AUDIT_UNAVAILABLE`, text `Audit recording is unavailable.`

## Actual retained RED/GREEN history

Private roots share
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-`.
The actual tool receipts retain the results below; long original failure output
was tool-truncated, not represented here as a complete saved pytest transcript.
Private files, including intentionally damaged failure witnesses, were not
repaired or removed.

| Root suffix | Actual result | Interpretation |
|---|---|---|
| `9apl_c9j` |48 failed/4 passed,0.41s; I/O0 | Original52-case RED on unchanged audit.py; missing strict keyword and destructive key paths. |
| `5l8bv80w` |1 failed/51 passed,0.21s; I/O0 | Fixture error: longer34-byte legacy KEY was wrongly supplied as os.urandom(32). Corrected only that entropy candidate/expectation to exact32 bytes. |
| `ir5r4r1p` |3 failed/57 passed,0.25s; I/O0 | New clock/UUID/fingerprint faults exposed raw exceptions; strict-only outer error normalization corrected them. |
| `tt4m8yo6` |60 passed,0.22s; I/O0 | Above cases green. Three original verify cases were strengthened to reach HMAC key access rather than short-circuit at absent fingerprint. |
| `lm_jtex0` |2 failed/60 passed,0.24s; I/O0 | Same-inode key/log alias actually appended over authored key; expired retry could succeed. Both fixtures remain retained. |
| `803iywhl` |62 passed,0.21s; I/O0 | Approved exact inode comparison and pre-attempt deadline check green. |
| `cq4k3cik` |141 setup errors,4.49s;141 denied attempts | Overbroad preservation setup imported AegleTwin/NumPy to install constructor traps. ctypes.PyDLL(None) was refused. No test ran and no native load succeeded; this is invocation error, not141 product failures. |
| `2x7m7wpz` |1 failed/62 deselected,0.08s; I/O0 | Root's explicit post-acquire deadline case reproduced; two-line post-acquire guard added. |
| `t328fxx8` |**139 passed,0.58s; I/O0** | Final63 dedicated +76 attached-client tests under unchanged network/native/child refusal. |

The preservation invocation was narrowed, not weakened: removed the unnecessary
runtime-importing plugin and excluded the three local preview minimization
fixtures which import runtime. Those three are not claimed passed here.
No inherited test file changed. Actual file operations, short writes, link
publication, flock contention on distinct descriptors, fsync and thread
concurrency ran only in fresh authored private directories. Interprocess
contention was not exercised because all child/process launch was prohibited.

## Exact final independent-repeat command

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`. To repeat only
the63 dedicated cases, omit the second test filename. Initial RED used the
first filename before implementation. The wrapper is not a service launcher.

```bash
PYTHONDONTWRITEBYTECODE=1 /Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B - <<'PY'
import os,sys,signal,socket,subprocess,urllib.request,multiprocessing.process
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:v for k,v in os.environ.items() if k in ('PATH','HOME','TMPDIR','LANG','LC_ALL')})
env.update(PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1');os.environ.clear();os.environ.update(env)
counts={'unexpected_io':0}
def deny(*a,**kw):
 counts['unexpected_io']+=1
 raise AssertionError('Unexpected network, native load, or child in strict audit tests')
for owner,names in ((socket,('socket','create_connection','getaddrinfo')),(subprocess,('Popen','run','call','check_output')),(urllib.request,('urlopen',)),(multiprocessing.process.BaseProcess,('start',))):
 for name in names:setattr(owner,name,deny)
def hook(event,args):
 if event in ('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.exec','ctypes.dlopen'):deny()
sys.addaudithook(hook);signal.alarm(45);print('Private test root:',root,flush=True)
import pytest
code=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(root/'pytest'),'livemorebio/tests/test_strict_pipeline_audit.py','livemorebio/tests/test_legacy_preview_recovery_clients.py'])
print('Refusals:',counts,flush=True);signal.alarm(0)
raise SystemExit(code or bool(counts['unexpected_io']))
PY
```

Lesson compounded: an opt-in strict writer is not key-preserving if ordinary
verification can still truncate the shared key. Atomic publication must precede
visibility, append uncertainty must preserve inconvenient bytes, and proving
the file is regular does not prove it is a different file from the signing key.
Test-isolation machinery can itself cross an import boundary; preserve that
failure and narrow the test selection instead of silently relaxing the guard.
No browser, service, native/OS probe, operational store or biological evaluation
was run. The separate OSP preflight and all six scientific programs stay outside
this engineering packet.

## Root independent source grade, September 9

Root read the complete283-line implementation,394-line tests, this report and
original HEAD audit implementation. Frozen hashes match. The unchanged canonical
record/HMAC inputs and existing normalized signing material are preserved. No
critical finding remains within the declared local POSIX/cooperative scope.
Independent dedicated repeat:63 passed in0.24s, private suffix`yv9ojgjk`, I/O0,
Node0/Git0 under the existing45-second isolated wrapper. This does not independently
repeat the maker's76 attached-client cases or establish cross-process/power-loss
properties. Root's additional real API/audit tests are independently reviewed by
the UI reviewer, not graded here by their maker.
