# Cendos current-source correction

2026-09-08. Root and independent pre-code review cleared the amended contract;
red-first implementation is in progress under the full-scope recovery and clinical
availability plans. The existing legacy current-twin assay is preserved; it does
not substitute for any of the six requested experiment programs.

## Reproduced source defect and bounded decision

`cendos/service.py::assay_current` reads `bus.snapshot('twin')`, ignores current
selection authority/model availability, and reconstructs a model from that cache.
`server.py::cendos_assay` forwards without a current-source guard. A failed bus
publication after observation-only selection can therefore leave an old person's
parameters available to the assay. This is an authorization/identity defect, not
an invitation to replace the assay equations or invent parameters.

Replace the cache as execution authority with an explicit authenticated Aegle
source capture. Keep the bus for notifications only. No failure may fall back to
cached parameters, a default healthy/T2D person, or a local imported Aegle process.

## Producer: protected current-source read

Add bodyless `GET /api/cendos/current-source`, no query fields. Require existing
operator authorization before any source read. Ensure startup state outside the
source guard. Under authority, require confirmed generation and READY numerical
availability. For a registered selection, use the shared audited active-record
read with `source_capture`, compare all four memory/record identity fields, and
require the existing source-specific `model_availability` dispatch to permit this
exact record, including its public-reference exclusions. Do not unconditionally
call `resolve_model_context` for SYNTHETIC, which remains the already supported
authored-reference compatibility path. REAL_HUMAN stays unavailable. Retain
the explicitly labeled unregistered reference-preview compatibility path; it is
not a clinical person.

Detach only the existing executable `profile`, `profile_params`, `pk_context`,
and `parameter_provenance`, selected six-field summary/null, and availability.
Do not return observations, notes, full human profile, waveforms, medical history
or an entire mutable bus snapshot. No numerical model is constructed by this
read. Canonicalize the exact detached payload, hash it and return:

```
schema: livemore.cendos-current-source.v1
snapshot: {profile, profile_params, pk_context, parameter_provenance,
           subject, model_availability}
snapshot_sha256: SHA-256 of strict sorted compact UTF-8 snapshot JSON
```

The maximum serialized response is 2,000,000 bytes, depth 64 and finite/safe
numeric JSON. Source identity includes the selected twin/version and authority's
generation; a reference preview has null twin and version zero. Return no-store
and a new canonical request UUID. Wrong-key/audit/storage failure is a fixed 503
REGISTRY_STORAGE_UNAVAILABLE, not a model-context error or empty preview.
Scientific-context failures retain their exact fixed 409 codes; DENY_ALL retains
SELECTION_COMMIT_UNCONFIRMED. No diagnostic values appear in error text.

## Consumer and proxy

Add a small Cendos source client using the existing attached safe transport:
configured Aegle peer URL, operator auth, redirects/proxies disabled, identity
encoding only, one bounded response read, no retries or local fallback. Existing
8 MiB wire transport cap remains unchanged; this schema's own 2,000,000-byte
canonical UTF-8 envelope cap is checked additionally after strict shared parsing.
The producer emits compact UTF-8 JSON within the same schema cap. This does not
claim a smaller client wire-read budget. Its 10-second socket timeout is not a
hard overall deadline.
Validate exact envelope/snapshot keys, hash, current UUID, availability, subject
ID/version coherence and existing full metabolic/PK parameter rules before any
pharmacology call. A source with unavailable biology is not executable merely
because parameter-shaped fields exist. The same copied parameters still feed
the existing baseline/treated calculation and retain their provenance.

The assay result adds the exact source envelope/identity needed to reproduce
and attribute the calculation. It is a frozen-source modeled result, not a live
person response or physical observation. Re-read the same authoritative source
once after calculation; if generation/identity/content changed, return a typed
MODEL_SOURCE_CHANGED and do not publish an assay result/event as current. An
unreadable post-check is operationally unavailable, never success. Neither read
repeats a mutation. No biological parameters are written back to the twin.

The existing Aegle assay proxy also checks model readiness and captures generation
after body parsing; recheck before actual dispatch and before presenting its
response. Network/calculation stays outside authority and manager locks. Preserve
source/context errors outside forwarding catch-all handling. This is not a
distributed transaction or revocation of an already-dispatched request. The
result's frozen source identity remains necessary even after a successful check.

### Wrong-peer protection and exact restrictive guard

The proxy captures the same detached source envelope locally before dispatch.
It rejects a caller's `expected_source` field, then adds its own exact guard:
`{source_generation, twin_id, twin_version, snapshot_sha256}`. Cendos treats this
only as a restrictive precondition: its independently read source must match
all fields before calculation. It never accepts caller-supplied parameters or
resolves a different subject to satisfy the guard. Direct Cendos use may omit
the guard for the retained explicit-current-source workflow; an optional supplied
guard still only narrows eligibility and cannot grant access or provide biology.
Null twin/version-zero preview is explicit in the guard.

The proxy validates the complete returned frozen source envelope/hash and requires
it to equal its own captured source, as well as the generation checks above.
Cendos pointed at a different Aegle instance must not cause this Aegle to show
that other instance's result. A wrong-peer/mismatched-envelope response is rejected
even if each server's local generation stayed stable. No bus or returned subject
label can override this comparison. Successful ASSAY_RUN notifications include
the frozen source generation/hash/selected identity, not only an old subject
label. They describe the attributed past calculation, never current live state.

## Red-first tests and preservation

1. Poison only an isolated technical bus with old ready parameters while the
   authoritative source is observations-only or DENY_ALL: no model/assay call.
2. Protected producer auth precedes registry reads; four-field mismatch, audited
   read failure, unavailable/uncertain states and oversized/invalid snapshot all
   reject without source mutation. Supported ready/reference-preview capture is
   detached and source-hashed; no native constructor and no observation leakage.
3. Real safe transport with intercepted bytes rejects wrong hash/schema/UUID,
   malformed/oversized/duplicate JSON, redirect/encoding/timeout and never retries.
4. Existing full-parameter and explicit PK tests remain; fixtures move from bus
   injection to the actual new source envelope, not to bypassed validation.
5. Source changes during calculation reject before result/event publication;
   captured input remains unchanged. Failed post-check cannot report success.
6. Proxy post-body, pre-dispatch and in-flight-result races do not publish stale
   success; no network under source/manager locks. Existing ready legacy assay
   remains functional on its declared reference context.
7. Two different stable Aegle peer fixtures reject before Cendos calculation when
   the restrictive guard mismatches. A forged/mismatched returned source is also
   rejected by the proxy. Registered authored SYNTHETIC, the existing admitted
   aggregate-reference context and null preview preserve their distinct eligibility;
   REAL_HUMAN/clinical descriptions never become ready through this change.

Root owns server, new Cendos source client, service and new tests. Registry maker
owns audit internals; reuse its existing `source_capture` action rather than
adding an audit store. SDK/terminal owner retains the shared transport file.
Independent pre-code review is required before implementation. Cross-service
HTTP, UI and installed-wheel acceptance follow source freeze; isolated tests
alone are not full-product, biological or clinical validation.
