# Legacy preview D0 diagnostics — implementation review

Status: **maker packet frozen; independent review required; no actual run authorized here**.
The approved proposal is `2026-09-08-legacy-preview-d0-diagnostic-proposal.md`,
including root's final pre-code decision (SHA-256
`b84feb5f941cac45c9086275fd5fd2c16dc460cd5421e4f5dcce0c4ab08e3118`).

## Exact frozen write set

| File | SHA-256 |
| --- | --- |
| `tools/check_legacy_preview_browser.cjs` (315 lines) | `0a30991b4f7b0d84ac9c505838df1b53c927da11fda7a4a97d1a10430cea0b9d` |
| `livemorebio/tests/test_legacy_preview_browser_harness.py` (644 lines) | `bcaba8ecde07d42f29e79ef9c6b52ff6ff93d7e60933ed165bbf2d664b6b7cdd` |
| Unchanged `tools/check_legacy_preview_browser.py` (494 lines) | `ea6f496a053b3afc91fc1f26542721416764303fd66aaf67af10a18d99ce4de1` |

No product/client/server/model/fixture-value/source change. Previous CJS
`b80c2bd5…` and both actual failed runs remain historical evidence, not overwritten.
The upv6333e D0 cause is still **unknown**; this corrects lost diagnostics, not an
inferred auth, browser, transport, UI, or biological defect.

## Bounded implementation

- Every existing asynchronous action now carries a fixed literal operation.
  First failure records only case/context/operation/allowlisted error class/code.
  Native-shaped TimeoutError and the unchanged harness action timer both retain
  ACTION_TIMEOUT. Later observer/page error/capture/cleanup cannot replace it.
- Original request identity maps to its existing bounded row using WeakMap.
  Response status, body stage and modeless-admission result contain no payload.
  Only the original successful baseline body is read once, with the old 2,000,000
  limit; no extra GET, second body read, body hash, trace, arbitrary exception name,
  message or selector is written.
- Fixed D0 navigation/modeless/cookie/profile/service booleans distinguish reached
  checks. False means not completed; it does not assert a particular transport cause.
- At most one failure viewport capture, separate from twelve acceptance images.
  It requires the existing owned browser/context/page entries, no pending allocation,
  connected browser, open page, exact parent associations and expected viewport.
  Only local Playwright identity getters precede screenshot; no evaluate, user
  interaction, scroll, reload, navigation or second-page attempt occurs.
  Capture has its own unchanged-allowance 2-second/4-MiB bound and uses the existing
  64-MiB exclusive private evidence writer. Timeout/error/size/ownership skip retain
  fixed status without modifying the primary failure. Late promise resolution has
  no file-writing continuation.
- Work remains 159 seconds plus the existing 21-second cleanup reserve. The
  optional 2-second capture, 3-second drain, at most three remaining 3-second closes
  and 3-second observer drain fit inside the reserve. Parent remains 350 seconds.
  Request256 / POST4 / heldGET2s / action10s / browser180s / normal12 images unchanged.
- Python parent admission needs no change: nonzero browser exit remains rejected;
  additive failure metadata cannot confer delivery or visual PASS. The normal
  twelve-image exact hashes/source/pins/cleanup admission remains unchanged.

Installed official Playwright client source confirms the new synchronous getters:
`browser.js:115` isConnected; `page.js:184,393,520` context/viewportSize/isClosed;
`browserContext.js:258` browser; `network.js:557` Response.request.
Root is `/Users/emman/.agents/skills/gstack/node_modules/playwright-core/lib/client/`.
No package acquisition/imported real browser or service occurred.

## RED and preservation receipts

All runs used the strict wrapper below; only authored Node --eval programs were
permitted. Socket/DNS/urllib/child process/ctypes use was refused.

| Stage | Result | Private review-root suffix | Node / unexpected I/O / Git refusal |
| --- | --- | --- | --- |
| Mounted targeted RED before CJS edits | 12 failed, original 84 passed, 13.05 s | z9o527k0 | 45 / 0 / 1 |
| First implementation repeat | 1 failed, 95 passed, 17.49 s | d3dkdbo2 | 45 / 0 / 1 |
| Frozen final repeat | **98 passed, 19.23 s** | aj6bkz5j | 47 / 0 / 1 |

The one intermediate failure was a **fixture clock assertion**, not a runtime fix:
the mounted fixture accelerates the outer deadline to 200 ms, so its deliberately
unadmitted HTTP503 ends with BROWSER_DEADLINE before the unchanged real 10-second
poll. The test now explicitly asserts that retained deadline while preserving
its actual503 / NOT_READ / null admission / zero body reads. No harness timer changed.

Twelve initial REDs exercise the real mounted runner/route/response/catch paths:
native navigation/body TimeoutError and Error, private custom-name redaction,
later page failure not replacing the first origin, original response identity,
non200 status, failure-image success/hash/viewport, timeout, oversize, error,
disconnected ownership and unresolved allocation. Two additional coverage cases
verify distinct STATE_PARSE/SyntaxError versus STATE_ADMISSION/Error and exact
READ/admission metadata. Existing successful runner assertions now also check
all D0 booleans, no failure image and exactly two admitted actual baselines among
multiple same-URL fixture responses. These two extra validation cases were added
after the initial red packet; they are not claimed as separately demonstrated REDs.

No DOM screenshot was produced by a real browser. Inert screenshot buffers prove
control flow/hash accounting only, not PNG decoding or visual acceptance.
Actual rendered review and the next once-only authorization remain root-owned.
No requirement row or requested scientific experiment is completed by this packet.

## Exact offline command

Working directory:
`/Users/emman/Livemore/.worktrees/full-scope-recovery`.

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os,socket,subprocess,sys,urllib.request,ctypes
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1
  permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=short','livemorebio/tests/test_legacy_preview_browser_harness.py'])
print('Refusal counts:',counts,flush=True)
raise SystemExit(status)
PY
```

## Compounded lesson

Attach diagnostic identity at the asynchronous origin, not in a shared outer
catch. A native timeout is identified by its safe class, not equality with one
harness-generated message. Keep failure evidence separate from acceptance evidence;
a successfully captured failed page never upgrades the failed run.

## Independent root review and once-only diagnostic execution

Root read the complete315-line CJS and644-line test file plus this report.
The first-origin/error-class, original-response metadata and bounded failure
capture are consistent with the approved diagnostic scope. Python remains
unchanged. Root repeated all98 offline cases independently: **98 passed in6.23s**,
private review root `livemore-research-review-7ayl6l_o`,47 authored Node programs,
zero unexpected I/O attempts and one refused optional Git probe. All three file
hashes above were rechecked unchanged. No actual UI acceptance is implied.

Authorize one actual run of the existing parent command against the unchanged
runtime source `d0311baf6fd4cd8cc6754685471cc11bd8712c53b30afc952fb9295e31c5aac4`.
All existing budgets, own private stores/ports8910–8912, four authored delivery
fixtures and scientific-execution tripwires remain unchanged. Stop at the first
failure, retain its diagnostic viewport when ownership permits, and clean up only
owned children. This is the explicit corrected diagnostic attempt; no automatic
retry or reinterpretation of the two previous actual failures is authorized.
