# Observation integrity: source, time and delivery are different contracts

## Decision

Preserve the prior release and exact v2 serialization. Extend the existing services
with v3 lineage rather than rewrite journals or introduce another backend.
Numerical predictions, technical fixtures, admitted measurements and scientific
qualification must never share an implicit status transition.

## Defects exposed by independent review

- Admission was able to label existing computed glucose/heart-rate traces as
  measured. Admission now adds observations without changing model provenance or
  physiological parameters. The legacy 33 °C placeholder was removed.
- Virtual sampling could read a mutable global bus snapshot and attach its values
  to a different subject/version. Explicit readings or a complete registered
  envelope are now mandatory; the browser uses a prepared-file workflow.
- Mean-curve residuals lacked an observation-to-model time/endpoint mapping.
  Residuals now require an immutable prediction and exact mapping. Only a
  technical identity mapping exists; real sensor transfer is unavailable.
- Even finite inputs can overflow subtraction/interpolation. Tests cover very
  large opposite-sign values and reject nonfinite outputs without inventing zero.
- Separate gateway instances could make replay decisions from stale memory.
  Transaction-scoped local POSIX locking refreshes durable sequence/session state.
  Replaced/truncated/corrupt journals fail closed instead of resetting watermarks.
- A new clock session could move UTC acquisition backward. Session retirement,
  acquisition ordering and registered command-channel checks are now enforced.
- Malformed metadata could be coerced into consent/custody strings. Typed bounded
  arrays are required. Public Patch errors use fixed categories, not decoder
  exception strings that can echo clinical values.
- A failed response does not prove a request failed before durable admission.
  The upload UI reports uncertainty and asks the operator to inspect the journal
  before retrying; it never claims that an uncertain packet was not admitted.
- An open SSE connection is not a coherent state update. Invalid snapshots retain
  the last good view, mark it stale and stop playback. Changed contexts reset the
  recorded playhead. Source metadata is shared across Patch and Atlas and must
  match the signal, envelope digest, value and unit.

## Verification discipline

Each finding received a regression, with red-first checks for the reproduced
failure, followed by independent review. Full-suite and browser evidence belongs
in the release verification report, not in an architectural claim of human
equivalence. The opt-in pinned Human-GEM tests execute the model; default skips
must not be counted as native-model execution.

Compound Engineering and gbrain were unavailable. This durable local note is the
fallback record, not a claim that those tools ran.

## Remaining limits

Local POSIX journal locking is not distributed coordination. A signed service
admission is not cryptographic proof that released hardware acquired a specimen.
Display recency is not assay validity. Model replay is not a wall-clock human
stream. Physical transfer models, corrected firmware/hardware, independently
measured counterparts and prospective acceptance criteria remain required.
