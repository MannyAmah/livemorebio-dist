# Historical handoff: preservation is not scientific acceptance

## Context

The founder requested a complete account and source checkpoint after a long
multi-worktree build. Older handoffs conflated target architecture, catalog
entries, numerical execution and qualified biology. The original parent source,
newer application, Unreal source and dedicated hardware were separate roots.

## Decision and lessons

- Preserve the full individualized human-replica objective without claiming it
  has been achieved. Keep requested scientific programs and rejected substitutions
  explicit; six programs remain unqualified despite other successful calculations.
- Inventory both Git trees and exact external source allowlists. Never recursively
  archive a parent workspace: a private key can be correctly ignored by Git while
  still present beside product files.
- Distinguish source preservation, third-party redistribution admission and
  scientific release acceptance. An explicit checkpoint/push request permits a
  feature-branch research snapshot, not a production or clinical release.
- Preserve byte-identical measured/model exports and imported structures even
  when generic whitespace checks object to CRLF/padding. Report those warnings
  instead of rewriting evidence or claiming the complete diff is whitespace-clean.
- Use independent history, experiment and publication reviewers. An installed
  library, a tool declaration, passing regression tests and a browser rendering
  are different evidence classes; none proves human functional equivalence.

## Actual process boundary

The September 10 task added documentation, manifests and source exports, preserved
the prior recovery code in Git and reran regression checks. It did not run new
biological experiments, change runtime equations, delete stores or fabricate
physical validation. gbrain, sequential-thinking and Compound Engineering tools
were unavailable in this session; this local lesson is not a claimed remote skill
execution. The full handoff and publication receipt contain the evidence.
