# Explicit selection recovery in Twins, SDK and terminal

Date: 2026-09-08. **Root and independent pre-code review completed with the
clarifications below; implementation and acceptance pending.**
Additive client workflow under the existing
[selection-reconciliation contract](2026-09-08-selection-reconciliation-contract.md)
and clinical availability amendment. No source, service, browser, registry or
native model changed while preparing this proposal.

## Outcome and inspected producer contract

An uncertain subject selection must be inspectable and explicitly recoverable
without asking the operator to repeat selection. Reconciliation is an audited
authority read, not a new selection, model binding or worker-cleanup operation.

The actual root implementation in `aegle/server.py` currently provides:

- `GET /api/twins`: a separately audited record page, `active`, and
  `selection_status: CONFIRMED | UNCONFIRMED`. During `DENY_ALL`, `active:null`
  means the selected identity is unconfirmed, not that there is no active person.
- `POST /api/twins/reconcile-selection`: authenticated, strict JSON body exactly
  `{}`, no query parameters. It requires `DENY_ALL`, performs audited authoritative
  read and final comparison, and never calls the selection mutation.
- A 200 response with exactly `selection_status:CONFIRMED`, `subject`,
  `model_availability`, and `prior_execution_cleanup:INSPECT_EXISTING_STATUS`.
  `subject` is the six-field selected summary or null for a genuinely unregistered
  reference preview. Availability is the existing eight-field v1 contract.
- Canonical server-owned UUID `X-Request-ID` and private/no-store responses.
  Fixed conflict code `SELECTION_RECONCILIATION_CONFLICT`; storage failure code
  `REGISTRY_STORAGE_UNAVAILABLE`. Other existing safe admission errors remain.
- No worker is reopened, stopped, resumed or acknowledged by this operation.
  Pending cleanup can still prevent new native work after authority is restored.

The full root contract and implemented route were read. The proposal does not
change their locks, audits, source generations, null-preview distinction, model
resolver, stored records, versions or ciphertext.

## Current consumer gaps

1. `subjects.js::renderTwins` ignores `selection_status` and renders `active:null`
   as “No active twin.” Stored ACTIVE badges can also look like current-selection
   confirmation. `message()` expires after five seconds, so it cannot hold an
   operational uncertainty state.
2. `selectObservations` refreshes only on success or committed-cleanup uncertainty.
   General lost acknowledgments leave stale selection controls visible. Existing
   `loadSequence` fences page responses but not a separate recovery operation.
3. Generic `request()` neither retains operation headers nor validates a successful
   recovery acknowledgment; it can repeat arbitrary server text in the banner.
4. The SDK has no reconciliation method and the shell no exact command. Its
   `twin list` branch calls `.get()` on `active`, which can now legitimately be null.
5. **Entry blocker requiring explicit approval in this packet:** attached
   `run_shell` calls `P.state()` before its command exception loop. Under `DENY_ALL`,
   the state endpoint returns 503; the SDK's legacy `_get` raises `HTTPError`, so
   the operator cannot reach the proposed recovery command. Null-model handling
   alone does not fix operational selection uncertainty.

## One persistent Twins recovery card

Keep the approved Twins layout, records, intake form and navigation. Add one
stable recovery card adjacent to the existing active-subject card; only one
selection-status presentation is visible at a time. Proposed selectors:
`#selection-reconciliation`, `#selection-reconciliation-status`,
`#reconcile-selection`, `#selection-reconciliation-request`.

For an authoritative listing marked UNCONFIRMED, hide the old active identity and
show: “Selection unconfirmed. The active person has not been verified. Records
remain inspectable. Reconcile selection from audited storage before continuing
with the current subject.” The sole mutation action is **Reconcile selection**.
The card does not expire, and no candidate identity is rendered from stale memory,
the previous selection request, or a contradictory `active` field in this response.

Listing rows remain descriptive evidence. A stored ACTIVE lifecycle may be shown
as “Stored lifecycle: ACTIVE,” without the current-selection green badge while
uncertain. It cannot serve as an alternate active-person assertion. Search,
pagination, explicit record/member inspection, intake, reference Atlas and the
existing Cendos/History navigation remain available. The existing Cendos URL is
`/cendos`; this packet does not invent an unsupported History query parameter.

While certainty is unknown/unconfirmed, disable and handler-guard current-selection
actions: numerical activation, observation selection, virtual binding, physical
pairing open and physical pairing submit. A previously opened pairing dialog
cannot submit stale target/version state. Its typed inputs need not be erased;
reinspection is required after certainty is restored. Do not infer that this
client guard replaces the server fence or blocks another browser/process.

Descriptive intake does not select a person and stays available. Do not globally
disable the record list, forms and pager for the duration of reconciliation just
because existing `withOperationLock` normally does so. Use a separate recovery
in-flight guard, compose it with existing operation locks for selection-dependent
buttons, and preserve all pre-existing disabled states on restoration.

## State, operation and fresh-read outcomes stay separate

The controller keeps selection certainty separately from the last request receipt:

| Selection view | Reconcile action | Source-dependent actions |
| --- | --- | --- |
| Initial/loading or failed read | Disabled until a valid listing says UNCONFIRMED | Disabled; no stale active assertion |
| Authoritatively UNCONFIRMED | Enabled when no recovery is pending | Disabled |
| Recovery POST or follow-up read pending | Disabled | Disabled |
| Fresh listing CONFIRMED | Disabled/hidden; retain relevant receipt notice | Re-evaluate existing model/record/device eligibility |
| Fresh listing still UNCONFIRMED | Eligible for a later explicit click | Disabled |

Each click submits exactly one POST to the fixed route with `{}`; no query,
subject, version, source generation, idempotency key or caller-generated request ID.
Rapid repeated clicks, Enter/Space activation and programmatic handlers cannot
dispatch a second POST while the first attempt/follow-up read is pending.

After a valid acknowledgment, perform one fresh listing GET using the current
record-page controls. Publish active identity only from that accepted listing,
not from the acknowledgment alone. A fresh identity changed by another operator
is current state, not a reason to overwrite it with this request's response.

After a lost/aborted/timed-out/malformed acknowledgment or conflict, perform one
fresh listing GET, never another POST. Keep the original attempt outcome distinct:
“Request acknowledgment unconfirmed; current selection confirmed by a fresh read”
is valid; “Reconciliation succeeded” is not. If that read fails, retain the
uncertainty card and existing read-only Refresh action. A later valid UNCONFIRMED
listing permits another deliberate recovery click, not a background retry.

No refresh loop or automatic reconciliation runs on initial load, pagination,
visibility change, reconnect, polling, route entry or a response error. A page
reload reconstructs the card from the server marker, not local storage. Do not
persist clinical identity or request receipts in browser storage for this feature.

Use an operation epoch as well as the existing page-load sequence. A GET started
before the recovery action cannot restore old active identity or enable controls
after its newer result. The latest eligible listing may update descriptive rows
without using an obsolete selection snapshot. Recovery receipt fields come only
from that specific response; an unrelated list refresh cannot overwrite its UUID.

The same shared selection epoch is invalidated when the existing activation or
observation-selection operation begins, not only for reconciliation. Any ambiguous
outcome of those selection requests causes one fresh listing read, never a POST
retry. A GET started before the operation cannot restore the old active identity
or controls afterward. Add a mounted selectObservations lost-acknowledgment plus
old-GET race regression, preserving the original uncertain receipt separately
from whichever selection a fresh read confirms.

On page disposal/navigation, abort owned fetches and invalidate their epochs;
late POST/GET callbacks cannot update DOM, reopen controls or launch a follow-up
read. Cancellation does not claim the server operation rolled back. On bfcache
return, reinitialize as unknown and perform a read only; no POST replay.

## Request and acknowledgment validation

Add a narrow selection-reconciliation controller/request module rather than
changing every generic `subjects.js` request. Reuse browser auth handling and the
existing strict JSON parser. Bound the new acknowledgment reader to its existing
2,000,000-byte public JSON budget; reject duplicates/non-finite numbers, invalid
UTF-8 and overflow before publishing a response. Do not modify the shared parser
or introduce a larger limit. One owned 60-second POST deadline includes response
body admission; the ensuing listing refresh has its own bounded 20-second wait.
Both release their timers/readers and preserve cancellation uncertainty.

Require canonical UUID metadata from the **current** response to confirm a 200
acknowledgment. Validate exact outer keys, CONFIRMED, exact cleanup marker, the
existing availability v1 shape and coherent subject identity/version:

- Non-null subject: six expected summary fields, supported source class, ACTIVE
  stored lifecycle, positive safe integer version, canonical twin handle,
  subject ID/display label within producer limits (96/80), matching availability
  twin ID/version. READY/model and UNAVAILABLE/observations_only remain distinct.
- Null subject: only READY/reference_preview, null twin ID, version zero and
  preparation_available true. Never turn an incoherent non-null subject into null.
- Malformed/missing UUID, contradictory fields or malformed 200 remain an
  unconfirmed acknowledgment even if a later independent read confirms selection.

Use fixed safe error codes/messages and escaped text. Never display raw response
bodies, exception strings, notes, medication lists, observation values or arbitrary
server-supplied error text. Preserve a verified operation UUID when available;
never recover one from old metadata or generate a client substitute.

Cleanup remains an explicit separate concern. Always display that restoring
authority does not confirm prior execution cleanup. Link to existing LIFE/execution
inspection and Cendos History navigation; do not invent an execution ID or select a
different execution. Existing fixed execution/history and explicit Stop cleanup
behavior remain unchanged. No Resume, prepare or native start is sent by recovery.

## SDK and terminal contract, including the entry blocker

Add `Platform.reconcile_twin_selection()` with no arguments and attach mode only.
Use exactly one existing `_continuous_request('POST', fixed_path, {})`, with the
existing `timeout=60` socket/blocking-call timeout; no local registry or numerical
fallback. Unlike the browser's absolute fetch/body deadline, urllib's timeout is
not a whole-operation wall-clock bound. This packet makes no hard total-deadline
claim for SDK transport and does not change that shared transport mechanism.
Validate its current UUID and full response contract before returning the SDK
record. There is no requested subject or expected version to infer or compare.
Keep the shared strict transport and default response/request caps unchanged.
Add the two fixed reconciliation/storage codes to the shared safe error allowlist.

Add exact `twin reconcile-selection` to the existing strict clinical command
family and pipeline-redaction classifier. Reject every extra argument/option,
including subject IDs, versions, queries and `json=true`, before any SDK call.
Print only confirmation/availability mode, safe twin handle and version if present,
cleanup-inspection marker and canonical current request UUID. Never dump the
subject summary or returned payload. Partial quoted command words and malformed
tails retain the already reviewed privacy behavior.

SDK/shell recovery methods remain one POST only, not an automatic GET+POST helper.
The automatic fresh-listing behavior above is a UI publication step. On a terminal
lost acknowledgment, preserve its typed error and direct the operator to an
explicit `twin list`/state inspection; do not silently retry or erase the outcome.

Proposed minimal entry correction for root approval: attached `Platform.state()`
uses the existing safe `_continuous_request` for the same `/api/state` GET, so the
known DENY_ALL response becomes typed `SELECTION_COMMIT_UNCONFIRMED`. Keep its
existing output projector, no in-process change, no second read and no fallback.
This also subjects the attached read to the existing 8 MiB response limit and
strict parser; preserve current valid ready-state fixtures and prove oversized or
malformed reads fail rather than truncate. The prior correlation-only correction
remains: no summary error adopts a previous mutation UUID.

At shell startup, catch **only** that typed uncertainty to print a restricted
recovery notice and enter the command loop. Other auth/storage/transport errors
do not become an empty selection or MODEL_BINDING_REQUIRED. Explicit commands
still face server gates. `twin list` becomes null-aware and reports the selection
marker/record count without claiming no active person; existing record rows and
pagination remain available. No new command automatically changes stored state.

## Concrete red-first and independent acceptance plan

New `test_selection_reconciliation_ui.py` must mount the actual controller with
realistic DOM selectors, not only compare source strings:

1. `test_unconfirmed_listing_never_publishes_stale_or_candidate_active_identity`
2. `test_recovery_card_persists_beyond_banner_timer_and_no_post_on_load`
3. `test_selection_controls_and_open_pairing_submit_are_guarded_but_inspection_survives`
4. `test_repeat_click_keyboard_and_programmatic_activation_send_one_empty_post`
5. `test_valid_ack_requires_fresh_listing_before_current_identity_publication`
6. `test_lost_ack_then_confirmed_read_keeps_two_distinct_outcomes_and_no_retry`
7. `test_lost_ack_and_failed_read_keep_card_without_guessing_active_selection`
8. `test_pre_operation_stale_listing_cannot_reenable_old_selection`
9. `test_disposed_or_replaced_controller_ignores_late_responses_and_no_followup`
10. `test_reconciliation_never_restarts_or_cleans_previous_execution`
11. `test_wrong_or_missing_uuid_and_incoherent_200_remain_unconfirmed`
12. `test_deadline_auth_failure_and_bfcache_return_never_replay_recovery`

New `test_selection_reconciliation_clients.py` must exercise real shared transport
with intercepted responses, actual root response projections where practical,
and the real attached shell startup/dispatch:

- Zero-argument SDK method, exact route/empty JSON body, once-only/no fallback/no GET.
- Successful selected/unavailable, selected/ready and genuine null-preview cases;
  exact subject/availability correlation, safe UUID and cleanup marker.
- Missing/wrong UUID, stale cached UUID, wrong subject/version/schema, unknown
  fields, non-finite numbers, duplicate keys, timeout/read failure and conflict.
- Startup under actual DENY_ALL error reaches the command prompt; operational
  errors are not mislabeled. `twin list` with active:null stays inspectable.
- Extra/malformed command arguments reject before SDK access; metadata output
  and pipeline echo never contain authored PHI-like sentinels.
- Preservation of 96 current clinical cases, strict JSON and 16 MiB member
  exception, existing client error correlation, ready state and terminal behavior.

After source freeze and independent `/review`, root-authorized real-browser QA on
a fresh private technical stack is required: initial uncertainty card, deliberate
recovery, stable confirmed read, lost-ACK interception, no duplicate POST, History
and intake still accessible, keyboard/focus and 390px wrapping of UUID/error text.
Use explicit technical fixtures only, preserve failures/screenshots, and never
grade this proposal or unit tests as clinical or hardware validation.

## Ownership and approval gate

Proposed maker files after approval: new `console/lib/selection_reconciliation.js`,
narrow `subjects.js`, `twins.html`, `subjects.css` mounts/guards, `sdk.py`, `shell.py`,
the two safe error additions in `execution_client.py`, and the two dedicated test
files. Root retains server/registry/context/audit routes; no shared parser, auth,
Atlas geometry, physiology or model equations are changed. Confirm ownership
before editing a concurrently used file.

Root has read and approved the complete packet, including the attached-state
transport/startup entry seam. The independent review's shared-epoch and timeout
clarifications are incorporated above; red-first implementation is authorized.
Independent review
must examine source-generation/late-response guards as well as the visible happy
path. No implementation or browser acceptance is claimed here.

## Exact successful HTTP status refinement — pre-code review cleared

Maker inspection found that the shared attached transport accepts either 200 or
201, while this reconciliation acknowledgment is defined only for 200. Root's
concurrently implemented CurrentSourceClient has the same exact-200 requirement.
Do not infer current HTTP status from a previous request, add it to metadata
implicitly, or replace safe non-success errors with an acknowledgment failure.

Add one optional keyword to `_continuous_request`: `expected_status: int | None =
None`. Before any network access, require None or an exact non-boolean integer in
the existing successful set `{200, 201}`. None preserves existing behavior and
all metadata shapes/headers. After bounded strict body admission and existing
non-success typed error handling, a successful response differing from the
explicit expectation raises the existing unreadable code: POST
CLIENT_UNCONFIRMED or GET CLIENT_RESPONSE, with the verified current request UUID.
There is no additional request, retry, parser budget, redirect, or body change.
Reconciliation and CurrentSourceClient opt in with `expected_status=200`; no
other caller changes. The browser reconciliation reader similarly requires 200.

Add intercepted real-transport red tests for both successful statuses/default
preservation, expected mismatch on GET/POST, UUID retention, non-success fixed
errors remaining unchanged, and malformed expectation rejection before network
(bool, string, float, out-of-set integer). Root owns CurrentSourceClient's call
and tests; this maker owns the transport/refinement and reconciliation opt-in.
The previously reviewed 16 MiB canonical member exception is unchanged. This
section records root's approval of the direction. The independent reviewer read
this entire refinement and cleared it before implementation, retaining a
response-close failure preservation regression for the mismatch branch.
