# Fresh OSP OS-only preflight after parser A and Budget B

2026-09-09. **Plan only; no fresh driver, authorization or run exists yet.**
Root must approve the small private implementation, then independently read
and repeat its inert tests, then make a separate once-only execution decision.
This does not authorize R/CLR, S01–S17, an OS diagnostic, scientific admission,
or any change to the six required scientific programs or R01–R51.

## Reuse and preserved evidence

Read the complete original plan, implementation/actual-failure report, private
379-line driver, 106-line fixture and 414-line tests. Reuse that implementation,
not a new runner. The only prospective behavior change is its inspector timing
and reserve admission, matching the independently cleared Budget B. The current
supervisor also contains independently cleared parser A's exact unused-region
exclusion; all other parser rejection and positive-path requirements remain.

Original consumed root `/private/tmp/livemore-osp-os-preflight.AFtKah` is read-only.
Its authorization, once marker, source, evidence and failed result remain intact:

| Original file | SHA256, reread for this plan |
|---|---|
| `run_preflight.py` | `90ee5c09988a1d2b6c0875f3bdf8adea637a3c2cb0d8928c34044a69b9ab6f48` |
| `fixture.py` | `6104182d06c6e75069ffb6e062c9e11e9c88be6c7605dbeb9cfec955886bb239` |
| `test_preflight.py` | `30de19f87c979fee23de4930c5eccc48311fa288c85de581df931f546ac8d2ff` |
| `preflight-result.json` | `1bbb6d3290bbf6bcc0869341d0447f8c02aefd333ef2a9eef6397013cd45446c` |

That actual O1 remains FAILED at its first 1.5-second vmmap work deadline;
O2–O7 remain NOT_RUN. The separate retained diagnostic remains FAILED on the
formerly rejected unused-region rows, despite its inspector's clean 1.8060875s
completion. Neither receipt becomes a pass, a permission/SIP diagnosis, or an
invocation to retry. The new packet is a prospective, separately authorized
seven-condition test of the changed source, not a rewrite of either history.

## Minimal private write set and exact binding

Only after this plan is approved, create one fresh 0700 directory using
`/private/tmp/livemore-osp-os-preflight-v2.XXXXXX`. Create three 0600 files there:
`run_preflight.py`, `fixture.py`, `test_preflight.py`. Preserve the original
files byte-for-byte in their original root. No repository runtime/test changes,
production flag edits, old driver/diagnostic edits or new generic interface.

Rebind the new driver's HERE/FIXTURE and fixture's ROOT to the one resolved fresh
root. Update both SUPERVISOR_SHA constants and recompute the new FIXTURE_SHA;
the OS-only request/ACK must bind those exact new bytes. New private hashes and
the fully resolved launch command cannot truthfully be supplied before authoring;
they are mandatory freeze outputs, not values inferred from the old hashes.

| Source reused unchanged | Exact required SHA256 |
|---|---|
| `tools/osp_semantic_supervisor.py` | `8f8c1f66be57f0466a4481fc5cc1b095e6ed47a3e01564f850ae9cf0aa17b79a` |
| `tools/osp_semantic_probes.py` | `12585d9bed93cd2a5625ec1cd625287406a22d475b49c34ba931109630ea82d7` |
| `tools/osp_semantic_probes.R` | `3ba6559b723cfe85c66bca47aac0abfbaac8e395c430bd7360105dc6f67625f7` |
| static inventory V2 | `d09b1f5dcb15d6d612b8b5301c2bb5f6a4c7f174b8e08eeff1df24b087c94be2` |

Root independently read Budget B and repeated 524 passed / two native-watchdog
exclusions in 1.63s, unexpected I/O zero (session36034, completion4a58a5,
private suffix kqoxs1j6). This is offline acceptance, not an OS result.
The new driver retains verified module/function binding and both production
gates false. Its own PREFLIGHT_EXECUTION_APPROVED remains false in the file.

Reuse all four original PINS: canonical Python3.11.15, `/usr/bin/vmmap`,
`/bin/sleep`, and `SystemVersion.plist`, including logical/resolved paths,
sizes, complete hashes and lossless identity integers. Statically reread those
exact files during implementation/freeze; stop on disagreement, do not substitute
or silently update them. They are retained pins, not newly observed live images.
No tool execution or runtime inventory is needed to prepare this packet.

## Only necessary timing delta

For each O1 barrier and the O3 stalled-inspector launch, immediately before
inspector allocation: prove the same worker owner, capture one monotonic value
`inspector_started`, then use the real supervisor's fixed-error check:

```python
s.need(outer_deadline - inspector_started >= s.LIMITS["inspector_s"] + 3.,
       "WORKER_DEADLINE")
```

Only after that check create the inspector directory/subdirectories or launch.
Use `inspector_started + s.LIMITS["inspector_s"]` as the exact `_execute`
deadline, never a second-clock `now + 3` or a clipped allowance. Use the same
limit in O1 `_admit_process` and O3 `grade_process("I3", ...)`. This replaces
the old two deadline and two admission literals, without changing grading.
Setup costs consume the three seconds. Owner-proof cost precedes the capture
and reduces the parent reserve. Exactly six seconds remaining is admissible;
less must fail before inspector files, policy-target allocation, launch or ACK.
The original outer worker/packet cleanup still runs after that refusal.

The reused `_execute` supplies **3s complete / 2.5s work / 0.5s inspector cleanup**.
The extra three seconds in the parent admission are the unchanged worker
cleanup reserve, not extra inspector time. No supervisor code changes are needed.
O1's 10s and O3's 8s caps already accommodate this schedule; do not increase
them or the fixture's eight-second failsafe to turn a slow result into success.

## Exact unchanged child and command schedule

Fixed executable:
`/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11`.
Each worker argv is exactly `[PYTHON, "-I", "-B", FRESH/fixture.py, case,
"worker", FRESH/evidence/case]`. The only inspector commands are below.
No shell, arbitrary argv, source XML, model input or inherited environment.

| Condition | Direct child sequence and required evidence | Complete ceiling |
|---|---|---|
| O1 | One worker, then `/usr/bin/vmmap -w <that proven PID>` at PRE_XML and FINAL, exactly once each. Two exact OS-only ACKs; both inspector receipts admit within3s, exit0, EOF and positive actual samples; parser requires correct PID and nonempty admitted paths. Same live owner throughout; worker exits0. | 10s including both inspectors |
| O2 | One immediate-exit worker. Exact fixed streams/exit0; retain positive valid samples or explicit ZERO_SAMPLES/count0 distinction, never resource-qualify zero samples. | 5s |
| O3 | One waiting worker plus `[PYTHON, "-I", "-B", FRESH/fixture.py, "O3", "inspector", FRESH/evidence/O3/inspector]`. Inspector deliberately times out with WORKER_DEADLINE, positive samples, TERM/settled/EOF within3s; worker retains PREFLIGHT_INSPECTOR_TIMEOUT and settles. | 8s including inspector |
| O4 | One worker forks exactly one same-group descendant. Both ignore TERM; retain actual sampled membership and TERM then KILL, empty-before-leader-reap. Eight-second natural expiry is not an escalation pass. | 6s |
| O5 | One worker; authored callback KeyboardInterrupt after ready/live sample. Retain SUPERVISOR_FAILURE and confirmed owned cleanup. No claimed external/user interrupt. | 6s |
| O6 | One worker directly execs `/bin/sleep` with exact argv `["/bin/sleep", "2.5"]`, no additional child. Preserve sampled contradiction and original UNRESOLVED_CHILD, no signals or reap under uncertain image. | 6s, also covering O7/settlement |
| O7 | Real entry guard plus otherwise-valid existing O2 `_execute` both reject UNRESOLVED_CHILD before files/spawn. Then only same-owner waitable natural-exit observation and separate unchanged cleanup receipt; never clear the historical slot. | No new allowance; at most3s within O6 |

Exactly nine direct children plus one fork descendant, only two actual vmmap
calls. The fixed classifier-only specialization remains finally-restored;
vmmap delegates to the original classifier. No sampling, signaling, WNOWAIT,
owner, drain, process-limit, parser or scientific-barrier substitution.

Keep one60s monotonic budget from `run()` entry through pins, setup, every case,
final revalidation and receipt write. No case starts without its full reserve.
O1–O6 caps total41s; this is headroom, not an entitlement to extend any case.
Production worker30s/packet600s, TERM1/KILL1/proof1, CPU20/21, sampled3GiB,
100ms target/500ms maximum gap, worker1MiB streams, inspector512KiB/8KiB,
case4MiB/packet64MiB, all false scientific gates and status labels stay unchanged.
No guarantee against driver loss or scheduler stalls is added.

## Test-first freeze, then separate execution decision

Retain all43 original offline cases and assertions in the new private test file,
with only new-root/source binding. Add exactly13 cases before changing the copied
driver's timing: one fixed pins/limits/gates contract, and three launch sites
(O1 PRE_XML, O1 FINAL, O3) times four mounted conditions: exact6s accepted with
setup charged to the captured deadline; 5.999999s refuses before files/execute;
owner-proof cost crossing that boundary refuses; over3s original inspector
receipt fails without ACK/expected-timeout acceptance. Use existing mounted
driver/receipt/clock seams, not a replacement scheduler. Preserve actual RED
receipt before implementation. Expected final56 offline cases, not OS evidence.

Reuse the original45s private pytest wrapper with socket/DNS/urllib, process
launch/fork/exec and ctypes-load refusals, disabled plugin autoload/cache, and
fresh `prepare_review_environment`. Change only its selected private test path.
Record exact command, counts, I/O refusals, before/after source hashes and tiny
diff. Root reads all changed lines and independently repeats before any run.

Only a subsequent explicit authorization may create fresh `authorization.json`
binding new driver/fixture/supervisor hashes, O1–O7,60s,9direct/1descendant.
Retain the exclusive new `once.json` before child allocation. The later launch
uses the pinned Python with `-I -B`, clean env-i/system PATH/C locale and private
HOME/TMPDIR/cache; its reviewed in-memory importlib launcher sets only the
private module flag, calls `run()` once, prints fixed status/elapsed and exits0
only for OS_PREFLIGHT_PASS. Freeze its exact fresh path and full command first.
No launcher, authorization or actual invocation is written by this plan.

Fail-stop with remaining NOT_RUN on any unexpected outcome. Root/independent
review must read original raw streams, recompute byte/hash links, inspect every
process/inspector receipt and O6/O7 separate terminal settlement. Preserve original
negative receipts and occupied historical slot; missing terminal proof remains
failure, not successful cleanup. Final stored receipt plus actual exit0 and
observed final elapsed under60s are all required; the receipt's pre-write elapsed
alone is insufficient. No automatic retry, source fix or S01–S17 follows a pass.

Lesson retained: change a measured inspection allowance prospectively at every
caller and admission boundary, without changing the failed observation that
motivated it. Keep technical permission/ownership evidence separate from model
or source qualification.

## Root pre-code decision

Root read all165 lines, the complete retained379-line driver and original
plan/implementation review. The exact private successor implementation is
approved: fresh bindings and reviewed timing/reserve changes only,43 retained
plus13 new red-first offline cases. Full frozen code/diff, original test receipts
and resolved launcher must return for independent review before authorization.
No actual OS/native operation or production gate is enabled by this approval.
