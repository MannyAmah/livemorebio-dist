# Molecular rejected-clock observation — prospective once-only decision

2026-09-09. Within the same R01–R51 correction-first scope. This is a
prospective technical diagnostic decision, not an experiment, release or
permission to repeat any consumed attempt.

## Why this narrow observation is needed

OYVOcS retained all four passing interaction stages and 11 planned captures,
but 29 network identities lacked admitted terminals and the observer retained
TRANSPORT_PROTOCOL_CLOCK without the offending event details. Independent audit
confirms that the cause cannot be
reconstructed from the other observer planes. The new fixed bounded retention
helper preserves both refusal predicates and the original failure path. An
actual observation is needed to distinguish malformed scalar input from the
observer's per-callback ordering assumption. Do not change the application
reader, control behavior, transport-success requirement or clock admission to
make the diagnostic pass.

## Preconditions — no invocation until independently clear

The frozen W8cBUx source and 124-case maker receipt are in
`2026-09-09-molecular-passive-transport-actual-decision.md`. An independent
complete source/test review and the exact inert repeat must be clear, with all
22 input + eight harness pins, parent preservation, unchanged page/Python/test
prefix and an absent successor `run` directory. Root must read that receipt
and explicitly activate this decision before invoking anything.

## Exact proposed single invocation

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-molecular-clock-evidence.W8cBUx/check.py --run-once
```

Private root: `/private/tmp/livemore-molecular-clock-evidence.W8cBUx`.
The unchanged supervisor exclusively creates `run`; no reuse or automatic retry.

- Checker SHA-256:
  `16dc2315c3093ff95fca1215d7c4b78b79314aee610617e947aaee044cad04a9`.
- Python supervisor SHA-256:
  `1dd4a2c22483f01c54ba45a53b9812d03f0c35bfe4b0dd80de9181903ac0a168`.
- Inputs SHA-256:
  `0335456d44b8aca8bc60862380e856668424d49e8206665d4a6a17e5355192d4`.
- Harness pins SHA-256:
  `a49608cf83e40187e0a4c95976cafa548d13e065678d1dd7c3bd9bd237223728`.

Retain all four D0/D1/D2/M0 stages and 11 captures, literal deposited structures,
explicit pig versus unavailable human INS, existing strict CSP and exact-route
GET-only service on 127.0.0.1:8910. Only pinned local browser/runtime and public
reference files. No participant store, hardware command, real-person data,
biological solver, remote request, installation, dependency change or active
product consumer switch.

Keep the existing 240-second outer limit, 180-second work budget, 15-second
cleanup, 128 requests, 32 MiB served and 64 MiB evidence ceilings. CDP events
and rejected-clock facts share the unchanged 512-event/256-KiB bounds and
derived pending/correlation reserve. No diagnostic overflow becomes success.

## Required result review

Preserve the original outcome even if FAILED. Inspect every original planned
and failure image; independently verify source/receipt/image hashes, exact
owned cleanup, and source preservation. Compare rejected clock event kind,
finite-or-null value, prior admitted value and explicit reason only as retained.
Do not reconstruct absent values, infer causal identity from route occurrence,
promote rejected terminals, or use another observer's completion to fill gaps.

Any later change to timestamp admission requires a new source-backed decision
and tests. Any actual result gets a separate data-only independent audit with
no rerun. All consumed failed roots remain unchanged. No commit, push, PR,
deployment or release. This does not complete Biology or any of the six
required experiment recordings.

The already-read QA skill supplies real control and screenshot inspection;
its clean-tree/commit defaults remain overridden by preservation and the release
gate. The previously documented pinned browser fallback remains unchanged.

## Root activation after independent review

Independent complete implementation review and repeat `4dd9db` cleared all
124 inert cases. Root read that receipt, reread the complete checker and Python
supervisor, and independently verified all 30 pins in both roots plus absence
of the new `run` directory (`aeacc2`). The independent prospective-decision
review found no blocking mismatch after the factual correction above: the old
packet does not prove which or how many terminal events were rejected.

Root now authorizes **only the exact single invocation above**. Keep all
30 pinned inputs frozen through final cleanup and preserve every original
attempt. No OSP/native execution may run concurrently; that lane remains
source-only. After this invocation, no automatic second run is authorized.
This decision does not waive a failure, revise a numerical model, admit human
equivalence or complete a requested experiment.

## Actual outcome and root inspection

The single invocation `5cdfd0`, completion **`4b4618`**, exited 1 after
45.34371916600503 s (browser 44949.18675 ms). Overall **FAILED** is preserved:
TRANSPORT_OBSERVATION_FAILED / TRANSPORT_PROTOCOL_CLOCK. All four stages and
11 planned captures passed. All 29 original Playwright requests and all 29
server responses finished, with zero page/console/CSP errors and no original
network failures. Served bytes: 10,296,699. This is not a retrospective repair
or explanation of the older ERR_ABORTED attempt.

The new evidence retained **27 CLOCK_REJECTED events**, each a FINISHED event
with finite EARLIER_THAN_LAST facts; no retention overflow/failure occurred.
CDP has 35 identities / 105 events: eight admitted FINISHED (six data and two
network) and 27 PENDING. All 27 rejected timestamps are after their own REQUEST
timestamps but earlier than their own admitted RESPONSE timestamps. Root's
decimal arithmetic check `8786ad` found request→terminal intervals
0.002431–0.015756 s and response-minus-terminal differences
0.000071–0.056189 s. These are retained event facts, not a cause attribution to
the application reader. The old ordering predicate still rejects them; this
packet must not be rewritten as PASS.

The compact transport JSON is 49,870 bytes within its 256 KiB ceiling, retaining
the 71,680-byte derived cutoff reserve. Desktop cutoff retains 18 pending CDP
ordinals and mobile nine; both other pending lists are empty and both observer
detach receipts SETTLED. No other plane supplies a missing CDP completion.

Root personally inspected all 11 original planned images and `failure.png`.
Source structures, sequence and readable source/scope labels remain present;
Help opens, genuine 5.82 Å measurement appears and is deleted, eight close
cycles remove the plugin and restore focus, and mobile Tab/Escape work. Initial
desktop/mobile canvas sizes remain 989×478 / 350×240. The mobile provenance
capture deliberately scrolls the canvas away; the failure image shows the
correctly closed private page, not a failed structure. Pig 4INS remains labeled
as pig, and unavailable human INS triggers no coordinate fetch or substitute.
These are public-reference inspection controls, not dynamic human Biology.

Read-only `48a318` verified original/embedded browser equality and complete
status/transport/cleanup data. `8786ad` independently checked all 12 original
image byte counts/SHA-256/dimensions and all 30 source/harness pins in both
W8cBUx and its parent. Evidence before final supervision totals 1,913,601 bytes;
including final supervision, 2,193,534 bytes. Original receipt identities:

- `browser-result.json`: 259,800 bytes,
  `3a048e6bef0785389365630c7a23aebfa91b421ea28dc8b113f937ca642ad39e`.
- `supervision.json`: 279,933 bytes,
  `0b013508e06cfa781b4019f8bd3940ed0af167ba0acb2143ea5bb29e66c6edb9`.
- `stdout`: 74 bytes,
  `71a9e357abb1da507a7e147bffebca508f09b5e0a9df927d906221bd6108cd56`.
- `stderr`: zero bytes, SHA-256
  `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

All eight owned closes settled; Node PID 45648 was reaped and all 16 tracked
descendants were absent according to supervision. Before/after listener checks
report NO_LISTENERS. Root's independent exact 17-PID postcheck `07e85f` returned
exit 1 with no rows. No unrelated process was signaled or operational store used.

Root reread pinned Playwright completion and protocol declarations (`1a09a6`).
They describe event timestamps, calculate completion relative to request start,
and clamp a derived response-end value; they do not require this diagnostic's
strict per-callback timestamp ordering. The observed discrepancy therefore
warrants a reviewed diagnostic interpretation correction, not alteration of
source coordinates, physiology or application transport. A separate data-only
audit is underway. No further actual invocation is authorized here.

## Independent data-only result and minimum next interpretation

Release-redteam independently completed retained-data audit **`7fd298`**
(exit 0), without importing the checker, running tests, opening a browser,
probing processes, making network requests or changing consumed evidence.
Original overall **FAILED remains authoritative**. The four original stream
sizes/hashes above match, and the full browser object embedded in supervision
equals the standalone original. Both W8cBUx and OYVOcS manifests independently
match all 22 input + eight harness entries by complete SHA-256, byte count and
exact integer `mtime_ns`, checked before and after each read. All 12 original
PNGs match their recorded complete hashes/counts and dimensions: nine desktop
1440×1000, two planned mobile 390×844, and failure 390×844. This is a data/hash
inspection; original-image visual conclusions above belong to root.

The independent check retains four stage PASS / 11 planned capture PASS,
29 original Playwright FINISHED terminals, zero original request failures,
and zero page/console/CSP errors. The 29 network identities form an exact
page/route/occurrence bijection across the three planes; each server identity
has REQUEST, RESPONSE_FINISH and RESPONSE_CLOSE, with complete request and
`writable_finished` true at both response events. Each side Playwright identity
has REQUEST and FINISHED. This is the declared occurrence correspondence,
not a shared native request-ID proof or causal substitution for CDP evidence.

Every CDP identity has exactly three retained events. Of 35 identities, 27
remain PENDING with CLOCK_REJECTED/FINISHED/EARLIER_THAN_LAST, while eight are
admitted FINISHED (six DATA_NON_NETWORK and network ordinals 1 and 18).
Independent decimal parsing of the original JSON confirms, for **each of the
27**, `own REQUEST < rejected FINISHED < own RESPONSE`; the rejection's
`last_protocol_time_s` equals that same identity's RESPONSE timestamp. These
are no longer missing or inferred terminal values. All eight admitted triples
also have finite nonnegative values and REQUEST ≤ RESPONSE ≤ FINISHED.

The complete rejected-identity comparison is below. Differences are exact
decimal milliseconds from original CDP numbers, not wall-clock estimates or
cross-plane timings; ordinal resolves to the original retained route/page.

| CDP ordinal | FINISHED − own REQUEST (ms) | Own RESPONSE − FINISHED (ms) |
| --- | ---: | ---: |
| 2 | 10.191 | 0.348 |
| 3 | 9.685 | 0.604 |
| 4 | 9.716 | 1.049 |
| 5 | 3.805 | 0.711 |
| 6 | 3.901 | 0.596 |
| 7 | 5.354 | 56.189 |
| 8 | 3.095 | 0.099 |
| 9 | 5.402 | 45.387 |
| 13 | 5.475 | 0.559 |
| 14 | 4.133 | 0.086 |
| 15 | 2.949 | 4.905 |
| 16 | 2.765 | 0.266 |
| 17 | 3.044 | 3.212 |
| 19 | 3.037 | 2.925 |
| 20 | 2.879 | 0.223 |
| 21 | 4.093 | 3.190 |
| 22 | 2.691 | 0.257 |
| 23 | 2.431 | 3.412 |
| 24 | 7.378 | 0.276 |
| 25 | 6.996 | 0.101 |
| 26 | 10.044 | 0.274 |
| 27 | 15.756 | 2.872 |
| 28 | 3.270 | 0.579 |
| 29 | 4.404 | 0.644 |
| 30 | 3.632 | 40.537 |
| 31 | 3.710 | 0.071 |
| 32 | 8.948 | 44.803 |

All 105 CDP / 87 server / 58 side-Playwright events are within their unchanged
bounds. The compact transport record is 49,870 bytes, with its 71,680-byte
cutoff reserve and no rejection-retention failure. Both cutoff pending sets
exactly equal the retained per-page PENDING identities (18 desktop, nine
mobile); all 20 + nine cutoff correlations resolve to the original identities,
and both detach results are SETTLED. The other two pending sets are empty.
All eight owned close receipts are SETTLED. Supervision records leader 45648
reaped, 16 tracked descendants absent, cleanup confirmed, and both listener
checks NO_LISTENERS. Root's separately observed exact-PID check `07e85f` is
attributed to root, not a new reviewer OS probe. Total retained evidence is
2,193,534 bytes including supervision (1,913,601 before it).

Two draft read-only audit commands stopped on incorrect local assumptions
about count-field representation; the completed audit uses the actual integer
counts and lower-case original terminal labels. No evidence or product was
changed, and those draft failures are not product regression results.

### Proposed next source-backed criterion — not implemented or run

Source reread **`c5c0bf`** and independent hashes in `7fd298` confirm the same
pinned Playwright sources: `crNetworkManager.js` `ad55830a…`, `network.js`
`679bd2f9…`, and `protocol.d.ts` `99a323dc…`. The declarations define the
monotonic time domain, not monotonically ordered timestamps across delivered
callbacks. The actual Chromium adapter's completion paths (426–465) use
terminal minus that request's stored start; `network.js` 406–410 clamps a
derived display timing. Neither imposes the checker's RESPONSE→terminal
ordering predicate, and that derived clamp must not modify original evidence.

The minimum justified prospective correction is to retain each identity's
REQUEST timestamp as its fixed floor. Keep exact finite-number/nonnegative
validation; require each later RESPONSE/FINISHED/FAILED timestamp to be at
least its own REQUEST timestamp (equality allowed). Refuse a before-request
event with a fixed reason and the exact compared request boundary retained
through the existing bounded rejection path. This request-start floor is a
conservative diagnostic consistency policy, not a claim that Playwright itself
rejects negative derived durations. A finite terminal earlier than a prior
RESPONSE but at/after its own REQUEST should be admitted as the reported
terminal; the prior-callback relationship remains descriptive in the unchanged
raw event timestamps. Do not sort, clamp, round, add a tolerance, compare other
planes, synthesize a terminal or waive actual FAILED/error events.

Before any implementation, freeze that exact narrow decision and RED cases:
the original 27 own-ID triples, both admitted network triples, equality at the
request floor, RESPONSE/FINISHED/FAILED strictly before the floor, malformed
scalar classes, and retained bounded rejection failure. Keep all unaffected
identity/duplicate/route/status/terminal-error/cutoff/byte/event/ownership
tests and all four stages/11 captures unchanged. No new observer framework,
product reader edit or actual run follows from this recommendation. The older
ERR_ABORTED remains unexplained and unreproduced here; default-consumer release
and all scientific/biological acceptance gates remain unchanged.

Lesson: a monotonic clock domain does not establish callback timestamp order.
Retain the rejected event and its actual comparison boundary before changing
an observer admission predicate; never reconstruct missing facts from another
observer's successful completion.
