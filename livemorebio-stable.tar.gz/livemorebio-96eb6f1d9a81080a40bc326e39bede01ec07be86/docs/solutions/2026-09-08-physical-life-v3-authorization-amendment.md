# Physical v3: proposed exact authorization, receipt and recovery amendment

Date: 2026-09-08. **PRE-CODE PROPOSAL — no physical implementation or provisioning
authorized.** Supplements the conditionally reviewed
[physical onboarding plan](2026-09-08-physical-life-v3-onboarding-parity-plan.md),
SHA `3e6cd6e3ae9a1bd3e2b44e8cd2a2f76ed9de4b9bcb4a25575ef773bebc6a001a`.
Root and independent review must accept the exact contracts below before code.
This resolves the earlier plan's intentionally open receipt/audit/retry policy.

Revision note: the first281-line candidate had SHA
`b4c82979aacf74112ac47f09686f839b5eea4307b944a1091edc734f18d1f195`.
Independent review found five pre-code ambiguities: late-delivery TTL/restart
identity, atomic journal metadata, caller-controlled intent deduplication,
unreserved completion quota, and cross-database audit atomicity. This revision
addresses those findings; it does not authorize implementation.

## 1. Preserve the boundary, including on failure

Operator authentication stays the existing protected local bearer/session scheme.
The HMACs below bind inter-service evidence; they are **not** a new user-auth system
or a manufacturer/device signature. Existing v2 signatures/hashes/journal AAD and
generic v2 replay behavior stay unchanged. Existing virtual-v3 execution receipts,
source clocks, numerical models and review gates stay unchanged.

Only newly admitted **physical v3** traffic uses this path. Both the generic LIFE
telemetry route and any dedicated physical alias dispatch such packets through
the same function, so the old generic route cannot bypass it. Aegle's generic
physical-v3 entry delegates to the new physical receipt consumer, not its old
process-local replay controller. Metadata-only historic v3 bindings remain
inspectable but cannot authorize new physical packets without explicit rebind.

No device is fabricated, registered, flashed, worn, commanded or enrolled by the
form. B0-EVT remains unqualified hardware. All consent/firmware/calibration
declarations keep their explicit evidence status. The current framework has no
manufacturer key authority or calibration-certificate validation service.

## 2. Identity and exact schemas

All JSON objects are bounded, strict, duplicate-key-free and finite; unexpected
fields reject. IDs are canonical bounded strings; hashes lowercase 64-hex; UUIDs
canonical. No booleans/numeric-string coercion for versions/counts. Canonical
serialization is sorted-key compact JSON with `allow_nan=False`, as used by the
current wire contract. Original **canonical envelope identity**, not arbitrary
transport whitespace, is the immutable packet identity.

The authorizing Aegle process and requesting LIFE process must have the same
expected startup `source_sha256` and explicitly configured loopback peers. Capture
both `process_instance` UUIDs and a store-owned random UUID for each new physical
receipt store. `life_store_id` identifies the LIFE intent/outbox role;
`aegle_store_id` identifies the Aegle authorization/receipt role. Also retain
`gateway_store_id` for the journal and `registry_store_id` for the subject registry.
These are distinct role-bound identities, not aliases for a path or each other.
Durable origin identities are never rewritten after restart; current responder
identity is separate. A source/package drift guard blocks new inspection,
authorization, admission and projection, while protected retained-record reads
remain available. No endpoint fallback to another running instance.

### 2.1 Registered-manifest inspection

The same-origin inspection returns exactly:

`{schema:"livemore.physical-manifest-inspection.v1", manifest, manifest_hash,
life_process_instance, life_store_id, gateway_store_id, source_sha256,
inspected_at, request_id}`.

`manifest` is the existing decoded `ManifestV3`; `manifest_hash` equals its
canonical `capability_hash`. Firmware/configuration/capabilities come only from
it. Inspection is authenticated/audited but does not expose a HMAC or secret.
The binding POST performs a fresh lookup and checks the displayed expected hash;
it never accepts an arbitrary client manifest as proof of registration.

### 2.2 Authorization request and signed response

New internal `POST /api/patch/physical/authorize` accepts exactly:

`{schema:"livemore.physical-authorization-request.v1", intent_id,
envelope_id, envelope_hash, device_id, subject_id, manifest_hash, firmware_hash,
custody_reference, first_received_at, life_receive_monotonic_s,
life_process_instance, life_store_id, gateway_store_id, source_sha256}`.

It contains no measurement values or whole profile. Custody is a bounded opaque
reference to the actual gateway/import record, not consent invented by the caller.
Aegle verifies its current selected REAL_HUMAN/ACTIVE record, `life_patch` scope,
custody, v3 physical binding and exact manifest/firmware identity under its source
authority guard. It resolves twin ID, record version, source generation and
consent fingerprint itself; request fields cannot assert them.

Return `{authorization, authorization_signature}`. `authorization` contains
exactly all request fields, plus:

`{schema:"livemore.physical-authorization.v1", authorization_id,
twin_id, twin_version, binding_hash, consent_fingerprint, source_generation,
aegle_process_instance, aegle_store_id, registry_store_id, issued_at, expires_at,
issuer_monotonic_s, ttl_s:30}`.

The response schema replaces, rather than duplicates, the request `schema`.
`binding_hash` authenticates the entire canonical saved v3 association.
`consent_fingerprint` is a domain-keyed digest of the actual relevant consent,
custody and record revision, not a publicly correlatable plain hash of identity.
Issuer time is operational authorization time, never sample capture time.

Sign with the existing local admission key and exact domain bytes
`b"livemore.physical-authorization.v1\0" + canonical(authorization)` using HMAC-SHA256.
Never reuse `patch-admission-v1` or `device-manifest-v1` messages interchangeably.
No HMAC is rendered into the browser or logged. The protected internal requester
still requires normal operator auth; possessing a stale signed record is not
permission to change the active person.

### 2.3 Durable journal admission and final receipt payload

Immediately before append, under the final authorized gateway transaction lock,
form a new immutable internal admission:

`{schema:"livemore.physical-journal-admission.v1", intent_id, authorization_id,
authorization_hash, envelope_id, envelope_hash, manifest_hash, firmware_hash,
device_id, subject_id, sequence, first_received_at, life_receive_monotonic_s,
admission_started_at, admission_started_monotonic_s, append_prepared_at,
life_process_instance, life_store_id, gateway_store_id, source_sha256}`.

Sign using the same configured key with **distinct** domain bytes
`b"livemore.physical-journal-admission.v1\0" + canonical(admission)`.
No declaration here claims a device-origin signature. The **same encrypted
journal record** contains the original envelope plus a new physical-only metadata
object containing the complete authorization/signature, server-owned intent ID,
admission/signature and original first-receive clocks. Its full metadata schema
is validated during tail replay and exact resolution. It is outside the canonical
wire envelope: existing v2/v3 wire bytes, hashes and journal AAD remain unchanged.
Legacy entries without this new metadata remain legacy, not backfilled authority.

The existing `admitted_at` field is captured before append; do not reinterpret it
as fsync completion. New `append_prepared_at` names that pre-append stage honestly.
After `_append` returns, the intent store may separately persist
`durability_observed_at` and local monotonic completion time. If a crash happens
first, recovery records completion time as **unknown**, although the complete
authenticated journal record proves retained admission. Never invent a completion
timestamp or infer zero fsync delay. That optional observation is not used to
change the original signed admission or frozen final payload.

Final fixed `POST /api/patch/physical/receipts` accepts exactly
`{envelope, manifest, authorization, authorization_signature, admission,
admission_signature}`. Each record is checked against its saved digest and every
shared identity/time/process/store field; nonphysical mode rejects. The complete
canonical request is frozen in the protected outbox before any final HTTP attempt.

## 3. First receipt, TTL and process restart semantics

At the LIFE HTTP handler entry, **before body parsing or authorization I/O**, record
actual UTC and local monotonic receive times. The body reader has a 5-second bound
and the existing v3 wire size cap. After complete validation, store a small
encrypted access/intent record with the first times and packet identity, not the
measurement payload, before authorization. LIFE owns and generates `intent_id`;
external telemetry never supplies it. The first transaction uniquely binds
`(life_store_id,envelope_id)` to its canonical hash and initial clocks, with a
device/sequence conflict guard. Exact repeated bytes reuse that intent and clocks;
changed bytes or the same device/sequence under a different envelope ID conflict.
Perform this deduplication before authorization, including concurrent requests.
A new client request or purported intent ID cannot reset a delayed packet's age.

Authorization is valid for initiating new journal admission for 30 seconds after
issuance, with all of the following checks:

- Same captured issuer/requester process instances and store IDs; matching source
  code identity; unchanged person/binding/consent/source generation.
- Exact `expires_at = issued_at + 30s`; local LIFE elapsed from first receive to
  admission start is in `[0,30]`; UTC ordering is consistent with the signed times.
- LIFE verifies signed UTC ordering
  `first_received_at <= issued_at <= admission_started_at <= expires_at` and its
  own first-receive-to-admission-start monotonic elapsed in `[0,30]`. Aegle captures
  its own monotonic issuance time; any issuance-time local elapsed check uses only
  that same Aegle process. Never subtract LIFE and Aegle monotonic origins, or a
  physical device clock from either server clock. Server UTC disagreement fails
  closed rather than being hidden by a fabricated clock correction.
- TTL is checked inside the final local admission transaction immediately before
  starting the append, not only before a potentially blocking lock/network call.
  Durability can finish later; record that delay without pretending that fsync
  shares a distributed transaction or a hard cancellation guarantee.

These are prospective local-software authorization budgets, not clinical latency
or sensor-accuracy tolerances. Gateway's existing physical source-age, device clock,
uncertainty, sequence/session and acquisition-window rules still apply independently.

The Aegle authorization operation itself is durable/idempotent by
`(life_store_id,intent_id)` plus exact request digest. Same bytes in the same valid
context return the original authorization, not a fresh expiry. Changed bytes
conflict. If it expires before admission, do not automatically reauthorize or
restamp; retain a rejected/pending receipt for explicit later recovery design.

TTL governs **starting a new gateway append**, not subsequent delivery of an
already-authorized durable record. For example, authorize at0s, append starts20s
and completes21s, and first successful final POST occurs45s: final admission
verifies the signed original20s eligibility, not `now-issued_at <= 30`. Exact
retry never refreshes authorization or permits another append. No distributed
monotonic clock or atomic cross-service consent revocation is claimed.

Any local or already-observed peer restart invalidates **new append use** of old
process-bound authority. LIFE cannot detect an Aegle restart/source change that
occurs after authorization but before append without another peer exchange; this
plan does not add such an exchange or imply atomic distributed revocation. If that
race occurs inside the original bounded admission window, originally authorized
journal bytes may be retained, but the current responder must return retained-only
or `RECOVERY_REQUIRED`, never project them. Test the exact sequence authorize →
Aegle restart → LIFE append → final receipt, with no authorization refresh.
If the exact authorized gateway record survives but Aegle has no receipt yet,
the current configured peers may verify it against the durable authorization,
saved role/store identities and unchanged reviewed source and retain a historical
receipt with `retained_not_current`; they may not project it. Missing authorization,
missing atomic journal metadata, changed store/key/source or ambiguous integrity
means `RECOVERY_REQUIRED`, not reconstruction. If Aegle's receipt already exists,
an exact lookup after restart likewise returns retained-only acknowledgment.
Origin process IDs remain original; transport checks the current responder IDs.
No historical record silently becomes current-device connectivity.
Even a same-process late receipt retains original capture/receive timestamps and
the existing display-recency rule. An ACK cannot refresh its age or establish a
device connection.

## 4. Durable state machine and lost-ACK handling

`RECEIVED_METADATA → AUTHORIZED → GATEWAY_ADMITTED → DELIVERY_PENDING →
ACKNOWLEDGED`, with distinct `REJECTED`, `RETAINED_NOT_CURRENT` and
`RECOVERY_REQUIRED` outcomes. A status denotes only the completed local action.

1. AUTHORIZED stores the original canonical envelope, manifest, received clocks,
   authorization and custody in an encrypted immutable intent **after** consent
   authorization and **before** gateway append. This makes a later crash resolvable
   without generating another acquisition. Before authorization, no raw measurement
   is persisted in this new path.
2. Gateway admission uses the exact registered manifest and original receiver
   time. On uncertain completion/retry, first call the existing durable
   `resolve_receipt(envelope_id,envelope_hash)`. If found, verify all canonical
   bytes and the authorization/intent/start-clock metadata from that same encrypted
   record, then advance the intent; never call `admit`
   again or allocate a new sequence. Same ID/different hash conflicts. An absent
   receipt permits the original admission only while its authorization is valid.
3. Pending final delivery retains exact payload bytes. The new path does not use
   the inherited `_forward_to_aegle` fallback or publish `patch.latest` before
   final current-context approval. Network timeout never means not committed.
4. Aegle uses an encrypted durable receipt ledger, unique by envelope ID and by
   device/sequence identity with digest-checked indexes. It validates signatures,
   ORIGINAL authorized journal-start window, rather than a new delivery TTL, and
   exact original source/binding. It rechecks
   current selected REAL_HUMAN, scope/custody/binding before **projection**.
   A changed context may leave authorized evidence retained, never attach it to
   the next person. This does not promise cross-process atomic consent revocation.
5. Persist the complete receipt before view changes. Project idempotently into an
   observation-only physical stream, not `runtime.applied`, initialized equations,
   profile parameters, Cendos outcomes or `execution_observations`. Use original
   `normalize_observations`; no resampling into fictitious live values. A later
   same-device sequence cannot be rolled back by an older receipt retry.
6. A failure after persistence but before projection/ACK is retried by exact
   receipt lookup and same-context projection. Do not use Aegle's process-local
   generic replay controller as the retry ledger. Success requires confirmed
   projection, or an explicit historical/superseded receipt status as below.
7. Only after an exact current-context ACK may LIFE publish a subject/device-bound
   observation event. No global unqualified `patch.latest` overwrite. If publication
   is retried after a crash, consumers deduplicate the immutable receipt ID; the
   bus is not falsely described as exactly-once transport. Changed context blocks
   current publication even if old authorized journal bytes are retained.

Receipt storage and Python memory/bus are not atomic. Preserve the distinction
between durable admission, projection and acknowledged delivery in both UI and
audit. No automatic deletion, rollback of a physical acquisition, new observation
timestamp or repeated treatment-history entry is an error-recovery strategy.

## 5. Exact final ACK and bounded transport

Final response has exactly:

`{schema:"livemore.physical-receipt-ack.v1", receipt_id, envelope_id,
envelope_hash, manifest_hash, binding_hash, sequence, received_at,
receipt_status:"durable", projection:"applied"|"superseded"|"retained_not_current",
projected_sequence, source_generation,
origin:{life_process_instance,life_store_id,gateway_store_id,
aegle_process_instance,aegle_store_id,registry_store_id,source_sha256},
responder:{aegle_process_instance,aegle_store_id,source_sha256},request_id}`.

`applied` means that same current source has the observation view after successful
normalization. `superseded` requires a newer admitted sequence from the same
device/person/binding stream and reports it. `retained_not_current` confirms only
durable historical evidence, has `projected_sequence:null`, and forbids a live bus
publication or “connected” UI claim. It resolves historical delivery uncertainty
without pretending that the old runtime was reconstructed. No quantities or health
profile are echoed in the ACK. `origin` must match the frozen authorization and
admission, while `responder` must match the current protected peer/build headers
and expected Aegle receipt-store role. A changed process cannot use `applied` or
`superseded` for an old process-bound receipt, even if the same person is selected.
All fields must match their respective original-request/current-peer authority;
partial, additional, malformed or wrong-source ACKs stay unconfirmed.

Use fixed loopback routes and source/process/store checked peer transport, no
redirects, no retries with altered bytes, and 5-second per-request timeout. An
explicit protected retry operation may attempt the same pending receipt once;
do not create an unbounded background task. Multiple callers use a per-intent
transaction fence so they do not double-admit. No extra device command is sent.

## 6. Storage and audit quota contract

Propose explicitly configured `LIVEMORE_LIFE_PHYSICAL_RECEIPT_STORE` and
`LIVEMORE_AEGLE_PHYSICAL_RECEIPT_STORE`, isolated by the managed launcher/review
environment. No implicit home/other-stack
fallback. Owner-only 0700 parent, regular single-link owner-only 0600 DB/WAL/SHM/key
files, safe-before-open guards, no symlink traversal/permission repair. Reuse the
reviewed encrypted-store primitives and existing configured AES-256 key with distinct
AAD prefixes for physical authorization, intent, receipt and audit. Immutable
encrypted `store_kind` is respectively `physical_life_intents_v1` and
`physical_aegle_receipts_v1`; UUID/key-kind markers also bind identity/encryption.
Reject both configured roles resolving to the same path or existing device/inode,
and reject aliasing either with the gateway journal or subject-registry DB. Before
opening, verify role, owner/path/DB identity; never repair or reinterpret a
wrong-role store. No new secret is published or created by inspection.

Proposed development limits per store: 128 MiB accounted encrypted payloads,
10,000 immutable receipts/intents combined, 128 pending deliveries, 32 distinct
physical device streams and 10,000 audit events. Maximum final payload512 KiB;
metadata/audit record4 KiB; authorization8 KiB; ACK4 KiB. Count all encrypted
versions and audit bytes, not only logical latest records. Admission checks quota
inside the write transaction, including reserved but not yet consumed capacity.
No auto-eviction/deletion when full; return a fixed
`PHYSICAL_STORAGE_QUOTA` code and retain prior evidence. These are finite local
engineering limits, not production retention or expected sampling-rate claims.

Reserve completion before any consent-authorized payload can become stranded:

- LIFE's metadata-intent transaction reserves named slots for AUTHORIZED payload
  (512KiB), immutable final outbox (512KiB), gateway metadata recovery (8KiB), final
  ACK (4KiB), terminal failure/recovery record (4KiB), and16 audit-record slots
  (4KiB each: begin/result records for at most8 logical accesses/transitions).
  Reserve a further512KiB for the new physical gateway record before its append;
  retain this accounting until exact journal reconciliation after any crash.
- Aegle's authorization transaction reserves the authorization (8KiB), final
  receipt (512KiB), projection status (4KiB), final ACK (4KiB), terminal failure/
  recovery record (4KiB), and16 audit-record slots with the same begin/result rule.
- Add a fixed256-byte encryption/framing allowance to every reserved record and
  count each named slot against the immutable-record/audit caps. Validate actual
  encoded size against its slot before writing. Consume a slot atomically with
  its completed transition; unused reservation is not available to other work
  until a recorded terminal transition releases it without deleting evidence.
  The byte limit counts accounted payloads/reservations, not a hard SQLite-file
  or filesystem cap. Pending/stream ceilings are also not guaranteed capacities.
- These slots protect the original operation and one explicit exact-recovery
  cycle, including their terminal audits. Every additional retry/access must
  reserve its own bounded begin/result audit and metadata capacity before I/O.
  Unrelated work cannot consume completion slots. A retry may be refused if new
  access capacity is unavailable, but an original in-flight operation can still
  record its ACK/outcome. Receipt state remains pending/unknown if delivery is
  unresolved, never falsely `failed_not_committed`.
- Gateway append and LIFE intent DB are not a shared transaction. A charged
  reservation plus atomic journal metadata allow deterministic reconciliation;
  no claim of cross-store rollback or exactly-once fsync is made.

Audit schema:
`{schema:"livemore.physical-access-audit.v1", request_id, action,
opaque_record_id, started_at, completed_at, outcome_code,
local_store_id, local_process_instance, source_sha256}`.

Allowed actions are inspect, bind, authorize, admit, receipt_read, project,
retry and acknowledge. Outcome is a fixed safe code, never raw exception/body.
Audits are encrypted; plaintext indexes contain only random IDs/order needed for
storage. Physical-v3 bind success audit is written to a new encrypted audit table
**inside the existing SubjectRegistry `BEGIN IMMEDIATE` transaction**, alongside
the record version and device association. Failure of that audit rolls back the
binding. It is not written to the new receipt DB and called atomic. This guarded
registry path has a separate bounded10,000-event/4KiB audit allocation checked
before mutation. No retroactive rewrite of legacy bindings/audits is performed.

Aegle authorization+audit+completion reservation commit together in the Aegle
physical receipt DB. LIFE intent+audit+reservation commit together in its LIFE
intent DB. A registry source/consent read and a receipt DB write are not one SQLite
transaction: hold the existing source-authority serialization fence, verify the
exact registry version before committing authorization, and still recheck current
context before projection. Audit/receipt roles and origin registry identity are
explicit; same service does not mean cross-database atomicity.
Protected reads begin access auditing before decrypt/return and finish before
response; audit failure fails closed. New end-to-end tests verify no raw subject,
device, quantities, custody/attestation references or secrets in logs/plaintext.

## 7. Required red tests before implementation and acceptance

In addition to the parent plan: freeze exact field sets/domains/TTL/quota; reject
signature substitution across purposes, changed processes/stores/source and source
clock origins; preserve first received time through delayed auth and lost ACK;
recheck TTL after blocking work; registration/authorization revoked or changed
between local stages; crash after every durable transition; gateway append without
intent status update; Aegle receipt without projection; projection without response;
late older retry after a newer sequence; restart retained-only ACK; wrong ACK
identity/status/extra data; duplicate concurrent retries; receipt/index tampering;
unsafe store paths; full audit/receipt quota; no unqualified bus publication;
no `applied` growth, profile/numerical mutation or virtual-observation overwrite.

The five clarification regressions are mandatory: append20s/final45s stays
historically eligible without TTL refresh; gateway-only versus Aegle-durable
restart each returns retained-only or explicit recovery-required under the frozen
identity rules; crash immediately after append resolves the original authorization
and start clocks with unknown completion time; changed caller intent and concurrent
same-envelope attempts preserve server-owned first receipt; unrelated quota fill
after authorize/append/final receipt cannot consume reserved terminal slots; bind
audit failure rolls back the same registry transaction, and either role opening
the other's file is rejected before data access.

Use only labelled software fixtures in private stores. Actual physical acquisition,
manufacturer proof, clinical consent administration and paired validation remain
absent. Independent code review and actual isolated-browser/socket checks are
separate pending gates. No native numerical gate or physical release status is
changed by approving this software-receipt plan.

## Pre-code review decision

Root read the complete revised 393-line proposal and subsequent explicit remote
restart/recency clarification (candidate SHA
`d50d4c9bb3bd924d85e3624118a4aa2a3c2f5db4d48e738384e99c68cc75f425`).
The independent reviewer cleared the five prior corrections conditional on that
now-recorded remote-restart boundary and its exact race regression. Root accepts
this bounded software contract for red-first implementation. Runtime files remain
frozen for current Atlas browser/HTTP acceptance; implementation begins only after
root releases that freeze and assigns an owner. No hardware provisioning, physical
acquisition, patient enrollment or numerical execution is authorized by this
software-only decision. Existing physical and virtual records remain intact.
