# Fresh seven-condition OSP preflight — private implementation freeze

2026-09-09. **Maker offline evidence; independent review and actual authorization
are separate gates. No actual preflight/OS sampler/vmmap/R/CLR/model was run.**
The approved plan is `2026-09-09-osp-fresh-seven-condition-preflight-plan.md`.
Root read its full165 lines and appended pre-code approval before authoring.
All R01–R51 obligations and six scientific programs remain unchanged.

## Frozen files and tiny implementation delta

Fresh private root: `/private/tmp/livemore-osp-os-preflight-v2.Yc5Y4i` (0700).
Three source/test files and evidence below are0600. Original consumed roots
are unchanged; no repository runtime/test or production-gate edit occurred.

| New file | Lines | SHA256 |
|---|---:|---|
| `run_preflight.py` | 385 | `a9fbb23b165cdba2bc7b551c14d3a7ffc9c57cd9a9dcc7cee14341c84dedee79` |
| `fixture.py` | 106 | `53537da44c9afd58337bd44514aef14937e465b0a443a3e2247450c90eb6b868` |
| `test_preflight.py` | 542 | `6ab65ffeeaec6eadeb83d3f4ea224062e79cfccee883b9389e6a6327f5f8d761` |

Original driver/fixture copied into the fresh root through apply_patch. Changes:

- Driver lines12/16/17 rebind HERE, current supervisor hash and new fixture hash.
- Driver223–225 and256–258: prove owner, capture one monotonic value, require
  at least LIMITS.inspector_s +3s before any inspector directory/target/spawn.
- Driver232/265 use that captured value +the same inspector limit as the exact
  `_execute` deadline. Lines237/268 admit the original receipt against that limit.
- Fixture lines8–9 rebind only its exact evidence root and supervisor hash.
  All behavior, imports, command scope,8s failsafes and fixed streams are unchanged.
- Copied inherited test fixture line200 adds only real `LIMITS` to its named-API
  tuple. Root read/approved that necessary dependency binding. Exact original
  414-line prefix otherwise matches byte-for-byte;128 lines append the13 cases.

The actual inspector allowance is the frozen supervisor's3s complete/2.5s work,
with0.5s cleanup retained. Owner-proof cost consumes parent time; directory setup
consumes the captured inspector deadline. No recomputed `now+3`, min-clipping,
extra reserve, new helper, classifier change or alternate cleanup is introduced.
`_execute`, parser A, samplers, WNOWAIT, ownership and stream code stay unchanged.

Supervisor pin: `8f8c1f66be57f0466a4481fc5cc1b095e6ed47a3e01564f850ae9cf0aa17b79a`.
Pure module remains `12585d9bed93cd2a5625ec1cd625287406a22d475b49c34ba931109630ea82d7`;
R remains `3ba6559b723cfe85c66bca47aac0abfbaac8e395c430bd7360105dc6f67625f7`.
Static inventory remains `d09b1f5dcb15d6d612b8b5301c2bb5f6a4c7f174b8e08eeff1df24b087c94be2`.
Both production gates and the private source-file gate remain false.

## Original RED, exact tests and GREEN

Run once before timing changes, after fresh source/path bindings: **12 failed,
44 passed in0.60s**, exit1, tool chunk6bd774, private review suffix uy5yjo8h,
unexpected I/O0. All43 inherited and the new static contract passed.
The timing-before driver is retained as `run_preflight.timing-before.py`, SHA
`a8c9e18e1bd3faea40f9c43e934ed4930e4b003c776289e44ccb86faee0d378c`.

The12 failures are PRE_XML, FINAL and O3 crossed with exact-six, late,
owner-proof-cost and overlong-original-receipt cases. Original execution recorded
O1 `(call_time, deadline)=(4.125,6.125)` instead of `(4.125,7.0)` and O3
`(2.125,4.125)` instead of `(2.125,5.0)`. Late sites executed an inspector before
failing old2s receipt admission, rather than refusing WORKER_DEADLINE before
files. Those are real callback/driver branches with authored transport/clock.
The earliest deadline assertion also stopped the overlong cases before their
later admission assertions; do not claim a distinct old acceptance from that RED.

After only the approved timing edits: **56 passed in0.57s**, exit0, tool
chunk67fa80, private review suffix bcptu3ap, unexpected I/O0. No test change after
RED. No wrapper/setup errors or excluded tests in this56-case packet.

The new mounted tests invoke actual `case_run` and its actual nested callback,
original strict request/parser/receipt/write functions, and copied existing
authored process transport. They cover all three launch sites, a charged125ms
setup interval, exact6s allowance,5.999999s refusal, proof cost crossing6s, and
original elapsed3.000001s rejection with no ACK/expected-timeout acceptance.
For exact-six PRE_XML, that first inspector is acknowledged but the later FINAL
correctly fail-stops without remaining reserve; exact-six FINAL succeeds. These
tests do not imply both phases can consume exact-six independently in one case.
The existing mounted whole schedule still proves two barriers, nine direct calls,
one descendant record and unchanged O6/O7 negative and separate terminal evidence.

## Retained evidence

Every path below is relative to the fresh private root, not an actual-run result.

| File | SHA256 |
|---|---|
| `initial-red.json` | `9cda0348f1779144d0bba903ada0c64cbc9297ea8e26715978d34545c5a4feaf` |
| `green.json` | `dea1bcb3421196c7af8b0a56d7c5a2a2442820f26fb781283859d8680f92967a` |
| `reviewed-delta.diff` | `c2ac46842e165c2e961bb023e8342adb5b6fa3dd6eb33860a6e60dbfaf4dde21` |
| `static-pins-readback.json` | `7d79a39c922b2ebc7ef833cf104d7fb5fa8fd9ae0bebf0bddff8b8a7607d6b42` |
| `repeat-offline.sh` | `a274f94e5c80bea8d64190797164ca545761190427838a572536638b750c0ac4` |

The RED/GREEN JSON files explicitly summarize original tool outputs, not invented
verbatim transcripts. The full consoles remain in chunks6bd774/67fa80. The full
three-file original-to-new diff and timing-before bytes are retained separately.

Static readback (chunk0845cc) rehashed exactly the four original pinned files:
canonical Python17,255,968B, vmmap262,464B, sleep101,168B and SystemVersion604B.
All complete SHA values, logical/resolved paths and regular-file metadata matched
before open, on the descriptor before/after reads, and afterward. All device,
inode, mode and nanosecond mtime values were compared as exact integers/decimal
strings. This is source-file inspection, not sampled live process/image identity.

## Exact independent offline command

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`.
This command was used for both RED and GREEN, with no actual child/OS API.

```bash
PYTHONDONTWRITEBYTECODE=1 /Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B - <<'PY'
import os,sys,signal,socket,subprocess,urllib.request,multiprocessing.process
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:v for k,v in os.environ.items() if k in ('PATH','HOME','TMPDIR','LANG','LC_ALL')})
env.update(PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1');os.environ.clear();os.environ.update(env)
counts={'unexpected_io':0}
def deny(*a,**kw):
 counts['unexpected_io']+=1
 raise AssertionError('Unexpected network, native load, or child in offline fresh OS-preflight tests')
for owner,names in ((socket,('socket','create_connection','getaddrinfo')),(subprocess,('Popen','run','call','check_output')),(urllib.request,('urlopen',)),(multiprocessing.process.BaseProcess,('start',))):
 for name in names:setattr(owner,name,deny)
def hook(event,args):
 if event in ('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.exec','ctypes.dlopen'):deny()
sys.addaudithook(hook);signal.alarm(45);print('Private test root:',root,flush=True)
import pytest
code=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(root/'pytest'),'--tb=short','/private/tmp/livemore-osp-os-preflight-v2.Yc5Y4i/test_preflight.py'])
print('Refusals:',counts,flush=True);signal.alarm(0)
raise SystemExit(code or bool(counts['unexpected_io']))
PY
```

## Fully resolved prospective launcher — NOT AUTHORIZED OR RUN

This is proposed command text only. Do not execute without a new root decision.
No launcher script or `authorization.json`, `once.json`, `evidence/` or
`preflight-result.json` has been created in the fresh root. The independent
review must precede exact fresh authorization; the old marker is never reused.

If separately authorized, create only the fresh exact canonical authorization:
schema OSP_OS_PREFLIGHT_AUTH_V1, authorized boolean true, cases O1–O7,
total_seconds60, direct_children9, descendants1; identity is driver
`a9fbb23b165cdba2bc7b551c14d3a7ffc9c57cd9a9dcc7cee14341c84dedee79`,
fixture `53537da44c9afd58337bd44514aef14937e465b0a443a3e2247450c90eb6b868`,
supervisor `8f8c1f66be57f0466a4481fc5cc1b095e6ed47a3e01564f850ae9cf0aa17b79a`.
Reuse the exact existing identity key names `driver_sha256`, `fixture_sha256`,
`supervisor_sha256`. Strict equality and exclusive marker are in the real driver.

```bash
env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C PYTHONDONTWRITEBYTECODE=1 \
 HOME=/private/tmp/livemore-osp-os-preflight-v2.Yc5Y4i \
 TMPDIR=/private/tmp/livemore-osp-os-preflight-v2.Yc5Y4i \
 XDG_CACHE_HOME=/private/tmp/livemore-osp-os-preflight-v2.Yc5Y4i \
 /Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -I -B - <<'PY'
import hashlib,importlib.util,json,os
from pathlib import Path
os.umask(0o077)
path=Path('/private/tmp/livemore-osp-os-preflight-v2.Yc5Y4i/run_preflight.py')
with path.open('rb') as stream:
 raw=stream.read(1024*1024+1)
if len(raw)>1024*1024 or hashlib.sha256(raw).hexdigest()!='a9fbb23b165cdba2bc7b551c14d3a7ffc9c57cd9a9dcc7cee14341c84dedee79':
 raise RuntimeError('DRIVER_CHANGED')
spec=importlib.util.spec_from_file_location('approved_osp_os_preflight_v2',path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
if module.PREFLIGHT_EXECUTION_APPROVED is not False:
 raise RuntimeError('PRIVATE_GATE_CHANGED')
module.PREFLIGHT_EXECUTION_APPROVED=True
result=module.run()
print(json.dumps({'status':result['status'],'elapsed_s':result['elapsed_s']}),flush=True)
raise SystemExit(0 if result['status']=='OS_PREFLIGHT_PASS' else 1)
PY
```

This preserves the original launcher shape: no arbitrary argv, startup override,
shell child, scientific gate or extra OS probe. Child environments remain the
driver's separately created private home/tmp/cache directories. The driver
60s timer starts at `run()` entry, as in the original approved packet, covering
pin admission through final write; interpreter/launcher setup is not represented
as measured driver time. No new timing allowance is created by this distinction.

The exact child schedule remains O1 worker+two vmmap, O2 worker, O3 worker+one
authored stalled inspector, O4 worker+one fork descendant, O5 worker, O6 worker
exec-to-sleep, O7 no child. Complete O1–O6 caps10/5/8/6/6/6s and packet60s remain.
No step resets the historical unresolved slot. Expected O6/O7 original failed
receipts and later same-anchor terminal settlement remain separate.

Actual acceptance would require retained raw output/hash verification, every
process/case/inspector receipt, exact negative outcomes, complete owned terminal
settlement, final source preservation, final exit0 and observed driver elapsed
under60s. A raw receipt alone, or these56 authored passes, is not that acceptance.
Any unexpected result stops remaining conditions; no retry or native run follows.
The original O1 timeout and separate parser diagnostic remain FAILED.

Lesson: caller budgets must migrate at launch, pre-allocation reserve and receipt
admission together. A mounted first-phase boundary can legitimately admit that
phase while refusing a later one; preserve this evidence rather than replenishing
the clock. These are technical ownership checks, never biological validation.

## Independent root grade and once-only decision

Root read the complete 385-line driver, 106-line fixture, original retained
test contract, entire changed-test diff, repeat command and this complete
192-line freeze report. Independent repeat: **56 PASS in 0.53s**, chunk
`7ad668`, private review suffix `z73q267c`, unexpected I/O zero.
No actual OS call was admitted by that test run.

Approve exactly one invocation of the frozen prospective launcher above in
fresh root `Yc5Y4i`, after matching source hashes and creating its exact new
authorization file. This authorizes only O1–O7, 60s, nine direct children and
one authored fork descendant, with the existing false production gates.
Any unexpected outcome stops further cases. Root must inspect actual receipts
and owned terminal state afterward; there is no automatic retry, extra OS
diagnostic or S01–S17/scientific-model execution authorized by this decision.
