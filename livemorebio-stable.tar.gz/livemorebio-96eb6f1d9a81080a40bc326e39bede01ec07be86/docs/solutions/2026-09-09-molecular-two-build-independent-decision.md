# Local molecular viewer: exact two-build decision

Root read the complete original and amended134-line private plan, all208 launcher
lines, all171 test lines, both identical35-line configs,19-file input inventory,
review report, canonical entry/spec and relevant reused process-owner code.
The stats-only runtime-module inclusion and shared30s postflight cap preserve
the approved bundle semantics. Independent23 tests passed0.029s, chunkc1513a,
unexpected I/O0. No build or scientific acceptance is inferred from those tests.

Authorize one execution of the frozen /private/tmp/livemore-molecular-two-builds.QkgKLS
packet: launcher6a466401…, planbdb1a5f0…, testsd402958e…, inputs6163b209…,
configs e9fd5969…. Exactly two stock webpack commands, second only after first
passes its original ownership/output bounds. Original read-only install2Ds7TZ
and supervisor d2ac remain pinned. No retries, dependency scripts, downloads,
vendor publication, old-store writes or model execution are authorized here.

Require the retained output/rights review and actual browser verification before
claiming a usable replacement. Any failure remains failed with original outputs;
no rerun of this once-only private root. Full scope and all six programs remain.

## Actual result — retained failure, not build admission

Session89932 returned FILE_BOUND at A; B was NOT_RUN. Webpack A exited0 and
settled, but its 83,354,656-byte stats file exceeded the original32MiB bound.
The 2,939,705-byte JS and69,902-byte CSS are private candidates, not an admitted
product viewer. Result SHA256 b5b5dc60d7bc19b0c69d84e270f8cee2c21a302b1402519e131bc1ab6f8a791b
remains FAILED unchanged. Root read the result, file sizes and entire118-byte
stderr (stock webpack stats-written message). Targeted subsequent PID inspection
found neither22808 nor22826. No input, installed vendor or old result was replaced.
Read-only bounded diagnosis is separate from regrading; no automatic build retry.

## Independently reviewed successor — September 9

Root read the complete FJiuBt plan, launcher, adapter, entry/config/spec,
21-file inventory, both test sources and frozen maker review. The bounded
amendment preserves the original limits, source/install pins and two-build
ownership. Only reason-edge duplication is omitted from stats; both complete
module-membership trees remain. The shared Binding formatter preserves the
38-default corpus without dynamic template evaluation. It is not a general
template engine and does not relax CSP or remove Help/selection controls.

Independent repeats: 27 Python tests PASS in0.044s (chunk4e6499), and56 Node
VM checks PASS (chunkd83d10), both unexpected I/O0. Pins independently matched
the frozen report. The Node check includes actual upstream Help methods with
inert element stubs and the original Function-trap failure control; it is not
browser rendering proof.

Authorize one execution of `/private/tmp/livemore-molecular-csp-builds.FJiuBt`
using launcher1ab58ed11de64a2d9a082e8c0efea219b138800df49c9ab0a1663efe8a8917e6,
pland04b670b64c2c0a802cf043242b80f20cb847eadcab4892774553d8c07fbf6c0,
inputs823e5ec776f84b40cf23796dd460f731c8bdd5c9604e28b358e74a16f2b62362.
Exactly A then B; B only after A passes. No retry or publication. Preserve both
old failed roots, installed2Ds7TZ and canonical9plldc. Release the d2ac owner
freeze after the actual pair settles, not after the separate rights research.
Successful private builds would still require embedded-notice closure,
actual CSP/browser checks, product wiring and wheel acceptance before release.

## Successor actual result — stats parser failure, retained

Session75463 exited1/ASSET_GRAPH after A; B NOT_RUN. Webpack A exited0 and
settled15.028236167s. Stats now fit7,653,489 bytes; input preservation passed.
Output inspection rejected the actual asset-tree shape, so no candidate is
admitted and no product viewer is replaced. Original result SHA256
5f1ae5cf1e43eab5747ef49db4694fa8b440b9a91cc89d4305f5970093bd69e0;
stats1b73a506270bc831c08c0dfba879fb0af9f7a5e15d84c40fb0761c03876e55c8;
JS6993c2c9f356d31dcb325a5423507450da9cdbda035cdc85315727447fba7ced.
Root read complete result and118-byte stderr, checked PID28947/28958 absent.
Both consumed build roots remain unchanged. d2ac source freeze is released.
Read-only diagnosis of retained actual stats and pinned webpack source is next;
no automatic retry or relaxed closure gate is authorized.

Separate independent formatter review repeated56 checks (chunk80479c), I/O0,
and confirmed shared Binding identity and entry order. Precision: the test
invokes actual Help getBindingComponents formatting/element creation, not
HelpText.render/BindingsHelp.render or React DOM. Those browser claims remain open.
