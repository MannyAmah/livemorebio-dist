# Observation/reconciliation: real-registry integration receipt

2026-09-08. Test-author evidence, **not maker-external product acceptance**. Root
read the complete 142-line plan and approved exactly 15 test cases before code.
After reading all 546 frozen test lines and the initial passing result, root
approved the exact 138-case preservation repeat. No runtime or existing test
fixture changed during this packet. The registry678 and route287 independent
gates remain distinct prior evidence; this packet does not replace them.

Plan: [real-registry integration](2026-09-08-observation-reconciliation-real-registry-integration-plan.md).
Only new file: `livemorebio/tests/test_checked_observation_registry_integration.py`.
All six scientific programs, R01–R51, ordinary rendered/terminal acceptance and
actual physical qualification remain required, not inferred from these tests.

## Actual boundary exercised

The tests invoke both protected ASGI routes without lifespan/startup, using the
real server registry getter and a fresh private authored SQLite store. Actual
SubjectRegistry bootstrap/encryption, full observation preparation, commit/audit
phase owner/witness, checked capture and checked confirmation are retained.
Method identity assertions unwrap only bound methods and cover those paths,
audit functions, real ModelSourceAuthority and server assignment/commit guards.
A real no-background ExecutionManager has no owners/adapters and a no-I/O store.
The real shared snapshot publisher calls only recording bus sinks in this fixture.

The modeless projection wrapper delegates unchanged to actual unavailable_state;
it adds only a bounded test checkpoint after projection. That checkpoint requires
completed capture/preparation access, all four locks unowned and independent
private BEGIN IMMEDIATE/rollback acquisition. This demonstrates released writer
ownership, not observation of a close syscall. Numerical constructors remain
trapped; only true-absence case9 may call the counted inert healthy factory/state,
exactly once. Every REAL_HUMAN case has zero candidate/model constructor calls.

Cases1–7 cross actual selection: different-target and same-target exact writes,
complete lost-ACK witness acceptance, damaged-terminal uncertainty, committed
storage-close ACK failure, same-version target reseal conflict and known rollback.
The original record evidence, creation/index/binding fields, unrelated rows and
non-active registry_state metadata remain exact. Metadata acknowledgment503 is
not mistaken for the committed record body: cleanup503 is checked against actual
new state, persisted rows and its separately published own snapshot.

Cases8–15 cross actual checked recovery: unbound person at stored MAX, true
absence with an unrelated admitted row, orphan ACTIVE row, pointer-clock conflict,
final audit commit/close acknowledgment uncertainty, the three-request ABA case,
and failed capture terminal commit. Recovery changes audit rows only; no clinical
version/pointer/index mutation, cleanup acknowledgment, numerical fallback or
execution reopening is attributed to it.

Every route response is correlated with canonical request UUID/no-store and its
actual encrypted audit ledger. Selection uses inspect then select_observations
with the target ID; checked recovery uses reconcile_selection with null target.
Distinct event identities, fixed payload keys/schema and pending/settled states
are asserted. No extra public record getter contaminates those audit counts.
Deliberately damaged private terminal bytes and pending reservations stay retained.

## Three actual requests, not a fabricated ABA result

R1 completes its real checked capture and pauses outside the authority/manager/
creation/initialization locks after an unchanged modeless projection. R2 completes
the real recovery route against unchanged selected bytes, installs fresh state
and publishes once. The fixture adds explicit authored R2 observation/action
sentinels, then a third actual same-target selection reaches its real mutation.

That third connection raises before final commit delegation, then refuses the
rollback acknowledgment. Actual close rolls the private transaction back. The
actual route returns SELECTION_COMMIT_UNCONFIRMED, installs DENY_ALL through the
real authority/manager fence and retains R2's exact inspection holders. Clinical
rows/pointer remain equal to the initial baseline; its mutation BEGIN/reservation
remain pending. It is not retroactively called confirmed rollback.

After resuming R1, the actual route returns409 before final access because its
captured state identity is stale. R1 has only its completed capture pair; R2 has
two successful access pairs; the third UUID has the inspect pair and pending
mutation BEGIN. The complete retained rows/audits/reservations are unchanged by
R1's rejection. R2's sentinels remain and it is the only published snapshot. No
manual DENY assignment, state substitution or mocked commit outcome creates this
sequence. Bounded in-process thread/Event coordination is not a process-death,
durability/fsync or distributed-writer guarantee.

## Frozen hashes

| File | SHA256 |
|---|---|
| New test, 546 lines / 15 cases | 89e0653ee8d82fb38e38b1477af60d161e210c1f8e12348c5d6082e4efae17d6 |
| server.py, unchanged | 878e585552d12de5fc4cc8e5381bec5a2874565ae3bdd5b496418e7e46875625 |
| subjects.py, unchanged | b5306edc2045fd98e943f9fefc124872996563c3c955fece4ec7aebb718d6441 |
| registry_audit.py, unchanged | b21f01fdf1c79604c5565fee0f7d94d3b0bd11967b199bc97ec8a193de045e4e |
| Existing checked binding integration | 4e9b8a45ac614bc5db8f9134e7f152b9e1964a9c8b14c48c7190fc5437b01489 |
| Existing checked preview integration | 24e6b6ceeace9caf42b52c0676e557e4d2847eafef7068ee2419353478dc191f |
| Existing observation/reconciliation boundary78 | 31d9e40eeb227c1cd6287cb5aa49f6bc90e2961614fdb47360dec1af538b5e23 |
| Existing clinical availability API nodes | 678b8876b4081b512b89210ee9b46dbcd807402533aba3ea55bd37b5aa0bc7d0 |

## Exact retained results

- Initial15: **15 passed, 3 existing warnings in 2.52 s**, exit0. Private root
  `/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-e9cfx07r`;
  complete tool chunk `e8b993`. No test adjustment followed this run.
- After root's full test/read/result review, preservation138: **138 passed,
  3 existing warnings in 4.88 s**, exit0. Private root
  `/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-46xjttp1`;
  final tool chunk `12e6a6`. The test/runtime hashes above remain unchanged.

Both printed `REVIEW_IO_COUNTS 0 1`: zero unexpected I/O attempts; exactly one
optional read-only Git metadata command refused into its existing fallback.
Warnings are existing TestClient/httpx and two startup-on_event deprecations,
not actual startup execution. All test processes completed. No browser, service,
real network HTTP, compiler/native model, solver, device or operational store ran.
There was no initial integration failure to relabel or hide. Older registry/route
RED and fixture-correction receipts remain untouched and separately linked by
their implementation reports.

## Exact reusable guarded command

From `/Users/emman/Livemore/.worktrees/full-scope-recovery`. This is the actual138
command. The initial15 command used only its first path, otherwise the same
wrapper/options; root can use `paths[:1]` for that exact bounded selection.

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os, sys, signal, socket, subprocess, urllib.request, multiprocessing.process
from tools.run_review_stack import prepare_review_environment
review_root, env = prepare_review_environment(inherited={k: os.environ[k] for k in
    ('PATH', 'HOME', 'TMPDIR', 'LANG', 'LC_ALL') if k in os.environ})
os.environ.clear(); os.environ.update(env)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
blocked, metadata = [], []
def deny(*args, **kwargs):
    blocked.append('unexpected')
    raise AssertionError('Review forbids network and child/native work')
def process(command, *args, **kwargs):
    if command == ['git', '-C', '/Users/emman/Livemore/.worktrees/full-scope-recovery',
                   'rev-parse', '--show-toplevel']:
        metadata.append('refused')
        raise OSError('Authored unavailable Git metadata')
    return deny()
def audit(event,args):
    if event in {'os.fork','os.forkpty','os.posix_spawn','os.exec',
                 'subprocess.Popen','socket.connect','socket.getaddrinfo'}: deny()
sys.addaudithook(audit)
multiprocessing.process.BaseProcess.start=deny
for name in ('bind','listen','connect','connect_ex'): setattr(socket.socket,name,deny)
socket.getaddrinfo=socket.create_connection=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
subprocess.Popen=process
import pytest
class InertReview:
    @pytest.fixture(autouse=True)
    def no_models(self,monkeypatch):
        from livemorebio.tests.clinical_registry_fixtures import forbid_compilation
        from livemorebio.aegle.runtime import AegleTwin
        from livemorebio.engines.metabolic.glucose_insulin import MetabolicProfile
        forbid_compilation(monkeypatch)
        monkeypatch.setattr(AegleTwin,'__init__',deny)
        monkeypatch.setattr(MetabolicProfile,'__init__',deny)
signal.alarm(45)
print('PRIVATE_REVIEW_ROOT',review_root,flush=True)
paths = [
    'livemorebio/tests/test_checked_observation_registry_integration.py',
    'livemorebio/tests/test_checked_binding_registry_integration.py',
    'livemorebio/tests/test_checked_preview_registry_integration.py',
    'livemorebio/tests/test_committed_observation_reconciliation_publication.py',
    'livemorebio/tests/test_clinical_availability_api.py::test_observation_selection_commit_installs_coherent_source_or_explicit_uncertainty',
    'livemorebio/tests/test_clinical_availability_api.py::test_selection_reconciliation_uses_audited_authority_and_never_reselects',
    'livemorebio/tests/test_clinical_availability_api.py::test_observation_selection_rejects_coercion_and_extra_fields_before_read',
    'livemorebio/tests/test_clinical_availability_api.py::test_selection_bounded_strict_json_before_registry',
    'livemorebio/tests/test_clinical_availability_api.py::test_selection_auth_precedes_registry_read',
]
rc=pytest.main(['-q','-p','no:cacheprovider','--tb=short',*paths],plugins=[InertReview()])
print('REVIEW_IO_COUNTS',len(blocked),len(metadata),flush=True)
signal.alarm(0)
raise SystemExit(rc)
PY
```

## Lesson and handoff

Integration evidence must keep the real committed side effects in view. A lost
audit acknowledgment cannot be replaced with a mocked status; an ABA race needs
later intent and unchanged storage together, not just two equal dictionaries.
Per-operation encrypted ledgers and original method identities make the wiring
claim inspectable without calling physiology or touching operational data.

Root independently reads/repeats the new15; the author does not grade their own
tests as whole-product acceptance. No further run, runtime change, actual browser
or source/model execution is authorized by this receipt.

## Root independent acceptance — scoped wiring only

Root read all 546 lines of the new test, the complete approved plan and this
186-line author receipt. The independent new15 repeat completed with **15 passed,
3 existing warnings in 2.65 s**, exit0, session72087. Private review root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-4nui57q9`.
The guarded command used the same no-network/no-child/no-model policy and only
the new integration file. Its printed I/O counts were0 unexpected and1 exact
optional Git-metadata refusal. The new test SHA remained
`89e0653ee8d82fb38e38b1477af60d161e210c1f8e12348c5d6082e4efae17d6`.
No implementation/test edits followed the independent run. Root also read the
subsequent author138 preservation receipt above; that is additional author
evidence, not an independently rerun138 claim. The frozen author report before
this append was `defc3695e57b533195cfde2b6145f67e109dbc98881fcc30688fb69621dfd132`.

Disposition: CLEAR for this actual encrypted-registry/inert-model wiring packet.
Real-browser interaction, terminal acceptance, physical device behavior, scientific
qualification and the R01–R51 completion register remain open. All prior failures
and excluded native/process cases remain as originally recorded.
