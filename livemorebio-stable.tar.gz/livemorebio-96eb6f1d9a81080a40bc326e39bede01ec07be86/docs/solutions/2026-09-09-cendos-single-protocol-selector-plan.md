# Cendos: one explicit preparation selector

2026-09-09. Narrow UI correction requested by the user and root after actual
browser review. Plan only; no implementation is authorized by this document
until root approves. Prior artifact: connected-cendos-preparation-correction.

## Concrete gap and retained scope

The current 340px preparation column presents cohort protocols, Human-GEM and
Lobeline as simultaneously visible cards, with Metformin preselected. The user
asked for a simple box selector, not a stack of forms. Keep all four existing
governed protocols, their exact labels, inputs, source limitations, endpoints,
readiness gates, results and rerun semantics. Neither Metformin nor Lobeline is
a substitute for the separate requested R40 experiment. No scientific expansion
or protocol removal is part of this correction.

## Proposed minimum delta

1. Reuse the existing `cohort-protocol-choice` select as the single top-level
   **Experiment protocol** selector, with a selected empty **Choose a protocol**
   option and exactly four existing choices:
   - Metformin · glucose–insulin response
   - Garcinoic acid · PXR concentration response
   - Human-GEM · oxygen-capacity experiment
   - Lobeline · VMAT2 initial-rate assay
   A listed protocol is not a claim that its local source/solver/cohort is ready.
2. Show only the selected preparation form/card. Metformin and PXR retain their
   existing cohort selectors and eligibility logic. Their shared cohort search
   and descriptive-cohort details are visible only for those two choices.
   Human-GEM retains its readiness message and disabled Run behavior. Lobeline
   retains the explicit nonhuman source limitation. Initial entry shows none.
   Keep global protocol status and rerun warnings outside hidden protocol forms.
   Keep legacy assay/lookup and evidence tools in their existing collapsed
   details, unchanged; they are not silently removed or renamed.
3. New experiment uses the already reviewed reset then sets the protocol choice
   to empty and hides all governed forms. Existing input defaults may remain
   within hidden forms; none is a selected experiment. Saved runs, cohorts,
   twins, assay log and immutable results in History remain intact.
4. Prepare rerun restores the selector to that exact returned protocol as well
   as its existing input restoration, so Human-GEM and Lobeline no longer land
   behind an unrelated cohort form. While a rerun is prepared, changing protocol
   requires the existing explicit New experiment path; do not lose lineage or
   route an old RERUN to a new endpoint. While PROTOCOL_BUSY, the selector is
   disabled and its handler refuses changes, matching the existing shared lock.
5. Ordinary protocol selection is local preparation only: no POST, recall,
   solver call, model creation or fallback. It invalidates older pending
   preparation/history reads through existing contextRevision. Recalling an
   immutable result remains read-only; do not relabel that result as a new
   preparation or auto-run anything. Existing handler bodies/endpoints and
   server admission remain unchanged.

## RED-first acceptance and ownership

Owned runtime is only `livemorebio/aegle/console/cendos.html`, with dedicated
tests in `test_cendos_preparation_ui.py` and only necessary old fixture seams.
Write actual-handler tests before runtime changes:

- initial and New entry: empty selection, no governed preparation form visible;
- each of four choices: exactly its form visible, source limitations retained,
  no execution/recall request from selection;
- prepared reruns: all four protocol identities restore the correct choice;
  preserve existing request/body/parent/new-configuration tests;
- busy selector and late history/rerun reads cannot change current preparation;
- new selection does not alter existing immutable result identity or saved data;
- existing legacy lock, cohort picker, result and history tests stay intact.

Use the existing isolated offline Python/Node guard; no maker browser/server,
native, model or biological calculation. Root independently reviews the delta
and performs real desktop/mobile browser QA and final Cendos recording. This
does not claim R40 scientific behavior or whole-product completion.
