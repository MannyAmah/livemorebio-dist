# Observation/reconciliation registry: original RED receipt

2026-09-08. Test-author evidence, not independent acceptance. Root read and
approved the62-case inventory before authoring, then read the frozen626-line test
before implementation. Only the new test file was authored. Neither runtime nor
the two approved later inherited-test migrations changed for this invocation.

## Exact original result

**53 failed,9 passed in2.31s**, exit1, exactly62 cases. Private fixture root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-e8secrt8`.
Unexpected network/process/native attempts0; exact optional Git metadata refusal1.
No browser, service, external HTTP, native/model or operational store ran. All
SQLite records and controlled interference were authored private fixtures.

| File at original RED | SHA256 |
|---|---|
| new test_observation_committed_registry.py,626 lines | 0d64a36778a1d010ba06f50d2ea8f137adac1bb43f27f9e5efc43fbdc4c58deb |
| subjects.py | 0a8eaee99b653a1b1823a1434c2e5ff1a2d468dc9659677cb426b33f6389b465 |
| server.py, untouched/outside this lane | cedcf801a9ede06cbddcc2de75a495068a0970c6785e68f8e5d9664e67c52f18 |

Earliest reached boundaries:

- 38 fourth-kind cases A–D failed on the absent
  `SubjectRegistry.prepare_observation_selection`. Their later exact witness,
  phase, safe-domain and fault assertions are **not yet exercised**, despite
  their test definitions. These are missing-contract RED, not independent proof
  of each downstream defect.
- Three valid direct-compatibility cases reached the original writer but hit a
  **test-fixture error**: `assert_selected` compared the entire registry_state
  table to the active-pointer tuple alone. The table correctly also retains
  registry_store_id. These3 are not product RED. The exact proposed correction
  preserves every original non-active registry_state tuple and substitutes only
  active_twin_id, still comparing the full sorted table. Their later four-event
  audit assertions did not run. Root was notified before correction/repeat.
- Three legacy forged preparations were actually accepted rather than rejected:
  float successor version, True→1 mapping_eligible alias, and invalid timestamp.
  The extra-evidence and malformed-digest rejection controls passed. Keep the
  intentionally altered private outcomes; do not repair them.
- Direct confirmed-close case reached the old writer's real successful commit
  and raised raw OSError from delegated close, not the required typed committed-
  cleanup outcome. No retry or rollback was performed to hide that result.
- Eight checked-action cases failed: three positive capture scenarios and two
  later-identity scenarios rejected reconcile_selection at the old allowlist;
  terminal/close fault cases likewise stopped at that old allowlist, before their
  intended fault; exact str-subclass rejection instead reached the deliberately
  forbidden connection seam. This last case is an input-admission tripwire, not
  an actual network/native attempt.
- The9 passing controls are legacy extra-evidence/digest rejection, stale pure
  digest rejection, pure detached preparation, four invalid checked actions, and
  unchanged startup inspect→reconcile confirmation. No claimed runtime GREEN.

This preserves all62 accounting:38 missing method +3 fixture failures +3 legacy
acceptance failures +1 untyped close +8 checked-action failures +9 passing controls.
No whole-foundation or ASGI packet was run here. The four excluded-process
obligations and all six scientific programs remain separate required work.

## Exact reusable initial command

From `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os, sys, signal, socket, subprocess, urllib.request, multiprocessing.process
from tools.run_review_stack import prepare_review_environment
review_root, env = prepare_review_environment(inherited={k: os.environ[k] for k in
    ('PATH', 'HOME', 'TMPDIR', 'LANG', 'LC_ALL') if k in os.environ})
os.environ.clear(); os.environ.update(env)
os.environ.update(PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
blocked, metadata = [], []
def deny(*args, **kwargs):
    blocked.append('unexpected')
    raise AssertionError('Registry review forbids network/child/native work')
def process(command, *args, **kwargs):
    if command == ['git', '-C', '/Users/emman/Livemore/.worktrees/full-scope-recovery', 'rev-parse', '--show-toplevel']:
        metadata.append('refused')
        raise OSError('Authored unavailable Git metadata')
    return deny()
def audit(event, args):
    if event in {'os.fork', 'os.forkpty', 'os.posix_spawn', 'os.exec', 'subprocess.Popen', 'socket.__new__', 'socket.connect', 'socket.getaddrinfo'}:
        deny()
sys.addaudithook(audit)
multiprocessing.process.BaseProcess.start = deny
socket.socket.connect = deny
socket.getaddrinfo = socket.create_connection = deny
urllib.request.urlopen = urllib.request.OpenerDirector.open = deny
subprocess.Popen = process
import pytest
signal.alarm(60)
print('PRIVATE_REVIEW_ROOT', review_root, flush=True)
rc = pytest.main(['-q', '-p', 'no:cacheprovider', '-p',
    'livemorebio.tests.test_committed_registry_transitions',
    'livemorebio/tests/test_observation_committed_registry.py', '--tb=line'])
print('REVIEW_IO_COUNTS', len(blocked), len(metadata), flush=True)
signal.alarm(0)
raise SystemExit(rc)
PY
```

The audit-hook/registry plugin refuses socket creation and child-process paths;
the new test's autouse fixture additionally traps AegleTwin and MetabolicProfile
constructors. Existing clinical constructor/compiler tripwires remain active.
Root review of this receipt and the narrow fixture correction precedes runtime
implementation; no additional run is implied by retaining the command.

## Approved assertion correction and exact corrected RED repeat

Root approved only the full-table fixture correction described above. The test
now retains every original non-active registry_state tuple, including the
immutable registry_store_id, then replaces/adds active_twin_id and compares the
complete sorted table. No other test assertion or runtime file changed.

Frozen corrected test: 630 lines, SHA256
`e64845fb99c0f76d76b23a055024e75d76cdd0cd33a588d308cf0f97518e2114`.
The subjects.py and server.py hashes in the original table remain unchanged.

Exactly the command above was repeated once against the corrected fixture:
**53 failed, 9 passed in 2.19 s**, exit 1. Private fixture root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-r9ghtp84`.
Tool result chunk `f458f7` retains the full failure list. The printed counters
were `REVIEW_IO_COUNTS 0 1`: zero unexpected I/O/native attempts, one refused
optional Git metadata call. No process remained running after the call.

All three previously fixture-blocked direct compatibility cases now pass their
exact row, timestamp, pointer, unrelated-record and immutable metadata checks.
They then reach the intended RED boundary: the old direct writer appends only
two audit events, whereas the approved full preparation plus committed mutation
requires four. Actual audit counts were 8 instead of 10 for different-target
and fresh-default cases, and 6 instead of 8 for the same-target case; original
audit prefix bytes were preserved. These three corrected failures are now
missing full-preparation audit evidence, not fixture failures. The original
three fixture failures remain separately recorded and are not retroactively
reclassified.

The other 50 failures and 9 preservation passes retain the original boundary
accounting above. In particular, the 38 new-method failures and the checked-
action allowlist failures still do not prove their later fault assertions have
executed. This is a corrected RED baseline only. Runtime implementation and the
two approved later inherited-test migrations remain held pending root review.

## Root RED review and implementation gate

Root read the full original626-line test, exact four-line assertion correction,
and this complete original/corrected receipt and guarded command. The corrected
53-failure/9-pass baseline is accepted as RED with the boundary limitations above;
the author's original fixture mistake stays recorded. Implement the approved
fourth fixed transition and checked-action changes in subjects.py, plus only the
two previously named inherited-test migrations. Preserve the62-case definitions
and current phase assertions. Report unexpected failures before any other test
change. The author must freeze source and provide GREEN/preservation evidence
for independent root review; this permission is not acceptance of the result.
