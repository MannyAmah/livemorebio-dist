# Legacy preview recovery: actual bounded acceptance

Status: the seven delivery/recovery cases passed; root inspected all twelve
original screenshots. This is a narrow software result, not full UI acceptance,
a biological experiment, clinical qualification or release approval.

## Exact run

- Private evidence: `/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-legacy-preview-uofz7at2`.
- Parent session27815, exit0, elapsed11.52414387499448s.
- Product source: `d0311baf6fd4cd8cc6754685471cc11bd8712c53b30afc952fb9295e31c5aac4`.
- Browser receipt SHA256: `704ff1c85497f7d2a510b681a6264fee831dbf0bfe57242d6b5d7d33900ac522`.
- Supervision SHA256: `8d9bccce48fcd2060775be1c41d0fbf22244ac015d9592d553fbff8343d0122b`.
- CJS source: `0a30991b4f7b0d84ac9c505838df1b53c927da11fda7a4a97d1a10430cea0b9d`.
- Both actual modeless baseline reads passed; both independent browser contexts
  acquired HttpOnly loopback sessions. All three actual service identities match.
- Four authored POST deliveries and exactly one follow-up GET per POST; zero
  service mutations, one explicitly unavailable genome-query fixture. No model
  was executed. Fixture values are labelled authored software-test data.
- Four owned direct children were reaped, thirteen recorded descendants absent,
  ports8910–8912 have no listeners, all five page/context/browser closes settled.
  No primary, cleanup or evidence failure. Existing8850/8890 services untouched.

## Inspected case outcomes

| Case | Actual interaction and observed outcome |
|---|---|
| D0 | Desktop opens authenticated observation-only source. Prior numerical values are absent; model-unavailable profile and recovery links are visible. |
| D1 | Healthy preview is held pending, old numbers clear; response B does not become authoritative over later read C. C is displayed with the request receipt. |
| D2 | Authored committed/cleanup-unconfirmed response keeps fresh C while displaying cleanup uncertainty and the matching receipt. |
| D3 | Note is typed and submitted by keyboard. Lost acknowledgment followed by an uncertain read clears plots/values and disables numerical use; no repeat POST. |
| D4 | Twins exposes selection reconciliation. Browser Back refreshes uncertainty; LIFE inspection remains available and Cendos History is empty. No reconciliation or experiment is run. |
| M1 | Fresh390×844 browser context repeats note submission with uncertainty and clears values. |
| M2 | Explicit fresh modeless read restores the model-unavailable profile while retaining the previous uncertain request receipt. |

Root personally opened `desktop-modeless`, `desktop-pending`,
`desktop-later-winner`, `desktop-cleanup`, `desktop-note-before`,
`desktop-unknown`, `desktop-twins-recovery`, `desktop-life-inspection`,
`desktop-history`, `mobile-note-before`, `mobile-unknown` and
`mobile-refreshed`. Each exact original image hash is in the receipt; no collage,
replacement drawing or edited screenshot was used.

The six console-error events remain recorded. This run deliberately produces
failed delivery responses and a lost acknowledgment; its aggregate counter does
not independently establish every console message's cause. No zero-console-error
claim is made. There was no page-script failure and all request paths/statuses
are retained in the original receipt.

## Remaining visual findings and next correction

1. **Open navigation obstruction:** `index.html::showBanner` uses a fixed
   top0/z-index9999 panel. The model-unavailable notice visibly covers the shared
   navigation on desktop and mobile. Replace this one banner with a normal-flow,
   accessible status region in the existing page layout, retaining its text and
   error semantics. Write the failing layout/handler test before the small fix,
   then independently inspect desktop/mobile/keyboard. Do not restyle A+B.
2. The legacy page retains generic “reacting live”, “ENGINE” and “one beat, live”
   labels even while a model is unavailable. The authored fixture makes no
   biological claim, but the static labels need source-aware correction in the
   full claims/presentation review. Do not remove the existing cardiac functionality.
3. Recovery notices are readable and wrap without document overflow, but remain
   visually dense. Progressive disclosure/spacing belongs to the already retained
   simple-interface requirement, not permission to hide uncertain outcomes.
4. Mobile navigation scrolls horizontally within its own region; this is not a
   document-width overflow. Complete mobile/keyboard/200% navigation remains open.

The original two actual failed attempts remain FAILED with their original cause
limits. This successful diagnostic run did not establish why the preceding D0
failed. Do not retroactively label it a repaired product timeout.

## Continuation authority

The temporary product-source freeze for this actual check is released. The
preserved source above remains the accepted narrow baseline; subsequent reviewed
increments must record their new identity and regression evidence. Proceed with
the already reviewed molecular source/controller and physical v3 contract seams
under their named file ownership. No old data, installed release or operational
service is changed by releasing this development freeze. All R01–R51 scope and
the six exact experiment programs remain; recordings are still0/6.

Lesson: an automated delivery PASS is not the end of visual review. Inspect the
actual images; retain usability failures even when the underlying recovery
protocol behaved correctly.
