# Atlas source-extent arithmetic: frozen maker packet

2026-09-08. Implements only the pure-helper lane approved in
`2026-09-08-atlas-selection-presentation-correction.md`, including its independent
near/far, label-bounds and frozen-interface precisions. **Independent source
review and scene/controller/browser acceptance remain separate.** This is not a
replacement for the retained failed Atlas acceptance or evidence of physiology.

## Scope and hashes

Only two new code/test files and this report were authored in this lane:

| File | SHA-256 |
| --- | --- |
| `livemorebio/aegle/console/lib/atlas_reference_presentation.js` | `325bf0f647ae02c7b47dcc29c9d5a91a6f1f6b50a89206fd538afabdc34378fd` |
| `livemorebio/tests/test_atlas_extent_projection.py` | `77ddc776b85ac6503b7f6d6470e82c50cbdff9672393ed2cd9c6d4ad7c843931` |

The helper is47 lines; the215-line test file contains71 collected cases. Renderer,
controller, CSS, THREE/vendor, geometry arrays, manifests, sources and all numerical
code were untouched by this maker. Root owns renderer/CSS, the UI maker owns the
controller. No browser, GPU, source download, package install, service, clinical
record or model execution was used.

## Exact semantics

`projectedSourceExtent(corners,width,height,near,far)` returns a new
`{x,y,width,height}` or null. It requires exactly eight supplied objects with
finite numeric x/y/z/depth, finite viewport dimensions greater than16, and
finite positive near/far with far>near. All eight corners contribute to extrema.
Camera-space forward depth, in the camera's units, is authoritative: any corner
at/before near suppresses; an extent entirely at/beyond far suppresses. NDC z is
also required finite. A box only partly beyond far remains a box cue; no clipped
surface, occlusion or projected contour is inferred.

NDC x/y extrema are intersected with the viewport before multiplication. This
avoids overflow from otherwise finite extreme projection coordinates. Screen y
is inverted, subpixels are retained, then the rectangle is clamped to the fixed
8px inset. Offscreen, edge-touching and empty/zero-area results return null;
there is no emergency full-canvas rectangle or geometry/camera adjustment.

`boundedExtentLabel(extent,labelWidth,labelHeight,width,height)` returns a new
`{x,y}` or null. Extent fields and measured label sizes must be finite numbers;
rectangle and label sizes must be positive. Labels that cannot fit wholly inside
the same viewport inset are suppressed. Otherwise the extent's x/y is preferred
and the label anchor is clamped independently. It does not grow, move or reframe
the source extent, and it makes no assertion about text metrics supplied by the
renderer. Inputs are never mutated. Neither helper imports libraries or accesses
DOM, network, storage, camera, scene or source objects.

## Red/green evidence

Command, from the full-scope-recovery checkout:

```text
/Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B tools/run_review_tests.py -q -p no:cacheprovider livemorebio/tests/test_atlas_extent_projection.py --tb=short
```

The existing Atlas Node test helper runs each module assertion under its bounded
20-second subprocess timeout. Actual Node runtime: v26.0.0 at
`/opt/homebrew/bin/node`. No third-party JavaScript API is used by this helper.

- RED before implementation:71 failed in4.93s, isolated root
  `livemore-research-review-a28f7jhu` (`--tb=no` for this first run). A separate
  exact eight-corner case with `--tb=short` confirmed ERR_MODULE_NOT_FOUND for the
  not-yet-created helper, one failed in0.12s, root
  `livemore-research-review-k7hbol39`.
- GREEN after implementation, without changed assertions:71 passed in5.08s,
  root `livemore-research-review-g92rkmuc`. No warnings or skips.

Coverage includes viewport17/17.5/390/768/1440 sizes; every corner's influence;
near equality/crossing and finite behind-camera projection; wholly/partly far;
partial/full offscreen and inset-only exclusion; coincident projected corners;
sparse/wrong-size/malformed containers; strict no-coercion numeric fields;
nonfinite/large finite values; deterministic subpixel output; frozen input objects;
long labels, exact fit, tiny extents and impossible labels. A fixed arithmetic
grid additionally checks every returned extent and label remains finite and
within the inset. These assertions do not measure rendered pixels or anatomy.

## Handoff and compounded lesson

Code/tests are frozen for the parent and independent reviewer. Combined scene/
controller preservation and ordinary browser acceptance are not claimed here.
The API deliberately represents a projected **source box**, not a surface contour:
bounded arithmetic cannot resolve source overlap, camera occlusion, label layout,
GPU visibility or biological truth. Keep those claims and their acceptance gates
separate rather than changing geometry to make selection appear cleaner.
