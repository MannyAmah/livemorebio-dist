# Explicit reconciliation after an uncertain subject-selection commit

Date: 2026-09-08. Status: independent-review proposal for root approval before
implementation. This is an additive recovery contract under section 11 of the
[clinical availability amendment](2026-09-08-clinical-context-availability-amendment.md),
not approval of a new model, physical device, registry migration or release.

## Why a separate operation is necessary

An observation-selection commit can succeed in SQLite while its acknowledgment
and immediate recovery read fail. The product must then retain `DENY_ALL`, not
repeat the mutation or choose between the old and requested person from memory.
The existing candidate summary is not proof of which record is authoritative.
Historical inspection, descriptive onboarding and explicit owned cleanup remain
available while numerical capture and advancement remain denied.

The independent registry review also found that an inner join could turn a
missing active-pointer target into an empty selection and a healthy preview.
The reviewed correction now distinguishes an absent pointer from a present but
incoherent target. Reconciliation must use that checked, audited contract, never
an inner join, cached `_state`, the global bus or a caller-supplied subject.

## Fixed route and admission

Add authenticated `POST /api/twins/reconcile-selection`. Accept exactly the JSON
object `{}` using the existing bounded strict-body reader: reject duplicate keys,
unknown fields, arrays, non-finite numbers and oversized bodies before registry
access. There is no subject ID, version, generation, mode or model choice in the
body, query or caller headers. Require current product authority to be `DENY_ALL`;
otherwise return a fixed conflict without rotating a healthy authority.

Generate one server-owned canonical UUID request ID before registry access and
return it in `X-Request-ID`; do not invent an ID after a lost acknowledgment.
All responses are private/no-store, with existing fixed, PHI-safe errors. Use the
shared encrypted registry audit and its reserved begin/result semantics. Add the
explicit allowlisted `reconcile_selection` action through the registry owner's
reviewed audit interface; no parallel audit database, clinical audit values or
unaudited decryption. Failed attempts retain their access result/reservation.

## Authoritative read, precomputation and final check

1. Perform an audited authoritative active-record read. A genuinely absent
   pointer permits the already supported unregistered reference-preview path;
   a present missing/non-TWIN/inactive/incoherent target is an operational error.
   Wrong-key, corrupt storage, audit exhaustion and an unreadable pointer remain
   operational errors. None is scientific model unavailability or an empty
   selection. The separate legacy zero-audit bootstrap blocker is not bypassed.
2. Freeze the complete authenticated record and pointer identity for this read.
   Prepare a detached subject summary, observation-only or supported-model
   availability, fresh observation state, empty action list, success/error
   responses and a fresh generation before the final commit interval. Use the
   existing explicit model-context resolver; never infer a model from clinical
   prose or substitute healthy physiology for an unresolved person. Any permitted
   constructor runs outside source/manager/registry commit locks.
3. Acquire the established lock order: authority, manager-creation lock when
   needed, execution manager, registry transaction. Require authority still to be
   `DENY_ALL`. Re-read the checked active pointer and authenticated record under
   the audited registry transaction. Compare exact canonical record content as
   well as ID/version; a same-version edit or absent/present transition conflicts.
   Do not silently restart this preparation or repeat a selection mutation.
4. Confirm the read-audit outcome before installing authority. Registry records,
   active pointer, versions, ciphertext, idempotency indexes and clinical AAD are
   unchanged by this route. An uncertain read/audit transaction outcome leaves
   `DENY_ALL`; it does not become a successful reconciliation.
5. Once the final read and audit are confirmed, install only the precomputed
   state and fresh generation while the authority/manager locks remain held.
   No serialization, constructor, network request, execution-store operation or
   native cleanup belongs between that confirmation and the memory assignments.
   Old executions remain tied to their old generations and are never revived.

This is the existing single-product-authority model, not an atomic transaction
across SQLite, process memory and arbitrary external database writers. Other
product selection writers must use the same authority contract. Do not claim
distributed or direct-database-edit synchronization from these local locks.

## Speculative identity and cleanup are separate concerns

Before reconciliation, `/api/twins` must not advertise the speculative candidate
as confirmed `active` merely because `_state.subject` is non-null. Return an
explicit selection-unconfirmed marker with no asserted active identity, while
allowing the separately audited record list to remain inspectable. Workspace,
Biology, execution and Cendos retain the operational uncertainty, not an
`UNAVAILABLE/MODEL_BINDING_REQUIRED` disguise for an unknown selection.

Physical observation intake is independent of numerical model readiness but not
of subject-selection certainty. During `DENY_ALL`, reject projection/binding that
depends on the current selected person before replay/admission watermarks or
observation state change. A confirmed observations-only REAL_HUMAN selection
continues to permit its separately governed physical-evidence path; no numerical
model is required merely to inspect admitted measurements.

Reconciliation does not claim prior worker shutdown succeeded, release retained
OS ownership or retry an observation/selection POST. Existing local pending
cleanup remains visible and prevents new native work. The operator uses the
existing explicit Stop cleanup seam with freshly inspected preconditions. The
reconciliation response distinguishes restored authority from cleanup readiness.

## Required red tests before implementation

- Auth and exact empty-body validation precede any audit/read; ready authority
  rejects; two concurrent reconciliations cannot both rotate generation.
- A committed-to-new-person outcome, confirmed prior-person outcome and genuine
  no-pointer outcome restore only the authoritatively read selection. A missing
  target, inactive/mismatched payload, wrong key and audit failure never preview.
- First read followed by a different pointer, version or same-version content
  change conflicts without memory assignment or automatic retry.
- The success path leaves exact registry record/pointer/idempotency bytes and
  versions unchanged, records the exact request audit, and installs one fresh
  generation before any blocked old initialization/frame can commit.
- Audit/commit uncertainty keeps `DENY_ALL`; late failure never restores an old
  source. A lost HTTP acknowledgment does not repeat registry selection or
  restart old executions; a subsequent POST outside `DENY_ALL` conflicts.
- The twins list does not expose a speculative active identity; current-person
  physical projection cannot mutate watermarks/state while selection is unknown.
  Confirmed observations-only intake remains distinct from model readiness.
- Pending cleanup ownership survives reconciliation; current-generation prepare
  may remain available, but new native work remains blocked until explicit
  cleanup is confirmed. History remains readable with original attribution.

Root must review this proposal and its typed response/audit interface before
implementation. Existing 247 registry tests and technical execution race tests
are separate evidence, not acceptance of this unimplemented route.
