# OSP initialization-contract technical successor

2026-09-09. Written before successor implementation. Root accepted the separate
initialization-contract correction after 656 independent offline passes. This
plan permits only a fresh private once-launcher and offline tests, not execution.
R01–R51 and all six scientific experiment/video requirements remain unchanged.

## Minimum implementation

Reuse the reviewed qUfcQ6 `run_packet_once.py` in a fresh private control root.
Preserve every consumed launcher, authorization and failed packet. Update only
the root, current supervisor/collector pins and the following additive startup
contract binding:

- Supervisor: `c3f5ec38a25be726a4d939c55f9a22b9fd41e45e9f21c7af43cb1b8a5ab67923`.
- Collector: `e108ff061e0f15a030eac3a2f80e0279edc12783eca866e210518c1da8fdd7c7`.
- Startup manifest: `70bed51c6cd58a70586fa9f59aa1d1fcddf0674029e14e1ae11a116ec1082d24`,
  at `docs/solutions/2026-09-09-osp-r-startup-contract-v1.json`, capped at 64 KiB.

Add this seventh input to the existing pin/identity machinery. Keep the existing
authorization schema and the scientific identity's three fields; bind the fresh
launcher hash as before. Require the loaded supervisor's manifest path/hash to
match before any in-memory gate change. Check packet/case manifest attribution
and acknowledged initialization for claimed successful cases, without masking
failed cases. Preserve exact returned/on-disk equality and all other predicates.
These checks verify producer claims; they do not replace independent inspection
of handoff files in an eventual retained packet.

Preserve S01–S17, 16 Run calls, first-failure stop, exclusive once consumption,
owned cleanup, limits, environment and false model admission. No new process
framework, OS API, dependency, protocol, numerical case or product mutation.
Initialization reserves 16 KiB/five entries inside existing case limits.

## Evidence before execution

Copy and preserve the 72 existing offline cases; explain exact fixture identity
updates and obsolete pin-count/source-substitution assertions. Add RED-first
cases for absent/stale startup manifest pins, producer binding disagreement,
missing/incorrect initialization claims, failed-result preservation and source
gate restoration. Root independently reviews the exact delta, tests and pins.
Do not create an authorization/once artifact or run R/CLR under this plan.

The historical Yc5Y4i O1–O7 receipt remains limited evidence for unchanged native
ABI, ownership and cleanup mechanisms. Its old unchanged-classifier rationale
does not cover the new initializer. Root accepts it only for those unchanged
mechanisms, alongside current source/offline review of the exact new topology;
this is not fresh preflight or validation of actual R startup. Do not repin or
invoke the old preflight driver: its Policy lacks the new initialization keyword.
A separately recorded root run decision must state this limit explicitly before
one technical packet can run. No concurrent browser/native job is permitted.

After any separately authorized run, preserve every original failure and inspect
the exact packet, reached cases, two bounded handoffs and pending evidence, source
pins and owned cleanup. A pass remains technical execution evidence, not source
qualification, human equivalence or the requested insulin experiment.

## Maker freeze — inert private successor

Prepared `/private/tmp/livemore-osp-native-once-initialization.oWpRO1` (0700).
No actual authorization, once marker, completion, home, tmp or cache exists there.
Consumed qUfcQ6 and CA533x launchers/tests remain unchanged; current repository
supervisor/collector/pure/manifests remain at the approved pins, with both source
execution gates false. No real supervisor, R/CLR, native preflight, process probe,
browser, network or model run occurred. This is a maker receipt, not approval.

RED `186848` ran against the byte-identical qUfcQ6 launcher
`4e3663b182f901a9d82df03ba39d8aa30f7d140205bc36167069e0a7a2b6e2df`:
28 failed / 81 passed in 0.83 s, unexpected I/O 0. After only the approved launcher
delta, GREEN `853014` passed 109 in 0.85 s; repeat `e92768` passed 109 in 0.72 s,
both unexpected I/O 0. The same tests and refusal wrapper were used throughout.

The 72 inherited cases remain: the original 45 test bodies are unchanged. Their
copied fixture adds an authored seventh input, loaded producer path/hash, packet
attribution and successful-case initialization claims. The fixture deliberately
supplies that input even to the RED baseline so rejection tests reach the missing
producer/claim checks; the separate production-pin assertion detects an absent
seventh pin. The copied 27-case evidence suite updates fixed path/supervisor pin,
the identity count from seven to eight, and replaces its two obsolete byte-exact
two-substitution assertions with AST preservation checks excluding only HERE/PINS,
the two changed launcher functions, and the one changed producer fixture. These
are not substitutes for root reading the complete retained diff. No inherited
test was removed. The 37 additive cases cover exact manifest binding/bounds,
input and authorization refusal, pre-gate producer disagreement, successful
packet/case claims, first/last case coverage, exact boolean acknowledgement,
failed-packet preservation, post-call pin changes and gate restoration.

The launcher adds no helper/framework. Only HERE, supervisor/collector pins,
the seventh 64 KiB manifest pin, `run`'s pre-gate producer binding and
`admit_packet`'s successful-result claim checks change. Existing failed packet
and case checks precede the new claims, preserving original rejection outcomes.
Authorization identity has seven input hashes plus the launcher hash; its schema
and the scientific identity's three fields remain unchanged. These authored
tests intentionally do not pretend that producer claims validate physical
handoff files. Independent bounded data review remains required after any
separately authorized actual attempt. The historical OS-receipt limitation above
still applies; its old Policy was neither repinned nor invoked.

Frozen files in the private root (SHA-256):

```text
run_packet_once.py
58fe279b9a5ce21fc1f2b8fdbb06391ecf7065b7952146738bc3a48a27d6a8bf
test_packet_once.py
db63defdb6975a40f5f3d8b5ddb8905a7cafb02e67c1cfcc797ec41c2aa7acab
test_packet_once_evidence.py
96fa8f5baf99048c5cdac4d3cb60f13cf1e3cfbee6966ed0914e3f3b41a64673
test_packet_once_initialization.py
c036bfd508445a1a51a6ffb620d8904e6305a74debb10ace258c517238454a28
repeat-offline.sh
bfc0cfbbd2c2c70822a260a97737693c9e966b9fd5aeb20b39956a24fcde9faa
source-tests.diff
75e86b114018f61ae9078b52197085e978c00aa4ae52599261ed1d37806cbd90
red.txt
67bca422a8a0e7cce8186c1aa5868bfcc4d622bb28fc395c2e3f2ba491ce65a0
green.txt
68aeccd1e27d5bd9938b61dfdc0f0f0d8f19217e2a4b3bb29f45d345a1620705
repeat.txt
baf4e0b7066a39f6dd7358778cb61f0832b12df6e3bf9fa96355cc65ded98701
```

`frozen-pins.txt` retains all seven actual input hashes and predecessor hashes
from data-only check `acadad`. Repeat from the worktree with:

```sh
sh /private/tmp/livemore-osp-native-once-initialization.oWpRO1/repeat-offline.sh
```

It uses the existing isolated review-environment preparation, disables plugin
autoload and bytecode/cache writes, refuses child/native/network calls, and
loads only authored supervisor stand-ins. Root independent grading and a
separate once-only actual decision are still required. No follow-on run is
authorized by this freeze.

### Fully resolved prospective command — NOT AUTHORIZED

This is the previously reviewed isolated launcher-entry command with only the
fresh fixed paths and launcher hash substituted. Do not execute it or create
authorization under this preparation plan. A separate root decision must first
confirm independent grade, all frozen pins and settled exclusive browser/native
ownership. The canonical authorization keeps OSP_NATIVE_ONCE_AUTH_V1 and now binds
the seven pinned inputs plus this launcher hash (eight identity fields).

```sh
env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C PYTHONDONTWRITEBYTECODE=1 \
 HOME=/private/tmp/livemore-osp-native-once-initialization.oWpRO1/home \
 TMPDIR=/private/tmp/livemore-osp-native-once-initialization.oWpRO1/tmp \
 XDG_CACHE_HOME=/private/tmp/livemore-osp-native-once-initialization.oWpRO1/cache \
 /Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -I -B - <<'PY'
import hashlib,os,stat
from pathlib import Path
os.umask(0o077)
path=Path('/private/tmp/livemore-osp-native-once-initialization.oWpRO1/run_packet_once.py')
fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
with os.fdopen(fd,'rb') as stream:
 info=os.fstat(stream.fileno())
 if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:raise RuntimeError('LAUNCHER_IDENTITY')
 raw=stream.read(1024*1024+1)
if len(raw)>1024*1024 or hashlib.sha256(raw).hexdigest()!='58fe279b9a5ce21fc1f2b8fdbb06391ecf7065b7952146738bc3a48a27d6a8bf':
 raise RuntimeError('LAUNCHER_CHANGED')
exec(compile(raw,str(path),'exec'),{'__name__':'__main__','__file__':str(path)})
PY
```
