# Supported-workflow recordings — September 9

Record actual browser actions against the isolated 8868/8869/8870 stack, after
testing the same workflow. Preserve the uncut original WebM and a playable MP4.
No screenshot montage, injected result, scripted biological outcome, borrowed
physical measurement, or replacement for the six requested candidate experiments.

Two bounded walkthroughs:

1. Aegle whole-person Atlas, distinct reference/research twins and cohorts,
   explicit virtual LIFE numerical execution with model time and independent
   controls, matching Aegle acknowledgments, selected-run Biology, and ordinary
   cardiomyocyte / local hERG reference inspection. Clearly distinguish the
   systemic execution, cell-model trace and static molecular coordinates.
2. Cendos clean preparation, verified Human-GEM source and explicit oxygen/glucose
   constraints, actual solver execution and negative controls, selected-result
   Biology, exact condition data, history and rerun preparation, and downloaded
   analysis outputs. This is generic steady-state network capacity, not a drug,
   individualized cohort or physical experiment.

These are usability and numerical-workflow evidence only. R40's insulin and five
botanical experiments remain separate, not satisfied by either walkthrough.
Only the review store receives new synthetic/research records. Existing installed
products, real-person data and earlier evidence are untouched. Do not add idle
time merely to inflate duration; allow readable pauses and retain execution time.
If a workflow fails, preserve that finding and fix/retest before a final recording.
Give a chaptered viewing guide and exact result/source IDs with the recordings.

For the recorded analysis step, use an owned token-protected JupyterLab bound
only to127.0.0.1:8873, rooted at the non-PHI workflow deliverables directory,
with a fresh private runtime directory. Keep its generated token in that private
runtime only; do not print it or record it in the address bar. Open the exact
downloaded notebook, inspect its code, execute its stored-result validation and
plot cells explicitly, and show outputs. No new biological result is generated
by these analysis cells. Stop the owned Jupyter process after capture; preserve
the source notebook separately from the executed copy.

## First capture: valid source-change refusal, not the final walkthrough

The first Atlas/cohort/twin/LIFE capture on September 9 reached LIFE preparation
while the newly approved viewer/package changes were still being finished.
The running server correctly refused preparation because source files differed
from its startup identity. No automatic retry or execution was performed.
The uncut recording is preserved as `diagnostic-source-change-refusal.webm`,
not counted as a successful walkthrough. Final recordings require the source
freeze and a normal restart of the isolated review stack first.
