# Molecular reference source admission

Current status (September9): original coordinates independently reviewed; the
reader and narrow package/fingerprint additions have47 maker passes and await
independent implementation admission. The historical steps below are retained.
Parent is the approved structure-only inspector plan and R03/R23/R24, not a new
experiment or reduced target list. No API/controller is installed yet.

## First read-only step

Root read the RCSB skill, its source-presentation instructions, canonical source
mapping and local wrapper. Use its existing `scripts/rest_request.py` for six
fixed public metadata GETs at `https://data.rcsb.org/rest/v1/core/entry/` followed
by `4OBE`, `1TUP`, `1M17`, `4INS`, `1N7D`, `6P2B`. Each request has a30-second
timeout. No search, participant data, credentials, archive, structure execution,
model evaluation, package install or service interaction is involved. Retain the
result/source provenance and original entry IDs; do not silently replace an entry.

Inspect current source revision, title, method, resolution, entity/model/atom
counts and species/construct evidence. Missing fields require a specific follow-up
to the returned entity IDs, not guesses from the target name. Metadata availability
does not admit the candidate for a given human target. Coordinate acquisition is
a separate fixed six-file, bounded, original-byte proposal after this inspection.
The existing21 target mappings remain in scope; no unknown mapping becomes a
positive molecular interaction or an executed reaction.

All six first GETs returned200, but the skill's default five-key summary omitted
the fields needed for admission. Retain these as successful connectivity/entry
lookup only, not completed source review. Perform one second exact six-entry
metadata batch with original JSON retention in the new private directory
`/tmp/livemore-molecular-metadata.nBet7P/`, bounded summaries at100 items/depth8.
This is an explicit format-completeness correction, not a coordinate download or
silent retry. Original raw JSON remains separate from summarized skill provenance.

## Metadata result and next original-byte acquisition

All second entry requests and nine returned polymer-entity requests succeeded200
without warnings. Raw originals are retained separately as `<ID>.entry.json` and
`<ID>.entity-<n>.json` in the private directory above. Current entry evidence:

| Reference | Revision | Resolution Å | Source detail retained |
|---|---|---:|---|
| [4OBE](https://www.rcsb.org/structure/4OBE) | 1.2,2023-09-20 | 1.24 | Human KRAS fragment1–169, GDP-bound; entity1, chainsA/B; P01116; E.coli expression host |
| [1TUP](https://www.rcsb.org/structure/1TUP) | 1.3,2024-02-14 | 2.2 | Human p53 entity3,219-residue sample, authorA/B/C versus labelC/D/E; two synthetic DNA entities1/2; P04637 |
| [1M17](https://www.rcsb.org/structure/1M17) | 1.3,2024-02-14 | 2.6 | Human EGFR kinase fragment671–998 with erlotinib, not full receptor; P00533; insect expression host |
| [4INS](https://www.rcsb.org/structure/4INS) | 1.5,2024-10-23 | 1.5 | Pig insulin, both entities taxon9823/P01315,21/30-residue chains; not human INS reference |
| [1N7D](https://www.rcsb.org/structure/1N7D) | 2.4,2026-08-12 | 3.7 | Human LDLR extracellular699-residue sample, two annotated mutations, P01130; not intact membrane receptor |
| [6P2B](https://www.rcsb.org/structure/6P2B) | 1.2,2023-10-11 | 2.3 | Tethered PXR-LBD/SRC-1p with garcinoic acid; O75469,344-residue sample; no native whole-cell claim |

All entries report one deposited model. Deposited atom count and hydrogen count
are distinct RCSB fields and will not be assumed to equal parsed atom-site rows.
Sequence coverage is not coordinate completeness or physiological applicability.
The source-link helper overgenerates possible structure links for unrelated
four-character tokens (e.g.CCP4/taxonomy IDs). Use only exact validated entry-ID
canonical links above; preserve raw JSON without those helper additions. No plugin
modification or unrelated external bugfix is included in this build.

[wwPDB usage policy](https://www.wwpdb.org/about/usage-policies) states CC0 for PDB
archive data and requests author attribution. Preserve author/citation/source
fields; rights availability is not a scientific-validation claim.
[RCSB file documentation](https://www.rcsb.org/docs/programmatic-access/file-download-services)
explicitly supports uncompressed text mmCIF. Root authorizes one fixed download
per candidate from `https://files.rcsb.org/download/<ID>.cif`, uppercase IDs
exactly as this table, into the same private directory; no automatic discovery,
alternative ID, file overwrite or runtime network path. The earlier web-tool
check of the compressed wwPDB4OBE path returned a non-retryable tool URL error;
no bytes were acquired there. The documented uncompressed path avoids that format.

Use existing curl with no redirects/retries, no proxy/credentials/config inheritance,
HTTPS only, identity encoding,30s timeout and8MiB maximum per file/48MiB total.
Retain response status/content headers, exact original bytes and SHA256. Any
non200, redirected/encoded/oversize/non-mmCIF response stays unadmitted; do not
repair it. Then inspect data with the existing trusted mmCIF parser, checking
entry/revision/model/atom/entity/chain and coordinate fields. This is inert data
inspection, not a molecular solver, docking, rendering or human equivalence test.
No coordinates enter the product until the descriptor/source review is complete.

All six original-coordinate GETs succeeded200, no redirect or Content-Encoding,
`chemical/x-cif`, each below0.5s and8MiB. Both existing Python environments lack
Biopython/Gemmi. For independent data inspection use the published Biopython1.88
mmCIF dictionary reader, whose complete primary source and official API were read,
rather than implementing another CIF parser. Authorize a single binary-wheel-only,
no-dependencies/no-compile Biopython1.88 install into the new private
`biopython-check` subdirectory, without changing either Python environment or the
product. Use explicit PyPI and retries0/timeout30. Inspect retained package files
and identity before reading coordinates; no molecule/solver code is invoked.

## Original coordinates and parser result

The single private Biopython1.88 wheel installation succeeded. It changed neither
Python environment nor the product. The retained reader SHA256 is
`0b418606f5fea90a4841f54b9415ebd7351677f0a670c55e9c4ec4aaf72a3d8a`.
The data-only inspection completed in1.4134s: all six hashes, entry IDs, revision
dates/numbers, model IDs, equal atom-column lengths, unique atom row IDs and finite
Cartesian coordinates passed. No network, child process, solver or model was used
by inspection. The original receipt is
`/tmp/livemore-molecular-metadata.nBet7P/coordinate-inspection.json`, SHA256
`acfd020938507cd799c5bd9d07e4b08dc5272188c0d9e27a06f6f8535cbba6cf`.
This is maker data inspection, not independent product/browser acceptance.

| Entry | Original bytes | Atom-site rows | H/D rows | Original SHA256 |
|---|---:|---:|---:|---|
| 4OBE | 888328 | 5725 | 2632 | `bc5738721380320d37c216a8f4412ddd3f66fad375c60fc0d0626bc6c277e5d7` |
| 1TUP | 698225 | 5828 | 0 | `cbc6ebdae1444998cf55744339e1a500d8822ac0761841d1eed96f5e8b59cb37` |
| 1M17 | 307709 | 2560 | 0 | `849bd2548dffb7ddcb7229a05202c1e2e41019a1fd69ec39483654cf984fc4d0` |
| 4INS | 186101 | 1182 | 0 | `05f3c80f9e87d76f781d8d37d890c8c5707daaa41e3334fbb91e047ae63c8b38` |
| 1N7D | 652947 | 4956 | 0 | `b9abcf21b6c0faa5c78e3562904cdfa55b324e64cb8fabdfdd0ff92b7908f31b` |
| 6P2B | 556174 | 4914 | 18 | `af61cc3ffddf6b89d68f85482a2c152fa25cfc11c5b097eca0eb0578b0ef2ed5` |

All have one deposited coordinate model numbered1. Atom-site rows are not unique
chemical atoms: alternate locations remain in the unmodified files. RCSB's
deposited atom count excludes the separately reported hydrogen rows in4OBE and
6P2B. The view must disclose both counts, not silently equate them.

Source details confirmed in the coordinate data:

- 4OBE has a leading expression-tag glycine in each KRAS chain.
- 1TUP's protein author chainsA/B/C are label chainsC/D/E; DNA uses the other
  entity/chain IDs. Selection must not silently swap these naming systems.
- 1M17 has five cloning-artifact residues before the EGFR kinase fragment.
- 4INS is Sus scrofa9823, not human9606; preserve it as a non-human reference
  related to INS, never as the admitted human INS structure.
- 1N7D has engineered ASN→GLN at author residues494/636, corresponding to
  UniProt515/657. It is an extracellular construct, not a native intact receptor.
- 6P2B has39 annotated expression-tag residues per chain (sample1–11 and317–344)
  around the aligned PXR fragment; retain the tethered SRC-1p context. Raw entity
  metadata confirms NR1I2/PXR as source gene labels. No kinetic affinity or
  physiological effect is derived from these static coordinates.

## Next implementation seam (within the reviewed parent plan)

Prepare the fixed descriptor/catalog and a small data-reader module in this
private molecular directory while the actual browser check requires the current
product source to stay frozen. Do not alter installed files, active stores,
existing seed mappings or the product fingerprint during that check. Root owns
this source/API seam; the UI agent owns the separate build/controller seam.

The catalog retains all21 organ targets plus the inherited KRAS/TP53/EGFR/LDLR
and PXR/NR1I2 keys. Unknown mappings stay explicit; AMPK/GLUT1 do not trigger a
first-hit search. INS has no admitted human structure here and exposes4INS only
as a clearly named related pig reference. Descriptor facts come from the original
CIF and selected source-identifying metadata fields, not bundled third-party
annotations/DrugBank prose in the expanded RCSB response. Preserve original
metadata privately; do not redistribute the entire augmented API response under
the archive's CC0 notice.

The reader uses only stdlib importlib.resources/path readers, exact packaged
names and SHA256 checks, with no network/model import/cache writes. Tests first
expose the absent reader; then verify exact bytes, descriptor copies, unavailable
and ambiguous mappings, human/pig separation, corruption and path/digest rejection.
The protected API remains the already reviewed two-route seam, reusing existing
authorization and fixed metadata-only access auditing; no new auth framework.
API/consumer integration follows release of the source freeze and independent
reader/source review, not another scientific scope change.

## Reader implementation receipt and next API seam

The actual legacy-recovery source freeze was released after root inspected its
successful twelve images. The six original CIF files and catalog were copied
unchanged into `livemorebio/scientific_sources/data/molecular/`; private originals
remain intact. The new stdlib reader has no source discovery, numerical imports,
store access or writes. It verifies fixed original bytes, prevents linked/nonregular
file reads, bounds reads, and returns fresh descriptors. Package-data patterns
include only the new catalog/CIF files; source identity now includes `.cif` under
the existing runtime-asset roots. No other data directory enters the fingerprint.

Actual RED/GREEN progression (all use the existing private refusal wrapper):

- Original absent module:43 failed in0.30s, retained output3a129b.
- First implementation:24 failed/19 passed in0.20s, privateakp1f5cs. The handoff
  confused catalog Unicode character count60,290 with UTF-8 bytes60,294. SHA256
  was correct and unchanged; the reader correctly refused the wrong length.
- Corrected byte constant:43 passed in0.12s, privateyyxra66i.
- Four added package/identity/zip-resource/linked-catalog checks:2 failed/45 passed
  in0.22s, privateijqagc8m, exposing missing package patterns and CIF fingerprint.
- Two narrow production corrections:47 passed in0.17s, privatex1uy63go.

Every guarded invocation reported zero unexpected I/O and zero authored Node
processes; only the fingerprint tests refused the optional Git lookup once.
The zip-resource test is not an installed-wheel or actual-browser acceptance.
Catalog SHA256 `89a15b12f2dbe5aac1edc53885b525c72863b3bb915a6c3e81a044f74ed67360`.
Original source files and full augmented API responses remain separately retained.
Independent catalog/reader review precedes route publication.

API engineering amendment for review before code: the existing `audit.record`
swallows append failures, so simply calling it cannot meet the approved fail-closed
access-audit contract. Reuse that recorder with an opt-in keyword-only `strict`
path, leaving existing callers unchanged. Strict mode rejects invalid/unreadable
signing keys without replacing them, creates only an absent key exclusively,
durably appends the existing metadata-only record, and propagates a fixed audit
failure. Existing signing format stays unchanged; no new audit store, patient
registry dependency, background agent or authentication framework. Tests first
cover bad key preservation, simultaneous creation, append/fsync failures and
fixed errors. This is a limited public-reference access improvement, not an
application-wide audit/security qualification.

The two routes authorize first, reject extra/duplicate query fields or any body,
then read only the catalog/coordinates. Valid responses retain startup identity,
no-store, reference-only descriptor and content SHA; every expected/unexpected
failure uses fixed text. Audit only the fixed operation, admitted public asset
identity (or null), fixed outcome and public build provenance—never caller text,
subject identifiers, cookies or coordinates. Audit failure returns503 and no
reference bytes. Wrong methods do not invoke the reader. No route change before
independent review of this minimal strict-audit amendment.

Lesson: hash and length must both describe encoded bytes, not display characters;
preserving species/construct identity is essential even when a legacy identifier
looks like the intended human target.

### Independently reviewed strict-audit implementation contract

Root approved this bounded increment before code: only `audit.py` and new
`tests/test_strict_pipeline_audit.py`, plus its evidence report. Root owns the
two API routes. No services, operational stores, PHI, native work or migration.
`record` adds only keyword-only `strict=False`; existing positional parameters,
canonical JSON, record fields, HMAC input and accepted existing normalized key
material remain unchanged. Legacy append failures remain best-effort.

- Shared key handling must never truncate/replace an existing key, including
  calls through legacy `sign` and `verify`. Preserve all existing raw bytes and
  the former accepted `raw.strip()` material (at least32 bytes). Verification
  reads only and never creates a key. Missing key with a nonempty existing log
  fails, rather than silently starting another signing epoch. New raw32-byte
  keys use at most32 attempts to obtain strip-stable material; publish a fully
  written, fsynced0600 temporary file by no-overwrite hard link, then sync its
  directory. A concurrent creator reads the complete winner. No key read-size
  cap silently invalidates a formerly accepted longer key.
- Both append callers use the same log-inode nonblocking exclusive flock with
  a fixed one-second acquisition budget. There is no new lock store. Under
  that lock require empty/newline EOF, append one pre-encoded record, detect
  short writes and fsync before strict success. Strict records are at most
  16KiB including newline. Short write/fsync/close/publication errors preserve
  whatever actually reached disk and fail; never truncate, repair or retry an
  uncertain append. An existing partial final line rejects later appends.
  Reject symlink/nonregular key or log targets. Sync newly created directory
  entries; do not claim durability if a sync or close fails.
- Strict metadata requires explicit dictionary provenance, exact dictionary
  inputs/outputs, a bounded action string and finite JSON-built-in values;
  reject unsupported values, excessive nesting/size and `log=False` before
  file access. Route-level fixed metadata allowlists, not this generic recorder,
  exclude caller/subject/coordinate contents. Supplying provenance avoids the
  legacy optional Git lookup. Every strict failure is the same fixed
  `AuditError`/`AUDIT_UNAVAILABLE`, without raw exception text.
- Root's route sequence remains authorization, bounded empty-body/query
  admission, fixed reference read and response preparation, then durable strict
  audit before returning bytes. Expected read failures get fixed outcome audit;
  an audit failure is not recursively audited. Unauthenticated/wrong-method
  requests never invoke reference/key/log access. No global serializer changes.

Private-file RED cases cover historical HMAC compatibility, concurrent first
creation/verification and strict/legacy append, invalid/unreadable/link/nonregular
preservation, missing key with old log, strip-boundary keys, short/torn writes,
key publication and file/directory fsync/close failures, lock timeout, strict
metadata rejection before I/O, and legacy best-effort append preservation.
The cooperative lock covers this updated recorder, not unsupported old binaries
or arbitrary external writers. No historical ledger scan or application-wide
audit/security qualification is claimed.

Final pre-code precisions within those same guarantees: compare the existing
key and opened log device/inode under the append lock and refuse only their
same-file alias; a valid newline-terminated signing key must not become its own
append target. Do not reject unrelated hard-linked historical keys. Check the
monotonic acquisition deadline before every lock attempt, including a retry
which might now succeed. Both missing checks were separately reproduced by
authored REDs (2 failed/60 passed); retain the original private damaged fixture.

### Independent route-review correction, September 9

The independent route reviewer identified that the body-wait `TimeoutError`
handler also enclosed source reads. A source timeout would incorrectly be
classified and audited as invalid request (422). The approved narrow correction
is to catch timeout only around the one-second empty-body wait and preserve its
422 outcome, while letting unexpected metadata/coordinate source timeouts reach
the existing fixed unavailable response (503). Add failing tests for both source
operations before changing the route; no new retry, timeout service, response
data, or active-twin access. Re-review the resulting diff and repeat the bounded
in-process packet. Real strict-audit integration remains a separate test.

### Independent protected-route review, retained original candidate

The independent UI/source reviewer read both complete new routes and their shared
`_molecular_reference_response`, the auth/header seams, the source reader, all32
new route cases and all47 reader cases. This grades root's route implementation,
not the separately authored strict audit recorder or the eventual local viewer.

Frozen identities before and after the independent repeat:

| File | SHA256 |
|---|---|
| `livemorebio/aegle/server.py` | `fada66c3ca973e4c0f54573e948c476860d2190b1928e9d5265a8af631ab8baf` |
| `test_molecular_reference_api.py` | `5b9b367c9e212a92cd8b523f6de491bad14039f1dadc01cdee2875723adefd7f` |
| `livemorebio/molecular_reference.py` | `b1f8533211b63eaa74ca279fd475ad4aab701a3ad30090892e382572a6cf7296` |
| `test_molecular_reference.py` | `0cdb3b0de52f9179ab8ae0bfa88b2d4b9473add18aef1451d8fdc2c3c06d09ad` |

The exact32+47 selection ran once using pinned Python3.11.15 and the existing
45-second private ASGI refusal wrapper documented in
`2026-09-08-observation-reconciliation-asgi-test-review.md`, replacing only its
pytest selection with these two complete molecular test files. The internal
TestClient socketpair remained allowed; external socket connect/bind/listen,
DNS, both urllib entrypoints, child creation, compilation and both numerical
constructors were refused. No TestClient lifespan/startup was entered.

```text
PRIVATE_REVIEW_ROOT .../livemore-research-review-fvm9ryrw
79 passed, 3 warnings in 1.77s
REVIEW_IO_COUNTS 0 1
```

Session1749 ended with exit0. The counters mean zero unexpected I/O and one
refused optional Git-metadata lookup, not an executed child. The three warnings
are the existing TestClient/HTTPX and startup-event deprecations. All audit calls
were deliberately stubbed by the route fixture; this is not actual durable
audit integration, installed-wheel or browser acceptance.

**P2, confidence10/10, not cleared at this candidate:** the outer timeout catch
in `_molecular_reference_response` (original lines1870–1872) covers the one-second
empty-body wait **and** both awaited source operations. If `source.lookup` or
`source.read_coordinates` raises an unexpected `TimeoutError`, it falls through
with the preconstructed422 `MOLECULAR_INVALID_REQUEST` response and that invalid-
request audit outcome. It should be a fixed503 `MOLECULAR_SOURCE_UNAVAILABLE`.
This is source-proven exception-flow evidence, not a separately executed probe;
the existing79 cases do not exercise a source `TimeoutError`.

Root confirmed the finding. Keep the body-wait timeout's422 behavior, but limit
that timeout catch to the body wait; allow source timeouts to reach the existing
fixed unexpected-source503 adapter. Add one source-timeout regression for each
route, preserving audit-before-release, no raw error reflection, no-store and
startup identities. Root owns this correction. No source/test repair was made
by the independent reviewer, and the original79 green receipt remains attached
to the original failing candidate above.

No other actionable blocker was found in this bounded route delta: auth precedes
reader/audit access, query/body admission is bounded, source identity and exact
bytes remain checked, unavailable mappings remain explicit, wrong methods avoid
the reader and global API middleware retains no-store. The existing Biology
remote full-viewer path remains pending the separately approved controller
replacement; these routes alone do not establish that user-visible restoration.

Lesson: a timeout handler must cover only the operation whose timeout has that
meaning. A shared exception class is not evidence that a source failure is a
malformed request, even when all current happy-path tests pass.

#### Independent source re-review of root's timeout correction

Exact corrected hashes were verified: server
`d3214fb8d2e3c738b37799b0c837ab7614248c39b6ee3ba78b9c9df2135d991b`,
34-case route test
`ec7bd4815e4ebd4784ee5448733ffe8d3e4f4b88abccff46f1fcac18e66ad5`.
The independent reviewer reread the complete corrected helper and both new
parameterized cases. Only the body wait handles TimeoutError as invalid shape;
source timeouts now reach the existing fixed503 adapter. Both tests require the
source-unavailable audit outcome and no private error reflection. The prior
body-timeout422 test remains intact. **The reported P2 is closed by source
review.** No additional independent run was performed at this checkpoint.

Root's separately reported evidence remains maker evidence:2 REDs at422 versus
503, private suffixdd4ivstk/session1975 in1.37s; corrected81 passed in1.86s,
private suffixhhpfelax/session90240, unexpected I/O0. This does not relabel the
original79 independent repeat or establish actual strict-audit integration.

#### Independent real route/audit integration, September 9

The reviewer read all9 new `test_molecular_reference_durable_audit.py` cases,
the complete current audit recorder and both current routes. The new fixture
does **not** replace `audit.record`, signing, verification or file append. It
redirects only the recorder paths to authored private test directories and
denies legacy implicit provenance/model access. Source/runtime files stayed
frozen; no operational audit key/log or selected subject was opened.

Verified identities before and after:

| File | SHA256 |
|---|---|
| `livemorebio/aegle/server.py` | `d3214fb8d2e3c738b37799b0c837ab7614248c39b6ee3ba78b9c9df2135d991b` |
| `livemorebio/audit.py` | `b82e241accdf6646f58d93171b5f3e2b173f64e7206aff3e52a7f7f6f799312c` |
| `livemorebio/molecular_reference.py` | `b1f8533211b63eaa74ca279fd475ad4aab701a3ad30090892e382572a6cf7296` |
| `test_molecular_reference_durable_audit.py` | `e21638aecd96eea216e71373bf78e64d1f4e1a32989be0daa8fb23bd06a0c595` |
| `test_molecular_reference_api.py` | `ec7bd4815e4ebd4784ee5448733ffe8d3e4f4f4b88abccff46f1fcac18e66ad5` |
| `test_molecular_reference.py` | `0cdb3b0de52f9179ab8ae0bfa88b2d4b9473add18aef1451d8fdc2c3c06d09ad` |

One authorized independent repeat selected those complete9+34+47 files with the
same pinned Python/private45-second ASGI wrapper documented above, including
constructor/compilation, external-network, DNS, urllib and child refusals.

```text
PRIVATE_REVIEW_ROOT .../livemore-research-review-cz4kuxwz
90 passed, 3 warnings in 1.63s
REVIEW_IO_COUNTS 0 1
```

Session12831 ended exit0; no test process remains. Zero unexpected I/O; one
optional Git-metadata child was refused, not run. The ordinary internal
TestClient socketpair remained available; startup/lifespan was not invoked.

**Scoped clearance:** no actionable blocker remains in this protected-reference
route/audit integration. Actual success leaves one verifiable signed record;
401 creates neither key nor log; file/directory fsync failures return fixed503
without coordinates, preserve the single reached signed row and do not retry;
invalid requests record only the fixed operation/null identity/outcome. The
source-timeout correction is also covered in this90-case repeat. No private
sentinel is reflected in responses or permitted record metadata.

The recorder's separate63-case independent durability/source review remains
attributed to root. This90-case repeat does not independently rerun its complete
concurrency matrix or claim universal crash/power-loss durability. It is not
browser/CSP/build/wheel acceptance, molecular dynamics, all-target mapping or
product-wide audit qualification. The retained original79 candidate and its P2
are not erased or relabeled.
