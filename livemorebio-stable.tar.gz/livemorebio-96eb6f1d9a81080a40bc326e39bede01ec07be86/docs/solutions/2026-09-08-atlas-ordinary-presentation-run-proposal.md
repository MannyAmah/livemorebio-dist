# Atlas ordinary presentation check: preservation gate and owned run proposal

Date: 2026-09-08. Status: **read-only proposal; not approved to implement or run**.
No browser, service, cache installation, conversion, numerical model, registry,
or operational-store operation was performed for this investigation. The only
new repository artifact is this document. Root retains run/source approval.

## Purpose and retained boundaries

Check the ordinary product's corrected selection presentation: assembled versus
isolated source geometry at the same camera, section suppression, readable view
status, and a 390 px viewport. This is **not** a rerun or replacement of the full
Atlas acceptance matrix. The retained attempt-2 result remains 28 PASS, 3 FAIL,
25 NOT_RUN, including unresolved warm-request/performance failures. New images
cannot close those gates, establish clinical registration, or demonstrate
spatial physiology. Source geometry remains reference-only.

Read prior art: `2026-09-08-atlas-selection-presentation-correction.md`,
`2026-09-08-atlas-publisher-install-acceptance.md`,
`2026-09-08-atlas-browser-attempt-2-results.md`, the reviewed browser plan and
`tools/check_atlas_browser.cjs`, and all of `tools/run_review_stack.py`.
The `/browse` skill was read fully. No connected gbrain, sequential-thinking,
or Compound Engineering provider was exposed by tool discovery; this local
evidence record is the available durable fallback.

## Blocking preservation regression: confirmed, no repair applied

The already admitted public Atlas manifest is retained at:

`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-1q65uy9g/anatomy/atlas/artifacts/8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a/manifest.json`

Its receipt is `083b2f038e74476ebfcef07e4a22f7c2`; nine GLBs contain
24,779,652 bytes, 489 source nodes, and 957,072 triangles. No artifact, manifest,
receipt, or pointer was changed. Geometry/source validity is not inferred from
the identity calculation below; the earlier admission record supplies that
separate evidence.

| Identity | SHA-256 |
| --- | --- |
| Admitted manifest | `8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a` |
| Manifest's loaded converter code | `e7532a863d945fabb296753e9aa8b5b6187f9609fb6dff518255053b1783e5f8` |
| Current loaded converter code, original runtime | `f7be5f9d28addfedec3c85fb7264f86358ad8abdf536e695f9e2417ec00e0595` |
| Exact admitted `strict_json.py` source | `6af73cc557bdb3a18bda10bc114148ef7e25f711410fd1d263e11279ea01c8e1` |
| Current `strict_json.py` source | `223228a095e85731bb7469fc6db9b26c59f7db72cfcf354048015f1980346a26` |
| Unchanged `atlas_reference.py` | `58ab81e85b0da2fc337d105cc6f49caccc80bed06c9800449af9eaad15dc8382` |
| Unchanged `_atlas_geometry.py` | `44b08f9bf486e8cb959db9a95d22a307c1b61874884d726ce5a85a1ecee56562` |

`atlas_reference._converter_identity()` lines 568–601 includes **every locally
defined function** in `strict_json`, not merely the parser used by geometry.
`_read_manifest()` lines 747–770 compares the stored complete conversion object
against the current identity and rejects a mismatch as
`ATLAS_UNSUPPORTED_CONVERTER`. Thus `status()` must report unavailable; this is
not a graphics failure or evidence that stored bytes changed.

The reviewed 16 MiB frozen-member response change added `_parse_object` and
`parse_frozen_member_response` and changed `parse_json_object` into a wrapper.
The other five local validator functions are unchanged. Geometry imports and
calls `parse_json_object` in `_atlas_geometry._decode()` (line 143); it never
uses the new frozen-member response entry point. Atlas metadata also uses the
ordinary parser. The converter's blanket function census nevertheless captures
the unrelated response decoder.

Exact admitted parser bytes exist independently in both retained source trees:

- `/tmp/livemore-network-source.ouSnkU/livemorebio/strict_json.py`
- `/tmp/livemore-wheel-audit.jzHnO4/build/lib/livemorebio/strict_json.py`

Both hash to `6af73c…`. The older checkout/other wheel version `418c7746…` is
**not** the admitted source; it predates the 8 MiB override and is not a suitable
restoration source.

An isolated, network-refusing identity calculation used the original interpreter
`/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python`, Python 3.11.15, NumPy 2.4.6,
trimesh 5.0.0, with bytecode writes disabled. It compiled the hash-verified,
trusted retained parser declarations into an unregistered module, without
replacing `sys.modules` or any current function. Rebuilding the same function
identity dictionary with only those original parser identities produced exactly
the stored `e7532a…`. The current dictionary independently reproduced `f7be5f…`.
All conversion options, versions, and the once-only root transform are equal.
There was no cache API call, conversion, network request, or model solve.

### Candidate minimal correction, subject to a separate approval

Restore the six original local parser/validator functions byte-for-byte in
behavior and loaded code identity. Move the fixed 16 MiB response entry/core to
a separate module. Preserve the existing import API with an imported alias
`strict_json.parse_frozen_member_response`, whose actual `__module__` stays the
response module; do not falsify that attribute. Share the unchanged strict
validator hooks. Avoid an import-order-dependent circular initialization.

This necessarily amends the prior factoring choice: the old parser body cannot
delegate to a new common core without changing its admitted identity. A narrow
response decoder can share validation primitives, with parity regression tests,
while retaining the original converter dependency exactly. No converter census,
allowlist, verification condition, receipt, pointer, exporter, or geometry change
is proposed. Do not reinstall/reconvert to make the old evidence disappear.

Required red-first checks: current-versus-stored identity mismatch; exact identity
restoration under the pinned runtime; unchanged 2,000,000-byte default and 8 MiB
maximum ordinary override; fixed 16 MiB response boundary and no override;
duplicate/depth/UTF-8/finite/safe-integer/object-only parity; both import orders;
the actual registry→JSONResponse→attached SDK large-member regression; canonical
bodyless GET/200-only transport scope; installed-wheel inclusion and retained
manifest read without cache writes. The larger producer/consumer compatibility
architecture remains a separate possible future plan, not this proposal.

## Fresh context; do not reopen the old technical registry

An empty review stack is not numerically inert. `server._startup_publish()` calls
`_ensure_selected_state()`; no selected record causes `AegleTwin("healthy")`.
`runtime.AegleTwin` computes a 14-hour metabolic trace and six cardiac beats.
The old SYNTHETIC fixture is also executable and rebuilding it computes models.
Neither is suitable for the requested no-new-model presentation check.

Opening the retained registry is not a read-only reuse: current initialization
may establish bootstrap metadata/audit authority, and reads are audited. Its old
records and key/sidecar graph must not be silently migrated or copied for this
visual task. Do not borrow its encryption keys, active selection, or bus.

Instead, after approval, prepare one fresh owner-private review root. Author one
clearly labelled **software-only, real-person-shaped intake fixture** using the
reviewed `clinical_registry_fixtures.human_payload` shape with no condition. Its
REAL_HUMAN schema class is deliberate contract testing, not a participant or
physical/clinical measurement claim. Keep the authored-fixture source URI and
display that distinction in the evidence; never use it as validation data.
Generate fresh review credentials, not the test module's fixed `KEY`.

Create through the actual registry API, then explicitly call
`select_observations(twin_id, expected_version=returned_version)` once before
service startup. Preserve its committed successor version. This uses audited
ordinary admission/CAS, not direct SQL, forged binding, or record rewriting.
Require `model_availability.state=UNAVAILABLE`, reason
`MODEL_BINDING_REQUIRED`, `selection_mode=observations_only`, and
`preparation_available=false`. On startup `_restore_active_subject()` retains
the descriptive subject and empty `ObservationState`, with `tw=None`; it does
not build or fall back to a healthy model. Exact current workspace identity and
null numerical projections must be checked before browser work.

Only this newly authored fixture and new review service bookkeeping may be
written. No patch/session/execution/experiment/calibration/install POST is part
of the run. No participant data is copied or rendered.

## Owned stack and source-only cache fence

After the preservation correction and independent review, freeze the then-current
package fingerprint. Do not reuse old `c9fee6…` source/process pins. Use a new
private output root and three explicitly checked-free loopback ports (proposed
8910–8912, subject to root ownership confirmation).

The standard runner always resets `LIVEMORE_ANATOMY_DIR` to the fresh root. A
reviewed one-shot owner wrapper is therefore required: call
`prepare_review_environment`, perform the fresh fixture setup, then override
**only** `LIVEMORE_ANATOMY_DIR` to the retained public anatomy directory stated
above. All registry, bus, model, source, evidence, LIFE, and Cendos mutable paths
remain fresh. Do not pass an inherited old environment, copy an old store, or
create links. This override authorizes reads of retained public Atlas artifacts,
not source installation or writes there. Hash the pointer/receipt/manifest/GLBs
before and after; a change is a hard failure. A copy or new installer option is
not currently authorized.

Spawn only the three normal modules used by `run_review_stack.py`, with its
no-access-log and bounded shutdown options. Record exact startup/current source,
all three service instance IDs, PID/start identity, and fresh subject/version.
Require those identities before each capture and at the end, plus the original
manifest/receipt identity. Source drift, unavailable cache, unexpected numerical
state, auth failure, or context drift stops the run rather than switching data.

## Browser route and camera evidence

Root's installed compiled `/browse` binary `--help` exited 137 without launching
a browser. It is an unsigned arm64 Mach-O; that does not establish the cause.
No retry, build, install, quarantine, or signature change is proposed. Root
verified the supported source launcher instead:

`/Users/emman/.bun/bin/bun /Users/emman/.agents/skills/gstack/browse/src/cli.ts`

Use a new private `BROWSE_STATE_FILE=<owned-root>/.gstack/browser.json` and existing
Bun on the child PATH; never the shared worktree state/profile. Before a non-help
invocation, inspect whether foreign `/tmp/browse-server*.json` or legacy browse
logs exist: the CLI's `cleanupLegacyState()` can terminate/remove them despite
the private state setting. If any could be touched, stop instead of launching.
Do not use `connect`/handoff, which uses shared Chromium-profile paths.

The source CLI's default bundled browser still has the previously demonstrated
WebGL-unavailable environment. It can inspect ordinary readouts but cannot count
as a rendered pass. For rendered images, seek explicit approval to reuse the
already reviewed isolated Playwright pattern from the same gstack installation:
installed Chrome, headed, `--use-angle=swiftshader` and
`--enable-unsafe-swiftshader`, fresh context, outer owned-browser `finally`.
This is software WebGL rendering, not hardware-GPU performance qualification.
Do not launch the full old acceptance harness unchanged: it pins the old subject,
source/process identities and performs unrelated instrumented/fault cases.

The retained ordinary attempt-2 receipt has named camera poses and screenshots,
not numeric camera vectors. Do not infer them from PNGs. Its optional metric
wrapper (`wrapSceneFactory` / `qaAtlasSnapshot().live.view.camera` in
`tools/check_atlas_browser.cjs`) is the known numeric extraction path, but that
instrumented stage was NOT_RUN. Ordinary product scene state is module-private.

For the new **ordinary, unmodified** image pair, use a fixed viewport, select the
source component, and Frame selected **once**. Capture assembled, toggle Isolate
without camera input or reframing, capture isolated, then Return and capture
restored. Scene `select/update` do not move the camera; only explicit camera
controls, framing, and resizing do. Record controls and unchanged canvas bounds.
This supports same-camera-by-controlled-workflow, not a recovered prior-camera
claim. If exact numeric vectors are required, approve a separate test-private
wrapper context; never present its screenshots as ordinary product images or
expose clinical state globally.

## Minimal capture and cleanup checklist

- Desktop 1440×1000: ordinary whole-person view; assembled/isolate/return pair
  for each retained pancreatic source component FJ1895 and FJ2629. Keep the same
  viewport and no intervening pointer camera input within each pair.
- One section-on screenshot showing suppressed extent cue and explicit section
  wording, then section-off. Preserve original provenance and the source-extent
  not-contour explanation. No material/geometry injection.
- At 390×844: readable current view status, selected source/provenance and one
  assembled/isolate pair. Capture the viewport and Atlas host without full-page
  scrolling artifacts; retain page/canvas/scroll dimensions and overflow result.
- Inspect actual visible DOM before every input. Record only fixed source/build,
  fixture, control and browser metadata, console-error categories and screenshots.
  Never persist cookies, credentials, raw registry payloads or auth headers.
- No install acknowledgment is manufactured. Install feedback fault states,
  warm timing, full zoom/keyboard/disposal matrix and other old NOT_RUN cases
  remain explicitly outside this small check, not silently passed.
- Stop on any unexpected failure; retain screenshot and bounded metadata without
  automatic rerun. Root independently views every resulting image.
- Close owned pages/context/browser even if capture or evidence writing fails.
  Stop/reap only the wrapper's three exact children, verify owned PIDs/listeners
  gone, and retain cleanup status. Leave the source cache and fresh audit/evidence
  files intact; never delete or rewrite the old review root.

## Durable lesson

Integrity identities must include their real dependencies, but an unscoped census
of every helper in a shared module can invalidate previously admitted artifacts
after an unrelated API extension. Diagnose the exact loaded-code change and
preserve the original producer dependency; do not weaken verification or replace
historical evidence merely to get a graphic back on screen.

## Root pre-code clearance and independent-review precisions

The parser preservation prerequisite is independently cleared:965 tests and
normal unchanged retained-cache reuse. The source-research reviewer independently
read this plan and the actual startup/controller/asset paths. Root accepts the
following mandatory corrections, and approves **harness implementation only**.
A frozen implementation review remains required before the one actual run.

Write set: new `tools/check_atlas_presentation.py`,
`tools/check_atlas_presentation.cjs`,
`livemorebio/tests/test_atlas_presentation_harness.py` and a separate report.
Reuse the existing environment preparation, source fingerprint and reviewed
browser helper where safe; do not edit product code or old acceptance scripts.

1. The comparison sequence is select→Frame once→assembled→Isolate on→Isolate
   off, with unchanged camera input and canvas bounds for that pair/triple.
   Return is a **separate full-body reset**, not a same-camera restoration.
2. Freeze a read-only request allowlist in the harness: exact ordinary root page,
   existing static `/lib/` resources, read-only build/services/workspace/stream,
   execution capabilities and session bootstrap, admitted Atlas status and the
   nine exact fixed-manifest asset URLs. No arbitrary same-origin GET allowance.
   Block legacy `/assets/anatomy/` acquisition GETs, install POSTs and every
   other mutation/unknown API. Interception may allow or abort, never rewrite
   returned product data/geometry/materials/scripts. External font resources are
   blocked and reported; unexpected same-origin access stops acceptance.
3. Use the already installed gstack Playwright with a new owned headed Chrome
   context and software WebGL flags, not the CLI's unsafe legacy cleanup path.
   Capture actual runtime versions. No shared browser/profile, installations,
   automatic updater, foreground-window capture or visibility override.
4. Freeze bounds: startup≤45s; one browser run≤180s including a60s readiness
   ceiling; per action/capture≤10s; each owned page/context/browser close≤5s.
   Parent supervises Node with a190s wall deadline. Every exact owned child gets
   independent terminate/wait≤5s then kill/reap≤5s attempts. An error in one
   cleanup cannot skip others. Record primary failure separately from uncertain
   cleanup, check all three ports and exact owned PIDs afterward; never signal
   pre-existing/unowned processes. Child logs stay private and unprinted.
5. Red tests precede harness implementation: only fresh review paths/keys except
   explicit read-only anatomy override; real registry observation-only setup;
   startup numerical constructor denied in tests; strict request allowlist;
   build/instance/fixture-version/manifest drift stops; primary failure preserved
   through failed capture/evidence writes and interrupted cleanup. No browser
   starts during test collection or unit tests.
6. One-shot evidence directory is new, owner-private and exclusive. Store only
   source/build/control/error-category metadata and ordinary screenshots, never
   credentials, cookies or raw intake/health payloads. Hash all16 source-cache
   files before/after even on failure. No previous receipt is overwritten.

The preparation fixture must visibly say authored software-only/not a participant.
Its schema class is not a biological claim. Unavailable numerics are expected
for this particular presentation-only check, not passed experiment functionality.
No R01–R51 item is closed by this harness. Root views every resulting PNG.
