# Observation selection and reconciliation: exact ASGI RED inventory

Status: inventory only; root review and explicit test-authoring approval pending.
No test or runtime implementation has been written or executed for this inventory.

## Authority, scope and prior art

This inventory implements the route-level test duty delegated in the full
`2026-09-08-observation-reconciliation-committed-publication-plan.md`, including
the independent captured-state ABA, complete finite-JSON snapshot and legacy
compatibility addendum and root's named-owner approval. The complete current
plan SHA256 is `015607f4a2852d6bb95e3db74e16cf766d4eb6bab5d7dffc9f95fee34807b9ec`.
The route baseline remains server SHA256
`cedcf801a9ede06cbddcc2de75a495068a0970c6785e68f8e5d9664e67c52f18`.

Prior art read: the actual two routes, source authority/fence and prepared/checked
registry APIs; confirmed-preview publication fixtures and retirement tests;
closed-manager publication fixtures; clinical availability API tests and actual
modeless projection. The existing independent 192-case preparation-status repeat
is preserved, not relabeled evidence for these still-unimplemented routes.

Own one new file, `livemorebio/tests/test_committed_observation_reconciliation_publication.py`,
with **78 collected cases** below. Two named existing test functions require
strictly bounded fixture migrations, totaling nine existing cases. Eight existing
body/auth cases stay unchanged. The route slice is therefore **95 cases**; adding
the distinct previously cleared 192-case preservation packet yields **287**, not
counting imported fixtures as collected tests. Registry crypto/read-set/audit tests
remain the registry owner's packet. UI/SDK recovery remains its separate owner.

## Shared fixture and assertions

- Reuse the actual FastAPI application through the existing `client` fixture,
  without entering its lifespan/startup context. Use only authored records and
  in-memory sentinels; no SubjectRegistry construction, SQLite, filesystem store,
  real model, adapter, biological solve, HTTP socket or subprocess.
- Use actual `ModelSourceAuthority`, its original `commit_guard` and
  `_model_fence_guard`, plus actual `ExecutionManager` with `run_background=False`
  and the existing `NoIOStore`/`OWNER_ID` authored ownership fixture. Wrappers
  delegate to original locks/fence; they observe phase entry/exit, not replace
  synchronization with a mock lock. No generic new test framework.
- Registry stand-ins return an inert exact prepared object or checked capture
  object, and assert the same object reaches the final owner API. Their recorded
  `record`/`active_before` values are detached. They refuse legacy target-only
  selection, unchecked capture, old confirmation signature, or extra calls.
  They model already-verified results/errors, not prove real audit durability.
- Observation targets are authored REAL_HUMAN-shaped, admitted, version 2;
  success is ACTIVE/observations_only version 3. An old numerical source is
  explicitly SYNTHETIC with READY availability and an inert candidate. An old
  modeless source is explicitly REAL_HUMAN/UNAVAILABLE with `tw=None`. No fixture
  pairs a real-human unavailable record with a supposedly ready old model.
- Actual `model_availability`, `ObservationState`, `_subject_summary` and
  `clinical_views.unavailable_state` are used for normal cases. Authored numerical
  `.state()` returns an explicitly technical dictionary with dictionary
  `profile_params`; it does not instantiate AegleTwin/MetabolicProfile. Bad-shape
  cases deliberately wrap a valid projection or factory with one named fault.
- Assert the lock tuple `(authority, creation, manager, initialization)` exactly:
  capture/preparation `(True, False, False, False)`; final commit/confirmation and
  assignment `(True, True, True, False)`; dependency construction, candidate or
  modeless projection, JSON validation, invalidation, publication and finalizers
  `(False, False, False, False)`. Final publication is already complete at guard
  exit; a source fence does not depend on successful old-owner cleanup.
- Every authenticated route response retains one canonical allocated operation
  UUID and `Cache-Control: no-store`, including preparation/final errors. The
  same UUID goes to capture and commit/confirmation. Exact fixed error codes and
  absence of authored PRIVATE sentinels are asserted. Auth-first401 tests do not
  incorrectly require a UUID allocated only after authentication.
- Success asserts full old/new subject, availability, fresh observation/action
  container identity and content, source generation and manager fence; old model
  `.state()` is forbidden. Failure asserts exact old/current object identities,
  not only dictionary equality. Only confirmed mutation publishes an own snapshot.
- Observe actual strict snapshot serialization before final commit/confirmation.
  The snapshot captured by `_snapshot_twin(st)` must be the already detached own
  value, including profile parameters/availability. No no-argument snapshot stub.
  Success wire metadata alone is not the finite-JSON gate.
- Races use one-shot deterministic hooks around the real guard/preparation phases,
  not sleep timing. Competing requests use the same real ASGI route and shared
  authority. Record exact ordered phases and per-operation call counts. Weak
  finalizers use only weak observations after fixture-owned references are removed;
  no assertion can pass because the fixture accidentally retains the tested owner.

## A. Request and initial admission: 8 cases

| Proposed test name | Fixed parameter values | Cases / required distinction |
|---|---|---:|
| `test_selection_auth_precedes_dependency_and_capture` | `observations`, `reconcile` | 2; no registry, authority capture, candidate or mutation before auth |
| `test_observations_rejects_nonincrementable_request_version` | `MAX`, `MAX+1` | 2; exact422 before registry; read-only MAX reconciliation remains allowed |
| `test_observations_denied_source_rejects_before_preparation` | none | 1;503, existing DENY and inspection state unchanged |
| `test_reconcile_rejects_payload_or_query_before_capture` | nonempty object; empty object with query | 2;422, no checked read |
| `test_reconcile_confirmed_source_rejects_before_capture` | none | 1;409, no checked read or rotation |

## B. Observation capture and final identity: 15 cases

| Proposed test name | Fixed parameter values | Cases / required distinction |
|---|---|---:|
| `test_observations_prepare_error_preserves_old_authority` | version conflict; storage error; actual `_transition_error('SELECTION_COMMIT_UNCONFIRMED')` | 3;409/503/503 respectively, no candidate/commit/invalidation/DENY installation |
| `test_observations_active_identity_matches_at_both_guards` | `twin_id`, `subject_id`, `source_class`, `version` × capture/final | 8; conflict, no commit; final race preserves the winning identity |
| `test_observations_active_absence_agreement` | both absent; memory only; registry only | 3; true absence proceeds, either one-sided absence conflicts |
| `test_observations_later_generation_blocks_final_commit` | none | 1; newer generation and holders retained, no old cleanup/publication |

For the final-field tests, change exactly the in-memory field after a coherent
capture while keeping the generation fixed, so the final four-field test is not
masked by a generation mismatch. For the generation test, keep the identity
fields fixed. All comparisons use actual values appropriate to the field.

## C. Observation committed publication: 24 cases

| Proposed test name | Fixed parameter values | Cases / required distinction |
|---|---|---:|
| `test_observations_outcome_publication_and_cleanup` | old READY/modeless × COMMITTED, committed-close marker, rollback, unknown, committed invalidation failure | 10; confirmed200/cleanup503 install new modeless source; rollback409 preserves old; unknown503 installs DENY but preserves exact old state/actions |
| `test_observations_closed_manager_keeps_owned_cleanup` | COMMITTED, rollback, unknown | 3; closed bit and retained owner survive; only confirmed/unknown invalidate exact captured old generation outside guards |
| `test_observations_bad_own_projection_never_commits` | non-dict; missing parameters; non-null parameters; incoherent availability; nonfinite other field; opaque other field | 6; fixed storage503, no mutation, no old model read or generation change |
| `test_observations_publishes_own_snapshot_after_later_winner` | none | 1; later source remains current while earlier publication contains exactly its own confirmed modeless snapshot |
| `test_observations_holders_release_outside_guards` | success; rollback; unknown; late-generation conflict | 4; retired/discarded observation/action/model holders finalize only outside all locks; retained old holders do not finalize on failed/unknown selection |

Unknown cleanup is still attempted once for the captured generation, never for a
later generation. All confirmed variants publish the frozen confirmed snapshot;
cleanup failure cannot change confirmed identity or erase the committed state.
Modeless snapshots contain null numerical parameters/quantities, fresh empty
observations/actions and no invented axis or execution. Same-target versus
different-target SQL transforms remain registry tests, not mocked SQL claims.

## D. Reconciliation capture and detached preparation: 17 cases

| Proposed test name | Fixed parameter values | Cases / required distinction |
|---|---|---:|
| `test_reconcile_checked_record_prepares_exact_supported_mode` | READY authored SYNTHETIC; UNAVAILABLE authored REAL_HUMAN; checked true absence | 3; record build, no-model projection, or healthy reference constructor respectively; no clinical mutation |
| `test_reconcile_stored_max_is_read_only` | none | 1; REAL_HUMAN version MAX restored unchanged, not incremented or treated as absent |
| `test_reconcile_actual_record_typed_context_rejection_is_modeless` | none | 1; allowed record factory throws actual `ModelContextError('MODEL_CONTEXT_UNSUPPORTED')`; explicit record/reason retained, no healthy fallback |
| `test_reconcile_true_absence_constructor_failure_is_operational` | none | 1; fixed503, no fabricated unavailable person and no final confirmation |
| `test_reconcile_checked_capture_error_keeps_denial` | storage failure; selection-read uncertainty | 2; fixed503, no factory/final confirmation, DENY and old holders retained |
| `test_reconcile_bad_own_snapshot_never_confirms` | READY state None; READY state list; missing parameters; null parameters; list parameters; NaN outside parameters; opaque value outside parameters; modeless non-null parameters; modeless opaque value | 9; fixed storage503 before confirmation; valid success metadata cannot hide a malformed detached snapshot |

The true-absence test receives an explicit checked token whose record is None,
not a default missing getter result. The registry owner proves no hidden ACTIVE
row/pointer exists. The typed context-failure case is an authored failure of the
otherwise permitted record factory, not an assertion that every valid SYNTHETIC
record normally raises. All no-record constructor errors remain operational.

## E. Reconciliation final authority, ownership and both wire projections: 14 cases

| Proposed test name | Fixed parameter values | Cases / required distinction |
|---|---|---:|
| `test_reconcile_checked_confirmation_failure_preserves_holders` | exact conflict; storage/terminal failure; commit-or-close uncertainty | 3;409/503/503; same captured token/record/UUID, no assignment, no publication |
| `test_reconcile_changed_captured_state_blocks_confirmation` | none | 1; replace `_state` while remaining DENY, reject before final read |
| `test_reconcile_now_confirmed_blocks_confirmation` | none | 1; newer admitted generation wins before final read |
| `test_reconcile_deny_confirmed_deny_aba_rejects_stale_request` | none | 1; R1 captures S, R2 recovers unchanged registry into T, later unknown observation commit returns DENY with T retained; R1 gets409 without its final confirmation or cleanup, preserving T and its newer observation/action sentinels |
| `test_reconcile_competing_recovery_confirms_once` | none | 1; nested winner confirms once; stale outer operation neither reconfirms nor rotates source |
| `test_reconcile_preserves_closed_pending_execution_ownership` | none | 1; retained closed manager/owner/cleanup set unchanged, zero invalidation/stop/reopen/acknowledgment calls |
| `test_reconcile_strong_holders_release_outside_guards` | successful replacement; rejected candidate; superseded captured state | 3; strong captured state survives preparation/supersession; old/candidate finalizers occur only after outer guard exit |
| `test_reconcile_publishes_own_snapshot_after_later_winner` | none | 1; earlier own detached snapshot never borrows later candidate parameters/availability |
| `test_selection_success_metadata_serialization_precedes_final_owner` | observations; reconcile | 2; opaque value in otherwise valid success-only record metadata fails safely before commit/confirmation; full snapshot validation is separately exercised above |

Confirmation-failure stand-ins expose the registry owner's fixed outcomes; they
do not pretend to distinguish physical COMMIT versus connection-close failure.
The separate registry packet owns those exact technical transaction probes.
Reconciliation always calls checked capture with fixed `reconcile_selection`,
`_checked_snapshot=True`, and confirmation with the exact `_expected_snapshot`.
It never calls a registry select/activate/clear/update API, including after error.
The four success keys remain exactly selection_status, subject, model_availability
and prior_execution_cleanup; no version/query/action is sent by the HTTP client.

## Exactly identified inherited fixture migrations

Only these two functions in `test_clinical_availability_api.py` change, if root
approves this inventory. Their nine original outcome cases and independent safety
assertions remain; no other body/auth/cohort/patch test is rewritten.

1. `test_observation_selection_commit_installs_coherent_source_or_explicit_uncertainty`
   (4 cases): adapt the inert registry from get/legacy-select to prepared capture
   and once-only commit; make the old numerical fixture explicitly SYNTHETIC/READY;
   use actual prepared outcomes/errors; preserve lock, generation, response,
   cleanup, workspace denial and list inspection assertions. For unknown only,
   replace speculative `tw is None` with exact old state/twin/observations/actions
   retention, and make its cleanup callback assert the matching outcome. Success
   still installs `tw=None`; unknown listing still has `active:null` and
   `selection_status:UNCONFIRMED`, and numerical capture remains blocked.
2. `test_selection_reconciliation_uses_audited_authority_and_never_reselects`
   (5 cases): update checked capture/signatures/token identity and authority-only
   capture assertion; the authored healthy-reference state must include dictionary
   parameters; change the no-argument snapshot stub to accept/assert the supplied
   own snapshot. Keep both success modes, first/final failures, same UUID/no-store,
   exact two audited-owner calls on success, no reselect and second POST conflict.

The unchanged eight cases are the four coercion/extra-body cases, three strict
JSON/size cases and one observation auth-first case. No broad client fixture
migration or weakened old assertions is authorized by this inventory. If another
fixture mismatch appears, retain it and request a named migration before editing.

## Execution and independent grading gate

After root approval only: write this one file and retain genuine current-server
RED outcomes, distinguishing missing new contract seams from authored fixture
mistakes. Root writes routes; registry owner writes its helper separately.
Freeze the 78-case collection before runtime work and preserve all old cases.
Run the 95-case route slice, then the distinct 192-case packet, or one deduplicated
287-case selection in the previously reviewed private 45-second ASGI wrapper.
No new test interpreter/plugin/model dependency is needed.

The wrapper denies sockets/DNS/urllib/child/native work, except the existing
internal ASGI socketpair and exact refused Git-metadata lookup, and denies both
AegleTwin and MetabolicProfile construction. Explicit authored factory stubs do
not weaken those global guards. Store paths/env are private and no lifespan runs.
Report collection, exact source/test hashes, raw RED/GREEN, all guard counts and
any unexpected I/O separately. Root independently reviews these authored tests;
another agent independently grades root's route implementation and later actual
registry integration. This inventory is not route, browser, model or product
acceptance and does not alter any retained Atlas evidence.

## Root inventory approval

Root read all207 original lines and the complete publication plan/addendum,
current routes, model-source authority, availability and modeless projections.
The78 new-case RED stage is approved at servercedcf801. Freeze and retain that
result before root changes either route. The two explicitly identified existing
functions (nine cases) may be migrated only afterward at preservation stage;
their independent behavior assertions and the eight unchanged cases remain.
No other existing test edits or collection expansion are authorized. The author
reports earliest reached boundaries, not retrospective claims that later fault
assertions already executed. This approval does not start a browser, service,
native solver or operational-store workflow.
