# Reference associations are not causal parameters; subjects are not rows

Date: 2026-09-05
Context: research-validation source lane and independent research-service review.

## Findings

Both inherited knowledgebase loaders turned a disease category into generic physiological
effects and registered every associated gene with those effects. Missing allele frequencies
then became fabricated cohort genotypes. A database association supplies neither a causal
effect size nor an individual's genotype. These paths are now reference-only; unknown allele
frequency remains unknown, and incomplete genotype coverage cannot silently mean wild type.
Explicitly named legacy synthetic phenotype presets remain unqualified demonstrations.

KEGG's public REST endpoint is academic-only. A commercial-use acknowledgement cannot
change that endpoint's terms. The adapter now requires a separately approved HTTPS host,
blocks the academic host and redirects, and offers a local permission-manifest import.
MalaCards uses the same exact-reference contract without scraping. Manifests bind source,
release, normalized schema, upstream and normalized hashes, explicit permissions and lifetime.
They record an operator's authority declaration, not independent legal verification.

The new resilience comparator initially treated freely supplied subject IDs as independent
experimental units, used shared healthy ranges and accepted future observations. That permits
false precision and premature treatment-free follow-up even when no cure claim is issued.
The correction freezes the subject roster and individual ranges before admission, rejects
whitespace aliases and unregistered IDs, and checks timezone-aware real chronology. Stress
must begin after washout; follow-up duration starts at the end of washout. Every declared
subject, applicable operation and stress remains in the completeness check. Repeated rows
or files do not create new independent subjects.

## Regression contract

- Reference ingestion must never call a physiology registration function.
- Missing population statistics or person observations must never become invented values.
- A local licensed-source record must pass schema, digest and permission checks on every read.
- Research measurements must bind to an immutable protocol and prespecified identities.
- Future timestamps, missing follow-up and incomplete subject coverage cannot pass a criterion.
- Software test fixtures remain technical checks, never independent biological validation.
- A statistical criterion, even met, cannot authorize a cure, calibration or a clinical release.

Relevant tests: `test_licensed_reference_sources.py`, `test_merged_layers.py`,
`test_life_system.py`, and `test_research_workflow.py`.

## Remaining scientific and production gates

Operator declarations do not independently authenticate an instrument, a real person, a stress
challenge, treatment cessation or a vendor agreement. Individual reference ranges require a
scientific rationale and provenance review. Finite follow-up only assesses the registered
endpoints and conditions; it cannot establish permanent cure or unmeasured reservoir clearance.
Production use needs independent identity/custody review and population-specific validation.
