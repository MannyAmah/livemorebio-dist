# Nrf2 original author export: bounded source-evidence review

Date: 2026-09-08. Status: **SOURCE INSPECTED; NOT EXECUTABLE-ADMITTED**.
Parent: [five-program mechanism and measurement packet](2026-09-08-five-program-mechanism-measurement-plan.md).
This is a read-only investigation, not a botanical experiment, numerical run,
source correction, fitted model, clinical validation or activation decision.
All five selected programs and their individualized exposure/context work remain
in scope. This source is relevant infrastructure for the Sterubin/Carnosic redox
programs; it does not contain an admitted input for either compound.

## Decision

The evidence is richer than a repository listing alone suggests: the supplement
does publish initial-state constraints and event/knockdown semantics, and the
RDS contains rate and parameter-formula strings. The earlier statement that an
initialization recipe was wholly absent should therefore be narrowed to:
**no reconciled, executable, versioned author reproduction recipe is supplied by
the inspected files.** Exact reproduction is not currently defensible without
resolving conflicting original representations and confirming the export's
condition/event and observation semantics.

Do not substitute a large finite number for `Inf`, reconstruct missing events
from condition names, insert a missing exponential silently, choose one pulse
width arbitrarily, or call a successful independently reconstructed model an
unchanged execution of the author's export.

## Sources and inspection boundaries

- Primary paper: Hiemstra, Fehling-Kaschek, Kuijper et al., *Dynamic modeling of
  Nrf2 pathway activation in liver cells after toxicant exposure*, Scientific
  Reports 12, 7336 (2022), [DOI 10.1038/s41598-022-10857-x](https://www.nature.com/articles/s41598-022-10857-x).
- [Pinned original repository](https://github.com/JetiLab/Nrf2-signaling/tree/5248764a169039e9b638f36b9924165370bac4a8),
  commit `5248764a169039e9b638f36b9924165370bac4a8` (2022-04-19).
- [Complete recursive tree](https://api.github.com/repos/JetiLab/Nrf2-signaling/git/trees/5248764a169039e9b638f36b9924165370bac4a8?recursive=1),
  `truncated: false`: LICENSE plus five files under `petab/model/`; no README,
  executable R script, dependency lock, SBML XML, YAML problem definition or
  machine-readable predicted trajectory. The inspected repository has two
  commits and no tags/releases.
- [Original supplementary PDF](https://media.springernature.com/original/springer-static/esm/art%3A10.1038%2Fs41598-022-10857-x/MediaObjects/41598_2022_10857_MOESM1_ESM.pdf),
  17 pages. Pages 1–11 read for equations, constraints, transformations and
  datasets; pages 2 and 6 also rendered and visually checked to distinguish
  mathematical notation from text-extraction artifacts. Later figure pages were
  inventoried, not digitized into numerical reference curves.
- [R Internals serialization specification](https://stat.ethz.ch/R-manual/R-devel/doc/manual/R-ints.html#Serialization-Formats)
  and [PEtab v1 specification](https://petab.readthedocs.io/en/latest/v1/documentation_data_format.html)
  consulted for format interpretation, not as proof that this particular export
  conforms to a complete interoperable problem.

Public-source browsing used a separate owned browser. Files were downloaded only
to `/tmp/livemore-nrf2-source.ogS1se/`; the product's source/cache/runtime, model
gates, services and scientific records were not modified. No R object or function
was loaded/evaluated. No package was installed, model compiled, solver run,
parameter fitted, experiment created or author contacted.

### Frozen original bytes

All repository paths below are relative to the pinned commit. SHA256 refers to
the actual downloaded bytes, not a Git blob hash.

| Path | Bytes | SHA256 |
|---|---:|---|
| [LICENSE](https://raw.githubusercontent.com/JetiLab/Nrf2-signaling/5248764a169039e9b638f36b9924165370bac4a8/LICENSE) | 1,064 | `e8eda4ff20d48582bbccb6076db8e2c049bb53ba5572baf299be3e79eeb8cef5` |
| [petab/model/experimentalCondition_model.tsv](https://raw.githubusercontent.com/JetiLab/Nrf2-signaling/5248764a169039e9b638f36b9924165370bac4a8/petab/model/experimentalCondition_model.tsv) | 1,333 | `426c558401c2d346da67aee9f169981e05909be3fe2e5dfddcd4dac7f241b882` |
| [petab/model/measurementData_model.tsv](https://raw.githubusercontent.com/JetiLab/Nrf2-signaling/5248764a169039e9b638f36b9924165370bac4a8/petab/model/measurementData_model.tsv) | 357,206 | `573719428858a6c156721b0ab733ad30f3d3901db308d3f9a0d6249646e6dbfb` |
| [petab/model/model_model.rds](https://raw.githubusercontent.com/JetiLab/Nrf2-signaling/5248764a169039e9b638f36b9924165370bac4a8/petab/model/model_model.rds) | 2,329 | `2ec08d1ca57c5646661e261c56ddf70c99f047daf9b6a264e9bf6b2b55da3af3` |
| [petab/model/observables_model.tsv](https://raw.githubusercontent.com/JetiLab/Nrf2-signaling/5248764a169039e9b638f36b9924165370bac4a8/petab/model/observables_model.tsv) | 903 | `4654c362ae9d9a2b19c59fdfa705dfe122475bd78461f11666f716298e385463` |
| [petab/model/parameters_model.tsv](https://raw.githubusercontent.com/JetiLab/Nrf2-signaling/5248764a169039e9b638f36b9924165370bac4a8/petab/model/parameters_model.tsv) | 6,078 | `b8f2180e1a97a93666558ffeac09374e379464a070797567a43e31cfb54a97f4` |
| Supplementary PDF, linked above | 17 pages | `17322702c46dc34163ab0986d4d3b8e09b76e0d8bc0b707a1e53a3bc241af3db` |

The code repository carries MIT copyright 2022 JetiLab. The paper states CC BY
4.0, subject to its third-party credit exceptions. Preserve these distinct
notices; permissive source rights do not establish biological qualification.

## What the original source actually describes

The experimental context is human hepatoma **HepG2** BAC-GFP reporter cell lines,
not primary hepatocytes, neurons, individual people or a whole liver. Nuclear
Nrf2 fluorescence, cytoplasmic Srxn1 signal, Keap1 foci, qPCR and glutathione assays
have different observation mappings. The paper describes at least three
biological replicates, then alignment/scaling that condenses replicates into
time courses. Exported rows must not be counted as independent donors.

Supplement pp. 1–3 describes mass-action/Hill processes, a baseline steady state,
72 h knockdown preparation, and a compound input switched on at model time 72 h.
The initial state is not an arbitrary all-zero vector. Table 4 (p. 9) supplies
14 steady-state substitutions, and Table 5 (p. 10) reports fitted values on a
logarithmic scale. Table 1/2 supplies the full hinge-latch reactions/ODEs; the
later DCF/OMZ extensions and dissociation variant are separate contexts.

The paper uses dMod for numerical modeling, estimation and identifiability.
It does not state an exact executable package/dependency lock or export command.
The supplement describes joint DEM/DCF fitting and OMZ-specific recalibration;
these should not be represented as independent, untouched prospective holdouts.
OMZ rows are absent from this pinned table export.

### Tabular inventory, without inference of missing values

Direct CSV inspection found:

- 66 parameter rows: 46 `log`, 19 `lin`, one `log10` (`time`). Nominal values
  exist. PEtab nominal values are in linear parameter space regardless of
  estimation scale; the supplement's logarithmic table must not cause a second
  exponentiation of the exported nominal values.
- 17 conditions: DEM, DCF, and DMSO control/knockdown contexts; no Sterubin,
  Carnosic acid or OMZ condition.
- 3,262 measurement rows over model times 72–120; all measurement/time values
  finite. All `preequilibrationConditionId` entries are empty and every
  `replicateId` is `1`. This is not 3,262 independently sampled cell populations.
- 10 observable definitions, eight with measurement rows. `Keap1_free` and
  `P62_bound` have no rows in this export.
- Four `noiseParameters` values are `NaN` (one GSH, three Srxn1). Every `lloq`
  entry is `-Inf`. A noise/missing-limit sentinel is not a physiological infinite
  state and must not be treated like the separate infinite DEM rate parameter.

## RDS format and safe metadata findings

The original RDS is gzip-compressed. Inert decompression yields 22,722 bytes,
SHA256 `9dad1a02ffda460d4ebfca92e7f7a97c77955af5e8b9a0be28954c173bf58626`.
Its header is `X\n`, serialization version 3, packed writer R 3.6.3, minimum
reader R 3.5.0, native encoding UTF-8. These header versions do **not** identify
the dMod/exporter version or prove current runtime compatibility.

The byte stream contains `wrap_real`, `base`, `eqnlist`, `data.table`,
`data.frame`, `.internal.selfref`, `equationList`, `events`, and
`parameterFormulaList`. It also contains rate expressions, state names and
derived-initialization formulas. The `events` name's presence does not verify
that a complete populated event table is present. No complete R object graph was
deserialized, no external pointer hydrated, and no formula evaluated.

For the following formula observations, the inspection additionally checked
length-delimited CHARSXP byte spans against the documented big-endian string
format. This avoids mistaking a preceding binary string-length byte for a minus
sign. It is still byte evidence, not an accepted semantic decoder or executable
export recipe.

## Concrete reconciliation blockers

| Boundary | Original evidence | Required resolution; no silent repair |
|---|---|---|
| DEM infinite rate | Every DEM condition gives `changeKeap1_RM=Inf`. Supplement p. 4 explicitly fixes this rate and `degradGsh` to 1000. RDS rate strings multiply it into Keap1/RM terms. | Determine which model version was exported and whether the author used a limiting/reduced equation or an export error. Do not replace `Inf` merely because 1000 appears elsewhere. |
| Knockdown transformation | Supplement p. 2 visibly uses `0.5 * exp(-Delta^2)`. RDS CHARSXP at uncompressed offset 19084, length 45, is `(buildNrf2Base)*0.5*-Delta_buildNrf2Base_KO^2`. Keap1/P62 strings at offsets 20003/21498 have the same missing-exponential suffix. | Obtain source export/transformation semantics or corrected author artifact. Literal execution could change sign/meaning; no new numerical outcome was computed here. The supplement and exported bytes must not be blended without a versioned correction. |
| Input pulse width and time factors | Supplement Table 1, p. 6 visibly uses Gaussian width 2; RDS input strings at offsets 13349/13444 use `0.166666666666667`. Exported modification rates additionally contain `60*60` factors absent from the corresponding printed reaction expressions. | Reconcile units, transformations and model revision before choosing a pulse or rate convention. Rounded figures are not a license to choose whichever curve looks best. |
| Event/dose/condition wiring | Condition columns are only ID/name, `changeKeap1_RM`, `degradRM`, `prodROS`, `dose_RM`. Nominal `DRUG` and three `Ko_*` switch values are zero. The supplement requires t=0 knockdown and t=72 compound switching plus concentration-dependent input. | Decode the actual event/parameter mapping inertly, then obtain the exact author reader/export script. Do not infer executable switches/doses solely from condition-name tokens or assume the RDS `events` name solves this. |
| Initial conditions and model variant | The supplement does supply steady-state constraints; RDS contains expanded derived formulas and additional names including `ROSRM` and `Keap1Nrf2P62`. Its state vector has not been accepted through a typed decoder. | Freeze exact state order, parameter dependency order, initial-zero states, full units and model variant; compare each derived formula to its author source, rather than using the paper's 18-state count for an extended export by assumption. |
| Observer/data/noise semantics | Eight observers are `log` with scale/offset expressions, while `noiseFormula` is literal 1 throughout and measurement rows contain varying noise overrides plus four NaNs. | Confirm original dMod export/reader conventions and which quantities are linear values versus transformed residuals. PEtab specifies transformation of both linear measurements and outputs for the objective; normalized fluorescence cannot become absolute concentration, and a hardcoded noise 1 cannot silently replace exported errors. |
| Benchmark and runtime | No original R execution script, dependency lock, source prediction table, tolerance definition or complete raw preprocessing package in the inspected tree. The paper's broader data statement directs requests to authors. | Obtain exact original source/reader and golden predictions, or explicitly preregister a separately identified paper reconstruction. Exported fitted observations are not an independent validation set. |

## Proposed next source-admission packet — not yet implementation approval

1. Preserve this exact original archive, hashes, license and supplementary pages.
   Create a manifest distinguishing original bytes from any later author update;
   never overwrite the original export. No automatic network/execute on status.
2. Review a **data-only R serialization inspection** separately: fixed-size input,
   decompression/object-count/depth bounds, typed scalar/vector/list graph,
   no calls, function evaluation, environments, dynamic imports or external
   pointer reconstruction. Expose a lossless audit of state/order/matrix/formula
   and event entries, with original offsets. Do not yet evaluate model formulas.
3. Request (only with separate authorization to contact authors) the original
   dMod setup/export/reader scripts and versions, condition/event tables, exact
   initial-state generation, parameter transformations, DEM limiting-rate policy,
   dose Gaussian/unit policy and predicted observables for the pinned optimum.
   Ask specifically about the three byte-versus-supplement mismatches above.
4. Before numerical execution, choose and independently review **one coherent
   version**. A paper reconstruction would have its own ID, source discrepancy
   register and unqualified status; it must not masquerade as unchanged original
   model reproduction. Missing mapping or unresolved nonfinite dynamics keeps
   execution unavailable. Any author correction remains explicit provenance.
5. Freeze the deterministic DEM/control benchmark first, not a botanical fit:
   state and parameter ordering, units, time/event boundary behavior, exact
   nominal values, observer/noise mapping, native runtime identity, solver
   limits and prespecified numerical tolerances. Reference data and golden
   predictions require separate classes. Preserve null/adverse predictions.
6. Only after independent admission/reproduction review, propose typed recorded
   process outputs (nuclear/cytoplasmic Nrf2, complex amounts, mRNA/readouts, GSH)
   within this HepG2 context. Do not emit molecular motion, human organ function,
   individualized cohorts, physical LIFE observations or Sterubin/Carnosic dose
   responses without their separate measured mechanism/exposure contracts.

### Red tests to require before an adapter

- Hash/source-version mismatch, excessive compressed/decompressed sizes,
  malformed/unsupported serialization types, function/environment/pointer
  activation attempts and cyclic or ambiguous data graphs reject without running
  code or making network calls.
- Missing/duplicate state or initial expression, dependency cycles, inconsistent
  parameter scale, unresolved symbol, malformed condition and absent event/dose
  maps remain explicit blockers, never zero/default-state fallbacks.
- Infinite DEM dynamics, conflicting Gaussian width, absent `exp` transformation
  and undocumented time/rate factors cannot pass admission by normalization.
- Observer transforms occur exactly once; linear amounts, scaled outputs,
  log residuals, noise/missingness and limits retain distinct units/meaning.
- Wrong model variant, absent original prediction reference, unapproved runtime
  identity or unknown numerical tolerance blocks any reproduction claim.
- A later native benchmark must compare original events/times/observers and
  include finite/domain checks and tighter-tolerance convergence; it must not
  fit around the exported defects. No such test or benchmark was run here.

## Lesson

An original model repository can contain useful initialization formulas and still
fail executable admission. Inspect the full supplement and serialized metadata
before declaring the science absent, but do not use that discovery to conceal
contradictions between representations. Exact source reconciliation precedes
execution; source replication, calibration and individualized-human qualification
remain different milestones.
