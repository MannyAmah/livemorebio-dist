# OSP retained runtime: static identity and fixed collector mapping

2026-09-08. Static preparation only by `release_redteam`. No R, dotnet, CLR,
native library, collector, test, browser, service or model was invoked. No
download, compilation, installation or retained-runtime write occurred. Only
this report, its inventory and its reproducible read-only method are new.

## Disposition and scope

The namespace hook and public call spellings are resolved; the bounded static
candidate set is frozen for independent review. This can support approval of
the already proposed two-file collector/supervisor implementation, **not its
execution**. Actual loading, inspector permissions, R/dotnet process topology,
time/resource adequacy and loaded-image admission remain unobserved. No generic
runner or new runtime authority is proposed.

Root explicitly retained `library(ospsuite)` startup, rather than substituting a
smaller rSharp-only startup. Direct `bin/exec/R` and FINAL-before-Dispose are the
two already approved launcher/checkpoint differences. The old Stage B R program
and `gim_recipe.R` remain read-only references and must not be sourced.

Governing amendment after root's decision:
`2026-09-08-osp-retained-native-collector-supervisor-amendment.md`, SHA256
`b2a33a54227f9045e31fd386a79db95a847d0562415ab7dd20a499564c6be06b`.
The original17 fixtures,16 Run calls, public-API evidence labels,30s/600s limits,
and false scientific-admission flags remain unchanged. This is software behavior
on retained bytes, not source-build attestation or qualification of insulin or
the other five required scientific programs.

## Frozen byte inventory and reproducibility

[Inventory](2026-09-08-osp-retained-runtime-static-inventory.json), SHA256
`fc5afe90a5d51b92014c559708b8737e1cc08e8b029bdea7cb79d7c565205f95`.
[Exact read-only method](2026-09-08-osp-retained-runtime-static-inventory-method.md),
SHA256 `47823872e887a4227dd2b32a59a24daa750927d8aaeb21805d9fbe019edadebe`.
The method emits JSON only; retention used `apply_patch`. An intermediate
metadata-enrichment expression failed on tuple unpacking before emitting JSON;
the corrected complete expression produced the frozen inventory. This was file
inspection, not a failed/successful native probe or an experiment rerun.

Logical root `/tmp/livemore-osp-native.mUlZwx` resolves to
`/private/tmp/livemore-osp-native.mUlZwx`. Each relative path is anchored to those
two exact roots. One internal file alias is explicit: Resources/lib/libRblas.dylib
resolves to libRblas.0.dylib. Every row includes size, complete SHA256, device,
inode, nanosecond mtime and mode. Hashing checked regular-file identity before,
during and after descriptor reading, and checked the final named path again.
No file exceeded the method's128MiB individual read bound.

- 79 **declared** R package closure members, not79 observed loaded namespaces.
  Seeds are ospsuite, jsonlite and the preserved base/methods/utils/stats/graphics/
  grDevices/datasets default packages. Closure follows installed DESCRIPTION
  Depends/Imports, not Suggests, arbitrary package discovery or a loaded trace.
- 1,370 retained file entries,274,739,515 bytes hashed in aggregate. Code/data,
  metadata, source evidence and image candidates have distinct roles. Source
  evidence and historical manifests are not executable-image allowances.
- 261 managed PE/CLI image candidates and78 ARM64 Mach-O path entries (including
  the libRblas alias), not claims of261/78 loads. PE/CLI classification is a
  static image-kind discriminator, not a managed assembly execution check.
- Package R/lazy-load/data/Meta/DESCRIPTION/NAMESPACE bytes, package runtime lib/
  libs, R etc/lib/modules, exact R executable, dotnet host/fxr8.0.30 and complete
  Microsoft.NETCore.App8.0.30 file roots are pinned. No package archive, help
  index or package version alone substitutes for those actual code bytes.
- Fourteen image exclusions are explicit:11 foreign-platform binaries plus
  grDevices/libs/cairo.so, modules/R_X11.so and modules/R_de.so. The last three
  declare external `/opt/X11` dependencies and are irrelevant to this nongraphics
  path. Their observation must fail identity admission; no X11 asset acquisition,
  load, graphics/data-editor call or allowlist expansion is authorized.

The complete original five principal hashes match the pure protocol, including
Core and ConsoleApp.deps.json. All79 package names, installed versions, declared
edges and exact candidate paths are machine-readable, so the collector need not
discover or extend an allowlist from a Run. Unexpected namespaces/images fail.
The candidate closure is conservative; static presence does not require every
candidate to load, and it does not authorize invoking unrelated package APIs.

### Native resolution and system-cache boundary

The inventory parses bounded ARM64 Mach-O load commands as bytes, without otool,
dyld, vmmap or library invocation. All included declared absolute dependencies
are either the retained R-framework family or named entries of the exact system
cache map. The retained R-framework install names remain the original
`/Library/Frameworks/R.framework/Versions/4.6/...` names: the already approved
private Resources/lib DYLD_LIBRARY_PATH is the relocation mechanism to verify,
not evidence that the global Framework copy loaded.

SimModelNative declares `@rpath/libOSPSuite.FuncParserNative.dylib` and rpath `.`;
its retained candidate is pinned at
`r-library/ospsuite/lib/libOSPSuite.FuncParserNative.dylib`, SHA256
`5ab90d872ee05605d9c1e7d043e256207f543f19f86ba236c036db3c65f2b4d1`.
libmscordbi's declared @rpath dependency has its retained same-directory
libmscordaccore candidate. These are static candidate resolutions, **not an
observed loader search**. Preserve ospsuite initialization and the private work
directory; do not change cwd into the package, inject another DYLD directory,
force-load a missing dependency or retry to manufacture success. An unresolved
load or different observed path fails the later run.

SystemVersion.plist states macOS26.4.1/build25E253 and is pinned. The exact
`/usr/lib/dyld`, `/bin/sh`, `/bin/ps`, `/usr/bin/vmmap` and vmmap manpage are pinned
as file bytes, without invoking them. The Cryptex cache root is
`/System/Volumes/Preboot/Cryptexes/OS/System/Library/dyld`:

- primary arm64e cache573,440 bytes, SHA256
  `23f83bb30ccedb95598b24850ac875df4031b84fa76da68cb6b1abff2537ef75`;
- exact arm64e map1,335,703 bytes, SHA256
  `22fb14ddcf854e3d828696b9b34b11f247b74ae456468bfc700b8cc20b14365b`,
  listing3,643 system image paths;
- twelve named arm64e subcaches retain size/mtime/first4096-byte hash with
  `full_file_sha256:null`. This is explicitly **cache metadata**, not a full
  subcache hash or a per-system-library content proof. x86_64/AOT caches are not
  admitted. No UUID is guessed from an undocumented byte offset.

Later system-image attribution requires exact named cache-map membership and
the reviewed OS/cache identity, not merely a `/System` or `/usr/lib` prefix.
System images remain labelled cached/system, never assigned fictional file
digests. Non-system observations require exact resolved candidate-file hashes.
If the inspector cannot distinguish the claimed mapping, identity remains
incomplete; do not normalize that ambiguity away.

## Namespace-visible system hook: source-backed binding and restoration

Retained R-lang.html2550–2575 places package lookups through imports then base
namespace before global/search path. R-ints.html974–999 says base and base
namespace use the same symbol-table bindings; their enclosing environments differ.
The retained fullrefman.pdf bindenv entry (PDF111–113, printed58–60) documents
lockBinding/unlockBinding/bindingIsLocked and changing an existing unlocked
binding even when its environment is locked. These exact documents are pinned
in the inventory. PDF text was extracted with the PDF skill, not by running R.

Pinned rSharp NAMESPACE imports methods/R6, not `system` from a different package;
R/zzz.R invokes unqualified `system` in `.checkDotnetPrerequisites`. Therefore:

1. At the start of the fixed collector, before loading ospsuite or rSharp, require
   rSharp absent from loadedNamespaces. Capture `asNamespace("base")`, its exact
   original `system` callable and original binding lock state. Reject an active
   binding or unexpected nonfunction. Do not create a global shadow.
2. Register restoration before changing anything. Unlock only this binding if
   needed, assign the narrow wrapper into that base namespace, and relock to its
   recorded lock state. Verify baseenv and base namespace resolve the wrapper.
   No environment-wide unlock, namespace file change or private CLR reflection.
3. Permit exactly the startup call
   `system("dotnet --list-runtimes", intern=TRUE, ignore.stderr=TRUE)` once. The
   wrapper validates exact named arguments/no extras and delegates the captured
   original callable with these unchanged arguments/defaults. Preserve original
   return vector, attributes, warning/error propagation and stderr suppression.
   Bounded receipt serialization must not replace the value rSharp receives.
4. Mark the allowed call consumed before delegating; retain parent-acknowledged
   begin/end and original status/output privately. Any second or other call is
   rejected, including failed-initialization retries. Keep the denial wrapper
   through Dispose; restore the original callable and original lock state only
   during final worker cleanup, checking identity of both lookups. Restoration
   failure is separate cleanup evidence, not success or a hidden replacement.

fullrefman.pdf system (PDF668–670, printed615–617) specifies that intern=TRUE
uses popen and a Unix shell, captures output lines and reports nonzero status in
the returned status attribute. It does not establish one exact transient PID or
the final shell argv spelling after stderr redirection. Freeze the exact R call
and resolved `/bin/sh`/dotnet images; retain actual observed argv/topology and
reject contradictions. Do not claim complete exec coverage from sampling.

This is the approved process-local hook, not a network/exec sandbox. Other R/C
execution entry points are not magically intercepted. Tests and the fixed
collector must prohibit their use; an observed forbidden child/image is fatal.

## Exact launcher and public call sequence

Intended argv is the absolute retained Resources/bin/exec/R, `--vanilla`,
`--slave`, `-f`, the fixed reviewed collector path, `--args`, one private fixed
configuration path. The parent controls every path; no user XML or R expression
argument and no wrapper/inline `-e`. Pin collector/supervisor bytes separately.

Provide exact retained R_HOME and its share/include/doc directories, empty
R_ARCH, reviewed private R library and framework library search, exact DOTNET_ROOT,
PATH beginning with retained dotnet then fixed system directories, single-thread
settings and private HOME/TMPDIR/cache/work. No inherited credential/proxy,
profile, Java, library-preload or alternate runtime override. Verify actual
.libPaths/namespace paths against the frozen roots before XML. This document
does not add a loader-directory exception beyond root's prior decision.

The fixed sequence uses the existing public rSharp NetObject `$get`, `$set` and
`$call` mapping (retained R/net-object.R266–323), not invented native APIs:

1. Install the hook; load jsonlite and preserve `library(ospsuite)`. Require
   exact installed ospsuite12.4.3/rSharp1.2.2 identities. Inspect
   `rSharp::getRSharpSetting("runtimeLoaded")` directly and require TRUE; this
   getter does not call .ensureRuntime. Stop on failure before any managed call;
   do not call dotnetAvailable or loadAssembly as a retry.
2. Explicitly load the exact retained OSPSuite.SimModel.dll; create one
   `OSPSuite.SimModel.Simulation, OSPSuite.SimModel`. Get `Options`; set
   AutoReduceTolerances=FALSE and StopOnWarnings=TRUE and retain cached managed
   getter results. Root confirmed public `Options` at pinned Simulation.cs211
   (constructor207). Do not label getters native-independent readback.
3. PRE_XML: collect two stable complete public managed-location inventories,
   registered R DLLs and namespace paths; hold this exact live object/process for
   the parent-owned bounded vmmap. Require the approved nine-image minimum and
   all other observations admitted against the frozen candidate/system evidence.
4. LoadFromXMLString gets only the exact Python-validated frozen fixture bytes
   decoded losslessly. FinalizeSimulation follows once. No XML rewrite, unit
   conversion, parameter override, high-level ospsuite simulation, sensitivity
   request, export, reset or code-generation call is introduced.
5. Positive cases call RunSimulation once; S01/S07/S08 call it twice on this
   same finalized object. After each successful call collect SimulationTimes,
   each exact fixture output entity ID through ValuesFor, its public IsConstant
   and unexpanded Values, fresh RunStatistics and SolverWarnings.Count. Preserve
   ordering, every returned double/count and17-digit serialization; no post-error
   statistics or filled-in missing outputs. Numeric bounds remain in the pure
   validator; unchanged legacy `native_constant` receives the public flag only
   under the amendment's explicit stored-size meaning.
6. S03/S04/S16/S17 require the original LoadFromXMLString/FinalizeSimulation
   rejection and zero Run calls. Constructor/options/readback/collection errors
   are not expected XML rejections. Both malformed table quantities remain the
   shared S16/S17 fixture; rejection cannot be attributed to one without evidence.
7. FINAL occurs after prescribed output collection or expected rejection,
   **before Dispose**. Positive cases additionally require the actual retained
   CVODES image. Do not force-load it; absence fails. Expected XML rejections do
   not assert a solver image. Then Dispose once if the object exists, restore
   the hook, retain process exit and complete exact-owned cleanup. Primary
   failure, Dispose, restoration, evidence and group-cleanup results stay separate.

The result is13 positive cases plus4 rejection cases,17 fresh workers and16
prescribed successful Run calls; repeats are preregistered calls, never retries.
No final technical pass exists until later execution and independent evidence
review, even if implementation mock tests pass. The stored-size constancy,
cached-option and managed-reported native-run-statistic labels remain mandatory.

## Remaining gates and durable lesson

Root/independent review must admit this exact candidate list and collector
mapping before code. Offline tests must cover binding restoration/second-call
rejection, failed startup without retry, case call ordinals, unknown image and
X11 exclusions, path/metadata changes, bounded partial evidence and FINAL-before-
Dispose ordering. They must invoke no actual R/CLR/native work.

Then independently review the fixed collector/supervisor and its OS-only probe.
The probe cannot establish R/dotnet topology. Only a later separately authorized
once-only17-case run can observe that topology, actual image maps, complete
cleanup and technical outputs. No prerequisite is erased because a candidate
list is complete. If preserved ospsuite startup invokes an unexpected helper or
loader branch, retain failure; do not change initialization to rescue the run.

Lesson: file inventory, namespace lookup and loaded-image observation answer
different questions. A source-backed namespace hook and conservative byte pins
make a bounded experiment inspectable; neither turns a failed biological
benchmark into validated evidence. CE/gbrain tools were not callable; this
docs/solutions packet retains the decision and reproducible method locally.
