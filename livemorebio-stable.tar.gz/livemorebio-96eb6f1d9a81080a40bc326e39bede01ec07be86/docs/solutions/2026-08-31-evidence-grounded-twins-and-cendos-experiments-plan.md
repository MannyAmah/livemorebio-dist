# Evidence-grounded twins and Cendos experiment demonstrations

**Date:** 2026-08-31  
**Branch:** `codex/interface-twin-onboarding`  
**Mode:** HOLD SCOPE, explicitly continued and expanded by the user  
**Status:** approved for implementation

## Outcome

Correct the A+B workspace so its Whole-body surface is a distinct living-person projection,
not the Biology organ-mesh explorer. Extend twin and cohort admission so every usable input has
field-level provenance, every reference-grounded cohort contains heterogeneous individuals, and
every experiment reports what was measured, what was calculated, and what remains unqualified.

The release slice will produce two detailed, real-interaction videos:

1. metformin across two individualized, reference-grounded T2D cohorts;
2. garcinoic-acid target engagement at human PXR using the measured 6P2B structure and published
   binding/activation values, with downstream effects left explicitly unqualified where evidence is
   missing.

## Premise challenge

A digital twin calculation is a simulation or model prediction, even when it uses mechanistic
equations, real molecular structures, real population data, and person-specific observations. It
becomes an observed human reaction only when a physical instrument, wet-lab assay, or clinical
measurement records that reaction. It becomes qualified only within the population, intervention,
dose, endpoint, and tolerance of a passed Cendos or clinical counterpart protocol.

This is not a wording detail. Calling a predicted trajectory “real evaluated data” would make the
platform scientifically indefensible and unsafe for pharmaceutical use. The product can still be
useful now: it can execute individualized, evidence-bound mechanisms, show uncertainty, generate
testable hypotheses, and close the loop as measurements arrive.

## Approaches considered

### A. UI-only correction

Remove the Biology mesh from Atlas, add more onboarding fields, and script the current demo.

- Effort: S
- Risk: High scientific and product risk
- Reuses: existing HTML and current screen endpoint
- Rejected because the saved cohort still contains only fingerprints and cannot reproduce the
  individual profiles shown in an experiment.

### B. Governed profile contract plus bounded experiment protocols

Add one profile-source contract, deterministic reference-population members, two bounded Cendos
protocols, one shared experiment-result projection, and a separate living whole-body renderer.

- Effort: L
- Risk: Medium
- Reuses: encrypted registry, metabolic/PK engines, Cendos evidence gates, workspace events, CLI,
  current charts, and existing Biology surface
- Selected because it fixes the data model and the user-visible evidence problem without replacing
  the existing product.

### C. Full clinical data lake and whole-body execution

Deploy SMART-on-FHIR connectors, credentialed research datasets, longitudinal feature stores,
every organ engine, validated device firmware, and production wet-lab integrations in one release.

- Effort: multi-quarter XL
- Risk: Extreme
- Deferred because access agreements, legal bases, dataset-specific validation, device builds, and
  wet-lab protocols cannot be created by repository code alone.

## Source truth

### Real-human twins

The admission bundle accepts bounded records from:

- FHIR R4 EHR resources: Patient, Condition, Observation, DiagnosticReport, MedicationRequest or
  MedicationStatement, AllergyIntolerance, Procedure, FamilyMemberHistory, and related provenance;
- LIFE Patch and other wearables through device observations with timestamp, unit, method, quality,
  and device identity;
- laboratory, genomic, medication, lifestyle, environmental, and region-level exposure records;
- consent, purpose-of-use, custody, and capture-time metadata.

No missing person value is silently synthesized. A model may initialize an unobserved value from a
named reference population only if that fact is visible at field level as `REFERENCE_INITIALIZED`.
Exact location and raw clinical narrative are not exposed to logs, videos, or the browser projection.

### Non-person twins and cohorts

OpenMed is not a patient-record source. It is a local clinical NER and de-identification toolkit.
Livemore will represent it as an intake processor, not a cohort generator.

Reference-grounded synthetic members will be generated from a versioned population-source
definition. The first release fixture uses named NHANES/DPP-style population descriptors and
explicit parameter distributions already supported by the metabolic engine. Each member receives
a stable seed, a unique profile, source lineage, and a `REFERENCE_GROUNDED_SYNTHETIC` evidence
class. No public dataset row is presented as a person, and no restricted patient record is copied.

```text
REAL PERSON                         NON-PERSON RESEARCH TWIN
FHIR / devices / lab / genomics    named population release + eligibility
              |                                  |
              v                                  v
      source validation                    distribution contract
              |                                  |
              v                                  v
      field provenance                      deterministic sampling
              |                                  |
              +-------------> TwinProfile <------+
                                  |
                                  v
                         executable model state
```

## Experiment architecture

```text
frozen cohort definition
        |
        v
individual member profiles -----> protocol applicability gate
        |                                      |
        |                                      +--> rejected / not assessable
        v
existing PK + physiology engine OR bounded target-engagement engine
        |
        v
per-member causal trace + uncertainty + evidence states
        |
        +--> Cendos run record
        +--> Biology visualization projection
        +--> CSV / JSON / Jupyter analysis artifact
        +--> evidence package (model-only until counterpart admitted)
```

### Protocol A: metformin cohort comparison

Two reproducible T2D cohorts will be created from the same named reference-population contract but
with different declared strata. Members remain varied within each stratum.

- Cohort 1: preserved OCT1 / reference renal-function distribution.
- Cohort 2: reduced OCT1-enriched / older renal-function distribution.
- Per member: age, sex, metabolic baseline, SLC22A1 state, renal factor, exposure, hepatic exposure,
  OGTT trajectory, glucose delta, insulin delta, and response decision.
- Evidence state: `MODELED_MECHANISTIC`, with real study and engine references, never `OBSERVED`.

### Protocol B: garcinoic acid and PXR

The protocol is constrained to evidence actually available in the supplied dossier and primary
structure record:

- Garcinia-kola compound identity remains distinct from whole-plant or seed claims.
- 6P2B is a measured human PXR-LBD/SRC-1p co-crystal with garcinoic acid.
- The attached structure yields 18 heavy-atom contacts within 4.0 Å, including His407–O10 at
  2.43 Å and Ser247–O09 at 2.66 Å.
- Published direct-binding/activation inputs are Kd about 0.33 µM and EC50 about 1.3 µM.
- The executable output is receptor occupancy/activation sensitivity across an explicit free-
  concentration range. CYP3A4 induction, systemic exposure, efficacy, and clinical DDI magnitude
  remain unqualified because the attached evidence does not supply the required translation model.

This turns the plant experiment into a rigorous question: “Does the measured ligand-target evidence
support PXR engagement under the tested exposure assumptions, and what wet-lab endpoints are needed
next?” It does not claim disease treatment.

## Whole-body and Biology separation

Atlas Whole-body will use only the `/api/workspace` state contract. It will not initialize the
registered anatomy/WebGL organ explorer or call `/api/biology`.

```text
Atlas Whole-body                      Biology explorer
----------------                      ----------------
living person silhouette              registered organ meshes
surface circulation / breathing       organ and pathway drill-down
LIFE Patch anatomical mount           anatomy provenance
system focus and biological time      active experiment mechanism
same timestamped workspace state      same timestamped experiment result
```

Motion is derived from returned heart rate, metabolic state, patch status, biological-time cursor,
and active mechanism. Contract-only systems do not animate as executed physiology. Reduced-motion
preferences remain honored.

## State machines

```text
PROFILE SOURCE
DECLARED -> VALIDATED -> ADMITTED
     |          |
     +-> REJECTED <---+

EXPERIMENT RUN
DRAFT -> APPLICABILITY_CHECKED -> RUNNING -> COMPLETED
                 |                    |          |
                 +-> NOT_ASSESSABLE   +-> FAILED+

EVIDENCE
REFERENCE / MEASURED_INPUT / MODELED_OUTPUT
       -> COUNTERPART_MATCHED -> QUALIFIED
```

Invalid transitions are rejected. A modeled result cannot self-promote to measured, validated, or
regulator-ready.

## Error and rescue registry

| Codepath | Named failure | Rescue | User sees |
|---|---|---|---|
| profile-source validation | `PROFILE_SOURCE_INVALID` | reject before persistence | field and source error |
| FHIR bundle intake | `FHIR_RESOURCE_UNSUPPORTED` | retain supported records; mark partial only when policy permits | resource count and reason |
| real-human activation | `PROFILE_COVERAGE_INSUFFICIENT` | keep data admitted | missing profile domains |
| reference cohort | `REFERENCE_SOURCE_REQUIRED` | no member generation | select a named source/release |
| deterministic sampling | `COHORT_GENERATION_FAILED` | no frozen cohort write | named generation error |
| experiment applicability | `PROTOCOL_NOT_APPLICABLE` | do not execute | unmet eligibility or evidence requirement |
| member execution | `MEMBER_EXECUTION_FAILED` | record member failure; run becomes partial | failed-member count and reason |
| garcinoic exposure | `FREE_EXPOSURE_UNKNOWN` | sensitivity range only | no systemic-effect claim |
| Biology projection | `EXPERIMENT_NOT_FOUND` | empty experiment state | run a Cendos protocol |
| artifact export | `ANALYSIS_EXPORT_FAILED` | preserve run | retryable export error |

No raw PHI, exact location, narrative text, or unredacted external-service response enters an error.

## Security and privacy

- Profile payloads remain AES-GCM encrypted in the local registry.
- Plaintext indexes remain opaque IDs, lifecycle, source class, version, and timestamps.
- Every source record has purpose-of-use and custody metadata.
- OpenMed processing is local-only; no clinical note is sent to a third-party model.
- The videos use deterministic reference-grounded synthetic members only.
- Browser output is a bounded summary, not the full admitted FHIR bundle.
- No physical LIFE Patch is treated as admitted until protocol-v2 envelope, calibration, attestation,
  and subject-binding checks pass.

## Test map

```text
PROFILE CONTRACT
  +-- FHIR/device/lab/genomic/lifestyle/environment source validation
  +-- every admitted field has provenance
  +-- exact location and raw notes rejected from browser projection
  +-- real-human missing values are not silently filled
  +-- encrypted persistence contains no PHI fixture strings

COHORTS
  +-- same seed/source/stratum produces byte-stable members
  +-- different members are not clones
  +-- stratum rules change distributions without removing within-stratum variation
  +-- OpenMed cannot be selected as a population data source

METFORMIN
  +-- two cohorts produce individualized per-member outputs
  +-- OCT1/renal differences alter PK and response trace
  +-- run is isolated from the live twin
  +-- output remains MODELED_MECHANISTIC

GARCINOIC ACID
  +-- 6P2B identity, contact count, Kd, and EC50 are pinned
  +-- activation is monotonic over concentration
  +-- absent systemic PK prevents systemic-effect qualification
  +-- plant, seed, extract, and purified compound are not conflated

UI / E2E
  +-- Atlas contains no organ mesh canvas or Biology API dependency
  +-- living body responds to returned state and reduced-motion
  +-- profile coverage and cohort heterogeneity are visible
  +-- both protocols update Cendos, Biology, evidence, and analysis views
  +-- two real-interaction MP4 recordings complete without console errors
```

## Performance and observability

- Cohort protocols remain capped for synchronous browser use; larger jobs belong in CLI/notebooks.
- Every run has a run ID, seed, protocol version, source release, start/end timestamps, member counts,
  partial-failure count, and result digest.
- External scientific sources are not called in the inner member loop.
- UI preserves the last consistent state during stream or export failure.
- PHI-safe structured events expose admission rejection, run lifecycle, and artifact creation.

## Deployment and rollback

1. Add contracts and tests without changing existing record compatibility.
2. Add reference-member generation and experiment run persistence.
3. Add Cendos protocol endpoints and analysis exports.
4. Replace only the Atlas body renderer; preserve `/biology` and `/legacy`.
5. Add UI workflow panels and browser tests.
6. Record videos using synthetic-only fixtures.
7. Run full suite, compile, JavaScript checks, diff review, and live browser QA.
8. Commit and push the feature branch, then open a PR.

Rollback is a git revert of this feature commit. Existing v1 twin/cohort records remain readable;
new fields are additive.

## What already exists

- encrypted `SubjectRegistry`, active-twin pointer, consent/custody/device guards;
- FHIR R4 as the workspace interoperability standard;
- `SyntheticHuman`, DPP cohort generation, metformin PK/pharmacogenomics, OGTT assay;
- Cendos service, counterpart qualification, evidence packages, and audit records;
- A+B Atlas, biological-time control, multiscale contracts, event stream, CLI/SDK;
- OpenMed local-extractor fallback and governed scientific-source catalog;
- Playwright H.264 recording infrastructure.

The implementation will refactor these paths into the new contract rather than create a parallel
product.

## NOT in scope for this release

- claiming an exact whole-human replica or clinical interchangeability;
- copying OpenMed Hugging Face model content as patient data;
- unrestricted public or controlled-access patient-level dataset ingestion;
- a quantified garcinoic-acid systemic PK, CYP3A4 fold-induction, efficacy, or safety claim;
- physical wet-lab execution, fabricated LIFE Patch hardware, firmware release, or human validation;
- deep executable coverage for every body system;
- automatic model calibration from a prediction or an unqualified experiment.

These are future program milestones with external evidence, regulatory, licensing, and physical
validation dependencies, not hidden omissions.

## Definition of done

- The Whole-body view is visibly and technically separate from Biology.
- Real-human and reference-grounded admission contracts preserve field provenance.
- Frozen synthetic cohorts contain stable, varied individual profiles.
- Both experiment protocols execute, visualize, export, and preserve evidence boundaries.
- Full automated and real-browser tests pass.
- Two detailed MP4s show genuine browser interactions and the complete evidence path.
- Technical, launch, terminal, experiment, LIFE Patch, Cendos, and future-build guides are current.
- Feature branch is committed, pushed, and represented by a GitHub PR.

## Future physical program

### LIFE Patch

1. Freeze the corrected Rev B hardware contract and remove Rev A contradictions such as treating
   MAX86141 as I²C, DS28E18 as an authenticator, and retaining redundant LMP91000 circuitry.
2. Implement signed firmware v2 packets, gateway transport, time synchronization, device identity,
   calibration records, replay, and local safety policy.
3. Complete electrical, EMC, biocompatibility, adhesive, sensor, analytical, cybersecurity, human-
   factors, and clinical-validation plans under design control.
4. Validate physical versus virtual signal equivalence per channel before enabling state updates.

### Physical Cendos Lab

1. Define LIMS identities for sample, aliquot, plate, protocol, instrument, operator, calibration,
   raw file, result, and deviation.
2. Start with the two software protocols in this release: metformin comparator assays and
   garcinoic-acid PXR target engagement/CYP3A4 induction endpoints.
3. Connect instrument files through immutable custody and QC gates; never copy dashboard values as
   measurements.
4. Admit qualified counterpart results into Cendos, compare to frozen predictions, and release only
   the bounded endpoints that meet protocol acceptance criteria.

## GSTACK REVIEW REPORT

| Review | Trigger | Why | Runs | Status | Findings |
|---|---|---|---|---|---|
| CEO Review | `/plan-ceo-review` | Scope and scientific product boundary | 1 | CLEAR | HOLD SCOPE; Approach B selected; 0 unresolved |
| Eng Review | `/plan-eng-review` | Architecture, data, tests, performance | 1 | CLEAR | additive contracts, isolated runs, explicit failure states |
| Design Review | approved A+B correction | Whole-body/Biology separation | planned after implementation | PENDING | live browser audit required |

**UNRESOLVED:** 0  
**VERDICT:** cleared to implement; diff-scoped review and live design QA remain release gates.
