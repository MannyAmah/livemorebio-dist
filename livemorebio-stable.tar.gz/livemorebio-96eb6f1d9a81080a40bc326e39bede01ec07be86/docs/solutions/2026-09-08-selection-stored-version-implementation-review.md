# Stored selection version: separate frozen maker packet

2026-09-08. Ready for independent grading, not accepted by its maker. Root
released this increment only after the audit-phase packet received independent
458-case clearance. Implements the full
[stored-version amendment](2026-09-08-selection-stored-version-bound-amendment.md),
SHA256 `798fc230b810734c375be6bae5218e8b813e5fa840879859c78b654e60868c51`.
The previous [phase evidence and independent grade](2026-09-08-committed-registry-audit-phase-implementation-review.md)
remain historical evidence of their exact earlier hashes, not this new packet.

## Frozen scope and hashes

| File | Phase baseline SHA256 | This packet SHA256 |
|---|---|---|
| `livemorebio/aegle/subjects.py` | `acef1a8562482f0504f7ff6430d949245e8c7d828a681044ed4d9fd4c90ce473` | `0867674f1693c02b0dd3f1797467f7682329504da330ccc61ac45d4eba7f6653` |
| `livemorebio/tests/test_committed_registry_transitions.py` | `f4c5a74467f381546beea4d78bf3567dc6f69f08fb07bd28f94fe1da491fc323` | `1985dc98faa36b6ac7914e921cc817cd9afd50cd2526c456d502f621c53e9e03` |

`registry_audit.py` stays exactly
`b21f01fdf1c79604c5565fee0f7d94d3b0bd11967b199bc97ec8a193de045e4e`.
The already authored checked-startup test-only packet stays at
`ed9c94102e1f9de0827f9dd44deaad23882532d3091d7c1df172a091d2e6dfc6`;
it was neither changed nor executed as part of this increment.

The runtime delta is only `_transition_read_version` at subjects.py:215 plus
the `_transition_snapshot` call at subjects.py:1149. The new validator admits
strict integer stored versions in `[1, MAX_SAFE_INTEGER]`. It uses the existing
fixed storage error; no integer conversion or repair is allowed. The existing
strict `_transition_version` remains unchanged, still requiring `< MAX` for
caller mutation preconditions and every actually changed row. Its transformation
calls at lines282/287 still protect target increments and active-row demotions.

Full authenticated/index equality, raw row/pointer/ACTIVE topology, phase audit
witnesses, exact physical-index retention, consent/admission and source guards
are unchanged. No new schema, timestamp, authority, clinical binding, model
parameter, numerical tolerance, execution gate or error code was introduced.

## Red and preservation evidence

Twenty-two additive `stored_version` cases were authored before the runtime
change. RED: **15 failed, 7 passed, 184 deselected in 1.43 s**, private root
`livemore-research-review-gkos02o4`. Eleven failures were the missing named
validator; four exercised the existing incorrect MAX read rejection, including
both actual virtual/replay binding paths. Seven preservation expectations already
passed, covering strict mutation rejection and authenticated/index disagreement.

After the six-line helper and one caller substitution:

| Packet | Result | Private root |
|---|---|---|
| Entire dedicated transition file | 206 passed in 6.63 s | `livemore-research-review-_rkmztaz` |
| Expanded preservation | 480 passed, 4 deselected in 22.67 s | `livemore-research-review-oqsfov6k` |

The expanded packet has one existing Starlette/httpx warning. Four `real_process`
bootstrap cases were intentionally excluded. Each run reported zero unexpected
network/process attempts and one explicitly refused optional Git metadata query.
All outer pytest processes completed. No browser, service, model, native worker
or operational record was used.

The tests assert: actual selected MAX reads require this request's durable BEGIN;
raw clinical/index bytes are preserved; unbound REAL-shaped and SYNTHETIC-shaped
records are read without a model; virtual/replay binding increments only the
other target and preserves the selected MAX row and physical index; replaying the
same prepared mutation conflicts; MAX target requests fail before any I/O;
demotion/preview clear still reject MAX; plain scalar type/domain checks and
authenticated/index mismatches remain errors. The original MAX−1→MAX success
and rejected further increment test remains unchanged and passes.

## Exact repeat scope

Use the complete private-environment, 60-second alarm and process-wide refusal
wrapper in the [phase report](2026-09-08-committed-registry-audit-phase-implementation-review.md),
unchanged except for the fixed descriptive refusal-message prefix. It patches
socket/DNS/urllib, subprocess and `BaseProcess.start`, and adds low-level
fork/exec/spawn/socket audit-hook refusal before pytest.

The expanded pytest argv is identical to that report: seven listed test files,
the four named lifecycle/pairing nodes, plugin
`livemorebio.tests.test_committed_registry_transitions`, `-p no:cacheprovider`,
`-k 'not real_process'`, `--tb=short`. RED selects only the dedicated file with
`-k stored_version`; dedicated GREEN selects that file without a filter.

## Acceptance boundary and lesson

Checked capture/confirmation at MAX remain preregistered RED tests waiting for
their separately approved reader implementation. This patch does not implement
or accept startup publication, old unchecked selection/reconciliation callers,
server/SDK/UI behavior, physical onboarding or biological equivalence. The six
requested scientific programs and their retained failures are unchanged.

Lesson: a terminal revision must remain readable even when another mutation is
forbidden. Reusing an increment guard for an unchanged read-set member creates a
false storage failure and blocks unrelated permitted work. Keep the two predicates
explicit while preserving exact authenticated identity and every write guard.

## Independent stored-MAX grade — 2026-09-08

The non-maker UI/review agent read the full amendment and maker report, all 22
additive cases, the changed helper and complete snapshot/transform consumers,
and the retained strict caller, before/after validation and terminal-version
regressions. The `/review` checklist was applied to this bounded packet, not to
unrelated inherited work. No runtime or test edit was made.

The scope was independently verified byte-for-byte: removing only the new helper
and reversing its one snapshot call substitution in a stdout-only reconstruction
produced the exact prior `subjects.py` SHA `acef1a8562482f0504f7ff6430d949245e8c7d828a681044ed4d9fd4c90ce473`.
The first 895 lines of the current test file exactly reproduce the prior test
SHA `f4c5a74467f381546beea4d78bf3567dc6f69f08fb07bd28f94fe1da491fc323`.
The frozen runtime/test/audit hashes above matched after testing; the separate
checked-startup test hash also remains `ed9c94102e1f9de0827f9dd44deaad23882532d3091d7c1df172a091d2e6dfc6`.

The exact expanded isolated packet completed **480 passed, 4 deselected, one
existing Starlette/httpx warning in 23.05 s**, exit 0. Interpreter:
`/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python`, Python 3.11.15. Private root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-ct42qzbj`.
The phase report's seven files, four lifecycle nodes, refusal plugin and
`not real_process` filter were retained. Socket/DNS, both urllib seams,
low-level fork/exec/spawn/subprocess and multiprocessing start were refused.
Final counters: **0 unexpected network/process attempts; 1 explicitly refused
optional Git metadata lookup**. No browser, service, native solver, model or
operational store was used. Four process-spawning tests remain unexecuted.

**No actionable blocker found in the stored-MAX packet.** The read guard accepts
only actual integers through MAX; authenticated payload/index equality still
applies. Caller preconditions and every increment/demotion still require less
than MAX. The actual virtual/replay paths preserve an untouched selected MAX
row while incrementing only the other target; replayed mutations still conflict.
This grade does not implement or accept checked startup, source publication,
unchecked observation/reconciliation callers, physical validity or numerical
qualification. Those remain separately required work.
