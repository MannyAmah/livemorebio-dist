# Execution molecular consumer — independent source and boundary review

2026-09-09. Review scope: the fixed-execution consumer only, not ordinary Biology,
saved-run integration, vendor admission, native molecular interaction or scientific
execution. No browser, service, operational store, biological constructor,
coordinate parser, native computation or external request ran in this review.

## Verdict

The two independently reproduced ownership defects are corrected in the frozen
source below. The corrected consumer/parent source is clear for this bounded
technical increment. **Real molecular rendering and the parent plan's three-context
browser acceptance remain pending.** No installed-product or scientific claim follows.

I read the complete parent structure-only plan, execution increment and its
pre-code correction, all original12 tests, actual execution consumer, actual
shared inspector, full continuous-execution parent, and relevant anatomy teardown.
The review skill supplied source, lifecycle, plan-completeness and frontend
trust-boundary checks. Connected CE/gbrain were unavailable; the lessons and exact
evidence are retained here. No skill-driven remote fetch, source autofix or browser
step was performed.

## Findings, original proof and minimal correction

1. **Geometry failure skipped the independently owned molecular teardown.**
   Original execution_anatomy.js:68 invoked explorer.dispose before scheduling
   molecular.dispose, after already setting disposed=true. An authored throw left
   inspector_disposals=0, including after an explicit second dispose. This is an
   actual consumer branch with an inert geometry fault, not evidence that a real
   WebGL disposal failed. The existing geometry disposer invokes resource disposers
   without swallowing their exceptions, so the fault was not an impossible seam.

   Root's correction separately catches geometry failure, records
   anatomyCleanup=unconfirmed and fixed geometry status, then always observes
   molecular disposal. The permanent regression proves exactly one attempt for
   each owner, no escaped raw error, stale-click refusal and no false molecular
   failure when molecular teardown succeeds.

2. **The execution parent overwrote nested control validity.**
   continuous_execution.js controls() originally assigned disabled=busy to every
   descendant button/input/select. Its actual mounted engine-change handler
   changed an authored inspector-owned control from disabled=true to false,
   with zero requests. The same controls() is called by status rendering.
   This is control-ownership evidence, not a claim that the probe rendered Molstar
   or exercised a particular upstream selection algorithm.

   Root captures the original parent control elements immediately after its
   markup, before mounting nested components. Only that fixed set receives the
   parent busy update; existing engine/LIFE predicates remain unchanged. The
   permanent regression preserves the late-mounted disabled child while proving
   an original parent-owned control still receives its update.

The actual inspector close() synchronously invalidates and hides the old owner
before its first await; open() waits for prior cleanup. Therefore I did not treat
the consumer's unawaited close call as a race by itself. Independently deferred
old-open and old-close rejection checks also passed: a newer target's fixed
feedback is not overwritten. Those checks now remain permanent regressions.

Immutable context is captured as the exact execution ID, source snapshot hash
and selected twin ID before caller mutation. Target labels and attributes are
escaped; exact keys, including unknown mappings, are passed without substitution.
The only consumer source request remains /api/biology/reference. Existing
section/labels/organ/retry tests are unchanged. The shared inspector, source
loader, anatomy geometry and numerical mechanisms were not edited by this review.

## Retained runs and attribution

All private suffixes below are beneath
/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-.
Results were returned by the tool; no absent JSON receipt is claimed.

| Run | Exact result | Private suffix / tool chunk |
| --- | --- | --- |
| Independent frozen original12 |12 passed1.11s; I/O0 Node12 Git0 |bevomk2_ /2b916e exit0 |
| Two original authored fault probes |2 reproduced failures; inspector disposal0 and nested disabled=false; I/O0 Node2 Git0 |947le3rg /e33d9b exit1 |
| Deferred old-open/old-close preservation |Both passed; I/O0 Node2 Git0 |5r_ingw1 /7211b7 exit0 |
| First permanent combined16 |15 passed/1 failed1.44s; I/O0 Node16 Git0 |1xvgwexi /70df95 exit1 |
| Final permanent combined16 |16 passed1.42s; I/O0 Node16 Git0 |fg8_tvk_ /41b82d exit0 |

The first permanent16 failure was my **fixture expectation**, not a remaining
product defect: it incorrectly required molecularCleanup for a geometry-only
failure whose molecular cleanup succeeded. Root approved changing only that
added assertion to anatomyCleanup, the exact fixed geometry status and absence
of a molecular-failure marker. All original ownership assertions remain.
The original two fault probes predate root's correction; the permanent test file
was completed while root corrected the already-proven branches. Do not relabel
the16-case fixture failure as the original product RED.

This reviewer authored only the new four-case boundary test and this report;
root remains responsible for reading those test fixtures independently.
No original test assertions were weakened.

## Frozen identities

| File | SHA-256 |
| --- | --- |
| Corrected execution_anatomy.js |6a4b203d3deef9227b4fbea6b5b8c13deed0a222cf17ffc063af610d9348a959 |
| Corrected continuous_execution.js |1aa54708c795987fb2fbd4d01e25757778d713ef45aaaea103f6f0befa6c15b6 |
| Original unchanged test_molecular_consumer_bindings.py |15730a29cb1aa37da5b8ccb865a3637c5361d7f1b6792220ccd1b1d44b9fbdf2 |
| New test_molecular_consumer_boundaries.py |5dcb354895e71cc3f58c48ddcee2067465c4ebbc01a032052e8ba72e53acf6f1 |

Original source identities remain review history:
execution_anatomy1f30bc3d8ce7b9a446adc80145b9b7227051036bc28622e77f0fc6188c0b508a;
continuous_execution868563126ccf48222c499c731cf576f7006111b465a09d5c6add768d97261aab.

## Exact final repeat

Run from /Users/emman/Livemore/.worktrees/full-scope-recovery.
The45s outer alarm and10s Node child limits are bounded test instrumentation,
not a general OS sandbox. Only fixed Node eval is admitted; the real consumer
fetch is replaced by its authored catalog seam. The parent ownership test makes
zero requests. New test fixtures use no private retained artifact paths.

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os,socket,subprocess,sys,urllib.request,ctypes,signal
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1';os.environ['PYTHONDONTWRITEBYTECODE']='1'
signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1;permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=short','livemorebio/tests/test_molecular_consumer_bindings.py','livemorebio/tests/test_molecular_consumer_boundaries.py'])
print('Refusal counts:',counts,flush=True);signal.alarm(0)
raise SystemExit(status)
PY
```

## Lesson

A nested component's owned cleanup and control validity are separate boundaries.
Catching its own rejected promise is insufficient if an earlier sibling teardown
can prevent that promise from being scheduled; a parent-wide control sweep can
also silently override a correctly guarded child. Test these two small actual
caller branches without claiming a stubbed DOM proves usable molecular rendering.

