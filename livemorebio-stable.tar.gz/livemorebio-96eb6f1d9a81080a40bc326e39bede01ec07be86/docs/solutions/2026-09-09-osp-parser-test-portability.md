# Portable parser regressions and retained local forensics

This is a test-only continuation of the accepted unused-region parser correction.
The production supervisor remains frozen at d2ac1bac… for the molecular build;
no process budget, parser, scientific gate or consumed result will change.

The default parser test file currently reads a prior machine-local diagnostic
stdout and two failed receipts beneath /private/tmp. An external checkout cannot
run those assertions. Skipping missing originals would conceal that dependency.

Before editing, reproduce the failure by running the existing test file while
refusing reads beneath /private/tmp. This is a portability test, not a new parser
failure. Then separate only the19 retained-row/full-corpus tests and the failed-
receipt hash test into an explicitly invoked, non-default-collected forensic
module under tools/diagnostics. Keep every original path, digest, count and
assertion there; no copying machine data into the product or deleting evidence.

The default test file keeps every authored grammar/refusal case and the current
budget/closed-gate assertions. It must pass with machine-private reads refused.
Explicitly run the forensic module against the unchanged local originals and
repeat the existing offline preservation suite. Document the different scopes;
neither suite proves native execution or scientific equivalence. Request an
independent diff review before release. No runtime, dependency, browser or store
operation is authorized by this test cleanup.

Lesson: portable regression fixtures describe the format contract. Machine-local
forensic receipts prove a particular historical event and require an explicit
local evidence invocation, not an implicit prerequisite for every installation.

## Maker results; independent diff review pending

Original default suite with private reads refused:1 failed,42 passed,19 setup
errors in0.13s; privateg6jpto6q, chunkfb8006. Two attempted private reads caused
all20 affected cases; no network/native/child operation. After the separation:
43 portable tests passed0.06s, privaterj_ltfi9, chunkfc0129, private reads0;
20 explicit forensic tests passed0.06s, privatez5rt22gk, chunkbe0189. Every original
forensic assertion remains, and the combined suite has one extra test because
the old combined budget/receipt check is now two separately scoped checks.

Full combined offline preservation:503 passed,2 native-watchdog cases deselected,
1.49s, session22316, privatele5g1i0v, unexpected I/O0. The default authored file
is SHA256c574694d7a5b271078f98013e6873f48c207b117751cbb703cf478c964155415;
explicit tools/diagnostics/osp_vmmap_retained_forensics.py is
beab9fe26032a8989e00c0408d53afed1991a989a8e86dc544434a9f407337af.
Supervisor remains exactly d2ac1bac780fbbeec7ad759994068104db8cb1eb70c95a3b3180696999117235.
No historical receipt, subprocess budget, parser or gate changed.

## Independent source-only review

Release reviewer read this complete plan/result, both complete split files, the
original parser implementation report and the unchanged supervisor's import/limit
declarations. Current hashes independently match `c574694d…`, `beab9fe2…` and
`d2ac1bac…`. No test, OS inspector, native worker or browser was run for this review.

The default file contains seven authored valid forms, 30 malformed-form refusals,
one empty-inventory refusal, four original format/identity/size refusals and one
unchanged-budget/closed-gate case: 43 cases. It contains no machine-local artifact
read. The explicit forensic module retains all 18 exact rejected line numbers,
the 322954-byte original corpus digest, 351 sorted unique positive paths and their
exact digest, all 17 unused-only path exclusions, and both original failed-receipt
hash/status assertions: 20 cases. Missing originals fail rather than skip.

Static AST inspection found no skip/xfail/importorskip call in either file and
identical `report()` helper ASTs. The project has no custom pytest filename pattern
that would collect `osp_vmmap_retained_forensics.py` by default. Source comparison
against the retained original report found no omitted assertion category, relaxed
expected value or hidden fallback. Separating the combined budget/receipt case
explains the increase from 62 to 63 cases; it is not new scientific coverage.

Provenance limit: the original 129-line untracked file's published SHA is
`84690c262cb392b3a85e2b4e3bedc25924bf3e4e637e6675074c24c7a9146c41`, but an
independent old-byte copy was not available to this review. Consequently this is
not a claimed cryptographic old/new AST-equivalence proof. The maker's executed
43/20/503 results above remain attributed to the maker, not an independent repeat.
Within that limit, the test-only separation is clear; budget B and all execution
gates remain separately held.
