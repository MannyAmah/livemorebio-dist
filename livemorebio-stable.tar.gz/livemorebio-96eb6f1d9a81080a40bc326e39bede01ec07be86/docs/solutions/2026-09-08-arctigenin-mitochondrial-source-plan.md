# Arctigenin/Burdock: mitochondrial mechanism and measurement dependency plan

2026-09-08. **Proposal for independent review; no model code or new solve has
been run.** This advances the required arctigenin program in the
[five-program dependency packet](2026-09-08-five-program-mechanism-measurement-plan.md),
not a replacement for individualized whole-human experiments. The insulin program
and all five botanical programs remain required. The failed OSP benchmark is
preserved and is not bypassed by this candidate.

## 1. Decision and context

Use the unchanged, pinned Beard CellML model first as a **mitochondrial reference
mechanism candidate**. It is neither a human arctigenin model nor a complete
cell. Before a compound-specific intervention can enter it, obtain a defensible
exposure-to-complex-I activity mapping. A named arctigenin dose is unsupported
until that mapping and its applicability have been reviewed.

Arctigenin reference identity: PubChem CID64981,
InChIKey `NQWVSMVXKMHKTF-JKSUJKDBSA-N`, formula C21H24O6. This is the molecule,
not a measured burdock extract, batch purity, bioavailability or mitochondrial
exposure. Arctiin is a distinct precursor, not an interchangeable material.
[PubChem arctigenin](https://pubchem.ncbi.nlm.nih.gov/compound/64981).

Huang et al. report mitochondrial complex-I inhibition and AMPK/metabolic
responses in myotubes, isolated muscle, hepatocytes and mice. Gu et al. report
energy-deprivation injury in glucose-starved A549 tumor cells. These observations
motivate both adaptation and toxicity endpoints, not a universal beneficial
response or a human dose-response. The publicly readable abstract of the former
does not supply a transferable binding/kinetic law. Its subscription full text
was not bypassed. [Huang 2012](https://pubmed.ncbi.nlm.nih.gov/22095235/),
[Gu 2012](https://pubmed.ncbi.nlm.nih.gov/22687625/).

Beard's model was parameterized on steady-state mitochondrial data; the author
explicitly identifies missing kinetic evidence for time-dependent validation.
Its boundary includes an empirical dehydrogenase drive, and it omits explicit
TCA, complex II, sodium/calcium transport and whole-cell regulation. A computed
time series is therefore numerical model behavior, not a validated arctigenin
reaction time course. [Beard 2005](https://doi.org/10.1371/journal.pcbi.0010036).

## 2. Actual source artifacts and permission

The [PMR exposure](https://models.physiomeproject.org/exposure/959a4da5d8a0638f4b36adf5800f4fc0/beard_2005.cellml/view)
identifies changeset `8ec69b34c31cd1cbb53580d1853841bb333de78e`, states that this
curation corrected dimensional errors, and licenses the work CC BY3.0. Preserve
author/curator credit, source URL, license, byte hash and any later change record.
The curation's statement of replication is source metadata, not our benchmark.

Small public files inspected in private storage only:

| Artifact | Exact SHA-256 |
| --- | --- |
| `beard_2005.cellml` | `4a4f931592df0e77a92c79447bf6d8947c7325f721a74b4d336d370abaaf3981` |
| `beard_2005.session.xml` | `29c9f91469412b941177f5733d3c864a0a8f1dd2dd040708cf219d22d3501c78` |
| Exposure HTML as retrieved | `0b28fc549e5609624c6403ef1911a1a86aa2d2b474af94b3b22a0a894623fa1c` |
| Publisher correction XML | `dec62248eefdda7809ba6038ca13ee2de04fd028435cc97b4c4b9721551fd485` |

Fixed source URLs:

- [CellML bytes](https://models.physiomeproject.org/workspace/beard_2005/@@rawfile/8ec69b34c31cd1cbb53580d1853841bb333de78e/beard_2005.cellml).
- [Session metadata](https://models.physiomeproject.org/workspace/beard_2005/@@rawfile/8ec69b34c31cd1cbb53580d1853841bb333de78e/beard_2005.session.xml).
- [2006 correction](https://doi.org/10.1371/journal.pcbi.0020008),
  [publisher XML](https://journals.plos.org/ploscompbiol/article/file?id=10.1371/journal.pcbi.0020008&type=manuscript).

Private evidence directory: `/tmp/livemore-arctigenin-source.BCaB9w`. No licensed
subscription content, participant data or operational model cache was copied.
The PMC metadata skill independently resolves the correction as PMC1356095,
CC BY, open access, not marked retracted. That metadata does not validate equations.
The correction XML contains its table as commented markup; numerical comparisons
below are extracted from that markup. A visual check against the published table
is still required before admitting a corrected parameter package. Browser-tool
image/PDF retrieval failed; do not pretend that check occurred.

## 3. Exact state, units and source discrepancies

Parsing the actual CellML MathML, without executing it, finds **19 differential
variables** in document order. Store qualified names rather than depending on
whatever state order a solver chooses. All concentrations below are mol/L of
their stated compartment; time is seconds, potential is mV.

| Component.variable | Initial value |
| --- | ---: |
| dH_x_dt.H_x | 6.30957344480193e-8 M |
| dK_x_dt.K_x | 0.14 M |
| dMg_x_dt.Mg_x | 0.005 M |
| dNADH_x_dt.NADH_x | 0.0015 M |
| dQH2_dt.QH2 | 0.0008 M |
| dCred_dt.Cred | 0.001 M |
| dATP_x_dt.ATP_x | 0 M |
| dADP_x_dt.ADP_x | 0.01 M |
| dATP_mx_dt.ATP_mx | 0 M |
| dADP_mx_dt.ADP_mx | 0 M |
| dPi_x_dt.Pi_x | 0.001 M |
| dATP_i_dt.ATP_i | 0 M |
| dADP_i_dt.ADP_i | 0 M |
| dAMP_i_dt.AMP_i | 0 M |
| dATP_mi_dt.ATP_mi | 0 M |
| dADP_mi_dt.ADP_mi | 0 M |
| dPi_i_dt.Pi_i | 0.001 M |
| dPsi_dt.dPsi | 160 mV |
| dO2_dt.O2 | 0.000026 M |

Here `x` is matrix, `i` intermembrane space, `e` external buffer; `m` in nucleotide
names denotes the Mg-bound form, not a new anatomical compartment. The source
sets `dO2/dt=0`: oxygen is a chemostatted boundary, **not** blood-oxygen depletion.
Its extra explicit ADP equation is the negative of the ATP equation, so
ATP_x+ADP_x remains0.01M. Together with constant O2 this explains the representation
difference from the paper's17 equations; prove that identity rather than deleting
states. Free and Mg-bound nucleotides must not be counted twice in total pools.

Actual defaults also include buffer Pi_e0.000125M, ADP_e/ATP_e/AMP_e0,
Mg_tot0.005M, pH_e7.1, K_e0.15M, RT2.4734kJ/mol, F0.096484kJ/(mol·mV),
NADtot0.00297M, Qtot0.00135M and Ctot0.0027M. These are reference conditions,
not a person's measured values. Native import must retain every other constant,
piecewise guard, algebraic relation and unit definition from the pinned bytes.

Material differences versus the correction's table text:

| Item | Actual CellML | Correction table text | Consequence |
| --- | ---: | ---: | --- |
| Complex-I activity | 0.36923 | 0.36923 with phosphate control | Matching source anchor, not compound potency. |
| AK activity x_AK | 0 | 1e6 | Disabled versus near-equilibrium reaction; unresolved context/version difference. |
| Matrix water fraction |0.9×0.72376=0.651384|0.6435| Different concentration/flux conversion. |
| IM water fraction |0.1×0.72376=0.072376|0.0715| Same volume issue, not harmless display scaling. |
| Inner-membrane capacitance |6.756756756756757e-6|6.75e-6| Different precision; retain exact source. |

No change above is authorized. A source-reproduction record must distinguish the
unmodified PMR implementation from a separately reviewed corrected-paper variant.
Do not alter constants until a desired plot appears. The custom CellML unit
definitions carry mitochondrial-volume tags; a parser discarding them must not
be treated as a successful dimensional check.

## 4. Executable mechanism and arctigenin admission boundary

These equations are direct readings of pinned CellML, not a new fitted model:

```text
dG_C1op = dG_C1o - RT·ln(H_x / 1e-7 M) - RT·ln(Q / QH2)
J_C1 = x_C1 · [exp(-(dG_C1op + 4·dG_H)/RT)·NADH_x - NAD_x]
dNADH_x/dt = (J_DH - J_C1)/W_x
dQH2/dt = (J_C1 - J_C3)/W_x
dATP_x/dt = (J_F1 - J_ANT)/W_x
ddPsi/dt = (4J_C1 + 2J_C3 + 4J_C4 - n_A J_F1 - J_ANT - J_Hle - J_K)/C_im
```

Fluxes have units mol/(s·L mitochondrial volume), not concentration per second
until divided by the appropriate water fraction. `x_C1` has units
mol/(s·L mitochondrial volume·M). Preserve the source signs and proton/redox
terms; a generic positive “drug benefit” weight cannot replace them.

After baseline acceptance, a **prospective capacity-sensitivity protocol** may
vary the dimensionless remaining-activity fraction `a` with
`x_C1_condition = a × x_C1_source`. This is a declared perturbation of model
capacity. It is not an arctigenin concentration-response, a Ki or a time-dependent
binding mechanism. Any grid must be preregistered separately; no dose slider,
compound-name route or human benefit label is enabled by this proposal.

To admit an arctigenin-specific mapping, obtain assay-resolved complex-I activity
versus **free site exposure**, substrate/cofactor conditions, temperature,
incubation time, reversibility/washout, uncertainty and independent replication.
An intact-cell OCR decrease alone cannot identify direct complex-I inhibition
separately from uptake, ATP demand, toxicity or other respiratory targets. An
IC50 cannot silently become Ki; a single endpoint cannot identify on/off rates.
Concentration-to-activity fitting uses a development subset and a frozen held-out
subset with assay-specific acceptance criteria, not the same data twice.

## 5. Proposed implementation and native acceptance gates

Each stage needs independent approval before code/solves. No source script is
executed by this research step. Candidate runtime is the already reviewed
Myokit1.39.2/SUNDIALS7.8.0 path, **not yet verified for this CellML file**.
Unsupported custom units, imports or algebraic constructs fail explicitly.
An OpenCOR comparison is optional only after its exact runtime is approved.

1. **Red source-contract tests, then import.** Fixed URLs/hashes/CC BY credit;
   no external XML entities, unknown imports or unit dropping; exact19-state map,
   all initial values, complete constants, algebraic assignments and source
   conditions. Independently verify the ADP conservation identity and constant
   oxygen equation. Preserve the source/paper discrepancy register.
2. **Preregister native test matrix before the first solve.** Proposed unchanged
   default runs over0–300s at RTOL1e-7/ATOL1e-11 and RTOL1e-9/ATOL1e-13;
   log full state/flux arrays on a shared0.1s grid plus exact endpoints. These
   solver tolerances are numerical policy, not biological accuracy. Repeat the
   tighter run and compare a150s full-state checkpoint continuation. Retain
   solver version, compilation identity, warnings, time/RSS and all failures.
   Use private worker storage, a120s wall deadline per solve and a64MiB output
   bound; measure peak RSS and stop at a1GiB worker budget. Inability to enforce
   the resource guard is an implementation blocker, not permission to run
   indefinitely. These limits are prospective and independently reviewable.
3. **Numerical gates, no post-hoc relaxation.** Every identity/time must satisfy
   `abs(a-b) <= atol_quantity + 1e-6*max(abs(a),abs(b))`, with comparison floors
   1e-12M for H,1e-10M for other concentrations,1e-4mV for potential and
   1e-9mol/(s·L mitochondrial volume) for fluxes. Check all states, not only
   ATP. Record every negative concentration; `c < -atol_quantity` fails numerical
   acceptance. Negative values in `[-atol_quantity,0)` are not physical. Such
   negatives remain flagged numerical uncertainty, never clamped or called
   physical. Require positive logarithm arguments; test Mg-bound≤total,
   conserved NAD/Q/cytochrome pools and ATP_x+ADP_x. Steady-state claims require
   a separate prespecified scaled-RHS/terminal-drift check, not elapsed time.
4. **Source-replication gate.** Obtain original author reference arrays/recipe
   or reconstruct exact published figure conditions with reviewed extraction
   uncertainty. First resolve AK/water-fraction differences. Paper-reported
   P50=0.373µM and cytochrome reduction≈14% at50µM O2 are possible check targets,
   not independent ground truth or all required boundary conditions. Full figure
   recipes and tolerance registration must precede these new runs. A diagram,
   successful import, or agreement of two solvers on the same wrong recipe
   cannot pass this gate. [Beard figure6](https://doi.org/10.1371/journal.pcbi.0010036.g006).
5. **Only then expose an isolated Cendos reference protocol.** Freeze explicit
   source/condition identity in history and export complete arrays for notebook
   analysis. Biology may display the computed mitochondrial quantities in
   native seconds with honest replay/live state. Do not animate uncomputed
   bonds, ROS, signaling, organ motion or drug transport. No physical LIFE
   observation mapping is currently admitted for these states.

## 6. Whole-individual program remains open

Required next dependencies are material/batch characterization; parent/arctiin/
metabolite gut–liver handling and tissue/site exposure; human tissue-specific
mitochondrial quantities and ATP demand; AMPK/signaling and glucose transport;
redox/injury/repair mechanisms; and cross-system circulation/endocrine coupling.
Each coupling needs units, conservation, latency, parameter lineage and paired
independent measurements. Public descriptive cohort rows alone supply none of
these kinetic bindings. A human gene identifier does not turn rat mitochondrial
reference parameters into individualized human biology.

Cendos physical validation would measure assay identity, material lot/purity,
free exposure, oxygen-consumption flux, nucleotides/redox, membrane potential,
cell viability and washout recovery with matching clocks, calibration/QC and
prespecified held-out specimens. No physical assay was performed here. Long-term
tissue recovery, pathological memory and treatment-free stress resilience are
separate endpoints; none follows from an ATP or AMPK change.

**Current gate status:** lawful source acquisition/inspection complete; source
discrepancies visible; native feasibility, numerical acceptance, source replication,
arctigenin mapping, human contextualization, UI execution and physical qualification
all pending. The next approvable increment is source-contract/native-reference
work, not claiming the required whole-individual botanical program completed.

Compounded lesson: a curated model's name and article DOI do not identify its
actual equations, parameter variant, state representation or experimental recipe.
Compare pinned bytes with corrections before running a compound study; keep
capacity sensitivity, compound potency and human outcome as distinct contracts.

## Stage 1 execution record — 2026-09-08

Root independently read and approved this plan for source-contract and native
import feasibility only. The bounded utility and red-first tests now retain the
exact source inventory and test the installed native parser. **Dimensional import
was rejected:** Myokit1.39.2 returned a parsed object with three warnings after
replacing the source's `cell`, `cytoplasm` and `mitochondria` base units with
dimensionless units. No equations, constants or unit declarations were altered;
no native solve or public execution integration was performed.

The complete [source/import report](../BEARD_MITOCHONDRIAL_SOURCE_IMPORT.md)
records counts, the two checked algebraic identities, measured parser/runtime
resources, reproducible tests and the next required engine/translation decision.
Twenty source/import tests passed with the explicit pinned-source opt-in; maker
tests still require independent review. The native dimensional gate is blocked,
not completed. No Stage 2 numerical matrix or compound mapping is admitted.
