# OSP rejected-startup evidence — one actual technical invocation

2026-09-09. Root decision within the approved full-scope correction work.
This is not a scientific insulin experiment or permission to modify biology.

## Independently reviewed readiness

The supervisor correction has independent complete source/test review and
553 passing offline cases (`61995d`, two native watchdog cases excluded).
The fresh once-only launcher has independent complete review and 72 passing
offline cases (`f29d3c`, zero unexpected I/O). See the rejected-process evidence
plan and retained-startup successor proposal for exact RED/GREEN and boundaries.
Root independently verified all current input pins and original CA533x evidence
in `6c0f6f`. No actual artifacts existed in the new control root at that check.

Root accepts the limited prior O1–O7 OS receipt together with the independent
offline amendment review for this one technical run: native ABI interfaces,
process classifier, ownership and cleanup functions remain unchanged, while
sampler stage labels and bounded failure retention are added. This is not a
fresh OS preflight, historical native-source attestation or scientific clearance.
No native startup candidate is allowlisted merely because it is observed.

## Exact single authorization

Private root: `/private/tmp/livemore-osp-native-once-evidence.qUfcQ6`.
Launcher SHA-256:
`4e3663b182f901a9d82df03ba39d8aa30f7d140205bc36167069e0a7a2b6e2df`.
Supervisor SHA-256:
`af735907d6eeb1ab4d158cc9a365d61e4af6f71d8c2e3b70afe4631b5b398dd6`.
Protocol SHA-256:
`5eb866376a2b121109066dbb11edad2eba701b3b85c8fe474ae1aa02b8e505e7`.
All six input hashes and the exact prospective command are in the independently
reviewed successor proposal. No other command or input substitution is approved.

Root authorizes creating only the exact canonical OSP_NATIVE_ONCE_AUTH_V1 object
for those seven identity hashes, then invoking the proposal's exact isolated
`env -i` / Python 3.11.15 `-I -B` hash-checking command **once**. The launcher
owns private home/tmp/cache creation and exclusive once/completion writes.
Preserve the once marker after every outcome; no automatic retry.

The unchanged schedule is all S01–S17, at most 17 R workers and 16 prescribed
Run calls, vector `[2,1,0,0,1,1,2,2,1,1,1,1,1,1,1,0,0]`. Stop on the first
failure. This is not an unannounced startup-only or easier substitute protocol.
Keep 600 s packet/completion, 30 s worker including cleanup, CPU soft20/hard21 s,
3 GiB sampled group RSS, 0.1 s sampling target / 0.5 s maximum gap, 3 s inspector
including 0.5 s cleanup, all stream/result/tree limits, and the 768 KiB/12-entry
sidecar reservation inside each existing 4 MiB/256-entry case ceiling.

All six source/runtime/OS-receipt input pins, launcher and tests remain frozen
through completion and cleanup. No concurrent browser or other native/model
run. No network acquisition, operational/participant store, hardware command,
existing experiment/cohort mutation, model admission, calibration or release.
The private process may set the two already reviewed gates in memory for one
call and must restore them; source gates remain false. An unresolved owner may
not be reset or bypassed.

## Required post-run evidence

Preserve terminal exit, completion, raw packet and reached case results even
if FAILED. Inspect only the exact returned private root and known work/cleanup
sidecars for reached workers/inspectors. Bound each sidecar read to 64 KiB and
whole case traversal to existing 4 MiB/256 entries. Check original phase/code/
stage, counts, sample versus retention state, reference hash/bytes and separate
accepted observations. A missing or aliased atomic artifact stays an explicit
failure, not a repair or a complete sample. If no root returns, do not invent it;
any follow-up inventory must be separately bounded to this exact private TMPDIR.

Verify source preservation and recorded owned cleanup; a read-only exact-PID
postcheck may cover only recorded identities. Never signal unrelated or uncertain
processes. Request independent data-only result review without another run.
Both prior failed packets remain unchanged and the original CA533x descendant
cannot be reconstructed from this new observation. All numerical/scientific
insulin-source failures, R01–R51 requirements and six requested videos remain.

## Actual result — FAILED with retained startup identity

The exact once-only command completed as `e16aee`, exit1, in
0.7936043750378303s before completion. It returned the exact private packet root
`/private/tmp/livemore-osp-native-once-evidence.qUfcQ6/tmp/livemore-osp-semantic-xh3jeb2w`.
Packet SHA256 is `386fd59ed5d69ebcad9a0ba4c093789f9786aad12be47fb77170b6b8fd592797`.
Overall FAILED/PACKET_REJECTED remains; source preservation CONFIRMED and no
launcher evidence errors. S01 FAILED/UNEXPECTED_DESCENDANT before any barrier,
comparison or inspector; S02–S17 NOT_RUN. Secondary PROCESS_FAILED records the
terminated worker, not numerical-model execution success.

The work sidecar preserves a complete but UNADMITTED sample: two enumerated,
sampled and retained rows, zero omitted, no retention errors, 1299bytes and
SHA256 `d5ee0f102a7efa8d71244acbfab9fc30a510f0a02aff0ae3edee155e6a598781`.
In addition to R leader47065, it records PID47070/PPID47065/PGID47065,
image `/bin/bash`, argv `["sh", "-c", "uname -a"]`. This is a new observed
startup candidate, not proof of the former CA533x child's identity, legitimate
authorization, or a reason to weaken the classifier. No cleanup-side failure
reference appears. Root read packet and sidecar originals (`d58f6d`,`ccff17`).

Worker cleanup records SETTLED, TERM sent, KILL not sent, exit-15 and group empty
before reap. Root's exact parent/leader/candidate PID postcheck `4d05dc` returned
exit1 with no rows for47056,47065,47070. Streams are empty EOF, with no stream
errors. Two resource samples (including the rejected complete sample) have
maximum gap0.10876774997450411s, peak group
RSS52,936,704bytes, no RSS overshoot. Bounded independent data/hash review is
requested next. No further native run or source-classifier edit is authorized.

## Independent retained-data audit — failure confirmed, not code self-approval

`osp_evidence_review` completed read-only data assertions `8ee1cf` and `676224`,
both exit0. This checks actual retained bytes/control relationships, not the
maker grading its own supervisor implementation or approving another execution.
No launcher/supervisor/R/CLR module was imported or executed, no test or native/
model/browser/network run occurred, and no OS process probe was performed.
The stdlib data reader refused writes, process/network creation and native-library
loading. Only this receipt was subsequently appended.

Reads used explicit paths, regular single-link files, O_NOFOLLOW, bounded reads
and stable before/open/after identities. The sidecar cap was64KiB; S01 traversal
stopped at4MiB/256 entries. Actual S01 is **9 entries:5 files and4 directories,
8,318 aggregate file bytes**. Files are configuration3,980B, result3,039B, work
sidecar1,299B and two empty streams. Directories are home, cache, tmp and its one
empty R temporary directory. All files are0600 without symlink, hardlink alias
or pending artifact. No cleanup sidecar, barrier, inspector, image or scientific
observation exists; collector observation/cleanup remain explicitly MISSING.

| Retained item | Bytes | Verified SHA256 |
|---|---:|---|
| authorization.json |1465| `9c35c7325930e153043430c663cf7cb7f573454656aa2ca86a899a3ae8e42440` |
| once.json |1261| `607748a6b389b33201ec971e8630b462a811d98fd095e093e6ab2b28f4e7b66e` |
| completion.json |1048| `25fc86cfaec4d22573ace45c1d6879c6b3fe7f555ea6bea7c3690192aa64212f` |
| packet admission.json |719| `8d74823a1971cafc8a5a7564e10c164142b5bba0514ec21eb519921ef4714e64` |
| packet result.json |4592| `386fd59ed5d69ebcad9a0ba4c093789f9786aad12be47fb77170b6b8fd592797` |
| S01/result.json |3039| `4ef3e4e636c57b91d3b1131f12f3eeebf774197998c7ab3b5689157de11f5b05` |
| S01/process-failure-work.json |1299| `d5ee0f102a7efa8d71244acbfab9fc30a510f0a02aff0ae3edee155e6a598781` |

Authorization and once are canonically equal despite formatting. Their exact
schema, seven current input/self hashes, false model admission,17 cases/16 Runs,
protocol and unchanged limits match. Packet admission matches packet identity/
case order/limits. Completion names and hashes the exact packet; its embedded
S01 is canonically equal to the separate case result. Completion remains
FAILED/PACKET_REJECTED with CONFIRMED source preservation and no evidence errors;
packet remains FAILED/CASE_FAILED; S01 is FAILED/UNEXPECTED_DESCENDANT plus
PROCESS_FAILED; S02–S17 NOT_RUN. Terminal exit1 and PID absence are root's
separate `e16aee`/`4d05dc`, not new process checks by this auditor.

The work reference exactly matches sidecar filename/bytes/hash/code/state.
It is UNADMITTED, phase work, prior_primary null, COMPLETE sample and retention,
2 enumerated/2 sampled/2 retained/0 omitted, without retention errors.
sampling_stage and failed_pid are null because capture completed and policy
classification—not a sampling substage—failed. Metadata/whole rows fit4KiB/60KiB
sub-budgets. No environment or arbitrary exception text is present.

`samples.count=2` is two resource observations, **not two admitted identities**.
`process_observations` contains exactly one accepted R identity. The rejected
complete group still contributes resources: sidecar RSS values sum to52,936,704B
and CPU values to1,912,560ns, matching the receipt. R's PID/PPID/PGID/start/image/
path/executable/argv match the accepted identity; candidate PPID/PGID equal its
leader PID. This preserves monitoring without granting executable permission.

Cleanup is recorded SETTLED, empty before reap, TERM true, KILL false, exit-15,
error null, elapsed0.018620458024088293s. Both streams and files are empty EOF
without overflow or stream errors. These are recorded relationships, not a
complete exec trace or new independent OS-liveness proof.

All six current input pins, launcher, copied45/additive27 test sources, offline
wrapper and frozen supervisor29-test source still match reviewed hashes. Static
AST inspection—not import—confirms both source gates false. The original CA533x
launcher, tests, authorization, once, completion and failed packet remain exact.
Neither failed packet is relabelled; CA533x's former rejected child is still
unidentified. No model admission, native attestation, numerical result or
follow-up run is approved by this retained-data check.

## Retained-source origin and finite correction proposal — no implementation

A separate read-only `startup_origin` source reviewer completed and stopped;
there is no follow-on parser/infrastructure work. Its non-executing standard-
library byte inspection bounded utils.rdx to16KiB, utils.rdb to2MiB and each
decompression to256KiB. The index and both named serialized objects parsed to
exact EOF (`a0aa19`, `58d53b`, final structural checks `52b6d1`/`52a51e`). A
preliminary parser assertion incorrectly required every reserved bytecode-
reference slot to be populated; correcting that reader overconstraint changed
no retained bytes and executed no serialized code. This is static source/data
evidence, not an R runtime call stack or native-source attestation.

Within the retained prefix
`/private/tmp/livemore-osp-native.mUlZwx/r-unpacked/R-fw.pkg/Payload/R.framework/Versions/4.6/Resources/`:

1. `library/base/R/Rprofile:1` states it always runs at startup. Lines51–59
   select defaults including utils when R_DEFAULT_PACKAGES is empty; lines74–84
   require those packages. `launch_spec` at supervisor208–219 sets no override.
2. `library/utils/R/utils:19–26` loads the retained lazy-load database. Its named
   `.onLoad` expression assigns `osVersion` from `.osVersion()` into its namespace.
3. `.osVersion`'s non-Windows branch checks `nzchar(Sys.which("uname"))`, then
   calls exactly `system("uname -a", intern = TRUE)`. Its Darwin branch reads
   `/System/Library/CoreServices/SystemVersion.plist` and performs string/vector
   operations, with no further external command in that branch. The separate
   `system("uname -r", intern = TRUE)` call belongs to SunOS, not Darwin.

The base profile SHA256 is
`3d05c14703f911330f14c5e658333542d14039cd0951de7f210d9a5b32cb5d00`;
utils.rdx `f19bd86aa747731ae0967a1296d2a3a4c45ac752a66980284b8ebcfafa77e643`;
utils.rdb `4ed12041e6b2501953aadcab5a97735f22a1575d5be9146ff21240f4e1ac3ca7`.
These match inventory lines1230,1384–1386 and were independently rehashed by the
data-review agent (`5301dd`, sizes7,239/8,121/1,033,876 bytes respectively).

The index locates `.onLoad` at RDB offset114985/entry length2862: decoded13,111B,
SHA256 `7be997aff7196700470b289f6a80c94267cdc532e63d4a7596ec45ea588a0e22`,
assignment-expression offset7366. `.osVersion` is at117847/3218: decoded16,836B,
SHA256 `fccf5e27b455833d32f54520ebb95658f20be7530f32b872766c534ec16b7597`;
decoded-expression offsets1966 for Sys.which,2159 for system("uname -a") and4380
for the Darwin branch. These offsets are serialized evidence locations, not
invented source line numbers.

This source path accounts for the observed qUfcQ6 command before collector entry.
It does not prove the dynamic call stack, all short-lived helpers, or CA533x's
former child. The collector installs its dotnet-only system hook at86–105,
after R initialization. The unchanged supervisor correctly rejects this sample
at660 because STARTUP_BEGIN has not been acknowledged; even changing that boolean
would still fail665–666 because neither /bin/bash nor uname matches the permitted
/bin/sh/dotnet command. Therefore the failure is a bootstrap-contract mismatch,
not evidence that the current classifier should have accepted the row.

The smallest justified next design is a **separate finite R-initialization phase**
from spawn through an explicit, write-once collector-entry handoff acknowledged
by the supervisor. It ends irreversibly before the existing CLR STARTUP_BEGIN/
END phase; that phase, its exact dotnet delegation and its four-barrier ordering
must not be broadened or reused to cover pre-collector work. Retain default
packages, original worker/cleanup/packet/resource limits, ownership rules and
failure-evidence retention. Admit no unspecified command or helper in either
phase. Any protocol/handoff addition requires its own reviewed written plan and
new exact source/protocol bindings; nothing here authorizes implementation.

This is **not yet an implementation-ready allowance**. The current manifest pins
/bin/sh (`094fc5e188feb7cc18906900b1b5c417e03aaed03a9fc132e925f38640d9bd59`),
but not /bin/bash or /usr/bin/uname. The retained R expression proves neither
shell dispatch/alias identity nor the eventual uname image or full transient
helper topology, including Sys.which's transitive behavior. A finite follow-up
design must close those exact command/image/parent-group identity questions
before approving any new phase policy. Do not simply append argv strings,
broaden startup_active, disable utils (dependencies may load it later under the
dotnet-only hook), suppress metadata output, or infer authorization from this
single observation. Both failed packets remain unchanged and no new run is
approved.
