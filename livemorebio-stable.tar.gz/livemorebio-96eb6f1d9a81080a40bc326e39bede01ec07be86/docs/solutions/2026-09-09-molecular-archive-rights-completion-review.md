# Molecular archives: completed input verification and original-notice review

2026-09-09. Source/data-only follow-up to the admitted canonical lock and final
archive batch. **Acquisition is complete; all 224 retained separate notice texts
have been reviewed. Emitted-bundle rights and build acceptance are not complete.**
No package import, install, build, native code, service, browser or new GET ran in
this review. The earlier failed attempts remain unchanged and failed.

## Actual final batch, independently checked

Root ran the separately authorized final helper once, exec25920, exit0. Root:
`/private/tmp/livemore-molecular-archives-final.dKZYOa`, mode0700.

| Evidence | Value |
|---|---|
| Raw status | ACQUIRED_INVENTORIED_REQUIRES_RIGHTS_REVIEW |
| Completed unique identities | 427, matching all428 canonical lock placements |
| Sources | 416 verified originals reused; exactly11 GETs, indexes416–426, all HTTP200 |
| Recorded elapsed | 2.927662375033833 seconds |
| Compressed archive bytes | 23,622,804 |
| Expanded tar-stream bytes, including framing | 124,231,680 |
| Inventory member rows | 18,135 |
| Evidence count before terminal receipt | 4,837,866 bytes |
| Actual retained run directory after terminal receipt | 2,138 regular files;28,571,348 bytes including archives;4,948,544 non-archive bytes |
| Input preservation | Original input hash map independently matches; no source/lock rewrite |

The independent stdlib-only check rehashed every archive with both SHA256 and
the lock's SHA512 SRI, every427 per-item receipt against the terminal ledger,
every retained manifest/notice blob against its size/hash, and the full original
input map. It compared exact name/version/resolved URL/SRI/placement identities,
not only counts. All totals and source counts match. The only admitted canonical
alias is webpack-cli5.1.4's two regular-file rows for lib/index.js, both200 bytes,
mode0644 and SHA256 ccc06af73f9f39663fa763b4a5bd618d68e56da004d1e302ae0d5cc15bdae1ed.
Both original names remain in the inventory. This does not certify all possible
tar formats or revise the earlier failures.

The checks used a30-second alarm and refused network, process and ctypes calls;
they did not extract executable inputs into an installed tree. Subsequent source
header/README reads used tarfile as a data reader, never eval/import/execution.

| File under final private root | SHA256 |
|---|---|
| acquire-once.py | 1cf92d31712618259f1ad2bb205a3d5859e1165f8c7c32b4437e5ab618570b90 |
| AUTHORIZE.json | be6642e1584207362ce134e1507d9d3ccfa0c851245653d6c175b4563afc846e |
| run/started.json | 8c3307cd1c14830a44e4f626803d597092848fe3b2a21c506e7838af86d58fcc |
| run/result.json | 697994d8ded8fccd197df3f7432e4d55c789ab68fb8ed67818509ca73b978f38 |
| rights-index.json | 320d17cc559495ac40c287cc1955221616031a2f75a79f12b90b8ed4e16a9846 |
| mit-review-groups.json | 2c3ca9e7c0cb9bc1b64e9b6a0ead9c565b3c934590f62eff92001668c46b466c |

The two derived review indexes are0600. They preserve paths into the unchanged
original run, not replacements for original archive or notice bytes.

## Complete notice coverage and method

The index contains224 distinct original separate notice texts totaling414,640
bytes, with every source package/version/member association. Source_research
personally read indexes0–35 in full and the complete1,727-line/88,141-byte Sass
composite at197. These include full Apache2.0, ISC, BSD2/BSD3, Python2.0 and its
historical constituent agreements, CC-BY4.0, 0BSD, and bundled attribution texts.
Sass composite SHA256 is
c128e51e7cf068fc98f558e3d21c1fe35bf50bb2a373fd22a6dff8c14494e2ff.
It contains Dart Sass MIT, Dart/component BSD3, MIT and full Apache2.0 sections;
the actual varying copyright holders and original placeholder text are retained.

For187 other originals (36–196,198–223), each complete variable prefix was read
and paired with one of31 complete, personally read, byte-identical suffixes.
Splitting at the first literal Permission does not normalize whitespace, CRLF,
punctuation or Unicode. Prefix+suffix exactly reconstructs each full original;
all hashes/sizes/group membership were checked. The comment-only Molstar bundle
notice is an explicit whole-body exception, not a full MIT text. Output that was
truncated was reread before coverage was recorded, including the complete CC-BY
text. No review was inferred from an SPDX label or an unreviewed text variant.

Release_redteam independently repeated that187-entry partition against205,934
original bytes, read all187 variable headers/source mappings and31 complete
representative texts, with zero reconstruction mismatches. Its complete record
is `2026-09-09-molecular-mit-notice-independent-review.md`, SHA256
014ffdcda6d1e125ad2b909e0514fc50827dcdb927326af7e8b31ae9b8e4b6da.
This is independent grading of that slice, not of this entire maker report.

Preserve exact original copyright/permission/disclaimer text and association,
not one generic MIT label. BSD source/binary retention and non-endorsement where
present, Apache license/NOTICE/changed-file requirements and patent/trademark
limits, CC-BY attribution/source/modification/license conditions, and the full
Python historical agreements remain distinct. These are observed source terms,
not a legal opinion or a conclusion that every dependency will be redistributed.
The caniuse dataset's CC-BY4.0 does not become coordinate-data CC0.

## Five packages without a separately named notice

Every listed original archive was read as data; no replacement was downloaded.
Source paths below are members of final run/NNN/archive.tgz.

| Index / exact package | Original evidence and bounded result |
|---|---|
|105 cookie-signature1.0.7|Readme.md contains full MIT, LearnBoost2012. Full read; README SHA1621ed10d0b2f865eb8608e0474a356cf7a9737a384b6593b61b30a9f6e50366. Preserve that section when its code is distributed.|
|142 esrecurse4.3.0|esrecurse.js header and README contain full BSD2, Yusuke Suzuki2014 and contributor attribution. Source SHAaa99847033c240a621fe987f0e06b754f388f22abd11a05bdf9cdd00794b7350; README SHAa7007c78c9d9da690ef6cdb0e7a3427d05832edb00abd1f5a9882700d73be4ad. Both full notice bodies read.|
|172 glob-to-regexp0.4.1|README contains full BSD2, Nick Fitzgerald2013. Full read; SHA18a53184b61f21e9f39035c106e5e6bf885353ce4177d18e15fcb18980cb1ee2.|
|386 tr46 0.0.3|Five-member original has only MIT package declaration; no full terms/copyright notice found. index.js SHA8194f9425ce9ab06ea9aebcd64a85ec064d95d61bb349f8f1c98762ad256638e loads its260,049-byte mappingTable.json. Exact Unicode-table source version/rights are not established by this archive. **Redistribution evidence gap**, not MIT-only clearance.|
|396 undici-types5.26.5|README describes dual-published types; package declares MIT but supplies no full license. fetch.d.ts SHA54cb85a47d760da1c13c00add10d26b5118280d44d58e6908d8e89abbd9d7725 points to specific undici-fetch/node-fetch commits as MIT; these pointers are not the missing original terms. **Redistribution evidence gap**; no .d.ts output is planned.|

Additional attribution checks: both estraverse versions' original JS headers
name Yusuke Suzuki2012–2013 and Ariya Hidayat2012 and contain full BSD2; these
resolve the standalone notice's unnamed "above copyright" referent. Acorn8.18.0
LICENSE refers to AUTHORS, but its ten-member archive has no AUTHORS file.
Preserve the exact various-contributors notice; do not invent a contributor list.
If it enters redistributed output, resolve any required omitted association first.

## Native, embedded and telemetry boundaries

- fsevents2.3.3 README and fsevents.js were read. JS immediately requires
  fsevents.node on Darwin. Its own full MIT notice is not native-load approval.
  There is no installation lifecycle hook in its manifest; prepublishOnly builds
  upstream, not during this proposed install. Proposed installation omits the
  sole optional fsevents record; the lock and original archive remain unchanged.
- h264-mp4-encoder1.0.12 README was fully read, SHA
  91c1951f57c87c78dc22199f457947e12e13b78cb5da60feee6c1bc63eb294b7.
  It explicitly names public-domain minih264 plus **MPL1.1 libmp4v2**, forked for
  Emscripten, and SINGLE_FILE base64 WASM inside JS. Its Trevor Sundberg MIT
  notice covers its own text, not a proven license closure for embedded code.
  No full embedded MPL/source closure is admitted. Codec bytes must not be
  executed or emitted; a filename-only .wasm scan is insufficient.
- @scarf/scarf1.4.0 is the only selected package declaring an install hook:
  postinstall node ./report.js. Original README and manifest confirm analytics;
  targeted report.js source confirms HTTPS and child_process usage. That code was
  not run or fully security-audited. Scripts remain disabled; SCARF_ANALYTICS=false
  and DO_NOT_TRACK=1 are secondary defense, not substitutes for --ignore-scripts.
  Scarf must be absent from emitted browser closure.
- Molstar prebuilt viewer's abbreviated React/safe-buffer notice does not prove
  full terms or embedded versions. The separately pinned React18.3.1 and current
  safe-buffer notice cannot attest old viewer contents. The old full viewer stays
  excluded. Swagger bundles similarly have abbreviated/third-party notices,
  including DOMPurify dual Apache/MPL references; they are private unused inputs,
  not permitted viewer substitutes or an admitted emitted dependency graph.

## Disposition and next gate

The427 original input identities and complete separate-notice review can be
handed to root. Three missing-file cases are resolved by original inline terms;
tr46 and undici-types plus embedded/full-viewer associations remain explicit
distribution gaps. A private scripts-disabled materialization may be proposed
without calling these gaps closed. Root must decide that bounded input use;
there is no install authorization in this report.

Before any vendor output: obtain the exact emitted module/file graph, exclude
native/codec/telemetry/full-viewer/server assets, map each emitted file back to
its admitted original and complete applicable notices, and reject unexplained
embedded code or required missing terms. Then perform the separately approved
two-build byte comparison, package/wheel and actual browser gates. Do not package
all427 inputs or the whole node_modules tree. No molecular or clinical efficacy,
participant-specific inference, or six-experiment completion follows from this.

Lesson: archive layout admission, original-notice coverage and emitted rights
closure are three different gates. Keep inline license terms and nested codec
licenses visible; neither a top-level SPDX label nor a .wasm filename search
substitutes for them.

## Proposed stock-offline materialization handoff

The exact unexecuted plan is
`/private/tmp/livemore-molecular-offline-install.a8XyYr/PLAN.md`.
It uses an empty cache seeded by14 fixed stock cache-add batches from these427
originals, then one stock ci; all commands offline, scripts/bin links disabled,
strict peers, no outer retry, no metadata acquisition. Omit only optional
fsevents while preserving the complete lock; require426 installed identities at
427 placements and complete original-byte postcheck. A cache miss stops. During
installation only pinned Node/npm and npm's installed implementation execute;
acquired package JS is not an entrypoint. The two later120-second webpack/Sass
builds remain separately gated. Root has not authorized this install.

Read installed primary implementation seams and hashes, not current web advice:

| File relative to /opt/homebrew/lib/node_modules/npm | SHA256 |
|---|---|
| bin/npm-cli.js | 8e5f6f3429f8cdbe693cdc29904e9d5a7b127a494bd15c804bd54c7403bfcbe7 |
| package.json (npm11.12.1) | 48a06e6aeede3499e391710db82fe948afa7e74ecbf3e819b66121f3cd54666b |
| npmrc | 72b4b27ffdcc6eade20c176600b98f8d91601990540ed19d24a2d2d6d5b95f8e |
| lib/commands/cache.js | 3eebc9e9a74db052c5c381f6bc178506e1fd0491ea560a25b0c4e26d2549efd5 |
| lib/commands/ci.js | 8a1b0b70e1e47a74d4736a06fc32c45b480f7dd19054d146ed40648d75b20df6 |
| node_modules/pacote/lib/fetcher.js | 97dbf9a402ad3329c517aa35928da4c115a2e3a77b51f513729a8e253ee1144a |
| node_modules/pacote/lib/file.js | e56e384ee34175b52b960bbb52e0f4127978cca1df3d5e7b1edaff5a24d1fba4 |
| node_modules/@npmcli/arborist/lib/arborist/rebuild.js | 3bbe7f326942762557e567b47025acd49e2aac21d16293bc3f24852f0efdf3dd |
| node_modules/npm-registry-fetch/lib/index.js | 9757d6aa767884be9e566ebfeaca76c94d80bbea854b41a42ce8648feb2fca42 |
| node_modules/make-fetch-happen/lib/cache/index.js | b9a47e604b9d6ec9211e5129636ba7366c408c074ea1d4b8c859cf221c347071 |

Node26.0.0 canonical executable is
`/opt/homebrew/Cellar/node/26.0.0/bin/node`, SHA256
08dad0581f00a0cabf4d49ec92ca1f25fdfd01c2c18fa8e92b35f04d4c24c164.
These named source seams establish the proposed stock behavior; they are not
a complete dependency/runtime attestation. The private launch preparation must
also freeze the full installed npm source inventory and preserve all input pins.
