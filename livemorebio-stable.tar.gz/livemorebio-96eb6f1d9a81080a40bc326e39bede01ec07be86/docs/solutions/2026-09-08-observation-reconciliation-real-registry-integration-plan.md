# Observation/reconciliation: real encrypted-registry ASGI integration

2026-09-08. **Plan only, pending root approval before test code or execution.**
Read the full approved publication plan/addendum, both current route bodies,
actual prepared observation/checked-access/confirmation owners, and the previous
real binding/preview fixtures and receipts. Local prior art supplies the bounded
test design; no gbrain, CE or sequential-thinking tool is callable here, and none
is claimed to have run. All six scientific programs and R01–R51 remain required.
This packet establishes transaction wiring, not physiological or device validity.

## Exact boundary and proposed write set

Create only `livemorebio/tests/test_checked_observation_registry_integration.py`
after approval. No runtime, existing fixture, registry schema, client or browser
change. Observed source pins:

- server.py: `878e585552d12de5fc4cc8e5381bec5a2874565ae3bdd5b496418e7e46875625`.
- subjects.py: `b5306edc2045fd98e943f9fefc124872996563c3c955fece4ec7aebb718d6441`.

Use the actual authenticated ASGI routes `/api/twins/{id}/select-observations`
and `/api/twins/reconcile-selection` without TestClient lifespan or service
startup. Reuse the existing availability `client` fixture and import only seed,
raw-row, audit/reservation and fixed-key decrypt helpers from the checked
binding/preview/startup and committed-registry tests. Do not import registry-only
autouse fixtures, which intentionally prohibit the ASGI internal socketpair.

Keep actual server `_subject_registry` with a fresh private path and public
authored test key, actual SubjectRegistry bootstrap/encryption/audit/prepare/
commit/witness and checked capture/confirmation. Real ModelSourceAuthority uses
the actual assignment fence/commit guard and a real no-background ExecutionManager
with an empty adapter registry and a no-I/O execution store. No owners/workers are
created. Prior inspection state has authored observation/action sentinels and
either an inert old model or `tw=None`; an old model's state method is forbidden.

Retain real model_availability, ObservationState, unavailable_state, strict JSON
response construction and `_snapshot_twin`. Replace only its file-backed bus
sinks with recording functions. The only allowed numerical candidate is a fixed
inert `server.AegleTwin('healthy')` factory in true-absence case9, with a dictionary
of authored parameters and one counted state call. Actual AegleTwin/MetabolicProfile
constructors, admitted_human/build_twin, extraction and model APIs remain trapped.
Every REAL_HUMAN case must count zero candidate constructors and zero fallback.

## Exact fifteen cases

| Case | Actual wiring and required outcome |
|---|---|
| 1 | Different selected SYNTHETIC/READY to admitted REAL_HUMAN: 200, actual two-row demotion/selection, target n+1, fresh modeless memory/fence and empty observations/actions; explicit own null-parameter snapshot. |
| 2 | Same target already REAL_HUMAN/observations_only: 200, only that row increments once; actual admission evidence/bindings remain unchanged, no old or new numerical call. |
| 3 | Different-target selection final commit persists then loses ACK: real full witness confirms; 200, two UPDATEs/one pointer write/one mutation attempt/one read-only witness, no reseal or write retry. |
| 4 | Same actual persisted selection/ACK loss, then alter only its terminal audit ciphertext: real witness refuses, SELECTION_COMMIT_UNCONFIRMED/503; authority+manager DENY and exact old inspection holders, no snapshot. Retain durable selection and damaged evidence, never call it rollback. |
| 5 | Actual selected commit succeeds, actual connection close completes then raises: SELECTION_COMMITTED_CLEANUP_UNCONFIRMED/503 with new modeless state/fence already installed and own snapshot published. This is storage-close ACK evidence, not execution-owner cleanup. |
| 6 | After the actual preparation pair, during unlocked modeless projection, independently reseal the target's authored payload at the same version: final actual commit conflicts409, preserves external bytes and old memory/fence; no selection publication. |
| 7 | Mutation final commit raises before real commit, real rollback succeeds: REGISTRY_STORAGE_UNAVAILABLE/503, original rows/pointer/holders/fence and failed mutation access audit; no publication or witness retry. |
| 8 | DENY with a selected unbound REAL_HUMAN at stored MAX: actual checked recovery200, no clinical/pointer/index writes or increment; two reconcile_selection audit pairs, fresh modeless state/holders, zero constructor. |
| 9 | DENY with true absent pointer and no ACTIVE row, plus unrelated admitted record: actual checked recovery200, exactly one healthy inert factory/state call outside locks; subjectNone/READY reference_preview, original records/indexes unchanged. |
| 10 | DENY with pointer deleted but authored ACTIVE row still present and immutable store identity retained:503 before candidate/projection, no false absence/fallback; actual failed checked capture audit and unchanged corrupted topology. |
| 11 | DENY REAL_HUMAN capture succeeds, then only pointer timestamp changes during unlocked projection: final actual checked confirmation conflicts409; external change retained, DENY/old holders preserved, no publication. |
| 12 | DENY REAL_HUMAN: actual final checked-confirmation terminal audit commit persists then loses ACK.503, no recovery publication or memory assignment despite durable audit; clinical bytes unchanged. No read-mutation retry. |
| 13 | DENY REAL_HUMAN: actual final checked-confirmation close completes then raises.503, DENY/old holders retained, successful audit bytes retained; no execution cleanup/reopen. |
| 14 | Pause R1 after actual checked capture. R2 really reconciles unchanged REAL_HUMAN storage; add authored new inspection sentinels. A third real selection of that same record gets commit-before-delegation plus rollback-ACK failure, then real close rolls back, producing DENY while retaining R2 state and unchanged clinical rows. Resume R1:409 before final audit access, R2 state/sentinels remain. Preserve the third operation's pending audit reservation, separate UUID ledgers and only R2's snapshot. |
| 15 | DENY REAL_HUMAN: capture terminal audit commit raises before delegation, real rollback and failed-access completion succeed.503 before candidate/final confirmation, original clinical bytes and old DENY inspection state; actual failed capture pair retained. |

Cases1–7 are selection; cases8–15 are checked recovery. This is not the 62-case
registry or 78-case route matrix repeated with real storage. Closed-owner,
malformed-input, per-field cross-products, weak finalizers and arbitrary output
validation retain their existing dedicated coverage rather than expanding this
packet. Case14 has exactly three ASGI requests; every other case has one.

## Narrow observation and fault seams

Normal cases preserve original `_connect`. A delegating wrapper around the actual
modeless projection may perform one authored checkpoint only after calling the
unchanged original projection, without modifying its arguments/result. At that
checkpoint require the completed capture/preparation audit, all authority,
creation, manager and initialization locks unowned, and independent private
BEGIN IMMEDIATE/rollback success. This proves released writer ownership, not an
observed close syscall. No product hook or generic transaction framework is added.

Reuse the fixed observation mutation fault pattern from the new registry tests:
delegate original guarded connections and real SQLite; arm on actual prescribed
record UPDATEs and exact parameterized pointer INSERT, not arbitrary connection
or commit ordinals. Record actual terminal action/UUID and mutation/witness counts.
Lost ACK delegates real commit first; known rollback raises before it; close ACK
delegates real close first. Case4 independently retains the old/changed terminal
tuples without decrypting the intentionally damaged row or replacing the witness.

For checked-audit faults, distinguish actual capture from confirmation using the
completed first access pair and the unlocked projection checkpoint. Final-phase
faults cannot fire during capture. Match current UUID/reconcile_selection/SUCCESS
before changing only the terminal commit or close acknowledgment. Capture fault15
must prove no second access or projection occurred. Original phase/encryption
functions remain actual, not mocked successful results.

Case14 uses bounded in-process Event/ThreadPoolExecutor coordination only if
needed to pause the first ASGI request; no process or network worker. Each wait
and join has a short explicit bound and releases the paused request in finally.
R2 and the third selection use the real routes and registry. The third operation's
delegating fault is confined to its request and restored before resuming R1.
Separate audit ledgers by each response UUID: R1 only its initial completed pair,
R2 two successful pairs, third selection inspect pair plus pending mutation BEGIN.
No manually fabricated registry outcome or state replacement substitutes for ABA.

## Common evidence, preservation and execution gate

Assert original method identities before/after (unwrap only bound methods): actual
getter/routes/shared snapshot; prepare_observation_selection/_prepare_transition,
commit, checked capture/validation/confirmation, selection read/phase owners,
snapshot/raw evidence/witness, `_open`/`_seal`, audit begin/finish/check_authority,
source observation/commit_guard/install_generation and manager fence callbacks.
Only named delegated `_connect` or projection checkpoints are exempt during their
fault/interference scope; no prepared object or returned outcome is substituted.

Compare full raw records/registry_state/identifier/device tables, retaining every
non-active state tuple. Decrypt only authored rows using original AAD; exact
selection changes exclude evidence, creation/index/binding fields. No public
getter after a request may contaminate audit counts. Preserve original audit
prefix and same response UUID/no-store on every path. Selection has inspect then
select_observations pairs with target ID; reconciliation has two fixed
reconcile_selection pairs with null target. Verify distinct event identities,
fixed schema/keys, completed or pending reservations, and deliberately damaged
outcomes. Audit counts are wiring evidence, not replacement for per-decrypt tests.

Recording bus sinks require durable final evidence and coherent installed
authority+manager/state before publication, outside all four locks. Known rollback
and conflict retain exact old holders/fence; unknown retains holders behind DENY.
Recovery performs no clinical mutation, invalidation, execution close or reopen.
Modeless snapshots remain null/no physiological axis, with fresh empty holders.

After root reads/approves, run only the new15 once under the existing private45s
ASGI wrapper (pinned fresh Python, no bytecode/cache/auto-plugins; bind/listen/
connect/connect_ex/DNS/urllib/child/native/model refusal; internal socketpair
allowed). Preserve initial failures; report any fixture/implementation defect
before adjustment. No browser, service, native model or operational-store access.

Proposed later compact preservation selection is **138 cases**: new15 + actual
binding13 + actual preview15 + the existing exact95 observation/reconciliation
route packet (new78 file and its five mapped legacy node IDs listed in the ASGI
test review). Use the same45s wrapper, not the registry-only socket-construction
plugin. The independently passed678 registry foundation remains separate; do not
silently rerun its four process cases. Root independently reads/repeats the frozen
new tests; the test author does not grade product completeness. No test authoring
or run is authorized merely by this proposal.

## Root pre-code approval

Root read the complete142-line proposal and actual route/registry boundaries.
Approved exactly the new15-case test module and its stated138-case preservation
selection under the existing45-second private ASGI wrapper. No runtime or old
fixture changes. Read the initial15 result before any correction or later138 run;
retain all failures and report the concrete cause before changing tests.

The same-target ABA case must prove that its third real request leaves clinical
rows unchanged after unknown rollback acknowledgment and actual close, rather
than manually installing DENY or restoring memory. Preserve its pending audit
reservation; R1 must reject before final access, not pass by a looser record-value
comparison. Only true-absence case9 may use the fixed healthy inert factory;
every REAL_HUMAN case must forbid all numerical constructors. Root independent
registry678 and external route287 gates are now clear; neither replaces this
integration check or the still-pending real-browser/scientific acceptance.
