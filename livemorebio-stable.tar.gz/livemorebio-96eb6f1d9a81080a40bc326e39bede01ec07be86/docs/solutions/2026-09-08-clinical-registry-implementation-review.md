# Clinical registry correction — implementation review packet

Date: 2026-09-08. Status: maker verification in progress; independent review and
root-owned API/browser acceptance are not yet complete. Atlas acceptance remains
FAILED under its separate retained report.

## Approved contract and ownership

Implements the registry/context lane of
[the clinical parent](2026-09-08-clinical-context-dispatch-correction-proposal.md)
and [the availability amendment](2026-09-08-clinical-context-availability-amendment.md).
Runtime source freeze was released by root after the retained Atlas functional
baseline and owned review-process cleanup. Runtime ownership is limited to
`subjects.py`, `clinical_parameters.py`, new `model_contexts.py` and
`registry_audit.py`, with dedicated authored-software tests. No person, physical
device, model source, equation, native solver or operational store was used.

## Implemented boundary

- Descriptive REAL_HUMAN admission retains observation units, source times, QC,
  fasting and declaration-conflict checks, but does not compile twelve engine
  parameters from a condition string. New records carry `model_binding:null`;
  no real-human binding is admitted by this increment.
- Legacy reference reconstruction is bound to its saved source/release/stratum
  and seven explicit values plus five unchanged defaults. Each context access
  returns a detached profile/provenance. The context cannot be borrowed by a
  different subject or relabeled as REAL_HUMAN.
- Old REAL_HUMAN retries authenticate their exact saved descriptive projection
  and historical provenance hash without inference or re-encryption. New encrypted
  creation identities bind request/key semantics, including insertion races.
  The old unauthenticated plaintext key-index limitation is not retroactively fixed.
- Observation-only selection prepares its return payload before commit, rechecks
  full authenticated content and revision, demotes the previous ACTIVE record in
  the same transaction, and reports uncertain commit separately. Root owns the
  surrounding in-memory generation fence and all-consumer projections.
- New real-human cohorts freeze complete member snapshots, exact versions and
  evidence digests under the writing transaction. Admission requires source,
  custody and research consent, not being the single ACTIVE subject or having a
  numerical model. Old unsnapshotted cohorts remain readable, not silently rebuilt.
- Shared encrypted audit reserves immutable begin/result capacity before access.
  Completion survives connection/process restart through persisted reservation
  identity. The completion event identifies its actual writer; the original begin
  retains the origin. The finite 10,000-event capacity is not enterprise retention.

## Clarification accepted before the corresponding implementation

The 16 MiB bound applies before cohort encryption/insertion and any successful
mutation-result audit. A required durable encrypted access begin and fixed failed
result are allowed for rejected oversized composition; otherwise the original
wording would require unaudited member decryption to determine exact payload size.
Root and independent reviewer explicitly accepted this resolution. The regression
requires no cohort, no SUCCESS event and no dangling reservation after normal
oversize failure. No clinical values appear in audit metadata.

## Red-first evidence

- Original context/audit run: 51 failed, 2 passed, 36 missing-module setup errors.
- Context/audit implementation initially reached 89 passes with two direct-helper
  ordering failures, subsequently corrected.
- Descriptive/selection increment reached 132 passes with 15 not-yet-implemented
  selection failures; those were then implemented against the retained tests.
- Strengthened cohort exact-connection, competing member edit and oversized-access
  audit tests reproduced three failures before composition implementation.
- Three DPP/NHANES/PXR historical provenance retry cases reproduced a hash change
  before preserving the exact old reference provenance contract.
- Public-source relabeling and restarted-audit writer identity each reproduced a
  failure before correction. Borrowed-context tests reproduced two failures before
  binding the immutable context to its subject/source class.
- Combined owned contracts and existing descriptive public-reference lifecycle
  reached 215 passing tests before the final borrowed-context additions. Latest
  exact verification counts/hashes will be appended after review stabilization.

All records and sources in these tests are authored technical fixtures in fresh
isolated SQLite stores. Legacy population fingerprints test frozen numerical input
preservation; they are not human-equivalence measurements. Source-data ingestion,
native trajectories, HTTP/UI review and clinical qualification are separate gates.

## Preserved unresolved requirements

The six requested programs (exogenous insulin and the five selected botanical
programs), all R01–R51 requirements, physical-v3 onboarding, individual model
qualification and broader whole-body coverage remain open as recorded elsewhere.
This packet does not repair the failed OSP benchmark or activate a model for a
person because their clinical description appears familiar.

## Lessons

Separating descriptive intake from computation is a storage-identity change as
well as a model guard. Provenance text can be part of an old idempotency hash;
preserve that exact contract without reviving the old disease-text inference.
Also, an outer write transaction alone is not evidence of atomic composition:
tests must identify the exact connection that read each member and inserted the
cohort. Durable access auditing and bounded payload rejection must coexist rather
than making either requirement an implicit exception.

## Candidate verification checkpoint

Final maker run at this checkpoint: **224 passed in 3.93 seconds** using
`tools/run_review_tests.py`, the managed interpreter, no cache provider, and the
four dedicated contract test modules plus `test_reference_cohort_lifecycle.py`.
The isolated stores were under
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-3v95d7s5`.
`git diff --check` was clean. Ruff/Black were unavailable in the managed runtime;
no dependencies were installed to format this packet.

| Candidate runtime file | SHA-256 |
|---|---|
| `aegle/subjects.py` | `5339dbe566d7efcd0354d0a08e6ce875e78f064d0f306887f165a82c5592a264` |
| `aegle/clinical_parameters.py` | `9222b4eefc600007b254eb9818161947b830b50ba51ac68ffaffe3de85944615` |
| `aegle/model_contexts.py` | `9a5400c09f4c2281c7356285a1e495ca7fee228ab4362dda7d0e75288feb8226` |
| `aegle/registry_audit.py` | `739e0d0a2878907632259b90e325c8fd9b542f62dab664cde0c8ded1a58511cc` |

The already-audited wrong-key reopening test reproduced an extra undecryptable
BEGIN before the correction. Existing encrypted audit/store identity is now
authenticated before appending any new event; the regression checks exact record,
audit and reservation bytes. Selection additionally accepts a validated optional
server-owned UUID `request_id`, so the API response and shared audit can refer to
the same operation. Direct internal use defaults to a new UUID.

**OPEN security review:** a legacy registry with no previous audit event has no
existing audit-key proof. The first durable BEGIN must precede clinical payload
decryption, so a failed first migration cannot be advertised as a successfully
verified audit identity. Root explicitly prohibited an automatic lockout or new
key-metadata recovery design in this increment. That bootstrap/recovery decision
is retained for independent review; no legacy ciphertext was rewritten or
quarantined to conceal it. The helper's `verify_existing` returns false when no
audit proof exists, rather than asserting key verification.

Independent source review and root-owned API/browser integration are still
pending at this checkpoint; passing this maker suite is not release acceptance.

## Independent-review correction: malformed active selection

The reviewer identified an inner-join ambiguity in `audited_active_twin`: both a
genuinely absent selection and a stored pointer with a missing/non-TWIN target
returned `None`. Startup may use only the former as permission for a reference
preview. Root approved the bounded correction under the existing malformed-store
fail-closed requirement; it does not expand the legacy audit bootstrap design.

The new technical regression module first produced **21 failures and 2 passes**.
The corrected reader checks pointer existence separately, then validates the
indexed target and its authenticated record identity, schema, version, source
class and ACTIVE lifecycle in the same audited transaction. Invalid storage
raises the fixed operational `RuntimeError` rather than `None`, a user-input
error or a scientific `MODEL_*` availability result. A missing pointer still
returns `None`; a coherent legacy selected record is returned unchanged. Tests
also cover reopened storage, boolean versions and a non-object encrypted payload.
Records and pointer bytes are preserved, and ordinary failed reads complete their
existing reserved failure audit.

The six-module maker packet passed **247 tests in 4.07 seconds**, with isolated
stores under
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-4b_t04un`.
`git diff --check` remained clean. No browser, HTTP, physical device or native
model execution was performed. Other candidate runtime files retain their hashes
above; this correction freezes:

| Corrected file | SHA-256 |
|---|---|
| `aegle/subjects.py` | `ed910394d16c5db2d49e647b8ecef1217364138e8ad202d08d13d03391008600` |
| `tests/test_active_selection_storage_integrity.py` | `5362ab3a85d237c091f77a9aa4a21cf4c102a620ad4ce94e77f7b851b3fad6d0` |

Lesson: absence and inconsistency are different storage states. Never use an
inner join's missing row as proof that no subject was selected. The zero-audit
legacy migration issue above remains OPEN, and this bounded correction is not
whole-registry or product release acceptance.

## Additive final-selection reconciliation seam

Root approved the exact registry seam under
[the reconciliation contract](2026-09-08-selection-reconciliation-contract.md)
before implementation. It is distinct from the still-unimplemented
[legacy bootstrap proposal](2026-09-08-legacy-registry-audit-bootstrap-proposal.md).

`confirm_active_selection(*, expected_record, request_id) -> None` freezes canonical
expected content before access, then reads through the same factored checked
active-record reader inside the audited writer transaction. A same-version edit,
different pointer, version change or absent/present flip conflicts. Genuine
absence can be confirmed; corrupt storage retains the operational error. No
record, pointer, version, ciphertext or idempotency index is changed. The caller
owns authority locks and precomputed memory installation, and keeps DENY_ALL
after any raised audit/commit exception.

The existing subject audit allowlist gains `reconcile_selection`, with no schema
or AAD change. `audited_active_twin` and internal `_audited` accept an optional
server-owned request UUID. Two sequential reads can share the route request ID:
their BEGIN/RESULT event IDs and reservations remain distinct, and the original
pair is unchanged after the final confirmation.

The dedicated module first reproduced **25 failing tests** for missing APIs. Its
implementation reached **272 combined passes**. Three additional focused probes
then verified frozen expected bytes and both committed/uncommitted final-ACK
failures: either exception prevents a confirmation return, including the case
where an audit SUCCESS is durable but its acknowledgment was lost. The final seven
module packet passed **275 tests in 4.36 seconds** using isolated stores under
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-szjmlwe9`.
`git diff --check` remained clean. No bootstrap, HTTP, browser or native action ran.

| Reconciliation candidate | SHA-256 |
|---|---|
| `aegle/subjects.py` | `0bc9b49fb0e2833fc0308ca2bce2a1c37704a3ccae59a0c18760288a3035783f` |
| `aegle/registry_audit.py` | `30e7a0a336752461981d44ad61715efefbe9da33d610058711281a32bbcdfe4f` |
| `tests/test_selection_reconciliation_registry.py` | `88aa5913c03440be1bb67638e6f1b264df09dca310c88626ad5878cfdddeaaaf` |

Lesson: a final authoritative comparison is an audited access, not another
selection. Sharing a request identity across preflight and final read must not
collapse their immutable events or make a lost commit acknowledgment look like a
confirmed return. Independent review and root-owned route acceptance remain pending.
