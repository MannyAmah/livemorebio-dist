# Checked startup publication — independent fixture design review

2026-09-08, `source_research`. **No material fixture-design blocker found in
the bounded 32 new cases plus one migrated legacy case.** This is static review,
not a passing runtime result. No test, service, browser, native model, operational
registry or network request was run by this reviewer. Root owns implementation
and will request an independent grade of its frozen runtime separately.

## Exact reviewed evidence

Read the full startup checked-selection proposal and appended refinements, the
complete current test file, its imported authored `client` fixture, and the
migrated legacy restoration-failure test. The independently cleared registry
checked-read packet remains a separate dependency, not a permissive fake's proof
of SQL/audit correctness.

| File | SHA256 at review |
| --- | --- |
| `test_checked_startup_publication.py` | `ac47cf5ef932f0b6b30c5ec57aa05d895b9a4115a80ebe08ba89f146f501ba41` |
| `test_subject_lifecycle.py` | `d5f5091216207fb5767c56fc87d9954f0d0433ea11a03b8858891e012111a3be` |
| startup checked-selection proposal | `efec7eb84ba2977b5a51d84ee0613e834b5e6d18334d74d8c584e779cb58c33a` |

Paths are respectively under `livemorebio/tests/` and
`docs/solutions/2026-09-08-startup-checked-selection-interface-proposal.md`.
Root's retained 33-RED result is maker evidence; it was not rerun here.

## What the fixtures actually establish

- The checked read requires the internal checked flag, inspect action and UUID.
  Final confirmation requires the very same capture object, exact record and
  source ownership before publication; unchecked `active_twin` is a trap.
- The final three-lock guard inspects the complete new availability, generation,
  summary, candidate-or-null, fresh empty observation state and new empty actions
  before any guard lock is released. The publication trap requires exactly one
  precomputed snapshot, its own current availability/generation, and candidate
  parameters or modeless null. It does not accept a late implicit snapshot.
- The six untyped failure stages include fallible registry acquisition. Late
  success and late failure cannot overwrite an intervening operator, including
  an initialized-state change at the same generation. Typed context failure is
  modeless only for a confirmed present record; failed absent-preview construction
  must install DENY_ALL, never impersonate an unbound person.
- Constructors and projection are outside authority/creation/manager locks.
  Invalidation, publication, returned unused-candidate retirement and displaced
  old model/action retirement are outside the initialization mutex as well.
  The old-payload test deliberately leaves no test-held strong owner, avoiding
  a false finalizer-order pass.
- Direct restore compatibility, ordinary ensure idempotence, already-denied
  entry, malformed own projection, event-handler single publication, and
  post-confirmation cleanup failure have explicit cases. The migrated
  `test_server_fails_closed_when_active_subject_restoration_breaks` at line384
  preserves denial of numerical access while leaving the static app available;
  an authored private error must not escape.

The permissive manager is appropriate for these server sequencing tests, but is
not sufficient for real closed-manager behavior. The separately approved
`test_closed_manager_source_publication.py` must exercise retained closure before
entry and during unlocked preparation, DENY_ALL assignment, no reopening or owner
detachment, and explicit cleanup retry. That packet is still being expanded.
These fixtures do not certify cross-process registry/memory atomicity or all
numerical/physical consumer routes.

## Exact legacy activation seam migrations proposed, not implemented

Both stale tests are in `livemorebio/tests/test_model_source_authority.py`, reviewed
SHA `e406c884ab26767f0dcd77dd444e84b9e73336e0f9b57813efcaf8bf57c7e86e`.
The current route never calls their `get_twin`/`activate_twin` doubles. A missing
`prepare_activation` currently diverts them to generic storage503 before the
intended assertion. Do not preserve that accidental failure or delete the tests.

1. Line115, `test_server_activation_build_failure_does_not_activate_registry`:
   preserve a candidate-construction failure before any registry commit. Supply
   a detached prepared prospective SYNTHETIC record and matching `active_before`
   through `prepare_activation`, asserting target, expected version and UUID.
   Make `build_twin` count its call and raise the original authored ValueError;
   make `commit_prepared_transition` a trap. Assert one preparation/build, zero
   commit/publication, unchanged memory and generation, and no private exception
   in the response. Under the approved current error contract this untyped
   preparation failure is fixed `REGISTRY_STORAGE_UNAVAILABLE`503, not the old
   422. This classification change must be explicit; do not swap in an unrelated
   typed input error merely to keep 422 green.
2. Line133, `test_activation_cannot_build_a_version_other_than_the_requested_snapshot`:
   preserve requested version2 versus stored version1. Have the prepared seam
   assert the exact request and raise typed `TWIN_VERSION_CONFLICT` before any
   construction or commit; both downstream methods remain traps. Keep the exact
   409/code assertions and add unchanged source/memory checks. This is a stale
   version conflict, not an HTTP shape-validation substitute.

Use isolated coherent authority/state and authored candidate values, with the
existing native/network refusal wrapper. Do not introduce a real model or weaken
the constructor/commit ordering assertions. Current typed-context activation
tests in `test_clinical_source_races.py` already use the prepared seam; retirement
tests already define both prepared methods. The direct real-registry lifecycle
integration is not a stale double and remains an integration obligation. The
shell's `FakePlatform.activate_twin` models a retained SDK method, not the removed
server-to-registry seam, and must not be mechanically migrated.

Lesson: when an orchestration seam moves, require proof that the intended fake
collaborator was reached. A generic error response cannot preserve a test of
pre-commit scientific admission, source version identity or construction order.

## Subsequent additive fixture reread

While this report was being written, root added
`test_ready_startup_constructor_cannot_return_no_model`. The complete new file
was re-read at SHA
`0a10defce24e8e0992e708403381fefa84f9e98bf9ca25024d74e48b98c6ea68`.
The added authored `None` constructor result must deny source access before
confirmation/publication, rather than allow READY with no model. This is a sound
additional boundary; the named original review remains intact. The current
design has33 new cases plus the migrated legacy case. No execution result for
this addition is claimed by this reviewer.
