# Atlas remaining dependency and visual correction proposal

Proposed only: no implementation or new browser invocation authorized here.
The previous c9 source attempt remains FAILED (three failed cases, 25 NOT_RUN).
The clinical availability UI packet is separate and does not repair these gates.

## Retained facts and boundaries

Read in full: the Atlas attempt-2 results and root grading. Its exact receipt,
42 ordinary screenshots, source/manifest/receipt hashes, failed measurements and
unrun obligations remain the baseline. New acceptance must pin its actual new
runtime source and process identities; it cannot reuse the old c9 receipt.

The intact 489-element, nine-group BP3D reference assembly, original coordinates,
triangles, degeneracies, source transforms and provenance stay unchanged. This
packet must not delete overlapping source elements, recenter organs, infer body
deformation from scalar values, supply a decorative biological motion, or call
reference geometry individualized anatomy. A+B overview and Biology inspector
remain different surfaces.

## A. Same-origin linked Biology dependencies

Confirmed source cause: `biology.html` requests Google Fonts and Molstar 4.4.0
CSS at document load. Its lazy `loadMolstar` requests the 4.4.0 script, and the
current `viewer.loadPdb` call can also make viewer-controlled external requests.
Only the two stylesheet requests were reached in the retained attempt; the
other branches are source-inspection findings, not tested failures.

Proposed bounded work, after approval:

1. Audit the complete dependency/request graph for ordinary, saved-run and fixed
   execution Biology entry points plus an explicitly opened molecular target.
   Keep the same-origin firewall; do not solve this by allowing arbitrary CDN or
   structure-server traffic from the clinical page.
2. Keep existing typography/design, but package the selected font files locally
   only after exact versions, primary licensing and byte hashes are reviewed.
   Until a file is actually admitted, use the existing declared fallback stack
   without a network link, explicitly documenting any visual difference.
3. Inspect primary Molstar 4.4.0 package/API/license and its transitive assets
   before deciding a pinned local bundle. Preserve the molecular inspector;
   merely removing its stylesheet or hiding the feature does not meet acceptance.
   Retain notices, bundle/source hashes, package inclusion and import-safety tests.
4. Resolve whether the existing server structure adapter can return admitted
   public structure bytes through a fixed, bounded, provenance-carrying local
   endpoint. A new endpoint is root-owned and requires its own exact request,
   license, cache, host/redirect, byte/time bound and audit contract. Do not route
   clinical notes or arbitrary URLs through it. The browser viewer may consume
   only that approved local source, not `loadPdb`'s implicit remote resolution.
5. Red tests reject external CSS/script/structure requests across the linked
   page lifecycle, retain target/source identifiers, and cover unavailable source,
   retry, close-during-load and no stale target publication.

Suggested ownership: UI owner for document/lazy viewer/controller changes and
tests; root for any protected structure route/package configuration; source
reviewer independently verifies licenses and the exact pinned dependencies.

## B. Label usability (confirmed presentation defect)

`atlas_reference_scene.js::draw` currently places every group label directly at
its projected bounding-box center. There is no screen-space collision resolution.
The retained labels screenshot shows overlapping organ names. The problem is
presentation, not proof of incorrect anatomical coordinates.

Propose a pure screen-space label layout: fixed group order, deterministic bounded
left/right callout columns, measured label rectangles, minimum vertical spacing,
viewport clamping and leader lines from each original projected anchor. Hide
labels whose anchor is outside the camera or whose layer is hidden; do not
silently rename or misassign organs. Keep an accessible complete label list in
the inspector if a narrow view cannot fit every callout. This moves labels only,
never any anatomical vertex or object transform.

Red tests: coincident anchors, nine labels, camera behind/outside clipping,
390/768/1440 widths, enlarged text, section/isolation/layer transitions, and
deterministic order. Ordinary desktop/mobile screenshots must show readable names
and unambiguous leader endpoints. Labels-toggle true is not the acceptance gate.

## C. Selected-pancreas mosaic (cause still unproven)

Source inspection shows all original elements are present with independent
double-sided opaque internal materials. Only the selected element is teal.
Coplanar parent/child geometry could explain alternating teal/beige triangles,
but neither the source code nor the screenshot alone establishes this.

First conduct a bounded, read-only analysis of the retained pancreas partition:
record its exact element membership, source hierarchy and geometric overlap
counts without modifying the GLB. Inspect the selected ID and isolated-vs-full
view at the same camera in a separately authorized ordinary browser check.

If overlap is confirmed, propose selection presentation independently: an
outline or other source-preserving screen-space highlight plus the exact selected
ID, not deletion/welding/offsetting of source meshes. Do not approve polygon
offset or other depth changes until the test demonstrates the mechanism and
shows they do not alter selection/raycast semantics. Preserve all original 489
elements and resource counts in whichever presentation solution is reviewed.

## D. Capture evidence and unfinished acceptance

- Preserve browser-zoom `before` and `after` width/DPR plus the attempted shortcut
  count before assertions. Use real browser zoom, not CSS scaling or a fake
  viewport override. Diagnose the actual shortcut/zoom state in a blank owned
  browser before another product acceptance invocation. The old raw values were
  not saved and cannot be reconstructed from its screenshot.
- Pair ordinary viewport and full-page screenshots at the same scroll position,
  retaining the header bounding rectangle and computed positioning. The header
  seen midway through a full-page image may be capture behavior; do not change
  product positioning based on that image alone.
- The diagnostic collector must settle on either request-finished or
  request-failed, preserving both as distinct terminal outcomes. Pinned Playwright
  `response.finished()` alone remains unresolved after a failed request. This
  known collector issue does not prove the cause of Chrome's ERR_ABORTED.
- Investigate `atlas_reference_requests.js`'s unconditional `reader.cancel()`
  after successful EOF using controlled transport tests before proposing any
  product reader change. No production change or causal conclusion is approved
  by this proposal. Exact bytes, hashes, same promise, two-request concurrency,
  deadline and cancellation semantics must remain intact.
- Keep the existing warm/performance thresholds. If their transport evidence
  remains unresolved, preserve FAILED/UNRESOLVED rather than silently redefining
  request completion as visual readiness. Functional controls may proceed under
  the already reviewed independent-gate design, but auth/source/cleanup remain
  hard stops.
- Exercise all 14 NOT_RUN fault cases after the linked-dependency blocker is
  corrected, including valid/unconfirmed installation acknowledgment at 390px.
  The acknowledgment currently has no specific anywhere-wrap rule; visible
  overflow must be measured, not presumed fixed. Complete the missing warm trials,
  frame budgets, real hidden/visible behavior, five dispose/reopen cycles and
  mobile touch/reduced-motion checks under their original reviewed bounds.

## Required decision sequence

Approve the bounded dependency and pure label-layout contracts first. Source
review precedes vendor acquisition/code; red tests precede each change. Separately
review the overlap diagnosis before a selection-rendering change. Independently
review the harness evidence corrections, then authorize one new fixed-source
ordinary/instrumented browser run with no concurrent numerical workload.

This is not a proposal to cut incomplete R21–R27/R46 requirements. All retained
functional, performance, visual, source-context and resource-cleanup obligations
remain open until their own evidence is obtained and independently graded.
