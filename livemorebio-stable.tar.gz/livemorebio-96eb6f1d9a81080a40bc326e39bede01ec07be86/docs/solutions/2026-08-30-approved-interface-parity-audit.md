# Approved A+B Interface Parity Audit

Date: 2026-08-30
Branch: `codex/interface-twin-onboarding`
Reference: `~/.gstack/projects/MannyAmah-livemorebio/designs/multiscale-human-workspace-20260830/approved-merged.png`
Audited URL: `http://127.0.0.1:8850/`

## Outcome

The current workspace preserves the right multiscale, intervention, evidence, and comparison
architecture, but it is not yet faithful to the approved A+B product or the inherited subject
lifecycle. The central body renderer and root Patch workflow both fail in the audited browser. Twin
and cohort creation are absent.

## Parity findings

| Area | Approved design | Current rendered product | Decision |
|---|---|---|---|
| Global tabs | Atlas, Twin, Patch, Cohorts, Evidence, Lab, API | Cohorts and first-class Evidence missing; Twin points to legacy console | add governed Twin and Cohorts surfaces |
| Whole body | visible anatomical human with organ/vascular activity | empty fallback ellipse after WebGL context failure | add permanent SVG body fallback driven by returned data |
| Scale navigation | whole body through gene/protein | present and changes focused evidence | preserve |
| Biological time | visible and active | present; currently advances label only | bind body activity and trajectory cursor |
| Intervention | visible mechanism and response | controls present, lifecycle available | retain and make all state transitions visible |
| LIFE Patch | connected physical/virtual contract | root virtual action returns subject namespace validation error | bind to active pseudonymous twin and test end-to-end |
| Twin creation | create/onboard/connect person and data | absent from redesigned workspace | restore as first-class lifecycle |
| Cohorts | create/freeze/run groups | absent from redesigned workspace | restore as first-class lifecycle |
| Token experience | no manual secret ceremony | authorization modal requires token copy/paste | use loopback same-origin HttpOnly bootstrap |
| Biology distinction | whole-body command view separate from deep biology explorer | routes are separate, but root body can disappear | preserve separation and fix root renderer |
| Responsive behavior | understandable product at narrower widths | desktop enforces `min-width: 1180px` and horizontal overflow | add responsive workspace modes |

## Verified current interactions

- Selecting Heart changes the focused node to `organ.heart` and displays the returned heart-rate
  state.
- Evidence tabs and biological-time controls are reachable.
- The anatomy loader attempts the registered 3D renderer, then logs repeated WebGL creation errors.
- The virtual Patch request fails with `subject ID must use the opaque pseudonym-<id> namespace` and
  does not switch to observed evidence.
- Existing Biology, Patch, Cendos, Adapters, legacy console, OpenAPI, SDK, and terminal surfaces are
  still routed and must remain intact.

## Release blockers

1. Missing twin lifecycle and real-human data admission.
2. Missing cohort lifecycle.
3. Empty whole-body fallback.
4. Broken root virtual Patch binding.
5. Manual token prompt on a launched loopback product.
6. No recorded browser proof that all primary controls and product pages work.

The implementation and release test gates are recorded in
`docs/solutions/2026-08-30-executable-multiscale-workspace-plan.md`.
