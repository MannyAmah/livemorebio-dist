# Actual banner and legacy recovery inspection — September 9

Scope: the existing legacy preview recovery surface, not the A+B Atlas, molecular
inspector, six experiments, whole-product release or human validation. Root ran
the separately reviewed14-image schedule once, then personally inspected every
original image. Original prior12-image evidence remains untouched.

Source `f755a2aab6883e40cd0e384b24d2b1e7ddca20719e5d1ba5873d3322fbbb83aa`.
Actual evidence directory:
`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-legacy-preview-y11aq6ff`.
Session30428 exit0;9.193098833027761 seconds. Browser receiptSHA256
`efd86fe6f7762faf858ae2982394840544c7de83bc1f65062d8872dc1525bcf7`;
supervisionSHA256`79782efc33986558117605d41a56de9e72be99df6cd3059728eada9d6c7f2992`.

Seven cases D0–D4/M1/M2 passed; desktop1440×1000 and mobile390×844. All three
isolated services agreed on the source identity. Two actual model-unavailable
state reads and six session bootstrap responses were admitted; cookies in both
browser contexts were HttpOnly and loopback-only. Four authored intercepted POST
deliveries and one follow-up GET each tested uncertainty/recovery; there were
zero actual mutations and no biological engine execution. Six console-error
events remain recorded from intentional failing-response cases, not claimed zero.

## Visual findings

Root viewed desktop-modeless/error/pending/later-winner/cleanup/note-before/unknown,
twins-recovery/life-inspection/history and mobile-error/note-before/unknown/refreshed.
The informational and validation-error banners are visibly in normal page flow,
below the top navigation, wrapping inside each viewport. The same banner node
clears and reappears with the correct status/alert and live-region attributes.
Keyboard validation retains focus and adds no POST (desktop0→0/mobile3→3).
The banner and visible clipped navigation links pass independent hit testing.

The scoped nav-occlusion defect is accepted as corrected. This is not a clean bill
of health for the entire view:

- Existing source-insensitive “reacting live”/“ENGINE”/“one beat, live” labels
  remain misleading in unavailable/uncertain states and require correction.
- A compound-entry validation error can remain visible during a later preview's
  pending/unknown state, especially in mobile-unknown. This is stale feedback,
  not a renewed compound submission. Keep the original screenshot and fix in
  the existing action-status ownership, not by adding another message layer.
- Dense recovery text/unadorned links and mobile navigation's internal horizontal
  scrolling remain design/accessibility work. This check does not prove access
  to offscreen links, all-keyboard operation or200% zoom.
- Values/lines in authored response cases are explicitly fixture data; none is
  an insulin or botanical experiment, observed biological response or video.

All four owned children6985/6986/6987/6997 were reaped; all14 observed descendants
were absent; ports8910–8912 had no listeners. Five browser/resource closes settled.
No primary, cleanup or evidence failure. Existing installed services/stores,
historical experiments and cohorts were not altered. The temporary source freeze
is released only for already approved next implementation increments.

Lesson: banner position and message ownership are separate requirements. Passing
layout checks does not mean an old action's message describes the next action.
