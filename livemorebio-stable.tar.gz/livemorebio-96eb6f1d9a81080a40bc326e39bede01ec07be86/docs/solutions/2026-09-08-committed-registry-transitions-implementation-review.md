# Committed registry transitions — maker packet

2026-09-08. **Frozen for independent review; not server or product acceptance.**
This is the registry-only increment of the approved
[interface](2026-09-08-committed-source-transition-interface.md) and
[parent plan](2026-09-08-committed-source-transition-plan.md). Tests use authored
local technical records, not real participants or hardware. No browser, service,
native numerical worker, source acquisition or operational store was used.

## Frozen ownership and identities

| File | SHA-256 |
|---|---|
| `livemorebio/aegle/subjects.py` | `f1bf94c2fc593ba82fc934d7b2bfb99d8cfa391681bf2edd5991020940a684dc` |
| `livemorebio/aegle/registry_audit.py` | `245eb3568587170379ae18d137ef4b79cbcaa00de86bee3726ef8235afa42546` |
| `livemorebio/tests/test_committed_registry_transitions.py` | `8eaff7fa92a0658d57da44b4e6ca221d636221041db3fa9ba0f03e821c95a472` |
| Approved interface | `e271a1b9c112699ec70475c57ffc9ff886e03ead95b90fd83b4950ea1f58bf98` |
| Parent plan | `c39b4fcba5dacd8bc8ddf1a9dcd49dbe43c7669967654901286838c36262d009` |

The source delta is the new prepared-transition type/helpers and thin direct
activation/binding/preview-clear wrappers in `subjects.py`; the audit delta is
only returning the already-created terminal event ID from `finish`. Existing
audit payloads, AAD and reservation accounting are retained. Bootstrap,
reference-cohort, server, UI, scientific source and previous evidence files were
not edited by this increment.

## Exact helper contract

`PreparedRegistryTransition` is frozen with private canonical bytes and immutable
row tuples. Detached properties are `record`, `target_before`, `active_before`,
`active_after` and `selected`; identity fields are `kind`, `store_id`,
`authority_token`, `request_id`, `target_id` and `timestamp`. Plaintext is omitted
from its repr. It is an internal value, not a client authorization token.

The accepted public helpers are `prepare_activation`, `prepare_patch_binding`,
`prepare_preview_clear` and `commit_prepared_transition`. The latter returns
`COMMITTED` or `COMMITTED_CLEANUP_UNCONFIRMED`; unconfirmed durable outcome raises
fixed `SELECTION_COMMIT_UNCONFIRMED`. Direct wrappers retain their return shapes
and raise `SELECTION_COMMITTED_CLEANUP_UNCONFIRMED` for the second confirmed
outcome, without calling a connection problem a native-worker problem.

Preparation durably audits access and binds the exact pointer, at most two
authenticated records, every relevant SQL column and one relevant physical
device index. Missing/incoherent/multiple ACTIVE topology fails closed. Profile
admission and timestamp/response preparation occur after the read connection has
closed. REAL_HUMAN numerical activation still requires its model binding; this
increment does not invent one.

Commit independently reconstructs the permitted transformation, durably commits
its own original BEGIN, then checks its authority and complete snapshot under
BEGIN IMMEDIATE before decryption or writes. It changes only the specified
target/demotion rows and pointer/device index. Versions are exact positive safe
integers with room for the next increment. Replay/virtual rebinding retains an
existing physical-device reservation; no new device release policy is added.

Lost commit acknowledgment is resolved only by one consistent read-only check
of the exact expected record/index/topology bytes, original BEGIN and terminal
audit bytes, and reservation absence. No re-encryption, clinical decryption,
operation retry or new receipt occurs during confirmation. A confirmed rollback
retains its bounded failed-access completion. Uncertain rollback stays unknown;
final close failures do not turn a confirmed commit into presumed rollback.

## Red/green evidence

- Initial fixture setup incorrectly blocked the read-only build-info git capture:
  74 setup errors. Moving that existing import before the process-refusal fixture
  exposed the intended **74 failing contract tests**, then 74 passed after code.
- Expanded tests found original BEGIN sequence tampering between the durable
  BEGIN and mutation transaction: **1 failed / 88 passed**, then **89 passed**
  after retaining the original bytes before the first commit and checking before
  protected decryption.
- A new synthetic close-interruption probe first interrupted pytest; the test
  was corrected to turn escaped interruption into an explicit failure. Both
  KeyboardInterrupt/SystemExit cases then reproduced red, and passed after
  committed-outcome-preserving cleanup handling. Full owned packet:
  **96 passed in 3.43 s**.
- The broader global-tripwire run first produced **320 passed / 50 setup errors**:
  this packet had replaced `socket.socket` with a function, while the bootstrap
  shape fixture also patched its methods. The owned fixture now uses a socket
  subclass that refuses construction, retaining compatible method attributes.
  No other test or product assertion was changed. Rerun: **370 passed in 20.20 s**.
- Four unchanged legacy activation/pairing cases passed in **1.19 s**, with one
  existing Starlette deprecation warning.

Coverage includes three operation families, detached preparation and original
creation-field preservation, same-version content/reseal/metadata drift,
strict versions and malformed bodies, malformed ACTIVE topology, forged prepared
changes, actual bootstrap adoption between phases, durable BEGIN-before-decrypt,
each witness component, physical index conflict/retention, actual concurrent
writer connections, audit/seal/partial-write/rollback/read failures, and direct
wrapper outcomes. The no-pointer clear case also confirms its audit-only commit.

## Exact reproduction

From `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```sh
/Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B tools/run_review_tests.py -q -p no:cacheprovider -p livemorebio.tests.test_committed_registry_transitions livemorebio/tests/test_committed_registry_transitions.py livemorebio/tests/test_subject_registry_audit_contract.py livemorebio/tests/test_registry_bootstrap_contract.py livemorebio/tests/test_registry_bootstrap_shape.py livemorebio/tests/test_clinical_descriptive_registry.py livemorebio/tests/test_real_cohort_contract.py livemorebio/tests/test_selection_reconciliation_registry.py --tb=short
```

The 370-case run used private root `livemore-research-review-rbmwo069` under the
system temporary directory. The plugin applies socket construction/DNS/helper,
urllib, subprocess and model/profile/compilation refusals to the entire selected
packet, not just the new module. The isolated runner supplies fresh mutable paths
and credentials. No raw clinical values or secrets are emitted by the report.

```sh
/Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B tools/run_review_tests.py -q -p no:cacheprovider -p livemorebio.tests.test_committed_registry_transitions livemorebio/tests/test_subject_lifecycle.py::test_virtual_patch_binding_retains_admitted_protocol_version livemorebio/tests/test_subject_lifecycle.py::test_only_authoritative_twin_remains_active livemorebio/tests/test_subject_lifecycle.py::test_physical_patch_pairing_requires_active_consented_human_and_attestation livemorebio/tests/test_subject_lifecycle.py::test_active_twin_survives_registry_restart_and_physical_device_cannot_double_pair --tb=short
```

That four-case run used `livemore-research-review-xcslaycv`. All test processes
finished. No full lifecycle suite/native model or actual device ran.

## Remaining acceptance and lesson

Root-owned server generation/publication, selected-binding observation/action
identity, post-lock cleanup and startup are not accepted by these tests. The
existing observation-selection/reconciliation weaker witness and ACTIVE-loop
contracts remain explicit reviewed follow-up work; this packet does not silently
claim to fix them. Physical-v3 onboarding and firmware qualification remain
separate. The OSP source-admission packet and failed insulin benchmark were left
unchanged and uninvoked. No numerical or whole-human-equivalence claim follows.

The durable lesson is to freeze a BEGIN witness before the first commit, rather
than recapturing possibly changed bytes later, and to classify the durable
mutation outcome independently from resource-cleanup success. Independent maker
review is the next gate; browser/product and R01–R51 acceptance remain open.
