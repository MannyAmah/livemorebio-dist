# Actual registry-to-preview wiring: test-author handoff

2026-09-08. **Maker evidence only; root independent review/repeat is required.**
The complete15-case proposal and producer P2 amendment were read, and root's
approval recorded before test code. Created only the new integration test and
its approved plan/report; no runtime or existing test was edited. R01–R51, the
six scientific programs, native model admission and real browser/client acceptance
remain unchanged. This is a software transaction integration packet, not biology.

## Retained invocations and frozen identities

First authorized run: **15 setup errors, 3 existing warnings in1.84s**, exit1,
private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-m7ad95pt`.
Test SHA `6f62f1d5b97114ddd2c610015779ec57b96f2335e4d8a6ff802f67f1b1702014`.
This was a fixture defect, not product RED: the generic protected-method check
used __func__ on `_raw_transition_evidence`, which is a staticmethod. Every case
stopped during fixture setup before its API/factory/clear. Private registry
initialization did occur. Root read the479-line test, confirmed this exact cause,
and approved only descriptor-aware identity comparison before the same15 repeat.

The correction stores the actual attribute and compares
`getattr(bound, "__func__", bound) is frozen_function`. Expected functions remain
identical; no protected implementation is substituted. No other assertion changed.

Second authorized run: **15 passed, 3 existing warnings in2.17s**, exit0,
private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-1k884c4p`.
Both runs: unexpected network/child/model attempts **0**; optional exact Git
metadata request refused **1**. No live service, external HTTP, browser, native
model or operational store was used. TestClient's internal socketpair and authored
private SQLite are expressly allowed. The45-second alarm was cancelled on return.
No further test run followed this handoff.

| File | SHA256 |
|---|---|
| new test,480 lines | 24e6b6ceeace9caf42b52c0676e557e4d2847eafef7068ee2419353478dc191f |
| server.py, intended and unchanged during both runs | 3fd852c3737406b7173cab1ed915b66bbd28d3cc3def2c8a75a3c84e8e775017 |
| subjects.py | 0a8eaee99b653a1b1823a1434c2e5ff1a2d468dc9659677cb426b33f6389b465 |
| registry_audit.py | b21f01fdf1c79604c5565fee0f7d94d3b0bd11967b199bc97ec8a193de045e4e |
| execution.py | 2caafc14925604e3ad3e194c3c668a7cf41eb83eb5fea3afa619bf897c277aac |
| approved plan plus first-failure record | f2cc042d169604106efed3c10a31fc4dc3cbebf147375283795c16fd3e7fbdb4 |

## Actual boundaries exercised

Actual server getter, guarded connection, SubjectRegistry initialization,
encryption, prepared-clear/phase-audit/commit and exact read-only witness remain
in use. Protected identities are asserted before/after each case, including
source authority, commit guard, fence and shared snapshot. The actual manager
has no background worker, native adapter or execution owner, and a no-I/O store.
Only inert candidate/human/local-note factories and the two recording bus sinks
replace numerical or file-backed consumers.

The15 cases are base READY, LIFE modeless and note selected success; actual true
absence with unrelated records; two one-sided capture cases and a subject-ID-only
four-field mismatch; same-version encrypted payload and pointer-timestamp
interference; confirmed rollback; exact lost ACK; damaged terminal; unconfirmed
rollback; confirmed close-ACK failure; and unauthorized note. They do not repeat
the full70 boundary cases, old15 or weak-retirement matrix.

The actual preview clear demotes only the selected row to DATA_ADMITTED, increments
version once and deletes the active pointer. It preserves remaining payload,
unrelated raw records, indexes and bindings. Exact lost-ACK confirmation checks
the demoted ciphertext, absent pointer, empty ACTIVE topology and original terminal
evidence, with one UPDATE/DELETE/final attempt and one read-only witness. It does
not retry the mutation. True absence leaves all original clinical/index rows exact.

Both successful audit pairs use inspect/subject-access/null opaque target and the
response UUID. Raw prefixes, fixed field sets and reservations are checked. Capture
conflicts retain only the preparation pair; storage conflict/confirmed rollback
retains ACCESS_FAILED. A deliberately damaged terminal is preserved and not
decrypted after corruption. Unknown rollback retains the pending mutation BEGIN
even after actual close rolls back. These cases keep old inspection holders behind
authority/manager DENY_ALL with no candidate snapshot. Known rollback preserves
old generation; confirmed close-ACK failure retains/publishes the new preview.

Factories verify completed preparation audit and unlocked source/creation/manager/
initialization locks. Independent BEGIN IMMEDIATE/rollback proves the preparation
writer lock has been released, **not an observed close syscall**. Normal and
interference paths keep the actual `_connect`. Only five fault cases delegate the
original guarded connection through a bounded acknowledgment wrapper, armed by
the exact demotion SQL rather than an audit commit ordinal. Terminal and pointer
operations precede the injected final commit fault. The wrapper directly records
delegated closes and read-only witness phase; no process-death/fsync/OS-owner claim
follows. Dedicated helper tests retain per-decrypt audit ordering/close obligations.

Recording sinks require completed durable audit and installed new preview/fence
outside all locks. Returned200 state matches its explicit snapshot and candidate
parameters; note metadata is detached. New observation/action containers do not
replace the retained old holders in failure cases. No extra public getter was used
to inflate audit counts, and deliberately damaged evidence was never repaired.

The original runtime REDs and first setup failure remain retained. This result
does not establish actual note extraction, synthetic-human physiology, physical
packet admission, clinical model readiness or UI/terminal operation. Analogous
activation/binding preparation-error adapters are a separate root-owned packet.

## Exact bounded repeat

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery` after source freeze
coordination. This is the exact second invocation, not a broader selection:

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os, sys, signal, socket, subprocess, urllib.request, multiprocessing.process
from tools.run_review_stack import prepare_review_environment
review_root, env = prepare_review_environment(inherited={k: os.environ[k] for k in
    ('PATH', 'HOME', 'TMPDIR', 'LANG', 'LC_ALL') if k in os.environ})
os.environ.clear(); os.environ.update(env)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
blocked, metadata = [], []
def deny(*args, **kwargs):
    blocked.append('unexpected')
    raise AssertionError('Review forbids network and child/native work')
def process(command, *args, **kwargs):
    if command == ['git', '-C', '/Users/emman/Livemore/.worktrees/full-scope-recovery', 'rev-parse', '--show-toplevel']:
        metadata.append('refused')
        raise OSError('Authored unavailable Git metadata')
    return deny()
def audit(event, args):
    if event in {'os.fork', 'os.forkpty', 'os.posix_spawn', 'os.exec', 'subprocess.Popen', 'socket.connect', 'socket.getaddrinfo'}:
        deny()
sys.addaudithook(audit)
multiprocessing.process.BaseProcess.start = deny
for name in ('bind', 'listen', 'connect', 'connect_ex'):
    setattr(socket.socket, name, deny)
socket.getaddrinfo = socket.create_connection = deny
urllib.request.urlopen = urllib.request.OpenerDirector.open = deny
subprocess.Popen = process
import pytest
class InertReview:
    @pytest.fixture(autouse=True)
    def no_models(self, monkeypatch):
        from livemorebio.tests.clinical_registry_fixtures import forbid_compilation
        from livemorebio.aegle.runtime import AegleTwin
        from livemorebio.engines.metabolic.glucose_insulin import MetabolicProfile
        forbid_compilation(monkeypatch)
        monkeypatch.setattr(AegleTwin, '__init__', deny)
        monkeypatch.setattr(MetabolicProfile, '__init__', deny)
signal.alarm(45)
print('PRIVATE_REVIEW_ROOT', review_root, flush=True)
rc = pytest.main(['-q', '-p', 'no:cacheprovider', '--tb=line',
    'livemorebio/tests/test_checked_preview_registry_integration.py'], plugins=[InertReview()])
print('REVIEW_IO_COUNTS', len(blocked), len(metadata), flush=True)
signal.alarm(0)
raise SystemExit(rc)
PY
```

Compounded lesson: exact identity checks must respect Python descriptors without
weakening identity. A staticmethod is already the function; only bound methods
need unwrapping. Preserve setup errors separately from route-level failures.

## Independent root acceptance of the test packet

Root read the entire approved plan, original479-line test, descriptor correction
and complete153-line maker report. The protected function identities, actual
encrypted rows/audit reservations, demotion/pointer deletion and original witness
remain exercised; none is replaced by a successful stub. The inert candidate and
bus sinks are disclosed and preserve the technical scope. The callback checks
prove unlocked preparation and writer-lock release, not a close syscall.

Before any later server edit, root independently repeated exactly15 cases at
server3fd852c… and new-test24e6b6…: **15 passed,3 existing warnings in2.38s**, exit0,
private suffix `vje5be8r`, unexpected I/O0/refused Git1. The same45-second ASGI
wrapper, no live services/models and actual private SQLite boundaries apply.
The initial descriptor setup error remains retained separately.

**The bounded actual registry→preview integration packet is independently CLEAR.**
This confirms the exercised storage-to-publication wiring, not full rendering,
extraction, physiology, real person qualification or physical device behavior.
Root subsequently began the separately approved activation/binding503 mapping
correction; it does not retroactively change the source identity of this result.
Full client and all-product acceptance, observation-selection/reconciliation
migration and all six scientific programs remain required.
