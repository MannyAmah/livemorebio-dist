# Molstar 4.4.0 distribution inspection: retained stages and findings

2026-09-08. **One archive acquired after explicit amendment; no distribution admission.**
The first stopped metadata phase remains below as history; later stages are
separately attributed rather than rewriting that failure as success.
Scope: [approved acquisition boundary](2026-09-08-molecular-distribution-acquisition-scope.md)
and the complete prior200-line molecular-inspector dependency review, both read.
The review skill's scope/distribution/source-evidence checks were applied. Its
upgrade, telemetry, repository mutation and external review commands were not
used in this restricted source-artifact task. No callable gbrain was available;
local prior-art reports were used.

## Retained first attempt

Private directory: `/tmp/livemore-molstar-inspection.uCgWWp`, mode0700.
The authored `acquire.py` uses a fixed metadata URL and fixed archive URL,
HTTPS verification, no proxy handler, no redirect or retry, bounded byte reads
and a default-action OS30-second alarm per phase. The metadata phase combines
one version GET with a metadata-only tarball HEAD to verify compressed size
before any archive GET. No npm CLI/package code is invoked.

The first phase exited1, retaining an AssertionError-class receipt at elapsed
0.5812169589917175seconds. Version metadata was retained and independently read;
the phase did not create its verified-size result. The exact failed HEAD guard
was not recorded: do not claim that a particular response header was missing.
This is an evidence limitation in the authored acquisition helper, not proof of
an npm distribution defect. No automatic retry occurred.

Exactly four files were present after stopping: `acquire.py`, `metadata.json`,
`metadata-started.json`, `metadata-failure.json`. No archive, extraction tree,
node_modules, install/build output, image or WASM was acquired. No browser,
service, patient/coordinate data, operational store or scientific runtime used.

| Retained file | SHA256 |
|---|---|
| `metadata.json` | `aae24de3b00242863d8bdce60817d18d29bbf139093426f1ba3dcceee69c7a49` |
| `acquire.py` | `a26884d46486f28b66545577a65be973bedfe3284b1fc032ba0a934218459b33` |
| `metadata-failure.json` | `ecb96294fbe424e584ad8350ff478239fadaaefb4edbbb95d4fe1a5220ad73f6` |

## Established official metadata, not archive observations

Source: [official exact-version metadata](https://registry.npmjs.org/molstar/4.4.0).
The response identifies `molstar`, version4.4.0, gitHead
`2b2dfd924589edce7b129e123323c87a4623bdb8`, MIT package label,
5,282 declared files and34,003,049 declared unpacked bytes. Its archive URL is
`https://registry.npmjs.org/molstar/-/molstar-4.4.0.tgz`.
Declared SHA1 is `65b90f7d952925b76f3ac07c58f47e2019264fc4` and SRI is
`sha512-APum+9xK4AIEDdgJIa6P889J05KOgrBzuH59aSVUYroymG8VTCBoXbXgpllIz5J1L6fuz60lExcqg3FIXnOo/g==`.
These are expected integrity values, not digests of an acquired archive.

Declared dependencies include `h264-mp4-encoder:^1.0.12`; dev dependencies
include React/ReactDOM18.3.1 ranges, TypeScript5.5.2 range, webpack5.92.1 range
and Sass1.77.6 range. These do not resolve exact transitive versions or licenses.
The declared viewer build invokes TypeScript, extra static-file copying and a
viewer webpack configuration. The declared test script installs `gl` and runs
lint/Jest. All were inspected as strings only, never executed. Archive contents,
emitted-code membership, embedded WASM, third-party notices and the smallest
structure-only entry graph therefore remain unverified.

## Stop condition and next decision

The approved compressed-size-before-acquisition condition is not yet satisfied.
Requested root direction: one additional **metadata-only HEAD**, retaining safe
status, final URL, Content-Length/Encoding and elapsed time, without archive GET
or a changed size limit. If compressed size still cannot be established, stop
again and request an explicit amended size-admission contract; do not silently
stream an archive under the current declaration. The one archive allowance is
unused. Preserve this failed phase and its hashes if later work is approved.

Lesson: a fixed safe exception class alone is insufficient acquisition evidence;
retain the exact non-sensitive admission stage/header facts before checking it.
No Molstar redistribution/build decision or R03/R23/R24 completion follows from
this metadata result. Existing molecular functionality remains unchanged.

## Separately authorized one-HEAD receipt

Root approved one15-second metadata-only HEAD in the scope's final section.
The new `head-metadata.py`, not the failed acquisition helper, ran once, exit0.
Receipt elapsed0.10721437499159947seconds: HTTP200, exact URL-match true,
Content-Length absent, Content-Encoding absent, Content-Type application/octet-stream.
No response body was read. These actual fields establish the missing compressed
size for this request; they do not retroactively identify the original failure.
`head-receipt.json` and `head-started.json` are retained in the same private root.
The archive allowance remains unused pending root's explicit size-admission
decision. No install/build/extraction or product change occurred.

## Explicitly amended single archive acquisition and bounded inventory

After reading the HEAD receipt, root amended the scope to allow a counted stream
without an advertised length, preserving32MiB/30s and exact URL/SRI/SHA1. The
new `archive-once.py` made exactly one archive GET. It completed exit0 in
0.2667452500318177seconds,6,960,078 actual bytes. SHA512 SRI and SHA1 both match
the original metadata. No metadata/HEAD repeat or archive retry occurred.

Archive SHA256: `d5c294fb5a87650c70a3012636b0060d60faca2e8542e3fd9a051df9678e06d5`.
SHA512: `00fba6fbdc4ae002040dd80921ae8ff3cf49d3928e82b073b87e7d69255462ba32986f154c20685db5e0a65948cf92752fa7eecfad2513172a8371485e73a8fe`.
No package/source installation, build, JavaScript/WASM evaluation or browser was
used. The compressed artifact remains in the original private0700 directory.

`inventory.py` read gzip/tar as data without extracting archive paths. It rejected
unsafe/noncanonical/duplicate paths, links, devices, sparse entries, excessive
file counts and sizes; separately capped total decompressed reads at300MiB.
All5,282 entries are regular files, totaling34,003,049 declared/actual file bytes,
exactly matching metadata. Total gzip output including tar framing is38,024,192
bytes. Package manifest name/version matches. Gzip EOF/CRC and trailing padding
were checked. Full canonical sorted name/size/SHA256 inventory is retained.

| Private retained evidence | SHA256 |
|---|---|
| `head-metadata.py` | `435981e91dfecf2926d3adb7642cfdaf534d9580acad1caa88dbc05ee6003146` |
| `head-receipt.json` | `2965fca443c3897ef9a17c9d6b59f79bf9d26439f18cc070ac45231f9f6cfa1d` |
| `archive-once.py` | `2655fc24b6373f2cb985f76710cfdba3301c3cd1c7b0407132fc09eb58db1028` |
| `archive-once-result.json` | `ce84876d46bbf15a11b9595fa6b1539febe000313524aaa7b4a16c5935cbf8cc` |
| `inventory.py` | `cf73cbe91cfacf67396cb7516ef6aca78a25d1f626094beb976bc69674a128fd` |
| `inventory.json` | `3b0154265a2505ef821a5be6da7c3bb6593fd585c8725ee170b94f0e5e04a5e9` |
| `retained-manifest-notices.json` | `61d35873478dcd4f78d6f58ade3a15ed2f5566ca5b686e449be98cb1ad79e120` |
| `bundle-evidence.py` | `c9e85e4f8834bc25d34836ddd3f6751c3f5973b59d2d9083addf10e1350b403c` |
| `bundle-evidence.json` | `2dda3429521a3a0612aa40f3c2a6cd92d0abbec7772571059937bb6553529340` |

## Actual emitted artifacts and notice gaps

The13 `build/viewer/` files total5,609,664 bytes: JS4,894,529;
CSS69,902; two HTML documents; favicon; seven JPGs; one extracted-license text.
The archive also contains transpiled ESM/CommonJS modules, declarations and SCSS.
It contains no `src/` TypeScript tree, webpack/tsconfig files or npm/yarn/pnpm
lockfile. Declared build commands therefore do not constitute a reproducible
build recipe contained entirely in this archive.

| Actual distribution artifact | SHA256 |
|---|---|
| `build/viewer/molstar.js` | `25c4c64c899a20a53736fe395bc71c8fb28879942a88852528a0cb7665cdca83` |
| `build/viewer/molstar.css` | `ec90bcaa8610dc104656bc57effede3d6e1b954c2386dcaee985a88b8799c089` |
| `build/viewer/molstar.js.LICENSE.txt` | `b25a1f014ffbc8707b53a424392a5729b4adc6cb5911925359f6bad765504003` |
| Embedded WASM payload,707,751 bytes | `32b6c253da5768b97ef3e4a6b22310c73698179e9033b97fe245a0d6e4210e37` |

The JS includes `createH264MP4Encoder` and one base64 data-URL payload with
WASM-v1 magic/version. The payload was decoded in memory only for size/hash,
not instantiated or saved as an executable. There are no standalone `.wasm`
or `.mp4` files. Therefore searching only filenames would miss codec bytes.
`lib/extensions/mp4-export/encoder.js` explicitly imports h264-mp4-encoder, and
`lib/apps/viewer/app.js` statically imports Mp4Export. Disabling its runtime
extension does not remove those distributed bytes. An embedded React18.3.1
string is observed, but does not resolve the entire dependency graph.

Only two license-named files exist: package MIT LICENSE and the emitted JS
notice. The latter contains safe-buffer and React/ReactDOM/JSX-runtime/scheduler
headers, not a resolved third-party license inventory. It has no h264/mp4v2
notice. The prior source review's encoder MIT/public-domain/MPL1.1 components
still require exact resolved-version and corresponding-source/notice review;
this archive does not close it. No legal conclusion of MIT-only redistribution
or exact embedded codec version follows from minified names or hashes.

All seven emitted JPG hashes match the corresponding cells/nebula module assets.
The backgrounds module retains the public-domain source comment for cells and
the skybox generator reference, not a full per-asset license inventory. Three
favicon copies and fourteen JPG copies appear across build/lib; no font files
were found. The SCSS retains normalize.css3.0.3's MIT header and a system-font
stack. Existing notice obligations must survive any separately approved build.

## Smallest supported structure-only build direction, not a build approval

Do not copy the full viewer bundle, and do not import `apps/viewer/index.js` or
`apps/viewer/app.js` into a supposedly structure-only entry. Their static imports
bring HTML/favicon, MP4, backgrounds, remote providers and other extensions.

A small reviewed entry can instead use the existing `lib/mol-plugin-ui/index.js`
`createPluginUI` and `lib/mol-plugin-ui/react18.js` renderer, an explicit Molstar
UI specification and `skin/light.scss`. The inspected Viewer data method uses
the existing builders' rawData → parseTrajectory → hierarchy.applyPreset path;
reuse this local-data path and Molstar's structure selection/focus/measurement
controls, not loadPdb or a new molecular renderer. Keep own close/disposal and
context fencing in the separately approved controller plan.

DefaultPluginUISpec/DefaultPluginSpec themselves include volume streaming,
download/open-file actions and animations. Merely removing viewer extensions
does not establish action or request closure. A structure-only build must select
needed structure behaviors/actions explicitly and test emitted import closure;
keep rotations/zoom/selection while distinguishing camera motion from biology.
Preserve needed controls rather than hiding the molecular feature.

Minimum new build inputs are: this admitted-by-integrity ESM/SCSS distribution,
a reviewed small entry/specification, exact locked browser dependencies
(including React/ReactDOM, not merely their ranges), bundler/Sass configuration,
toolchain pins and complete third-party notices. The archive can supply existing
transpiled modules; reproducing upstream's TypeScript build requires separately
acquired exact-commit source/configuration, not an invented local `npm run build`.
No build output or tree-shaking result has been measured here.

**DONE_WITH_CONCERNS:** bounded acquisition/inventory completed, with original
failure preserved. Independent retained-inventory review precedes any build or
vendor decision. Licensing/dependency closure, protected coordinate admission,
same-origin behavior, installed-wheel coverage and real UI acceptance remain
open exactly as in the prior plan. No R03/R23/R24 or full-product completion claim.

## Root retained-artifact review

Root read all193 report lines; all174 lines of the archive, inventory and bundle
inspection helpers; the full retained manifest/notices; and both summary receipts.
Root independently rehashed the6,960,078-byte archive, full inventory, three
helpers and retained notices; all match the pins above. No network acquisition,
package execution, extraction or bundle build was repeated. Integrity/inventory
review is CLEAR within this data-only boundary. It does not clear dependency
licensing, package installation, emitted bundle behavior or product acceptance.
The next bounded increment is a written finite structure-only build/controller
plan using existing Molstar components and the protected coordinate path. No new
molecular renderer, full viewer/codec copy or product edit is approved here.
