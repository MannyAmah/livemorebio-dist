# Scientific integrity: parameter identity and unsupported interventions

Date: 2026-09-05. Applies to Aegle profiles, metabolic/GEM interventions and Cendos assays.

## Failure and decision

The previous generic plant paths assigned beneficial Si/Gb/gamma changes to any name.
ChEMBL action labels became assumed flux multipliers; GEM capacity ratios were then
treated as whole-body physiological changes. These transforms had no qualified
compound/exposure/context relationship. They now raise
`UnsupportedInterventionError` (`UNSUPPORTED_BIOLOGICAL_INTERVENTION`) before mutation.
Reference target lookup and explicitly specified low-level reaction constraints remain
available. The existing registered metformin and PXR hypothesis protocols retain their
stated limited scope. An unknown compound also cannot receive a generic PK curve.

Food names no longer add protective disease-progression coefficients. The meal equation
can still use known carbohydrate content, while phytochemical effects are not assessable.
Cendos's current-twin assay requires an actual current-twin snapshot instead of silently
substituting a T2D preset.

## Admitted profile contract

Reference single twins formerly regenerated an unrelated SyntheticHuman on activation,
discarding the stored reference physiology. They now compile the frozen saved parameters
through the same explicit profile boundary as admitted person records.

Clinical observations require aware timestamps and compatible units. Known glucose,
insulin and weight units normalize before mapping; original values and units are retained.
Failed QC is rejected. Unassessed measurements remain records but cannot initialize a
model parameter. Random glucose cannot set the fasting glucose parameter; an explicit
fasting signal/context is required. Conflicting observations or declared overrides need
review. Positive finite executable-domain checks reject invalid model parameters.

Every metabolic parameter carries its value, unit, source and initialization class.
Missing physiology remains a visible reference prior, not a claimed person measurement.
Declared research parameters are distinct from clinical observations. Runtime parameter
changes retain the initial value and initial evidence class.

An independent cross-system check also found that Aegle and Cendos copied only eight
profile fields, silently restoring five others to defaults. The complete dataclass
now survives admission, state export, bus publication and current-twin assay:
`p2`, `n`, `ka`, `f_bioavail` and `vg_per_kg` are included and validated. Cendos rejects
partial parameters, missing/inconsistent profile identity and missing explicit PK
input context. Assay output returns the exact parameter set and context it used.
Reference age/genotype assumptions are declared in the snapshot rather than invented
by the receiving service. Restart both services when upgrading this snapshot contract.

## Verification

The first 22 integrity regressions failed on the inherited implementation, then passed
after repair. Extended lane verification: 87 passed and 7 model/environment-gated skips
across the scientific-integrity, subject lifecycle, protocol, pharmacology, Cendos,
GEM, screen, trajectory, food and Aegle tests. This checks software integrity, not
clinical or wet-lab equivalence. The root release validation report records final totals.

## Remaining scientific work

The metformin PD gains, age-derived renal clearance and metabolic–cardiac coupling remain
explicit research assumptions. Replacing them requires qualified longitudinal exposure,
endpoint and organ-function data. The real-human intake is an admitted data bundle; this
repair does not create a vendor EHR connection, validate instrument provenance or establish
a clinically qualified model. Independent measured counterparts are still necessary.

Lesson: preserving a reference source label is insufficient. Persist and execute the exact
individual parameter set, normalize admitted measurements, and reject any unsupported
causal transformation at every callable boundary.

## Independent research API review

The HTTP boundary must preserve the same evidence guarantees as the service. The
independent API tests verify that authorization precedes parsing/storage, caller-supplied
predictions cannot replace the stored run, technical fixtures cannot acquire a validation
claim, measurement bindings and units are enforced, exports are explicit, and frozen
runs cannot be overwritten. Test data and encrypted stores are temporary fixtures only.

Review reproduced missing no-store headers, nonfinite/duplicate JSON acceptance, an
uncaught key-configuration failure, and synchronous SQLite work on the async request
loop. The research router now applies no-store to handled responses and authorization
errors, rejects ambiguous/nonfinite/deep JSON, returns a safe storage failure, and moves
blocking mutation work into a worker thread. Application middleware must also cover
authorization failures that occur before the router. Stored-run shape and evidence
validation belong in the service too, not only in the JSON request parser.

Lesson: a frozen protocol is only useful if every interface reads that exact protocol.
Transport errors must fail closed and must not hide independent service validation gaps.

The integrated scientific-integrity, HTTP research, service research, inherited
evidence-grounded experiment and subject-lifecycle tests passed together: 146 passed
with three framework deprecation warnings. This is software integrity evidence only.

## Legacy evidence migration

The old browser exporter manufactured an independent protocol approver and a QA
reviewer to lock reports. It also presented the hash of a seed-module label as a
dataset-content hash. These assertions are removed. Internal legacy reports are
unapproved drafts with no reviewer authority. Dataset lineage is explicitly not
declared, working-tree code is explicitly unpinned, and caller audit references
remain unverified correlation identifiers instead of verified content hashes.

Browser `POST /api/evidence` now returns `409 LEGACY_EVIDENCE_INTAKE_DISABLED`
before parsing the body: arbitrary person profiles cannot be admitted to its legacy
plaintext store. Migrate creation to `/api/research/studies`, which resolves frozen
server-side Cendos runs and uses encrypted research storage. Existing records remain
readable; draft ZIP export requires a separately authenticated review and lock.
The endpoint does not invent a reviewer to perform that action.

Finite-number admission now converts integer-to-float overflow into a bounded input
error. Scientific narrative fields permit printable paragraphs and tabs, while IDs,
authors, modules and URLs retain their strict single-line boundary. The legacy
intervention endpoint rejects malformed JSON and nonobject parameters before mutation.

Follow-up verification including the evidence service: 212 passed and 44 subtests
passed, with three framework deprecation warnings. All new boundary tests use
temporary synthetic fixtures and do not establish physical or clinical equivalence.
