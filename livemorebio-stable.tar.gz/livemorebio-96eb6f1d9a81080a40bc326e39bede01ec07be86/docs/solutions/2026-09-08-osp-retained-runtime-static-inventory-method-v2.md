# OSP static inventory V2: fixed-file, lossless retention method

2026-09-08. Root-approved representation correction only. The original V1
manifest, method, mapping and RED receipts are unchanged. This method reads only
the exact original candidate paths; it does not rediscover or add candidates.
It reads bytes/stat metadata, never imports product code or starts R/CLR/native,
network, browser or subprocess work. Its two scalar loops are authored encoding
checks, not physiological or collector tests.

Run with the existing bundled Python interpreter and `-B`. All unsafe integers
are encoded from exact Python integers to canonical decimal strings BEFORE
json.dumps. No float conversion appears in generation or acceptance. The helper
integer() applies only to known numeric fields, never arbitrary strings.

The method emits one SHA256 transport-header line followed by final JSON bytes.
The functions orchestration splits that first line as text and passes the exact
remaining stdout through apply_patch, without JSON.parse or JSON.stringify.
The final file SHA256 must equal that producer header. Reading JSON for later
validation is separate and must preserve unsafe integer strings.

The fresh stat values must match the exact decimal observations in the retained
RED and inode replay; any intervening metadata drift stops. Every original full
content hash and each original subcache header hash must match. Thus a new file
or unexplained change cannot be absorbed as a representation repair.

```python
from pathlib import Path
from copy import deepcopy
import hashlib,json,os,re,stat
DOCS=Path('/Users/emman/Livemore/.worktrees/full-scope-recovery/docs/solutions')
MAX_SAFE=9007199254740991
PINS={
 '2026-09-08-osp-retained-runtime-static-inventory.json':'fc5afe90a5d51b92014c559708b8737e1cc08e8b029bdea7cb79d7c565205f95',
 '2026-09-08-osp-static-metadata-precision-red.json':'e772739b66f6a4ab083692baf025b93c21a8b5ec5adaf7fb68e1974e44e13a64',
 '2026-09-08-osp-static-metadata-roundtrip-reproduction.json':'2e36816702e92d60277a27ed4cf5c0fa2253f7b8d9a81b56c4c5c632ea9be449'}
def evidence(name):
    raw=(DOCS/name).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==PINS[name]
    return json.loads(raw)
old=evidence('2026-09-08-osp-retained-runtime-static-inventory.json')
red=evidence('2026-09-08-osp-static-metadata-precision-red.json')
replay=evidence('2026-09-08-osp-static-metadata-roundtrip-reproduction.json')
assert old['schema']=='OSP_RETAINED_STATIC_INVENTORY_V1'
assert old['counts']['files']==1370
expected_time={(r['group'],r['path']):int(r['current_mtime_ns']) for r in red['checks']}
expected_inode={r['path']:int(r['current_inode']) for r in replay['inode_checks']}
assert len(expected_time)==1390 and len(expected_inode)==6
new=deepcopy(old)
ROOT=Path(old['runtime_root']); REAL=Path(old['resolved_runtime_root'])
assert ROOT.resolve(strict=True)==REAL
def encode(x):
    if type(x) is int:return str(x) if abs(x)>MAX_SAFE else x
    if type(x) is list:return [encode(v) for v in x]
    if type(x) is dict:return {k:encode(v) for k,v in x.items()}
    return x
def integer(x):
    if type(x) is int:
        assert abs(x)<=MAX_SAFE
        return x
    assert type(x) is str and len(x)<=21
    assert re.fullmatch(r'(?:0|-[1-9][0-9]*|[1-9][0-9]*)',x)
    value=int(x)
    assert abs(value)>MAX_SAFE
    return value
# Fixed scalar schema boundary checks, no native/product invocation.
for n in (0,1,-1,MAX_SAFE,-MAX_SAFE,MAX_SAFE+1,-MAX_SAFE-1,
          MAX_SAFE+2,-MAX_SAFE-2,1788854861134072669,
          1152921500312570752,1152921500312570762):
    assert integer(encode(n))==n
assert encode(True) is True and encode(False) is False
for bad in (True,False,None,1.0,float(MAX_SAFE+1),MAX_SAFE+1,
            -MAX_SAFE-1,'0','-0','1','+9007199254740992',
            '09007199254740992','9.007199254740992e15',' 9007199254740992',
            '9007199254740992 ','9'*22):
    try:integer(bad)
    except (AssertionError,ValueError):pass
    else:raise AssertionError('INVALID_INTEGER_ACCEPTED')
def stat_key(s):
    return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,stat.S_IMODE(s.st_mode))
full_hashes=0; headers=0
for group,rows in [('files',new['files']),
                   ('system_files',new['system_identity']['files']),
                   ('subcache_metadata',new['system_identity']['subcache_metadata_not_content_proof'])]:
    for row in rows:
        logical=ROOT/row['path'] if group=='files' else Path(row['path'])
        resolved=logical.resolve(strict=True)
        expected=(REAL/row.get('resolved_relative_path',row['path'])) if group=='files' else Path(row.get('resolved_path',row['path']))
        assert resolved==expected.resolve(strict=True)
        if group=='files':assert resolved.is_relative_to(REAL)
        before=resolved.stat()
        assert stat.S_ISREG(before.st_mode) and before.st_size==row['bytes']
        assert before.st_mtime_ns==expected_time[(group,row['path'])]
        identity=row.get('file_identity')
        if identity is not None:
            assert before.st_dev==identity['device'] and stat.S_IMODE(before.st_mode)==identity['mode']
            old_inode=expected_inode.get(row['path'],identity['inode'])
            assert before.st_ino==old_inode
        h=hashlib.sha256()
        with resolved.open('rb') as f:
            assert stat_key(os.fstat(f.fileno()))==stat_key(before)
            if group=='subcache_metadata':
                h.update(f.read(4096)); headers+=1
                assert h.hexdigest()==row['header_4096_sha256']
            else:
                assert before.st_size<=134217728
                while block:=f.read(1048576):h.update(block)
                full_hashes+=1
                assert h.hexdigest()==row['sha256']
            assert stat_key(os.fstat(f.fileno()))==stat_key(before)
        assert stat_key(resolved.stat())==stat_key(before)
        assert logical.resolve(strict=True)==resolved
        if identity is not None:
            row['file_identity']={'device':before.st_dev,'inode':before.st_ino,
                                  'mtime_ns':before.st_mtime_ns,'mode':stat.S_IMODE(before.st_mode)}
        else:row['mtime_ns']=before.st_mtime_ns
assert full_hashes==1378 and headers==12
new['schema']='OSP_RETAINED_STATIC_INVENTORY_V2'
new['integer_encoding']='UNSAFE_INTEGERS_AS_CANONICAL_DECIMAL_STRINGS'
new=encode(new)
# Every numeric token is now safe; unsafe fields have schema-directed strings.
def check(x):
    if type(x) is int:assert abs(x)<=MAX_SAFE
    elif type(x) is list:
        for v in x:check(v)
    elif type(x) is dict:
        for v in x.values():check(v)
check(new)
parts=[]
for key,value in sorted(new.items()):
    body=('[\n'+',\n'.join(json.dumps(v,sort_keys=True,separators=(',',':')) for v in value)+'\n]') if type(value) is list else json.dumps(value,sort_keys=True,separators=(',',':'))
    parts.append(json.dumps(key)+': '+body)
raw=('{\n'+',\n'.join(parts)+'\n}\n').encode('utf-8')
# Digest line is a transport header, not part of the JSON payload.
print('SHA256='+hashlib.sha256(raw).hexdigest())
print(raw.decode('utf-8'),end='')
```

## Post-retention exact-check source

This separate file-data check runs after V2 is written. It compares the entire
new structure against V1 with only the approved schema/encoding/exact metadata
changes, then verifies every actual admitted file. No directory discovery,
external process or scientific module is used. Its successful receipt is recorded
in the lossless-correction amendment. The V2 digest is deliberately fixed here.

```python
from pathlib import Path
from copy import deepcopy
import hashlib,json,stat,datetime
docs=Path('/Users/emman/Livemore/.worktrees/full-scope-recovery/docs/solutions')
files={'old':'2026-09-08-osp-retained-runtime-static-inventory.json','new':'2026-09-08-osp-retained-runtime-static-inventory-v2.json','red':'2026-09-08-osp-static-metadata-precision-red.json','replay':'2026-09-08-osp-static-metadata-roundtrip-reproduction.json'}
sha={k:hashlib.sha256((docs/v).read_bytes()).hexdigest() for k,v in files.items()}
assert sha['old']=='fc5afe90a5d51b92014c559708b8737e1cc08e8b029bdea7cb79d7c565205f95'
assert sha['new']=='d09b1f5dcb15d6d612b8b5301c2bb5f6a4c7f174b8e08eeff1df24b087c94be2'
xs={k:json.loads((docs/v).read_bytes()) for k,v in files.items()}
expected=deepcopy(xs['old']); observed=xs['new']
times={(r['group'],r['path']):int(r['current_mtime_ns']) for r in xs['red']['checks']}
inodes={r['path']:int(r['current_inode']) for r in xs['replay']['inode_checks']}
for group,rows in [('files',expected['files']),('system_files',expected['system_identity']['files']),('subcache_metadata',expected['system_identity']['subcache_metadata_not_content_proof'])]:
    for row in rows:
        target=row.get('file_identity',row);target['mtime_ns']=times[(group,row['path'])]
        if group=='system_files' and row['path'] in inodes:target['inode']=inodes[row['path']]
def encode(x):
    if type(x) is int:return str(x) if abs(x)>9007199254740991 else x
    if type(x) is list:return [encode(v) for v in x]
    if type(x) is dict:return {k:encode(v) for k,v in x.items()}
    return x
expected['schema']='OSP_RETAINED_STATIC_INVENTORY_V2'
expected['integer_encoding']='UNSAFE_INTEGERS_AS_CANONICAL_DECIMAL_STRINGS'
assert observed==encode(expected),'UNEXPECTED_MANIFEST_CHANGE'
n=0; hashed=0; headers=0
for group,rows in [('files',observed['files']),('system_files',observed['system_identity']['files']),('subcache_metadata',observed['system_identity']['subcache_metadata_not_content_proof'])]:
    for row in rows:
        p=Path(observed['runtime_root'])/row['path'] if group=='files' else Path(row['path'])
        resolved=p.resolve(strict=True);s=resolved.stat()
        expected_path=Path(observed['resolved_runtime_root'])/row.get('resolved_relative_path',row['path']) if group=='files' else Path(row.get('resolved_path',row['path']))
        assert resolved==expected_path.resolve(strict=True)
        assert stat.S_ISREG(s.st_mode) and s.st_size==row['bytes']
        ident=row.get('file_identity',row)
        assert s.st_mtime_ns==int(ident['mtime_ns'])
        if group!='subcache_metadata':
            assert s.st_dev==int(ident['device']) and s.st_ino==int(ident['inode'])
            assert stat.S_IMODE(s.st_mode)==int(ident['mode'])
        h=hashlib.sha256()
        with resolved.open('rb') as f:
            if group=='subcache_metadata':
                h.update(f.read(4096));assert h.hexdigest()==row['header_4096_sha256'];headers+=1
            else:
                while b:=f.read(1048576):h.update(b)
                assert h.hexdigest()==row['sha256'];hashed+=1
        t=resolved.stat()
        assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_mode)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns,t.st_mode)
        assert p.resolve(strict=True)==resolved
        n+=1
assert n==1390 and hashed==1378 and headers==12
print(json.dumps({'status':'PASS','observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exact_rows':n,'full_content_hashes':hashed,'subcache_header_hashes':headers,'unexpected_semantic_changes':0,'original_sha256':sha['old'],'v2_sha256':sha['new']},sort_keys=True))
```
