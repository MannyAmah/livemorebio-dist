# OSP fixed OS-only preflight — private implementation review packet

2026-09-09. **Maker evidence only; independent source/test review is required.**
No actual OS preflight, fixture child, vmmap, R, CLR, compiler, model, browser,
service or network request was run. Nothing here admits S01–S17, changes the
six original scientific programs or reverses any retained failure.

## Authority and exact write boundary

Root read and approved the complete
[seven-condition plan](2026-09-08-osp-semantic-os-preflight-plan.md), including
its final private-only ownership decision, before this implementation.
The sole new implementation/test directory is
`/private/tmp/livemore-osp-os-preflight.AFtKah` (0700).
It contains exactly the three 0600 files below. The directory has no
authorization, once marker, evidence directory or actual-run receipt.
No existing repository runtime or test file was edited by this task.
This report is the only new repository artifact.

| Private file | Lines | SHA256 |
|---|---:|---|
| run_preflight.py | 379 | 90ee5c09988a1d2b6c0875f3bdf8adea637a3c2cb0d8928c34044a69b9ab6f48 |
| fixture.py | 106 | 6104182d06c6e75069ffb6e062c9e11e9c88be6c7605dbeb9cfec955886bb239 |
| test_preflight.py | 414 | 30de19f87c979fee23de4930c5eccc48311fa288c85de581df931f546ac8d2ff |

Frozen reuse was rehashed after the final changes:

| Unchanged repository file | SHA256 |
|---|---|
| tools/osp_semantic_supervisor.py | cdb00a1acb5b08b3f7d8aff0f3977f746b5a506ed4f97355b56dd34bf2d2a476 |
| tools/osp_semantic_probes.R | 3ba6559b723cfe85c66bca47aac0abfbaac8e395c430bd7360105dc6f67625f7 |
| tools/osp_semantic_probes.py | 12585d9bed93cd2a5625ec1cd625287406a22d475b49c34ba931109630ea82d7 |

The private gate and both production gates remain false on disk.
The actual-launch command and separate exact-hash authorization still require
root's independent decision. Enabling only the private driver module's flag
in a future approved launcher must not edit these frozen bytes or enable either
production flag. No launcher or authorization was written or executed here.

## Fixed implementation

The driver verifies the supervisor module path and original function source
bindings. It changes only that module's process classifier inside one
try/finally; sampling, WNOWAIT, owned-group proof, Popen, stream draining,
limits, TERM/KILL, cleanup and the unresolved slot are the original methods.
The fixed classifier records bounded unique contradictory observations before
rejecting them and uses the supervisor's actual SupervisionError type.

The fixture accepts only the six reviewed worker commands and the single
O3 inspector command, with the exact private directory. Its imports are only
json/os/signal/sys/time. Marker output is exactly
`<case>:<role>\n` on stdout and `osp-os-only\n` on stderr.
Expected hashes are recomputed from those bytes, not trusted from receipts.
PID-bearing barrier/ready JSON is strict, bounded to4KiB and atomically
published without replacement. The only exec target is exact /bin/sleep2.5;
the only fork is the one declared O4 same-group descendant.

The mounted test path uses authored process observations and callbacks.
The actual execution path remains the unchanged supervisor:

- O1: two OS-only barriers, two actual vmmap commands scoped to the proven
  worker PID, original vmmap format/parser and original inspector admission.
- O2: exact immediate-exit streams; positive resource samples or the distinct
  zero-sample fail-closed branch, never a false resource-qualified success.
- O3: one authored sleeping Python inspector; original2s deadline/cleanup.
- O4: readiness pipe and observed descendant; actual TERM then KILL required.
- O5: deliberately raised parent callback KeyboardInterrupt, labeled as such.
- O6: original Python image becomes contradictory after an exact exec ACK.
  The callback does not prematurely re-prove that deliberately changed image;
  the unchanged timed sampler classifies and retains the contradiction.
  Unresolved cleanup must contain no signals, reap or claimed exit.
- O7: both the real entry guard and actual _execute entry are exercised with
  the existing otherwise-valid O2 command/directory. No O7 directory/child.
  Only then may WNOWAIT observe the same held leader's natural exit and the
  unchanged cleanup method settle it. Original unresolved receipt and the
  historical slot remain intact.

The whole60s budget and complete10/5/8/6/6/6s case ceilings are unchanged.
The seven-condition success path accounts for exactly nine direct children,
of which three are inspectors, and one fork descendant. No retries.
Unexpected failure stops subsequent cases as NOT_RUN.

Before the first child: static pin verification, exact canonical authorization,
exclusive once marker, then private case allocation. After the matrix: source
and static pin revalidation, unchanged production gates, bounded evidence tree,
and deadline admission. The final JSON explicitly has
`completion_requires_exit_zero=true` and
`elapsed_before_final_receipt_s`; it is not, by itself, proof that its write
completed on time. A post-write deadline check must pass before a zero exit.
The final stdout elapsed value includes revalidation and the receipt write.
A failed or late write exits nonzero without rewriting the original JSON.
Case evidence-write/disk failures retain the original process/inspector receipts
in the returned parent packet and add a separate fixed evidence error.

## Static identity reads, not process-image observations

Only the four exact plan-authorized files below were read and hashed for
preparation. Their source-code pin fields preserve identity integers as
lossless decimal strings; the driver converts only safe exact integers for
the unchanged shared validator. No executable was invoked to obtain this data.

| Path | Bytes | SHA256 |
|---|---:|---|
| /Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 | 17255968 | e3938f2a272dafdc33f3dd12b093dfc85354629476cb97a7d7d4a7201b8482dd |
| /usr/bin/vmmap | 262464 | d396d8f087ef05c626eb5e0e533f88f196550e1efbedba4413e11578615436e9 |
| /bin/sleep | 101168 | 00c84d198e2b80da7dc47c0e30d311cd632f74c257793c4b45723f2cb7ca5d2c |
| /System/Library/CoreServices/SystemVersion.plist | 604 | 7cd74d8a730f38923ef39aed140d3172b3886e64b55f7489f33cef3731687709 |

Resolved paths, device/inode/mode/mtime_ns are retained in the driver PINS rows.
These are static file identities, not observations of loaded Python/R images,
the rSharp shell topology, native library closure or source/build equivalence.

## RED/GREEN evidence retained

All invocations below used the same guarded private offline command in the
next section. Their complete outputs are retained in this task's tool history;
the private review roots hold authored pytest artifacts, not subprocess logs.
Every invocation reported zero unexpected I/O attempts.

Private root prefix:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-`

| Root suffix | Actual result | Interpretation |
|---|---|---|
| dhb0m5wb | 32 setup errors,0.21s | Initial RED: driver did not exist; not actual OS evidence. |
| 53g0ub3c | 32 passed,0.15s | First implementation of fixed offline contracts. |
| g7ztzmbs | 3 failed,33 passed,0.23s | New exact exception-class, full mounted matrix and otherwise-valid O7 tests exposed2 driver defects. |
| _bmgkofr | 36 passed,0.19s | Corrected classifier exception type and O2 scope. |
| qcb9wnhe | 5 failed,38 passed,0.41s | New mounted evidence-write/disk, post-exec callback and final timing checks exposed3 driver defects. |
| 5mw_1mhb | 43 passed,0.36s | Final corrected candidate; no weakened assertions. |

The last five failures were exactly: two missing returned process receipts
after final case-write/disk errors; O6 became IDENTITY_BRANCH failure because
a callback proof preempted sampled contradiction; no post-final-write deadline
rejection; and final elapsed excluded two seconds of authored revalidation
plus0.1s of authored write. The corresponding corrections are private-driver
only. Raw process receipts remain unchanged.

The43 tests cover gate-before-access, fixed argv/env/roles and child scope,
original vmmap delegation, contradiction retention, zero-sample distinction,
cleanup/stream/elapsed refusal, terminal observation before cleanup, actual
occupied-slot guard before Popen, classifier finally restoration, fixture AST,
a complete mounted seven-condition/nine-call path, fail-stop, case evidence
failure retention, O6 callback ordering, full mounted driver authorization/
marker/result path, final deadline/timing, static-pin failure before allocation,
and rejecting numeric1 in place of boolean authorization.
No test calls the actual OS sampling or process-launch functions.

## Exact reusable independent offline command

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`.
This is an offline pytest command, **not the preflight invocation**.
Socket construction/connect/DNS, urllib, process launch/fork/exec/spawn and
ctypes dynamic loading are refused. Pytest plugin autoload is disabled;
the45s alarm bounds this test process. prepare_review_environment creates
only a fresh private test environment.

```bash
PYTHONDONTWRITEBYTECODE=1 /Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B - <<'PY'
import os,sys,signal,socket,subprocess,urllib.request,multiprocessing.process
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:v for k,v in os.environ.items() if k in ('PATH','HOME','TMPDIR','LANG','LC_ALL')})
env.update(PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1');os.environ.clear();os.environ.update(env)
counts={'unexpected_io':0}
def deny(*a,**kw):
 counts['unexpected_io']+=1
 raise AssertionError('Unexpected network, native load, or child in offline OS-preflight tests')
for owner,names in ((socket,('socket','create_connection','getaddrinfo')),(subprocess,('Popen','run','call','check_output')),(urllib.request,('urlopen',)),(multiprocessing.process.BaseProcess,('start',))):
 for name in names:setattr(owner,name,deny)
def hook(event,args):
 if event in ('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.exec','ctypes.dlopen'):deny()
sys.addaudithook(hook);signal.alarm(45);print('Private test root:',root,flush=True)
import pytest
code=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(root/'pytest'),'--tb=short','/private/tmp/livemore-osp-os-preflight.AFtKah/test_preflight.py'])
print('Refusals:',counts,flush=True);signal.alarm(0)
raise SystemExit(code or bool(counts['unexpected_io']))
PY
```

## Review gate and lesson

Independent root source review and the same offline repeat remain required.
Only afterward may root separately decide whether to authorize one actual
OS-only preflight. An offline PASS establishes authored harness behavior,
not macOS permissions/ABI/argv/vmmap behavior, actual sampling cadence, actual
descendant cleanup or the17 scientific technical cases.

Lesson: negative ownership probes require evidence-path fidelity as well as
a safe refusal. A generic exception or premature callback proof can hide the
very sampled contradiction under test. Likewise, returning a primary process
receipt and persisting the final packet are separate fallible phases; preserve
both evidence and observed deadline semantics without laundering a failure
into successful cleanup or rewriting a prior receipt.

## Independent root review and once-only OS decision

Root read the complete379-line driver,106-line fixture,414-line tests, this
report and the133-line approved plan. All six private/original file hashes
match the frozen table. Independent exact offline repeat:43 passed in0.34s,
private review suffix `ncv84k0v`, zero unexpected I/O. No actionable blocker
found in the fixed OS-only packet. The occupied historical owner remains
distinct from a live unresolved child; original negative evidence is retained.

Root authorizes one actual OS-only invocation with the exact frozen driver,
fixture and supervisor identities above. A small in-memory importlib launcher
using the pinned canonical Python3.11.15, `-I -B`, env-i system PATH/C locale
sets only the imported private driver's PREFLIGHT_EXECUTION_APPROVED flag.
It calls run(), prints fixed status/elapsed metadata and exits0 only on
OS_PREFLIGHT_PASS. No file's gate is edited; both production gates stay false.
The separate authorization binds seven cases,60seconds,nine direct children
and one fork descendant. Existing exclusive once marker and original cleanup
remain mandatory. No retries, R/CLR/scientific execution or product mutation.

This is not advance acceptance of actual behavior. Root must read the actual
terminal result, every case/process/inspector status and final ownership
settlement. An unexpected result stops the remaining cases and is preserved.
No insulin or plant experiment, biological equivalence or recording is
completed by an OS-only result, even if every condition passes.

## Actual once-only result — FAILED, September9

The authorized invocation ran once, session25355, exit1, elapsed1.6232s.
Original final receipt:
`/private/tmp/livemore-osp-os-preflight.AFtKah/preflight-result.json`, SHA256
`1bbb6d3290bbf6bcc0869341d0447f8c02aefd333ef2a9eef6397013cd45446c`.
Root read the entire receipt and the retained inspector streams. No retry or
change to the original authorization, source, limits or receipt occurred.

O1 stopped on its first vmmap inspector. PID12131 inspected authored worker
PID12130 with the exact approved `/usr/bin/vmmap -w 12130` argv. Its primary
result is WORKER_DEADLINE after1.5203986s; stdout contains0 bytes. The40-byte
stderr is `vmmap: terminated; resuming target task\n`, SHA256
`41bc02d0afd3ef5b8d3300c1702fdf2d5c1beab98516c49198fb0ded1b8253a4`.
It received TERM, not KILL, and settled with exit255 and empty-before-reap.
The15 inspector samples have maximum gap0.1064412s and peak RSS37,027,840bytes.
The original supervisor reserves0.5s of the2s inspector envelope for cleanup,
so its work window is1.5s. These facts show a work deadline, not a demonstrated
permission denial, SIP restriction or incorrect scientific source.

O1's worker was then terminated and settled: exit-15, TERM only,
empty-before-reap, elapsed1.5618171s,15 samples, maximum gap0.1060718s,
peak RSS17,301,504bytes. Both stream EOF receipts were retained. No barrier
was accepted or acknowledged. The case remains FAILED/PRIMARY_OR_SAMPLES;
O2–O7 are NOT_RUN. Root's targeted postcheck found neither PID remaining.
The final historical slot is unoccupied. Original source attestation remains
UNVERIFIED; model_admission and native_executed are false.

This failure does not erase the43 offline passes or convert them into actual
OS acceptance. A separate read-only diagnosis must precede any proposed
correction and new execution decision. Do not extend time limits, infer a
permission cause, change mapping semantics or rerun the retained packet merely
to obtain a pass. All17 scientific technical cases and all six experiments
remain unrun in this packet.
