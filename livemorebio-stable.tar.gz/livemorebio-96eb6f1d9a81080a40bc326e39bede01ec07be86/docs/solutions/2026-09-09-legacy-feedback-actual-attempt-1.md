# Current-feedback actual browser attempt 1 — retained failure

Root ran the frozen16-image schedule once. Session45096 exited1 after
10.166079959s. Evidence remains at
`/private/tmp/livemore-legacy-preview-c_1ximjr`.
Source: `f9f7b4384cba70ea6080b631c1ca33c7e8b2bda8c3c0797d527858e234520fed`.
Supervision SHA256:`ca10df08ebbe4832d19f9687500b537159a7f64acd7b20e2405068fe40686cea`.
Browser receipt SHA256:`15fbec5eeea76c2438c393fff6c8eb535986541b7dc42e24660f597b2aac1355`.

D0 passed. D1 failed `CURRENT_FEEDBACK_FAILED` during the desktop-ready geometry
check; D2–D4/M1/M2 were not run. Four scheduled originals and one failure original
were saved and personally inspected by root. No accepted16-image result exists.

The recorded ready row has all three expected labels/copy/source predicates,
hidden empty banner and all three hit tests true. Native scrolling moved the
nonsticky navigation to y=-155.5 with bottom=-95.5. The checker rejects nav.y<0,
although the three cardiac labels are fully visible at y73.796875,71.75,499.
The failure capture confirms that the header is naturally above the viewport,
not covering the labels. Fix the check's visible-occlusion premise, retaining
strict label geometry/hit checks and ordinary scrolling; do not change product
CSS just to satisfy the harness. Independent review and a fresh run remain due.

The pending row retained six true clear predicates; the old compound error did
not persist into pending or ready. This limited observation is not full UI
acceptance. The inherited legacy figure, dense recovery copy and other product
visual obligations remain separate. Authored response fixtures are not numerical
scientific execution, human response or a requested experiment video.

Four direct children14942–14945 were reaped; eight observed descendants were
absent;8910–8912 had no listeners. All service-failure receipts absent, cleanup
and evidence failures null. Three browser resources closed. One intercepted
authored POST and its follow-up read occurred; actual mutations0. No installed
stores, patients, experiments, scientific engine or hardware were changed.

Lesson: a scrolled-out normal-flow header is not an occluding fixed header.
Visibility tests must check the actual viewport intersection, while separately
requiring target labels to remain fully visible and hit-testable.
