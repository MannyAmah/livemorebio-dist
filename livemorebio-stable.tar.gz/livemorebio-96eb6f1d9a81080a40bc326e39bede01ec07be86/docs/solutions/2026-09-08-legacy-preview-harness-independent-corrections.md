# Legacy preview browser harness: independent pre-run corrections

2026-09-08. Source-only review requested by root. **Original candidate is not
cleared for execution.** No browser, service, native model, HTTP request, test
process or runtime edit was performed by this review. The maker's original
31-pass receipt and implementation claims remain historical evidence, not a
demonstration of actual work-loop safety or real session startup.

## Reviewed identity and evidence

Read the complete acceptance plan (223 lines), implementation report (196),
new Python (309), CJS (237), tests (237), and relevant unchanged producer,
auth, legacy-control and imported ownership/listener code.

| Frozen artifact | SHA-256 |
| --- | --- |
| tools/check_legacy_preview_browser.py | 96a59c51711d3427ad57c7da77ecea0cebb7e3ce3663a4e59ad752dc586eca85 |
| tools/check_legacy_preview_browser.cjs | 0f59dedbcfc3c1dcfc4906fae1151a3dde513e6b26e063376b62556b71075825 |
| livemorebio/tests/test_legacy_preview_browser_harness.py | 2d717f595b76f0f0c99faf00448d18310ebfb3192b2652b8a020b55d50f21281 |
| implementation report | 2aec26af94b76e45249c15386232b6f09d3f2cb10d2e41d2e0e11d72746d0e3d |

All line references below identify that original candidate. No protocol, fixture
values, browser image count, numerical gate, request timeout or product source
change is proposed. Root owns implementation/run authorization and independent
grading. The review skill's source/checklist method was used; its writes, remote
fetches and auto-fixes were excluded by the explicit read-only instruction.

## Required bounded corrections

1. **P2, exact real bootstrap status (confidence 10/10).** CJS:153 accepts only
   200; actual `aegle/server.py:380–394` returns `Response(status_code=204)` with
   the HttpOnly cookie. Unchanged auth.js accepts this success. Require the actual
   exact204 contract, without fulfilling bootstrap, changing auth or admitting
   arbitrary successes. Retain independent actual modeless read and cookie
   attributes in both fresh contexts. Add a response-observer branch regression
   proving204 succeeds and noncontract responses fail before fixtures.

2. **P1, stop/settlement and late resource ownership (confidence 9/10).**
   CJS:91/219 races the work promise without canceling it. The finally block at223
   closes the current owned list while allocation at125–126 can still resolve;
   subsequent work can register resources after the cleanup pass and continue
   actions. `evaluate`, route installation, binding/init-script setup, cookies,
   body reads and allocation also lack the promised per-operation10s boundary.
   Use one fixed stopped state and existing180s work deadline, with at most10s
   remaining per awaited operation. Check before dispatch and after settlement.
   Register every resolved resource before checking stopped state, including
   late allocations, then close the exact late resource under the existing
   per-resource cleanup bound. Drain or explicitly classify unresolved work and
   observer promises; never claim SETTLED merely because Promise.race returned.
   Keep the original2s held-read deadline, including its screenshot. Exercise
   actual `run`/attach/route branches with authored pending allocation/read
   promises: expiry must prohibit later clicks/POSTs and retain individual
   late page/context/browser cleanup receipts. Do not build a generic scheduler.

3. **P2, fixed delivery counts (confidence 10/10).** CJS:78–80 returns C/UNKNOWN
   repeatedly after consuming the intended follow-up; D1–M2 never assert exactly
   one current GET per explicit action. CJS:139–140 permits unlimited genome
   replies while historyFixture is true, although only one was approved. Add
   small fixed per-phase read counters and an exact one-use genome budget.
   Distinguish automatic page-entry reads, Back refresh and explicit Refresh from
   each preview's one follow-up. Preserve exactly four intercepted POSTs and
   zero upstream mutations. Add actual route/schedule branch regressions for
   duplicate GET, duplicate genome request, wrong phase and missing expected
   reads. No new request class, delayed retry or relaxed count is authorized.

4. **P2, parent completion admission (confidence 10/10).** Python:272–277 accepts
   Node exit0 without opening `browser-result.json`. Require that fixed private
   regular owner-only bounded file, then validate the exact schema/source/pins,
   completed case outcomes, four POSTs/zero upstream mutations, both real-auth
   baselines, required12 image names/hash/size evidence and exact per-resource
   cleanup outcome before reporting supervisor success. Validate files read-only;
   never repair/regenerate evidence. Missing, corrupt or incomplete receipts are
   evidence failure even with exit0. Preserve nonzero primary failures separately.
   Tests belong in actual parent result-admission branches, with authored files
   and child handles, not a second application response-validation framework.

5. **P2, explicit failure ledger (confidence 10/10).** CJS:95 records only
   `completed[]`; failed and remaining cases have no explicit statuses. Initialize
   the fixed D0–M2 list as NOT_RUN, mark current failure and completed success,
   retaining only fixed stage/error names and bounded safe metadata. Preserve
   cleanup/evidence failure separately from the initial failure. A failure after
   D1 must retain D0/D1 PASS, the exact current FAIL and every later NOT_RUN,
   without attempting their screenshots or actions. No scenario multiplication.

## Pins and limits, without new scope

The package source is checked before/after the run; the harness and imported
helper files are presently only hashed before it. Add the same final read-only
comparison for already-declared local pins and compare receipt pins to the parent
capture. This is a small completion check, not a new runtime attestation system,
dependency inventory or claim that on-disk hashes prove loaded native images.

The maker report's statements that all actions have10s bounds and observers are
drained are stronger than the original code proves. Preserve that report and
append correction history rather than overwriting its original31-pass result.
The old tests cover helpers but not the full timeout/late-allocation sequence.
Root's repeat is separate from this source-only review.

The correction write set stays the same three new harness/test files plus an
append-only review receipt. Existing source, browser controls, actual bootstrap,
fixture literals and all six scientific programs remain unchanged. Author
red-first tests only for the actual work/route/parent branches above, freeze new
hashes and request independent re-review before any actual once-only run.
