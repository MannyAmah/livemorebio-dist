# Bootstrap graph shape must precede authority selection

2026-09-08. Bounded correction to the approved bootstrap proposal, not a new
registry design. Root read the frozen implementation, caller transactions,
original plan and tests. Independent UI review reproduced the defect; a separate
release reviewer reviewed the smallest correction contract before code.

## Defects and preservation

Removing identity/proof/binding rows while retaining the authenticated bootstrap
events/attempts allows the current implementation to take its legacy-audit
fallback. A second malformed singleton row is also ignored by `WHERE singleton=1`.
These are malformed-storage integrity failures, not unauthenticated HTTP attacks.
The prior 355 passing tests do not waive either finding.

Retain all five existing tables, independent key, data-key proof, historical
witnesses, authority tokens, audit formats and current numerical/clinical rules.
No schema migration, new secret, automatic repair, geometry, model or network
change. All destructive test operations affect authored private test stores only.

## Reviewed implementation contract

Add one private `RegistryBootstrap._preflight_shape(connection) -> None`:

1. Acquire/reuse the existing writer transaction. Inspect each of the three
   singleton tables with `SELECT singleton ... LIMIT 2` (without filtering to 1).
   Permit zero or one row; any present value must be integer 1. Reject duplicates
   or misplaced singleton rows before key creation or record access.
2. Inspect all five populations, counting only bounded metadata subqueries:
   at most 513 events, 257 attempts and 257 pending attempts. Retain 512 events,
   256 attempts and 512 charged event-plus-pending slots. No ciphertext loading
   or new cryptographic validator in this helper.
3. If identity is absent, every other bootstrap table must be empty. Require
   proof and binding both absent or both present. Require events and attempts
   both empty or both nonempty. A proof/binding pair requires identity and
   nonempty event/attempt history.
4. Identity-only and structurally coherent failed/pending histories remain
   provisional. A proof/binding pair before SUCCESS is allowed structurally
   because `establish -> finish` constructs this pair inside one transaction.
   Existing authenticated `_ledger` checks links and outcomes; existing
   `assert_authority` still requires exactly one complete linked SUCCESS.
5. Invoke before `_key(create=True)` in `ensure_identity`, before proof lookup
   and legacy fallback in `assert_authority`, and before decrypt in `_ledger`.
   Never delete, repair, adopt or append ordinary audit to malformed graph state.
   Surface fixed `RegistryBootstrapError`, not raw database details.

The helper is structural admission, not data-key authority. It does not detect
arbitrary rollback or deletion of all historical local metadata: external
anti-rollback authority was not part of this local contract. Supported reference
cohort writer integration remains a separate open correction.

## Red-first tests and independent gate

- Reopen and already-open access after orphaning event/attempt history must
  fail before clinical decrypt and ordinary audit append; preserve every record
  and remaining metadata byte.
- Duplicate and misplaced identity/proof/binding singleton rows fail through
  authority admission and direct helper entry points without key replacement.
- Independently orphan events or attempts and a paired proof with empty history
  fail structurally. Existing no-proof successful history must still fail.
- Preserve identity-only, valid failed/pending recovery, wrong-first/correct-next,
  authentic legacy normal-audit opens, explicit adoption, successful marked
  opens, and the same-transaction proof-pair-before-RESULT construction.
- Exercise both quotas and SQL failure with fixed exceptions. Run the original
  355-case matrix plus new regressions with private stores and network refusal.

Root approves this bounded contract for tests and implementation. A reviewer
other than the maker must inspect and rerun the corrected packet before it is
accepted. No full-product, clinical, Atlas or six-program acceptance follows.

## Frozen maker evidence

Initial 44-case packet: **30 failed / 14 passed in 1.22 s**, private root
`livemore-research-review-ruuoa4qx`. It reproduced orphan-history legacy fallback,
ignored duplicate singleton rows, incomplete direct-helper checks and direct
completion of malformed history. The between-transactions case already stopped
on an authority-token mismatch, but only after falling back to the wrong authority;
it now fails at graph shape before that fallback. Its genuine BEGIN remains
pending, not fabricated as completed.

After the runtime fix the 44 new plus original 62 tests passed: **106 passed in
13.83 s**, private root `livemore-research-review-y1nfc92j`. Six additional metadata
boundary/error cases and key-access refusal were then added. Final complete
preservation matrix: **405 passed, 1 existing warning, 20.20 s**, private root
`livemore-research-review-etrml7x5`. This is the original 355-case matrix plus
50 new shape cases; no existing test was weakened or edited by this correction.

Main-process socket/DNS refusal was installed before the final matrix. Tests use
authored private encrypted stores; the original bootstrap suite includes its
bounded harmless child-process races. No HTTP, browser, native scientific worker,
operational registry, physical device or production key was used. New tests
assert retained clinical ciphertext, normal audit/reservation rows, remaining
bootstrap graph and key bytes; they do not assume SQLite file-byte equality.

| Frozen file | SHA-256 |
| --- | --- |
| `livemorebio/aegle/registry_bootstrap.py` | `83d00d6ac21515bc6925e09e9f70c93489c3a77fca1a3a44d01fae27e1714455` |
| `livemorebio/tests/test_registry_bootstrap_shape.py` | `57cd7c2612295275e5bbcaecb796c14bb9fe5ebbeb7e35ae889f22a2cc4afd40` |

The original audit and subjects modules remain at `f8d5f02fac150e9c89506b7108db8a823094ff4360279a1c8416f895fbb55f5b`
and `af46597193a4453e86b2a6a115100c76ce6b6812b9d7a198fabed350a34ba0c4` respectively.
This maker packet is frozen for independent review, not accepted yet.

Lesson: an authentic fallback must also prove that its prerequisite absence is
real. Querying only the expected singleton can hide inconsistent surrounding
metadata. Check bounded shape first, authenticate the complete retained graph
second, and keep both checks inside each actual writer transaction. This local
solutions entry records the lesson without claiming an unavailable CE run.

## Independent correction review

An independent reviewer read the complete correction plan, all 50 new tests,
the changed helper/callers and the preserved authority/establishment paths.
Runtime `83d00d6a…` and test `57cd7c26…` matched the frozen hashes above;
subjects/audit remained unchanged. A fresh private technical environment with
main-process socket/DNS refusal repeated the full matrix: **405 passed, one
existing Starlette warning, 19.10s**. No operational stores, HTTP, browser,
native scientific execution or source edits were involved.

Separately repeating the original orphan-history and duplicate-identity probes
now rejects both constructor reopen and retained-object access with fixed
`REGISTRY_BOOTSTRAP_INVALID`. Original record ciphertext, normal audit and key
bytes remain unchanged. Shape admission precedes key/decrypt/fallback, while
identity-only/failed/pending histories, atomic pair-before-RESULT establishment,
reserved quotas and existing-audit adoption remain covered and passing.

No actionable blocker remains in this bounded correction. This clearance does
not close the separate reference-cohort writer integration, committed-source
transition work, external anti-rollback limitation or whole-product acceptance.
