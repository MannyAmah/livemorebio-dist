# Molecular embedded layout and present-residue correction

2026-09-09. Root is the maker of this increment. Independent grading and fresh
browser acceptance are still required. The original WoWI5H failure is preserved.
No active ordinary Biology viewer, vendor distribution or biological engine changed.

The independent pre-code review accepted the written correction with a concrete
portrait amendment. Root read the pinned upstream sources: responsive controls
remain inside the stage, but portrait regions require97+361px. Owned-stage
min-height700px provides room for at least240px of coordinates. The external
dialog remains scrollable for the original controls and provenance.

## Product changes and RED/GREEN evidence

Exactly three product/test files changed in this increment:

| File | SHA256 |
|---|---|
| `livemorebio/aegle/console/lib/molecular_inspector.js` | `9ec1baea5dbcc75baaba871e57059c633b643433ae880fe3c35c95c38dfdaef2` |
| `livemorebio/aegle/console/lib/molecular_inspector.css` | `22cdc2fcf65dd25c4cad24d19eeada013c174013cd3ffe1f81c3171786dc6695` |
| `livemorebio/tests/test_molecular_inspector_ui.py` | `5a591b9688e14dc00adae0004fa4c828a9b6765f4d3f8b8a78568af6b0112197` |

Five new cases failed before implementation (f0eb00,0.55s, privateh_u1b27e):
three frozen absent/partial/populated spec shapes, owned-button CSS isolation
and portrait breakpoint/arithmetic. After the narrow change, the same five
passed (3a69b8,0.49s, private7vi5f0n3). No assertion was relaxed.

Full seven-file related preservation packet:153 passed in17.22s, session84780,
completiona0f41f, privateuhcn0zt6,152 authored Node children, unexpected I/O0.
This includes the previous95 controller/reader cases and ordinary/frozen/fixed
consumer checks. It is not whole-product, actual graphics or biological validation.

Controller changes copy only spec/layout/initial, preserving sibling function,
array and object identities, then set controlsDisplay reactive. CSS now styles
only the inspector-owned Close/Retry buttons; upstream buttons are untouched.
The portrait min-height matches upstream's portrait/max-width1000px condition.
No loader, coordinate, source identity, security or physiological change occurred.

## Fresh private browser-check implementation, not yet executed

New0700 root `/private/tmp/livemore-molecular-layout-browser.LygJpf`. Reused
original page, Python supervisor and inert wrapper byte-for-byte. No `run`
directory exists yet. CJS keeps the same four stages,11 required captures,
six literal structures, human INS unavailable distinction, fixed local origin,
request/byte limits, process ownership and cleanup deadlines.

New present-residue selection is scoped to one visible sequence wrapper, checks
two distinct indices/labels before clicks, and retains their zero-based wrapper
convention without claiming PDB numbering. Actual history and finite-distance
assertions remain. Initial open also requires a200×240px minimum canvas and
unobscured status/scope center points. Original screenshots still need visual review.

Passive requestfinished/requestfailed callbacks, stage starts, per-resource
retirement starts and final cleanup use the same Node monotonic origin. Terminal
rows are capped128 and cleanup marks16; overflow fails. No response.finished
wait, refetch, transport modification or error waiver exists. A canceled request
still prevents a pass regardless of rendering or cleanup timing.

New harness RED:10 failed/36 preserved passes (1af217,182.850ms). After helper
implementation:46 Node passes187.588ms plus6 Python passes0.021s, completion
d16fd4 exit0, no actual browser. The previously reviewed42 checks remain.

| Private file | SHA256 |
|---|---|
| check.cjs | `f7b477d44cf8ddd8fecff855d18a9653894369528f15310b9652d201da71f4ce` |
| check.py | `1dd4a2c22483f01c54ba45a53b9812d03f0c35bfe4b0dd80de9181903ac0a168` |
| test-check.cjs | `80925439fcda7047f39ec1bb44c3c613f1209d434b9569112d5b16bd050ce728` |
| inputs.json | `6498c3f95ddf53a635e57badaebb1eb7d9ce695cfaedb38edb9d318e4b46bd9a` |

`harness-pins.json` binds all eight private inputs; `inputs.json` binds22
runtime/public-source inputs. Only the intended controller/CSS bytes and new
private page paths differ from the consumed parent map. The bundle and public
coordinates are unchanged. Independent review must check the exact source and
repeat the52 inert checks before a separate actual browser decision.

Inert repeat: pinned Python3.11 `-B` on the private `run-inert.py`. Prospective
actual command is that same pinned interpreter with `-B` on private `check.py
--run-once`; it is not authorized by this maker report.

Lesson captured under the investigation workflow: a nonzero WebGL canvas does
not establish usable embedded controls. Check upstream layout defaults and
reserved portrait regions, then test actual visibility. Sequence entries without
deposited coordinates must never be used to fabricate selectable atoms.

## Independent source and offline grade

2026-09-09, release_redteam: **CLEAR for the bounded product delta and private
harness, not rendered acceptance**. Read the complete updated correction plan,
this maker report, all three product/test files and all fresh private CJS,
Python, page, test, refusal-wrapper and input-map files. The review checklist's
scope, async ownership, frontend and failure-preservation checks were applied;
no remote review, automatic fix, browser or native process was authorized.

The JS copies exactly spec/layout/initial and changes only controlsDisplay;
frozen positive cases preserve sibling references and settings. The CSS leaves
upstream controls alone and adds the exact portrait/max-width1000 minimum.
Independently reversing only those two approved textual deltas in memory
reproduced original JS `00266652ee37295650a7012676aafb2e91bfeaf03289f804937fb4b1e909c0aa`
and CSS `edf18be340be74c770dbb1e4d4f51876a24a37870c466725914ea972dcee948c`
hashes (completion `5fc5b9`); neither source file was rewritten.

Exact seven-file product repeat: **153 passed in 18.70 s**, session 22242,
completion `c5c5ac`, private review root `3pyyv_ga`, unexpected I/O 0,
152 authored Node children, Git refusals 0. The inspected command is retained
at `/private/tmp/livemore-molecular-layout-browser.LygJpf/repeat-product-offline.sh`,
SHA256 `f0ff1232205c43a797b1842d84034e017186d0bb4ebf975b934ff117f75c055e`.
Run with `/bin/sh` from the fixed worktree; it preserves the 45 s refusal wrapper
and exact seven-file selection. This extra offline review file is not a browser
input or a change to the already frozen private harness map.

Exact private repeat: **46 Node cases passed in 187.300833 ms and 6 Python
cases passed in 0.021 s**, completion `a4aeb2`, exit 0. Invocation:

```text
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-molecular-layout-browser.LygJpf/run-inert.py
```

These tests retain the real harness functions with authored resources and
network/child refusal; they do not launch the actual browser or HTTP server.
The present selector has one visible wrapper, exact retained distinct indices
and labels, then still requires actual history and a finite measurement.
Passive terminal callbacks and stage/retirement marks share one clock; overflow
fails and canceled requests still prohibit PASS. No response completion wait,
refetch, native/source substitution or cleanup-policy relaxation was introduced.

Independent read-only pin check `1cb9ff` verified all 22 input and 8 harness
rows against exact integer metadata and SHA256, including stable before/after
stats. Only expected input rows 0/1 (new private page paths) and 2/4 (approved
controller/CSS bytes) differ from the consumed parent map. The Python supervisor,
Python tests, HTML, page module and inert wrapper are byte-identical to their
originals. The new CJS diff was read in full. `harness-pins.json` SHA256 is
`a7036010c1ad955d4acce018b8484151263cb6877205fc2f17fada84ac07d5d3`.
No actual `run` directory existed at this independent checkpoint.

No actionable implementation blocker was found. Actual portrait canvas/control
usability, all 11 original images, deposited-source selection and request-terminal
ordering remain the separately authorized browser run's obligations. The original
WoWI5H failure, unknown ERR_ABORTED cause, and broader product/scientific gates
are not waived by this source-only grade. All tests have stopped for handoff.
