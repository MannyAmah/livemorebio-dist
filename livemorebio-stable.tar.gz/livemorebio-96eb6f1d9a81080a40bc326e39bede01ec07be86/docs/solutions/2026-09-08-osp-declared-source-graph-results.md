# OSP source graph: complete declared links, unresolved numerical admission

2026-09-08. This is static source evidence, **not an insulin experiment, model
repair or human validation**. The original Stage B numerical result remains FAILED.

After the independently reviewed nonfinite-literal amendment, root authorized
one new static invocation. It completed with `STATIC_GRAPH_COMPLETE`,
`model_admission=false`, and `numeric_input_completeness=false`. No source
expression, native worker, solver, physiological advance or operational product
store was invoked. The process-local gate closed in finally and the on-disk gate
stayed false. The original source, three domain ledgers, original failed static
receipt and old numerical code retained their exact hashes.

## Retained artifact

Report:
`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-osp-static-review-4s3eumay/osp-source-admission-v1-3819ef03ab124bc7a9bd220255755526/report.json`.

- Bytes:31,567,123 (within the unchanged128MiB output bound).
- File SHA256:`7bf6f4a9c125d26338bd08d39ae1b9656a0d125fa18bccd3dc79a8dfb033fac6`.
- Canonical content SHA256:`d78c4e8fa3c8112495b4196a28a7e77620e59752a597367c6cdf225d5cbf0b54`.
- Original XML:7,477,881 bytes,
  `e78bb23d39ce7138f46bb876a54b43becb79bbf833e50c0cd7006f2a80eac3cb`.
- Tool:`f6b5d2daf5d90c5b6949ae35f2089fd75a12b2b935e060b7ac96ce8ead321821`.
- Policy:`livemore.osp-nonfinite-literal-policy.v1`.

The earlier453-byte finite-literal FAILED receipt remains untouched at the
location in the [nonfinite amendment](2026-09-08-osp-source-nonfinite-static-amendment.md).
The new classification does not rewrite that earlier result or its contract.

## Actual structural inventory

There are28,683 graph nodes,64,564 typed edge occurrences and104 independent
root-role traversals:77 downstream possible-influence and27 reverse initializer
dependency traversals. They retain54 initializer-role records,27 negative-state
roots,15 restoration roots and8 context roots. All reviewed direct-definition,
table, event, solver, initializer and XML-node inventory pins matched.

| Edge kind | Count |
|---|---:|
| Declared formula references | 50,446 |
| Parameter formula binding | 8,536 |
| State RHS formula | 3,917 |
| Observer formula | 1,475 |
| Event condition | 33 |
| Event → assignment | 39 |
| Assignment formula | 39 |
| Assignment target | 39 |
| Initial formula | 27 |
| Table binding | 3 |
| Offset binding | 3 |
| Solver binding | 7 |

The56 unresolved P declarations retain their exact string `NaN`, source metadata
and98 direct reference occurrences. None is numerically coerced or excluded.
All27 reverse initializer lists are explicitly present and empty for these56
declarations. That establishes only absence from the chosen declared initializer
dependency closures; it does **not** establish irrelevance to downstream dynamics,
event behavior, other outputs or biological interpretation.

Aggregate retained visited-root/node pairs:488,359. Aggregate examined-root/edge
pairs:792,972. Both are within original fixed budgets. Seventeen conditional
dimensional/declared-convention assertions remain non-admitting.

Root independently read the retained JSON with a separate standard-library
inspection script, checked canonical digest, unique node keys, every edge endpoint,
all root reachable-node counts/digests, unresolved-node lists, and original-file
preservation. A different reviewer must still verify actual source-to-report edge
accounting and traversal evidence before treating this as independently graded
static completeness. No generator rerun is required for that read-only review.

## What remains unresolved

The report retains EVENT_SEMANTICS_UNVERIFIED, TABLE_SEMANTICS_UNVERIFIED,
TIME_UNIT_UNVERIFIED and SOURCE_NONFINITE_LITERAL_UNRESOLVED. A structurally
complete graph does not resolve receptor restoration units, glycogen/pool domains,
publisher NaN intent, numerical convergence, individual insulin exposure or
independent physical validation. No tolerance, dose, kinetic parameter or source
equation was changed. Exogenous insulin and all five named botanical programs
remain required, unqualified as whole-person experiments; requested videos0/6.

**Lesson:** preserve a source's inconvenient declarations and trace them explicitly.
Structural evidence can improve the next scientific correction without granting
the model permission to produce a purported validated human response.
