# OSP private once-only launcher: implementation review packet

2026-09-09. Maker report by `release_redteam`, implementing only the root-approved
[180-line plan plus decision](2026-09-09-osp-once-only-native-technical-packet-plan.md).
No native packet, R, CLR, vmmap, service, browser or scientific model was run.
No supervisor, collector, pure fixture, inventory or historical evidence changed.
Independent review and a separate recorded actual authorization remain required.

## Frozen files and actual red/green evidence

Private0700 root: `/private/tmp/livemore-osp-native-once.CA533x`.
All its files are0600. No real authorization, once marker, completion, home,
tmp, cache or native packet directory has been created there.

| File | Lines | SHA256 |
|---|---:|---|
| `run_packet_once.py` |231| `bb03511e1f4a89bb878aa807083869ebd75f692c7a1cc266b5c8a45397eb9de5` |
| `test_packet_once.py` |319| `771e45489b083f08f8918dc8ca0d3901a361f65f715d78e2c76d9baae1d4ec1c` |
| `run_packet_once.before.py` |33| `e4c76282f30dda2494018f66c8fb562ec810a5942157f26cc97d33993eca99ce` |
| `test_packet_once.initial.py` |246| `4cc0526f5f4375daf71288e6598a1e140b4bce170befb649e662adaeece4429b` |
| `repeat-offline.sh` |19| `9db9a4c4bddae9a1fd63b9baf54c664a029cd47aba6a0a66799d7f9a08334b44` |
| `offline-results.json` |—| `9f7ec02bfdd0acf5e50fa76048d2b6d0aecb522a6a2e7af775e409e9b8a2e948` |
| `reviewed-delta.diff` |—| `ea4710e9b65e5cc357e911141c4933a92ae17cff52e352bed2de98cc887b3048` |

Original RED:22 failed/16 passed/one warning in2.23s, session29941, completion
`a30ed1`, private review suffix`xxwdg7zn`, unexpected I/O0. This was a constants
plus NotImplemented stub, not a scientific execution. The16 negatives already
refuse under that stub; they are not prior implementation preservation evidence.
The joined test thread's missing implementation caused the one warning. No
assertion was weakened. Initial implementation:38 passed in0.23s, `de5beb`.

Three added failed-result-link tests then failed while40 passed (`69c3e4`):
admission rejected the failed/corrupt/absent raw result before retaining its
known returned root/hash. The correction records the confined root before read
and the available raw hash before validation, without rewriting any raw result.
Two additional tests exercise only authored module bytes and cached-module
refusal. That additive test packet yielded43 passed in0.31s (`66c4de`).

Final source review identified a second evidence issue: final pin checking was
after successful result admission only. Two regressions failed/43 passed in0.29s
(`9ca492`). The existing final check now runs during finalization on every
post-marker outcome, with separate `source_preservation` and fixed secondary
`FINAL_IDENTITY_CHANGED` evidence; it does not mask a packet's primary failure.
Final result: **45 passed in0.27s**, chunk`aac372`, private suffix`i8pwikap`,
unexpected I/O0. Initial test bytes remain an exact prefix and are separately
retained. The JSON receipt is a clearly labelled summary of tool transcripts,
not an invented disk console log or native result.

## Small boundary actually implemented

The231-line launcher includes fixed pins/limits, strict bounded file/JSON reads,
exclusive once/control writes, the isolated module binding, final packet
admission and entrypoint. It has no configurable runtime/fixture/argv CLI.
Unaliased regular input checks use before/open/after identity and O_NOFOLLOW;
control files use0600 O_CREAT|O_EXCL|O_NOFOLLOW plus flush/fsync. A partial marker
is consumed. The concurrency test uses two threads and the real exclusive-file
primitive, not subprocesses; it is not a new actual cross-process OS test.

Input hashes, OS result, canonical authorization, executable path and private
environment are checked before the marker/import. The verified pure/supervisor
bytes are compiled under their original file identities into an explicitly
empty-path `tools` namespace; no project initializer or cached project module is
executed. This changes no supervisor function, code byte, fixture, policy or
native behavior. Both source gates must initially beFalse; only this private
authorized call sets them in memory and restores them in `finally`. An unexpected
preexisting gate is refused, not claimed as this launcher's authorization.

The fixed `run_packet()` still owns all17 case attempts/16 prescribed Run calls,
first-failure stop, exact oracles, source/runtime admission and owned cleanup.
The wrapper accepts only exact returned/on-disk equality, the pinned identity,
all17 ordered matches, unchanged limits and false model admission/unresolved
flags. Known failed roots/raw hashes are retained; a thrown call with no returned
root does not invent one or claim that no tree was created. Unknown exceptions
use fixed phase codes, never arbitrary exception text.

The600s completion clock starts immediately before `run_packet`, covering its
inventory/worker work, raw result write, wrapper admission, final pin recheck and
completion write. Interpreter/import/authorization preparation precedes that
existing packet scope. There is no extra worker time or watchdog. Check elapsed
again after the completion write; a late or failed write produces nonzero exit
while preserving any already written receipt. Thus completion receipts explicitly
require exit0 and subsequent independent evidence review. Blocked filesystem or
scheduler behavior is not presented as a hard timing guarantee.

Control objects are64KiB each; raw packet result remains16MiB. JSON rejects
duplicate/nonfinite values with bounded depth32/one-million visited values.
These are private readback guards, not a changed producer/observation schema.
No control file is added inside the supervisor's64MiB packet tree.

## Exact independent offline repeat

From `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```bash
/bin/sh /private/tmp/livemore-osp-native-once.CA533x/repeat-offline.sh
```

The frozen19-line script uses the existing `prepare_review_environment`, an
allowlisted fresh private HOME/TMPDIR/cache, no pytest plugins/cache, and a45s
alarm. It initializes stdlib ctypes before installing native-load refusal;
then refuses socket creation/DNS, urllib, subprocess/fork/exec/spawn and further
ctypes.dlopen. It selects only this private45-case test file. Mounted packet
results are authored JSON; no real supervisor or native packet is invoked.

## Fully resolved proposed actual command — NOT AUTHORIZED

First, independent review must clear this packet. Only a subsequent explicit
root decision may create the fresh `authorization.json` here. Its exact object
is `OSP_NATIVE_ONCE_AUTH_V1`, authorized booleanTrue, model_admission booleanFalse,
the fixed ordered `cases`, exact Run vector, protocol SHA and exact `LIMITS`
object from the plan/source. `identity` has exactly seven SHA fields:
`launcher_sha256`=`bb03511e1f4a89bb878aa807083869ebd75f692c7a1cc266b5c8a45397eb9de5`,
plus `supervisor_sha256`, `collector_sha256`, `pure_sha256`, `inventory_sha256`,
`os_result_sha256`, `python_sha256` with the six exact plan/source pins. Canonical
object equality rejects unknown fields, changed counts and bool/int substitutes.
Do not copy an OS authorization, reset any old marker or generate this authority
as part of a test. There is currently no actual authority in the fresh root.

```bash
env -i PATH=/usr/bin:/bin LANG=C LC_ALL=C PYTHONDONTWRITEBYTECODE=1 \
 HOME=/private/tmp/livemore-osp-native-once.CA533x/home \
 TMPDIR=/private/tmp/livemore-osp-native-once.CA533x/tmp \
 XDG_CACHE_HOME=/private/tmp/livemore-osp-native-once.CA533x/cache \
 /Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -I -B - <<'PY'
import hashlib,os,stat
from pathlib import Path
os.umask(0o077)
path=Path('/private/tmp/livemore-osp-native-once.CA533x/run_packet_once.py')
fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
with os.fdopen(fd,'rb') as stream:
 info=os.fstat(stream.fileno())
 if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:raise RuntimeError('LAUNCHER_IDENTITY')
 raw=stream.read(1024*1024+1)
if len(raw)>1024*1024 or hashlib.sha256(raw).hexdigest()!='bb03511e1f4a89bb878aa807083869ebd75f692c7a1cc266b5c8a45397eb9de5':
 raise RuntimeError('LAUNCHER_CHANGED')
exec(compile(raw,str(path),'exec'),{'__name__':'__main__','__file__':str(path)})
PY
```

The source/R/pure/V2 and actual OS result pins were rehashed after implementation
and remain exactly those in the approved plan. No actual interpreter/runtime
admission, R parsing, startup command/hook, CLR/image topology or scientific
result is inferred from these45 tests. Native source attestation remains
UNVERIFIED, historical runtime UNKNOWN, model admissionFalse. No actual
S01–S17 or old numerical packet retry is authorized by this report.

Lesson: failure-path evidence needs the same terminal pin checks and raw links
as success. Retain the original failure and separate completion/preservation
uncertainty; never turn a late-written receipt into terminal success by itself.
