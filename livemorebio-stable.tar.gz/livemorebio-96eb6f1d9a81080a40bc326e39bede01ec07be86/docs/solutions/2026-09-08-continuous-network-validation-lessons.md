# Continuous execution network validation: evidence, not test counts

Status: engineering work in progress. This record does not qualify a human model,
device, clinical endpoint or full release. Applies to R04/R29/R31/R47/R48.

## Decisions and observed defects

- Device wire sequence and engine frame index are independent clocks/counters.
  Device sequence starts at zero and survives successive execution bindings;
  the native execution frame starts at one. Admission binds both exact fields
  without requiring them to be numerically equal.
- A same-host virtual frame must pass both UTC age and producer-monotonic age.
  A recent envelope timestamp cannot refresh an old numerical frame.
- A delivery outbox may truthfully be pending while journal admission, signed
  forwarding and acknowledgment are in flight. Requiring it to be empty on
  every sampled status read is not a valid continuous-delivery test.
- A new acknowledgment after a stalled monitoring request must not reset away
  the observation gap. Check elapsed progress before updating the deadline.
  This is bounded observed progress, not a measured per-frame latency claim.
- A successful timed loop is insufficient: pause the producer, drain the exact
  committed tail, require final frame/hash/ACK equality and an empty outbox,
  then stop the consumer and producer. Check the drain deadline before accepting
  its completion, including time spent in blocking reads.
- External interruption is a failed check. Preserve evidence and independently
  attempt to stop only IDs created by that check. Bound cleanup calls and do
  not let a second interrupt or cleanup error hide the first failure.
- Validate raw configured absolute paths before initializing any shared
  gateway. Trimming a path for validation while another component opens the raw
  value can create a different, relative file. Use the same canonical value at
  validation and opening. The technical reproduction was moved recoverably to
  a private temporary directory, not deleted.

## Evidence and remaining checks

`tools/check_continuous_network.py` uses actual HTTP between three independent
review processes and engine-authored native frames. It writes private exclusive
reports, records source identity and its own source hash, and does not read
credentials into console output. Only fresh explicit review stores are admitted.

The original attempt stopped at 20 checked frames and is retained as failed.
The subsequent actual SIGTERM exercise produced `accepted=false`, failure type
`NetworkCheckInterrupted`, and cleanup results `consumer_stop=stopped` and
`producer_stop=stopped`; authenticated follow-up reads independently confirmed
both states. Eight harness regressions pass. Independent reviewer cleared the
bounded harness before the next timed attempt.

The subsequent 1,800-second run completed in **1,802.429 seconds** with
**1,730 checked frames and 1,730 acknowledgments**, exact final tail drained,
no pending outbox and unchanged physical observations. Independent subsequent
HTTP reads confirmed producer and consumer `stopped`; native time ended at
345.9999999999889 minutes under the explicitly declared 12× numerical/wall
time policy, not 346 minutes of observed human time. The result is stored in
the private review root `livemore-research-review-336k8ef0` as
`continuous-network-31e4a87202dd4ed0885db1a63dd8dbf4.json`.
The frozen runtime source was
`1408cabb609c48ee82e8a5ceb1ca433945e62935d3205abf56e8fd2b1eff3c02`;
the independently reviewed harness source was
`20988d64d3583a37802f3e2a4c7ab8b12dc1c4ce89f859e2a18bdbcbabd8e12b`.
Read-only database aggregates confirmed 1,730 persisted frames (3,738,134
encrypted frame bytes), one execution (3,743,562 payload bytes including its
frames), and one session (2,718 payload bytes). Total files in the private
root were 24,244,702 bytes at report time, below the per-store 256 MiB payload
quota. This workload did not reach/exercise quota exhaustion; separate quota
unit tests retain that boundary check. This record does not replace either
earlier failed/interrupted attempt.
The manual frozen-source network snapshot is not a wheel-install acceptance
test and predates later UI/client refinements; final release tests must bind
the final candidate build. Physical observations must remain unchanged throughout.

## Browser lifecycle defect is independent of the soak result

The later current-source browser test delivered two acknowledged frames, then
Pause LIFE received 409 because background receipt/status writes changed the
same revision required for user controls. Both created records were stopped,
and failure screenshots were preserved. This is a real usability defect despite
the separate successful transport soak. See the written
`2026-09-08-continuous-control-revision-correction.md` for the separate durable
control revision, no automatic command retry, and stale-worker failure fences.

## Do not forget

The native numerical probe is a metabolic plasma-glucose projection, not a
physical ISF assay, an ECG, or a bench-qualified virtual replica of every Rev B
channel. Full native source convergence, sensor transfer functions, independently
measured validation and the six requested experiment programs remain separate
acceptance requirements. There is no automatic live-twin self-calibration.
