# Pinned models, immutable installs and coherent biology views

Date: 2026-09-05. Compound Engineering/gbrain were unavailable in this session;
this local lesson captures the reviewed decisions without claiming an MCP run.

## Source availability is not an execution contract

A readily downloadable human metabolic reconstruction may still have commercial
restrictions, a permissive medium, an unsuitable objective or unsupported biological
coupling. Human-GEM 2.0.0 is pinned with its source licence and annotations. The
reviewed Recon3D source embeds CC-BY-NC-ND; keep it restricted until rights are
resolved. Never revive old gene-to-organ multipliers merely because model files exist.

The release gate executes a bounded reference-network protocol with explicit medium,
objective, GPR-aware complete knockout, numerical controls and diagnostic tolerances.
It does not self-grade patient equivalence. FBA is steady state, not a dynamic
human response or evidence that an organ label has executable physiology.

## A pinned installer can still import the wrong source

`python -m` normally includes the caller's directory. A correct commit archive and
venv can therefore run an older local checkout's model installer/CLI. Isolate
managed entrypoints with `-I -B`; launch child services from their own package root.
Reuse checks must also disable pytest caches/bytecode, otherwise a successful test
changes the release digest and makes the next same-commit install fail integrity.
Regressions cover the exact launcher arguments and base-to-full activation gate.

## Identity and biology must change together

Switching to a note/reference preview must clear the persistent active pointer as
well as the memory projection, without deleting the admitted record. Construct and
validate the replacement first. Reject unknown base names; retain documented aliases.
Otherwise a typo silently becomes T2D and durably deactivates a governed subject.

Cell views must not fetch a cardiac trace from whichever subject happens to be
active after the organ was opened. The read APIs supply an opaque context token
bound to the captured instance and full sampled state; the UI rejects mismatches,
invalidates stale modals and refreshes context before resuming hidden-tab playback.
A before/after check also detects in-place updates during Biology projection.
This is coherence protection, not proof that the underlying model is clinically valid.

## Read protection and unavailable function are first-class

Mutation authorization alone does not protect PHI-like Biology GET responses.
Require operator authorization and no-store on active-context reads. Keep absent
renal/neural/adipose execution visibly unavailable rather than deriving a normal/
impaired label from glucose. Reference cell diagrams must not animate uncomputed
transport or contraction. Show actual model parameters, units and evidence class.

## Verification is a workflow, not a green badge

Retain immutable runs and exact preparation inputs. A simplified form must disclose
heterogeneous saved media before an exact rerun; its displayed table and submitted
conditions must use the same state. Serialize cursor transitions before awaits.
Real video is native interaction capture with input, computation, diagnostics and
analysis, not screenshot animation. Stop only owned review child processes, including
SSE connections that outlive graceful shutdown. Keep current-user stores untouched.

## Test execution must not become operational history

The literal published installer exposed audit/key writes into its new runtime
directory even though no experiment was intentionally seeded. Verification now
uses a separate retained owner-only directory with all mutable paths and local
credentials replaced. Only the already verified reference-model cache is shared.
Fresh and reused releases use the same isolation helper, with bytecode and pytest
cache writes disabled. Test failure retains the private verification directory for
diagnosis and does not activate a failed release. A blank workspace must be checked
before starting services, not inferred from an empty screen.

## Concurrent SQLite sidecars are not stable files

The published-install test also exposed a journal unlink between filesystem
preflight calls. Inspect one `lstat` snapshot rather than mixing `exists`, `is_file`
and several `stat` calls. APFS can return an owned regular journal inode with zero
links while unlink completes; permit that only for transient SQLite sidecars, not
the primary database. Keep symlink, hardlink, foreign-owner and nonregular-file
rejections. Independent-store concurrent saves and deterministic unsafe-path tests
cover the distinction. Permission fixtures must explicitly `chmod` their intended
mode: `mkdir(mode=0o755)` alone is not an insecure directory under `umask 077`.

## CI contexts depend on evaluation phase

GitHub's runner context is unavailable in job-level `env`. Initialize the private
model-cache setting from `$RUNNER_TEMP` in an allocated step through `$GITHUB_ENV`.
An invalid workflow can report a failed run without creating any jobs; inspect
that state rather than mistaking an absent test log for a test failure.
