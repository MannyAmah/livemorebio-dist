# Single-skin terminal diagnostic — harness implementation review

2026-09-08. Maker `ui_audit`. Frozen for independent code review, **not authorized
for an actual invocation**. No browser, service, listener query, asset request,
installer, native experiment, operational store, product reader or UI was run or
changed. The full Atlas matrix remains28PASS/3FAIL/25NOT_RUN; the subsequent
ordinary20-case/33-image presentation result and its five ERR_ABORTED events remain
unchanged. Collection is not transport, performance or physiological acceptance.

## Approved boundary and frozen files

Read the complete269-line
[terminal supplement](2026-09-08-atlas-terminal-cause-supplement.md), its original
diagnostic amendment, the existing Python supervisor and both browser helpers.
Root approved this bounded mode before implementation. Supplement SHA256 remains
`c63364f5a67725ca3bb68b9cbe65ac4ba55a1a44f9d8ecf19f54d8ea057b5911`.
Context7 was unavailable in tool discovery. Exact installed Playwright1.58.2
protocol declarations and the existing pinned visibility/source helpers were
read locally instead; no external documentation request or upgrade occurred.

| Owned file | SHA256 |
| --- | --- |
| `tools/check_atlas_presentation.py` | `77982780e71188b633ade499e0f7d744e823a8f6a14a84de79ebad03e722ea76` |
| `tools/check_atlas_request_diagnostic.cjs` | `2846b11ff8f25975bfe6e92c410598e5eb13c80f1c2866cd2343d33aa52fdb68` |
| `livemorebio/tests/test_atlas_skin_terminal_diagnostic.py` | `ccf81632fe7c5e1850ba9436a3e3f853798fe27010f539779505115e5b1f8df3` |

Unchanged presentation CJS:
`23b38f60e2ebee4e306ba6331f35bc10c13e0fa9a8da18e1970c3d7ee06803ac`.
Unchanged original request reader:
`7ad7c023571614635d196cc5b0638d195ae46b166ce4602be16eb87e4cf4b9bc`.
No original tests, runtime source, private cache or prior evidence were edited.

## Implemented paths

- Python adds closed `--check presentation|skin-terminal` dispatch. Default
  presentation retains its original config without a mode field, fixed Node
  command,190-second ceiling, result label and cleanup contract. Skin mode adds
  only its marker and fixed `--skin-config` command with105-second ceiling.
  Actual supervisor-main tests use authored process/health stand-ins and verify
  all four dispatches, configuration and distinct result labels, not source text.
- Skin mode reuses the fresh observation-only fixture and normal three-service
  setup unchanged. The preserved real setup/startup constructor-denial regression
  still passes. No old c9 identity is substituted for new service/config data.
- The Node branch starts its one90-second clock before config I/O; checks the
  owner-private regular config, fixed mode/base/cache identity, current source,
  exact reader hash and pinned Playwright runtime; then owns every allocation.
  Shared build/workspace/Atlas validators check the actual dynamic identities,
  all three start times, source generation, typed model unavailability and exact
 4,901,056-byte skin declaration.
- A fixed fulfilled diagnostic document imports the original reader and contract
  from their unchanged routes. Only those two module GETs, that one document and
  the one fixed skin GET pass its once-only firewall. There is no workspace,
  scene, GLB parser, module rewrite or screenshot. The independent metadata GET
  helper allows only bootstrap/build/services/workspace/Atlas-status endpoints,
  exact204/200 and zero redirects; it cannot request an asset body.
- The original factory and native fetch promise are returned unchanged by their
  observers. One read-only signal listener and a private-document metadata
  binding retain bounded safe snapshots. No Response, stream, reader, cancel,
  byte chunk or fetch prototype is replaced. The only private CDP command is
  `Network.enable`; exact-URL mapped request/terminal events retain sanitized
  enums, original timestamps and nullable counters, not raw protocol IDs/errors.
- The runner waits for application and both terminal observations, not
  `response.finished()` or `request.sizes()`. Failed transport can be collected
  without being relabeled successful. Missing resource timing stays unavailable;
  observer agreement is a separate field. Final source/context checks follow.
  The three collection stages remain PASS/FAIL/NOT_RUN and `acceptance_pass` is
  alwaysfalse.

## Deadline and cleanup mechanics

The existing shared budget gained two opt-in arguments used only by the new
mode: a before-cancel snapshot callback and reverse allocation-order close
initiation. Old callers retain no callback and original close order. A red test
proved snapshotting must happen **before** the deadline closes resources, not in
the later catch/finally after teardown events could have arrived.

CDP detach is initiated before page/context/browser closure, but none of those
closure attempts waits on a stalled detach/allocation. Every pending allocation
remains tracked; a late resource closes when it arrives. The single combined
five-second cleanup deadline reports CLEANUP_UNCONFIRMED if the pending work
cannot settle. A never-resolving CDP allocation or detach cannot prevent the
other owned close attempts. The Python supervisor still independently records
proven descendant identities and tri-state LISTEN cleanup; this maker ran no OS
inspection. Evidence writing has its separate fixed five-second wait, and early
invalid config never chooses an untrusted output path. Node's scope remains
90+5+5 seconds, with105 seconds outside it, not a new whole-Python bound.

## Red/green evidence and fixture corrections

1. Initial guard packet: **16failed in1.56s**, private `...-829ml9wx`,15 exact
   authored Node/-e children. Missing fixed dispatch/observer APIs caused the
   intended REDs; no browser or network was involved.
2. After implementing those guards, three newly written real-runner/entry guards
   remained **3failed/16passed in2.15s**, `...-1g_2ay6x`. After their implementation,
   the explicit before-cancel ordering test reproduced **1failed/25passed in2.82s**,
   `...-0hs0xvwh`; adding the scoped callback made all26 pass in2.38s, `...-ft2t7pze`.
3. Two new supervisor-main fixtures initially returned a dictionary where the
   inherited cleanup contract requires a list of reaped-child rows. Their
   **2failed/28passed in2.61s**, `...-zc0y31q3`, were authored fixture errors, not
   product regressions. Only that stand-in return shape changed; assertions stayed.
4. The first expanded matrix passed208 cases in14.44s, `...-6mdmhlqy`. Subsequent
   stricter cleanup guards reproduced **2failed/29passed in2.96s**, `...-vi3je1qe`:
   waiting for CDP before initiating all other closes could block them. Close
   initiation was corrected as described above. One first detach-stall stand-in
   then rejected when page.close fired, so its timer had correctly disappeared;
   that **1failed/30passed in2.72s**, `...-3nhkkzem`, was a fixture timing mistake.
   It now deliberately stays unresolved to exercise the stated cleanup deadline.
5. Final frozen six-module preservation matrix: **209passed,2 existing startup
   deprecation warnings in14.30s**, private `...-5s83f2z0`, session72495 exited0.
   It includes all31 new cases, original diagnostic/Atlas/continuous guards and
   all ordinary presentation/listener/capture-bookkeeping guards. Every Node
   invocation was an exact authored `-e` or `--eval` subprocess, with networking
   and child-process calls refused inside Node. Python socket/connect/DNS, both
   urllib seams and low-level process launch were refused except those exact
   test children. No service/browser/asset/listener/solver probe occurred.

Reproduction: use the pinned Python3.11.15 interpreter and fresh
`prepare_review_environment`, install the same parent/Node refusal wrapper as the
ordinary harness review report (also refusing Popen unless inside the exact Node
invocation), and select these files with `-q -p no:cacheprovider --tb=short`:

```text
livemorebio/tests/test_atlas_skin_terminal_diagnostic.py
livemorebio/tests/test_atlas_request_diagnostic.py
livemorebio/tests/test_atlas_browser_harness.py
livemorebio/tests/test_continuous_browser_harness.py
livemorebio/tests/test_atlas_presentation_harness.py
livemorebio/tests/test_atlas_presentation_correction_harness.py
```

The exact optional `git -C <worktree> rev-parse --show-toplevel` lookup is refused
into its existing unavailable-metadata fallback. No blanket subprocess exception,
live service fallback or old assertion removal is needed.

## Gate and lesson

Root and an independent reviewer must read these exact scripts/tests before any
once-only diagnostic authorization. The native one-skin outcome remains unknown.
This implementation does not prove reader.cancel causes ERR_ABORTED, does not
repair the original diagnostic history and does not close any full-product
visual/performance/biological requirement.

The durable lesson is to separate application completion, native terminal state,
and evidence collection, and to snapshot before cancellation. A failed recorder
must not either invent a successful transfer or prevent unrelated owned-resource
cleanup. This local record is the compound artifact; no unavailable CE/gbrain
tool invocation is claimed.

## Metadata acknowledgment correction — frozen maker packet

2026-09-08. This append supersedes only the observer-delivery seam of the earlier
candidate; its209-case result and hashes remain attributable above. Root authorized
the complete independently reviewed correction plan at SHA256
`3f7059150dc079d33c46cd6a22b2863289038cf29fa3ae71bbfa5dd13473596c`.
No actual browser, HTTP, service, asset, listener, operational store or numerical
process was used for this correction. Actual transfer cause remains unresolved.

Only the diagnostic CJS, its existing skin test and a new dedicated delivery test
changed. The owner keeps at most eight acknowledgments in flight, invokes each
binding immediately, attaches success and rejection handlers, and makes failure
sticky. Positive completion requires sealing after the final snapshot and removal
of the real signal listener, plus acknowledgment of every registered emission.
Attempted emission after seal throws the fixed observer error visibly. An already
resolved Promise remains immutable; the implementation does not claim otherwise.

`startSkinBrowser` still returns the exact original reader task. Its side observer
does not replace/cancel that task or the native fetch Promise. The shared private
orchestration waits separately for the load outcome and metadata owner and returns
exactly two booleans. Node validates that closed result inside the evaluation
member of `Promise.all`, before waiting for other native/PW terminal observations.
Known delivery failure is DIAGNOSTIC_OBSERVER_FAILED even with held other terminal
events. Load rejection with successful delivery remains FUNCTIONAL_UNAVAILABLE.
The existing90-second clock, partial-evidence freeze before cancellation,5-second
combined cleanup,5-second evidence write and105-second outer ceiling are unchanged.

### Correction red/green and fixture fidelity

- Initial expanded RED: **29failed,207passed,2 existing warnings in16.75s**, private
  `...-436iydfi`, session64915 exited1. New owner/orchestration APIs were missing;
  three old cases failed at the explicitly approved fixture migration. A malformed
  result with other terminal promises held initially exited Node without completing
  its assertions. That was a test false-positive, not evidence of correct handling.
- Added explicit `beforeExit` completion assertions to every new asynchronous Node
  probe and two tests executing the actual serialized program with only its import
  replaced by an authored factory. Tightened new packet: **29failed in2.89s**,
  private `...-z2g09qc7`, session23794 exited1, before implementation.
- First implementation repeat: **28passed,1failed in2.69s**, private `...-a2ha8h76`.
  The never-ACK fixture did not model page closure rejecting the evaluation caller,
  leaving the cleanup clock unadvanced. Corrected only that authored boundary:
  closure rejects the evaluation caller without changing the in-page original load
  or ACK. Added a distinct never-delivered callback case to preserve null partial
  metadata and prove late delivery cannot rewrite frozen evidence. No deadline or
  result assertion was removed. All30 new cases then passed in2.76s (`...-odbm8r35`).
- Final seven-module matrix: **239passed,2 existing startup deprecation warnings
  in17.75s**, private `...-x5oayzq8`, session88745 exited0. This includes all209
  previous cases plus30 new cases. There is no running test process.

Coverage includes delayed-all/terminal, rejected-all/terminal/final, final-ACK-first,
never-ACK, never-delivery, synchronous emission failure, overflow, snapshot/disposal
failure, malformed result, original load rejection, known failure with held other
terminals, exact fetch/task identity, serialized orchestration and frozen evidence.
Mounted fixtures execute the same orchestration function as the serialized program;
they no longer substitute a successful boolean after the original load alone.

The exact previous isolated reproduction wrapper and six modules remain applicable;
add `livemorebio/tests/test_atlas_metadata_delivery.py` to the module list. The pinned
Python3.11.15 invocation uses fresh `prepare_review_environment` and disables pytest
cache and bytecode writes. Parent socket/connect/DNS, both urllib open seams, Popen
and low-level process launches are denied except exact authored Node `-e`/`--eval`
children. Their prefix refuses global fetch, net/TLS/HTTP/HTTPS/DNS and child-process
launch APIs and `Socket.prototype.connect`. The exact optional git metadata lookup
is refused into its existing fallback. No blanket HTTP/process exception or live
service fallback was introduced. These are offline technical fixtures, not browser
or scientific evidence.

### Frozen identities and review boundary

| File | SHA256 |
| --- | --- |
| `tools/check_atlas_request_diagnostic.cjs` (569 lines) | `4d4751346878794d39f6ba801d59ea67a2a5e1a3286e8bca35503bae90c07a8b` |
| `livemorebio/tests/test_atlas_metadata_delivery.py` (184 lines) | `94e4792eafe938a36eca68f57e18da67006896fd980acd3c4486c5003f265648` |
| `livemorebio/tests/test_atlas_skin_terminal_diagnostic.py` (389 lines) | `a31c427aa6e07f0463fc0341dd0673d2799c4f39d308eca6759562d7d8e82158` |
| Unchanged supervisor `tools/check_atlas_presentation.py` | `77982780e71188b633ade499e0f7d744e823a8f6a14a84de79ebad03e722ea76` |
| Unchanged ordinary presentation `tools/check_atlas_presentation.cjs` | `23b38f60e2ebee4e306ba6331f35bc10c13e0fa9a8da18e1970c3d7ee06803ac` |
| Unchanged old diagnostic tests | `674f885cbbec89f3fa992ccea81c69dcc51326b443efbf363cea5530bf79f084` |
| Unchanged product reader | `7ad7c023571614635d196cc5b0638d195ae46b166ce4602be16eb87e4cf4b9bc` |

Root and independent source review of this exact candidate remain required before
any actual run. The correction closes a reproduced harness evidence-completion
defect only. It does not classify ERR_ABORTED, repair old failed diagnostics, waive
warm-render gates or extend the accepted ordinary presentation slice. The lesson
is that preserving an original Promise and delivering all evidence about it are
separate invariants; a detached, silently rejected acknowledgment violates the
second even when the first is correct.

### Root-requested pending-load reproduction — candidate not cleared

After the239-case freeze, root identified that the shared orchestration still
awaits the original load before consulting the delivery owner's early false result.
Two additional authored tests confirmed this gap without changing the CJS:
**2failed,30deselected in0.28s**, private `...-tr205s6q`. The serialized program
remains pending after the initial ACK rejects while the original load is held.
The mounted shared path reaches its existing90-second deadline and incorrectly
records DIAGNOSTIC_DEADLINE rather than the known DIAGNOSTIC_OBSERVER_FAILED.
Owned fixture cleanup settles. Explicit completion guards prevent these probes
from exiting green with unfinished assertions. No actual browser occurrence or
transfer cause is inferred. The239-case result above remains historical, not
clearance of this newly reproduced boundary. CJS `4d475134...` is unchanged while
the maker awaits authorization for an observation-only race; the original fetch
and load task must remain unchanged.

### Authorized pending-load correction and final freeze

Root authorized the reproduced orchestration-only correction after those two
REDs. The runner now races two observation-side outcomes: handled original-load
plus full delivery completion, versus the delivery owner's sticky false result.
Positive delivery still waits for the original load and cannot imply its success.
All native and ACK rejection handlers stay attached. No original Promise is
replaced, no load/controller is aborted by the observer, and no timer, request,
accepting state or product path is added. Delivery failure retains priority even
while the original load is pending; the existing Node failure/partial-freeze/owned
cleanup path handles it.

The complete seven-module repeat is now **241passed,2 existing startup deprecation
warnings in17.09s**, private `...-w798uin_`, session45433 exited0. This preserves
the original209 plus32 new tests, including the two root-requested serialized and
mounted pending-load reproductions. The same exact Node-only Python/Node refusal
wrapper was used. No actual browser, asset, service or model run occurred, and no
process remains running.

Final superseding frozen identities:

| File | SHA256 |
| --- | --- |
| `tools/check_atlas_request_diagnostic.cjs` (573 lines) | `91cd052b2284d5e47c6196076b59750e29ff14d563109de7d2ec7b28ae39f7fa` |
| `livemorebio/tests/test_atlas_metadata_delivery.py` (207 lines) | `1d90f61d0b51d1d94d096e539955cace0f4e05f09cfa6a915be3566145e9ef7f` |
| `livemorebio/tests/test_atlas_skin_terminal_diagnostic.py` (389 lines) | `a31c427aa6e07f0463fc0341dd0673d2799c4f39d308eca6759562d7d8e82158` |

All unchanged identities listed above remain the same. The earlier239 result and
two subsequent REDs remain preserved; this final maker result is not independent
acceptance. Root and independent review must clear the exact candidate before any
real diagnostic is authorized. The asset-transfer cause and old performance/full
product matrix remain unresolved.

## Root independent repeat of the final241 packet

Root read the complete reviewed correction and final changes, including the
observation-only race that reports rejected metadata while the original load is
still pending. The exact seven-module packet independently passed241 tests in
17.58s, with2 existing startup deprecations, private review suffix `iwsu4fbx`.
The45-second parent alarm was cancelled at exit0. Unexpected I/O attempts:0;
one exact optional Git metadata lookup was refused;172 explicitly authored Node
children ran with their network/process interfaces refused. The actual startup
constructor-denial guard remains green on the new binding server3d521a02.

Root verified final diagnostic91cd052b…, metadata tests1d90f61d…, skin tests
a31c427a…, supervisor77982780… and terminal supplementc63364f5… unchanged.
The narrow offline collection mechanics are cleared by root, independent of the
maker. A separate source review is still pending. No browser, service, model,
physical packet, asset request or repeat of the33 retained presentation images
occurred in this check. An eventual single-skin diagnostic must retain failed
transport as failed even if collection succeeds; it is not product acceptance.

## Independent final source and offline grade — source_research

2026-09-08. **CLEAR in the bounded diagnostic-harness scope.** The reviewer read
the complete terminal-cause supplement, metadata-delivery correction and its
independent lifecycle requirements, this implementation history including the
early-ACK refinement, all573 diagnostic CJS lines, all207 delivery-test lines and
all389 current skin-test lines. No actionable source or fixture blocker remains
in this candidate. This is not a transfer-cause finding, ordinary Atlas acceptance
or authorization to execute the diagnostic.

The final owner separates delivery from the original native fetch and reader
tasks. It registers every issued ACK, never treats a temporary zero pending count
as completion, requires final sealing and all successful ACKs for a positive
result, and retains sticky failure. The terminal observer emits before removing
its signal listener and sealing. Its return remains the original reader task;
no observer cancellation, response/stream read, replacement buffer, second skin
GET or request retry was added. A failed ACK races independently of an unfinished
original load and yields the fixed observer failure. Positive delivery still
waits for the original load. The closed two-boolean result is checked inside the
evaluation branch before the other terminal observers can delay known failure.

The new tests exercise the actual serialized browser program and the same shared
orchestration used by the mounted runner. Their asynchronous completion guards
prevent an unfinished Promise from producing a false green Node exit. Delayed,
rejected, reordered and never-settling ACKs, the pending-load early rejection,
original-load rejection, malformed output and final-emission failures preserve
the intended separate outcomes. The prior skin fixture now uses that exact
orchestration rather than returning a synthetic successful boolean.

Source review also confirms the fixed private config/source/runtime/context
checks; the one-document/two-module/one-skin route budget; the closed metadata
endpoint allowlist with no redirects; sanitized native/PW terminal observations;
and partial-evidence freeze before owned teardown. The existing90-second shared
observation budget,5-second combined cleanup,5-second evidence-write wait and
105-second outer ceiling are unchanged. A failed native terminal remains FAILED
even when its observation can be collected; original-load rejection remains a
functional failure. `acceptance_pass` stays false in every outcome. These are
source and authored-test findings, not observations of the installed browser.

Independent repeat: **241passed,2 existing startup deprecation warnings in17.50s**,
private `/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-qqw9uyen`,
session38658 exited0. The same seven-file selection above ran under the pinned
Python interpreter with fresh isolated review storage and the exact Node-only
launch restriction; the parent45-second alarm was cancelled at completion.
Bytecode and pytest cache writes were disabled. The wrapper additionally refused
Python bind/listen, hostname lookups, `BaseProcess.start` and low-level exec,
alongside the documented socket/urllib/process refusals. Each permitted authored
Node child retained its network/child-process refusal prefix. Counters were
**0unexpected I/O,1exact optional Git metadata refusal,172authored Node children**.
No browser, service, listener query, asset, operational store or native model was
used; the actual startup constructor-denial preservation case passed.

Frozen identities independently checked before and after the repeat:

| File | SHA256 |
| --- | --- |
| Diagnostic CJS | `91cd052b2284d5e47c6196076b59750e29ff14d563109de7d2ec7b28ae39f7fa` |
| Metadata delivery tests | `1d90f61d0b51d1d94d096e539955cace0f4e05f09cfa6a915be3566145e9ef7f` |
| Skin terminal tests | `a31c427aa6e07f0463fc0341dd0673d2799c4f39d308eca6759562d7d8e82158` |
| Unchanged Python supervisor | `77982780e71188b633ade499e0f7d744e823a8f6a14a84de79ebad03e722ea76` |
| Unchanged ordinary presentation CJS | `23b38f60e2ebee4e306ba6331f35bc10c13e0fa9a8da18e1970c3d7ee06803ac` |
| Unchanged original diagnostic tests | `674f885cbbec89f3fa992ccea81c69dcc51326b443efbf363cea5530bf79f084` |
| Unchanged product reader | `7ad7c023571614635d196cc5b0638d195ae46b166ce4602be16eb87e4cf4b9bc` |
| Terminal-cause supplement | `c63364f5a67725ca3bb68b9cbe65ac4ba55a1a44f9d8ecf19f54d8ea057b5911` |

Only this review record was appended by the reviewer. A prospective once-only
run still needs root's explicit authority with the fixed source/config/ownership
boundary; there is no permission to retry or infer a transport cause from this
offline clearance. Prior failed recordings, the full Atlas matrix and all
scientific/physical qualification gates remain unchanged.
