# Local Biology molecular controller: test-first implementation breakdown

Documentation only. Root-approved architecture is unchanged from
`2026-09-08-molecular-structure-only-build-controller-plan.md`; its three consumer
contexts and R03/R23/R24 remain in scope. This breakdown sequences implementation,
not a new build/install/acquisition or permission to switch the live page.

## What already exists and what stays

- `biology.html` has accepted `STATE.context_id`, current/reference-only model
  availability, all21 organ targets, the molecular host, and the separate cell
  and anatomy controls. Reuse these; do not read/select an active twin elsewhere.
- `auth.js` already supplies same-origin HttpOnly-session bootstrap, abort-aware
  waiting and no mutation retry. Use its fetch entrypoint, not another token
  store/bootstrapper. No clinical metadata is passed to Molstar.
- Root's fixed catalog/coordinate routes retain legacy success fields and the
  full `livemore.molecular-reference.v1` descriptor. Their corrected timeout
  mapping is source-reviewed; actual strict-audit integration remains a gate.
- The canonical stock-npm lock is admitted as a lock only. The426 new archive
  acquisition, dependency rights, offline build, emitted graph and wheel remain
  separate gates. None is implied complete by this document.
- Keep the existing remote `_mol`/`closeMol` block and stylesheet tags until the
  replacement is usable and the switch is authorized. Their known lifecycle
  limitations remain recorded, not reclassified as a working local viewer.

## Small file boundary and order

1. **Contracts and bounded reads:** new `console/lib/molecular_loader.js` with
   descriptor admission and browser metadata/coordinate reads; dedicated
   `test_molecular_loader_ui.py`. No generic transport framework, server edits
   or reuse of Atlas's unresolved EOF/cancel behavior by copying it blindly.
2. **Owned plugin/dialog lifecycle:** new `console/lib/molecular_inspector.js`
   and scoped `molecular_inspector.css`; `test_molecular_inspector_ui.py` mounts
   the actual controller with deferred, authored adapter objects.
3. **Molstar adapter verification:** extend the already prepared small build
   entry/spec only in the authorized build lane; test actual public init,
   rawData/parse/preset and teardown orchestration. No full Viewer factory.
4. **Consumer adapters, last:** bounded ordinary Biology wiring first, then
   the already approved frozen-run and fixed-execution wiring; dedicated
   `test_molecular_consumer_bindings.py`. Preserve existing tests and controls.

Steps1–2 can be authored/tested inertly while the separate build/source owners
finish their gates. Step3 requires admitted build inputs. Step4's production
switch requires the built adapter plus independent source review and the
reviewed browser check below. One owner edits these shared UI files sequentially;
source/API/audit and acquisition remain independent lanes. Root coordinates
server/CSP/package patterns, not the controller maker.

## Source and context contract

```text
existing target button + accepted context + optional frozen PDB identity
  -> new owner epoch -> exact metadata GET -> descriptor/identity admission
  -> one fixed coordinate GET -> exact bytes/hash -> owned plugin init
  -> mmCIF parse -> explicit deposited-model preset -> visible READY
     any stale/failed boundary -> no publication -> owned cleanup
```

The existing public API remains `mountMolecularInspector(host,{context,onClose})`
returning `open(targetKey,optionalFrozenStructureId)`, `setContext`, `close` and
`dispose`. Context contains only the owner's opaque binding and fixed mode,
not a copied patient/readout object. Ordinary mode takes its accepted context_id;
run mode retains run/member/stage and recorded inspection binding; execution mode
retains execution/source-snapshot/selected-identity binding. No active fallback.

Admit only exact200 responses, expected JSON/mmCIF type, fixed descriptor schema,
finite typed bounds, reference-only flags, format, source identity and absolute
same-origin asset path derived from its64-lowercase-hex digest. No query, fragment,
encoded traversal, foreign origin or redirects. Metadata `gene` must equal the
requested target; available `pdb` must equal descriptor `pdb_id`. A supplied frozen
PDB identity must match; unknown/ambiguous mappings remain visible unavailable
states without fetching coordinates or selecting a related species.

The descriptor's source URLs are provenance links, never fetch destinations.
Use `cache:'no-store'`, same-origin credentials and redirect rejection. Bind both
responses to one non-null source SHA/process pair. Retain response metadata before
validating it; missing/mismatched identity is visible unavailable, not a fabricated
pin. An explicit retry may restart the entire operation against a newly confirmed
build, never combine old metadata with new bytes. No automatic retry/refetch.

One30-second monotonic operation deadline includes bootstrap wait, bounded reads,
import/init, parsing, preset and publication. Coordinate size must equal the
descriptor and remain at most8MiB; metadata is bounded by the existing2MiB JSON
ceiling. Verify actual byte length and SHA256 before fatal UTF-8 decode/rawData.
Abort pending owned reads on invalidation. EOF success must not be followed by an
unnecessary reader cancel; unfinished/error-path readers are canceled explicitly.
These are new reader tests, not a claim to have resolved the old Atlas transport
finding. No worker or synchronous-parser preemption guarantee is introduced.

## Exact deposited model, using upstream code

Use the retained Molstar4.4.0 builders:
`rawData({data,label})`, `parseTrajectory(data,'mmcif')`, then
`hierarchy.applyPreset(trajectory,'default', parameters)`, with exactly
`{model:{modelIndex:descriptor.selected_model_index},
structure:{name:'model',params:{}},showUnitcell:false}`.
The default without these parameters means first assembly, not deposited model.

Validate the parser's source mmCIF atom-site row count against `atom_site_rows`
and its trajectory/model identity against `source_model_numbers`,
`selected_model_index` and `selected_model_number`. Pinned public declarations
expose `Trajectory.frameCount`, `Model.modelNum`, and MmcifFormat data's `db` and
`frame`; use these original source facts, not canvas triangle/visible-atom counts.
All six admitted inputs currently contain model1/index0. Do not infer that every
future parser-filtered representation has the same count as raw atom-site rows.
Any mismatch prevents READY and disposes the candidate; no assembly expansion,
coordinate synthesis, model interpolation or missing-residue filling.

Keep the actual source construct/taxon/chain/entity/author-versus-label namespace,
coverage, experimental method/resolution, revision, rights and no-dynamics warning
readable. INS has no admitted human mapping; 4INS is a labeled related pig source,
not an automatic success. 6P2B remains tethered PXR/SRC-1p with its exact limitations.
Geometric selection/focus and Å/degree measurements stay upstream Molstar actions;
quantities from Biology, Cendos or LIFE never displace/color molecular coordinates.

## Ownership, focus and failure behavior

Register PluginUIContext ownership before init. Handle `init`, `initialized` and
`canvas3dInitialized` rejections. Check epoch/context before React render and after
every await. A rejected/missing canvas never becomes READY. Retain the React root
and unmount before plugin.dispose, using the reviewed tiny public orchestration.

Close/new target/setContext/pagehide/dispose first invalidate publication, abort
owned reads, clear old inspector labels/selection/measurements, and detach the
visible host. A pending init/parse/preset stays owned until its completion permits
cleanup; no second plugin starts while teardown is pending. Late success is
disposed, late rejection handled, exactly once. Deadline or cleanup failure gives
a fixed visible unconfirmed state, not a false disposed claim or automatic retry.

The dialog has a real Close button, title association, Escape, contained keyboard
focus and a remembered trigger. Close returns focus only to a still-connected,
enabled trigger in the same accepted context; otherwise use the existing owner
region as the neutral fallback. Context invalidation must not refocus an old
subject's removed control. Failed/unavailable loads retain readable status and
Close/explicit Retry. Provenance uses textContent, never source HTML/raw errors.

Ordinary `loadBiology` calls setContext before publishing an accepted changed
STATE, and closes on linked-context rejection or page teardown. READY to numerical
UNAVAILABLE closes the previous binding but preserves the new context's reference
target controls. A transient failed refresh must not relabel the retained reference
as a newly confirmed current context. Cell/anatomy rendering and polling remain
owned by their existing code, with no new numerical requests from this inspector.

## RED inventory and acceptance sequence

Tests below are requirements, not tests already implemented or passed:

| Test family | Required authored branches before implementation |
|---|---|
| Loader admission | Valid target/descriptor; unknown and ambiguous; malformed schema/types/nonfinite values; wrong target/frozen PDB; foreign/encoded/query/redirect path;401/404/503/non200; absent/different build or process; wrong format/length/hash/UTF-8; oversize; deadline/abort at headers and body; no external fetch/no retry |
| Source parser | Exact rawData input and explicit preset; wrong source rows/frame count/index/model number; parse/preset rejection; no default assembly/provider call; parser result does not synthesize missing coordinates |
| Owner races | Close/new target/context/dispose at metadata/body/import/init/React/canvas/parse/preset; old A finishing after B; repeat Close; late resolve/reject; every pending promise handled; init never settles; cleanup throws/remains pending; no second plugin; explicit same-source retry only after confirmed teardown |
| Dialog/focus | Keyboard target activation; Escape/Close; exact focus return and removed-trigger fallback; no focus steal by late result; no stale labels/measurements; safe provenance and fixed failure text; unavailable mapping still closable |
| Ordinary adapter | Actual module mount, accepted context capture, linked mismatch, READY→UNAVAILABLE with reference usable, old read failure not new identity, unrelated cell/organ/section/Retry data unchanged; old viewer remains before switch and only one selected implementation runs after switch |
| Frozen adapters | Run/member/stage/time and PDB mismatch; fixed execution/source hash identity; no current-context fallback; immutable endpoint/provenance/plots and existing anatomy controls unchanged; missing mappings remain actionable |

Use pytest-driven Node fixtures that import/mount actual new modules. Deferred
adapters expose the real public method/property shapes and assert call order and
arguments; missing imports must produce genuine RED, not skipped mounts. Migrate
`biology_ui_fixtures.py` only for the actual new import seam while retaining its
full controller/availability/geometry assertions. Freeze exact tests/source and
independently review before any actual package execution or browser check.

The local switch is one deliberate edit after the vendor manifest/notices and
outside-checkout wheel/static-route checks pass. No permanent hidden feature flag
or automatic CDN fallback. Keep legacy source/history recoverable; remove its
active block/CDN CSS and fonts only alongside the selected local replacement.
Root's page-local CSP and independent external-request refusal must pass together.

Then use the existing owned browser tooling on an authorized source-frozen URL,
not a new runner framework: actual six source identities where explicitly exposed,
selection/sequence/focus/reset/styles and add/remove distance/angle/dihedral;
ordinary, frozen run and fixed execution; missing mapping, close/change races,
five open/dispose cycles, WebGL/context loss, desktop1440/mobile390/200% zoom,
readable provenance and focus. Preserve every failure/NOT_RUN and separately
classify request terminal errors. Screenshots plus independent operation review
are required; inert tests or a vendor file's existence cannot authorize switch-over.

## Scope and review status

Not in this implementation: new molecular renderer, dependency resolver, numerical
engine, drug-induced animation, clinical inference, new target discovery or Atlas
changes. These are not shortcuts for restoring the existing reference inspector.
All-target mapping, molecular dynamics and the larger R03/R23/R24 visual matrix
remain open requirements, not removed work. No new TODO framework is proposed.

Engineering checklist applied: reuse/scope, architecture, failure/code boundaries,
test diagram and memory/performance limits. No new architectural decision is
required beyond the already approved packet; real build/parser/CSP/browser
verification remains explicitly pending. Root/independent review still decides
the implementation/switch checkpoint; this author is not grading its own plan.

Lesson: a source-bound viewer owns three independent lifetimes: the requested
context, the asynchronous plugin, and keyboard focus. Correct bytes alone do not
prevent a late plugin or focus return from reviving the wrong inspection context.
