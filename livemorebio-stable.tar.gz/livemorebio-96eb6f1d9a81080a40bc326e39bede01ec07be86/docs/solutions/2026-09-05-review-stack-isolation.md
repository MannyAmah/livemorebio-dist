# Alternate ports do not isolate healthcare data

Date: 2026-09-05. Component: local review launcher and legacy cross-service stores.

## Finding and incident

The first review startup used separate subject/protocol stores and service ports,
but legacy bus snapshots/events still pointed at the installed `~/.livemore`
directory. Startup replaced its shared twin snapshot with a review-key-encrypted
default twin. The original service's in-memory twin was not changed. The review
stack was stopped; the shared twin snapshot was restored from the original
authenticated service and checked against that state. The incident was disclosed
during work, not hidden behind passing tests.

Existing append-only event history was not erased or rewritten. It can retain
review-key-encrypted startup/test entries; the legacy reader skips records it cannot
decrypt. This is not a claim that historical event continuity or every old audit
record has been repaired. Production-grade event retention and explicit corruption
reporting remain open work. No physical measurement or human-device experiment was
performed to validate the review environment.

A final independent review found additional path overrides still missing from the
launcher: Patch journal/device/command companions, screen runs, reference/resolve
caches, anatomy assets and associated LIMS. An inherited production evidence-signing
identity was also inappropriate for a review candidate. These paths were fixed
before the final restart; no physical Patch commands or measurements were created
as a substitute for missing test evidence.

## Root cause

The repository evolved multiple storage defaults before `LIVEMORE_DATA_DIR` existed.
Changing ports and two databases was not an isolation boundary. A broad inherited
environment could silently reconnect a development service to production stores or
signing credentials. `mkdir(mode=0700, exist_ok=True)` also does not make an existing
public directory private or reject credential symlinks.

## Repair and regression

`prepare_review_environment()` is import-safe and testable without starting a
service. It resolves all known store/cache/signing paths beneath an owner-only
review root, overrides inherited locations, discards inherited evidence issuer/audit
identities, and pins child source/cwd to this checkout. Bus/audit/licensed defaults
also derive from the configured data root.

Reused directories and credential files must belong to the current user. Unsafe
permissions, symbolic links, shared hardlinks, unexpected file types, empty/invalid
credentials and unsafe derived paths reject before launch. Credentials are never
printed, checked into Git or copied from a production identity.

Tests exercise hostile inherited path settings, actual module consumers, SQLite
sidecars, journal companions, signer paths and credential reuse. Red tests were
written before the launcher repair. The focused isolation/parser run passed 99 tests;
the release report records the separate full-suite result.

## Durable rule

For every new persistent component, add its path to the review environment contract
and the actual-consumer regression. Test defaults and inherited overrides. Do not
call an environment isolated based only on its URL. If a review touches existing
state, stop, preserve evidence, repair only known targets and disclose what remains
unverified. Never erase audit history to make a test environment look clean.
