# Connected workflow correction: clean Cendos preparation and owned history reads

Date: 2026-09-09. Pre-code plan under the approved preserve-and-extend full-scope
recovery plan. User direction retains all R01–R51; this packet addresses concrete
R06/R20/R27/R38/R47/R48 defects and does not claim the whole workflow accepted.

## Source audit and decision

The selected-twin, non-T2D and reference-cohort consumers already exist. The
server advertises healthy reduced-model templates separately from source-grounded
population strata; its healthy population generator remains explicitly unavailable
(`aegle/population.py:78–95`). Public reference and REAL cohorts without a qualified
binding correctly remain descriptive. Do not convert these into executable healthy
people, choose T2D implicitly, or alter biological equations or source admission.

Cendos has a bounded 50-cohort page plus retained explicit selections, member
inspection and separate blank Preparation/History. Its existing New experiment
handler, however, leaves previously selected cohort IDs and the legacy current
reconciliation quantity/evidence selection behind. Its Recall and Prepare rerun
success paths check `contextRevision`, but their error paths do not: a late failed
read can overwrite the feedback of a newer preparation. These are UI ownership
defects, not missing biological mechanisms.

Selected minimum-diff correction, using existing handlers and revision ownership:

1. New experiment clears all three protocol cohort selections and the current
   legacy result/reconciliation/evidence selection, while retaining documented
   protocol input defaults, saved records and the explicit historical assay log.
   No automatic load, execute, create or deletion is introduced.
2. Recall and Prepare rerun may publish errors only while their existing revision
   is current. New experiment and a newer recall/rerun already invalidate older
   success responses; preserve those guards. Current failures remain visible.
3. Exercise actual inline handlers with authored deferred responses and an inert
   DOM. Cover blank entry, reset after rerun, stale success/failure, current failure,
   exact rerun restoration and unchanged explicit one-POST/parent lineage. Retain
   all old compact-member, biological context and fixed-history tests.

Owned runtime is only `livemorebio/aegle/console/cendos.html`; dedicated test file
is `livemorebio/tests/test_cendos_preparation_ui.py`. No API, security/auth/build
identity, OSP, worker or biological store changes. No browser/server/model launch
by this maker. Root independently reviews the delta and owns fresh actual browser
QA; passing inert tests are not rendered or scientific acceptance.

## Verification

Write failing tests before runtime edits. Use the existing isolated Python/Node
test guard, with all external I/O, scientific constructors and unapproved child
processes refused. Run the dedicated tests and relevant prior UI preservation
tests. Record exact RED/GREEN receipts and final hashes below, then release the
Cendos source freeze to root. Any further defect requiring scientific inputs or
new API authority is reported separately, not silently repaired here.

## Pre-code follow-up: legacy assay shares the existing action lock

The first planned correction passed 13 dedicated tests after six genuine REDs.
Before handoff, source inspection found that `runAssay` did not acquire or check
the existing `PROTOCOL_BUSY` lock. A pending legacy POST could therefore accept a
second Run or allow New experiment/History to switch context before republishing
the prior result. Reuse the current busy boundary for this existing action; do
not add a new execution framework. Disable its Run control while any protocol is
busy, including a concurrent source-read completion, and always release the lock
after success/error. New experiment and History already honor this lock.

Add RED-first authored pending-POST tests for duplicate Run, New experiment and
read completion during the pending action, plus failure release/no-replay. This
changes no assay request, calculation, response contract, stored result or auth.

## Maker result and repeat command

The initial ordinary-handler RED was `7b6883`: 6 failed / 7 passed in 2.10s,
unexpected I/O0, Node13, Git0. The first correction passed `109ed8`: 13 passed
in 1.92s. The action-lock follow-up RED `31b67f` was 2 failed / 13 passed in
1.75s; its first GREEN `eb3ba0` was 15 passed in 1.92s. An additional assertion
retained RED `a3abce` (1 failed / 14 passed), exposing a stale progress label;
the existing legacy action now explicitly reports request completion without
claiming a successful outcome or automatically retrying it.

The initial broader wrapper refused seven old tests' literal `node` child paths
(`0d6b8d`: 7 failed / 62 passed, seven refused I/O attempts). The wrapper now
normalizes that exact executable spelling to the same pinned local Node before
applying its unchanged argument and network guards. The next repeat `519c49`
was 1 failed / 68 passed: one old extracted-function fixture lacked the new
`PROTOCOL_BUSY` module binding. Only `PROTOCOL_BUSY=false` was added to that
fixture; its existing assertions were retained.

Final preservation `ab8ec8`: **69 passed in 7.16s**, two existing FastAPI
on_event deprecations; unexpected I/O0, authored Node62, Git-refused1. No browser,
model, service, native OSP or scientific calculation was run. This is maker
software evidence, not independent acceptance.

Final SHA-256 pins:

- `livemorebio/aegle/console/cendos.html`: `b9ea2b12eade8072dd97a8cc0f2ee4199baa64a40e99cd2b61538df1d443c7da`
- `livemorebio/tests/test_cendos_preparation_ui.py`: `265d3154b20b087138bd4d1237910fc143a3f44097387d7f27b292a4cf357db8`
- `livemorebio/tests/test_cendos_compact_members.py`: `4f3f50539a5c76eaeeb97832514cc19d5d4d58773230faa50d1406f0463fee09`

Runtime delta: three New-experiment clearing lines; current-revision guards in
two history-read catch branches; legacy current-assay Run disabled by the shared
busy state, with busy admission/acquisition/final release and source-read
preservation of that disabled state. No protocol request, result, admission,
biological calculation or source capability was changed.

### Exact independent 69-case repeat

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os,signal,socket,subprocess,sys,urllib.request,ctypes
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('OFFLINE_DEADLINE')));signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.socket.bind=socket.socket.listen=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and cmd and cmd[0]=='node':cmd=['/opt/homebrew/bin/node',*cmd[1:]]
 if isinstance(cmd,list) and (len(cmd)==4 or len(cmd)==5 and cmd[4]=='file:///Users/emman/Livemore/.worktrees/full-scope-recovery/livemorebio/aegle/console/lib/execution_view_state.js') and cmd[:2]==['/opt/homebrew/bin/node','--input-type=module'] and cmd[2] in ('-e','--eval'):
  counts['node']+=1;permit=True
  try:return run0([*cmd[:3],'import {createRequire as scopedRequire} from "node:module";const require=scopedRequire(import.meta.url);'+prefix+cmd[3],*cmd[4:]],*a,**k)
  finally:permit=False
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1;permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
class NoModels:
 @pytest.fixture(autouse=True)
 def prevent(self,monkeypatch):
  from livemorebio.tests.clinical_registry_fixtures import forbid_compilation
  from livemorebio.aegle.runtime import AegleTwin, MetabolicProfile
  forbid_compilation(monkeypatch)
  monkeypatch.setattr(AegleTwin,'__init__',deny)
  monkeypatch.setattr(MetabolicProfile,'__init__',deny)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=line','livemorebio/tests/test_cendos_preparation_ui.py','livemorebio/tests/test_cendos_compact_members.py','livemorebio/tests/test_clean_workflow_ui.py','livemorebio/tests/test_protocol_inspection_ui.py','livemorebio/tests/test_population_capabilities_ui.py','livemorebio/tests/test_life_empty_selection_ui.py','livemorebio/tests/test_clinical_execution_ui.py','livemorebio/tests/test_execution_view_ui.py'],plugins=[NoModels()])
print('Refusal counts:',counts,flush=True)
raise SystemExit(status)
PY

```

### Lesson

Clearing a visible card is not a clean workflow reset: selected IDs, reconciliation
readouts and evidence providers must reset together while immutable history stays
intact. Async failure paths require the same context ownership as success paths,
and legacy actions must share the mutation lock with the controls around them.
