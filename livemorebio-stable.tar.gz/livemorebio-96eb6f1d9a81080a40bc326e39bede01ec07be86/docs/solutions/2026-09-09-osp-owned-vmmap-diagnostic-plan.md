# OSP: one separately governed owned-target vmmap diagnostic

2026-09-09. **Proposal only, pending root review and separate implementation /
execution decisions.** No driver, worker, test or authorization is created by
this document. No OS/native/model process or browser was run.

## Question and non-substitution boundary

The original OS preflight failed its first inspector at the approved1.5s work
cutoff inside a2s complete call. The retained evidence does not identify why
vmmap had no stdout by that cutoff. See the
[independent diagnosis](2026-09-09-osp-os-preflight-vmmap-timeout-diagnosis.md).

Measure **one actual uncancelled completion time, or one bounded refusal/timeout**,
for the identical `/usr/bin/vmmap -w <owned-Python-PID>` command against a new
authored waiting Python worker. This is a separately identified latency/mapping
diagnostic, not a retry of the seven-condition acceptance matrix. It does not
run O2–O7 or any R/CLR/OSP model, and does not authorize S01–S17.

Keep the original result SHA
`1bbb6d3290bbf6bcc0869341d0447f8c02aefd333ef2a9eef6397013cd45446c`
and original once marker/authority untouched. All original scientific failures,
criteria, six programs,2s production inspector,30s worker and600s packet bounds
remain unchanged. No result here is labeled OS_PREFLIGHT_PASS.

## Smallest implementation and identity boundary

After approval, use one new0700 private directory with a small fixed driver,
worker and offline tests (0600). Root reads every line and independently repeats
the inert tests before deciding an actual one-shot launch. No existing file is
edited and no generic runner/API is introduced.

Reuse frozen supervisor SHA
`cdb00a1acb5b08b3f7d8aff0f3977f746b5a506ed4f97355b56dd34bf2d2a476`
unchanged: _execute, Owned, sampling, WNOWAIT, streams, child limits and cleanup.
Only the same previously approved private classifier specialization is needed:
exact pinned Python/worker argv and no descendants; real vmmap delegates to the
original classifier, restricted to this already-proven worker PID. Restore the
classifier in finally. No sampling, proof, cleanup or production gate override.

Use the existing exact Python3.11.15, vmmap and OS identity pins from the frozen
preflight driver. Verify their original file identities/hashes and the new
driver/worker hashes before launch and after collection. Fixed clean private
HOME/TMPDIR/cache and C locale; no inherited R/DOTNET/DYLD/proxy/credential
settings, shell, R package import, install, compilation or elevated privilege.
One new exact-hash authorization and exclusive once marker precede all child
creation. No authorization is implied by the original preflight's marker.

## Exact two-child schedule and fixed budgets

**Exactly one worker leader and at most one vmmap inspector; no fork, exec,
descendant, second map, retry or additional diagnostic tool.** Both direct
children get the unchanged supervisor's separate owned process-group handling.

| Bound | Proposed diagnostic value | Relationship to existing behavior |
|---|---:|---|
| Whole diagnostic, including pin reads/evidence/cleanup | 20s | Separate diagnostic-only budget; not600s scientific packet. |
| Complete worker call | 15s | Existing3s cleanup reserve leaves12s work. Full15s reserve required before spawn. |
| Complete inspector call | 10s | Existing0.5s cleanup reserve leaves9.5s work. Explicitly different from the original2s acceptance bound. |
| Worker natural-exit failsafe | 16s | Later than its complete-call ceiling; natural expiry cannot count as timely successful worker cleanup. |

The worker writes one bounded atomic READY message with its own PID, fixed
diagnostic ID, sequence and supervisor hash, then waits for a matching atomic
ACK. It has no scientific work and no request for another process. Full argv,
image/start identity and actual live-group proof must precede inspection.

Before creating the sole inspector, require at least13s remaining in the worker
deadline (10s complete inspector plus3s worker cleanup). Otherwise fail without
an inspector. Cap every deadline by the original20s common deadline; never
extend a clock after a failure. The existing target sampler continues through
the inspector's outer_tick callback.

If the inspector finishes cleanly and its original strict process admission
and bounded full-path parser pass, verify the same worker again and send its
one exact ACK, allowing a normal exit. If inspection fails or times out, retain
that receipt and stop the worker through the unchanged cleanup path; do not
send a success ACK. TERM/KILL remain proof-gated. Unknown ownership retains the
original anchor and fails closed; no ad-hoc signal/reap or slot reset.

Existing CPU20/21s, sampled3GiB,100ms target/500ms maximum sample gap, worker1MiB
streams, inspector512KiB stdout/8KiB stderr, case4MiB and fixed output-entry
bounds remain. Whole evidence is bounded to16MiB. No memory/CPU stress or
hard-memory-isolation claim. Whole timing must include the final receipt write;
late/missing final evidence exits nonzero without rewriting original receipts.

## What must be retained and what it may establish

Retain raw stdout/stderr, exact observed/retained lengths and independently
recomputed hashes, full original worker/inspector receipts, sampled identity
and resource records, READY/ACK, fixed source/tool identities and all clocks.
Keep the fixed expected worker marker bytes independent of receipt assertions.
Report the inspector's complete _execute elapsed and its cleanup elapsed
separately; do not claim an exact internal vmmap completion instant from them.

Classify outcomes as diagnostic-only: clean completed mapping; clean nonzero
refusal; work timeout; or unresolved/evidence failure. To call mapping clean,
require positive samples, no original primary/error/overflow, EOF, exit0,
no TERM/KILL and unchanged target proof, then complete parse of original stdout.
An empty, truncated or unparsable map is not accepted. Store exact mapped paths;
do not reduce them to a mere count or treat all shared-cache images as loaded.

If clean elapsed exceeds the original1.5s work window, report that single
observation. It can motivate a separately reviewed engineering-budget proposal,
not silently change the existing bound. Even a fast completion does not erase
the original failure or complete O1's two-barrier condition. A timeout at9.5s
is still not proof of SIP/permission failure. No success here establishes
R-image closure, source/build equivalence or scientific validity.

Root independently reads all raw results and exact post-cleanup ownership
evidence. A missing owner-exit observation remains unresolved. No automated
follow-on preflight or native run is permitted from any diagnostic outcome.

## Eight minimum inert test contracts before any launch decision

1. Closed gate, wrong authorization or wrong pin creates no marker/child.
2. Fixed two-child ceiling, exact argv/target and no descendant or second map.
3. 20/15/10s clocks and13s pre-inspector reserve, including nested work/cleanup.
4. Successful owned mapping uses original process admission/parser, one ACK.
5. Timeout/refusal retains original inspector output/primary and stops worker.
6. Unknown ownership cannot signal/reap/reset; classifier restoration still runs.
7. Stream/parser/disk/final-write failure cannot become diagnostic completion.
8. Every classification leaves original preflight FAILED and all production
   gates false; no scientific or automatic retry callback exists.

Tests use authored process/API stand-ins only, with network, process creation
and ctypes loading refused. The code and exact eventual command remain a new
independent review gate; this plan is not permission to execute them.

## Why retain vmmap rather than guess an alternative

The fully read installed Apple manual documents -w full paths and default
loaded split-library filtering. It does not document a guaranteed faster
equivalent. -summary removes required region detail; -allSplitLibs includes
unloaded shared libraries. lsof/open-file enumeration is not yet proven to
provide the same loaded-image evidence. Switching tools now would add an
unreviewed equivalence assumption. A single bounded same-command measurement
answers the immediate latency/refusal question with the smallest new boundary.

## Root pre-code decision

Root read the full proposal and the independent retained-failure report, and
rechecked the unchanged supervisor work/cleanup and parser seams. Approve the
small private driver/worker and eight-group inert-test preparation. This is a
separate measurement of the inspection tool, not relaxation of a scientific
acceptance bound. Keep the20/15/10-second complete deadlines,13-second nested
reserve, exact two-child ceiling and unchanged original ownership cleanup.
No actual process launch is authorized yet. Freeze all new code, tests and
input pins for independent review and a separate once-only decision.
