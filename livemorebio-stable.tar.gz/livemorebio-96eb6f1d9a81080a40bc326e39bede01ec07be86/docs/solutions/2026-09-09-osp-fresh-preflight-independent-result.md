# Fresh OSP OS-preflight — independent retained-result audit

2026-09-09. **Bounded OS_PREFLIGHT_PASS is supported. No scientific/native-model
packet was run or admitted by this review.** Root independently graded the
private implementation, then launched it once; this audit independently reads
its retained actual evidence, not a rerun or self-grading of source tests.

## Result and method

Consumed root: `/private/tmp/livemore-osp-os-preflight-v2.Yc5Y4i`.
Complete final result:75,634B, SHA256
`b579c9a1563b4309fa2127955faa2da16ada105051f1773865834f0e44f04b43`.
Root reports actual session2832/completion0ae0fd, exit0, final driver elapsed
9.679222667007707s. Those terminal facts are attributed to root's direct tool
observation. The stored receipt itself contains pre-write9.677427958988119s
and completion_requires_exit_zero=true, not the final elapsed/exit evidence.

Read all case/process/inspector fields and original OS-only requests/ACKs.
A separate stdlib-only read/compare pass used no supervisor/driver import:
strict duplicate/nonfinite-rejecting JSON, exact canonical authorization,
all6 standalone case/result and9 process records equal their final embedded
records, exact commands/identity/start ordering, prescribed negative outcomes,
limits, and all42 evidence file bytes/hashes. Total evidence738,554B, within
4MiB per case/64MiB packet. The18 raw streams individually match both retained
and observed byte/hash receipt fields. Fixed technical markers are reconstructed
from O1–O6 case/role, not trusted from receipt hashes alone.

Authorization SHA `3ca5599c5d6f24918955d30278e95c54e9e73c9e514789fbab5929dd8f9aa7c7`;
exclusive once SHA `f9e53f01616e732eab88c08b3799a221928dc0ea53ac504fa654066a8ffa25c6`.
Their serialized order differs, but strict canonical objects exactly match the
approved hashes/seven cases/60s/nine direct/one descendant. There is no O7 file
or directory, extra request, retry inspector or unaccounted evidence file.

## Exact actual conditions

| Item | PID | Samples | Elapsed seconds | Retained outcome |
|---|---:|---:|---:|---|
| O1 worker | 33683 | 25 | 2.637155458 | exit0, no signal, SETTLED/empty-before-reap |
| O1 PRE_XML vmmap | 33684 | 18 | 1.839972250 | exit0, no signal, complete streams |
| O1 FINAL vmmap | 33688 | 7 | 0.713963542 | exit0, no signal, complete streams |
| O2 immediate worker | 33689 | 1 | 0.031156041 | exit0, positive sample; ZERO_SAMPLES alternative did not occur |
| O3 worker | 33690 | 26 | 2.746732625 | PREFLIGHT_INSPECTOR_TIMEOUT, TERM/-15, SETTLED |
| O3 authored inspector | 33691 | 24 | 2.523681792 | WORKER_DEADLINE, TERM/-15, SETTLED within3s |
| O4 leader +descendant33697 | 33696 | 12 | 1.245071167 | PREFLIGHT_CANCEL, TERM then KILL/-9, SETTLED/empty-before-leader-reap |
| O5 worker | 33698 | 2 | 0.222579250 | authored callback SUPERVISOR_FAILURE, TERM/-15, SETTLED |
| O6 worker | 33699 | 12 | 1.220365291 | WORKER_IMAGE_OR_ARGV; original cleanup UNRESOLVED_CHILD |
| O7 | none | — | no new budget | real entry and execute guards both UNRESOLVED_CHILD |

All9 direct identities have their own process group and parent33674.
The only recorded descendant is O4 PID33697, parent/group33696, same fixed
Python/fixture argv. Direct start identities strictly follow the prescribed
schedule. Every worker and the O3 inspector uses exact frozen Python/fixture/
case/role/path argv; both vmmap commands target only PID33683.

Aggregate retained sample count127, largest gap0.11453616700600833s below0.5s,
largest sampled group RSS39,354,368B below3GiB, zero RSS overshoot. All retained
CPU and per-process elapsed summaries satisfy their bounds. These are checked
sampler aggregates, not an independently reconstructed per-tick trace: the
packet retains deduplicated process observations, not every raw timing sample.
No hard memory-isolation, unsampled-interval or global-machine guarantee follows.

## O1 raw map evidence, not R image closure

Each complete original output was decoded and scanned independently using
address/size columns and region/protection/share/detail tokens, without calling
the production parser. Both identify live Python33683; requests and ACKs have
the exact same PID/sequence/phase/supervisor hash, with recomputed request hashes.
Both inspector receipts have the exact `/usr/bin/vmmap -w 33683` argv.

Each contains1,777 ordinary positive path rows, deduplicating to exactly351
paths matching the corresponding final barrier list. The sorted canonical path
list digest is `e63c2901f8f4ab5a79838d3ffcdd1ef0656fd72d9384c6b780cb57ead4425b35`
at both barriers. Positive rows include the exact pinned Python executable.
Both also contain42 specifically unused rows:4 __TEXT,20 __DATA and18
__DATA_DIRTY. Their address order, four size columns, reviewed protections and
fixed detail/path rules match the admitted exclusion. Seventeen distinct paths
present only in unused fragments are absent from positive lists. No excluded
fragment was promoted to loaded-image proof.

This proves the prescribed actual Python/vmmap format and ownership observation,
not an R/CLR/native-library closure, source-to-binary attestation or patient/model
equivalence. The faster second map is one observation, not a latency guarantee.

## Original negative versus later terminal evidence

O6's original Python identity remains stored. Its two policy observations retain
PID33699/start11339046753390/group33699/parent33674 unchanged while path/argv/
image UUID changes from Python to exact `/bin/sleep 2.5`. Primary and evidence
error remain WORKER_IMAGE_OR_ARGV. Original cleanup took1.0004027499817312s,
error OWNERSHIP_UNCERTAIN, status UNRESOLVED_CHILD, exit null, no TERM/KILL and
no empty-before-reap claim. Both original streams remain INCOMPLETE even though
their retained fixed marker bytes match. They were not retrospectively made EOF.

O7 separately records both UNRESOLVED_CHILD refusals. Only afterward, the
reviewed same-anchor waitable natural-exit path yields the distinct terminal
receipt: SETTLED, exit0, empty-before-reap, no error/signal, cleanup
0.0009900410077534616s. The historical slot remains occupied/retained=true.
This expected failure/refusal followed by separately verified terminal settlement
satisfies the approved negative condition; it does not mean the original
identity proof or cleanup succeeded, or permit another child in that process.

## Current exact-PID absence and source preservation

At **2026-09-09 07:51:26 UTC**, independent read-only command
`/bin/ps -p 33683,33684,33688,33689,33690,33691,33696,33697,33698,33699 -o pid=,ppid=,pgid=,lstart=,stat=,comm=`
returned exit1/no rows (chunkbdd4db). Thus none of the nine direct children or
one descendant occupied those PIDs at that timestamp. There was no extant row
requiring PID-reuse/start comparison. This is a present-state observation,
not retroactive evidence of a signal or wait syscall. Root separately reports
its own no-row check including launcher33674; that is not this reviewer's check.

Recomputed current driver/fixture/tests match a9fbb23b…/53537da4…/6ab65ffe….
Supervisor8f8c1f66…, pure12585d9b…, R3ba6559b… and inventoryd09b1f5d… match
the frozen full hashes in the implementation report. A further exact four-file
static readback after the run verifies original Python/vmmap/sleep/OS metadata
and full bytes, including before/open/after inode/mode/nanosecond identity.
Both production flags and the private source-file gate remain false.
No consumed file was edited by this audit.

Old preflight result still hashes
`1bbb6d3290bbf6bcc0869341d0447f8c02aefd333ef2a9eef6397013cd45446c`;
the separate diagnostic still hashes
`4c437eaafca75f57a4063f71309d71a5ea1ef148d63dd9cde6e5ce97ce9e1112`.
Both remain FAILED. No budget change retroactively clears them.

## Independently recomputed original stream links

Paths relative to evidence/. Same byte count and hash matched observed and
retained fields in every original process receipt.

| Stream | Bytes | Original read state | SHA256 |
|---|---:|---|---|
| O1/stderr.bin | 12 | EOF | `4ad914216d8422916e61d3391d3d3110d29bbd535c11c1cd681226f2484a2134` |
| O1/stdout.bin | 10 | EOF | `3f5e4e6751c80250f72dd99e7b3639e6a724c75d94f5d57bffff53642ae31ff2` |
| O1/PRE_XML/stderr.bin | 0 | EOF | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| O1/PRE_XML/stdout.bin | 322683 | EOF | `58bf6fe17922c74a2a4db36af6993c51dc3056b0ac66d1edcb2bc731351c0493` |
| O1/FINAL/stderr.bin | 0 | EOF | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| O1/FINAL/stdout.bin | 322684 | EOF | `9931a1b4f3557eab3b1c162c926fa2cebc7b891156a6b544bae43f5f951f143b` |
| O2/stderr.bin | 12 | EOF | `4ad914216d8422916e61d3391d3d3110d29bbd535c11c1cd681226f2484a2134` |
| O2/stdout.bin | 10 | EOF | `9ad675c816aadcbd535a43cd9a5d4796cc51db06bb0439bc6635969deb11c6de` |
| O3/stderr.bin | 12 | EOF | `4ad914216d8422916e61d3391d3d3110d29bbd535c11c1cd681226f2484a2134` |
| O3/stdout.bin | 10 | EOF | `772a27831d4b3ff59bcf7a6332f7d8b8a269838ea103b36a9f330e66851f953c` |
| O3/inspector/stderr.bin | 12 | EOF | `4ad914216d8422916e61d3391d3d3110d29bbd535c11c1cd681226f2484a2134` |
| O3/inspector/stdout.bin | 13 | EOF | `20b11b509653a91e7f490ca96817a52cf0b4444fa219e571de40543b99651b12` |
| O4/stderr.bin | 12 | EOF | `4ad914216d8422916e61d3391d3d3110d29bbd535c11c1cd681226f2484a2134` |
| O4/stdout.bin | 10 | EOF | `46b366964117d804f1649de49300afb766c833f9f8daa787d29dd63e68c63309` |
| O5/stderr.bin | 12 | EOF | `4ad914216d8422916e61d3391d3d3110d29bbd535c11c1cd681226f2484a2134` |
| O5/stdout.bin | 10 | EOF | `a5e1b18c00b36ee1fd933f1f8d97b85901b758f45be9aa3df70fd06254ff00c6` |
| O6/stderr.bin | 12 | INCOMPLETE | `4ad914216d8422916e61d3391d3d3110d29bbd535c11c1cd681226f2484a2134` |
| O6/stdout.bin | 10 | INCOMPLETE | `ccd3c652a25cf3df10cb99e4d2d410e96aaddd5d1edb8b61e49318cdf48af3de` |

## Bounded conclusion

No acceptance blocker found for these seven prescribed OS-only conditions on
this one frozen run. model_admission=false, native_executed=false and
source_attestation=UNVERIFIED remain literal original result fields. Here
native_executed means the unrun R/CLR/scientific collector, not that Python or
macOS tools are nonnative binaries. S01–S17, original insulin and other required
scientific programs remain separate, unrun/not qualified by this result.
Any next native technical packet needs its own written, hash-bound authorization.
