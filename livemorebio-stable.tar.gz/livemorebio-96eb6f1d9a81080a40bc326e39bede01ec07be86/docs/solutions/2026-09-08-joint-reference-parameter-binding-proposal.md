# Named joint-reference parameter binding proposal

2026-09-08. **Proposal only; no registry, API, or executable binding implemented.**
Follows the approved source-core plan and its source-only audit. It does not close
R05/R19, the insulin program, or any whole-individual botanical program.

## Decision required

Keep a source-linked cohort inspectable without making it executable by default.
For the current three-state metabolic engine, the most precise available binding
candidate is `livemore.closed-loop-metabolic.screened-reference.v1`. Its provenance
would be **three source-derived initial-condition assumptions plus nine explicitly
authored reference parameters**, not twelve identified human parameters. It is
not an externally benchmarked author-model reproduction.

This candidate is useful for a separately reviewed engineering context, but it
does not yet satisfy a scientific release gate for predicting individualized drug
responses. Do not activate it merely because the source-data join is now working.
The preferred scientific release requires a named source-supported parameter
bundle, exact coefficient/table lineage and an independent dynamic benchmark.

## Exact candidate values and source

The existing `engines/metabolic/glucose_insulin.py` at source SHA-256
`84f6496d033e8a303f3caf1c6af97a80ef2a583b96084cfd643b7035663853c1`
declares the following values in `MetabolicProfile`/`HEALTHY`. That code describes
them as illustrative, literature-typical, not cohort-fitted. Its general citations
to Bergman 1979/1981 do not establish a per-coefficient source for the complete
added pancreatic/oral-absorption system. No paper-table attribution is inferred.

| Parameter | Proposed value | Unit | Provenance and boundary |
| --- | --- | --- | --- |
| `weight_kg` | Same member's BMXWT | kg | Released body weight with source comments. Using it to scale a model distribution volume is a separate model assumption. |
| `Gb` | Same member's LBXGLU | mg/dL | Released fasting glucose. Using one fasting observation as the model's basal set point is an initialization assumption, not a fitted equilibrium. |
| `Ib` | Same member's detectable LBXIN | uU/mL | Released fasting insulin. Using it as basal insulin is an initialization assumption; no mass/molar conversion is introduced. |
| `SG` | 0.026 | 1/min | Unmeasured, fixed internal reference coefficient; not inferred from HbA1c. |
| `p2` | 0.025 | 1/min | Unmeasured, fixed internal remote-action decay coefficient. |
| `Si` | 0.0005 | mL/uU/min | Unmeasured internal reference insulin sensitivity; not derived from HOMA or independently sampled. |
| `gamma` | 0.12 | uU/mL/min/(mg/dL) | Unmeasured coefficient in the added secretion loop; not measured beta-cell mass or function. |
| `Gt` | 100 | mg/dL | Internal model secretion threshold, not an individual's measured threshold. |
| `n` | 0.14 | 1/min | Internal insulin-clearance coefficient; not inferred from age or kidney status. |
| `ka` | 0.020 | 1/min | Internal oral glucose appearance coefficient; not individualized gastrointestinal transport. |
| `f_bioavail` | 0.75 | dimensionless | Internal oral glucose availability assumption; not insulin or botanical bioavailability. |
| `vg_per_kg` | 2.0 | dL/kg | Internal glucose distribution-volume coefficient; not a measured anatomical volume. |

The candidate's first three values must carry both their original
`PUBLIC_REFERENCE_MEASUREMENT` lineage and a distinct
`SOURCE_DERIVED_INITIALIZATION_ASSUMPTION` mapping. The nine remaining parameters
must carry `INTERNAL_REFERENCE_ASSUMPTION`, the exact bundle/source digest, units,
and an explicit absence of person identification. A source measurement is not
relabeled as a clinical observation merely because it initializes an equation.

HbA1c, age, reported sex and questionnaire answers remain reference attributes or
eligibility inputs; they do not determine `Si`, secretion, renal function, genetic
variants, disease type or hidden tissue states. No genotype default is allowed.

## Equation applicability and mathematical preconditions

The current engine contains three ODE states: glucose `G`, remote insulin action
`X`, and plasma insulin `I`. It uses

```text
dG/dt = -(SG + X) G + SG Gb + Ra(t)/(vg_per_kg * weight_kg)
dX/dt = -p2 X + (Si * p2) (I - Ib)
dI/dt = gamma max(0, G - Gt) - n (I - Ib)
```

`Ra` is the existing oral-carbohydrate appearance model. It is not injectable
insulin PK, a botanical absorption model, a receptor network, or a gene/protein
expression model. The candidate must not be routed to those intervention types.

For zero input and initial `(G, X, I) = (Gb, 0, Ib)`, all three derivatives are
zero only if `Gb <= Gt`. The screened source definition has glucose below 100,
so it satisfies this particular mathematical condition with the candidate
threshold. That establishes an equilibrium of these equations, not evidence
that a single NHANES fasting observation identified the person's physiology.

The broader source definition includes higher fasting glucose. Blindly using
the same threshold can cause secretion at the declared baseline. It must remain
unbound rather than being relabeled type 2 or silently changing `Gt`. A different
context requires its own reviewed parameter/equilibrium definition and evidence.

No parameter noise, sensitivity draws, allele frequencies, ad hoc clearance
factors, endpoint scripting, or retrospective fitting to a desired result are
part of this proposal. Different source initial conditions are not sufficient
evidence of identified person-specific response functions.

## Required integration and red tests after a binding is approved

1. A source-linked cohort has an immutable construction digest, source definition,
   unchanged measured tuples and **no executable binding by default**. Inspection,
   cohort pagination and history work without physiological parameter fallback.
2. A separate binding record names a reviewed bundle and intended context, its
   parameter/source digests, all mappings and assumptions, supported perturbations,
   numerical tolerances and qualification state. UI, SDK and CLI use the same API.
3. Execution requires that explicit binding. All twelve parameter slots are
   resolved without `initialize_profile` filling silent defaults; unknown inputs,
   missing genotypes, unsupported interventions and failed baseline checks block.
4. A run freezes both cohort construction and binding hashes. Editing source
   records or bundle values cannot modify a historical run or its replay.
5. Red tests cover no-binding rejection, wrong-context rejection, all-12 completeness,
   zero-input equilibrium, units/finite/positive-domain checks, member-specific
   initialization, mismatch of source/binding/run hashes, unchanged source tuples,
   no fallback type assignment, and no clinical/device admission from source data.
6. Biological output may expose only the actual integrated quantities and their
   recorded time grid. Anatomy remains reference geometry. No organ, cell or
   molecular activity is invented from a whole-body glucose/insulin value.

Before activation, add an independent dynamic reference dataset and preregistered
per-quantity acceptance, not just equilibrium/unit tests. The existing core's
general literature attribution is not enough to assert that these nine exact
coefficients represent all selected people.

## Native insulin route is a separate gate

The inspected OSP source has much richer structure, but the current
[Stage B report](../OSP_INSULIN_STAGE_B_RESULTS.md) fails its preregistered
full-state numerical/domain acceptance. It must not be substituted as an already
qualified binding for NHANES records. Correcting that source/version and validating
its native state semantics precede cohort identification or dose personalization.
The public fasting tuples alone do not identify its tissue geometry, sensitivity,
clearance, receptor states or injectable formulation parameters.

## Recommendation

Approve the source-linked descriptive cohort lifecycle first, with execution
visibly unavailable until a separate binding passes review. Do not claim the
internal-reference candidate is a published, fitted, or clinically validated
human model. Keep the complete biological-person objective active while obtaining
the missing dynamic identification and model-specific evidence.
