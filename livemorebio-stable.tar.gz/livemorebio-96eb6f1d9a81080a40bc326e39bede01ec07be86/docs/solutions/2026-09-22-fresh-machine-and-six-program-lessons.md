# Lessons: why a 6,416-test pass was not evidence, and what made the six programs executable

Date: 2026-09-22. Branch `codex/real-systems-continuation`, parented on
`codex/full-scope-recovery` at `0cfdd85`. Compounded per the project's
post-task rule so the next contributor does not repeat these.

## 1. A green suite on the author's machine can be an artifact of the author's machine

The September 9 checkpoint reported 6,416 passed. On this same laptop with an
empty `HOME`, the same commit failed 54 tests. On Linux CI it failed 988.

Three independent causes, each invisible locally:

| Cause | Why it hid | Correction |
|---|---|---|
| 20 test modules hardcoded `/opt/homebrew/bin/node` | The path exists on the author's machine | `livemorebio/_toolchain.py` resolves the environment first; `livemorebio/tests/_node.py` skips with a reason when Node is absent |
| Inline Node programs exceeded the Linux per-argument limit | macOS allows larger arguments | Oversized programs spill to a file **in the child's working directory**, preserving relative `require` resolution |
| `security._load_secret` falls back to `~/.livemore/*.key` | The author's real keys were present | `livemorebio/tests/conftest.py` gives every session a private data directory and ephemeral keys |

**Rule.** A test suite that reads real key material is not isolated, and its
result is not portable evidence. Run the suite at least once with `HOME` set to
an empty directory before quoting a pass count as verification.

**Rule.** The installer verifies with `python -I`, which ignores every `PYTHON*`
environment variable. Use `-X utf8`, not `PYTHONUTF8`, when the child must not
depend on the host locale.

**Rule.** `Path.mkdir(mode=...)` is masked by the process umask. A permission
test that creates a 0755 directory under `umask 077` silently tests nothing.

## 2. A withdrawn dependency version breaks installation everywhere at once

`libcellml==0.7.0` was removed from PyPI. Because the lock is hash-pinned,
`pip install --require-hashes` failed before installing anything, so the
published one-line installer could not complete on any machine. A lock file is
not durable evidence that an install still works; only a periodic fresh install
proves that.

## 3. The six programs were blocked by missing capability, not missing data

The endocrine engine (Bergman minimal model) has no exogenous insulin input at
all, and `interventions.plant_compound` raised unconditionally. No amount of
literature would have produced a result, because there was no execution path.
The OSP native route's failure had obscured this: it looked like one hard
blocker when there were two separable ones.

**Rule.** Before sourcing data for an experiment, check that the engine can
represent the intervention. State the missing capability as its own work item.

## 4. Choose the smallest question that can be answered and can fail

For the botanicals, the executable question is the exposure margin: does modelled
unbound exposure of a declared material reach the concentration range at which
its declared mechanism was measured? It is computable from published sources,
it produces a negative result when the answer is no, and it names precisely the
missing measurement when it cannot be computed at all.

Outcome across the five: one margin computable (arctigenin, below the measured
range at 400 mg), one exposure-only (erinacine A, no admitted active range), and
three blocked with exact reason codes.

## 5. Publish the inconsistency instead of fitting it away

For cyanidin-3-glucoside, the published parent-compound t-max (1.8 h) and
half-life (0.4 h) cannot both hold under one-compartment first-order kinetics,
which caps t-max at `1/ke` = 0.58 h. Two tempting moves were available: silently
reinterpret the half-life, or fit the parameters. Both would have manufactured a
number. `source_consistency()` returns the numbers and the cap and refuses the
run with `SOURCE_PARAMETERS_INCONSISTENT`.

**Rule.** A refusal carrying an exact reason code is a better deliverable than a
plausible number. Encode the refusal in the code path, not only in prose.

## 6. Controls belong inside the result, not in the test suite

Every protocol result carries its own analytical controls: a zero-dose arm that
must reproduce the untreated arm exactly, and a conservation identity (insulin
mass balance; integrated exposure against dose over apparent clearance). They
travel with the frozen run and its exported notebook, so a reader who never runs
pytest can still see that the controls passed.


## 7. A portability fix is not done until every call site uses it

The first pass fixed the twenty test modules that hardcoded the author's Node
path. Linux still failed 98 tests, because a further thirteen modules spawned
Node through their own local helper: they resolved the executable correctly but
still passed the program inline, and Linux caps a single argument at 128 KiB.

**Rule.** When replacing a machine-specific mechanism, search for the
*behaviour* (`subprocess.run([... "--eval"`), not only for the literal string
that was wrong. Route every call site through one helper so the next fix lands
once.

Two related traps in the same area:

* A helper that spills a program to a temporary file must place it in the
  child's working directory. Relative `require` and `__dirname` resolve against
  the script's location, so a file in the system temp directory silently changes
  module resolution.
* Importing that helper with a bare name collides with test modules that already
  define `run_node` locally, which turns the call into silent recursion. Import
  it under a private alias.

## 8. Load-dependent CI failures can be real product races

A background-scheduler test failed only on the CI runner, at `close()`, with
`EXECUTION_CONFLICT`. It was not flakiness in the test: `ExecutionManager.close()`
treated "another thread is already releasing this execution" as a control
conflict, so a clean shutdown under load reported a failure. The conflict code
is correct for operations such as resume, so the correction is scoped to
shutdown: wait for the other thread's cleanup to confirm, and only then continue.

**Rule.** Before dismissing a CI-only failure as environment noise, read the
production code path it exercises. A race that needs a loaded machine to appear
is still a race.

## 9. What is still failing, and why it is recorded rather than patched

After this work the CI matrix went from 988 failures on Linux and 85 on macOS to
33 and 32 (8 and 7 distinct tests, the rest being parametrisations). Every
remaining one was already failing before this branch, and all belong to the same
atlas browser-harness family.

Linux, run 35701114449:

```
test_atlas_metadata_delivery.py::test_mounted_shared_orchestration_joins_delivery_or_rejects_before_other_terminals
test_atlas_reference_ui.py::test_mounted_reference_cancels_hidden_load_and_restores_same_source_retry_state
test_atlas_renderer_review.py::test_missing_drawn_and_context_lost_controls_publish_real_availability
test_atlas_renderer_review.py::test_partial_geometry_disables_only_unavailable_source_partition_controls
test_atlas_skin_terminal_diagnostic.py::test_actual_runner_teardown_alarm_freeze_failure_is_not_relabelled_success
test_atlas_skin_terminal_diagnostic.py::test_actual_runner_teardown_attribution_and_primary_failure_preservation
test_atlas_skin_terminal_diagnostic.py::test_actual_runner_terminal_collection_or_bounded_stall_keeps_partial_evidence
test_atlas_view_status.py::test_failure_recovery_and_changed_manifest_restore_only_current_settings
```

macOS, same run: the three skin-terminal tests, the metadata-delivery test and
the reference-UI test as above, plus
`test_atlas_group_search_ui.py::test_unloaded_heart_results_remain_counted_but_disabled`
and `test_atlas_view_status.py::test_retry_retains_isolation_but_does_not_claim_unloaded_element_displayed`.

The two platform sets overlap but are not identical, and they shift between
runs, which points at timing rather than a fixed environment difference.

Ruled out so far: the machine-specific Node path, the Linux argument ceiling,
the developer's key files, the absent UTF-8 locale, the umask-masked permission
fixture, the macOS-only temp path, and the missing Playwright package. Also
checked: the suite passes with an empty home directory, under both the local
Node major version and the runner's, in isolation, in the full suite, and with
the atlas suites run under saturating CPU load.

**Rule.** Do not "fix" a test you cannot reproduce by loosening its assertion.
That converts a real unknown into a silent one. Record the exact list, the
environments checked and what was ruled out, then leave it open until it can be
reproduced with diagnostics on the runner itself.
