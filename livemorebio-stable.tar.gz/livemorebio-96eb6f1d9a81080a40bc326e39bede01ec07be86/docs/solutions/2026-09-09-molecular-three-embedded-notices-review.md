# Molecular viewer: three embedded-source notice associations

2026-09-09, release_redteam. Bounded independent source/terms review of
gl-matrix, ColorBrewer and chroma.js only. Read the complete
`2026-09-09-molecular-build-stats-closure-diagnosis.md` first. Source_research
owns the remaining embedded families and adapter review.

**Result: complete notice-input association is available for these three
adaptations in the exact Molstar4.4.0 source. This is not emitted-bundle release
acceptance or a legal guarantee.** The exact original upstream release used
by Molstar for gl-matrix/chroma is not declared. Do not relabel the adaptations
as whole installed copies of the reference tags below.

The important additional condition is ColorBrewer's original export notice:
the generic Apache2.0 body alone omits its specific end-user acknowledgment,
non-endorsement and product-naming conditions. Retain both original bodies.

## Evidence scope and acquisition

Private evidence root, newly created and not a consumed build input:
`/private/tmp/livemore-molecular-three-notices.8ISHwt`.

`source-reads.json` records all23 individually bounded primary HTTPS reads,
exact URLs, HTTP200 observations, raw byte counts and SHA256s. Each curl read
used `--proto '=https' --location --fail --max-time 15 --max-filesize 1048576`.
There was no automatic retry. Three initial web previews located the terms;
the retained originals are the direct raw responses, not web-rendered copies.
Root explicitly approved public-source HTTP fallback after the previously
documented browse exit137; this review did not launch or repair a browser.

No package JavaScript, npm, build, native model, service, operational store or
browser ran. No product, installed-source, archive, stats or consumed-run file
was changed. Python below only parses JSON/tar/text and writes its own new
derived receipt. It does not import, evaluate or execute acquired JavaScript.

Original Molstar archive:
`/private/tmp/livemore-molstar-inspection.uCgWWp/molstar-4.4.0.tgz`, SHA256
`d5c294fb5a87650c70a3012636b0060d60faca2e8542e3fd9a051df9678e06d5`.

Actual installed root:
`/private/tmp/livemore-molecular-offline-monitor.2Ds7TZ/node_modules/molstar`.
The seven JS files below, package.json and LICENSE were individually compared
with the same regular members of that archive, exact full-byte equality9/9.
The package manifest declares molstar4.4.0 and the Molstar repository; it has
no gitHead field. Source_research supplied the package upstream commit
2b2dfd924589edce7b129e123323c87a4623bdb8 separately. This review does not use
that report as a substitute for the checked archive bytes.

Retained `QkgKLS/A/stats.json`, SHA256
`e783538f445d407393632567c9dd5c58254c9bc64bb87c562f47123cc1db4df2`,
lists all seven under emitted concatenated chunk792. Inherited parent chunks
were followed, not only each child's empty chunks array. This establishes
source-module membership, not that every comment/function/data row survives
minification or is exercised. Conservatively retain each applicable notice.

| Path relative to installed Molstar root | Bytes | SHA256 |
|---|---:|---|
|lib/mol-math/linear-algebra/3d.js|1104|14f9bdf63174f0e77111940cbf0614075352a06e781c38f213f639431a96f37d|
|lib/mol-math/linear-algebra/3d/common.js|913|03cae4f467a1829db568698ead7b2a8e6854510e89c7cce2f134a6a5eb5e0de0|
|lib/mol-math/linear-algebra/3d/mat4.js|39526|3c8cf90fbdb2d81d13580f7b68c4083a8071496cbab1e460dacd8fc1b40f980d|
|lib/mol-math/linear-algebra/3d/vec3.js|21352|7adcd6db60d78ac11e3b0738f2a640d09e5fc71b56af3c351a2de221dd3b5fbd|
|lib/mol-util/color/lists.js|11767|7edfeb56de2987876aa3ceb23b99c5d45b3febaac7e0b4c0b6f7810a9eaf5520|
|lib/mol-util/color/spaces/hcl.js|3076|9b7efc93a582e7df49889fed31908b3a3d2d236f94d25dc3c89acf4a80544c0f|
|lib/mol-util/color/spaces/lab.js|5024|9133bcd242017c6abcb738acc465a11499abbc19f31a8cd081e3398302ae7e94|

## gl-matrix

All four installed headers explicitly say modified from the toji/gl-matrix
repository and credit Brandon Jones and Colin MacKenzie IV, copyright2015.
Their identical comment fragment SHA256 is
`1038ad5787ff03d7783dc8c80645eea6f8c91848c7e9e873419fd07cfa187555`.
It ends immediately before the copyright-retention requirement and warranty
disclaimer, so it is not a complete MIT notice.

The primary [v2.3.2 MIT license](https://raw.githubusercontent.com/toji/gl-matrix/6723211d7adcde84f4b3f5cfc9c3f75eb8acaccb/LICENSE.md)
and the full headers of that commit's vec3.js/mat4.js carry the exact same
2015 holders and the complete permission, retention and disclaimer text.
All these complete notice bodies were personally read. Retained annotated-tag
metadata maps v2.3.2 through tag b5a732b58d7547f138bb4f3e49d53038e6c0fdab
to commit6723211d7adcde84f4b3f5cfc9c3f75eb8acaccb, dated2016-02-24.
It is an unsigned tag, not a signature attestation.

Source witnesses strengthen the association beyond a label: Vec3.dot,
Vec3.cross and Mat4.determinant bodies match that primary code after removing
whitespace/line comments and normalizing only const/var declaration tokens.
The original bodies were read; normalization is explicitly not byte identity
or a proof of complete-library equivalence.

For eventual NOTICE, retain the full MIT body, both upstream holders and the
Molstar adaptation statement. The Molstar file headers separately credit
David Sehnal and Alexander Rose; 3d/common date2017–2019, mat4 dates2017–2020,
vec3 dates2017–2023. Molstar's own full MIT remains independently applicable.
Do not claim Molstar imported v2.3.2 exactly: no retained source states that.

## chroma.js

Both installed HCL/LAB headers explicitly identify chroma.js adaptations,
Gregor Aisch, copyright2011–2018, and BSD. Their Molstar adaptation headers
credit Alexander Rose, copyright2019–2023 Molstar contributors.

The complete primary [v2.0.3 LICENSE](https://raw.githubusercontent.com/gka/chroma.js/d88e5cf877e77b985fa3eca12915b405101cf335/LICENSE)
was read in full. Its first section is the matching-holder BSD3 text: source
notice retention, binary distribution notice reproduction, named-author
non-endorsement and the complete disclaimer. It also retains separate
ColorBrewer and X11-color references; the complete original is preserved,
not silently converted into a generic BSD template.

Retained annotated-tag metadata maps v2.0.3 through
c252265720c93f8ea1ef38c5a73fb2a26f287bcd to
d88e5cf877e77b985fa3eca12915b405101cf335, dated2019-02-16, unsigned.
Seven small primary files were personally read in full: lab-constants,
lab2rgb, rgb2lab, lab2lch, lch2lab, darken and saturate. The eight D65/threshold/
brightness constants match exact numeric spellings. Both RGB/XYZ matrices,
NaN-hue behavior, hue rounding and chroma/lightness operations give matching
source-level witnesses, with Molstar's explicit out-parameter/clamp/API
adaptations retained, not described as unmodified upstream code.

The lch2lab source and Molstar HCL conversion preserve the specific attribution
to David Dalrymple for the formulas and Gregor Aisch for the saturation
multiplier. Retain that credit alongside the copyright/BSD notice; do not
invent an additional license or assert that the credited formulas are novel.

Use “color-conversion adaptations from chroma.js in Molstar4.4.0” in inventory
wording. v2.0.3 is a pinned source/terms witness, not an established imported
version. This slice does not grade Molstar's separate named-color/X11 tables.

## ColorBrewer

Installed lists.js lines10–58 identify Brewer palettes, copyright2002 Cynthia
Brewer, Mark Harrower and The Pennsylvania State University, Apache2.0.
Several descriptions explicitly name ColorBrewer2.0. The read primary
[repository README](https://raw.githubusercontent.com/axismaps/colorbrewer/7d135fc4e19eda73f2eb1bf55fcdf4a04fe4881f/README.md)
identifies colorbrewer2.org and Axis Maps; the retained primary source is
pinned to commit7d135fc4e19eda73f2eb1bf55fcdf4a04fe4881f, not a floating
master URL. Its scheme-file header credits Cynthia Brewer's color designs.

The data check reads literals without JS execution: all35 standard palettes
match their upstream RGB triplet lists exactly after lossless RGB24 encoding,
same order. They are18 nine-color sequential,9 eleven-color diverging and
8 qualitative palettes (8/9/12 colors). The36th Molstar “many-distinct” list
is exactly Dark2[8] + Set1[9] + Set2[8], in order,25 colors. The JSON receipt
retains every target name, upstream name/count, complete integer values and
comparison result. This is a source-data witness, not a perceptual validation.

Personally read both complete original notices:

- [Root LICENCE.txt, Apache2.0 full terms](https://raw.githubusercontent.com/axismaps/colorbrewer/7d135fc4e19eda73f2eb1bf55fcdf4a04fe4881f/LICENCE.txt).
  Preserve the license, applicable attribution, modification notices,
  warranty/liability text and its patent/trademark conditions.
- [export/LICENSE.txt, ColorBrewer-specific original](https://raw.githubusercontent.com/axismaps/colorbrewer/7d135fc4e19eda73f2eb1bf55fcdf4a04fe4881f/export/LICENSE.txt).
  This1710-byte file names the same2002 holders and states Apache2.0, then
  adds numbered conditions1,2,4,5. Preserve that original numbering. It requires
  source-notice retention and an end-user documentation/software acknowledgment
  crediting Cynthia Brewer's color specifications/designs and colorbrewer.org.
  It also restricts endorsement and use of ColorBrewer in derived-product
  names without permission. Do not omit those conditions or reduce this
  document to an SPDX label.

The complete, untruncated895-entry primary Git tree contains these two
license paths and no filename containing NOTICE. That is a filename/tree
observation, not a claim to have read every unrelated website asset.
The acknowledgment required by export/LICENSE.txt exists regardless of the
absence of a separately named NOTICE file. Do not title Livemore's viewer
ColorBrewer or imply endorsement. Retain the Molstar modification/conversion
context, including the combined palette, in the eventual third-party section.

## Retained original terms and reproducible check

Paths below are relative to the new private evidence root. `source-reads.json`
has the complete URL/path/hash map for all23 primary responses, including
the source witnesses and tag/tree metadata.

| Original body | Bytes | SHA256 |
|---|---:|---|
|gl-matrix-LICENSE.md|1078|e8b80a53d0f95a3cf0f992f8cfc6b3911a7f32f47e0e4a8d4fd66582eeae9484|
|chroma-LICENSE|2418|2e77193e93436b4261058a553ac432a8ed5087fff89b9cf4f03801bd7343fcaa|
|colorbrewer-LICENCE.txt|11357|b40930bbcf80744c86c46a12bc9da056641d722716c378f5659b9e555ef833e1|
|colorbrewer-export-LICENSE.txt|1710|aba881933999be3549b2171832a11a9dfad574243019df95c067ccf3d47b9649|

Molstar's original full MIT is separately retained at notice index164:
`/private/tmp/livemore-molecular-archives-final.dKZYOa/run/000/eabd1831ed605a29cf9d7e60221c019c1bc026add81e3c0686ce5f24b3d4d500.blob`.
Its1108 bytes/SHA256eabd1831ed605a29cf9d7e60221c019c1bc026add81e3c0686ce5f24b3d4d500
match installed LICENSE and the exact archive member. Full body read.

The fixed data-only method is `check_associations.py`, SHA256
e5994493f5a4fa92afb14ce1d0094024ba0d836dad8b149947b18b2bf0a83fee.
One initial analysis attempt correctly stopped on an accidentally overbroad
section delimiter, matching magma against the Brewer input. The delimiter was
corrected to the actual “Matplotlib colormaps” heading; no source data or
acceptance comparison was changed. The corrected check completed in0.499s:
9 exact original files,7 emitted memberships,3 gl-matrix body witnesses,
36 palette matches and8 exact chroma constants. This is not a product test.

`associations.json`:33046 bytes, SHA256
9615dbce95ee1be054a1d2f207ccc98f8580d1cfab5c0dbfaae40b1307878651.
It predates the final two ColorBrewer reads; those are separately included in
`source-reads.json`. The checker creates the receipt exclusively and refuses
to overwrite it. Reproduction must use a new output path/copy, not erase the
retained original. No author-supplied JavaScript is executed by this method.

## Remaining gates and lesson

Ready to supply the exact bodies/credits for a reviewed NOTICE assembly.
Not yet done: assembly/inspection of actual redistributed notices, remaining
embedded families, new output-to-source closure, reproducible two-build
acceptance, wheel/publication and actual viewer acceptance. Original
QkgKLS/A FAILED FILE_BOUND and B NOT_RUN remain unchanged; this review does
not revise them or grade a later build.

The exact originating gl-matrix/chroma releases remain unknown. That is an
explicit provenance limit, not permission to fabricate release versions.
The notice recommendation rests on Molstar's explicit project/holder/year
adaptations plus pinned full terms and matching code witnesses. If a later
release policy requires the original upstream commit rather than this
adaptation identity, that additional provenance question remains open.

Lesson: a top-level package license and a minifier's comment sidecar are not
embedded-source notice closure. Inspect source-specific terms and export
notices. ColorBrewer's extra acknowledgment illustrates why identifying the
correct license family is only the start, even when palette values match.
