# Five botanical programs: mechanism and measurement dependency packet

Date: 2026-09-08. Status: PROPOSED, awaiting root review before implementation.
Parent: [full-scope recovery](2026-09-08-full-scope-recovery-plan.md).
Source/material record: [OSP and candidate sources](../OSP_INSULIN_AND_CANDIDATE_SOURCES.md).
This packet narrows the next scientific dependencies; it does not remove any
R01–R51 obligation or count an isolated assay as an individualized-human program.

## 1. Decision

Retain all five selected programs. Build exposure and tissue-mechanism contracts
before connecting compound inputs to body-state outputs. A reference molecule,
reported endpoint, mechanistic equation and physical validation dataset are four
different objects. No current source admitted in this review supplies a complete
individualized-human response model for any of these five materials.

The immediate executable opportunities are **source-model reproductions**:
the already executed OSP insulin feasibility, a proposed Nrf2 source-admission
probe, and a proposed mitochondrial reference-model probe. They are dependencies
of future programs, not replacement experiments. The C3G population-PK lead has
material-dose and random-effect ambiguities and must not be operationalized as a
measured individualized exposure model.

## 2. Exact reference identities and program questions

These are root-verified PubChem identities, not authenticated plant batches.
Keep isolated compounds separate from extracts and metabolites. The C3G record
is a flavylium cation, not a chloride-salt batch or a guarantee of pH stability.

| Program | Reference identity | Program question, including null/adverse results |
|---|---|---|
| Lion's Mane, LBHR-172 | Erinacine A; [CID10410568](https://pubchem.ncbi.nlm.nih.gov/compound/10410568); C25H36O6; `LPPCHLAEVDUIIW-NLLUTMDRSA-N` | Does an authenticated material reach its relevant neural compartment and change a specified neurotrophic endpoint without injury? Enriched mycelium, fruiting body and pure erinacine are different interventions. |
| Yerba Santa, LBHR-129 | Sterubin; [CID1268276](https://pubchem.ncbi.nlm.nih.gov/compound/1268276); C16H14O6; `DSAJORLEPQBKDA-AWEZNQCLSA-N` | Under matched exposure, which neural/glial redox and inflammatory responses occur, and where do protection, no response or injury occur? |
| Rosemary, LBHR-062 | Carnosic acid; [CID65126](https://pubchem.ncbi.nlm.nih.gov/compound/65126); C20H28O4; `QRYRORQUOLYVBU-VBKZILBWSA-N` | Resolve eicosanoid/redox effects and systemic exposure; preserve the CNS objective as an additional module requirement, not an inferred consequence of inflammation assays. |
| Burdock, LBHR-030 | Arctigenin; [CID64981](https://pubchem.ncbi.nlm.nih.gov/compound/64981); C21H24O6; `NQWVSMVXKMHKTF-JKSUJKDBSA-N` | Where does mitochondrial energetic inhibition produce adaptation versus energetic injury? Arctiin precursor conversion and direct arctigenin administration require different material/exposure models. |
| Bilberry, LBHR-135 | Cyanidin 3-glucoside; [CID441667](https://pubchem.ncbi.nlm.nih.gov/compound/441667); C21H21O11+; `RKWHWFONKJEUEF-GQUPQBGVSA-O` | Establish parent/metabolite exposure before a vascular or retinal endpoint. Pure C3G, black-bean extract and bilberry mixtures are not interchangeable. |

## 3. Primary evidence to admit, and what it cannot parameterize

### A. Erinacine-defined material: exposure → neurotrophic biology

The [2020 human pilot](https://doi.org/10.3389/fnagi.2020.00155) studied enriched
mycelium, with material characterization and participant outcomes. It is not a
pure-erinacine human PK experiment. Its discussion's erinacine-A BBB statement
relies on unpublished results; the cited published erinacine-S result concerns a
different molecule. Neither supplies an admitted human unbound brain curve.

Admit the material specification, HPLC method, cohort definition and measured
clinical endpoints separately. Do not translate cognitive scores into receptor
binding, neurogenesis rates or synapse creation. Required dependencies are
gut/liver disposition, unbound plasma and brain exposure, BBB transport,
neuron/glia context, and source-supported neurotrophic signaling. No complete
source executable with these parameters was located in this bounded review.

### B. Sterubin: exposure → cellular redox and glial inflammation

The [primary structural-comparison study](https://doi.org/10.3390/antiox11112197)
uses HT22 neuronal and BV2 microglial cell systems. Its Figures 2–4 provide
GSH, Nrf2-related expression and inflammatory perturbation evidence, including
knockdown comparisons. Those are assay-specific endpoints, not human neuronal
rate constants, absolute protein abundance or BBB permeability.

Admit time, concentration, species/cell line, perturbation, observer and replicate
structure with each endpoint. A later human neuron/microglia module needs its own
baselines, exposure mapping and kinetic data. The proposed Nrf2 baseline below
can establish executable pathway infrastructure, but cannot silently acquire a
sterubin input merely because both sources mention Nrf2.

### C. Carnosic acid: exposure → eicosanoid/redox response

The [mPGES-1 study](https://pubmed.ncbi.nlm.nih.gov/22511203/) reports a cell-free
IC50 of 5 µM and a whole-blood PGE2 IC50 of 9.3 µM. Its first assay uses a short,
cold microsomal context; its whole-blood experiments have their own pretreatments
and stimulation conditions. The compound was isolated from sage. Identity of a
pure molecule does not establish equivalent rosemary extract composition.

Admit assay conditions and concentration-response points from the primary figures
before considering any fit. Do not set Ki equal to IC50, invent a Hill slope,
turn a cold endpoint into a physiological-temperature reaction rate, or extrapolate
the observed selectivity to all inflammation. Required modules are eicosanoid
production/turnover, inflammatory-cell context, parent/oxidized-metabolite PK,
and BBB/neural context for the separate CNS question.

### D. Arctigenin: exposure → energetic adaptation or injury

The [AMPK/complex-I study](https://pubmed.ncbi.nlm.nih.gov/22095235/) spans muscle,
hepatocyte and mouse systems; it does not establish a human dose-response.
[Tumor-cell energetic injury](https://pubmed.ncbi.nlm.nih.gov/22687625/) is relevant
counterevidence to an unconditional beneficial-metabolic interpretation.

Required measurements distinguish parent and precursor/metabolites, concentration
at the mitochondrial site, oxygen consumption, ATP/ADP/AMP, redox state, membrane
potential, AMPK signaling and injury. These are proposed endpoints, not existing
Livemore measurements. A source energetics model can support a defined capacity
perturbation, but an arctigenin dose-to-complex-I rule remains absent. Human-GEM
flux capacity alone cannot supply that kinetic rule or predict cellular survival.

### E. C3G: parent and metabolites before tissue effects

The [human isotope-tracer study](https://pubmed.ncbi.nlm.nih.gov/23604435/) and
[follow-up metabolite analysis](https://doi.org/10.1111/bph.12676) provide measured
ADME/serum-metabolite evidence. Recovered isotope and labeled metabolites must
not be relabeled as intact-parent bioavailability. Admit individual analyte,
matrix, time, units, quantification limits and formulation before using the
published noncompartmental summaries. These sources do not supply a complete
individualized PBPK–endothelial–retinal model.

The [Jeon 2012 human PK paper](https://doi.org/10.4196/kjpp.2012.16.4.249) describes
12 healthy volunteers receiving black-bean extract. Table 3 reports an apparent
one-compartment model: CL/F=3420 L/h, V/F=7280 L, Ka=9.94/h and lag=0.217 h.
These are formulation-specific fitted apparent quantities, not anatomical organ
volumes, intrinsic clearance or demonstrated bilberry parameters. The extract's
C3G mass and the original NONMEM control stream were not found in the reviewed
article. Its prose and variance-table labeling do not unambiguously resolve Ka
between-subject versus between-occasion variability.

The [nlmixr2lib reconstruction](https://nlmixr2.github.io/nlmixr2lib/articles/Jeon_2012_C3G.html)
is a checked implementation lead, not the source authors' original code. It
back-calculates a 14.57 mg equivalent dose from observed AUC and fitted CL/F,
collapses the ambiguous Ka variability into one random effect, and renders NaN
AUC summaries because its initial sample is later than the integration start.
Consequently neither that dose nor its cohort is admitted. Using AUC to infer
dose and then compare the resulting AUC is not independent validation; AUClast
also cannot be silently substituted for the complete AUC in dose/clearance
identities. A dimensioned unit-input analytic check may later test software
mathematics, but it would not complete this material's PK program.

## 4. Narrow executable benchmark candidates before botanical coupling

| Candidate and source | Actual source state | Proposed first acceptance and remaining blocker |
|---|---|---|
| [OSP insulin](../OSP_INSULIN_NATIVE_FEASIBILITY.md) | Private native source recipe executed. Source shares the administered `Insulin` pool with endogenous insulin; this is not the separate `Insulin Ex` pool or a modern SC analogue. | Root's independent source/numerical review, prespecified convergence and reference comparison precede product wiring. R33 and all five botanical outcomes remain open. |
| [Nrf2 author model](https://doi.org/10.1038/s41598-022-10857-x) and [pinned repository](https://github.com/JetiLab/Nrf2-signaling/tree/5248764a169039e9b638f36b9924165370bac4a8) | MIT repository, commit `5248764a169039e9b638f36b9924165370bac4a8`. It contains condition, parameter, observable and measurement TSVs plus `model_model.rds`; no SBML XML, YAML manifest or executable reproduction script appears in the inspected full tree. Not downloaded or executed in this stage. | Admit original equations/export and source DEM/control conditions; reproduce author observables without fitting. Resolve the R object/export semantics and complete initial/condition mapping before calling this a PEtab/AMICI-ready model. Model context is HepG2 adaptation, not primary liver, neuron or whole-person biology. |
| [Beard 2005 mitochondrial CellML exposure](https://models.physiomeproject.org/exposure/959a4da5d8a0638f4b36adf5800f4fc0/beard_2005.cellml/view) | PMR exposure references workspace changeset `8ec69b34c31c`, CC BY 3.0, with curation notes about dimensional corrections and source reproduction. No local execution in this stage. | Pin exact CellML bytes/imports, validate dimensions, reproduce source conditions and compare published/native reference before adding any perturbation. Its preparation/context is not an individualized human arctigenin model. No compound-specific inhibition kinetics are supplied by this model. |

Nrf2-specific source-admission issues are concrete: the condition table contains
`Inf` for a DEM-specific parameter; this requires the author's limiting-equation
semantics, not replacement with an arbitrary large constant. Observable formulas
include scales/offsets and log transformation, so normalized fluorescence must
not become molar concentration. Nominal parameter values and estimation flags
exist, but cannot repair a missing executable initialization recipe by guessing.
The repository's measurement table is available even though the article's
broader data-availability statement directs requests to authors; distinguish
that exported table from unprovided raw imaging or source prediction goldens.

For each admitted model, register the exact equation version, state order,
units, boundary conditions, initial state, output transform, parameter provenance,
native runtime and numerical tolerances. Benchmark original inputs first. Then
introduce separately reviewed exchange ports; do not fit a botanical effect
until the relevant material-specific measurements exist.

## 5. Common measurement contract and cross-system work

The following records are required inputs, not invented completion values:

1. **Material:** taxon/part, extraction or isolated-compound identity, stereochemistry,
   salt/form, batch identifier, measured purity/content, stability/speciation,
   actual parent and metabolite concentrations with uncertainty and method.
2. **Exposure:** route/formulation and administered amount; total versus unbound
   plasma; time-resolved parent/metabolites; distribution, transport and clearance
   information adequate for the proposed organs. Do not infer all parameters
   independently from one sparse plasma curve.
3. **Tissue mechanism:** organism, cell/donor/tissue context, initial state,
   perturbation and matched controls, units, time and environmental conditions;
   distinguish independent biological donors from technical repeats. Concentration
   at the target site is not automatically the administered or plasma concentration.
4. **Observation:** raw/corrected value, units, collection time, assay/instrument,
   quality/calibration, detection/quantification limits, missingness, source hash,
   consent/permitted use and adjudication. Preserve below-limit data as censored
   where appropriate, not a fabricated zero or healthy default.
5. **Comparison:** freeze model, parameters, cohort definition and endpoint criteria
   before revealing an independent physical set. Holdouts must not have supplied
   the dose, model fit, parameter selection or acceptance threshold.

New body modules required across the programs include gut chemistry/absorption,
hepatic metabolism, renal elimination, BBB transport, neuron/glia signaling,
mitochondrial energetics, eicosanoid/immune regulation, and endothelial/retinal
responses. Their coupling must conserve the relevant mass/amount and reconcile
time scale, volume, free fraction and observer units. Expression context from
HPA/GTEx or tissue Human-GEM does not supply kinetic parameters by itself.

In Aegle, only executed state series may drive dynamic process views; a static
capacity result remains static. In Cendos, physical observations and modeled
predictions remain separate linked evidence. LIFE channels may observe only
qualified mappings with their sampling/quality metadata; these compounds do not
gain a physical sensor or tissue-state observer by being added to a catalog.

## 6. Staging and explicit release gates

| Stage | Deliverable | Cannot be claimed yet |
|---|---|---|
| S1: source admission | Reviewed, hashed source equation/parameter/observer packet and access rights; original native benchmark, no botanical coupling | Whole-human execution or an experimental candidate outcome |
| S2: exposure and context | Material-specific inputs, tissue context, sensitivity/identifiability assessment, separately registered boundary coupling | Clinical personalization from an arbitrary random seed or population average |
| S3: mechanistic program | Executable compound-specific pathway, matched initial conditions, explicit unsupported systems, conserved coupling and full provenance | Physical human equivalence or cure from a plotted trajectory |
| S4: independent qualification | Prespecified endpoint/tolerance/population/dose context compared with independent wet-lab and, where required, human observations | Transfer to other doses, populations, tissues or diseases without additional qualification |
| S5: prospective evaluation | Treatment-free follow-up, disease-memory and stress-resilience endpoints where relevant to the proposed indication | Proof of eradicated pathological memory from a transient biomarker change |

For the proposed Nrf2/mitochondrial S1 probes, write red tests for source/hash
failure, missing initialization, dimension/observer mismatch, invalid condition,
nonfinite solve and absent reference data before an adapter. Freeze numerical
acceptance before running: original benchmark agreement, tighter-tolerance/time
resolution convergence, finite/domain checks, correct zero-input/control behavior
and conservation identities only where that specific model supports them.
An independent reviewer must set or accept the comparison tolerances; arbitrary
clinical accuracy percentages are not defaults. No new S1 probe is executed by
this planning document.

## 7. Open dependencies, rights and lessons

The [shared access/runtime record](../OSP_INSULIN_AND_CANDIDATE_SOURCES.md)
retains Human-GEM/ftINIT expression preprocessing, Gurobi entitlement, standalone
Recon3D restrictions, PhysiCell coupling, AMICI runtime, All of Us and UK Biobank
access gates. None is removed because a native OSP run succeeded. Article access,
model-code rights, software licenses, solver entitlement and physical validation
are independent gates. Jeon 2012's article is CC BY-NC; that is not permission to
redistribute its figures commercially, nor a blanket assertion that private
inspection of numerical facts is prohibited. Retain source-specific rights review.

The practical next decision is approval of one S1 source-admission probe at a time,
while obtaining the five material/exposure packets in parallel. The Nrf2 export
requires reconstruction review before a native benchmark; the mitochondrial
model offers a clearer kinetic-format probe but no botanical input. Neither should
be advertised as completion of the requested five individualized experiments.

Compounded lesson: source-code availability can hide missing dose semantics,
ambiguous random effects, unavailable initialization and transformed observers.
A plausible graph or successful solver run does not repair those omissions.
Preserve them as explicit missing dependencies instead of calibrating around them.
