# Selection revisions — readable maximum versus incrementable maximum

2026-09-08. **Pre-code amendment; root must approve before implementation.**
This narrowly refines the shared stored-row reader used by the
[committed-transition interface](2026-09-08-committed-source-transition-interface.md)
and proposed [checked startup capture](2026-09-08-startup-checked-selection-interface-proposal.md).
No source, tests, registry or model was changed or run for this amendment.

## Source-proven mismatch

`MAX_SAFE_INTEGER` is `9_007_199_254_740_991`. The accepted
`test_last_incrementable_version_is_exact_and_cannot_be_incremented_again`
legitimately commits a record at that version by incrementing MAX−1.
Current `_transition_snapshot` nevertheless calls the strict incrementability
validator for every read row, which rejects MAX.

An unchanged reuse of that reader for startup would reject a legitimate terminal
version despite performing no version increment. The same defect affects an
unselected virtual/replay binding: its target can be incrementable while the
selected, untouched row is already MAX. That selected row must not block the
otherwise permitted operation merely because it cannot itself be incremented.

This is a source-traced pre-code issue, not a new numerical or live-store result.
No integer precision, mutation precondition or overflow guard is relaxed.

## Exact minimal implementation boundary

Separate these two questions without a second version authority:

| Use | Exact admitted values |
|---|---|
| Authenticated/index-coherent stored-row read | `type(value) is int` and `1 <= value <= MAX_SAFE_INTEGER` |
| Caller expected_version and every row actually incremented | `type(value) is int` and `1 <= value < MAX_SAFE_INTEGER` |

Keep existing `_transition_version` strict and its current error mapping. Add a
small private stored-read validator beside it, for example
`_transition_read_version(value: object) -> None`, using the inclusive bound and
the existing fixed storage error for malformed/out-of-safe-range stored values.
Change `_transition_snapshot` to use this read validator globally, not a special
startup-only bypass or flag. Keep its authenticated plaintext/index equality,
strict plaintext int, complete raw-row, pointer and ACTIVE checks unchanged.

`_transition_changes` must still call the strict incrementability validator for
**each row included in its after-records** before adding one:

- activation/binding target;
- selected row demoted by a different activation;
- selected row demoted by clear-for-preview.

Do not call that strict transformation validator merely because a row is part of
the read set. An unmodified active row remains exact readable evidence. Do not
clamp, wrap, coerce, reset a revision or invent a fresh identity to evade MAX.

The future `CheckedActiveSelection` field validation must use the same inclusive
stored-read rule. Capture/confirmation are reads, so MAX is valid when all exact
record/index/pointer/authority checks and audited completion succeed. Existing
strict direct/HTTP mutation expected_version admission remains unchanged and
rejects MAX before registry access. A stored MAX selected row that would require
demotion still rejects through the existing strict transformation path; this
amendment adds no new error code or response status.

Preserve the audit-phase correction's fresh live raw baselines. Neither reading
MAX nor rejecting an increment may rewrite its ciphertext, creation fields,
pointer, authority, audit payload or existing observations. Only the already
authorized metadata-only access audit may be added on audited read paths.

## Required red-first cases

Use authored private SQLite fixtures and inert caller/model doubles only:

1. Read an exact selected record at MAX through the shared reader after durable
   access admission. It succeeds without rewriting any clinical/index byte.
2. Checked startup capture and confirmation at MAX succeed with exact matching
   row/record/pointer/authority. Include ordinary known-model-shaped and unbound
   descriptive records without constructing a physiological model.
3. Target mutation at expected_version MAX still rejects before registry I/O,
   for both direct activation and binding; preserve existing strict body tests.
4. Activating another target when the selected row is MAX rejects because it
   would demote/increment that selected row. No target/demotion/pointer writes.
5. Clearing for preview when selected version is MAX also rejects without
   deleting the pointer or producing a replacement reference preview.
6. Unselected virtual binding with target version1 and selected version MAX
   succeeds once. Target becomes2; selected raw row, ciphertext, pointer and
   relevant preserved physical-index policy remain byte-for-byte unchanged.
   Repeat the same preservation case for replay mode or parameterize it.
7. The existing MAX−1→MAX target success remains, followed by rejected further
   target mutation. Do not change that test's expected stored maximum.
8. Bool, float, string, zero, negative and MAX+1 stored revisions still reject;
   authenticated/index mismatches remain errors even if one side is valid MAX.

The reader/transition cases belong in `test_committed_registry_transitions.py`.
The checked capture/confirmation cases belong in the separately proposed
`test_checked_startup_selection.py` when that helper is authorized. Do not make
the audit-phase correction silently implement startup or unchecked observation/
reconciliation API migration. Root owns later server source/publication tests;
unselected binding's no-generation-change contract remains separately required.

## Ownership and review

Proposed runtime write set: the small validator and shared read call in
`subjects.py`, plus using that same rule in the future checked type validator.
No strict_json/parser change, new timestamp, schema, counter, model input, source
equation, physical qualification, service or browser operation is needed.

Root requested this written refinement after independently agreeing with the
source-proven edge. It is not implementation approval or maker grading. The
registry owner must retain audit-phase work separately until root approves this
increment, then capture reds and obtain independent review. R01–R51, six programs,
prior failed receipts and all scientific acceptance gates remain unchanged.
