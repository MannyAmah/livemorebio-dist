# Navigation-first session implementation receipt

Date: 2026-09-09. Maker: release_redteam. Root-approved scope is
[the navigation-first plan](2026-09-09-navigation-first-session-plan.md).
This is maker evidence only; independent source/test review and root-owned real
browser acceptance are required. No browser/service/native/solver was launched.

## Exact source change

Six runtime files only. [Exact source delta](2026-09-09-navigation-first-session-source.diff)
was derived from pre-edit bytes retained in the tool session and current files,
not from HEAD or an invented historical checkout.

- security: optional frozen document-path set in the existing response hook.
  Issue only on status200 text/html, GET, exact local navigation metadata.
  Reject duplicate Host/metadata/Origin and malformed or different Origin tuples.
  Explicit port0 is not silently replaced with a default port. Credential
  retrieval failures leave the static shell usable without a cookie.
- server: opt in the nine planned documents; old bootstrap always fixed410/no-store,
  with no token lookup or issuance.
- auth.js:20-line passive button mount; no fetch replacement, request, timer,
  credential access or automatic recovery. User click reloads the same document.
- workspace/protocol_biology: remove only their session-ensure waits.
- patch: user recovery reloads once and does not unpause/replay the old read.

Existing bearer/cookie validation, comparison, CLI credentials, scientific context,
model/consent gates and other source files are unchanged. Cookie remains the
existing operator credential, not a newly time-bounded session. Header-only
loopback authority is not a public deployment guarantee.

Installed primary API source read before coding: FastAPI0.141.1
applications.py4683–4726 (middleware), Starlette1.6.0 responses.py1–191
(Response/HTMLResponse/JSONResponse/set_cookie), datastructures.py497–550
(Headers/getlist). Context7/gbrain/CE were not callable; no claim they ran.
Root's written architecture plan and independent pre-code review were reused.

## Current runtime SHA-256

```text
security.py d65f28049c19e5d6e736b841b4835e300e04e7412090283b41d294d58df4f2b6
aegle/server.py 12153128b250a5632e4db85a54420e7db2c427483336b1aa32e93e52f7407f67
console/lib/auth.js d2aa63edd56a914bb2f49d315b8da1a7583a146d9e48326f4461060891ac3488
console/lib/workspace.js 26738bb44878384e19ac54118a1e7c96e6696cfbf2cdce429501f55c267f6e44
console/lib/protocol_biology.js 4353bdcdbfa0421d0ab93beea177bafbfadf551ea8b6984ae7376c6b962a108d
console/patch.html cf402afe8db317ec289cc1397f0f103e7bec039d5ebdb335373dd0b23a8c9cab
```

Paths above are under livemorebio/ (console paths under aegle/).
Pre-edit hashes, in the same order:
f213d7ac1836636a0b0eabd35c8f48f263129289897e631efdcf8b6ad27b5006,
d3214fb8d2e3c738b37799b0c837ab7614248c39b6ee3ba78b9c9df2135d991b,
4e5130f476ce0a3a3a0d0096986985cbdd2ecbf7131afbe3e89d7a7430996bf3,
1bb39afbda46a04ada6763dc9997ae023ee964ae7b9b76c0c67069386a1242f5,
0b59d25e6e6109420b4138d5d787ee765185e335ccd8e38d028873a36579a1a8,
e851a2eb8a7b586c9dcb6b68c6b6822b14086023c4555e6a3a01fd9348b16de9.

## Test changes and history

New current suites:56 ASGI/middleware cases plus10 UI cases (8 mounted Node,
2 source-consumer checks). Actual nine document handlers and protected read
authorization run without TestClient lifespan; the only registry read result is
authored, and actual compiler/model constructors are denied.

SHA-256 under livemorebio/tests/:
```text
test_navigation_session.py e6ffa337add5c974cc84c7068c354d0006ab5b7a226635bf4d174606bffa0a15
test_navigation_session_ui.py 32260c5d43c4916c2c463f2cbce5375337ab381931c91d8a18aa42fb2aafd2f8
test_browser_session_bootstrap.py 928a219b9353457c0def2243767f5a76af139d2b639104b377682d166128f811
fixtures/auth_bootstrap_historical.js 4e5130f476ce0a3a3a0d0096986985cbdd2ecbf7131afbe3e89d7a7430996bf3
test_subject_lifecycle.py 1bbe242212a7cd6f5ef9768145981c73fb81117e38e2673e0c4381f87e305cd7
test_molecular_loader_ui.py cbc3ebb56327f16f585f26795df97df41a64c33607338a574d97bbaaf592b8a8
test_qa_regressions.py 3283403abf6fe708249b468895a440ac136a1c95794349aea84288e718b7a4d3
```

Explicit root-approved migrations, not claims that old behavior now passes:
- The21 old bootstrap assertions are unchanged. Only header and AUTH path change
  to the exact pre-edit JS fixture. It is test-only, outside console serving and
  console package-data patterns. Historical21 are reported separately.
- Lifecycle credential acquisition uses document navigation; unauthorized
  mutation, cookie flags and actual encrypted-registry authorized creation
  assertions remain. Cross-origin document has no cookie. Adjacent UI assertion
  now requires no bootstrap path and the explicit reopen control.
- Molecular loader still executes actual auth.js, checks exact coordinate text
  and credentials. Two native source requests replace three including bootstrap;
  native fetch identity is additionally asserted.
- Patch VM preserves paused/closed/hidden guards. Explicit recovery performs one
  reload and no read. A separate fresh-document context preserves the original
  successful visible-polling assertions.

## Original RED and corrections retained

All receipts below are original tool outputs, not invented disk result files.

1. Wrapper typo:21ac2a/00855b,56 setup errors1.32s, I/O0/Node0.
   Wrong aegle.profile import corrected to runtime.MetabolicProfile; no product RED.
2. First real-source attempt c6d3fb/b06f2a:30fail26pass2.72s, I/O0/Node8/Git-refused1.
   Eight VM cases hit an authored missing closing brace; not product failures.
3. After that exact brace correction cefbfa/8f2be9:30fail26pass2.63s.
   One foreign-URL fixture still reached missing legacy timer context; preserve
   that limitation. Its focused attempts4e4256/182e99 and ef7883/f7b55f retain the
   setup failure then the genuine untouched-fetch-identity RED (1fail0.95s).
   No assertion was removed. All runtime bytes were still original.
4. Six-file implementation:64a52c/f80c2d,56PASS2.77s,I/O0/Node8/Git-refused1.
5. Added duplicate-header/port/method/file-fallback boundary packet:
   43d84f/ad2380,6fail4pass46deselected1.52s,I/O0.
   Five duplicate-header cases and exact-zero-port case reproduced first.
6. Corrected exact metadata admission: f2ef13/cbedc1,66PASS2.79s,
   I/O0/Node8/Git-refused1, private root suffix gtkbckbj.

Broader attempt a1f7a7/b57387:168pass51fail11.51s;49 Node module evals were
refused by an over-narrow invocation allowlist, one deliberately denied real
AegleTwin constructor was overselected, and one unchanged v2-copy assertion
already disagrees with unchanged twins.html. No model or forbidden child ran.
Next141dc8/ab2814:168pass49fail2deselected14.73s,I/O0; those49 were an
invocation-only escaped-newline syntax defect. Both failed attempts remain.

Correct invocation99d7cd/dd7513:217PASS2deselected21.06s, Node121/I/O0/
Git-refused1, private suffix z6yjt9_s. The two explicitly ungraded nodes are:
test_actual_reference_projection_passes_browser_contract (requires a real model),
test_twins_pairing_explicitly_bounds_the_form_to_legacy_v2 (unrelated stale copy).
Neither was edited or relabeled PASS.

Historical fixture repeat9ba0f3/3b7398:21PASS3.78s,Node21/I/O0/Git0,
private suffix waum_o0u. This is historical behavior preservation, not21 more
current-product passes.

## Exact independent current66 repeat

Run from /Users/emman/Livemore/.worktrees/full-scope-recovery.
This permits only authored Node eval children and TestClient's internal socketpair;
connect, DNS, bind, listen, urllib, native loading, model constructors and other
process creation are refused. No application lifespan runs.

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os,signal,socket,subprocess,sys,urllib.request,ctypes
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('OFFLINE_DEADLINE')));signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.socket.bind=socket.socket.listen=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1;permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
class NoModels:
 @pytest.fixture(autouse=True)
 def prevent(self,monkeypatch):
  from livemorebio.tests.clinical_registry_fixtures import forbid_compilation
  from livemorebio.aegle.runtime import AegleTwin, MetabolicProfile
  forbid_compilation(monkeypatch)
  monkeypatch.setattr(AegleTwin,'__init__',deny)
  monkeypatch.setattr(MetabolicProfile,'__init__',deny)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=line','livemorebio/tests/test_navigation_session.py','livemorebio/tests/test_navigation_session_ui.py'],plugins=[NoModels()])
print('Refusal counts:',counts,flush=True)
raise SystemExit(status)
PY
```

## Learning and remaining gate

Delivering the credential before scripts run removes a session-startup request
and its global interception ownership entirely. It does not explain or waive old
transport failures, provide server TTL, or qualify biological behavior. All old
private browser harnesses and failed receipts remain untouched. Root must grade
this source and inspect actual navigation/UI before accepting the replacement.

## Exact related preservation repeat

This is the actual corrected217-case invocation (dd7513), not a new runner.
It adds only the previously approved Node module-eval form to the66-case guard,
and explicitly deselects the real-constructor and unrelated stale-copy nodes.

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os,signal,socket,subprocess,sys,urllib.request,ctypes
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('OFFLINE_DEADLINE')));signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.socket.bind=socket.socket.listen=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and len(cmd)==4 and cmd[:2]==['/opt/homebrew/bin/node','--input-type=module'] and cmd[2] in ('-e','--eval'):
  counts['node']+=1;permit=True
  try:return run0([*cmd[:3],'import {createRequire as scopedRequire} from "node:module";const require=scopedRequire(import.meta.url);'+prefix+cmd[3]],*a,**k)
  finally:permit=False
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1;permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
class NoModels:
 @pytest.fixture(autouse=True)
 def prevent(self,monkeypatch):
  from livemorebio.tests.clinical_registry_fixtures import forbid_compilation
  from livemorebio.aegle.runtime import AegleTwin, MetabolicProfile
  forbid_compilation(monkeypatch)
  monkeypatch.setattr(AegleTwin,'__init__',deny)
  monkeypatch.setattr(MetabolicProfile,'__init__',deny)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=line','livemorebio/tests/test_navigation_session.py','livemorebio/tests/test_navigation_session_ui.py','livemorebio/tests/test_subject_lifecycle.py::test_document_navigation_replaces_bootstrap_but_keeps_mutation_auth','livemorebio/tests/test_subject_lifecycle.py::test_approved_navigation_and_source_bound_whole_person_mount_are_shipped','livemorebio/tests/test_qa_regressions.py::test_issue_patch_page_pauses_polling_when_authorization_is_cancelled','livemorebio/tests/test_molecular_loader_ui.py','livemorebio/tests/test_workspace_stream_ui.py','livemorebio/tests/test_protocol_inspection_ui.py','livemorebio/tests/test_selection_reconciliation_ui.py','livemorebio/tests/test_phase1_screen_launch.py::test_mutation_routes_require_configured_bearer_token','livemorebio/tests/test_phase1_screen_launch.py::test_phi_like_audit_and_evidence_reads_require_operator_auth','livemorebio/tests/test_phase1_screen_launch.py::test_cli_creates_persistent_owner_only_mutation_token','livemorebio/tests/test_phase1_review_regressions.py::test_adapter_probe_requires_mutation_auth','livemorebio/tests/test_phase1_review_regressions.py::test_attach_authorization_reuses_persisted_launcher_token','livemorebio/tests/test_phase1_review_regressions.py::test_concurrent_token_initialization_converges_on_one_token','livemorebio/tests/test_molecular_reference_api.py::test_auth_first_before_reference_and_audit_io','livemorebio/tests/test_molecular_reference_api.py::test_cross_origin_cookie_cannot_read_reference','livemorebio/tests/test_research_api.py::test_every_research_data_route_requires_auth_before_storage','livemorebio/tests/test_research_api.py::test_main_app_auth_middleware_cannot_bypass_no_store','livemorebio/tests/test_clinical_availability_api.py::test_unavailable_state_and_workspace_preserve_reference_without_any_previous_physiology','livemorebio/tests/test_clinical_availability_api.py::test_unavailable_biology_keeps_actual_reference_atlas_and_null_quantities','livemorebio/tests/test_clinical_availability_api.py::test_unavailable_patch_has_no_fabricated_model_day_or_channels','livemorebio/tests/test_clinical_availability_api.py::test_unavailable_numerical_actions_fail_before_engine_or_registry_calls','livemorebio/tests/test_clinical_availability_api.py::test_selection_auth_precedes_registry_read','livemorebio/tests/test_clinical_availability_api.py::test_cohort_member_routes_require_auth_before_registry','-k','not test_actual_reference_projection_passes_browser_contract and not test_twins_pairing_explicitly_bounds_the_form_to_legacy_v2'],plugins=[NoModels()])
print('Refusal counts:',counts,flush=True)
raise SystemExit(status)
PY
```
