# Private distance-unit checker correction

2026-09-09. Root maker report. Independent pre-code review accepted NFC plus
anchored numeric-token/exact-unit boundaries in the preceding actual-decision
document. No product, renderer, coordinate, selector or transport file changed.

Fresh0700 root `/private/tmp/livemore-molecular-unit-browser.kCPxWp`.
Only private check.cjs and test-check.cjs differ from the prior harness; the
fresh input manifest updates the two same-byte page paths. check.py, page files,
Python tests and inert runner are unchanged. No actual run directory exists.

The new four-line distanceResult helper canonicalizes a copy of the display
string with NFC, admits only its leading fixed-decimal value followed by the
angstrom unit and pipe/end boundary, then checks finite numeric conversion.
It retains the original display string, capped200 characters as before. The
actual workflow calls this helper before the unchanged finite-distance assertion.
No result value, tolerated scientific error or rendered text is rewritten.

Original failed actual string `5.82 Å | THR 3 — MET 2` and upstream U+212B default
were directly verified (be7684 and independent1a77ba). The new helper's13 tests
were written first; they failed because the helper did not exist (4b6178,
133.249ms). That is distinct from the actual retained original-regex failure.
Tests include three canonical Unicode forms and ten malformed/nonfinite/unit
negatives. No old test was weakened. Final whole private packet:59 Node cases
passed171.806ms plus6 Python cases0.020s, completiona43c32 exit0, no browser or
native scientific execution. Prior52 checks remain.

Frozen private hashes:

| File | SHA256 |
|---|---|
| check.cjs | `0024e5c455835e52d28973e7aa217a88bede81a1e7348c7b34f79a9e0963d225` |
| test-check.cjs | `2abf6a1b5d9a46774892c4db9e4da232d03c05a23d7a75b2b3a5f3e7db4404f0` |
| inputs.json | `f709a6416eac39a92e63abaf53fb372d6b7db5937defcfbfc04eb97aa7f6c989` |

The eight-file harness map binds these new private files and unchanged originals.
All22 runtime/public-source entries remain fixed except same-byte private page
locations. The full four-stage/11-image/six-structure workflow and all budgets,
cleanup rules, source/provenance and failure admission remain unchanged.

Independent review/repeat is required before a new actual decision. Exact inert
command: pinned Python3.11 `-B` on this root's `run-inert.py`. A future actual
command would use the same interpreter on `check.py --run-once`, but this report
does not authorize it. Both previous actual failed roots remain untouched.

Lesson: canonical Unicode equivalents can differ at the code-point level.
Normalize only the comparison copy; keep original evidence and exact unit
boundaries so a formatting correction cannot admit overflow or the wrong quantity.

## Independent bounded grade

2026-09-09, release_redteam: **CLEAR for this private checker correction**.
Read this complete report and the complete source/test delta against consumed
LygJpf. The only CJS changes are the four-line helper, its actual measurement
call and export. Thirteen tests are additive; the old 52 assertions remain.
The leading fixed-decimal token, NFC angstrom unit and pipe/end boundary reject
numeric suffixes, wrong dimensions and overflow without changing the original
display text or the measurement producer. No product, source or transport fix
is being smuggled into the evidence parser.

Independent exact repeat completed `f0d0fe`, exit 0: **59 Node cases passed in
188.162167 ms and 6 Python cases passed in 0.021 s**. It used the reviewed
network/child-refusing inert wrapper, not the browser entry point:

```text
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-molecular-unit-browser.kCPxWp/run-inert.py
```

The same read-only check verified all 22 input/eight harness rows against exact
integer metadata and hashes with stable before/after stats. Only the two
same-byte page paths differ in the input map. check.py, page.html, page.js,
test-check.py and run-inert.py match the prior originals byte-for-byte.
Harness map SHA256 is
`e74237d6af0e698157d75e8543499570bc01155bf4fbb3509a7f1ed5fecde697`.
All three previously graded product/test hashes remain unchanged, so the
153-case product packet was not redundantly rerun. No actual run directory
existed at this checkpoint, and all offline tests are stopped.

No actionable blocker was found in this narrow delta. Both previous actual
failures remain FAILED, and all 11 images, mobile/desktop interaction, exact
source checks, request-terminal failures and cleanup requirements remain the
separate actual decision's obligations. This grade does not authorize that run.
