# Launch decision: what merging to main actually changes, and what is still red

Date: 2026-09-22. Prepared so the merge decision is made on evidence. Nothing in
this document merges anything; the merge is the founder's call.

## What "launch" means mechanically

`install.sh` defaults to `LIVEMORE_REF=main`, and the published one-line command
resolves `main` at run time. So whatever sits on `main` is what every future
install gets. Today `main` is far behind: it predates the recovery checkpoint,
the six programs, the installability fixes and the platform contract.

Two pull requests stand between the current work and `main`:

| PR | Branch | Base | Contents |
|---|---|---|---|
| #8 | `codex/full-scope-recovery` | `main` | the September 10 recovery checkpoint and complete handoff |
| #9 | `codex/real-systems-continuation` | `codex/full-scope-recovery` | this work: installability, insulin engine, six programs, platform contract |

Merging #9 alone does not reach `main`. The order is #8, then #9, or a single
combined pull request from the continuation branch to `main`.

## Green before the decision

* Full suite from an empty home directory, with pinned Human-GEM assets: passing.
* The one-line installer, run into an isolated home against the branch: exit 0,
  including its own full-suite gate.
* `Platforms` workflow: container job passing, which starts all three services
  and drives an insulin run, a botanical margin and a blocked program through
  the API. Windows job passing, which records the refusal and its guidance.
* Six-program behaviour: executes or refuses with a typed reason code, with
  analytical controls inside every result.

## Red before the decision

* The `Installer` release gate is red on both runners. Eight distinct tests on
  Linux and seven on macOS fail, all in the atlas browser-harness family, all
  already failing before this branch, none reproducible locally. See the lessons
  record for the exact list and everything ruled out.
* Therefore a merge today lands a `main` whose release gate is red for reasons
  that predate this work. That is a deliberate decision to make, not a detail to
  discover afterwards.

## Continuous integration became unavailable partway through 2026-09-22

From roughly 08:36 UTC, every job in both workflows began failing before running
a single step, with no logs produced, while a job that had started at 08:32 kept
running to completion. That pattern is an account-level GitHub Actions
condition on this private repository, not a change in the code: the workflow
files were unchanged between the last successful run and the first instant
failure, and only documentation had changed in that commit.

The most likely cause is exhausted included minutes or a spending limit. macOS
runners bill at ten times the Linux rate and this repository ran many macOS jobs
that day. Confirm at <https://github.com/settings/billing>. The billing API
needs a token scope this session does not have, so this is stated as the
probable cause rather than a verified one.

Consequence for the decision: until Actions accepts jobs again, CI cannot
verify anything, and local verification plus the isolated-home installer run are
the only evidence available. The last complete CI results, recorded above,
remain valid for the commit they ran against.

## Options

1. **Merge now.** `main` becomes installable and current, and the installer
   stops shipping a stale tree. The release gate stays red until the atlas
   failures are diagnosed. Recommended only with that red state acknowledged in
   the release notes.
2. **Diagnose the atlas failures first.** They need a run on the runner itself
   with diagnostics, because they do not reproduce locally. Timeline unknown,
   because the cause is unknown.
3. **Merge with the atlas suites quarantined.** Mark them as expected failures
   with an issue link so the gate reflects reality. This makes the gate
   meaningful again, and it must not be confused with fixing them.

## Recommendation

Option 1 or 3. The product is materially more usable on `main` than what is
there now, and the red tests are inherited rather than introduced. Option 3 is
better if a green gate matters for client-facing confidence, provided the
quarantine is explicit and tracked.

## After the merge, whichever option

1. Run the one-line installer from `main` into a fresh home and confirm exit 0.
2. Run `livemore doctor` and the container quickstart on a clean machine.
3. Tag the release only after both succeed.
