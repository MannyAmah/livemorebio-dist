# Research validation and biological integrity build

Date: 2026-09-05
Branch: `codex/research-validation`, based on the reviewed interface branch `0db2a4d`.
Authorization: the user's current request authorizes review, implementation, testing,
recording, and further-development planning. Routine repairs proceed under that request.

## Product and premise review (office-hours)

The intended user is a pharmaceutical researcher preparing an intervention, selecting
individualized biological subjects, observing endpoints, and assessing causal evidence.
The founder has identified concrete failures: cluttered UI, a weak experimental journey,
short videos, and concern that outcomes have been assumed rather than established.
No customer payment or clinical equivalence evidence is available in this session.

The objective remains whole-human functional equivalence, down through molecular biology.
It is an empirical objective. Computation must expose its assumptions and missing states;
independent physical experiments must be able to falsify it. Reading papers cannot make
an unmeasured state observed or prove an atomistic whole-human replica.

The current software contains generic plant benefit defaults, silent parameter replacement,
decorative motion, and a time control that does not project the recorded time series.
Those are defects relative to the user's stated requirement and are first priority.

## Alternatives and chosen approach

1. Cosmetic cleanup and longer recordings (small): reuses current UI but leaves biological
   integrity defects. Rejected because it cannot satisfy the request.
2. Repair the existing biological paths, add a usable measurement and resilience workflow,
   govern knowledge revisions, and simplify the UI (large, selected): reuses encrypted
   registry, protocol store, evidence service, scientific adapters, browser and terminal.
3. Rewrite as an atomistic human and physical robotic lab (research program): not achievable
   by code alone; needs measurement coverage, physical instrumentation, validated models,
   model identifiability, commercial access, and substantial scientific development.

The chosen approach completes an auditable research workflow while preserving the full
system objective. It does not silently redefine software verification as clinical validation.

## What already exists

- Aegle metabolic/cardiac engines and formal whole-body module contracts.
- Encrypted subjects, source manifests, reproducible heterogeneous profiles, Patch binding.
- Cendos metformin and garcinoic-acid/PXR protocols, run storage, CSV/notebook exports.
- Evidence-service review and calibration separation, Patch-v2 measurement admission.
- Source catalog and reference graph, KEGG restricted adapter, database workflow routing.
- Approved A+B Atlas plus distinct Biology, Twins, Cohorts, Cendos and Patch pages.

## Implementation and ownership

Lane A (biology agent): fail closed on unknown or generic plant effects; preserve saved
reference parameters on activation; reject incompatible units/quality in observation mapping;
trace reference initialization; add regression tests. Avoid shared server.py unless coordinated.

Lane B (UI agent): simplify Atlas to body, selected subject and experiment actions; retain
multiscale navigation and evidence via progressive disclosure; make biological time select
actual recorded values; gate motion on supported data; fix dead controls. Own workspace
HTML/CSS/JS and UI-focused tests, no Cendos page or server edits initially.

Lane C (sources agent): repair commercial KEGG transport assumptions and add licensed
MalaCards/KEGG import integration using explicit records, source identity and hashes;
preserve missing credentials as actionable unavailable states. Own reference/source modules
and source tests; write primary-source taurine assessment and database terms citations.

Lane D (main): immutable experiment records and comparison to admitted measurement manifests;
five-operation treatment-free resilience evaluation; versioned biology learning records;
API/CLI/UI wiring; reproducible paced interaction recording, executed analysis, full QA,
release documents and roadmap. Coordinate shared files explicitly.

## Architecture and data paths

```text
sources + units + context -> preserved person profile -> bounded executable protocol
       |                              |                          |
 invalid -> explicit error       missing -> reference label       v
                                                      frozen run + analysis
                                                                 |
instrument raw file + custody + QC -> measurement admission ------+
                                                                 v
                                          paired residuals / acceptance assessment
                                                                 |
                                      independent review -> context qualification

literature / physical residual / contradiction -> versioned learning record
       -> reviewer + test evidence -> candidate module revision -> regression gates
       -> explicit model release (never direct edits to active twins)
```

Empty sources, no measurements, wrong identities, unit mismatch, failed QC, stale data,
unsupported interventions, and endpoint mismatches must yield visible missing/invalid states.
No substituted measurements and no automatic therapeutic commands.

## Cure hypothesis contract

Implement the user's five operations as prespecified evidence requirements: driver removal,
pathological-memory clearance, tissue restoration, healthy homeostasis, and treatment-free
resilience. Evaluation requires endpoint definitions, units, individual healthy ranges,
off-treatment follow-up, stress conditions, and minimum independent subjects/challenges.
Missing operations, absent follow-up or continued treatment prevent a supported assessment.
Use an explicit lower confidence bound for resilience evidence, with assumptions shown.
No optimizer invents a cure or recommends a human dose from these data.

## Continuous biology learning contract

Cover atomic/chemical, molecular, genetic, cellular, tissue, organ and whole-body levels
in a contributor curriculum. Every biological code change must identify mechanism, primary
evidence, units, conservation assumptions, applicable population/time scale, counterevidence,
benchmark and reviewer. The software stores versioned learning records and exposes the gaps.
Reinforcement learning is not enabled by adding a label; it needs an explicit task, reward,
offline evaluation and controlled candidate release. Learned candidates cannot self-calibrate.

## CEO and engineering review

Mode: HOLD SCOPE for the user's requested review/build. Existing A+B design remains the
design source; simplification uses fewer simultaneous panels rather than another redesign.

1. Architecture: four ownership lanes reuse existing services; no extra service/database.
   Distinguish prediction, instrument measurement, hypothesis assessment and model release.
2. Errors: typed input errors, missing evidence, unauthorized source, unavailable upstream,
   conflicting identity, and corrupt file paths are visible. Do not swallow exceptions.
3. Security: existing auth on all sensitive routes, no PHI in health/status/logs/prompts,
   encrypted storage for admitted person/assay data, safe text rendering and bounded uploads.
4. Data/UX: disable repeat submissions; durable run IDs survive navigation; empty first run
   is usable; selection remains explicit; never load an unrelated latest experiment.
5. Quality: reusable comparator and knowledge records; fail-closed legacy paths; no generic
   benefit multipliers hidden behind a new drug name. Existing heuristic models remain labeled.
6. Tests: unit and integration tests for identity, units, finite values, immutability,
   unsupported compounds, wrong endpoint/QC, off-treatment and missing evidence gates.
7. Performance: bounded input arrays/files and synchronous cohort sizes; cache references;
   no external API requests inside a per-member loop. Large datasets remain future work.
8. Observability: run/source/version hashes and reason codes, no raw clinical data in logs.
9. Rollout: isolated branch/services/data fixture, preserve old release and user data.
   Additive records; rollback by returning launch to prior release; do not delete evidence.
10. Future: physical Cendos and Patch evidence remains the key dependency; production
    tenancy, audits, independent biological validation and hardware release are milestones.
11. Design: one clear primary workflow; detail drawers with real behavior; time-series
    projection and empty/partial/error states. Desktop/mobile and reduced motion verified.

## Failure and test map

| Path | Failure | Behavior/test |
|---|---|---|
| unknown drug | default benefit | explicit unsupported, unchanged twin test |
| reference activation | profile regenerated | frozen parameters preserved test |
| observation | wrong unit, nonfinite, failed QC | reject/normalize, unit tests |
| source import | license absent, bad ID, corrupt record | no evidence admitted, tests |
| source network | academic host in commercial mode | reject, no HTTP call test |
| experiment | no physical counterpart | pending measurement, no validation claim |
| comparison | wrong subject/endpoint/unit/digest | reject before computation |
| resilience | missing operations, on-treatment, missing stress | not assessable |
| learning | unsupported source or no test/reviewer | no model release |
| UI time | label-only or stale response | assert displayed numerical state changes |
| recording | hidden preload or short output | chapter log + durations + actual interactions |

```text
tests: pure validators -> storage/API integration -> browser end-to-end -> recorded analysis
release: isolated run -> unit/integration -> review -> browser QA -> video -> docs -> branch PR
rollback: stop isolated run -> previous launch entry -> retained immutable evidence files
```

## Demonstration acceptance

Record a deliberate plant research journey with preparation, source identity, cohort
construction, concentration entry, execution, individual result inspection, Biology view,
CSV/notebook export, executed analysis and measurement requirements. Target 6-10 minutes
of real actions/read time, no frame duplication or speed alteration to manufacture duration.
Record a separate metformin/review journey if it materially verifies preserved flows.
Keep step captions legible, show typing/cursor, include chapters and a reproducible script.
No fabricated wet-lab results; a missing measurement is shown as missing.

## External blockers and further development (explicitly not claimed complete)

- Exact whole-human equivalence: no complete model/data coverage or independent validation.
- Physical Cendos execution: needs an actual instrument, reagent characterization, sample
  identities, protocols, calibration and wet-lab data; software cannot manufacture these.
- Physical LIFE Patch: hardware/firmware/gateway/channel validation still needs bench/human
  comparisons and authenticated device data. No therapeutic actuation is authorized here.
- KEGG/MalaCards: commercial access requires applicable permission and vendor delivery mode.
- Taurine: review and contradictory primary evidence inform a research protocol; they do
  not supply a validated human causal engine or establish an anti-aging/cure outcome.
- Pharmaceutical production release: contextual scientific validation, tenancy/RBAC,
  operational security and independent acceptance testing remain evidenced release gates.

## Independent review refinements

- Clinical mappings normalize compatible units, require timezone-aware timestamps and QC,
  distinguish fasting from random glucose, and expose inherited parameter provenance.
- Unsupported physiology protection covers generic pharmacology, both Cendos assay routes,
  annotation-to-physiology, ChEMBL action-to-flux and GEM transformations.
- Resilience defines the independent experimental unit before analysis. Repeated challenges
  cannot inflate sample size. An operation may be declared not applicable only with a
  prespecified scientific rationale. Treatment-free requires cessation and washout evidence.
- Measurement comparison resolves server-stored run values and protocol acceptance criteria;
  the caller cannot rewrite predictions or tolerances after seeing measurements. Raw artifact
  digests and run hashes bind the comparison. Technical fixture comparisons stay fixtures.

## Review status

Written before implementation. Primary and independent plan reviews complete; four
acceptance refinements incorporated above. Independent scientific and UI audits complete.
The plan is cleared for the authorized implementation; scientific equivalence remains open.
Missing physical data has been
asked asynchronously and does not block software repairs or the research workflow build.
