# Molecular loader and owned inspector — steps 1–2 review packet

Status: maker source/test freeze, awaiting independent review. The 82 inert
cases pass; no Molstar package was executed, no real coordinates were fetched,
and no browser/rendering acceptance is claimed. The existing viewer remains
unchanged and active. No production switch is authorized by this receipt.

## Approved boundary and implementation

Root read and authorized steps 1–2 of
`2026-09-09-biology-local-molecular-controller-breakdown.md`, following the fully
reviewed `2026-09-08-molecular-structure-only-build-controller-plan.md`. Only
three new console files and two new tests are in this maker packet. No Biology,
workspace, legacy page, CSP, vendor/build, server/audit, registry or scientific
implementation was changed. The brief root wheel-snapshot hold was respected
and explicitly released before further runtime writes.

- `molecular_loader.js`: exact target/frozen-PDB and descriptor admission;
  one metadata read and one fixed same-origin coordinate read when available;
  exact200, type, digest/byte count, source/build process binding, reference-only
  flags, fatal UTF-8, finite bounded metadata, explicit missing mappings, and a
  single bounded operation. No related-species fallback or automatic retry.
  Finished operations cannot be reused outside their deadline. Successful EOF
  releases its reader without cancel; unfinished/error bodies are canceled.
- `molecular_inspector.js`: opaque context/epoch ownership, source metadata
  rendered as text, fixed local adapter import, PluginUIContext registered
  before initialization, retained React root, explicit deposited-model preset,
  parsed frame/model/raw-row checks, canvas admission, and deferred exactly-once
  unmount-before-dispose. Pending native promises remain owned, not declared
  released on timeout. No second plugin starts while old cleanup is pending.
- Scoped CSS: accessible fixed dialog, visible status, Close/Retry, title
  association, focus outline, wrapped provenance and mobile layout. This is
  source CSS only; it has not been seen in an actual browser.

The six adapter exports match the prepared original Molstar4.4.0/public React
entry: PluginUIContext, Plugin, createRoot, createElement, createStructureSpec,
modelPresetParameters. The default import names the future admitted local
`vendor/molstar-4.4.0/structure.js`; that file is not supplied by this packet.
No substitute renderer or mock is used in runtime. Tests supply authored public
API-shaped objects; they do not establish actual upstream execution.

The original upstream factory waits until after init to return ownership and
catches canvas rejection. The approved small orchestration instead retains the
context before init and refuses READY after any missing/rejected canvas. It
retains all original upstream parsing/rendering responsibilities. The preset
uses model index plus `structure: {name:'model',params:{}}` and unitcell false,
not the default expanded first assembly.

### Authentication and late-close refinements

There is no exported `auth.fetch`: actual `auth.js` is an IIFE replacing
`window.fetch`. Biology line11, legacy line6 and workspace line10 load it before
their controllers. The default transport resolves global fetch at call time.
An inert test executes that unchanged auth IIFE with an authored native delegate
and proves exactly one bootstrap plus the two protected GETs, all same-origin
credentials. No other token store or bootstrapper was introduced. Consumer
integration must preserve this script ordering and still test the real page.

Root's preliminary read correctly identified post-await close publication and
callback races. Five new mounted regressions reproduced old close callbacks
after open/context/dispose, an old timeout replacing new LOADING, and invalid
context completion replacing a newer context. Close now captures its epoch/key
and only its current lease can publish/call back; invalid-context completion uses
the same fence. A separate genuine regression showed replacement from inside the
dialog returned focus to Close rather than the original external trigger. That
trigger is retained across same-dialog replacement; a new external trigger is
still honored. Cleanup ownership is not weakened by these UI fences.

## Frozen identities

SHA256, relative to this worktree:

| File | SHA256 |
|---|---|
| `livemorebio/aegle/console/lib/molecular_loader.js` | `bf6e1845ce9f37458239ff42960dd44eed29c0d246c34f995a9b8a8d76d57c71` |
| `livemorebio/aegle/console/lib/molecular_inspector.js` | `144102776f716d8ed3fbcdeb9a356e6a3113ea5481c15e97166be2f249117667` |
| `livemorebio/aegle/console/lib/molecular_inspector.css` | `edf18be340be74c770dbb1e4d4f51876a24a37870c466725914ea972dcee948c` |
| `livemorebio/tests/test_molecular_loader_ui.py` | `200663abb308ba030780a3ee1692191707300ad0c4cd27c356741a425e1445ce` |
| `livemorebio/tests/test_molecular_inspector_ui.py` | `01145bb50b27cd8b1cd8f22081e58f32fef60dd759cb0b840f01e9c6d2d55841` |

Runtime line counts are170/231/22; tests164/249. Loader has37 cases and inspector45.
Tests import the actual source modules, not source-string replacements of their
logic. The one import URL is redirected to the actual loader as an inert Node
data module. Test coordinate bytes explicitly say `data_TECHNICAL_ONLY`; hashes
and byte counts are technical fixtures, not the admitted molecular assets.

## Retained RED and GREEN history

Every row used an isolated private review root, no external I/O, and only the
exact authored Node children. Root suffixes below are under the printed macOS
temporary `livemore-research-review-` prefix. Git refusals were0 throughout.

| Root suffix / exec session | Result | Classification |
|---|---|---|
| `13byywpk` /13479 |32 failed,3.39s | Initial authored JS runner `+const`/string escaping syntax error, not product RED |
| `b1i_xfpg` /24258 |32 failed,2.75s | Actual missing loader-module RED; downstream assertions masked |
| `00yyqa6w` /84854 |32 passed,3.60s | First loader GREEN |
| `ldfeofrl` /78345 |29 failed,3.40s | Authored plugin-object brace syntax error, not product RED |
| `5rlz7c0g` /47615 |29 failed,2.69s | Actual missing inspector-module RED |
| `k4ij7_fz` /60116 |1 failed,60 passed,7.18s | Authored15ms pending-init fixture could expire before init entry; corrected technical timeout to100ms, production30s unchanged |
| `sohgar08` /86006 |6 failed,64 passed,28.12s | Genuine array-target coercion, completed-operation reuse, invisible status placement, and three invalid-context stale-view failures |
| `wlomnutm` /19923 |70 passed,8.51s | Those source corrections GREEN |
| `s7u2v7_w` /76173 |1 failed,75 passed,9.21s | Replacement focus returned to Close instead of external trigger |
| `k7pbccd4` /21602 |6 failed,76 passed,10.40s | Previous focus failure plus five old-close/context publication/callback races; actual auth-default control passed |
| `5llpfqij` /39090 |82 passed,10.23s | Final complete maker packet, exit0,82 Node children, unexpected I/O0 |

Fixture corrections are not scientific or product acceptance. The descriptor
nonfinite test changed wire `Infinity` to string `Infinity` because JSON.stringify
turns numeric Infinity into the valid nullable resolution value; it retains the
invalid-wire-type assertion. Failed-node reporting was shortened to name/message
with immediate nonzero exit to prevent a known failed assertion from retaining
its timer and printing huge encoded data-module stacks. Before-exit completion
guards remain, as do all assertions. Reference-equality focus assertions use a
boolean identity test to avoid dumping the entire authored DOM on failure.

## Exact isolated repeat command

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`. This is the
reviewed Node-only45s wrapper, not permission for browser/native work. It permits
only `/opt/homebrew/bin/node --eval` with injected network/process refusals.
Each child also has a10s pytest subprocess timeout; no package/vendor code is
imported. A network/API/model result cannot satisfy these technical fixtures.

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - livemorebio/tests/test_molecular_loader_ui.py livemorebio/tests/test_molecular_inspector_ui.py <<'PY'
import os,socket,subprocess,sys,urllib.request,ctypes,signal
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1';os.environ['PYTHONDONTWRITEBYTECODE']='1'
signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1;permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=line',*sys.argv[1:]])
print('Refusal counts:',counts,flush=True);signal.alarm(0)
raise SystemExit(status)
PY
```

## Lessons and explicit remaining gates

The async graphics lifetime, visible context, and keyboard trigger are separate
resources. Waiting for cleanup does not retain authority to publish to the next
owner or call an old close callback. Conversely, invalidating UI authority does
not release a still-running plugin. Tests must prove both halves with actual
mounted asynchronous control flow. Real auth-default behavior needs an actual
wrapper test; naming a nonexistent exported auth.fetch would hide the integration
contract rather than establish it.

Independent source review is next. Actual vendored adapter/React/Molstar execution,
all six deposited sources, measurements/selection, three consumer wiring, wheel,
CSP, responsive keyboard/WebGL and real-browser verification remain NOT_RUN in
this packet. The upstream parser is synchronous in parts; this30s owner deadline
does not claim native or synchronous-JS preemption. All-target mapping, genuine
spatial dynamics and the larger R03/R23/R24/full-product matrix remain open.

Separate retained visual finding, not fixed here: root's accepted original
14-image legacy banner run `y11aq6ff` shows a compound-validation banner surviving
a later pending/unknown preview. The new root-owned
`2026-09-09-legacy-current-feedback-correction.md` addresses that finding and the
static cardiac labels. This molecular packet neither edits that surface nor
claims those subsequent corrections accepted. Prior Atlas transport failures,
NOT_RUN controls and original scientific claims remain unchanged.

## Independent root review, September9

Root read all170 loader lines,231 inspector lines,22 CSS lines,164 loader-test
lines,249 inspector-test lines and this complete packet. The five frozen hashes
match. Independent actual-module repeat:82 passed in10.89s, private `ys1qhn07`,
session37335 exit0;82 authorized Node children, unexpected I/O0, Git0. The two
earlier root-identified late-close/auth-default seams have explicit source and
test evidence in this packet. No package, coordinate source or browser ran.

The source read identified a remaining keyboard visibility issue before switch:
`focusBack` and the dialog candidate filter inspect only a node's own `hidden`
property. Connected controls inside a hidden/inert ancestor or CSS-hidden
upstream panel can be chosen. Focus may then stay on a hidden closing dialog
instead of the promised neutral owner region, or traversal may wrap toward an
invisible upstream control. The authored DOM has no ancestor/CSS-visibility
model, and only Escape, not full Tab traversal, is currently exercised. This
does not authorize a production switch or establish accessible modal behavior.

Next narrow correction: add red-first actual-controller tests for hidden-ancestor
and unavailable trigger fallback plus visible-only first/last Tab/Shift-Tab
candidates. Reuse ordinary DOM visibility/inert checks; do not replace Molstar
controls or add another focus framework. Actual browser focus, mobile and200%
checks remain mandatory after the real adapter exists. Independent packet
acceptance remains scoped/pending this keyboard seam and the already listed
loader/consumer/browser gates. Nothing here closes R03/R23/R24 or any video.

## Maker keyboard correction, retained RED and new freeze

Root authorized the narrow existing focus contract after its independent review.
Only inspector JS and its dedicated test changed. The loader/CSS/loader-test
hashes in the first freeze remain unchanged; the first82-case receipt is retained
above, not rewritten.

New RED: **12 failed,83 passed in12.06s**, private `n30duh1i`, session29416,
exit1,95 exact Node children, external I/O0, Git0. All original82 passed. The
already-supported disabled-trigger case passed; six newly authored connected
hidden-trigger cases and all six actual Tab/Shift-Tab traversal cases failed.

The small shared visibility check now uses native connected/disabled matching,
`closest('[hidden],[inert]')`, computed visibility, nonzero `getClientRects`, and
ancestor opacity. CSS display-hidden ancestors have no client rectangles.
It does not equate offscreen-but-focusable with hidden or invent viewport-based
control hiding. A hidden/inert/CSS-hidden/zero-area connected trigger uses the
neutral host; visible same-context triggers still receive focus. The existing
first/last Tab wrapping uses this filter plus nonnegative tabIndex, includes
upstream textarea controls, and leaves ordinary interior Tab handling native.
No Molstar controls, models, plugin lifecycle or consumer state were replaced.

The authored DOM gained these standard geometry/ancestor/style interfaces and
accurate form-control selector handling; no prior assertion was removed. New
cases cover hidden, inert, display:none, visibility:hidden, opacity:0 and missing
rectangles, plus the disabled preservation control. Tab and Shift-Tab exclude
hidden upstream panels and negative-tabIndex controls; visible input/textarea
interior navigation remains native. Fixed authored dimensions are a unit-test
fixture, not a browser visibility result.

Final maker repeat with the same above45s Node-only wrapper: **95 passed in12.41s**,
private `g5lm8n4t`, session37674, exit0,95 Node children, unexpected I/O0, Git0.
New frozen identities:

- inspector241 lines:
  `00266652ee37295650a7012676aafb2e91bfeaf03289f804937fb4b1e909c0aa`;
- inspector tests299 lines:
  `d749855a9c41b6e431d2f8506e309b2f393fd81f9fb577b35616a2e60c44c007`.

Independent re-review and actual-browser accessibility remain pending. This
source-level correction does not change the no-production-switch status or any
of the adapter/consumer/full-product acceptance limitations above.

## Independent keyboard correction review

Root read the full241-line controller,299-line dedicated tests and the maker
amendment, and checked both frozen hashes. The visibility filter addresses
the previously identified hidden/inert/CSS ancestor seam without replacing
upstream controls or ordinary interior keyboard handling. Independent repeat
with the retained Node-only45s wrapper:95 passed in11.47s, private `ntk4j7sh`,
session37820 exit0,95 exact Node children, unexpected I/O0 and Git0.

This clears the narrow source-level keyboard correction for subsequent adapter
wiring. It does not certify native browser focus behavior, visible geometry,
Molstar operation, three-consumer integration, mobile/200% rendering or complete
Biology acceptance. Those gates remain as stated above. No active product
viewer, numerical mechanism, source data or experiment was changed by this repeat.
