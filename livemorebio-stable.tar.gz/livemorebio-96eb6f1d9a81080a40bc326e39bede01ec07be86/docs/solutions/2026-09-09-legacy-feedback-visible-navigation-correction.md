# Legacy feedback: visible navigation geometry correction

Date: 2026-09-09. Bounded harness-only correction authorized by root after
the retained actual failure. No product or browser-run authorization is added.

## Evidence and cause

The reviewer read the full browser-result.json and supervision.json in
`/private/tmp/livemore-legacy-preview-c_1ximjr` and personally viewed the
original `failure-D1-context-1.png`. This attempt remains FAILED, with D0 PASS,
D1 CURRENT_FEEDBACK_FAILED, D2–M2 NOT_RUN, one authored POST, four completed
original images and one retained failure image. It is not a16-image pass.

The desktop-ready row has all copy/class/title/banner/source/hit predicates
true. Its three label boxes fit the1440×1000 viewport at y73.796875,71.75,499.
Native scrolling put the normal-flow navigation at y=-155.5, height60,
bottom=-95.5. It is completely outside the viewport, not covering those labels.
The current CJS validator rejects `nav.y < 0`; Python repeats that assumption.
The screenshot agrees with the raw geometry. This is an overstrict harness
assumption that navigation must always remain visible, not a product defect.

Original elapsed10.166079959s. Supervision records all four children reaped,
all eight proven descendants absent, no listeners and no cleanup failure.
These are the retained root execution receipts, not new OS probes by this author.

## Exact pre-code correction

Leave `scrollFeedbackHeading`, ordinary browser DOM/CSS, native scroll, label
reader, seven row order,16 image order, four POSTs and all bounds unchanged.
Both admitters must continue requiring a finite positive navigation rectangle.
They compute its intersection with `[0,width] × [0,height]` from the retained
raw rectangle; they do not rewrite the rectangle or old receipt.

- An empty intersection means the navigation is not visible and cannot
  geometrically occlude a label. Negative or beyond-viewport nav coordinates
  alone are not an error.
- A nonempty intersection must have zero positive-area overlap with each
  complete label box. Touching an edge is allowed, covering any area is not.
- All three labels still require finite positive boxes, nonnegative x/y,
  complete viewport containment, exact native hit, exact fixed copy and no
  horizontal document overflow. No text shrinking, field hiding or image retry.
- The original five banner/nav checks at scroll0 remain entirely unchanged.
  This correction applies only to the two heading-layout checkpoints.

Only CJS `requireFeedbackSnapshot`, Python `_admit_feedback_checks`, the new
dedicated feedback tests and this report may change. Existing123 harness
assertions and31 new cases remain; no supervisor/reader/scroll/source edits.

## Red-first test map

Add fixed offline tests against both admitters, first with a known good row:

1. Exact retained desktop-ready geometry must be admissible as a component
   geometry proof, without promoting the failed whole receipt to acceptance.
2. Wholly above/below/left/right navigation and partially clipped navigation
   that does not cover a label are admitted; border contact is admitted.
3. Partially clipped or fully visible navigation covering a label is rejected.
4. An offscreen nav cannot excuse a negative/clipped/zero/nonfinite label,
   failed native hit or horizontal overflow. Malformed nav remains rejected.
5. Actual serialized reader preserves the negative raw nav coordinates and
   true native label hits. Parent and CJS row admission agree on fixed cases.

No actual browser or OS test. Repeat the same guarded three-file offline
matrix after GREEN. Freeze hashes and receipt for independent root review.
Any later single ordinary browser run needs separate root authorization.

## Durable lesson

Normal-flow navigation can leave the viewport after a legitimate scroll.
Validate the visible occluder intersection, not an assumed sticky layout.
Keep raw evidence unchanged so a validator fix cannot rewrite a failed run.

## Frozen maker implementation and offline evidence

New20 cases at the prior frozen validators: **14 FAILED,6 PASS,31 deselected
in0.75s**, private `i2jojkdx`, direct exec exit1, external I/O0, Node7, Git0.
The exact retained geometry and offscreen-positive controls failed; the six
already-valid strict rejection/contact controls passed. Tests that exercise a
bad label first require the corresponding offscreen-nav good case to pass.

Only the two named admitters then changed: navigation itself remains finite
and positive, while label boxes remain completely visible with strict hits.
Navigation uses the same clipped positive-area intersection formula in both
languages. `readFeedbackSnapshot`, `scrollFeedbackHeading`, original fixtures,
image writer, route schedule and supervision are unchanged.

Frozen complete repeat: **174 PASS in15.28s**, private `iaiirwri`, session20550,
exit0; external I/O0, Node143, Git-refusal1. This preserves all154 prior cases
and adds20. Run the exact three-file45s Node-only refusal wrapper in
`2026-09-09-legacy-current-feedback-browser-harness-review.md`, unchanged:

`/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - livemorebio/tests/test_legacy_current_feedback_browser_harness.py livemorebio/tests/test_legacy_preview_browser_harness.py livemorebio/tests/test_legacy_banner_browser_harness.py`

Frozen SHA256:

- Python: `b3d435c3b6327ae645c6375aa78d07d1ef22e1bd0e8c59c0bc2ffd876afb55eb`
- CJS: `c6d15ae26e4a86e2a6120b1507280f25b96f3e68256bc958a8b56b9e27fbf0d4`
- Feedback51-case test: `9108af494d6713548aa0eba118a3f7131a383c35423a2898bc148e3480c466f3`
- Original harness test, unchanged this correction:
  `896045af52165af134f57c19f2e93fb2335520b0169b43f221bd2190c12238c7`
- Original banner test, unchanged this correction:
  `8aac85655e5b9c55042011c917034e62b7333596756468dd5cfcca0dcd081076`

Read-only retained failing evidence hashes:

- browser-result: `15fbec5eeea76c2438c393fff6c8eb535986541b7dc42e24660f597b2aac1355`
- supervision: `ca10df08ebbe4832d19f9687500b537159a7f64acd7b20e2405068fe40686cea`
- original failure PNG: `bc36ef5257947b719af79965705a06522f2c90ee16f9f1f3b2e432a4409d172e`

No further actual run or evidence rewrite was made. Independent source review,
offline repeat and separately authorized browser acceptance remain required.

## Root independent grade and new run decision

Root read both changed validators, every added test and this full report.
Independent repeat:174 passed15.37s, session24154, private82i9obuf;
unexpected I/O0, Node143, expected Git refusal1. The two validators preserve
full-label containment and native hit requirements, and reject any positive
visible-navigation overlap. No product source changed; its fingerprint remains
`f9f7b4384cba70ea6080b631c1ca33c7e8b2bda8c3c0797d527858e234520fed`.

Authorize one fresh ordinary16-image run with the two corrected frozen harness
files. Retain the prior failed run unchanged. This is a new evidence directory,
not regrading or rerunning inside the old one. Same stores/commands/limits and
scientific-execution tripwires; root must inspect all originals before accepting.
