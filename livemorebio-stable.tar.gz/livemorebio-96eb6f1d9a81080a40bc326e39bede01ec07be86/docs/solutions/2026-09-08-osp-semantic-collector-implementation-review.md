# OSP fixed technical collector implementation — independent review packet

2026-09-09. Maker: release_redteam. **Source/offline-test freeze, not execution
clearance.** Root approved this implementation after independently admitting the
lossless V2 inventory. No R interpreter/parser, dotnet, CLR, OS inspector probe,
native model, service, browser, download, compilation or package installation was
invoked. No original scientific failure or admission criterion was changed.

## Exact write set and frozen identities

Only the two planned new implementation files, one dedicated new test file and
this receipt are added. No old source/test file was modified.

| File | Lines | SHA256 |
|---|---:|---|
| `tools/osp_semantic_supervisor.py` | 920 | `cdb00a1acb5b08b3f7d8aff0f3977f746b5a506ed4f97355b56dd34bf2d2a476` |
| `tools/osp_semantic_probes.R` | 207 | `3ba6559b723cfe85c66bca47aac0abfbaac8e395c430bd7360105dc6f67625f7` |
| `livemorebio/tests/test_osp_semantic_supervisor.py` | 570 | `36f1454cc22f229bfe8410c7e31728fac70961856d07671c2765a50e1c9571ee` |

The original pure module remains
`12585d9bed93cd2a5625ec1cd625287406a22d475b49c34ba931109630ea82d7`;
its original tests remain
`5c4d29106391b97f429d1f66969e3262c8d35395678b11947d94d74a08951b09`.
The protocol remains
`5eb866376a2b121109066dbb11edad2eba701b3b85c8fe474ae1aa02b8e505e7`.
V2 inventory remains
`d09b1f5dcb15d6d612b8b5301c2bb5f6a4c7f174b8e08eeff1df24b087c94be2`.
Original V1's metadata failure and all original OSP static/numerical failures
remain preserved; this code does not rewrite or invoke them.

Governing full reads: the307-line retained-native technical proposal, source
map, full collector/supervisor amendment including root's FINAL-before-Dispose
decision,244-line static mapping,197-line lossless method, root's V2 admission/
implementation gate, pure fixture module/tests/review, and biological change
contract. No callable context7/CE/gbrain tool was available; pinned local primary
sources and the existing reviewed mappings were used. No new library API was
guessed from a current package version.

## What is implemented, narrowly

The supervisor imports only standard-library modules plus the unchanged pure
fixture module. It has no physiological importer, generic XML/argv CLI, service
or reusable external process-runner API. Its fixed entry point has both
`EXECUTION_APPROVED=False` and `OS_PREFLIGHT_APPROVED=False` before inventory
reads, directory creation or process work. Importing it is inert: ctypes/ABI
initialization is deferred into the OS-only functions.

Only S01–S17 can be configured. The parent supplies exact validated XML, exact
output entity IDs and run counts, but no expected grid/value/oracle arrays to R.
The unchanged comparator still returns false execution/cleanup/model flags;
the outer evidence does not mutate those fields. The source schedule remains
17 fresh workers,13 positive cases,4 Load/Finalize rejections and16 prescribed
Run calls. Only S01/S07/S08 repeat on their same finalized object. First failure
stops the schedule and preserves every later case as NOT_RUN.

Direct retained `bin/exec/R --vanilla --slave -f ... --args configuration.json`
uses the explicit reviewed private environment, not the relocated shell wrapper.
It preserves `library(ospsuite)`. The namespace-visible base `system` hook is
installed before rSharp loading, allows the one original literal call during
STARTUP, marks it consumed before unchanged delegation, and is restored after
Dispose. There is no dotnetAvailable/init retry or system2 fallback.

Four bounded request/reply records bind PID/case/sequence/manifest:
STARTUP_BEGIN, STARTUP_END, PRE_XML and FINAL. These are two image checkpoints,
not four image inspections. Reply publication is atomic and no-overwrite.
At each image checkpoint the parent owns one exact
`/usr/bin/vmmap -w <held R PID>` invocation. It retains bounded raw private
inspector output and separate process/resource/cleanup receipts, then reconciles
two stable managed inventories, R DLLs/namespaces, exact library paths and the
mapped-file list against V2. Native/managed mandatory minima are channel-specific;
positive FINAL requires CVODES before Dispose. Unknown/X11 images fail; system
cache membership never receives an invented file digest or full-cache proof.

The public IsConstant flag is explicitly stored-size evidence, not independent
semantic constancy. Managed option getter readback is labelled cached, and
successful Run statistics are labelled managed-reported native out-parameters.
Raw arrays/counts are unexpanded, serialized with17 digits, then checked by the
unchanged pure comparator. Constructor/options/collection errors cannot be
reclassified as the four expected Load/Finalize call rejections. The shared
malformed table cases do not attribute a rejection to one particular table.

Complete worker budget remains30s and packet600s; no next case begins with less
than35s remaining. CPU20/21s rlimits and sampled aggregate CPU/RSS checks remain
separate. Sampling targets100ms, rejects gaps over500ms and zero samples, and
continues through cleanup. Three seconds are reserved inside the worker budget
for ownership stabilization/TERM/KILL; the2s inspector has a half-second cleanup
reserve, not additional time outside its budget. These are code bounds, not
observed OS performance.

The exclusive Popen owner is retained before fallible observation; no poll or
early reap is used. Only held-owner proof permits group signals. Unknown identity
gets bounded observation only, then the unresolved slot retains ownership and
blocks later entry/files/spawn. A nested unresolved inspector and its R owner
are both retained in that one blocked invocation. Stream prefix hashes, full
observed counts/hashes, EOF/incomplete/overflow state, exit observations, Dispose,
binding restoration and evidence failures are separate. Nonzero worker exit
does not erase its own recorded primary/Dispose failure. This is not an OS
network/exec sandbox or a promise to survive simultaneous supervisor loss.

## Approved source-only representation precision

Root explicitly approved this conditional during implementation, before the
six focused RED cases: only R DLL entry name/key `base` with exact path `base`
may be recorded as `R_BUILTIN_EXECUTABLE_ALIAS`, and only with the already
verified pinned R leader plus positively observed libR. It receives
`file_sha256:null`. Wrong name/path, missing leader or missing libR fails.
All other nonabsolute/malformed DLL paths remain fatal. This is an accepted
representation conditional, **not a claimed observed runtime sentinel**.

Retained R fullrefman.pdf pages304–305 (printed251–252) were read as document
text, without R. They document getLoadedDLLs, require [[ for DLLInfo fields,
and describe PACKAGE=base as searching the R executable. They do not assert
that this still-unexecuted collector actually returns the sentinel.

Root separately approved reading only relevant installed SDK declarations for
the already planned own-child OS checks. Read libproc.h96/102, proc_info.h85–99
and754, sysctl.h KERN_PROCARGS2. Exact source-file hashes:

- libproc.h: `246d87709fc6b9157ce5cf3c475656ac48e0e1ae8bbdc46cf45acd34294448cd`.
- sys/proc_info.h: `e427fa96b348537b21552b9de71e01039410bcad2cedee5584c5e5fddafd70fc`.
- sys/sysctl.h: `4a77c53e0ee4035ca1c9e6a910aeddbc8f6163ccb8415940bbe7e398013f3764`.

These declarations are under
`/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/include/`.
No OS function was called. The fixed sampler reads only admitted owned-group
PIDs; it parses bounded argv, discards the KERN_PROCARGS2 environment tail without
parsing/retaining it, and captures start/image twice to reject a crossed exec
observation. Observed command/PID/image records are not a complete exec journal.

## Retained red/green history

All private roots below share
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-`.
The table records actual tool results, not reconstructed hypothetical failures.

| Root suffix | Actual outcome | Meaning |
|---|---|---|
| `0u4shlax` |62 errors,0.35s; unexpected I/O0 | Original RED: new supervisor module absent. |
| `knckc8iq` |62 errors,2.12s;62 denied attempts | Importing ctypes tried PyDLL(None). Audit refusal blocked it. Real import-side-effect bug, no successful native load. Fixed by lazy OS initialization, not a weaker wrapper. |
| `u19d_llv` |61 PASS/1 FAIL,0.18s; I/O0 | Source-test error: lexical on.exit registration order was mistaken for R execution order. Corrected to assert Dispose belongs only to on.exit and FINAL follows raw collection. Not an R lifecycle execution claim. |
| `pxx1m0iu` |81 PASS/1 FAIL,0.21s; I/O0 | Atomic ACK RED: target visible at fsync before complete publication. |
| `nm6aqbkz` |87 PASS/2 FAIL,0.25s; I/O0 | Exact cached booleans and sampled aggregate CPU REDs. |
| `7l0c88hj` |89 PASS/7 FAIL,0.25s; I/O0 | Six approved builtin-alias cases plus resource sampling through pending TERM. |
| `c44pnnya` |96 PASS,0.20s; I/O0 | Above paths green. |
| `dl8_azjm` |107 PASS/1 FAIL,0.78s; I/O0 | Positive-image fixture's fake resolver doubled /private in an already resolved path. Only its prefix conversion was corrected. No product allowance relaxed. |
| `pfe16joa` |108 PASS,0.74s; I/O0 | Positive/negative all-channel admission and quota tests green. |
| `hz1_6e0r` |439 PASS/2 deselected,1.26s; I/O0 | First preservation matrix before final failure-evidence regression. |
| `j5et8o7o` |108 PASS/1 FAIL,0.79s; I/O0 | Nonzero worker exit hid recorded primary/Dispose evidence. Fixed bounded independent file read before acceptance checks. |
| `1bg21e48` |**440 PASS/2 deselected,1.25s; I/O0** | Final109 dedicated plus331 preserved offline cases. |

Both deselections are original native_watchdog cases; they are not passes.
The tests execute authored Python process/barrier/image transports and real
strict-validation/control branches. They use no actual child or OS sampler.
R-specific tests read source for namespace/public-call/cleanup structure:
**no actual R syntax, hook delegation, native call sequence or R lifetime test
has run.** The later independent source review and separately authorized
OS-only/native gates remain mandatory.

## Exact final independent-repeat command

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`. The original
RED selected only the new test file. The command below is the final full
preservation packet, with fresh private stores and a45s outer alarm.

```bash
PYTHONDONTWRITEBYTECODE=1 /Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B - <<'PY'
import os,sys,signal,socket,subprocess,urllib.request,multiprocessing.process
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:v for k,v in os.environ.items() if k in ('PATH','HOME','TMPDIR','LANG','LC_ALL')})
env.update(PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1');os.environ.clear();os.environ.update(env)
counts={'unexpected_io':0}
def deny(*a,**kw):
 counts['unexpected_io']+=1
 raise AssertionError('Unexpected network, native load, or child in offline collector tests')
for owner,names in ((socket,('socket','create_connection','getaddrinfo')),(subprocess,('Popen','run','call','check_output')),(urllib.request,('urlopen',)),(multiprocessing.process.BaseProcess,('start',))):
 for name in names:setattr(owner,name,deny)
def audit(event,args):
 if event in ('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.exec','ctypes.dlopen'):deny()
sys.addaudithook(audit);signal.alarm(45);print('Private test root:',root,flush=True)
import pytest
code=pytest.main(['-q','-p','no:cacheprovider','--tb=short','livemorebio/tests/test_osp_semantic_supervisor.py','livemorebio/tests/test_osp_semantic_probes.py','livemorebio/tests/test_osp_source_admission.py','livemorebio/tests/test_osp_stage_b.py','livemorebio/tests/test_osp_stage_b_analysis.py','-k','not native_watchdog'])
print('REFUSAL_COUNTS',counts,flush=True);raise SystemExit(code)
PY
```

## Review handoff and lesson

The maker does not grade this packet. Root/another reviewer must read the frozen
two implementations, dedicated tests and this receipt, then independently repeat
the offline matrix. Only afterward can the separately written fixed OS-only
preflight be reviewed. No authorization for that preflight or the17-case native
run is implied here. Both gates remain false.

Actual Darwin ABI/inspector behavior, R startup topology and path representation,
package/assembly loading, native output/flags, timing, solver visibility before
Dispose and cleanup remain unobserved. Missing or contradictory evidence must
fail the later fixed attempt; do not enlarge the candidate set, alter the
launcher, rerun a failed case or relax tolerances to obtain a pass.

Lesson compounded locally: an apparently harmless ctypes import can cross the
native boundary; a JSON ACK visible before completion is not a valid barrier;
and a nonzero exit is not a substitute for retaining the worker's primary and
Dispose failures separately. Offline proofs must state which language/process
actually ran. None of these engineering checks qualifies insulin, a patient,
physical LIFE Patch behavior, the other five scientific programs or full product
readiness.

## Root independent grade, September9

Root read all920 supervisor lines,207 R lines,570 dedicated-test lines and this
complete report. All three frozen hashes match. Root independently repeated
the exact refusal-wrapped440-case command: **440 passed,2 deselected in1.22s**,
private`livemore-research-review-kujnf8hi`, exec18409 exit0, unexpected I/O0.
This closes source/offline implementation review, not either execution gate.

Root checked the installed SDK declarations and Apple's primary
[libproc implementation](https://github.com/apple-oss-distributions/xnu/blob/main/libsyscall/wrappers/libproc/libproc.c):
`proc_listpgrppids` converts returned bytes to PID count, consistent with the
collector's count handling. This is source corroboration, not an observed ABI
test or claim that the current upstream source equals the installed binary.
The first attempted unrelated libproc repository path returned404; no artifact
or alternative native library was acquired.

Proceed only to the already proposed fixed OS-only preflight preparation. Reuse
the reviewed ownership/stream code; no additional general supervisor, process
discovery framework, broad native allowlist or numerical fixture. Pin exact
authored inert children, seven named conditions, actual output bounds and total
deadline before root decides a single execution. Both product/native gates stay
false. Native startup, R syntax/lifetime, solver outputs and the six scientific
programs remain unobserved by this packet.
