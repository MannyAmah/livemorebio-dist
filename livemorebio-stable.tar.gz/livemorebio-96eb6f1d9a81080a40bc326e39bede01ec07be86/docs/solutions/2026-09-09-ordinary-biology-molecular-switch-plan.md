# Ordinary Biology: remaining local-inspector wiring

2026-09-09. Source-reviewed implementation plan, not an active switch or a new
renderer. The approved structure-only controller plan and all R01–R51 remain.

## Actual gap

Root reread the ordinary page, inspector and existing execution/frozen test
seams. `biology.html` still has the remote `loadMolstar`/`Viewer.create`/
`loadPdb` block and external stylesheet. It does not bind asynchronous molecular
loads to `STATE.context_id`, and its Close span lacks the new dialog's keyboard
behavior. Fixed-execution and frozen-run target wiring already exist. Their
presence and private viewer screenshots do not complete ordinary Biology.

Do not patch a second ownership system into that obsolete block. Replace it
with the accepted shared inspector only when its local assets and delivery
path are ready. Keep cell rendering, all existing organ targets, anatomy
recovery, cross-section controls and model availability handling intact.

## Exact proposed source boundary

- `biology.html`: import the existing shared inspector; use one persistent
  labelled host and fixed-feedback status; lazy mount on the first valid target
  action. Remove the old molecular modal/CSS/remote loader only as the matching
  local inspector and built local styles become the selected implementation.
  No hidden feature flag or fallback back to the CDN.
- Capture `{kind:'ordinary', key:STATE.context_id, mode:'REFERENCE_ONLY'}`;
  reject absent/invalid context before mounting. Never pass person metadata,
  biomarkers or experiment state into the molecular plugin.
- Before publishing an accepted changed Biology context, synchronously invoke
  `setContext` so its invalidation precedes any new page state. Observe its
  promise with generation-scoped fixed feedback. A linked-context rejection
  invalidates the inspector immediately. A failed refresh must not invent a
  new confirmed identity for the retained previous readout.
- Changed organ / all-organs navigation closes the previous inspection; ordinary
  same-organ data refresh must not close a useful same-context reference or
  steal focus. READY-to-UNAVAILABLE closes the old binding while current
  reference targets remain usable. Graphics retry must not destroy a separately
  owned molecular view.
- Existing inspector owns plugin cleanup, focus, deadline and pagehide disposal.
  Ordinary wrapper observes failures and prevents stale actions after pagehide;
  no duplicate plugin, owner framework, model request or mutation retry.
- Extend `biology_ui_fixtures.py` only for the real import seam; retain the full
  ordinary controller and its current behavior assertions. Dedicated consumer
  tests mount ordinary handlers with an explicit authored inspector seam. The
  shared inspector's real module/race tests remain independently exercised.

## RED and acceptance cases

1. Exact target and captured accepted context; no eager plugin or extra state,
   cohort, experiment or remote request from opening molecular references.
2. Context changes before late open completion; linked mismatch; missing context;
   READY/UNAVAILABLE transition; failed refresh retains only its old identity.
3. Repeated same-organ refresh preserves inspection; changed organ closes;
   removed trigger does not revive; anatomy retry/section/labels/cells unchanged.
4. Mount/open/setContext/close/dispose failures show fixed feedback, with no raw
   errors; late old failures cannot overwrite the current context's feedback.
5. Pagehide/close idempotence and no stale handler reopening. No new source or
   clinical computation, automatic retries, substitute coordinates or species.

Write these failures first, then the minimum inline wiring, independently review
the diff and full affected tests, then inspect the actual page in a fresh isolated
technical stack across ordinary/frozen/execution contexts. Use the already
reviewed browser tooling; do not introduce another test infrastructure. Include
desktop/mobile, keyboard and source provenance alongside existing organ/cell
controls. Private synthetic contexts are not actual human observations.

## Prerequisites that remain explicit

Private viewer clock correction has independent clearance, but its fresh actual
check remains FAILED on three coordinate-request cancellations. Public vendoring is not
cleared: the retained notice review leaves CAS and fastapprox intermediate
permissions unresolved. This plan does not waive that question, remove features,
rewrite third-party rendering code, publish vendor bytes or make a clinical
claim. Installed-wheel/static asset delivery and the three actual consumer
checks remain required before calling the switch accepted. Root must separately
review readiness and authorize the active source switch; no code is changed
by this document. Broader Biology dynamics and all six exact videos remain open.

Lesson: a working isolated component is not a completed application integration;
track its actual active caller, identity binding and distributable asset path.

## Independent source-only pre-code review

Release-redteam read the complete plan and actual ordinary inline controller,
shared inspector/CSS, frozen-run and fixed-execution binding seams, and the
ordinary VM import fixture. No code, tests, browser, service, native execution
or clock-pinned input changed. The shared-owner direction is appropriate;
three precise boundaries must be explicit before implementation:

1. **Bind the target action to the rendered selection, not whichever STATE is
   current when a stale callback fires.** `biology.html:372` currently emits
   global `_mol(target)` handlers without context or detail identity. The
   refresh at 297 also leaves old detail markup when its selected organ is
   absent from the new list. Capture accepted context and a detail generation
   in the actual rendered target handler, and require the current selected
   organ/target membership and a still-current trigger before lazy mounting or
   opening. An old handler must not relabel a target onto a newly accepted
   context, even if both contexts contain the same target. Use the existing
   frozen-run `detailGeneration` pattern, not a new owner. RED cases: old
   detached button after same-organ rerender, old button after context switch,
   selected organ removed, and same valid-context reference remaining open
   during ordinary refresh. Preserve target spelling; no fallback target.

2. **Validate incoming ordinary context before publishing it.** At
   `biology.html:275–288`, the 64-hex check presently applies only to the linked
   URL branch. `molecular_inspector.js:8–14` intentionally accepts a general
   nonempty key for its three consumers; it is not an ordinary context-ID
   validator. Require `typeof next.context_id === 'string'` and exactly
   `/^[a-f0-9]{64}$/` before accepting next STATE or constructing the ordinary
   binding. This matches `server.py:158–161`'s opaque SHA-256 coherence token.
   Invalid refresh retains the previous confirmed readout/key as stale, not a
   new identity; invalid initial context cannot mount or request coordinates.
   Retain the separate explicit linked-mismatch invalidation. Call `setContext`
   directly before STATE assignment, not from a deferred `.then()` callback.

3. **Test the shared inspector's actual failure contract.** Its `open` catch
   (186–197) and `close` catch (110–113) publish FAILED/CLEANUP_UNCONFIRMED but
   normally resolve; `setContext` may also resolve after that close. A resolved
   promise is not a positive cleanup/render acknowledgment. Keep the shared
   persistent host's fixed status visible and authoritative, and generation-
   guard only the ordinary wrapper's own feedback. Do not clear a failure,
   remount over a blocked owner, or remove its host because an await resolved.
   In addition to rejected/synchronously throwing seam doubles, retain a
   resolved-with-FAILED and resolved-with-CLEANUP_UNCONFIRMED case and the
   independently exercised actual shared-module lifecycle tests. No new public
   inspector result API is required for this wrapper.

Two existing requirements need concrete calls/paths rather than broader work:
same-key `setContext` is a no-op (`molecular_inspector.js:210`), so an actual
READY→UNAVAILABLE transition must explicitly close once even if an authored
fixture retains the context key; subsequent same-context UNAVAILABLE refreshes
must not repeatedly close or steal focus. And `biology.html` currently includes
neither `/lib/molecular_inspector.css` nor the matching local built structure
CSS: the eventual authorized switch must deliver both styles for all three
page modes, not merely delete the remote stylesheet. Preserve their existing
dialog/portrait bounds; do not change the unrelated cell/anatomy styles.

These are finite pre-code/test precisions within the listed scope, not a request
for another renderer, abstraction or current-source API. Source review is
conditional on incorporating them. The notice/distribution, installed-asset,
actual three-consumer/browser and original transport acceptance gates remain
separate; no active switch or actual run is authorized by this review.

## Root incorporation of independent pre-code review

Root read the complete 142-line reviewed plan (`d181c7`) and incorporates all
three conditions into implementation acceptance, without changing the scope:

- Ordinary target actions capture the accepted context, selected organ and
  detail generation when rendered. Before lazy mount/open, require the same
  accepted context and detail generation, connected/current trigger and target
  membership in the currently selected organ. Clear obsolete detail markup when
  that organ disappears. Test detached old handlers both with and without a
  context change; they must never rebind to whichever STATE happens to be current.
- Require an exact lower-case 64-hex context ID before publishing ordinary
  STATE, including unlinked entry. Missing/malformed initial identity cannot
  mount. An invalid refresh preserves the previous confirmed readout as stale,
  never a new identity. Keep linked-mismatch invalidation separate and invoke
  setContext synchronously before STATE assignment on an accepted change.
- Resolved inspector calls do not imply success. Its persistent host and actual
  FAILED/CLEANUP_UNCONFIRMED status remain authoritative. Include resolved-failed
  seam cases as well as throws/rejections; do not clear that status or remount a
  blocked owner. Wrapper feedback alone is generation-scoped.

Explicitly close once on same-key READY→UNAVAILABLE, not on every subsequent
unavailable refresh. The eventual switch includes both the existing local
inspector stylesheet and its matching built local structure stylesheet for all
three modes. Existing cell/anatomy behavior and dialog bounds remain unchanged.
The independent review is incorporated; distribution, request-failure and actual
application acceptance prerequisites remain open. No active switch occurred.

## Immediate preservation-safe prerequisite implementation

Root authorizes implementing two independently identified ordinary data-controller
corrections now, without activating or modifying either molecular renderer:
validate the ordinary incoming 64-hex context before STATE publication, and
remove a selected organ's obsolete detail/cell view when that organ is absent
from a newly accepted response. Return to the actual available organ overview
and clear the removed isolation; do not invent a replacement organ or quantity.
Keep the existing linked-mismatch branch and same-organ refresh behavior.

This is an incremental execution of the reviewed plan, not a substitute for the
full shared-inspector switch or six experiments. Touch only the ordinary data
acceptance/detail reconciliation and dedicated controller tests. No dependency,
style, molecular modal/loader, frozen/execution caller, model, device or server
change. RED cases must cover malformed initial/refresh identities, retained
valid context on failed refresh, absent selected organ, same-organ preservation
and empty available organs. Use the real ordinary inline controller through the
existing VM seam; no copied alternate controller. Independently review/repeat
the affected preservation suite before any actual application acceptance claim.

The preserved readout after a failed refresh is not current authorization to
request a new cell trace. Track confirmed-data availability with one ordinary
controller boolean, set only after accepted data and cleared on read failure;
the existing cell entry refuses while it is false. Existing replay remains
paused by the current error path and can resume after a valid same-context
refresh. This is required to preserve the inherited no-new-trace-on-missing-
context behavior when rejecting an invalid response now retains old STATE.
Migrate only malformed authored successful-context fixtures in the affected
older tests to 64-hex IDs; keep their missing-context/error assertions intact.

Independent implementation review found two paths requiring the same contract:
an in-flight cell response must recheck confirmed data before accepting its
trace, and the render/replay entry must not run while data is unconfirmed.
Also route anatomy selection through the existing current-organ lookup instead
of accepting a cached mesh's old organ object directly. Add exact RED probes
for late matching-key trace after failed refresh and removed/updated cached
organ clicks. No geometry reconstruction or new ownership system is needed.
