# OSP static identity metadata: retained-number precision diagnosis

2026-09-08. Diagnosis and proposed correction only, pending root review before
regeneration. The original manifest/method/report remain unchanged. No retained
runtime file, collector, model, service or browser was modified or invoked.

## Finding and original evidence

The exact metadata gate correctly rejects the original static manifest. The
defect is my Python-to-JavaScript retention path, not evidence of source change.
Python collected exact integers; JavaScript parsed them as binary64 Numbers
before formatting the retained JSON. Nanosecond timestamps and six system inode
numbers exceed Number.MAX_SAFE_INTEGER and lost decimal precision.

Original manifest SHA256 remains
`fc5afe90a5d51b92014c559708b8737e1cc08e8b029bdea7cb79d7c565205f95`.
Original method SHA256 remains
`47823872e887a4227dd2b32a59a24daa750927d8aaeb21805d9fbe019edadebe`.
Original mapping report SHA256 remains
`f08879e800ca26d51a6f2b839ca1d5b95729e0bf84f846e9e4f7405aca995f94`.
Its pre-code readiness statement is now conditional on a corrected, independently
admitted lossless inventory. Do not admit the old manifest by approximate
metadata matching, casting current values to float, or removing identity checks.

Root's independent first-row check observed unchanged cran-dependency-lock.csv
SHA256 and matching before/after live metadata, but a stored timestamp mismatch:

| Field | Exact value |
|---|---|
| Current mtime_ns | `1788854861134072669` |
| Retained JSON token | `1788854861134072600` |
| Retained minus current | `-69 ns` |
| JavaScript exact-safe limit | `9007199254740991` |

The exact lost precision is reproducible without a file mutation:
`JSON.stringify(JSON.parse("1788854861134072669"))` produces
`"1788854861134072600"`.

## Bounded all-row RED and retention trace

[Metadata-only RED](2026-09-08-osp-static-metadata-precision-red.json), SHA256
`e772739b66f6a4ab083692baf025b93c21a8b5ec5adaf7fb68e1974e44e13a64`.
Observed at `2026-09-09T03:17:37.121233+00:00`; command exited1 as intended.
It loads the original JSON using Python's integer-preserving json parser,
resolves only its fixed paths, and compares two immediate regular-file stat
observations with each recorded row. It does not read candidate file contents.
Every observed large integer is emitted as a decimal string in this RED receipt,
and its raw stdout was retained without a JavaScript numeric parse/reformat.

- 1,390 rows checked:1,370 retained files,8 system files,12 cache subcache rows.
- 50 mtime mismatches, all in the1,370 retained-file rows; maximum absolute
  difference179ns. All1,390 timestamps are equal at binary64 precision.
- Six additional mismatches are system-file inode values. Other available
  device, mode, byte-size and resolved-path comparisons match; stat was stable
  across each pair of observations.
- The original JSON has1,396 unsafe integer fields:1,390 mtime_ns values and
  six inode values. Some unsafe values happened to survive, which does not make
  their JSON-number encoding safe for this retention path.

[Exact JavaScript round-trip reproduction](2026-09-08-osp-static-metadata-roundtrip-reproduction.json),
SHA256 `2e36816702e92d60277a27ed4cf5c0fa2253f7b8d9a81b56c4c5c632ea9be449`.
The actual functions-session JSON.parse/JSON.stringify operation reproduced all
1,390 stored timestamp tokens from current exact decimal strings. A bounded
read of the six affected system inode values likewise reproduced every stored
token. In particular `/bin/ps` inode`1152921500312570752` and `/bin/sh`
inode`1152921500312570762` both became`1152921500312570800`. Timestamp-only
repair would leave an identity collision in the receipt.

No full candidate content-hash repeat was performed for this diagnosis; root's
first-row matching hash is attributed to root. Matching metadata and exact
binary64 replay establish this representation mechanism, not a new blanket
source-content attestation or historical claim that no file could ever change.

The defective retention steps were in the orchestration call, not the retained
Python scanner:

```javascript
const x = JSON.parse(r.output);      // exact Python integer tokens become Number
Object.entries(x).map(([key, value]) =>
  JSON.stringify(key) + ': ' + JSON.stringify(value)); // rounded decimal retained
```

The original method note said stdout was retained using apply_patch but omitted
this intervening parse/reformat. The corrected method must document the complete
producer, transport and persistence path. `apply_patch` was not the rounding
source; it faithfully wrote text whose numbers were already rounded.

## Minimal proposed correction and exact write set

After root approval, create only new counterparts:

1. `2026-09-08-osp-retained-runtime-static-inventory-v2.json`;
2. `2026-09-08-osp-retained-runtime-static-inventory-method-v2.md`;
3. append corrected results/independent-review disposition to this amendment.

Preserve the original three files and both RED evidence files byte-for-byte.
Do not change pure fixtures, original hashes, collector/runtime files, candidate
membership, dependency policy, limits, source attribution or biological gates.
This is input representation, not a new identity framework.

V2 uses schema`OSP_RETAINED_STATIC_INVENTORY_V2` and explicit
`integer_encoding="UNSAFE_INTEGERS_AS_CANONICAL_DECIMAL_STRINGS"`.
Before the **first** Python json.dumps, recursively encode exact ints with
absolute value above`9007199254740991` as canonical base10 strings. Preserve
safe ints and booleans as their existing types; test exact type rather than
isinstance(value,int) so booleans are not rewritten. No float intermediate,
formatting through a rounded value, locale, exponent, leading plus/zero, whitespace
or negative zero. Document this for all identity metadata, not just mtime_ns.

Known numeric metadata fields are decoded using exact integer parsing solely
for comparison. A decimal string is allowed only where the schema names an
integer field, only in canonical syntax, and only outside the safe interval.
Unsafe JSON numeric tokens, floats/bools, malformed/overlong strings and numeric
strings in arbitrary fields are rejected. Safe metadata integers remain numbers.
No tolerance or float-equivalence acceptance rule is introduced.

Emit final JSON formatting in Python and retain raw stdout verbatim through
apply_patch. Do not parse and reserialize that producer output in JavaScript.
A string-only JavaScript orchestration hop is acceptable. Compare the producer's
complete UTF-8 byte digest with the final file digest as a retention check. This
is in addition to, not a replacement for, exact live metadata/content checks.

Fresh exact metadata must be re-read from the same admitted paths; do not convert
the old rounded numbers to strings and call them repaired. Repeat the existing
fixed file hashing and stable-stat checks, without discovering extra files or
altering the candidate set. Compare every content digest/path/size/policy with
the original; any substantive difference stops and is reported rather than
absorbed by regeneration. Metadata differences must be limited to the separately
recorded exact fresh values and representation fix, with no source-change claim.

## Required RED-to-GREEN checks before new admission

- Preserve the current exact-metadata RED (50 timestamps plus6 inodes).
- Reproduce the original69ns case and ps/sh inode collision through the actual
  JavaScript transport before correction; assert distinct exact values survive
  the proposed string encoding and complete persistence path afterward.
- Check zero, booleans, safe-limit values, first unsafe positive/negative ints,
  observed large inode and nanosecond values. Reject noncanonical strings,
  unsafe numeric JSON and invalid field types; never accept by rounding.
- Validate all1,390 freshly retained rows with exact metadata equality and
  repeated stable-stat checks. Check every candidate SHA256 against original
  pins and exact path/count/exclusion preservation. Inventory size/count and
  hashes are actual outcomes to retain, not invented GREEN numbers.
- Independently repeat retention and actual-file checks before accepting V2.
  A passing mock/serialization check is not a native execution authorization.

The investigate skill was read fully and used to trace/prove the boundary before
proposing a fix. Its implementation phase is paused at root's explicit review
gate; no skill telemetry, upgrades, broader test suite or unrelated edits were
run. Lesson: even exact Python stat collection becomes inexact evidence if a
later JavaScript formatting hop silently converts64-bit identity integers.

## Root pre-code approval

Root read the complete151-line amendment, original244-line mapping and157-line
method, RED summary and first-row exact live-stat/hash evidence. The original
content hash matches; the69ns metadata mismatch was reproduced independently.
Approve the minimal new V2 manifest/method and lossless transport checks above.
Keep original manifest, mapping, method and failed receipts immutable; do not
change candidate paths, exclusions, content identities, source claims or limits.
The fixed reread is file-data inspection only. Freeze V2 and report any unexpected
content/metadata drift; root independently checks it before collector code.
No R/dotnet/native/browser/service or OS-only probe is authorized here.

## V2 implementation and maker checks, frozen for independent review

Only the two approved new data/method files were created; this evidence is
append-only. Original manifest, method, mapping and both RED receipts retain
their original bytes and hashes. The investigation skill's root-cause-first
sequence led to changing the retention representation, not weakening stat checks.

- [V2 inventory](2026-09-08-osp-retained-runtime-static-inventory-v2.json):
  453,842 UTF-8 bytes, SHA256
  `d09b1f5dcb15d6d612b8b5301c2bb5f6a4c7f174b8e08eeff1df24b087c94be2`.
- [Complete V2 method and post-retention check](2026-09-08-osp-retained-runtime-static-inventory-method-v2.md):
  197 lines, SHA256
  `ce9a1b1183bf0cb2da4c9ffe560c986c81cec7bff7bd6e3164daa5dc75c5c5fd`.

The producer reads only the original fixed file list, not a new directory walk.
It checks exact fresh metadata against the decimal-string RED observations and
six-inode replay before hashing. Every1,378 complete-file digest and12 partial
subcache-header digests matched the original. Metadata was stable across named
path/descriptor checks. No candidate, classification, exclusion or content hash
changed. It then encoded unsafe ints as strings and emitted already formatted
JSON. Its SHA256 transport header exactly equals the final retained file hash;
the persistence step never parsed/reformatted the payload in JavaScript.

Producer scalar checks:12 valid boundary/observed integers round-tripped exactly,
both booleans retained their types, and16 malformed/type/unsafe-number cases were
rejected. Float values appear only as intentional invalid test inputs, never as
a metadata normalization or comparison path.

Actual post-retention JavaScript parse/stringify check:5,681 numeric tokens were
all safe integers; all1,390 timestamp strings survived unchanged, as did all
other semantic values. The original cran timestamp remains the exact string
`1788854861134072669`. ps inode`1152921500312570752` and sh inode
`1152921500312570762` remain distinct strings. This is semantic round-trip
checking, separate from the exact producer-to-file byte digest check.

Separate post-retention actual-file checker completed exit0 in0.62s, at
`2026-09-09T03:24:32.889317+00:00`: **1,390 exact metadata rows PASS;
1,378 complete-file hashes PASS;12 subcache-header hashes PASS; zero unexpected
structural/semantic changes.** It compared the entire V2 object against V1 with
only the approved schema/encoding and exact metadata changes. Its full source
is the second Python block of the197-line method, using the same existing
bundled Python interpreter with `-B`; no omitted private helper is required.

This closes the maker's representation check, not independent admission.
Root must independently verify the frozen files before collector implementation.
No R, dotnet, CLR, model, native/OS-only probe, service, browser, network request,
package installation or runtime/test-source edit occurred.

## Root independent V2 admission and collector implementation gate

Root read all197 lines of the V2 method, the final maker receipt and all prior
mapping/amendment source boundaries. V2/method hashes match. Root independently
ran the complete second, fixed-path verification block with a30s outer alarm and
network/subprocess refusal: exit0 in0.641s, observed2026-09-09T03:26:32.092123Z,
**1,390 exact rows;1,378 complete hashes;12 partial subcache headers PASS; zero
unexpected semantic changes**. The original V1 stays failed for exact metadata;
its bytes and all original source/model evidence remain unchanged. Earlier root
generic-stat and narrowed first-row checks remain failed evidence, not passes.

V2 is admitted for the bounded retained-byte technical collector. This is neither
a source-build attestation nor evidence of actual loaded images or human biology.
Root now approves the already planned two new files `tools/osp_semantic_probes.R`
and `tools/osp_semantic_supervisor.py`, dedicated new offline tests and receipt.
Use the original pure fixture module/tests unchanged, the reviewed namespace hook,
public API meanings and fixed V2 candidate set. Preserve all17 cases/16 prescribed
Run calls,30s/600s limits, PRE_XML/FINAL-before-Dispose checkpoints and failure/
cleanup distinctions. Do not source old Stage B or physiological inputs, invent
parameters, broaden image allowances, or relax any numerical acceptance.
Write/run red-first offline tests only; no R, CLR, native, OS-only inspector probe,
browser or service execution yet. Freeze this small collector for independent
source review before the separately specified execution decisions. No generic
supervisor, production API or additional runtime is authorized by this gate.
