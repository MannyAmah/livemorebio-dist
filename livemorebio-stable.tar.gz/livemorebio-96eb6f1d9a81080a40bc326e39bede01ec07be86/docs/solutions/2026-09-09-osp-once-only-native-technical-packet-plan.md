# OSP S01–S17: proposed once-only retained-byte technical packet

2026-09-09. Planning only, by `release_redteam`. No R/CLR/native invocation,
supervisor import, gate change, launcher implementation or new attempt occurred
for this proposal. Root approval of the small private launcher, independent
offline review, and a separate exact once-only execution decision remain required.

## Decision and claim boundary

Proceed toward one invocation of the existing `run_packet()`, not a replacement
runner. The parent [technical proposal](2026-09-08-osp-retained-native-technical-probe-proposal.md)
section1 expressly allows a separately labelled, nonphysiological experiment on
the retained bytes despite incomplete native build attestation. Its conclusion
is reinforced by the root decision in the [collector amendment](2026-09-08-osp-retained-native-collector-supervisor-amendment.md).
Therefore `native_source_attestation=UNVERIFIED` is **not a blocker to this exact
technical packet**. It remains a blocker to claiming source-equivalent native
build provenance from this packet. Historical author runtime remains `UNKNOWN`.

A complete match would establish only the frozen software fixtures' behavior
on the admitted retained runtime, with the recorded identity/ownership limits.
It does not qualify the original insulin model, establish biological or human
equivalence, reproduce GIM, admit a compound, or satisfy any of the six scientific
programs. `model_admission=false` and the pure comparator's narrower verification
fields stay unchanged. All original numerical, source, OS and diagnostic failed
receipts remain failed and immutable. No new tolerance, source equation or case
substitution is proposed.

## Exact prerequisites and pins

All paths below are relative to the fixed checkout
`/Users/emman/Livemore/.worktrees/full-scope-recovery`, except the explicit private
OS result and interpreter. These bytes were rehashed during this source review.

| Input | SHA256 |
|---|---|
| `tools/osp_semantic_supervisor.py` | `8f8c1f66be57f0466a4481fc5cc1b095e6ed47a3e01564f850ae9cf0aa17b79a` |
| `tools/osp_semantic_probes.R` | `3ba6559b723cfe85c66bca47aac0abfbaac8e395c430bd7360105dc6f67625f7` |
| `tools/osp_semantic_probes.py` | `12585d9bed93cd2a5625ec1cd625287406a22d475b49c34ba931109630ea82d7` |
| `docs/solutions/2026-09-08-osp-retained-runtime-static-inventory-v2.json` | `d09b1f5dcb15d6d612b8b5301c2bb5f6a4c7f174b8e08eeff1df24b087c94be2` |
| `/private/tmp/livemore-osp-os-preflight-v2.Yc5Y4i/preflight-result.json` | `b579c9a1563b4309fa2127955faa2da16ada105051f1773865834f0e44f04b43` |
| `/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11` | `e3938f2a272dafdc33f3dd12b093dfc85354629476cb97a7d7d4a7201b8482dd` |

The canonical pure protocol digest remains
`5eb866376a2b121109066dbb11edad2eba701b3b85c8fe474ae1aa02b8e505e7`.
The existing seventeen XML byte/hash/count pins are in the [fixture report](2026-09-08-osp-semantic-fixture-implementation-review.md),
SHA `25f7f98296f3098d3960ee710de9cdf89aef06aae1233b0b492f0580e954695a`;
reuse them exactly, with the actual pure source supplying the fixed fixtures.

The [independent OS result](2026-09-09-osp-fresh-preflight-independent-result.md),
SHA `ddb02c343b4389b1742bfe3523c75d5452ee917f0bfb12f1a6411a7af09b89c2`,
clears O1–O7 only. Root observed exit0 and complete elapsed9.679222667s; the
retained result is `OS_PREFLIGHT_PASS`. Raw streams, both image barriers and the
separate O6/O7 refusal versus later terminal settlement were independently
checked. Exact owned PID absence was checked separately. This does not prove
R startup, CLR topology, the namespace hook or native image admission. The old
OS authorization/once files are inputs to history, never reusable run authority.

Retain the V2 resolution `/tmp/livemore-osp-native.mUlZwx` to
`/private/tmp/livemore-osp-native.mUlZwx`. `run_packet()` verifies the1390 identity
rows:1378 full hashes and12 bounded system-cache headers. The79 packages are a
declared closure, not a claim all namespaces load. System-cache membership/header
identity is not full cache-content attestation; anonymous JIT code is not hashed.
An unexpected image/path or changed identity fails admission, never expands the
allowlist. No install, build, download, repair or exploratory R probe is allowed.

## Frozen execution and collection

The ordered case IDs are exactly S01 through S17, with Run counts
`[2,1,0,0,1,1,2,2,1,1,1,1,1,1,1,0,0]`: seventeen fresh R workers and sixteen Run
calls **if the complete packet reaches all cases**. S03/S04/S16/S17 require their
exact prescribed Load/Finalize rejection, not an arbitrary startup/Run error.
S01/S07/S08 repeat on the same finalized object; these are planned reset probes,
not retries. First unexpected result stops subsequent cases as `NOT_RUN`.

Reuse the current fixed direct R executable, `--vanilla --slave -f` collector
and fixed case configuration, with the existing private home/tmp/cache and
explicit loader/thread environment. Preserve `library(ospsuite)` startup and the
namespace-visible original `system` hook before rSharp loads: exactly one original
`dotnet --list-runtimes` delegation per reached worker, no retry/private API.
No physiological importer, `osp_stage_b_native.R` or `gim_recipe.R` is invoked.

The R worker creates the same public Simulation, sets and checks the managed
cached options, records native-reported Run statistics and raw named arrays,
then takes FINAL **before Dispose**. PRE_XML remains before XML load. Each
checkpoint admits its own exact vmmap result against V2. Positive FINAL requires
actual CVODES presence, not forced loading; expected rejection does not invent
solver use. Dispose, system-binding restoration, process exit and owned cleanup
are independently mandatory. `IsConstant` means the public stored-size==1 marker,
not independent native semantic constancy; options are not independent native
readback. S16/S17 cannot attribute the shared malformed table's rejection to one
table without evidence. Restart trace remains unobservable.

Keep invented `u`/`tau` units, exact grids/output IDs, fixed XML/oracles and
double-bit repeat comparison. Keep AbsTol1e-9, RelTol1e-8, HMax0.05, UseJacobian1,
the existing other solver settings, no tolerance reduction and zero warnings.

No child-count confusion:17 R leaders is not17 total OS processes. A complete
packet can have34 separate vmmap inspectors plus the already bounded startup
helper topology. Short-lived helpers missed by sampling are not a complete exec
trace. No extra native call or checkpoint is added for identity collection.

## Unchanged bounds and stop conditions

Packet600s, each worker30s including its cleanup, CPU soft20/hard21s, sampled
RSS3GiB, sample target0.1/maxgap0.5s. Both inspectors retain3s complete/2.5s work
and0.5s cleanup. The post-owner captured-clock admission requires6s remaining
before inspector directory/spawn. Worker cleanup retains its3s proof/TERM/KILL
reserve. No new worker starts with less than35s packet time remaining.

Retain1MiB per worker stream,256KiB observation,4MiB case,16MiB structured packet,
64MiB packet tree and existing entry counts; inspector stdout512KiB/stderr8192.
These are observed/enforced supervisor limits, not guarantees against an
unresponsive kernel or scheduler. No uncertain identity may be signalled, no
unresolved slot reset, and no next worker after unresolved cleanup. An early
failure is a retained failed attempt, not authorization to fix and rerun it.

## Small remaining launcher boundary — proposed, not implemented

The reviewed `run_packet()` already owns fixtures, workers, inspectors, evidence
and comparison. It does not have a cross-process exclusive once marker, and its
`elapsed_s` is sampled before its final result write. Address only those external
authorization/completion boundaries with one fixed private `run_packet_once.py`
and one small offline test file in a new0700 control root. No repository runtime
or consumed-root edits, supervisor refactor, configurable CLI or OS abstraction.

1. Freeze the resolved new control-root path, launcher bytes/hash and exact
   `env -i` command before any actual decision. Use the pinned Python `-I -B`,
   fixed checkout, allowlisted PATH/locale and private HOME/TMPDIR/cache. Do not
   inherit credentials or alter the frozen R child environment. Verify expected
   source/input hashes before importing the exact supervisor and pure module;
   no unpinned project initializer/import path may execute implicitly.
2. Require a bounded strict root-authored authorization object with exact schema,
   launcher/input/OS-result/protocol hashes, case order, Run vector and unchanged
   limits. No unknown fields or permissive status coercion. Use an exclusive
   no-follow0600 `once.json` in the private control root before any native work;
   preserve it on every outcome, including pre-packet inventory failure. Existing
   marker, malformed authorization or identity mismatch means zero native work.
3. Require both source gates initiallyFalse and empty unresolved slot. Only a
   later explicit run decision permits this one private process to set those two
   in-memory flags for one `run_packet()` call, restoringFalse in `finally`.
   No gate source bytes or pure protocol/comparator flags change. Do not replace
   ownership, classifier, Popen, timing, fixture or comparator functions.
4. `run_packet()` creates its own fresh result tree beneath the private TMPDIR.
   If the call fails without returning a root, report no returned packet; do not
   assert none was created or invent a root. Retain actual returned/result
   identity, status and hash, with no rewrite of a raw failed result. Check final
   source pins again.
5. Start a separate monotonic completion measurement immediately before the
   call. Include final raw-result write, bounded admission and launcher completion
   write in the600s acceptance check. Require exact returned/on-disk result
   equality, fixed identity, no unresolved child and all17 required matches.
   A completion receipt requires exit0; sample/check elapsed again after its
   write, and return nonzero on overrun. Preserve the runner's earlier elapsed
   as such. This adds no time or worker to the packet, and does not claim a
   hard watchdog for blocked filesystem calls. Missing completion or lost exit
   evidence cannot pass. Bound each authorization/once/completion object to64KiB
   and the raw result to the existing16MiB. Control evidence is separate and
   immutable; do not add it to or enlarge the64MiB scientific packet tree.

Offline tests should exercise only these five mounted launcher branches, using
an inert fake `run_packet` and explicit native/process/network refusal: exact
success once; duplicate/concurrent marker refusal; missing/malformed/hash-changed
authority/input refusal; call failure/partial result and flag restoration;
absent/corrupt/mismatched/nonmatching result or late/write-failed completion.
No additional scientific tests, fabricated native evidence or live OS call.

## Requested next decision

Approve only that minimal private launcher/test implementation and its frozen
independent review next. Its final path/hash/command and root authorization are
still missing, so this document is **not execution authority**. Actual R syntax,
hook behavior, admitted startup/image topology and prescribed technical outcomes
remain unobserved and must fail closed during the one future packet; they do not
justify preliminary native probes. If separately authorized, stop at the first
unexpected outcome, review exact raw receipts and bounded owned PID identities,
and obtain a new decision before any follow-up. No automatic scientific run.

Lesson: OS ownership evidence and native technical behavior are separate gates.
Hash-bound once-only authorization and terminal completion must surround the
existing runner without changing its experiment or upgrading its provenance.

## Root pre-code decision

Root read this complete proposal, the actual seven-condition independent OS
report and the retained `run_packet` implementation. Approve only the small
private once-only launcher and inert tests described above. Reuse the exact
existing17 technical fixtures and16 planned Run calls; no native execution,
gate source edit, scientific tolerance change or model admission is authorized.
Return frozen files, test evidence and the exact command for independent review
before requesting a separately recorded actual execution decision. The original
insulin failure and all six scientific programs remain separate requirements.
