# Person intake: source time and explicit consent correction

Date: 2026-09-08. Parent R16–R19/R31/R47. Written before implementation;
independent pre-code review accepted. This continues, not replaces, full-profile intake.

## Reproduced source findings

The current Twins manual form defaults smoking to `never` and pre-fills three
consent scopes. `subjects.js` labels one `new Date().toISOString()` value as the
capture time of both the glucose observation and all four unrelated source records.
This is submission time, not evidence of when any of those measurements/records
were acquired. `profile_sources.py` currently checks only bounded nonempty text
for source capture time. Clinical observation validation already requires a
timezone and rejects a timestamp more than five minutes into the future.

The generic guidance correction has passed independent browser checks, but does
not fix these defects. Root inspected the entire manual form, source normalizer,
clinical initializer and relevant create/activate paths before this proposal.

## Bounded correction, preserving the existing workflow

1. Smoking initially means `unknown`, never an invented non-smoking history.
   Consent scopes start empty and remain required; explain that the operator
   must enter the actual consented scopes, not infer them from a product feature.
2. Manual entry requires an explicit original timestamp for the glucose
   observation and separately for the EHR, wearable, genomic and environment
   source records. No value is initialized to the current time and no timestamp
   is copied between sources. Use timezone-bearing ISO-8601 values, preserving
   input until the existing protected server normalizes accepted times.
3. Group source-time controls in a clearly labelled provenance section of the
   current form, with an explanation and discoverable validation feedback. Do
   not hide invalid required fields in a collapsed disclosure that cannot focus.
   Keep the current source/person controls, Atlas, Biology and history intact.
4. Reuse one server-side timestamp normalizer for observations and explicit source
   records: bounded string, valid ISO-8601, timezone required, existing five-minute
   future-clock allowance, canonical UTC output. Never repair an unknown date.
   Supplied malformed, timezone-free or future source records fail before a
   registry write with safe field-level error text, never echoing record contents.
5. Existing stored records are not rewritten, relabelled or deleted. The existing
   internally generated legacy-source fallback keeps its explicit `not_provided`
   marker and partial-coverage status; that is not authority for newly supplied
   source records to bypass timestamp validation. Historical capture time cannot
   be recovered from this patch. Registry creation time remains separate.

This is not a FHIR importer or an assertion that a typed source identifier has
been verified against a hospital system. Source quality remains `not_assessed`;
this patch does not upgrade QC, consent evidence, applicability or validation.

## Red-first tests and independent acceptance

- Pure timestamp tests: timezone offsets normalize correctly; empty, malformed,
  timezone-free, non-string and future inputs rejected; no time synthesized.
- Existing observation unit/QC/context mapping preserved. Explicit source-record
  capture times stay distinct. Legacy records remain inspectable without rewrite.
- UI payload tests use five different technical timestamps and verify all five
  reach their exact fields, with no submission-time substitution. Test required
  error feedback, reference→real switching and unknown smoking/empty consent.
- Protected API test: invalid source timestamp fails before persistence;
  authenticated technical valid record retains original temporal ordering.
  No actual human data, record activation, device command or experiment in tests.
- Actual browser desktop/mobile form inspection after an owned review restart;
  record local-only technical form interactions and rejected submission. Do not
  record PHI or submit an invented real participant as evidence of onboarding.
- Independent code review and rendered evidence inspection before acceptance.
- Reviewer-required negative cases: explicitly supplied `LEGACY_ADMISSION` with
  `not_provided` rejects; internal fallback and historical reads remain unchanged.
  UTC normalization overflow becomes a safe validation error. Switching reference
  →real→reference retains entered times/consent but disables hidden required fields.

## Explicitly retained adjacent requirements

Complete EHR/wearable/omics/history/lifestyle/environment ingestion and per-field
source reconciliation still need a reviewed bundle/import workflow. A source ID
alone must not stand in for actual domain data. The current genomics requirement,
empty-genome domain-presence test, single-lab physiology coverage and mandatory
lifestyle scalar need their own missingness/model-applicability correction.

`clinical_parameters.initialize_profile` also chooses T2D whenever free text
contains `diabetes`, including type 1 or diabetes insipidus. It must be replaced
by explicit model/context binding, not a larger substring heuristic. The existing
joint-reference binding proposal records the missing kinetic evidence; neither
this intake patch nor the cohort selector supplies it. These issues remain open
under R16–R19 and are not hidden by a new successful timestamp test.

Physical v3 provisioning/UI, independent clinical/wet-lab qualification and
reviewed state-update application remain separate R29–R32/R39 requirements.

## Ownership and lesson

Root owns the manual-form/subjects-controller changes, timestamp helper and
dedicated tests after review. Do not touch source/cache/Atlas renderer, native
workers, existing stores, package pointers, physical devices or other worktrees.

Lesson: data-entry time is operational metadata, never measurement time. A blank
clinical field must stay unknown, and consent must describe an actual permission,
not the software's preferred workflow. Preserve old evidence while correcting new
admission; passing software checks does not establish participant equivalence.

## Bounded acceptance record

The 15 initial timestamp checks failed before the shared normalizer was written.
Two real-controller/markup tests then reproduced prefilled consent and five
submission-time substitutions before the form/controller changes. The combined
timestamp, form, discovery and retained lifecycle/evidence packet passed73 tests.
Additional protected API and historical-ciphertext checks brought the dedicated
packet to19 passing tests (root11.74s; independent3.65s; three existing warnings).
Two added test expectations were corrected against the unchanged API contract:
validation uses422, not400; smoking is retained in `lifestyle_profile`, while
`lifestyle` remains the existing numeric activity input. No product code was
changed to satisfy those mistaken test assumptions.

The API tests instantiate the existing app, which constructs its native Myokit
runtime. This is not a no-native-initialization test; no participant activation,
submitted physiological experiment or physical-device command occurs.

Actual browser acceptance at8910 is retained in
`docs/screenshots/full-scope-recovery/intake/attempt-1/intake-evidence.json`:
source `d0f617d253ea45d13bcc69229b3bcbef93400a289788f9d557d969589f2c1917`,
Aegle instance `6cfd6814-66ee-4b57-9c5c-1e54d84071ca`, LIFE
`1f0b41fb-45b0-4d98-a07c-cd90d33f468c`, Cendos
`64c8f23b-e9e7-4e57-b372-7ec8e4ac78b2`. The genuine local form interaction
checked native required-field focus, initially unknown smoking and empty consent,
five independent timestamps, hidden-control disabling and value preservation
across source changes. Exactly one deliberately invalid, explicitly technical
submission reached the server and returned `PROFILE_SOURCE_INVALID`/422. No
participant was created; the registry before/after matched. No JavaScript errors
or390px horizontal overflow were observed. Root and independent reviewer read the
complete receipt and personally inspected all three desktop/mobile screenshots.

Remaining UX/clinical work is not closed: the manual form remains long, its error
toast uses an internal field path, source selection/smoking copy clips in narrow
desktop controls, and typed source IDs do not establish imported data or verified
consent. A real bundle importer, missingness-aware model eligibility and full
profile reconciliation remain required. No existing release or data was replaced.
