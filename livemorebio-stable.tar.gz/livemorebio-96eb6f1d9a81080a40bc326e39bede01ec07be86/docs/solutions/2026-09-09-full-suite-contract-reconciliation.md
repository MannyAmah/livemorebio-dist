# Full-suite contract reconciliation

Root plan before changes. The September 9 isolated full sweep returned 6,338
passes, nine failures, 43 skips and five network deselections in 397.52 seconds
(receipt `227e61`; collection 6,395). The preserved source tree and all failed
tests remain the baseline. Passing counts are software checks, not biological
qualification. No scientific skip is converted to a pass.

## Diagnosis and finite changes

- Packaging assertions still parse only `>=` after the reviewed converter was
  pinned to `trimesh==5.0.0`; verify the exact declared pin instead. The wheel's
  six-structure assertion must admit the new independently reviewed seventh
  structure and check its actual installed bytes/identity.
- The legacy snapshot test asks publication to borrow a different live object's
  parameters. The newer committed-publication contract explicitly forbids this.
  Supply the frozen snapshot's complete parameters, put different parameters on
  the unrelated live object, and retain exact full-parameter equality.
- The old preview double has only `clear_active_twin`, not the reviewed
  prepare/commit interface, and lacks its own parameter dictionary. Use an actual
  isolated registry and a complete authored preview; assert the confirmed
  generation transition and explicit invalidation callback.
- A lifecycle test passes independently but fails in the whole sweep. Isolate its
  server state, source authority and execution-manager reference instead of
  weakening stale-source rejection. Direct legacy setup must not leak state to
  another test.
- Changed-source legacy Patch requests now reject at the generation fence before
  binding validation. Retain exact 409 rejection, no forwarded request and no
  model-parameter mutation, while asserting the current exact error code.
- Current source retirement preserves immutable earlier objects/results and
  invalidates executions; it must not mutate a retained old twin. Replace the
  obsolete in-place-clear expectation with retained-receipt equality, invalid
  source/paused execution and rejection of further advancement.
- An incomplete real-human profile still remains partial. Activation now rejects
  earlier at the missing model binding. Assert that exact reason and unchanged
  registry lifecycle/version/no active pointer; do not invent a model binding.
- Physical-v3 copy now correctly states that complete onboarding is unavailable,
  rather than incorrectly promising the API/SDK supplies it. Test the current
  visible boundary and unchanged read-only protocol-v2 field.

These are narrowly justified test/fixture updates to already reviewed behavior,
not permission to weaken a product gate or change physiology. Root will run the
affected files and newer competing-contract suites, request independent review
of the complete diff, then repeat the broad sweep after source freeze. Any new
functional failure gets a distinct diagnosis; do not make it green by deleting
assertions or adding a skip.

## Maker receipt — nine-test reconciliation checkpoint

The nine authorized test files were corrected without production changes, new
skips, or changed scientific/model tolerances. Exact pre-edit files are retained
under `/private/tmp/livemore-contract-reconciliation.Eah9GX/`.

- RED: `f40005` → `f0e278`, **9 failed, 234 passed in 28.81s**, reproducing all
  nine diagnosed mismatches in the eleven-file selection below.
- GREEN: `be6213` → `cb0eac`, **243 passed in 31.78s**. One additional Patch
  no-parameter-mutation assertion was added while that invocation was already
  loaded; the following repeat covers the final frozen test bytes.
- Final repeat: `5d2e10` → `fa1564`, **243 passed in 29.18s**, with three existing
  deprecation warnings and no skips/deselections in the selected files.
- Baseline-relative complete diff: `reconciliation.diff`, SHA-256
  `0ec8921e3a59daef54f8ec0193c1b8c3da7f9fbdd052739db86ba19975060d6a`.
  Exact before/after identities: `pins.json`, SHA-256
  `c6b960ae93466469cb99adbf2c403ad27f66f02f8a45ffe53a096eedd8a5fbcc`.
  Both files are in the retained private directory above.

Exact repeat from this worktree:

```sh
LIVEMORE_TEST_MODEL_DIR=/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-rqo3olua/models /tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python tools/run_review_tests.py -q -p no:cacheprovider -m 'not network' livemorebio/tests/test_anatomy_meshes.py livemorebio/tests/test_wheel_runtime_data.py livemorebio/tests/test_scientific_integrity.py livemorebio/tests/test_model_source_authority.py livemorebio/tests/test_subject_lifecycle.py livemorebio/tests/test_patch_closed_loop.py livemorebio/tests/test_execution_observations.py livemorebio/tests/test_evidence_grounded_experiments.py livemorebio/tests/test_workspace_stream_ui.py livemorebio/tests/test_committed_publication_snapshot.py livemorebio/tests/test_confirmed_preview_publication.py
```

The retained-old-object/receipt/frame assertions now accompany paused, invalid
execution and exact `MODEL_SOURCE_CHANGED`/409 assertions. The standalone
manager's `advance_once() is None` tests its no-work polling branch, not a claim
that a product source fence raises there. Snapshot publication uses its own
complete frozen parameters, contrasted against a different live object. The
partial human profile remains partial and activation is rejected for its absent
model binding without changing its record or active pointer. Packaging checks
verify all seven installed structures, including exact 5VA2 bytes/identity.

Independent source-only review by `startup_origin` returned CLEAR for all nine
diffs; it did not rerun tests or exercise a browser. Root read the complete diff
and accepted the narrow contract alignment. This is a software-test checkpoint,
not biological qualification, a whole-suite result, or launch approval. Root
subsequently took ownership of `test_wheel_runtime_data.py` for a separate real
vendor-bundle packaging gap; that follow-on change is outside these frozen pins.

Lesson: test fixtures must own their publication parameters and isolated source
authority, while retirement assertions preserve historical objects and reject
new work. Stale expectations must not be reconciled by weakening those gates.
The requested Compound Engineering/gbrain tools were unavailable in this task;
this receipt records the lesson directly. An initial wrong-interpreter diagnostic
(`f9d4de`) stopped before collection with missing pytest and is not a test result.
