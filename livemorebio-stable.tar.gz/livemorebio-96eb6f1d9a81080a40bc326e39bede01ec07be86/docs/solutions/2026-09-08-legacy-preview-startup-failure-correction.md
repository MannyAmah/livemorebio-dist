# Legacy preview startup failure: source diagnosis and bounded correction proposal

Status: **pre-code proposal only**. No service/browser/native rerun, test execution,
runtime edit, package acquisition or operational-store access in this diagnosis.
The investigate skill was used for source-first diagnosis; reproduction and edits
remain behind root's separate approval. Existing failure evidence is unchanged.

## Retained outcome and exact limit of attribution

The once-only run stopped after 2.4832049580290914 s with
`SERVICE_OR_TRIPWIRE_FAILED`. Its original evidence root is
`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-legacy-preview-kju2ft7s`.
`supervision.json` SHA-256 is
`e5d104b6fbde43f124135b032d46700dcf5cf4539973a475bc152428ad3781d2`.
All three `service-{0,1,2}-guards.json` contain exactly
`{"installed":12,"model_execution":false}`. No tripwire fault, browser config,
Chrome child or image exists. Three children were reaped; listener inspection
recorded `NO_LISTENERS` and `SETTLED`. These facts do not identify which child
first exited or its exception. No traceback or original per-child exit code was
retained. The original run remains **FAILED**, not retrospectively reclassified.

## Concrete source defect

`tools/check_legacy_preview_browser.py:135` calls
`app.add_event_handler("startup", check_startup)` after importing Aegle and before
`uvicorn.run` at line 136. In the exact installed source below, this attribute
does not exist. There is no dynamic forwarding on either application class.
Reaching this statement deterministically raises `AttributeError`, with no
numerical or I/O tripwire needed. This is a concrete causal candidate consistent
with the retained failure; the missing original traceback prevents assigning it
as the observed exception from that run.

Installed source root:
`/tmp/livemore-fresh-venv.lSTVr3/.venv/lib/python3.11/site-packages/`.

| Evidence | Exact source | Version / SHA-256 |
|---|---|---|
| FastAPI inherits Starlette; application has `on_event`, not `add_event_handler` | `fastapi/applications.py:42`, `:4662–4687` | 0.141.1 / `38dccb19b2a0b0b984c8d7541263842954a37c087cf96b4463aea17873c6183c` |
| Complete Starlette application class lacks `add_event_handler` | `starlette/applications.py:19–143` | 1.6.0 / `1119714f44c8f5a39cbb5c9d0209e6fc13e7d5c18015dff3234adb5c52fa84a1` |
| Router owns the supported registration and ordered startup invocation | `fastapi/routing.py:6364–6377`, `:6396–6414` | `7b1ef65fb6b209445dc43be070a23324b7879aef9c6b9f63e6968234b7723b55` |
| Default lifespan invokes this router startup | `fastapi/routing.py:250–274` | same routing hash |

Product code already uses `app.router.add_event_handler` for shutdown in
`livemorebio/aegle/server.py:48–50` and `life_system/service.py:26`. No product
change is needed. Independent source-only corroboration by release_redteam
matched the application hashes and router seam; they ran no imports or tests.

The Uvicorn arguments are not a demonstrated failure: installed 0.52.4
`uvicorn/config.py:44–51` admits `critical`; `:381–423` accepts `log_config=None`
and `access_log=False`. `uvicorn/main.py:494` accepts an app object. The private
environment excludes `WEB_CONCURRENCY`; defaults do not request workers/reload.
Its lifespan handler can swallow an application exception and later exit with a
generic startup status (`lifespan/on.py:86–115`, `main.py:628–629`). Therefore
capturing only an outer `SystemExit` would still lose some future startup causes.

## Minimal proposed correction and diagnostic, before another launch

Own only `tools/check_legacy_preview_browser.py` and additive tests in
`livemorebio/tests/test_legacy_preview_browser_harness.py`; CJS, all 12 images,
seven cases, four intercepted POSTs, product source and original evidence stay
unchanged. The change is one supported registration call plus a small fixed
service-local failure observer, not a new service framework.

1. Change the callback registration to `app.router.add_event_handler` and retain
   its original order after Aegle's own startup handler. The observer still
   requires initialized, selected, observation-only/modeless state; no fallback.
2. Track a fixed in-memory phase in `run_service`: `GUARD_INSTALL`,
   `UVICORN_IMPORT`, `APP_IMPORT`, `HOOK_REGISTRATION`, `SERVER_RUN`,
   `LIFESPAN_STARTUP`, `RUNNING`, `LIFESPAN_SHUTDOWN`, `STOPPED`.
   A single transparent async context-manager wrapper delegates the existing
   `app.router.lifespan_context(app)` unchanged. It observes entry/exit failures
   before Uvicorn hides them; no route, handler body, event ordering, thread,
   resource policy, auth or HTTP payload changes. It re-raises the original error.
3. On first failure, write at most one private exclusive
   `service-{role}-failure.json` (maximum 1,024 bytes, existing 0600/no-link writer).
   Fixed schema `livemore.legacy-preview-service-failure.v1`; exact fields:
   `schema`, integer `role` 0–2, fixed `stage`, `outcome="FAILED"`,
   `error_class`, `exit_code` (integer only for numeric SystemExit, otherwise null).
   `error_class` is a fixed allowlist of `AttributeError`, `ImportError`,
   `RuntimeError`, `OSError`, `ValueError`, `TypeError`, `TimeoutError`,
   `SystemExit`, `KeyboardInterrupt`, `HarnessError`, or `OTHER`.
   Never serialize messages, traceback, file paths, locals, configuration, keys,
   notes, subject identifiers or arbitrary custom class names. If an inner lifespan
   failure is already retained, an outer SystemExit must not replace it. Evidence
   write failure must not mask the original failure; report only a fixed safe
   marker on stderr (still DEVNULL), with absence explicit in parent evidence.
4. On child death, parent retains all three observed pre-cleanup poll results
   (integer or null), and safely reads these three fixed failure filenames using
   the existing bounded original-file reader and strict JSON rules. Store fixed
   `PRESENT`, `ABSENT`, or `INVALID` receipt state; malformed evidence never becomes
   a cause guess or success. Read again after bounded cleanup for late receipts,
   preserving the original `SERVICE_OR_TRIPWIRE_FAILED`. A signal/abrupt exit with
   no receipt remains explicitly unattributed. No broad log collection is added.

## Required red-first offline verification and stop criteria

- Exercise the real `run_service(0)` path using an actual installed `FastAPI()`
  app with authored modeless state, while substituting product import,
  `uvicorn.run`, audit-hook installation and guard installation. No application
  service import, bind, listener, constructor or model may execute. The current
  unsupported registration must fail RED; the fixed version appends exactly one
  observer after an authored existing handler. Inertly enter the real router's
  lifespan to verify original ordering and the observer's modeless refusal.
- Import/registration/server-run and lifespan entry/exit failures retain exact
  fixed phase/class, including inner failure followed by outer SystemExit.
  Use private authored sentinels to prove messages, paths and clinical-shaped
  values never enter receipts. Evidence-write failure preserves the primary error.
- Parent's real control flow records pre-cleanup child outcomes and safely admits
  present/absent/invalid fixed receipts without masking its original failure.
  Retain existing 65 tests with the same strict offline refusal wrapper.
- Freeze hashes and send full source/receipt for independent review. No new actual
  startup, browser or diagnostic process is authorized by this proposal. If the
  inert installed-contract test does not reproduce the attribute failure, stop
  and reconcile loaded module identity before changing the launcher. Any further
  actual startup failure stops the run and retains the new fixed evidence; no
  automatic retry, disabled guard, numerical fallback or enlarged budget.

Lesson: mock-only launcher tests missed an installed framework API removal.
Test the real registration contract without a server, and preserve a bounded
failure phase rather than trading PHI-safe logging for a completely opaque exit.

## Root pre-code decision

Root read the full proposal, complete installed Starlette application class,
FastAPI router registration implementation and actual product registration call.
The exact installed versions and missing/supported API distinction agree with
the maker and independent source reviewer. Approve the two-file red-first
correction above, preserving CJS/product bytes and every original actual failure.
The lifespan observer must delegate the original context manager and preserve
exception propagation, handler order and cleanup; it is not a replacement
startup implementation. Bound evidence and keep only fixed safe fields.
Run the actual inert installed-contract RED before changing the call, then the
new diagnostic tests and original65 preservation cases under the same refusal
wrapper. Freeze the candidate for root review. No actual server/browser/native
execution, dependency upgrade or enlarged budget is approved by this decision.

## Frozen implementation candidate and offline receipt

Only the approved Python harness and dedicated test file changed. The unsupported
application call is replaced by the installed router contract. The original
lifespan context is delegated once, including yielded state and original
entry/exit exception propagation. The existing guard order and Uvicorn arguments
are unchanged. No application service was imported by the new regression:
the actual installed `FastAPI()`/router was paired with authored startup/shutdown
callbacks, a substituted product-module acquisition and inert `uvicorn.run`.
The async context was advanced directly, without an event loop or socket.

First-failure receipts are exclusive, fixed-field and bounded to 1,024 bytes on
read; emitted fields are fixed enums plus role and a signed 32-bit SystemExit
code or null. The inner lifespan failure survives a later generic SystemExit.
Custom exception names, messages and non-integer exit payloads are excluded.
Failed receipt writes retain the primary error and emit only a fixed marker.
The parent records pre-cleanup child exit observations and before/after receipt
states. A newly arriving shutdown failure or invalid receipt cannot leave the
overall run successful. Original failures are not replaced. The bounded file
reader now opens nonblocking before its regular-file check, so a substituted
FIFO cannot stall the parent's cleanup path before `fstat` rejects it.

All roots below are under
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/`.

| Stage | Private root suffix | Result | Time | Node / unexpected I/O / Git refusal |
|---|---|---|---|---|
| Installed registration and diagnostics RED | `livemore-research-review-pz146fci` | **14 failed / original 65 passed** | 3.82 s | 33 / 0 / 1 |
| Core correction | `livemore-research-review-vm44gaeg` | 79 passed | 3.91 s | 33 / 0 / 1 |
| Late shutdown diagnostic outcome RED | `livemore-research-review-eaynco49` | 1 failed / 82 passed | 3.88 s | 33 / 0 / 1 |
| Late failure retained | `livemore-research-review-lpgwnofr` | 83 passed | 3.98 s | 33 / 0 / 1 |
| Nonblocking original-evidence open RED | `livemore-research-review-76mrujpz` | 1 failed / 83 passed | 3.97 s | 33 / 0 / 1 |
| Final frozen packet | `livemore-research-review-p0uui78_` | **84 passed** | **3.92 s** | **33 / 0 / 1** |

The installed-registration RED was the exact `AttributeError` at old harness
line 135, not a missing test helper. Other failures in that first packet were
partly masked by the same registration error; their intended phase, identity,
failure-write and privacy assertions all ran green afterward. Original actual
run attribution remains unchanged: this is an inert deterministic reproduction,
not recovery of its missing traceback.

| Frozen file | Lines | SHA-256 |
|---|---:|---|
| `tools/check_legacy_preview_browser.py` | 494 | `ea6f496a053b3afc91fc1f26542721416764303fd66aaf67af10a18d99ce4de1` |
| `livemorebio/tests/test_legacy_preview_browser_harness.py` | 557 | `c70f09ac7050c13cb0be5c0299c746ef9ac47ace34c59840fe32663ea365b993` |
| Unchanged `tools/check_legacy_preview_browser.cjs` | 271 | `b80c2bd5a7be145d3def489830152313a7d65f66efbe536ed1c1eff658c9c71d` |

Use the unchanged exact guarded stdin command in
`2026-09-08-legacy-preview-browser-harness-implementation-review.md`, under
“Exact guarded offline repeat”, from the full-scope-recovery worktree. The final
run used `--tb=short`; RED output used `--tb=line` only to bound diagnostic output.
No dependency, product, CJS, source input, operational store or resource limit changed.
No actual service, browser or native process ran. This packet is frozen for
maker-external grading; a further once-only launch still needs root authorization.

## Root independent review and corrected once-only launch

Root reviewed the frozen implementation and installed registration contract, and
independently repeated all84 offline cases: **84 passed in3.91s**, exit0,
private root `livemore-research-review-3qwzhnk_`, Node33 / unexpected I/O0 /
Git refusal1. The three frozen harness/test hashes above match; the package remains
`d0311baf6fd4cd8cc6754685471cc11bd8712c53b30afc952fb9295e31c5aac4`.
No product source or operating data changed for this launcher correction.

Authorize one execution of this corrected candidate with the existing fixed
seven-case/twelve-image acceptance plan. Reserve8910–8912 for its private stack;
the existing preflight must refuse occupied ports. Retain the prior failed launch
as failed. This is a new candidate test, not an automatic retry or a biological
experiment. All previous limits, tripwires, source checks, response-fixture labels,
stop-first-failure and exact-owned cleanup remain. Root must inspect the original
receipts and every produced image separately. No inline source repair or further
actual rerun is authorized by this decision.

## Corrected candidate: original actual result

The authorized corrected launch exited1 after17.748s, session78605. Original
evidence root is `/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-legacy-preview-upv6333e`.
All three services started with exactd031 package identity, installed12 tripwires
each and no guard fault or service failure receipt. Startup compatibility is
therefore exercised successfully, but the browser workload is **FAILED**.

D0 failed with `BROWSER_CHECK_FAILED`; D1/D2/D3/D4/M1/M2 are NOT_RUN. Eighteen
allowlisted actual GETs, one observed204 bootstrap, zero admitted baseline reads,
zero POSTs and zero images. The error category does not reveal the failing
browser operation; no specific product fault is inferred from this opaque result.
No response fixture or scientific experiment ran.

Original browser cleanup lists page/context/browser SETTLED. All four owned
children were reaped,11 tracked descendants absent, and8910–8912 had no listeners
with settled inspection. No cleanup/evidence failure is reported. Original hashes:
supervision `78be1737f6075b77f342ed5957d6d7421db05bebcb20a1223395850075ed8cfb`;
browser result `0505db6786cf15d28ddb1e756cebe2d3d59fab9b237fd1d22e32984895e82048`.
Root read both originals. Static maker-external diagnosis requested; no automatic
rerun or source change is authorized. Missing failure screenshots are also a
diagnostic limitation, not a rendered acceptance pass.
