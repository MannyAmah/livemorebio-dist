# OSP owned-target vmmap diagnostic: private implementation review packet

2026-09-09. Maker packet only; independent source review and an actual launch
decision remain separate. No worker, vmmap, R, CLR, model, service or browser was
launched by this work. No production file, scientific gate, budget or old receipt
was changed. The original O1 result remains **FAILED**; O2–O7 and S01–S17 have not
been advanced by this diagnostic preparation.

## Approved scope and frozen files

The fully read [plan](2026-09-09-osp-owned-vmmap-diagnostic-plan.md), including
root's pre-code decision, is SHA256
`a470cd0d8e1d307a311697828f99ddbbe86355c464ca4648b0387e7046a51edb`.
Only three new files exist in
`/private/tmp/livemore-osp-vmmap-diagnostic.3D8Ode` (directory0700, files0600).
No authorization, once marker, output directory or actual result exists there.

| File | Lines / bytes | SHA256 |
|---|---:|---|
| `run_diagnostic.py` | 228 / 12005 | `7bd6d24b18a0d2babe97fb5c1297b925279c1bb32c76087877c04ad2005e63d1` |
| `worker.py` | 61 / 2063 | `c19a69d319e49c76cacca66c119fd250b98e9f37d5c1419ce22f0437a5f2f607` |
| `test_diagnostic.py` | 200 / 10298 | `7617fe11f5133d6d40d10326955930d70f848a647b6da08201dd7d8a47208bf1` |

The driver reuses only the frozen preflight module's inert loader, static pin
checker and clean environment helper. It never calls that module's matrix/run
or cleanup shortcuts. That helper path is
`/private/tmp/livemore-osp-os-preflight.AFtKah/run_preflight.py`, SHA256
`90ee5c09988a1d2b6c0875f3bdf8adea637a3c2cb0d8928c34044a69b9ab6f48`.
Its exact original Python/vmmap/OS pins and source pins are checked before and
after collection. Reading its additional original sleep/fixture pins is not an
invocation or an additional diagnostic candidate.

Frozen supervisor, pure fixture and R source hashes remain respectively:

- `cdb00a1acb5b08b3f7d8aff0f3977f746b5a506ed4f97355b56dd34bf2d2a476`
- `12585d9bed93cd2a5625ec1cd625287406a22d475b49c34ba931109630ea82d7`
- `3ba6559b723cfe85c66bca47aac0abfbaac8e395c430bd7360105dc6f67625f7`

The new diagnostic flag, original preflight flag and both supervisor production
flags are false. Importing source in the tests is inert; the real OS sampler,
child launcher, ownership implementation and worker main are not executed.

## Implementation boundaries

One new exact-hash authorization and exclusive once marker precede any child.
Strict canonical JSON comparison distinguishes `true` from numeric1. A wrong
pin/gate/authority stops before marker/evidence creation. No CLI accepts a
different worker, target, command, output directory or budget.

The fixed worker is isolated Python `-I -B`, with no shell/fork/exec/native work.
It atomically emits source-bound READY, writes fixed stdout/stderr markers, then
waits for the exact ACK. Duplicate/malformed/oversized/mismatching ACK fails;
its16s natural failsafe is not a timely15s success fallback.

The driver delegates both actual children to unchanged `_execute`/Owned,
sampling, streams, proof and cleanup. Its only specialization is the approved
private `_check_processes` classifier: exact worker image/argv/no descendants;
the sole inspector delegates to the original classifier and must name that
proven worker. Classification history preserves contradictions, bounded to64
unique rows. The original callable is restored in `finally`. No slot reset,
ad-hoc signal, manual reap or uncertain-owner retry exists.

The whole20s clock starts before imports/pin reads. Full15s remains before
worker spawn, and full13s remains before the sole10s inspector. All deadlines
are capped by the original common deadline. Original3s/.5s cleanup reserves,
CPU/RSS/sampling/stream/output limits remain unchanged. The worker sampler is
the inspector's `outer_tick`. Repeated READY callbacks cannot create a second
inspector or ACK.

Original inspector and worker receipts are attached before fallible evidence
writes. Raw streams are retained with independent file-byte/hash/length links;
receipt observed lengths/hashes remain untouched, including overflows. Clean
mapping requires original process admission, positive samples, complete EOF,
no errors/overflow/TERM/KILL, full strict vmmap parsing and same-worker proof.
Timeout/nonzero refusal retain their original primary/exit/streams and receive
no ACK; the worker must have confirmed original TERM/KILL cleanup. Uncertain
ownership, parser/stream/disk failures or incomplete evidence stay failed.

Only `CLEAN_MAPPING` may yield `DIAGNOSTIC_COMPLETED`. Even that label is
diagnostic-only, never OS_PREFLIGHT_PASS or scientific permission. Final receipt
explicitly requires exit0. Stored `elapsed_s` is labeled pre-final-write; stdout
reports complete elapsed after final write and final disk/deadline checks. A
late write can leave its original receipt with a success field, but exits
nonzero; reviewers must not admit the JSON alone or rewrite it afterward.

## Test-first evidence (eight groups / eighteen cases)

The eight authored groups cover admission, fixed scope, nested reserves,
mapping/ACK/parser, timeout/refusal, held ownership, failed/late evidence, and
original-input/non-scientific preservation. Process APIs are in-process
stand-ins; the real pure bounded-stream/admission/parser/JSON helpers are reused.
This is not an OS lifetime, actual latency, scheduler or permission test.

1. Initial missing-driver RED: **18 setup errors,0.12s**, private root
   `livemore-research-review-ww97bykk`; exit1, unexpected I/O0. This is the
   intentionally absent implementation boundary, not eighteen proven OS faults.
2. First implementation: **4 failed /14 passed,0.15s**, `y7gun3qn`; exit1,
   unexpected I/O0. My driver used a nonexistent stream receipt key `bytes`;
   the frozen producer's actual key is `retained_bytes`. The raw authored
   inspector/worker receipts remained in that test's failed output.
3. Corrected key: **18 passed,0.15s**, `7vvgml3j`; exit0, unexpected I/O0.
4. Final source, additionally requiring stopped-worker exit -15/-9 for failure
   classifications and checking whole disk size after final write:
   **18 passed,0.15s**, `broop5q5`; exit0, unexpected I/O0.

All four private roots are below
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/`.
The original RED/intermediate failed output was not deleted or regraded.

## Exact inert repeat command

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`. This invokes
pytest only; it does not invoke either new executable's main.

```bash
PYTHONDONTWRITEBYTECODE=1 /Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B - <<'PY'
import os,sys,signal,socket,subprocess,urllib.request,multiprocessing.process
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:v for k,v in os.environ.items() if k in ('PATH','HOME','TMPDIR','LANG','LC_ALL')})
env.update(PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1');os.environ.clear();os.environ.update(env)
counts={'unexpected_io':0}
def deny(*a,**kw):
 counts['unexpected_io']+=1
 raise AssertionError('Unexpected network, native load, or child in offline OS-preflight tests')
for owner,names in ((socket,('socket','create_connection','getaddrinfo')),(subprocess,('Popen','run','call','check_output')),(urllib.request,('urlopen',)),(multiprocessing.process.BaseProcess,('start',))):
 for name in names:setattr(owner,name,deny)
def hook(event,args):
 if event in ('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.exec','ctypes.dlopen'):deny()
sys.addaudithook(hook);signal.alarm(45);print('Private test root:',root,flush=True)
import pytest
code=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(root/'pytest'),'--tb=short','/private/tmp/livemore-osp-vmmap-diagnostic.3D8Ode/test_diagnostic.py'])
print('Refusals:',counts,flush=True);signal.alarm(0)
raise SystemExit(code or bool(counts['unexpected_io']))
PY
```

## Original failure preserved; next gate

Read-only hashes still match the original preflight's result, authorization
and once marker:

- result `1bbb6d3290bbf6bcc0869341d0447f8c02aefd333ef2a9eef6397013cd45446c`
- authorization `05a7904a1883215074688fb3602afed42f482dab3ac1962a6ae9cdbb056d80f6`
- once `0bede77cf0cefbd0bb679583e74fc406d4e25e5e0739efb7202a8ade3625fac2`

The [retained failure diagnosis](2026-09-09-osp-os-preflight-vmmap-timeout-diagnosis.md)
still makes no permission/SIP conclusion. This packet requests independent
source/test review only, followed by a separate exact once-only launch decision
and source-pinned launcher. No follow-on preflight/native callback is present.

Compounded lesson: source-level receipt schemas must be read directly and used
exactly; a diagnostic exit and its final-write boundary are part of evidence,
not interchangeable with a JSON success field. Keep both inconvenient failures
and diagnostic-only bounds distinct from scientific acceptance criteria.

## Root independent review and once-only diagnostic decision

Root read all228 driver,61 worker and200 test lines, the full plan/report and
rechecked the original execution/cleanup/parser seams. All three hashes match
the freeze. Independent guarded repeat using the fresh Python3.11 environment:
18 passed in0.18s, private root`_op1r77o`, unexpected I/O0.

Authorize one execution of this exact private diagnostic only, using its new
authorization and exclusive once marker. Enable only the imported private
diagnostic flag in memory; leave all files' gate defaults and both production
flags unchanged. One waiting Python worker and one owned-target vmmap, fixed
20/15/10s complete limits. No R/CLR/model, follow-on preflight or experiment.
Preserve raw receipts even if failed. Root must read actual evidence and exit
before deciding any next action; original O1 FAILED remains immutable.

## Actual diagnostic — failed parser acceptance, not tool timeout

Root executed the authorized new diagnostic once: session29962 exit1,
complete elapsed1.931422875s. Retained diagnostic-result SHA256
`4c437eaafca75f57a4063f71309d71a5ea1ef148d63dd9cde6e5ce97ce9e1112`.
Inspector15512 itself exited0 without TERM/KILL in1.8060875s (cleanup0.001037417s),
17 samples, maximum gap0.1149155s. Raw stdout322954 bytes SHA256
`0559751779f8c0c98bd1ef1ea40001bf5a92ae70027fd790d5ada845cbcd96c1`,
stderr0; both EOF/no overflow. This single clean tool completion exceeded the
original1.5s work allowance; it does not estimate a reliable upper latency bound.

The unchanged full-path parser rejected an actual row with
`INSPECTOR_AMBIGUOUS_ROW`. No ACK was issued. Worker15511 was stopped through
owned TERM, exit-15, settled empty-before-reap in1.858758042s,17samples and
maximum gap0.114753791s. Its stdout25/stderr8-byte fixed markers match hashes
`9b85d209c2fe6467d713ead67751e588a83ae19bf11ee322e4f4bfb35875993e`
and`d2899ec1b86671b253f49a4b7780fbbe645e9aa41871cbe5ea5fa0b2415c28c8`.
Both owned processes are absent on root's targeted post-check. No unresolved
owner, stream/evidence error, second inspector or scientific execution occurred.

Overall status remains FAILED/UNRESOLVED_OR_EVIDENCE_FAILURE because mapping
acceptance failed. New authorization SHA256
`a26a9eef790703dc0311172942241515acb1bbdb38266b51bed497632dde853e`
and exclusive marker`a353011f4e95918b16748bd14fc97bfc8b249b5840a2d6ba98b625a19ad24388`
are preserved. Root read the complete result and initial original map rows;
independent diagnosis of the complete retained output is next, without another
OS run. Original O1 FAILED and all production gates remain unchanged.
