# Cendos single-selector implementation

Root approved written plan `d80e87e886e2536755b395cff38157c1f377844c426c901d4f6dde95e89e5d61`
before runtime changes. Runtime is frozen; root independently reviewed source
and owns the actual browser/restart/recording. Maker tests are not browser or
scientific qualification.

## Exact delta and evidence

Only `livemorebio/aegle/console/cendos.html` and
`livemorebio/tests/test_cendos_preparation_ui.py` changed. No old test assertion
or fixture was removed or edited. Twelve new parametrized cases were appended.
No backend, auth, biological, native worker or catalog source changed.

The existing selector has an empty initial choice and four exact preserved
protocols. Existing forms use their `hidden` boundary; only the selected form is
shown. Shared status/rerun warnings stay outside hidden forms; legacy tools stay
collapsed. New resets the selection to blank. Rerun restoration selects its
exact protocol and locks protocol switching until New. Existing PROTOCOL_BUSY
and contextRevision prevent pending operations/readbacks from changing the
selection. Execution request bodies and endpoints are untouched.

- A first test collection attempt used pytest's reserved parameter name
  `request`; this was corrected before the actual RED and is not behavior evidence.
- Genuine RED `edfaa6`: **12 failed / 15 passed in 3.70s**, I/O0, Node26, Git0.
- Dedicated GREEN `39d446`: **27 passed in 3.48s**, I/O0, Node27, Git0.
- Required inherited eight-file preservation `e5bf43`: **81 passed in 8.18s**,
  I/O0, Node74, Git-refused1 (never executed), two inherited FastAPI deprecations.

Boundary disclosure: a follow-up was mistakenly expanded to the entire
`test_lobeline_ui.py` before noticing that its fixture executes a pure
source-pinned Lobeline assay calculation. The stop attempt arrived after its
104-case completion (`e99245`, 10.42s, I/O0). No native/service/browser/network
ran, but this exceeded the intended inert-only maker scope. It is not the
requested acceptance run, no scientific claim is inferred, and the expanded
command will not be repeated. The exact required81 repeat below excludes it.

## Frozen pins and task-base diff

- Cendos HTML SHA-256: `dbebf03586136b3a7fd98e50af1538a6881409c3e6ca2963e8b834a370d4722a`
- Dedicated tests SHA-256: `522b4586b88fe8d2fb2461044ab14cef385038646db91dfde287cf31e9262fb7`

Exact pre-task copies are retained at
`/tmp/livemore-cendos-selector.zt7Z8G/cendos.html` and
`/tmp/livemore-cendos-selector.zt7Z8G/test_cendos_preparation_ui.py`.
Compare each with its corresponding worktree path. Do not use the unrelated
dirty Git baseline as this task's delta. Root independently read both exact
diffs and cleared the narrow source before repeating tests/browser QA.

## Exact required81 repeat

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os,signal,socket,subprocess,sys,urllib.request,ctypes
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('OFFLINE_DEADLINE')));signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.socket.bind=socket.socket.listen=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and cmd and cmd[0]=='node':cmd=['/opt/homebrew/bin/node',*cmd[1:]]
 if isinstance(cmd,list) and (len(cmd)==4 or len(cmd)==5 and cmd[4]=='file:///Users/emman/Livemore/.worktrees/full-scope-recovery/livemorebio/aegle/console/lib/execution_view_state.js') and cmd[:2]==['/opt/homebrew/bin/node','--input-type=module'] and cmd[2] in ('-e','--eval'):
  counts['node']+=1;permit=True
  try:return run0([*cmd[:3],'import {createRequire as scopedRequire} from "node:module";const require=scopedRequire(import.meta.url);'+prefix+cmd[3],*cmd[4:]],*a,**k)
  finally:permit=False
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1;permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
class NoModels:
 @pytest.fixture(autouse=True)
 def prevent(self,monkeypatch):
  from livemorebio.tests.clinical_registry_fixtures import forbid_compilation
  from livemorebio.aegle.runtime import AegleTwin, MetabolicProfile
  forbid_compilation(monkeypatch)
  monkeypatch.setattr(AegleTwin,'__init__',deny)
  monkeypatch.setattr(MetabolicProfile,'__init__',deny)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=line','livemorebio/tests/test_cendos_preparation_ui.py','livemorebio/tests/test_cendos_compact_members.py','livemorebio/tests/test_clean_workflow_ui.py','livemorebio/tests/test_protocol_inspection_ui.py','livemorebio/tests/test_population_capabilities_ui.py','livemorebio/tests/test_life_empty_selection_ui.py','livemorebio/tests/test_clinical_execution_ui.py','livemorebio/tests/test_execution_view_ui.py'],plugins=[NoModels()])
print('Refusal counts:',counts,flush=True)
raise SystemExit(status)
PY
```

## Lesson

Root independently read the entire exact before/after runtime and12-test delta,
confirmed the existing `[hidden]` styling and unchanged mutation endpoints, and
repeated the exact eight-file guard: `4b6199`, **81 passed in8.64s**, unexpected
I/O0, Node74, Git-refused1. Source review is CLEAR for this narrow correction.
Actual final desktop/mobile inspection, rerun/New and recording follow a normal
restart of only the isolated8868/8869/8870 review stack. This is not acceptance
of the four protocols' scientific validity or R40's six different programs.

An empty result panel is not a blank experiment preparation when a protocol is
preselected and several independent input forms remain visible. Keep protocol
selection explicit, preserve all protocol identities, and restore the selection
with immutable rerun lineage rather than merely restoring hidden input values.
