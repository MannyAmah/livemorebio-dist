# Frozen public-reference cohorts: integrity and admission lessons

2026-09-08. Approved parent scope: descriptive source-linked cohorts, not an
executable healthy population or a clinical enrollment route. See the
[reviewed lifecycle amendment](2026-09-08-descriptive-reference-cohort-lifecycle-amendment.md).

## Implemented boundaries

`reference_cohorts.py` freezes whole source-derived joint records inside the
existing AES-GCM registry, with an encrypted ordered member integrity manifest.
`reference_cohort_api.py` supplies authenticated/no-store source admission,
preview/create, and member inspection. Metadata-only access events commit before
data return; creation and its audit commit atomically with all members.

The signed preview binds the store, exact draft, source/definition/construction
hashes, and loaded normalization identity. The idempotency lookup uses a
domain-separated HMAC, not the caller's header text. Committed matching retries
remain readable after preview expiry or source-cache removal. New creation
requires the current verified source and decoder.

`PUBLIC_REFERENCE` and its cohort/member schemas are not enrolled persons or
physiological models. The direct registry/model/protocol guard rejects explicit
missing bindings, including descriptive members wrapped in a legacy-looking
cohort. Legacy frozen research cohorts retain their earlier contract.

The UI preserves the existing model/enrolled-twin form and adds a separate
joint-source preparation mode. It shows source/count/criteria provenance without
printing selected participant measurements in previews. Member values are
available only through explicit authenticated local inspection. Cendos lists
descriptive cohorts as unavailable for execution instead of silently substituting
a diabetes template. Real-browser acceptance remains pending the root's isolated
restart and independent review checkpoint; controller tests are not a substitute.

## Independent findings and corrections

1. A wrapper around an explicitly unbound member initially had only an
   `executable:false` flag at its top level. Overriding that flag could pass the
   lightweight direct guard. Independent review reproduced it. The wrapper now
   carries a dedicated descriptive schema and source class; the guard also checks
   nested descriptive references and explicit null binding. Tests use an actual
   stored/retrieved member, not merely an invented marker dictionary.
2. Plaintext SQLite idempotency/request indexes are lookups, not authenticated
   request identities. Independent review changed the request-hash index to a
   different valid preview and reproduced a false successful retry. The encrypted
   record now binds both request identity and idempotency fingerprint; every read
   recomputes the former and compares both indexes. Tests also swap idempotency
   indexes between cohorts. Corruption returns503 without reference data.
3. Loaded transform identity must describe memory, not whichever source file was
   edited after import. The new identity gate captures loaded Python code,
   decoder entrypoint/defaults, module function defaults, ordered table constants,
   rule/source definitions, and package versions. Known pandas2.3.3/Python3.11
   XPORT and read_sas entrypoints are explicit reviewed identities. Runtime code,
   default or order replacement rejects new normalization. This is software
   reproducibility evidence, never scientific qualification.

The separate review caught the first two failures before any real source cohort
was persisted. A subsequent bounded self-review refinement added the decoder
entrypoint/default/order regression under independent method approval. No raw
NHANES rows, source participant numbers, secrets, or public member-value screenshots
were written into the repository.

## Verification checkpoint

- Red-first lifecycle/API/controller/guard regressions are present.
- Prior independent source/core review reproduced all14 official source hashes,
  normalization counts and missingness without changing source bytes.
- Independent lifecycle rerun:109passed before the final defensive malformed-field
  and loaded entrypoint/default/order follow-up.
- Broader local lifecycle/source/UI/legacy subject suite:135passed, three existing
  framework deprecation warnings. The later entrypoint/default/order test separately
  passed (10identity tests total).
- Actual browser and root integration tests remain separate required acceptance.
- Qualified executable source-derived healthy/non-T2D cohorts remain open work;
  no internal nine-parameter assumption bundle was activated by this packet.

CE commands/gbrain were unavailable in this tool session. This local durable
decision record is the compounding fallback, not a claim that those tools ran.
