# OSP OS-only preflight: retained first-inspector timeout diagnosis

2026-09-09. Independent read-only failure assessment. No retry, OS sampler,
vmmap invocation, fixture child, R/CLR/model, browser, service or network request
was performed for this assessment. No existing evidence, driver, supervisor,
fixture, gate or budget was changed.

## Verdict

The initiating observed failure is **WORKER_DEADLINE in the first vmmap
inspector**, consistent with its approved1.5s work cutoff inside the2s complete
call budget. Both attempted owned groups settled cleanly. The cause of vmmap
not finishing within that work window is **not established** by the retained
output. In particular, this is not evidence of a permission/SIP denial, a
parser failure or a measured requirement for a longer timeout.

No functional code correction is justified by this receipt alone. Keep the
original OS preflight FAILED. O2–O7 and every R/native scientific case remain
NOT_RUN. Do not shorten the cleanup reserve, extend the2s complete-call budget,
accept missing image evidence or substitute another tool merely to pass.

## Retained identity and verified links

Evidence root: `/private/tmp/livemore-osp-os-preflight.AFtKah`.
Root reported actual session25355 closed with exit1. This reviewer did not
launch or independently rerun that process.

| Artifact | SHA256 |
|---|---|
| preflight-result.json,6537 bytes | 1bbb6d3290bbf6bcc0869341d0447f8c02aefd333ef2a9eef6397013cd45446c |
| authorization.json | 05a7904a1883215074688fb3602afed42f482dab3ac1962a6ae9cdbb056d80f6 |
| once.json | 0bede77cf0cefbd0bb679583e74fc406d4e25e5e0739efb7202a8ade3625fac2 |
| evidence/O1/request-1.json | 8f60a8b5bfed9edaa70a7224e9aef9577f4c5597b556a5d05f2f87fcf1a85b05 |

The authorization and once marker have equal decoded values; their different
byte hashes reflect their original serialization, which was preserved.
They bind the frozen driver/fixture/supervisor hashes and exact seven-case
60s/9-direct-plus1-descendant scope.

Independently checked original JSON equality:

- evidence/O1/result.json equals the final packet's complete O1 row.
- evidence/O1/process.json equals O1's worker process receipt.
- evidence/O1/PRE_XML/process.json equals its sole inspector receipt.
- All four original stream files exactly match their retained and observed
  lengths/SHA256 values, have EOF and no overflow.
- request-1 is the exact PRE_XML/sequence1 barrier for PID12130 and the frozen
  supervisor. There is no ack-1 or request-2. No FINAL inspection occurred.
- The six remaining rows are exactly O2 through O7 with status NOT_RUN.

Current read-only rehashes of the frozen code still match the actual receipt:

| File | SHA256 |
|---|---|
| run_preflight.py | 90ee5c09988a1d2b6c0875f3bdf8adea637a3c2cb0d8928c34044a69b9ab6f48 |
| fixture.py | 6104182d06c6e75069ffb6e062c9e11e9c88be6c7605dbeb9cfec955886bb239 |
| test_preflight.py | 30de19f87c979fee23de4930c5eccc48311fa288c85de581df931f546ac8d2ff |
| tools/osp_semantic_supervisor.py | cdb00a1acb5b08b3f7d8aff0f3977f746b5a506ed4f97355b56dd34bf2d2a476 |

## What actually happened

| Observation | vmmap inspector | Python worker |
|---|---:|---:|
| PID / group leader | 12131 | 12130 |
| Primary | WORKER_DEADLINE | PROCESS_FAILED |
| Complete elapsed | 1.5203985829721205s | 1.5618170829839073s |
| Cleanup elapsed | 0.016692915989551693s | 0.0038857909967191517s |
| Cleanup / empty before reap | SETTLED / true | SETTLED / true |
| TERM / KILL | true / false | true / false |
| Observed exit | 255 | -15 |
| Samples / maximum gap | 15 /0.1064411670085974s | 15 /0.10607183299725875s |
| Peak sampled group RSS | 37,027,840 bytes | 17,301,504 bytes |
| Sampled CPU | 18,960,044ns | 510,835ns |
| Stream/evidence errors | empty / empty | empty / empty |

Inspector argv was exactly `/usr/bin/vmmap -w 12130`. Its retained identity and
sampled rows matched that executable/argv and its own group. No sampled RSS,
CPU, cadence or stream limit caused this failure.

Inspector stdout is empty, SHA256
`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.
Its entire40-byte stderr is:

```text
vmmap: terminated; resuming target task
```

Stderr SHA256 is
`41bc02d0afd3ef5b8d3300c1702fdf2d5c1beab98516c49198fb0ded1b8253a4`.
This termination/resume message is consistent with its recorded TERM cleanup;
it does not establish why the preceding collection had not finished, or an
independent successful permission/attach proof.

Worker stdout is exactly `O1:worker\n` (10 bytes), SHA256
`3f5e4e6751c80250f72dd99e7b3639e6a724c75d94f5d57bffff53642ae31ff2`.
Worker stderr is exactly `osp-os-only\n` (12 bytes), SHA256
`4ad914216d8422916e61d3391d3d3110d29bbd535c11c1cd681226f2484a2134`.

Final packet status is FAILED, primary CASE_FAILED, slot_occupied false,
elapsed_before_final_receipt_s1.6225516250124201. Root separately reported
post-run absence of both PIDs. That historical OS postcheck is root's direct
observation, not a new independent process check by this reviewer. The raw
process/group-cleanup evidence itself was independently read and linked above.

## Source trace and primary documentation

Private run_preflight.py227–234 gives the inspector
`min(outer_deadline, monotonic()+2)` and applies original strict process
admission. Supervisor681–689 intentionally reserves cleanup inside the
complete call: `work_end = deadline - (.5 if inspector else 3.)`. For the
unchanged2s inspector this is approximately1.5s of work, including its startup
and sampling overhead, plus reserved cleanup. The receipt's1.5204s total and
16.7ms cleanup are consistent with crossing that work cutoff. Exact check-time
timestamps are not separately recorded, so no more precise cutoff timing is
claimed from subtraction.

Supervisor729–735 rejects the inspector's non-null primary as PROCESS_FAILED.
That propagates to the outer worker's preserved primary. The private O1 grader
then rejects its expected-success branch as PRIMARY_OR_SAMPLES; the matrix
adds CASE_FAILED. Those wrapper labels do not replace the retained initiating
WORKER_DEADLINE in the nested inspector receipt. No image parser was reached.

Read the complete installed Apple primary manual `/usr/share/man/man1/vmmap.1`
(8048 bytes; SHA256
`cdd8195c81895d2dd261717aa73056e94546969ee4f887aed37888be3baaa18a`).
It documents `-w` as wide output showing full mapped-file paths and explains
that default split-library output selects libraries loaded by the target,
whereas `-allSplitLibs` includes unloaded shared-cache libraries. It supplies
neither a completion-time guarantee nor a diagnosis for this retained stall.
`-summary` drops individual region detail and is not an equivalent replacement
for required loaded-path evidence. No undocumented flag or alternative
permission mechanism is inferred.

## Smallest next authorization recommended

**Authorize only a bounded read-only primary-source investigation of the
pinned vmmap collection/termination path and documented collection modes.**
Its question is whether an evidenced cause or an equivalent documented
loaded-path mode can be established while preserving current ownership and
complete-call bounds. No implementation, retry, elevated privilege, SIP change,
new subprocess, inspector substitution or S01–S17 execution is authorized by
this recommendation. The full preflight should not be repeated unchanged merely
in hope of a faster run.

If static evidence cannot resolve the cause, root must separately choose and
review an exact diagnostic-only OS experiment before any launch. It must answer
a concrete unresolved question and preserve this FAILED baseline; it cannot
count as a pass of O1 or authorize native biology. No such experiment or budget
amendment is proposed or performed in this report.

The evidence-supported correction now is reporting precision only: call this
a1.5s **work** timeout under a2s **complete-call** budget, show the nested
inspector failure, and do not call it proven SIP/permission failure. Existing
JSON already retains that evidence, so no runtime edit is needed for accuracy.

## Investigation boundary and lesson

The investigate skill's evidence-first method was applied using retained
artifacts and source. Its reproduction/implementation steps were deliberately
not run because root limited this task to read-only diagnosis with no retry.
Status: diagnosis complete with the underlying vmmap wait cause unresolved;
no fix or fresh successful reproduction is claimed.

Lesson: a canceled diagnostic's nonzero exit and termination text are not the
original cause. Distinguish the collector's work deadline, its cleanup reserve,
and the process's own output before changing timing or weakening evidence.
