# Legacy preview browser harness: implementation review packet

2026-09-08. **Frozen for independent engineering review; NOT RUN in a browser.**
Approved scope: `2026-09-08-legacy-preview-browser-acceptance-plan.md`, including
root's fixed unavailable genome-catalog amendment. No existing runtime, test,
scientific source, operational store or Atlas harness was edited in this packet.
The independent reviewer, not this maker, must grade the code and later images.

## Frozen identity

| Artifact | Lines | SHA-256 |
| --- | ---: | --- |
| tools/check_legacy_preview_browser.py | 309 | 96a59c51711d3427ad57c7da77ecea0cebb7e3ce3663a4e59ad752dc586eca85 |
| tools/check_legacy_preview_browser.cjs | 237 | 0f59dedbcfc3c1dcfc4906fae1151a3dde513e6b26e063376b62556b71075825 |
| livemorebio/tests/test_legacy_preview_browser_harness.py | 237 | 2d717f595b76f0f0c99faf00448d18310ebfb3192b2652b8a020b55d50f21281 |
| approved browser plan | — | 3e457b8ee915065edbc39693154b69558c77ba989866cb26ac892ff9656e794c |
| unchanged ownership/listener helper | — | 77982780e71188b633ade499e0f7d744e823a8f6a14a84de79ebad03e722ea76 |
| unchanged review environment helper | — | 468d87df4bf50f7e5ca5ea2193377f34849f1c4ba71aed0b2fcdee8642213f84 |

Read-only package fingerprint after the separately reviewed SDK audit correction:
`d0311baf6fd4cd8cc6754685471cc11bd8712c53b30afc952fb9295e31c5aac4`.
This is a prospective launch pin, not evidence of any running service.
SDK privacy-increment SHA is `022e850ee3c85e35cd64be4bf27910d84a777e35a068c949511a20658feee0b8`;
the original client report retains its historical prior pin and 632-case receipt.

The fixed serialized fixture bundle (A/B/C state literals, note, unavailable genome
catalog and four UUIDs), in the CJS `fixture_sha256` field's exact order, hashes to
`05b3fac47c16391d1d210865aca3f60e262ea54b3d5408ee4f6a88c17fc0acf3`.
One guarded pure Node hash read independently produced this string in private
`livemore-research-review-5d9s9vco` (1 Node / 0 unexpected I/O / 0 Git). No model
or physiology computation was involved. Numbers remain the prior authored unit
fixture literals and are prominently labeled **AUTHORED UI ONLY**.

## RED and offline evidence

All private roots below use the existing review environment under:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/`.

| Checkpoint | Result | Private root suffix |
| --- | --- | --- |
| Tests before either implementation module existed | 26 FAILED, 1.88s | livemore-research-review-l15q478y |
| Initial helper implementation | 26 PASSED, 1.32s | livemore-research-review-tvwixiz_ |
| Actual default Twins query / mobile ACTUAL baseline / completion auth additions | 3 FAILED, 27 PASSED, 1.67s | livemore-research-review-9dp1rsdt |
| Corrected exact query10 and second-context read admission | 30 PASSED, 1.73s | livemore-research-review-dn69_4tv |
| Missing auth-count rejection strengthened | 1 FAILED, 30 PASSED, 1.74s | livemore-research-review-1txs5rje |
| Corrected auth-count check + explicit async-test completion | 31 PASSED, 1.78s | livemore-research-review-14k2_x13 |
| Final frozen code repeat | **31 PASSED, 2.00s** | **livemore-research-review-kla9l9mr** |

Final repeat: **20 authored Node calls; 0 unexpected I/O; 0 Git calls; exit 0**.
Each Node process is the existing test helper's fixed 15-second eval, with explicit
network and subprocess refusal prepended. Async probes require a completion marker;
an unresolved Promise cannot create a false green. Python socket/DNS/urllib,
ctypes loading, subprocess and fork/exec paths are refused. No Playwright import,
service initialization, authored-registry creation, HTTP, browser, solver or native
model operation ran in these tests. Source-only fixture/setup checks are not
actual startup or visible-UI acceptance. Scoped `git diff --check` passed.

## Exact finite request graph

All browser page routes use only `http://127.0.0.1:8910`; no installed8850 fallback.
Supervisor / browser metadata health checks target only fixed8910–8912.
Only normal `GET /api/session/bootstrap` establishes the actual HttpOnly cookie.
Neither its response nor auth.js is fulfilled or modified by the adapter.

- Documents: `/legacy`, `/twins`, `/patch`, `/cendos`; `/favicon.ico`.
- Actual bounded reads: `/api/build`, `/api/services`, `/api/vocab`,
  `/api/evidence`, `/api/population-capabilities`, `/api/executions/capabilities`,
  `/api/patch`, `/api/cohorts?limit=50`,
  `/api/cendos/protocols/history?limit=10`.
- Actual first modeless state read in **each context**, followed only by scheduled
  `/api/state` responses; minimal `/api/biology` fixture for READY rendering.
- Only during D4: `/api/twins?limit=10` gives the fixed UNCONFIRMED listing;
  `/api/genome-models` gives the explicitly unavailable dependency fixture.
  The latter never reaches `stoichiometry.runtime_capabilities()` / GLPK.
- Exactly four intercepted POSTs: Healthy base, carrier, Note lost ACK, Note503.
  Exact path and serialized body family are checked before counting or fulfilling.
  No actual service mutation, repeat, reconciliation or execution request is sent.
- Known Google Fonts CSS2 requests are denied and reported as font fallback.
  Any other URL, query, method, graphics asset or dynamic source acquisition fails.

Static closure, all under `/lib/`:
`design.css, auth.js, shell.js, core.js, build_identity.js, evidence.js,
provenance.js, legacy_preview_recovery.js, selection_reconciliation.js,
strict_json.js, biological_projection.js, subjects.css, subjects.js,
population_forms.js, reference_cohorts.js, continuous_execution.css,
continuous_execution.js, execution_view_state.js, execution_anatomy.js,
execution_presentation.js, anatomy_loader.js, anatomy_view_state.js`.
The offline test derives the actual static import closure from the four documents.
The imported anatomy loader is dormant without an execution; no vendor, geometry,
Atlas, WebGL capability probe or 3D mount is admitted.

## Actual initialization and path inventory for later review

`prepare_review_environment` receives only PATH/HOME/TMPDIR/LANG/LC_ALL and
fresh8910 endpoints. Fresh private data include subject/bootstrap/audit SQLite,
execution and virtual-execution SQLite, bus snapshots/events and registry,
population/reference/model caches, protocol runs/index, research/evidence stores,
evidence export/signing keys, Patch journal/companions, screen/resolve caches and
Cendos DB. All helper-defined store variables point inside the new child directory.
No retained Atlas/anatomy override is used. Browser HOME/TMPDIR are new0700 children;
no persistent Chrome profile is supplied.

The authored fixture uses actual `human_payload(condition="")`, create and
observation-only selection before services. It must produce ACTIVE/unbound v2.
This launcher code has not been executed yet. It does not create a numerical
candidate or invoke the legacy clinical compiler.

Each fixed service child imports and traps the declared Myokit Simulation/importer,
SciPy integrators, MetabolicProfile, GlucoseInsulinModel, CardiacCell, AegleTwin and
both execution adapters **before importing its app**. Import-time existing reference
constant declarations are not presented as numerical solves. An Aegle startup
observer then checks actual tw=None, initialized and MODEL_BINDING_REQUIRED.
No routes/auth handlers are replaced. Constructor failures and forbidden outbound
I/O create only one fixed private fault receipt and cause the supervisor to fail.
The fixed optional Git lookup may fail without becoming a numerical fault.

- Aegle startup: checked selected-record restoration, observation holder, audit
  and bus publication only. No absent-selection healthy fallback is allowed.
- LIFE import: ordinary router/shutdown registration; health loads packaged
  KnowledgeBase JSON seed files, no population generation or external source read.
- Cendos import: ordinary routes/reference constants only; no startup assay.
- LIFE page: actual Patch observation read and modeless capabilities may initialize
  an empty encrypted execution store/manager and audit metadata; no adapter/frame.
- Cendos History: empty actual protocol-run index and evidence inspection stores;
  no experiment is seeded. Cohort reads use the existing registry audit. Population
  capabilities describe configured metadata and cache status; no source install.
- The only discovered automatic native dependency query, genome readiness, is
  intercepted with the separately approved unavailable fixture; no GLPK query.

## Run boundaries and limitations

The exact approved four deliveries and12 image names are in the CJS constant.
The single pending read has its original2s deadline, including screenshot work;
late release fails. Navigation uses real anchors, keyboard and browser Back.
The bfcache flag is observed, not forced. The browser does not replace fetch,
native promises, handlers, DOM/CSS or state. Screenshots are ordinary viewports;
no renderer injection. Only metadata and authored screenshots are saved.

The180s browser deadline,10s actions,256 requests and64MiB evidence ceiling are
unchanged.75s is reserved from the350s supervisor budget for exact-child cleanup
and proof. Every page/context/browser close gets an independent3s receipt;
response observers are bounded/drained before a completion verdict. Every Python
child gets10s TERM/5s KILL and exact-handle reap; inherited listener3/2/2 and
PID/start descendant verification remain mandatory. Unknown cleanup never passes.
Signals stop new work and allow bounded cleanup; original failures are preserved.
No raw service/browser logs or request/response bodies are retained.

The31 offline cases do **not** prove Chromium rendering, auth cookie policy,
service startup, source identity across actual navigation, screenshots or cleanup
against real processes. These remain the next **separately authorized once-only**
run after root and independent source review. No run command is authorized here.

Lesson retained: a real-browser recovery demonstration must use the real default
navigation requests and real auth in each context, while explicitly labeling its
intercepted delivery boundary. Unit fixture success is not proof of those browser
boundaries or any of the six required scientific programs.

## Exact guarded offline repeat

Run from the full-scope-recovery worktree with:
`/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B -`, supplying this stdin:

```python
import os,socket,subprocess,sys,urllib.request,ctypes
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1
  permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=short','livemorebio/tests/test_legacy_preview_browser_harness.py'])
print('Refusal counts:',counts,flush=True)
raise SystemExit(status)
```

## Independent pre-execution review — not cleared

Root read the full plan, frozen three files, this196-line maker report and the
actual bootstrap/navigation/history consumers. release_redteam independently
read the same packet. Neither reviewer launched a browser or service. The31
offline passes above do not cover these actual mounted-runner gaps:

1. **P1: timeout ownership.** Racing `work()` does not cancel its pending resource
   allocation or continuation. A late context/page can be appended after cleanup
   has passed. Add a fixed stopped owner, check before each further action,
   bounded allocation settlement and individual cleanup of late resources. The
   10s bound must include allocation, evaluate, cookie and body reads—not just
   Playwright locator defaults. A stopped sequence must issue no later click/POST.
2. **P2: bootstrap contract.** The unchanged producer returns204, while the
   response observer requires200. Admit the exact204 producer response; do not
   alter production authentication to fit the harness.
3. **P2: delivery counts.** Require exactly one follow-up state GET per preview
   submission and exactly one D4 unavailable genome catalog fixture. The current
   fallback allows duplicate reads. Distinguish ordinary navigation/periodic reads
   from the four fixed preview-followup slots; do not block genuine Cendos polling
   or alter production timers to manufacture counts.
4. **P2: parent receipt.** An exit0 is insufficient. Before success, the Python
   supervisor must safely admit the bounded original browser receipt, fixed case
   matrix, source/pins, four intercepted/zero actual mutations,12 exact images
   with matching bytes/digests and per-resource cleanup. Reject missing/corrupt
   evidence and retain original nonzero failure separately. Recheck frozen helper/
   harness identity before acceptance; do not silently trust changed code.
5. **P2: failure accounting.** Freeze all seven scheduled cases as NOT_RUN before
   work; record current case and FAIL separately from completed PASS cases. On
   stop, remaining cases stay explicitly NOT_RUN. Never synthesize missing images.

Root authorizes one bounded correction to these three new harness/test files,
with red-first mounted tests of the actual observer/schedule/work-owner/parent
receipt paths. Keep the fixed two viewports/four deliveries/12-image matrix and
all resource budgets unchanged. No new framework, product edit, numerical model,
service/browser/Atlas/skin execution or automatic rerun is authorized. Retain
the frozen original hashes and all REDs above. Freeze the corrected packet for
independent review and root's offline repeat before any launch decision.

## Five-correction candidate — frozen for independent review

The original three-file hashes and 31-case result above remain historical evidence,
not an accepted browser run. Only the same three harness/test files changed.
No product, source input, client, service, registry, scientific or borrowed helper
file was edited. No actual browser, service, native model or network call ran.

### Retained RED and offline results

All commands used the exact guarded stdin above; early correction repeats used
`--tb=line` instead of `--tb=short` solely to limit failure output. Private roots
are under `/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/`.

| Stage | Private root suffix | Result | Time | Node / unexpected I/O / refused Git |
|---|---|---|---|---|
| Mounted runner/route + parent original-evidence RED | `livemore-research-review-prm6ziui` | 24 failed, original 31 passed | 2.85 s | 29 / 0 / 0 |
| First five corrections | `livemore-research-review-8ozesmfx` | 55 passed | 2.98 s | 29 / 0 / 0 |
| Actual parent-main branches + late launch | `livemore-research-review-g42qjg27` | 61 passed | 3.17 s | 30 / 0 / 1 |
| Final runtime-pin drift RED | `livemore-research-review-rb2eeeh0` | 1 failed, 61 passed | 3.16 s | 30 / 0 / 1 |
| Every retained runtime pin rechecked | `livemore-research-review-atxc6cit` | 62 passed | 3.46 s | 30 / 0 / 1 |
| Final D4 outcome/unsettled-allocation preservation | `livemore-research-review-9t4rr3dk` | **65 passed** | **3.65 s** | **33 / 0 / 1** |

The mounted Node tests call the real `run`, response observer and route handler
with authored in-memory Playwright substitutes, bounded accelerated timers and
filesystem output substitutes. They do not test real Chrome or actual DOM pixels.
The parent tests call the real `main` with four inert handles and authored private
receipts/images. No process or HTTP implementation is reached. The original 31
assertion intents remain; the old positive completion fixture now supplies the
new mandatory case/count fields instead of weakening their validation.

### Exact correction behavior

- A fixed stopped flag gates every further browser action before invocation and
  after settlement. Allocation promises are tracked before awaiting; late returned
  browser/context/page resources are individually closed rather than starting the
  next action. Work/allocation drain is bounded at 3 s. An unresolved allocation
  records `UNCONFIRMED`; this is not a claim that a promise or OS process was
  cancelled. The parent still owns exact-process cleanup. The existing 180 s
  browser allowance reserves 21 s for drain/independent closes/observer settlement,
  leaving 159 s for the fixed work. Individual action 10 s, held GET 2 s (including
  its screenshot), each close 3 s and all other parent bounds remain unchanged.
- Bootstrap requires the actual producer's exact **204**. A synthetic 200 now
  fails D0 before its screenshot or any preview submission.
- Each of the four preview POSTs creates one consumable follow-up GET slot.
  Duplicate legacy follow-up reads fail; explicit Refresh/back reads have separate
  one-use slots. Normal non-legacy page state polling remains actual and separately
  tagged `ACTUAL_PAGE_READ`. Exactly one D4 genome catalog fixture is allowed.
- The parent admits the bounded original strict-JSON receipt and fixed seven-case
  success ledger; source/service/runtime/fixture identities; exact four intercepted
  and zero actual mutations; follow-up/genome counts; both cookie/auth observations;
  all five named successful resource closes; and all twelve safely opened original
  image bytes, lengths, hashes and viewport PNG headers. This checks byte/header
  evidence, not rendered visual quality. Missing, linked, malformed or inconsistent
  evidence fails even on Node exit 0. A nonzero Node result retains its original
  observed exit code and fixed failure. All seven original pin paths are rehashed
  before acceptance, followed by original service/source identity checks.
- D0/D1/D2/D3/D4/M1/M2 begin `NOT_RUN`, advance individually to `PASS`, and the
  current failed case becomes `FAIL` with a fixed failure code. Later cases remain
  `NOT_RUN`. D4 stays current through desktop health and resource cleanup, so a
  failure there cannot falsely label unstarted M1. Final cleanup/evidence failures
  remain separate stages. No missing image is synthesized.

| Frozen corrected file | SHA-256 |
|---|---|
| `tools/check_legacy_preview_browser.py` | `51965380a7bf9cee714bbabda8eb8fab79ae828f39757bfd12ea90cc4a982c48` |
| `tools/check_legacy_preview_browser.cjs` | `b80c2bd5a7be145d3def489830152313a7d65f66efbe536ed1c1eff658c9c71d` |
| `livemorebio/tests/test_legacy_preview_browser_harness.py` | `7eaa22b7784b1c79db389c9357e584a06df0acbf248378749b3c1c07257c5242` |

The plan and two borrowed helper hashes still match their preceding records.
The exact offline repeat is unchanged. This is a maker candidate, **not** an
independent clearance or launch authorization. Root and maker-external review
must grade it before any once-only browser decision. Actual twelve-image rendered
acceptance and real OS cleanup remain unexecuted.

Lesson: an exit code is not an evidence receipt, and a raced timeout is not
cancellation. Fixed ownership and explicit incomplete outcomes must survive both
late allocation and the original failure without manufacturing success.

## Root independent clearance and once-only browser decision

Root read the frozen395-line Python supervisor,271-line CJS runner and419-line
test file, checked all three hashes above and both borrowed helper hashes, and
reviewed the five corrections against the prior independent findings. No maker
test result was substituted for the root repeat. Root's guarded repeat used the
same stdin above, with pytest plugin auto-loading disabled and a45s outer alarm:
**65 passed in3.72s**, Node33, unexpected I/O0, refused Git1; exit0/session10760,
private `livemore-research-review-69mw_nfq`. This clears the narrow offline harness
contracts, not rendered UI or scientific behavior.

The unchanged product source rehash is
`d0311baf6fd4cd8cc6754685471cc11bd8712c53b30afc952fb9295e31c5aac4`.
Root now reserves8910–8912 and authorizes **one** run of the frozen supervisor
with that exact `--expected-source`. The supervisor must stop if ports are not
free. Use its new private stores, ordinary auth, fixed12-image/four-interception
schedule, constructor/solver tripwires and original bounded cleanup. No installed
service/store, source edit, Atlas/skin rerun, model execution or experiment is
authorized by this decision. Stop on first failure; no automatic rerun or live
allowlist expansion. Root must read the original receipts and inspect every image
actually produced before any visible-UI verdict. Missing images remain missing.

## Once-only actual launch — FAILED before browser

The frozen command ran once (session48893, exit1). Original private evidence:
`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-legacy-preview-kju2ft7s`.
The original supervision receipt reports `SERVICE_OR_TRIPWIRE_FAILED` at2.4832s.
Three service guard-installation receipts exist; no tripwire fault receipt exists.
No browser config, browser process, browser result or screenshot was produced.
Therefore all seven browser cases remain **NOT_RUN**, visible acceptance is not
established, and the cause is not narrowed beyond an exited service at this point.
No raw stderr was retained by this deliberately silent launcher. Do not infer a
specific import/initialization failure from the generic status.

All three exact service children were terminated/reaped with SETTLED receipts;
listener query reports NO_LISTENERS/SETTLED and no tracked descendants remain.
Primary failure is preserved separately from null cleanup/evidence failures.
No installed service, operational registry, scientific model or source file was
changed. Static startup inspection is the next step; no automatic second launch,
browser rerun or restriction bypass is authorized by this failed attempt.
