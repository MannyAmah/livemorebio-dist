# Private molecular adapter: first actual browser increment

Proposal only,2026-09-09. No page/server/browser has been launched or product
file changed. Root requested a small private loopback check after the actual
IviiqA A/B pair passed its separate output gate. This uses the real built Molstar,
current inspector/loader and original public coordinates, not a new renderer.
It is not the final ordinary/frozen-run/fixed-execution acceptance matrix.

## Exact reuse and private file ownership

Prepare only a fresh0700 private directory containing a small `check.py`,
`check.cjs`, `page.js`, `page.html`, frozen input manifest and inert tests.
No new permanent scenario in the accepted legacy browser harness. Its default
16-image and physical4-image scenarios remain byte-unchanged.

The Node script imports only existing `bounded`/`closeOwned` from the pinned,
import-safe `tools/check_legacy_preview_browser.cjs`. Python imports only the
stdlib-only `process_snapshot`, `descendant_identities`, `remaining_descendants`
and bounded listener-inspection helpers from `tools/check_atlas_presentation.py`;
do not call its app/registry preparation, old build owner or model paths.
Use the existing exact-child stop/wait pattern with provenance snapshots; no
PID-only or unowned-Chrome termination. No npm/build/install operation.

At preparation freeze, pin these helpers, Python/Node, installed gstack Playwright,
Chrome, the actual current three inspector files, full catalog, all six CIFs,
and IviiqA's JS/CSS/sidecar bytes. Do not copy any operational registry, private
session, patient state or auth token. The page contains only public reference
metadata plus the literal heading “Technical adapter check, not a participant,
not a scientific experiment.” No application services or startup constructors.

Use `/Users/emman/.agents/skills/gstack/node_modules/playwright/index.js`, headed
installed Chrome and the already reviewed Atlas launch flags
`--use-angle=swiftshader --enable-unsafe-swiftshader`, isolated context/profile.
This is the existing /browse Playwright ecosystem, not a shared browser or driver
change. Record it as software graphics, not physical-GPU performance evidence.

## Ordinary unmodified execution on a private fixture page

Serve the current original `molecular_inspector.js`, `molecular_loader.js` and
`molecular_inspector.css` bytes at their normal relative paths. Serve exact
IviiqA A `structure.js`/CSS at `/lib/vendor/molstar-4.4.0/`; the inspector's
default dynamic import works unchanged. The private page imports the actual
mount function and calls only its public open/close/setContext/dispose methods.
No module wrappers, prototype mutations, global plugin hook or fake canvas.
Do not replace React/Molstar. READY comes from the real parser/model/row-count
checks already in the current controller.

A small exact-path static handler in the same owned Node child binds only
127.0.0.1:8910, after the existing bounded LISTEN check. It maps literal paths
to frozen in-memory original bytes, with no directory listing, traversal,
generic file server, redirect, proxy or upstream fetch. Every expected response
has exact Content-Type/Length, no-store and nosniff. Reject other Host/origin,
methods, queries, paths and request bodies; all POST attempts are failures.
Browser context routing independently permits only the same finite GET list.
No APIRequestContext, external endpoint or repeated download is needed.

The private `/api/structure?gene=<fixed key>` response follows the actual
lookup projection from the frozen catalog. Coordinates use the descriptor's
exact64-hex path and original bytes. Both responses carry the same literal
source SHA and fresh UUID, explicitly recorded as **technical fixture headers**,
not a real Aegle build/process/auth claim. Metadata and actual byte hashes remain
bound by the unchanged loader. Only this private handler bypasses application
auth/audit; no real route is used and no API/auth integration is accepted here.

CSP: default-src 'none'; script-src 'self'; connect-src 'self'; style-src 'self'
'unsafe-inline' (Molstar/React inline styles); img-src 'self' data:; font-src
'self'; worker-src 'none'; object-src 'none'; base-uri 'none'; frame-ancestors
'none'. No unsafe-eval, remote source, worker, font or codec exception. No inline
script; use page.js. Preserve CSP violations, page errors and failed requests as
separate fixed evidence. A rendered canvas does not waive delivery/CSP failures.

## Six public sources, without turning pig insulin into human INS

Use the real admitted target projections for KRAS4OBE, TP531TUP, EGFR1M17,
LDLR1N7D and PXR6P2B. Preserve all source constructs/species/model1/index0 and
atom-site counts. No expanded assembly, coordinate changes or biological motion.

Root explicitly approved this private-only sixth control:
“4INS · pig insulin · deposited reference only”. It requests literal PDB_4INS
metadata containing the exact unchanged related4INS descriptor and original
bytes. This is an explicit PDB-only technical fixture, not an admitted gene
mapping. Separately the real INS projection remains MAPPING_UNAVAILABLE with
4INS merely related; that action must request no coordinate or substitute.
Both facts must be readable in screenshots and receipt. No product catalog edit.

## Finite first run: four stages, eleven originals

1. Desktop1440×1000, initial KRAS4OBE: click the ordinary page trigger, require
   READY, exact source provenance, visible nonzero canvas and native control
   hitboxes. Capture `desktop-4obe`. Record actual load duration without adopting
   an Atlas performance threshold or interpreting startup as physiological work.
2. Same real viewer: open Mouse/Key Help (capture `desktop-help`), select via
   real sequence/canvas controls, focus, rotate/zoom/reset, and add then delete
   one distance measurement using upstream UI (capture `desktop-distance`).
   Require visible nonempty source selection and finite Å display, not an
   invented expected molecular quantity. No hidden direct plugin calls. Exact
   roles/selectors are taken from the retained source and inspected DOM; an
   unavailable/ambiguous control fails rather than silently bypassing the UI.
3. Close/reopen the other five explicit sources, capturing `desktop-1tup`,
   `desktop-1m17`, `desktop-1n7d`, `desktop-6p2b`, `desktop-4ins-pig`. Each must
   reach READY with exact descriptor and then close with hidden dialog, no
   attached plugin/canvas and returned trigger focus. This supplies at least
   five real open/close cycles, not a GPU-memory-leak certification. Then actual
   INS unavailable, capture `desktop-ins-unavailable`, assert no coordinate GET.
4. New390×844 context: KRAS4OBE READY, capture `mobile-4obe`; scroll the actual
   dialog to source metadata, capture `mobile-provenance`. Inspect close/focus/
   Tab/Escape and readable source copy, no horizontal clipping. Measure actual
   upstream button/control hitboxes; the current broad inspector button rule
   applies to Molstar too. Preserve any resulting geometry defect, no CSS patch.

These are11 PNGs, not a composite or regenerated image. Screenshots are ordinary
browser views of unmodified product modules on the explicitly private fixture.
Every stage/capture has PASS/FAIL/NOT_RUN, and failures preserve the active stage,
partial metadata and one failure image. Root independently inspects originals.
Angle/dihedral, fault/context-loss/retry,200% zoom and all three real consumers
remain required in the subsequent full matrix, not accepted by this first slice.

## Fixed bounds and cleanup

One invocation only. Python ceiling240s: preflight at most15s, exact owned Node
at most200s, reserved cleanup15s and receipt10s. Node starts its monotonic budget
before any async allocation:180s acquisition/work plus15s cleanup. Action10s;
the unchanged inspector's operation limit30s remains. Maximum128 GETs,32MiB
served response bytes,64MiB evidence, original source limits unchanged. No retry
of failed cases, browser launch, GET or full run without a separate root decision.

Every allocation retains its exact owner even if the budget wins; late resources
close under the same bounded cleanup policy. Reuse closeOwned for page, context,
browser (3s each), then close the exact static server with a3s cap. Python tracks
only proven Node descendants while its exact child lives, then verifies exact
identities absent and listener state, retaining CLEANUP_UNCONFIRMED on survivors
or unknown ownership. Do not claim a socket bind/TIME_WAIT as LISTEN evidence.
Retain safe stage/error enums, source/path IDs, counts and geometry only; no raw
exception stacks, environment, arbitrary request URL or patient/global state.

## RED-first implementation and gate

Before implementing the small entry/runner, add inert checks for the exact
static/GET map and CSP; wrong method/path/query/Host/body; original file/hash
changes; metadata/source identity; pig fixture versus real INS unavailable;
six source ordering and11-capture/NOT_RUN accounting; action/total deadlines;
late allocation and each cleanup failure. Exercise actual proposed runner
functions with deferred authored boundaries, not source-string-only assertions.
Reuse existing helper tests and do not reimplement their process framework.

Freeze source, tests, exact runtime command and private input hashes for root
review before any actual listener/browser launch. NOTICE assembly can proceed
separately, but this private public-structure graphics check neither
redistributes the bundle nor clears its retained CAS/fastapprox source limits.

After this increment: actual protected API/auth/audit, installed vendor/wheel,
ordinary Biology, immutable saved run and fixed execution bindings, remaining
control/failure/responsive cases all remain mandatory. No molecular dynamics or
six-program scientific outcome is inferred from static reference rendering.

## Root pre-code decision — 2026-09-09

Root read the complete 154-line proposal at SHA256
`c69039bc692a2ce2145b86f7ea28673a59e51386ef3e24bbf0d694de8cfc41f1`.
Approve this finite private implementation and its inert RED/GREEN tests.
Do not launch the listener or browser until root separately reviews the frozen
implementation, test evidence, input manifest and exact invocation. The pig-only
4INS fixture must remain visibly separate from the unavailable human INS mapping.
This approval changes no product release, rights, physiology or API acceptance gate.
