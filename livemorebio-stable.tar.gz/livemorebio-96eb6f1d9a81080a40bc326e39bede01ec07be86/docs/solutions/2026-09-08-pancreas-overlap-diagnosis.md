# Selected pancreas: retained source-overlap diagnosis

Date: 2026-09-08. Independent, read-only diagnosis under section C of
[the remaining Atlas proposal](2026-09-08-atlas-remaining-dependency-visual-proposal.md).
**Source overlap confirmed; same-camera GPU comparison NOT RUN.** This does not
change the FAILED Atlas acceptance or authorize a presentation implementation.

## Symptom and bounded investigation

Root requested diagnosis of the alternating teal/beige triangles in selected
`FJ1895`, not repair or deletion of reference geometry. The reviewer personally
opened `selected-pancreas.png` from
`docs/screenshots/full-scope-recovery/atlas/attempt-2-FRpGPo/browser/ordinary/`.
The screenshot explicitly names Pancreas / FJ1895 / FMA7198 and shows that mosaic.
The complete [retained attempt-2 report](2026-09-08-atlas-browser-attempt-2-results.md)
was read. Its 28 functional PASS, 3 FAIL and 25 NOT_RUN cases remain unchanged.
Passing selection assertions do not establish visual usability.

The investigation skill's source-tracing and hypothesis-verification phases were
used. No fix was applied. No browser, service, download, extraction to disk,
converter, physiological model, clinical store or experimental execution was
performed. Only existing public-reference archive members, admitted GLB/manifest/
receipts, source maps and runtime source were read. Gbrain, Context7 and CE tools
were unavailable; the local prior reports provide the source and decision history.

## Exact retained inputs

The cache root used was:

```text
/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-1q65uy9g/anatomy/atlas
```

Paths below are relative to that root. Hashes were recomputed in this pass.

| Path / input | Bytes | SHA-256 |
|---|---:|---|
| `sources/40665852c49f218326590e204db91064a1ecfc3c6f8cbd7bbbcaac62c7cd409e.zip` | 142,903,898 | `40665852c49f218326590e204db91064a1ecfc3c6f8cbd7bbbcaac62c7cd409e` |
| `sources/a3de74423f943b0d724ae8f59b3a817f87c423a544f8db98113b1980817cbeaf.txt` | Pinned IS-A map | `a3de74423f943b0d724ae8f59b3a817f87c423a544f8db98113b1980817cbeaf` |
| `sources/3f5f6df1028eb122b30de77c711597b6bb8e5541658e5985859fd228adbf88ea.txt` | 651,179 | `3f5f6df1028eb122b30de77c711597b6bb8e5541658e5985859fd228adbf88ea` |
| `artifacts/8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a/manifest.json` | 475,337 | `8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a` |
| Same artifact directory, `pancreas.glb` | 517,084 | `1b89be32e9725a48140bb6f754c3ac4a6852a98067bf4491a28fe8988f56e908` |

`active.json` and `receipts/<manifest hash>.json` were read and agree on source
`bp3d-4.0-20130619-surface-core-v1`, manifest above and installation receipt
`083b2f038e74476ebfcef07e4a22f7c2`. The original receipt retains
`2026-09-08T14:41:30.445957+00:00` to `2026-09-08T14:45:11.080420+00:00`.
No new receipt or installation was created. Their raw byte hashes were not newly
printed by this pass, so none is invented here.

The separate previously retained source directory
`/tmp/livemore-bp3d-review.vqpHeK` supplied the following authenticated hierarchy
files, with hashes recomputed in this pass:

- `isa_parts_list_e.txt`: `ab7796deedd49205e77f3609a1cb8c53e2bbee14ecb5c9a6ca05227469780513`.
- `isa_inclusion_relation_list.txt`: `26e7d818e03a8c909fe09c561f38d0d513423c87681f9450a803bc38f5b07564`.

## Membership, hierarchy and array preservation

Archive paths are exactly `isa_BP3D_4.0_obj_99/<element ID>.obj`.

| Element | Concept / representation / source name | Vertices | Triangles | OBJ bytes | Source SHA-256 |
|---|---|---:|---:|---:|---|
| FJ1895 | FMA7198 / BP4631 / Pancreas | 2,462 | 4,890 | 307,895 | `ed9111890b410aebacb86ae06ce2f7e3010bac8a2db3f9b292b53359bbf18026` |
| FJ1896 | FMA10419 / BP5645 / Pancreatic duct | 3,941 | 3,368 | 344,665 | `aaf43697017cb6a8df51f1c95b4a10917fa165178fbd4e32dce946332d2cbc03` |
| FJ2629 | FMA63120 / BP9199 / Parenchyma of pancreas | 2,153 | 4,272 | 267,563 | `bd34649f3c15c34fe2fe845a6c6e926de2c014557360df48922f7266dba113e6` |
| FJ2630 | FMA63103 / BP8172 / Pancreatic duct tree | 4,340 | 4,432 | 405,261 | `77e2f5c9bf24cfe0c74b354d1fe0ee559d2fc130e7fb62b1b32951298be5a3b5` |

All source-byte hashes matched the immutable manifest. Every POSITION value for
all four elements exactly equals the source decimal coordinates cast to float32,
then promoted back to float64 for analysis. Every triangle index matches the
original OBJ vertex index and order. This covers all 12,896 positions and 16,962
triangles, not a sample. NORMAL arrays were **not newly compared** in this overlap
pass; the earlier independently accepted all-489 artifact check, recorded in
[install acceptance](2026-09-08-atlas-publisher-install-acceptance.md), includes
normal preservation. Do not conflate the two scopes.

The retained PART-OF map contains exactly all four IDs under FMA7198. FMA63103
contains FJ1896 and FJ2630; FMA10419 contains FJ1896; FMA63120 contains FJ2629.
IS-A FMA7198 contains FJ1895 only. The retained IS-A hierarchy has:

```text
FMA55662 lobular organ -> FMA7198 pancreas
FMA30320 duct -> FMA10419 pancreatic duct
FMA45732 parenchyma -> FMA63120 parenchyma of pancreas
FMA14065 organ component -> FMA63103 pancreatic duct tree
```

These are source representation/membership facts, not proof that two meshes are
disjoint or a claim of direct anatomical parentage from a flattened membership
map. The GLB has one `bp3d-native` root and four sibling nodes, each with one exact
element ID/mesh and no child transform. FJ2629 is **not** a GLB child of FJ1895.
The shared root applies `(x,y,z) mm -> (0.001x,0.001z,-0.001y) m`; its glTF matrix is:

```text
[.001,0,0,0, 0,0,-.001,0, 0,.001,0,0, 0,0,0,1]
```

No duplicate instance of the same element ID or independently recentered organ
was found in this partition. Distinct source IDs carry overlapping geometry.

## Reproducible method and complete pair results

The executed analysis used only stdlib and NumPy, independently of the product
converter/validator. The fixed inputs bound the workload to four source members,
six unordered mesh pairs, and native plus float32 representations. It did not
construct an all-pairs vertex-distance tensor: nearest-vertex work used 32 chunks.
There was no adaptive solve, generated source, clinical parameter or network call.

1. Decode source `v` and triangular `f` rows without welding/reordering. Decode
   glTF accessors directly from the retained GLB binary using `struct`/NumPy.
2. Count exact shared position tuples and sorted three-coordinate triangle sets.
   These exact-set counts ignore winding; no proximity tolerance is substituted.
3. For each triangle in one mesh, select other-mesh candidates whose native AABBs
   overlap. Test each of its three edges against each candidate triangle, then
   reverse the directions. Count a pair once if any strict intersection exists.
4. Use the Moller-Trumbore segment equations with determinant cutoff `1e-10 mm^3`
   and dimensionless `1e-10` interior margins for barycentric coordinates and
   segment fraction. Exclude coplanarity, endpoints, shared edges and vertices.
   These are diagnostic counts, not certified exact-arithmetic topology or a new
   source-admission tolerance. Float32 and threshold effects remain explicit.

| Pair | AABB candidates, both representations | Exact shared positions | Exact shared triangle sets | Strict crossing pairs native / GLB | Crossing faces left,right native | Crossing faces left,right GLB |
|---|---:|---:|---:|---:|---|---|
| FJ1895 / FJ1896 | 299 | 0 | 0 | 45 / 45 | 4, 41 | 4, 41 |
| FJ1895 / FJ2629 | 51,891 | 334 | 93 | **6,619 / 6,623** | 2,787, 2,701 | 2,789, 2,705 |
| FJ1895 / FJ2630 | 561 | 0 | 0 | 50 / 50 | 14, 36 | 14, 36 |
| FJ1896 / FJ2629 | 405 | 0 | 0 | 46 / 46 | 42, 4 | 42, 4 |
| FJ1896 / FJ2630 | 9,440 | 0 | 0 | 526 / 526 | 282, 176 | 282, 176 |
| FJ2629 / FJ2630 | 787 | 0 | 0 | 49 / 49 | 13, 36 | 13, 36 |

Exact shared-position/triangle-set counts were unchanged between source and GLB.
Unique positions within the four native arrays respectively number 2,447; 1,686;
2,138; 2,218. Repeated source positions were preserved, not welded.

Nearest **vertex**, not point-to-surface/Hausdorff, distances from FJ1895 to FJ2629
have quantiles `[min,p25,p50,p75,p90,p95,max]` in mm:

```text
[0, .0008025000000012605, .010000000000218279, .0940340939919849,
 .9059036274251542, 1.602196247848733, 4.322072007729625]
```

Among 2,462 vertices, 651 are within .001 mm, 1,229 within .01 mm, and 1,858 within
.1 mm. FJ1896 to FJ2630 has 3,941 samples, quantiles
`[.07725438498878649,1.1522181911426277,2.0231177153095783,3.0913801707327946,4.045286369344014,4.801428270837765,8.936784005446253]`,
with counts 0 / 0 / 11 at those three cutoffs. These numbers describe the retained
meshes only; they are not anatomical accuracy or physiological measurements.

## Concrete crossing witness, independent point consistency

All indices here are zero-based. Native FJ1895 face **28**, edge **1** (vertex 1
to vertex 2 of that face), crosses the strict interior of native FJ2629 face
**22**:

```text
segment fraction: 0.8773377367813299
target barycentric weights: [0.7005978819604153, 0.1859090100272164,
                             0.1134931080123684]
signed endpoint-to-target-plane distances (mm):
  [-0.2509737727235472, +0.03508912210221196]
intersection (native mm):
  [-44.85439724875641, -124.47728712264885, 1017.8138668868392]
distance between segment and triangle point parameterizations:
  1.1457157353758233e-13 mm
```

Both segment and barycentric coordinates are well inside their domains, with
opposite-sign endpoint distances. This proves a genuine retained source-surface
crossing rather than only a shared AABB or a microscopic floating-point contact.

## Cause and what remains unproved

`atlas_reference_scene.js::apply` assigns only selected FJ1895 teal `0x168f85`;
unselected pancreas elements remain beige `0xc9a273`. Internal materials are
opaque, depth-writing and double-sided. All four source meshes remain enabled.
The selected and unselected surfaces both coincide exactly in places and cross
elsewhere. Opposing selection colors therefore expose the competing source
surfaces as a triangle mosaic. The mechanism is consistent with the retained PNG.
Calling this **only depth-buffer z-fighting** would omit the confirmed geometric
interpenetration; a depth offset is not an established solution.

No same-camera assembled-versus-isolated browser experiment was run here, and no
GPU pixel/depth-buffer attribution was obtained. No claim is made that all visible
pixels or shading differences come from one pair. The static source diagnosis
does not waive ordinary rendered acceptance or the other Atlas failures.

## Minimal source-preserving presentation proposal, not implementation

Keep group base fill colors in the assembled view. Indicate the selected exact
source element with a bounded screen-space selected-extent cue (for example,
projected-bound corner brackets and exact ID), explicitly an **extent**, not a
new anatomical contour. Retain the existing inspector and explicit single-element
isolation; isolated selected fill may remain teal. Do not automatically hide
other source elements merely because a selection changes.

This avoids making overlapping surfaces compete in contrasting selection colors
without deleting, welding, offsetting, recentering or rewriting source geometry.
The cue must not participate in raycasting or alter depth/clipping settings. Keep
all original mesh/resource identities and distinguish overlay resources if any
are added. A DOM/SVG screen-space cue can avoid new source geometry/GPU meshes.
Root must review the exact presentation contract before code; an actual contour
mask would require separately bounded render-target/disposal/performance design.

Required RED cases before that implementation:

1. Distinct intersecting/coincident source-ID fixtures: selection leaves every
   position, index, normal, transform and source hash unchanged; full-view material
   depth settings and per-group fills stay unchanged, with one exact-ID cue.
2. No automatic mesh hiding or ID deduplication; preserve the original 489 nodes
   in the full admitted assembly. Overlay nodes are never selectable anatomy.
3. Existing ray hit/selected ID and explicit isolate/return behavior remain exact;
   FJ1895 and FJ2629 never become aliases. Teal isolated fill does not leak on return.
4. Cue updates on camera, resize, layer, section and selection changes; correctly
   bound/clip projections behind or outside the camera. A hidden or fully clipped
   selected element must not claim current visible anatomy. Explain/reset an empty
   section separately from renderer failure.
5. Dispose/retry/context-loss/hidden-view paths remove or suspend cues and retain
   existing resource bounds, source fences and no-decorative-motion behavior.
6. Separately authorized ordinary screenshots at the **same retained camera**,
   assembled and isolated, confirm readable selected identity without the
   selection-induced teal/beige mosaic. Keep failed performance/NOT_RUN gates open.

## Retention and replay

Original arithmetic was executed through read-only shell/stdin commands and its
stdout is retained in the task tool transcript. No standalone raw JSON result was
written then. This document transcribes those actual outputs without inventing a
new receipt. [The fixed-input replay artifact](artifacts/pancreas_overlap_review.py)
packages the same calculations, with explicit pins and input bounds. It has not
been executed after persistence; syntax checking is not a fresh geometry result.

An authorized reviewer with the retained paths and NumPy environment can run:

```bash
cd /Users/emman/Livemore/.worktrees/full-scope-recovery
PYTHONDONTWRITEBYTECODE=1 /Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B docs/solutions/artifacts/pancreas_overlap_review.py
```

The script has no arguments, service/model imports, output-file writes, extraction,
downloads or fallback inputs. It fails if fixed input hashes differ. Do not point
it at clinical stores or regenerate the source cache to make replay possible.

Lesson: deduplicating element **identity** does not imply disjoint surface
geometry. Preserve both source semantics and geometry; design selection emphasis
so overlapping representations do not falsely suggest damaged or dynamic tissue.
