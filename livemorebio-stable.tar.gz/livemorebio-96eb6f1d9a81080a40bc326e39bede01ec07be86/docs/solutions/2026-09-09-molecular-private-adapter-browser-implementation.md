# Private molecular adapter browser packet

Maker freeze, 2026-09-09. Implementation and inert checks only. **No listener,
browser, actual coordinate request, application service, model, build or install
was run.** The actual once-only invocation below is pending independent root
review and a separate run authorization. This is not visual acceptance.

Approved scope: the complete private-adapter plan and root approval in
`2026-09-09-molecular-private-adapter-browser-plan.md`. The browse skill was read
in full. Context7 was unavailable; exact retained Molstar 4.4.0 primary source
was used for control names, selection bindings, sequence events and measurements.
No external documentation retrieval or dependency execution was needed.

## Frozen private files

Root: `/private/tmp/livemore-molecular-adapter-browser.WoWI5H` (private0700).
No permanent product or accepted legacy/physical harness file was changed.

| File | SHA256 |
|---|---|
| check.cjs | `8d820195693257d7b6c2e40c3b7c34ad70877db29b2ac6df599e3fc4bfe87bea` |
| check.py | `1dd4a2c22483f01c54ba45a53b9812d03f0c35bfe4b0dd80de9181903ac0a168` |
| page.html | `b00171ecdd53e2ec61b7b24cf35021ab7658e5c709da88b9ee6fc1c87b24e5f7` |
| page.js | `481baf087e9bb49b248e7a1c1ef7f9d1404b61c831b0c6fdf9985622253c58b2` |
| inputs.json | `7647b1c1b5ba431a9d7a194b24a835f6d80a75ba37de6a9c5837239d37760a9a` |
| test-check.cjs | `b47aef9e45421dc45edb32708b004a83d3baa7d0e91172623390ba5b662dc7aa` |
| test-check.py | `b60b0909f5bd9224ea157d7732356abca5f311ee5671d92f7a6a351b7a279993` |
| run-inert.py | `142f4c5700a07b90752aa0542c07f973236992af537cda404c738da2395f3493` |
| harness-pins.json | `bbda2f1d3c0f2bedd47028ef68097f6984323823182303243963105738401e02` |

`inputs.json` pins22 original files including all three current inspector files,
catalog/six CIFs, actual IviiqA A JS/CSS/sidecar, both reused ownership helpers,
Python/Node/Chrome and installed gstack Playwright entry/package metadata. The
manifest contains exact path, SHA256, bytes and mtime. All22 were independently
re-read by the maker's non-executing verifier after implementation and matched.
`harness-pins.json` separately pins the eight executable/test/input files above.

`prepare.py` was run once, offline, to build the immutable input inventory. It
reads files and computes hashes, not package imports. It is not invoked by the
actual check. No `run/` output directory exists yet. The exclusive creation of
that directory prevents accidental repeat of the same prepared packet.

## Concrete runner behavior

One Node child owns the exact loopback-only8910 static handler and private
headed Chrome context. Response bytes come from the frozen files in memory,
with exact source/coordinate headers. The literal fresh UUID and manifest hash
are explicitly **technical fixture headers**, never application auth/build proof.
No APIRequestContext, proxy or upstream network request is used. Browser routing
independently blocks non-allowlisted requests. Every POST fails without dispatch.

The actual unchanged inspector's default import loads the actual built ESM
adapter. No global plugin reference or injected fake rendering/coordinates.
The small page calls only its public mount/open interface; the actual controller
owns close, keyboard, context and pagehide teardown. The six deposited models
and INS unavailable distinction match the approved plan. Pig4INS retains the
unchanged construct text: “2Zn pig insulin crystal structure (Sus scrofa), not
human insulin.” Its explicit private target is PDB_4INS, never human INS.

Four ordered stages and11 original screenshots have explicit PASS/FAIL/NOT_RUN
rows. The active stage, active capture, exact metadata, selected-source counts,
control boxes and partial evidence precede assertions. One additional failure
PNG is attempted within1s, never substituted for planned screenshots. Raw errors
and arbitrary rejected URLs are not retained. Failed delivery/CSP/page errors
remain failure evidence even when rendering succeeds.

Selectors are grounded in retained actual upstream files under
`/private/tmp/livemore-molecular-offline-monitor.2Ds7TZ/node_modules/molstar/lib`:

- `mol-plugin-ui/sequence/sequence.js`: real `[data-seqid]` mouse events.
- `mol-plugin/behavior/dynamic/representation.js`: primary-click toggle with
  no modifiers in selection mode; no synthetic property assignment.
- `mol-plugin-ui/structure/selection.js` and `viewport/help.js`: Toggle Selection
  Mode, Show/hide help, Mouse & Key Controls and actual binding descriptions.
- `mol-plugin-ui/base.js`: Measurements is `.msp-transform-wrapper` with the
  exact `#measurements` header, not the unrelated ControlGroup wrapper.
- `mol-plugin-ui/structure/measurements.js`: actual Add/Distance action, two
  selection-history entries, focus buttons, finite Å label and Delete.

Camera receipt deliberately records inputs and visible Reset Zoom control, not
hidden camera state or biological motion. Actual screenshots and control layout
still require root inspection, especially the broad existing button CSS.

The shared180s work budget begins before async allocation, each ordinary action
has10s, real source loading retains the unchanged30s controller bound. Cleanup
retains late allocations; existing closeOwned supplies3s per exact resource,
with15s aggregate including failure capture. Python uses the existing exact
child/descendant observation helpers and strict LISTEN result, not bind/TIME_WAIT.
Its phases are15s preflight,200s Node,15s cleanup,10s evidence,240s total.
No PID-only or unrelated process termination. Unconfirmed cleanup fails.
Response count≤128, response bytes≤32MiB, total evidence≤64MiB. Planned images
reserve8MiB for a failure image inside the total limit.

## RED and GREEN receipts

1. Initial Node RED:28 failed,0 passed,135.401ms. New harness absent; these are
   missing implementation/API failures, not observed product regressions.
2. First35-case expansion:32 passed,3 failed,158.984ms. The missing measured
   panel helper and original failure-image retention were then implemented.
3. Initial Python RED:5 setup/API errors,0 passed,0.008s, absent supervisor.
4. Listener-result regression:5 passed,1 error,0.023s. Actual existing parser
   returns `owned_listeners_absent`/`inspection_code`/`query_cleanup`, not an
   invented top-level `state`. Admission now consumes that exact contract.
5. Combined-wrapper initial setup error is retained: Node35 passed but Python
   replaced socket before ssl declared its subclass. This was a test-wrapper
   initialization defect, not product RED. Importing stdlib ssl/mock before the
   transport refusal corrected it without allowing network.
6. Final exact bounded combined invocation: **35 Node +6 Python =41 PASS**,
   Node148.255ms, Python0.022s, outer execution0.233s, exit0.

The Node cases replace process creation, HTTP/HTTPS/TLS/DNS/socket connect and
fetch with refusals. No Playwright or Molstar module is imported in those tests.
Python's actual helper parser is exercised only with authored bytes; process and
socket paths are refused. Failure-image tests use clearly authored non-image
bytes in their own private test directories; these are not browser screenshots.

Independent repeat (permitted inert checks only):

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-molecular-adapter-browser.WoWI5H/run-inert.py
```

Pending actual once-only command, **do not invoke before separate authorization**:

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-molecular-adapter-browser.WoWI5H/check.py --run-once
```

Output is the exclusive `WoWI5H/run/` directory. Any actual failure is retained
without automatic retry. These tests do not prove selectors are visually usable,
GPU behavior, auth/audit integration or all three product consumer contexts.
Rights remain false; this does not vendor/redistribute the private bundle.

Compounded lesson: use the exact upstream control container and actual existing
listener receipt shape. Pure assertions against guessed wrappers can pass while
the real browser never reaches the relevant behavior. Actual UI remains the next
separately reviewed gate, not a claim supplied by the inert fixture.

## Root cleanup finding and corrected freeze

The table above is the first candidate, not the current accepted freeze. Root's
complete source read found that `owners.close()` awaited a newest unresolved
allocation before closing already-owned parents. A new actual-owner regression
reproduced RED:1 failed in131.903ms; the expected context/browser/server close
list was empty. This was a concrete harness defect, not a browser result.

Root authorized the minimal correction. Known resources now close in reverse
order immediately; pending allocations retain their existing late-retirement
callback and are awaited afterward inside the same aggregate budget. No repeat
close, new owner framework, extra timer or accepting state. An unresolved value
still yields CLEANUP_UNCONFIRMED even when known parents have closed.

Corrected exact combined command above: **36 Node +6 Python =42 PASS**,
Node171.395ms, Python0.021s, outer0.269s, exit0. All earlier assertions retained.
No actual listener, browser, source request or process inspection was performed.

Current replacements:

- `check.cjs` (240 lines): `8201cf354b61bc11b1b25f10bd6dd455e48d33b41019fc75ea120d390adea818`.
- `test-check.cjs`: `8388931c7ac5d8c3b55fef4f570eed27c6f05bb702ac397283c553744d2e9859`.
- `harness-pins.json`: `7c8b72394ae43e682fe00114a3e3edd4543e7f25e72c33d24b8396195713917a`.

All other file hashes remain as above. Original `harness-pins-v1.json` retains
the prior manifest bytes at `bbda2f1d3c0f2bedd47028ef68097f6984323823182303243963105738401e02`.
Root and an independent non-maker reviewer must clear this corrected candidate
before the separately authorized actual invocation.

## Independent root grade and once-only decision

Root, who did not author this runner, read the complete corrected240-line Node
runner,121-line supervisor, both page files, all42 tests, input/harness manifests
and exact inert wrapper. Root's independent repeat produced36 Node passes
(175.3725ms) and6 Python passes(0.022s), with no browser/network/model execution.
Current runner/supervisor/pins rehash exactly8201cf35…/1dd4a2c2…/7c8b7239….
The parent-starvation correction addresses root's retained finding without
waiving unresolved allocations. The additional assigned reviewer hit the account
usage limit and did not deliver an independent grade; no such grade is claimed.

Root independently clears this finite technical harness and authorizes **one**
invocation of the exact `check.py --run-once` command above in WoWI5H. Exclusive
run-directory creation, source pins, request bounds and cleanup requirements
remain unchanged. Stop on failure; preserve original evidence. No product
service/store, native biological experiment, public vendor switch or release is
authorized. Actual screenshots and retained receipts still require inspection.
