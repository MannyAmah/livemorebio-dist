# Navigation-first ordinary browser results

Date: 2026-09-09. Reviewer/browser operator: root, separate from implementation
maker release_redteam and independent source/test reviewer startup_origin.
Result: **narrow navigation/session replacement verified; full UI and biological
acceptance NOT complete**. The LIFE empty-selection defect below is not waived.

## Running identity and preservation

- Normal `tools/run_review_stack.py --base-port 8868`, session77899.
- Fresh private root:
  `/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-5ywbh152`.
- Launcher69869; Aegle69878/8868, LIFE69879/8869, Cendos69880/8870.
- Actual health identity (31e3c2): startup2026-09-09T13:36:07.561969+00:00,
  instance5b19fb51-7855-448a-8971-e13d2914e65b,
  sourceSHA256 `d262911c1683114bc6818e43eb6fc4e1c27c157a548084f5e8daa0334ff63d23`.
- Parent commit83994425f2a3884188b1e3ee494241eba5c272f5 plus the recorded dirty
  recovery source; parent alone is not the running source identity.
- Actual in-app browser tab3, initial normal top-level navigation to8868; no
  credential injection, mocked bootstrap or substituted scientific response.
  Existing healthy reference startup computed the shipped reduced model trace.
  No participant, registered twin, experiment, device or physical sample created.

Exact navigation change and tests are in the implementation receipt. The reviewer
repeated66 cases: **66 passed in2.60s**, three existing deprecation warnings,
unexpected I/O0, Node8, Git-refused1 (27e73f). This is distinct from actual-browser
evidence below. Maker217 affected passes and historical21 are not added to that
independent66 count.

## Actual interactions and observations

| Page/action | Observed result | Remaining boundary |
| --- | --- | --- |
| Atlas `/` | Healthy reference preview, current state/readouts and active scale tree loaded | Clean store has no fixed whole-person reference installation; explicit install prompt, no substitute body |
| Twins | Protected list settles to0records/0stored; reference preview and admitted-source form visible | No individual admitted or varied cohort scientifically qualified |
| Cohorts | Protected list settles to0records/0stored; compact preparation, search/pagination visible | Healthy joint population generator not configured; no cohort created |
| Biology | Healthy-context quantities and six of seven reference organ meshes loaded | One cold asset still loading at exit; full anatomy acceptance remains incomplete |
| Biology Heart → ventricular cell | Matching heart ontology/parameter inspector and recorded voltage/calcium cell display opened; close worked | Schematic cell shape/recorded numerical readout, not computed contraction or physical measurement |
| LIFE Patch | Actual source read returns a visible inconsistency warning before any mutation | Valid unregistered-preview capability mismatch; separate correction plan created |
| Reopen local session | Explicit click reloads same `/patch` document; source read works again; no action replay | The source mismatch remained, correctly retained as separate failure |
| Cendos Preparation → History | History reports0runs/0matching, no saved experiments | No protocol or experiment executed |
| Cendos New experiment | Returns to unexecuted preparation and preserves empty history | Still displays inherited protocols; the six requested programs remain to be built/qualified |
| Research | Blank counterpart study/measurement forms and empty research ledger load | No physical measurement or qualification submitted |
| More → Knowledge | Catalog and configured/blocked/external source states load | Catalog counts do not establish operational/workflow-wired sources; no health-probe run |
| More → Advanced console | Preserved healthy numerical readouts, current-state controls and legacy views load | Legacy claims, controls and visual simplification still require full-scope review |

All nine document routes were reached through the actual UI. Relevant record and
history reads completed rather than displaying401. Final observed warning/error
console log was empty; this is not an exhaustive network trace and does not
certify every asynchronous request. Source/tests establish removal of the old
bootstrap and global fetch override; this browser run establishes ordinary page
use and explicit reopen behavior, not independent wire-level cookie inspection.

Opening the cell modal blocks underlying navigation until it is closed. It was
closed through the visible close glyph before continuing. Keyboard/focus/accessibility
acceptance of that legacy modal was not performed here. Biology document width
and viewport both measured1440, but this session was not a complete responsive/
zoom acceptance matrix. The first captures use the initial browser surface, later
captures use the1440x1000 requested viewport; screenshot dimensions are retained.

## Original image evidence

`docs/screenshots/navigation-first/` contains12 native screenshots: atlas, twins,
cohorts, biology, biology-cell, life-patch, life-reopened, cendos-history,
cendos-preparation, research, adapters and legacy. Root personally viewed every
original image. The browser delivered JPEG bytes; filenames were corrected from
the initially assumed `.png` to `.jpg` without modifying/re-encoding image bytes.
They are not experiment videos and do not count toward R40 or R41.

## Cleanup and next step

After checking exact PIDs/commands/parent identity, root sent TERM only to the
owned launcher69869. All three children logged normal application shutdown;
session77899 exited0 (7d7406). A subsequent exact-PID check found none of the four
processes (a2f3f0). No installed service or original store was stopped or deleted.

The next source change is the one-file
`2026-09-09-life-empty-selection-correction.md` plan. Restart the isolated stack
before testing its new source; do not combine old runtime identity with new UI.
The same local cookie remains host-scoped, not port-scoped; this narrow change
does not establish an independently isolated multi-port credential architecture.

Lesson: ordinary fresh-browser use exposed a valid empty-state mismatch that
mocked/native-refusal test packets did not cover. Preserve the strict execution
gate while correcting the distinction between an inspectable reference preview
and a registered execution source. No amount of passing authentication tests
substitutes for walking the real product. This docs/solutions entry is the local
compounding fallback; CE tooling was unavailable.
