# Preserve uncertainty status on activation and binding preparation

Narrow pre-code follow-up to the independently found preview P2. This is required
source-transition recovery work under R01/R15/R30/R31/R45–R48, not a new feature.
The preview correction and its original failed/green evidence remain separate.

## Source finding and scope

`SubjectRegistry._selection_read_access` raises the fixed
SELECTION_COMMIT_UNCONFIRMED error when preparation access rollback cannot be
confirmed. `server.activate_twin` and `server.bind_twin_patch` have the same outer
adapter omission as the preview publisher: the fixed code falls to generic422.
Existing preparation-rejection cases test a409 version conflict, not this503.
No clinical selection or binding commit has been attempted in this phase.

Keep the old in-memory source, generation, holder ownership, actions and
observations intact. Do not build a candidate, project old numerical state,
enter a mutation commit, publish a bus snapshot, invalidate a source or install
DENY_ALL because an audited preparation access could not finish. The response is
503 with the same route-allocated UUID and no-store, carrying only the existing
fixed code/message. Do not claim durable audit recovery or instruct POST replay.

Only add that code to these two existing outer503 sets. Do not change the shared
`_subject_error`, global exception handlers, registry/audit implementation or
actual commit-uncertainty behavior. No route layout/API/default change.

## Tests before code and independent grade

Extend the existing `test_committed_source_transitions.py` preparation fixture
with the exact `_transition_error` exception and retain all original assertions.
One parameterized test covers activation, selected binding and unselected binding.
Capture the request UUID inside preparation and compare it with the response;
assert only preparation was entered and exact old source/fence preserved.
Run these three RED before the two-line runtime change. Then run the exact
existing activation/binding transition and admission files, new binding35,
actual binding13 and preview87 to detect accidental adapter edits.

Use the existing45-second private ASGI no-network/no-model refusal wrapper.
No new dependency, constructor, real service, browser, operational database or
device work. The root may author the code only after a maker-external reviewer
reads this plan; the same reviewer independently repeats and grades afterward.
The final server hash must be handed to the concurrent preview-integration author
so no execution silently uses a different frozen candidate.

Lesson: fixed error codes are phase-specific facts. A preparation read failure
must not be mislabeled as invalid input or generalized into the mutation phase's
source denial behavior.

Independent pre-code reviewer read this full plan, both actual consumers and the
originating `_selection_read_access` branch, and cleared this exact red-first
scope. No code, test, probe or service was run by that review. Root will preserve
the concurrent actual-registry preview candidate until its author finishes the
currently approved frozen run, then coordinate the two-line adapter change.

Root authored the three regressions and reproduced the actual RED against
unchanged server3fd852c…: **3 failed/54 deselected in1.59s**, exit1, private
`livemore-research-review-vjbw8c2v`. All three fail at422 versus503. The exact
private45-second ASGI wrapper recorded unexpected I/O0 and one refused optional
Git metadata query, with3 existing warnings. Runtime correction is still held
for the concurrent frozen preview-registry packet; this RED is not a release.

## Maker implementation receipt

After the actual preview registry packet finished and root independently repeated
its15 cases at the unchanged source, root added the fixed code to only the
activation and binding outer503 sets. An initial patch-context verification failed
before changing any file; the corrected exact consumer contexts were then used.
No shared error mapper, registry, numerical code or preview publisher changed.

Final server SHA256:
`cedcf801a9ede06cbddcc2de75a495068a0970c6785e68f8e5d9664e67c52f18`.
Extended existing transition test SHA256:
`a8a723e178529151613a59f4a3e8ca7e8176443b181003df07dcc81c8a1e679b`.
The three new cases use the actual fixed preparation exception and compare the
UUID captured by the preparation fixture, with no candidate/projection/commit/
cleanup/snapshot or old-state mutation. Prior tests remain semantically intact.

Root's exact preservation packet returned **192 passed,3 existing warnings in3.30s**,
exit0, private suffix `kophjl8j`, unexpected I/O0/refused Git1 under the same45-second
ASGI wrapper. Selection: complete committed transitions+legacy admission57,
new binding35, actual binding13, preview70+retained15+retirement2. These overlap
prior packets and are not192 new or full-product tests. Diff check passes.
Independent implementation review/repeat is required before clearing this packet.

## Independent implementation grade

The independent reviewer read the full plan/receipt, both actual outer adapters,
the originating preparation error path and the new fixture/test additions. The
review retained the earlier preview distinction: preparation access uncertainty
returns503 without source denial or mutation; an uncertain attempted clinical
commit still follows its existing DENY_ALL path.

Server `cedcf801a9ede06cbddcc2de75a495068a0970c6785e68f8e5d9664e67c52f18`
and test `a8a723e178529151613a59f4a3e8ca7e8176443b181003df07dcc81c8a1e679b`
matched the frozen packet. Reversing only the two approved set additions in memory
reproduced server `3fd852c3737406b7173cab1ed915b66bbd28d3cc3def2c8a75a3c84e8e775017`.
Removing only the new preparation fixture branch and parameterized three-case
test in memory reproduced original test
`896837d1fde3eaa1b0861b04445f9e2ca25fb0612a20e4ac5d9f22cda11e65c6`.
These comparisons wrote no file and prove that unrelated runtime and prior test
bytes were not changed in this correction.

The exact independent repeat returned **192 passed,3 existing warnings in3.23s**,
exit0, private suffix `ny6qaq7x` under the standard review-root prefix. It selected
only the seven files in the maker packet: committed source transitions, legacy
transition admission, confirmed binding publication, actual checked binding
integration, confirmed preview publication, retained committed previews and
source retirement. The45-second ASGI wrapper recorded unexpected I/O0 and one
refused optional Git metadata lookup; only internal TestClient socketpair and
authored private registry fixtures were permitted. No service, browser, native
model, operational store or extra probe was used.

**CLEAR in this bounded implementation scope.** No additional actionable finding
was identified. Actual-registry preview acceptance at its earlier frozen source
remains separate evidence; this run does not replay or relabel it. Observation /
reconciliation migration, UI/SDK recovery, scientific programs and full-product
acceptance remain open. No runtime or test file was edited by the reviewer.
