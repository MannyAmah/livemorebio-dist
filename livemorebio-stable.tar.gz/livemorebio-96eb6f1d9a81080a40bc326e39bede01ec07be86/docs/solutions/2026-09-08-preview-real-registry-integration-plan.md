# Research preview: actual encrypted registry-to-publication integration

2026-09-08. **Proposal only; root approval is required before test authoring.**
Read the complete approved confirmed-preview plan, current three route branches
and shared publisher, actual prepared-clear/phase-audit/commit/witness paths, and
the retained actual binding/startup integration fixtures. Local prior art is the
independently cleared binding13 packet. No test, request, model, service, browser
or operational store was run for this proposal. R01–R51 and all six scientific
programs remain unchanged; this is transaction wiring, not biology acceptance.

## Boundary and exact write set

After approval, create only
`livemorebio/tests/test_checked_preview_registry_integration.py`; preserve all
runtime and existing tests. Root-dispatched server baseline SHA256:
`ca5113ee9725923f91201bf4765b1c1822fd289aaba0be98355d24325a69764a`.
The final read-only identity check during this proposal observed server SHA256
`3fd852c3737406b7173cab1ed915b66bbd28d3cc3def2c8a75a3c84e8e775017`.
No runtime was edited by this author; root must name the intended test source
and any relevant intervening delta before the test run. This plan is not a grade
of that whole server revision.
The original preview RED evidence, existing15 cases, new67 boundary cases and
independent runtime grade remain separate evidence, not replaced by this packet.

Exercise actual ASGI dispatch for base/LIFE via `/api/stimulate` and local note
via `/api/ingest_note`, without lifespan/startup or external HTTP. Keep the actual
server registry getter, guarded `_connect`, SubjectRegistry encryption/bootstrap/
audit, prepared-clear and commit/witness implementations. Use a fresh private
registry path and public fixed test key; seed only authored technical records.
Import existing seed/raw-row/audit functions, not registry-only autouse fixtures
that forbid TestClient's internal socketpair.

Use actual ModelSourceAuthority, assignment-only fence, commit guard and an actual
no-background ExecutionManager with a no-I/O execution store, no owners, adapters
or worker. Old selected READY state is an inert holder; old REAL_HUMAN state is
actually modeless with typed availability and ObservationState. Both retain
explicit authored observation/action sentinels. Only the candidate factories,
LIFE human carrier and local-note extractor are inert doubles; no physiological
constructor or formula executes. Retain real `_publish_research_preview` and
`_snapshot_twin`; replace only the latter's two file-backed bus sinks with
recording functions. Do not substitute prepared objects or commit outcomes.

The actual clear differs from binding: `prepare_preview_clear` has no target ID;
both audit pairs use action `inspect`, subject-access schema and **null** opaque
record ID. It still captures the exact selected row/pointer. Confirmed clear
demotes that row ACTIVE→DATA_ADMITTED, increments its version once, changes only
the prescribed timestamp/encrypted representation, and deletes the active
pointer. It neither deletes the person nor changes bindings/identifier/device
indexes. With true absence, unrelated records remain byte-identical and there is
no record mutation, but both access pairs still complete.

## Fifteen proposed cases (not a full cross-product)

| Case | Concrete dispatch and actual boundary |
|---|---|
| 1 | Base from selected SYNTHETIC/READY: real demotion and pointer deletion; 200 with candidate-owned parameters, fresh preview fence/availability, fresh observation/action containers and attributed snapshot. |
| 2 | LIFE from selected unbound REAL_HUMAN/UNAVAILABLE: same actual clear, 200 READY/reference_preview, no attempt to construct the old person's model or promote their stored evidence. |
| 3 | Note from selected SYNTHETIC/READY: real clear and candidate snapshot plus detached authored extraction metadata; one local extractor/factory call, no real note processing. |
| 4 | Base with no active pointer, no ACTIVE row and memory subject None, but an unrelated admitted row present: 200; exact unrelated bytes, successful audited clear and new preview. |
| 5–6 | LIFE with actual selected record but memory subject None; note with actual true absence but memory selected. Capture returns MODEL_SOURCE_CHANGED/409 after the actual preparation access, before any factory or mutation access; no implicit healthy fallback. |
| 7 | Base with actual selected record and a memory summary differing only in subject_id while twin_id/source_class/version match: actual four-field agreement rejects before construction. The remaining per-field/two-phase permutations stay covered by the67 boundary packet. |
| 8–9 | During an unlocked LIFE factory, independently re-encrypt the selected authored payload at the same version; during an unlocked note factory, change only active-pointer timestamp. Actual final helper rejects TWIN_VERSION_CONFLICT/409. Retain the external edit exactly and preserve old memory/fence, no preview publication. |
| 10 | Base selected clear: final mutation commit raises before real commit and real rollback succeeds. Fixed REGISTRY_STORAGE_UNAVAILABLE/503, original rows/pointer/memory/fence preserved, ACCESS_FAILED terminal retained. |
| 11 | LIFE selected clear: final commit actually persists, then loses ACK. Actual read-only witness confirms exact demotion, **absent pointer/empty ACTIVE topology** and terminal evidence; 200, once-only mutation and one snapshot, not a retry. |
| 12 | Note selected clear: final commit persists then loses ACK; deliberately alter its exact terminal audit ciphertext. Actual witness refuses confirmation: SELECTION_COMMIT_UNCONFIRMED/503 and authority/manager DENY_ALL, exact old inspection holders retained and no candidate publication. Preserve the durable demotion/deleted pointer and damaged terminal; do not call it rollback. |
| 13 | Base selected clear: final commit fails while transactional and rollback acknowledgment also fails. Preserve pending mutation BEGIN/reservation and unknown response/fences even after delegated real close rolls back. No retroactive confirmation from eventual raw rows. |
| 14 | LIFE selected clear: real commit succeeds and delegated close completes then raises once. Fixed SELECTION_COMMITTED_CLEANUP_UNCONFIRMED/503 with new preview already installed coherently and explicitly published. This is a storage-close acknowledgment case, not an execution-owner cleanup probe. |
| 15 | Unauthorized note request:401, no new audit/record/index bytes, no getter-dependent mutation, factory or source change. No startup handler enters. |

All three dispatches cross actual preparation, commit and publication. Four-field
capture is tied to an actual checked record; final storage interference is tied
to actual bytes, not a mocked outcome. Closed-manager, late in-memory generation,
postcommit operator-winner and weak-retirement permutations remain in their
already authored boundary tests. No new generic fixture framework or exhaustive
input matrix is proposed here.

## Observation and fault seams

Success/interference retain actual `_connect`. In inert factory/state callbacks,
require the completed preparation audit before candidate work and all authority,
creation, manager and initialization locks unowned. Independently acquire
`BEGIN IMMEDIATE` and roll it back on the private DB: this proves released writer
ownership, **not an observed close syscall**. Dedicated helper tests retain the
close contract. A same-version/pointer interference writer runs only here; retain
its before/after raw tuples and never repair them.

Cases10–14 alone use a small delegating wrapper around original guarded `_connect`
and real SQLite. Arm on the actual fixed `UPDATE records` for the captured active
ID/version with new DATA_ADMITTED lifecycle, not an audit commit ordinal. Record
that the real pointer DELETE and terminal phase occur before the final commit
fault. Delegate SQL, transaction state and ordinary operations unchanged. Record
bounded phase counts; no row plaintext, ciphertext or key logging.

For lost ACK, real commit runs once before raising. Preserve one demotion UPDATE,
one pointer DELETE and one final mutation attempt; the real witness performs its
single read-only check without resealing/retrying. The damaged-terminal case
changes only the just-persisted terminal tuple using a separate private writer;
retain original/changed bytes locally, never decrypt damaged bytes or replace the
witness result. Rollback fault raises before delegation; real close releases the
private transaction. Close-ACK fault delegates close first. These are controlled
acknowledgment faults, not process death, fsync or hardware failure tests.

## Cross-boundary evidence and run gate

- Assert actual method identities before/after: server getter/publisher/shared
  snapshot, prepare_preview_clear, `_prepare_transition`, commit, selection read
  owner/phase begin/reenter/finish, transition snapshot/raw evidence/witness,
  encryption `_open`/`_seal`, RegistryAudit begin/finish/check_authority, source
  observation/commit_guard/install_generation and assignment/fence guard. Actual
  `_connect` is unchanged except the five explicitly delegated fault cases.
- Preserve raw audit prefix. Normal success has preparation BEGIN/SUCCESS then
  mutation BEGIN/SUCCESS; capture mismatch has only the first pair; confirmed
  rollback/interference ends ACCESS_FAILED. Every new event uses the response
  UUID, correct null target/schema/action/store and fixed bounded fields without
  clinical content. Each pair has distinct event identities; settled paths have
  no pending reservations. Preserve damaged/pending outcomes as specified. Counts
  are not a substitute for dedicated per-decrypt audit-order tests.
- Compare actual record/pointer/ACTIVE topology/identifier/device index bytes.
  Independently decrypt only authored fixture rows using original AAD; verify
  exact demotion fields and preservation of all remaining payload fields and
  unrelated rows. No extra public getter may contaminate route audit accounting.
- Recording sinks require durable final audit and installed preview/manager fence
  before publication, outside every lock. The 200 body and bus payload come from
  the explicit candidate snapshot, with actual READY/reference_preview identity,
  subject None and reset containers. Known rollback/conflict preserves exact old
  holders/fence; unknown retains those holders behind DENY_ALL without output.
- Correlate fixed errors/no-store with the request UUID. Assert no owners,
  adapters, execution-store calls or numerical constructors. Preserve intentionally
  damaged evidence; do not recover records to make teardown or assertions pass.

After root reads/approves this complete plan, author only the named new file and
run it once under the binding report's exact private45-second ASGI wrapper with
the test-path substitution: bytecode/cache/auto-plugins disabled, connect/
connect_ex/bind/listen/DNS/urllib/child/native/model refusal, internal socketpair
allowed. Report original outcome, source/test hashes and I/O counters. Any
integration defect goes to root before runtime changes. Root independently reads
and repeats the packet; its author does not grade it. No implementation or run
is authorized by this proposal itself.

## Root approval before test code

Root read the complete original133-line proposal and approved exactly15 cases,
the named new test file and one private45-second run. The intended server is
`3fd852c3737406b7173cab1ed915b66bbd28d3cc3def2c8a75a3c84e8e775017`.
The author read the producer-plan and implementation-report P2 append: this
revision maps the real preparation SubjectRegistryError uncertainty to503, not
422, preserving prior state/generation because no clear was attempted. Root's
87-case result and independent follow-up are separate evidence. This packet does
not add actual preparation rollback-fault injection beyond its approved15 cases.
Null-target audit semantics, demotion/pointer deletion, real witness and damaged
outcomes remain mandatory. No runtime or existing test edit is authorized; root
will independently read and repeat the finished new tests.

## Retained first invocation: test-fixture error

New test SHA256 `6f62f1d5b97114ddd2c610015779ec57b96f2335e4d8a6ff802f67f1b1702014`,
479 lines. The first approved private15-case run returned **15 setup errors,
3 existing warnings in1.84s**, exit1; private root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-m7ad95pt`.
Unexpected I/O0, exact optional Git metadata refusal1. This is not product RED:
the identity assertion assumed every protected instance attribute has __func__,
but `_raw_transition_evidence` is a staticmethod and already returns its function.
Every case stopped before route/factory execution. Root was notified before any
test correction or repeat. The proposed correction retains exact class-function
identity while unwrapping only bound methods; no protected method is substituted.
