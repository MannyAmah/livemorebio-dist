# Continuous LIFE and Biology UI binding

2026-09-08. Additive implementation under the approved continuous-execution plan
and R01–R51 master. This packet does not replace any insulin, botanical, whole-body
or physical-validation obligation. Existing Atlas, saved experiments, anatomy,
device intake, cohort creation and physical observations remain available.

## Approved scope and visible behavior

1. LIFE's primary panel becomes an explicit continuous numerical-device workflow.
   A compact setup box shows the selected registered twin, supported source, native
   horizon and wall/model rate. Preparation never starts computation. A fixed
   virtual probe is registered and separately bound to that twin before source
   capture, because binding changes the registry version. Each click has a pending,
   succeeded, conflicted or unconfirmed outcome. No automatic mutation retries.
2. Prepare → bind LIFE session → start producer is visible as separate controls.
   The panel distinguishes engine, LIFE admission and Aegle acknowledgment. Pause,
   resume and stop are separate lifecycle controls; resuming a consumer does not
   start its producer. Recovery tells the user which source/revision to inspect.
   Refresh never creates a device, source or sample. No browser heartbeat renews
   producer permission. A fixed execution/session can be reopened by their IDs.
3. The existing prepared-envelope and recorded-playback interfaces remain in an
   explicitly secondary section. Physical packets are not replaced by this
   numerical source. No fabricated HR, ECG, oxygen or ISF sensing is introduced.
4. A Biology URL with `execution_id` opens a distinct execution-bound inspection
   surface; no active-twin or saved-run data is substituted. It shows the exact
   frozen subject/source/condition, native clock, committed frame, numerical state,
   quantities with units/compartments and source provenance. The same ID links back
   to LIFE. Ambiguous run+execution URLs fail visibly instead of picking a source.
5. New committed series update plots/readouts only when their frame arrives. There
   is no autonomous playback, invented interpolation, clamping or repeated beat
   presented as new computation. Source invalidation stops follow mode and leaves
   clearly marked historical values, not a moving replacement. Offline/error states
   keep last values visibly stale. Frame cursor/hash/predecessor/selection and native
   units are checked before UI publication; server-authored hashes remain identity,
   not a claim that browser JSON float serialization recreates canonical bytes.
6. Reference anatomy remains inspectable with its existing renderer, clipping,
   isolation and bounded asset retries. Geometry is not resized or made to contract
   from an unrelated scalar. Metabolic G/X/I are systemic compartment quantities;
   cardiac membrane voltage/calcium are ventricular-cell quantities, not ECG or
   mechanical heart output. Only available quantities are live. Missing gene,
   tissue-mechanics and sensor-transfer contracts remain explicit dependencies.
7. Whole-person Atlas is not replaced by this organ-inspection surface. Its later
   live-state binding must consume the same exact source, not borrow a default twin.

## Implementation boundaries

- New small modules `execution_view_state.js`, `continuous_execution.js` and a
  shared stylesheet. Mount additive LIFE and execution-Biology hosts; preserve
  existing active and run-specific code branches, except excluding the new branch
  from their automatic loads. No new frontend framework or external CDN.
- Existing same-origin authenticated execution and LIFE proxy APIs only. Strict
  16-KiB creation/control bodies contain IDs, revisions and explicit policies, not
  result arrays. Read pages use bounded frame cursors, max10 per request and a
  bounded1000-point per-quantity UI window. Older native data remain in the durable
  execution, not silently deleted by view retention.
- Poll while visible with one in-flight request, abort on navigation/source
  replacement/disposal, bounded timeout. Hidden pages stop polling but do not stop
  the server's explicitly started worker or LIFE consumer. Retry is a read action.
- Escaped text/DOM textContent for all source/error fields; no arbitrary HTML from
  a peer. Buttons disable during a request; stale revisions do not refresh+retry
  mutations. Auth failures offer local-session recovery without printing tokens.
- Do not persist physiological payloads in localStorage, logs, clipboard or query
  strings. URLs may hold opaque execution/session IDs only; operational HTTP access
  logs must remain disabled in the private acceptance stack.

## Red-first and independent acceptance

Pure state tests reject wrong execution/source/selection, out-of-order or changed
frame hashes, missing/nonfinite series, time rollback and mixed units. Validate
window bounds, unchanged-value but advancing-time frames, correct no-frame state,
stale/source-invalid display and no hidden playback. Browser tests exercise real
buttons against private real services, inspect console/network failures and
screenshots at desktop/mobile widths. Inspect preserved active/saved Biology,
Atlas, cohorts and physical/legacy Patch sections for regressions. Maker tests
are not independent acceptance. Record actual preparation and interaction only
after native two-service and browser review; the separate30-minute soak remains
open until measured. No video of a technical fixture substitutes for the six
required experiment recordings.

Independent pre-code review approved this additive view on2026-09-08. Additional
mandatory cases: rapid source switch while an older response is in flight;
adjacent frames' shared boundary sample is deduplicated only if time and value
agree; reopening after more than10 missed frames catches up by bounded pages and
never labels a retained window as the entire history. Source identity must remain
coherent throughout. Root retains actual-browser acceptance ownership.
