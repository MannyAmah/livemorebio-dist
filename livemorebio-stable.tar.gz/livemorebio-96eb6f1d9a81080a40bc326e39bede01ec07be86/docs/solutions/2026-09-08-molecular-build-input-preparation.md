# Molecular build input preparation: stock resolver boundary

2026-09-08. **Private source preparation only; resolver NOT RUN.**
Root approved preparation under the final section of the
[structure-only plan](2026-09-08-molecular-structure-only-build-controller-plan.md).
The concrete source evidence below prevents claiming that npm's lock-only flag
enforces the narrower metadata-only acquisition contract.

## Prepared and frozen inputs

Private0700 directory: `/tmp/livemore-molecular-build-plan.4ej8oR`.
Exactly seven authored files are present. No lockfile, cache, node_modules,
extraction tree, dependency archive, build output or process was created.
The files were written with apply_patch. No installed Molstar/library module was
imported or executed; the established archive was read as data only. No product,
old harness, service, browser, model, coordinate file or operational store changed.

| Private file | SHA256 |
|---|---|
| entry.js | `24ad4a5a52229b0f852d2aa67e8bd404fb370bd79b0b3cbeb97d2516141b214a` |
| spec.js | `49f9b841e1cd144767d734e5520dfabaf95b9234c2cbc6ae4e52110441bf2b35` |
| package.json | `577a4874ac6d7a3e0050bacab10748787cd1e5a6f7eff6bd81cbac48c5bc195c` |
| webpack.config.cjs | `331c71c6dffb146b7915565ce067633ee5d78f09e37530ab358ce3a8e9d04427` |
| RESOLUTION-NOT-AUTHORIZED.md | `122642b642d8de11d144bf036f4a1da54cae1b3bf829465943be46b156e871b4` |
| user.npmrc | `a2a25208bb447d7290095431c05d2e6967f4a60be37703097af3bb3c1276fb56` |
| global.npmrc | `df8c32ff108ef28e33a8260e68e9ce78ae66b5be795cb9acf48400668d390e25` |

entry.js exports the existing public PluginUIContext/Plugin/React18 primitives,
the explicit spec, and exact model-preset parameter shape. It does not mount or
implement the yet-to-be-RED-tested lifecycle controller. spec.js composes existing
selection, camera, sequence, measurement, style and representation components;
no new renderer. The upstream public ViewportCanvas is used without its optional
external logo, with a local missing-WebGL paragraph. Source signatures were read
from the retained package; no visual behavior is claimed from these drafts.

The manifest pins all nine direct packages: the retained Molstar file plus
React/ReactDOM18.3.1 and the six exact approved webpack/Sass packages. It has no
scripts. Transitive dependencies remain unresolved; this is not a fabricated
lockfile. The webpack input is a production ESM entry, no eval/source-map,
split/runtime chunk or destructive clean step, with one CSS output. Actual
compile/graph/notice closure and browser lifecycle RED/GREEN remain later gates.

## Exact local tool identities and inspected primary sources

Node executable: `/opt/homebrew/Cellar/node/26.0.0/bin/node`.
One `--version` invocation returned v26.0.0; it did not run npm or package code.
The npm launcher is `/opt/homebrew/lib/node_modules/npm/bin/npm-cli.js`, with
version11.12.1 read from its package.json, not an npm command. npm's built-in
npmrc contains only `prefix = /opt/homebrew`. The candidate command explicitly
overrides that prefix and both user/global config files with private paths.

| Exact local file | SHA256 |
|---|---|
| Node executable | `08dad0581f00a0cabf4d49ec92ca1f25fdfd01c2c18fa8e92b35f04d4c24c164` |
| npm bin/npm-cli.js | `8e5f6f3429f8cdbe693cdc29904e9d5a7b127a494bd15c804bd54c7403bfcbe7` |
| npm package.json | `48a06e6aeede3499e391710db82fe948afa7e74ecbf3e819b66121f3cd54666b` |
| npm npmrc | `72b4b27ffdcc6eade20c176600b98f8d91601990540ed19d24a2d2d6d5b95f8e` |
| npm/node_modules/@npmcli/config/lib/definitions/definitions.js | `6d1a21868e9f46538c1e4999c73987325a516f03e3b7fe8f986df932325e3b83` |
| npm/node_modules/@npmcli/arborist/lib/arborist/build-ideal-tree.js | `ae6809d5ab55bfabc7b1c3064e8dfa78b1a5f7f36f67de5cce85f70c71654c60` |
| npm/node_modules/pacote/lib/remote.js | `d4843de4eec468b75632de2f431eb769a333dbd345b1b294f57a4a9eb077192c` |
| npm/node_modules/make-fetch-happen/lib/fetch.js | `7d57bfd656a6ae2a53738fb3f25365d074d9cb7364794005bc70317ff2bf81e8` |
| npm/node_modules/npm-registry-fetch/lib/index.js | `9757d6aa767884be9e566ebfeaca76c94d80bbea854b41a42ce8648feb2fca42` |

These pin the executable/launcher and inspected decision seams, not the complete
installed npm dependency tree. Before a future authorized invocation, the full
tool-tree file manifest should be frozen as read-only metadata; no tool upgrade.
Context7/gbrain were again unavailable; installed official npm source and the
retained Molstar source were used, not guessed configuration flags.

## Exact command and actual enforcement gap

`RESOLUTION-NOT-AUTHORIZED.md` contains the complete fixed argv, cwd and minimal
environment. It invokes the installed Node and npm CLI with package-lock-only,
lockfile-version3, ignore-scripts, allow-git=none, no audit/funding/update-notifier,
fetch-retries0, fetch-timeout30000, maxsockets1, strict SSL/peer dependencies,
no bin links/workspaces, exact official registry and private prefix/cache/logs.
No HOME override, credentials, inherited proxy/NODE_OPTIONS or user npm config.
The private tmp/cache/log directories are not created because no invocation ran.

Supported flags were checked against the installed definitions. `allow-git=none`
is an actual value, not a guessed option. **Nevertheless the command cannot be
called metadata-only under the approved constraints:**

1. Arborist build-ideal-tree.js:804–835 explicitly says package-lock-only complete
   trees crack open tarballs for bundle/shrinkwrap dependencies and calls
   `pacote.extract`. This applies even to registry dependencies, without an
   adversarial remote spec. Whether this exact pending closure would hit it is
   unknown; the source proves the stock command does not enforce the prohibition.
2. pacote remote.js:82–91 delegates remote `manifest()` to the file fetcher;
   its metadata comes from the remote archive stream. Registry configuration is
   not a transitive-spec origin/path firewall.
3. make-fetch-happen fetch.js follows redirects unless its own lower-level
   redirect mode rejects them. npm-registry-fetch index.js:104–135 constructs its
   options without a corresponding redirect-error CLI field. No documented
   `npm install --no-redirects` flag was found or invented.
4. fetch-retries0 disables the configured HTTP retry mechanism. It does not
   establish once-only application fetches or prevent metadata fallback paths.
5. The384-package, response-byte and15-minute total bounds are not npm CLI
   admission limits. A post-resolution count does not bound the preceding work.

The manifest also points to the already retained local Molstar archive. Its
manifest can be inspected without a second network GET, but stock pacote may
extract that local archive. This needs an explicit allowed local-data treatment;
it is not hidden inside a claim of zero archive handling.

## Smallest next decision

Keep npm/Arborist as the version/peer/placement resolver. Do not implement a new
dependency-resolution algorithm. Root can approve a narrow **request-denial
boundary** around the installed resolver: exact official packument GET paths,
no redirects/archive requests or Git/children, bounded metadata size/count/time,
safe partial evidence, and explicit permitted reading of the retained Molstar
manifest. Its practical hook/OS boundary and inert negative tests must be written
and reviewed before invocation. This packet does not implement that boundary or
claim that post-hoc lock inspection provides one. A plain stock command remains
NOT_AUTHORIZED; no requests are spent while root chooses that bounded approach.

The useful prepared structure-only entry/spec is retained for the next input
step. No current target or consumer mode was removed. The six coordinate IDs
remain candidates in the parent plan; no coordinate URL was requested here.
The prior acquisition integrity clearance and full-product open requirements
remain unchanged. Lesson: lockfile-only means no materialized installed tree,
not a guaranteed metadata-only network graph.

## Exact proposed denial layer (pre-code; root checkpoint requested)

Keep the CLI argv above and add only
`--require /tmp/livemore-molecular-build-plan.4ej8oR/metadata-policy.cjs`
between the Node executable and npm-cli.js. That preload does not exist yet.
One small private `resolve_metadata.py` would launch that exact single Node child
with the recorded environment and a900-second total deadline, retain bounded
stdout/stderr and a fixed receipt, then reap/confirm that owned child. The Node
preload owns abort signals and receipts; it neither resolves semver/peers nor
writes a lock. npm/Arborist alone produces the real lockfile. No proxy/server,
new registry implementation, library fork or custom dependency resolver.

### Source-backed interception points and order

1. Validate argv/cwd/config/manifest and the pinned local npm source manifest
   before loading the CLI. Reject any changed/missing source, existing cache/lock
   or inherited execution hook. Deny subprocess spawn/exec/fork variants and
   worker creation before npm loads. Global fetch/HTTP outside the approved npm
   request context must fail closed. The boundary covers this pinned trusted npm
   call graph, not malicious native code or a general-purpose OS sandbox.
2. Load the pinned `make-fetch-happen/lib/index.js` before npm-registry-fetch or
   pacote, retain its original export, and replace its require-cache export with
   a guarded delegate. Preserve public Request/Response/Headers/error exports.
   Its public `defaults(defaultUrl, options, wrappedFetch)` implementation accepts
   a delegate; any defaults call must remain wrapped, never close over the raw
   original. An initialization assertion verifies the actual downstream require
   resolves to this exact wrapper before invoking npm CLI.
3. Each delegated request must be a bodyless GET with pacote's packument request
   classification, exact HTTPS `registry.npmjs.org` origin, no credentials,
   explicit port, query or fragment. Allow only one canonical package path:
   `/name` or `/@scope%2fname` (case-normalize the sole encoded slash). Reject
   `/-/`, additional separators, dot traversal/other escapes, tarball endpoints
   and arbitrary URLs before the original fetch is called. Bind the low-level
   HTTPS request to that exact allowed URL using a request-scoped authorization
   context; raw HTTP/HTTPS/global fetch without it is denied. No general URL
   allowlist beyond these npm packument paths.
4. Force the **supported lower-level** original-fetch options `redirect:'error'`,
   `follow:0`, `retry:{retries:0}`, `strictSSL:true`, no proxy, full JSON Accept
   and identity Accept-Encoding, one request-specific abort signal and no-store
   for the metadata fetch. These are not invented npm CLI flags: make-fetch-happen
   index.js constructs Request with supplied options; fetch.js explicitly checks
   `options.redirect === 'error'` before getRedirect. The additional low-level
   URL fence prevents an alternate-origin hop even if that behavior regresses.
5. Before returning a response to npm, collect only its bounded metadata body:
   at most16MiB per packument and128MiB aggregate actual bytes, at most384 distinct
   package-name requests, with30seconds including headers/body inside the one
   overall900-second deadline. Any present Content-Length must be valid and
   match the identity body; reject nonidentity encoding or non-JSON type. Do not
   misuse minipass-fetch's `size` field as a maximum: its installed body reader
   uses MinipassSized for expected size. Count chunks explicitly and abort on
   excess. Return a fresh upstream Response containing the exact admitted bytes,
   status and safe headers; no source JSON field or dependency range is rewritten.
6. Retain one in-flight/completed metadata result per exact package URL. Repeated
   resolver demand may share the original in-flight byte collection and receive
   fresh Response instances after success; it must not make another HTTP request.
   Failure stays sticky and is returned again without retry. Require exact200;
   redirects,404,5xx, transport failure and timeout stay fixed failed outcomes.
   Source metadata bodies remain private; the final receipt lists only fixed
   package identities/status/counts/byte lengths/hashes, not raw errors or env.
7. Wrap the existing `pacote.manifest` entry, preserving its actual resolver for
   registry version/range/tag/alias specs after npm-package-arg classification.
   All Git, remote, directory and file specs fail before resolution except the
   **one exact retained Molstar file**. For that exception read the already
   verified package.json text from retained-manifest-notices.json, validate both
   that retained-file hash and archive identity, and return a detached copy with
   FileFetcher's documented `_resolved`, `_integrity`, `_from` identity fields.
   This substitutes a previously verified manifest read for FileFetcher.manifest's
   extract-to-temp step; it does not fabricate a version or resolve a dependency.
   The actual npa file-spec identity and normalized manifest parity must be tested.
8. After each successful selected registry manifest, reject nonempty
   bundleDependencies or `_hasShrinkwrap`, unknown/nonregistry dependency specs,
   nonofficial dist URL, missing integrity and the385th distinct selected
   name/version before returning it to Arborist. Keep dependency ranges intact;
   on rejection stop, do not filter a dependency or choose a different version.
   Also replace pacote's extract/tarball methods and file/remote fetcher extraction
   paths with fixed denial, so an overlooked crack-open cannot acquire/extract
   anything. No selected package source or lifecycle code is executed.

The384 selected-version cap and384 unique packument cap are separate. A packument
contains upstream metadata for many versions; those records are not treated as
selected installed packages. The128MiB limit here is a new **metadata-body**
ceiling, not permission to spend the later archive budget. Raw network chunks can
arrive before a cap is observed; abort immediately on the first excess chunk and
retain that actual count, never report that exactly the nominal cap was received.
The per-request signal covers DNS/headers/body while Node is responsive. The
parent enforces the whole-child900-second wall bound, including JSON parsing;
no claim of preempting synchronous parser work with a JS timer. Use5seconds
additional owned-child cleanup, fixed CLEANUP_UNCONFIRMED if not reaped. Receipt
failure cannot skip cleanup. No service/listener or unowned process is touched.

### Bounded RED-before-code checks:38 cases, all offline

One private test file exercises the actual preload helpers plus installed pinned
npm/Arborist with authored metadata and a refused socket/DNS/subprocess boundary.
It never imports Molstar/React, runs npm online or extracts a dependency archive.
No existing product assertion is changed to accommodate these tools.

-10 URL cases: valid ordinary/scoped paths; reject external host, HTTP downgrade,
  credentials, nondefault port, query, fragment, tarball path and encoded traversal.
-4 redirect cases:301/302/307/308, assert exactly one attempted original request,
  no destination request and retained status before failure.
-2 method/body cases: POST and bodyful GET denied before delegate.
-3 failure cases:500, connection error and held headers timeout, no retry.
-3 body cases: over16MiB, inconsistent length and encoded response; held-body
  cancellation is included in the oversized stream case without changing caps.
-3 resource cases:385th unique name,385th selected version and total deadline
  during body/JSON workflow, preserving partial count/failure and owned cleanup.
-2 retained-file cases: exact Molstar identity/manifest parity versus wrong hash
  or another file spec; no file extraction or archive stream requested.
-2 crack-open cases: bundleDependencies and `_hasShrinkwrap` rejected, using
  actual Arborist paths and denial spies, not only guard input predicates.
-3 escape cases: child/Git attempt, raw out-of-context network and wrapper
  defaults/alternate import path cannot reach an unguarded request.
-2 whole-resolver cases: real npm/Arborist produces the expected private lock
  for an authored peer/alias graph; an authored remote dependency stops before
  acquisition. Existing npm semver/placement is exercised, not reimplemented.
-2 duplicate cases: concurrent/success repeat gets fresh response with one GET;
  repeat after failure preserves that failure with no retry.
-2 receipt/cleanup cases: metadata observer/write failure still reaps; forced
  supervisor deadline reports unresolved work instead of a complete lock.

The exact hook code, complete npm tool-tree hashes and offline receipts must be
root/independently read before the single actual metadata resolution is separately
authorized. This amendment authorizes no request itself; no new helper or runner
is implemented here. If the hooks cannot be made coherent against the pinned
actual resolver within this small scope, report that concrete incompatibility
rather than silently switching resolvers or permitting tarball acquisition.
