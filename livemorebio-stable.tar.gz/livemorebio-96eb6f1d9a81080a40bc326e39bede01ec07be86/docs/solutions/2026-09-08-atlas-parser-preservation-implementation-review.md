# Atlas parser preservation — maker checkpoint

Date: 2026-09-08. Implementation follows the root/independently approved
`2026-09-08-atlas-parser-identity-preservation.md`, including its pre-code
verification precisions. **Independent implementation review remains pending.**
No browser, running service, participant store, actual publisher acquisition,
actual source conversion, or physiological model was used.

## Bounded change

Only two runtime files changed. `strict_json.py` now contains the exact original
six local function definitions from retained source SHA
`6af73cc557bdb3a18bda10bc114148ef7e25f711410fd1d263e11279ea01c8e1`, followed
by a documented imported alias. A source diff against those retained bytes
contains only the bottom comment/import addition. The original argument checks,
validation order, errors, defaults, constants, and five validators are unchanged.

New `frozen_member_json.py` owns only the fixed 16 MiB decode envelope. It imports
the shared validators and exact `StrictJSONError` at call time; neither import
order has a partially initialized dependency. Its genuine module identity stays
`livemorebio.frozen_member_json`, and the old strict_json import is the same
function object. No `__module__`, code-object, or converter identity manipulation
exists in runtime code. The generic parser still has its original 2,000,000-byte
default and 8 MiB override ceiling. No SDK, transport, route, source declaration,
receipt, cache, converter, geometry, or dependency version changed in this packet.

## Red-first evidence

New `test_atlas_parser_preservation.py` was written before either runtime change.
Using the pinned interpreter and a newly prepared private environment, the first
run produced **12 failed / 6 passed in 1.91 s**. Failures showed the extra local
functions, changed generic parser and combined identity, absent response module,
missing shared-hook seam, both fresh import orders, and absent wheel module.
The five unchanged validator pins and actual converter mutation-sensitivity test
already passed. This distinguishes the observed preservation regression from
tests for the newly proposed separate module.

The admitted identity pins are explicitly CPython 3.11.15-specific. Tests assert
the exact six local names and defaults on every interpreter; they do not pretend
that loaded Python bytecode hashes are portable. Semantic/import checks remain
independent. An altered generic validator still changes the actual Atlas
converter hash, so the preserved integrity check has not been bypassed.

## Verification results and scope

- First parser/frozen-member/research JSON packet: **199 passed in 6.65 s**.
- Broader 19-module packet: **965 passed, 3 existing deprecation warnings in
  22.62 s**. It includes all fixed-16-MiB byte/route/SDK semantic negatives,
  ordinary strict JSON parity, Atlas source/geometry/cache/process/worker/API/
  client/command tests, execution clients/commands/control revision clients,
  clinical SDK and selection-reconciliation clients, and three source-authority
  fences. No test was deselected in this packet.
- A final strengthening makes the shared-validator assertion occur immediately
  after the fixed parser call, before the comparison generic parse can supply
  any hook calls. The final exact-file rerun passed **18 tests in 2.25 s**,
  including its private wheel and fresh-process checks.
- The new wheel test stages source in pytest-private storage, builds without pip,
  dependency resolution, or network, checks exact module bytes, then tests both
  import orders outside the checkout using `-I -B`. Import-time write/network
  guards and absence of numerical runtime imports are asserted.

All parent test runs used six explicit refusal hooks: `socket.socket.connect`,
`connect_ex`, `socket.create_connection`, `socket.getaddrinfo`,
`urllib.request.urlopen`, and `OpenerDirector.open`. Private child import/wheel
checks install their own same hooks. Test-only source conversions use the existing
labelled technical triangles, not the publisher's body. No live HTTP fallback,
browser, physiological solver, or operational registry is involved.

Exact interpreter: `/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python`, Python
3.11.15, NumPy 2.4.6, trimesh 5.0.0, with bytecode writes disabled. Each run calls
the existing `prepare_review_environment()` before pytest and disables pytest's
cache provider. The broader private environment ended in
`livemore-research-review-zy15ktnc`.

The reproducible 19-file selection is `livemorebio/tests/test_` plus each of:

```text
atlas_parser_preservation.py
frozen_member_response_limits.py
research_json_parity.py
atlas_reference.py
atlas_reference_geometry.py
atlas_reference_cache.py
atlas_reference_process.py
atlas_reference_worker.py
atlas_reference_api.py
atlas_clients.py
atlas_commands.py
execution_clients.py
execution_commands.py
control_revision_clients.py
clinical_sdk_terminal.py
selection_reconciliation_clients.py
product_source_authority.py
execution_source_fence.py
model_source_authority.py
```

## Actual retained manifest: read-only reuse, not new admission

A separate guarded process opened the original public-reference cache with
normal `_Cache()` and `_read_manifest()`. It did not replace either function or
alter the converter identity. Network refusal, an audit hook rejecting writes
and process creation, and call-profile refusal of install/acquisition/conversion/
publication entrypoints were active. The full cache inventory was hashed before
and after. No create, install, conversion, repair or fallback occurred.

Result: `READ_ONLY_MANIFEST_REUSE_PASS`.

| Evidence | Value |
| --- | --- |
| Original manifest | `8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a` |
| Restored loaded converter identity | `e7532a863d945fabb296753e9aa8b5b6187f9609fb6dff518255053b1783e5f8` |
| Files compared | 16 |
| Total retained bytes | 169,952,687 |
| Before content/size/mtime inventory SHA | `2583e453656b1d18cbb7925b62809a92dc8316b359495ca5b7ea8a2fdb06deeb` |
| After content/size/mtime inventory SHA | `2583e453656b1d18cbb7925b62809a92dc8316b359495ca5b7ea8a2fdb06deeb` |

The current full conversion metadata equals the stored metadata exactly. This
check restores normal manifest admission and confirms unchanged files; it is
not a fresh all-array source qualification, performance result, or screenshot
acceptance. The original receipt and all prior browser failures remain retained.

## Frozen files for independent review

- `livemorebio/strict_json.py`:
  `87522902a7463d4ff3f6c68f3371b1f1d3ed2786f6ccd5549e021e166a3395fa`
- `livemorebio/frozen_member_json.py`:
  `081b9bc06f0df6726fc42286d4246a84586dc2d45ce38bf1524c732e53e528b2`
- `livemorebio/tests/test_atlas_parser_preservation.py`:
  `8a4aecf6b3455ebc211068f50a195d7b4aa556460e4396561cae90b110dab912`

Unchanged Atlas source/cache, geometry and process-helper hashes were rechecked:
`58ab81e8…`, `44b08f9b…`, and `c8b9fe7b…` respectively. No converter namespace
allowlist or historical artifact rewrite was introduced.

## Compounded lesson

The older shared parser was also part of an admitted scientific artifact's
producer identity. A new feature's passing semantic tests did not prove retained
artifact compatibility. Keep an exact dependency regression beside the new
feature, and independently test installed imports and actual immutable reuse.
Never respond to preservation failure by disabling the integrity comparison or
replacing the old artifact. The unavailable CE provider is not claimed as run;
this local record retains the lesson and test evidence.

## Independent root review

Root read the full plan, both runtime modules, all188 final test lines and this
report. The diff against the verified admitted source contains only the bottom
alias/comment; the fixed response keeps shared validators and its actual module
ownership. No runtime identity spoof, budget expansion or transport edit found.
Independent full19-module rerun: **965 passed,3 existing deprecation warnings in
22.72s**, private root `livemore-research-review-dmsa4cp8`, explicit socket,
connection,DNS and urllib refusal. The final strengthened test was included.

A separate normal `_Cache(create=False)`/`_read_manifest` check independently
returned the original manifest and converter hashes above. All16 files and
169,952,687 bytes matched before/after in content,size,mtime; no install,
conversion or write was allowed. The profile tripwire produced a shutdown-only
AttributeError when an interpreter-finalization module name became None, after
the PASS and cache comparison; this is a diagnostic-hook defect, not a cache
or product failure. It does not support any additional acceptance claim.

This bounded parser correction is independently cleared. Browser presentation,
performance, whole-product acceptance and all six programs remain unclosed.
