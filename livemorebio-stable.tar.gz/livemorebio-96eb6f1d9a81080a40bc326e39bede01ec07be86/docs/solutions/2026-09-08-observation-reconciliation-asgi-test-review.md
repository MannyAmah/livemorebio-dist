# Observation/reconciliation ASGI test packet: authored RED receipt

## Approved scope and frozen original

Root read the full committed-publication plan and independent addendum and the
207-line exact ASGI inventory before authorizing this test-only packet. One new
file implements the enumerated78 collected cases. No server, registry, model,
client, browser or operational-store implementation was changed by this author.

Original new test:
`livemorebio/tests/test_committed_observation_reconciliation_publication.py`
(1,035 lines), SHA256
`66d808fa53fb20b1b31eecb7a12a7e948fe7973c43798a5f7154d0aeda000caa`.
Server before and during the original RED:
`cedcf801a9ede06cbddcc2de75a495068a0970c6785e68f8e5d9664e67c52f18`.

The author and root both identified the prospective cleanup503 wire-fixture
mistake before this first run. The frozen file already gates record
twin_id/version/lifecycle and availability assertions on status200; cleanup503
still asserts the new committed state, own snapshot and exact fixed code. This
was a source-reading correction, not a runtime failure or observed RED→GREEN fix.

## One authorized original RED

The exact78-case file ran once against that unchanged server:

```text
PRIVATE_REVIEW_ROOT .../livemore-research-review-fyzgljhg
72 failed, 6 passed, 3 warnings in 1.81s
REVIEW_IO_COUNTS 0 1
```

Execution session61236 completed with exit1; no test process remains. The three
warnings are the existing TestClient/HTTPX and startup-on_event deprecations.
The guard counts mean unexpected I/O0 and exactly one refused optional Git
metadata lookup. No lifespan/startup, model/native child, browser, service, real
HTTP, operational database or registry constructor was used.

The six passing cases are both auth-first cases, request MAX+1 rejection by the
existing strict JSON parser, both invalid reconciliation body/query cases, and
reconciliation rejection when source authority is already confirmed.

The42 observation failures reach the forbidden old target-only `get_twin` path
instead of the new audited full preparation; this includes request MAX and DENY
cases that should have rejected before that read. The30 reconciliation failures
reach the old call lacking `_checked_snapshot=True`; the current route catches
that missing-keyword failure as storage503. Expected capture/factory/final phase
assertions prevent these incidental503s from becoming false passing cases.

Therefore later snapshot, final-guard, ABA, cleanup and weak-retirement assertions
are still masked by earlier missing product seams. This receipt does not claim
those later faults were independently reached. Pytest expanded the intentional
`pytest.fail` legacy-call guard into nested ASGI exception-group tracebacks;
the tool output was truncated, but its final78-case summary/counts and explicit
failed case names were returned. No complete raw traceback file was generated or
claimed, and the run was not silently repeated to change its output.

## Exact original repeat command

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery` only after the
independent reviewer receives the intended source/test freeze. This is the exact
original wrapper and single-file selection, not an invitation to run services.

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os, sys, signal, socket, subprocess, urllib.request, multiprocessing.process
from tools.run_review_stack import prepare_review_environment
review_root, env = prepare_review_environment(inherited={k: os.environ[k] for k in
    ('PATH', 'HOME', 'TMPDIR', 'LANG', 'LC_ALL') if k in os.environ})
os.environ.clear(); os.environ.update(env)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
blocked, metadata = [], []
def deny(*args, **kwargs):
    blocked.append('unexpected')
    raise AssertionError('Review forbids network and child/native work')
def process(command, *args, **kwargs):
    if command == ['git', '-C', '/Users/emman/Livemore/.worktrees/full-scope-recovery',
                   'rev-parse', '--show-toplevel']:
        metadata.append('refused')
        raise OSError('Authored unavailable Git metadata')
    return deny()
def audit(event,args):
    if event in {'os.fork','os.forkpty','os.posix_spawn','os.exec',
                 'subprocess.Popen','socket.connect','socket.getaddrinfo'}: deny()
sys.addaudithook(audit)
multiprocessing.process.BaseProcess.start=deny
for name in ('bind','listen','connect','connect_ex'): setattr(socket.socket,name,deny)
socket.getaddrinfo=socket.create_connection=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
subprocess.Popen=process
import pytest
class InertReview:
    @pytest.fixture(autouse=True)
    def no_models(self,monkeypatch):
        from livemorebio.tests.clinical_registry_fixtures import forbid_compilation
        from livemorebio.aegle.runtime import AegleTwin
        from livemorebio.engines.metabolic.glucose_insulin import MetabolicProfile
        forbid_compilation(monkeypatch)
        monkeypatch.setattr(AegleTwin,'__init__',deny)
        monkeypatch.setattr(MetabolicProfile,'__init__',deny)
signal.alarm(45)
print('PRIVATE_REVIEW_ROOT',review_root,flush=True)
rc=pytest.main(['-q','-p','no:cacheprovider','--tb=line',
    'livemorebio/tests/test_committed_observation_reconciliation_publication.py'],plugins=[InertReview()])
print('REVIEW_IO_COUNTS',len(blocked),len(metadata),flush=True)
signal.alarm(0)
raise SystemExit(rc)
PY
```

The existing internal TestClient socketpair remains available. The exact refused
Git query is not a permitted child; all other process/network requests fail.
The fixture uses actual authority and creation/manager guards with a non-background
manager, actual modeless projections and inert registry results. These tests do
not grade registry encryption, transactional audit or whole-product readiness.

## Authorized post-RED test-only work

Root authorized adding actions to the same during-supersession strong-liveness
assertion, without adding cases or rerunning this masked RED. Root's planned C1
capture now retains both state and actions. Preserve the original66d808…/72FAIL6PASS
history above. The only inherited migrations permitted are the four observation
outcomes and five reconciliation outcomes named in the inventory; the other
existing assertions and eight parser/auth cases stay intact. Their final hashes
will be appended after migration. Runtime implementation and independent grading
remain separately owned.

Lesson: fail at the missing contract boundary without claiming downstream checks
ran. Keep safe error-response assertions distinct from committed source facts,
and make weak-lifetime probes independent of references retained by test fixtures.

## Post-RED test freeze for route implementation

No second run was performed. The same supersession case now explicitly requires
the captured old actions to remain alive along with state/model/observations
during unlocked preparation, matching root's exact additional C1 retention
instruction. Final cleanup still checks every weakly observed holder outside
all four locks. Case count remains78. New test SHA256:
`31d9e40eeb227c1cd6287cb5aa49f6bc90e2961614fdb47360dec1af538b5e23`.
The original66d808… test and its RED are not retrospectively relabeled this hash.

Only the two approved functions in `test_clinical_availability_api.py` were
migrated. Original full-file SHA256:
`525bda82c69b3830e7c36b71e41468c47ebfe80785f019be014a5fe3e1ccc70e`.
Migrated full-file SHA256:
`678b8876b4081b512b89210ee9b46dbcd807402533aba3ea55bd37b5aa0bc7d0`.

- Four observation cases now call prepared capture/once-only commit; the old
  numerical fixture is explicitly SYNTHETIC/READY. Unknown retains the exact
  previous state/twin/observations/actions/availability while still DENY, unable
  to supply workspace physiology, listed with active:null, and cleaned up once.
  Confirmed success/cleanup still selects `tw=None` and publishes its own null-
  parameter snapshot. Original status/version/empty-observation assertions remain.
- Five reconciliation cases now require checked capture under authority and pass
  that exact token to final confirmation with the same UUID. The authored absent
  reference returns dictionary parameters. The snapshot stub consumes/asserts
  its own explicit argument; original success/failure/no-reselect/repeated-POST
  assertions remain. No real checked registry is constructed by either fixture.

The exact postimplementation95-case selection is the new file plus these five
node IDs from the existing file; substitute only this list in the wrapper above:

```text
livemorebio/tests/test_committed_observation_reconciliation_publication.py
livemorebio/tests/test_clinical_availability_api.py::test_observation_selection_commit_installs_coherent_source_or_explicit_uncertainty
livemorebio/tests/test_clinical_availability_api.py::test_selection_reconciliation_uses_audited_authority_and_never_reselects
livemorebio/tests/test_clinical_availability_api.py::test_observation_selection_rejects_coercion_and_extra_fields_before_read
livemorebio/tests/test_clinical_availability_api.py::test_selection_bounded_strict_json_before_registry
livemorebio/tests/test_clinical_availability_api.py::test_selection_auth_precedes_registry_read
```

The nine migrated cases and stronger liveness assertion are unrun at this freeze;
root's producer implementation and independent review must exercise them. No
other existing test function, runtime file, service, cache or operational record
was edited by this author. This is a frozen test handoff, not implementation
acceptance or permission to expand collection beyond the approved packet.

## Root route implementation and maker GREEN

Root read all1035 original test lines (including the pre-RED cleanup-wire fix),
the approved actions-liveness precision, the complete receipt, and both migrated
legacy functions before the preservation repeat. The client's prior87-case
producer repeat had finished at servercedcf801 before root modified the server.
Only select_twin_observations and reconcile_twin_selection changed in server.py.
Frozen new server SHA256:
`878e585552d12de5fc4cc8e5381bec5a2874565ae3bdd5b496418e7e46875625`.

Observation selection captures the prior generation and full prepared active
identity together, prepares a modeless snapshot outside all guards, validates
the whole finite-JSON snapshot and wire response, and commits the prepared
transition once. Confirmed replacement installs the new state; unknown commit
installs DENY while retaining exact previous inspection holders. Both invalidate
only the captured prior generation after guard exit. Own-snapshot publication and
retirement happen outside guards; cleanup failure cannot erase confirmed identity.

Reconciliation captures the checked immutable storage snapshot under authority
with both state and actions strongly retained. Final confirmation requires DENY
and the same captured state object, preventing the local ABA race. Candidate or
modeless projection and full JSON validation precede the final checked read;
true checked absence alone may use the existing healthy reference constructor.
No old execution stop, restart, cleanup acknowledgment or clinical mutation is
introduced. All local errors use fixed safe messages and the current UUID.

Maker runs used the existing45-second private ASGI refusal wrapper from the
preparation-status packet, with safe inherited PATH/HOME/TMPDIR/LANG/LC_ALL only,
both numerical constructors forbidden and no plugin/cache/bytecode artifacts:

| Selection | Result | Private root suffix | I/O receipt |
|---|---|---|---|
| New78 at test31d9e40e | 78passed,3existing warnings,1.97s,exit0 | fk05mkdo | unexpected0,Git refused1 |
| Exact95 plus distinct192 preservation, no duplicate collection | 287passed,3existing warnings,3.99s,exit0 | impx2ozt | unexpected0,Git refused1 |

The exact commands are retained in the main tool store as
observation_reconcile_78_tests, observation_reconcile_95_tests and
observation_reconcile_287_tests. To reproduce287 from the written wrapper above,
use the six95-case paths already listed, then append the seven existing paths:

```text
livemorebio/tests/test_committed_source_transitions.py
livemorebio/tests/test_legacy_transition_admission.py
livemorebio/tests/test_confirmed_binding_publication.py
livemorebio/tests/test_checked_binding_registry_integration.py
livemorebio/tests/test_confirmed_preview_publication.py
livemorebio/tests/test_committed_preview_transitions.py
livemorebio/tests/test_source_retirement_lock_boundary.py
```

No test process remains. These are maker route results, not independent grading,
actual observation/reconciliation encrypted-registry integration or rendered UI
acceptance. The independently owned subjects.py fourth-kind implementation is
still being reviewed in its separate registry packet. The current source is
frozen for maker-external review before any actual-browser or native workflow.

## Independent route review and retained repeat

The independent reviewer read the complete approved publication plan/addendum,
both changed root-authored routes, the full final78-case source and the existing
UI/SDK acknowledgment consumers. The review applied the full local review skill
and checklist within the explicitly read-only scope: no fetch, autofix, release
operation or operational store access. This grades root's two route methods, not
the reviewer's own test authorship or the entire inherited server file.

Before and after the repeat, the frozen SHA256 values were unchanged:

| File | SHA256 |
|---|---|
| `livemorebio/aegle/server.py` | `878e585552d12de5fc4cc8e5381bec5a2874565ae3bdd5b496418e7e46875625` |
| `test_committed_observation_reconciliation_publication.py` | `31d9e40eeb227c1cd6287cb5aa49f6bc90e2961614fdb47360dec1af538b5e23` |
| `test_clinical_availability_api.py` | `678b8876b4081b512b89210ee9b46dbcd807402533aba3ea55bd37b5aa0bc7d0` |
| Frozen registry dependency `subjects.py` | `b5306edc2045fd98e943f9fefc124872996563c3c955fece4ec7aebb718d6441` |

The first independent invocation used private root suffix `cw8e6_m5`, session
45235. Its process ended, but the combined source-read/poll tool output exceeded
the context budget and its final receipt was not retrieved. Record that run as
**OUTCOME_NOT_RETRIEVED**, not PASS or FAIL. A subsequent poll confirmed that the
session was closed. Root explicitly authorized one identical receipt-only repeat;
no source, test, fixture, wrapper or selected case was changed.

The authorized repeat used the exact written45-second wrapper and287-case list
above, pinned Python3.11.15, a fresh private environment ending `s7d2d6x1`, and
session9313. Its final output was retained separately:

```text
287 passed, 3 warnings in 4.04s
REVIEW_IO_COUNTS 0 1
exit 0
```

The warnings are the same existing TestClient/HTTPX and startup-on_event
deprecations. Low-level socket/DNS/connect/listener, urllib and child/native
refusals stayed installed; both numerical constructors and compilation were
forbidden. The internal TestClient socketpair remained available. Unexpected
I/O was zero; one exact optional Git-metadata child was refused, not executed.
No test process remains. No browser, service, lifespan startup, model execution,
real HTTP, operational database or registry construction was used.

No actionable finding remains in this bounded route packet. The source review
confirmed whole detached snapshot and response serialization before final
ownership, preparation failure without invented mutation uncertainty, exact
unknown-outcome DENY with prior inspection holders retained, captured-generation
cleanup outside guards, checked reconciliation plus the captured-state ABA fence,
same-operation UUID/no-store responses, and outside-lock own-snapshot publication
and holder retirement. True checked absence retains the existing reference mode;
an unresolved actual person remains explicitly modeless. Reconciliation neither
acknowledges nor reopens prior cleanup ownership.

This is independent **inert ASGI route clearance only**. The registry packet is a
different maker's separate review; actual encrypted-registry-to-route integration,
rendered client/terminal recovery, and the larger product/Atlas/scientific gates
remain open. The successful receipt does not overwrite the earlier missing
receipt or the original72FAIL/6PASS RED history.
