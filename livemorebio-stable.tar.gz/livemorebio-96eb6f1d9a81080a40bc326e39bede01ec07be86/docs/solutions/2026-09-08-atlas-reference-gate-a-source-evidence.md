# Atlas Gate A: BodyParts3D source and coordinate evidence

Date: 2026-09-08. Parent: `2026-09-08-whole-person-atlas-native-context-subplan.md`.
Status: **source investigation complete with explicit concerns; candidate only, not admitted or rendered**. Root approved this read-only investigation after reading the parent plan and viewing approved A+B. No package, service, patient, experiment or cache content was changed. Public source files were read from the isolated review cache and independently downloaded into a separate temporary research directory.

## Recommendation

BodyParts3D release 4.0 provides a source-authored whole-person surface and organ components with documented common coordinates. It is a viable **REFERENCE_ONLY adult-male anatomical reference** for a dedicated Atlas renderer. It is not a patient scan, complete anatomy, a biomechanical model or evidence that a twin functions like a human.

Proceed to independent source/manifest review, then a separately authorized coordinate-preserving conversion/rendering packet. Do not activate the candidate just because this investigation produced a manifest. Keep biological quantities and spatial fields separate as in the parent plan.

## Primary sources inspected

The `/browse` skill was read completely and used in a private source-only browser session. These are publisher/source pages, not third-party summaries:

1. [Archive description](https://dbarchive.biosciencedbc.jp/en/bodyparts3d/desc.html): identifies an adult-human-male whole-body anatomical reference.
2. [Current archive license](https://dbarchive.biosciencedbc.jp/en/bodyparts3d/lic.html), updated 2025-02-27: specifies CC BY 4.0 and an attribution notice. [Update history](https://dbarchive.biosciencedbc.jp/en/bodyparts3d/update.html) records the license update and release-4.0 archive update on 2013-06-19.
3. [Dated release directory](https://dbarchive.biosciencedbc.jp/data/bodyparts3d/20130619/), [release note](https://dbarchive.biosciencedbc.jp/data/bodyparts3d/20130619/release_4.0_e.html) and [coordinate diagram](https://dbarchive.biosciencedbc.jp/data/bodyparts3d/20130619/coordinate_system.png). The release note is dated 2013-05-16, distinct from the archive publication date.
4. [Archive README](https://dbarchive.biosciencedbc.jp/data/bodyparts3d/20130619/README_e.html) explains FMA concept versus representation versus elemental OBJ identity, and the IS-A/PART-OF compound membership files. [Mesh description](https://dbarchive.biosciencedbc.jp/en/bodyparts3d/data-7.html) names the 99% polygon-reduction dataset and 2,234 entries.
5. [Creator documentation](https://lifesciencedb.jp/bp3d/info_en/index.html) warns that reference parts may be artist-created or adjusted, concept representations may be incomplete or erroneous, and different major coordinate versions must not be silently combined.
6. [CC BY 4.0 legal code](https://creativecommons.org/licenses/by/4.0/legalcode.en) was read for attribution, modification notices, downstream restrictions, non-endorsement and warranty boundaries. This is a technical source-admission recommendation, not legal counsel's clearance of a pharmaceutical deployment.

## Frozen source identity

The dated archive URL was downloaded independently and its complete SHA-256 matched the existing isolated cache. The dated IS-A map also matched the cached map. Do not rely on the mutable `LATEST` path for the new manifest.

| Artifact | Bytes / identity | SHA-256 |
|---|---|---|
| `20130619/isa_BP3D_4.0_obj_99.zip` | 142,903,898 bytes; release 4.0 | `40665852c49f218326590e204db91064a1ecfc3c6f8cbd7bbbcaac62c7cd409e` |
| `20130619/isa_element_parts.txt` | 2,905 concepts; 29,549 concept-element rows | `a3de74423f943b0d724ae8f59b3a817f87c423a544f8db98113b1980817cbeaf` |
| `20130619/partof_element_parts.txt` | 651,179 bytes; 1,368 concepts; 17,943 rows | `3f5f6df1028eb122b30de77c711597b6bb8e5541658e5985859fd228adbf88ea` |
| `20130619/isa_parts_list_e.txt` | 128,086 bytes | `ab7796deedd49205e77f3609a1cb8c53e2bbee14ecb5c9a6ca05227469780513` |
| `20130619/isa_inclusion_relation_list.txt` | 207,664 bytes | `26e7d818e03a8c909fe09c561f38d0d513423c87681f9450a803bc38f5b07564` |
| `20130619/coordinate_system.png` | Publisher coordinate diagram | `338736275c11eac8c89531fdc14193c9a8adf5baab674033d9d89259f152a5f6` |
| `20130619/release_4.0_e.html` | Retrieved release note | `771bd30a47ab11396eb6333e73a946426093c57fa4d4a1db8f718910fea7d985` |
| `20130619/README_e.html` | Retrieved 2025-updated README | `f9a90b4d945ad0fe50db45c712e931aa54e52667187b30d7085b6cc394f40107` |
| Current `en/bodyparts3d/lic.html` | Retrieved current license page | `03647628a93d935c2f7d2e48f1ffc935b14e175707311098ebaae4d6fa439759` |

Page hashes identify this retrieval, not permanent URL immutability. The archive has 2,234 OBJ members and no other members, 479,605,380 uncompressed bytes, 4,209,773 vertices and 6,681,030 triangular faces. No nonfinite vertices or out-of-range/zero face indices were found in all 2,234 files. These are raw source counts, not measured GLB, GPU-memory or frame-rate claims. Before/after hashes of the existing isolated archive and map remained unchanged.

## Coordinates: backed, with one documented discrepancy

Publisher diagram and per-file `Bounds(mm)` agree on millimeters. The diagram states +X is anatomical left, +Y posterior, +Z superior, with the centerline approximately along Z. The release note says skeletal and organ coordinates were changed together for release 4.0. All 489 proposed initial components have an explicit compatibility-4.0 header.

Preserve those vertices. A proposed single root conversion into a right-handed, Y-up meter-based scene is `(x, y, z) mm → (0.001x, 0.001z, -0.001y) m`. This is a unit/axis conversion for the entire assembly, not patient registration. It has not been applied. Do not separately center, fit or spread organs. Camera centering is not a mesh transform.

The diagram's statement that all Z values are positive is **not true for the supplied release-4.0 vertices**: skin extends to Z = -78.1112 mm. Keep the actual source origin and discrepancy, do not clip negatives or move individual feet to match the diagram. Left kidney has X bounds 32.8399 to 90.383 mm; right kidney -87.5754 to -30.4276 mm, consistent with the documented left/right axis. The proposed core's aggregate bounding box lies within skin's box; that is only a bounding-box check, not a watertight enclosure or anatomical landmark validation.

## Exact candidate components and budgets

The machine-readable **proposal**, `2026-09-08-atlas-reference-gate-a-candidate.json`, contains every initial element ID, archive member name, byte hash/size, concept/representation header, vertex/face count and native bounds. It explicitly has `PROPOSED_NOT_ADMITTED`, no converted asset/hash, and `patient_registered:false`. Each group's sorted-ID digest is reproducible from the frozen source map; the digest convention is in that JSON.

| Initial reference group | Mapping root | Elements | Triangles | Raw OBJ bytes |
|---|---|---:|---:|---:|
| Whole-person skin surface | IS-A `FMA7163`, `FJ2810`, `BP9115` | 1 | 203,382 | 14,465,502 |
| Heart components | PART-OF `FMA7088` | 83 | 102,802 | 6,822,515 |
| Liver components | PART-OF `FMA7197` | 60 | 191,622 | 12,935,351 |
| Pancreas components | PART-OF `FMA7198` | 4 | 16,962 | 1,325,384 |
| Right kidney | PART-OF `FMA7204`, `FJ3147` | 1 | 2,310 | 139,395 |
| Left kidney | PART-OF `FMA7205`, `FJ3145` | 1 | 2,982 | 182,275 |
| Right lung components | PART-OF `FMA7309` | 156 | 73,312 | 4,754,472 |
| Left lung components | PART-OF `FMA7310` | 124 | 41,438 | 2,660,353 |
| Brain components | PART-OF `FMA50801` | 59 | 322,262 | 21,659,135 |
| Deduplicated surface + core union | Exact proposal members | **489** | **957,072** | **64,944,382** |

Skin source-byte SHA-256 is `682f402206f15592acdeaae8ffb6b34c3e5c3267fa4685e63d2e4920ef2a80e0`. Its vertex bounds are `[-334.119, -246.783, -78.1112]` to `[332.825, 45.2476, 1641.36]` mm. This is a complete-height source surface, not proof that the mesh has no holes or represents any particular user's body. Pancreas membership is exactly `FJ1895` (pancreas), `FJ1896` (pancreatic duct), `FJ2629` (parenchyma), `FJ2630` (duct tree). Overlapping compound memberships must be rendered once by element identity and remain distinct ontology memberships.

Additional same-archive layers are available but require separate coverage and component review:

| Layer | Frozen map root | Elements | Triangles | Raw OBJ bytes | Concern |
|---|---|---:|---:|---:|---|
| Bone organs | IS-A `FMA5018` | 203 | 505,532 | 33,328,421 | Prefer this declared grouping over claiming the incomplete PART-OF skeleton is complete. |
| Muscle organs | IS-A `FMA5022` | 323 | 2,086,974 | 163,859,896 | Eight included files have blank version/name/concept headers. |
| Arteries | IS-A `FMA50720` | 562 | 750,450 | 48,734,799 | Three included files have blank version/name/concept headers. |
| Veins | IS-A `FMA50723` | 342 | 785,804 | 50,869,864 | Headers present; representation completeness still not established. |
| Aorta | PART-OF `FMA3734` | 5 | 10,188 | 639,228 | Exact elements `FJ1931,FJ1932,FJ3411,FJ3413,FJ3427`. |

The surface/core/bone/muscle/artery/vein union is 1,648 elements and 4,950,146 triangles. Do not load every layer eagerly or infer mobile readiness from these counts. Initial surface-first loading and explicitly pending internal layers can retain an intact person, but GPU frame time, memory, transparency ordering, draw calls, interaction and actual rendering still need measurement. Source-authorized 99%-reduction geometry is already reduced; no extra silent decimation is proposed.

## Coverage and source-integrity concerns

- All IS-A and PART-OF map element IDs exist in this one archive. This means map-to-file resolution works, not that every anatomical concept is covered.
- PART-OF `FMA20394` human body contains 1,258 elements, while the archive has 2,234. PART-OF `FMA23881` skeletal system contains only 138 elements with Z minimum 751.951 mm, omitting lower-limb extent. The creator explicitly explains incomplete compound representations. Do not use those labels as completeness certificates or silently infer missing relations.
- Seventeen archive OBJ files have blank compatibility, representation, concept and name headers: `FJ1450,FJ1451,FJ1454,FJ1455,FJ1465,FJ1525,FJ1543,FJ1547,FJ1548,FJ1549,FJ1550,FJ1552,FJ1553,FJ1656,FJ1664,FJ1665,FJ1719`. None is in the initial 489-member proposal. Some still occur in compound maps. Their membership in the release archive is known; their missing local metadata must remain visible, not manufactured.
- The creator describes artist-authored or adjusted morphology and warns against canonical accuracy claims. Existing `anatomy/meshes.py` prose that excludes all artist-created/approximated geometry is unsupported for BP3D and must be corrected in a separately authorized source/documentation patch. Frozen runtime code was not changed in this investigation.
- Adult-male reference identity is source-described. No ethnicity, measured health status, disease-free status, patient registration, exact posture category, scan acquisition protocol or demographic personalization was inferred.
- No tissue mechanics, flow, membrane trajectory, molecular coordinates or drug-reaction field is contained in these OBJ files. Native numerical series remain separately sourced; a visualization cannot manufacture those missing fields.

## License record and shipping obligations

The current publisher archive page licenses this database under CC BY 4.0 and requests: “BodyParts3D, © The Database Center for Life Science licensed under CC Attribution 4.0 International”. Preserve source attribution, license link, changes/conversion notice, warranty limitations and non-endorsement in the manifest and accessible UI/export notices. Do not impose downstream restrictions on the licensed geometry that contradict its license.

The old OBJ headers contain CC BY-SA 2.1 Japan notices; creator documentation still names that older license. The 2025 README prose names BY 4.0 but its generic license hyperlink still points at the old BY-SA page. Preserve all historical notices and link the current explicit archive license plus update date. Do not silently erase historical provenance or infer from old code that the current source requires share-alike for the application. The release owner should explicitly record the selected current license basis before public geometry redistribution. No external contact or license purchase was performed.

## Manifest admission proposal

The eventual admitted `livemore.atlas-reference.v1` should bind:

1. Dated archive URL, exact source hash/size and release; separately hashed map, coordinate and license evidence.
2. Element identities and content hashes, deduplicated geometry plus multiple declared ontology memberships; explicit excluded/unresolved components and completeness state.
3. Source-authored adult-male reference class, millimeter/native axes, one root conversion, unmodified native bounds, and `patient_registered:false`.
4. Converter code/version and deterministic options, output node mapping, GLB hash/size, tolerances for documented float32 encoding, and round-trip landmark/vertex checks. Do not call numeric container conversion mathematically lossless without testing the representational precision.
5. Current publisher license basis and retained historical notices; no endorsement or clinical-accuracy claim.
6. Asset readiness distinct from renderer readiness, source registration checks and physiological qualification. Missing source/GPU support keeps the specific state unavailable, not replaced by unrelated geometry.

The proposed route shapes remain those approved in principle by root. Root owns `server.py`; no routes or cache installers were added here. An installer may download only the fixed hash-pinned archive/manifest, never arbitrary user URLs. Existing private-cache atomic publication and bounded archive safety require independent review in the implementation packet.

## Remaining Gate A acceptance

Before geometry activation: independent verification of the candidate JSON against frozen source bytes/maps; release-owner license-basis decision; exact visual layering/defaults and measured conversion plan; red tests for coordinate/member/source identity and unsafe input. After authorized conversion: real front/side/back anatomical landmark inspection, source-native versus GLB comparison, wireframe/topology checks where relevant, and actual rendered performance/interaction. A bounding-box check or source diagram is not a rendered-product pass.

Source-browser evidence (not product QA): `/tmp/livemore-bp3d-review.vqpHeK/source-coordinate.png` and `source-license.png`, both visually inspected. Independent source copies and frozen-source audit inputs are in that same private temporary directory. No source rows are patient records.

## Operational lesson

Root independently read this report, the publisher's current license page,
release note and coordinate diagram. The independent release reviewer checked
all 489 candidate elements against the archive, all nine group sets/digests,
all 2,234 files' counts/valid indices, the 17 excluded blank headers and nine
source/evidence hashes; no material mismatch was found. Source facts are accepted
for the next conversion packet, not as rendered or physiological acceptance.
The archive includes IDs with an `M` suffix outside the selected set; future
parsers must follow actual source identity rather than assume digits only.

Root selects the explicit current publisher CC BY 4.0 basis for isolated feature
development, retaining historical BY-SA notices and attribution without claiming
legal clearance for all pharmaceutical uses. Public release remains separately
gated. The exact coordinate-preserving conversion, cache, layering, numerical
precision and rendered-landmark plan must be reviewed before implementation.

The gstack source CLI's detached server exits after its CLI parent disappears; use an owned persistent server for multiple research calls. Its `download` command crashed on the publisher's relative redirect for a text attachment. After reproducing the cause, the tool was not patched or retried indefinitely: primary pages stayed in `/browse`, and explicitly identified data URLs were downloaded as read-only source artifacts with bounded `curl`, then hashed. Never touch root's QA browser state or work around a source failure by importing a different anatomical version.
