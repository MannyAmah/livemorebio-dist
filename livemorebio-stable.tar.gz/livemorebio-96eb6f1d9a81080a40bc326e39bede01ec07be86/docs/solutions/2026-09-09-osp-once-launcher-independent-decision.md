# Independent private OSP launcher decision

2026-09-09. Root independently read the complete frozen231-line launcher,
319-line inert test file,19-line refusal wrapper and149-line maker report.
Verified launcher SHA256
`bb03511e1f4a89bb878aa807083869ebd75f692c7a1cc266b5c8a45397eb9de5`
and tests SHA256
`771e45489b083f08f8918dc8ca0d3901a361f65f715d78e2c76d9baae1d4ec1c`.

Independent exact inert repeat:45 passed in0.29s, completion79334e exit0,
private review3udapvyb, unexpected I/O0. No native module, process or network
was invoked by those tests. The original22/3/2 RED failures and intermediate
fixes remain preserved in the maker packet. No scientific pass is inferred.

The minimal wrapper is accepted only for its proposed authorization/readback/
completion boundary. Root also reread unchanged `run_packet`: it verifies its
inventory before creating a packet tree, stops on the first unexpected case,
and preserves all later cases as NOT_RUN. Final identity checking now runs
on unsuccessful as well as successful calls, without replacing primary evidence.

## Separate once-only actual decision

Authorize exactly one invocation of the hash-bound command in
`2026-09-09-osp-once-launcher-implementation-review.md`, using the fresh0700
control root `/private/tmp/livemore-osp-native-once.CA533x` and exact pinned
Python interpreter. Root may create only its exact canonical authorization
object before that invocation. The launcher creates its own exclusive once
marker; it is never removed or reset. No preliminary R/CLR probe, retry,
new tolerance, supervisor edit or alternate collector is authorized.

The fixed S01–S17 technical cases,16 prescribed Run calls,600s packet bound,
30s worker bound and first-failure stop remain unchanged. All on-disk execution
gates remain false. Only this process changes its two in-memory technical
gates for this one call and restores them. This checks retained software bytes;
native source attestation stays UNVERIFIED and historical runtime UNKNOWN.
Model admission stays false. It is not an insulin/GIM experiment, human-equivalence
claim, or completion of any of the six requested recordings.

After execution, retain the original packet and terminal completion, independently
inspect raw failure or successful-case evidence, and check exact owned process
identities. A failed or missing receipt does not authorize automatic repair and
rerun. No installed product, operational store, real participant, patch or
publication is involved. This document records a prospective decision, not a
result; the actual outcome must be appended separately.

## Actual outcome, preserved failure

The exact authorized command was consumed once: completion51d74d exit1. The
launcher reported FAILED/PACKET_REJECTED, with final source preservation
CONFIRMED and no secondary evidence errors. Its separate elapsed-before-completion
was0.9386914169881493s; the raw packet's earlier elapsed was0.9270700829802081s.
No success is inferred from this early terminal.

Original returned packet:
`/private/tmp/livemore-osp-native-once.CA533x/tmp/livemore-osp-semantic-n6yhhp1f/result.json`,
SHA256 `9ddea114d4a1732c8548812848e86da685dfa61714e4ac9b5b52f404fc55c808`.
S01 stopped with primary UNEXPECTED_DESCENDANT. Its secondary evidence codes
are PROCESS_ARGUMENTS and PROCESS_FAILED. S02–S17 remain NOT_RUN; no barrier,
comparison, native image admission or scientific observation was recorded.
Both original worker streams reached EOF with zero bytes. Only the leader's
identity was retained in process observations; the rejected candidate's exact
identity is not in that record. Do not infer which child caused rejection.

The worker receipt records TERM, exit-15, no KILL, cleanup SETTLED and group
empty before reap. Unresolved-child is false. Root's separate exact check of
parent38444 and recorded leader38453 returned no rows, exit1/completion401301.
This checks those two recorded PIDs only, not an invented complete child trace.

All consumed files and the exclusive marker remain intact. Read-only diagnosis
is in progress. No automatic adjustment, retry, native gate expansion or
model admission follows from this failure.

Root's separate data-only receipt verification passed (431373 exit0): outer
packet hash, exact embedded S01 result equality,16 subsequent NOT_RUN rows,
both empty EOF stream hashes, admission identity/limits/order and canonical
authorization/once-object equality. Completion SHA256 is
`676bb4d83299f22561d5a57d7c253586e98c88e60780f0498bb02c37616fc78b`.
This verifies the retained failed result, not technical or biological success.
