# Analysis export cancellation: separate delivery from browser tooling

Root observed three immediate agent-browser download cancellations for the same
Human-GEM notebook/CSV links. Stop repeating that action. Read-only route/source
inspection plus a different bounded authenticated loopback GET path returned
HTTP 200 and exact full attachments on the first attempt. The actual exports,
source/result hashes, response headers, notebook-cell inspection and limitations
are in the [retained export receipt](../deliverables/2026-09-09-workflows/human-gem-qa-export-receipt.md).

No product change is warranted from this evidence. The product export API works
for this exact run; the failing automation/browser delivery path is not fully
diagnosed or browser-qualified. Do not erase the three failed interactions or
call the alternate fetch a successful browser click. Future notebook execution
must preserve the original attachment and write a separate executed artifact.

Lesson: when a download tool cancels before useful network evidence, distinguish
the click/transfer layer from authenticated response generation. Preserve exact
response bytes and compare embedded result identity before reanalysis. Keep auth
in memory and public scientific references separate from patient-bearing exports.
The investigation skill was used; CE/gbrain were not callable, so this lesson is
recorded directly. No browser, model, experiment, or registry mutation was run.
