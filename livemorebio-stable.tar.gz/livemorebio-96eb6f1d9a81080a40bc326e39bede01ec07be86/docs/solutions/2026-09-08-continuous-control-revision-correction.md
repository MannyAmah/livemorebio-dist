# Continuous lifecycle control revision correction

Parent: full-scope recovery R04/R27/R29/R45/R47/R48. Status: written before
implementation; independent engineering review required. No biological model,
source, frame value, calibration, clock, installed service, or old store changes.

## Actual browser failure

The current-source 8910 browser attempt delivered two engine-authored frames
through LIFE and received Aegle acknowledgments. Pause LIFE then returned 409.
The browser held session revision 21; delivery/polling advances that revision
several times per frame, including updates that contain no new frame. The UI
therefore cannot reliably issue a normal lifecycle action from displayed state.
The failed receipt and screenshots remain under continuous/attempt-1; both owned
sessions were explicitly stopped. The 1,630-pass broad test result did not detect
this real interaction failure and is not final acceptance.

## Decision

Retain the existing strict `revision` for durable record writes, sample-order
fences, internal in-flight work and legacy API callers. Add an independent,
persisted `control_revision` for user lifecycle decisions. Never solve this by
automatic POST replay, ignoring conflicts, or a hidden read-and-retry loop.

1. Both encrypted record types initialize `control_revision=1`. Reading an old
   record projects its existing revision as the initial control revision; the
   next existing write persists that value. No bulk migration, delete, history
   rewrite, new plaintext physiological columns, or source-hash alteration.
2. Producer control revision advances for effective lifecycle state, source
   validity, failure or consumer-binding changes, not checkpoint/frame commits
   or lease renewal. Preserve internal whole-record revision fencing. A
   completion, restart, source invalidation, consumer expiry or pause/resume
   cycle invalidates stale control intent (including ABA).
3. LIFE control revision advances for effective lifecycle/error/lease-binding
   changes. `waiting_for_engine` and `streaming` are the same active control
   phase, so normal acquisition cannot invalidate a Pause click. Paused,
   blocked, interrupted, stopped and completed remain distinct phases. Normal
   producer-status refresh, pending/receipt/ACK writes do not change control
   revision. No-op writes do not increment it. A lifecycle decision crossing an
   I/O gap must fence any late delivery result and cannot be overwritten by the
   old worker's catch path; explicit recovery failures still report blocked.
   An accepted resume reserves a control epoch before source I/O, even while
   durable state remains paused. A Pause that cancels this pending resume is a
   real control event and also advances the epoch. "No-op" above refers to
   background metadata writes, not accepted lifecycle decisions. An internal
   store-only `control_event` flag is strictly boolean and never accepted from
   a request or arbitrary changes dictionary.
4. Control methods/routes accept exactly one of `expected_revision` (legacy)
   or `expected_control_revision` (new). Producer operations still require
   exact source generation. Under the existing manager lock, compare the chosen
   revision and then execute the transition using the current durable revision.
   Wrong type, boolean, missing/both fields, stale lifecycle, wrong owner and
   wrong source remain rejected. Stop retains the existing ability to stop its
   own fenced source without permitting resume on another source.
5. Public statuses expose both revisions. UI lifecycle buttons use the control
   revision they actually displayed, with no automatic retry. Readouts separate
   sample and control revisions. LIFE-to-producer explicit pause uses the same
   control guard after exact source verification; no unguarded cancellation.
6. Attached CLI/SDK get the same explicit choice: `control_revision=` versus
   existing `revision=`. Preserve old arguments/strict conflict behavior; no
   inferred freshest revision or automatic command retry. Keep confirmation,
   source identity and PHI-safe output rules. Source/consumer binding and
   checkpoint fork continue using their existing exact-record guards.

## Red-first acceptance

- Read displayed status, commit multiple genuine technical frame/receipt
  updates, then pause with displayed control revision: succeeds; legacy record
  revision still conflicts. No frame advances after accepted pause.
- Pause/resume/stop or failure/recovery in between invalidates the earlier
  control revision, even when state returns to running/streaming.
- Unit/API/CLI/UI strict one-guard parsing, booleans, wrong generation, ownership,
  process restart, source invalidation, lease expiry and completion boundaries.
- Late native callback or LIFE HTTP callback cannot commit into a newer
  lifecycle decision or replace an explicit pause/stop with a worker error.
- Preserve existing encrypted payload quota, frame hash chain, immutable
  receipt, no-replay, audit, native state and source-selection tests.
- Independent review before restarting only owned8910. Rerun actual browser
  preparation→binding→stream→pause→resume→hidden→Biology→mobile; save a new
  attempt directory, never overwrite failure evidence. Rerun broad regressions.

## Ownership

Root coordinates/reviews and owns API route integration and durable plan.
Backend maker may own only the two stores/managers, the typed source-client
pause method, and dedicated control revision tests after review. UI/CLI owner
may own only console controls, attached client/command parser and their tests
after receiving the exact contract. No concurrent edits to shared files. Native
Beard source/technical-worker work remains an independent lane.

## Independent correction review and evidence

Root reviewed both stores, the engine and LIFE control transitions, typed source
pause client, route changes and their red-first regression tests. The separate
UI/SDK maker independently reviewed the root-owned API integration. A final root
review found two additional defects: a newly accepted LIFE resume could overtake
an already-issued remote pause, and a failed control write retained a newly
claimed owner. Both reproduced before correction (three failures, two existing-
ownership preservation passes).

The fixed-peer pause request now remains under the local LIFE control lock after
the final epoch check. Its bounded Aegle endpoint has no LIFE callback. This
serializes local intent; it is not distributed atomicity or proof of remote
completion after a transport timeout. Failed writes release only newly acquired
ownership, preserve existing ownership and cancel renewal without a remote call.

Root independently ran nine store/manager/source/API/client suites: **249 passed,
three existing warnings, 7.29 seconds**. Separately, all 20 route tests passed,
including real engine and LIFE manager integration. The prior UI/client/harness
199-pass independent packet remains separate, with overlap not added into a
misleading unique total. This clears only this correction for isolated browser
retesting. Attempt 1 remains failed; no final browser or full-product pass yet.
