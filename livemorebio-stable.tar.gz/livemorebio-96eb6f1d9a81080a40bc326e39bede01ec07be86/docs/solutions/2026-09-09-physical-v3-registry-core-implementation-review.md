# Registered physical-v3 binding core — frozen maker packet

2026-09-09. Implements only the root-approved
[registry-core proposal](2026-09-09-physical-v3-registry-core-proposal.md), originally
169 lines/SHA `bb54b55e71815c049c2691ba3189793713de8a5e0e5674db02c139947f66c829`.
Root read the whole plan and approved red-first two-runtime-file implementation;
its approval was appended before test code. **Independent implementation grading
remains required.** No self-awarded release or physical authorization.

## Exact write set

| File | Frozen SHA256 |
| --- | --- |
| `livemorebio/aegle/subjects.py` | `b41b73a29f614239102b510f7b8b796095cc95055074390fb359b3b78af31628` |
| new `livemorebio/life_patch/physical_binding.py`, 184 lines | `5032f4af44048bf50224a71e64f58a5bbb31ab044c7efffa33e145bac8ee8a46` |
| new `livemorebio/tests/test_registered_physical_v3_binding.py`, 374 lines/28 cases | `192eeaa137a9063afc22db67e1228e63f2745150833d24d90fc3eff8913a51d3` |
| `test_committed_registry_transitions.py`, one approved protocol literal | `e2d9cef599eae098aa5454cbcdc2b195a91f53ca0381480af33705bdaf58bb04` |

Before this increment, subjects was
`b5306edc2045fd98e943f9fefc124872996563c3c955fece4ec7aebb718d6441`.
Registry audit remains
`b21f01fdf1c79604c5565fee0f7d94d3b0bd11967b199bc97ec8a193de045e4e`.
The existing 13-case test is unchanged at
`4e9b8a45ac614bc5db8f9134e7f152b9e1964a9c8b14c48c7190fc5437b01489`.
No server, gateway, protocol, journal, key loader, execution, observation, UI or
OSP supervisor bytes were changed by this lane. OSP remains `d2ac1bac…`.

## What is implemented, and what is not

The new internal preparation method validates the exact request/inspection
structure before storage. It requires a decoded provisioned physical manifest,
canonical hash, declared calibration/attestation references and bounded peer
identity fields. It retains a detached, discriminated normalized input in the
existing prepared binding JSON. The old public metadata parser cannot accept this
input and refuses new physical3.0 without inspection; v2 and virtual3.0 keep
their old path. No public route calls the new method yet.

The existing `bind` kind still owns admitted-real-person checks, ACTIVE pointer,
life_patch scope, unique device index, full current-row comparison, physical
audit, mutation and exact acknowledgment witness. Commit independently rebuilds
the entire after-record from the normalized request and inspection. No new SQL
table, audit scheme, fifth transition kind or framework was added.

The encrypted entry records complete canonical manifest, its redundant derived
identity/configuration/capabilities, original inspection, declaration references
and person/consent context. It explicitly remains PAIRING_RECORDED,
PENDING_SIGNED_ENVELOPE, OPERATOR_DECLARED and NOT_ESTABLISHED.

The actual registry `_open` checks structural integrity only for explicitly new
schema entries, recomputing manifest identity and redundant fields. It does not
require current ACTIVE status/consent to inspect a historical entry. The separate
pure record predicate checks selected-record-shaped REAL_HUMAN/ACTIVE metadata,
current life_patch scope/custody, exactly one binding and complete matching saved
identity. This is **not a current database selection/index check, not verification
of a fresh LIFE peer, and not consent authorization**. It performs no I/O and
does not sign a receipt. The future issuer must obtain an audited eligible-record
and device-index snapshot with final source confirmation; no new predicate
success may replace those guards.

The first packet covers every numbered row of the approved 28-case inventory.
Case26 was strengthened, after original RED but before runtime edits, with seven
lines proving an actually persisted corrupt new manifest is rejected by the real
getter without repairing its raw rows. Count stayed28. Original RED used the
367-line test SHA `a348ce956a57357661bf6f2e44e4e2d8216773bd0b447b39b670fec8d535a59c`;
the original earliest missing-method failure for that case is retained, not
claimed as an execution of its later unreachable added assertions.

## Original attempts and retained outcomes

All private roots are under
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-`.
Tool session/chunk receipts below are retained tool outputs, not invented JSON files.

| Attempt | Actual result | Receipt / private suffix |
| --- | --- | --- |
| First wrapper | 28 setup errors,1.56s;28 refused ctypes calls,Git1 | 61536 /224fca /fvjg3fix |
| Valid original RED | **27 failed,1 passed,2.02s**,I/O0,Git1 | 58716 /9f40f7 /t4um85ru |
| Core first green | **28 passed,2.13s**,I/O0,Git1 | 86726 /8a599c /eisaqb__ |
| Inherited fixture migration RED | **4 failed,1.19s**,I/O0,Git1 | 46881 /f70bec /rw7j7w_7 |
| Full registry preservation including new28 | **706 passed,4 deselected,1 existing warning,33.07s**,I/O0,Git1 | 57563 /0aa32d /z957r52w |
| Existing real-registry/API binding | **13 passed,3 existing warnings,2.23s**,I/O0,Git1 | 19462 /a28963 /ws_uuu81 |

The first attempt is a wrapper failure, **not product RED**. NumPy's ordinary
import through the existing compilation-refusal fixture initialized standard
`ctypes.PyDLL(None)` after the wrapper's new dlopen refusal was installed. Root
approved initializing stdlib ctypes with the other stdlib imports before the
refusal; all later dlopen/network/process refusals and constructor traps stayed.
No test assertion/runtime change was used to fix that invocation. Ordinary
NumPy/clinical module imports occur; no numerical constructor, clinical compiler,
solver call, OSP/R/CLR worker, device operation or operational store ran.

The valid RED exposes the missing preparation/predicate and the real old
metadata-only physical3 path reaching storage. The v2 preservation case already
passed. Each real commit fault delegates to the actual guarded connection:
known rollback, committed lost ACK, terminal witness corruption and close ACK
failure retain distinct outcomes. The raw damaged terminal remains damaged.
There is no power-loss/fsync or actual process-cleanup claim.

### Exact inherited migration, approved before editing

`physical_body()` at line92 is used by four dedicated cases (one the device
branch of a parameterization) and by the modeless physical branch of the existing
13-case API integration. These assert metadata pairing/index/audit/rollback
semantics, not registered lineage. After retaining all four new-policy failures,
root authorized changing **only** its `protocol_version` literal3.0→2.0.
No assertions changed, no physical gate was relaxed, and no other inherited
fixture was touched. The four cases are included in the final706, and the API
physical branch in the final13. New tests separately cover registered3 success,
metadata-only3 pre-storage refusal and unchanged historical3 reads.

## Exact protected foundation repeat

From `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os, sys, signal, socket, subprocess, urllib.request, multiprocessing.process, ctypes
from tools.run_review_stack import prepare_review_environment
root, env = prepare_review_environment(inherited={k: os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ})
os.environ.clear(); os.environ.update(env)
os.environ['PYTHONDONTWRITEBYTECODE']='1'; os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
blocked=[]; metadata=[]
def deny(*a, **k):
 blocked.append('unexpected'); raise AssertionError('Registry review forbids network and child/native work')
def process(command, *a, **k):
 if command == ['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  metadata.append('refused'); raise OSError('Authored unavailable Git metadata')
 return deny()
def audit(event, args):
 if event in {'os.fork','os.forkpty','os.posix_spawn','os.exec','subprocess.Popen','socket.__new__','socket.connect','socket.getaddrinfo','ctypes.dlopen'}: deny()
sys.addaudithook(audit); multiprocessing.process.BaseProcess.start=deny
socket.socket.connect=deny; socket.getaddrinfo=deny; socket.create_connection=deny
urllib.request.urlopen=deny; urllib.request.OpenerDirector.open=deny; subprocess.Popen=process
import pytest
signal.alarm(45)
print('PRIVATE_REVIEW_ROOT', root, flush=True)
rc=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(root/'pytest'),"-p","livemorebio.tests.test_committed_registry_transitions","livemorebio/tests/test_registered_physical_v3_binding.py","livemorebio/tests/test_observation_committed_registry.py","livemorebio/tests/test_checked_startup_selection.py","livemorebio/tests/test_committed_registry_transitions.py","livemorebio/tests/test_subject_registry_audit_contract.py","livemorebio/tests/test_registry_bootstrap_contract.py","livemorebio/tests/test_registry_bootstrap_shape.py","livemorebio/tests/test_clinical_descriptive_registry.py","livemorebio/tests/test_real_cohort_contract.py","livemorebio/tests/test_selection_reconciliation_registry.py","livemorebio/tests/test_subject_lifecycle.py::test_virtual_patch_binding_retains_admitted_protocol_version","livemorebio/tests/test_subject_lifecycle.py::test_only_authoritative_twin_remains_active","livemorebio/tests/test_subject_lifecycle.py::test_physical_patch_pairing_requires_active_consented_human_and_attestation","livemorebio/tests/test_subject_lifecycle.py::test_active_twin_survives_registry_restart_and_physical_device_cannot_double_pair","-k","not real_process",'--tb=short'])
print('REVIEW_IO_COUNTS',len(blocked),len(metadata));signal.alarm(0)
raise SystemExit(rc or bool(blocked))
PY
```

For the new28-only repeat, select only
`livemorebio/tests/test_registered_physical_v3_binding.py` and omit the global
plugin and real_process filter; its imported no-model fixture remains autouse.
The foundation's four real_process bootstrap tests are excluded, not passes.
Alarm45s bounds the process. All stores are authored under the private environment.

## Exact protected API preservation repeat

This separate approved wrapper allows TestClient's internal socketpair but
refuses bind/listen/connect/connect_ex/DNS/HTTP and all child/native launches:

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os, sys, signal, socket, subprocess, urllib.request, multiprocessing.process, ctypes
from tools.run_review_stack import prepare_review_environment
root, env = prepare_review_environment(inherited={k: os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ})
os.environ.clear(); os.environ.update(env)
os.environ['PYTHONDONTWRITEBYTECODE']='1'; os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
blocked=[]; metadata=[]
def deny(*a, **k):
 blocked.append('unexpected'); raise AssertionError('Registry review forbids network and child/native work')
def process(command, *a, **k):
 if command == ['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  metadata.append('refused'); raise OSError('Authored unavailable Git metadata')
 return deny()
def audit(event, args):
 if event in {'os.fork','os.forkpty','os.posix_spawn','os.exec','subprocess.Popen','socket.connect','socket.getaddrinfo','ctypes.dlopen'}: deny()
sys.addaudithook(audit); multiprocessing.process.BaseProcess.start=deny
socket.socket.connect=deny; socket.getaddrinfo=deny; socket.create_connection=deny
urllib.request.urlopen=deny; urllib.request.OpenerDirector.open=deny; subprocess.Popen=process
for name in ('bind','listen','connect_ex'): setattr(socket.socket,name,deny)
import pytest
class InertReview:
 @pytest.fixture(autouse=True)
 def no_models(self,monkeypatch):
  from livemorebio.tests.clinical_registry_fixtures import forbid_compilation
  from livemorebio.aegle.runtime import AegleTwin
  from livemorebio.engines.metabolic.glucose_insulin import MetabolicProfile
  forbid_compilation(monkeypatch)
  monkeypatch.setattr(AegleTwin,'__init__',deny);monkeypatch.setattr(MetabolicProfile,'__init__',deny)
signal.alarm(45)
print('PRIVATE_REVIEW_ROOT', root, flush=True)
rc=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(root/'pytest'),'livemorebio/tests/test_checked_binding_registry_integration.py','--tb=short'],plugins=[InertReview()])
print('REVIEW_IO_COUNTS',len(blocked),len(metadata));signal.alarm(0)
raise SystemExit(rc or bool(blocked))
PY
```

## Remaining gates / lesson

Fixed-peer registered inspection with real distinct gateway/physical-store
identities, two durable receipt-store roles, authorization reservations and TTL,
locked journal admission, immutable recovery metadata, durable final receipt,
fresh apply-time consent/source check and exact ACK before publication all remain
required and unimplemented here. No existing journal or public physical intake
path becomes newly authorized. Legacy stores are not migrated or repaired.
All R01–R51 and six scientific programs remain; software pairing proves neither
hardware nor calibration nor human biological equivalence.

Engineering-plan review focused this increment on the reusable existing commit
owner instead of introducing a second weaker transaction. CE/context7/gbrain
tools were unavailable in this session; no tool execution is falsely claimed.
No new third-party API was introduced: existing ManifestV3, registry/SQLite/AES
seams were read and reused. Compound lesson: make structural lineage immutable
and auditable, but never label that structural check as peer or consent authority.

## Independent root implementation grade

Root read the complete184-line pure module, all374 new test lines, actual registry
normalization/preparation/reconstruction/entry/read changes and this full report.
The private representation is unavailable through the public metadata parser;
commit reconstructs the complete after-record and relies on the original audited
read-set/index/commit witness. The one-line inherited fixture migration was read
and approved against its exact unchanged assertions before it was made.

Independent foundation repeat:706 passed,4 real_process cases explicitly excluded,
31.62s (10974/oblfgw_j), unexpected I/O0/refused Git1. Separate real-registry/API
repeat:13 passed1.77s (24113/bn5t135f), I/O0/refused Git1. Existing deprecation
warnings remain, not new failures or silently repaired library versions.
These clear only the bounded registered-binding core. No new public route,
physical telemetry path, calibration verification or human-use claim is enabled.

Root added four separate independent persisted-record probes in
`test_registered_physical_binding_review.py` (SHA1d0281fb1d63dcafc7f0b22b9fc54f09f0a919c702b9ef709006ece4d6f55599):
revoked scope keeps history readable but cannot satisfy the current predicate;
tampered redundant firmware/configuration/hardware-bool fields cannot hide behind
an unchanged canonical manifest. All four passed1.94s (4127/sstyqhk9), I/O0/Git1,
without repairing retained bytes. Runtime hashes remain b41b73a2…/5032f4af….
