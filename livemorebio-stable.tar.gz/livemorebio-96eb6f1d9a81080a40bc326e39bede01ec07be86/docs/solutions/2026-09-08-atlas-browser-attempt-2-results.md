# Atlas browser acceptance attempt 2 — retained failure

## Authority, identity and unchanged scope

Root authorized exactly one invocation of the independently reviewed acceptance
harness `tools/check_atlas_browser.cjs`, SHA256
`2913ffca546ea3b8a16d61f956a32923c63abb061de162fdf26d8a1a39b024cd`.
This was reference-anatomy rendering QA, not a biological experiment, human
validation, physical-device test or source installation. No runtime/package
files, services, source assets, subject records or experiments were changed.
No rerun was performed after failure.

The harness's fixed source and process fences were retained:

- URL: `http://127.0.0.1:8910/` (owned technical review stack).
- Runtime source: `c9fee6db135dfd338c2b793ac4c4f22936db3c692421f728196ecfd3693de47a`.
- Aegle instance: `28fbb877-f42f-49e3-8197-a00983093d8f`.
- LIFE instance: `4c4f352f-7fd3-43ae-bea3-e2573654d8c1`.
- Cendos instance: `89c2a9b6-0dc7-4a20-a594-721bdddb3324`.
- Technical twin: `twin-07bfab3bb80e4d869975e76c85bc6c5a`, version 8,
  `SYNTHETIC`, explicitly not a participant.
- Atlas manifest: `8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a`.
- Original installation receipt: `083b2f038e74476ebfcef07e4a22f7c2`.

No later source/subject integrity failure was reported. The final hard stop was
the request allowlist violation described below; the outer final package check
was not reached, so this report does not invent a successful post-run fence.

## Retained invocation and result

- Exec session: 59017, completed exit 1.
- Started: `2026-09-08T16:57:01.005Z`.
- Finished: `2026-09-08T16:59:58.685Z`.
- Duration: 177.680 seconds.
- New private output directory:
  `docs/screenshots/full-scope-recovery/atlas/attempt-2-FRpGPo/browser/`.
- Final receipt: `atlas-browser-evidence.json`.
- Receipt SHA256: `ee03891e48e1416ddc7a84a29a1435b8ce6aeaae9dfc00b5cdf7ca492846f69b`.
- Progress receipt: `atlas-browser-progress.json`.
- Screenshots retained: 42; all from the ordinary, unmodified product surface.

Of 56 preregistered cases, 28 had passing functional assertions, 3 failed, and
25 were explicitly NOT_RUN. Overall acceptance remains **FAILED**, with
`VISUAL_REVIEW_REQUIRED`. A passing control assertion is not independent visual
acceptance and does not establish scientific function.

### Exercised control coverage

Passing assertions cover intact whole-person reference view, front/side/back
camera controls, all nine layer toggles, source selection for skin/heart/
pancreas/both kidneys, isolation and return, labels, x/y/z section controls,
skin appearance, source search/provenance, mouse/keyboard input, and widths
1280, 768 and 390. Selection retained source element identifiers and hashes.
The original reference geometry was used; no scalar biological value warped
geometry or supplied a fabricated physiological motion.

### Failed cases

| Case | Retained outcome | What it establishes |
| --- | --- | --- |
| `warm-1440-1` | `PERFORMANCE_GATE_FAILED` | The unchanged warm criterion did not pass. |
| `browser-zoom-200` | `FUNCTIONAL_GATE_FAILED` | Actual 200% browser zoom was not demonstrated by the required viewport/DPR ratio checks. |
| `biology-linked-context` | `UNAUTHORIZED_REQUEST` | Navigation caused two cross-origin stylesheet GETs, correctly blocked by the same-origin request firewall. |

The warm receipt retains nine request events, seven marked failed and two
completed, callback-overlap maximum 3, no successful skin request-finished
timestamp, all-layer readiness 5802.545125 ms after first asset request, and
navigation-to-ready 11909.7595 ms. Full source geometry was visibly rendered,
but that does not replace the failed performance criterion. Prior diagnostic 1
separately recorded all nine unchanged application promises resolving exact
bytes with maximum application overlap 2; it did not establish the cause of
Chrome's `ERR_ABORTED` events. Those distinct observations remain distinct.

The zoom branch asserts before returning its `before`/`after` metadata; those
raw values are absent in this failed receipt. Do not infer an exact zoom level
or blame the product from the screenshot alone. Retaining those values before
assertion is a future harness evidence correction, not a reason to mark this
case passed or repeat the invocation without review.

### Exact linked-page request cause

The network receipt contains two `BLOCKED_UNAUTHORIZED_REQUEST` GET events,
followed by failures for `/css2` and
`/npm/molstar@4.4.0/build/viewer/molstar.css`. Source inspection of the unchanged
`livemorebio/aegle/console/biology.html` identifies:

- Line 7: Google Fonts stylesheet at `https://fonts.googleapis.com/css2`.
- Line 8: Molstar 4.4.0 stylesheet at
  `https://cdn.jsdelivr.net/npm/molstar@4.4.0/build/viewer/molstar.css`.

These are existing external dependencies in the ordinary Biology document,
not a clinical-data upload or a new experiment. The same-origin firewall must
not be silently broadened. The dynamic Molstar JavaScript source at line 382
is another external dependency, but this invocation did not request it; no
molecular-viewer acceptance is claimed.

Two console errors correspond to the blocked stylesheet loads; no JavaScript
page error was recorded. Other retained request-failure events (bootstrap,
stream and GLBs) are not silently counted as the same cause. A bounded,
reviewed same-origin dependency correction is needed before a linked-page
functional run can proceed under this policy.

## Required coverage still NOT_RUN

The hard stop prevented the remaining five warm trials, instrumented initial
load, desktop/mobile frame-budget tests, idle/native-hidden check, five
dispose/reopen cycles, and mobile touch/reduced-motion case. All 14 fault
cases remain NOT_RUN: missing, acquiring, skin failure, heart failure, delayed
heart, hidden load, navigation during load, tampered asset, vendor failure,
corrupt status, auth failure, WebGL context loss, unconfirmed installation
acknowledgment, and valid installation acknowledgment. In particular, the
390px installation-receipt overflow concern has not been exercised.

## Visual review observations, not established causes

Root personally inspected initial ordinary screenshots and found the intact
whole-person arrangement visibly distinct from the earlier exploded-organ
view. Independent review of the complete image set remains required.

Three observations require follow-up without altering source geometry:

1. Selected pancreas appears as alternating teal/beige triangles. Coplanar
   parent/child source overlap is a hypothesis, not an established cause.
2. A sticky header appears partway through some full-page captures after
   scrolling. A full-page capture artifact must be distinguished from actual
   viewport behavior before any product correction.
3. `labels.png` contains overlapping thoracic and abdominal labels that obscure
   organ names. The labels-toggle assertion is not label-usability acceptance.

Neither concern is waived by passing control assertions. Preserve the original
screenshots and source identities for any subsequent bounded investigation.

## Owned cleanup and lesson

The receipt records `OUTER_BROWSER_FINALLY_EXECUTED_IF_LAUNCHED`; the reviewed
owned-browser wrapper closes its browser in `finally`. Exec 59017 ended, and
a read-only process check at `2026-09-08T17:03:59.557Z` found no Atlas harness
process or Playwright Chrome temporary-profile process. No shared browser or
service was killed. No process command lines or credentials were emitted.

Lesson: functional readiness can be evaluated independently of a failed
performance measurement, but source/auth/cleanup failures remain hard stops.
Linked pages must be included in the dependency audit before an otherwise
same-origin feature is considered deployable. Preserve failed measurements
and NOT_RUN coverage rather than substituting visual plausibility for either.

No new browser execution, runtime edit or acceptance claim is authorized by
this record. Root retains grading and next-packet authorization.

## Root grading and coordinated implementation release

The independent reviewer reconciled all 56 cases, all 42 screenshot paths and
the receipt hash above. Root retains the overall failed result, three failed
gates, 25 NOT_RUN obligations and the visual defects. None is waived.

After collection, root independently re-read the protected build/services and
technical workspace. All three startup identities, the package fingerprint,
technical twin version 8 and context
`df9f87e2dc42fbc02edfa89b24c80c93bd72e8291773ea44364551fbb27817f9`
were unchanged. Root then stopped only the exact owned review wrapper PID 1633
and its children 1642–1644. Exec 32803 closed exit 0 with all three services
reporting completed shutdown. Old services, installed release and stores remain
untouched.

The c9 runtime measurement freeze is now released for the already reviewed
clinical-context implementation packet. This is an engineering sequencing
decision, not Atlas acceptance. No browser rerun is authorized here; a new
source-pinned run must retain and address these failed gates.

Disjoint ownership: source owner implements subjects, clinical-parameter
validation, immutable model contexts and encrypted registry audit; root
implements source authority, execution fencing and backend consumers; UI owner
implements the approved explicit availability, observation selection and compact
REAL cohort interfaces. Their red tests and the approved clinical amendment
remain the contracts. Atlas dependency/visual corrections need their own bounded
diagnosis and reviewed patch; no source-geometry alteration is authorized.

## Completed root inspection of the retained 42-image set

Root personally opened all 42 ordinary PNGs across the continuing review,
including every camera, nine layer-off views, nine section positions, three
opacity settings, selected elements, isolation, keyboard controls, labels,
responsive widths, long-name provenance, linked Biology and both failure images.
The final 15 images were inspected after the independent Cendos source review.
This completes the retained-image inspection only: the receipt still has
28 functional PASS, 3 FAIL and 25 NOT_RUN cases, and overall acceptance is FAILED.
No fresh browser, source install or experiment was run for this inspection.

Additional presentation findings to retain in the next bounded correction:

- The intact front/side/back person, native-position organ toggles and varying
  skin opacity are visibly different from the Biology exploded inspector.
  Reference geometry is not individualized physiological coverage.
- The status continues to say `9 / 9 reference layers drawn` with hidden layers,
  an isolated single element and a completely sectioned-away view. Distinguish
  acquired/loaded groups from enabled/visible presentation; do not claim exact
  rendered visibility from a loader count. An intentionally empty section also
  needs a clear explanation and reset control distinct from a failed renderer.
- The label overlap and alternating teal/beige selected-pancreas triangles are
  visible. Selection metadata identifies the source element, but neither the
  label-toggle assertion nor element selection establishes visual usability.
- Several scrolled full-page images place the fixed/sticky header across the
  scene or controls and leave space above it. The paired viewport/full-page
  capture and header-position diagnosis already proposed remains required;
  these images alone do not establish whether ordinary viewport use is occluded.
- 390/768 layouts stack the main areas, but long select-option text is clipped
  in the native list. Full text appears in the selected-element inspector in
  the long-name image. Keyboard selection, mobile reachability and the unrun
  installation acknowledgment are not accepted solely from these images.
- `linked-biology.png` contains seven reference organs and an explicit numerical
  readout rather than a blank scene; its external stylesheet requests still
  fail the linked-page gate. This retained technical fixture does not prove the
  current build, all entry points, detailed cell/gene reactions or six requested
  experiments are functioning.

Keep these observations alongside, not instead of, the original failed metrics.
No geometry edits, physiological deformation or decorative behavior are implied.
