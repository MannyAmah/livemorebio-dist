# Preserve scientific invariants without rebuilding unbound human models

Date: 2026-09-08. **Proposed test migration only; no source or test changes.**
Static review of the six reported `test_scientific_integrity.py` failures and
three retained `test_subject_lifecycle.py` failures. No test, HTTP request,
service, model, key or operational store was executed/accessed for this review.
The root-owned Cendos fixture migration and network tripwire remain untouched.

Authority: the complete clinical-context parent and availability amendment,
especially amendment §§2–3, 6–8 and its committed-selection rules. Admitting
descriptive measurements is not numerical activation. New REAL_HUMAN records
remain unbound; a disease string, measured fasting glucose or complete declared
parameter set cannot authorize a model. No replacement healthy fallback is allowed.

## Six scientific-integrity failures: exact preservation mapping

| Existing test / current line | Original invariant | Proposed replacement assertions |
| --- | --- | --- |
| `test_fasting_observation_is_normalized_before_parameter_mapping`, 76 | Glucose units must be normalized before a value is compared with a basal declaration; mmol/L must never be mistaken for mg/dL. | Test `normalize_observation("fasting_glucose_mgdl", observation)` directly: 7.0 mmol/L becomes 126.10913 mg/dL using the existing factor 18.01559, original value/unit, source, capture time and QC remain. Preserve the old 0.001 absolute comparison tolerance. Separately require the unbound `AdmittedHuman.metabolic_profile` call to raise the exact `ModelContextError.code == MODEL_BINDING_REQUIRED`, with no profile construction. Rename the test to describe evidence normalization, not clinical parameter initialization. |
| `test_random_glucose_is_not_a_fasting_setpoint`, 81 | Random glucose must not become a basal glucose set point. | Call the pure `validate_clinical_inputs(observations=..., model_parameters={})`: random/unspecified-context glucose produces empty candidate values and provenance; the input observation remains 180 mg/dL. Add/retain an explicit fasting-context comparison at the pure validator boundary. Missing binding still rejects numerical initialization. **Do not assert HEALTHY.Gb or REFERENCE_INITIALIZED as fallback for the person.** |
| `test_unassessed_observation_is_retained_without_initializing_biology`, 100 | Unassessed QC cannot initialize biology, but the source observation must remain inspectable. | Normalize the same 150 mg/dL observation, retain value/source/time/`not_assessed`, and assert `mapping_eligible is False`; the pure conflict validator returns no basal candidate. Verify the original stored/input observation survives. Numerical access returns MODEL_BINDING_REQUIRED, not a healthy set point. `mapping_eligible` is the existing validation/QC flag, not an admitted model binding. |
| `test_every_executable_parameter_exposes_initialization_provenance`, 110 | Every actual executable input has a value, unit and truthful origin; measured, declared and defaulted quantities cannot be conflated. | Split the two contracts. For pure evidence validation, the existing fasting observation plus declared weight 80 returns only `Gb` and `weight_kg`, respectively MEASURED_CLINICAL and USER_DECLARED_MODEL_PARAMETER; assert no `Si` or other invented defaults. This is an internal validation result, not stored executable provenance. For an actually supported source-bound legacy reference context, assert provenance keys equal all 12 numerical `MetabolicProfile` fields, each value/unit/source matches its immutable context and every class is REFERENCE_INITIALIZED. Use the existing `_legacy_reference_record` pattern and exact seven-overwrite/five-default expectations; never relabel `_human` or give a REAL record a reference context. |
| `test_admission_persists_parameter_provenance_and_unit_conversion`, 214 | Unit conversion and admitted evidence lineage survive encrypted storage/reload, rather than being lost between intake and execution. | Retain the same REAL admission fixture and assert normalized/original glucose fields, source/time/QC, custody and profile-source/field-provenance information through get and reopen. New record must contain `model_binding: null`, the descriptive creation identity, no generated `parameter_provenance`, and no filled `Si`. Test model resolution rejects. Keep historical saved provenance preservation in the existing old-record tests, not by regenerating it for new records. Rename this test to persisted observation provenance and conversion. |
| `test_complete_saved_metabolic_parameters_survive_activation`, 247 | The five easily omitted fields (`p2=.031`, `n=.19`, `ka=.027`, `f_bioavail=.68`, `vg_per_kg=2.4`) must not disappear or silently revert to defaults. | Retain all five exact declarations through REAL create/get/reopen and, if selection is included, explicit observation-only selection. Assert they do not authorize numerical activation or gain measured/fitted provenance; failed activation leaves selection/version/bytes unchanged. Preserve complete executable parameter transport in the already migrated frozen-source Cendos test and existing Aegle snapshot test. A separate pure dataclass/source-snapshot test may exercise these five technical values without a person. **Do not relax the legacy reference resolver's exact seven-value input shape or its five frozen defaults to make this test pass.** |

The last test currently calls `admitted_human(...).metabolic_profile`, not
`activate_twin`, despite its name. Its preservation invariant is valid; its
assumed authorization to compile the REAL record is not. Moving declarations
through observation selection must not manufacture numerical readiness.

## Passing tests that would otherwise become vacuous

`test_bad_clinical_observations_cannot_set_engine_parameters` (line 93, four
parameterized cases) and `test_invalid_model_parameters_cannot_activate` (line 125,
three cases) currently accept **any ValueError** from an unbound AdmittedHuman.
The early ModelContextError is a ValueError and can make all seven cases pass
without exercising their original validation.

Preserve these cases at the pure validation seam:

- Bad unit, malformed/timezone-free capture time and failed QC must reach
  `normalize_observation` / `validate_clinical_inputs` and reject for the relevant
  unit/time/QC reason, not MODEL_BINDING_REQUIRED. Keep submitted fixtures unchanged.
- Negative Si/Gb and zero weight must reach `validate_model_parameters` and
  reject the executable-domain violation. Keep declared-versus-measured conflict
  tests at `validate_clinical_inputs`; none of those calls chooses a model.
- Keep a separate exact missing-binding rejection for the real-human constructor.
  Do not solve the masking problem by broadening `pytest.raises` further.

Existing `test_clinical_context_contract.py` already covers the pure random/QC
and measured/declaration distinctions (75–106), exact legacy full-member and
12-value hashes (110–171), detached context/provenance and source mismatch.
Existing descriptive-registry tests cover rejection before insertion and forbid
compilation. Reuse these contracts; retain focused assertions in the scientific
integrity suite so its named scientific safeguards continue to be exercised.

## Three lifecycle failures: selection, custody and privacy

1. **Physical pairing preconditions (line 198; failure at 233).** Original
   invariant: synthetic subjects cannot pair physically; an admitted selected
   person needs explicit LIFE consent, attestation, firmware and calibration.
   Replace only the fixture's `activate_twin` step with
   `select_observations(id, expected_version=...)`. Assert ACTIVE plus
   `selection_mode == observations_only`, no admitted model binding and continued
   numerical rejection. Preserve the synthetic rejection, missing-attestation
   rejection, fixed pairing metadata and PENDING_SIGNED_ENVELOPE assertions. Keep
   this explicitly legacy protocol-v2 pairing metadata, not a v3 enrollment or
   hardware/measurement qualification test. The legacy `hardware_present` boolean
   is serialization compatibility, not independent evidence of real hardware.

2. **Restart and one-device ownership (line 260; failure at 284).** Original
   invariant: exactly one selected subject survives restart, and a physical
   device cannot silently bind to a second person. The helper should select each
   admitted person for observations, not instantiate physiology. Preserve the
   device ownership conflict and restart ID equality. Add exact observation-only
   selection mode, prior-person demotion and unchanged declared parameters;
   assert no numerical constructor or hardware command is called. The later
   committed-source/binding integration plan still owns broader route atomicity.

3. **Shell lifecycle and compact identity (line 554; failure at 619).** Original
   invariant: list/admit/activate/virtual-bind/cohort commands reach the intended
   SDK methods and retain IDs, versions, idempotency and reference-stratum arguments.
   It does not require logging a pseudonymous person ID. Make the fake list
   response explicitly `selection_status=CONFIRMED` with
   `active.twin_id=twin-shell-001`; assert that opaque ID and confirmation in the
   compact output, plus the existing VIRTUAL_ELIGIBLE/cohort/request assertions.
   Assert `pseudonym-shell-001` and the display label are absent from terminal text.
   Retain an additional missing/unknown selection-status case that displays
   `active=unconfirmed`, even if an old `active` object is present. Do not change
   the synthetic admission payload or legacy numerical-activation dispatch in
   this fake-platform test.

## Proposed implementation and verification boundary

Only after root approval: modify the identified tests and, if useful, a clearly
authored test-only fixture helper. No runtime change, new REAL binding, profile
compiler, observed-to-parameter update, source relabeling or hardcoded clinical
default is justified by these failures. Do not touch the root's migrated Cendos
source fixture, its no-peer-network tripwire, or its four current-source tests.

Run the migrated pure tests with local isolated stores, then the complete
scientific-integrity suite under the existing network tripwire and the relevant
lifecycle cases under numerical-constructor/hardware-call tripwires. The root
coordinates any actual numerical test already present in other suite cases.
Keep the DPP/NHANES four-member and twelve-value golden hashes unchanged. Independent
review must check that each old safeguard has an exercised new assertion, not
merely a green early missing-binding exception.

Decision requested: approve this test-only migration, including the seven
currently passing but masked validation cases. This proposal is not evidence of
new human-model qualification, physical Patch validation or full product readiness.
