# OSP insulin: version-bound runtime semantics, source evidence only

2026-09-08. Read-only investigation by `source_research`, pending independent
review. No generator, R/.NET/native library, formula evaluator, compiler or solver
was invoked. No source XML, runtime, criterion, result, registry or execution gate
was changed. Only this note is new.

## Outcome and evidence boundary

The author recipe and the source corresponding to the retained **managed**
assemblies resolve several ambiguities. They do not repair the insulin benchmark.
The original Stage B numerical FAILED result, first static FAILED receipt and
subsequent STATIC_GRAPH_COMPLETE report remain unchanged. The latter is still
declared-graph evidence, with numeric completeness false and semantic limitations.
See the [accepted independent graph review](2026-09-08-osp-declared-source-graph-independent-review.md:1)
and [failed numerical result](../../docs/OSP_INSULIN_STAGE_B_RESULTS.md:35).

Three distinct levels must not be collapsed:

1. **Author intent:** the pinned 2017 MATLAB recipe explicitly transfers only
   independent initial values. This is directly documented, not inferred.
2. **Version-bound code behavior:** retained managed binary metadata identifies
   SimModel commit `395dccf72a310b0485e63928741703045a1b40aa` and Core commit
   `b941097d3b76c00163ba5fb8d21b48a6406f7107`. Their official source was read.
3. **Actual native artifact and historical equivalence:** the co-packaged ARM64
   native libraries have retained hashes, but no native binary-to-commit build
   attestation was established here. Nor is the author's 2017 native build known.
   C++ statements below therefore identify the inspected source revision; they
   are not a newly observed execution trace or historical equivalence finding.

The earlier feasibility note's `0969102edb524f73e980de729b165bbb55956f14`
reference establishes an API example, **not** the retained assembly's source pin.
It must not silently replace `395dccf…` for semantic diagnosis. The newer commit
changes export support; this investigation neither uses nor activates exports.

## Exact local provenance

All package paths in this section are beneath the retained private root
`/tmp/livemore-osp-native.mUlZwx/r-library/ospsuite/`.

| Artifact | Read-only evidence |
|---|---|
| `lib/ConsoleApp.deps.json`, lines 362–376, 548–554, 1371–1376 | Core 12.3.32; SimModel NuGet 4.0.0.75. SimModel assembly/file versions are only 1.0.0.0, insufficient alone to identify the implementation. SHA256 `65e93420e84c69a063a8b5f42311772fca7fe2d93e52b3754497e7d687e65fea`. |
| `lib/OSPSuite.SimModel.dll` | Existing SHA256 `4c14eb2824397a1577e7c689984e4b9e9ea1b4297e6e480824681f19d199e520`. Static `strings` inspection finds `1.0.0.0+395dccf72a310b0485e63928741703045a1b40aa` and the official repository URL. No assembly was loaded. |
| `lib/OSPSuite.Core.dll` | SHA256 `4a06d51aeda6175ce48cacbbee5494fb92c6b34420b01578a1f3ea8be1ae19b6`; static metadata contains `12.3.32+b941097d3b76c00163ba5fb8d21b48a6406f7107` and official repository URL. |
| `lib/libOSPSuite.SimModelNative.dylib` | Retained SHA256 `d3ca3467fa7886898e76c47a81df031dfa5403e3497448611c3cb0d71c120bd4`. No embedded source commit found by the bounded static string check. |
| `lib/libOSPSuite.SimModelSolver_CVODES.dylib` | Retained SHA256 `19453818ef70c4b722f7aba518660927ac005e9b89ba8621598ec0038d99e257`; not loaded or run. |
| `lib/OSPSuite.Dimensions.xml` | SHA256 `69de334be1f2d35801cd44f90e26e63cae40974a8978189da527a0f62510322c`; lines 615–619 declare Time base unit `min`. |
| `doc/table-parameters.Rmd` | SHA256 `a98592e2b5ca8c9b7ea0f6df88945b1112b69faeaf658aba41e383a2f189611f`. Lines 56–66 describe high-level table y interpolation, not derivative evaluation in SimModel. |
| `doc/set-values.Rmd` | SHA256 `7b9f14ac8ce94bde8620402a85b50c24d3f3626d629cf7e0292d1482415acbf6`. Lines 113–142 distinguish high-level fixed-value overrides, reset and state-variable initial values from RHS formulas. |

The [official workflow at 395dccf](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/.github/workflows/build-and-publish.yml#L73)
builds managed/native platform packages from checkout and assigns one build
version. It names separate MacOSArm64 and MacOSx64 packages and publishes to the
OSP GitHub package registry. This explains why a nuget.org page was not a useful
binding source; it is not itself a retained per-artifact build receipt. The
[official Suite release issue](https://github.com/Open-Systems-Pharmacology/Suite/issues/166)
also names SimModel 4.0.0.75, but does not prove our native byte-to-commit mapping.

## Author initialization and retained collector

Source commit is `17a7f8eaac8d6c3e3f49d0a6e0fe6101e4bc3e18`, XML SHA256
`e78bb23d39ce7138f46bb876a54b43becb79bbf833e50c0cd7006f2a80eac3cb`.
The [author recipe, lines 53–67 and 120–143](https://github.com/Open-Systems-Pharmacology/Glucose-Insulin-Model/blob/17a7f8eaac8d6c3e3f49d0a6e0fe6101e4bc3e18/GIM_simulations.m#L53)
registers only non-formula species initials as variable, runs the initial phase,
copies their final values into initial values, changes application inputs and
starts another run. It does not transfer all evolved states or solver history.
The exact local recipe is [GIM_simulations.m](/tmp/livemore-osp-source.fmi3LG/GIM_simulations.m:120),
SHA256 `6cd652d8d2c23bceb5ed715625e614edc66fb0d46065c74c058a5e8560f0c2f0`.

The retained [R translation](/tmp/livemore-osp-native.mUlZwx/gim_recipe.R:62)
changes only the 1,073 `V[@value]` entries, leaving 27 initializer formulas intact.
The [Stage B collector](../../tools/osp_stage_b_native.R:92) independently constructs
a new native object for each branch, loads transformed XML, finalizes, runs and
reads `ValuesFor`. It does not resume a native checkpoint. Its source SHA remains
`6a16df63980de72b06c39b21b200de10a7bd04f54405a06c7bf5512a64dc1f37`.
The retained [all-state accounting](../../docs/OSP_INSULIN_STAGE_B_RESULTS.md:104)
already reports the two actual formula-reset differences, rectal liquid V5518 /
F5523 and IVITT depot V28279 / F28280. This note neither recomputes nor changes them.

## Semantic map of the inspected SimModel source

Every C++ link below is fixed to **395dccf72a310b0485e63928741703045a1b40aa**.
Line numbers are source-file lines, not a claim that these source files were
downloaded or compiled locally. Read the native-build limitation above with every
row. No generic API meaning is substituted for the low-level XML implementation.

| Contract | Exact source behavior and consequence |
|---|---|
| XML event names | [GlobalConstants.cpp, 19–22, 83–92](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/GlobalConstants.cpp#L83) maps native Switch/Change to XML Event/Assignment and the named flags. Time quantity ID is 0. |
| `oneTime` | [Switch.cpp, 28–38, 69–88, 146–148](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/Switch.cpp#L69): flag true only for attribute value 1; an already-fired one-time switch returns without reassessing. Condition must evaluate exactly to 1. It marks fired before sequential assignments; reset clears the latch. This is not an assertion of an SBML-style simultaneous event batch. |
| `useAsValue`, target-dependent | [FormulaChange.cpp, 31–34, 70–118](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/FormulaChange.cpp#L70): a species target evaluates the new formula at current state/time, divides by its ODE scale and writes that state, independent of the mode flag. A non-species target with mode 1 sets the evaluated constant; mode 0 installs the new formula, unless already identical. Installing a formula retains future dependency, not a sampled number. The static mode counts alone cannot classify target behavior. |
| XML literal/formula precedence | [Quantity.cpp, 114–159](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/Quantity.cpp#L114) **rejects both attributes**, rather than giving one precedence. Literal and formula are alternate initialization representations. Recognized NaN strings can be parsed; parse acceptance does not supply missing numeric inputs or prove unusedness. |
| Runtime value/reset distinction | [Quantity.cpp, 213–234, 270–272](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/Quantity.cpp#L213): `SetInitialValue` discards formula and changes original value; event `SetConstantValue` changes current value/formula only; `SetFormula` changes current formula only. `ResetState` restores original value/formula. A high-level R `$reset()` description alone is not proof of this native lifecycle. |
| Initial dependency order and rerun | [Simulation.cpp, 662–744, 998–1040](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/Simulation.cpp#L662) constructs initials by leveled dependency order, checks unset NaN initials and conditionally checks negative-disallowed states; a separate scaled vector divides by ODE scales. After run completion or failure, quantities and event latches reset. The runtime's permissive/conditional checks are not our scientific acceptance rules. |
| Assignment/event ordering | [SimModelXMLHelper.h, 35–71](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/include/SimModel/SimModelXMLHelper.h#L35) reads sibling order, and [Simulation.cpp, 758–764](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/Simulation.cpp#L758) iterates switches. Assignments can observe earlier writes; no atomic snapshot of all replacement values is made in these loops. Actual firing times and compound-condition root detection still need their precise execution path, not graph reachability. |
| Output versus switch | [DESolver.cpp, 174–215, 287–345](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/DESolver.cpp#L174) initializes saved arrays before the initial switch update. At subsequent saved times it stores observers/state before performing switches, then reinitializes the solver when required. Exported t=0 or event-time samples must not be relabeled post-event internal state. Observer evaluation and final state export also call the small-negative cleanup helper. |
| Derived/non-derived tables | [TableFormula.cpp, 43–154, 192–225](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/TableFormula.cpp#L192): derived mode returns segment slope `(y[i+1]-y[i])/(x[i+1]-x[i])` on left-closed/right-open intervals, zero before first x and at/after last x. Non-derived mode interpolates y and holds endpoint y outside the table. It requires strictly increasing x and sufficient points. All three GIM tables declare derived mode; ordinary y interpolation is not its native RHS interpretation. |
| `restartSolver` | [TableFormula.cpp, 111–154](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/TableFormula.cpp#L111) always schedules the first x, adds explicitly flagged later points, and in derived mode also adds zero-slope to nonzero-slope transitions. Therefore all 683 flags being zero does **not** imply zero restart points. No restart schedule was computed in this task. |
| Offset | [TableFormulaWithOffset.cpp, 23–59, 73–78, 145–171](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/TableFormulaWithOffset.cpp#L73) resolves Table and Offset as quantities; evaluates offset at current state/time, then table at time minus offset. Scheduled restart times add the offset only when deemed constant; otherwise scheduling uses zero offset. Example GIM F28346 points to P28334 and P28338, not directly to a formula ID. |
| Time | [QuantityReference.cpp, 111–126, 178–185](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/QuantityReference.cpp#L178) returns the passed solver clock for ID 0, without unit conversion or a separately defined quantity. Retained Dimensions XML declares min; GIM offset P28338 explicitly declares min; author reference grids use min. These support this recipe's clock convention, **not** unit inference for every bare Time reference or a dimensional proof of every RHS. |
| Small negative export policy | [SimulationTask.cpp, 171–204](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/SimulationTask.cpp#L171) actually zeros only values strictly between `-AbsTol` and 0, despite broader nearby comments. Its negative-disallowed check uses `< -100*AbsTol`. Those are software behaviors, not physiological admissibility thresholds; our frozen domain failures are unchanged. |

The Core/R table readout ambiguity is resolved at the API layer:
[Core TableFormula.cs, 54–98](https://github.com/Open-Systems-Pharmacology/OSPSuite.Core/blob/b941097d3b76c00163ba5fb8d21b48a6406f7107/src/OSPSuite.Core/Domain/Formulas/TableFormula.cs#L54)
defines `UseDerivedValues` as a solving flag, while `ValueAt` independently uses
y interpolation. Thus the retained R interpolation test and native derivative
code are different interfaces, not evidence that the GIM tables were changed.

## Consequences for exact GIM source and unresolved questions

The accepted graph retains all 33 events, 39 assignments, all 27 initializer
closures and Table/Offset links. Nothing here weakens that accounting. Example
event14925 condition14928 writes V3376 with mode1 and P3385/P3399 with mode0;
under the inspected implementation those are a state update and two formula
installations. A classification solely by the numeric flag would be wrong.

This source reading does **not** establish that an event caused the I0/I2
End-IR-en error, T1/T2 pancreatic insulin discrepancy, or the T0/C0 failures. It
does not authorize a receptor restoration coefficient, glycogen-pool repair,
signed-state exemption or any threshold change. The prior exact-ID dimensional
and zero-boundary concerns still require source/measurement evidence. The 56
NaN literals, 28 with declared consumers, remain unresolved numeric inputs even
though the parser source recognizes NaN syntax.

Explicit remaining unknowns:

- Native ARM64 byte-to-source/solver build mapping, beyond co-packaging and managed
  informational-version evidence; the author's original runtime and golden trace.
- Actual event/assignment firings and pre/post-event states in the retained runs.
  The saved outputs are not an event journal. No root-localization guarantee for
  every compound condition has been established by this bounded reading.
- Whether any unresolved NaN declaration reaches an evaluated branch in each
  particular protocol phase; graph reachability alone cannot decide it.
- Complete units/domain definitions for `S_I`, receptor-restoration terms and
  signed-looking regulatory/bookkeeping states. A Time base-unit declaration
  does not repair a missing volume/rate factor or qualify a person-specific model.

## Minimal next diagnostic proposal, not execution approval

First close the **native source identity** gap with the original official
MacOSArm64 package/build manifest or equivalent retained-byte source evidence;
do not substitute current master, recompile a replacement or upgrade the runtime.
Then propose a separate, fixed technical semantic probe packet, independent of
GIM: one-time latch/reset; parameter mode0 versus mode1; state targets under both
flags; formula/literal conflict and dependency initialization; table endpoint,
offset and restart behavior; and pre/post-switch output timing. Expected results
must be written from these exact methods before execution. Keep native output
cleanup separate from a technical fixture's analytic internal state.

Only after source identity and those expectations are independently reviewed
should a further GIM diagnostic be proposed: retain exact event identity/order,
native clock and before/after state without modifying equations or numerical
gates. Stop on source-pin mismatch, semantic disagreement, omitted event evidence
or unexpected input. Do not silently rerun the physiological matrix or call the
insulin program ready. Exogenous insulin, erinacine A, sterubin, carnosic acid,
arctigenin and cyanidin-3-O-glucoside remain the six required programs.

## Method and durable lesson

Read the accepted graph review and retained author/runtime/collector/source-audit
records first. `/investigate` kept diagnosis separate from repair. `/browse` was
read fully, but its installed binary exited137 before opening a page. Root then
authorized purpose-built read-only web retrieval of official source pages. No
browser repair, runtime/source archive acquisition or third-party source was used.
`gbrain`, context7 and sequential-thinking tools were not callable in this session.

The lesson is to bind semantics to **actual package bytes and call paths**, not a
recent source URL or similarly named high-level helper. Separate XML declarations,
initializer reset, internal solver state, event-time output, runtime cleanup and
scientific acceptance. The maker has not graded this note as experiment admission.
