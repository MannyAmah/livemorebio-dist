# Navigation-first local console session

Date: 2026-09-09. Scope: R03/R27/R45/R46/R48. Branch: full-scope recovery.
User authority: proceed; replace repeatedly failing paths completely without
compromising the product. This is an approved boundary replacement, not a new
identity provider, biological model or clinical admission policy.

## Problem and chosen complete alternative

The last two actual data-recovery checks both retained a failed startup bootstrap
request. Its internal cause remains unproven. No additional attempt to patch that
request is planned. Replace the initiation architecture entirely:

```text
top-level navigation to an exact approved console document
  -> existing server attaches protected cookie to successful HTML
  -> browser evaluates application modules
  -> unmodified native fetch / EventSource send same-origin cookies
  -> existing read/mutation authorization, consent and model gates
```

Compared alternatives: explicit JS session client still has a startup dependency
and forces every caller to migrate; introducing a new bounded session provider
changes credential, expiry and stream policies. Selected navigation-first delivery
reuses browser-native behavior and the current local operator identity. Separate
server-expiring sessions remain a security requirement to evaluate before broader
release; this increment must not call the persistent token cookie time-bounded.

Independent source-only review: release_redteam identified the precise consumers
and preserved auth boundary. Root read security.py, complete auth.js, document
hook placement and the three explicit consumers. Root reviewed the primary
[Fetch Metadata specification](https://www.w3.org/TR/fetch-metadata/): normal
address-bar navigation is `none`; document and iframe destinations differ.
Context7 is not callable; inspect installed FastAPI/Starlette implementation and
official response/middleware docs before referencing their APIs.

## Exact six-file runtime scope

- security.py: opt-in document-delivery hook, separate from API credential policy.
- aegle/server.py: enable for `/`, `/legacy`, `/twins`, `/cohorts`, `/biology`,
  `/patch`, `/cendos`, `/adapters`, `/research`. Fixed410/no-store bootstrap retired.
- console/lib/auth.js: passive explicit reopen control only. No fetch override,
  startup request, token handling, automatic recovery or uncertain-write replay.
- console/lib/workspace.js: remove ensure wait before EventSource.
- console/lib/protocol_biology.js: remove ensure wait before saved-result read.
- console/patch.html: explicit user recovery reloads document, never calls load
  again after an uncertain authorization attempt.

Keep existing nine auth.js tags. No new broad call-site migration. Preserve
existing scientific source contexts, rendering values, selection and stale guards.

## Security and compatibility contract

Issuance requires exact path, GET, successful HTML response, loopback URL authority,
`Sec-Fetch-Mode:navigate`, `Sec-Fetch-Dest:document`, and `Sec-Fetch-Site:none` or
`same-origin`. Reject missing/ambiguous metadata, cross-site, iframe/subresource,
redirect/error, arbitrary API/asset responses. If Origin exists, require actual
same origin including scheme/authority. Keep no-store, HttpOnly, host-only,
SameSite=Strict, path behavior. No credentials in HTML, JavaScript, URLs or logs.
Missing/invalid token means no cookie, protected routes still refuse.

Do not relax `_request_credential` (including its `none` rejection on API calls),
bearer precedence or constant-time comparison. Preserve CLI/SDK and env/file
credential distinctions. LIFE/Cendos shared auth remains opt-out of the hook.
Host alone is not proof of network socket locality; preserve the local-launch
boundary and Docker bridging support, no public exposure or reverse-proxy change.

## Error and state paths

```text
navigation valid + token configured -> cookie -> native requests
navigation invalid -> no cookie -> protected request refuses
credential missing -> static shell + explicit reopen help, no automatic retry
old open tab -> old bootstrap receives410 -> user explicitly reloads
401 / uncertain write -> visible existing failure -> no replay
```

No session promise, abort wrapper or polling timer remains in auth.js. Browser
request bodies and signals are untouched. Reopen navigates only to the same
document, not an arbitrary supplied URL, and cannot be triggered automatically.

## Red-first test and independent review gates

1. Every actual document route issues the expected cookie under admitted metadata;
   assets/API/errors/redirects/missing metadata and disallowed origins do not.
2. Raw token absent from all document bodies; cookies have fixed flags; no-store.
3. Mutation and protected-read refusal occurs before stores/models; bearer and
   cookie/Origin/Fetch-Metadata tests remain valid. CLI compatibility unchanged.
4. Actual auth.js leaves native fetch identity intact, makes zero network calls,
   never consumes Request bodies/signals and exposes only explicit same-page
   navigation. No automatic action on401 or replay.
5. Workspace and saved-result consumers have no bootstrap dependency. Patch user
   recovery makes exactly one deliberate navigation, no hidden load/mutation.
6. Retired bootstrap always410/no cookie, does not fall back.
7. Existing selection, source authority, consent, clinical availability and auth
   tests run along with new tests. Preserve historical tests/receipts separately
   when they intentionally describe the removed implementation; do not rewrite
   them into false old PASS claims. Identify intentional migrations explicitly.
8. Real browser smoke uses the actual security/document path with isolated authored
   data and no physical native engine. No injected cookie or mocked bootstrap.
   Prove navigation, authorized read, reload/recovery, no session-bootstrap request,
   coherent Biology data recovery and screenshot evidence. Scientific/graphics
   acceptance is separate and must not be inferred from a session smoke test.

Architecture/code/performance review: six runtime files, one opt-in hook, no new
framework/dependency, no database migration, no new I/O per API beyond existing
authorization. Threat/error/test paths above have specific acceptance checks.
Independent maker/reviewer separation required after implementation.

## Rollout, rollback and preserved scope

Cut over as one coherent restart/reload in the isolated review stack only.
Preserve originals and failed receipts. Rollback is explicit source rollback by
the owner; never automatic bootstrap fallback and never git reset of the dirty
worktree. No installation over the user's active stores, no PR/release yet.
R01–R51, six experiments plus full-product demo remain active. Timer board is
independent and may update while this work proceeds.

## Decision

Root approves red-first implementation of this exact boundary replacement under
the latest user authorization, after independent source review. Any broader auth
policy, model, consent or deployment change must be proposed separately.

### Ordinary-browser check boundary

After independent source/test clearance, use the existing `run_review_stack.py`
on unused loopback ports 8868–8870 with a fresh automatically generated private
store. Do not inject browser credentials or replace scientific responses. Root
inspected startup: verified absence of a selected record creates the existing
healthy **reference preview**, using the shipped reduced metabolic/cardiac model.
This ordinary startup computation is permitted for this check; it is neither an
experiment nor a real-person model nor permission to run the OSP replacement.

Use actual in-app browser navigation to all nine documents, inspect ordinary
protected-read outcomes and the explicit reopen control, and retain original
screenshots. Do not enter participant data, create experiments, pair a device,
post physical measurements, load licensed sources or contact an external model
service. Empty reference/model caches and absence of supporting services/assets
must be reported honestly, not papered over as graphics acceptance. Stop only
these exact owned review services at handoff; leave installed ports/stores intact.
An unexpected startup failure is retained and reviewed before another attempt.
