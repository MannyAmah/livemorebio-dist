# LIFE-bound execution: prospective consumer-lease amendment

Date: 2026-09-08. Status: proposed; root and independent reviewer approval required before code.
Parent: [continuous execution subplan](2026-09-08-life-continuous-virtual-execution-subplan.md), R04/R08/R25/R26.

## Why this is needed

A LIFE consumer can request an Aegle pause after a forwarding failure, but that
request cannot guarantee a pause if the HTTP surface is unreachable while Aegle's
numerical worker remains alive. The already approved outage/backpressure rule
therefore needs a producer-local lease. This is an explicit resource/lifecycle
amendment, not a new biological mechanism or a completion claim.

Standalone Biology numerical executions remain unbound and have no consumer
lease. Only an explicit LIFE binding activates this requirement. No lease is
inferred from a browser poll, SSE connection, page load or patch.latest.

## Exact contract proposed before implementation

- One consumer session per execution. Binding requires the existing execution
  revision/source-generation preconditions, a 32-hex session ID and exact frozen
  source hash. The authenticated LIFE caller, not an arbitrary numerical body,
  performs this operation. A different consumer requires an explicit stopped
  session/rebinding operation; no silent takeover.
- Fixed lease TTL **30 seconds**, renewal target **5 seconds**, producer expiry
  check target **100 ms**. These are prospective engineering settings, not
  measured latency guarantees. The native interval deadline remains 15 seconds
  and native initialization deadline 45 seconds; neither is called the lease TTL.
- Aegle alone records `time.monotonic()` for expiry. Client wall clock or a
  caller-supplied deadline cannot extend it. Lease identity and the requirement
  are retained in the encrypted execution record; the live monotonic deadline is
  process-local. A restart invalidates the lease and never resumes computation.
- Renewal verifies execution/source/session identity. It updates only the
  process-local lease deadline/lease counter, **not** the execution revision or
  model checkpoint. This prevents routine renewal from discarding a valid native
  interval through the revision fence. Status presents lease state/age/remaining
  duration separately from engine state, native time and sample age.
- A prepared execution may be bound before the producer is started. Binding and
  renewal never construct a solver, produce a frame or advance model time.
- Start/resume requires a currently renewed lease when the execution is bound.
  Server routes must run blocking native initialization off the async event loop,
  permitting authenticated renewals while the owned worker initializes. No
  authority/manager lock is held across native work or network I/O.
- Expiry pauses scheduling locally and increments the ordinary execution revision
  once, fencing an in-flight result. `advance_once` checks expiry both before
  dispatch and immediately before frame commit. A late candidate is discarded,
  never relabeled or published as a newly accepted sample.
- An expired initializing job is cancelled within its owned-worker termination
  bound; it produces no frame. If no initial checkpoint was committed, an explicit
  Resume may initialize the same admitted source again after renewal. If a full
  checkpoint exists, Resume reconstructs the adapter from that full state/native
  clock, labeled numerical continuation, not bit-identical solver history.
- Expiry retains the source, checkpoint, immutable frames, pending LIFE envelope
  and last acknowledgment. It does not delete journals, replace a device identity,
  increment a device sequence or restamp an old envelope.
- A renewed heartbeat after expiry does **not** resume the execution. The operator
  must explicitly resume both service lifecycles with current revisions/source
  identity. Stopping the LIFE session cancels renewal and requests an explicit
  producer pause; unreachable transport still falls back to local lease expiry.
- Renewal eligibility is owned by the LIFE session lifecycle, not an independent
  always-on heartbeat: only a source-matched waiting-for-engine/streaming session
  with healthy delivery permission may renew. A forwarding failure, unresolved
  admission, blocked delivery, source mismatch or backpressure **immediately
  disables renewal**, even if Aegle's renewal endpoint remains reachable. Preserve
  the exact pending envelope; explicit recovery must resolve it and restore
  consumer permission before renewal, followed by explicit producer Resume.
- Source invalidation wins over lease renewal: a current heartbeat cannot make
  `source_valid=false` runnable. A stopped/completed/failed execution cannot be
  revived by lease calls. A lease is not a physical-device connection or evidence
  of successful delivery to Aegle's observation view.

Proposed manager seam:

```text
bind_consumer(execution_id, session_id, source_snapshot_hash,
              expected_revision, expected_source_generation)
renew_consumer(execution_id, session_id, source_snapshot_hash,
               expected_source_generation)
```

Proposed authenticated endpoints are
`POST /api/executions/{id}/consumer` and
`POST /api/executions/{id}/consumer/renew`; root may align names while preserving
the identity, audit and concurrency contract. Include them in the encrypted
access audit with bounded allowlisted actions. Renewal audit failure is a failed
renewal, not a hidden lease extension. An audit outcome failure after renewal is
an ambiguous response with its request ID; an exact repeat can renew the same
identity safely but never advance model time. This is not a distributed lease.

## Exact red-test packet and acceptance

1. An unbound execution advances without a lease; binding a prepared execution
   does not initialize a solver and missing/wrong session/source/revision rejects.
2. Fake monotonic clock crosses exactly TTL: just-before may commit; at/after
   expiry pauses and admits no candidate. Wall-clock jumps do not change expiry.
3. A native job blocked in a technical adapter straddles expiry; no frame or
   checkpoint advance commits after expiry. The complete prior state is retained.
4. Renewals during that job keep the execution revision unchanged and a valid
   completion is admitted once; duplicate renewals produce no biological sample.
5. Heartbeat after expiry leaves the producer paused; explicit Resume continues
   the prior full state/native clock with no paused-wall-time integration.
6. Expiry during initialization cancels only the owned worker and permits explicit
   same-source reinitialization after renewal, with no fabricated initial frame.
7. Source switch followed by renewal cannot revive the old source. Wrong consumer
   and a previous process's lease reject; restart is interrupted, never advancing.
8. Simulated LIFE/Aegle HTTP outage blocks remote pause/renewal, yet the producer
   locally pauses within TTL plus measured scheduler/termination lag. Record the
   actual lag; do not describe the prospective 100-ms check as an OS hard bound.
9. Lease metadata, audit and pending delivery remain bounded/encrypted. No
   repeated renewal appends unbounded in-memory history or bumps device sequence.
10. Observation intake fails while lease-renewal HTTP still works: the LIFE
    lifecycle must stop renewing, so producer-local expiry still pauses it. A
    pending/failed delivery cannot be hidden by an independent healthy heartbeat.

Independent approval and subsequent measured results are required before this
amendment can satisfy the outage portion of the parent acceptance matrix.

Root approved the exact timing/revision/checkpoint proposal on 2026-09-08. The
independent reviewer approved it with the renewal-eligibility clarification above
and strict producer-process restart invalidation (no deadline reconstructed from
persisted wall timestamps). No lease implementation or timing result is claimed
by this approval record.

## Independent implementation review — 2026-09-08

The independent source reviewer read the manager's lease, activation,
cancellation, ownership and restart paths, and the gateway's narrowly added
encrypted-admission and exact-receipt resolution paths. The first private run
passed 121 lease/lifecycle/gateway/v3 tests. A separate constructor-failure probe
nevertheless reproduced an ownership leak: a failed adapter constructor left a
failed execution's kernel lock retained without an adapter instance. The maker
added a failing regression, then replaced the adapter-presence cleanup condition
with explicit activation-success tracking. The reviewer re-read that correction
and independently reran the same packet: **122 passed in 2.43 seconds**.

The checked contracts include exact monotonic expiry, late-result rejection,
renewal without revision changes, renewal after expiry remaining paused,
initialization cancellation and explicit recovery, source invalidation, prior
process lease rejection, encryption-required admission without plaintext
fallback, exact lost-response receipt recovery and unchanged ordinary replay
rejection. Tests used isolated private technical stores; no native biological
solver or physical device was executed in this review.

No remaining actionable blocker was found in this bounded manager/gateway
packet. This is not acceptance of the still-separate LIFE consumer HTTP/outbox
lifecycle, Aegle observation receipt projection, native outage timing or physical
equivalence. Those require their own implementation and integration checks.
The source constructor regression illustrates why passing existing tests is not
a substitute for independent failure-path review; resource cleanup must cover
failure before an owned worker object has been returned.
