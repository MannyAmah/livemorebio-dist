# Local molecular viewer dependency materialization decision

Root read the complete private launcher/test candidate, complete source-identity
amendment and frozen reports. The original source/rights plans remain applicable.
Current private root:`/private/tmp/livemore-molecular-offline-install.a8XyYr`.
Launcher SHA256`8ac417f6d9704fa320e7934ff28466a054589c386fe4aebbbc913325239007cb`;
plan`13fb3308d055407d0b3ded5c7b604b85a95783f355abba37fc38eec89e615e3a`;
tests`3b8152e3e43eb4cf711c3b28e2e8a25034a3d27dd370bfb1b4dd79070f7dedc3`.
Independent guarded repeat:38 passed0.062s, unexpected I/O0. The narrow
identity-only adapter retains held-child/group/start/image/path proof without
mistaking npm's mutable title memory for immutable launch arguments. Shared OSP
code/gates remain unchanged. This is not a hermetic operating-system proof.

Authorize one invocation of this unchanged private launcher:14 offline stock
cache-add batches and one offline ci with scripts, Git, audit, funding, notifier
and retries disabled as frozen. Exactly427 admitted archive identities, unchanged
canonical428-placement lock; omit only declared optional fsevents. Existing
stores/builds are not targets. New exact authorization and exclusive marker
remain required before launch. No old metadata cache, online recovery or retry.

The115s work/5s cleanup and30s pre/post evidence bounds remain. Root will inspect
actual final receipt, command failures/cleanup, immutable input verification and
installed-original-byte comparison before any downstream decision. A failed
installation is retained, not overwritten. This is private input materialization
only: no webpack/Sass build, vendoring, scientific experiment, consumer wiring,
redistribution clearance or installation for external users is accepted yet.

The previous34-case candidate and archive acquisition failures remain preserved.
Unresolved emitted-license/source obligations (including tr46/undici-types and
any embedded excluded codec) must be checked against the later actual bundle.
# Retained actual attempt — not an install pass

The authorized once-only invocation finished exit1 in private root
`/private/tmp/livemore-molecular-offline-install.a8XyYr`. The result is
47,094 bytes, SHA256
`edcf38092c1da24614010f80e400c3159ef24297d28ee20e9a052c53a3c9afbe`:
SUPERVISOR_FAILURE at CACHE_ADD_11 after12 command receipts and11.673819083s
child work/cleanup. All12 children exited0, with SETTLED empty-before-reap
cleanup and no TERM/KILL; this does not erase the primary supervision failure.
The exact underlying exception was not retained, so an exit-transition race is
only a candidate cause pending source review and a reproducing test.

Root's post-run targeted process check found none of parent16705 or the12
recorded child PIDs present. Inputs_preserved is true; install-once.py still
hashes8ac417f6d9704fa320e7934ff28466a054589c386fe4aebbbc913325239007cb.
The once marker, authorization, scripts, result, private partial cache and logs
remain untouched. No ci/build/vendor/product change was made. A new attempt
requires a separate corrected source and fresh directory, not rerunning this one.
