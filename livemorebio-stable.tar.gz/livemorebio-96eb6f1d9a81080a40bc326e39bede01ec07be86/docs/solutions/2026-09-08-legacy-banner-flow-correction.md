# Legacy banner: normal-flow correction

Approved scope: root's actual-recovery acceptance report, remaining finding1.
Root inspected all12 original uofz7at2 images and found top-fixed `showBanner`
covering shared navigation at desktop/mobile. No new general design plan needed.

Pre-code seam: only `aegle/console/index.html`. Add one initially empty/hidden
`#__banner` immediately after `.top`, before the existing research-preview status
section. `mountShell` already prepends navigation/framing before these blocks.
Use normal static block flow, existing info/error colors, wrapping and no overlay
position/z-index. `showBanner` reuses that region, writes textContent, sets status/
polite for info and alert/assertive for errors, retains aria-atomic, and clears/
hides on empty input. Do not steal focus, disable navigation, create a second
status framework, change request/state logic or remove controls.

Author dedicated mounted-handler and static-layout regressions first; preserve
the existing98 harness and632 client packets under their refusal wrappers.
No real browser/services/native work in this increment. Independent desktop/
390px/keyboard inspection on the new source remains root-owned after freeze.

Explicitly still open and untouched: generic “reacting live”/“ENGINE”/“one beat,
live” labels while unavailable, generic Recon3D/genome mechanism claims, positive
parametric/T2D captions, recovery-density refinement and complete navigation at
200%/tablet/mobile. These remain in the actual-recovery report and all-page visual
inventory; this banner correction does not satisfy them or the six experiments.

## Frozen implementation and test receipt

Status: **maker implementation complete; independent code/rendered grade pending**.
No actual browser/service/model operation occurred in this increment. The QA
skill's minimal-fix/regression guidance was used; its browser verification is
explicitly reserved for root's separately authorized run. No commits, unrelated
working-tree edits or operational configuration changes were made.

| File | SHA256 |
| --- | --- |
| `livemorebio/aegle/console/index.html` | `16f39c7f5d5c20cacf8de066132a552baa993b0bd740ea44e94e4fb061a5ee94` |
| New `livemorebio/tests/test_legacy_banner_flow.py` | `2638a8a3e4f9224143ecf723ddc8cf330a731f482d8f1d860ceda65906f3aef4` |

The only page changes are three scoped CSS rules, one empty static status block
and `showBanner`. Removing those rules/block and restoring the exact old handler
in memory reproduced the prior whole-page SHA256
`93c65024d14f20abd420fd228ce876fcf624b97d0a9a4050b9c2f2b97c4a7b3f`.
All surrounding page bytes, controls, A+B workspace files, models and request/
source/clinical logic are untouched. The hidden empty banner clears prior text;
subsequent info/error messages reuse the same region. Long messages wrap without
fixed width/height/overlay placement. All content remains textContent, not HTML.

| Gate | Actual result | Private review-root suffix | Node / unexpected I/O / optional Git refusal |
| --- | --- | --- | --- |
| New mounted/static RED before product edit | 6 failed,0.45s | 25fwila_ | 4 / 0 / 0 |
| New tests after exact banner correction | 6 passed,0.39s | epufcwl0 | 4 / 0 / 0 |
| Unchanged harness preservation | 98 passed,5.94s | ut0dclo9 | 47 / 0 / 1 |
| Unchanged client preservation | 632 passed,32.06s | jv98i5ps | 186 / 0 / 1 |

The six tests cover static region placement/role/hidden state, normal-flow CSS,
actual handler info/error/default semantics, unchanged literal long text/no HTML,
same-node clear/reopen, no body append/duplicate region, no focus theft and no
state change. These are DOM/handler and source-CSS tests, not a layout engine or
screen-reader/browser pass. No existing test was modified for this fix.

Exact offline invocations use the frozen strict wrappers already recorded in:

- `2026-09-08-legacy-preview-d0-diagnostic-implementation-review.md`, command
  unchanged for98; replace only its pytest file with
  `livemorebio/tests/test_legacy_banner_flow.py` for the6-case RED/GREEN.
- `2026-09-08-legacy-preview-client-recovery-implementation-review.md` §Exact632,
  unchanged file list/45-second alarm/Node shapes/tripwires. Its environment line
  was replaced by the already independently approved sanitized variant:

```python
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1';os.environ['PYTHONDONTWRITEBYTECODE']='1'
```

All run from `/Users/emman/Livemore/.worktrees/full-scope-recovery` using
`/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B -`. Authored Node evals only;
all Python/Node network and unrelated process operations refused. The632 gate
retains its explicit native/model exclusions; this does not change their status.

Next root-owned rendered check: show model-unavailable info and a safe authored
error at desktop1440 and390px, verify shared navigation unobscured/clickable and
keyboard focus unchanged, confirm text wraps and clear/reopen remains readable.
Do not claim 200%/all-page accessibility or static scientific-label correction
from these unit results. Prior12-image baseline and both failed attempts remain
immutable and distinguishable from the new page identity.

Lesson: persistent status belongs in document flow, not above shared navigation.
Moving its element should not change the underlying action or failure contract.

## Independent source review, 2026-09-09

Independent reviewer: ui_audit, not the implementation maker. **No actionable
blocker found in this bounded banner delta. Rendered acceptance remains pending.**
Both frozen hashes above matched. The reviewer read the complete new tests,
actual handler/callers, shared shell and applicable shared/page CSS. Removing
only the three new CSS rules/static block and restoring the original handler in
memory independently reproduced whole-page SHA256
`93c65024d14f20abd420fd228ce876fcf624b97d0a9a4050b9c2f2b97c4a7b3f`.
Thus no surrounding handler, numerical/source state, control or markup change
is hidden in this correction. No file was rewritten by that check.

The focused repeat was **6 passed in0.39s**, exit0, private root
`livemore-research-review-qzoxxgl4`: four authored Node evals, zero unexpected I/O
and zero optional Git calls. It used the cited D0 wrapper with only this test
file, the sanitized environment above, plugin autoload/bytecode disabled and a
45-second default-OS alarm. Python socket/DNS/urllib/ctypes/unrelated processes
and Node network/child-process APIs were refused. No browser/service/model,
operational store or molecular tooling operation ran.

Construction evidence: `index.html:15–17` supplies normal static block flow,
unbounded wrapping height and an explicit hidden display rule. The body-level
region at143 follows `.top`; `shell.js` prepends nav/framing before it. Neither
applicable stylesheet positions this banner over navigation. Handler336–340
updates only its dataset, ARIA role/live attributes, literal text and hidden
state. No focus or scroll API, body append, HTML insertion, current-state write
or control disabling occurs. The mounted tests exercise that actual function,
not a rewritten stand-in. They do not implement a layout engine, accessibility
tree or screen-reader announcement test.

### Minimal actual verification proposal, not execution approval

Reuse `check_legacy_preview_browser.py/.cjs` with its existing private modeless
fixture, authored delivery schedule, exact source/process pins, request/POST
guards and owned cleanup. Unmodified it can show the info banner, but does not
exercise this banner's error branch or directly hit-test navigation. A small
reviewed harness amendment can cover the missing checks without new framework:

1. Retain all12 prior capture slots and four authored deliveries. Position the
   existing desktop-modeless/mobile-refreshed info captures deterministically
   at the nav/top; record banner/nav rectangles, horizontal document overflow,
   and hit-testing of visible nav links. A link outside the mobile scrollport
   is not falsely reported visible; keyboard-scroll it into view before checking.
2. After each context's existing `refresh('A')`, inspect that Compound is the
   selected class and its input is empty. Keyboard-activate the existing enabled
   run button once. Its current empty-input validation returns before `runVia`,
   so require unchanged POST count and retained focus on that button. Require
   the exact error text/alert attributes; add desktop-error/mobile-error viewport
   captures with nav and banner both inspected, for14 images total. No request
   interception or scientific fixture value is changed by this check.
3. Continue the existing workflow. Ordinary rendering clears the error; the
   final modeless refresh reopens info. Assert same banner node, cleared old
   text, no focus theft and visible/hit-testable nav. Preserve the existing
   Twins/LIFE/History navigation and final source/cleanup checks.

Parent/CJS exact image admission and inert harness tests would need the same
two additive image names before a separately authorized run. Keep all time,
request, POST and evidence-byte budgets; fail rather than extend them. This
proposal does not grade full mobile/200% navigation, screen-reader behavior,
remaining static scientific labels or the broader product acceptance matrix.

## Approved harness implementation precisions, before code

Root approved the preceding two-image extension on2026-09-09. Only the existing
Python/CJS harness and dedicated harness tests may change. The original seven
case ledger and twelve image names/order are preserved as a subsequence; insert
`desktop-error` immediately after `desktop-modeless` and `mobile-error` immediately
before `mobile-note-before`. Exact image count becomes14 in CJS and parent
admission; all other limits, authored POST bodies/count/order, model tripwires,
source/process checks and cleanup remain unchanged. No actual run is authorized.

Capture the existing banner element as a page-owned remote handle after each
normal baseline. Its identity is compared to the current singleton for every
new check; closing the owned page/context releases that handle. No browser-global
state or product markup is written. Fixed readout metadata contains only boolean
checks, viewport/nav/banner rectangles and visible-link index/hit-test flags,
never banner text, input values, clinical quantities or arbitrary error messages.
Retain metadata before assertions so failed placement/focus checks remain useful.

Five ordered banner check rows are required: desktop-info, desktop-error,
desktop-cleared, mobile-error, mobile-info. Before each error, record that the
existing authored A render hid/cleared the banner, inspect Compound selected,
empty input and enabled run button, focus the button and press Enter once.
Require unchanged scheduled POST count and request-POST count, exact fixed
empty-input error, and unchanged button focus. The ordinary C render supplies
desktop-cleared; the final modeless read replaces mobile-error with mobile-info.
Capture positioning scrolls the nav/top to a deterministic origin, then checks
the whole banner is below navigation and inside the viewport, normal flow/wrap,
no document overflow, and visible nav-link hitboxes. Offscreen links are recorded
as offscreen, not passed as hit-tested; complete keyboard/mobile navigation
remains explicitly outside this bounded visual claim. No nav click is added.

Red tests cover both new image slots/count, actual serialized DOM reader and
negative rectangles/occlusion, mounted real runner placement/focus/unexpected-POST
failures with retained metadata, same-node clearing, strict receipt completeness
and parent admission. Existing mounted fixtures may add only the standard
elementHandle/evaluate/focus behavior and authored banner DOM state needed by
these checks; every prior failure/cleanup/state assertion is retained. Literal
12-image expectations migrate to14 only after their new count RED is captured.
