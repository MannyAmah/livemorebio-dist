# Checked startup: real registry wiring verification

2026-09-08. Root approves the independent release reviewer's ten-case test-only
proposal. This extends verification of the same approved startup increment; it
does not alter physiological behavior, runtime contracts or R01–R51 scope.

Create only `test_checked_startup_registry_integration.py`. Use the actual server
registry getter with a private tmp_path and explicit fixed test key, real checked
SubjectRegistry read/confirmation/audit, ModelSourceAuthority and no-background
ExecutionManager. Reuse reviewed authored seed/rows/events helpers, not their
socket-denying autouse fixture. No participant or operational data is allowed.

The ten cases are: checked true absence with an unrelated unselected row; ACTIVE
SYNTHETIC; unbound ACTIVE REAL_HUMAN; same-version authenticated payload interference
during build; pointer-timestamp-only interference during build; orphan ACTIVE
topology; SQLite trigger rejecting audit INSERT; unauthorized state/current-source/
mutation access before startup with static access retained; and direct initialized
restore parametrized for absence/SYNTHETIC.

Stub only numerical construction/candidate state. Root explicitly approves
record-only bus sinks while keeping `_snapshot_twin` real; this prevents unrelated
file-backed publication and tests the actual startup-to-publication call. Do not
replace checked readers/confirmations, audit methods, real-manager `_open` or
authority/fence guards. No model, adapter, service, browser or child is run.

Assert completed capture audit before unlocked construction; exact confirmation
audit before coherent publication; preserved ciphertext/version/index/pointer and
prior audit bytes except deliberate interference; no terminal reservations after
settled access; fail-closed state/current-source/numerical access after failure;
no retry/fallback; second ordinary ensure idempotence. Preserve the deliberate
external edit when confirmation rejects. Negative cases expose meaningful missing
checks, not a replacement of protected code with permissive doubles.

Run using the established private ASGI-compatible environment, fixed45s alarm,
network/process/native refusals and internal TestClient socketpair allowance.
Report exact results and freeze hashes for independent review. Any runtime defect
found returns to root before a correction. No new native persisted-model run or
whole-product acceptance follows from this packet. The original persisted-model
integration remains a separate obligation.
