# Anatomy and cohort UI restoration subplan

Parent: `2026-09-08-full-scope-recovery-plan.md`, first reviewed implementation packet. Scope IDs R03/R05/R06/R19/R20/R22/R25/R27/R48 remain open until their evidence is produced; this is not a substitute for the full R01–R51 program.

## Baseline and implementation question

The preserved run page hides the anatomy stage by design. Active Biology separately fails when its WebGL/CDN dependencies are unavailable, but its tests exercise only the data fallback. Cohort indication is a hardcoded T2D value; frozen members are rendered in an unbounded full-ID dropdown. These are distinct defects and need distinct tests.

Restore anatomical inspection of normal and saved human-research contexts while keeping reference anatomy, model output and measurements distinct. No physiological equations, calibration, numerical parameters or records change in this UI packet. An intact Atlas remains separate from Biology's reference-organ inspector; no unregistered organ montage becomes a patient scan or whole-person geometry claim.

## Data and renderer seams

1. Vendor the existing Three.js 0.160.0, GLTFLoader and OrbitControls dependencies as one reproducible same-origin bundle, retaining MIT notice, source version and source/bundle hashes. No external CDN dependency is needed to render existing anatomy. The source-owned HRA/BodyParts3D meshes and provenance remain unchanged.
2. Introduce a shared graphics loader with bounded timeout, explicit capability/dependency/asset/context failure states and Retry. Actual mesh-ready/rendered state must be distinguishable from merely having a canvas. Dispose old renderers, listeners and late asset callbacks before a retry or workspace teardown. No placeholder geometry.
3. Root supplies a reference-only Biology catalog from existing ORGAN_ATLAS and mesh catalog, with no active twin access or parameter values. Saved human-research runs join that catalog with `protocolInspection`'s exact run/member/native-axis/source selection. No `/api/state` or active `/api/biology` call is permitted in that path.
4. The run-bound anatomical inspector shows reference organs, cell/pathway/target identifiers and an explicit current-member readout. Systemic glucose/insulin/remote-action quantities remain labeled systemic reduced-model states, not organ-specific concentrations, cellular kinetics or motion. PXR retains concentration conditions and its reporter-model scope. GEM and rat-vesicle lobeline remain separate non-person assay workspaces.
5. A member/condition/stage/quantity/sample change updates every displayed context field together. Member changes pause playback and reset the saved-sample cursor. Reference geometry can stay cached, but no prior member value or cell trace can survive a context replacement. Null/unavailable quantities stay unavailable. No default benefit, pulse or looping physiology is added.

## Controls and scaling

- Keep existing human-run plots, stage controls, source details, CSV/notebook exports and immutable History. Add an anatomical area and visible organ/cell selection with the same frozen context; do not replace quantitative inspection with geometry.
- Replace the full member dropdown with compact selected-member summary plus search/filter/paged inspection, at most 50 visible rows. Retain full stable IDs in details and source records. Paging/search must not silently change selection.
- Cendos uses compact cohort-level selection independently of experimental protocol, with compatibility visible and member inspection on demand. Preserve existing protocol request bodies and explicit Run.
- Root supplies one population-capability endpoint for generic twin/cohort forms. Remove silent T2D name/indication defaults; show healthy and supported contexts only from that contract. If a context lacks a configured source/generator, display the actual blocker and do not submit invented parameters. Real-person indication is not forced to the research prior's disease label.

## Red-first tests and evidence

1. Pure selection tests: wrong/missing run/member identity, nonhuman exclusion, zero/adverse/unchanged values, missing units, selected source lineage, no input mutation.
2. Renderer controller tests: local dependency path, timeout/retry, late completion after disposal, asset failure/retry, no prior-context values, preserved independent data polling.
3. Actual browser test with real GLBs and WebGL: nonzero loaded mesh/triangle count and visibly rendered geometry; normal selected twin; saved human run/member switch; organ isolation/clipping/cell details; no active-subject request in saved-run mode. A browser incapable of WebGL is reported blocked, never marked passed by fallback.
4. Separate unavailable-WebGL/dependency/asset cases preserve data with precise failure and successful retry where recoverable. No screenshot-only acceptance.
5. Technical member workloads 1, 100 and 10,000: bounded DOM, search/filter/no-match, selected member retained across pages, keyboard operation, delayed rapid clicks, responsive layout.
6. Generic form tests preserve indication/source compatibility, reject unavailable contexts, and keep protocol payload/History/rerun lineage unchanged.
7. Independent code review and formal browser QA after a clean checkpoint; screenshots include exact isolated build/URL and technical/reference-only data. No mutation on ports 8850 or 8890.

## Ownership and external dependencies

UI owner edits console assets except root-owned `shell.js` and `workspace.js`, dedicated UI tests and this subplan. Root owns Python routes, capability source, runtime isolation, packaging metadata and shared identity. New API needs are communicated before implementation. Context7/gbrain/Compound Engineering tools are unavailable in this session; existing source, official pinned library files and local durable lessons are the documented fallback. No global tool upgrade or installed-release pointer change.

Missing measured-person scans, organ kinetics, healthy-source parameterization and physical telemetry are not repaired with illustrations or synthetic observations. They remain explicit full-scope dependencies, not completion claims.
