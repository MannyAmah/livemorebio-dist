# Atlas fixed-source acquisition: hard deadline amendment

Date: 2026-09-08. Parent: `2026-09-08-atlas-reference-conversion-renderer-packet.md`.
Status: written for independent pre-code review; no actual source acquisition or
conversion authorized. The fixed source, nine groups, coordinate transform,
rights and physiological boundaries do not change.

## Boundary found during red-first implementation

The current synchronous acquisition checks a shared monotonic 600-second
deadline before and after each response read and uses 30-second socket inactivity
timeouts. These checks prevent late bytes from being admitted, but do not stop a
blocked DNS/header/slow-drip operation precisely at the total deadline. A Python
thread/future timeout would leave work running and is not an acceptable repair.

Reuse the existing owned subprocess/liveness/lock mechanism for **two sequential
phases**, not a new service or general worker interface:

1. `acquisition`: the exact three packaged HTTPS source objects, total 600 seconds.
2. `conversion`: the already verified source to the exact nine GLBs, total 180
   seconds, unchanged geometry contract.

There is at most one phase child per installer at a time. The installation lock
is held continuously by the parent and inherited by the current child. A second
installer cannot start either phase while the first or an orphan child holds
that same open-file-description lock.

## Exact child authority and lifetime

- One internal phase launcher selects only the two literal entrypoints. Callers
  cannot supply code, URL, path, source metadata or subprocess arguments.
- Launch the same reviewed Python executable with `-I -B`, insert the reviewed
  package parent explicitly, and bind the packaged declaration hash for
  acquisition; bind both declaration and loaded converter identity for conversion.
  The child does not resolve code from the caller's working directory.
- Pass only the checked private cache-root descriptor, shared installation-lock
  descriptor and parent-liveness read pipe. A clean environment contains only
  fixed PATH/locale/thread-count values, no inherited operator credentials,
  cookies, proxy credentials or clinical inputs. Stdin/stdout/stderr are not
  exposed as data/log channels.
- The parent records the **absolute monotonic phase deadline before spawn**.
  A fixed minimal **stdlib-only launcher bootstrap** validates the literal phase,
  absolute finite deadline, owner-private regular lock descriptor and liveness
  pipe, computes the remaining interval, rejects expired/invalid intervals and
  arms default-termination `SIGALRM` plus the parent-EOF watcher **before any
  Livemore phase/package import**. The module then revalidates the unchanged
  absolute deadline. This protects an orphan even if phase import stalls, not
  merely after networking/NumPy/trimesh begins. Startup consumes the same
  budget. No file, redirect, socket or partition resets that deadline.
- The same dedicated liveness pipe ends the child on parent EOF. If Python-level
  handling cannot run, the OS timer terminates it. If the parent is killed while
  the child is stopped or in native/network work, the child retains the lock
  until it exits. The parent never explicitly unlocks or replaces that lock.
- Parent waits only until the remaining phase deadline; on timeout/error it
  terminates and waits for its exact owned process group. Cleanup cannot kill an
  unrelated browser, service, process or old PID. No automatic phase retry.
- Normal child success is not admission. The parent independently rereads the
  exact source/archive/map bytes and metadata before converter admission, and
  independently decodes all GLB arrays before receipt/pointer publication.

## Source-only writes and interruption

The acquisition entrypoint only calls the fixed-source acquisition functions.
It may create the private `sources/` namespace and write unique 0600 temporary
files within that namespace; after exact byte count and SHA verification it
atomically renames each file to its pinned content-addressed source name and
fsyncs the directory. These are raw reference objects, **not admitted geometry**.
It never writes `artifacts/`, installation receipts or `active.json`, and never
calls conversion or physiological code. Other already verified raw sources and
the last admitted geometry remain untouched when a later source fails.

A killed worker can leave a private, unpublished source temporary file. It is
never read as a source, promoted by existence, or served. Do not recursively
delete arbitrary cache content or unsafe files to recover; retain this evidence.
Ordinary exceptions remove only that worker's exact temporary file. Final parent
publication and all previously approved fsync/immutable artifact checks remain
unchanged. Explicit later installation is a new authenticated action; read-only
status never restarts a failed phase.

## Red-first acceptance additions

- Production acquisition dispatch uses the bounded helper, never direct parent
  network reads; only literal phases and expected hash identities are accepted.
- Actual owned tiny child processes stand in for blocked DNS, indefinitely
  incomplete headers and a slow byte drip. They do not use external hosts or
  publisher assets. Each exceeds a shortened technical deadline and must be
  terminated without output admission or a surviving owned process.
- Kill the installer during phase startup and an active source read. Verify the
  orphan keeps the lock while alive/stopped, exits by EOF or its OS deadline,
  and only then permits another installer. No receipt/active geometry appears.
- Exercise a real technical stalled-package-import hook after the stdlib
  bootstrap has armed its guards; kill the owning parent during that import.
  The orphan still holds the lock and exits by EOF or the original OS deadline.
- Cover EOF before heavy imports, exact source/declaration identity mismatch,
  expired startup deadline, nonfinite/boolean deadline values, invalid phase,
  pipe/lock validation, parent timeout, spawn error and close-on-exec cleanup.
- Preserve safe headers/fixed HTTPS/no-redirect behavior, byte/CRC/ZIP/schema
  checks, private paths and all existing tiny technical conversion roundtrips.
- Keep actual publisher acquisition/conversion behind root plus independent
  implementation review. These process tests prove bounded engineering
  behavior, not anatomical rendering or biological validity.

Independent pre-code reviewer requested the bootstrap-before-package-import
correction above; root agreed. The correction is written before implementing
the acquisition phase. No additional source, geometry or publication authority
is granted.
