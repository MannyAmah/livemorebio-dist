# Ordinary Biology context and removed-organ correction

2026-09-09. Independent controller regrade is clear; real-page acceptance pending.
This implements only the immediate prerequisite paragraph of the reviewed
ordinary-Biology molecular-switch plan. All R01–R51 remain; no scope reduction.

## Reproduced defects and minimal correction

An ordinary unlinked response accepted malformed or absent context IDs, whereas
the server publishes an opaque 64-hex token. A refresh whose organ list no
longer contained the selected organ retained the old detail markup. Rejecting
an invalid refresh must retain the previous readout as stale without treating
it as permission to request another cell trace.

The actual inline controller now validates a string of exactly 64 lower-case
hex characters before STATE publication (including length to exclude a final
newline). The existing linked-mismatch invalidation stays first. One boolean
tracks accepted data versus failed refresh. Cell entry refuses while data is
unconfirmed; the existing error path pauses replay. A valid same-context refresh
restores cell entry/replay. A removed open cell is closed even on a same-key
response. A removed selected organ returns to the real remaining overview and
clears isolation exactly once. Same-organ refresh still updates detail without
restarting isolation. No new framework, dependencies, styles or model behavior.

The old molecular modal/loader and both newer consumer implementations remain
unchanged. This does not activate the local molecular switch or resolve its
three browser cancellations or distribution terms.

## RED → GREEN and preserved tests

New controller tests use the complete real inline script via the existing
helper. A test-only insertion exposes STATE/view/selection and allows an
authored graphics double; it replaces no controller function. This is not
WebGL, a live application or a participant-data check.

Before product edits, `7f0f9b`/`b50a00` reproduced **18 failures and one pass**
in 1.78 seconds: 10 invalid initial identities, three invalid refreshes, four
removed-organ variants, and failed-refresh cell entry. Same-organ preservation
already passed. No new test assertion changed afterward. The minimum product
patch then passed all 19 in 1.77 seconds (`50788d`).

The first affected suite returned three expected authored-fixture mismatches
and 75 passes (`7d2fef`). Three older successful fixtures had omitted context
or used context-a/technical-context rather than the server's actual contract.
Only those fixtures' identity literals were migrated to repeated a/b/c/d 64-hex
values (six lines). All inherited assertions, including null-context refusal,
HTTP failure/retry, unavailable quantities, replay mismatch, pause/resume and
late old-context rejection remain intact.

The final maker affected suite **013bb7 passed 78 checks in 7.39 seconds**,
zero failures/skips, 75 exact Node children and zero unexpected I/O under the
existing refusal wrapper. It includes the new reconciliation file, clean
workflow, linked protocol inspection, biological projection and clinical-model
availability UI tests. This is not a new full-product test count.

## Frozen files for independent review

| File | Previous SHA256 | Current SHA256 |
|---|---|---|
| biology.html | `8bbc7c9fc3f57790b9866559162514372ebfbc03c840c5c47a1432e1543163cc` | `499fbd5a68b9e7e675873ebeee5fc1b051a794b816cd1cd631bb3f8851ce80b1` |
| test_biology_context_reconciliation_ui.py | new | `879f5c1b3cc82c1d5db21c197cc1e3849c32292f71af85203f846cd7b9964683` |
| test_clean_workflow_ui.py | `ba7bf0e74eb5571cb49d18372100a7f3e9a10209d380d2cca305762bff25972c` | `85a6054d3b5014a53d0da9a437c9b20523f4bf94365854b5cf42463f167f0cb1` |
| biology_ui_fixtures.py | unchanged | `49ff0b090d2b99651ddc4a4373cf02c8fac35039972cc739906d8db66f63cb8b` |

Independent reviewer must inspect the written plan, exact added tests and the
data-controller delta, repeat the bounded suite, and report defects rather than
accepting the maker's count. Existing unrelated worktree changes are preserved.
No browser/native/service/participant/device execution is permitted by this
offline repeat. Actual-page QA remains required before release.

## Exact independent repeat

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os,signal,socket,subprocess,sys,urllib.request,ctypes
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('OFFLINE_DEADLINE')));signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and len(cmd)==4 and cmd[:3]==['/opt/homebrew/bin/node','--input-type=module','--eval']:
  counts['node']+=1
  permit=True
  try:return run0([*cmd[:3],'import {createRequire as scopedRequire} from "node:module";const require=scopedRequire(import.meta.url);\n'+prefix+cmd[3]],*a,**k)
  finally:permit=False
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1
  permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=line','livemorebio/tests/test_biology_context_reconciliation_ui.py','livemorebio/tests/test_clean_workflow_ui.py','livemorebio/tests/test_protocol_inspection_ui.py','livemorebio/tests/test_ui_biological_projection.py','livemorebio/tests/test_clinical_model_availability_ui.py'])
print('Refusal counts:',counts,flush=True)
raise SystemExit(status)
PY
```

## Lesson

A retained successful readout is useful recovery information, not a newly
confirmed source. Validate identity before publishing state and reconcile
drill-down selections against the new available entities. Preserve useful
same-entity views, but never leave removed entities looking current.

## Independent review: two remaining controller gaps

Release-redteam read the complete written scope, actual ordinary controller,
new 19 tests, all five affected test files, real anatomy callback/state-update
seams and the actual availability validator. Review used the review skill's
race/value/consumer checks within the explicit no-Git/no-network/no-product-edit
boundary; no automatic fixes or browser review were performed.

The exact command above independently passed **78 tests in 7.22 s**, with
75 bounded Node children, zero unexpected I/O, zero Git attempts and no skips
(`43eb84` / completion `1872e3`, private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-ana6yvvn`).
All four frozen file hashes match the maker table. In-memory reversal of only
the six authorized identity-literal edits reproduced the recorded predecessor
SHA `ba7bf0e74eb5571cb49d18372100a7f3e9a10209d380d2cca305762bff25972c`
(`a2cb1d`). This is an **inverse-delta hash check**, not a separately retained
original file. No original assertion changed in that verified six-line delta.

The prerequisite is **not independently clear yet**. Two separately authorized
authored VM probes fail on the frozen `499fbd5a…` source. Both ran through the
same 45 s private environment and Python/Node refusal policy, with no product or
test-file edits. Receipt `291729` exited 1; two assertions failed, two Node
children, zero unexpected I/O/Git. Private root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-udzl6l0u`.

1. **P2, confidence 10/10: late cell completion restarts stale replay.** The
   refresh catch clears `dataCurrent` at Biology line 313, but a pending cell
   request's completion at 466 and the render loop at 480 check only the retained
   context key. After accepting A, hold its cell request, reject a null-context
   refresh, then resolve the matching-A trace. STATE correctly remains A, but
   the old sequence is unchanged: the response restarts one RAF and replaces
   the paused cell status with the replay status. Guard completion and rendering
   against unconfirmed data, preserving the existing valid-refresh resume path.
2. **P2, confidence 10/10: the actual mesh callback revives removed detail.**
   Biology's `onSelect` at 210 forwards the cached organ object directly to
   `showDetail`. The real anatomy `updateStates` (235–238) retains existing
   nodes; picking (332–337) supplies their cached `userData.organ`. After the
   same-context kidney-only response correctly clears the selected heart,
   invoking the captured actual callback returns to detail/heart with the old
   heading. Resolve the callback ID to the current accepted organ object and
   refuse absent IDs; do not rewrite geometry or reuse cached annotations.

### Exact independent probe bodies

The probes reuse the new test file's literal `PREAMBLE` and
`biology_controller_script()`, inserting the same existing `window.testScope`
seam before `loadBiology();\ninitAnatomy();`. Each body runs in its own authored
VM/Node child; assertion errors propagate to exit 1.

```js
const activeHeart={...heart,cell:{...heart.cell,render:'cardiac'}};
payload=state('a'.repeat(64),[activeHeart]);
const ordinaryFetch=context.fetch;let release;
context.fetch=async(path,...args)=>{
 if(path!=='/api/state')return ordinaryFetch(path,...args);
 calls.push(path);await new Promise(resolve=>{release=resolve;});
 return {ok:true,json:async()=>({context_id:'a'.repeat(64),cardiac:{v:[-80,20,-80],cai:[0.0001,0.0002,0.0001],t_ms:[0,100,200]}})};
};
await mount();const accepted=context.window.testScope.state();
const pending=context.window._cell('heart');await flush();a.equal(typeof release,'function');
payload=state(null,[activeHeart]);await refresh();
a.equal(context.window.testScope.state(),accepted);a.equal(frames.size,0);a(el('biology-status').textContent.includes('may be stale'));
release();await pending;
console.log(JSON.stringify({probe:'late_trace',raf_after_failed_refresh:frames.size,cell_display:el('cellmodal').style.display,cell_status:el('cell-data-status').textContent}));
a.equal(frames.size,0,'LATE_TRACE_RESTARTED_AFTER_FAILED_REFRESH');
```

Observed: `raf_after_failed_refresh:1`, `cell_display:"block"`, and the saved
model replay status. This is an authored trace, not execution of a cardiac model.

For the second body only, the exact dependency declaration
`const {loadAnatomyDependencies}=await import('/lib/anatomy_loader.js');` is
replaced in memory by `const loadAnatomyDependencies=window.probeLoad;`.
The real initialization and `options.onSelect` expression are unchanged; this
captures that callback using an inert graphics double, not actual WebGL/picking.
The retained-node/picking connection is established by the real anatomy source.

```js
context.window.WebGL2RenderingContext=function(){};
context.document.createElement=()=>({getContext:()=>({getExtension:()=>null})});
const view={...graphics(),clearClip(){},setClip(){},setLabels(){}};
context.window.probeLoad=async()=>({THREE:{},GLTFLoader:function(){},OrbitControls:function(){},createAnatomyExplorer:options=>{
 context.window.probeSelect=options.onSelect;return view;
}});
await mount();a.equal(typeof context.window.probeSelect,'function');
context.window._sel('heart');payload=state('a'.repeat(64),[kidney]);await refresh();
a.equal(context.window.testScope.view(),'overview');a.equal(context.window.testScope.selected(),null);
context.window.probeSelect(heart);
console.log(JSON.stringify({probe:'removed_mesh_callback',view:context.window.testScope.view(),selected:context.window.testScope.selected(),removed_detail_visible:el('panel').innerHTML.includes('<h2>Technical reference heart</h2>')}));
a.equal(context.window.testScope.view(),'overview','REMOVED_MESH_CALLBACK_REVIVED_DETAIL');
```

Observed: `view:"detail"`, `selected:"heart"`, `removed_detail_visible:true`.
The original 78 PASS remains preservation evidence, not coverage of these races.
Root owns the corrective implementation and permanent tests. No molecular,
browser, native, model, device, source-distribution or whole-Biology acceptance
is granted by this review. Lesson: entry-time freshness checks must also guard
late completion/rendering, and retained graphic objects are not current data.

## Maker correction of both independent findings — regrade pending

Root incorporated both findings into the written implementation scope, then
added four permanent cases: late same-key trace, late already-scheduled frame,
removed cached-mesh selection, and same-ID current annotation preservation.
`7accb1`/`fbb723` reproduced exactly **four failures with the prior 19 passing**
in 2.10 seconds, 23 Node calls, zero unexpected I/O. The four assertions were
not changed after RED. Their anatomy callback is extracted verbatim from the
actual inline options and made available in the existing test-only scope seam;
no separate replacement callback/controller is authored.

The additional product delta is one callback routing through existing `_sel`,
one completion freshness check, one render freshness check, and inclusion of
the same check at replay resume. No transport operation, frame data, model
equation, geometry, molecular control or API route changes. The inherited
same-key valid-refresh resume and late old-context rejection assertions remain.

Final maker suite `51b1d9` passed **82 cases in 7.55 seconds**, zero skips,
79 bounded Node children and zero unexpected I/O/Git. Use the exact independent
command above unchanged; the test file now contains 23 cases. New frozen hashes:

- Biology: `5b2fd6284ec1517407110c31f818c79f8860206fa7457d18eb1f536efab9f1f6`
- Dedicated tests: `233635ee3256ae759ac2e58f9e2c25351842649bf1c951540b101665c24326a6`
- Older fixtures: unchanged `85a6054d3b5014a53d0da9a437c9b20523f4bf94365854b5cf42463f167f0cb1`
- Controller helper: unchanged `49ff0b090d2b99651ddc4a4373cf02c8fac35039972cc739906d8db66f63cb8b`

The earlier maker freeze and independent failures remain historical evidence,
not overwritten as passing. Independent regrade and actual-page verification
remain outstanding. The full product is not ready for release.

## Independent regrade of the four-site correction

Release-redteam read the appended plan/correction receipt, all four permanent
regressions and the actual completion/render/resume/current-organ paths. The
current callback resolves through `_sel`'s current `organsData` lookup. Trace
completion refuses while `dataCurrent` is false, and both render and replay
resume independently enforce that condition. Valid same-context recovery remains
covered by the inherited assertions. No remaining blocker was found in this
bounded prerequisite correction.

The exact independent command above passed **82 tests in 7.63 s**, no skips,
79 guarded Node children, zero unexpected I/O/Git (`92d60e`, completion
`00d960`, private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-8vmmojqa`).
Both original independent probe bodies and their dependency-only seam were
rerun **unchanged**: **2 PASS**, Node 2, unexpected I/O/Git 0, receipt `139eed`,
private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-vectgny2`.
The late trace left RAF count 0 and the paused status; the removed mesh callback
left overview/null selection with no removed detail. The earlier two failures
remain retained above.

All four revised frozen hashes match. In-memory inversion of only the four
new product sites exactly reproduced the earlier `499fbd5a…` SHA (`c9c0b9`),
confirming the bounded runtime delta without creating an alleged original file.
Verdict: **independently CLEAR for the ordinary context/detail prerequisite
only**. No product/test source was changed by this reviewer. This regrade does
not accept actual-page behavior, the molecular switch, its transport/rights
gates, native biology, all of Biology, or any of the six required programs.

## Actual ordinary-page recovery check — partial observations, overall FAILED

Root reviewed the complete frozen private runner, tests and 35 input/harness
pins. Independent inert repeat `c25859` passed 20 Node and 10 Python cases.
Root separately authorized and invoked the single `PHua9I` run (`906a00`,
completion `5d324f`, exit 1). No repeat or source alteration occurred.

All six actual interaction stages passed: initial organ overview, opened heart
reference cell, heart removal closing that cell and returning to the remaining
kidney, malformed-context refusal with retained detail and blocked cell entry,
visible Retry data recovery, and portrait layout. Root personally inspected
all six original images. Desktop captures are 1440×1000; portrait is 390×844.
The portrait capture shows internally scrolling navigation and vertically
stacked graphics/detail; it is not proof of all mobile controls or full A+B QA.

The unchanged failure gates correctly retain **FAILED / REQUEST_FAILED**:
one local request failed and two stylesheet console messages had the exact
text `net::ERR_BLOCKED_BY_CLIENT.Inspector`. The two stylesheet URLs are the
runner's declared external blocks; its classifier did not recognize that exact
suffix. The local failure ledger retained only `LOCAL`, not URL/error/time, so
its cause cannot be established or excused from this packet. The original
failed result is not converted to PASS by the six successful interaction stages.

The 20.1499 s supervision receipt records 32 GETs, 243562 served bytes, no page
exceptions, four settled owned closes, no remaining descendants/listeners and
all 29 input/six harness pins unchanged. Root independently checked exact PIDs
55070, 55073, 55074, 55077, 55086, 55087, 55088, 55089, 55094, 55095, 55096 and
55118 absent (`34b44e`). No participant store, mutation, native model or device
was used. The technical fixture deliberately disables WebGL; the empty graphics
surface in these captures is not an observed product graphics regression.

Original evidence directory:
`/private/tmp/livemore-biology-context-qa.PHua9I/run`.

- `browser-result.json`: `2f424c89b77edaab97410133ed58aa2decb8421322340577f4cefb58ab022673`
- `supervision.json`: `0c76e97587f445840e835fa4ec7ef8f2661f9e749bcd4516241d8b27ecaa1c3a`
- `recovered.png`: `17f81246b1f6ebbf5a8040780074dd23af4c389c27fc8a055325bf3154dc8d46`

Lesson: retain exact scoped request identity and failure text when testing
recovery. A location class alone is insufficient to distinguish application,
transport, fixture and intentional teardown failures. It is not a reason to
waive a failure or change product biology. The molecular, graphics, whole-product
and six-recording requirements remain open.

Independent data-only audit `154ef9` confirmed exact raw/embedded browser-receipt
equality, all 35 pins/metadata, all 21 visited source receipts and six original
PNG hashes/dimensions. Total original image bytes: 1638282; full final evidence:
1661690 bytes (the parent counter precedes its own final receipt write).
Source ordering places the local request failure before the first owned close:
the pre-cleanup failure-capture check had already seen it, with all six image
slots occupied. Its route/error/time remain unknown. This rules out attributing
it to final owned teardown without adding missing evidence. Audit made no edits,
browser or native runs and did not change the FAILED verdict.

## Follow-on visible stale-state correction — written plan before code

Independent source/visual review found a separate, reproducible presentation
defect: cell-entry refusal calls `invalidateCell`, replacing the explicit stale
readout warning while retaining the old detail. Preserve the warning and Retry
control for a rejected stale entry; keep the existing context-mismatch wording
for a genuinely invalid/mismatched context. Add a failing controller regression
before changing that branch. Preserve cell invalidation/closure behavior.

The ordinary heading and shell subtitle also unconditionally claim executable
state even for the actual UNAVAILABLE path. Make these fixed headings neutral
(`Living Biology` / `Multiscale biology — model state and evidence`), retaining
the existing per-quantity evidence and availability messages. Do not infer that
all `reference_preview` selections lack numerical execution or invent another
availability state. Pin the heading change in a regression. No model, geometry,
transport, selection, metadata or data value changes.

Keep the original PHua9I source/image/failed receipts immutable. Review this
small product correction independently before updating a fresh diagnostic
runner's page identity. Repeat the affected preservation suite. The previous
82-pass result and six actual observations describe their recorded predecessor,
not the as-yet untested new bytes. Whole-page acceptance remains open.

Root implemented only the three planned product lines after `72930e` / `b8a00f`
reproduced **2 failures, 23 passes**, 2.20 s, Node 24 and zero unexpected I/O.
The new stale-entry test checks the unchanged warning/detail, visible Retry,
closed cell, no new trace and no replay frame. The heading test checks both
neutral fixed surfaces. No existing assertion was changed.

Maker preservation repeat `c35224` / `a83264`: **84 passed, 8.10 s**, Node 80,
zero unexpected I/O/Git, no skips. Page SHA:
`510bae8d67cd3bdb703a2d02b06da35805e7311942c65b7c984618fd1ba18f1f`;
test SHA: `8cca04fb1f8d13559de6d3ec04216d0391eec2823764793dbad8a23213347c22`.
The source reviewer who found the defect is independently grading this freeze.
The earlier failed browser packet remains tied to its original `5b2fd628…`
page; it cannot be reported as a browser test of these newer bytes.

Independent source reviewer regrade: **CLEAR**, exact documented five-file
repeat `dc16dc` / `590635`, **84 passed in 8.05 s**, Node 80, zero unexpected
I/O/Git, no skips. Two additional in-memory checks (`68c81d`, Node 2, I/O 0)
confirmed that a trace missing its context still closes and warns, whereas a
stale entry retains the stale warning and clears replay. Valid recovery alone
does not reopen that closed cell; explicit new entry is required. In-memory
inversion recovered the exact predecessor page/test hashes, establishing the
three-line product boundary and additive tests. All four current pins match.
No browser, native, service, participant, source or Git change by the reviewer.
Current page is cleared for inclusion in the fresh private request-evidence
diagnostic; original PHua9I remains FAILED and no actual pass is implied.
