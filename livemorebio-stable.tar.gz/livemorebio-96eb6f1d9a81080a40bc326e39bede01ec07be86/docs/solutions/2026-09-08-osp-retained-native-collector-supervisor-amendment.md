# OSP retained-native collector and supervisor: source-only amendment

2026-09-08. **Proposal only. No implementation or execution authorization.**
This completes the planned collection/ownership boundary for the existing17
technical probes. It changes no fixture, hypothesis, equation, tolerance, failed
Stage B result, product model or clinical admission. Root and independent review
must resolve the explicit decisions below before collector implementation.

## 1. Read scope and what already exists

Read the full307-line [technical protocol](2026-09-08-osp-retained-native-technical-probe-proposal.md),
171-line [source map](2026-09-08-osp-native-semantics-source-map.md),
the complete [331-case independent fixture review](2026-09-08-osp-semantic-fixture-independent-review.md),
its262-line maker report, all407 lines of `tools/osp_semantic_probes.py`,
the [biological model-change contract](../BIOLOGICAL_MODEL_CHANGE_CONTRACT.md),
the old collector and relevant existing ownership helpers. The engineering-plan
skill's scope, failure, test and resource review was applied. Its update,
telemetry, external-agent, browser and release commands were not run in this
explicitly source-only task. No callable CE/gbrain search was available; prior
decisions were recovered from these local documents.

Reuse the frozen pure `protocol`, `fixture`, `validate_fixture` and
`compare_observation` interfaces. Their source remains
`12585d9bed93cd2a5625ec1cd625287406a22d475b49c34ba931109630ea82d7`,
test source
`5c4d29106391b97f429d1f66969e3262c8d35395678b11947d94d74a08951b09`.
The original protocol digest remains
`5eb866376a2b121109066dbb11edad2eba701b3b85c8fe474ae1aa02b8e505e7`.
Do not change its false admission/loaded-manifest flags; the new outer receipt
separately binds actual collection and identity evidence.

Use only the already retained runtime at `/tmp/livemore-osp-native.mUlZwx`.
The old `osp_stage_b_native.R` is call-path reference, not an import: it sources
`gim_recipe.R` and loads physiological inputs. Neither file may be evaluated.
Likewise reuse the **reviewed ownership design**, not an import that triggers
Beard generation, compilation or a physiological entry point.

Proposed implementation write set remains the two new files already named by
the protocol, `tools/osp_semantic_probes.R` and
`tools/osp_semantic_supervisor.py`, plus dedicated new collector/supervisor tests
and a receipt. No edits to the existing pure fixture module/tests are needed.
The supervisor can be the fixed private driver and orchestration owner; a second
generic runner/service or new product API is unnecessary. Sequential work in
these coupled modules, then independent review; no parallel edits to them.

## 2. Primary source facts, not newly observed runtime behavior

The local rSharp source tree is the retained official commit
`3a8686e70c700437b451a01216ad4fb2990e432c`. The prior feasibility receipt records
private installation from this source with its supplied ARM64 bridge after the
official binary archive failed integrity. Installed R lazy-load bytes were hashed
here, not loaded or evaluated.

- [R/zzz.R](https://github.com/Open-Systems-Pharmacology/rSharp/blob/3a8686e70c700437b451a01216ad4fb2990e432c/R/zzz.R),
  locally SHA256 `3bdcd0c0c5c9b4e27ccb7a8c16ed8c5f2adfd2c51a3bf843ab0ff1851c628472`:
  `.onLoad` calls `.checkDotnetPrerequisites`, which invokes exactly
  `system("dotnet --list-runtimes", intern=TRUE, ignore.stderr=TRUE)` before
  `.loadAndInit`. A later `.ensureRuntime` may retry if initialization failed.
  Thus the collector must not use `dotnetAvailable()` as a second readiness probe
  after failed loading. It must inspect the recorded runtimeLoaded setting and
  stop before any further managed call if initialization did not succeed.
- [R/utilities-assembly.R](https://github.com/Open-Systems-Pharmacology/rSharp/blob/3a8686e70c700437b451a01216ad4fb2990e432c/R/utilities-assembly.R),
  SHA256 `0c24146237d035cf43d9dd7f924212a6eb3e128588cdbf537666132b7cce9f17`:
  `getLoadedAssemblies(fullname=TRUE, filenames=TRUE)` obtains current managed
  assembly names and locations through the existing facade.
- [InternalReflectionHelper.cs](https://github.com/Open-Systems-Pharmacology/rSharp/blob/3a8686e70c700437b451a01216ad4fb2990e432c/shared/ClrFacade/InternalReflectionHelper.cs),
  SHA256 `42c0018013a9fc46120beea2fdc653fbbb73d050d1e67f01588b5299fc1aa345`:
  the implementation enumerates `AppDomain.CurrentDomain.GetAssemblies()` and
  reads `Assembly.Location`. This is managed-assembly evidence, **not a native
  image inventory**. Empty locations, not-found results, duplicates/ambiguity and
  changing consecutive inventories must fail identity admission, not disappear.
- The same pinned `shared/rSharp.cpp` locates hostfxr through `get_hostfxr_path`,
  then initializes from its own `RSharp.runtimeconfig.json` and loads ClrFacade.
  A successful dotnet listing does not establish which host/runtime was loaded.
- Apple's retained `/usr/share/man/man1/vmmap.1`, SHA256
  `cdd8195c81895d2dd261717aa73056e94546969ee4f887aed37888be3baaa18a`,
  documents `-w` for full mapped-file paths and, by default, only the system
  split libraries loaded in the specified process. Do not use `-v` or
  `-allSplitLibs`, which would include system libraries not loaded by that process.
  `/usr/bin/vmmap` currently hashes
  `d396d8f087ef05c626eb5e0e533f88f196550e1efbedba4413e11578615436e9`.
  No vmmap invocation was made for this proposal.

These source links are attribution to the corresponding **locally read** files,
not a new web retrieval or proof of native build attestation. No network request
was made. The SimModel source/native distinction remains exactly as in the parent
protocol: native_source_attestation=UNVERIFIED, historical_author_runtime=UNKNOWN.

## 3. Launcher and narrowly permitted prerequisite child

The old retained `Resources/bin/R` wrapper hashes
`d4d0fb318c22512f4bdf9ac40d07b940212c35cc6843c1b99a90914805967801`.
It is explicitly relocated, sets private DYLD_LIBRARY_PATH, and its `-f` branch
calls `/usr/bin/sed` twice before executing R. Its sourced `etc/ldpaths` also adds
an unrelated Java fallback directory. Reusing it unchanged would contradict a
dotnet-only auxiliary-child allowance. Do not silently allow those helpers.

**Recommended explicit launcher amendment:** execute the same retained
`Resources/bin/exec/R` directly, with `--vanilla --slave -f <fixed collector>
--args <fixed private configuration>`. Its SHA256 is
`3a64ef371bfadd5be2839300761e7bce1a59f05b9ea8f0c8c5ef37a540d33c9e`.
Provide the source-derived R_HOME/R_SHARE_DIR/R_INCLUDE_DIR/R_DOC_DIR and an
empty R_ARCH explicitly. Pin the Resources/etc startup configuration as data.
Set only the reviewed private R lib directory as DYLD_LIBRARY_PATH; do not
inherit or reproduce the Java/global fallback search. This narrow relocation
setting must be an explicit exception to the clean-environment declaration,
not an inherited loader override or a replacement native library.

Preserve the existing retained runtime path, private R library, exact DOTNET_ROOT,
single-thread numerical environment and separate private HOME/TMPDIR/cache/work.
PATH starts with the exact retained dotnet directory, followed only by the fixed
system directories needed by R's original command. Pin its resolved executable:
`dotnet/dotnet` SHA256
`5eb02c8acf243fc35f09b3fa3da80a0d03806fdb6ce2a1be18dcc333bbf5defe`.
No dotnet SDK, restore/build/package command, user startup file, proxy, credential,
Java path or arbitrary environment override is allowed. No R wrapper edit occurs.

Successful rSharp loading predicts **one prerequisite command per fresh R worker**,
not a new independent experiment: the literal command/arguments above, during
STARTUP only. A shell implementation may temporarily introduce `/bin/sh -c` or
exec dotnet in that PID. Freeze its exact source-derived command and resolved
system shell identity; do not accept a general shell or merely a process name.
Observed same-group helper identity/ancestry/arguments must agree and all helper
resources count with the R worker. No such helper is permitted after STARTUP.
Retrying initialization or a second prerequisite command stops the packet.

A minimal process-local observation/denial hook may wrap only the existing R
`system` entry point: allow exactly that literal call with the three fixed
arguments once, delegate the original implementation unchanged, retain its
returned status/output privately, and reject every other call. Its startup
begin/end metadata must be parent-acknowledged within the same worker deadline.
It must not fabricate the dotnet output or substitute a Python broker for the
original call. Pin the hook/collector separately from the untouched rSharp
source and test that the exact original call executes once in an inert double.

This hook and sampled process tree are **not an OS execution/network sandbox**.
Short-lived shell/CLI images can fall between samples. Record command-level
observations separately from sampled PID/image observations; never claim a
complete exec journal or invent missing PID samples. Any contradictory observed
helper, out-of-window child, identity ambiguity or unresolved group is a stop.
The OS-only preflight below must determine the actual platform topology before
the exact allowed transitions are frozen for a native attempt.

## 4. Static identity manifest versus live image evidence

Before a native execution decision, create and independently review a canonical
**static candidate-file manifest** without loading packages. It binds full resolved
paths, original logical paths, size, SHA256 and stable file identity for the R
executable/core/startup data, relevant installed R package code/lazy-load files,
rSharp facade/bridge/runtimeconfig, CLR/framework DLLs and dylibs, OSP managed/
native files and resolution metadata. Include the existing principal five pins
unchanged, and the R/package dependency locks; archive/package names alone are
insufficient. Reject changed files during hashing, unexplained symlink resolution,
nonregular files or unreviewed native roots. Do not recursively hash unrelated
user directories or expand the allowlist from files discovered during a solve.

Useful additional pins confirmed by byte reads in this proposal:

| Retained file | SHA256 |
|---|---|
| Resources/lib/libR.dylib | `9ed638d6cefd8a07b30c6bee1452bba5658b5903c477d272e293ef8ea3a33517` |
| rSharp/lib/rSharp.mac.arm64.so | `e9fa825acc556c4872624d4dda7ae1da0cb2907b964b87120843c14240cc8749` |
| rSharp/lib/ClrFacade.dll | `c651d5839383bb6f7e0a6fbc6254764be0fc3e4ff43225bcbb0a39a184ea918c` |
| rSharp/R/rSharp.rdb | `a9b98f8783f28d09cb7fc9196877c03a22ddadbe367d43790efdfde289b18cf4` |
| rSharp/R/rSharp.rdx | `69f790857a9d785ad9ad3c4fb5ac2ebe7e1612c23b3c68164a3a4de2ba54fe65` |
| rSharp/lib/RSharp.runtimeconfig.json | `b1040fd17ea6bafd211788f06c52379ca5145deedabff28457e025f9cc1e23c4` |
| native-artifact-manifest.csv | `cde88b47e498f9024b4a11ea299200ba0a1d651aa2a8bf310ec94a0c1334b902` |
| cran-dependency-lock.csv | `b89aabde41803970f608ac18fc5fb9a53c9e5a8d9c0c5e56e511b48dd5ca0ccd` |

The table is **not the complete allowlist**. Freezing that complete bounded list
and identifying system dyld-cache evidence remain pre-execution work. Do not
label a static dependency list `loaded_manifest_complete`.

At PRE_XML and FINAL, while the exact R process remains alive at a collector
barrier, reconcile three independent views: current managed locations from
rSharp, registered R DLLs/namespaces and their pinned code paths, and a parent-
owned `/usr/bin/vmmap -w <exact-owned-PID>` result. No process-name selector,
memory graph, memory-content read, address dump interpretation, task injection,
new native bridge or source code compilation. Parent strips address ranges from
its normalized public metadata; full diagnostic text stays private and bounded.
Separate mapped-file identity from anonymous CLR JIT memory; no claim to hash
JIT code or internal solver state. System shared-cache entries bind the exact OS
build/cache identity and explicit system status, never a fabricated file digest.

Every observed non-system managed/native file must resolve to the preapproved
manifest with unchanged bytes. Require positive nonempty R/CLR/rSharp/SimModel
evidence appropriate to the checkpoint; the exact phase-required subset is
frozen after source mapping, not guessed from basename. Preserve both live sets
and additions/removals. A newly observed allowlisted solver image at FINAL can
be lazy loading; an unknown image, absent mandatory image, truncation or unreadable
inventory fails. Do not reuse a PRE_XML list as FINAL or reuse one worker's list
for another. Rehash the observed files and all resolution metadata afterward.

Run each inspector as a separate, parent-owned bounded auxiliary process, never
as a child admitted to the R worker's group. Allow at most the two named
checkpoints per worker, each with2s wall and bounded output within the existing
per-case4MiB/packet64MiB disk limit. Proposed inspector stdout cap512KiB and
stderr cap8KiB, no truncation acceptance. Its startup/cleanup time counts inside
the worker30s and packet600s clocks. Its own process/resource/cleanup receipt
is mandatory; retain separate inspector usage so R group RSS is not mislabeled
as the total supervisor footprint. No arbitrary vmmap retry on a missing list.

## 5. Collector phases and evidence ownership

```text
fixed manifests + exact Sxx XML
  → parent verifies before files/spawn (capacity-one unresolved guard)
  → owned R STARTUP, one fixed prerequisite call, loaded runtime check
  → managed Simulation / reviewed options, PRE_XML identity barrier
  → exact LoadFromXMLString → FinalizeSimulation
      ├─ four prescribed rejections: stage + zero Run calls
      └─ positive: RunSimulation → raw grid/values/statistics
           └─ S01/S07/S08 only: same-object second Run, no retry
  → best-effort Dispose, FINAL live identity barrier
  → parent verifies exact observation + primary/cleanup evidence
  → owned group empty before anchor reap → next fixed case or STOP
```

The supervisor owns checkpoints/sequence numbers and the final result; a worker
JSON cannot assert its own cleanup or execution_verified. Each barrier has one
request/one reply bound to worker identity, case, stage and manifest. Missing,
duplicate, out-of-order, oversized or late messages stop, using the existing
monotonic deadline, never a resettable stage timer. A failed final identity or
Dispose does not erase an earlier native disagreement/rejection/error. A blocked
Dispose remains subject to parent TERM/KILL; if FINAL cannot be reached, record
it as unobserved and reject technical acceptance, not as a successful empty list.

All options must use the previously reviewed public API with exact set/readback.
Do not infer CVODES settings from a label. Keep original native arrays, counts,
finite values, initial samples and17-digit serialization. The pure comparator's
native_constant input must come from a verified public native property, **not**
length-one inference as used by the old Stage B collector. Its exact API remains
an explicit mapping gate below. No restart trace is invented.

Keep the original30s wall, CPU20/21s, sampled3GiB,100ms target/500ms max sampling
gap,1MiB per worker stream,256KiB structured observation,4MiB per-case files,
16MiB structured packet and64MiB total storage limits. All17 R workers remain
sequential and at most16 successful Run calls are prescribed. Auxiliary
prerequisite/inspection processes are separately counted, not silently included
as additional scientific cases or omitted from resource evidence. No next case
starts with less than35s remaining or any unresolved owned process.

Reuse held-waitable leader ownership and stable start/image checks before
signaling. TERM≤1s then KILL≤1s only for a proven owned group; uncertain ownership
uses the≤1s observation-only stabilization bound and then UNRESOLVED_CHILD.
Do not reap the anchor before group verification or signal by PID alone.
Evidence/write/close failure and cancellation retain primary cause and partial
stream counts/hashes. Missing parent/final receipt is never technical success;
the plan does not claim an OS sandbox or immunity to simultaneous supervisor loss.

## 6. Red-first coverage, then separately authorized OS-only preflight

No test or probe was run while writing this proposal. Write dedicated inert tests
with network/process/dlopen refusals before implementation, using authored
process and R-call transport doubles. Preserve the existing331-case pure packet.

| Path | Required negative and preservation cases |
|---|---|
| Launcher/environment | wrapper/helper not implicitly allowed; wrong exe/hash/root; inherited loader/profile/proxy/secret absent; direct argv exact |
| Startup command | exact once/delegate unchanged; wrong argument, extra option, later/second call, failed init no dotnetAvailable retry; shell→dotnet identity transition and short-lived observation honestly separated |
| Manifest | duplicate/path escape/symlink drift/change-during-hash; empty/unobservable managed location; missing required image; unknown lazy dependency; system-cache status not file hash |
| Inspector | fixed PID/argv; denied task access, nonzero exit, malformed/truncated/missing output, stalled process, cleanup/close failure; no substitute stale checkpoint |
| Collector | original call sequence and four native rejection stages; no Run after rejection; same-object repeat only; readback mismatch; raw native constant/property failure; arrays never borrowed from oracle |
| Boundaries |30s/600s shared clocks;1s/1s owned termination;500ms sample gap; zero valid samples; stream/disk/RSS overflow; waitable short exit; unexpected descendant; ambiguous identity; second-entry refusal |
| Retention | primary error plus Dispose/identity/write/cleanup errors; FINAL missing; fake success with nonzero exit; all remaining cases NOT_RUN |

The new OS interfaces and allowlisted prerequisite transitions cannot be accepted
from mocks alone. Recommend a **separately reviewed OS-only schedule**, before R:
owned inert worker pauses at both image barriers; fixed vmmap query of that exact
worker; short clean exit; timed-out inspector; TERM-ignoring worker/descendant;
parent-side cancellation; identity ambiguity and unresolved-second-entry refusal.
Use only authored nonnumerical children and existing OS/Python tools. No dotnet,
R, CLR, OSP library, model or technical fixture evaluation in that preflight.
Freeze exact case count, hashes, ABI/OS identities and total deadline before it is
authorized. It tests observation/ownership, not actual rSharp startup semantics.

## 7. Decisions and remaining admission gates

1. Root must approve the direct retained R executable/explicit private loader
   environment instead of silently broadening the old shell-wrapper helper set.
   It is source-derived but not yet executed in this configuration.
2. Root must approve fixed vmmap checkpoint ownership and the process-local
   exact `system` observation/denial hook. Native images are not supplied by the
   managed assembly list. A privileged/unobservable vmmap path must fail, not
   trigger sudo, security-setting changes or an alternative memory API.
3. Freeze complete resolved runtime/system manifest and the supported public
   native-constant/options/settings API from pinned primary source before code
   uses it. No local complete SimModel source/API file or executed property
   inspection was available in this task. Source reading may be authorized
   separately; no current-master/API guessing or native metadata exploration.
4. Freeze exact OS-only preflight after inert implementation review; then a
   separate hash-bound17-case native decision. Pure tests, an OS pass and this
   proposal are not permission to launch the native packet.

Architecture review identifies these real boundary decisions; code-quality review
recommends two new narrow files with no generic framework; test review maps each
branch above; performance review retains all existing clocks and adds inspector
cost inside them. No numerical tolerances or resource limits may be raised after
failure. This is a **proposal with concerns**, not an execution-ready declaration.

NOT in scope: GIM reruns or source alteration; native rebuild/upgrade; arbitrary
XML/formulas; clinical/compound inference; tracing solver internals; collecting
memory contents; global process monitoring; installation or distribution of a new
product artifact. The original numerical FAILED/static receipts and all six
required programs remain open and unchanged. Lesson: an allowlisted file is not
proof of a loaded image, and a source-predicted startup command is not a complete
OS process journal. Preserve each evidence level explicitly.

## 8. Pinned public-API semantics correction and phase subset proposal

Root requested this correction after reading the pinned public implementation.
It supersedes the independent-native-property requirement in sections5/7 and
the older protocol's corresponding claim, not the numerical tests. The preceding
307-line source-only candidate remains attributable at SHA256
`faba3876a6fc563621ba62bd3a6881d3a3cf7e33d59145b05832305dd44b8f5c`.
Root authorized a narrow web fallback because the previous browse startup failed;
the four fixed source files below were read completely through that fallback.
Thus section2's no-network statement describes the original candidate only.
No browser, R, CLR, assembly metadata evaluator or native probe was launched.
No raw-source byte digest is asserted from the web tool's rendered text.

### Public flag, stored length and option evidence are different claims

At commit `395dccf72a310b0485e63928741703045a1b40aa`, public
`VariableValues.IsConstant` calls the stored-value-size API and tests size equal
to one. The internal `QuantityIsConstant` import is not used by this getter.
`Values` separately retrieves size and fills the array. Record the public flag
and actual returned length separately; neither independently proves semantic
constancy. Missing/malformed flag or inconsistent shape fails collection; do not
substitute a collector-computed flag, reflection or a native bridge.
Source: [VariableValues.cs](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModel/VariableValues.cs).

Proposed outer per-output evidence is `public_is_constant` (strict boolean),
`stored_length` (exact returned array length),
`constant_flag_basis="MANAGED_API_STORED_SIZE_EQ_ONE"` and
`native_semantic_constancy="UNOBSERVED"`. Preserve all raw values, counts and
bitwise repeat comparisons. For compatibility only, the unchanged comparator's
legacy `native_constant` field receives that public flag, explicitly identified
as this legacy spelling in the receipt. Scalar expansion remains comparison
normalization, never an additional sampled trajectory or constancy proof.

The `SimulationOptions` constructor initially fills its managed struct from the
native API. Public setters update that struct then call the native setter;
getters return cached fields, not a fresh native read. Set the existing two
options (`AutoReduceTolerances=false`, `StopOnWarnings=true`) and retain exact
managed readback. A match establishes requested/managed option evidence only.
Source: [SimulationOptions.cs](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModel/SimulationOptions.cs).
Use outer `managed_options_requested`, `managed_options_readback` and fixed
`native_options_readback="UNOBSERVED"`. A setter exception or mismatch fails;
do not claim a no-exception setter independently verifies native configuration.

`Simulation.RunSimulation` copies successful native out-parameters into
RunStatistics before collecting warnings. The statistics object begins with
false/NaN values, so read it only after the prescribed successful call and never
promote initialized/stale statistics following failure. Label it
`MANAGED_REPORTED_NATIVE_RUN_OUT_PARAMETERS`, not independent solver-state
inspection. The public managed constructor/load/finalize/dispose boundaries are
also directly confirmed. Sources:
[Simulation.cs](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModel/Simulation.cs),
[SimulationRunStatistics.cs](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModel/SimulationRunStatistics.cs).

These are source-defined API meanings, not attestation that the retained native
bytes implement the same source. Keep native_source_attestation=UNVERIFIED and
historical_author_runtime=UNKNOWN. No formula,17-case schedule, oracle, tolerance,
pure schema/digest, scalar normalization or failed Stage B receipt changes.
Add inert tests for flag/length mismatch, missing public property, option setter
failure/cached readback, no statistic reuse after failed Run, and fixed evidence
labels. They test collection honesty, not native semantics.

### Exact proposed minimum live-image set; completeness remains gated

All paths below are relative to the single retained runtime root. At PRE_XML,
after successful bridge initialization, Simulation construction and option calls,
the following minimum must be positively identified. Require it again at FINAL
while R/CLR and the collector remain alive. This is a proposed admission policy,
not an observation of this unexecuted collector configuration. Managed names must
resolve to exact paths, and native paths must be present in the parent's live
image inventory; a basename or static file alone does not satisfy the gate.

| Exact retained relative path | Evidence channel | Rationale |
|---|---|---|
| `r-unpacked/R-fw.pkg/Payload/R.framework/Versions/4.6/Resources/lib/libR.dylib` | native | Running retained R core |
| `r-library/rSharp/lib/rSharp.mac.arm64.so` | native and R DLL list | Explicit pinned bridge load |
| `dotnet/host/fxr/8.0.30/libhostfxr.dylib` | native | Pinned rSharp loader retains its dlopen handle |
| `dotnet/shared/Microsoft.NETCore.App/8.0.30/libcoreclr.dylib` | native | Hosted CLR execution |
| `dotnet/shared/Microsoft.NETCore.App/8.0.30/System.Private.CoreLib.dll` | managed | CLR core assembly |
| `r-library/rSharp/lib/ClrFacade.dll` | managed | Initialized facade |
| `r-library/rSharp/lib/RDotNet.dll` | managed | SetRDotNet(true) converter initialization |
| `r-library/ospsuite/lib/OSPSuite.SimModel.dll` | managed | Explicit Simulation class |
| `r-library/ospsuite/lib/libOSPSuite.SimModelNative.dylib` | native | Simulation constructor/options native calls |

Additional byte-read pins (no loading) are respectively:
`libhostfxr.dylib=aa5afa3d78b86e2d0565a35fb8e51dcc1dd4f8b1e6ee6780d875b44abf4006df`,
`libcoreclr.dylib=b4ff459f2aee2235fba12eab2939a2c4e2f8aa079fa651138762ad71cd85bfbe`,
`System.Private.CoreLib.dll=9bfdc5f5c3e8779bb3aea4a933ef01e2408b77b239d39836b1feee54b133d1c9`,
`RDotNet.dll=9e2e009c333ed9265adb8b493cec45f4624e041d348ddba02f6904f20867397d`.
The other five pins are already in section4/the frozen principal-pin set.

`libOSPSuite.SimModelSolver_CVODES.dylib` remains an exact static required pin
(`19453818ef70c4b722f7aba518660927ac005e9b89ba8621598ec0038d99e257`).
Its live-image lifetime across Dispose is not established by the four managed
sources. Therefore this proposal does **not** yet assert it must be absent at
PRE_XML or present after Dispose. Freeze a source-supported positive-run phase
rule before code, or obtain root review for moving the existing FINAL barrier
before Dispose with separately retained cleanup evidence. Do not add an extra
native load/call/checkpoint merely to force visibility, or silently drop solver
identity from the admission requirement. Expected rejection cases do not imply
that a solver was loaded or called.

The nine-entry minimum is not a full dependency closure: OSPSuite.Core and
ConsoleApp.deps retain their original static pins; other managed dependencies,
libhostpolicy, R package native DLLs and system-cache files must be resolved into
the complete static allowlist without claiming each is phase-mandatory from file
presence. Missing closure/system-cache identity and the solver lifetime rule
remain implementation-admission blockers. No allowlist is expanded from a solve.

**Frozen proposal status:** public constant/options mapping is resolved with
explicitly limited meanings; direct launcher, private loader environment, exact
startup hook and vmmap ownership still need root approval. Complete file closure,
solver phase evidence and the separately bounded OS-only preflight remain to be
reviewed. This is not permission to implement or run. Do not expand this into a
generic monitor; product work remains the priority.

## Root decision after independent review

Root read all422 frozen lines, the parent307-line protocol, source map, pure331
receipt and biological change contract. Root also read the retained rSharp
startup/assembly functions, reflection helper, relocated R wrapper/ldpaths and
the four pinned public API implementations. release_redteam independently read
the same proposal/source boundaries and conditionally cleared it. The frozen
pre-decision proposal SHA is
`03603a60ef65d2d3ce2aac70f215f2324632461c18cbcddd93e24c95be94b955`.

The following three explicit precisions are approved:

1. Move the existing FINAL live-image checkpoint before Dispose, after the last
   prescribed Run and raw-output capture (or prescribed rejection). No extra
   checkpoint, model load, run or numerical change. For successful positive
   cases, actual CVODES image presence at this checkpoint is an admission gate,
   not a source-proven lifetime fact. Absence fails identity admission; do not
   force-load it. Dispose, original process exit and owned-group cleanup still
   follow and each can independently prevent acceptance. Expected rejection
   cases require no invented solver load or call.
2. The OS-only preflight can establish inspector permissions/format and process
   ownership behavior, but cannot establish R/dotnet startup topology because it
   does not execute them. Later native admission must retain observed startup
   command and process evidence separately from source predictions. A short-lived
   child missed by sampling is not a fabricated complete exec trace.
3. Identify and wrap the namespace-visible original `system` binding before
   rSharp `.onLoad`; a global shadow is insufficient. Delegate the single exact
   approved command unchanged. Preserve rejection/init/readback evidence and
   stop on failed initialization. No rSharp source-byte modification, reflection
   call to private native APIs, or retry through dotnetAvailable is permitted.

The direct retained R executable and explicit private loader environment are
approved as the intended launcher, not yet an executed configuration. The owned
vmmap checkpoints and narrow process-local command hook are approved design
choices, not an OS sandbox or human-equivalence test.

Next authorized increment is static retained-file/system identity inventory and
exact collector call/binding/argv mapping only. Use bounded named runtime roots,
no arbitrary home traversal, code loading, compilation, package installation,
R/dotnet/CLR/native invocation, browser or service. Resolve the remaining file
closure and R binding mechanism from pinned source before collector implementation.
Preserve the original17 cases,16 prescribed Run calls, all30s/600s/resource limits,
pure schemas/digests and failed Stage B evidence. No new native-source attestation
standard is imposed: any eventual result remains technical behavior on exact
retained bytes with source attestation UNVERIFIED and historical runtime UNKNOWN.
Collector implementation, OS-only preflight and the native packet remain separate
review decisions; no generic supervisor or product API is authorized here.
