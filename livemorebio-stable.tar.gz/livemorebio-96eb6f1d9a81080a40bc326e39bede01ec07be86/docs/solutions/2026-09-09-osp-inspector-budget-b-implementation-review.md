# OSP inspector budget B: offline implementation evidence

2026-09-09, maker release_redteam; root is independent grader.
The pre-code addendum is in `2026-09-09-osp-vmmap-unused-region-parser-amendment.md`,
SHA256cc16b2201258cc02671872a69662033cf8da3630baed118d3bcb6ac2623997e5.
Root approved only prospective3s complete/2.5s work with existing0.5s inspector
cleanup and at least6s parent remaining before directory/spawn. Worker30s,
packet600s, ownership/resource rules and both closed gates remain unchanged.

## Initial RED retained; temporary source hold

New21 authored cases: `livemorebio/tests/test_osp_inspector_budget.py`, SHA256
e7b89f864ed6c9fdc2726758b533831d1b0d8478a7d0ae34442a01dbd12655c6.
Actual original-source result: **19 failed,2 passed in1.41s**, exit1,
session60474, completion chunk181f3c, private dkg3wk9b, unexpected I/O0.
Failures are the old2.0 limit/deadline and missing pre-directory reserve check.
The two actual `_execute` control-flow preservation cases already pass with
authored children: work cutoffs2.5/27 and unchanged complete deadlines3/30.
The overlong-receipt tests initially reach the old launch-deadline assertion
first, not their downstream receipt admission assertion; do not overstate RED
as independent execution of every later branch.

The real callback, barrier admission, control JSON, file writer, vmmap parser
and process receipt admission are retained. Only the actual execution/image
transport is authored; no native process, R/CLR/model/OS inspection occurs.
Both PRE_XML and FINAL are mounted at their respective expected sequence,
not represented as an executed four-stage R lifecycle.

Root then identified a new molecular build that still pins d2ac and required a
source hold. Supervisor remains exact
d2ac1bac780fbbeec7ad759994068104db8cb1eb70c95a3b3180696999117235.
No runtime edit or inherited assertion migration occurred before this RED.
Implementation/green/preservation are pending explicit root source release.

## Durable original evidence and repeat

New private evidence root: `/private/tmp/livemore-osp-budget-b.BMjF7I`.
`initial-red.json` retains original launch/completion tool text, session ID,
source/test pins and exact original scope. `repeat-new.sh` is the exact guarded
command; run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`.
It uses the existing private45s wrapper and interpreter
`/Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B`,
plugin autoload/cache disabled, socket/network/child/ctypes refusal. Authored
test doubles replace only named boundaries and actual OS activity remains
refused by the audit hook. No actual native_watchdog case is run.

Full original before-images are retained and hash-verified for later diff:

| Private before-image | SHA256 |
|---|---|
|osp_semantic_supervisor.py.before|d2ac1bac780fbbeec7ad759994068104db8cb1eb70c95a3b3180696999117235|
|test_osp_semantic_supervisor.py.before|36f1454cc22f229bfe8410c7e31728fac70961856d07671c2765a50e1c9571ee|
|test_osp_vmmap_format_contract.py.before|c574694d7a5b271078f98013e6873f48c207b117751cbb703cf478c964155415|

These are evidence copies, not replacement code or consumed-run patches.
No old private driver, authorization, marker, failed O1 receipt or later
failed diagnostic receipt was changed or rerun. No scientific or OS-preflight
gate is opened by this packet. Final implementation evidence will be appended.

## Implementation after explicit source release

Root reported the fresh IviiqA molecular A/B run settled with preserved inputs
and explicitly released the d2ac hold. Only then was budget B implemented.
This paragraph supersedes the temporary pending status above, not the retained
RED or historical failures.

The complete diff against the three retained original files is
`reviewed-delta.diff`, SHA256
fee39f1a9b0a417197b871e265ee0208c393cd3b71747ccd0acc53b964f38dea.
Production change is three replaced lines and two added lines in the supervisor:
line46 sets3.0; lines794–795 capture the clock after owner proof and reject
less than6s remaining before mkdir; line800 uses that captured clock plus the
same limit; line806 admits the receipt against the same limit. No new helper,
process abstraction, retry or schema was introduced. Directory/setup time is
inside the captured complete allowance. The unmodified `_execute` subtracts
0.5s inspector cleanup or3s worker cleanup from its existing passed deadline.

Exactly the two approved inherited assertion literals changed2→3. The new
166-line/21-case test file is byte-identical to its original RED. No fixture
correction or assertion weakening occurred between RED and GREEN.

| Frozen file | SHA256 |
|---|---|
|tools/osp_semantic_supervisor.py|8f8c1f66be57f0466a4481fc5cc1b095e6ed47a3e01564f850ae9cf0aa17b79a|
|livemorebio/tests/test_osp_inspector_budget.py|e7b89f864ed6c9fdc2726758b533831d1b0d8478a7d0ae34442a01dbd12655c6|
|livemorebio/tests/test_osp_semantic_supervisor.py|0d6bd396e8d0a15953719746133e960896c51cea9cc610d818a8d4e84f37fe41|
|livemorebio/tests/test_osp_vmmap_format_contract.py|e00132655ef15c9ba4b7f3a4f5c5d5fb95abe525f15e7abce6be1329e2e91865|

Pure tool12585d9b…, pure tests5c4d2910…, collector R3ba6559b…,
V2 inventoryd09b1f5d… and retained forensicsbeab9fe2… were rehashed before and
after and remain unchanged. Product Python/JS, registry, molecular source,
private executed drivers/markers/results were not edited.

## Actual inert GREEN and preservation

- New packet: **21 passed in0.17s**, exit0, chunkcbb6d1, private6njlmnua,
  unexpected I/O0.
- Full packet: **524 passed /2 deselected in1.46s**, exit0, session22964,
  completion chunkbb9d64, private9sgkjvna, unexpected I/O0.
  This is21 new +43 portable parser +440 prior offline +20 explicitly
  invoked retained-forensic cases. The two actual native_watchdog cases remain
  excluded, not passed. Full preservation does not invoke the old OS driver.
- `green.json` retains both complete tool outputs and exact source/test pins,
  SHA2561d23a4d9bd2326d6fe5ff558bf47db8089da45f9efa6505d85edad3a0463ab8b.
  Initial RED remains `initial-red.json`,
  SHA2569204c180d967e79b7b1c4223023abd32335b0b13bb340da7486d0d749203488a.

The actual callback tests now reach both2.5/3.0-second receipt acceptance and
3.000001-second refusal. For both phases, late5.999999/3/0 and the owner-proof
cost crossing leave only the byte-identical input request, no inspector
directory/files, no execute or ACK. Actual `_execute` logic under authored
child/OS doubles reaches2.5/27 work deadlines and the unchanged3/30 complete
cleanup deadlines. These are deterministic control-flow tests, not measured
OS inspector latency, real cleanup confirmation or runtime image proof.

## Exact independent full repeat

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`.
The same command is retained as private `repeat-full.sh`, SHA256
b450a4c7248cd437f3dc3da50ad5ab046723c65af3a6353514a56187aedd1893.

```bash
PYTHONDONTWRITEBYTECODE=1 /Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B - <<'PY'
import os,sys,signal,socket,subprocess,urllib.request,multiprocessing.process
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:v for k,v in os.environ.items() if k in ('PATH','HOME','TMPDIR','LANG','LC_ALL')})
env.update(PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1');os.environ.clear();os.environ.update(env)
counts={'unexpected_io':0}
def deny(*a,**kw):
 counts['unexpected_io']+=1
 raise AssertionError('Unexpected network, native load, or child in offline OSP budget tests')
for owner,names in ((socket,('socket','create_connection','getaddrinfo')),(subprocess,('Popen','run','call','check_output')),(urllib.request,('urlopen',)),(multiprocessing.process.BaseProcess,('start',))):
 for name in names:setattr(owner,name,deny)
def hook(event,args):
 if event in ('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.exec','ctypes.dlopen'):deny()
sys.addaudithook(hook);signal.alarm(45);print('Private test root:',root,flush=True)
import pytest
code=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(root/'pytest'),'--tb=short','livemorebio/tests/test_osp_inspector_budget.py','livemorebio/tests/test_osp_vmmap_format_contract.py','livemorebio/tests/test_osp_semantic_supervisor.py','livemorebio/tests/test_osp_semantic_probes.py','livemorebio/tests/test_osp_source_admission.py','livemorebio/tests/test_osp_stage_b.py','livemorebio/tests/test_osp_stage_b_analysis.py','tools/diagnostics/osp_vmmap_retained_forensics.py','-k','not native_watchdog'])
print('Refusals:',counts,flush=True);signal.alarm(0)
raise SystemExit(code or bool(counts['unexpected_io']))
PY
```

The new-file-only command is private `repeat-new.sh`, SHA256
e895472dcca05a91c54abecaf527804f68a68a7db94ed5258112ba0453dcd676;
it differs only in selected test paths/no -k filter. Missing local forensic
originals fail their explicit check, not skip. Default portable tests remain
independent of those private historical artifacts.

## Disposition and compounded lesson

Frozen for root's independent complete source/diff/test review. No maker
self-clearance or execution authorization is implied. Both scientific/OS flags
remain false. Original O1 FAILED hash1bbb6d32… and diagnostic FAILED
hash4c437eaa… remain preserved and checked by the unchanged local forensic tests.

After independent acceptance, root may separately authorize preparation of a
newly pinned seven-condition OS-only preflight. No such preparation or run is
part of this implementation, and no numerical test follows automatically.

Lesson: a nested tool budget must reserve parent cleanup *before* allocating
its output directory or child, and receipt admission must use the same declared
limit as launch. Capture the clock after ownership proof, avoid resetting the
deadline after setup, and retain original timed-out/format-failed evidence when
making an explicit prospective engineering change.


## Root independent implementation grade

After the molecular pair settled and its final input check passed, root released
the d2ac source hold. Root then read the full actual supervisor delta against
the preserved before-image, both exact inherited one-literal test migrations,
and all21 new cases. No additional runtime change was found: inspector complete
budget3s, one post-proof clock, six-second parent reserve before directory/spawn,
and the same limit in launch/admission. Source hash is
`8f8c1f66be57f0466a4481fc5cc1b095e6ed47a3e01564f850ae9cf0aa17b79a`.

Independent guarded repeat: **524 PASS,2 native_watchdog cases deselected,
1.63s**, session36034/completion4a58a5, private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-kqoxs1j6`,
unexpected I/O0. The unchanged20 explicit retained-forensic checks were included.
This is narrow offline budget/ownership regression acceptance; it is not actual
OS inspection, native/source admission or numerical/clinical validation. A new
seven-condition preflight requires its own exact reviewed plan and authorization.
