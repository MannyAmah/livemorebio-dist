# Continuous workspace: visible science and readable control state

2026-09-08. R04/R21/R24/R26/R27/R46 follow-up. Pre-code correction packet;
root owns implementation, independent review required. Approved A+B and all
scientific/program requirements remain unchanged.

## Actual browser evidence and problem

Root's attempt 4 passed the full current-source LIFE→Biology→LIFE lifecycle:
50.684 seconds,42 acknowledged native frames, genuine hidden-tab polling pause,
producer/LIFE pause and explicit resume, seven reference organs, mobile layout,
zero JavaScript errors and both owned services stopped afterward. All nine
screenshots and metadata were personally inspected. This is an engineering
workflow pass, not visual-design acceptance or one of six experiment videos.

The screenshots still expose three product defects:

1. Preparation consumes the first viewport after execution starts. Reopening a
   fixed execution leaves the unrelated active-source preparation text saying
   “Reading…” even though that read is intentionally never performed.
2. Full-precision scalar strings, internal field names and repetitive identity
   text dominate primary controls. Biology geometry is below three large plots.
3. LIFE's public projection labels every outstanding receipt `blocked`, even
   during healthy in-flight forwarding. A pending ACK is not a transport failure.

## Minimum-diff selected approach

Reuse the existing shared continuous controller and independent anatomy viewer.
No physiological equations, source bindings, stores, clocks, polling ownership,
control revisions, automatic retries or mutation behavior changes. No new page,
framework or replacement of the deeper Biology/whole-person Atlas distinction.

- Make preparation a native keyboard-accessible disclosure: open on fresh
  preparation; collapse only after an explicit successful start or fixed-source
  selection. Do not re-close it on polling after a user opens it. Its fixed-source
  summary says preparation is separate; opening can deliberately read the active
  source, but does not activate/create/bind/start anything. No permanently pending
  “Reading…” message without an actual request.
- Keep engine, LIFE and receipt state plus applicable lifecycle buttons visible.
  Put verbose IDs/revision explanations in a clearly labeled disclosure; exact
  IDs/control fences remain in state and provenance. Do not hide actual failures.
- In Biology, place the existing reference inspector beside the native traces,
  before them on mobile. Keep its reference-only label and all existing controls.
  LIFE retains its own compact native trace workspace. Provenance is accessible
  beneath the primary work, not an empty full-height column.
- Format only presentation labels to six significant digits, using scientific
  notation for tiny/large values. Preserve zero, sign and null/unavailable. Plot
  positions, comparisons, original arrays, hashes, exports and inspected raw
  values remain unchanged. Provide the exact raw value in a readable disclosure;
  rounding is not biological precision or a numerical-error tolerance. Quantity
  labels retain their units and compartments; no disease/physical-effect label.
- Public delivery projection: outstanding envelope with active waiting/streaming
  state is `pending`; outstanding envelope in paused/stopped/interrupted/blocked
  state remains `blocked` (explicit lifecycle state still explains why). No
  pending envelope preserves existing acknowledged/not-delivered semantics.
  A new ACK is the only basis for advancing its existing counter/timestamp.

## Red-first acceptance and ownership

Root may edit `continuous_execution.js/css`, a small pure presentation helper,
and `life_patch/virtual_execution.py` projection only after this packet is
reviewed. Do not edit Atlas files or original Biology geometry placement.

Tests must fail first for presentation of zero/tiny/negative/nonfinite values,
unchanged arrays, exact raw availability, source disclosure initialization and
one-time collapse, visible geometry ordering, and pending-vs-blocked states.
Retain control/client/source/hidden-tab and physical-evidence checks. Reviewer
inspects the diff; root reruns the actual browser with new build identity and
checks all nine captures plus disclosure keyboard behavior. Preserve attempt 4
as the passing pre-readability baseline; do not overwrite it or reuse its pass
for the changed source.

Full-product visual acceptance, true spatial biology, six complete experiments,
recordings and public release remain open. This correction cannot close them.

## Independent pre-code review and root acceptance

Source reviewer read the current controller/projection and identified three
required compatibility cases. Root accepts this packet with these additions:

1. `execution_view_state.js` strictly validates delivery-status enum values.
   Add `pending` to that exact contract with negative tests; all source, revision,
   counter and evidence checks remain unchanged.
2. Internal selection after Prepare is not an operator reopening a saved/fixed
   source. Keep preparation open through Prepare→Bind LIFE; collapse after an
   explicit successful Start, or external fixed-source selection only. A user
   may reopen the disclosure without polling closing it again.
3. Keep the exact-values disclosure outside the replaced quantity-article DOM.
   Updating raw values must preserve the disclosure element, open state and
   keyboard focus. Test this over subsequent frames and a failed refresh.

Geometry reordering uses the document's actual reading order, not a CSS-only
visual rearrangement. The same source-specific mount/dispose remains. Root may
now write red tests and implement the bounded patch; independent diff review
and rendered reacceptance are still required.

## Maker packet

Six new checks failed before implementation; twelve preservation cases passed.
The implemented packet passes **147 targeted tests in 2.82 s**. Two existing
mounted tests initially failed because revision text moved from the primary
status heading to the identity disclosure; assertions now require the same exact
engine/LIFE revisions at that new location plus the correct visible state.
No control guard or conflict assertion was removed. Eight harness guard tests
also pass. The expanded real-browser harness will check preparation stays open
through binding, successful-start collapse, keyboard-expanded exact values and
focus through native progress, document reading order and fixed-source reopen.
This is not yet independent or rendered acceptance of the new source.

## Independent checks and first rendered diagnostic

Independent reviewer ran 147 targeted cases successfully in 2.36 s. Root's
current-source attempt 5 failed at its first-frame browser assertion; both newly
owned execution and LIFE session stopped during cleanup. The producer had started and frame 1 was
acknowledged. Root inspected the failure image and then read the same stopped
source in the browser: the provenance disclosure was closed, `innerText` of its
timestamp paragraph was empty, and `textContent` contained the correct clocks.
All three quantity articles were present and preparation had correctly closed.
The harness still expected visible text from a now intentionally closed panel.

Before rerunning, correct only this harness assumption: check stored metadata
with `textContent`; independently open the clocks disclosure with the keyboard,
assert its actual visible timestamp text, then close it. Give the first-frame
stage its own name. Preserve the failed attempt and add a regression assertion
before the harness change. No product, model, acknowledgment or lifecycle change
is warranted by this diagnostic. The later induced-GET-failure check remains
explicitly technical and must retain exact values and focus before read recovery.

## Rendered acceptance and retained lesson

Root's attempt 6 passed at package source `08aba1ee…`: ten screenshots, 56.387 s
observed after Start, 44 acknowledged native frames at the final metadata read,
zero browser errors, both owned records stopped during cleanup. It includes
actual keyboard-visible clocks, exact-value/focus preservation through native
progress and an explicit technical read failure, recovery, pause/resume, genuine
hidden-tab behavior and desktop/mobile Biology. Root read the full receipt and
personally inspected every image. Independent evidence review is separate.
See the exact full identities and retained attempts in
`docs/screenshots/full-scope-recovery/continuous/qa-progress.md`.

Lesson: a disclosure change alters rendered text availability even if stored
DOM text is unchanged. Verify metadata from text content and verify discoverable
content through real visible controls; neither alone proves both contracts.
Keep the disclosure node stable while replacing its data so polling cannot steal
focus. Source/clinical qualification, whole-person Atlas and full-product release
remain explicitly outside this bounded engineering acceptance.

The independent reviewer subsequently read the complete attempt-6 receipt and
personally inspected all ten captures, clearing this bounded workflow. The
service processes remained up; cleanup stopped only the owned execution and
LIFE session. This does not close full-product or physical validation gates.
