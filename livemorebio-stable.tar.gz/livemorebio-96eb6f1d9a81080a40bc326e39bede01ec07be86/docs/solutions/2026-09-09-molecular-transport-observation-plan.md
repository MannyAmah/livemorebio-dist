# Molecular transport: passive observation before a product change

2026-09-09. Continuation of the approved correction-first plan. This is a
diagnostic amendment, not a new feature, scientific experiment or release gate
waiver. R01–R51 and all six exact experiment recordings remain open.

## Decision and evidence

The retained kCPxWp browser packet is FAILED even though all four interaction
stages and 11 images passed. Its first original KRAS coordinate request failed
before D1 and any explicit retirement. The unchanged reader reached exact
length, EOF, digest verification and parser checks; it does not cancel at EOF.
The server recorded intended bytes, not response finish/close. Installed
Playwright's Chromium adapter forwards Network.loadingFailed into the failed
request event, but the checker did not retain the underlying canceled/blocked
fields. Neither application success nor a failed terminal identifies the cause.

Prior art: the Atlas terminal-cause supplement identified the same missing
protocol evidence, but its reader differs. Do not copy an Atlas cancellation
diagnosis into this case. Local pinned Playwright source and protocol type
definitions are the API references; context7 and gbrain are not callable in
this session. Their use is not claimed.

## Bounded proposal for independent pre-code review

Prepare a fresh private successor to kCPxWp, leaving all consumed roots and all
product/source/bundle files untouched. Retain the same four stages, 11 original
captures, six exact structures, unavailable-human-INS check, CSP, local route
firewall, timers and once-only Python supervisor. Repeating these existing
interactions is preferable to inventing a different workload whose successful
transport would not explain the failure under inspection.

Add only passive, bounded diagnostic observations:

1. For each admitted local request, retain a local ordinal and server
   finish/close/aborted/error facts with Node-monotonic observation times and
   explicit writableFinished/complete booleans when applicable. Do not read a
   second body, alter headers, delay a response or change route admission.
2. Attach an owned read-only CDP Network observer before each page navigates.
   Map only exact admitted URLs to bounded local ordinals. Retain request start,
   response status, loadingFinished/loadingFailed, original protocol timestamp,
   canceled, sanitized blocked/error enums and encodedDataLength when supplied.
   Unknown protocol IDs or duplicate/ambiguous terminals remain explicit errors.
   No headers, cookies, initiator stack, response body or arbitrary URL is saved.
   Do not use CDP Fetch commands or change existing interception/cache/CSP policy.
3. Keep Playwright's original terminal ledger unchanged. Correlate by page plus
   exact route and occurrence; the same route in desktop and mobile is not the
   same request. Retain separate clocks rather than claiming network timestamps
   are synchronized with page or Node clocks.
4. Own each CDP session explicitly under existing bounded cleanup. Detach it
   before explicit page retirement and before final page cleanup, recording that
   observation cutoff. Do not call an absent or failed detach settled. Retain
   all known resource ownership and late-allocation protections.

At most 128 request identities and 512 sanitized events per observer plane,
with a 256 KiB serialized bound for the added evidence. Overflow or unsupported
identity/clock/value is a diagnostic failure, never silent truncation. Existing
32 MiB response/64 MiB total evidence and all time limits remain unchanged.
Capture collection may succeed while transport remains FAILED. Any new packet
preserves the original rule that a failed request cannot yield overall PASS.

No fetch, Response, ReadableStream, reader, abort or releaseLock wrapper is
proposed. No extra fetch, response.finished wait, library upgrade, model run,
registry mutation, PHI, hardware command, vendor publication or consumer switch.

## Verification and interpretation

Write failing tests first for exact-route/occurrence identity, malformed fields,
optional values remaining null, failed/success terminal distinction, independent
clocks, fixed caps, no payload/secret retention, server close versus finish,
session ownership/late allocation and observer detach. Preserve all 65 parent
inert tests and byte-pin all unchanged inputs. Root independent code/test review
must precede a separate once-only actual-run decision; this plan itself does not
authorize a browser invocation.

- CDP FAILED and Playwright FAILED: native transport failure is corroborated;
  canceled is a protocol fact, not proof of an application AbortController call.
- CDP FINISHED and Playwright FAILED: retain disagreement and inspect adapter
  identity handling; do not treat either ledger as a substitute for the other.
- Server finish with browser failure: server finish does not prove client
  completion. It narrows the missing evidence without declaring a cause.
- All observers finish: the new attempt did not reproduce. It does not erase
  old failures, prove a fix, or authorize repeated sampling.

Stop after the one separately authorized attempt and inspect its original
receipts/images. A product correction requires a demonstrated cause and its own
red-first review. No automatic retry or expanded implementation is authorized.

## Independent pre-code refinements accepted by root

The reviewer cleared the passive-only, unchanged-workload design with three
precisions. Root accepts these before implementation:

- The pinned private page has a `data:,` favicon and its CSP permits data images.
  Installed Playwright deliberately ignores data-URL requests. If raw CDP emits
  them, retain only a bounded DATA_NON_NETWORK identity class (no URL/body),
  within the same total caps. Unknown HTTP(S) URLs, unknown terminal IDs and
  malformed identities still fail; data identities cannot excuse a network one.
- New server error listeners must record a fixed failing code, never suppress an
  otherwise unhandled error into success. Request abort, response close and
  response finish remain different facts. A close is not automatically failure,
  and writableFinished is not a browser acknowledgment.
- At observer cutoff, retain every pending admitted identity as incomplete and
  fail diagnostic admission. Own detach with a real close-compatible wrapper;
  absent, rejected or unresolved detach must not become SETTLED. Preserve the
  parent late-allocation and reverse-ownership protections.

Implementation is limited to a fresh private diagnostic successor and red-first
inert tests. Add focused branches for these refinements; preserve all 65 parent
checks. No product edit, actual browser run or publication is authorized yet.

## Frozen implementation receipt — independent grading pending

Fresh private root:
`/private/tmp/livemore-molecular-transport-browser.OYVOcS`.
Its `run` directory does not exist. No browser, service, native/scientific
execution or product edit occurred. The consumed kCPxWp result remains FAILED.

Only private `check.cjs` and additive `test-check.cjs` changed behavior. The
Python supervisor, inert wrapper, Python tests, page HTML and page JS are
byte-identical. All original 59 Node test bytes remain an exact prefix; the
original six Python checks remain unchanged. `inputs.json` differs only in
the first two private page paths and their exact integer mtimes; all content
hashes, sizes and the remaining 20 input rows are unchanged. The eight private
pins were refreshed losslessly. A final read-only check verified all 30 pins
in both the original consumed root and the fresh root.

The observer adds Network.enable only, with four passive CDP event listeners.
Its close-compatible owned wrapper retains late allocations and detaches before
page retirement. Original Playwright terminals still record after that cutoff.
Server finish/close events after cutoff are explicitly labeled; errors always
set the original failure path. A later finish cannot erase the stored list of
pending identities at cutoff. Correlation is labeled PAGE_ROUTE_OCCURRENCE_ONLY;
server page attribution uses the serial active-page scope, not a browser ID or
proof that two clocks are synchronized. No body/header capture, arbitrary URL
retention or fetch/reader/abort wrapper was added.

Root's review found that a 256-byte reserve could lose cutoff facts near the
serialized cap. The accepted correction derives a tail before server/browser
creation from `L`, the largest complete JSON correlation row for any admitted
route (including escaped/UTF-8 bytes, maximal counters and null IDs):
`384*(L+1) + 384*4 + 2*1024 + 384 + 512` bytes. This covers at most 384
correlation rows and pending ordinals across both pages, two fixed cutoff
envelopes with 32-character numeric-clock allowance, all identity-state growth
and fixed failure/detach labels. Ordinary events cannot consume this tail.
Oversize configuration fails before server/browser work. Cutoffs no longer get
popped/discarded at the limit; all observed pending IDs remain explicit. The
256 KiB total cap, identity/event caps and all original timers are unchanged.

Retained inert evidence (all files are under the fresh private root):

- Initial source RED: e29dc7 output was truncated; the unchanged-source repeat
  74c54e retained `red-inert.txt`: 37 failures, 59 original Node passes,
  210.837 ms. Python tests were not reached because the unchanged wrapper stops
  after Node failure. This is not a 65-case preservation result.
- First implementation: da8635, 95 passes/1 new fixture failure. The fixture
  reused one page emitter for two supposed pages. It now creates a genuine
  second authored page/session; its three-terminal assertion is unchanged.
  `green-attempt-fixture-failure.txt` preserves the original failure.
- Self-review REDs: 576cec, 2 failures/97 passes (`boundary-red.txt`), covering
  post-cutoff error suppression and skipped detach after listener-removal error;
  then 105 checks passed. 8da646, 1 failure/100 passes (`late-server-red.txt`),
  exposed missing post-cutoff server finish/close facts; then 107 checks passed.
- Root reserve finding: 67016d, 3 failures/101 passes (`reserve-red.txt`). It
  reproduced a discarded pending cutoff at the cap and required pre-work
  configuration refusal plus all 384 final states/two cutoff envelopes.
- Final 9a48f8: **104 Node + 6 Python = 110 PASS**, no skips; Node 3218.355583 ms.
  The deliberate unresolved-detach fixture retains the inherited three-second
  close timer. `final-green-inert.txt` SHA-256:
  `82966da1c90466f454bea0ded318fd9ed5b29f1396455af2b10d572e2504714c`.

Final frozen identities:

| File | SHA-256 |
|---|---|
| check.cjs (473 lines) | `4ac226878e9fc5f0e4edd099ee728feb8ee30fe98ef3599f6b5b63c920d02cfa` |
| test-check.cjs (390 lines) | `a5575d4a7f99ac74e2dddbb04eb28e18bf2919d2a51d931c9b7ac6817ddb2adb` |
| inputs.json | `e598e99b847179cf49de31724ee2367bcd01c1973ac297ff15dccef0a7d406af` |
| harness-pins.json | `3da8c7f2a97d9959aaa2ebf8fc9cced97be77877ceb1645a2c727e5699f5286b` |
| final-source-preservation-and-diff.txt | `9e996d072983d1e36ac9c70dc97885e70e207d7a3a57733ed4ee70ee0cc94b33` |

The final preservation/diff file contains the complete checker delta and hashes
of every retained RED/intermediate/GREEN transcript. Earlier intermediate
preservation/diff evidence is retained separately, not overwritten.

Exact inert repeat from the worktree (never calls the actual runner):

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-molecular-transport-browser.OYVOcS/run-inert.py
```

The unchanged wrapper permits only its fixed Node unit-test child (10-second
deadline); those tests refuse Node network/child-process entry points and use
authored emitters. The six Python checks then refuse process/network calls.
No context7/gbrain/compound tool was callable; installed Playwright source and
protocol declarations were read directly. Lesson retained: an observer must
budget its terminal evidence before collection and must not suppress errors by
adding a listener. These technical tests do not establish the ERR_ABORTED cause,
fix transport, open a consumer gate, or authorize an actual run.

## Implementation-review boundary correction

Root's independent diff read identified that reserving only 256 bytes would not
cover later identity-state changes and cutoff/correlation records. Popping an
oversized cutoff would also lose explicit pending-request evidence. Before the
private checker is frozen, add RED cases and derive a reserved tail from the
longest JSON-encoded admitted route: at most 384 correlation rows and pending
ordinals across three 128-identity planes, two cutoff envelopes, all state-label
growth and fixed failure/detach/numeric-field allowances. Ordinary event appends
must leave that reserve intact. Reject an impossible configuration before
browser work; do not raise the 256 KiB ceiling or discard cutoff facts. Root
approved this narrowly scoped correction; actual execution remains unapproved.

## Root independent implementation grade — 2026-09-09

Root read the complete frozen checker delta and all added tests, including the
derived-tail correction. The independent inert repeat completed as receipt
`0b4f8b`, exit 0: **104 Node tests plus 6 Python tests passed**, no skips or
cancellations; Node duration 3234.155625 ms, Python 0.021 s, outer wall time
3.326720208 s. This is not the maker's 9a48f8 run.

After resuming, root re-read the complete 473-line checker and unchanged Python
supervisor. Read-only receipt `caeaac` independently verified all **22 input and
8 harness pins in both roots**, including exact integer mtimes, sizes and
SHA-256 values. It also verified the unchanged Python/page files, the original
Node tests as an exact byte prefix, all six frozen receipt hashes above, and
the absence of the successor's `run` directory. `git diff --check` returned
exit 0 (`311571`). No product or previously consumed evidence bytes changed.

No remaining critical implementation finding was identified in this bounded
passive-observer change. Original request failures still preclude acceptance;
CDP/server disagreement, incomplete cutoffs and cleanup failures cannot become
PASS. This grade supports only a separately recorded one-attempt diagnostic
decision. It does not establish the original cancellation cause, transport
reliability, scientific qualification or release readiness. A further independent
read-only spot review is in progress; no actual browser invocation has occurred.
