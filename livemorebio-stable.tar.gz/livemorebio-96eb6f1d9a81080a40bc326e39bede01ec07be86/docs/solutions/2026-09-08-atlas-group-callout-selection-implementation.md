# Atlas group callouts and exact selection: implementation checkpoint

Date: 2026-09-08. Maker checkpoint, **not independent acceptance or browser QA**.

## Authority and bounded implementation

The root read and approved the complete post-presentation correction proposal,
then froze the exact product rules before code. Its appended selected-cue
obstacle precision was also written before that additive implementation. This
packet implements only group-callout placement and exact search/scene selection
reconciliation. The screenshot and listener-checker proposals remain separate;
neither presentation harness was edited or run.

The pure presentation helper packs natural measured labels in stable ATLAS_GROUPS
order on the anchor's left/right rail, with8px box inset and6px separation across
both rails. It requires finite positive-depth, near/far and in-frustum anchors.
It preserves projected anchors and connects them to the facing label edge.
Packing is deterministic, not a maximum-capacity packing claim. No text shrinking
or biological/camera/mesh adjustment makes the boxes fit.

The one existing selected source-extent label is a reserved obstacle: its existing
position plus natural measured width/height are returned from its unchanged draw
path. Group boxes move or receive an explicit space-limited omission; the selected
cue is not moved. Invalid supplied obstacle shapes fail closed. Other overlays
are not generalized into a new layout engine.

The actual scene measures group text, renders pointer-transparent/aria-hidden
keyed labels and leaders, and reports placed keys plus omission reasons. Section,
isolation, labels-off, hidden page, context loss and disposal suppress callouts.
The existing inspector retains all nine names and an explicit omitted count.
An old disposed scene cannot publish a report into its replacement controller.

The controller reconciles the result select against the exact scene ID after
search and controls updates. Null selection clears only highlight, retaining
query/options. An out-of-filter ID does not select a different result. Same-source
Retry preserves matching selection. A new changed-manifest regression also found
the existing source article was not reset when the scene/list were cleared; the
same existing `selected(null)` path now clears that article. This stays within
the written changed-source reset contract and adds no source or numerical data.

## True red-first evidence

All executions used private `prepare_review_environment` roots, Python bytecode
and pytest cache disabled, socket connect/connect_ex/create_connection/DNS and
both urllib entrypoints replaced with refusal tripwires. Node modules are local;
scene tests use authored tiny technical triangles, local pinned THREE math and
GLTF parsing with a fake renderer. No browser/GPU, publisher source acquisition,
native biological model, HTTP, service or operational store was used.

1. Initial28 new cases: **28 failed in4.26s**, before product changes. Failures
   covered missing layout, actual scene/report behavior, stale native-like select
   state, and missing complete accessible list. Private root suffix `meid54fx`.
2. Initial implementation: **28 passed in3.59s**, root suffix `vt9dakcy`.
3. Changed-manifest old article: **1 failed /3 deselected in0.25s** before the
   bounded existing-selection-path fix. Its exact assertion was retained.
4. First broader matrix: **171 passed /1 failed in16.61s**, root suffix
   `94dj22bb`. The inherited coordinate/disposal fixture's minimal DOM double
   lacked `getBoundingClientRect()`. This was a fixture capability failure, not
   evidence of a product browser failure. Root approved adding only that standard
   method with authored90×20 dimensions; every geometry/idle/stale/disposal
   assertion remains unchanged. No production fallback was added.
5. Approved selected-cue constraint: **6 failed /26 deselected in1.50s**, root
   suffix `eg2rm9c3`, before obstacle implementation. Both pure near-corner and
   actual-scene collisions reproduced; four malformed obstacles also failed.
6. Final complete scoped matrix: **179 passed in17.91s**, no skips, private root
   `/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-8hsobhpb`.

The dedicated modules now contain36 cases. Arithmetic checks include coincident
anchors, retained clustered positions without inventing their source identity,
fractional viewport/text-size grids, reversed arrival order, narrow cross-rail
overflow, invalid/outside/behind-camera anchors and the selected-cue obstacle.
Mounted tests exercise actual controller code with native-like select semantics.
The broader143 cases preserve loader/source/cancellation/Retry/view settings,
extent cues, geometry/material/camera invariants and owned disposal.

Reproduction from the worktree, with no service fallback:

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B -c 'import os,socket,urllib.request,pytest; from tools.run_review_stack import prepare_review_environment; root,env=prepare_review_environment(); os.environ.update(env); os.environ["PYTHONDONTWRITEBYTECODE"]="1"; print("Private test root:",root); deny=lambda *a,**k: (_ for _ in ()).throw(AssertionError("OFFLINE_NETWORK_TRIPWIRE")); socket.socket.connect=deny; socket.socket.connect_ex=deny; socket.create_connection=deny; socket.getaddrinfo=deny; urllib.request.urlopen=deny; urllib.request.OpenerDirector.open=deny; raise SystemExit(pytest.main(["-q","-p","no:cacheprovider","livemorebio/tests/test_atlas_group_labels.py","livemorebio/tests/test_atlas_selection_sync.py","livemorebio/tests/test_atlas_extent_projection.py","livemorebio/tests/test_atlas_selection_presentation.py","livemorebio/tests/test_atlas_view_status.py","livemorebio/tests/test_atlas_reference_ui.py","livemorebio/tests/test_atlas_renderer_review.py"]))'
```

## Frozen files (SHA-256)

Paths below are relative to this worktree. Only the four product files, two new
test modules, the approved one-method inherited fixture and these docs changed
in this lane.

| File | SHA-256 |
|---|---|
| `livemorebio/aegle/console/lib/atlas_reference_presentation.js` | `7960ef112c10bf2b418c9b9790b18ce3172db8dc7b97aaea7b92fcd8a5f2fc19` |
| `livemorebio/aegle/console/lib/atlas_reference_scene.js` | `78e4b81eb4a2c41da171c735d2adbe60c57dca4d0a9e741f7dd724cc5d326640` |
| `livemorebio/aegle/console/lib/atlas_reference.js` | `9f48618e7cfd86f687c23ad7736242725a5ecaeba1018c0d957dc011df80a2d8` |
| `livemorebio/aegle/console/lib/atlas_reference.css` | `1259f1a30d4fb2ed9882731c0de785fa7a4efddaf6f8572646a3c387d900cfe1` |
| `livemorebio/tests/test_atlas_group_labels.py` | `c75964102607c0195f8748ace2ecec56aadba2552263c87571c768b7e9109cf1` |
| `livemorebio/tests/test_atlas_selection_sync.py` | `441b8ce2063c9f4f88642a214713103af2ea5204b33df152c12c56ba9ced82ee` |
| `livemorebio/tests/test_atlas_reference_ui.py` | `db8f991b97b9e2fafd422053f92bec8b019d14186a3ba34fbf80a87070fbf3b1` |
| `docs/solutions/2026-09-08-atlas-post-presentation-correction-proposal.md` | `360ad5a6377b0c4a56059b88e072abc6e9e83278c93d61ecf09f61b1cb2d25d6` |

The untouched presentation harness hashes are Python
`625031248f8cbce3eab8185bbbfd4182bcfe2819d3da6ff1018cb6c59f431284`
and CJS `4a8b11ab1c8424136404a0bd3ef8764d7668486430c3c1a913211726eddbb0e9`.

## Review and acceptance still required

Root and independent reviewer must grade this frozen source before a separately
authorized source-frozen ordinary browser check. That check must inspect measured
label collisions and overflow at desktop/mobile, selected-cue coexistence, exact
Return/search state, section/isolation reasons and actual text readability. No
new screenshot, performance, scientific or full-product acceptance is claimed.
The earlier Atlas matrix remains28 PASS /3 FAIL /25 NOT_RUN; retained transport
errors, screenshot contamination, TIME_WAIT checker evidence and all other
uncompleted product requirements remain open and are not replaced by these fixes.

Durable lesson: screen-space presentation needs both positive projection
eligibility and measured collision constraints; the exact source selection must
be reconciled across scene, inspector and native form controls. Preserve omitted
identities accessibly, and distinguish an incomplete test DOM from a real browser
failure. No Compound Engineering provider was available; this local decision and
red/green record is the explicit fallback, not a claimed invocation.

## Root independent implementation review

Root read the complete four product files, both new test modules, the authorized
inherited fixture adjustment and this report. The measured-packing path retains
mesh transforms/materials and camera position; the selected extent path changes
only by returning its existing measured rectangle as an obstacle. Exact selection
reconciliation and changed-source article clearing remain within the approved
contract. No additional actionable code blocker was found in this review.

Root independently repeated all179 scoped cases: **179 passed in24.73s**, no
skips, private root `livemore-research-review-gwk03ru2`. In addition to parent
socket/DNS/urllib refusal, all176 Node test invocations received an in-memory
builtin net/TLS/HTTP(S)/HTTP2/datagram/DNS/fetch refusal preload. The technical
scene remains a fake renderer with authored triangles and actual local math;
this is not a GPU/browser or biological experiment. No service was launched.

This clears the narrow product implementation for a separately reviewed/frozen
browser check. Actual readability and selection behavior still need new images;
the earlier findings and full R01–R51 acceptance are not retroactively closed.
