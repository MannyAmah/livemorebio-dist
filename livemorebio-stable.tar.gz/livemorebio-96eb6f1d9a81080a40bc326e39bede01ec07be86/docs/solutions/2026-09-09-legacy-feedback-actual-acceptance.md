# Current-feedback correction: actual desktop/mobile acceptance

Root ran the independently reviewed174-test harness once at source
`f9f7b4384cba70ea6080b631c1ca33c7e8b2bda8c3c0797d527858e234520fed`.
Session54253 exit0;8.440222125s. Original evidence:
`/private/tmp/livemore-legacy-preview-5ztzbevi`.
Browser receipt SHA256`6a6469b62eb6a8edc111ca0fc141610f36c98c5d5089a1f5c11cd6fbdf32a316`;
supervision`b1fdb093b6358b7da7940a6b73799dfaf5b2b7afc2b2d2b13732d0c5d2e37186`.
The earlier failed attempt`c_1ximjr` remains unchanged, not regraded.

## Narrow acceptance

All seven cases D0–D4/M1/M2 passed. Root read the full receipts (including the
separately retrieved middle request rows) and personally viewed every original:
desktop modeless/error/pending/later-winner/cardiac/cleanup/note-before/unknown/
twins-recovery/life-inspection/history; mobile cardiac/error/note-before/unknown/
refreshed.16 images,1440×1000 and390×844.

The stale compound message is absent during pending, ready and unknown actions.
The current informational banner returns on model-unavailable refresh. Cardiac
state, provenance and time labels correctly distinguish calculated, pending and
unavailable traces. All three calculated-state labels are fully visible and
native-hit-testable on both viewports after normal scrolling. Pending/unknown
states retain all six clear predicates, with old numerical images/metrics absent.
Native validation keeps focus and sends no new POST. Recovery routes still open
Twins, LIFE and Cendos History. This accepts the targeted message/label fixes.

Three isolated services matched the source identity. Two model-unavailable
actual reads, six authenticated session bootstrap responses, four intercepted
authored POSTs and exactly one follow-up GET each. Actual mutations0; solver
constructors were guarded. Six expected console errors from deliberate failing
responses are retained, not described as zero errors. This is UI engineering
evidence, not an insulin/botanical experiment or observed biological response.

Four owned children16291/16292/16293/16297 reaped;12 observed descendants absent;
ports8910–8912 have no listeners. All five browser resources settled. No primary,
cleanup or evidence failure. No old operational store, cohort or experiment was
altered. Product source freeze for this completed check is released only for
already approved next increments.

## Remaining obligations, not waived by this pass

Dense raw recovery text, retained historical uncertainty messages after refresh,
mobile navigation requiring horizontal scrolling, the legacy figure and wider
scientific copy still require full design/interaction review. This is the retained
advanced console, not acceptance of the A+B Atlas or deeper Biology. No full
keyboard/200%-zoom/tablet/all-page approval, native molecular viewer, physical
device proof or six-program video is supplied by this run.

Unmodified representative originals and both receipts are copied to
`docs/screenshots/full-scope-recovery/legacy-feedback-2026-09-09/`; their hashes
remain bound in the original browser receipt. Every original remains at the
private evidence path. Do not present authored trace fixtures as scientific data.

Lesson: validate message ownership separately from layout, and inspect actual
screens after offline tests. A normal-flow header outside the viewport does not
occlude the current panel; a unit-count pass cannot establish visual acceptance.
