# A fail-closed reader needs a repair path, or the runbook becomes `mv`

Date: 2026-09-23
Scope: LivemoreBio LIFE Patch telemetry journal

## What happened

The LIFE Patch gateway validates every record in the telemetry journal before
publishing any state. One record written on 2026-08-31 used a clinical
descriptor (`type-2-diabetes`) as its subject ID, where a later protocol
requires an opaque `pseudonym-<id>`. The gateway refused the whole file, and
the entire LIFE virtual session manager stayed down.

Failing closed was correct. The privacy rule was correct. What was missing was
anywhere to go afterwards: the only available remedy was to move the journal
aside, which discards **16 valid records to escape 1 invalid one**.

## The shape of the mistake

A validating reader was built without its repair counterpart. That is fine on a
developer's machine, where the journal is disposable. It is not fine on a
client's machine, where the journal is the operational record — and where
"delete your history" is not an answer you can put in a runbook.

The tell: when the remedy for a product's own error state is a generic Unix
command, the product has not finished handling that state.

## What was built

`livemore patch-journal verify | quarantine [--apply]`

* `verify` is read-only and names each rejected record and the rule it broke.
* `quarantine` moves **only** the rejected records to a sidecar and keeps the
  rest replayable. It reports and changes nothing unless `--apply` is given.

Three properties were non-negotiable:

1. **Stored bytes are never re-encoded.** Records may be AES-GCM sealed over a
   fixed AAD, so a record round-tripped through `json.dumps` is not the same
   record. Kept records are copied verbatim; quarantined ones are preserved as
   their original line text. Verified: the repaired file's sha256 equals
   `tail -n +2` of the original, and the sidecar's `record_line` is
   byte-identical to the original line.
2. **The reason is a protocol rule, never payload.** The sidecar and report
   carry the rule and the record's position. Nothing decrypted crosses into
   either.
3. **The same field set decides both.** The gateway and the repair tool read
   `JOURNAL_METADATA_FIELDS` from one place, so a tool that disagreed with the
   reader about what a record *is* cannot exist.

The service-level code changed too: a rejected journal now reports
`PATCH_JOURNAL_INVALID` and names the command that fixes it, rather than
`EXECUTION_STORAGE`, which sent the operator to inspect healthy storage.

## What to do next time

- When adding a validating reader, ask immediately: *what does the operator run
  when this refuses?* If the answer is `rm` or `mv`, the feature is half-built.
- Preserve the rejected thing. A record that today's protocol refuses is still
  evidence, and quarantine is reversible in a way that deletion is not.
- Default to reporting. A repair tool that changes nothing until `--apply` can
  be run by a nervous operator on a production machine.
- Tightening a protocol rule is a migration event for every artefact already on
  disk. The rule change and the repair path belong in the same change.

See also: [[livemore-honest-refusal-pattern]],
[[livemore-suite-green-launch-broken]]
