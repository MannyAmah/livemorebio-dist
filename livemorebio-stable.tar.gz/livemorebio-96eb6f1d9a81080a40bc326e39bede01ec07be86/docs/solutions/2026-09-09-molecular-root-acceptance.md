# Root integration review: local molecular inspection

September 9, 2026. Narrow software acceptance, not dynamic molecular, complete
protein, patient-geometry or human-equivalence acceptance.

Root read the complete local adapter, frame implementation, inspector integration
and maker record. The original BSD-3 license and GLmol/Three/jQuery terms and
complete additional component notices were inspected. The unchanged published
bundle is pinned; unresolved embedded dependency versions are stated, not guessed.

Root independently executed the exact guarded 11-file command from the maker
record (SHA `0e848efd8d383f5f7a00f002a9b821080b90b088e56da99a8cda00fac40d8873`).
Receipt `d58dbc`: **237 passed in 26.42s**, zero unexpected I/O, 229 bounded Node
test processes and zero Git calls. Isolated review root ends `4aoqm_y9`.

Actual ordinary Biology browser inspection on port8868 then established:

- Heart and its ventricular-cell/ion-channel controls were present.
- KCNH2 opened local PDB5VA2 with a READY status and visible WebGL geometry.
- Cartoon and atoms/bonds selections visibly changed the rendered representation.
- A real pointer selection reported source atom row2362, author chainA, ASP609 C.
- Fit and Escape worked; closing left zero owned molecular iframes.
- The source/construct limitations remained visible: engineered single subunit,
  no assembly expansion, unresolved source numbering, no patient-specific motion.

Screenshots retained initially at `/tmp/livemore-local-herg-viewer.png` and
`/tmp/livemore-herg-atoms.png`; the final delivery consolidates accepted images.
This does not yet claim an actual two-atom measurement or all three consumer
contexts; those remain in the final browser walkthrough checks.

Root separately caught a real distribution defect: nested vendor files were not
included by the existing wheel patterns. The new exact bundle/three-notice
archive assertions failed (`f20d11`), then passed after one fixed directory
pattern was added (`143d8b`, 1 test in2.57s). Existing outside-checkout manifest,
seven original molecular sources, no-network reads and missing Atlas checks all
remain. No external model, experiment, cache or private state was bundled.

The nine unrelated full-suite failures were reviewed separately against their
before-image diff, not fixed by weakening biological claims. Their maker and
independent source-review receipts are retained in the contract-reconciliation
record. A final broad sweep follows the last runtime source freeze.
# Additional actual distance and installed-wheel check

Root ordinary-page browser check `bb3d88` selected two displayed atoms in
5VA2, yielding **21.72 Å**: atom row2335, author chainA PRO605 CG, and row1193,
author chainA PHE424 C. Independent inspection of the original CIF rows
(`c05cd6`) gave (89.016,62.056,107.050) and (99.027,56.844,88.498);
Euclidean distance21.715473031918958Å rounds to the displayed21.72Å.
Clear selection worked; Escape removed the owned iframe (count0, `bfaa64`).
Original screenshot: `/tmp/livemore-herg-distance-2172.png`.
The missing Biopython optional parser was not installed to manufacture a pass;
the direct source rows and independent arithmetic were used instead.

The separate wheel admission test failed before the single package-data pattern
was added (`f20d11`), then passed the real installed-wheel check (`143d8b`).
Independent source review by the evidence agent is CLEAR: exact vendored bundle
and all three unchanged notices are included, all earlier wheel assertions
retained. This closes that packaging gap, not the separate cardiac CellML
distribution-rights boundary or whole-product acceptance.
