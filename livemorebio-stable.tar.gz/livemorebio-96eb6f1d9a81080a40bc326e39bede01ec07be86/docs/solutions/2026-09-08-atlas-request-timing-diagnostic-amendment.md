# Atlas request timing: retained failure and diagnostic amendment

Date: 2026-09-08. Status: **PROPOSED; no correction or rerun authorized here.**
Scope: harness-only measurement/coverage correction under the reviewed Atlas
browser plan. Runtime source remains `c9fee6db135dfd338c2b793ac4c4f22936db3c692421f728196ecfd3693de47a`.
No model, cache, source, service, fixture or product change.

## 1. Actual attempt retained, not accepted

Root authorized one run of reviewed harness `97af0239a4e8e482a643b931c4449864a7c92f92a55be9fed60dc312873a8cce`.
It ran 16:16:23.309–16:18:34.925Z and exited1. Private evidence root:
`docs/screenshots/full-scope-recovery/atlas/attempt-1-AxzdqF/browser/`.
The final evidence SHA is `5ec4b9894e87b5aa1cd6d40a612b94523ebe756f9bc94b7bda01d46e92f63f08`.
Do not rewrite this receipt, reclassify its failures or overwrite screenshots.

All seven load prerequisites failed: three ordinary1440 trials, three ordinary390
trials and one instrumented initial load. Each reached the nine-layer ready DOM
and a visible intact source body. Six ordinary screenshots and one instrumented
screenshot remain separate. Root personally viewed the first desktop/mobile
screenshots; this is rendered evidence, not a performance or full-control pass.

| Ordinary viewport/trial | Asset-phase to nine ready, ms | Navigation to ready, ms |
|---|---:|---:|
| 1440/1 | 6251.544 | 11958.259 |
| 1440/2 | 5437.799 | 10981.445 |
| 1440/3 | 5550.971 | 10914.846 |
| 390/1 | 5660.497 | 10540.528 |
| 390/2 | 5198.416 | 9871.317 |
| 390/3 | 5687.822 | 10335.326 |

Every ordinary trial recorded skin `requestfailed`, null skin response-end and
maximum callback-observed internal concurrency3. Instrumented initial load
recorded skin complete, but first internal request callback preceded its finished
callback by about5ms; its event-overlap maximum was also3. These fail the current
predicate even though the full drawn geometry is present. The elapsed values
above are retained observations, not selected passing trials.

No page errors, console errors, blocked mutations or install attempts occurred.
The native blank-tab visibility preflight passed. Camera/p95 sampling, ordinary
controls, sections, source inspection, five disposal cycles, fault/recovery,
200% zoom and mobile touch are **NOT_RUN**. The existing stage dependency skipped
them after the load predicates failed. No platform-wide health score is justified.

Owned cleanup: exec59677 ended exit1; the reviewed outer browser finalizer ran.
At16:19:18.833Z, a filtered process inventory found no harness, temporary
Playwright-profile or debug-pipe browser process. At16:19:37.478Z, a read-only
postcheck confirmed the same three process IDs, source, technical twin version8
and context `df9f87e2dc42fbc02edfa89b24c80c93bd72e8291773ea44364551fbb27817f9`.
No cleanup action targeted an existing user browser or service. The receipt's
generic cleanup wording is not upgraded in place; these are supplemental checks.

## 2. Confirmed measurement defect versus unresolved transport cause

Read current pinned source, without modifying it:

- `atlas_reference_requests.js:18–35`: the original loader reads through stream
  EOF, checks the exact byte count and SHA-256, and only then fulfills with its
  buffer. It calls reader cancellation/release in cleanup. Whether that cleanup
  produces the observed network error in this Chrome run is **not established**.
- `atlas_reference_loader.js:82–95`: skin load/draw is awaited first; exactly two
  subsequent application workers await each load/draw before claiming another.
- `atlas_reference.js:109–124`: a partition is counted ready only after the
  original request resolves and the unchanged scene loader accepts it.
- `check_atlas_browser.cjs:observeWarm`: concurrency is inferred from Node arrival
  timestamps of request/finished/failed callbacks. It neither records browser
  network timestamps nor original application promise completion. It conflates
  three clocks/states: network request completion, application verified-buffer
  completion and transport-delivered event callbacks. They are not interchangeable.

Pinned primary Playwright1.58.2 docs (`playwright-core/types/types.d.ts`): Request
events describe HTTP/body completion and failures; `request.timing()` supplies
browser-origin timing, with responseEnd unavailable until terminal completion.
`response.finished()` can report an error; `request.failure().errorText` contains
the network error. Chromium implementation `crNetworkManager.js:426–465` uses
Network terminal events, retains a response even in a later failed branch, and
records original protocol timestamps. The harness discarded those distinctions.
Relevant official API references: [Request](https://playwright.dev/docs/api/class-request),
[Response](https://playwright.dev/docs/api/class-response),
[Page events](https://playwright.dev/docs/api/class-page#page-event-requestfinished).

The current receipt does not contain safe failure codes, response statuses,
resource timings or body-completion timestamps. Therefore it cannot identify
the exact browser net:: error, prove a transport abort cause, or support changing
a failed request to success. Source inspection plus nine verified drawn partitions
does establish that the current callback-based performance predicate is not a
sufficient measurement of the two-worker application contract.

## 3. Proposed bounded diagnostic, before another acceptance run

After written review and explicit run authorization, use one fresh owned context
on the same frozen technical source. No install, experiment, source or browser
upgrade. Bound this diagnostic to one normal warm load and at most90s, with the
same ownership, native visibility preflight and outer cleanup. It is diagnostic
evidence only; it does not retroactively pass attempt1 or replace ordinary trials.

Retain a fixed allowlisted per-request record for the nine exact manifest asset
URLs only (fixed route/asset IDs; no arbitrary URLs, headers, bodies or cookies):

- Context sequence, navigation sequence, request sequence, method GET, asset key,
  expected static digest/bytes and normalized same-origin route.
- Node callback timestamps for request, response, finished and failed separately;
  do not overwrite a response record with a later terminal category.
- Response status, expected content-type/digest/header-match booleans, browser
  request timing and bounded response-body size when available. Preserve null
  for missing metrics. Classify failure text into a fixed enum such as
  `ERR_ABORTED`, `ERR_FAILED`, `ERR_CONNECTION_RESET`, `ERR_TIMED_OUT`,
  `OTHER_NETWORK_ERROR`, `UNAVAILABLE`; never persist the raw error text.
- Read-only same-page `PerformanceResourceTiming` entries for exact fixed asset
  paths: startTime, fetchStart, responseStart, responseEnd, duration, transferSize,
  encodedBodySize and decodedBodySize. Keep this browser clock separate from
  Node callback-arrival time. Reject duplicate/unmatched rows instead of guessing.
- Bounded `response.finished()` settlement and safe outcome. Do not call
  `response.body()`: its pinned Chromium fallback can issue an additional network
  resource load, which would contaminate a one-load diagnostic.

For exact verified-buffer/application concurrency, extend only the already
reviewed diagnostic-module approach to the fixed
`/lib/atlas_reference_requests.js` export. Import and hash-fence its unchanged
original bytes with one fixed private query marker. The wrapper invokes the
original factory/load/dispose once with the same arguments/receiver, returns the
**same promise**, and attaches bounded metadata-only settlement handlers. It
records browser-monotonic start/resolve/reject, exact asset identity and resolved
buffer byteLength, never buffers, patient data, response bodies or control state.
No fetch/reader/global hook, rewritten scheduling or response substitution.
Resolve means the original loader completed its own EOF/count/hash contract,
not an independently measured physical or GPU event.

Retain wrapper/original hashes and prove exact promise/value/error identity and
one-call delegation in red-first tests. A wrapper changes observability and is
explicitly instrumented; ordinary screenshots continue to use unmodified modules.
If same-source records disagree or a metric is unavailable, keep the case
unresolved. No epsilon allowance, clipping of negative intervals or automatic
relaxation of the maximum-two-worker requirement.

## 4. Correct coverage dependency without masking performance failures

The next reviewed harness must track performance, functional readiness and
source/ownership integrity separately. A failed timing prerequisite remains
failed and contributes to overall failure; it must not silently suppress all
independent controls/fault coverage when the same-source scene is usable.

- After the first ordinary load trial, explicitly assess source-fenced functional
  readiness (same context, usable scene, nine available layers). If ready, run
  its ordinary controls regardless of that trial's performance predicate. If not
  ready, record dependent controls NOT_RUN with the exact prerequisite reason.
- Instrumented geometry/count readiness is distinct from warm event timing. It
  may permit the unchanged20s camera sample and disposal cases even when a warm
  timing case failed. Do not treat fallback/no-geometry as readiness.
- Fault/recovery cases retain separate fresh contexts and should run after an
  ordinary performance failure. An identity/source mismatch, unauthorized
  request or unconfirmed owned cleanup remains a hard stop, not permission to
  continue in a replacement context or service.
- Every planned case is registered before execution and ends PASS/FAIL/NOT_RUN
  with a prerequisite reason. Overall acceptance still fails if any required
  performance, functional, integrity or resource gate is failed/unverified.

Red-first guards: response200 then failed retains both states; callback timing
inversion does not become invented body timing; unknown errors are sanitized;
missing/duplicate resource rows remain unmeasured; no response.body/refetch;
request-module wrapper exact delegation and bounded metadata; failed warm timing
plus independently ready scene still runs controls/faults and stays overall
failed; absent scene marks dependent cases NOT_RUN; identity/cleanup failures
prevent any further product navigation; all failures and original attempts remain.

Compounded lesson: a browser event can describe network lifecycle without being
the application promise's completion clock. Keep raw clock domains and failure
states distinct, and make functional coverage independent from performance
grading without weakening either acceptance gate. Implementation and another
browser launch remain subject to root and independent written review.

## 5. Root-requested deadline and observer boundary clarification

The90,000ms diagnostic deadline is one Node monotonic deadline, beginning before
the first live identity request/browser launch. It includes HTTP setup, launch,
context/page allocation, native blank-tab preflight, authentication, navigation,
the one asset load, all `response.finished()` waits, resource collection and
evidence observation. It is not merely a check at entry or a per-step timeout.
Every awaited browser/HTTP operation uses the remaining shared budget and a
post-settlement deadline check. No waiting for networkidle on the workspace SSE.

Expiry stops new commands/requests, invalidates observer generation, aborts owned
HTTP requests, and closes only the exact owned context/browser. Cleanup has a
separate5s bound, not90s of additional observation. Attach terminal handlers to
all pending operations, including a browser launch that resolves after expiry;
such a late owned browser must be closed rather than returned to the test. If
launch, cancellation or closure cannot settle, record `CLEANUP_UNCONFIRMED` and
stop; no successful cleanup claim or further browser stage. No service/shared
browser/OS-process mutation is introduced. Evidence-write failure must not bypass
the owned-resource finalizer; retain available in-memory bounded evidence when
disk recording fails, without printing clinical content or raw errors.

Each request row keeps separate `response_status`, terminal event enum and
`finished_outcome` (`COMPLETE`, `NETWORK_ERROR`, `DEADLINE`, `UNAVAILABLE`). A missing
response or unresolvable `response.finished()` at the deadline remains null plus
the explicit outcome; it is not complete. Missing/duplicate/mismatched resource
rows carry `UNAVAILABLE`, `AMBIGUOUS` or `MISMATCH` and cannot supply timings. Late
callbacks cannot mutate a finalized row or append to a later context/navigation.
During bounded collection, count an observed late callback in a fixed counter;
after listener disposal, ignore it without retaining promises/responses/buffers.

The same-promise wrapper's side observer always has rejection handling. A thrown
metadata handler is caught in the observer path, records only
`DIAGNOSTIC_OBSERVER_FAILED`, and cannot change the original promise/value/error
or produce an unhandled child rejection. The original call still occurs once.
Red tests deliberately throw from both settlement metadata handlers, asserting
same-promise identity, original rejection identity, call counts and absence of
unhandled rejections. No handler reads a clinical/global state object.

Use typed run outcomes rather than blanket generic catches: `SOURCE_MISMATCH`,
`CONTEXT_MISMATCH`, `AUTH_UNAVAILABLE`, `UNAUTHORIZED_REQUEST`,
`DIAGNOSTIC_OBSERVER_FAILED` and `CLEANUP_UNCONFIRMED` are hard stops. They prevent
later product navigation. `PERFORMANCE_GATE_FAILED` can coexist with independently
confirmed `FUNCTIONAL_READY`; absent geometry is `FUNCTIONAL_UNAVAILABLE` and
dependent controls become NOT_RUN. Unknown failures remain unresolved and cannot
be downgraded to a performance-only failure to keep running. Final acceptance
requires all mandatory gates, with each planned case explicitly accounted for.

## 6. Approved implementation checkpoint — no browser launch

Root and independent release review cleared the216-line amendment at
`f9ca082b1c9ff1a35fe206cc6372cd4e30bcc477051238c3a843a94631307209`.
Root separately approved serving the exact source-fenced local original request
module at the fixed private query marker, avoiding a network response-body read.
The original module SHA is
`7ad7c023571614635d196cc5b0638d195ae46b166ce4602be16eb87e4cf4b9bc`.
Neither the asset reader nor any packaged runtime/UI file was edited.

Implementation candidate:

- `tools/check_atlas_request_diagnostic.cjs`: independent one-load entrypoint,
  shared90s setup/load/collection budget and separate5s owned cleanup; bounded
  three-clock metadata, no response body/refetch, exact same-promise request
  observer, safe failure enums, original/wrapper route and byte identities.
- `tools/check_atlas_browser.cjs`: all cases preregistered PASS/FAIL/NOT_RUN,
  independent functional readiness after a failed timing gate, retained unchanged
  timing thresholds, typed source/context/auth/cleanup hard stops. This does not
  authorize another full acceptance run or regrade attempt1.
- `livemorebio/tests/test_atlas_request_diagnostic.py`: isolated no-browser
  regressions and one actual unchanged loader exercised only with technical
  in-memory bytes and a supplied local fake fetch—not publisher traffic.

Red sequence: first10 tests failed because the new helper did not exist. Two
further red guards exposed missing mounted response-settlement coverage and a
nonfinite clock edge case: checking `expired` before `remaining()` allowed NaN
to evade the post-settlement condition. The corrected deadline returns zero
immediately when time is nonfinite. The full current regression set passes45
tests in3.41s, including prior Atlas and continuous-browser harness preservation
tests. Both JavaScript entrypoints pass `node --check`.

Maker verification only. Current package fingerprint independently read by the
existing hash helper is still `c9fee6db135dfd338c2b793ac4c4f22936db3c692421f728196ecfd3693de47a`.
No browser, product HTTP request, model solve, source acquisition, runtime edit
or service operation occurred in this implementation checkpoint. The original
attempt remains failed; the net:: failure cause remains unresolved. Independent
candidate review and explicit authorization are required before the one90s
diagnostic. Functional and fault browser coverage remains required afterward.

Root review then reproduced a classification gap in the acceptance follow-up:
camera cleanup used a generic assertion, which the case runner converted into a
non-hard functional failure. The actual mounted camera→case-runner regression
failed first (missing expected hard-stop rejection). Camera cleanup now throws
typed `CLEANUP_UNCONFIRMED`; later registered cases remain NOT_RUN and no further
screenshot/navigation is attempted. A second red test proved setup cleanup could
surface an untyped close error after authentication failed; that branch is now
typed identically.47 combined guards pass3.57s. The standalone diagnostic code
was not changed during this root review correction; no browser was launched.

### Independent clearance and single diagnostic authorization

Root read the full standalone diagnostic, acceptance harness, tests and amendment,
including the cleanup correction, and independently ran47 guards (3.53s).
Independent release review read the same current files and ran47 guards (3.59s),
finding no further actionable blocker for this bounded collection. Reviewed hashes:
diagnostic `5d94aa9460bdae62ac7ec77fe4a81cb7e0d036f46d483083858d5f65bca318cd`;
acceptance helper `2913ffca546ea3b8a16d61f956a32923c63abb061de162fdf26d8a1a39b024cd`;
diagnostic tests `674f885cbbec89f3fa992ccea81c69dcc51326b443efbf363cea5530bf79f084`.

Root authorizes ONE invocation of this standalone diagnostic against the exact
frozen8910 technical stack, with its90s total observation deadline and separate5s
owned cleanup. No acceptance rerun, runtime change, model work or install is
authorized by this entry. All other test/browser/native workloads pause during
collection. Missing or disagreeing measurements stay unresolved. The original
failed attempt remains unchanged; diagnostic completion never equals acceptance.

### Actual authorized diagnostic result — deadline, not acceptance

The single invocation (exec16088) ended exit1. Start16:51:45.251Z,
finish16:53:15.738Z; observation elapsed90,004.477083ms. Outcome
`DIAGNOSTIC_DEADLINE`, owned cleanup `SETTLED`. Retained receipt:
`docs/screenshots/full-scope-recovery/atlas/diagnostic-1-gLkFxF/browser/atlas-request-diagnostic.json`,
SHA`9c44a713a51a8de0b5a11bc09b60cb31946644954235c0204bcca81a67297b02`.
Root read all516 lines. No automatic retry is authorized.

All nine responses were200 and matched the expected source, process, digest,
manifest and content-type headers. The unchanged application loader resolved all
nine exact byte lengths; its observed maximum internal concurrency was2 and
skin resolved before internal requests started. This is instrumented application
completion evidence, not a transport/performance or patient-geometry qualification.
Skin, heart, liver, right lung and brain separately produced `ERR_ABORTED` network
events; their `response.finished()` calls remained unresolved to the deadline.
The other four finished normally with measured response byte counts. Resource
timing collection and final application finalization were not reached; their
absence must not be filled with inferred values. The original cause of the
aborted network events is still under source-level investigation.

After completion a narrowly filtered process check found no owned diagnostic or
temporary Playwright/debug-pipe browser process. An authenticated read-only
postcheck verified unchanged package fingerprint, all three service instances,
technical twin version8 and context`df9f87e2dc42fbc02edfa89b24c80c93bd72e8291773ea44364551fbb27817f9`.
No runtime, store, asset or installed-release change occurred. The existing Atlas
attempt and this diagnostic remain failed; independent functional browser
coverage is still required rather than being inferred from nine loaded layers.

### Independent receipt review and functional acceptance authorization

Independent review verified the receipt hash and recomputed nine resolved buffers
(24,779,652 bytes), maximum two internal loads and a34.1ms skin-first margin.
Pinned Playwright's client/browserContext.js failed-request branch supplies
timing but does not resolve the response completion promise awaited by
client/network.js; this explains the diagnostic wait, not the aborted requests.
Those failures remain unresolved and resource timing remains unavailable.

Root and independent review approve proceeding with ONE run of the current
reviewed acceptance harness, SHA`2913ffca546ea3b8a16d61f956a32923c63abb061de162fdf26d8a1a39b024cd`,
to exercise source-fenced controls, fault recovery, disposal and mobile behavior.
The existing warm predicates,20s camera budget and performance limits are
unchanged. A warm failure remains an overall acceptance failure but no longer
suppresses independent functional coverage when the exact-source scene is ready.
No second diagnostic, source install, numerical experiment, runtime modification,
existing-store change or automatic retry is authorized. Keep other test/native
workloads paused during collection and retain all failures and NOT_RUN cases.
