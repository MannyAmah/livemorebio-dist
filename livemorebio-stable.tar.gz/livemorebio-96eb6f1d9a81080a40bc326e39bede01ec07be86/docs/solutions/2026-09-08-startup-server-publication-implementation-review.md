# Checked startup and closed-manager publication: implementation packet

2026-09-08. Maker: root. Frozen for independent implementation review, not
whole-product acceptance or release. R01–R51 and all six experiments remain open.

## Approved basis and exact changes

The checked-startup interface proposal and appended implementation mechanics,
independently cleared checked registry reader, and separately approved
closed-manager fence correction govern this increment. Main read each completely.
The independent fixture review records 33 new startup cases plus the migrated
legacy failure case, and the separate reviewer authored 26 real-manager cases.

- `ExecutionManager.set_source_generation` loses only its `_open()` prerequisite;
  validation, lock, assignment, deadline clearing and all execution/cleanup guards
  remain. Closed executors remain closed with unresolved ownership retained.
- Startup has one checked-read/preparation/confirmation path. Both compatibility
  restore and ordinary ensure own a retirement holder outside the initialization
  mutex. The latter is idempotent; the former can explicitly restore initialized
  state without overwriting a later operator selection.
- Ownership is captured before registry acquisition. True absence, executable
  selection and observation-only selection are distinct. Constructors/projection
  run outside authority/creation/manager/registry locks; returned models are held
  immediately for outside-lock retirement. READY with no returned model is refused.
- Exact checked confirmation precedes the prepared state/generation swap under
  authority → creation → manager. Failure installs DENY_ALL only if the starter
  still owns both generation and initialized state. No healthy fallback, fabricated
  reason, silent retry or fatal static-app startup error is introduced.
- Already-denied startup marks initialization without reading/building or
  reauthorizing. Cleanup/publication happen after all four locks. Old containers
  remain held through the swap; an unused candidate retires after the outer mutex.
- The startup event publishes no second implicit snapshot. Shared snapshot
  publication logs only fixed phase text, not arbitrary exception names/messages.
- One inherited fatal-startup test now exercises the checked seam and asserts
  static200/state503 while preserving the numerical-denial invariant. The direct
  real-model persisted-subject integration remains a separate obligation.

## Frozen identities

All paths below are relative to this recovery worktree.

| File | SHA256 |
| --- | --- |
| `livemorebio/aegle/server.py` | `f77b80c4d5a2cc86e38fe4dbfe76fe879a84840f6ee1cef833ef01f14b79bfab` |
| `livemorebio/aegle/execution.py` | `2caafc14925604e3ad3e194c3c668a7cf41eb83eb5fea3afa619bf897c277aac` |
| `livemorebio/tests/test_checked_startup_publication.py` | `0a10defce24e8e0992e708403381fefa84f9e98bf9ca25024d74e48b98c6ea68` |
| `livemorebio/tests/test_subject_lifecycle.py` | `d5f5091216207fb5767c56fc87d9954f0d0433ea11a03b8858891e012111a3be` |
| `livemorebio/tests/test_closed_manager_source_publication.py` | `226c3eb07c93cf545a131cc682719bab4f2841cfec2b2f5fa62613cd1c796cda` |
| `livemorebio/tests/test_committed_publication_snapshot.py` | `9c457e2317ee419b7f3c46be44ab38584fcbb257c81e39c5f898937c5cb36441` |

## Red/green evidence and test-harness distinction

Every invocation used a fresh private review environment, Python3.11.15 from the
retained fresh venv, no pytest cache/bytecode/auto-plugins and a45s outer alarm.
The exact ASGI-compatible wrapper is retained in the confirmed-activation report.
It refuses network/DNS/listeners/urllib, processes and actual numerical/clinical
constructors; TestClient's internal socketpair is allowed. These tests use authored
records/candidates, never operational stores, participants or solver output.

| Packet | Result | Private root suffix |
| --- | --- | --- |
| Startup32 + migrated legacy1, before implementation | 33FAILED /1.41s | `v58yuuc4` |
| Same after first implementation | 33PASS /1.39s | `igff8_of` |
| Added missing READY candidate | 1FAILED,32deselected /1.49s | `cx2jy0t5` |
| Startup33 + legacy1 after correction | 34PASS /1.61s | `hk4k16zc` |
| Closed fence6 activation +2 bookkeeping, before setter fix (test author) | 8FAILED,8deselected /1.40s | `24z1zkto` |
| Expanded26, after setter but before startup (test author) | 23PASS,3startupFAILED /1.56s | `7xn1u2kk` |
| Expanded26 after startup | 26PASS /1.14s | `fxm1ot38` |
| Snapshot private-name logging before correction | 1FAILED,8PASS /1.28s | `98aqwbdq` |
| Snapshot logging after correction | 9PASS /1.25s | `gnpdoiz1` |
| Activation preservation after startup | 31PASS,41other-family-deselected /1.08s | `z0duwl8l` |
| Source-fence/cleanup before setter | 41PASS /1.80s | `b4f8i4pu` |
| Source-fence/cleanup after setter | 41PASS /1.38s | `mc3r3rk1` |

All listed runs had zero unexpected I/O/process attempts. ASGI packets refused
one exact optional Git lookup into the existing fallback; the41-case packet did
not require it. The41-case wrapper allows only the reviewed MetabolicProfile
dataclass as a parameter carrier, while trapping both actual execution-adapter
constructors instead. Authored adapters exercise ownership/frames, not physiology.
No actual native worker was started. Results are bounded and not additive clinical
or full-suite evidence; the41 excluded activation-family cases are not passed.

An intermediate closed16 run gave4 failures/12 passes (pcy_z38p,1.46s); a single
repeat identified the fixture's unconditional unlocked-state assertion on the
subsequent committed GET (qlq708ve,1.62s). The author corrected the phase assertion:
pre-commit projection remains unlocked, while committed read owns authority and
not creation/manager. Runtime GET locking was not weakened. This fixture failure
does not erase the original setter RED or the retained independent P1 probe.

## Exact independent repeat selections

Use the ASGI-compatible wrapper in the activation report without its `-k`, with:

```
livemorebio/tests/test_checked_startup_publication.py
livemorebio/tests/test_subject_lifecycle.py::test_server_fails_closed_when_active_subject_restoration_breaks
livemorebio/tests/test_closed_manager_source_publication.py
livemorebio/tests/test_committed_publication_snapshot.py
```

This is69 cases, with no selection exclusions. Repeat activation's exact31-case
wrapper separately. For the41 source-fence/cleanup preservation cases select only
`test_execution_source_fence.py` and `test_execution_cleanup_races.py`; replace the
MetabolicProfile constructor trap with constructor traps on
MetabolicExecutionAdapter and CardiacExecutionAdapter. Do not select the underlying
continuous-execution module's actual solver tests just because its technical
fixture helpers are imported. No service/browser/native run follows from this.

## Remaining obligations and lesson

Root's exact combined69-case packet passed in1.58s, private root suffix
`_97p35c_`, zero unexpected I/O/process and one refused optional Git lookup.
The two old activation doubles were then migrated exactly as proposed in the
independent fixture review: prepared-source seam, explicit constructor call and
commit traps, unchanged-source assertions, original ValueError mapped to fixed
503 instead of obsolete422, and unchanged409 version-conflict contract. Both
pass in1.37s, private suffix `_k2u6kq8`, zero unexpected I/O/process and one refused
optional Git lookup. Their containing `test_model_source_authority.py` is frozen
at SHA256 `13fa71af47f69ee289a25df4f8ff1cc57e307f1fec5621e97e7910499e95ea0c`.
This test-only migration did not change any frozen runtime or packet above.

Independent runtime review/repeat is next. Real checked registry-to-server startup,
the actual persisted-model integration, binding/preview and unchecked selection
families, whole-product UI/terminal/stream/experiment workflows and every recording
remain separate work. No commit, push, PR, installed-pointer or service change.

Lesson: source identity bookkeeping must remain available after execution closes;
it does not grant execution permission. Also, a checked stored identity and a
prepared model are not enough: the confirmation, memory publication, late-user
selection precedence and outside-lock object retirement must be tested together.
Local plans/lessons and independent review are the fallback for unavailable CE,
gbrain/context7/sequential tooling; no invocation of unavailable tools is claimed.

## Independent frozen runtime grade

2026-09-08, `source_research`: **CLEAR in this bounded startup/fence increment**.
No remaining actionable defect found in the reviewed change. This is not a
whole-product, browser, physiological or deployment grade. The prior independent
activation P1 and maker RED receipts remain preserved, not overwritten by green
results.

The reviewer read the entire implementation report, approved startup proposal
and refinements, closed-manager plan, complete changed startup/retirement/
snapshot functions, activation path and the complete real ExecutionManager.
Also read the authority/creation/shutdown guards, execution prepare/fork/start/
resume/consumer/observation callers, current-source and state/workspace gates,
typed model availability, relevant authentication/no-store middleware, all new
startup/closed-manager/snapshot tests and the exact migrated legacy startup case.
The review skill's core, testing, security, API, maintainability and performance
checks were applied locally. No external review service or additional model
agent was invoked, and no runtime or test source was edited by this reviewer.

### Independent execution evidence

Used the exact documented fresh-venv ASGI wrapper and selections, with45-second
outer alarm, private review stores, no bytecode/cache/auto-plugins, network/DNS/
listener/urllib/child refusals and constructor traps. Each was a separate Python
process. The41-case variant allowed only the reviewed MetabolicProfile data
carrier and explicitly trapped both actual execution-adapter constructors.
Its imported TechnicalAdapter advances an authored counter, not an ODE.

| Independent packet | Result | Private root suffix | Unexpected I/O / optional Git refusal |
| --- | --- | --- | --- |
| Exact startup/legacy/closed/snapshot selection | 69PASS,3 existing warnings /1.79s | `ei8_v0ov` | 0 /1 |
| Exact activation preservation selection | 31PASS,41 other-family deselected,3 existing warnings /1.00s | `qq15sjjx` | 0 /1 |
| Exact source-fence/cleanup selection | 41PASS /1.25s | `engv0_pc` | 0 /0 |

All outer processes exited0 and alarms were cancelled; no test/worker process
remained running from these invocations. No actual adapter, native worker,
service, browser, solver or operational record was invoked. The41 deselected
cases in the activation selection are not counted as passes. The private roots
are retained under the system temporary `livemore-research-review-` prefix.

### Mechanisms verified, not inferred from counts

- `server.py243–320` captures permitted generation and initialization ownership
  before the fallible registry getter; uses the actual checked keyword/object
  contract; and confirms storage before assigning prepared state and generation
  inside the same authority/creation/manager guard. Later operator selection wins
  over both late success and late failure.
- READY requires a returned model and its own prepared projection. Present typed
  unavailability and true absence stay distinct. Uncertain checked storage cannot
  become a healthy fallback or invented model reason. The denied branch avoids
  registry access and does not reauthorize an already-denied source.
- The retirement holder is owned outside the initialization mutex. Returned
  candidates and replaced model/action containers stay retained through the last
  guarded assignment. Invalidation, publication and their final reference
  release occur after the four locks. Cleanup failure does not poison an already
  confirmed selection; fixed logging excludes arbitrary exception identity.
- `execution.py73–80` permits only validated identity bookkeeping after close.
  It preserves `_closed`, owner/adapter/pending collections and explicit shutdown
  retry. Prepare/fork/open checks, start/resume control checks, late constructor/
  initialization/frame guards and source/lease conditions remain present. The
  real retained-manager tests establish DENY_ALL after startup uncertainty both
  before entry and after closure during unlocked construction.
- Product source capture rejects DENY_ALL before numerical preparation or current
  source observation attachment. The direct observation helper still depends on
  its documented caller-owned source authority; it is not newly claimed to be an
  independently closed-manager admission API. Retained history and separately
  source-labelled best-effort bus snapshots are not current numerical authority.

All six frozen files in the identity table were rehashed after review/tests and
matched exactly, including server
`f77b80c4d5a2cc86e38fe4dbfe76fe879a84840f6ee1cef833ef01f14b79bfab`
and execution
`2caafc14925604e3ad3e194c3c668a7cf41eb83eb5fea3afa619bf897c277aac`.
The root's later two-test activation seam migration was read and matches the
separately approved assertion-preserving design; its maker2PASS is not silently
included in the three independent results above.

Next gate remains the separately planned actual checked-registry-to-server
integration with authored private records and inert model constructors. No
approval is implied for native physiology, source changes, binding/preview or
other unchecked selection families. The useful lesson is that a retained closed
executor must still accept a deny-all identity fence, while only independently
verified cleanup can release its resources.
