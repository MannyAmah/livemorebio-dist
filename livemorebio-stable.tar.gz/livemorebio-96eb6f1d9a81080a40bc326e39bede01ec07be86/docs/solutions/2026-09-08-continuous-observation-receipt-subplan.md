# Continuous LIFE delivery: durable Aegle receipt and exact retry

Date: 2026-09-08. Independently reviewed amendment to the approved continuous
execution/API plans, R04/R29/R31/R47; implementation authorized with the
clarifications below.

The inherited Aegle telemetry controller rejects an already processed sequence.
After an HTTP response is lost, LIFE cannot distinguish that successful delivery
from no delivery. Retrying with a new sequence or timestamp would fabricate a new
acquisition. Preserve legacy v2/v3 admission behavior; add an exact engine-backed
delivery route with source-bound durable idempotency.

## Trust and identity

The new endpoint accepts only the existing LIFE-signed admission, original v3
envelope and registered manifest. The continuous operator is the separately
reviewed `metabolic-plasma-glucose-identity-v1`: modeled plasma glucose in mg/dL,
not a claim of ISF transport, chemistry assay validation or physical sensing.

Resolve model_context.prediction_id `execution-<32hex>-frame-<index>` against the
local execution manager's exact immutable frame. Recompute/check frame identity,
then compare subject/twin/version/source-generation/full selection, model ID,
condition, native model time, endpoint/compartment/unit and the exact scalar value
with that frame. Require engine authorship and modeled provenance, not a client
claim of either. Require registered virtual device binding and exact manifest.
Never use global bus snapshots or the active twin's downsampled display arrays.

Every request requires operator auth and LIFE admission signature; validating an
old signature alone cannot attach old data to a new twin/source. The original
received_at, captured/acquisition time, clock, envelope hash and sequence survive
all retries. Source changes fence pending delivery before another subject becomes
active. Saved/paused executions remain inspectable, not a new active data source.

Independent execution-lane review added two accepted invariants. Enforce a
unique (execution_id, frame_index, device_id, operator_id) binding as well as
envelope ID/hash, so an old frame cannot be restamped into a second new sample.
First admission requires acquisition time no earlier than frame.generated_at
and no later than 30 seconds afterward. This prospective source-age budget is
a software delivery policy, not a measured sensor or clinical latency tolerance.
An exact already-persisted receipt retry retains original times; it cannot reset
the sample's age. An existing receipt may finish its idempotent projection while
the same source is paused after backpressure. A replaced/invalid source cannot
project. Finishing delivery after pause does not imply numerical advancement.

Delivery-loss correction, independently reviewed by the LIFE consumer owner:
the first Aegle receipt may also arrive while paused when LIFE already durably
admitted the exact pending envelope before its first HTTP request was lost. The
same original frame/acquisition age, binding and current producer instance are
required; paused state must not deadlock this retained outbox. Never re-acquire,
restamp, or auto-resume. Invalid/restarted source or changed bytes still reject.

## Durable order and projection

1. Under the source-authority observation guard, verify current registry/runtime
   coherence and exact source/registered-device/frame/admission identity.
2. Append an encrypted receipt in the execution store before changing the view.
   Bind complete original envelope/manifest/admission, frame/source hashes and
   selection. Use a distinct AAD and account for receipt bytes in the global
   quota. Exact repeat returns the same receipt; a reused envelope ID with
   different content rejects. No history deletion or rewritten timestamps.
3. Project this admitted envelope into observation-only runtime fields. This is
   an idempotent last-value projection, not an append to runtime.applied for every
   packet and never a change to model parameters or initialized solver state.
   Repeated/older accepted frames do not roll back a newer observation.
   The continuous virtual channel has a separate `execution_observations` view;
   it must not overwrite `observations` or the physical/legacy `patch` state.
   Both use the same v3 observation normalization, but source class and separate
   receipt identity remain visible for comparison. This prevents a prospective
   modeled plasma value from replacing a person's actually measured channel.
   Key each projection by execution/source/device/operator, not a global frame
   number. The reconstructible view holds at most 64 streams; an exceeded bound
   fails delivery without deleting receipts. Source invalidation clears this
   view before another context is exposed. Readers select an exact stream and
   its source identity; unrelated executions cannot roll each other backward.
4. Only acknowledge applied delivery after projection succeeds. If persistence
   succeeded but projection/response failed, a retry checks the original durable
   receipt and safely projects it again (unless a newer accepted frame exists).
   A crash does not manufacture an application acknowledgement. A process/source
   restart requires explicit matching source recovery, not automatic attachment
   of old executions to the new runtime.

The receipt proves durable admission; runtime view state is reconstructible and
does not share a database transaction. Do not claim atomic commit across network,
SQLite and Python memory. Distinguish admitted, projected, and delivery-acknowledged
states in returned results and audit records. An exact historical receipt can
remain available even when source replacement forbids projecting it.

Root owns the Aegle receipt additions, API and LIFE publish/forward callback.
The execution owner retains gateway/outbox/consumer modules. Existing canonical
v2/v3 bytes and generic replay rejection remain unchanged. The callback receives
the exact gateway.admit/resolve_receipt dictionary, never re-admits it, and uses
its original received_at when signing/forwarding. Failed forward retains that
same outbox record and produces no new measurement.

## Required red-first tests

Exact duplicate after lost response; changed hash under same envelope ID; wrong
frame/source/subject/version/condition/unit/value/manifest; technical fixture
masquerading as engine; store failure before projection; projection failure after
durable admission and successful exact retry; later frame followed by older retry;
source switch during delivery; interrupted process and source-restart mismatch;
key/quota/symlink safety; no plaintext packet; no per-packet applied-list growth;
unchanged profile and numerical initialization; legacy v2/v3 golden/replay tests.
Then run actual two-service HTTP forwarding with a pinned numerical worker and
an independently verified browser/LIFE/Biology shared-frame inspection.

## Implemented packet and independent review

Root implemented encrypted receipt storage, exact signed frame intake, a separate
source-keyed modeled observation projection, authenticated consumer/observation
routes, and exact LIFE forwarding callback. The receipt is persisted before view
projection; original acquisition/receipt hashes and times survive response loss.
No physical observation, model parameter, or per-packet applied-list entry is
overwritten. Source invalidation clears only the modeled execution view.

Independent review found a plaintext-index integrity defect: a changed SQLite
frame index could select an older encrypted receipt during reconstruction. Three
red regressions reproduced index mismatch; all keyed indexes and frame numbers
are now checked against decrypted receipt contents before use. The source-age
test was strengthened to isolate the 30-second boundary from future-time checks.
The independent reviewer reran 31 receipt/observation tests successfully in
10.46 seconds, including actual native reduced-metabolic workers; three inherited
dependency deprecation warnings remain. Separate forwarding tests: six passed in
5.39 seconds. These are software/numerical delivery checks, not physical or
clinical qualification. Complete two-service consumer, browser, soak, CLI and
whole-product acceptance remain open; this packet does not close R01–R51.

Compounded lesson: encryption authenticates payloads, not the query indexes that
select them. Verify indexed ordering/identity against authenticated contents when
rebuilding a view, and distinguish pre-request loss from post-commit ACK loss.
