# Molecular notice assembly — independent root review

2026-09-09. Scope: the exact IviiqA A/B structure-only assets, not a product
release or legal certification. No source, built asset, public vendor directory,
scientific model, catalog mapping or existing operational store was changed.

## Evidence and independent result

Private packet: `/private/tmp/livemore-molecular-notice-assembly.5Sg5Wv`.

| Artifact | SHA256 |
|---|---|
| Complete 142,215-byte notice text | `374ced6e174c8ff1f9bcca290de4dff2766f8bbfe280d36bd34fb69df87d0fc9` |
| Exact source/output associations | `b844ed98f38b65d8a617e86dc6bca37d5b670dde47ae00f1e0c21b2eb9fe2df8` |
| Accepted build result | `fbbe521d9f08eff73908903f0289287598130315efbb305ddcb13431cbafd8a2` |

Root read the complete assembler, all 16 tests, complete notice text in bounded
pages, release record, all family/source/notice mappings and all body locations.
The large unchanged source/hash lists were independently checked as data, not
treated as executable code or substituted for the readable notice review.

Independent test invocation returned **16 PASS in 0.044s**, chunk `4f11cf`.
The tests deny network/DNS, process launch and native loading. A separate
read-only, 30-second-bounded root verifier returned **ROOT_READ_ONLY_INTEGRITY_PASS**
in 0.302s, chunk `dd5507`: all 54 complete bodies match their original source
bytes/ranges and exact output offsets; all 89 credits match output bytes; all
1,228 pinned inputs rehash correctly; all assembly-result output links match.
The full logical family/body association projection was read in chunk `78aa61`.
Neither verifier reran the consumed assembly or wrote product files.

The 59 emitted package/version pairs use 27 original package notice blobs;
generated webpack runtime adds one, and embedded upstream bodies add 26, giving
54 bodies. `micromark-util-sanitize-uri` is **2.0.1**. Historical LiteMol sections
are preserved original notices, not claims that their old dependencies were
emitted by this build. Required SMAA and ColorBrewer acknowledgments and the
local binding-help formatter modification notice are present.

## Decision and remaining conditions

**Notice completeness/integrity for the enumerated inputs: CLEAR.**
**Public redistribution/rights acceptance: NOT CLEARED.**

CAS's Shadertoy intermediate grant remains unverified; the linked fastapprox
JavaScript port lacks a separately verified grant. Retaining original AMD MIT
and original fastapprox BSD terms does not invent either missing permission.
Both explicit exceptions remain PENDING and `rights_cleared` remains false.
Do not strip these source implementations, substitute numerical code, or vendor
the bundle merely to bypass this unresolved review. Private technical browser
verification can proceed under its separately reviewed finite plan.

Lesson: tie full notices and original credits to actual emitted membership,
retain byte-exact permission/disclaimer text, and separate an integrity pass
from the decision to redistribute. A green artifact check is not full Biology,
whole-product, physical-device or human-equivalence validation.
