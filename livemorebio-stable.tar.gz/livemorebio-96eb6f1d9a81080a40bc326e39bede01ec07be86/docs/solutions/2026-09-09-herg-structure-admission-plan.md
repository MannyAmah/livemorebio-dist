# Add the missing human hERG structural reference

Pre-code plan, 2026-09-09, within R12/R24. The live normal Biology button for
KCNH2 currently says no experimental structure was found. The actual catalog
only lacks an admitted mapping. RCSB explicitly identifies 5VA2 as human KCNH2,
cryo-EM at 3.8 Å: https://www.rcsb.org/structure/5VA2 .

## Minimal correction

1. Acquire the original 5VA2 mmCIF and source metadata into private staging.
   Verify PDB ID, human source, UniProt identity, deposited construct, selected
   model number, atom/chain counts and explicit unmodeled portions. Preserve
   author and label numbering. No tetramer assembly is inferred from one chain.
2. Add a failing lookup/identity/coordinate-integrity test before modifying the
   fixed catalog. Append only 5VA2 and map KCNH2 to it, with original bytes and
   hashes. Preserve all six existing structures byte-for-byte and all other
   missing/ambiguous mappings. Update the catalog's exact pin, not its verifier.
3. Use the existing hash-addressed coordinate route and package-data patterns.
   No remote first-hit lookup, patient transmission, generated coordinates,
   docking, reaction kinetics or individual-variant inference.
4. Independently review raw-source metadata and focused regressions, including
   missing/corrupt source refusal. Test the rendered reference only after the
   alternate local renderer is ready and independently reviewed.

The structural reference is static deposited geometry, not an executable ion
channel or evidence of a drug effect. Cardiac equations and validated states are
unchanged. Original PDB archive data use the archive's CC0 policy; third-party
augmented annotations are not assumed covered by that policy.

## Alternative renderer decision

The retained Molstar distribution path is still blocked by unresolved bundled
notices and repeated delivery failures. In accordance with Emmanuel's explicit
alternative-after-repeated-failure instruction, the UI owner is evaluating a
version-pinned local 3Dmol.js distribution. Its own exact license/dependencies,
source-coordinate fidelity, cleanup and actual browser behavior must pass; the
current source/identity/context checks are not waived. Existing work is preserved.
