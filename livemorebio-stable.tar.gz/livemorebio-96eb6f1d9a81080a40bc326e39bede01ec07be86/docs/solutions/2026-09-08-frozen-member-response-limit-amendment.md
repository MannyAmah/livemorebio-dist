# Explicit frozen-member read: bounded 16 MiB transport compatibility

Date: 2026-09-08. **Root and independent pre-code approval recorded; implementation
and acceptance pending.** Additive compatibility amendment to
[clinical SDK/terminal parity](2026-09-08-clinical-sdk-terminal-addendum.md).
No runtime, parser, SDK, audit or operational data changed for this proposal.

## Reproduced problem and scope

Root reports the independent client review admitted a frozen REAL_HUMAN cohort
whose explicit member response is **9,439,766 bytes**. The existing cohort contract
allows its entire serialized record up to **16,777,216 bytes (16 MiB)**. However,
`execution_client.py` reads at most 8 MiB + one byte, and `strict_json.py` rejects
any generic `max_bytes` override above 8 MiB. A permitted frozen record therefore
cannot be inspected through the SDK, even though the backend can return it.

Change **only** an explicit, exact frozen-member detail GET to a fixed 16 MiB
response and parser cap. The generic JSON default remains **2,000,000 bytes**, its
public override ceiling stays **8 MiB**, other continuous responses stay **8 MiB**,
and requests stay **16 KiB**. No HTTP input limit, listing limit, response
compression policy, JSON depth/number/key rule or scientific eligibility changes.

## Existing seams to reuse

- `subjects.py:1327–1333` returns the exact stored frozen member wrapper, already
  contained in `record['members']`; the API does not append a second outer wrapper.
- `enforce_real_cohort_size` bounds canonical JSON for the entire cohort before
  encryption. The stored member, including its integrity/identity metadata, is
  smaller than that enclosing canonical record.
- `server.py:593–604` returns the wrapper as `JSONResponse` with `no-store`.
  The installed Starlette renderer uses compact separators, `ensure_ascii=False`
  and `allow_nan=False`. Its UTF-8 output cannot be assumed identical to canonical
  escaped storage bytes; the tests below verify that the actual response fits.
- `Platform.get_cohort_member` already requires attached mode, validates identifiers,
  percent-encodes individual segments, and validates schema/source/snapshot identity.
  Keep those semantic checks and once-only, explicitly requested disclosure.
- The shared client already rejects proxies, redirects and encoded responses,
  retains validated operation metadata, and handles safe close/read errors. Do not
  introduce a second transport stack.

## Exact implementation design

### Strict parser

Factor the existing admission implementation into a private `_parse_object` core.
It retains UTF-8 validation, byte length check **before decoding**, depth limit 64,
duplicate-key rejection at every object, finite floating-point numbers, the same
JavaScript-safe integer range, valid syntax and object-only root. One implementation
owns these checks; do not fork a permissive parser for clinical payloads.

`parse_json_object(raw, *, max_bytes=MAX_JSON_BYTES)` keeps its existing public
argument/range validation and all existing error behavior. It still rejects a
16 MiB override, booleans, zero, negatives and values above 8 MiB.

Add named wrapper `parse_frozen_member_response(raw)` with **no configurable size
argument**, calling the same private core at exactly `16 * 1024 * 1024`. The name
identifies the special response contract; it is not a generic larger parser.
Frozen schema/identity validation remains in the existing SDK, not duplicated in
the JSON parser. The private core is not a public caller-selected unlimited escape
hatch; the only public entry points have fixed, checked maxima.

### Transport policy

Add a private exact-route predicate and one fixed named constant
`MAX_FROZEN_MEMBER_RESPONSE_BYTES = 16 * 1024 * 1024`. Do not add a caller-controlled
`max_response_bytes` option to `_continuous_request`, SDK or shell.

The expanded read/parser budget applies only when **all** are true:

1. Method is exactly `GET`, request body is absent, response status is exactly 200.
2. Path has exactly `/api/cohorts/{cohort_id}/members/{member_id}`; no query string,
   fragment, trailing slash, extra segment, prefix/suffix match or empty component.
3. Each segment is the canonical percent-encoding produced by the existing
   `identifier` + `urllib.parse.quote(..., safe='')` contract. Decode once, validate
   the identifier, then require exact canonical re-encoding. Encoded slash,
   malformed percent escapes, double encoding and dot traversal do not qualify.

This is a capability for the known explicit read, not a reason to inspect headers
or the partially decoded body and retroactively expand a budget. All other requests
and non-200 error responses retain the existing 8 MiB read/parser ceiling.

For the qualifying response, request at most **16 MiB + one byte** from the existing
stream. Exact-boundary valid JSON may be accepted; one byte over is rejected before
parsing. Select the named parser only for that qualified branch. Preserve identity
encoding rejection, close-on-all-paths behavior, `CLIENT_RESPONSE` for rejected
GET bytes, and current request/status metadata without logging response text.

Do not trust `Content-Length` as a substitute for the bounded actual read. Do not
truncate, follow a second page, read another member, fetch the current twin, retry,
construct a local registry or infer model readiness. Normal error-code and POST
uncertainty handling are unchanged.

## Red-first tests and acceptance

New dedicated `test_frozen_member_response_limits.py` uses authored software
payloads, an isolated technical registry and intercepted byte streams. No person,
service, model or operational store is used.

1. **Critical regression:** admit a technically authored single-member REAL cohort
   under the actual 16 MiB serialization gate with a member over 8 MiB. Serialize
   the actual `get_cohort_member` result using the actual `JSONResponse.render`,
   pass those bytes through the real attached transport/SDK parser, and require
   complete frozen content/identity returned. No hand-built smaller replacement.
2. Verify the entire response wrapper, not just `snapshot`, at the source boundary.
   Include a near-limit admitted ASCII member and non-ASCII/control-string cases;
   assert actual HTTP UTF-8 response <=16 MiB, no truncation and exact decoded values.
3. Named parser accepts strict object bytes exactly 16 MiB and rejects 16 MiB +1.
   Generic parser still rejects >2,000,000 by default and any override >8 MiB.
   All request/other response limits remain unchanged.
4. Parameterize strict-parser failures at both entry points: invalid UTF-8, duplicate
   keys nested or top-level, NaN/Infinity/float overflow, unsafe integers, depth65,
   malformed syntax and non-object root. Do not weaken existing depth64 acceptance.
5. The large detail response qualifies only on the exact GET/status200 path.
   Pages, cohort summary, current twin, executions, POST, error status, query,
   fragment, malformed/double-encoded segments and path lookalikes stay8 MiB.
   Test valid canonically encoded identifiers accepted by the existing SDK too.
6. Assert read limit is16 MiB +1 only on that branch and8 MiB +1 otherwise. A
   misleading or missing Content-Length cannot bypass the actual byte bound.
   Oversize/malformed/read-error paths close once, retain safe metadata and make
   no retry or automatic follow-up request. Gzip/other encodings remain rejected.
7. Feed the expanded transport a large but wrong member/schema/source wrapper:
   existing SDK semantic admission still rejects it. Terminal output remains its
   metadata allowlist; no snapshot/clinical padding is printed to stdout/stderr.
8. Run existing strict/continuous transport and full clinical SDK/terminal tests
   unchanged. Add no new broad max override to satisfy old tests. Capture peak
   resource use of the bounded technical regression as diagnostic evidence, not
   a claim that16 MiB parsing consumes only16 MiB RAM.

Code-path map: exact known detail read -> fixed larger byte admission -> shared
strict parser -> existing frozen-identity checks -> explicit SDK result/compact
shell output. Every other branch retains its prior budget and parser contract.

## Ownership, limitations and review

The independent reviewer cleared revision c50d1f1f and the root read and approved
the complete amendment. The SDK/terminal maker owns this bounded parser/transport
packet after its request-correlation correction; root will not concurrently edit
`strict_json.py` or `execution_client.py`. Tests and
source freeze precede independent re-review. No UI alteration is needed.

NOT in scope: generic unlimited JSON, larger cohorts, larger member pages, new
clinical fields, deeper JSON, compressed transfers, chunked semantic reconstruction,
normalization changes, new record access permissions or biological qualification.
The admitted old payload can still fail independent semantic/JSON integrity
checks; byte compatibility does not erase those gates.

Engineering decision: scope accepted as a route-specific compatibility fix, not
a global limit increase. Approval is not implementation or acceptance evidence.
Lesson: storage, full serialized response and client admission limits must agree
for the exact explicit operation. Increasing a socket read alone cannot fix a
second, stricter parser boundary.

## Maker implementation checkpoint — pending independent grading

The full approved amendment was read before implementation. Dedicated red-first
matrix: **31 failed / 54 passed in 2.01 s**. All three actual private registry
cases admitted a single frozen authored member under the existing cohort gate,
then failed the prior 8 MiB client admission after actual `JSONResponse`
serialization. The fixtures cover an over-8-MiB ASCII member, an enclosing cohort
within 64 KiB of the 16 MiB ceiling, and Unicode/control-string padding. They do
not represent participants or clinical evidence.

Implemented only `strict_json.py`, `execution_client.py`, and dedicated
`test_frozen_member_response_limits.py`. The named fixed parser delegates to the
one existing strict core. Public generic default/override, other response limits,
request limits and all JSON semantic gates remain unchanged. The response limit
is selected before reading only for the exact canonical bodyless GET/status200
detail path. Canonical encoding is checked after one strict UTF-8 percent decode;
the assembled request URL must also have that exact path, so an attachment prefix
cannot silently enlarge a different route. No header/body inspection expands it.

The final matrix passed **601 tests in 5.58 s**, including **98 dedicated byte,
route, parser, semantic and cleanup cases**, unchanged research JSON parity,
clinical SDK/terminal tests and existing execution/Atlas client/command tests.
The original correlation-corrected SDK and shell hashes remain unchanged. Private
temporary registry files are pytest-owned only; no operational registry, HTTP
service, browser, native engine or model was used. All intercepted responses close
once, preserve current safe metadata, and never retry or fetch another record.

Resource diagnostic: `/usr/bin/time -l` around just the three actual registry →
JSONResponse → SDK cases reported **3 passed in 2.78 s**, **3.13 s wall time**,
**556,515,328 bytes maximum RSS**, **556,401,600 bytes peak memory footprint**, and
**0 swaps** on this macOS host. This is the whole Python test process, including
imports, fixture construction, encryption, canonical hashing and multiple retained
objects; it is not a parser-only measurement or a claim of 16 MiB RAM use.

Source freeze for independent review:

- `execution_client.py`: `c7f659843f2269122538023b95e9ffe446a3454d0a2598c23c6f7dac343c0e34`
- `strict_json.py`: `223228a095e85731bb7469fc6db9b26c59f7db72cfcf354048015f1980346a26`
- Dedicated tests: `607ab123c77194bff83f2f8e77a51f0a65a7129440c321f1cea1647214c48be5`

Compounded lesson: verify the full frozen wrapper across real storage and response
serialization, then scope any byte exception to the explicit read capability.
Do not globally widen parser admission to solve one operation's compatibility.
Independent review and an authorized actual terminal/API exercise remain separate
acceptance gates. The unavailable CE compound tool is not claimed as executed;
this document retains the local lesson and test evidence.

## Preservation correction to the factoring choice

The later Atlas review discovered that the generic parser is part of the exact
admitted converter identity. The original shared-core refactor broke retained
artifact compatibility even though JSON semantics passed. The separately
reviewed `2026-09-08-atlas-parser-identity-preservation.md` restores the exact
generic six-function implementation and moves only the fixed16MiB response
envelope into `frozen_member_json.py`, preserving the old imported API and shared
validator rules. No byte/route/SDK admission rule from this amendment is relaxed.
The old source freezes above remain historical, not current-runtime pins.
Independent965-test and actual unchanged-cache reuse evidence is recorded in
`2026-09-08-atlas-parser-preservation-implementation-review.md`.
