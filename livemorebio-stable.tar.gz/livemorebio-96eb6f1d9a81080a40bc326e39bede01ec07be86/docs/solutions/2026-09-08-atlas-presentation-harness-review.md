# Ordinary Atlas presentation harness implementation review

Date: 2026-09-08. Status: **frozen for independent implementation review; no browser or service run authorized**.

Approved scope is the complete ordinary-presentation run proposal and its root
clearance. This new tool is not the old full acceptance harness. Retained Atlas
28 PASS / 3 FAIL / 25 NOT_RUN results and unresolved asset terminal events remain
unchanged. No product, converter, cache, receipt or older harness is modified.

## Final evidence and ownership precision, before implementation

Root required a complete predeclared PASS/FAIL/NOT_RUN case ledger, including a
safe active-stage identifier on failure, rather than only completed screenshots.
Every paired capture will restore the inspected canvas to viewport center and
record equal viewport/canvas bounds; Isolate off is the same-camera restoration,
whereas Return is separately recorded as the full-body camera reset.

Root approved read-only PID/parent/start-time snapshots while the exact owned
Node child lives. The supervisor retains only proven descendants, not unrelated
process metadata or command arguments. After cleanup it rechecks the recorded
PID/start identities. Any surviving or uncheckable ownership is
`CLEANUP_UNCONFIRMED`. This is an observation/uncertainty safeguard, not authority
to kill by PID alone, to terminate unrelated Chrome, or to claim an escaped
process sandbox. Ordinary Chrome shutdown remains owned by Playwright. The
existing bounded terminate/wait then kill/reap applies only to direct Popen
children. All three service children are independently cleaned even after a
Node failure. Late Playwright allocations remain owned and receive close even
if their awaiting action already timed out; late/unsettled cleanup is not a pass.

## Red-first record

- Initial missing harness: 5 failed, 11 errors in 0.50 s.
- Initial implementation: 16 passed, two existing warnings in 1.94 s.
- Late resource ownership: two additional tests failed before implementation;
  subsequent private offline packet: 18 passed in 2.00 s.
- Network, DNS and both urllib entry points are refused for the private packet;
  Node tests use fake resources and never import Playwright or launch a browser.
- Actual registry creation, observation selection and server startup are tested
  in a fresh private fixture root with numerical constructors explicitly denied.

## Frozen candidate and coverage

| File | SHA-256 |
| --- | --- |
| `tools/check_atlas_presentation.py` | `625031248f8cbce3eab8185bbbfd4182bcfe2819d3da6ff1018cb6c59f431284` |
| `tools/check_atlas_presentation.cjs` | `4a8b11ab1c8424136404a0bd3ef8764d7668486430c3c1a913211726eddbb0e9` |
| `livemorebio/tests/test_atlas_presentation_harness.py` | `90e9fa7f981c36070d1e4ffad5af45723fa26e89f0c29f31e618a5a1d1ae171c` |
| Approved ordinary-run proposal | `fbd0cfcc33168ba05c08c0f5fcedc6dfdc82bb2a06e778b71a447fa363bcad17` |

The case ledger contains graphics readiness, 15 named captures and final identity.
Each entry is PASS, FAIL or NOT_RUN, with the active safe stage retained. A PASS
is a harness assertion result, never independent visual acceptance. Unknown
routes/mutations, identity drift and unexpected numerics stop the workflow.
Known `ERR_ABORTED` asset events are recorded separately and do not become a
network/performance pass. The tool never waits for asset `response.finished()`,
reads asset bodies, refetches them or rewrites responses. All nine loaded source
layers remain a required readiness condition.

The authored fixture comes from `clinical_registry_fixtures.human_payload` with
empty conditions and the explicit label “Authored software-only Atlas check, not
a participant.” Its custody is `urn:test:authored-fixture:not-a-clinical-record`
and its source URI is `urn:test:fixture`. Those are software test declarations,
not patient provenance or biological validation. The actual registry selects
observations once at successor version 2. Tests deny numerical constructors and
run the actual startup plus workspace projection through the browser context
validator. No direct database mutation or old registry reuse occurs.

Three additional ledger/descendant tests failed before implementation (0.18 s).
The first 22 new cases plus 47 inherited pure harness guards passed: 69 passed,
two existing FastAPI deprecation warnings, 5.92 s, in private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-jalcm7zw`.

The reviewer identified two unbounded awaits (route registration and Playwright
package metadata read), and the APIRequestContext redirect default outside the
browser route interceptor. Root authorized both bounded corrections. Each new
guard failed before its helper existed (stalled route 0.15 s; redirect/options
0.16 s). Both awaits now use the existing work budget. Exact metadata GETs use
`maxRedirects:0` and reject non-200 before body parsing while still disposing the
response. No route, returned content, deadline or product behavior is broadened.
The initial CJS `e4c66aa1…` / tests `30bd978c…` remain the pre-review candidate,
not accepted browser evidence.

Config lstat/read/validation is a separately bounded ≤5 s pre-browser setup;
failure there starts no browser and is retained as a supervisor failure/private
fixed setup log, without trusting an invalid output path or inventing case PASS.
The subsequent browser acquisition/work/capture/cleanup/evidence window remains
≤180 s (156 s work + 4 s failure evidence + three 5 s closes + 5 s write).
The parent's unchanged ≤190 s whole-Node ceiling covers both windows. Timers
bound asynchronous waits, not an uninterruptible native call; parent supervision
and explicit cleanup uncertainty remain separate safeguards.

Final repeat: **71 passed, two existing warnings, 6.42 s** (24 new and 47
inherited), private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-9t_c900k`.
Node syntax checking also passed. The process observer is tested with supplied
metadata fixtures; no OS process scan, browser, service or actual-cache read is
part of the test run.

Independent repeat command, from the worktree root (creates its own private
technical store, blocks all six network seams, never invokes either tool main):

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B -c '
import os, socket, urllib.request, pytest
from tools.run_review_stack import prepare_review_environment
root, env = prepare_review_environment()
os.environ.update(env)
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
print("Private test root:", root)
def deny(*args, **kwargs):
    raise AssertionError("OFFLINE_NETWORK_TRIPWIRE")
socket.socket.connect = deny
socket.socket.connect_ex = deny
socket.create_connection = deny
socket.getaddrinfo = deny
urllib.request.urlopen = deny
urllib.request.OpenerDirector.open = deny
raise SystemExit(pytest.main([
    "-q", "-p", "no:cacheprovider",
    "livemorebio/tests/test_atlas_presentation_harness.py",
    "livemorebio/tests/test_atlas_browser_harness.py",
    "livemorebio/tests/test_atlas_request_diagnostic.py",
    "livemorebio/tests/test_continuous_browser_harness.py",
]))'
```

Independent review and separate root run authorization remain pending. No
screenshots, warm performance result, rendered acceptance or R01–R51 closure is
claimed. Files outside this four-file write set were not changed by this task.

## Root one-run clearance

Root read both complete harness files, all24 new guards, the final deadline and
redirect corrections, and this report. Independent reviewer repeated71 passing
tests in7.92s with additional Node network/DNS/fetch refusal. All concurrent test
processes are stopped. Root authorizes exactly one fresh, isolated ordinary
presentation run of Python625031… / CJS4a8b11… / tests90e9fa… using the admitted
unchanged public cache and the authored observation-only fixture. Runtime code
must remain frozen until final source/process/context/cache/cleanup checks.
No automatic retry, source installation, physical/numerical experiment or
acceptance claim is authorized. Root must personally inspect every resulting
PNG and retain all failed and NOT_RUN cases.

## Durable lesson

A timeout rejects an awaiting operation; it does not cancel ownership of a
resource that may finish allocating later. Register ownership before awaiting
the allocation, close late resources, and retain cleanup uncertainty separately.
Likewise a stopped capture workflow must retain its unrun cases, not disappear
behind a collection of successful screenshots.

## Independent frozen-packet review

The independent reviewer read the complete proposal, Python supervisor, browser
script, dedicated tests, relevant startup/request producers and reused helpers,
then reread the final deadline/redirect corrections. The three frozen code/test
hashes in the table were checked before and after testing and remained exact.
The two reported findings are closed: route installation and package metadata
reads use the work budget; fixed API metadata reads disable redirects and reject
non-200 before parsing. Installed Playwright source was inspected read-only to
confirm its otherwise-default 20-redirect behavior. No HTTP probe was used.

Independent repeat of the four test modules above: **71 passed, two existing
FastAPI deprecation warnings, 7.92 s**. Fresh private test root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-udaph7n6`.
The six Python network seams were refused. All 55 Node test invocations also
received an in-memory preload refusing net/TLS, HTTP(S)/HTTP2, datagram, DNS and
global fetch calls, while retaining authored in-memory test doubles. The real
authored registry/observation-selection/startup fixture ran only in fresh private
storage with the dedicated numerical-constructor guards active.

No remaining actionable blocker was found in this bounded implementation review.
No browser or service was launched, no actual process snapshot was taken, no
model was constructed or solved, and no admitted cache was opened or changed.
All review tests stopped after this packet. Cleanup remains exact-owned bounded
attempts plus explicit uncertainty, not an escaped-process sandbox claim.
This clears the harness for root's separately authorized one-shot run, not its
future result. Every resulting image still requires independent visual review;
the old full-Atlas failures and all R01–R51/program obligations remain unchanged.
