# Atlas ordinary presentation — independent retained-evidence review

Date: 2026-09-08. Reviewer: release-redteam, independent of the renderer and
harness makers. This report does not modify either raw receipt or any image.

## Disposition

The narrow source-preserving selection presentation is visually acceptable at
the recorded desktop and mobile poses: exact-ID extent cues are readable,
assembled colors remain distinct from isolated highlighting, isolation is
reversible, sectioning suppresses the cue, and Return restores the whole body.
This is **not full Atlas acceptance**. Existing group-label collisions remain
visible. Long desktop element screenshots have capture overlays and cannot be
used as clean full-element layout evidence. Transport/performance remains open.

The ordinary ledger contains 17 PASS cases, but the supervisor still reports
`CLEANUP_UNCONFIRMED` with `owned_ports_released=false`. That failed raw outcome
is retained unchanged. Root's later listener/process postchecks are supplementary
observations, not a replacement PASS receipt.

## Evidence and method

Evidence root (all files below are beneath this exact directory):

`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-atlas-presentation-ld91xez0`

I read both JSON receipts completely and personally viewed all 30 original PNGs
listed in the inventory below. I used local-file viewing only: no new browser,
HTTP request, service, model, test suite, geometry conversion, or cache scan.
Read-only Python standard-library arithmetic recomputed hashes, PNG dimensions,
case/image counts, receipt identity agreement, recorded cache equality, label
rectangle intersections, and selected-label bounds. No pixels were edited.

| Raw receipt | Bytes | SHA-256 |
|---|---:|---|
| `presentation.json` | 21,265 | `240dae70fe0bdc87b9120b5cd250f6d4893e952391c05681a582732b08471f06` |
| `supervision.json` | 8,739 | `1c503df01c6ccf640fb601286c3acac831d5c07df00655142da223fa5727e111` |

The first arithmetic printer used a nonexistent `captures` key and stopped with
`KeyError` before modifying anything. The corrected read used the actual
`screenshots` key. This was a report-reading correction, not another experiment.

The fixture is explicitly authored, software-only, and not a participant. Its
`REAL_HUMAN` schema class does not convert it into real-person evidence. The page
shows observations-only/model-unavailable language; the report does not infer
physiology or numerical execution from the reference body.

Both receipts agree exactly on source, three service identities, and fixture.
The recorded package source is
`9ce846ff846af8a0bdda511ac9481913358e7a57185b4b5e19150e2d6bcbf68c`.
Recorded instances are Aegle `16abf41e-4666-4171-aa23-2bb31321c19a`,
LIFE `032a977c-0750-4626-98e2-a3275af05203`, and
Cendos `ca2da642-d774-4618-8377-e9c27e30ef94`.
The context hash is
`7f9a6a39a53fc6381088b3f9dcc5e4f4c9573c665538672051f30ae8b4fb405a`;
the Atlas manifest hash is
`8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a`;
the install receipt ID is `083b2f038e74476ebfcef07e4a22f7c2`.
These are retained run identities, not a new live service-identity check.

## Recorded coverage, without expanding its claims

All 17 declared cases are PASS: graphics readiness; desktop whole person;
desktop FJ1895 assembled, isolated, and assembled-restored; desktop FJ2629
assembled, isolated, and assembled-restored; section x; section off; Return;
reference group labels; mobile FJ2629 assembled, isolated, and assembled-restored;
mobile whole body; final identity. None of these 17 is FAIL or NOT_RUN.

There are 15 SAVED capture records and exactly 30 PNGs, totaling 7,527,477 bytes.
The page records zero script errors and work time 111.488373917 seconds before
cleanup. Its result is `REQUIRES_INDEPENDENT_VISUAL_REVIEW`, with
`full_acceptance=false`, not an automated visual PASS.

The environment is Playwright 1.58.2, Chrome 152.0.7977.76, installed Chrome with
SwiftShader software WebGL. This is neither a hardware-GPU benchmark nor a
biological-motion experiment. Four retained asset failures are `ERR_ABORTED`
(skin, heart, liver, brain). The receipt explicitly calls transport status
`UNRESOLVED; not a network/performance pass`. Visible geometry and nine loaded
layers do not close that issue.

### Selection, camera, and layout observations

- Desktop whole-person and Return captures show the complete reference body
  inside the canvas. Mobile Return likewise shows head through feet. Reference
  anatomy and lack of patient registration remain explicit.
- At both selected desktop IDs, assembled views retain beige anatomy and nearby
  structures; the selected-source extent has a small teal exact-ID label and
  corners. The earlier teal/beige triangle mosaic is not visible in these new
  captures. Isolated views show the single teal selected component; switching
  isolation off restores assembled appearance. This is presentation evidence,
  not repaired source geometry or a reproduction of the old attempt's camera.
- FJ1895 and FJ2629 remain distinct inspectable identities. The inspector shows
  Pancreas/FJ1895/FMA7198 and Parenchyma of pancreas/FJ2629/FMA63120, respectively,
  including source-native bounds and counts. The explanation accurately calls
  the cue a projected bounding box, not an anatomical contour or proof of pixel
  visibility.
- The action ledger frames each selected ID once, then toggles isolation on and
  off without another camera action. Each triple retains identical canvas
  bounds. Thus the paired comparison is controlled by recorded user actions;
  no numeric camera-vector or prior-attempt-camera equality was measured.
- Section x at 50% visibly cuts the scene, hides the selected extent cue, and
  displays recovery instructions. Section off restores the cue and appearance.
  Return restores full-body framing and removes the selected cue. In the mobile
  full-body inspector, selection details clear and Frame/Isolate are disabled.
- Desktop viewport/canvas sizes are 1440×1000 / 858×490; mobile sizes are
  390×844 / 334×440. Recorded document widths 1430 and 380 do not exceed their
  viewport widths. The mobile controls and inspector wrap readably in the
  inspected images; this is not a universal responsive-layout proof.
- All ten selected-cue label rectangles satisfy the eight-pixel canvas inset by
  independent arithmetic. Desktop labels are at (8,8), 142.453125×20; mobile
  labels are at (9.28125,123.7890625), 142.453125×20. Labels are readable in the
  paired ordinary viewport images.

The FJ1895 assembled and assembled-restored desktop **element PNGs are byte
identical**. The same is true for FJ2629 assembled, assembled-restored, and
section-off element PNGs. This supports restoration at those captured states;
it does not remove the element-capture overlay limitation described next.
Mobile before/after PNGs differ in bytes and were assessed visually, not called
pixel-identical.

## Remaining findings

### 1. Group-label visual collision remains open

`desktop-reference-labels-viewport.png` clearly contains overlapping group
labels around the chest and abdomen. This also appears in its element capture.
The group-label case checks containment, not collision avoidance, so its PASS
cannot serve as a non-overlap acceptance result.

I computed positive-area axis-aligned intersections directly from the nine
recorded label rectangles. There are nine intersecting pairs (one-based raw
array indices): `(2,7)`, `(2,8)`, `(3,5)`, `(3,6)`, `(3,7)`, `(4,5)`, `(4,6)`,
`(5,6)`, `(7,8)`. For example, pair (5,6) overlaps by
56.140625×18.2578125 CSS pixels; pair (2,8) overlaps by
41.6640625×17.8203125. This is quantitative corroboration of the viewed collision,
not merely a concern about possible future camera poses. Label collision was
outside this selection correction and is not waived here.

### 2. Long desktop element captures have overlay contamination

Expanded-inspector desktop `*-atlas.png` captures place the sticky global
navigation/fixture strip across the upper canvas or panel. It obscures some
readiness/cue content in those long images. Matching `*-viewport.png` captures
show the corresponding upper-canvas content clearly without that overlay.

The observed limitation is specific to this paired capture evidence; it does
not establish that the ordinary on-screen viewport has the same overlay defect.
Use viewport PNGs to assess the actual visible canvas and long PNGs only for
unobscured inspector content. Do not publish a contaminated long capture as
clean full-element acceptance. No CSS, DOM, screenshot, or capture retry was
used to hide the artifact in this review.

### 3. Raw cleanup failure stays failed; listener check needs distinct semantics

The supervisor has `cleanup_failure=CLEANUP_UNCONFIRMED` and
`owned_ports_released=false`. Separately, its four direct children are all
recorded reaped with SETTLED cleanup; all 12 recorded browser descendants are
absent from its final snapshot; `browser_ownership_cleanup=SETTLED`. The browser
receipt records page, context, and browser cleanup SETTLED.

Root directly reported historical `lsof` checks finding no LISTEN on 8910–8912,
`ps` checks finding the exact owned process list absent, and `netstat` showing
only retained TIME_WAIT. Those observations exist in root's tool outputs, not
an additional retained file. I did not re-run these OS checks or treat the
report as an independent historical observation by this reviewer.

The reviewed harness reuses a bind-availability probe after shutdown; that is
not the same assertion as absence of listeners/processes when TIME_WAIT remains.
The root postcheck and source behavior are consistent with a port-probe false
negative, but this report does **not** rewrite the observed field, certify a
new successful run, or claim proof about unrecorded/escaped processes. A future
bounded harness correction should distinguish startup bind availability from
post-run exact-owner/listener disposal, retain residual socket state explicitly,
and add negative tests for a real surviving listener. It must not simply accept
all bind failures or relax startup occupancy safeguards.

## Source preservation and limits

I independently compared the two retained cache dictionaries: all 16 entries
are identical in path, byte count, mtime, and SHA-256 before versus after. This
is verification of the receipt's preservation evidence, not another live-cache
read. The prior source/GLB overlap diagnosis and unchanged-source implementation
review remain the basis for geometric preservation; screenshots alone cannot
prove vertex/index equality.

This narrow result does not complete group-label placement, dependency/vendor
admission, transport timing, full Atlas acceptance, arbitrary near/far/camera
positions, 200% zoom, every failure/hidden/unloaded state, molecular layers,
native spatial registration, living-human motion, numerical source calibration,
or any of the six scientific programs. Previous failed Atlas attempts and the
master R01–R51 scope remain active. No operational or participant data were
accessed for this review.

## Complete personally viewed image inventory

Each exact filename below was personally opened. Hashes were computed from the
original PNG bytes after viewing; no screenshot is inferred from another view.

| Filename | SHA-256 |
|---|---|
| `desktop-whole-person-viewport.png` | `e4936eb3b920d732f9b33926c9a0efebe488d5f24b174c972341c1c1b3e4cc4a` |
| `desktop-whole-person-atlas.png` | `8043222eb009eda0ecdfcdd4fc0ebab8792801e7a1330621df413c851122bb83` |
| `desktop-FJ1895-assembled-viewport.png` | `f855588cd65a051fd7be51a9cdb8b7d5168fde871260f938cd235aae002d8e1b` |
| `desktop-FJ1895-assembled-atlas.png` | `8be8227499272b9255ccb14a9b85e8e373dcb6acbc285bd95383693a7ea53e65` |
| `desktop-FJ1895-isolated-viewport.png` | `422dd823e099a69a238c2bdfb1bfbf0689c5383ec53a8ad691cefbaa47f287c2` |
| `desktop-FJ1895-isolated-atlas.png` | `75388c6823ba7576e39b2eeb47a28f4a3e348964ce71b3bd33aa22b144db181e` |
| `desktop-FJ1895-assembled-restored-viewport.png` | `fd3e13fc049a7a37838b4693276b17f82b3902c4ef3b5d1957db473b6e9fecb9` |
| `desktop-FJ1895-assembled-restored-atlas.png` | `8be8227499272b9255ccb14a9b85e8e373dcb6acbc285bd95383693a7ea53e65` |
| `desktop-FJ2629-assembled-viewport.png` | `c00be368f1acbd3721598ce89d286626b72d14696ce441c0869b19a39788baf0` |
| `desktop-FJ2629-assembled-atlas.png` | `050a436910e6851ff2dc6b551c00d6df1a51ae174f6a5aeac1f9f2e05e57bfec` |
| `desktop-FJ2629-isolated-viewport.png` | `4e2c85e3a28b94343a0b07c74466c22f6eb2ad888dc7c7205922c80c57f13e46` |
| `desktop-FJ2629-isolated-atlas.png` | `1081e00c787ca27c2fdf3d7d248c01c6d64835a0d7ac175bb80eed2746c44790` |
| `desktop-FJ2629-assembled-restored-viewport.png` | `f00a5de08a372cb3cc00adc85f77b41a53230e4f4ae5db731f4ccc0566216825` |
| `desktop-FJ2629-assembled-restored-atlas.png` | `050a436910e6851ff2dc6b551c00d6df1a51ae174f6a5aeac1f9f2e05e57bfec` |
| `desktop-section-viewport.png` | `ccc1adf76694e7e4604f6267be920a3649a3453ac7c6c1724d4a1322b338890e` |
| `desktop-section-atlas.png` | `638bb07fce70c5cf2f0691624581edd970b42ccc8df78ed022aea65ede50f0d1` |
| `desktop-section-off-viewport.png` | `261f4331f100d8efae3d50fd5a10b00b4283f18ac400dd16fc453309d15912df` |
| `desktop-section-off-atlas.png` | `050a436910e6851ff2dc6b551c00d6df1a51ae174f6a5aeac1f9f2e05e57bfec` |
| `desktop-return-full-body-viewport.png` | `174227ad6f6c18e34eb423024fef08cc03293fd0b4674531cbeccd284c8c2476` |
| `desktop-return-full-body-atlas.png` | `6ad3656c961177ce6b037c43c61372773c7814518af249b2ecfe5c73e5967529` |
| `desktop-reference-labels-viewport.png` | `cde91b2ac1d0b286b4ecd507471c6de9f74345824b208a0b700e017a38af98ad` |
| `desktop-reference-labels-atlas.png` | `168f9984571433675f35ee7cbf092afd8f1cf25f08840662e023ad8f3e9e3a35` |
| `mobile-FJ2629-assembled-viewport.png` | `724756d2f7ab1d69256b5a09e0bbb44380558f435db09db97da0dff0492c8bf3` |
| `mobile-FJ2629-assembled-atlas.png` | `d1792842c9eeeb80f1d07468cd62c00ad3c3967af1afd3bfd6b9968616b76fbe` |
| `mobile-FJ2629-isolated-viewport.png` | `2a86c58b77ca52427f02e684c7b231e4fcff45b8036d5574a67f6a7aebac99b2` |
| `mobile-FJ2629-isolated-atlas.png` | `ecb17c7dafd86ab8d0cb1d839fae22fbbbed0c6ad9507b8cdf390c0efe37814c` |
| `mobile-FJ2629-assembled-restored-viewport.png` | `981e604b090656413000e6a13bc361a5a6a934b0db465c6fe1f760f02aa58cd8` |
| `mobile-FJ2629-assembled-restored-atlas.png` | `ab922d9db2fc3eab7d495fa0e870e0e18bf473a1f7c19fdcf40506da429f6bd2` |
| `mobile-full-body-viewport.png` | `823c614d7ce3d3466a2204d8041a64c57061a749c542acd4165d0630f5e8f30b` |
| `mobile-full-body-atlas.png` | `4d04c7bb7a643fcd16d7bd58486f24bddcd52aedf4d95337dcb6243100247d04` |

## Lesson

Keep three separate judgments: functional assertions, personally viewed visual
evidence, and resource-cleanup evidence. Contained labels can still be unreadable;
a clean viewport can have a contaminated long capture; a failed bind probe is
not synonymous with a surviving listener. Preserve each inconvenient result
under its original identity and add a scoped interpretation rather than silently
promoting a run to PASS.
