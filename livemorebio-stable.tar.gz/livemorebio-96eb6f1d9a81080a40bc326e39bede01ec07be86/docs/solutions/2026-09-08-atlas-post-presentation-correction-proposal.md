# Atlas retained presentation findings: bounded correction proposal

Date: 2026-09-08. Status: **read-only diagnosis and pre-code proposal**.
No code, tests, services, browser, source cache or retained evidence were changed
or rerun for this investigation. Root approval and independent review are needed
before implementation. The investigation skill was read fully; its implementation
phase is deliberately deferred under this task's read-only boundary. Connected
gbrain/Compound Engineering tools were unavailable; prior local decisions were
read instead.

## Evidence and scope

One actual ordinary run is retained, untouched, at:
`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-atlas-presentation-ld91xez0`.

- Source: `9ce846ff846af8a0bdda511ac9481913358e7a57185b4b5e19150e2d6bcbf68c`.
- Aegle instance: `16abf41e-4666-4171-aa23-2bb31321c19a`.
- LIFE instance: `032a977c-0750-4626-98e2-a3275af05203`.
- Cendos instance: `ca2da642-d774-4618-8377-e9c27e30ef94`.
- `presentation.json`: SHA-256 `240dae70fe0bdc87b9120b5cd250f6d4893e952391c05681a582732b08471f06`.
- `supervision.json`: SHA-256 `1c503df01c6ccf640fb601286c3acac831d5c07df00655142da223fa5727e111`.

The browser receipt has 17 harness assertions PASS and 30 saved PNGs, with page,
context and browser closure SETTLED. That is not independent visual acceptance.
The raw supervisor retains CLEANUP_UNCONFIRMED because its bind-based final port
check returned false. Four exact children were reaped; its recorded descendant
survivor list is empty. Root separately checked all four child and 12 descendant
PIDs absent, no 8910–8912 LISTEN sockets, and only TIME_WAIT entries. That OS
finding is root's contemporaneous evidence, not a new probe by this investigator.
Do not overwrite the original failure or retrospectively issue a successful raw
receipt. A separate adjudication may explain the checker defect.

Read prior art: ordinary-run proposal and harness review; remaining dependency
and visual proposal, especially label layout and screenshot cautions; selection
presentation correction; current controller/scene/CSS and pinned Playwright
screenshot implementation. Three selected retained PNGs were directly viewed:
`desktop-reference-labels-viewport.png`, `desktop-return-full-body-atlas.png`, and
`mobile-FJ2629-assembled-atlas.png`. Root/release reviewer own full 30-image grading.

The earlier full Atlas matrix remains 28 PASS / 3 FAIL / 25 NOT_RUN. Known asset
ERR_ABORTED events remain unresolved. This proposal does not close warm/frame
budgets, dependent Biology/molecular loading, zoom, fault, visibility, disposal,
touch or full-product/scientific obligations. Geometry, 489 IDs, source transforms,
material semantics, provenance and numerical availability are unchanged.

## 1. Group-label collision: product presentation defect

Confirmed mechanism: `atlas_reference_scene.js:75–80` writes each label's left/top
directly from its projected group bounding-box center. CSS line 11 translates the
label by half its own size. There is no collision placement and only projected Z
is checked, not measured screen bounds. `atlas_reference_presentation.js` bounds
the selected-ID extent label, not these nine group labels.

The retained desktop label screenshot visibly overlays the thoracic/abdominal
names. Its nine recorded rectangles have **nine positive-area pair overlaps**
(indices 1/6, 1/7, 2/4, 2/5, 2/6, 3/4, 3/5, 4/5, 6/7). This was calculated from
the retained JSON only. The current receipt lacks label keys, so do not infer
exact source assignments from those array indices. Existing bounds assertions
passed because every box is inside the canvas; containment does not test overlap.

Minimal complete correction, building on the existing proposal: one pure bounded
screen-space layout helper plus its scene adapter and narrow overlay CSS. Use
measured label sizes, stable ATLAS_GROUPS identity/order, deterministic left/right
callout placement with vertical spacing, and leader lines to the original projected
group anchors. Neither the leader nor a bounds-center label establishes surface
visibility or a physiological point. Do not move or warp meshes/camera to make
labels fit. Preserve source names and exact keys.

Before code, freeze spacing/inset and ordering rules, projection/behind-camera
eligibility, and section semantics. Suppress invalid/offscreen/disabled or isolated
group callouts. If the viewport cannot fit all eligible boxes without overlap,
report how many callouts are omitted and retain a complete accessible named list
in the existing inspector; never silently drop identities or shrink text to
illegibility. An active section must not turn an uncut group center into a claimed
visible cut-surface point. The fallback list is an overflow accommodation, not a
replacement for readable ordinary desktop/mobile callouts.

Red tests: nine coincident/nearby anchors; the retained nine rectangles; stable
results despite asynchronous partition arrival; 390/768/1440 widths; enlarged
text/tiny viewport; invalid/behind/offscreen anchors; disabled layer, isolation,
section and label-toggle transitions. Assert finite coordinates, bounded boxes,
pairwise non-overlap, exact key/text/leader mapping, deterministic omitted list,
and unchanged geometry/material/camera/source identity. The harness must retain
label keys and rectangles before overlap assertions. Independent ordinary images
remain required after approval, not just arithmetic PASS.

## 2. Return leaves a stale highlighted search option: product state defect

Confirmed path: scene `home()` at line 169 resets selected to null, clears
isolation/section and calls `onSelect(null)`. Controller `selected()` lines 85–90
updates the view, disables Frame/Isolate through `controls()`, and resets the
source article, but does not reconcile `[data-results]` selection. `controls()`
only updates option disabled states (line 81). `search()` is the only code that
assigns `selectedIndex=-1`, and Return does not call it.

Retained desktop Return and mobile full-body states still report `selected:
"FJ2629"`, because the harness reads the select control, even though the cue is
hidden and the source article says to select an element. The desktop PNG shows
the old highlighted pancreas row with disabled Frame/Isolate. This is UI state
divergence, not a surviving scene selection or source mutation.

Minimal correction: centralize result-selection reconciliation in the existing
controller. Null scene selection clears `selectedIndex`; an exact selected ID
present in the current result list selects that option; an ID outside the filter
must not select an unrelated option. Preserve the user's search query and matching
options after Return, allowing deliberate reselection without erasing their work.
Use the same reconciliation after results are rebuilt, so same-manifest refresh
does not falsely clear a still-selected matching ID. Canvas/skin selection outside
the filter remains identified by the source article, never by a false list match.

Red mounted-controller tests: search/select/isolate→Return yields scene null,
list index -1/value empty, hidden cue, disabled Frame/Isolate and reset article;
select the same retained option again and verify exact-ID activation; exercise
header Home/front/side/back paths, canvas selection outside the filter, matching
selection across same-manifest refresh, and changed-manifest reset. Retain all
existing camera/Retry/cancellation/source tests. No additional fetch or mutation
is needed. Future receipt should name `search_result_value`, not ambiguously
`selected`, and retain article/cue/control state to test their agreement.

## 3. Tall host screenshots contain sticky chrome: capture-path defect

Ordinary desktop viewport PNG shows header/navigation at the top and the body in
its panel. The tall Return host PNG crops the header into the top of the supposed
Atlas-only image and overlays source status. Mobile host image does not show the
same contamination. Current CSS explains the responsive difference:
`workspace.css:20,33` uses sticky header/top 0 and sticky scope strip/top 68;
line 148 makes the mobile header static.

The harness snapshots canvas bounds, takes a viewport image, then calls element
`screenshot()` at CJS lines 206–207. Pinned Playwright
`server/screenshotter.js:185–206` independently scrolls that element, computes a
document rectangle, and detects whether it fits the viewport. Chromium
`crPage.js:203–220` requests `captureBeyondViewport` for the taller element. The
snapshot therefore describes the earlier viewport, not the compositor/scroll
state of the tall element screenshot. This source path plus the retained pair
explains the contamination; it does not establish a broken ordinary sticky header.
No header/CSS product change is proposed.

Minimal harness correction: keep ordinary viewport images as primary evidence.
Replace beyond-viewport host screenshots with a bounded visible-canvas clip at
the already inspected centered camera and a separately named ordinary inspector
viewport after explicit scrolling. Use `page.screenshot`, not a tall element
capture that performs its own scrolling. If source details need multiple views,
predeclare bounded inspector scroll positions; do not stitch, hide/mask chrome,
inject CSS, resize a page just to fit a screenshot, or crop existing evidence.
Retain canvas/viewport/scroll/header/scope rectangles immediately before and after
each capture. A visible clip must lie inside the current viewport and below any
intersecting sticky chrome, otherwise retain a capture failure.

Red harness guards: capture never calls oversized `locator.screenshot`; clip
rejects offscreen/occluded/negative/nonfinite bounds; each pair retains identical
canvas/viewport dimensions and scroll history; inspector scrolling is not called
a camera reset; failure records partial metadata before stopping. A later approved
blank-page sticky-header technical check can validate capture behavior, then
ordinary product images establish readability. Neither is authorized now.

## 4. TIME_WAIT mistaken for retained service: teardown checker defect

`check_atlas_presentation.py:130–143` attempts a plain bind on each port, correctly
conservative for startup. Finalization calls the same function at lines 340–346
and calls any failure CLEANUP_UNCONFIRMED. That answers “can a fresh socket bind
with these options?”, not “is an owned service still listening?”. The raw failure,
all-reaped receipt and root's LISTEN-versus-TIME_WAIT check match this mechanism.
Do not add sleep-until-TIME_WAIT-clears or reuse-address flags merely to pass.

Minimal separate teardown check: leave the startup bind guard unchanged. After
independent direct-child cleanup and descendant identity checks, perform a bounded
read-only listener query for exactly TCP ports 8910–8912. Use installed macOS
`lsof` with numeric output, exact port range, LISTEN filter and machine fields;
freeze its parser/exit contract before code. Retain only fixed-port PID/address/
state metadata, never command arguments or unrelated endpoints. Empty successful
result, or documented no-match exit with empty stdout/stderr, means no listener.
Missing binary, timeout, permission warning, malformed result or ambiguous exit
means UNCONFIRMED, not absence. A listener on any target, even unowned, fails the
release check without authorizing its termination. No connect/HTTP request is
needed. Exact child and sampled-descendant identity evidence remains independent.

Use an explicit new `owned_listeners_absent` field; do not reinterpret old
`owned_ports_released` records. Retain `cleanup_failure` when any PID, browser
closure, listener query or evidence write is unconfirmed. Source/cache checks
must still execute even after checker errors.

Red tests: no LISTEN plus TIME_WAIT-only technical transcript does not fail;
LISTEN on any exact target does fail; unrelated ports ignored without persisting
their metadata; IPv4/IPv6/wildcard endpoints; malformed/permission/timeout/missing
command/unknown-exit fail closed; all listener and identity checks still run after
another cleanup failure. Use authored subprocess results, no real sockets in the
unit matrix. A separately approved short local socket test can cover real active
close/TIME_WAIT behavior without product services, then the actual owned workflow
must retain new evidence. No original receipt rewrite or browser retry now.

## Proposed ownership and next gate

Split the two product changes (label layout and exact selection controls) from
the two evidence-tool changes (visible captures and listener teardown). Root
selects owners and reviews the small layout/query contracts before red tests/code.
Do not merge these into a broad UI redesign or change biological semantics.
Independent source review precedes another one-shot, source-frozen browser check.
The rest of Atlas and the full-product matrix remains active throughout.

Durable lesson: control state is not scene state; box containment is not label
readability; an oversized element capture is not the recorded viewport; and a
failed bind is not proof of a listener. Preserve each evidence boundary explicitly.

## Root pre-code harness contract proposal

This is the remaining harness-only implementation contract, separate from the
approved product label/selection fixes. Root reread both complete harness files
and installed lsof4.91 help/field documentation. No harness code has changed yet.

### Listener evidence

Keep `free_ports()` exclusively as the existing conservative startup bind guard.
Finalization instead queries `/usr/sbin/lsof` with fixed arguments
`-nP -a -iTCP:8910-8912 -sTCP:LISTEN -F pfnPT`; no DNS/port names, credentials,
command arguments, broad process selection or connection attempt. Fixed English
locale and minimal PATH. The machine fields are p PID, f descriptor, P protocol,
n numeric address, and T TCP metadata. PID/fd record boundaries must be explicit.
Require canonical positive PID, unique descriptor per PID, protocol TCP, a valid
numeric IPv4/IPv6 or wildcard address with one of the three exact target ports,
and exactly one `TST=LISTEN`. Other T fields may be accepted only from a small
documented numeric queue-field allowlist; no unknown arbitrary text is retained.
Unexpected/unrelated endpoints fail closed rather than being written as evidence.

Use one owned subprocess with a three-second total read/wait budget. Bound stdout
to64KiB and stderr to8KiB during reading, not just after communicate allocation;
on limit/timeout, stop/reap only that child with bounded TERM/KILL fallback. Retain
fixed failure category, never raw stderr. Unknown exit, missing binary, nonempty
stderr, malformed records, incomplete groups, parse failure or cleanup uncertainty
means listener inspection UNCONFIRMED. Exit1 with both streams empty is the
documented no-match result; exit0 requires a complete nonempty LISTEN record set.
Do not treat a socket's TIME_WAIT or ordinary bind failure as a listener.

New receipt field is `owned_listeners_absent`, plus bounded sanitized PID/fd/port/
address/state entries for a positive match. A real listener, including an unowned
one, means false and CLEANUP_UNCONFIRMED, not authority to kill it. Retain all
direct-child, sampled-descendant, browser-close, source/cache and evidence-write
checks independently. Do not reinterpret or rewrite old owned_ports_released.

### Capture evidence

Keep the15 existing named control poses and primary ordinary viewport images.
Replace each oversized host screenshot with a `page.screenshot` visible canvas
clip named `-canvas.png`. Do not call locator.screenshot, captureBeyondViewport,
fullPage, hidden chrome, injected styles or image composition. Snapshot canvas,
viewport, scroll offsets, workspace-header and scope-strip rectangles before and
after each image. Require finite positive canvas bounds fully inside the current
viewport and no positive-area overlap with visible fixed/sticky chrome; require
unchanged rectangles/scroll for the pair, otherwise retain failure.

Add exactly three ordinary inspector viewport poses after the FJ1895 desktop,
FJ2629 desktop and FJ2629 mobile triples. Scroll the existing data-selection
article into view, capture the current viewport with its real chrome and retain
its rectangles/visible text and source ID. No claim that this captures every
long inspector/provenance row. If the article exceeds the visible area, explicitly
record that partial coverage, not a full-element PASS. No new camera action is
introduced; the next existing capture restores centered canvas scrolling.

Freeze all18 visual poses in the initial ledger before launch (plus readiness
and final identity), yielding30 viewport/canvas PNGs plus3 inspector PNGs when
complete. Keep156-second work,4-second failure capture,15-second resource closure,
5-second evidence write,5-second config and190-second parent bounds unchanged.
If additional captures exhaust these budgets, retain NOT_RUN/failure rather than
increasing them during a run.

Snapshot `search_result_value` separately from selected source article/cue and
Frame/Isolate enabled state; Return must show empty result selection, cleared cue
and disabled selection actions while preserving query/options. Retain group-label
source keys, text, boxes and leader mapping; group case checks pairwise non-overlap
and separation from any visible selected extent label, not containment alone.
No screenshot, remote response, source geometry or failed receipt is rewritten.

### Tests and execution boundary

Implement red-first authored subprocess transcripts for empty/matched/IPv4/IPv6/
wildcard/unknown states, malformed records, stderr, timeout, over-limit data and
all cleanup paths. Authored DOM/capture stubs reject offscreen/occluded/nonfinite
clips, scrolling between paired captures and oversized element screenshot calls;
verify every pose is predeclared and partial metadata survives failure.
Use existing pinned local browser APIs as inspected, no new dependency.
Independent review must precede any actual subprocess/listener or browser exercise.
This written contract proposes implementation only, not a rerun or acceptance.

## Independent harness-contract precisions accepted by root

The independent reviewer read both harnesses and installed lsof documentation,
without querying any process/socket. Root accepts the following before code:

- Three-second query observation/read/wait deadline, followed only if needed by
  TERM+wait up to2seconds then KILL+wait up to2seconds on that exact Popen child.
  Ownership persists until reap or explicit cleanup uncertainty. These bounded
  four cleanup seconds do not change the190-second Node wait budget; that budget
  was never a bound on the entire Python supervisor including service teardown.
  `owned_listeners_absent` is null for inspection/cleanup uncertainty, false for
  confirmed LISTEN, true only for exit1 and exactly empty stdout/stderr.
- Require final newline for nonempty machine output, nonempty/unique PID and fd
  groups, exactly one P/n/ST field per fd; optional TQR/TQS only with canonical
  nonnegative decimal values and no repeats. Reject unknown fields, arrows,
  IPv6 zone text, duplicate singleton fields and incomplete records. Exit1 is
  not assumed to mean no match if any stdout/stderr or other failure exists.
- Clip coordinates are viewport CSS coordinates, never document scroll-adjusted.
  Save before/after metadata around each individual image, so a second capture
  failure cannot erase the first saved image. Inspector article text is labeled
  DOM text, not guaranteed pixel-visible content. Record its viewport intersection
  and chrome occlusion; require the identity header region actually visible or
  explicitly record the limitation/partial coverage.

The selected-cue obstacle is covered by dedicated technical tests, but the planned
group-label screenshot follows Return and therefore does not exercise simultaneous
group and selected-cue rendering. Do not claim it does. This remains a bounded
20-case/33-image ordinary presentation run; full Atlas coverage stays separate.

Root approves red-first harness implementation under this final contract. Its
independent source/test review remains required before any actual owned OS probe
or browser run. Original receipts/images, product source and admitted cache remain
outside that implementation write set.

## Root-approved product implementation contract

Root read all203 proposal lines and authorized **only sections1 and2**. No browser
or harness changes/run are part of this implementation. Owned product files:
existing `atlas_reference_presentation.js`, `atlas_reference_scene.js`,
`atlas_reference.js`, `atlas_reference.css`, plus dedicated tests. Independent
source review and a later source-frozen browser check remain required.

Freeze label-box inset8px and minimum box gap6px. Measure natural text dimensions
without shrinking. Iterate source keys in ATLAS_GROUPS order, never partition
arrival order. A finite anchor must have positive camera depth within near/far
and NDC x/y/z within[-1,1]. Invalid or absent anchors are explicitly omitted.
Anchor x<0 chooses the left rail; x>=0 chooses the right rail. Rail boxes are
inset from the corresponding edge. Use the nearest admissible vertical position
to the anchor, testing the inset bounds and positions6px above/below already
placed boxes; distance ties choose the upper position. Collision tests include
both rails. Previously placed boxes are not moved; unplaceable labels get a
stable space-limited omission reason. This is deterministic packing, not a claim
that every mathematically possible packing is found.

Each displayed callout keeps the original projected group-center anchor and a
leader to the facing box edge, with the endpoint vertically clamped to that box.
Both leader endpoints remain within the viewport; the8px inset applies to label
boxes, not a fabricated replacement for an original in-frustum anchor near an
edge. Leaders are reference-bound associations, not surface visibility or flow.
No mesh, material, camera or physiological quantity changes for label placement.

Suppress all group callouts for labels-off, section, isolation, hidden document,
lost context or disposed scene. The inspector displays the specific reason and
explicit omitted count. Its complete accessible nine-name list is always retained,
including loaded/disabled/unavailable/offscreen/space-limited states. Callout
overlay duplicates are aria-hidden and pointer-transparent. A stale/disposed
scene cannot publish a new label report into a replacement controller.

Null scene selection clears result highlight while retaining query/options.
Reconcile exact matching result selection after search rebuilds and view/control
updates; an out-of-filter scene ID leaves no false list match. Same-source Retry
preserves valid matching selection; changed-source reset clears it. No new request
or mutation is introduced. The selected article retains all source provenance.

Red-first tests cover pure layout invariants/retained overlaps and deterministic
overflow, actual scene integration with authored tiny geometry and fake renderer
(no GPU/network), and the actual mounted controller with DOM selection semantics.
No unresolved product choice remains within these bounds; a required deviation
must be raised before implementation.

### Approved selected-cue obstacle and inherited test fixture precision

Before the additive correction, root approved reserving the **one existing visible
selected source-extent label** as an obstacle. Pass its positioned, naturally
measured rectangle from the existing extent-label draw into group placement;
retain the cue, its text, and its placement entirely unchanged. Group boxes must
keep the same6px gap from this rectangle and from all other group boxes. Include
the obstacle's upper/lower boundaries in the finite placement candidates. Do not
hide all group labels merely because an element is selected. If no box fits,
retain the ordinary explicit space-limited omitted count and complete named list.
An absent/hidden cue supplies no obstacle; an invalid supplied rectangle fails
closed. This is one optional rectangle, not a generic layout engine. A red
near-corner collision test and actual scene integration test precede this change.

Root also approved adding only standard `getBoundingClientRect()` with authored
fixed dimensions to the inherited coordinate/disposal test's minimal DOM double.
Its first broader run failed because that double had no text-measurement method;
all existing geometry, idle, late-parse and disposal assertions are retained.
No production fallback or weakened assertion is permitted.
