# Molecular inspector: finite structure-only build and controller packet

2026-09-08. **Pre-code proposal; no build, install, new acquisition or browser run.**
The current product source remains frozen for root's separate startup diagnostic.
This packet advances R03/R23/R24; it does not close those requirements or turn a
reference structure into an executing molecular model.

## Decision and inspected basis

Use the retained Molstar **4.4.0 ESM package**, React18 and its existing plugin,
structure builders, selection, focus and measurement components. Do not copy the
full viewer bundle or build a replacement renderer. Replace the remote molecular
load path only when the local replacement passes the same useful interactions.

Read the full molecular dependency review and acquisition report, the master
R03/R23/R24 rows, actual ordinary/run/execution consumer seams, and the relevant
retained package entry/spec/UI/disposal/builder sources as data. The engineering
plan skill supplied the scope, reuse, test and failure-boundary review. gbrain,
CE and Context7 were not callable; local retained primary source is the fallback.
No upstream package code was executed. Root independently cleared acquisition
integrity, **not redistribution**, in the preceding packet.

- Archive: `/tmp/livemore-molstar-inspection.uCgWWp/molstar-4.4.0.tgz`,
  6,960,078 bytes, SHA256
  `d5c294fb5a87650c70a3012636b0060d60faca2e8542e3fd9a051df9678e06d5`.
- Exact upstream commit: `2b2dfd924589edce7b129e123323c87a4623bdb8`.
- The existing 4,894,529-byte full viewer contains a 707,751-byte embedded WASM
  payload and H264 encoder entrypoints; disabling MP4 at runtime is insufficient.
- The archive contains compiled ESM, declarations and SCSS, but no source-tree
  build config or resolved package lock. A new small entry can consume that ESM;
  acquiring the upstream TypeScript tree is not required for this build.
- Current ordinary Biology alone calls the CDN `Viewer.create`/`loadPdb` path.
  Saved-run and fixed-execution molecular context is textual. Shared wiring is
  new work; their existing immutable context and anatomy controls must remain.

Primary source references are the retained archive paths below, independently
hashed in its inventory, and their corresponding
[pinned upstream source tree](https://github.com/molstar/molstar/tree/2b2dfd924589edce7b129e123323c87a4623bdb8/src).
The previous [dependency review](2026-09-08-molecular-inspector-dependency-review.md)
and [artifact report](2026-09-08-molecular-distribution-acquisition-review.md)
remain attributable; this plan does not revise their failed or missing evidence.

## 1. Build entry and exact supported UI surface

Create `tools/molecular-viewer/entry.js`, `spec.js`, `package.json`,
`webpack.config.cjs` and a generated, reviewed `package-lock.json`. Use webpack
production mode, one ESM library entry, no eval devtool, no CDN externals and no
runtime chunk download. Compile the existing light SCSS into one local CSS file.
This is a small app adapter over upstream code, not a Molstar fork.

Direct source roots under `molstar/lib/`:

| Purpose | Existing module/API |
|---|---|
| Plugin initialization | Public `PluginUIContext` + `Plugin`, following `createPluginUI({target,spec,render,onBeforeUIRender})` orchestration with caller-owned cleanup, as root approved below |
| React18 rendering | `mol-plugin-ui/react18.js` demonstrates `createRoot(target).render(element)`; retain an owned root for unmount as below |
| Explicit spec entries | `mol-plugin/spec.js`: `PluginSpec.Action/Behavior`; `mol-plugin/config.js`: `PluginConfig` |
| Highlight/select/focus/camera | existing `PluginBehaviors.Representation`, `PluginBehaviors.Camera`, and `StructureFocusRepresentation` |
| Model-local annotations | existing StructureInfo, SecondaryStructure and ValenceModel custom-property behaviors; no remote annotation providers |
| Coordinates | `plugin.builders.data.rawData({data,label})`, `plugin.builders.structure.parseTrajectory(data,'mmcif')`, hierarchy `applyPreset(trajectory,'default', explicitParams)` |
| Visible structure tools | `StructureMeasurementsControls`, `StructureComponentControls`, `StructureQuickStylesControls` from their `mol-plugin-ui/structure/*` modules |
| Canvas and inspection | existing `Viewport`, `ViewportControls`, `SelectionViewportControls`, `LociLabels`, `SequenceView`, task progress components |
| Measurement transforms | existing `StructureSelectionsDistance3D`, `StructureSelectionsAngle3D`, `StructureSelectionsDihedral3D`, `StructureSelectionsLabel3D` |
| Styles | `mol-plugin-ui/skin/light.scss` and its upstream imports; system fonts only |

Build the spec explicitly, not by spreading `DefaultPluginUISpec` or the app
Viewer defaults. Actions include only the coordinate/model/structure/selection
and representation transforms used by this path and the four measurement
transforms above. Include ParseCif, TrajectoryFromMmCif, ModelFromTrajectory,
StructureFromModel, StructureSelectionFromScript and StructureRepresentation3D.
Do not register DownloadStructure, DownloadFile, OpenFiles, LoadTrajectory,
volume streaming, remote snapshots, MVS, extensions or animation actions.
`animations:[]`; no automatic camera spin, trajectory playback or displacement.

Set `VolumeStreaming.Enabled=false`, `Viewport.ShowAnimation=false`,
`Viewport.ShowTrajectoryControls=false`, `Viewport.ShowSettings=false`,
`Viewport.ShowSelectionMode=true`, and preserve controls/expand. Set
`components.remoteState='none'`, left and bottom controls to `'none'`,
`disableDragOverlay=true`. Use a small `structureTools` composition of the
upstream measurement/styles/components controls, omitting source/import/volume
controls. A small viewport composition retains the upstream canvas, camera,
selection, labels and task UI but omits animation and snapshot-playback UI.
Capture-phase drop/drag handlers on the owned host reject file/session imports.
No new molecule drawing, atom picking, measurement algorithm or camera engine.

Rotation/pan/zoom/reset, atom/residue/chain selection, sequence selection,
focus, representation styles, distance/angle/dihedral measurement and deletion
remain real Molstar operations. Measurements are geometric distances in Å or
angles in degrees on the admitted reference coordinates, not biomarker assays.
Preserve the upstream local screenshot control if exposed by ViewportControls;
do not add remote upload/import. No patient label is passed into Molstar state.

The generic plugin modules themselves import default/volume machinery. An
explicit spec is therefore **not proof of a stripped output graph**. The build
stats and emitted bytes must prove that `apps/viewer`, `extensions/mp4-export`,
`h264-mp4-encoder`, background image extensions, MVS, remote importer extensions
and embedded codec/WASM payloads are absent. Generic unused provider constants
may remain in upstream core; assert their actions are unreachable and enforce
the runtime network boundary instead of claiming that zero URL strings exist.

### Ownership during initialization: root-approved narrow adaptation

The public callback signature above is verified in `mol-plugin-ui/index.js`.
The upstream React18 helper discards the React root handle. Root accepted a tiny
app-owned callback with the same `createRoot`/`render` calls, retaining that root
solely to `unmount()` before `plugin.dispose()`; no upstream renderer changes.

There is a second, narrower issue: `createPluginUI` creates its context internally,
awaits `ctx.init()`, and only then invokes `onBeforeUIRender`. `PluginContext.init`
rejects/rethrows without disposal. If that early initialization fails, the public
caller never receives the context. Do not claim that a callback can clean up an
object it never obtained. Root independently read these exact archive sources
and approved **a tiny app-owned equivalent of the public orchestration**, using
`PluginUIContext`, `Plugin` and React18 so ownership exists before `init()`.
This changes no renderer or upstream file; no iframe or broad plugin fork.

Allocate/register the context with its owner before calling init; handle both
the init task and `plugin.initialized` rejections. After init, check owner epoch
before creating/rendering the React root. Await `canvas3dInitialized` without the
upstream factory's empty catch: rejected/unavailable canvas is not success. Close
during init invalidates publication immediately; retain the pending owner until
init settles and its registered cleanup can safely dispose it. No second plugin
may start while that cleanup remains pending. A never-settling task or failed
cleanup is explicitly unconfirmed after the UI deadline, not a claimed release.
Unmount any mounted root before plugin.dispose, and handle all late completion
and rejection paths exactly once. Tests must cover early-init rejection, close
during init, late successful init, canvas rejection and pending cleanup.

## 2. Build-lock acquisition and distributable outputs

No dependency install is authorized by writing this plan. The finite next input
batch is an isolated official-registry resolution of this private build manifest:

- Molstar4.4.0 is installed from the already retained, verified archive, not
  downloaded again. Exact direct React/ReactDOM pins:18.3.1.
- Exact build pins from the package's declared toolchain: webpack5.92.1,
  webpack-cli5.1.4, sass1.77.6, sass-loader14.2.1, css-loader7.1.2,
  mini-css-extract-plugin2.9.0. No TypeScript/Babel/source compile is needed.
- Resolve the reachable runtime dependencies of those ESM roots into the lock,
  including rxjs/immutable/immer/tslib/react-markdown and any imports actually
  required. Their package ranges are not exact versions; do not invent them.
  Keep unused Molstar server/CLI/codec packages out of the entry graph. If npm
  installs an unused dependency from the Molstar manifest, distinguish private
  tool input from redistributed output and inventory its rights separately.
- Record exact Node/npm executables and versions, every resolved package version,
  tarball URL/SRI/SHA256, license/notices and the complete lock before a build.
  No Git/URL dependency other than the fixed retained Molstar file. No upgrade,
  postinstall/test scripts, telemetry, vulnerability-fix command or native addon.

Proposed batch limits for root approval: at most384 distinct resolved package
versions,32MiB per archive,128MiB total compressed and512MiB total unpacked,
with15-minute aggregate acquisition wall budget and30-second per archive limit.
Only HTTPS `registry.npmjs.org`, no redirects, proxy inheritance or retries.
Resolve metadata first; display the exact lock closure/size inventory before
the archive batch. If a dependency requires a lifecycle script, native build,
different origin or exceeds a limit, stop with its exact fixed package identity.
This is one bounded build-input decision, not permission to run `npm install`
with unreviewed lifecycle scripts or expand to another toolchain.

After input review: install only the verified private cache offline with scripts
disabled; run the explicit webpack/Sass entry build, not Molstar's build/test
scripts. Bound build at120seconds, retain failure output without environment or
paths in product errors. Compare two clean offline builds with the same lock,
toolchain and entry bytes; require equal final file hashes before vendoring.

Admitted outputs only:
`console/lib/vendor/molstar-4.4.0/structure.js`, `structure.css`,
`manifest.json`, `THIRD_PARTY_NOTICES.txt` and required exact license texts.
No prebuilt viewer HTML/favicon/JPG, fonts, MP4/WASM, source map with local paths,
worker or lazy chunk unless explicitly reviewed as a newly required output.
Initial output ceiling:8MiB JS,256KiB CSS,1MiB notices/manifest. An oversize or
unexpected output is a build finding, not grounds to substitute the full viewer.
Manifest records entry/spec/lock/toolchain and each emitted size/hash plus the
upstream archive identity. Independent review must verify all bundled licenses;
the existing incomplete full-viewer license text is not the new notice inventory.

## 3. Protected reference coordinate path, no runtime discovery proxy

Root owns this server/source lane. The existing `/api/structure?gene=` takes an
unbounded query, picks first UniProt/PDBe hits, and returns only an ID. Replace
its molecular-inspector use with a strict curated catalog lookup, auth first,
no-store and fixed safe errors. Retain successful legacy `gene`, `pdb`, `uniprot`
fields when known, add a versioned reference descriptor; unknown remains null,
not a guessed accession. No automatic network work at page open or target click.

Proposed minimal new byte route:
`GET /api/molecular/structures/{64-lowercase-hex-sha256}/coordinates`.
It serves only bytes present in the admitted package catalog, never a filesystem
path, arbitrary PDB/URL or user input. Reject query/body/unknown digest and wrong
method. Metadata and bytes require the same existing local authorization, fixed
PHI-safe access audit, no-store and exact build headers. No active-subject lookup
or numerical construction is needed to inspect a public reference in any mode.
Audit contains the fixed operation/reference asset identity only, not coordinates,
patient names, notes, model values or browser context snapshots. Audit failure
fails closed with fixed503; auth failure is not a missing-structure success.

Descriptor `livemore.molecular-reference.v1`: target key, source PDB ID/revision,
coordinate SHA256/byte size/format (`mmcif`), exact same-origin asset path,
source URLs, source title/method/resolution when supplied, author attribution,
rights, model/entity/chain IDs, source taxon/construct, coverage/missingness and
explicit `REFERENCE_ONLY`/no dynamic coordinates. Unknown source fields remain
null/explicitly unknown, never inferred from a target label. A catalog key maps
to a reviewed descriptor or fixed `MAPPING_UNAVAILABLE`/`AMBIGUOUS_TARGET` reason.
Keep catalog and original coordinate bytes immutable together in package data.

First source-admission work is finite: examine the five existing seed references
KRAS4OBE, TP531TUP, EGFR1M17, INS4INS, LDLR1N7D plus the already recorded PXR
6P2B reference. These are **candidate identifiers, not admitted coordinates**.
4INS must be labeled pig insulin, never silently humanized. 6P2B must retain the
tethered PXR-LBD/SRC-1p construct and ligand scope, not claim a whole native cell.
Propose one original text-mmCIF file per candidate, fixed official wwPDB source,
8MiB each/48MiB total, at most100,000 atom-site rows per file and30seconds per
file; fixed source URLs, redirects/encoding policy and source metadata must be
written and approved before that separate data-only acquisition. Never execute
or fit structures, infer missing coordinates, or rewrite the original files.

Keep all21 existing organ targets plus the seed/PXR entries visible in the
catalog. AMPK and GLUT1 are not automatically unique human identities. Targets
without an admitted exact mapping show an actionable source-unavailable reason,
not a dead click or alternate-species fallback. This first finite coordinate
packet does not satisfy all-target molecular coverage: the remaining mapping
work stays in R03/R23/R24's open dependency ledger with the unchanged target list.
Existing seed data and frozen Cendos records are not rewritten to match the UI.

## 4. One controller, three exact consumer contexts

Add `molecular_inspector.js` plus a small loader/contract module and scoped CSS.
Public app API: `mountMolecularInspector(host,{context,onClose})` returning
`open(targetKey,optionalFrozenStructureId)`, `setContext(context)`, `close()`
and `dispose()`. It owns one dialog/React root/plugin and one current load. No
global patient/plugin object, new generic state framework or module per organ.

| Consumer | Context and preserved behavior |
|---|---|
| Ordinary `biology.html` | Capture its already accepted Biology context_id; preserve organ/cell controls and unavailable numerical state. Context change immediately closes old structure inspection. |
| `protocol_biology.js` | Exact immutable run_id/member/stage plus existing inspection binding. Reuse the run's recorded PDB ID when present; disagreement with the admitted descriptor is unavailable, not remapped to today's first hit. Preserve recorded time/quantity and endpoint disclosure. |
| `execution_anatomy.js` | Exact execution_id/source_snapshot_hash/selected twin identity already passed by the owner. Targets remain reference context; never consult active twin/run fallback or suggest scalar frames moved the molecule. |

Reference inspection stays usable when model_availability is UNAVAILABLE; its
banner must still state the current mode and reference-only scope. Opening a
molecule never starts an experiment, advances playback, selects a person or
changes a model binding. Existing Patch/anatomy/Atlas/history routes remain.

Load sequence: capture monotonically increasing owner epoch + immutable context
key + target/descriptor identity → authenticated bounded metadata read → exact
same-origin bytes → verify status/build/descriptor/hash/format → existing
rawData/parseTrajectory/preset → publish only if all captured identities remain.
No `loadPdb`, provider URL, remote snapshot or substitute structure. Use a single
30-second UI operation deadline covering reads, initialization and publication;
8MiB byte cap, strict descriptor validation and text decoding before parser.
Verify parsed atom count/model selection against the admitted descriptor; do not
apply an unbounded symmetry assembly. The pinned default preset otherwise picks
the first assembly. Pass explicit params `{model:{modelIndex:<admitted index>},
structure:{name:'model',params:{}},showUnitcell:false}` instead; this exact shape
is used by `mol-plugin-state/builder/structure/hierarchy-preset.js`. Report the
source model number separately from its zero-based parser index, and disclose
unrepresented source models/assemblies. Do not call it a biological assembly.

Close/new target/context/dispose increments the epoch first, aborts owned fetch,
removes subscriptions and clears old labels/measurements/loading state. A late
factory result is unmounted/disposed rather than attached. All deferred parsing
and preset promises have rejection handlers; every boundary rechecks ownership.
The render callback also checks ownership so a stale context never briefly
mounts before the outer await notices it. Settle cleanup idempotently; cleanup
failure produces a fixed visible failure, not an automatic new viewer or retry.
Retry is explicit, same admitted source, and starts one new generation. Timeout
does not prove synchronous parser preemption; source admission/atom limits and
actual responsiveness testing remain mandatory. No hard worker guarantee is
claimed for Molstar's main-thread parser.

Use a proper labelled dialog, Escape/Close, focus return, keyboard-reachable
targets/selection tools and bounded mobile layout. Keep provenance as textContent
or escaped data, never HTML from source metadata. The page uses local CSS/system
font fallbacks, removing its Google Fonts and remote Molstar styles only when
local output is present. Root adds a page-local CSP with same-origin connect,
script/style/font restrictions compatible with existing inline page code and
required local data/blob screenshots; no `unsafe-eval`/external allowlist added.
Browser request trapping independently verifies closure, including settings,
selection, measurements, attempted drop and close/retry—not just initial load.

## 5. Files, RED strategy and independent acceptance

| Owner lane | Bounded files |
|---|---|
| Build/controller maker | new `tools/molecular-viewer/*`; new `console/lib/molecular_inspector.js`, loader/contract and CSS; admitted fixed vendor directory |
| Existing consumers | bounded replacement of old molecular block/style tags in `biology.html`; additive target wiring in `protocol_biology.js` and `execution_anatomy.js` only |
| Root source/API/package | new fixed `molecular_reference.py` and catalog/coordinate package-data directory; existing structure metadata adapter + one byte route; `pyproject.toml` exact data globs and build fingerprint coverage |
| Tests/docs | new dedicated build-contract/controller/route tests; additive outside-checkout wheel assertions and reviewed bounded molecular browser harness; this plan and final evidence report |

No edits to engines/biology.py targets, scientific equations, clinical dispatch,
registry lifecycle, Cendos records, Atlas geometry or old acceptance receipts.
Allocate named authors before code so root server ownership and concurrent UI
work do not overlap. Tests are written RED against current actual code first.

```text
retained archive + exact lock → local entry build → manifest/notices/wheel
admitted original CIF + descriptor → protected read → identity/hash admission
ordinary | frozen run | fixed execution → owner epoch → Molstar → explicit close
                             stale/failed/oversize ↘ no publish + owned cleanup
```

- `test_molecular_build_contract.py`: exact source/lock; no full-viewer/codec
  graph; no unexpected output/assets/eval/lazy requests; notices and output hashes.
- `test_molecular_reference_api.py`: auth-before-read, strict keys, missing and
  corrupt data, byte/atom/format/identity bounds, no discovery/network/model call,
  audit failure, safe errors/no-store/build identity; private authored files only.
- `test_molecular_inspector_ui.py`: mounted actual controller with deferred
  adapters; close/new target/context during metadata/init/parse/preset; rejected
  initialization/render/load/cleanup; exactly-once teardown; late resolve/reject;
  explicit retry; source mismatch; no stale labels or model-availability fallback.
- `test_molecular_consumer_bindings.py`: actual ordinary/run/execution branches,
  recorded PDB mismatch, unavailable model with usable reference, precise frozen
  member/time context and existing plots/cell controls preserved. Inert fixtures
  are never claimed as molecular rendering evidence.
- Existing wheel test extension: build/install outside checkout, network denied,
  import/read/static route each exact nested asset and catalog file, hash/notices
  equality, no lazy acquisition or numerical constructor on missing data.
- Preserve biology readout, protocol inspection, clinical availability, anatomy
  restoration/retry and wheel tests; do not replace behavior with source-string
  assertions or skip mounts to make the new import seam pass.

After independent code/artifact review, a separately authorized real-URL browser
check uses only technical context and admitted public structures. Record exact
runtime/build/process/asset identities, all requested cases PASS/FAIL/NOT_RUN and
owned cleanup. Desktop1440 and mobile390: actual coordinate scene, atom/residue
and sequence selection, focus/reset/styles, distance/angle/dihedral add/remove,
readable provenance/pig and construct limitations, unavailable mapping, all three
consumer contexts, changed-target/close loading races, five open/dispose cycles,
keyboard and200% zoom, missing/corrupt source and WebGL/context-loss retry.
Observe actual bytes and loading duration; no invented performance pass or
borrowed Atlas timing threshold. External requests blocked; retain any terminal
request failure separately rather than treating a rendered image as delivery proof.

Root/reviewer inspect screenshots and control outcomes; maker does not grade
maker. This packet restores reference molecular inspection and removes its
external runtime dependency. R24 still requires actual calculated/measured
molecular dynamics where supported; R23's five source-reference comparisons,
all-target mapping and the larger Atlas/full-product matrix remain open.

## Next finite decision and lesson

Approve the small entry/spec/file ownership and one bounded lock-resolution input
batch, retaining root's initialization-ownership decision. Then review its exact lock
and rights closure before the offline build; coordinate-source admission proceeds
as its separately bounded six-ID packet. No generic dependency installer,
scientific experiment or renderer redesign is needed to reach the first working
local molecular inspector. Missing mappings remain visible work, not scope cuts.

Lesson: selecting fewer runtime plugin features, distributing fewer dependency
bytes, and owning asynchronous UI teardown are separate obligations. The retained
source shows why each needs its own small test, without inventing new biology.

## Root architecture review and next input decision

Root read all351 proposal lines and the retained plugin entry, React18 helper and
PluginUIContext implementation. The existing-component architecture, caller-owned
initialization/disposal, reference-only boundary and three exact consumer seams
are approved. These restore the existing inspector; they are not a new renderer
or evidence that static coordinates react to a drug. Keep every current target
and its explicit missing mapping; no silent reduction of R03/R23/R24.

Next authorize preparation of the small entry/spec/build manifest and exact
**metadata-only lock resolution** in a new private root, within the proposed
384-package/15-minute bounds. Use an established npm lock resolver, not a new
dependency-resolution framework. Before invoking it, freeze its exact local
Node/npm identities, command, safe environment and the practical enforcement of
registry-only/no-retry/no-lifecycle/no-archive scope. If that scope cannot be
enforced by the chosen command, report the concrete limitation before executing;
do not claim flags that the tool does not support. This decision does not yet
authorize archive acquisition, install, build, vendoring, product edits, coordinate
downloads, browser/service work or a second Molstar download. Root retains the
server/API lane. The fixed six-ID coordinate proposal can be prepared in parallel
as source URLs/metadata policy only; no candidate is admitted by its PDB label.
