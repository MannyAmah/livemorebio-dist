# Clinical context correction — usable observation-only subjects

Date: 2026-09-08. Status: PRE-CODE, independent review required.
Parent: `2026-09-08-clinical-context-dispatch-correction-proposal.md`.
Scope: R05, R15–R19, R24, R34 and the approved physical-v3 contract; no scope
item is removed. This amendment replaces the parent's startup-failure-only
proposal. Runtime remains frozen during Atlas acceptance.

## Decision and evidence

Clinical prose currently chooses HEALTHY or T2D parameters through a diabetes
substring. Removing that inference is necessary but is not sufficient: a saved
unbound person must not prevent the application, History or LIFE observations
from opening. Nor may a healthy preview or the previous subject remain under
the newly selected identity. Both root and the independent reviewer traced
registry restoration, workspace, Biology, Patch, execution and Cendos consumers.

This packet separates the selected subject from availability of an executable
model. It does not add a new diagnosis algorithm, claim new person-specific
calibration, qualify a reference preset for a real person, or alter equations.
The original twelve-value DPP/NHANES and saved protocol contracts remain fixed.

## 1. Selected subject and model availability

Use the existing server `_state` authority; do not introduce a second selected
subject store. `_state["subject"]` remains the selected registry summary.
`_state["tw"]` is an AegleTwin only when its computational context resolved;
otherwise it is `None`, never a placeholder twin or default profile.

Add one shared typed availability projection, schema
`livemore.model-availability.v1`, with these exact fields:

- `state`: `READY` or `UNAVAILABLE`.
- `reason_code`: null when ready; one of `MODEL_BINDING_REQUIRED`,
  `MODEL_CONTEXT_UNSUPPORTED`, `MODEL_CONTEXT_SOURCE_MISMATCH`,
  `MODEL_CONTEXT_INVALID` when unavailable.
- `selection_mode`: `reference_preview`, `model`, or `observations_only`.
- `twin_id`: selected opaque registry ID, or null only for a reference preview.
- `twin_version`: exact selected positive integer, or zero for a preview.
- `source_generation`: the current model-source authority generation.
- `preparation_available`: exactly true for ready, false for unavailable.

Selection mode is an operator workflow choice, not a disease or scientific
qualification. An unavailable selected record always projects observations-only
even if historical metadata says it once had a computational selection. A
ready reference model remains visibly reference-initialized.

One `require_model` guard raises the safe named availability error before model
construction, source mutation/invalidation, action append, numerical capture or
worker creation. Direct adapter capture must use it for BOTH engines: the
cardiac capture's current `getattr(..., 0)` fallback would otherwise admit None.

## 2. Startup and explicit selection

Resolve the saved active record before constructing any healthy preview. If no
active record exists, the existing explicit healthy reference preview remains.
If one exists with unsupported/missing context, restore its identity and the
unavailable state without constructing either physiological engine. Preserve its
ciphertext, version, active ID, stored provenance and historical results.

Catch only the four named computational-context failures for this usable state.
Wrong encryption key, corrupted ciphertext, malformed stored record, database
failure or source-integrity failure outside the typed context contract remain
operational errors. Never catch arbitrary exceptions into an empty dashboard.

Keep `/api/twins/{id}/activate` as a numerical activation request. It must reject
an unbound record before changing either active identity, source generation or
registry version. Add the explicit protected mutation
`POST /api/twins/{id}/select-observations` with exactly
`{"expected_version": <positive integer>}`; reject booleans, coercions, unknown
keys, missing version and stale version. This selects an existing REAL_HUMAN
record for evidence inspection/device intake without numerical activation.

The new selection transaction retains lifecycle `ACTIVE` for compatibility with
the physical-v3 custody/binding contract, and adds
`selection_mode: "observations_only"` to the selected record revision. The term
ACTIVE denotes subject selection here, not model execution or hardware release.
The UI must say “Observations only”, not “Biology running”. Keep the one-active
subject constraint: demote the previous record with normal optimistic versions
in the same registry transaction, update active ID and append the selection audit
atomically in that database. No cross-database atomicity claim.

Selection requires an admitted REAL_HUMAN record with explicit pseudonymous
identity, existing consent/custody validation and retained source evidence. It
does not require every modeled physiological parameter or a prior Patch sample:
that would prevent enrolling the first correctly paired measurement. `life_patch`
consent is checked for pairing/intake, not inferred from observation selection.
PUBLIC_REFERENCE, technical synthetic and legacy reference cohorts cannot use
this path to authorize physical observations. All current physical-v3 hardware,
manifest, calibration, attestation and use-context gates remain unchanged.

Prepare/validate selection before acquiring the source-mutation context. The
exact committed-only sequencing and in-memory producer fence are specified in
section11 below; durable execution invalidation is not the fence. Do not expose
an intermediate new identity with old physiology. A confirmed registry rollback
leaves source generation unchanged. Do not reuse the current mutation context,
which invalidates before its body and can fail midway through execution writes.

## 3. Descriptive admission, strict compilation and legacy preservation

Retain every existing observation source-time/unit/QC/fasting/conflict check,
model-parameter domain check, consent, demographics and profile provenance rule.
Remove mandatory REAL_HUMAN profile compilation during descriptive create. Store
`model_binding: null` for newly unbound records; do not synthesize parameter
provenance. No new client-supplied binding is admitted in this correction.

Refactor measurement/declared-parameter validation so it can run without choosing
a template. Conflicting eligible basal observations and declared values still
reject before writing even when model availability is absent. Description and
evidence may be admitted without filling unmeasured engine parameters.

Use one strict governed resolver shared by AdmittedHuman, build, activate, Reset,
startup and detached SDK. Conditions never select a model. A caller's default
base argument cannot rescue a supplied human without a binding. Source/stratum-
bound legacy reference reconstruction remains a separate explicit compatibility
contract, tested against the exact twelve-value and full-member hashes in the
parent plan. PXR remains static and separate. SyntheticHuman compatibility does
not become a real-human binding.

Keep record schema v1, AES-GCM AAD, keys and read ciphertext unchanged. Numeric
record version is a lifecycle revision, not a new schema. Old parameter provenance
is historical only, not resolver authority. Same-key retry behavior must be
specified and tested against saved old requests without executing the removed
substring inference. Freeze the exact strategy in a reviewed addendum before
registry implementation; do not silently change hash semantics or treat a changed
payload as the same admission. No bulk migration or re-encryption.

## 4. Response contract and all consumers

Ready responses retain their existing values/shapes plus `model_availability`.
Unavailable responses are successful authenticated projections, not 503 retries.
The unavailable twin-state shape explicitly sets `profile`, `base`,
`profile_params`, `pk_context`, `parameter_provenance`, `provenance`, `intervention`,
`metabolic`, `cardiac`, `hepatic`, and `comparison` to null; `applied` is empty.
`active_execution` is null. Reference system contracts and capability descriptions
remain, but their current numerical state is UNAVAILABLE with the named reason.
No zero, empty plotted numeric axis, assumed 840-minute day or inherited trajectory.

Preserve subject-bound, admitted physical observations and Patch receipt metadata
outside the numerical twin, including original capture/receive times, class,
device, sequence and QC. Do not merge different subjects or envelopes. A small
engine-free observation holder/projection may be shared by available and
unavailable states. It cannot call a model constructor, recompute, change model
parameters or grow the intervention history. Existing v2/v3 admission checks must
run before updating it. Virtual model samples remain unavailable without a model;
historical replay stays explicitly historical.

Update these inspected consumers together:

- State, workspace, multiscale projection, selected twin listing and SSE: use the
  shared state projection; retain reference Atlas/contracts and current identity.
- Biology: return reference anatomy/mechanisms plus unavailable live readouts,
  without invoking `biology_state(twin)` or carrying over cell/organ activity.
- Patch: return admitted observed channels with their own clocks, no numerical
  channels or default physiological current values when unavailable.
- Workspace actions, stimulate/reset/drug/meal/lifestyle/factor, trajectory and
  virtual sample preparation: guard before source generation or writes change.
- Continuous capabilities/prepare/start/resume/fork, source capture for cardiac
  and metabolic engines, virtual consumer setup: enforce the selected binding.
  Pause/stop and fixed historical frame inspection remain available for cleanup.
- SDK/terminal summaries expose the same typed availability, not zeros or hidden
  healthy fallback. Explicit reference selection is a visible identity change.
- Frontend snapshot validation recognizes the discriminated unavailable-success
  shape. On ready-to-unavailable selection it clears all old plotted values,
  comparison readouts, active execution and live following. It does not retain
  last-good physiology under the new person. Disable numerical controls with the
  named reason; keep Atlas, History, onboarding and admitted observation controls.
- Legacy console and Biology must branch explicitly, dispose old live render
  resources and show reference-only structure. Missing values are not formatted
  through default-number expressions. Whole-body Atlas remains distinct from
  detailed Biology and remains inspectable.

## 5. Cendos source authority, not stale bus state

`_snapshot_twin` currently catches missing-profile errors and can leave the last
person's complete profile on the bus. Publish an unavailable tombstone containing
selection and source generation, with all numerical fields null, on unavailable
selection. Do not treat publication success as authoritative admission.

`/assay/current` must acquire a protected current-source snapshot from Aegle under
its source-authority lock instead of trusting `bus.snapshot("twin")`. Use the
existing configured fixed loopback peer, credentials, expected product/source
build and process identity checks; no redirects, fallback host or clinical data
in logs. A bounded, strict, no-store response supplies the complete source data
and its digest/selection generation only when the model is ready. Unavailable or
unreachable source rejects before assay construction. Authenticated retrieval is
audited without values. Reading a stale bus must never permit an assay even if
the tombstone publication failed.

The capture has an explicit linearization point. Subsequent selection changes
cannot mutate its frozen inputs. A completed result is attributed to that captured
source and cannot be presented as the newly selected current person. Do not claim
cross-process transactions or retroactively mutate fixed protocol History.

## 6. Red-first acceptance and preservation

Add tests before implementation for the full parent's dispatch matrix, plus:

1. Startup on encrypted unbound ACTIVE record: zero physiological constructors,
   same ciphertext/version/active ID; metadata and history available. Wrong key
   and corrupt storage remain distinct failures.
2. Ready to observation-only: one atomic selection revision, no stale charts,
   no old action/parameter provenance, correct new source identity. Inject registry
   failure before commit and prove no generation change or producer invalidation.
3. Direct cardiac/metabolic capture, all numerical routes and detached SDK cannot
   bypass missing context. Assert zero solver, worker, action or parameter write.
4. Valid physical observation admission without model preserves exact clocks and
   does not grow `applied`; wrong consent/subject/binding/hash/sequence rejects.
5. Cendos stale bus plus failed tombstone publication still rejects current assay.
   Frozen historical runs and explicit reference workflows preserve old hashes.
6. Descriptive validation and old/new idempotency remain exact; no condition text
   modifies a bound tuple or infers healthy status. Four-member legacy fingerprints
   and existing protocol golden tests remain unchanged.
7. Browser transitions on workspace, Biology, LIFE Patch, twins, cohorts, Cendos
   and legacy console, including responsive layouts and actual screenshots;
   terminal/API parity; visible unsupported reason and usable History/Atlas.

Independent code review and actual private-store browser tests are required after
unit/integration tests. No real participant is enrolled for QA. This correction
does not qualify all organ models; remaining scientific coverage and all six
requested experiments remain open in the master ledger.

## 7. Frozen descriptive request identity and legacy retries

This is a pre-code contract, not a migration or permission to edit saved
clinical records. The current `create_twin` inserts inferred
`parameter_provenance` into its normalized request before computing its hash;
the current `_idempotent` lookup therefore occurs too late to avoid inference.
The same lookup is used after an insertion race. Both paths must use the same
reviewed identity matcher.

Define `C(value)` as the existing canonical JSON operation:
`json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)`
encoded as UTF-8, with the existing default `ensure_ascii=True`. `H` is SHA-256
of the specified bytes, returned as lowercase hexadecimal. Arrays remain ordered;
do not sort observations, conditions, consent lists or member rosters to make a
changed request match. Hashes are identifiers, not substitutes for encryption.

### 7.1 Exact descriptive projections

The legacy twin creation projection `D_twin` contains exactly these fields, each
normalized by the preserved pure descriptive rules:

```
source_class, subject_id, display_label, consent_scope, chain_of_custody,
demographics, conditions, medications, genome, lifestyle, lifestyle_profile,
environment, observations, model_parameters, profile_sources, profile_coverage,
field_provenance, reference_source, reference_stratum, reference_lineage,
generation_seed
```

For REAL_HUMAN, the reference fields keep their existing null values; a new
reference source must not be manufactured during normalization. The projection
does not contain `parameter_provenance`, `model_binding`, creation identity,
registry-generated record identifiers, record creation/update timestamps,
lifecycle, numeric revision, selection mode or Patch bindings. Original source
capture timestamps inside observations remain part of the descriptive intent.

The legacy REAL_HUMAN cohort creation projection `D_cohort` contains exactly:

```
source_class, name, size, seed, indication, member_twin_ids, stratum,
reference_source
```

`size` equals the ordered roster length; `stratum` and `reference_source` remain
null for REAL_HUMAN. Current member records, versions, consent decisions and
snapshots are deliberately not part of this retry input. They are resolved and
frozen only for a genuinely new cohort, under Section 8's transaction.

Neither normalizer may call `AdmittedHuman`, `initialize_profile`, `build_twin`,
`generate_members`, a clinical text classifier, a solver or a numerical source
capture. This new branch is REAL_HUMAN-only; the existing SYNTHETIC and explicit
source-bound reference contracts retain their own reviewed normalization and
golden hashes. Extract the current eligible-observation/conflicting-declaration
checks into a pure validator without template selection. Preserve exact source
times, units, quality and fasting rules, declared-parameter domains and existing
consent/custody/profile validation for new admission.

### 7.2 Existing legacy key: authenticate content, never recompile

After authentication and bounded parsing, look up a nonempty supplied key before
any compiler or current member-eligibility evaluation. Require the expected row
record type, decrypted schema, record ID and REAL_HUMAN source. Preserve the
existing global key namespace across TWIN and COHORT; a cross-type key conflicts.

For a legacy twin without the new creation identity:

1. Normalize the candidate using the pure legacy rules to obtain `D_twin`.
2. Extract the same exact field projection from the authenticated saved record;
   require its equality with the candidate. Do not fill a missing saved field
   from a current template or a new default.
3. Extract the saved encrypted `parameter_provenance` object unchanged as
   historical data, not a model binding. Compute
   `H(C({**D_twin, "parameter_provenance": saved_parameter_provenance}))` and
   require equality with the existing row's request hash.
4. Return the existing current record, without writing, incrementing its version,
   re-encrypting it, changing selection, revising provenance or rerunning inference.

For a legacy REAL_HUMAN cohort, require equality with the authenticated saved
`D_cohort` and require `H(C(D_cohort))` to equal the stored request hash. Return
the retained cohort before inspecting current member eligibility. That retrieval
is not new enrollment, renewed consent or authorization to run an experiment.

Activation, demotion, observation selection and Patch binding modify fields
outside these projections, so old exact create retries continue to return their
current saved revision. Newly submitted client `model_binding`, creation identity
or lifecycle fields cannot be ignored as a way to smuggle a new binding into an
old retry; reject these server-reserved fields explicitly. Freeze legacy handling
of other previously ignored fields rather than silently changing their meaning.
Malformed historical projections/provenance, an unknown identity version, or an
unreconstructible legacy normalized request produce a safe
`LEGACY_IDEMPOTENCY_UNVERIFIABLE` conflict. Changed descriptive input produces
`IDEMPOTENCY_CONFLICT`. Neither error permits an inferred repair or replacement.

The legacy plaintext key index was not authenticated in the encrypted payload.
Projection and hash checks authenticate request content against that payload;
they do not retroactively prove historical ownership of a modified key index.
Do not claim that guarantee or migrate old ciphertext to imply it.

### 7.3 New encrypted creation identity

New REAL_HUMAN twins and cohorts retain their outer v1 record schemas and AES-GCM
AAD. Add an encrypted `creation_identity` object with exactly:

```
schema: "livemore.subject-creation-identity.v1"
normalizer_id: "livemore.real-human-descriptive.v1"
record_type: "TWIN" | "COHORT"
request_sha256: <64 lowercase hex characters>
idempotency_key_sha256: <64 lowercase hex characters> | null
```

The request digest is exactly:

```
H(C({"schema": "livemore.descriptive-creation-intent.v1",
     "normalizer_id": "livemore.real-human-descriptive.v1",
     "record_type": record_type, "payload": D_twin_or_D_cohort}))
```

The key digest is `H(b"livemore.subject-idempotency-key.v1\0" + key.encode("utf-8"))`
for the exact supplied nonempty key, or null when no key is supplied. Do not trim
or case-fold the key. The digest remains inside ciphertext and must match both
the requested key and the row index on every retry. It is not a credential or a
new authorization mechanism. Existing API key parsing/bounds remain in force;
this contract does not authorize a separate unbounded input path.

Store the same request digest in the existing row index, but never trust that
index without checking the encrypted identity and recomputing the digest from
the saved descriptive projection. A candidate must match that projection and
digest. New twin records store `model_binding: null` and no generated
`parameter_provenance`. The same matcher must resolve both initial lookup and
`_insert_or_existing`'s uniqueness-race recovery; do not leave a hash-only bypass
in the concurrent path. New normalization changes require a new declared version,
not changing the meaning of this identifier in place.

## 8. REAL_HUMAN cohort composition is not selected ACTIVE state

The current registry demotes every previously ACTIVE twin when selecting one
person, while real-human cohort creation requires every member ACTIVE. Replace
that cohort criterion, not the one-selected-person invariant or physical binding
rules. An admitted but unselected person can belong to a research cohort.

### 8.1 New composition and eligibility

For a new REAL_HUMAN cohort, require a nonempty ordered roster of at most 1,000
canonical twin IDs, without duplicates, each resolving to a distinct pseudonymous
subject. Reusing one person under multiple IDs does not increase cohort size.
Require authenticated REAL_HUMAN admitted records, explicit custody, retained
admitted source evidence and explicit `cendos_validation` consent. A nonempty
unrelated consent list, selected ACTIVE status, a reference preset or numerical
readiness cannot satisfy this requirement. Known revoked/invalid admission or
consent fails; do not invent a consent expiry or revocation mechanism absent from
the stored contract. Normal evidence/time/unit/QC validity remains required, but
complete executable organ parameters and `ADMITTED_COMPLETE` model coverage are
not cohort-enrollment requirements. Protocol-specific evidence sufficiency and
current consent are checked again before a later new experiment.

For each accepted member, preserve its entire authenticated decrypted twin record
as an immutable snapshot in the encrypted cohort `members` list. The wrapper has
exactly these fields:

```
schema: "livemore.frozen-real-human-member.v1"
source_class: "REAL_HUMAN"
twin_id: <exact registry ID>
record_version: <exact positive integer revision>
snapshot_sha256: <64 lowercase hex characters>
evidence_sha256: <64 lowercase hex characters>
snapshot: <complete finite-JSON authenticated twin record>
```

Require wrapper ID/version/source to agree with the snapshot. Preserve absent
historical fields as absent: do not insert a binding or rewrite old provenance in
the snapshot. `snapshot_sha256` is
`H(b"livemore.real-human-member-snapshot.v1\0" + C(snapshot))`.
The evidence projection has exactly these fields from the snapshot:

```
source_class, subject_id, consent_scope, chain_of_custody, demographics,
conditions, medications, genome, lifestyle, lifestyle_profile, environment,
observations, model_parameters, profile_sources, profile_coverage, field_provenance
```

`evidence_sha256` is
`H(b"livemore.real-human-member-evidence.v1\0" + C(evidence_projection))`.
This evidence digest retains declared versus measured distinctions; it does not
promote model parameters or profile coverage to measurements. Historical inferred
provenance, if present, is covered by the complete snapshot digest but is not
authority for a physiological binding. No hashes, snapshots or clinical values
are written to access logs or an unencrypted member table.

Validate member records, freeze versions/snapshots, build these digests, enforce
uniqueness, and insert cohort plus success audit inside the SAME registry
`BEGIN IMMEDIATE` transaction. Revalidate inside that transaction even if a
preflight read succeeded; do not open independent member-read transactions and
claim an atomic cohort. Audit failure rolls back admission. Existing-key replay
uses Section 7 before these new-eligibility checks and does not refreeze members.

The fully serialized new REAL_HUMAN cohort plaintext payload, including all
snapshots, wrappers, creation identity and record metadata, must be at most
16 MiB (16,777,216 UTF-8 bytes under `C`). Accumulate with an early bound while
reading/building members, then check the final exact serialized byte count before
encryption or any cohort/audit write. Over-limit input fails safely as
`COHORT_PAYLOAD_TOO_LARGE`; never truncate, omit members or silently split the
cohort. This is a plaintext-payload bound, not a hard process-memory or SQLite
disk-size cap. The existing 1,000-member count bound also remains independently
enforced.

### 8.2 Frozen execution and source-specific errors

Future experiments read these snapshots, never silently reload current members
as computational inputs. Each member's model binding, applicability and numerical
readiness are assessed separately from its frozen evidence. Current authorization
and consent checks are separate from that immutable scientific input: neither
changing nor revoking current consent rewrites history, and an old snapshot does
not override current authorization. Missing binding blocks that member or the
whole requested protocol according to its explicit completeness rule; this
correction does not silently drop unready members or substitute reference priors.

Old REAL_HUMAN cohorts lacking frozen snapshots remain readable and retryable.
Any new execution requiring member state must return
`COHORT_MEMBER_SNAPSHOT_REQUIRED` instead of fetching today's members. A new,
explicit cohort creation may freeze current eligible records; do not backfill old
ciphertext or relabel past experiments. All existing ready reference and legacy
reference cohort contracts, full-member hashes and fixed History remain unchanged.

Route an unbound REAL_HUMAN record or frozen member through the typed governed
resolver first: missing binding returns `MODEL_BINDING_REQUIRED`; unsupported,
invalid and source-mismatched contexts retain Section 1's named errors. Do this
before the generic `ensure_cohort_executable` null-binding guard, which otherwise
raises the public-reference-specific `REFERENCE_MODEL_BINDING_REQUIRED`. Do not
remove the public-reference guard or allow changing only a `source_class` label
to bypass its schema/lineage detection. Contradictory source/schema wrappers fail
validation, not fallback compilation. Apply this ordering to direct constructors,
activation, SDK, Cendos member dispatch and both engine capture paths.

## 9. Additional pre-code red-first cases

- Legacy REAL_HUMAN same-key retries with all clinical compilers and constructors
  patched to fail; include records revised by physical binding, activation,
  demotion and observation selection. Assert identical saved bytes, revision,
  active ID, audit semantics and source generation after retry.
- Changed conditions, consent, custody, sources, units, capture times, declared
  parameters or roster order conflict. Reserved-field injection, unknown identity
  version, malformed old provenance, hash-index tampering and cross-type key
  reuse reject. Record the legacy unauthenticated-key-index limitation explicitly.
- New exact retries validate encrypted identity/key digest; changed key-index or
  request-hash fields cannot switch authenticated intent. Concurrent identical
  requests produce one record, conflicting requests fail, and uniqueness recovery
  invokes the same matcher without inference.
- Pure descriptive validation still rejects conflicting eligible basal readings
  and declared parameters, without choosing HEALTHY or T2D or manufacturing
  unmeasured values. Existing reference golden hashes remain exact.
- Multiple eligible REAL_HUMAN members, only one or none selected ACTIVE, create
  one frozen descriptive cohort. Missing research consent, custody/source
  evidence, repeated IDs or repeated subject identities fail before write.
- Member changes racing composition are revalidated transactionally; retained
  snapshots/hash/version remain exact after later member edits. Same-key replay
  after those edits returns the old cohort without new eligibility or composition.
  New-key composition freezes the new eligible versions instead.
- Exact 16 MiB payload accepts; one byte over and member 1,001 reject without a
  partial cohort/audit write. Inject audit/encryption/storage failures and assert
  no partial roster or false successful enrollment.
- Missing REAL_HUMAN binding returns its clinical availability error, not a
  public-reference label; PUBLIC_REFERENCE schema/lineage spoofing still rejects.
  Legacy real-human cohorts without snapshots cannot resolve live member inputs.
  Per-member numerical failure never causes a hidden reference substitution.

## 10. Bounded real-human cohort UI/API projections

Root inspected an additional consumer: `project_cohort_summary_for_api` currently
returns non-public-reference records unchanged. Returning the new encrypted
cohort's full decrypted member snapshots from list/create/get would regress the
compact UI, produce large responses and expose unnecessary clinical detail.

For REAL_HUMAN cohorts, list/create/get return a bounded summary with schema,
cohort ID/version/lifecycle/timestamps, name, indication, source class, total member
count and a typed readiness state. Exclude `members`, all member snapshots, full
rosters/fingerprints, creation identity and clinical data. Legacy real-human
cohorts expose `COHORT_MEMBER_SNAPSHOT_REQUIRED`, not an empty eligible cohort.
Keep existing reference cohort responses and hashes unchanged.

Add protected no-store `GET /api/cohorts/{cohort_id}/members` for paged REAL_HUMAN
member summaries and `GET /api/cohorts/{cohort_id}/members/{twin_id}` for explicit
single-member frozen inspection. Page size defaults to10, is strictly1–50, and
cursor identity binds cohort ID/version, ordered position and page semantics
using the existing signed-cursor pattern. Reject forged/cross-cohort/stale cursors,
numeric coercions and unknown source kinds. A page row contains only the frozen
twin ID/version, display label, source class and typed numerical readiness; a
single-member response may expose its authenticated frozen snapshot to the
authorized local operator. Neither operation fetches today's profile as a
substitute. Access is audited without clinical values in logs; audit failure
cannot produce a false successful sensitive read.

Connect the existing compact member picker and Cendos cohort selector to these
pages, with loading/empty/error/retry and keyboard behavior. Members are inspected
on demand, not rendered as one large preparation column. No experiment is run
merely by selecting or inspecting a cohort. SDK/terminal use the same protected
summary/page/member contract. Direct registry getters remain available only to
the governed internal workflow and are not serialized by a generic HTTP return.

Add red tests that1,000-member cohorts never appear inline in list/create/get;
page responses contain at most50 summary rows, a selected member is exact, and
wrong/stale cursor or denied audit leaks no snapshot. Confirm browser compactness
and no horizontal overflow, preserving current reference picker behavior.

The shared registry audit used by selection and new cohort admission must be
implemented once, coordinated with the physical-v3 audit packet. Successful
mutation audit is in the same database transaction; sensitive read audit is
durable before return. Audit payloads are encrypted with a distinct fixed AAD
domain, not clinical plaintext log lines. Do not imply atomicity with the LIFE
journal or another service database. Freeze any necessary audit schema alongside
the reviewed implementation contract before code rather than improvising two
incompatible tables in separate owner lanes.

### Frozen shared registry audit storage

Implement one `registry_audit` table in the existing subject database with columns
`event_id` (random UUID primary key), `sequence` (unique monotonically ordered
integer), `nonce` and `ciphertext`. Plaintext indexes contain no record ID, action,
timestamp, subject/device fingerprint or clinical value. The existing registry
key encrypts audit payloads with AAD
`b"livemore.subject-registry.audit.v1\0" + event_id.encode("ascii")`; this does
not change the AAD of any pre-existing subject/cohort record. There is no new
secret, external logger or second audit database.

Permit the exact physical audit schema/fields/actions from the approved physical
amendment, unchanged. For clinical selection/admission/read, use
`livemore.subject-access-audit.v1` with those same ten fields and fixed actions
`inspect`, `select_observations`, `create_twin`, `create_cohort`, `member_page`,
`member_read`, `source_capture`. `opaque_record_id` remains inside ciphertext;
use null before a new record ID exists. Outcome is a fixed safe code. The audit
records authenticated local service access; current shared operator-token auth
does not identify individual staff accounts, and this packet must not claim
per-person staff accountability it cannot provide.

Use one persistent random subject-registry store UUID in `registry_state`, checked
as metadata, plus the actual local process/source identity. New initialization
may add that missing metadata, not rewrite existing record ciphertext. Every
event is at most4KiB of serialized plaintext; the shared registry audit allocation
is10,000 immutable events as already required by the physical packet. Check
capacity before access/mutation, reserve the begin/result pair in the same
transaction, and count reserved capacity. No eviction or silent overwrite.
Full/failed audit returns a fixed storage/audit-unavailable response without
leaking data or claiming successful admission. This finite local audit allocation
is explicit; enterprise retention/capacity rollout remains a separate release
requirement, not a promise of unlimited operation.

Sensitive reads append their begin event before decrypting requested clinical
payloads and result before return. New mutation, success audit and required
reservation release commit together. A failed mutation may have a separately
retained failure/access audit but never a successful event for rolled-back data.
Reuse one helper with an existing SQLite connection so nested connections cannot
break same-database atomicity. Do not hold this database write transaction across
network calls, native model execution or another service's transaction.

Begin and terminal result are two immutable encrypted events with the same
request_id, not an update to a begin row. Reserve BOTH slots before decrypting
clinical data. An incomplete begin after a crash retains its reserved terminal
slot; unrelated operations cannot consume it. Finishing uses its reservation,
not a fresh free-capacity check. Red tests cover exactly9,998 and9,999 charged
events, concurrent unrelated filling, crash-incomplete begins and successful
terminal completion with all unreserved capacity exhausted. Reservation metadata
contains only opaque event/request identifiers and capacity, no clinical fields.
Legacy idempotent retry “without writing” means no subject/cohort rewrite;
it does not exempt that access from the new encrypted begin/result audit.

## 11. Committed selection and storage-independent execution fencing

Independent review found that ExecutionManager.invalidate_source performs
fallible get/update operations for every tracked execution. A failure on its
first or later record must not retain the previous person's runtime, permit
an in-flight native result to commit, or make a persisted invalidation flag the
only source-authority check.

Give the product execution manager one current permitted source-generation
value, initialized under the source-authority lock when the manager is created.
This is a single value, not an unbounded set of revoked generations or copied
clinical records. Standalone deterministic manager tests may retain their
explicit unbound mode; the product factory must always bind the manager. Every
product generation rotation updates this fence while holding the manager lock,
before attempting durable execution invalidation. A newly created manager binds
the current authority generation, never a persisted execution's generation.
Use the consistent lock order: source authority, manager creation lock when
needed, execution manager, subject registry transaction. A manager never calls
back into source authority, a network peer, or the global bus while locked.

Effective source validity is the existing persisted flag AND equality with the
manager's permitted generation. Enforce it for prepare/fork, start/resume,
consumer binding/renewal, initialization admission/completion, advance admission
and final frame commit. The last check is under the same manager lock as the
write, after native computation returns. Status/lease projections must also
report the effective invalid state even if the corresponding durable flag could
not be updated. Historical frames remain attributed to their original source;
they are not presented as current live frames. Explicit pause/stop may still
attempt cleanup using their own recorded generation and normal revision check;
they do not authorize resuming an invalid source.

The observations-only selection sequence is:

1. Validate the requested record/version/admission and prepare the immutable
   selected summary, unavailable projection, empty action/observation state,
   success response and next generation before committing. Final record version
   checks and success audit remain inside the registry transaction.
2. Hold source authority and, if it exists, the manager lock across the short
   registry commit and the following in-memory assignments. No native call,
   adapter close, network call or durable execution-store operation occurs in
   this interval. A worker already calculating cannot enter its final commit.
3. On confirmed registry commit, set the manager's permitted generation, rotate
   authority generation and install the prepared new subject with tw=None and
   cleared prior numerical/live projection before either lock is released.
   These are assignments of precomputed values, not callbacks that construct
   models, serialize data, allocate response structures or access a store.
4. Only then attempt durable invalidation and owned producer cancellation.
   Durable failure must not restore the old generation, old twin, prior plotted
   state or authority. Remove old-generation scheduling in memory regardless
   of store availability; final frame/initialization checks retain the fence.
   Release/cancel owned adapters outside the nested locks using their existing
   bounded cleanup contract; retain cleanup failure without pretending success.
5. If post-commit persistence/cancellation fails, report a fixed
   SELECTION_COMMITTED_CLEANUP_UNCONFIRMED outcome with request identity and
   no clinical values. The new selection remains authoritative. The client
   re-inspects protected state and cleanup status; it must not blindly repeat
   the selection mutation or display the previous person's physiology.
   Tombstone publication is best-effort after this fence, never the authority.

A confirmed pre-commit rollback changes neither source generation nor the
manager fence. If the database commit outcome itself is uncertain, fail closed
as a storage/selection-unconfirmed operational state: prohibit current source
capture and numerical mutation until the authoritative record is re-read and
reconciled under the same locks. Do not classify a storage uncertainty as one
of the four scientific-context errors or fabricate a healthy/empty subject.
No automatic repeated mutation, cross-database transaction or rollback of a
possibly committed subject is claimed.

Represent uncertain commit with an explicit product `DENY_ALL` fence, distinct
from the optional standalone unbound compatibility mode. Never overload None to
mean both unrestricted and uncertain. Enter DENY_ALL while holding the manager
lock: it immediately rejects in-flight initialization/frame commits, scheduling
and consumer renewals as well as new API captures. Only a successful authoritative
registry re-read and coherent state reconciliation under the same locks may
install a new permitted generation. Storage uncertainty cannot leave an old
generation permitted while merely disabling new HTTP requests.

Add red tests for first and later durable invalidation get/update failure,
adapter cancellation failure, confirmed registry rollback, uncertain commit,
manager creation concurrent with selection, and a blocked native initialize/
advance completing across selection. Assert exact new subject/generation,
no late frame or checkpoint commit, no stale consumer renewal, no old data in
status/workspace/Cendos capture, typed committed/unconfirmed response, and usable
historical inspection/cleanup once storage is available. Existing ready-source
mutation tests must also prove that their generation fence is installed before
any fallible invalidation, without changing biological equations or saved hashes.

### Pre-code review disposition

Root and independent reviewer read the complete parent and amendment, inspected
the actual registry, initializer, server, execution manager and source authority.
The reviewer cleared the bounded packet after the committed-selection fence and
audit reservations were specified, with the explicit DENY_ALL clarification above
incorporated. Implementation is accepted for red-first work only after the Atlas
runtime acceptance freeze is released. This is not an implementation, browser,
scientific validation or whole-product release pass. All R01–R51 remain retained.

### Cleanup ownership clarification from red-test review

The assignment-only source fence must not call adapter initialization, advancement,
cancel/close or execution-store methods. Independently reviewed red tests must
trap those callbacks, not merely assert that scheduling stopped. When later
adapter cancellation cannot be confirmed, retain its owned handle and OS ownership
lock for explicit bounded cleanup; do not silently release the record for another
owner. Return the fixed `EXECUTION_CLEANUP_UNCONFIRMED` internal outcome, mapped
to the committed-selection outcome above at that route. Block admission of new
native work while owned cleanup is unconfirmed; History/status and explicit
cleanup remain usable. A successful cleanup must release ownership before test
teardown, verified through independent lock acquisition. This clarifies the
existing requirement to retain cleanup failure, not a new numerical model or
automatic retry. The exact helper/guard implementation still needs code review.

Explicit cleanup uses the existing stop control: when its record already says
`stopped` but this manager retains unconfirmed cleanup ownership, a new explicit
stop with the freshly inspected revision/generation may retry only that owned
cleanup. It does not restart computation or silently repeat a clinical selection.
Status projects the fixed cleanup code through its existing `failure_code` while
that local cleanup is pending; this is not a claim the failed database persisted
that code. Web/CLI controls must keep this explicit cleanup action available.
Successful cleanup removes the local pending projection, releases the OS lock
and keeps the historical stopped record. Ordinary stopped records without pending
cleanup do not become a general repeated-mutation bypass. Concurrent cleanup
attempts must not close or release the same handle twice. Preparing a current-
generation record may remain possible, but starting/advancing native work while
any owned cleanup remains unconfirmed must fail with the fixed cleanup code.

### Source mutation precondition and lock interval

Root's integration tests reproduced a ready check before reading a request body
followed by a subject switch; the subsequent action changed generation and tried
to use the now-unavailable twin. Recheck numerical availability under the source
authority before the assignment-only fence. A rejected precondition changes no
generation, action history or execution ownership. The manager lock covers only
the memory-fence installation for ordinary model actions, not their numerical
body. Keep the source authority across the body so other product source captures
cannot see partially updated model inputs. Durable selection uses the separate
short commit_guard contract above, not the ordinary action mutation helper.
Cleanup remains outside both locks. Red tests require no manager lock inside the
ordinary body and unchanged authority on rejected preconditions. This correction
adds no model or intervention and does not qualify unsupported physiology.

### Independent server-review corrections

Six independent technical HTTP probes reproduce two remaining problems: a
selection preflight storage failure is an untyped/cacheable 500, and legacy
trajectory/virtual-Patch requests can switch source while awaiting their body.
The bounded correction retains the initial readiness check, then captures a
coherent detached source and its generation under authority after body parsing.
Trajectory computation and virtual forwarding stay outside authority/manager
locks. Check the captured generation immediately before dispatch and again before
returning its result; reject a stale result with MODEL_SOURCE_CHANGED. Forwarding
is not a distributed transaction: LIFE/Aegle telemetry admission must independently
check the bound subject, device and current source before attachment. Do not claim
that this read-side fence revokes a request already sent over the network.

Virtual capture compares all four active identity fields (twin_id, subject_id,
source_class, version), not merely a subject string. The same comparison precedes
physical replay-watermark admission, so an external registry selection cannot
attach measurements to an old in-memory subject. No network runs under a source
lock, no observation becomes a model parameter, and no failed precondition rotates
the generation. Preflight RuntimeError/OSError/sqlite failures return fixed
REGISTRY_STORAGE_UNAVAILABLE, no-store and a new request UUID; post-commit outcomes
retain the separate uncertain/committed-cleanup handling. These corrections require
red-first race/error tests and independent re-review, not a new scientific claim.
