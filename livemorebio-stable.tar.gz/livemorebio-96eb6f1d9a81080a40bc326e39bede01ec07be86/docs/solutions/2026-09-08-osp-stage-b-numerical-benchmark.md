# OSP case2 Stage B: preregistered numerical benchmark proposal

Date: 2026-09-08. Status: PROPOSED, independent approval required before new solves.
Parent: [R11/R33 source subplan](2026-09-08-osp-insulin-reference-subplan.md).
Prior work: [Stage A native feasibility](../OSP_INSULIN_NATIVE_FEASIBILITY.md).
The [five botanical programs](2026-09-08-five-program-mechanism-measurement-plan.md)
remain active and are not replaced by this insulin benchmark.

## 1. Purpose, disclosure and decision boundaries

Establish whether the reviewed translation executes the pinned historical IVITT
recipe reproducibly, with numerically converged state and observer trajectories.
This does not establish human equivalence, dose safety, prospective prediction,
or personalized insulin treatment. It does not qualify a physical LIFE channel.

The Stage A baseline output and source-reference residuals have already been
seen. This is therefore **prospective for the new convergence/initialization
experiments**, not a blinded preregistration of the original baseline or physical
comparison. The thresholds below are proposed engineering acceptance rules,
not source-author clinical criteria. Root must approve this document's exact
content/hash before new runs; any later amendment retains prior outcomes and
creates a new benchmark version rather than silently replacing a failed gate.

Maintain three independent outcomes:

- **Recipe/source fidelity:** exact data, configuration, event and observer checks.
- **Numerical adequacy:** repeatability, convergence and initialization sensitivity.
- **Physical-reference discrepancy:** descriptive residual analysis only; no
  clinical pass threshold and no author-runtime equivalence claim without a
  separately obtained numerical author trace.

Stage C product wiring may be considered only after independent review of the
first two outcomes and honest display of the third. R33 remains open until the
remaining individualized, cross-system, visual and physical criteria are met.

## 2. Frozen source and runtime contract

Model repository commit: `17a7f8eaac8d6c3e3f49d0a6e0fe6101e4bc3e18`.
The [pinned author recipe](https://github.com/Open-Systems-Pharmacology/Glucose-Insulin-Model/blob/17a7f8eaac8d6c3e3f49d0a6e0fe6101e4bc3e18/GIM_simulations.m)
is the configuration authority for case2, not a newly optimized protocol.

| Source input | Required SHA256 |
|---|---|
| GIM_Healthy.xml | `e78bb23d39ce7138f46bb876a54b43becb79bbf833e50c0cd7006f2a80eac3cb` |
| GIM_simulations.m | `6cd652d8d2c23bceb5ed715625e614edc66fb0d46065c74c058a5e8560f0c2f0` |
| ParSets_OSPS.xls | `305577c76510cc423135c09a81b79188bbf70d62b007b30b7a33df590e6f945e` |
| Sorensen_1985_IVITT004.xls | `7332b2c85bf38041077c89b2afbde6cd7ee27ee13d7ad013bebb4db29f8fa79d` |

Use the already inspected private R4.6.1 ARM64, .NET8.0.30, rSharp1.2.2,
ospsuite12.4.3 and locked package set. Recheck selected runtime/source SHA256s
against the Stage A manifests before loading, not just the prototype's MD5
assertion. The retained corrupt upstream archive is not a runtime dependency.
Record the three native assembly/library hashes from the feasibility report.
No dependency updates, downloads, global installation or external network during
benchmark execution. Low-level SimModel XML v4 remains the input; do not spoof
the version or use the failed high-level PKML loader as a substitute.

Freeze the original R recipe, future benchmark harness and source transformation
manifest separately. Temporary absolute paths may change, source identities may
not. Do not execute arbitrary downloaded MATLAB/R scripts or deserialize a
user-supplied R/.NET object. Retain original attribution and do not redistribute
source reference spreadsheets without their separately reviewed rights.

## 3. Source preparation and initial-state identity

Read-only XML enumeration confirms **1100 state entries**, comprising **1073
`value` initializations and 27 `initialValueFormulaId` dependencies**, with no
overlap. Units are 1087 µmol amount entries and 13 litre entries. These are
solver states, not a count of independently validated human mechanisms.

Preparation must preserve the exact `entityId`, path, unit, variable/formula
identity and ordering manifest. Apply the empty Global sheet and all 37 Healthy
rows, then source `S_I=0.9`, TypeDM=0 and the eight enumerated disabled applications.
Source insulin potency is 7 nmol/IU with 5808 g/mol; dose is exactly
`0.04 * 7e-9 * 5808 * 1e-3` kg/kg. IVITT starts at 0 minutes and lasts 3 minutes.
This is historical recipe reproduction, not a clinical administration instruction.

After initialization, transfer all 1073 independent values by exact entity ID,
never position alone. Reject missing, duplicate, foreign or nonfinite entries.
Keep all 27 formula-defined initializations and their dependencies untouched.
Changing `persistable` to retain state output must not change equations or rates.
Preserving formula text does **not** establish that those 27 evolved states
continue unchanged: a new native import reevaluates their initial formulas.
For every treated/control import, collect all 1100 native states at its actual
T/C t=0 and compare by ID with the corresponding initialization run's final
1100-state vector. The 1073 independent transferred values must satisfy the
transport tolerance below. Enumerate each of the 27 recomputed values, its
formula/dependency identity, I-final value, imported t=0 value and difference.
Separately identify any source-intentional formulation/application reset caused
by intervention setup; never hide it in an aggregate convergence result.

Each changed initial value must be explained by an exact source formula and
the author recipe's reinitialization/application semantics. Any unexplained
difference stops candidate acceptance pending independent source review; do not
overwrite a formula or alter a state merely to make this comparison pass.
Call this **source reinitialization with independent-state transfer**, not full
1100-state continuation. Retain unchanged and changed-state counts, and the
complete mapping, for T0/T1/T2, C0/C1/C2, repeats/dense/disabled controls and the
long-initialization counterparts.

Decimal transport must agree pointwise within
`4 * binary64_epsilon * max(1, abs(value))` in each native unit; this is a
serialization test only. Do not truncate small hormone amounts to zero.

For source-tolerance runs, the complete FormulaList, reaction/event definitions
and all unapproved attributes must remain unchanged. For tighter runs, allow only
the two reviewed solver constants below to differ; retain an exact structural
diff and hash. No biological parameter may change to improve convergence or fit.
Each initialized state snapshot records its originating source, parameter set,
solver configuration, native stop time and ordered state hash. A later run cannot
quietly use a different tolerance's initialization under the same identifier.

## 4. Native solver and observer contract

The XML solver parameter references resolve to these source constants:

| Setting | XML formula ID | Source value | Benchmark variation |
|---|---|---|---|
| Absolute tolerance | 28623 | 1e-9 | B1=1e-11; B2=1e-13 |
| Relative tolerance | 28625 | 1e-4 | B1=1e-6; B2=1e-8 |
| Initial step | 28627 | 1e-10 min | None |
| Minimum step | 28629 | 0 min | None |
| Maximum step | 28631 | 60 min | None |
| Maximum steps | 28633 | 100000 | None |
| Use Jacobian | 28635 | 1 | None |

Before coding the setter, inspect the pinned native API or modify only the two
explicit numeric solver equations in an in-memory benchmark copy, after asserting
their IDs, roles and old contents. Any other changed equation fails admission.
Read native RunStatistics after every solve: requested/used tolerances must agree,
no automatic tolerance reduction, no warnings, finite ordered output and a complete
requested time grid. A solver failure cannot return a shortened successful trace.

Record all 1100 states by identity plus these four primary observers:

| PeripheralVenousBlood observer | Exact entity ID | Native unit | Display/comparison |
|---|---|---|---|
| Glucose / Plasma | `fT9KXj-pOEOMpswmFcDqXw` | µmol/l | divide by 1000 to mmol/L |
| Insulin / Plasma | `Wdd1jFvIGkyEfh0czha_uQ` | µmol/l | multiply by 1e6 to pmol/L |
| Glucagon / Plasma | `wT9hFIa100WGzxHvdPxp3Q` | µmol/l | retain native units or explicit conversion |
| Insulin Ex / Plasma | `hrlxPfqB4U-AzxZ9o_DyEg` | µmol/l | separate source pool, not case2's administered fraction |

All paths begin `GIM_Healthy|Organism|PeripheralVenousBlood|` and end
`<molecule>|Plasma`. Match ID, path and unit together, not a display name.
The administered case2 material enters shared `Insulin`, which includes endogenous
insulin. `Insulin Ex` must not be relabeled as this dose's exposure. The local
73 kg MATLAB variable is not permission to change formula-derived organ geometry.
Native one-element constant outputs may be expanded only with explicit constant
series metadata; missing time samples may never be filled with interpolation.

## 5. Run matrix, frozen before execution

One worker at a time, new private benchmark directory, no product stores. Each
row has an immutable input manifest and independent output files. B0 is the
source tolerance; B1/B2 are the tighter settings above.

| Runs | Initialization and intervention | Purpose |
|---|---|---|
| I0/I1/I2 | Respectively B0/B1/B2, no applications, 0:1:1000 min | Full-state initialization convergence |
| T0/T1/T2 | Each from its corresponding I snapshot, case2, 0:1:200 min | End-to-end treated convergence |
| C0/C1/C2 | Same corresponding I snapshot, IVITT active with zero dose, 0:1:200 min | Paired numerical zero-dose controls |
| T2-repeat | Fresh process, exact T2 serialized inputs | Deterministic numerical/configuration repeatability |
| T2-dense | Same I2 state and B2 tolerance, 0:0.1:200 min | Output-grid sensitivity and event/peak inspection |
| D2 | Same I2, case2 dose retained but IVITT disabled | Event-disabled control; compare body observers, not unused formulation depot amounts |
| I2-long | B2, no applications, 0:1:2000 min | Source-initialization adequacy check, not silent replacement |
| T2-long/C2-long | Source intervention/zero-dose from I2-long final state, 0:1:200 min | Consequence of longer initialization for intended observers |

This is 15 solves. No new dose, T1DM case, CIVII schedule correction or botanical
effect enters this matrix. Abort each native process after 120 seconds and the
whole batch after 20 minutes. Monitor RSS and terminate above 3 GiB; record the
sampling interval, so this is not misrepresented as an instantaneous OS hard
memory guarantee. Preserve termination artifacts and report failed/resource-limited
status. Do not raise limits automatically after seeing a failed result.

## 6. Proposed numerical acceptance, not clinical tolerances

For values with the **same quantity and native unit**, define
`E(a,b; A,R) = abs(a-b) / (A + R * max(abs(a),abs(b)))`.
Never pool raw errors from µmol, litres and concentrations. Report maximum,
99th percentile and RMS scaled errors, plus each failing identity/time. Maximum
error is the gate; averages cannot hide an individual state failure.

1. **Finite/domain:** every stored state and primary observer is finite at every
   native output time. For amount/volume variables, values below
   `-10*(1e-13 + 1e-8*max_time_abs_value)` fail the B2 numerical-domain gate.
   Values between that bound and zero are retained and reported, not clamped.
   Any source state requiring a signed domain needs an explicit independently
   reviewed classification before its solve, not an exception invented afterward.
2. **Full-state tolerance convergence:** compare I1/I2, T1/T2 and C1/C2 at all
   common native times/identities; require max E <= 1 with A=1e-9, R=1e-4.
   Compare B0 against B2 with the same scales; require max E <= 10. These use
   the source solver's numeric error scales as an engineering global-difference
   budget; they are not a theorem that local error control bounds global error.
3. **Primary observer convergence:** require max E <= 1 for B1/B2 and <=10 for
   B0/B2, with A=1e-9 µmol/L, R=1e-4, separately for each of the four observers.
4. **Repeatability:** T2 versus T2-repeat, exact native times, max E <=1 with
   A=1e-12 in each native unit and R=1e-10 for all retained states/observers.
   Matching rounded CSVs alone is insufficient; compare unrounded binary64
   values or round-trip-safe decimal exports and exact input identity.
5. **Output-grid check:** T2 versus T2-dense at shared integer times, max E <=1
   with A=1e-9 and R=1e-4 for all retained states/observers. This checks changing
   requested output times, not solver convergence by itself. Report dense versus
   coarse peak/nadir values and native sample times; do not claim exact continuous
   extrema. Inspect the 0 and 3 minute event boundaries without smoothing them.
6. **Disabled-event control:** compare D2/C2 for the four peripheral-venous
   observers using A=1e-9 µmol/L, R=1e-4 and max E <=1. Record full-state
   differences, including source-defined formulation reservoirs; do not require
   an unused dose depot to equal a zero-dose depot or assign it to human plasma.
7. **Initialization adequacy for the declared context:** compare T2/T2-long and
   C2/C2-long for all four primary observers, requiring max E <=10 using
   A=1e-9 µmol/L and R=1e-4. Report all 1073 initial-state differences and
   1100-state trajectories, but do not assume cumulative sink states are stationary.
   A failing observer makes the source 1000-minute initialization insufficient
   under this gate; it cannot be silently replaced by 2000 minutes.

For initialization, also report native finite-difference drift over 900–1000 and
1900–2000 minutes, including units and the complete state identity list. This is
a sampled drift diagnostic, **not** an exact RHS derivative or proof that every
compartment is at a mathematical steady state. Any state-level stationarity claim
requires a source-derived classification of physiological pools versus cumulative
sinks/application/auxiliary states and a reviewed criterion. No undifferentiated
sum of all model amounts is a valid whole-body mass-conservation test.

Threshold failure stops numerical-ready status, not scientific reporting. Retain
the original source response and discrepancy; investigate cause before proposing
a versioned change. Do not tune S_I, initial values, dose or tolerances to obtain
the reference curve or expected glucose direction.

## 7. Physical-reference comparison and replication limits

Reparse the pinned IVITT workbook as data only, with exact sheet/header checks:
11 glucose records in mmol/L and 12 insulin records in pmol/L. Reject nonfinite
values/times, duplicate times within an analyte, unordered time or points outside
the output interval. Preserve raw numeric values and source units; verify file
identity before reading. These are source-distributed digitized historical
references, not newly measured Cendos data or a holdout for this model.

Primary comparison reproduces Stage A's method: linear interpolation of the
source-grid modeled observer **only at reference times**, no extrapolation.
Retain each observed/predicted value and residual, then compute count, signed
bias, MAE and RMSE separately by analyte. Report the dense-grid comparison as
a separately labeled interpolation-sensitivity analysis; it must not replace
the original method simply because it gives a smaller discrepancy. Do not
invent error bars, participant-level variability or a clinical pass threshold.

Recalculated source-grid metrics must reproduce the retained Stage A report from
its own retained input CSVs within 1e-9 relative/absolute numerical tolerance;
this checks the analysis implementation, not the newer solver's agreement with
Stage A or with humans. T0-versus-retained-Stage-A trajectory differences are
reported separately and must satisfy the B0 numerical comparison rule above.

There is no admitted numeric author-prediction golden trace or old-runtime
reproduction. Therefore label the result `source_recipe_reproduction` with its
native runtime, not `author_runtime_equivalent`. If an independently obtained
author trace is later supplied, register its source, recipe, units and comparator
before examining a migration-equivalence result. The source physical points do
not answer that separate numerical question.

## 8. Red tests, records and independent approval

Before adding a harness, write failing tests for altered SHA256, changed solver
formula role, unit/path mismatch, 1073-state omission/duplicate/reordering,
27-dependency overwrite, nonfinite state, malformed constant output, missing grid,
unexpected tolerance reduction, warning/failure, timeout and missing comparator.
Test that a deliberately perturbed trajectory fails the exact maximum-error gate,
and that one bad state cannot disappear inside an aggregate metric. A test fixture
is never entered as a physical observation.

Output package: approved protocol hash/version; source/runtime manifests;
per-run transformed XML hash and permitted structural diff; initial state
identity/units; exact grids; raw full-state and observer values; solver statistics;
resource/failure logs without private credentials; numerical metric tables;
source-reference residuals; and an explicit outcome for every gate. Retain all
failed attempts and analysis versions. No network, patient data, device commands,
automatic live-twin calibration, or product readiness mutation occurs in Stage B.

Root and an independent numerical reviewer approve the proposed criteria before
execution and review results afterward. A successful benchmark may support a
later bounded product-worker plan, never automatic completion of insulin human
qualification or the five botanical programs.

## Independent preregistration review record

Root read the proposal, original author recipe and private Stage A prototypes;
release-redteam independently reviewed the numerical proposal. Both accepted
the 15-run matrix and per-unit comparison/physical-evidence boundaries, subject
to the added native post-import 1100-state comparison and explicit source
reinitialization accounting above. That amendment is now present. New solves
remain pending root approval of the amended document hash.
