# Preserve scientific JSON before admission

Date: 2026-09-05

## Failure and repair

The Research HTTP API rejected duplicate JSON keys, but browser JSON forms and
terminal file commands parsed them first using permissive defaults. A duplicate
specimen identifier silently retained its final member mapping before the API
could detect the ambiguity. Strict server validation alone did not protect the
scientific identity boundary.

`livemorebio/strict_json.py` now supplies one dependency-free parser to the API and
research shell commands. `console/lib/strict_json.js` applies the corresponding
contract to specimen mapping, resilience protocol, and licensed-release forms.

- Require one JSON object and valid syntax.
- Reject duplicate decoded keys at any depth, including Unicode-escaped aliases.
- Limit input to 2,000,000 UTF-8 bytes and 64 container levels.
- Reject nonfinite numbers and integer literals outside the exact browser-safe
  range ±9,007,199,254,740,991. Larger identifiers belong in strings.
- Preserve narratives and other strings; domain-specific validation follows.
- Build JavaScript objects with null prototypes so prototype-like keys remain
  ordinary data. Error messages never repeat submitted keys or values.
- Bound terminal reads independently of the preliminary file-size check.

## Verification

The first regression run failed on duplicate specimen mapping admission. Following
the repair, 169 tests passed across `test_research_json_parity.py`, the independently
written `test_research_api.py`, and `test_research_workflow.py`. Tests exercise all
five research file commands before SDK dispatch, valid actual SDK route forwarding,
HTTP body rejection, browser parser parity, Unicode byte limits, decoded duplicate
keys, oversized integers, prototype safety, and unchanged valid data. Both modified
JavaScript modules passed `node --check`.

This is software admission verification, not physical instrument or biological
validation. Browser module loading at the isolated review URL succeeded; final
independent browser form submission verification remains assigned to the main
review/recording lane. The author's local browser tool returned successful click
operations without dispatching the expected event, so that run is not counted as
a passed interaction test. No records were written during that check.

## Durable lesson

Validation must occur before every lossy transformation. A backend cannot reject
duplicate source identities after a client has overwritten them. Treat raw-input
parsing, transport, and scientific domain admission as distinct tested boundaries.
