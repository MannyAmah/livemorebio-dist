# Cendos authenticated source: frozen maker packet

2026-09-08. Independent review pending. This preserves the legacy current-source
assay and repairs its source authority; it does not implement or replace any of
the six requested programs. R01–R51, all-page acceptance and all recordings remain
open. Authority: `2026-09-08-cendos-current-source-correction.md` and its cleared
wrong-peer/exact-guard amendment.

## Implemented boundary

Aegle now exposes an authenticated bodyless/no-query current-source capture. It
checks confirmed selection, audited persisted identity, source-specific numerical
eligibility, complete parameters and the exact detached schema. It returns only
reconstructive model inputs, selected summary, availability and SHA-256—not notes,
observations, waveforms or a full person record. Private failures retain fixed
codes; no source/model/selection writes occur.

Cendos reads that source using the existing attached safe client, not the bus.
It validates the source before its unchanged legacy calculation and reads again
before publishing a result/event. Aegle's proxy supplies its own restrictive
generation/twin/version/hash guard and checks the full returned source as well as
pre-dispatch and post-result authority. Another stable Aegle peer is not accepted
just because its response has a valid shape.

The source client explicitly requires HTTP 200 through the independently cleared
optional shared `expected_status` contract. Default client status handling and
metadata shapes are preserved. Existing 8 MiB transport cap is unchanged; source
envelopes have an additional 2,000,000-byte canonical UTF-8 cap. Socket timeouts
are not claimed as hard total deadlines. No retry, proxy, redirect, cache or local
model fallback was added.

## Red/green and preservation evidence

- The earlier initial producer/cache/proxy red cases remain in the work history.
  Initial two proxy red tests attempted the configured review peer HTTP because
  they patched a not-yet-used helper. They are **not network-free evidence**.
  Their safe rerun added the inherited `urlopen` tripwire before implementation.
- New exact guard test: **1 failed / 32 passed, 1.49 s**. A direct guard accepted
  integer `2**53`; bounded safe-integer validation now rejects it. Its HTTP test
  correctly expects the pre-existing strict request parser's 400, not guard 422.
- New exact HTTP status test: **1 failed / 37 deselected, 0.64 s** before opting
  the source client into exact 200. A valid-looking 201 now fails with the current
  safe request UUID.
- Final dedicated producer/consumer/proxy/transport packet: **74 passed**, three
  existing deprecation warnings, **1.73 s**. Private root:
  `/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-9nmcn6_j`.
- Legacy Cendos integrity preservation subset: **7 passed / 25 deselected**,
  one existing deprecation warning, **1.13 s**. Private root:
  `/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-o3g5iuox`.
  Complete-profile/explicit PK/no-mutation assertions remain. Missing current
  source now asserts the authoritative MODEL_BINDING_REQUIRED. Malformed peer
  inputs assert unavailable CLIENT_RESPONSE (503), not a caller-validation error.
  No scientific assertion was changed into a success-shaped fallback.
- Broader integrity run retained **7 failed / 95 passed, 3.01 s**: one was the
  unsafe-integer HTTP expectation corrected above; six are pre-existing clinical
  observation-to-model assumptions that conflict with the approved binding
  boundary. Those six are not waived or counted as passing. A separate invariant
  mapping/review is required before migrating their assertions.

Tests use authored in-memory source records, ASGI request clients and intercepted
bytes. Both old `urlopen` and new `build_opener` are refused by default within
these Cendos fixtures. Transport tests replace that refusal with an inspected
in-memory opener. No external HTTP, operational store, participant, hardware or
native physiological worker was used by these final focused runs. The preserved
seven-test subset still runs the legacy local pharmacology math where it did
before; it is not an independent physical experiment or clinical validation.

Coverage includes four-field identity mismatch before state access, audit/storage
failure, invalid/oversized captured profiles, source-specific aggregate-reference
eligibility and descriptive-public/REAL rejection, auth-first reads, wrong peers,
pre-dispatch/in-flight/post-body races, unreadable post-checks, immutable inputs,
event source attribution, schema/hash/PK errors, duplicate/nonfinite/deep JSON,
current UUID, unsafe revisions, encoding/redirect/timeout/quota rejection and no
automatic retry. Full cross-service/browser and installed-wheel acceptance is
still required after the combined source freeze.

## Frozen files

| File | SHA-256 |
| --- | --- |
| `livemorebio/cendos/current_source.py` | `439d7acbda3b22a74d93a08ef144866f03a8622cf399ba791606c45fa64302c9` |
| `livemorebio/cendos/service.py` | `47e3ca6859e95d58f67442db1298261bdee2658873674e262d10d4712b3b9dc6` |
| `livemorebio/aegle/server.py` | `065c435e3148ac0ded4ac942db17bba6b0445532e0f2eef590b52d4a083939b5` |
| `livemorebio/aegle/runtime.py` | `630de029e9184bb33853ca2be7e72067bd1f954d386ee15b1ec53348f3e495a0` |
| `livemorebio/tests/test_cendos_current_source.py` | `6675c0eeb53044816e205d3fa0b8882c999d6eb2028cc13b39d61ab06f8c315f` |
| `livemorebio/tests/test_cendos_source_transport.py` | `319c9854ac67019a33086267e72e46dde73c3ebebf2dd444596f4071120f2ca4` |
| `livemorebio/tests/cendos_source_fixtures.py` | `feb23f938e8f31b60ce710dbf47a435c9986f7fa041b705005298f9c2be94d79` |
| `livemorebio/tests/test_scientific_integrity.py` | `5c497e243c2d2debe4ef4537c67f35591e66466efec89f8e77c1e3e63b8d8d6d` |
| Shared client dependency at execution | `88da31ed4d542281b04cb33a074379703d836ea0cb9d29fc1d362688c6d71b78` |

## Limits and retained lesson

This is a single-process source fence plus attributed frozen calculations, not a
distributed transaction or revocation of work already dispatched. It does not
qualify clinical model bindings or solve the separately identified legacy
activation/preview/binding commit-uncertainty defects. Source facts and numerical
outputs do not become observed human responses through a successful hash check.

Lesson: notification caches are not execution authority. Verify the exact source
before calculation and before presentation, while preserving its frozen identity
for later inspection. Isolated data directories do not isolate peer URLs; tests
must intercept both inherited and replacement transports. CE is unavailable, so
this solutions entry retains the lesson without claiming an unrun invocation.

## Independent source-fencing review

2026-09-08, source-research reviewer (not the maker of this correction). Read the
complete approved plan, source-envelope/client module, producer and proxy paths,
consumer changes, shared transport and the dedicated tests. All nine frozen
hashes above matched before testing or the separately approved clinical-test
migration. No actionable blocker remains in this bounded correction.

- Independently rerun dedicated packet: **74 passed, 3 existing warnings, 1.55 s**;
  private isolated root `livemore-research-review-hiw1evqy`.
- Independently rerun unchanged Cendos integrity subset: **7 passed, 25 deselected,
  1 existing warning, 0.67 s**; private root `livemore-research-review-oiocxmh4`.
- Both runs used `tools/run_review_tests.py` and the inherited `urlopen` plus
  `build_opener` tripwires; tests used authored source envelopes/intercepted
  transport, not external services, real records or native physiological workers.

The review checked detached minimal inputs, exact source hashes and four-field
registry identity, source-specific eligibility, current request IDs, safe parsed
errors, own-proxy restrictive guards, wrong-peer rejection, no network under
authority locks, and pre/post-calculation and presentation fences. The seven
preserved tests still exercise their original complete parameter/PK/no-mutation
and unsupported-compound invariants. The separately documented six clinical
test failures and seven masked validation cases are not included as passing
evidence here; their approved test-only migration follows this freeze.

This is source attribution and single-process authority fencing, not a
distributed transaction, revocation of already dispatched calculations, clinical
model qualification, physical evidence, or acceptance of the outstanding legacy
activation/binding/preview commit paths. No source or test implementation was
changed during this independent review.
