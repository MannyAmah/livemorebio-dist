# Governed twin onboarding and live multiscale workspace

**Date:** 2026-08-30  
**Status:** implemented and locally verified  
**Scope:** synthetic development workflows and guarded real-human/physical-device admission

## Problem

The redesigned console had improved scientific visibility but had displaced a foundational
product workflow: creating a digital twin or cohort, connecting a person to the authoritative
twin, and binding the matching physical or virtual LIFE Patch. The interface also needed to
merge the approved A+B design without reducing Livemore to a visual dashboard. Browser actions
had to execute the same backend functions as terminal/API operations, show their lifecycle,
and preserve the distinction between modeled, observed, and validated evidence.

## Decision

Make the governed subject identity the product's shared root. Atlas, LIFE Patch, Biology,
Cendos, terminal, and notebooks must resolve one authoritative active subject. Keep the
approved A workspace density and action/evidence model, add B's whole-body view, biological
time, top navigation, and multiscale rail, and preserve the inherited console under `/legacy`.

The visual body is a state projection, not the biological engine. Its motion, rates, values,
and focus derive from live workspace state and server events. The metabolic and cardiovascular
engines remain the current deep executable contexts; unimplemented systems return explicit
unavailability rather than fabricated reactions.

## Architecture implemented

### Encrypted subject registry

`livemorebio/aegle/subjects.py` stores encrypted subject/cohort payloads in
`~/.livemore/subjects.sqlite3`. AES-256-GCM protects payloads. Plaintext is limited to opaque
indexes required for uniqueness and lookup. A persisted registry pointer identifies the
authoritative active twin.

The registry enforces:

- one admitted subject fingerprint maps to one governed twin;
- version-checked activation and binding;
- idempotent concurrent admission;
- no activation of real-human records without consent, chain of custody, and observations;
- physical pairing only to an active real-human record with LIFE Patch consent;
- protocol 2.0, B0-EVT-target, firmware, current calibration, and attestation metadata;
- one physical device identifier cannot be paired to multiple subjects;
- physical pairing remains `PENDING_SIGNED_ENVELOPE`, never hardware validation.

Startup restores this identity and fails closed when restoration fails. This prevents the
browser, Patch, Cendos, and terminal from silently diverging onto different people.

### Browser authorization

Loopback Aegle now bootstraps a short-lived HttpOnly, SameSite=Strict operator cookie from the
same origin. The API token is not exposed to browser JavaScript or stored in `sessionStorage`.
Terminal and SDK clients still read the owner-only token file, and `livemore token` remains an
explicit diagnostic for tools such as `curl`.

### UI and operation semantics

- `/twins` admits, activates, versions, and binds Patch contracts.
- `/cohorts` creates frozen seeded synthetic cohorts or explicit real-human cohorts.
- `/` is the approved A+B Atlas with the whole-body view, biological time, multiscale path,
  visible operation lifecycle, state traces, mechanism path, and provenance.
- `/patch`, `/biology`, `/cendos`, and `/adapters` retain their specialized roles and share the
  current subject.
- `/legacy` preserves the inherited console.

Subject mutations and workspace actions are guarded by client-side operation locks. The UI
cannot dispatch a second conflicting mutation while the first is in flight. The body exposes
busy state, controls visibly lock, and lifecycle events progress through queued, running, and
completed states.

### Runtime reliability

The launcher waits for consecutive successful health checks before reporting a service ready,
and waits for ports to close before reporting it stopped. Adapter health probes run concurrently,
while licensing-blocked KEGG/GeneCards adapters are never probed. Responsive CSS prevents Cendos
from overflowing the mobile document while retaining an internal evidence-table scroller.

## Verification

- Full suite: 316 passed, 15 declared environment/network skips, 44 subtests passed.
- Compile check, JavaScript syntax checks, and diff whitespace check passed.
- Actual Aegle stop/start restored the selected authoritative subject.
- Real-browser QA covered all primary pages, desktop and mobile viewports, clean-session
  authorization, live action locking, SSE updates, virtual Patch sampling, Biology drilldown,
  Cendos metformin assay, and adapter probing.
- A real-interaction H.264 walkthrough was recorded at 1440 × 900, 25 fps, 46.72 seconds.

See `.gstack/qa-reports/qa-report-127-0-0-1-8850-2026-08-30-final.md` for the evidence ledger.

## Lessons to retain

1. Subject identity is a cross-product invariant, not a page-local selection.
2. A synthetic source class is not permission to call output measured or validated.
3. Device binding and device validation are separate lifecycle events.
4. A visually living anatomy must be driven by state and time, but animation never upgrades
   model maturity or evidence class.
5. Startup readiness must require stable health, not a single successful request.
6. Concurrent user actions need explicit operation locks even when backend version checks exist;
   otherwise correct rejection still appears as a broken interface.
7. Catalog breadth and adapter reachability do not establish scientific qualification.

## Remaining gates

- Persist and replay runtime perturbations through an append-only event history.
- Complete production tenant identity, external key management, RLS/authorization review,
  backup/restore, audit export, monitoring, and HIPAA deployment controls.
- Qualify physical LIFE Patch firmware/hardware, sensor calibration, analytical equivalence,
  wireless transport, and human-use safety.
- Admit governed wet-lab/clinical counterpart data before advancing any Cendos result beyond
  model-only hypothesis triage.
- Deepen renal, hepatic, endocrine, autonomic, immune, respiratory, gastrointestinal,
  neurological, musculoskeletal, reproductive, integumentary, and lymphatic execution and
  cross-system coupling under their formal contracts.
