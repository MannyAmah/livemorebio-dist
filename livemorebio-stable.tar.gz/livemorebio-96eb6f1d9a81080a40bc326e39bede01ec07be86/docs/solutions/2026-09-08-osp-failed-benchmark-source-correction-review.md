# OSP insulin: source diagnosis and prospective correction options

2026-09-08. Read-only investigation after the failed [Stage B benchmark](../OSP_INSULIN_STAGE_B_RESULTS.md).
**No additional solves, parameter fits, source edits, domain exemptions or product
activation were performed.** This document proposes the next decision; it does
not approve a corrected model. R11/R33 and all five botanical programs remain open.

## 1. Is a corrected author release available?

The official repository's current HEAD remains
`17a7f8eaac8d6c3e3f49d0a6e0fe6101e4bc3e18` (2019-03-23, README change).
The only published release is `v1.0` (2017-05-05). The XML's source revision is
the original upload `5c79524fde7ab3bae5621950319be82944c8d088`; the repository's
11-commit history contains no later XML correction. The public issue endpoint
returned zero open/closed entries on this review date. This is evidence about
the inspected public repository, not a claim that no private corrected model
exists. The README also warns that examples do not show the model's best
performance and identifies legacy physiology/runtime versions.
[Official repository](https://github.com/Open-Systems-Pharmacology/Glucose-Insulin-Model),
[release history](https://github.com/Open-Systems-Pharmacology/Glucose-Insulin-Model/releases),
[XML history](https://github.com/Open-Systems-Pharmacology/Glucose-Insulin-Model/commits/master/GIM_Healthy.xml).

The README links a later renal/SGLT2 extension. Its current HEAD is
`8f86253c06996781b59d7d6396e4ad1617f398a4`; it adds renal hyperfiltration and
dapagliflozin using MoBi 7.2 with inherited PK-Sim 5.6 physiology. Its README
does not identify it as a correction to the negative states or a new insulin
case2 benchmark. Its large models were not downloaded or run for this review.
[Official renal extension](https://github.com/Open-Systems-Pharmacology/SGLT2i-hyperfiltration-model).

The existing model's GPLv2 source terms remain distinct from individual paper,
supplement, clinical-data and native dependency rights. No new licensing
entitlement, restricted data access or redistribution permission is inferred.

## 2. Exact source audit: different failures need different explanations

All identities below refer to the original XML SHA256
`e78bb23d39ce7138f46bb876a54b43becb79bbf833e50c0cd7006f2a80eac3cb`.
These are observations from static source inspection, not guessed physiology.

| State / formula | What the source actually does | Consequence and unresolved question |
|---|---|---|
| Hepatic Glycogen, V11063 / `mdP0iJQBakus6Ccula0b9A` | Starts at -12,639,308.8716699 µmol. RHS11158/11160 integrate uptake minus hepatic production, without a glycogen-dependent availability factor in those terms. | The source cannot be treated as a finite nonnegative stored glycogen pool. A signed net-balance role is plausible; exact-ID author semantics and dependency closure are still needed. |
| Glycogen Phosphorylase b_N, V10939 / `TLdL2i5sDkGwDdIggEL5qw` | Starts at -0.131815269016201 µmol. RHS11164 follows `df_2`; formula10985 relaxes toward `(sigmoidal_response - 1)/2`. Formula10947 subtracts this state from a response multiplier. | This algebra supports a signed adaptation variable rather than an enzyme amount, despite the stored name/unit. A future semantic correction must label the transform and its domain, not invent measured enzyme concentration. |
| Liver End-IR-en, V11238 / `XfNRmePAdUqtWi-MaZANDw` | RHS11299 adds target receptor concentration minus a sum of receptor concentrations to the amount derivative. Every referenced receptor parameter is an amount/volume concentration; the target is µmol/L. This term contains no explicit volume or inverse-time factor. The other RHS terms include volume and kinetic factors. | There is a source dimensional-consistency concern and a restoring term that need not vanish at zero End-IR-en. This is not a license to multiply by an arbitrary volume/time constant or clamp negatives. Exact intended transcription/degradation law and units are missing. |
| SalivaGland insulin, V14202 / `U0dWUHJBAkKZQE3gOxua6A` | Its sole RHS20758 is the negative arterial-to-saliva exchange expression. RHS20759 adds the equal opposite into Saliva insulin V14170. The driving concentrations are arterial plasma and Saliva, not SalivaGland insulin itself. | A finite gland pool can be drained below zero by a flux not constrained by its amount. It could instead be a bookkeeping donor balance, but that requires explicit author/domain confirmation. A genuine gland compartment would require a complete replenishment/transport model. |
| Oral mass-absorbed counters | Integrate net para/transcellular transport; source names are cumulative counters, not tissue amounts. | Signed net transport can be meaningful, but the original benchmark was not preregistered with such exemptions. Preserve its failure; only a new independently reviewed domain manifest could distinguish counters from physical pools. |

Static indexing must distinguish defining XML nodes from ID references:
`RHSFormula id=...` is a reference and must not overwrite its `ExplicitFormula`
definition. The benchmark uses separate direct lists and is unaffected by this
diagnostic-parser pitfall.

## 3. What the primary publications establish—and do not

The 2013 paper describes sigmoidal pharmacodynamic transfers and an adapted
Quon receptor model; the more detailed Koschorreck model was evaluated but was
not the chosen receptor implementation. It also discusses unresolved meal,
subcutaneous absorption and glucagon-response limitations. Its reported
plasma-response evaluation does not supply an all-1100-state numerical golden
trace or certify every state as a nonnegative anatomical amount. The main text
does not explain the negative source initials. The linked 2013 supplementary ZIP
returned HTTP 403 on direct retrieval, so its missing definitions remain missing;
no access workaround was attempted.
[Schaller et al., 2013](https://ascpt.onlinelibrary.wiley.com/doi/full/10.1038/psp.2013.40).

A 2017 extension coauthored by Schaller explicitly states in Supplementary Text2
that the original hepatic production model did not quantify its precursor pool.
That supports the glycogen-bookkeeping hypothesis, but does not prove the exact
2017 XML identity's intended domain. The extension addresses labeled-glucose
recycling, not a repaired insulin receptor benchmark. Its fixed glycogen pool is
not a new dynamic depletion model. The article's displayed glycogen unit requires
checking against its cited measurement/source implementation before reuse; no
constant was imported from that text.
[Lahoz-Beneytez et al., 2017](https://www.frontiersin.org/journals/immunology/articles/10.3389/fimmu.2017.00474/full),
[Supplementary Text2, PDF page13](https://www.frontiersin.org/api/v4/articles/252675/file/Presentation_1.PDF/252675_supplementary-materials_presentations_1_pdf/1).

Koschorreck and Gilles provide explicit receptor balance equations and MATLAB
code with rat validation data, not a drop-in human replacement. Their mass-action
network is a useful independent structural reference for conservation and
positivity analysis. Its rat/in-vitro-derived constants must not be transferred
into personalized human physiology without justified human parameterization.
[Koschorreck and Gilles, 2008](https://link.springer.com/article/10.1186/1752-0509-2-43).

## 4. Recommended next packet: diagnosis first, new version only if justified

**Stage B1-source-diagnosis (proposed; no new solve authorized here):**

1. Freeze all old artifacts/hashes and the failed acceptance report unchanged.
   Build a new exact-ID domain/dimension manifest with explicit categories:
   physical amount, volume, concentration, signed cumulative flux, transformed
   regulatory state. Require equations, dependency paths and source rationale
   for every proposed nonphysical state. Do not classify by name alone.
2. Trace each failing state through the full reaction/dependency graph. Perform
   dimensional analysis, zero-boundary positivity tests and finite-pool balance
   checks without changing equations. Include all analogous organ receptor
   terms, not just liver. Distinguish intentionally open-system sources/sinks
   from supposed finite pools.
3. Request the author's exact domain definitions, units and positive-state
   initialization, plus a native author-runtime case2 export with all states,
   observers, dosing events, solver settings and reset semantics. Root must
   authorize any external contact; none was sent during this review.
4. Isolate each justified source correction in a new versioned patch with old/new
   equations, dimensional proof and source provenance. Reclassifying a signed
   counter is a semantic change, not repaired physiology. Replacing the glycogen
   balance with finite storage or receptor regulation is a new biological model
   requiring source-backed parameters and independent review.
5. Only after that review, preregister a new numerical comparison matrix. A
   tighter production solver candidate may be evaluated against still tighter
   reference runs with the same physical tolerances, but cannot erase old B0/B1
   failures. Tightening a solver will not repair negative source initials or an
   invalid zero-boundary law. No averaging, clipping or threshold loosening to
   obtain acceptance.

## 5. Exact input/evidence blockers to a credible biological correction

| Proposed correction | Required information, not presently supplied |
|---|---|
| Receptor restoration/turnover | Intended concentration-to-amount conversion, compartment volume convention, synthesis/degradation time constant or separate rate laws, source-domain proof and matched initialization. If replaced biologically: human tissue receptor abundance, internalization/recycling/degradation kinetics and exposure-response data, with uncertainty. |
| Finite hepatic glycogen and endogenous glucose supply | Measured initial glycogen amount/concentration with wet-tissue/volume units; synthesis, glycogenolysis and gluconeogenesis allocation/kinetics; precursor pools and availability feedback; matched fasting/feeding and tracer data. A fixed literature mean cannot describe each individual. |
| Gland versus saliva exchange | Whether V14202 is an anatomical pool or bookkeeping donor; if anatomical, its volume, arterial perfusion/replenishment, partition and secretion/elimination flux definitions, plus matched plasma/saliva time courses. |
| Reliable individualized insulin experiment | Exact insulin formulation, potency basis, route/rate/timing, anthropometry and physiological context; paired glucose, insulin and relevant secretion/clearance measurements with sampling/error metadata; calibration versus untouched validation records; declared population and intervention limits. Basal defaults and a historical cohort mean do not provide these. |
| Native portability and numerical benchmark | Source-author runtime/solver identity and full-state reference output, including all formula-reset states. Current R/.NET completion is already proven; absence of this golden trace is a scientific/portability evidence gap, not a missing-installation problem. |

Insulin remains an active whole-individual program. None of these steps replace
it with metformin, lobeline, a receptor-only assay, a glucose-only curve, or a
static capacity result. The five botanical programs retain their additional
systems, pharmacokinetic and experimental dependencies in the separate
[five-program packet](2026-09-08-five-program-mechanism-measurement-plan.md).

## Evidence and review scope

The 2017 supplementary PDF was retrieved from the publisher into private
evaluation storage, SHA256
`a91319d072bea516f80803f3768eb7678c1a9c410a19d037156569a2c9dd0183`;
its complete relevant Text2 and references were visually inspected. It is not
redistributed in this repository. Public source metadata was checked on the
date above; original XML/recipe and retained results were read only. This
proposal needs independent scientific review before implementation or new
native runs. Successful source diagnosis is not numerical acceptance or physical
qualification.

## Addendum: retained receptor/domain dependency audit

2026-09-08, local-only documentation checkpoint. This addendum advances the
**static** parts of proposed B1-source-diagnosis, not a new numerical branch.
The investigation skill was used to trace symptoms to exact definitions and
separate proven source properties from hypotheses. Its implementation and fresh
solve phases are intentionally not authorized here. No browser, HTTP request,
source acquisition, author contact, model evaluation, native solve, parameter
change or tolerance change occurred. The original failed Stage B report remains
unchanged. This addendum awaits independent scientific review.

### A. Exact source and retained evidence

The original local [GIM_Healthy.xml](/tmp/livemore-osp-source.fmi3LG/GIM_Healthy.xml)
was rehashed as
`e78bb23d39ce7138f46bb876a54b43becb79bbf833e50c0cd7006f2a80eac3cb`.
It is the previously acquired source at repository commit
`17a7f8eaac8d6c3e3f49d0a6e0fe6101e4bc3e18`, not a newly downloaded or repaired
variant. Source literals, declared units, aliases and graph edges were parsed
with the standard-library XML parser. The parser honored the original
`http://www.systems-biology.com` namespace and kept `FormulaList`, `VariableList`,
`ParameterList` and `ObserverList` definitions separate from ID references.
No expression was evaluated and no OSP, R, .NET or solver module was loaded.

The preserved domain ledgers below were read, grouped and hashed, not rerun:

| Retained artifact | SHA256 |
|---|---|
| [I2-domain.json](/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-osp-stage-b-81u4w4wd/analysis-v1/I2-domain.json) | `7302921e7cf899603678868800b182e1f2d36841f69f3952a309a55970d377ba` |
| [T2-domain.json](/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-osp-stage-b-81u4w4wd/analysis-v1/T2-domain.json) | `879da88776d8ad07751b9e82dc8d6cb3baac3b671c3c56d94fff81c1aed49797` |

These temporary paths are retained evaluation evidence, not an operational model
cache or an archival-retention guarantee. The existing collection manifest and
numerical report retain their original identities.

### B. All 15 tissue restoration terms share the same concern

Each formula below contains the same exact expression, wrapped here for readability:

```text
(End_IR_0*S_I-(End_IR+End_IR_en + End_IIR+End_IExIR
 + End_IIR_p+End_IExIR_p + End_IIR_p_en+End_IExIR_p_en))
```

Each is directly listed in its `End-IR-en` amount state's RHS with
`ScaleFactor=1`. All nine receptor/target references declare `µmol/l`; shared
`S_I` is parameter P786, literal 1, with no declared unit. Treating that factor
as dimensionless leaves a concentration term in an amount/time derivative.
The expression has no explicit compartment-volume or inverse-time factor.
This is an exact exported-source dimensional concern, not proof of which missing
coefficient or domain convention the author intended.

| Tissue | RHS formula | State | Exact state entity ID | Failed I2 sample times, min |
|---|---:|---:|---|---|
| Bone | 790 | V723 | `Cbtq5t2-aUSfa6WtD_9_uQ` | 1, 2 |
| Brain | 1278 | V1217 | `03kQmJZ0xESep6cIbAa-gQ` | 1, 2 |
| Fat | 1915 | V1854 | `XOliQ03Pk0WDdFfGe0W8VA` | 1 |
| Gonads | 2374 | V2313 | `cw1kpC2Al0SYI5XYg2ko4Q` | 1, 2 |
| Heart | 2825 | V2764 | `PL6XIhds3EaDooa4kyNmwA` | 1, 2 |
| Kidney | 3292 | V3231 | `Tsf__7M3D0WFb7H-7V-XIQ` | None in retained I2 ledger |
| Stomach | 6123 | V6062 | `dJrNAbjD302o4boSlIt0oQ` | 1, 2 |
| Small intestine | 6634 | V6573 | `KPDIIPpXKE-OdKiRXWZe9g` | 1, 2 |
| Large intestine | 8755 | V8694 | `cp1rdD2qRkuIrEZRnEvYZA` | 1, 2 |
| Liver | 11299 | V11238 | `XfNRmePAdUqtWi-MaZANDw` | 1, 2 |
| Lung | 11753 | V11692 | `4EVsWvoZmkWSSi06f5nxhA` | 1, 2 |
| Muscle | 12355 | V12294 | `NMxXgxQAvEC7ZHKUkpYVpw` | None in retained I2 ledger |
| Pancreas | 12907 | V12846 | `lHOddKRPUkW9NTByturNNg` | None in retained I2 ledger |
| Skin | 13465 | V13404 | `cQGZGzHFGUSdbPBMQxuQSg` | 1, 2 |
| Spleen | 13914 | V13853 | `PxlnVIG-YUGUyg7SPoaC7Q` | 1, 2 |

Thus 12 of 15 tissues contribute 23 receptor-domain failure records in I2.
The minimum is the liver value `-0.00013239595033584774 µmol` at minute 1.
Absence from this one sampled failure ledger is not a proof of continuous
positivity, valid units or safety in kidney, muscle or pancreas. The other
14,002 I2 negative records are not excused by isolating these 23: total I2 remains
14,025 records/26 identities and T2 remains 2,840 records/15 identities.

The complete liver amount derivative lists F11294, F11298, F11299 and F11307.
F11298 is

```text
(km5*IntF/9*End_IR
 - RRF*IntF*km5*End_IR_en
   *((End_IRp+End_IExIR_p+End_IRp_en+End_IExIR_p_en)/End_IRp_0)^SRI_TC)*V
```

Here P785 `km5` is exactly **0.003 1/min**, not 0.0031/min; P474 `IntF` is 3,
P475 `RRF` is 65 and P787 `SRI_TC` is 1. P10741 volume declares litres and uses
F11206 `f_endo*SA_pls_int*d_endo`. P11208 target concentration uses F11209
`End_IR_0_liv` through P10986. Listing these constants does not authorize fitting
or moving them between tissues.

The other two terms are `k9*PTP*IntF*RRF*IIR_p_en*V` (F11294) and
`k9*PTP*IntF*RRF*IExIR_p_en*V` (F11307). Their source `k9` parameters P473/P488
are 0.461 1/min, but P10743 `PTP` declares **µmol**, literal 1. Under those literal
units, these terms also contain an extra amount dimension. A normalized-activity
interpretation might explain the numeric factor but is not established by the
declared unit. Do not call these remaining terms dimensionally validated just
because they include volume and a rate constant. Adding a guessed factor to
F11299 alone cannot establish a consistent receptor-pool model.

**Static zero-boundary check:** in the bare formula, set `End_IR_en=0`, set
`End_IR` and phosphorylated receptor complexes to zero, and consider positive
nonphosphorylated `End_IIR` greater than `End_IR_0*S_I`. The other three listed
terms then vanish while the restoration expression is negative. This is an
algebraic domain counterexample, not a new evaluated source state or a claimed
reachable patient condition. A valid nonnegative-pool contract would need an
explicit admissible-state constraint excluding that case or an author-supported
balance law. The exported dimensional concern remains unresolved, so this
argument does not pretend the resulting derivative already has valid units.

### C. Negative names are not enough: exact downstream roles differ

Dependency tracing followed quantity references to formula definitions, then to
derived parameters/observers, and stopped at each reached differential-state RHS.
The paths below concern that exported equation graph. They do not claim that
every administration-event dependency or unexported author convention was audited.

| Source quantity | Confirmed graph role | What remains unproven |
|---|---|---|
| V11063 hepatic Glycogen | Its direct consumers F11065/F11067 are `M/V` readouts. No downstream differential-state RHS is reachable through the exported parameter/formula graph. Its own F11158/F11160 integrate uptake minus production. | This supports a terminal net-balance interpretation, but does not turn its negative initializer into a measured stored glycogen amount or establish author-approved domain semantics. |
| V10939 Glycogen Phosphorylase b_N | V10939 → F10947 → P10938 `M_NHGP` → F11160 reaches glycogen V11063; F11161 reaches hepatic glucose V11005. V10939 → F10985 → P10984 `df_2` → F11164 also feeds its own derivative. | It is active regulatory feedback, not merely a disposable chart counter. The signed-transform interpretation needs an exact unit/domain contract. |
| V14202 SalivaGland insulin | Its direct consumers F14204/F14206 are `M/V` readouts; no downstream differential-state RHS is reachable through the exported parameter/formula graph. F20758 removes exactly the exchange added to Saliva insulin V14170 by F20759. | Terminal donor bookkeeping is plausible. It is not proof of a finite anatomical gland insulin compartment or its replenishment. |
| V11238 liver End-IR-en | V11238 → F11240 → P11239 concentration → F11297 changes End-IR V11251; F11298/F11299 feed its own derivative. | This receptor quantity participates in reaction feedback. A blanket signed-counter exemption would not establish a physical receptor balance. |

Two further declared-unit issues prevent treating a reclassification as a repair:

- F11158 multiplies organ glucose metabolization P10933 (`µmol/min`) by
  `M_IHGU`, which references V10978 Glycogen Synthase a (`µmol`). F11160/F11161
  multiply P11159 (`µmol/min`) by `M_IHGP`, V10970 Glycogen Phosphorylase b_I
  (`µmol`). The other named response factors have no declared unit. Literal
  amount units on what appear to be response multipliers create an extra amount
  dimension. Their biological meaning cannot be established by renaming them.
- F10947 subtracts `f_2`, V10939 (declared `µmol`), from a sigmoid built from a
  ratio of glucagon concentrations and unitless source coefficients. F10985
  relaxes that state toward `(sigmoid-1)/2` with `tN=120 min`. This algebra is
  evidence for a transformed regulatory variable; it is not a measured enzyme
  amount and no new nonnegative or signed domain was admitted.

The salivary exchange has a different issue: F20758/F20759 use arterial insulin
P102 and saliva insulin P14171 (`µmol/l`), saliva flow P14160 (`l/min`), unbound
fraction P156 and partition P20754. Its amount/time units are consistent under
dimensionless fraction/partition conventions, but the flux does not depend on
the remaining V14202 gland amount. Dimensional consistency alone cannot supply
a finite-pool availability or replenishment law.

### D. Why neither a receptor correction nor case2 result is admitted

The source and retained array findings explain why a plausible glucose or plasma
insulin curve is insufficient. They do not establish a unique corrected source:

1. All 15 restoration laws need a declared target-pool and turnover convention,
   concentration-to-amount/time mapping, initialized admissible states and an
   explanation of normalized factors versus stored units. The PTP and hepatic
   multiplier annotations show why a one-factor dimensional patch is inadequate.
2. Domain identities for signed balance/readout states and transformed feedback
   must come from exact source semantics with a reviewed mapping. Any changed
   classification is a new manifest; the failed v1 ledger cannot be retrospectively
   passed. Finite glycogen or gland pools require additional measured inputs and
   equations, not only new labels.
3. Numerical failures remain: I0/I2, T0/T2, T1/T2 and C0/C2 fail their frozen
   gates. Each T/C branch starts from its own I-branch transfer, so those end-to-end
   comparisons do not isolate initialization error from treatment integration.
   A causal attribution to one solver setting or receptor term is not proven.
4. The author recipe transfers 1073 independent states and reevaluates 27 formula
   initializations. Its two retained changes are rectal luminal volume and the
   IVITT depot, not evidence of an importer silently corrupting all state.
   Case2 administers into shared **Insulin**, not a tracked administered fraction
   of **Insulin Ex**. No exogenous-specific exposure claim may be inferred from
   the separate pool's name.
5. A current-runtime solve is not an independent source-author all-state golden
   trace or person-specific qualification. The required exact formulation/potency,
   route/rate/timing, anthropometry, receptor/clearance context and paired untouched
   validation observations remain missing for a credible individualized experiment.

Next authorized work must be a reviewed source-domain/units decision and a new
versioned correction proposal, followed by a separately preregistered numerical
matrix if justified. No receptor correction, parameter exemption, compiler run,
new solve, clinical activation or external author request is authorized by this
documentation checkpoint. Exogenous insulin remains the required whole-individual
R33 program. Erinacine A, sterubin, carnosic acid, arctigenin and cyanidin
3-glucoside retain their separate whole-individual programs; none is replaced by
this source audit or by an isolated assay.

**Lesson retained:** inspect exact IDs, declared dimensions and downstream use
together. A signed terminal balance, a signed regulatory state and a failed
physical-pool boundary can share a negative-value symptom while requiring three
different source decisions. Do not use the most convenient interpretation to
erase a failed benchmark.
