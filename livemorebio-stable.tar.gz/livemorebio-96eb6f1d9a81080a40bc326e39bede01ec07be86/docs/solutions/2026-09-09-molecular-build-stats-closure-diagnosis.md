# Molecular build A: retained stats and closure diagnosis

2026-09-09. Read-only diagnosis, not a build retry or acceptance. The consumed
`/private/tmp/livemore-molecular-two-builds.QkgKLS` remains unchanged. Root
authorized inspection of its existing stats up to96MiB with a30s limit;
stdlib-only data checks used that alarm and refused network, subprocess,
fork/spawn/system and ctypes/native calls. No package JavaScript was executed.
Each data check finished below2s. No B build, vendor switch or browser occurred.

## Original failure remains final

Root's session89932 exited1. The complete retained result says `FILE_BOUND`,
phase A, one invocation, inputs_preserved=true. Its SHA256 independently
matches b5b5dc60d7bc19b0c69d84e270f8cee2c21a302b1402519e131bc1ab6f8a791b.
Webpack itself exited0 in15.335078417s including the owned invocation/cleanup;
cleanup SETTLED, empty_before_reap=true, no TERM/KILL. The recorded sampled
soft disk high-water is86,585,184B,142 samples, largest gap0.114736292s.
This is not a hard kernel disk bound or an acceptance of the oversized file.

The launcher reads the three permitted assets before `stats.json`; all three
are below their frozen limits. The latter is83,354,656B against the unchanged
33,554,432B stats gate, explaining the precise `FILE_BOUND` seam. Its original
bytes are retained; no truncation, compression, cap change or retroactive PASS.

| Retained A file | Bytes | SHA256 |
|---|---:|---|
| stats.json |83354656|e783538f445d407393632567c9dd5c58254c9bc64bb87c562f47123cc1db4df2|
| dist/structure.js |2939705|449518ae2da48efa1dad9232c258bc0871ec86fdaa4bc2e827db9aa131d8c1b2|
| dist/structure.css |69902|ec90bcaa8610dc104656bc57effede3d6e1b954c2386dcaee985a88b8799c089|
| dist/structure.js.LICENSE.txt |971|bc83aaff43d3ef9301331bbfeaacc4d2d8549dfc9029f786bd6abdd32363b020|

## Why the stats are large

Stock webpack5.92.1/CLI5.1.4 serialized the deliberately verbose approved
configuration, not module source. There are zero compile errors and three
ordinary webpack performance-size warnings. In compact JSON the main `modules`
field is55,304,676B and the single `chunks` field28,048,268B. Nested concatenated
modules also occur in top-level/orphan and chunk representations. Across the
whole object there are91,927 reason records occupying75,636,124B of reason
arrays, largely repeated identifiers/issuer strings. This is the dominant size
driver; do not add overlapping nested-subtree byte totals as independent data.

In-memory removal of only `reasons` fields from the retained JSON produces
7,678,239B; also removing duplicate chunk module arrays yields5,228,635B.
These are diagnostic transformations, not written artifacts or a guarantee of
what another stock build would produce. No original bytes were rewritten.

Smallest proposed successor: **only `stats.reasons:false`**, retaining the
existing nested/dependent/orphan/runtime modules, both main and chunk module
trees, IDs, chunk relations, assets/related assets, errors/warnings and
source:false. Keep32MiB, all time/resource limits, exactly two fresh A/B builds,
full input preservation and no B after A failure. There is no need to remove
chunkModules or enlarge a cap. Preserve this83MB original as historical reason
evidence. The new contract must explicitly call its evidence a complete module
membership/asset graph, not claim that it contains dependency-reason edges.
That is a reviewed evidence-format refinement, not a partial/filtered graph
silently called complete. A new root, exact config/input hashes and separate
authorization are required. This document does not authorize implementation.

Minimal REDs: config changes only this evidence flag; nested and chunk-only
membership still classified; nonzero filtered counts still fail; fixture with
intentionally absent reasons remains admitted as membership evidence without
inventing edges; original size/no-B/strict-JSON/output comparisons stay unchanged.

## What the retained emitted graph establishes

Iterative main-module traversal propagates the parent's chunk membership to
nested concatenated modules. It has2,501 occurrences,1,358 unique identifiers,
and1,162 emitted identifiers. The separate chunk tree has exactly those1,162
identifiers, zero extra entries and zero membership conflicts. There are no
nonzero filtered counts. This is source-membership evidence, not proof that
every statement within each module survives tree shaking or executes at runtime.

Mapping each emitted identifier's resource (after loader/type prefixes) to its
longest exact installed lock placement yields1,155 unique package source files
in59 package/version pairs, plus four generated webpack runtime identifiers and
three local records (entry, spec, concatenated entry aggregate). No identifier
is unmapped. An initial exploratory mapping split the `javascript/esm|` prefix
too early and visibly left typed records unmapped; the corrected resource-prefix
mapping above preserves those entries rather than omitting them.

There are no emitted `/extensions/` modules or the named full-viewer, MP4/h264,
MVS, backgrounds or Zenodo paths. tr46, undici-types, Acorn, Scarf and fsevents
are not members of this emitted graph. The actual files have no source map,
dynamic import, known embedded-WASM signatures or h264 marker. These finite
checks do not establish absence of every possible encoded payload or runtime
request; those remain separate gates. Generic Molstar parsers and shader code
are present even where their corresponding actions are not mounted.

CSS has no @import or @font-face and only two inline PNG URLs, not remote URLs:
the select arrow156B/16x20 SHA37f5ac769fd5a11c62b3640e2e6c89ebb0da8a39b79f2ec7c343f4e6601c9797,
and Molstar logo6133B/87x32 SHA195d332ce5ed283275b312f8cca8a45af3792a78cc42f9a71036705506d8d714.
They remain original embedded CSS data requiring attribution/source association;
the absence of separate image files must not hide them from output inventory.

## Rights mapping: package coverage is not embedded closure

All59 exact package pairs map to28 original notice blobs (39,545B), whose size
and SHA were rechecked against the frozen rights-index320d17cc… . Notice163 is
the old Molstar full-viewer comment-only file and is **not** required evidence
for this new bundle; use the full Molstar164 notice and actual emitted React
versions. The four generated webpack runtime fragments also map to webpack's
full MIT notice79 (1071B, SHA9068a8782d2fb4c6e432cfa25334efa56f722822180570802bf86e71b6003b1e).
These original bodies/attributions were read in the prior completed224-notice
review and independently checked for the assigned187 slice, not inferred from
SPDX labels. Keep RxJS Apache2.0 and tslib's license/notices distinct.

Exact package mapping below: `package@version: source-module count / original
notice indexes`. It describes this failed A only, not a future build.

```text
@ungap/structured-clone@1.4.0: 4 / 1
bail@2.0.2: 1 / 57
comma-separated-tokens@2.0.3: 1 / 71
decode-named-character-reference@1.3.0: 1 / 85
devlop@1.1.0: 1 / 90
estree-util-is-identifier-name@3.0.0: 1 / 102
extend@3.0.2: 1 / 106
hast-util-to-jsx-runtime@2.3.6: 1 / 85
hast-util-whitespace@3.0.0: 1 / 71
html-url-attributes@3.0.1: 1 / 127
immer@10.2.0: 1 / 130
immutable@4.3.9: 1 / 131
inline-style-parser@0.2.7: 1 / 133
is-plain-obj@4.1.0: 1 / 132
mdast-util-from-markdown@2.0.3: 1 / 85
mdast-util-to-hast@13.2.1: 28 / 71
mdast-util-to-string@4.0.0: 1 / 57
micromark@4.0.2: 9 / 85
micromark-core-commonmark@2.0.3: 22 / 85
micromark-factory-destination@2.0.1: 1 / 85
micromark-factory-label@2.0.1: 1 / 85
micromark-factory-space@2.0.1: 1 / 85
micromark-factory-title@2.0.1: 1 / 85
micromark-factory-whitespace@2.0.1: 1 / 85
micromark-util-character@2.1.1: 1 / 85
micromark-util-chunked@2.0.1: 1 / 85
micromark-util-classify-character@2.0.1: 1 / 85
micromark-util-combine-extensions@2.0.1: 1 / 85
micromark-util-decode-numeric-character-reference@2.0.2: 1 / 85
micromark-util-decode-string@2.0.1: 1 / 85
micromark-util-html-tag-name@2.0.1: 1 / 85
micromark-util-normalize-identifier@2.0.1: 1 / 85
micromark-util-resolve-all@2.0.1: 1 / 85
micromark-util-sanitize-uri@2.1.0: 1 / 85
micromark-util-subtokenize@2.1.0: 2 / 85
molstar@4.4.0: 943 / 164 (163 excluded as old-viewer evidence)
property-information@7.2.0: 18 / 177
react@18.3.1: 4 / 150
react-dom@18.3.1: 3 / 150
react-markdown@9.1.0: 1 / 187
remark-parse@11.0.0: 1 / 192
remark-rehype@11.1.2: 1 / 85
rxjs@7.8.2: 65 / 24
scheduler@0.23.2: 2 / 150
space-separated-tokens@2.0.2: 1 / 71
style-to-js@1.1.21: 2 / 206
style-to-object@1.0.14: 1 / 207
trim-lines@3.0.1: 1 / 154
trough@2.2.0: 1 / 210
tslib@2.8.1: 1 / 32,33
unified@11.0.5: 2 / 211
unist-util-is@6.0.1: 1 / 212
unist-util-position@5.0.0: 1 / 57
unist-util-stringify-position@4.0.0: 1 / 71
unist-util-visit@5.1.0: 1 / 57
unist-util-visit-parents@6.0.2: 2 / 71
vfile@6.0.3: 5 / 211
vfile-message@4.0.3: 1 / 85
xhr2@0.2.1: 1 / 223
```

The actual971B Terser LICENSE file contains only four React-family comments
referring to source LICENSE files. It is not the full permission/disclaimer
texts and does not carry the other package/embedded attributions.

A bounded comment scan of the943 emitted Molstar source files (6,100,389B)
identified63 explicit copyright/license adaptation blocks after excluding the
ordinary Molstar-only header. All63 selected blocks were read, including the
four identical gl-matrix fragments and six identical SMAA headers. This is a
targeted evidence scan, not an exhaustive legal/source-origin certification.
It establishes additional attribution obligations, not a Molstar-MIT-only
closure. In particular:

- `mol-math/linear-algebra/3d{,/common,/mat4,/vec3}.js` preserves Brandon Jones /
  Colin MacKenzie IV2015 plus a permission fragment ending at “conditions”,
  without the condition/disclaimer in that block. Do not invent the missing
  original full association from Molstar's different copyright.
- `mol-util/color/lists.js` explicitly attributes ColorBrewer to Cynthia Brewer,
  Mark Harrower and Penn State2002 under Apache2.0; `color/spaces/{hcl,lab}.js`
  attributes Gregor Aisch2011–2018/chroma.js but says only “BSD license”. Its
  exact BSD terms/version must be source-bound before redistribution.
- Other retained families include three.js/WestLangley, SMAA2.8, Tarek Sherif /
  Shuai Shao's WebGL examples, Arseny Kapoulkine's Niagara specialization,
  FidelityFX/shader adaptation, fastapprox/BSD, InternalFX/ISC, Parsimmon,
  image-js/iobuffer, netcdfjs, NGL, CIFTools/MMTF, DensityServer, LiteMol, MolQL
  and ts-fibonacci-heap. Keep their actual headers and establish corresponding
  full terms/source association; a label or algorithm citation alone is not
  evidence that every inherited notice is complete.
- `mol-plugin-ui/controls/slider.js` does contain the full Alipay2015-present
  MIT body. Preserve it; the generated971B file omitted it.

Thus package-level notice matching is complete for the observed membership,
but **redistributable embedded-source rights closure remains open**. This is
not a reason to redo acquisition/install or to distribute node_modules. The
next rights task should be confined to these actual embedded families, starting
with retained sources; any needed primary-source acquisition requires approval.

## Separate source-backed CSP compatibility finding

There are three `new Function` sites in the actual JS. Webpack's global-object
fallback is bypassed when globalThis exists; Molstar scheduler's string-callback
fallback is bypassed for function callbacks. Neither alone proves a failure.
The apparent `.eval(` hit is a method call, not global eval.

However, the selected UI has a real path: canonical spec.js24 mounts
SelectionViewportControls; `structure/selection.js98,197,203` exposes Help;
expanding Mouse & Key Controls renders `viewport/help.js19–30,54–76` bindings;
`mol-util/binding.js39–43` calls `string.js56–59`, which constructs a Function.
ShowSettings=false disables a different viewport button, not this selection
help. With the approved no-unsafe-eval CSP, this path is incompatible. This is
a source-backed inference, **not an observed browser failure** and not the
stats failure's cause. No CSP relaxation or silent control removal is approved.

Exact installed Molstar4.4.0 source hashes:

| Relative to node_modules/molstar/lib | SHA256 |
|---|---|
| mol-plugin-ui/structure/selection.js |bceb9cd7de41427a7bea5e3f7cf9434bd80b3c96eb652c6bd58810d56798c7a5|
| mol-plugin-ui/viewport/help.js |3aabecd02776e67191880cfb27c1dbfe49799c923b8d84401542a2c1cad42c4b|
| mol-util/binding.js |c5a23f42433bced402ba9d6665b713105c00f3206ba7a3bd9cadcacfe268158e|
| mol-util/string.js |bba2fbeefb0125a2c35f2f0e497dbac88f8a081f758d15bb84b76ba5da37fa66|
| mol-task/util/scheduler.js |3932a97d33790cf700bac4e7a63591a598c5e9af495c2183df5c2f3c77464d52|

### Exact compatibility options, source-only follow-up requested by root

The actual default bindings are defined in three files, read directly:
trackball21 descriptions, camera8 and representation9. Their38 occurrences
contain exactly nine distinct templates, each with one literal `${triggers}`
and no backtick, backslash escape or other interpolation expression:

```text
Click element using ${triggers}
Click on element using ${triggers}
Click on element using ${triggers} to extend selection along polymer
Click on nothing using ${triggers}
Drag using ${triggers}
From selected to hovered element along polymer using ${triggers}
Hover element using ${triggers}
Press ${triggers}
Scroll using ${triggers}
```

Source hashes: trackball.js18cedd5b85d46ae55c974051e775ec09c3989b8a96163cbabd2afa9c6af716b3;
camera.jsdb36c28f76b705fc7cda2be7f13aee6b5787a132de6c8e272fcbcfafc2c20155;
representation.jse3f6e8211c8a53e8d1202368e74d0821219e2970c8c0ac77699b845f5890a20e.
Empty bindings are skipped by BindingsHelp; the existing empty-description
fallback remains stringToWords(name). No consumer-supplied binding templates
are part of the reviewed adapter. Do not infer a general upstream templating API.

Preferred minimal proposal: a named build-entry compatibility adapter sets only
the shared public `Binding.format` before plugin construction. It retains
`binding.description || stringToWords(name)` and the existing
`'<i>' + Binding.formatTriggers(binding) + '</i>'` value, replacing the literal
token with `help.split('${triggers}').join(value)`. Split/join does not interpret
replacement-dollar syntax or evaluate replacement text. For the exact frozen
nine descriptions it is equivalent to the original template interpolation.
Plain fallback text remains literal; an unsupported `${...}` expression,
backtick or backslash in a non-default description must fail explicitly, never
fall back to Function or accept arbitrary template code. This does not sanitize
arbitrary HTML or broaden acceptance of custom bindings. Preserve all controls.

This option changes a shared export in this private composition only, so its
ordering and module identity are explicit test obligations: install once before
creating the plugin; all Help readers use that same imported Binding object;
all38 literal cases, fallback, repeated token and dollar/backtick-like trigger
output are checked without executing templates; unknown syntax fails; Function
trap stays active while mounting the actual Help path. It needs a separately
approved entry/adapter change and changed-source notice, not an installed-tree
patch. If assignment-based adaptation is rejected, an exact hash-pinned private
copy of the original binding module with only this formatter replaced and an
explicit exact-module build alias is an alternative; that has more source and
resolution surface. Neither option removes Help or relaxes CSP. No code for
either was written or run here.

The other two sites are not invoked by the inspected supported paths:

- `webpack/runtime/global` first returns globalThis when it is an object. The
  actual supported modern browser must satisfy that condition; its Function
  fallback is for a different environment, not executed by loading this ESM in
  that environment. This still needs the later CSP browser observation.
- Scheduler's string fallback occurs only when callback is not a function.
  All retained Molstar ESM call sites are `mol-plugin/context.js172,178` arrow
  functions; `mol-gl/webgl/context.js87–106` passes the named checkSync function;
  `mol-task/execution/observable.js161` calls immediatePromise, whose
  scheduler.js166–173 callback is a Promise resolver. No supported string
  callback was found. Private callers supplying arbitrary strings are outside
  this adapter. The module's legacy IE script-element scheduling path is also
  not the inspected modern-browser path; do not infer permission to run it.

The successor stats option remains one flag, reasons:false. Keeping both module
trees at the diagnostic7.68MB estimate retains a useful membership crosscheck;
removing chunkModules as well is unnecessary and would weaken that redundant
evidence. If root chooses the latter5.23MB option, it needs an explicit changed
membership-validation contract, not an unreviewed second optimization.

Disposition: original A FAILED, B NOT_RUN; source/asset diagnosis is useful but
does not count as two-build reproducibility, rights, wheel, real-browser or
scientific acceptance. All six requested experiment identities remain intact.
Lesson: package names and minifier LICENSE comments are insufficient for
embedded-source attribution, and a complete emitted module graph need not carry
megabytes of repeated human-readable dependency reasons.
