# LivemoreBio one-line installer plan

Date: 2026-08-30
Status: implemented and verified locally; pending review and merge
Branch: `codex/patch-closed-loop-adapters`

## Outcome

An authorized user installs or updates LivemoreBio with one command. The installer
fetches the managed source checkout, creates the Python environment, installs all
declared extras, runs the release verification, and exposes `livemore` from a normal
terminal. The existing manual instructions remain as an advanced fallback.

The repository is private. A plain unauthenticated `curl` to GitHub Raw would return
404 and create a misleading public-install promise. The immediate supported command
therefore checks the authenticated GitHub CLI, resolves one exact commit, downloads
the complete installer to a temporary file, and only then executes it:

```bash
bash -c 'set -euo pipefail; command -v gh >/dev/null || { echo "Install GitHub CLI first: https://cli.github.com" >&2; exit 1; }; gh auth status >/dev/null || { echo "Run: gh auth login" >&2; exit 1; }; c=$(gh api repos/MannyAmah/livemorebio/commits/main --jq .sha); f=$(mktemp); trap '\''rm -f "$f"'\'' EXIT; gh api "repos/MannyAmah/livemorebio/contents/install.sh?ref=$c" -H "Accept: application/vnd.github.raw+json" >"$f"; test -s "$f"; LIVEMORE_REF="$c" bash "$f"'
```

After this branch is merged, the command resolves `install.sh` from the default branch.
During PR verification, the same command supplies the branch ref explicitly.

## Premise challenge

The user problem is not Python packaging. It is installation ceremony. Publishing a
PyPI package would shorten one command but would not solve private distribution,
scientific-kernel compatibility, source checkout management, or end-to-end verification.
A repository-owned bootstrap script solves the actual problem with the smallest
reversible change.

## Approaches considered

### A. Documentation-only chained shell command

- Minimal diff, but still exposes implementation details and becomes hard to maintain.
- No idempotence, update handling, prerequisite diagnostics, or focused installer tests.

### B. Repository-owned installer fetched through authenticated GitHub CLI (selected)

- One user-facing command for the current private repository.
- Reuses GitHub authorization without printing or embedding tokens.
- Keeps install logic versioned, reviewable, testable, and compatible with a future
  public bootstrap URL.

### C. Publish to PyPI or a private package index

- Attractive long-term distribution channel, but needs release credentials, package
  ownership, artifact signing, and a decision about public versus private source.
- Does not by itself create the managed checkout and verification experience requested.

## What already exists

- `pyproject.toml` declares the `livemore` console entry point and the complete
  `dev,kernels,server,notebooks` dependency profile. Reuse it.
- `python -m pytest` and `python -m compileall` are already the release gates. Reuse them.
- `livemore start/status/token/open` already own runtime initialization. The installer
  must not duplicate service or secret-management logic.
- `docs/LAUNCH_GUIDE.md` contains the manual sequence and troubleshooting. Promote the
  one-line path to the top and retain the manual path below it.

## Architecture

```text
authorized terminal
      |
      | gh api (private source, no token printed)
      v
  pinned install.sh
      |
      +--> validate Bash 3.2+, gh auth, tar, and Python 3.11.x
      +--> resolve the exact commit and acquire an installer lock
      +--> fetch that commit's source archive through authenticated gh api
      +--> build an inactive, versioned release at its immutable final path
      +--> create that release's .venv without moving it afterward
      +--> install .[dev,kernels,server,notebooks]
      +--> pytest + compileall
      +--> atomically switch current -> verified release
      +--> install a stable managed launcher plus ~/.local/bin/livemore symlink
      +--> add one marked, idempotent PATH block to the interactive-shell profile
      +--> print exact start/token/open commands
```

The managed checkout defaults to `~/.local/share/livemorebio`. Runtime state remains
separate under `~/.livemore`; the installer must not read, delete, log, or migrate
PHI-like runtime files or secret material.

## Installer contract

- Bash 3.2-compatible implementation; macOS and Linux supported and linted with
  `shellcheck -s bash`.
- Default source is `MannyAmah/livemorebio`, default ref is `main`; every accepted
  ref is resolved to one 40-character commit SHA before source retrieval.
- Source archives are downloaded through `gh api`, so the same authenticated path
  covers the bootstrap and the private product source without printing a token.
- `LIVEMORE_INSTALL_DIR`, `LIVEMORE_BIN_DIR`, and `LIVEMORE_REF` support isolated
  CI and authorized advanced installs. They do not weaken installation or verification.
- A missing prerequisite fails before changing the managed checkout and prints one
  concrete correction.
- A `mkdir`-based installer lock rejects concurrent runs and reports the recorded PID.
- Each commit installs under `releases/<commit>/`; dependency installation and release
  verification never mutate the active release. The virtual environment is created at that
  immutable final path because Python console scripts embed absolute interpreter paths.
- Dependencies install from an exact-version, SHA-256 lock before the local project is
  installed with dependency resolution and build isolation disabled.
- A complete-release marker and external full-tree digest are written only after dependency, test, and compile gates
  pass. Then a temporary symlink is renamed over `current` atomically. A failure or
  interruption leaves the prior `current` target unchanged and usable.
- Re-running an already complete commit verifies every release file against the external
  digest, then repairs activation and the command launcher without rebuilding it.
  Installer-owned inactive incomplete commit paths are removed under the lock and retried;
  an incomplete or changed active release is never deleted in place. Symlinked or conflicting
  targets fail closed.
- A pre-existing unrelated `livemore` file or symlink in the chosen bin directory is
  never overwritten.
- If the bin directory is absent from `PATH`, the installer appends a bounded Livemore
  marker block to `.zshrc` for interactive zsh or `.bashrc` for interactive Bash.
  Unknown shells receive an exact manual export instead of an unsafe profile edit.
- The supported product installer runtime is Python 3.11.x, matching the existing
  release command and scientific-kernel verification environment. Interpreter selection
  is deterministic: `python3.11` only. Other versions fail before staging, even though
  library consumers may use the broader `pyproject.toml` compatibility declaration.
- Verification is mandatory. Installer tests use fake authenticated `gh`, Python, and
  tiny source archives to exercise production branches without a bypass variable.
- The installer never accepts or echoes `LIVEMORE_API_TOKEN`, GitHub tokens, PHI,
  biomarker data, or clinical inputs.

## Test coverage map

```text
installer entry
  +-- bootstrap missing/unauthorized gh ----------- subprocess
  +-- bootstrap empty/truncated response ---------- subprocess
  +-- installer lock/concurrent run --------------- integration
  +-- unsupported/missing Python ---------------- unit/subprocess
  +-- missing venv/ensurepip --------------------- integration
  +-- pinned authenticated source archive -------- integration with fake gh
  +-- new inactive release ----------------------- integration
  +-- same-commit repeat install ----------------- integration
  +-- interrupted/failed update preserves current  integration
  +-- failed update then same-commit retry succeeds integration
  +-- unexpected or symlinked target refusal ------ integration
  +-- dependency-install failure ---------------- integration with fake executable
  +-- verification failure ---------------------- integration with fake executable
  +-- stable launcher invokes active CLI -------- integration
  +-- existing unrelated shim refusal ------------ integration
  +-- clean macOS zsh PATH setup ----------------- integration
  +-- clean Ubuntu Bash PATH setup --------------- integration
  +-- clean Linux zsh PATH setup ----------------- integration
  +-- unknown shell PATH guidance ---------------- integration
  +-- running services retain prior process ------- documented integration behavior
  +-- unsafe/option-like ref rejection ------------ unit/subprocess
  +-- Python 3.11 selected among multiple versions  unit/subprocess
  +-- Python <3.11 or >3.11 rejected before staging unit/subprocess
  +-- spaces in install path -------------------- integration
  +-- shell syntax and ShellCheck ---------------- CI/local gate
```

## Failure modes

| Codepath | Failure | Handling | Test | User sees |
|---|---|---|---|---|
| bootstrap fetch | GitHub auth/repository access denied | `pipefail` preserves failure | command smoke | GitHub's actionable auth error |
| bootstrap fetch | empty or truncated installer | download to temp and require non-empty completed response before Bash | yes | install aborted before execution |
| prerequisite detection | Python absent or too old | stop before checkout mutation | yes | required version and candidate commands |
| installer lock | concurrent or stale installer | reject live PID; recover only a verified stale lock | yes | exact lock owner/recovery guidance |
| archive retrieval | private source request fails | same authenticated `gh api` path, inactive target removed | yes | GitHub error and failed phase |
| dependency install | missing native wheel/compiler | pip error preserved | yes | failed phase plus underlying pip output |
| test/compile gate | product regression | inactive release rejected; current unchanged | yes | exact failed verification phase |
| activation | interruption or rename failure | temporary link never replaces `current` | yes | nonzero exit; old command remains functional |
| inactive retry | interrupted build left an incomplete release | remove only the installer-owned commit path under lock, then rebuild | yes | retry succeeds without manual cleanup |
| shim creation | bin directory unwritable | fail without sudo | yes | path and permissions guidance |
| PATH setup | unknown login shell/profile conflict | no profile mutation | yes | exact export and full command path |

There are no accepted silent failures.

## Implementation sequence

1. Add failing bootstrap and installer contract tests using temporary homes, tiny source
   archives, and fake authenticated `gh`/Python executables; no network and no real
   home-directory writes.
2. Add `install.sh` with explicit phases, safe quoting, Bash 3.2 compatibility, exact
   Python 3.11 selection, source pinning, a concurrency lock, inactive immutable releases,
   handled-failure cleanup limited to the owned commit path, mandatory verification,
   atomic activation, rollback preservation, a non-conflicting shim, and bounded
   interactive-shell profile setup.
3. Add a GitHub Actions installer smoke job for Ubuntu and macOS.
4. Promote the one-line command in README and launch guide; retain manual and private-
   repository troubleshooting paths.
5. Run installer tests, ShellCheck, the complete Python suite, compileall, and a real
   isolated install against the local branch.
6. Run independent diff review, fix all critical findings, commit, and push to PR #3.

## NOT in scope

- Making the repository public: disclosure decision is separate and irreversible.
- Publishing to PyPI/Homebrew: requires registry ownership, signing, and release policy.
- Installing system-level GitHub CLI, compilers, or OS package managers: the bootstrap
  checks authenticated `gh`; the script diagnoses other missing prerequisites without
  invoking `sudo` or modifying the OS.
- Starting services automatically: installation must not unexpectedly occupy ports;
  the completion message gives one `livemore start all` command.
- Production PHI deployment: this remains a loopback research release.

## Worktree strategy

Sequential implementation, no parallelization opportunity. The installer, its tests,
CI invocation, and documentation are one distribution contract.

## Acceptance gates

- One documented command replaces the seven manual setup commands for authorized users.
- The command exits nonzero on bootstrap, install, test, or compile failure.
- The installer and source archive are pinned to the same exact commit.
- Fresh install and repeat install pass in isolated temporary homes.
- Failed and interrupted updates prove the old command remains functional.
- Missing/unauthorized `gh`, unsafe refs, lock contention, launcher conflicts, unknown shells,
  macOS/Linux zsh PATH setup, Ubuntu Bash PATH setup, failed-update retry, and deterministic
  Python 3.11 selection have regression tests.
- No test writes to `~/.livemore` or the real user shell profile.
- `bash -n install.sh` and `shellcheck -s bash install.sh` are clean on Bash 3.2+.
- Full project tests and compileall remain clean.
- The existing PR contains the installer commit; `main` is not pushed directly.

## GSTACK REVIEW REPORT

| Review | Trigger | Why | Runs | Status | Findings |
|---|---|---|---|---|---|
| CEO Review | `/office-hours` + `/plan-ceo-review` | Scope and distribution | 1 | CLEAR | Selected the private, authenticated one-line path; public publishing deferred |
| Eng Review | `/plan-eng-review` | Architecture, errors, tests, performance | 3 | CLEAR | Two review rounds resolved 12 findings: pinning, end-to-end auth, atomic releases, retry recovery, PATH, Python selection, locks, and tests |
| Design Review | not applicable | No browser UI changes | 0 | SKIPPED | Documentation and terminal UX only |

**UNRESOLVED:** 0. The user's direct request approves the one-line installer outcome; the
private repository determines authenticated delivery, and transactional activation is
the only design that honestly preserves a working installation on failure.

**VERDICT:** CEO + ENG CLEARED for implementation. Post-change diff review remains required.
