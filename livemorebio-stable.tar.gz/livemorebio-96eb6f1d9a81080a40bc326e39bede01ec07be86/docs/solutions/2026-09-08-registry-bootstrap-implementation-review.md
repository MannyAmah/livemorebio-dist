# Registry bootstrap implementation: independent review candidate

Date: 2026-09-08. **Maker packet frozen; independent acceptance pending.**
No operational database, participant, production key, service, browser or
physiological model was accessed by this implementation work. Tests use authored
encrypted software fixtures in private temporary directories.

Authority: [approved bootstrap proposal](2026-09-08-legacy-registry-audit-bootstrap-proposal.md),
including its exact schemas, provisional/marked distinction and root §12.
Approved proposal SHA-256:
`ceae6cca1fc75a78ae5b53201fcf3896813e8a176a6c682c384c35ed4e06f685`.

## What changed

The new `registry_bootstrap.py` distinguishes independent attempted access from
verified data-key authority. A wrong first key on an old zero-audit store records
an independently encrypted failed BEGIN/RESULT pair. A later correct key may
establish a proof without modifying historical clinical ciphertext or AAD.

- Exactly five additive tables implement the reviewed identity, events, persistent
  attempt links, data-key proof and independent proof-binding graph.
- The first lexicographic record is the historical key witness, including a
  cohort-only store. Empty establishment is explicitly different. Authentication
  does not certify that every historical record is sound.
- A committed independent BEGIN precedes witness decryption and subject-index
  migration. Successful migration, proof, binding and RESULT commit together.
- Pending attempts reserve terminal capacity. A subsequent process records
  `INTERRUPTED_OUTCOME_UNKNOWN`, not an invented successful or no-access outcome.
- Proof checks authenticate the complete linked graph and historical byte hashes.
  They do not require legitimately updated live records to equal old witness bytes.
- Normal existing-audit opens retain the old key verification. They do not create
  an independent secret or adopt a proof merely because ordinary startup occurs.
- Explicit local `SubjectRegistry.adopt_audit_authority()` authenticates the old
  normal audit before recording an `EXISTING_AUDIT` proof. It does not decrypt
  clinical records or rewrite the existing audit ledger.
- `recover_unverified_audit(...)` immediately rejects with
  `RECOVERY_REVIEW_REQUIRED`, without filesystem or database activity. No proven
  exclusion barrier exists for unsupported already-open old executables.

Normal clinical record AAD remains `livemore.aegle.subject-registry.v1` plus the
record ID. Normal access-audit payloads and `livemore.subject-registry.audit.v1`
AAD remain unchanged. Existing physiology, reference generation, clinical
normalization and numerical binding criteria were not changed by this packet.

## Transaction interfaces for other owners

`RegistryAudit.check_authority(connection, reservation=None)` obtains the writer
guard and invokes its optional **trusted internal** `authority_check` callback.
`SubjectRegistry` supplies that callback; standalone audit utilities do not gain
clinical access from an unbound helper.

`begin()` retains an in-memory authority token in `AuditReservation` without
adding it to the frozen audit payload. `SubjectRegistry._audited()` and its
specialized observation-selection path follow this order:

```text
writer guard + current authority -> normal BEGIN -> commit
BEGIN IMMEDIATE -> compare reservation authority -> clinical access/mutation
same-transaction authority check + RESULT -> commit
```

A marked token binds the immutable proof ID and proof-ciphertext digest. An
unmarked authenticated-audit token binds its historical first event envelope.
Adoption between the two transactions invalidates the old reservation's token;
the old access is denied and remains pending rather than receiving a false
completion. Wrong-key already-open helpers cannot append a new normal BEGIN.

These checks fence cooperating **reviewed-runtime** writers. They do not make an
old executable that lacks the check stop writing, confer a distributed lease,
or establish quiescence merely because a local lock was obtained.

## Local key and storage contract

The local independent secret is a random 32-byte fixed sibling
`<registry basename>.bootstrap-key`. It is not derived from the data key. An
exclusive atomic publication is fsynced, and a competing winner is reread.
A published orphan key before the first identity commit is reused. Once
bootstrap metadata exists, a missing or mismatching key is never regenerated.

The exact parent must be owner-only 0700; DB, key, WAL, SHM, rollback journal and
bootstrap-lock final components must be owner-only regular single-link 0600
files. Existing unsafe files are rejected, not chmod-repaired. Exact DB inode
identity is rechecked. The local POSIX bootstrap lock has a five-second acquisition
bound and closes its descriptor on failures.

Backups must preserve **both** the original registry data key and the independent
bootstrap key with a transactionally consistent database backup. Neither secret
belongs in a support log or exported clinical response. Copying a live SQLite DB
without its committed WAL is not a documented backup method. Key replacement,
rotation, loss recovery and production managed-secret provisioning require a
separately reviewed operational procedure; no such command/provider is added here.
The sidecar is a local-development implementation, not enterprise key management
or a claim of HIPAA certification.

Fixed bounds: 512 charged bootstrap slots including outstanding terminal
reservations; 10,000 normal audit slots remain unchanged; witness ciphertext at
most 16 MiB plus AEAD overhead; at most 10,000 migrated TWIN rows and 256 MiB total
migration ciphertext. These are finite local admission limits, not eviction or
unlimited good-key availability under repeated bad-key attempts.

## Red-first and retained execution evidence

Initial red packet: **17 failed, 4 missing-helper errors in 0.62 s**. The direct
old-schema wrong-first/correct-next regression reproduced the original poisoning
before implementation. It did not manufacture a legacy store through the new
constructor.

Subsequent red tests caught and corrected integer-ciphertext error leakage,
migration limits checked after witness access, incompatible action/proof-kind
claims, UTF-16 auto-detection despite an UTF-8 contract, error masking after
terminal rollback failure, closed-connection lost-commit ACK handling,
non-object authenticated witnesses, unsupported lock errors, and unsafe key-mode
checks occurring after a SQLite open.

Final focused execution: **355 passed, one existing Starlette deprecation warning,
19.46 s**. Includes **62** dedicated bootstrap cases, shared audit reservation
tests, descriptive clinical registry, frozen REAL cohorts, reconciliation,
public-reference lifecycle/API, population records and typed clinical contexts.
Private execution root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-vakdx3io`.

The dedicated tests cover correct/wrong keys, empty/cohort-only stores,
wrong-first retries, historical witness updates, full graph corruption,
provisional pending/failed identity, reserved quota contention, migration
rollback, exact durable BEGIN ordering on another connection, explicit adoption,
already-open writer fences, commit-ACK uncertainty, fixed error behavior,
private-path failures and bounded lock rejection.

Two actual spawned-process races exercise correct/correct and wrong/correct
candidates. Two additional harmless fixture processes deliberately exit after
key publication and after committed BEGIN. Parent test code joins or terminates
only those owned children; the next process verifies retained keys/attempts.
No native scientific execution or physiological output is involved.

Reproduce with the managed interpreter and `tools/run_review_tests.py` isolation,
`-q -p no:cacheprovider`, selecting these files in `livemorebio/tests/`:
`test_registry_bootstrap_contract.py`, `test_subject_registry_audit_contract.py`,
`test_clinical_descriptive_registry.py`, `test_real_cohort_contract.py`,
`test_selection_reconciliation_registry.py`, `test_reference_cohort_lifecycle.py`,
`test_reference_cohort_api.py`, `test_population_records.py`,
`test_clinical_context_contract.py`. Never point test stores at an operational DB.

## Explicit open dependencies and non-acceptance

1. **Independent review is pending.** Passing maker tests is not release acceptance.
2. **Another supported writer needs integration.** `ReferenceCohortService` uses
   `registry._connect/_open/_seal` and a separate public-reference journal, bypassing
   `_audited`. Its existing write transactions must call the current authority
   check after obtaining `BEGIN IMMEDIATE`, before member/cohort decrypt or writes;
   preview's audit write needs the same check. A check before the transaction is
   insufficient. Root and the independent reviewer were notified; this file was
   not modified by the bootstrap owner. Public-reference semantics remain unchanged.
3. A broader preservation run retained **302 passed / 3 failed** in 23.81 s before
   the final added bootstrap cases. `test_subject_lifecycle.py` still calls
   numerical activation for two unbound REAL pairing fixtures (correctly rejected
   with `MODEL_BINDING_REQUIRED`), and one shell fixture expects pseudonym output
   that the new compact client intentionally does not print. Their original
   assertions remain unchanged here and require the owning clinical review.
4. In-place poisoned-ledger recovery, unsupported-writer quiescence, production
   secret/backup procedures, legacy activation/binding commit semantics and the
   wider clinical/product acceptance remain open. Atlas remains FAILED. No full
   R01–R51 completion, real-human equivalence or biological qualification is claimed.

## Frozen candidate hashes

| File | SHA-256 |
| --- | --- |
| `livemorebio/aegle/registry_bootstrap.py` | `f2a3d93deaa8ce804d42a512f02c5f85df73674a4c7ffa7b1dc4edb8680882ab` |
| `livemorebio/aegle/registry_audit.py` | `f8d5f02fac150e9c89506b7108db8a823094ff4360279a1c8416f895fbb55f5b` |
| `livemorebio/aegle/subjects.py` | `af46597193a4453e86b2a6a115100c76ce6b6812b9d7a198fabed350a34ba0c4` |
| `livemorebio/tests/test_registry_bootstrap_contract.py` | `81c8c32dc840884847e3ed365872770befe617e63b894042676b2c4351276711` |
| `livemorebio/tests/test_clinical_descriptive_registry.py` | `bbdefecce257cd6bfbc29a8f0dd306190b4f5416aab69b0711bd91159fa5da6f` |

Lesson retained: a durable attempt is evidence of an attempt, not proof of its
credential. Establish authority only through an independently readable attempt
and an authenticated, atomic proof graph; recheck that authority where each writer
actually accesses protected state. No CE tool was available; this solutions entry
records the decision and regressions without claiming an unrun skill invocation.
