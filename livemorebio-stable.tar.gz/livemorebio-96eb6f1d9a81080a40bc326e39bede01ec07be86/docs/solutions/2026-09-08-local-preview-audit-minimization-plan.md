# Local preview audit minimization

2026-09-08. R45/R47/R50; a correction to inherited private-data logging, not a
change to biological behavior or a new preview mode. Status: proposal for
independent review before code. The attached-client gate remains preserved.

Root read the full current Platform.patient implementation while independently
reviewing the attached preview changes. The unchanged in-process tail still
passes demographic/genome inputs and the numerical summary to audit.record.
No real audit data was read. This creates an avoidable release-blocking privacy
risk even though the present test inputs are authored fixtures.

Implement the smallest correction: retain the existing patient.set event name
and its placement after successful in-process preview construction, but supply
only fixed family (note/base/life_system), mode=inprocess and outcome=CREATED
metadata. Do not include identifiers, clinical text, demographics, genes,
conditions, profile names, calculated summaries, timestamps supplied by the
caller, or a fabricated server acknowledgment/request UUID. Remove the now-unused
clinical inputs audit dictionary. The already reviewed attached event stays
unchanged. No constructor, extraction, model equation, method arguments, returned
summary, error propagation or terminal behavior changes in this increment.

Write three red-before-green cases (base, note, structured local preview) in a
new test module. Execute the actual patient method on an uninitialized Platform
instance set to inprocess, using inert AegleTwin/SyntheticHuman/extractor fixtures
and the real summary path where practical. Each retains its original return and
constructor arguments while a spy requires the exact metadata-only event and
absence of an authored private sentinel. No actual model constructor, extraction,
native solver, audit store, network or child process. No old fixture migration.

After external pre-code review: run the three new cases first under the existing
private no-model ASGI/unit guard; retain RED; implement only sdk.py; repeat the
three and the existing632 client packet. The new tests are separate and are not
smuggled into or substituted for the preserved632. External review must grade
root's source and independently repeat the three cases. Re-freeze the SDK hash
and package identity before any pending real-browser run. Notify the browser
owner before editing sdk.py; all frontend source remains frozen. Do not run the
three excluded actual-model clean-workflow tests or any operational service.

This removes the identified event payload, not all application-wide PHI logging.
The broader privacy audit, authentication and release requirements remain open.
No clinical source, model fidelity or human-equivalence claim follows.

Independent pre-code review: ui_audit read the complete plan, actual patient
branches and audit.record and cleared this bounded correction. Exact event
contract: patient.set inputs={family:<fixed branch>, mode:inprocess},
outputs={outcome:CREATED}, exactly once after summary construction. The three
branches also retain note-over-base precedence and original constructor/extractor
arguments. Root accepted that precision before test or runtime authoring.

## Root maker receipt — independent implementation review pending

At the preserved SDK hash2c8e7529e168e562d7957e28547dfe981d050f6f0d2fb0222e5b7a1efac29af3,
the exact three new cases failed their audit argument assertion: **3 failed in
0.97s**, private zlp8jfhs, zero I/O attempts and zero optional Git refusals.
The original method returned the expected summaries and preserved constructor
arguments before each assertion, so these REDs isolate the disclosed audit
payload rather than a numerical/fixture failure. Inputs were authored sentinels,
not real clinical records. No audit file was written or read.

Root then removed the obsolete clinical audit-input dictionary, recorded the
fixed branch name inside each unchanged in-process branch and replaced only the
patient.set event payload. The same three tests passed in1.14s, private zryu9w7b,
exit0, I/O0 and Git0. Both test processes completed. No fixture was changed after
RED. Scoped diff whitespace validation passed.

Frozen SDK SHA256:022e850ee3c85e35cd64be4bf27910d84a777e35a068c949511a20658feee0b8.
Frozen test SHA256:3e9a733a4fc2eab0555689297a8776bfe8408d353f1822294c96a30b67409fc8.
File:livemorebio/tests/test_local_preview_audit_minimization.py.
The original632 client-preservation repeat completed independently of the new
three-case selection: **632 passed in31.55s**, exit0, private i7dwss1t,
Node186, unexpected I/O0 and optional Git refused1. This used the exact command
from the client implementation receipt with root's already documented safe
inherited-environment reduction. It is root maker preservation evidence for this
new SDK increment, not external implementation grading. All frontend hashes,
routes and registry remain frozen. No model/service/browser/installation ran.

Exact three-case command (workdir is the recovery worktree):

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os, sys, signal, socket, subprocess, urllib.request, multiprocessing.process
from tools.run_review_stack import prepare_review_environment
root, env = prepare_review_environment(inherited={k: os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ})
os.environ.clear(); os.environ.update(env)
os.environ['PYTHONDONTWRITEBYTECODE']='1'; os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
blocked=[]; metadata=[]
def deny(*a, **k):
    blocked.append('unexpected'); raise AssertionError('Review forbids network and child/native work')
def process(command, *a, **k):
    if command == ['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
        metadata.append('refused'); raise OSError('Authored unavailable Git metadata')
    return deny()
def audit(event, args):
    if event in {'os.fork','os.forkpty','os.posix_spawn','os.exec','subprocess.Popen','socket.connect','socket.getaddrinfo'}: deny()
sys.addaudithook(audit); multiprocessing.process.BaseProcess.start=deny
socket.socket.bind=deny; socket.socket.listen=deny; socket.socket.connect=deny; socket.socket.connect_ex=deny; socket.getaddrinfo=deny; socket.create_connection=deny
urllib.request.urlopen=deny; urllib.request.OpenerDirector.open=deny; subprocess.Popen=process
import pytest
class InertReview:
    @pytest.fixture(autouse=True)
    def no_models(self, monkeypatch):
        from livemorebio.tests.clinical_registry_fixtures import forbid_compilation
        from livemorebio.aegle.runtime import AegleTwin
        from livemorebio.engines.metabolic.glucose_insulin import MetabolicProfile
        forbid_compilation(monkeypatch)
        monkeypatch.setattr(AegleTwin, '__init__', deny)
        monkeypatch.setattr(MetabolicProfile, '__init__', deny)
signal.alarm(45)
print('PRIVATE_REVIEW_ROOT', root, flush=True)
rc=pytest.main(['-q','-p','no:cacheprovider','livemorebio/tests/test_local_preview_audit_minimization.py','--tb=line'], plugins=[InertReview()])
print('REVIEW_IO_COUNTS',len(blocked),len(metadata))
signal.alarm(0)
raise SystemExit(rc)
PY
```

## Independent implementation review

ui_audit read the full amended plan, all73 test lines, the complete current
Platform.patient method and the audit.record contract. The frozen SDK
`022e850ee3c85e35cd64be4bf27910d84a777e35a068c949511a20658feee0b8`
and test
`3e9a733a4fc2eab0555689297a8776bfe8408d353f1822294c96a30b67409fc8`
hashes matched. No runtime or test was edited by the reviewer.

The exact three-case wrapper above independently passed **3 cases in0.62s**,
exit0, private root suffix `yv7exs_4`, with unexpected I/O0 and Git refusals0.
No test process remains. Actual model construction, extraction, audit storage,
native work, network, services and browsers were not used.

No actionable blocker remains in this bounded payload correction. The event
retains its name and post-summary position with exactly the fixed family/mode
inputs and CREATED outcome; it no longer receives clinical inputs or calculated
summary. The actual summary path, constructor/extractor arguments, note-over-base
precedence and returned value remain covered by the three inert branches.
Attached acknowledgment handling and local audit-error propagation are unchanged.
This is maker-external source/test clearance for the specific event payload,
not proof of audit durability or application-wide PHI logging compliance. Root's
separate632 preservation repeat and the larger release gates remain separately
attributed evidence.
