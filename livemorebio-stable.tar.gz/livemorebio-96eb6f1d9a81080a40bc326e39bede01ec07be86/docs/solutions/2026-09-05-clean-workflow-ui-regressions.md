# Clean research workflows and independently loading Biology

Date: 2026-09-05. Scope: approved genome-models-clean-workflows plan, UI lane.
Independent UI review completed; root integration/release gates still apply. This is software/UI evidence,
not human, clinical, assay or device qualification.

## Root cause and changes

The active Biology overview referenced an undeclared `PROTOCOL` variable. The API
and anatomy assets returned successfully, while every refresh threw before the
organ cards rendered. Separately, top-level awaited graphics imports could prevent
any data from appearing when WebGL or a CDN failed.

The data fetch now runs independently of optional graphics. It has an HTTP/schema
check, a bounded deadline, serial polling, a visible retry action, and last-good
data with an explicit stale state. Selected organ readouts refresh without replaying
camera movements. Organ cards are native keyboard-operable buttons. Structure-viewer
JavaScript loads only when the user requests a molecular structure.

A requested frozen protocol never loads active-twin anatomy as a fallback. Dispatch
is explicit for metformin trajectories, PXR concentration points, and Human-GEM
steady-state conditions. The latter has neither a person selector nor a time slider.
Its ATP-capacity flux, uptake fluxes, numerical controls and constraint/source records
come from the saved result. No interpolated or invented biological response is added.

Cendos starts in Preparation with no selected result. History is paginated and
searchable. Recall only reads a result. Prepare rerun restores the saved request and
parent identity without executing it. Run creates a new immutable ID. An explicit
new-configuration acknowledgment is available for changed/legacy input contexts;
the backend remains authoritative. Exact GEM reruns preserve condition IDs and
individual media, including inputs not representable by the simplified input pair.

Twins and cohorts use opaque cursor pages and local search. The active subject card
is independent of the page. Empty intermediate search pages expose Continue search
when the backend has more encrypted records to scan. New reference creation requires
an explicit stratum selection; it does not silently choose a disease profile. The
initial healthy reference preview is not an admitted participant or a validated
healthy population cohort.

## Red-green and browser evidence

Three regressions were written and observed failing before implementation: graphics
failure prevented Biology loading, Cendos auto-recalled the latest result, and subject
pages had no search/pagination controls. Targeted UI/projection tests now report
12 passed. `tools/test_clean_workflow_browser.cjs` executes a real Chromium browser
against an ephemeral HTTP fixture server, and passed all of the following:

- First Biology load and second poll; blocked graphics must not block organ data.
- HTTP failure keeps last-good readout, shows a stale message, and Retry recovers.
- Unknown run never requests unrelated `/api/biology` values.
- Static GEM condition selector projects exactly the selected saved condition.
- Cendos opening is blank; History Recall and Prepare rerun cause no POST.
- Twin/cohort Next, Previous, page-size, search and empty-page Continue search work.
- Rapid double-Next during a delayed response advances exactly one cursor page.
- Heterogeneous saved media are fully visible before rerun; shared-input edits
  update the same condition array that execution will submit.
- Active-subject visibility survives paging; Cendos fits a 390-pixel viewport.
- No uncaught JavaScript errors.

The fixture script uses explicitly technical response data, not observations and not
scientific validation. It does not create or contact real subjects. Run it with a
locally installed `playwright` Node package and Chromium; an existing Chrome binary
can be supplied through `PLAYWRIGHT_CHROMIUM_EXECUTABLE`. The bundled Node package
path can be supplied through `NODE_PATH`. The local bundle's default browser revision
was absent, so the installed Chrome executable was used successfully.

## Live service check (isolated 8870 candidate only)

The untouched initial candidate had zero twins, zero cohorts and zero saved protocols,
and a healthy-adult unregistered reference preview. Biology rendered its model cards
and anatomy; selecting Heart opened its organ/cell/target details. The new Cendos
workspace remained blank on opening, including after saved experiments existed.

An actual UI submission ran the pinned Human-GEM protocol with glucose uptake cap 1
and oxygen caps 0, 2 and 10 mmol/gDW/h. Saved run
`protocol-20b8a63bc75d43f3b09627640534028e` returned ATP-capacity flux approximately
2, 12 and 31.5 mmol/gDW/h, actual oxygen uptake 0, 2 and 6, optimal solver status,
and zero ATP for both negative controls. Biology displayed each selected condition
from that run. These are numerical model outputs, not physical reactions.

History Prepare rerun restored 0, 2, 10 and did not execute. Explicit Run created
`protocol-1e02c5d3d1da4765bc66ffde0cc42c86` with the original parent ID and matching
displayed numerical results. History then contained both runs; an exact-ID search
returned the original, and Recall still displayed its result. Unknown run selection
showed Experiment unavailable, not the active twin. No physical measurements were
admitted during this check. Existing deployments on 8850 and 8860 were not touched.

Screenshots: `docs/screenshots/genome-models-clean-workflows/` contains empty Cendos,
healthy Biology, actual GEM result, run-bound Biology, History and mobile History.
The gstack browser binary exited 137; the separate `clean-workflow-qa` agent-browser
session was used as the available fallback. Native off-screen controls must be
scrolled into view before clicking and then re-inspected; an immediate snapshot can
precede an asynchronous response. Do not interpret a tool's Click done message as
evidence that the resulting workflow completed.

## Remaining gates and lessons

Root's full integration/release validation still applies. Populated subject paging was exercised with technical browser fixtures;
the live initial store was intentionally empty. Source/solver/control checks are
not wet-lab or human qualification, and the new GEM protocol is not admitted to
the existing person-based physical measurement comparison workflow.

Keep state/data initialization out of optional graphics imports. Test the first
successful render, a subsequent poll, and a failure/retry in a real browser. Freeze
record identity at every visualization boundary; never substitute a different twin
because a run, scientific layer or graphics dependency is unavailable.

## Independent review refinements

The independent source reviewer found that the metabolic provenance drawer used
`run.software`, while the actual protocol records `run.solver`. A real-shape render
test failed before the fix. The drawer now preserves the recorded solver metadata,
model and input digests, and bounded reference annotations/stoichiometric graph.
Older frozen runs display only the versions they actually recorded; the UI does not
backfill new software provenance into old results. A live read-only check confirmed
the saved GLPK/COBRA metadata, tolerances and reference links in the drawer, with no
JavaScript errors (`biology-provenance.png`). These source links are not assertions
that external database services are operational or physiological effects validated.

The reviewer also identified a navigation race: two rapid Next clicks could push
the same cursor twice, showing Page 3 with Page 2 records. A delayed HTTP browser
regression reproduced that mismatch. Subject and History pagers now disable and
guard navigation while the current request is pending and discard stale Next
cursors on error. Sequence checks still allow a new search to replace an older
pending search without accepting its stale response. The full browser regression
passed after the fix. Request sequencing alone does not protect cursor-stack
mutations; navigation state must be locked before awaiting network work.

Further review removed invalid organ/cell proxies at the backend boundary. The
UI now shows unknown kidney, brain and adipose function as unavailable, without a
null reference ratio. Parameter-only readouts retain explicit units and evidence
classes. Organ geometry and its hotspot label share the same status color, including
gray for unknown/reference coverage (red-green hotspot test). Pathway annotations
and anatomical identity remain available without implying executable kinetics.

Noncardiac cells are static reference schematics. Empty quantities do not imply a
membrane trace, zero activity, a lipid-load percentage, or measured transport.
Cardiac replay validates finite, aligned voltage/calcium/time arrays, selects recorded
samples by recorded time, and labels replay explicitly. The former arbitrary
calcium-to-contraction shape scaling was removed because no mechanics output supports
it. A live Chromium check opened both the reference-only renal cell and the cardiac
model replay with no JavaScript errors; screenshots are `biology-reference-cell.png`
and `biology-cardiac-replay.png`. This check was read-only and admitted no measurements.

An exact GEM rerun can have unequal glucose caps that the simple shared-cap input
cannot express. The complete pending-media table now displays every condition ID,
glucose cap and oxygen cap. It shares `pendingGemConditions()` with execution. When
shared media controls change, the table shows the replacement shared-cap conditions
and requires a new-configuration acknowledgment. Browser red-green evidence used
explicitly technical glucose caps [1,10], changed them to [3,3], then restored the
unchanged saved controls and verified [1,10]. A single form field must never conceal
scientifically material parameters preserved behind it.

The final independent review exposed a cross-tab active-subject race in the inherited
cell fetch. The authenticated Biology and state APIs now provide an opaque server
context token. The UI requires equality between displayed context, captured modal
context and returned cardiac trace context before painting any sample. A changed
poll closes the old modal and invalidates its pending fetch; a missing token prevents
opening. These are coherence checks, not scientific validation credentials. Controller
regressions cover mismatched identity, a late old response, missing context and
context change while a cell is open.

Hidden tabs cancel replay work. A visible tab resumes only after successfully
refreshing the same context, preserving replay position. An unavailable refresh
visibly pauses the modal rather than silently advancing a possibly stale context.
An actual Chromium check against the restarted authenticated 8870 server opened the
bound cardiac trace and reported no JavaScript errors. The complete fixture browser
regression also passed after these refinements. The independent source reviewer
then reran all seven UI/controller tests and checked the live browser: the renal
reference canvas was unchanged over 550 ms, the recorded cardiac trace changed over
340 ms and continued after tab return, and no JavaScript errors occurred. The
reviewer found no remaining critical issue in this bounded cell path. This does
not qualify the underlying models or complete root's broader release gates.
