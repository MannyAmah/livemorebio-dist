# Approved correction-first build: measurement integrity and multiscale inspection

Status: user approved 2026-09-08; implementation begins from preserved commit
`5c71ee8e0a643b4be11bac0fe65712494449be56` on a separate worktree/feature branch.

## Acceptance and scope

The objective is progressively measured, individualized functional equivalence, not
scripted outcomes. Numerical mechanism execution and independent physical observations
remain different evidence classes. Neither visualization nor passing software tests
establishes human equivalence. Physical observations may inform controlled estimation;
predictions never qualify themselves or silently recalibrate live twins.

The founder approved the correction-first approach. Preserve Aegle, Cendos, LIFE,
clean installation, immutable experiment history and the current release. Ignore the
Derya reference. Product copy uses visualization and recorded playback. Unsupported
processes remain visibly unavailable rather than acquiring decorative behavior.

## What already exists; decisions and alternatives

Reuse the existing gateway, encrypted journal, authenticated admission, evidence ledger,
protocol history, console, numerical runtime and review-stack isolation. No new service
or database is needed. The following choices were independently reviewed before code:

- **Add v3 beside v2**, rather than extending v2 serialized objects. Freeze v2 bytes,
  hashes and journal encryption context. Normalize only after integrity verification.
- **Explicit clock/endpoint mapping**, rather than mean-curve residuals or guessed
  acquisition-to-model alignment. Missing mappings produce named unavailable results.
- **Registered assembly assets**, rather than independently resized organ meshes
  represented as a whole person. Preserve the existing whole-person overview; keep
  unregistered organ inspection separate until registered assets are verified.
- **Bounded source-backed assay**, rather than invented human compound kinetics.
  Lobeline–VMAT2 initial-rate sensitivity has published inputs and contradictory
  kinetic evidence. Its rat-vesicle context is mandatory, never a human cohort claim.
- **Hold scope**, not architectural expansion. Insulin delay-model reproduction and
  additional botanical protocols require their own complete source/benchmark gates.

## Architecture and data boundaries

```text
v2 unchanged decoder/hash ─┐
v3 strict decoder/hash ────┴→ trusted admission → immutable journal
                                                  ↓
                                   normalized lineage-preserving projection
                                                  ↓
frozen prediction + admitted time/endpoint mapping → residual OR unavailable reason
                                                  ↓
                            Aegle / LIFE / Cendos inspection and exports

Recorded run → protocol + member + condition + native axis + quantity/unit
           → readouts, plots, geometry context and provenance (same identity)
```

Transport receipt, sensor acquisition, relative model time and recorded playback are
separate clocks. V3 carries acquisition windows, monotonic session/timing uncertainty,
raw/calibrated/derived lineage, assay/cartridge/biofluid/site, firmware and calibration
identities. A trusted registered manifest is bound to signed LIFE admission. Changed
cartridges require explicit configuration registration; replay watermarks never reset
implicitly. Waveforms are bounded linked source blocks, not fabricated scalar values.

Physical comparison requires a frozen prediction, subject/condition/endpoint/unit and
site/compartment match, permitted transfer mapping and an in-domain time coordinate.
Legacy packets lacking this context have unavailable residuals. A technical identity
mapping may exercise interpolation but is not a validated sensor transfer function.

## Implementation order and ownership

1. Wire/admission owner: additive v3 contract, trusted manifest, normalized observations,
   bounded input, compatibility tests. No existing packet/journal rewrite.
2. Integration owner (root): actual receipt time, source/freshness projections, frozen
   alignment, API/UI correctness and integration tests. Own `aegle/server.py`.
3. UI owner: typed run-bound inspection and reference controls; preserve A+B, separate
   whole-person overview from organ inspection; no biological motion without data.
4. Assay owner: original equation implementation, cited parameter/contradiction record,
   strict applicability, immutable result/export tests. No live-twin mutation.
5. Independent cross-review, complete regression run, isolated real-browser QA, detailed
   interaction recording, guides/release notes and durable lessons. Feature PR only.

## Quality, error and test review

- Golden v2 hashes; mixed-version reload; tampered/mixed/unknown versions rejected.
- Strict numbers (not booleans), finite values, bounded counts/bytes, duplicate IDs,
  units, acquisition order, clock resets, future/stale data and replay controls.
- Subject/device/mode/manifest substitution rejection; preserve consent, encryption,
  physical admission, auth, audit and no-automatic-calibration gates.
- Alignment: `[0,10] → [100,200]` at time 2 predicts 120, not mean 150. Exact endpoints,
  negative/zero residuals, missing identity/mapping, mismatched units/site/condition,
  out-of-domain/uncertain clocks all have explicit tests.
- Virtual/fixture streams never displayed as observed physical measurements. Freshness
  is based on acquisition and receipt separately; replay never appears live.
- UI views share one run/member/condition/time context. Unknown runs do not fall back to
  a different twin. Missing, flat and adverse outputs remain unchanged and visible.
- Graphics/asset failure leaves numerical inspection usable; keyboard/mobile/reduced
  motion support; playback and stage selection issue no mutation requests.
- Lobeline: zero/control limits, dimensional conversion, positivity, monotonicity,
  unchanged high-substrate limit, invalid material/context rejection and independently
  calculated holdout discrepancy. No post-hoc fitting or statistical qualification.
- Existing onboarding, cohort variation/pagination, blank Preparation, History, rerun
  lineage, notebooks/CSV and installed-wheel reference data remain regression gates.

## Security, performance and operations review

Use only isolated technical fixtures in QA/recordings. No operational patient store,
credentials or PHI enters test output or third-party services. Bound validation before
hashing/journaling and avoid waveform rescans on each view refresh. Preserve existing
auth requirements and owner-only storage. Errors expose safe categories, not payloads.
Structured evidence/source/time statuses are the observable contract; no false live
connection inferred merely from a previous packet. Original ports 8850–8852 untouched.

Deploy as a separate feature branch/PR, never directly to main. Preserve the old release
and data. Rollback is selection of the unchanged prior release, not journal conversion.
No production or Hermes monitor is claimed without an actual configured environment.

## Hardware and scientific release limits

Rev B0 remains an EVT research artifact. Document MAX30003 core-supply/FCLK errors,
TPS61291 voltage/bypass mismatch, pod current-limit assumptions and incomplete control
nets as fabrication blockers. An engineering correction draft is not released hardware,
firmware, a verified cartridge, a real-person sensor stream or clinical validation.

Not in this increment: fabrication/GATT firmware, human actuation, hot-swapping, inferred
genetics from LIFE Patch, universal clinical equivalence, fabricated tissue kinetics,
unlicensed bulk database import, whole-body asset registration guessed from screenshots.

## Remaining development gates

After this correction layer: reproduce the licensed insulin delayed model against its
native reference solver; complete conserved-pool audit; admit registered anatomy and
coordinate trajectories with provenance; build additional source-complete plant assays;
establish paired device/wet-lab datasets and prespecified tolerances before physiological
qualification. Keep each system's unsupported coverage visible throughout.

## Review provenance

Office-hours acceptance was resolved by explicit user approval. Engineering/CEO
scope-hold review and independent wire, UI and source reviews informed this plan.
Context7, gbrain and Compound Engineering tools are unavailable in this session; local
`docs/solutions/`, official documentation and independent reviewers are the fallback.
No implementation tests or completion claims are implied by approval of this plan.
