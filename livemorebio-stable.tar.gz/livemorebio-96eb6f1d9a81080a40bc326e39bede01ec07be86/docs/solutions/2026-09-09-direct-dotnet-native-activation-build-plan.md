# Direct .NET native activation and isolated build

2026-09-09. **PLAN READY FOR ROOT APPROVAL. No activation or build executed.**
Continues the independently cleared parent checkpoint, 73 PASS / zero refused
I/O calls (`1ce677`), and the root-approved direction. This step produces a
native-capable artifact, not a native qualification result.

## Scope and existing implementation

Reuse the exact current parent, C# worker, package-free project and
`tools/osp_dotnet_worker/build_fake.py`; no new runner, dependency, command API
or experiment. Engineering-plan review was applied in spawned mode to scope,
architecture, error paths, tests and performance. Prior art is the direct worker
plan, connection plan and independent parent report in this directory. The
gbrain, CE, Context7 and sequential-thinking connectors are unavailable here;
none is claimed as executed. Existing SDK/project source is the API reference;
no new framework/library API is introduced.

Exact source edits proposed after approval:

1. `tools/osp_dotnet_worker.py`: only `EXECUTION_APPROVED = False` to `True`.
2. `tools/osp_dotnet_worker/Worker.cs`: only
   `Program.NativeExecutionApproved => false` to `true`.
3. `tools/osp_dotnet_worker/build_fake.py`: one fixed `native-build` stage using
   a separate immutable stamp, output/home/tmp/packages directories and receipt
   labels. Same restore/build/fake-host commands, same selected SDK/runtime.
4. `tools/osp_dotnet_worker/tests/FakeTests.cs`: migrate precisely one obsolete
   gate test, as explained below. All other fake groups remain byte-identical.
5. One new offline Python test file,
   `livemorebio/tests/test_osp_dotnet_native_build_stage.py`, plus this receipt.

No changes to NativeSimulation.cs, Fixtures.json, pure protocol, supervisor,
project/config files, native libraries, solver settings, source equations,
model-admission flags or clinical/product routes. Initial parent/worker/build
hashes are respectively `42b7982e0d2fcd154f4e6c8218862a2d7a2abe5a0574b2c8c26346e6aaeee3db`,
`70011d37d2c459e264d9e7e250148ab082e1912cf492a6ca32e8957a514302db`,
`cf01c6ba9b0be2589018d3aaecb19a7edc870faaae77ab6667ea8650bec66b75`.

## Fixed flow and filesystem boundary

```text
root approves plan -> new authored REDs, no SDK/native
  -> two activation literals + finite build stage/test migration
  -> offline stage GREEN -> read-only input/hash preservation check
  -> one isolated offline restore -> build -> FakeTests.dll (32 groups)
  -> guarded Python73 on fresh emitted bytes + new stage tests
  -> exact three artifact/source pins -> independent review
  -> STOP (no package, authorization file, native worker or S01-S17 launch)
```

Retained root remains
`/private/tmp/livemore-dotnet-worker-toolchain.E09gsz`. New names are exactly:

- `offline-native-build-start.json`, created exclusively once; an existing
  native-stage stamp refuses a second invocation without modifying it.
- `native-build`, `native-build-home`, `native-build-tmp`,
  `native-build-packages`, all fresh and private before use.
- `native-build.inputs.json`, `native-build-restore.*`,
  `native-build-build.*`, `native-build-tests.*` for the original JSON and
  stdout/stderr receipts. Exclusive writes preserve first failures.

Original `build*`, `review-build*`, `pipe-build*`, `red*`, `green*`, `review-*`,
`pipe-green*`, original stamps, acquisition, archives and manifests are never
reset, rewritten or used as output. Failure consumes the new stage; no automatic
second stamp, output root, rebuild or retry.

The exact prospective build invocation, only after source approval, is:

```sh
/usr/bin/python3 -B tools/osp_dotnet_worker/build_fake.py /private/tmp/livemore-dotnet-worker-toolchain.E09gsz native-build
```

It restores/builds only `tests/FakeTests.csproj`, whose project reference emits
Worker as well, then directly runs only
`native-build/bin/FakeTests/Release/net8.0/Livemore.OspWorker.FakeTests.dll`
with standard input DEVNULL. It never starts the Worker executable. No native
library search path is added to the build environment. The existing empty
NuGet source list, disabled audit/telemetry/workload updates, fixed net8.0/
runtime8.0.31, disabled compiler/build servers, no roll-forward and isolated
home/tmp/package roots remain unchanged. This configuration and the fixed
command are not represented as an independent kernel network sandbox.

## Timing and preservation

New stage budget: 300 seconds total, each direct child at most180 seconds,
stdout and stderr at most2 MiB each, first failure stops the three-command
sequence. Existing `run()` has a three-second emergency wait after its work
deadline. To make the new complete limits literal, propose one native-stage-only
cleanup-reserve argument: compute the child's complete deadline as the minimum
of the stage deadline and start+180, stop work three seconds earlier, and use
only the remaining complete budget for settlement. Refuse exhausted admission
before opening outputs/spawning. Existing stages retain their prior defaults;
no original receipt is reinterpreted. No generic process-ownership refactor.
If settlement is unresolved at the limit, record failure and stop; no later
build child or native action is permitted. Root approval of this paragraph is
required with the stage change.

Before the one build, read-only recheck the fixed acquisition manifest/hash,
SDK/runtime archive identities and all417 entries in the original
`compiler-reference-sha256.txt` (SHA
`996b59947a70ab6c4f60db846f9ac1d59985353bc257774432da38bda00a02f7`).
Retain source/config and original artifact pins before/after, explicitly
separating the four approved source/test changes from preserved bytes. Check
the same compiler/reference and original artifact pins after completion. The
existing source-input receipt binds current hashes, not a stale pre-activation
worker. No archive acquisition, installation or source-generation fallback is
allowed; the existing Fixtures.json must already be present and pinned.

## Exact old test migration

The first FakeTests group currently calls `Program.Main(empty args)` and checks
only nonzero under label `native entry is gated`. After activation, that would
read DEVNULL, fail with EOF and still pass without establishing its label.
Replace only this group with `activated entry rejects arguments`: assert the
activation property and `Program.Main(new[] { "unexpected" }) == 1`. The actual
Main's existing argument guard precedes stdin/config and
NativeSimulation.Configure. The other31 groups continue to use only the
authored ISimulation factory/MemoryStream and never the numerical constructor.
This is an explicit intentional migration, not native-API evidence. A separate
source-order assertion binds the argument guard ahead of input/config/native
preparation. The existing Python disabled-gate test patches the flag false, so
its original refusal assertion and all73 tests remain unchanged.

## RED-first finite test map

New Python file, exactly10 authored unittest groups, no subprocess/native/network:

| Group | Real branch/assertion | Expected failure/result |
|---|---|---|
| 1 | Parse exact two activation properties; model gates remain false | RED before two literals change |
| 2 | Mount `main(native-build)` with authored paths, time and `run` | Fresh distinct output/stamp/three commands,300s |
| 3 | Existing native stamp and partial new output | Refuse reuse, retain original bytes, zero child calls |
| 4 | First/second/third command nonzero | Stop exactly there, never start next child |
| 5 | New stage exhausted before admission | No new logs or child |
| 6 | Mounted run child complete deadline | 180s cap includes three-second cleanup reserve |
| 7 | Stage is earlier than child cap | Same remaining stage deadline, no budget borrowing |
| 8 | Stream overflow/timeout/settlement failure | Fixed failure, bounded retained streams, no retry |
| 9 | Existing pipe/review stage selection | Original paths, stamps and default timing unchanged |
| 10 | C# migrated refusal order and sole test delta | No empty-argument Main call, native factory unchanged |

Use real authored temporary file writes, but substitute SDK/process/time facts.
All unexpected socket, subprocess, ctypes and OS process operations are refused,
as in the independently executed parent73 wrapper. Retain original RED output
before implementing. After build, repeat the unchanged four-file73 wrapper with
only its explicit RAW_PATH changed to `native-build-tests.stdout.txt`; report
73 plus10 separately, including actual C# envelope checks rather than default
skips. Confirm exactly32 C# fake groups PASS and zero build warnings/errors.

## Handoff and independent gate

Record original/new source hashes and inverse-delta proof for the two activation
literals and single C# group. Freeze full build/test command and outputs; deliver
the exact SHA256/byte lengths of:

- `native-build/bin/Worker/Release/net8.0/Livemore.OspWorker.dll`
- same directory's `Livemore.OspWorker.deps.json`
- same directory's `Livemore.OspWorker.runtimeconfig.json`

Root independently reviews source/tests and repeats offline checks before
approving these exact three hashes for `prepare_package`. The future package
must bind the activated parent/source and current artifact, not the old inactive
DLL. Preparation itself, manifest publication, once authorization and actual
qualification each remain outside this step.

Not in scope: native worker execution, vmmap/OS probe, package creation, old R
retry, biology/physiology claims, arbitrary XML, tolerance or17-case/16-Run
changes, network/service/browser, public distribution or deployment. All native
source attestation stays UNVERIFIED, historical author runtime UNKNOWN and
model_admission=false. No TODO/architecture expansion proposed. Sequential
implementation, independent source challenge can run in parallel. Engineering
review: bounded existing-flow reuse; the two explicit test/timing precisions
above await root approval. This written plan is not self-grading or execution
authorization.

## Root implementation approval and initial preservation

Root read all173 original plan lines (SHA
`99894e27b7fb29c857509ee4db4c6fffba6d6379bfa50d4139d64b9a304adbfc`)
and explicitly approved the two activation literals, one native build invocation,
single fake-group migration,10 inert stage groups and300/180-second complete
budgets with three-second settlement reserve inside them. Native Worker,
package and authorization creation remain prohibited.

Before edits, the reviewer/maker independently rechecked48 frozen entries,
all417 compiler/reference rows, both original archive hashes and both executable
host hashes. Zero differences. The exact four before-source byte strings and
fixed preservation identities are retained in
`/private/tmp/livemore-dotnet-worker-toolchain.E09gsz/native-activation-before.json`.
No source or acquired file was modified by that check. New tests are authored
against the original source before the first RED invocation.

## Maker implementation/build freeze

Implemented only the four approved existing-file deltas and the new10-group
test file. Exact activation inverses recover the cleared parent/worker hashes;
the single C# group inverse recovers the original complete fake-test hash. These
are executable assertions, not only line-count comparisons. Original73 Python
tests are unchanged. No implementation fixture correction was needed.

- Original RED `cd8ff5`:10 groups,8 nonpassing and2 preservation groups;
  unittest reports6 failures plus6 errors because groups contain subtests.
  Errors identify the not-yet-added cleanup_reserve API. Prohibited I/O0.
- New stage GREEN `b4a709`:10 PASS in0.161s, prohibited I/O0.
- Single build: start `c9ae3a` / session50481, completion `e009a6`, exit0.
  Restore1.708225s, build3.622691s, fake host0.430880s. Exactly32 groups PASS,
  zero failed; build stdout records0 warnings and0 errors. Stamp-to-final receipt
  interval5.765128477s, inside300s. No second build was attempted.
- Full guarded repeat `a0d697`: **83 PASS in0.662s**, prohibited I/O0, no skips.
  This is unchanged73 plus10 stage groups; both emitted-byte consumers explicitly
  read the fresh `native-build-tests.stdout.txt`.

Complete RED/GREEN output and the exact standalone83 command are retained at
`/private/tmp/livemore-dotnet-worker-toolchain.E09gsz/native-activation-offline.txt`,
SHA `e21467a3192c2392834995c963dff77c393d79b9525941f79766e297d5d40583`.
No compiler command executes in that offline repeat. Actual build argv,
environment, streams and exits are in the three `native-build-*.json` receipts.
`WORKER_FAILED` on fake-host stderr is the expected fixed rejection from the
nonempty-argument test, not a hidden failed test or native solver attempt.
Fake-host output is authored numerical transport data, not solver output.

Final source SHA256:

| File | SHA256 |
|---|---|
| parent, activation literal only | `8b158726c891f36a6ac90f329d7ef22f5bc750d2b3ea14bc0ecdcab7ada0e0d5` |
| Worker.cs, activation literal only | `2f07a2e808dbad5c718b68f40785153a98a1b1b0c813904ef07b2d5977654ddc` |
| build_fake.py, additive stage/reserve | `7fae2ce371311ad621676924f7bd59d03db5f801419902092b04b1a0021c4caf` |
| FakeTests.cs, one group migration | `bc99180830bf97d7083d45e29ce0702dce50c98d063691cbd0571fcae531969d` |
| new10-group Python tests | `657c0fa8297023b331b8d3789f65b76425d96eb4b2234813484e4f141f52d03b` |

Candidate directory for later separately approved inert packaging:
`/private/tmp/livemore-dotnet-worker-toolchain.E09gsz/native-build/bin/Worker/Release/net8.0`.

| Artifact | Bytes | SHA256 |
|---|---:|---|
| Livemore.OspWorker.dll |141824| `db7f681191a10802c301dd1054e967141d3b9bb6a778483ffaffda8111820bb0` |
| Livemore.OspWorker.deps.json |1182| `1a48e4a9e96ef182b6e78c549b44fcc7d9b27dcbe6a67c8e898bb8aa578aca91` |
| Livemore.OspWorker.runtimeconfig.json |359| `a54ac5262f010c9d2d3cc1ea3778f237c73915881a01e8f86e70953dd02fecb8` |

`native-activation-freeze.json` binds77 source/build/original-evidence files,
SHA `e428497db34d0cf7ba36c589b3aea70cc47bca532d54cade498dbc8bbefd2c93`.
Pre/post checks confirm all44 unaffected old freeze entries, all417 compiler/
reference rows, both archives and both hosts unchanged. Four deliberate edits
are separate; no stale inactive-source hash is claimed to match. Exact diff
against retained original strings: `native-activation-source.diff`, SHA
`981bc5d99b1496f4daff96d5242ba0cee30bf91c00d69361b2807b28fd068544`.
Original before-source receipt SHA
`d392eab7074089373a7e2138dec429e76536c5b6264d367866ec8eb426db4508`.
Fresh fake stdout SHA
`1f1295f6795729c53c936714171978838535524d7581da3d91854b80b84f21e3`.

Activation booleans are now true; all model-admission and old scientific gates
remain false. This step did **not** execute Worker.dll, configure the native
adapter, create an execution package/manifest or once authorization, start an
inspector, or run S01-S17 against a native solver. Compiler/fake-host receipts
do not prove a kernel network sandbox or independently empty descendant tree.
Root must grade source/tests and artifact pins before the separate next gate.

Compounded lesson: activation can make an old negative test falsely green by
EOF rather than its intended guard. Bind the replacement rejection before native
preparation, and preserve every other assertion. Complete-time budgets need
cleanup reserved inside them without reinterpreting older receipts. These
lessons are recorded here because CE is unavailable. Maker status: frozen for
independent review, not self-cleared for native execution.
