# OSP fixed OS-only preflight — proposed exact seven-condition packet

2026-09-09. **Preparation only; root must review before harness authoring.**
No OS/native/R/CLR call, child, test, browser or service was invoked to write
this plan. This is the previously approved OS boundary check, not an eighteenth
scientific case, new native-source standard or permission for S01–S17.

## Frozen reuse and the single necessary specialization

Read the full retained collector/supervisor amendment, all920 current supervisor
lines, its independent440-case receipt and the retained Beard OS-only plan.
Reuse `tools/osp_semantic_supervisor.py` unchanged at SHA256
`cdb00a1acb5b08b3f7d8aff0f3977f746b5a506ed4f97355b56dd34bf2d2a476`.
Its `_execute`, `Owned`, actual Darwin samplers/held-waitable checks, stream
draining, limits and cleanup remain the implementation under test. The R source
stays `3ba6559b723cfe85c66bca47aac0abfbaac8e395c430bd7360105dc6f67625f7`;
pure fixture/source and both false production execution gates stay unchanged.

`_check_processes` intentionally admits only the fixed R leader or vmmap. A
Python fixture cannot use `_execute` unchanged at that policy seam. Proposed
private specialization: install a finally-restored classifier only in the
preflight driver process. It admits exact frozen Python fixture argv/path and
only the one declared same-group fork descendant; real vmmap delegates to the
original classifier. Record contradictory sampled rows before rejection.
Do not replace sampling, identity proof, WNOWAIT, signaling, clocks, output
draining, cleanup, admission gates or any scientific function. No production
signature, generic argv API, generic runner or new OS abstraction changes.

The private OS worker uses two explicitly OS-only PRE_XML/FINAL barrier messages.
Do not call the scientific `Barriers` class or fabricate its dotnet STARTUP
events, managed inventories, R namespaces or native observations. Real vmmap
collection reuses `_execute(inspector=True)` and `vmmap_paths`; its target is
only the already proven exact owned Python PID. Two calls total, no retry.

## Proposed write set and fixed identities

After approval, create one0700 private directory containing only
`run_preflight.py` and `fixture.py` (0600), plus new authored offline tests in
`livemorebio/tests/test_osp_semantic_os_preflight.py` and an evidence report.
Root/reviewer reads every byte and freezes their hashes before any invocation.
There is no edit to `livemorebio/` runtime, original OSP files or existing tests.

Use the same fixed Python3.11.15 executable as the retained Beard OS packet:
`/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11`,
historical pin `e3938f2a272dafdc33f3dd12b093dfc85354629476cb97a7d7d4a7201b8482dd`.
That is a retained pin, not a new current-byte observation. Before code freeze,
read and pin the current logical/resolved executable, size, SHA and lossless
identity integers; also `/usr/bin/vmmap` and `/bin/sleep`, fixed source/helper
hashes and the V2 manifest's exact OS/build metadata. Reject disagreement; never
search for a replacement Python/tool. No dSYM/tool invocation is required for
static preparation; actual sampled image UUID remains separately observed.

The driver starts with `-I -B`, fixes the reviewed repository source path for
verified module loading and confirms expected function bindings. The fixture
receives only its fixed case/role and private directory, never arbitrary code,
XML, shell command or environment. Use a clean environment with private
HOME/TMPDIR/cache, `PYTHONDONTWRITEBYTECODE=1`, C locale and fixed system PATH;
no R/DOTNET/DYLD settings, proxies, credentials or inherited startup overrides.
Existing child umask/core/CPU/file limits remain. No R, dotnet, CLR, OSP library,
NumPy, scientific importer, package installation or compiler is used.

A separate exact-hash authorization and exclusive once-only marker precede
the first child. No execution authorization exists now. The driver has a
separate closed local gate; it never enables either production OSP gate.

## Fixed schedule and required observations

Exactly **nine direct children plus one fork descendant**: six worker leaders,
two actual vmmap inspectors and one authored stalled-inspector child. Condition7
creates no directory or child. No repetitions, retries or overlapped cases.

| ID | Fixed behavior | Required outcome, without rewriting raw receipts |
|---|---|---|
| O1 | Python worker emits two bounded OS-only barrier requests and waits for exact ACKs. Parent runs `/usr/bin/vmmap -w <owned-PID>` once at each. Worker exits0 after FINAL ACK. | Both original inspector receipts exit0, complete bounded streams, correct target PID and nonempty unambiguous mapped paths; same live proven worker at both barriers; positive samples, unchanged identities, all three groups empty/reaped. This is Python image/permission/format evidence, not R image closure. |
| O2 | Immediate-exit Python writes fixed ASCII stdout/stderr and exits0. | Actual exit0, exact stream bytes/hash, empty-before-reap. Accept either valid positive samples or exactly ZERO_SAMPLES with count0, clearly counted as fail-closed resource admission rather than resource-qualified success. No other primary error qualifies. |
| O3 | Waiting worker; parent runs one fixed authored Python inspector which writes a marker then sleeps. Same inspector2s deadline/limits and unchanged cleanup. | Inspector primary WORKER_DEADLINE, positive actual samples, settled empty-before-reap/EOF within2s. Outer fixed callback records the expected timeout and stops/cleans its worker. This exercises timed-out inspector ownership, not an actual hung vmmap/kernel task. |
| O4 | One worker forks exactly one same-group child; both ignore TERM and have8s natural-exit failsafes. A readiness pipe proves the descendant exists. Parent cancels after observing both. | Actual TERM then KILL, both identities/group membership recorded, leader killed, no live descendant before leader reap, positive samples and complete fixed streams. Natural failsafe expiry cannot count as successful escalation. |
| O5 | Default-TERM worker emits ready marker. Fixed parent callback raises KeyboardInterrupt after a valid live sample. | Actual parent cancellation path retains SUPERVISOR_FAILURE, settles the owned group and streams within budget. Record the deliberate callback trigger; do not claim an externally delivered signal or invent a user interrupt. |
| O6 | After initial Python identity is captured and ACKed, the fixed worker directly execs `/bin/sleep` with exact argv `[/bin/sleep, 2.5]`, no new process. | Actual image/argument contradiction is retained; old identity is never updated to admit it. The unchanged proof stabilizer reaches UNRESOLVED_CHILD without TERM/KILL/reap while the changed image is live. Preserve the owner object and original failed receipt. Missing contradiction or early natural exit fails this condition rather than triggering another attempt. |
| O7 | Immediately invoke the existing entry guard and a would-be second `_execute` with its fixed otherwise-admissible fixture spec. | Both reject UNRESOLVED_CHILD before child creation or case files. No classifier/sampler/owner override can make this pass. Then perform only the bounded terminal observation described below. |

Every fixture writes only fixed technical markers, its own/declared child PID,
case/phase/sequence and source-binding metadata. Freeze exact expected bytes and
hash reconstruction before code review; do not accept only the supervisor's
claimed hash. PID-bearing expected bytes use the verified parent-owned PID.
Barrier JSON is at most4KiB, atomic no-overwrite publication, one ACK per phase;
source/request mutation or excess messages fail. No coordinates, biological
quantity, patient record, environment dump or broad process inventory is read.

## Negative-case terminal ownership and budgets

For O6/O7 only, retain the original unresolved receipt and occupied private slot.
Observe that **same** held leader's fixed natural exit using unchanged WNOWAIT;
only after it is waitable may unchanged `Owned.cleanup` confirm the empty group
and reap it. No signal is sent while its image proof is uncertain. Record this
later terminal receipt separately; do not relabel the earlier cleanup success,
clear the slot or start any further work. Incomplete original stream evidence
remains incomplete. A later fresh native process would still require its own
authorization; no state is carried forward as native permission.

Root decision needed before code: this deliberately expected negative branch
may satisfy the OS preflight only if both refusal and later verified terminal
settlement are retained. The module slot remains occupied by its now-settled
historical owner until private driver exit; occupied-slot and actually unresolved
live-process status must not be conflated. Missing terminal proof is overall
failure, with the held anchor retained and no cleanup claim.

Use one60s monotonic whole-preflight budget including identity checks, setup,
all nested inspectors, evidence and cleanup. Complete O1/O2/O3/O4/O5/O6 ceilings
are10/5/8/6/6/6 seconds respectively, each capped by that common deadline.
O6's ceiling includes O7 and at most3s observation-only final settlement: no
clock extension after its failed proof. No case starts without its full reserve.
Production30s/600s limits are unchanged. Inspector2s, TERM1s/KILL1s, proof1s,
CPU20/21s, sampled3GiB,100ms target/500ms maximum sampling gap, worker1MiB
streams, inspector512KiB/8KiB, case4MiB and packet64MiB remain unchanged.
There is no deliberate memory/CPU/stream exhaustion or hard-memory-isolation
claim. No guarantee is made against simultaneous driver loss or OS scheduling
stalls beyond retained observed deadlines.

Fail-stop on an unexpected condition; retain attempted receipts and NOT_RUN
remaining rows. Preserve primary error, expected-negative classification,
separate cleanup/stream/identity evidence and exact authorization/hashes. Overall
OS_PREFLIGHT_PASS requires all seven prescribed conditions and final absence of
actually live/uncertain owners, not an empty historical slot. Missing/late/bad
evidence or failure to persist the final receipt exits nonzero.

Offline tests must first exercise the fixed classifier/argv scope, exact schedule
and child cap, gate-before-I/O, two barriers/two inspector calls, per-case/shared
budgets, negative-result grading, original receipt retention, no slot reset or
signals during uncertainty and no spawn/files after O7 refusal. Run no actual
child/OS sampler in that test phase. Root independently grades that frozen
implementation before deciding one actual preflight; no invocation is implied
by approval of this plan.

Root read all133 original lines and approved the exact private test-first
implementation. Both explicit decisions are accepted: fixed classifier-only
specialization with finally restoration, and original unresolved/blocked-entry
receipts followed by separate waitable-anchor settlement, never slot reset or
signals under uncertain image proof. All three authored files (driver, fixture,
offline tests) live in one private directory; no repository runtime/test edits
are required. Root reads every byte and independently repeats inert tests before
any once-only execution decision. Whole60s and9-direct-plus1-descendant caps,
all production gates and scientific status remain unchanged.
