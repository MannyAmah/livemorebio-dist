# Molecular passive transport: one actual diagnostic decision

2026-09-09. Root decision within the approved R01–R51 correction-first scope.
This document authorizes one technical browser invocation, not a scientific
experiment, product release, repeated sampling or active consumer switch.

## Independent readiness

The implementation and independent 110-case inert repeat are recorded in
`2026-09-09-molecular-transport-observation-plan.md`. Root re-read the full
frozen checker and unchanged Python supervisor, verified 22 input plus 8
harness pins in both roots (`caeaac`), confirmed unchanged parent tests/page
bytes and absence of the new `run` directory. Source review found no remaining
critical issue after the red-first derived-tail correction.

The additional read-only `osp_evidence_review` spot audit found no critical
issue: original network failures still block PASS, incomplete cutoff facts
survive later completions, post-cutoff errors remain failures, and CDP detach
retains cleanup ownership. It ran no tests or browser. Correlation remains
page/route/occurrence evidence, not proof of causal identity across observers.

## Exact once-only authorization

Run only:

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-molecular-transport-browser.OYVOcS/check.py --run-once
```

Fixed private root: `/private/tmp/livemore-molecular-transport-browser.OYVOcS`.
The supervisor exclusively creates `run`; this root cannot be reused.
Checker SHA-256:
`4ac226878e9fc5f0e4edd099ee728feb8ee30fe98ef3599f6b5b63c920d02cfa`.
Python supervisor SHA-256:
`1dd4a2c22483f01c54ba45a53b9812d03f0c35bfe4b0dd80de9181903ac0a168`.
Input manifest SHA-256:
`e598e99b847179cf49de31724ee2367bcd01c1973ac297ff15dccef0a7d406af`.
Harness manifest SHA-256:
`3da8c7f2a97d9959aaa2ebf8fc9cced97be77877ceb1645a2c727e5699f5286b`.

Retain all four existing stages and 11 captures, six literal deposited
structures and the unavailable-human-INS check. Retain exact-route GET-only
127.0.0.1:8910 service, pinned local Chromium/Playwright, original CSP and
interception, no remote requests, no application stores, no biological/native
model execution and no hardware command. Existing 240-second outer deadline,
180-second work budget, 15-second cleanup, 128 requests/32 MiB served/64 MiB
evidence and new bounded passive observation limits remain unchanged.

## Outcome rules

Preserve the original result even if failed. Read and hash original supervision,
browser and image files; inspect every generated planned image and any failure
image. Verify exact owned cleanup and unchanged pins. Request independent
data-only result review without another invocation. A non-reproduction is not
a demonstrated fix; a failed terminal still prevents PASS. Do not rerun this
root or alter the reader based on an unproved cause.

QA's clean-tree/atomic-commit defaults are overridden by the user's explicit
preservation and release gates: no stash, discard, commit, push or PR here.
Its visible-action and screenshot checks use the already documented pinned
private Playwright fallback after gstack browse exit 137. No upgrade or absence
of QA tooling is disguised as full-product acceptance.

All R01–R51 remain open/in progress. The six required detailed experiment
recordings remain 0/6. Public reference inspection does not establish human
functional equivalence, an experiment result or completion of deep Biology.

## Actual outcome and root inspection

The sole invocation completed `7ffbda`, exit 1, **FAILED** after
47.10822741698939 seconds. Browser elapsed time was 46707.620542 ms.
All four D0/D1/D2/M0 stages and all 11 planned captures passed. All 29 original
Playwright requests finished; there were no retained network failures and no
page, console or CSP errors. Served bytes remained 10,296,699. The previous
ERR_ABORTED did not reproduce in this attempt; this does not establish its cause
or a fix.

Overall failure is `TRANSPORT_OBSERVATION_FAILED`, with the observer's first
code `TRANSPORT_PROTOCOL_CLOCK`. All 29 server identities have finish and close
events. The independent CDP observer retained 29 network request/response pairs
(all response status 200), but no admitted network terminal; their states remain
PENDING. Six DATA_NON_NETWORK identities finished. Added transport evidence is
43,842 bytes, below its 256 KiB ceiling. Both cutoffs preserve all pending CDP
ordinals and have settled detach. Do not infer CDP completion from another plane.

Root inspected all 11 original planned PNGs plus `failure.png` using the image
viewer. The source structures, sequence, Help, selection and genuine **5.82 Å**
distance are visible. Desktop canvas is 989×478 and mobile canvas 350×240.
Initial status/scope text is unobscured, with no horizontal clipping. The later
mobile provenance capture intentionally scrolls the molecular canvas out of view.
The failure image shows the correctly closed technical page and restored focus,
not a failed source render. All eight open/close cycles restore focus and remove
the plugin; mobile Tab containment and Escape closure pass. Pig 4INS remains
explicitly separate from unavailable human INS, which made zero coordinate GETs.
These are limited public-reference controls, not live cells or experiment effects.

Root read-only receipt `3e0b6f` verified exact original/embedded browser equality,
all 12 image sizes/hashes/dimensions, source identities, selection and close
cycles. Raw browser result is 250,468 bytes, SHA-256
`06a66f5fa9ca1dea2e8c072b6305718dddb9d3cfce13b7e8444178f237ff26bf`.
Supervision is 270,252 bytes, SHA-256
`41db85d9c746c818179cf10ec9acb23dd71f5060a2a2f29d38073b50d7dccef7`.
Both are under this decision's fixed private `run` directory. All 22 input and
8 harness pins in both original and successor roots remained exact (`6c9c1b`).

All eight owned closes settled: two CDP observers, two pages, two contexts,
browser and server. The supervisor reaped Node PID 43592, retained 19 descendant
identities, found no remaining descendants, and confirmed no owned listeners.
Root's separate exact 20-PID check `84d30e` returned exit 1 with no rows. No
unrelated process was signaled and no existing product service/store was touched.

The checker uses one code for both malformed/nonfinite protocol timestamps and
timestamps earlier than the last received event, then throws before retaining
the rejected fact. Therefore this packet does not establish the rejected event
type/value or which condition failed. Root read the pinned protocol types and
Playwright source: the former defines a monotonic clock, not callback delivery
ordering; the latter computes completion against request start and clamps its
derived response end. This makes the observer's added ordering assumption an
investigation target, not evidence for an application-reader correction.

No retry is authorized. An independent data-only review is in progress. The
consumed root and all old failed results remain intact. The next independent
increment is the already planned OSP failure-evidence correction, not a change
to numerical biology or a substitute for the six requested recordings.

## Independent data-only review

The independent reviewer completed read-only audit `eb7f52`, exit 0. Both JSON
files were decoded completely with duplicate-key and nonfinite-value refusal;
the embedded browser result exactly equals the original. Every planned PNG and
the additional failure PNG matches its original recorded hash, size and IHDR
dimensions (nine 1440×1000 planned desktop images, two 390×844 planned mobile
images, and one 390×844 failure image). This reviewer verified bytes/metadata,
not rendered appearance; the visual inspection above belongs to root.

All 30 successor input/harness pins were independently rehashed with exact
size/mtime checks and stable before/after file identity metadata. All eight
source/provenance descriptors exactly match the retained catalog, including
separate pig 4INS and unavailable human INS. All 29 server/PW/CDP correlations
match page, route and occurrence. The complete retained tables have 35 CDP
identities/76 events, 29 server identities/87 events, and 29 PW identities/58
events. Every network CDP identity has REQUEST then RESPONSE(200), but no
admitted terminal. Exactly six data identities have REQUEST/RESPONSE/FINISHED.
The complete pending lists contain 20 desktop and nine mobile CDP ordinals;
server/PW lists are empty. No rejected timestamp was recovered or inferred.

The original 74-byte stdout is also FAILED, SHA-256
`71a9e357abb1da507a7e147bffebca508f09b5e0a9df927d906221bd6108cd56`;
stderr is empty. Before writing supervision, retained evidence totals exactly
1,900,872 bytes; adding the 270,252-byte supervision file gives 2,171,124 bytes.
All eight close receipts are SETTLED, with Node reaped and 19 recorded
descendants absent according to the supervisor. The separate present-state
20-PID check `84d30e` is attributed to root; this reviewer ran no OS probe.

Source-only inspection `4c64fe`/`ee8efb` confirmed the evidence limitation:
the frozen checker rejects at lines 176 or 184 before appending at line 200,
and both paths use TRANSPORT_PROTOCOL_CLOCK. Installed
`playwright-core/types/protocol.d.ts:9965` defines the clock and the four
payloads' numeric timestamps, but does not establish the checker's per-callback
ordering rule. `lib/server/chromium/crNetworkManager.js:436` and `:459` calculate
completion relative to request start; `lib/server/network.js:406`–`:410` use
`Math.max(responseEndTiming, responseStart)` and resolve completion. The latter
source SHA-256 is
`679bd2f9566d39b2ac16bba525b6d40c9f250463dc00b84a71fce226a1e41cd0`;
the Chromium adapter remains
`ad55830a87387450440a4b372ae6a93a6c91c089ccc1e72ffeb298662dddb744`.
These support challenging the observer assumption, not claiming that this
attempt actually received a backwards, missing or nonfinite timestamp.

Conclusion: **FAILED retained**. The earlier ERR_ABORTED did not reproduce in
the original PW ledger; the new observer did not obtain valid network-terminal
evidence. Neither fact establishes a product fix, identifies the previous abort's
cause, or opens a release/scientific gate. No tests, browser or model were run in this
review, and no consumed files or source code were changed.

## Proposed next diagnostic precision — not authorized implementation or run

The smallest next correction is rejected-fact retention, not a product change
or silent relaxation of clock/transport admission. In a separately reviewed
fresh private successor only:

- Before either clock refusal, retain a bounded fixed CLOCK_REJECTED event with
  the event kind, page, known local ordinal (otherwise null), Node observation
  time, and an explicit classification: MISSING, NONNUMERIC, NONFINITE, NEGATIVE,
  or EARLIER_THAN_LAST. Do not retain a nonnumeric value/string or arbitrary ID,
  URL, header or payload. A finite rejected number (including a negative one)
  may be retained as evidence; otherwise its numeric field is null, never zero.
- Retain the last admitted protocol timestamp separately when available. A
  finite earlier-event relationship must be distinguishable from malformed
  scalar input; neither is an application AbortController attribution. Record
  the observed protocol event kind without promoting its rejected terminal
  into FINISHED or erasing the original pending-at-cutoff evidence.
- Initially keep the existing refusal and original overall FAILED path. The
  current packet cannot support choosing which condition to relax. Any later
  decision to treat finite timestamp ordering as descriptive rather than an
  admission gate needs its own explicit source-backed review, not a guessed
  reconstruction of the discarded actual event.
- Red-first authored emitter cases must prove every classification, safe finite
  versus null representation, known/unknown ordinal handling, original failure
  preservation, and rejected-event/cutoff evidence within the same derived
  256 KiB bound. Preserve all 110 current tests and the unchanged four-stage,
  11-image workload, product/reader/Python bytes, ownership and time limits.

This proposal authorizes no implementation or further browser sampling. Root
must first approve the exact small correction, independently review its frozen
inert evidence, then separately decide whether any actual attempt is warranted.

## Root next correction decision — inert implementation only

Root accepts the independently proposed rejected-clock retention correction.
Implement it in a fresh private successor, never in the consumed OYVOcS root.
Retain both existing clock refusal predicates and overall failure semantics;
this is not approval to accept earlier timestamps or mark any pending request
finished. Only add the fixed bounded rejected fact before refusal and authored
RED tests for its classifications, privacy, identity and limits. Original 110
tests, product/page/Python bytes, native dependencies and all limits remain.
The first error code must survive even if retaining the additional event hits a
bound; such overflow must stay explicit. No unbounded alternate ledger.

Root will implement this narrow diagnostic correction and the independent
reviewer must grade it. **No additional browser invocation is authorized.**
The active OSP correction remains independently owned and its source/native
gates are not affected. All six programs and R01–R51 remain unchanged.

## Root maker receipt — rejected-clock evidence, awaiting independent grade

The fresh private successor is
`/private/tmp/livemore-molecular-clock-evidence.W8cBUx`. Its consumed parent
OYVOcS is unchanged. Root added a 20-line internal clock-evidence helper and
replaced the two existing inline checks with calls retaining the same refusal
predicates. CLOCK_REJECTED records only fixed event/page classifications,
known local ordinal or null, observation time, finite rejected/prior numbers
or null, and the five planned reason codes. Original transport failure is
latched before evidence writing. Overflow or unusable observation time retains
a bounded fixed retention-failure code; no rejected terminal becomes FINISHED.
Existing event/byte limits and pending cutoff reservation remain unchanged.

The first RED attempt `d1b3b8` had 13 intended new failures plus one inherited
fixture failure because the successor input manifest had not yet been copied;
103 inherited Node checks passed. After copying the manifest with only its two
private page paths changed, and with implementation still unchanged, `b797da`
established 13 new RED / 104 inherited Node PASS. Its complete `red-inert.txt`
SHA-256 is `ff496bf063e5616147ae59f69ccb723942653a49fa85a7f562e0335903d73c2d`.
Python was not reached after either Node failure, as the wrapper fails closed.

After implementation, `6ac8d1` passed 117 Node and six Python checks. Root then
added one zero/invalid-observation-clock boundary case without changing source.
Final maker run `613bdc` passed **118 Node + six Python = 124 checks**, with
zero failures, cancellations or skips (Node 3229.927166 ms, Python 0.021 s;
outer 3.461636166 s). `final-green-inert.txt` SHA-256 is
`e232085e4aa94390312089313206728e97013f045ccf079576c7e532af7a1994`.
These are maker results, not an independent acceptance receipt.

The 14 additive cases cover malformed scalar classes, earlier-than-last,
known/unknown identity, response/failed event kinds, original error retention,
event/byte bounds, pending cutoff, zero and invalid observation clock. Root's
read-only `d2657e` confirmed all 22 input + eight harness pins in both roots,
five unchanged copied files, and the original Node test file as exact prefix.
The successor has no `run` directory. Root reviewed the complete source delta
in `271245`; no product, page, Python, reader, model or dependency was changed.

Frozen successor identities:

- `check.cjs`: 35,875 bytes, SHA-256
  `16dc2315c3093ff95fca1215d7c4b78b79314aee610617e947aaee044cad04a9`.
- `test-check.cjs`: 40,554 bytes, SHA-256
  `5741a45c290bda88b44b6aa5df2a771e1506bfc6ba7305557d915fe2a1a7d674`.
- `inputs.json`: 7,764 bytes, SHA-256
  `0335456d44b8aca8bc60862380e856668424d49e8206665d4a6a17e5355192d4`.
- `harness-pins.json`: SHA-256
  `a49608cf83e40187e0a4c95976cafa548d13e065678d1dd7c3bd9bd237223728`.
- Unchanged Python checker: SHA-256
  `1dd4a2c22483f01c54ba45a53b9812d03f0c35bfe4b0dd80de9181903ac0a168`.

Independent review may inspect the complete delta and run only the exact
`run-inert.py` wrapper with the pinned Python 3.11.15 interpreter. This remains
an inert diagnostic correction; it authorizes no browser/native execution,
public consumer switch or release, and leaves the original actual FAILED.

## Independent grade — rejected-clock retention successor

**CLEAR for this bounded private diagnostic increment only.** The independent
reviewer read the complete prospective/maker record, complete checker delta,
surrounding identity/serialization/cutoff paths, all 14 additive cases and the
unchanged inert wrapper. No blocking source or assertion issue was found.

The two original refusal predicates remain equivalent for the admitted private
entry state: finite/nonnegative timestamps are required first, and subsequent
events must still be no earlier than the last admitted timestamp. The helper
adds evidence before refusal, not a new completion path. Known ordinals/prior
values come only from the bounded internal map; event/page/reason labels are
fixed. Strings, objects, raw protocol IDs and nonfinite values cannot leak into
the new numeric fields. Zero is retained as zero. First failures latch before
retention; event/byte/observation-clock refusal uses a bounded fixed fallback.
That additional fallback fits the existing 512-byte fixed-label allowance;
the 256 KiB ceiling, derived cutoff tail, pending lists and ownership are intact.

Read-only precheck `b00e70` verified all 22 input plus eight harness pins in
**both roots**, the five byte-identical copied files, the complete parent Node
test file as an unchanged prefix, and the maker's four frozen hashes above.
Only input rows 0/1 differ by private page path/mtime; no product, reader, page,
Python supervisor or dependency bytes changed. Both retained maker transcript
hashes match this document. The fresh root had no `run` directory.

The reviewer ran exactly:

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-molecular-clock-evidence.W8cBUx/run-inert.py
```

Independent session `17394`, initial receipt `f9c7f4`, completion `4dd9db`,
exit 0: **118 Node + six Python = 124 PASS**, zero failures/cancellations/skips.
Node duration was 3218.075375 ms; Python six-case duration was 0.020 s. Only the
fixed Node unit-test process was permitted under the unchanged network/child
refusals; no browser/native/model/OS probe or actual runner was invoked.

The subsequent read-only check `aad8ac` reverified both 30-pin sets, the five unchanged
files and original test prefix, all four original actual receipt/stream hashes,
and all 12 original PNG hashes. The successor `run` directory remains absent.
This acceptance neither reconstructs the earlier rejected timestamp nor proves
the ERR_ABORTED cause or repair. Original FAILED results remain unchanged.
Any actual browser invocation requires a separate root decision.
