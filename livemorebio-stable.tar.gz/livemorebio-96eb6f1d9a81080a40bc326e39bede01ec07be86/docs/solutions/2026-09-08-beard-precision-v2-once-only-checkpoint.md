# Beard precision v2 — private execution checkpoint

2026-09-08. PREPARATION ONLY. This adds no product API or experiment outcome.
The frozen numerical protocol is SHA256
`68ff48a84ce6ca51828dbc2034322ada2c51ac4875b53a6fb8f1f6b4685ea758`.
The corrected supervisor candidate is
`45e7442b9e9872a2a62a67c47c0f7b77d1ae170c5ea0e9bd986ab187d251853d`.
Root read the complete584-line execution implementation,215-line implementation
review, supervisor amendment and numerical protocol. Root repeated the isolated
static/mock packet:229 passed,32 explicit opt-in skips in1.25s. No native process,
compiler, source evaluation or solver was enabled by those tests.

## Private driver preparation

After independent supervisor clearance, prepare a new owner-only private driver
directory with `mktemp -d`; retain the original v1 driver and every failed result.
Reuse its reviewed fixed-path/verified-byte loading pattern, not its execution
authorization. The new driver must have a distinct authorization ID and bind its
own exact hash. No authorization receipt is written until root and reviewer read
the complete candidate driver. Creating the driver is not permission to run it.

Required bindings and behavior:

- Exact pinned original source, v1/v2 protocols, every reused source module, all
  three precision modules, Python executable/prefix, libCellML package and native
  runtime/compiler/dylib manifest. Load Python modules from their verified bytes;
  verify loaded path, object linkage and code filenames before enabling gates.
- Read-only retained B1 result and stdout from the original successful local B1
  branch, with their fixed hashes. No B1 recomputation.
- Fresh isolated `-I -B` process, sanitized environment, private files and no
  network, user data, operational stores, service mutation or device interface.
- Atomic exclusive, fsynced once-only marker before the matrix. No recovery by
  erasing the marker, auto-retry, parameter override or tolerance change.
- Enable only precision execution and original source-expression evaluation in
  that authorized process. Keep v1 execution and technical-worker gates false;
  reset enabled flags in `finally`. On-disk gates always remain false.
- Exactly I2a,I2b,P2,P3,H3,R3,K3 under the frozen fail-stop rules. The v2 matrix
  implementation owns per-branch source/resource/cleanup checks. No extra source
  invocation, pre-run biological trial or alternate candidate.
- Record actual elapsed time, complete status, matrix/artifact references and
  failure details. Only an unqualified `NUMERICAL_PASS` can exit zero; uncertainty,
  missing diagnostics or any failure exits nonzero. No whole-driver hard-resource
  guarantee beyond the existing per-invocation bounds is claimed.
- If the supervisor's capacity-one unresolved-child slot is occupied, force a
  nonzero `UNRESOLVED_CHILD` driver outcome, retaining the actual primary matrix
  failure separately. Report PID and unknown cleanup rather than claiming it was
  stopped. Do not clear the anchor or attempt an unreviewed recovery signal.
- Raw stdout remains private evidence; reports contain bounded structured
  outcomes, not whole output dumps. Receipt-writing failures remain secondary to
  the original outcome and may not turn a failed matrix into success.

The runtime's actual OS ownership behavior is exercised by the fixed matrix once
authorized; mocked process tests alone have not established it. If independent
review requires an additional harmless process-only probe, specify it before
execution instead of inserting an undocumented extra invocation.

## Acceptance after the single authorized attempt

Root reads the complete driver and freezes its hash before authorization. A later
explicit root checkpoint permits one attempt only. Afterward root and independent
reviewer inspect complete original grids, initialization, checkpoint lineage,
all five acceptance comparisons and three diagnostic comparisons, exact settings,
raw hashes, process cleanup and observed resources. Verify that recorded owned
processes are absent; do not signal unrelated services or numeric PIDs without
resolving ownership. Retain any failed outcome and all old v1 failures unchanged.

Even a numerical pass is a reference mitochondrial mechanism result, not an
arctigenin dose-response experiment, human replica or physical qualification.
All six requested programs and material/exposure/tissue dependencies remain open.
