# OSP retained-native technical semantics: pre-code proposal

2026-09-08. Proposal only, by `source_research`. No fixture, collector, worker,
native load, compile, formula evaluation or solve was made for this note. Root
and independent approval are required before implementation; exact candidate
code/fixture/runtime review and a separate once-only authorization precede runs.

## 1. Decision and bounded provenance result

Recommend a small **technical behavior experiment on the retained byte set**,
without representing it as a source-equivalent build. Incomplete native build
attestation is a limitation, not an automatic reason to prohibit a separately
reviewed, bounded, nonphysiological experiment on those already-permitted bytes.
This replaces the strict ordering recommendation in the prior
[source map](2026-09-08-osp-native-semantics-source-map.md:139), not its evidence.
That frozen map's SHA256 is
`8e988ffe2fe511b60f1070e52aefc50283a4c01d0fa80315c3de4f89e463beb6`.

One bounded official web lookup was completed, with the previously authorized
read-only fallback after `/browse` startup failed. No package, asset, archive,
runtime or source tree was downloaded and no credentials were used:

- The [official ARM64 version page](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/pkgs/nuget/OSPSuite.SimModel.MacOS.Arm64/358613766)
  identifies **OSPSuite.SimModel.MacOS.Arm64 4.0.0.75**, package-version ID
  `358613766`. It lists a `package.nupkg` asset but exposes no member digest,
  source commit or build attestation in the retrieved page. We did not fetch it.
- The [fixed workflow](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/.github/workflows/build-and-publish.yml#L73)
  checks out source/submodules, changes version.h, builds platform packages and
  publishes to GitHub Packages. This is a recipe, not a receipt for our dylib.
  Its matrix spelling `MacOSArm64` is not the package-page spelling
  `MacOS.Arm64`; do not silently turn either name into byte-level provenance.
- The [Actions query](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/actions?query=branch%3Amaster+395dccf)
  returned loading errors/no usable run receipt. Direct public Actions and
  package-version metadata API retrieval was unavailable in this tool. This is
  not evidence that no historical build or attestation exists. Stop lookup here.

Retain `native_source_attestation=UNVERIFIED`, `historical_author_runtime=UNKNOWN`.
The source hypotheses below refer to inspected SimModel commit
`395dccf72a310b0485e63928741703045a1b40aa`, not to an established native build.
The managed informational version identifies that commit; Core identifies
`b941097d3b76c00163ba5fb8d21b48a6406f7107`. Do not upgrade either.

## 2. Runtime identity and allowed implementation boundary

Existing private root: `/tmp/livemore-osp-native.mUlZwx`. Existing R 4.6.1 ARM64,
.NET 8.0.30, ospsuite 12.4.3, rSharp 1.2.2, with their retained dependency lock.
Use the same R/rSharp low-level managed `Simulation` call path as the preserved
[collector](../../tools/osp_stage_b_native.R:123), but **do not import that
collector or gim_recipe.R**. They load physiological sources and are out of scope.

Mandatory existing byte pins, under `r-library/ospsuite/lib/`:

| Artifact | SHA256 |
|---|---|
| OSPSuite.SimModel.dll | `4c14eb2824397a1577e7c689984e4b9e9ea1b4297e6e480824681f19d199e520` |
| libOSPSuite.SimModelNative.dylib | `d3ca3467fa7886898e76c47a81df031dfa5403e3497448611c3cb0d71c120bd4` |
| libOSPSuite.SimModelSolver_CVODES.dylib | `19453818ef70c4b722f7aba518660927ac005e9b89ba8621598ec0038d99e257` |
| OSPSuite.Core.dll | `4a06d51aeda6175ce48cacbbee5494fb92c6b34420b01578a1f3ea8be1ae19b6` |
| ConsoleApp.deps.json | `65e93420e84c69a063a8b5f42311772fca7fe2d93e52b3754497e7d687e65fea` |

Before any later execution authorization, freeze a complete resolved loaded-file
allowlist for R, rSharp, CLR, managed and native dependencies, including final
paths and SHA256, rather than only the three principal SimModel files. Check the
loaded images against it before `LoadFromXMLString` and again at completion. No
fallback library search, restore, package install, compiler or JIT source export;
ordinary existing CLR JIT execution is part of the retained runtime, not a new
native model build. A changed or unobservable non-system image blocks the run.

Proposed new-only write set after approval: `tools/osp_semantic_probes.py` (fixed
fixture/expectation manifest and orchestration), `tools/osp_semantic_probes.R`
(bounded low-level collector), `tools/osp_semantic_supervisor.py` (owned process
control), and `livemorebio/tests/test_osp_semantic_probes.py`. No generic XML or
expression CLI; only exact admitted fixture IDs/hashes. Serialized XML, expected
JSON, driver and receipts live in a new 0700 private task directory, files 0600,
exclusive creation with no final-component symlink/hardlink acceptance. No edits
to any old OSP/Beard tool, source, native binary, result, product or gate.

## 3. Fixed technical definitions, before XML authoring

All quantities are invented **software-test quantities**, not biological pools,
parameters, measurements or doses. Clock `t` is the raw numeric native clock;
unit label `tau` means an arbitrary test-clock unit, **not minutes**. State unit
is `u`; RHS unit is `u/tau`. This tests numeric identity, not dimensional checking
by SimModel or a conversion convention for GIM. No anatomy/person/compound IDs.

Common grid G is `[0, 0.5, 1]`. Table grid H is `[0, 0.5, ..., 5]`, exactly 11
points. Use at most 4 state variables, 8 observers, 32 parameters, 64 formulas,
2 events and 4 assignments per fixture; XML <=64 KiB, <=1,024 nodes, depth <=16,
no DTD/entities/external URI. IDs/aliases unique, all references resolved except
the explicit native Time ID 0. No input or parameter is NaN/Inf. XML version4
grammar comes from inspected source; exact XML and full identity maps must be
reviewed before execution. No extraction of a small GIM submodel.

Solver settings for every positive fixture: CVODES, AbsTol `1e-9`, RelTol `1e-8`,
H0 `0` (native automatic initial step), HMin `0`, HMax `0.05`, MxStep `10000`.
No tolerance auto-reduction; zero warnings required. Every positive fixture has
a nonconstant technical state, adding `clock_state'=1`, initial0, when needed so
the packet does not accidentally test only the all-constant no-ODE shortcut.
All ODE scales are1 except the expressly declared scale10 case below. Persist
every named state and observer. Sensitivities and export/code-generation are off.
Confirm exact serializer/API mappings statically; unsupported mappings block
execution, not permission for guessed defaults.

Native method sequence: new managed Simulation, LoadFromXMLString, Finalize,
RunSimulation, SimulationTimes/ValuesFor/RunStatistics/SolverWarnings, Dispose.
For the three prescribed repeats call RunSimulation again on the same finalized
object without changing inputs, then collect and Dispose. No reset by a newly
invented API; the repeat tests the inspected native reset path itself.

## 4. Exact fixed schedule: 17 processes, at most 16 successful Run calls

Run S01 through S17 once in this order, separately initialized processes. S03,
S04, S16 and S17 must reject before RunSimulation. S01/S07/S08 each have two
prescribed same-object runs, the other positive rows one. The second call is a
preregistered repeat, never a retry after failure. Stop after the first unexpected
result. No fixture may be repaired and retried under the same authorization.

These are **SOURCE_EXPECTED** hypotheses. Observed arrays cannot be inferred
from them; fill observed fields only from the later actual retained-byte run.

| ID | Exact test input | Source-expected selected output on G unless stated |
|---|---|---|
| S01 | q=2, p=q+1; x(0)=1, x'=1, y(0)=p+x+1, y'=0. Declare y before x and p before q. Repeat same object. | x=`[1,1.5,2]`, y=`[5,5,5]`; second run identical, not x starting at2. This checks dependency initialization and reset, not continuation. |
| S02 | Fresh S01 except independent x initial2, retaining y's formula. | x=`[2,2.5,3]`, y=`[6,6,6]`. The evolved y from S01 is not transferred. |
| S03 | S01 x declares both value1 and an initial formula returning7. | Native Load/Finalize rejection, stage retained; Run never called. No chosen precedence. |
| S04 | S01 p declares both value3 and formula q+1. | Native Load/Finalize rejection; Run never called. |
| S05 | P=0, Q=0, oneTime1 event condition1 at initialization, assignments P=(t+2) mode1 then Q=(t+2) mode0. Observe P,Q. | Saved initial P,Q=0; at t0.5: P2,Q2.5; at t1: P2,Q3. Sampled constant versus installed time-dependent formula. |
| S06 | x,z initial0, RHS0; scales x10,z1; oneTime1 condition1, x=(t+2) mode0, z=(t+2) mode1. | Both unscaled state series `[0,2,2]`. Species assignment is sampled under both flags, and division/rescaling must not turn x into20 or0.2. |
| S07 | x initial0/RHS0; oneTime1 condition1; assign x=x+1 mode1. Repeat same object. No tables or other events. | Both runs x=`[0,1,1]`; no second firing while condition remains true, and latch resets between runs. |
| S08 | Same as S07, oneTime0. Repeat same object. | Both runs x=`[0,1,2]` for this exact save/update schedule. This is not a firing-rate law independent of the requested grid. |
| S09 | P,Q initial0; one initial oneTime1 event assignments P=2 then Q=P+1, both mode1. | P=`[0,2,2]`, Q=`[0,3,3]`. Sequential assignments, not an old-value batch. |
| S10 | S09 with assignment order Q=P+1 then P=2. | P=`[0,2,2]`, Q=`[0,1,1]`. |
| S11 | Two initial oneTime1 events, E1 assigns P=2; E2 assigns Q=P+1; XML order E1,E2. Both initial0/mode1. | P=`[0,2,2]`, Q=`[0,3,3]`. |
| S12 | S11 XML event order E2,E1. | P=`[0,2,2]`, Q=`[0,1,1]`. No claim about simultaneous SBML event semantics. |
| S13 | Tables/offset/integral defined below, grid H, all point restartSolver flags0. | Exact table and analytic integral vectors below, plus native Time observer exactly H. |
| S14 | Exact S13 except explicitly flag the point at x=3 for restart. | Same requested output expectations as S13. Internal restart occurrence/count remains unobserved without a supported trace; equal outputs do not prove equal schedules. |
| S15 | Negative-allowed technical x(0)=-5e-10, x'=-1e-10; z(0)=-2e-9,z'=-1e-10, both scales1; observe x,z and independent literal -5e-10. | At t0.5 and1, source predicts exported x=0 and x-observer=0, z and z-observer=-2.05e-9/-2.1e-9. The independent literal observer remains -5e-10. Retain all t0 values separately; initial observer timing is not asserted from the post-step cleanup path. Never label zero export an observed zero internal state. |
| S16 | S13 table with duplicate x coordinates: (1,2),(1,3), all flags0. | Native Load/Finalize rejection; Run never called. |
| S17 | S13 table reduced to a single point (1,2). | Native Load/Finalize rejection; Run never called. |

Formula/literal conflicts and invalid tables are bounded, deterministic authored
malformations, not fuzzing or arbitrary native input admission. Only these four
malformed cases bypass the fixture validator's corresponding semantic rule;
their exact XML hashes are still allowlisted. No other validation bypass exists.

### Tables: exact inputs and output oracle

T has points `(1,2),(2,2),(3,5),(4,9)`. Define T_y with useDerivedValues0, T_d
with useDerivedValues1. Constant offset `o=0.5 tau`; native TableWithOffset
quantities refer to each table quantity and o. Observe T_y(t), T_d(t), both
offset counterparts, Time. State a'=T_d(t), a(0)=0 is a genuine technical ODE.

On H the source hypotheses are:

- T_y: `[2,2,2,2,2,3.5,5,7,9,9,9]`.
- T_d: `[0,0,0,0,3,3,4,4,0,0,0]`.
- Offset T_y: `[2,2,2,2,2,2,3.5,5,7,9,9]`.
- Offset T_d: `[0,0,0,0,0,3,3,4,4,0,0]`.
- a: `[0,0,0,0,0,1.5,3,5,7,7,7]`.

This tests both sides of table endpoints and derivative discontinuities.
From inspected TableFormula source, unshifted inferred restart candidates are
{1,2} for S13 and {1,2,3} for S14, shifted by0.5 for constant-offset tables.
Keep these **source-expected candidate sets**, not measured restart receipts.
The managed collection path's saved arrays/warning counts are insufficient to
observe internal restart calls. Do not add native hooks, inspect private memory,
recompile, or invent a restart count. Report `RESTART_TRACE_UNOBSERVABLE` in this
packet. Dynamic offsets/compound condition root localization remain untested.

## 5. Comparison, evidence and status semantics

For nonzero order-one analytic outputs use fixed absolute difference <=`1e-6`;
for directly constant/interpolated observer outputs <=`1e-12`. Exact output
grid, IDs, counts, event order and settings are equality checks. S15 requires
exact numeric zero for cleaned outputs; other selected tiny values must differ
from the written analytic value by <=`1e-13`, not the order-one allowance that
would mask cleanup. Same-object repeats must have equal grids/IDs and bit-equal
collected doubles; no JSON roundoff substitute (serialize17 significant digits).
These are technical discrimination allowances, not replacements for any GIM
convergence/domain gate. Any result outside them is disagreement, not a reason
to change an expectation or tolerance after the fact.

Record every native saved value, including initial values not used by a selected
oracle. No interpolation onto missing outputs; constant native vectors may be
expanded only with an explicit native-constant marker plus original value/count.
All returned values must be finite, unique, complete and on the requested grid.
Any hidden extra saved grid points are a contract disagreement to inspect, not
silently dropped. No live twin, state cache or scientific evidence store is used.

Each immutable receipt binds schema `osp-retained-native-semantics.v1`, protocol,
driver/collector/fixture/runtime manifests, fixture ID, call ordinal, source
hypothesis IDs, native source-attestation status, actual stage/call count,
requested/returned grids/settings/arrays, warnings, exit and resource/cleanup
evidence. Structured result <=256 KiB/process and complete packet <=16 MiB.
Retain raw stdout/stderr separately with lengths/hashes, do not paste raw native
exceptions, local paths or environment into ordinary summaries.

Per-case labels: `OBSERVED_MATCH`, `OBSERVED_DISAGREEMENT`,
`OBSERVED_EXPECTED_REJECTION`, `INCOMPLETE`, `RESOURCE_STOP`, `CANCELLED`,
`IDENTITY_FAILURE`, `UNRESOLVED_CHILD`. Packet may be `TECHNICAL_EXPECTATIONS_MET`
only if all17 prescribed cases and16 Run calls finish as specified, independent
review confirms saved evidence, and cleanup is proven. The restart limitation
and `native_source_attestation=UNVERIFIED` remain even then. A match supports
only the stated input/call path on the retained bytes, not all source behavior,
historical-author equivalence, general event correctness or model qualification.

## 6. Resource, ownership and failure contract

One worker at a time, no concurrent Atlas measurement or other native job.
Before launch, create isolated HOME/TMPDIR/work directories, sanitized allowlist
environment, explicit existing runtime paths, no inherited credentials/proxies,
R startup profiles, preload variables or package-network restoration. Use R
`--vanilla`, fixed local script/XML only; Python supervisor `-I -B`. Networking
is not needed: collector must never call network APIs and tests install socket,
DNS and R download tripwires. These tripwires are not an OS network sandbox.

Per process: 30s wall from spawn, CPU RLIMIT_CPU soft20s/hard21s; 3 GiB sampled
resident threshold including any owned descendants; sample target100ms and
maximum permitted observation gap500ms. Exceedance, sampler/OS identity failure,
or unexpected descendant stops the packet. This is **sampled soft memory
protection**, not a hard3GiB cap. Record actual gaps, peak observed RSS, overshoot,
valid sample counts, total wall including cleanup, and available CPU observations.
Zero valid live samples cannot support a resource-protection claim.

Stdout and stderr each capped1MiB with continued draining/discard after the cap
only during termination; overflow is failure. Structured output256KiB. Each
fixture plus work output <=4MiB, total task budget64MiB. No retention deletion or
retry on full disk. Whole packet monotonic deadline600s including per-worker
cleanup, with no new launch unless at least35s remain. Limits never increase
after failure. MxStep10000 is a per-native-request guard, not a total CPU bound.

Use an owned process group and verified PID/start/image identity. Preserve the
leader as a waitable ownership anchor while checking descendants, including
already-exited leaders. Reuse the reviewed ownership algorithm conceptually,
not an old unbounded OSP runner or an unlocked Beard physiological gate. A
bounded observation-only stabilization window <=1s handles Darwin transition
ambiguity; no signal while ownership is uncertain. On failure/cancel/deadline,
TERM only the proven owned group, wait <=1s, then KILL if still needed, wait <=1s;
verify the group empty before reaping its anchor. Never signal an unrelated PID.

If proof/cleanup remains unresolved, preserve a capacity-one unresolved-child
anchor, stop every later entry before files/spawn, exit nonzero and report
`UNRESOLVED_CHILD`, not "cleaned". Parent/child loss cannot be hidden by a success
JSON. Handler interruption must retain the primary cause; Dispose errors,
evidence-write/read failures, cleanup failures and partial-stream SHA/observed
exit go in separate bounded fields, never overwrite it. Dispose is best effort
inside the same wall bound; forced group cleanup must work if native Dispose
hangs. Preserve partial outputs and the original attempted fixture hashes.

## 7. Pre-execution review sequence and stops

1. Independent review of this proposal. No new clinical or numerical approval.
2. If implementation approved, red-first pure tests of fixed XML identity,
   analytic vectors, normalization/strict JSON, per-case call counts, pin checks,
   missing/wrong outputs and all failure/resource/signal paths. Include mocked
   same-group descendant/short exit/identity ambiguity, malformed output with
   nonzero exit, evidence storage failure and second-entry unresolved rejection.
   Tests must prohibit any actual R/native invocation at this phase.
3. Freeze/read all exact XML, sources, dependencies and a once-only private
   driver. Identify public API observability before claiming any check. No
   unsupported calls or newly guessed runtime defaults. A need to change the
   fixed inputs/method requires a new written amendment before execution.
4. A separate fixed OS-only ownership/timeout/cancel probe may be needed before
   native authorization if the new supervisor cannot directly reuse already
   independently verified behavior. This requires its own reviewed schedule,
   not an implicit permission in this proposal.
5. Root separately authorizes the hash-bound17-case packet once; no numerical
   fallback or automatic rerun. Unexpected behavior ends it and leaves remaining
   cases explicitly `NOT_RUN`. Independent saved-evidence review follows.

No matter the outcome, do not rerun GIM, change its constants, classify away its
negative outputs, alter receptor/glycogen equations, recalibrate a profile, or
admit case2 insulin results. The Stage B FAILED matrix, first static FAILED and
accepted STATIC_GRAPH_COMPLETE remain intact. Exogenous insulin, erinacine A,
sterubin, carnosic acid, arctigenin and cyanidin-3-O-glucoside remain required.

The durable distinction is **provenance versus observation**: exact build
attestation supports source equivalence; a fixed technical experiment can support
observed behavior on exact bytes even without it. Neither supplies missing
physiological constants, exposure data or individual validation.

## Pre-code mapping precision, approved by root

The independent UI reviewer read the frozen 280-line proposal and source map and
found no material blocker in the technical-only hypotheses. Runtime identity,
supervisor proof, exact fixtures and separate execution authorization remain open.
The first implementation increment is only the new pure fixture/expectation and
strict observation-validation layer, with no R/native load or final acceptance
receipt. Its tests cannot substitute generated expected arrays for observations.

Before authoring fixtures, the independent implementer identified the missing
seventh required solver parameter. Root separately read the pinned
[DESolverProperties source](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/DESolverProperties.cpp):
all seven properties must resolve to constant parameters. Set **UseJacobian=1**
explicitly in every positive fixture and its declared malformed derivative.
This selects the source's exact equality-to-one branch; it is a declared test
setting, not a recovered historical GIM value or a convergence result.

The managed call spelling is **FinalizeSimulation**, as independently checked in
the pinned [managed Simulation API](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModel/Simulation.cs).
The proposed shorthand Finalize is not an additional callable API. The pinned
[SimulationOptions API](https://raw.githubusercontent.com/Open-Systems-Pharmacology/OSPSuite.SimModel/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModel/SimulationOptions.cs)
exposes AutoReduceTolerances and StopOnWarnings: the later collector must set and
read back false and true respectively. No reliance on a guessed XML attribute or
default is permitted. Remaining options/serializer mappings must be frozen and
reviewed before execution. No input equation, oracle, tolerance, call schedule,
resource limit or existing failed result changes in this mapping precision.
