# Explicit research preview: confirmed replacement only

2026-09-08. Refinement of the approved committed-source transition plan/interface,
not a new product mode or experiment. Root read the actual three dispatch paths,
prepared clear helper, authority/fence, snapshot publisher, local extractor,
current UI/SDK callers, all15 existing preview regressions and the separate
weak-reference retirement test before writing this plan. Independent pre-code
review is required. No runtime change is authorized while the Atlas source is
frozen for its once-only diagnostic.

R01–R51 and all six required programs remain unchanged. These legacy unregistered
previews are preserved but cannot substitute for insulin or any selected plant
experiment, enrolled people or qualified individualized physiology.

## Existing defect and smallest change

`stimulate` currently enters `authority.mutation` before dispatching `base` or
`life_system`. That advances the source before validation, construction and the
registry clear. Both candidates and their snapshots are built under authority.
`ingest_note` constructs outside the lock but still uses the eager mutation and
old clear wrapper. Rejection can invalidate the prior source. Confirmed close
uncertainty can leave memory stale. Successful previews retain prior-person
observations/actions, and old objects can finalize under locks.

Change only these three replacement branches and a small private shared preview
publisher in `aegle/server.py`, plus dedicated tests. Do not change registry,
audit, model equations, source authority, normal nonreplacement interventions,
governed patch ingestion, UI/SDK or storage policy. Reuse the independently
cleared `prepare_preview_clear` / `commit_prepared_transition` and assignment-only
manager fence. No generic transaction framework or new dependency is needed.

## Admission and original behavior retained

- Explicit operator authorization precedes extraction, registry work or model
  construction. Preserve the existing bounded duplicate/nonfinite-rejecting
  request parser and existing outer `kind`/`params` and nonempty-note requirements.
  Local preview responses use one request UUID and no-store headers; fixed errors
  must not reflect clinical text, parsed data or arbitrary exception strings.
- Existing base values remain `healthy`, `t2d`, `type-2-diabetes`; missing base
  remains healthy. Invalid base is rejected before getter/preparation.
- Existing LIFE UI/SDK modes remain `random`, `t2d_apoe4`, `carrier`, `custom`;
  missing mode remains random. Reject a nonstring or unknown mode before getter.
  Keep original custom construction/defaults/conversions in the candidate phase;
  failed conversion or construction returns a fixed preparation/input error
  before commit, never a partially replaced source. Do not introduce a new human
  phenotype or pretend the legacy generated priors are measured physiology.
- Note extraction stays on the existing local `ClinicalExtractor` path. It is
  not OpenMed admission, EHR import, consent verification or a third-party PHI
  authorization. The extracted response remains attached only to this explicit
  preview's snapshot. Nothing from its input is placed in logs or audit fields.
- Direct UI/SDK callers retain the successful state JSON, including `extracted`
  for a note preview. Confirmed-close and unknown commit outcomes are fixed503
  responses requiring inspection, never automatic mutation replay.

## Prepare outside execution locks; confirm before publishing

1. Parse/validate, allocate UUID, get registry outside authority. Under authority
   only, read the prior generation and prepare the exact audited clear. Compare
   `active_before` with in-memory selected identity in all four existing fields,
   including explicit absence. DENY_ALL cannot be bypassed with a healthy preview.
2. Outside authority/creation/manager/initialization/registry locks, run the
   original candidate factory (and original LIFE generation or note extraction),
   then take one detached candidate state. Reject None, malformed snapshot or
   missing/non-dict/non-null `profile_params` before a clear can commit. Preserve
   the candidate's own parameters; never obtain them from the later current twin.
3. Allocate a fresh generation, `model_availability(None, source_generation=...)`,
   fresh observation holder, empty action container and complete new state shell.
   Add copied availability to the snapshot. Preconstruct success/uncertainty/
   cleanup responses, including serializing success JSON, outside commit guards.
   Unsupported/nonfinite output or extracted metadata fails before registry write.
4. Under the exact original commit guard, recheck generation and four-field
   agreement. Retain old state/actions and candidate ownership through this
   interval. Invoke the actual commit helper once. Confirmed COMMITTED or
   COMMITTED_CLEANUP_UNCONFIRMED installs the new fence, complete preview state
   and empty actions before that guard exits. No old observation holder is reused.
5. Unknown completion or SELECTION_COMMIT_UNCONFIRMED installs DENY_ALL in the
   same guard; leave old inspection holders intact behind denial, do not install
   or publish a speculative preview, and do not retry. Confirmed rollback/conflict
   changes neither memory nor generation and performs no invalidation/publication.
6. Outside every lock, invalidate only the captured old generation. If cleanup
   fails after confirmed commit, retain the committed new source and report the
   existing cleanup-unconfirmed503. If already unknown, keep the unknown outcome.
   A closed execution manager remains closed and retains its cleanup ownership.
7. Publish only the precomputed, explicitly attributed snapshot after confirmed
   replacement. A concurrent later source winner must not change that snapshot's
   parameters or availability. Release retained old/candidate objects outside all
   locks in `finally`; destructor callbacks cannot run in the commit interval.

Normal nonreplacement interventions keep their existing path. The preview
branches must return before entering its eager mutation guard. Remove their old
clear/mutation implementations from `_apply_stimulus`; do not retain a second
unguarded direct replacement entry. `ingest_note` delegates the same publisher
with a candidate factory; no extractor executes before audited preparation.

## Red-first evidence and independent acceptance

The retained15 preview tests and base weak-finalizer regression already expose
the old behavior; repeat them under the existing private45-second ASGI wrapper.
Add only missing authored cases in a dedicated module after independent review:

- All three branches: preparation failure, invalid snapshot/serialization,
  late generation and exact selected-record mismatch at capture/commit, confirmed
  cleanup failure and unknown outcome retaining old inspection holders.
- True absent active record with no selected person; reject inconsistent
  one-sided absence rather than treating it as healthy permission.
- Ready, modeless and closed-manager old sources preserve or retire the correct
  holders according to outcome; no old-person observations/actions in success.
- Later winner between commit and snapshot publication; current source remains
  the winner while the old operation publishes only its own detached result.
- Original constructor/extractor work and JSON serialization occur before commit
  and outside all guards. Unauthorized/invalid requests never obtain the registry.
- Weak ownership checks cover all three replacement families, not only base.
  Preserve all existing activation/binding/startup/fence/snapshot assertions.

No real model, extractor, participant data, listener, browser, child or numerical
worker is run in these fixtures. Tests keep the actual authority, exact guard
boundary and manager semantics; authored factories/sinks are named explicitly.
Actual registry-to-preview integration and UI/terminal acceptance remain separate
required gates. No six-program or whole-product completion follows from this fix.

## Durable lesson

An explicit research preview is still a source replacement. It must preserve the
prior selected person's state on rejection and retire that state only after a
confirmed clear. A pleasant healthy default is not recovery authority for an
uncertain registry. Local written review/lessons remain the fallback while the
requested CE/gbrain/context7/sequential-thinking tools are unavailable.

## Independent pre-code review and root decisions

The independent UI/contract reviewer read this complete plan, the original three
server dispatch paths, prepared-clear/commit and source-authority boundaries,
availability and snapshot publication, the retained15 preview tests and weak
retirement fixture, and actual legacy UI/SDK/terminal and current Cendos consumers.
This was local source inspection only: no test, constructor, registry operation,
HTTP call, browser, service or native process was run. No runtime/test file was
changed. The confirmed-clear, exact-generation and outside-lock retirement
direction is cleared with the following two refinements, accepted by root before
implementation:

1. These three candidate previews always publish `READY` / `reference_preview`.
   Therefore their detached `profile_params` must be a dictionary; **null is also
   rejected before commit**, correcting step 2's broader dict-or-null wording.
   Do not alter generic `_snapshot_twin` support for a null unavailable snapshot
   or invent missing parameters. Add a null rejection case for each family.
2. Capture and final-guard conflict/uncertainty responses retain this operation's
   allocated UUID and no-store headers. Do not let those errors fall through the
   existing global handlers, which generate another UUID for a generation
   conflict or omit it for selection uncertainty. Add exact response/request-ID
   equality checks for capture rejection, late conflict and unknown completion.

The current Cendos assay obtains and rechecks an authenticated source envelope;
it does not use the notification snapshot as calculation authority. Retaining an
older completed operation's own detached publication after a later winner is
therefore not permission to replace that winner or borrow its profile parameters.
Keep the later-winner source and publication regression as written.

### Required cross-product client work remains open

The following are concrete existing consumer gaps, not claimed repaired or
accepted by this server-only packet. Root retains them as required next client
implementation and acceptance work in the master scope; they are not removed or
silently deferred:

- The legacy base selector assigns every parsed response to `S` and calls
  `render`, including a503 error object. It needs status/shape-aware handling that
  does not present an unconfirmed replacement or stale numerical state as current.
- The shared legacy `stim` helper blocks `life_system` even when an explicit
  preview should be available from an observations-only source. Preserve the
  distinction between unavailable numerical perturbations and explicit preview
  replacement; do not weaken source-selection uncertainty denial.
- Attached SDK `patient` calls use legacy `_post`; a503 raises `HTTPError`, which
  the terminal's typed-client-error handlers do not catch. The note/LIFE UI paths
  also show generic service-failure messages rather than inspect-required outcome
  metadata. Preserve once-only submission and require safe typed uncertainty /
  committed-cleanup handling and confirmed-state inspection, without POST replay
  or in-process fallback.

No end-to-end preview usability, new biology, six-program completion or broader
product acceptance follows from this plan review. The Atlas product/harness
freeze and all retained diagnostic failures remain independent evidence.

Root separately repeated the retained15 preview cases plus both retirement cases
against the unchanged current server: **16 failed, 1 passed in 1.70 s**, private
root `ipkc6qu9`, exit1, unexpected I/O0 and one refused Git metadata attempt.
Only activation retirement passed; all three preview families and base retirement
remain RED. This is root's reported baseline, not an independent execution by the
plan reviewer, and does not replace the additional refinement regressions.

## Approved test-author inventory before new code

Create only `test_confirmed_preview_publication.py`; preserve the existing15
preview and activate/base retirement tests. Reuse their client/request helpers,
not a replacement publisher. The new fixture uses actual ModelSourceAuthority,
original commit guard and a no-background ExecutionManager with the existing
no-I/O owner helper. Factories/extractor are inert and called through actual HTTP
dispatch; bus sinks record while `_snapshot_twin` stays real. A delegating real
JSONResponse renderer observes candidate serialization outside locks.

The proposed67 parameterized cases cover only missing assertions:

- 11 output cases: null parameters for all3 families; four representative malformed
  state/missing/list-parameter outputs; nonfinite serialized state for all3;
  nonfinite note extraction metadata. All reject503 REGISTRY_STORAGE_UNAVAILABLE
  before commit; generic modeless snapshot null support is not changed.
- Six capture cases: preparation rejection and DENY_ALL for all3, preserving the
  one allocated request UUID/no-store. Eight four-field mismatch cases distribute
  capture/final phases across all3 branches; three late-generation cases preserve
  the exact preparation UUID and do not commit.
- Ten holder/ownership cases: unknown outcome on ready/modeless old state for
  all3; modeless→confirmed preview; real closed-manager committed/rollback/unknown
  paths, preserving owners until explicit shutdown retry.
- Three explicit-absence cases; three later-winner cases with the actual explicit
  snapshot; nine preserved base aliases/LIFE modes/default dispatch cases.
- Six invalid-input cases: invalid base/mode before getter and custom conversion
  failure only after preparation; three unauthorized cases before any factory.
- Five weak-lifetime cases: old models/actions on LIFE/note success and failed
  candidates on all3 rollbacks. Finalizers record lock state only, never native
  cleanup. No test-held strong owner may conceal the tested retirement interval.

Root confirmed the existing fixed code choices before authoring: candidate
projection/serialization failures503; invalid admission and ValueError/TypeError
candidate construction422 INVALID_INTERVENTION/INVALID_NOTE; capture/final source
conflict409 and selection uncertainty503, all with this operation's UUID and
no-store. The test module pins only server.uuid4 for response correlation; source
authority generation creation remains actual. Run once against frozen3d521a… in
the approved private45-second ASGI-compatible refusal wrapper and report real
RED without claiming later assertions were reached if an earlier boundary fails.

### Test-author frozen RED handoff

The new module is now authored and frozen:576 lines, SHA256
`c610ce3bd603c640d28e6f9c028e3488fa75c85bb52cd5451f9784ed92bcbab7`.
The first approved private45-second run selected only this module: **64 failed,
3 passed,3 existing warnings in1.88s**, exit1. Private environment:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-nw2ewnpn`.
The3 passing cases are unauthorized base/LIFE/note preservation. Unexpected
network/child/model attempts0; exact optional Git metadata lookup refused1.
Server remained
`3d521a029bccf5d9069a4e78806d40fbf895aca3b3cf6b6f370ad9500645676d`.

Used the same no-I/O ASGI wrapper recorded in the real-binding integration report,
with only the selected module changed to
`livemorebio/tests/test_confirmed_preview_publication.py`; cache/auto-plugins and
bytecode disabled, internal socketpair allowed, real model constructors refused.
No existing test/runtime source, service, operational store or browser was changed.
Later assertions are prospective where old eager mutation or factory-before-audit
fails first. The separate LIFE/note weak probes directly observed old-model
retirement under authority and retained old actions, not merely a missing helper.
This is the test author's RED evidence, not independent implementation acceptance.
The original15 preview/base-retirement baseline remains unaltered.

## Independent implementation finding: preparation rollback uncertainty

The independent reviewer repeated84 cases successfully at server ca5113ee… but
found one uncovered real exception path. `_selection_read_access` can raise
SubjectRegistryError with code SELECTION_COMMIT_UNCONFIRMED when its preparation
read/audit rollback cannot be confirmed. The preview outer adapter incorrectly
maps this through generic422. The existing capture-denial tests cover the source
authority exception, not this registry exception.

Root accepts the finding before correction. Add one case for each base/LIFE/note
using this exact preparation exception, and assert503, the same request UUID and
no-store, no candidate/extractor, no commit, no invalidation/publication and exact
old state/actions/generation preservation. Do not install DENY_ALL here: the
selected clear was never attempted. Run these three RED first, then add only the
fixed uncertainty code to the outer503 mapping. Do not weaken actual commit
uncertainty's DENY_ALL behavior or alter other registry/authority exceptions.
Independent re-review is required before clearing this runtime packet.
