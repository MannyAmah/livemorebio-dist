# LIFE continuous virtual execution — proposed implementation contract

Date: 2026-09-08. Parent: [full R01–R51 recovery plan](2026-09-08-full-scope-recovery-plan.md). Preserved source: `83994425f2a3884188b1e3ee494241eba5c272f5`.

Status: **NUMERICAL PACKET INDEPENDENTLY REVIEWED; consumer implementation under review.** Root approved the complete architecture and exact numerical packet before implementation. The independent numerical result and subsequent implementation records below supersede the original proposed state; end-to-end services, browser acceptance and the 30-minute soak are not complete. No physical qualification is claimed. No existing service, experiment, stored measurement or installed pointer was changed while preparing this proposal.

The engineering-plan review skill informs the ownership, failure-path and test design. gbrain, context7 and sequential-thinking tools are unavailable in this session; local source and existing solution records are the explicit fallback. Before changing native numerical calls, implementation must inspect the exact locked dependency's primary documentation and satisfy the biological change contract; this plan is not a substitute for that source review.

## 1. Requirement and acceptance boundary

Implement R04's genuinely advancing, engine-authored virtual LIFE counterpart, with the shared device/timing/quality contract in R29, selected-twin association in R30, and provenance-preserving observation path in R31. Contribute explicit native-clock state to R07/R08/R24–R26 and browser/SDK/restart evidence to R45/R47/R48. No requirement in R01–R51 is removed or closed by this packet.

The user must be able to select an admitted source, start numerical execution, see newly calculated states reach LIFE and the matching Biology view, pause, resume, stop, switch source and recognize stalled/disconnected data. A real physical source updates only from actual admitted packets. Replaying a saved trace remains useful, separately labeled functionality; replay is never renamed continuous execution or acquisition.

LIFE remains the dedicated RevB0 sensing/assay product, not a bundle of external wearable APIs. Numerical equivalence to its sensors is a separate, still-open observation-model and independent-physical-evidence obligation. The implemented source coverage must be explicit; restoring one executable signal does not close the full sensor, multiscale, insulin or five-candidate programs.

## 2. What the preserved code actually supports

| Source inspected | Implemented behavior | Consequence for this packet |
|---|---|---|
| `aegle/runtime.py`, `AegleTwin._recompute()` | Runs metabolic `simulate(hours=14)` from basal initial state; derives cardiac coupling and resting HR using the mean of the entire result; computes a fresh cardiac run. Every stimulation recomputes. | It is not a stateful online integrator. Do not call it repeatedly and call that continuation, or use future whole-trace summaries as causal live inputs. |
| `engines/metabolic/glucose_insulin.py`, `_rhs()` / `simulate()` | Explicit three-state ODE: glucose G (mg/dL), remote insulin action X (1/min), insulin I (uU/mL); native time minutes. LSODA integration always starts at `(Gb, 0, Ib)` and time zero. Meal appearance depends on absolute elapsed time since every admitted meal. | Add an interval adapter carrying the complete state and absolute model time, without changing existing equations or legacy `simulate()` outputs. Preserve event history needed by the RHS. |
| `engines/cardiac/action_potential.py`, `CardiacCell.simulate()` | Constructs a new Myokit simulation, pre-paces it, returns a single paced beat's membrane voltage and intracellular calcium; it does not expose a continuation handle or the complete final state. | Add a distinct execution adapter that owns a cloned model and one continuing simulation. A displayed old beat cannot initialize the missing full cellular state. |
| Installed locked Myokit source, `_sim/cvodessim.py`, `run()`, `pre()`, `state()`, `time()` | `run()` advances internal state and time; `pre()` changes state/default state without advancing the public time. These APIs were inspected, not exercised. | In-memory continuation is technically supported by the dependency, but unimplemented in this product. Record pre-pacing as initialization, not acquired human time; benchmark numerical continuation independently before enabling it. |
| `engines/cardiac/heart_rate.py` | Hand-authored coefficients, whole-trace mean/minimum and horizon-normalized circadian term; not a continuously integrated autonomic or ECG model. | Preserve historical calculations as recorded prior outputs. Do not manufacture advancing HR/HRV from these helpers or treat paced ventricular-cell voltage as surface ECG. A source-backed autonomic/ECG observation model remains an explicit R08/R29 dependency. |
| `life_patch/stream.py`, `SyntheticPatchStream.sample()` | Selects indices from a precomputed metabolic trace and repeats one HR value; holds a mutable twin reference. | Preserve compatibility but do not use for the new source. Do not reconnect the legacy calibration helpers in `driver.py`. |
| `aegle/server.py`, `/api/patch`, `/api/state` | Displays downsampled recorded traces. Existing coherence token hashes view state including observations and process-local twin identity. | Public/downsampled display responses are not full-state checkpoints. A fresh observation must not invalidate its own numerical source: create a separate stable model-source generation, not an execution identity based on the changing view token. |
| `life_patch/protocol_v3.py` | Explicit mode, manifest, provenance, acquisition/receipt clocks and minute-based model context; strict existing signal catalog. `modeled` plus caller-supplied IDs is not itself proof of engine authorship. | Preserve v2/v3 canonical bytes. Require trusted source lookup and exact committed-frame binding for the new engine path; do not promote arbitrary prepared uploads into that path. |
| `life_system/service.py`, `_accept_patch()`; `gateway.py` | Registered-device, durable replay/clock admission, signed LIFE forwarding and observation-only attachment already exist. Generic `patch.latest`/`twin` snapshots also exist. | Reuse admission; never select the new source from those mutable global snapshots. Existing journal AAD, hashes, replay and command safety behavior stay intact. |
| `alignment.py`, `observation_view.py` | Frozen, technical identity mapping only; physical transfer remains closed. Display recency is not connectivity or assay validity. | Do not relax residual eligibility to obtain a green comparison. Add independent engine and delivery freshness, not a false physical-validation status. |

Prior art applied: [observation integrity](2026-09-08-observation-integrity-corrections.md), [review isolation incident](2026-09-05-review-stack-isolation.md), [run-stage inspection](2026-09-08-run-stage-and-assay-inspection.md), and [biological model-change contract](../BIOLOGICAL_MODEL_CHANGE_CONTRACT.md).

## 3. Smallest complete architecture

Keep the existing Aegle and LIFE services. Add bounded internal modules, not another service or frontend framework. Separate the biological executor from the virtual-device observation operator so future admitted insulin/candidate/organ workers can expose the same execution contract without inventing their mechanisms here.

```text
Explicit selected twin/run/member + expected source generation
  → atomic admission/freeze of full model inputs and initialization
  → Aegle execution owner → numerical worker → committed EngineFrame
                                                  ↓ exact execution/frame ID
                      LIFE source-bound device session reads authenticated frame
                                                  ↓ versioned observation operator
                      registered virtual manifest → existing gateway + journal
                                                  ↓ signed LIFE admission
                      matching Aegle observation projection + Patch/Atlas/Biology

Physical firmware packets → existing physical admission/QC/custody path ──────┘
Saved trace → explicit replay view (no advancing executor; no new acquisition)
```

Aegle is the sole owner of numerical execution state. LIFE owns device registration, device-session consumption and telemetry admission. The browser owns only selection and display; it cannot send the measured/model output values for a continuous session. LIFE fetches frames from the explicitly configured, authenticated, build-checked Aegle service by execution ID and cursor. It does not discover a source from `patch.latest`, `bus.get_snapshot("twin")`, current UI cursor, profile name or “latest run.”

The source and frame records below are an execution boundary extending existing typed selection/model/run contracts, not a second shorter authority. Use references into the existing subject and protocol registries; do not duplicate their membership, consent or lifecycle authority. Existing frozen runs lacking complete state remain inspectable/replayable, but cannot resume by guessing hidden states.

### 3.1 Proposed typed interfaces

All identifiers and collections are bounded; all numbers exclude booleans and must be finite. Exact canonical content hashes use the project's established deterministic JSON convention. PHI-like payloads never appear in logs or unauthenticated health.

| Record | Required contents and invariants |
|---|---|
| `ExecutionSource` | Server-issued `execution_id`; immutable `source_snapshot_hash`; parent source/run/checkpoint references; subject/twin and admitted version; complete `{cohort, member, run, condition, stage}` selection (explicit null/not-applicable where appropriate); model source/asset hashes, adapter version, build fingerprint; state-variable schema with units/compartments; full initial state, native axis origin/unit; admitted immutable parameters, schedule and provenance; initialization/pre-pacing method; numerical tolerances and admitted time domain. No caller-supplied result arrays. |
| `ExecutionPolicy` | Explicit wall/model speed and frame period, bounded native advance per job, end-of-domain policy, frame/byte/storage limits, solver deadline and maximum queued work. These are numerical/display policies, not physiological parameters. UI shows the chosen ratio; no concealed acceleration. |
| `EngineFrame` | Server-issued monotonic frame index and canonical hash; execution and source hashes; preceding committed frame/checkpoint hash; source generation; complete selection; native start/end time and quantity/unit/compartment; finite outputs and full-state checkpoint reference; producer build/adapter identity; actual generated UTC and producer monotonic clock; numerical status. A failed integration produces failure metadata, not a value-filled frame. |
| `VirtualDeviceSession` | Session ID/revision; explicit execution/source/subject binding; registered virtual device and manifest hash; released operator ID/hash; selected compatible channels; last consumed frame/hash, pending exact envelope and last accepted envelope; lifecycle and delivery status. No implicit reassignment to another active twin. |
| `SourceStatus` | Execution state, transport state and last accepted observation are distinct. Include last committed model time/frame, last computation time, last durable admission/receipt time, delivery lag and bounded error code. Status does not repeat biological values in operational logs. |

Suggested module methods, to finalize in root review:

```text
ExecutionManager.prepare(selection, expected_source_generation, model_contract_id, policy)
ExecutionManager.start(execution_id, expected_revision, idempotency_key)
ExecutionManager.pause/resume/stop(execution_id, expected_revision, idempotency_key)
ExecutionManager.frames(execution_id, after_frame, limit)
NumericalAdapter.initialize(admitted_source) → full checkpoint
NumericalAdapter.advance(checkpoint, native_end) → candidate frame + checkpoint
VirtualSessionManager.start(execution_id, source_hash, device_id, operator_id, expected_revision)
VirtualSessionManager.pause/resume/stop(session_id, expected_revision)
ObservationOperator.project(committed_frame, registered_manifest) → candidate v3 measurement
```

Proposed authenticated API families: `/api/executions` and `/api/executions/{id}/{start|pause|resume|stop|frames}` on Aegle; `/patch/virtual/sessions` and `/patch/virtual/sessions/{id}/{pause|resume|stop}` on LIFE, with same-origin Aegle proxies for browser/SDK use. Exact endpoint names may be aligned with the existing execution API during review; the ownership, authorization and payload restrictions are mandatory. Creation takes source/model IDs and expected versions, not measurements, arbitrary Python, executable expressions, paths or user-picked service URLs. No mutation through GET. Controls use strict duplicate-key-rejecting JSON and idempotency/conflict responses.

### 3.2 Source freezing, selection and concurrency

1. Root-owned runtime integration supplies one guarded capture operation. Validate active registry record, complete selection, expected model-source generation and registered binding; capture the actual full model input/state under the same guard. Detach mutable lists/objects before hashing. A before/after view hash alone is not a substitute for the guarded operation.
2. Introduce a model-source generation advanced by initialization, intervention, model release or selected-subject change. Observation-only attachment does not change frozen model inputs or this generation. Bind the UI's view generation separately to reject stale responses. Never use object `id()` as persistent scientific identity.
3. The execution references its immutable source, not the live `AegleTwin` object. Start at an explicitly admitted initial state or a complete checkpoint from this execution family. Neither the final point of a displayed 840-minute curve nor interpolated G/I alone supplies the missing X/cellular states.
4. One guarded source-change hook pauses/detaches the former device session before the new subject/model becomes active. Await or fence in-flight completions with a generation token; late old-source frames can remain in their original execution archive but cannot attach to the new twin or view. The parent runtime mutator paths must all use this hook, not only the dropdown.
5. One executor owner per local execution uses a process lease/lock plus durable revision checks; concurrent start requests return the same admitted execution or a conflict. Numeric solver objects do not run concurrently on shared mutable state. Existing gateway POSIX locking remains the device-sequence authority; no multi-host/distributed guarantee is introduced.

## 4. Numerical continuation and observation contracts

### Metabolic adapter: existing equations, new stateful execution

- Preserve `GlucoseInsulinModel.simulate()` and its historical result contract. Add an explicit interval method or separate adapter using the same `_rhs` and immutable parameter copy, starting from `(G, X, I, absolute_t_min)` and returning a candidate next state only after successful integration and finite/domain checks.
- Do not reset X, insulin or model time at every tick. Use absolute meal-event times, retaining the admitted schedule and all tails required by the existing meal appearance equation. Bound schedule size at admission; do not discard meal effects to keep a display ring buffer small.
- Default source initialization is explicitly the admitted basal initial state at model T0, not the user’s current wall-clock physiological state. A source contract must declare the evaluated horizon; reaching it completes the execution. It never wraps to T0. Extension beyond a source's admitted domain requires a reviewed contract/new execution, not an automatic endless day.
- Each job advances only the next requested bounded interval. Restarting LSODA at a chunk boundary with the complete state is numerical continuation of the equations, not preservation of internal solver history; chunk-size/tolerance equivalence tests must quantify the difference. No rerun of the whole day per frame and no precomputed future curve used as online output.
- G, X and I are exposed as modeled biological state in their native units. Existing v3 admits only `glucose_mgdl` from this trio. The numerical observation operator uses G exactly with `biofluid=plasma`, the declared model compartment, no physical sampling site and `calibration_status=not_applicable`. Its quality pass means software/numerical checks passed, not assay calibration. Values outside the existing signal domain yield an explicit unprojectable channel; do not clamp a model failure into a plausible sensor result.
- This identity operator is a virtual numerical probe, not sweat/interstitial/blood transfer, glucose electrode chemistry or a claim that RevB0 measures insulin. I and X remain typed engine outputs in Biology/LIFE's numerical-source view; they are not slipped into the device's signal catalog.

### Cellular adapter: independently advancing native cell state

- Clone the pinned cell model per execution. Record all model modifications, constants, stimulus protocol and complete initial state. Compile/create the native simulation once per worker; pre-pace only as explicitly admitted initialization, then retain the continuing simulation object across `run(duration)` calls.
- Keep membrane voltage (mV), intracellular calcium (native model unit verified from the pinned asset), full-state checkpoint and cellular milliseconds. Do not connect cardiac milliseconds to whole-body minutes merely because both are time. An explicit declared execution scheduling ratio controls display/compute pacing; a physiological cross-scale coupling needs its own released contract.
- The cardiac worker's fixed pacing protocol is an input, not a measured heart rate or an autonomic model. Membrane voltage is not `ecg_mv`. No derived ECG, HRV, SpO2 or mechanical cardiac output is emitted without its own supported observation model.
- The existing whole-day hyperglycemia/HR heuristic is not applied to future frames. Preserve it only in the recorded legacy calculation, with its original provenance. New causal metabolic-to-cardiac, autonomic, PK and other couplings are named scientific dependencies under R07/R08/R10; another engine packet must supply equations, applicability and source benchmarks before enabling them.

### Source compatibility and v3 binding

- The continuous path reads only committed frames from its authenticated execution source. Verify source/selection/quantity/units/model/native time/frame predecessor and monotonicity before projecting. A caller's v3 `provenance=modeled` plus matching-looking IDs remains a declared prepared payload unless the trusted execution lookup verifies the exact frame and value.
- Preserve old prepared uploads and replay as separate choices; label their engine authorship unverified unless a stored engine frame resolves and matches. Never set `execution_running` or `engine_verified` from the provenance string alone.
- Existing minute-compatible v3 model context can bind `prediction_id` to an immutable emitted-frame prediction record, `condition_id` to the selected condition, `model_id` to the pinned model and `mapping_id` to the released numerical identity operator. The source catalog resolves full execution/snapshot lineage. Do not add unsupported fields to hash-covered v3 objects or change v2 bytes. A new native axis not representable honestly by this v3 mapping stays in the typed engine frame until a separately reviewed additive wire contract is needed.
- Virtual manifest declares only genuinely projected capabilities, virtual software version/hash and `hardware_present=false`. That hash is virtual adapter identity, not a hardware firmware qualification. A manifest capability change requires the existing new-device-identity rule; no in-place capability widening.
- Scalar virtual acquisition UTC/monotonic timestamps represent when the numerical probe sampled the committed frame, not simulated physiological elapsed time. Use a zero-duration scalar acquisition window with actual monotonic/UTC acquisition and actual LIFE receipt. Native model time is separate; accelerated model time must never become future UTC or a waveform's wall-clock sample period.
- A delayed unsent frame cannot be sampled later merely to obtain a fresh timestamp. Check the producer generation age and last-consumed cursor; expired backlog remains historical/unadmitted with its reason. Reconnection resumes from an explicit execution boundary, not by replaying old frames into the live channel. An already-created envelope always keeps its original acquisition timestamps.
- Keep `align_observation()` physical transfer gate closed. Engine-to-own-identity-probe agreement is software conformance, not independent residual evidence; no validation outcome or calibration authorization is created. Existing evidence conversion remains synthetic baseline input only. Learning proposals/releases and authorized application/rollback remain the separate R31 program.

## 5. Lifecycle, clocks and failure semantics

Two related lifecycles avoid making a network failure a biological outcome:

```text
Execution: prepared → admitted → running ↔ paused → completed | failed | cancelled
Device:    unbound → bound → streaming ↔ paused → stopped
                              ↘ stalled / admission_uncertain / source_changed
```

| Action/event | Required behavior |
|---|---|
| Start | Validate source, model readiness and device binding before starting the owned task. No automatic start on page open, source selection, installation or history recall. Disable duplicate UI submit; idempotency works across uncertain HTTP response. |
| Tick | Commit one validated numerical advance, then expose it to LIFE. Heartbeat/SSE alone never advances native time or freshness. No arbitrary jitter, noise, flat placeholder or requestAnimationFrame-created biological sample. |
| Pause | Stop scheduling new advances and device samples; fence the in-flight job. A bounded completion may be archived under its old generation but cannot appear after the acknowledged pause cursor. Model time freezes; wall clock continues. Show pending/paused until the acknowledged boundary is known. |
| Resume | Resume from the last committed full state and the same admitted source, with a new scheduler wall-clock anchor. Do not integrate the paused wall interval, reset model time, replay old samples as new or catch up an unbounded backlog. |
| Stop | Acknowledge last committed frame, cancel/terminate only the owned worker within its deadline and retain archive/journal. A subsequent Start is a new execution or an explicit checkpoint fork; no erase/reuse of sequence history. |
| Switch twin/run/member/condition/model/device | Explicit stop/pause fence and fresh binding. Clear incompatible visible channels and stale frame cursors. No late-response leakage and no automatic following of the global active twin. Switching physical/virtual never changes another packet's source class. |
| Aegle/LIFE outage or timeout | Mark transport unavailable and retain exact pending frame/envelope. Show last accepted timestamp and model time without making it “live.” Pause the producer under bounded backpressure; do not generate an unlimited outbox. |
| Admission response lost | `admission_uncertain`, not “not admitted.” Resolve by exact source-frame/envelope hash against durable LIFE admission. Retry uses identical bytes, ID, sequence and acquisition time; never stamp the same model frame with a fresh acquisition time to evade replay. The new session endpoint may return the original exact-match receipt idempotently; generic replay rejection remains unchanged. |
| Clock rollback/discontinuity | Fail/stall under existing gateway ordering rules. Do not widen uncertainty, retire/reuse a session ID or advance captured time to make admission pass. Resume only with an explicit valid clock/session transition preserving sequence and UTC ordering. |
| Domain end, solver failure, invalid state, unsupported channel | Stop/complete/fail according to the declared contract, retain the last valid frame and a fixed error code. No silent positivity clamps, zeros or substituted channel. Display already committed partial history as incomplete when execution failed. |
| Service restart | No automatic numerical resume or acquisition. Mark prior running executions interrupted; inspect durable source/frame/admission records. An explicit Resume verifies versions, last full checkpoint and source identity. If exact native restart is unsupported, offer a labeled reproducible checkpoint fork rather than claim bit-identical continuation. |
| Physical source | No generated fallback. Preserve registered firmware/attestation, consent/custody/QC and actual packet clock rules. Recent accepted packets do not prove continuous hardware connection. Command transport failures cannot create successful receipts. |

Freshness UI presents `execution advancing/paused/completed/failed`, `transport available/unavailable`, and `last accepted sample age` independently. Example scheduling policy for review: 1-second delivery target; mark producer stalled after three missed scheduled frames plus the declared job deadline. This is a proposed software policy to test, not measured latency or biological validity. Preserve the existing separately labeled 60-second observation display-recency policy. Old data retains its original acquisition/receipt time during pause, reconnect and replay.

The browser's combined Start/Pause/Resume/Stop orchestrates these two service lifecycles explicitly; it does not imply a cross-service atomic transaction. Start prepares the source and bound consumer before enabling the producer. Any partial failure records which operation succeeded and fences delivery; compensation stops only this operation's owned work and never deletes its record. Pause acknowledgement names the final delivery cursor and executor boundary. Tests cover successful control followed by failed status refresh, and failure between every pair of service calls.

## 6. Bounded resource use, persistence and PHI

- One active numerical producer per selected local execution; one in-flight job, one pending delivery envelope, bounded subscribers. No timer-per-widget or solver-per-browser-tab. Cardinality is configured and tested rather than inferred from CPU availability.
- Proposed default display ring: at most 600 scalar frames per channel; every frame and subscriber queue also has a byte cap. Native cellular frames use at most the wire limit of 4096 samples per block and an explicit overall byte budget; do not accumulate adaptive solver logs forever. These are acceptance targets, not reported benchmarks.
- Durable full-state checkpoints and frame chunks use an encrypted, versioned execution store under a new explicitly configured `LIVEMORE_EXECUTION_STORE` beneath the data root. Reuse owner-controlled encryption utilities and safe file checks, with a distinct record AAD, instead of copying subject-registry records or saving pickle/native executable blobs. Opaque indexes only; no cleartext parameters, subject labels or observations.
- The protected-storage requirement follows data sensitivity, not physical/virtual evidence class. Existing gateway code encrypts based on nonvirtual mode; the new engine-authored path must require a storage key and encrypt its journal/outbox records too, including modeled outputs derived from a real-human profile. Preserve reads of old records and the existing journal AAD/canonical envelope hashes. Do not reclassify virtual outputs as physical merely to obtain encryption.
- Proposed per-execution storage quota is 256 MiB with a pre-write quota check. Quota exhaustion pauses with a retained receipt and actionable error, not deletion, silent eviction or a corrupted final checkpoint. Final quota and frame sizes require benchmark review. Persisted execution evidence is not deleted automatically to satisfy a buffer test.
- LIFE session cursor/outbox is durably versioned, encrypted and bound to exact frame/envelope hashes. JSONL admission append and cursor commit are not one atomic transaction: recovery must reconcile an appended record before advancing/retrying the cursor. Duplicate start/ack recovery tests are required. Reuse the gateway's locked durable sequence authority; a separate in-memory counter is insufficient.
- New continuous consumers must not repeatedly load the entire growing telemetry journal. Consume admitted events/exact receipts and bounded execution-page cursors. Any history helper added for exact receipt recovery must stream/index with bounded memory and preserve corruption/replay checks; never rewrite or truncate the existing journal.
- Add every new store, SQLite sidecar, outbox, lease, native compilation cache and scratch path to `prepare_review_environment()` and actual-consumer isolation tests. Override hostile inherited values, require owner-only safe paths, and never reuse the installed/operator signing or data identity. Worker launch uses the intended interpreter and explicit checkout/import path, `-B`, sanitized environment and closed parent descriptors.
- PHI-like source/frame/packet reads and lifecycle mutations require the existing operator authorization and access-audit convention. Audit records carry opaque IDs, action/result and bounded error category, never values, names, notes or raw payloads. API errors are fixed strings/codes, not native solver/decoder text. New public health exposes only readiness/build/status counts; no stored source metadata.

## 7. Test-first implementation order and ownership

No implementation until root accepts this proposal and the numerical/source test packet. No test uses existing ports/stores or requires unapproved physical hardware.

| Order/owner proposal | Files and seam | Red-first acceptance |
|---|---|---|
| 1. Root runtime/context integration | `aegle/server.py`, `aegle/runtime.py`, existing subject/run selection consumers; minimal shared source-capture/generation seam | Switching subject or mutating model during capture cannot bind mixed inputs; observation-only updates do not invalidate the execution source; stale worker cannot attach after pause/switch. Root owns these files. |
| 2. LIFE/execution owner after review | New `aegle/execution.py`, `aegle/execution_store.py`, narrowly scoped numerical adapters; minimal additive seam in metabolic/cardiac modules only after source review | Typed/full immutable source, strict admission, complete state continuation, bounded job and frame lifecycle; legacy constructors/results unchanged. Independent science reviewer grades numerical behavior, not the maker. |
| 3. LIFE owner coordinated with root | New `life_patch/virtual_execution.py`; existing `life_system/service.py`, `gateway.py`, `observation_view.py`, evidence only where needed; root integrates Aegle proxies | Fetch exact engine frames; no arbitrary numeric body/global bus; v3 manifest+clock+source binding; exact receipt retry; all existing v2/v3 hash/replay/auth/security tests remain green. Root and LIFE owner must explicitly hand off shared files before editing. |
| 4. Root review infrastructure owner | `tools/run_review_stack.py`, `tools/run_review_tests.py`, `test_review_isolation.py`, packaging and CI paths | Actual consumers all use fresh private roots; outside-checkout installed imports/assets; no production pointers, cache or credentials touched. |
| 5. UI owner | `console/patch.html`, shared source controller/view module and matching Atlas/Biology consumers; no competing direct UI edits | Source chooser and start/pause/resume/stop are functional; clocks/source/freshness visible; independent recorded replay preserved; bounded buffers and late-source rejection. |
| 6. Root SDK/docs owner | Existing SDK/CLI command family and documentation | Same explicit preparation/start/status/pause/resume/stop behavior as browser; no credentials in examples; old detailed guide retained. |
| 7. Independent reviewer + UI QA owner | Dedicated new unit/integration/browser tests and exact build-linked artifacts | Reviewer is not the implementing maker; actual advancing values/native clocks and acceptance failures inspected in a new isolated stack. No screenshots-only substitute for functional testing. |

Suggested dedicated tests: `test_continuous_execution.py`, `test_execution_store.py`, `test_virtual_execution_admission.py`, `test_continuous_life_integration.py`, plus frontend controller tests using the existing local JS test harness. Test names can follow repository conventions; coverage cannot be dropped when splitting ownership.

### Required regression and scientific/numerical matrix

| Group | Required tests / visual evidence |
|---|---|
| Source/authorship | Actual engine frame vs arbitrary numeric upload; source ID/hash spoof; missing full state; wrong subject/member/run/condition/stage/unit/compartment/model/native axis; schema extras/duplicate JSON/bool/NaN/oversize; signature/issuer/source lookup failure. A label alone never authorizes engine status. |
| Metabolic continuation | Basal/no-meal invariance, healthy and existing T2D reference contracts, meals spanning a chunk boundary, all three states carried, absolute clock not reset, unchanged admitted parameters, finite/domain failures, no future-summary dependence. Compare monolithic and multiple chunk sizes at matched times. Preregister tolerances before seeing output; keep current LSODA settings and choose quantity-specific absolute/relative test tolerances justified by convergence, not by adapting them to a failing test. |
| Cardiac continuation | Full state size/order matches pinned model; per-execution cloned constants; initialization/pre-pacing clocks explicit; contiguous split vs monolithic native simulation under recorded tolerances; no reset every beat; phase continuity and bounded logged samples; failure/cancel/native restart behavior. ECG/HR/HRV remain unavailable without a released operator. |
| Lifecycle/concurrency | Double start, concurrent worker claim, pause during job, resume with wall gap, source switch during lookup/solve/HTTP response, stop deadline, disconnected/reconnected subscriber, process restart, stale revision, changed source asset. Replay/scrub does not run the solver or admit new samples. No hidden catch-up or T0 wrapping. |
| Admission/persistence | Two LIFE workers, conflicting sequence, exact same-frame retry after append-before-response/cursor crash, mismatched retry hash, missing/truncated/corrupt journal, unsafe symlink/hardlink/owner/sidecar, disk full/quota, snapshot/cursor mismatch. Preserve all prior journals and v2 canonical hashes. |
| Evidence/physical separation | Modeled source on a REAL_HUMAN-derived twin remains modeled/synthetic evidence; modeled input cannot self-calibrate, become a validation outcome or bypass consent. Inferred/raw physical data remain separately classified. No actual packet means no physical values/connection claim. No manufactured skin temperature, SpO2, ECG, HRV or concentration transfer. |
| Performance | Fake-clock rapid tests plus a real 30-minute isolated technical soak at a declared speed within the admitted model domain; bounded frame count/bytes, pending work, subscriptions and storage; measured CPU/RSS, cadence and cancellation latency. End-of-domain completion is visible, not repeated to make the soak appear continuous. If two native axes cannot meet the intended cadence, expose measured lag and obtain a reviewed scheduling correction, not prerecorded fallback. |
| UI/SDK/E2E | Fresh empty install → create/select reference twin → admit source → bind compatible virtual device → start → newly calculated native time/value visible in LIFE and same-context Biology → pause → resume → switch → stop → inspect exact immutable record. Repeat failure/offline/unauthorized/long-name/mobile/keyboard paths. Independently capture screenshots and real interaction video; verify source, clock, value and frame hashes across views. |

## 8. Explicit dependencies and completion record

Before numeric implementation, approve the exact interval/state/checkpoint contract and its source/numerical tolerance packet. This proposal preserves existing equations; it does not certify their parameter provenance, cellular-to-organ coupling or human prediction accuracy. Native cold-start, interval runtime, determinism and memory remain unmeasured until the tests run.

Still-open obligations carried into the parent child inventories: causal autonomic/HR/HRV and ECG transfer; chemical/optical/electrical cartridge/sensor forward models and calibrated units/site/biofluid mapping; battery/communications/firmware failure models with actual evidence; corrected RevB0/firmware and paired physical captures; insulin and all five candidate-specific systems; independent Cendos/physical residual qualification and reviewed model application/rollback. Their outputs cannot be invented to populate channels, but these requirements are not dropped or silently deferred by implementing the execution transport.

Review decision requested from root: accept or amend the source-owner/device-consumer architecture, strict no-global-source boundary, numerical adapters and source gates, immutable record schema, proposed bounds, retry/restart semantics, ownership and red-test matrix. After approval, implementation evidence must be appended under the relevant R IDs with exact commit/environment/test/browser results. No pass counts, readiness, complete restoration or physical equivalence is asserted by this draft.

## 9. Numerical packet fixed before implementation

Root accepted the ownership architecture, stable source generation, no-global-bus boundary, native axes, encrypted virtual output, exact retry and bounded lifecycle on 2026-09-08. The following numerical acceptance tolerances are recorded before any new integration output was computed. They are engineering convergence limits, **not human prediction-error targets or physiological normal ranges**. A failed limit requires investigation and an independently reviewed correction; do not loosen it after seeing a result simply to obtain a pass.

### Pinned source and checkpoint identity

- Locked and installed versions inspected: Python 3.11, NumPy 2.4.6, SciPy 1.17.1, Myokit 1.39.2. Package digests are pinned in `requirements-python311.lock`; do not silently use another worker version. Native CVODE/SUNDIALS runtime identity must be recorded during the first numerical run; no native-runtime version is asserted by this metadata-only inspection.
- Primary numerical API source inspected in those installed distributions: SciPy `scipy/integrate/_ivp/ivp.py`, `solve_ivp`, including explicit `t_span`/`y0` and local error rule `atol + rtol*abs(y)`; Myokit `myokit/_sim/cvodessim.py`, `run`, `pre`, `state`, `time`, `set_state`, `set_time`, `set_tolerance`. These version-pinned author sources, rather than unverified current-web API signatures, ground the interval/checkpoint design.
- Metabolic mechanism source remains the unchanged repository `_rhs`/meal appearance code in `engines/metabolic/glucose_insulin.py`. Its pancreatic/oral closures and reference priors are not upgraded into a revalidated original Bergman model by this adapter. Capture that file's digest and complete admitted parameter provenance in every source.
- Pinned cellular primary model: `models/cardiac/ohara_rudy_cipa_2017.cellml`, SHA-256 `ed127e6737611eb1469ea32db0b9d102f0780fc286a29ca88d11d8a868a94175`. Metadata-only parsing with Myokit 1.39.2 found 49 states, native milliseconds, membrane mV, cytosolic calcium mM, stimulus period 1000 ms and pulse duration 0.5 ms. No solver was constructed or executed for this check. Preserve model-declared units, including surprising source annotations, instead of silently correcting them.

Metabolic checkpoint order is exactly `(glucose_mgdl, insulin_action_per_min, insulin_uU_ml)`, plus absolute `t_min` outside that state vector. Checkpoint identity also binds parameter/schedule/source/model hashes, units and adapter version. Missing/reordered/duplicate state names reject, even if the vector length matches.

Cellular checkpoint order is exactly the following Myokit 1.39.2 import order; store names and units alongside values, verify them against the pinned model, and bind native time, initialization/pacing/constants/source hashes. Never infer it from the order of JSON object keys:

```text
membrane.v, CaMK.CaMKt,
intracellular_ions.nai, intracellular_ions.nass,
intracellular_ions.ki, intracellular_ions.kss,
intracellular_ions.cass, intracellular_ions.cansr,
intracellular_ions.cajsr, intracellular_ions.cai,
INa.m, INa.hf, INa.hs, INa.j, INa.hsp, INa.jp,
INaL.mL, INaL.hL, INaL.hLp,
Ito.a, Ito.iF, Ito.iS, Ito.ap, Ito.iFp, Ito.iSp,
ICaL.d, ICaL.ff, ICaL.fs, ICaL.fcaf, ICaL.fcas, ICaL.jca,
ICaL.ffp, ICaL.fcafp, ICaL.nca,
IKr.IC1, IKr.IC2, IKr.C1, IKr.C2, IKr.O, IKr.IO,
IKr.IObound, IKr.Obound, IKr.Cbound, IKr.D,
IKs.xs1, IKs.xs2, IK1.xk1, ryr.Jrelnp, ryr.Jrelp
```

### Admitted initialization and numerical test domain

`metabolic-continuous-v1` starts only from the server-captured, already admitted `MetabolicProfile` with all 12 numerical parameters and its separate name present, using the existing `clinical_parameters.validate_model_parameters()` executable ceilings and finite positive values. Those ceilings are numerical input limits, not validated joint population ranges. At fresh model T0 the only initial vector is `(profile.Gb, 0, profile.Ib)`. Resume/fork accepts only a complete, hash-verified checkpoint generated under this exact contract. An HTTP caller cannot set hidden state values. Preserve named reference/prior versus measured parameter provenance and never claim the full domain is individually qualified.

The immutable meal schedule is explicitly captured, sorted by native time, at most 64 nonnegative-time/nonnegative-gram events, no more than 500 grams per event, within the selected 0–840 minute execution domain. These are bounded research-input limits, not a recommended meal or a clinical applicability claim. Existing schedules outside this new contract remain preserved and inspectable but the new executor rejects rather than alters them. No new exogenous insulin, PK or botanical intervention enters this adapter without its own admitted mechanism.

`cardiac-continuous-v1` starts from all 49 pinned CellML initial values; no arbitrary caller initial vector or general constant override is accepted. The only inherited intervention input in this packet is an explicit captured ventricular-cell IKr block fraction in [0, 0.9], with its existing declared provenance; do not copy the whole-day glucose-derived `twin.ikr_block`. Fixed reference pacing is 1000 ms, 0.5 ms pulse, 50 ms offset, with five paced cycles as recorded initialization. Do not use the heuristic `twin.cardiac_cl_ms` as measured/autonomic evidence. Resume uses the full verified checkpoint and unchanged pacing/constants. The maximum configured execution domain is 1,800,000 native ms for the planned 30-minute numerical soak; successful computation there is not long-term biological validation.

### Preregistered numerical checks

For matched points use `abs(candidate-reference) <= A + R*abs(reference)`; every point must pass, not only the mean. Reference and interval runs use identical inputs and initial/pre-paced states. Endpoint clock error is at most `1e-9` in the declared native unit, with no duplicate boundary frames.

| Output/check | A (native unit) | R | Test setting |
|---|---:|---:|---|
| Metabolic glucose | 0.02 mg/dL | 0.0002 | LSODA preserved `rtol=1e-6`, `atol=1e-8`; compare split 0.25/1/5-minute chunks and a monolithic 240-minute trajectory, then 1/7-minute chunks over 840 minutes. |
| Metabolic insulin | 0.005 uU/mL | 0.0002 | Same runs, full state retained. |
| Remote insulin action X | 0.000002 1/min | 0.0002 | Same runs; never replace X with insulin or receptor activity. |
| Tightened metabolic convergence | same three limits | same | Recompute reference with `rtol=1e-8`, `atol=1e-10`; default outputs must remain within the fixed limits. |
| Cellular membrane voltage | 0.05 mV | 0.0001 | New adapter CVODE tolerances `abs_tol=1e-10`, `rel_tol=1e-8`; compare 10/100/250 ms chunks against monolithic output on the same fixed 1-ms sampling grid over two cycles after identical pre-pacing. |
| Cellular cytosolic/subspace calcium | 0.0000002 mM | 0.0001 | Same runs and matched phase, no phase-shift fitting. |
| Cellular Na/K compartments | 0.0001 mM | 0.0001 | Compare full final checkpoints, not just plotted outputs. |
| Cellular NSR/JSR calcium | 0.000002 mM | 0.0001 | Same full-state comparison. |
| Other cellular states | 0.000001 of each model-declared unit | 0.0001 | Includes CaMK/gates/occupancies/release states; preserve all 49 values and source units. |
| Tightened cellular convergence | same state limits | same | Repeat with `abs_tol=1e-12`, `rel_tol=1e-10`; no tolerance changes to the legacy `CardiacCell.simulate()` path. |

Metabolic cases are the existing HEALTHY and T2D reference presets, no meal, one 75-g event at T0, an event strictly across a chunk boundary, and the existing three-meal schedule. No-meal T2D is **not** asserted stationary: the current secretion closure has `Gb > Gt`. Stationary basal algebra is tested only where the unchanged equations actually admit it (HEALTHY with no meal). Test finite positive glucose/insulin and complete numerical outputs; X may be negative under the existing equations and must not be clamped or rejected merely for its sign. Cellular tests include IKr block 0 and 0.5, using the same initialization on both sides. Quota/cancellation/restart/switch tests use explicitly technical adapters, with separate opt-in native cases so fake workers never count as solver verification.

Independent source review requires an additional event-resolution regression: a HEALTHY stationary interval followed by a future meal strictly inside a large chunk must produce the corresponding nonzero appearance/response. `t_eval` does not force LSODA's internal steps to land on an event. Split integration at admitted meal onset times and retain absolute time; compare the same event-aware reference equations, without altering the rate-of-appearance function or refitting parameters. Historical `simulate()` remains unchanged; any discovered legacy event-resolution discrepancy is recorded rather than hidden by weakening the new test.

Stop criteria: any failed fixed tolerance, missing solver/model identity, unsupported initialization, nonfinite output, inconsistent full checkpoint, reversed time or failed domain/QC gate prevents an advancing qualified frame. Archive the bounded named failure; do not retune, repair the state or supply another model's output. The numerical adapter can pass software conformance only; no independent physical validation is implied.

## Root source-authority implementation seam

Root and reviewer agreed a synchronous `ModelSourceAuthority` with one reentrant lock,
opaque process-generation UUID, detached `capture(expected_generation)` and separate
`observe()` attachment. Every model/subject mutation fences the old execution before
changing generation. Fence failure prevents mutation; a failed mutation cannot reuse
the invalidated generation. Observation-only attachment shares the guard but keeps
generation. No `await` or remote request is held inside the guard. Lock order is
authority then manager; the manager never calls back into the authority. This is a
single-process runtime guarantee, not distributed ownership.

The manager seam is `capture_source_payload(twin, selection, source_generation,
engine_contract_id)` called inside the authority, followed by prepare/start/pause/
resume/stop/status/frames and synchronous `invalidate_source(old_generation, reason)`.
Capture uses complete detached parameters and initial state, never downsampled
`tw.state()` results. Route integration and numerical tests remain pending. Root's
five authority tests failed before the new implementation existed.
## Independent numerical correction verification, 2026-09-08

The source-research lane independently read the contract, native adapters,
frame consumer and numerical tests. Two admission gaps were reproduced with a
technical copy of a genuine one-minute metabolic output: a negative intermediate
glucose value and a plotted endpoint disagreeing with its checkpoint. Both now
fail closed. Metabolic glucose/insulin must remain positive at all emitted
samples; every emitted endpoint must exactly match its mapped saved state.
Small negative cardiac concentrations inside the preregistered numerical floors
are retained with explicit numerical-uncertainty notes, never clamped or treated
as physically valid concentrations. Values below those floors are rejected.

The convergence tests now require the complete expected quarter-minute plus
meal-onset grid and reject duplicate boundary samples, rather than comparing
only a nonempty intersection. The independent numerical/lifecycle/store packet
passed **52 tests in 18.66 seconds**, including both actual native cardiac cases,
in fresh isolated storage. Observed native identity: Myokit **1.39.2**, CVODE,
SUNDIALS **7.8.0**, absolute tolerance **1e-10**, relative tolerance **1e-8**,
pre-pacing **5000 ms**, `full_state_native_interval` continuation. No tolerance
was relaxed for this review.

No further critical issue was found in this bounded numerical scope. This is
evidence of software continuation and convergence under the stated contexts;
it does not establish physical human equivalence, device qualification, or
completion of the wider LIFE lifecycle/whole-body requirements.

## Consumer implementation checkpoint, 2026-09-08 (not acceptance)

The approved manager interfaces are now implemented as explicit typed operations:

```text
ExecutionManager.bind_consumer(execution_id, session_id, source_snapshot_hash,
    expected_revision=..., expected_source_generation=...)
ExecutionManager.renew_consumer(execution_id, session_id, source_snapshot_hash,
    expected_source_generation=...)
VirtualSessionManager.start(execution_id, source_snapshot_hash, device_id,
    expected_selection=..., idempotency_key=...)
VirtualSessionManager.status(session_id)
VirtualSessionManager.pause/resume/stop(session_id, expected_revision=...)
```

The source client uses a fixed, explicitly configured literal-loopback endpoint,
operator authentication and the expected packaged source fingerprint. Every
response must carry that source hash and the same Aegle process instance. It
follows no redirects, consults no proxy environment and requests one immutable
frame at a time through a strict two-megabyte JSON limit. LIFE receives no public
argument containing arbitrary result arrays, scalar sensor values or service URL.

The new observation operator remains only
`metabolic-plasma-glucose-identity-v1`, explicitly modeled plasma glucose in
mg/dL. Its virtual manifest has no physical hardware and no manufactured HR,
ECG, skin temperature, ISF transport or chemistry-assay equivalence. Frame age at
original acquisition must be between zero and 30 seconds; this is software
policy, not a measured physical latency. Cellular native-ms outputs remain
separate typed execution quantities, not substituted ECG signals.

`VirtualSessionStore` uses a separate encrypted SQLite database, a keyed active
device constraint, bounded global payload accounting, reserved transition/audit
capacity and one encrypted pending envelope/receipt per session. An encrypted
storage-kind marker prevents execution and virtual-session databases from being
silently interchanged. Existing unmarked execution databases can adopt the
execution marker; a virtual-session database must be atomically new or already
carry its own matching marker. SQLite file/page/journal overhead is outside the
encrypted-payload quota and must be measured separately.

Maker tests currently report **33 passed in 1.24 seconds** across source/operator,
session store and consumer lifecycle. They include exact gateway append-before-
response recovery, forwarding acknowledgment loss, first forward while the
producer is paused, quota rejection before journal write, changed source/peer,
explicit same-peer LIFE restart recovery and stop during a pending source fetch.
These are technical fixtures, not independent numerical/HTTP/browser evidence.
The consumer packet still requires independent review and genuine engine-backed
two-service verification. Root owns signed Aegle receipt/projection integration.

The separate [consumer-lease amendment](2026-09-08-life-consumer-lease-amendment.md)
records independent lease/gateway review. On-time renewal does not change an
execution revision; late renewal first applies the expiry pause/fence. A separate
local expiry checker can cancel a blocked numerical job. No measured remote
pause-time or physical-link guarantee follows from its prospective cadence.

Compounded failure lessons: a constructor can fail before returning an adapter,
so ownership cleanup must track successful activation rather than object
existence. An explicit Pause issued while a Resume request awaits source I/O must
fence that older request; otherwise it can restore consumer permission afterward.
The red regressions preserve both boundaries. Retried delivery retains its exact
envelope, sequence and clock; a new timestamp is not an idempotency mechanism.

Final timing correction within the approved frame contract: new execution frames
also retain `generated_monotonic_s` from the producer's actual monotonic clock.
The same-host, process-pinned LIFE operator requires both UTC elapsed age and
monotonic elapsed age to lie within zero to 30 seconds at original acquisition.
This prevents a wall-clock rollback from making an old frame look newly generated.
Exact receipt retries retain both original clocks; legacy v2/v3 wire bytes are
unchanged. Three additional regressions were red before this correction and green
afterward. The maker's combined lifecycle/source/store/consumer packet then passed
82 tests in 2.77 seconds; independent delta review and root's signed intake check
remain separate gates, not assumed by this result.

### Independent consumer review, 2026-09-08

The source reviewer independently read `execution_source.py`,
`virtual_session_store.py`, `virtual_execution.py`, their tests, and the adjacent
receipt/forwarding contracts. Startup originally exposed an owned session to the
background poller before binding finished; the poll could change its revision and
make startup fail. A busy fence and post-I/O owner/revision checks now prevent
that race. The operator manifest originally reread a later on-disk source file
when labeling already loaded code; its source hash is now captured at import.
The LIFE service must additionally reject package drift before new operations,
including lazy imports after startup.

Independent rerun: **61 passed in 13.69 seconds**, three inherited dependency
deprecation warnings, across the 36 source/store/consumer cases and adjacent
forwarding/intake suites. No additional blocker was found in the three consumer
modules within this review. Technical consumer fixtures do not prove native
source execution. A cross-lane defect remained at this review snapshot: Aegle
intake equated device-global wire sequence with execution-local frame index.
Fresh devices, history anchors and reused devices require distinct counters.
Root owns that intake correction and its real two-service acceptance test.
This review does not certify physical equivalence, long-duration operation,
browser behavior, or the complete product.

Compounded lesson: process/transport counters, execution frame cursors and
acquisition clocks have different owners and lifetimes. Bind them explicitly;
never infer equality from the first happy-path example. Source provenance must
describe the code actually loaded, not whatever bytes appear on disk later.
