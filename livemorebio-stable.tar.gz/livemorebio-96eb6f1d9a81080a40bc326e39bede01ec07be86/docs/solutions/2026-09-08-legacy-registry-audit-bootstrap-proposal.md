# Legacy registry audit bootstrap: separate an attempt from key authority

Date: 2026-09-08. **PROPOSAL ONLY.** No implementation or operational migration is
authorized by this document. Root and independent security review must approve
the design before red tests or runtime changes. The current zero-audit defect
remains an OPEN release blocker.

## 1. Observed failure and minimum scope

In `subjects.py:295–325`, initialization creates the audit helper with the supplied
data key, commits its first BEGIN, then decrypts historical twins. With a wrong
first key, decryption fails but that BEGIN/reservation remains. Subsequently,
`registry_audit.py:67–80` authenticates the first audit event with the correct data
key and fails before it can reach the unchanged clinical record.

Independent reviewer evidence is the isolated authored-software fixture
`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-legacy-bootstrap-review-7exr94r8/technical.sqlite3`.
It was created directly with the old `records` schema and fixture encryption,
not through the new constructor. Reviewer observed wrong-key `InvalidTag`, then
correct-key `InvalidTag`, one BEGIN, one reservation, and unchanged original
nonce/ciphertext. This proposal author did not open or modify that database.

Reuses the existing AES-GCM record/AAD format, SQLite writer transactions, shared
reserved BEGIN/RESULT audit, source/process identity and private-file patterns.
Adds only a **bootstrap attempt journal and independently provisioned local key**,
plus a key-proof marker. Normal clinical and physical audit event schemas remain
unchanged. It does not introduce a new network service or clinical authority.

Prior art: [clinical amendment](2026-09-08-clinical-context-availability-amendment.md),
[implementation review](2026-09-08-clinical-registry-implementation-review.md),
and existing `RegistryAudit` reservation tests. Gbrain, Context7 and
sequential-thinking tools were not available in this session. Engineering-plan
review covered architecture, code boundaries, tests and performance using local
source only; third-party API verification remains required before implementation.

## 2. Trust constraint and alternatives

An unverified caller-supplied data key cannot simultaneously provide authoritative
key verification and an independently readable audit of its own failed attempt.
Before the first permitted clinical decrypt, the legacy store has no trusted
data-key proof. Encrypting a new audit event with that candidate key proves only
that this process possessed the candidate, not that it decrypts the old store.

**Recommended A: independent bootstrap audit key.** Keep pre-verification attempts
readable by the local operator even when the supplied clinical key was wrong.
Only a later successful, already-audited verification may establish data-key
authority. This requires backing up one additional local secret with the database.

Rejected B: try a clinical decrypt before BEGIN. It violates access ordering.
Rejected C: retain candidate-key audit partitions only. It avoids poisoning but
cannot promise the legitimate operator can read wrong-key attempt metadata later.
Rejected D: discard/re-encrypt the wrong event or search for a decryptable audit
row and silently trust it. That rewrites evidence or conflates unverified attempts
with authoritative key identity.

These are local software trust boundaries, not HIPAA certification, an external
tamper-proof ledger, or protection against the OS account owner replacing the
database and its keys. The plan does not create enterprise key management.

## 3. Exact state distinction

```text
UNMARKED_EMPTY         -> initial key establishment, no clinical key claim
UNMARKED_ZERO_AUDIT    -> independent durable BEGIN -> audited legacy key check
                                                    | bad/unknown: failed result
                                                    | good: atomic proof + result
VERIFIED_PROOF         -> authenticate proof before any new normal audit write
UNMARKED_WITH_AUDIT    -> existing normal verification, unchanged
                        if it fails: normal startup rejects without writes
                        explicit local recovery can independently audit a check
```

Normal startup of an already-audited store must retain the existing wrong-key
no-record/no-audit-byte-change behavior. An unmarked existing audit encrypted with
another key could mean either a wrong current key or the reproduced wrong-first
attempt. **Those cases cannot be distinguished automatically.** Therefore the
already-poisoned case requires an explicit local recovery entry point, not an
automatic fallback or an HTTP flag. The caller selects the exact store; no broad
search, key guessing or automatic retry. No recovery entry point is implemented
by this proposal.

For a future zero-audit migration under the proposed design, a wrong first key
leaves only the independent bootstrap journal. A subsequent correct ordinary
open can retry under its own durable BEGIN and establish the proof. No special
recovery is needed in that new case.

## 4. Key, storage and identity contract

1. Use one random 32-byte bootstrap key per registry, independent of the supplied
   data key and never derived from it. Local-development default is a fixed sibling
   sidecar `<registry basename>.bootstrap-key`; production must supply it through
   a separately managed secret. Do not reuse the permissive current `_load_secret`
   behavior unchanged: unreadable/malformed existing keys are errors, not absence.
2. Before any database or key access, validate the exact parent (0700, owner,
   directory) and final key/DB/WAL/SHM/lock files (0600, owner, regular, single link,
   no symlink). Do not chmod-repair existing material. Store identity is a UUID,
   not an absolute path in audit output. Tests/launcher isolation must include this
   new secret and sidecar so tests cannot alter a live directory.
3. Create a missing key only if there is no existing bootstrap identity/event/proof.
   Publish exclusively with file and directory durability and re-read the winner.
   An orphan published key before any DB bootstrap commit is safe to reuse. A
   missing or mismatching key after bootstrap metadata exists is an explicit
   `REGISTRY_BOOTSTRAP_KEY_UNAVAILABLE`; never generate a replacement.
4. Bootstrap tables live in the **same registry SQLite database**, with distinct
   kind `livemore.subject-registry.bootstrap.v1`. Plain indexes contain only
   random event/request IDs, sequence and reservation links. Encrypted metadata
   contains store/process/source identity, fixed action/outcome, UTC timestamps,
   and nullable witness/legacy-ledger digests. No clinical values, condition text,
   source paths, data key, plaintext key fingerprint or caller error strings.
5. Bootstrap AAD is exactly
   `b'livemore.subject-registry.bootstrap.v1\0' + event_uuid_ascii`.
   New data-key proof AAD is exactly
   `b'livemore.subject-registry.key-proof.v1\0' + store_uuid_ascii`.
   Old `livemore.aegle.subject-registry.v1` record AAD and
   `livemore.subject-registry.audit.v1\0` audit AAD remain byte-for-byte unchanged.
6. Key proof is a new immutable encrypted row with exact schema, local store UUID,
   random challenge UUID, `proof_kind` (`LEGACY_WITNESS`, `EXISTING_AUDIT`, or
   `EMPTY_ESTABLISHMENT`), bootstrap request ID, witness digest or null, and origin
   source/process IDs. It is encrypted with the verified data key. Bootstrap
   metadata additionally authenticates its ciphertext digest with the independent
   bootstrap key. Neither proof rewrites or asserts authenticity of older rows.
7. Do not trust any marker while bootstrap key identity, proof binding, or its
   schema is missing/inconsistent. Do not scan for a convenient alternative proof.
   Key changes/rotation are a separate explicit migration, not a retry.

## 5. Zero-audit flow and atomicity

A single process-shared local POSIX lock with a five-second acquisition bound
serializes bootstrap initialization/check/recovery for an exact DB identity. Use
the existing reviewed private-lock ownership pattern, not a new spinlock or lease.
Keep the lock through the following two transactions and all error finalization.

1. Inspect metadata only. Distinguish truly empty `records` from a store containing
   only cohorts or other records. A store with ciphertext is never empty merely
   because its TWIN query returns zero rows. Reject malformed source metadata.
2. Reserve BEGIN plus terminal capacity in the independent bootstrap table and
   commit BEGIN durably **before invoking any clinical decryption**, including
   authentication-only decryption that discards plaintext. No normal v1 audit is
   created with the unverified data key at this stage.
3. Acquire `BEGIN IMMEDIATE` for the check/migration transaction. Re-read marker,
   witness and DB identity. A competing state change is rejected, not applied using
   preflight bytes. Pick exactly the lexicographically first existing record ID as
   a key witness; authenticate its original nonce/ciphertext/AAD and discard the
   plaintext unless normal constructor migration needs that same admitted record.
   Do not fall back to another row when that witness fails. This proves that the
   candidate decrypts that stored envelope, **not that every record is sound**.
4. Existing constructor subject-index migration still decrypts all required TWINs
   under this already committed BEGIN. Its duplicates, malformed JSON and other
   corruption errors remain operational errors. No model/profile constructor is
   called. A damaged non-witness row is not excused by a valid witness.
5. Only after required migration succeeds, atomically insert the key proof,
   bootstrap proof-binding metadata and successful terminal result with the subject
   index changes. Commit all in the same connection. Then use the existing normal
   audit helper for subsequent clinical access, authenticating proof first.
6. If verification or migration fails, roll back its transaction and append fixed
   `KEY_OR_RECORD_UNVERIFIABLE` or `MIGRATION_FAILED` terminal outcome in the reserved
   slot. Do not assert that an AEAD failure identifies the key rather than damaged
   ciphertext. No proof or subject-index changes may remain. Preserve the original
   failure if terminal write also fails; the BEGIN/reservation stays unresolved.
7. If no clinical record exists, record `EMPTY_ESTABLISHMENT` explicitly. The first
   selected key initializes a new empty store; there is no previous correct key
   to discover. This case must not advertise authenticated historical data.

The new proof resolves the first-BEGIN poisoning, not the authentication of all
mutable SQLite indexes. Existing full-record/ciphertext validation still applies
on access. The old active-pointer corruption guard stays unchanged.

## 6. Existing audits and explicit poisoned-store recovery

For an unmarked store whose existing normal audit authenticates, preserve normal
startup behavior. A later explicit adoption may bind an `EXISTING_AUDIT` proof
without decrypting clinical data; ordinary startup need not rewrite existing audit
rows or create a new bootstrap key merely to accept an already valid store.

For explicit recovery when an old first audit does not authenticate with the
operator's supplied key, run the independently audited witness/migration flow
above. Preserve **every** old audit row and reservation byte. Record encrypted
digests/counts of the pre-existing audit ledger as `LEGACY_UNVERIFIED`, not failed,
verified, completed or deleted. Their candidate-key plaintext may be permanently
unavailable; this limitation is recorded, not “recovered” by invented metadata.

If recovery succeeds, a verified proof becomes the explicit key-authority source
for new normal audit events; `verify_existing` must not still treat sequence 1 as
authoritative. Normal event schemas/sequence ordering/AAD remain unchanged. Old
unverifiable pending reservations remain charged and are not silently finished or
removed. Normal audit reads must surface their unavailable status rather than
return a fabricated decrypted event. Recovery fails closed if either journal lacks
required reserved capacity. Existing valid-audit wrong-key normal reopen still
has no audit mutation. This recovery route requires separate operator acceptance
of the retained historical-audit limitation before implementation.

## 7. Crashes, concurrency and finite bounds

- Bootstrap event plaintext is at most 4096 bytes; at most 512 charged event slots
  (256 BEGIN/RESULT attempts), including terminal reservations, per store. Existing
  normal audit retains its 10,000-slot bound. No TTL eviction, quota reset or
  deletion. Reservations are acquired before access and cannot be consumed by
  unrelated writers. A full bootstrap ledger blocks new attempts explicitly; it
  cannot promise indefinite good-key availability under unlimited wrong attempts.
- The normal migration witness must be at most 16 MiB ciphertext plus AEAD overhead;
  larger legacy envelopes produce `MIGRATION_REVIEW_REQUIRED` before decryption,
  not silent truncation or a claim that their content is corrupt. Existing twin
  migration should stream its rows instead of `fetchall`; proposed 10,000 TWIN and
  256 MiB total ciphertext admission bounds require explicit reviewer acceptance.
  Exceeding either preserves data and reports a separate reviewed migration need.
- A crash after BEGIN but before proof/result leaves a durable pending attempt.
  The next process may append `INTERRUPTED_OUTCOME_UNKNOWN` under the independent
  key using its reserved slot. It cannot claim no clinical access occurred or resume
  the old key check; a new attempt gets a new BEGIN. Origin and completing process
  are recorded separately. The original BEGIN remains immutable.
- Proof, success result and migration writes commit together. After uncertain
  commit, reconnect under the lock and authenticate the exact request/proof/result
  tuple. If that cannot establish commit or rollback, return
  `BOOTSTRAP_COMMIT_UNCONFIRMED`; do not retry, decrypt more data or return success.
- Two processes with different supplied keys cannot publish competing proofs.
  A waiter rechecks under the lock: after a valid proof exists, a wrong key fails
  before any new audit write. After a failed candidate, the correct candidate can
  create a new independent BEGIN. Crashes release the OS lock, not audit evidence.
- Key-sidecar/db replacement, unsupported filesystem locking/durability, malformed
  markers or audit corruption fail with fixed safe errors. No raw paths, keys,
  ciphertext or clinical exception contents in logs/API responses.
- These are bounded local cooperative-writer controls, not remote-WORM integrity
  or protection against deletion by the machine owner. Secret/database backup and
  key-loss recovery procedures must ship with the migration, not be inferred.

## 8. Red-first acceptance and coverage map

All new tests use directly constructed old-schema, encrypted **technical** records.
No operational store, participant or physiological engine is used.

```text
constructor/recovery [integration, real SQLite connections/processes]
  empty                   -> establishment identity, no false legacy proof
  legacy zero-audit        -> BEGIN before first _open
    wrong then correct    -> failed attempt retained, good open succeeds
    corrupt witness       -> fixed rejection, no fallback witness
    cohort-only records   -> not mistaken for empty
    migration failure     -> no proof/index mutation, terminal retained
  existing audited        -> correct unchanged; wrong zero new writes
  explicit recovery       -> old audit bytes immutable/unverified, good proof
  crash at each boundary  -> reserved unknown result or exact committed result
  concurrent keys         -> one authoritative proof, two durable attempts
  quota/key/path failures  -> no decrypt and no successful mutation
```

Required new dedicated module `test_registry_bootstrap_contract.py`:

1. **Critical regression:** direct old-schema fixture, first wrong key then correct
   key, both attempt metadata readable with independent key; original records/AAD,
   old audit rows and indexes preserved except explicit successful index migration.
2. Spy at each clinical decrypt and require that exact request's fresh BEGIN has
   committed on a different read connection. No unrelated prior audit qualifies.
3. Empty, cohort-only, malformed witness, correct witness with damaged later twin,
   duplicate pseudonym, out-of-bound rows, and immutable pending failures.
4. Crash injection before/after key publication, BEGIN commit, decrypt, proof insert,
   result insert and commit ACK; reopen with a different process and only persisted
   reservation identity. No reread/side effect without a new BEGIN.
5. Two connections/processes racing wrong/correct and correct/correct keys; exact
   lock/DB identity, revalidation and proof count. No process-local-only evidence.
6. Exact 510/511/512 quota boundaries, concurrent capacity contention, and terminal
   completion after another operation fills all unreserved capacity.
7. Missing, malformed, replaced, linked, wrong-owned or unsafe-mode key/DB files;
   no silent regeneration/repair or access. Test isolated review/installer paths.
8. Already-audited wrong-key no-byte-change regression remains. Explicit recovery
   of a retained wrong-first audit must preserve its bytes and unknown meaning.
9. Old ciphertext/index/hash golden preservation; no calls into clinical compiler,
   numerical resolver, source-loader, physical provisioning or device commands.
10. Primary failures survive failed evidence writes; commit uncertainty is explicit;
    public errors contain no fixture markers, keys, source paths or raw exceptions.

Run these red before implementation, then owned context/registry/audit/public
reference lifecycle tests. Root independently grades a fresh-process startup
fixture for absent, coherent and corrupted active selection. Browser acceptance
remains separately required for the surrounding clinical release, not evidence
that this crypto/storage migration works. No tests have been run for this proposal.

## 9. Implementation boundaries and pending decisions

Sequential implementation in one registry lane, then independent review. Reuse
`RegistryAudit` transaction/reservation mechanics without broad changes to physical
contracts. Proposed files: new bounded bootstrap helper plus subjects/audit seams,
dedicated tests, and local recovery/backup guide. No new external dependencies.
An operator-facing recovery command, if approved, is a separate small integration
step owned with CLI/SDK maintainers; no web recovery endpoint.

NOT in scope: record re-encryption, data-key rotation, audit deletion, recovery of
unknown-key audit plaintext, remote audit services, automatic production key
generation, changes to any biological inputs/equations, physical-v3 implementation,
or a conclusion that PHI controls are production-qualified.

Engineering review outcome: **DONE_WITH_CONCERNS, pre-code proposal only.** The
primary decisions requiring root and independent approval are (1) the independent
bootstrap secret and its backup contract, (2) explicit recovery and retained
unverifiable old audit entries, and (3) finite migration bounds. All identified
failure branches have prespecified tests, but zero implementation acceptance is
claimed. This document is the test-plan artifact in the authorized solutions
directory; no skill telemetry/configuration or unrelated files were changed.

Lesson: durable recording is not key verification. A provisional attempt must not
become the authority that decides whether later attempts may authenticate.

## 10. Independent-review clarification: frozen schema and authority order

**Proposal-only amendment, 2026-09-08.** This section resolves the independent
review's schema and historical-witness ambiguities. Section 11 specifies the
remaining recovery writer-exclusion gate. No runtime, legacy store or key was
changed. The earlier 512/10,000-slot and migration-size limits remain unchanged.

### 10.1 Exact new tables and invariant indexes

All tables below are in the existing registry SQLite database. Every operation
enables foreign-key enforcement; application validation also checks authenticated
links rather than trusting mutable indexes. These are additive tables, not a
replacement for `records`, `metadata`, `registry_audit` or its reservations.

| Table | Exact columns and constraints |
| --- | --- |
| `registry_bootstrap_identity` | `singleton INTEGER PRIMARY KEY CHECK(singleton=1)`, `identity_id TEXT NOT NULL UNIQUE`, `nonce BLOB NOT NULL`, `ciphertext BLOB NOT NULL` |
| `registry_bootstrap_events` | `event_id TEXT PRIMARY KEY`, `sequence INTEGER NOT NULL UNIQUE CHECK(sequence>0)`, `nonce BLOB NOT NULL`, `ciphertext BLOB NOT NULL` |
| `registry_bootstrap_attempts` | `begin_event_id TEXT PRIMARY KEY REFERENCES registry_bootstrap_events(event_id)`, `request_id TEXT NOT NULL UNIQUE`, `result_event_id TEXT UNIQUE REFERENCES registry_bootstrap_events(event_id)` |
| `registry_data_key_proof` | `singleton INTEGER PRIMARY KEY CHECK(singleton=1)`, `proof_id TEXT NOT NULL UNIQUE`, `nonce BLOB NOT NULL`, `ciphertext BLOB NOT NULL` |
| `registry_bootstrap_proof_binding` | `singleton INTEGER PRIMARY KEY CHECK(singleton=1)`, `binding_id TEXT NOT NULL UNIQUE`, `proof_id TEXT NOT NULL UNIQUE REFERENCES registry_data_key_proof(proof_id)`, `nonce BLOB NOT NULL`, `ciphertext BLOB NOT NULL` |

Each encrypted row has a fresh random 12-byte nonce; ciphertext is 17–4112 bytes
and decoded plaintext is at most 4096 bytes. Reject duplicate/unknown fields,
invalid UTF-8, non-object roots and non-finite/nested unbounded values. All IDs
named `*_id` or `*_instance` below are server-owned canonical UUID strings except
the historical witness's bounded opaque record/audit ID. Hashes are lowercase
64-character SHA-256 strings. Sequences are positive integers, never booleans.
UTC times are canonical timezone-aware strings emitted by the server; no caller
timestamp, free-text outcome, path or clinical content enters these payloads.

An attempts row with `result_event_id IS NULL` reserves exactly one terminal
event slot. Charged slots are `COUNT(events) + COUNT(pending attempts)`. BEGIN
requires two free slots before insertion. Completing an attempt inserts its
RESULT and changes only its result index in the same transaction; both immutable
event rows remain. The unique persistent request index prevents reusing a request
after completion. A second result or a substituted request/result index fails
authenticated linkage checks, not an idempotent success guess.

Singleton proof and proof-binding rows are insert-only. Their pair plus the
successful RESULT and migration writes commit atomically. Partial or duplicate
singletons fail closed. No replace/upsert, scan for a different proof or quota
eviction is permitted.

### 10.2 Exact encrypted payloads and AAD

Payloads contain **exactly** the listed fields. Nullable means explicit JSON null,
not omission. Canonical JSON means sorted keys, compact separators, strict finite
JSON; hashes are over the specified bytes, not decrypted clinical values.

`registry_bootstrap_identity` uses the independent bootstrap key and AAD
`b'livemore.subject-registry.bootstrap-identity.v1\0' + identity_id_ascii`:

```text
schema = livemore.subject-registry.bootstrap-identity.v1
identity_id, local_store_id, created_at,
origin_process_instance, origin_source_sha256
```

Every BEGIN and RESULT uses the section 4 bootstrap event AAD and independent
key. Both have this exact envelope:

```text
schema = livemore.subject-registry.bootstrap-event.v1
event_id, sequence, event_type, begin_event_id, request_id, action,
local_store_id, started_at, completed_at, outcome_code,
origin_process_instance, origin_source_sha256,
completion_process_instance, completion_source_sha256,
proof_id, proof_kind, witness, legacy_ledger
```

- `event_type` is `BEGIN` or `RESULT`; `action` is `INITIALIZE`,
  `ADOPT_EXISTING_AUDIT` or `RECOVER_UNVERIFIED_AUDIT`.
- A BEGIN has `begin_event_id == event_id`; completion fields, outcome, proof ID,
  proof kind, witness and legacy ledger are null. The origin identifies the
  process that durably requested access, not a subsequent completing process.
- A RESULT retains the exact BEGIN request/action/store/start/origin fields and
  names that BEGIN. Completion fields are non-null and identify the process that
  actually records the result. Its `outcome_code` is exactly `SUCCESS`,
  `KEY_OR_RECORD_UNVERIFIABLE`, `MIGRATION_FAILED` or
  `INTERRUPTED_OUTCOME_UNKNOWN`. A failed/unknown result has null proof fields;
  it may contain a retained ledger digest only when that digest was actually
  obtained, never guessed from a failed access. A success references the exact
  proof fields below. Its sequence follows its BEGIN; do not assume adjacency.
- `proof_kind` is null or one of the three section 4 kinds. `witness` is null or
  exactly `{kind, opaque_id, index_sha256, nonce_sha256, ciphertext_sha256}`.
  `kind` is `RECORD` for `LEGACY_WITNESS`, `AUDIT_EVENT` for `EXISTING_AUDIT`.
  The opaque ID is a bounded existing ID, retained only inside encryption.
  `index_sha256` authenticates canonical historical record-index fields
  `{record_id,record_type,version,source_class,lifecycle}` or audit-index fields
  `{event_id,sequence}`. Absent record-index fields are explicitly null, not filled
  from inference. Nonce and ciphertext hashes are over their original bytes.
- `legacy_ledger` is null or exactly `{state,event_count,reservation_count,
  ledger_sha256}` with `state == LEGACY_UNVERIFIED`. Counts are nonnegative
  integers. The digest covers a domain-prefixed, length-delimited canonical
  sequence of all old audit rows ordered by sequence and old reservations
  ordered by event ID: original index fields plus original nonce/ciphertext
  hashes, including request/reservation links. Fix the domain to
  `b'livemore.subject-registry.legacy-audit-digest.v1\0'`. Do not decrypt old
  candidate-key audit records to compute this snapshot or label them verified.

The data-key proof uses the supplied, successfully verified data key and the
section 4 key-proof AAD. Its exact plaintext is:

```text
schema = livemore.subject-registry.key-proof.v1
proof_id, local_store_id, challenge_id, proof_kind,
bootstrap_identity_id, bootstrap_request_id, bootstrap_begin_event_id,
bootstrap_result_event_id, established_at,
origin_process_instance, origin_source_sha256, witness, legacy_ledger
```

The challenge is independently random; it is not a data-key hash. A legacy proof
requires a RECORD witness; an existing-audit proof requires an AUDIT_EVENT witness;
empty establishment requires `witness == null` and `legacy_ledger == null`.
Only explicit recovery may carry `LEGACY_UNVERIFIED`. Origin fields name the
process that establishes the proof; the linked BEGIN separately retains the
access origin if different. Empty establishment never proves old clinical data.

The proof binding uses the independent key and AAD
`b'livemore.subject-registry.proof-binding.v1\0' + local_store_id_ascii`:

```text
schema = livemore.subject-registry.proof-binding.v1
binding_id, local_store_id, bootstrap_identity_id, proof_id,
proof_nonce_sha256, proof_ciphertext_sha256,
bootstrap_request_id, bootstrap_begin_event_id, bootstrap_result_event_id,
established_at, origin_process_instance, origin_source_sha256
```

The binding, proof and successful RESULT must agree on IDs, store, proof kind and
witness/ledger fields where present. Proof/binding `established_at` equals RESULT
`completed_at`; proof/binding `origin_process_instance` and `origin_source_sha256`
equal RESULT's **completion** process/source, not necessarily its retained BEGIN
origin. BEGIN and RESULT retain identical start/origin fields. Validate this fixed
graph including the attempts row, not merely whether any one AEAD decrypt
succeeds. All older record and normal-audit bytes/AAD remain unchanged.

### 10.3 Authority-check order, including already-open objects

In this section, **marked** means a complete committed proof + binding + linked
SUCCESS graph, not merely bootstrap tables, an identity, or an attempt. A valid
bootstrap identity with failed/pending attempts and neither proof nor binding
is provisional and remains retryable through the audited zero-audit bootstrap
path. A one-sided proof/binding, or a pair without its coherent SUCCESS graph,
is corruption and must not be retried as provisional initialization.

For a marked store, before a new normal audit write or clinical decrypt:

1. Validate exact filesystem/DB identity and writer capability; obtain the normal
   transaction's writer guard. Re-read marker state from that connection, not a
   constructor-time boolean or cached first audit row.
2. Authenticate the singleton bootstrap identity with the independent key and
   validate its store ID against the existing registry identity.
3. Authenticate the singleton binding, compare its exact proof nonce/ciphertext
   hashes, then authenticate that exact proof using the supplied data key.
4. Validate all exact schemas and linked BEGIN/RESULT/attempt identities. Require
   a successful established proof, not an unresolved attempt. Authenticate their
   encrypted metadata under the independent key before using its authority.
5. Only then append the normal v1 BEGIN and commit it before clinical decryption.
   At the subsequent access/mutation transaction, recheck the same authority
   identity under the writer lock before any `_open` or mutation. A changed or
   unavailable authority is a fixed operational failure; it is never a fallback
   to the old first-event heuristic or an unaudited clinical key test.

For an unmarked already-audited store, the existing audit key check remains
before new writes. An unmarked zero-audit store uses the separately committed
bootstrap-BEGIN path, never the candidate-key normal-BEGIN path. A failed
proof/binding/identity check does not create a new wrong-key normal audit entry.
These checks also cover long-lived registry objects created before proof
establishment **in the reviewed runtime**; old executable versions that lack the
guard require the separate exclusion contract in section 11.

### 10.4 A witness is historical key-establishment evidence

The witness fields identify the exact bytes that established the key at that
time. They are immutable historical evidence, **not a requirement that the live
record forever retains that nonce, ciphertext, version or lifecycle**. Routine
authorized activation, observation-only selection, evidence updates and index
changes may legitimately replace the live record's encryption. Subsequent opens
authenticate the immutable proof/binding/event graph and validate the requested
current record normally; they do not compare its bytes to the old witness digest.

Add a red regression establishing a legacy proof, then performing a normal
authorized witness-record version/selection update and reopening with the same
correct data and bootstrap keys. The new live record and unchanged old proof
must both validate; a wrong supplied data key must still make no writes. Separately
tamper the proof/binding/historical event bytes and require rejection. Historical
evidence preservation is not permission to ignore current record corruption.

## 11. Explicit recovery: writer exclusion is a prerequisite, not a claim

The bootstrap-only POSIX lock in section 5 does **not** prevent an already-open
old `SubjectRegistry` object from writing via `_audited`. A SQLite writer lock
protects a transaction, not all later writes after recovery releases it. File
descriptor listings, an operator checkbox or this utility's own lock alone do
not prove old executables will remain unable to write. Do not stop arbitrary
services, infer quiescence from a port check or claim cross-process exclusion
merely because this tool runs locally.

The implementation proposal must therefore include both:

1. The per-transaction authority recheck in section 10.3 for every supported
   writer, including existing objects and an operation whose durable normal
   BEGIN preceded proof establishment. Acquire the SQLite writer lock before
   re-reading authority. A stale wrong-key helper must fail before a new BEGIN
   or clinical decrypt, without poisoning the recovered store. Its old pending
   access remains charged/unknown unless an actually authorized completion is
   recorded; recovery cannot invent its outcome.
2. A separate, independently approved exact-store quiescence procedure for
   unsupported old executable versions that lack this check. **No such procedure
   has yet been demonstrated by this proposal.** Until it is, explicit in-place
   poisoned-store recovery is `RECOVERY_REVIEW_REQUIRED`, not an available runtime
   repair. Merely deploying a new constructor while leaving an old writer alive
   does not satisfy this gate. Normal future zero-audit initialization with the
   reviewed runtime remains a distinct proposed path, not authority to migrate
   an arbitrarily active legacy store.

Required tests use two real SQLite connections and retained old/new helper
instances: attempt a BEGIN after proof adoption; pause between a durable BEGIN
and its clinical transaction while adoption occurs; race completion and recovery;
and prove exact old audit/reservation bytes remain unchanged on rejection.
An intentionally unguarded legacy-writer fixture must make in-place recovery
refuse before bootstrap/clinical writes, not produce a false recovery success.
Unsupported-writer capability detection and the operational offline procedure
remain explicit pre-code review decisions; no automatic migration fallback or
service-control implementation is authorized here.

## 12. Root implementation disposition

Root read the original proposal and complete §§10–11; independent review cleared
the exact graph and requested the explicit provisional/marked distinction now
included in §10.3. Approve red-first implementation of the described future
zero-audit initialization, authenticated adoption and supported-runtime authority
checks in isolated technical stores. Preserve all old clinical/audit bytes and
AAD. This is not acceptance or permission to migrate an operational store.

In-place poisoned-store recovery remains unavailable with RECOVERY_REVIEW_REQUIRED:
unsupported writer exclusion has not been demonstrated. No service stopping,
operational key creation, legacy-store repair or automatic recovery is authorized.
The maker must freeze source and preservation/race/error evidence for independent
review before product acceptance or a new installer can use these changes.
