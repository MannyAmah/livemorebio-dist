# Atlas renderer: independent browser acceptance plan

Date: 2026-09-08. Status: **ROOT-REVIEWED PLAN; harness implementation authorized, independent harness review required before execution.**

Parent: the approved Atlas conversion/cache/renderer packet, its root-owned renderer review corrections, actual publisher install acceptance, and the full R01–R51 register. This is the bounded rendered-reference acceptance gate, not the full living Atlas, physiological qualification, an experiment video or public redistribution clearance.

## 1. Reviewed evidence and exact boundary

Read completely for this proposal:

- `2026-09-08-atlas-reference-conversion-renderer-packet.md` (403 lines), including the skin-first, source-preserving, warm-render and disposal gates.
- `2026-09-08-atlas-renderer-review-corrections.md` (96 lines): canonical membership order, unavailable controls and operation acknowledgment remain independently testable.
- `2026-09-08-atlas-publisher-install-acceptance.md` (144 lines): one real source installation and independent decoded-array verification, not a WebGL pass.
- The renderer implementation lesson and genuine-browser-visibility correction; the all-page visual inventory remains the broader acceptance ledger.

The report-only `/qa-only` skill was read completely to guide evidence, reproduction and independent grading. This preparatory engineering plan inspects the explicitly assigned renderer/consumer seams; it is not a claim that the skill's black-box browser pass has occurred. `/browse` must be read completely before the later browser work. Existing approved Chrome/SwiftShader and original-session visibility safeguards are reused rather than changing a browser installation. Connected CE/gbrain tools were not available in the preceding inventory; no unavailable invocation is claimed.

The actual retained manifest is `8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a`, source `bp3d-4.0-20130619-surface-core-v1`, receipt `083b2f038e74476ebfcef07e4a22f7c2`. The source has 489 elements, nine partitions, 957,072 triangles and 24,779,652 GLB bytes. Do **not** reinstall, reconvert, change cache files, rewrite receipts or use other geometry.

Root reports independent correction clearance: 88 tests and the exact nine real GLBs/489 bindings/receipt passed. Root supplied the fresh candidate identity:

| Service | Startup source SHA-256 / process instance |
|---|---|
| All three | `c9fee6db135dfd338c2b793ac4c4f22936db3c692421f728196ecfd3693de47a` |
| Aegle, 8910 | `28fbb877-f42f-49e3-8197-a00983093d8f` |
| LIFE, 8911 | `4c4f352f-7fd3-43ae-bea3-e2573654d8c1` |
| Cendos, 8912 | `89c2a9b6-0dc7-4a20-a594-721bdddb3324` |

These are expected inputs to recheck, not permission to accept a later different process. A restart requires a new explicit identity and attempt. The canonical page is `/`, not `/workspace`. Root retained its mistaken `/workspace` navigation and separate bundled-Chromium WebGL-unavailable screenshot; neither is a successful rendered Atlas case. The latter correctly demonstrates unavailable controls in that environment.

## 2. Ownership and permissions

After plan approval, add only `tools/check_atlas_browser.cjs` and dedicated `livemorebio/tests/test_atlas_browser_harness.py`. Root/reviewer independently reads these before running or accepting results. No package/source/UI, vendor, service, cache, model or registry edit is authorized by this plan. The renderer maker does not provide the sole final grade: root reviews the ordinary screenshots and results; the release reviewer grades the harness/instrumentation boundary.

The harness owns a fresh Chrome process, contexts, pages, browser-only interceptions, timers and an exclusive output directory. It never connects to an existing profile, root's gstack browser or the user's browser. Every post-launch allocation is under an outer `finally`; browser closure occurs even if context creation, screenshot, receipt writing or inspection fails. No screenshots/reports are overwritten or deleted.

Use only `http://127.0.0.1:8910`, the same root-owned technical review store and its existing reference cache. Require explicit technical-only acknowledgment and root-confirmed screenshot-safe current workspace context before opening the product. If the current subject is not the explicitly approved fixture/reference preview, stop; do not activate/create a different person by API. No twin creation, experiment, session, intervention, biological reset, device command or actual source-install POST is in scope.

Source asset reads use the product's normal same-origin authorization. Local-session bootstrap may occur normally; do not read/print token files, cookies or authorization headers. Build/source checks occur before product inspection, before each test pass and after completion. Each route pass records only allowlisted paths, method/status/timing, static source digests and bounded renderer metadata, never arbitrary request/response bodies.

## 3. Three separate evidence passes

### A. Ordinary, unmodified product

Use an unmodified page and the genuine current backend/retained GLBs. Do not intercept or rewrite modules, API responses, assets, rendering calls, DOM, styles, camera state or context state. Ordinary user inputs and read-only DOM/resource timing inspection are allowed. The ordinary screenshot set is the visual acceptance evidence. Test-only instrumentation or failure fixtures cannot supply a missing ordinary screenshot or turn a failed real case green.

Confirm installed Chrome/Playwright versions and software-WebGL renderer. Use the already reviewed pinned original-session focus-emulation disable solely for genuine native visibility testing, preceded by the two blank-tab preflight; no `document.hidden` override, dispatched visibility event or global browser modification. Record this automation-environment setting accurately.

### B. Explicitly instrumented engineering measurements

The scene already returns `metrics()` with reference-only loaded counts, draw calls, triangle counts, renderer geometry count, DPR and CPU render-submission durations. The controller keeps this object private. Do not add a product global, export patient state or modify the product merely to expose tests.

Proposed test-private wrapper: intercept only the exact same-origin `/lib/atlas_reference_scene.js` request in one dedicated context. Serve a small wrapper that imports the **unchanged original bytes** from the same path with one fixed test-private query marker, reexports `atlasViewState`, and delegates `createAtlasReferenceScene` to the original once. Route the original-query request through unchanged. Before running, hash both fetched original bodies and require equality with the reviewed local module hash and runtime source fence. Fail if the route does not serve identical bytes or the expected named exports differ.

The wrapper must not substitute dependencies, constructor arguments, manifest, buffers, options, clocks, scheduling, return values, exceptions or source geometry. It delegates original methods with their correct receiver exactly once. Only bounded before/after scalar snapshots around `addPartition` and `dispose` may be collected. It retains the live controller solely through `WeakRef`; historical records contain numeric counts, static source IDs/digests, reference view settings, timestamps and an instance sequence, never the scene graph, DOM node, GLB arrays, function closure, person or clinical state.

Expose the bounded snapshot reader as a **wrapper-module-only named export**, retrieved by the harness via import of that exact intercepted module. Do not attach it to `window`, application state or a product DOM attribute. The original module and all rendering still execute as shipped. This pass is labeled `INSTRUMENTED_ENGINEERING`, and its screenshots are not the unmodified-product acceptance set.

Retain a wrapper SHA and exact original module SHA in the receipt. Tests must prove identity delegation, one original call, argument/return/exception preservation, bounded metadata, no patient/global export and weak ownership. If this is not demonstrably noninterfering, stop and propose another reviewed observation method rather than changing the product.

### C. Labeled, browser-local fault injection

Use a third fresh context for exact-route failure interception and intentional WebGL context loss. No actual cache is made missing/corrupt and no service is restarted. Screenshots/receipts are labeled `TECHNICAL_FAILURE_INJECTION`; they verify failure handling, not real upstream failure or successful source admission.

Use request aborts/delays where possible. For missing/acquiring/status-integrity and malformed install acknowledgment cases, use explicitly named minimal technical API fixtures only within this owned context, with `reference_geometry:true`, `patient_registered:false` and no model/person fields. Never fabricate a success mesh or physiological response. A selected install click is intercepted locally before network dispatch and produces the chosen rejected/malformed response; count and assert **zero actual install POSTs reach the service**. Real asset requests still use the exact retained bytes when recovery is exercised.

## 4. Preflight and mandatory stopping conditions

1. Validate explicit loopback URL, absolute new output path, technical acknowledgment, expected source, all three expected process IDs and admitted manifest digest before browser launch. No auto-discovery of a replacement service/source.
2. Verify installed Playwright 1.58.2/core 1.58.2 and the two source pins from the reviewed visibility helper. If they differ, no internal API fallback or package installation. A headed Chrome launch uses the existing `--use-angle=swiftshader` and `--enable-unsafe-swiftshader` reference configuration only.
3. Run the zero-product-network, two-owned-blank-tab trusted visibility preflight with outer cleanup. Record browser/OS/architecture, viewport, DPR, WebGL vendor/renderer/version and capability. SwiftShader is software rendering, not actual hardware-GPU or mobile-device qualification.
4. Read `/api/build` and `/api/services`, checking exact startup/current source, ports and fixed process identities. Verify relevant responses' startup build headers, not only a compatible JSON schema. Stop on source drift, static/runtime mismatch, changed process, unavailable peer or unapproved current subject.
5. Read actual static Atlas status without installing. Require the exact admitted manifest/digest/source/rights/counts; retain only static reference metadata. If not available, retain the real failure and stop the success run. Browser fixtures cannot repair this preflight.
6. Bound each wait/action/request and the total pass. A performance threshold failure is recorded at its original time even if the harness waits longer to capture the failure. No source or triangle reductions, automatic install retries or increasing thresholds after inspection.

## 5. Ordinary rendered/control matrix

Inspect the current visible DOM before selecting each control and after opening drawers. Use current labels/roles; the selectors below identify reviewed seams, not permission to skip inspection.

| Case | Required visible behavior and evidence |
|---|---|
| Initial `/` | Approved green header, left multiscale path, separate readouts/time/response panels, intact full-height source skin, no montage/illustration or patient-registration claim. `#atlas-reference-host` must reach nine drawn groups. |
| Source progression | Observe skin submitted before internal requests, per-layer pending/ready states and no more than two internal requests in flight. Capture natural first-surface state if possible; otherwise retain its measured transition and capture deliberately delayed internals only in pass C, not mislabel it ordinary. |
| Front / Side / Back | Click all `[data-view]` controls; head/feet remain in whole-person framing, correct source-native orientation, brain above thorax, heart/lungs and abdominal components in the admitted arrangement. Inspect source bounds/IDs, not claim clinical anatomical accuracy. |
| Source selection | Select skin explicitly; search and select actual heart/pancreas/right-kidney/left-kidney element IDs from the admitted manifest and visible results. Verify exact FJ/FMA IDs, source hash, counts, IS-A versus PART-OF, visible selected highlight, frame-selected view and drawer text. Do not guess IDs or click an off-screen imaginary organ. |
| All nine layers | Toggle each off/on once, verify corresponding rendering/labels/control state and restored count. `loaded_groups` is not visibility count; use renderer and view evidence, not an incorrect count assertion. No scalar-dependent biological tint or transforms. |
| Isolation / return | Select an available source element, isolate, frame, return to whole person and use header `#body-home`; visible view and section/isolation controls agree. Source installation and model quantities are unchanged. |
| Labels | Toggle `[data-labels]` and header `#body-labels`; labels are actual reference group labels, aliases agree and source geometry remains unmodified. |
| Sections | Exercise off/x/y/z and representative depths 0/.5/1 via visible controls. Check anatomical axis labels, output in world meters, visible clipping and Home reset. Clipping does not cut/repair stored vertices. |
| Appearance | Change skin opacity .05/.24/1; explicitly appearance-only; availability changes correctly when skin is hidden or a non-skin element isolated. |
| Mouse / keyboard / touch | Real drag orbit, wheel zoom, focused-canvas arrow keys and plus/minus produce visible camera changes without source-array changes. Test touch input in a separately labeled browser mobile-emulation context; not physical touch-device acceptance. |
| Search edges | Empty query, no result, bounded first-30 result list and a real long source name; selection disabled until its partition is available. No arbitrary HTML/source text execution. |
| Source drawer | Read source/release/axes, all three source-file hashes, converter identity, selected member provenance, BY4 plus retained historical notice and limitations. Drawer stays bounded beside the scene. |
| Biology link | Follow existing `#open-biology-context` with the root-approved safe current context; verify exact URL/context and reference-versus-numerical distinction. Return through ordinary navigation. Do not claim this completes Gate B native execution binding. |
| Independence | Readouts, evidence drawer, biological-time controls and primary product links remain present. Scene controls cause no mutation request or new numerical run; the body does not spontaneously pulse, orbit or deform during a 5-second idle sample. |

Compare ordinary desktop screenshots directly with `approved-merged.png`, `variant-A.png`, `variant-B.png`, `approved.json` and `feedback.json` in `/Users/emman/.gstack/projects/MannyAmah-livemorebio/designs/multiscale-human-workspace-20260830/`. Keep Option C preserved. Reference mockup example values are not acceptance target measurements. List discrepancies; do not call this bounded packet complete A+B or all-page parity.

## 6. Warm rendering, source integrity and resource measurements

At 1440×1000 and 390×844, perform three fresh-page warm-server-cache trials, preserving every trial rather than selecting the fastest. No browser cache bypass trick or network throttle is used to improve results; actual assets remain no-store. Report navigation→status, first asset request→nine ready, status accepted→nine ready and skin response-end→first drawn/next paint opportunity separately. The preregistered gates remain skin visible within 5 seconds after its response ends, all nine partitions within 15 seconds from the asset-loading phase, and p95 controlled-camera frame duration ≤50 ms. Do not quietly exclude slow status/auth from end-to-end figures.

Use same-origin Resource Timing/network completion and ordinary DOM transitions for pass A. A DOM ready flag alone is not a visible-body pass: root inspects ordinary screenshots. In pass B capture the original scene's first skin submission and the next browser frame opportunity; report this as CPU/browser timing, not proof of GPU completion.

For each viewport, perform at least 120 rendered samples during bounded actual camera input, with a maximum 20-second sampling period. Record the input sequence, all render-submission duration samples, rAF intervals during active input and long tasks separately. Existing `metrics().frame_ms` measures time spent inside `renderer.render`, **not full presented/composited frame time**. The ≤50-ms user-facing frame gate uses the observed active-input browser-frame interval distribution alongside CPU submission data. Neither supplies a hardware GPU timer or display scanout measurement. Insufficient samples or unsupported observation is `NOT_MEASURED`, never a pass.

Require exact 489 loaded source elements/nine partitions and exact total source triangles/asset byte digests. At all-layers/front/no-section defaults report `renderer.info.render.calls` and submitted triangles as measured, not assume transparent rendering calls equal 489 or that culling equals source totals. Pixel ratio must be ≤2 and match the declared device/browser setting. No triangle decimation or per-organ transformation is allowed to meet performance.

During five successive **same-page explicit Retry/dispose/reopen** cycles, first set selection, camera, labels, axis/depth, layer visibility and opacity through actual controls. Each cycle must dispose the prior scene, cancel old requests, create exactly one replacement, reach the same source counts and restore compatible view settings. Retain scalar before/after metrics and source identities. No stale prior-scene append, duplicate canvas or extra visibility handler is acceptable.

After each disposal inspect renderer geometry count, wrapper instance/dispose balance and old-controller weak reachability without retaining strong objects in the wrapper. A separately declared CDP garbage-collection observation may confirm old weak references clear; it is not used during performance timing. Read CDP aggregate DOM/listener counts or scoped listener counts, release all remote handles promptly, and compare settled baselines across cycles. Do not save raw heap snapshots or claim these counts prove total GPU-memory absence. If memory/GC counters are unavailable, report that resource subgate unverified. No forced product cleanup call substitutes for the user Retry path.

## 7. Failure, recovery and cancellation matrix

| Injected case | Required boundary |
|---|---|
| Missing metadata | No geometry/placeholder, explicit reason and install guidance; all scene-dependent controls and both header aliases disabled; metadata/Retry available; no automatic POST. This is a technical missing-state fixture, not deletion of the real cache. |
| Acquiring metadata | Explicit pending, disabled install, no second installation. Two owned tabs may observe the same fixture; no actual lock/cache change or cold-install claim. |
| Skin request failure | No automatic framing of detached internals; surface error and disabled controls; valid independent readouts stay available. Remove interception, explicit Retry renders real skin and nine groups. |
| Delayed / failed heart | Skin remains intact; correct partial count; only drawn layers/selectable results available; absent partition controls disabled. Release delay or remove failure, explicit Retry restores all nine exact groups. |
| Bad status/member/source metadata | Integrity error, not silent substitute source. Existing source-backed retained geometry can remain inspectable only under its explicit reference-only error message. No fabricated alternate manifest accepted to exercise source change. |
| One-byte asset tamper in browser | Exactly one isolated response copy fails its original hash; never alter cache bytes or hash headers to make it pass. No damaged geometry appended; later clean Retry recovers same source. |
| Vendor failure | Abort only local vendor request; useful unavailable message, no no-op enabled controls. Remove interception and Retry; immutable geometry/readouts independent. |
| Actual WebGL context loss | Use the owned canvas's `WEBGL_lose_context` extension in pass C, not manually dispatched events. All affected controls disabled, visible error, no ongoing draws; explicit Retry creates a working context and restores same-manifest settings. Lack of extension is untested, not simulated by an event. |
| Hidden during load / loaded view | Native same-window tab switching, trusted visibility events. Pending fetches are canceled, old results cannot append while hidden; no draws while hidden. Return refreshes the same source and only resumes legitimate loading. |
| Navigate away during load | Abort only the owned delayed asset, navigate normally and return; disposed scene cannot append into a new page/context, no duplicated requests/canvas. No deliberate HTTP response changed to another person. |
| Status 401 / unavailable | Existing authentication cancellation remains bounded; failed status does not silently show a new available source. Recovery is explicit, no mutation replay. |
| Unconfirmed install response | Intercept the exact POST locally, return malformed200 or response loss, then return actual available status. Keep persistent unconfirmed acknowledgment separate from readable geometry, assert one attempted/zero upstream POSTs. Do not synthesize a valid new receipt. |
| Populated acknowledgment at 390px | In a separately labeled fixture, reuse the exact already retained static installation receipt/status as the intercepted response, never invent a new receipt or claim a new service acknowledgment. Visually inspect both valid populated `[data-install-ack]` (64-hex digest and32-hex receipt) and unconfirmed/error text at390px: wrapping, clipping, page overflow and keyboard reachability. Root identified missing ACK-specific wrapping as a possibility to verify, not an assumed defect or an authorized CSS edit. |

Changed-manifest reset is already covered by strict technical controller tests. The real cache exposes only one admitted manifest; do not manufacture another successful geometry manifest or mutate the active pointer just to obtain a browser screenshot. Report that browser case as not exercised on a second authentic installation, with the existing unit evidence separately linked.

## 8. Responsive and accessible inspection

Walk 1440×1000, 1280, 768 and 390×844 widths in the ordinary product, including expanded controls, source details, selected long names and labels. Require no page-horizontal overflow or clipped active controls/selection details; canvas stays within its panel. Check 200% **actual browser zoom** using ordinary browser keyboard controls and verify effective CSS viewport/DPR change. CSS `zoom`, a smaller viewport alone or page-scale emulation cannot masquerade as browser zoom; unsupported shortcut observation is a retained blocker for that subcase.

Use keyboard Tab/Shift+Tab, Enter/Space, Escape where applicable, native selects, visible focus and screen-reader names. Confirm disabled controls cannot be activated through header aliases or keyboard. Check reduced-motion preference does not create motion or prevent deliberate controls. Mobile-emulated input and SwiftShader do not qualify physical devices, accessibility conformance or actual hardware GPU support.

## 9. Harness red tests, receipt and independent gate

Before implementation, write failing pure harness tests for:

- Wrong URL/source/process/manifest/current-fixture scope rejected before product navigation; no replacement discovery or source installation.
- Renderer wrapper import marker/source-hash mismatch; exact one-call semantics; preserved return/error; no strong historical scene/DOM references or biological data capture; no wrapper in ordinary pass.
- Fault interception cannot escape its exact route/context, call the real install endpoint or substitute geometry; one-POST uncertainty checks survive later successful status.
- Source/triangle count mismatch, fewer than120 timing samples, threshold violation, unavailable metric, failed dispose cycle and process drift cannot emit an overall pass.
- Context/page creation failure, screenshot/write failure, native-visibility failure and midcase exceptions close the owned browser independently of evidence-write success and retain any possible failure receipt.

After independent harness review, root or the delegated independent reviewer executes a new unique `docs/screenshots/full-scope-recovery/atlas/attempt-N/` directory. Separate `ordinary/`, `instrumented/` and `faults/` screenshots and metrics. Save bounded action ledger, per-case state, exact build/process/browser/source identities, static hashes, timings/counts, context/fault labels, console/network error categories and resource-cleanup outcome. Screenshot an issue before/after, reproduce once in a new bounded case and preserve both outcomes; never retry a source mutation.

Root must personally view ordinary first/front/side/back, selected/source, clip/isolation, mobile and 200%-zoom screenshots and compare the approved images. Automated screenshots are not reviewed evidence until viewed. Formal browser QA reports enumerate untested/failed cases and distinguish technical injected errors from unexpected page errors. The scope cannot receive `ACCEPTED_SOFTWARE` if it only reaches charts/fallback, silently misses source groups, fails the warm budgets, exposes no-op controls or leaks retained scenes across five cycles.

Expected implementation/run order: plan approval → red harness guards → harness implementation → independent source review → fresh identity recheck → ordinary pass → instrumented/fault passes → root visual grading → bounded report/lesson. No model, device, patient-registration or full-platform validation claim follows from this reference-renderer acceptance. R21–R27/R46 and all missing native spatial, multiscale and physical capabilities remain explicitly active beyond this packet.

Root read this complete 153-line proposal. The three evidence contexts, original
module hash fence, weak metric ownership, actual-input/render timing distinction,
immutable source and no-upstream-install rules are accepted. The bounded harness
and red-first guard tests may now be implemented. Runtime/package source stays
frozen at the stated build; no harness failure licenses changing the product,
relaxing a performance threshold or calling another source installation.

## Harness implementation and independent-review handoff

The approved harness is now `tools/check_atlas_browser.cjs`, with seven dedicated
guards in `livemorebio/tests/test_atlas_browser_harness.py`. Six initial tests
failed before the harness existed (0.41s). A subsequent source-identity regression
went red twice while correcting Python `Path` component ordering and its exact
eight-byte filename-length prefix. Both are part of the producer's hashing
contract; neither permits a different runtime source. One read-only diagnostic
script initially lacked its local `assert` import and was corrected; no product
operation was involved. The final Node hash independently matches the actual
Python source fingerprint `c9fee6db135dfd338c2b793ac4c4f22936db3c692421f728196ecfd3693de47a`.

The seven new guards plus nine existing continuous-browser guards pass together:
**16 passed in 1.08 seconds**. `node --check` also passes. These are maker tests,
not independent browser or visual acceptance. The source/runtime is unchanged.

Root separately confirmed the technical workspace is registry twin
`twin-07bfab3bb80e4d869975e76c85bc6c5a`, version8, source class `SYNTHETIC`, subject
`pseudonym-private-browser-lifecycle-check`, label
`Technical browser lifecycle check — not a participant`. The harness fences all
of these before screenshots and checks the unchanged context throughout. It
cannot create or activate a replacement source. The actual root-owned source
reuse/SDK/CLI tests are separate evidence, not a browser operation by this lane.

The harness leaves every screenshot `VISUAL_REVIEW_REQUIRED`; an automated
boolean cannot supply root's landmark, readability or approved-image comparison.
It separates ordinary, instrumented and failure-injected contexts, enforces no
upstream mutation, retains failed cases and stops at its35-minute case boundary.
Individual browser/API waits remain separately bounded. The module-local wrapper
stores weak controller references and bounded scalar geometry metrics only.
Original factory/method arguments, receivers, results and failures are delegated
without replacing source buffers, native coordinates or render scheduling.

Connected context7 was unavailable; the installed pinned Playwright type/API
documentation and the independently reviewed existing harness were inspected.
The `/browse` skill was read completely before this handoff. No browser was
launched and no publisher bytes were acquired/reconverted. Independent harness
review and explicit run clearance remain required.

Compounded lesson: cross-language source-identity verification must match both
ordering and framing bytes. An almost-identical hash algorithm can falsely reject
an unchanged candidate; compare against the actual producer using a tiny fixture
and a read-only full-source check before diagnosing runtime drift.

### Root-confirmed evidence-retention correction

The first harness candidate, SHA
`c6bad25f3580bccb4e6731b69a9a57bc927f1a8422707a78cf83e05a3ecfbe62`,
is retained in this review history as **not accepted**. Root independently found
that warm/frame-budget operations asserted before returning their metadata.
`caseRun` therefore kept only a generic failure and discarded the measurements
that explained it. Earlier concurrency/count and insufficient-frame assertions
had the same defect. No browser was run against that candidate.

Root authorized a harness-only correction under the existing approved retention
requirement. Three new guards failed first (0.32s); a fourth camera-input-failure
guard then failed before its bounded partial-sample reporting existed (0.15s).
The new case-scoped recorder persists fixed, allowlisted reference measurement
shapes before deadline, warm load/count/concurrency, sample, p95 and resource
assertions. Failed warm waits retain observed requests and null unavailable
times. Failed camera input retains initial draw counts and already available
frame samples. Every Retry cycle writes its baseline/current counters and view
before validation; no raw clinical values or exception text are retained.

Nonfinite diagnostic samples are recorded as explicit null, not silently clipped
to a passing number. Arrays/cycle records are bounded. The unchanged gate still
fails when its required sample count, timing, identity, geometry or disposal
condition fails. Screenshots remain a separate, subsequently reviewed artifact.
The correction does not change product paths, input sequences, thresholds,
source/runtime, models, caches or mutation authority.

The corrected harness passes **20 new/preserved tests in1.52s**, including the
four new failure-retention regressions. `node --check` passes. Independent review
of the corrected candidate and explicit browser-run clearance remain pending.

### Monotonic camera-sampling deadline amendment, before correction code

The independent reviewer then found a second harness defect in candidate
`4cceb44330946396ff1aeb611c9385137cb34735218ef1f2a6f047874a60d8a5`:
the rAF promise could remain pending while hidden, delayed mouse operations could
cross the20-second sampling limit inside a nested loop, and the final predicate
did not reject an overlong elapsed duration. Root authorizes the following
harness-only correction; the earlier candidate remains unaccepted in this record.

- Start one Node monotonic deadline of exactly20,000ms at measurement admission.
  It never resets per input, frame, viewport, retry or observation. Validate
  elapsed time as finite, nonnegative and≤20,000ms in the final timing predicate,
  in addition to the unchanged skin≤5s/all-layers≤15s/≥120 samples/p95≤50ms gates.
- Bound every awaited measurement operation against the same remaining time,
  including recorder creation, each mouse movement/down/up/wait, final recorder
  read and metric read. Check the remaining time within the inner loops, not
  only after a complete back-and-forth sequence. The existing deliberate input
  pattern and approximately11-second collection target remain unchanged.
- Replace the one-shot10-second rAF promise with a private JavaScript-handle
  recorder. It owns only its frame timestamps, rAF callback and timeout, exposes
  bounded stop/snapshot methods through that handle and never attaches to the
  page/application global. It starts with the CPU sampling window and stops when
  actual input ends; both CPU samples and rAF samples therefore describe the
  same bounded window, not an early10-second trace versus later delayed input.
  A local timer stops its own callback by20s even without another rAF tick.
- A Node deadline or failed measurement stops issuing inputs immediately and
  cancels/settles the recorder. On expiry, close only the **exact harness-owned
  page** with `runBeforeUnload:false` to cancel in-flight browser input/evaluation;
  verify page/context/browser ownership first. Never touch a shared page, service,
  model, source or OS process. Do not issue an unbounded cleanup mouse-up after
  expiry. Closing the page makes this attempt fail and ends further work on it.
- Treat page-close/pending-operation settlement as a separate bounded cleanup
  phase (5 seconds), not extra measurement time or a passing sampling window.
  Attach rejection handlers to all outstanding operations. If settlement cannot
  be confirmed, retain `CLEANUP_UNCONFIRMED`, fail the attempt and let the existing
  owned-context/browser finalizers run; no successful cleanup claim or retry.
- Persist the elapsed deadline state and all already available bounded samples
  before assertions/cleanup. Use null for inaccessible samples; do not fabricate
  late frames, force visibility, truncate a failing elapsed duration to20s, or
  relabel a lost recorder as120 accepted observations. Dispose recorder handles
  and cancel both timers. Unexpected error text remains excluded from evidence.

Red-first cases:25,000ms/nonfinite/negative elapsed rejected; a never-resolving
rAF/input operation reaches the fixed deadline and closes only the owned page;
the inner loop cannot issue another input after expiry; partial evidence survives;
pending promises settle or are explicitly unconfirmed; normal completion clears
timers/handles and records the same actual sampling window. Fake clocks/browser
stand-ins test these branches without a real browser; actual acceptance still
requires independent source review followed by root's explicit run clearance.

### Monotonic deadline implementation checkpoint

The three named deadline regressions failed first (**3 failed,11 deselected in
0.30s**): `test_atlas_timing_rejects_elapsed_outside_fixed_measurement_window`,
`test_atlas_measurement_deadline_cancels_owned_page_and_settles_pending_input`,
and `test_atlas_private_frame_recorder_stops_without_a_future_raf_or_global_export`.
An additional failure-path test then exposed skipped handle disposal after a
recorder-stop exception (**1 failed,2 passed,14 deselected in0.30s**); cleanup now
attempts each remaining owned cleanup independently and reports unconfirmed
cleanup rather than masking the failure with a success state.

The implementation has one20,000ms monotonic budget covering all measurement
commands. It checks immediately before and after each command, so a late response
cannot pass merely because the Node alarm callback has not yet run. Expiry closes
the exact owned page, starts no more input, and waits at most5s for the pending
command and close response to settle. A hung close/command reports
`CLEANUP_UNCONFIRMED`; the original bounded partial sample stays in the receipt.
The fake clock parameter is test-only and has no environment/CLI override.

The private handle's browser-local recorder reads CPU draw counters at its start
and stop, alongside its own rAF intervals. Its independent timer stops the rAF
callback without needing a future tick. Normal completion stops it once and
disposes the handle; the final sample retains both Node elapsed acquisition time
and the recorder's measured window, without truncating an overlong value.
No application global, patient state, source buffer or render method is changed.

Mounted no-browser probes cover late input returning at25,000ms before alarm
dispatch, a stalled recorder read canceled at20,000ms, and normal approximately
11-second collection with preserved frame counts and cleared timers/handles.
The original p95/skin/all-layer/frame-count thresholds are unchanged. The combined
new/preserved harness matrix is **29 passed in2.14s**; `node --check` passes.
Read-only package fingerprint verification still equals
`c9fee6db135dfd338c2b793ac4c4f22936db3c692421f728196ecfd3693de47a`.
No browser was launched, publisher asset installed, service restarted or runtime
file modified by this correction. Independent review and actual browser/visual
acceptance remain pending.

Compounded lesson: a per-input timeout and an elapsed check between loops do not
enforce a measurement window. Deadline ownership, cancellation settlement and
the final elapsed predicate must agree; all three need adversarial tests that
retain the failed measurement, not only happy-path frame statistics.
