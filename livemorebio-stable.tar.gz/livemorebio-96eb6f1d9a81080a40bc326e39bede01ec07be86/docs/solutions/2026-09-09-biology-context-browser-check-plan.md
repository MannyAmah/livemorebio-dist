# Ordinary Biology: private data-recovery browser check

2026-09-09. Narrow actual-page QA after independent controller review. This is
not a retry of the paused molecular-coordinate check and does not waive its
three real cancellations. No molecular structure request or biological engine
execution belongs to this check. The product-wide visual/experiment gates remain.

Serve the unchanged current biology.html and its local JS/CSS from a fresh
GET-only loopback server. Use explicitly authored technical context/organ
responses, no participant/operational store. The session-bootstrap response is
a declared fixture; this check cannot validate real authentication. Services
remain unavailable and build identity remains unavailable rather than inventing
an all-systems-operational claim. Block foreign requests; record those expected
blocks. Intentionally disable WebGL to exercise the documented independent
readout/recovery path. Do not claim atlas/organ geometry acceptance from it.

Use the already reviewed pinned Playwright fallback and existing owned-resource,
deadline and exact-child supervision helpers; no browser/tool upgrade or new
general framework. Preserve actual page source bytes. No direct application
function invocation, DOM replacement or screenshot synthesis. Browser clicks,
normal polling, status readouts and screenshots are the verification surface.

Check desktop and portrait states: initial reference organ overview; open heart
detail and its reference cell; accept a response removing heart and verify old
detail/cell closes; preserve the remaining kidney; reject an invalid context
on polling without replacing confirmed detail; block cell entry while stale;
use visible Retry data to recover; retain actual before/after screenshots.
Inspect the screen captures independently and preserve errors as failures.

Bound the check to 60 seconds work/15 seconds cleanup, at most 128 GETs,
32 MiB served, six screenshots/16 MiB screenshot bytes and 64 MiB total evidence.
No retries of the complete run. A fresh private process/port precheck and exact
owned cleanup apply; no uncertain process is signaled. The QA runner and source
hashes are reviewed/frozen before the one actual invocation. No clinical/science
claim, model change, device action, existing experiment mutation, commit or push.

## Private implementation inventory before code

Release-redteam owns only the fresh `/private/tmp/livemore-biology-context-qa.PHua9I`
runner, wrapper, authored inert tests and manifests. Root independently grades
all bytes before any actual run. The original page remains pinned to
`5b2fd6284ec1517407110c31f818c79f8860206fa7457d18eb1f536efab9f1f6`.

Use six fixed stages/screenshots: initial overview, heart reference cell,
removed-heart overview, stale kidney detail after rejected context, recovered
kidney detail, portrait kidney detail. Data changes are only a Node-owned fixed
fixture phase; removal and malformed identity arrive through the normal 8 s
poll. Recovery uses the actual Retry data button. No injected application call,
DOM replacement, alternate HTML, coordinates, `/api/state` or model request.

The reference-preview READY envelope is explicitly an authored software fixture,
not an actual ready model. All displayed numerical quantities are null and both
cells use the existing reference renderer. This permits the removal check to
exercise membership closure rather than the separate close-on-UNAVAILABLE path.
Session bootstrap is a fixed empty 204 fixture, services are all down, and build
identity returns 503. These are not authentication or health acceptance.

Serve only the exact local page/static-import/CSS closure, plus the four fixed
fixture GET paths and an empty favicon. Deny all mutation, body-bearing, unknown
local, coordinate and foreign requests. Only the page's two exact external
stylesheet URLs are labelled expected scope blocks; other failures stay fatal.
Disable WebGL constructors in an explicitly declared context-init fixture, not
by replacing application functions or altering source/DOM. This is not graphics QA.

Reuse USnuJu's guarded-import `owners`/`workBudget` and the existing Atlas exact-
child/listener helpers. Browser work remains 60 s and owned cleanup 15 s. The
parent reserves up to 10 s preflight, an 80 s child watchdog, 15 s terminal
settlement and 5 s evidence finalization, with an outer 110 s refusal bound.
These bookkeeping ceilings do not extend the browser work/cleanup budgets.

Inert tests come first: exact GET/path/body admission and expected-block identity;
fixed fixture semantics/phase transition; real handler response statuses and
bounded counters; original screenshot count/byte limits; mounted workflow click,
normal-poll and phase ordering with negative checks; parent malformed/missing/
failed receipt admission, image/source preservation and exclusive-run guard.
Tests refuse network and browser/child launches except the one allowlisted
Node test process. No actual run is created while authoring or testing.

## Frozen private implementation and maker receipt

Root accepted the authored READY/reference-preview envelope and the separate
parent bookkeeping ceilings before implementation. Root subsequently requested
an original failure screenshot within remaining work and the existing six-image/
16 MiB ceiling, plus bounded original public-fixture error details. Both are
included: unavailable work/page/slot is explicit, never a budget extension;
page and unexpected-console counters are never suppressed. The first eight
details retain name/message/scoped location (each truncated at 512 characters,
with a truncation flag); foreign or credential-bearing locations are not copied.
The exact declared build-503 resource console text is retained separately only
when its URL and observed response/served status match. Expected network failures
remain only the two exact external stylesheet requests blocked by this runner.

Private directory: `/private/tmp/livemore-biology-context-qa.PHua9I`.
No product or prior private runner was changed. No `run` directory exists.
The static inventory is the unchanged page plus 20 local JS/CSS files; dynamic
graphics, external viewer script, structures, numerical APIs and store routes
are absent. The helper child independently read this closure; no execution was
needed for that source inventory. The manifest additionally pins five runtime
entry files and the three reviewed ownership/supervision helpers, not a claim
that all dependency images or actual authentication have been attested.

All original RED receipts remain in tool output, not invented disk receipts:

- `5d9ed5`: initial 17 Node failures because the new implementation module did
  not yet exist; Python not reached. This is harness RED, not product failure.
- `6b3e73`: 17 Node passed; all six original Python cases errored because the
  parent module did not yet exist.
- `b2a30d`: original 17 Node + 6 Python passed, 0.211 s wall.
- `f610a3`: requested failure-image boundary was 1 RED / 18 preserved Node;
  `edae57`: 19 Node + 6 Python passed after implementation.
- Four additive parent preservation cases check exclusive consumed-root refusal,
  source hash/metadata identity, original image bytes/viewport, and duplicate
  receipt-key refusal (`0f77d1`, 19 Node + 10 Python passed).
- `7601c8`: requested bounded error details were 1 RED / 19 preserved Node.
  Final `21c0a7`: **20 Node + 10 Python passed**, 0.199 s wall, no skipped cases.
  No browser, service, model, network or operational-data operation was invoked.

Frozen files (SHA-256):

| File | Lines | SHA-256 |
|---|---:|---|
| `check.cjs` | 176 | `cfd2fd3524ae72dc7c0e98919ceb6b8a0029d1086946d87eedd5b0fc367834b9` |
| `check.py` | 146 | `3ca5d4f9750874b6636bc8534f5aa62c478b66fcec16d4fdb1a01a188dc50e5b` |
| `test-check.cjs` | 93 | `0ba5db24cdae836581a24ab26e8f3de67fd1ab536fe5798c5b9182429cc44484` |
| `test-check.py` | 53 | `34054a1ca04951856715ad7424b694fdd39a5da4a2a20048bd928d6557362ef9` |
| `run-inert.py` | 34 | `e3094923a9309c49f817d670ecf276870ee428d8a3cd57bcab67e4f3243cf75e` |
| `inputs.json` | — | `8624add7a966c3e442b9efef0f6f34c6d2a4710cb9f19a6c5757f2bc1cd066f7` |
| `harness-pins.json` | — | `8fbcf6ccff24147cbae47c397ec5b6300db5d062d5c1acc535a68001dc25f0d7` |

Read-only verification `f0e486` matched all 29 input and six harness rows in
size, exact decimal-string nanosecond metadata and full content SHA, and confirmed
`run_absent=True`. The input page still has the original approved `5b2fd628…` SHA.

Exact independent **inert** repeat (only the allowlisted Node test child):

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-biology-context-qa.PHua9I/run-inert.py
```

Prospective one-shot command, **not authorized or executed by this receipt**:

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-biology-context-qa.PHua9I/check.py --run-once
```

Root must read and independently grade the source/tests/pins, then make any
separate actual-run decision. These inert checks establish only this finite
harness contract; they do not establish browser usability, graphics, biology,
real authentication, molecular transport recovery, or completion of R01–R51.

## Root actual decision and result

Root read the full frozen sources, tests and manifests and repeated the inert
command: `c25859`, 20 Node + 10 Python PASS. Root then separately authorized
and invoked the one-shot command above (`906a00`, completion `5d324f`). Its
exclusive run directory is now consumed and must not be reused or edited.

The six interaction stages and captures passed, but the complete result is
**FAILED**, exit 1. One local request failure lacks the identity/error needed
for attribution; two declared blocked styles emitted an unrecognized exact
`.Inspector` error suffix. Both remain recorded, not retroactively waived.
Root inspected all six original images and independently found all twelve
recorded PIDs absent. Detailed preserved result, limits and receipt hashes are
in `2026-09-09-biology-context-reconciliation-implementation.md`. No graphics,
physiology, authentication or whole-product acceptance follows from this check.

## Minimum failure-evidence correction — plan before code

The independent audit establishes an evidence gap, not a product transport
cause. Permit a fresh private successor of this finite runner, preserving
PHua9I byte-for-byte. Change only the following diagnostic fields/classification,
with RED-first tests and root independent review before any actual invocation:

1. In the existing request callbacks, retain a bounded request-object identity
   ledger for scoped local requests: integer ID, exact admitted route (never
   credentials/body), method/type, request/response/finished-or-failed event,
   existing workflow stage and monotonic receive offset. Retain actual response
   status and failure error text (at most 512 characters). Keep at most 128
   requests and a fixed bounded event count under the existing receipt ceiling.
   Unknown routes are recorded as refused enums, not copied. Missing/duplicate
   terminal, malformed or overflow evidence must remain a failed check.
2. Recognize only the additionally observed exact stylesheet error text
   `Failed to load resource: net::ERR_BLOCKED_BY_CLIENT.Inspector`, for the
   two existing exact URLs and only when that request was actually blocked
   by the runner. Keep other errors, including local failures, fatal. The
   original PHua9I console errors are not retroactively reclassified.
3. Preserve the page, all six clicks/polling phases, authored fixtures, private
   origins/routes, body handling, work/cleanup/image limits and owned-resource
   protocol. No CDP attachment, body observer, fetch replacement, extra request,
   retry loop, relaxed source pin, new renderer or product mutation. Reuse the
   existing reviewed helpers and parent; repin only new private successor files.

This permits offline diagnostic implementation only, not a run. A subsequent
single actual run needs a separate root decision after exact source/pin/test
review. Non-reproduction would not fix or excuse the original local failure.
The purpose is to identify its boundary before deciding whether any product
correction is warranted, not to build another general QA system.

## Frozen request-evidence successor — offline maker receipt

Fresh private root: `/private/tmp/livemore-biology-request-evidence.1xHVWj`.
PHua9I and its consumed failed result remain untouched. The only checker changes
are the scoped request-object ledger, exact blocked-style console classification,
and the explicitly approved prospective page pin. The original six-phase
workflow, GET/body handling, fixture data, all limits and ownership helpers are
unchanged. `check.py`, `test-check.py`, and `run-inert.py` are byte-identical copies;
the original 20 Node tests are an exact byte prefix of the new test file.

The ledger holds at most 128 local request identities and 384 lifecycle events.
Response association uses the actual matching Request object, never URL matching.
It retains finite monotonic receive offsets, workflow stage, scoped route,
method/type, actual status and up to 512 original failure-text characters plus
a truncation flag. Expected foreign styles are not relabeled local requests.
The explicit cutoff removes only the four added listeners and preserves pending
IDs. Missing, duplicate, unobserved, malformed and overflow evidence remains
fatal, as does every local request failure. No CDP, fetch/body interception,
server lifecycle expansion or new browser request was introduced.

Root additionally approved a RED-first `EMPTY_REQUEST_EVIDENCE` guard: a wholly
absent observation stream must not pass vacuously. Finalization requires the
observed `/biology` request, with the existing terminal rules. Only the two
new positive fixture setups gained a completed navigation; the original tests
and the new same-route-object assertions remain. Context7 was unavailable;
the retained Playwright declarations for Request/Response and the four page
events were read as primary API documentation. They distinguish response
headers from body completion and permit failure after a response; this ledger
does not infer success from HTTP status alone.

Retained tool receipts:

- `63fa41`: **12 new RED / 20 preserved Node**; Python not reached.
- `9539b2`: **32 Node + 10 Python PASS**, 0.218 s wall.
- `6cb95a`: nonempty-stream boundary **1 RED / 32 preserved Node**.
- `fe61ff`: **33 Node + 10 Python PASS**, 0.248 s wall after that one guard.
- Final `c1295a`: **33 Node + 10 Python PASS**, 0.226 s wall after the approved
  page repin. No skips, actual browser, service, native/model or network run.

Root supplied the independently cleared page SHA
`510bae8d67cd3bdb703a2d02b06da35805e7311942c65b7c984618fd1ba18f1f`.
Only that first input row's bytes/mtime/hash and `PAGE_SHA` changed; the other
28 input rows are exactly equal to PHua9I's manifest. This new page contains the
separately reviewed neutral heading/stale-warning correction, not a transport
fix. Its product review and original actual failure remain separate evidence.

Frozen SHA-256:

| File | SHA-256 |
|---|---|
| `check.cjs` (209 lines) | `4f4dc97b123fc246a789b804769f4be6030e590e29c844d0690a794617425510` |
| `check.py` (unchanged) | `3ca5d4f9750874b6636bc8534f5aa62c478b66fcec16d4fdb1a01a188dc50e5b` |
| `test-check.cjs` (163 lines) | `1806fca7a2081565c742d4f0bd0920a39abbbb8aba10a1588e761f91023bf81e` |
| `test-check.py` (unchanged) | `34054a1ca04951856715ad7424b694fdd39a5da4a2a20048bd928d6557362ef9` |
| `run-inert.py` (unchanged) | `e3094923a9309c49f817d670ecf276870ee428d8a3cd57bcab67e4f3243cf75e` |
| `inputs.json` | `2a768c4b260c1d732a1863d46774618d24b25ea9e0f900f8ec7262b7d8532af8` |
| `harness-pins.json` | `7cb9e1f0930851be9b06e431130fe3d7d175203775ab6b85c6da5cd678bde733` |

Read-only `84b466` matched all 29 input and six harness rows, including exact
decimal-string nanosecond metadata; confirmed the unchanged files/original test
prefix and `run_absent=True`. It rehashed PHua9I's original failed raw receipt
to `2f424c89b77edaab97410133ed58aa2decb8421322340577f4cefb58ab022673`
and supervision to `0c76e97587f445840e835fa4ec7ef8f2661f9e749bcd4516241d8b27ecaa1c3a`.

Exact independent **inert** repeat:

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-biology-request-evidence.1xHVWj/run-inert.py
```

Prospective command only, **not authorized by this maker receipt**:

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-biology-request-evidence.1xHVWj/check.py --run-once
```

Root independently grades this packet and separately decides any single actual
diagnostic invocation. Lesson retained: an unqualified negative counter cannot
identify a failed boundary. Preserve exact bounded request-object evidence
before proposing a cause or fix; no amount of UI-stage success waives a real
request failure. All molecular/graphics/scientific and six-program gates remain.

## Root actual request-evidence result — FAILED, retained

Root independently repeated the final 33 Node + 10 Python inert checks
(`35e730`) before one separately authorized actual invocation. Actual `842eda`
completed as `b4357e`, exit 1, at private root `1xHVWj/run`.
All six interaction stages passed, with zero page errors and zero unexpected
console errors. Overall acceptance nevertheless FAILED: request 15,
`GET /api/session/bootstrap`, received HTTP 204 then `net::ERR_ABORTED` at
3069.59725 ms. Requests 25 and 28, `GET /api/build`, received HTTP 503 but had
no observed terminal event at the 19715.312666 ms cutoff. Of 32 local request
objects, 29 finished, one failed and two were pending. The 94 retained events
identify this run's boundaries only, not their cause or PHua9I's unidentified
failure. Missing terminals are not relabeled transport failures or successes.

Root viewed all six original images, including stale/recovered/portrait. The
stale warning and Retry remain visible; recovery leaves the cell closed. Mobile
navigation is horizontally scrollable; the removed-organ desktop heading wraps.
This fixture deliberately disables WebGL and supplies authored reference-only
organs. It is NOT full anatomy/graphics, whole-body design or scientific acceptance.

Independent data review `112d13` checked all 35 source/harness pins, 21 visited
source receipts, request/event association and six image identities/dimensions.
Root rehashed the original receipts (`6b38fb`):

- Raw, 27,320 bytes: `1c6c42fade7be1e52d2a2a442a22d37960942aa33bb236c2270870c013b7ff60`.
- Supervision, 32,879 bytes: `bf9731420e557fc18975b23d53acf33dd0f59307f04833fe9f203d94ff12e7eb`.
- Original images total 1,624,900 bytes; full evidence 1,685,165 bytes.

All four closes settled; leader 57345 reaped, remaining descendants empty,
listeners absent. Root exact-PID postcheck `9f6560` found none of 57345, 57348,
57349, 57352, 57359, 57363, 57364, 57366, 57367, 57372, 57374, 57375.
No automatic retry, failure waiver or production transport change follows.
