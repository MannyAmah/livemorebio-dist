# Independent registry transition review: blocked

Date:2026-09-08. Reviewer:ui_audit, independent of this packet's maker.
Root accepted the two terminal-write blockers and profile/authority mismatch.
No helper, audit, server, test or operational store was changed by this review.

## Reviewed checkpoint and bounded test result

Read the complete committed-transition plan/interface, maker report, all new
helpers/consumer wrappers, complete audit module and552-line new test module.
Frozen hashes matched before review:

- subjects.py:`f1bf94c2fc593ba82fc934d7b2bfb99d8cfa391681bf2edd5991020940a684dc`
- registry_audit.py:`245eb3568587170379ae18d137ef4b79cbcaa00de86bee3726ef8235afa42546`
- test_committed_registry_transitions.py:`8eaff7fa92a0658d57da44b4e6ca221d636221041db3fa9ba0f03e821c95a472`
- maker report:`92a08e27a8d37ea415aaeb6a61898c4381d76db3d4d25bfb6f8b70aa866f1bbc`

Independent repeat combined the maker's370 preservation cases and four named
legacy cases: **374 passed, one existing Starlette warning,22.78s**. Interpreter:
`/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python`. Fresh private root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-6ad836p7`.
The new test module was loaded as a pytest plugin to apply its socket/DNS,
subprocess and model/profile refusals across the packet. The independent runner
also refused `urllib.request.OpenerDirector.open`. No HTTP, live service, browser,
native numerical worker, publisher acquisition or existing participant store ran.

Passing tests do not clear the concrete additional reproductions below. The
helper remains blocked, and no server integration is accepted.

## P1: terminal row is adopted as its own expected audit witness

Confidence10/10. `subjects.py:1322–1327` calls `audit.finish` then reads the newly
stored terminal row and retains those returned bytes as the expected witness.
Only presence, difference from BEGIN ID, original BEGIN equality and reservation
absence are checked. The terminal bytes are not compared with independently
retained append-origin bytes, nor authenticated against the expected complete
completion semantics before the clinical transaction commits.

An authored AFTER INSERT trigger that alters only the terminal event to one byte
of ciphertext produced this actual independent output:

```text
{'reported_outcome': 'COMMITTED', 'stored_version': 2,
 'terminal_ciphertext_bytes': 1}
```

The trigger is installed after successful preparation. Its reservation-presence
condition excludes the mutation BEGIN insert, because that row is inserted before
its own reservation. It affects the terminal INSERT while the existing reservation
is still present. This is a test of a private technical SQLite fault, not a claim
that an operational database has such a trigger.

## P1: terminal side effect can change the record after the exact comparison

Confidence10/10. The complete clinical/index/topology evidence comparison occurs
at `subjects.py:1320`, before `audit.finish`. No equivalent comparison follows
the terminal write. A terminal INSERT trigger can therefore modify the target
after it passed the comparison; a normal acknowledged commit immediately returns
COMMITTED. A second independent trigger left the audit row valid but changed the
record's indexed version:

```text
{'reported_outcome': 'COMMITTED', 'expected_version': 2,
 'stored_version': 999}
```

The server would receive a prepared version2 candidate while the helper confirms
an inconsistent version999 durable row. The lost-ACK confirmation path happens to
compare retained clinical evidence later; the normal acknowledged commit path
must enforce the same intended write set before commit.

## Exact authored reproduction

This code was run in two separate fresh Python processes. Each used only an
authored SYNTHETIC technical record under its new private review root. No source
file was edited. Choose one trigger body per invocation; do not target old stores.

```python
import os
from pathlib import Path
import urllib.request
import pytest
from tools.run_review_stack import prepare_review_environment

root, env = prepare_review_environment()
os.environ.update(env)
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
from livemorebio.tests.test_committed_registry_transitions import (
    SubjectRegistry, KEY, seed, prepare, rows, no_network_or_models,
)

patch = pytest.MonkeyPatch()
no_network_or_models.__wrapped__(patch)
urllib.request.OpenerDirector.open = lambda *a, **k: (
    _ for _ in ()).throw(AssertionError("OFFLINE_OPENER_TRIPWIRE"))
registry = SubjectRegistry(Path(root) / "authored-terminal-test.sqlite3", key=KEY)
target = seed(registry)
prepared = prepare(registry, "activate", target)

# Probe1. Probe2 replaces this body with: UPDATE records SET version=999;
body = "UPDATE registry_audit SET ciphertext=X'00' WHERE event_id=NEW.event_id;"
connection = registry._connect()
try:
    connection.execute(
        "CREATE TRIGGER technical_terminal_fault AFTER INSERT ON registry_audit "
        "WHEN EXISTS (SELECT 1 FROM registry_audit_reservations) BEGIN "
        + body + " END"
    )
    connection.commit()
finally:
    connection.close()

outcome = registry.commit_prepared_transition(prepared)
stored_version = rows(registry)["records"][0][4]
connection = registry._connect()
try:
    terminal_bytes = connection.execute(
        "SELECT length(ciphertext) FROM registry_audit ORDER BY sequence DESC LIMIT 1"
    ).fetchone()[0]
finally:
    connection.close()
print({"reported_outcome": outcome, "expected_version": prepared.record["version"],
       "stored_version": stored_version, "terminal_ciphertext_bytes": terminal_bytes})
patch.undo()
```

Only safe counts/outcome/version metadata were printed. No clinical row, key,
nonce/ciphertext contents or private payload was logged.

## Profile work conflicts with the approved outer-lock contract

Confidence9/10, source-traced interface defect, no numerical reproduction run.
`subjects.py:1171` calls `_activation_transition_admission(..., profile=True)`
during preparation. At `subjects.py:260–261`, supported non-SYNTHETIC admission
calls `SubjectRegistry.admitted_human(record).metabolic_profile(None)`. Closing
the SQLite snapshot connection first does not release a caller's authority lock.
The approved server interface deliberately captures preparation under authority
and requires profile/candidate construction outside that lock. The current
registry test checks closed SQLite connections, not this outer-lock interval.

Remove profile construction from the prepared-read helper. Preserve the necessary
profile/context validation through the existing outside-lock candidate/direct
wrapper workflow; do not drop validation or broaden executable REAL_HUMAN scope.
Test a supported-reference technical seam with explicit profile-entry refusal
while authority is held, then prove the actual required validation runs after it
is released. No real solver is needed to grade that ordering.

## Minimal intended correction boundary for the maker's new plan

1. Freeze a trusted append-origin terminal witness, not an expected value obtained
   solely by rereading the potentially modified row. Preserve existing audit
   schema, encryption/AAD, reservation quota and compatible public return contract.
   The completion must match this request's complete original BEGIN metadata,
   exact SUCCESS outcome, current completion provenance/time and reservation
   consumption; ID/version or merely decryptable ciphertext is insufficient.
   Exact row identity includes sequence, nonce and ciphertext. Keep any witness
   private and transient. Do not add a parallel durable receipt or log PHI.
2. After every terminal write and reservation effect, recompare the entire intended
   record/index/pointer/ACTIVE evidence and trusted audit witness before the one
   clinical commit. Reject/rollback unexpected effects. Preserve original evidence
   for the existing single read-only lost-ACK confirmation; never retry a mutation.
3. Retain all existing rollback/unknown/committed-close classifications, original
   BEGIN checks, authority/adoption checks and exact two-record bounded topology.
   Extend reds with both actual terminal triggers, terminal metadata substitutions,
   post-finish target/demotion/pointer/device/topology effects, and successful
   ordinary/lost-ACK/cleanup paths. No allowlist, weakened assertion or synthetic
   successful receipt should hide the fault.
4. Separate preparation's audited read/pure transforms from profile construction
   under the exact authority ownership contract above. Server integration and
   independent review remain later gates.

This review does not claim to correct startup, observation-only selection or
reconciliation, whose remaining witness/topology gaps are already explicit in the
approved plan. The local review skill/checklist informed this independent read;
gbrain/Compound Engineering providers were unavailable. Lesson: checking the
write set before the last write is insufficient, and database-returned bytes are
not an independent expected witness for that same write.
