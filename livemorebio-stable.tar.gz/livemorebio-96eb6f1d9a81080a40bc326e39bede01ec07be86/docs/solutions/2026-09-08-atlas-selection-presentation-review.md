# Atlas selection and view-state correction — implementation evidence

Status: maker integration passes; independent implementation review pending.
Plan and independent pre-code precisions are in
`2026-09-08-atlas-selection-presentation-correction.md`. No geometry, manifest,
source cache, vendor, physiological model, server or installation pointer changed.
The earlier Atlas3 FAIL/25 NOT_RUN receipt remains unchanged.

## Implemented behavior

Assembled fills keep existing group colors. Explicit isolation alone may color
the exact selected source element teal. One pointer-inert DOM cue projects the
selected source bounding extent, labels its exact ID, and bounds both brackets
and measured text independently within the viewport. The accessible existing
inspector retains every source field and explains that this is not a contour or
evidence of pixel visibility. Sectioned, hidden, unloaded, context-lost, behind/
near-camera and wholly far/outside extents suppress the cue. Document hide cancels
the pending demand frame immediately; disposal removes owned DOM/resources.

The controller separates loaded-layer status from enabled/isolation/section
settings. Failure/pending/paused status hides the new settings sentence even when
old retained geometry remains operable. Disabled or unloaded isolated selections
are explained explicitly. Installation acknowledgment text wraps without changing
its receipt/uncertainty semantics. No scripted biological output or free-running
render loop was added.

## Red and integration results

- Root's12 scene/CSS cases initially **12 failed in2.20s**, private root
  `livemore-research-review-p2qoe1ph`. Failures exposed changed assembled fills,
  missing cue, hidden/context behavior and absent styles before implementation.
- Source helper's71 cases failed before its module existed, then **71 passed
  in5.08s**; separate complete helper report retains its exact run and hashes.
- UI controller's11 new cases failed before its change, then11 passed with one
  inherited callback-count assertion failing. Root approved its exact old
  `visibleCount===1`→`===2` update because hide now must call scene.visible() too.
  UI's bounded packet: **57 passed,2 vendor cases deselected,6.17s**; these
  exclusions are not used as the combined acceptance suite.
- First combined scene/controller/preserved UI: **70 passed,1 failed,8.84s**,
  private root `livemore-research-review-0hs4d73a`. The new disposal fixture wrongly
  assumed its two byte-identical triangle objects must own two distinct geometry
  instances. The pinned GLTF loader shares the geometry. The test now tracks
  disposal of each actual unique geometry without changing runtime disposal,
  original source IDs, arrays or shader behavior. It does not assert GPU counts
  from the technical renderer as measured browser resources.
- Corrected combined packet below: **304 passed in14.35s**, private root
  `livemore-research-review-5ts3ekmk`; no skips/deselections. It includes the two
  pinned-loader/scene cases excluded by the earlier controller-only lane.

```text
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B tools/run_review_tests.py livemorebio/tests/test_atlas_selection_presentation.py livemorebio/tests/test_atlas_extent_projection.py livemorebio/tests/test_atlas_view_status.py livemorebio/tests/test_atlas_reference_ui.py livemorebio/tests/test_atlas_renderer_review.py livemorebio/tests/test_atlas_reference_geometry.py livemorebio/tests/test_atlas_clients.py livemorebio/tests/test_atlas_commands.py -q --tb=line -p no:cacheprovider
```

These use authored technical arrays/metadata and pinned local THREE arithmetic
with a non-GPU renderer. New scene/controller tests prohibit unexpected fetch;
the review runner isolates stores but is not a process-wide network firewall.
No real browser, public participant source, native model or operational service
was invoked. Independent review should rerun with additional transport tripwires.

## Frozen packet

SHA-256, relative paths under livemorebio:

| File | SHA-256 |
|---|---|
| aegle/console/lib/atlas_reference_scene.js | 9c3f3b4a97ea50434986b63b96a3d1109d29b3a41d012b73a348a0f3ae0706c6 |
| aegle/console/lib/atlas_reference.js | befd7a2436c311da8b78deb6b3fe2efd8b2b5ecba14bd80f1df58afd9d3a40fa |
| aegle/console/lib/atlas_reference.css | 8dfbe7b7a594202fc4b69e715fc231b6463800fd120ab142f7b5b8254a9b2b88 |
| aegle/console/lib/atlas_reference_presentation.js | 325bf0f647ae02c7b47dcc29c9d5a91a6f1f6b50a89206fd538afabdc34378fd |
| tests/test_atlas_selection_presentation.py | ecf0a3bc3f37ac293437a91ec48a31e79ddc61c13aea40c6afbb5400eb4610cf |
| tests/test_atlas_view_status.py | eda5468e749bd144b88bfc6bbc6ca6dda5a19757d5852fb3ed28b5126bb7ecc8 |
| tests/test_atlas_extent_projection.py | 77ddc776b85ac6503b7f6d6470e82c50cbdff9672393ed2cd9c6d4ad7c843931 |
| tests/test_atlas_reference_ui.py | 92a62f61adc3603e5b02f3f92b72ab3df65b11ff923c21faf23a1d16249b155b |

The reviewer must check actual final files; no earlier browser source hash applies
to this changed renderer. `git diff --check` is clean.

## Open acceptance and compounded lesson

### Final measurement-bound refinement

Independent review's original304-pass packet and three boundary probes are
retained below as historical evidence. It flagged a real-layout risk, not a
claimed browser reproduction: measuring an absolutely positioned label at its
stale inline position may shrink its width, then anchoring can allow it to grow.
Root's authored layout-sensitive case went RED **1 failed,12 deselected,1.03s**,
private root `livemore-research-review-cyhewl1y`. It is explicitly a technical CSS
stand-in, not an actual screenshot or rendering-engine test.

The reviewed-plan refinement resets label left/top to8px before measuring; the
same bounded helper then anchors it. No other runtime behavior changed. Combined
command above now includes the new case: **305 passed in14.36s**, private root
`livemore-research-review-r4zfmdws`; `git diff --check` is clean. Final replacements:

- `atlas_reference_scene.js` SHA-256
  `704ed1347f89507b2f7d913944dbaec0cf61a25455a456488d9837c9bb57eff6`.
- `test_atlas_selection_presentation.py` SHA-256
  `1c5d2c2515a859c557d32831e26672feccac82fd71be41379a12e3b3a7725c04`.

All other frozen hashes remain as listed. Independent final-delta review remains
required. The actual far-right-selection→narrow-resize browser check stays open.

### Retained open acceptance

All42 old screenshots were viewed, but none proves this new rendering. The next
ordinary browser check must compare assembled/isolation at the same camera and
readability at small widths. Label collisions, molecular local dependencies,
transport/performance/capture corrections and full Atlas fault coverage are still
open. No A+B, full Biology, experiment or clinical acceptance is claimed here.

An anatomical source may intentionally contain distinct overlapping
representations. Preserve both identity and geometry; selection emphasis must not
turn their competing surfaces into apparent tissue changes. Likewise resource
availability, current view settings and actual visible pixels are different
claims and need different UI feedback. Technical loader sharing is also not ID
deduplication: tests should assert the resource ownership actually returned by
the pinned dependency, not an assumed one-object/one-buffer correspondence.

## Independent implementation review — original frozen packet

The independent reviewer read the complete amended plan, helper report, four
runtime files and all new tests, and verified all eight frozen hashes above.
The exact eight-file matrix passed independently: **304 passed in 18.23s**, no
skips or deselections. Private review root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-tlrgy20q`.

The run used the same pinned fresh Python interpreter and a fresh
`prepare_review_environment`, with Python socket connect/connect_ex, DNS,
urllib urlopen and OpenerDirector.open replaced by refusal tripwires. All 139
Node invocations received an independent pre-import network-refusal module
covering socket/TLS, HTTP(S)/HTTP2, DNS, datagrams and default fetch. Authored
in-memory fetch fixtures remained usable; this is test instrumentation, not an
OS sandbox or a claim about arbitrary future subprocesses.

Three further independently authored mounted checks passed in private root
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-r1yhhjeo`,
using the actual scene and pinned local loader with authored technical triangles:

- An oversized measured label hides text only, then recovers at an admissible
  measured size; the brackets and source arrays remain unchanged.
- Widths 0/16/390/768/17/600 suppress or restore the cue without source changes or
  an idle frame loop.
- Disabled-layer/isolation/selection/section/hide ordering preserves exact-ID
  binding, suppresses inappropriate cues, and restores the current selected ID.

Source review found no reproduced geometry/material-preservation, projection,
failure-status or lifecycle blocker in that packet. The disposal fixture now
correctly checks each actual unique geometry; its renderer counters are authored,
not measured GPU resources. The inherited visibility count change preserves its
original assertions and adds the required hide notification.

**Final clearance remains pending a focused label-layout follow-up.** The label
is measured at its previous absolute position before assigning its new anchor.
The technical fixtures use a supplied rectangle, not browser shrink-to-fit
layout, so they do not establish that the final wrapped rectangle retains the
eight-pixel inset after a far-right position and narrow resize. The reviewer
raised this as a plausible, not browser-reproduced, issue; root requested a
layout-sensitive red test and, only if reproduced, neutral-origin measurement
under the already approved label-bounds contract. The 304-pass packet must not be
substituted for that final hash and review. No runtime file was edited by this
reviewer, and no browser, service, operational store or biological model ran.

After that focused follow-up, ordinary same-camera assembled/isolation and
small-width visual checks are still required. The earlier overall Atlas failure,
label collisions, dependency/performance/fault gaps and full product/scientific
acceptance remain unchanged.

### Independent final-delta disposition

The reviewer read the subsequent pre-code measurement refinement, the exact
neutral-origin reset and the new layout-sensitive mounted regression. The reset
measures at left/top 8px before applying the separately bounded anchor, so a stale
right-edge position cannot artificially constrain the input measurement. It
changes no source geometry, camera, selection, material or lifecycle behavior.

Verified revised scene SHA-256:
`704ed1347f89507b2f7d913944dbaec0cf61a25455a456488d9837c9bb57eff6`;
revised scene-test SHA-256:
`1c5d2c2515a859c557d32831e26672feccac82fd71be41379a12e3b3a7725c04`.
The focused final file passed independently: **13 passed in 3.01s**, no skips,
with the same Python transport refusal and all 12 Node invocations preloaded with
network refusal. Fresh isolated root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-_ki1y923`.
The independent broad run remains the original 304 result above; the later 305
combined result is root's separately reported run, not an independent rerun.

This closes the conditional code-review hold for the revised packet. **No
remaining actionable implementation blocker was found for proceeding to the
targeted ordinary browser check.** The layout-sensitive fixture is still not a
browser layout result. Actual final label rectangles, narrow-width wrapping and
same-camera assembled/isolation appearance remain explicit browser acceptance
checks; this disposition does not change any earlier overall Atlas failure or
broader product/scientific gate.
