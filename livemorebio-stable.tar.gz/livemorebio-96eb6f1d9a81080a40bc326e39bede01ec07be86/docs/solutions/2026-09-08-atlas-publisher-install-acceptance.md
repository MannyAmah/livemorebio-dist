# Atlas actual-source install acceptance

Date: 2026-09-08. Parent: full-scope recovery R21–R23/R45–R48 and the
reviewed Atlas conversion/cache/renderer packet. Status: **ACTUAL ISOLATED SOURCE
INSTALL, NETWORK-FREE ARRAY RECHECK AND INDEPENDENT ARTIFACT REVIEW PASSED;
current-build HTTP parity and rendered acceptance pending.**

## Preserved boundary and pre-execution checkpoint

Root and the independent reviewer have read the complete source/cache/geometry
and guardian implementations. The independent source/API packet passed 218
technical tests; the subsequent Linux scanner correction independently passed
69 process/worker tests. Linux fixtures on macOS do not establish Linux OS
acceptance. The header follow-up separately passed 179 tests independently.

This checkpoint authorizes one explicit `install` call for
`bp3d-4.0-20130619-surface-core-v1`. It downloads only the pinned publisher sources,
converts them with the reviewed converter and admits them only after the existing
independent array checks. It is not biological execution, a physical measurement,
a patient-registered body or authorization to redistribute geometry publicly.

Exact frozen code before the call:

- `atlas_reference.py`: `58ab81e85b0da2fc337d105cc6f49caccc80bed06c9800449af9eaad15dc8382`.
- `_atlas_process.py`: `c8b9fe7bb344dd7fffb6b5d1e208ae98c21b87f692bdd10b5c3818fbc0f76336`.
- Declaration: `e2df5ada0b3a983c69d409ce9e18cbc4c1568208cea49fc23f40a847b6bc57ad`.
- `_atlas_geometry.py` and strict JSON identities are checked and recorded before
  invocation; the converter independently binds its loaded bytecode and versions.

Use `/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B`, from this preserved
worktree, with `LIVEMORE_ANATOMY_DIR` set only to the existing owned technical
review directory:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-1q65uy9g/anatomy`.
The original installed release and other running stacks/stores are untouched.
Read-only status immediately before this checkpoint returned `missing`, with
null manifest and `patient_registered:false`. The renderer owner keeps source,
cache, geometry and process files frozen while continuing separate UI work.

## Once-only procedure and evidence

1. Check all code/declaration identities and the explicit cache target before
   calling the fixed-source API. Abort if any expected identity differs.
2. Run one install. Retain its existing immutable manifest, source archive,
   assets and receipt in that private cache. Record elapsed wall time, returned
   state, manifest digest, receipt and asset totals; no arbitrary source URL.
3. On a typed failure, preserve evidence and stop. Do not retry, alter precision,
   weaken source validation or use previous downloaded geometry as a fallback.
4. After success, run a separate network-free status/read verification and
   confirm owned phase processes are gone. Inspect exact source-native/world
   bounds, component membership and source-degenerate faces in the manifest.
5. Actual SDK/CLI/REPL HTTP reuse and coherent whole-person GPU rendering require
   a fresh, source-frozen review-stack restart and separate acceptance. A
   successful cache install does not close those requirements.

The first actual SDK/HTTP attempt correctly reported missing geometry but failed
because the Atlas route omitted startup build headers. The seven red-first header
regressions and independent 179-test pass correct that defect; the failed attempt
is retained in the terminal-parity plan. No publisher install occurred during it.

## Packaging consistency correction — before implementation

The converter intentionally admits only trimesh 5.0.0, and the existing hashed
Python 3.11 installer lock already pins 5.0.0. However, the wheel's `server` extra
still accepts `trimesh>=4.0`; an existing 4.x installation can therefore satisfy
package metadata but cannot perform the reviewed Atlas conversion. Add a failing
built-wheel metadata assertion, then change only that existing dependency to
`trimesh==5.0.0`. Preserve every other dependency and the hashed lock. Rebuild and
test the wheel outside the checkout, and independently review this one-line
packaging correction. This is not authorization to install packages into the
user's existing environment or activate a new product release.

## Actual install and read-only verification

The once-only source install returned success in **226.206 seconds**, without
reuse or fallback. Its immutable manifest is
`8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a`;
receipt `083b2f038e74476ebfcef07e4a22f7c2` records
`2026-09-08T14:41:30.445957+00:00` through
`2026-09-08T14:45:11.080420+00:00`. The installer also reverified publication
before returning. The observed installer PID 94309 and acquisition guardian
94321 were absent afterward; both phases require proved group cleanup before
the reviewed implementation can return success.

Exact geometry and strict-JSON source hashes were respectively
`44b08f9bf486e8cb959db9a95d22a307c1b61874884d726ce5a85a1ecee56562` and
`6af73cc557bdb3a18bda10bc114148ef7e25f711410fd1d263e11279ea01c8e1`.
The admitted runtime is Python 3.11.15, NumPy 2.4.6, trimesh 5.0.0;
loaded converter code digest
`e7532a863d945fabb296753e9aa8b5b6187f9609fb6dff518255053b1783e5f8`.

Root separately called full status with network access replaced by a rejecting
guard. It rehashed/decoded/rechecked the complete installation in **5.426 seconds**.
The aggregate report passed: 489 exact components; nine partitions; 957,072
triangles; 24,779,652 GLB bytes. No introduced zero-area triangles; the three
original source faces of FJ2820 at indices 9472, 11025 and 11147 remain preserved.
Maximum coordinate error is 0.00005859375005456968 mm, normal-component error
0.000000029800415024539006, and world-coordinate error
0.00000005859375005456968 m, within the preregistered bounds.

| Partition | Source components | Triangles | GLB bytes |
|---|---:|---:|---:|
| Skin | 1 | 203,382 | 4,901,056 |
| Heart | 83 | 102,802 | 2,749,816 |
| Liver | 60 | 191,622 | 4,978,928 |
| Pancreas | 4 | 16,962 | 517,084 |
| Right kidney | 1 | 2,310 | 56,888 |
| Left kidney | 1 | 2,982 | 72,968 |
| Right lung | 156 | 73,312 | 2,079,608 |
| Left lung | 124 | 41,438 | 1,211,212 |
| Brain | 59 | 322,262 | 8,212,092 |

The once-only shared transform is 0.001 × (native x, native z, −native y).
The skin spans world y −0.0781111984 to 1.6413599854 m. No child was independently
recentered or enlarged. This is `REFERENCE_ONLY` and `patient_registered:false`.

Retained reporting failure: the first read-only summary script completed the
status check, then treated the manifest's asset list as a dictionary and failed
while printing. It changed no source/cache data and did not rerun installation.
The corrected list-aware, bounded summary above was a fresh network-free read;
the original reporting error is not erased or counted as a passing workflow.

Packaging verification: the built-wheel metadata assertion failed before the
one-line pin change. The wheel and isolated installer harness then passed **57
tests in 41.82 seconds**. Independent source review cleared the metadata/lock
consistency correction. These installer tests are not a new end-user installation
or release activation. The retained wheel digest is
`b5b9dce6d18dee8f27a95315ab077b88abc261eaa94b4dc02bb2d6be9bbc0782`.

## Independent artifact verification

The reviewer independently decoded the retained OBJ and GLB bytes with a separate
NumPy/stdlib checker, without invoking the product converter or status verifier.
All three publisher source hashes, all 489 element identities and source hashes,
535,346 positions/normals and 957,072 source-order triangle indices matched.
The nine GLB hashes/lengths, immutable manifest/receipt/pointer, native/world bounds,
single shared root transform and identity children also passed. Private ownership,
file modes and no final symlink/hard-link aliasing were checked.

Direct recomputation found maximum world error 0.00000005859375007410961 m,
consistent with the fixed bound and with root's differently ordered floating-point
arithmetic. The three original degenerate source faces remain explicitly recorded.
This closes the isolated artifact check, not rendered landmarks, human registration,
biological function or public redistribution clearance. The reviewer also rechecked
the exact wheel digest/metadata and absence of bundled GLB/OBJ/archive geometry.
