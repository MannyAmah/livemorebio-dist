# Observation-only selection and reconciliation: exact committed publication

2026-09-08. **Plan only, pending root and independent pre-code review.** No
implementation, test execution, registry access, model, service or browser was
performed for this proposal. It completes the explicitly retained observation /
reconciliation obligation in the committed-source interface; it does not replace
R01–R51, the six programs, actual device qualification or client acceptance.

## Prior decisions and exact remaining seams

Read alongside the approved
[committed-source interface](2026-09-08-committed-source-transition-interface.md),
[reconciliation contract](2026-09-08-selection-reconciliation-contract.md),
[checked-reader receipt](2026-09-08-startup-checked-selection-implementation-review.md)
and [preview review](2026-09-08-confirmed-preview-publication-implementation-review.md).
The review traced actual server routes, registry preparation/commit/checked-read
helpers, availability, current snapshot publisher and UI/SDK acknowledgment
validators. No CE/gbrain/sequential-thinking tool is callable here; this local
source-linked plan is the bounded fallback, not a claim those tools ran.

Current `select_twin_observations` prepares a target-only record before capturing
source generation, then takes whatever generation exists at final commit. It
does not freeze the selected pointer/other selected row or compare memory with
that snapshot. Its registry writer demotes every ACTIVE row and recognizes a
lost commit ACK from target ciphertext plus pointer alone. It can also lose a
confirmed outcome to its connection close. On uncertainty the server replaces
inspection holders with speculative target state; old models/actions can retire
under locks. Its final `_snapshot_twin()` reads mutable current state.

Current reconciliation uses the legacy audited-record path, not the newly checked
whole-row/pointer/ACTIVE-topology capture. Canonical record equality does not bind
pointer timestamp, SQL indexes, resealing or bootstrap authority adoption. State
projection occurs after publication through `_snapshot_twin()` and old holders
are not retained across assignment. Existing source DENY admission, exact empty
request and cleanup independence are correct requirements to preserve.

## Frozen scope and wire compatibility

Keep both existing protected POST routes and their strict16KiB JSON reader:

- `/api/twins/{id}/select-observations`: exactly `expected_version`, no new source,
  model, generation, patient-data or recovery fields. Preserve authenticated
  REAL_HUMAN admission and explicit `observations_only` selection. Request version
  must be an exact safely incrementable integer, `1 <= n < MAX_SAFE_INTEGER`;
  response record and availability both retain the committed `n+1`.
- `/api/twins/reconcile-selection`: exactly `{}`, no query fields, subject/version
  or model choice. Require DENY_ALL both at capture and final publication. Never
  repeat a selection mutation. Success remains exactly `selection_status`,
  `subject`, `model_availability`, `prior_execution_cleanup`, with the existing
  `CONFIRMED` and `INSPECT_EXISTING_STATUS` values.

One canonical operation UUID/no-store must survive every local response, including
capture/late conflicts, storage errors and uncertainty. Preserve fixed safe error
codes and status distinctions, no raw clinical text or exception strings. No
transport budget, response schema, model equations, bootstrap policy, registry
encryption/AAD, audit payload, SDK fallback or physical replay policy changes.

Observation selection is always modeless: no AegleTwin or MetabolicProfile
construction, numerical state read or healthy substitute. Existing primitive
availability/admission checks remain allowed; they do not construct physiology.
Retain original evidence,
consent, profile source facts, creation identity and bindings. Selection does not
reinterpret stored biomarkers as a sampled live stream. New live observation and
action holders start empty; descriptive records remain inspectable.

Reconciliation preserves the original three outcomes: an admitted observations-
only person remains unavailable with `tw=None`; an already supported numerical
record may rebuild only its existing qualified computational context; **checked
true absence alone** permits the already-supported healthy reference preview.
Root explicitly confirmed this absence compatibility during plan preparation.
Missing/inconsistent pointer target, orphan ACTIVE row, unknown storage or an
unsupported person never becomes absence or invented physiology.

## A. Narrow fourth fixed registry transition

Amend the ancestor's exact three-kind restriction to add only
`select_observations`. Reuse `PreparedRegistryTransition`, `_transition_snapshot`,
the origin-checked phase owner and the exact commit witness. No generic mutation
callback or new transaction/audit framework.

Proposed additive server-facing method:

```python
SubjectRegistry.prepare_observation_selection(
    twin_id: str, *, expected_version: int, request_id: str,
) -> PreparedRegistryTransition
```

It captures the existing full bounded target+selected read set, pointer including
timestamp, ACTIVE topology and authority token through `_selection_read_access`.
After its audited connection closes, validate existing REAL_HUMAN admission and
derive only the permitted structural transformation. Do not call activation's
numerical admission. A distinct selected row is demoted once to DATA_ADMITTED;
the target becomes ACTIVE/observations_only and increments once; the pointer
identifies the target with the frozen timestamp. Same-target selection increments
only that target. A second ACTIVE row or incoherent pointer rejects rather than
repairing/decrypting an unbounded collection. Stored target and demoted versions
must be safely incrementable; a read-only reconciliation may still inspect MAX.

Preparation retains the existing `inspect` audit meaning. Its mutation BEGIN and
terminal retain `select_observations`, already allowlisted, under the existing
subject-access schema. Other kinds' audit actions do not change. The commit
validator independently reconstructs this fourth exact transformation and checks
all existing type/canonical/read-set/authority constraints. No physical index or
unrelated row is written. Keep BEGIN-before-decrypt, post-audit raw-state checks,
terminal origin and bounded failure audit behavior unchanged.

Actual commit acknowledgment uses the entire reviewed witness: expected affected
and untouched rows, pointer, topology, BEGIN/terminal identities and reservation
absence. Retain exact outcome classes COMMITTED, COMMITTED_CLEANUP_UNCONFIRMED,
confirmed rollback and SELECTION_COMMIT_UNCONFIRMED. No target-only shortcut,
write retry or fresh mutation to discover an outcome.

Preserve direct `select_observations(..., prepared=None, request_id=None)` and the
standalone pure `prepare_observation_selection(record, ...)` signatures. The
legacy PreparedObservationSelection is not full-store authority. If supplied to
the direct wrapper, first perform a fresh full audited preparation, then validate
its exact original digest, admitted target, strict timestamp and complete allowed
after-record before embedding that compatible frozen result into the internal
transition. Preserve a valid caller's prepared timestamp/record; reject forged,
stale or malformed preparations before writes. No old writer remains as fallback.
Direct confirmed-close failure becomes the existing typed committed-cleanup
exception rather than a presumed rollback. Preserve all original valid returns.

## B. Observation-selection server publication

1. Authenticate/parse, allocate UUID, validate version/target and initialize the
   registry dependency outside source locks. Under authority only, capture the
   generation and new full prepared transition; require four-field active-record
   agreement with memory, including both-none versus one-sided absence. DENY_ALL
   rejects before selection preparation. Preparation uncertainty is503 with old
   state/generation retained, not mutation-phase denial.
2. Outside every source/creation/manager/registry/initialization lock, construct
   fresh ObservationState, availability, subject summary, empty action container,
   complete selected-state shell and detached `unavailable_state` snapshot. Require
   coherent UNAVAILABLE/observations_only, no numerical fields/axis, null parameters
   and `tw=None`. Serialize success and all postcommit responses before writing.
3. Under the original commit guard recheck generation and four-field agreement.
   Retain old state/actions. Invoke the actual prepared commit once. Confirmed
   outcomes install the fresh generation and complete modeless state before
   guard exit. Unconfirmed mutation installs DENY_ALL but retains the exact old
   inspection holders; do not install a speculative new subject. A confirmed
   rollback/conflict leaves everything unchanged.
4. Outside all locks, invalidate only the captured prior generation for confirmed
   or unknown mutation outcomes. Cleanup failure after confirmed commit retains
   the new source and reports the fixed committed-cleanup503; unknown stays unknown.
   Preserve closed-manager state/owners. Publish only the precomputed own snapshot
   after confirmed replacement, even if a later source wins; never read that later
   model or substitute its availability. Release all retired holders outside locks.

The old uncertain-route assertion `tw is None` reflects speculative replacement,
not a required wire guarantee. Replace only that mapped fixture assertion with
exact old-holder retention while preserving DENY, inaccessible current physiology,
list `active:null`, cleanup attempt and history/observation safety assertions.

## C. Reconciliation via checked read, not a mutation

Extend only the checked-read action allowlist to `inspect` and
`reconcile_selection`. Pass the selected fixed action into `_checked_selection_access`
for capture; default startup capture remains inspect, and checked confirmation
remains reconcile_selection. No action is accepted from HTTP. Preserve legacy
default dict-returning signatures and the exact CheckedActiveSelection type.

1. With DENY_ALL checked under authority, call
   `audited_active_twin(action='reconcile_selection', request_id=..., _checked_snapshot=True)`.
   Retain this complete immutable capture and its detached record. First and final
   encrypted audits use the same operation UUID, distinct events and the existing
   reconcile_selection action. Bootstrap authority/adoption and phase protections
   apply before protected decryption; failed access does not grant recovery.
2. Outside all guards, prepare the permitted current record's modeless or supported
   model state, fresh observations/actions, complete availability and explicit own
   snapshot. Any allowed model/state call occurs here. READY requires a non-null
   candidate and dictionary parameters; modeless requires `tw=None`/null parameters.
   A typed model-context rejection for an actual record preserves its explicit
   unavailable reason; a failed no-record healthy constructor is operational
   failure, not an invented unavailable person. Pre-serialize the unchanged success
   response. No model work is needed for an observations-only REAL_HUMAN record.
3. Under commit_guard require authority still DENY_ALL; invoke
   `confirm_active_selection(expected_record=record, request_id=..., _expected_snapshot=captured)`.
   It checks exact rows, pointer timestamp, ACTIVE topology, authority token and
   terminal audit through the current checked owner. Only a returned confirmation
   permits assignment of the precomputed state/generation. Every failure, including
   commit/close acknowledgment loss, keeps DENY_ALL and the old holders, with a
   fixed503 or exact409 reconciliation conflict and the same UUID/no-store.
4. Retain and release old/candidate objects outside the guard; publish only the
   detached confirmed snapshot. Do not invalidate, stop, reopen, acknowledge or
   otherwise change old execution ownership here. Existing pending cleanup and
   fixed execution history remain separate. A second/later successful recovery
   cannot reuse this request to rotate a now-confirmed source.

Reconciliation writes audit records only: no clinical row, pointer, version,
ciphertext, identity index, binding or persistent response receipt changes. A
same-version reseal or timestamp-only pointer change is a conflict, not a no-op.
The older default helpers' behavior is not silently broadened or advertised as
checked; the two product routes must explicitly use the full checked interfaces.

## RED packet and independent acceptance

Registry owner first writes dedicated observation-transition and reconciliation-
action tests; root separately owns actual ASGI publication tests. Freeze exact
case lists before execution. No maker grades their own implementation.

- REAL_HUMAN target selection from another selected record, same target and true
  absence; exact1/2-row changes and untouched indexes/evidence; no numerical call.
- Every four-field, full-row/reseal, pointer timestamp/topology and authority-token
  change between capture/commit; wrong key, quota/audit failure, source MAX and
  malformed/forged legacy/full prepared values. Reject unsafe next versions before
  clinical writes while read-only MAX confirmation remains supported.
- Lost BEGIN/terminal ACK, actual commit then ACK loss, each missing witness part,
  confirmed and unconfirmed rollback, confirmed-close failure, same-transaction
  audit triggers and post-BEGIN/terminal raw-state guards. Preserve private raw
  before/after rows and audit semantics without printing source content.
- Server preparation failure versus actual unknown mutation: correct503/UUID,
  no-factory/no-commit preservation versus DENY and old-holder retention; modeless
  successful projection, cleanup failure/closed manager and four-lock finalizers.
- Reconciliation ready/modeless/true absence; malformed pointer/second ACTIVE;
  same-version record change/reseal and authority adoption; final audit/close
  failure and two competing reconciliations. Exact clinical bytes unchanged.
- Pre-serialization failure cannot follow clinical commit; late source winners
  keep their current authority while old operations publish only their own snapshot.
  No hidden healthy/numerical construction for an unresolved person; no cleanup
  or execution revival on reconciliation.
- Keep UI/SDK exact ACK schemas, successor-version, same request UUID and once-only
  mutation semantics, stale GET/POST epochs, lost ACK plus one authoritative UI
  read, disposed callback and cleanup/history tests. The SDK's currently wider
  MAX request admission must not imply an executable successor: server rejection
  remains fixed before writes; any client-bound refinement needs its own scoped
  approval, not a transport/schema rewrite here.

Preserve the original clinical descriptive registry, selection reconciliation,
availability, committed transition, audit-phase, stored-MAX, checked-startup,
activation/binding/preview and physical-evidence admission tests. Update only
identified route fixture seams/old speculative-holder assumptions; do not delete
legacy-helper tests or relabel malformed legacy absence as checked true absence.
Use the reviewed private no-network/no-model wrappers, separate registry inert
and45-second ASGI packets, no operational stores. Actual encrypted-registry→route
integration must follow the inert tests, then source-frozen ordinary UI/terminal
acceptance. No service/browser/native execution is authorized by this plan.

## Ownership and lesson

After explicit approval: source/registry owner owns subjects.py and new registry
tests, root owns the two server routes and ASGI tests. UI/SDK, source authority,
execution manager, audit encryption and biological models remain unchanged unless
a separate reviewed regression requires a narrow amendment. Coordinate source
freezes with the already active preview integration and scientific work.

Observation-only does not mean concurrency-free. Its identity transition needs
the same exact commit evidence as a numerical selection, while reconciliation
must confirm that evidence without repeating the write. Retaining old inspection
holders behind DENY and keeping cleanup separate avoids both speculative patients
and fabricated recovery. This proposal grants no implementation approval itself.

## Independent pre-code review: required publication and compatibility precisions

The independent reviewer read the complete original252-line proposal, both actual
server routes, ModelSourceAuthority, the checked capture/confirmation owner,
prepared transition/change/witness paths, legacy direct selection and its tests.
No test, registry operation, model, service or browser was run. The fourth fixed
kind, bounded topology, inspect→select_observations audit distinction, unchanged
default startup path, inclusive read-only MAX and checked-absence-only preview
are coherent. The following mechanics must be explicit before code; root accepted
the first finding and requested this additive record.

### Reconciliation must retain the captured inspection-state identity

DENY_ALL is one sentinel, not a generation for each uncertainty interval. R1 can
capture denied state S, release authority for preparation, and pause. R2 can then
reconcile the same unchanged registry into new state T. A later selection/preview
can suffer an unconfirmed rollback, restoring DENY_ALL while retaining T and the
same raw selected record/pointer. R1's old checked DB snapshot can still match.
Checking only DENY_ALL would let R1 overwrite T and its newer inspection holders.
Exact database confirmation is necessary but does not prove unchanged local intent.

At C1, while checking DENY_ALL under authority, capture a **strong reference** to
the actual `_state` object before the checked read. Retain it through unlocked
preparation. At C3, under the original commit guard and **before** calling final
checked confirmation, require both authority DENY_ALL and `_state is captured_state`.
Either mismatch returns the existing fixed reconciliation409/current UUID/no-store,
with no confirmation, assignment, invalidation or publication. There is no failure-
side state assignment to guard: failures preserve whichever state is then current.
The capture reference and candidate/retired holders are released only by the outer
cleanup after guard exit, including early-return/error branches. This adds no
authority API, synthetic generation, generic epoch or persistent receipt.

RED: hold R1 after its checked capture; complete R2 recovery; return to DENY_ALL
through the later unknown-outcome seam with DB rows/pointer unchanged and a
distinct T plus observation/action sentinels. Resume R1. Assert409, no R1 final
confirmation, T/its holders and DENY preserved, no cleanup/publication, and weak
retirement callbacks outside all four locks. Preserve ordinary competing-recovery
and unchanged-single-recovery tests. This is a local state identity fence, not
distributed synchronization with arbitrary direct SQLite writers.

### Validate the complete own snapshot, not just the wire acknowledgment

Observation-selection and reconciliation success responses omit some/all fields
of the separately published unavailable/numerical snapshot. Serializing only the
metadata acknowledgment cannot validate a candidate snapshot containing NaN or an
unsupported object elsewhere, even when profile_params is a dictionary. Before
final write/confirmation, outside all guards, strictly JSON-validate the entire
detached own snapshot as well as the unchanged success response. READY requires
candidate plus dictionary parameters; modeless requires null parameters. This is
a local prepublication check, not a new transport or shared-serializer contract.
Use existing actual JSONResponse construction or the same strict finite JSON
path; do not introduce global policy changes or silent coercion.
Projection/serialization failure uses fixed storage-unavailable503/current UUID;
observation selection retains its old generation and performs no mutation, while
reconciliation retains DENY_ALL/old holders and performs no final confirmation.

RED: valid dictionary parameters but NaN or an opaque object in another numerical
snapshot field; malformed modeless projection; correct success metadata alone
must not pass. Assert no final commit/confirmation, no publication and no raw
exception/source text. Do not change startup's separately reviewed behavior.

### Embed legacy preparation without a weaker transformation path

For a valid legacy PreparedObservationSelection, preserve its timestamp and exact
target result only after fresh full audited capture. Reconstruct **all** allowed
after rows and the new pointer from that capture using the same validated legacy
timestamp, including a distinct selected row's demotion. Do not replace only the
target bytes in an otherwise freshly timestamped transition. Compare canonical
typed bytes against the exact permitted target transformation, not only Python
dict equality (which aliases True/1 and1/1.0). Commit still independently validates
the fourth fixed kind. Forgery/staleness rejects before clinical mutation; mandatory
preparation/failure audit writes are not incorrectly prohibited by that phrase.
The old pure preparation binds a record digest, not old SQL nonce/pointer authority;
the fresh full preparation supplies the current exact rows/pointer/token.

RED: valid legacy timestamp preserved across target/demotion/pointer and returned
record; exact same-target result; forged numeric aliases, extra changed fields,
invalid timestamp and stale digest rejected without clinical edits. Keep the pure
standalone helper side-effect-free and the wrapper's optional UUID compatibility.

The checked capture action requires type(action) is str and accepts only inspect
or reconcile_selection; reject invalid values before store access. Checked final
confirmation remains unconditionally reconcile_selection. Default startup capture
remains inspect, legacy dict-returning access is not silently relabeled checked,
and neither HTTP body supplies an audit action. Final case inventory, root review
and explicit implementation approval remain required after this addendum.

## Root architecture approval and named owners

Root read the complete original252 lines and independent86-line addendum, plus
the actual source-authority, current routes, checked reader and prepared registry
transformation/witness code. Both review findings and the compatibility precisions
are accepted. The exact bounded architecture is approved; no additional model or
physical channel is introduced. Existing client recovery is separately owned.

Assign release_redteam the registry test inventory and later subjects.py/new
registry tests; assign ui_audit the actual ASGI test inventory and later ASGI test
authorship; root retains the two server route implementations. This explicitly
delegates the earlier root test-authoring duty, not source implementation or
release authority. Root will read/review each frozen inventory before authoring
is authorized. Test authors do not claim runtime acceptance; root independently
reviews registry work and another agent independently reviews root's route code.
No service, browser, native model or operational-store action is authorized by
this architecture approval. The already-cleared source-status correction remains
preserved at servercedcf801… until the staged route implementation gate.
