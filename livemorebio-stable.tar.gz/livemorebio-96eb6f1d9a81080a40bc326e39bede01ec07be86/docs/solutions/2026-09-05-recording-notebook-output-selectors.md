# Genuine workflow recordings and notebook output selectors

Date: 2026-09-05

## Problem

The prior short, screenshot-based recordings did not demonstrate the complete research
workflow. A new native browser recorder needed to show actual preparation, execution,
individual result inspection, downloads and execution of the exported notebook.

During the first long plant take, Jupyter successfully executed the cells, but a broad
text selector for `Frozen run verified:` matched both the source-code string and its
printed output. The recorder stopped because Playwright correctly rejected the ambiguous
locator. A fast preflight had not exposed the issue because Jupyter virtualizes cells;
the visibility of source text differed at the slower recorded pace.

## Resolution

- Scope the success selector to `.jp-OutputArea-output pre` and wait for a real output image.
- Wait for the loaded notebook's exact heading, not an initial placeholder cell.
- Verify every saved code cell has an execution count and no error output.
- Bind both exports to the selected immutable run ID, then check CSV membership and the
  notebook's frozen-run digest before using results.
- Authenticate Jupyter before recording, keeping its token out of URLs in the video.
- Label incomplete takes explicitly; never deliver a failed take as a completed workflow.

## Verification and boundary

The completed plant recording runs for 417.72 seconds. Its native browser capture includes
27 clicks, eight typed fields, ten selections and actual local Jupyter execution of all
three code cells. Raw video is transcoded to H.264 without speed changes or inserted frames.
Frame inspection confirmed a readable notebook plot in the encoded MP4.

This verifies the software path and recorded analysis, not human biological equivalence.
No physical measurements were fabricated, imported or promoted to validated evidence.
PXR remains a static equilibrium research model; metformin retains its heuristic mapping.

## Reuse

Run `tools/record_research_walkthroughs.cjs` against the isolated review service. A preflight
checks selectors quickly, but a paced full capture and saved-output inspection remain
required: speed and virtualization can reveal materially different browser states.
