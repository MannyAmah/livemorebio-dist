# Livemore full-scope recovery and biological expansion

## Dated delivery checkpoint — September 9, 2026

The current [delivery review](../DELIVERY_REVIEW_2026-09-09.md) records supported
functional recovery: owner-observed Atlas 9/9, Biology 7/7 and cell trace, local
hERG inspection with independently checked 21.72 Å distance, LIFE 121/121
acknowledgments, actual Human-GEM 2/7/31.5 ATP-capacity outputs with both negative
controls at 0, and successfully executed saved-result notebook analysis. These are
bounded software/reference-model observations, not whole-human or clinical
qualification. The molecular wheel bundle/notice gap has RED→GREEN evidence and
independent source review. The timer/tracker remains disabled.

**R42 is ACCEPTED** for the independently inspected 24-slide technical PPTX/PDF
and its source citations. No other register status is advanced by this checkpoint.
R40 remains open; insulin and LBHR-172/129/062/030/135 remain 0/6 validated, with no
substituted assays. Direct native qualification, final source/full-suite and
video acceptance, external model/access/rights, physical LIFE/Cendos, complete
onboarding and release obligations remain open. The current tester guide is for
the supplied checkout, not a published installer or current remote commit.

The original dated status and all historical attempts/failures below are retained
unchanged, except the explicitly authorized R42 register status. They must not be
read as erased or retroactively successful by this newer checkpoint.

---

Date: 2026-09-08. Scope approved by Emmanuel: “Proceed as itemized. … EVERYTHING LISTED MUST BE BUILT.”
Branch: `codex/full-scope-recovery`. Preserved parent: `83994425f2a3884188b1e3ee494241eba5c272f5`.
Status: ACTIVE; first regression implementation packet independently cleared, implementation acceptance pending. This is not a completion or release claim.

## Current continuation checkpoint — selection recovery and preserved clients

**Active continuation, September9:** the user-supplied direct Atlas MP4 resolves
the outstanding reference by user mapping; do not request it again. All R01–R51
remain in force and requested experiment videos remain0/6. The installed product,
previous stores and source parent remain preserved. No release/PR was published.

The local molecular dependency installation is preserved. BuildQkgKLS FAILED
the32MiB stats bound; successorFJiuBt FAILED asset-report admission; B NOT_RUN
in both. Their failures remain intact. The exact stock empty-object-leaf parser
correction passed49 independent cases including all retained actual stats/asset
bytes. Fresh IviiqA now completed both builds, byte-identical3assets, original
inputs preserved, both children settled/absent. Independent actual emitted
membership review is clear:59 package/version pairs and1155 unchanged source
files. Complete notice assembly now has16 independent passes and separate
root verification of54 original bodies,89 credits and1228 pinned inputs.
CAS/fastapprox intermediate permissions remain unresolved; no public vendor
or active Biology switch occurred. A shared-binding CSP formatter has56 independent checks;
upstream Molstar4.4/React18 source API compatibility is independently clear,
not actual WebGL/CSP/control acceptance. No security-policy relaxation. Fixed
execution reference wiring has16 independent passes; frozen-member wiring23,
with148 combined preservation checks. The private adapter browser increment now
ran once after42 independent harness checks. Original KRAS4OBE and Help rendered,
but the packet FAILED at selection: the checker selected a sequence position
without deposited coordinates. Two original images also exposed overlapping
viewer controls. A coordinate ERR_ABORTED was retained without terminal timing;
its cause remains unresolved. All owned closes settled and all15 recorded PIDs
were separately absent. The failed WoWI5H directory is preserved, not reusable.
The reactive-layout/owned-button correction and independently identified portrait
stage minimum are now implemented with5 RED→GREEN cases and153 related maker
passes. Fresh private successorLygJpf adds present-residue selection and passive
request/retirement timing, with10 RED→GREEN cases and52 total inert maker passes.
Independent review cleared the three product files (153 repeated passes) and
the private harness (52 repeated passes). Actual LygJpf then reached a genuine
5.82 Å distance, but its unit checker rejected the canonical angstrom symbol;
that original result remains FAILED. The narrowly corrected checker passed 65
independent cases. Its separately authorized kCPxWp actual run passed all four
interaction stages and all 11 original captures, including mobile, but remains
FAILED overall: the first D0 coordinate request retained ERR_ABORTED before D1
and all explicit teardown. Root inspected all originals; an independent data-only
review confirmed all image hashes, 30 pins, source identities and settled cleanup.
The transport cause remains unproven; no automatic retry or failed-request waiver
is authorized. Explicit pig 4INS remains separate from unavailable human INS.
Ordinary Biology and all three consumer-context acceptance remain open. See
the September 9 molecular-layout actual decision and independent-result report.
The narrowly reviewed passive diagnostic passed 110 independent inert checks,
then its once-only OYVOcS actual run passed all four stages and 11 planned
captures with all 29 original Playwright requests finished (no ERR_ABORTED).
It still FAILED overall on the observer's TRANSPORT_PROTOCOL_CLOCK check;
29 CDP network terminals were not admitted. All eight owned closes settled,
root verified exact 20 recorded PIDs absent and all 30 source/harness pins
unchanged, and inspected the 11 planned images plus the failure image. Original
abort non-reproduction is not a cause/fix, and the observer's rejected timestamp
was not retained. Independent data-only review confirmed all original source,
image and transport receipts; the overall result remains FAILED. The fresh
private W8cBUx clock-evidence correction now has 124 maker inert passes after
13 new RED cases, preserving both clock refusal predicates and all original
110 tests. Independent grading cleared124 cases; its separately authorized
once-only actual then completed all4stages/11captures with29PW/server finishes,
but remainsFAILED under the unchanged ordering predicate. It now retains27
finite FINISHED timestamps earlier than RESPONSE but later than REQUEST,
explicitly exposing the observer's ordering issue. All8ownedcloses settled,
root verified17recordedPIDs absent, all12images and both30-pinsets. Independent
data-only audit7fd298 confirmed every retained clock triple, pin and image.
The narrow request-origin-floor correction now passed 163 independent inert
checks, preserving the 27 raw clock witnesses and all unrelated refusal rules.
Its separately authorized USnuJu actual completed all four stages/11 captures,
but remains FAILED on three real coordinate ERR_ABORTED events (KRAS, TP53,
EGFR); no clock rejection recurred. Root inspected all 12 original images and
verified all 21 recorded PIDs absent. Independent data-only audit 8c922a confirms
both pinsets, full original/embedded equality, all image hashes, exact failed
request correlations and eight settled closes. Further browser attempts are
held for source-based cancellation diagnosis; no product-reader waiver or
active ordinary switch is authorized. The ordinary shared-inspector plan now
incorporates independent stale-handler/context and resolved-failure corrections.
Its preservation-safe data-controller prerequisite reproduced 18 failures before
the first correction and then passed 78 affected maker checks. Independent
review found two additional stale paths (late cell response and cached anatomy
selection). Four further RED cases reproduced both paths and their related
edge cases. The four-site correction now independently passes all 82 affected
checks and the two unchanged independent probes. This clears the narrow
controller review, not whole-Biology acceptance. The separately authorized
PHua9I actual-page check completed all six data-recovery interaction stages and
original captures. Its overall result remains FAILED: one unidentified local
request failure and two exact blocked-style console messages were retained.
Root inspected all six originals; all four owned closes settled and all twelve
recorded PIDs were independently absent. The fixture explicitly disabled graphics
and supplied no participant or numerical biology, so this is not graphics or
whole-Biology acceptance. Preserve the consumed runner and original failures;
the missing request identity prevents causal attribution or a success waiver.
The follow-on three-line stale-warning/neutral-heading correction now has
84 independently repeated affected tests and two independent context/refusal
probes. It preserves the explicit stale warning when cell entry is refused,
without changing model values or reference-preview semantics. A fresh private
request-evidence diagnostic subsequently passed43 independent inert checks and
ran once as1xHVWj. All6interaction stages passed, but overallFAILED remains:
bootstrap204thenERR_ABORTED; two build503 responses lacked terminal events.
All35pins/94events/6originalimages were independently checked; all4closes settled
and12recordedPIDs were absent. Root inspected all images. This identifies only
this run, not PHua9I's unknown failure or a cause. A source-reviewed narrow
build-status response-ownership correction is now approved for red-first tests;
no production auth change or consumed-run retry is authorized. The build-status
correction now independently passes 101 affected tests; root independently passed
49 framing-harness checks. Fresh twZXX0 actual passed all six stages with both
build 503 requests FINISHED and no pending requests, but overall FAILED remains
on bootstrap 204 then ERR_ABORTED. Root inspected all six originals; all four
closes settled and 12 PIDs were absent. No additional retry or whole-Biology /
physiology claim is accepted. See the September 9 build-status response-ownership
plan for exact code and evidence.
See the retained-clock once decision, request-floor correction/data audit and
ordinary-Biology molecular-switch plan.
This does not replace any visual, biological or recording requirement.

Atlas cleanup attribution now has271 independently repeated offline checks,
including late/failed resource ownership and bounded detached receipts. This is
diagnostic readiness only: no new Atlas browser attempt ran, the older coordinate
terminal and unconfirmed individual closes remain unresolved, and no reader or
request-success exception has been introduced. It does not replace the required
whole-body visual restoration or full browser acceptance.

The physical calibration form's two native attempts remain FAILED and preserved.
The corrected semantic selection harness now has329 independent passes. Fresh
actual runhaagy7pu passed nine observations/six choices/four original desktop/
mobile images, zero POST attempts and zero mutations, all cleanup settled. Root
inspected all originals and complete receipts; acceptance covers visible local
validation only, not native popup-key behavior or physical-v3. The internal
encrypted exact-manifest registry core passed706 preservation/13 actual API/
four additional independent tamper/consent checks. The public physical-v3 route
remains disabled pending the fixed-peer/consent/physical-receipt admission chain.

OSP default test portability is source-review clear:43 authored cases pass without
private artifacts;20 explicit historical forensic checks remain independently
invocable, not skipped. Combined preservation503 passes,2 native cases excluded.
No OSP native scientific gate has been opened. These technical counts overlap
earlier reports and must not be added into a claimed whole-product pass total.
OSP timing's separate3s complete/2.5s work amendment is now implemented after
the molecular pair settled and released its owner-source hold. Root independently
read the exact5added/3replaced runtime lines and two inherited timing literals:
524 passes/2 native cases excluded, including all21new budget cases, I/O0.
A separately reviewed fresh OS-only preflight now completed O1–O7 in9.679s,
exit0, after56 independent offline passes. Root reverified all original stream/
receipt links and all eleven recorded parent/child PIDs absent. Separate actual
review is clear for these seven OS-only conditions, with all18 raw stream links
independently checked; see the September9 fresh-preflight independent-result
report. O6's original UNRESOLVED_CHILD and incomplete stream
receipts remain intact, with O7 refusal and later natural-exit settlement recorded
separately. A separately reviewed once-only launcher then passed45 independent
inert checks and one retained-byte technical packet was explicitly authorized.
That actual packet FAILED at S01/UNEXPECTED_DESCENDANT before any barrier or
comparison; S02–S17 are NOT_RUN. The worker was terminated and cleanup settled;
recorded parent/leader PIDs are absent. Original packet/control links and empty
EOF streams independently match; the rejected descendant row was not retained,
so its identity cannot be inferred. The consumed CA533x attempt is preserved.
No new native retry, model admission or scientific gate is authorized. See the
September9 once-launcher independent-decision report.
The rejected-process evidence-retention correction now has an independently
reviewed bounded sidecar design and root approval for red-first implementation
only. It preserves admission predicates and retains rejected/partial records
separately within existing ceilings. Root independently reviewed the frozen
implementation and repeated553 offline cases (two native watchdog cases
excluded, zero unexpected I/O). Work/cleanup sidecars and their final/pending
space reserve stay inside existing limits; process admission remains unchanged.
The fresh once-only launcher then independently passed72 inert cases. Its exact
authorized qUfcQ6 actuale16aee FAILED again at S01/UNEXPECTED_DESCENDANT, but now
retains the complete unadmitted startup sample: R plus `/bin/bash`, argv
`sh -c 'uname -a'`. Cleanup settled and exact three recorded PIDs are absent;
S02–S17 remain NOT_RUN. Independent data review is complete. Source-only tracing
identifies the retained default-R utils initialization path through the uname
lookup and exact uname command; this does not identify the original CA533x
child. The separate initialization-contract correction now independently passes
656 offline checks, with two native watchdog cases excluded and zero unexpected
I/O. Source review corrected the R missing-path predicate and excluded access
time from stable ACK metadata; those earlier defects remain in the history.
It admits only source-established owned startup topologies, closes permission
at configuration-ready, and preserves model-phase rules. Actual R/CLR startup
was tested once after109independent launcher checks and a separate root decision.
The oWpRO1 actual completed initialization-ready/ACK and both dotnet startup
barriers, thenFAILED at S01/EVIDENCE_FILE_TYPE before any biological comparison.
S02–S17 remainNOT_RUN; cleanupSETTLED and all4recordedPIDs absent. The exact
offending leaf was not retained and is no longer present, so its identity is
unknown. Further native attempts are held for explicit direction after this
third failed native path. No model admission or scientific pass is claimed.
Whole-source compileall passed with private cache output; it is syntax evidence,
not scientific or whole-product acceptance. All six detailed recordings remain0/6.

**Latest September9 checkpoint (supersedes the older status paragraphs below):**
the14-image actual banner/recovery run`y11aq6ff` passed in9.193s with all owned
children/descendants/listeners absent. Root inspected all14 originals and accepted
only the normal-flow banner/nav correction. The subsequently reproduced stale
compound feedback and source-insensitive cardiac labels are now corrected with
647 maker preservation passes and16 independent targeted passes. Their new
first16-image browser attempt failed at D1 because its checker incorrectly
rejected the normal-flow header scrolling out of view. That failed evidence is
preserved. The corrected harness passed174 independent tests and fresh actual
run`5ztzbevi` passed8.440s, all16 originals inspected by root, all owned processes
and listeners absent. Only targeted message/cardio-label corrections accepted;
dense text/mobile
navigation and full UI acceptance remain open. See the original actual-acceptance
report and `2026-09-09-legacy-current-feedback-correction.md`.

The fixed local molecular reader/catalog, protected routes and strict durable
access records now have153 maker checks; root independently reviewed/repeated
63 audit cases, and the separate reviewer independently passed90 actual API/
audit/reader cases. A source-timeout422 misclassification was reproduced and
corrected to503 without changing body-timeout422. Biology's new local inspector
steps1–2 have82 independent offline passes; the additional keyboard-visibility
correction now has95 independent passes in11.47s after retained red-first tests. No active viewer
switch has occurred. Canonical dependency acquisition now retains all427
SRI-verified originals and inventories:416 reused and11 new GETs, exit0 in2.928s.
The original failed batches are preserved, including webpack-cli's exact
noncanonical alias. All224 unique notice originals have been reviewed; stock
offline install preparation and exact emitted-closure admission remain separate.
The first stock offline dependency install was attempted in an isolated directory
with scripts disabled. It stopped at CACHE_ADD_11 with SUPERVISOR_FAILURE after
12 commands; all command children exited0 and settled, but the failed supervision
result is not an install pass. Original inputs were preserved; no build or vendor
switch occurred. Read-only diagnosis and a red-first correction precede any new
attempt. That separately reviewed monitor correction is now independently50-pass
tested and its fresh actual install succeeded:15 commands,17.325s,18,090 files.
Root separately reverified all original archive/input/installed-file bytes and
stream hashes in5.237s; all owned PIDs absent. The first failed attempt remains
preserved. Private dependencies are available; emitted build/rights closure and
three-context browser acceptance remain open. The isolated wheel's single package-data
test and actual retained artifact now have independent source/byte review;
this is not full installer acceptance and the CellML packaging gap remains open.
OSP's once-only OS preflight FAILED at its first vmmap work deadline, with both
owned processes settled and absent. O2–O7 and all native scientific cases remain
NOT_RUN. Independent read-only diagnosis confirmed the1.5s work cutoff but could
not establish the tool's underlying wait cause. A separately bounded two-child
OS-only latency/mapping diagnostic was separately run once: vmmap exited0 in
1.806s, but the full diagnostic FAILED at the unchanged path parser's ambiguous
row check. Both processes settled/absent; raw output retained for read-only
diagnosis. Original scientific/preflight budgets/results remain unchanged.
The fifth visual post (MdrBwl) returned403 and no exact-ID search result. Emmanuel
has now designated the already inspected Human Atlas direct MP4 for that exact
question. Media access is resolved by user mapping, not by post retrieval; its
implementation and visual acceptance remain open. The other references remain.
All R01–R51 and all six exact programs remain active; videos0/6.

Latest bounded result: the diagnostic-corrected legacy browser run `uofz7at2`
passed all seven cases and produced12 original images in11.524s, source d0311baf…;
root inspected all12. Pending/uncertain state clears stale numerical displays,
later-read authority wins, and Twins/LIFE/History remain inspectable. All owned
children/descendants/ports settled. The prior two actual failures remain retained;
their causes are not rewritten by this success. Root found a fixed banner covering
navigation and inherited source-insensitive labels; these remain open visual
corrections. See `2026-09-08-legacy-preview-actual-recovery-acceptance.md`.
The temporary source freeze for that check is released for already reviewed next
increments; no requirement row or experiment recording is completed by it.

September9 continuation: six original public mmCIF files, the27-key catalog and
small reader/package/fingerprint changes are independently reviewed with47 passes.
Pig insulin is related-only; PXR source-numbering disagreement is explicit. The
protected route correction has32 maker checks (79 with reader preservation),
but its strict audit integration and independent route review remain pending.
The canonical offline dependency lock correction now independently matches all
428 placement records/427 versions; exact archive/rights acquisition is next,
not yet an install/build. The banner fix has6 independent checks plus retained
98/632 maker preservation; two new real error-state captures are being prepared.
OSP's fixed collector has440 independent offline passes/2 native cases excluded;
OS/native execution gates remain closed. None closes a six-program experiment,
full UI acceptance, installed release or requirement row below.

The continuing build remains on `codex/full-scope-recovery`; no installed release,
old store, cohort, experiment or service has been replaced. No requirement below
is closed by this checkpoint. The new base/LIFE/note preview publisher now has
red-before-green maker evidence:84 targeted passes, with79 startup,48 binding,
31 selected activation and29 existing binding preservation passes in isolated
no-network/no-model fixtures. Counts overlap and are not full-product validation.
Independent implementation review found and closed an additional preparation
uncertainty status defect; the final87-case packet passed independently. The
runtime packet is narrowly clear. The separate15-case actual encrypted
registry→preview packet now also passed root's independent repeat and review;
full client acceptance remains open. See
`2026-09-08-confirmed-preview-publication-implementation-review.md`.

The analogous activation/binding preparation status correction has192 maker and
independent preservation passes and is narrowly clear. The fourth prepared
observation transition and checked reconciliation action now have678 independent
registry passes in29.45s, with four original real-process cases still excluded.
The root-authored observation/reconciliation producer changes have78 dedicated
and287 preservation maker passes; independent source/route grading is now clear
with287 passing cases in4.04s. Its first completed independent invocation lost
its output receipt and remains OUTCOME_NOT_RETRIEVED, not retroactively a pass.
Root independently read the new546-line actual encrypted-registry integration
test and repeated all15 cases:15 passed in2.65s, private4nui57q9, I/O0/Git1.
The scoped wiring gate is clear; the author subsequently completed138 preservation
cases in4.88s, private46xjttp1, I/O0/Git1 with unchanged runtime/test hashes. Root
read that receipt; it is not an independent138 rerun. Actual browser/terminal
acceptance remains open.
All original REDs and the narrowly justified inherited fault-fixture corrections
are retained in `2026-09-08-observation-registry-implementation-review.md` and
`2026-09-08-observation-reconciliation-asgi-test-review.md`.

The legacy preview UI/terminal changes now have independent source review and
632 passing offline cases in32.30s, including real inline-handler tests. They
repair stale displays, once-only submission, typed terminal failures and
metadata-only preview logging; they do not redesign A+B or replace scientific
work. All six runtime and two new test hashes are frozen in
`2026-09-08-legacy-preview-client-recovery-implementation-review.md`. Three original
real-model clean-workflow cases remain unrun, not weakened or counted as passes.
The separately reviewed two-viewport12-image browser harness now has65 independent
offline passes in3.72s after five red-first corrections. Its once-only actual
launch stopped before browser creation: SERVICE_OR_TRIPWIRE_FAILED at2.4832s,
privatekju2ft7s, three guard receipts/no fault receipt, all three children reaped,
ports absent. All seven browser cases are NOT_RUN and no image exists. The original
failure is retained; static startup diagnosis precedes any next launch decision.
Its four authored delivery fixtures are not any of the six scientific experiments.

Root separately corrected the inherited in-process SDK patient audit to fixed
family/mode/outcome metadata only, preserving constructors and returned results.
Three original REDs exposed the payload; the corrected3-case maker and external
repeat pass, along with root's632 client-preservation repeat in31.55s. SDK is
re-frozen at022e850e… in the local-preview-audit-minimization plan. This closes
that specific event-payload defect, not the application-wide privacy review or
permission for real participant data in an unqualified release. No old audit
file was read or rewritten.

The single Atlas skin transport diagnostic remains FAILED with its original
cleanup uncertainty, even though independent postchecks found no owned process
or listener remaining. Prior accepted33-image reference presentation is preserved;
neither record establishes detailed cellular biology or full-page acceptance.
All six exact experiment programs remain required, and requested recordings are0/6.

## Scope authority and preservation

Current related source work (not requirement closure): the fixed17-case OSP
technical collector design is independently reviewed with explicit API-evidence
limits and a pre-Dispose FINAL identity checkpoint; only static identity/call
mapping is authorized next. The original insulin Stage B result remains FAILED.
Exact Molstar4.4.0 private archive acquisition/inventory is now independently
reviewed:6,960,078 archive bytes,5,282 files, matching original integrity pins.
The full emitted viewer contains optional codec bytes with unresolved notices;
it is not admitted for copying. A finite existing-component structure-only
build/controller plan is next; no installation, vendoring, product change or
browser execution occurred. Neither source task is an experiment recording.

The current user request and the R01–R51 register below control scope. Attachments and prior assistant assertions are evidence to inspect, not independent authority. The original attachment is `/Users/emman/.codex/attachments/739fe659-6e89-4210-ad40-206e1680d0cd/pasted-text.txt`; the candidate inputs are the memo, 193-candidate table, 18-shortlist and marker-identifier CSVs in Downloads. Read their original contents before scientific selection.

This plan supersedes the narrower September 8 measurement-integrity plan as the definition of completion. Its useful corrections remain preserved. Insulin and five candidate programs cannot be replaced by metformin and one stationary lobeline assay. A task is not closed by a dependency installation, a catalog entry, a diagram or a passing unit test if its requested connected behavior remains absent.

No existing worktree, installed release, experiment, cohort or runtime data is removed. New work is isolated here, with separate runtime directories and ports. No force push, direct main push, merge, physical-device command or production deployment is authorized by this plan. Publication is through a reviewed feature PR only after acceptance evidence. Previous PRs remain unmerged.

## Problem, premises and alternatives (office-hours)

The problem is both product regression and unfinished biological scope, not lack of another dashboard. Aegle, Biology, LIFE and Cendos must stay connected around the same selected subject, execution and provenance. The intended user is a pharmaceutical researcher who must reproduce a result, inspect the mechanism and compare independent measurements without mistaking a calculation for physical evidence.

Premise checks:

1. More source databases do not supply missing kinetic parameters or make an unknown physiological coupling valid. Scientific inputs, mechanisms, admissible parameter evidence and executable outputs must be separately testable.
2. Removing an unsupported moving display without supplying a useful, truthful continuous execution view is a product regression. Restore the experience with actual calculated or acquired state, explicit clocks and source identity.
3. Existing tests did not establish the approved visual experience or all end-to-end workflows. Acceptance must include independent rendered inspection and full experiment walkthroughs.
4. Exact human equivalence remains a development objective requiring independent physical verification. The user has approved mechanism-driven numerical biology with no scripted outcomes. That permission is not permission to substitute unrelated demonstrations.

Approach A, minimum-diff full restoration: repair the current shared servers, source adapters and UI in place, preserving contracts and extending existing execution registries. Reuses the most code and has the lowest migration risk; the existing large UI modules still need bounded internal seams.

Approach B, separate replacement platform: rewrite the application around new services/renderers and migrate all state. Greater architectural freedom, but much higher risk of losing existing functions or creating a disconnected second product. Rejected as inconsistent with preservation.

Selected approach: A with isolated, version-pinned scientific workers only where native runtime incompatibility requires them. This implements the user's approved preserve-and-extend approach; it does not reduce the R01–R51 scope. The approved A+B visual direction is retained; no new visual style contest or implementation of option C.

## Source truth baseline

- Latest preserved review worktree: measurement-integrity-atlas, commit 8399442.
- Prior clean genome-model build: genome-models-clean-workflows, commit 5c71ee8.
- Read-only process inspection found port 8850 running the older interface-twin-onboarding checkout, commit 0db2a4d; port 8890 runs measurement-integrity-atlas.
- Installed launcher still points to release 34b0f6f8f8d67d1bb78f2396b6964f22d8f439de. These builds report the same package version, 0.0.1. Exact build identity must become visible without exposing local paths or secrets.
- The actual user regressions must be inspected on both running UIs before assigning cause. Inspection of 8850–8852 and 8890–8892 is read-only: no submit, experiment execution, subject selection mutation, restart or borrowed credentials/data. Any mutating reproduction uses fresh isolated technical fixtures in this new worktree. This plan does not assume a healthy older baseline merely because it is older.
- Existing biological change contracts, v3 observation admission, immutable saved runs, signed device binding, PHI-safe errors and source/freshness safeguards are retained.

## Master requirement register

Status vocabulary: OPEN, IN_PROGRESS, VERIFIED_SOFTWARE, BLOCKED_EXTERNAL, ACCEPTED. Each row remains open until its full acceptance is met. VERIFIED_SOFTWARE alone is not clinical qualification. A blocker records a missing dependency without deleting or deferring the requirement. No row below is initially marked complete based on previous partial work.

| ID | Retained requirement | Required acceptance evidence | Initial state |
|---|---|---|---|
| R01 | Preserve functioning code, models, data, experiments, cohorts, integrations, designs and docs. | Preserved commit/worktree plus before/after state and regression comparison; no destructive migration. | IN_PROGRESS |
| R02 | Establish actual running-build regression baseline against the last functioning build. | URL, commit, process identity, source tree, screenshots and reproduced failures. | IN_PROGRESS |
| R03 | Restore normal Biology twin visualization and inspection. | Selected twin visible; meaningful body/cellular inspection works in real browser, no missing renderer. | OPEN |
| R04 | Restore continuously updating LIFE data and virtual counterpart with distinct clocks/source. | Continuous calculated/acquired updates, pause/resume, disconnect/freshness, selected-twin isolation and no fabricated physical readings. | OPEN |
| R05 | Correct apparent T2D-only cohorts. | Healthy and each supported condition selectable without implicit disease defaults. | OPEN |
| R06 | Compact, experiment-independent Cendos cohort selector. | Cohort-level selection, member inspection on demand, bounded panel at large cohort counts. | OPEN |
| R07 | Executable multiscale biology from atoms/ions through genes, RNA, proteins, molecules, organelles, cells, tissues, organs, systems and whole-body/environment. | Executable coverage map, typed exchanges and source-backed behavior at implemented scales; missing coverage explicitly remains open. | OPEN |
| R08 | Formal functional module contracts. | Units/state/input/output/mechanism/time/identifiers/person parameters/observation mappings/perturbations/uncertainty and reference tests for every module. | OPEN |
| R09 | Persistent scientific learning, relearning and evidence record applied to biology. | Versioned source and counterevidence, hypotheses, qualification tests and reviewed changes; learning cannot mutate a live twin. | OPEN |
| R10 | Build additional cellular/tissue/organ systems required by selected experiments. | Dependency-to-experiment mapping with executing modules; no easier substitute counted as completion. | OPEN |
| R11 | Install/evaluate and functionally integrate applicable Human-GEM, Recon3D or explicitly discussed suitable alternative, BiGG/COBRApy, tINIT/RAVEN, GTEx/HPA, All of Us/UK Biobank, PhysiCell/intracellular metabolism, RoadRunner/MaBoSS, PK-Sim/MoBi/OSP, SBML/SED-ML/AMICI. | Per-tool pinned source/version/rights/runtime, executed reference case and product consumer; controlled access recorded as blocked rather than faked. | OPEN |
| R12 | Verify integrations from actual input through execution to consumed output. | Integration tests, failure paths and reproducible artifacts for each adapter and downstream workflow. | OPEN |
| R13 | Report actual dependency, scientific evidence, rights and access blockers; propose alternatives before changing scope. | Explicit blocker ledger with attempted access, required action and affected IDs; no dummy success. | OPEN |
| R14 | Retain/audit NAR/ELIXIR, KEGG/GeneCards/MalaCards, Neo4j/TuringDB/OpenMed, Physiome and supplied tools, Rosalind, scientific databases/literature/viewers and bioinformatics. | Resource inventory with maturity and workflow routing, live verified integrations where permitted, not a catalog masquerading as implementation. | OPEN |
| R15 | Create/select/switch/inspect/manage individual twins and cohorts. | Browser, terminal and persistence tests across creation and switching. | OPEN |
| R16 | Real-person onboarding from permitted wearable/EHR/history/lab/medication/omics/lifestyle/environment/location sources. | Consent/access, identifiers, missingness, provenance and protected import; no PHI in demos/logs/external prompts. | OPEN |
| R17 | Ground non-person research twins in real reference population evidence. | Population source manifests and constraints; no fabricated enrolled-person identity or invented measured profiles. | OPEN |
| R18 | Meaningful individual biological variation. | Parameter provenance, joint constraints and heterogeneous response tests without disease-label shortcuts. | OPEN |
| R19 | Healthy defaults and explicit supported disease profiles. | Fresh-install and create-form tests; disease condition not silently introduced. | OPEN |
| R20 | Search/filter/pagination and compact cohort management. | Empty/large/search/filter/selection persistence and keyboard/browser tests. | OPEN |
| R21 | Approved A+B: A overall UI, B whole-body/time/green header, left multiscale path; C preserved only. | Reference-to-screen visual acceptance with all retained elements and responsive states. | OPEN |
| R22 | Whole-person Atlas distinct from deeper Biology, but connected. | Separate visual roles with same selected person/run/context; coherent navigation and no detached organ substitute for Atlas. | OPEN |
| R23 | Implement/account for all five retained video references; exclude only Derya. | Per-reference inspection and mapped working controls/biological views; inaccessible source explicitly reported. | OPEN |
| R24 | Detailed executing cell/gene/protein/tissue/organ responses. | Source-backed calculated or measured state visibly inspected at relevant scales in experiment walkthroughs, not charts alone. | OPEN |
| R25 | State-driven visualization, including null, adverse and unchanged states. | View-state lineage and no scripted effect sequences; missing quantity never invented. | OPEN |
| R26 | Explain biological time, device time, replay and paired baseline/treated. | Visible labels/help, exact time/quantity mapping and same-individual comparison. | OPEN |
| R27 | Every control visibly acts with feedback/provenance/errors. | Full interaction inventory and browser acceptance for loading/empty/error/success/partial states. | OPEN |
| R28 | LIFE is a dedicated advanced sensing/assay wearable, not a bundle of third-party wearable APIs. | Architecture, software contracts, UI and technical deck consistently represent the actual product and maturity. | OPEN |
| R29 | Physical and virtual software share device configuration/channel/timing/QC/calibration/firmware/cartridge/battery/comms/failure contracts. | Contract conformance, supported-command tests and actual numerical virtual counterpart; bench tests explicitly separate. | OPEN |
| R30 | Anatomical mounting and device/twin association. | Correct anatomical anchor, association/reassociation rules and selected-twin mapping tests. | OPEN |
| R31 | LIFE–Aegle–Cendos closed loop with controlled state estimation and traceability. | Admission→observation mapping→residual→permitted proposal→reviewed update, experiments and independent validation; modeled output never self-validates. | OPEN |
| R32 | Resolve RevB0 errors before fabrication; firmware/gateway/bench/physical verification program. | Hardware errata and corrected contract review, bench/firmware deliverables and explicit human-use/fabrication gate. | OPEN |
| R33 | Select insulin type and design/execute/visualize/analyze its experiment. | Exogenous insulin intervention with mechanism, individual cohorts, relevant biology and executed analysis; endogenous insulin or metformin not substitute. | OPEN |
| R34 | Select five candidates from attached 193/18/memo/marker files. | Five named IDs/materials, selection rationale/source review and experiment dependency map. | IN_PROGRESS |
| R35 | Accurate plant/food/extract/fraction/compound/salt/metabolite identity and properties. | Verified identifiers, composition uncertainty, source/property lineage and admission tests; no guessed values. | OPEN |
| R36 | Full experiments with question, cohorts, exposure, route/time, controls, endpoints, variability, uncertainty and validation. | Reproducible protocol/result packages without predetermined outcomes. | OPEN |
| R37 | Preparation→Cendos→twin Biology→saved results→bioinformatics/Jupyter. | Same execution IDs across complete workflow, exported notebook runs successfully. | OPEN |
| R38 | Blank Cendos Preparation and searchable History with recall/compare/rerun. | New session clean, original records immutable, explicit rerun lineage and comparison. | OPEN |
| R39 | Physical Cendos instrument/software/sample/measurement interfaces. | Sample/protocol/instrument identity, admitted measurement and validation contracts; no pretend wet-lab execution. | OPEN |
| R40 | Detailed actual-interaction videos for insulin and each of five candidates. | Six unhurried recordings with preparation/typing/clicks/execution/detailed Biology/analysis, not screenshot slides. | OPEN |
| R41 | Separate full-product explanatory demonstration. | Recorded complete ecosystem journey and component explanation. | OPEN |
| R42 | Detailed technological product pitch deck. | Technical architecture/biology/LIFE/Cendos/integrations/workflows/evidence/limits, not an investor marketing deck. | ACCEPTED |
| R43 | Short direct install/use guide preserving old detailed guide; verified one-line installation. | Copy-paste installation in fresh environment followed by documented first workflows. | OPEN |
| R44 | Clean new installation with no previous cohorts/experiments; explain supported coverage. | Empty-state release test and explicit opt-in examples. | OPEN |
| R45 | Meaningful terminal/SDK/notebook functionality and easy local auth without unprotected mutation routes. | Web/CLI workflow parity matrix, auth and secret-safety tests, reproducible launch. | OPEN |
| R46 | Entire UI visual inspection against approved designs/references. | Every page/tab/control/body/plot/stream and empty/error state, real-browser screenshots. | OPEN |
| R47 | Entire connected workflow tests including onboarding, switching, experiments, LIFE, history, exports, notebook, persistence and restart. | Integration/E2E evidence with exact build/environment and no test-data leakage. | OPEN |
| R48 | Regression tests exposing reported failures, plus real-browser validation. | Red-before-green tests and independent maker/reviewer separation; no unit-count proxy. | OPEN |
| R49 | Update technical/docs/whole-body and physical roadmap; retain prior experiment reviews, taurine research and treatment-free-resilience framework. | Source-backed roadmap and outstanding scientific questions, framework does not assert cures. | OPEN |
| R50 | Publish only after agreed acceptance with checkpoint/feature PR and visible unresolved scope. | Full R01–R51 accounting and child inventories, secret/data scans, reviewed PR. A partial-scope or externally blocked release requires an explicit user exception; no narrower self-selected “claimed release.” | OPEN |
| R51 | Preserve original scope through every status, plan and communication. | This stable register, progress/evidence updates keyed by ID, no silent substitution or deferral. | IN_PROGRESS |

## Execution order, not scope reduction

### Current continuation checkpoint

The user's latest continuation resumes this same recovery branch and full
R01–R51 register. No installed service, operational store, preserved release,
commit or publication target has been changed. The required programs remain
exogenous insulin and the five chosen candidate programs, not legacy metformin
or lobeline. All six requested experiment recordings remain outstanding.

- R15/R31/R47/R48: the audit-phase, stored-version inclusive-read and checked
  startup registry increments now have independent clearance. The latest bounded
  registry repeat passed616 cases in26.50s, with four real-process cases explicitly
  excluded. Checked startup publication and the failed-shutdown source-fence
  correction are implemented and independently cleared in their bounded packet:
  69startup/closed-manager/publication cases,31activation cases (41other-family
  cases explicitly deselected), and41fence/cleanup preservation cases passed.
  The original33startup RED results remain recorded, not erased. Root independently
  reviewed and repeated10 additional actual encrypted-registry-to-startup cases:
  10passed in1.89s, private `atcq3bt6`, zero unexpected I/O/process attempts.
  The P1 confirmed-commit/old-source exposure is corrected without reopening a
  closed manager or dropping unresolved cleanup ownership. Confirmed binding
  publication is now independently cleared on server3d521a02: new35, existing29
  (25other cases deselected), activation31 (41other cases deselected) and startup79
  including the10 real-registry cases all passed independently with zero unexpected
  I/O. Binding preserves the actual model availability and a coherent copied
  observation sample; uncertain storage completion denies use without fabricating
  a successful association. Root then independently read/repeated13 actual
  encrypted-registry-to-binding cases:13passed in2.20s, private p6nzjyya,
  zero unexpected I/O. Exact lost-ACK witness, damaged selected/unselected
  terminal evidence, rollback/close uncertainty and physical metadata-only
  association retain the correct source/evidence status. Actual user-facing
  and signed-device acceptance remain open, as do preview and
  observation-selection/reconciliation.
  These results
  are not native persisted-model, whole-product or human-equivalence validation.
- R22/R27/R46/R48: root independently repeated the corrected Atlas bookkeeping
  harness131 offline cases (9.00s). The once-only actual presentation run hsfd6dss
  then passed20 checks, produced33 original PNGs and exited0 with settled owned
  cleanup, unchanged cache and consistent three-service source identity. Root
  personally inspected all33; the targeted whole-person/selection/section/labels
  and metadata-card corrections are visually confirmed. Five ERR_ABORTED requests,
  the older full-matrix failures and full visual acceptance remain open.
  Root also repeated209offline one-skin diagnostic cases (15.07s), then identified
  an asynchronous metadata-delivery gap. Five authored probes confirmed premature
  failure on delayed delivery and false collection PASS on a rejected final emit.
  The separately reviewed acknowledgment-barrier correction now passes root's
  independent241-case offline run (17.58s, private iwsu4fbx, zero unexpected I/O,
  172 authored Node children). Root also exposed and retained two subsequent REDs
  for a failed acknowledgment while the original reader remains pending; the
  corrected observer exits on that evidence failure without altering the native
  request. Final source review independently cleared the same241 packet. The
  subsequently authorized one-skin run zpg7lltg reproduced native/PW ERR_ABORTED
  with canceled=true despite exact verified-buffer resolution and no application
  signal abort. All three collection stages passed, but the run remains FAILED
  because Node cleanup was unconfirmed. Outer supervision and root postchecks
  found all owned processes gone, no listeners, unchanged cache/source. There is
  no automatic retry or claim that reader cancellation caused this result.
  Independent retained-artifact interpretation is complete and preserves FAILED:
  the exact request-cancellation cause and individual rejected cleanup operation
  are not established. See the skin-terminal retained-results review. No repeat
  or production reader change is authorized by that interpretation; previous/full
  visual failures remain.
- R31/R48: cross-product snapshot parameter mixing retains its eight independently
  passing cases. A ninth regression exposes arbitrary exception-class names in
  publication logs; fixed phase-only logging now passes all nine maker cases in
  1.25s and is included in the independently cleared69-case packet above.
- R10/R11/R33: version-bound OSP source reading resolved important event and
  table semantics, with a retained-native provenance limit. The failed insulin
  benchmark remains failed. No new physiological execution or experiment
  qualification is inferred from source reading or static graph verification.
  The separately reviewed17-case retained-native technical probe's pure fixture/
  oracle/schema layer has independent clearance:196 new cases and331 combined
  independent passes in0.76s, with two native child-process tests excluded. Actual
  OSP startup has a source-confirmed dotnet child process and unresolved final-image
  inventory requirements; these need a bounded collector/supervisor amendment.
  No collector, supervisor or new native execution is authorized by that result.

```text
Preserved source + complete register + independent plan review
  → reproduced UI/LIFE/cohort regressions + red tests
  → restored connected subject/run/device experience
  → verified model/tool dependencies + tissue/person contracts
  → exogenous insulin + FIVE candidate-specific mechanisms/systems
  → detailed multiscale state-driven biological inspection
  → six experiment recordings + full-product recording + technical deck
  → fresh installer/guide/terminal parity + complete regression/visual QA
  → independent release acceptance + reviewed PR
```

Physical measurement access, approved hardware and controlled data credentials are parallel dependencies, not software-generated substitutes. Record every missing dependency against its requirement. Software work can proceed on reference and explicitly technical test data without claiming those dependencies fulfilled.

## Connected architecture and boundaries

```text
Reference sources → versioned model/parameter/material admission → biological execution
                      ↓                                      ↓
Person imports → permitted twin state → cohort snapshot → Cendos protocol/execution
                      ↑                                      ↓
Physical patch → gateway → observed stream                immutable result
Virtual patch ← observation operator ← executed twin state    ↓
                      ↓                              Atlas / Biology / analysis
                 residual comparison ← independent wet-lab / physical observations
                      ↓
                 reviewed calibration proposal (never automatic self-validation)
```

Shared context extends the existing typed contracts, not a new shortened authority: `{subject, cohort, member, run, condition, stage, model_identity, snapshot_identity, quantity, unit, compartment, native_axis_kind, native_axis_unit, native_axis_value, source_class, device_identity, acquisition_context}`. Not every field applies to every assay, and nonapplicability is explicit. Views consume the same immutable snapshot; switching subjects clears incompatible run/device selections. Native cellular time and assay time are not silently converted into whole-body clocks. A stationary assay is not a dynamic person experiment. Tests must reject wrong-member, wrong-unit, wrong-clock and stale-snapshot substitutions.

Model execution lifecycle: `prepared → admitted → queued → running → completed|failed|cancelled`. Invalid/stale inputs remain `prepared` with a named error. A rerun creates a new execution and preserves its parent. Result qualification is a separate lifecycle, not set by successful solver termination.

## Error, security and interaction review requirements

| Path | Named failure | Required behavior and test |
|---|---|---|
| Source/model admission | MissingSource, InvalidIdentity, UnavailablePermission, ChecksumMismatch | No guessed replacement; actionable error, unchanged registry and source evidence. |
| Physiological execution | UnsupportedMechanism, UnitMismatch, MissingParameter, NonConvergence | Failed/unsupported result, no fabricated effect or partial result presented as complete; conservation and numerical convergence tests. |
| Worker integration | WorkerUnavailable, Timeout, IncompatibleVersion, InvalidOutput | Bounded execution/cancellation, sanitized failure, reproducible input retained without PHI logging. |
| Observation stream | ReplayedFrame, WrongSubject, InvalidClock, StaleStream, InvalidCapability | Reject invalid admission, preserve last accepted state, visibly stale/disconnected; never restart free-running fake data. |
| UI data/rendering | MissingRenderer, InvalidContext, FailedAsset, StaleResponse | Keep selected twin identity, visible failure/retry, reject late response from previous selection; no silent chart-only acceptance. |
| Cohort/history operations | EmptySelection, MissingCohort, DuplicateRequest, ConflictingUpdate | Clear feedback, cohort-level bounded display, idempotent create/run and immutable history. |
| Installation | UnsupportedRuntime, DownloadFailure, IntegrityFailure, PortConflict | No broken pointer swap or data overwrite, exact error and recoverable previous release. |

Every new route uses existing authorization and data boundaries. Subject, model and sample inputs are PHI-like. No PHI in logs, recordings, repository or third-party model prompts. Use only authorized technical/research data in demonstrations. Model/source files are untrusted inputs; reject unsafe paths, oversized payloads, executable notebook injection and external resource loading. Credentials remain environment/secret-store inputs and are never printed.

For every form: validate before submit, prevent duplicate requests, retain entered non-sensitive state on failure, show progress and completion. For every asynchronous view: cancellation and context generation checks prevent cross-subject leakage. For lists: zero results, long names, large counts, search and pagination. Keyboard and responsive views are part of acceptance.

## Tests, observability and rollout

```text
Contract/unit tests → native-model reference reproduction → coupled integration tests
      → real browser interaction/visual tests → six full protocol walkthroughs
      → fresh install/restart/CLI/notebook tests → independent release review
```

Each model change records native units, conservation/positivity, timestep convergence, known counterexample and source benchmark. Source agreement is not independent human validation. Unknown parameters remain unknown; estimated values have provenance and applicability. Repeatability uses fixed recorded inputs, not hard-coded outcomes.

Performance checks cover large cohort selection, bounded stream buffers, long-running worker cancellation and rendering responsiveness. Do not launch all reference databases per experiment. Expensive model loads are version-keyed and worker-isolated; evaluate memory and runtime with measured benchmarks rather than invented latency promises.

Operational visibility uses build identity, worker readiness/version, execution state, frame freshness, rejected-frame counts and sanitized trace IDs. No biological values or subject identity in operational logs. A visible review build cannot be mistaken for the installed release.

Rollout: preserve base → isolated feature checkout/data → review stack → verified candidate installer → PR. Installed release pointer is not changed merely to make a screenshot look current. Rollback is stop only owned review processes and relaunch the preserved build with its own data; no deletion, downgrade migration or rewriting existing runs.

## Not in scope changes

No R01–R51 requirement is removed. Excluded by the user: Derya reference and implementing visual option C now. Excluded actions: fabricated biology or measurements, unsupervised therapeutic hardware control, licensing bypass, PHI disclosure, destructive rollback and direct main release. Generic tool upgrades, telemetry enrollment and unrelated framework rewrites are not needed for this product work.

## Review record

Scope mode: HOLD SCOPE. Office-hours premise and alternative review and CEO/engineering coverage are recorded using the already approved preserve-and-extend direction. The independent release-redteam reviewer cleared the first regression packet and shared build identity after revisions. This clears that packet for implementation, not the entire scientific program or release. The root read and approved the anatomy/cohort restoration subplan and the OSP Stage A isolated native feasibility probe; OSP product integration still requires its benchmark review. This file is not evidence that implementation or acceptance has passed.

gbrain, sequential-thinking and context7 tools were searched for but are not exposed in this session. Use local `docs/solutions/`, independent review and primary-source documentation as explicit fallbacks. Compound Engineering commands are not exposed; preserve durable lessons under `docs/solutions/` without claiming an unavailable tool ran.

## First regression implementation packet

No biological equations, calibrated parameters or existing observations change in the first packet. Named entry points are `/health`, `/api/services`, `/`, `/biology`, `/cohorts`, `/cendos` and `/patch`. Existing source reuse: `aegle/server.py`, `aegle/console/lib/shell.js`, `biology.html`, `protocol_biology.js`, `subjects.js`, `life_patch/`, `life_system/service.py` and `cendos/service.py`. No replacement frontend framework.

1. **Build identity (root owns shared runtime identity and services):** add a shared read-only build report bound to the imported package, never current shell directory. Include source fingerprint, validated commit when available, package version, source kind and startup identity. No absolute filesystem paths, environment secrets or subject data in public output. Expose consistently from the three existing services and show compact build identity in shared UI. Missing VCS in an installed wheel must report unavailable rather than using a surrounding unrelated repository. Tests in `livemorebio/tests/test_build_identity.py`: wrong CWD, absent/malformed metadata, git unavailable, source mutation changes fingerprint, all-service agreement and sanitized output. Do not solve this by changing installed pointers.
2. **Biology restoration (UI owner after reproduction):** preserve person/run identity and restore anatomical inspection in run context rather than hiding the entire stage. Render selected run/member state only; do not use the current active twin's unrelated geometry state as if it belonged to a saved individual. Inspect graphics failure separately from intentional hiding. Reference geometry remains reference geometry, not a patient scan. Regressions cover normal selected twin, saved human run, nonhuman assay distinction, renderer failure/retry, changed context, empty data and subject switch race.
3. **Cohort selection (UI owner, sequential with Biology UI edits):** cohort-level compact picker shared across protocols, member drawer/search/pagination, selectable healthy/supported clinical contexts from one backend capability source. No hardcoded `type2` in generic create forms. Tests cover empty/one/large cohorts, opaque long IDs, condition preservation, protocol switching and immutable history. Unsupported physiological contexts must not acquire invented parameters.
4. **Continuous virtual counterpart (separate LIFE owner once source contract reviewed):** engine-authored numerical samples bound to an explicit execution snapshot and registered virtual device. The observation operator consumes that execution's units, time, quantity and subject, not arbitrary caller numbers or a mutable global bus snapshot. Source class remains modeled; receipt/acquisition/numerical clocks remain distinct. Start/stop/resume/switch/disconnect must have visible effects, bounded buffers and no auto-loop of an 840-minute model day. Physical mode requires actual admitted hardware packets. A replay control is not continuous acquisition. Red tests precede gateway/UI behavior changes.

```text
Identity tests → shared report → health/service response → visible build label
Biology red tests → correct person/run state → renderer/data/asset outcomes → browser inspection
Cohort red tests → generic context-aware creation → compact cohort/member selection → saved protocol
Virtual stream red tests → frozen engine execution → observation operator → gateway → paired views
```

All environment consumers for new workers/caches/scratch/signing keys must be included in `tools/run_review_stack.py` isolation and `test_review_isolation.py`; installed operational roots must never be inherited accidentally. CI path filters must include `tools/**` and acceptance/recording documentation, with new ledger and bundled-asset checks. The initial packet is not a release or closure of remaining requirements.

## CEO/engineering review coverage

1. Architecture: preserve current service boundaries; isolate only incompatible native workers. Source truth ambiguity is reproduced, not inferred. The three current builds need identity checks.
2. Errors: seven explicit failure families above; every child implementation packet must map its concrete existing/new exception types and tested handling. Generic unavailable displays cannot count as visual acceptance.
3. Security: retain mutation authorization, owner-only isolated stores, PHI-safe errors and data-class boundaries. No new therapeutic command path.
4. Data/UX: all read projections are context-bound; async switch, null/empty/upstream failure, double-submit and large-cohort paths are required tests.
5. Code quality: reuse existing protocol/run/device registries; no second disconnected model/UI platform. Large console modules are edited in owned lanes to avoid concurrent conflicts.
6. Tests: red-first packet above, native scientific source benchmarks, integration, browser and complete workflow acceptance. Current 1033-test historical result is not this build's result or full-scope acceptance.
7. Performance: native worker runtime/memory and stream/render buffer caps require measurement; no invented p99 promise. List creation cannot render every cohort member into an unbounded form.
8. Observability: exact build, immutable run/context, worker readiness and stream freshness; operational metrics contain no physiological payloads.
9. Deployment: isolated review only, no installed-pointer change; PR publication gated by full ledger or explicit user exception. Rollback preserves old code and all data.
10. Trajectory: multiscale child inventory and scientific change records retain missing biology as active obligations. Software can build interfaces, but controlled-data and physical-validation gates stay explicit.
11. Design: approved A+B unchanged. Normal and run-specific Biology both need a usable body view, compact cohort controls, meaningful feedback, keyboard/responsive tests and retained-reference acceptance.

Parallel lanes: root shared runtime/services/identity; UI source/assets/console (one owner); science source/model subplans (read-only until source review); independent reviewer (no maker edits). New native model workers use separate module ownership from UI. Merge integration proceeds only after contract tests. No R requirement is moved to a later task without user agreement.

R07 child inventory must name each requested scale and all body systems. R11 child inventory must name every listed tool/runtime/dataset. R14 child inventory must name each retained catalog/source/backend/viewer integration. Each child records implementation, execution, downstream consumer, test/visual evidence and external evidence separately; parent closure requires every child's acceptance or a user-approved scope change. Mere installed/existing coverage cannot close a parent row.

R31 requires more than today's proposal ledger: a later reviewed packet must implement independent review decision, immutable model release, authorized application audit and rollback. No automatic self-calibration. Cohort performance tests use 1, 100 and 10,000 members with no more than 50 visible member rows per page; virtual-stream tests include a 30-minute technical soak and assert the configured buffer cap is respected, plus frame-order and reconnect checks. These are test workloads, not claims of measured performance before execution.

## Progress record

- Current continuation preserves the same branch and all R01–R51 obligations.
  Root and independent review have now matched the entire retained OSP declared
  graph to the pinned XML:28,683 nodes,64,564 edges,104 traversals and17 conditional
  witnesses. Static completeness is accepted;56 unresolved source declarations,
  semantic/domain questions and the original numerical FAILED result still prevent
  numerical admission. The earlier finite-only static FAILED receipt is retained.
  Atlas group-label/selection code has179 independently passing technical checks;
  its corrected20-case/33-image browser harness is being tested before any new
  browser run. Registry commit work passed392 scoped checks after independent
  terminal-audit/state-integrity findings were corrected, and is frozen for new
  independent review. Root's activation/binding/preview source-publication tests
  remain intentionally RED against the old server, with explicit preservation
  and lock-boundary checks. No server-integration acceptance, six-program video,
  physical qualification, full UI pass or release follows from these packets.
  Requested recordings remain0/6. No old operational store, installed pointer,
  commit, push, PR or production service has changed.

- Current recovery continuation: cohort storage-error adapter independently
  cleared157 checks; reference-cohort transaction authority independently
  cleared in287 combined checks. Atlas source-preserving extent/view-state
  correction cleared305 combined checks plus the final independent13-case
  layout seam review. Browser preparation exposed and corrected an unrelated
  shared-parser fingerprint regression; independent965 checks and unchanged
  normal reuse of all16 retained cache files now pass. Counts are overlapping
  technical packets, not whole-product or human validation. Ordinary desktop/
  mobile checks are being prepared with new isolated observation-only test
  data and read-only preserved anatomy. Prior Atlas3 FAIL/25 NOT_RUN stays
  unchanged. R33 insulin static event/initialization closure is under review;
  its failed source benchmark is not waived. All R01–R51, the exact six named
  programs/videos, physical LIFE/Cendos work, detailed Biology, guides, deck
  and release acceptance remain active. No existing store, installed pointer,
  operational service, commit, push or PR has changed.

- Latest bounded correction checkpoint: independent reviewers cleared the
  selection-action acknowledgment correction (618 checks) and bootstrap graph
  shape correction (405 checks plus reproductions of the original defects).
  Root's related cohort list/detail storage-error adapter now has157 focused
  maker passes and is under independent review. Reference-cohort same-transaction
  authority checks are implemented and frozen for independent review. These are
  overlapping software packets, not whole-product acceptance. All42 retained
  Atlas screenshots were inspected; read-only source analysis confirmed pancreas
  surface overlap. An exact source-preserving selection/view-status correction
  plan is under review before code. The Atlas3 FAIL/25 NOT_RUN result, six named
  experiment programs, physical LIFE/Cendos work, detailed Biology views, six
  recordings, installer/guides/deck and full UI/release gates remain open. No
  existing state, installed pointer, commit, push, PR or production service changed.

- Current continuation: independent Cendos source-fencing review cleared the
  frozen correction (74 dedicated + 7 preserved tests). Root independently
  cleared the approved clinical test-only migration (94 passed, isolated with
  connection/DNS refusal). Neither is clinical or six-program qualification.
  Independent reviews of the 564-case selection client and 355-case bootstrap
  packets each found one bounded P2: false action acknowledgment and malformed
  bootstrap graph fallback/cardinality. Both are being corrected red-first;
  those packets are not accepted despite passing prior suites. Root has now
  personally inspected all 42 retained Atlas images and recorded additional
  loaded-versus-visible count and intentional-empty-section issues. Atlas still
  has 3 failed and 25 unrun cases. All R01–R51 requirements remain open; no
  installation pointer, existing operational store, commit, push or PR changed.

- Continuation checkpoint: R01–R51 remain active with no acceptance row closed.
  New source-authority corrections are frozen for independent review: Cendos
  current-source capture/peer guards (74 focused tests plus7 preserved legacy
  assay tests), selection recovery UI/SDK/terminal (564 tripwire-protected tests),
  and registry bootstrap proof/audit authority (355 focused tests). Counts are
  separate, overlapping technical packets—not whole-product or clinical evidence.
  Six old scientific-integrity and three lifecycle assertions require reviewed
  migration to the approved observation-only contract; none is silently waived.
  Legacy activation/binding/preview/startup commit semantics and a public-reference
  direct-writer authority check remain integration dependencies. No new browser,
  physical experiment or requested-program recording has occurred in this packet.
  Atlas attempt2 is still FAILED; richer Biology and all six requested programs
  remain open. The historical source freezes below apply only to their recorded
  attempts; the combined current source has changed and requires a fresh freeze.
- Independent Beard precision-v2 grading is now complete: all715,765 required
  comparison pairs and477,159 historical pairs were independently recomputed.
  The five preregistered v2 comparisons pass; the old B1 failures remain.
  This is bounded numerical-source acceptance only, not arctigenin or human
  qualification. The completed result record supersedes the earlier pending
  review entry below; no new solve or rerun occurred during independent grading.
- Atlas's one authorized request diagnostic reached its90s deadline and retained
  a failed result with confirmed owned cleanup. Nine original verified-buffer
  promises resolved in correct skin-first/two-worker order, while five network
  requests reported ERR_ABORTED and their completion observers did not settle.
  Source/process/technical-context postchecks are unchanged. No acceptance is
  inferred and no automatic retry is authorized; functional UI coverage remains.
- Clinical failure-test packet now includes32 expected-red execution ownership
  cases, including concurrent single-owner cleanup, plus the separate descriptive
  intake/context/frozen-cohort/encrypted-audit suites. No runtime implementation
  is claimed by red-test authoring; runtime remains frozen for Atlas inspection.
- The single authorized Beard precision-v2 matrix completed with a numerical
  pass: seven branches, five required comparisons, worst normalized error
  0.0768236108206. The three historical B1 comparisons still each have18 failures.
  Exact retained arrays, source identities, checkpoint and14 cleanup receipts
  are undergoing independent grading. This does not qualify arctigenin, insulin,
  an individual or any of the six requested experiment programs. See
  `2026-09-08-beard-precision-v2-results.md`; no matrix rerun is authorized.
- Atlas browser attempt1 is retained as FAILED, not accepted. Desktop and mobile
  screenshots show the intact whole-person reference body, but seven warm-load
  prerequisites failed because callback-based network timing conflicts with
  verified application completion. Detailed controls, faults and disposal did
  not run and remain explicitly unverified. A bounded harness-only diagnostic
  and independent functional-coverage correction are under review; see
  `2026-09-08-atlas-request-timing-diagnostic-amendment.md`.
- Runtime/console source remains frozen at c9fee6db… for that diagnostic. Root
  authorized red-test authoring in the explicitly fingerprint-excluded tests
  directory without runtime changes. The first20 execution-source-fence tests
  fail because the new permitted-generation/DENY_ALL contract is absent; these
  are technical ownership fixtures, not numerical or biological tests. Their
  private run took0.29s with no running browser or model workload. Clinical
  registry/context/audit red tests are being prepared in the separate owner lane.
- Clinical availability correction now has a complete independently reviewed
  contract: no diagnosis-text model dispatch, useful observation-only selection,
  exact legacy/new idempotency, multi-person frozen cohorts, bounded member
  inspection, encrypted access-audit reservations, and a storage-independent
  source-generation fence including an explicit DENY_ALL state for uncertain
  selection commits. See the clinical-context availability amendment. This is
  pre-code acceptance, not restored-function or participant-model qualification.
  Implementation remains held until the current Atlas source freeze is released.
- Corrected Beard precision-v2 supervisor passed root and independent229-test
  packets (32 explicit opt-in skips). Its exact private once-only matrix driver
  passed complete independent source review. A separately reviewed harmless
  OS-only ownership probe is being prepared before execution authorization;
  no new source evaluation, compilation or numerical matrix has run. The v1
  failed convergence evidence and all six requested programs remain unchanged.
- Atlas harness review exposed lost failure measurements and an unenforced
  camera-sampling deadline before browser execution. The failure-evidence fix
  has20 passing root/independent guards; the strict20-second measurement-window
  fix is in red-first implementation. No visual/performance acceptance is
  inferred from these harness tests. Runtime source remains c9fee6db135dfd338c2b793ac4c4f22936db3c692421f728196ecfd3693de47a.

- Atlas current correction checkpoint: one isolated actual publisher install and
  independent source-to-GLB array verification passed (489 source components,
  nine partitions). Actual producer/consumer inspection then exposed canonical
  membership key-order rejection, enabled no-op controls and lost install-ACK
  uncertainty. The approved red-first correction produced 21 failing regressions,
  then 104 preserved/new passing checks; unchanged real manifest and all nine
  pinned-loader bindings now pass. Independent corrected-UI review and fresh
  real-browser acceptance remain required. R21–R27 are not closed by reference
  anatomy, and no source surface claims patient-specific spatial physiology.
- Beard v2 remains locked: independent review passed 195 static/technical tests
  with 32 explicit opt-in skips but found process-ownership cleanup and partial
  failure-evidence defects. A bounded v2-only correction amendment is under
  review; no new model execution or change to v1's failed result. Physical-v3
  authorization/recovery semantics are likewise under pre-code review. These
  checks retain all six required programs and all R01–R51 obligations.

- 2026-09-08: preserved clean 8399442 in new worktree; no source code or runtime data changed. Began independent regression, scientific-source and full-scope reviews. R01/R02/R34/R51 in progress; all acceptance remains open.
- 2026-09-08: first implementation packet underway in isolated worktree. Build-identity/health/host-spoof regression tests went red then green; 32 targeted tests passed with review-isolation tests. Biology-reference, capability and unsupported-template tests reproduced seven failures before implementation. These counts are packet evidence only, not full-product acceptance. No installed-pointer changes, commits, pushes or existing runtime-data mutations.
- 2026-09-08, continuing same build: R03/R06/R20 restoration has source-reviewed saved-member anatomy, renderer recovery and compact cohort controls, with isolated browser evidence under `docs/screenshots/full-scope-recovery/anatomy/`. R21–R24 full approved-reference acceptance remains open; restoring the existing reference anatomy does not fulfill a whole-person Atlas or all molecular views.
- R04/R08/R29/R31/R45/R47: native metabolic and cardiac continuous execution, encrypted frame/receipt storage, exact-source LIFE numerical observation delivery, authenticated lifecycle APIs and attached terminal/SDK controls now have bounded contract and independent regression evidence. The numerical LIFE probe currently supports the metabolic plasma-glucose operator only, not cardiac ECG or physical chemistry sensing. Continuous UI is in independent review; actual browser acceptance is pending. The closed-loop clinical-review/release/application chain remains open.
- R05/R15/R17/R18/R19/R20: source-pinned joint NHANES reference records and protected descriptive reference-cohort creation/list/member APIs plus compact UI are implemented and independently reviewed. Public reference membership is not admission of individualized kinetic parameters and must not silently enter a physiological experiment. Live UI creation, installation and executable parameter-binding acceptance remain open. Controlled participant data require separate authority.
- R10/R11/R33/R34/R35/R36: selected candidates remain Lion’s Mane (172), Yerba Santa (129), Rosemary (062), Burdock (030), Bilberry (135), alongside the exogenous-insulin program. Native OSP source execution was installed and exercised, but its Stage B numerical/source-domain acceptance failed and is not enabled as an accepted experiment. Beard mitochondrial source/import inventory passed 20 source tests against the exact pinned file; Myokit dropped three custom base dimensions and was correctly rejected before solving. A unit-preserving route is under investigation. No unrelated experiment substitutes for these six programs.
- R47/R48: actual three-service HTTP endurance evidence is isolated from every existing product store. The first attempt failed a test assertion at 20 checked frames and remains a failed record. Corrected harness gates have eight red-first passing tests and independent review. A real SIGTERM exercise recorded `NetworkCheckInterrupted`, `accepted=false`, and confirmed both owned producer and consumer stopped through subsequent HTTP reads. The new 1,800-second attempt is running; no endurance pass is claimed until it finishes and final frame/ACK/source/state checks pass.
- R40/R41/R42/R43/R44/R46/R49/R50 remain open: six required detailed experiment recordings, full-product recording, technical deck, verified clean one-line installation, all-page visual acceptance, updated external guides/roadmaps and final publication have not been completed by the preceding engineering checks. No commit, push, PR, merge, installed-pointer change, or mutation of old operational stores has occurred in this continuing turn.
- Broad isolated non-network test run: **2 failed, 1,590 passed, 6 skipped, 5 deselected, 44 subtests passed in 193.96 s**. Failures preserve old literal-source assertions for authorization polling and saved-run guards; the UI owner is checking equivalent behavior and must not insert inert strings or remove the protections to obtain green tests. This remains a failed full run until corrected and rerun.
- Separate offline wheel diagnostic reproduced a missing cardiac CellML asset outside the source checkout. See `2026-09-08-wheel-model-asset-diagnostic.md`. The existing managed installer uses a full source archive; its clean-install acceptance remains separate, not inferred failed or passed from the wheel test.
- Subsequent broad isolated run after the UI assertion corrections: **1,630 passed, 7 skipped, 5 deselected, 44 subtests passed in 209.79 s**, five existing warnings. Explicitly skipped: two source-only Beard opt-ins, two native cardiac opt-ins, official network model download, two pinned stoichiometry integrations. These require their dedicated source/environment gates; they are not silently counted as passes. Later control-revision corrections still require another broad run.
- The frozen-source three-service endurance run completed: 1,730 checked engine frames and 1,730 acknowledgments in 1,802.429 s, physical observations unchanged, final outbox empty, owned producer and consumer stopped. See continuous-network validation lessons for exact source identity and buffer evidence. This is transport-engineering evidence, not six-program scientific or human validation.
- Actual current-source browser acceptance found a Pause LIFE revision race after two advancing acknowledged frames. Preserved `continuous/attempt-1` is FAILED. Correction plan written and independently reviewed before implementation: separate lifecycle control revision from per-sample storage revision, retaining exact internal fences, no automatic mutation replay, and protection against late worker errors overriding Pause. R04/R27/R45/R46/R47 remain open until the corrected real interaction passes.
- Dedicated root native checks subsequently passed: **19 cardiac/numerical tests in 18.17 s**, including the actual native cardiac opt-ins; **5 Human-GEM integration tests in 69.18 s** on an isolated copy of the verified release-2.0 model asset. These establish the stated source/numerical controls, not patient equivalence or any of the six new programs. The official network-download check remains separate.
- Root independently reviewed and tested the control-revision correction: **249 targeted tests passed in 7.29 s**, including source, store, lifecycle, API and client guards. Two additional late-pause/ownership failures were reproduced and corrected before this pass. The isolated 8910 review stack may now be restarted for a new browser attempt; no existing installed or operational service is changed.
- Root read the complete all-page visual inventory and new Atlas subplan, and personally inspected the approved merged/A/B images and approval records. Gate A single-source assembled-anatomy investigation is approved; no guessed coordinate registration or whole-person geometry activation is authorized before its evidence review. Full visual and multiscale acceptance remains open.
- Atlas Gate A source investigation now records 489 exact BP3D reference components in common coordinates; independent review and conversion/rendering remain pending. Root independently read the current publisher license, source coordinate diagram, release note and evidence report. This is source admission work, not a patient-registered or functionally complete body.
- Browser attempts 2 and 3 passed the corrected visible pause/resume steps but failed genuine tab-hiding because the test browser's original automation session forced visibility. Root implemented the independently investigated, hash-pinned harness-only correction after three failing guard tests; 8 tests now pass. The real corrected browser workflow remains pending. No document-state override or manufactured visibility event is used.
- Superseding isolated broad run: **1,800 passed, 32 skipped, 5 network tests deselected, 44 subtests passed in 203.52 s**, five existing warnings. The increased skips include explicit new source/native-worker opt-ins, independently exercised in their 74-test packet. Skips are not passes; this broad result is not full physiological or visual acceptance.
- Corrected current-source browser attempt 4 **passed**: 50.684 seconds,42 acknowledged native frames, explicit pause/freeze/resume, actual hidden-tab polling pause while services continued, exact execution navigation to Biology and back,seven loaded organs/959,711 triangles,390-pixel no-overflow check,zero JavaScript errors and both owned producer/LIFE consumer stopped. Root read the complete receipt and all nine screenshots. R04's tested numerical workflow has concrete engineering evidence; full device parity, richer biology, A+B visual acceptance and six-program demonstrations remain open. Root recorded the remaining readability/pending-ACK defects before a separate correction packet.
- Readability correction and actual attempt6 independently passed: native setup collapses after Start, six-significant-digit display retains exact raw values, Biology precedes/borders plots, visible source clocks, deliberately interrupted frame-read recovery, keyboard/focus retention, genuine hidden-tab behavior, pause/resume and same-source return. 56.387 seconds/44 acknowledged frames at the final receipt, zero browser errors, both owned execution/session stopped; root and reviewer inspected all ten images. Attempt5's hidden-details text-check harness failure remains retained, not erased. This is limited numerical-workspace acceptance, not complete Atlas/cellular/physical qualification.
- Cohort source-guidance/indication-reset/busy-discovery defects corrected after red tests and independent review. Actual member-current-2 browser checks passed at source47ab6d26e0422eb98166af0fa81b5dd04589bda66148e0b8696592859a574d7a; root and reviewer read JSON and all five images. Dynamic source help, delayed failure/success/retry and typed indication preservation work; only age/conditions/lifestyle/SLC22A1 blankness was checked. Smoking default, source timestamps, full-profile onboarding and disease-to-model assignment remain open under R16–R19. No participant records were submitted.
- Atlas conversion/cache/API packet approved for implementation only. Fixed-source routes have 29 independently passing technical tests; metadata/build-identity/old-anatomy combined75 passed. Actual wheel extraction outside checkout carries declaration/modules/local viewer, with missing status network/write-free and no geometry bundled. Source/cache code is still being tested and independently reviewed before any actual conversion/install; source-preserving whole-person rendering remains open.
- Unit-preserving Beard source implementation remains locked. Independent source review found four correctable blockers (failure evidence preservation, strict redox nonnegativity, source-expression diagnostic context, and altered-source evaluator-lock bypass). Red-first corrections are underway; no Beard compilation/initialization/RHS/solve has occurred. Failed OSP benchmark remains failed; neither case is substituted for insulin or the five candidate experiments.
- Subsequent intake correction independently passed19 dedicated tests and actual desktop/mobile browser attempt1 at source d0f617d253ea45d13bcc69229b3bcbef93400a289788f9d557d969589f2c1917. Five original source/measurement times are retained; consent starts blank and smoking unknown; invalid timestamp rejection preserves registry and historical ciphertext. Full profile importing, model eligibility, missingness and consent verification remain open. See person-intake correction record for native app-construction disclosure and remaining visual issues.
- After independent clearance of four source-review corrections, root read and explicitly authorized one isolated Beard I0a/I0b/B0/B1/R1/K1 matrix. It completed but FAILED preregistered B0↔B1 convergence (552 derived-quantity/time differences); repeat/restart and local source/domain checks passed. On-disk gates remain false; no tolerance changes or retry. Full artifacts and cleanup/resource evidence retained in BEARD_NATIVE_SOURCE_MATRIX_RESULTS.md, with independent all-grid recomputation pending. This is not an arctigenin experiment or accepted physiological release; all six requested programs remain required.
- Atlas source/cache independent review caught raw lock errors, receipt-before-pointer ordering and an exited-leader/descendant cleanup gap. The first two have red-first corrections; root read and independently approved the bounded stdlib guardian amendment before lifecycle code. Actual publisher conversion and assembled rendering remain held until implementation review. No existing product geometry or data is removed during these checks.
- Independent retained-array review has now reproduced every Beard cross-run failure/count/maximum without any new solve. The failed verdict stands. A source-expression conditioning diagnosis explains the state-to-flux discrepancies; a new numerical-precision preregistration is being prepared, not executed. All six scientific programs remain open.
- R12/R21/R43/R45: attached Atlas status/install controls added under an independently approved narrow plan, with 95 client and 23 command red-before-green tests. Expanded existing client preservation totals304 passing tests; outside-checkout wheel smoke passes with process/helper/client/command modules and no automatic geometry/twin creation. Independent code review and actual HTTP/renderer agreement remain open. No published installer claim, commit, push or existing data-store change.
- Latest retained ordinary Atlas run: all17 targeted browser assertions passed,
  with30 original PNGs personally inspected by root and the independent reviewer.
  Whole-person/native source selection, isolation, restored assembly, section and
  mobile controls have narrow evidence. Group-label overlap and a stale results
  highlight remain product defects; tall host screenshots contain sticky chrome.
  Raw supervisor CLEANUP_UNCONFIRMED is retained. Root's direct postchecks found
  no listeners or owned PIDs, only TIME_WAIT sockets; the bind-based teardown
  checker needs a distinct listener check, not a retroactive PASS. See the
  ordinary-presentation independent results and post-presentation proposal.
  Old full Atlas28PASS/3FAIL/25NOT_RUN, transport/performance and all-product
  acceptance remain unchanged. No old operational service/store was modified.
- OSP static source packet independently passed90 technical tests, then its one
  authorized original-source inspection FAILED on P26258's publisher literal NaN.
  Root read-only inventory found56 such missing P values. The source and original
  numerical FAILED evidence remain unchanged. An explicit non-admitting static
  missing-input amendment is under independent review, not a new numeric result.
  Registry committed-transition helpers and narrow Atlas label/selection fixes
  continue in separate red-first lanes. AllR01–R51 remain open/in progress, all
  six exact programs remain required, and requested experiment recordings are0/6.

## 2026-09-09 timed continuation checkpoint

User requested an elapsed timer, visible done/current/remaining tracking and
complete alternatives for repeatedly failing paths. The read-only board at
`http://127.0.0.1:8865/` reads this exact R01–R51 register, rather than replacing
it with a smaller task list. Restart/use instructions are in `docs/BUILD_PROGRESS.md`.
Its saved phase start is12:57:59UTC; calendar time is not active work or an ETA.
Each handoff records paused activity explicitly. No accepted row is inferred from
the number of tests or a running timer.

- R03/R27/R45/R46/R48: replaced bootstrap/global-request interception with
  navigation-first local authorization. Independent66PASS and ordinary nine-page
  browser inspection; API protection retained. Full scientific/UI acceptance
  remains open. Details: navigation-first session and browser-result documents.
- R04/R29/R45/R48: corrected the valid LIFE empty-reference selection without
  creating a twin or relaxing execution admission. Independent34PASS, then fresh
  desktop/mobile source-read, session-reopen and disabled-control checks. Read
  timeout wording no longer implies an uncertain mutation. No physical telemetry
  or experiment created; the continuous LIFE acceptance remains separate.
- R11/R12/R33/R48: direct .NET worker core built as the complete alternative
  direction to the consumed R/CLR path. Offline fake/API/encoding tests and
  source/build identity evidence exist; a reproduced cross-language negative-zero
  defect was corrected without changing the numerical consumer or its oracles.
  Parent supervision/native entry and actual scientific qualification remain
  unimplemented/unqualified, disabled, and next in this lane. No new native solve.
- R51: board tested (14 independently repeated cases; extended15-case suite also
  passed) and actual desktop/mobile timer/filter/freshness/update checks recorded.
  Verified increments, incomplete whole requirements, six exact experiments and
  separate full-product recording remain distinctly visible.

The ordinary review servers and their fresh private stores were isolated from
installed8850–8852 services. Both owned review stacks were stopped after their
checks, stores/evidence preserved; the separate read-only tracker stays available.
No original product/data reset, accepted-requirement deletion, compound
substitution, commit, push, PR or release. The entire R01–R51 scope and all child
inventories remain active; experiment walkthroughs0/6 and ecosystem demo0/1.
