# Molecular browser result and narrow correction plan

2026-09-09. R03/R24/R27/R46/R48 remain open. This is not a scientific
experiment or acceptance of the ordinary Biology page.

## Preserved actual result

The once-only private adapter check at
`/private/tmp/livemore-molecular-adapter-browser.WoWI5H/run` exited1;
session83120/completionb97fce. Result **FAILED**,23.979790959s.
Original browser result SHA256
`9ae4e9bf4e72173f6fdafa14b29cb4b70c226e2d0d2e99e88ee3933bcb4a3391`;
supervision SHA256
`701658e008db16b43964d6958168ae6fbae56b4d70e5bf7ca96010c022e3d2d4`.

D0 rendered the original KRAS4OBE and reported READY, with a1289×578 canvas.
The recorded source-load interval was6388.770584ms, not physiological time.
D1 opened real help but failed SELECTION_UNAVAILABLE: only one selection-history
item after the check clicked the first two sequence spans. No distance was
created. D2 and mobile were NOT_RUN; the other nine planned captures do not exist.
The attempted failure image was unavailable; that absence is not a successful
capture. There were9 GETs/3,929,176 served bytes,0 page/console/CSP errors and one
coordinate request reported ERR_ABORTED. No timestamp was retained for that
terminal, so its relationship to rendering or shutdown cannot be inferred.

All four owned closes (page/context/browser/server) settled. Python reaped
Node36683 and retained14 descendant identities, all absent in its final snapshot;
both listener checks returned NO_LISTENERS. Root's separate exact15-PID check
returned no rows, exit1 (22f2be). No installed service or operational store ran.

Root independently viewed both original PNGs and reverified their byte hashes,
all30 input/harness pins, and exact browser-result equality to the supervisor's
embedded record (23c6c8). Desktop image131491B SHA
`885b1fb0a0d9608e53ecc7878d3d53fea733a08d36c968777798eb676201910d`;
help image85041B SHA
`f9d822a241861c1f6ac8ad3f6cbfe6d4e96accceff4dd22589f0bdbad5952c77`.
These show actual rendered deposited coordinates, not detailed dynamic biology.
No consumed file is to be edited or rerun.

## Source-backed findings

1. **Product layout defect.** Original images show the sequence panel covering
   the inspector's status/scope area, while the tools extend below its stage.
   The pinned upstream `PluginLayoutStateParams.controlsDisplay` defaults to
   `outside`. Its `controls-outside.scss` deliberately places top controls at
   negative top and lower controls below the viewport. The current spec does
   not override this default. The current global inspector button rule also
   adds margin/min-height to every upstream button. A nonzero canvas alone did
   not establish a usable, readable dialog.
2. **Test selection defect.** In original4OBE, entity sequence position1 is
   GLY, but chainA atom-site rows begin at label_seq_id2/MET. Its sequence scheme
   records no observed residue for that first GLY. Upstream sequence clicks
   yield empty loci for missing coordinates, and `tryAddHistory` ignores empty
   loci. The checker must choose two explicitly present residue elements, not
   blindly the first two sequence positions. No atom is to be fabricated.
3. **Transport cause unresolved.** The molecular loader already avoids canceling
   its reader after EOF. Its exact-byte/hash/parser checks reached READY, yet
   Playwright reported a failed request. Neither fact erases the other. This
   result does not establish the cause of either this terminal or the older
   Atlas terminal. No reader change or exception waiver is proposed here.

## Proposed correction, before code

Use the same controller and unchanged IviiqA bundle; no rebuild, dependency
upgrade, replacement renderer or public vendor switch is needed for layout.
At the controller's existing `PluginUIContext` construction, make a detached
copy of the returned spec/layout/initial objects and set only
`controlsDisplay:'reactive'`. This uses the pinned upstream internal layout
classes and preserves all actions, behaviors, source/model selection and security
settings. Narrow button spacing to the inspector-owned close/retry buttons;
do not override Molstar's own control sizing. Confirm both viewport orientations
and actual status/scope visibility in the next reviewed browser increment.

Write RED tests first in the existing controller fixture: the spec passed to
the actual constructor seam must retain all original settings, use the internal
responsive layout and not mutate the adapter's shared spec. Add a narrow CSS
regression for the owned-button boundary. Preserve all existing95 controller/
loader checks and related frozen/execution consumer tests. No physiology change.

For a separately prepared private successor harness, change only the sequence
selector to actual `.msp-sequence-present[data-seqid]`, assert two distinct
present IDs before clicks and retain them. Preserve finite distance/selection
assertions. Add passive request-terminal timestamps and active stage, including
cleanup start, so a new failure can be located without inventing its cause.
Do not erase ERR_ABORTED or admit a failed request as successful. Keep all11
required original captures, six source controls/INS distinction and existing
time/request/cleanup limits. No retry from the consumed WoWI5H directory.

Independent pre-code review is required before these edits. Then independent
implementation grading precedes one fresh actual browser decision. The six
scientific programs, Atlas restoration, physical closed loop and full product
acceptance remain outstanding; this plan does not replace any of them.

## Independent pre-code finding and agreed portrait amendment

The independent reviewer found that reactive layout alone would still leave
no usable canvas at the planned390×844 viewport. Root independently read the
pinned upstream layout.scss, controls-portrait.scss, variables.scss and original
adapter spec: portrait top97px plus lower tools361px consumes458px. The present
50vh stage is422px. Missing left/bottom components do not remove the active
top/right regions. This is a concrete layout arithmetic defect, not a reason
to change coordinates, dependency versions or scientific content.

Extend only the inspector-owned stage rule with a700px minimum under the exact
upstream `(orientation: portrait) and (max-width: 1000px)` condition. That retains
at least242px of canvas at the planned mobile viewport while the already
scrollable outer dialog gives access to the tools and provenance. Preserve the
normal landscape rules and all upstream internal styles. Add a RED CSS/breakpoint
arithmetic guard and verify actual usable canvas dimensions and source/status
visibility in the fresh browser packet; nonzero dimensions alone are insufficient.

Root accepts this narrow amendment as required to fix the already identified
mobile defect. The reviewer subsequently cleared pre-code implementation with
these finite refinements: preserve frozen spec/layout/initial sibling object,
function and array identities using shallow copies; scope selection to one
visible sequence wrapper and retain two distinct present wrapper indices and
labels. Those zero-based indices are not PDB residue numbers. Retain the actual
history-count and finite-distance checks.

Passive requestfinished/requestfailed rows, stage starts, explicit page/context
retirement starts and final cleanup start will share the Node monotonic origin.
Keep at most128 terminal rows under the unchanged request/evidence budgets;
overflow fails admission. Do not await response.finished, refetch, waive failures
or infer cause from timing. The fresh check will require a canvas at least
200px wide/240px high and unobscured status/scope at initial open, in addition
to the unchanged11 images and desktop/mobile controls. Original consumed files
are unchanged. Product implementation and fresh harness receive separate
independent grading before any new actual browser decision.
