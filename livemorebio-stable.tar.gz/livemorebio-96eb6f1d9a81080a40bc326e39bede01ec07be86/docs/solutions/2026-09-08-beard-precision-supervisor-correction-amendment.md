# Beard precision v2 — supervisor and failure-evidence correction

Date: 2026-09-08. **Written amendment for pre-code review only.** Root requested
this bounded correction plan after independent review found two engineering
defects in the locked v2 candidate. No correction implementation, source
evaluation, compilation, initialization or native solve is authorized by this
document. All three on-disk execution/evaluation gates remain false.

## 1. Evidence preserved and scope boundary

The immutable numerical preregistration remains
`2026-09-08-beard-native-precision-v2-preregistration.md`, SHA-256
`68ff48a84ce6ca51828dbc2034322ada2c51ac4875b53a6fb8f1f6b4685ea758`.
Preserve the initial candidate hashes and independent findings in the
[implementation review](2026-09-08-beard-precision-v2-implementation-review.md).
Independent review ran195 tests with32 explicit opt-in skips; that was not a
native numerical result and did not clear the two defects below.

This correction may change only the precision execution module, its dedicated
tests and this correction/review evidence. A new `beard_precision_*` helper is
permitted only if needed for a single shared supervisor. Do not edit any frozen
v1 source, supervisor, wrapper, evaluator, parser, protocol or retained artifact;
do not import the moving Atlas process implementation as a runtime dependency.
The reviewed Atlas guard is a design precedent, not a substitute source pin.

No C-wrapper, equation, source constant, unit, observer, complete-grid rule,
candidate identity, tolerance, hmax, solver setting, matrix order, checkpoint,
conservation/positivity rule or scientific acceptance criterion changes. H3
remains the prespecified candidate. All six requested experimental programs
remain required; this worker correction is not a compound or human result.

## 2. Independently reproduced defects

1. `invoke_precision` immediately calls the old held-child ownership guard.
   Darwin can produce `WNOWAIT: not exited`, `getpgid: ESRCH`, then `WNOWAIT:
   not exited` during an exit transition. The current code classifies this
   transient state as cleanup failure and then reaps the leader without having
   established that its possible descendants stopped. The v2 compiler path
   also reaches this old guard through `native._invoke`.
2. Supervision errors are raised before `invoke_precision` returns. Consequently
   `_run_one` still has `invocation=None`; its failure receipt omits the partial
   output hash and observed exit code. Files remain on disk, but the receipt
   does not bind that retained evidence to the primary failure. Evidence-read
   failure must not replace the original cancellation/resource/identity error.

## 3. One v2-only compiler/native supervisor

Replace the two v2 call paths with one private precision-only supervision
primitive. Fixed compiler and native wrappers construct their exact command;
the shared primitive is not a public arbitrary-command, environment or solver
API. Both require the existing precision gate before files or processes.

- Compiler: construct the command from the already hash-verified runtime and
  fixed local `model.c`, `worker.c`, output name and reviewed linker flags. Keep
  the isolated `-I -B` Python launcher that sets private umask, disables core
  files, applies the64MiB file limit and execs the exact compiler. Do not invoke
  the frozen `native._invoke` from v2 afterward.
- Native: exact `[private_directory/precision-worker, approved_matrix_mode]`
  only; same process image/start-time/RSS identity checks as the locked v2
  candidate. No additional source call or solver probe.
- Common: private files, sanitized environment, exclusive `Popen` waiter,
  `start_new_session=True`, no `preexec_fn`, existing cancellation/signal handling,
  held waitable PID, group inspection, deadlines and failure receipts.
- Reuse only frozen low-level waitable-child, group enumeration, sampling,
  runtime inspection and linkage primitives whose hashes are already admitted.
  Implement the stabilization/cleanup sequence locally in the v2 layer.

Resource policy does not expand: native wall120s, native hard CPU60s and64MiB
file/stream limits,1GiB sampled-soft RSS threshold, requested10ms sampling;
compiler wall30s and64MiB file/core policy. Preserve the current compiler
supervisor's64KiB stdout/stderr retention/inspection cap as the stricter existing
bound. Compiler RSS and hard CPU protection are not claimed. Zero compiler RSS
samples explicitly mean not measured, not zero memory use. Both paths use one
additional bounded cleanup budget of3s; this is separate from their work deadline.

## 4. Ownership stabilization and cleanup sequence

Start one cleanup deadline before any ownership probe; do not reset it between
proof stabilization, group termination and final reap. Retain the `Popen` child
as the exclusive waitable ownership anchor. Do not call `poll`, `wait`, `waitpid`
or another reaping operation while deciding whether its group is ours.

1. Check that the child has not already been reaped by this supervisor. Observe
   only the exact child with `waitid(WNOWAIT)`.
2. An exited, still-waitable child proves its PID has not been reused. Otherwise
   require `getpgid(child.pid) == child.pid`. A different group is an ownership
   failure, not a reason to signal that new group.
3. On `ESRCH` while the same child remains recognized but not yet waitable-exited,
   repeat these observation-only checks every2ms until proof stabilizes or the
   original cleanup deadline expires. Do not signal, reap or start a background
   retry while the numeric identity is uncertain. Non-ESRCH errors and lost-child
   errors fail closed immediately. Record actual probe count and elapsed time.
4. Only after proof, enumerate the complete bounded owned group, excluding the
   non-running held zombie leader. If live members remain, send the existing
   SIGKILL to that proven group. Record whether the signal was sent. Treat a
   concurrent ESRCH from `killpg` as a transition requiring subsequent observed
   empty-group proof, not as success by itself.
5. While keeping the leader waitable, prove that the owned group has no live
   members and the leader exited. Use the same3s deadline. Only then perform the
   final reap with the remaining budget and record the observed exit code.
6. If ownership or empty-group proof cannot be established within the bound,
   do not reap merely to unblock cleanup, and do not signal an uncertain PID.
   Retain the `Popen` anchor in a bounded in-process unresolved-child slot so its
   destructor cannot silently become a second waiter. Fail the invocation and
   stop the matrix. Report unresolved ownership/cleanup explicitly. No detached
   cleanup task, further native branch or claim of successful cleanup follows.
   This is safe failure reporting, not a guarantee that an uninspectable process
   was stopped; the later one-off driver must surface that exceptional condition.

Signal handlers are restored in a nested `finally`; SIGINT/SIGTERM are ignored
only during this bounded owned cleanup. All stream handles are closed even when
proof, signaling, waiting or receipt capture fails. No fallback `child.kill()`
followed by unconditional reap is allowed to bypass the whole-group proof.

## 5. Hash-only evidence on every outcome

Collect a bounded stream receipt after the cleanup attempt and before returning
or raising the original outcome. This path must also handle pre-spawn failure,
partial file creation, identity/sampler failure, cancellation, output overflow,
nonzero exit, cleanup failure and ordinary success.

Each `stdout`/`stderr` receipt has fixed fields:

```text
read_state: complete | bounded_prefix | not_created | unsafe_file |
            changed_during_read | read_failed
observed_bytes: integer or null
hashed_bytes: integer
sha256: digest or null
hash_scope: entire_observed_file | bounded_prefix | none
read_code: fixed safe code or null
```

Only the exact private files created by this invocation may be read. Capture
their creation device/inode identity; on read require same identity, regular
file, expected owner, single link, no final symlink, and stable before/after
metadata. Read at most the stage's stream cap in bounded chunks. For an oversized
file retain a prefix hash explicitly labelled `bounded_prefix`, never a purported
whole-file hash. A missing, replaced, unsafe or unreadable stream records its
fixed read state; it must not silently become the empty-file digest. A legitimate
zero-byte stream is `complete` with the SHA-256 of zero bytes.

Supervision metadata always reports `exit_code` as the actually observed code or
null, plus `exit_status_state` (`observed_after_reap`, `not_started`, or
`unknown_unreaped`). Never infer an exit code from a signal merely attempted.
Retain stage, elapsed time, work-limit failure, sample count/peak/gap/overshoot,
process identity, ownership proof outcome, cleanup code and `child_reaped`.
Do not call `poll()` to manufacture final exit evidence after uncertain cleanup.

The first failure retains its original safe code and structured details. Add
supervision and stream receipts without overwriting source identity/time/unit or
native diagnostic context. Cleanup and stream-read/persistence errors are
separate secondary fields, not replacement primary errors. If no earlier failure
exists, an unsuccessful cleanup or unavailable required full stdout becomes the
primary failure. Raw bytes are retained privately but never embedded in JSON
failure metadata, console error text or public logs.

For success, the bytes passed to the parser must be the same verified full stdout
bytes used for its receipt hash. A hash-only success receipt cannot excuse a
partial parse. `_run_one` propagates this metadata even when the shared supervisor
raises before assigning `invocation`. Compiler failures receive the same receipt
semantics. Writing `failure.json` may report a separate persistence failure, but
cannot mask the original process/source error.

## 6. Required red-first tests before correction

Use only software fixtures and mocked processes at this stage. Any actual
technical child/descendant check needs separate root approval; neither compiler
nor Beard native execution is part of this correction's initial validation.

1. Parameterize both compiler and native paths over the Darwin
   false/ESRCH/false→exited transition. Before stabilization assert no signal,
   group inspection or reap; afterward require group inspection and descendant
   termination before reap.
2. Persistent uncertainty reaches the shared deadline with no signal/reap,
   records unresolved cleanup and blocks all later matrix branches. Wrong group,
   missing child, failed enumeration and incomplete termination fail closed.
3. Cancellation, deadline, RSS, image identity, output limit and nonzero exit
   each retain the primary outcome, observed exit status and partial stdout and
   stderr hashes for both stage policies where applicable.
4. File creation/read/stat/close failures, changed inode, symlink, hard link,
   oversize prefix and evidence-storage failure produce truthful fixed secondary
   states. No unsafe file contents, raw exceptions or inherited secrets appear.
5. A genuine empty file differs from missing/unreadable output. Full-success
   parser bytes/hash agree; partial output never enters numerical acceptance.
6. Locked/cancelled entrypoints spawn nothing. Exact compiler/native command
   constructors reject other modes/paths and neither v2 path uses the frozen old
   guard/invoker. Recheck every frozen v1 file hash and all three false gates.
7. Existing complete-grid/H3/repeat/checkpoint and seven-position fail-stop tests
   remain green without changing expected numerical values or tolerances.

## 7. Review and execution boundary

Root read all 202 original lines and the candidate analysis, execution and C
wrapper. Independent review cleared this pre-code scope with the following
mandatory bound: the unresolved-child retention slot has capacity **one**. Once
occupied, every later precision compiler/native/matrix entry rejects before any
file creation or process spawn. It never evicts its anchor or automatically
retries cleanup. Add a direct second-entry rejection test in addition to the
existing matrix fail-stop cases. The eventual once-only driver must explicitly
report `UNRESOLVED_CHILD` with a nonzero outcome; lifetime in the driver process
does not imply preservation after the driver exits. No successful cleanup may
be claimed for that state.

With this clarification, root authorizes the bounded red-first implementation
and mocked/static tests only. All evaluation/compilation/native gates remain
closed, and the changed supervisor requires independent implementation review.

After root reads and authorizes this amendment, write failing regressions, record
their red results, implement only the approved correction and rerun the static/
mocked packet. Freeze refreshed code/test hashes while retaining the original
candidate hashes and both review findings. Request independent source and
failure-path review again. Do not enable any gate on disk or introduce an
environment/CLI bypass. Actual compilation or physiological execution still
requires the separate reviewed runtime/once-only driver and explicit root
authorization. A successful worker correction is not a numerical convergence
result or evidence of human/compound effects.
