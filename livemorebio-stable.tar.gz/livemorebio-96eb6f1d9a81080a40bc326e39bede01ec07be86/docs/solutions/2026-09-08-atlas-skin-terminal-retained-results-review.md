# Single-skin diagnostic: independent retained-evidence review

2026-09-08 local date; actual receipt times are2026-09-09 UTC. Reviewer:
`source_research`. **The run remains FAILED, not accepted.** The three observation
stages completed, but the diagnostic retained `CLEANUP_UNCONFIRMED` and the
supervisor retained `BROWSER_CHECK_FAILED`. This review does not rewrite either
outcome or authorize another invocation.

The investigation skill's evidence-first workflow was applied. This was local
read-only artifact/source analysis: no browser, HTTP, listener/process query,
native worker, test, replay, package acquisition or operational-store access.
Credentials, private configuration and logs were not read. No runtime/test file
changed. Available-tool discovery exposed no usable gbrain/CE/sequential-thinking
tool; local prior plans and findings were used without claiming those invocations.

## Exact evidence and identity

Both files were read completely from
`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-atlas-presentation-zpg7lltg/`:

| Artifact | SHA256 |
| --- | --- |
| `skin-terminal-diagnostic.json` | `cf0ae732f0acd833cbae91c1858d0bf3c60c39d36673b7c9349089a5c51f9fb6` |
| `supervision.json` | `5e7e72104ff4c46d920fac2caf99127043ff9c24b2d79f11da07b35af875bc5e` |

The retained source is
`b1ff46168943d61cff3da6d5f411abb66f003e82b2c5271910cd945c3fde1f6c`.
The diagnostic and supervisor agree exactly on all three service source hashes,
process instances and start times, plus authored selected twin ID/version. This
was an observation-only software fixture, not a participant or a physiological
model. Root's once-only authorization is preserved in
[the checkpoint](2026-09-08-atlas-skin-once-only-checkpoint.md).

Current retained source bytes match the authorized diagnostic
`91cd052b2284d5e47c6196076b59750e29ff14d563109de7d2ec7b28ae39f7fa`,
supervisor `77982780e71188b633ade499e0f7d744e823a8f6a14a84de79ebad03e722ea76`
and unchanged reader
`7ad7c023571614635d196cc5b0638d195ae46b166ce4602be16eb87e4cf4b9bc`.
Recorded browser identity is Chrome153.0.8010.36 and Playwright/core1.58.2, with
the previously pinned runtime hashes and successful native visibility preflight.
This reviewer did not recompute a live package fingerprint or launch that browser.

## What the run establishes

- `source-preflight`, `single-skin-observation` and `final-fence` each retain PASS.
  `collection_pass` and `acceptance_pass` nevertheless remain false because the
  diagnostic's teardown was not confirmed. Do not turn three stage passes into
  an overall pass.
- There is one routed private document, one GET of each of the two unchanged
  modules, and exactly one skin GET. The response is200; content type and all
  source/process/digest/manifest header checks are true.
- The original load retains RESOLVED with exactly4,901,056 bytes, one factory,
  one fetch, no factory disposal and no internal concurrency. Its source-declared
  SHA256 is `e8a0c3f0897783fdb2c9bad9fe020c287ae8913a45f88bd7cd4ae47e8b628f0a`.
  The unchanged reader returns only after exact length and `crypto.subtle.digest`
  validation (`atlas_reference_requests.js:22–35`). This is source-bound evidence
  of a verified returned buffer; the buffer itself was not persisted or rehashed
  by this reviewer.
- Both Playwright and CDP retain FAILED/ERR_ABORTED. CDP additionally records
  `canceled:true`, null blocked/CORS reasons and unknown encoded-data-length.
  Their agreement does not convert the native terminal into FINISHED. Nor does
  CDP's canceled flag establish an AbortController or stream-cancel cause.
- The signal observer records initially-aborted=false, abort-observed=false and
  no abort timestamp through its final sample. This rules out an observed abort
  on that supplied signal during the measured load. It does not prove that no
  other browser or stream mechanism could produce the native terminal.
- Resource timing is AVAILABLE: encoded and decoded body size4,901,056,
  transfer size4,901,356 and duration986.1000000238419ms. Original-load duration
  is995.5ms; CDP request-to-terminal is987.2289999620989ms; PW callback interval
  is992.2144580000004ms. These are different documented clocks/boundaries, not
  interchangeable latency measures or a new performance gate.

The unchanged reader calls `reader.cancel()` in its finally block at line31,
including after its read loop observed `done`. That source fact leaves a possible
stream/browser terminal interaction worth distinguishing later, but there is no
counterfactual run or captured native stack proving it caused ERR_ABORTED. No
reader change, cancellation exemption or transport-cause claim follows here.
The harness's final owned teardown occurs after terminal observation and the final
identity fence; that later teardown is not an explanation for the already-recorded
terminal event in this control flow.

## Cleanup: confirmed outer containment, unresolved inner attribution

The full supervisor records all four direct children reaped with SETTLED cleanup,
12 recorded browser descendants and zero remaining, and
`NO_LISTENERS / owned_listeners_absent:true / query_cleanup:SETTLED`. Its before
and after inventories contain the same16 entries and are exactly equal in bytes,
SHA256 and mtime. These equalities were independently recomputed from the saved
JSON only. Root separately reported a later exact-PID and listener check; this
reviewer did not repeat it. Outer containment does **not** retroactively confirm
each earlier CDP/page/context/browser close Promise.

The diagnostic stores only the aggregate cleanup result. In
`check_atlas_request_diagnostic.cjs:103–120`, close rejection or a failing
before-cancel callback sets one sticky boolean; a five-second incomplete drain
also returns the same code. Resource identity, individual outcome, safe error
class and cleanup monotonic duration were not retained. The all-PASS stage ledger
and successfully populated freeze fields do not reveal which close failed.

Its recorded UTC span is16.448s and pre-cleanup elapsed is16.096062417s. With a
stable wall clock, their roughly0.352s difference favors a quickly rejected close
over exhaustion of the five-second cleanup allowance. This is only an inference:
no separately measured cleanup clock or per-resource rejection receipt exists.

### Pinned implementation supports a concurrency hypothesis, not a verdict

The cleanup helper initiates CDP, page, context and browser closes in reverse
allocation order but does **not await child closure before starting parent
closure**. The installed primary package has these concrete behaviors:

| Source under `playwright-core/lib/` | Relevant behavior |
| --- | --- |
| `client/cdpSession.js:44–45` | `detach()` forwards its channel Promise without a target-closed catch. |
| `server/dispatchers/cdpSessionDispatcher.js:36–38` | Dispatches native detach as a potentially scope-closing operation. |
| `server/chromium/crConnection.js:137–155,177–189` | Detach awaits protocol operations; an already-closed session or closure of outstanding callbacks can reject. |
| `client/browserContext.js:441–467` | Context close awaits request disposal/instrumentation and later channel close; it has no surrounding target-closed catch. |
| `client/page.js:505–518`; `client/browser.js:139–151` | These public closes specifically suppress `TargetClosedError` in their stated normal-close branches. |
| `client/connection.js:107–109,178–185` | A closed connection rejects later sends and outstanding callbacks. |

Thus parent shutdown can invalidate an unfinished child closure, and the helper
will retain a rejection even if all owned resources eventually disappear. This
is a source-supported hypothesis for the aggregate result, not evidence that the
specific failed operation was CDP detach, context close or a particular error.
Other close failures or a pending drain remain possible. Do not merely ignore
`TargetClosedError`, serialize teardown or relabel this attempt on that hypothesis.

Exact installed Apache-2.0 Playwright1.58.2 source identities inspected here:

| File under `playwright-core/` | SHA256 |
| --- | --- |
| `package.json` | `16a25dbd7368a87af8b58a45c6216b9cec5a91a72cf704533344701997ebde22` |
| `lib/client/cdpSession.js` | `b69012f85807ae8ad8a5363f82868f86b9d8a51ce35c9cf6c863e1badec0ba2c` |
| `lib/client/browserContext.js` | `6ea97975a148f6c5b8706d9525bf2a665494091558dc1497e96373c16537613b` |
| `lib/client/page.js` | `409b11561b319e8dfb4d1ec3f8b126fb32ab19e894fae529edbeae57c056ae84` |
| `lib/client/browser.js` | `f83e3a90c706cfae4b548311be902c2dbeb2f79cf561ea7f9b785057f7c57b7f` |
| `lib/client/connection.js` | `e063a23c7fb0ed81e7a09baa0844851c660b3cba1c39176963f17b10a1bf1526` |
| `lib/client/fetch.js` | `27690689a46bf22b838c39a6712ed2af1bfd3e6ac1956dbe7905bc8bb5d28fa6` |
| `lib/server/chromium/crConnection.js` | `0d41a058ad1f5c897329a9c821c52b952e0e709ab38c3e6e355224b167922f13` |
| `lib/server/dispatchers/cdpSessionDispatcher.js` | `a8e89e19d8a40e2f838f3e794d2d548488498491a85281c07b73f30a5630abd1` |

The inspected root is `/Users/emman/.agents/skills/gstack/node_modules/playwright-core/`.
These additional close-source hashes were captured now; the original run did not
individually attest every close file. They support analysis of the currently
installed pinned package, not a newly invented historical binary attestation.

## Smallest next discriminating proposal, not execution approval

First add **harness-only teardown attribution**, leaving the existing schedule,
timeouts, original reader and failure policy unchanged. Use four fixed resource
roles only (`cdp`, `page`, `context`, `browser`), one attempted close per owned
instance, monotonic start/settlement timestamps, and fixed outcomes
`NOT_STARTED / PENDING / FULFILLED / REJECTED`. Store only a reviewed closed error
classification (target-closed, other, unknown), never raw message/stack/protocol
IDs or credentials. Separately record aggregate drain deadline and the first
primary failure so teardown cannot erase earlier evidence. Missing attribution,
rejected closure or an incomplete drain still fail; no exception is waived.

Write and independently review offline authored cases before implementation:
all closes succeed; each of the four closes rejects; each remains pending;
child-rejection-after-parent-close; late allocation; freeze/observer failure;
and cleanup evidence-write failure. Prove no changed close ordering, no duplicate
close, bounded output, all other close attempts still occur, and the unchanged
five-second combined drain. Preserve the existing241 cases and old artifacts.

Only after separate source review and explicit root authority, the smallest
native discriminator would be **one fresh blank-page teardown-only probe** with
the same pinned Chrome/Playwright, one context/page/CDP session, no services,
asset/metadata GET, clinical fixture, geometry or model. Apply the unchanged
concurrent teardown once and retain the four role receipts plus the independent
owned-process cleanup outcome. Reuse the existing90-second setup/observation,
5-second combined cleanup,5-second evidence write and105-second outer ceiling;
do not borrow a new timeout or repeat if it does not reproduce. A separately
reviewed test-only owner must prove process ownership and cleanup without
starting the service stack; this proposal does not authorize a new launcher.
This can establish whether the teardown policy alone produces a closure race;
it cannot identify the historical zpg7lltg error without that missing receipt.
Any serialization experiment or further skin/transport counterfactual needs a
new specific plan and approval after this evidence is reviewed.

Status: retained-evidence review complete with unresolved cleanup/transport
causes. The old full Atlas matrix,33 presentation images, earlier failed runs,
six required scientific programs and all physical/participant qualification
requirements remain unchanged. The durable lesson is to distinguish outer process
containment from per-resource API settlement and preserve both levels of evidence.
