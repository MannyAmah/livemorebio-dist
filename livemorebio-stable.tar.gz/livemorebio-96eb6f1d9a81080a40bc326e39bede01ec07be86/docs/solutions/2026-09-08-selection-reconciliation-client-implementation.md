# Explicit selection recovery — client implementation and test evidence

Date: 2026-09-08. Maker source frozen for independent review. No browser
acceptance, clinical validation, or hardware result is asserted.

The full client/UI proposal and root reconciliation contract were read before
code. Root and independent review approved the shared selection-epoch and
timeout clarifications first. A later exact-HTTP-status refinement was written
and independently cleared before the shared transport changed.

## Implemented boundaries

- The persistent Twins authority card separates UNKNOWN/UNCONFIRMED/CONFIRMED
  selection from PENDING/ACKNOWLEDGED/ACK_UNCONFIRMED/REJECTED request outcome.
  It never presents a candidate or prior person as current during uncertainty.
- A deliberate recovery invokes exactly one fixed POST with `{}`. There is no
  automatic selection/reconciliation retry. It performs one bounded fresh page
  read after the request settles; identity is published from that accepted read,
  not from the acknowledgment. A lost acknowledgment stays separately visible.
- Existing activation and observation-only selection share the operation epoch,
  prior-GET fencing, once-only POST and fresh-read behavior. Repeated actions
  while pending cannot create another selection request.
- List requests are owned/abortable. Page disposal fences late callbacks and
  aborts reads; bfcache return starts unknown and reads only. No identity or
  receipt is persisted in browser storage.
- Current-selection controls, including an already open physical pairing form,
  are guarded while unconfirmed. The open form also checks selected ID, version
  and epoch before submission. Existing disabled eligibility and record-operation
  locks compose independently. Intake, paging, references and History remain.
- Stored ACTIVE row badges lose their current-selection styling during
  uncertainty. Existing active-card text is removed, not merely hidden beneath
  a new identity. Cleanup remains a separate inspection concern; recovery does
  not start, resume, stop or acknowledge any worker/session.
- The browser request uses the shared strict 2,000,000-byte parser, strict UTF-8,
  current canonical UUID, exact recovery response shape, coherent subject and
  availability, and exact HTTP200. Its absolute 60-second deadline includes body
  admission; the final monotonic check also covers synchronous parsing. The
  fresh listing has a separate 20-second bound.
- SDK `reconcile_twin_selection()` is attach-only and sends one empty POST with
  no read or retry. It validates the response and current canonical UUID. The
  existing urllib timeout remains a 60-second socket/call timeout, not a claimed
  hard wall-clock deadline.
- Attached `state()` uses the shared strict safe GET transport. Shell startup
  catches only typed SELECTION_COMMIT_UNCONFIRMED to allow explicit recovery;
  other operational errors still fail. `twin list` is null-aware and does not
  call uncertainty “No active twin.” The exact new command rejects all extra
  arguments and prints metadata only.
- Optional shared `expected_status=None` preserves existing success handling.
  Only exact int200/int201 opt-ins are accepted before attachment/auth/network.
  Mismatched successful status retains current UUID and unreadable code; safe
  non-success errors and response-close diagnostics are preserved. No metadata
  shape, parser limit, request limit or frozen-member route exception changed.

## Red evidence and fixture isolation lesson

The first client run was **29 failed / 3 passed**. The new UI module began with
**26 failed** missing-module probes. After correcting a test-only duplicate
variable declaration, three mounted `subjects.js` integration cases failed on
the missing controller/seam. Additional red cases exposed pending-list disposal,
stale pairing revision, old ACTIVE badge and overlapping-operation disabled-state
restoration. A Unicode boundary test caught JS UTF-16 length differing from the
producer's code-point count; the accepted labels now use the producer's limits.
The exact-status/final-deadline refinement began with **24 failed** tests.

The approved old-fixture migration check initially reported **21 failed / 125
passed**. Fifteen state cases still stubbed `_get`; six VM cases stripped the
new module import. Some old state fixtures consequently reached the configured
local Aegle GET instead of their authored result. The returned state was labeled
as QA data, but this was still an unintended live read and is **not offline test
evidence**. No POST, store mutation or native work was performed. A subsequent
configuration-only check resolves the default local attachment to
`http://127.0.0.1:8850`; the initial fixture requests did not retain their URL
metadata, so this is not invented per-request tracing. No returned payload is
repeated in this record.

The correction was not to change transport defaults: old fixtures now stub the
exact safe GET `/api/state` seam and reject legacy fallback, method/body changes
and extra calls. The UI fixtures mount the actual imported controller, keeping
their original exact revision, no-activation, one-refresh and cleanup assertions.
Later matrix runs install socket-connect and DNS tripwires before pytest starts.

One non-performance auth probe used a test-only 20ms deadline; cold Node Response
initialization consumed that interval and correctly produced deadline uncertainty.
That probe now uses 1s for auth/byte/format cases. Dedicated short stall and
monotonic deadline tests remain; product60s/20s limits were not changed.

Lesson: when moving a transport seam, change its test boundary before treating
an old stub as an isolation guarantee. Likewise, importing the real controller
must not be replaced with no-op bindings merely to keep a VM fixture green.

## Frozen verification

**564 passed in 20.07s**, with network/DNS tripwires, across the two new modules
(66 client and 45 UI cases), prior96 clinical SDK cases,98 frozen-member byte
cases, execution/control-revision clients and commands, clinical availability
UI, population guidance, REAL cohort member and compact Cendos tests.
Both changed JavaScript modules pass `node --check`; `git diff --check` is clean.

Runtime candidate SHA256 values:

| File | SHA256 |
| --- | --- |
| selection_reconciliation.js | 44ae70b474eeb9148b1434064f42341c8138a41b32b4a933feba57d1a3deae4e |
| subjects.js | 7ad996ac3e934b2d50fbb539f5d6aa1e68ae35d062ec218557c0f79f3dbdb4c8 |
| twins.html | 6afceafb6fcf9df10de6371b8e2b7f4f656cbc62b9dcd55bc6241cdb081af5f8 |
| subjects.css | 28496e98a47e48d5f4ce0a10b0e8ae59cc0498245b2e81d75ab1d580f96e7999 |
| sdk.py | 353c07d2c91cd620892db08d36985204e0e1befe2da1fba72f8b95053373e7f7 |
| shell.py | 4f10b51407fbeefaa631955ef1b64d8c7033a6e6a53b906abb831c19a01abdf1 |
| execution_client.py | 88da31ed4d542281b04cb33a074379703d836ea0cb9d29fc1d362688c6d71b78 |

New test SHA256 values: client
`46080052c54e446460400d97f4cdab3f6e25b65da72366b2300916cf30c7f03a`;
UI `e575ed0a2ef37730c8c3f24e2fea86a06bd85afca807631cfd65c862163ad1e1`.

Independent source review is requested. No services were started/restarted and
no browser or operational-store mutations were used by this implementation.
Real rendered, responsive, keyboard, lost-ACK and restored-state QA requires the
separately authorized private technical browser run after independent review.
Atlas rendering/performance failures and the larger biological scope remain open.
