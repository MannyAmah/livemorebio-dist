# Reference-cohort transactions must use shared registry authority

2026-09-08. **Proposal only; no implementation authorized by this document.**
Bounded dependency of the clinical/bootstrap and committed-source transition
plans. No source acquisition, test execution, operational database, native model
or browser was used to prepare this plan.

## Scope and existing mechanisms

Reuse `RegistryAudit.check_authority(connection, reservation=None) -> str | None`
and its trusted `RegistryBootstrap.assert_authority` hook. These already check
the loaded data key, exact registry identity and retained bootstrap proof inside
a writer transaction. Do not invent another key proof, lock, schema or access
reservation. The bootstrap malformed-graph preflight correction is root-owned
and must clear independent review before this integration can be accepted.

`ReferenceCohortService` already has private-path guards, encrypted cohort/member
records, a separate encrypted `public_reference_access` journal, exact preview
and idempotency identities, atomic member insertion, and safe service errors.
Keep those contracts. Its direct `_connection` calls bypass the new shared
registry authority check. A valid constructor or check outside the transaction
does not authorize a later direct read/write by an already-open object.

Prior art read: the descriptive-reference lifecycle amendment, its independent
core findings, registry-bootstrap proposal/implementation, and the supported-writer
section of `2026-09-08-committed-source-transition-plan.md`. Engineering-plan
review was used for scope, transaction mapping and failure/test coverage.
gbrain, sequential-thinking and context7 tools were not available in the active
tool inventory; no invocation or external source verification is claimed.

## Exact file and helper boundary

Primary change: `livemorebio/aegle/reference_cohorts.py` only. Keep public method
signatures and response schemas unchanged. Replace the existing internal
context manager, rather than leaving a second unchecked connection path:

```python
@contextmanager
def _connection(
    self, *, expected_authority: str | None = None,
) -> Iterator[tuple[sqlite3.Connection, str]]:
    ...
```

Every use becomes `with self._connection(...) as (con, authority):`.

1. Open with the existing guarded registry connection. Execute **BEGIN IMMEDIATE**.
2. Require the production registry's trusted `audit.authority_check` hook to be
   present; call `registry.audit.check_authority(con)` on this exact connection.
   A missing hook or a None/non-string token is unavailable, never standalone
   audit mode. When `expected_authority` is supplied, compare it to that token.
3. Once `self.store_id` has been initialized, verify the stored
   `public_reference_store_id` still equals this object's ID before using its
   cached HMAC/AAD namespace. Do not rewrite a mismatch. During initial setup
   this field is assigned only from the transaction's existing/inserted UUID.
4. Yield the same connection and checked token. Before successful commit, recheck
   shared authority against that token and the initialized public store identity.
   This is not an access receipt; the caller still inserts its existing journal
   event in the transaction.
5. Commit before returning any result. On an ordinary precommit error roll back;
   always close the owned connection. If commit/rollback/close cannot be confirmed,
   return the fixed storage-unavailable error, never a success or assertion of
   rollback. Do not mask an earlier error with raw cleanup diagnostics.

The helper owns the transaction; remove each caller's redundant BEGIN. In
initialization, replace `executescript` with the two unchanged individual CREATE
TABLE statements **after** the helper's authority check. `executescript` would
otherwise break the transaction with an implicit commit. Keep table definitions,
constraints, AAD, keys, ciphertext serialization and normal access events exact.

`expected_authority` is an internal, operation-local token, not a client field or
new durable identifier. A fresh operation on a previously opened good-key service
may authenticate a newly adopted proof. An operation that started under a legacy
token and crosses adoption during its unlocked work must fail instead of mixing
epochs. No permanent instance-wide lockout of a correct key is proposed.

## Complete transaction/request map

| Path / present seam | Required protected interval |
| --- | --- |
| `__init__`, currently DDL then BEGIN around line158 | Shared guarded constructor stays first. New checked writer transaction includes both public tables, insert-or-ignore/read of store UUID, UUID validation and commit. No public DDL or store-ID change before authority. |
| `preview`, currently implicit audit transaction around line257 | New short initial checked transaction obtains a token before `_selection`. Close it, load/normalize/select outside all DB locks, prepare response/token, then enter a final transaction with that token and insert the unchanged preview journal event. No response if either check or audit fails. |
| `create` first idempotency phase, around line315 | Validate draft/token syntax first without source I/O. Checked writer transaction captures token and calls `_existing`; its encrypted cohort read and `create_replay` event stay inside this connection. An existing match returns only after commit, before expiry or source availability checks. |
| `create` new-request final phase, around line336 | After unlocked source selection/hash comparison and in-memory preparation, enter with the first-phase token. Recheck idempotency; insert cohort, every member and the original `committed` journal event atomically. No insert, member decrypt or audit under a changed authority. |
| `get_summary`, around line348 | Checked writer transaction precedes `_record`/`registry._open`; unchanged summary journal event commits before return. |
| `page_members`, around line370 | Same connection protects `_record`, cursor/manifest checks, member SELECTs, `_member`/`_unseal` and page journal. Preserve limit1–50, order, cursor format and completeness errors. |
| `get_member`, around line393 | Same connection protects matching cohort/member reads, decrypt/integrity and member journal. No source reload. |
| Existing `/api/cohorts` and detail projection | First shared registry page/get already uses `_audited`; preserve it. Each new public summary then uses `project_cohort_summary_for_api -> service().get_summary` above. No partial list response when a projection fails. Historical non-public projections remain unchanged. |

```text
preview:  checked TX(token) -> unlocked source selection -> checked TX(same token + public audit) -> response
create:   checked TX(token + existing?)
            existing -> replay audit + commit -> frozen response, source not needed
            absent   -> unlocked source selection/preparation
                     -> checked TX(same token + existing? + cohort/members/audit) -> response
read:     checked TX -> authenticated cohort/member -> existing public journal -> commit -> response
failure:  no success payload; fixed unavailable/conflict; no automatic retry or deletion
```

Keep a short version of this transaction/source-I/O diagram next to the helper
and two-phase create method. No computation/source package reads may occur while
its writer connection is open. In-memory canonicalization/encryption remains
bounded by existing cohort/member limits; it is not an external lookup.

## Failure and compatibility rules

- Authority/key/proof/store mismatch is operational failure:
  `REFERENCE_STORAGE_UNAVAILABLE`, HTTP503 through `_safe_operation`/existing
  reference API adapter. No label, measurement, key, token, path or exception text.
  It is not missing biology, an empty cohort or new eligibility failure.
- Preserve the distinct `public_reference_access` operation/result payloads and
  commit-before-return rule. Do not manufacture shared clinical BEGIN/RESULT
  events, consume their reservations or call `SubjectRegistry._audited` as a
  substitute for the existing public journal. Shared authority checks append
  neither journal. Existing shared constructor initialization remains separate.
- Failure after one member insertion must leave zero new cohort/member/create
  journal rows. A committed transaction whose acknowledgment is lost may already
  exist: return unavailable with no rollback assertion; a later explicit exact-key
  retry authenticates current authority and recovers the frozen record with one
  replay event, without source reloading or duplicate members. No new receipt
  table or automatic replay is proposed.
- Wrong-key reopen of an already authenticated store must not append either
  journal or change cohort/member bytes. A never-authenticated legacy first-key
  attempt remains governed by bootstrap's retained independent attempt audit;
  this integration does not promise to erase that permitted evidence.
- Authority cannot change through cooperating SQLite writers while one writer
  transaction is held. This does not fence pre-barrier old software, arbitrary
  SQL, same-user key theft or in-place poisoned-store recovery. Those existing
  unsupported recovery limits remain.

**Adjacent root-owned error adapter:** existing `server.list_cohorts/get_cohort`
catch only SubjectRegistryError/ReferenceCohortError. A bootstrap/audit failure in
their *first shared registry read*, before the public projection wrapper, can
escape as a generic500. Add a final narrow operational-storage exception adapter
there (bootstrap/audit/SQLite/cryptography storage errors, fixed503/no-store) while
preserving existing typed404/409/422 handling. Never catch BaseException or emit
partial cohort lists. This seam needs root ownership and tests; no server edit is
authorized by this proposal itself.

## Red-first test packet

New dedicated `livemorebio/tests/test_reference_cohort_authority.py`, reusing only
authored `test_reference_cohort_lifecycle` population tables and private registry
fixtures. No downloaded population records, network, models, devices or services.
Use explicit URI/opener and numerical-constructor tripwires. Existing lifecycle,
API, public-source and bootstrap suites remain unchanged.

1. **Every phase ordering:** spy on the exact connection and its SQL trace;
   require BEGIN IMMEDIATE then real shared check before each DDL, store-ID
   statement, `_record`, `_open`, `_unseal`, `_audit` and insertion. Include
   initializer and both new preview phases. An unrelated guarded connection is
   not sufficient. Missing production hook/None token must reject.
2. **Wrong-key/current store:** actual wrong-key service constructor on a marked
   technical store fails with no changed records, members or journal bytes.
   Reopen correctly still works. Test a cached object's failed actual authority
   validation, not merely a monkeypatched `ReferenceCohortError` return.
3. **All already-open operations:** corrupt a retained proof/binding or store
   identity in authored storage after service creation; preview/create/replay/
   summary/page/detail each fail before protected access/audit/mutation. Include
   stale `public_reference_store_id`, orphan graph and duplicate-singleton cases
   supplied by the independently corrected bootstrap layer.
4. **Actual adoption between phases:** establish a valid old audited fixture,
   begin preview/create under its legacy token, pause its unlocked `_selection`,
   and use a second supported registry to perform explicit good-key adoption.
   Final phase rejects before new cohort/public journal writes. A fresh explicit
   operation may use the new proof. No silent re-preview or token refresh.
5. **Source work outside locks:** during `_load_population` let a second
   connection obtain BEGIN IMMEDIATE and roll back. Cover preview and new create;
   expired/already committed replay must not load source. No sleeps as race proof;
   use barriers/events with bounded joins.
6. **Write race:** two connections, same-key create, both outside source phase;
   one committed cohort/member set, second authenticates and returns replay. Each
   actual read/write uses its own checked writer connection. No duplicate event
   substitute for the two distinct operations.
7. **DDL/member/audit failures:** injected failure after first public DDL, first
   member, and public audit insertion before commit preserves all previous bytes
   and rolls back that operation's new rows. Inherited shared bootstrap effects
   are recorded separately; do not call them rolled back with later public DDL.
8. **Lost commit acknowledgment:** actual private SQLite commit followed by an
   injected error returns no data/success. Reopen and exact-key retry recovers the
   same complete frozen cohort after expiry/source absence; no duplicate members,
   one new replay event, original `committed` audit retained. Confirmed rollback
   remains distinguishable from possible commit in the test's retained evidence.
9. **Read/preview commit or close failure:** no prepared public data escapes;
   fixed safe503, no invented successful access or raw diagnostics. Test rollback
   and close failure without overwriting the primary failure.
10. **Journal preservation:** unchanged schema/operation fields/AAD, private
    modes, source/member fingerprints, preview/cursor/idempotency tokens and old
    ciphertext. No shared clinical access event added by these direct phases.
11. **HTTP adapters [integration]:** actual ASGI routes with private fixtures;
    auth before service access, authority failure503/no-store/no private sentinel,
    including legacy list/get first-read failure and late public projection
    failure. No partial lists. No live socket or browser required for this delta.

The failures in1–4 are new required RED coverage of the bypass; existing tests
already cover basic atomic insertion/audit rollback, idempotency and frozen-member
integrity but do not prove authority ordering. Maker must retain exact red/green
commands/counts and final code hashes, then request independent review.

## Performance, ownership and non-goals

Authority evaluation is bounded by the shared bootstrap limits and adds checks
per writer transaction. Preview adds one short transaction; create retains two.
Do not cache authority across transactions to reduce queries. Keep the existing
5-second SQLite busy timeout; tests must show contention becomes safe unavailable,
not an unbounded retry. Existing list projection can perform one service/read per
public summary; no batching redesign or latency claim in this small correction.

Primary maker lane: reference_cohorts.py and dedicated authority tests. Root owns
the two legacy server error adapters and their focused tests. Shared registry/
bootstrap files remain frozen except root's separately reviewed graph fix.
Sequential implementation, no parallelization opportunity inside the transaction
helper/callers; root's route adapter can be prepared independently after signatures
are agreed. Do not start until root and a separate reviewer approve this proposal.

**NOT in scope:** population selection/normalization, new eligibility or clinical
bindings, record/schema/key migration, public journal redesign/retention quotas,
active-source transitions, physical-v3 admission, source downloads, UI changes,
production recovery, full product acceptance or science execution. No TODO is
silently removed; existing full-scope and transition plans retain those programs.

Plan result: scope retained; one transaction-coverage defect plus the adjacent
typed-error gap mapped to11 red-test groups; source-I/O lock interval addressed.
No independent plan approval, implementation or passing-test claim yet.

Lesson: a service that shares an encrypted database also shares its authority
boundary, even when it correctly keeps a separate domain access journal. Checking
one constructor or guarding only the visibly mutating method misses preview,
idempotent replay, initialization and reads that write audit evidence.

## Root review and exact adjacent error adapter

Root read all229 proposal lines and the complete existing service, reference API
and legacy list/detail paths. The same-connection authority checks, operation-local
token, source I/O outside transactions and unchanged separate journal are approved
in principle. Independent plan review remains required before implementation.

Root's server lane is limited to:

- Replace the known `_subject_registry()` unavailable-key `RuntimeError` with
  a private typed `_RegistryKeyUnavailable(RuntimeError)` using the same fixed
  message; do not change
  key creation, accepted keys, cached objects or any exception's private detail.
- In legacy cohort list/detail, catch `RegistryBootstrapError`,
  `RegistryAuditError`, `_RegistryKeyUnavailable`, `sqlite3.Error`, `InvalidTag` and `OSError` after the
  existing typed domain handlers. Return fixed `REFERENCE_STORAGE_UNAVAILABLE`
  503 with `Cache-Control: no-store` using the existing reference failure adapter.
  Unexpected programming exceptions are not silently converted into empty lists.
- Preserve exact typed404/409/422 response codes, adding no-store to these private
  failures as already used by successful cohort reads. No query/version/request
  schema or response identity change. Do not return a partially projected list.
- New isolated ASGI tests cover both initial shared-registry failure and late
  public projection failure, unavailable key, authentication before storage,
  no private sentinels, and preserved typed404/409/422. Trap numerical constructors
  and all peer transports; do not run startup or use an operational registry.

This adapter does not implement general storage recovery or change model/source
admission. The independently cleared Cendos packet remains preserved; any touched
server hash must be re-recorded and its tests rerun with this delta.

Independent pre-code review caught that the initially proposed bootstrap error
inherits ValueError and would change older consumers' payload-error classification.
The private RuntimeError subclass above preserves the original catch hierarchy;
test its type explicitly and retain observation selection's preflight storage
branch. Root accepts this correction before runtime edits. No other global
storage-error taxonomy or handler rewrite is included.
