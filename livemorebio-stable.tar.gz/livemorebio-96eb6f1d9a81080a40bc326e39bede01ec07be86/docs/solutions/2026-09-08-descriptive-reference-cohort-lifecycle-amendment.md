# Descriptive reference-cohort lifecycle: route and storage amendment

2026-09-08. **Pre-code amendment for independent review.** Parent:
[source-linked healthy and context cohorts](2026-09-08-source-linked-healthy-and-context-cohorts-plan.md).
The source/core already passed independent review; this lifecycle has not been
implemented. The nine-parameter internal-reference bundle is not activated.
Executable individualized contexts remain required open work under R05/R19 and
the relevant insulin/botanical program requirements.

## 1. Record identity and source isolation

Add the storage/result class `PUBLIC_REFERENCE` only through the new lifecycle.
Do not extend the existing `create_twin`/legacy `create_cohort` allowlist to accept
it. A public reference member is a source-linked research record, not an enrolled
person or a generated physiological model.

Use **`LIVEMORE_POPULATION_SOURCE_DIR`** as the single explicit server/CLI source
cache override. Default resolution is `registry.REG_DIR / "population-sources"`.
The review launcher must override it to `<private-review-root>/population-sources`
and validate it as a private directory; never inherit the installed/production
cache. Installation and status share this resolver. No caller can supply a path,
URL, source digest, parser options, participant rows or linkage IDs through HTTP.
Only the already reviewed exact source ID/manifest is supported.

Raw source files stay in that owner-private statistical-source cache. Selected
normalized member snapshots go into the existing AES-GCM subject registry, not a
new plaintext dataset file. No public record enters `subject_identifiers`,
`physical_device_bindings`, active-twin state, LIFE telemetry, clinical observation
normalization, or `AdmittedHuman` construction.

The registry receives one stable opaque `public_reference_store_id` UUID in
`registry_state` during additive initialization. It is metadata, not a person
identifier. Fingerprint, preview-signature and idempotency keys are separately
domain-separated HMAC derivations from the registry key and this store identity.
Keys are never returned. A copied database with its key preserves identity;
another initialized store cannot accept its preview tokens, even if an operator
erroneously reuses the same encryption key. Existing registry records are unchanged.

## 2. Exact routes

Every new route requires operator authentication, returns `Cache-Control:
no-store` including authorization/error responses, and uses strict duplicate-key,
nonfinite, nesting and byte-limited JSON parsing. Preview/create bodies are capped
at 16 KiB. Errors are named and PHI-safe. No request body, query text, participant
value, source fingerprint, credential or cache path is logged.

| Method/path | Contract |
| --- | --- |
| `GET /api/population-sources` | Metadata-only reviewed source/definition list and cache state. Never downloads, normalizes a pool, creates cohort/member records, or opens a remote service. |
| `POST /api/population-sources/{source_id}/install` | Exact body `{accepted_use:"statistical_research"}`; deliberately installs the fixed manifest into the resolved private cache. Source acquisition runs off the event loop, uses existing source lock/staging, and returns the sanitized verified/busy/error state. It never enrolls anyone. |
| `POST /api/reference-cohorts/preview` | Validates the complete draft below, reads a verified source package, normalizes with this registry's fingerprint key, selects whole joint records, and returns aggregate preview plus a signed token. No cohort/member/idempotency record or active biological state changes. Initial registry schema/store-UUID setup and metadata-only access audit are permitted setup effects. |
| `POST /api/reference-cohorts` | Exact body `{draft,preview_token}` and required `Idempotency-Key` header. Verifies the token/draft/store, recomputes source selection when this is a new request, checks hashes, then atomically freezes one cohort and its member snapshots. Returns 201 for first creation, 200 with `idempotent_replay:true` for an already committed matching request. |
| Existing `GET /api/cohorts` | New summaries join the same stable created-at/opaque-ID pagination and local encrypted-label search. Existing record payloads are unchanged; new summaries contain no embedded member array. |
| Existing `GET /api/cohorts/{cohort_id}` | For a new public-reference cohort, returns its frozen summary/source definition, construction hash and member-list link. Old cohorts retain their current response. |
| `GET /api/reference-cohorts/{cohort_id}/members` | New-class cohorts only. `limit` 1–50, default10; opaque signed cursor. Returns exact frozen member snapshots plus pagination. No source download or recomputation is needed. |
| `GET /api/reference-cohorts/{cohort_id}/members/{member_id}` | Retrieves one matching encrypted frozen member. A member ID from another cohort/store is rejected. No activation or biological execution. |

The draft has exactly these fields, all required:

```json
{
  "name": "Public reference research cohort",
  "indication": "unspecified",
  "source_id": "nhanes-2021-2023-joint-public-v1",
  "definition_id": "nhanes-2021-2023-screened-normal-glycemia-prescription-free-adults-v1",
  "size": 20,
  "seed": 71,
  "require_nonpregnant": false,
  "accepted_use": "statistical_research"
}
```

`name`/`indication` are strings trimmed to 1–100 characters; indication is a
research label, never a diagnosis or a template selector. `size` is a strict
integer 1–1,000 and cannot exceed actual eligibility; `seed` is a strict integer
0–2^31−1; pregnancy restriction is a strict boolean. Unknown fields, non-string
labels, duplicate keys, booleans as numbers and fractional numbers fail. No
replacement sampling or limit-based truncation is permitted. The broader measured
adult definition is selectable without being labeled type 2 or healthy.

## 3. Preview/create coherence and idempotency

Preview returns definition/source/normalization version, source manifest digest,
definition digest, construction digest, selected size, eligible/excluded counts,
nonexclusive exclusion counts, source selection bias, bounded selected-group
measurement/age ranges and reported-sex counts. It does not return raw source IDs,
HMAC secrets or participant rows. It explicitly says `executable:false`,
`model_binding:null`, `clinical_admission:false`, and `physical_device_association:false`.

Selected-group numeric/sex summaries are suppressed for sizes below five with
`summary_suppressed:true`; selection/eligibility counts and source criteria remain
visible. Larger-group summaries are still authenticated reference data, not
claimed deidentified merely because they are aggregates. Public screenshots/demo
evidence show source/count/criteria/availability panels only, not selected
measurement ranges or member records. Detailed member inspection remains local
and authenticated, and is tested without publishing participant contents.

The opaque HMAC-signed preview token contains version, store identity, canonical
draft digest, source manifest digest, definition digest, normalization version,
construction digest and a 15-minute expiry. Token verification is constant-time;
decoded fields are bounded and checked against the exact schema. It is not a
scientific validation signature. The construction digest already binds actual
normalized member values, not only participant fingerprints.

`normalization_version` is not the raw source hash: it names the reviewed rule
release and a digest of the loaded transport/normalizer implementation identities,
plus pandas version and its XPORT reader implementation identity. Capture code
identity when the normalization implementation loads; do not claim a subsequently
edited source file describes already loaded functions. Persist that identity in
the preview and cohort. An unavailable or unrecognized decoder identity blocks
new normalization instead of substituting another parser. Historical committed
members remain readable without rerunning that decoder.

For creation, validate the token MAC/schema/store and draft match first. Canonical
creation-request hashing includes the normalized draft plus source, definition,
normalization and construction identities; token expiry and token serialization
are excluded so re-previewing an unchanged selection does not change identity.
The required idempotency header is 1–128 ASCII letters/digits/`._:-`; UI/SDK use a
random opaque key retained through uncertain responses. Store only a namespaced
HMAC of that header, not user-provided header text.

If a committed record with this key and request hash exists, return its frozen
summary **before** requiring current source availability or unexpired preview.
The MAC and store/draft identity must still be valid. Reuse of the key for another
canonical request is 409 `IDEMPOTENCY_CONFLICT`, never a second cohort.

For a new request, require the unexpired preview, reread verified source bytes,
recompute selection and compare every preview-bound identity. A changed source,
definition, normalization version, selected member value or pregnancy/draft field
requires a new preview; return 409 `REFERENCE_PREVIEW_CHANGED`. No payload-supplied
member data or client-computed digest can replace the server result.

After computation, `BEGIN IMMEDIATE` checks idempotency again and inserts the
cohort summary plus all member rows in one transaction. Concurrent same-key
requests converge on one committed cohort. A failure after any member insert
rolls the entire creation back. A different idempotency key deliberately creates
a separate named frozen cohort; repeated source fingerprints identify overlapping
reference records, not additional independent people.

## 4. Additive encrypted storage

Reuse the existing `records` table with `record_type='COHORT'` and
`source_class='PUBLIC_REFERENCE'`; it has no source-class SQL constraint. Use a new
encrypted summary schema `livemore.public-reference-cohort.v1` with:

- Opaque `cohort_id`, name, indication, source class, `generation_method` equal to
  `joint_public_records_without_replacement`, `lifecycle:FROZEN`, version1 and
  software creation/update times (never specimen collection times).
- Source/definition/normalization/construction identities, immutable draft, counts,
  selected-group summary and selection bias. `members_materialized:true`, size,
  `members_included:false`, member-list URI; no embedded public member array.
- `executable:false`, `model_binding:null`, `qualification_state:NOT_QUALIFIED`,
  `clinical_admission:false`, `physical_device_association:false`.

Add `public_reference_members` containing `cohort_id`, opaque `member_id`, ordinal,
nonce and ciphertext; unique `(cohort_id,member_id)` and `(cohort_id,ordinal)`, FK to
the cohort. Use AES-GCM with a dedicated AAD domain including store, cohort and
member identities. Payload contains the exact normalized member, member digest,
source/definition/construction digests and immutable ordinal. No labels, numbers,
raw linkage values or source fingerprints enter plaintext columns.

The encrypted cohort record additionally retains an ordered integrity manifest
of member IDs, ordinals, normalized-member digests and reference fingerprints.
This internal manifest is omitted from list/summary API projections. Member reads
verify against its expected entry, not merely against a digest supplied inside
the same member payload. The construction identity binds the full ordered set.

Before opening the registry for a new public-reference operation, validate its
parent directory is owner-owned mode0700, and existing DB/WAL/SHM files are
owner-owned regular mode0600 files, not symlinks or hardlinks. Create only absent
paths with explicit private modes and exclusive/no-follow file creation; unsafe
existing paths fail without chmod, replacement or repair. Recheck companion files
after SQLite opens/initializes WAL and before data access. Private parent ownership
is part of the assumption against path substitution; same-user privileged
filesystem tampering is not claimed to be prevented. Do not rely on the inherited
registry's after-open chmod. Guarded new-service initialization precedes calling
the existing registry constructor. Legacy records retain their bytes and APIs.

Add an encrypted `public_reference_access` append-only-by-API audit table with
opaque event ID, creation time, nonce and ciphertext. Metadata payload contains
operation, resource kind/opaque ID, result status, source/construction identity
where relevant, and `actor:authenticated_local_operator` (the current shared
operator auth cannot attribute distinct humans). Never include body/query text,
labels, member fingerprints/values, token or cache paths. A dedicated AAD domain
binds event/store identity. There are no update/delete audit routes; this is local
tamper-evident payload storage, not a regulatory-grade audit service claim.

Preview, summary/member reads and idempotent replay must durably append the
metadata event before returning reference data; audit failure returns503 without
data. Read events mean `prepared_for_return`, not proof a human viewed them.
Creation writes its `committed` audit event in the same transaction as cohort and
members, so audit failure rolls everything back. If the response is lost after
commit, a valid idempotent retry returns the existing cohort and appends a replay
event; it does not pretend the original transaction failed. Auth rejection occurs
before data access; unavailable audit/storage returns no reference data. Source
status is nonsensitive catalog metadata; installation retains its source receipt.
Legacy list/get routes must use the new summary projection/audit hook for new-class
records while leaving legacy payloads unchanged. Tests inject audit failure before
commit/return and verify both rollback and postcommit response-loss semantics.

There is no update/delete/materialize-as-real-person operation in this amendment.
The server recomputes the stored member digest on read, verifies its linkage and
construction metadata, and fails closed on corrupted/mismatched payloads.

Member cursor v1 binds store, cohort, construction digest, requested limit and
last ordinal with domain-separated HMAC. It contains no clinical values or search
text. Pages follow immutable ordinal ordering; tampered, cross-cohort, cross-store
or wrong-limit cursors return 422 `INVALID_REFERENCE_MEMBER_PAGE`. `total` is the
frozen size; missing rows/count mismatch are storage errors, not shorter success.

## 5. Admission gates and backward compatibility

The new class and schema cannot reach `SubjectRegistry.admitted_human`,
`build_twin`, activation, virtual/physical Patch binding, synthetic member
generation, or clinical observation normalization. Explicit guards reject those
attempts with `REFERENCE_MODEL_BINDING_REQUIRED` or `REFERENCE_NOT_A_REAL_PERSON`
before constructing an engine or changing state. No default physiology is filled.

At both Aegle protocol admission and the direct Cendos protocol function guard,
public-reference or explicitly unbound cohorts fail before `_profile`, PK,
target-factor lookup, integrator calls or run persistence. API response is 422
`REFERENCE_MODEL_BINDING_REQUIRED` with supported next step: inspect source facts
or define/qualify a model-specific binding. This is not overridden by an arbitrary
stratum, indication, changed `source_class`, or `executable:true` flag. Checks
recognize the schema/generation method and missing binding as well as class.

Existing legacy reference cohorts and their frozen reruns remain unchanged:
absence of a new field is not retroactively treated as a new unbound record.
Nonhuman lobeline/GEM assay protocols keep their existing separate contracts.
No new method converts public members into legacy cohort dictionaries.

## 6. Capability/UI/terminal wiring

Extend `/api/population-capabilities` additively with
`descriptive_reference_cohorts` containing the two exact definitions, source state,
generation availability, `executable:false` and the missing-binding explanation.
Preserve legacy strata and templates. Existing `healthy_reference_cohort.available`
remains false for executable healthy-cohort support, with copy directing users to
the new screened descriptive source workflow and clarifying it is not disease-free.

On `/cohorts`, add a clear public-data preparation mode alongside existing source
modes: explicit source-use acceptance, definition/size/seed, Preview, then Create.
Any draft edit invalidates Preview/Create. Keep action locking and stable
idempotency keys across retries. New cards open paginated frozen-member inspection
and source/measurement provenance. They show execution unavailable and do not
offer activation/device buttons or link an unsupported member to an unrelated
active Biology view. Cendos retains these cohort selections as visibly unsupported
instead of silently changing to a legacy T2D cohort. No graphics/kinetics invented.

Add SDK methods and matching shell/CLI actions for source status/install,
reference preview/create and member page/get. They call the same authenticated API;
no duplicate local random generation. Source-install use acceptance is explicit.
CLI errors retain the server codes and report model-binding absence accurately.
First implementation may use narrowly separated population command handling to
avoid altering the legacy `cohort <n>` behavior.

## 7. Red-first acceptance and ownership

Tests must fail before implementation for: source cache isolation/no auto-network;
strict draft/token parsing; changed/expired/cross-store preview; same-key
concurrent atomic create and mismatched-key conflict; replay after cache removal;
rollback on partial member insert; no plaintext member values; unchanged active
twin/legacy records; cursor tampering/page completeness; corrupted member digest;
and every execution/device/real-person admission bypass above. Source SHA and
measurement units/missingness remain exact through preview→create→read/restart.

API tests cover 401/no-store, source install use acceptance, bounded input, PHI-safe
errors, source-unavailable/busy, named gate codes, and no run records on rejection.
They also cover unsafe existing directory/DB/WAL/SHM mode, symlink and hardlink
rejection without repair, audit failure before data return, per-member integrity
manifest mismatch, and small-preview summary suppression.
UI/SDK/CLI parity tests use authored technical fixtures. A real isolated browser
walkthrough may use an explicitly installed public source after the checkpoint;
screenshots show source/aggregate data only, not raw public participant rows or IDs.
An actual selected-member view can be technically tested without publishing it.

Independent pre-code review of digest
`c0f523a0606accddda579ff0efe89ba191b359fa708faeeabb709f72f3a84dcd`
cleared the refined storage/audit/identity contract. Root approved the contract,
environment name and ownership. Implementation is authorized; completed code
still requires independent review and actual isolated browser verification.

Ownership after independent review: UI/source agent owns new
`reference_cohorts.py`, `reference_cohort_api.py`, source normalization version,
focused registry extensions, cohort UI and dedicated tests; root coordinates
`server.py` router/capability/protocol gates, launcher environment, and SDK/CLI
shared surfaces as needed. No maker grades its own completed packet.

## Independent core review — 2026-09-08

The source reviewer independently read the lifecycle, loaded normalization
identity, shared admission guard and API projection, and reproduced two defects
using authored technical records in private stores, never public participant rows:

- An actual returned frozen member initially lacked a durable top-level class and
  schema marker. Changing only its `executable` flag could bypass the direct
  admission guard. The corrected member contract carries both markers, verifies
  its flags on read, and rejects raw/wrapped members and members nested inside a
  legacy-looking cohort without changing the behavior of actual legacy records.
- Changing the plaintext idempotency request index could return an old cohort for
  a different draft. The encrypted cohort now binds its complete request digest
  and namespaced idempotency fingerprint. Reads recompute those bindings and
  compare both indexes before returning either replay or conflict. The internal
  fields are excluded from public summaries.

The reviewer reread both corrections and independently ran lifecycle, identity,
source normalization, joint-record and API tests: **109 passed in 3.22 seconds**,
with one existing Starlette deprecation warning. This clears those two findings
in the reviewed core. It does not certify pending legacy-route wiring, browser
interaction, multi-tenant privacy, clinical admission, or physiological binding.

Compounded lesson: encryption of payloads is insufficient when mutable indexes
choose their identity or replay semantics. Bind request identity inside the
authenticated payload, and preserve the descriptive evidence class at every
returned envelope level rather than relying on one editable boolean.

Follow-up independent review covered typed handling of malformed optional schema
and draft fields, plus loaded `read_sas` entrypoint/default identity, normalization
function defaults and ordered table rules. These now reject changed runtime
semantics rather than silently assigning the old transform identity. A fresh
lifecycle/identity/API run passed **55 tests in 1.14 seconds**, with the same
existing warning. No new actionable core blocker was identified. Source data,
kinetic binding and browser acceptance retain their separate gates.
