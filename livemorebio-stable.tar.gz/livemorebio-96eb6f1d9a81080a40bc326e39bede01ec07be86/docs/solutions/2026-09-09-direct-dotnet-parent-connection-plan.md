# Direct .NET parent connection, finite implementation

2026-09-09. Maker plan before code. Continues the independently cleared direct
worker checkpoint and Emmanuel's completion instruction. Native activation and
execution remain a separate root decision after independent source/test review.

## Scope challenge and decision

Implement the missing fixed parent in `tools/osp_dotnet_worker.py`. No service,
new dependency, container, old-lane retry or arbitrary XML/argv interface. Reuse
unchanged reviewed primitives from `osp_semantic_supervisor.py`: strict JSON and
file utilities where their bounds fit, `BoundedStream`, `Samples`, `Owned`,
`process_sample`, `waitable_exit`, `group_members`, `_limits_child`, `vmmap_paths`.
Do not call its R-specific `_execute`, callback, startup classifier or image gate.
Hash the old helper and pure modules before import. Their sources stay untouched.

The frozen worker source is `70011d37...`, native API source `23b17fe7...`, compiled
worker `8a217d42...`. Exact current full pins and independent review are in
`2026-09-09-direct-dotnet-worker-plan.md` and the E09gsz correction inventory.
Read AGENTS, biological model-change contract, complete parent plan/receipts and
actual implementation. No equation, source oracle, tolerance, unit or model gate
changes are required. gbrain/Context7/CE/sequential-thinking are unavailable; no
claims those tools ran. Engineering-plan skill applied in spawned mode, without
setup, telemetry, browser or unrelated configuration changes.

Minimum source boundary: one parent module, two dedicated Python test files,
an additive preparation/runtime manifest artifact, this plan/receipt. Only if the
wire tests establish a concrete need, a minimal worker/its fake-test change.
Existing C# activation stays false until root reviews the complete connection.

## Architecture and fixed flow

```text
fixed package + expected manifest hash + exact once authorization
  -> full source/runtime/system identity verification, no unresolved child
  -> fresh Sxx scratch/ and parent evidence/ under one accounted case
  -> direct runtime/dotnet worker/Livemore.OspWorker.dll (no shell)
  -> exact configuration over nonblocking stdin
  -> PRE_XML(seq1) -> owned vmmap + stable managed inventories -> ACK1
  -> OBSERVATION(seq2), exact payload bytes retained and pure-validated
  -> FINAL(seq3) -> owned vmmap + required final images -> ACK3
  -> COMPLETE(seq4) -> empty-group-before-reap cleanup -> pin/evidence readback
  -> technical case PASS only if every gate agrees; otherwise stop packet
```

1. Package preparation uses only verified existing E09gsz runtime-only output,
   current frozen worker output, the exact five principal provenance files plus
   retained Utility/FuncParser. No download/build/replacement runtime. Fresh
   private fixed layout as the parent plan specifies. Exact runtime/source/build,
   compiler manifest and system-cache identity become a versioned manifest;
   caller must supply its independently approved SHA, never trust a self-hash.
   No authorization/once marker is fabricated by preparation. Full package hash
   verification precedes each worker; cheap file-identity checks continue during
   work/cleanup, full verification runs at acceptance. Hash loops yield monitoring
   where a live worker exists. Runtime/compiler packages are not case scratch.
2. One internal direct-child executor serves only the generated worker and vmmap
   commands. Retain `Owned` immediately after Popen, before any fallible call.
   Both kinds admit only their exact leader image/argv/parent/PGID/start/UUID;
   every ordinary descendant is rejected, never learned from an observation.
   Resource accounting and disk/stream checks continue after policy rejection,
   including cleanup and while nested inspectors run. Partial samples remain
   partial; no accepted identity is inferred from them.
3. A small pipe state machine admits only four successful envelopes and two ACKs.
   Bind schema/case/protocol/three identity hashes/PID/phase/exact sequence and
   exact payload keys/types. Failed COMPLETE may terminate earlier but cannot
   pass; retain its primary/disposal separately. Configuration and ACK writes are
   nonblocking with partial-write/EPIPE/deadline handling. No replay, resumption,
   dropped stdout text, infinite write or acknowledgment before image acceptance.
   Retain raw stdout plus frame offset/length/hash. Extract exact observation bytes
   from the fixed compact envelope, not a Python JSON reserialization. Test the
   real C# envelope's signed-zero payload too if existing evidence lacks it.
4. Managed inventories are the exact two equal bounded path arrays emitted by the
   worker. Admit only manifest-declared runtime/worker managed images. Require
   worker, CoreLib, SimModel and Utility; native PRE_XML requires the selected host
   identity/CLR/hostfxr/SimModelNative/FuncParser, positive FINAL also CVODES. Other
   mapped native/managed paths require exact manifest pins or named membership in
   the frozen macOS shared-cache map, never prefix allowlists. Preserve the map's
   existing metadata-not-full-content-proof limitation. Inspector failure stops
   the worker; no replacement inspector or forced native preload.
5. Scratch accepts owned directories/single-link regular leaves, not sockets,
   FIFOs, symlinks or hard-link escapes. Traverse directories no-follow with
   descriptor identity checks. Scratch may grow within limits; immutable evidence
   may not change. Retain the exact offending relative path/type/identity/stage
   before failure, without opening a rejected special node. Same-user private
   directories and sampling are not an adversarial filesystem/OS sandbox.
6. Reserve six immutable work/cleanup failure sidecars (worker plus two inspectors),
   each 64KiB with 4KiB metadata and 60KiB whole candidate rows, shared 64 identity
   cap, and temporary atomic-link overhead. A phase's first failure is immutable.
   File/pipe failures share that phase record; exact rejected-entry facts are
   bounded candidate rows. Candidate omissions/overflow are explicit evidence
   failures, never silent acceptance. Project retained streams/observation/receipts
   plus unconsumed reserves against the same case budget before writes. Raw frames
   are not duplicated into separate files. Incomplete outer writing cannot PASS.
7. Parent writes immutable raw streams, observation, inspector receipts, case and
   packet results; re-read their hashes/identities at acceptance. Stop after the
   first failed case, preserve NOT_RUN for the rest. Always report technical-only,
   model_admission=false, native source attestation UNVERIFIED, and original gates.

## Limits, code quality and performance

No changes to 30s worker including 3s cleanup; 600s packet; CPU20/21s; sampled
RSS3GiB, target0.1/maxgap0.5s; streams1MiB each; observation256KiB; case4MiB/256
entries; structured16MiB; packet64MiB/5000 entries. Inspector3s including0.5s
cleanup, stdout512KiB/stderr8192B. No budget borrowing. The old cleanup primitive
still proves identity before TERM/KILL, emptiness before sole-waiter reaping,
and retains unresolved ownership to block the next child. No unrelated signal.

Keep the executor/pipe logic finite and explicit rather than a reusable worker
framework. Bounded trees/frames/process-history and precomputed manifest path
maps avoid repeated broad searches. Retain the first primary and subsequent
evidence/disposal/cleanup facts, never exception text or environment data.

## RED-first test map

```text
new parent entry [GAP -> authored offline tests]
  |-- manifest/package: drift, alias/link, missing/extra image, pre-import hash
  |-- pipe: all four frames/two ACKs, wrong PID/hash/type/order/replay/EOF/overflow
  |          partial write, EPIPE, native stdout pollution, signed-zero envelope
  |-- process: exact leader, descendants, PID reuse/exec/reparent/group change
  |             leader exit with survivor, no samples, partial sampling
  |-- work + inspector + cleanup: monitoring continues after every rejection
  |             inspector timeout/failure, TERM->KILL, unresolved blocks next
  |-- evidence/scratch: type/path/identity retention, no-follow, byte/count boundary
  |             atomic overhead, failed writer, first-failure survival
  `-- packet: all17/16Run protocol preserved, first failure stops, no scientific PASS

real fixed host/loader/owned process path [GAP -> separately approved qualification]
  `-- meaningful exact worker packet, independent data review; no toy retries
```

Use new `livemorebio/tests/test_osp_dotnet_parent.py` and
`test_osp_dotnet_parent_execution.py`, authored process/time/I/O fixtures only.
Native calls, subprocess/network and actual OS sampling are refused in offline
tests; only isolated temporary evidence writes are real. Existing preserved tests
run under their known refusal wrapper, no expectation weakening. Any C# envelope
addition/rebuild needs a new finite build-stage decision, not an expired stamp.

## Review, execution and exit criteria

Root independently reviews this finite plan and complete RED/GREEN delta before
native activation. Then root chooses the exact source activation/rebuild, fresh
package pins/once command and actual qualification budget. No automatic retries
of the consumed R packets or the new native candidate. Report a real loader,
dependency, sampling or cleanup blocker immediately. Three repeated implementation
failures trigger a bounded architecture reassessment, not more allowance patches.

Sequential implementation in this single parent module, no safe code-parallel
lane. Independent review can inspect frozen boundaries/tests while main owns
product QA and other agents own deck/UI integration; no overlap with their files.

Not in scope: public distribution/license approval, product/API biology changes,
arbitrary models/XML, six-program substitute experiments, clinical/human-equivalence
claims, network service or new OS sandbox. These are not needed to complete this
fixed technical engine boundary. R12's prescribed later model/unit qualification
is not satisfied by S01-S17 or synthetic transport checks.

Engineering review: scope reduced to existing primitives plus one fixed parent;
architecture/code-quality/performance safeguards above accepted as the concrete
recommendation, test gaps explicitly mapped. No additional TODO or unrelated
refactor proposed. Status: PLAN_READY_FOR_ROOT_REVIEW, not execution approval.

## Maker freeze — direct connection implemented, native execution still off

Root approved the finite plan before implementation. New parent is
`tools/osp_dotnet_worker.py`; dedicated tests are
`livemorebio/tests/test_osp_dotnet_parent.py` and
`livemorebio/tests/test_osp_dotnet_parent_execution.py`. No old supervisor, pure
protocol, R collector, numerical oracle, model or source tolerance was edited.
`Worker.cs` and `NativeSimulation.cs` are unchanged. The only existing worker
edits are one additive real-PipeChannel fake test and one distinct bounded
`pipe-green` build stage. No consumed launcher, authorization or actual packet
was changed or retried. Package preparation code exists but was not invoked.

Implemented fixed package/manifest validation, direct process ownership, four
frames/two acknowledgments, owned vmmap barriers, exact raw observation extraction,
unchanged pure comparison, resource checks during rejection and cleanup, first
failure sidecars, immutable retained streams/receipts, all17 cases/16 Run schedule,
first-failure stop, once authorization and packet readback. Both native source
gates remain false. The produced fake-stage DLL is not an activated native entry.
Independent acceptance and an explicitly bounded activation/build/qualification
decision remain required; this is not a claim of an operational qualified solver.

RED/GREEN evidence (tool output identifiers are historical receipts):

- Initial parent17 tests RED `7d918e` (module absent), GREEN `593439`.
- Admission10 tests RED `01cc26`, GREEN `7b2a90`; owned-executor5 RED `c56c19`,
  GREEN `b0ad94`; connection5 RED `5cef15`, GREEN `81d896`. An authored negative
  case through the real pure comparator exposed the wrong return-key lookup
  (`aacb9a`); corrected without changing the comparator, GREEN `d8096f`.
- Actual full-frame evidence RED `bad672`: the old immutable fake stdout had
  zero of8 required full envelopes. Added the real PipeChannel fake route only.
  Approved build `e3036b`/`60f754`: restore1.230941s, build2.776964s, fake
  host0.263515s, exit0 and **32 groups PASS**. Actual envelope Python GREEN
  `aa0e0e`; signed-zero and changed-zero REPEAT_BITS survive JsonElement framing.
  Controlled fake values are transport/decoder evidence, not solver validation;
  numerical disagreements remain, and pure execution/cleanup/model flags remain
  false. Ordinary test discovery does not choose a private file: actual-byte
  tests require the explicit retained stdout argument/RAW_PATH.
- Immutable metadata work checks and original pure error-code retention RED
  `52d2e6`, GREEN `3eb1b7`.
- Independent reviewer findings: successful COMPLETE with phase CONSTRUCT wrongly
  passed (RED `7d55b3`); earlier-case same-size mutation wrongly passed final
  packet admission (RED `fd7ac3`). Success now requires DISPOSE, and all written
  case hashes plus file identities survive through final packet readback.
- Nonblocking no-follow opening and real Owned post-reap behavior RED `748d49`:
  O_NONBLOCK was absent; authored ECHILD after the sole wait caused a false
  cleanup failure. GREEN `daa638`: opened-node regular/identity checks remain,
  and after reaping only final pipe/file/resource checks run, never waitid or
  process sampling. Tests use real Owned with authored child/group/wait facts;
  no OS process is launched. An inert changed-node fstat case also refuses FIFO.
- Packet byte/count/structured ceilings now project live case buffers/reserves
  and packet-result atomic overhead globally, not just at the end. Provenance
  Core.dll is not a loadable image. RED `84f14b`, GREEN `2e6d4a`.
- Late final result readback RED `83fa61`, GREEN `e922f1`: prewrite elapsed is
  recorded after final tree checks, and readback must still finish inside600s.
  A post-publication deadline refusal preserves the original immutable result;
  the invocation's nonzero exit/FAILED completion remains authoritative. A
  result file alone is never sufficient for technical acceptance.

Final guarded repeat **73 Python groups PASS,0.507s, zero prohibited calls**
(`698d90`). This includes all22 previous package/actual-observation tests and
51 new parent tests. The guard refuses process creation, process waits/signals,
network sockets and dynamic native loading except explicit authored mocks.
Only isolated temporary fixture writes and retained technical/source-file reads
occur in these Python tests. Compiler/fake-host completion is not independent
proof of no descendants or no network; no such claim is made.

Frozen source SHA256:

| File | SHA256 |
|---|---|
| parent | `42b7982e0d2fcd154f4e6c8218862a2d7a2abe5a0574b2c8c26346e6aaeee3db` |
| parent protocol/evidence tests | `e80657b5e09c69ccfcc0f2e60125c67aa12c24e018971216cabb6e99c8136ba0` |
| parent execution tests | `9d2e768306f7560170698c52f38e046c37461082d14c45dbe494b6f017fc9b99` |
| build driver | `cf01c6ba9b0be2589018d3aaecb19a7edc870faaae77ab6667ea8650bec66b75` |
| additive C# fake tests | `faceb3705bed126a3e169fd77cdd08e10804ab202284d0a2d499752f4d102fff` |
| unchanged worker | `70011d37d2c459e264d9e7e250148ab082e1912cf492a6ca32e8957a514302db` |
| unchanged native API adapter | `23b17fe78f781d8f3bd54c9efd50386cb143cdd7ad4e52fe505fb323f1720364` |

Private evidence root is `/private/tmp/livemore-dotnet-worker-toolchain.E09gsz`.
`parent-connection-freeze-sha256.json` lists48 exact source/build/output pins;
its read-only compiler check found all417 original compiler/reference rows
unchanged. The selected SDK8.0.425 and separate runtime8.0.31 remain the same;
no download or package restoration from the network was introduced. New outputs
are only `pipe-build*`, `pipe-green*`, and the separate immutable
`offline-pipe-envelope-start.json`, preserving original/review builds and stamps.
The new stamp epoch1788968422.378973 and final fake receipt epoch1788968426.6574922
are4.278519s apart inside the300s stage. The freeze inventory SHA256 is
`4ed12bf293eb52c9a4bae998ab13eab9ec8827dbbcc6e965603eec4c99b3aeb5`.

| New artifact | SHA256 |
|---|---|
| `pipe-green-tests.stdout.txt` | `2458a3a503e571a388959f9d877322b641ba1c8745810073399ca2c157e2c977` |
| `pipe-build/bin/Worker/Release/net8.0/Livemore.OspWorker.dll` | `faf6d0ae9ce7bf24a72180a4710ce67f61c579959f0c116d6a293f8c0b3bd87a` |
| worker deps | `1a48e4a9e96ef182b6e78c549b44fcc7d9b27dcbe6a67c8e898bb8aa578aca91` |
| worker runtimeconfig | `a54ac5262f010c9d2d3cc1ea3778f237c73915881a01e8f86e70953dd02fecb8` |

Exact guarded offline repeat, from the worktree (no compiler/native process):

```sh
/usr/bin/python3 -B -c 'import contextlib, ctypes, importlib.util, os, socket, subprocess, sys, unittest; from unittest.mock import patch; denied=[]
def refuse(*args, **kwargs):
 denied.append("REFUSED_IO"); raise AssertionError("REFUSED_IO")
with contextlib.ExitStack() as stack:
 for obj, names in ((socket,("socket","create_connection","getaddrinfo")),(subprocess,("Popen","run","call","check_call","check_output")),(ctypes,("CDLL","PyDLL")),(os,tuple(name for name in dir(os) if name.startswith("spawn") or name in ("system","fork","forkpty","posix_spawn","posix_spawnp","waitid","waitpid","kill","killpg")))):
  for name in names: stack.enter_context(patch.object(obj,name,side_effect=refuse))
 suite=unittest.TestSuite()
 for index, path in enumerate(("livemorebio/tests/test_osp_dotnet_toolchain.py","livemorebio/tests/test_osp_dotnet_observation_bytes.py","livemorebio/tests/test_osp_dotnet_parent.py","livemorebio/tests/test_osp_dotnet_parent_execution.py")):
  spec=importlib.util.spec_from_file_location("parent_review_tests"+str(index),path); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
  if index in (1,2): module.RAW_PATH=module.Path("/private/tmp/livemore-dotnet-worker-toolchain.E09gsz/pipe-green-tests.stdout.txt")
  suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
 result=unittest.TextTestRunner(verbosity=1).run(suite)
 print("REFUSED_IO_CALLS",len(denied)); raise SystemExit(0 if result.wasSuccessful() and not denied else 1)'
```

Prospective operational entry after a separate reviewed activation/rebuild and
fresh package preparation is exactly the fixed parent with five arguments:
`/usr/bin/python3 -B tools/osp_dotnet_worker.py MANIFEST_PATH MANIFEST_SHA OUTPUT_PATH AUTHORIZATION_PATH AUTHORIZATION_SHA`.
There is no arbitrary model/command flag. `prepare_package(fresh_nonexistent_path,
approved_build_directory, exact_three_emitted_hashes)` creates an inert package
and manifest only, not authorization or once files. Root must approve exact new
paths/pins and the native build's two activation lines before this command is
usable; a literal unresolved placeholder is not an authorized command.

Remaining limitations: sampled process/resource observation is not a hard OS or
network sandbox; same-user private-directory TOCTOU boundary remains; system-cache
map/header metadata is not full cache-content attestation; native dependency
binding, actual loader inventory, numerical behavior and cleanup on this direct
path are still unqualified. All scientific/unit/evidence gates stay unchanged.
No six-program or arbitrary-model result is inferred from these tests.

Compounded lesson: test the exact serialized outer envelope and the real
sole-waiter lifecycle boundary. In-memory payload tests and permissive child
fixtures can respectively conceal number-token conversion and post-reap ECHILD.
This lesson was recorded directly here because CE is unavailable. Engineering
plan skill informed the finite scope and review map; maker does not self-grade.
