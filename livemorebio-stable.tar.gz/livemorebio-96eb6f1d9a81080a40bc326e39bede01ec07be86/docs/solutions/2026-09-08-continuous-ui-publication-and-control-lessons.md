# Continuous UI: one source, atomic publication, separate control lifecycle

2026-09-08. Implementation record under the independently reviewed continuous
lifecycle UI binding plan. This is not acceptance of whole-body equivalence,
physical sensing, insulin or the five botanical experiments.

## Corrections and why they matter

- Publish a frame page only after its optional LIFE session matches the same
  execution, source digest/generation, complete selection and metabolic contract.
  Validate revisions, counters, authorship and evidence class before publishing
  either peer's data. A mismatch retains the previous numerical window as stale.
- Independent reviewer `release_redteam` reproduced a mounted-controller race:
  a read begun at prepared revision1 could arrive after Start returned running
  revision2, poisoning a valid source as stale. Control actions now abort the old
  poll generation and fence reads while pending. Only a successful settled action
  resumes reads; uncertain mutations are never automatically retried.
- The same reviewer identified a15-second timeout conflicting with permitted
  native initialization. Start/resume now use60 seconds; ordinary reads retain
  a15-second bound. The separate shared authorization-bootstrap deadline remains
  another owned correction and is not silently claimed fixed here.
- Preserve frame generation, LIFE capture and Aegle acknowledgment timestamps.
  Their age is calculated for presentation without re-timestamping any sample.
  A future or unavailable clock has unavailable age, not a fabricated fresh age.
- Hidden views abort reads and mark the retained display historical until a
  verified refresh. They do not issue producer/consumer lifecycle commands.
- Execution-bound Biology uses source-backed reference geometry plus exact
  committed systemic or ventricular-cell quantities. It does not resize an organ
  from glucose, call membrane voltage ECG, borrow the active twin, or assign
  gene/tissue dynamics that this contract does not compute.

## Red → green evidence

`test_execution_view_ui.py`:10 tests pass, including atomic peer/frame rejection,
mounted pre-control response cancellation, deadline selection, original clocks,
source replacement, missing and invalid frames, finite/unit/time/sequence checks,
bounded catch-up and retained windows. The first mounted run failed with
`control did not cancel older status read`; the clock test failed because the
presentation helper did not exist. The session/frame test failed because the
combined admission boundary did not exist.

Independent source reviewer reran the execution/anatomy/retry subset:
31 passed. Broader maker UI controller/anatomy/reference-cohort/Cendos subset:
47 passed. Neither result is a substitute for real-browser acceptance, which
root owns after restarting the dedicated8910 stack from stable source. The
separate8930 endurance run was not touched.

## Legacy test harness repair, not discarded assertions

The first broader run had42 passes and these5 failures:

1. `test_clean_workflow_ui.py::test_biology_data_loads_and_retries_independently_of_graphics`
2. `test_clean_workflow_ui.py::test_unavailable_organs_and_cells_do_not_invent_measurements_or_activity`
3. `test_clean_workflow_ui.py::test_cell_replay_binds_context_invalidates_pending_data_and_resumes_after_refresh`
4. `test_protocol_inspection_ui.py::test_stage_quantity_and_time_handlers_share_the_selected_frozen_context`
5. `test_protocol_inspection_ui.py::test_linked_anatomy_rejects_changed_context_instead_of_displaying_another_twin`

Four extracted ESM entry scripts were fed into `vm.Script`, which cannot parse
the new static `restoreAnatomyView` import (`SyntaxError: Cannot use import
statement outside a module`). The fixture now inlines that exact real local
helper and supplies the browser's global event registration method. It still
runs the full Biology mount, polling, retry, unknown-state and cell-context tests.

The stage test lacked the newly introduced compact member-picker import and
run-anatomy mount. It now executes the real member-picker code/handlers, stubs
only the separately tested geometry rendering boundary, and additionally asserts
that the same selected member reaches that boundary. All prior quantity, time,
unavailable-stage, source-lineage and no-unrelated-data-fetch assertions remain.

Root's subsequent full non-network run found2 more literal-source failures
(1590 passed,6 skipped,5 deselected,44 subtests before correction):

- `test_qa_regressions.py::test_issue_patch_page_pauses_polling_when_authorization_is_cancelled`
  expected exactly `if(!AUTH_PAUSED)load(true)`. The real condition now also requires
  a visible page and open recorded-workspace disclosure. Its replacement executes
  the entire recorded controller: closed first load makes no request; an open401
  pauses all interval reads and does not auto-retry authorization; explicit retry
  recovers; hidden/closed reads remain paused; visible authorized polling resumes.
- `test_ui_biological_projection.py::test_ui_has_no_autonomous_biological_motion_or_active_twin_run_fallback`
  expected the old run-only branch guard string. The real guard now excludes both
  `run_id` and `execution_id`. Its replacement executes the entire active Biology
  controller for valid, invalid and ambiguous fixed-context URLs, proving no
  active source request, active DOM mount or active timer occurs. Other no-motion
  and recorded-time assertions remain unchanged.

Those2 files plus the new browser-harness guard tests pass10 tests. No protection
was weakened and no literal comment was added to make a test pass.

## Root-run browser harness (not executed by its maker)

`tools/check_continuous_browser.cjs` requires the exact8910 review URL, an explicit
existing synthetic technical twin ID, technical acknowledgment and absolute output
directory. It creates no twin and fails before writes if the selected source is
absent or differs. It inspects visible controls before acting, prepares/binds/starts
through those controls, observes two distinct acknowledged frames and a frozen
pause, separately resumes LIFE/producer, verifies actual browser hidden/visible
behavior, follows the exact Biology source, checks reference geometry and mobile
layout, and observes for at least50 seconds after producer start. No visibility
override, imported sample or screenshot slideshow is used.

Successful creation-response IDs are captured before waiting for UI rendering so
failure cleanup can stop only those new owned session/execution IDs. It never
deletes records or unbinds a prior device. The new probe and technical twin binding
remain recorded as setup provenance. JSON evidence is an explicit metadata
allowlist, not native value arrays or a health profile. Failure screenshots are
allowed only after rechecking the exact currently selected technical source.
Four red→green harness guard tests pass without launching a browser; root owns
actual execution, screenshot inspection and acceptance.

Independent harness review found and corrected two additional acceptance hazards:
the launched browser now has an outer resource `finally` covering context/page
allocation and evidence-write failure; and the harness requires an explicit
reviewed source SHA256, checks all three service build identities/ports/process
instances before mutations and again at the end, and preserves these operational
identities separately from the numerical source snapshot digest. A compatible old
backend cannot be accepted merely because it answers on8910. These safeguards have
no-browser failure-path tests; their addition is not a claim the browser run passed.

## Pending acceptance

Real-browser lifecycle, auth recovery, actual committed native frame display,
desktop/mobile screenshots, execution-linked graphics, and descriptive public
cohort UI/API integration require independent browser review. These are not
declared complete by the source/controller tests. Whole-person living Atlas
R21–R24 and qualified healthy/non-T2D executable cohorts remain separate open work.
# Lifecycle intent must not race normal telemetry

The independent current-build browser attempt under
`docs/screenshots/full-scope-recovery/continuous/attempt-1/` failed after two
acknowledged numerical frames: Pause LIFE submitted displayed record revision 21,
but normal pending/receipt/ACK/status writes had advanced the same revision.
This was a real product failure, not a stale assertion or an acceptable retry.

The approved follow-up plan is
`2026-09-08-continuous-control-revision-correction.md`. It preserves the storage
revision and introduces separately persisted lifecycle `control_revision`.
Client-side source/subject guards, private errors and no-retry behavior remain.

UI/CLI/SDK red state: **73 failed, 25 passed, 10 deselected** in 0.46 s. Failing
families were the unsupported SDK keyword, CLI mapping, missing/ambiguous guard
handling, strict UI control-revision validation, and mounted lifecycle display.
Browser metadata/cleanup guard red state: **2 failed, 3 passed** in 0.34 s.
The corrected five-file test group passed **199 tests in 1.26 s** before final
independent review. These are software tests, not browser acceptance.

The mounted regression retains a displayed LIFE control revision while advancing
the fake server's record revision, then clicks Pause once. The outgoing request
must use the displayed control revision. A genuine lifecycle conflict remains
visible and stale, with exactly one POST and no hidden revision fetch/retry.
Producer controls retain the exact source-generation field. Missing, boolean,
nonpositive, nonintegral, regressing or impossible control revisions are rejected
before the UI publishes the snapshot. Legacy explicit record guards still work
in CLI/SDK; neither mode infers a fresh guard.

The root-run harness records both revision domains and its owned cleanup uses
only an explicitly returned valid control revision, never a sample-revision
fallback. The failed first attempt remains unchanged. Final rendered acceptance
and backend concurrency review belong to independent owners.
