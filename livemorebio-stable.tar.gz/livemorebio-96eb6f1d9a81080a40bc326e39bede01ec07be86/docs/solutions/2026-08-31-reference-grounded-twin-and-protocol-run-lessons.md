# Reference-grounded twins and run-scoped protocol projections

**Date:** 2026-08-31  
**Applies to:** Aegle subject registry, cohort generation, LIFE Patch binding, Cendos protocol runs,
and Biology visualization

## Problem

An apparently rich digital-twin form can still produce scientifically meaningless records if the
browser is allowed to declare its own source metadata, if a cohort stores only member hashes, or if
Biology loads whichever experiment happened to finish last. The same class of identity error
appeared in the Patch loop: Atlas requested a hard-coded virtual device even after the active twin
had been bound to a different one.

These failures look like UI defects, but the root cause is missing authority and identity at the
data-contract boundary.

## Decision

1. Population-source metadata is server-owned. A request supplies only an allowed source ID,
   stratum, and seed; conflicting release, provenance, or population text is rejected.
2. A reference cohort materializes each heterogeneous member profile plus field-level lineage.
   Fingerprints are integrity summaries, not substitutes for executable biology.
3. A real-human profile counts a domain only when both a source declares it and corresponding data
   are actually admitted. Missing person values are never silently replaced.
4. Exactly one twin may be authoritative. Activation demotes the previous `ACTIVE` record.
5. Every protocol result has an immutable run ID. Cendos export and Biology projection require that
   ID instead of a global `latest` record.
6. Virtual telemetry resolves the device bound to the active subject. A mismatched caller device is
   rejected instead of creating a second hidden identity.
7. Evidence state travels with the run. Mechanistic and structure-backed execution never promotes
   itself to observed, qualified, or clinically validated.

## Implementation pattern

```text
request source ID + stratum + seed
              |
              v
      server-owned manifest
              |
              v
 materialized heterogeneous members
              |
              v
      frozen protocol run ID
        |             |
        v             v
   CSV/Jupyter     Biology ?run_id=
```

The same identifier-binding pattern applies to the closed loop:

```text
active twin -> recorded Patch binding -> LIFE admitted envelope hash -> Cendos counterpart
```

No global latest-person, latest-device, or latest-experiment lookup belongs in a scientific
workflow.

## Tests that prevent regression

- caller-supplied reference metadata cannot override the source manifest;
- same source/stratum/seed is deterministic, while cohort members remain heterogeneous;
- declared-only real-human source domains remain uncovered;
- activating a twin leaves exactly one `ACTIVE` record;
- protocol applicability rejects the wrong cohort stratum;
- Biology loads only a valid selected run ID;
- Patch sampling rejects unbound and mismatched subjects/devices;
- modeled results remain modeled when stored, exported, and visualized.

## Product lesson

“Biologically grounded” is not achieved by adding more fields or databases. It requires explicit
authority for every value, executable contracts for supported contexts, immutable experiment
identity, and a measurement path that can later falsify the model. That pattern scales organ by
organ and protocol by protocol without pretending the current system is already a complete living
human replica.
