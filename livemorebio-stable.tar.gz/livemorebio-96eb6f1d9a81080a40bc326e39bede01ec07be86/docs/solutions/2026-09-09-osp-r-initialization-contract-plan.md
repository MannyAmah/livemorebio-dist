# OSP R initialization: bounded contract correction plan

2026-09-09. Source-based follow-up to the preserved qUfcQ6 startup failure.
No new native run, model admission, changed numerical semantics or blanket
child-process allowance is authorized here. R01–R51 and six videos remain open.

## Cause and exact source closure

The supervisor admits only the four collector-controlled CLR barriers, but R
loads its default utils package before the collector can send a barrier.
utils .onLoad calls .osVersion, which calls Sys.which("uname") and then
system("uname -a", intern=TRUE). The process policy therefore rejects standard
R initialization, not an insulin computation. Preserve the two failed packets.

The additional source-only review establishes these two sequential commands:

```text
/usr/bin/which 'uname' 2>/dev/null
uname -a
```

The first is composed by the retained base Sys.which source expression,
shQuote and system's ignore.stderr behavior. Only a nonempty lookup proceeds
to the second. shQuote and system serialized objects parsed completely;
Sys.which's source expression decoded, but a later compiled tail has an
explicit unsupported-type gap. Do not claim full bytecode/native attestation.
The current SDK popen manual documents /bin/sh -c and pclose waiting. It is not
the historical native R build source. The retained .osVersion Darwin branch
does not call uname -r or arbitrary shell helpers.

Current read-only identity checks (root d2565b/e61a36/27f406/c0c802 and independent
cd0ecb/9ec2aa/fcff69/1d7ddf) establish:

| Executable | Bytes | SHA256 |
|---|---:|---|
| /bin/sh |101232| `094fc5e188feb7cc18906900b1b5c417e03aaed03a9fc132e925f38640d9bd59` |
| /bin/bash |1293840| `35536aea9733aa345b61134a98d00232380898e55b2ea2a07c497011f7dfc7a3` |
| /usr/bin/which |101456| `306ab854443c4770cb1a76f8df0e37abbb8290d70639119ef50170677c3065cb` |
| /usr/bin/uname |101456| `9abecf7a88117e093ff6c34ce07bacf7dc1277af1193b1cb0a0bf8fa4b2d4696` |

/private/var/select/sh currently points to /bin/bash. /bin/sh's static strings
name that selector and supported shells; those strings alone do not prove all
dispatch control flow. The earlier PATH candidate retained dotnet/uname is
absent. The current first executable uname candidate is /usr/bin/uname.
Existing inventory verification checks listed files, not absence of additions;
therefore the new startup contract must verify this shadow absence explicitly.

## Proposed smallest implementation boundary — review before code

1. Add a separate R-initialization state to the existing case callback, active
   from spawn only until a write-once collector-entry handoff. Do not broaden or
   rename the existing CLR startup boolean or reuse its sequence numbers. The
   collector sends entry before library(ospsuite), waits for the matching
   acknowledgment, and only then can reach the unchanged four barriers.
2. Bind the handoff to exact case/PID/runtime manifest plus the new startup
   contract hash. Use bounded exclusive/atomic files in the existing case
   directory, with strict shape/identity and immutable reread. Reject malformed,
   changed, repeated, missing or out-of-order entry; no reactivation after it.
   Keep the existing worker deadline and cleanup reserve; no new time allowance.
3. During this state admit only the owned R leader, one exact lookup-or-uname
   shell and its matching leaf, at most three processes in the same owned group.
   Exact commands above only; shell image must match verified /bin/sh or its
   verified configured /bin/bash image. Account for shell→leaf exec using the
   existing sampled image/start/argv identities. Leaf argv is only which+uname
   or uname+-a, with parent relation matching the observed owned topology.
   No mixed branches, arbitrary shell arguments, inspector children or unrelated
   process images. At/after collector entry, no R-initialization child remains
   admissible. Existing CLR-only command/parent rules are not silently widened.
4. Bind the four full executable identities, exact shell selector target and
   earlier PATH shadow absence in an additive startup manifest; recheck before
   spawn and before accepted case completion. Do not rewrite the preserved V2
   runtime inventory or claim it excluded extra files. Freeze new manifest,
   supervisor, collector and protocol/launcher bindings before any actual run.
5. Add RED-first tests for each exact accepted topology, wrong argv/image/hash,
   shadow addition, selector change, parent/group mismatch, mixed branches,
   entry acknowledgment order/immutability, irreversible state, missing entry,
   zero/multiple handoffs, cleanup/failure retention and complete-call bounds.
   Preserve all existing semantic cases and their Run counts, CLR barriers,
   units/options/solver settings, ownership rules and closed execution gates.

Sampled process observations are not a complete exec trace and cannot prove
exact invocation counts for transient helpers. The correction must state this
limit rather than pretending a finite allowlist is native-source attestation.
If source review finds the handoff or topology cannot be made exact within the
current small callback, report the specific issue before changing code. Do not
create a general process framework, disable utils, fabricate platform output,
substitute an easier protocol or retry either consumed private root.

## Acceptance and lesson

Independent engineering review, failing tests, minimum implementation and
independent offline repeat precede any separately reviewed fresh technical run.
Even a complete S01–S17 technical pass would not qualify the inherited insulin
source, repair its units/domain/convergence questions or count as an experiment.

Bootstrap behavior is part of an execution contract. Retain the actual rejected
process, trace the source's full lookup chain, then admit only the necessary
bounded initialization behavior instead of relaxing model-phase controls.

## Independent engineering review incorporated; offline implementation decision

Root accepts the six source-backed review precisions and authorizes only the
minimum RED-first/offline implementation. No native run is authorized.

- Name and place the boundary accurately: configuration-ready, after validated
  configuration and jsonlite load, immediately before library(ospsuite). Keep
  the existing early system-hook registration and guaranteed restoration.
- Close initialization permission irreversibly before a forced complete
  leader-only sample and before acknowledging readiness. Use the existing
  sampler/resource/failure-retention path, not a second process inspector; an
  ordinary tick's 100 ms sampling interval is not sufficient for this boundary.
  Refuse any CLR request before acknowledgment. Expire permission on work
  termination, including failures. Recheck retained handoff bytes/identity in
  work monitoring, cleanup and final admission, not just the callback body.
- Exact allowed graphs are R alone; R→one shell; R→one leaf after shell exec;
  or R→one shell→its matching leaf. Exact leaves are ['/usr/bin/which','uname']
  and ['uname','-a']. Only the two source-established shell command strings
  above, with the existing sh or /bin/sh argv0 forms. No sibling/mixed branches,
  cycles, missing parents, unrelated images or reliance on an earlier sampled
  shell observation. All process groups stay owned and at most three rows.
- The verified dispatcher-equivalent /bin/bash image is also permitted for
  the existing exact dotnet-only CLR shell command, solely within its existing
  CLR window. Its command, parent/group and size predicates remain unchanged.
  Initialization command permissions never extend into CLR/model phases.
- Use fixed initialization-ready.json and initialization-ack.json, each at
  most 4096 bytes. Readiness binds schema OSP_R_CONFIGURATION_READY_V1,
  case_id, pid, runtime_manifest_sha256 and startup_contract_sha256; ACK has
  those same fields plus status CONTINUE. No extra/duplicate keys or implicit
  sequence reuse. Publish via no-replace atomic link semantics; check both
  final/pending names. Reads are bounded, non-following regular/single-link
  identity-checked reads. Both files and pending paths count inside existing
  case limits without taking the six reserved failure-sidecar slots.
- Keep semantic identity's exact three keys and pure protocol unchanged. Add
  a separate startup_contract_sha256 to configuration, handoff and technical
  receipts. Create a versioned additive manifest for the four exact executable
  identities, selector lstat/target identity and earlier PATH absence. Verify
  absence with lstat so a dangling symlink is not mistaken for absence. Preserve
  old V2. Recheck before spawn/final acceptance; errors cannot mask an earlier
  primary or interrupt owned cleanup. A future fresh launcher must pin this
  manifest separately; none of the consumed launchers/authorizations is edited.

Permitted source boundary: the existing supervisor and collector, additive
startup-contract manifest, targeted new tests and only strictly necessary
fixture-contract updates to inherited tests (with exact explanation). No model
importer/equation, runtime artifact, numerical fixture/protocol, package upgrade,
operational store, device, network or browser change. Keep both execution gates
false. Record all pre-edit identities, RED results, minimum delta and complete
offline preservation results for independent root review before any actual run.

### Approved pending-publication precision (before collector edits)

The retained R manual does not document an exclusive file-connection mode;
unsupported modes may be silently substituted. Root therefore explicitly
selected atomic `dir.create` of the fixed private
`initialization-ready.json.pending` directory, containing one completed
`payload` file. Preexisting directories, regular files or symlinks must refuse
creation, with no retry or following of the preexisting object. Publish the
closed payload using documented no-replace `file.link`, and clean up only
exact-owned resources. Count the directory, payload, final readiness file and
ACK final/pending names inside the existing byte/entry ceilings, independently
of the six failure-sidecar reservations. Do not invent an R exclusive open
mode or claim link publication is a two-name atomic transaction. A transient
two-link payload is not a completed single-link readiness file. No runtime
execution or additional scientific/operational permission is granted.

Root also approved the precise reader boundary: the Python parent is
authoritative for bounded descriptor-level no-follow, regular/single-link and
inode/content identity checks on both immutable handoff files during work,
cleanup and final admission. The base R ACK reader performs a bounded byte read,
exact schema/values, and before/after `file.info`/`Sys.readlink` checks; any
failure stops collection. R does not claim inode/nlink/O_NOFOLLOW verification.
The same-user private directory remains a trust boundary with a TOCTOU
limitation, not an adversarial filesystem sandbox. No native helper or new
transport is authorized. The retained manual supports checked `file.remove`
for an empty directory on most Unix platforms: attempt only the exact-owned
payload then the exact-owned empty pending directory; failure retains evidence
and stops without recursive removal, retries, replacement or cleanup of
unknown entries. Actual platform success remains unobserved until a separately
approved execution.

Independent source review then found that retained `Sys.readlink` returns
`NA`, not an empty string, for a nonexistent path (manual PDF page 661,
printed 608). `NA` can also represent another error. The minimum correction
therefore treats `!file.exists(path)` plus exactly `NA_character_` only as an
absence candidate in this fixed private directory, never authoritative proof.
Existing files/directories and nonempty dangling-link targets still refuse;
thrown R errors are not caught by the predicate. The parent `lstat` preflight,
checked exclusive directory creation, no-replace final link and parent strict
handoff reads remain authoritative. This intentionally does not claim that
base R distinguishes every missing-path condition from every OS readlink error.
Six authored source/truth-table RED cases precede the correction; they do not
execute the R interpreter. The earlier 650-pass offline result is preserved as
incomplete evidence because this source-level defect was found afterward.

## Maker receipt — frozen for independent review, not execution approval

The authorized source correction is complete and frozen. Root must independently
grade it. Both execution gates remain false. No R/.NET/model/vmmap invocation,
OS process sample, browser, network, dependency installation, commit, push or
consumed-launcher modification occurred in this implementation. Existing CA533x
and qUfcQ6 failures remain failures; nothing identifies the lost CA533x child.

Initial copies and all offline evidence are retained in
`/private/tmp/livemore-osp-initialization-offline.HYnsZ1/`. Initial identities:

| File | Pre-edit SHA256 |
|---|---|
| supervisor | `af735907d6eeb1ab4d158cc9a365d61e4af6f71d8c2e3b70afe4631b5b398dd6` |
| collector | `3ba6559b723cfe85c66bca47aac0abfbaac8e395c430bd7360105dc6f67625f7` |
| inherited supervisor tests | `0d6bd396e8d0a15953719746133e960896c51cea9cc610d818a8d4e84f37fe41` |
| inherited inspector-budget tests | `e7b89f864ed6c9fdc2726758b533831d1b0d8478a7d0ae34442a01dbd12655c6` |

### Exact RED/GREEN chain

- Before source edits, `9d7fab`: **66 failed, 1 passed**, 0 unexpected I/O.
  Initial new-test SHA `88fabf6ae3e563bcdbe75845c343bd4fb5be0d6ba63705ed0f9ed17954b362f2`.
  `red.txt` SHA `537011551bd66c29504c5450ea90e010600bbc997337936dbd915fc54678f913`.
- Approved pending-directory/preexisting-name/reservation amendment, `4bf9cf`:
  **15 failed, 81 passed**, 0 unexpected I/O.
  `red-pending.txt` SHA `51ba1db0be552d6416cb0a900fc27991ac4630fa3b604be42f1ddce93a071c64`.
- Atime-independent R metadata and same-byte manifest identity reread, `6e34f1`:
  **2 failed, 95 passed**, 0 unexpected I/O.
  `red-reread.txt` SHA `a5f48e5b5d26b6895e6364669a6834a21d6553dd2b53a24a6dbd2b38333896ee`.
- Historical intermediate full repeat, `dd107c`: **650 passed, 2 excluded**.
  `green.txt` SHA `072ce8b1b76badd9248a9a783b2bf3550c7ad389f1cf6b906d572c1931f1b3bd`.
  Independent source review subsequently found the missing-path `NA` defect;
  this intermediate pass was explicitly not accepted as a freeze.
- Source-backed absence-candidate correction, `3be941`: **6 failed, 97 passed**,
  0 unexpected I/O. `red-absence.txt` SHA
  `cec0762c9b6b48844a2d0c935d425bcc4c974d38d94f89f460048a6e2e032908`.
- Final full suite `2f9da2`: **656 passed, 2 native watchdog cases excluded in
  1.78 s**, exit 0, 0 unexpected I/O. These are 103 new cases plus 553 inherited
  offline cases. `green-absence.txt` SHA
  `0de5d377caf75b0bc58b0caa1ac91497a50abb8fc320b490e0989f9aa34804d6`.
- Frozen maker repeat `eb6248`: **656 passed, 2 excluded in 1.76 s**, exit 0,
  0 unexpected I/O. `repeat.txt` SHA
  `c6cc1435add1026e87625e640e1a0fa85e969ecb83875e3d0657cf33e39ab8f3`.

The four symlink preexisting-name test expectations retain the original
`EVIDENCE_TREE_BOUND` refusal, which precedes the new name check; they do not
require replacing that earlier primary with `INITIALIZATION_PREEXISTING`.

### Frozen file identities and minimum delta

| File | Bytes | SHA256 |
|---|---:|---|
| `tools/osp_semantic_supervisor.py` | 64721 | `c3f5ec38a25be726a4d939c55f9a22b9fd41e45e9f21c7af43cb1b8a5ab67923` |
| `tools/osp_semantic_probes.R` | 14546 | `e108ff061e0f15a030eac3a2f80e0279edc12783eca866e210518c1da8fdd7c7` |
| `livemorebio/tests/test_osp_r_initialization.py` | 25316 | `74de813a574c0a7144aa9385e6efe9735747fdea4dd7c168cc29a85dc196605b` |
| `livemorebio/tests/test_osp_semantic_supervisor.py` | 31860 | `f4527a2d6ff5a7f31f19fd220765acfc42ac35e04470891bba619ff37d1b1d0b` |
| `livemorebio/tests/test_osp_inspector_budget.py` | 8587 | `7130d7fb301b671b6c95eee78f7014667bc10b463b74d42ab5f93cbe25061a8e` |
| `docs/solutions/2026-09-09-osp-r-startup-contract-v1.json` | 1605 | `70bed51c6cd58a70586fa9f59aa1d1fcddf0674029e14e1ae11a116ec1082d24` |

`source.diff` contains the complete six-file delta (973 lines), SHA
`2d85214373b2b13b4ebe3f2fd87caf6ed70ae94eaf069e2d14a11b6ee2da7bb3`.
`source-identities.json` SHA
`82d7c6308218115ddd0d64eccfc4d00d17b10b37fc88d606bbc9ecea935ecce6`.
The source-only AST comparison preserved all 21 original module assignments.
Existing definitions changed only in configuration, process policy, shared
evidence budget/observation, execution, case callback/admission and packet
receipt; three small top-level helpers were added. Owned cleanup, raw OS
sampling, resource limits, ordinary launch environment and four CLR barriers
are unchanged. Removing only the added R helper and its one invocation yields
the exact original collector bytes; its hook, restoration, model calls and
numeric options were not rewritten.

Inherited fixture changes are limited to two post-handoff state assignments
(with comments) in each existing inspector checkpoint fixture, and the same
state plus an authored manifest-verification stub for the otherwise successful
disk-overrun fixture. No inherited assertion or expected model result changed.
The stub prevents that fake worker from reading actual system executable bytes.

The six failure-sidecar reservation slots remain independent. Initialization
reserves another 16 KiB and five entries inside, not above, the existing
4 MiB/256-entry case ceilings until its two final files are published and
counted. Work and cleanup continue resource/stream/disk monitoring after
process rejection; the forced readiness sample uses that same retention path.

Pure source remains `12585d9bed93cd2a5625ec1cd625287406a22d475b49c34ba931109630ea82d7`;
V2 remains `d09b1f5dcb15d6d612b8b5301c2bb5f6a4c7f174b8e08eeff1df24b087c94be2`;
consumed qUfcQ6 launcher remains
`4e3663b182f901a9d82df03ba39d8aa30f7d140205bc36167069e0a7a2b6e2df`.
The technical protocol, its 17 cases and 16 Run-call schedule are unchanged.

### Exact offline repeat and remaining limits

From `/Users/emman/Livemore/.worktrees/full-scope-recovery`:

```bash
PYTHONDONTWRITEBYTECODE=1 /Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B /private/tmp/livemore-osp-initialization-offline.HYnsZ1/run_offline.py --full
```

The runner SHA is
`6a5a4df2bc7c008c686253f397ddbfbf1777899d4842512142de68a5e39f2b00`.
It uses the established `prepare_review_environment`, disables plugin autoload
and bytecode/cache generation, excludes both native watchdog cases, and refuses
socket/network, subprocess, process-start, OS spawn/exec and ctypes loading.
All actual `_execute` tests replace ownership/OS boundaries with authored rows;
real file writes occur only in isolated test roots.

R behavior is source-checked against the retained manual and authored truth
tables, not executed. The PDF skill was used read-only for that manual
(`fullrefman.pdf`, SHA `25f4629922dc0ea8d26f72130672a0ac366d82e84fd0c6d5ee3be26ff69e3042`),
including file linking/removal, directory creation, readlink return values and
documented connection modes. Platform success of empty-directory `file.remove`
and the entire R/CLR handshake remain unobserved. Link/close publication is not
power-loss durability; base-R reads retain the explicit same-user/TOCTOU and
`NA` ambiguity limits above. Sampled helpers are not a complete exec trace.
No PID coercion was added without evidence. A future launcher must separately
pin this additive manifest and obtain a new decision; neither this receipt nor
any offline pass authorizes one.

Lesson: a Python-green source transport still needs independent review of the
other language's actual API contract. Here that review caught a real missing-
path mismatch before any native attempt, while preserving the failed records.

## Independent root regrade

Root read the complete supervisor delta, collector helper/call boundary,
all 103 new cases, both inherited fixture diffs, additive manifest and exact
offline runner. The review confirms the separate irreversible initialization
state, forced leader-only boundary sample, unchanged CLR commands/barriers,
bounded immutable handoffs and retained failure/resource/cleanup paths. The
R missing-path and access-time findings are historical defects corrected in
this freeze; no undocumented PID coercion or interpreter execution was added.

Independent exact repeat `eb8c4f` / completion `374632` passed **656 tests,
2 native watchdog cases deselected, 1.77 s**, with zero unexpected I/O. Private
test root: `/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-z4f6l7eu`.
Verdict: **CLEAR for this offline initialization-contract correction only**.
The source-level absence predicate retains its documented ambiguity, and the
sampled process policy is not a full execution trace. Actual R/CLR startup,
scientific source admission and the 17-case native packet remain unverified.
No consumed launcher was changed and neither execution gate was opened.
