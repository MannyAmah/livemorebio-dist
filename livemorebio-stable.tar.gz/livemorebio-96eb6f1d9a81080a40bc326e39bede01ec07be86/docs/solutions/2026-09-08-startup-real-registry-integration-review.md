# Checked startup: independent integration review

2026-09-08. Root reviewed the release reviewer's frozen315-line test-only packet,
its ten-case plan, actual startup consumer and reused seed/rows/events helpers.
Root did not author these tests. The runtime startup/fence changes were already
independently graded by the source reviewer in the separate implementation report.

## Result and limits

All10 cases passed independently in1.89s, private review `atcq3bt6`, exit0.
The isolated45-second ASGI-compatible wrapper recorded zero unexpected network/
process attempts and one refused optional Git metadata lookup. Its internal
TestClient socketpair is not a listening service. Three existing FastAPI/Starlette
deprecation warnings remain; no dependency migration is included in this packet.

The actual server registry getter used a private database and public fixed test
key. Checked reads, exact selection confirmation, encryption and reserved audit
begin/finish stayed real. The source authority, no-background manager and snapshot
projection stayed real. Numerical constructors/candidate state and unrelated bus
storage sinks were deliberately inert; their substitution is explicit, not proof
of native model execution or cross-service delivery.

Confirmed cases cover true selection absence with unrelated records retained,
selected synthetic records, unbound real-human-shaped observation-only records,
and explicit restoration after initialization. Storage changes at unchanged
version or pointer timestamp are rejected without overwriting the external edit.
Orphan ACTIVE topology and failed audit INSERT do not create a healthy fallback.
Unauthorized requests do not trigger restoration; confirmed uncertainty leaves
static access available while selected-state/current-source/actions fail closed.
Completed encrypted audit pairs precede construction/publication, preexisting
record/index/audit bytes are preserved, reservations settle and ordinary ensure
does not retry. No participant data or operational store was used.

## Frozen identities

| File | SHA256 |
|---|---|
| test_checked_startup_registry_integration.py | cfdea590951dcd2c3f4b2282afe410114621abd42652efba3feb036c5c11d153 |
| server.py | f77b80c4d5a2cc86e38fe4dbfe76fe879a84840f6ee1cef833ef01f14b79bfab |
| subjects.py | 0a8eaee99b653a1b1823a1434c2e5ff1a2d468dc9659677cb426b33f6389b465 |
| registry_audit.py | b21f01fdf1c79604c5565fee0f7d94d3b0bd11967b199bc97ec8a193de045e4e |
| execution.py | 2caafc14925604e3ad3e194c3c668a7cf41eb83eb5fea3afa619bf897c277aac |

This clears this bounded integration packet only. Actual persisted native-model
restoration, binding/preview and observation/reconciliation migration, browser
acceptance, R01–R51 and all six experiment recordings remain open. The lesson is
to test the encrypted reader and its final confirmation through the real startup
consumer; independently correct components do not alone establish their wiring.
