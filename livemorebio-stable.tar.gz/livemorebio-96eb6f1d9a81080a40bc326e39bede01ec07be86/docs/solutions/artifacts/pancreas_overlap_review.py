"""Fixed-input, read-only replay of the retained pancreas overlap arithmetic.

This is a review artifact, not a product converter, mesh repair, model or GPU test.
No arguments, downloads, output files or product imports. NumPy is the only
non-stdlib dependency. Original executed results are recorded in the companion
diagnosis; this persisted packaging of those calculations has not been rerun.
"""
from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path
import struct
import zipfile

import numpy as np


ATLAS = Path("/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-1q65uy9g/anatomy/atlas")
MANIFEST = "8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a"
ARCHIVE = "40665852c49f218326590e204db91064a1ecfc3c6f8cbd7bbbcaac62c7cd409e"
ISA = "a3de74423f943b0d724ae8f59b3a817f87c423a544f8db98113b1980817cbeaf"
PARTOF = "3f5f6df1028eb122b30de77c711597b6bb8e5541658e5985859fd228adbf88ea"
GLB = "1b89be32e9725a48140bb6f754c3ac4a6852a98067bf4491a28fe8988f56e908"
IDS = ("FJ1895", "FJ1896", "FJ2629", "FJ2630")
SOURCE_PINS = {
    "FJ1895": ("ed9111890b410aebacb86ae06ce2f7e3010bac8a2db3f9b292b53359bbf18026", 307895, 2462, 4890),
    "FJ1896": ("aaf43697017cb6a8df51f1c95b4a10917fa165178fbd4e32dce946332d2cbc03", 344665, 3941, 3368),
    "FJ2629": ("bd34649f3c15c34fe2fe845a6c6e926de2c014557360df48922f7266dba113e6", 267563, 2153, 4272),
    "FJ2630": ("77e2f5c9bf24cfe0c74b354d1fe0ee559d2fc130e7fb62b1b32951298be5a3b5", 405261, 4340, 4432),
}


def read_pinned(path: Path, digest: str, maximum: int) -> bytes:
    with path.open("rb") as stream:
        raw = stream.read(maximum + 1)
    assert len(raw) <= maximum and hashlib.sha256(raw).hexdigest() == digest
    return raw


def emit(label: str, value: object) -> None:
    print(label, json.dumps(value, sort_keys=True), flush=True)


def face_keys(positions: np.ndarray, faces: np.ndarray) -> set:
    # Exact coordinate sets, independent of vertex indexing and winding.
    return {tuple(sorted(map(tuple, triangle))) for triangle in positions[faces]}


def proper_segment_crossings(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Strict interior edge/triangle intersections in both directions.

    Determinant cutoff: 1e-10 mm^3. Barycentric and segment-fraction margin:
    1e-10 dimensionless. Coplanar, shared-edge and shared-vertex contacts are
    deliberately excluded. This is a diagnostic count, not a topology repair.
    """
    epsilon = 1e-10
    found = np.zeros(len(b), dtype=bool)
    for index in range(3):
        origin = a[index]
        direction = a[(index + 1) % 3] - origin
        e1, e2 = b[:, 1] - b[:, 0], b[:, 2] - b[:, 0]
        h = np.cross(np.broadcast_to(direction, e2.shape), e2)
        determinant = np.einsum("ij,ij->i", e1, h)
        valid = np.abs(determinant) > epsilon
        inverse = np.divide(1, determinant, out=np.zeros_like(determinant), where=valid)
        s = origin - b[:, 0]
        u = inverse * np.einsum("ij,ij->i", s, h)
        q = np.cross(s, e1)
        v = inverse * np.einsum("j,ij->i", direction, q)
        fraction = inverse * np.einsum("ij,ij->i", e2, q)
        found |= valid & (u > epsilon) & (v > epsilon) & (u + v < 1 - epsilon) & (fraction > epsilon) & (fraction < 1 - epsilon)
    for index in range(3):
        origin = b[:, index]
        direction = b[:, (index + 1) % 3] - origin
        e1, e2 = a[1] - a[0], a[2] - a[0]
        h = np.cross(direction, e2)
        determinant = np.einsum("j,ij->i", e1, h)
        valid = np.abs(determinant) > epsilon
        inverse = np.divide(1, determinant, out=np.zeros_like(determinant), where=valid)
        s = origin - a[0]
        u = inverse * np.einsum("ij,ij->i", s, h)
        q = np.cross(s, e1)
        v = inverse * np.einsum("ij,ij->i", direction, q)
        fraction = inverse * np.einsum("j,ij->i", e2, q)
        found |= valid & (u > epsilon) & (v > epsilon) & (u + v < 1 - epsilon) & (fraction > epsilon) & (fraction < 1 - epsilon)
    return found


def pair_stats(dataset: dict, left: str, right: str) -> dict:
    pa, fa = dataset[left]
    pb, fb = dataset[right]
    triangles_a, triangles_b = pa[fa], pb[fb]
    bmin, bmax = triangles_b.min(1), triangles_b.max(1)
    crossings = candidates = 0
    a_faces, b_faces = set(), set()
    for index, triangle in enumerate(triangles_a):
        possible = np.flatnonzero(np.all(bmax >= triangle.min(0), axis=1) & np.all(bmin <= triangle.max(0), axis=1))
        candidates += len(possible)
        if len(possible):
            hits = possible[proper_segment_crossings(triangle, triangles_b[possible])]
            crossings += len(hits)
            if len(hits):
                a_faces.add(index)
                b_faces.update(map(int, hits))
    return {
        "left": left, "right": right,
        "exact_shared_positions": len(set(map(tuple, pa)) & set(map(tuple, pb))),
        "exact_shared_triangle_coordinate_sets": len(face_keys(pa, fa) & face_keys(pb, fb)),
        "aabb_candidate_pairs": candidates, "strict_interior_crossing_pairs": crossings,
        "left_crossing_faces": len(a_faces), "right_crossing_faces": len(b_faces),
    }


def main() -> None:
    artifact = ATLAS / "artifacts" / MANIFEST
    manifest = json.loads(read_pinned(artifact / "manifest.json", MANIFEST, 475337))
    members = {member["element_id"]: member for member in manifest["members"]}
    asset = next(item for item in manifest["assets"] if item["asset_key"] == "pancreas")
    assert asset["sha256"] == GLB and asset["bytes"] == 517084
    assert asset["audit"]["element_ids"] == list(IDS)
    glb = read_pinned(artifact / "pancreas.glb", GLB, 517084)
    assert struct.unpack_from("<III", glb) == (0x46546C67, 2, len(glb))
    json_length, json_kind = struct.unpack_from("<II", glb, 12)
    assert json_kind == 0x4E4F534A
    document = json.loads(glb[20:20 + json_length])
    binary_length, binary_kind = struct.unpack_from("<II", glb, 20 + json_length)
    assert binary_kind == 0x004E4942 and 28 + json_length + binary_length == len(glb)
    binary = glb[28 + json_length:]
    assert document["nodes"] == [
        {"name": "bp3d-native", "children": [1, 2, 3, 4], "matrix": [0.001, 0, 0, 0, 0, 0, -0.001, 0, 0, 0.001, 0, 0, 0, 0, 0, 1]},
        *[{"name": "bp3d:" + element, "mesh": index} for index, element in enumerate(IDS)],
    ]

    def accessor(index: int) -> np.ndarray:
        entry = document["accessors"][index]
        view = document["bufferViews"][entry["bufferView"]]
        width = {"SCALAR": 1, "VEC3": 3}[entry["type"]]
        dtype = {5125: "<u4", 5126: "<f4"}[entry["componentType"]]
        assert "byteStride" not in view
        return np.frombuffer(binary, dtype=dtype, count=entry["count"] * width, offset=view.get("byteOffset", 0) + entry.get("byteOffset", 0)).reshape(entry["count"], width)

    archive = ATLAS / "sources" / (ARCHIVE + ".zip")
    digest, size = hashlib.sha256(), 0
    with archive.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            size += len(block)
            assert size <= 142903898
            digest.update(block)
    assert size == 142903898 and digest.hexdigest() == ARCHIVE
    native, converted = {}, {}
    with zipfile.ZipFile(archive) as zipped:
        for element in IDS:
            source_hash, byte_count, vertex_count, face_count = SOURCE_PINS[element]
            member = members[element]
            assert member["source_sha256"] == source_hash
            entry = "isa_BP3D_4.0_obj_99/" + element + ".obj"
            assert member["archive_member"] == entry and zipped.getinfo(entry).file_size == byte_count
            with zipped.open(entry) as stream:
                raw = stream.read(byte_count + 1)
            assert len(raw) == byte_count and hashlib.sha256(raw).hexdigest() == source_hash
            positions, faces = [], []
            for line in raw.decode("utf-8").splitlines():
                fields = line.split()
                if fields and fields[0] == "v":
                    positions.append([float(value) for value in fields[1:]])
                elif fields and fields[0] == "f":
                    faces.append([int(value.split("/")[0]) - 1 for value in fields[1:]])
            p, f = np.array(positions), np.array(faces)
            assert p.shape == (vertex_count, 3) and f.shape == (face_count, 3)
            mesh = next(item for item in document["meshes"] if item["extras"]["element_id"] == element)
            primitive = mesh["primitives"][0]
            gp = accessor(primitive["attributes"]["POSITION"]).astype(float)
            gf = accessor(primitive["indices"]).reshape(-1, 3)
            assert np.array_equal(gf, f)
            assert np.array_equal(gp, p.astype("f4").astype(float))
            native[element], converted[element] = (p, f), (gp, gf)
            emit("ARRAY_LINK", {"element": element, "vertices": len(p), "triangles": len(f), "positions_and_indices_exact": True})
    for name, bound in [(ISA, 2000000), (PARTOF, 651179)]:
        data = read_pinned(ATLAS / "sources" / (name + ".txt"), name, bound)
        rows = [row for row in data.decode().splitlines() if row.split("\t")[0] in {"FMA7198", "FMA10419", "FMA63120", "FMA63103"}]
        emit("SOURCE_MEMBERSHIP", {"sha256": name, "rows": rows})
    for left, right in itertools.combinations(IDS, 2):
        emit("NATIVE", pair_stats(native, left, right))
        emit("GLB_FLOAT32", pair_stats(converted, left, right))
    for left, right in [("FJ1895", "FJ2629"), ("FJ1896", "FJ2630")]:
        p, q = native[left][0], native[right][0]
        distances = []
        for chunk in np.array_split(p, 32):
            distances.extend(np.sqrt(np.min(np.sum((chunk[:, None, :] - q[None, :, :]) ** 2, axis=2), axis=1)))
        d = np.array(distances)
        emit("NEAREST_VERTEX_MM", {"left": left, "right": right, "n": len(d), "quantiles": np.quantile(d, [0, .25, .5, .75, .9, .95, 1]).tolist(), "le_0.001": int(sum(d <= .001)), "le_0.01": int(sum(d <= .01)), "le_0.1": int(sum(d <= .1))})
    # The separately found retained witness, evaluated through two point forms.
    pa, fa = native["FJ1895"]
    pb, fb = native["FJ2629"]
    a, b = pa[fa[28]], pb[fb[22]]
    origin, direction = a[1], a[2] - a[1]
    e1, e2 = b[1] - b[0], b[2] - b[0]
    h = np.cross(direction, e2)
    determinant = np.dot(e1, h)
    s, q = origin - b[0], np.cross(origin - b[0], e1)
    u, v, fraction = np.dot(s, h) / determinant, np.dot(direction, q) / determinant, np.dot(e2, q) / determinant
    normal = np.cross(e1, e2)
    normal /= np.linalg.norm(normal)
    point = origin + fraction * direction
    emit("STRICT_CROSSING_WITNESS", {"pancreas_face_zero_based": 28, "parenchyma_face_zero_based": 22, "pancreas_edge_zero_based": 1, "segment_fraction": float(fraction), "target_barycentric": [float(1 - u - v), float(u), float(v)], "signed_endpoint_plane_distance_mm": [float(np.dot(origin - b[0], normal)), float(np.dot(origin + direction - b[0], normal))], "intersection_mm": point.tolist(), "independent_parameterization_residual_mm": float(np.linalg.norm(point - (b[0] + u * e1 + v * e2)))})
    emit("BOUNDARY", "Read-only source/GLB arithmetic; no NORMAL comparison, conversion, GPU reproduction or biological execution.")


if __name__ == "__main__":
    main()
