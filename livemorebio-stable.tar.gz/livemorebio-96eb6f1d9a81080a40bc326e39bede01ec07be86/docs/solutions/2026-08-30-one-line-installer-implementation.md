# One-line private installer: implementation and lessons

Date: 2026-08-30
Status: implemented and clean-room verified on macOS; CI covers macOS and Linux

## User outcome

An authorized user can install or update LivemoreBio from the private GitHub repository
with one command. The bootstrap resolves `main` to one exact commit, downloads that
commit's installer through authenticated `gh api`, and executes the installer from a
completed temporary download.

The installer creates a release under
`~/.local/share/livemorebio/releases/<commit>/`, installs the fully resolved product
dependency graph from a hash-verified Python 3.11 lock,
runs the complete test, compile, and CLI gates, and switches the `current` symlink only
after all gates pass. It never starts services automatically or touches runtime state under
`~/.livemore/`.

## Decisions that matter

- The repository is private, so an unauthenticated raw `curl` URL is not an honest install
  path. GitHub CLI authorization supplies private access without placing a token in the
  command, process arguments, or shell history.
- The bootstrap and source archive are pinned to the same 40-character commit. A branch
  cannot move between downloading the installer and downloading the source.
- A virtual environment cannot be built in a temporary directory and then moved. Python
  console scripts contain an absolute interpreter shebang. Releases are therefore built at
  their immutable final path while inactive, and only the `current` pointer moves.
- `~/.local/bin/livemore` points to a stable, installer-owned launcher. The launcher invokes
  the active environment's Python module and avoids operating-system shebang-length limits
  for long installation paths.
- Installer-owned incomplete release paths are removed only while holding the install lock.
  An unrelated command, launcher, current link, symlinked managed directory, or
  non-normalized path is never overwritten.
- Dependency artifacts are exact-version and SHA-256 locked. The project itself is installed
  with dependency resolution and build isolation disabled, after locked build requirements
  are present.
- Repeat activation hashes every file in the release, including importable bytecode, and
  compares it with a digest stored outside the mutable release tree. A changed active release
  is refused rather than deleted in place.

## Clean-install defects found and resolved

1. `basico>=0.80` named an unrelated PyPI project. The intended COPASI distribution is
   `copasi-basico>=0.80`, whose import name remains `basico`.
2. `cobra` and `networkx` were present in the developer environment but absent from declared
   dependencies. A clean install could not collect six scientific tests. They are now direct
   declarations in `pyproject.toml`.
3. Two LIFE-to-Aegle transport tests accidentally depended on a token file in the developer's
   real home directory. They now set an explicit synthetic test token.
4. Concurrent Cendos evidence exports exposed a time-of-check race in local signing-key
   creation. If another worker published the key after the first open failed but before the
   existence check, the losing worker re-raised a stale `FileNotFoundError`. The loader now
   re-reads the published key, with a deterministic regression test.

## Verification evidence

- Installer contract: 41 subprocess tests covering the documented bootstrap, authentication,
  commit and dependency pinning, failure rollback, release integrity,
  locks, incomplete-release recovery, dependency/test/compile/CLI gates, conflicts, shell
  profiles, Python selection, and repeat installs.
- Shell: `bash -n install.sh` and `shellcheck -s bash install.sh` pass.
- Clean-room release gate: the hash-locked dependency graph installed in a new Python 3.11
  environment; 276 tests passed, 16 environment/network-gated tests skipped, 44 subtests passed; compile and both CLI
  checks passed.
- Repeat clean-room install reused the verified commit without rebuilding, repaired the
  activation links, and the installed `livemore --help` command succeeded.
- CI: the installer contract and complete release gate run on `ubuntu-latest` and
  `macos-latest`.

## Operational rule

When testing a Python installer, a mock-only test suite is insufficient. Always perform one
clean install with no inherited virtual environment and execute the installed console command
after activation. That is what revealed the undeclared dependencies, state-dependent test,
and absolute-shebang failure.
