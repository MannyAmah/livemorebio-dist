# Molecular viewer: remaining embedded-source notice inputs

2026-09-09, source_research. Source/terms evidence only. No redistribution,
viewer, build, physiological or experimental acceptance is granted here.
QkgKLS remains FAILED FILE_BOUND; FJiuBt remains FAILED ASSET_GRAPH, B NOT_RUN.
Neither consumed root, installed tree, package, shader nor control was edited.

**Result:** full original terms are retained and associated with the identified
remaining source families. CAS's intermediate Shadertoy grant remains unverified;
fastapprox's original BSD terms are known but its linked JavaScript gist has no
separate license statement. Those limits are not erased by Molstar's MIT label.
Actual NOTICE assembly, independent inspection and final emitted-output closure
remain gates, not completed work. No new shader or control removal is authorized.

## Exact evidence and method

New private root: `/private/tmp/livemore-molecular-embedded-notices.bdKPPj`.
Twenty-five retained original text/source files total196,693 bytes. Every read
was HTTPS, at most1MiB and30s per file, no automatic retry or redirect following;
total remained below32MiB. They were not executed. `sources.json` and
`additional-sources.json` contain each exact source URL. `evidence-index.json`
adds each original byte count/SHA256 and records its observed HTTP200.
This receipt indexes the retained successful originals, not every search/API
response in the transcript. API metadata was used to resolve stable paths and
license-file commits; it is not a signed source-build attestation.

The /browse instructions were read completely. Its prior startup failure and
root's authorized primary-HTTPS fallback remained in force: no browser repair,
package installation, author contact or third-party clinical query occurred.
No Context7/gbrain tools were callable in this session. Primary sources below,
not search-result summaries, establish the terms. The inherited approved plan
and prior312-line stats/closure diagnosis were the starting point.

`index-evidence.py` is a fixed data-only checker, not a package runner. With a
30s alarm and socket/subprocess/ctypes/fork/spawn/system refusals, it verified
the943 emitted Molstar source files against their exact regular archive members.
It followed inherited concatenated-module chunks in the retained QkgKLS stats.
The first exploratory path split found942 JS files; the corrected resource
parser also includes the CSS loader's source file, bringing the exact set to943.
No stats entries were omitted to make a check pass.

The old63-block count was a narrower copyright/license keyword observation,
not a complete source-origin census. For reproducible retention this index
also includes adaptation-only and generated-schema comments:86 selected blocks,
with full unnormalized bytes, source line, whole-file hash and block hash.
All86 selected bodies were read; these are not86 new licensing problems.
The broader regex is recorded and is not an exhaustive legal/source-origin
scanner. ColorBrewer's line-comment/palette evidence is in the independent
three-family report, not silently claimed as a block-regex hit.

Pins:

| Evidence | SHA256 |
|---|---|
|evidence-index.json|42b73df89c48e9116ef4e80b6e8e6bf64bd9a4aba110ad2dcdf1a5e010a4a97a|
|index-evidence.py|8072a7c67a3f96b1e597b4ad5bcad193eaa1f6959356eed2788a5693141d7ba3|
|sources.json|84b98341c2c59890ccb56d984437d29da24138387528254cee916f2cd0402d09|
|additional-sources.json|205c2d39229b4a26ed6d50f2e7d715422739c4056cb4ca8d6e0b1376961e3981|
|Molstar4.4.0 archive|d5c294fb5a87650c70a3012636b0060d60faca2e8542e3fd9a051df9678e06d5|
|QkgKLS/A stats|e783538f445d407393632567c9dd5c58254c9bc64bb87c562f47123cc1db4df2|

The check completed successfully under its alarm. No precise complete elapsed
time was retained, so no fabricated timing is supplied. Rerunning it requires
a new output path because its receipt is exclusive-create. Do not overwrite
this evidence. The complete original archive/source bytes remain unchanged.

## Finite family-to-notice map

Block indexes below are zero-based in evidence-index.json. Preserve Molstar's
own full MIT notice164 and every local adaptation/author credit in addition
to the corresponding original terms. A pinned license revision establishes
the inspected body, not an invented imported version where Molstar names none.

| Family / source blocks | Complete original retained / association |
|---|---|
|three.js:0–2,8–9,45–46,48; SMAA port11–16|three-r165.txt full MIT, same three.js authors. Retain each local2010–2018/2020/2021/2022/2023/2024 year statement; r165 is a terms witness, not a claim all adaptations came from r165.|
|WestLangley lines10|three-westlangley.txt full MIT at exact af28b2fb706ac109771ecad0a7447fad90ab3210 named in the installed header.|
|SMAA11–16|smaa-v2.8.txt complete source/binary conditions and disclaimer; exact v2.8 is declared by all six shader headers. Also retain three.js port attribution.|
|Dual-depth peeling3|webgl2-dpoit.html lines2–23 has full MIT naming BOTH Tarek Sherif and Shuai Shao2017, matching Molstar. The top-level webgl2examples.txt names only Tarek and is not sufficient alone.|
|Niagara specialization4,17|niagara.txt MIT, Arseny Kapoulkine2018; preserve Michael Mara/Morgan McGuire2013 algorithm citation and Molstar modification credits.|
|CIFTools5–6,18–19,21,33–34,37,40–41,85|ciftools.txt MIT David Sehnal2016. Local explicit project links match; generated dictionary descriptions28–32 are not a new claim of code copied from the old CIFTools repository.|
|MMTF18,20,23–24,27|mmtf.txt full MIT Alexander S. Rose2015–2016. Conservatively include msgpack-js-LICENSE.txt below for inherited decoding source, not just MMTF's top-level statement.|
|image-js/iobuffer22|iobuffer.txt full MIT Michaël Zasso2015, exact holder/project matching local conversion header.|
|netcdfjs25|netcdfjs.txt full MIT cheminfo2016. Original cheminfo-js repository redirects; explicit repository ID71766418 resolves to cheminfo/netcdfjs. License initial commit b9e3824f8bc6c18f8fff820234287355c6db6457.|
|DensityServer26|densityserver.txt original David Sehnal Apache-2.0 notice plus apache-2.0.txt complete terms. Not reclassified as MIT.|
|NGL35–36,38–39,44,53–58|ngl.txt full MIT Alexander S. Rose2014–2017; retain local Fred Ludlow, Alexander Rose and David Sehnal credits and stated port/adaptation context.|
|fastapprox42; paper citation43|fastapprox-COPYING.txt complete BSD3 Paul Mineiro2011; original header retains2011 and2012 notice variants. Linked JavaScript gist has no separate license statement; see explicit limit below. Retain the arctangent paper citation separately, not as a software license.|
|MolQL52,62–77|molql.txt full MIT MolQL contributors2017. Preserve David Sehnal, Koya Sakuma, Alexander Rose and Panagiotis Tourlas local modification credits.|
|Alipay slider60|Full original MIT body already embedded at slider.js106–129, index block60, copyright2015-present Alipay.com. No fabricated or substitute text is needed.|
|LiteMol59,61,81,83|litemol.txt original composite7950B, fully read. LiteMol's own section is Apache-2.0; pair with apache-2.0.txt. Retain adaptation statements. Its historical React/Immutable/Rx sections do not relabel the new bundle's different versions.|
|InternalFX78|distinct-colors.txt full ISC InternalFX Inc.2015. Preserve iWantHue inspiration citation; a citation alone is not proof of imported iWantHue code.|
|Fibonacci heap82|ts-fibonacci-heap.txt full MIT Daniel Imms2014 including original project URL.|
|Parsimmon84|parsimmon.txt full MIT J. Adkisson2011-present, matching local source credit.|
|gl-matrix47,49–51; chroma79–80; ColorBrewer lists|Independent peer source/terms report below; do not replace its full BSD/ColorBrewer-specific terms with a label.|
|CAS/RCAS7|fsr-v1.0.2.txt is AMD's complete MIT; fsr-v1.0.2-header.h is official RCAS source. Intermediate Shadertoy stXSWB grant is NOT authenticated.|

### Source-specific conditions that the minifier sidecar omits

SMAA's [original v2.8 terms](https://raw.githubusercontent.com/iryoku/smaa/v2.8/LICENSE.txt)
are not a generic MIT body. Preserve the complete source conditions and its
specific binary-use acknowledgment, including Tiago Sousa in that acknowledgment
even though the five leading copyright lines omit that name. Its full disclaimer
and no-official-policy representation text remain intact in the original.

The [dual-depth source](https://raw.githubusercontent.com/tsherif/webgl2examples/da1153a15ebc09bb13498e5f732ef2036507740c/oit-dual-depth-peeling.html)
also retains the Bavoil/Myers paper citation. Both software holders are named
in this file's complete MIT grant; no inference from Tarek-only root text is
needed. The source hash is eba9f164865c254fa44d2ed34bcf29f6fa587affac5913969a836cb9558dba33.

MMTF's [source decoding file](https://raw.githubusercontent.com/rcsb/mmtf-javascript/4710d805a1543a8016537481510175332e8ed582/src/msgpack-decode.js)
explicitly credits creationix/msgpack-js and Tim Caswell2013 inside decodeMsgpack.
The [complete original MIT body](https://raw.githubusercontent.com/creationix/msgpack-js/729ce49797f33f4eda6969c41c876d64ef5581a0/LICENSE)
is retained1098B/SHA965f55506b525f57576885307b4985dc4ad7de18206a85687d167257a4ee715c.
This conservative inherited notice is not a claim of an exact imported msgpack-js
version or that every old MMTF file is in the viewer.

The [LiteMol original](https://raw.githubusercontent.com/dsehnal/LiteMol/2410d16fd4990137a251159cb6a3bfe89f030731/LICENSE)
contains LiteMol Apache-2.0, three.js MIT, historical React/Immutable BSD3,
Rx Apache-2.0, zlib.js MIT and ColorPicker MIT. All sections were read and kept
as source evidence. The eventual attribution assembly must distinguish the
actual toast/cache/data-source adaptation from unrelated historical bundled
components. The [DensityServer notice](https://raw.githubusercontent.com/dsehnal/DensityServer/94ab4c06e0a18775604c54d0d7cfc14400a6b820/LICENSE)
and [full Apache terms](https://www.apache.org/licenses/LICENSE-2.0.txt) remain
separate. Include applicable change notices, source attributions and any
relevant upstream NOTICE evidence; do not use RxJS's appended copyright as if
it belonged to DensityServer or LiteMol. No blanket trademark endorsement.

The independent three-family report was read completely:
`2026-09-09-molecular-three-embedded-notices-review.md`, SHA
c3aa773d6488ad4f531afcf1e6b968510b6bfded943d001d87aef6973f4fbae7.
Its seven exact archive-matching source files, gl-matrix/chroma code witnesses,
35 exact ColorBrewer palettes and25-color concatenation are independent evidence.
Keep BOTH ColorBrewer root Apache and export/LICENSE conditions, including the
required acknowledgment, non-endorsement and derived-product-name restrictions.
The peer's private23-source inventory is retained at
`/private/tmp/livemore-molecular-three-notices.8ISHwt/source-reads.json`.

## Precisely retained unknowns and decision boundary

**CAS:** the complete installed cas.frag.js was read. Line10 directly names
[stXSWB](https://www.shadertoy.com/view/stXSWB); ftsXzM is only an alternative
sharpening reference inside the copied comment, not its stated direct source.
The copied comment says MIT, but does not name the intermediate author or
carry a complete grant. The primary page failed the web reader and direct
bounded HTTPS returned403. Other ports call the author goingdigital; those
third-party acknowledgments do not independently establish the original grant.
No credentials, API-key search, challenge bypass or author contact was attempted.

Its emitted source and callable path are real: draw.js60 constructs
AntialiasingPass; postprocessing.js760 constructs CasPass unconditionally;
cas.js16/80 imports and builds ShaderCode from this module. Rendering is gated
by antialiasing enabled and sharpening on (draw.js257/317;
postprocessing.js795–820). Default sharpening off is not exclusion from emitted
bytes, nor evidence that every interaction leaves it unused. Do not solve rights
by silently disabling a default, claiming tree-shaking, or dropping controls.

Official [FSR v1.0.2 RCAS](https://raw.githubusercontent.com/GPUOpen-Effects/FidelityFX-FSR/v1.0.2/ffx-fsr/ffx_fsr1.h)
has a complete AMD MIT grant and was read through the relevant constant/setup/
32-bit RCAS functions. It is a possible source for a separately reviewed
single-module build alias preserving the export/uniforms/pass/control contract.
It is NOT a behavior-identical replacement: official min/max uses all four
neighbors and center-aware limiters, whereas the retained port differs; its
reciprocal approximations also differ. No alias, rewrite, control removal,
GPU invocation or browser comparison is implemented/authorized by this report.

**fastapprox:** [Paul Mineiro's original COPYING](https://raw.githubusercontent.com/pmineiro/fastapprox/259f553d6f8463e4cb4ad5d0275bf2960ae98e41/fastapprox/COPYING)
has the full BSD3 conditions and matching2011 attribution; its big header
also retains2012 variants. The exact [linked JavaScript gist](https://gist.githubusercontent.com/imbcmdth/6338194/raw/f4b56f68a31e2f52bf6570c5b9616588d59ba1c6/fast_math.js)
is retained5527B and its source was read, but contains no separate license.
Molstar explicitly describes it as a port from BSD fastapprox. This supports
original-term/algorithm association, not an invented independent grant for
every intermediate port edit. Preserve that provenance limit for the release
decision; no new approximation implementation or scientific change is made.

Unknown upstream import commits for generic adaptations remain identified as
unknown. Pinned license-file revisions with matching project/holder/year are
notice-input evidence, not release labels or whole-library equivalence proofs.
The generated dictionary descriptions and mathematical citations are retained,
not treated as new software licenses. This bounded scan is not an exhaustive
copyright/patent opinion on every algorithm, dictionary or inline asset.

## Proposed assembly and next gate, not implementation

Use the actual admitted future module set, the prior59-package/full-notice map,
these original family terms, local modification statements and the peer's
special notices. Keep full human-readable permission/disclaimer text rather
than the971B minifier comments; no whole node_modules redistribution. Retain
SMAA/ColorBrewer required acknowledgments where end users can access them.
Current tr46/undici-types/Acorn/Scarf/fsevents/h264/old-viewer exclusions are
membership observations about QkgKLS A, not a universal package clearance.

Root must decide the explicit CAS/fastapprox provenance limits before public
vendoring. Then inspect actual NOTICE assembly and freshly accepted output
membership; successful private compilation alone does not settle those gates.
No further broad research, install or build is requested here.

Lesson: preserve original source-specific terms and modification lineage;
the root package's license and generated comment sidecar are not substitutes.
An inaccessible intermediate source should be reported precisely, not converted
into either a fabricated permission or an indefinite unrelated research task.
