# Current-preview feedback correction

Status: proposed implementation increment under the approved R27/R48 recovery
plan. No redesign, physiological model or experiment change. The accepted
14-image banner run remains preserved as its original result.

## Evidence and scope

Root inspected all original `y11aq6ff` browser captures. A compound-validation
message remains displayed while a later preview request is pending or uncertain.
The cardiac headings also say “reacting live”, “engine” and “one beat, live” even
when no numerical state exists. In `index.html`, `clearLegacyCurrent` clears the
state and numerical surfaces but not the banner; the three labels are static.
These are presentation defects, not evidence that a biological engine executed.

The approved product objective and six exact experiments are unchanged. This
increment does not make the legacy page the accepted A+B interface, does not
alter biological equations, replace any module, or qualify a result as human
equivalent. It removes stale feedback and makes this retained page's available
state legible while the separate Biology restoration continues.

## Written implementation plan and engineering boundaries

1. Keep the existing single accessible banner and normal-flow layout. Clear its
   previous message as part of `clearLegacyCurrent`, before a new owner publishes
   pending/current-selection feedback. Do not clear a newly published message
   asynchronously, steal focus, auto-repeat a request or touch History.
2. Give the three cardiac heading labels stable IDs and unavailable initial copy.
   Use a single small presentation function to publish `Numerical trace` /
   `computed` / `calculated beat` only when the current state has an admitted
   cardiac model and trace. Otherwise show no-current-trace copy. Pending
   numerical work is explicitly pending, not live. Read actual state shapes and
   tests before choosing the exact presence guard; no inferred engine identity
   from generic non-null state or measured-input provenance.
   Source inspection confirms the owner admits READY only with nonempty finite
   equal-length cardiac `t_ms`, `v` and `cai` arrays. The presentation guard will
   require READY and those arrays; it will not accept metabolic `measured` input
   as cardiac evidence. Copy is “Calculated response” / “computed” / “calculated
   beat · milliseconds”; busy is “Update pending” / “pending” / “update pending”.
   Unavailable or unconfirmed is “No current trace” / “unavailable”. It does not
   name a specific engine from the existence of arrays or claim wall-clock live
   physiology. This guard is presentation defense, not a new source-admission
   mechanism or scientific qualification.
3. Call that presentation function at existing clear/render/control-update
   boundaries. Existing owner tokens remain the authority; do not add a second
   owner or clock. No change to the numerical arrays, timing, audit, services,
   data stores or existing banner error messages.
   Independent pre-code review identified that numerical actions set busy but do
   not clear the existing state. Clear the previous banner on the false-to-true
   busy transition as well, once per action. Do not clear it on repeat busy calls
   or the true-to-false transition: those would erase newly published failures.
4. Add red-first mounted actual-handler regressions for ready-to-pending,
   unavailable, uncertain failure, successful refresh, render failure and
   preservation of a newly published failure message. Assert the same banner
   node, no extra POST, no focus theft and no stored-history change. Keep the
   original banner and recovery tests. Source-sensitive label tests must prove
   measured metabolic input cannot imply measured cardiac tissue or live data.
5. Independent review and offline preservation tests precede actual browser
   acceptance. Extend the existing bounded browser check only after separate
   review to capture pending/uncertain and ready labels and stale-message
   removal. No earlier screenshot or test count is repurposed as this change's
   actual-browser acceptance.

Alternatives considered: clearing all messages on every control update could
erase the current failure; changing only the copy leaves misleading source state;
replacing this whole page risks unrelated regressions. The narrow owner-boundary
correction is selected. A reviewer must check the small proposed change before
implementation; this document is not its own acceptance record.

## Completion and remaining scope

Completion here requires the red/green receipts, independent review and actual
browser captures for this correction. Full A+B visual acceptance, continuous
physical/virtual LIFE, deeper Biology, all R01–R51 and six experiment videos
remain open regardless of this result. No publication or installed-release
pointer change is authorized by this increment.

## Independent pre-code review

`ui_audit` read the plan and actual source, agreeing with the narrow guard/copy
and ownership approach. Its numerical-start finding above is included before
code. A mounted numerical-pending case is required in addition to preview
pending, and the later browser receipt must inspect banner plus label state.
This permits the written test-first implementation, not its acceptance.

## Preservation fixture amendment, before edit

The first expanded647-case preservation run completed646 passes and one failure
in34.64s (`jl01cyvs`, session1555, I/O0). The inherited isolated-render test
extracts `render` without its newly called presentation helper; it fails with
ReferenceError before checking the unavailable page. Mount the actual helper
source and its existing false busy initial state in that fixture, not a stub or
optional production call. Preserve every old no-draw/no-stale-state assertion
and add the three unavailable-label assertions. This is test seam maintenance,
not removal or weakening of the failing test.

## Maker implementation freeze and receipts

The small page delta is implemented: three stable unavailable headings, one
presentation helper called by render/control boundaries, clear on current-state
retirement and false-to-true busy only. No numerical, provenance, network,
selection-owner or stored-history values are modified by the helper. The actual
legacy owner, shared transport, styles/layout, and biological engines are
unchanged by this increment.

| Stage | Result | Private review suffix / session |
|---|---|---|
| First invocation used CJS-only wrapper for ESM tests |1 genuine markup failure,8 process-shape refusals; not8 product REDs |j6v3tvvr / completed directly |
| Correct existing CJS+ESM refusal wrapper, before page edit |9 failed,1.17s;8 Node children,I/O0 |d9g5ccat /82450 |
| Labels corrected, old banner behavior retained |4 failed,5 passed,1.17s; old pending/uncertain/render-failure feedback reproduced |jftycqoa /98512 |
| Owner-boundary banner clearing added |9 passed,1.14s;8 Node children,I/O0 |vlvq0wde /17034 |
| First full preservation |646 passed,1 isolated-render fixture error,34.64s |jl01cyvs /1555 |
| Actual helper mounted in original isolated-render fixture |647 passed,34.85s;198 Node children,I/O0,Git refusal1 |1d10z9q5 /61554 |

All commands used private review environments with plugin autoload and bytecode
disabled. The complete existing Exact632 command from
`2026-09-08-legacy-preview-client-recovery-implementation-review.md` was reused,
with the already approved sanitized environment and the banner test file added.
New RED selection was only the two banner/recovery files with `-k 'feedback or
headings'`. The45-second alarm and per-Node timeout were not increased. Authored
technical values and held requests did not execute a biological model.

Frozen SHA256 values:

| File | SHA256 |
|---|---|
|index.html|`224f600cef4d652989028fe8d499aa3271e9576222fbf4330e5eafd5b5f3f074`|
|test_legacy_banner_flow.py|`59e513e994920905b421944f00b1ba03e17bd2ba7bec8ab535cc2c8f222391a9`|
|test_legacy_preview_recovery_ui.py|`df8e41e91b0a8f3181053d8a216316c0e196af1ffd54a1803f8e53e215379ff7`|
|test_clinical_model_availability_ui.py|`f13b28814023dfe52d03b5d29fd8470b50712f580a840135e34071a9b013fa94`|

Independent implementation review and new actual browser acceptance remain
pending. Existing14 originals show the previous accepted banner layout and
original open findings; they are not captures of this new source. No six-program
video or all-page acceptance is claimed. The wider source-insensitive biological
copy and legacy replay behavior remain separate open findings.

Lesson: feedback has an owner just as numerical state does. Clearing on every
control update can erase the current failure, while clearing only on full state
retirement misses numerical starts that preserve the current trace. Test both
boundaries and their completion with the real handler, not a replacement model.

## Independent implementation review, ui_audit

Bounded source verdict: CLEAR for this implementation increment, not browser or
full-product acceptance. All four frozen hashes above matched. The reviewer read
the complete plan, three changed tests and actual owner/caller branches, then
compared the entire page and test delta to root's retained immutable wheel-source
snapshot (`/tmp/livemore-molecular-wheel.IKsy3D/source`). Its original index hash
is `16f39c7f5d5c20cacf8de066132a552baa993b0bd740ea44e94e4fb061a5ee94`.
No implementation or fixture edits were made during independent review.

The actual page delta is exactly the three headings, presentation helper and its
render/control calls, plus banner clearing in clearLegacyCurrent and only the
false-to-true busy transition. The helper requires READY and all three nonempty,
finite equal-length arrays. It does not mutate the arrays, infer a named engine
or treat measured metabolic provenance as cardiac observation. Completion does
not clear a newly shown error. The unchanged owner checks continue to prevent
old callbacks from publishing across a later request. No new focus or request
operation was added. All inherited assertions remain, including the isolated
unavailable renderer now mounting the actual presentation helper.

Independent focused repeat: **16 passed in1.64s**, exit0, private review suffix
`pb66g5ln`, exec session82309. Refusals:13 exact Node children, external I/O0,
Git0. This uses the report's cited Exact632 CJS+ESM45s refusal wrapper and approved
sanitized environment, changing only the pytest selection to:

- all7 `test_legacy_banner_flow.py` cases;
- the8 `test_actual_legacy_controller_integrates_owner_and_clears_real_nodes`
  parameters named `feedback_preview_pending`, `feedback_unknown`,
  `feedback_refresh`, `feedback_modeless`, `feedback_numerical_pending`,
  `feedback_numerical_failure`, `feedback_render_failure`, `feedback_source`;
- `test_legacy_unavailable_clears_old_readouts_instead_of_catching_a_null_render_error`.

This independently repeats all9 new cases, the6 original banner cases and the
one migrated actual-render fixture. Root's647-case preservation remains its
separate receipt; the independent16 are not described as a647-case rerun. The
review checklist was applied to ownership, typed guards, conditional side
effects and assertion preservation. No hosted PR/network/CLI review, model,
service, browser or operational store was accessed.

## Proposed minimal existing-browser extension, not implemented

Use the existing `tools/check_legacy_preview_browser.py` / `.cjs` only. Keep the
same private modeless setup, actual auth/health/source/process gates, constructor
refusals, fixed four authored POST deliveries, one fresh GET per POST, two
viewport contexts, route allowlist and original seven D0–M2 cases. Keep original
14 image slots as an ordered subsequence, never overwrite their retained files.
No additional POST, numerical execution, new clinical fixture or browser runner.

Add a fixed metadata-only feedback reader to the current DOM/clearCheck seams,
not page-global clinical hooks. Read the three named headings and the existing
banner only. Record expected and observed fixed categories (computed, pending,
unavailable, OTHER), presence, exact fixed-copy/title/class checks, same banner
identity and empty/hidden checks where appropriate. Do not serialize arbitrary
page text, input, patient state or raw errors. Retain a row before asserting it.
Parent and browser receipt admission must both reject missing, duplicate,
out-of-order or false rows; merely having the images is not sufficient.

Fixed feedback checkpoints:

| Existing state | Required label mode | Required banner |
|---|---|---|
|desktop initial modeless/D0|unavailable|existing current info, not hidden|
|desktop held fresh-read/D1|pending|same node, empty and hidden|
|desktop later winner C/D1|computed|same node, empty and hidden|
|desktop unknown/D3|unavailable|same node, empty and hidden|
|mobile ready A/M1, before error action|computed|same node, empty and hidden|
|mobile unknown/M1|unavailable|same node, empty and hidden|
|mobile refreshed modeless/M2|unavailable|existing current info, not hidden|

Extend `clearCheck` with the appropriate expected label mode and hidden-banner
proof for its three current calls. It must not demand a hidden banner after a
confirmed modeless render, which intentionally publishes current information.
The pending read uses its existing2s hold; collect these flags in the existing
single evaluation, without adding a new hold, screenshot or timer in that window.

Add exactly two viewport screenshots: `desktop-cardiac` immediately after
`desktop-later-winner`, and `mobile-cardiac` after mobile refresh A and before
`mobile-error`. Both use already-present authored READY arrays; captions and
receipt remain AUTHORED UI ONLY, not computed biology or model acceptance.
Bring the real cardiac heading below the measured sticky navigation with a
deterministic scroll, without changing the DOM or CSS. Retain all three label
rectangles, viewport/scroll and visible hit checks; require nonzero finite
rectangles, full visibility and no navigation occlusion or horizontal overflow.
Use the existing image writer/failure capture and byte budget. If the actual
viewport cannot show the required headings, retain the failure for review rather
than hide fields, shrink text or relax visibility checks.

Only the image count changes14→16 in Python/CJS receipt admission;180s browser,
159s work,21s cleanup reservation,350s outer,10s actions,2s hold,256 requests,
four POSTs,4MiB per image and64MiB total evidence remain unchanged. No new wait
for transport completion or provider requests is introduced.

Before harness code, write red tests in a dedicated
`test_legacy_current_feedback_browser_harness.py`: actual serialized reader on
authored DOM, valid modes, malformed/missing labels and stale banner rejection;
mounted full runner retaining exactly seven feedback rows and16 images with
four POSTs; false feedback/occlusion failure retaining metadata and NOT_RUN;
parent rejection of missing/duplicate/tampered rows and unchanged original
image ordering/nonimage budgets. Extend existing test fixtures only for the new
explicit fields while preserving their old assertions. Then freeze for root
and independent review before any separately authorized single browser run.
