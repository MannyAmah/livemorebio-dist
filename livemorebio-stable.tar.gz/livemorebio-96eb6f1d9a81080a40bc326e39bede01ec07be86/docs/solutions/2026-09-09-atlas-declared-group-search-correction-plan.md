# Atlas search: declared group membership

2026-09-09. Plan and exact test inventory only. Root must approve tests and
separately release the recording/runtime hold before implementation. No browser,
service, model, geometry or acquisition work is included.

## Observed cause and smallest correction

The actual screenshot `/tmp/livemore-record-a-atlas-controls.png` shows `heart`
with zero results while nine layers are ready. This is not missing geometry:
the admitted declaration has489 elements, including83 exact heart constituents.
`atlas_reference.js:110–115` currently matches only member `name`, `element_id`
and `concept_id`. The group label/key `heart` and group FMA7088 are not member
fields. Read-only inspection found zero current literal matches for both, versus
one for FJ2417 and11 for `ventricle`. Backend status preserves the full manifest.

Change only `livemorebio/aegle/console/lib/atlas_reference.js`:

- In the existing `search()` filter, find each member's group through exact
  `group.element_ids.includes(member.element_id)`. Add only that group's
  `label_from_source`, `asset_key` and `fma` to the existing searchable text.
  Retain trim/lowercase substring matching. A missing optional text field adds
  no text; never stringify `undefined` or an object as a searchable alias.
- Clarify the placeholder to `Element or layer name, FJ or FMA ID`.

Use current validated `snapshot.manifest` on each search; no extra index/cache,
new public helper, inferred ontology traversal, synonym map or backend change.
The existing strict manifest validator requires every member to belong to one
of the nine exact groups. Missing or unknown groups remain rejected, not a new
partially admitted mode. A defensive absent lookup contributes no group terms.

`heart` and FMA7088 must report83 matches, showing the same first30 real members
in existing declaration order. Do not add a synthetic whole-heart result or
change member names, FJ/FMA identities, group PART-OF/IS-A text, result ordering,
30-option maximum, exact-node selection, loading-disabled options or controls.
Searching alone must not select a result, alter camera/section/layers, install
anything, mutate the manifest or change model/observation state.

Empty or whitespace-only input must keep the existing empty result list and
`Search the admitted reference; this is not a list of patient findings.` help.
The reported clear-input behavior is not established by the supplied nonempty
screenshot; retain it as an explicit regression/browser check, not an invented
second root cause. Do not change blank search into all489 results.

Source pins before any edit:

- Controller SHA256 `9f48618e7cfd86f687c23ad7736242725a5ecaeba1018c0d957dc011df80a2d8`.
- Declaration SHA256 `e2df5ada0b3a983c69d409ce9e18cbc4c1568208cea49fc23f40a847b6bc57ad`.

## Exact red-first packet:12 cases

After root approval add only
`livemorebio/tests/test_atlas_group_search_ui.py`. Reuse the existing
`test_atlas_view_status.controller`, `test_atlas_reference_ui.node` and source
declaration-backed `technical_manifest`. Register/search/select through actual
mounted production handlers, with the existing in-memory asset responses and
inert scene. Reuse the native-like select properties from selection-sync tests
locally; do not edit inherited fixtures or bypass manifest admission.

| # | Case and exact assertion |
|---|---|
|1|`heart`:83 matches, exact first30 IDs of the declared heart membership filtered in manifest member order; no other group IDs, no synthetic group option. Search alone preserves serialized manifest and complete scene view.|
|2|`FMA7088`: same exact83/first30 membership, existing refinement message.|
|3|`  HeArT  `: identical IDs/count, proving existing trim/case handling applies to the new terms.|
|4|Declared right-kidney key and source label: each resolves only its declared member; no alias or substring-based assignment of group membership.|
|5|Exact `FJ2417`: one exact existing element; choose via actual change handler and retain member name/concept/source digest and PART-OF FMA7088 source card; no group substituted as selection.|
|6|`ventricle`: preserve the existing11 exact member-name matches and their order, not all brain/heart members.|
|7|Unknown query: zero options/zero count, no inferred anatomy or change to existing scene selection/view.|
|8|Dispatch actual input after a populated search with empty then whitespace input: zero options and exact existing help, no selection/view change and no all-member listing.|
|9|Retry with only heart asset unavailable: group search still counts83 real matches/30 options, all30 disabled by unchanged readiness; no false loaded/selected claim.|
|10|Missing group in an authored manifest: actual strict validator rejects; no no-group search fallback can admit it.|
|11|Unknown group key in an authored manifest: actual strict validator rejects; no invented group-term expansion.|
|12|Mounted markup exposes the clarified placeholder and retains source-only label/results accessible name, input maxlength120 and existing30-cap behavior (case1).|

Expected new RED is group-label/FMA/normalization and placeholder behavior;
preservation cases may already pass. Report actual counts, not a promised RED
count. No fixture migration is expected. Any needed migration requires review.

Run only these12 initially under the existing private45-second Python/Node
refusal wrapper: plugin/cache off, Node eval/module-eval allowlist only, no
network/child/native/model work. Preserve original RED before runtime edits.
After the explicit source release and correction, bounded preservation is the
new file plus `test_atlas_selection_sync.py`, `test_atlas_view_status.py` and
`test_atlas_renderer_review.py`; no full suite, browser or actual asset install.
Record exact invocation, hashes and output for independent root review.

Root owns later browser acceptance after recording: type heart, verify83/first30,
select a real constituent and inspect its exact PART-OF card, clear via the
actual control and see help, then exact FJ lookup. Existing nine layer controls,
camera and source identity must remain intact. Until then claim offline search
correctness only, not a new geometry/scientific qualification.

Lesson: a source-correct literal element search can still fail an ordinary organ
query when the organ is represented by declared constituent membership. Search
the already admitted relationship without inventing geometry or anatomy.

## Approved test-only RED receipt

Root read the entire plan and approved these twelve tests with inert execution;
runtime remains held during video A until a separate explicit release. New test
file SHA256: `d42d78baea877aa29139ad68cf69237c0782bdff341509dcfb943840ee676253`.
No inherited test, fixture or refusal wrapper was changed.

Original RED: session44133, tool chunks `bc7423` / `683052`, private environment
suffix `1_73pebx`: **6 failed, 6 passed in2.03s**, Node12, unexpected I/O0, Git0.
The failures are heart, group FMA, normalized heart, kidney key/source label,
unloaded-heart membership and placeholder. Existing exact-FJ selection, literal
ventricle, unknown query, clear-input help and both malformed-group refusals pass.
Controller remains at the original `9f48618e…` hash. This is authored inert
evidence, not a browser result or a claim that the reported clear action passed.

Exact command from the worktree (the retained wrapper is hash-checked; only the
pytest target list is substituted in memory, without modifying its file):

```sh
PYTHONPATH=/Users/emman/Livemore/.worktrees/full-scope-recovery /tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
from pathlib import Path
from hashlib import sha256
path=Path('/private/tmp/livemore-legacy-claim-correction.3gKmj6/repeat-offline.py')
raw=path.read_bytes()
assert sha256(raw).hexdigest()=='26166de650a6e7b4bbe0b09a0268f800c6c75f5ae88ebd0dff335e393d46e57e'
source=raw.decode()
start=source.index("targets=['livemorebio/tests/test_legacy_claim_navigation_ui.py']")
end=source.index('try:\n    result=pytest.main',start)
source=source[:start]+"targets=['livemorebio/tests/test_atlas_group_search_ui.py']\n"+source[end:]
exec(compile(source,str(path),'exec'))
PY
```

## Released implementation and bounded maker GREEN

After video A stopped and closed (root receipt `c4587e`), root explicitly
released the runtime hold and approved the exact filter/placeholder correction.
Only those two sites in `atlas_reference.js` changed. No validator, backend,
declaration, scene, inherited fixture/test, model state or browser was changed.

Full original and corrected controller copies are retained in
`/private/tmp/livemore-atlas-group-search.vGgvXH/atlas_reference.before.js` and
`atlas_reference.after.js`. `diff -u` shows only the placeholder replacement and
the original one-line predicate expanded to the exact membership lookup plus
string-only declared group terms. No result/count/selection code changed.

- Before SHA256: `9f48618e7cfd86f687c23ad7736242725a5ecaeba1018c0d957dc011df80a2d8`.
- After SHA256: `7260d7c122009b4394fb518b13e02ed53085a156e660a694e17cb9b392e6e548`.
- Tests unchanged from RED: `d42d78baea877aa29139ad68cf69237c0782bdff341509dcfb943840ee676253`.

The exact approved four-file packet passed **48 cases in7.24s**: session35615,
chunks `32900f` / `92b221`, private suffix `l5__dsh5`, Node47, unexpected I/O0,
Git0. The twelve new cases are included, not separately double-counted. This is
maker evidence only. Root independently reviews/repeats and owns a fresh actual
Atlas search segment; historical video A and its original zero-result behavior
remain unchanged evidence.

Exact independent repeat from the worktree, same immutable refusal wrapper:

```sh
PYTHONPATH=/Users/emman/Livemore/.worktrees/full-scope-recovery /tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
from pathlib import Path
from hashlib import sha256
path=Path('/private/tmp/livemore-legacy-claim-correction.3gKmj6/repeat-offline.py')
raw=path.read_bytes()
assert sha256(raw).hexdigest()=='26166de650a6e7b4bbe0b09a0268f800c6c75f5ae88ebd0dff335e393d46e57e'
source=raw.decode()
start=source.index("targets=['livemorebio/tests/test_legacy_claim_navigation_ui.py']")
end=source.index('try:\n    result=pytest.main',start)
source=source[:start]+"targets=['livemorebio/tests/test_atlas_group_search_ui.py','livemorebio/tests/test_atlas_selection_sync.py','livemorebio/tests/test_atlas_view_status.py','livemorebio/tests/test_atlas_renderer_review.py']\n"+source[end:]
exec(compile(source,str(path),'exec'))
PY
```

## Independent root acceptance

Root read the full updated plan (read receipt `46988c`) and exact source diff
(`c9c31a`), then independently repeated the same bounded packet: **48 passed in
7.96s**, Node47, unexpected I/O0, receipt `0fda26`. This clears only the scoped
offline group-search implementation. Actual corrected search/clear/selection
browser acceptance is still pending at this checkpoint and remains root-owned.
The original actual zero-result observation and video A are preserved; this
test result does not qualify geometry, patient registration, scientific
programs or native model admission.
