# Pinned metabolic models and clean research workflows

Date: 2026-09-05. Status: approach approved by Emmanuel; independent specification
review completed before implementation (decisions below); additive implementation
and software release verification complete, with scientific/physical gates retained.
Branch: `codex/genome-models-clean-workflows`.
Preserved baseline: `19c1edaa2b15cc414d148e9fde49919b3653ab3f`, PR #5.

## Problem, outcome and constraints

External testers need a reproducibly installed, empty research product with working
Biology, healthy-first onboarding, manageable twin/cohort and experiment histories,
and an executable, auditable metabolic model. They must see what actually executes,
which assumptions are supplied, and which physiological functions are unavailable.
An installed model is not evidence of patient-specific or whole-human equivalence.

Preserve all prior worktrees, recordings, source, keys, experiments and user state.
Do not reset or migrate the running 8850 or 8860 deployments. Use new private stores
and ports for this candidate. Existing physical-measurement admission, no silent
calibration and unsupported-intervention gates remain mandatory.

Primary project prior art: Biological Model Change Contract; research validation
plan; review-stack isolation lesson; run-bound UI projections; strict JSON parity;
one-line installer plan/implementation. gbrain, context7, sequential-thinking and
Compound Engineering tools are unavailable. Use local durable lessons, primary
upstream documentation, explicit review matrices and independent reviewers instead.

## Investigated facts and premise challenge

- Biology `/api/biology` and seven anatomy assets return 200, but an undefined
  `PROTOCOL` variable in `overview()` throws every poll. Top-level graphics imports
  can independently block data rendering. Correct data must not depend on WebGL/CDN.
- Fifteen tests are skipped at module level. Only eight need a large model; five
  offline safety tests and two network reference tests should not share that gate.
- Legacy gene-bound scaling incorrectly disables OR-redundant reactions, assumes
  50% loss per allele and maps disease/lifestyle to substrate without evidence.
  Solver failures can become zero flux. Installing files must not reactivate this.
- Human-GEM v2.0.0 (commit `635f533152dc5f7290ce04d12700eaa882273c3e`) is
  CC-BY-4.0. The linked guide guarantees an older release. Source XML contains
  12,931 reactions, 8,461 metabolites, 2,848 genes and nine compartments. Private
  COBRApy/GLPK evaluation succeeded with explicit medium and objective. Initial
  controls gave about 0/2/31.5 ATP for closed/glucose-only/glucose-plus-oxygen.
  These are measured software outputs, not wet-lab or human observations.
- Official VMH Recon3DModel_301 at commit
  `967ff5113d4a3ad3fb65e7cf6aea82e63e76d914` executes technically but embeds
  CC-BY-NC-ND 4.0. BiGG also requires contact for commercial incorporation/use.
  Keep commercial execution/redistribution unavailable without separate rights.
- Cendos auto-opens latest results; subject lists silently cap at 200. Empty
  startup constructs an unregistered T2D profile marked active. Stored governed
  identity already restores on restart and must not be replaced with healthy data.
- PR #5 macOS and Ubuntu installer/full release checks passed. Baseline is clean.

The right goal is reproducible executable biology with explicit conditions and
falsifiable readouts, not making skipped tests green by restoring unsupported
shortcuts or by relabelling an optimization output as a real-person response.

## Alternatives and approved choice

1. Minimal: repair Biology and download files into legacy locations. Smaller diff,
   but leaves unsafe gene scaling, hidden tests, poor installation and history UX.
2. Additive pinned model service, preserving existing research workflows while
   fixing requested UI/startup/distribution gaps. Reuse stores, exports, auth,
   SDK and browser surfaces. This is the user's explicitly approved approach.
3. Rewrite all physiology around a GEM or deploy graph services as a new reaction
   engine. Rejected: stoichiometry does not supply kinetics or validated cross-scale
   coupling; replacing the product would violate preservation and add scope.

Hold the requested scope. The change touches more than eight files because it
crosses existing service/UI/distribution boundaries. Avoid a new general orchestration
framework; add only model asset management and explicit-condition execution.

## Architecture and biological contract

```text
official pinned model + annotations + licence
       -> bounded download -> SHA verification -> private versioned cache
                                      | missing/corrupt/restricted -> unavailable
                                      v
Cendos explicit medium/objective/complete knockout conditions
       -> strict validation -> isolated serialized COBRA/GLPK execution
       -> solver + mass-balance + bound + closed-medium checks
       -> immutable run (model/conditions/software/source digests)
             |-> Aegle Biology result projection (not active twin mutation)
             |-> CSV / notebook / terminal, same frozen results
             |-> directed reference-only annotation projection
             |-> Cendos evidence comparison, awaiting independent measurements
LIFE observations and active Aegle subject remain separate admitted evidence
```

Implement Human-GEM oxygen-limited ATP-capacity research protocol first. Explicit
glucose and oxygen uptake constraints have model flux units (mmol/gDW/hour where
the source convention applies). Close all unlisted uptake and substrate-producing
boundary reactions. Specify ATP-maintenance objective and direction. Include
closed-medium and no-glucose controls; never inherit the source's permissive default
medium or biomass objective. Report objective flux, actual glucose/oxygen uptake,
selected exchange fluxes, solver status and mass-balance/bound residuals. Report
nonunique solutions explicitly; a selected flux is not a unique biological prediction.

Allow exact stable gene IDs and complete GPR-aware knockouts only. Reject unknown
genes, partial activities, arbitrary drug-to-flux mappings, nonfinite bounds and
unbounded or infeasible results. This initial protocol is reference-network capacity,
not tissue-specific, person-specific, dynamic, dose-response or observed chemistry.
No elapsed biological-time animation for steady-state comparisons. Existing healthy,
T2D and other supported profiles remain separate reduced-model research contexts.

Pin XML and annotation/licence metadata by commit and SHA256, retain source URLs,
download time and software versions. No model files bundled without redistribution
rights. New installations can fetch Human-GEM using the supported CLI; failed model
downloads must not mark the product operational. Keep Recon discoverable with exact
licence/entitlement status and a lawful bring-your-own-file route only when rights
are independently reviewed in a future release. This slice has no Recon execution
override or permission checkbox; discovery and inspected-source metadata only.

Graph wiring is a deterministic, directed, versioned reference projection of model
reactions, metabolites, compartments, GPR and source annotations. KEGG/MalaCards
links remain references and obey existing access controls. Neo4j/TuringDB service
availability is reported honestly; no graph dependency in numeric execution, no new
unapproved services, no references automatically setting physiological coefficients.

## User flows and persistence

```text
Fresh install -> zero stored twins/cohorts/runs -> healthy reference preview
     -> Create/onboard twin -> explicit activate -> saved subject restored on restart
Existing install -> restore existing subject and records unchanged

Cendos open -> blank Preparation tab -> Run -> new immutable result
                            ^              |-> History (paged summaries)
                            |                     -> Recall exact result
                            +--- Prepare rerun <---|
                                    -> explicit Run -> new ID + parent-run lineage
```

- New experiment clears only the view, never historical files.
- Rerun restores original parameters and stable cohort IDs; changed/missing inputs
  are visible and require confirmation through the ordinary run action. Never
  overwrite a frozen result or silently execute on recall. Persist parent-run ID.
- Twin/cohort search and stable cursor pagination support all stored records,
  bounded page sizes, empty states, errors, active-subject visibility and keyboard
  operation. Do not scan or print PHI in diagnostics; search stays local.
- Healthy preview is unregistered reference initialization, not an enrolled person.
  Activating existing twins switches the same Aegle/LIFE/Cendos subject identity.
- Explain biological time as elapsed time from the specified protocol event T0;
  recorded replay is not wall-clock streaming. For paired experiments, baseline is
  the same individual and challenge without intervention, treated is with the
  specified intervention. Label individual versus cohort summary and missing data.
- Biology data loads independently of graphics, with visible retry and partial
  state if graphics fail; stale polling cannot overwrite a newly selected run.

## Review: architecture, errors, security, data and code

| Path | Failure and response | Required verification |
|---|---|---|
| model download | timeout, HTML, truncation, size/digest mismatch: typed failure, no publish | bounded HTTPS fetch; atomic private cache; interrupted/repeated install |
| model permission | Recon lacks commercial entitlement: unavailable with actionable explanation | no automatic fetch/activation/redistribution |
| model parse | wrong release/IDs or malformed SBML: reject before execution | fixed parser metadata and known-ID assertions |
| solver | missing GLPK, infeasible, unbounded, nonfinite: no numeric result represented as success | typed status; controls; perturbation tests |
| concurrent runs | mutable shared model contamination: serialize isolate/restore per solve | concurrent differing media, restoration after error |
| reference export | unsafe ID/label or directional loss: stable IDs, typed edges, parameterized output | injection strings and roundtrip direction |
| Biology | undefined state, HTTP error, unavailable graphics: visible data/error/retry | first load plus second poll; graphics/network rejection |
| history | malformed cursor, missing/corrupt run: safe 4xx/5xx and no silent fallback | auth, strict JSON, no-store, stable pagination |
| rerun | double click, changed/missing cohort: lock submission, explicit validation | new ID/parent, original bytes unchanged, no hidden execution |
| subject startup | empty versus stored subject, bad decryption: preview or exact restoration/fail closed | never reset storage; existing identity preserved |
| installer | stale PATH, dependency failure, partial release: retain old release | isolated full install, wheel assets, retry, CLI and browser |

Use existing authorization for every mutation and PHI-like read, owner-only stores,
strict JSON and PHI-safe errors. Download only fixed public URLs, not caller-controlled
SSRF targets. Runtime private paths/keys never enter Git, demo or logs. No new external
patient data transfer. Preserve default loopback binding; not a production PHI release.

Reuse ProtocolRunStore with explicit protocol dispatch instead of current PXR fallback;
reuse immutable notebook/CSV infrastructure and reference approval boundaries. Additive
history format, no destructive database migrations. Document unsupported legacy GEM
helpers rather than letting model availability silently reactivate them.

## Test review and execution map

```text
Asset CLI -> pinned manifest -> download/hash -> inspect -> execute
  [unit] bad IDs, digest, permissions, truncated data, unknown request
  [integration] actual Human-GEM parse, GLPK controls, conservation, GPR AND/OR
  [integration] concurrency, solver error, zero-medium, snapshot immutability
Cendos -> execution -> frozen run -> history -> recall -> prepare rerun
  [integration] auth/no-store, immutable bytes, dispatch, CSV and notebook checksum
  [E2E] visible status, actual results, history restored, rerun never overwrites
Subjects -> search/page -> activate -> restart
  [integration] >200 rows; exact stable cursors; empty/invalid/search bounds
  [E2E] active identity and healthy first-run preview
Biology -> load -> data cards -> optional graphics -> second poll
  [CRITICAL E2E regression] no PROTOCOL error; graph failure cannot blank data
External tester -> one-line pinned installation -> empty state -> create -> run
  [installation E2E] isolated stores/ports; use exact documented commands
```

Write failing regression tests before behavioral edits. Separate always-on safety
tests from model/network opt-ins. Run full suite with installed available model
assets, compileall, wheel packaging and independent code/browser review. Record
actual test counts and any remaining skips by reason; do not invent coverage.

## Performance, observability, rollout and rollback

Human-GEM parsing measured about 8 seconds and 1.3 GB peak RSS in initial evaluation.
Use one bounded serialized computation lane and explicit busy/loading response;
avoid a new model per request or blocking routine Biology polling. Bound conditions,
runtime, download size, graph projection and API response size. Publish model-ready
status separately from web-service health. Report solver/control results, version,
elapsed computation and safe failure category, never person values in logs.

```text
preserved commit -> new worktree -> private 8870/8871/8872 stack
 -> red/green tests -> real installed model -> independent reviews -> browser QA
 -> distinct oxygen-capacity experiment/video -> tested guide -> feature PR
rollback: stop candidate only -> launch retained candidate -> retain all histories
```

New installer source must be pinned to the new commit, not unmerged main. The repo
is private: testers require authorized GitHub access or an explicitly authorized
distribution artifact. Do not make it public. macOS/Linux are supported test targets;
Windows only if separately demonstrated. Install tests must not overwrite the user's
managed installation, shell config, old keys or runtime stores. Empty state means
new private data directory, not a delete-history command.

## UI and trajectory review

Preserve approved A+B body/atlas layout and green header. Default visible content is
one clear next action, selected identity and evidence class. Advanced model metadata
stays expandable. Cover loading/empty/error/success/partial states, accessible tabs,
focus and responsive list controls. Screenshots must show actual rendered changes.

12-month direction: measured, context-qualified cell/tissue/organ interfaces integrated
with physical LIFE Patch and Cendos. This build adds a reproducible molecular network
slice and usable first-run workflow, not universal body equivalence. Next-organ plan
will specify state/units, coupling, sources/tools, measurement channels, falsification
tests, independent data, release gates and physical software/hardware dependencies.

## Parallel implementation ownership

| Lane | Ownership | Dependency |
|---|---|---|
| A: source/models | new model-asset module/manifest, pinned model docs and asset tests | specification review |
| B: scientific backend | explicit GEM engine, Cendos protocol/history/export/evidence dispatch and tests | A's loader interface |
| C: UI | Biology repair, healthy/time copy, Cendos preparation/history, subjects pagination UI/tests | backend contracts |
| Root | healthy startup, subject pagination backend, Aegle proxy/CLI/installer/review runner, guide/roadmap/recording | lane contracts |

Each agent owns explicit files; shared routes are wired by root after interfaces
agree. Final independent review rotates ownership so makers do not grade themselves.

## Not in scope and remaining external gates

- Commercial Recon enablement without permission, or automatic licence acceptance.
- Arbitrary drugs/variants → flux → whole-body physiology; needs admitted quantitative
  mechanisms and independent validation, not more annotations.
- Deploying production Neo4j/TuringDB/PHI services or releasing human-use Patch hardware.
- All-organ implementation in this change; a detailed staged plan is requested instead.
- Real chemical reactions/clinical efficacy claims from the new computational protocol.
- Resetting existing user data, replacing prior videos, public distribution or merging main.

## Review status

Office-hours premise and alternatives completed; user selected additive approach.
CEO/engineering review evaluated architecture, errors, security, data interactions,
quality, tests, performance, observability, rollout, trajectory and UX above.
Independent specification review returned 8/10 with six clarifications, addressed
below. These refine the approved approach without expanding it. No implementation
code had been written at review time.

### Locked implementation decisions following independent review

1. New ID: `cendos.human-gem-oxygen-capacity.v1`. Each record has stable
   `condition_id`, canonical SHA256 of complete constraints, endpoint
   `atp_maintenance_capacity`, unit `mmol/gDW/h`, model SHA/release, solver metadata
   and `MODELED_STEADY_STATE` / `NOT_QUALIFIED`. It is not a roster of people. The
   existing member-based ResearchService measurement admission explicitly rejects
   this protocol pending a separately reviewed cell/assay context. ATP concentration
   cannot be compared to ATP flux. Exports and Biology dispatch explicitly by ID.
2. Fixed Human-GEM IDs: objective `MAR03964` maximize, glucose `MAR09034`, oxygen
   `MAR09048`. XML unit is `mmol_per_gDW_per_hr`. Only glucose/oxygen uptake allowed;
   all other uptake, including producing nonexchange boundaries, closed. Glucose
   bound 0–10 and oxygen bound 0–1000; no booleans/nonfinite/unknown fields. At most
   six requested conditions plus two negative controls, five exact complete gene
   knockouts. GLPK feasibility/optimality target 1e-7; S*v and bound residual <=1e-6,
   closed-medium ATP absolute <=1e-6. Initial expected ratios are characterization
   values, not a universal hardcoded biological law. Actual numerical diagnostics
   must pass. Selected exchange fluxes carry `fva_status: not_computed` and no invented
   confidence interval; bounded FVA can be added only within the same time budget.
3. One computation admission lock spans a complete execution, including controls.
   Busy requests receive a typed busy response without an unbounded queue. Use an
   owned subprocess for each full experiment, not each condition/member. Solver
   deadline <=10 seconds per optimization; hard subprocess deadline <=120 seconds.
   Lock remains held until the child is terminated/reaped. Parent server stays
   responsive; HTTP/SDK deadline exceeds the worker budget. Read-only metadata and
   graph projections do not reuse a concurrently mutable solver. Test restoration
   within condition contexts and no retained state across runs.
4. Recon3D remains completely unavailable for commercial execution in this release.
   Retain Human-GEM attribution/licence and specify that Livemore changes constraints
   in memory, not upstream files. No restricted XML is committed or distributed.
5. The documented full installer fetches/verifies Human-GEM by default. Explicit
   `LIVEMORE_INSTALL_MODELS=none` supports base-only installation and prints
   the capability limitation. Asset failure prevents claiming a successful full
   installation and does not replace the previous active release. Runtime health
   and model readiness are separate. The CLI provides explicit install/status/check
   commands, and all documentation tests use a fresh private data/model root.
6. Prepare-rerun is read-only and derives configuration/parent digest from the stored
   result. Executing a rerun validates the stored parent's protocol, model digest
   and cohort identities/versions. Exact sources must exist. Changed configurations
   must be labelled as new configurations, not silent reproductions. The new ID
   stores authoritative parent ID/hash, and originals remain byte-identical.

Independent specification concerns were resolved before implementation. Completed
implementation and actual release checks are recorded in
[the evidence report](../GENOME_MODEL_REVIEW_EVIDENCE.md); future biological and
physical qualification gates remain open.

### Release-verification refinements

The first literal published installation failed closed on two defects not exposed
by the original pre-publication pass: a transient concurrent SQLite journal unlink,
and an insecure-permission fixture affected by installer umask 077. Both received
red/green regression fixes and independent review. Test execution also wrote
technical audit data into the new operational store, so the installer verification
helper now isolates all mutable paths and credentials while retaining the verified
model cache. This refinement preserves the approved empty-install requirement;
it does not delete existing records or weaken activation gates. Actual published
fresh/repeat installation subsequently passed, followed by installed browser, SDK,
terminal and notebook checks. See the evidence report for counts and exact scope.
