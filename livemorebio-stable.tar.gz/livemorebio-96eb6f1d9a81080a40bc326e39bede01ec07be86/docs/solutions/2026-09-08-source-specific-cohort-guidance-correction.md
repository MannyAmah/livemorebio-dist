# Source-specific cohort guidance correction

Date: 2026-09-08. Parent: full-scope recovery R05/R15/R17/R18/R19 and the
source-linked healthy/context cohort plan. Status: independent pre-code review
accepted; bounded implementation authorized. This is a UI correction, not new physiology.

## Evidence and decision

Root's actual member/current-1 browser check and screenshot show an enrolled
real-human cohort form beside NHANES/DPP aggregate/reference-template guidance.
The source field and indication are generic, but the unchanged explanation is
wrong for that selection. Source inspection also shows capability refresh
dispatches the stratum change handler, which clears an entered real-human
indication even though the operator did not change source class.

Keep the existing two research/enrolled paths and separate descriptive public
records. Do not change generation, eligibility, API payload or activation gates.
Implement a small pure source/view-specific guidance helper in population_forms.js
and wire it into subjects.js with existing textContent assignments. Reference
mode describes aggregate anchors and unmeasured priors; enrolled mode describes
existing admitted, consented twins and model-specific experiment eligibility,
not source-row sampling or automatic full biological qualification.

Use a named source-help element in the cohort form. Capability-success guidance
must match the current source on both Twins and Cohorts. A loading/failed
capability request remains visible and creation stays disabled; changing the
source class must not hide the failure or bypass the existing server contract.
An unavailable healthy generator remains explicit in reference mode.

For cohort indication, clear the input only on an actual reference→real source
transition. Reference stratum changes continue to set their documented indication.
Capability refresh or source-class-preserving updates must retain typed enrolled
indication. Do not silently infer any disease/model from that label.

## Red-first and rendered acceptance

- Pure helper: both views/source classes, healthy-unavailable note only in
  reference guidance, unsupported source rejection, detached inputs unchanged.
- Mounted wiring: source help and success status update together; discovery
  failure stays visible and submit disabled when switching source; typed
  indication survives successful discovery refresh.
- Preserve existing cohort member paging, reference source constraints, blank
  person fields and clean Cendos history behavior. No test submits real-person
  data or creates a biological experiment to prove copy.
- Extend the existing member browser check with actual source changes, retained
  indication after retry and visible help assertions; run at a new stable source
  identity and inspect the resulting screenshots. A textual helper pass does
  not close full enrollment/healthy execution or any requested experiment.
- Independent review additionally requires switching source during an in-flight
  capability request, for both successful and failed settlement. Guidance uses
  the current source, failure/loading keeps submission disabled, and typed real
  indication survives same-source change events and discovery refresh.

## Scope and other retained findings

Root owns this narrow population_forms.js/subjects.js/cohorts.html patch and
dedicated tests/harness additions. No changes to backend cohorts, source records,
clinical parameters, LIFE commands, Atlas renderer, stored history or launcher.

The existing manual real-human form also assigns submission time to submitted
observation/source timestamps. That is a separate admission-quality defect,
not solved by these explanations; it requires explicit source-time and profile
intake review before claiming complete real-human onboarding. It is retained
under R17, alongside full-profile/domain imports and v3 physical pairing UI.

Lesson to retain: generic selectors are insufficient if explanations and refresh
handlers retain assumptions from the original single-disease workflow. Source
class drives both visible guidance and editing behavior; data eligibility remains
the independently enforced server responsibility.

## Independently reproduced operation/discovery overlap

The independent reviewer reproduced an existing overlap: record-operation busy
state saves the create button as disabled while capabilities are pending; a
successful discovery during the operation cannot enable it; ending the operation
restores the stale saved-disabled value permanently. This directly affects the
same form's loading/ready contract. The bounded correction is to recompute this
form's primary submit disabled state from the two actual authorities after busy
restoration: `operationBusy || population === null`. Other buttons retain their
existing restoration behavior. A failing controller regression must precede it,
including success and failure while busy. No admission or record API changes.

Evidence so far: pure/wiring red tests 2 failed/2 passed, then 22 scoped tests
passed; independent controller review identified the overlap above. The expanded
browser harness also now bounds capability-request start waits to 15 seconds
with phase-specific errors; a missing request cannot strand the browser check.

## Bounded acceptance

The independent reviewer retained production-controller tests in
`livemorebio/tests/test_population_guidance_controller.py`. The operation overlap
was red (1 failed/4 passed) before the correction. Independent recheck: 6 controller
tests passed, including failed discovery during an operation; 20 relevant tests
passed. Root separately ran 9 then-current controller/guidance tests successfully.

Actual browser acceptance `docs/screenshots/full-scope-recovery/member-current-2/`
passed on source `47ab6d26e0422eb98166af0fa81b5dd04589bda66148e0b8696592859a574d7a`.
All three service startup identities matched before/after. Source changes during
delayed successful and failed discovery, same-source events, retry, retained
indication, source-specific twin guidance, blank age/conditions/lifestyle/SLC22A1 fields, compact member
search and clean Cendos preparation/history checks passed without JavaScript
errors. No registry or experiment writes. Root read the complete JSON and inspected
all five screenshots. The separate 10,000-ID DOM workload is a technical selector
test, not an admitted cohort or biological experiment.

This closes only the named guidance/refresh/disabled-state defects. Full onboarding
(R16/R17), unknown clinical values and source timestamps, complete enrollment,
healthy physiological binding, all-page visual quality and requested experiment
recordings remain open. Narrow source selectors and small explanatory text still
need the full responsive usability review; no new broad readiness claim follows.
The smoking selector still defaults to `never`; the four blank-field checks do
not establish that all unknown clinical values are preserved. Independent review
read the full browser JSON/harness and all five images and accepted only this
bounded correction, requesting this evidence-wording clarification.
