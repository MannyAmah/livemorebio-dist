# Source-native Atlas renderer: implementation and review handoff

Date: 2026-09-08. Parent: `2026-09-08-atlas-reference-conversion-renderer-packet.md`, including root's lane C authorization. This is a maker implementation record, not independent rendered acceptance.

## What changed

The approved A+B workspace keeps its header, multiscale column, focus card,
recorded time controls, glucose/insulin plots, interventions, evidence drawer,
LIFE guidance and navigation. Only the former schematic SVG in the whole-person
panel is replaced by the dedicated BodyParts3D reference scene. It never calls
the dispersed Biology explorer, rescales/centers individual organs or borrows
clinical values to tint a surface. Biology remains the deeper coherent-context
organ/cell/molecular workspace.

Five small frontend modules separate the immutable manifest contract,
same-origin hash-bound requests, loader/source association, actual scene and
controller. The renderer uses the installed pinned Three/GLTFLoader/OrbitControls
package; no external dependency is fetched. Each admitted GLB already contains
the same native-millimeter to world-meter root transform. The new assembly is
identity. Search, selection, visibility, isolation, camera, sections and labels
alter view state only. A synchronous renderer submission of the skin precedes
at most two concurrent internal requests. No idle orbit or physiological motion
is invented. Hidden, disposed and superseded loads cannot append late geometry.

One important loader detail was tested against the real pinned loader, not only
a mock: Three removes `:` from runtime object names. The source association uses
the loader's node/mesh index map and retained original names/hash/ID, so a source
element remains selectable without guessing the sanitized name. A labeled tiny
technical source triangle exercises the real converter and loader; it is not
installed in the product or presented as human anatomy.

## Red states and preserved tests

- Fifteen initial UI contract/request/mount tests failed before their modules or
  mount existed. Seven additional loader-binding/skin-first queue tests failed
  before the loader module; the view-state test failed before the scene module.
- The approved SVG replacement intentionally broke two inherited tests that
  required `living-body` and hand-authored vascular SVG paths. Root approved
  changing only those expectations to the dedicated source mount/no scalar
  tint while retaining navigation, context, exact dose and timeline assertions.
- A preservation sweep then had 78 passes and one obsolete SVG patch-marker
  failure. Root authorized its narrow replacement: no hand-positioned patch on
  source anatomy; retain actual source-class/measurement-digest evidence and
  explicit LIFE setup guidance. All other stream/auth/context assertions remain.
- Mounted-controller tests cover absent source without hidden installation,
  exactly one explicit install despite double clicks, no automatic POST retry
  after response failure, disposal, hidden/visible request cancellation and
  same-manifest control-state restoration. A real pinned-loader test and a
  graphics-driver stand-in test verify native arrays and scene matrices remain
  unchanged through controls, and late parsed data is rejected. The driver
  stand-in is not WebGL or performance evidence.

## Current source boundary and remaining gates

The reference panel states `REFERENCE ONLY`, adult male authored geometry,
not patient-registered physiology. Every source group reports pending/ready or
unavailable. Source declaration, archive/map hashes, license and historical
notice, loaded converter identity, axes and limitations remain inspectable.
No geometry is shown on missing source; failed graphics retain independent
numerical cards but cannot satisfy rendered acceptance. The explicit fixed
source install uses one bounded request with separate read-only status checks;
an uncertain response never triggers a second mutation.

R30 anatomical LIFE registration remains open: the prior SVG patch mark had no
admitted placement coordinates and was removed, not recreated on the new skin.
The actual Patch evidence drawer remains. Native source/run/member selection,
spatial fields, tissue/cell/molecular dynamics, additional body systems and
patient-specific registration remain active follow-on gates in the master
R01–R51 plan. This first reference scene does not close them.

Root separately performed the approved actual publisher installation; this UI
lane performed no publisher install, operational service restart or browser
acceptance. Independent current-build GPU/SwiftShader inspection must still
verify front/side/back landmarks, all controls, missing/partial/error recovery,
responsive/keyboard behavior, same-source retry and measured rendering budgets.
Screenshots and exact runtime identity belong to that independent receipt,
not a maker statement that unit tests prove a living human replica.

## Compounded lesson

Source-native data can be authentic while its presentation is scientifically
misleading. Preserve coordinate transforms and source identifiers all the way
through the graphics loader; keep model scalars separate unless an explicit
spatial contract exists. Updating old SVG-specific tests is legitimate only
when their underlying provenance, context and nonfabrication protections are
preserved with new behavioral coverage. Never retain an unsupported marker or
insert a string merely to make a stale test pass.

CE/gbrain tools were unavailable in the connected tool inventory; this local
solution record captures the lesson without claiming a tool invocation.
