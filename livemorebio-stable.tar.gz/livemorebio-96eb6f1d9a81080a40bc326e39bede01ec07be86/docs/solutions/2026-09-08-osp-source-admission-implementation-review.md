# OSP static source-admission implementation, review candidate

2026-09-08. **Maker packet frozen; independent implementation review pending.**
No pinned-source report invocation has occurred. No formula evaluation, native
worker, biological advance, source correction or product admission is included.
The original insulin Stage B benchmark remains **FAILED**.

## Authority and exact scope

This implements only the new static parser/test packet approved in
[the source-admission proposal](2026-09-08-osp-insulin-next-source-admission-proposal.md),
including its final section E. The reviewed proposal's current SHA256 is
`56d961d57dd3591abb9c11321bc8c8da5f147c2f0852834767661b7b2fcbac9d`.
The source XML was inspected read-only for grammar during implementation. It was
not passed to the new report generator. No old collector, recipe, numerical
analysis, input, output, runtime package or service file was edited.

| New file | Lines | Frozen SHA256 |
|---|---:|---|
| [Static tool](../../tools/osp_source_admission.py) | 631 | `cadf91942cedcb8dfb1154bcdfb6ee53826871b5d721368308e164aa061b8d27` |
| [Dedicated tests](../../livemorebio/tests/test_osp_source_admission.py) | 407 | `4648a7404e3772e7f70d323f87f64b3d7b22d498b9f9a34bb4f3bcdbd411ff3f` |

## Implemented contract

- Strict bounded UTF-8 XML grammar, exact namespace, typed direct definitions,
  raw source literals/flags/units, all three formula kinds, table points and
  explicit Table/Offset parameter links. It does not parse equation language or
  claim equation-symbol completeness beyond the declared XML references.
- Every declared nonbuiltin reference must resolve to an allowed definition
  kind, including references outside selected roots. The only builtin exception
  is exact `0/Time`, with unknown unit. Unknown constructs, malformed literals,
  duplicate identities/aliases and limit failures reject the whole report.
- Input-to-consumer graph includes conditions, assignments, replacement formulas,
  targets, initialization and ordinary RHS edges. Downstream records describe
  possible influence, not events that occurred.
- Each of the 27 independently pinned initializer pairs gets both its own
  downstream record and a reverse `upstream_initialization_dependencies` record.
  Only the section-E allowed edges enter the latter. Literal parameters/states
  and Time remain explicit leaves; incoming RHS and event writes are excluded.
- Iterative traversal retains cycles and every edge occurrence, deterministic
  predecessor witnesses, reached RHS/assignment targets, and reachable-set counts
  and hashes. No recursive all-path expansion is used.
- Fixed source/ledger/inventory/root-set checks and conditional exact-ID
  dimensional assertions are implemented but **not exercised against the pinned
  production XML in this packet**. These assertions are not a symbolic engine or
  new biological domain classifications.
- `PINNED_REPORT_APPROVED=False` remains on disk. Both `run_pinned` and its inner
  pinned report entry reject before source inspection while the gate is closed.
  There is no environment or CLI override. The separate technical entry labels
  small authored fixtures `AUTHORED_TECHNICAL_XML` and never gives model admission.
- Owner-private, new-only report directories use descriptor-relative creation,
  exclusive temporary files, synchronized atomic publication and checked path
  identity. Storage failure is not a successful returned report; a pending file
  is retained if evidence publication fails. No existing report is overwritten.

Every successful graph still has `model_admission=false` and
`EVENT_SEMANTICS_UNVERIFIED`, `TABLE_SEMANTICS_UNVERIFIED`,
`TIME_UNIT_UNVERIFIED`. A failed graph is not returned as partial COMPLETE.
Engineering bounds remain exactly those in the approved proposal.

## Red/green evidence

All runs used the existing isolated-store runner and managed Python, with no
network or native opt-in. The dedicated fixture refuses socket creation, DNS,
urllib access and subprocess launch before importing the new module. Only
authored technical XML/JSON and test-private output directories were used.

1. Initial RED: **80 setup errors in 0.68 s**, missing new module, before writing
   implementation. Private runner root ended `livemore-research-review-sz17djke`.
2. Initial GREEN: **80 passed in 0.15 s**.
3. Additional bounded regression packet: **6 failed, 84 passed in 0.23 s**.
   It exposed missing explicit assignment-target output, an unguarded inner
   report entry, malformed/duplicate technical-root handling and a replaced
   output-parent path. The other added tests strengthened reverse dependency,
   complete initializer-set and evidence-fsync checks.
4. Final GREEN: **90 passed in 0.15 s**. Runner root ended
   `livemore-research-review-r6_xxjxr`. No test or worker remains running.

Exact final command, from the feature worktree:

```text
/Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B tools/run_review_tests.py -q -p no:cacheprovider livemorebio/tests/test_osp_source_admission.py --tb=short
```

Testing is paused for the separately coordinated Atlas capture window. Do not
start even the static pinned report until root completes the independent review
and separately authorizes its exact invocation. Tests passing is not that review.

## Preservation and remaining gates

The final test and read-only SHA check retain these original bytes:

| Preserved artifact | SHA256 |
|---|---|
| `tools/osp_stage_b.py` | `a1bb8ac68aa746066f6ecdf9b45e27f77384465c1a114bc250eea96f35e1e0cc` |
| `tools/osp_stage_b_native.R` | `6a16df63980de72b06c39b21b200de10a7bd04f54405a06c7bf5512a64dc1f37` |
| `tools/osp_stage_b_analysis.py` | `baa13b3c8dac922c4e87896af2bce9d9892072ddd5a62249a774a021ebafab15` |
| Original numerical preregistration | `91fe2f3d517878eecb1014023ac414287a8ff0c4dca9b6490f57611db669806d` |

Independent grading must check the code and technical tests, then separately
verify actual source inventory, all roots, edge accounting, bounds and output
size when a pinned static invocation is authorized. Event/table semantics and
source-unit conventions still require source evidence. No source-supported
receptor-pool repair or new case2 insulin result is admitted by this work.

R33 exogenous insulin remains required alongside erinacine A, sterubin, carnosic
acid, arctigenin and cyanidin 3-glucoside. None becomes a qualified whole-person
experiment through this diagnostic packet.

**Retained lesson:** a forward influence path and an upstream initialization law
are different claims. Keep both directions explicit, and never turn possible
event writes into an initialization equation merely to complete a graph.

## Root independent implementation review and one static invocation

Root read all 631 implementation lines, all 407 dedicated test lines, this maker
packet, and the complete final proposal contract. The two frozen source hashes
above remain the reviewed versions. Root independently ran the 90 authored
technical tests: **90 passed in 0.15 s**, using
`/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python` and the isolated-store runner;
the private test root ended `livemore-research-review-3rpctz_3`. The dedicated
fixture refuses socket creation/DNS, urllib and native subprocess work before
module import. No pinned XML was evaluated in that run. These are parser and
evidence-publication tests, not biological validation.

Root clears exactly one static invocation of the reviewed `run_pinned` entry:

- Source: `/tmp/livemore-osp-source.fmi3LG/GIM_Healthy.xml`, exact source hash and
  length already frozen above and in the proposal.
- Ledger directory:
  `/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-osp-stage-b-81u4w4wd/analysis-v1`;
  only the three exact I2/T2/C2 ledger hashes in the implementation are read.
- New owner-private output parent allocated by `mkdtemp`, no existing result
  directory, source or numerical result writes.
- The private caller verifies implementation/test hashes, refuses network and
  subprocess entry points, then opens only the process-local static gate. The
  on-disk gate remains false. No source expression/native evaluator is imported.
- Fixed implementation budgets are unchanged. A 60-second process alarm bounds
  this static-only invocation; failure is retained rather than retried to pass.
  A normal report is independently checked for exact inventory, edge accounting,
  all root roles, deterministic digests and non-admitting semantic flags.

This is an independent review of a different maker's code, not self-grading.
The original numerical FAILED result remains FAILED, even if the declared-XML
graph is complete. Native model admission and all six experiment/video gates
remain open.
