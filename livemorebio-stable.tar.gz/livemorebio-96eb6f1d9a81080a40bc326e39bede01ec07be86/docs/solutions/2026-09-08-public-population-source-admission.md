# Joint public population source admission

Date: 2026-09-08. Approved parent plan:
[source-linked healthy and context cohorts](2026-09-08-source-linked-healthy-and-context-cohorts-plan.md).

## Scope and release boundary

This packet admits a fixed public source package for statistical research and
normalizes same-participant measurements. It does not enroll patients, associate
physical devices, fit individual kinetics, enable an executable biological model,
or establish a disease-free population. Registry/API/UI integration and the named
12-parameter model-binding proposal remain separate approval gates.

`population_sources.py` freezes seven official NHANES August 2021-August 2023
XPORT files and their seven codebooks. Each artifact has an exact byte count,
SHA-256, URL and expected table schema/row count. Import and status do not download.
`install_source` is explicit, requires statistical-research use acceptance, and
publishes an owner-private directory only after every artifact is verified.
Incomplete acquisition does not replace a previously admitted package. A changed
package is rejected, not repaired by overwriting it.

Public status exposes source metadata/counts only. Verified bytes are an internal
local input. Public source identifiers are not person identifiers. Participant
linkage values are used in memory only for the same-release join and then replaced
with keyed HMAC fingerprints; the key and original linkage values are not returned.

## Exact measurement interpretation

| Source fields | Normalized interpretation | Important boundary |
| --- | --- | --- |
| DEMO: RIDAGEYR, RIAGENDR, RIDEXPRG, RIDEXMON | Released age, reported sex, pregnancy status, coarse exam period | Age 80 is topcoded. Unreleased pregnancy status is never negative. No exact collection timestamp is manufactured. |
| BMX: BMXWT, BMXHT, BMXBMI, BMIWT, BMIHT | Weight, height, BMI and original measurement-comment codes | Clothing/appliance and positioning comments remain attached; no claim of device QC or unqualified “normal” measurements. |
| GLU: LBXGLU, WTSAF2YR | Fasting glucose in mg/dL and its fasting subsample weight | Zero/missing fasting weight is ineligible even when a glucose value is present. |
| INS: LBXIN, LBDINLC, WTSAF2YR | Insulin in uU/mL with censoring and independent weight-agreement check | A below-detection source fill is retained only as a fill, never as an exact measured concentration. Missing comment code is not detectable status. |
| GHB: LBXGH, WTPH2YR | HbA1c percent and separate phlebotomy weight | The source-defined no-result zero becomes unavailable; fasting and phlebotomy weights are not conflated. |
| DIQ: DIQ010, DIQ160, DIQ050, DIQ070 | Released questionnaire answers with missing/skipped/refused/unknown states | Reported diabetes is not typed as type 1 or type 2. Skipped insulin questions are not negative insulin-use answers. |
| RXQ_RX: RXQ033, RXQ050 | Past-30-day prescription-use answer and count | This release does not supply names, doses or durations. The source question excludes prescription vitamins/minerals. |

Every normalized quantity retains its variable, file digest and codebook digest.
Definitions require joint complete cases, not independent marginal draws. Selection
is deterministic without replacement; requests above the eligible count fail.
Exclusion counts are explicitly nonexclusive and are not prevalence estimates.

The screened definition uses explicit negative diabetes/prediabetes/prescription
answers, glucose below 100 mg/dL and HbA1c below 5.7%, ages 20–79, and positive
required measurements/survey weights. The broader adult definition does not apply
the questionnaire or normal-glycemia restrictions and assigns no diabetes type.
Both remain research references. An optional requirement for a documented negative
pregnancy result excludes unreleased status, including men and ages outside the
public release range; that selection bias is explicit.

## Transport-zero review: exact representation, not biological clipping

Actual released INS_L bytes exposed a pandas 2.3.3 XPORT decoder issue: the 3,509
comment-code fields documented as zero decode to approximately 5.3976e-79. All
3,509 raw numeric fields are exactly eight zero bytes. No participant values or
linkage keys were printed during this aggregate verification.

The official [SAS TS-140 specification](https://support.sas.com/techsup/technote/ts140.pdf),
pages 20–21, initializes the IEEE output to zero and returns directly when both
IBM words are zero. The installed pandas vector converter omits that branch.
The specification download SHA-256 is
`c7c82e664651fdf7c74134b3536af2ba1c5c2834ca91ea427e886eea0b118ac3`.

Proposed correction for independent review: use the parser's verified field
offset/width and row boundaries to inspect the original bytes, and restore zero
only for an entirely zero numeric field. An equal-valued tiny nonzero IBM mantissa
and the SAS missing-value representation must remain untouched. There is no
epsilon threshold, clinical clipping or inference from a questionnaire code.

The root reviewed the complete decision and red fixture. An independent source
reviewer checked the current official SAS-hosted specification, the installed
pandas converter, the original field offsets, the 3,509 exact-zero field count,
and the red test without modifying data. The root approved only the exact-byte
correction and the required bounds/alignment regression tests.

Implementation validates all layouts and complete row coverage before modifying
any cell. It uses physical row positions, supports documented 2–8-byte numeric
widths, skips character fields, and rejects truncated/overlapping/reordered or
invalid-width metadata. Nineteen transport tests went red before the change and
green afterward, including an entry-point test proving the actual parser invokes
the correction. No source file bytes are rewritten.

## Actual source-only verification

The explicit installation fetched all 14 fixed official URLs into a new private
source-only cache and returned `verified`. No operational service, patient store,
cohort registry, or existing source package was modified. The source manifest
digest is `cf348215b48a5607a542d21cd4f7ad5b2b3572ab4902789559a7c9d47f4cdce1`.
Actual normalization retained 11,933 released demographic records with explicit
missingness. The definitions yield:

| Definition | Eligible joint records | With documented-negative pregnancy restriction |
| --- | ---: | ---: |
| Joint measured adult research reference | 2,637 | 486 |
| Screened normal-glycemia, prescription-free adult research reference | 384 | 135 |

These are complete-case source counts, not a weighted population estimate, and
not claims about executable biological coverage. The strict pregnancy filter's
large restriction illustrates why unknown status cannot silently become negative.

The source/core suite currently has 59 passing tests. Tests use authored numerical
fixtures, not copied participants. Real-source checks emitted only aggregate
counts, hashes, schema and metadata. Construction digests bind the normalized
member values as well as the selected fingerprints and definition; identical
identities alone do not imply identical normalized data.

Independent completed-code review then passed all 59 tests in 2.47 seconds,
reverified all 14 installed artifact digests, and independently reproduced all
four eligibility counts above. The reviewer confirmed 3,509 exact restored
insulin-comment zeros and 486 missing comments. Before/after hashes of every
source artifact were unchanged; no normalized rows were persisted or printed.
No actionable blocker was found in this bounded source/normalization core.
This acceptance does not extend to UI/API wiring, individualized biological
parameter identification, clinical admission, or any scientific release gate.

## Compounded lesson

A schema-valid, hash-correct scientific file is not sufficient evidence that a
general-purpose decoder preserved its values. Cross-check transport special cases
against the format specification and published aggregate frequencies before using
decoded fields in scientific eligibility or model initialization. Keep transport
correction, source missingness, and physiological interpretation as separate steps.
