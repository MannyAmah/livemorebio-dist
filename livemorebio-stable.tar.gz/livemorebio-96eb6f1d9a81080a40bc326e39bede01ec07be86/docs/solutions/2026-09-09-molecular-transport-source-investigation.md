# Molecular first-coordinate terminal: source-only investigation

2026-09-09, release_redteam. The investigate workflow's no-fix-without-cause rule
applies. Scope is the unchanged product reader/controller, consumed private page
and harness, and bounded read-only inspection of the installed Playwright event
mapping. No browser, native model, service, new dependency, source modification
or attempted reproduction was run. **Root cause remains unproved.**

Prior evidence is preserved in
`2026-09-09-molecular-unit-browser-independent-result.md`: kCPxWp is FAILED
despite all four interaction stages/11 images passing. First D0 coordinates
reported ERR_ABORTED at Node offset 3755.837334 ms; D1 began 11555.940167 ms,
first explicit page retirement 41949.869709 ms, final cleanup 45948.171542 ms.
Default-consumer release remains blocked by this transport failure.

## Exact reviewed source

| Source | Current SHA256 |
|---|---|
| product molecular_loader.js | `bf6e1845ce9f37458239ff42960dd44eed29c0d246c34f995a9b8a8d76d57c71` |
| product molecular_inspector.js | `9ec1baea5dbcc75baaba871e57059c633b643433ae880fe3c35c95c38dfdaef2` |
| private kCPxWp/check.cjs | `0024e5c455835e52d28973e7aa217a88bede81a1e7348c7b34f79a9e0963d225` |
| private kCPxWp/page.js | `481baf087e9bb49b248e7a1c1ef7f9d1404b61c831b0c6fdf9985622253c58b2` |

The complete files were read in the preceding independent grades; hashes were
rechecked (`a52f38`) and all cancellation, completion, event and serving paths
were retraced here. No changed byte is being assumed equivalent to an old one.

## What each layer establishes, and what it does not

**Fetch and body:** loader lines 108–139 use one GET with the operation's signal,
read every chunk until `done`, validate exact total, and return copied bytes.
`eof=true` is assigned only on `done`; the finally block calls cancel only when
EOF was not reached, then releaseLock. There is no response clone, second body
consumer or normal-success cancel in this product path. The digest/UTF-8 checks
follow at 155–162. READY in the unchanged controller follows this successful
read and the exact upstream source/model checks; it is not merely an HTTP-200
check. Thus this success path is incompatible with an ordinary thrown body
read, digest mismatch or early-body cancellation in that same operation.

However, the receipt contains no individual fetch-resolution/read/EOF/cancel/
releaseLock timestamps or signal event. Source logic and successful output are
not an observed network-stack trace. In particular, releaseLock is a separate
call after EOF, not a source call to cancel; no trace here establishes that it
caused ERR_ABORTED. Do not propose deleting it or changing the reader on suspicion.

**Operation and controller:** the fixed page passes no timeout override, so the
operation has 30 s. Its timer/deadline abort paths are loader 89/91. finish at
169 only sets finished and clears the timer; it does not abort. Explicit abort
is controller retire at 81, reached for close, replacement, invalidation,
disposal/pagehide, or error teardown. Initial D0 has no previous owner and the
page has no automatic second open or context switch. Its only open handler is
the user-action button callback. The frozen workflow first closes the inspector
in D1, long after the observed D0 terminal. A 30 s timeout is inconsistent with
the 3.756 s whole-browser offset and successfully completed initial open. No
actual abort event was captured, so this is control-flow exclusion, not a claim
that every possible browser-internal cancellation has been observed.

**HTTP fixture:** check.cjs 141–151 admits the exact local bodyless GET, accounts
the intended body length, waits for request end and invokes writeHead/res.end
with the original Buffer and exact Content-Length. Body data or failed route
admission sets a failing record; no such scalar failure exists in this result.
The server is only closed during owned cleanup, after the D0 terminal. But
accounting happens before res.end and is not a completion acknowledgment.
No request-aborted, response finish/close, socket error or terminal byte counters
are retained. Even a future server finish event must not be mislabeled as proof
that the browser accepted all bytes. The current READY/digest evidence provides
an independent application fact, not the missing server event trace.

**Routing/CSP:** the exact allowlist route continues unchanged requests; its
catch aborts and records REQUEST_DENIED. Neither that flag nor a CSP violation
is present. Same-origin connect is permitted by the fixed policy; no service
worker or remote source is enabled. Therefore an observed allowlist/CSP refusal
is not supported. The catch has no passive continue-completion record and the
boolean CSP ledger does not retain detailed browser blocked reasons, so avoid
claiming a network-stack mechanism was exhaustively excluded.

**Playwright terminal:** the checker labels ERR_ABORTED only when
`request.failure().errorText` is exactly `net::ERR_ABORTED`. It does not infer
that code from EOF, a page close, status, or elapsed time. The installed
Playwright 1.58.2 Chromium mapper subscribes to Network.loadingFailed; it stores
`event.errorText || event.blockedReason` and emits requestFailed. The public
client exposes the failure string, not the original canceled/blocked/CORS fields.
The current Node callback timestamp is reception time and stage, not the
original CDP event timestamp. A failed event is not itself an attribution to
AbortController, reader.cancel or the application's owner teardown.

Relevant installed primary-source paths under
`/Users/emman/.agents/skills/gstack/node_modules/playwright-core/` were read,
not imported or executed:

| File / relevant lines | Current SHA256 |
|---|---|
| lib/server/chromium/crNetworkManager.js:441–465,499–509 | `ad55830a87387450440a4b372ae6a93a6c91c089ccc1e72ffeb298662dddb744` |
| lib/server/frames.js:254–265 | `fa67e7a3755a79cf0e0ac96b6930987ec2bcc643f60735c6ec748066f7c3e16b` |
| lib/client/browserContext.js:183–202 | `6ea97975a148f6c5b8706d9525bf2a665494091558dc1497e96373c16537613b` |
| lib/client/network.js:175–181 | `385cd7a58fea3cf46d82533b7c041eee41c903cf9179a810da11f4953df4d9e3` |

The local protocol declarations at types/protocol.d.ts:11415–11462 explicitly
define loadingFailed requestId/timestamp/type/errorText and optional canceled,
blockedReason/corsErrorStatus, and loadingFinished encodedDataLength. These are
source/API facts at review time, not a new full runtime-closure attestation or
proof that a particular low-level event payload occurred in the failed run.

## Candidate classes, not claimed causes

The remaining source-supported boundary is between server completion, Chromium's
request/interception bookkeeping, and the application response-body lifecycle.
The retained evidence cannot choose among these classes. Normal user teardown,
the late measurement parser and a 30 s application timeout do not fit the
recorded early chronology. No documented dependency defect was established by
this investigation, and none is invented from the string ERR_ABORTED.

The earlier LygJpf D0 and later kCPxWp mobile coordinate requests finished with
the same current product reader/bundle and coordinate bytes. That argues against
a permanently forbidden URL or unusable source, but does not identify an
intermittent cause or prove reliable transport. The environments/request objects
were not identical experiments, and the later success cannot replace failure.

## Smallest proposed diagnostic, subject to new approval

Prefer a fresh **D0-only diagnostic** through the unchanged actual consumer and
the same fixed local fixture/routing, not another full 11-image acceptance run.
Keep one context/page, the original source hashes, request/byte/time/cleanup
bounds, and one explicitly authorized attempt. No product or installed adapter
change, response-body read/refetch, route bypass, retry, failure waiver or default
consumer release. Absence of failure would be a non-reproduction, not a fix.

Add only bounded passive evidence at the two presently missing boundaries:

1. Fixed first-coordinate server request/response end/finish/close records and
   completion flags, with Node-monotonic offsets and a local sequence ID. Keep
   res.end inputs, backpressure and close behavior unchanged; no body/log dumps.
2. An owned page's passive CDP network observer: allowlisted request identity,
   response status, loadingFinished length or loadingFailed canceled/error/
   blocked fields. Retain both raw protocol timestamp and Node receive offset,
   labeled as different clocks; do not subtract them as synchronized times.
   Preserve existing Playwright terminal records and source identity checks.

Use bounded enums/lengths and existing evidence limits, record only this public
local source, and detach/settle the observer with the owned page. Adding an error
listener must not silently convert a previously fatal failure into success.
No request interception policy or server response completion behavior should
change. Author tests for event correlation, absent/duplicate terminal, bounds,
cleanup and raw failure preservation before any actual diagnostic decision.

If these passive facts still cannot locate the boundary, a separately reviewed
same-promise, same-argument fetch/signal/body observer could be considered later.
Do not introduce that broader instrumentation in the first diagnostic by default,
and never tee, clone, refetch, preconsume or replace a body to obtain evidence.

This is a finite recommendation, not implementation or execution authorization.
Investigation status: source trace complete; cause unresolved; no fix performed.
Lesson: body EOF, server finish and browser request-failed are separate signals.
Capture their identity and chronology before assigning blame or changing code.
