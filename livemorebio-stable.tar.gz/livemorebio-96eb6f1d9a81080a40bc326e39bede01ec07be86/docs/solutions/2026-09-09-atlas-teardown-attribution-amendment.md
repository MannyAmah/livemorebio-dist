# Atlas retained teardown failure — attribution-only amendment

2026-09-09. Proposal only; root review precedes implementation or execution.
Read the complete retained-results review and current helper/skin runner,
reader, relevant authored harness tests, and installed local error-class source.
No test, browser, service, request, build, source import or native probe ran.

## Evidence and unchanged limits

The retained zpg7lltg run remains FAILED: diagnostic SHA `cf0ae732…`, supervisor
`5e7e7210…`. Three observation stages passed, the unchanged reader returned the
exact verified 4,901,056-byte buffer, both native observers recorded ERR_ABORTED,
and API cleanup was `CLEANUP_UNCONFIRMED`. Later absent processes/listeners do
not retrospectively confirm the four close promises or identify cancellation.

Current diagnostic is still `91cd052b2284d5e47c6196076b59750e29ff14d563109de7d2ec7b28ae39f7fa`.
Reader remains `7ad7c023571614635d196cc5b0638d195ae46b166ce4602be16eb87e4cf4b9bc`.
Its unconditional post-read `reader.cancel()` remains untouched and unattributed.
The helper at `tools/check_atlas_request_diagnostic.cjs:103–120` folds close
rejection, before-cancel failure and incomplete drain into one sticky outcome.
Its reverse order starts **CDP → page → context → browser concurrently**, without
awaiting a child before starting its parent. Preserve that exact scheduling.

Keep 90s observation, one combined 5s close/drain allowance, 5s evidence write,
and the existing 105s outer limit. No new timer per resource, retries, second
GET, serialized teardown, exception waiver, reader change, or larger ceiling.

## Smallest implementation seams

Only `tools/check_atlas_request_diagnostic.cjs` and additions to the existing
`test_atlas_request_diagnostic.py` / `test_atlas_skin_terminal_diagnostic.py`.
No Python supervisor, runtime reader, product, launcher, or remote-source change.

Extend the existing helper, not a new owner/framework:

- `createDiagnosticBudget(clock, beforeCancel, reverseClose, {attributeRoles:false}={})`.
  Existing three-argument/default callers keep their return values and behavior.
- In opt-in skin mode, `acquire(action, role)` / `own(resource, role)` use only
  `browser`, `context`, `page`, `cdp`. `mainSkin` supplies these at its four current
  acquisitions (including the existing `{value,close:()=>value.detach()}` wrapper).
  Validate/reserve a role before starting its acquisition; no duplicate launch.
  Preserve late-acquisition ownership and immediate close after cancellation.
- Instrument the existing `close(resource)` promise at actual invocation and
  settlement. Keep exactly-once close, existing `track`, reverse launch order,
  sticky rejection failure, and drain loop. Add no awaited diagnostic work.
- `finish()` still returns `SETTLED` or `CLEANUP_UNCONFIRMED`.
  New `teardownSnapshot()` returns a detached, fixed-size diagnostic record.
  Copy it once after `finish` into `evidence.teardown`; late settlement must still
  be observed/cleaned but cannot rewrite the already-retained snapshot.

Record schema `livemore.atlas-teardown-attribution.v1`, four fixed role rows:
`role`, `allocation` (`NOT_REQUESTED/PENDING/OWNED/REJECTED`),
`close` (`NOT_STARTED/PENDING/FULFILLED/REJECTED`), `started_ms`, `settled_ms`,
and `error_class` (`TARGET_CLOSED/OTHER/UNKNOWN`, null except rejection).
All timestamps are finite monotonic offsets from the existing budget start;
unknown timestamps remain null. A not-yet-requested role is not a missing close.
An allocation still pending at drain timeout differs explicitly from an owned
resource whose close remains pending. Keep pending counts bounded by real sets.

The aggregate includes `finish_started_ms`, `snapshot_ms`,
`drain` (`SETTLED/DEADLINE`), `pending_at_snapshot`, `attribution_complete`, and
the first fixed cleanup failure's role/phase. Allocation/close times may precede
`finish` because the observation alarm can already have called cancel. Do not
rebase those clocks or interpret UTC subtraction as measured cleanup duration.
Cap serialized attribution at 4KiB; invalid/missing attribution fails closed.

Use a closed error-shape classifier, not raw message matching: a guarded
constructor-name check for `TargetClosedError`, ordinary Error => OTHER,
non-error/throwing inspection => UNKNOWN. This is a diagnostic class label,
not a new cleanup exemption or an authenticated remote type claim. Installed
`playwright-core/lib/client/errors.js:36` defines `TargetClosedError extends Error`
without assigning `.name`; checking only `error.name` would mislabel this exact
class. No new dependency/import or private error text is needed. File SHA:
`13ec20bbf18461690043785515025bd3d3bfff8b51afcbf8c4e06dffbc014347`.

In the existing `mainSkin` finally only, retain `failure_before_cleanup` before
cleanup precedence can replace `primary_failure`. Record fixed non-resource
phases `freeze`, `listener_remove`, `collector_dispose`, `before_cancel` separately
from four resource roles (counts/status/class, no event names or protocol IDs).
Guard these existing calls so a failure remains fatal but does not skip owned
close attempts. Preserve their old position/order; the combined 5s drain starts
where `finish` currently starts it, not five extra seconds after each phase.
Keep final aggregate failure/CLI nonzero policy. Evidence-write rejection or
timeout must still fail; do not claim a failed write durably retained its own
new status. The outer supervisor's fixed failure receipt remains independent.

## RED-first evidence required

Reuse the current fake-clock helper tests and actual `mainSkin` RUNNER fixture;
do not replace them with a new scenario framework. Add:

1. All four fulfilled: exact CDP/page/context/browser invocation order and no
   child await before parent starts; detached finite timing snapshot, four roles.
2. Each role rejects, and each stays pending: all other closes still attempted;
   rejection versus 5s drain expiry distinct, no second 5s timer or duplicate close.
3. CDP rejects only after context/browser starts: retain that rejection and
   actual timing; never accept TargetClosedError as successful cleanup.
4. Late/never-returning acquisition, preflight with zero resources, duplicate
   role refused before acquisition, and repeated cancellation: ownership remains
   exact; NOT_REQUESTED differs from allocation PENDING and close PENDING.
5. Freeze/listener/collector/before-cancel failures: first earlier source failure
   preserved, fatal cleanup reported, every already-owned close still attempted.
6. Invalid clocks, unknown errors, private canary message/stack/IDs, oversized or
   incomplete attribution, late settlement after snapshot, and evidence-write
   rejection/5s timeout: no leak, mutable receipt, false PASS or waived failure.

Preserve the prior 241-case offline packet with its strict Node-only refusal
wrapper. Extend runner cases that already cover `detach-fails`, `detach-stall`,
`late-cdp`, `never-cdp`, freeze-before-close and fixed evidence-write timer.
Require independent source/test review and frozen hashes before any actual run.

This makes a *future* failure distinguishable as a particular close rejection,
pending close/allocation, or non-resource teardown failure. It cannot recover
the missing historical error or explain the already-observed stream cancellation.
The prior blank-page teardown-only discriminator remains a separate unapproved
proposal; this amendment requests no browser/probe or transport counterfactual.

## Root pre-code decision — 2026-09-09

Root read all 116 proposal lines, the actual original request reader, existing
budget helper and complete `mainSkin` path. Approve the narrow opt-in attribution
amendment and RED-first tests in the three listed files. Preserve default callers,
all original test assertions, original loader bytes, concurrent close order and
the single combined five-second drain. No browser/probe is authorized here.
Return the frozen delta and independent-repeat command before any actual run.
