# Beard native precision v2: proposed numerical preregistration

2026-09-08. **PROPOSAL ONLY. No implementation, compilation, initialization,
source-expression evaluation or native solve is authorized by this document.**
Root approved writing this new numerical protocol after reading the retained
failure and its diagnosis. Root and an independent reviewer must approve its
exact hash before implementation; a second code/runtime/driver review and
explicit once-only execution approval are separate gates.

## 1. Question and permanent v1 status

Question: does a prespecified increase in numerical precision, together with a
maximum-step challenge, settle every required output of this exact mitochondrial
source within the **unchanged v1 output gates**, with independent source checks,
repeatability and full-state restart intact?

The [v1 protocol](2026-09-08-beard-native-source-preregistration.md), SHA-256
`95351a1e380178725ab38731d8e9dc63b57ebd4a1ae507dad17d3884e28167e7`, and its
single failed attempt remain immutable evidence. Its B0/B1 comparison has 552
failed pairs, including `J_F1` at 724.5410 times its allowance. Nothing in v2
reclassifies v1 as passed. The
[retained-state diagnosis](2026-09-08-beard-output-convergence-diagnosis.md) explains
why passing state thresholds did not establish convergence of net fluxes.

No arctigenin intervention, oxygen sweep, parameter fit, participant/cohort,
virtual device, data transfer, biological stimulation or desired outcome enters
this matrix. The evidence class remains `MODELED_REFERENCE_MECHANISM`, with
numerical acceptance a separate status. This is not clinical qualification.

## 2. Fixed source, units and runtime

| Property | Required identity |
| --- | --- |
| Original source | PMR Beard 2005 commit `8ec69b34c31cd1cbb53580d1853841bb333de78e` |
| Original CellML SHA-256 | `4a4f931592df0e77a92c79447bf6d8947c7325f721a74b4d336d370abaaf3981` |
| Converted CellML 2 SHA-256 | `5b2ffa7a1e8bae8be173fc9e8e84cd88bdfc02efcfd00c28cf222b0af633a40c` |
| Generated C SHA-256 | `3af10f8a848e6077f6059186fc1b34a9895e89f9f9c47f80669001ccfbc9795a` |
| Generated header SHA-256 | `9cef032fa93c51f54a327d10ff3a625c0c7c881378f67edd65148a282e751d5e` |
| Generator | libCellML 0.7.0, existing exact package-file identity |
| Native runtime | SUNDIALS 7.8.0, ARM64, Apple clang 21.0.0, reviewed SDK and dylibs |
| Existing runtime-manifest digest | `775e5190a01bfbf0408efe1e1c76b5e502cd645fff65df6e28e212d7f0d025f2` |
| Model / generator / solver licenses | CC BY 3.0 / Apache 2.0 / BSD 3-Clause |

[Pinned PMR source](https://models.physiomeproject.org/workspace/beard_2005/@@rawfile/8ec69b34c31cd1cbb53580d1853841bb333de78e/beard_2005.cellml),
[curation and attribution](https://models.physiomeproject.org/exposure/959a4da5d8a0638f4b36adf5800f4fc0/beard_2005.cellml/view).
Retain original attribution, license, metadata and conversion record.

Re-admit 47 components, 339 declarations, 28 unit definitions, 65 equations,
226 equivalence edges, 66 literal initial values and 19 states. Require zero
analyser issues, including warnings, and only the existing allowed conversion
messages. All aliases must remain bound to their exact qualified-ID/native slot
and dimension. Preserve the custom cell, cytoplasm and mitochondria dimensions;
`molar_per_cyto` retains its actual source mitochondria factor. Reject uncovered
units, unresolved equivalences and all unpinned source variants.

Keep the PMR defaults, including `x_AK=0`, `W_x=0.651384`, `W_i=0.072376` and
capacitance `6.756756756756757e-6` in their original units. Keep external Pi,
ATP/ADP/AMP, Mg, pH, K, oxygen and redox totals exactly as in v1. Do not silently
substitute the paper's corrected parameter set. No source literal changes.

The existing v1 and two-state technical wrappers remain unchanged and locked.
Proposed implementation is isolated under new `tools/beard_precision_*` files
with dedicated tests and a new false-by-default review gate. It may reuse the
reviewed source/unit admission, original-MathML evaluator, analysis primitives
and process-ownership protections by exact hash. It must not mutate v1 matrices,
enable their flags at import, or accept arbitrary modes/parameters/paths. The
existing evaluator gate may be enabled only inside a later separately approved
one-off process, never through an environment variable or product route.

## 3. Initialization and complete observation contract

New `I2a` and `I2b` are distinct fresh native invocations for this candidate:

- `I2a` calls generated initialization/computed constants only. No rate callback.
  Compare all 19 states and 47 literal constants exactly to binary64 values of
  their original literal strings; compare all 12 computed constants to the
  independently evaluated original source under the unchanged expression gates.
- `I2b` is allowed only after I2a passes. Evaluate the t=0 rates and algebraics
  once, record that RHS call, and require all source/domain/conservation checks.
  No epsilon-time initialization or skipped inactive-branch semantics.

The 19 states in generated order remain:

| Qualified ID | Unit | Initial value |
| --- | --- | ---: |
| `dH_x_dt.H_x` | M | 6.30957344480193e-8 |
| `dPsi_dt.dPsi` | mV | 160 |
| `dPi_x_dt.Pi_x` | M | 0.001 |
| `dNADH_x_dt.NADH_x` | M | 0.0015 |
| `dQH2_dt.QH2` | M | 0.0008 |
| `dCred_dt.Cred` | M | 0.001 |
| `dO2_dt.O2` | M | 0.000026 |
| `dATP_mx_dt.ATP_mx` | M | 0 |
| `dADP_mx_dt.ADP_mx` | M | 0 |
| `dATP_x_dt.ATP_x` | M | 0 |
| `dMg_x_dt.Mg_x` | M | 0.005 |
| `dADP_x_dt.ADP_x` | M | 0.01 |
| `dATP_mi_dt.ATP_mi` | M | 0 |
| `dATP_i_dt.ATP_i` | M | 0 |
| `dADP_mi_dt.ADP_mi` | M | 0 |
| `dADP_i_dt.ADP_i` | M | 0 |
| `dAMP_i_dt.AMP_i` | M | 0 |
| `dPi_i_dt.Pi_i` | M | 0.001 |
| `dK_x_dt.K_x` | M | 0.14 |

This table is a review aid, not a replacement for exact source extraction. All
339 aliases, 47 literal constants, 12 computed constants and 34 algebraic slots
retain the full source map. Record 19 rates with their state units per second.
Do not double-count Mg-bound pools inside total ATP or ADP. Time is seconds.

## 4. Fixed seven-invocation matrix and candidate identity

Every branch is a fresh native process. No branch starts until the previous
owned process and any descendants are confirmed terminated/reaped. Run exactly
in this order, subject to the failure rules in Section 8:

| Order / branch | Requested outputs | RTOL | Scalar ATOL | hmax | Role |
| --- | --- | ---: | ---: | --- | --- |
| 1 / I2a | Initialization only | none | none | none | Initialization subgate |
| 2 / I2b | t=0 only | none | none | none | Source/RHS subgate |
| 3 / P2 | 0–300 s | 1e-11 | 1e-15 | default, no imposed maximum | Tighter precision reference |
| 4 / P3 | 0–300 s | 1e-12 | 1e-16 | default, no imposed maximum | Adjacent precision reference |
| 5 / H3 | 0–300 s | 1e-12 | 1e-16 | 0.01 s | **Prespecified candidate** |
| 6 / R3 | 0–300 s | 1e-12 | 1e-16 | 0.01 s | Independent repeat of H3 |
| 7 / K3 | 150–300 s | 1e-12 | 1e-16 | 0.01 s | Full-state restart of H3 |

All advances use CVODE BDF, serial vectors, dense linear solve, default Newton
iteration and binary64. Retain default order/initial/minimum-step behavior. Do
not introduce analytic Jacobians, new constraints, event handling or an alternate
solver in this increment. Exact scalar ATOL is applied numerically in each
state's own native unit, not interpreted as one physical unit or measurement
noise shared by M and mV. These new solver settings do not change any output
acceptance threshold and are not guaranteed to pass.

**H3 is the candidate before seeing results.** Do not pick P2, P3, a smoothed
trajectory or the closest-looking branch if H3 fails. R3 must repeat H3, and K3
must restart from H3, never from old B1 or whichever new run is most favorable.

Requested grids are exactly integer `index/10` seconds: 0…3000 for P2/P3/H3/R3
and 1500…3000 for K3, with no duplicates or missing values. Require the returned
output time to equal that binary64 requested time. Record states/rates/algebraics
using `%.17g`; include original constants and computed constants plus their hashes.
State/value map, constants and computed constants must remain unchanged except
for the evolved state values themselves.

## 5. Internal time, bounded-step challenge and restart

CVODE normal mode may return an interpolated requested-time state after stepping
past that time. `CVodeSetMaxStep` sets the maximum step; `CVodeGetCurrentTime`
and `CVodeGetLastStep` report current internal time and last accepted step. Use
their documented success return codes. This compares the joint integration and
interpolation procedure, not interpolation in isolation.
[Official CVODE 7.8 APIs](https://sundials.readthedocs.io/en/v7.8.0/cvode/Usage/index.html).

The old K1 internal terminal time was 581.3497381826858 s although its final
requested sample was 300 s. That was allowed by v1 and is not retrospectively
a failure. V2 does not reuse that trajectory as its restart candidate. H3, R3
and K3 all have hmax=0.01 s, including K3 immediately after initialization.

For all advance branches, record the exact setting and the success of each
configuration API call. After each successful output advance, record current
internal time, last accepted step, current total step count and last order,
with the requested time separately. Initial output has a clearly marked
`not_advanced` state; do not invent an initial last step/order.

For H3/R3/K3 require, at every advanced output:

- finite internal time, positive finite last step, valid BDF order 1…5 and
  nondecreasing step count/internal time;
- `internal_time >= requested_time - clock_slack`;
- `internal_time <= requested_time + 0.01 + clock_slack`;
- `last_step <= 0.01 + clock_slack`.

Here the fixed clock-only roundoff allowance is
`clock_slack = 32 * ulp(max(1, abs(requested_time), abs(internal_time)))` seconds.
It is not a biological/output tolerance. Preserve actual values, never clamp
them into the allowed interval. Terminal internal time must satisfy the same
bound relative to 300 s. This verifies configured behavior plus sampled last-step
diagnostics; it is not a claim to have logged every internal accepted step.
For P2/P3 retain the same diagnostics but impose no newly invented hmax bound.

K3 uses H3's exact sample at index1500. Freeze all 19 states by qualified ID,
the 47 constants, 12 computed constants, original source/units, full H3 input
manifest, H3 raw-output hash and index/time in the checkpoint digest. Use a
separately checkpoint-bound binary if required by the reviewed implementation.
Before its first RHS, validate every restored state and constant bit-for-bit
against this checkpoint. Generated initialization may be checked separately but
must not replace restored values. Recomputed constants must match exactly.
K3's first recorded sample equals the checkpoint states and observations;
subsequent outputs use the fixed comparison gates. No hidden prepace.

This is a fresh-solver state restart, not restoration of CVODE multistep history.
It tests sensitivity to a restart under the same bounded-step candidate method.

## 6. All cross-run acceptance and diagnostic comparisons

The following five **mandatory acceptance comparisons** cover complete expected
grids, all 19 states and all 34 algebraic quantities:

| Comparison | Grid | Purpose |
| --- | --- | --- |
| P2 ↔ P3 | indices0…3000 | Adjacent precision convergence |
| P3 ↔ H3 | indices0…3000 | Same precision, bounded-step sensitivity |
| P2 ↔ H3 | indices0…3000 | Candidate directly agrees with independent coarser method |
| R3 ↔ H3 | indices0…3000 | Candidate repeatability |
| K3 ↔ H3 | indices1500…3000 | Candidate state-restart agreement |

Every pair uses the unchanged v1 rule:
`abs(a-b) <= floor(unit, identity) + 1e-6 * max(abs(a), abs(b))`.

| Output kind | Absolute comparison floor |
| --- | ---: |
| H_x | 1e-12 M |
| Other concentrations, including algebraic complements | 1e-10 M |
| Potential | 1e-4 mV |
| Flux | 1e-9 mol/(s·L mitochondrial volume) |
| Free-energy algebraic output | 1e-8 kJ/mol |

No average/RMSE, last-time-point-only check, zero filtering, subset or intersection
may replace these maxima. Report all 159,053 pairs per full comparison and 79,553
pairs for restart, with all failure counts and per-identity maxima. Retain a full
failure ledger or an explicit bounded displayed subset backed by the full raw
arrays/counts; no truncated summary may masquerade as the full failure set.
Rates are retained and expression-checked, not assigned concentration units or
silently included under an invented cross-run tolerance.

Mandatory **diagnostic-only comparisons** are retained v1 B1 versus P2, P3 and
H3 on the full0…3000 grids, under the same formula. Verify old raw/source/code
identities before comparison. Their purpose is to show changes from the failed
precision regime, not to redefine old B1 as a ground truth or require a more
accurate new candidate to reproduce its errors. They are explicitly outside v2
pass aggregation. Report their maxima/counts even if inconvenient. Missing or
invalid old evidence is `DIAGNOSTIC_EVIDENCE_UNAVAILABLE`, not fabricated data;
the complete dossier cannot be accepted until this required diagnostic is resolved
without another v1 solve.

No monotonic improvement at each sample is required or claimed. Agreement among
these numerical methods is not proof of exact solution accuracy or physical
validation. An independently coded solver/author-data comparison remains open.

## 7. Unchanged source/domain/conservation gates

V1 Sections3 and5 are incorporated by their frozen hash with no relaxation:

- Exact literal state/constant initialization and all alias/unit bindings.
- Independent original-MathML computed-constant/algebraic/rate comparison at I2
  and every output, relative1e-10 and original per-unit absolute floors:
  H1e-14 M, other concentrations1e-12 M, potential1e-8 mV,
  flux1e-11 mol/(s·L mitochondrial volume), free energy1e-10 kJ/mol;
  corresponding state floor per second for rates; `l_water_per_l_mito`1e-12
  in that tagged unit. Unknown units fail. Literal constants require exactness.
- Finite native states, rates and algebraics at every RHS/output; active log,
  denominator, square-root and exponential domains unchanged. ANT's original
  lazy piecewise guard is preserved. No replacement of invalid factors by zero.
- Retain/count negative trial/output concentrations. Below H−1e-12 M or other
  concentration−1e-10 M fails. Smaller negatives remain explicit numerical
  uncertainty, never clipped. Strict nonnegative six redox partners at outputs
  remains required regardless of that general reporting band.
- Mg-bound versus total pool limits unchanged; all smaller violations flagged.
- Matrix ATP+ADP stays0.01 M and free Mg+bound ATP+bound ADP stays0.005 M,
  each within1e-10 M. Oxygen state exact0.000026 M and derivative zero.
- Redox complement sums within1e-12 M; correctly labeled algebraic identities,
  not independent empirical conservation. Open intermembrane nucleotide balance
  uses the source flux expression floor, not an invented closed-pool constraint.
- External ATP/ADP/AMP and all five intermembrane nucleotide states remain exact
  zero. Their states/rates must stay exactly zero under the source's proved
  invariant subspace. No seeding, activating AK, changing boundaries or claiming
  ATP export. No new steady-state criterion at300s.

All failures retain qualified identity, unit, time/clock, calculation stage,
raw-data hash and original error, including truncated-native-diagnostic cases.

## 8. Resource limits, fail-stop and no retry

Retain the reviewed source-worker limits unchanged:

| Resource | Bound and scope |
| --- | --- |
| Native wall deadline | 120 seconds per invocation, monotonic supervision |
| Native CPU | hard60 seconds per native process before generated calls |
| Native output/file bounds | 64 MiB per stdout/stderr/file; core files disabled |
| Native resident memory | 1 GiB sampled soft termination threshold, not hard isolation |
| RSS sampling | requested10ms; record actual gaps, peaks, overshoot, ownership and failures |
| Compilation | separate30second wall bound, reviewed fixed inputs; core disabled and64MiB file bound |
| CVODE work | 10,000 internal steps per output call, total generated RHS calls≤1,000,000 |

Compiler RSS and hard CPU are **not** claimed to be protected by the native
policy. The existing compiler launcher has wall/file/core protection but no
measured RSS guarantee; v1 compiler receipts had zero RSS samples. Record that
truthfully. Hmax0.01 implies at least approximately30,000 accepted steps over a
300s branch; this is not an upper bound or a prediction of actual work. The
existing per-output and total-call limits still apply and must not be raised if
the tighter study exhausts them. Do not force minimum steps or increase maximum
order to make the runtime fit.

Run sequentially in new private0700 task storage with0600 evidence files and
sanitized process environment, no PHI, operational cache, service mutation,
network, inherited preload variables or credentials. Verify compiler/library
graph membership before launch; use the reviewed held-waitable PID/start/image
and process-group protections. Sampling failure, identity mismatch or cleanup
uncertainty is a failure, not a fallback estimate. Cancellation/signals preserve
original outcome plus separate cleanup/evidence-persistence outcome.

Seven invocations permit at most840s of individually bounded native wall time
and at most210s of separately bounded compilation wall time if all are needed.
These sums do not claim a hard whole-driver wall/CPU/RSS limit: source admission,
finite bounded-array analysis and report persistence are separate. The new driver
must report its actual elapsed time; no background operation or detached retry.
Any additional whole-driver enforcement requires its own reviewed implementation,
not an unreviewed signal that could strand children in separate process groups.

Fail-stop rules are explicit:

1. Source/runtime/units/initialization/I2a/I2b failure: stop all later native work;
   mark remaining branches `BLOCKED_DEPENDENCY` with the original reason.
2. Domain/conservation/expression failure, native error, resource breach,
   cancellation, ownership/cleanup failure or incomplete native branch: terminate
   that invocation safely, then stop subsequent native work. Preserve partial
   arrays as diagnostics; they cannot enter acceptance comparisons as complete.
3. A cross-run numerical discrepancy between otherwise fully admitted branches
   does not alter their settings. The remaining **already prespecified** independent
   branches may complete so the bounded precision/step/restart experiment has
   interpretable evidence. The full matrix stays failed. This is not a retry.
4. K3 requires a fully source/domain/conservation-admitted H3 checkpoint at150s
   and complete H3 grid. It may run for diagnosis if an inter-branch comparison
   failed, but never when H3 itself is incomplete/invalid or has unresolved
   numerical-domain uncertainty. Otherwise K3 is `BLOCKED_DEPENDENCY`.
5. Output uncertainty without another local failure retains
   `NUMERICAL_PASS_WITH_UNCERTAINTY` locally, not an unqualified pass. It cannot
   produce an accepted v2 candidate. No rounding/zeroing to remove that status.
6. One execution authorization permits one invocation of this exact fixed
   matrix. No retry, fallback, additional point, parameter edit, revised threshold
   or switch to a successful branch after any outcome. A later attempt needs a
   new reviewed manifest and preserves every earlier failure.

## 9. Red-first implementation and independent acceptance

Before any native code is executed, write failing static/technical tests for:

- exact branch table, H3 candidate binding, repeat/checkpoint parent and fixed
  grid/units; reject injected mode/tolerance/hmax/checkpoint/source values;
- all five required acceptance comparisons and distinct historical diagnostics;
  missing/duplicate/extra identities/times, unbounded-step metadata and clocks;
- a fixture whose states pass but derived output fails; no zero-net exemption;
- exact full-state restoration and wrong-H3-parent rejection; constants/metadata
  cannot be replaced during generated initialization;
- configured hmax success, invalid/failed stats, clock-slack boundary behavior,
  separate output and internal time, and last-step diagnostics not misrepresented
  as a full native-step log;
- source/runtime changes, both locked-on-disk gate behavior, technical-wrapper
  two-state guard and altered-source bypass prevention;
- all failure statuses, cancellation, preserved resource/native diagnostic
  evidence, cleanup, source-expression context and no implicit retry.

The implementation review freezes new worker/parser/analysis/driver hashes and
all reused source/runtime/code hashes. Source equations and generated C must
remain identical. A separately reviewed private one-off driver verifies exact
loaded module paths/code/runtime/source/protocol hashes before enabling only its
two necessary gates in that process. False defaults remain on disk. Root must
read that complete driver and authorize its exact hash before any native call.

After authorized execution, an independent reviewer recomputes raw complete-grid
maxima/counts and checks source/initial/checkpoint/units/runtime/resource evidence.
Overall accepted numerical execution requires every branch local gate, all five
cross-run gates, required diagnostics, no output uncertainty and successful
cleanup. Otherwise record `FAILED`, `BLOCKED_DEPENDENCY`, `NOT_RUN` or explicit
uncertainty as applicable, with no aggregate success hiding the distinction.

Even numerical acceptance only admits this fixed reference implementation and
method. Published-source replication, corrected-paper variant, physical specimen
measurements, compound exposure/kinetics, person-specific applicability and human
functional equivalence remain separate gates. This document adds no product UI,
public API, sensor mapping or cohort binding.

## 10. Six-program continuity and current authority

Required programs remain exogenous insulin; Erinacine A/Lion's Mane LBHR-172;
Sterubin/Yerba Santa LBHR-129; Carnosic acid/Rosemary LBHR-062;
Arctigenin/Burdock LBHR-030; and C3G/Bilberry LBHR-135. This is one mitochondrial
mechanism dependency, not completion of any individualized program. Nothing
changes the failed insulin benchmark or the candidate-specific data/PK/tissue/
measurement requirements in the existing dependency packet.

**Current status:** written v2 proposal only. Independent scientific pre-code
review and root approval pending. No new native binary, source evaluation or
solve has been created or run. Protocol hash will be frozen outside the document
after approval, avoiding a self-referential digest. Any semantic change requires
another review before implementation or execution.

Lesson: declare the candidate before results, and test output convergence,
step-bound sensitivity, repeatability and restart separately. A tighter numerical
setting changes computational accuracy, not biological truth or qualification.
