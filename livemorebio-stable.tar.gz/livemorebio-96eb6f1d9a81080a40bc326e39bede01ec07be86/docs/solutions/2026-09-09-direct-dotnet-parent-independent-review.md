# Direct .NET parent: initial independent source review

2026-09-09. **NOT CLEARED for native execution.** This is a bounded source review
of the new parent, not the worker's native API or scientific qualification.
No native, SDK, process, browser, network or test invocation was made by this
reviewer. The maker was still adding tests while this review ran; final frozen
bytes require a separate regrade. No production code was edited.

Read the complete 161-line connection plan, full parent implementation and both
dedicated tests, plus the reused ownership/wait/sampling/admission primitives,
the worker terminal path and relevant pipe protocol. The review child separately
checked the finite test contracts. Findings were sent to root as discovered.

## 1. Post-reap process monitoring prevents successful admission

Priority P1, high confidence. `execute()` unconditionally invokes
`cleanup_drain()` after `Owned.cleanup()` returns. The real cleanup implementation
has already called `child.wait()` and reaped the leader before reporting SETTLED
(`osp_semantic_supervisor.py:570–574`). The forced monitor then enumerates an
empty group and calls `waitable_exit()` for the reaped PID. That helper requires
successful `waitid()` (`455–463`); a reaped child is no longer waitable. The
result becomes a cleanup evidence error, and `_admit_process()` refuses the
otherwise successful inspector/worker.

The authored executor fixture masks this: its fake cleanup sets returncode,
but the `waitable_exit` stub keeps returning true after that point. Minimal
correction: retain final stream draining, outer-worker monitoring, resource and
file checks, but do not inspect a process identity after its sole-waiter reap.
Add an inert fixture whose waitability ends exactly when its fake `wait()` runs.
Do not alter the original safe cleanup primitive or invoke an OS child to prove
this control-flow issue.

## 2. Earlier immutable case evidence is not checked at packet acceptance

Priority P1, high confidence. `Evidence.written` is verified within `run_case()`
and then discarded. Final `run_packet()` checks authorization, package pins,
once bytes, tree types and aggregate sizes, but not prior case artifact hashes
and identities. A later case or intervening same-user mutation can change an
earlier stream/observation/receipt while the final packet still reports PASS.
This contradicts the plan's immutable-evidence acceptance guarantee; it is not
a demand for a new filesystem sandbox.

Retain the bounded per-case verification records through final acceptance and
recheck them under the existing deadline/budgets. Add a mounted offline packet
fixture that changes an earlier case's bytes and another that changes identity
before final acceptance. Both must fail without starting a child. The existing
case-order test mocks `run_case` and cannot establish this property.

## 3. Successful COMPLETE accepts an impossible terminal phase

Priority P2, high confidence. `Wire.admit()` only checks the payload phase against
an uppercase regex; `finish()` requires success/disposal/counts but not
`phase == "DISPOSE"`. Four otherwise valid frames ending with successful
COMPLETE/CONSTRUCT therefore satisfy the current parent contract. The real
worker assigns DISPOSE only after FINAL acknowledgement and emits that phase on
success (`Worker.cs:245`). Require that exact phase for successful completion;
retain early failed COMPLETE behavior. One finite negative protocol fixture is
sufficient.

## 4. File replacement can block before identity/deadline checks

Priority P2, high confidence. `read_file()` uses lstat then
`os.open(O_RDONLY | O_NOFOLLOW)` without O_NONBLOCK. A regular-file-to-FIFO
replacement between the two can block inside open before descriptor identity or
deadline checks. The plan explicitly refuses special nodes rather than opening
them. Add nonblocking open and retain descriptor regular-file/identity checks;
an inert flags/replaced-node fixture is sufficient. No real FIFO or expanded OS
probe is necessary.

## 5. Default test collection depends on private retained output

Priority P2 for portable repository tests; not a native API finding.
`EmittedEnvelopeTests` unconditionally reads a specific private E09gsz stdout
file (or another private fallback). Outside this machine both are absent.
Preserve actual C# envelope-byte coverage as an explicit retained-evidence test
with a supplied fixed input, and keep ordinary protocol fixtures portable. Do
not silently count an absent retained-byte test as executed or replace those
bytes with a Python reserialization.

## Evidence snapshot and next gate

The complete first source/test read covered parent
`ecd4a3e288d7472fd6809c9e3bc7cb6fa0e18f7995e679321d944fef5afa0572`,
protocol tests `ebc4829bf66b09d7303aa29fad28efd0e9f8ad56af53459895efe0f702c0bb0f`
and execution tests
`9e7ce72f2be6b5a4fcc2f62c60c2e8e1b55d8589cffa458111f8613bff8a8bc4`.
Plan SHA is `8685b39e5ea1c1702de9291aca9c2301e7dd2e3e769ad605461f645a14864389`.
The later targeted line inspection at tool receipt `65ffe0` still showed the
post-reap and blocking-open issues while maker bytes had advanced to
`a7d8bd97c10367703f944d501f727f8005f4aee31e8f181808aac5cc19d8a94c`.
These are source-derived findings, not claimed dynamic reproductions.

Next gate: maker retains finite REDs, applies the minimal corrections, freezes
source/tests and exact protected offline command, then independent full-delta
review/repeat. The 17-case/16-Run protocol, limits, source attestation UNVERIFIED,
model_admission=false and separate native authorization remain unchanged.

## Final frozen independent regrade — 2026-09-09

**CLEAR for the bounded offline parent implementation checkpoint. This is not
native execution authorization or scientific/model admission.** The historical
five findings and original NOT CLEARED assessment above remain intact. All five
are corrected in the frozen source; no additional blocker was found in this
regrade.

Read the complete updated connection plan, the full parent across the initial
read and final-delta review, both complete dedicated test files, and both
preservation files in the exact repeat. The source-only review child separately
rechecked successful COMPLETE, earlier-case preservation, global accounting and
provenance exclusion; its conclusions agree with this review.

### Corrected boundaries

1. `execute()` no longer queries process identity/waitability after its sole
   owner's reap. Final pipe draining, still-owned outer-worker monitoring and
   resource/file checks remain active. The regression uses the actual `Owned`
   cleanup implementation with an authored child whose waitability ends at its
   single wait, not the old perpetually-waitable fake.
2. Each case's exact immutable evidence hashes and file identities survive in
   the packet-level retained map and are reread before packet admission.
   Same-size/restored-timestamp byte replacement and inode replacement both
   have mounted packet regressions.
3. Successful COMPLETE requires the exact `DISPOSE` phase both when admitted
   and at `finish()`. Early failed COMPLETE remains a retained failure.
4. File opens are nonblocking/no-follow and the opened descriptor must still
   be regular, single-linked and identity-matched. Authored replacement/flag
   regressions do not invoke an actual FIFO.
5. Actual C# output checks are explicit retained-evidence checks. The ordinary
   portable suite does not silently substitute Python-generated bytes. This
   independent command supplied the pinned original stdout, so those checks
   executed here rather than being skipped.

Also verified the final additions: global 64 MiB / 5,000-entry / 16 MiB
structured-evidence admission includes active pending data, reserved failure
receipts and 2 MiB atomic packet-publication overhead; case limits remain
4 MiB / 256 entries. `provenance/` images are refused as loadable images,
including the explicit Core.dll fixture. Final result readback is followed by
the original packet-deadline check. If that final check fails, an immutable
already-published result may still say PASS, but the entry's failed completion
and nonzero exit make the invocation failed. **A result file alone is not an
accepted invocation.** The late-readback regression retains that distinction
without rewriting evidence.

### Independent execution and byte binding

Executed the exact four-file guarded command in
`2026-09-09-direct-dotnet-parent-connection-plan.md` (frozen SHA below), using
`/usr/bin/python3 -B`, from the fixed full-scope-recovery worktree. It replaces
socket creation, subprocess launch, ctypes native loading, process spawn/wait
and signal operations with counted refusals, and explicitly assigns both
retained-output modules' `RAW_PATH` to the original `pipe-green-tests.stdout.txt`.

- Independent tool receipt **`1ce677`**: **73 tests PASS in 0.594 s**, exit 0,
  `REFUSED_IO_CALLS 0`; no skips reported.
- Post-repeat fixed-file check **`bd351f`**: all **48** source/build/receipt
  entries matched both byte length and SHA-256, zero mismatches.
- Freeze manifest:
  `/private/tmp/livemore-dotnet-worker-toolchain.E09gsz/parent-connection-freeze-sha256.json`,
  SHA `4ed12bf293eb52c9a4bae998ab13eab9ec8827dbbcc6e965603eec4c99b3aeb5`.
- Parent SHA
  `42b7982e0d2fcd154f4e6c8218862a2d7a2abe5a0574b2c8c26346e6aaeee3db`.
- Protocol-test SHA
  `e80657b5e09c69ccfcc0f2e60125c67aa12c24e018971216cabb6e99c8136ba0`.
- Execution-test SHA
  `9d2e768306f7560170698c52f38e046c37461082d14c45dbe494b6f017fc9b99`.
- Plan/command SHA
  `2a4fda3cd9936896e1a59cc3fadab88a89fb2ce7556754226475e2b4079072d5`.
- Actual retained C# stdout: 45,890 bytes,
  SHA `2458a3a503e571a388959f9d877322b641ba1c8745810073399ca2c157e2c977`.

This reviewer did not execute the C# artifact, SDK, vmmap, native solver,
package preparation, network or browser. Local authored test files were the
only exercised filesystem mutation scope; product/source files were unchanged.
The 417-entry compiler manifest itself is included in the checked 48 files;
this regrade does not claim a fresh independent rehash of all 417 compiler files
or a new SDK qualification.

### Remaining execution gate

`EXECUTION_APPROVED=False` and `MODEL_ADMISSION=False` remain in the parent;
the native worker activation/build/package/once authorization is a separate
root-owned decision with its own exact hashes and fresh output. No old packet
may be retried or relabeled by this review. Actual qualification must inspect
the exit/completion together with every process, barrier, stream, observation,
comparison, immutable receipt and cleanup result. The fixed 17 cases / 16 Run
calls, 30-second workers, 3-second inspectors, 600-second packet, unchanged
oracles, `native_source_attestation=UNVERIFIED` and historical runtime UNKNOWN
remain explicit. Passing the offline parent tests proves neither a working
new native host nor biological/human equivalence.
