# Selection action acknowledgments must match the requested operation

Date: 2026-09-08. Bounded correction authorized by root after independent
review of the frozen selection-reconciliation packet. The existing proposal,
source and producer routes were read before this addendum. No server semantics,
model/context rules, registry data or clinical equations change.

## Retained defect and producer facts

Frozen `selection_reconciliation.js` SHA256
`44ae70b474eeb9148b1434064f42341c8138a41b32b4a933feba57d1a3deae4e`
validates recovery acknowledgments, but `runSelection` accepts any resolved
response. Independent review supplied HTTP200 `{}` for an activation and a fresh
listing of the old selected subject: the card falsely said acknowledgment
confirmed. Current identity was still read-bound; the operation receipt was not.

Actual `server.py::activate_twin` returns HTTP200 with the full stored
`livemore.twin-record.v1` after `SubjectRegistry.activate_twin` increments the
requested version by exactly one and sets lifecycle ACTIVE. It does not add a
request UUID or model-availability field. Mutation middleware adds no UUID.
This legacy success must remain usable without manufacturing a correlation ID.

Actual `select_twin_observations` returns HTTP200 with the prepared full record
and `model_availability`, plus canonical current `X-Request-ID`. Preparation sets
version n+1, lifecycle ACTIVE and selection_mode observations_only. The currently
supported REAL_HUMAN descriptive context produces UNAVAILABLE availability with
matching twin/version, an explicit model reason and preparation_available false.
Its cleanup/storage uncertainties remain non-success responses, not success ACKs.

## Narrow implementation contract

1. `subjects.js` passes a detached `{action, twinId, expectedVersion}` alongside
   each callback to `runSelection`, where action is exactly `activate` or
   `select-observations`. Validate this bounded intent before dispatch and freeze
   its copy; no target/version may be inferred from the response or fresh listing.
   Expected version must be a positive safe integer whose successor is safe.
2. Require the response record's schema, supported source class, bounded identity
   summary, ACTIVE lifecycle, exact requested twin handle and exact successor
   version. Full clinical record fields remain allowed: this is acknowledgment
   identity validation, not a new full-record scientific or clinical admission.
3. Observation selection additionally requires REAL_HUMAN, the explicit
   observations_only record mode, canonical current UUID and the existing strict
   availability v1 shape. Require UNAVAILABLE/observations_only, matching target
   and successor version, bounded source generation and no preparation permission.
4. Activation accepts its actual legacy response without a UUID or availability.
   If a UUID header is supplied it must be canonical; absence stays null and is
   never replaced with an older/generated ID. Optional availability, if supplied,
   must be coherent READY/model for this target/version. A contradictory explicit
   record selection_mode must not be acknowledged as numerical activation.
5. The narrow request reader requires HTTP200 for these two fixed action paths
   just as it already does for recovery. Do not change generic requests, shared
   SDK transport, parser budgets or safe non-success outcomes. For activation,
   reject a present malformed correlation header but permit actual absent legacy
   metadata. Observation selection and recovery still require canonical UUIDs.
6. All validation failures become fixed CLIENT_UNCONFIRMED / ACK_UNCONFIRMED.
   Preserve a valid current UUID and perform exactly one fresh listing GET. Do
   not retry POST, publish the response record as current, or overwrite the fresh
   selection with the requested target. Existing epochs, disposal, independent
   cleanup status and non-selection inspection remain unchanged.

No server-contract change is requested. The new intent argument is internal to
the two current subjects.js callers; existing recovery uses its separate validator.

## Red-first verification and independent gate

- Mount the actual recovery controller and request reader; provide HTTP200 `{}`,
  malformed schema, wrong target, unchanged/wrong/bool version, wrong lifecycle,
  malformed summary/source, contradictory availability and wrong/missing UUID.
  Assert ACK_UNCONFIRMED, one POST/one GET, no raw errors/clinical values displayed,
  fresh old selection preserved and old-GET fencing unchanged.
- Positive activation with absent legacy UUID and no availability, and positive
  observation selection with canonical current UUID and availability, must remain
  acknowledged. Use actual `prepare_observation_selection`/`model_availability`
  helpers to create the latter fixture, without a registry or numerical execution.
- Mount actual `subjects.js` for both actions to prove each intent is forwarded;
  controller-only tests cannot prove the production callers adopted validation.
- Test intent mutation while pending, repeated clicks, disposed response and a
  different authoritative selection following an otherwise valid ACK. The card
  must separate acknowledgment from current state in all cases.
- Preserve the prior 564-case no-network matrix, adding socket/DNS tripwires and
  fresh private test environment. No service/browser/native/model work. Rerun
  syntax and diff checks, freeze exact changed hashes, then request independent
  review. Browser acceptance remains separately authorized and outstanding.

Lesson: a fulfilled fetch promise is transport completion, not an acknowledgment
of the requested target and state transition. Fresh-read identity fencing and
operation-specific receipt validation are distinct obligations.

## Implementation evidence — frozen for independent review

Before changing runtime code, the new operation probes reproduced **45 failed /
4 passed in 5.55s**. The two actual subjects.js bad-ACK paths independently failed;
their two valid counterparts passed. All failures were authored Node/response
fixtures, not HTTP or real participants. An initial test-authoring stray `+`
before a JavaScript declaration was removed before the red execution.

After the fix, **97 passed / 1 failed** identified an old controller-only fixture
still supplying the formerly ignored string argument `observations`. It now
supplies the required exact action/target/version intent; its stale-GET rejection,
one POST, one GET, unchanged fresh identity and uncertainty assertions remain.
This fixture migration is separate from the reproduced product receipt defect.

Final repeat: **618 passed in 25.15s**, including 50 dedicated operation cases,
49 existing/revised recovery UI cases and the prior client/strict-parser/member/
availability/paging coverage. A fresh `prepare_review_environment` and main-process
socket-connect/DNS tripwires were installed before pytest. The Node probes use
only explicit authored fetchers/DOM. No real HTTP, services, registry actions,
browser, native solver or operational stores were used. Both changed JS modules
pass `node --check`; `git diff --check` passes.

Frozen SHA256 values:

| File | SHA256 |
| --- | --- |
| selection_reconciliation.js | d7a6486fb12fd27cc865ce5385d988f5da41efaec26b81cdde3919cff85684a2 |
| subjects.js | 7c4b3053c768712683318cfc6dac73ab2103681af1fb2948a3fac1884b6429eb |
| test_selection_action_acknowledgments.py | cd5be4772bcbe09c8459a5150caa6177e974bc0246e4b2e0e0c960ce46c0baf1 |
| test_selection_reconciliation_ui.py | 64d5417dcf8247ffe217e2c1e98e6ec50803f0772cdb240c56db62dccd8dfea8 |

Only these two runtime UI modules changed in this correction. SDK, transport,
registry/bootstrap, Cendos and servers are unchanged by this lane. Independent
source review and separately authorized real-browser acceptance remain pending;
these unit results are not whole-product or clinical validation.

## Independent correction review

The independent reviewer read the corrected controller, both production callers,
actual activation/observation-selection producer contracts and dedicated tests.
All five frozen file hashes above and the pre-append document hash
`118b46ae6b8e921343ff8cea1d791ef4ce3e5f7d73bbb762e52015649d0d65ff`
matched. The isolated matrix independently passed **618 tests in 25.20s** under
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-2vgt1ifv`,
with socket-connect and DNS refusal installed before pytest.

A separate authored Node probe, independent of the maker fixtures, confirmed
empty, wrong-target, wrong-successor and malformed-present-UUID activation
responses remain ACK_UNCONFIRMED with exactly one POST and one fresh listing.
The old authoritative identity remained current. A valid legacy activation with
no UUID remained ACKNOWLEDGED with null correlation, never an invented ID.

No remaining actionable issue was found in this bounded correction. No runtime
files, services, browsers, native models or operational stores were changed or
executed by this review. Real-browser and full-product acceptance remain separate.
