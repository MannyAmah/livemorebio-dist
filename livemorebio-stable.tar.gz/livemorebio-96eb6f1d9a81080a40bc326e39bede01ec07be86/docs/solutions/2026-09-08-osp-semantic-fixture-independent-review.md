# OSP semantic fixtures: independent bounded review

2026-09-08. Reviewer: `source_research`, not the fixture maker. No material
blocker found in the frozen **pure fixture/expectation/observation-comparison**
increment. This is not collector, supervisor, native execution or GIM admission.

Read the complete current307-line
[protocol](2026-09-08-osp-retained-native-technical-probe-proposal.md),171-line
[version-bound source map](2026-09-08-osp-native-semantics-source-map.md),407-line
[implementation](../../tools/osp_semantic_probes.py),456-line
[tests](../../livemorebio/tests/test_osp_semantic_probes.py), and262-line
[maker report](2026-09-08-osp-semantic-fixture-implementation-review.md).
No maker source or test was changed.

## Frozen identities

| File | SHA256 |
|---|---|
| `tools/osp_semantic_probes.py` | `12585d9bed93cd2a5625ec1cd625287406a22d475b49c34ba931109630ea82d7` |
| `livemorebio/tests/test_osp_semantic_probes.py` | `5c4d29106391b97f429d1f66969e3262c8d35395678b11947d94d74a08951b09` |
| Protocol | `0d477233d6555b5b694b2541512833d14b3c41a8d32ecaa5880a3d537278dcd0` |
| Maker report | `25f7f98296f3098d3960ee710de9cdf89aef06aae1233b0b492f0580e954695a` |

## Review result

- Exact S01–S17 XML, all seven solver references, separate parameter/readout
  identities, state scales, ordered events/assignments, and quantity-targeted
  Table/Offset links agree with the written mapping. The paired XML tests cover
  the actual isolated serialized distinctions, including S12 sibling order.
- S16/S17 apply the specified malformed **shared T** input to both derived and
  ordinary table declarations. This agrees with the source definition. A later
  rejection cannot identify which declaration rejected without actual evidence.
- Initialization/reset, mode and save-time hypotheses remain source expectations;
  the table values, slopes, shifted values and integral vectors agree with the
  fixed technical definition. Source formulas were not evaluated in this review.
- Explicit native-constant expansion retains the original count/marker/vector.
  Repeats compare raw double representations and vector shape. S15 unspecified
  initial exports remain retained, not replaced with a purported native zero.
- Strict byte/identity/schema/grid/output/statistics validation, bounded JSON,
  nonfinite/duplicate rejection and separate oracle/repeat disagreement reporting
  are appropriate for a collector claim. No return authenticates execution.

## Independent repeat

The maker report's exact four-file pure selection was independently repeated with
the managed Python, fresh `prepare_review_environment`, plugin/cache disablement,
60-second outer bound and network/process refusal. Audit hooks additionally
refused low-level socket operations and `ctypes.dlopen`.

**331 passed,2 explicitly deselected in0.76s; zero unexpected I/O attempts.**
The two excluded tests contain inherited `native_watchdog` child launches. No
R/CLR/native library, evaluator, compiler, solver, browser, service or operational
store was accessed. Private fixture root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-kkebtedf`.

## Remaining boundary

The native byte-to-source build attestation remains UNVERIFIED. Actual loaded
images, options/settings readback, native-constant observability, collection,
resource limits, exit/partial-output receipts and owned cleanup require later
implementation and independent review before a separate execution decision.
Expected-rejection stage claims do not prove a native rejection cause.

Original insulin numerical FAILED and static records remain unchanged. Neither
this review nor a future technical match qualifies GIM, compound response or a
person. All six required experimental programs remain in scope. The durable
lesson is that exact serialization and raw-vector identity are part of an oracle
contract; a matching expected JSON fixture is never native scientific evidence.
