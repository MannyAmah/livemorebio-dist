# Webpack stats leaf relations: retained failure and minimal correction plan

## Original evidence, not a new build

Root requested read-only diagnosis after session75463. The consumed
`/private/tmp/livemore-molecular-csp-builds.FJiuBt` remains unchanged. A's webpack
process exited0 with owned cleanup SETTLED/empty-before-reap, no signals, in
15.028236s; the packet then failed ASSET_GRAPH. B was NOT_RUN. The receipt says
inputs_preserved=true. This is not successful two-build or vendor admission.

The complete result, frozen208-line parser, tests, actual stats structure and
pinned webpack source were read. No package/build/browser/model/service was
executed. A stdlib JSON read produced only a bounded shape/count census, not a
rewritten stats file or an alternate admission result. Investigation followed
the already read evidence-first checklist. No operational data was accessed.

| Retained file under the consumed root | Bytes | SHA256 |
|---|---:|---|
| result.json | retained original | `5f1ae5cf1e43eab5747ef49db4694fa8b440b9a91cc89d4305f5970093bd69e0` |
| A/stats.json | 7,653,489 | `1b73a506270bc831c08c0dfba879fb0af9f7a5e15d84c40fb0761c03876e55c8` |
| A/dist/structure.js | 2,940,473 | `6993c2c9f356d31dcb325a5423507450da9cdbda035cdc85315727447fba7ced` |
| A/dist/structure.css | 69,902 | `ec90bcaa8610dc104656bc57effede3d6e1b954c2386dcaee985a88b8799c089` |
| A/dist/structure.js.LICENSE.txt | 971 | `bc83aaff43d3ef9301331bbfeaacc4d2d8549dfc9029f786bd6abdd32363b020` |
| build-once.py | frozen original | `1ab58ed11de64a2d9a082e8c0efea219b138800df49c9ab0a1663efe8a8917e6` |

## Confirmed cause, not asset grouping

The retained top-level assets are ordinary named `type:asset` records for JS and
CSS. The JS row has a list containing its named `type:license` related asset.
Both the CSS leaf and nested license leaf instead have `related:{}`. No unnamed
asset group occurs in these bytes. Frozen inspect_output lines96–99 requires
every related field to be a list; its LIFO traversal rejects the CSS leaf first.

The existing authored outputs supplied no related field, which defaults to [],
and the license test appended a flat top-level license row. Neither represented
the real producer's empty-object leaf or nested license. This is a parser/fixture
compatibility failure, not evidence that webpack omitted or failed to emit the
three retained assets. The original ASSET_GRAPH result remains unchanged.

Pinned primary source is installed webpack5.92.1 under
`/private/tmp/livemore-molecular-offline-monitor.2Ds7TZ/node_modules/webpack/`:

- `lib/stats/DefaultStatsFactoryPlugin.js:700–715` moves actual related assets
  from the top-level set into a parent's relation list.
- Its959–968 relatedAssets extractor calls factory.create with asset.related,
  even when a leaf's relation value is undefined. filteredRelated is undefined
  for that leaf and therefore omitted from JSON, not a nonzero omitted count.
- `lib/stats/StatsFactory.js:156,274–291` uses an array pipeline for arrays and
  an object accumulator for non-arrays. The leaf path returns `{}`.
- `DefaultStatsPresetPlugin.js:188–194` distinguishes JSON/toString grouping;
  no new group parser or config change is required by this actual failure.

Source hashes respectively:
`fc4990c177d42b0f4a79e1856b5460b66dc826f3c81656c3da2a8e5af0093e72`,
`4b08f9e7dee32bd7022ccc4a6b25de6c22800f934f0ad5291a21242410d10d90`,
`65111aef9bdf4118753043238171ddfb313a505ebb90cef919f5694f979cad44`.

The read-only census saw1361 top-level module rows and21 chunk module roots.
Traversing both full nested trees yielded3666 records,2326 with effective chunk
membership and1340 orphan records; all have type=module and string identities.
No nonzero/malformed filtered marker was seen in those module rows. Stats has
0 errors/3 warnings. This census is diagnostic, not a completed closure gate.

## Proposed bounded parser delta, before code

In a fresh successor packet only, normalize an exact empty dict in an asset's
`related` field to zero child relations. Continue accepting lists and the
existing absent-field empty case. Reject every nonempty dict, null, scalar,
unnamed record and unsupported group. Do not treat a nonempty info.related
declaration as an empty leaf: if that declaration exists, an empty-dict sentinel
must fail rather than hide its declared relation.

Keep the entire traversal and exact recursively collected asset-name set equal
to the actual dist file set. The nested license must be discovered, not omitted
or relabeled as a chunk. Keep filteredModules/Children/Assets/Related/Reasons
checks at every existing level; don't coerce booleans/null into zero. Preserve
both module trees, effective parent chunk membership, forbidden module/bytes,
source/rights review obligations, original file caps and error categories.

No grouping support, config change, output trimming, new module transform,
relaxed bounds or generic stats-normalization framework. Parent/owner deadlines,
two-build order, no-B-after-failure and exact A/B comparison stay unchanged.
No update to consumed FJiuBt, prior QkgKLS, installed tree or product/vendor.

## Required RED-first tests and next gate

First use the complete retained A/stats.json and three actual dist files as
read-only parser inputs, with the hashes above checked before/after. The old
parser must fail ASSET_GRAPH on those bytes. The corrected parser must return
all three exact asset hashes and full main/chunk/nested module membership,
without webpack or any other package execution. Retain this actual-source
regression instead of validating only newly authored JSON shapes.

Add small fixtures derived from the actual asset rows, including nested license:
valid exact empty-object leaves; valid []/absent legacy leaves; nonempty dict,
null/scalar related; missing/unnamed nested license; nonzero filteredRelated or
filteredAssets; empty leaf contradicting info.related; unexpected/omitted file.
Keep existing filtered-module and emitted-child/orphan negatives. Begin from a
known valid complete record before each mutation so failures are not masked by
a different malformed field. Preserve original tests, with only the old
pre-run AUTHORIZE/started absence assertion mapped to the new unconsumed root.

Root must review this proposal before implementation. Then independently review
the corrected parser and actual-retained-output regression before deciding any
fresh A/B build invocation. Do not resume B in FJiuBt or claim its A inspection
retroactively passed. Rights, actual built CSP/browser, wheel and scientific
gates remain separate and open.

## Durable lesson

Stock tooling's serialized shape is an input contract. Exercise the complete
retained producer output before another invocation; a tidy mock with omitted
fields cannot establish parser compatibility. Diagnose the actual leaf shape
instead of adding speculative grouping support or relaxing completeness checks.

## Root pre-code decision

Root read the complete114-line proposal and approved only fresh-successor
parser implementation and RED-first tests. The full unchanged FJiuBt artifact
must exercise the actual parser with before/after identities; exact empty-dict
leaf handling and the contradictory info.related rejection are the only parser
changes. Preserve all27 original tests and paired adapter/entry/config/spec.
No AUTHORIZE or build invocation is permitted before independent source/test
review. Fresh private root: `/private/tmp/livemore-molecular-leaf-parser.IviiqA`.

## Maker freeze, not build acceptance

The fresh successor is frozen for independent review. Full private receipt:
`/private/tmp/livemore-molecular-leaf-parser.IviiqA/IMPLEMENTATION-REVIEW.md`,
SHA256 `664a3df4525faba57cfd737c8b595af24e35e2129183a4a03e11bae60049c416`.
Helper SHA `cf597439fe4311ae2c03218800608b199dd3247c7861b80b044dfb3f7a52b3db`;
new22-case test SHA `ebe9e4b34d87434d94b76521d87617be672497d2acb07ad2db9314a6e34211c9`.
Original27 tests remain byte-identical. Initial49-case RED:30 PASS/19 ERROR,
1.643s/session73889, including the complete actual-artifact ASSET_GRAPH; many
negative cases were blocked on their required valid baseline rather than their
own mutations. Final49 PASS2.353s/session25824; both runs unexpected I/O0.

The corrected parser returns all exact retained assets and the full3,666-record
main/chunk/nested membership multiset (2,326 emitted/1,340 orphan), while the
original-parser control still fails as expected. Every retained input's hash,
size,mode and mtime agrees before/after. No original artifact was rewritten or
copied to satisfy admission; no build/package/browser/native operation ran.
Only ROOT/INPUTS_SHA and the six-line leaf branch changed. The new21-row input
manifest changes only the12 copied-root paths. No AUTHORIZE/started/dist exists.
Independent review and a separate build decision remain required.

## Root independent review and one-use build decision

Root fully reviewed PLAN, IMPLEMENTATION-REVIEW, all22 new cases, the unchanged
27-case suite, the full21-file inventory and the complete corrected helper.
The only parser change is the six-line exact-empty-leaf branch described above;
the paired entry/spec/config/package/lock/adapter inputs remain unchanged.
Independent repeat: **49 PASS in3.559s**, session52523/chunk53be0e,
unexpected I/O0. The original-parser control still rejects the retained real
output; the corrected parser preserves its complete3,666-record membership.
Root independently rechecked all seven frozen helper/plan/inventory/report/test
hashes and the `d2ac1bac…` owner source before this decision.

Authorize exactly one fresh A-then-B invocation in IviiqA using the reviewed
helper `cf597439fe4311ae2c03218800608b199dd3247c7861b80b044dfb3f7a52b3db`,
plan `3322debe99354efaca729ccb5a0b317e35eb7b01bd947169ae799c3b9ed65382`,
inventory `732f62f36046d07036a3c63fcefe2df859d6358b8dd0424d5a05c5e7aca2e201`,
and retained install receipt `16a905c168cb45afa62cc105de9d767bb5af19a038e4c9f6d7d2fa9f00f27990`.
B may run only after A passes. No retry/resume, source mutation, installer
rerun, vendoring, browser execution, or scientific acceptance is authorized by
this decision. Source owner remains frozen through the pair and final input
verification. Original two failed packets remain immutable.

## Actual fresh pair result

Session1789 completed exit0, status `BUILT_REQUIRES_CLOSURE_AND_RIGHTS_REVIEW`.
A15.262629s and B15.555252s both exited0 with SETTLED cleanup,
empty-before-reap, no TERM/KILL or stream errors; final inputs_preserved=true.
Root read the complete receipt, both output inspections and stderr originals.
All three paired assets are byte-identical: JS2,940,473B/SHA6993c2c9…,
CSS69,902B/SHAec90bcaa…, sidecar971B/SHAbc83aaff… . Both inspections retain
3,666 module records and three warnings; A/B stats naturally differ in path
identities and are not asserted byte-identical. Full rights/closure review
remains separate. The small minifier sidecar is not the complete notice bundle.

Root rechecked the complete result SHA
`fbbe521d9f08eff73908903f0289287598130315efbb305ddcb13431cbafd8a2`,
inspection SHAs `dbc3078a26054e7b24e5b764d313c41120f85c882f21dc1dd57761fe06c816d4`
and `fca0ca08f94be6590ea902e558e5fbd8cda79f55a592479cfa5c1f6415e5369c`.
Direct postcheck found supervisor30973 and children30993/31015 absent. The
temporary d2ac owner-source hold is released; this consumed pair must not be
rerun after the separately reviewed OSP budget change. Independent emitted
membership review and actual CSP/WebGL/UI acceptance remain required. No
product vendor, ordinary Biology screen, installed release or experiment changed.

Independent reviewer subsequently cleared the actual pair's finite source/
membership gate, without importing the released owner. Root read the complete
report `2026-09-09-molecular-actual-pair-independent-review.md` and its retained
review-data receipt. Exact1,155 source files in59 packages are unchanged from
FJiuBt; all86 retained source-credit blocks agree, no emitted member is unmapped.
The actual source set corrects older prose's sanitize-uri2.1.0 to2.0.1 and
28-plus-webpack count to27-plus-webpack; no package drift or missing notice.
Root authorized only a private full-notice assembly and a proposed actual
adapter browser check. These do not authorize redistribution or active switching.
