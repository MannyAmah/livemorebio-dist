# Molecular inspector — pinned upstream API review

Date: 2026-09-09. Independent reviewer: source_research.

## Verdict and boundary

**CLEAR in the requested source-compatibility scope.** No concrete mismatch was
found between the current inspector's calls and the installed Molstar 4.4.0 /
React 18.3.1 implementation and declarations. No product correction is proposed.
This is not acceptance of rendering, CSP compatibility, browser resource cleanup,
rights, scientific validity, or the still-separate build-output admission.

Only source/declaration reads and file hashes were performed. No module import,
test, CIF parse, model/native call, build, service, browser, or network operation
was run. The review skill's source checklist informed this read; its mutation and
launch actions were excluded by the explicit read-only assignment.

Prior evidence: the structure-only build/controller plan and loader/inspector
implementation review. The latter's 95 authored-adapter tests remain useful
controller evidence, not execution of these upstream APIs. In particular the
test's `createStructureSpec: () => ({})` does not exercise the real spec.

## Frozen identities

- Inspector `livemorebio/aegle/console/lib/molecular_inspector.js`:
  `00266652ee37295650a7012676aafb2e91bfeaf03289f804937fb4b1e909c0aa`.
- Loader `livemorebio/aegle/console/lib/molecular_loader.js`:
  `bf6e1845ce9f37458239ff42960dd44eed29c0d246c34f995a9b8a8d76d57c71`.
- Inspected entry `/private/tmp/livemore-molecular-csp-builds.FJiuBt/A/entry.js`:
  `1cb794b2ce31358ad270e78f185e6bfe71c1d789c05727a0856b78c16ab1df10`.
- Same directory's `spec.js`:
  `49f9b841e1cd144767d734e5520dfabaf95b9234c2cbc6ae4e52110441bf2b35`.
- Upstream source root below is
  `/private/tmp/livemore-molecular-offline-monitor.2Ds7TZ/node_modules`.
  The three package manifests state Molstar 4.4.0, React 18.3.1 and React-DOM
  18.3.1. This review uses those retained bytes, not current online documentation.

## Exact call mapping

| Inspector seam | Installed source evidence and assessment |
| --- | --- |
| Construction and initialization, lines 138–143 | `molstar/lib/mol-plugin-ui/context.js:20` extends `PluginContext`; `mol-plugin/context.js:314` supplies async `init()`, sets `_isInitialized`, and settles the separate `initialized` promise. Both promises are constructed on the context before `init`. `context.d.ts:98` and `:220` declare `Promise<void>`. Awaiting `init()` plus `initialized` is redundant but valid. The owner is installed before the awaited work. |
| UI mounting and canvas readiness, lines 144–148 | Official `mol-plugin-ui/index.js:11` uses the same context → await init → render `Plugin` → await `canvas3dInitialized` order. `plugin.js:17` checks `isInitialized`; `viewport/canvas.js` mounts through `plugin.mount`. `mol-plugin/context.js:123` builds the canvas and schedules promise resolution, or schedules rejection on viewer initialization failure. `behaviors.canvas3d.initialized` is a different observable; the inspector correctly uses the promise. |
| Raw data and mmCIF parse, lines 149–150 | `mol-plugin-state/builder/data.js` commits `RawData` with `revertOnError`; `builder/structure.js:33` resolves the input selector and dispatches the `mmcif` provider. `formats/trajectory.js:15` commits ParseCif → TrajectoryFromMmCif and returns `{trajectory}`; the builder returns that selector, not the wrapper. `mol-state/object.js` supplies its `.obj` getter. |
| Trajectory count and selected frame, lines 151–160 | `mol-model/structure/trajectory.d.ts` declares numeric `frameCount` and `getFrameAtIndex` returning `Model` or `Task<Model>`. The built-in `ModelFromTrajectory` implementation (`transforms/model.js:463`) resolves either using `Task.resolveInContext`. The inspector correctly delegates this to the preset rather than assuming a synchronous frame. Loader lines 45–49 require an in-range zero-based index and matching source model number; upstream's modulo operation cannot silently select an out-of-range descriptor. |
| Default preset result, lines 154–161 | `builder/structure/hierarchy.js` recognizes the string `default`. `hierarchy-preset.js` accepts `model: {modelIndex}`, `structure: {name: 'model', params: {}}`, and `showUnitcell: false`, returning a `model` state selector. The inspector passes its own exact bounded parameter object after checking the adapter result. `helpers/root-structure.js:142` calls `Structure.ofModel` for `name: 'model'`; it does not choose an expanded assembly. Empty model params are valid because `dynamicBonds` is optional. |
| Source model identity, lines 161–164 | `mol-model-formats/structure/basic/parser.js` sets `modelNum` from `pdbx_PDB_model_num` and retains `sourceData: format`. `structure/mmcif.js:83` makes `kind: 'mmCIF'` with `data: {db, file, frame, source}`. The correct row count is **`db.atom_site._rowCount`**, as implemented, not `db._rowCount`. It counts the original atom-site table, not the selected model's rendered atoms. |
| Real spec actions/behaviors | All ten actions and eleven behavior references in the retained spec exist in the installed export modules. `mol-plugin/spec.js:23` / `:27` wrap them in the expected shapes; the spec uses one-argument arrow callbacks, so array indices do not become behavior default parameters. `mol-state/action/manager.js:21` explicitly accepts StateTransformers and converts them to actions. `PluginContext.initBehaviors` installs custom properties first and then other behavior categories. Missing unlisted UI actions are not needed merely to invoke these builders' transforms. |
| Real spec UI components | `mol-plugin-ui/plugin.js:152` consumes `components.viewport.view`, `controls.top`, and `structureTools` exactly as supplied. `viewport/canvas.js` accepts `noWebGl` as a component. The imported selection, label, measurement, quick-style and component controls exist. This verifies reference shape, not the actual rendered control layout or behavior. |
| Teardown, lines 64–74 | React-DOM `client.js` exports the production root API. Production source line 309 and development source lines 29324–29381 implement `render` and synchronous `unmount` (flush the null tree, release the root marker); they do not return cleanup promises. Molstar `PluginUIContext.dispose()` is synchronous and calls the base disposer then layout disposer. Base `context.js:201` stops animation, disposes canvas/context/state/managers and unmounts. The inspector's root-unmount-before-plugin-dispose order matches these APIs, waits for tracked tasks first, and retains cleanup failure rather than assuming release. |

The canvas disposer further releases input/context listeners and WebGL resources
(`mol-canvas3d/canvas3d.js:212`), and the scene disposer cancels its animation
handle and disposes controls/renderer (`:854`). These are source obligations, not
an observed claim that a browser or GPU has finished releasing everything.

## Important remaining acceptance limits

React `root.render()` is scheduled work, not a render-completion promise. Waiting
for Molstar's actual canvas promise is the correct available initialization seam;
it does not prove that every later asynchronous React render/control succeeds.
The actual private CSP/browser gate must still inspect the scene and Help,
selection, measurement, close/reopen and failure/timeout outcomes. A never-settling
upstream task remains owned and blocks replacement rather than being considered
cleaned up by a timer. No new retry or wider browser matrix is proposed here.

The reviewed source field checks establish deposited-model identity and original
source-row consistency only. They do not prove full canonical-protein coverage,
biological assembly, physiology, patient specificity, or experimental readiness.
Prior failed build receipts and the unresolved embedded-source rights conditions
remain unchanged.

## Key installed implementation hashes

Paths in this table are relative to the installed source root above.

| File | SHA-256 |
| --- | --- |
| `molstar/lib/mol-plugin/context.js` | `bcdb11e06c453d5f00311d427d8c6e71207b07d975646af20276e24eb4b413ae` |
| `molstar/lib/mol-plugin-ui/context.js` | `6521127a6602df2c79f9e4f1ac807ec33b83f383a722601e633073a7ce0a7620` |
| `molstar/lib/mol-plugin-ui/index.js` | `578b37008e0b0b1e96786ac4b7b59e170a22062c8427075fca903b9406e9f910` |
| `molstar/lib/mol-plugin-ui/plugin.js` | `4240237a00845e52d21804b8be4a0bfe2bf7e0f9e2a3fc657670a95f754638cb` |
| `molstar/lib/mol-plugin-state/builder/data.js` | `78dba03aa7ddcb72d417fb55ab3be246d040f80311b5f3a00aa70a004bf26b3d` |
| `molstar/lib/mol-plugin-state/builder/structure.js` | `46906a9f80cce2c02cfce9b997e090727b2b62bad5bb564284268551d8643274` |
| `molstar/lib/mol-plugin-state/builder/structure/hierarchy.js` | `38bc1d835aba968de1f7943f3160ebbb4a9b8622c7daea91cac40580a215cb78` |
| `molstar/lib/mol-plugin-state/builder/structure/hierarchy-preset.js` | `d4581a730580350f5ff4c6c966ee9d69f19e964148792dd8927813abdbbcda75` |
| `molstar/lib/mol-model/structure/trajectory.js` | `6135d1661d5a951e864a7eff3d5e87713a67b572852ab984e5eba182c880aeed` |
| `molstar/lib/mol-plugin-state/transforms/model.js` | `3c62a9b950e3717831444dfbd7983c9b5310c0e85e8a1ff5ca1154db038e6497` |
| `molstar/lib/mol-model-formats/structure/mmcif.js` | `3fc5d9c3e2986fe44453edc4a37c37efdab5f10a6ee917039c0c74f1b0a79141` |
| `react-dom/client.js` | `a510041dfc40d69b3aa574e5e111864186c711fbeb3db41aa2f27196b27c429f` |
| `react-dom/cjs/react-dom.production.min.js` | `cbf7fe6b9726ee65f8bcd5715289cc5161c8dacf74d0b8aaa0d29412516f5f47` |

Compounded lesson: keep upstream asynchronous canvas readiness, trajectory task
resolution and selected-model source identity as separate checks. Authored mocks
must not be mistaken for evidence that those version-specific runtime seams ran.
