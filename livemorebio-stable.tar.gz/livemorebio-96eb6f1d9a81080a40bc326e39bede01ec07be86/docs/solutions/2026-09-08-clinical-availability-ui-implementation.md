# Clinical availability UI implementation and regression lesson

Status: maker implementation checkpoint; independent source review and real-browser
acceptance are pending. No service, participant, numerical experiment, or anatomy
asset was changed by this UI packet. This does not qualify a biological model.

## Approved scope

Implements the UI portions of the reviewed clinical-context dispatch proposal and
clinical-context-availability amendment. The backend owns the exact
`livemore.model-availability.v1` contract and descriptive selection transaction.
The UI does not infer a diagnosis, assign a profile, repair missing model bindings,
or substitute healthy/T2D values for an unavailable individual model.

## Consumers and preservation

- Atlas/workspace validates the unavailable branch before publishing the immutable
  snapshot. Prior current numerical plots, mechanism values, comparison and replay
  are cleared. Reference Atlas and the admitted observation drawer remain usable.
  A secondary render failure cannot restore the previous person's physiology.
- Active Biology closes an existing cell inspection on a context transition and
  displays reference anatomy without numerical cell replay. Explicit saved-run
  and fixed-execution paths retain their separate source identity.
- LIFE Patch uses no fallback biological-time axis when the model is unavailable.
  Existing admitted observation value, class, unit, source digest and original
  timestamps remain visible. No new virtual or physical samples are produced.
- Continuous execution distinguishes explicitly opened immutable History from a
  current execution panel. Unavailable current capabilities pause following and
  remove current numerical displays; a deliberate committed-History read can
  restore those exact old frames as historical, not current person data.
- Both pending-cleanup codes, `EXECUTION_CLEANUP_UNCONFIRMED` and
  `CLEANUP_UNCONFIRMED`, expose the single explicit Stop cleanup operation in all
  backend-supported states. Start/Resume remain disabled while cleanup is pending.
  Ordinary completed/stopped results do not acquire general repeat-Stop authority.
  The displayed control revision and fixed source generation are submitted once.
- REAL_HUMAN selection is a distinct observations-only action with exact
  `expected_version`. The committed-selection/cleanup-uncertain response triggers
  a state re-read, not a repeated mutation. Activation and virtual pairing are not
  suggested as a way around missing numerical model bindings.
- REAL cohorts use compact summary cards plus explicit 10/25/50-member pages and
  separate frozen-evidence inspection. Selection alone does not fetch the clinical
  snapshot. Pagination/disposal are fenced, and protected GETs use `no-store`.
  Current-member substitution and protocol execution never occur in the picker.
- Cendos preserves preparation and saved History while blocking the legacy
  current-twin assay when its model is unavailable. The older console also clears
  previous numerical readouts instead of catching a null-state rendering error.

## Red-before-green evidence

The initial ten clinical UI regressions returned **9 failed / 1 passed** before
implementation. They reproduced unavailable-projection rejection, null comparison
rendering, old profile/readout retention, the fabricated 840-minute fallback axis,
disabled cleanup, missing observations selection and compact REAL inspection.

Additional mounted cleanup cases reproduced **10 failed / 22 passed** before the
two-code/all-state correction. Both source-valid and invalid states are tested;
the accepted cleanup response preserves a completed terminal state when applicable.

The remote member picker began with three missing-function failures, then passed
bounded first-page, explicit-only detail, rapid navigation, failed-read clearing,
disposal and mismatched frozen-wrapper checks. Cendos additions were likewise
captured red before their own UI corrections.

One new historical-read test initially supplied an invalid empty page cursor of
zero after frame two. The product correctly rejected it. The fixture now returns
the API's unchanged cursor two, and also asserts the explicit historical-success
message. No assertion was skipped and no production integrity guard was weakened.

Final bounded run: **137 passed in 13.33 seconds**, three existing
Starlette/FastAPI deprecation warnings. Seventeen affected module/inline scripts
also passed parse-only checks without browser or model execution. Test files:

- `test_clinical_model_availability_ui.py`
- `test_clinical_execution_ui.py`
- `test_real_cohort_member_ui.py`
- `test_cendos_compact_members.py`
- Existing workspace stream, biological projection, continuous execution,
  population guidance, member picker, anatomy restoration/retry, QA regressions,
  and reference-cohort UI tests.

The existing Biology VM harness now includes the actual shared availability
function when resolving its new module import; it still mounts the original
controller and retains all existing assertions.

## Durable lesson

Missing computational eligibility is a first-class successful descriptive state,
not a transport failure and not permission to retain the previous subject's
numerical output. Clearing current physiology and preserving exact historical
evidence must be separate operations. Lifecycle terminal labels also do not prove
owned native resources are cleaned up: explicit cleanup availability follows the
typed pending-cleanup record, without resuming computation or retrying mutations.

The CE compound command is not callable in this session. This durable record is
the equivalent local lesson output; it does not claim an unavailable tool ran.

## Remaining gates

Independent maker-never-grades review, backend integration with the final source
contract, and browser screenshots on a fresh owned review stack remain required.
The retained Atlas performance/network, external Biology dependency, zoom and
unrun fault/resource-cycle findings stay open in the separate Atlas report. This
UI packet does not modify Atlas geometry or convert those failed gates into passes.

## Independent review corrections — retained red evidence

The independent source reviewer reproduced three defects after the initial
137-test checkpoint. The initial result is not treated as acceptance:

1. Action reset targeted nonexistent `.action-step` elements and the wrong CSS
   states. Actual `#action-flow [data-state]` nodes retained `done`/`current`.
2. The secondary-render failure test verified the JavaScript state, not the
   previously painted mechanism/evidence DOM. Those nodes could survive under
   the newly published observations-only identity.
3. Legacy numbers cleared while prior cardiac-path/neural color, the metabolic
   measured-provenance chip and APD/block warning classes survived.

Three exact DOM regressions failed before correction. The workspace now clears
the numerical/evidence presentation before publishing an unavailable identity,
and clears again on partial rendering failure. That operation does not dispose
or replace the reference Atlas. Action classes use the actual document selectors.
The legacy unavailable path resets the derivative colors, chip title/class/text
and warning classes without changing supported numerical calculations.

Recheck: **138 passed in 13.46 seconds**, the same three existing warnings.
Workspace syntax and scoped whitespace checks also passed. Only `workspace.js`,
`index.html` and the dedicated clinical UI test changed in this correction.
Independent rereview and real-browser acceptance remain pending.

Lesson reinforced: object-state tests cannot stand in for display invalidation.
Test real DOM selectors and derivative evidence/color/class state, including an
exception after the new identity label is rendered, not only the happy path.
