# Atlas harness — reconcile visible and omitted callouts

2026-09-08. Pre-code amendment only, awaiting root approval. No script, test,
product, cache or retained browser evidence changes are authorized by this text.
It refines the approved 382-line post-presentation correction contract without
adding a camera pose, asset, minimum-visible-label criterion or run budget.

## Concrete frozen-candidate gap

Frozen CJS `8a1d71bc950044206797665655c0836df3b46c41f7625ecfebf879a22518f667`
validates geometry for each member of `labels` at lines118–133, so an empty array
passes. Lines227–228 record the footer/list without validating them, and truncate
the list to nine entries without recording its original count. The group case
at336 can therefore pass with no overlays and a footer claiming nine placed, a
missing/duplicate list, or a checked labels control whose scene remains off.
These are source-confirmed acceptance gaps, not a new browser observation.

## Frozen source identities and bookkeeping grammar

Use exactly the existing ordered source keys:
`skin, heart, liver, pancreas, right-kidney, left-kidney, right-lung, left-lung, brain`.
The actual product display name is the lowercase key with hyphens replaced by
spaces. Do not rename the product, infer keys from array position alone, or require
that all nine source centers are in the camera view.

Add bounded snapshot metadata only:

- `labels_requested`: the actual `[data-labels].checked` boolean;
- `document_hidden`: the actual document visibility boolean;
- `callout_list_count`: untruncated number of `[data-callout-list] li` elements;
- retain the existing first-nine bounded list texts and bounded footer text;
- `group_controls`: exactly the nine keyed `[data-group]` controls with checked
  and disabled booleans, to distinguish an explicitly disabled layer from an
  unsupported omission claim. No new control interaction is added.

The checker requires raw list count exactly9, all nine names exactly once and in
the frozen source order, and no truncated/missing/unrecognized row or footer.
For each expected name, admit only the current literal `name + ' · ' + reason`
form. Reasons are these existing product strings, not new scientific evidence:

| Meaning | Existing row text |
| --- | --- |
| Placed | `callout placed` |
| Off | `labels off` |
| Section | `suppressed during section` |
| Isolation | `suppressed during isolation` |
| Space | `insufficient label space` |
| Outside | `anchor outside the camera view` |
| Invalid | `anchor or measured text unavailable` |
| Disabled | `layer disabled` |

The existing capture gate already requires ready graphics and all9 loaded groups.
In those successful states, `layer not loaded`, `callout unavailable`, hidden,
disposed or context-lost bookkeeping cannot be reported as a successful capture.
Such states remain failures with retained metadata, not silently remapped reasons.

Match the complete footer to its existing grammar, with canonical integer counts
0–9: `N group callouts placed · M omitted. <mode sentence> Complete reference group list:`.
Require N+M=9. N must equal the actual visible-label count. Each named `callout
placed` row must match exactly one visible source key, and vice versa. Every
remaining key must have one admitted omission reason. Existing text, leader,
inset/gap and selected-cue geometry checks remain in force for every visible label.

## Requested-state/suppression coherence

Use the actual product precedence, not a new policy:

1. A hidden document cannot pass the existing ready capture gate.
2. If labels_requested is false, expect zero visible labels, all nine rows `labels
   off`, and the footer mode sentence `labels off`.
3. Otherwise if axis is not off, expect zero visible labels, all rows `suppressed
   during section`, and that same footer mode sentence.
4. Otherwise if isolated is true, expect zero visible labels, all rows `suppressed
   during isolation`, and that same footer mode sentence.
5. Otherwise expect footer mode sentence `Reference bounds-center anchors, not
   surface visibility.`. A checked/enabled group may be placed or omitted for
   space/outside/invalid; an unchecked group must say layer disabled and cannot
   be visible. All-nine-loaded captures require enabled group controls.

The reference-label pose must explicitly record labels_requested=true after its
existing check action. A no-op scene toggle that still reports labels off fails.
Checking the footer is a control/evidence consistency test, not independent proof
that the renderer's stated projection/omission reason is scientifically correct.

**Zero visible labels remains valid** in the labels-on, section-off, nonisolated
case when all nine are consistently omitted for the admitted per-group reasons.
Do not set a minimum count, relocate the camera, enable missing layers, or weaken
source/graphics readiness to manufacture visible callouts. Manual visual review
and the broader matrix remain separate.

## Integration, red tests and preservation

Add one pure fixed-shape bookkeeping checker in the same harness and invoke it
alongside existing visible-label geometry validation before and after captures,
including inspector poses. Preserve metadata before any rejection and retain
each previously saved image. The 20-case/33-image ledger, all control actions,
camera/scroll sequence, 3/2/2 listener bounds and browser budgets stay unchanged.
Only the new dedicated harness test file and CJS may change after root approval;
Python listener implementation and all product files remain frozen.

REDs must include: zero overlays with nine claimed placed; one visible key missing
its placed row; omitted key incorrectly visible; wrong total/count, malformed
footer, missing/duplicate/reordered names, raw count10 hidden by bounded text
capture, unrecognized or unavailable reason, labels requested on but scene off,
off/section/isolation precedence mismatch, and disabled-layer contradiction.
Positive controls: valid zero-visible all-outside and mixed space/invalid cases,
valid partial visible/omitted partition, valid off/section/isolation suppression,
and exact same valid snapshot passed through both pre/post capture checks.
Extend the actual DOM-double test so checkbox state and original list count are
read from the real snapshot function, not a source-string stand-in.

No actual OS, listener, browser, HTTP or model probe is part of RED/green work.
Keep Python/Node refusal guards, unchanged inherited assertions and source hashes.
Freeze the updated packet and append attribution to the implementation report;
root and independent reviewer must clear it before any actual run.

## Root pre-code approval and raw control-count precision

Root read all115 lines and approved this exact harness-only correction after the
independent snapshot-publication review. Also retain `group_controls_count` before
bounding the control array: extras or duplicate keyed controls must not disappear
behind a first-nine projection. Require exactly9 raw controls and the exact nine
unique keys; no product changes, Python listener edits or actual probe. CJS and
the dedicated correction test are the only implementation write set. The existing
20-case/33-image ledger and valid zero-visible semantics remain unchanged.
