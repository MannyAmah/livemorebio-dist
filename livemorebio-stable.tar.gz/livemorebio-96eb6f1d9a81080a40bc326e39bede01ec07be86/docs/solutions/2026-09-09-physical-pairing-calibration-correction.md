# Physical pairing: explicit operator-declared calibration

## Scope and decision before code

This is the narrow legacy-declaration correction already required by §5 of
`2026-09-08-physical-life-v3-onboarding-parity-plan.md`, authorized by root after
the separately retained 16-image legacy-feedback acceptance. It is not complete
physical-v3 onboarding, calibration verification, hardware validation or a
participant experiment. No sample, certificate, firmware or calibration date is
generated. The full parent plan and its 416-line authorization amendment remain
required work, including registered-manifest lineage, pre-journal authorization,
distinct durable receipt stores, apply-time authority and SDK/terminal parity.

The engineering-review skill checklist was used for this bounded plan. Its
selected instructions, workspace rules, biological-change contract and both
physical plans were read completely. Prior-art search found the exact default
and reopening defect already recorded in the parent plan. No connected gbrain,
CE, Context7 or sequential-thinking tool is available; no external service or
browser was used to prepare this correction.

## Current source evidence

- `twins.html` has a non-required calibration select whose first option is
  `current`; the dialog is fixed to legacy protocol `2.0` / `B0-EVT-target`.
- `openPhysicalPatch` clears device, firmware and attestation, but not calibration.
  A preceding choice therefore silently carries into a later opening/person.
- `bindPhysicalPatchForm` already fences the captured selection epoch, twin ID
  and exact version, and uses the existing operation lock. It does not explicitly
  validate the form/calibration before entering that lock and issuing the POST.
- Registry physical admission already requires declared `current` calibration,
  selected ACTIVE REAL_HUMAN authority, LIFE consent and attestation. Current
  prepared transitions/audit are preserved. The older parent-plan statement that
  unknown binding fields are ignored is stale: the current normalizer rejects
  them. This correction changes neither that policy nor any stored record.
- API/SDK can carry protocol `3.0` metadata, but that alone does not implement the
  complete registered-lineage workflow. The dialog must not imply otherwise.

Baseline SHA-256:

| File | SHA-256 |
| --- | --- |
| `livemorebio/aegle/console/lib/subjects.js` | `7c4b3053c768712683318cfc6dac73ab2103681af1fb2948a3fac1884b6429eb` |
| `livemorebio/aegle/console/twins.html` | `6afceafb6fcf9df10de6371b8e2b7f4f656cbc62b9dcd55bc6241cdb081af5f8` |

## Exact implementation and ownership

Maker owns only those two product files, new
`livemorebio/tests/test_physical_pairing_calibration_ui.py`, and this report.
No server, registry, protocol, gateway, SDK, terminal, hardware, store, existing
browser harness or other UI module edit is authorized by this packet.

1. Add a required, disabled, selected empty placeholder to calibration; retain
   `current`, `due`, `failed` and their wire values. Label the field **Declared
   calibration**. Empty is not a calibration state and is never sent.
2. Every permitted dialog opening sets calibration to `""`, alongside the
   existing field clearing. Preserve captured selection/version/epoch, showModal
   and initial device-field focus. A rejected submit in the same open dialog
   retains operator inputs; closing/reopening requires a fresh choice.
3. After the existing selection fence and before the operation lock / recording
   message / POST, call native `form.reportValidity()`. If invalid, return. Then
   require the exact selected value `current`; other values produce fixed feedback
   (“Physical pairing requires an explicit declaration of current calibration.
   Due or failed calibration cannot be paired.”), focus calibration and return.
   Unknown DOM values also fail this exact check. Do not assign `current` in code.
4. Preserve the exact existing v2 POST fields, expected version, operation lock,
   success/load/error flow, backend admission and all virtual-pairing behavior.
5. Keep existing pending-signed-envelope, no-live-connection and B0-not-human-use
   warnings. Replace the API/SDK completeness implication with “Complete
   registered-lineage physical-v3 onboarding is not available in this form.” Add
   “Calibration is an operator declaration, not a verified calibration certificate.”

No additional design choice or general validation framework is needed. Native
validity handles required text fields; the explicit exact calibration predicate
mirrors existing server policy rather than introducing a scientific gate.

## Red-first technical tests

New tests mount the actual controller functions in an authored DOM with the
actual imported selection-reconciliation controller. Only transport is stubbed;
no real record is created and no browser-native validation is claimed by the DOM
double. Its `reportValidity` seam records invocation and authored validity.

Initial bounded inventory: **16 cases**:

- One parsed-markup case: required empty placeholder, no selected Current,
  unchanged legacy fields/options and explicit evidence-limit copy.
- Four reopen cases after prior empty/current/due/failed: empty selection, cleared
  existing fields and preserved initial device focus.
- One new-person opening case: fresh empty choice plus new captured identity,
  version and epoch.
- One blank/native-invalid submit: validity called, no POST or recording state.
- Three due/failed/unknown submit cases: fixed feedback, calibration focus, no POST.
- One explicit-current case: exact unchanged v2 payload and one POST.
- Four stale epoch/version/twin/unconfirmed cases: original selection rejection,
  no validation or POST, no weakened existing fence.
- One overlapping submit case: pending original operation remains one POST.

Preservation repeats retain the existing selection-reconciliation UI matrix and
the existing person-intake UI checks. Existing assertions are not rewritten.
Any stale fixture discovered in a preservation run is reported separately before
changing it; no operational fallback is allowed to make a fixture pass. Tests
run only in a fresh private review environment with network/process refusals and
bounded Node evaluation, no model construction or application startup.

## Completion and remaining acceptance

Freeze source/test hashes plus original RED and final GREEN receipts for root and
independent review. This maker cannot grade its own implementation. Real native
required-selection, keyboard/focus, desktop and 390px dialog checks require a
separately reviewed/authorized owned-browser increment after source freeze; no
browser launch is included here. Do not reuse a harness that only visits Twins
with selection unconfirmed and call that physical-dialog acceptance.

Lesson to retain: a calibration dropdown is an operator assertion. A convenient
default or value retained across openings silently invents a fresh assertion;
requiring an explicit choice must not be described as verifying its truth.

## Root-approved local feedback precision, before code

Root read the complete packet and approved the two-file product correction.
The initial 16-case RED was 10 failed / 6 passed in 1.73s, private `mkhdlrn4`,
session12758 exit1 (external I/O0, Node15, Git0). The first implementation passed
16 in1.48s, private `nvwar3wa`, session15252 exit0 with the same refusal counts.
The original RED remains attributable to the baseline above.

Source inspection then found that the existing subject banner is outside the
native modal: focusing the calibration field alone does not make its rejection
message readable. Root approved this exact additive precision before further
product edits: one form-local `role="status"` paragraph, associated through the
calibration select's `aria-describedby`. Clear its text on each permitted open
and each current submit after the original selection fence, before validity.
Due/failed/unknown use the same fixed text and focus; preserve the global
selection/error flow and all existing assertions. No new modal framework or
layout change. Add two state cases (reopen clears local text; rejected then
explicit-current pending submit clears it), plus strengthen existing markup and
three noncurrent cases to prove the local association/message. Native visibility
must still be verified in the later real-browser gate; DOM ancestry is not a
screenshot claim. The completed focused inventory is therefore18 cases.

## Frozen implementation and technical receipts

Root approved the local-feedback addition and the test-only intake fixture
migration. Product ownership stayed at the same two files.

| Stage | Result | Private suffix / session |
| --- | --- | --- |
| Original RED |10 failed,6 passed,1.73s; I/O0,Node15,Git0 | `mkhdlrn4` /12758 exit1 |
| Initial GREEN |16 passed,1.48s; I/O0,Node15,Git0 | `nvwar3wa` /15252 exit0 |
| Local feedback RED |6 failed,12 passed,1.80s; I/O0,Node17,Git0 | `j5661ln3` /20052 exit1 |
| First preservation |68 passed,1 failed,11.78s; I/O0,Node67,Git0 | `zinrus85` /43839 exit1 |
| Final preservation |**69 passed,11.74s**; I/O0,Node67,Git0 | `hkdr4gdf` /32062 exit0 |

The preservation failure was the inherited intake VM's missing
`mountSelectionReconciliation`, before form behavior. Root approved only:
import/mount the actual recovery helper, supply current window page-event,
AbortController and clearTimeout globals, explicitly stub its actual strict GET
at `/api/twins?limit=10`, and assert exactly one such GET. Every original
five-clock, consent, source-toggle and submitted-body assertion remains.
Original authored422 POSTs still create no record. No runtime fallback changed.

Final SHA-256:

| File | SHA-256 |
| --- | --- |
| `lib/subjects.js` | `b35b6aa4e1277eef95ac128ff64f93d874cfb589d3d992c7554927f1f001e95a` |
| `twins.html` | `32d70f6a0fec0ffeb0bfde0de6a12b9589c6f708e31e601bcf272214c8fd96cf` |
| `test_physical_pairing_calibration_ui.py` | `56dac16c669c093dd7b115e995af778b3bcf16ea6ad9fbfdfe6ce59fd7cec4ed` |
| `test_person_intake_ui.py` | `df451a83230d56dfc70dec85ed7b02aaba800a69b7bd757229ff17d9472b7366` |
| Unchanged `test_selection_reconciliation_ui.py` | `64d5417dcf8247ffe217e2c1e98e6ec50803f0772cdb240c56db62dccd8dfea8` |

69 =18 new +49 unchanged selection recovery +2 intake cases. This is not native
validation, backend binding or full-v3 acceptance. No actual browser, service,
device, operational store, model construction or native numerical work occurred.

### Exact independent-repeat command

CWD `/Users/emman/Livemore/.worktrees/full-scope-recovery`. Only known Node eval
shapes are admitted, under original12/15s child timeouts and default OS45s alarm.
The inherited bare node is mapped to the pinned binary, not PATH discovery.
These refusals are bounded test instrumentation, not an OS sandbox claim.

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - livemorebio/tests/test_physical_pairing_calibration_ui.py livemorebio/tests/test_selection_reconciliation_ui.py livemorebio/tests/test_person_intake_ui.py <<'PY'
import os,socket,subprocess,sys,urllib.request,ctypes,signal
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1';os.environ['PYTHONDONTWRITEBYTECODE']='1'
signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
esm_prefix='import {createRequire as __reviewRequire} from "node:module";const require=__reviewRequire(import.meta.url);\n'+prefix
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1;permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if isinstance(cmd,list) and len(cmd)==4 and cmd[0] in ('/opt/homebrew/bin/node','node') and cmd[1:3]==['--input-type=module','-e']:
  counts['node']+=1;permit=True
  try:return run0(['/opt/homebrew/bin/node',*cmd[1:3],esm_prefix+cmd[3]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=line',*sys.argv[1:]])
print('Refusal counts:',counts,flush=True);signal.alarm(0)
raise SystemExit(status)

PY
```

## Proposed smallest native browser gate — not launch authorization

Root independently read the full changed form/controller, all183 lines of the new
test and the complete migrated intake fixture. Its guarded repeat passed69 in
11.87s, private28dg0y0y/session9318 exit0, I/O0/Node67/Git0. Narrow software
acceptance is clear. Root approved preparation of the four-image native scenario
below; actual browser acceptance is still pending and no launch has occurred.

Do not rerun the accepted legacy16-image scenario. Reuse the existing
`check_legacy_preview_browser.py` private-environment, actual authored modeless
registry fixture, constructor-denying three-service bootstrap, source/process
fences, fixed8910–12 preflight and independent owned cleanup. Its ACTIVE,
observation-only REAL_HUMAN-shaped record is labeled not a participant; no device
or calibration entry needs storing.

Propose a separately reviewed fixed physical-calibration scenario in the existing
browser harness, preserving its default legacy scenario, limits and16 originals.
The alternate needs a small four-image receipt/case schema. Use the current
pinned gstack Playwright/owned Chrome mechanism, no shared profile, no new browser
framework, no module/content rewrites and no old unbounded intake runner.

- Only ordinary `/twins`, inspected static dependency closure, protected
  build/services/current-state metadata, population capabilities and
  `/api/twins?limit=10` GETs. Source/process/technical-context pins before and
  after. Block every POST and unknown request before forwarding; zero mutation.
- Desktop1280×900: open actual Pair physical Patch; verify modal/device focus,
  empty required calibration, readonly2.0/B0 and declaration/evidence-limit copy.
  Capture initial dialog. Fill only authored device/firmware/attestation strings.
  Native-click submit with blank calibration: invalid event/validity, calibration
  focus and zero POST. Keyboard-select Due and submit: local exact feedback,
  modal retained, accessible association and actual visible readable text.
  Capture desktop rejection.
- Keyboard-select Current but do not submit. Escape/close and reopen; prove
  empty choice, cleared feedback/fields, device focus. This does not claim a
  successful pairing; the positive unchanged POST is a technical test only.
- At390×844, capture upper dialog/copy. Repeat native blank validation and
  keyboard-select Failed rejection. Native-scroll the dialog if needed; verify
  no horizontal overflow, calibration focus and visible lower local feedback.
  Capture mobile rejection, then close/reopen and verify empty/reset again.
  Four original PNGs total. Preserve partial rows and bounded failure image.

Root/independent pure-harness review precedes launch. Native checks and ordinary
images, not the authored DOM, decide this slice. No actual pairing POST means
this does not close physical API/SDK/CLI or v3 parity. Manifest, authorization,
receipt stores, calibration authority, hardware safety and all-page QA remain.
