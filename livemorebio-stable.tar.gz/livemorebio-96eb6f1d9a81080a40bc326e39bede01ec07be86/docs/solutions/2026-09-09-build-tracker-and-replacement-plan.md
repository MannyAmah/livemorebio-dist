# Build tracker and complete replacement paths

Date: 2026-09-09. Branch: `codex/full-scope-recovery`.
Authority: Emmanuel explicitly requested proceeding, a timer and accurate tracker,
and complete alternatives for repeatedly failing paths without shortcuts.
Scope mode: HOLD SCOPE. R01–R51 in the September 8 master register remain active.
Phase start: **2026-09-09T12:57:59Z**, obtained from the clock at this turn's start.
This is elapsed calendar time for this build phase, not historical project time,
agent compute time, biological time, or a completion estimate.

## Office-hours: problem, premises and alternatives

The founder cannot see what actually changed, what is being worked on, and what
still blocks the product. Repeated low-level attempts have consumed time without
producing whole-product acceptance. A task counter must not conceal that fact.

Existing sources: the stable 51-row master register; September 9 build-status
response ownership, Biology recovery and OSP initialization decision records.
The installed product and stores are preserved. No tracker currently exists.
Prior-art search found related evidence/progress receipts, but no reusable board.
gbrain, Context7, sequential-thinking and CE tools were searched and are not
callable in this session. Written local plans and independent agent review are
the fallback; no claim that those unavailable tools ran.

Alternatives evaluated:

1. Conversation-only table and timer: least code, but no persistent ticking view
   and status can be lost across messages. Insufficient for this request.
2. Read-only local progress board: selected. Real elapsed timer, saved status,
   current lanes, completed verified increments, original requirements and six
   experiment videos. No coupling to the biological product or its auth/store.
3. Add project management inside the Aegle dashboard: rejected for this increment;
   would add clutter and couple development status to an already fragile surface.

The user has already chosen preservation, complete alternatives and the existing
full product scope. No new taste question or scope reduction is needed for the
read-only board. Product replacement architectures require separate source-based
plans and review before implementation; this document does not silently approve
a new scientific model, weaken evidence gates, or deploy a service.

## Selected tracker design

Standalone private loopback page, neutral typography and teal accents, separate
from the Aegle/Cendos/LIFE dashboards. No external scripts/fonts/telemetry. The
first screen shows elapsed phase time, status freshness, current work and completed
verified increments. Then the six videos and a collapsible complete R01–R51 list.
Do not compute a percentage from test counts or imply 0 accepted requirements
means no code exists. Partial work remains visibly partial.

```text
reviewed progress JSON + unchanged master requirement register
                    | read-only, fixed paths
                    v
loopback tracker server --> browser: timer / lanes / evidence / all 51 rows
                    X no biological API, patient store or model mutation

page load -> loading -> valid saved snapshot -> fresh / stale / paused
                     \-> error (retain last valid snapshot, label unavailable)
timer = max(0, now - phase_start); session state never inferred from timer
```

Recorded activity is a manually published checkpoint, not an agent heartbeat.
Show its exact UTC last-update time and age. After five minutes without an update,
show **Update overdue; current activity unconfirmed**. On final handoff, publish
**Paused between turns**. The elapsed phase clock continues, labeled calendar
elapsed; no promise of autonomous background work. Refresh data periodically
without overlapping requests; abort each request after a bounded timeout. JSON
errors must be visible and never overwrite good data with guessed progress.

## CEO review, all sections

1. Architecture: independent read-only surface; reuse the original register
   directly, avoiding 51 manually copied acceptance definitions. No product route.
2. Error map: read/parse/validation failures return a generic unavailable state;
   fetch timeout and rejected response keep the last good snapshot with a warning.
3. Security: serve only fixed board assets and status; bind loopback; no directory
   listing, arbitrary paths, CORS, POST, query-driven reads, tokens or clinical data.
   Status text rendered with textContent, never injected HTML.
4. Interaction: filter completed/current/remaining; expand the requirements;
   reload and narrow-screen use must preserve truthful counts. Empty filters have
   explicit no-matches text. Timer is not an aria-live once-per-second announcement.
5. Quality: small standard-library server and browser-native UI, no new framework
   or production dependencies, no global product fetch wrapper reuse.
6. Tests: red-first parser/required-ID/time/status checks; real local HTTP and
   browser tests for timer, filtering, all 51 rows and update propagation.
7. Performance: one status request every five seconds, 3-second timeout, bounded
   payload and 51 rows. No database/network scientific work to show progress.
8. Observability: exact snapshot revision/time, stale/error/paused states; saved
   tracker data is the handoff record. No access log containing payloads or paths.
9. Rollout: open private board only; previous product unchanged. Rollback is to
   stop this board's own process. No data migration or external publication.
10. Future: reusable across subsequent turns by updating the saved checkpoint;
    no replacement for model validation or issue acceptance.
11. Design: timer/status first, current work second, evidence and full scope below.
    Keyboard labels, visible focus, responsive cards, no dashboard duplication.

No new product scope proposed. No new uncontrolled background work. No release
approval implied. The goal is visible accountability, then verified product work.

## Engineering review and test plan

New paths only: `tools/build_tracker.py`, `tools/build_tracker/` assets/data and
`livemorebio/tests/test_build_tracker.py`. The master requirement table is read,
not rewritten. Existing biology/auth/native code remains unchanged for this packet.

```text
fixed read -> parse JSON + 51 master rows -> validate -> response -> safe DOM
     |          |                           |              |
 missing     malformed / duplicate      fail closed    retain last-good + error

timer(now,start) -> nonnegative h:m:s -> DOM text
filter(state) -> selected entries -> explicit empty state
refresh -> one request -> response/error/timeout -> next scheduled refresh
```

Required tests before acceptance:

- Exactly R01 through R51, no duplicate/missing IDs; parse titles/acceptance from
  the existing register and preserve original status separately from lane status.
- Six fixed experiment identities; no metformin/lobeline substitution.
- Snapshot validates timezone-aware timestamps, allowed stage/evidence states and
  full requirement references. A completed increment requires an evidence note.
- Invalid/missing JSON/register, unknown path, traversal/query/POST refusal;
  generic errors never expose absolute paths or contents.
- Only board assets are served, loopback binding, no directory listings/CORS.
- Browser timer advances; start epoch and recorded timestamps survive reload;
  stale/paused/error states not displayed as active. No fake progress percentage.
- Actual current/done/remaining filters and requirement expansion, desktop/mobile
  screenshot inspection, no horizontal overflow or browser errors.
- Status update appears without reload; invalid update doesn't discard last good
  state. Expired request aborts and requests cannot overlap.
- Independent code/test review; root inspects original browser screenshots.

Failure table:

| Failure | Handling | Test / visible result |
| --- | --- | --- |
| Missing or invalid source | OSError / ValueError -> fixed 503 | Unavailable, no secrets |
| Duplicate or missing scope | ValueError -> fixed 503 | No false completion |
| Unknown URL / query / traversal | Fixed 404 | No source tree browsing |
| Attempted mutation | Fixed 405 | No writes |
| Network / timeout | Catch failed fetch, bounded abort | Last-good + warning |
| No update for five minutes | Derived stale label | Activity unconfirmed |
| Agent turn ends | Explicit paused checkpoint | No background-work claim |

## Parallel lanes and replacement decision gates

- Root: tracker plan, implementation, browser inspection and scope maintenance.
- Independent reviewer: tracker plan then code/test review, no maker grading.
- Browser lane: replace bootstrap-fetch/global wrapper architecture, preserve
  same-origin/HttpOnly/CSRF/CLI compatibility and supported deployment topology.
  Navigation-first bounded sessions are a candidate, not yet implemented.
- Scientific lane: separate one-shot direct OSP .NET backend candidate, preserve
  source semantics, units, oracle, resource/cleanup/security/admission gates.
  Do not alter or retry the consumed R/CLR packets. SDK availability is a gate.

For repeated failures: preserve evidence, identify the failing architectural
boundary, compare independent alternatives, choose a complete replacement for
that boundary, red-first tests, independent review, then a meaningful real test.
Do not repeat old attempts under renamed folders, disable checks or lower the
scientific bar. A replacement failing repeatedly triggers a new decision, not
another automatic retry. Missing controlled data/rights/physical measurements
cannot be fixed by substituting invented data.

## Not in this tracker increment (still in full product scope)

No production auth changes, native scientific execution, new experiments, public
hosting, package release, PR or production deployment. Those remain in their
original R01–R51 lanes; they are not waived or declared done by this board.

## Review and acceptance record

Written before implementation. Independent startup_origin review found two
clarifications, both accepted as necessary to preserve the existing scope:

- Requirement partitions are exhaustive/disjoint: only master ACCEPTED is done;
  checkpoint-declared active IDs are current; all other IDs (partial, blocked or
  unmapped included) are remaining. Original master status is also retained.
  Completed increments are displayed separately, not counted as accepted R-items.
- Six experiment walkthroughs are R40; the separate full-product demo R41 is a
  seventh visible recording requirement, not absorbed into the six count.

Allowed lane stages: planned, reviewing, building, implemented, verified, blocked.
Verified is a software/evidence increment only and requires a nonempty evidence
note. It never means human equivalence. Session states: working or paused.
These clarifications clear the tracker plan for red-first implementation under
the user's already explicit proceed request. No unresolved tracker scope choice.
The existing September8 approved plan remains source of scope; this adds
visibility and user-authorized alternative strategy, never replacement scope.

### Implemented and independently checked

The first new-feature run failed before the tracker files existed (1370f5).
The implemented 14-case suite passed; independent review required the live
checkpoint age promised above. That correction was red-first (356fd3), then
green (64e67b). Final independent review returned CLEAR and independently
repeated **14 passed in 1.23 seconds** (ae7779). Pins at that independent review:

- tracker.js SHA256 `2f9c2c758b739f1836a596106e5058b76a395e4b78e957bc89b17d087cae5568`.
- test_build_tracker.py SHA256 `4b17ee0da0f63f45329e67e6fdec8e9aa96c963e5757b6e3802574aee38e9030`.

Root subsequently added one test of timeout/rejection, last-good error retention
and stopped-poller behavior without changing runtime code. The extended suite
passed **15 cases in 1.29 seconds** (5a7ed8). This additional test is root evidence,
not an independently repeated 15-case result; the 14-case review pin above is
historical and must not be mistaken for the current test file's hash.

Root's separate actual-browser QA at `http://127.0.0.1:8865/` verified advancing
time and checkpoint age, automatic overdue marking, current/verified/remaining
filters, expansion of exactly 51 requirement rows, all seven recordings and no
horizontal overflow at 1280x900 and 360x800. Warning/error logs were empty.
Revision 3 appeared without a page reload after revision 2 had been inspected.
Original desktop/mobile screenshots are in `docs/screenshots/build-tracker/`.
These are tracker checks, not acceptance of the biological product.

The gstack browser helper exited 137 before a page opened; it was not retried.
The available in-app browser control provided the actual interaction and visual
inspection. No participant store or clinical API was touched. The standalone
server is read-only and explicitly does not continue agent work after a turn.

### Compounded lesson

Always separate validated increments from broad requirement acceptance. A useful
progress board preserves the original scope, shows evidence and freshness, and
never turns an elapsed timer or a count of tests into a claim of biological
readiness. Replacing repeated failures must change the failing architecture,
not erase its receipts or reduce its acceptance criteria. CE tooling is not
available in this session; this local docs/solutions record is the explicit
memory-layer fallback, not a claim that an unavailable command ran.
