# Registry audit-phase correction — frozen maker evidence

2026-09-08. Ready for independent grading; not accepted by its maker. Implements
the [approved phase proposal](2026-09-08-committed-registry-audit-phase-correction-proposal.md),
SHA256 `0a1d6ff0755ed6cc4a0634475f2e652c2553197da553b8ba439a6c36ef0a0079`.
The [independent findings](2026-09-08-committed-registry-audit-phase-independent-review.md)
and earlier terminal-correction report remain unchanged. Their earlier green
tests do not negate the subsequently reproduced phase defects.

## Frozen write set and lineage

| File | Before this correction | Current SHA256 |
|---|---|---|
| `livemorebio/aegle/subjects.py` | `3778a837877b57623112549884a379930c348987942d83d1ed6d2e53d29dd51a` | `acef1a8562482f0504f7ff6430d949245e8c7d828a681044ed4d9fd4c90ce473` |
| `livemorebio/tests/test_committed_registry_transitions.py` | `f3cb3a549b4e0c99ffb6096c838468399c19249047407201ca444195ce01b22e` | `f4c5a74467f381546beea4d78bf3567dc6f69f08fb07bd28f94fe1da491fc323` |

`registry_audit.py` is unchanged at
`b21f01fdf1c79604c5565fee0f7d94d3b0bd11967b199bc97ec8a193de045e4e`.
No other runtime, scientific input, output, threshold, gate, source, service,
startup, server or UI file was edited. No operational stores were accessed.
The separate stored-version maximum amendment is not implemented in this packet.

## Exact correction

The immutable `_SelectionAuditOrigin` retains the existing reservation and exact
BEGIN tuple immediately after the existing audit owner has verified its origin.
There is no new audit schema, AAD, quota, table or public return contract.

`_selection_raw_baseline` reads the target plus the **current** pointer target
(at most two records), pointer absence/value/timestamp, relevant device row and
bounded ACTIVE topology. Pointer metadata is bounded before record lookup.
It reads ciphertext/index bytes only, never clinical payloads.

The three fixed primitives are `_selection_audit_begin`,
`_selection_audit_reenter` and `_selection_audit_finish`. They own no connection
commit/close. BEGIN checks authority and a fresh raw baseline before the existing
audit writes, then exact BEGIN/reservation and raw state after the last write.
Re-entry verifies the original BEGIN and exact reservation under the writer lock
before protected decryption. Finish checks expected raw state before writing;
after the existing verified finish it checks authority, original BEGIN, verified
terminal, absent reservation and raw state last. The same rows remain the
mutation's exact read-only lost-ACK witness.

The private fixed `_selection_read_access` owner replaces only the common read
path for activation, patch-binding and preview-clear preparation. Its BEGIN is
committed before decryption; writer re-entry precedes `_transition_snapshot`.
Read SUCCESS must leave the relevant raw state unchanged. A prepared result is
not returned after a lost acknowledgment or close failure. Uncertain rollback
does not attempt failure completion. Confirmed rollback permits a bounded failed
access completion using a **new live-pointer scope**, not the former prepared
IDs. A bad completion rolls back and preserves the primary error/pending origin.

`commit_prepared_transition` reuses these phases, preserving its existing
before/after transforms, device indexes, exact terminal witness, mutation commit
outcomes and no-retry behavior. The global `_audited` and old unchecked families
are untouched. Preparation stays structural; profile/model construction is not
moved under authority or database locks.

## Retained red/green evidence

The 70 additive `selection_phase` cases were written before the runtime patch.
Independent test-design reading found no material fixture blocker, but did not
run them or assert that all 70 should fail. The actual pre-fix result was
**57 failed, 13 passed, 114 deselected in 4.32 s**, private root
`livemore-research-review-6cwn63f8`. Existing earlier protections explain the
13 passes; the failures exposed the missing phase checks and safe read-failure
classification. Original 114 dedicated cases were preserved.

After implementation:

| Packet | Result | Private root |
|---|---|---|
| All dedicated cases | 184 passed in 6.16 s | `livemore-research-review-apq7rjs8` |
| Expanded preservation | 458 passed, 4 deselected in 22.99 s | `livemore-research-review-5r3doj2w` |

The expanded packet emitted one existing Starlette/httpx deprecation warning.
The four `real_process` bootstrap tests were deliberately excluded, not passed
or silently allowed to spawn. Each run recorded zero unexpected network/child
attempts and one explicitly refused optional Git metadata lookup. All three
outer test processes finished. No model, native solver, browser or service ran.

The additive cases cover BEGIN/reservation/terminal/delete trigger writes to
target, selected row, pointer, device and ACTIVE topology; changed/deleted
reservation and BEGIN sequence before decryption; lost read-BEGIN/terminal ACKs;
close and rollback uncertainty; absent or malformed pointers; all three
preparation entrypoints; and a genuine second SQLite connection changing the
selected record after rollback before malicious failure-completion writes.
That last fixture checks the newly selected row and exact primary error, no
ACCESS_FAILED success, retained reservation and exactly two protected opens.

## Exact expanded invocation

From `/Users/emman/Livemore/.worktrees/full-scope-recovery`, the invocation below
reuses the reviewed environment preparer while installing process-wide refusal
before pytest. No new runner file is required. The pytest module is also loaded
as the constructor/numerical/network refusal plugin. The omitted real-process
cases must not be re-enabled under this packet's authorization.

```sh
/Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B - <<'PY'
import os, sys, signal, socket, subprocess, urllib.request, multiprocessing.process
from tools.run_review_stack import prepare_review_environment
root, env = prepare_review_environment(inherited={k: os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ})
os.environ.clear(); os.environ.update(env)
os.environ['PYTHONDONTWRITEBYTECODE']='1'; os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
blocked=[]; metadata=[]
def deny(*a, **k):
    blocked.append('unexpected'); raise AssertionError('Registry review forbids network and child/native work')
def process(command, *a, **k):
    if command == ['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
        metadata.append('refused'); raise OSError('Authored unavailable Git metadata')
    return deny()
def audit(event, args):
    if event in {'os.fork','os.forkpty','os.posix_spawn','os.exec','subprocess.Popen','socket.__new__','socket.connect','socket.getaddrinfo'}: deny()
sys.addaudithook(audit); multiprocessing.process.BaseProcess.start=deny
socket.socket.connect=deny; socket.getaddrinfo=deny; socket.create_connection=deny
urllib.request.urlopen=deny; urllib.request.OpenerDirector.open=deny; subprocess.Popen=process
import pytest
signal.alarm(60)
print('PRIVATE_REVIEW_ROOT', root, flush=True)
files=['test_committed_registry_transitions.py','test_subject_registry_audit_contract.py','test_registry_bootstrap_contract.py','test_registry_bootstrap_shape.py','test_clinical_descriptive_registry.py','test_real_cohort_contract.py','test_selection_reconciliation_registry.py']
nodes=['test_virtual_patch_binding_retains_admitted_protocol_version','test_only_authoritative_twin_remains_active','test_physical_patch_pairing_requires_active_consented_human_and_attestation','test_active_twin_survives_registry_restart_and_physical_device_cannot_double_pair']
rc=pytest.main(['-q','-p','no:cacheprovider','-p','livemorebio.tests.test_committed_registry_transitions',*[f'livemorebio/tests/{f}' for f in files],*[f'livemorebio/tests/test_subject_lifecycle.py::{n}' for n in nodes],'-k','not real_process','--tb=short'])
print('REVIEW_IO_COUNTS',len(blocked),len(metadata))
signal.alarm(0)
raise SystemExit(rc)
PY
```

For the retained RED run the pytest arguments selected the dedicated file with
`-k selection_phase`; for dedicated GREEN the same file was selected without
that filter. The environment and refusal wrapper were otherwise the same.

## Limits and lesson

Independent code grading remains pending. This packet does not accept startup,
old observation/reconciliation families, arbitrary audit-only callers, server
publication, UI, physical onboarding or clinical/model readiness. It does not
change the six requested programs or rehabilitate either failed insulin result.

The investigation lesson is phase-local: final mutation correctness cannot undo
a clinical side effect already committed with an earlier audit BEGIN. Every
committed audit phase needs its own bounded unchanged-state witness; re-entry
must authenticate the exact reserved access before decrypting. Failure cleanup
must scope the current selected row after rollback, not trust stale prepared IDs.
The unavailable CE compound tool was not claimed as run; this durable report
retains the executable regression and lesson locally.

## Independent phase review — 2026-09-08

The non-maker UI/review agent read the complete approved 244-line phase proposal,
269-line prior independent findings, this maker report, all 895 lines of the
dedicated tests, the complete audit owner, and the affected preparation,
validation, phase, commit, witness and wrapper consumers. The three frozen
runtime/test hashes listed above matched both before and after review.

One explicit isolated repeat completed with **458 passed, 4 deselected, one
existing Starlette/httpx warning in 22.73 s**, exit 0. Interpreter:
`/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python`, Python 3.11.15. Private root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-q8m5qost`.
The exact expanded test list above was used with the constructor refusal plugin,
both urllib refusals, socket/DNS and low-level fork/exec/spawn/subprocess refusal,
and multiprocessing start refusal. Final counters were **0 unexpected attempts,
1 explicitly refused optional Git metadata lookup**. No native model, browser,
HTTP request or operational store was used. The four `real_process` cases remain
unexecuted in this review.

An earlier isolated invocation in `livemore-research-review-bbvncmh0` exited, but
its final output was unavailable after the reviewer's context handoff. No result
is claimed for that invocation; the repeat above was explicitly labeled before
execution rather than silently substituting for it.

No remaining actionable blocker was identified in this **bounded audit-phase
correction**. Source and tests verify unchanged-state checks before each durable
BEGIN/read completion, retained append-origin/reservation verification before
protected decryption, trusted terminal verification after reservation deletion,
and a fresh current-pointer baseline for failed completion after confirmed
rollback. The pre-existing exact mutation lost-ACK witness and terminal cleanup
classification remain in place. The earlier phase failures are not erased by
this result; they are addressed by the specific new guards and regressions.

The separately raised possibility of profile construction during structural
activation admission was checked against the actual consumer chain.
`resolve_model_context` validates primitive fields and returns canonical bytes
inside `ResolvedModelContext`; it does **not** access that object's `profile`
property. `ensure_cohort_executable` only performs descriptive marker/shape
admission checks. No profile-construction defect was established in this path,
so no speculative admission removal or migration is recommended. For precision,
the existing plugin denies `initialize_profile`, `admitted_human`, `build_twin`
and `generate_members`; it does not directly replace `MetabolicProfile.__init__`.
Present purity is supported by the full source trace and the supported-reference
authority regression, not a claim that every possible future constructor is
already instrumented.

This clearance does not grade startup, old observation-selection/reconciliation
or global `_audited` consumers, server publication/retirement integration,
stored-version maximum changes, physical hardware validity, or clinical/model
qualification. Those dependencies remain separate, as in the maker report.
