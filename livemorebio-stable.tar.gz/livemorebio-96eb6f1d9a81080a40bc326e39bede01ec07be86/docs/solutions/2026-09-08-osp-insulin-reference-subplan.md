# R11/R33: pinned OSP exogenous-insulin integration subplan

Date: 2026-09-08. Parent: [full R01–R51 scope](2026-09-08-full-scope-recovery-plan.md).
Status: STAGE A ISOLATED NATIVE FEASIBILITY EXECUTED, 2026-09-08.
Root approved Stage A after reading this plan. A private extracted runtime and
public source case2 executed outside product stores; see the
[actual feasibility report](../OSP_INSULIN_NATIVE_FEASIBILITY.md).
Stage B subsequently executed and **failed numerical/domain acceptance**; see
[the retained result](../OSP_INSULIN_STAGE_B_RESULTS.md). Independent arithmetic
review reproduced that failure. The later source and technical-fixture reviews
do not overturn it. Stage C product wiring remains gated on a separately reviewed
scientific correction and new benchmark; this original subplan is retained as
the historical implementation sequence, not a current readiness claim.

## Decision and scope retained

Use the source authors' whole-body glucose–insulin–glucagon PBPK/PD model as the
first exogenous-insulin execution candidate. Keep the existing metabolic engine,
metformin, Human-GEM and saved histories intact. Do not insert a guessed insulin
term into the existing three-state engine or count an endogenous-insulin trace
as an exogenous-insulin experiment.

The first source reproduction is the intravenous insulin tolerance test (IVITT).
The exact historical insulin preparation is not established by the repository's
README. Source inspection during execution corrected an earlier assumption:
case2 IVITT administers the model molecule `Insulin`, which shares its observer
with endogenous insulin; the separate `Insulin Ex` pool is not this intervention.
It does not establish a modern named analogue. The reference protocol must be labelled historical exogenous
insulin, intravenous, source-defined potency convention. A later commercial
regular-human-insulin protocol requires verified preparation, potency conversion,
formulation and applicability. Do not call this lispro, aspart, glargine or a
subcutaneous depot model. This unresolved material detail remains part of R33/R35.

R33 is not closed by native reference reproduction. Meaningful individualized
cohorts, multiscale inspection, analysis, video and independent physical comparison
remain required. The five candidate programs in the linked source record remain
in scope; none is replaced by insulin or a convenient isolated assay.

## Evidence and local runtime inventory

Full source/rights record: [OSP and candidate sources](../OSP_INSULIN_AND_CANDIDATE_SOURCES.md).
Read before implementation: [biological change contract](../BIOLOGICAL_MODEL_CHANGE_CONTRACT.md).

Read-only checks on this host found macOS 26.4.1, ARM64. `R`, `Rscript` and `dotnet`
were absent from PATH. No R framework or .NET installation was found at the
standard locations inspected, and Homebrew reported no installed R/.NET formula.
No unrelated private directories were searched. This is a bounded inventory,
not proof that another nonstandard installation cannot exist.

Candidate source pins:

| Component | Pinned candidate | Meaning |
|---|---|---|
| GIM model and author recipe | `17a7f8eaac8d6c3e3f49d0a6e0fe6101e4bc3e18` | Current model repository HEAD inspected; do not call it release v1.0, whose tag points elsewhere. |
| OSPSuite-R | `v12.4.3`, commit `315014f54e27ff7da73a4f4fb16a83d914266c9b` | Stable release, native core matching OSP12 update3. |
| rSharp | `v1.2.2`, commit `3a8686e70c700437b451a01216ad4fb2990e432c` | Stable release targeting .NET8; installed package alone can succeed without usable .NET. |
| R | `4.6.1`, ARM64 | Official signed/notarized macOS package candidate; compatible R-major/minor with published binary metadata. |
| .NET runtime | `8.0.30`, `osx-arm64` | Official supported runtime candidate for pinned native packages; maintenance support ends 2026-11-10. |
| Remaining R package dependencies | LOCK PENDING | Resolve exact versions/hashes in isolated R library before benchmark; do not use moving `@*release` or R-universe latest at ordinary execution. |

Current OSPSuite-R main is `41db4b5b41bd2f7bedd9864ff83eca0871c6aed9`, reporting
`13.0.0.9008` and .NET10. It is NOT selected or interchangeable with the stable
12.4.3/.NET8 pair. The 12.4.3 README omits macOS from its support list, but its
source/release contains native Mac libraries. Header inspection of its
`libOSPSuite.SimModelNative.dylib` and CVODES library confirms ARM64 Mach-O.
Thus native Mac feasibility needs an actual load/solve probe, not a blanket
unsupported-platform conclusion. Desktop PK-Sim/MoBi GUI parity is separate.

## Source recipe, units and contradictions

The inspected `GIM_Healthy.xml` is OSP `Simulation` version4 in namespace
`http://www.systems-biology.com`, not SBML. It contains 1,100 variables,
1,475 observers, 33 events and 14,027 formulas. These are XML element counts,
not claims of 1,100 independent physiological states or validated mechanisms.

For author recipe case2:

1. Apply the `Global` and `Healthy` parameter workbook sheets.
2. Preserve `initExact=1`, including source insulin sensitivity `S_I=0.9`.
3. Disable source applications; calculate 1,000 minutes of initialization.
4. Transfer final independent species values to initial values, leaving
   formula-defined initial conditions dependent. Do not overwrite those formulas.
5. Activate IVITT at t=0 for three minutes. The author's conversion is
   `0.04 * 7e-9 * 5808 * 1e-3` kg/kg for the dose-per-body-weight parameter.
   This is a historical recipe, not present-day administration advice. Its
   7nmol/IU convention must be explicit, not silently replaced by another factor.
6. Observe the 0–200 minute source grid and preserve full solver settings.

Important discrepancies and limits:

- README continuous infusion says 150 minutes. Code case3 sets a 1,440-minute
  infusion starting at t=20 and observes until t=200. Keep case3 unavailable for
  a claim of exact 150-minute reproduction until adjudicated. A faithful code
  reproduction and a corrected experimental protocol must have different IDs.
- Case2 and case3 use different source-specific sensitivities (0.9 and1.1).
  They are not two measured people or an empirical parameter distribution.
- The script sets a local weight variable to73kg. Changing it alone is not
  evidence that all organ volumes, flows and dose conventions change correctly.
- Source initialization has special basal insulin support for its T1DM cases.
  A T1DM baseline must not omit that infusion and be described as matched.
- The exported peripheral-venous plasma glucose, insulin and glucagon observers
  use µmol/L. Author figures divide glucose by1,000 to mmol/L and multiply
  insulin by1,000,000 to pmol/L. Do not relabel those values as mg/dL or µU/mL.
- The repository provides measured-reference spreadsheets and a prediction
  figure, not a numeric author prediction golden file. Numerical migration
  equivalence and agreement with physical data are different checks.
- The private Stage A probe parsed the `.xls` files with pinned R `readxl`1.5.0:
  Global is empty, Healthy has37 parameter rows, and IVITT has11 glucose and12
  insulin reference points. No spreadsheet macros were executed. These are
  source-distributed digitized references, not newly collected measurements.

## Implementation sequence after explicit root review

### Stage A: native feasibility probe, before product behavior

1. Resolve the remaining dependency lock and exact licences. Check the signed R
   installer, official runtime digest and release package hashes. Use no academic
   credentials or restricted source licence bypass. Inspect archive paths and
   native architecture before extraction/loading.
2. Install only after root approval. Prefer an explicit R4.6.1 installation plus
   a private .NET8.0.30 directory and private R package library. If R framework
   installation requires administrator interaction, stop for that action; do not
   silently install a global replacement, change shell profiles or switch OS.
   Microsoft documents user-directory runtime extraction. A Linux worker is an
   explicit alternative requiring a reviewed runtime/deployment choice.
3. Verify `rSharp::dotnetAvailable()` and a native OSP smoke model, not just
   `library(ospsuite)`. A load-only success is insufficient in rSharp1.2.2.
4. Inspect and parse the model and workbook in the private workspace. Enumerate
   units, parameter paths, species/formula dependencies, solver values, events
   and workbook sheet values before constructing the translated recipe.
5. Run the unmodified source model with an original, reviewed translation of
   the author case2 recipe. Do not execute the downloaded MATLAB script.
   Record the native/model versions, output paths, event schedule, elapsed time,
   peak memory, input hashes and full numerical results in a reference report.

The feasibility probe is one process, one reference recipe, no personal data,
no device command and no network required during solve. Initial watchdog budget
proposal: 300 seconds per recipe and one worker at a time. Measure memory before
choosing a production limit. A timeout is a failure with retained evidence,
never grounds to manufacture a shorter successful trace. This budget is a
proposed execution bound, not a performance or scientific claim.

### Stage B: source benchmark acceptance, before Aegle integration

Required before any software-ready status:

- Model bytes, native architecture, all dependency versions and unit mappings
  match the admitted manifest; rejects checksum, version or dimension mismatch.
- Healthy no-intervention initialization is stable according to a criterion
  preregistered before viewing intervention results. Check derivative/drift,
  nonnegative concentrations within declared numerical tolerance and no NaN/Inf.
- Case2 events, sensitivity, initial-condition dependency handling and source
  conversions match the script line by line in independent review.
- Run numerical convergence at tighter tolerances/output grids. Predeclare a
  scaled-error criterion and reference quantities before evaluating acceptance;
  preserve failures. Output-grid interpolation alone is not solver convergence.
- Compare native direct execution against the future adapter at identical
  native output times. This tests transport/configuration equivalence, not
  independent biological validity. No source prediction golden numbers are
  currently available; do not invent them.
- Compare glucose and insulin with the pinned physical-reference spreadsheets:
  report residuals, RMSE, bias and peak/nadir timing with data provenance and
  digitization limitations. No automatic human-qualification pass threshold
  can be derived from the same results being evaluated.
- Use IVITT absent/zero-dose, wrong-unit, wrong-parameter-path and disabled-event
  controls. Wrong configuration must fail or produce the appropriate unchanged
  calculation, never the expected intervention curve from stored artwork.
- Retain held-out/source-other-protocol work separately. CIVII disagreement is
  not erased by calibration; T1DM cases require their actual workbook and
  reference data before being enabled.

An independent reviewer must approve a benchmark packet with tolerances and
context of use before Stage C. Numerical reproducibility alone does not prove
human equivalence, dose safety, clinical suitability or physical-device parity.

### Stage C: connected product implementation packet, still to be reviewed

Proposed new owned modules only: an OSP asset/worker boundary and a Cendos insulin
protocol module, using existing immutable `ProtocolRunStore`, SDK/shell and
authenticated Aegle/Cendos routes. Root owns shared server/UI integration.

Input contract: pinned model identity; exact protocol ID; author parameter-set
identity or independently admitted parameter snapshot; intervention material,
route, units and event schedule; output selection/grid; native tolerances;
source/subject/cohort identity and provenance. No arbitrary R code, file path,
URL or unvalidated XML in a public API. Unknown interventions reject.

Output contract: immutable run and parent IDs; separate native simulation and
wall-clock time; member/condition/model/snapshot identity; quantity, compartment,
unit and values; native solver status; source/parameter provenance; reference
residuals and applicability. Model outputs remain modeled. Reference-data
overlays remain physical-reference data from their original studies, not newly
collected Cendos measurements or observations of the selected twin.

The worker must be launched with an allowlisted environment and isolated data,
scratch, R library and .NET locations. Include every mutable path in
`tools/run_review_stack.py` and isolation tests. Never inherit operational PHI
stores, credentials, `.Rprofile` or an arbitrary current working directory.
Bound worker concurrency/time/output size; preserve cancellation/failure history.
Untrusted XML must reject DTD/external entities and external resources. rSharp's
native runtime config enables unsafe BinaryFormatter serialization, so no
untrusted serialized .NET/R objects may be admitted across this boundary.

### Stage D: individualized experiments and visual acceptance

The source model's healthy/T1DM parameter groups are not a sampled human cohort.
Build a person-parameter mapping with jointly admissible measurements, uncertainty,
missingness and held-out endpoints. Require parameter identifiability before
fitting; do not independently randomize organ flows, volumes and clearances.

Show each requested member, paired control/treated condition, exact run clock and
relevant computed compartments. Only display receptor/cellular/organ states that
the admitted model actually computes and that have validated mapping semantics.
Static anatomical reference is not an atomistic or morphological trajectory.
Insulin plasma is not a physical patch channel unless a specific sensor/assay
and calibration are qualified. LIFE predicted observations remain modeled, with
residuals versus independently admitted measurements and no automatic retuning.

Acceptance includes browser preparation, visible error handling, native execution,
member/condition inspection, history recall/rerun, CSV export, executed notebook
and detailed actual-interaction recording. Tests also cover cross-subject async
responses, stale context, cancellation, restart and absence of test data in a
fresh installation. These must be independently inspected, not maker self-graded.

## Blocker ledger and full-scope accounting

| Blocker | Affected requirements | Required resolution | State |
|---|---|---|---|
| Product runtime and installer integration | R11,R12,R33 | Private R/.NET/package lock and native solve demonstrated; product installer/security review pending | OPEN; Stage A feasibility passed |
| Stable Mac README/artifact discrepancy | R11,R13 | ARM64 native solve demonstrated; independent numerical benchmark still pending | OPEN; native execution demonstrated |
| Legacy XML v4 migration and initialization mapping | R08,R11,R33 | Native SimModel XML interface avoids high-level PKML conversion; independent recipe review pending | OPEN; isolated recipe executed |
| Historical potency/formulation; CIVII schedule contradiction | R33,R35,R36 | Source adjudication; distinct historical/corrected protocol IDs | OPEN |
| No numeric author prediction golden trace | R12,R33,R48 | Native migration comparison and honest reference residual report | OPEN |
| Patient-specific parameter distributions and physical validation missing | R16–R18,R31,R33,R36,R39 | Admissible data, identifiability and prospective validation | OPEN |
| Five botanical human response models/PK links incomplete | R07,R10,R34–R37,R40 | Candidate-specific systems and independently supported parameters | OPEN |
| Controlled-data/solver/restricted-source entitlement unknown | R11,R13,R14,R16–R18 | User/institution authorization and access-specific architecture | OPEN |

No blocked requirement is removed, deferred to an easier demonstration or marked
accepted. Runtime/core support for .NET8 ends soon; a separately benchmarked OSP13
migration is needed before depending on this candidate beyond that support window.

## Durable lesson

Read executable recipes, model units and binary metadata as well as README prose.
Here the code contradicts the advertised infusion duration, and release artifacts
support an ARM64 feasibility path omitted from an older README. Catalogue entries,
successful imports and visually plausible curves each answer a different question.

## Review record

Source author: source-research lane. Root Stage A plan review: APPROVED.
Independent implementation/recipe review: PENDING. Native feasibility: EXECUTED.
Numerical migration/physical qualification benchmark: NOT ACCEPTED.
No gbrain, context7 or Compound Engineering tools were exposed in this session;
local prior-art records and official documentation were used. The browse skill
executable failed with exit137; available web/source retrieval was the fallback.
