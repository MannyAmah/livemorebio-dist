# OSP startup refusal: retain the facts that were rejected

2026-09-09. Proposed diagnostic correction only; independent pre-code review is
pending. The preserved CA533x native technical attempt remains FAILED at S01.
No new native run, numerical model admission or scientific experiment is
authorized here.

## Proven defect

Root read the complete independent startup-failure diagnosis and retraced
`tools/osp_semantic_supervisor.py` process classification, execution sampling,
cleanup and admission. The primary refusal is UNEXPECTED_DESCENDANT, but the
rejected process identity was discarded: `_check_processes` runs before rows
are retained. A failed list-comprehension sample also discards earlier sampled
rows. The actual rejected child's identity cannot be reconstructed or guessed.
The process policy is not shown to be wrong; its diagnostic evidence is missing.

## Small correction proposed before implementation

Preserve every current refusal predicate and process/time/disk/privacy limit.
Add a separate bounded **unadmitted candidate** record for the first failed
owned-group observation in each of the work and cleanup phases, including the
successfully sampled rows, the
fixed phase (work or cleanup), the failing PID if sampling failed, and the
classification or sampling code. Do not promote candidates into accepted
`process_observations` or evidence of authorized execution. Existing resource
monitoring must remain active even for a subsequently rejected process; resource
usage and process admission are separate facts. Do not retain environment strings,
arbitrary exception messages, unrelated processes or unbounded history.

The intended change is a small sampling/retention helper shared by work and
cleanup. Explicitly sample one owned PID at a time so an exception cannot erase
earlier facts. Retain no more than the existing 64-identity history ceiling;
refuse overflow without silently truncating it to an acceptable group. Keep the
existing argument count/length validation and add a serialized evidence bound
inside the current packet limit. Preserve an earlier primary refusal even when
cleanup sampling also fails, with both phases separately labeled. Exact row
contents are evidence of observation, not authorization to run that executable.

Tests must fail before the change for a rejected complete set, a partial sample
failure and cleanup failure after a primary. Add identity-history/byte bounds,
no-environment-tail and accepted-versus-candidate separation cases. Repeat the
existing offline OSP process/ownership/portability/budget tests without starting
R, dotnet, an OS inspector or any model. No sampled child is allowlisted merely
because it appeared in a rejected record.

After independent implementation review, a separate once-only native technical
decision may be proposed with the updated source pins. That is not authorized
by this plan. Preserve all old source receipts, the consumed marker, the original
failure and S02–S17 NOT_RUN; do not republish them as successful evidence.

Lesson carried forward: fail-closed admission and diagnosable rejection are
separate requirements. Losing rejected facts prevents a justified repair and
encourages unsafe guessing. Record facts with their status before drawing a
conclusion, while leaving all execution gates closed.

## Independent pre-code findings

The independent reviewer identified two required precisions. Root accepts both;
implementation remains pending a concrete budget/retention design:

1. Account against the actual inner writers: 256 KiB for an inspector receipt
   and 1 MiB for a case result, including embedded inspector receipts. Reserve
   compact failure metadata. A diagnostic overflow must remain an explicit
   failure with a retained receipt, not become EVIDENCE_WRITE_FAILED that loses
   the original reason. Do not raise either writer limit to fit new diagnostics.
2. Carry a fixed sampling substage. PROCESS_ARGUMENTS currently covers both
   sysctl capture and argument-parser failures. Preserve the existing primary
   error code but separately identify the fixed stage; never save an arbitrary
   native exception message or environment buffer. Partial observations must
   not count as a complete group sample.

Both need authored offline cases before a source correction is implemented.
The reviewer ran no tests or native tools. All original failed receipts and
closed execution gates remain unchanged.

## Concrete bounded option for the next implementation decision

The reviewer recommends two immutable private sidecars per execution:
`process-failure-work.json` and `process-failure-cleanup.json`. Each has a
64 KiB ceiling: reserve 4 KiB for fixed failure metadata and no more than
60 KiB for whole sampled rows, using the existing encoder. Metadata preserves
phase, primary code, fixed substage, failing PID, enumerated/sample/retention
counts and explicit completeness/overflow. A retained subset is never passed
to classification or counted as a complete sample. Never silently omit a row.

Compact parent references carry fixed basename, bytes, hash and retention state.
Sidecars preserve the triggering facts independently if an inherited outer
result-size failure occurs. They do not claim that inherited oversized outer
results now fit. At most six sidecars across the worker and two inspectors add
384 KiB, within—not on top of—the existing 4 MiB case/directory limits. Use the
existing restrictive, atomic non-overwriting writer. A failed sidecar write must
itself remain explicit; filesystem availability cannot be guaranteed.

The fixed sampling substages are GROUP_ENUMERATION, OS_SETUP, INITIAL_USAGE,
BSD_IDENTITY, IMAGE_PATH, ARGUMENTS_CAPTURE, ARGUMENTS_PARSE and IDENTITY_RECHECK.
Keep original primary codes, all admission predicates, resource monitoring and
gap checks. Do not record native exception strings or environment tails.

Root retains this as a concrete next option, not an implementation or native-run
authorization. The molecular private diagnostic is the current active increment.

## Root implementation decision — after molecular diagnostic settlement

The molecular once-only run has finished and all eight owned closes settled;
root's exact 20-PID postcheck found no remaining process (`84d30e`). Root has
read the concrete sidecar proposal, independent diagnosis and current sampling,
classification, directory-budget and writer paths. The bounded evidence-retention
option above is now approved for red-first implementation only.

Scope: `tools/osp_semantic_supervisor.py`, a new dedicated offline test file,
and this plan's maker receipt. Preserve `_check_processes` predicates, existing
accepted-record meaning, primary error strings, all ceilings, native source and
closed gates. Use the existing Python standard-library interfaces. A first work
failure and a subsequent cleanup failure must have separate immutable records;
partial or overflowed candidate records are never valid process admission.
Account the reserved sidecar allowance within the existing case bytes and entry
limits, including both inspectors and atomic pending-file overhead. Do not erase
the original primary if evidence writing or cleanup fails. Retain fixed status
and fixed sampling stage, never exception text or environment contents.

Before changing implementation, demonstrate the missing records with authored
RED cases. Add fail-closed cases for complete rejected groups, partial sampling,
byte/history overflow, first-failure preservation, writer failure, and ongoing
cleanup/resource checks. Keep all inherited tests intact unless root separately
approves a demonstrated assertion-contract correction. Run only isolated offline
tests with native/process/network entry points refused. No R, dotnet, vmmap,
native library or model invocation, and no actual OS sampling is authorized.

Independent root source/test review and an independent repeat are still required
before acceptance. No successor native invocation is authorized by this decision.
The CA533x packet remains FAILED; no insulin program or any candidate experiment
becomes enabled by diagnostic evidence retention.

## Maker receipt — frozen for independent root review

Implemented only the supervisor and new dedicated offline test file. The first
23 authored cases failed against the preserved original supervisor before source
editing (`85aa3f`). Six additional reservation/ownership boundary cases were
subsequently checked against that exact preserved original and also failed
(`25133f`); they required no additional implementation changes. The final frozen
29 new cases plus all 524 inherited offline cases passed: **553 PASS, 2 native
watchdog cases deselected**, zero unexpected I/O (`23e9dd`, completion `0815a0`).
The independent root repeat and source/test grade remain pending.

The helper writes only the first failed owned-group observation in each work and
cleanup phase to separate immutable sidecars. Full versus partial sampling and
complete versus overflowed retention are explicit independent fields. Parent
references carry fixed names, original codes, byte counts, hashes and write/
retention states. Write failure is recorded once and never replaces the original
process primary or silently retries an existing file. Whole rows use at most
60 KiB of each 64 KiB sidecar; fixed metadata has a separate 4 KiB check.
Accepted observations and retained candidate rows share the 64-identity ceiling.

Worker and both inspectors share one six-slot case reservation through the
existing outer-tick ownership path. Conservatively reserving each final name and
its atomic pending name uses **768 KiB and 12 entries inside the existing 4 MiB
and 256-entry ceilings**. Actual final/pending files remain in the ordinary
directory traversal; only the consumed, non-retryable slot releases its reserve.
Tests cover all six writes, actual atomic link visibility, failed unlink retaining
both names, existing-file refusal, and actual nested `_execute` budget sharing.

Complete resource samples are counted before policy classification; partial
samples never reset the complete-sample gap. Resource, stream and directory checks
continue after sampling or classification rejection, including cleanup after
initial identity stabilization fails. Sampler exceptions retain their original
class/code plus one fixed stage. No environment tail or arbitrary native/write
exception text is retained.

Static preservation (`6e0831`) checked 515 source/test files. Only the authorized
supervisor and new test file differed. `_check_processes` is byte-for-byte exact;
every original module-level assignment, including limits and both closed gates,
is preserved. The only changed existing functions are `process_sample` and
`_execute`; the added helpers are private evidence/reservation functions. Existing
tests, native collectors, numerical sources and original receipts were not edited.

Frozen SHA256 values:

| Artifact | SHA256 |
|---|---|
| `tools/osp_semantic_supervisor.py` | `af735907d6eeb1ab4d158cc9a365d61e4af6f71d8c2e3b70afe4631b5b398dd6` |
| `livemorebio/tests/test_osp_rejected_process_evidence.py` | `6a7796e30da70c3aac33f8d9f7ca179162bd39bf77695fe1051e42af20829c2c` |
| original supervisor | `8f8c1f66be57f0466a4481fc5cc1b095e6ed47a3e01564f850ae9cf0aa17b79a` |
| `supervisor.diff` | `5c1fa33561f687b18137a33355e6dc75219215a7a472bbc54a18f46f8ad6cbd0` |
| `red.txt` | `80e779823d1a495986f1fedc51a7b311a39e58c0a5b0921f97c962d18a28dd5e` |
| `red-reserve-original.txt` | `777b179874e635d158bb7ec42379b61661103b9759c459a06631296a3338765f` |
| `green-final.txt` | `7b10b1a2a566734c93530854f5fae399ea97a1b53137c1ca1b6a0e6afa684909` |

Private generated evidence, original source copy, complete diff, logs and the
preservation result are in `/private/tmp/livemore-osp-evidence-offline.jIUyrq/`.
No browser, actual process sampling, R, dotnet, vmmap, native library, model,
commit, push or successor native run was performed.

Remaining limits: this is authored offline verification, not OS/runtime proof.
Filesystem write failure remains possible and explicit. Sidecars survive an
inherited outer-result size refusal, but this amendment does not redesign that
outer writer. Candidate row overflow preserves bounded whole rows and explicit
omission counts, not missing identities. Directory monitoring remains sampled,
not hard isolation against concurrent child writes. CA533x remains FAILED and
its rejected descendant remains unidentified.

Exact independent repeat command, from this worktree:

```bash
PYTHONDONTWRITEBYTECODE=1 /Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B - <<'PY'
import os,sys,signal,socket,subprocess,urllib.request,multiprocessing.process
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:v for k,v in os.environ.items() if k in ('PATH','HOME','TMPDIR','LANG','LC_ALL')})
env.update(PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1');os.environ.clear();os.environ.update(env)
counts={'unexpected_io':0}
def deny(*a,**kw):
 counts['unexpected_io']+=1
 raise AssertionError('Unexpected network, native load, or child in offline OSP evidence tests')
for owner,names in ((socket,('socket','create_connection','getaddrinfo')),(subprocess,('Popen','run','call','check_output')),(urllib.request,('urlopen',)),(multiprocessing.process.BaseProcess,('start',))):
 for name in names:setattr(owner,name,deny)
def hook(event,args):
 if event in ('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.exec','ctypes.dlopen'):deny()
sys.addaudithook(hook);signal.alarm(45);print('Private test root:',root,flush=True)
import pytest
code=pytest.main(['-q','-p','no:cacheprovider','--basetemp',str(root/'pytest'),'--tb=short','livemorebio/tests/test_osp_rejected_process_evidence.py','livemorebio/tests/test_osp_inspector_budget.py','livemorebio/tests/test_osp_vmmap_format_contract.py','livemorebio/tests/test_osp_semantic_supervisor.py','livemorebio/tests/test_osp_semantic_probes.py','livemorebio/tests/test_osp_source_admission.py','livemorebio/tests/test_osp_stage_b.py','livemorebio/tests/test_osp_stage_b_analysis.py','tools/diagnostics/osp_vmmap_retained_forensics.py','-k','not native_watchdog'])
print('Refusals:',counts,flush=True);signal.alarm(0)
raise SystemExit(code or bool(counts['unexpected_io']))
PY
```

## Independent root implementation review

Root read the complete 15,453-byte supervisor delta, complete 20,739-byte new
test file, and surrounding process policy, resource, directory, execution,
cleanup, inspector and admission paths. No critical defect was found in this
bounded diagnostic correction. Sidecar status remains UNADMITTED, partial
sampling does not reset the complete-sample gap, first-phase failure is immutable,
and the original primary survives write/resource/cleanup secondary failures.
Final and pending names remain charged to the existing directory traversal;
unused reservation covers six writes across the worker and nested inspectors.
This is not hard filesystem isolation or a guarantee of available evidence disk.

Independent source check `554f25` verified every frozen source/log hash above,
the exact unchanged `_check_processes`, all 19 original module assignments,
and protected-file changes limited to the two authorized files. Only
`process_sample` and `_execute` changed among existing functions. Root did not
modify maker implementation or tests.

Independent invocation `ced91d`, completion **`61995d`**, repeated the same
29 new + 524 inherited offline cases with the established private Python
environment: **553 passed, two native watchdog cases deselected in 1.65 s**,
zero unexpected I/O. Private test output root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-yu7jdxfz`.
Network, process launches and native loading were refused; authored process
fixtures do not establish actual OS startup behavior.

The narrow implementation is independently clear. No native retry is authorized
by this receipt. The next decision must first assess the once-only launcher's
source pins and evidence handling against these new sidecars. Original CA533x
remains FAILED, the rejected descendant remains unidentified, scientific gates
remain closed, and all six required experiment recordings remain outstanding.
