# Beard precision v2: recorded numerical pass, independent grading pending

2026-09-08. The single authorized v2 matrix returned `NUMERICAL_PASS`, process
exit 0, with H3 as the prespecified candidate. All seven branches and five
required comparisons passed their unchanged output gates. This is a maker's
retained-evidence report, **not final independent acceptance**. Root and the
independent reviewer still grade the complete arrays and source evidence.

Evidence class: `MODELED_REFERENCE_MECHANISM`. Physical qualification: false.
No compound, person, cohort, device, clinical observation or product activation
was part of this execution. The [failed v1 result](../BEARD_NATIVE_SOURCE_MATRIX_RESULTS.md)
remains failed; it was not replaced or rerun.

## Fixed scope and authority

The [v2 preregistration](2026-09-08-beard-native-precision-v2-preregistration.md)
was frozen at SHA-256
`68ff48a84ce6ca51828dbc2034322ada2c51ac4875b53a6fb8f1f6b4685ea758`.
Its prospective wording remains unchanged as historical evidence. Subsequent
implementation, supervisor, OS-probe and exact-driver approvals are separate
records, not edits to those numerical criteria.

Root authorized driver SHA-256
`7414173690d1aaebf4895498d281949f8cd698152abb2498b5c2a8c7b667ac13`
under authorization ID `beard-precision-v2-matrix-root-review-2026-09-08-01`, after
the [fixed OS-only probe](2026-09-08-beard-precision-os-probe-results.md).
The driver ran once in private storage. Its receipt records 29.048461 seconds;
the inner matrix records 28.040923 seconds. These scopes include preparation
and analysis, not just native integration.

The exact PMR Beard 2005 source remains commit
`8ec69b34c31cd1cbb53580d1853841bb333de78e`, CellML SHA-256
`4a4f931592df0e77a92c79447bf6d8947c7325f721a74b4d336d370abaaf3981`.
Source constants, units, equations and initial state were unchanged. This is
the pinned PMR variant, not an unannounced corrected-paper parameter set.
The conversion record retains 47 components, 339 declarations, 28 units,
65 equations, 226 equivalence edges, 19 states, 47 literal constants,
12 computed constants and 34 algebraic outputs, with zero analyser issues.
Custom `cell`, `cytoplasm` and `mitochondria` dimensions were retained.

## Seven branches and five acceptance comparisons

All advances used CVODE BDF, serial vectors, dense linear solve and binary64.
Scalar ATOL is numerical in each state's own unit, not a shared physical
measurement error. Configuration calls returned success.

| Branch | Recorded outputs | RTOL / ATOL | Maximum step | Native steps / generated RHS calls |
| --- | --- | --- | --- | ---: |
| I2a | Initializer only, no sample/RHS | Not advanced | Not applicable | 0 / 0 |
| I2b | t=0, one sample/RHS | Not advanced | Not applicable | 0 / 1 |
| P2 | 0–300 s, 3,001 samples | 1e-11 / 1e-15 | Unbounded default | 2,049 / 6,044 |
| P3 | 0–300 s, 3,001 samples | 1e-12 / 1e-16 | Unbounded default | 2,884 / 7,185 |
| H3 | 0–300 s, 3,001 samples | 1e-12 / 1e-16 | 0.01 s | 32,184 / 45,700 |
| R3 | H3 repeat, 3,001 samples | 1e-12 / 1e-16 | 0.01 s | 32,184 / 45,700 |
| K3 | 150–300 s, 1,501 samples | 1e-12 / 1e-16 | 0.01 s | 15,002 / 21,256 |

All 13,506 recorded samples have complete finite 19-state, 19-rate and
34-algebraic arrays. Grids equal the exact expected integer index/10 seconds,
without duplicates or omissions. Native raw rows equal their retained parsed
results. I2a separately passed the original initializer/computed-constant gate.

Each comparison checks all 19 states and 34 algebraic outputs using
`|a-b| / (absolute_floor + 1e-6 * max(|a|, |b|))`; acceptance requires a maximum
no greater than 1. Floors remain H:1e-12 M, other concentrations:1e-10 M,
potential:1e-4 mV, flux:1e-9 mol/(s·L mitochondrial volume), free energy:1e-8 kJ/mol.
Rates retain their separate source-expression checks, not concentration gates.

| Required comparison | Pairs | Maximum normalized error | Failures | Worst output / time |
| --- | ---: | ---: | ---: | --- |
| P2 ↔ P3 | 159,053 | 0.0768018977765 | 0 | J_F1 / 5 s |
| P3 ↔ H3 | 159,053 | 0.00633789661743 | 0 | J_F1 / 3.4 s |
| P2 ↔ H3 | 159,053 | 0.0768236108206 | 0 | J_F1 / 5 s |
| R3 ↔ H3 | 159,053 | 0 | 0 | Exact numeric agreement |
| K3 ↔ H3 | 79,553 | 0.00000270736211988 | 0 | J_F1 / 178.5 s |

`J_F1` is `ATP_synthesis_flux.J_F1`. P2/P3/H3 use the same solver implementation;
their agreement is not an independently coded solver or exact-solution proof.

Required historical diagnostics each contain 159,053 pairs and remain outside
v2 acceptance aggregation. B1↔P2 has 18 failures, maximum **8.03675468859**;
B1↔P3 has 18, maximum **8.03736304034**; B1↔H3 has 18, maximum
**8.03745483048**. All worst cases are J_F1 at 4 s. Complete failures and
per-identity maxima remain in the matrix. These diagnostics do not rehabilitate
v1 or make its B1 trajectory a ground truth.

## Source, domain, clocks and checkpoint

The execution's original-MathML checks reported no failures at every recorded
sample, including constants, rates and algebraics, under the frozen source
expression gates. Domain/conservation checks reported zero output uncertainty
or failure, including strict redox-partner nonnegativity, matrix adenylate and
Mg accounting, fixed oxygen and the exact-zero nucleotide subspace.

Negative *trial-evaluation* occurrences were retained: P2 73, P3 103, H3 1,077,
R3 1,077 and K3 500. The most negative recorded concentration minimum was
−7.099236996815172e-18 M, in intermembrane free ADP/ATP algebraic quantities in
P2. Some Mg-binding trial algebraics were also slightly negative. No recorded
output concentration was negative. These small trial values are numerical
diagnostics, not physical concentrations; no clipping or new exemption was
introduced. Internal error-test rejections were 60/67/60/60/0 for P2/P3/H3/R3/K3;
they were recovered CVODE steps, not hidden run failures. Nonlinear convergence
failures were zero in each branch.

P2 and P3 internally stepped to 440.7541058633 s and 342.2585712929 s while
returning their final requested sample at 300 s. Their default maximum-step
policy explicitly permits this normal-mode interpolation. H3/R3 internally
ended at 300.0068907805 s; K3 at 300.0019830434 s. All bounded-branch sampled
clocks passed the original 0.01 s plus 32-ULP clock allowance. The largest
reported H3/R3 last step was 0.010000000000000002 s, retained without rounding.
These records sample solver diagnostics at requested outputs, not every internal
step. The comparison challenges integration and interpolation jointly.

K3 checkpoint SHA-256 is
`8a9b520a0ef09e25400cbc658587db9d9571a3dffc6cef3946b6d087e61edd8c`.
It binds H3 raw output, input manifest, source/units, index 1500 and t=150 s.
All 19 ID-bound states and all first-sample rates/algebraics match H3 bit-for-bit;
47 constants and 12 computed constants agree exactly. The separate K3
`initialization` record deliberately records the original source initializer.
The reviewed wrapper restores the checkpoint before its first RHS; that original
initializer record must not be mistaken for the restored start. This is a fresh
CVODE state restart, not restoration of its multistep history.

The source's external ATP/ADP/AMP and five intermembrane nucleotide states remain
zero, as preregistered. This specialization **does not test ATP export**. It also
does not test arctigenin exposure, target inhibition, a drug response or tissue
coupling. No steady-state criterion or biological equivalence claim is added.

## Runtime, resource and cleanup evidence

Runtime: libCellML 0.7.0; SUNDIALS 7.8.0; Apple clang 21.0.0; macOS 26.4.1 ARM64,
build 25E253. The pinned runtime-manifest SHA-256 is
`775e5190a01bfbf0408efe1e1c76b5e502cd645fff65df6e28e212d7f0d025f2`.
Source/generated/compiler/linked-library identities were retained. Ordinary
branch binary SHA-256 is
`e96cc76ececfd941dbc526fc5a23a56aa9435b9b13d929d6c017e095c9f1bdd9`;
the checkpoint-bound K3 binary is
`65fc3b19b882380e86eddb9a6ec8adf7b3e76b8173f5f1f8221c016a5f4cd58a`.

Seven native supervised invocations summed to 2.124787 s and reported 0.742911 s
CPU. Native wall durations were 0.205388–0.377947 s. Across 155 resident samples,
the maximum sampled RSS was 7,634,944 bytes; largest actual sample gap 17.091333 ms,
requested 10 ms; observed overshoot zero. The 1 GiB rule is a **sampled soft
threshold, not hard memory isolation**. Native bounds remained wall 120 s,
CPU 60 s, files 64 MiB, 10,000 steps/output and 1,000,000 generated RHS calls.

Seven compiler invocations summed to 1.800321 s, each within its separate 30 s
wall limit. Compiler RSS was not measured; native RSS/CPU protection must not
be attributed to compilation. All native/compiler stderr streams were empty.
All 14 receipts record exit 0, established ownership, no live owned-group member
before reaping, successful reaping and no cleanup/signal-restoration error.
The driver unresolved-child slot is null. A later read-only process check found
all 14 recorded compiler/native PIDs absent.

## Evidence identities and review boundary

Private root: `/private/tmp/livemore-beard-precision-once.pyzqUN`.
Matrix directory: `livemore-beard-precision-matrix-rg_pbv3s`.
These are retained evaluation artifacts, not an operational installation path.

| Artifact, relative to private root unless stated | SHA-256 |
| --- | --- |
| `driver-result.json` | `7560350be840b32722340af0dc7c63feba961457b38d2cadb617f8ab83a33081` |
| Matrix `matrix.json` | `65bc4ceefd7b70f6fa17952d0cb12c3e223a75aa8ab3283d6eb7b5fe94a9d7b4` |
| `admission.json` | `7246d4a9ccc2b12d12ced9f6d0ccaa1d349a000849a9a6de4af7f737050cc264` |
| `execution-authorization.json` | `7b3c468b56f2081f2e9d489ce43f339edb1ca2f34ea563cb94e1cb171cb29292` |
| H3 `H3.stdout` | `50881d352e073e62eee3c4df45be652749b40292b82c325dc0038c70eaf7f725` |
| H3 `result.json` | `ac6a6e211e8da908347bd2537368a3ca191e65a8e208471e9d61b670940c13e4` |
| K3 `K3.stdout` | `7106c0825900ffe4966a296323e45ac6d59b08f10072ea27bfe2819d463f2fd7` |
| K3 `result.json` | `b7d28ead509344a3da62ae8415f4aca813f1e96fea075780ee0ee715f8652b3b` |

This reporting pass checked all branch raw/prepared-file/binary hashes, all
28 raw stream receipts, exact grids/finite shapes, checkpoint digest/input and
bitwise first-sample restoration, driver/matrix agreement, current reviewed
code-file hashes and cleanup records. It did not import a source evaluator,
recompute equations, compile, advance a solver or change a gate. Full independent
cross-run arithmetic and scientific grading are pending separately. All three
on-disk execution/evaluation gates remain false.

Next: independent numerical evidence review, then a separately approved decision
on source replication and the next mechanism contract. An independent solver,
author/reference-data replication, corrected-paper variant, compound-specific
potency/PK mapping, tissue context and physical validation remain open. Exogenous
insulin and all five botanical programs, Erinacine A, sterubin, carnosic acid,
arctigenin and C3G, remain required; this mitochondrial result completes none
of their individualized experimental programs.

Lesson: stricter numerical settings can settle derived outputs without changing
biology or relaxing output gates. Preserve the failed earlier method and its
historical discrepancies, and keep numerical agreement separate from physical
truth. Documentation evidence checks do not let the maker grade its own model.

## Independent retained-evidence grading — 2026-09-08

The independent reviewer completed the previously pending grading above and
accepts **bounded `NUMERICAL_PASS` for this fixed reference method**. This section
supersedes only the report's pending-review status, not any frozen protocol,
earlier failure or qualification limit. Root received and accepted this review.

The review used independent Python standard-library arithmetic on saved raw
stdout and JSON, not the maker's comparison/evaluation functions. It recomputed
all **715,765 acceptance pairs** and **477,159 historical diagnostic pairs**.
Every per-identity maximum and complete failure ledger exactly matched the
matrix. All five acceptance comparisons passed; R3/H3 output agreement was
exact. All three historical comparisons retained their 18 failures, and v1
remains `FAILED`.

The reviewer also checked:

- Complete expected grids and finite 19-state/19-rate/34-algebraic arrays for
  all 13,506 samples; raw rows matched retained parsed rows.
- Nonnegative output concentrations and all six redox partners, exact-zero
  intermembrane nucleotide states/rates and fixed oxygen, matrix adenylate/Mg
  sums, redox reconstruction, bound-versus-total pools and open nucleotide
  balance using retained values. No output uncertainty was hidden or clamped.
- All 66 literal state/constant initial values against original XML; exact
  membership/units of 339 aliases and the 226 original equivalence edges.
- Every advanced output's configuration/clock requirements, including the
  bounded branches' original 32-ULP allowance. Unbounded P2/P3 internal-time
  overshoot remains explicitly reported above.
- Checkpoint/input digest and source/unit lineage; the 19 qualified states and
  hexadecimal checkpoint header, all constants/computed constants, and K3's
  first states/rates/algebraics matched H3 at 150 s bit-for-bit. The separately
  recorded K3 source initializer was not misread as its restored start.
- All 28 stream hashes/lengths, 14 compiler/native ownership/cleanup receipts,
  private file/directory modes, source/generated/binary hashes, 11 frozen code
  hashes, 69 pinned runtime-file hashes and exact once-only authority/schedule.
  All recorded driver and 14 child PIDs were absent at the read-only check;
  the unresolved-child slot was null and all three on-disk gates remained false.

This review did **not** import a model/evaluator, re-evaluate original MathML,
compile or run a native child, repeat a solve, change flags, or touch product or
participant state. Original-MathML/expression and trial-domain checks are the
retained zero-failure execution receipts from the previously reviewed frozen
implementation, not a newly repeated independent expression evaluation. Native
RSS remains sampled soft protection; compiler RSS was not measured.

The independently checked matrix digest is
`65bc4ceefd7b70f6fa17952d0cb12c3e223a75aa8ab3283d6eb7b5fe94a9d7b4`;
driver-result digest is
`7560350be840b32722340af0dc7c63feba961457b38d2cadb617f8ab83a33081`.
No compound, person-specific, physical, published-source replication or
independently coded solver qualification follows from this numerical acceptance.
