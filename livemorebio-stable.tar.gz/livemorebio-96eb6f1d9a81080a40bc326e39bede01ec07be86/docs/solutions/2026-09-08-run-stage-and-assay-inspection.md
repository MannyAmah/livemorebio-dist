# Run-bound stages and nonhuman assay inspection

Status: implementation and targeted exploratory checks, not final release QA.

## Decision

Keep Atlas as the whole-person overview. Its Biology links carry the authenticated
state coherence token; Biology rejects a changed/missing requested context rather
than showing another twin's state. The token establishes response coherence, not
scientific qualification. Unregistered organ assets remain in the separate inspector.

For frozen Cendos experiments, use one selection contract for run, member, condition,
native axis, biological quantity/unit and provenance. Stage selection is a read-only
inspection operation. Unsupported molecular and tissue stages remain unavailable.
Metformin glucose, insulin and remote insulin-action X are distinct saved quantities;
X is not receptor signaling. PXR concentrations and Human-GEM constraints are not time.

Lobeline has its own nonhuman assay inspector. The rat-striatal-vesicle context,
lobeline-hemisulfate material and stationary initial-rate contract are explicit.
The source's 8-minute uptake endpoint normalized per minute is not an observed
instantaneous rate or an executed time trajectory. The model/source Km discrepancy
is retained. No human/cohort binding, physical comparison gate or live-twin calibration
is invented. The VMAT2 schematic is reference context, not atomic coordinates.

## Regression lessons

- Validate zero separately from missing data. Zero substrate gives zero rates and an
  unavailable rate/control fraction, not a fabricated zero fraction.
- Validate the exact protocol evidence class, not a `MODELED` string prefix. Existing
  PXR records use `STRUCTURE_AND_IN_VITRO_BACKED_MODEL`.
- Preserve recorded units and all paired samples. An absent unit, boolean, incomplete
  paired array, ambiguous member or unordered clock cannot become a complete trace.
- Keep selected-point provenance focused. Do not duplicate every trajectory sample in
  a raw source drawer on every playback frame.
- Returning from an unavailable stage must restore the correct native-axis explanation.
- Restoring a Cendos preparation never executes it; explicit Run creates a new immutable
  result with parent lineage. New experiment resets preparation, not history.
- An open transport is not a fresh state. Validate the workspace schema, coherence token,
  required render structures and finite aligned trajectories before replacing the last
  good immutable snapshot. A rejected SSE event or failed refresh pauses playback and
  retains the prior timestamp with a visible stale indication. A changed context resets
  playback to T0; identical-context updates preserve the recorded selection.
- Separate action receipts from state capture: a successful action followed by an
  unavailable refresh remains a completed action with an unavailable updated view.
- Match Patch source/freshness metadata by signal and envelope digest, and confirm value
  and unit equality. Missing or contradictory metadata stays unclassified. Packet
  admission is not physical connectivity; the Atlas shortcut leads to explicit Patch
  setup, not an unbound request that silently samples mutable state.
- Frozen assay integrity includes the complete source/input concentration grid and the
  unrefitted benchmark discrepancy. Reject conflicting refit flags, missing controls,
  out-of-domain quantities and a comparator that differs from its frozen source record.

## Targeted evidence

Red-first tests were added for projection/controller behavior and Lobeline preparation.
The combined projection, inspector, existing clean-workflow, Lobeline and workspace-stream
UI run passed 82 tests on 2026-09-08, including the final context-change/record-label
review corrections. The tests use
technical fixtures or an in-memory nonhuman calculation, never physical measurements.

Exploratory `/browse` checks used the isolated `127.0.0.1:8890` review stack only:

- Cendos starts blank, Lobeline Run produces a saved result, and Biology links to that
  exact result. Inhibitor/substrate selection changes the selected saved data without
  additional experiment requests.
- History preparation restored all concentration values. Explicit rerun preserved the
  original and recorded parent lineage.
- Desktop and 390-pixel layouts have no page-wide horizontal overflow; captured in
  `docs/screenshots/measurement-integrity-atlas/`.
- No JavaScript errors in the assay path. The active Biology anatomy renderer reported
  unavailable optional graphics while numerical/cellular inspection remained available.
- The coherent Atlas cardiomyocyte link opened the matching Biology cell inspector.

Formal final `/qa`, independent review, full-suite checkpoint and recording are owned
by the release workflow and were deliberately not claimed here.

## Browser operation note

The local gstack packaged binary cannot run in this environment. The installed Bun
source CLI works. Its auto-started server inherits a short-lived CLI parent watchdog,
so separate calls can lose browser state. A dedicated source-server process with
`BROWSE_PARENT_PID=0`, its own `BROWSE_STATE_FILE`, and CLI `BROWSE_NO_AUTOSTART=1`
keeps an isolated review session. Stop that dedicated process when finished. A stop
command may report connection loss after the server has already exited successfully;
verify the process result rather than creating another browser or product stack.

Compound Engineering and gbrain tools were unavailable; this local durable note is
the fallback, not a claim that a missing skill/tool ran.
