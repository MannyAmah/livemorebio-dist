# Atlas teardown attribution — implementation review packet

2026-09-09. Maker packet for independent review, not actual-probe authorization.
Approved contract: `2026-09-09-atlas-teardown-attribution-amendment.md`, including
root's pre-code decision. Only the three authorized implementation/test files
changed in this packet. Product reader and Python supervisor remain unchanged.

## Frozen files

| File | SHA-256 |
|---|---|
| `tools/check_atlas_request_diagnostic.cjs` (641 lines) | `675d37774cc04d388dc8c3dcacf54218372a3ae5e0724ef205c55c82865b28ae` |
| `livemorebio/tests/test_atlas_request_diagnostic.py` (337 lines) | `e9ef71ba566330fd1d6c163fc1bd76fbaad76f2fb658085251fb138f079a5119` |
| `livemorebio/tests/test_atlas_skin_terminal_diagnostic.py` (449 lines) | `ab2cdd58b2dbe4bdd28ec3d613e0798acfaffb4c0e73ed8f19665edb1cfff396` |
| Unchanged `livemorebio/aegle/console/lib/atlas_reference_requests.js` | `7ad7c023571614635d196cc5b0638d195ae46b166ce4602be16eb87e4cf4b9bc` |
| Unchanged `tools/check_atlas_presentation.py` | `77982780e71188b633ade499e0f7d744e823a8f6a14a84de79ebad03e722ea76` |

Previous CJS was `91cd052b2284d5e47c6196076b59750e29ff14d563109de7d2ec7b28ae39f7fa`.
The changed source seams are the existing `createDiagnosticBudget` (line 103)
and `mainSkin` (line 414): opt-in four-role acquisition/close attribution,
fixed non-resource phase reporting, guarded existing finally calls, and the
detached snapshot copied into final evidence. Generic `main`, request reader,
metadata ACK machinery, protocol observer, requests, source pins and CLI policy
were not changed.

## Behavior and tests

The opt-in ledger reserves each exact role before its factory; duplicate or
unknown roles cannot start another factory. It retains allocation PENDING versus
REJECTED versus an owned close PENDING/REJECTED/FULFILLED. Close calls still start
CDP, page, context, browser concurrently, with no child-close await before the
parent call. Existing owner/pending sets and the combined five-second drain
remain in use; opt-in repeated finish returns the same task and adds no timer.
Late ownership/settlement is still observed, but cannot rewrite the saved JSON
snapshot. Default three-argument callers retain their existing outcomes.

Class labels are closed and message-free, including constructor-name detection
of the installed TargetClosedError shape; this never waives a failed close.
Invalid monotonic stamps or incomplete/over-limit attribution fail closed.
The four fixed phase rows hold counts/status/class only. A freeze error during
the 90-second alarm is recorded at that actual freeze call, before the enclosing
before-cancel failure; a later no-op cannot relabel it successful. The pre-cleanup
primary failure is separately retained. All already-owned closes still start
after a freeze/listener/collector failure. Evidence-write rejection remains fatal.

No timing limit changed: 90s observation, one combined 5s drain, existing 5s
evidence-write limit and 105s supervisor ceiling. No retry, second GET, serialized
teardown, new owner framework, reader cancellation change or cleanup exception
waiver. This diagnoses a future teardown outcome only: retained zpg7lltg remains
FAILED and its missing historical close error/cancellation cause stays unknown.

## RED and GREEN lineage

- Original 26 authored teardown cases: **26 RED**, 49 deselected, 2.66s, private
  `livemore-research-review-sykl9yc3`; original CJS unchanged. 26 authored Node calls.
- First implementation: **26 PASS**, 49 deselected, 2.71s,
  `livemore-research-review-y8py1fmv`; 26 authored Node calls.
- Added alarm-freeze boundary reproduced **1 RED**, 37 deselected, 0.17s,
  `livemore-research-review-l_6fzhez`: phase falsely read FULFILLED after an
  earlier freeze failure. Moved the phase record to the actual existing freeze.
- Three supplementary cases cover refused missing/unknown roles and rejected
  allocation, plus strengthened zero-resource preflight assertions. These are
  preservation additions, not claimed RED against the first implementation.
- First full repeat: **270 PASS / 1 refusal**, 20.15s,
  `livemore-research-review-3iowpumq`. An extra maker-added ctypes.dlopen refusal
  blocked the historical startup fixture's NumPy → ctypes.PyDLL(None) import.
  No source/test was relaxed; that additional wrapper restriction was removed
  to restore the exact previously admitted offline wrapper. Retain this receipt.
- Final exact historical wrapper, all original 241 plus 30 additions:
  **271 PASS**, 2 existing FastAPI on_event deprecation warnings, **21.47s**,
  private `livemore-research-review-fyec6cnk`, command session 19665 exit 0.
  **202 authored Node invocations**, one exact optional Git lookup refused,
  zero unexpected network/process attempts. No browser, service, native model,
  numerical solve or operational store was invoked.

The final repeat includes actual runner fixtures for all existing deadline,
late-CDP, never-CDP, detach-reject/stall, metadata delivery and evidence-write
boundaries, not just helper tests. New tests cover every role's rejection and
pending close, exact invocation order, target-closed rejection after parent
start, finite/frozen snapshots, late/missing allocation, unknown errors and large
private canaries, invalid clocks, before-cancel failure, real freeze/listener/
collector faults and source-error preservation. Original assertions remain.

## Exact guarded independent repeat

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`.
The fixed authored Node tests retain their own 15-second child timeouts; the
Python wrapper has a 45-second outer alarm. It permits only their two existing
Node-eval command forms, rejects real network/process operations inside Node
and Python, and refuses the exact optional Git metadata query.

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os,socket,urllib.request,subprocess,sys,signal,pytest
from tools.run_review_stack import prepare_review_environment
kept={k:v for k,v in os.environ.items() if k in {'PATH','HOME','TMPDIR','LANG','LC_ALL'}}
os.environ.clear();os.environ.update(kept)
root,env=prepare_review_environment();os.environ.update(env);os.environ['PYTHONDONTWRITEBYTECODE']='1'
print('Private root:',root,flush=True)
signal.signal(signal.SIGALRM,lambda *a: (_ for _ in ()).throw(AssertionError('REVIEW_DEADLINE')));signal.alarm(45)
def deny(*a,**k):raise AssertionError('NETWORK_OR_PROCESS_REFUSED')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
original_run=subprocess.run;original_popen=subprocess.Popen;permit=False;nodes=0;git=0
prefix='const deny=()=>{throw Error("NETWORK_OR_PROCESS_REFUSED")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return original_popen(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit,nodes,git
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2] in (['/opt/homebrew/bin/node','-e'],['/opt/homebrew/bin/node','--eval']):
  permit=True;nodes+=1
  try:return original_run([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  git+=1;raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
def audit(event,args):
 if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit:deny()
sys.addaudithook(audit)
code=pytest.main(["-q","-p","no:cacheprovider","--tb=short","livemorebio/tests/test_atlas_metadata_delivery.py","livemorebio/tests/test_atlas_skin_terminal_diagnostic.py","livemorebio/tests/test_atlas_request_diagnostic.py","livemorebio/tests/test_atlas_browser_harness.py","livemorebio/tests/test_continuous_browser_harness.py","livemorebio/tests/test_atlas_presentation_harness.py","livemorebio/tests/test_atlas_presentation_correction_harness.py"])
print('Authored Node:',nodes,'Optional Git refused:',git,flush=True)
signal.alarm(0);raise SystemExit(code)
PY
```

## Acceptance boundary and lesson

Independent source/test grading is pending. No new browser/probe is authorized,
and this packet grants no transport-cause, rendering, physiology or cleanup
acceptance to any historical run. A successful retained metadata observation is
not the same claim as successful resource teardown. Recording each close's
actual settlement and freezing that record is the smallest way to retain that
distinction without changing the operation under investigation.

## Independent root grade

Root read the complete changed budget and mainSkin seams, the retained original
reader, every added test and this full packet. Independent repeat of the exact
guarded command above: **271 passed,21.72s**, two existing deprecation warnings,
202 authored Node calls and one optional Git refusal; session76171/chunkacf172,
private `livemore-research-review-jn1z1mdl`. No actual browser or model ran.
The four-role, detached teardown evidence is narrowly clear. This does not
resolve the original Atlas transport cause, waive its failed close, or authorize
another actual probe. The reader and all scientific gates remain unchanged.
