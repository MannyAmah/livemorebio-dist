# Precision worker — actual OS ownership probe

2026-09-08. Root-authorized one attempt of the separately reviewed fixed OS-only
packet. Scope is process supervision, not source or biological execution.

Evidence directory: `/private/tmp/livemore-beard-os-probe.p6NHRC`.
Driver SHA256: `a6d2d70d1195a393bd94502fe9a73527ebd3b3cac417e371e69d75dd471d7a3d`.
Plan SHA256: `86e7711f3613bff68ec40dca8f54fa57e22b0db1faf9e30f71b002ad4b783536`.
Result SHA256: `5de6363be1c498817f68de51c5d36425979c404fb6ee68a58025b80805f208d6`.
Admission time:2026-09-08T16:03:50.248781+00:00. Interpreter is the pinned managed
Python3.11.15 on Darwin25.4.0/arm64, imageUUID4c4c44df55553144a1fbd70a13481905.

## Actual result

Driver returned `OS_SUPERVISOR_PROBE_PASS`, exit0, elapsed1.506973333s. All18
prescribed direct children ran once: N0,D0,C01–C08,S01–S08. Ten native-policy
fixtures had valid owned-image RSS samples; eight compiler-policy fixtures had
explicitly unmeasured RSS. Zero short-exit zero-sample cases occurred, so that
branch retains its earlier technical-test evidence only. No retry was performed.

Every receipt records established ownership, observed expected exit code,
empty-group proof before leader reap, clean reap, stopped cancellation timer,
no signal/cleanup error and no unresolved child. Per-invocation elapsed values
were0.019750542–0.253929042s, below the fixed5.25s observed ceiling.

The critical D0 descendant case retained exit23 after its leader exited naturally.
Cleanup observed one live same-group descendant, sent the group termination
signal, proved no live group members before reaping the held leader, and retained
both complete stream receipts. D0 cleanup took0.016100542s; complete invocation
including timer cleanup took0.253929042s. Its17 samples peaked at15,515,648bytes.
The8s descendant failsafe was not used as successful cleanup.
D0 result SHA256: `68670604bc5a0dd8973873ed57cdd3428021b3a4d3319400a86e09d63c272df9`.

Root read all18 bounded outcome projections, full D0 receipt and admission. The
independent reviewer then compared all18 individual receipts with the aggregate,
recomputed all36 raw stream lengths/hashes, checked every code/fixture/authority
binding and the three closed on-disk gates, and confirmed the driver,18 children
and descendant were absent through a read-only process query. This bounded OS
prerequisite is accepted. The separate numerical matrix requires its own exact
authorization; OS acceptance does not enable any product scientific path.

## Lesson and boundary

Mocked lifecycle tests did not establish the Darwin exited-leader behavior.
An intentionally nonzero, short-lived process with one independently ready child
tested the exact cleanup seam without using biological outputs as a proxy. This
is a bounded engineering check, not proof of all OS schedules, a hard memory
sandbox, physiological validity or arctigenin efficacy. Retain the original v1
convergence failure and all six requested scientific programs unchanged.
