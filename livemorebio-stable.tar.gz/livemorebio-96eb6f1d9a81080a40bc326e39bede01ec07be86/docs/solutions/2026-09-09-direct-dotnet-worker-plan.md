# Direct .NET OSP worker, complete execution-boundary replacement

Date: 2026-09-09. Status: **PLAN, acquisition/build approval pending**.
Authority: Emmanuel requested complete alternatives for repeatedly failing paths,
with preservation of the product and no shortcuts. Root authorized this written
plan and anonymous official text/metadata reads, not binary acquisition,
installation, compilation, worker execution, model execution or another old packet.

## Decision

Build a small framework-dependent `net8.0` C# worker calling the existing public
`OSPSuite.SimModel` API directly, with a separate fixed-purpose parent adapter.
Remove R/rSharp, namespace interception, R initialization handoffs and package
startup commands from this new lane. Do not revise or retry the consumed R lane.
This replaces the execution boundary, not SimModel, CVODES, XML, units or science.

The recommended fresh build/host candidate is **SDK 8.0.425 / runtime 8.0.31,
osx-arm64**, subject to root's explicit selection below. It is a new host identity,
not a claim that retained runtime 8.0.30 changed or was requalified. All five
principal pins in the unchanged pure protocol remain exact. SDK 8.0.424 paired
with 8.0.30 is documented as the provenance-matching alternative, not an automatic
fallback. Do not download both or fall back between them after a failure.

Why now: CA533x rejected an unidentified startup descendant; qUfcQ6 retained
R's `sh -c 'uname -a'`; oWpRO1 completed initialization/CLR-startup handoffs and
then failed `EVIDENCE_FILE_TYPE`. The third packet did not retain the offending
path/type/creator. `_directory_bytes` accepts directories but rejects non-regular
leaves throughout the case, including runtime TMPDIR. A direct worker alone
would not correct that mixed scratch/evidence contract. All three FAILED packets
and their receipts remain unchanged; no socket/FIFO identity is inferred.

Alternatives considered:

| Path | Decision |
| --- | --- |
| Direct macOS ARM64 .NET worker | Selected. Same low-level solver API and existing native bytes; removes the R bridge and gives an explicit scratch/transport/lifecycle contract. |
| Retained `ConsoleApp.dll` | Not selected. Its deps identifies OSPSuite.R/PKSim.R; no fixed XML/result CLI or entry source was established. |
| Linux container/service | Deferred. Linux cannot load the retained Mach-O dylibs. Different native builds need new artifact provenance and semantic qualification. No retained supported service protocol/access was established. |
| Containerizing the same R chain | Rejected as this replacement: preserves the fragile startup chain and changes the platform without resolving its contracts. |

## Immutable scientific and protocol boundary

Keep `tools/osp_semantic_probes.py` SHA256
`12585d9bed93cd2a5625ec1cd625287406a22d475b49c34ba931109630ea82d7`
unchanged. Its protocol SHA256 is
`5eb866376a2b121109066dbb11edad2eba701b3b85c8fe474ae1aa02b8e505e7`.

- Exact S01–S17 fixture XML byte equality precedes native use; no arbitrary XML,
  file path, expression, parameter override, high-level OSP transformation or API.
- Seventeen fresh workers, sixteen prescribed Run calls. S01/S07/S08 repeat on
  the same finalized object. S03/S04/S16/S17 perform zero Run calls and must reject
  at LoadFromXMLString or FinalizeSimulation, not construction/options/readback.
- Preserve output IDs/order, grids, native vector counts, public stored-size
  `IsConstant` meaning and unexpanded arrays. Preserve every finite binary64
  result through round-trip serialization, including signed zero; no rounding,
  clamping, interpolation, float32 conversion or filled-in missing values.
- Preserve AutoReduceTolerances=false, StopOnWarnings=true and every existing XML
  solver setting/oracle tolerance. Options getters are cached managed readback;
  run statistics are managed-reported native out-parameters after successful Run.
- Core.dll and ConsoleApp.deps.json remain exact reference/provenance artifacts
  required by the pure protocol, not a fabricated claim that the new worker loads
  Core or executes ConsoleApp. A new outer backend/manifest identifies actual
  worker, runtime, managed/native image requirements and collector provenance.
  The existing three observation identity keys bind the new parent adapter file,
  compiled worker DLL and new runtime manifest respectively. Record worker source
  and build pins in that manifest. R startup/restoration fields belong only to old
  receipts; do not fabricate them or reuse an old successful-cleanup schema.
- Existing `EXECUTION_AUTHORIZED=False` and `MODEL_ADMISSION=False` source gates
  are untouched. The new adapter also defaults unavailable without its own later
  explicit approval. No scientific gate can be set by a technical worker result.

## Official source feasibility, now checked directly

Official commit
[`395dccf72a310b0485e63928741703045a1b40aa`](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/tree/395dccf72a310b0485e63928741703045a1b40aa)
was read as text through its GitHub tree/raw endpoints. The tree response was
complete (`truncated=false`). No assembly was loaded or decompiled.

The public API is sufficient without private reflection or a new native binding:

1. `new OSPSuite.SimModel.Simulation()`; obtain `.Options`, set only the two
   prescribed options and retain their getters. Constructor creates the native
   simulation and parameter/species-info vectors.
2. PRE_XML barrier, independent parent image inspection, then acknowledged release.
3. `void LoadFromXMLString(string)` followed by `void FinalizeSimulation()`.
   The loader also fills parameter/species properties; do not reproduce only its
   P/Invoke and accidentally omit that work.
4. Prescribed `void RunSimulation()` calls. After each success read `double[]
   SimulationTimes`, `ValuesFor(string entityId)` for the exact existing IDs,
   `.IsConstant`, `.Values`, the three `.RunStatistics` fields, and
   `.SolverWarnings.Count()` (`SolverWarnings` is `IEnumerable<SolverWarning>`,
   not a public Count property in C#).
5. FINAL barrier before a single explicit `.Dispose()`. Preserve its failure
   separately from the primary failure. The class also has a finalizer; a failed
   explicit disposal cannot be represented as proof that native disposal happened
   exactly once. Parent process cleanup remains authoritative in that case.

Sources: [Simulation.cs](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModel/Simulation.cs),
[SimulationOptions.cs](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModel/SimulationOptions.cs),
[VariableValues.cs](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModel/VariableValues.cs),
[SimulationRunStatistics.cs](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModel/SimulationRunStatistics.cs).

### Exact source-retention candidates

Acquire only these text blobs for review/provenance after approval, not a repository
checkout/build. Paths below are relative to the exact commit above. Git blob IDs
are official Git object SHA-1 identities, **not archive SHA256 or signatures**.
On acquisition verify Git blob identity and also record local SHA256/byte count.
No official SHA256 for a generated source archive was established; do not invent it.

| Relative path | Official Git blob ID | Bytes |
| --- | --- | ---: |
| src/OSPSuite.SimModel/Simulation.cs | 2b52988e37ce177c9191b4b90a6ebc4259315f6a | 32721 |
| src/OSPSuite.SimModel/SimulationOptions.cs | 2db6393ae843d4cbf391a8df1e6c823281998cea | 6191 |
| src/OSPSuite.SimModel/VariableValues.cs | 00fbba5e5a14d55eb1b4253d9424ddd0df753e0d | 3291 |
| src/OSPSuite.SimModel/SimulationRunStatistics.cs | f25e9b3fa4397a7a4b3a99a61d765839d2182ab9 | 1542 |
| src/OSPSuite.SimModel/SimModelImportDefinitions.cs | b37e87df2418ed5afa570088dfb18fbcc31439bf | 392 |
| src/OSPSuite.SimModel/OSPSuite.SimModel.csproj | 65594051c99bbe21e2b366d2b55daf579a1b4e67 | 3215 |
| src/OSPSuite.SimModel/OSPSuite.SimModel.MacOS.Arm64.nuspec | f2bc2cf89b8f722338e4d87b235bec5e9a03dedb | 2713 |
| src/OSPSuite.SysTool/src/DynamicLibrary.cpp | f3696bcbb7c86b152a50796c3da3a43f871025fd | 4185 |
| src/OSPSuite.SimModelNative/src/DESolver.cpp | 15b60e2623c702fe6eeee6597c78029ebfa5739c | 24709 |
| src/OSPSuite.SimModelNative/CMakeLists.txt | 678bb7bbc1abcfc1c24a764b371749da44ec2e6d | 1356 |
| .github/workflows/build-and-publish.yml | b0d27a4ff91c154aa626ab757270b8212e78e647 | 7703 |
| LICENSE | b0ef8e79eb505aee5b76b6e5dfb9cb52deead1ac | 17756 |

The source project targets net472/netstandard2.0 and references Utility4.1.0.6,
FuncParser4.0.0.73 and CVODES4.1.0.19 packages. **Do not rebuild that project or
restore its packages.** The retained deployment actually supplies Utility4.1.1.1;
the worker must reference the retained DLL, not replace it with 4.1.0.6.
The official workflow publishes to GitHub Packages using an authenticated token.
Anonymous NuGet.org text endpoints for SimModel4.0.0.75 and Utility4.1.1.1 returned
404, and Utility's returned tag list did not identify 4.1.1.1. No registry access
or exact Utility source-build attribution is presumed. Existing retained bytes
avoid requiring registry access for this worker.

## Exact SDK/host candidates and acquisition boundary

Read on September 9 from Microsoft's official
[8.0 release metadata](https://builds.dotnet.microsoft.com/dotnet/release-metadata/8.0/releases.json).
The 1,584,285-byte metadata response had locally computed SHA256
`21cc0b1f333822c9c86df690b9dad0191ee3bd4abebd05ad86a0bb353e38fc0b`.
Its signature filename is `releases.json.20260908221732.p7s`; no signature
verification is claimed. File hashes below were independently matched against
the official [8.0.31 checksum list](https://builds.dotnet.microsoft.com/dotnet/checksums/8.0.31-sha.txt)
and [8.0.30 checksum list](https://builds.dotnet.microsoft.com/dotnet/checksums/8.0.30-sha.txt).
Sizes are current HEAD Content-Length values, not downloaded/verified binary sizes.

| Candidate | Exact official URL | HEAD bytes | Official SHA512 |
| --- | --- | ---: | --- |
| Recommended SDK 8.0.425 | https://builds.dotnet.microsoft.com/dotnet/Sdk/8.0.425/dotnet-sdk-8.0.425-osx-arm64.tar.gz | 209896438 | d42156be70b489236479a415536013a89a9fd6eaca57d5716a7017612fcc65bdb459068973d7cffd6fe710f2799af8bee95b2046ba032762d47df176f5c4a7d6 |
| Separate runtime-only 8.0.31 | https://builds.dotnet.microsoft.com/dotnet/Runtime/8.0.31/dotnet-runtime-8.0.31-osx-arm64.tar.gz | 29086664 | 1963d2ab3798efdc2b33034ef57d4252849a066a2313ce62a574e556d19e5e981afe13c9545eb6d59437849723e1c8350f10f8068bcfa6b7a2815a07263bb8b3 |
| Retained-host-matching SDK 8.0.424, alternative only | https://builds.dotnet.microsoft.com/dotnet/Sdk/8.0.424/dotnet-sdk-8.0.424-osx-arm64.tar.gz | 209904374 | 975b686a2c6a5d62b20d95d04a233325670f38acc2ab5815d65126f05338783eb5988b16f504c9de516a63a550bcef0c061fc20fd25f128cc5b46be957065999 |

SDK8.0.425 includes runtime8.0.31. The separate runtime archive is optional if the
reviewer accepts a recorded runtime-only extraction/copy of the SDK host/shared
closure; never silently mix both installations. Prefer an explicit runtime-only
package for the execution root so no compiler/SDK is present in worker search paths.
The acquisition decision must choose one method, not opportunistically discover it.

Metadata reports 8.0.31 as a September 8 **security** servicing release, 8.0.425 as
latest SDK, and .NET8 maintenance/EOL November 10, 2026. The
[release notes](https://github.com/dotnet/core/blob/main/release-notes/8.0/8.0.31/8.0.31.md)
list five CVEs with titles still marked TBD. Applicability to this fixed offline
worker was not established. Do not silently endorse retained8.0.30 for new use or
claim the new host fixes every security issue. Root must explicitly approve the
fresh8.0.31 host candidate, or document the justified constrained8.0.30 decision.
Neither choice changes OSP solver bytes or old historical evidence.

Prospective acquisition: exact HTTPS URLs only, bounded sizes/time, no credential
use, fresh private directory, verify SHA512 before extraction, retain local SHA256,
response metadata and licensing. Reject archive traversal, absolute paths, unsafe
links/special entries and excessive expanded size/count before extraction; do not
execute install scripts, use an installer package, modify PATH globally, restore
packages or write the retained runtime. Root sets the finite acquisition/extraction
ceilings in that approval; they are separate from and do not enlarge case limits.

## Build and loader closure

Build only the new worker, not OSP. Use the chosen isolated SDK, an exact
`global.json` (`rollForward=disable`, `allowPrerelease=false`), net8.0 and local
file references. No NuGet package references are needed for the worker's own
JSON/collections/IO: use the framework. Generate restore assets offline with
package sources cleared, then build without restore. Explicitly disable compiler
sharing/build servers, workload advertising and telemetry, control private CLI
home/cache, and deny build network/process expansion outside the reviewed compiler
closure. Do not treat unsupported `DOTNET_SKIP_FIRST_TIME_EXPERIENCE` or
`DOTNET_MULTILEVEL_LOOKUP` as .NET8 isolation mechanisms. Official
[SDK selection](https://learn.microsoft.com/en-us/dotnet/core/tools/global-json),
[runtime selection](https://learn.microsoft.com/en-us/dotnet/core/versions/selection)
and [environment documentation](https://learn.microsoft.com/en-us/dotnet/core/tools/dotnet-environment-variables)
were checked.

Use framework-dependent output, no apphost, single-file extraction, self-contained
publish, trimming, AOT, ReadyToRun generation or native rebuild. Pin the generated
runtimeconfig to the chosen exact Microsoft.NETCore.App patch with runtime
roll-forward disabled. Hash sources, local references, SDK/compiler/reference-pack
closure and output DLL/deps/runtimeconfig. Check emitted AssemblyRef metadata with
the approved SDK's metadata API before native execution; no generic PE parser is
required. Confirm all non-framework references resolve solely to the manifest.

Runtime layout, fresh owned root, no names below are authorization to create it:

```text
runtime/        exact chosen runtime-only host/shared closure, immutable
worker/         worker DLL/deps/runtimeconfig + exact required managed DLLs
native/         exactly the three retained ARM64 OSP dylibs, immutable
provenance/     unchanged Core.dll, ConsoleApp.deps.json, source/license manifests
cases/Sxx/
  scratch/      private HOME/TMPDIR/cache; not the evidence namespace
  evidence/     parent-created regular files only
```

Required retained native/managed SHA256 pins:

| Artifact under retained `r-library/ospsuite/lib/` | SHA256 |
| --- | --- |
| OSPSuite.SimModel.dll | 4c14eb2824397a1577e7c689984e4b9e9ea1b4297e6e480824681f19d199e520 |
| OSPSuite.Utility.dll (4.1.1.1) | 48159576a958e6e2578b45c35ee0239c547f02f8d5e4d8d377275c85d19788b0 |
| libOSPSuite.SimModelNative.dylib | d3ca3467fa7886898e76c47a81df031dfa5403e3497448611c3cb0d71c120bd4 |
| libOSPSuite.FuncParserNative.dylib | 5ab90d872ee05605d9c1e7d043e256207f543f19f86ba236c036db3c65f2b4d1 |
| libOSPSuite.SimModelSolver_CVODES.dylib | 19453818ef70c4b722f7aba518660927ac005e9b89ba8621598ec0038d99e257 |

The managed P/Invoke name is `OSPSuite.SimModelNative`, Cdecl. A fixed
[supported import resolver](https://learn.microsoft.com/en-us/dotnet/standard/native-interop/native-library-loading)
on that one assembly may map only that name to the exact absolute native path;
it must not become a plugin resolver or force-load CVODES. Native
[DESolver](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SimModelNative/src/DESolver.cpp)
opens `OSPSuite.SimModelSolver_CVODES` through
[DynamicLibrary](https://github.com/Open-Systems-Pharmacology/OSPSuite.SimModel/blob/395dccf72a310b0485e63928741703045a1b40aa/src/OSPSuite.SysTool/src/DynamicLibrary.cpp),
which calls `dlopen("lib" + name + ".dylib", RTLD_LAZY | RTLD_GLOBAL)` on macOS.
Therefore the managed resolver alone does not close native loading.

Proposed exact loader environment: CWD is immutable `native/` and
DYLD_LIBRARY_PATH is that single canonical directory, containing only the three
admitted names; no inherited DYLD/preload/alternate framework/search overrides.
This supplies CVODES leaf loading and SimModelNative's recorded
`@rpath/libOSPSuite.FuncParserNative.dylib` dependency/rpath `.` without binary
patching or preloading. System libxml2/libc++/libSystem remain the independently
admitted platform closure. CWD and library search directory are not scratch.

This is source-backed but still needs actual qualification. The local Apple
`dlopen(3)` explicitly describes DYLD_LIBRARY_PATH-at-launch and leaf-name search,
and also restricted/entitled-host behavior; `dyld(1)` describes SIP restrictions.
Their local SHA256 values are respectively
`baa10d9ac164d9be8a6920559e0a93778979e78b559e836b91193c9c46d57524`
and `aa997c7497467de10cc8918b84f7be7370b3e0164c6cb87e657f4f9c7ecadc07`.
Do not remove signatures/entitlements, bypass SIP, mutate install names, add global
library paths or force-load a missing image to rescue a failed candidate.

## Complete transport, evidence and cleanup contract

One parent-owned worker process per case, exact absolute host and DLL argv, no
shell/CLI discovery command, and no ordinary child process admitted. Parent-owned
image inspectors retain their separate exact ownership/budgets. Reuse reviewed
low-level ownership/OS sampling/image-parser primitives where applicable; do not
reuse `_execute`, `_CaseCallback` or R-specific startup classification wholesale.

Use a finite inherited-pipe protocol, not filesystem polling or a service:

```text
parent exact config -> worker construct/options -> PRE_XML + managed inventory
  parent process/image checks -> matching CONTINUE
  worker load/finalize -> prescribed runs -> observation or exact-stage rejection
  worker FINAL + managed inventory -> parent image checks -> matching CONTINUE
  worker Dispose receipt + exit -> parent verifies exact-owned cleanup
  pure unchanged validator + complete evidence + cleanup -> technical decision
```

Bound every frame before allocation. Bind backend version, case, protocol/worker/
manifest hashes, PID, phase and strictly increasing sequence. Only two CONTINUE
barriers, with no retry/replay/fallback. Duplicate, missing, stale, wrong-PID,
out-of-order, nonfinite, deeply nested, oversized or truncated content fails closed.
Frames are at most 256KiB, CONTINUE at most 4KiB; exact XML remains at most 64KiB
and the total stdout/observation ceilings below still apply. The final schema and
maximum frame count must fit the existing reserve before code approval.
Retain exact admitted frame bytes; worker stdout is protocol-only and stderr is
separately bounded. Unexpected native text on stdout is a protocol failure, not
silently stripped. Parent alone writes observations/manifests/receipts as immutable
regular files. A worker's favorable self-report cannot grant acceptance.

At both barriers require two stable, complete, bounded managed-location inventories
and the independent parent native-image inventory. Reject unexpected/dynamic or
unresolved assembly locations, changed paths/identity and unadmitted images. The
new explicit minimum includes the selected host/CLR and actual SimModelNative/
FuncParserNative at PRE_XML; all positive cases additionally require CVODES at
FINAL. Enumerate the chosen runtime/platform dependency closure in the manifest;
do not import the old minimum R/rSharp images or drop image admission to simplify
the replacement. Pin checks continue through cleanup/final evidence acceptance.

Set `DOTNET_EnableDiagnostics=0` before the host starts. Microsoft's
[diagnostic-port documentation](https://learn.microsoft.com/en-us/dotnet/core/diagnostics/diagnostic-port)
states this disables ports; macOS normally uses a TMPDIR Unix socket. No debugger,
profiler, EventPipe/custom ports, startup hooks, additional deps or runtime network
configuration is inherited. This is justified independently of oWpRO1, whose
offending entry is still unknown. Native image admission uses parent vmmap, not
the disabled .NET diagnostic port. Do not label this an OS network sandbox.

Scratch and evidence are accounted together under unchanged limits. Default
scratch admission remains owned directories/regular files, no symlink following,
hard-link escapes or special-file opening. Disabled diagnostic IPC is the selected
solution, not a broad special-file exception. Any unexpected scratch type/change
must retain its exact relative path, lstat type/identity and sampling stage before
failing. If a required runtime scratch node is later established, stop for an
explicit architectural decision, not an observation-derived allowlist patch.

Keep immutable first-failure metadata and complete-vs-partial candidate identities
even if an outer writer fails. Retain the existing bounded sidecar principle:
64KiB per phase, 4KiB metadata plus 60KiB whole rows, shared 64 identity cap, no
environment/exception text; six possible work/cleanup sidecars and atomic overhead
inside existing case byte/entry ceilings. Reserve necessary pipe/phase/file-failure
metadata inside these ceilings before starting. Never truncate accepted evidence
silently or recast an evidence failure as native success.

Unchanged limits: worker 30s including cleanup 3s; packet 600s; CPU soft 20/hard 21s;
sampled process-group RSS 3GiB, target 0.1s/max gap 0.5s; stdout/stderr 1MiB each;
observation 256KiB; case 4MiB/256 entries; structured 16MiB; packet 64MiB/5000 entries;
inspector 3s including cleanup 0.5s, stdout 512KiB/stderr 8192B. Monitoring continues
during work and cleanup despite any policy/evidence rejection. No budget borrowing.

Preserve exact PID-start/image/PGID ownership, no unrelated signaling, TERM then
bounded KILL, empty group before leader reaping, and unresolved ownership blocking
the next worker. Preserve primary, disposal, evidence and cleanup failures as
distinct facts. Sampled resource/process checks and private same-user directories
are not adversarial filesystem/process isolation or hard RSS/disk confinement.

## Implementation and qualification, one real worker rather than more wrappers

Proposed new source boundary: `tools/osp_dotnet_worker/` (worker, fixed project,
manifest/build inputs), `tools/osp_dotnet_worker.py` (small dedicated parent
adapter), and dedicated offline tests. Avoid a general worker framework/service,
arbitrary validator, reflection transport or new parser. Root reviews this source
boundary and exact schema before maker code. Old source/launchers/tests/receipts,
biology files and live stores remain untouched.

1. Root selects SDK/host and bounded acquisition. Retain the listed exact primary
   source blobs and toolchain metadata, verify artifact identities and inspect
   package/loader closure. No native use yet.
2. Write failing tests first, then implement the fixed worker and parent adapter.
   Use a fake solver boundary for C# sequence/serialization/error tests; compile
   only this worker with the approved isolated SDK. No native calls in these tests.
   A package-free test executable is sufficient, not a new test framework.
3. Independently review the complete delta, emitted dependency/loader manifest and
   exact offline repeat. Preserve existing Python tests under the established
   process/network/native-refusal wrapper; do not rewrite old expectations to make
   a new backend pass. New parent tests use authored process/time/IO fixtures.
4. Root approves one meaningful exact-worker technical qualification after the
   ownership/cleanup/image-inspection path is qualified for this host/argv. Old OS
   receipts are historical evidence for unchanged primitives, not blanket proof
   for the new CLR host, layout, classifier or scratch behavior. No throwaway
   loader retry series or recycled once marker.
5. Run the unchanged 17-case protocol only under that separate execution decision;
   independent evidence review decides technical acceptance. Any failure remains
   failure and stops dependent work. No automatic return to the old R backend.

Required red-first coverage:

- Exact fixture/protocol/principal binding, every call ordinal, same-object
  repeats, zero-Run rejection cases and rejection-stage distinctions.
- Option labels; result count/flag/order; binary64 including signed zero;
  nonfinite/overlong output; original primary preserved through disposal failure.
- Every pipe malformed/replay/sequence/PID/hash/EOF/timeout/oversize branch;
  PRE_XML before XML and FINAL before Dispose; stdout pollution never discarded.
- Changed/missing/unknown assembly/native image, failed inspector, loader outside
  the sole frozen package, prohibited children and source/runtime drift.
- PID reuse, reparenting/group changes, leader exit with survivors, process-sample
  partial failure and monitoring continuity, TERM/KILL/cleanup failure.
- Scratch/evidence directory/file/symlink/hardlink/special/race cases, exact
  rejected-entry metadata, combined byte/count boundaries, atomic-write overhead,
  sidecar survival and no PASS when output retention is incomplete.
- CPU/RSS/time/stream/inspector limits, sampling gaps, packet early stop; no
  solver/native, OS-sampling or network access during offline tests. The later
  approved isolated compiler and fake-solver test-host processes are explicitly
  counted build/test activity, not mislabeled as a zero-process native test.

## Remaining approvals, scientific limitations and rollback

Root decisions needed: SDK/host selection; finite acquisition/build budgets and
locations; emitted dependency/loader manifest acceptance; independent maker review;
then separate exact-worker execution approval. No binary acquisition or execution
has happened under this plan. The SDK includes native compiler/host executables;
even fake-solver managed tests require that later build/test authority.

The upstream license is GPLv2 plus a clarifying addendum. Retain all notices and
dependency licenses; linking a new worker does not erase distribution obligations.
No public artifact/service distribution is approved without the relevant license
review. Utility/native binary-to-source build attestation and historical-author
runtime equivalence remain unresolved and explicitly labeled, not implementation
blockers disguised as established provenance.

Stage B's convergence and domain failures remain FAILED. Technical equivalence
does not prove physiological positivity, conservation, person-specific calibration,
complete-state checkpoint equivalence, actual restart/event traces, clinical
validity or an exact human replica. The six programs remain exogenous insulin,
erinacine A, sterubin, carnosic acid, arctigenin and cyanidin-3-O-glucoside. No source
reference/candidate experiment replaces any requested program or physical evidence.
No insulin matrix/model run is authorized by technical worker qualification.

Rollback is to keep this new lane unavailable, preserve its failed evidence and
leave the prior product/data/source unchanged. Never silently fall back to a
consumed R worker, change solver bytes or promote a partial result to PASS.

## Preparation receipt and lesson

Architecture shaped by the preceding `plan-eng-review` whole-contract review.
This plan's author checked official Microsoft release/checksum text, exact-commit
OSP source text and local Apple loader manuals. The browse skill was inspected;
no browser was started alongside root's tracker QA. Official HTTPS metadata/text
reads and HEAD requests only; no binary response downloaded to disk, dependency
installed, compiler/runtime invoked or target product source changed. gbrain,
Context7/sequential-thinking/CE were unavailable; no claim those tools ran.

Lesson: a replacement is complete only when the direct API, transitive loader,
runtime scratch, observation transport, ownership and failure retention form one
reviewed contract. Removing R does not remove CLR behavior. Preserve exact solver
semantics while making runtime identity and every remaining evidence gap explicit.

Independent plan/build/execution approval: **not yet granted by this document**.

### Root review and acquisition/build decision — 2026-09-09

Root independently read the full plan, reviewed the public Microsoft release,
SDK-selection and diagnostics documentation, and approves the direct-worker
architecture under the user's complete-alternative instruction. Select **SDK
8.0.425 and a separate runtime-only 8.0.31 archive**, both exact osx-arm64 URLs
and SHA512 values above. Do not acquire the older alternative or copy/mix the
SDK runtime into the execution root. This is a new explicitly recorded host
identity; old 8.0.30 receipts and all OSP principal/fixture pins remain unchanged.

Bounded preparation/build authority, not biological execution authority:

- Use one fresh private `mktemp -d` directory under `/private/tmp` with the prefix
  `livemore-dotnet-worker-toolchain.`. Record its resolved path. No global install,
  PATH/profile changes, installer script, package registry, public distribution
  or existing source/runtime/store overwrite.
- Exact SDK download ceiling 220 MiB/300 seconds; exact runtime 32 MiB/90 seconds;
  listed source/metadata text 2 MiB per response/32 MiB combined/30 seconds each.
  Verify the published SHA512 before any extraction. No automatic fallback/retry.
- Preflight archives before extraction: SDK at most 2 GiB/50,000 entries; runtime
  at most 256 MiB/5,000 entries, combined preparation at most 3 GiB. Reject path
  escape, absolute paths, unsafe links, duplicate entries and special entries.
  The fixed new acquisition script may write downloaded/generated artifacts;
  authored script/source edits use apply_patch. Preserve failed receipts.
- New authored source is restricted to `tools/osp_dotnet_worker/`, the dedicated
  `tools/osp_dotnet_worker.py` adapter, dedicated tests and evidence documentation.
  First implement package-free failing tests and the worker/fake-solver boundary;
  no modification of the pure 17-case protocol or old launcher to obtain a pass.
- Offline restore/build and package-free fake-solver tests may invoke only the
  isolated verified SDK/runtime and its compiler closure. Disable shared build
  servers/telemetry/advertising, clear package sources, retain exact commands and
  bounded output. Per build/test process ceiling 180 seconds, 2 MiB stdout/stderr,
  whole initial build/test stage 900 seconds. Stop for review on an unplanned
  dependency, loader change or repeated failure. Do not claim an OS sandbox.
- No OSP constructor, native solver, XML loading or real semantic packet is
  authorized yet. Return emitted references, source/build pins and offline test
  evidence for independent review first. This restriction preserves the agreed
  staged scientific qualification; it is not a new request for user permission.

The parent evidence namespace, private scratch, process ownership, fixed pipe
schema and exact numerical gates must remain as designed. The design is accepted
for bounded implementation, not as evidence of native or human equivalence.

### Maker offline checkpoint — 2026-09-09 13:55 UTC

Status: **partial implementation frozen for independent review, not native-ready
and not maker-approved**. Fresh private root:
`/private/tmp/livemore-dotnet-worker-toolchain.E09gsz` (0700). All old consumed
launchers, receipts, runtime bytes and pure protocol sources remain unchanged.
No OSP constructor, native solver, XML load, model, biological packet or browser
was run in this preparation. The permitted compiler and fake-test CLR hosts were
real processes, not mislabeled as a zero-process test or an OS sandbox.

Acquisition `444ffa` → `f0da67`, exit 0, retained the exact two approved archives,
12 exact-commit source blobs and two official metadata/checksum responses. SDK:
209,896,438 compressed bytes, 621,819,430 expanded bytes, 5,559 archive entries;
runtime: 29,086,664 compressed bytes, 78,054,168 expanded bytes, 195 entries.
Both official SHA512 values and every source Git blob/size matched before use.
Original `acquisition.json` SHA256:
`b89f62d052d0572a3a959257ae97fad2441b327ba5ff2ee44b0e33a612273619`.
It remains historical `VERIFIED_NOT_EXECUTED` acquisition evidence; subsequent
compiler/fake-host execution is separately recorded below, not hidden by that
historical label. No dependency package was restored from a registry; the private
`build-packages` directory is empty. The one observed additional SDK entry is
the empty `sdk/metadata` directory (zero file bytes), seen after builds and within
the entry ceiling; the maker did not capture its creator PID or infer attribution.

Implemented files are the new `tools/osp_dotnet_worker/` package-free projects,
fixed preparation/build scripts, embedded fixture data and dedicated
`livemorebio/tests/test_osp_dotnet_toolchain.py`. The worker provides strict bounded
JSON, exact 17-case/16-Run fixture binding, same-object call schedules, positive
versus expected-load/finalize-rejection distinctions, option/shape/grid/statistic
checks, binary64 preservation, PRE_XML/FINAL pipe barriers and primary-failure
preservation through disposal. Tests inject fake simulations; metadata inspection
reads PE bytes without constructing the OSP simulation. The dormant direct API
adapter compiles against the two retained local managed references. The executable
entry is deliberately unavailable: its first branch returns 73 with the fixed
`NATIVE_EXECUTION_NOT_APPROVED` diagnostic before any OSP construction.

RED/GREEN evidence, all originals retained in the private root:

- Archive RED `ff6938`: source import missing before implementation; eight authored
  tests could not yet execute. GREEN `006e4e`: eight local archive groups passed.
- Worker RED `4ad6c1` → `1293b8`: restore passed, build failed with two CS2001 missing
  implementation-source errors. GREEN `e233db` → `1364c5`: 26 fake groups passed,
  build zero warnings/errors.
- Additional strict-wire RED `ac103f` → `c072f8`: the escaped unpaired-surrogate
  test exposed acceptance; the then-uncaught test assertion ended the fake host
  with -6 (shell 250). This failed receipt is preserved, not converted to PASS.
  Minimum string/surrogate validation and a non-aborting test result collector
  yielded `2e78d0` → `818c28`: 30 PASS/0 FAILED, zero build warnings/errors.
- Frozen repeat `0c0eb2` → `e65f23`: restore 0.943689s, build 0.632670s, fake tests
  0.194621s, all exit 0; 30 PASS/0 FAILED. `strict-green.inputs.json` exactly equals
  `repeat.inputs.json` (SHA256 `eb846d779bf7af36f5fa192364396c398293b6e2e181fb87dbc80fd714860e3c`).

The first build driver incorrectly persisted a monotonic value across Python
processes; a source/data check showed this environment's monotonic origin was not
usable that way. Before strict-wire RED it was changed to derive remaining stage
time from the **original unchanged** stamp mtime and use monotonic time only
inside each process. Original start 1788960998 / 13:36:38 UTC; final repeat receipt
1788961724 / 13:48:44 UTC, 726 seconds later, inside the original 900-second stage.
The stamp was not refreshed. That stage has now expired; no further maker build
or fake-host invocation is authorized by silently restarting it.

The exact historical full repeat command, from this worktree, was:

```sh
/usr/bin/python3 -B tools/osp_dotnet_worker/build_fake.py /private/tmp/livemore-dotnet-worker-toolchain.E09gsz repeat
```

Each `*-restore.json`, `*-build.json` and `*-tests.json` retains complete argv,
private environment/cwd, timing, byte counts and exit. A future independent
compiler/host repeat needs its own explicitly bounded reviewer decision; do not
reuse or reset the consumed build stamp.

**Prospective acquisition review correction, no redownload.** Independent review
identified that the original urllib opener followed a redirect before its URL
equality check, and the socket timeout plus between-read clock checks did not
interrupt an overlong individual operation. The original script is preserved as
`prepare_toolchain.acquired.py`, SHA256
`3e808db3ca51c2bd3046542dce07ee2676a06bc586e4a88174d5333876eb9db6`.
The corrected script refuses redirect creation before a second request and arms
one POSIX ITIMER_REAL deadline around opener/TLS/open/read/write. It refuses a
preexisting active timer, does not reset the deadline on chunks, and restores the
prior handler/disarms its timer on every exit. The socket timeout is secondary,
not represented as a total deadline. This fixed main-thread POSIX design uses the
local standard-library signal contract; it is not a general concurrent downloader
or proof of adversarial OS scheduling bounds. Signal delivery and responses were
authored in offline tests, not exercised against a live slow server.

RED `30bd1d` retained an initial shared-target fixture artifact; isolating each
redirect target yielded RED `d67729`: 15 tests, eight failed assertions and one
legacy-308 HTTPError. GREEN `f68add`: 15 passed in 0.029s. Independent-repeat-ready
maker refusal wrapper `483fad`: 15 passed in 0.041s, zero attempted prohibited
socket/process/native calls. Eight original archive groups are preserved; seven
new groups cover redirects, open/read deadline delivery, prior timer conflict,
timer restoration, read failure/no retry and byte overflow. Complete correction
receipt: `acquisition-correction-offline.txt`, SHA256
`6cb19ae4f8ab15b22ba15f273e13cadbb9955f073dacc7699ff516db74fa6153`.
These later preparation-only changes do not change the C# output or retroactively
repair the original acquisition procedure's guarantees.

Frozen source/artifact/RED/GREEN/repeat inventory:
`/private/tmp/livemore-dotnet-worker-toolchain.E09gsz/checkpoint-sha256.txt`, SHA256
`6800646179981ab3142bd147ef3a0f966385a14798314ae41b2254485e47427a`.
Key source/output pins:

| Item | SHA256 |
|---|---|
| `Worker.cs` | `5eb250949f1077795fa0f828f16ff580dc4ace1868a98ee45e6d07b2591ef34d` |
| `NativeSimulation.cs` | `23b17fe78f781d8f3bd54c9efd50386cb143cdd7ad4e52fe505fb323f1720364` |
| `FakeTests.cs` | `fc8e5dd69616540548005c9c4b7bfa02f84e5a1645954b6bf7734a4d3f551ada` |
| corrected preparation | `f0bc0acfa26f6d70d2311b8ffba47ea947ec36f9847f3350cd76d7f7db93649f` |
| build driver | `2f7601c49afa48ed7642f847df926ad811b51011fbfe5f6f0b47b40b61402289` |
| preparation tests | `b7cc5eb0af5b993dcfad2a561b4820ee86bbf3fe04908efdebb3f1ca9bf58adf` |
| worker DLL | `d234862a1c270e8d3a33e7ce1dad7afda39a78af03b31016358bba6129d004b0` |
| worker deps | `1a48e4a9e96ef182b6e78c549b44fcc7d9b27dcbe6a67c8e898bb8aa578aca91` |
| runtime configuration | `a54ac5262f010c9d2d3cc1ea3778f237c73915881a01e8f86e70953dd02fecb8` |
| fake-test DLL | `b1f6365ff3293c93d72db4be225093ba9fb25410f595a300e000cf63700f0581` |

Outputs are in `build/bin/Worker/Release/net8.0/` and
`build/bin/FakeTests/Release/net8.0/` beneath the private root. Emitted AssemblyRef
metadata is retained verbatim in `repeat-tests.stdout.txt`: the worker references
SimModel 1.0.0.0 and retained Utility 4.1.1.1; SimModel itself requests Utility
4.1.0.6 plus netstandard 2.0, while retained Utility references only netstandard
2.0. Compile success against the higher retained Utility is **not** runtime/native
binding qualification. No additional package or runtime fallback was introduced.

Still unimplemented/unqualified: `tools/osp_dotnet_worker.py` parent adapter;
native-entry activation and exact execution manifest; authoritative filesystem,
image and process inspection; ownership/cleanup/resource/pipe-timeout enforcement;
combined scratch/evidence accounting and immutable first-failure retention; and
actual unchanged-protocol qualification. Existing Python preservation tests were
not rerun at this maker checkpoint; their old source hashes were checked unchanged.
No technical, numerical, scientific or release gate was advanced. Root's separate
independent acquisition/source/build review is required before continuing.

Lesson: compile/fake-API evidence resolves a real toolchain and static API question
but cannot close native-loader or ownership questions. Preserve each stage's
limits and failed evidence, name unfinished wiring, and never label a deliberately
closed native entry as ready. This appendix is the durable lesson/receipt; CE was
unavailable, and no CE execution is claimed.

### Root decision: finite offline review corrections

Independent source review cleared the fixed call sequence, not native execution.
Three gaps are in scope: preserve signed zero through actual emitted C# bytes
and the unchanged Python validator; bind compiler/reference-pack and emitted
DLL/deps/runtimeconfig hashes; verify the pure module hash before importing it on
the missing-fixture branch. Correct these with focused RED/GREEN tests. Preserve
the original acquisition and expired initial-stage receipts.

Authorize a separate **offline-review-corrections** compile/fake-test stage only,
using the same acquired SDK, runtime, retained references and package-free setup.
Start a new, distinctly named immutable stamp when this finite executable stage
actually begins, not while editing or awaiting review. Whole stage ceiling:
300 seconds; each child remains 180 seconds and each output stream 2 MiB.
This is a new bounded correction stage, not a reset or rerun of the expired
initial stage. Record exact RED/GREEN commands, input/output hashes and outcomes.
No downloading, package source, parent wiring, OSP constructor, native solver or
scientific packet is permitted. Stop on repeated failure or an unplanned change.
Direct-child completion is not proof of absent descendants or network activity.

### Maker finite-review-corrections freeze — 2026-09-09

All three requested offline gaps are implemented; independent final review remains
with root/release_redteam. This supersedes the **current** source/output pins in
the earlier maker checkpoint, without rewriting or deleting its historical
inventory, failed receipts, initial build outputs or original acquisition.

1. Hash-before-import RED `add6f3` executed only the exact missing-fixture AST body
   with a drift hash and an authored import refusal: it reached `UNBOUND_IMPORT`
   first. Moving the existing exact pure-source hash check before import yielded
   `3a6ed4`, 16 Python groups passed. No pure module or fixture bytes changed.
2. Actual emitted-byte RED `879e67` → `6fb3cb` compiled and ran 31 fake groups,
   retaining the 17 synthetic case observations and five binary64 variants as
   base64 of the exact bytes passed to `IWorkerChannel.Observation`. The unchanged
   Python validator then produced `ae544b`: four passed, two failed. Negative zero
   was emitted as integer token `-0`; Python decoded it as positive zero, losing
   the sign and concealing a `REPEAT_BITS` difference. The only runtime correction
   is a supported `JsonConverter<double>` writing negative double zero as numeric
   `-0.0`, with all other values delegated to `Utf8JsonWriter.WriteNumberValue`.
   The local 8.0.31 reference-pack XML documents the converter/validated raw-value
   APIs; no third-party package or speculative serializer API was introduced.
3. `compiler-reference-sha256.txt` binds 411 exact Roslyn/reference-pack files plus
   six MSBuild/build-task/host files, alongside the already official-hash-bound
   full SDK archive. Emitted DLL/deps/runtimeconfig files and retained references
   are pinned again in the final inventory, not inferred from a successful build.

GREEN `e92888` → `520419`: restore 0.978605s, build 3.164905s with zero warnings or
errors, fake host 0.193061s with **31 PASS/0 FAILED**, all exit 0. The unchanged
Python validator over the actual emitted bytes then passed all six groups
(`203e8a`, 0.007s). Final refusal-wrapped repeat `b7620c`: **22 Python groups PASS**
in 0.032s, zero attempted prohibited calls. All eight original archive groups are
preserved; the additional checks include prior acquisition corrections, producer
binding, exact 22-observation inventory, all17 schemas/rejection counts, signed
zero, an adjacent-double repeat difference and finite extreme/tiny values.

This is **encoding/decoder/binary64 fidelity only**. Synthetic observations passing
shape checks are not solver results. The pure validator/oracles are unchanged;
ordinary numerical disagreements are retained, and every compared observation
continues to report execution_verified, cleanup_verified and model_admission
false. The six artifact-dependent Python checks require an explicit retained
stdout path and skip ordinary discovery without one; the retained repeat command
selects the exact actual fake-worker bytes and executes all six. Imports do not
consume discovery arguments or silently choose a private fixture.

The separate immutable `offline-review-corrections-start.json` begins at epoch
1788962332 / 13:58:52 UTC. The final fake-host receipt is epoch 1788962392 /
13:59:52 UTC: 60 seconds inside its 300-second ceiling. The original initial stamp
1788960998 is unchanged. Outputs, home, temporary storage and the empty package
cache use the separate `review-build*` directories, preserving the original build.
No further compile/fake-host invocation is planned in this maker stage. Historical
commands were the existing fixed build driver with `review-red`, then the emitted
byte Python test over `review-red-tests.stdout.txt`, followed by `review-green`
and the same Python test over `review-green-tests.stdout.txt`. Full exact commands,
including the replayable 22-test process/socket/native-refusal wrapper, are retained
in the receipt below. Real compiler/fake-host completion does not establish no
descendants or no network; no such claim is made.

Final private-root evidence, all beneath
`/private/tmp/livemore-dotnet-worker-toolchain.E09gsz`:

| Evidence | SHA256 |
|---|---|
| `review-corrections-sha256.txt` — complete source/output pins | `a10e9142854b757eef24d2517c2c3b57784ff47b1aeacc78ff05de5b5dac3e71` |
| `review-corrections-offline.txt` — exact RED/GREEN/repeat commands/results | `0d5cdb237a60414df274c6b14439c6614546e5796e9a6c3fdee37a6a3e878238` |
| `compiler-reference-sha256.txt` — 417 compiler/reference/host files | `996b59947a70ab6c4f60db846f9ac1d59985353bc257774432da38bda00a02f7` |
| corrected `Worker.cs` | `70011d37d2c459e264d9e7e250148ab082e1912cf492a6ca32e8957a514302db` |
| corrected `build_fake.py` | `48f528be1799a89fcfff660c775863c7203fd6cc9b8bac5d71b84a745cb302ce` |
| additive `FakeTests.cs` | `1a316dfbee6341308ad207592a55d6865398c1124ca1ac915b9fa557949e8763` |
| toolchain Python tests | `e8c024fb3ed95d0ec6ed15e2afa97b66dba1646e88dbada38efa9efa0f36df05` |
| emitted-byte Python tests | `966d5f5e2fe157a49992a134ab61f750f49bcee4e9618cfb4992c2cd2ddf4a94` |
| `review-build/bin/Worker/Release/net8.0/Livemore.OspWorker.dll` | `8a217d42e1a5bab51233f9015beab38b42429dc94a325741242d53a3c6ff54a6` |
| worker `.deps.json` | `1a48e4a9e96ef182b6e78c549b44fcc7d9b27dcbe6a67c8e898bb8aa578aca91` |
| worker `.runtimeconfig.json` | `a54ac5262f010c9d2d3cc1ea3778f237c73915881a01e8f86e70953dd02fecb8` |
| fake-test DLL | `52d35308c0752b7dbefa52482a749f3bb7634e60edbfb9e612a6493e334b0d4c` |
| `review-red-tests.stdout.txt` | `db72a814a81381ab9763e983fee19038af6d3b2c9c83521ffbd6dd5e91df5438` |
| `review-green-tests.stdout.txt` | `8424da2ee313474c0febb4a68f999ccad14554cd249159427f6245e5997e867c` |

The RED/GREEN stdout sizes are 35,423/36,119 bytes; GREEN stderr is the 30-byte
closed-gate diagnostic. Emitted AssemblyRefs and deps/runtimeconfig identities
remain unchanged; the higher retained Utility runtime-binding question remains
unqualified. Parent reports independent acquisition source review clear for the
prospective redirect/timer-ownership correction, not an adversarial blocking or
hard-kill/DNS guarantee; no redownload occurred.

**Current accurate status: worker built and offline-tested; parent supervision
and native qualification next, not operational.** No parent adapter/native entry
activation, real loader inspection, process ownership/cleanup/resource/scratch
qualification, scientific packet, biological experiment or release was added in
this stage. The maker does not approve its own implementation.

Compounded lesson: same-language JSON roundtrips can hide a cross-language loss
of signed zero. Test the exact emitted bytes at the unchanged consumer boundary,
keep mathematical tolerances separate from binary representation, and retain
failed observations instead of changing the consumer to accept producer loss.

### Independent finite-checkpoint review

Release-redteam independently repeated the recorded refusal wrapper: **22 Python
groups passed in0.040s**, including all six actual emitted-byte checks, prohibited
I/O0 (`81d4fc`). Its read-only comparison reproduced the retained RED negative-zero
loss and GREEN signed-zero preservation (`c60ae2`); no numerical oracle changed.
All417 compiler/reference hashes,16 source pins,28 correction-artifact pins and
63 historical private-artifact pins matched. Original acquisition/build/stamp
evidence remained unchanged; separate correction-stage timing corroborated60s/300s.

Independent verdict: **CLEAR for this finite offline correction checkpoint**.
No SDK, constructor, native solver or scientific run was repeated by the reviewer.
Entry remains disabled/73; parent adapter and native loader/image, ownership,
resource, pipe, cleanup and evidence qualification remain unfinished. This is not
operational OSP integration or scientific/human-equivalence acceptance.
