# Physical calibration: native choice commit and two visible form defects

## Evidence and scope before code

Root authorized this bounded correction after the single retained native run at
`/private/tmp/livemore-legacy-preview-mgjbj3fk`, session30942. The investigation
skill's evidence-first discipline was applied. Both complete receipts, both
original PNGs, actual form/controller/CSS, harness workflow and pinned Playwright
input/locator implementations were read. No browser, service or network was
started for diagnosis. Available tools still contain no gbrain/Context7/CE or
sequential-thinking connector. No global skill configuration was changed.

The source-fenced run was `1e3516cbd12ac304e3f47b4325ae39f46ad969c7336abcd72bfb8ecbfcd1d99f`.
D0 passed; D1 failed `PHYSICAL_CALIBRATION_FAILED`; mobile was NOT_RUN. The actual
blank selection produced invalid_count1, submit_count0 and calibration focus.
The first ArrowDown was followed immediately by a value read recorded as OTHER.
The failure image still shows the blank placeholder. No Current/Due/Failed
commit, rejection or reopen acceptance follows from this run. All POSTs were0.

| Retained file | SHA256 |
|---|---|
| browser-result.json | `df31d786b463025d2aef2c2a1f1f5888df72f13c922cb953dc06669064383537` |
| supervision.json | `77662b32bf7f04e45348664e16f3d6950cc975610083eb97bacdc856370f3317` |
| physical-desktop-open.png | `cdd73a06a9633a150c7ae1c492211a3877fbc5b1688c45af7ba35e7ecbd48f20` |
| failure-D1-context-1.png | `12f0e978221bbc45848a7172a628e91e7d2b3573bb04f8f0f5e79eafa709f7c9` |

Preserve the exact cleanup distinction: browser page-1 close was UNCONFIRMED at
3002.584ms; subsequent context/browser closes SETTLED. The supervisor reports
all4 children reaped,9 owned descendants absent and no8910–12 listeners. Later
process absence does not rewrite the earlier page-close uncertainty.

## Confirmed harness error and remaining hypothesis

`physicalCalibrationFlow` assumes each arrow immediately commits select.value.
Both its authored double and the full-runner double implement that assumption
by assigning the next value on every arrow. Pinned Playwright client input.js42
delegates keyboardPress; server input.js92–118 sends down/up only. Locator
inputValue merely reads the current value. Neither guarantees native popup
selection has committed. The retained blank result disproves the harness's
immediate-value assumption. Native popup/commit handling is the leading causal
hypothesis; these bytes alone do not establish every macOS popup transition.

Root approved one explicit ordinary native choice unit: click the real select,
press the unique label's c/d/f key, then Enter to commit, then read exact value,
calibration focus and unchanged invalid/submit counts. The six expected choices
remain desktop Current,Due,Current and mobile Current,Due,Failed. No selectOption,
value assignment, synthetic change event, arbitrary sleep, retry or new timer.
No claim that a platform accepted this sequence until the new authorized native
run. Every POST remains blocked before forwarding.

Persist six bounded `choice_checks` records before assertions, alongside the
existing keyboard_choices: context plus safe value enum (including explicit
empty), fixed focus enum and the two existing synchronous counters. First two
desktop and all mobile choices require counts1/0; the desktop Current choice
after Due rejection requires1/1. This catches an Enter accidentally submitting
the form even if the selected value looks right. Both CJS and Python completion
admitters require the exact six records. No text, device input or global state
is added to the receipt. All nine existing physical observations and four images
remain unchanged, as do source, request, timing and ownership limits.

## Separately confirmed product presentation defects

Both originals show an empty orange feedback bar. The empty paragraph has the
shared source-help padding/background/border, with no empty-state rule. Add only
`#physical-calibration-feedback:empty { display:none; }`; nonempty fixed rejection
text still renders under the original role=status/aria-describedby association.
Do not change submit, reset, selection fences or error flow.

The 281.5px desktop select visibly clips “Select declared calibration status”.
Shorten only its required, selected, disabled empty option to “Choose status…”.
Keep the existing “Declared calibration” label and all exact wire values. No
font shrinking, layout redesign, default Current or certificate implication.

Owned changes: the two existing harness scripts, dedicated physical harness
test, twins.html, subjects.css, dedicated physical calibration UI test and this
report. No subjects.js, service, registry, model, hardware or unrelated UI edit.
The larger full-v3 and original product/scientific-program scope stays active.

## Red-first and independent acceptance

Strengthen the existing workflow and actual inert-runner doubles so a native
highlight remains distinct from committed value until Enter; the old code must
fail with a blank value, not because a helper is missing. Add8 exact dual-admitter
choice cases (valid plus empty/wrong/focus/invalid/submit/missing/duplicate), and
3 full-runner faults for uncommitted choice, unexpected submit and lost focus.
Use completion guards, preserve partial evidence, all existing assertions and
zero-POST forwarding checks. Add2 product regressions for the shortened empty
option and scoped empty-feedback rule, retaining the prior69 product tests.

Repeat the resulting bounded technical matrix with the existing private45s
CJS/ESM refusal wrapper; no browser or operational data. Freeze full hashes and
receipts for independent review. Root owns any subsequent explicit source-pinned
four-image run and inspection. Original failed evidence is never overwritten.

## Frozen correction and maker receipts

The initial96-case RED retained15 FAIL /81 PASS in7.90s,
private `_rzmjywq`, session54026 closed exit1, I/O0, Node81, Git0. The changed
workflow double reproduced the exact blank-versus-Current failure. Its pending
popup semantics also stopped the full-runner positive and later cleanup paths
before their intended success. The three new full-runner fault cases additionally
required absent commit metadata; they are not independent proof of native OS
behavior. Seven dual-admitter negatives exposed the missing commit acceptance
checks; both presentation source regressions failed.

After correction,96 passed in7.37s, `jnon4i4v`, session17527 closed exit0,
I/O0, Node81, Git0. The full preservation packet passed **321 in33.06s**,
`yq5sgear`, session51952 closed exit0, I/O0, Node274, refused Git1.
No test/browser/service/native process remains from these bounded commands.

321 =76 physical harness +174 unchanged legacy harness +20 physical product
+49 unchanged selection-reconciliation +2 unchanged intake tests. Original
assertions are preserved. The existing physical workflow/full-runner doubles now
model separate pending highlight and committed value, and their earlier positive
paths remain required. Serialized readPhysicalChoice is exercised in the actual
DOM VM, including unknown-value privacy sanitization. No new unbounded helper,
timer, dynamic request or field default was introduced.

Frozen review map:

- CJS221–232: safe native-choice observation and exact six-position predicate;
  274–285: fixed click/typeahead/Enter sequence; 287–295: required commit evidence;
  522–531: actual locator click and atomic choice read persisted before assertions.
- Python393–400: six exact typed commit records admitted before existing receipt
  checks. No main/supervisor limits, cleanup or legacy admission changes.
- twins.html94: only the empty placeholder text; subjects.css37: only scoped
  empty-feedback hiding. subjects.js remains unchanged.
- Harness test299 lines; product test204 lines. New tests are the exact11+2
  described above, not an expanded browser scenario.

| Frozen file | SHA256 |
|---|---|
| tools/check_legacy_preview_browser.cjs | `9ece94eb6fd6b090d4324a90e00ce59a4846a2c62ec8e2b2488ef6bdca9208de` |
| tools/check_legacy_preview_browser.py | `9f8dcd8afe8fb5738a8ac61100811bf400ee75ae620bf0fb83045715058806b6` |
| test_physical_calibration_browser_harness.py | `8c1e673303379a0c7d03883772d4e38d52c207770ba6e8110f0813dbdfeaa9fa` |
| twins.html | `69afbfb72fdbed33444667941a5ea2a4ff1555d23dbccf64da9e40c88d27200e` |
| lib/subjects.css | `4a4a8d5d209fe10e4026679202ef39a85e188d3c3fb29a07233c5d415db8fb21` |
| test_physical_pairing_calibration_ui.py | `fd9ef80a15a7d86bbfad0f7821c3f750b6cfd977e93b57653fa815dd013354c9` |
| unchanged lib/subjects.js | `b35b6aa4e1277eef95ac128ff64f93d874cfb589d3d992c7554927f1f001e95a` |
| unchanged test_person_intake_ui.py | `df451a83230d56dfc70dec85ed7b02aaba800a69b7bd757229ff17d9472b7366` |
| unchanged test_selection_reconciliation_ui.py | `64d5417dcf8247ffe217e2c1e98e6ec50803f0772cdb240c56db62dccd8dfea8` |

The three original174-test hashes remain exactly those in the parent harness
report. Both original native images and raw receipts remain untouched. D1 is
still FAILED, mobile still NOT_RUN, and page-1 cleanup remains UNCONFIRMED in
that retained attempt. This maker result is not independent or native acceptance.

### Exact independent repeat

CWD `/Users/emman/Livemore/.worktrees/full-scope-recovery`. This is the existing
private45s CJS/ESM refusal wrapper. Only exact authored Node evaluation children
are admitted. Network/process refusal is test instrumentation, not an OS sandbox.

```bash
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - \
  livemorebio/tests/test_physical_calibration_browser_harness.py \
  livemorebio/tests/test_legacy_preview_browser_harness.py \
  livemorebio/tests/test_legacy_banner_browser_harness.py \
  livemorebio/tests/test_legacy_current_feedback_browser_harness.py \
  livemorebio/tests/test_physical_pairing_calibration_ui.py \
  livemorebio/tests/test_selection_reconciliation_ui.py \
  livemorebio/tests/test_person_intake_ui.py <<'PY'
import os,socket,subprocess,sys,urllib.request,ctypes,signal
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1';os.environ['PYTHONDONTWRITEBYTECODE']='1'
signal.signal(signal.SIGALRM,signal.SIG_DFL);signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
esm_prefix='import {createRequire as __reviewRequire} from "node:module";const require=__reviewRequire(import.meta.url);\n'+prefix
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1;permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if isinstance(cmd,list) and len(cmd)==4 and cmd[0] in ('/opt/homebrew/bin/node','node') and cmd[1:3]==['--input-type=module','-e']:
  counts['node']+=1;permit=True
  try:return run0(['/opt/homebrew/bin/node',*cmd[1:3],esm_prefix+cmd[3]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
status=pytest.main(['-q','-p','no:cacheprovider','--tb=line',*sys.argv[1:]])
print('Refusal counts:',counts,flush=True);signal.alarm(0)
raise SystemExit(status)

PY
```

### Lesson and next gate

A keyboard-event acknowledgment is not a native selection commit. Test doubles
that change select.value on each arrow merely encode the assumption being tested.
Keep highlight and committed value separate and ensure Enter did not submit the
form. Separately, a visually empty live-region container can still render a
warning bar through shared CSS; inspect actual empty and populated states.

Investigation is complete within the retained-evidence boundary; the correction
is technically verified with concerns explicitly retained. Root independent
source/tests review and a newly authorized source-pinned four-image native run
are required. Do not retry automatically, substitute authored DOM validity for
native evidence, or call the form complete physical-v3 onboarding.

## Independent review and fresh native decision

Root read all215 report lines, all299 harness test lines, all changed production/
harness sections and the two new product regressions. The321-case exact private
repeat passed33.56s (9133/lhb_osr6), I/O0/Node274/refused Git1; all six frozen
file hashes match. The native choice observer checks committed value AND unchanged
submit/invalid counts, not merely keyboard acknowledgment. The source-scoped CSS
does not hide nonempty feedback. Original failure records remain unchanged.

Authorize one fresh source-pinned physical-calibration four-image run after the
coordinated runtime pause. No previous root is reused. Same private technical
record/three-services/noPOST boundaries apply; all four images plus cleanup must
be independently inspected. This is not authority to pair a real device or admit
the newly authored registered-v3 core as released. A native failure must remain
failed and be diagnosed before any further attempt.

## Second actual attempt — Enter submitted; blocked, not accepted

Fresh session77688, /private/tmp/livemore-legacy-preview-aq_vroym,
sourcebd31cec7605d8004d442fb7b1b865f5e258d83c2a89de529857feb5ae57ba126,
FAILED D1/UNEXPECTED_REQUEST in10.621910s. D0 and native blank rejection passed.
Click/typeahead/Enter caused one POST attempt, blocked before forwarding; actual
mutations0. No choice_checks were reached. Root viewed both originals: Current
is selected in the failure image, alongside the failed-network feedback. This
does not support the authored popup-commit assumption. Do not regrade it or
claim six choice checks/four-image completion. Mobile NOT_RUN.

The desktop-open original does verify that the empty orange strip is gone and
Choose status… fits. This narrow presentation observation is separate from the
failed interaction matrix. Page-close again UNCONFIRMED3002.3435ms, followed by
settled context/browser. All four children reaped, ten descendants absent;
root separately confirmed all14PIDs and8910–8912 listeners absent. Original
images/receipts retained. Further native input work requires evidence-first
diagnosis and a reviewed plan, not another speculative retry.
