# Local 3Dmol replacement maker record

Written plan approved by root before runtime edits. This record is software
evidence, not independent acceptance or actual WebGL/browser evidence.

## RED / GREEN

- Initial RED `decc90`: 8 failed in 1.13s, absent adapter/bundle and ordinary
  caller still remote. Unexpected I/O 0, Node 6, Git 0.
- First GREEN `289156`: 8 passed in 1.78s. The actual pinned upstream CIF parser
  preserves all seven original source atom counts; 5VA2 is 4,394 atoms, chain A.
- Caller-boundary RED `4c1585`: 1 failed / 10 passed in 2.19s. An ordinary
  trigger-options object was incorrectly being passed as the inspector's frozen
  PDB argument. Corrected to the actual `open(gene)` contract. Existing inspector
  captures active-element focus itself; no second argument is required.
- Dedicated GREEN `5a7857`: 11 passed in 1.95s, I/O 0, Node 9, Git 0.
- Preservation `8de6a5`: 234 passed in 26.52s, I/O 0, Node 226, Git 0.
- Added real GLModel atom/interaction wiring and keyboard/failure-preservation
  tests: `b74424`, 14 passed in 2.90s, I/O 0, Node 12, Git 0.
- Final complete preservation `3df0a7`: **237 passed in 26.13s**, unexpected
  I/O 0, Node 229, Git 0. Runtime source frozen; root independently grades next.

The exact public bundle is unchanged, not rebuilt. Full upstream LICENSE and
additional notices are retained in `lib/vendor/3dmol-2.5.5/`. The notice record
explicitly does not invent unresolved embedded dependency versions where the
published artifact contains no lockfile. Source atom numbers and angstrom units
are retained; bonds/cartoon are renderer-derived, not experimental bond orders
or molecular dynamics. No model, native, service or browser process was run.

## Runtime delta

- Shared inspector lazily selects the new local adapter and waits for its owned
  ready/dispose resource using the existing operation, epoch and cleanup owner.
  The old injected Molstar branch remains unchanged.
- New same-origin fixed-srcdoc adapter passes verified CIF text as data, not
  interpolated markup. Abort before load settles, removes the child document;
  ready documents are disposed by the inspector. Escape and Tab boundaries work
  across the document boundary. No postMessage or external coordinate request.
- Child parses with the exact upstream parser, rejects unsupported multi-model
  topology and atom-count loss, creates an actual upstream atom model and offers
  cartoon/sticks, fit, atom selection and two-atom source-coordinate distance.
- Ordinary Biology uses the same inspector with a persistent status host, exact
  accepted context, render generation, connected target, organ membership and
  confirmed-data guards. Context invalidation occurs before STATE publication.
  Same-context refresh retains inspection; removed/changed organ or overview
  closes it. Anatomy/cell rendering and numerical admission remain unchanged.
- The only old test-helper change is the actual ESM import seam. No old assertion
  was removed. No catalog, Python server, auth, build-identity or OSP file changed.

## Exact independent repeat

Run from `/Users/emman/Livemore/.worktrees/full-scope-recovery`. The final three
additional tests bring the full expected count to 237; first preservation was234.

```sh
/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B - <<'PY'
import os,signal,socket,subprocess,sys,urllib.request,ctypes
from tools.run_review_stack import prepare_review_environment
root,env=prepare_review_environment(inherited={k:os.environ[k] for k in ('PATH','HOME','TMPDIR','LANG','LC_ALL') if k in os.environ});os.environ.clear();os.environ.update(env);os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('OFFLINE_DEADLINE')));signal.alarm(45)
import pytest
print('Private root:',root,flush=True)
counts={'unexpected_io':0,'node':0,'git_refused':0}
def deny(*a,**k):
 counts['unexpected_io']+=1
 raise AssertionError('UNEXPECTED_IO')
socket.socket.connect=socket.socket.connect_ex=socket.socket.bind=socket.socket.listen=socket.create_connection=socket.getaddrinfo=deny
urllib.request.urlopen=urllib.request.OpenerDirector.open=deny
ctypes.CDLL=ctypes.PyDLL=deny
run0=subprocess.run;popen0=subprocess.Popen;permit=False
prefix='const deny=()=>{throw Error("UNEXPECTED_IO")};global.fetch=deny;for(const k of ["node:net","node:tls","node:http","node:https","node:dns","node:child_process"]){const m=require(k);for(const n of ["connect","createConnection","request","get","lookup","resolve","spawn","spawnSync","exec","execSync","execFile","execFileSync","fork"])if(typeof m[n]==="function")m[n]=deny;}require("node:net").Socket.prototype.connect=deny;\n'
def launch(*a,**k):return popen0(*a,**k) if permit else deny()
def run(cmd,*a,**k):
 global permit
 if isinstance(cmd,list) and cmd and cmd[0]=='node':cmd=['/opt/homebrew/bin/node',*cmd[1:]]
 if isinstance(cmd,list) and (len(cmd)==4 or len(cmd)==5 and cmd[4]=='file:///Users/emman/Livemore/.worktrees/full-scope-recovery/livemorebio/aegle/console/lib/execution_view_state.js') and cmd[:2]==['/opt/homebrew/bin/node','--input-type=module'] and cmd[2] in ('-e','--eval'):
  counts['node']+=1;permit=True
  try:return run0([*cmd[:3],'import {createRequire as scopedRequire} from "node:module";const require=scopedRequire(import.meta.url);'+prefix+cmd[3],*cmd[4:]],*a,**k)
  finally:permit=False
 if isinstance(cmd,list) and len(cmd)==3 and cmd[:2]==['/opt/homebrew/bin/node','--eval']:
  counts['node']+=1;permit=True
  try:return run0([*cmd[:2],prefix+cmd[2]],*a,**k)
  finally:permit=False
 if cmd==['git','-C','/Users/emman/Livemore/.worktrees/full-scope-recovery','rev-parse','--show-toplevel']:
  counts['git_refused']+=1
  raise subprocess.CalledProcessError(1,cmd)
 return deny()
subprocess.run=run;subprocess.Popen=launch
sys.addaudithook(lambda event,args: deny() if event in {'socket.connect','socket.getaddrinfo','os.fork','os.forkpty','os.posix_spawn','os.system'} or event=='subprocess.Popen' and not permit else None)
class NoModels:
 @pytest.fixture(autouse=True)
 def prevent(self,monkeypatch):
  from livemorebio.tests.clinical_registry_fixtures import forbid_compilation
  from livemorebio.aegle.runtime import AegleTwin, MetabolicProfile
  forbid_compilation(monkeypatch)
  monkeypatch.setattr(AegleTwin,'__init__',deny)
  monkeypatch.setattr(MetabolicProfile,'__init__',deny)
status=pytest.main(["-q","-p","no:cacheprovider","--tb=line","livemorebio/tests/test_molecular_3dmol_ui.py","livemorebio/tests/test_molecular_inspector_ui.py","livemorebio/tests/test_molecular_loader_ui.py","livemorebio/tests/test_molecular_consumer_bindings.py","livemorebio/tests/test_molecular_consumer_boundaries.py","livemorebio/tests/test_molecular_frozen_consumer.py","livemorebio/tests/test_biology_context_reconciliation_ui.py","livemorebio/tests/test_clean_workflow_ui.py","livemorebio/tests/test_clinical_model_availability_ui.py","livemorebio/tests/test_protocol_inspection_ui.py","livemorebio/tests/test_ui_biological_projection.py"],plugins=[NoModels()])
print('Refusal counts:',counts,flush=True)
raise SystemExit(status)
PY
```

## Lesson

Changing only the renderer delivery adapter can preserve scientific/source
admission and asynchronous ownership. A complete app integration additionally
requires the ordinary caller's real signature, render-bound identity and focus
boundary tests. A pure parser test is valuable but is not WebGL or scientific
qualification; root must independently grade the real page.

## Frozen SHA-256 pins

Paths below are relative to the worktree; `lib` means
`livemorebio/aegle/console/lib`.

- `livemorebio/aegle/console/biology.html`: `173624def9816ea30b159676fc8c6a22844cecf9f97e0e8f6adaceb2824ae303`
- `lib/molecular_inspector.js`: `257f5609b85be47e67843ba16a196d86a0fe8e08f527ec19acbc7468245196b0`
- `lib/molecular_inspector.css`: `7c5605ec1daef9b21f74be0964090968dc56f8a5843c7d472c6ba25166f19236`
- `lib/molecular_3dmol.js`: `4b7239778b5613d78ae008b24e2fc7b73e0c81820c9f5e28b22b9e12b0021ccf`
- `lib/molecular_3dmol_frame.js`: `277b5ddd18c1f8895fe72a1b54eff55c70533d95e21cace2c2b40e4c6c452000`
- `lib/molecular_3dmol.css`: `eda401c5f418e2dc74d35e8f37ec48653d5166cafacbd1b0e88b0d7dc825db2d`
- `lib/vendor/3dmol-2.5.5/3Dmol.es6-min.js`: `95513f6494717cc82fb2ba4d264f29b7ef189a31d4ece36a38d1f9666bf6d427`
- `lib/vendor/3dmol-2.5.5/3Dmol.es6-min.js.LICENSE.txt`: `ae3bfc688d0c9687b76e0ecc7fece0b393bcb4acf2aee09e19dda697eaa10b16`
- `lib/vendor/3dmol-2.5.5/LICENSE`: `4c6eaaed856f3f28a3b1a98e74f4a8a71618de7d51ea4155c29f6f793bcef861`
- `lib/vendor/3dmol-2.5.5/THIRD_PARTY_NOTICES.txt`: `c2bba999daf7722149d423a23f0cb3169de1f1e922c110fc2e204a441e89a566`
- `livemorebio/tests/test_molecular_3dmol_ui.py`: `605d3430dd45934a8238b8dc59379b5105f86fbbab90169b3812244d2ef58740`
- `livemorebio/tests/biology_ui_fixtures.py`: `4572416f9c210dac348f20e894e89238291ae41b4bffdbddc9c9392b9b07ed42`
