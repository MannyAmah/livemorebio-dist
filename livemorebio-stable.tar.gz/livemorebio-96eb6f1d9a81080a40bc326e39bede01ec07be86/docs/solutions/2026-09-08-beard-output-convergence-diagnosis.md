# Beard B0/B1 output-convergence failure: retained-evidence diagnosis

2026-09-08. **Diagnosis complete; numerical acceptance remains FAILED.** This
document proposes a later numerical experiment, not permission to run it. No
model callback, original-MathML evaluation, native compilation, ODE solve,
parameter change or acceptance-threshold change was performed for this diagnosis.
Both on-disk execution gates remain false.

## 1. Finding

All **552 failing output/time pairs across ten algebraic quantities** can be
accounted for by the differences between the already-retained B0 and B1 states,
using exact finite-difference identities or first-order derivatives of the pinned
source expressions. No evidence of a generated-C/original-expression mismatch
was found in the previously executed, independently reviewed same-state checks.

The central issue is **output conditioning and insufficient demonstrated
trajectory accuracy for the required outputs**, not a failing state-only test.
Large kinetic multipliers and subtraction of almost equal forward/reverse terms
make small state differences matter substantially to several net fluxes. The
concentration-complement failures have a different cause: the derived, smaller
pool has a smaller relative-error allowance than the state from which it is
subtracted. All 19 state comparisons pass, but that does not imply output
convergence. This is a numerical diagnosis, not attribution of biological cause.

The evidence does not establish which trajectory is closer to the exact ODE
solution. It also does not isolate global integration error from normal-mode
output interpolation error. Neither source accuracy nor human equivalence follows
from these computations.

## 2. Identity, method and reproducibility

The [failed native result](../BEARD_NATIVE_SOURCE_MATRIX_RESULTS.md) records the
single authorized I0a/I0b/B0/B1/R1/K1 attempt. Its immutable
[preregistration](2026-09-08-beard-native-source-preregistration.md) remains SHA-256
`95351a1e380178725ab38731d8e9dc63b57ebd4a1ae507dad17d3884e28167e7`.

The [exact PMR CellML source](https://models.physiomeproject.org/workspace/beard_2005/@@rawfile/8ec69b34c31cd1cbb53580d1853841bb333de78e/beard_2005.cellml)
is commit `8ec69b34c31cd1cbb53580d1853841bb333de78e`, source SHA-256
`4a4f931592df0e77a92c79447bf6d8947c7325f721a74b4d336d370abaaf3981`.
It remains the PMR variant, not a silently substituted version of the paper or
its correction. The original custom units and all source constants remain intact.

Private evidence root: `/private/tmp/livemore-beard-once.bi8ASk/`.

| Retained or diagnostic artifact | SHA-256 |
| --- | --- |
| `livemore-beard-matrix-o81womfv/matrix.json` | `c05c31168f01a9a51eaedb8a69053c2846c11891120a2e52ecb53aaf5b4ed6c9` |
| B0 raw output | `a3b3b4b285eb9917212430cb7c0f6ce292dc3104ab93eb7a26c762c1be3c4c83` |
| B1 raw output | `7ab07ea42259b00d8c455c85785ac4876f2e20f1c649a582243a9b6b311ce997` |
| New read-only `retained_sensitivity.py` | `261d1a7099dac6fdfe09550d8bae28b1ac4b83e923d0f63eac86e651b74d4436` |
| New `retained-sensitivity-diagnosis.json` | `0b73df7c20ee02791be9831539f8c1a96bd3c05cf7e13ce2731d4d639d43aa5d` |

The diagnosis program uses only Python standard-library JSON, hashing and
arithmetic. It checks the matrix/source identities, raw output hashes and equality
of raw rows to retained result rows before calculation. It checks both complete
3,001-point grids and enumerates all failed pairs with the unchanged per-unit
acceptance rule. It imports no model module or native library and performs no
exponential/logarithmic evaluation. The original results are not rewritten.

Here `delta` means B0 minus B1 at the same retained time. Linear derivatives are
evaluated algebraically from the retained B1 values. For exponential expressions,
the forward term is recovered from retained B1 net flux plus the reverse term;
this is a conditioning decomposition, **not an independent implementation of
the source expression**. The independent same-state expression checks are those
already performed during the approved native run, not a new check disguised as
this arithmetic. Exact/bilinear versus first-order treatment is stated below.

## 3. All failing identities and their explanation

Times are the first and last failing samples, not a continuous interval in which
every time fails. `R/allowance` is the maximum unexplained arithmetic remainder
divided by the original comparison allowance across that identity's failed pairs.
Flux units are mol/(s·L mitochondrial volume); concentrations are molar, M.

| Exact algebraic identity | Count; times (s) | Source-state explanation | Max R/allowance |
| --- | --- | --- | ---: |
| `ATP_synthesis_flux.J_F1` | 227; 0.1–46.1 | Exponential membrane-potential/proton dependence, ADP/Pi product, minus Mg-bound ATP; first order | 9.5900e-4 |
| `Potassium_hydrogen_flux.J_KH` | 41; 0.1–6.5 | Exact affine combination of matrix H and K, multiplied by `x_KH` | 3.1533e-8 |
| `MgATPx_binding_flux.J_MgATPx` | 122; 0.3–35.4 | Exact Mg-binding bilinear difference, including the cross term | 6.1325e-9 |
| `MgADPx_binding_flux.J_MgADPx` | 141; 0.3–35.4 | Exact Mg-binding bilinear difference, including the cross term | 2.4716e-7 |
| `Q_concentration.Q` | 2; 0.5–0.6 | Exact `delta Q = -delta QH2`; smaller derived-pool allowance | 0 |
| `Electron_flux_complex_I.J_C1` | 7; 0.5–4.3 | First-order H/potential/QH2/NADH dependence with conserved complements | 1.7606e-6 |
| `Pi_substrate_flux.J_Pi2` | 3; 2.3–4.9 | Exact `-gamma*x_Pi2*delta Pi_i` | 1.3197e-11 |
| `Phosphate_hydrogen_cotransporter_flux.J_Pi1` | 3; 2.3–4.9 | First-order quotient dependence on matrix H and matrix/intermembrane Pi | 2.8671e-8 |
| `NAD_x_concentration.NAD_x` | 3; 3.1–3.3 | Exact `delta NAD_x = -delta NADH_x`; smaller derived-pool allowance | 0 |
| `MgATPx_binding_flux.ATP_fx` | 3; 10.4–10.6 | Exact total-minus-bound ATP difference; smaller free-pool allowance | 0 |

The largest first-order relative remainder over all 552 failures is 2.7506e-5
of that failed difference, for `J_F1`. The largest absolute `J_F1` remainder is
1.0152712e-12 flux units. Thus the source-derived sensitivity calculation explains
the failed differences far more closely than their original acceptance limits.
That agreement explains the failure; it does not waive it.

## 4. Worst point: ATP synthesis flux at 4.3 s

The retained values are:

- B0: `5.7914615230541705e-5` mol/(s·L mitochondrial volume).
- B1: `5.8681673539786745e-5` in the same units.
- Difference: `-7.670583092450408e-7`.
- Allowed absolute difference: `1.0586816735397868e-9`.
- Normalized discrepancy: **724.5410291087028**, therefore failed.

With `x` denoting matrix and `i` intermembrane, the source has
`J_F1 = x_F1 * (E * ADP_mx * Pi_x - c0 * ATP_mx)`, where `c0` is the
source's literal **1 M**, not an omitted dimensionless constant.
`E = exp((-dG_F1o + n_A*dG_H)/RT) * K_DD/K_DT` and
`dG_H = F*dPsi + RT*ln(H_i/H_x)`. The constants are unchanged:
`x_F1=150.93` mol/(s·L mitochondrial volume·M²), `n_A=3`,
`F=0.096484` kJ/(mol·mV), `RT=2.4734` kJ/mol.

Let `U = J_F1(B1)/x_F1 + c0*ATP_mx(B1)`, the retained forward term in M².
The first-order contributions are:

| State | B0−B1 state difference | Fraction of its state allowance | Contribution to delta J_F1, flux units |
| --- | ---: | ---: | ---: |
| Matrix H | 1.56336613e-15 M | 0.001456 | -1.91557177e-8 |
| Membrane potential | -1.60201172e-5 mV | 0.058449 | -5.64758364e-7 |
| Mg-bound matrix ADP | 4.72656660e-10 M | 0.162549 | 5.07103498e-8 |
| Matrix phosphate | -1.21594140e-10 M | 0.556496 | -3.09108312e-7 |
| Mg-bound matrix ATP | -4.98593512e-10 M | 0.237934 | 7.52527188e-8 |

These are respectively
`-x_F1*U*n_A/H_x*delta H_x`,
`x_F1*U*n_A*F/RT*delta dPsi`,
`x_F1*U/ADP_mx*delta ADP_mx`,
`x_F1*U/Pi_x*delta Pi_x`, and `-x_F1*c0*delta ATP_mx`.
Their sum is `-7.670593245161915e-7`. The remainder is only
`1.0152711506809044e-12`, or 1.3236e-6 of the actual discrepancy.

At B1 this forward term is `0.0019959019984264414 M²`; the reverse term is
`0.0019955131978331877 M²`. Their difference is `3.8880059325373843e-7 M²`.
The ratio `(abs(forward)+abs(reverse))/abs(net)` is **10,265.97**.
This near cancellation magnifies the importance of small changes in inputs.
Potential and phosphate differences dominate this particular decomposition.

For scale only, assigning the entire output allowance to one first-order term
would require approximately `3.0e-8 mV` potential difference, `4.2e-13 M`
phosphate difference, or `8.6e-17 M` H difference. These are local sensitivity
budgets at this point, not justified solver tolerances, biological uncertainty
bounds, or independent errors that may simply be added without accounting for
correlation and the other terms.

## 5. Other conditioning mechanisms

### Fast Mg binding

The source uses `x_MgA=1e6` mol/(s·L mitochondrial volume·M²),
`K_DT=2.4e-5 M` and `K_DD=0.000347 M`:

`J = x_MgA * ((total - bound)*Mg_x - K_D*bound)`.

Its exact finite difference is
`x_MgA * (Mg_1*delta total - (Mg_1+K_D)*delta bound + free_1*delta Mg +
(delta total-delta bound)*delta Mg)`. The last term is retained, not discarded.

At 30.2 s the Mg–ADP net forward/reverse terms are approximately
`9.26343468696e-7` and `9.26343468779e-7 M²`. Their cancellation ratio is
**2.2273345921e10**. B1's net flux is `-8.3179552101e-11`, while the B0/B1
difference is `-8.8991346553e-9` flux units. Mg–ATP at the same time has a
cancellation ratio of **1.1668894850e9** and a B0/B1 flux difference of
`7.0450343789e-9`. Retained state differences explain both with the exact
bilinear identity. These numbers do not establish binary64 roundoff as the
dominant cause; the two trajectories already differ in their inputs.

### Transport and conserved complements

`J_KH=x_KH*(K_i*H_x-K_x*H_i)` with `x_KH=29802000` in the source's
flux-per-M² unit. At 4.3 s its H and K state-difference contributions are
`6.9887e-9` and `7.8516e-9` flux units, accounting for `1.48402741e-8` total.
`J_Pi2=gamma*x_Pi2*(Pi_e-Pi_i)`, with fixed external Pi and
`gamma*x_Pi2=1958.73/s`. A `-1.00347145e-12 M` intermembrane Pi difference
therefore gives a `1.96552963e-9` flux difference at 4.3 s.

`Q=Q_total-QH2` and `NAD_x=NAD_total-NADH_x` do not amplify absolute error.
Their errors are exactly the negatives of their state differences. They fail
because a smaller complement receives a smaller relative allowance. Likewise,
free ATP's `3.841055815e-10 M` discrepancy at 10.5 s is exactly total ATP's
`2.241150396e-9` minus bound ATP's `1.857044815e-9 M` difference; its own
allowance is about `3.715e-10 M`.

For complex I the retained forward term is `V=J_C1/x_C1+NAD_x`. Differentiating
the exact source expression gives coefficients `5*x_C1*V/H_x`,
`-4*x_C1*V*F/RT`, `-x_C1*V*(1/Q+1/QH2)` and
`x_C1*(V/NADH_x+1)` for H, potential, QH2 and NADH differences. The factor 5
includes both the source free-energy H term and the four proton-motive terms.
At 0.6 s the calculated discrepancy is `2.460677877e-9`, versus retained
`2.460679918e-9`. Phosphate cotransporter's quotient derivative similarly
accounts for its discrepancy, dominated by matrix Pi at 4.3 s. The diagnostic
JSON retains the full per-point inputs, units, terms and remainder.

## 6. What the solver and output precision do, and do not, establish

CVODE's error weights apply to the integrated state vector, with denominators
`RTOL*abs(y_i)+ATOL_i`; local-error control is not direct control of every
algebraic output or global trajectory error. See the official
[CVODE 7.8 mathematics](https://sundials.readthedocs.io/en/v7.8.0/cvode/Mathematics_link.html).
Its documentation supports per-state absolute tolerances and recommends
examining how solutions change when tolerances decrease. Normal mode may step
past a requested time and interpolate back. See the official
[tolerance and output APIs](https://sundials.readthedocs.io/en/v7.8.0/cvode/Usage/index.html).

The executed scalar settings were B0 `RTOL=1e-7, ATOL=1e-11` and B1
`RTOL=1e-9, ATOL=1e-13`, applied numerically in each state's own native unit.
They were not output-error guarantees. The native C recorder uses `%.17g`, not
display-rounded values. At the worst J_F1 point the B1 flux's binary64 spacing is
`6.7762635780e-21`, far below the `7.6706e-7` observed discrepancy. Decimal
serialization resolution cannot explain this failure.

Output sampling was 0.1 s, not fixed internal stepping. The results document now
explicitly distinguishes recorded endpoints from internal terminal times and
notes that compiler receipts contain no RSS samples. Neither clarification
changes acceptance. Retained rows alone do not separate interpolation and
integration contributions. No admitted experimental transient data resolve
which numerical trajectory is physically accurate. Do not change the comparison
floor to a claimed measurement resolution that has not been supplied.

## 7. Proposed corrective experiment, NOT authorized or implemented

The evidence supports a **new numerical-precision study**, not a kinetic change.
Keep this failed v1 matrix permanently. Keep its source variant, initial values,
constants, complete state/unit mapping, output grids, strict redox/domain/pool
checks, zero-subspace checks, source-expression checks and all output acceptance
floors unchanged. Do not filter the ten difficult outputs or substitute a
state-only acceptance test.

Proposed next design for root and independent reviewer consideration:

1. Freeze a new numerical manifest with two tighter independent solves using
   proposed scalar pairs `RTOL/ATOL = 1e-11/1e-15` and `1e-12/1e-16`. These
   proposed settings are a bounded precision ladder, not fitted physiology or a
   promise that the output gate will pass. Comparison to retained B1 is diagnostic;
   the old B0/B1 result never changes. No successive retries chosen after seeing
   results are allowed.
2. Include one same-tolerance comparator at the tighter pair with a proposed
   `hmax=0.01 s`, while retaining the identical 0.1 s requested output grid. This
   challenges dependence on the combined stepping/interpolation procedure; it
   does not isolate interpolation error by itself. Reject work/resource failures
   under the existing bounds rather than raising limits during a run.
3. Require every state and algebraic output in both new adjacent-precision and
   bounded-step comparisons to meet the existing per-unit thresholds. Report
   all counts and maxima, including values near zero. Also preserve independent
   source-expression and initialization checks. A fresh repeat and full-state
   t=150 restart of the candidate must be prespecified before execution if this
   is intended as acceptance rather than exploratory diagnosis.
4. If the precision ladder does not settle the outputs, stop that candidate.
   Propose a separately reviewed unit-aware error-weight or higher-precision
   study using sensitivity budgets across the full retained trajectory. Do not
   choose a vector from the single worst point, remove source units, alter fast
   binding constants, clamp outputs, or relabel model discrepancy as measurement
   noise. An independent solver comparison would require its own pinned runtime
   and source/units-equivalence admission, not a fallback switch.

The proposed tighter values remain well above binary64 relative roundoff but
are not guaranteed feasible. Relative and absolute settings are solver
parameters, not acceptance criteria. This document does not amend the immutable
preregistration, implement these changes, authorize a driver, or enable a gate.
Root must first approve the scientific rationale, then a complete new numerical
manifest, red-first implementation and independent code review before any run.

## 8. Program continuity and lesson

All six requested programs remain active requirements: exogenous insulin;
Erinacine A/Lion's Mane LBHR-172; Sterubin/Yerba Santa LBHR-129; Carnosic
acid/Rosemary LBHR-062; Arctigenin/Burdock LBHR-030; and cyanidin
3-glucoside/Bilberry LBHR-135. See the
[six-program dependency record](2026-09-08-five-program-mechanism-measurement-plan.md).
This mitochondrial source diagnosis addresses one mechanism dependency, not an
arctigenin exposure-response model or any completed individualized human program.
The exact default zero intermembrane nucleotide subspace still prevents an ATP
export claim. Compound-specific kinetics, exposure, tissue context, individual
parameters and independent physical qualification remain separate requirements.

Durable lesson: numerical acceptance must cover the quantities the experiment
will report. A state may converge within its own units while a derived net flux
does not, particularly near forward/reverse cancellation. Preserve failed runs
and diagnose source algebra before changing numerical methods. Never weaken
output gates to make a biological visualization appear successful.

Independent review of this diagnosis/proposal: **pending**. The independent
reviewer has already confirmed the original failed matrix, not yet this new
sensitivity decomposition or proposed next numerical design.
