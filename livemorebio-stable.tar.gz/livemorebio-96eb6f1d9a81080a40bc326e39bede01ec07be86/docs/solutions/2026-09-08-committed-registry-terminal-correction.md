# Committed registry transitions — terminal trust and preparation correction

2026-09-08. **Pre-code proposal. No correction is implemented or authorized by
this document.** The frozen maker packet remains at subjects SHA `f1bf94c2…`,
audit `245eb356…`, tests `8eaff7fa…`, with the prior report retained unchanged.
This narrowly amends the approved committed-source interface, not clinical model
eligibility, bootstrap, physical-v3, OSP or full-product acceptance.

## Independently reproduced defects

The UI reviewer reran all 374 scoped cases and then used new authored private
SQLite trigger fixtures. With the trigger installed after preparation:

1. A terminal audit INSERT trigger, distinguished by an existing reservation,
   replaces the new ciphertext with one byte. The current helper trusts its
   post-finish SELECT as the witness and returns COMMITTED with a corrupt audit.
2. A terminal audit INSERT trigger instead sets the target SQL version to999.
   The current helper checked the clinical/index state before `finish`, so it
   returns COMMITTED with prepared version2 and stored version999.

The current preparation also calls `admitted_human(...).metabolic_profile(None)`
after closing its registry connection. That is still inside root's outer source
authority guard. Closing the database connection does not satisfy the separate
no-profile/model-construction-under-authority requirement.

## Minimal audit witness correction

Keep all existing public audit inputs and `finish(...) -> str` behavior. No new
persistent receipt, audit field, AAD, key, table or transaction framework:

- Factor encryption/insertion into private `_append_row(connection, payload)`.
  Before INSERT, construct the exact immutable tuple
  `(event_id, sequence, nonce, ciphertext)` from the payload, generated identity,
  nonce and authenticated ciphertext. Preserve the existing canonical payload
  serialization and4096-byte bound. Return that original tuple, never a tuple
  constructed from a post-insert database SELECT.
- Verify the inserted row equals that original tuple before returning. `_append`
  remains a compatible private ID-returning adapter. `begin` retains the original
  tuple across both event INSERT and reservation INSERT, then verifies that tuple
  **after reservation insertion** before returning its unchanged AuditReservation.
  Also require the exact `(event_id, request_id)` reservation row at this point;
  a trigger-deleted or substituted reservation is not a complete durable BEGIN.
  This catches either an event-INSERT trigger or reservation-INSERT trigger;
  checking the event only before the last BEGIN write would repeat the defect.
- `finish` obtains the original terminal tuple, deletes exactly its reservation,
  then verifies that exact terminal row again before returning its ID. The second
  check also catches reservation-DELETE triggers that alter the event. A missing,
  resealed, sequence-shifted or replaced row raises fixed RegistryAuditError.
  Its original payload derives from the authenticated reserved BEGIN and the
  fixed SUCCESS/ACCESS_FAILED operation, completion clock and current source/
  process/store identities; no externally supplied terminal payload is admitted.

The commit helper must then **after `finish` and all its writes**, immediately
before mutation commit, compare the complete expected record/index/topology
evidence again, the original BEGIN, the verified terminal row and reservation
absence. No further writes occur between this final check and commit. The held
SQLite writer transaction excludes a separate writer between terminal verification
and the caller's retained raw-row capture; SELECT has no user callback here.
The lost-ACK read-only witness uses those checked expected bytes unchanged.

An alternative return type or witness callback is unnecessary: the audit helper
itself proves origin-byte equality before returning, and the caller captures
the verified row under the same unchanged writer transaction. No mutable global
"last event" is introduced. If independent review requires returning the tuple
instead, freeze that interface before code; do not infer a new public contract.

Any failed terminal/record check rolls back the mutation. The existing reserved
ACCESS_FAILED completion is attempted using the same safe audit path; if a
malicious fixture trigger also corrupts that attempt, preserve the original
error and pending reservation rather than claiming a completed failure receipt.
Never return COMMITTED or publish the prepared identity in these cases. Unknown
rollback or lost-ACK confirmation remains SELECTION_COMMIT_UNCONFIRMED.

The failure completion must not repeat the late-record side effect: after the
main mutation rollback is confirmed, obtain the writer transaction/authority for
the reserved failed-access completion, capture the current bounded raw relevant
record/index/pointer/ACTIVE baseline, write ACCESS_FAILED, then recompare that
baseline before its commit. A different value rolls back this audit attempt and
retains its reservation/primary error. Capture this baseline freshly, not from
the prepared snapshot, because a legitimate competing change or the original
snapshot conflict may precede the failed-access attempt. No clinical decrypt,
new record scan, mutation retry or false successful failure receipt is needed.

## Preparation and direct-wrapper boundary

Make `_activation_transition_admission` purely structural: retain the exact
source/class/context/admission checks, but remove its profile switch and all
human/profile construction. `prepare_activation` may call this pure validation
and freeze the timestamp, never `admitted_human`, `.profile`, `metabolic_profile`,
`build_twin`, an AegleTwin constructor or a numerical method.

Root's server prepares its candidate/model/state/response after releasing source
authority, then performs final exact prepared commit/publication under its guard.
That is where server numerical/profile admission belongs. This packet does not
edit the server. For the standalone `activate_twin` wrapper, preserve the prior
non-SYNTHETIC profile admission as an explicit precommit step after the prepared
read returns and before the commit helper is called, with no registry/source/
manager lock owned by the wrapper. SYNTHETIC behavior remains unchanged. An invalid
candidate must prevent commit. No REAL_HUMAN binding is introduced or bypassed.

## Red matrix and preservation

Author the two independent trigger reproductions before code, then extend with:

- terminal sequence/nonce/ciphertext/ID replacement and DELETE-trigger corruption;
- BEGIN event/reservation-INSERT corruption, including a valid ordinary BEGIN
  control, with no protected clinical read before the verified durable BEGIN;
- late target/demotion row, pointer and physical-index edits, plus second-ACTIVE
  injection, all after terminal insertion; retain original clinical/index bytes
  after confirmed rollback and never return success;
- origin-tuple versus a different, validly encrypted terminal row in an authored
  fixture, proving ciphertext authenticity alone is insufficient;
- existing normal/lost-ACK/close-failure outcomes and per-component witness tests
  unchanged; final failure-audit corruption preserves the primary failure;
- a record-changing terminal trigger on both SUCCESS and ACCESS_FAILED: neither
  completion may silently persist the record side effect; confirmed original
  clinical/index bytes remain, the failed-access reservation stays pending;
- mocked profile/human constructors that fail if preparation or final commit
  invokes them, including an actual supported aggregate-reference-shaped record;
- standalone candidate admission runs outside registry transactions and before
  commit; a rejected candidate performs no mutation. Keep source/stratum and
  REAL_HUMAN missing-binding guards unchanged.

Run the exact370-case preservation command and four legacy lifecycle nodes from
the frozen maker report, expanded by the new red cases. Only authored private
data and network/native tripwires; no HTTP, browser, service or source execution.
The audit-only factoring must preserve original record bytes, old audit payloads,
AAD, reservations and all caller return expectations. Freeze new hashes and an
append-only correction report for independent review; do not replace the failed
candidate evidence. Atlas harness implementation stays paused during this work.

Ownership remains subjects.py, registry_audit.py and the dedicated registry test
file. No original observation-selection/reconciliation/startup weakness is claimed
fixed by these corrections. Root and the independent reviewer must approve this
proposal before implementation.

## Pre-code approvals

Root fully read the original120-line proposal, complete audit code, independent
findings and expanded133-line proposal, requiring the BEGIN-after-reservation
boundary. The independent UI reviewer read all133 lines and cleared the bounded
design conditional on the exact reservation tuple check now added above. Root
then authorized red-first implementation of this correction, preserving public
returns, audit payload/AAD/quota, primary-error semantics and the unrelated open
families. Release redteam will independently grade the corrected frozen packet;
this approval is not runtime/service/browser execution or product acceptance.
