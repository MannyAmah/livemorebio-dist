# Executable Multiscale Human Workspace Plan

Date: 2026-08-30
Branch: `codex/patch-closed-loop-adapters`
Status: approved for implementation by the user
Design source: approved A+B multiscale workspace

## Outcome

Build the approved A+B operating workspace over a shared executable biology contract. The
workspace must expose biological computation performed by Aegle, LIFE Patch, and Cendos. It must
not maintain a second UI-only biological state.

The first deep functional slice is cardiovascular-metabolic pharmacology. The whole-body
framework includes every registered human system, but a system without an executable engine must
return `UNAVAILABLE`, not fabricated physiology.

```text
genes / variants
      |
RNA / proteins / molecular interactions
      |
cell functions and signaling
      |
tissue transport and mechanics
      |
organ physiology
      |
whole-body regulation and homeostasis
      |                         ^
      v                         |
physical / virtual LIFE Patch  |
      |                         |
      v                         |
Cendos counterpart validation -+
```

## Scope decision

Mode: HOLD SCOPE. The user explicitly selected the A+B design and explicitly required the
executable multiscale system underneath it.

Three approaches were considered:

1. UI adapter only. Lowest effort, rejected because it repeats the previous error: a dashboard
   that displays biological labels without a shared executable contract.
2. Replace Aegle, LIFE, and Cendos with a new monolith. Rejected because it destroys working
   closed-loop, evidence, SDK, and terminal behavior and creates an untestable migration.
3. Shared contracts plus a strangler-style orchestration layer. Selected. Existing engines and
   product routes remain authoritative; the new workspace consumes their common state.

## What already exists and will be reused

| Capability | Existing implementation | Decision |
|---|---|---|
| Whole-human ontology | `livemorebio/anatomy/ontology/` and `foundation.py` | Extend with runtime contracts; do not duplicate |
| Glucose-insulin physiology | `engines/metabolic/glucose_insulin.py` | Reuse as endocrine/metabolic execution |
| Cardiac electrophysiology | `engines/cardiac/action_potential.py` | Reuse as cardiomyocyte execution |
| Heart rate/HRV | `engines/cardiac/heart_rate.py` | Reuse as organ/system output |
| Individualized PK | `engines/hepatic_pk.py` and `engines/pharmacology.py` | Reuse dose-to-exposure and genotype gates |
| Genome-scale metabolism | `engines/metabolism.py` and `engines/coupling/gem_metabolic.py` | Reuse molecular-to-physiology bridge |
| Metabolic-cardiac coupling | `engines/coupling/metabolic_cardiac.py` | Reuse with explicit applicability limits |
| Physical/virtual Patch contract | `life_patch/protocol.py` and `gateway.py` | Add observation-model reconciliation; preserve admission |
| Cendos counterpart evidence | `cendos/counterparts.py` and `evidence/` | Add bounded qualification result; preserve evidence gate |
| Cross-product transport | encrypted bus, registry, snapshots | Reuse; add typed workspace projection |
| Existing products | `/biology`, `/patch`, `/cendos`, `/adapters` | Preserve and link from workspace |
| Terminal and SDK | `cli.py`, `shell.py`, `sdk.py` | Add workspace/multiscale access without breaking commands |

## Functional contracts

Each executable biological module declares:

- module and model identity;
- biological scale and anatomical identifiers;
- state variables and UCUM-compatible units;
- typed inputs and outputs;
- biological time scale;
- person-specific parameter sources;
- executable engine and version;
- observation mappings;
- supported perturbations;
- evidence class, uncertainty, applicability, and maturity;
- upstream and downstream module links.

Each execution returns both current state and a causal trace. A trace node cannot claim a scale or
mechanism that the bound engine did not compute.

```text
FunctionalModuleContract
  +-- identity / scale / anatomy
  +-- variables[] {name, value, unit, provenance}
  +-- inputs[] / outputs[]
  +-- time_scale
  +-- person_parameters[]
  +-- observation_mappings[]
  +-- perturbations[]
  +-- applicability / uncertainty / evidence
  +-- engine {id, version, citations}
```

## First executable path

The cardiovascular-metabolic path is assembled from existing engine outputs:

```text
SLC22A1 genotype
  -> OCT1 transport factor
  -> metformin hepatic exposure
  -> hepatic glucose-output parameter
  -> Bergman glucose and insulin trajectories
  -> mean glycemic exposure
  -> bounded metabolic-cardiac coupling
  -> IKr input to O'Hara-Rudy ventricular cell
  -> APD90 / calcium transient / HR and HRV
  -> whole-body metabolic and cardiovascular state
```

All coefficients retain their current model-only framing. The trace reports literature source,
engine identity, and limits. It does not promote a mechanism to clinical validation.

## LIFE Patch reconciliation

Physical and virtual telemetry already share the v2 envelope. Add a deterministic reconciliation
projection that compares admitted observations with the virtual sensor values predicted from the
same twin state.

```text
admitted physical observation ----+
                                   +--> unit check --> residual --> tolerance class
virtual observation from twin -----+                         |
                                                             +--> evidence / review
                                                             +--> no automatic calibration
```

Results include signal, observed value, predicted value, unit, residual, normalized residual,
quality state, source envelope, and allowed next action. Missing, mismatched, or failed-QC inputs
remain explicit. Reconciliation never mutates `profile_params`.

## Cendos qualification

Cendos compares a frozen prediction with a qualified counterpart measurement only when subject,
endpoint, unit, time window, protocol, QC, and calibration bindings agree. The output is a bounded
qualification record for the declared population, intervention, dose, endpoint, and tolerance.

```text
frozen prediction + pre-approved criterion + qualified measurement
       -> binding checks
       -> absolute-error calculation
       -> pass / fail / not-assessable
       -> evidence package event
       -> optional later calibration authorization through EvidenceService
```

The new projection does not bypass the existing evidence lifecycle or authorize calibration.

## Workspace architecture

```text
Browser A+B workspace
  |
  +-- GET /api/workspace -----------------------------+
  |                                                   |
  +-- POST /api/workspace/actions                     |
          |                                           |
          v                                           |
      AegleTwin.stimulate / existing experiment APIs  |
          |                                           |
          +--> shared multiscale execution -----------+
          +--> LIFE Patch reconciliation              |
          +--> Cendos snapshot / qualification        |
          +--> signed audit + encrypted event bus ----+

Standalone preserved surfaces:
  /biology  /patch  /cendos  /adapters  /docs
```

The aggregate endpoint is a read projection. Mutations continue through authenticated existing
paths. Workspace actions have a lifecycle record:

```text
QUEUED -> RUNNING -> COMPLETED
                   \-> FAILED
```

Invalid transitions are rejected. Every record has action ID, subject binding, origin, timestamps,
engine links, evidence links, and a PHI-safe error code.

## User experience

The root Aegle page becomes the approved A+B workspace:

- far-left product navigation;
- green Atlas tab;
- multiscale path: Whole Body > Cardiovascular > Heart > Ventricular Tissue >
  Cardiomyocyte > Ion Channel > Gene / Protein;
- live anatomy viewport bound to `/api/workspace`, with a non-WebGL functional fallback;
- biological-time scrubber over returned model time arrays;
- intervention controls using authenticated existing actions;
- baseline-versus-treated physiological plots;
- evidence inspector with observed, modeled, reference, calibrated, and validated states;
- physical-versus-virtual LIFE Patch residuals;
- model lineage and applicability;
- visible action lifecycle and failures.

Every interactive control must visibly change a returned state, focus, trace, action status, or
error surface. Static controls are not permitted.

## Error and rescue registry

| Codepath | Failure | Rescue | User-visible result |
|---|---|---|---|
| Contract construction | non-finite value or missing unit | reject with typed validation error | module unavailable with reason |
| Multiscale execution | engine output missing | omit affected trace and mark unavailable | partial state banner |
| Patch reconciliation | signal absent | `not_assessable` row | missing observation/prediction reason |
| Patch reconciliation | unit mismatch | do not compare | unit mismatch error |
| Cendos qualification | binding mismatch | reject before calculation | named binding failure |
| Workspace projection | Cendos snapshot absent | empty qualified-measurement state | Cendos awaiting result |
| Workspace action | invalid input | HTTP 422, no mutation | field-specific error |
| Workspace action | engine failure | FAILED lifecycle, retain prior state | retryable error with action ID |
| Browser fetch | timeout/offline/401/5xx | retain last state, stop pending UI | recoverable banner and retry |

No new catch-all handler may swallow a failure. Existing silent bus-publish handlers touched by this
change must emit a PHI-safe diagnostic event or structured logger record.

## Security and data boundaries

- `/api/workspace` is an authenticated PHI-like read.
- Workspace mutations use the existing operator-token middleware.
- Subject identifiers exposed to Cendos or logs remain pseudonymized.
- No raw clinical notes or observations enter browser logs, server exception strings, or audit
  summaries.
- Numeric and string inputs are bounded and finite.
- No new third-party browser dependency is introduced.
- Existing Patch attestation, anti-replay, admission signatures, local encryption, and evidence
  separation remain mandatory.

## Test map

```text
CONTRACTS
  +-- valid units, scales, identifiers, variables
  +-- reject non-finite / missing / duplicate state
  +-- unavailable modules return reasons, never fake values

MULTISCALE EXECUTION
  +-- healthy and T2D produce different person-specific traces
  +-- SLC22A1 genotype changes PK trace and downstream state
  +-- metformin trace spans all implemented scales
  +-- reset returns deterministic baseline
  +-- scenario execution does not mutate an unrelated live twin

PATCH
  +-- physical and virtual use the same signal mapping
  +-- residual math and unit checks
  +-- missing/failed-QC paths
  +-- reconciliation cannot mutate model parameters

CENDOS
  +-- endpoint/unit/subject/time-window binding
  +-- pass/fail/not-assessable qualification
  +-- qualification alone cannot authorize calibration

API / PRODUCT PRESERVATION
  +-- workspace auth and schema
  +-- action lifecycle success and failure
  +-- /biology /patch /cendos /adapters remain available
  +-- existing API regression suite remains green

E2E
  +-- load root workspace
  +-- navigate every product
  +-- select every multiscale level
  +-- run metformin and observe returned biological changes
  +-- emit virtual Patch and inspect residuals
  +-- run Cendos assay and inspect evidence state
  +-- test loading, empty, partial, auth, and failed-action states
```

## Performance

- The workspace endpoint performs no outbound scientific-database requests.
- It projects the current in-memory twin and bounded local snapshots.
- Multiscale traces reuse existing simulation arrays and downsampled state.
- Maximum action history and event history are bounded.
- The anatomy renderer loads only the selected scale assets.

## Governed scientific-source layer

The NAR database collection and ELIXIR Core Data Resources are part of the same product
infrastructure, but catalog presence is not operational integration. Every source moves through an
explicit, monotonic lifecycle:

```text
cataloged -> evaluated -> configured -> operational -> workflow_wired -> scientifically_qualified
```

The source catalog records collection membership, organism, data type, access method, version,
provenance URL, licence, permitted use, workflows, review date, and lifecycle evidence. An
unevaluated or licence-unknown source is never queried by an experiment. Runtime routing returns
only `workflow_wired` or `scientifically_qualified` sources for the requested scientific workflow.

```text
NAR / ELIXIR metadata snapshots
        -> governed source catalog
        -> licence + access + identity evaluation
        -> configured adapter
        -> bounded operational probe
        -> workflow-specific mapping
        -> scientific qualification record
        -> Aegle / LIFE / Cendos use within the qualified context
```

Evidence remains separated into reference facts, executable-model output, LIFE Patch observation,
Cendos wet-lab measurement, and clinical validation. Retrieval cannot promote one class into
another.

Backend decisions:

- NetworkX is the deterministic local/test implementation.
- Neo4j is accessed through a backend interface with parameterized writes, explicit environment
  configuration, and a live-test gate. Community Edition is not treated as adequate PHI-like
  production authorization infrastructure.
- TuringDB remains an isolated evaluation candidate until commercial licensing, durability,
  access-control, and benchmark gates pass.
- OpenMed is local clinical de-identification/entity intake using its current public Python API. It
  is not an executable-biology or biological-reaction engine.

Initial routing domains are genome/variants, cells/tissues, proteins/structures,
reactions/metabolism, drug discovery, experimental evidence, and microbiome/infectious disease.
The catalog may contain every discoverable NAR/ELIXIR entry while only a qualified subset is wired.

## Rollout and rollback

1. Add contracts and tests without changing routes.
2. Add read projection and action lifecycle.
3. Add Patch and Cendos projections.
4. Add the new root workspace while retaining the prior console as `/legacy`.
5. Run full Python and browser suites.
6. Keep rollback to the prior root page as a single route/template change.

## Not in scope for this implementation slice

- Deep executable models for every remaining body system. The framework includes their contracts,
  but only implemented engines return state.
- Physical hardware fabrication, firmware release, or human-use claims.
- Automatic calibration from Patch or Cendos results.
- Bulk copying of every NAR/ELIXIR database's scientific contents. Complete catalog metadata and a
  reproducible refresh path are in scope; content ingestion remains source-specific and gated.
- Deferred C pharma operations console.
- Unreal/MetaHuman replacement of the browser workspace.

## Definition of done

- Shared contracts and cardiovascular-metabolic trace are executable and tested.
- Patch residuals and Cendos qualification are governed and tested.
- A+B root workspace operates all implemented interactions.
- Existing product routes and APIs pass regression tests.
- Terminal/SDK expose the same state and actions.
- Browser QA includes screenshots and an interaction recording.
- Independent code and design reviews have no unresolved critical findings.

## GSTACK REVIEW REPORT

| Review | Trigger | Why | Runs | Status | Findings |
|---|---|---|---|---|---|
| CEO Review | `/plan-ceo-review` | Scope and strategy | 1 | CLEAR | HOLD SCOPE; shared-contract approach selected |
| Eng Review | `/plan-eng-review` | Architecture and tests | 1 | CLEAR | Preserve engines/routes; add bounded projections and failure tests |
| Design Review | approved A+B design | UI direction | 1 | APPROVED | A with B body/atlas/biological-time elements |

**UNRESOLVED:** 0

**VERDICT:** CEO and engineering scope are clear for implementation. Diff-scoped review and live
browser design review remain required after code changes.

## Phase 2 correction: subject lifecycle, approved-design parity, and live operation

Date added: 2026-08-30
Branch: `codex/interface-twin-onboarding`
Mode: HOLD SCOPE

The first implementation established the executable multiscale projection, but the live product
audit found three release-blocking omissions relative to the approved A+B design and the inherited
product:

1. there is no first-class workflow to create, activate, or inspect a digital twin or cohort;
2. the whole-body viewport can collapse to an empty ellipse when WebGL is unavailable;
3. the root virtual Patch action supplies a nonconforming subject identifier and fails before the
   LIFE-to-Aegle reconciliation loop completes.

The phase also removes the manual token-copy ceremony for the launched loopback workbench. It does
not remove mutation authentication. A loopback-only, same-origin bootstrap will establish an
HttpOnly, SameSite session cookie. CLI, SDK, notebooks, and external clients continue to use the
owner-only launcher token automatically.

### Product contract

```text
consented person / governed synthetic specification
        |
        v
data admission bundle
  - source class
  - consent and purpose
  - provenance and timestamps
  - observed values and units
  - person parameters and inference labels
        |
        v
TwinRecord: DRAFT -> DATA_ADMITTED -> ACTIVE -> ARCHIVED
        |                         |
        |                         +--> physical / virtual LIFE Patch binding
        |                         +--> Aegle executable state
        |                         +--> Cendos experiment subject binding
        v
CohortRecord: DRAFT -> FROZEN -> EXECUTING -> COMPLETE
```

A real-human twin cannot be activated from fabricated defaults. Real-human activation requires an
admitted observation bundle, explicit consent scope, chain-of-custody metadata, and a pseudonymous
subject identifier. Values not observed from the person remain visibly reference-initialized or
model-inferred. A governed synthetic twin is allowed for demos and preclinical hypothesis work, but
must remain labeled `SYNTHETIC` through Aegle, LIFE Patch, Cendos, exports, and recordings.

### Persistent subject registry

Add a bounded local registry for twin metadata, admitted biological data, cohort membership, and
Patch bindings. PHI-like payloads are encrypted with the existing owner-only local storage key.
Indexes contain only opaque IDs, lifecycle state, source class, and timestamps. No name, clinical
note, biomarker value, genotype, or device serial is written to logs or plaintext indexes.

```text
POST /api/twins                 create draft and admit data
GET  /api/twins                 list PHI-safe summaries
GET  /api/twins/{id}            read one authorized record
POST /api/twins/{id}/activate   bind record to the executable Aegle state
POST /api/twins/{id}/patches    bind physical or virtual device contract
POST /api/cohorts               create/freeze a reproducible cohort definition
GET  /api/cohorts               list cohort summaries
GET  /api/workspace/stream      same-origin server-sent state updates
```

Every mutation is finite, bounded, schema-validated, audited, and conflict-safe. Repeated submits
must be idempotent or return a named conflict. Activating one twin must never mutate stored data for
another twin.

### Approved A+B interface parity

The approved merged design is the pixel and information-architecture baseline:

- top tabs: Atlas, Twin, Patch, Cohorts, Evidence, Lab, API;
- left product rail preserved across the workspace;
- whole-body figure, multiscale column, biological time, intervention controls, evidence inspector,
  and baseline-versus-treated results visible together;
- the Twin view owns creation, data admission, activation, and Patch pairing;
- the Cohorts view owns cohort definition, membership provenance, freeze state, and experiment handoff;
- Biology remains the deeper anatomy/mechanism explorer and is not reused as the whole-body view.

The whole-body view has two renderers over the same state contract. WebGL remains the enhanced 3D
renderer when supported. A first-class inline SVG renderer is always available and shows an
anatomical body, organs, circulation, Patch mount, and scale focus. Heart pulsation is driven by the
returned heart-rate value; vascular flow speed is derived from the same returned state; metabolic
activity follows the returned glucose trajectory and biological-time cursor. Contract-only systems
do not animate as executed physiology.

### Live state and visible interaction requirements

- Server-sent events update the active twin summary, engine time, Patch connection, and action
  lifecycle without a page reload.
- Every top tab, rail item, scale node, evidence tab, body control, onboarding step, cohort action,
  intervention, and Patch action changes a visible state or presents a named error.
- Loading, empty, validation, conflict, disconnected, partial-engine, and unavailable-renderer states
  are designed states, not alerts or console-only failures.
- Motion is disabled or reduced when `prefers-reduced-motion` is active.
- A recording-mode fixture uses synthetic records only and includes no local PHI.

### Additional failure and rescue map

| Failure | Named response | Rescue and visible state |
|---|---|---|
| real-human twin lacks admitted observations | `TWIN_DATA_REQUIRED` | keep DRAFT; show required fields and provenance |
| consent or purpose missing | `CONSENT_REQUIRED` | do not persist/activate; focus consent step |
| duplicate idempotency key | existing result or `IDEMPOTENCY_CONFLICT` | no duplicate twin/cohort |
| activation races with another request | `TWIN_VERSION_CONFLICT` | reload current version and retry explicitly |
| Patch subject namespace is invalid | `PATCH_SUBJECT_BINDING_INVALID` | derive from active opaque twin ID; no telemetry admission |
| Patch device is bound to another twin | `PATCH_BINDING_CONFLICT` | reject and display current binding fingerprint |
| WebGL unavailable | no API failure | render the animated SVG body immediately |
| SSE disconnects | `STREAM_RECONNECTING` | retain last state, back off, then resume with cursor |
| automatic local session unavailable | `LOCAL_SESSION_UNAVAILABLE` | read-only health page and CLI recovery command |

### Phase 2 test gate

```text
REGISTRY
  +-- real-human activation requires observations, consent, custody, and units
  +-- synthetic demo remains labeled through twin, cohort, Patch, and Cendos projection
  +-- encrypted persistence contains no plaintext PHI markers
  +-- idempotency, version conflict, twin isolation, restart recovery

AUTH
  +-- loopback same-origin bootstrap produces HttpOnly/SameSite cookie
  +-- cross-origin and non-loopback bootstrap rejected
  +-- mutations still reject missing/invalid session
  +-- bearer-token SDK/CLI behavior remains compatible

PATCH / STREAM
  +-- root virtual Patch action uses the active pseudonymous twin binding
  +-- virtual sample reaches LIFE, Aegle, reconciliation, and observed evidence tab
  +-- SSE carries monotonic event IDs and reconnects without state mutation

UI / E2E
  +-- approved navigation and layouts present
  +-- create and activate a synthetic demo twin
  +-- create/freeze a reproducible synthetic cohort
  +-- run metformin and visibly change returned mechanistic state
  +-- SVG body remains present and data-driven when WebGL creation fails
  +-- every route and primary control exercised at desktop and mobile widths
  +-- real Playwright interaction recording saved as MP4
```

### Phase 2 review decision

The selected approach is to extend the existing authoritative Aegle runtime with an encrypted
subject registry and bounded projections. A UI-only localStorage implementation is rejected because
it cannot safely bind Patch, Cendos, terminal, and browser behavior. A wholesale service rewrite is
rejected because it would duplicate the validated engine and evidence boundaries. No unresolved
product decisions remain: the user already approved A+B and explicitly restored twin/cohort creation,
real-human onboarding, LIFE Patch pairing, visible live motion, verification, documentation, and a
real interaction recording to scope.
