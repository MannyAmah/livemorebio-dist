# Physical LIFE Patch v3 onboarding: parity and admission plan

Date: 2026-09-08. Status: **PROPOSED — read-only audit completed; no implementation,
device registration, participant creation, telemetry import or hardware command
authorized by this document.** Root and independent pre-code review are required.

Parent requirements: R16, R29–R32 and the privacy/source requirements R26/R47.
This packet contributes to those requirements; it does not close them. The full
insulin and five-candidate programs, Beard numerical-v2 proposal and all existing
numerical gates remain unchanged.

## 1. Outcome and boundary

Make the physical pairing form, attached SDK/terminal, protected binding API and
v3 telemetry consumer refer to the **same registered device manifest**, selected
consented person and original measurement lineage. Preserve exact v2 decoding,
hashes, encrypted journal AAD, saved records and explicitly labelled legacy use.

Pairing is an encrypted association record. A registered manifest is a declaration
accepted by the local trusted provisioning workflow. Neither proves a manufactured
device, running firmware, calibration accuracy, a live radio connection or a
human-use release. This increment must not fabricate those proofs.

The proposed first checkpoint is versioned pairing and its exact apply-time
binding checks. The second is a narrow pre-journal v3-physical consent/association
authorization. Both are needed before claiming this onboarding path is protected
end to end; shipping only the dropdown is not acceptance.

## 2. Source audit: what currently exists

The audit read the complete relevant functions/classes, not operational records or
secret files. This is source inspection, **not a passing new runtime test**.

| Surface | Current implementation | Consequence |
|---|---|---|
| `aegle/console/twins.html`, physical dialog | Protocol input is readonly `2.0`; hardware is `B0-EVT-target`; firmware is free text; calibration defaults to `current`; an attestation-reference string is required. Copy says v3 provisioning uses API/SDK. | UI cannot submit v3. A default/prior selection can become an unsupported calibration declaration. |
| `aegle/console/lib/subjects.js`, `openPhysicalPatch` / `bindPhysicalPatchForm` | Submits device/mode/hardware/protocol/firmware-version/calibration-status/attestation and expected twin version. Opening the dialog clears some fields, not calibration. | No firmware hash, configuration ID or registered-manifest lookup/freeze. |
| `aegle/subjects.py`, `SubjectRegistry.bind_patch` | Accepts `2.0` or `3.0`, but saves the same metadata-only binding for both. Ignores extra firmware/manifest/configuration fields. Physical mode requires REAL_HUMAN, lifecycle ACTIVE, `life_patch` consent, nonempty firmware and attestation, `current` calibration, unique device/person association. | Protocol `3.0` alone does not bind actual v3 lineage. The encrypted record retains no v3 manifest digest or firmware hash. |
| `sdk.py::bind_patch`, `shell.py` twin-patch command | Attached SDK passes a generic payload; shell defaults protocol to `2.0` and has no manifest-digest/calibration-reference fields. | API/SDK existence is not a completed v3 physical workflow. |
| `life_system/service.py`, `/patch/devices` | Parses v2/v3 manifests; physical/external registration requires hardware-present declaration, provisioned firmware version and a valid local device-manifest HMAC. `/patch/devices/{id}` is authenticated. | Real registered metadata is available. The local HMAC is not a manufacturer signature or measured firmware attestation. |
| `life_patch/protocol_v3.py` | Immutable v3 manifest covers firmware version/hash, configuration, hardware, capabilities/provenance/cartridges and safe commands in its hash. Envelope binds manifest/firmware hashes, pseudonymous subject, UTC acquisition window, clock session/monotonic window, uncertainty, QC and measurement context. | Reuse this exact contract; do not create a second form-specific wire format. |
| `life_patch/gateway.py` | Requires a registered manifest, validates packet binding, encrypts physical journal data, enforces durable sequences and session/window order under local cooperating-process locking. Changed manifest for an existing device ID is rejected. | Keep this integrity path and immutable identity policy. No automatic firmware upgrade/reassociation is available. |
| `life_system/service.py`, `_accept_patch` / `/patch/telemetry` | Nonvirtual evidence requires caller-supplied nonempty consent and custody. LIFE journals and publishes before forwarding a signed admission to Aegle. | It does not check current Aegle person/consent/binding before storing a v3 physical packet. Aegle rejection does not undo that journal write. |
| `aegle/server.py`, `/api/patch/telemetry` | Checks signed LIFE admission, active subject/device/mode/protocol, registered v3 manifest against packet, receipt clock and sequence. | It cannot compare firmware/configuration/manifest hashes against the twin's saved metadata-only binding. It does not explicitly recheck current REAL_HUMAN / ACTIVE / `life_patch` scope in this path. |
| `life_patch/protocol.py::PhysicalPatchGateway` | Legacy helper decodes `TelemetryEnvelope.from_dict`, i.e. v2. Shared `decode_envelope` already dispatches v2/v3 elsewhere. | Do not claim the helper supports v3. Use the shared decoder in the new path; retain the legacy helper API until separately reviewed. |
| `life_patch/evidence.py`, `aegle/runtime.py`, `life_patch/observation_view.py` | Normalized observations preserve v3 lineage and stay separate from computed traces; evidence is baseline input, not validation outcome. Runtime's legacy `patch.connected` flag means an envelope was admitted; observation projection explicitly reports `connection_verified:false`. | Expose last admission and source/QC/timing, not a verified live connection or independent validation. |

Additional inspected contracts: `security.py` mutation/read authentication and
local manifest/admission signing; encrypted registry create/activate/bind paths;
existing subject lifecycle and measurement-integration test fixtures; current
source-checked `aegle/life_session_api.py` peer-client pattern.

Prior art: [measurement-integrity plan](2026-09-08-measurement-integrity-atlas-build-plan.md),
[continuous virtual plan](2026-09-08-life-continuous-virtual-execution-subplan.md),
[person source-time correction](2026-09-08-person-intake-source-time-correction.md),
[closed-loop guide](../LIFE_PATCH_CLOSED_LOOP.md),
[measurement guide](../MEASUREMENT_INTEGRITY_REVIEW_GUIDE.md) and
[model-change contract](../BIOLOGICAL_MODEL_CHANGE_CONTRACT.md).
Available-tool discovery found no gbrain/context7/CE tools; local decisions were
searched instead. No numerical model or third-party API behavior is changed here.

## 3. Proposed v3 physical binding contract

### 3.1 Resolve, then bind; never provision from the form

Add an authenticated same-origin Aegle **registered-device inspection** route,
proposed `GET /api/patch/registered-devices/{device_id}`. It queries only the
explicitly configured local LIFE peer, using the existing bounded, no-redirect,
strict-JSON, source/build-checked transport pattern. No browser-supplied URL,
fallback to another running stack, credentials in JSON, global discovery or
automatic registration. Quote/validate the opaque ID before constructing a path.

This route may return only the decoded registered manifest and a bounded inspection
receipt (device/protocol, canonical digest, peer build/process identity and server
inspection time). Inspection time is **not** manufacturing, calibration, sample or
firmware-build time. A current firmware hash is supplied by the manifest, not
computed from the version string. No attestation HMAC/key is returned to the UI.

The binding POST does its own fresh registered-manifest lookup; it must not trust
a browser's previous response, boolean `verified`, arbitrary manifest body or
signature string. Resolve network data before acquiring registry/model-authority
locks; recheck person and expected version under the local transaction before
commit. Never hold an Aegle lock while calling a LIFE endpoint that calls Aegle.

For `mode:physical, protocol_version:3.0`, admit a strict request containing:

- Positive integer `expected_version` (not bool, float or coerced string).
- Canonical bounded `device_id`, exact `mode` and protocol.
- `expected_manifest_hash`, lowercase 64-hex, matching the fresh registered result.
- Explicit `calibration_status:current`, `calibration_reference` and
  `attestation_reference`, both bounded opaque references to the operator's actual
  records. No default values and no invented timestamp or certificate contents.

The new reference field records a **declaration**, not a certificate validator.
Missing evidence cannot be turned into `current` by the software. Unknown, due,
failed or absent declarations block *new physical pairing* under the existing
policy; they do not rewrite previously saved records. A separate certificate
registry with issuer/signature, applicability, uncertainty, date/expiry and
revocation is still required before calibration-validity claims.

From the trusted decoded manifest, save an additive binding schema, e.g.
`livemore.patch-binding.physical.v3`, containing the complete canonical manifest
snapshot, digest, firmware hash/version, configuration ID, hardware revision,
capability/cartridge declarations, local peer identity, original inspection receipt,
operator evidence references and the encrypted person/consent context. The saved
record must recompute and verify its manifest digest on read/use. It must not
include secret signatures/keys or duplicate unencrypted person/device metadata.

The API body cannot override any manifest-derived field. Stored status is
`PAIRING_RECORDED` / `PENDING_SIGNED_ENVELOPE`; add explicit
`calibration_evidence_state:OPERATOR_DECLARED` and
`hardware_validation_state:NOT_ESTABLISHED`. Do not reuse `validated` for either.

### 3.2 Person, concurrency and preservation rules

Before v3 physical binding, require the registry record and authoritative selection
to agree on this exact twin; source class REAL_HUMAN; lifecycle ACTIVE; current
`life_patch` scope and nonempty custody; expected record version; a registered
physical manifest with hardware-present declaration and nonplaceholder firmware.
PUBLIC_REFERENCE, research-prior, synthetic, replay and virtual identities cannot
be promoted through request flags. Existing activation/data-coverage checks stay
unchanged; pairing does not initialize missing physiology or activate a person.

Preserve device-to-person uniqueness and the existing rejection of a changed
registered manifest under the same device ID. No silent reassignment, firmware
replacement or automatic unpairing. Explicit revocation/reassociation/device-key
rotation requires a separate lifecycle design, not a bypass button.

Preserve all v2 saved ciphertext/records and wire/journal golden fixtures. Existing
v2 clients remain explicit legacy clients. Existing metadata-only v3 bindings are
inspectable but are **not upgraded by guessing hashes**: new physical v3 intake
requires an explicitly reviewed rebind to the registered manifest. Existing
virtual-v3 continuous sessions and their separate signed execution receipts are
outside this new physical-binding branch.

Use existing optimistic concurrency. A failed/uncertain POST is not blindly
retried: UI/SDK refreshes the binding and expected version and shows whether the
association exists. No response may claim an atomic distributed transaction.

### 3.3 Protected access and durable audit

New inspection/binding/authorization reads and mutations require operator auth,
`Cache-Control:no-store` and a protected access audit. Add a narrowly scoped
encrypted metadata audit in the governed local store; commit the binding and its
success audit together. Begin protected lookup/access auditing before returning
PHI-like data; audit failure fails closed. Log only fixed error codes and opaque
request IDs, not body values, subject IDs, device IDs, hashes linked to persons,
record references or credentials. Existing legacy audit gaps are not solved by
claiming global compliance.

Before adding a new audit table/path, the implementation packet must identify the
exact owner-only storage guard and AAD/domain separation reused, with red tests for
unsafe files and failed audit writes. Do not invent a new authentication system,
repair broad user-directory permissions, expose keys or silently create a second
operational store. This is still a local single-operator deployment, not production
PHI readiness.

## 4. v3 physical admission, source clock and consumer rules

1. Add a bounded internal association-authorization operation for LIFE before
   admitting a *physical v3* envelope. Aegle verifies current active REAL_HUMAN,
   consent/custody, binding schema/version and exact subject/device/manifest/firmware
   hashes. Return no health profile. Bind the authorization to the exact envelope
   hash, binding revision and consent fingerprint; retain its server time and
   source identity in encrypted LIFE admission evidence, not inside wire bytes.
   Caller-supplied consent strings cannot replace this check.
2. Use an explicit source-checked fixed peer, bounded timeout and no fallback. If
   Aegle is unavailable, do not admit new physical v3 data to the operational
   journal/bus or claim success. Do not make an unbounded plaintext queue. A future
   offline capture/consent policy needs separate approval.
3. This is an authorization at a particular revision/time, not a cross-service
   atomic revocation guarantee. Do not claim zero-delay consent revocation. LIFE
   may retain the authorized receipt even if selection changes after authorization;
   Aegle must recheck the active selection, current consent and exact binding at
   apply time. A changed/revoked context blocks projection/forwarding as applicable
   and is recorded explicitly. Strong revocation, retention/erasure and multi-device
   offline rules remain an open release dependency. The final implementation design
   must freeze a bounded authorization lifetime and retry/idempotency rule before
   code; a stale receipt is not an indefinite bearer permission.
4. At Aegle apply time compare all manifest-derived fields via the frozen canonical
   digest, then use existing `validate_manifest_binding` and exact signed LIFE
   admission. Do not reset gateway sequence/session state after a failed bind.
   A first successfully admitted packet does not mark firmware/calibration validated.
5. Require the existing full v3 envelope: pseudonymous subject; exact manifest and
   firmware hashes; UTC acquisition start/end/captured times; device session and
   monotonic start/end; UTC uncertainty; measurement ID/kind/unit/provenance/QC;
   channel, biofluid/site/compartment/assay/cartridge/calibration/derivation context.
   The manifest's capabilities are authoritative for allowed signals/provenance.
   Waveforms remain waveforms; raw current/impedance cannot become concentration.
6. Preserve existing clock gates: ordered windows, captured time equals acquisition
   end, duration consistency with declared uncertainty, receiver time ordering,
   durable session/sequence/replay checks and existing age limits. Do not replace
   device time with form submission time. Physical-device monotonic clocks are not
   comparable to a server's monotonic origin; keep within-session comparisons.
   The existing uncertainty allowance and generic admission age are engineering
   bounds, not demonstrated sensor-clock accuracy or assay validity.
7. Bind per-measurement calibration/cartridge/derivation identifiers to the original
   envelope; do not copy the form's pairing reference into every measurement.
   Preserve `due`, unknown and degraded QC on admitted records where the existing
   wire policy permits them. Exclude them from any future qualification policy
   unless that policy explicitly admits their context. No silent upgrading/clamping.
8. Keep physical observations separate from continuous numerical
   `execution_observations`, source traces and Cendos predicted endpoints. Receipt
   admission does not recalibrate model parameters, append a treatment or satisfy
   independent validation. Existing baseline-input evidence classification remains.

## 5. UI and attached terminal/SDK parity

- Physical dialog offers explicit `3.0 — registered lineage` and `2.0 — legacy`.
  No old association is silently changed. New v3 path starts with an empty device
  ID and **Inspect registered device** action; no provision/register/command action.
- Show registered protocol, hardware, configuration, firmware version/hash and
  manifest digest readonly, with expandable channel/cartridge details. Copy explains
  that these are registered declarations, not bench verification.
- Calibration starts unselected every opening; references have no defaults. Keep
  entered values during retry of the same inspection, but invalidate resolved
  metadata immediately when device/protocol/person changes. Discard late responses
  using a captured dialog/person/device generation; disable submit while unresolved,
  busy, failed or stale. Native required-field focus must work on desktop/mobile.
- Clear success distinction: **pairing recorded / awaiting admitted packet**;
  **last admitted observation** with original/receipt clocks and QC; **connection
  not verified**. Reuse `observation_channel` display-recency semantics rather than
  promote legacy `patch.connected` to live-device proof. No fictitious heartbeat.
- SDK gains the same registered-device inspection plus attached v3 bind payload;
  shell exposes the equivalent inspect and bind parameters with compact safe
  acknowledgments. No interactive hash signing, credential output or fallback into
  a detached local participant registry. Existing v2 command behavior is retained.
- Do not redesign the whole onboarding form, Atlas, Biology or Cendos in this
  packet. Full-profile import and anatomical mounting remain separate requirements.

## 6. Red-first test and review packet

Before implementation, freeze the final endpoint/authorization/audit schema in a
reviewed amendment. Then prove each relevant current failure in isolated fixtures:

1. Registry: v3 fields currently dropped; false/extra manifest overrides; wrong
   manifest/firmware/configuration; stale version; bool version; inactive/wrong
   source/consent; cross-person reuse; complete encrypted roundtrip and restart;
   stored digest tampering. No real person's records in tests.
2. Preserve exact v2 manifest/envelope/journal/AAD golden bytes and saved registry
   ciphertext before/after inspection. Legacy and virtual-v3 workflows still pass.
3. Lookup: auth absent, non-ASCII credentials, wrong stack/build/process, missing
   configuration, malformed/oversized JSON, redirect, encoded/path-injection ID,
   timeout, absent/unprovisioned/virtual/mutated manifest, audit failure. No arbitrary
   URL, import, registration or key creation.
4. Binding/consumer: signed packet from a valid LIFE manifest differing from the
   saved twin manifest rejects; current consent/selection changes reject at apply;
   unbound/metadata-only-v3 pairing rejects without guessed upgrade; packet/source
   hashes and QC survive exact successful projection. Profile/traces/execution
   observations/validation status remain unchanged.
5. Pre-journal authorization: missing/bad/stale/wrong-envelope/wrong-binding receipt,
   Aegle unavailable, revocation/change between check and application, exact retry
   after uncertain response, concurrent admissions and restart. Verify which
   stores/bus projections remain unchanged on each rejection; never imply rollback
   of an already durably authorized physical receipt.
6. Timing: timezone-free/future/old/cross-session/reordered/overlapping windows;
   UTC/monotonic mismatch and declared uncertainty boundaries; valid device clock
   with unrelated server monotonic origin; waveform timing and raw-unit rejection.
7. Real controller tests: blank calibration; legacy/v3 switch; device/person switch
   during success/failure; same-device retry; late response after dialog close;
   busy/validation feedback and immutable payload capture. SDK and shell requests
   must match web/server contract exactly without exposing sensitive arguments.
8. Actual isolated-browser acceptance after independent code review: inspect empty,
   missing, mismatched, stale and technical registered-device states at desktop and
   390px; keyboard focus; explicit v2 preservation; no overflow or console errors.
   Any API fixture with REAL_HUMAN class is a labelled software test in a private
   ephemeral store, not a participant or clinical evidence. No actual device is
   provisioned or commanded. Raw physical data/keys never enter screenshots/video.

The maker cannot grade these checks. Retain red/green results, exact source build,
test environment, reviewed screenshots, failure receipts and independent review.
Until that evidence exists, tests/browser/physical verification are **pending**.

## 7. Remaining release blockers and lesson

This parity increment does not implement BLE/GATT firmware, secure boot/device
origin signatures, manufacturer key custody, commissioning/rotation/revocation,
calibration certificate validation, hardware safety/RevB0 errata closure, paired
physical vectors, actual deployment/clinical consent administration, robust offline
physical forwarding, anatomical mount calibration or a validated sensor→body
observation transfer function. No human-use, fabrication or therapeutic command
release is authorized. Safe-command software allowlists are not bench safety tests.

R31 still requires independent measurements, qualified observation mappings,
residual analysis, permitted proposals, independent review, immutable model release,
authorized update and rollback. Paired agreement between two software modules is
not physical validation. R16 still requires actual lawful data imports and
reconciliation, not typed source identifiers alone.

Lesson: protocol version parity is insufficient when the saved association drops
the manifest identity. Bind the declared configuration to the person and the exact
admitted packet, distinguish declaration from measurement, and preserve old evidence
instead of manufacturing missing provenance during a migration.
