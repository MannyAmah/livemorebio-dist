# Atlas renderer corrections before browser acceptance

Date: 2026-09-08. Parent: full-scope recovery and approved Atlas lane C.
Status: **Plan independently cleared; correction code awaiting independent review.** Source-native
coordinates, the preserved A+B layout and all broader requirements stay unchanged.

## Independently reproduced defects

1. **Authentic manifest rejected:** the frontend compares membership objects with
   `JSON.stringify`, which treats property insertion order as meaningful. The
   installed canonical manifest orders `asset_key,fma,logic`; the expected literal
   orders `asset_key,logic,fma`. The independent reviewer directly reproduced
   rejection of manifest `8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a`.
   This blocks all real geometry despite passing technical UI tests.
2. **Silent unavailable controls:** missing source leaves Front/Side/Back,
   Select skin, search and section controls enabled while their optional scene
   calls do nothing. Context/graphics loss has the same required unavailable-state
   boundary. Disabled actions must be visibly disabled, not silent placeholders.
3. **Lost acknowledgment distinction:** a malformed successful install response
   is discarded and followed by status refresh. Available geometry then erases
   the uncertainty of that particular installation attempt. Status can establish
   readable geometry, not supply an absent operation receipt.

## Smallest complete correction

- Validate membership as exactly one record with exactly the three required
  keys and exact typed string values, independent of key order. Do not loosen
  component identity, group membership, extra-key rejection, array order, matrix,
  count or hash checks. Preserve the actual canonical serialization in regression
  tests and recheck the retained real manifest without acquisition or conversion.
- Centralize scene-dependent control availability. No reference surface means
  camera, skin selection, layers, search/result selection, sections, opacity and
  labels are disabled. Frame/isolate additionally require the selected partition.
  Keep Retry/source installation and source metadata readable. During partial
  loading, enable only actions whose required source partition is drawn. On
  context/dependency loss disable the affected controls; same-source retry retains
  view settings. Explicitly staged preferences are not introduced in this patch.
- Add a strict install response validator alongside the status contract: valid
  available status/manifest; exact boolean `reused`; exact five-field receipt;
  fixed source; matching manifest digest; 32 lowercase hex receipt ID; bounded
  timezone-aware ISO dates in order. Preserve microsecond ordering rather than
  silently accepting reversed times rounded into one JavaScript millisecond.
  Reject invalid calendar dates. Server receipts are UTC, but equivalent valid
  offsets may be compared without replacing the original strings.
- Keep a separate persistent operation acknowledgment message. Malformed/failed
  or unavailable responses remain **unconfirmed/rejected response** even if a
  later read verifies available geometry. Valid receipt ID and digest identify a
  confirmed operation. Never automatically repeat POST; geometry status and
  operation acknowledgment remain separate. No raw server error text or response
  payload is echoed as an operation explanation.

## Red-first and independent acceptance

Before the fix, reproduce canonical membership rejection, missing/partial/lost
graphics controls and malformed-200 acknowledgment loss. Add preservation cases
for altered membership value/extra key, exact good receipt, wrong source/hash,
boolean aliases, naive/reversed/invalid-calendar/microsecond times, a read-only
refresh after unconfirmed POST and one POST only. Run the prior 81-case UI matrix
and client/API/wheel preservation as relevant. The independent reviewer then
reads changed code and runs the retained real-manifest/real-loader checks.
Only afterward restart the owned review stack for current-source browser evidence.

The renderer maker is now on a separate read-only source-research task. Root owns
these three bounded UI corrections; shared backend/cache/source files stay frozen.
No old geometry or records are deleted and no source is reinstalled by this work.

Lesson: fixtures must include the serialization actually emitted by the producer.
Typed object meaning does not depend on key insertion order. A ready data read
also cannot serve as an acknowledgment for a different mutation request.

## Root implementation evidence

The independent reviewer cleared this amendment before code and explicitly
included the external whole-body Home/Labels controls. The red packet first
reproduced 19 failures, then 21 failures after partial-layer and retained valid
receipt cases were added (2.06 seconds). No failing expectation was removed.

The three bounded corrections now pass all 21 new regressions and the prior 27
Atlas tests (48 passed in 5.58 seconds). A wider preserved UI/subject/stream packet
passes 104 tests in 15.90 seconds with three existing framework deprecations.
This is maker verification, not independent browser acceptance.

An additional network-free process used the unmodified retained canonical
manifest `8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a`,
checked its byte digest and each of the nine GLB byte digests, then ran the actual
pinned GLTFLoader and source-binding validator. All 489 source elements bound
successfully without key reordering, source reinstall or conversion. That check
does not exercise WebGL or establish physiological/spatial equivalence.

The UI now separates persisted operation acknowledgment from current geometry
status, rejects malformed exact receipts including reversed microseconds, and
disables unavailable source-dependent controls and both header aliases. A valid
retained geometry read after a failed status request may remain inspectable as
reference only; context loss disables controls until explicit graphics recovery.
Independent code/producer-consumer review and current-build rendered acceptance
remain outstanding. Backend/cache/source files were not changed by these fixes.
