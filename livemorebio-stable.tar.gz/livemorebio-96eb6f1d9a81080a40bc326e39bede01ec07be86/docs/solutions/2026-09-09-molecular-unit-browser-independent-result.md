# Independent molecular browser evidence audit: kCPxWp

2026-09-09. **Overall FAILED; default-consumer release remains blocked by
transport.** All four interaction stages and 11 required captures passed, but
the original first-coordinate request retained ERR_ABORTED. No failed receipt
is relabeled, no canceled request is waived, and no new run or code change was
performed by this review.

## Scope, originals and independent method

Consumed original root:
`/private/tmp/livemore-molecular-unit-browser.kCPxWp/run`.
Root's actual invocation terminated exit 1, completion `c1fdac`; supervisor
elapsed 46.675947084033396 s, browser interval 46265.825583 ms.

| Original | Bytes | SHA256 |
|---|---:|---|
| browser-result.json | 173952 | `7896893ea9252b15ff92619d8ae22e799db58dabd711c168339bef3e53823358` |
| supervision.json | 187770 | `ca11f09cd56c3ea11f5ee454d8d26ec3fb251b526dd5cc7eb0ff2c5e6097db03` |
| stdout | 48 | `5f461d6fdb43dada20b5e11b4960c69b269159fbea0a245c848a5b36a1e9cddd` |
| stderr | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |

release_redteam read the original JSON with stdlib only, compared the complete
embedded browser object to the standalone original, and independently checked
all original PNG bytes plus IHDR dimensions. Repeated provenance objects were
compared in full to the original catalog, not accepted from display labels.
Duplicate JSON keys and nonfinite JSON constants were refused. No supervisor,
browser, loader, numerical module or OS inspector was invoked.

The complete independent read-only check passed `f85f38`, exit 0. Earlier
check `135a62` reached all image/pin/source/chronology assertions, then stopped
at an overbroad whole-stat comparison on stdout. Follow-up `c8dc5e` verified
the exact stream identity fields and bytes; the final repeat uses stable
device/inode/mode/link/size/mtime/ctime, not read-sensitive access time. The
initial diagnostic assertion is retained in tool output, not called a product
failure or silently erased. No consumed file was edited.

All 22 input rows and eight harness rows still match exact metadata and hashes.
Current checks preserve the controller, CSS, loader, bundle, public coordinates,
catalog and helper/runtime inputs. The supervisor also records 22/22 input and
8/8 harness preservation before/after the actual run. Its embedded receipt
equals the full original, with image_hashes_match true.

## Exact capture evidence

All 11 planned PNGs exist, total 1,606,022 bytes. Desktop IHDR is 1440×1000;
both mobile images are 390×844. I verified bytes/hashes/dimensions, not rendered
appearance. Root owns the separate inspection of all 11 original images.

| Capture | Bytes | SHA256 |
|---|---:|---|
| desktop-4obe | 172272 | `3921930ebc6180a55b52354ce344c1c95b6f9746eb3564f207217a4f66be6b8d` |
| desktop-help | 151191 | `5353729778d3f680513778667c1e01e0bf9ccacbd6dcf7f6ef77d217355666ee` |
| desktop-distance | 177914 | `052d9de115fd816f8fa478616ff68bb9132a5ea9ddbfd875564d0f7e50132326` |
| desktop-1tup | 186122 | `78b0a586d45f1862a940e10f6938842cd50fa08b18c6f22ee5264ca146287344` |
| desktop-1m17 | 171628 | `568641441621c7bfe7d85d8b43af6bd638e2de49e56625aa16cd501b236dab2a` |
| desktop-1n7d | 179194 | `3432b64bcd0316a07b40324d4586e3854a7f9e8821b3929af6fe96ab8f6cf206` |
| desktop-6p2b | 205118 | `d893981f12c796699e86f8d8c7cc3928bc91a88ab7908347c348efa9c5d755ae` |
| desktop-4ins-pig | 133822 | `4a9518d277c1c33d43030295b96a1b46f5161abf7e9260343880f1ac9316cba6` |
| desktop-ins-unavailable | 51529 | `7c8b615cae8220ab695021d6439ec254c7ddc850c386fa29277db32e3280556b` |
| mobile-4obe | 79952 | `ffb6b1ee46b9b39be6378c863ea8cba49d41ba05ef143b7f16cf62eefa60cada` |
| mobile-provenance | 97280 | `03877bf3c1a1c3b9b1b8bf743085c9c383bce1e3b4e9129932c8146a36ff8275` |

## What the original interaction ledger establishes

D0, D1, D2 and M0 are PASS. Eight source opens are exactly KRAS, TP53, EGFR,
LDLR, PXR, PDB_4INS, INS, KRAS. All eight complete metadata objects and the
later mobile provenance object equal the expected original catalog projections.
The six admitted deposited structures remain reference-only. Human INS remains
MAPPING_UNAVAILABLE/HUMAN_STRUCTURE_NOT_ADMITTED, null reference, no canvas and
zero coordinate requests; the separate 4INS entry remains explicitly pig insulin.

Every ready source initially has one canvas, unobscured status/scope centers and
no horizontal overflow. Desktop canvas is 989×478; mobile is 350×240. The later
mobile provenance scroll naturally places the canvas/status above the viewport;
its false text-clear flags are retained and are not an initial-layout assertion.
These measurements do not prove every offscreen control was individually used.

The real selection history has two entries with distinct wrapper indices 1/2
and original zero-width-delimited M/T labels. The displayed source-geometry
measurement is exactly `5.82 Å | THR 3 — MET 2`; creation and deletion checks
passed. No independent recalculation or biological distance claim is made.
Help, rotate/zoom inputs and reset control passed their existing checks; camera
evidence remains INPUT_AND_VISIBLE_CONTROL_ONLY. Eight close cycles confirm
plugin absence/focus restoration, including mobile Escape and in-dialog Tab.

## Transport timing: bounded conclusion only

29 admitted GETs served 10,296,699 bytes. There are exactly 29 terminal rows,
with matching URL multiplicities, 28 finished and one failed. Page errors,
console errors and CSP violations are zero. The failed row is the first D0
4OBE coordinate URL ending in its exact `bc573872…/coordinates` digest path.

All times below use the same Node-monotonic origin; they are observation times,
not independently synchronized network-stack or wire timestamps.

| Event | Offset ms |
|---|---:|
| D0 begins | 1571.699792 |
| first KRAS metadata request finished | 3747.702459 |
| first KRAS coordinates ERR_ABORTED | 3755.837334 |
| first structure.js request finished | 3829.661209 |
| D1 begins | 11555.940167 |
| first explicit page retirement, D2 | 41949.869709 |
| final cleanup begins | 45948.171542 |

The failure is recorded before D1 selection/measurement/inspector close and
before every explicit page/context/browser retirement. Those later checker
actions cannot explain this earlier recorded terminal. The second mobile
request to the same coordinate URL finished at 42413.685167 ms, but is a
different request; it does not repair the first one or prove a cause.

The frozen product still reached exact-byte/hash/source/parser checks and READY
for D0. The loader source consumes through EOF and does not cancel an EOF
reader (`molecular_loader.js:126–139`), but the original receipt does not record
its read/EOF/abort call timing or the browser network-stack failure details.
Application success and the failed browser terminal are distinct observations.
This trace cannot attribute cause to reader cancellation, teardown, server close,
Playwright, Chrome, SwiftShader, a protocol defect, or permissions. No code change
or new probe is justified by a guessed attribution. Earlier failed attempts are
also not explained retrospectively.

## Cleanup and disposition

Six owned closes are SETTLED: desktop page/context, mobile page/context,
browser and server. Node PID 40215 is reaped; all 16 recorded descendant
identities have empty retained remainder. Both before/after listener inspections
are NO_LISTENERS with settled query cleanup. This review checked the exact
17-identity ledger and retained terminal evidence; it did not perform a new OS
process check. Root's separate exact check `ae101f` returned exit 1/no rows for
40215, 40218, 40220, 40222, 40239, 40241, 40242, 40245, 40246, 40247, 40344,
40354, 40407, 40424, 40500, 40502 and 40503. This is attributed to root's direct
observation, not a new independent probe or historical process reconstruction.

The original stdout accurately reports FAILED with a null scalar failure field:
the actual admission failure lives in the retained network_failures array, not
an invented new exception. The overall failure is correct under the unchanged
acceptance contract. No additional product defect was established by this
evidence audit, and no acceptance requirement is waived.

Retain this as functional interaction/capture evidence with an open transport
failure. Default-consumer release remains blocked, no further browser/source
action is authorized here, and the six scientific programs/R01–R51 are not
completed by static public-reference graphics.
