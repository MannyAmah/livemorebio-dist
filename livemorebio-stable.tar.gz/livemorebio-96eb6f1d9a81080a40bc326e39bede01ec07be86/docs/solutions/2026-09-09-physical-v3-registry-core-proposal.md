# Physical-v3 registered binding: smallest next backend increment

Status: **pre-code proposal; no implementation or test execution authorized by this document.**
This is a bounded continuation of the approved physical-v3 onboarding plan and
authorization amendment, not completion of either. All R01–R51 obligations and
the six scientific programs remain required. Authored software evidence is not
hardware, calibration, consent-document verification, or biological validation.

## Source-backed decision

Implement the **registered-manifest binding core in the actual encrypted subject
registry**, with a reusable, explicitly non-authorizing binding predicate. Reuse
the existing prepared `bind` transaction, physical access audit, raw read-set
confirmation and uncertain-commit witness. Do not add a fifth transition kind,
new transaction framework, HTTP route, physical receipt store, or UI in this slice.

Read for this assessment: the complete physical onboarding plan, 416-line
authorization amendment, biological change contract, registry audit module and
observation holder; relevant complete prepared-binding/validation/commit, manifest
binding, LIFE admission, Aegle telemetry, storage/key and peer-client functions.
Existing real-registry binding integration and v2 physical lifecycle fixtures
provide the test pattern. No operational store was opened.

Current evidence:

| Actual seam | Consequence |
| --- | --- |
| `aegle/subjects.py:253` `_normalize_transition_binding` accepts only the existing scalar metadata fields. `:1299`–`:1309` prepares the existing `bind`; `:1527` commits with encrypted audit and exact SQL/audit witnesses. | The old plan's “drops unknown fields” diagnosis is stale: current input rejects them. Extend a **separate internal preparation seam**, not the public allowlist. |
| `subjects.py:285` `_transition_changes` already requires selected ACTIVE REAL_HUMAN, admission evidence, `life_patch`, attestation/current calibration and unique device ownership for physical pairing. | Reuse these checks and index policy. Add registered lineage; do not replace them with a manifest-only check. |
| `life_patch/protocol_v3.py:156` and `:407` validate/canonicalize the exact manifest and its envelope relationship. | Reuse their hash, firmware, capability, cartridge and unit semantics; no alternative digest or signal normalizer. |
| `life_system/service.py:180` journals before `:184`–`:200` publishes and before forwarding. Aegle `server.py:1345` validates supplied manifest plus generic admission, not a saved full binding and fresh consent authorization. | The full authorization/journal gap is still open. This registry slice does not make current physical-v3 telemetry safe or accepted. |
| LIFE gateway has no persistent gateway UUID. Neither required physical receipt-store role exists. Existing execution/virtual-session stores have different schemas, roles, AAD and reservation accounting. | Do not invent inspection identities or call a virtual-session store equivalent. Fixed-peer inspection and new physical persistence remain required before onboarding can be enabled. |

## Exact proposed implementation boundary

Runtime write set: `livemorebio/aegle/subjects.py` plus one small new pure module
`livemorebio/life_patch/physical_binding.py`. Tests: one new
`livemorebio/tests/test_registered_physical_v3_binding.py`. The report/approved
plan may be appended. No server, gateway, service, security/key-loader, protocol,
observation, execution-store, clinical-parameter or UI changes in this slice.

Proposed internal API:

```python
SubjectRegistry.prepare_registered_physical_v3_binding(
    twin_id, body, *, inspection, expected_version, request_id,
) -> PreparedRegistryTransition
```

`body` has exactly the physical-v3 fields already frozen by the parent plan:
`device_id`, `mode`, `protocol_version`, `expected_manifest_hash`,
`calibration_status`, `calibration_reference`, `attestation_reference`, and
`expected_version`. Exact positive safely incrementable int, not bool/coercion;
exact physical/3.0; current calibration declaration; bounded nonempty references.
Caller-supplied manifest, firmware override, hardware override, verified flag,
peer URL, consent proof or identity override is rejected before registry access.

`inspection` has exactly the approved
`livemore.physical-manifest-inspection.v1` envelope. Decode using `ManifestV3`,
require physical/provisioned/hardware-present, match device and expected digest,
and retain the complete canonical manifest. Require canonical process/store/request
UUIDs, distinct LIFE receipt-store and gateway-store IDs, source SHA-256 and
timezone-aware inspection timestamp. Apply the parent's existing strict bounds;
do not substitute a fresh local timestamp, random peer/store identity or default
manifest when a field is missing. The peer response is detached before preparation.

**Structural inspection validity is not proof of network origin.** This is an
internal Python preparation input, not a public authorization token. The later
route must obtain it itself from the authenticated, fixed, source/process-checked
LIFE peer outside all commit locks, with its real store identities. No public body
or persisted inspection from an earlier operation may supply that authority.

Keep `kind == "bind"`. Add one exact, discriminated private normalized binding
representation containing the normalized request and detached inspection in
`PreparedRegistryTransition._binding_json`. A small internal decoder extracts the
common device/mode fields for existing read-set/index logic. At commit,
`_validate_transition` must independently normalize that representation and
reconstruct the entire expected updated record; never accept a prepared after-row
or inspection hash on trust. Do not allow these private fields through the old
`prepare_patch_binding` input parser.

The stored entry uses the approved `livemore.patch-binding.physical.v3` schema:
full canonical manifest/digest, firmware hash/version, hardware/configuration and
capabilities from that manifest, peer inspection identity, declaration references,
and the existing admitted person/consent context. No invented `VERIFIED` state.
Preserve the original record schema/AAD, creation metadata, existing unrelated
bindings, device uniqueness index, and safely increment only the target revision.
Successful mutation audit remains in the **same registry transaction**.

The old public/direct binding preparation must refuse **new physical 3.0** pairing
without this internal inspection input. It must not silently downgrade to 2.0.
Existing v2 behavior and virtual-v3 preparation are unchanged. Old metadata-only
physical-v3 rows remain readable byte-for-byte; no background migration/backfill.
The current UI already says registered-lineage physical-v3 onboarding is unavailable.

The pure module also supplies one private predicate, provisionally
`require_registered_physical_v3_binding(record, *, device_id, subject_id,
manifest_hash, firmware_hash, custody_reference)`. It validates eligible REAL_HUMAN
ACTIVE record, current `life_patch` scope/custody, exactly one matching schema entry,
canonical saved manifest/hash, and exact subject/device/manifest/firmware identity.
It returns a detached binding or a fixed bounded rejection, and performs no I/O.
**It does not prove current selection, device-index consistency, freshness, or grant
authorization.** Future issuer/apply code must invoke it only on a fresh checked
registry snapshot with the device-index read-set, under source authority and the
approved final confirmation. It cannot replace those checks or create an HMAC.

## First RED packet: 28 authored cases

Use real `SubjectRegistry`, encryption, `_connect`, prepared reconstruction,
physical audit and commit/witness. Reuse only seed/raw-row/audit helpers from the
existing committed-registry and checked-binding fixtures, not their ASGI fixture.
Use private authored records and manifest IDs; trap model/device constructors,
compilers, network, subprocess and native loading. No arbitrary real-world IDs.

| Cases | Exact obligation |
| --- | --- |
| 1 | Eligible observation-only human: prepare and commit exact manifest entry; reopen actual encrypted registry; exact revision/index/audit and no model construction. |
| 2–9 | Wrong inspection device, protocol, mode, expected digest, changed firmware/capability without matching digest, hardware absent/unprovisioned, malformed UUID, aliased LIFE/gateway role IDs each refuse before clinical mutation. |
| 10–12 | Extra public/private fields, bool revision, and metadata-only physical-3.0 public preparation reject before protected storage access. |
| 13–17 | Nonhuman, unselected/inactive target, missing `life_patch`, changed/empty custody, and another person's existing physical-device index refuse with original records/index retained. |
| 18 | Mutating input inspection/request and detached result cannot alter prepared bytes or committed identity. |
| 19 | Forged prepared normalized inspection/after-row fails independent reconstruction before mutation. |
| 20 | Raw selected-record/pointer change after preparation causes exact conflict; preserve the changed external state. |
| 21 | Physical mutation audit failure yields no successful binding; retain auditable failure/pending evidence per existing contract. |
| 22 | Delegated real connection known rollback preserves clinical rows/index; no false success. |
| 23 | Actual commit then lost ACK is accepted only by the existing complete clinical/index/audit witness. |
| 24 | Lost ACK plus damaged/unknown witness remains unconfirmed; do not repair its retained bytes. |
| 25 | Confirmed commit plus close failure yields the existing committed-cleanup-unconfirmed outcome. |
| 26 | Saved full binding with tampered manifest/hash or subsequently revoked scope fails the reusable predicate; caller-supplied matching hash cannot rehabilitate it. |
| 27 | Existing physical-v2 bind and wire/record/AAD behavior preserved. |
| 28 | Virtual-v3 preparation preserved; old metadata-only physical-v3 remains readable but fails the new predicate, with original ciphertext unchanged. |

Rows containing closely related alternatives should assert both without creating
an expansive parameterized cross-product. Freeze the actual collected inventory
and original RED receipt before implementation. No weakening existing fixtures:
if a legacy *new* physical-3.0 positive test requires migration, identify its exact
case and obtain root approval first. Preserve its original failure evidence.

After green, repeat the bounded existing registry foundation plus the existing
13-case real binding integration and v2 protocol goldens under their respective
approved isolation wrappers. Do not accidentally include lifecycle tests that
construct numerical models or claim all protocol/service tests are inert.

## Remaining dependencies and stopping conditions

```text
this core: encrypted exact-manifest binding + reusable record predicate
    → real physical store/gateway identities and fixed-peer inspection
    → actual binding route uses its own fresh inspection + committed publication
    → issuer audit + 30-second consent authorization + named reservations
    → authorization checked at locked journal append; immutable retry metadata
    → durable Aegle receipt + fresh source/consent check + exact ACK
    → LIFE subject/device publication only after current ACK
```

These are still original required work, not substitutes or optional follow-ups.
The existing key helpers can chmod/fallback; the current execution store can create
schema before role validation; the peer client has a 16-KiB request limit. None can
be reused unchanged and advertised as satisfying the physical amendment. The later
store/transport increment needs its own exact proposal, not opportunistic edits here.

At this checkpoint, public physical-v3 onboarding remains unavailable; no physical
packet, journal append, consent signature, observation projection, device command
or hardware claim is newly enabled. Pure predicate success must never be labeled
authorization. No code/test process was run during this assessment.

Engineering lesson: reuse the now-strengthened prepared registry transaction, but
do not collapse structural manifest validity, peer identity, durable consent
authorization and apply-time authority into one “paired” flag.

## Root implementation gate

Root read all 169 proposal lines and approved the exact two runtime files and one
new 28-case test file, red-first. Browser runtime freeze was explicitly released;
the failed native keyboard selection in that separate browser attempt is not a
backend result. No public route, receipt store, gateway or publication edits are
authorized. OSP supervisor remains frozen. Root independently grades this maker
packet after its original RED, green and bounded preservation receipts are retained.
