# Stock molecular lock resolution: actual receipt and failed admission

2026-09-08 local /2026-09-09 UTC. **One approved invocation completed; the lock
is NOT admitted for installation/build. No retry occurred.**
Scope is the root-approved final section of the
[stock resolution amendment](2026-09-08-molecular-stock-lock-resolution-amendment.md).
The rejected custom interception framework was not implemented.

## Actual operation and cleanup

Private input root: `/tmp/livemore-molecular-build-plan.4ej8oR`, mode0700.
Its physical directory is `/private/tmp/livemore-molecular-build-plan.4ej8oR`.
All seven input hashes plus Node/npm/config and retained Molstar archive hashes
matched before launch; the seven inputs were rehashed unchanged afterwards.

The standard stdlib `resolve-once.py` launched the exact approved stock npm argv
once, under the written explicit environment, with115seconds work/120seconds total.
No resolver preload/network shim or scientific package was executed.

- Parent exec session11092 completed exit0; owned npm PID99697.
- npm exit0; elapsed31.098866582964547seconds; no timeout.
- Leader reaped; read-only process-group existence check returned absent.
- No `node_modules` materialized. No lifecycle script, install/build/vendor step,
  browser/service, coordinate request or product edit was invoked.
- stdout19bytes (`up to date in 30s`); stderr0bytes. npm's private debug log is
  retained separately. No operational credentials were passed.
- Private receipt directory mode0700 and result file mode0600 confirmed.
- npm cache846 regular files,101,823,150 actual bytes. No symlink found by the
  complete cache inventory. This is observed storage, not a claimed enforced cap.

Raw result status is `RESOLVED`, accurately reporting npm's exit; the separate
inspection status is `BLOCKED_COUNT_AND_LOCK_TOPOLOGY`. Neither is rewritten to
conceal the difference. A complete npm resolution is not installation admission.

## Complete lock inspection

Lockfile236,991bytes, version3, SHA256
`137389a21bee2716e563e36b5ecdd8df1e1fdb2c311e22515191a39d26b15321`.
The full JSON was parsed with duplicate-key rejection; all428 dependency records
were retained in `package-inventory.json` with sources, integrity, licenses,
dependencies/peers/optional declarations, engine fields and path comparisons.
The original lock remains intact for independent inspection.

| Check | Actual result |
|---|---|
| Root package record | name/version and all nine direct pins exactly match the frozen manifest |
| Top-level version | **unexpected** `file:../../private/tmp/livemore-molecular-build-plan.4ej8oR`, not `0.0.0` |
| Dependency locations | **all428** begin `../../private/tmp/livemore-molecular-build-plan.4ej8oR/node_modules/`, not ordinary root-relative node_modules keys |
| Selected records |428 entries,427 distinct name/version pairs, exceeding the proposed384 review budget |
| Resolved sources |427 official HTTPS registry artifact URLs; one exact retained local Molstar archive |
| Integrity | every row has syntactically valid SRI; Molstar's exact SHA512 matches its already verified archive |
| Other source specs | no Git, external URL, other file, link/workspace or npm-alias dependency spec found in dependencies/peers/optional fields; no linked dependency row |
| License labels | all rows populated; these are metadata labels, not complete notice/body review |
| Bundle/shrinkwrap flags | none present in selected rows |
| Script flags | @scarf/scarf1.4.0; optional fsevents2.3.3; neither was authorized to execute |

427 is **not an inflated count of unselected optional metadata**. Among428 locked
records, only fsevents2.3.3 is marked optional (Darwin);148 are marked dev and3
peer. These classifications overlap. There are426 distinct nonoptional selected
name/version pairs and one optional pair. They are selected dependency records
for the tooling manifest, not installed files or evidence of emitted browser code.
Molstar's optional peers canvas/gl/jpeg-js/pngjs were fetched as metadata according
to npm's log but are **absent from the resulting lock**. Those unselected peer
queries were not counted in427.

The private manifest uses the full official Molstar package, whose dependencies
include server/CLI tools as well as client modules. This explains why a small UI
entry does not produce a comparably small npm lock. h264-mp4-encoder1.0.12 is a
selected private dependency, with an MIT package label; the previously identified
embedded-codec/license obligations still forbid treating that as MIT-only output
admission. Its bytes must remain absent from the eventual structure-only bundle.

Other license labels: MIT389, ISC15, BSD-2-Clause8, BSD-3-Clause7, Apache-2.0 6,
0BSD1, CC-BY-4.0 1 (caniuse-lite1.0.30001810), Python-2.0 1 (argparse2.0.1).
The script dependency path is swagger-ui-dist5.32.15→@scarf/scarf1.4.0; optional
fsevents2.3.3 comes through chokidar3.6.0. Future installation must retain scripts
disabled and review any native/tooling requirement separately; lock metadata is
not permission to enable telemetry or native compilation.

The complete log contains452 `http fetch GET` events, all reported HTTP200 at
registry.npmjs.org. None of those logged event URLs is a tarball. Local Molstar
extraction/cache activity was permitted. The log does not prove absence of every
intermediate redirect or archive access. No such network-closure claim is made;
the operation used the explicitly relaxed stock-npm boundary, not an intercept.

## Canonical-path cause from existing source, no second resolution

The configured prefix was `/tmp/livemore-molecular-build-plan.4ej8oR`; npm's own
log records cwd `/private/tmp/livemore-molecular-build-plan.4ej8oR`.
The existing OS symlink is `/tmp -> private/tmp`.

Installed Arborist `build-ideal-tree.js::#rootNodeFromPackage` lines374–406 calls
realpath(this.path), then selects **Link when real !== this.path**, with a target
Node at the physical path. `shrinkwrap.js::commit` uses the target's package for
the `packages[""]` record but computes dependency locations with
`relpath(this.path,node.path)`. Its legacy top-level writer explicitly sets a
Link node's version to `file:${relpath(this.path,node.realpath)}`. `relpath.js`
uses Node path.relative without filesystem canonicalization. These exact source
branches explain both observed artifacts while preserving the correct root
package record; no fabricated dependency or coordinate was involved.

For the first actual key, lexical resolution from the configured /tmp prefix
lands at `/private/tmp/.../node_modules/@discoveryjs/json-ext`; from the physical
cwd it instead lands at `/private/private/tmp/.../node_modules/@discoveryjs/json-ext`.
Do not hand-rewrite the lock or install it hoping the ambiguous base is repaired.
This is a private build-tool path-admission defect, not a molecular or clinical
model failure. Source evidence establishes the mechanism; a corrected result
has not been produced or accepted.

## Proposed next finite step (not authorized/executed here)

Use a fresh **canonical `/private/tmp/...`** private root consistently for cwd,
prefix, temp/cache/log paths and the retained archive reference. Preserve this
entire attempt, lock and cache unchanged. After root approval, a copy of the
retained cache can support one stock **offline** canonical lock-only resolution;
no need to spend another online acquisition to diagnose this path effect.
Retain the same package versions/manifest semantics and all script restrictions.
If offline metadata is insufficient, stop and report it rather than go online.
Require top-level0.0.0, normal node_modules keys and a source/integrity comparison
against this retained selected inventory before any installation.

For the review budget, recommend explicitly admitting review of this **measured
427-version tooling closure**, rather than treating the earlier384 estimate as
a scientific gate or substituting a custom resolver. The next expected ceiling
can be427 unique pairs, with every new/changed pair explained against the retained
inventory. Build output size/codec/rights checks remain unchanged. Root must make
that budget decision and review the corrected lock; no automatic increase,
dependency filtering, code execution or installation follows this report.

## Retained evidence hashes

All paths below are inside the private root; outputs are data, not installed code.

| File | SHA256 |
|---|---|
| resolve-once.py | `18837c499fb04fcc767487cb2a3fbc138f640478a1117819b37e6af9efadf825` |
| resolution-receipt/result.json | `800590038159cd37e7316efa4adf0af72a460750d6ba2c20410e6d07b8918393` |
| logs/2026-09-09T03_42_23_019Z-debug-0.log | `12760e659a8cd0c3d35078c5616165af3c7d8153bfc55336b85e02c10a857cab` |
| inspect-lock.py | `0a645e07ae248a814b867e1f5542ae1a0cece529943d022e55aab0ed3afd9456` |
| resolution-receipt/inspection.json | `16cb3bd9a82c357b9026dccd8a225398fdc1c5674dc8a664507762735b2f3465` |
| resolution-receipt/package-inventory.json | `75736b67bab004d90df3b4f1d3bc74668667faa5a481c9953badaa82d084fb5d` |
| resolution-receipt/cache-inventory.json | `2c2f578c8d3eed459e6a0e50fb2d794700e2fe8f2b5bb13719a6e0cdecad7da2` |
| resolution-receipt/logged-fetch-events.json | `6e28ecdb3ea69ac7767f85ad5d60197d655795cbec206e09961a87ea36ee4161` |
| installed npm Arborist shrinkwrap.js | `418c671d6f50737d2ff9f0dd5ecdc0a65de4b473af4f5d25b931489d3bab6376` |
| installed npm Arborist relpath.js | `905b4f9ffb96ebd085045b11e1cc36b083ffa3f3b5ecbe7735792931ccfd9e4d` |

No process remains from this invocation. Independent root review is still
required; there is no molecular rendering, wheel, scientific or release claim.
Lesson: canonicalize the private build root before invoking an established lock
resolver, and distinguish resolved dependency records from runtime bundle scope.

## Root review and corrected private resolution decision

Root read this complete report, the actual package manifest and one-run launcher,
and the installed Arborist root-node branch. The canonical-path explanation is
consistent with those bytes. Preserve the first lock and cache unchanged; they
are not an install input. The original384 estimate was a tooling-review budget,
not a scientific or security assertion about package count. Root approves review
of the measured427 unique versions, with no unexplained version/source/integrity
change relative to the complete retained inventory.

Authorize one corrected **offline, lock-only** stock npm invocation in a fresh
0700 canonical `/private/tmp/` root. Copy the retained cache into that new root;
do not operate on or rewrite the original cache. Use canonical paths for cwd,
prefix, cache, logs, temp and the exact retained Molstar archive, with the same
version pins, script/Git restrictions and115s/120s bounds. Preserve the original
manifest; the corrected manifest may change only its archive path spelling to
the same canonical file and descriptive status text. No network fallback,
manual lock rewrite, install, build or native execution is authorized by this
decision. First check the exact package-pair/source/SRI comparison, normal root
paths and top-level version; freeze the resulting packet for independent review.

## Corrected canonical offline invocation — actual separate receipt

The approved single corrected invocation completed on2026-09-09UTC. The first
attempt, its failed admission and all original files remain unchanged.
New root: `/private/tmp/livemore-molecular-canonical.9plldc`, mode0700, verified
equal to its filesystem-resolved path before launch. All846 copied cache files
matched the original retained byte counts and SHA256 hashes. The new manifest
changes only the permitted description and canonical spelling of the same
already admitted local Molstar archive; its SHA256 is
`c4cac1572b0b072aa0874971828429f504b539aaa562298beb5abab58a3aae87`.
The other six prepared inputs are byte-identical to the original pins; all seven
were rehashed after completion and match the new launcher pins.

The exact argv/environment are retained in `resolution-receipt/result.json`.
It is the previous stock npm command plus `--offline`, with every private path
canonicalized to the new root. Node26.0.0/npm11.12.1, the same explicit four-field
environment, script/Git restrictions,115s work and120s overall bounds were used.
No custom resolver, network interception, dependency code or lifecycle script
was introduced. This is the second separately authorized stock invocation,
not a silent retry of the first failed-admission result.

- Exec session95691 completed exit0; owned npm PID1876.
- Actual elapsed4.661525541974697seconds; no timeout or offline-cache failure.
- npm exit0; leader reaped and read-only process-group check absent.
- No `node_modules`; stdout18bytes, stderr0bytes. Receipt and lock mode0600.
- Entire original file inventory before/after matches, including content hashes,
  sizes, modification timestamps and modes. The original cache was not operated
  on; only its copy was supplied to npm.
- No online fallback, further acquisition, install/build, coordinate request,
  product edit, browser, service or scientific/native workload occurred.

### Complete comparison, not a count-only check

The resulting lock is213,405bytes, version3, SHA256
`6b4a6d69d5c8c16cb68b1510b2bb121a309f6c4fad49d2e1377e6ace6173804e`.
Top-level and root-record version are now exactly `0.0.0`; all428 dependency
placement keys are ordinary root-relative `node_modules/…` keys. Root name and
all nine direct pins exactly match the corrected manifest.

The data-only comparison parses both complete locks with duplicate-key rejection.
It strips only the known erroneous original placement prefix and resolves only
the local Molstar file reference to the exact retained canonical archive path;
registry URLs are compared without rewriting. After that normalization:

- **All427 unique name/version/source/SRI identities match exactly**, with zero
  added or removed identities.
- **All428 placement metadata records match exactly**, not only their versions:
  zero changed keys or metadata fields, including dependencies, optional/peer
  declarations, script flags, licenses and engines.
- Every source remains the official registry or the exact retained Molstar file;
  every SRI is well-formed. The prior license/codec/native/script obligations
  remain unchanged. fsevents is still the only optional selected record.

The complete debug log has454 HTTP-fetch log events, all registry HTTP200 and
all explicitly marked `(cache stale)`. npm's separate `packumentCache ...
cache-miss` lines concern its in-memory cache, not an offline store miss. The
observed stale-cache event categories and successful `--offline` operation are
retained as stock-tool evidence; no packet-trace or custom egress-enforcement
claim is made. This run made no online fallback invocation.

### Corrected packet hashes and finite handoff

Paths below are relative to the new private root. These frozen records supplement
the first attempt; they do not replace its lock, receipts or admission outcome.

| File | SHA256 |
|---|---|
| resolve-once.py | `b9ed2b8de4fdb29f517a53bacb07a5162aa2418f2620dcaf938f69dc2a1c1728` |
| compare-locks.py | `8a8bff3ef2616e16fe1a5734c7cf07cae4a030a23f70625c32d67c58b26fd2ae` |
| resolution-receipt/result.json | `97b3e7ffa2d057dcc159a4feaac3c3b19984efad11a2ef0f71b01d36177321c2` |
| resolution-receipt/canonical-comparison.json | `220cdf8ddb3cb9ed841ef79d1eec3b0e489660fd9233918793b1f798a8b6cd41` |
| resolution-receipt/canonical-identities.json | `6bd6ee4c39c4e8f26b2427c521624f6083898f281d4af54f22914f94f92893aa` |
| resolution-receipt/canonical-package-inventory.json | `992849ad6e71302ac4280efe78eb6366797f755be346c4d3c66ce577aaca9fa1` |
| resolution-receipt/canonical-fetch-events.json | `7ef4a873008d6b51d21955fb94342623c03c95c143150123f4bb084a444881c1` |
| resolution-receipt/original-before.json | `8185ba016cf3cd9b59ca27500ee73768ab7df7dbdfc6821782235966035ca0c5` |
| resolution-receipt/original-after.json | `8185ba016cf3cd9b59ca27500ee73768ab7df7dbdfc6821782235966035ca0c5` |
| logs/2026-09-09T03_54_35_710Z-debug-0.log | `b150a482fc8570448ebe1e7474010aaacccb3a90b0ec61178c3bce02064c6362` |

The canonical-path repair is demonstrated for this private lock operation, and
the comparison status is `MATCH`. Independent root review is still required
before admitting it as an install input. The next finite step is review of this
lock and its unchanged selected tooling closure, followed only if separately
authorized by a standard script-disabled locked dependency installation and the
already planned structure-only build/output inventory. There is no permission
here to enable dependency scripts, ship full-viewer/codec bytes, or skip license,
controller, wheel and actual-browser acceptance. No further resolver run is
needed to prove this path correction.

## Root independent canonical-lock admission, September9

Root read the complete corrected receipt, launcher, comparison implementation,
actual result, manifest, entry/spec and webpack configuration. An independent
stdlib-only comparison of the original/corrected locks confirmed all428 complete
placement records equal after exactly the documented path normalization, with
root version0.0.0 and the frozen213,405-byte lock hash. No package code executed.
The427-version tooling closure is admitted as a dependency-acquisition input,
not as redistributed code, a browser pass or scientific evidence.

The next step remains the finite archive/rights acquisition from this exact lock:
same427 identities, retained local Molstar archive reused, official registry only,
scripts disabled, no version changes or resolving again. Prepare a minimal
bounded acquisition invocation and inventory under the existing32MiB/file,
128MiB compressed,512MiB unpacked and15-minute overall ceilings; use established
download/archive facilities, not a new resolver/network-interception framework.
Review source/size/integrity/notice results before an offline install/build. The
reviewed entry/spec/config remains provisional until its actual output graph,
component semantics and two-build identity are checked. No full-viewer/MP4/WASM
substitution, installation or browser run is authorized by this paragraph alone.
