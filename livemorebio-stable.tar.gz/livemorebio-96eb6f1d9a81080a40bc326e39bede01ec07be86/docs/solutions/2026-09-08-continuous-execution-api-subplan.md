# Continuous execution: authenticated product wiring

Date: 2026-09-08. Status: independently reviewed; implementation authorized.
Parent: full-scope recovery R04/R08/R25/R26/R29/R31/R45/R47. This is an
additive integration packet, not completion of those requirements or R01–R51.
The numerical and LIFE contracts remain governed by the continuous-execution
subplan. No changes to the installed release or prior operational stores.

## Problem and source ownership

The tested numerical manager is not yet reachable through the product. Browser,
terminal and SDK must use one authenticated service contract, not manufacture
frames from display arrays or post an arbitrary model snapshot.

Initial product source is the currently activated, registry-backed twin only.
The preview is not a registered person. A capability response explains how to
create/activate a twin when none exists. Saved Cendos member/condition sources
remain a separate required extension with their frozen run identity; they must
not silently resolve to the active twin.

Within ModelSourceAuthority.capture, validate the active runtime summary against
the registry's active twin, including twin ID, subject ID, version and source
class. Construct selection on the server: exact subject/twin/version, null
cohort/member/run for this source, condition_id=`active-model-inputs`,
stage=`prospective-execution`, source_data_class from the admitted registry.
The names describe inputs, not a claim of biological baseline or treatment.
Reject client-supplied source payloads, parameter overrides, source classes,
initial state arrays, run bindings or physical-validation labels.

## Additive API

- GET `/api/executions/capabilities`: authenticated/no-store, supported engine
  contracts, native axes, explicit modeled evidence status, selected-source
  identity/generation and preparation availability/reason. No full health
  profile or storage path. Configuration absence is visible, never a fallback.
- POST `/api/executions`: strict bounded object with engine_contract_id,
  expected_source_generation, expected_twin_id, expected_twin_version, policy;
  require Idempotency-Key. Capture and prepare under authority then manager
  lock. No numerical solve under that lock.
- GET `/api/executions/{id}` and `/frames?after_frame=&limit=`: authenticated,
  no-store, bounded incremental results and exact source binding. Never return
  another execution's latest frames. A browser may poll only its selected ID.
- POST `/api/executions/{id}/{start,pause,resume,stop}`: strict revision and
  source-generation preconditions. Start/resume first validate the current
  authority generation, then release it before native work; the manager's
  tracked source-validity flag and in-flight revision fence close the intervening
  source-change race. Stop may use the execution's recorded generation even
  after source replacement; a fenced source is already paused and cannot resume.
  Stop never activates a replacement twin.
- POST `/api/executions/{id}/fork-checkpoint`: strict parent revision plus the
  same new-source/preparation preconditions. Explicitly linked new execution,
  exact model/selection/parameter/schedule identity and full checkpoint only;
  no claim of bit-identical retained solver history.

Read at most 16 KiB request bytes using the request stream, independent of
Content-Length. Reject invalid/non-object/duplicate-key/nonfinite/deep JSON,
unknown fields, coercible booleans and invalid ranges. Fixed error codes only;
no exception strings, body echo, local path, credentials or profile in errors.
Keep responses bounded by the manager's frame-byte/page limits.

## Store and audit boundary

Construct one lazy manager behind a creation lock from explicit
LIVEMORE_EXECUTION_STORE and patch_storage_key(create=False), with no inherited
home-directory fallback and no secret generation. The installed launcher will
later provision its private path/key through a separately tested installer
change. Missing configuration makes this feature unavailable; it does not
disable existing readouts. Manager shutdown closes only its owned workers.

All execution access is PHI-like, including synthetic sources. Before an
authenticated operation reads or mutates an execution, append a durable encrypted
request event. Append its outcome before returning data. If initial audit fails,
do not perform the operation. If outcome audit fails after a mutation, return a
fixed unavailable response; retain the request ID and operation idempotency so
the caller can inspect/retry safely instead of duplicating execution.

Preferred minimal seam is ExecutionStore.record_access with an encrypted SQLite
audit table in the same private store: random request ID, server timestamp,
allowlisted action/phase/result code, optional validated random execution ID,
and principal=`local-operator`. Never store tokens, request bodies, patient
identifiers, quantities or raw exception messages. Encrypt with distinct AAD per
random audit record. Transactional append and quota account for audit records;
no silent error swallowing or automatic deletion of history. A small reserved
control/audit budget must allow a quota pause and its result to be persisted.

`local-operator` truthfully describes the existing single-operator credential;
this packet is not multi-tenant RBAC, individual-user attribution, a tamper-proof
external audit service, HIPAA certification, or production clinical release.
The legacy plaintext best-effort audit helper is not suitable for this path.

Before scientific source capture, require the current packaged runtime source
fingerprint to equal the process startup fingerprint. Otherwise report
EXECUTION_RESTART_REQUIRED, never hash new files while claiming the already
imported runtime uses them. Existing execution frames retain their original
source identity; an edited checkout is not hot-swapped into a running worker.

### Independent engineering review and accepted amendments

The execution-maker lane reviewed this root-owned API packet before root coding.
It accepted the route/source/locking boundaries, with these corrections:

- Capture plus prepare/fork is one authority-guarded operation. The manager
  invalidates tracked records; it need not accumulate unbounded generation
  tombstones. Start/resume still compare the current authority generation and
  check the tracked record after that guard is released.
- Reserve one bounded encrypted outcome for each admitted audit request before
  doing its operation. A shared spare budget alone does not protect a pending
  outcome from concurrent polling. The seam is begin_access(action, optional
  execution_id) -> random request_id; finish_access(request_id, result_code).
  A crashed request remains incomplete; it is never labeled successful.
- Actions are capabilities, prepare, status, frames, start, pause, resume, stop,
  fork_checkpoint. Results are OK or fixed execution/source error codes; no
  arbitrary native message. Root independently reviews the store implementation.
- The parent plan proposed a per-execution 256 MiB quota. This amendment adds a
  total encrypted-payload quota, a 256-record admission limit and bounded
  transition/audit reserves. Physical SQLite pages/journals add separately
  reported overhead; an encrypted payload quota is not an exact disk-size cap.

No clinical or physical qualification is added by this engineering approval.

## Test before implementation and acceptance

Write failing tests for missing auth; absent explicit store/key; unsupported
engine; malformed/oversized/duplicate JSON; injected source/unknown fields;
preview/registry-version mismatch; idempotent repeat versus conflicting repeat;
source replacement between precondition and start; mutation during slow native
initialization; stale late frame; wrong execution frame lookup; strict revision;
checkpoint restart identity; secret/PHI-safe failure; audit-before-access and
audit-failure behavior; private review-store isolation; clean shutdown.

Use a clearly classified technical adapter for route race tests, plus a separate
real native integration of prepare/start/frames/pause/resume/stop with the pinned
metabolic engine. All numerical outputs remain modeled. Cell voltage is not ECG;
intracellular calcium is not a LIFE Patch chemistry reading. LIFE projections
will use their separately reviewed device contract, not a convenience rename.

After independent code review, walk the controls in the real isolated browser,
inspect visible current/paused/stale/error states, and retain screenshots and
full interaction evidence. Do not count that technical walkthrough as any of
the six required insulin/botanical program videos.

## Independent implementation review — 2026-09-08

The source/numerical reviewer, separate from this API's maker, read the router,
source-authority and manager seams, encrypted audit boundary, shared credential
handling, and route regression tests. Two independently reproduced P2 findings
were returned to the maker and corrected:

- A source-file change after preparation originally bypassed the startup/runtime
  fingerprint guard on Start and Resume. Both actions now require that guard;
  status, retained frames and Stop remain available for safe inspection/control.
- A non-ASCII Authorization value originally raised from string comparison and
  produced HTTP 500. Shared read and mutation authentication now rejects invalid
  credential characters/length before any store access and compares ASCII bytes.

The reviewer reread the corrections and independently ran the complete API test
file in a fresh private `prepare_review_environment` namespace: **25 passed in
3.92 seconds**, with three existing FastAPI/Starlette deprecation warnings. This
includes one actual metabolic native route execution alongside explicitly
technical adapters for lifecycle/audit races. No retained operational store or
installed service was used. No remaining actionable finding was identified in
this bounded API review. This is not browser QA, a complete platform security
audit, multi-tenant authorization approval, consumer-lease acceptance, or physical
or clinical model qualification; those retain their separate gates.

### Independent LIFE API and proxy follow-up — 2026-09-08

The same independent reviewer read the LIFE session router, fixed-loopback
configuration, guarded consumer source, same-origin proxy and shutdown seam. A
private reproduction showed that validating a stripped journal path while the
cached gateway consumed its raw value could create a different relative journal.
The correction rejects surrounding path whitespace before creation, constructs
the gateway from the validated exact journal path and verifies its encryption key
against the session store. It no longer inherits an unrelated cached gateway.

The additive source-client status helper retains bounded strict JSON, source-build
and process identity checks for explicitly allowed statuses; its default remains
200-only. Consumer fetch, renewal and delivery retain the runtime-drift guard.
The proxy uses a separate base client and does not renew a producer lease.

An independent isolated run of LIFE API, source-client, proxy and actual native
ASGI-loop tests passed **37 tests in 4.29 seconds**, with three existing
deprecation warnings. No actionable blocker remained in those requested deltas.
The actual loop uses numerical metabolic output and the real encrypted gateway
and signed intake through ASGI; this is not real-socket, browser, 30-minute soak,
hardware, or physical-equivalence evidence. Those gates remain separate.
