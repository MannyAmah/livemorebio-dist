# Beard precision v2 — fixed OS-only supervisor probe

Date: 2026-09-08. **PRE-CODE; root and independent review required.** This is a
small engineering acceptance packet before the separately authorized numerical
matrix. It authorizes neither probe execution nor model work by its existence.

## 1. Purpose and frozen boundaries

The corrected shared precision supervisor passed independent static/mock review:
229 passed, 32 explicit gated skips. Those tests did not exercise the actual
Darwin child-exit transition or terminate a real descendant. This packet checks
only that operating-system behavior and the retained exit/stream receipts.

Freeze the reviewed execution module at SHA-256
`45e7442b9e9872a2a62a67c47c0f7b77d1ae170c5ea0e9bd986ab187d251853d`.
The unchanged numerical preregistration remains
`68ff48a84ce6ca51828dbc2034322ada2c51ac4875b53a6fb8f1f6b4685ea758`.
No source equation, parameter, unit, grid, solver setting, numerical criterion,
runtime package, C file or package/service API changes. All on-disk gates remain
false. No CellML parsing/conversion, source evaluation, C compilation, native
biological callback, physiological initialization or solver call is permitted.
These probe outcomes are not numerical or biological evidence.

## 2. Private fixed driver and admission

After this plan is reviewed, author a separate owner-only directory and a complete
fixed probe driver plus three small Python fixture scripts using `apply_patch`.
Do not edit the production modules to expose a generic command endpoint. Root
and reviewer read all scripts, freeze every SHA and separately authorize one
attempt before an authorization receipt is created or any fixture is executed.

The driver uses the reviewed verified-byte module-loading pattern from the
private matrix checkpoint: a fresh managed interpreter with `-I -B`, exact Python
3.11.15 executable/prefix, source module paths/hashes/object bindings, sanitized
environment and no inherited loader/preload settings or credentials. Fixed
Python executable is:

`/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11`

SHA-256: `e3938f2a272dafdc33f3dd12b093dfc85354629476cb97a7d7d4a7201b8482dd`.
Its Mach-O UUID is read with the fixed system inspection tool before any fixture
launch and frozen in the reviewed driver/receipt; do not substitute an assumed
or dynamically selected Python image. The exact managed venv prefix and every
reused module hash are also part of that later driver review. Package imports
must not enable or invoke scientific paths; no compiler/runtime benchmark is a
prerequisite for this process-only probe.

In that private process only, set `PRECISION_EXECUTION_APPROVED=True` for the
explicit test-only call and retain the v1 execution/evaluator gates false.
Acquire the existing `_SUPERVISION_LOCK`, call the unchanged `_supervise_owned`
with the exact verified fixture argv and declared policy lane, then release the
lock in `finally`. Restore the precision gate in the outermost `finally`.
This private helper call is not a supported product arbitrary-command interface.
Do not monkeypatch sampling, ownership, cleanup, timers, failure handling or any
model function to obtain a passing result.

Create an exclusive, fsynced once-only marker before the first fixture launch.
No second invocation, discarded failure, replaced script or automatic retry is
allowed. Only the separately fixed repetition count below is authorized.
An occupied unresolved-child slot stops before further files or children.

## 3. Exact probe schedule and outcomes

Run sequentially in this fixed order: N0, D0, C01–C08, S01–S08. This is exactly
18 direct children and, only in D0, one same-group descendant. Every invocation
gets a new private subdirectory and fixed stdout/stderr paths. No fixtures are
run concurrently and no live services or browsers are controlled.

| Probe | Fixture and lane | Required engineering outcome |
|---|---|---|
| N0 | Verified Python writes `probe-nonzero-out\n` to stdout and `probe-nonzero-err\n` to stderr using `os.write`, stays alive for 0.20 s so sampling is possible, then `os._exit(17)`. Native-policy lane, actual Python image UUID required. | Observed exit exactly 17; at least one valid owned-image RSS sample; complete streams with exact expected hashes; clean group proof and reap. Nonzero fixture exit is intentional, not a model failure or successful computation. |
| D0 | Verified Python creates one anonymous readiness pipe and calls `os.fork()` once. Descendant sends a fixed readiness byte, closes the pipe, stays in the same session/group without exec, sleeps 8 s as a failsafe and exits. Leader waits for that byte, emits its and the descendant's integer PIDs with a fixed marker, writes fixed stderr, sleeps 0.20 s, then `os._exit(23)`. Native-policy lane. | Leader exit exactly 23; at least one valid sample; cleanup observes at least one live group member, sends a group termination signal, proves no live group members BEFORE leader reap, then observes exit 23. This proves a naturally exited held leader did not cause the surviving descendant to be skipped. |
| C01–C08 | Eight distinct invocations of the fixed immediate-exit script: fixed stdout/stderr markers then `os._exit(0)`, no sleep/fork/exec. Compiler-policy supervisor lane, but it launches Python and is explicitly NOT a compiler test. | Each observes exit 0, complete exact streams, established group ownership/empty-group proof, clean reap. RSS is explicitly not measured in this lane. |
| S01–S08 | Eight distinct invocations of that same immediate-exit script under native-policy supervision and the fixed Python UUID. | If sampling occurred: complete response with exit 0 and normal checks. If the child exits before the first valid sample: exactly `RESOURCE_SAMPLING_FAILED`, zero valid samples, actual exit 0, complete streams and clean group proof/reap. That explicitly expected fail-closed branch is not counted as a resource-qualified native success. Any other error fails the packet. |

The D0 leader output format is exactly ASCII
`<leader_pid>:<descendant_pid>:descendant-ready\n`. Both IDs must be distinct
positive integers; the leader ID equals the supervisor receipt PID. Its fixed
stderr is `probe-descendant-err\n`. Immediate-exit fixtures emit
`probe-short-out\n` and `probe-short-err\n`. No output contains paths,
environment values, credentials, subject records or scientific quantities.
Hashes are computed from the exact prescribed bytes (including actual D0 PIDs),
not merely copied from the supervisor's own receipt.

The 0.20 s lifetimes are deliberate OS fixture behavior to exercise sampling,
not a performance claim. D0's 8 s failsafe is not cleanup success: if the
supervisor cannot prove termination, report that failure even if the descendant
later exits by itself. Do not wait out the failsafe and reclassify the result.

## 4. Bounded resources and failure handling

The module's compiler/native limits are unchanged. In addition, the private
driver creates a fresh cancellation Event and a timer setting it after 2.0 s
for each fixture. This exercises the existing cooperative cancellation seam;
it does not replace or weaken the existing work/resource/cleanup limits. The
sampler's requested interval remains 10 ms. Cancel and join the timer after the
call; failure to quiesce that owned timer is a packet failure, not a leaked task.

Each invocation retains the existing single 3 s ownership/termination/reap
budget. Declare a 5.25 s observed elapsed acceptance ceiling per call, allowing
the 2 s cancellation period, 3 s cleanup budget and 0.25 s scheduling overhead.
This is an observed acceptance bound, not hard real-time scheduling or hard
process-memory isolation. Record actual elapsed times; do not hide excess time
by excluding cleanup. Check the ceiling even if the desired exit eventually
arrives. N0/D0 may not pass by taking the cancellation branch instead of their
prescribed exits.

No fixture allocates a large buffer, reads a file, opens a network connection or
creates more than the declared single descendant. Compiler-policy streams retain
the reviewed 64 KiB cap; native-policy streams retain the reviewed 64 MiB cap.
This packet does not try to exhaust those caps. Native-policy RSS retains the
sampled-soft 1 GiB threshold, observed sample count/gap/peak/overshoot and exact
image/start identity. No compiler RSS/hard CPU claim is made. Fixture scripts
disable core dumps and use owner-only umask before other fixture work; the driver
does not add a new hard whole-process memory claim.

Fail stop on the first unexpected result. Retain all completed receipts and mark
remaining IDs NOT_RUN with the original reason. Never retry or widen a deadline
after observing a failure. A nonempty `_UNRESOLVED_CHILD` forces nonzero
`UNRESOLVED_CHILD`, retaining the original error separately. Do not clear the
anchor, signal a bare PID, reap an uncertain leader or start another fixture.
The anchor is process-local and is not promised to survive driver exit; report
unknown cleanup honestly. No unrelated process/service is terminated.

## 5. Evidence and independent acceptance

Before launch, record driver/script/module/protocol hashes, exact authorization,
Python binary/UUID/prefix, OS/architecture, private output directory and fixed
schedule. For every attempted fixture retain original streams and all existing
supervision fields, including primary/secondary errors, observed exit state,
actual sample metrics, ownership probes, group count, signal and cleanup-before-
reap flags. Also record independently computed expected stream lengths/hashes,
probe-specific assertions, timer completion and observed elapsed acceptance.

The aggregate status is `OS_SUPERVISOR_PROBE_PASS` only if all 18 outcomes meet
the prespecified rules. Count native sampled successes and zero-sample
fail-closed outcomes separately. Any other condition exits nonzero; failure to
persist a receipt cannot turn failure into success. No raw stream data is copied
into public summaries. Record absence of unresolved anchors and restore all
temporary gates even after errors. Do not claim that repeated short exits
exhaustively establish absence of OS races.

Root and an independent reviewer read this proposal, then the complete driver,
fixtures and hashes, before an explicit once-only probe authorization. After
execution they inspect the actual retained receipts and especially D0's exit 23,
live-descendant count, group signal, empty-group proof and reap ordering. The
private numerical matrix driver remains a separate file, authorization and
attempt. It may not overlap Atlas browser performance measurements. A probe pass
does not grant authority to compile/evaluate/solve the Beard model.
