# Atlas reference conversion, cache and initial renderer packet

Date: 2026-09-08. Parent: `2026-09-08-whole-person-atlas-native-context-subplan.md` and the full R01–R51 recovery register. Status: **WRITTEN PROPOSAL — independent engineering review and root implementation approval required**. No converter, installer, renderer or product route was implemented while writing this packet.

## Authority, scope and prerequisite decisions

Root and the independent release reviewer accepted the facts in `2026-09-08-atlas-reference-gate-a-source-evidence.md` and checked the exact 489-member candidate against the archive and maps. Root selected the current publisher CC BY 4.0 basis for isolated feature development, preserving historical notices; public release remains separately gated. The source investigation is not rendered acceptance or physiological qualification.

This packet makes that accepted single-source geometry installable and inspectable in the approved A+B whole-person Atlas. It preserves A's workspace, B's green header/body/time, the left multiscale path and every existing product. Biology remains the deeper process/organ/cell/molecular inspector, not the source of an exploded whole-body montage. This packet does not close all R21–R27/R46 or the missing spatial/multiscale obligations.

Engineering-review framework: `/plan-eng-review` was read completely. Its architecture, code-quality, test and performance sections inform this proposal; the author is not independently approving their own plan. Existing written product/design decisions remain authoritative. Connected gbrain, CE and context7/sequential-thinking tools were not found in this session; no substitute tool invocation or independent review is claimed.

### Step 0: scope challenge and existing mechanisms

Use the existing Python/NumPy/trimesh server dependency and packaged Three.js/GLTFLoader/OrbitControls. Do not add a geometry service, general asset-upload system, worker queue, new scientific solver or parallel application. A small strict source parser plus explicit trimesh scene construction is preferable to a general importer that might merge or repair geometry silently. GLB serialization should use the existing exporter, not a new hand-written glTF writer.

| Existing seam | Reuse and limitation |
|---|---|
| `anatomy/meshes.py` cache/read/lock patterns | Reuse the reviewed design, not unsafe assumptions: its mutable `LATEST` acquisition and existence checks do not establish this frozen archive identity. Do not change the old seven-organ catalog in this packet. |
| `anatomy_vendor.js` and its manifest | Reuse the exact local Three/GLTF/OrbitControls package, including license and dependency-integrity tests. No CDN dependency. |
| `anatomy_requests.js` | Reuse cancellation/single-request/bounded-pending behavior. Its existing allowlist accepts only legacy asset URLs; extend by an explicit validator hook or a narrow new helper, never an arbitrary URL escape hatch. |
| `anatomy_loader.js` | Reuse WebGL capability and local dependency loading, but do not import or mount the legacy dispersed organ explorer in Atlas. |
| `anatomy_view_state.js` / existing Retry tests | Reuse the control-state contract where equivalent. Camera/section/layer state must be reapplied after a successful same-manifest Retry. |
| `biological_projection.js`, `execution_view_state.js` | Later exact-source state binding remains separate. Neither contains an organ displacement field. This packet cannot infer motion from those scalar series. |
| `workspace.html`, `workspace.js/css` | Mount one dedicated reference scene inside the existing whole-person area. Root coordinates changes to currently shared workspace ownership. |
| Existing review launcher, build-identity and browser harnesses | Reuse isolated stores/ports, exact runtime identity and real Chrome/SwiftShader inspection; no old operational state. |

The packet crosses more than eight files once tests, package data and the root-owned routes are counted. The justified seams are source/cache, static HTTP, scene/UI and independent acceptance—not new services. Implement in stages with explicit owners rather than combining source admission, physiological state binding and every Atlas control into an unreviewable change.

Rejected shortcuts: reuse `normalize()`/`SPREAD` from Biology; combine unrelated HRA/BP3D frames; load a skin illustration; declare geometry ready from a HTTP 200; invoke trimesh processing/welding; silently decimate; manufacture body motion. The complete version here includes safe cold installation, exact transforms, honest missing states, all nine groups and measured rendered inspection.

## 1. Frozen source declaration and exact node mapping

Promote the independently checked candidate into small packaged **source metadata**, not a bundled licensed archive. Original proposal:

`docs/solutions/2026-09-08-atlas-reference-gate-a-candidate.json`

Its current file SHA-256 is `24fda873f5fe594cdeaa026fcbffac2c110721760cbb5cc8bc99a788f222cb8a`. Packaging may change the schema/status intentionally; it must retain all source member/hash/count/bounds and group-set values with an explicit cross-check test. The eventual packaged declaration hash is computed only after review, never copied from a differently serialized file.

Fixed source ID: `bp3d-4.0-20130619-surface-core-v1`. Source release: 4.0; archive publication directory: 20130619. Fixed archive:

- URL: `https://dbarchive.biosciencedbc.jp/data/bodyparts3d/20130619/isa_BP3D_4.0_obj_99.zip`
- Exact bytes: 142,903,898; SHA-256: `40665852c49f218326590e204db91064a1ecfc3c6f8cbd7bbbcaac62c7cd409e`.
- Exact dated IS-A/PART-OF map URLs and hashes from the accepted source report. No `LATEST`, user-supplied URL, alternate anatomical release or guessed missing part.

Every element is keyed by its exact upstream `element_id`; preserve source `representation_id`, `concept_id`, name, compatibility header, archive path, source byte hash, counts and native bounds. A compound FMA ID is a membership relation, not a geometry ID or an independent copy of every member. No guessed UBERON crosswalk is added.

| Fixed asset/group key | Declared map root | Elements | Triangles | Raw bytes |
|---|---|---:|---:|---:|
| `skin` | IS-A FMA7163 | 1 | 203,382 | 14,465,502 |
| `heart` | PART-OF FMA7088 | 83 | 102,802 | 6,822,515 |
| `liver` | PART-OF FMA7197 | 60 | 191,622 | 12,935,351 |
| `pancreas` | PART-OF FMA7198 | 4 | 16,962 | 1,325,384 |
| `right-kidney` | PART-OF FMA7204 | 1 | 2,310 | 139,395 |
| `left-kidney` | PART-OF FMA7205 | 1 | 2,982 | 182,275 |
| `right-lung` | PART-OF FMA7309 | 156 | 73,312 | 4,754,472 |
| `left-lung` | PART-OF FMA7310 | 124 | 41,438 | 2,660,353 |
| `brain` | PART-OF FMA50801 | 59 | 322,262 | 21,659,135 |
| Exact union | Nine sets, 489 unique IDs | **489** | **957,072** | **64,944,382** |

The initial nine sets are disjoint in the reviewed candidate. Nevertheless, build an element→memberships index first, then allocate one asset/node owner in the fixed table order; subsequent memberships reference that same node. Do not deduplicate by display name, coordinate similarity or geometry hash. Two distinct upstream IDs remain distinct even if some coordinates match. Assert the current exact sets/digests and unique union; an unexpected overlap or changed group is a declaration mismatch requiring review, not an automatically repaired catalog.

Within each asset, order elements lexicographically by their exact IDs. Use node name `bp3d:<element_id>` and mesh name `bp3d-mesh:<element_id>`. The manifest maps each ID to `{asset_key, node_name, mesh_name, node_index, mesh_index, memberships}`; parser/exporter array indices must be verified from decoded output, not guessed from insertion order. Preserve ASCII IDs with actual valid upstream suffixes in the generic parser, while admission accepts only this explicit 489-ID allowlist.

Nine GLBs are retrieval partitions for progressive loading, not nine independently positioned anatomical frames. One geometry node/primitive per source element; no cloning to implement system filters. No merged anonymous organ mesh that loses selecting the source element.

## 2. Conversion and numerical preservation

### Source grammar confirmed before implementation

An additional read-only audit of the 489 exact source byte hashes found:

- 535,346 `v` records and 535,346 `vn` records; 957,072 triangular `f` records.
- Exactly one `g` and `usemtl` record per member; no other noncomment record classes.
- Every face token has the form `vertex//normal`, and all 2,871,216 referenced normal indices equal their vertex indices. No texture index, repair or reindexing is needed.
- Longest line: 300 bytes. Largest selected member: 14,465,502 bytes; largest vertex array: 102,467 positions.
- Source normal lengths lie in [0.9999991616926486, 1.0000008409041463]. Do not normalize these source arrays in the converter.
- A float64 cross-product audit found three zero-area triangles in `FJ2820` (source SHA `bac2d30a479b0a7765f4a7fe4e25bd44fa7c01cd6a0b24bf4323d270bad75b35`, zero-based face indices 9472, 11025, 11147). The same three remain after source positions are encoded to float32 and decoded; zero additional zero-area triangles and zero repeated face indices were found across the 489 elements. This is a numerical source audit, not proof of a watertight/manifold or anatomically accurate surface. Preserve and report these source triangles rather than repairing or dropping them.

Read ASCII line records in their original order. Require the exact approved header identity and finite three-component vectors, positive bounded indices, three vertices per face, matching normal-index policy, declared counts and source hash. Reject unrecognized geometry-affecting directives, vertex weights, texture coordinates, polygons, malformed groups, external materials, empty geometry, duplicates of required headers, extra numbers, zero/out-of-range indices and all nonfinite values. Retain `usemtl` only as source metadata; the current files do not provide a material library for the proposed display. View colors are reference navigation styling, not recovered biological tissue appearance.

Construct each trimesh mesh from explicit vertices/faces/normals with `process=False`, `validate=False`; no merge, fix-normal, repair, cleanup, convex hull, resampling or automatic unit inference. Use the existing GLB exporter with normals included and `unitize_normals=False`, no Draco/quantization or texture encoding. The locally inspected version is trimesh 5.0.0, whose installed API exposes these options. Before implementation uses its APIs, record primary documentation/installed-code review; connected context7 was unavailable. The converter receipt includes actual Python, NumPy and trimesh versions, relevant loaded converter/exporter identity and fixed options. A different converter identity cannot silently reuse a readiness claim for old outputs.

### Exactly one common coordinate conversion

Native: millimeters; +X anatomical left, +Y posterior, +Z superior. Preserve negative native Z; the source skin extends to −78.1112 mm despite the publisher diagram's positive-Z statement.

Use this same top-level matrix in **each GLB**, above identity element nodes:

```text
world-meters = M × native-millimeters

M (row-major for this document):
  0.001   0       0       0
  0       0       0.001   0
  0      -0.001   0       0
  0       0       0       1

glTF column-major matrix:
[0.001,0,0,0, 0,0,-0.001,0, 0,0.001,0,0, 0,0,0,1]

identity renderer assembly
  ├─ skin GLB: M → identity element node(s)
  ├─ heart GLB: M → identity element node(s)
  └─ ...same exact M for every remaining partition
```

All partition roots use one common conversion policy, not organ-specific placement. The renderer assembly stays identity and **must not apply M again**. This retains native millimeter attributes but standards-compliant meter-based scene coordinates. Do not emit millimeter GLB identity scenes and rely on an undocumented external scaling convention. Do not bake a transform into positions and also leave it on the root.

No local element translation, scaling, rotation, recentering, fitted organ placement, mesh normalization or `SPREAD`. Camera target/framing may use the complete transformed surface bounds; moving the camera is not modifying vertices. Normals use the corresponding orientation/normal transform during rendering; stored normals remain source values within float32 representation tolerance.

### Preregistered round-trip gates

The read-only source-to-float32 calculation gave maximum absolute position-component error **0.00005859375005456968 mm** and normal-component error **2.9800415024539006e−8**. These are source encoding calculations, not a completed GLB round-trip.

Before admitting any output, decode its GLB accessors independently of the exporter and check **every** vertex, normal and triangle, per element:

1. Exact source ID/node membership, vertex/normal/triangle counts and vertex/face order. Decoded indices equal original zero-based indices exactly; no dropped/reordered/welded vertices or faces.
2. Native position component error ≤ **0.0001 mm**; source-normal component error ≤ **1e−7**. Any excess rejects; no after-the-fact widening.
3. Apply decoded full scene graph matrices, invert the declared M and compare all coordinates. World-space per-component error ≤ **2e−7 m**. Assert right-handedness, exact matrix policy, identity child/renderer matrices and no extra transforms. This is decoded/CPU geometry verification, not a claim of GPU arithmetic or anatomical accuracy.
4. Recompute per-element and union bounds from arrays. Check expected source bounds, negative inferior coordinate and left/right kidney positions after inverse conversion. Check each element's hash and source-order mapping against the declaration.
5. Round-trip shape and topology checks distinguish the three documented source zero-area triangles from introduced damage. Do not repair or discard a source-degenerate triangle; count and report it. Reject new degeneracy caused by conversion or a failed normal/index mapping. Independently reproduce the source audit and decoded-GLB comparison before approving output; a near-degenerate triangle is not silently clipped to zero by an epsilon rule.

Run identical conversion twice with the same loaded converter identity and require byte-identical GLBs and canonical manifest. Exclude acquisition times/random staging paths from the deterministic manifest; retain them in a separate installation receipt. If the exporter injects unstable metadata, remove only identified nongeometric metadata through a documented deterministic option, with tests; do not normalize geometry to force determinism.

## 3. Hard budgets and staged loading

These are predeclared rejection/resource budgets, not measured performance claims. One MiB means 1,048,576 bytes.

| Boundary | Accepted actual value / hard limit |
|---|---|
| Downloaded archive | Exact 142,903,898 bytes and SHA; streaming ceiling 144 MiB; content-length is advisory, not the validator |
| ZIP central directory | Exactly 2,234 reviewed OBJ members; aggregate uncompressed 479,605,380 bytes; hard ceiling 512 MiB; no encrypted entries, duplicate names, symlinks, absolute/traversal paths or unexpected file types |
| Extracted selected content | Exact 64,944,382 bytes; ceiling 70 MiB; do not `extractall` or unpack unrelated entries |
| One selected OBJ | Declared exact byte count/hash; ceiling 16 MiB; line ceiling 1 KiB; bounded vertices/faces from the declaration |
| Source text map | Exact reviewed hash and schema; ceiling 8 MiB each; fixed source URLs only |
| GLB partitions | Maximum 16 MiB per partition and 40 MiB total; JSON chunk ≤ 2 MiB per partition; finite bounded accessor/index ranges |
| Expected raw GLB attribute/index payload | 24,333,168 bytes for float32 positions/normals and uint32 indices; JSON/padding measured afterward; no claim final GLBs already have this size |
| Concurrent geometry downloads | Skin first; at most two internal partitions in flight; do not fetch internal partitions before the surface is drawn |
| Conversion working memory | Process one partition at a time; target peak additional RSS ≤ 512 MiB and measured total converter process RSS ≤ 1 GiB; report actual baseline/peak in acceptance |
| Cold acquisition | 30 s connect/read inactivity bound, 600 s total fixed-source network deadline, 180 s conversion deadline; fail with retained prior valid installation, no unbounded implicit retry |
| Temporary disk requirement | Require ≥ 512 MiB available for bounded archive/maps/output/staging plus declared existing-cache usage; retain only owned artifacts, never clear unrelated cache to make space |

ZIP admission must bind the full archive SHA **before** parsing geometry, then validate all entry metadata and exact selected member hashes while streaming. Per-entry decompression cannot exceed declared size. A hostile central directory, duplicate member or CRC/decompression failure aborts the candidate installation. Source member grammar is allowlisted rather than a general OBJ upload parser.

The network client disables implicit redirect following. Every initial source URL is an exact packaged HTTPS allowlist entry with ordinary TLS certificate/hostname verification; reject userinfo, changed scheme/host/port/path/query and every redirect whose resolved target has not been independently approved in that declaration. **No redirect hops are approved initially**. A publisher redirect therefore returns a named source-policy error rather than silently changing authority; any necessary new target requires source review. If later reviewed targets permit a hop, enforce at most two explicitly declared HTTPS hops, forbid downgrades and carry the original monotonic 600 s total deadline and byte budget across the whole chain. A redirect, retry or new socket must not reset either bound. Send no operator token/cookie or PHI to source hosts. Tests include same-host unapproved path, foreign host, HTTP downgrade, relative Location, loops, absent/ambiguous Location and delayed hops; no output publication on rejection.

Per-partition uncompressed position/normal/index payload estimates from the exact counts are: skin 4,899,792; heart 2,672,496; liver 4,932,984; pancreas 513,048; right kidney 55,632; left kidney 71,712; right lung 1,934,232; left lung 1,096,296; brain 8,156,976 bytes. They exclude JSON, padding and renderer bookkeeping, and do not replace actual GLB/GPU measurement.

Warm rendered performance targets to measure at 1440×1000 and 390×844: whole-person surface visible within 5 s after its same-origin bytes finish; initial nine-partition loading within 15 s on the isolated warm cache; bounded controlled camera inspection with p95 frame time ≤ 50 ms on the declared Chrome/SwiftShader reference environment. Report hardware/renderer/browser/version, DPR, asset bytes, triangle/draw-call counts, frame-time distribution and memory scope. These targets are proposed acceptance thresholds, not source-derived facts. Actual hardware-GPU support requires a separately available hardware environment; SwiftShader cannot prove it.

Cap renderer pixel ratio at min(devicePixelRatio, 2). No idle render loop is required: render on asset load, user camera/clip/layer/resize/selection changes or admitted state updates; camera damping, if used, ends after settling and pauses while hidden. No idle orbit, pulse or deformation. If budgets fail, retain failure and submit a reviewed same-source loading/representation adjustment; do not silently reduce triangles or call a fallback successful.

## 4. Private, atomic source/cache admission

Cache namespace: a new owner-private `atlas/` child of the already configured `LIVEMORE_ANATOMY_DIR`. No new global env override is needed; review/installed launchers already isolate that parent. Do not create or rewrite anything during import or a missing-cache status check. Do not change permissions on unsafe existing paths to make them pass.

```text
explicit install(fixed source ID)
  → validate private cache root and single acquisition lock
  → verify fixed raw archive/maps (or bounded HTTPS acquisition)
  → compare exact packaged declaration, parse one partition at a time
  → export to private uniquely owned staging directory
  → independent accessor/matrix/hash/size/topology checks
  → fsync files + staging directory
  → atomic rename to artifacts/<manifest_sha256>/
  → fsync artifacts parent + source staging parent after the rename
  → atomic durable receipt publication + fsync receipt parent
  → atomic active pointer publication + fsync pointer parent (last)
  → return admitted metadata; later HTTP reads verify the same bytes

failure/cancel/process death before final publication
  → previous active artifact stays valid; partial staging is never served
```

The new child and artifact/staging subdirectories must be real owner-owned 0700 directories; regular files/lock/receipts 0600, no symlinks or hardlinks. Validate fixed root/subpaths before open and validate descriptors after `O_NOFOLLOW`/relative directory opens; reject changed identity/type/ownership/unsafe mode. Handle allowed system path aliases explicitly without following user-created symlinks inside the designated cache. Existing inherited cache helpers are patterns, not proof that these stricter pre-open checks exist.

Durability ordering is part of the commit contract: fsync every completed data/manifest file, then the staging directory; after renaming into `artifacts/`, fsync both destination parent and the source parent when different. Write/fsync the immutable installation receipt to a same-directory temporary file, rename it and fsync its parent. Only then write/fsync and replace the active pointer, followed by fsync of that pointer's parent. Return success only after those directory syncs finish. Fault-inject each file/rename/directory-sync boundary; an incomplete candidate is never served. A failure after pointer replacement but before its parent fsync is an **unconfirmed publication**, not a confirmed success or grounds for an unsafe compensating rollback. Previous immutable artifacts/receipts remain intact; an explicit idempotent install/reconciliation can verify and finish durability. A read may describe verified current bytes but cannot retrospectively claim that the interrupted acknowledgment was durably completed.

Use a bounded nonblocking `fcntl` installation lock for the one fixed source ID on supported macOS/Linux. Concurrent install returns acquiring/conflict and does not start a second download/conversion. Reads of an already admitted immutable artifact remain available during a new candidate install; no reader is handed a half-replaced GLB/manifest pair. Windows cache locking remains an explicit unsupported platform for this implementation unless independently implemented/tested; do not silently use an unlocked fallback.

Raw source objects are stored under their expected hashes, verified on reuse. Never trust the older unpinned cache just because a filename exists. This initial implementation may deliberately download the fixed archive into the new namespace; an existing archive may be read only through an explicitly validated safe import seam with an exact full-hash check and private atomic copy, not a hardlink. Avoid adding that optimization before its actual safety tests.

`manifest_sha256` hashes canonical deterministic manifest bytes without a self-referential hash field. It binds packaged source declaration, source/archive/map hashes, conversion identity/options, M, exact node/member mapping, nine asset hashes/sizes and verified precision statistics. The installation receipt separately records start/end time, receipt ID, source and manifest digest, bounded status/error code and artifact counts. No patient/twin data, arbitrary paths, tokens or raw source content in operational logs. No fake audit event or success response if durable publication fails.

Open assets by strict lowercase 64-hex manifest digest and fixed asset key, not free paths. Verify manifest identity and admissible source/conversion contract, file safety, exact bytes/hash, GLB structure and semantic allowlist. Return bytes from the same verified open descriptor/read, with before/after identity checks; avoid the verify-path→later-FileResponse race. Reject external buffers/images/URIs, textures, skins, morph targets, embedded timelines, extensions, extra scenes, nontriangle modes, sparse/unbounded accessors and unknown nodes. The only transforms are the reviewed root M and identity children. Hash-addressed URL alone does not prove those semantics.

Status/read paths are read-only and network-free. Report `missing`, `acquiring`, `available`, `corrupt`, `unsafe_cache`, `unsupported_converter` or `failed` accurately. `available` means admitted immutable bytes/manifest, not renderer/GPU/clinical readiness. Do not return local filesystem paths. Previous admitted geometry can remain accessible by its immutable digest; changing the active pointer does not rewrite old URLs.

## 5. Callable and route contract for root review

Source/cache owner proposes new `livemorebio/anatomy/atlas_reference.py` and packaged `anatomy/atlas/*.json` metadata; root owns all route wiring and package/launcher changes.

| Callable | Contract |
|---|---|
| `catalog()` | Pure packaged source declaration/coverage/rights summary; no cache creation or network |
| `status()` | Read-only bounded readiness, optional admitted manifest digest, acquiring state and safe reason; no person context |
| `install(source_id)` | Explicit fixed-ID action; validate source ID before filesystem/network; return admitted manifest+receipt; never accept arbitrary URL/path/content |
| `read_manifest(manifest_sha256=None)` | Exact admitted manifest, active only when digest omitted; no on-demand acquisition |
| `read_asset(manifest_sha256, asset_key)` | Verified immutable `(bytes, metadata)`; only nine allowlisted asset keys |

Proposed HTTP interface (root finalizes names/status mapping before code):

- `GET /api/anatomy/atlas-reference`: static catalog/readiness, `Cache-Control:no-store`; no subject/biological lookup and no acquisition. Schema `livemore.atlas-reference-status.v1`, `{source_id, state, available, manifest_sha256, manifest, reason, reference_geometry:true, patient_registered:false}`. Missing manifest is null, not a candidate mislabeled admitted.
- `POST /api/anatomy/atlas-reference/install`: authenticated mutation using existing local-session/origin protections; strict JSON exactly `{source_id}`. Successful new/reused installation returns receipt/manifest. Unknown fields or IDs422; auth401; active acquisition409 with `ATLAS_ACQUIRING` and `Retry-After:3`; source/integrity/storage failures503 with stable safe codes. No arbitrary remote source or physical command.
- `GET /assets/anatomy/atlas/{manifest_sha256}/{asset_key}.glb`: exact read-only admitted bytes, no install. Unknown key/digest404; unsafe/corrupt503; `Content-Type:model/gltf-binary`, `X-Content-Type-Options:nosniff`, exact content hash/manifest headers. Cacheable immutable public reference bytes only after the release owner approves public distribution; use private/no-store during internal feature acceptance. Authorization policy for internal asset delivery should match root's source-publication gate, not be inferred from absence of PHI.

Keep the synchronous core callable usable through `python -m livemorebio.anatomy.atlas_reference status|install <fixed-id>`. The install HTTP route must run outside the event-loop thread, with one bounded in-flight installer enforced by its process lock. No new background job platform: long-running explicit installation may continue after a client disconnect; the UI must report response uncertainty, poll **read-only** status and never automatically repeat POST. A 900 s client deadline covers the bounded operation; status feedback remains inspectable in another request. Service termination leaves unpublished staging and preserves the last good manifest.

Enforce the 180 s exporter deadline with one owned, isolated converter subprocess, not a Promise/thread timeout that leaves native conversion running unbounded. It processes the nine partitions sequentially from the already verified fixed source into only its unique private staging directory; it cannot publish the active pointer. Bind the child to the exact reviewed package/converter identity, not caller CWD/PYTHONPATH; use the existing isolated-launch patterns and no shell command expansion. On timeout the parent terminates/waits only its owned child/process group, keeps the prior installation, and records safe failure. This is one bounded conversion helper, not a new service or general user-code executor.

Parent-death safety is mandatory, not supplied by the parent's timeout alone:

1. Pass the already held installation-lock descriptor to the child with the same open-file-description lock, along with a dedicated parent-liveness pipe read end. The parent retains the only write end; unrelated subprocesses do not inherit either end. Child validates the inherited lock file's expected safe identity before work. Never unlink/replace the lock file or explicitly unlock the shared lock while a child may still run; close descriptors only after owned work has stopped. If the parent is killed, the child's descriptor keeps the lock held, so a second installer returns `ATLAS_ACQUIRING` rather than starting another converter.
2. Before importing NumPy/trimesh or parsing geometry, the child arms an OS real-time termination timer with no Python exception handler (`SIGALRM` default termination on the supported Unix platforms), using no more than the remaining conversion deadline. This independent hard deadline cannot be reset per partition or depend on the parent surviving. Unavailable timer/lock semantics reject startup; there is no unsafe fallback. Child also checks monotonic remaining time at partition boundaries.
3. A child liveness watcher reads the dedicated pipe. Parent EOF triggers local child termination, not a publication or a stale PID lookup. The OS timer remains the backstop if a native call prevents Python-level liveness handling. Lock retention prevents a concurrent converter throughout that interval. On ordinary completion the child exits before the parent alone validates/publishes; a parent lost after output generation still leaves only unpublished staging. No child has authority to modify the active pointer.
4. Real subprocess tests kill the installer during converter startup and mid-conversion. Verify the child detects parent loss or reaches its independent shortened test deadline, a concurrent install cannot acquire while the child lives, the lock becomes acquirable only after all inherited holders exit, no output is published and unrelated processes remain untouched. Also cover EOF before heavy imports, parent/child timeout, close-on-exec/descriptor leakage, startup failure, explicit stop and successful cleanup. Tests must exercise actual lock/pipe/process lifetime rather than mocked subprocess return codes.

Installed-wheel tests must prove the source declaration and local renderer dependencies are present, import/status perform no network/write, clean installation has no geometry until explicit acquisition, the private review cache is isolated, and old biological pages still work. No archive/GLB/raw patient data in the wheel/repository. Public publishing, any geometry export and revised dependency pins require root/release-owner review; implementation must not quietly promote a development asset to a public release.

## 6. Initial scene and A+B mount

One new `console/lib/atlas_reference_scene.js` owns geometry, hit testing, camera and disposal. It accepts a fully validated manifest plus the existing local vendor dependencies; it does not fetch physiology, start an execution, activate a twin or submit a perturbation. A narrow controller/mount in existing workspace code owns status/install UI and hands the scene read-only source selection. Preserve existing build-identity code through explicit root/UI ownership handoff.

Default is the **whole person**, not an isolated organ. First show a bounded acquiring/ready state; load and draw `skin` first with its real full-height source surface. Then load the eight internal groups, with explicit per-group pending/failure/count state. No placeholder anatomy or silent missing-layer completion. Use the same native coordinates and front orientation derived from the documented axes, not screen-position guesses.

Initial display: all nine groups enabled, whole-person camera framing, section off, no isolation and compact labels off. The skin is a semitransparent reference envelope so internal groups can be inspected; its opacity control is explicitly appearance-only. Internal groups use stable neutral/reference colors, selection highlight and physically ordinary lighting; no color-coded functional/diagnostic state without an admitted data mapping. Transparent skin must not occlude internal picking unexpectedly; clicks distinguish visible interior candidates and an explicit skin-selection action. Describe overlapping/partial source representation where necessary, not as a live compartment.

Retain the full-height reference surface while internals arrive. If skin fails, do not auto-frame scattered internals as the whole-person default; show the exact surface error and Retry. Valid numeric cards remain visible independently but cannot pass the rendered Atlas gate. If an internal group fails, the body remains available with an explicit partial-layer count and Retry for that same source.

All nine groups have named visibility toggles. Search by source name/ID and selecting from results highlights the exact existing node, opens its reference/source card and can frame it on explicit request. Isolation is deliberate and reversible; show `Return to whole person`. Home restores whole-person framing/section/isolation consistently and updates the controls; it does not change a source or stored preference invisibly. Clip axes are named anatomical axes with visible normalized depth and units/extent; source vertices remain unchanged. Labels and isolation/clip settings survive same-manifest Retry; a changed manifest resets incompatible selection explicitly.

Show group and element breadcrumbs without presenting IS-A versus PART-OF as the same edge. The deeper Biology link carries existing exact subject/run/member/execution context only if valid; anatomy-only selection remains `REFERENCE_ONLY`. No unsupported humanization of Human-GEM or lobeline assay results. If current selected numerical context changes, clear stale quantity/source state while retaining only manifest-compatible camera preferences. Gate B's full native-source Atlas selection controller remains the next explicit packet, not silently implemented or considered complete here.

No numerical quantity changes a node transform, surface mesh or biological color in this packet. Reference interaction is useful but is not executing spatial physiology. R24's tissue/membrane/cell/molecular mechanisms, actual deformation/flow fields, real anatomical LIFE mounting and complete organ coverage remain active work. Do not label this a complete living human or use decorative motion to fill the gap.

## 7. Red-first test plan and failure coverage

All new branches start as failing assertions against missing behavior. Existing anatomy/measurement/source/lifecycle tests remain unchanged except explicit additive cases. Unit passing is not the rendered gate.

```text
SOURCE / CACHE [new tests/test_atlas_reference.py]
  catalog → exact 489/nine sets/names/hashes [UNIT]
  install
    ├─ bad ID / body / unsafe cache → reject before FS/network [UNIT]
    ├─ cold fixed HTTPS → bounded download/hash/ZIP/source grammar [INTEGRATION]
    ├─ warm exact bytes → no network; stable output identity [INTEGRATION]
    ├─ concurrent acquire / interrupted publication → prior valid result [INTEGRATION]
    ├─ killed installer / orphan converter → inherited lock + child deadline [REAL SUBPROCESS]
    ├─ unapproved redirect / downgrade / delayed hop → bounded rejection [UNIT/HTTP FIXTURE]
    ├─ rename/receipt/pointer directory fsync failure → no success acknowledgment [INTEGRATION]
    └─ disk full / truncated source / changed map/export → visible failure [INTEGRATION]
  convert → every accessor/index/node/M/bounds/tolerance [UNIT + real-source gated]
  read → exact manifest+asset; unsafe/raced/extra/external data rejected [INTEGRATION]

ROUTES [root-owned tests/test_atlas_reference_api.py]
  safe status(no writes) → explicit protected install → immutable bytes [→E2E]
  wrong auth/origin/ID/body → no installer call; acquiring/corrupt honest [UNIT/ASGI]
  client response lost → status inspection; no automatic POST retry [→E2E]

SCENE [new tests/test_atlas_reference_ui.py]
  unavailable/vendor/WebGL → useful Retry; numerical state unchanged [UNIT + →E2E]
  surface first → internals pending/ready/error → complete nine-group count [→E2E]
  one scene M per GLB + identity assembly → no double/no scale [UNIT + →E2E]
  choose/search/layer/isolate/clip/labels/home → exact node + visible state [→E2E]
  rapid toggle/source change/retry/dispose → no stale append or duplicate fetch [UNIT]
  hidden/context lost → bounded pause/dispose/restore; no idle motion [→E2E]
  same-source Retry → restore controls; changed manifest → explicit reset [→E2E]

PRESERVATION
  all existing nine pages + exact run/member/execution branch semantics [regression]
  wheel import/status + packaged metadata + isolated cache [installed integration]
  A+B side-by-side + all device sizes + no montage/fallback-only acceptance [→E2E]
```

Specific adversarial fixtures: positive/negative indices, duplicate archive names, directory traversal, symlink/hardlink root/file/lock, ZIP bomb metadata, stream overruns, invalid CRC, changed file after validation, stale active pointer, swapped manifest/GLB, forged source ID, duplicate JSON keys, NaN/Infinity, oversized accessor counts, buffer offsets outside BIN, external URI, extra scene/node, nonidentity element transform, double M, missing M, reversed kidneys/axis transpose, floating precision violation, altered normals, reordered faces, missing/duplicate selected element, all nine exact counts and small valid converted fixture. Use small clearly technical synthetic geometry only in unit/security fixtures; never serve it as the accepted real-body asset.

Real-source tests are explicitly marked network/large-asset as appropriate, use an isolated cache and preserve source bytes. A developer with no archive gets a clear skip for the real-source fixture, not a generic passing anatomical claim. The release acceptance requires an actual successful source install and decoded round-trip independently reviewed.

## 8. Independent rendered acceptance and evidence

Root or a reviewer who did not author the scene runs the real current-source browser after a checkpoint. Use exact build SHA/startup/current identities for all three services, a fresh private technical store/cache and an owned Chrome session. Preserve every failed attempt. No global browser modifications, forced visibility events, borrowed operator records or fabricated model responses.

Required screenshots and matching metadata-only receipts in `docs/screenshots/full-scope-recovery/atlas/attempt-N/`:

1. Missing-source state and explicit installation preparation; pending progress and retained prior geometry on an intentionally failed source test.
2. First rendered full skin surface; eventual full nine-group front view; approved merged/A/B side-by-side comparison without copying their illustrative measurements.
3. Front/side/back real reference landmarks: head/feet and surface extent, brain above thorax, heart/lungs in thorax, liver/pancreas/kidneys in the abdominal source arrangement, correct left/right. Use source-native bounds and source labels in the review, not clinician-level anatomical-accuracy certification. Record any author-source or rendering inconsistency rather than fixing it by hand.
4. Search/select exact skin/heart/pancreas and each kidney; reference details and working deeper Biology link in a valid technical context; no unrelated active-person fallback.
5. Every group toggle, labels, isolation/return, home, section axes/depth, mouse/touch/keyboard camera operation; screenshots show changed view and controls agree.
6. Two tabs during cold acquisition; explicit Retry; corrupt/integrity error; dependency/WebGL/context loss; navigation while acquiring; no duplicate or substituted geometry. Readouts remain separate from graphics failures.
7. 1440/1280/768/390 widths, 200% zoom, keyboard focus/labels, reduced motion, mobile overflow, long source names, selected-object detail and bounded provenance drawer.
8. Measured source/download/GLB sizes, loaded nodes/triangles/draw calls, warm timings, frame-time distribution and declared GPU/SwiftShader renderer; disposal/reopen repeated five times without increasing retained geometries/listeners.

A source-native-versus-decoded vertex equality test establishes conversion fidelity; a rendered landmark check establishes correct rendering of that reference. Neither establishes patient registration, completeness, organ function, physical equivalence or clinical qualification. The initial Atlas is not accepted if only its charts/fallback work or if it still shows the rejected independently positioned organ montage.

## 9. Ownership, delivery order and review gates

| Lane | Modules/files | Dependency and boundary |
|---|---|---|
| A: source/cache maker (UI audit after approval) | New `anatomy/atlas_reference.py`, packaged source declaration, dedicated source/cache tests | Written packet approval first; no changes to old meshes.py without root coordination |
| B: route/distribution owner (root) | `aegle/server.py`, package-data configuration, installed/cache-isolation tests | Agreed callable/error/schema contract; can write red route tests alongside A, never duplicate installer logic |
| C: scene/UI maker | New `console/lib/atlas_reference_scene.js`, narrow request helper, workspace mount/CSS and dedicated UI tests | Source output contract approved; workspace.js currently shared/root-owned—explicit handoff before editing |
| D: independent source/render reviewer | Read-only code/decoded-source review, real-browser harness/run and evidence review | Must not grade their own maker lane; package stable/checkpoint and real runtime identity before acceptance |

Launch A and root's red route tests in parallel. Independently review the converter/cache and actual decoded real outputs before admitting them through B. Write scene unit tests against explicitly technical fixtures, then C integrates only the admitted source; D grades actual rendered behavior. Dedicated browser harness is added only after selectors/contract settle and root approves its mutating install/cleanup boundary. No service restart or operational data mutation by this lane without separate root coordination.

Package-data, optional converter dependency compatibility and installed-wheel tests are part of this packet, not post-release chores. Root chooses any dependency pin only after verifying the current installed exporter and old anatomy behavior; no global pip change. Public release is still blocked on the broader agreed requirement/rights/review gates, not enabled by a source cache installer.

## 10. Not implemented here; explicitly retained obligations

- Full Atlas native execution/run/member/source-selection controller (Gate B) and cross-scale spatial dynamics (Gate C): remain required follow-on packets; initial reference geometry cannot close them.
- Skeletal/muscle/systemic artery/vein expansion, missing body systems, female/other reference geometry and patient-scan registration: require exact source/frame/coverage review. The initial nine groups are not the entire human anatomy.
- Actual molecular/cellular coordinates, tissue mechanics, blood flow and spatial chemical concentration: require separately executed typed spatial outputs, not a UI-scale transform.
- Physical LIFE anchors/placement/hardware and Cendos measurement validation: no coordinates or biological response are invented for absent inputs.
- Fifth retained video reference mapping, six full experiment videos, complete A+B controls and all-page visual acceptance: retained in the master inventory; this geometry packet is not a substitute.
- Public geometry redistribution/exports: current BY4 basis accepted internally with historical notices preserved; final release-owner decision and complete obligations remain necessary.

No new scope is removed or called done. There is no separate `TODOS.md` in this checkout; the R register, all-page inventory and these explicit follow-on gates remain the authoritative backlog, rather than an unreviewed list of deferred requirements.

## Engineering review handoff

Architecture: one bounded source/cache module and one scene module, no new service; root-transform and once-only application are explicit. Code quality: reuse existing exporter/vendor/security patterns, no arbitrary ingestion or physiology coupling. Tests: all new branches and preserved regressions mapped above; none is claimed implemented. Performance: actual source/attribute budgets known, conversion/GLB/rendering measures still required. Failure modes have named rejection and visible recovery paths; no silent fallback is acceptable.

Independent reviewer should challenge cache path races/publication, source and converter authority, matrix/float32 round-trip tests, GLB semantic admission, cold-install request lifecycle, transparency/picking/performance and the A+B mount boundary before root authorizes code. There is no independent implementation or rendered clearance in this document.

### Independent pre-code review amendments

The release reviewer read the prior 313-line packet at SHA `8d793d902cb6a4d0c47b7b0430e2c900e50e7df4f080c965adcaadb71df5752c`. They found the 489-element identity, common root matrix, source-preserving conversion and reference-only staged rendering coherent, and requested three explicit safety refinements: parent-directory fsync ordering, exact HTTPS redirect authority/deadline, and converter parent-death/lock lifetime. Root approved incorporating those refinements. They are specified above with additional fault/subprocess tests; independent recheck and root's bounded implementation ownership approval are still pending. No source geometry or the three documented source-degenerate triangles were changed.

## Operational lesson

### Root implementation authorization

Root read this complete packet and its three amendments. The independent
reviewer rechecked the amended packet at SHA
`5c9151b290a5213620c2a656e3cba82d9b6d5da7c027fcf58f60e2c5d6cc51c7`
and found no remaining material pre-code blocker. Source/cache lane A and root's
route/distribution lane B are approved for red-first implementation. Lane A owns
only its new Atlas source/cache modules, packaged declaration and dedicated tests.
Do not edit inherited meshes, workspace, existing services or run acquisition
until source code review and the actual-source execution checkpoint. Root owns
server routes and package configuration. Rendering lane C requires a subsequent
explicit workspace ownership handoff, not a new product-scope decision.

The proposed three HTTP paths are accepted. Status remains metadata-only and
network-free; installation uses existing mutation authorization and strict body
admission. Internal immutable asset reads require the existing local/operator
authorization and private/no-store headers; no public publication is authorized.
No raw source archive or generated geometry enters the repository/wheel. Preserve
all other product work and the remaining full-scope obligations.

### Lane C implementation mapping authorized by root

After reading the frozen source/cache packet, root approved red-first scene/UI
implementation while independent source review proceeds. Actual publisher
acquisition remains separately gated. UI-owned additions are a dedicated scene,
manifest/request/controller/dependency helper, small Atlas stylesheet and narrow
`workspace.html`/`workspace.js` mount wiring plus dedicated tests. Existing source
modules remain frozen; server, service and onboarding changes stay root-owned.

The mount replaces only the existing schematic SVG inside `#body-scene`. Keep
the approved A+B header, left multiscale path, focus card, biological time,
response plots, research controls, source/evidence drawers and all other pages.
The old `renderLivingBody()` scalar-to-opacity mapping is removed; a separate
readout may show the selected recorded quantity, but it cannot tint or transform
source geometry. The geometry controller does not submit biological actions.

Import the existing pinned `anatomy_vendor.js` directly with bounded WebGL/dependency
loading; `loadAnatomyDependencies()` currently also imports the legacy dispersed
explorer and must not be reused unchanged. The new renderer must not call
`normalize()`, use `SPREAD`, invent source coordinates or rely on an illustrative
fallback. It creates one identity assembly containing the nine source GLB roots.

Source binding must use `gltf.parser.associations.get(object).nodes` against the
decoded manifest's exact node index. The inspected Three 0.160 GLTFLoader
sanitizes `:` from runtime `node.name`; original node names are retained in
`userData.name`. Do not assume `getObjectByName('bp3d:FJ…')` finds the source node.
Verify the original name, source element/hash and source mesh/node association.

The request helper accepts only exact fixed manifest/hash/key routes, enforces
bounded same-origin bytes and content SHA, and cancels owned work on source change
or disposal. Explicit installation has one 900-second request bound plus separate
read-only readiness polling; response loss never triggers another POST. Status,
source install and graphics errors remain local to the Atlas reference panel.

Skin is drawn first, then at most two internal partitions load concurrently.
Default view remains the whole person with all groups, labels off, section off,
no isolation and appearance-only transparent skin. Home, group toggles, source
search/selection, frame-selection, anatomical-axis clip/depth, labels, isolation,
source details and Retry must alter the actual renderer and agree with controls.
Same-manifest Retry preserves view state; a changed manifest clears incompatible
selection. Only user interaction/rendered loading/resize triggers graphics work;
hidden or disposed views do not keep an idle loop.

The existing `atlasInspectionLink()` carries the current coherent numerical
context to Biology. This packet does not fabricate run/member/native execution
bindings or fill missing molecular/cellular geometry. Full source-native Atlas
context and spatial outputs remain required follow-on gates, not dropped work.
Independent current-build browser acceptance follows section 8 after real source
admission. Technical fixture tests cannot replace it.

An accepted common-coordinate source does not mean the old organ renderer can assemble it. The old renderer deliberately applies per-organ normalization and spread; retaining authentic mesh bytes does not preserve anatomical arrangement. Conversely, storing native millimeter positions under identity GLB nodes without an explicit root conversion would create a unit-contract defect. Keep source coordinates and IDs, encode the same meter/Y-up scene transform exactly once in each standard GLB, and leave the renderer assembly identity. Verify through decoded matrices/accessors and then actual rendered landmarks; neither phase can replace the other.
