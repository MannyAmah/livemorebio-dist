# Confirmed research-preview publication — implementation receipt

This is a narrow maker receipt, not independent acceptance or full-product
validation. It continues R01–R51 in the full-scope recovery plan. Existing
experiments, operational stores and installed services are preserved. The six
specified programs and their recordings remain required; recordings completed:0/6.

## Approved scope and frozen source

The complete written confirmed-preview publication plan, its independent
pre-code corrections and the new test author's RED inventory preceded code.
Plan SHA256: `4d4aae3d965559df395e4f356680d981326a9cf08d0e670e8d68875ba14493d3`.

Root changed only `livemorebio/aegle/server.py` for this packet, adding a private
shared publisher and routing the existing base/LIFE/note replacements through it.
Server SHA256: `ca5113ee9725923f91201bf4765b1c1822fd289aaba0be98355d24325a69764a`.
The original nonreplacement numerical dispatch, registry, execution manager,
clinical equations, console and SDK are not changed by this packet.

The new 67-case test module was written by a different agent before root's code.
`test_confirmed_preview_publication.py` SHA256:
`c610ce3bd603c640d28e6f9c028e3488fa75c85bb52cd5451f9784ed92bcbab7`.
Root read all576 lines before implementation. Original15 preview and two
retirement tests are unchanged.

## Implemented behavior

- Authenticate and validate the pure request before registry/factory access.
  Keep base aliases, LIFE modes/defaults/custom arguments and local note extraction.
- Prepare the audited selected-pointer clear under source authority, requiring
  four-field selected-record agreement or explicit absence. Build the candidate,
  copy its state and serialize its own complete response outside authority locks.
  A READY preview requires its own parameter dictionary; null, malformed or
  nonfinite output cannot reach the durable commit.
- Recheck the original generation and selected record in the existing commit
  guard. Commit the actual prepared transition exactly once. Only a confirmed
  durable clear installs the complete new preview state and empty action history.
  An uncertain durable outcome installs DENY_ALL while retaining the previous
  inspectable state; it does not publish a speculative preview or retry storage.
- Invalidate the captured old execution generation and retire old holders outside
  both guards. Preserve the distinction between committed cleanup uncertainty
  and an unknown durable commit. Publish this operation's detached snapshot,
  never a later winner's parameters. Keep the allocated operation UUID and
  no-store headers on local conflict, uncertainty and failure responses.

These are source-consistency guarantees under the exercised technical fixtures,
not a claim that a research preview is a registered human or validated biology.

## Red-before-green evidence

Before root's implementation, the new67 cases returned64 failed/3 passed in1.88s
(`nw2ewnpn`, maker); the3 passing cases were existing auth denials. Root separately
reproduced16 failed/1 passed in1.70s (`ipkc6qu9`) across the original15 previews
and two retirement tests. Those failed baselines remain recorded in the plan.

The following final-source root runs all exited0. Private roots share prefix
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-`.

| Packet | Result | Private suffix |
| --- | --- | --- |
| New67 + retained15 preview + retirement2 | 84 passed,1.99s | `0uq6zhix` |
| Startup34 + closed publication26 + snapshot9 + actual registry10 | 79 passed,1.85s | `dhjv2xhd` |
| Confirmed binding35 + actual registry binding13 | 48 passed,1.76s | `vaub8mo0` |
| Selected activation preservation | 31 passed,41 deselected,1.49s | `gb1bv2hy` |
| Existing binding preservation | 29 passed,25 deselected,1.48s | `9_sp_4hn` |

Each used the existing private45-second ASGI-compatible refusal wrapper: no
network/DNS/listening/child/native model work, no background execution workers,
pytest auto-plugins/cache and bytecode disabled, actual internal socketpair
permitted. Each recorded unexpected I/O0 and exactly one deliberately refused
optional Git metadata query. Each had the same3 existing FastAPI/Starlette
deprecation warnings. Deselected tests were not run or counted as passes.
`git diff --check` passed. These distinct packets overlap; do not sum them as
unique full-product coverage.

## Remaining review and integration gates

Independent implementation review and independent84-case repetition are pending.
The runtime is frozen for that review. Actual registry→preview integration has a
separate test-plan lane; the new67 use real authority/commit guards and inert
registry/factories, not a real encrypted registry. Actual binding13 and startup10
are preservation checks of their own previously reviewed boundaries.

Legacy UI and attached SDK recovery remain open: a POST acknowledgment must not
be mistaken for current selection, a late callback must not repaint a previous
person, and a failed response must not be summarized as a healthy twin. Their
written client plan requires independent pre-code review before edits. Observation
selection and reconciliation still need the committed-publication migration.

The actual once-only Atlas skin diagnostic remains FAILED; neither these unit
tests nor its separately confirmed process exit retroactively accept that run.
No new browser/native probe, six-program experiment, physical device validation,
production qualification, commit, push, PR or installed-pointer change occurred.

## Durable lesson

A completed request, confirmed durable selection, current display and resource
cleanup are four separate facts. Prepare and serialize candidate output before
commit; publish only its own captured result; invalidate numerical authority on
uncertainty while preserving inspectable evidence and old resource ownership.
Consumer recovery must keep those distinctions rather than filling missing state
with a plausible-looking default.

## Independent implementation review, initial frozen candidate

The independent reviewer read the complete amended plan, all three actual
replacement branches and shared publisher, the selected-record/source/fence and
snapshot consumers, the registry preparation/commit exception paths, all576 new
test lines and both retained test modules. The review skill/checklist informed
the race, conditional-side-effect and consumer checks. No source or test was
edited, and no service, browser, operational registry or native model was used.

The exact approved84-case repeat passed independently: **84 passed,3 existing
warnings in1.82s**, exit0, private suffix `3uyxn7se` under the prefix above.
The45-second ASGI refusal wrapper was copied from the linked actual-binding
integration report, changing only the selected files to the new67, retained15
and retirement2. Unexpected network/child/model attempts0; one exact optional Git
metadata lookup refused. Internal TestClient socketpair remained permitted.
No additional test scope or standalone fault probe was executed.

The server and new-test hashes matched the frozen values above before and after
the repeat. Retained test hashes were also recorded:

- `test_committed_preview_transitions.py`:
  `618a21c2b119c1764d9259c0fbdba183f6cc3075a3f147f0839decc96cb4ebb5`.
- `test_source_retirement_lock_boundary.py`:
  `cc39635b694350e2e695e6046fe68103d3e386c2ef7af16ab36904ba556e331f`.

**One P2 remains in this initial candidate (source-proven, confidence10/10):**
`prepare_preview_clear` can propagate
`SubjectRegistryError("SELECTION_COMMIT_UNCONFIRMED")` when
`_selection_read_access` cannot confirm its rollback (`subjects.py:1470`). The
preview publisher's outer error adapter at `server.py:1549–1554` only maps the
storage/audit-unavailable codes to503. This uncertainty therefore falls through
`_subject_error` to422, contrary to the approved preparation-uncertainty503
contract. The existing capture-DENY cases use `SourceSelectionUnconfirmed`, a
different exception class, so the84 passes do not cover this actual producer
path. The intended narrow correction is to map the fixed registry uncertainty
code to503 with the same UUID/no-store and add a preparation-error regression.
Preserve the original holders/generation and no invalidation: no clinical clear
was attempted on this preparation failure.

No other actionable issue was found in the bounded publisher review. Candidate
serialization precedes commit; confirmed outcomes publish complete new holders;
uncertain clear outcomes install denial without a speculative preview; retained
objects and captured-generation cleanup occur outside the guards; a later winner
cannot supply this operation's parameters. Those observations and the84-case
repeat do not clear the remaining P2, actual encrypted-registry-to-preview
integration, legacy client recovery or real UI/terminal acceptance. This entry
retains the initial candidate and is not superseded by any later correction.

## Root P2 correction receipt — independent re-review pending

The written plan now includes the reviewer-found preparation rollback uncertainty
before correction. Root added the exact registry exception mode and three route
cases to the new test module, without changing the retained17 tests. An initial
test invocation (`afiobqfd`,3 failed/67 deselected,1.50s) incorrectly passed the
client rather than the fixture to the existing request helper; it is a harness
failure, not the product RED. After that correction, `38odb02a` reproduced the
actual **3 failures/67 deselected in1.62s**, all422 versus required503.

The first attempted one-line runtime edit matched the analogous activation error
adapter, not preview. The87-case run `dglfuk99` remained **3 failed/84 passed
in1.76s**. Root immediately restored that activation edit and applied the change
under unique preview context. No operation/service ran on either interim source.
These failures are retained, not presented as successful validations.

The final correction only adds SELECTION_COMMIT_UNCONFIRMED to the preview outer
503 set. Final server SHA256:
`3fd852c3737406b7173cab1ed915b66bbd28d3cc3def2c8a75a3c84e8e775017`.
New70-case module SHA256:
`acc8085de2041d04f6c1665e5b87c2f752f1ecfbfb092da0393ad8057c0e378e`.
Root's complete70+15+2 packet now returns **87 passed in1.83s**, exit0,
private suffix `njvlcgv8`. All attempts used the same45-second no-I/O wrapper,
unexpected I/O0/refused Git1 and the same3 existing warnings. Diff check passes.
Preparation failure preserves the exact previous generation/state/actions and
calls no candidate, commit, cleanup or snapshot. Actual commit uncertainty still
installs DENY_ALL. Independent re-review/repetition remains required.

Source inspection also found analogous outer adapters on activation and binding;
their preparation exception status needs a separate explicit regression/correction
packet. Their current source is preserved rather than silently broadening this
preview patch. This is retained required work, not acceptance of those error paths.

## Independent P2 correction re-review

The independent reviewer read the appended pre-code amendment, complete correction
receipt, actual preview mapping and new preparation exception/three-route test.
Final frozen hashes verified:

- Server: `3fd852c3737406b7173cab1ed915b66bbd28d3cc3def2c8a75a3c84e8e775017`.
- New70 tests: `acc8085de2041d04f6c1665e5b87c2f752f1ecfbfb092da0393ad8057c0e378e`.

A read-only in-memory reversal of the single preview mapping change reproduced
the exact prior server hash `ca5113ee…`; no other runtime delta remains, including
the interim activation edit. Removing only the new fixture exception branch and
parameterized regression in memory reproduced the exact original new67-test hash
`c610ce3b…`. No file was rewritten by either comparison.

The independently repeated **87 tests passed,3 existing warnings in1.77s**, exit0,
private suffix `d8e_ipv5`. The exact prior45-second ASGI-compatible wrapper selected
only70+15+2, with no unexpected network/child/model attempts and one refused
optional Git metadata lookup. No service, browser, operational store, real model
or extra test packet ran. The three new cases raise the actual `_transition_error`
result from preparation and assert503, the same UUID/no-store, exact previous
holders/generation and no factory, commit, invalidation or publication. Existing
unknown-clear tests retain their distinct DENY_ALL requirement.

**The identified preview P2 is closed; this bounded server implementation and
87-case technical packet are independently CLEAR.** The original failed candidate,
RED results and authoring mistakes remain attributable above. The analogous
activation/binding mapping omission is separate required work, not cleared by
this result. Actual encrypted-registry-to-preview integration, legacy client
recovery and real UI/terminal acceptance remain open, along with the full product,
scientific-program and retained Atlas diagnostic gates.
