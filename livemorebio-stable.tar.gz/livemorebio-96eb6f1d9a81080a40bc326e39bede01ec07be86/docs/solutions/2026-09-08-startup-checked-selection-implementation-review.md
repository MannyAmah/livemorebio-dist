# Checked startup selection: registry implementation review packet

2026-09-08. Maker: `source_research`. **Frozen for independent review**, not
self-graded startup or product acceptance. No server, UI, model, physical-v3,
scientific input/output, operational database or key was changed or accessed.

## Approved boundary and exact files

Read the complete latest
[checked-startup proposal](2026-09-08-startup-checked-selection-interface-proposal.md)
and its root/independent refinements, the fixed audit-phase primitives and all135
retained checked-reader RED/default cases. Root released this implementation only
after independent audit-phase and stored-MAX clearance. No deviation requiring
a new transaction or audit schema was needed.

| File | Final SHA256 |
|---|---|
| `livemorebio/aegle/subjects.py` | `0a8eaee99b653a1b1823a1434c2e5ff1a2d468dc9659677cb426b33f6389b465` |
| `livemorebio/tests/test_checked_startup_selection.py` | `48548487d52c3ac0584df3324c851828bf7b998a50a1178e940dc2dd00dcf371` |
| Unchanged `livemorebio/aegle/registry_audit.py` | `b21f01fdf1c79604c5565fee0f7d94d3b0bd11967b199bc97ec8a193de045e4e` |
| Unchanged `livemorebio/tests/test_committed_registry_transitions.py` | `1985dc98faa36b6ac7914e921cc817cd9afd50cd2526c456d502f621c53e9e03` |

The prior independently cleared subjects SHA was
`0867674f1693c02b0dd3f1797467f7682329504da330ccc61ac45d4eba7f6653`.
This increment adds `CheckedActiveSelection`, `_validate_checked_selection`,
`_checked_selection_access` and the two explicit internal keyword branches.
The original484 test lines retain exact SHA256
`ed9c94102e1f9de0827f9dd44deaad23882532d3091d7c1df172a091d2e6dfc6`;
one additive strict-scalar regression follows them. No prior assertion changed.

## Implemented semantics

- `audited_active_twin(..., _checked_snapshot=True)` requires the exact bool,
  action `inspect` and explicit canonical request UUID. False/default uses the
  original unchecked return shape and implementation.
- `confirm_active_selection(..., _expected_snapshot=capture)` canonicalizes the
  caller's expected record before I/O and validates exact private type, immutable
  rows/bytes, scalar types, zero/one topology, store, capture UUID and plaintext
  index/content coherence. No saved ciphertext is decrypted during this check.
- The fixed helper reuses `_selection_read_access` with no target/device scope.
  Its durable BEGIN, exact reservation re-entry, fresh live raw baseline,
  last-write terminal checks, failed-access completion, commit and close behavior
  are unchanged. Actual current protected content is authenticated at most once
  via `_transition_snapshot(connection, None, None)` after the durable BEGIN.
- A changed authority token rejects before that protected decrypt. Exact row
  bytes/all11 SQL columns, pointer including timestamp, active topology and
  canonical current content must match the capture. Request IDs intentionally
  need not match: distinct accesses may use a fresh UUID or the same completed
  workflow UUID, but retain separate BEGIN/RESULT identities and reservations.
- The immutable capture is constructed/validated inside the read body and
  returned only after the fixed owner's terminal commit and close. True absence
  requires no pointer and no ACTIVE row. Malformed storage never becomes absence
  or a model-unavailable reason. Stored MAX remains readable without increment.

Only normal metadata-only audit rows/reservations are written. TWIN/cohort
ciphertext, original AAD, clinical versions, pointers/timestamps, physical and
subject indexes, bootstrap authority and numerical eligibility are unchanged.
The saved capture is not an HTTP authorization token or mutable client binding.

## Red/green and preservation evidence

The prior test-only packet ran before implementation:133 checked-interface
failures and2 preserved default cases. Its private executing root was
`livemore-research-review-iebucr73`; the exact elapsed summary was not retained,
so no duration is asserted. An earlier collection-only reserved-parameter-name
error was corrected before that RED run and is not runtime evidence.

First implementation: **135passed in4.26s**, private `...-zdtaw2vs`.
A self-review strict topology string-subclass case was then authored; its invalid
scalar reached the forbidden connection tripwire: **1failed in1.03s**, `...-7f5sqy7q`.
Adding the exact scalar-type guard fixed it. Expanded preservation then passed
616 cases in26.01s (`...-onquwc7j`). The final source additionally checks the
zero/one topology tuple length before inspecting its elements; this preserves
the same rejection semantics and makes the field validation explicitly bounded.

**Final exact source:616passed,4 explicitly deselected,1 existing framework
deprecation warning in26.56s.** This includes all136 new checked-reader cases and
the same480-case independently cleared prerequisite/preservation selection.
Every run recorded zero unexpected network/process attempts and one exact
optional Git metadata lookup refused into its existing fallback. All test
processes completed; no native/model/solver/browser/service process was started.

Final private fixture root:
`/private/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-research-review-bo8ydol6`.
The four excluded `real_process` bootstrap cases require separate explicit process
authority; they are not omitted silently or reported as freshly passed here.

Exact expanded command, from the full-scope-recovery worktree:

```sh
/Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B - <<'PY'
import os, sys, signal, socket, subprocess, urllib.request, multiprocessing.process
from tools.run_review_stack import prepare_review_environment
root, env = prepare_review_environment(inherited={k: os.environ[k] for k in
    ('PATH', 'HOME', 'TMPDIR', 'LANG', 'LC_ALL') if k in os.environ})
os.environ.clear(); os.environ.update(env)
os.environ.update(PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
blocked = []; metadata = []
def deny(*a, **k):
    blocked.append('unexpected')
    raise AssertionError('Checked reader review forbids network/child/native work')
def process(command, *a, **k):
    if command == ['git', '-C', '/Users/emman/Livemore/.worktrees/full-scope-recovery',
                   'rev-parse', '--show-toplevel']:
        metadata.append('refused'); raise OSError('Authored unavailable Git metadata')
    return deny()
def audit(event, args):
    if event in {'os.fork', 'os.forkpty', 'os.posix_spawn', 'os.exec',
                 'subprocess.Popen', 'socket.__new__', 'socket.connect', 'socket.getaddrinfo'}:
        deny()
sys.addaudithook(audit); multiprocessing.process.BaseProcess.start = deny
socket.socket.connect = deny; socket.getaddrinfo = deny; socket.create_connection = deny
urllib.request.urlopen = deny; urllib.request.OpenerDirector.open = deny
subprocess.Popen = process
import pytest
signal.alarm(60); print('PRIVATE_REVIEW_ROOT', root, flush=True)
files = ['test_checked_startup_selection.py', 'test_committed_registry_transitions.py',
         'test_subject_registry_audit_contract.py', 'test_registry_bootstrap_contract.py',
         'test_registry_bootstrap_shape.py', 'test_clinical_descriptive_registry.py',
         'test_real_cohort_contract.py', 'test_selection_reconciliation_registry.py']
nodes = ['test_virtual_patch_binding_retains_admitted_protocol_version',
         'test_only_authoritative_twin_remains_active',
         'test_physical_patch_pairing_requires_active_consented_human_and_attestation',
         'test_active_twin_survives_registry_restart_and_physical_device_cannot_double_pair']
rc = pytest.main(['-q', '-p', 'no:cacheprovider', '-p',
    'livemorebio.tests.test_committed_registry_transitions',
    *[f'livemorebio/tests/{f}' for f in files],
    *[f'livemorebio/tests/test_subject_lifecycle.py::{n}' for n in nodes],
    '-k', 'not real_process', '--tb=short'])
print('REVIEW_IO_COUNTS', len(blocked), len(metadata), flush=True)
signal.alarm(0); raise SystemExit(rc)
PY
```

## Remaining gate and lesson

Independent code/test review is next. Root owns server startup publication and
its separate frozen RED packet; no server implementation, browser QA, public
availability, old unchecked-family repair or whole-product acceptance follows
from these unit/integration fixtures. Cross-process memory/storage atomicity is
not claimed after the read transaction releases its writer lock.

The lesson is to validate a saved snapshot's metadata without decrypting its
clinical ciphertext before durable access admission. Exact current-row evidence
and the common last-write audit owner then supply the checked boundary; matching
versions, a frozen dataclass or a successful earlier read alone cannot do so.

## Independent registry-only review — ui_audit

Independently read the complete approved checked-startup proposal and refinements,
this146-line maker report, all136 checked-reader cases, the new private type and
both checked branches, and their actual snapshot/phase-owner/audit consumers.
The four frozen file hashes above matched before and after review. The retained
first484 test lines independently hashed to `ed9c94102e1f9de0827f9dd44deaad23882532d3091d7c1df172a091d2e6dfc6`.
No runtime or test file was edited. The separate incomplete Atlas maker packet
was paused before this independent review and was not exercised.

The exact listed616-case selection was independently repeated with
`/tmp/livemore-fresh-venv.lSTVr3/.venv/bin/python -B` (Python3.11.15), the report's
fresh `prepare_review_environment` setup and registry-only plugin. Result:
**616passed,4 explicitly deselected,1 existing framework warning in26.50s**.
Private root ended `livemore-research-review-y8t4ldto`; tool session75143 exited0.
The outer socket-creation/connect/DNS, both urllib entrypoint, low-level process
and multiprocessing refusals recorded **zero unexpected I/O/process attempts**;
the one exact optional Git metadata lookup was refused into its existing fallback.
No child, browser, service, native model, HTTP endpoint or operational store was
used. The four `real_process` cases remain separately authorized obligations,
not newly passed evidence.

No actionable blocker was found in this bounded checked-reader increment:

- Capture/confirmation validate their private mode, UUID and immutable metadata
  before acquiring the checked access. Saved ciphertext is never decrypted to
  validate a capture; the exact current row is authenticated only after durable
  BEGIN and verified reservation re-entry.
- Confirmation compares the actual authority token, complete11-column raw row,
  canonical content, pointer including its timestamp and exact zero/one ACTIVE
  topology. Same-version re-encryption/content changes and adoption reject. True
  absence is checked rather than inferred from a missing pointer alone.
- The returned object is held until the shared last-write audit/raw checks,
  terminal commit and close have all completed. The matrix retains real SQLite
  trigger, lost-ACK, uncertain-rollback, failure-completion and close cases;
  ACCESS_FAILED uses the new live baseline after rollback, not the former subject.
- Stored MAX remains readable without increment, and original false/default
  method behavior and return shapes remain intact. Structural reading adds no
  model/profile construction or clinical-binding admission.

This clears only the named private registry read interface on these hashes.
Server startup generation/publication/retirement, closed-manager fencing, the
unchecked audit families and broader product/browser acceptance are not graded
by this result. The ordinary final checked-read commit still does not claim
cross-process atomicity between subsequent SQLite changes and in-memory state.
