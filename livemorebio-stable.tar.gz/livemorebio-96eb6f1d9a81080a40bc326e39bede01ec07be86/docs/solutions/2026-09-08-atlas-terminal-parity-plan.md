# Atlas reference assets: terminal and notebook parity

Date:2026-09-08. Parent R12/R21/R43/R45. Pre-code plan, not a new scientific
program or permission to acquire publisher assets before the source/cache gate.

## User outcome and decision

The new Atlas must be operable from the attached terminal and notebooks as well
as its browser controls. The existing `python -m ...atlas_reference` command
acts directly on local cache configuration. It does not establish parity with
the selected running Aegle service. Provide attached status and explicit fixed
source install through the same API; keep the local maintenance entry intact.

Do not add an asset-upload API, a general download command, background acquisition
on startup, a second source catalog, physiological execution or public geometry
export. Status and install do not claim patient registration or biological function.

Alternatives: reuse the broad SDK `_get/_post` helpers (shortest, but these follow
redirects and read unbounded responses); repurpose continuous-execution errors
(would conflate anatomy with physiological execution); or add a narrow fixed-path
Atlas transport. Select the narrow transport, reusing existing auth, URL selection,
strict JSON parser, attached SDK/CLI/REPL conventions. Do not refactor all HTTP
clients during this patch.

## Exact interface and ownership

- `Platform(mode="attach").atlas_reference_status()` issues one GET to
  `/api/anatomy/atlas-reference` on that Platform's configured Aegle service.
- `Platform(mode="attach").install_atlas_reference(source_id)` validates the one
  fixed source ID and issues one POST to `/api/anatomy/atlas-reference/install`
  with exactly `{"source_id": ...}`. No generated IDs or implicit retry.
- Direct CLI and attached shell/pipeline share `atlas status [json=true]` and
  `atlas install bp3d-4.0-20130619-surface-core-v1 [json=true]`. Default output is
  concise source/state/manifest/receipt metadata, explicitly reference-only.
  Full bounded manifest JSON requires `json=true`; no binary export in this packet.
- Unknown verbs, extra/duplicate options, malformed quoting and nonexact IDs
  reject before HTTP or native model construction on the new command path.
  The new SDK methods reject in-process mode without additional construction;
  the existing `Platform(mode="inprocess")` constructor already calls `patient()`
  and is not changed by this packet. Direct CLI constructs `Platform(mode="attach")`;
  it never silently starts servers.
- Root owns new `atlas_client.py`/`atlas_commands.py`, narrow SDK mixin, CLI early
  dispatch/help and shell early dispatch/help/error handling. UI owner continues
  source/cache/guardian/renderer; no overlapping source modules are changed.

## Transport, state and errors

Use existing protected operator auth without printing it. Validate destination:
HTTPS or loopback HTTP only, no credentials/query/fragment in base URL; disable
proxies and redirects. Fixed path and payload only. Reject nonidentity response
encoding, malformed/duplicate/nonfinite JSON and response bytes beyond2MiB.
Read timeout20s for status,900s for install; this is a client socket wait, not a
claim of total server execution time. Server owns its phase deadlines and lock.

One safe typed error vocabulary covers input/attach/auth/transport/response errors
and the server's fixed Atlas error categories. Never echo upstream text, URLs,
paths, raw exceptions or credentials. Timeout/disconnect/malformed success after
POST is explicitly unconfirmed: inspect status, do not automatically repeat.
This also covers oversized, invalid-schema and unknown-error responses after
dispatch, including malformed non-2xx responses. Only allowlisted determinate
server errors retain a more specific safe category.
An already-acquiring response reports busy. An unconfirmed publication reports
its safe server category and requires status inspection. CLI returns nonzero;
the pipeline stops, the interactive shell remains usable. Closing a response
cannot erase a confirmed response or replace the original error.

Validate status schema/source/fixed allowed states, boolean availability and
reference-only/patient_registered=false on every successful response. Available
requires a64hex manifest digest, matching source/schema in manifest and no
patient-registration upgrade. Install additionally requires a receipt matching
source/digest plus boolean reused. An installation HTTP200 must specifically
have `state="available"`, `available is True` and the complete typed receipt;
missing, acquiring or corrupt states cannot confirm installation. Do not accept
an HTTP200 as sufficient evidence.
Full geometry/source-array admission remains the server's job, not a second
numerical verifier inside the client.

## Red-first and acceptance

1. Recorded technical HTTP fixtures prove exact method/path/body/auth selection,
   no redirects/proxy forwarding, bounded parsing, failure categories and once-only
   POST semantics. Malformed/numeric-alias/foreign-source successes reject;
   duplicate/foreign/typed-alias receipts and close-failure cases are explicit
   regressions.
2. CLI, shell, pipeline and SDK invoke identical methods with no local model or
   direct cache access. Unknown/malformed input emits safe nonzero errors. An
   unconfirmed install stops a pipeline; the next command is not executed.
3. Repeat existing continuous/subject/CLI/SDK tests to preserve all prior behavior.
4. Actual HTTP attached status against the owned fresh8910 stack, exact build
   identity retained, must agree with the browser's status. Actual install is
   held until separate source/cache/guardian approval, then verify installed
   status agreement and a reused installation without another acquisition.
5. Independent code/tests and actual transport evidence before acceptance.
   Update the candidate guide only after commands have been exercised; do not
   claim the older published installer already contains uncommitted commands.

No new third-party dependency is needed. Context7 was unavailable; the existing
reviewed standard-library transport and primary Python documentation remain the
fallback. All tests use isolated technical stores, never real participant data.

## Independent pre-code review

The independent reviewer approved the narrow architecture, conditional on the
three response-confirmation, mutation-uncertainty and legacy-construction
clarifications above. They are incorporated before writing implementation.

## Candidate implementation evidence (not final acceptance)

The reviewer subsequently read the revised plan and explicitly cleared it.
Primary Python 3.11 `urllib.request` documentation was read through the private
gstack browser before implementation: timeout covers blocking operations rather
than total wall time, `ProxyHandler({})` disables inherited proxies, and the
redirect hook is explicitly overridden. No new third-party dependency was added.

- Technical client tests: 95 missing-implementation failures, then 95 passed.
- CLI/REPL/pipeline tests: 23 failures before implementation, then all passed.
- Combined Atlas plus existing continuous command/client preservation: 204 passed.
- Expanded preservation including model-workflow and control-revision clients:
  **304 passed in 0.42 s**, using isolated test stores. No native source solve,
  geometry download, active participant change or hardware command was requested.
- Outside-checkout wheel smoke now includes the new process helper, client and
  commands, attached construction without a twin, and missing-status checks
  without network/cache creation. Its result is recorded separately after running.

The expanded outside-checkout wheel smoke subsequently **passed (1 test, 1.91 s)**.
It does not admit publisher geometry or resolve the separate cardiac CellML
distribution/licensing gap.

Implementation is submitted for independent review. Actual HTTP status/install,
renderer agreement, exact restarted build identity and guide acceptance remain
open. No published installer or release claim has been changed.

Durable lesson: a failed or unreadable response to a one-shot installation can
be uncertainty about an already completed write, not proof that no write
occurred. Preserve that distinction for malformed non-2xx responses as well as
successful HTTP statuses. Validate reference identity and the complete receipt
before reporting installation, and do not erase a valid receipt if closing the
connection or displaying output fails.

## Actual HTTP attempt 1: missing build headers; correction before recheck

The owned 8910–8912 review stack was restarted only after the UI owner held
source writes. Source `de4f5c5bb0f393bf1a1f45a4cfddc975e7e8524d5dd76f7e5b8b9f36ea9ef352`;
Aegle instance `cc9d1ed9-7735-4814-9967-7f7b6975ca73`, startup
`2026-09-08T14:30:07.533486+00:00`. All three health identities matched the
checkout. Actual SDK status was correct `missing`, but its response metadata
was empty. The harness failed at the required source-header assertion. No
install, source acquisition or model experiment occurred. Preserve this failure;
unit mocks supplied headers that the actual Atlas routes did not yet supply.

Pre-code correction: replace the fixed Atlas private-header dictionary with a
small response-header helper retaining `private, no-store` and adding the
immutable startup source SHA (when available) and process instance from the
existing `build_identity()`. Apply to Atlas status, install, asset success and
normalized route errors; no global middleware/auth modification. Upstream auth
middleware may still reject before a route and does not acquire a new header
guarantee. Do not fabricate a request ID or recompute identity from edited files.

Add failing actual route tests for status/install/asset/normalized failure
headers. Preserve all current Atlas cache/privacy/authorization tests. Require
independent correction review, a fresh frozen-source restart and complete
SDK/CLI/shell/HTTP agreement before actual-status acceptance. The previous
failure is not a reason to weaken the header assertion.

## Actual HTTP attempt 2: attached interfaces agree

After the independently cleared header and three UI corrections, root stopped
only owned review wrapper92546 and children92557/92558/92559, verified all four
absent, then restarted the same private review directory on8910–8912. All service
health responses matched source
`c9fee6db135dfd338c2b793ac4c4f22936db3c692421f728196ecfd3693de47a`.
Aegle instance `28fbb877-f42f-49e3-8197-a00983093d8f` began
`2026-09-08T15:14:53.669204+00:00`.

Actual SDK status returned available with the exact source/process headers and
manifest `8b796d93b76079c99eac3c45cff7375130dba8681968e162b72f46d151cc030a`.
One explicit attached installation returned `reused:true`, retaining the original
receipt `083b2f038e74476ebfcef07e4a22f7c2` and original start/completion times; no
publisher reacquisition or conversion occurred. Actual standalone CLI status,
shell command dispatch and an interactive `attach` subprocess receiving
`atlas status` then `quit` all returned the same digest and exited successfully.
The driver kept the private review credentials in process environment and did
not print them. No new experiment, participant or device command was issued.

The ordinary browser's provenance panel independently showed the same manifest,
but the default gstack Chromium had no WebGL support. It correctly reported that
graphics limitation and disabled Front/Side/Back/Skin and external Home/Labels.
The retained screenshot is in
`docs/screenshots/full-scope-recovery/atlas-current/attempt-1-gstack-no-webgl/`.
Root personally inspected it. That is unavailable-state evidence, not a rendered
pass. The first manual navigation used `/workspace` and returned404; the actual
canonical `/` route returned200. No product route was added for the mistaken URL.
The installed Chrome/SwiftShader rendered reference check remains separate.

The current related SDK/CLI/API/cache regression packet passed244 tests in5.76s
with three existing framework deprecations. Independent raw interface/browser
acceptance and external installer documentation remain required before release.
