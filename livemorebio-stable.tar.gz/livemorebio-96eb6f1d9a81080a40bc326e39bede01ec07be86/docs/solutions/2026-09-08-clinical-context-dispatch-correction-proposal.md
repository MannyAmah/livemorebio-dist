# Clinical descriptions are not computational context selectors

Date: 2026-09-08. Status: **PRE-CODE PROPOSAL; independent approval required**.
Parent: [source-linked healthy/context cohorts](2026-09-08-source-linked-healthy-and-context-cohorts-plan.md),
R05/R15–R19 and the [person-intake correction](2026-09-08-person-intake-source-time-correction.md).
Only this document is written in this task. No product source, encrypted record,
runtime, model, renderer, service or scientific gate was modified.

## Confirmed cause and scope

`aegle/clinical_parameters.py:79–87` selects a preset with
`T2D if "diabetes" in condition_text else HEALTHY`. It then overlays observations
and declared parameters. This is clinical free text controlling numerical model
initialization, not merely a label problem.

An in-memory, authored technical probe called the actual `initialize_profile`
without constructing a registry, native cardiac model, API or solver:

| Technical condition text | Actual selected reference | Si | gamma |
|---|---|---:|---:|
| empty conditions | healthy-adult | 0.0005 | 0.12 |
| type 1 diabetes | type-2-diabetes | 0.00015 | 0.045 |
| diabetes insipidus | type-2-diabetes | 0.00015 | 0.045 |
| family history of diabetes | type-2-diabetes | 0.00015 | 0.045 |
| no diabetes | type-2-diabetes | 0.00015 | 0.045 |
| prediabetes | type-2-diabetes | 0.00015 | 0.045 |
| type 2 diabetes | type-2-diabetes | 0.00015 | 0.045 |
| unrelated condition | healthy-adult | 0.0005 | 0.12 |

These are fabricated strings for a software probe, not clinical records. No
biological trajectory was computed. The investigation skill's root-cause phases
were used; its implementation phase is intentionally stopped at this written
proposal. gbrain/CE/sequential-thinking were searched for but unavailable, so the
full linked plan, source inspection and durable lessons supplied prior art.

### Consumers that make a one-line replacement insufficient

- `subjects.py:126–134`: both `AdmittedHuman.metabolic_profile` and
  `parameter_provenance` invoke the selector. Provenance can therefore repeat the
  same untyped decision, rather than bind a frozen computational context.
- `subjects.py:419–423`: new non-SYNTHETIC intake compiles that provenance before
  storing a descriptive record. Merely changing the selector to throw would
  prevent descriptive admission of otherwise valid unsupported profiles.
- `subjects.py:637–667`, `883–918`: activation and reconstruction use the same
  initializer. `admitted_human` does not carry an explicit model binding or
  legacy stratum into the current initializer.
- `runtime.py:42–56`: explicit base choices already validate healthy/T2D IDs;
  the `human` branch bypasses that base guard. A caller's default `base="healthy"`
  must not become fallback authority for an unsupported supplied human.
- `runtime.py:259–264`: Reset reconstructs from the human again. It must retain
  the exact accepted context, not rediscover a preset from text or a current
  global default.
- `server.py:124–141`: restoration constructs the authoritative saved subject
  before publishing it. It already raises on failure and does not intentionally
  replace an un-restorable subject with the initial healthy preview. Preserve
  this fail-closed behavior; a future degraded read-only startup is separate work.
- `cendos/protocols.py:53–65`: frozen legacy cohort experiments bypass this
  initializer and construct seven explicit profile values plus the unchanged
  dataclass defaults. Do not route them through the new clinical admission code.
- Legacy `SyntheticHuman`, `LifeSystem.generate`, and SDK `patient`/`cohort`
  have separate compatibility semantics. They must not be mistaken for enrolled
  clinical intake or silently used to recover an unsupported REAL_HUMAN record.

## Decision: separate three contracts

1. **Descriptive intake:** source-backed demographics, conditions, medication
   history, observations, unknowns, consent and provenance. Accepting it records
   submitted evidence, not a diagnosis made by Livemore and not eligibility for
   a physiological model.
2. **Computational context:** an explicit, typed model/initialization contract
   with source/version, applicability and consumed input provenance. An operator's
   text label or choice of a disease name is not this contract.
3. **Execution:** accepts only the resolved immutable context plus its exact
   subject/reference snapshot. A valid record with no supported binding stays
   inspectable and cannot be activated into a substitute physiology.

No larger diagnosis regex, synonym dictionary, age heuristic, medication-based
inference, missing-condition-to-healthy rule or free-text exact-match dispatch.
Even the exact string `type 2 diabetes` is descriptive evidence, not authority
to choose a parameter bundle. The two current reference presets remain useful
explicit reference models, not qualified individual-human models.

## Proposed additive record and callable contract

Names below are proposed and require root/reviewer agreement before code.
Reuse `model_binding`, already recognized by the descriptive public-reference
guard, instead of adding an independent boolean activation bypass.

- New descriptive REAL_HUMAN records include `model_binding: null` and a bounded
  `execution_eligibility` projection with state `MODEL_BINDING_REQUIRED` and
  missing context identifiers. Supplied evidence and declared model parameters
  may be retained with their actual provenance, but do not auto-fill twelve
  engine fields or claim they were fitted. Existing consent/unit/QC/source-time
  validation still applies. This is not permission to remove clinical-data
  validation because computation is unavailable.
- Explicit reference previews retain the existing accepted public base IDs
  `healthy`, `t2d`, `type-2-diabetes`; normalize `t2d` only at that explicit
  compatibility boundary. They have no admitted human ID. A preview is not
  a new executable binding for a submitted person.
- A future admitted binding is an immutable server-resolved object, proposed
  schema `livemore.model-context.v1`, containing `model_id`, `model_version`,
  `initialization_id`, exact `source_snapshot_sha256`, all consumed parameter
  values/units/evidence, declared applicability and a binding digest. Identity
  must cover loaded initialization rules, not just a mutable source file path.
  New client data cannot assert `qualified:true`, supply an arbitrary source hash,
  or invent an initialization bundle to bypass the server registry.
- Replace `initialize_profile(human)` for governed paths with an explicit
  `initialize_profile(human, *, context=resolved_context)` or a new strict
  compiler. Missing/malformed/unsupported context raises a fixed safe named
  error **before** a model constructor, parameter mutation or event publication.
  Do not read `conditions` to select a template. Descriptive source fields may
  be displayed but cannot set engine mode.
- `AdmittedHuman` carries the accepted binding/context or explicitly none.
  `parameter_provenance` comes from that same immutable compilation result,
  never a second text-based compilation. `build_twin`, activation, Reset,
  restoration, detached SDK construction and direct helper use share the guard.
- Proposed safe codes: `MODEL_BINDING_REQUIRED`, `MODEL_CONTEXT_UNSUPPORTED`,
  `MODEL_CONTEXT_SOURCE_MISMATCH`, `MODEL_CONTEXT_INVALID`. Mutation requests
  reject before writes; do not echo clinical text, source payloads or secrets.
  Source/record corruption remains an operational integrity failure, not a
  user-correctable request that retries into a different model.

This correction does **not** activate a nine-parameter reference assumption
bundle for empirical NHANES members, nor establish a new real-person scientific
binding. Current public-reference schemas and explicit missing-binding guards
remain rejected by all execution paths. Qualification of healthy/non-T2D
person-specific models remains required open work in the parent plan.

## Compatibility, encrypted records and restoration

Keep encryption keys, AES-GCM AAD, opaque identifiers, ciphertext and existing
schemas unchanged. The inspected subject schema is `livemore.twin-record.v1`,
with `_AAD=b"livemore.aegle.subject-registry.v1"`; its numeric `version` becomes
2 after a lifecycle mutation. Lifecycle version 2 is not an implicit model
context version or authorization to rewrite an old encrypted record.

If additional v2 record formats are identified before implementation, add their
exact schemas and fixtures to the inventory rather than assuming their meaning.
Preserve all of them byte-for-byte on read. No mass migration, re-encryption,
deletion, source relabeling or automatic corrected diagnosis in this packet.

- Old records remain readable with their saved historical evidence. Expose
  missing context as an additive projection; do not rewrite old payloads merely
  to add `model_binding:null` or recompute their parameter provenance.
- Unsupported or unbound historical REAL_HUMAN records cannot regain execution
  by running the old substring selector. An explicit separately reviewed binding
  transaction would produce a new record revision/lineage while preserving the
  original; that transaction is not implemented by this correction.
- Saved experimental results remain inspectable under their original run,
  equation and parameter hashes. Reading History never recomputes them.
- Restoring an unsupported authoritative subject fails before publication and
  must never clear its active ID or attach healthy/T2D preview quantities to it.
  The narrow first packet retains the existing startup failure semantics. If
  usability requires metadata-only degraded startup, write/review a separate
  all-consumer availability contract; do not catch-and-continue under a false
  healthy subject merely to keep the dashboard loading.
- A previously active supported context remains unchanged when activating a
  different unsupported record fails. Test both registry version and in-memory
  model-source authority to avoid partially changed subject identity.

### Exact legacy DPP/NHANES/PXR boundary

Retain `population.py::generate_members`, its RNG draw order, source metadata,
rounded values, IDs and the frozen `_profile` defaults. These are legacy
aggregate/prior-derived numerical contracts, not newly diagnosed people. Never
infer diabetes type from the old NHANES label.

For legacy reference *twin* reconstruction, use a separate source/stratum-bound
compatibility compiler with the frozen initialization contract, not condition
text. Validate the exact existing source ID/release/stratum and retained parameter
shape. Carry stratum and lineage explicitly; the current `AdmittedHuman` drops
them. Do not regenerate a stored cohort or add fields to its frozen members.
The DPP and older-NHANES seven explicit model values overwrite every numerical
difference between HEALTHY and T2D in this engine; shared defaults are identical.
Preserve the existing twelve-value output nevertheless with exact tests, not
that observation alone. PXR remains its distinct static reference context.

Pure no-solve preservation fingerprints captured on the current source, using
`json.dumps(..., sort_keys=True, separators=(",", ":"), allow_nan=False)`:

| Fixed technical request | Complete four members SHA256 | Four `asdict(_profile(member))` SHA256 |
|---|---|---|
| DPP, size4, seed17 | `b4001aa3191b148a59e18fc868115882bdf3d4a021dba174fbed821d17ef182b` | `abd0339e0b209b9dfd4d3b1e8d6eca68a4ee8d4087442549c05e0a1c0bac74a0` |
| older NHANES, size4, seed29 | `42f6e00030cbab7a50082226618c92e2f2b979774b9fe4ba4aeb55d45ed53097` | `784fef2081e91971b7fffa61bec40c3ed9bd6556d23644974cb4edd1afac1d00` |

These freeze numerical inputs, not biological validity or solver trajectories.
Preserve existing protocol golden results and source snapshots independently.

## Bounded implementation sequence and ownership proposal

1. Write red dispatch and no-native-call tests around the actual initializer,
   direct AdmittedHuman path, create/build/activate/restore/Reset. Freeze the
   legacy twelve-value golden tuples above plus encrypted old-record fixtures.
2. Add a small strict context resolver/compiler and safe error type. Change
   clinical initialization and AdmittedHuman consumers only after agreeing the
   exact context schema. Do not change any physiological equation or parameter.
3. Separate descriptive create validation from model compilation in the registry;
   preserve existing data and request idempotency. New request identity includes
   typed context selection where supplied. Old same-key retries must use the
   historical request-version rules, not become a different admission silently.
4. Root-owned server activation/startup and attached SDK/CLI expose the same
   safe unavailable reasons. No context inferred by CLI shorthand or selected
   from a condition list. Legacy generic research routes stay visibly legacy,
   never an alternate clinical-admission path.
5. UI may show a compact computation-readiness summary alongside descriptive
   intake and retain inspect/history actions. It must not promise runnable
   physiology because data were saved. Any form changes require separate actual
   browser acceptance and screenshots; Atlas renderer stays untouched.

Expected coordinated surface: new `aegle/model_contexts.py`,
`clinical_parameters.py`, `subjects.py`, narrow `runtime.py` guards, root-owned
server errors/startup, governed SDK/CLI consumers and dedicated tests. Legacy
`population.py`, protocol equations, source normalizers, physical devices and
continuous producer equations remain unmodified. More than a one-line fix is
required because admission and compilation currently share an unconditional call.

## Required red-first regression matrix

- All eight technical text cases above: no text-derived selection; an absent
  context remains unavailable. Changing only condition text cannot change a
  bound parameter tuple, choose a different model or manufacture a diagnosis.
- Explicit reference healthy/T2D previews still work; unsupported, blank, null,
  boolean, list and forged context IDs reject before cardiac/metabolic creation.
- Valid unsupported descriptive intake persists its original text and evidence;
  no engine is called. Invalid clinical units/QC/time still fail before writing.
- Direct new-record helper calls, bool override, nested missing-binding records,
  Reset and detached SDK construction cannot bypass missing-context admission.
- Wrong subject/source/binding hash, stale version and context mismatch fail
  atomically. No old source series or observation is attached to a new subject.
- Existing encrypted lifecycle-v2 and other inventoried historical schemas decrypt
  identically and retain byte-identical ciphertext on read. Unsupported restore
  publishes no healthy/T2D replacement and does not clear the authoritative ID.
- Legacy DPP/NHANES complete-member and twelve-value profile hashes above remain
  exact. Add PXR and legacy reference-twin reconstruction goldens. Existing saved
  run values/hashes and explicit prepare-rerun lineage remain unchanged.
- Existing fasting-context, original-unit, capture-time, QC, conflict and
  parameter-domain checks retain their behavior. Snapshot values are not silently
  promoted from observed source evidence to individually identified kinetics.
- Auth/no-store/audit and safe error bodies tested at real routes; no clinical
  text, input values or encryption material in logs. Preserve existing physical
  observation/model-output separation and no self-calibration.
- Independently reviewed code, installed-source tests and actual browser/terminal
  unavailable/supported reference paths before acceptance. Test success is not
  person-specific or clinical validation.

## Lesson and present limit

A disease substring can select the wrong numerical model while every value is
finite and every provenance field appears complete. Separate descriptive evidence
from a typed computational contract, and test negative context admission at every
constructor and restoration seam. Correcting the selector does not supply the
missing person-specific physiology or complete the five botanical programs.
