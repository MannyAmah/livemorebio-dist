# Molecular diagnostic request-floor correction

2026-09-09. Written root implementation decision within the approved R01–R51
recovery plan. No product or scientific scope substitution.

## Evidence and decision

Root read the complete independent W8cBUx data review (`7fd298`) and its exact
27 clock witnesses. Each retained FINISHED is after its own REQUEST and before
its own RESPONSE. Pinned Chromium/Playwright source does not establish ordered
timestamps across callbacks. W8cBUx remains FAILED; no consumed evidence changes.

Approve the reviewer's minimum diagnostic correction in one fresh private copy:
retain immutable own REQUEST time and use it as the floor for RESPONSE,
FINISHED and FAILED. Values must remain finite numbers and nonnegative;
equality with the request floor is allowed. A prior RESPONSE is descriptive,
not a new floor. Preserve raw event timestamps and bounded rejection facts,
including the exact request boundary and a fixed EARLIER_THAN_REQUEST reason.
No clamping, sorting, rounding, tolerance, cross-plane substitution, fabricated
terminal, FAILED-event waiver or application transport change.

## Red-first implementation and independent review

Keep the old private root untouched. Copy the eight-file harness into a fresh
private root, update only root-dependent manifests and the narrowly identified
checker/test contract. Before implementation retain RED for the original 27
triples, both admitted network triples, equality, and RESPONSE/FINISHED/FAILED
before-request refusal. Preserve malformed-number and bounded-retention checks.
Explicitly document changed old expectations rather than silently dropping tests.
All unrelated identity, route, duplicate, status, cutoff, byte/event, process and
cleanup rules, four stages/11 captures, page, Python supervisor and source pins
remain unchanged. No new observer framework or dependencies.

Use the existing inert refusal wrapper only. Freeze complete source/test diff,
original and successor hashes, RED/GREEN receipts and the exact independent
repeat. Root must independently inspect and repeat; the maker cannot approve.
No actual browser run, ordinary Biology switch, native run, participant/device
use, release or recording is authorized by this implementation decision.

## Acceptance boundary and lesson

This corrects the interpretation of technical clock evidence, not biological
behavior. Any fresh actual check needs a separate bounded decision after review.
Older ERR_ABORTED is not explained by this result. Main Biology integration,
all required body functions and the six exact experiment videos remain open.

A monotonic time source does not guarantee timestamp order across callbacks;
compare reported timings to their own immutable request origin and retain facts
without rewriting them.

## Frozen maker implementation receipt — subsequently independently graded below

Fresh private root: `/private/tmp/livemore-molecular-request-floor.USnuJu`.
The consumed W8cBUx/OYVOcS roots were not changed. No `run` directory exists
in the successor, and no browser, service, native/scientific process or product
consumer was invoked or edited. This section records maker evidence only.

Only `check.cjs`'s clock helper and initial request-entry construction changed:
the entry retains `start` once, later events compare to that origin rather
than `last`, and rejected facts additionally retain `request_protocol_time_s`
(null when no request exists). `last_protocol_time_s` still reports the actual
prior admitted event; all admitted event values remain raw. Finite/scalar and
nonnegative predicates, fixed error propagation, event/byte reservations,
status/identity validation, ownership and terminal-failure handling are unchanged.
The checker diff is five removed/seven added lines including two explanatory
comment lines; no public API, dependency, reader or observer framework changed.

### RED → GREEN

Before checker edits, the new 39 cases were appended after the complete
unchanged 118-case parent Node test prefix. Original RED invocation `be92ad`
exited 1; its tool display was truncated. A second identical inert invocation
**before any checker or inherited-expectation edit**, `f3c81a`, retains the full
receipt in `red-output.txt`: **33 failed / 124 passed / zero skipped**, 157 Node
cases, 3242.927375 ms. The Python phase was correctly NOT_RUN after Node failure.
All 118 inherited cases were among those 124 preservation passes.

The 33 new failures were exactly 27 retained terminal triples rejected by the
old prior-response floor, three before-request facts lacking the new reason and
request-boundary field, two terminal/failed-event floor-equality cases, and one
per-identity floor case. The two previously admitted network triples, RESPONSE
equality, zero request origin and both retention-ceiling cases already passed.

After the narrow checker edit and the explicitly listed inherited expectation
migrations below, **`bf8eb2` passed 157 Node + six Python = 163 checks**, zero
failed/skipped. Node 3241.315083 ms; Python 0.023 s; outer command 3.352501792 s.
The unchanged refusal wrapper allowed only its fixed Node unit-test child,
which refused network and child entry points; the six Python cases ran under
the existing subprocess/socket refusals. No actual runner was invoked.
`green-output.txt` retains the full output. No assertion in the 39 new cases
changed after RED.

New case inventory is deliberately finite:

- 29 mounted triples: the exact 27 rejected and two admitted network triples
  copied from the original W8cBUx receipt, asserting raw event order/values,
  exact terminal state, correlation/pending results and settled detach. These
  are portable constants with authored emitters/IDs/routes, not a replay claim.
- Three before-request refusals: RESPONSE, FINISHED and FAILED, preserving the
  exact origin, prior event, rejected value, fixed reason and pending cutoff.
- Three equal-floor cases, retaining FAILED/ERR_ABORTED as failure; one all-zero
  origin/timestamp case; one two-ID test proving floors cannot alias or advance
  with another request or their own response.
- Two floor-refusal retention ceilings (event/byte), keeping the original
  failure, pending ordinal, exact detach and unchanged 256 KiB ceiling.

### Explicit inherited expectation changes

No inherited case was removed. Only these five existing blocks changed:

1. The eight malformed scalar cases add the exact request-origin field to their
   existing full fact equality; all scalar refusals and payload exclusions stay.
2. The former `earlier-than-last` case now admits `[1000,1001,1000.5]` unchanged
   as FINISHED with no clock error. Its intentionally unmatched other planes
   still fail cutoff with exact TRANSPORT_CORRELATION_INCOMPLETE.
3. Unknown/rejected-initial identity cases additionally assert null request
   origin, preserving null local identity and no raw protocol-ID retention.
4. Rejected response/FAILED malformed facts additionally assert the existing
   request origin; reasons, previous values, state and secrecy assertions stay.
5. The zero rejected terminal keeps numeric zero and clock-retention failure
   checks, changing the ordering reason to EARLIER_THAN_REQUEST and asserting
   the exact 1000 request boundary.

### Frozen identities and repeat

Complete original→successor source/test/manifest diff: `source.diff` in the
private root. The original RED test source is separately `red-test-check.cjs`.
The five files `check.py`, `page.html`, `page.js`, `test-check.py` and
`run-inert.py` remain byte-identical to W8cBUx. `inputs.json` changes only its
two page-file root paths. `harness-pins.json` updates the eight exact copied
paths and current hashes/metadata, with integer nanoseconds preserved without
a JavaScript-number round trip.

| File in USnuJu | Bytes | SHA-256 |
| --- | ---: | --- |
| check.cjs | 36128 | `0ee8659da5ba331e800580293d439d5bfd4d5596531b22d2262cf2a8bd2fc8d8` |
| test-check.cjs | 48641 | `79743c8a5b5a81e79917957b5d4c57122d5e934ae0a9253ebdf69f675afea868` |
| inputs.json | 7762 | `9f412423b86e97d31ebf3842d5441ea3ea5093cb30c076d71255dd7e773512ff` |
| harness-pins.json | 1920 | `883c76975c1a11cbd7cead75692f7388b4641d56147171130329dbc60af19158` |
| red-test-check.cjs | 48407 | `008e0b8bea9d3d8f876312dac3714083301af6d2329833cd69d7f783989e8bc0` |
| red-output.txt | 44997 | `fe09ac4ff764e39aaa18944dc1670d64e201b099fcb728873b10c58d01cdc4ad` |
| green-output.txt | 12191 | `e4f80c62c3350480dc87e44a20f6fb1f4c657199fb58704a06ee16c6d1101066` |
| source.diff | 19872 | `3b62c24c8fa24457a8ea170c1a5afbc0ce0edb72c2940424128e4e8a531f13fd` |

Post-freeze read-only check `79f628` verifies both original/successor 30-pin
manifests by complete hash, size and exact mtime_ns, all five unchanged files,
the exact original 29 own-ID triples versus the retained JSON, unchanged new
cases since RED, and successor `run` absence. The original FAILED browser
receipt remains 259800 bytes / `3a048e6bef0785389365630c7a23aebfa91b421ea28dc8b113f937ca642ad39e`.

Exact independent inert repeat (not actual-run permission):

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-molecular-request-floor.USnuJu/run-inert.py
```

Root must read the complete delta and independently grade this packet. No
actual invocation or old receipt reclassification is authorized by this freeze.

## Root independent grade and exact actual decision

Root read the complete maker receipt and source/test/manifest delta
(`63ade5`,`0b5b44`), the surrounding actual observer, unchanged Python supervisor
and refusal wrapper, and the pinned Chromium completion implementation
(`1bfd30`,`ac8bbb`). The correction changes only the request-origin comparison
and retained comparison boundary. Old scalar/identity/refusal/budget/cleanup
behavior remains; explicit inherited expectation migrations are justified by
the observed and source-reviewed clock contract, not by a wish for PASS.

Root's independent read-only check **4643b8** verifies all30pins in both roots,
five unchanged files, all29 exact original triples, the unchanged39new tests
since RED, seven frozen source/receipt hashes and absent successor run directory.
The exact independent repeat **fa72a0** passed **157 Node +6 Python =163**,
zero failures/skips; Node3206.749958ms, Python0.020s. No actual browser/native
run occurred in that repeat. This is independent technical clearance only.

Root now authorizes one fresh actual invocation, exactly:

```sh
/Users/emman/.local/share/uv/python/cpython-3.11.15-macos-aarch64-none/bin/python3.11 -B /private/tmp/livemore-molecular-request-floor.USnuJu/check.py --run-once
```

It is bound to the frozen checker0ee8659d, supervisor1dd4a2c2,
inputs9f412423 and harness883c7697 full hashes above. The exclusive fresh
`/private/tmp/livemore-molecular-request-floor.USnuJu/run` may be created only
by this invocation. No reuse/retry. All30inputs remain frozen through cleanup.
Only the same public-reference GET-only loopback8910 service, pinned browser
and four D0/D1/D2/M0 stages/11planned images are allowed. Keep240s outer,
180s work,15s cleanup,128requests,32MiB served,64MiB evidence and the existing
512event/256KiB transport bound/reserve. No participant store, device command,
other service, native/model execution, remote request or source/vendor switch.
OSP actual has ended and recorded PIDs are absent; OSP work remains source-only.

Preserve actual failures and all original receipts/screenshots. Root will inspect
all original images, transport and exact recorded-PID cleanup; independent
data-only review follows with no rerun. A passing result admits this private
reference-viewer interaction check only, not ordinary Biology, pharmacological
equivalence, any of the six experiments, package rights or publication.

## Actual result and independent evidence review — FAILED, preserved

The exact invocation (`3a1196`, completion `3ec751`) consumed its sole run
authorization and exited 1 in 42.1764504169696 seconds. All four stages and
11 planned captures passed, but the packet remains
FAILED/TRANSPORT_OBSERVATION_FAILED, with TRANSPORT_CDP_FAILED. Three genuine
desktop coordinate-request failures were retained in both Playwright and CDP:
KRAS D0, TP53 D2 and EGFR D2. Each is ERR_ABORTED/canceled true after a 200
response, before any owned teardown. No clock rejection recurred. Neither a
rendered structure nor server completion overrides those failed terminals.

Root inspected all 12 original images, including the failure capture. The
deposited geometries, Help, sequence selection, actual 5.82 Å distance and
mobile scrollable provenance are visible. Explicit pig 4INS stays separate
from unavailable human INS. These are private public-reference component
checks, not ordinary Biology acceptance, individual physiological reactions,
an experiment video or human equivalence. The failure image is the already
closed mobile reference page, not a reconstructed error screen.

Independent data-only audit `8c922a` confirms original/embedded JSON equality,
all 12 complete PNG hashes/dimensions, both original/successor 30-entry pinsets,
all three exact failed-event correspondences and preserved old receipts. See
[the complete independent data audit](2026-09-09-molecular-request-floor-data-audit.md).
The browser original is 259724 bytes/SHA256
`ba75972e2a48ccfdcaf321d8d0bcb52f874a3acc8032a824cdab56e513f5e12f`;
supervision is 280204 bytes/SHA256
`6f5f2e5fa952cf037c9c81f1a686d55cdbb6317eb47b59a5889c273bd1a8af76`.

There were 29 requests/10,296,699 served bytes, zero page/console/CSP errors,
35 CDP identities (six non-network data identities), and empty pending lists
at both cutoffs. All eight owned closes settled, Node 48802 was reaped, and
root's exact 21-recorded-PID check `99aed7` returned no rows. Both listener
checks are NO_LISTENERS. Final evidence is 2,187,654 bytes, within the original
ceiling. Empty pending means terminal, not successful. No source/vendor or
operational data was changed; no native/model run overlapped this check.

Root invoked the investigation skill and holds further actual browser attempts
until a specific source/evidence-based cancellation diagnosis and reviewed
correction or diagnostic are available. Do not change loader cancellation,
ignore ERR_ABORTED, weaken acceptance or reuse this consumed run directory.
The approved scope remains R01–R51 and the six requested videos remain 0/6.
