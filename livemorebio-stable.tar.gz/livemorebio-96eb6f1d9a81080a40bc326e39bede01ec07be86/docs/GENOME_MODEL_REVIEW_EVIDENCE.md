# Genome-model and clean-workflow release evidence

September 5, 2026 · additive candidate `codex/genome-models-clean-workflows`.
Preserved baseline: `19c1edaa2b15cc414d148e9fde49919b3653ab3f` / PR #5.

This document records software and numerical verification, **not** physical,
clinical, whole-human, device-equivalence or pharmaceutical-production qualification.
The previous worktree, running user deployments, keys, experiments and recordings
were preserved. Recording services used a private store on 8870–8872; final
published-install QA used another private store on 8880–8882.

## Implemented capability

- Eight official Human-GEM 2.0.0 files, pinned to commit and SHA256 with attribution,
  install into a private versioned cache. Availability, execution readiness and
  restrictions are distinct states. Corrupt/missing files fail closed.
- A bounded isolated COBRApy/GLPK worker executes explicit glucose/oxygen media,
  ATP-maintenance objective and optional complete GPR-aware gene knockouts.
  Unlisted uptake is closed. Each run has closed-medium/no-glucose controls,
  solver/balance/bound checks, versions, hashes, units and reference annotations.
- The same immutable Cendos run reaches Biology, terminal, CSV and Jupyter.
  Unknown compound-to-network effects and genome-to-organ shortcuts remain disabled.
  Reference graph projections retain direction, stoichiometry and identifiers;
  they do not imply a deployed Neo4j/TuringDB service or licensed external access.
- Healthy unadmitted initial preview; no seeded patient, cohort or experiment
  records. Existing active identity restores. Twin/cohort paging/search and Cendos
  blank Preparation, paged History, read-only recall/preparation and explicit reruns.
- Biology first load, retry and optional graphics are decoupled. Unsupported organ
  function and cell kinetics stay unavailable/reference-only. Cardiac voltage/calcium
  playback uses recorded samples and time, not invented contraction geometry.
- Biology reads require authorization. Opaque view-context binding prevents a cell
  trace from being used for a different selected instance/readout. In-place changes
  detected during Biology projection return a controlled retry response.
- Installer model verification and the managed command use isolated imports;
  service children use the same installed source, not a caller's older checkout.
  Reverification does not write bytecode or pytest caches into an immutable release.

## Actual model checks

Source XML SHA256:
`cc5a4383c6116b0c91f4db089cc640f29aec7e840249b573b74d3792c9ca4a7a`.
Counts: 12,931 reactions, 8,461 metabolites, 2,848 genes, nine compartments.
See [model-source review](HUMAN_GEM_MODEL_SOURCES.md) for full provenance and licence.

| Explicit condition, glucose uptake cap 1 | ATP maintenance capacity (mmol/gDW/h) |
|---|---:|
| No knockout, oxygen cap 0 | 2 |
| No knockout, oxygen cap 2 | 12 |
| No knockout, oxygen cap 6 or 10 | 31.5 |
| ATP5F1B complete model knockout, oxygen cap 0 | 2 |
| ATP5F1B complete model knockout, oxygen cap 2 | 3.3333333333 |
| ATP5F1B complete model knockout, oxygen cap 6 | 4 |

Both negative controls gave zero and passed. All displayed experimental conditions
were optimal with residuals within the declared tolerance. These are pinned-network
characterizations, not ATP measurements or proof of efficacy. Flux optima can be
nonunique; FVA is not computed. Conditions are neither independent subjects nor
elapsed biological time. No active twin or LIFE observation is calibrated by them.

## Verification record

Full candidate command (Python 3.11, native scientific dependencies installed):

```sh
LIVEMORE_TEST_GENOME_MODELS=1 LIVEMORE_TEST_MODEL_DOWNLOAD=1 python -m pytest -q -rs
python -m compileall -q livemorebio tools/run_review_stack.py
bash -n install.sh
shellcheck -s bash install.sh
```

The final pre-publication complete pass reported **773 passed, 44 subtests passed,
zero skipped** in 171.61 seconds. This included actual official downloads and both
native Human-GEM integrations, final cell-context checks and review-process cleanup.
Four warnings were framework deprecations plus a headless Matplotlib display warning,
not failed computations. Compileall, Bash syntax, ShellCheck and whitespace checks
also passed. Published installation verification is recorded separately below.

Independent reviewers exercised source/licensing, model bounds/GPR/control behavior,
history immutability, API error handling, UI projections, installer import isolation,
identity transitions and guide parity. Concrete findings received regression tests
and fixes: graphics blocking data; undefined Biology variable; misleading proxies;
stale solver provenance; double-Next cursors; hidden heterogeneous media; note
preview identity; invalid base fallback; unauthenticated Biology; cell context and
visibility replay; release-cache mutation and review-stream shutdown.

An outside-checkout wheel probe verified the new modules, ten required packaged
HTML/JS/ontology/metadata assets, 16 seed JSONs, an eight-file model manifest and
offline reference loading (20 diseases/30 genes). It did not claim complete server
startup from a wheel without the source-tree cardiac assets. Distribution to
testers uses the verified source installer, not an unsupported bare wheel command.

Six guide Bash blocks parsed, its JSON validated, and SDK/shell examples dispatched
correctly with mocked transport. These checks are separate from the actual published
installer check and do not substitute for it.

## Browser QA and recorded experiment

Real Chrome checks on the isolated service exercised healthy/empty first load,
Biology organ/cell details, actual model execution, all condition selections,
provenance, immutable recall, prepare/explicit rerun and history search. Separate
technical HTTP-fixture browser tests exercised failed graphics, failed data/retry,
unknown run isolation, delayed double-click paging, heterogeneous rerun media,
encrypted-search continuation and 390-pixel mobile layout. Fixture responses are
not biological observations.

Root also created and activated two labeled non-person research twins from different
strata/seeds through the actual UI; older records were retained. Active identity
survived candidate restart. These actions populate only the QA store, never a fresh
external installation.

Screenshots are in [the candidate QA directory](screenshots/genome-models-clean-workflows/).
The final new [ATP5F1B walkthrough](demo/genome-models/walkthrough-atp5f1b-20260905083741.mp4)
is **436.96 seconds (7m17s), 1600×1000 H.264**, native browser capture with no speed
changes or screenshot slides. It includes preparation/typing, actual computation,
Biology selection and provenance, two downloads, History recall/preparation and
actual Jupyter Run All/save. It contains 79 logged actions/chapters and two executed
notebook code cells with no errors. See [recording verification](demo/genome-models/walkthrough-atp5f1b-20260905083741/verification.md)
for hashes, exact results, chapters, method and the candid remaining layout limit.

## External install verification

The first literal published-candidate installation correctly **failed closed**:
771 tests passed and two failed. It exposed a concurrent SQLite journal-unlink race
and a permissions test whose intended 0755 fixture was changed by installer umask
077. Inspection additionally found technical audit/key writes in the new runtime
directory. These findings triggered fixes and independent regression review; they
were not suppressed or treated as a successful installation. The failed evaluation
directory is retained and no failed release was activated.

The corrected literal one-line command from [the tester guide](EXTERNAL_TESTER_GUIDE.md)
was executed from the **older preserved checkout**, with new private installation,
bin, operational-data and model roots. It downloaded published commit
`1bbfeab7f5d092f6440ace53fc6405e6ff697b4c`, installed hash-locked dependencies,
fetched/verified all eight model assets and passed **807 tests, 44 subtests, zero
skips** in 220.60 seconds before compilation and activation. Model and network
opt-ins were enabled. Before service startup, operational data contained **only
model assets/cache/lock metadata**: no audit log/key, subjects, cohorts or runs.

Reinstalling the same published commit reused verified assets without downloading,
used a different retained private verification directory and passed both native
integrations in 68.36 seconds. Independently recalculating the complete release
digest afterward matched the original exactly:
`c16fa79ef7afeb8567ec2047d5305d3ccf42b3958b96b9ecd7767b6e2d5355ab`.
Managed `--help` and `models check human-gem` worked from the older checkout.

The documented **installed** review runner started 8880–8882 with isolated stores
and credentials. Browser QA confirmed healthy unadmitted preview, empty Twins,
Cohorts and History, blank Preparation and independently loading Biology. All
three health endpoints returned 200. Authorized Biology matched the state context;
unauthorized Biology returned 401. LIFE and Research loaded without admitting
physical evidence. No browser JavaScript errors were reported. Screenshots use the
`installed-*.png` prefix in the candidate QA directory.

The exact guide SDK example created
`protocol-ddae6963cc8c435e9b21d9b326669e6b`: ATP capacities 2 and 31.5, optimal
solutions, matching constraints and passing zero-energy controls. Recall equaled
the original response; preparation did not add a run; the complete active-state
response remained unchanged. The **installed terminal** then exercised models,
list/history/show/prepare/export and explicit rerun. Child
`protocol-37115958128b448a99948016ba39702f` retained the input digest and exact
parent ID/hash; its parent remained unchanged. The exported notebook executed
code cells 1 and 2 with zero errors in the installed Jupyter environment. Its local
kernel warned about unencrypted TCP; this non-person loopback test is not a
production-PHI security qualification.

Browser condition selection, History recall and Prepare rerun displayed those
same saved outputs/inputs. Final state: zero twins, zero cohorts, **two explicitly
executed QA runs**, zero research measurements. These runs were created after the
blank-state check and are not installer seed data.

CI for diagnostic-test commit `0daecdd30383078962e91774e24e298115a6394d` passed on
[macOS and Ubuntu](https://github.com/MannyAmah/livemorebio/actions/runs/33957515945):
**809 tests and 44 subtests passed** per platform. The one skip was the separate
network-download opt-in; CI independently downloaded/verified the assets before
both native integrations. No model test skipped because of missing files. This
commit differs from the installed runtime only in sanitized test diagnostics and
three offline diagnostic regressions.

An earlier macOS run had a structured model-worker failure whose exact cause was
not recoverable from the original sanitized exception; it was not the 120-second
watchdog. Added diagnostics report only allowlisted categories. **No solver
deadline, residual threshold, expected output or control was relaxed.** Two
subsequent macOS/Ubuntu CI runs passed. The earlier failure remains an unreproduced
reliability observation, not a proven timeout or claimed fixed numerical defect.
Future recurrence must retain its safe failure category.

Independent guide review corrected separate-evaluation store, model-root, token
and stale-launcher instructions. All eight Bash blocks and the nested bootstrap
parsed successfully. Existing deployments and the preserved baseline remained
unchanged. [PR #6](https://github.com/MannyAmah/livemorebio/pull/6) is the additive
review boundary; no direct main push or merge was performed.

## What still blocks stronger claims

Recon3D commercial rights are unresolved; no restricted model is activated or
redistributed. There is no general healthy-population cohort manifest, tissue-specific
Human-GEM context, GEM-to-organ kinetic coupling, prospectively qualified patient
prediction, physical Patch equivalence, or wet-lab evidence for this new protocol.
Licensed sources and production graph services retain their explicit gates.
Multi-user authorization, tenant isolation, production key management and approved
PHI operations are not delivered by this local research candidate.

The [development roadmap](MULTISCALE_DEVELOPMENT_ROADMAP.md) covers all body systems,
cross-scale contracts, continuous evidence learning/change control, staged LIFE
firmware/hardware and physical Cendos qualification. It supplies future acceptance
gates, not a claim that those systems are already executable or validated.
