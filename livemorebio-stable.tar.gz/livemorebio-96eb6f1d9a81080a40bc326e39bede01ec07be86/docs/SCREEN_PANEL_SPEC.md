# SCREEN PANEL SPEC — authoritative implementation order for the next build phase
**Repo:** github.com/MannyAmah/livemorebio (private, `main`) · local `/Users/emman/Livemore/livemorebio`
**Baseline commit:** `35f8b4b` · Read `docs/HANDOFF.md` FIRST — it is the complete project handoff.

> **Implemented and superseded on 2026-08-29.** This file preserves the inherited design,
> but its process-global `last_screen`, unscoped downloads, permissive cohort, and blanket
> “signed” language are no longer the product contract. The shipped contract uses explicit
> T2D-enriched/OGTT admissibility, PK-linked metformin response, run-scoped durable artifacts,
> full-ranking integrity binding, bearer-authenticated mutations, and governed evidence-package
> language. Operate it from [LAUNCH_GUIDE.md](LAUNCH_GUIDE.md).

## 0 · Corrections to assumptions (read before writing any code)
1. **There is no "Phase 2c" document.** This spec IS the written plan for the next phase
   (HANDOFF §11.1–.2 / §12.2–.3). Build to THIS document.
2. **This is Python 3.11 + FastAPI — there is NO `package.json`.** Conventions come from
   `pyproject.toml` + `requirements.txt`. Web UI is vanilla JS inside server-rendered HTML files
   (`livemorebio/aegle/console/*.html`) using the project's warm-palette CSS tokens. No React,
   no build step, no component library.
3. **`pin_cached` exists ONLY as uncommitted working-tree changes** (preserved on branch
   `wip/parallel-pk-pinned-screen`; also in the bundle). A parallel session already built much of
   Stage 2 in `livemorebio/sdk.py`: `Platform._pin_resolution(compound, refresh)` (resolve once →
   pin {chembl_id, source, targets[gene→scale]} to rcache key `screen-pin:<name>`; raises on
   unresolved — nothing substituted), a `screen(..., mode="auto"|"chembl"|"parametric")` dispatcher
   (metformin → individualized PK path via `engines/pharmacology.py`; explicit
   si_boost/gb_drop/gamma_boost → parametric; anything else → pinned ChEMBL through each member's
   Recon3D), `pin_cached` in outputs, and GEM memoization. It ALSO added a hepatic-PK drug-plasma
   channel to `/api/patch` (live when `st["hepatic"]` has a dose, honestly pending otherwise) with
   matching `runtime.py`/`biology.py`/`pharmacology.py` changes. **VERIFY AND COMPLETE this work —
   do not rebuild it and do not duplicate it.** The committed audit module (`livemorebio/audit.py`)
   is unchanged: `record/verify/result_fingerprint` only — pins live in the screen's
   `audit.inputs`, not in audit.py.
4. **All Aegle routes live in `livemorebio/aegle/server.py` and MUST be defined ABOVE the
   `if __name__ == "__main__": main()` guard** at the bottom of the file, or they never register.
5. Aegle does NOT auto-reload. Restart after server changes:
   `pkill -f "livemorebio.aegle"; pkill -f 8850; sleep 2; (./.venv/bin/livemore start Aegle >/tmp/aegle.log 2>&1 &); sleep 6; curl -s http://127.0.0.1:8850/health`
6. Gate every stage on: `py_compile` clean → curl verification → pytest
   `(./.venv/bin/python -m pytest -q > /tmp/pytest.log 2>&1 &)` → expect **55 passed, 3 skipped
   (network), 0 failed** → commit with `git -c core.hooksPath=/dev/null commit`.
7. Owner's rules: no fakes; honest flagging; ask before substituting an approach; model-only
   framing ("hypothesis triage", never per-person prediction) on anything pharma-facing.

## 1 · Stage 1 — `POST /api/screen` (endpoint first)
**Purpose:** expose the existing SDK cohort screen (`livemorebio/sdk.py::Platform.screen`) to the
web console. The SDK already does the science; the endpoint only orchestrates.

**Contract**
```
POST /api/screen
body: { "compound": "metformin",          # or any plant-compound name (Stage-1 set, see below)
        "dose": 1.0, "grams": 75.0,
        "n": 30, "seed": 0,
        "si_boost": 0.30, "gb_drop": 0.06, "gamma_boost": 0.10 }   # plant-compound params, optional
→ 200: the exact dict returned by Platform(mode="inprocess").screen(...):
        { "summary": {compound,dose,grams,cohort_n,seed,n_effect,responder_rate,
                      mean_delta_mean,best,worst},
          "ranked": [ per-twin rows: id,age,sex,conditions,baseline_mean,delta_mean,
                      delta_iAUC,rel_mean,decision ],
          "audit":  signed record (result_sha256, hmac_sha256, ts, action, inputs,
                      outputs, provenance) }
→ 400: {"error": ...} for n>60 or missing compound.
```
**Implementation notes**
- `from ..sdk import Platform` inside the handler (match the file's local-import style).
  `Platform(mode="inprocess")` builds its OWN isolated `AegleTwin` — it does NOT touch the live
  `_state["tw"]`, so the console twin is unaffected. This isolation is the point; keep it.
- Synchronous; ~0.5–1.5 s per twin (Recon3D-free path). **Cap `n` at 60** and return 400 above it.
  v1 is synchronous by design — do NOT add job queues without asking.
- Stash the last result server-side: `_state["last_screen"] = result` (needed by Stage 1b).
- Stage-1 compound set = what `screen()` supports today: `"metformin"` (dose-scaled curated
  intervention) or ANY other name → parametric multi-target plant compound via
  `si_boost/gb_drop/gamma_boost` (`engines/metabolic/interventions.py::plant_compound`). Label
  plant compounds honestly in the UI as "parametric multi-target (ethnobotanical)". ChEMBL-resolved
  screening is Stage 2 — do not fake it in Stage 1.
- Verification: curl the endpoint (n=10, seed=3) twice → identical `ranked` order AND identical
  `audit.result_sha256`; `python -c "from livemorebio import audit; ..."` verify(rec) is True.

## 2 · Stage 1b — signed report download
**Contract**
```
GET /api/screen/report.md          → text/markdown, Content-Disposition: attachment;
                                     filename="livemore-screen-report.md"
GET /api/screen/report.audit.json → application/json attachment (the signed record alone)
→ 404 {"error":"no screen has been run"} when _state["last_screen"] is absent.
```
**Implementation notes**
- Render with the EXISTING `livemorebio/report.py::screen_report_md(result)` — do not re-implement
  the report. Return `PlainTextResponse`/`JSONResponse` with the attachment header; no temp files
  needed.
- The report already contains fingerprint + signature + provenance + model-only framing +
  `livemore audit verify` instructions. Keep them intact.
- Verification: download both, then
  `./.venv/bin/livemore audit verify <downloaded>.audit.json` → "VALID — reproduces + untampered".

## 3 · Stage 1c — the Screen panel (web console UI)
**Where:** `livemorebio/aegle/console/index.html`, right ("ctrl") column — insert a new
`<div class="grp" id="screenPanel">` directly BELOW the existing `#expBuilder` group. Single-file
vanilla JS; reuse the existing tokens/classes exactly: `.grp h2`, `.rowlbl`, `.tin`, `.seg2`,
`.btn.run`, `.hint`, `.pv-sub`, and the `$()` helper. Palette vars: --paper #faf6ec, --paper2
#f0ead9, --ink #1a1a17, --muted #6f6a5d, --teal #0a3d3a, --biolume #46d6c1, --amber #c9501c,
--gold #b88a2a, --line #ddd5c4, --dim #b8b1a1.

**Panel contents (top→bottom)**
1. `<h2>Cohort screen · pharma workflow</h2>`
2. Compound input (`.tin`, default "metformin") + seg2 toggle [Metformin | Plant compound];
   Plant mode reveals the three sliders (Si +0..80%, Gb −0..30%, γ +0..40%) mirroring the Cendos
   page's plant form.
3. Cohort controls: n slider 10–60 (default 30, labeled "virtual twins") + seed number input
   (`.tin`, default 0) + dose slider 0.25–2.0× (compound mode).
4. `<button class="btn run">Screen across cohort →</button>` with sub-line
   "reproducible seeded cohort → per-twin OGTT → ranked, signed".
5. Results block (hidden until run): summary line
   (`responders X/N (·%) · mean Δ −·.· mg/dL · seed S`), a top-8 ranked mini-table
   (id · age/sex · Δmean · decision) styled like `#expLog`, fingerprint short-hash line
   (`signed · <sha16>…`), and two download links →
   `/api/screen/report.md` and `/api/screen/report.audit.json`.
6. Busy state: reuse `$('app').classList.add('busy')` exactly as `runVia()` does; a screen of
   n=30 takes tens of seconds — show "screening N twins… (~Xs)" text while pending.
7. Honesty line (`.hint`): "model-only in-silico hypothesis triage · deterministic · signed".

**Do NOT**: touch the live twin, re-list results with innerHTML string concat that breaks on
quotes in condition names (escape or use textContent), or add libraries/build tooling.
**Verification (browser or curl+grep):** run a screen twice with same seed → identical table and
fingerprint; downloads work; zero console errors; the beat/metabolic loops keep running while busy.

## 4 · Stage 2 — ChEMBL-resolved compounds with PINNED resolution
**STATUS: PARTIALLY BUILT, UNCOMMITTED (see §0.3 — branch `wip/parallel-pk-pinned-screen`).
Your job is to verify, complete, test, and commit it — not rebuild it.** Remaining to confirm/do:
per-twin `gem_drug_effect` path correctness + runtime budget (~2–5 s/twin with Recon3D; keep the
n-cap and warn in the UI), `targets_in_model / n_targets` honest reporting (0-in-model → ~0 effect
displayed truthfully, curcumin precedent in HANDOFF), the full pin embedded in `audit.inputs` so
`result_sha256` covers it, re-run reproducibility with the pin (identical fingerprint even with
ChEMBL down), pytest green, and the hepatic-PK patch channel verified live-with-dose /
pending-without. Original design intent for reference:
- Resolve ONCE server-side via the existing `_resolve_compound(name)` in `aegle/server.py`
  (curated MoA → bioactivity fallback; persistent `aegle/rcache.py` cache; retry-on-timeout).
- **Pin:** embed the resolved `{chembl_id, source, targets:[{gene,action,scale}]}` into the screen's
  `audit.inputs.pinned_resolution` BEFORE running, then run every twin from that pinned dict —
  never re-hitting the network mid-screen. A re-run MUST reuse the pin (pass it back in or read
  rcache) so the fingerprint reproduces even if ChEMBL changes or is down.
- Per-twin effect path: `engines/coupling/gem_metabolic.py::gem_drug_effect(profile, h.genome,
  {gene:scale}, dose, human=h)` → treated profile → `ogtt_effect`. Note this loads Recon3D —
  budget ~2–5 s/twin; keep the n-cap and warn in the UI.
- Honest flagging: report `targets_in_model / n_targets`; if 0 targets in Recon3D, the metabolic
  effect will be ~0 — display that truthfully (see curcumin precedent in HANDOFF).
- New SDK signature: `screen(compound=..., resolved=None)` where `resolved` is the pin; server
  passes it. Audit `inputs` must include the full pin so `result_sha256` covers it.

## 5 · File inventory for this work (all in the bundle / repo)
- `livemorebio/aegle/server.py` (484) — add routes here, above the main guard
- `livemorebio/sdk.py` (178) — `Platform.screen()` is the engine of Stage 1; extend in Stage 2
- `livemorebio/audit.py` (105) — signing; DO NOT MODIFY in Stage 1
- `livemorebio/report.py` (53) — report rendering; reuse as-is
- `livemorebio/aegle/rcache.py` (64) — persistent resolution cache (Stage 2)
- `livemorebio/aegle/console/index.html` (611) — the panel's home; study `#expBuilder`,
  `runVia()`, `logExperiment()` for the house style
- `livemorebio/engines/metabolic/interventions.py`, `engines/coupling/gem_metabolic.py`,
  `cendos/assays.py`, `life_system/population.py|synthetic_human.py|knowledge.py` — the science
  `screen()` composes (read, don't modify)
- `pyproject.toml`, `requirements.txt` — environment truth
- `docs/HANDOFF.md` — everything else

## 6 · Order of work (fixed)
1. `POST /api/screen` → curl-verified deterministic + signed → pytest green → commit.
2. Report downloads → `audit verify` VALID on the downloaded record → commit.
3. Screen panel UI → browser-verified (no console errors, reproducible, downloads) → commit.
4. STOP. Ask the owner before Stage 2 (pinned ChEMBL screening) — confirm-before-phase is the rule.
