# OSP insulin Stage B: completed execution, failed numerical acceptance

2026-09-08. The [preregistered benchmark](solutions/2026-09-08-osp-stage-b-numerical-benchmark.md)
was approved at SHA256
`91fe2f3d517878eecb1014023ac414287a8ff0c4dca9b6490f57611db669806d`.
No criterion, dose, biological parameter or solver tolerance was changed after
seeing these results. **The model is not numerically accepted or product-ready.**
R11/R33 and the five whole-individual botanical programs remain open.

## What actually ran

All 15 specified native solves completed in fresh private storage, one process
at a time. Each exported all 1100 state identities and all four designated
observers at every requested native time. Source/native SHA256 checks, unchanged
source definitions outside the explicit recipe/output/tolerance allowlist,
requested tolerances, zero warnings, no tolerance reduction, finite values and
complete grids passed. The original author source and earlier artifacts were
not overwritten. No product state, person, device or clinical evidence changed.

Native-process elapsed time was **6.74–13.76 seconds per run**, summing to
**143.07 seconds**. Maximum sampled RSS was **1,369,554,944 bytes** (1.276 GiB),
below the fixed 3 GiB termination threshold; RSS was sampled every 100 ms and is
not an instantaneous OS hard-limit measurement. The fixed 120-second/run and
20-minute/batch deadlines were not exceeded. All child processes stopped.

Python contract/analysis fixtures: **17 passed in 0.40 seconds**. Separate
source-only R tests passed, without a solve. The first Python and R contract
runs failed because their implementations did not yet exist. Tests cover
changed identity/units/paths/dependencies, malformed output, full grids,
constant-series metadata, warning/tolerance rejection, maximum-error rather
than average acceptance, transport integrity, reference arithmetic and
no extrapolation, fixed negative-domain rules, timeout and nonzero exit.
These are technical tests, not physical measurements.

## Preregistered numerical outcomes

The scaled error is exactly the approved per-quantity equation; a maximum over
all states and designated observers cannot be replaced by a visually good
plasma curve. Every failing identity and native time is retained in JSON.

| Comparison | Maximum scaled error | Limit | Outcome |
|---|---:|---:|---|
| I1 versus I2 | 0.602342 | 1 | Pass |
| I0 versus I2 | 12.744436 | 10 | **Fail: 1 point** |
| T1 versus T2 | 1.263644 | 1 | **Fail: 1 point** |
| T0 versus T2 | 73.195938 | 10 | **Fail: 197 points** |
| C1 versus C2 | 0.317426 | 1 | Pass |
| C0 versus C2 | 17.871386 | 10 | **Fail: 364 points** |
| T2 repeat, all states/observers | 0 | 1 | Pass, exact numeric equality |
| T2 versus dense, common integer times | 0 | 1 | Pass, exact numeric equality |
| Disabled dose event versus zero dose, primary observers | 0.000001679 | 1 | Pass |
| T2 versus long initialization, primary observers | 9.646264 | 10 | Pass, near the declared boundary |
| C2 versus long initialization, primary observers | 9.646264 | 10 | Pass, near the declared boundary |
| T0 versus retained Stage A primary observers | 3.08e-11 | 10 | Pass |

Failure localization:

- I0/I2: liver endosomal `End-IR-en` at minute 3.
- T1/T2: pancreatic plasma insulin at minute 60.
- T0/T2: 13 identities, maximum pancreatic interstitial insulin at minute 34.
- C0/C2: four identities, maximum descending-colon luminal glucose at minute 200.

No post-hoc tolerance increase or parameter fit was attempted. Primary observers
have per-quantity records in the same comparison outputs; whole-state failure
remains failure even where the primary observers converge.

## Domain failures: not merely small rounding error

Every B2 run failed the prespecified amount/volume domain gate. Examples are
identified below to distinguish inherited source state, signed bookkeeping
possibilities, and dynamically generated negative compartment amounts.

1. The pinned **original XML itself** initializes hepatic intracellular
   `Glycogen` to **−12,639,308.8716699 µmol** and `Glycogen Phosphorylase b_N`
   to **−0.131815269016201 µmol**. These are not introduced by the port,
   serialization or tighter solver. Glycogen subsequently reaches about
   −13,518,373.12 µmol in T2. A physical stored-glycogen interpretation is
   not admissible on this evidence.
2. The source glycogen RHS sums hepatic glucose uptake and negative hepatic
   glucose production (formula IDs 11158/11160). It may serve a net-balance
   bookkeeping role, but that is a **hypothesis requiring source-author
   semantics**, not permission to reinterpret a named amount as a valid pool.
   The `b_N` state follows source `df_2`; its name/unit alone does not establish
   whether a signed response variable is intended.
3. Eleven segment-level `Oral mass absorbed segment` variables and an aggregate
   absorbed counter become negative. The duodenal counter, for example,
   integrates the sum of para/transcellular absorption rates (formula 3647).
   Signed net transport could explain a cumulative counter's sign; this does
   not retroactively pass the preregistered domain gate or establish a negative
   anatomical amount. Explicit reviewed domain/observation classifications are
   needed before using such counters in a body view.
4. Actual compartment quantities also cross below zero: liver endosomal
   `End-IR-en` reaches **−0.0001323959503 µmol at I2 minute 1**, and salivary-gland
   insulin reaches **−0.00000888794149 µmol in T2**. These exceed the fixed
   numerical floors and cannot be dismissed as binary64 rounding. They need
   source-equation/state-domain and solver diagnosis, not clamping.

I2 has 26 failing state identities and 14,025 negative sample records; T2 has
15 failing identities and 2,840 negative records. Full per-identity/time values,
floors and failure flags are preserved for every B2 run. The original quantities
were neither replaced nor clipped. No author-approved signed-state classification
was available before the run, so none is used as a post-hoc pass exemption.

## All-1100 native reinitialization accounting

All **1073 independent transferred values** passed the prespecified four-epsilon
transport gate at the actual native T/C t=0. Of the **27 formula initializations**,
25 agree with their I-final values. Two reinitialize, in every relevant import:

| Source state | Native source explanation | Example T2 change |
|---|---|---|
| Rectal luminal liquid volume, `OSqLbw_wx0upZOafCXXpSA` | Formula 5523 is `V * SteadyStateFillLevel`, with volume formula 5536 and fill-level parameter 5506. Reimport reevaluates this initialization; it does not continue the evolved liquid-volume state. | 0.0005261547109086681 → 0.0005255788335973548 L |
| IVITT insulin formulation depot, `43jXOaJiEkyI5GC9p8M-SA` | Formula 28280 references DrugMass; 28276 is Dose/MW; 28278 is DosePerBodyWeight × source body weight. The author recipe changes the source administration input and reinitializes the depot. | 0.02050009752254767 → 0.020500601767966992 µmol; zero-dose control resets it to 0 |

This is **source reinitialization with independent-state transfer**, not full
1100-state continuation. Formula definitions and their dependencies remain
unchanged. Every import retains its complete ledger, not only these changed rows.
The source-formula explanation is available for independent review; it does not
remove the numerical/domain failures above. No formula was overwritten to force
an endpoint match.

## Physical-reference discrepancies remain descriptive

The pinned source-distributed workbook contains 11 glucose and 12 insulin
digitized historical points. They are neither new Cendos measurements nor an
independent individual holdout. Source-grid linear interpolation only at
reference times reproduced the Stage A MAE/RMSE within the frozen arithmetic
tolerance. No clinical pass threshold, confidence interval or fit was invented.

| Comparison | Glucose RMSE, mmol/L | Insulin RMSE, pmol/L |
|---|---:|---:|
| Source-tolerance T0 | 0.37258637 | 220.55506 |
| Tight T2, same source-grid method | 0.37251246 | 220.56620 |
| T2 dense-grid sensitivity, separately labeled | 0.37241284 | 232.74607 |

The dense insulin discrepancy is larger; it is retained rather than selecting
the better-looking comparison. T2 glucose minimum is 2.57074842 mmol/L at native
minute 33, versus dense 2.57033130 at 32.7. T2 shared-pool insulin peaks at
3708.69099 pmol/L at minute 3; the dense recorded peak is 3779.94034 at 3.2.
These are **sampled computed extrema**, not measured human responses or exact
continuous extrema. Case2 enters shared `Insulin`; `Insulin Ex` remains a
separate source pool, not a tracked fraction of this administered material.

## Evidence package and next decision

Private evidence root:
`/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-osp-stage-b-81u4w4wd`.
These are retained evaluation artifacts, not a durable installation location.

| Artifact | SHA256 |
|---|---|
| Frozen collection manifest | `1453aefe48b46a5e0ae9bceff931e21a45c590c6101309f1bad412b280344e58` |
| Analysis v1 summary | `84c7b70cd357e5032b1ba5726cac0fa0ff20e7e4b7ccb4585a27090b1213768e` |
| T2 transformed XML | `b362db9b34d554d9c3a66c50d7073eee34ec6ebdf8deb614a82cad718e46c1bd` |
| T2 native output including runtime statistics | `af7a84b34d95dd24ff64c5b68d551f6f1664df8adf3b10e945837a485d11ab68` |

T2-repeat has the exact same transformed-XML hash and exact numeric trajectories;
its complete output hash differs because elapsed runtime statistics are retained.
Per-run inputs, transformed XML/structural diffs, all state/observer outputs,
resource/status logs, full initialization ledgers and source-reference records
are kept. Analysis v1 retains all failures, comparisons, drift diagnostics and
negative-domain records. The code is in `tools/osp_stage_b*.py/.R`; it has no
product-ready flag, physical-device command or live-twin mutation path.

Next work requires a separately reviewed correction/version, not automatic
Stage C wiring:

1. Obtain or independently establish source-specific state semantics: genuine
   concentration/amount pools versus cumulative net transport and transformed
   regulatory variables. Bind those definitions to the exact XML identities.
2. Investigate the negative initial hepatic states and dynamic endosomal/salivary
   amounts against the author implementation/equations and a curated numerical
   author trace. Preserve the failed source version and this report.
3. Only with a justified correction, preregister a new version and repeat the
   declared full-state/domain/source-reference checks without loosening thresholds
   merely to pass. A signed-counter classification must not excuse true negative
   compartment amounts.
4. Review the corrected numerical output independently before proposing the
   isolated product worker, individualized parameter identification, API/UI/CLI
   visualization or physical qualification. The five botanical programs and
   their additional biological systems remain separate active requirements.

Lesson: all-state, unit-aware admission exposed substantial source limitations
that a plausible plasma glucose curve did not reveal. Successful native solves
and a visible drug-response curve are not sufficient evidence of a defensible
executable biological contract.

Independent root arithmetic check (2026-09-08): after reading the complete
benchmark/analysis and correction proposal, root recomputed all six B0/B1 versus
B2 state-and-observer comparisons directly from retained native JSON arrays,
without calling the maker's comparison implementation. Exact reported maxima
and failure counts reproduced: I0 12.744436450096137/1, I1
0.6023419061936085/0, T0 73.19593842827959/197, T1
1.2636435516609532/1, C0 17.87138582145385/364, C1
0.31742579229669105/0. No new solve, tolerance change, source edit or result-file
write occurred. This confirms the failed numerical comparison, not acceptance
of the biological source or human equivalence.
