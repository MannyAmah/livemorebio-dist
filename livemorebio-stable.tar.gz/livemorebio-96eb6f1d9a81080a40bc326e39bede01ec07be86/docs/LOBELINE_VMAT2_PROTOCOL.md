# Lobeline–VMAT2: bounded nonhuman initial-rate assay

Protocol: `cendos.lobeline-vmat2-initial-rate.v1`.

This original calculation implements competitive Michaelis–Menten transport using
minimal published parameter facts. Its context is **rat striatal isolated synaptic
vesicles**, not a personalized human, intact brain, whole plant or clinical trial.
The output is `MODELED_INITIAL_RATE`, `NOT_QUALIFIED`; it cannot update or calibrate
an Aegle twin. No cohort, patient identifier, time course or atomistic structure is
accepted as an input.

## Source and applicability

Nickell et al., *Lobelane Inhibits Methamphetamine-Evoked Dopamine Release via
Inhibition of the Vesicular Monoamine Transporter-2* (2010) includes comparative
lobeline experiments. See the materials and vesicular dopamine uptake methods and
the kinetic-analysis results. [Original publication](https://doi.org/10.1124/jpet.109.160275),
[PMC full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC2812121/).

The source material is **lobeline hemisulfate**. Input concentration is the reported
nominal assay concentration, not free human tissue exposure. No mass-to-molar,
salt-to-free-base, plant-extract equivalence or exposure conversion is supplied.
The code does not reproduce the paper's methamphetamine-release experiments.

The package retains only cited numerical facts, context and original code. It does
not redistribute the article, figures, full tables, supplements or author software;
an article redistribution licence has not been established. The `source_sha256` is
the digest of the included minimal parameter/model record, **not a digest or licence
claim for the original article**.

## Executable contract

```text
v(S,I) = Vmax × S / [Km × (1 + I/Ki) + S]
Km, Ki, S, I: micromolar (uM)
v, Vmax: pmol/min/mg protein
```

| Quantity | Fixed value | Interpretation |
| --- | ---: | --- |
| Control Km | 0.11 uM | Published kinetic summary; SEM 0.0081 uM |
| Control Vmax | 46.7 pmol/min/mg protein | Published kinetic summary; SEM 7.92 |
| Lobeline Ki | 0.47 uM | Functional uptake-inhibition estimate, not binding affinity |

The competitive model changes apparent Km and holds its Vmax constant. This is a
stationary **initial-rate relation**, not integration of substrate depletion,
vesicular energetics, efflux, disease pathways or complete cellular physiology.
The source kinetic experiment used an eight-minute uptake endpoint. Its fitted,
time-normalized rate parameters do not supply a measured instantaneous trajectory.
Rate units contain minutes because uptake is normalized by time; the independent
axis is concentration, **not elapsed biological time**.

Requests require both concentration arrays and an explicit material/context/unit.
`uM` and `nM` are accepted and normalized to uM before calculation and hashing.
Substrate must be 0.001–5 uM, with optional zero as an analytical negative control.
There must be 2–200 distinct substrate values and 2–8 distinct inhibitor values.
The inhibitor grid must include 0 and 0.25 uM and stay within that interval.
Intermediate inhibitor conditions are numerical sensitivity conditions, not a
scientifically qualified exposure range. Duplicate conditions are not replicates.

Unknown fields, human/cohort context, other materials, parameter overrides, missing
units, booleans, numeric strings, nonfinite numbers and out-of-domain inputs fail
before result creation. The API does not echo rejected payload values.

## Discrepancy preserved, not fitted away

At 0.25 uM inhibitor, the source-parameterized equation predicts apparent Km
**0.1685106383 uM**. The same paper's lobeline kinetic analysis reports **0.29 uM**
(SEM 0.064 uM). The exported difference is **−0.1214893617 uM**. That kinetic
analysis also reports Vmax 50.2 (SEM 7.80), while this competitive calculation retains
the control Vmax of 46.7. Both summaries remain in the source record.

No parameter is refitted. The comparator is a separate kinetic summary from the
same paper, not independent laboratory replication. Raw replicate data, covariance
and a prospectively justified acceptance criterion are unavailable. Consequently,
the software reports `UNQUALIFIED_DISCREPANCY`, not statistical significance, a
confidence interval, assay qualification or human equivalence. Published SEM is
not sampled as person-specific variation.

For an arithmetic check at S=0.1 uM, the expected model rates are 22.2380952381
without inhibitor and 17.3922345483 at I=0.25 uM, in pmol/min/mg protein. Tests also
check zero substrate, half-maximum at uninhibited Km, positivity, monotonicity,
constant high-substrate limit and nM/uM equivalence. These are software/equation
checks, not wet-lab results.

## Prepare, run, inspect and export

Save this specification as a local `lobeline-assay.json` using an editor:

```json
{
  "material_id": "lobeline-hemisulfate",
  "context_id": "rat-striatal-synaptic-vesicles",
  "concentration_unit": "uM",
  "substrate_concentrations": [0, 0.001, 0.1, 0.11, 1, 5],
  "inhibitor_concentrations": [0, 0.25]
}
```

Use the configured local installation and authenticated server described in the
[launch guide](LAUNCH_GUIDE.md). No real-person enrollment is needed for this assay.
Do not change the user's operational data directories for a demonstration; use
the approved isolated review stack for testing or recording.

```text
livemore attach
protocol lobeline /absolute/path/lobeline-assay.json
protocol history q=lobeline
protocol show <returned-run-id>
protocol prepare <returned-run-id>
protocol rerun <returned-run-id>
protocol export <returned-run-id> notebook=/absolute/new/path/lobeline-analysis.ipynb
```

`prepare` is read-only. `rerun` creates a new immutable run and retains the parent
digest; it does not overwrite the original. Changed conditions or changed source
record require explicit `new_configuration=true`; they are no longer an exact
reproduction. Notebook export refuses to overwrite an existing file.

The SDK uses the same attached-server contract:

```python
import json
from pathlib import Path
from livemorebio.sdk import Platform

platform = Platform(mode="attach")
specification = json.loads(Path("lobeline-assay.json").read_text())
run = platform.run_lobeline_vmat2(specification)
print(run["run_id"], run["benchmark_discrepancy"])
```

Aegle POST: `/api/cendos/protocols/lobeline-vmat2`.
Direct authenticated Cendos POST: `/protocols/lobeline-vmat2`.
Both invoke the same executable module and immutable store. Browser and SDK exports
are `/api/cendos/protocols/<run-id>/analysis.csv` and `/analysis.ipynb`; direct Cendos
exports omit the `/api/cendos` prefix. No credentials belong in URLs, examples or
recorded screens.

CSV preserves each requested concentration point, rate, units, source digest and
the separate published-parameter comparison. The notebook embeds a hashed frozen
run and independently recomputes rates and the discrepancy, then plots the native
concentration axis. Execute its cells in Jupyter; generating a notebook alone is
not analysis execution.

## Visual and qualification boundaries

The Biology inspector may display a **reference VMAT2 transport diagram** and the
frozen calculated concentration plot. Selection changes may highlight the recorded
condition. They must not manufacture an atomistic trajectory, flowing human
dopamine, clinical improvement, person-specific response or a biological clock.

Next scientific increment: obtain a lawful independent assay dataset with material
identity/lot, species/preparation, substrate and inhibitor concentrations, protein
normalization, uptake method, timestamps, controls and raw replicate custody.
Prespecify endpoints, tolerances and the discrepancy investigation before looking
at new results. A separate validation protocol is required; the current generic
member-based clinical evidence workflow is intentionally not applied to these
nonhuman concentration conditions.
