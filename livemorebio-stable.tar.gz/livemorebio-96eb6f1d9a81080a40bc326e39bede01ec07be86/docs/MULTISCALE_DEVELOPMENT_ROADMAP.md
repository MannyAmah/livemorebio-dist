# Multiscale biology, LIFE Patch and physical Cendos development roadmap

Planning baseline: September 5, 2026. This is a development roadmap, not a claim that the listed biology, hardware or laboratory is already operational. It complements the [biological model-change contract](BIOLOGICAL_MODEL_CHANGE_CONTRACT.md), [Human-GEM source contract](HUMAN_GEM_MODEL_SOURCES.md), and [LIFE Patch closed-loop contract](LIFE_PATCH_CLOSED_LOOP.md).

## 1. Product objective and present boundary

Build an executable, cross-scale human biology system that earns context-specific functional equivalence through independent measurements. Complete anatomical coverage is the organizing framework. It is not evidence of complete mechanistic coverage, an atom-by-atom living person, or unrestricted transfer of a computed intervention to a human.

Current architecture includes contracts for all 15 registered systems in `livemorebio/multiscale.py`. Some systems expose existing cardiac, glucose/insulin or drug-exposure computations; other contracts explicitly report unavailable behavior. Naming a state variable does not supply its dynamics, identifiable parameters or empirical qualification.

This candidate adds a separate, executable Human-GEM v2.0.0 network-capacity protocol. It uses 12,931 reactions, 8,461 metabolites, 2,848 genes and nine compartments, with a pinned source package. Under the explicit tested glucose/oxygen constraints, the network has ATP-maintenance capacities of approximately 2 and 31.5 mmol/gDW/h. Complete ATP5F1B knockout gives approximately 2 and 4 in those conditions. Numerical conservation, negative controls and GPR behavior pass. These are model characterizations, not measured physiology or clinical validation.

No automatic bridge from this generic network capacity to an individual's glucose, cardiac rate, drug response or LIFE Patch observations is enabled. The old unrestricted Recon/Human-GEM helper paths are retired. Recon3D commercial execution remains blocked. Physical LIFE Patch conformity, an operational Cendos wet lab, and physical equivalence of the whole platform have not been demonstrated in this build.

## 2. Acceptance ladder

Keep these gates separately visible in the API, terminal, notebooks and interface:

| Gate | Required deliverable | What it establishes |
|---|---|---|
| Architecture | Named module, exact interfaces, missing-state semantics and owner | Where a biological function belongs |
| Executable | Versioned equations/reaction network, source permission, units, solver and deterministic input contract | Software can calculate the declared quantity |
| Numerically verified | Conservation, positivity, boundary conditions, solver status, convergence, failure controls and replay tests | Calculation obeys its declared mathematics |
| Calibrated | Admitted fitting data, parameter identifiability, estimation method and independent validation split | Parameters were estimated for a declared context |
| Empirically qualified | Frozen context of use and acceptance criteria, independent measurements, uncertainty and failure analysis, independent review | A bounded predictive claim is supported |
| Replicated | Another operator/site/instrument/population reproduces the prespecified result | Evidence extends beyond the original experiment |
| Deployment released | Security, quality, usability, operational and applicable regulatory review | The specific intended use can be deployed under its release controls |

Do not compress this ladder into a single green “validated” badge. FDA's computational-model credibility guidance describes a risk-informed assessment for device submissions; it is useful input to the assurance process, not blanket approval of Livemore or of pharmaceutical uses. A regulatory lead must define the applicable path for each intended use. [FDA credibility guidance](https://www.fda.gov/regulatory-information/search-fda-guidance-documents/assessing-credibility-computational-modeling-and-simulation-medical-device-submissions).

## 3. Contract every biological module before adding behavior

Each release packet must include the following, with explicit unavailable fields where evidence is missing:

1. **Identity:** model/version/source digest, species, anatomy and compartment identifiers, cell type, mechanism and context of use. Resolve identifiers without converting an association into a causal coefficient.
2. **State and units:** distinguish extensive amounts from concentrations, free from total compound, intracellular from extracellular, flux from pool size, and activity from abundance. Record compartment volumes and dry-weight normalization when needed.
3. **Dynamics:** equations or reaction network, algebraic constraints, initial and boundary conditions, solver tolerances, event rules, valid domain and numerical failure behavior. State whether the result is steady-state, equilibrium or time-evolving.
4. **Person parameters:** value, unit, uncertainty, source record, measurement time, QC, fitting version and applicability. Labels such as age, diabetes or a gene name cannot silently select invented fluxes or expression values.
5. **Ports:** named incoming and outgoing quantities, units, compartment, direction, timestamp/interval, latency budget, missingness, uncertainty and ownership. Every unit conversion must be testable and recorded.
6. **Perturbations:** material identity, route, dose, concentration or exposure, mechanism and permitted range. Complete gene knockout is not a heterozygous-variant model. A target association is not a concentration-response curve.
7. **Observation operator:** what a specific physical sensor or assay would measure from the model state, including delay, spatial sampling, noise, bias, saturation and QC. Do not make an unmeasured variable look observed.
8. **Qualification:** reference benchmark, fitting/held-out split, subgroup coverage, uncertainty, acceptance rationale, contradictory evidence, independent reviewer and rollback criteria.

The existing multiscale variable lists are starting contracts, not an exhaustive biochemical specification. For example, a unitless placeholder for beta-cell responsivity must be replaced by the selected equation's dimensional definition before that port is used across engines.

### Coupling rules

Use one owner for each conserved pool and transfer flux. If liver uptake removes an amount from blood, the corresponding amount enters the liver or a declared elimination route exactly once. Check mass, charge and volume balances, not just agreement of plotted values.

Fast electrophysiology, organ transport and slow remodeling need different numerical steps. Define an exchange clock, interpolation policy, delayed observations and event ordering; demonstrate that reducing the coupling interval does not change the quantity of interest beyond its prespecified numerical tolerance. An animated rendering clock is not a biological integration clock.

Human-GEM `mmol/gDW/h` cannot be connected directly to blood `mg/dL`. Such a bridge needs tissue/cell context, dry mass, compartment volume, transport, substrate availability, operating objective and independent evidence. Until then, keep the network experiment separate from a person model.

At atomic and molecular scales, use the resolution appropriate to the question. A local binding or chemical-reaction calculation requires protonation, stereochemistry, solvent, energy model and uncertainty. Its output must pass an explicit coarse-graining step before entering a cellular model. No universal atomistic human engine is claimed or scheduled as a near-term deliverable.

## 4. All 15 registered systems: staged executable coverage

The following are proposed development quantities and tests, not measurements produced by the current platform. Times describe the phenomena to cover, not promised acquisition rates. P1 is the first coupled qualification slice; P2 expands homeostasis; P3 extends tissue, immune and organism coverage. Sequence within each phase follows evidence availability and dependency gates.

| Registered system | Priority and next executable function | State, units and times | Required coupling and individualization | Independent evidence gate |
|---|---|---|---|---|
| Cardiovascular | P1: ventricular electrophysiology plus pressure/flow circulation; do not infer pump function from a beat animation | Voltage mV; ionic concentration mmol/L; pressure mmHg; volume mL; flow mL/min; milliseconds to days | Calcium and ATP-demand interfaces, autonomic input, blood oxygen, renal volume; measured geometry and appropriate channel/contractility parameters | Held-out voltage/APD and ECG endpoints separately from pressure/flow endpoints; pacing and hemodynamic challenges; documented uncertainty |
| Endocrine | P1: deepen glucose-insulin control; P2: add glucagon, stress and thyroid axes separately | Glucose mg/dL or mmol/L with explicit conversion; insulin pmol/L or assay-specific units; hormones with analyte-specific units; seconds to months | Gut appearance, hepatic production, muscle/adipose uptake, renal clearance, circadian timing; admitted endocrine measurements and identifiable parameter fits | Meal/OGTT or clamp data in a declared population; delayed/held-out trajectories; no biomarker shortcut for beta-cell mass |
| Digestive/hepatobiliary | P1: oral absorption and hepatic exposure; P2: transport, secretion and metabolic routing | Compound amount mg or µmol; free concentration µmol/L; clearance L/h; bile flow mL/min; seconds to months | Gut transit, food effects, portal circulation, liver compartments, renal elimination; measured binding/transport/enzyme context | In-vitro transport/metabolism plus independently held-out PK; mass recovery; distinguish whole-extract effects from purified compounds |
| Urinary | P2: filtration, secretion/reabsorption, fluid/electrolyte and acid-base regulation | GFR mL/min; indexed eGFR mL/min/1.73 m² kept distinct; urine flow mL/min; solutes mmol/L; seconds to years | Perfusion, blood volume, endocrine feedback, transporter exposure; renal function and body-surface area from admitted records | Clearance and urinary excretion data; electrolyte/fluid challenges; validated mapping before scaling drug clearance |
| Nervous | P2: autonomic feedback first; P3: selected neural circuits and disease mechanisms | Membrane voltage mV, current pA, firing Hz, transmitter concentration mol/L; milliseconds to years | Cardiovascular/baroreflex, endocrine stress, respiration and motor output; circuit-specific anatomy and observed functional parameters | Circuit-level and autonomic tests separately; latency/gain and stress response; no inference of whole cognition from a small neural model |
| Respiratory | P2: ventilation/perfusion and blood gas exchange | Gas volume L, flow L/min, partial pressure mmHg, compliance L/cmH₂O; milliseconds to days | Cardiac output, blood hemoglobin, acid-base balance, neural drive; spirometry and gas-exchange context | Held-out gas tensions and ventilation challenges; sensor oxygen saturation is not a direct measure of every respiratory state |
| Blood/hematopoietic | P2: oxygen carriage and blood volume; P3: hematopoiesis/coagulation modules | Hemoglobin g/dL, cell counts cells/L, O₂ content mL/dL, coagulation factors in assay-specific units; seconds to months | Respiratory gases, vascular flow, marrow production, renal erythropoietin and immune effects | Blood counts/gases and analyte-specific laboratory controls; oxygen content and saturation tested as different quantities |
| Lymphatic/immune | P3: antigen/cell-state and cytokine dynamics with lymph transport; memory as an explicit state | Cell populations cells/mL, cytokines pg/mL, lymph flow mL/min; seconds to years | Tissue drainage, trafficking, marrow, endocrine modulation and persistent clones; cell/subtype and assay-specific baseline | Independent immune phenotyping and time-course assays; distinguish cytokine suppression from removal of pathogenic memory |
| Muscular | P2: substrate use and activity demand; P3: excitation-contraction and force | Force N, activation fraction, length m, ATP turnover mmol/gDW/h with tissue mapping; milliseconds to months | Neural activation, perfusion, glucose/fatty-acid delivery, skeletal loading; measured muscle mass/geometry and capacity | Force/EMG and metabolic readouts with separate observation models; activity labels alone cannot set ATP demand |
| Skeletal | P3: joint mechanics and bone remodeling | Load N, stress Pa, geometry m, areal density g/cm² versus volumetric density g/cm³; milliseconds to years | Muscle forces, endocrine regulation, mineral pools and inflammation; imaging-based geometry and material uncertainty | Mechanical benchmarks, imaging and longitudinal remodeling; do not equate a single density value with fracture behavior |
| Integumentary | P1: Patch contact and surface measurement model; P3: barrier, thermal and wound response | Temperature °C, sweat flux mg/cm²/min, skin impedance Ω, heat flux W/m²; seconds to days | Local perfusion, environment, hydration, sweat transport and device contact; site, pigmentation/contact and skin condition | Bench/contact phantoms followed by approved paired measurement studies; skin temperature is not automatically core temperature |
| Special senses | P3: choose one modality and receptor-to-circuit path | Voltage mV; stimulus units specific to light, sound, mechanical or chemical modality; milliseconds to years | Peripheral receptor, neural circuit, local vascular/metabolic support; modality-specific anatomy and thresholds | Modality-specific physiological/perceptual measurements; no generic unitless stimulus used as a universal sensory input |
| Reproductive | P3: hormone feedback and cycle-dependent physiology; pregnancy as a separate qualified context | Named hormones with assay units, compartment volumes, phase/time; seconds to years | Endocrine, vascular, renal and developmental state; recorded sex-related anatomy, stage, contraception/pregnancy context as relevant | Longitudinal hormone and organ-specific endpoints; no extrapolation from nonpregnant adult models to pregnancy or development |
| Microbiome | P3: community substrate transformations and host exchange | Taxon abundance fraction, absolute biomass when available, metabolite amount/flux; minutes to years | Gut substrates, microbial metabolites, host absorption and immune response; assay/site, diet and strain context | Community composition plus independent metabolite/flux data; relative abundance cannot by itself determine absolute biochemical flux |
| Interstitial/fascial | P2: interstitial fluid transport; P3: matrix mechanics, fibrosis and repair | Pressure mmHg, fluid volume mL, matrix stiffness kPa, solute concentration mol/L; milliseconds to years | Capillary exchange, lymph drainage, cells, renal fluid state and wound/fibrotic memory; tissue geometry and material parameters | Transport and mechanical assays/imaging; separate fluid redistribution from structural matrix remodeling |

A system cannot advance because a neighboring system advanced. Every port used by a coupled claim must meet the required gate for that claim. An unavailable port must block the calculation or trigger a declared restricted context, never silently substitute a “healthy” value.

## 5. Model and tool integration sequence

### P1: reproducible cardiac-metabolic research slice

1. Freeze existing equation implementations, assumptions and independent benchmark datasets. Keep metformin PK, heuristic PD, glucose dynamics and any cardiac effect mapping separate in the evidence record.
2. Select one CellML cardiac model and one glucose/insulin model based on the context of use, source data and licensing. Reproduce the upstream benchmark before changing parameters or coupling. The [CellML project](https://www.cellml.org/getting-started/faq) documents model provenance/metadata, while [OpenCOR](https://opencor.ws/) provides a candidate execution environment. The Physiome welcome URL returned an access error during this check; no new Physiome artifact was admitted on that basis.
3. Keep Human-GEM as a separately constrained network analysis until an experimentally justified tissue operating model exists. Add sensitivity and identifiability analysis before any person-parameter bridge.
4. Qualify an observation mapping and one paired physical endpoint. Then assess the coupled quantity of interest on data withheld from both component fitting and coupling design.

### P2 and P3: bounded tools, not an unrestricted plugin mesh

Evaluate [COPASI](https://copasi.org/) for explicitly specified biochemical reaction networks and parameter estimation; its documentation describes those analysis capabilities. Consider [SED-ML](https://sed-ml.org/) for interoperable numerical experiment descriptions. Neither tool makes a missing rate constant, individual profile or validation dataset appear. Pin the selected tool version, exported model, algorithm settings, permitted use and benchmark results before admission.

Reference graph backends may organize reaction, gene, disease and evidence relationships. They are not equation solvers. A KEGG or MalaCards cross-reference must retain its source and entitlement boundary; it cannot become an enzyme rate or a predicted disease response. Neo4j/TuringDB adoption still requires operational, access-control, durability, benchmark and license gates. No external graph write is implied by the current bounded Human-GEM projection.

Rosalind/Jupyter workflows should receive only authorized datasets and frozen run artifacts, with environment lockfiles, code hashes and output lineage. Remote processing of PHI-like data needs an approved data boundary and contractual controls. OpenMed is an intake/extraction candidate, not a complete human dataset, replacement physiology engine or source of invented patient records.

## 6. Individual twins and cohorts

For real-human onboarding, preserve consent scope, identity separation, source authorization, medical history, labs, medications, wearables, genomics when available, lifestyle and environmental context. Do not interpret a source category checkbox as complete coverage. Distinguish prescribed, reported and actually administered medication; record measurement time, units, method, reference range, QC and missingness.

FHIR R4 is the planned clinical exchange target, not a claim that every EHR already connects. Define profiles for the particular resources and terminologies used, validate conformance and retain source Provenance/observation identity. HL7 defines FHIR as a healthcare information exchange standard; clinical validity remains a separate concern. [FHIR R4 overview](https://www.hl7.org/fhir/R4/overview.html).

For reference-initialized twins, record the lawful dataset release and derivation. Estimate joint distributions and preserve supported covariances, missingness and exclusion criteria; independently sampled marginal priors do not establish representative cohorts. Assign each record a stable identity and version. Changing the active twin must not mutate the stored profile or silently retune validated models.

For cohort experiments, freeze inclusion/exclusion rules, member roster, per-member parameters, source hashes, intervention and endpoint definitions. Keep sample size separate from repeated samples or technical replicates. Retain failures and subgroup coverage. Reference-initialized synthetic members are not enrolled human participants and must not be described as observed clinical trial data.

## 7. LIFE Patch hardware, firmware and virtual parity

### Reconcile the engineering authority first

The inherited `docs/hardware/LIFE_Patch_Build_Package.md` contains obsolete A.1 wiring and component claims. It is not fabrication or human-use authority. The referenced “Describe Human Biology Systems” handoff describes a corrected B0 EVT target; the checked local closed-loop document agrees with that target. Obtain and reconcile the complete revision-controlled schematics, PCB files, BOM, firmware source, risk file and test records before any build release.

The MAX86141 supports SPI; the older I²C/0xC4 instruction must not survive into the released design. DS28E18 is a communications bridge, not the pod authenticator. DS28C36 is the stated authentication candidate. Verify every rail, pin, electrical limit and footprint against the exact manufacturer revision rather than copying this roadmap as wiring instructions. [MAX86141](https://www.analog.com/en/products/max86141.html), [DS28E18](https://www.analog.com/en/products/ds28e18.html), [DS28C36](https://www.analog.com/en/products/ds28c36.html).

### Deliverables and release gates

| Stage | Hardware and software deliverables | Exit evidence |
|---|---|---|
| H0: design control | One authoritative B0 package; hazard analysis; sensor/channel claims; power and charging policy; firmware/device-contract version matrix | Independent electrical, firmware and assay review; old contradictory instructions visibly quarantined |
| H1: bench acquisition | Drivers, acquisition scheduler, monotonic sequence/timebase, calibration tables, FIFO/buffer handling, contact/QC flags and signed raw-data export | Traceable electrical/optical/temperature standards and fault-injection results; no human connection needed |
| H2: secure device software | Provisioned device keys, authenticated pairing, signed updates, rollback/recovery, watchdog and local command bounds | Invalid signatures, replay, rollback, power loss, buffer overflow, disconnection and key revocation tested |
| H3: virtual/physical parity | Shared manifest/schema; hardware-specific transfer functions; timestamp, noise, latency, saturation, dropout and sensor-placement models | Same canonical test vectors through firmware/gateway/virtual parser; paired bench recordings and prespecified per-channel residual tests |
| H4: wear and assay evaluation | Mechanical/adhesive, thermal, electrical, battery, cleaning, usability and channel-specific assay evaluation | Approved test plans and independent qualified laboratory evidence; research/clinical oversight before human studies |
| H5: intended-use release | Manufacturing tests, device history, calibration lifecycle, fleet management, incident response and approved claims | Quality, security and applicable regulatory review; no release by software test count alone |

Evaluate [Zephyr device firmware upgrade](https://docs.zephyrproject.org/latest/services/device_mgmt/dfu.html) and [MCUboot](https://docs.mcuboot.com/) for firmware infrastructure. Their documented compatibility and image-management capabilities make them candidates, not already integrated LIFE Patch firmware. Pin compatible versions and exercise the actual board's recovery and key-provisioning workflow.

The virtual device must compute the observation expected from the same sensor contract, not publish internal twin variables as if they were measured by hardware. A matching capability hash proves schema agreement only. Physical parity requires paired measurements, sensor transfer characterization and uncertainty over the declared operating domain.

Keep device-origin observations immutable. State estimation may propose a hidden-state update with residuals and uncertainty; model parameter or equation changes require the model-change gate. Proposed commands must terminate in local safety limits and auditable receipts. The current v2 contract rejects therapeutic actuation. Drug delivery, stimulation and other interventions require separate hardware and clinical control development; the cloud must not bypass a local safety controller.

Sweat or interstitial-fluid chemistry remains analyte/cartridge-specific. Genetics, general disease processes, drug effects and internal organ state are not automatically sensed continuously by this patch. Identify which signals are measured, derived, externally supplied or unavailable for every channel.

## 8. Physical Cendos laboratory and software

No wet-lab instrument, facility, staffed laboratory or qualified physical assay is established by this candidate. The physical program should begin with a narrow assay partnership or facility workflow before investing in broad automation.

### C0: materials and protocol authority

Select the biological question and assay endpoint before selecting a plant outcome. Record authenticated botanical identity, voucher/source, plant part, preparation/extraction, lot, storage and contamination tests. For a purified compound, retain structure/stereochemistry, analytical identity, purity, concentration, stability and batch traceability. Whole extract, fraction and purified molecule are different test articles.

Prespecify exposure range, vehicle and positive/negative controls, assay interference checks, viability/cytotoxicity checks, biological versus technical replicates, randomization/blinding, exclusion rules, endpoint, normalization and analysis. Domain scientists must approve the actual experimental methods and safety requirements. No desired efficacy result is hard-coded.

### C1: LIMS/ELN and instrument intake

Implement immutable sample/material IDs, sample custody, plate/well mapping, instrument identity, calibration/maintenance records, methods, raw-file digests, acquisition timestamps, operator identity, deviations and signed review. Separate a specimen's identity from a twin/member identity; mappings are explicit and frozen, never inferred from row order or labels.

Use an instrument adapter layer with read-only acquisition first. Evaluate [SiLA 2](https://sila-standard.com/) where supported to connect instruments to informatics systems. A vendor export parser can be the first adapter when it preserves raw data and provenance. Adding a liquid handler or plate reader requires device-specific command validation, local interlocks and a manual emergency-stop path before automation is permitted.

LIMS stores materials/specimens and execution records; ELN stores rationale and protocol narrative; the evidence registry binds independently measured endpoints to frozen predictions. They must not overwrite one another's provenance. Encrypted, tenant-isolated, role-authenticated storage, audited access, backup/restore testing and least-privilege instrument credentials precede any PHI-like physical intake.

### C2: first comparative assays

Start with purified-compound receptor or enzyme assays whose outputs can be measured independently, with identity/exposure and interference checks. A PXR engagement prediction must not be compared to a downstream CYP3A4 endpoint as if they were the same quantity. Metformin glucose dynamics need a declared physiological context and separate exposure/PK evidence; a cell assay alone cannot validate an entire person's glycemic trajectory.

For Human-GEM ATP capacity, design a new cell/assay-specific protocol with dry-mass normalization, measured medium and oxygen availability, maintenance/biomass assumptions, ATP-production measurement mapping and intracellular storage context. Oxygen consumption is not itself an ATP-production measurement. A living cell with stored substrates may produce ATP without external glucose, so the software's closed-network control is not automatically the correct physical negative control. The current member-based Research comparison remains blocked for this protocol.

### C3: analyze without contaminating validation

Export frozen raw and processed data to a pinned local notebook/workbench environment. Keep model outputs and physical measurements in different tables and evidence classes. Compare prespecified endpoints with uncertainty and retained QC failures. Do not refit and validate on the same data; a revised model creates a new version and new prospective test.

After one context qualifies, repeat with a different operator/site and expand populations, disease states, exposure ranges or materials deliberately. Research on taurine or new botanical compounds enters this same material/mechanism/measurement process. A publication, ancient use or plant origin does not establish therapeutic potency, safety or a whole-body response.

## 9. Disease memory and treatment-free resilience

Maintain the founder's five-operation cure hypothesis as a falsifiable research program: extinguish a driver, assess pathological memory, repair lost tissue, restore homeostasis, and test treatment-free resilience. Define disease and healthy regions with measurable endpoints and age/person context. Absence below an assay's detection limit is not proof that every reservoir, pathological seed or cell clone is gone.

For each disease context, specify applicable memory mechanisms, detection limits, withdrawal/washout, follow-up window, stress challenges, competing explanations and independent-subject analysis before intervention selection. A model should preserve relapse mechanisms unless evidence supports their removal. The current resilience evaluator does not confer lifetime cure or replace a physical clinical protocol.

## 10. Continuous biology learning as product engineering

Every contributor must complete the model-change packet, not merely read a syllabus. Start at the mechanism being changed and trace its molecular, cellular, tissue, organ and whole-body interfaces. Record primary sources, contradictions, extraction provenance and assumptions in the learning ledger. Test comprehension by reproducing a benchmark and explaining where the model should fail.

New publications and physical residuals produce versioned proposals. They do not automatically retrain deployed biology. Any learned component needs training-data permission, data leakage checks, independently withheld evaluation, uncertainty/OOD behavior and release review. Reinforcement learning additionally needs a defined action space, reward, constraints and offline safety assessment; self-generated outcomes cannot serve as independent evidence of human equivalence.

## 11. Next build decisions and blockers

The immediate next vertical slice should be one frozen cardiac-metabolic context, one independently justified observation mapping and one paired physical endpoint. Keep the Human-GEM network experiment separately usable while the tissue/physiology bridge is developed and measured.

Before selecting that slice, obtain:

- A pharmaceutical partner's intended-use statement, target population, intervention/exposure and decision endpoint.
- Qualified biological, assay, firmware/electrical, quality, security and regulatory owners with independent review responsibility.
- Lawful independent reference and held-out experimental datasets, not only literature descriptions or model-generated samples.
- The authoritative B0 hardware package and evidence of what has actually been fabricated, flashed and bench-tested.
- A physical laboratory/instrument partner, material characterization, assay methods and raw-data access.
- A deployment data boundary, tenant/role model, encryption/key management and approved PHI handling.

Until those inputs and gates are satisfied, the defensible deliverable is executable research infrastructure with explicit unqualified boundaries. The long-term objective remains progressively measured biological correspondence, not a more convincing animation.
