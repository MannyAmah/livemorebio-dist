# Correction-first candidate: verification record

Date: 2026-09-08. Branch: `codex/measurement-integrity-atlas`.
Preserved base: `5c71ee8e0a643b4be11bac0fe65712494449be56`.
Product implementation checkpoint: `21db5b3`; clean browser-QA starting checkpoint:
`9629f9c`. Product/evidence checkpoint: `75ba51f43e688a72242e721e954c00171d794d80`.
Later recording/documentation changes do not modify the biological kernels.

**Scope:** verified software behavior in a local research environment. This is not
a pharmaceutical production release, wet-lab validation, sensor qualification or
proof of equivalence to a living human. No physical participant was enrolled.

## Automated verification

Full isolated suite:

```bash
LIVEMORE_TEST_GENOME_MODELS=1 LIVEMORE_TEST_MODEL_DIR=/absolute/verified/model-cache \
  /absolute/python3.11 -B tools/run_review_tests.py -q -rs
```

Result: **1,033 passed, 44 subtests passed, 1 skipped, 5 warnings, 243.76 seconds**.
The skipped test is the optional repeat official-network download in
`test_model_assets.py`; both pinned Human-GEM execution tests ran and passed.
Warnings concern inherited FastAPI/httpx deprecations and noninteractive plot
display in two notebook-code tests. Compilation and changed JavaScript syntax
checks passed. Earlier red runs are not hidden: regressions exposed real defects
and obsolete UI/error-copy expectations; those were corrected before this run.

Coverage includes v2 golden hashes, additive v3 strict validation, local journal
concurrency/replay, clocks/sessions, safe commands, signed subject/device admission,
PHI-safe rejected-input errors, immutable prediction alignment, no automatic twin
calibration, source/freshness projection, typed run inspection, source-backed assay
controls, frozen history/reruns, exports, onboarding and existing model workflows.

Human-GEM: version 2.0.0, upstream commit
`635f533152dc5f7290ce04d12700eaa882273c3e`; XML SHA-256
`cc5a4383c6116b0c91f4db089cc640f29aec7e840249b573b74d3792c9ca4a7a`.
The original model cache was read-only for tests. A separately copied and verified
private cache was used by the review services. No reference asset was modified.

## Fresh installation

An independent reviewer created `/tmp/livemore-fresh-venv.lSTVr3/.venv`, Python
3.11.15, with system site packages disabled. The guide's hash-locked requirements
and no-dependency editable installation both succeeded. `pip check` reported no
broken requirements. From outside the checkout, isolated Python imported nine
new/preserved modules and verified eight console assets and eight LIFE seed files.
CLI help and attach help passed. A fresh-environment isolated subset passed
**130 tests in 0.98 seconds**.

The release owner also attached this fresh environment's terminal client to the
isolated review service and ran `protocol history q=lobeline`. It returned the
actual six saved review records without a token-copy prompt or mutation.

Dependency-lock SHA-256:
`979917b5661a35cfaa3f65ba60e194a9b397566d96001200de4a26b0ec96f2a4`.
The host already had clang/CVODE prerequisites. This is a fresh editable-environment
test, not a clean operating-system test or proof that a newly published installer
has run on another machine. The original installed `current` pointer and shell
profile were not changed.

## Independent review

Separate owners reviewed wire, science, interface and integration work. No maker
was the only reviewer of their own implementation. Independent checks included:

- 143 tests and separately constructed packets confirming replay/session/channel
  corrections, safe local-store failure and v2 compatibility.
- Six malformed-request probes covering all five LIFE mutation boundaries with
  fixed error categories and no rejected-input echo.
- Execution of the actual upload controller with a failed response, proving that
  it reports uncertain admission and retains original duplicate-key input bytes
  for server rejection.
- Original-paper parameter and applicability review for lobeline. The contradictory
  kinetic summary is retained without refitting or scientific qualification.

The optional Codex CLI adversarial-review attempt could not run because the
installed CLI was too old for its configured model. No result is attributed to
that failed attempt. The actual independent reviewers above supplied the review.

## Real-browser acceptance

Only isolated `http://127.0.0.1:8890` (Aegle), `:8891` (LIFE), `:8892` (Cendos)
were exercised. Operational ports 8850–8852 and their stores were untouched.
Formal QA began from a clean saved checkpoint. gstack's installed source browser
was used because its packaged binary was unavailable on this host.

Verified directly by the release owner:

- Atlas whole-person orientation remains separate from standalone organ meshes.
  Recorded time advances readouts and plots from saved samples; Patch evidence
  does not label a missing or virtual observation as measured.
- Atlas cardiomyocyte selection opens the same captured model context in Biology,
  including recorded voltage/calcium samples. The optional 3D renderer was
  unavailable in this browser; numerical/cellular fallback worked. This is **not**
  a passed registered-3D-assembly or full visual-design acceptance test.
- Cendos rejects blank concentration entries rather than turning them into zero.
  Valid lobeline preparation executes and links the exact saved run to Biology.
  Run `protocol-433fea6749af4d3ab2df1700c928fd4a`: at inhibitor 0.25 µM and
  substrate 0.1 µM, selected modeled rate 17.39223 versus control 22.23810
  pmol/min/mg protein; apparent Km 0.1685106 µM. These are calculations, not
  independently measured assay observations.
- Desktop and 390-pixel assay layouts fit without page-wide horizontal overflow.
  The narrow plot is small; the same numeric values remain in accessible readouts
  and an expandable table.
- Cendos Human-GEM execution completed from its actual preparation form. Run
  `protocol-f8499956f08545d2aa9de935a03e572c`: glucose cap 1 and oxygen caps
  0/2/6 produced ATP capacities 2/12/31.5 mmol/gDW/h; both negative controls
  produced zero and passed. Condition selection in Biology retained exact values.
- A nonexistent run produced an explicit unavailable/retry view, never a fallback
  to an unrelated active twin. Its deliberate 404 is expected test evidence.

Independent LIFE prepared-file checks also passed. See the
[complete report](screenshots/measurement-integrity-atlas/final-qa/life-patch/qa-report.md),
[round-trip evidence](screenshots/measurement-integrity-atlas/final-qa/life-patch/roundtrip-evidence.json)
and [retained journal evidence](screenshots/measurement-integrity-atlas/final-qa/life-patch/journal-evidence.json).

- Missing file, malformed JSON and a physical-mode packet were rejected before
  submission by the virtual-only form. An unbound subject was rejected with 409.
- A registered/bound v3 **technical fixture**, not a physical measurement, was
  admitted with 202 and delivered LIFE → Aegle. Atlas and Patch retained the same
  72 bpm value, source class, digest, measurement context and original receipt.
- Replaying the same file returned 422 and left exactly one journal entry. Twin
  parameters remained unchanged before admission, afterward and after replay.
- No admitted transfer mapping existed: `MAPPING_UNAVAILABLE` and a null residual
  were retained, rather than inventing a comparison or calibration.
- The 390-pixel form and statuses fit without horizontal page overflow. No
  application JavaScript exception occurred; deliberate 409/422 responses were
  expected negative-test evidence.

The native operating-system file picker remains **untested**: the browser tool's
upload command failed before reaching the app. The reviewer populated the actual
DOM File input with File/DataTransfer and clicked the actual Admit button, testing
File.text, JSON validation and HTTP admission. This limitation is not represented
as a full native-picker pass. Fixtures, inputs, seven screenshots and review receipts
are retained alongside the report; no credentials or real-person records are included.

## Recording and analysis evidence

Both final captures completed against the isolated review stack. The
[evidence index](demo/measurement-integrity-atlas/README.md) links the MP4s, exact
run JSON/CSV, original and executed notebooks, HTML analysis, chapters, screenshots,
timestamped actions and manifests.

| Workflow | Native duration | Frozen run | Notebook execution |
| --- | --- | --- | --- |
| Lobeline–VMAT2 rat-vesicle assay | 4:35 (275.000 s) | `protocol-2e5e4a70ee1d4a5e935e33cbb9fe6d6c` | 3 code cells; no errors |
| Metformin, two varied four-member research-prior cohorts | 5:26 (325.960 s) | `protocol-dcbc15ed14e7422ab6ad0f3e5ac3f6c9` | 3 code cells; no errors |

These are native 1600×1000 browser recordings, not screenshot slides. Typed
preparation, actual execution, selected conditions/members, results, history recall,
rerun preparation and analysis are visible. H.264 conversion does not change speed.
There were zero browser page errors and zero mutations during Biology inspection,
history recall or rerun preparation. Metformin created two non-person cohorts and
one run; lobeline created one isolated assay run. No physical observation was invented.

Final MP4 SHA-256:

```text
lobeline:  e61bba0eb1295bbdefd6a0c190d3fe17d18ed66216a5eafde62194c484041eea
metformin: 9f84f4fde11875e0fb0fb38e64136c7d244714429adc9dda544e276621b70ca2
```

Final exported notebooks executed in a fresh isolated Python 3.11.15 Jupyter kernel.
The recording shows browser inspection of the executed HTML export, not a live
interactive Jupyter session. No generated plot is substituted for execution.
CSV files do not all embed a run ID: retain the run-specific export URL and the
recording manifest's run-ID/file-hash binding together with the frozen notebook.

An independent final artifact reviewer verified all 12 manifest hashes against
filesystem and Git bytes, video duration/codec/resolution, notebook source identity
and execution counts, action statistics and the stated numerical ranges. No
credentials or real-person payloads were found in the 19 recording text artifacts,
eight published recording screenshots or eight members' synthetic provenance.
Video inspection sampled extracted frames rather than every frame. Raw/preflight
captures are retained locally and excluded from the publication. All 33 local
Markdown file links across the three new guides resolved at the evidence checkpoint.

## Release and scientific gates

- Published [PR #7](https://github.com/MannyAmah/livemorebio/pull/7) targets
  `codex/genome-models-clean-workflows` at the preserved base, not main. No merge
  or deployment occurred. GitHub reports the branch mergeable.
- Hosted [Ubuntu/macOS installer and release gates](https://github.com/MannyAmah/livemorebio/actions/runs/34195699453)
  were queued/running at publication for `75ba51f`; this is not a hosted-CI pass.
  The completed local and fresh-environment checks above remain separate evidence.
- Physical LIFE origin, corrected Rev B0/firmware/GATT, clock/assay transfer
  calibration, instrument adapters and paired physical captures: not established.
- Lobeline is an isolated rat-vesicle stationary initial-rate calculation, not a
  human cohort or intact plant response. Published disagreement remains open.
- Metformin uses reduced physiology and recorded research assumptions; the
  recordings do not establish individual clinical prediction accuracy.
- Registered whole-human anatomy, atom/trajectory assets, full molecular/cellular
  kinetics and additional organ models remain separate development gates.
- No production PHI/partner-confidential deployment, universal human equivalence,
  regulatory readiness or unattended monitoring is claimed.

See the [review and use guide](MEASUREMENT_INTEGRITY_REVIEW_GUIDE.md) for detailed
boundaries and the ordered next-development gates.
