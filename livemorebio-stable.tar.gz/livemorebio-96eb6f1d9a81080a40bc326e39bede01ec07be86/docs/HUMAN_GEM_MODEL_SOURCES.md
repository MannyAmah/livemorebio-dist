# Human-GEM sources, installation and integrity contract

Reviewed 2026-09-05. This release installs actual upstream Human-GEM reference
files and exposes them only after byte-for-byte verification. Model installation,
solver availability, numerical checks and scientific qualification are separate
states. An installed genome-scale network is not an individualized, complete human.

## Selected source and permissions

The supported source is [Human-GEM / Human2 v2.0.0](https://github.com/SysBioChalmers/Human-GEM/releases/tag/v2.0.0),
released March 30, 2026, at commit
`635f533152dc5f7290ce04d12700eaa882273c3e`. Downloads use this commit, not a moving
branch or the release tag alone. The upstream [CC-BY-4.0 license](https://raw.githubusercontent.com/SysBioChalmers/Human-GEM/635f533152dc5f7290ce04d12700eaa882273c3e/LICENSE.md)
permits reuse, including commercial reuse, subject to its conditions. Retain
attribution, the license and warranty notices, source links and modification notices.
This is not a patent license, endorsement or guarantee of scientific fitness.

Original files are unchanged. Livemore records its explicitly selected medium,
objective and knockout constraints separately and changes only its in-memory model.
The exact upstream [citation.cff](https://raw.githubusercontent.com/SysBioChalmers/Human-GEM/635f533152dc5f7290ce04d12700eaa882273c3e/citation.cff)
is retained. At this pin its preferred article citation is marked “In press”; do not
invent a final publication DOI. The citation file also identifies the Human-GEM
Zenodo record. Use the retained file for attribution when exporting derived work.

The linked [Human-GEM guide](https://sysbiochalmers.github.io/Human-GEM-guide/)
states that its instructions are guaranteed for v1.12.0. It is background guidance,
not proof that its version-specific examples apply unchanged to Human2. The actual
pinned XML and TSV headers govern this adapter.

## Exact installed artifacts

Every source below is relative to
`https://raw.githubusercontent.com/SysBioChalmers/Human-GEM/635f533152dc5f7290ce04d12700eaa882273c3e/`.
The module catalog returns the complete HTTPS URL for every artifact. Total source
payload is 45,829,803 bytes; no model binary is bundled in the Python wheel.

| Asset | Upstream path | Bytes | SHA256 |
|---|---|---:|---|
| XML | `model/Human-GEM.xml` | 43,115,559 | `cc5a4383c6116b0c91f4db089cc640f29aec7e840249b573b74d3792c9ca4a7a` |
| Genes | `model/genes.tsv` | 1,132,077 | `2a6058a157b3b9f3c958ba753e71d7a702d2716742972741d2ef36535ae9dff6` |
| Reactions | `model/reactions.tsv` | 886,012 | `1436dd90e959714366270a9904fd6a5108044a2f7f1d7f8360bf7a195fc9e28f` |
| Metabolites | `model/metabolites.tsv` | 674,780 | `9d58bb3a9cd217c47dc0d54ea9517b0a23e0603bbb60d5428551e0449af1eab3` |
| License | `LICENSE.md` | 17,068 | `bb5e0179a1e9bdb55634a4303784cf73c297a1dcee27b92cd546bf398075531c` |
| Schema notes | `model/README.md` | 2,586 | `8bfa0bfd39ce7783df8b7191184695a8c6d38a928c71fb6181070d22007ff9f8` |
| Citation | `citation.cff` | 1,716 | `41f90f96a1b05ba1e8ea8ca1927799f6244d47d8d41f813511751b89ee684f67` |
| Version | `version.txt` | 5 | `f22abd6773ab232869321ad4b1e47ac0c908febf4f3a2bd10c8066140f741261` |

`model/README.md` is stored as `schema.md`; other filenames are unchanged. A local
`installation.json` receipt records acquisition time, full pinned source metadata
and the canonical manifest SHA256. It contains no patient or solver results.

## Install, inspect and recover

From an installed Livemore environment:

```bash
python -m livemorebio.model_assets install human-gem
python -m livemorebio.model_assets status human-gem
python -m livemorebio.model_assets check human-gem
python -m livemorebio.model_assets catalog
```

The CLI emits JSON. `status` is read-only and exits successfully even when its
`available` field is false; it is a diagnostic report. `check` exits nonzero when
integrity fails or the model is unavailable. `install` returns success only after
all artifacts pass verification. `human-gem-2.0.0` is an exact alias; arbitrary
model identifiers, local model paths and caller-specified URLs are unsupported.

Cache resolution is evaluated at call time:

1. `LIVEMORE_MODEL_DIR`, if set.
2. Otherwise `LIVEMORE_DATA_DIR/models`.
3. Otherwise `~/.livemore/models`.

This cache is independent of legacy Recon or Human-GEM caches. No legacy model
helper is reactivated by installing these files. The directories must be owned by
the current user and mode `0700`; files must be regular, single-link, owned and
mode `0600`. Symlink cache/package/file targets are rejected. Existing permissions
are not silently changed. macOS and Linux are supported; Windows is not yet tested.
When choosing a custom location, supply the same model/data environment to the
installer, terminal client and all Aegle/Cendos services. A one-command environment
prefix does not persist into later shells or running services.

For a completely isolated evaluation, create a fresh private directory with
`mktemp -d`, set `LIVEMORE_MODEL_DIR` to its `models` child, and run the same install
command. Do not reuse a running deployment's cache for destructive tests.

Downloads use fixed HTTPS sources with redirects refused, certificate verification,
exact size bounds, SHA256 checks, a 10-second network-operation timeout and a
120-second package download deadline checked between reads. There is no arbitrary
URL or entitlement override. Installation stages in a private temporary directory,
fsyncs files, and publishes the complete version directory atomically under a
nonblocking process lock. Concurrent installers receive `busy`. Retrying a complete
valid installation performs no download. An interrupted unpublished stage is not
operational; ordinary failures clean up only that task's stage.

Every verification hashes **all eight files**, including annotations, license and
citation, and checks the receipt. Corrupt packages are preserved and rejected;
there is no silent deletion or replacement. To recover without modifying evidence,
retain the suspect directory and select a fresh private model root before installing.
Missing assets never become zero flux or a fallback model. Public errors do not
print local paths, external response bodies or secrets.

Stable error categories are `invalid_id`, `invalid_manifest`, `restricted`,
`missing`, `corrupt`, `unsafe_path`, `download`, and `busy`. There is no automatic
network access during status checks, reference lookup or ordinary scientific runs.

## Consumer contract

```python
from livemorebio import model_assets

report = model_assets.status("human-gem")  # Public-safe, no local paths.
asset = model_assets.verified_asset("human-gem")  # Internal worker only.
xml_path = asset["xml_path"]
manifest = asset["manifest"]
```

`verified_asset` includes canonical model ID, release, commit, XML SHA256, manifest
SHA256, manifest, license/source metadata and XML/three annotation paths. It verifies
the entire package first. Internal paths must not enter UI responses, exports or logs.
The asset manifest provides:

- `expected_counts`: 12,931 reactions, 8,461 metabolites, 2,848 genes, 9 compartments.
- `expected_ids`: objective `MAR03964`, glucose `MAR09034`, oxygen `MAR09048`.
- `objective_direction`: `max`; `flux_unit`: `mmol_per_gDW_per_hr`.
- Actual source format: SBML Level 3 Version 1, FBC Version 2.

`execution_lock_path()` is an internal helper returning the private cache's
`.execution.lock` path. It does not acquire the lock. The engine must open it safely
and hold its nonblocking cross-process lock until the isolated worker is reaped.

These identifiers were read from the pinned files and verified by COBRApy, not
ported from Recon conventions. In particular, the source's default objective and
permissive medium are not the Cendos oxygen-capacity protocol's constraints.

`annotation_rows(kind, ids)` accepts `genes`, `reactions` or `metabolites` and up to
100 unique exact IDs. It returns the unchanged matching TSV fields in requested
order, explicit `missing_ids`, source SHA/URL, and evidence class
`REFERENCE_MODEL_ANNOTATION`. The TSV keys are respectively `genes`, `rxns`, and
`mets`. Gene IDs are Ensembl-style identifiers, not automatically interchangeable
with HGNC symbols or Recon Entrez-transcript identifiers. Identifier cross-references
are not new licenses to download the referenced databases, and are never converted
to causal weights, drug responses, expression values or missing-gene replacements.

The downstream graph projection must preserve reaction direction/stoichiometry,
stable model IDs, GPR logic and provenance. An external Neo4j/TuringDB service is
not required to load or solve the network, and this module does not claim either
service is connected.

## Solver context and known limitations

The asset manager is Python-standard-library only and does not import COBRApy.
The separate engine parses the pinned SBML with COBRApy, uses explicit medium and
objective, handles complete knockouts through GPR logic, and reports solver status,
constraint/mass-balance residuals and controls. Relevant primary API references:
[model IO](https://cobrapy.readthedocs.io/en/latest/io.html),
[growth media and boundary reactions](https://cobrapy.readthedocs.io/en/latest/media.html),
[reaction/gene manipulation](https://cobrapy.readthedocs.io/en/latest/getting_started.html),
[solution and flux variability analysis](https://cobrapy.readthedocs.io/en/latest/simulating.html).

Initial isolated characterization on this Mac used COBRApy 0.32.1, libSBML 5.21.1
and GLPK. Human2 parsed in about 7.9 seconds with about 1.3 GB peak process RSS.
These measurements are environment-specific engineering observations, not minimum
hardware guarantees or clinical evidence. Budget memory for one isolated worker,
and never make routine UI polling instantiate another model.

Stoichiometric feasibility is not enzyme kinetics, tissue dynamics, pharmacokinetics,
individual biological equivalence or a measured treatment response. Complete GPR
knockouts do not justify default 50% allele effects. Model predictions must not
self-calibrate the active twin or enter physical-measurement evidence channels.

## Recon3D is cataloged, not enabled

The inspected official [VMH Recon repository](https://github.com/VirtualMetabolicHuman/Recon)
at commit `967ff5113d4a3ad3fb65e7cf6aea82e63e76d914` contains
`Current_Version/Recon3D_301_Generic_Model/Recon3DModel_301.xml`. Its embedded notice
explicitly states [CC-BY-NC-ND-4.0](https://creativecommons.org/licenses/by-nc-nd/4.0/).
The [BiGG licensing page](https://bigg.ucsd.edu/license) separately provides a contact
route for commercial incorporation/use. Technical ability to parse a file is not
commercial permission.

The catalog retains the inspected source URL, size 21,575,547 bytes and SHA256
`6f96538177cc65248413c012876fc6e7608dda2647c2445c64f0b5ab727ad440`.
All `recon3d`/`recon3d-3.01` install and execution-path calls fail with `restricted`
**before filesystem creation or HTTP access**. No restricted XML is distributed,
fetched by this installer or copied into the operational model cache. A future
integration requires independently reviewed rights and a separately reviewed
execution contract; this release has no checkbox or environment-variable bypass.

## Verification recorded for this lane

Tests were written before the module, initially failing on its missing import.
Additional malformed-annotation and deeply nested receipt tests reproduced two
typed-error gaps before the guards were added. On 2026-09-05:

- 45 asset tests passed with the official-download opt-in enabled.
- The standalone CLI separately installed all eight official files into a fresh
  private temporary cache, then verified the full package in about 30 ms locally.
- The XML digest matched the table above. ATP-maintenance annotation lookup returned
  actual `MAR03964` source links, including KEGG `R00086`, BiGG `ATPM` and Rhea IDs.
  An absent queried gene remained explicitly absent.
- Offline runs skip only the explicit network download test. Enable it with
  `LIVEMORE_TEST_MODEL_DOWNLOAD=1 python -m pytest -q livemorebio/tests/test_model_assets.py`.

These are asset/adapter tests. Engine, API, full installer, UI and wet-lab validation
are separate evidence and must be reported by their actual runs.
