# Research workflow: prediction, measurement, learning

2026-09-05 · local single-operator research candidate.

For the additive Human-GEM and clean-workflow build, first read the
[external tester guide](EXTERNAL_TESTER_GUIDE.md) and
[candidate verification evidence](GENOME_MODEL_REVIEW_EVIDENCE.md). Cendos now opens
blank Preparation and uses paged History for recall/explicit rerun. The separate
Human-GEM protocol is reference-network steady-state flux, not person-based
physiology; the physical comparison below intentionally rejects it until a matching
cell/assay protocol is reviewed. This document continues to describe the preserved
metformin/PXR and Research evidence workflows.

This guide supersedes the August demo's claims about run-specific Biology and
biological-time playback. Historical run values are not benchmarks for this build:
the September integrity repair removed unsupported physiological mappings.

## Start this review build without disturbing an existing product

From this feature checkout, use its installed Python environment:

```bash
PYTHONPATH=. python tools/run_review_stack.py
```

This foreground review stack creates a fresh owner-only data directory and prints
its path. It serves Aegle at `http://127.0.0.1:8860`, LIFE at `:8861` and Cendos at
`:8862`. Stop with Ctrl+C. It does not replace the managed installation or the
services on ports 8850–8852. For a restart, pass `--data-dir /absolute/review/path`.
Do not point the review runner at a production or real-person data directory.

For a normal installed release, use `livemore start all`, then `livemore open`.
The one-line installer in the launch guide installs the selected main commit, not
an unmerged feature branch. Do not expect the new Research tab from an older main
installation before the feature is reviewed and released.

`LIVEMORE_DATA_DIR` scopes registry, keys, bus snapshots/events, audit and default
subject/research/evidence stores. The explicit `LIVEMORE_AEGLE_URL`,
`LIVEMORE_LIFE_URL`, and `LIVEMORE_CENDOS_URL` overrides allow alternate ports.
The review runner sets the related store overrides and local credentials for you.
Reference/model caches are not physical patient datasets. Never place PHI in them.

## Compatibility and intake boundaries

The legacy `POST /api/evidence` intake is disabled with HTTP 409 before its body
is admitted. It cannot establish measurement provenance. Use the encrypted
Research study/measurement workflow below. Historical evidence remains historical;
an old export or an internally drafted package is not an independent review.

New subject activations retain the complete metabolic profile and explicit PK
context. Older snapshots missing required fields must be reactivated from their
saved subject record; Cendos rejects incomplete snapshots instead of silently
substituting defaults. Missing age/genome input is explicitly reference-initialized,
not imputed as an observation from a real person.

Research JSON intake is consistent across the browser, terminal and API: duplicate
keys, nonfinite numbers, unsafe integer literals, excessive nesting and oversized
payloads reject before admission. Specimen and member identifiers must be strings.
Ordinary floating-point scientific values retain normal finite-precision behavior;
the parser is not an arbitrary-precision measurement system.

## 1. Prepare a cohort and execute a supported protocol

1. In **Cohorts**, create heterogeneous reference research cohorts using an explicit
   stratum, size and seed. These are generated from curated priors, not copies of
   NHANES or DPP participants. OpenMed is an intake/de-identification SDK, not a
   patient dataset.
2. In **Cendos Lab**, select two eligible metabolic strata for metformin, or a
   `pxr-reference` cohort for purified garcinoic acid. Enter dose/load or the free
   concentration series. Execute and inspect the recorded per-member values.
3. In **Biology**, use **Visualize this run**. Select members explicitly. Metformin
   time playback reads the exact stored ODE trajectories behind the report. PXR
   selection changes static concentration-response values; no time kinetics or
   downstream CYP3A4 response is invented.
4. Download the CSV and notebook. In a compatible Jupyter Python kernel, use Run All.
   The notebook verifies the embedded run digest and calculates tables and plots.
   Its distributions are model dispersion, not clinical confidence intervals.

Unknown compounds in the legacy generic-effect path now return
`UNSUPPORTED_BIOLOGICAL_INTERVENTION`. This is a deliberate integrity repair, not
a missing default that should be restored. A new compound needs its own admitted
mechanism and measurements.

## 2. Freeze the physical counterpart before collecting data

Open **Freeze a measurement comparison** from the completed Cendos run.

- Load the saved run, not caller-supplied predicted values.
- Enter a study title, endpoint-compatible absolute tolerance and scientific rationale.
- Specify assay method, material/lot, controls and a unique specimen→member mapping.
- Freeze. The saved study contains the run hash and immutable criteria.

The current paired endpoints are `relative_pxr_activation` (unit `1`) and
`delta_mean_glucose` (unit `mg/dL`). Mapping a specimen to a research member is an
operator declaration of the intended assay counterpart, not proof of individual
biological equivalence. A qualified counterpart needs comparable material,
exposure, assay normalization, population and endpoint context.

## 3. Admit an independent measurement

Use an actual instrument file only when its lawful use and custody are established.
For software checks, explicitly choose **Technical fixture**. The service preserves
that distinction and will not award biological qualification to a fixture.

Paired CSV columns:

```text
sample_id,member_id,concentration_um,endpoint,unit,value,replicate_id,measured_at,quality_status
```

For metformin, replace `concentration_um` with `dose_mg`. Values and conditions must
match the frozen endpoint contract. Required metadata include instrument ID,
calibration ID, method, material lot, operator, source/custody reference and explicit
control/calibration QC declarations. Timestamps need timezones and cannot be in the
future. Duplicate replicates, unknown members, mismatched units/conditions and
invalid numerics reject. Failed QC is retained but prevents a qualifying comparison.

Raw CSV, parsed rows and metadata are AES-GCM encrypted locally. A SHA-256 digest
binds the original bytes. The import is still operator-attested; device authenticity,
sample identity and calibration validity are not independently proven by a form.

## 4. Compare without self-calibration

Select the frozen study and admitted measurement record. The service resolves the
prediction from storage, groups technical replicates without treating them as
independent people, and reports measured mean/SD, residual, tolerance, RMSE and
coverage. Missing data report `AWAITING_MEASUREMENTS`; incomplete, retrospective or
failed-QC evidence is not a passed prospective assessment. A technical fixture always
reports `TECHNICAL_CHECK_ONLY`.

`CRITERION_MET` is one numerical comparison, not model qualification or regulatory
validation. Every comparison keeps `calibration_authorized: false`. Independent
scientific review, instrument/specimen verification and applicability assessment
remain required.

## 5. Register a treatment-free resilience hypothesis

The **Treatment-free resilience** tab starts with an explicit placeholder template.
Replace every placeholder before saving. Prespecify:

- Population and all five operations with measurement endpoints and units.
- Nonapplicability rationale where justified; resilience always applies.
- An independent subject roster and a profile reference for each subject.
- Subject-specific healthy ranges for every applicable operation.
- A justified washout, **post-washout** follow-up interval, stresses, minimum
  independent subject count and target probability p*.

Resilience CSV columns:

```text
subject_id,operation,endpoint,unit,stress_id,stress_started_at,value,measured_at,last_treatment_at,washout_confirmed,quality_status
```

IDs are exact and canonical. Stress must begin after washout and before measurement;
prospective assessment requires stress after registration. Follow-up is measured
after washout, not concurrently with it. Every registered subject must cover every
applicable operation × stress. A subject passes jointly, not once per repeated row.
The one-sided 95% Wilson lower bound must meet p*. Missing evidence remains
`NOT_ASSESSABLE`. No result authorizes a permanent-cure claim.

## 6. Learn continuously without silently rewriting biology

In **Scientific learning**, record a module/scale, precise claim, primary sources,
counterevidence, independent test plan, population boundary and author. Each record
is immutable and remains `PROPOSED`. The eight-scale curriculum and contributor
contract are binding prerequisites for future changes. Source ingestion is not
reinforcement learning; no automatic training or active-twin update is enabled.

## 7. Use KEGG and MalaCards where they belong

In **Disease references**, look up the exact source disease ID. Without a current
permitted local release, the UI explicitly shows unavailable rather than pretending
that integration is operational. Upload only a vendor-authorized normalized export
with the required manifest. See [licensed reference integration](LICENSED_REFERENCE_INTEGRATION.md).
An API configuration flag alone now reports `configured`, not `ready`.

## Terminal and notebooks use the same contract

`livemore attach` supports:

```text
research list
research freeze counterpart-criteria.json
research import measurement-payload.json
research compare research-STUDY_ID measurement=research-MEASUREMENT_ID
research resilience resilience-protocol.json
research assess research-PROTOCOL_ID measurements=research-MEASUREMENT_ID
research learn biological-proposal.json
research source kegg H00409
research source malacards exact_vendor_identifier
research source-import licensed-release.json
```

Use actual opaque IDs returned by the service. `freeze` JSON includes `run_id` plus
criteria. `import` JSON includes `study_id`, `csv` and custody metadata. File-based
intake avoids putting clinical content in terminal history. The terminal displays
record IDs/status, not raw patient rows.

```python
from livemorebio.sdk import Platform
p = Platform(mode="attach")
records = p.research_overview()
result = p.compare_research_study(study_id, measurement_id)
context = p.disease_reference("kegg", "H00409")
```

For the isolated review stack, set `LIVEMORE_DATA_DIR` to its printed directory and
`LIVEMORE_AEGLE_URL=http://127.0.0.1:8860` for the attached client. It reads the local
owner-only token, never a secret embedded in source. Do not log returned PHI-like
data or send it to third-party tools.
