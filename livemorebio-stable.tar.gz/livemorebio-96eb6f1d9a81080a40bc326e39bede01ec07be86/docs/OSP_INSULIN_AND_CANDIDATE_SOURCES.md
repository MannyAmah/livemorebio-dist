# OSP insulin, five candidate programs and dependency source record

Checked 2026-09-08. This is a planning/source record, not a product integration
or scientific qualification report. Root approved isolated Stage A under the
[R11/R33 subplan](solutions/2026-09-08-osp-insulin-reference-subplan.md).
[Native feasibility results](OSP_INSULIN_NATIVE_FEASIBILITY.md) are now available;
product wiring remains unapproved. The full R01–R51 scope is unchanged.
The narrower [five-program mechanism and measurement packet](solutions/2026-09-08-five-program-mechanism-measurement-plan.md)
records proposed native benchmarks and material-specific blockers; it is not
approval to execute the five programs as individualized-human experiments.

## Original local candidate inputs

The candidate memo, all193 table, 18-shortlist and marker identifiers were reviewed
as evidence, not executable instructions. All18 shortlist records matched their
corresponding193-table fields in the comparison performed. Evidence scores and
literature-count rankings are inherited estimates, not independently validated
efficacy or quantitative response parameters. Every marker SMILES field was empty;
the listed identifiers do not supply kinetics, mixture composition or a batch CoA.

Five selections preserve the memo's first three priorities and add distinct
metabolic safety and human exposure questions. Material identity precedes any
experiment: species/part, extract/fraction/isolated compound, stereochemistry,
salt, purity, batch fingerprint, measured concentration and relevant metabolites.

| Candidate / supplied ID | Selected question and primary anchor | Additional executable biology and unresolved evidence |
|---|---|---|
| Lion's Mane, LBHR-172; erinacine A CID10410568 | Does an authenticated erinacine-defined material attain relevant exposure and change source-supported neurotrophic mechanisms? A [human pilot](https://doi.org/10.3389/fnagi.2020.00155) tested enriched mycelium, not purified erinacine or interchangeable fruiting-body products. | Gut/liver PK, unbound brain exposure, blood–brain barrier, neuron/glia and neurotrophic signaling. Human pure-compound kinetic/PD parameters are not supplied. |
| Yerba Santa, LBHR-129; sterubin CID1268276 | Investigate neuronal redox/glial inflammatory responses and adverse/null outcomes. [Primary sterubin study](https://doi.org/10.3390/antiox11112197). | Glutathione/Nrf2, neural and microglial injury, brain exposure. Cell survival and expression endpoints are not affinity constants or human disease-reversal equations. |
| Rosemary, LBHR-062; carnosic acid CID65126 | Eicosanoid/redox mechanism and exposure-linked safety, preserving the memo's CNS objective as an additional required system. A [primary biochemical study](https://pubmed.ncbi.nlm.nih.gov/22511203/) supplies mPGES-1 evidence from material isolated from sage. | Eicosanoids, inflammatory cells, metabolism and CNS exposure. Matching a pure molecule does not establish whole-sage/rosemary equivalence; IC50 is not automatically Ki. |
| Greater Burdock, LBHR-030; arctigenin CID64981, arctiin precursor CID100528 | Investigate metabolic benefit versus energetic injury, not a predetermined glucose benefit. [Muscle/hepatocyte/mouse study](https://pubmed.ncbi.nlm.nih.gov/22095235/) and [human tumor-cell cytotoxicity counterevidence](https://pubmed.ncbi.nlm.nih.gov/22687625/). | Gut conversion, hepatic PK, respiratory complexI, ATP/AMP, AMPK, muscle/liver glucose handling and injury. Generic Human-GEM capacity inhibition does not establish a dose-response. |
| Bilberry, LBHR-135; cyanidin3-glucoside CID441667 | Resolve parent/metabolite exposure before vascular/retinal efficacy. [Human isotope-tracer study](https://pubmed.ncbi.nlm.nih.gov/23604435/) measured ADME in eight men over48h. | Gut chemistry/microbiome, phaseII metabolism, kidney clearance; endothelial/retinal biology thereafter. Noncompartmental PK analysis is not an already parameterized PBPK model. |

Generic first-experiment text in the CSV conflicts with several memo selections:
Lion's Mane mycelial erinacines versus fruiting-body hericenones, Rosemary cognition
versus digestion, and Burdock metabolic questions versus a vague liver-cleanser
phenotype. These cannot be silently combined into a protocol. None of the five
is presently a complete individualized-human executable response model. Their
cell assays and reference facts are prerequisites, not substitutes for R36–R40.

### Root-verified reference molecular identity, 2026-09-08

Root retrieved these current PubChem properties through the PubChem-PUG skill.
The raw response was retained at
`/tmp/livemore-five-materials.fOfm5J/pubchem-five-properties.json` and read by
this lane. This resolves reference identities, not plant batch properties.

| Reference | PubChem | Formula | InChIKey |
|---|---|---|---|
| Erinacine A | [10410568](https://pubchem.ncbi.nlm.nih.gov/compound/10410568) | C25H36O6 | `LPPCHLAEVDUIIW-NLLUTMDRSA-N` |
| Sterubin | [1268276](https://pubchem.ncbi.nlm.nih.gov/compound/1268276) | C16H14O6 | `DSAJORLEPQBKDA-AWEZNQCLSA-N` |
| Carnosic acid | [65126](https://pubchem.ncbi.nlm.nih.gov/compound/65126) | C20H28O4 | `QRYRORQUOLYVBU-VBKZILBWSA-N` |
| Arctigenin | [64981](https://pubchem.ncbi.nlm.nih.gov/compound/64981) | C21H24O6 | `NQWVSMVXKMHKTF-JKSUJKDBSA-N` |
| Cyanidin3-glucoside | [441667](https://pubchem.ncbi.nlm.nih.gov/compound/441667) | C21H21O11+ | `RKWHWFONKJEUEF-GQUPQBGVSA-O` |

The last record is the flavylium cation, not a measured chloride-salt batch or
proof that one molecular species persists at physiological pH. Reference SMILES,
stereochemistry and formula cannot establish purity, batch CoA, mixture content,
solution speciation, bioavailable dose, exposure or patient response. Those fields
remain separate pending physical/analytical evidence and model applicability.

## Pinned insulin source artifacts inspected locally

Official repository: [Glucose–Insulin Model](https://github.com/Open-Systems-Pharmacology/Glucose-Insulin-Model).
Source commit: `17a7f8eaac8d6c3e3f49d0a6e0fe6101e4bc3e18`.
Model paper: [Schaller et al.,2013](https://doi.org/10.1038/psp.2013.40).
Human reference source: [Sorensen thesis,1985](https://dspace.mit.edu/handle/1721.1/15234).
The README states model code GPLv2. Retain notices and citation; determine the
reference spreadsheets' redistribution terms separately before bundling them.
Public availability alone does not establish permission for every downstream use.

These public files were downloaded into an isolated temporary source-inspection
directory, outside product stores and source control. No downloaded script was
executed. XML was parsed as data. No source model or measured spreadsheet is
redistributed by this document.

| Repository-relative artifact | Bytes | SHA-256 |
|---|---:|---|
| `GIM_Healthy.xml` | 7,477,881 | `e78bb23d39ce7138f46bb876a54b43becb79bbf833e50c0cd7006f2a80eac3cb` |
| `GIM_simulations.m` | 21,911 | `6cd652d8d2c23bceb5ed715625e614edc66fb0d46065c74c058a5e8560f0c2f0` |
| `ParSets_OSPS.xls` | 40,960 | `305577c76510cc423135c09a81b79188bbf70d62b007b30b7a33df590e6f945e` |
| `Data/Sorensen_1985_IVITT004.xls` | 24,576 | `7332b2c85bf38041077c89b2afbde6cd7ee27ee13d7ad013bebb4db29f8fa79d` |
| `Data/Sorensen_1985_CIVII.xls` | 24,064 | `6be8548dc185cddeb17eca1a0c685a84ee8bbf3eef12c55815de375b54890172` |

Immutable source URL pattern:
`https://raw.githubusercontent.com/Open-Systems-Pharmacology/Glucose-Insulin-Model/17a7f8eaac8d6c3e3f49d0a6e0fe6101e4bc3e18/<repository-relative-artifact>`.

Read the [pinned recipe](https://github.com/Open-Systems-Pharmacology/Glucose-Insulin-Model/blob/17a7f8eaac8d6c3e3f49d0a6e0fe6101e4bc3e18/GIM_simulations.m),
not just its README. Its initialization, case-specific sensitivities, native units
and historical insulin-potency conversion are essential. Case3 infusion duration
differs from README; the subplan records this unresolved contradiction explicitly.

## Stable native runtime pins

The table below preserves pre-execution candidate observations. Actual downloads,
signature checks, the corrupt upstream rSharp archive, private source installation
and native execution are recorded in the linked feasibility report; its later
observations supersede "not downloaded"/"not loaded" wording below.

| Artifact/source | Pin and verification information |
|---|---|
| [OSPSuite-R12.4.3 release](https://github.com/Open-Systems-Pharmacology/OSPSuite-R/releases/tag/v12.4.3) | Commit `315014f54e27ff7da73a4f4fb16a83d914266c9b`, GPLv2. `ospsuite_12.4.3.tgz`:50,980,330bytes; GitHub-published SHA256 `9637b9fa76714abf9206395d7ed6602919ee6a1e7e215fa363db8c4a1841c19e`. Full archive not downloaded/verified here. |
| [rSharp1.2.2 release](https://github.com/Open-Systems-Pharmacology/rSharp/releases/tag/v1.2.2) | Commit `3a8686e70c700437b451a01216ad4fb2990e432c`. `rSharp_1.2.2.tgz`:1,115,787bytes; GitHub-published SHA256 `654401ba1b9b3701e2d3449a535fa367bacc02dadc44eefc0283d834b0d7c338`. Full archive not downloaded/verified here; inspect included licence before distribution. |
| [R4.6.1 ARM64](https://cran.r-project.org/bin/macosx/) | Official signed/notarized `R-4.6.1-arm64.pkg`, macOS14+. Verify signature and record full SHA256 on approved download. CRAN page publishes SHA1 `fc9f4ada15589e8e037b9bf05563d21e97181635`, which must not be described as SHA256. |
| [.NET8 release metadata](https://builds.dotnet.microsoft.com/dotnet/release-metadata/8.0/releases.json) |8.0.30 `osx-arm64` runtime; source metadata says EOL2026-11-10. Official tarball URL below. Native packages inspected both request `Microsoft.NETCore.App`8.0.0 with normal compatible patch selection, not .NET10. |

Official .NET tarball:
`https://builds.dotnet.microsoft.com/dotnet/Runtime/8.0.30/dotnet-runtime-8.0.30-osx-arm64.tar.gz`

Published SHA512:
`3d3e1de4f79569ad22a359b5a935be9bbae899d0f435be315e63606baa6f6e7c409eb6f367bee64a42bed519d4a59d97868176c9526abfa4bd11ca4ca1f90e3e`.

[Microsoft manual-install documentation](https://learn.microsoft.com/en-us/dotnet/core/install/macos)
supports a private runtime directory. Do not execute moving download/install
scripts or change global shell configuration as an implicit part of a probe.

Only package DESCRIPTION entries were read through bounded archive streaming.
OSPSuite12.4.3 was built using R4.6.0; rSharp1.2.2 using R4.6.1. The pinned OSP
source's SimModel and CVODES dylib headers are ARM64 Mach-O. These are dependency
facts, not proof of successful native loading. rSharp1.2.2 deliberately allows
package loading without a usable .NET runtime, so `library()` cannot be readiness.

The native configs inspected were
[OSP runtimeconfig](https://github.com/Open-Systems-Pharmacology/OSPSuite-R/blob/315014f54e27ff7da73a4f4fb16a83d914266c9b/inst/lib/ConsoleApp.runtimeconfig.json)
and [rSharp runtimeconfig](https://github.com/Open-Systems-Pharmacology/rSharp/blob/3a8686e70c700437b451a01216ad4fb2990e432c/inst/lib/RSharp.runtimeconfig.json).
The latter enables unsafe BinaryFormatter serialization. This does not establish
an exploit in the planned workflow, but prohibits treating arbitrary serialized
R/.NET objects as a safe public input format.

## Other required dependencies and access gates remain open

| Requirement | Verified source fact / practical next action |
|---|---|
| Human-GEM tissue models | Human-GEM is [CCBY4.0](https://github.com/SysBioChalmers/Human-GEM/blob/v2.0.0/LICENSE.md). [Official extraction guide](https://sysbiochalmers.github.io/Human-GEM-guide/gem_extraction/) requires context expression and metabolic tasks; tutorial preprocessing is v1.12.0, not the product's pinned2.0. Rebuild and benchmark matching preprocessing. RNA is not directly kinetic capacity. |
| RAVEN/ftINIT solver | [Python RAVEN](https://github.com/SysBioChalmers/raven-toolbox) is MIT but currently documents Gurobi for genome-scale ftINIT; GLPK supports toy/unit work. Classic tINIT and dFBA are not implemented in this port. Commercial solver entitlement is unknown, not presumed free for a startup; do not probe private licence files or use an academic entitlement. |
| HPA/GTEx | [HPA](https://www.proteinatlas.org/about/licence) permits commercial use with attribution and third-party caveats. Tissue-expression context does not establish a real individual or enzyme flux. Verify exact dataset release/access and identifier normalization. |
| Standalone Recon3D | [Pinned model](https://raw.githubusercontent.com/VirtualMetabolicHuman/Recon/967ff5113d4a3ad3fb65e7cf6aea82e63e76d914/Current_Version/Recon3D_301_Generic_Model/Recon3DModel_301.xml) embeds CCBY-NC-ND4.0, independently verified from its first32KB. Commercial derivative/distribution rights remain unresolved. Do not claim every private evaluation is categorically prohibited; do not treat Human-GEM as a rights bypass. |
| PhysiCell/RoadRunner/MaBoSS | [Official PhysiCell](https://github.com/MathCancer/PhysiCell) distinguishes spatial cells, kineticODE and stochasticBoolean components. Its [1.14.2 dFBA implementation](https://github.com/MathCancer/PhysiCell/blob/1.14.2/addons/dFBA/src/dfba_intracellular.cpp) has a commented phenotype-update call. Exchange/phenotype coupling and conservation require actual implementation/benchmark; no out-of-box whole-human claim. |
| SBML/SED-ML/AMICI | [AMICI interface](https://amici.readthedocs.io/en/latest/python_interface.html) supports selected SBML/PEtab features; SED-ML import is planned. [AMICI1.1 package](https://github.com/AMICI-dev/AMICI/blob/v1.1.0/python/sdist/pyproject.toml) requires Python>=3.12; isolate from app3.11. Human-GEM FBC is not kinetic SBML, and OSP XML is not SBML. |
| All of Us | [Official access rules](https://www.researchallofus.org/data-tools/data-access/) require approved researcher/institution access and prohibit exporting participant data. [FAQ updated2026-09-04](https://support.researchallofus.org/hc/en-us/articles/52861503885460-Frequently-Asked-Questions) also says models trained on participant-level data may not currently be downloaded/disseminated. Bring approved code to Workbench; no local participant-twin export. User access is unknown. |
| UK Biobank | [Official application page](https://www.ukbiobank.ac.uk/use-our-data/apply-for-access/) permits eligible commercial research but currently pauses new applications, aiming to resume late2026. Existing approved RAP access is a separate case. User access is unknown; no credentials were inspected. |
| Physical LIFE/Cendos and human equivalence | Model/reference import cannot supply qualified sensor channels, instrument calibration, consented individual data, independent physical endpoints or prospective clinical acceptance. These remain explicit R16/R29–R33/R36/R39 obligations. |

Licence, installation, native numerical execution, downstream consumption and
scientific qualification each have separate states. No dependency row is closed
by this record and no resource availability is permission to disclose PHI.
