# Beard step-4 implementation candidate — execution remains locked

2026-09-08. **Independent implementation review pending. No Beard C compilation,
initialization, RHS evaluation or solve has occurred in this increment.**
The source-execution and independent-source-evaluation constants are both false,
with no environment or command-line override. Do not enable them until the root
and independent reviewer approve the exact implementation and numerical manifest.

This is an implementation of the prospective
[source-execution protocol](solutions/2026-09-08-beard-native-source-preregistration.md),
not new numerical evidence or a completed arctigenin/human experiment. Existing
technical-worker results and the rejected Myokit import remain unchanged.

## Frozen identities

| Artifact | SHA-256 |
| --- | --- |
| Approved protocol | `95351a1e380178725ab38731d8e9dc63b57ebd4a1ae507dad17d3884e28167e7` |
| Original PMR source | `4a4f931592df0e77a92c79447bf6d8947c7325f721a74b4d336d370abaaf3981` |
| Generated source C | `3af10f8a848e6077f6059186fc1b34a9895e89f9f9c47f80669001ccfbc9795a` |
| Generated model header | `9cef032fa93c51f54a327d10ff3a625c0c7c881378f67edd65148a282e751d5e` |
| Candidate source wrapper | `b0be2b4d5bdbd8bf91e7df5a0f255422cfee46e1c451956d829055b1d05a3018` |
| Candidate supervisor/orchestration | `202cb1549d7816152b1adb21c6edcbc5d64e5dbad91ab9b8aaa0755a9c57bac2` |
| Candidate array analysis | `85d4ddb39e9e849efb1d35199c0a6ed4fab9f547aa818fd25101594c2c2f0263` |
| Candidate independent MathML evaluator | `88ee0e3526a4a8822e739c3a54fa21e45e5810ad47fd8a1dde542e13bbbe5c3b` |
| Existing technical worker Python, unchanged | `e0e80716e3bfa4fb6bdf74499036c575501dfb3877c2085cab09842580c4d1c9` |
| Existing two-state technical C, unchanged | `427139375707d6f4ddf9e94b552957199d0572989d044ded861a77003f122f06` |

The native runtime's canonical JSON fingerprint is
`775e5190a01bfbf0408efe1e1c76b5e502cd645fff65df6e28e212d7f0d025f2`.
It was calculated from the previously retained reviewed technical runtime, not
from a newly executed source worker. It binds SUNDIALS/library/header hashes,
compiler bytes/version, SDK, compile flags, OS build and platform. Any change
blocks this candidate. The new binary/linkage hash is **not yet available**.

## What is implemented, but not natively exercised

- `tools/beard_mathml.py`: a bounded, independent original-MathML interpreter;
  qualified variable/equivalence resolution; lazy branches; finite/domain gates;
  exact rational proof of the source's five-state zero nucleotide subspace.
- `tools/beard_source_worker.c`: separate 19-state source wrapper. I0a initializes
  source arrays without rates; I0b evaluates t=0 only. B0/B1/R1/K1 retain complete
  native-time JSONL grids, counts, trial/output negative flags, source domains,
  solver diagnostics and bounded partial failure evidence. Initial arrays start
  as NaN, so missing initialization cannot be supplied by a default zero.
- `tools/beard_source_execution.py`: fixed-source admission, source-generated
  metadata/units header, immutable K1 checkpoint, private per-cell directories,
  runtime/linkage gates, source-specific supervisor and sequential matrix.
- `tools/beard_source_analysis.py`: literal initialization, per-identity source
  expression checks, complete-grid comparisons, domain/conservation checks,
  explicit uncertainty and failed/missing dependency states.

All 339 aliases retain their original units and equivalence mapping into the
19 state, 47 literal, 12 computed-constant, 34 algebraic and one time slot.
The numerical floats are not a replacement for the retained dimensions.

The source supervisor retains the reviewed PID/start/image and held-waitable
process-group primitives. Its new 1 GiB RSS threshold is **sampled soft
protection**, not hard memory isolation. The fixed source policy is 120 s wall,
60 s native CPU, 64 MiB per output/file, requested 10 ms RSS sampling. Zero valid
samples, stale identity, sampler failure, excess final output or failed cleanup
cannot be accepted. Actual resource performance remains pending native execution.

## Tests executed before review

- New source packet: **62 passed in 0.21 s**, including the explicit local pinned
  source and existing conversion-artifact **static-only** tests.
- Combined default packet: **107 passed, 29 explicit source/native opt-in skips
  in 0.22 s**. No source callback or native compiler was enabled by that run.
- Red tests covered missing evaluator/analysis/orchestrator, incomplete target
  projection, substituted generated header, missing grids, per-value discrepancy,
  zero-subspace perturbation, concentration uncertainty, missing branch/comparison,
  early execution lock, canceled spawn, process identity and cleanup failures,
  unobserved process identity, late stream growth, malformed/nonfinite/deep JSON,
  invalid summary metrics, and error-preserving evidence-write failure.

These are **software/static tests only**. Fake process objects and parser arrays
are labeled technical test fixtures in test code and are not source-model output.
The C review includes structural assertions but **not a compile check**: compiling
the actual Beard binary is itself behind the independent-review gate. Native
I0a, I0b, B0, B1, R1 and K1 all remain `NOT_RUN`.

## Scientific boundary and next required review

Exact PMR defaults keep external ATP/ADP/AMP and all five intermembrane nucleotide
states zero. Their source flows form an invariant zero subspace. No ATP export,
arctigenin response, human personalization or drug efficacy follows from it.
The wrapper checks exact zero on retained outputs; Jacobian solver-trial
perturbations are explicitly distinct from accepted output states.

The reviewer must inspect initialization/callback sequencing, source/unit/index
identity, the independent interpreter, strict active domains, complete matrix and
K1 semantics, failure evidence and process ownership before granting execution.
A numerical pass, if later obtained, would qualify only execution of this pinned
reference implementation—not physiological equivalence or a compound response.

Compounded lesson: preserving source defaults includes preserving an uninteresting
zero boundary. A Jacobian trial is not an observed trajectory; a solver pass is
not a source-expression pass; a missing comparison is not an accepted result.

## Independent review correction scope — approved before code

The table above retains the original, **not accepted**, implementation candidate.
Independent review reproduced four P2 defects using static branch execution and
explicit software fixtures, without compiling or evaluating Beard. Root approved
the following bounded red-first corrections on 2026-09-08:

1. A nonzero native exit remains `NATIVE_RUN_FAILED` even if its final diagnostic
   is empty, truncated, malformed or exceeds the per-line bound. Retain the exit,
   supervision/cleanup evidence and raw-output hash; record diagnostic parsing as
   a secondary status, never as a replacement for the primary native failure.
2. Enforce the already preregistered **strict nonnegative redox partners** for
   NAD/NADH, Q/QH2 and Cox/Cred at retained outputs, including values inside the
   generic concentration uncertainty band. Do not change the other concentration
   bands, source constants, comparison limits or zero-subspace specialization.
3. Retain original-MathML failure identity, original native unit, quantity kind,
   recorded time/time unit and initialization/output-analysis stage through the
   orchestration failure record. Nested expression failures keep the innermost
   failing qualified identity. No source values are fabricated to replace them.
4. A source hash mismatch no longer implies a technical model. Admit only the
   exact pinned source (still execution-locked) or an explicitly named, bounded
   one-state scalar dependency test fixture with a fixed identity/unit/connection
   schema. Reject unknown fixture tags, oversized/deep documents and source
   variants—including pinned Beard plus whitespace—before any evaluation.

Acceptance: reproduce these defects red, then pass their regressions plus the
existing static/source-contract packet. Preserve both hard-coded execution gates
as false, unchanged technical worker hashes and the approved protocol hash
`95351a1e380178725ab38731d8e9dc63b57ebd4a1ae507dad17d3884e28167e7`.
Record corrected candidate hashes separately and request another independent
review. **No native source compilation, initialization, RHS or solve is authorized
by this correction scope.** Numerical I0a/I0b/B0/B1/R1/K1 remain `NOT_RUN`.

### Corrected candidate — independent re-review pending

The first correction test run reproduced **26 failures, with the previous 62
tests still passing**. After corrections and five additional end-to-end failure
context/admission tests, the combined six-module packet passed **154 tests, with
13 explicit native/conversion opt-in skips, in 2.83 s**. The run used the retained
local source/conversion artifact for structural verification and repeated the
previously reviewed Myokit parser rejection. It did not compile the Beard C
source, initialize source arrays, evaluate its RHS, or perform a physiological
solve. There are **93 dedicated step-4 technical/static tests** in this packet.

| Corrected artifact | SHA-256 |
| --- | --- |
| Independent MathML evaluator | `35ef2274454626274e72b57ccfaedd172dd31add8ea6911f0b8e9183f934871c` |
| Array analysis | `67b1c7bcb479c1c668139530bb4c201a8503cbc9cb06dc2d843579673450c3f4` |
| Supervisor/orchestration | `057b6a822a0f6002a2eb48e0b3c0ad84c5ab38bb2784a39d6aae6c52fe97d74b` |
| Evaluator tests | `64aa905ed290b1870a033fa0ba183e139a436da620fedb2f52f072f5ef4f9ebc` |
| Array-analysis tests | `9930a7ec4be3ad463ba4f91d1c16f035ade28e83aff6e68a974b20a8b3dbee77` |
| Orchestration tests | `73cc82ea047c2f6ced4ae319833d43bf7baf165729fedea99ade65f005006e4e` |

The original candidate table above is deliberately retained as rejected review
history. The protocol, source C wrapper and two original technical-worker hashes
are unchanged. Both execution gates are still false. Independent re-review is
required before any native-source step is authorized.

Reproduction (from this worktree, using the retained private source artifacts):

```sh
LIVEMORE_TEST_BEARD_SOURCE=/tmp/livemore-arctigenin-source.BCaB9w/beard_2005.cellml \
LIVEMORE_TEST_BEARD_ARTIFACT=/var/folders/4c/5614q8pd4rvfcvkgf0cr35j40000gn/T/livemore-beard-conversion-830r2ice/artifact.json \
/Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B tools/run_review_tests.py -q -p no:cacheprovider \
livemorebio/tests/test_beard_mathml.py livemorebio/tests/test_beard_source_analysis.py \
livemorebio/tests/test_beard_source_execution.py livemorebio/tests/test_beard_source_contract.py \
livemorebio/tests/test_beard_conversion.py livemorebio/tests/test_beard_native_worker.py
```

Correction lesson: a diagnostic parser must not erase independently established
process failure. A sum identity does not prove its partners are admissible.
Allowing software fixtures must be an explicit bounded admission path, never the
default meaning of a scientific source hash mismatch. Error context must survive
the full interpreter → analysis → orchestration path, not merely exist at origin.

## One-off native execution method — driver review required before execution

The independent reviewer cleared the four corrections: 93 dedicated static and
technical tests passed, and additional probes rejected six altered-source/tag
combinations, preserved native failure evidence for malformed output, and failed
all six redox partners at a small negative value. Source/protocol and existing
worker hashes matched. This clearance is implementation evidence, not a solve.

Root authorized **preparation only** of a private one-off driver for the exact
I0a/I0b/B0/B1/R1/K1 matrix. Actual execution requires a separate root read and
confirmation of the complete driver. Its method is:

1. A fresh managed Python process with `-I -B`, no arguments, and no inherited
   loader/credential overrides. Its fixed private directory contains the driver
   and, only after approval, an execution authorization receipt binding the
   driver, source, immutable protocol and complete code hashes. This receipt is
   an explicit local review record, not a cryptographic signature.
2. Verify the Python binary/path/version, all reviewed module/wrapper bytes and
   their exact paths, then load verified bytes directly into modules. Verify
   loaded module origins and recheck code bytes. Reject any preloaded module or
   runtime substitution. Verify the reviewed libCellML package and complete
   native runtime fingerprint before any gate changes.
3. Write private, fsynced admission evidence and a create-exclusive one-shot
   execution marker. Set only the two source-execution/evaluation flags in that
   process, call the existing fixed `run_matrix` **once**, then reset both flags
   in `finally`. On-disk defaults stay false; no product, environment or generic
   CLI override is introduced.
4. Retain the existing matrix's complete success/failure/partial artifacts and
   source-specific resource/cleanup receipts. The driver writes a separate
   summary or failure record without masking the original failure if secondary
   evidence storage fails. There is no retry, solver fallback, parameter change,
   threshold change or selection of a different checkpoint. I0 failure stops
   advancement exactly as preregistered.

The driver will be created under `/tmp/livemore-beard-once.bi8ASk/` with owner-only
permissions. Its complete content and SHA-256 must be read by root **before** an
authorization receipt is created or the driver is executed. Native matrix status
is still `NOT_RUN` at this preparation stage. No individualized-human or
arctigenin dose-response claim is included in this authorization.

Prepared driver (228 lines; AST syntax checked only, not executed):

- Path: `/private/tmp/livemore-beard-once.bi8ASk/run_once.py`
- SHA-256: `b285989aa6a9ec1f981786493a0e3a0bf6095d8d82e67078ad2ec8c1bcf84e64`
- File mode: `0600`; containing directory `0700`.
- Execution receipt: **not created**; driver execution: **not performed**.
- Planned invocation, only after separate approval and its matching receipt:
  `/Users/emman/.local/share/livemorebio/releases/34b0f6f8f8d67d1bb78f2396b6964f22d8f439de/source/.venv/bin/python -I -B /private/tmp/livemore-beard-once.bi8ASk/run_once.py`.

The driver binds the previously reviewed eight code/wrapper hashes plus the
resolved CPython 3.11.15 binary hash, libCellML package identity and native runtime
fingerprint. It loads reviewed Python module bytes directly (not their cached
bytecode), verifies dependency-module identity and records paths/hashes before
the process-local gates change. Its one-shot marker prevents another native
attempt in the same directory. No driver execution is implied by this record.

### Root's exact one-off execution authorization

After reading all 228 driver lines and this method, root explicitly approved the
**actual once-only invocation** of driver SHA
`b285989aa6a9ec1f981786493a0e3a0bf6095d8d82e67078ad2ec8c1bcf84e64`
for the exact I0a/I0b/B0/B1/R1/K1 matrix and reviewed code/source/runtime pins.
The matching private receipt was created at
`/private/tmp/livemore-beard-once.bi8ASk/execution-authorization.json` before
invocation. The approval requires `-I -B`, sanitized process environment, no
retry/fallback or parameter/tolerance changes, and retention of failures and
cleanup/resource receipts. On-disk gates remain false. Any numerical pass applies
only to the reference implementation and is not arctigenin, individualized-human
or physical qualification. Completion evidence will be appended after the single
attempt; the preceding NOT_RUN entries describe their earlier preparation stage.

### Single execution completed — overall numerical failure retained

The authorized driver ran once and returned matrix `FAILED` in 61.9873 seconds.
All six native branches passed their local checks; B0↔B1 failed 552 prescribed
identity/time comparisons. R1↔B1 and K1↔B1 passed. No retry or threshold/source
change occurred. All native and compiler children were reaped, native owned
groups had no live members before reap, and cleanup codes were null. On-disk
gate/source/protocol hashes were rechecked unchanged.

The complete outcome, per-quantity failure distribution, resource measurements,
paths and hashes are retained in
[the native matrix results report](BEARD_NATIVE_SOURCE_MATRIX_RESULTS.md).
Independent numerical recomputation is pending. The failed matrix is not a
scientific release and does not authorize product activation or human/compound
claims. Earlier NOT_RUN entries above are explicitly historical preparation.
