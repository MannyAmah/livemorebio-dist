# Measurement integrity and run-bound Biology: review guide

September 8, 2026. Feature branch: `codex/measurement-integrity-atlas`.
Preserved base: `5c71ee8e0a643b4be11bac0fe65712494449be56`.

This guide covers the additive, local review candidate. It does not replace the
installed product or certify pharmaceutical, clinical or human-device use. The
branch is a research candidate. See the [verification record](MEASUREMENT_INTEGRITY_VERIFICATION.md)
for exact tests, independent reviews, fresh-environment installation and browser
checks. Publication and video evidence are tracked there; none of those
software checks qualifies a model for clinical use.

The correction-first [approved plan](solutions/2026-09-08-measurement-integrity-atlas-build-plan.md)
keeps Aegle, LIFE and Cendos connected while making the boundary between a source
record, numerical calculation, admitted measurement and validation explicit.
Historical screenshots, videos, test counts and commands in older guides describe
their own release, not this candidate. In particular, their implicit virtual-Patch
sampling and mean-curve reconciliation examples are superseded here.

## What changed

| Surface | Executable behavior | Boundary |
| --- | --- | --- |
| LIFE v3 telemetry | Explicit acquisition window, monotonic session, clock uncertainty, firmware/manifest hashes, measurement lineage and endpoint context | Software contract, not released firmware or proven sensor performance |
| Legacy v2 | Exact decoder and canonical hashes preserved; normalized observations identify missing lineage | No invented v3 metadata and no journal conversion |
| Aegle observations | Receives a signed LIFE admission bound to the active subject, device, mode and protocol | Observations do not overwrite physiological model parameters |
| Measurement alignment | Explicit frozen prediction plus matching endpoint, subject, condition, unit, site, compartment and time mapping | Only technical-fixture identity mapping is executable; physical transfer mappings are unavailable |
| Atlas | Whole-person overview and source-aware readouts remain distinct from organ inspection | Unregistered organ meshes are not a registered whole-human assembly |
| Run-specific Biology | Selected run, member, condition, stage and native axis bind every quantity and its provenance | A stage click is inspection, not another experiment |
| Lobeline assay | Published-parameter competitive uptake calculation for isolated rat vesicles | Nonhuman stationary initial-rate approximation, not personalized human biology |

Numerical model execution is real computation. It is not a physical human reaction.
Physical data, when admitted, remain a separate evidence class. Passing software
tests or obtaining a visually plausible plot does not establish functional human
equivalence, a cure, assay qualification or clinical transferability.

## 1. Use a separate local checkout and review environment

This candidate is published in [PR #7](https://github.com/MannyAmah/livemorebio/pull/7),
stacked on the preserved previous candidate, not merged to main. The installer in
the [external tester guide](EXTERNAL_TESTER_GUIDE.md) still selects the previous
branch; it is not silently repointed by this build. The tested workflow below is
an isolated editable installation, not a newly verified one-line installer.

To obtain the tested product and evidence checkpoint in a new, unused directory:

```bash
git clone --branch codex/measurement-integrity-atlas --single-branch https://github.com/MannyAmah/livemorebio.git livemorebio-measurement-review
cd livemorebio-measurement-review
git checkout --detach 75ba51f43e688a72242e721e954c00171d794d80
```

Repository access is required. If that directory already exists, choose a different
unused name rather than overwriting an existing checkout. The pinned checkpoint
contains the verified code and evidence; later publication notes do not change its
biological kernels. Check PR status before considering any broader deployment.

For an editable local review checkout, use Python 3.11 and the existing locked
dependency instructions. From this branch's checkout, if a dependency environment
does not already exist:

```bash
python3.11 -m venv .venv
./.venv/bin/python -m pip install --require-hashes -r requirements-python311.lock
./.venv/bin/python -m pip install --no-deps --no-build-isolation -e .
```

Use that environment's Python for every following command. Do not install into
system Python or change the prior installation's `current` pointer. The compiler
and SUNDIALS prerequisites for the preserved cardiac engine still apply; see the
[external tester prerequisites](EXTERNAL_TESTER_GUIDE.md#1-install-the-right-candidate-with-one-command).

Run a fresh review stack from the checkout on three unused ports:

```bash
PYTHONDONTWRITEBYTECODE=1 ./.venv/bin/python -B tools/run_review_stack.py --base-port 8990
```

The runner prints a private review directory and serves Aegle at
`http://127.0.0.1:8990`, LIFE at `:8991`, and Cendos at `:8992`. It replaces inherited
mutable store paths and local credentials rather than borrowing operational data.
The installed ports 8850–8852 remain untouched. If 8990–8992 are occupied, choose
another unused consecutive range. The runner rejects occupied ports before starting.

Keep the foreground terminal running. Open the Aegle URL, not a local HTML file.
The loopback browser bootstraps its private session; there is no API-token copy
step. Do not record terminal output containing credentials or a Jupyter token.

For subsequent sessions, retain the printed directory privately and use:

```bash
PYTHONDONTWRITEBYTECODE=1 ./.venv/bin/python -B tools/run_review_stack.py --data-dir /absolute/printed/review-directory --base-port 8990
```

Stop only this foreground runner with Ctrl+C. Do not delete user stores or
terminate unrelated Python processes. Temporary review directories are not backups.

### Reference-model cache

The runner intentionally selects the review directory's own `models` folder.
Changing a general data-root variable in another shell does not move an existing
cache or reconfigure a running service. To install the preserved Human-GEM asset
for this review, substitute the actual printed review directory:

```bash
LIVEMORE_MODEL_DIR=/absolute/printed/review-directory/models ./.venv/bin/python -m livemorebio.model_assets install human-gem
LIVEMORE_MODEL_DIR=/absolute/printed/review-directory/models ./.venv/bin/python -m livemorebio.model_assets check human-gem
```

The model installer verifies fixed sources and hashes. The lobeline calculation
does not require Human-GEM, a solver download, a database entitlement or a patient
cohort. Missing model assets must not be replaced with fabricated output.

## 2. Confirm blank state and inspect the whole-person view

With a new review directory, Twins, Cohorts and Cendos History start empty. The
healthy reference preview is not an enrolled human or a saved demonstration twin.
Existing stores retain their records and active identity.

Open Atlas, Biology, LIFE Patch and Cendos. Check the selected context and units,
not just the page title. The whole-person overview is distinct from standalone
organ assets. A static atlas supplies reference context; it does not establish a
registered anatomical assembly or measured movement. Numerical output remains
inspectable when graphics cannot load.

For a saved metformin run, Biology offers preparation/exposure, recorded-response
and reference inspection stages. Only quantities actually stored for the selected
member are shown. Playback selects recorded model samples; changing member or
quantity must update its readout, plot and provenance together. PXR, Human-GEM and
lobeline use recorded concentration/constraint conditions, not fabricated time axes.

## 3. Understand LIFE Patch acquisition and alignment

V3 is additive to v2. The strict schema lives in
[`protocol_v3.py`](../livemorebio/life_patch/protocol_v3.py); exact-version dispatch
is in [`protocol.py`](../livemorebio/life_patch/protocol.py). A v3 packet includes:

- Registered device, mode, pseudonymous subject, sequence, manifest and firmware hashes.
- Acquisition start/end UTC, captured time equal to the acquisition end, monotonic
  session/start/end and UTC uncertainty. Service receipt time is recorded separately.
- Measurement identity, signal/unit, scalar or bounded waveform, explicit provenance,
  QC/calibration status and quality flags.
- Endpoint, biofluid, site, compartment, assay/cartridge and calibration/derivation
  identities, with missing fields retained as missing when the contract permits them.
- A frozen model context for modeled projections. Raw waveforms remain linked source
  blocks; they are not converted into invented scalar endpoints.

LIFE validates a registered manifest before admission. Its signed forwarding record
binds that manifest and the envelope. Aegle also checks the authoritative active
subject and device/protocol binding before admitting the observation. Physical or
external mode requires provisioned/attested device metadata, explicit consent and
custody, and encrypted storage. Those software checks do not authenticate actual
hardware-origin acquisition without the pending physical provisioning program.

The Patch view distinguishes virtual, inferred, technical-fixture and observed
records. Acquisition age and service receipt are not interchangeable. The UI's
60-second recency threshold is a display policy, not a sensor validity period.
An old or recent record is not proof of a continuously connected device.

### Virtual sampling is now explicit

`POST /api/patch/virtual` is the bound Aegle forwarding route;
`POST /patch/virtual/sample` is the LIFE route. The old behavior that read a mutable
global twin/bus snapshot and manufactured a sample is disabled.

- Legacy v2 requests must supply a nonempty `readings` object. The Aegle route
  resolves and verifies the active twin's virtual device binding; direct LIFE
  requests require the explicit `device_id` and `subject_id` as well.
- V3 requires a complete virtual `envelope`, including acquisition and model
  context, and a registered matching v3 manifest. The wrapper may not mix that
  envelope with sampling overrides. V3 requests cannot silently use a v2 binding.
- A caller-supplied number is not a measured sensor value. Virtual and technical
  test records remain nonphysical; do not submit fixtures to an operational store.

Use only the isolated test environment for packet-conformance exercises. This
guide deliberately does not invent a physical packet, subject, calibration
certificate or supposedly measured glucose value to make a dashboard look live.

### Residuals require a valid mapping

[`alignment.py`](../livemorebio/life_patch/alignment.py) compares an explicitly
bound observation against a frozen series, without extrapolation or parameter
updates. Its technical identity mapping is a software test facility. There is no
released physical sensor transfer/lag mapping in this candidate.

Missing mapping/context, different subjects/endpoints/units/sites/conditions,
failed QC, out-of-domain time and nonfinite results yield named unavailable
statuses. They must not produce a residual against a curve mean or another twin.
A calculated technical residual is unqualified and cannot authorize calibration.

## 4. Execute the source-backed lobeline assay

Open **Cendos Lab → Preparation → Lobeline / VMAT2**. This protocol needs no twin
or cohort because its context is isolated rat striatal synaptic vesicles.

1. Read the material and scope: lobeline hemisulfate, nominal assay concentration.
2. Select `uM`. Enter substrate concentrations `0, 0.001, 0.1, 0.11, 1, 5` and
   inhibitor concentrations `0, 0.25`. Unit changes change the meaning of entered
   values; the UI does not silently convert the text already entered.
3. Click **Run**. Inspect the returned immutable run ID, input/source digests,
   analytical controls and saved conditions. No physical measurement is created.
4. Open the run in **Biology**. Select each inhibitor and substrate condition.
   The readout, selected plotted point, table and source panel must refer to the
   same recorded condition. The VMAT2 schematic is static reference context.
5. Inspect the retained published discrepancy. Do not hide it or treat it as a
   passed validation gate.
6. Download the run's CSV and notebook. Recall it through History without running
   it again; prepare a rerun, then explicitly execute if a new calculation is wanted.

The original equation is `v = Vmax*S / (Km*(1 + I/Ki) + S)`. The source study used
an eight-minute uptake endpoint. The calculation is a stationary initial-rate
approximation using time-normalized parameters, not a measured instantaneous
trajectory or an eight-minute time simulation. The native axis is concentration.

The source-parameterized apparent Km at 0.25 uM differs from the same paper's
kinetic summary. The difference remains `UNQUALIFIED_DISCREPANCY`; parameters are
not refitted. The same-paper summary is not independent replication. No raw
replicate covariance or prospectively justified acceptance criterion is supplied.

See [the full scientific contract](LOBELINE_VMAT2_PROTOCOL.md) for parameters,
equation checks, source citation, material boundaries and exact input schema.
That document links the [original publication](https://doi.org/10.1124/jpet.109.160275).
The software does not infer human brain exposure, dopamine dynamics, efficacy,
whole-plant properties, dose advice or individualized biological responses.

## 5. Use the same workflow from terminal and Jupyter

In a second shell, replace the path with the review runner's actual directory,
use this checkout's environment, and keep the matching endpoint exports:

```bash
export LIVEMORE_DATA_DIR=/absolute/printed/review-directory
export LIVEMORE_AEGLE_URL=http://127.0.0.1:8990
export LIVEMORE_LIFE_URL=http://127.0.0.1:8991
export LIVEMORE_CENDOS_URL=http://127.0.0.1:8992
unset LIVEMORE_API_TOKEN
./.venv/bin/livemore attach
```

The client reads this review directory's private token rather than displaying it.
Save the JSON specification from the scientific contract in your editor, then:

```text
protocol lobeline /absolute/path/lobeline-assay.json
protocol history q=lobeline
protocol show <returned-run-id>
protocol prepare <returned-run-id>
protocol export <returned-run-id> notebook=/absolute/new/path/lobeline-analysis.ipynb
```

`protocol rerun <returned-run-id>` is an explicit new execution, not recall. It
retains the original run and parent digest. Changed input or source snapshots
require a declared new configuration. Do not supply the illustrative ID literally.

For Python, use `Platform(mode="attach").run_lobeline_vmat2(specification)` under
the same environment. The default in-process mode is not the running governed
service. Browser, SDK and terminal use the same protocol implementation and store.

Start Jupyter locally from a private analysis directory with this environment's
absolute Python path:

```bash
/absolute/path/to/checkout/.venv/bin/python -m jupyterlab --no-browser --ServerApp.ip=127.0.0.1
```

Open its locally printed URL privately. Load the exported notebook, use **Run →
Run All Cells**, inspect the hashes, independent equation calculations, discrepancy
and concentration plot, then Save. A generated notebook is not an executed
analysis. The notebook does not contact a participant, fabricate wet-lab data or
calibrate the active twin.

## 6. Verification status and acceptance record

| Gate | This candidate's release status |
| --- | --- |
| Full isolated regression and compile checks | 1,033 tests + 44 subtests passed; one optional repeat-download test skipped; native Human-GEM executed |
| Independent wire/API/source/UI review | Reported corrections verified independently; see verification record |
| Actual browser desktop/mobile interaction checks | Atlas, run-bound Biology, assay, native Human-GEM and LIFE prepared-file paths passed; native OS file picker and optional 3D renderer remain coverage limits |
| Detailed native interaction video and executed notebook | [Lobeline 4:35 and metformin 5:26](demo/measurement-integrity-atlas/README.md); both exported notebooks executed three code cells without errors |
| Publication | [PR #7](https://github.com/MannyAmah/livemorebio/pull/7), stacked feature branch; code/evidence checkpoint `75ba51f`; no merge or production deployment |
| Installer and hosted CI | Fresh editable environment passed; old one-line installer unchanged; hosted job status is linked in the verification record |
| Real device-origin recording or wet-lab comparison | Not supplied or established by this build |
| Physical sensor transfer model or human equivalence | Unavailable; not authorized by software tests |

Developers should run tests with isolated mutable stores, not against their normal
deployment:

```bash
./.venv/bin/python -B tools/run_review_tests.py -q
```

For an explicit native-model test run, supply a verified reference cache through
`LIVEMORE_TEST_MODEL_DIR` and `LIVEMORE_TEST_GENOME_MODELS=1`. No missing-model skip
counts as a successful native execution. Preserve safe error categories and test
artifacts; do not copy clinical payloads or credentials into reports.

The final record must identify the checkout commit, environment, actual command,
test counts/failures/skips, browser URL/viewport, selected run IDs, notebook cell
execution and video duration/hash. A screenshot alone is not evidence that a button
worked, and a software demonstration is not physical validation.

## 7. Next release gates, not features claimed here

1. Review PR #7 and its repository CI before merging the candidate.
   Repeat native file-picker and optional 3D-renderer acceptance on a supported
   tester workstation; the passed numerical fallback is not a registered-atlas pass.
2. Freeze a corrected LIFE Rev B0 engineering package. Resolve the reviewed core
   supply/clock, power-mode, pod-current-limit and incomplete-control-net issues
   before fabrication. No schematic/BOM/firmware release is made by this guide.
3. Implement and bench-test device-origin authentication, firmware/GATT framing,
   calibration traceability, clock synchronization and safe local command limits.
   Retain paired physical/virtual captures with device, channel and assay context.
4. Obtain lawful independent lobeline uptake data with material/lot identity,
   preparation, raw replicates, controls, units, QC and custody. Prespecify a
   separate nonhuman validation protocol and investigate the source discrepancy.
5. Add physical Cendos instrument adapters only with actual instrument contracts
   and qualified measurements. A software response cannot substitute for a run
   performed in a wet laboratory.
6. Reproduce source-complete insulin and other organ models against their native
   reference benchmarks, then qualify explicit cross-system transfer functions.
   Do not convert annotations or expression scores into invented kinetic constants.
7. Complete production identity, tenant isolation, managed keys, audit/consent
   operations and deployment approval before any partner-confidential or PHI use.

The existing [multiscale development roadmap](MULTISCALE_DEVELOPMENT_ROADMAP.md),
[biological change contract](BIOLOGICAL_MODEL_CHANGE_CONTRACT.md),
[Human-GEM source contract](HUMAN_GEM_MODEL_SOURCES.md) and
[licensed source policy](LICENSED_REFERENCE_INTEGRATION.md) still apply. No
unattended monitoring, physical manufacture or production deployment is implied.
