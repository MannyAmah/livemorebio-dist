# LIFE Patch v2 closed-loop operating contract

September 8 additive candidate: start with the
[measurement integrity review guide](MEASUREMENT_INTEGRITY_REVIEW_GUIDE.md).
It preserves v2 hashes, adds explicit v3 lineage and requires caller-supplied virtual
readings or a complete v3 envelope. Implicit mutable-twin sampling and unqualified
mean-curve residual examples below are historical, not the new operating contract.
Physical transfer mappings and human equivalence remain unavailable.

September research candidate: use the [Research validation guide](RESEARCH_VALIDATION_GUIDE.md)
for independent measurement intake. The legacy generic evidence POST is disabled;
neither a virtual packet nor a modeled Cendos endpoint authorizes clinical validation.
For current KEGG permissions and approved commercial transport configuration, see
[licensed reference integration](LICENSED_REFERENCE_INTEGRATION.md).

The v2 software contract connects the virtual LIFE Patch now and is the required
boundary for future physical devices:

```text
physical/mobile gateway ─┐
                         ├─> LIFE admission + durable journal
virtual LIFE Patch ──────┘          │
                                    ├─> Aegle observed-state overlay
                                    └─> Cendos protocol/evidence context

Aegle or Cendos request ─> LIFE safe-command broker ─> patch receipt
```

Telemetry is observation. It does not change Aegle model parameters or establish
person calibration. A qualified Cendos result is a counterpart measurement. It does
not become validation until the evidence service binds it to a frozen prediction,
protocol, endpoint, unit, time window, QC/calibration state, custody trail, acceptance
criterion, and independent review.

## Contract and corrected B0 target

`livemorebio.life_patch.protocol` defines the shared manifest, telemetry envelope,
admission rules, safe commands, and receipts. Physical and virtual manifests have the
same capability hash. Their mode and evidence class remain distinct.

The software target is `B0-EVT-target`:

- MAX30003 ECG over SPI;
- MAX86141 optical AFE over SPI;
- AD5940 electrochemistry/EIS; redundant LMP91000 removed;
- isolated pod I²C with DS28C36 pod authentication;
- QSPI local storage.

This is a target contract, not proof that hardware or firmware exists or conforms.

## Bind the Patch to a governed twin

Create or admit the subject at <http://127.0.0.1:8850/twins>, activate that twin, then
bind its virtual Patch contract. The same lifecycle is available from `livemore attach`:

```text
twin list
twin admit ./synthetic-twin.json key=patch-demo-001
twin activate twin-... version=1
twin patch twin-... version=2 mode=virtual device=virtual-life-patch-001
```

Real-human admission requires consent, chain of custody, field-level source records, and actual
admitted core-domain data. Merely declaring EHR, device, laboratory, genomic, medication,
lifestyle, or environmental sources does not satisfy profile coverage. Physical pairing also
requires `life_patch` consent, an active human twin, protocol `2.0`, the
`B0-EVT-target` hardware revision, firmware version, current calibration, and an attestation
reference. One physical device fingerprint cannot bind to two twins. Pairing records metadata
only; telemetry remains pending until LIFE accepts a signed v2 envelope.

The virtual sample route resolves the active twin's recorded virtual-device binding. It rejects
an unbound subject or a caller-supplied device that does not match that binding, preventing Atlas,
the Patch dashboard, and Cendos from silently using different device identities.

## Start and exercise the virtual loop

```bash
./.venv/bin/livemore start all
export LIVEMORE_API_TOKEN="$(./.venv/bin/livemore token)"
export LIVEMORE_ACTIVE_SUBJECT="$(./.venv/bin/livemore workspace --full | jq -r '.subject.subject_id')"

curl -fsS -X POST http://127.0.0.1:8850/api/patch/virtual \
  -H "Authorization: Bearer ${LIVEMORE_API_TOKEN}" \
  -H 'Content-Type: application/json' \
  -d "{\"subject_id\":\"${LIVEMORE_ACTIVE_SUBJECT}\"}"

curl -fsS http://127.0.0.1:8850/api/state \
  -H "Authorization: Bearer ${LIVEMORE_API_TOKEN}"
curl -fsS "http://127.0.0.1:8851/patch/telemetry?subject_id=${LIVEMORE_ACTIVE_SUBJECT}" \
  -H "Authorization: Bearer ${LIVEMORE_API_TOKEN}"
```

The Aegle response must show the latest values under `observations`. The
`profile_params` object must remain unchanged by ingestion, and
`person_calibrated` must remain false.

## Send a safe request back to a patch

```bash
curl -fsS -X POST http://127.0.0.1:8851/patch/commands \
  -H "Authorization: Bearer ${LIVEMORE_API_TOKEN}" \
  -H 'Content-Type: application/json' \
  -d '{"device_id":"virtual-life-patch-001","command":"request_quality_check","parameters":{}}'
```

Only sampling, burst capture, chemistry-session, quality-check, and calibration-check
commands are allowed. Therapeutic actuation is outside v2 and is rejected.

## Physical gateway admission

A physical/mobile gateway first registers a `DeviceManifest`, then sends a
`TelemetryEnvelope` to LIFE:

- `POST /patch/devices`
- `POST /patch/telemetry`
- `GET /patch/commands?device_id=...`
- `POST /patch/commands/receipts`

Physical and external manifests require an `X-Livemore-Device-Attestation` HMAC created
by the trusted provisioning workflow. Virtual devices are created internally. The
launcher generates owner-only local storage and admission keys for development; production
mode requires externally managed keys.

For real-human telemetry, the request body wraps the envelope with explicit
`consent_scope` and `chain_of_custody`. LIFE rejects unregistered devices, mismatched
contracts, invalid hashes, NaN/infinite/out-of-range values, stale or future timestamps,
bad units, failed quality/calibration, and replayed/out-of-order sequences.

The local implementation hashes each canonical envelope, encrypts physical/external
telemetry at rest with AES-256-GCM, and signs LIFE-to-Aegle admissions. A physical release
still requires device-origin packet signatures, hardware-rooted provisioned identities,
and rotation/revocation procedures.

## Cendos wet-lab counterpart intake

`POST http://127.0.0.1:8852/evidence/lab-results` accepts a pseudonymized qualified-lab
record only when QC and calibration pass and consent and custody are present. It returns a
hashed `counterpart_outcome` measurement plus `validation_status: not_assessed`.

Every patch and lab submission must contain `subject_pseudonymized: true` and use the
opaque `pseudonym-<id>` subject namespace; the boolean alone is not accepted as proof.
Reading an admitted counterpart through `GET /patch/latest` requires the operator token,
that pseudonymous `subject_id`, and the exact telemetry `envelope_hash`. LIFE persists an
immutable snapshot per admitted hash, so a newer sample cannot make a protocol-bound older
sample unreachable; a global "latest patient" read is deliberately impossible.

The first two governed software protocols create concrete counterpart targets:

- metformin: frozen cohort member, dose, exposure/PK, OGTT timing, glucose and biomarker endpoints;
- purified garcinoic acid: compound identity and concentration, human PXR reporter engagement,
  CYP3A4 readout, and exposure measurement linked to the 6P2B evidence context.

Their software outputs stay `MODELED_MECHANISTIC` or
`STRUCTURE_AND_IN_VITRO_BACKED_MODEL`. A Cendos measurement must reference the exact frozen run,
protocol, cohort/member, endpoint, unit, time window, instrument, calibration, QC result, and
custody record before an evidence reviewer can assess equivalence.

The local plaintext evidence runtime intentionally blocks storing real-human or qualified
lab payloads in a package. Production use requires an encrypted, tenant-isolated,
role-authenticated, audited PHI deployment before that capability is enabled.

## Scientific reference adapters

KEGG and GeneCards connectors are fail-closed. They make no request without explicit
commercial entitlement configuration. License IDs and tokens never appear in registry
responses; an audit-safe entitlement fingerprint does.

```bash
export LIVEMORE_KEGG_COMMERCIAL_LICENSE=acknowledged
export LIVEMORE_KEGG_LICENSE_ID='agreement-record-id'

export LIVEMORE_GENECARDS_COMMERCIAL_LICENSE=acknowledged
export LIVEMORE_GENECARDS_LICENSE_ID='agreement-record-id'
export LIVEMORE_GENECARDS_API_BASE='https://licensed-provider-endpoint.example/api/'
export GENECARDS_API_TOKEN='provider-token'
```

GeneCards uses only the configured licensed JSON gateway; it never scrapes HTML. Source
records are scientific reference context, not experimental validation. Query the combined
licensed context after configuration with:

```bash
curl -fsS http://127.0.0.1:8851/reference/genes/TCF7L2 \
  -H "Authorization: Bearer ${LIVEMORE_API_TOKEN}"
```

## Required artifacts before physical equivalence can be claimed

- authoritative Rev B0 hardware manifest, BOM, pin map, and fabrication revision;
- firmware repository and immutable commit;
- BLE GATT/packet framing specification;
- device key provisioning, rotation, and revocation procedure;
- calibration-certificate schema and non-PHI sample;
- golden packet vectors or bench captures from real devices;
- per-channel analytical validation plan and acceptance criteria;
- paired virtual/physical conformance dataset.

Until these are supplied and tested, the console correctly says physical hardware is
pending.

## Physical implementation sequence

1. Freeze the authoritative Rev B schematic/BOM/PCB and reconcile every inherited Rev A.1 file
   with the B0 target above.
2. Implement signed firmware-v2 packets, BLE/mobile gateway transport, clock synchronization,
   device-root identity, safe-command enforcement, and an immutable firmware release manifest.
3. Complete bench characterization, calibration traceability, electrical/EMC, biocompatibility,
   adhesive, cybersecurity, human-factors, and per-channel analytical validation plans.
4. Collect paired physical/virtual recordings under frozen protocols and quantify sensor,
   timing, missingness, drift, and state-estimation residual tolerances.
5. Enable real-human model calibration only through released evidence authorization; never from
   a prediction, a single unqualified sample, or a cloud command that bypasses local safety.
