# Launching and operating LivemoreBio

**Extended candidate:** use [the external tester guide](EXTERNAL_TESTER_GUIDE.md)
for its one-line branch-pinned installation, Human-GEM execution, empty-workspace
rules, healthy preview, paged History/reruns, terminal and notebook examples.
[Verification evidence](GENOME_MODEL_REVIEW_EVIDENCE.md) and the
[next-organ/LIFE/physical-Cendos roadmap](MULTISCALE_DEVELOPMENT_ROADMAP.md) are separate
from the preserved candidate results below. Do not assume a main installation
contains unmerged features.

September 5 candidate: use [Research validation operations](RESEARCH_VALIDATION_GUIDE.md)
for the isolated 8860–8862 stack, the new Research tab, terminal commands, strict evidence
intake and the replacement detailed recordings. The main installer below installs main,
not an unmerged candidate. See [readiness gates](PHARMA_READINESS_AND_ROADMAP.md).

This guide launches the local research product: LIFE on `127.0.0.1:8851`, Aegle on
`127.0.0.1:8850`, and Cendos on `127.0.0.1:8852`. It is for model-only pharmaceutical
hypothesis triage. It is not approved for production PHI, clinical decisions, dosing,
device control, or regulator-facing evidence claims.

## 1. Install with one command

The source repository is private. The installer therefore uses GitHub CLI authorization
instead of placing a personal access token in a URL or shell history. Requirements:

- [GitHub CLI](https://cli.github.com/) with access to `MannyAmah/livemorebio`
- one completed `gh auth login`
- Python 3.11 (`python3.11`)
- Bash 3.2+ and `tar` (included on supported macOS and Linux hosts)

Copy and run this single line:

```bash
bash -c 'set -euo pipefail; command -v gh >/dev/null || { echo "Install GitHub CLI first: https://cli.github.com" >&2; exit 1; }; gh auth status >/dev/null || { echo "Run: gh auth login" >&2; exit 1; }; c=$(gh api repos/MannyAmah/livemorebio/commits/main --jq .sha); f=$(mktemp); trap '\''rm -f "$f"'\'' EXIT; gh api "repos/MannyAmah/livemorebio/contents/install.sh?ref=$c" -H "Accept: application/vnd.github.raw+json" >"$f"; test -s "$f"; LIVEMORE_REF="$c" bash "$f"'
```

The installer:

1. resolves `main` to one exact commit and downloads that commit through authenticated
   GitHub APIs;
2. installs into `~/.local/share/livemorebio/releases/<commit>/`;
3. creates an isolated Python 3.11 environment and installs the exact
   `dev,kernels,server,notebooks` dependency graph from a hash-verified lock;
4. runs the complete tests, compile check, and CLI smoke check;
5. installs a stable launcher and atomically points `current` at the verified release;
6. records a full release digest outside the release tree and adds one marked PATH block
   to `.zshrc` or `.bashrc` when needed.

Re-running the same line updates LivemoreBio. Installation failures never replace the
working `current` release. The installer does not read, move, or delete runtime state or
keys under `~/.livemore/`.

The stable launcher also avoids Python's absolute console-script shebang limit when the
managed release directory has a long path. It always invokes the active release through
its own Python 3.11 environment.

### Manual developer checkout

Use this only when you need an editable source tree. Native scientific kernels may
require a C/C++ toolchain on a new machine.

```bash
git clone git@github.com:MannyAmah/livemorebio.git
cd livemorebio
python3.11 -m venv .venv
./.venv/bin/python -m pip install --require-hashes -r requirements-python311.lock
./.venv/bin/python -m pip install --no-deps --no-build-isolation -e .
./.venv/bin/python -m pytest -q
./.venv/bin/python -m compileall livemorebio
```

The release gate is zero failures in the full suite and compile check. Optional or
network-gated checks may be skipped with their reason shown.

## 2. Start the product

```bash
livemore start all
livemore status
livemore workspace
livemore open
```

`start` launches detached loopback services, waits for stable health responses, and creates
a random operator token plus separate storage-encryption and internal patch-admission keys
if they do not exist. `livemore open` opens the loopback origin. That origin bootstraps an
HttpOnly, SameSite=Strict session cookie automatically, so the browser has no token prompt
and stores no token in JavaScript-accessible storage.

`livemore token` remains available only when an explicit API client such as `curl` needs a
bearer value. The attached terminal and SDK read the owner-only launcher token directly.
There is no external token provider, account page, or manual token-generation workflow.

You can also double-click `Livemore Console.command` on macOS. Stop everything with:

```bash
livemore stop all
```

## 3. Confirm service health

```bash
curl -fsS http://127.0.0.1:8850/health
curl -fsS http://127.0.0.1:8851/health
curl -fsS http://127.0.0.1:8852/health
```

OpenAPI is available at:

- Aegle: <http://127.0.0.1:8850/docs>
- LIFE: <http://127.0.0.1:8851/docs>
- Cendos: <http://127.0.0.1:8852/docs>

## 4. Walk every product page

### Executable multiscale Atlas, `/`

1. Open <http://127.0.0.1:8850/>.
2. Confirm the header says `LOCAL · AUTHENTICATED`; loopback authorization is automatic.
3. Traverse Whole Body → Cardiovascular → Heart → Ventricular Tissue → Cardiomyocyte
   → Ion Channel → Gene/Protein. Selection must update the anatomy focus, functional
   value, engine lineage, and evidence inspector together.
4. Run metformin. The action must visibly pass through queued, running, and completed;
   the baseline-versus-treated glucose and insulin traces and cross-scale mechanism must
   update from the same person-specific execution.
5. Request a virtual Patch sample. The Observed tab must show its v2 observation against
   the virtual sensor prediction as an unqualified residual. It must not show physical
   hardware, person calibration, or clinical validation.
6. Inspect Reference. All 15 systems have formal variables, units, inputs, outputs,
   time scales, perturbations, and maturity. Systems without engines must say
   `UNAVAILABLE` and return no invented biological state.
7. Use the product rail to open the preserved surfaces. The previous Twin console is at
   <http://127.0.0.1:8850/legacy>.

### Digital twins, `/twins`

1. Select **Reference-grounded research person** for a non-person twin. Choose a governed
   population stratum and seed; the server, not the browser, creates the profile from
   `livemore-public-metabolic-reference-v1`. Confirm the record shows
   `REFERENCE_GROUNDED_SYNTHETIC`, the source release, member lineage, and an opaque
   `pseudonym-` subject identifier.
2. Activate it. Atlas, the virtual LIFE Patch, Cendos, terminal, and notebooks now resolve
   the same authoritative subject. Activation demotes the previously active record, so only
   one twin is authoritative. The pointer survives Aegle restarts.
3. Bind a virtual Patch and confirm the device contract appears on the twin record.
4. Select **Consented real-human data** only for a lawfully admitted person bundle. Provide
   explicit consent and purpose, chain of custody, and source records for the applicable
   EHR/FHIR, laboratory, medication, LIFE Patch or wearable, genomic, lifestyle, and
   environmental fields. The browser records bounded, pseudonymized summaries; do not enter
   names, medical-record numbers, raw notes, or exact locations.
5. Confirm `ADMITTED_COMPLETE` before activation. Declaring a source domain without admitting
   corresponding data does not count as coverage, and missing real-human values are not filled
   from a population prior without an explicit `REFERENCE_INITIALIZED` field provenance.
6. Physical Patch pairing is metadata admission only. It requires an active consented
   real-human twin, protocol `2.0`, hardware target `B0-EVT-target`, firmware version,
   current calibration, and an attestation reference. Telemetry remains
   `PENDING_SIGNED_ENVELOPE`; pairing does not prove hardware or human-use readiness.
7. One pseudonymous subject cannot be admitted as two twins, and one physical device cannot
   be paired to two subjects.

### Cohorts, `/cohorts`

1. Create a reference-grounded cohort with an explicit name, size, indication, seed, and
   one of the governed strata: `dpp-high-risk-metabolic`,
   `nhanes-diagnosed-diabetes-older`, or `pxr-reference`.
2. Confirm the record is `FROZEN` and shows the pinned source manifest, immutable member
   fingerprints, and varied member summaries. Repeating the same source/stratum/seed is
   deterministic; members within a cohort are not clones.
3. A real-human cohort accepts only explicitly listed, active real-human twin IDs. It never
   silently fills members from synthetic or reference records.
4. OpenMed is an optional local de-identification and clinical entity-intake processor. It is
   not a population dataset and cannot be selected as a cohort source.

### Biology, `/biology`

1. Open <http://127.0.0.1:8850/biology>.
2. Select an organ card and return to all organs.
3. If WebGL is available, rotate the anatomy, toggle labels, and test a cross-section.
4. If WebGL is unavailable, the page must say so and retain the organ/state drill-down.
   A blank or permanently loading page is a defect.
5. Reference anatomy is not executed organ function. Kidney, brain and adipose
   physiology remain unavailable; basal glucose, insulin sensitivity and responsivity
   are labeled model parameters with units, not invented cellular transport rates.
6. The Human-GEM run-specific view is an independent condition comparison with no
   biological-time animation. See the external guide for precise interpretation.

### LIFE Patch, `/patch`

1. Open <http://127.0.0.1:8850/patch>.
2. Pause/resume the timeline and change playback speed.
3. Select `virtual patch v2`. Confirm the B0 target, protocol version, sequence, and virtual
   connected badge appear. The observation cards remain separate from modeled traces.
4. Load a CGM demo and inspect provenance. Demo packets populate observed state only and may
   not claim person calibration, hardware presence, or clinical validation.
5. Pending channels stay pending. Fixed skin temperature remains marked nominal.

### Cendos Lab, `/cendos`

The extended candidate opens blank **Preparation** every time. **History** is
paged/searchable; **Recall** is read-only, and **Prepare rerun** requires a separate
Run to create a new parent-linked result. New experiment clears the view only.
Human-GEM oxygen/ATP conditions do not require or represent human cohorts.

1. Open <http://127.0.0.1:8850/cendos>. The page lists only cohorts eligible for each
   governed protocol.
2. For the metformin comparison, select one DPP high-risk cohort and one older
   diagnosed-diabetes cohort. Set the oral dose and OGTT load, then run the protocol.
   Inspect per-member baseline glucose, SLC22A1/OCT1 state, renal factor, modeled AUC/Cmax,
   OGTT deltas, decision, cohort mean, and within-cohort range.
3. For the plant-chemical workflow, select a `pxr-reference` cohort and run purified
   garcinoic acid at the displayed free-concentration series. Inspect 6P2B, receptor
   occupancy, individualized NR1I2-expression response, and the explicit
   `CYP3A4 NOT_QUANTIFIED` boundary. The whole seed or an extract is not represented.
4. Use **Download analysis CSV**, **Open Jupyter notebook**, and **Visualize this run in
   Biology**. Biology is run-scoped with `?run_id=...`; it does not silently display the
   most recent unrelated experiment.
5. Create an evidence package from a completed eligible run before leaving the page. The capture
   is awaited, so the button cannot race an unfinished handoff.
6. Open its tabs. Its claim state remains `model_only` until governed counterpart
   measurements and validation events exist.
7. Exporting locks the package and therefore uses authenticated `POST`, not a mutating GET.

These protocol runs are executable software calculations. The metformin output is
`MODELED_MECHANISTIC`; the garcinoic-acid output is
`STRUCTURE_AND_IN_VITRO_BACKED_MODEL`. Neither is an observed human reaction or a clinical
efficacy, safety, or dosing result.

### Scientific adapters, `/adapters`

1. Open <http://127.0.0.1:8850/adapters>.
2. Confirm the catalog summary shows 39/39 ELIXIR Core Data Resources and the NAR
   summary-entry snapshot. NAR reports 2,173 independent databases while its official
   alphabetical page contains multiple summary papers for updated resources; the product
   preserves that distinction instead of claiming false deduplication.
3. Click every workflow route. Only `workflow_wired` or
   `scientifically_qualified` sources may appear in a runtime route; catalog-only sources
   remain excluded and their count stays visible in the lifecycle funnel.
4. Review access, integration state, product consumer, capabilities, and source license.
5. Run bounded health probes. A reachable adapter is only operationally ready. It does not
   validate a model or evidence claim. Probes use authenticated `POST /api/adapters/probe`;
   ordinary registry reads use `GET /api/adapters` and never trigger network egress.
6. KEGG and GeneCards remain blocked until commercial/licensed access is recorded. When
   enabled, query a gene through LIFE's authenticated `GET /reference/genes/{symbol}` and
   confirm the response remains labeled `reference_context_only`; it must not change a
   validation state. USDA
   FoodData Central remains credential-gated until `USDA_API_KEY` is set. Rosalind is an
   external governed-workbench handoff, not an in-process database.

## 5. Use the terminal product

Start an isolated research shell:

```bash
livemore shell
```

Attach the shell to the live browser twin:

```bash
livemore attach
```

Example isolated workflow:

```text
patient t2d
show workspace
action metformin dose=1
show workspace
patch sample
sources workflow=reactions_metabolism limit=10
cohort 12 seed=17
screen metformin mode=metformin n=12 seed=17 dose=1.0 grams=75
report livemore-screen-report.md
audit verify livemore-screen-report.audit.json
quit
```

Governed live subject operations use the attached shell:

```text
twin list
twin admit ./synthetic-twin.json key=admission-001
twin activate twin-... version=1
twin patch twin-... version=2 mode=virtual device=virtual-shell-001
cohort list
cohort create name='DPP cohort' size=24 seed=17 indication=type-2-diabetes source=REFERENCE_GROUNDED_SYNTHETIC stratum=dpp-high-risk-metabolic
cohort create name='Older T2D cohort' size=24 seed=18 indication=type-2-diabetes source=REFERENCE_GROUNDED_SYNTHETIC stratum=nhanes-diagnosed-diabetes-older
cohort create name='PXR cohort' size=24 seed=19 indication=pxr-research source=REFERENCE_GROUNDED_SYNTHETIC stratum=pxr-reference
protocol metformin cohort_a=cohort-... cohort_b=cohort-... dose=1000 grams=75
protocol garcinoic cohort=cohort-... concentrations=0.05,0.33,1.3,5.0
protocol latest
protocol history limit=10
models
protocol metabolic ./oxygen-capacity.json
protocol show protocol-REPLACE_WITH_RETURNED_ID
protocol prepare protocol-REPLACE_WITH_RETURNED_ID
protocol export protocol-REPLACE_WITH_RETURNED_ID notebook=./analysis.ipynb
```

Admit real-human bundles from a protected JSON file rather than typing observations or
identifiers into shell history. The browser and terminal call the same version-checked API.

Only the declared T2D-enriched/OGTT screen context is admitted in Phase 1. Unsupported
indications, cohorts, and assays fail closed instead of generating rankings.

For a compact read of the same live Atlas projection shown in the browser:

```bash
livemore workspace
livemore workspace --full > multiscale-workspace.json
livemore sources --workflow genome_variants --limit 20
livemore sources --collection elixir --lifecycle cataloged --limit 20
```

## 6. Call authenticated APIs

Mutation routes and selected PHI-like reads require the bearer token. Health, static
manifests, and public adapter-registry reads do not:

```bash
livemore token
export LIVEMORE_API_TOKEN='paste-the-printed-token-here'
curl -fsS -X POST http://127.0.0.1:8850/api/screen \
  -H "Authorization: Bearer ${LIVEMORE_API_TOKEN}" \
  -H 'Content-Type: application/json' \
  -d '{"compound":"metformin","mode":"metformin","n":4,"seed":17,"indication":"type-2-diabetes","cohort":"t2d-enriched","assay":"ogtt"}'

curl -fsS http://127.0.0.1:8850/api/state \
  -H "Authorization: Bearer ${LIVEMORE_API_TOKEN}"

curl -fsS http://127.0.0.1:8850/api/workspace \
  -H "Authorization: Bearer ${LIVEMORE_API_TOKEN}"

curl -fsS 'http://127.0.0.1:8850/api/scientific-sources?workflow=proteins_structures&limit=20'
```

Do not paste patient identifiers, clinical notes, biomarkers, or other PHI into shell
history or test payloads.

## 7. Scientific adapter configuration

The default open retrieval paths are ChEMBL, PubChem, Open Targets, UniProt, RCSB PDB,
Reactome, GWAS Catalog, OLS, and the Human Reference Atlas. Their product usage and
licensing are visible in `/adapters`.

The versioned catalog contains metadata for the official NAR and ELIXIR collections.
Catalog records default to `cataloged` and `catalog_metadata_only`; they are not queried
until the evaluation, configuration, operation, and workflow-wiring gates are recorded.
Refresh the snapshot during a governed release process with:

```bash
python3 tools/refresh_scientific_source_catalog.py
python3 -m pytest -q livemorebio/tests/test_scientific_source_catalog.py
```

For a Neo4j evaluation environment, provide secrets externally:

```bash
export NEO4J_URI='neo4j+s://your-managed-instance'
export NEO4J_USERNAME='livemore-loader'
export NEO4J_PASSWORD='from-your-secret-manager'
export NEO4J_DATABASE='livemore-reference'
```

No Neo4j credentials are stored in source. The backend uses parameterized properties and
fails closed when configuration is incomplete. Production use still requires an approved
edition/topology, RBAC, backup/restore verification, and live integration qualification.

TuringDB remains an isolated evaluation candidate. Setting `TURINGDB_ENDPOINT` records only
configuration; it does not clear the commercial licence, durability, access-control, or
benchmark gates and does not make TuringDB workflow-wired.

OpenMed is optional local clinical intake. Install and stage locally approved model artifacts
in an isolated environment, then use its current Python API through `OpenMedNER`. PHI-like
text is masked locally before analysis; if OpenMed is unavailable the request fails closed.
Synthetic/non-PHI development text may still use the deterministic substrate extractor.

Optional credentials belong in the environment, never source control:

```bash
export USDA_API_KEY='your-key'
```

KEGG and GeneCards are intentionally fail-closed. After legal approval, configure the
entitlement and access environment variables documented in
[`LIFE_PATCH_CLOSED_LOOP.md`](LIFE_PATCH_CLOSED_LOOP.md). GeneCards uses a licensed JSON
gateway and never website scraping. KEGG uses its REST service only after a recorded
commercial entitlement. Adapter readiness is reference access, not experimental validation.
The combined, provenance-bearing lookup is:

```bash
curl -fsS http://127.0.0.1:8851/reference/genes/TCF7L2 \
  -H "Authorization: Bearer ${LIVEMORE_API_TOKEN}"
```

## 8. Docker mode

```bash
livemore up
livemore token
livemore status
livemore down
```

`livemore up` supplies the generated operator token, AES-256-GCM storage key, and internal
patch-admission HMAC key to all three containers. If you call `docker compose` directly,
set `LIVEMORE_API_TOKEN`, `LIVEMORE_PATCH_STORAGE_KEY`, and
`LIVEMORE_PATCH_ADMISSION_HMAC_KEY` first or Compose will refuse to start.

## 9. Runtime state and logs

Local runtime files live under `~/.livemore/`:

- `api-token`, owner-only local operator token
- `patch-storage.key`, owner-only AES-256-GCM key for PHI-like local state
- `patch-admission.key`, owner-only key for LIFE-to-Aegle admission and manifest attestation
- `registry.json`, service discovery
- `subjects.sqlite3`, encrypted twin/cohort payloads plus opaque subject/device uniqueness indexes
- `cendos-protocol-runs/`, immutable run-scoped protocol JSON plus the latest-run pointer
- `cendos-protocol-runs/.index.sqlite3`, additive bounded History metadata index
- `models/`, owner-only pinned Human-GEM reference assets and integrity receipt (not patient data)
- `LIFE.log`, `Aegle.log`, `Cendos.log`, detached service logs
- `screen-runs/`, run-scoped screen artifacts
- `evidence.sqlite` and `evidence-exports/`, governed evidence package state
- `pipeline-audit.jsonl` and `livemore-sign-hmac.key`, local integrity records
- `patch-telemetry.jsonl`, encrypted admitted LIFE Patch v2 envelopes and evidence references
- `patch-telemetry.devices.json`, registered device manifests
- `patch-telemetry.commands.jsonl`, safe commands and device receipts

These files can contain research inputs or outputs. Treat them as PHI-like even in development.
Production mode refuses to generate storage or admission keys locally; inject externally
managed values from the deployment secret manager or KMS-backed workflow.

## 10. Review the interactive demonstrations

The checked-in recordings use reference-grounded, non-person research records only and show
native browser navigation, clicks, API-backed execution, and visible state changes:

- [governed workspace](demo/livemorebio-governed-workspace-demo.mp4)
- [metformin across two individualized cohorts](demo/livemorebio-metformin-two-cohorts-demo.mp4)
- [purified garcinoic acid → human PXR](demo/livemorebio-garcinoic-acid-pxr-demo.mp4)

They are not screenshot slideshows and do not contain real-person data. The second protocol
video is paced for readability after native browser capture; no results or frames were added.
See [VALIDATION_AND_DEMO_GUIDE.md](VALIDATION_AND_DEMO_GUIDE.md) for exact run results,
source hashes, interpretation, and the physical validation work still required.

The general workspace recorder can be regenerated after starting the product and installing
Playwright in a developer environment:

```bash
npm install --no-save playwright
node tools/record_demo.cjs
```

Set `LIVEMORE_DEMO_URL` or `LIVEMORE_DEMO_OUTPUT` to override the default loopback URL or
output path. The recorder fails if the browser emits an error; it does not assemble screenshots.

## 11. Troubleshooting

`401 authentication required` in the browser: open the product through
`http://127.0.0.1:8850`, not `file://` or another hostname, then reload. For `curl`, add
`Authorization: Bearer $(livemore token)` without printing or committing the value.

`503 mutation API disabled`: the service was started outside `livemore start` without
`LIVEMORE_API_TOKEN`. Stop and restart the stack through the CLI.

Port already in use or old code still visible: run `livemore stop all`, confirm `livemore
status` shows all services down, then start again. Do not use broad `pkill` commands.

Biology says 3D unavailable: enable WebGL/hardware acceleration or use another browser. The
organ cards and state readouts must still work.

ChEMBL or another open adapter is degraded: retry later or use an already pinned successful
resolution. Never replace a failed source with fabricated targets.

## 12. Scientific and product boundary

LivemoreBio is being built toward a biological functional human-body replica, but this release
does not claim that outcome. Fifteen systems are architecturally registered and reference-backed;
the metabolic and cardiovascular contexts are the executable coupled models. No current system
is person-calibrated, context-validated, independently replicated, regulator-ready, or connected
to validated LIFE Patch hardware. The virtual v2 device proves software-contract parity only.
Research intended for human transfer still requires assay, model, context-of-use, validation,
quality, ethics, clinical, and regulatory gates. See the
[closed-loop guide](LIFE_PATCH_CLOSED_LOOP.md) for API operation and the
physical-equivalence artifact list.
