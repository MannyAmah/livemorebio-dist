# KEGG and MalaCards reference integration

Updated 2026-09-05. These adapters supply reference context; importing annotations
does not add kinetic parameters, update a person's genome, qualify a model, or
turn a computational result into a physical measurement.

## Verified access routes

KEGG requires a commercial license for nonacademic use. The public API at
`rest.kegg.jp` is restricted to academic users. Pathway Solutions provides licensed
downloads and mirror services. Obtain the applicable agreement and delivery route:
[KEGG terms](https://www.kegg.jp/kegg/legal.html),
[API restrictions](https://www.kegg.jp/kegg/rest/),
[commercial licensing](https://www.pathway.jp/en/licensing.html).

MalaCards offers commercial licensing for pharma, biotech and AI companies.
LifeMap advertises JSON, SQL, Neo4j CSV, Biolink TSV and REST delivery for its
Knowledge Graph. Actual vendor schemas and endpoint access depend on the customer
agreement. Suite terms restrict scraping and unauthorized AI training:
[MalaCards](https://www.lifemapsc.com/malacards/),
[delivery formats](https://www.lifemapsc.com/knowledge-graph/),
[terms](https://www.lifemapsc.com/terms-of-use/).

An environment flag or a locally entered license ID records an operator's declaration.
It is not independent verification of a vendor agreement. Local files remain subject
to that agreement, including model-training and redistribution restrictions.

## Local import contract

Use a local licensed export normalized into `livemore.disease-reference.v1`.
The normalized schema is Livemore's contract, not an invented vendor API schema.
Preserve the original export and its SHA-256 digest separately. Do not put licensed
data in Git, public artifacts, prompts or third-party tools without the applicable
permission.

```python
from livemorebio.life_system.reference.sources import LicensedReferenceStore

store = LicensedReferenceStore("/absolute/local/licensed-references")
receipt = store.import_records(manifest, records)
context = store.disease_context("malacards", "vendor_disease_identifier")
```

The default location is `<LIVEMORE_DATA_DIR>/licensed-references` (or
`~/.livemore/licensed-references` when the data root is unset), overrideable with
`LIVEMORE_LICENSED_REFERENCE_DIR`. Files have owner-only permissions. Imports are
content-addressed and keep prior releases; the active source pointer is atomic.
Lookups verify hashes, schema, permissions and expiry on every read.

Manifest required fields:

| Field | Contract |
|---|---|
| `schema` | `livemore.licensed-reference-manifest.v1` |
| `record_schema` | `livemore.disease-reference.v1` |
| `source` | Exact lowercase `kegg` or `malacards` |
| `release` | Vendor release identifier |
| `normalization_version` | Version of the vendor-to-Livemore transformer |
| `upstream_sha256` | SHA-256 of the original licensed export |
| `acquired_at`, `expires_at` | ISO timestamps with timezone; permission must be current |
| `license_id`, `approval_reference` | Locally recorded agreement and approval references; not returned by lookups |
| `permissions` | Explicit booleans: `internal_research`, `reference_lookup`, `model_training`, `redistribution`; the first two must be true |
| `record_count` | Exact number of normalized records, 1–5,000 |
| `records_sha256` | SHA-256 of canonical normalized JSON |

Canonical JSON is `json.dumps(records, sort_keys=True, separators=(",", ":"),
ensure_ascii=True, allow_nan=False).encode("utf-8")`. The full manifest/records
payload is limited to 5 MB. This is a bounded research import, not a bulk release
loader for every vendor record.

Each record has exactly `id`, `name`, `description`, `genes`, `pathways`,
`identifiers`, `citations`. Genes, pathways and citations are arrays of strings;
identifiers is a namespace-to-identifier mapping. KEGG disease IDs use `H` plus
five digits. MalaCards IDs use lowercase alphanumeric/underscore identifiers.
Lookup is exact, so an ambiguous substring never picks a different disease.

`source_status(source)` returns `available`, `unavailable` or `invalid`.
`disease_context(source, identifier)` additionally returns `not_found`; a valid
result carries the release digest, record digest, reference evidence class,
`physiology_effect: none` and `qualification_state: NOT_QUALIFIED`.

For API/SDK integration:

```python
from livemorebio.life_system.reference.sources import get_disease_context

result = get_disease_context("kegg", "H00409")
```

This function performs local lookup only. The service exposing it must enforce
operator authorization and keep data within the licensed deployment boundary.
`MalaCards(directory=...).disease(identifier)` wraps the same path.

## KEGG commercial transport

The REST adapter requires all of:

- `LIVEMORE_KEGG_COMMERCIAL_LICENSE=acknowledged`
- `LIVEMORE_KEGG_LICENSE_ID` identifying the applicable agreement
- `LIVEMORE_KEGG_API_BASE` containing the vendor-approved HTTPS base URL
- `LIVEMORE_KEGG_APPROVED_HOST` matching that URL's hostname exactly
- Optional `LIVEMORE_KEGG_API_TOKEN` for a vendor-approved bearer-authentication route

No endpoint or credential is supplied by Livemore. The academic REST host is
rejected even if entered as the approved host. URLs with embedded credentials,
query strings or fragments are rejected; redirects are rejected to prevent
credential forwarding. Requests are serialized at no more than three per second.
Cache entries are scoped to the recorded entitlement and endpoint. A configured
adapter still requires connectivity and response-schema verification before it
can be described as operational.

`KEGG.disease(identifier)` first checks an authorized local disease release, then
uses configured transport if available. API-ready `get_disease_context` is local
only and makes the source's permission/missing-data status explicit.

## Scientific-integrity changes

Both knowledgebase entry points now share reference-only association semantics.
`register_into_engine()` is a compatibility no-op. Disease associations carry
unknown allele frequencies and empty causal-effect dictionaries. No fuzzy search
hit or disease category creates a `G.define` entry.

Legacy demonstration factories skip unknown allele frequencies. The human builder
does not force carrier genotypes from a disease annotation or apply a generic
category effect. Its pre-existing named phenotype presets are still explicitly
synthetic demonstrations and unqualified. PRS calculations skip unknown source
frequencies and require complete genotype coverage; missing variants are not
silently treated as reference alleles.

Inherited bundled seed annotations remain tagged `inherited_seed_requires_review`.
Their presence in the old repository does not establish a current commercial
entitlement or complete acquisition provenance. Reconcile those assets before
redistribution or pharmaceutical reuse.

## Regression evidence

`test_licensed_reference_sources.py` covers corrupted hashes, permission denial,
expiry, duplicate records, unsupported schemas, unknown sources, invalid IDs,
owner-only local files, exact disease lookup, academic-host refusal, credential
scoping, and reference/physiology separation. Fixtures are invented `TEST RECORD`
entries and explicitly provide no vendor data or scientific evidence.
