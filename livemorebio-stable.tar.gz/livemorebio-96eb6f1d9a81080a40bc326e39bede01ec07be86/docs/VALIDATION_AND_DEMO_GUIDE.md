# Evidence-grounded twins and Cendos protocol validation

Historical August 31 report. Superseded for current behavior by
[Research validation operations](RESEARCH_VALIDATION_GUIDE.md),
[the September 5 recordings](demo/research-validation/RECORDING_GUIDE.md) and
[the readiness review](PHARMA_READINESS_AND_ROADMAP.md). Preserve the old artifacts for
traceability; their numbers are not September benchmarks and their short videos are
not the requested detailed demonstrations. Unsupported gene/condition and generic
compound effect mappings have since been removed.

**Release candidate:** 2026-08-31  
**Branch:** `codex/interface-twin-onboarding`  
**Scope:** local research infrastructure; no production PHI, clinical decision, dosing, or
regulator-facing claim use

## What was built

This release connects one governed lifecycle across Aegle, the LIFE Patch contract, Cendos,
Biology, the terminal, and Jupyter exports:

```text
consented person data OR governed population manifest
                         |
                         v
               versioned digital twin
                         |
             frozen heterogeneous cohort
                         |
                         v
            bounded Cendos protocol run
                         |
          +--------------+---------------+
          |              |               |
       Biology          CSV           Jupyter
          |                              |
          +------ physical counterpart --+
                         |
                    evidence review
```

The Atlas Whole-body surface is now a live systems silhouette driven only by the Aegle workspace
contract. It does not initialize or reuse the Biology organ-mesh explorer. Biology remains the
organ, cell, pathway, and molecular drill-down for one active twin and an explicitly selected
`run_id`.

## Twin source contracts

### Real-human admission

A `REAL_HUMAN` record requires explicit consent/purpose, chain of custody, and field-level source
records for the data that are actually admitted. Supported domains include demographics,
conditions/history, medications, laboratory observations, physiology from LIFE Patch or another
wearable, genomics, lifestyle, and region-level environment. A declared source without matching
data does not count toward coverage. Exact GPS/street fields and raw clinical narrative are not
admitted to the browser projection.

The profile becomes `ADMITTED_COMPLETE` only when all eight core domains are backed by both source
metadata and actual data. A missing value remains missing unless a field explicitly records a
reference initialization; the system never silently pretends that a population prior was measured
from the person.

### Non-person research twins

OpenMed is not a patient or population dataset. It is an optional local de-identification and
clinical entity-intake processor.

`REFERENCE_GROUNDED_SYNTHETIC` profiles are generated server-side from the immutable
`livemore-public-metabolic-reference-v1` manifest. The manifest pins:

- CDC/NCHS NHANES August 2021–August 2023 public release metadata;
- DPP baseline publication PMID 11092283;
- per-field population anchors versus separately labeled model priors;
- deterministic sampling and the statement that no participant row is copied or persisted.

The governed strata are:

- `dpp-high-risk-metabolic`;
- `nhanes-diagnosed-diabetes-older`;
- `pxr-reference`.

Each member has a stable identity, age, sex, condition context, SLC22A1 state, metabolic model
parameters, a source-lineage record, and within-stratum heterogeneity. Repeating the same
source/stratum/seed produces the same members. Caller-provided source metadata or biology cannot
override the server manifest.

## Demonstration A — metformin across two individualized cohorts

**Video:** [livemorebio-metformin-two-cohorts-demo.mp4](demo/livemorebio-metformin-two-cohorts-demo.mp4)  
**Duration:** 52.9 seconds  
**SHA-256:** `afdfc12e34f60cb5ad565764168e3ecc3f974b78af5494b6e8762661ff4672f9`

The native browser recording shows:

1. frozen heterogeneous cohorts in `/cohorts`;
2. Cendos eligibility filtering and a 1,000 mg metformin / 75 g OGTT protocol run;
3. individualized rows with baseline glucose, SLC22A1/OCT1 transport, renal factor, modeled
   exposure, glucose deltas, and decisions;
4. run-scoped Biology projection and liver→hepatocyte drill-down;
5. the `MODELED_MECHANISTIC · NOT_QUALIFIED` boundary and required counterpart.

The final QA run was `protocol-ddf7e59678d540c89a3b6d43662e690c`:

| Frozen cohort | n | Mean modeled Δglucose | Within-cohort range | Mean OCT1 transport | EFFECT count |
|---|---:|---:|---:|---:|---:|
| QA NHANES older diagnosed-diabetes cohort | 12 | −12.77 mg/dL | −16.2 to −6.3 | 0.933 | 10 |
| QA DPP high-risk cohort | 12 | −8.47 mg/dL | −13.7 to −5.6 | 0.800 | 6 |

The different values arise from each member's admitted/reference-initialized parameters and the
same deterministic PK→PD→OGTT equations, not a random post-hoc response multiplier. This proves
software individualization and reproducible model execution. It does **not** prove that a real
person would experience those glucose changes. Qualification requires exposure, OGTT, and
biomarker measurements under an approved counterpart protocol.

## Demonstration B — purified garcinoic acid and human PXR

**Video:** [livemorebio-garcinoic-acid-pxr-demo.mp4](demo/livemorebio-garcinoic-acid-pxr-demo.mp4)  
**Duration:** 32.5 seconds; the native capture was slowed 1.5× for legibility, without adding or
removing interactions or results.  
**SHA-256:** `cafb063639f3c59892c9967684cfa60e7fa11b4582b27c0b35fa633e5e059189`

The protocol is deliberately narrower than a whole-plant efficacy claim. It represents purified
garcinoic acid, human PXR/NR1I2, a measured 6P2B co-crystal context, Kd 0.33 µM, EC50 1.3 µM, and
member-specific NR1I2-expression priors. It does not represent bitter-kola seed exposure,
bioavailability, systemic pharmacokinetics, clinical efficacy, or safety.

The final QA run was `protocol-d02addee58fe44d99e4e4a7fa3dd9c06`:

| Free concentration | Mean receptor occupancy | Mean relative PXR activation | Individual range |
|---:|---:|---:|---:|
| 0.05 µM | 0.1316 | 0.0385 | 0.0301–0.0472 |
| 0.33 µM | 0.5000 | 0.2106 | 0.1648–0.2581 |
| 1.30 µM | 0.7975 | 0.5200 | 0.4070–0.6375 |
| 5.00 µM | 0.9381 | 0.8254 | 0.6460–1.0119 |

The structure record contains 18 heavy-atom contacts within 4.0 Å, including His407
NE2–O10 at 2.43 Å and Ser247 OG–O09 at 2.661 Å. The output state is
`STRUCTURE_AND_IN_VITRO_BACKED_MODEL · NOT_QUALIFIED`. CYP3A4 fold induction remains
`NOT_QUANTIFIED` because no qualified free-exposure-to-human-hepatic-induction model or human PK
was admitted.

## Attached input integrity

The uploaded dossiers and structure were treated as evidence inputs, not instructions. Their
release hashes are:

| Input | SHA-256 |
|---|---|
| `bitter_kola_dossier.html` | `8c9221c3801ff2c8aac79161fd076f835fe51eaca57788ee5c81ef95735acb76` |
| `drug_development_dossier.html` | `adcd27b705ee7dab7a349b0d190f46a16cd7afae252d07c5996c2b86c6409253` |
| `GA_PXR_cocrystal_6P2B.pdb` | `a9e427e38d6fcd2d6473b5cdfde2ee100ec2796d9e737b1559a9a0501a7ddff6` |

The protocol pins the supported compound/target/structure/binding facts in tests. It does not
infer an unsupported downstream treatment claim from a dossier.

## Verification evidence

Automated release gate on Python 3.11:

```text
333 passed, 15 skipped, 3 warnings, 44 subtests passed in 88.87s
```

The skips are explicitly environment/network-gated. The warnings are FastAPI/Starlette lifecycle
deprecations, not test failures. Focused lifecycle, reference-cohort, protocol, run-store,
cross-product Patch binding, and Biology projection tests also passed after the last fixes.

Real-browser QA covered `/`, `/twins`, `/cohorts`, `/cendos`, both run-scoped `/biology` views,
`/patch`, `/adapters`, `/legacy`, and `/docs`. It created a non-PHI real-human fixture with eight
source-backed domains, verified one authoritative active twin, bound and sampled its virtual
Patch, created all three cohorts, ran both protocols, opened analysis and Biology controls,
drilled into liver/hepatocyte, probed adapters, and expanded OpenAPI. The browser reported no page
or console errors. The same core Atlas and Cendos workflows were visually checked at 390×844.

Screenshots and the full action log are in `.gstack/qa-reports/`.

## Run it yourself

```bash
livemore start all
livemore status
livemore open
```

Open <http://127.0.0.1:8850/cohorts>, create the three governed cohorts, then open
<http://127.0.0.1:8850/cendos>. Run the applicable protocol, inspect the frozen result, export CSV
or Jupyter, and open Biology from the result so the URL contains its exact `run_id`.

Terminal parity:

```text
livemore attach
cohort list
protocol metformin cohort_a=cohort-... cohort_b=cohort-... dose=1000 grams=75
protocol garcinoic cohort=cohort-... concentrations=0.05,0.33,1.3,5.0
protocol latest
```

The browser authorizes itself on loopback with an HttpOnly cookie. `livemore token` is only for an
explicit API client such as `curl`; it is not a browser setup step.

## What the release validates—and what it does not

Validated as software:

- source/coverage enforcement, encrypted twin/cohort persistence, single active identity;
- deterministic heterogeneous cohort materialization and reproducibility;
- individualized metformin and PXR calculations within their declared contracts;
- run-scoped persistence, CSV/notebook export, Biology visualization, and evidence labels;
- virtual Patch subject/device binding and observed-versus-modeled separation;
- desktop/mobile interaction, API authorization, and no-PHI fixtures.

Not yet validated physically or clinically:

- a complete living-human replica or all-organ functional equivalence;
- per-person calibration, prospective clinical performance, efficacy, safety, or dosing;
- LIFE Patch Rev B fabrication, firmware conformance, or analytical equivalence;
- physical Cendos assays, organoids, instruments, or qualified counterpart measurements;
- garcinoic-acid human PK, CYP3A4 induction magnitude, efficacy, or safety.

## Next physical build program

### LIFE Patch

1. Freeze the corrected Rev B schematic, BOM, PCB, firmware contract, BLE framing, provisioning,
   calibration, safe-command, and release manifests.
2. Complete bench, EMC, biocompatibility, adhesive, cybersecurity, human-factors, and per-channel
   analytical verification.
3. Collect paired physical/virtual packets and quantify timing, quality, missingness, drift, and
   state-estimation residual tolerances before any calibration claim.

### Physical Cendos Lab

1. Implement LIMS identities for sample, aliquot, plate, protocol, instrument, operator,
   calibration, raw file, result, and deviation.
2. Execute metformin comparator assays with frozen exposure/OGTT endpoints.
3. Execute purified-garcinoic-acid identity, concentration, PXR reporter, CYP3A4, and exposure
   assays; do not substitute seed/extract claims.
4. Admit immutable QC-passing measurements against the exact frozen software run and let the
   evidence service assess equivalence within a declared population, intervention, dose, endpoint,
   and tolerance.

### Biological depth

Deepen hepatic, renal, endocrine, and autonomic coupling next, then respiratory, immune,
gastrointestinal, neurological, musculoskeletal, reproductive, integumentary, and lymphatic
systems. Each addition must include units, timescale, identifiers, perturbations, observation
mapping, uncertainty, applicability, and physical validation tests before its maturity advances.
