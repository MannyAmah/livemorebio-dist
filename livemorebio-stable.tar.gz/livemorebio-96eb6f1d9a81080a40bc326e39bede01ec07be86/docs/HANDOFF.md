# LivemoreBio — Complete Project Handoff & State Document

## September 10, 2026 — superseding historical handoff

Read the [complete product, implementation and experiment handoff](handoff/2026-09-10/LIVEMORE_BIO_COMPLETE_HANDOFF.md)
and its source inventory and publication receipt before using this older document.
The founder's objective remains a complete, individualized biological human
replica, dedicated physical **and** virtual LIFE Patch hardware/software, and a
real physical Cendos wet lab working together. That objective has not been
achieved by the current software. The older integration-layer-only LIFE wording
below does not define the current device scope. Original claims, counts and
commands below are preserved history, not current readiness or authorization.

## Additive correction candidate, September 8, 2026

`codex/measurement-integrity-atlas` starts from preserved release `5c71ee8` without
replacing its installation or data. Read the
[measurement integrity review guide](MEASUREMENT_INTEGRITY_REVIEW_GUIDE.md) and
[approved correction plan](solutions/2026-09-08-measurement-integrity-atlas-build-plan.md)
for current local operation, v3/v2 compatibility, explicit sampling, frozen
alignment, run-bound Biology and the nonhuman lobeline initial-rate assay.
Physical transfer mappings, device equivalence and human validation are not supplied.
Final tests, browser/video evidence and publication remain pending until recorded.
All earlier commands and claims below retain their original historical scope.

## Current additive candidate, September 5, 2026

Use `codex/genome-models-clean-workflows`, extending preserved research commit
`19c1edaa2b15cc414d148e9fde49919b3653ab3f`; do not replace the prior installation.
The approved plan and actual verification are in
[the build plan](solutions/2026-09-05-genome-models-clean-workflows-plan.md),
[external tester guide](EXTERNAL_TESTER_GUIDE.md),
[candidate evidence](GENOME_MODEL_REVIEW_EVIDENCE.md), and
[multiscale/physical-program roadmap](MULTISCALE_DEVELOPMENT_ROADMAP.md).

Human-GEM 2.0.0 now executes through the isolated `engines/stoichiometry.py`
service and Cendos `human-gem-oxygen-capacity` protocol. Eight official assets,
including attribution and annotations, are pinned and checksum-verified by
`model_assets.py`. The model is not coupled to a patient's organs by invented
gene/flux multipliers. Recon3D remains restricted, not operational: the reviewed
source embeds commercial-use restrictions. See [source review](HUMAN_GEM_MODEL_SOURCES.md).

Fresh stores contain no admitted twins, cohorts or runs; the initial healthy view
is an unadmitted reference preview. Saved active identity remains authoritative.
Cendos opens blank Preparation, with searchable/paged History and read-only
recall/prepare before explicit, lineage-bound execution. Twin/cohort lists are
paged and locally searched, and research strata begin explicitly unselected.

Biology data no longer depend on graphics loading. Organ parameters, unavailable
functions and actual recorded electrophysiology are distinguished; proxy cell
activity percentages and unmodeled contraction/transport animations are removed.
Active Biology reads require operator authorization. Cell trace/view coherence
uses an opaque context token, not a clinical or scientific validation claim.
Time playback means recorded model time, not wall-clock aging or live patient time.
Human-GEM conditions are steady-state comparisons and have no time animation.

Published clean installation passed 807 tests/44 subtests with no skips; same-commit
reinstallation passed both native model tests and preserved the complete release
digest. Final macOS/Ubuntu CI passed 809 tests/44 subtests per platform (one explicit
network-only skip; real assets and native calculations were checked separately).
The installed three-service review instance was verified on 8880–8882. It started
with zero records; its two later QA runs were explicitly created by SDK/terminal
tests, not installed seed data. See the evidence report for exact commits, earlier
failures and retained limitations. Do not point a separate evaluation at default
ports/stores; use the guide's isolated installed-runner instructions.

The historical implementation descriptions below are retained for traceability,
**not current authorization to restore disabled biology, build Rev A hardware,
bypass Git hooks, install into system Python, or treat prior modeled trials as
physical validation**. The current guide supersedes their runbook and test counts.

---

September 5 handoff: this document preserves the prior release history. Current changes,
operation, evidence gaps and development gates are in
[Research validation operations](RESEARCH_VALIDATION_GUIDE.md),
[Biological model change contract](BIOLOGICAL_MODEL_CHANGE_CONTRACT.md), and
[Pharmaceutical readiness and roadmap](PHARMA_READINESS_AND_ROADMAP.md).
Do not reintroduce generic compound effects, gene/diagnosis multipliers or automatically
approved evidence reviewers from historical descriptions below. The full metabolic
profile now crosses Aegle→bus→Cendos without dropped fields; old partial snapshots fail.

**Repo:** `github.com/MannyAmah/livemorebio` (private) · **Canonical source:** `livemore-ecosystem/` or the active feature worktree
**Owner:** Emmanuel Amah — clinician-founder, Livemore Health & Biosciences (livemoreai.com)
**Last updated:** 2026-08-31 · evidence-grounded twin/cohort admission, two governed Cendos protocols, run-scoped Biology, and final browser QA
**Audience:** any engineer or AI agent continuing this work. Read this whole file before touching code.

---

## 1 · What this product is

**LivemoreBio** is a biology-first, mechanistically interpretable **in-silico human digital-twin
platform for pharmaceutical drug development**. Its core mandate: *every outcome emerges from each
individual's biology* (genome, conditions, lifestyle, diet, environment, history). Person A ≠
Person B ≠ Person C — by construction, not by post-hoc noise.

The correct current external framing is: **evidence-governed, context-declared mechanistic
simulation for pharmaceutical hypothesis triage**. The architecture is being built toward a
biological functional human-body replica; the current release is not a complete living-human
replica, a calibrated per-person prediction, or a clinical decision system.

### The founding vision (Aegle HHDT Ecosystem, blueprint v0.1)
Three organs in one body of work, a closed loop (see project file `aegle-hhdt-ecosystem.html`):

| Pillar | Name meaning | Role |
|---|---|---|
| **Aegle HHDT** | Greek goddess of good health; Human Health Digital Twin | The computational center. Multi-scale twin (cellular→organ→system). In-silico experiments run, are calculated, and exported here for clinical handoff. |
| **LIFE Patch** | Living Integrated Functional Equipment | NOT a new app — an **integration layer / SDK** drawing continuous physiological signal (HR, HRV, SpO₂, glucose, temp, motion, sleep) from devices people already use (HealthKit/Google Fit/Fitbit/Oura + gen-2 dedicated patch hardware), FHIR-normalized at the edge, piped to the twin. |
| **Cendos** | Latin *cendere*, to kindle/grow | The wet-lab counterpart: physical iPSC organoids mirroring the digital ones. Qualified wet readouts enter as immutable counterpart measurements; only a governed evidence decision may later authorize calibration or validation. |

Design principles from the blueprint: **closed-loop or nothing** (twin without wet feedback drifts;
wet lab without twin is just slow); **hypothesis-as-code** (every experiment is a versioned,
reproducible artifact); **don't build another app** (infrastructure/SDK); **privacy structural**;
**the patient is the source of truth**.

### Scientific thesis
Chronic disease is treated as a failure of regenerative **signaling** (not regenerative capacity) —
ecosystem collapse across microbiome–immune–metabolic axes — addressable via mechanistic digital
twins and **multi-compound plant formulations** (African ethnobotany, e.g. bitter kola/berberine,
is a structural blind spot of single-molecule pharma). Cendos' longer arc: phytochemical
standardization → computational screening → multi-organ organoid validation → botanical drug
regulatory pathway.

### Customers & positioning
Primary customers: **pharmaceutical companies** (candidate triage, dose ranging, responder
stratification, trial-design support). Competitors: Twin Health, Unlearn.AI, Aitia, Dassault
Biomedia. **Differentiator: mechanistic interpretability + regulator-favorability** — every number
traces to a named physiological model; deterministic, signed, reproducible pipelines. This moat is
never to be compromised for convenience.

---

## 2 · Non-negotiable engineering principles (violating these fails review)

1. **No fakes, ever.** No hardcoded outcomes, no placeholder values presented as biology, no
   animation artifacts pretending to be physiology. Every moving/changing thing on screen is a
   *readout of a real mechanistic computation*. (Historical example: HR was a flat 60 bpm
   placeholder for every patient — treated as a serious defect and replaced with a real
   autonomic/metabolic HR engine, commit `ede43e9`.)
2. **Honest flagging.** Anything not yet modeled or not yet physical is visibly labeled
   `pending` / `nominal` / `hardware pending` / `model-only`. The Cendos wet lab and the physical
   patch are capital/hiring programs — their data panels stay EMPTY until real. No fabricated
   organoid or sensor data, ever.
3. **Framing discipline.** Hypothesis triage, not per-person numeric prediction (see §1).
4. **Generic infrastructure over pre-built catalogues.** Live database resolution (ChEMBL, Open
   Targets, PubChem) over hand-enumerated drug lists; extensible systems over fixed enumerations.
5. **Measured state and modeled state remain separate.** A real feed (for example CGM or
   measured HR) updates the observed-state overlay and provenance. It never silently rewrites
   model parameters or self-calibrates a live twin. A governed reconciliation event is required
   before a released calibration can change model state.
6. **Determinism & signing for anything pharma-facing.** Seeded cohorts, pure-function
   interventions, timestamp-independent result fingerprints, HMAC signatures (see §10).
7. **Owner's workflow:** confirm before each phase; build and verify exactly as specified; never
   silently substitute an approach at a roadblock — ask. Rate-able outputs; hard critique welcome.

---

## 3 · Architecture

Three independent FastAPI services + shared infrastructure, all local (single-box) today:

```
LIFE   :8851  livemorebio.life_system.service   — population, references, LIFE Patch admission
Aegle  :8850  livemorebio.aegle.server          — twin runtime, observed overlay, ALL web pages
Cendos :8852  livemorebio.cendos.service        — in-silico assays + qualified counterpart intake

Shared:
  registry.py       ~/.livemore/registry.json       — service discovery (url_of("Cendos") etc.)
  bus.py            ~/.livemore/events.jsonl        — encrypted cross-system pub/sub, trimmed 500
                    ~/.livemore/snapshots/          — encrypted state snapshots
  audit.py          ~/.livemore/pipeline-audit.jsonl + livemore-sign-hmac.key — signed records
  security.py       ~/.livemore/api-token           — operator auth for mutations + PHI-like reads
                    ~/.livemore/patch-storage.key   — AES-256-GCM local-state encryption
                    ~/.livemore/patch-admission.key — LIFE admission + manifest attestation HMAC
  screen_runs.py    ~/.livemore/screen-runs/          — durable, run-scoped screen artifacts
  aegle/rcache.py   ~/.livemore/resolve_cache/      — persistent ChEMBL/OpenTargets resolution cache
  aegle/subjects.py ~/.livemore/subjects.sqlite3    — AES-GCM twin/cohort payloads;
                                                      opaque subject/device uniqueness indexes;
                                                      authoritative active-twin pointer
  aegle/population.py                                — pinned population manifest, strata, and
                                                      deterministic heterogeneous member generation
  cendos/protocol_runs.py ~/.livemore/cendos-protocol-runs/
                                                     — durable run-scoped protocol results + exports
```

**Data flow:** virtual or attested physical patch → LIFE contract admission + encrypted durable
journal → signed LIFE admission → Aegle observed-state overlay; Cendos reads only the exact
subject/envelope-hash counterpart. Separately, any modeled twin mutation in Aegle →
`_snapshot_twin()` publishes state + baseline profile params to the encrypted bus → Cendos
`/assay/current` reconstructs and assays that modeled twin → publishes `assay.run` back. Patch
observations never enter `profile_params` directly.

The browser uses a loopback-only same-origin bootstrap to receive an HttpOnly,
SameSite=Strict operator cookie. It does not ask users to copy a token or place the token in
`sessionStorage`. Terminal/SDK attach mode reads the owner-only launcher token file. Aegle
restores the authoritative twin identity from the encrypted registry on startup and fails
closed if restoration cannot be completed. Runtime perturbation state is still session-scoped;
restart reconstructs the admitted baseline rather than replaying prior drug/meal actions.

Twin source truth is deliberately split. A `REAL_HUMAN` record contains only admitted,
provenance-bearing person data; declared source domains without corresponding data do not satisfy
coverage. A `REFERENCE_GROUNDED_SYNTHETIC` record is a non-person research profile generated on the
server from `livemore-public-metabolic-reference-v1`, a named stratum, and a seed. OpenMed may
de-identify and extract local clinical intake, but is not a patient or population dataset. Exactly
one registry twin may be `ACTIVE`; activating a replacement demotes the previous record.

The complete current operating contract, API examples, licensing gates, and physical-equivalence
artifact list are in [`LIFE_PATCH_CLOSED_LOOP.md`](LIFE_PATCH_CLOSED_LOOP.md).

**SDK execution modes** (`livemorebio/sdk.py`): `inprocess` (default — engines run directly in the
caller's process; deterministic, isolated; the substrate for signed pipelines) vs `attach` (drives
the live services over HTTP; terminal + browser share one session). Identical method surface.

**Stale artifacts warning:** `~/.livemore/audit.jsonl`, `audit-hmac.key`,
`evidence-signing-ed25519.key`, `evidence.db.audit.key` are leftovers from a superseded
architecture (RBAC/tenant endpoints that no longer exist). The live audit system is
`livemorebio/audit.py` → `pipeline-audit.jsonl` + `livemore-sign-hmac.key` only.

---

## 4 · Complete repository map (line counts for the files touched by the whole-human foundation)

```
livemorebio/                          root package (pyproject.toml, requirements.txt, README.md, LICENSE)
├── foundation.py              285   all 15 ontology systems + independent maturity claims;
│                                    LIFE/Aegle/Cendos + physical/virtual patch/workbench contracts
├── cli.py                     157   `livemore` entrypoint: infra control + manifest/shell/attach/run
├── sdk.py                     185   Platform(mode) — patient/cohort/perturb/assay/state/manifest/screen
├── shell.py                   195   interactive REPL + pipeline runner + command dispatch
├── audit.py                   105   HMAC-SHA256 signed records; result_fingerprint (ts-independent)
├── report.py                   53   signed markdown screen-report renderer (+ .audit.json)
├── bus.py                      89   file-backed pub/sub + snapshots (publish/events/set_snapshot)
├── registry.py                 36   service registry (~/.livemore/registry.json)
├── aegle/
│   ├── runtime.py             218   AegleTwin: profile+human+meals; _recompute() = metabolic sim +
│   │                                individualized resting HR/HRV/hr_series + O'Hara–Rudy pacing;
│   │                                stimulate(kind,...); ingest_patch (measured HR overrides); state()
│   ├── server.py              679   ALL web routes + APIs (see §5); serves console/ pages; bus publish
│   ├── rcache.py               64   disk cache for successful compound resolutions (atomic writes)
│   ├── profile_sources.py           bounded provenance contract for person-data domains
│   ├── population.py                pinned population manifest + governed research strata
│   ├── subjects.py                  encrypted twin/cohort lifecycle and Patch bindings
│   └── console/
│       ├── index.html         611   main console (3-col): body/organs · myocyte+builder · patient/patch
│       ├── patch.html         159   LIFE Patch streaming biomarker dashboard
│       ├── cendos.html        167   Cendos assay console (+ honest reconciliation panel)
│       └── biology.html       333   Living Biology 3D (Three.js + HRA GLB organs + Mol* molecules)
├── cendos/
│   ├── assays.py               23   ogtt_effect(base,treated,grams) → Δmean/Δpeak/ΔiAUC/decision
│   ├── protocols.py                 individualized metformin and garcinoic-acid/PXR protocols
│   ├── protocol_runs.py             run-scoped persistence plus CSV/Jupyter exports
│   └── service.py              93   /health /assay/ogtt /compound(PubChem) /assay/current(bus twin)
├── life_system/
│   ├── synthetic_human.py      66   SyntheticHuman(id,age,sex,conditions,genome,lifestyle)
│   │                                → metabolic_profile(kb): real params from biology
│   ├── population.py           52   LifeSystem.generate(n,seed) — reproducible cohorts
│   ├── genome.py               48   12 curated mechanistic variants (TCF7L2, APOE4, PPARG_loss,
│   │                                SLC22A1_lof/OCT1…) + GWAS loci registration (~172 total)
│   ├── knowledge.py           142   KnowledgeBase from seed/*.json (20 diseases, genes, drugs…)
│   ├── extract.py             100   ClinicalExtractor — regex NER on substrate vocab (no ML needed;
│   │                                OpenMed NER optional, torch NOT installed) → SyntheticHuman
│   ├── graph.py               121   Neo4j knowledge graph adapter
│   ├── retrieval.py            95   search index (TuringDB-ready)
│   ├── service.py              65   LIFE service (population/human/graph/search)
│   └── seed/                        anatomy, diseases, drugs, genes, gwas, meta, pathways,
│                                    structures (.json) — the substrate vocabulary
├── life_patch/
│   ├── stream.py               74   feeds: synthetic day / real CGM (diabetic|healthy) → packets
│   ├── packet.py               50   packet schema (hardware_present honesty flag)
│   ├── sensors.py              60   sensor channel definitions
│   └── driver.py               32   hr_to_cl_ms() and packet→twin drive
├── engines/
│   ├── metabolic/glucose_insulin.py 110  Bergman glucose–insulin ODE; HEALTHY/T2D profiles;
│   │                                MetabolicProfile(name,weight,Gb,Ib,Si,gamma,Gt,SG)
│   ├── metabolic/interventions.py   25   metformin(profile,dose), plant_compound(si/gb/gamma)
│   ├── cardiac/action_potential.py  72   O'Hara–Rudy CiPA 2017 myocyte (49-state), ikr_block, cl_ms
│   ├── cardiac/heart_rate.py        87   resting_heart_rate / hr_series / hrv_rmssd (autonomic+
│   │                                metabolic: fitness/vagal, IR/glycemia→sympathetic, conditions)
│   ├── coupling/gem_metabolic.py    95   gem_drug_effect: {gene:scale}→Recon3D flux at operating
│   │                                point → ΔGb/ΔSi + mechanism why; personalize_profile; food_effect
│   ├── coupling/metabolic_cardiac.py 32  hyperglycemia_to_ikr_block
│   ├── metabolism.py               298   Recon3D load/FBA, _find_gene, operating point, pathways
│   ├── genome_scale.py             164   Human-GEM handling + EGC (energy-generating-cycle) QC
│   ├── drug_targets.py             115   ChEMBL: resolve_drug (curated MoA) / resolve_bioactive
│   │                                (measured IC50/Ki/EC50) — lru_cached, 12s timeout
│   ├── disease_links.py             80   Open Targets GraphQL: target→disease signatures
│   ├── foods.py                    100   foods = macros (USDA) + phytochemical target signatures
│   ├── factors.py                   82   stress/lifestyle/environmental factors (e.g. BPA)
│   ├── pharmacology.py              73   PK individualization (OCT1 genotype gating etc.)
│   ├── trajectory.py               132   disease emergence over time (T2D natural history)
│   ├── validation.py                86   DPP retrospective validation harness (#4)
│   ├── biology.py                  151   per-organ state derivation (activity + quantities from
│   │                                Si/Gb/γ) + cellular scale — feeds /api/biology
│   └── _cellml.py                   91   CellML/SBML helpers (libRoadRunner/Myokit)
├── tests/                              348 collected; 333 pass + 15 environment/network-gated skips
│                                    in the current release gate, plus 44 subtests;
│                                    includes whole-human contract and installed-wheel checks
models/                                Recon3D.xml (~28MB, gitignored), Human-GEM.xml + genes.tsv, cardiac/
docs/hardware/                         LIFE Patch gen-2 EDA schematics: MAX30003 ECG, MAX86141 PPG,
                                       AD5940+LMP91000 chemistry, BMI270/BMM150 IMU, BQ25120A power,
                                       nRF52840 MCU (legacy Rev A.1 design docs only — hardware NOT
                                       built; reconcile later engineering corrections before use)
trials/                                first full-system trial evidence package (§11)
```

---

## 5 · Complete API reference

### Aegle :8850 (`aegle/server.py`)
| Route | Purpose |
|---|---|
| `GET /` `/twins` `/cohorts` `/patch` `/cendos` `/biology` `/adapters` | serve the governed A+B workspace and preserved product pages (no-store) |
| `GET /api/session/bootstrap` | loopback/same-origin-only HttpOnly browser session bootstrap |
| `GET/POST /api/twins` | list or admit encrypted, pseudonymous twin records; mutations are idempotent |
| `GET /api/twins/{id}` `POST /api/twins/{id}/activate` | read/version-activate one twin; active identity persists across restarts |
| `POST /api/twins/{id}/patches` | bind virtual/replay devices or record safeguarded physical pairing metadata |
| `GET/POST /api/cohorts` | list or freeze materialized reference-grounded/real-human cohort definitions |
| `POST /api/cendos/protocols/metformin-cohorts` | execute two eligible heterogeneous cohorts through individualized metformin PK→PD→OGTT |
| `POST /api/cendos/protocols/garcinoic-pxr` | execute 6P2B/Kd/EC50-pinned PXR engagement for an eligible cohort |
| `GET /api/cendos/protocols/{run_id}` | retrieve one immutable protocol run; Biology never relies on global latest |
| `GET /api/cendos/protocols/{run_id}/analysis.csv` | export individualized analysis rows |
| `GET /api/cendos/protocols/{run_id}/analysis.ipynb` | export a bounded Jupyter analysis notebook |
| `GET /api/workspace` `GET /api/workspace/stream` | authenticated A+B projection and one-second SSE updates |
| `POST /api/workspace/actions` | visible queued→running→completed multiscale perturbation lifecycle |
| `GET /health` | service health + twin profile |
| `GET /api/state` | authenticated full twin state with separate modeled and observed patch state |
| `GET /api/system-manifest` | read-only whole-human architecture coverage, per-system maturity, LIFE/Aegle/Cendos contract, patch/workbench status, and governed reference-adapter status |
| `POST /api/stimulate` | kinds: `base`, `patch` (feed modes synthetic/cgm_diabetic/cgm_healthy), `life_system` (modes random/t2d_apoe4/carrier/**custom**{id,age,sex,conditions,genome,lifestyle}), `meal{grams,minute}`, `metabolic_drug`, `gem_drug{name,dose}`, `food{name,grams}`, `factor{name,intensity}`, `cardiac_drug{ikr_block}`, `lifestyle{si_delta,gb_delta}`, `reset` — every mutation publishes to the bus via `_pub` |
| `POST /api/ingest_note` | free-text clinical note → ClinicalExtractor → grounded twin; returns state + `extracted` |
| `GET /api/resolve?compound=&refresh=` | ChEMBL curated-MoA → bioactivity fallback; Recon3D membership per target; Open Targets disease signature; served from rcache when cached (`cached:true`); `refresh=true` forces live |
| `POST /api/experiment` `{compound,dose}` | resolve → {gene:scale} → `gem_drug_effect` through the person's Recon3D at their operating point → re-simulate; returns state + versioned `experiment` spec |
| `GET /api/vocab` | substrate vocabulary: 20 conditions, 172 variants + variant_meta (axes, diseases) |
| `POST /api/patch/virtual` `GET /api/patch` | generate admitted virtual v2 telemetry through LIFE; authenticated patch frame keeps observations separate from modeled traces |
| `GET /api/biology` | per-organ computed model state (7 organs: activity + quantities) — drives Biology 3D |
| `GET /api/structure` | molecular structure metadata (RCSB) for the Mol* viewer |
| `POST /api/trajectory` | disease-emergence simulation |
| `POST /api/validate` | DPP retrospective validation run |
| `GET /api/search` `GET /api/graph` `GET /api/services` | retrieval index, knowledge-graph stats, registry |
| `GET /api/events?after=ts` | authenticated poll of the encrypted cross-system bus |
| `POST /api/cendos/assay` `GET /api/cendos/compound` | same-origin proxies → Cendos (Aegle→Cendos cross-system) |
| `POST /api/screen` | isolated T2D-enriched/OGTT cohort screen; metformin PK, pinned ChEMBL, or explicit parametric research path; returns a unique `run_id` |
| `GET /api/screen/{run_id}/report.md` `GET /api/screen/{run_id}/report.audit.json` | run-scoped local reproducibility artifacts; the legacy global download routes return `410` |
| `GET /api/adapters` `POST /api/adapters/probe` | governed adapter registry plus authenticated, bounded health probes; registry reads never trigger outbound egress |
| `GET/POST /api/evidence...` | create/read governed model-only evidence packages; export is authenticated `POST` because it locks lifecycle state |

### Cendos :8852 (`cendos/service.py`)
`GET /health` · `POST /assay/ogtt` (explicit base vs treated) · `POST /assay/current` (**reads the
modeled live twin off the bus snapshot**, reconstructs its MetabolicProfile, applies metformin or
plant_compound, runs the executable OGTT model, publishes `assay.run`) · `GET /compound?name=` (PubChem) ·
`POST /evidence/lab-results` (pseudonymized, qualified counterpart intake) · authenticated
`GET /patch/latest?subject_id=&envelope_hash=` (exact counterpart binding, never global latest).

### LIFE :8851 (`life_system/service.py`)
`GET /health` · `GET /population` · `POST /human` · `GET /graph` · `GET /search` · authenticated
`GET /reference/genes/{symbol}` (licensed KEGG/GeneCards reference context) ·
`POST/GET /patch/devices` · `POST/GET /patch/telemetry` · `POST /patch/virtual/sample` ·
`POST/GET /patch/commands` · `POST /patch/commands/receipts`.

---

## 6 · Interfaces (what each page does)

- **`/` — merged A+B multiscale Atlas.** Approved top tabs and product rail; a living systems
  silhouette that is visually and technically distinct from the Biology organ meshes; Whole Body
  → Cardiovascular → Heart → Ventricular
  Tissue → Cardiomyocyte → IKr → SLC22A1/OCT1 scale path; biological time; intervention controls;
  queued/running/completed action state; mechanism graph; observed/modeled/reference/qualified
  evidence separation; one-second server-sent state updates. Heart beat, vascular flow, and
  metabolic intensity are driven by returned state, not decorative timing.
- **`/twins` — governed subject operations.** Encrypted reference-grounded or consented
  real-human admission, field provenance and coverage, versioned single-twin activation, virtual
  Patch binding, physical pairing safeguards, one-subject uniqueness, and persisted identity.
- **`/cohorts` — governed cohort operations.** Frozen source manifest, stratum, indication, seed,
  materialized heterogeneous profiles, lineage, and member fingerprints; real-human cohorts accept
  only explicitly listed active humans.
- **`/legacy` — preserved prior console.** Existing patient builder, experiment builder, and
  historical surfaces remain available during the A+B rollout.
- **`/patch` — LIFE Patch dashboard.** Streaming day playhead (honest time-lapse labels: 1/5/15/35
  min-per-second with real-time multiplier), live traces (glucose, insulin, HR 84–101 bpm intra-day),
  HRV live tile, skin-temp nominal, 10 channels honestly "engine pending", feed controls (virtual /
  real CGM diabetic / real CGM healthy), 6s polling picks up console perturbations. **rAF pauses in
  background tabs** — the playhead only animates when the tab is focused (expected browser behavior).
- **`/cendos` — Cendos Lab.** Preserves the single-twin assay while adding two bounded cohort
  protocols: individualized metformin PK→PD→OGTT across DPP and NHANES metabolic strata, and
  purified garcinoic-acid/PXR target engagement across a PXR reference cohort. Results are durable,
  exportable as CSV/Jupyter, and projected into Biology by run ID. The
  **in-vitro↔in-silico reconciliation panel keeps the organoid side empty** until measurements exist.
- **`/biology` — Living Biology 3D.** Real HuBMAP HRA GLB organ meshes (Three.js), tinted by the
  twin's live state, organ→molecular drill-through (Mol* 4.4.0 / RCSB), cellular scale (Phase 1),
  individualized header (Si/Gb/γ). Browsers without WebGL retain the organ/state drill-down and
  display an explicit 3D-unavailable message.
- **`/adapters` — Scientific adapters.** Operational readiness, product integration, concurrent
  bounded probes, workflow routing, capabilities, license links, credential gates, and
  commercial-source hard blocks.

---

## 7 · Governed scientific and population sources

Active governed retrieval paths: ChEMBL (curated MoA + measured bioactivity) · Open Targets GraphQL (target→disease) · PubChem
(compound identity) · Recon3D + Human-GEM (genome-scale metabolism; EGC QC guard) · USDA
FoodData Central (only when `USDA_API_KEY` is configured) · HuBMAP HRA (GLB organ meshes) · RCSB/PDBe via Mol* · UniProt ·
Reactome (pathways) · Disease Ontology / Orphanet (seed) · Neo4j (graph) · measured-input CGM demos
(patch feeds). KEGG and GeneCards are entitlement-gated connectors: they become operational only
after Livemore records the required commercial access, and GeneCards uses a configured licensed
JSON endpoint rather than scraping. Their records remain reference context and cannot validate a
wet-lab result. USDA FoodData Central is credential-gated. **ChEMBL caveat:** EBI latency intermittently exceeds the engine's 12 s timeout
(observed 20–23 s); mitigations = server-layer retry-with-cache-clear + persistent `rcache`
(resolve once → served offline forever; `refresh=true` to re-fetch). The 12 s timeout lives in the
engine and was deliberately left untouched — raising it is a candidate future change.

The first reference-person manifest is `livemore-public-metabolic-reference-v1`. It pins an
NHANES August 2021–August 2023 public release URL, the DPP publication PMID 11092283, per-field
lineage, population anchors, and separately declared model priors. It supports three explicit
strata: `dpp-high-risk-metabolic`, `nhanes-diagnosed-diabetes-older`, and `pxr-reference`.
It does not copy a public-data row or claim that a generated member is a real participant.

---

## 8 · Delivery layer (roadmap #6 — pharma product)

- **`livemore`** (bare) → interactive Livemore environment (claude-style REPL). Subcommands:
  `shell [--attach]`, `attach`, `run <pipeline> [--attach]`, `start/stop/status/open`,
  `manifest`, `workspace`, `sources`; `token` is for explicit API clients, not browser setup.
- **Shell/pipeline commands** (identical interactive & scripted): `patient <healthy|t2d>` ·
  `patient note "<text>"` · `patient age=61 sex=M lifestyle=.4 conditions=cad genome=APOE4` ·
  `twin list|admit|activate|patch` · `cohort list|create` · `cohort <n> [seed=]` ·
  `perturb <compound> [dose=]` / `perturb kind=meal grams=100` ·
  `protocol metformin cohort_a=<id> cohort_b=<id> dose=1000 grams=75` ·
  `protocol garcinoic cohort=<id> concentrations=0.05,0.33,1.3,5.0` ·
  `assay <compound>` · `screen <compound> [n= seed= dose= grams=]` · `show twin` ·
  `report [path.md]` · `pipeline <file>` · `audit verify <record.json>` · `mode` · `help/quit`.
- **SDK** (`from livemorebio.sdk import Platform`): the one surface both use. `screen()` is
  in-process only (reproducibility requires isolated state) — cohort → per-twin OGTT → rank →
  signed result.
- **Audit format** (`audit.py`): `result_sha256` = SHA-256 of canonical
  {action,inputs,outputs,provenance} — timestamp-INDEPENDENT (same science → same fingerprint);
  `hmac_sha256` = HMAC(key, {result_sha256, ts}) — tamper-evidence + timestamping; provenance
  stamps platform/python/git. `verify()` recomputes both. Key auto-generated 0600 at
  `~/.livemore/livemore-sign-hmac.key`.
- **Reports** (`report.py`): run-scoped markdown screen report (full ranking, provenance, local
  HMAC integrity, model-only framing, verification instructions) + sibling `.audit.json`. This is
  not a governed evidence-package signature.
- **Auth:** every mutation and selected PHI-like read requires the local operator credential at
  `~/.livemore/api-token` (0600). Browser access uses an HttpOnly loopback cookie; attach-mode
  clients read the file. Local subject records, patch journals, and bus snapshots use AES-256-GCM
  when the launcher-generated storage key is present. Accounts, tenant isolation, production
  authorization, production KMS, and PHI approval remain deliberately deferred.

---

## 9 · Build history (complete, commit-mapped)

### Original roadmap #1–#5 (pre-interface-rebuild)
| Commits | Work |
|---|---|
| `a4aa20e`…`c69e881` | O'Hara–Rudy myocyte, metabolic→cardiac coupling, Cendos in-silico assays; living-twin runtime + first reactive console |
| `b077d6d` `78a70d8` `c3178d9` `a579a4b` | LIFE Patch ingestion SDK + real-data drive; Synthetic Human population on real biology; knowledge graph (Neo4j) + retrieval + clinical NER; `livemore` CLI + independent LIFE/Aegle/Cendos services |
| `f23488c` `ff218b5` `25b2580` `22895e2` `474bb42` (#1) | individualized drug response; Human-GEM foundation; generalized ChEMBL drug→target→GEM (no drug hand-coded); EGC QC; calibrated Recon3D foundation (metformin 32→22 ATP) |
| `44ff2e2` `1609442` (#2) | genome-scale metabolism drives the whole-body twin; dose-scaled inhibition fix |
| `7723f28` `7f3f7ba` `c28d782` `db01103` `916b3ae` `d708d46` (#3) | foods as macros+phytochemical targets; Open Targets exposure→disease; disease trajectory; non-food factors; operating-point readout; target-matched pathway readouts |
| `a300777` (#4) | **DPP retrospective validation — the credibility keystone** |
| `3f79a0e` `9e74d47` (#5) | Living Biology reactive multi-scale 3D view; console link |

### Interface rebuild Phases 1–4 (this cycle)
| Commit | Phase | Delivered |
|---|---|---|
| `ff2cc00` | **P1** | cellular scale in /biology; heart/brain-visibility fix (normalize-after-scale centroid bug) |
| `f4a181a` | **P2** | experiment/perturbation builder (live ChEMBL+OT preview, 6 classes, versioned hypothesis log w/ replay); `GET /api/resolve` + `POST /api/experiment`; **persistent resolve cache** (`rcache.py`) with retry-on-timeout (lru_cache poisoning fix) |
| `75f4bc1` | **P3.1–2** | Quick/Build/Note patient panel + `/api/vocab`; note-ingestion fixes (black-on-black textarea, extracted-entity display, sex-shorthand extraction); **LIFE Patch streaming dashboard** `/patch` + `GET /api/patch` (honest live/nominal/pending channels) |
| `1edf769` | **P3.3** | individualized whole-body view — `paintBody()`/organ readout from `/api/biology`, engine/exposure badges, click-through, perturbation-reactive (liver 1.37→1.57× ref proven live) |
| `290924b` | **P4** | cross-system bus (`bus.py`) + twin snapshot publishing + `/api/events`; **Cendos assay interface** `/cendos` + `POST /assay/current` (bus twin) + Aegle proxies; **live metabolic playhead** (`metabLoop`) |
| `ede43e9` | **HR fix** | mechanistic heart rate: `engines/cardiac/heart_rate.py` (resting HR from fitness/vagal + IR/glycemia sympathetic + age + conditions; intra-day series tracking glucose excursion; HRV reduced under hyperglycemia); myocyte paced at real `cl_ms`; patch HR→series, HRV→live; honest time-lapse labels. Verified: healthy 69 bpm/HRV 38 vs T2D 84/16, cl_ms 868 vs 711 |
| `8e89c8b` | **#6 A** | `sdk.py` (Platform inprocess/attach) + `audit.py` (result_fingerprint + HMAC) + `screen()` cohort workflow — deterministic, tamper-detected, seed-sensitive |
| `da8d4c7` | **#6 B+D** | `shell.py` interactive environment + `livemore run` pipelines + `report.py` signed reports + `audit verify`; CLI rewired (bare `livemore` = the environment) |

### First full-system trial (uncommitted scripts in `trials/` — commit them)
Two-arm in-silico OGTT: cohort **n=48** (44 structured + 4 note-intake), 24 treatment / 24 placebo,
seed `20260716`. **Metformin 24/24 responders, OGTT Δmean −9.2 mg/dL (range −6.3…−17.8, median −7.0);
berberine 24/24, −10.2; placebo 0/24, exactly 0** (honest noiseless in-silico placebo). Secondary:
ΔHR −1.7 bpm, ΔHRV +2.5 ms (emergent autonomic benefit). Result fingerprint
`0f027d314bbeaece00767a5e0886f3c3745cacd498d3f654440894a84c0c64cf` — **re-run reproduced it
identically.** Evidence package in `trials/`: `LivemoreBio_Trial_Report.docx` (66 ¶, 2 tables,
3 charts), `livemore_trial_walkthrough.gif` (9-frame headless-captured walkthrough of the live
platform), `trial_results.json` (full per-twin data + signed record), `chart_*.png`,
`full_system_trial.py` / `make_charts.py` / `make_report.py` / `capture_walkthrough.py`.

---

## 10 · Verification state (2026-08-31 release candidate)

- **pytest:** **333 passed, 15 skipped, 44 subtests passed, 0 failed** in Python 3.11 on
  2026-08-31. The three warnings are framework deprecations; compileall, JavaScript syntax,
  and `git diff --check` remain required release gates.
- **20/20 functional sweep** (`/tmp/verify_all.py` pattern): pages+markers, HR individualization,
  patch channels, organ state, vocab, Cendos bus-twin assay, bus events, SDK determinism/signing/
  tamper-detection, attach mode.
- **Full visual pass in a real browser:** field-provenance real-human admission, single active-twin
  enforcement, bound virtual Patch sampling, three frozen heterogeneous cohorts, distinct animated
  Atlas silhouette, both Cendos protocols, run-scoped Biology drill-down, CSV/notebook controls,
  adapters, legacy console, and OpenAPI. Desktop and 390×844 mobile screenshots plus two native
  protocol recordings are retained under `.gstack/qa-reports/` and `docs/demo/`.
- **Trial reproducibility:** identical fingerprint on re-run (see §9).

---

## 11 · What remains / known gaps (honest)

1. **Broader executable physiology** — metformin/OGTT and PXR target engagement are bounded model
   contexts, not whole-human equivalence. Every new organ, indication, intervention, and endpoint
   needs a formal contract, an engine, coupling tests, an applicability declaration, and a physical
   qualification protocol.
2. **Commercial and credentialed adapters** — KEGG and GeneCards remain license-gated; USDA FDC
   remains credential-gated; Rosalind remains a governed external workbench handoff.
3. **Accounts/tenant isolation/production authorization** — local bearer auth exists, but
   multi-user identity and production PHI controls remain deferred.
4. **Runtime-state recovery** — authoritative subject identity survives restart, but transient
   perturbations and Patch observations reconstruct from the admitted baseline rather than a
   versioned event replay. Add encrypted event-sourced recovery before continuous clinical use.
5. **Agentic natural-language research terminal** — deferred to a later phase BY OWNER: an inbuilt
   research system that plans/runs multi-step experiments and hands results to Cendos. Do NOT build
   until asked.
6. **Pending organ engines** — vasculature, lungs, immune, and a full liver system have no autonomous
   engines (honestly flagged). A one-compartment hepatic PK module exists; that is not a complete
   liver twin. Kidney/brain are exposure-coupled readouts, not autonomous. Each new engine
   should light up its organ in body view + /biology and add patch channels.
7. **Pending patch biomarkers** — lactate, cortisol, Na/K/Cl, urea, ammonium, ethanol, SpO₂,
   motion: channels specified, no models. Skin temp is a flagged nominal constant.
8. **In-silico placebo realism** — placebo arm is exactly zero (no biological noise). If pharma
   feedback wants realistic placebo variability, add a documented stochastic layer (seeded!) —
   never silently.
9. **Bus scale-up** — file-backed pub/sub is right for single-box; socket/broker when distributed.
10. **Cendos assay breadth** — the software now has metformin/OGTT and PXR engagement protocols;
   PXR CYP3A4 induction remains deliberately unquantified. Add lipid, inflammatory, cardiotoxicity,
   and validated CYP3A4 assay wrappers only with corresponding measurement contracts.
11. **Physical programs** — LIFE Patch gen-2 hardware (EDA docs in docs/hardware) and the Cendos
    iPSC wet lab are capital/hiring programs, not software tasks. Never fake their data.
12. **Prospective validation** — framed as a partner-funded research program, not a pre-MVP build.
    (Retrospective DPP validation exists, #4; a second retrospective case reproducing a known
    clinical outcome is the highest-value missing credibility item.)
13. **Housekeeping** — commit `trials/`; stale `~/.livemore` keys (§3) could be archived. The
    installer contract runs on macOS and Linux CI; the complete scientific suite remains a local
    pre-activation gate.

---

## 12 · Recommended next steps (in order)

1. Execute the physical Cendos comparator plans for metformin and purified garcinoic acid; admit
   immutable QC-passing results against the frozen software run IDs.
2. Freeze LIFE Patch Rev B hardware, firmware, calibration, security, and per-channel analytical
   equivalence artifacts before claiming physical/virtual parity.
3. Add a second retrospective validation case and then a prospective partner protocol.
4. Build the next deep organ modules: hepatic/renal/endocrine first, then autonomic and the
   remaining whole-body systems, preserving continuous cross-system coupling.
5. Add tenant identity, production KMS, audit policy, and authorization before any partner PHI.
6. Review and deliberately import the untracked `trials/` evidence harness if its provenance is accepted.

---

## 13 · Engineering runbook

```bash
cd /path/to/livemorebio                       # editable checkout; venv: ./.venv
./.venv/bin/livemore start                    # LIFE :8851, Aegle :8850, Cendos :8852 (detached)
./.venv/bin/livemore open                     # opens http://127.0.0.1:8850 (start does NOT open a browser)
./.venv/bin/livemore status | stop            # infra control
./.venv/bin/livemore manifest                 # all 15 body systems + honest maturity JSON
./.venv/bin/livemore                          # bare = interactive pharma environment (REPL)
./.venv/bin/livemore run <pipeline.txt>       # scripted reproducible pipeline

# Restart Aegle after server.py changes (uvicorn does NOT auto-reload here):
./.venv/bin/livemore stop Aegle
./.venv/bin/livemore start Aegle
curl -s http://127.0.0.1:8850/health

# Tests (~100s; run in background and poll):
(./.venv/bin/python -m pytest -q > /tmp/pytest.log 2>&1 &) ; tail /tmp/pytest.log
# Current release gate: 333 passed + 15 environment/network-gated skips + 44 subtests.
# Zero failures is required.

# Git conventions:
git -c core.hooksPath=/dev/null commit -q -m "..."   # hooks bypassed deliberately
git push -u origin codex/<feature>                    # open a PR; never push feature work to main
```

**Environment:** Python 3.11.15. Installed: fastapi, uvicorn, cobra/COBRApy, COPASI/BasiCO,
chembl_webresource_client, libRoadRunner, libSBML, Myokit+CVODE, Neo4j driver, matplotlib,
selenium, Pillow, playwright (+chromium-headless-shell 149, used for headless capture),
python-docx 1.2.0. **NOT installed:** torch/transformers (OpenMed NER falls back to the regex
extractor — which is the working path; don't assume ML NER exists). `pip install` on this Mac
needs `--break-system-packages`.

**Gotchas that have already cost time (do not rediscover):**
- `aegle/server.py` has `def main()` mid-file with `if __name__ == "__main__": main()` at the
  BOTTOM — **routes must be defined above that guard** or they never register.
- `drug_targets` functions are `lru_cache`d — a ChEMBL timeout used to poison the cache until
  restart; the server-layer `_resolve_compound` clears+retries and `rcache` persists successes.
  Only successful resolutions are ever cached.
- Console pages fetch from the server — open `http://127.0.0.1:8850/...`, never `file://`.
- Browser rAF pauses in background tabs → /patch and metabolic playheads freeze until focused.
- Console element IDs churn (auto-refresh) — when driving the UI programmatically, call window
  functions (`stim(...)`, `runExperiment()`, `runAssay()`) rather than clicking stale refs.
- 3D `/biology`: mesh centering must happen AFTER scaling (the P1 heart-visibility bug).
- Twin `hr_measured` flag: real patch HR overrides the HR model — preserve this when touching
  `_recompute()`.
- Trial/report scripts read `/tmp/trial_results.json`; the canonical copy is
  `trials/trial_results.json`.

**QA tooling note:** exercise the loopback product in a real browser, retain desktop/mobile
screenshots, and use `tools/record_demo.cjs` for the interaction MP4. The recorder captures native
Playwright video and fails on browser errors; it is not a screenshot-to-video generator.

---

## 14 · Repos & artifacts index

- **Code:** `github.com/MannyAmah/livemorebio` (private) ↔ canonical workspace source or feature worktree
- **Vision/architecture:** project file `aegle-hhdt-ecosystem.html` (Aegle HHDT Ecosystem blueprint
  v0.1 — three pillars, closed loop, stack, phased P1–P6 plan incl. FDA MIDD / 21 CFR Part 11
  aspirations, Research Institute layer)
- **Evidence package:** `trials/` (report .docx, walkthrough .gif, signed results .json, charts,
  reproducible scripts)
- **Protocol demonstrations:** `docs/demo/livemorebio-metformin-two-cohorts-demo.mp4` and
  `docs/demo/livemorebio-garcinoic-acid-pxr-demo.mp4`
- **Release validation:** `docs/VALIDATION_AND_DEMO_GUIDE.md` and `.gstack/qa-reports/`
- **Hardware design docs:** `docs/hardware/` (LIFE Patch gen-2 EDA schematics — design only)
- **Models:** `models/` (Recon3D.xml gitignored ~28MB — re-obtain from VMH/BiGG if cloning fresh;
  Human-GEM.xml + genes.tsv; cardiac model assets)
- **Runtime state:** `~/.livemore/` (registry.json, encrypted events/snapshots/patch journals,
  resolve_cache/, owner-only operator/storage/admission keys, integrity records, service logs)
- **This document:** `docs/HANDOFF.md` — keep it updated at every phase boundary.

*End of handoff. The loop is the product; the mechanism is the moat; nothing fake, ever.*
