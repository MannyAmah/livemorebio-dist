# Beard mitochondrial source/import feasibility

2026-09-08 · Stage 1 only · **Native dimensional import rejected. No solve run.**

This packet advances the arctigenin/Burdock mechanism dependency. It does not
complete an arctigenin dose-response, tissue model, individualized human program,
or physical experiment. It does not change any running Livemore model or store.
The [approved source plan](solutions/2026-09-08-arctigenin-mitochondrial-source-plan.md)
retains the missing compound exposure/activity and whole-individual dependencies.

## Source evidence

The unchanged [PMR CellML file](https://models.physiomeproject.org/workspace/beard_2005/@@rawfile/8ec69b34c31cd1cbb53580d1853841bb333de78e/beard_2005.cellml)
has SHA-256
`4a4f931592df0e77a92c79447bf6d8947c7325f721a74b4d336d370abaaf3981`.
Its [exposure record](https://models.physiomeproject.org/exposure/959a4da5d8a0638f4b36adf5800f4fc0/beard_2005.cellml/view)
identifies commit `8ec69b34c31cd1cbb53580d1853841bb333de78e` and CC BY3.0.
Credit: Daniel A. Beard; CellML curation by David Nickerson and Physiome Model
Repository contributors. Original units, equations and initial conditions were
not rewritten. Model bytes remain in the previously acquired private source
directory; no subscription content or participant records were used.

The source audit retains all 47 components, 339 variable declarations,
28 unit definitions, 160 connections, 65 equations, 19 differential states and
66 literal initial values. MathML retains ordered children, numeric exponent
tails, units and piecewise structure. Complete inventories can be regenerated
with the tool below; the source hash, not an abbreviated summary, identifies
the original implementation. This bounded inventory is not a general CellML
validator or a completed dimensional proof.

Two exact source identities were checked without integration:

- Matrix ATP and ADP right-hand sides cancel. Their identically named fluxes and
  water-fraction inputs are also connected to the same source quantities; local
  spelling alone was not accepted as evidence of that identity.
- The oxygen right-hand side is exactly zero in molar/second. Oxygen is a fixed
  boundary in this implementation, not computed systemic oxygen consumption.

The source/paper discrepancies remain unresolved: disabled AK activity versus
the correction's active value, different water fractions and capacitance
precision. The original publication's kinetic-validation limitations remain.
[Original paper](https://doi.org/10.1371/journal.pcbi.0010036),
[published correction](https://doi.org/10.1371/journal.pcbi.0020008).

## Actual native import result

Myokit1.39.2's [CellML API support notes](https://myokit.readthedocs.io/en/stable/api_formats/cellml_v1.html)
explicitly exclude new base-unit definitions. Its installed parser implementation
warns and substitutes dimensionless units for unsupported base definitions.
The [documented native parser](https://myokit.readthedocs.io/en/stable/api_formats/cellml_v1.html#myokit.formats.cellml.v1.parse_string)
was exercised on the unchanged verified source, without a simulation object,
native compilation or solver call.

| Check | Actual result |
| --- | --- |
| Native parse returned an object | Yes |
| Custom base units in source | `cell`, `cytoplasm`, `mitochondria` |
| Native parser warnings | 3 |
| Import accepted | **No** |
| Structured gate code | `UNSUPPORTED_DIMENSIONAL_CONSTRUCT` |
| Equations/units modified | No |
| Native solves | 0 |
| Audit + parser elapsed time | 0.125846 s in the retained review process |
| Process peak RSS | 55,803,904 bytes on macOS; includes Python/runtime imports |

The returned object is **not** admitted as a unit-preserving model. Neither
warnings suppression nor a dimensionless metadata label fixes this loss. The
tool also refuses an unreviewed Myokit version or a changed source hash.

## Reproduce and review

`tools/beard_source_contract.py` is a standalone source-audit utility, not a
product execution protocol. It reads a previously acquired pinned file; it has
no network downloader, registry integration or solver route. Use a private review
environment as for the other source/native tests. For the existing source copy:

```bash
LIVEMORE_TEST_BEARD_SOURCE=/tmp/livemore-arctigenin-source.BCaB9w/beard_2005.cellml \
  /Users/emman/.local/share/livemorebio/current/source/.venv/bin/python -B \
  tools/run_review_tests.py -q -p no:cacheprovider \
  livemorebio/tests/test_beard_source_contract.py
```

The isolated regression run passed **20 tests in 0.29 seconds**. Without the
explicit local source opt-in, 19 technical tests pass and the actual-source
parser check is clearly skipped. Initial tests failed before the utility existed.
Tests cover source pinning, unknown imports/MathML/variables/units, nonfinite and
bounded XML, duplicate identities, exact source counts/states and failure when
a parser returns an object after unit loss. Technical fixture XML is not source
or measurement evidence. This maker test result awaits independent review.

For inspection in an already isolated process, the source-audit command is:

```bash
python -I -B tools/beard_source_contract.py PATH_TO_PINNED_CELLML --probe-import
```

`--full-inventory` additionally prints the complete mathematical/unit inventory.
Exit status reports whether the audit command completed; **it is not scientific
readiness**. Inspect `execution_ready:false` and `native_import.import_accepted`.
Do not use import-command success as a launch gate.

## Next decision, not yet implemented

Choose and independently review a native CellML engine that preserves custom
base dimensions, or a mathematically explicit, independently validated unit
translation retaining compartment-volume semantics outside a solver's limited
unit system. Such a translation would be a new source-derived version, not the
unchanged import. It must account for every original unit and all equations,
with dimensional and conservation tests before numerical integration. Do not
turn arbitrary compartment volume labels into SI mass/length substitutes.

Only after that gate may the separately preregistered numerical matrix run.
Source replication, arctigenin exposure-to-complex-I activity mapping, human
contextualization and physical validation still remain independent gates.

Compounded lesson: parsers can return plausible model objects after dropping
scientifically meaningful dimensions. Read runtime support and warnings, compare
the source representation explicitly, and fail admission rather than allowing
syntactic import success to become a biological-readiness claim.
