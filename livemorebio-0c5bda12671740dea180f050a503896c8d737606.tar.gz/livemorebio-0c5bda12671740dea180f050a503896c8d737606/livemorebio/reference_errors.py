"""Stable typed reason codes for optional reference-data boundaries."""
from enum import StrEnum


class ReferenceReason(StrEnum):
    DATA_NOT_DISTRIBUTED = 'REFERENCE_DATA_NOT_DISTRIBUTED'


class ReferenceDataNotDistributed(RuntimeError):
    """The optional reference substrate is not present in this distribution."""
    code = ReferenceReason.DATA_NOT_DISTRIBUTED

    def __init__(self, *, public_omission: bool = True) -> None:
        super().__init__(
            'The plant reference profiles and safety register are not distributed '
            'with the public archive. A complete, lawfully acquired reference '
            'dataset is required to load this substrate.'
            if public_omission else
            'A required plant reference file is missing. A complete, lawfully '
            'acquired profiles dataset and safety register are required to load this substrate.'
        )
