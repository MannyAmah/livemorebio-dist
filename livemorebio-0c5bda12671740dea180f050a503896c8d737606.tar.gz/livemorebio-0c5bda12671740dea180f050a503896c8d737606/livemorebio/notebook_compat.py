"""Compatibility for the qualified Jupyter/Tornado static-file combination."""
from __future__ import annotations

from functools import wraps
from importlib import metadata
import os

from jupyter_server.base.handlers import FileFindHandler
import tornado
from tornado.web import StaticFileHandler


def install_static_file_compat() -> None:
    """Supply Jupyter's missing symlink boundary; leave Tornado validation intact."""
    if tornado.version != "6.5.9" or not hasattr(StaticFileHandler, "_resolve_symlink_target"):
        return
    try:
        if metadata.version("jupyter-server") != "2.21.0":
            return
    except metadata.PackageNotFoundError:
        return

    validate = FileFindHandler.validate_absolute_path
    if getattr(validate, "_livemore_symlink_compat", False):
        return

    @wraps(validate)
    def validate_with_symlink_root(self: FileFindHandler, root: str, absolute_path: str) -> str | None:
        if (hasattr(StaticFileHandler, "_resolve_symlink_target")
                and not hasattr(self, "allowed_symlink_directory")):
            # Match FileFindHandler's unresolved first-root selection, rather
            # than allowing symlinks to any of its other static search roots.
            for served_root in self.root:
                if (absolute_path + os.sep).startswith(served_root):
                    self.allowed_symlink_directory = served_root
                    break
        return validate(self, root, absolute_path)

    setattr(validate_with_symlink_root, "_livemore_symlink_compat", True)
    FileFindHandler.validate_absolute_path = validate_with_symlink_root
