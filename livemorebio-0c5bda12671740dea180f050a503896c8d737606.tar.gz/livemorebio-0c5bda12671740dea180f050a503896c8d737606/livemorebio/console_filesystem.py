"""Descriptor-only native ownership checks and extended ACL tightening."""
from __future__ import annotations

import ctypes
from dataclasses import dataclass
import errno
import os
import sys


_NATIVE_PLATFORM = sys.platform
_ACL_TYPE_EXTENDED = 0x100
_ACL_ALLOW, _ACL_DENY = 1, 2
_ACL_MUTATIONS = tuple(1 << bit for bit in (2, 4, 5, 6, 12, 13))
# sys/acl.h: every Darwin permission, including metadata and synchronize.
_ACL_PERMISSIONS = tuple(1 << bit for bit in (*range(1, 14), 20))
_ACL_FLAGS = tuple(1 << bit for bit in (4, 5, 6, 7, 8))
_UNSAFE_LINUX_FILESYSTEMS = frozenset({
    0xFF534D42, 0xFE534D42, 0x517B, 0x4D44, 0x2011BAB0,
    0x5346544E, 0x65735546, 0x01021997,
})


class ConsoleFilesystemError(RuntimeError):
    """The caller must refuse the descriptor and attach its admitted pathname."""


class ACLClearError(ConsoleFilesystemError):
    """Retain successful replacement evidence if cleanup/readback fails."""

    def __init__(self, message: str, *, replaced: bool):
        super().__init__(message)
        self.replaced = replaced
        self.foreign_access_detected = False
        self.foreign_access_cleared = False


_POINTER = ctypes.c_void_p
_OUT_POINTER = ctypes.POINTER(_POINTER)
_ACL_SIGNATURES = {
    "acl_get_fd_np": (_POINTER, [ctypes.c_int, ctypes.c_int]),
    "acl_get_entry": (ctypes.c_int, [_POINTER, ctypes.c_int, _OUT_POINTER]),
    "acl_get_tag_type": (ctypes.c_int, [_POINTER, ctypes.POINTER(ctypes.c_int)]),
    "acl_get_qualifier": (_POINTER, [_POINTER]),
    "acl_get_permset": (ctypes.c_int, [_POINTER, _OUT_POINTER]),
    "acl_get_perm_np": (ctypes.c_int, [_POINTER, ctypes.c_int]),
    "acl_get_flagset_np": (ctypes.c_int, [_POINTER, _OUT_POINTER]),
    "acl_get_flag_np": (ctypes.c_int, [_POINTER, ctypes.c_int]),
    "acl_set_fd_np": (ctypes.c_int, [ctypes.c_int, _POINTER, ctypes.c_int]),
    "acl_init": (_POINTER, [ctypes.c_int]),
    "acl_free": (ctypes.c_int, [_POINTER]),
    "acl_valid": (ctypes.c_int, [_POINTER]),
    "mbr_uid_to_uuid": (ctypes.c_int, [ctypes.c_uint32, _POINTER]),
}


def _darwin_acl_library():
    try:
        library = ctypes.CDLL("/usr/lib/libSystem.B.dylib", use_errno=True)
        for name, (result, arguments) in _ACL_SIGNATURES.items():
            function = getattr(library, name)
            function.restype, function.argtypes = result, arguments
        return library
    except (OSError, AttributeError, TypeError):
        raise ConsoleFilesystemError("required extended ACL protections are unavailable") from None


def _require_zero(result: int) -> None:
    if result != 0:
        raise ConsoleFilesystemError("extended ACL inspection or replacement failed")


@dataclass(frozen=True)
class _ACLEntry:
    tag: int
    principal: bytes
    mutations: int
    flags: int
    permissions: int


def _darwin_acl_entries(library, descriptor: int) -> list[_ACLEntry]:
    ctypes.set_errno(0)
    acl = library.acl_get_fd_np(descriptor, _ACL_TYPE_EXTENDED)
    if not acl:
        if ctypes.get_errno() == errno.ENOENT:
            # On Darwin a valid descriptor without an extended ACL returns
            # NULL/ENOENT (verified against real empty and nonempty scratch ACLs).
            # No pathname is involved, so this cannot mean a missing path.
            return []
        raise ConsoleFilesystemError("extended ACL inspection failed")
    try:
        _require_zero(library.acl_valid(acl))
        entries = []
        selector = 0  # Darwin ACL_FIRST_ENTRY; ACL_NEXT_ENTRY is -1, not Linux's 1.
        while True:
            entry = _POINTER()
            ctypes.set_errno(0)
            result = library.acl_get_entry(acl, selector, ctypes.byref(entry))
            if result == -1 and ctypes.get_errno() == errno.EINVAL:
                # Darwin documents EINVAL at exhaustion, including an empty ACL.
                # acl_valid above distinguishes a malformed ACL from exhaustion.
                return entries
            _require_zero(result)
            selector = -1
            tag = ctypes.c_int()
            _require_zero(library.acl_get_tag_type(entry, ctypes.byref(tag)))
            if tag.value not in {_ACL_ALLOW, _ACL_DENY}:
                raise ConsoleFilesystemError("extended ACL entry type is unsupported")
            principal = library.acl_get_qualifier(entry)
            if not principal:
                raise ConsoleFilesystemError("extended ACL principal inspection failed")
            try:
                qualifier = ctypes.string_at(principal, 16)  # Darwin ACL principals are UUIDs.
            finally:
                _require_zero(library.acl_free(principal))
            permissions, flags = _POINTER(), _POINTER()
            _require_zero(library.acl_get_permset(entry, ctypes.byref(permissions)))
            _require_zero(library.acl_get_flagset_np(entry, ctypes.byref(flags)))
            permission_bits = flag_bits = 0
            for permission in _ACL_PERMISSIONS:
                enabled = library.acl_get_perm_np(permissions, permission)
                if enabled not in {0, 1}:
                    raise ConsoleFilesystemError("extended ACL permissions inspection failed")
                if enabled:
                    permission_bits |= permission
            for flag in _ACL_FLAGS:
                enabled = library.acl_get_flag_np(flags, flag)
                if enabled not in {0, 1}:
                    raise ConsoleFilesystemError("extended ACL flags inspection failed")
                if enabled:
                    flag_bits |= flag
            entries.append(_ACLEntry(tag.value, qualifier,
                                     permission_bits & sum(_ACL_MUTATIONS), flag_bits,
                                     permission_bits))
    finally:
        _require_zero(library.acl_free(acl))


def require_no_foreign_acl_writes(descriptor: int) -> None:
    if _NATIVE_PLATFORM != "darwin":
        # On Linux, 0700 directories and 0600 pages mask POSIX ACL entries to
        # nothing. Its ancestor mode/sticky checks also cover the ACL mask.
        return
    library = _darwin_acl_library()
    entries = _darwin_acl_entries(library, descriptor)
    allows = [entry for entry in entries if entry.tag == _ACL_ALLOW and entry.mutations]
    if not allows:
        return
    owner_uuid = (ctypes.c_ubyte * 16)()
    _require_zero(library.mbr_uid_to_uuid(os.geteuid(), owner_uuid))
    # Groups, unresolved UUIDs and inherit-only mutation grants are not the
    # effective user's own grant. DENY entries never grant authority.
    if any(entry.principal != bytes(owner_uuid) for entry in allows):
        raise ConsoleFilesystemError("an ACL entry grants another account write access")


def _replace_with_empty_acl(library, descriptor: int, remaining_error: str) -> None:
    empty_acl = library.acl_init(0)
    if not empty_acl:
        raise ACLClearError("extended ACL replacement failed", replaced=False)
    replaced = False
    try:
        try:
            _require_zero(library.acl_set_fd_np(descriptor, empty_acl, _ACL_TYPE_EXTENDED))
            replaced = True
        finally:
            _require_zero(library.acl_free(empty_acl))
        if _darwin_acl_entries(library, descriptor):
            raise ConsoleFilesystemError(remaining_error)
    except ConsoleFilesystemError as error:
        raise ACLClearError(str(error), replaced=replaced) from None


def clear_launch_directory_acl(descriptor: int) -> None:
    if _NATIVE_PLATFORM != "darwin":
        return
    library = _darwin_acl_library()
    if _darwin_acl_entries(library, descriptor):
        _replace_with_empty_acl(library, descriptor,
                                "extended ACL entries remain on the launch directory")


def clear_extended_acl(descriptor: int) -> bool:
    """Clear every entry, verify removal, and report foreign access grants.

    The caller must establish descriptor ownership first. DENY entries grant
    nothing; group and unknown UUIDs conservatively count as other principals.
    Even an inherit-only ALLOW can expose subsequently created credentials.
    """
    if _NATIVE_PLATFORM != "darwin":
        return False
    library = _darwin_acl_library()
    try:
        entries = _darwin_acl_entries(library, descriptor)
        if not entries:
            return False
        allows = [entry for entry in entries if entry.tag == _ACL_ALLOW and entry.permissions]
        foreign = False
        if allows:
            owner_uuid = (ctypes.c_ubyte * 16)()
            _require_zero(library.mbr_uid_to_uuid(os.geteuid(), owner_uuid))
            foreign = any(entry.principal != bytes(owner_uuid) for entry in allows)
    except ConsoleFilesystemError:
        # Classification is advisory: an unreadable or unknown entry must not
        # prevent revocation, and cannot safely be treated as owner-only.
        foreign = True
    try:
        _replace_with_empty_acl(library, descriptor, "extended ACL entries remain")
    except ACLClearError as error:
        # A successful empty replacement already revoked access, even if a
        # later free/readback fails or a concurrent actor reinstalls an entry.
        error.foreign_access_detected = foreign
        error.foreign_access_cleared = foreign and error.replaced
        raise
    return foreign


def has_extended_acl(descriptor: int) -> bool:
    """Inspect an admitted descriptor without replacing its inode's ACL."""
    return _NATIVE_PLATFORM == "darwin" and bool(
        _darwin_acl_entries(_darwin_acl_library(), descriptor)
    )


def require_empty_page_acl(descriptor: int) -> None:
    if has_extended_acl(descriptor):
        # Never repair a page: another account may already hold its descriptor.
        raise ConsoleFilesystemError("page has an extended ACL entry")


class _DarwinStatFS(ctypes.Structure):
    # sys/mount.h __DARWIN_STRUCT_STATFS64, shared by arm64 and x86_64.
    _fields_ = [
        ("f_bsize", ctypes.c_uint32), ("f_iosize", ctypes.c_int32),
        *[(name, ctypes.c_uint64) for name in ("f_blocks", "f_bfree", "f_bavail", "f_files", "f_ffree")],
        ("f_fsid", ctypes.c_int32 * 2), ("f_owner", ctypes.c_uint32),
        ("f_type", ctypes.c_uint32), ("f_flags", ctypes.c_uint32), ("f_fssubtype", ctypes.c_uint32),
        ("f_fstypename", ctypes.c_char * 16), ("f_mntonname", ctypes.c_char * 1024),
        ("f_mntfromname", ctypes.c_char * 1024), ("f_flags_ext", ctypes.c_uint32),
        ("f_reserved", ctypes.c_uint32 * 7),
    ]


class _LinuxStatFS(ctypes.Structure):
    # Linux statfs uses native long/unsigned long counts (not statfs64 on ILP32).
    _fields_ = [
        ("f_type", ctypes.c_long), ("f_bsize", ctypes.c_long),
        *[(name, ctypes.c_ulong) for name in ("f_blocks", "f_bfree", "f_bavail", "f_files", "f_ffree")],
        ("f_fsid", ctypes.c_int32 * 2), ("f_namelen", ctypes.c_long),
        ("f_frsize", ctypes.c_long), ("f_flags", ctypes.c_long), ("f_spare", ctypes.c_long * 4),
    ]


def require_ownership_filesystem(descriptor: int) -> None:
    try:
        if _NATIVE_PLATFORM == "darwin":
            library = ctypes.CDLL("/usr/lib/libSystem.B.dylib", use_errno=True)
            record = _DarwinStatFS()
            # The explicit 64-bit ABI avoids Intel's legacy fstatfs symbol;
            # arm64 exports fstatfs64 too, without the $INODE64 alias.
            function = library.fstatfs64
        elif _NATIVE_PLATFORM.startswith("linux"):
            library = ctypes.CDLL(None, use_errno=True)
            record = _LinuxStatFS()
            function = library.fstatfs
        else:
            raise ConsoleFilesystemError("required filesystem ownership protections are unavailable")
        function.restype = ctypes.c_int
        function.argtypes = [ctypes.c_int, ctypes.POINTER(type(record))]
        if function(descriptor, ctypes.byref(record)) != 0:
            raise ConsoleFilesystemError("filesystem ownership inspection failed")
    except (OSError, AttributeError, TypeError):
        raise ConsoleFilesystemError("filesystem ownership inspection failed") from None
    unsafe = (bool(record.f_flags & 0x00200000) or record.f_fstypename not in {b"apfs", b"hfs"}
              if _NATIVE_PLATFORM == "darwin"
              else record.f_type & 0xFFFFFFFF in _UNSAFE_LINUX_FILESYSTEMS)
    if unsafe:
        raise ConsoleFilesystemError("the filesystem does not enforce ownership")
