"""Opt-in, product-served OpenAPI reference without third-party browser assets."""
from __future__ import annotations

from html import escape
import json
import os

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, Response


_STYLE = """
body { font-family: system-ui, sans-serif; max-width: 75rem; margin: 2rem auto; padding: 0 1rem; }
summary { cursor: pointer; padding: .75rem; background: #f2f4f6; }
details { margin: .75rem 0; border: 1px solid #ddd; }
pre { white-space: pre-wrap; overflow-wrap: anywhere; padding: 1rem; }
code, pre { font-family: ui-monospace, monospace; }
a { color: #14597a; }
"""


def install_api_docs(app: FastAPI) -> None:
    """Both familiar documentation URLs expose the same read-only reference.

    An explicit setting at service startup is required. The product owns every
    asset, so enabling docs never imports executable CDN code into its origin.
    """
    if os.environ.get("LIVEMORE_ENABLE_API_DOCS") != "1":
        return

    @app.get("/api-docs.css", include_in_schema=False)
    def documentation_styles() -> Response:
        return Response(_STYLE, media_type="text/css")

    @app.get("/docs", include_in_schema=False)
    @app.get("/redoc", include_in_schema=False)
    def documentation() -> HTMLResponse:
        schema = app.openapi()
        title = escape(str(schema.get("info", {}).get("title", "API reference")))
        entries = []
        for path, operations in schema.get("paths", {}).items():
            for method, operation in operations.items():
                if method not in {"get", "put", "post", "delete", "options", "head", "patch", "trace"}:
                    continue
                summary = escape(str(operation.get("summary", "")))
                body = escape(json.dumps(operation, indent=2, ensure_ascii=False))
                entries.append(f"<details><summary><code>{method.upper()} {escape(path)}</code> "
                               f"{summary}</summary><pre>{body}</pre></details>")
        components = escape(json.dumps(schema.get("components", {}), indent=2, ensure_ascii=False))
        return HTMLResponse(
            '<!doctype html><html lang="en"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            f'<title>{title} — API reference</title>'
            '<link rel="stylesheet" href="/api-docs.css"></head><body>'
            f'<h1>{title}</h1><p>Read-only API reference. '
            '<a href="/openapi.json">Download the OpenAPI schema</a>.</p>'
            + "".join(entries)
            + f'<details><summary>Schema definitions</summary><pre>{components}</pre></details>'
            '</body></html>', headers={"Cache-Control": "no-store"},
        )
