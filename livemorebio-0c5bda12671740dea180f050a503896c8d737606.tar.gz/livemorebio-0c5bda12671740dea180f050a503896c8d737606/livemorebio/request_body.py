"""Stream-bound private console forms and whole-body legacy JSON requests."""
from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import unquote_to_bytes

from fastapi import HTTPException, Request

from .strict_json import MAX_JSON_BYTES


MAX_CONSOLE_FORM_BYTES = 4096
_CONSOLE_FORM_MEDIA = re.compile(
    r"application/x-www-form-urlencoded(?:[ \t]*;[ \t]*charset[ \t]*=[ \t]*utf-8)?\Z",
    re.ASCII | re.IGNORECASE,
)
_CONSOLE_FORM = re.compile(rb"code=((?:[a-zA-Z0-9*_.+\-]|%[0-9a-fA-F]{2})+)\Z")


async def bounded_console_form_request(request: Request) -> str:
    """Admit one ASCII form field without buffering an over-limit chunk."""
    def refuse(status: int = 400) -> None:
        raise HTTPException(status_code=status, detail="invalid or expired console code")

    media = request.headers.getlist("content-type")
    if len(media) != 1 or _CONSOLE_FORM_MEDIA.fullmatch(media[0].strip(" \t")) is None:
        refuse()
    lengths = request.headers.getlist("content-length")
    if len(lengths) > 1:
        refuse()
    if lengths:
        if re.fullmatch(r"[0-9]+", lengths[0], re.ASCII) is None:
            refuse()
        try:
            advertised = int(lengths[0])
        except ValueError:
            refuse()
        if advertised > MAX_CONSOLE_FORM_BYTES:
            refuse(413)

    raw = bytearray()
    async for chunk in request.stream():
        if len(raw) + len(chunk) > MAX_CONSOLE_FORM_BYTES:
            refuse(413)
        raw.extend(chunk)
    match = _CONSOLE_FORM.fullmatch(raw)
    if match is None:
        refuse()
    try:
        code = unquote_to_bytes(match[1].replace(b"+", b" ")).decode("ascii")
    except UnicodeDecodeError:
        refuse()
    if any(ord(char) < 32 or ord(char) == 127 for char in code):
        refuse()
    return code


async def bounded_json_request(request: Request) -> Any:
    """Keep legacy JSON semantics within the existing 2 MB research input limit."""
    length = request.headers.get("content-length")
    if length is not None:
        try:
            advertised = int(length)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid Content-Length") from None
        if advertised < 0:
            raise HTTPException(status_code=400, detail="Invalid Content-Length")
        if advertised > MAX_JSON_BYTES:
            raise HTTPException(status_code=413, detail="Request body exceeds 2 MB")

    raw = bytearray()
    async for chunk in request.stream():
        # Content-Length can be absent or false. Do not retain an over-limit
        # chunk, and leave the remaining stream unread after the refusal.
        if len(raw) + len(chunk) > MAX_JSON_BYTES:
            raise HTTPException(status_code=413, detail="Request body exceeds 2 MB")
        raw.extend(chunk)
    return json.loads(raw)
