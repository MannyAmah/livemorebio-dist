"""Bounded, unambiguous JSON admission without HTTP or storage dependencies."""
from __future__ import annotations

import json
import math
from typing import Any

MAX_JSON_BYTES = 2_000_000
MAX_JSON_DEPTH = 64
MAX_SAFE_INTEGER = 9_007_199_254_740_991


class StrictJSONError(ValueError):
    """Safe input error: messages never repeat scientific or identifying payloads."""


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise StrictJSONError("JSON contains duplicate object keys")
        result[key] = value
    return result


def _finite_float(value: str) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise StrictJSONError("JSON requires finite numbers")
    return result


def _safe_integer(value: str) -> int:
    # Browser Number would silently round larger integer identifiers or counts.
    if len(value.lstrip("-")) > 16 or abs(int(value)) > MAX_SAFE_INTEGER:
        raise StrictJSONError("JSON integers must be exactly representable; use a string for larger identifiers")
    return int(value)


def _reject_constant(value: str) -> None:
    raise StrictJSONError("JSON requires finite numbers")


def _check_depth(text: str) -> None:
    depth = 0
    quoted = False
    escaped = False
    for char in text:
        if quoted:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char in "[{":
            depth += 1
            if depth > MAX_JSON_DEPTH:
                raise StrictJSONError("JSON nesting exceeds 64 levels")
        elif char in "]}":
            depth -= 1


def parse_json_object(raw: str | bytes | bytearray, *, max_bytes: int = MAX_JSON_BYTES) -> dict[str, Any]:
    """Parse the same strict object contract used by browser JSON forms and APIs."""
    if not isinstance(raw, (str, bytes, bytearray)):
        raise StrictJSONError("JSON requires text")
    if type(max_bytes) is not int or not 1 <= max_bytes <= 8 * 1024 * 1024:
        raise StrictJSONError("JSON byte limit is invalid")
    try:
        encoded = raw.encode("utf-8") if isinstance(raw, str) else raw
        if len(encoded) > max_bytes:
            raise StrictJSONError("JSON input exceeds 2 MB" if max_bytes == MAX_JSON_BYTES else "JSON input exceeds byte limit")
        text = encoded.decode("utf-8")
    except UnicodeError as error:
        raise StrictJSONError("JSON requires valid UTF-8 text") from error
    _check_depth(text)
    try:
        result = json.loads(text, object_pairs_hook=_unique_object, parse_float=_finite_float,
                            parse_int=_safe_integer, parse_constant=_reject_constant)
    except StrictJSONError:
        raise
    except (ValueError, RecursionError, OverflowError) as error:
        raise StrictJSONError("JSON requires valid syntax") from error
    if not isinstance(result, dict):
        raise StrictJSONError("JSON requires an object")
    return result


# Atlas artifacts fingerprint the original local parser functions. Keep the
# response-only extension outside that producer namespace without changing its API.
from .frozen_member_json import parse_frozen_member_response
