"""The one decision on free-text clinical-note intake (L0-R15, walk finding L0W-1).

The release states that PHI-like input fails closed unless local
de-identification is operational. This release ships no operational local
de-identification (OpenMed is optional, not shipped and not qualified as a
de-identifier), so every path that accepts a free-text clinical note calls
:func:`clinical_note_gate` before it reads, parses, stores, logs or echoes the
note, and the gate refuses. Nothing configures it open: no setting, environment
variable or argument changes the answer.

The gate never receives the note, so it cannot keep or log it. The refusal
names a code and a reason in words, and never contains note text.

A note can also arrive where no note is asked for (L0-R15 round 1). Two rules
of this module answer that, and both refuse through the same gate. Only the
first is closed; the second is a best-effort extra, not a gate (L0-R16):

- **Structured fields take technical values only.** A field that describes a
  modeled person (an identifier, sex, conditions, genome) admits a value only
  from its closed vocabulary or grammar; anything else is refused with
  :func:`refuse_field`, which names the field and what it accepts and never the
  value. A body key a route does not define is refused the same way, so a note
  under a misspelled key is never taken as a success.
- **Some free text is screened, as a best effort.** Text some fields keep or
  echo passes :func:`screen_text` (or :func:`screen_strings` for a whole body)
  first. Text that carries a listed mark of a clinical note (a record number, a
  date of birth, an age-and-sex shorthand, a contact identifier, a patient
  label or a note heading) is refused before it is stored or echoed. The screen
  is a deny-list of marks, not de-identification and not a guarantee: a note
  written without those marks passes, and other free-text fields are not
  screened at all. The release is not a patient-data environment; patient data
  must never be entered. Its value is never kept, logged or put in the refusal.

No free text leaves the machine whatever this screen decides: outbound requests
to third parties pass the egress check of ``livemorebio/egress.py`` (L0-R16).

``livemorebio/tests/test_l0_clinical_note_gate.py`` and
``livemorebio/tests/test_l0_free_text_gate.py`` hold every path to this. A
release that makes de-identification operational changes this module and
revisits every caller those tests list, because each caller treats the gate as
a refusal.
"""
from __future__ import annotations

import re
import unicodedata
from typing import Any, NoReturn

CLINICAL_NOTE_NOT_ACCEPTED = "CLINICAL_NOTE_NOT_ACCEPTED"
CLINICAL_NOTE_REFUSAL_REASON = (
    "this release does not accept clinical notes; local de-identification is not operational"
)
# HTTP routes answer with this status, like the release's other typed refusals.
CLINICAL_NOTE_REFUSAL_STATUS = 422


class ClinicalNoteRefused(Exception):
    """A typed refusal of a clinical note. It holds no note text.

    ``field`` and ``accepts`` are fixed descriptions written in the code (the
    field's name and what it admits), never caller input; they are absent when
    a note itself was refused.
    """

    code = CLINICAL_NOTE_NOT_ACCEPTED
    reason = CLINICAL_NOTE_REFUSAL_REASON

    def __init__(self, field: str | None = None, accepts: str | None = None) -> None:
        super().__init__(f"{CLINICAL_NOTE_NOT_ACCEPTED}: {CLINICAL_NOTE_REFUSAL_REASON}")
        self.field = field
        self.accepts = accepts

    def payload(self) -> dict[str, str]:
        """The JSON body of the refusal: the code and the reason in words."""
        body = {"code": self.code, "error": self.reason}
        if self.field is not None:
            body["field"] = self.field
        if self.accepts is not None:
            body["accepts"] = self.accepts
        return body


def clinical_note_gate() -> NoReturn:
    """Decide clinical-note intake before the note is touched. This release refuses.

    Every intake path calls this first, before any parsing, storage, logging or
    echo of the note. Without operational local de-identification it raises
    :class:`ClinicalNoteRefused`, always.
    """
    raise ClinicalNoteRefused()


def refuse_field(field: str, accepts: str) -> NoReturn:
    """Refuse a structured field whose value is not technical: it may carry a note.

    ``field`` and ``accepts`` must be fixed strings from the code. The value is
    never passed here, so it cannot reach the refusal.
    """
    try:
        clinical_note_gate()
    except ClinicalNoteRefused:
        raise ClinicalNoteRefused(field, accepts) from None


# ---------------------------------------------------------------- the screen

# Letters from other scripts that read as Latin ones. A note spelled with them
# is still a note, so they are read as the Latin letter before the marks.
_CONFUSABLE = str.maketrans({
    "А": "A", "В": "B", "С": "C", "Е": "E", "Н": "H", "І": "I", "Ј": "J", "К": "K", "М": "M",
    "О": "O", "Р": "P", "Ѕ": "S", "Т": "T", "Х": "X", "У": "Y", "а": "a", "с": "c", "е": "e",
    "і": "i", "ј": "j", "о": "o", "р": "p", "ѕ": "s", "х": "x", "у": "y", "ԁ": "d", "ո": "n",
    "Α": "A", "Β": "B", "Ε": "E", "Ζ": "Z", "Η": "H", "Ι": "I", "Κ": "K", "Μ": "M", "Ν": "N",
    "Ο": "O", "Ρ": "P", "Τ": "T", "Υ": "Y", "Χ": "X", "ο": "o", "ν": "v",
    # Armenian look-alikes, and Latin small capitals, which have no compatibility form
    "օ": "o", "Օ": "O", "ս": "u", "հ": "h",
    "ᴀ": "A", "ʙ": "B", "ᴄ": "C", "ᴅ": "D", "ᴇ": "E", "ꜰ": "F", "ɢ": "G", "ʜ": "H", "ɪ": "I",
    "ᴊ": "J", "ᴋ": "K", "ʟ": "L", "ᴍ": "M", "ɴ": "N", "ᴏ": "O", "ᴘ": "P", "ʀ": "R", "ꜱ": "S",
    "ᴛ": "T", "ᴜ": "U", "ᴠ": "V", "ᴡ": "W", "ʏ": "Y", "ᴢ": "Z",
})
# Separators that may sit inside an abbreviation ("M.R.N.", "D O B").
_SEP = r"[^a-z0-9]{0,2}"
# A mark stands alone: not inside a longer run of letters or digits.
_START, _END = r"(?<![a-z0-9])", r"(?![a-z0-9])"
# A record label may run straight into its number ("MRN8823", "DOB19020304").
_LABEL_END = r"(?![a-z])"
_MARKS_FOLDED = tuple(re.compile(pattern) for pattern in (
    # record and identity labels
    _START + "m" + _SEP + "r" + _SEP + "n" + _LABEL_END,
    _START + "d" + _SEP + "o" + _SEP + "b" + _LABEL_END,
    _START + "s" + _SEP + "s" + _SEP + "n" + _LABEL_END,
    r"medical[^a-z0-9]+record[^a-z0-9]*(?:#|:|[0-9]|(?:number|no|num)" + _END + ")",
    r"(?<![a-z0-9])record[^a-z0-9]*(?:#|(?:number|no|num)" + _END + ")",
    r"date[^a-z0-9]+of[^a-z0-9]+birth",
    r"birth[^a-z0-9]*date",
    r"(?<![a-z0-9])born[^a-z0-9]+(?:on[^a-z0-9]+)?(?:[0-9]|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)",
    r"social[^a-z0-9]+security",
    r"(?<![a-z0-9])patient[^a-z0-9]+(?:name|id|identifier|number|no)" + _END,
    r"(?<![a-z0-9])(?:patient|pt)[ \t]*[:#]",
    # age shorthand
    r"(?<![a-z0-9])[0-9]{1,3}[^a-z0-9]{0,2}(?:years?|yrs?)[^a-z0-9]{0,2}old" + _END,
    r"(?<![a-z0-9])(?:years?|yrs?)[^a-z0-9]{1,2}old" + _END,
    r"(?<![a-z0-9])[0-9]{1,3}[^a-z0-9]{0,2}y[^a-z0-9]{0,2}o(?:[^a-z0-9]{0,2}[mf])?" + _END,
    # contact identifiers (the e-mail shape is anchored at "@", so a long run of letters is read once)
    r"(?<=[a-z0-9._%+-])@[a-z0-9-]+(?:\.[a-z0-9-]+)+",
    r"(?<![0-9])[0-9]{3}-[0-9]{2}-[0-9]{4}(?![0-9])",
    # L0-R27: a phone number stands alone; one inside a longer run of letters and digits is an
    # identifier ("fd698243-0406-..." is a UUID, not "698243-0406").
    r"(?<![a-z0-9])\(?[0-9]{3}\)?[ .-]?[0-9]{3}[ .-][0-9]{4}(?![0-9])",
    # note headings
    r"chief[^a-z0-9]+complaint",
    r"history[^a-z0-9]+of[^a-z0-9]+present[^a-z0-9]+illness",
    r"assessment[^a-z0-9]+and[^a-z0-9]+plan" + _END,
))
_MARKS_CASED = tuple(re.compile(pattern) for pattern in (
    # an age with a sex letter: "58F", "58 F", "58/F", "8M" (a lone digit and a space is a
    # molar concentration, "2 M", and is not a mark)
    r"(?<![A-Za-z0-9.])(?:1[01][0-9]|120|[1-9][0-9])[ \t]?[/-]?[ \t]?[MF](?![A-Za-z0-9])",
    r"(?<![A-Za-z0-9.])[1-9][/-]?[MF](?![A-Za-z0-9])",
    # the sex letter first: "F/61"
    r"(?<![A-Za-z0-9])[MF][ \t]?/[ \t]?(?:1[01][0-9]|120|[1-9][0-9]?)(?![A-Za-z0-9.])",
    # an honorific before a name
    r"(?<![A-Za-z0-9])(?:Mr|Mrs|Ms|Mx|Miss|Dr)\.?\s+[A-Z]",
    # note headings written as abbreviations
    r"(?<![A-Za-z0-9])(?:HPI|A/P)(?![A-Za-z0-9])",
))


def _readable(text: str) -> str:
    """The text as a person reads it: compatibility forms, hidden marks and accents removed."""
    decomposed = unicodedata.normalize("NFKD", text)
    kept = "".join(character for character in decomposed
                   if unicodedata.category(character) not in {"Mn", "Me", "Cf"})
    return unicodedata.normalize("NFKC", kept.translate(_CONFUSABLE))


# L0-R27: an identifier in canonical UUID form is never clinical text. Its hex groups can look like a
# contact number ("fd698243-0406" reads "698243-0406") or an age with a sex letter ("-107F-"),
# so each one is set aside before the marks are read. Marks elsewhere in the text still count.
_UUID = re.compile(r"(?<![0-9a-z])[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(?![0-9a-z])",
                   re.IGNORECASE)


def carries_clinical_note_marks(text: str) -> bool:
    """Whether ``text`` carries a mark of a clinical note. Reads only; keeps nothing."""
    # Replaced by one letter, not removed, so text built around it keeps its shape: an e-mail address
    # whose part is a UUID still reads as an e-mail address (review 9).
    readable = _UUID.sub("x", _readable(text))
    folded = readable.casefold()
    return (any(mark.search(folded) for mark in _MARKS_FOLDED)
            or any(mark.search(readable) for mark in _MARKS_CASED))


def screen_text(value: str, field: str | None = None) -> str:
    """Return ``value`` unchanged, or refuse it when it carries a mark of a clinical note.

    ``field`` is the field's fixed name in the code, for the refusal. Call this
    before the text is stored, logged or echoed.
    """
    if isinstance(value, str) and carries_clinical_note_marks(value):
        try:
            clinical_note_gate()
        except ClinicalNoteRefused:
            raise ClinicalNoteRefused(field) from None
    return value


def screen_strings(value: Any, field: str | None = None, *, _depth: int = 0) -> Any:
    """Screen every string in a JSON-like value (keys included); return it unchanged.

    Bodies are bounded by their readers; the depth bound only stops a cycle.
    """
    if _depth > 64:
        return value
    if isinstance(value, str):
        screen_text(value, field)
    elif isinstance(value, dict):
        for key, item in value.items():
            screen_text(key, field) if isinstance(key, str) else None
            screen_strings(item, field, _depth=_depth + 1)
    elif isinstance(value, (list, tuple)):
        for item in value:
            screen_strings(item, field, _depth=_depth + 1)
    return value


def install_refusal_handler(app) -> None:
    """Answer a refusal raised anywhere in a service's routes with its typed 422."""
    from fastapi.responses import JSONResponse

    @app.exception_handler(ClinicalNoteRefused)
    async def clinical_note_refused(_request, error: ClinicalNoteRefused):
        return JSONResponse(error.payload(), status_code=CLINICAL_NOTE_REFUSAL_STATUS,
                            headers={"Cache-Control": "no-store"})
