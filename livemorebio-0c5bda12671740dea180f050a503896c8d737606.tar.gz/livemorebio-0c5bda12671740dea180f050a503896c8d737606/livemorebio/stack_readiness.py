"""Separate credential-free listener liveness from proved stack readiness."""
from __future__ import annotations

import http.client
import json
import socket
import time
from urllib.parse import urlsplit

from . import stack_client, stack_transport
from .registry import DataDirSecurityError
from .security import CredentialFileError
from .service_identity import IdentityError, IdentitySnapshot
from .service_identity_config import ServiceIdentityConfigurationInvalid


_SERVICE_NAMES = {"aegle": "Aegle", "life": "LIFE", "cendos": "Cendos"}
READINESS_ERRORS = (stack_transport.ServiceIdentityUnproven, IdentityError,
                    ServiceIdentityConfigurationInvalid, CredentialFileError, DataDirSecurityError)


class ServiceHealthUnavailable(RuntimeError):
    code = "SERVICE_HEALTH_UNAVAILABLE"
    endpoint_reachable = True

    def __init__(self) -> None:
        super().__init__("SERVICE_HEALTH_UNAVAILABLE: This endpoint proved this stack's service identity "
                         "but did not return valid health. Check the service logs and restart this stack.")


def listener_reachable(url: str, *, timeout: float = 0.2) -> bool:
    """Connect and close without HTTP, credentials, or claims about ownership."""
    try:
        target = urlsplit(url)
        if target.scheme not in {"http", "https"} or not target.hostname:
            return False
        port = target.port or (443 if target.scheme == "https" else 80)
        budget = stack_transport._Budget(time.monotonic() + timeout)
        family, kind, protocol, address = stack_transport._resolve(target.hostname, port, budget)
        with socket.socket(family, kind, protocol) as peer:
            budget.arm(peer)
            peer.connect(address)
        return True
    except (OSError, ValueError, stack_transport.ServiceIdentityUnproven):
        return False


def proved_health(role: str, url: str, *, timeout: float = 1.5,
                  startup_identity: IdentitySnapshot | None = None) -> dict | None:
    """One independently proved, bounded health GET; local trust never provisions."""
    role = role.lower()
    expected_service = _SERVICE_NAMES[role]
    identity = stack_client.operation_identity(role, url, startup_identity=startup_identity)
    try:
        response = stack_transport.request(url.rstrip("/") + "/health", identity=identity,
                                           timeout=timeout, max_response_bytes=65536)
    except stack_transport.ServiceIdentityUnproven as error:
        # Explicit false means the dial cannot reach its configured authority;
        # it is configuration evidence, not evidence of an absent listener.
        if getattr(error, "endpoint_reachable", None) is False:
            raise
        # A closed port is absent. A listener that cannot prove is a refusal,
        # never a reason for the launcher to start another service over it.
        if not getattr(error, "endpoint_reachable", False) and not listener_reachable(url):
            return None
        error.endpoint_reachable = True
        raise
    except ServiceIdentityConfigurationInvalid:
        raise
    except (OSError, ValueError, http.client.HTTPException):
        raise ServiceHealthUnavailable() from None
    try:
        payload = json.loads(response.body)
        if (response.status != 200 or not isinstance(payload, dict)
                or payload.get("service") != expected_service or payload.get("ok") is not True):
            raise ValueError("invalid service health")
    except (ValueError, UnicodeError, RecursionError):
        raise ServiceHealthUnavailable() from None
    return payload


def failed_status(error: Exception, url: str) -> dict:
    """Expose only local fixed causes, never a remote response or credential."""
    reachable = (False if isinstance(error, ServiceIdentityConfigurationInvalid)
                 else getattr(error, "endpoint_reachable", None))
    if reachable is None:
        reachable = listener_reachable(url)
    return {"reachable": bool(reachable), "ready": False, "healthy": False, "health": None,
            "reason_code": getattr(error, "code", "SERVICE_HEALTH_UNAVAILABLE")}


def service_status(role: str, url: str, *, timeout: float = 1.5,
                   startup_identity: IdentitySnapshot | None = None) -> dict:
    try:
        health = proved_health(role, url, timeout=timeout, startup_identity=startup_identity)
    except (*READINESS_ERRORS, ServiceHealthUnavailable) as error:
        return failed_status(error, url)
    ready = health is not None
    return {"reachable": ready, "ready": ready, "healthy": ready, "health": health,
            "reason_code": None if ready else "SERVICE_UNAVAILABLE"}
