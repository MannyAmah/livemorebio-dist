"""The label of the live twin's unsourced coupling, without importing any engine (L0-R15).

``metabolic_cardiac_hyperglycemia_to_ikr`` has no admitted source for its
magnitude, so every output whose value it changes carries this label. Kept
apart from the engines so that projections and views can label outputs without
loading a solver.
"""
from __future__ import annotations

HYPOTHESIS_UNSOURCED = "HYPOTHESIS_UNSOURCED"
METABOLIC_CARDIAC_COUPLING_ID = "metabolic_cardiac_hyperglycemia_to_ikr"


def coupling_label(*fields: str) -> dict:
    """The label an output carries when the coupling changes its value.

    ``fields`` names the values in that output which the coupling changes; the
    other values in the same output do not depend on it.
    """
    return {"coupling_id": METABOLIC_CARDIAC_COUPLING_ID, "coupling_claim_state": HYPOTHESIS_UNSOURCED,
            "coupled_fields": list(fields)}
