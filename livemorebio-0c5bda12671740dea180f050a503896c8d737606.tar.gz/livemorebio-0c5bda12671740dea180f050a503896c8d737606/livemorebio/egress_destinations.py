"""What a request to a third-party service may carry (L0-R16). Data only; the check is in ``egress.py``.

Every outbound request to a third-party service must match one route of its
destination below. A route fixes the method, the path, the query keys and the
JSON body shape. Its only variable parts are slots, written ``{name}``; a slot
holds an identifier that matches one of that destination's identifier grammars,
or a term of one of the product's local vocabularies. ``{a|b}`` admits either.
``{const:module:NAME}`` admits exactly that constant of the product's code (a
fixed request document). A route marked ``pinned`` admits only the exact URLs of
the product's pinned source catalogs.

Each grammar names its source. A grammar is the destination's own identifier
form, so it admits any value of that form: a short upper-case token matches the
gene-symbol grammar whether or not it names a gene. No grammar admits a space,
so no sentence of free text fits one.
"""
from __future__ import annotations

GRAMMARS: dict[str, dict[str, str]] = {
    "chembl_id": {
        "pattern": r"CHEMBL[0-9]{1,9}",
        "source": "https://registry.identifiers.org/registry/chembl.compound and "
                  "https://registry.identifiers.org/registry/chembl.target (pattern ^CHEMBL\\d+$)",
    },
    "ensembl_gene": {
        "pattern": r"ENSG[0-9]{11}",
        "source": "https://www.ensembl.org/info/genome/stable_ids/index.html (human gene: ENSG and 11 digits)",
    },
    "hgnc_symbol": {
        "pattern": r"[A-Z][A-Z0-9]{0,14}(?:-[A-Z0-9]{1,6})?",
        "source": "https://www.genenames.org/about/guidelines/ (approved symbols: upper-case Latin letters "
                  "and Arabic numerals, a hyphen in a few; the length bound is this product's)",
    },
    "hgnc_id": {
        "pattern": r"HGNC:[0-9]{1,6}",
        "source": "https://registry.identifiers.org/registry/hgnc (pattern ^((HGNC|hgnc):)?\\d{1,5}$)",
    },
    "uniprot_accession": {
        "pattern": r"[OPQ][0-9][A-Z0-9]{3}[0-9]|[A-NR-Z][0-9](?:[A-Z][A-Z0-9]{2}[0-9]){1,2}",
        "source": "https://www.uniprot.org/help/accession_numbers",
    },
    "pdb_id": {
        "pattern": r"[0-9][A-Za-z0-9]{3}",
        "source": "https://registry.identifiers.org/registry/pdb (pattern ^[0-9][A-Za-z0-9]{3}$)",
    },
    "reactome_stable_id": {
        "pattern": r"R-[A-Z]{3}-[0-9]{1,9}(?:\.[0-9]{1,3})?",
        "source": "https://registry.identifiers.org/registry/reactome (pattern ^(R-[A-Z]{3}-\\d+(-\\d+)?(\\.\\d+)?)$)",
    },
    "ncbi_taxon": {
        "pattern": r"[0-9]{1,7}",
        "source": "https://registry.identifiers.org/registry/taxonomy (pattern ^\\d+$)",
    },
    "dbsnp_rsid": {
        "pattern": r"rs[0-9]{1,10}",
        "source": "https://registry.identifiers.org/registry/dbsnp (pattern ^rs\\d+$)",
    },
    "doid_number": {
        "pattern": r"[0-9]{1,7}",
        "source": "https://registry.identifiers.org/registry/doid (pattern ^DOID:\\d+$); "
                  "DiseaseOntology.term sends the number part",
    },
    "doid_iri_quoted": {
        "pattern": r"http%3A%2F%2Fpurl\.obolibrary\.org%2Fobo%2FDOID_[0-9]{1,7}",
        "source": "OBO PURL http://purl.obolibrary.org/obo/DOID_<n> (https://obofoundry.org/id-policy.html), "
                  "percent-encoded twice as the OLS4 v2 entity path takes it (https://www.ebi.ac.uk/ols4/help)",
    },
    "orphacode": {
        "pattern": r"[0-9]{1,7}",
        "source": "https://registry.identifiers.org/registry/orphanet (pattern ^\\d+$)",
    },
    "opentargets_disease_id": {
        "pattern": r"(?:EFO|MONDO|Orphanet|DOID|HP|OTAR|GO|NCIT)_[0-9]{1,10}",
        "source": "https://platform-docs.opentargets.org/disease-or-phenotype (EFO-based ontology "
                  "identifiers written with an underscore)",
    },
    "opentargets_release": {
        "pattern": r"[0-9]{2}\.[0-9]{2}",
        "source": "https://platform-docs.opentargets.org/release-notes (releases YY.MM; the same check as "
                  "current_open_targets.build_current_seed)",
    },
    "opentargets_evidence_counts_document": {
        "pattern": (r"query DirectEvidenceCounts\(\$id: String!\) \{ disease\(efoId: \$id\) \{ "
                    r"t[0-9]{1,3}: evidences\(ensemblIds: \[\"ENSG[0-9]{11}\"\], enableIndirect: false, "
                    r"size: 1\) \{ count \}(?: t[0-9]{1,3}: evidences\(ensemblIds: \[\"ENSG[0-9]{11}\"\], "
                    r"enableIndirect: false, size: 1\) \{ count \}){0,199} \} \}"),
        "source": "the document current_open_targets.direct_associations builds; only Ensembl gene "
                  "identifiers (ensembl_gene) vary in it",
    },
    "kegg_entry": {
        "pattern": r"(?:(?:ds|dr|path|hsa):)?(?:H[0-9]{5}|D[0-9]{5}|hsa[0-9]{5}|[0-9]{1,9})",
        "source": "https://www.kegg.jp/kegg/rest/keggapi.html and https://registry.identifiers.org/registry/kegg "
                  "(disease H, drug D, human pathway hsa entries; human genes by NCBI Gene number)",
    },
    "kegg_hsa_gene": {
        "pattern": r"[0-9]{1,9}",
        "source": "https://www.kegg.jp/kegg/rest/keggapi.html (KEGG GENES human entries hsa:<NCBI Gene ID>)",
    },
    "api_data_gov_key": {
        "pattern": r"[A-Za-z0-9]{40}|DEMO_KEY",
        "source": "https://api.data.gov/docs/developer-manual/ (FoodData Central keys from "
                  "https://fdc.nal.usda.gov/api-key-signup): the operator's credential for that service",
    },
    "page_size": {
        "pattern": r"[0-9]{1,4}",
        "source": "a page size, row count or page index that the product's code sets (no identifier)",
    },
    "language_code": {
        "pattern": r"[a-z]{2}",
        "source": "ISO 639-1 two-letter language code, Orphadata's lang parameter (https://api.orphadata.com/)",
    },
    "nar_category": {
        "pattern": r"[0-9]{1,3}",
        "source": "NAR Database Summary Paper category numbers (https://www.oxfordjournals.org/nar/database/c/)",
    },
}

# Local vocabularies: closed sets of terms the product itself ships. ``egress.py``
# names the provider of each; a term matches case-insensitively, with runs of
# white space read as one space.
VOCABULARIES: dict[str, str] = {
    "compound_term": "drug and compound names the product ships: the reference seed's drugs "
                     "(build_seed.DRUGS and the knowledge base's drug records), the reference dynamics' "
                     "drugs and compounds, the drug-indication graph, the hepatic PK drugs, the curated "
                     "phytochemicals of engines/foods.py and the constituents of discovery/pipeline.py",
    "food_term": "food and plant names the product ships: engines/foods.py (PHYTOCHEMICALS, CURATED_MACROS), "
                 "the reference dynamics' compounds and the plants of discovery/pipeline.py",
    "reference_term": "the reference knowledge base's condition vocabulary (names, queries and search terms)",
    "organ_term": "the anatomy catalog's organ ids (anatomy/meshes.py CATALOG)",
    "reference_graph_term": "fixed graph schema terms and string properties of the reference graph built "
                            "from a fresh package KnowledgeBase; never the supplied export graph or "
                            "the mutable get_kb singleton",
    "pinned_model_asset": "the pinned model files of model_assets.py (Human-GEM and the cardiac CellML file)",
    "pinned_atlas_source": "the pinned BodyParts3D files of the anatomy atlas catalog (anatomy/atlas_reference.py)",
    "pinned_mesh_source": "the pinned HRA reference-organ GLB files and BodyParts3D files of anatomy/meshes.py",
    "pinned_population_source": "the pinned NHANES files of aegle/population_sources.py",
}

# Neo4j carries the product's reference graph, not arbitrary operator text. Its
# biomedical identifiers use the same sourced grammars as the HTTP destinations;
# its remaining strings must be terms of its shipped reference vocabulary. Credential,
# pagination and generic token grammars are deliberately not graph identifiers.
NEO4J_VALUE_SLOT = (
    "chembl_id|ensembl_gene|hgnc_symbol|hgnc_id|uniprot_accession|pdb_id|"
    "reactome_stable_id|dbsnp_rsid|opentargets_disease_id|"
    "reference_graph_term"
)

# Destinations. ``bases`` are URL prefixes; a route's ``path`` follows the base.
# ``configured_base`` names the function that returns an operator-approved base
# (licensed services), or ``None`` when that service is not configured.
DESTINATIONS: dict[str, dict] = {
    "chembl": {
        "service": "ChEMBL web services (EMBL-EBI)",
        "bases": ["https://www.ebi.ac.uk/chembl/api/data/"],
        "routes": [
            {"path": "status.json"},
            {"path": "target/{chembl_id}.json"},
            {"path": "molecule.json", "query": {"pref_name__iexact": "{compound_term}"}},
            {"path": "molecule/search.json", "query": {"q": "{compound_term}"}},
            {"path": "molecule/search", "query": {"q": "{compound_term}", "format": "json"}},
            {"path": "mechanism.json", "query": {"parent_molecule_chembl_id": "{chembl_id}"}},
            {"path": "mechanism.json", "query": {"molecule_chembl_id": "{chembl_id}"}},
            {"path": "activity.json", "query": {"molecule_chembl_id": "{chembl_id}",
                                                "standard_type__in": "IC50,Ki,Kd,EC50", "limit": "300"}},
        ],
    },
    "pubchem": {
        "service": "PubChem PUG REST (NCBI)",
        "bases": ["https://pubchem.ncbi.nlm.nih.gov/rest/pug/"],
        "routes": [
            {"path": "compound/name/{compound_term}/cids/JSON"},
            {"path": "compound/name/{compound_term}/property/MolecularFormula,MolecularWeight,IUPACName/JSON"},
            {"path": "compound/name/{compound_term}/property/"
                     "MolecularFormula,MolecularWeight,CanonicalSMILES,InChIKey/JSON"},
        ],
    },
    "opentargets": {
        "service": "Open Targets Platform GraphQL API",
        "bases": ["https://api.platform.opentargets.org/api/v4/graphql"],
        "routes": [
            {"path": ""},
            {"method": "POST", "path": "", "body": {
                "query": "{const:livemorebio.engines.disease_links:TARGET_SEARCH_QUERY}",
                "variables": {"q": "{hgnc_symbol}"}}},
            {"method": "POST", "path": "", "body": {
                "query": "{const:livemorebio.engines.disease_links:TARGET_DISEASES_QUERY}",
                "variables": {"id": "{ensembl_gene}", "n": "{page_size}"}}},
            {"method": "POST", "path": "", "body": {
                "query": "{const:livemorebio.life_system.reference.current_open_targets:VERSION_QUERY}",
                "variables": {}}},
            {"method": "POST", "path": "", "body": {
                "query": "{const:livemorebio.life_system.reference.current_open_targets:SEARCH_QUERY}",
                "variables": {"terms": ["{reference_term|compound_term}"], "entity": "disease"}}},
            {"method": "POST", "path": "", "body": {
                "query": "{const:livemorebio.life_system.reference.current_open_targets:SEARCH_QUERY}",
                "variables": {"terms": ["{reference_term|compound_term}"], "entity": "drug"}}},
            {"method": "POST", "path": "", "body": {
                "query": "{const:livemorebio.life_system.reference.current_open_targets:IDENTITY_QUERY}",
                "variables": {"id": "{opentargets_disease_id}"}}},
            {"method": "POST", "path": "", "body": {
                "query": "{const:livemorebio.life_system.reference.current_open_targets:ASSOCIATIONS_QUERY}",
                "variables": {"id": "{opentargets_disease_id}", "page": "{page_size}"}}},
            {"method": "POST", "path": "", "body": {
                "query": "{const:livemorebio.life_system.reference.current_open_targets:DRUG_QUERY}",
                "variables": {"id": "{chembl_id}"}}},
            {"method": "POST", "path": "", "body": {
                "query": "{opentargets_evidence_counts_document}",
                "variables": {"id": "{opentargets_disease_id}"}}},
        ],
    },
    "opentargets_ftp": {
        "service": "Open Targets release files (EMBL-EBI FTP over HTTPS)",
        "bases": ["https://ftp.ebi.ac.uk/pub/databases/opentargets/platform/"],
        "routes": [{"path": "{opentargets_release}/etc/config/pis_chembl.yaml"}],
    },
    "uniprot": {
        "service": "UniProt REST API",
        "bases": ["https://rest.uniprot.org/uniprotkb/"],
        "routes": [{"path": "{uniprot_accession}.json"}],
    },
    "rcsb": {
        "service": "RCSB PDB Data API",
        "bases": ["https://data.rcsb.org/rest/v1/core/"],
        "routes": [{"path": "entry/{pdb_id}"}],
    },
    "reactome": {
        "service": "Reactome Content Service",
        "bases": ["https://reactome.org/ContentService/"],
        "routes": [
            {"path": "data/database/version"},
            {"path": "data/pathways/top/{ncbi_taxon}"},
            {"path": "data/pathway/{reactome_stable_id}/containedEvents"},
            {"path": "data/diseases"},
            {"path": "search/query", "query": {"query": "{reference_term|hgnc_symbol}", "species": "Homo sapiens",
                                               "types": ["Protein", "Pathway,Reaction"], "cluster": "true"}},
        ],
    },
    "gwas_catalog": {
        "service": "GWAS Catalog REST API (EMBL-EBI)",
        "bases": ["https://www.ebi.ac.uk/gwas/rest/api/"],
        "routes": [
            {"path": "studies", "query": {"size": "{page_size}"}},
            {"path": "singleNucleotidePolymorphisms/{dbsnp_rsid}/associations", "query": {"size": "{page_size}"}},
        ],
    },
    "ols": {
        "service": "EBI Ontology Lookup Service (OLS4)",
        "bases": ["https://www.ebi.ac.uk/ols4/api/"],
        "routes": [
            {"path": "ontologies"},
            {"path": "search", "query": {"q": "{reference_term|doid_number}", "ontology": "doid",
                                         "rows": "{page_size}"}},
            {"path": "v2/ontologies/doid/entities/{doid_iri_quoted}"},
        ],
    },
    "hgnc": {
        "service": "HGNC REST",
        "bases": ["https://rest.genenames.org/"],
        "routes": [
            {"path": "fetch/ensembl_gene_id/{ensembl_gene}"},
            {"path": "fetch/symbol/{hgnc_symbol}"},
            {"path": "fetch/hgnc_id/{hgnc_id}"},
        ],
    },
    "hra_api": {
        "service": "HuBMAP Human Reference Atlas API",
        "bases": ["https://apps.humanatlas.io/api/"],
        "routes": [
            {"path": ""},
            {"path": "v1/reference-organs"},
            {"path": "v1/asctb", "query": {"organ": "{organ_term}"}},
        ],
    },
    "hca_azul": {
        "service": "Human Cell Atlas Azul",
        "bases": ["https://service.azul.data.humancellatlas.org/"],
        "routes": [
            {"path": "index/catalogs"},
            {"path": "index/projects", "query": {"size": "{page_size}"}},
        ],
    },
    "protein_atlas": {
        "service": "Human Protein Atlas",
        "bases": ["https://www.proteinatlas.org/"],
        "routes": [{"path": "{ensembl_gene}.json"}],
    },
    "orphadata": {
        "service": "Orphadata API",
        "bases": ["https://api.orphadata.com/"],
        "routes": [{"path": "rd-cross-referencing/orphacodes/{orphacode}", "query": {"lang": "{language_code}"}}],
    },
    "usda_fdc": {
        "service": "USDA FoodData Central (credential-gated)",
        "bases": ["https://api.nal.usda.gov/fdc/v1/"],
        "routes": [
            {"path": "foods/search", "query": {"query": "{food_term}", "pageSize": "{page_size}",
                                               "api_key": "{api_data_gov_key}"}},
            {"path": "foods/search", "query": {"query": "{food_term}", "pageSize": "{page_size}",
                                               "dataType": "Foundation,SR Legacy", "api_key": "{api_data_gov_key}"}},
        ],
    },
    "kegg_licensed": {
        "service": "KEGG, through an operator-approved licensed endpoint only",
        "configured_base": "livemorebio.life_system.reference.sources.entitlements:approved_kegg_base",
        "bases": [],
        "routes": [
            {"path": "list/disease"},
            {"path": "list/pathway/hsa"},
            {"path": "get/{kegg_entry}"},
            {"path": "link/pathway/hsa:{kegg_hsa_gene}"},
            {"path": "find/genes/{hgnc_symbol}"},
            {"path": "find/drug/{compound_term}"},
            {"path": "find/disease/{reference_term}"},
        ],
    },
    "genecards_licensed": {
        "service": "GeneCards, through an operator-configured licensed endpoint only",
        "configured_base": "livemorebio.life_system.reference.sources.entitlements:approved_genecards_base",
        "bases": [],
        "routes": [{"path": "genes/{hgnc_symbol}"}],
    },
    "model_files": {
        "service": "pinned model files (GitHub raw content, Physiome Model Repository)",
        "bases": ["https://raw.githubusercontent.com/", "https://models.physiomeproject.org/"],
        "routes": [{"pinned": "pinned_model_asset"}],
    },
    "bodyparts3d": {
        "service": "pinned BodyParts3D archive files (DBCLS)",
        "bases": ["https://dbarchive.biosciencedbc.jp/"],
        "routes": [{"pinned": "pinned_atlas_source"}, {"pinned": "pinned_mesh_source"}],
    },
    "hra_cdn": {
        "service": "pinned HRA reference-organ files",
        "bases": ["https://cdn.humanatlas.io/"],
        "routes": [{"pinned": "pinned_mesh_source"}],
    },
    "nhanes": {
        "service": "pinned NHANES public files (CDC NCHS)",
        "bases": ["https://wwwn.cdc.gov/"],
        "routes": [{"pinned": "pinned_population_source"}],
    },
    "nar_database": {
        "service": "NAR Database Summary Paper Category List (the scientific source catalog refresh tool)",
        "bases": ["https://www.oxfordjournals.org/nar/database/"],
        "routes": [{"path": "a/"}, {"path": "cat/{nar_category}"}],
    },
    "elixir": {
        "service": "ELIXIR Core Data Resources index (the scientific source catalog refresh tool)",
        "bases": ["https://elixir-europe.org/"],
        "routes": [{"path": "platforms/data/core-data-resources"}],
    },
}
