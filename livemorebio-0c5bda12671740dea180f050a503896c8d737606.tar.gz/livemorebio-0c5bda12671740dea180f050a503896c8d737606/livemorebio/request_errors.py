"""Private HTTP failures, caught before the ASGI server can log their values."""
from __future__ import annotations

import logging
from contextvars import ContextVar
from typing import TYPE_CHECKING
from uuid import uuid4

from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Message, Receive, Scope, Send

if TYPE_CHECKING:
    from .aegle.registry_bootstrap import RegistryBootstrapError


# Model/compiler dependencies may attach root handlers to temporary streams.
# Uvicorn configures its service error handler independently; use that boundary
# so a closed third-party capture stream cannot print an exception context via
# logging.handleError while we are handling a private route failure.
logger = logging.getLogger("uvicorn.error.livemore")
_REQUEST_ID = "_livemore_private_request_id"
_REQUEST_SCOPE: ContextVar[Scope | None] = ContextVar("livemore_private_request_scope", default=None)


def registry_bootstrap_error(error: RegistryBootstrapError, *,
                             headers: dict[str, str] | None = None) -> JSONResponse:
    """Keep storage authority failures typed, including through ValueError catches."""
    return JSONResponse({"code": error.code, "error": str(error)}, status_code=503,
                        headers={"Cache-Control": "no-store", **(headers or {})})


def _request_id(scope: Scope) -> str:
    if _REQUEST_ID not in scope:
        scope[_REQUEST_ID] = uuid4().hex
    return scope[_REQUEST_ID]


def log_private_failure(exception_type: str, request_id: str | None = None,
                        *, scope: Scope | None = None) -> str:
    """Call outside except blocks: a failed logging sink must have no private context."""
    if scope is None:
        scope = _REQUEST_SCOPE.get()
    scope = scope if scope is not None else {}
    request_id = request_id if request_id is not None else _request_id(scope)
    scope[_REQUEST_ID] = request_id
    route = getattr(scope.get("route"), "path", "<unmatched>")
    try:
        logger.error(
            "Unhandled request failure type=%s method=%s route=%s request_id=%s",
            exception_type, scope.get("method", "<unavailable>"), route, request_id,
            exc_info=False, stack_info=False,
        )
    except Exception:
        # A broken diagnostic sink must not turn a safe refusal into another
        # unhandled error. No private exception object reaches this function.
        pass
    return request_id


def private_request_error(request: Request, exception_type: str) -> JSONResponse:
    """Return a fixed failure after its originating except block has exited."""
    request_id = log_private_failure(exception_type, scope=request.scope)
    return JSONResponse(
        {"code": "INTERNAL_ERROR", "error": "The request could not be completed.",
         "request_id": request_id},
        status_code=500,
        headers={"Cache-Control": "no-store", "X-Request-ID": request_id},
    )


class PrivateRequestErrors:
    """Consume route failures inside Starlette's re-raising error middleware.

    An Exception handler alone still allows ServerErrorMiddleware to re-raise to
    uvicorn, which logs the private exception text a second time.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        response_started = False
        response_finished = False

        async def private_send(message: Message) -> None:
            nonlocal response_started, response_finished
            if message["type"] == "http.response.start":
                response_started = True
                # A streaming response may fail after its headers are sent.
                # Give it a correlation ID before that irreversible point.
                headers = list(message.get("headers", []))
                existing = next((value for name, value in headers
                                 if name.lower() == b"x-request-id"), None)
                if existing is None:
                    headers.append((b"x-request-id", _request_id(scope).encode("ascii")))
                else:
                    # Existing typed responses own their diagnostic ID. Do not
                    # change their established response/error contract.
                    scope[_REQUEST_ID] = existing.decode("ascii", errors="replace")
                message = {**message, "headers": headers}
            elif message["type"] == "http.response.body" and not message.get("more_body", False):
                response_finished = True
            await send(message)

        context = _REQUEST_SCOPE.set(scope)
        try:
            exception_type = None
            try:
                await self.app(scope, receive, private_send)
            except Exception as error:
                exception_type = type(error).__name__
            if exception_type is not None:
                response = private_request_error(Request(scope), exception_type)
                if not response_started:
                    await response(scope, receive, send)
                elif not response_finished:
                    # HTTP cannot replace already transmitted headers/content.
                    try:
                        await send({"type": "http.response.body", "body": b"", "more_body": False})
                    except Exception:
                        # A disconnected client cannot receive termination; the
                        # originating failure has already been logged privately.
                        pass
        finally:
            _REQUEST_SCOPE.reset(context)


# L0-R16: a refusal never echoes the value it rejected. FastAPI's default answer
# to a parameter that fails validation repeats the rejected input; each service
# installs this handler instead.
_VALIDATION_PLACES = frozenset({"query", "path", "header", "cookie"})
VALIDATION_MESSAGE = "the value is not valid for this parameter; it is not repeated here"
_ERROR_TYPE = __import__("re").compile(r"[a-z][a-z_]{0,47}")  # pydantic's fixed error-type names


def validation_error_payload(errors: list[dict]) -> dict:
    """The refusal of a request that failed validation: where and what kind, never the value.

    ``loc`` keeps the place and, for a declared query, path, header or cookie
    parameter, its name from the route. A body location is reported as ``body``
    alone, because a body's keys are the caller's. ``type`` is pydantic's fixed
    error type. The input, its context and pydantic's message are dropped.
    """
    detail = []
    for error in errors:
        location = tuple(error.get("loc") or ())
        place = location[0] if location and location[0] in _VALIDATION_PLACES | {"body"} else "request"
        loc = [place]
        if place in _VALIDATION_PLACES and len(location) > 1 and isinstance(location[1], str):
            loc.append(location[1])
        kind = error.get("type")
        detail.append({"type": kind if isinstance(kind, str) and _ERROR_TYPE.fullmatch(kind)
                       else "value_error", "loc": loc, "msg": VALIDATION_MESSAGE})
    return {"code": "REQUEST_VALIDATION_FAILED", "detail": detail}


def install_validation_error_handler(app) -> None:
    """Answer a request that fails parameter validation without echoing the rejected value."""
    from fastapi.exceptions import RequestValidationError

    @app.exception_handler(RequestValidationError)
    async def request_validation_failed(_request, error: RequestValidationError):
        return JSONResponse(validation_error_payload(list(error.errors())), status_code=422,
                            headers={"Cache-Control": "no-store"})
