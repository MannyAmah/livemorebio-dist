"""Local identity admission and response compatibility for first-party clients."""
from __future__ import annotations

from email.message import Message
from collections.abc import Mapping
import io
import os
from typing import TYPE_CHECKING
from urllib.response import addinfourl

from . import stack_transport
from .service_identity import IdentityError, IdentitySnapshot, service_identity_key
from .service_identity_config import expected_authority

if TYPE_CHECKING:
    from fastapi import FastAPI


def operation_identity(role: str, dial_url: str, *, startup_identity: IdentitySnapshot | None = None) -> IdentitySnapshot:
    """Freeze local trust once; discovery and HTTP headers supply no trust input."""
    try:
        key = startup_identity.key if startup_identity is not None else service_identity_key(create=False)
    except IdentityError as error:
        if error.code != "SERVICE_IDENTITY_UNPROVEN":
            raise
        raise stack_transport.ServiceIdentityUnproven() from None
    if key is None:
        raise stack_transport.ServiceIdentityUnproven()
    authority = expected_authority(dial_url, os.environ.get(f"LIVEMORE_{role.upper()}_IDENTITY_AUTHORITY"))
    return IdentitySnapshot(key, role, authority)


def startup_identity(app: FastAPI) -> IdentitySnapshot:
    """Peer sends use the identity actually loaded by this service's startup."""
    state = app.state.stack_proof
    if state is None:
        raise stack_transport.ServiceIdentityUnproven()
    return state.snapshot


def request_response(url: str, *, identity: IdentitySnapshot, method: str = "GET",
                     headers: Mapping[str, str] | None = None, body: bytes | None = None,
                     timeout: float = 20, max_response_bytes: int | None = 8_388_608,
                     response_limits: Mapping[int, int] | None = None) -> addinfourl:
    """Adapt a fully read, closed proved request to the clients' existing parser."""
    result = stack_transport.request(url, identity=identity, method=method, headers=headers,
        body=body, timeout=timeout, max_response_bytes=max_response_bytes,
        response_limits=response_limits)
    headers = Message()
    for name, value in result.headers:
        headers[name] = value
    response = addinfourl(io.BytesIO(result.body), headers, url, result.status)
    response.msg = result.reason
    return response


def failure_response(error: Exception) -> tuple[int, Message] | None:
    """Retain admitted response metadata when its body could not be read."""
    result = getattr(error, "stack_response", None)
    if result is None:
        return None
    headers = Message()
    for name, value in result.headers:
        headers[name] = value
    return result.status, headers
