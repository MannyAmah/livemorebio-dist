"""Bounded service proof route with a startup-pinned identity generation.

The route authenticates possession of the stack key for its fixed role and bind
origin. It does not encrypt traffic or authenticate a browser's later socket.
"""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from dataclasses import dataclass
import os
from posixpath import normpath
import secrets
import threading
import time
from urllib.parse import unquote

from fastapi import FastAPI, Request
from fastapi.responses import Response
from starlette.requests import ClientDisconnect

from .service_identity import IdentityError, IdentitySnapshot, proof_response, service_identity_key
from .service_identity_config import (CanonicalOrigin, ServiceIdentityConfigurationInvalid, expected_authority,
                                      literal_authority_address, service_authority)


PROOF_PATH = "/api/stack/prove"
BODY_DEADLINE_SECONDS = 2.0
# Covers the conservative 256-session producer ceiling plus source fetch/renew
# and a declared 10/s serial notebook allowance. On-demand callers have no code
# rate/concurrency ceiling; the dispatch record retains that N5c-8 qualification.
PROOF_RATE = 32768
PROOF_BURST = 2 * PROOF_RATE
PROOF_MAX_INFLIGHT = 4096
_ZERO_PROOF = bytes(96)


class ProofLimiter:
    """Constant-sized process quota, shared by all addresses and nonces."""

    def __init__(self, *, rate: int = PROOF_RATE, burst: int = PROOF_BURST,
                 maximum_inflight: int = PROOF_MAX_INFLIGHT) -> None:
        self.rate, self.burst, self.maximum_inflight = rate, burst, maximum_inflight
        self.tokens = float(burst)
        self.updated = time.monotonic()
        self.inflight = 0
        self._lock = threading.Lock()

    def enter(self) -> bool:
        with self._lock:
            now = time.monotonic()
            self.tokens = min(self.burst, self.tokens + max(0., now - self.updated) * self.rate)
            self.updated = now
            if self.tokens < 1 or self.inflight >= self.maximum_inflight:
                return False
            self.tokens -= 1
            self.inflight += 1
            return True

    def leave(self) -> None:
        with self._lock:
            self.inflight -= 1


# These three fixed entries never grow with requests, clients, or app factories.
_SERVICE_LIMITERS = {role: ProofLimiter() for role in ("aegle", "life", "cendos")}


@dataclass(frozen=True)
class ServiceProofState:
    snapshot: IdentitySnapshot
    instance: bytes
    limiter: ProofLimiter
    # The published authority's port, pinned only by an actual bind: the console
    # cookie is named by it. Technical fixtures leave it unset (their listener).
    authority_port: int | None = None


def _load_key() -> bytes:
    key = service_identity_key(create=False)
    if key is None:
        raise IdentityError("service startup requires an existing service identity key; restart through the updated launcher")
    return key


def configure_bind_identity(app: FastAPI, host: str, port: int) -> None:
    """Called only where the actual uvicorn bind is known, before startup."""
    authority = service_authority(host, port, os.environ.get("LIVEMORE_SERVICE_IDENTITY_AUTHORITY"))
    role = app.state.stack_proof_role
    validate_peer_authorities(role)
    snapshot = IdentitySnapshot(_load_key(), role, authority)
    app.state.stack_proof = ServiceProofState(snapshot, secrets.token_bytes(32), _SERVICE_LIMITERS[role],
                                              CanonicalOrigin.parse(authority).port)


def validate_peer_authorities(role: str) -> None:
    """Admit each possible peer audience locally before opening the service bind."""
    from . import registry

    peers = {"life": ("aegle",), "aegle": ("life", "cendos", "aegle"), "cendos": ("aegle",)}
    defaults = {"aegle": ("Aegle", 8850), "life": ("LIFE", 8851), "cendos": ("Cendos", 8852)}
    for peer in peers[role]:
        name, port = defaults[peer]
        configured = os.environ.get(f"LIVEMORE_{peer.upper()}_URL", "").strip()
        native = f"http://127.0.0.1:{port}"
        # Aegle's health fan-out uses native defaults, while forwarders also
        # consult discovery. Validate both paths without trusting either as identity.
        discovered = (registry.url_of(name) if not configured and not (role == peer == "aegle") else None)
        bases = [configured or discovered or native]
        if role == "aegle":
            bases.append(configured or native)
        for base in bases:
            authority = expected_authority(base, os.environ.get(f"LIVEMORE_{peer.upper()}_IDENTITY_AUTHORITY"))
            literal_authority_address(base, authority, role=peer)


def configure_test_identity(app: FastAPI, snapshot: IdentitySnapshot) -> None:
    """Explicit no-listener injection for technical ASGI fixtures only.

    There is no environment switch or production default for a TestClient origin.
    The fixture must supply all trust inputs and the app's installed fixed role.
    """
    if snapshot.role != app.state.stack_proof_role:
        raise ServiceIdentityConfigurationInvalid("The technical snapshot differs from the app's fixed role.")
    app.state.stack_proof = ServiceProofState(snapshot, secrets.token_bytes(32), ProofLimiter())


def proof_refusal(status: int) -> Response:
    return Response(_ZERO_PROOF, status_code=status, media_type="application/octet-stream", headers={
        "Cache-Control": "no-store", "Referrer-Policy": "no-referrer", "Connection": "close",
    })


def is_proof_target(scope: dict) -> bool:
    """Recognize aliases for refusal, never for authentication exemption."""
    return normpath(unquote(scope.get("path", ""))).rstrip("/").endswith(PROOF_PATH)


def exact_proof_target(scope: dict) -> bool:
    return (scope.get("method") == "POST" and not scope.get("root_path")
            and scope.get("path") == PROOF_PATH and scope.get("raw_path") == PROOF_PATH.encode("ascii")
            and not scope.get("query_string"))


def _header_status(request: Request) -> tuple[int | None, int | None]:
    headers = request.scope.get("headers", [])
    if len(headers) > 32 or sum(len(name) + len(value) for name, value in headers) > 8192:
        return 413, None
    seen: dict[bytes, bytes] = {}
    for name, value in headers:
        name = name.lower()
        if name in seen:
            return 400, None
        seen[name] = value
    if seen.get(b"content-type") != b"application/octet-stream" or b"content-encoding" in seen:
        return 415, None
    transfer = seen.get(b"transfer-encoding")
    if (b"trailer" in seen or (transfer is not None
            and (transfer != b"chunked" or b"content-length" in seen))):
        return 400, None
    # ASGI owns chunk decoding. The same streamed count bounds both admitted
    # chunked requests and requests with no declared length.
    length = seen.get(b"content-length")
    if length is None:
        return None, None
    if not length or len(length) > 10 or any(value < 48 or value > 57 for value in length):
        return 400, None
    count = int(length)
    if count > 32:
        return 413, None
    return None, count


async def _prove(request: Request) -> Response:
    state: ServiceProofState | None = request.app.state.stack_proof
    if state is None:
        return proof_refusal(503)
    if not state.limiter.enter():
        return proof_refusal(429)
    try:
        status, declared_length = _header_status(request)
        if status is not None:
            return proof_refusal(status)
        nonce = bytearray()
        try:
            async with asyncio.timeout(BODY_DEADLINE_SECONDS):
                async for chunk in request.stream():
                    # Test the chunk before extending; no overlong nonce is retained.
                    if len(chunk) > 32 - len(nonce):
                        return proof_refusal(413)
                    nonce.extend(chunk)
        except TimeoutError:
            return proof_refusal(503)
        except ClientDisconnect:
            return proof_refusal(400)
        if len(nonce) != 32 or (declared_length is not None and declared_length != len(nonce)):
            return proof_refusal(400)
        try:
            body = proof_response(state.snapshot, bytes(nonce), state.instance, secrets.token_bytes(32))
        except Exception:
            # Randomness or proof generation failure must never emit diagnostics.
            return proof_refusal(503)
        return Response(body, media_type="application/octet-stream", headers={
            "Cache-Control": "no-store", "Referrer-Policy": "no-referrer",
        })
    finally:
        state.limiter.leave()


def install_stack_proof(app: FastAPI, role: str):
    """Install the shared route and require explicit startup bind admission."""
    if role not in _SERVICE_LIMITERS:
        raise ServiceIdentityConfigurationInvalid("The app must install one fixed service role.")
    app.state.stack_proof_role = role
    app.state.stack_proof = None
    original_lifespan = app.router.lifespan_context

    @asynccontextmanager
    async def checked_lifespan(application):
        if application.state.stack_proof is None:
            # Preserve missing/invalid-key refusal even for an unconfigured ASGI
            # embedding, but never infer a listener from a request or a default.
            _load_key()
            raise ServiceIdentityConfigurationInvalid(
                "Service startup needs an admitted actual bind; launch through the service main function.")
        async with original_lifespan(application) as state:
            yield state

    app.router.lifespan_context = checked_lifespan
    app.add_api_route(PROOF_PATH, _prove, methods=["POST"], include_in_schema=False)
    return next(route for route in app.routes if getattr(route, "endpoint", None) is _prove)
