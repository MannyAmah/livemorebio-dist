"""Ed25519 issuer signatures for externally verifiable evidence exports.

The public key carried in a manifest is discovery metadata, not a trust anchor.
Recipients must obtain the issuer public key through an authenticated out-of-band
channel and pass it to :func:`verify_signed_export`.
"""
from __future__ import annotations

import base64
import binascii
import errno
import hashlib
import json
import os
import stat
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

from .canonical import canonical_json_bytes, content_hash, sha256_hex
from .errors import IntegrityError, SigningConfigurationError, SigningIdentityUninitializedError


SIGNED_ARTIFACT_NAMES = (
    "evidence.json",
    "fhir-draft.json",
    "measurements.csv",
    "report.md",
)
TRUST_NOTICE = (
    "Issuer authenticity requires an out-of-band trusted Ed25519 public key; "
    "the public key embedded in this manifest is informational only."
)
_PRIVATE_KEY_ENV = "LIVEMORE_EVIDENCE_SIGNING_KEY"
_PRIVATE_KEY_FILE_ENV = "LIVEMORE_EVIDENCE_SIGNING_KEY_FILE"
_KEY_ID_ENV = "LIVEMORE_EVIDENCE_SIGNING_KEY_ID"
_SIGNING_PROFILE_SCHEMA_VERSION = "livemore.evidence-signing-profile.v1"


def _production_environment() -> bool:
    return os.environ.get("LIVEMORE_ENVIRONMENT", "").strip().lower() in {
        "prod",
        "production",
    }


def _raw_public_key(key: Ed25519PublicKey) -> bytes:
    return key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )


def _fingerprint(public_bytes: bytes) -> str:
    return "sha256:" + hashlib.sha256(public_bytes).hexdigest()


def _decode_base64(value: str, field_name: str) -> bytes:
    try:
        return base64.b64decode(value.strip(), validate=True)
    except (binascii.Error, ValueError) as error:
        raise SigningConfigurationError(f"{field_name} must be canonical base64") from error


def _load_private_key_bytes(data: bytes) -> Ed25519PrivateKey:
    stripped = data.strip()
    if stripped.startswith(b"-----BEGIN"):
        try:
            loaded = serialization.load_pem_private_key(stripped, password=None)
        except (TypeError, ValueError) as error:
            raise SigningConfigurationError("evidence signing private-key PEM is invalid") from error
        if not isinstance(loaded, Ed25519PrivateKey):
            raise SigningConfigurationError("evidence signing key must be Ed25519")
        return loaded
    if len(data) != 32:
        raise SigningConfigurationError("raw Ed25519 private key must contain exactly 32 bytes")
    try:
        return Ed25519PrivateKey.from_private_bytes(data)
    except ValueError as error:
        raise SigningConfigurationError("evidence signing private key is invalid") from error


def _read_private_key(path: Path, *, production: bool | None = None) -> Ed25519PrivateKey:
    flags = os.O_RDONLY
    flags |= getattr(os, "O_CLOEXEC", 0)
    flags |= getattr(os, "O_NONBLOCK", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    descriptor: int | None = None
    try:
        descriptor = os.open(path, flags)
        file_status = os.fstat(descriptor)
        if not stat.S_ISREG(file_status.st_mode):
            raise SigningConfigurationError(
                "evidence signing key file must be a regular file"
            )
        enforce_private_permissions = (
            _production_environment() if production is None else production
        )
        if enforce_private_permissions and file_status.st_mode & 0o077:
            raise SigningConfigurationError(
                "production evidence signing key file permissions must not grant "
                "group or world access"
            )
        key_file = os.fdopen(descriptor, "rb", closefd=True)
        descriptor = None
        with key_file:
            data = key_file.read()
    except SigningConfigurationError:
        raise
    except OSError as error:
        raise SigningConfigurationError("evidence signing key file is unavailable") from error
    finally:
        if descriptor is not None:
            os.close(descriptor)
    return _load_private_key_bytes(data)


def _held_export_count(export_root: Path) -> int:
    """Count published manifests without following artifact-tree symlinks."""
    directory_flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
    try:
        root_descriptor = os.open(export_root, directory_flags)
    except FileNotFoundError:
        return 0
    try:
        count = 0
        with os.scandir(root_descriptor) as entries:
            for entry in entries:
                if entry.name.startswith(".") or not entry.is_dir(follow_symlinks=False):
                    continue
                directory_descriptor = None
                manifest_descriptor = None
                try:
                    directory_descriptor = os.open(entry.name, directory_flags,
                                                   dir_fd=root_descriptor)
                    manifest_descriptor = os.open(
                        "manifest.json", os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC,
                        dir_fd=directory_descriptor,
                    )
                    if stat.S_ISREG(os.fstat(manifest_descriptor).st_mode):
                        count += 1
                except OSError as error:
                    if error.errno not in {errno.ENOENT, errno.ENOTDIR, errno.ELOOP}:
                        raise
                finally:
                    if manifest_descriptor is not None:
                        os.close(manifest_descriptor)
                    if directory_descriptor is not None:
                        os.close(directory_descriptor)
        return count
    finally:
        os.close(root_descriptor)


def _load_or_create_local_private_key(
    path: Path, *, export_root: Path | None = None,
) -> Ed25519PrivateKey:
    try:
        return _read_private_key(path, production=False)
    except SigningConfigurationError as read_error:
        try:
            path.lstat()
        except FileNotFoundError:
            pass
        except OSError:
            raise read_error
        else:
            # Another worker may publish the key between the failed open and
            # this existence check. Re-read instead of surfacing the stale
            # FileNotFoundError from the first attempt.
            return _read_private_key(path, production=False)
    from .. import registry

    if export_root is not None:
        from .store import EvidenceStore

        database = os.environ.get("LIVEMORE_EVIDENCE_DB", str(Path(registry.REG_DIR) / "evidence.sqlite"))
        try:
            export_count = EvidenceStore.recorded_export_count(database) + _held_export_count(export_root)
        except (IntegrityError, OSError) as error:
            raise SigningConfigurationError("evidence export inventory is unavailable") from error
        if export_count:
            # An init/first-export contender may have published while the
            # read-only inventory was being counted. Reuse its winner.
            try:
                return _read_private_key(path, production=False)
            except SigningConfigurationError as error:
                raise SigningIdentityUninitializedError() from error

    if registry.is_stack_secret_directory(path.parent):
        directory_status = registry.ensure_data_dir(str(path.parent))
        registry.require_secret_creation(directory_status)
    else:
        try:
            path.parent.mkdir(parents=True, exist_ok=False, mode=0o700)
        except FileExistsError:
            if not path.parent.is_dir():
                raise SigningConfigurationError(
                    "evidence signing key parent exists but is not a directory"
                )
    generated = Ed25519PrivateKey.generate()
    raw = generated.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    temporary_descriptor: int | None = None
    temporary_path: Path | None = None
    try:
        temporary_descriptor, raw_temporary_path = tempfile.mkstemp(
            prefix=f".{path.name}.",
            dir=str(path.parent),
        )
        temporary_path = Path(raw_temporary_path)
        os.fchmod(temporary_descriptor, 0o600)
        os.write(temporary_descriptor, raw)
        os.fsync(temporary_descriptor)
        os.close(temporary_descriptor)
        temporary_descriptor = None
        try:
            # A hard-link publishes a fully written key without ever exposing a
            # partial final file, and fails atomically when another process won.
            os.link(temporary_path, path)
        except FileExistsError:
            return _read_private_key(path, production=False)
    except OSError as error:
        raise SigningConfigurationError("cannot create local evidence signing key") from error
    finally:
        if temporary_descriptor is not None:
            os.close(temporary_descriptor)
        if temporary_path is not None:
            try:
                temporary_path.unlink()
            except FileNotFoundError:
                pass
    return generated


def _absolute_without_resolving_symlinks(value: str | Path) -> Path:
    return Path(os.path.abspath(os.fspath(Path(value).expanduser())))


def _assert_key_outside_export_root(key_path: Path, export_root: Path) -> None:
    try:
        try:
            key_status = key_path.lstat()
        except FileNotFoundError:
            pass
        else:
            # Refuse a final symlink before resolution can inspect its target
            # in another stack. The eventual key reader also uses no-follow.
            if stat.S_ISLNK(key_status.st_mode):
                raise SigningConfigurationError("evidence signing key file is unavailable")
        resolved_key_path = key_path.resolve(strict=False)
    except (OSError, RuntimeError) as error:
        raise SigningConfigurationError("evidence signing key file is unavailable") from error
    if (
        key_path == export_root
        or export_root in key_path.parents
        or resolved_key_path == export_root
        or export_root in resolved_key_path.parents
    ):
        raise SigningConfigurationError(
            "evidence signing key must be outside the export artifact directory"
        )


@dataclass(frozen=True)
class IssuerSigner:
    """An Ed25519 signer plus non-secret issuer metadata."""

    private_key: Ed25519PrivateKey
    key_id: str
    public_key_bytes: bytes
    public_key_fingerprint: str
    key_path: Path | None = None

    @classmethod
    def load(cls, export_root: str | Path, *, create: bool = True) -> "IssuerSigner":
        root = Path(export_root).expanduser().resolve()
        configured = os.environ.get(_PRIVATE_KEY_ENV, "").strip()
        configured_file = os.environ.get(_PRIVATE_KEY_FILE_ENV, "").strip()
        production = _production_environment()
        key_path: Path | None = None

        if configured:
            private_key = _load_private_key_bytes(
                _decode_base64(configured, _PRIVATE_KEY_ENV)
            )
        elif configured_file:
            key_path = _absolute_without_resolving_symlinks(configured_file)
            _assert_key_outside_export_root(key_path, root)
            if production or not create:
                private_key = _read_private_key(key_path, production=production)
            else:
                private_key = _load_or_create_local_private_key(key_path)
        elif production:
            raise SigningConfigurationError(
                "production evidence export requires LIVEMORE_EVIDENCE_SIGNING_KEY "
                "or LIVEMORE_EVIDENCE_SIGNING_KEY_FILE"
            )
        else:
            # Each unconfigured local stack owns its issuer under REG_DIR.
            # The default stack keeps its existing file and identity. Missing
            # keys with recorded or held exports require deliberate offline init.
            from .. import registry

            key_path = _absolute_without_resolving_symlinks(
                Path(registry.REG_DIR) / "evidence-signing-ed25519.key"
            )
            _assert_key_outside_export_root(key_path, root)

            # Admit the actual parent before even an existing key is read.
            registry.ensure_data_dir(str(key_path.parent))
            if create:
                private_key = _load_or_create_local_private_key(key_path, export_root=root)
            else:
                private_key = _read_private_key(key_path, production=False)

        return cls._from_private_key(private_key, key_path)

    @classmethod
    def _from_private_key(cls, private_key: Ed25519PrivateKey, key_path: Path | None) -> "IssuerSigner":
        public_bytes = _raw_public_key(private_key.public_key())
        fingerprint = _fingerprint(public_bytes)
        key_id = os.environ.get(_KEY_ID_ENV, "").strip() or (
            "ed25519-" + fingerprint.removeprefix("sha256:")[:16]
        )
        if any(character in key_id for character in "\r\n\x00"):
            raise SigningConfigurationError("evidence signing key ID contains control characters")
        return cls(private_key, key_id, public_bytes, fingerprint, key_path)

    def sign(self, payload: bytes) -> str:
        return base64.b64encode(self.private_key.sign(payload)).decode("ascii")

    def issuer_metadata(self) -> dict[str, str]:
        return {
            "algorithm": "Ed25519",
            "key_id": self.key_id,
            "public_key_base64": base64.b64encode(self.public_key_bytes).decode("ascii"),
            "public_key_fingerprint": self.public_key_fingerprint,
            "trust_notice": TRUST_NOTICE,
        }

    @property
    def signing_profile_hash(self) -> str:
        """Identify every signer metadata field that changes signed export bytes."""
        profile = {
            "schema_version": _SIGNING_PROFILE_SCHEMA_VERSION,
            "issuer": self.issuer_metadata(),
        }
        return sha256_hex(canonical_json_bytes(profile))


def initialize_stack_signer(
    export_root: str | Path, *, before_create: Callable[[], None] | None = None,
) -> IssuerSigner:
    """Deliberately initialize only this stack's absent local signing key."""
    from .. import registry

    if os.environ.get(_PRIVATE_KEY_ENV, "").strip() or os.environ.get(_PRIVATE_KEY_FILE_ENV, "").strip():
        raise SigningConfigurationError("signing init requires unset signing key and signing key file overrides")
    path = _absolute_without_resolving_symlinks(Path(registry.REG_DIR) / "evidence-signing-ed25519.key")
    _assert_key_outside_export_root(path, Path(export_root).expanduser().resolve())
    registry.ensure_data_dir(str(path.parent))
    try:
        path.lstat()
    except FileNotFoundError:
        pass
    except OSError as error:
        raise SigningConfigurationError("evidence signing key file is unavailable") from error
    else:
        existing = _read_private_key(path, production=False)
        raise SigningConfigurationError(
            "evidence signing key already exists: " + _fingerprint(_raw_public_key(existing.public_key()))
        )
    if before_create is not None:
        before_create()
    private_key = _load_or_create_local_private_key(path)
    return IssuerSigner._from_private_key(private_key, path)


def _trusted_public_key(value: Ed25519PublicKey | bytes | str) -> Ed25519PublicKey:
    if isinstance(value, Ed25519PublicKey):
        return value
    data = value.encode("ascii") if isinstance(value, str) else bytes(value)
    stripped = data.strip()
    if stripped.startswith(b"-----BEGIN"):
        try:
            loaded = serialization.load_pem_public_key(stripped)
        except (TypeError, ValueError) as error:
            raise IntegrityError("trusted Ed25519 public key PEM is invalid") from error
        if not isinstance(loaded, Ed25519PublicKey):
            raise IntegrityError("trusted evidence public key must be Ed25519")
        return loaded
    if len(data) != 32:
        try:
            data = base64.b64decode(stripped, validate=True)
        except (binascii.Error, ValueError) as error:
            raise IntegrityError("trusted Ed25519 public key must be raw bytes, PEM, or base64") from error
    if len(data) != 32:
        raise IntegrityError("trusted Ed25519 public key must contain exactly 32 raw bytes")
    try:
        return Ed25519PublicKey.from_public_bytes(data)
    except ValueError as error:
        raise IntegrityError("trusted Ed25519 public key is invalid") from error


def verify_signed_export(
    directory: str | Path,
    trusted_public_key: Ed25519PublicKey | bytes | str,
    *,
    expected_key_id: str | None = None,
) -> dict[str, Any]:
    """Verify a signed export against an independently trusted issuer public key.

    The embedded public key is never accepted as its own trust anchor. The returned
    dictionary is the verified manifest.
    """

    root = Path(directory).expanduser()
    manifest_path = root / "manifest.json"
    try:
        manifest_bytes = manifest_path.read_bytes()
        manifest = json.loads(manifest_bytes)
    except (OSError, TypeError, ValueError) as error:
        raise IntegrityError("signed evidence manifest is unavailable or invalid") from error
    if not isinstance(manifest, dict) or manifest_bytes != canonical_json_bytes(manifest):
        raise IntegrityError("signed evidence manifest is not canonical JSON")
    signature_record = manifest.get("signature")
    expected_manifest_keys = {
        "schema_version",
        "issuer",
        "package",
        "evidence_audit_proof_reference",
        "artifacts",
        "signature",
    }
    if set(manifest) != expected_manifest_keys:
        raise IntegrityError("signed evidence manifest fields are invalid")
    if manifest.get("schema_version") != "livemore.evidence-export-manifest.v2":
        raise IntegrityError("signed evidence manifest schema is unsupported")
    if not isinstance(signature_record, dict) or set(signature_record) != {"algorithm", "value"}:
        raise IntegrityError("signed evidence manifest signature record is invalid")
    if signature_record.get("algorithm") != "Ed25519":
        raise IntegrityError("unsupported evidence manifest signature algorithm")
    unsigned = {key: value for key, value in manifest.items() if key != "signature"}
    key = _trusted_public_key(trusted_public_key)
    trusted_raw = _raw_public_key(key)
    trusted_fingerprint = _fingerprint(trusted_raw)
    issuer = unsigned.get("issuer")
    expected_issuer_keys = {
        "algorithm",
        "key_id",
        "public_key_base64",
        "public_key_fingerprint",
        "trust_notice",
    }
    if not isinstance(issuer, dict) or set(issuer) != expected_issuer_keys:
        raise IntegrityError("signed evidence manifest issuer metadata is missing")
    if issuer.get("algorithm") != "Ed25519":
        raise IntegrityError("signed evidence manifest issuer algorithm is invalid")
    if issuer.get("public_key_fingerprint") != trusted_fingerprint:
        raise IntegrityError("evidence issuer fingerprint does not match the trusted public key")
    embedded = issuer.get("public_key_base64")
    try:
        embedded_raw = base64.b64decode(str(embedded), validate=True)
    except (binascii.Error, ValueError) as error:
        raise IntegrityError("embedded evidence public key is invalid") from error
    if embedded_raw != trusted_raw:
        raise IntegrityError("embedded evidence public key does not match the trusted public key")
    if issuer.get("trust_notice") != TRUST_NOTICE:
        raise IntegrityError("evidence issuer trust notice is missing or altered")
    if expected_key_id is not None and issuer.get("key_id") != expected_key_id:
        raise IntegrityError("evidence issuer key ID does not match the expected key ID")
    try:
        signature = base64.b64decode(str(signature_record.get("value")), validate=True)
        key.verify(signature, canonical_json_bytes(unsigned))
    except (binascii.Error, ValueError, InvalidSignature) as error:
        raise IntegrityError("evidence manifest issuer signature is invalid") from error

    artifacts = unsigned.get("artifacts")
    if not isinstance(artifacts, dict) or set(artifacts) != set(SIGNED_ARTIFACT_NAMES):
        raise IntegrityError("signed evidence manifest artifact set is incomplete")
    artifact_bytes: dict[str, bytes] = {}
    for name in SIGNED_ARTIFACT_NAMES:
        expected_hash = str(artifacts[name])
        try:
            artifact_path = root / name
            if artifact_path.is_symlink() or not artifact_path.is_file():
                raise IntegrityError(f"signed evidence artifact is not a regular file: {name}")
            artifact = artifact_path.read_bytes()
        except OSError as error:
            raise IntegrityError(f"signed evidence artifact is unavailable: {name}") from error
        if sha256_hex(artifact) != expected_hash:
            raise IntegrityError(f"signed evidence artifact hash mismatch: {name}")
        artifact_bytes[name] = artifact

    evidence_bytes = artifact_bytes["evidence.json"]
    package_record = unsigned.get("package")
    if not isinstance(package_record, dict):
        raise IntegrityError("signed evidence package commitment is missing")
    if package_record.get("evidence_sha256") != sha256_hex(evidence_bytes):
        raise IntegrityError("signed evidence byte commitment does not match evidence.json")
    try:
        evidence_data = json.loads(evidence_bytes)
        from .models import evidence_package_from_dict

        package = evidence_package_from_dict(evidence_data)
    except Exception as error:
        raise IntegrityError("signed evidence package cannot be reconstructed") from error
    if canonical_json_bytes(package) != evidence_bytes:
        raise IntegrityError("signed evidence package bytes are not canonical")
    expected_projection = {
        "package_id": package.package_id,
        "package_content_hash": package.content_hash,
        "evidence_sha256": sha256_hex(evidence_bytes),
        "computed_claim_state": package.claim_state.value,
        "lifecycle": package.lifecycle.value,
        "revision": package.revision,
    }
    if package_record != expected_projection:
        raise IntegrityError("signed evidence package projection does not match evidence.json")
    if content_hash(evidence_data) != package.content_hash:
        raise IntegrityError("signed evidence content hash does not match evidence.json")
    audit_reference = unsigned.get("evidence_audit_proof_reference")
    if not isinstance(audit_reference, dict):
        raise IntegrityError("signed evidence audit proof reference is missing")
    if audit_reference.get("schema_version") != "livemore.evidence-audit-proof-reference.v1":
        raise IntegrityError("signed evidence audit proof reference schema is invalid")
    audit_status = audit_reference.get("status")
    if audit_status not in {"available", "not_available"}:
        raise IntegrityError("signed evidence audit proof reference status is invalid")
    if audit_status == "available":
        expected_audit_keys = {
            "schema_version",
            "status",
            "package_id",
            "package_revision",
            "package_payload_sha256",
            "audit_event_id",
            "audit_event_sequence",
            "audit_action",
            "audit_occurred_at",
            "audit_previous_event_hash",
            "audit_event_hash",
            "audit_key_version",
            "audit_event_signature",
            "audit_payload_key_version",
        }
        if set(audit_reference) != expected_audit_keys:
            raise IntegrityError("signed evidence audit proof reference fields are invalid")
        if (
            audit_reference.get("package_id") != package.package_id
            or audit_reference.get("package_revision") != package.revision
            or audit_reference.get("package_payload_sha256") != sha256_hex(evidence_bytes)
        ):
            raise IntegrityError("signed evidence audit proof reference does not match the package")
    else:
        if set(audit_reference) != {"schema_version", "status", "reason"}:
            raise IntegrityError("unavailable evidence audit proof reference fields are invalid")
        if not isinstance(audit_reference.get("reason"), str) or not audit_reference["reason"]:
            raise IntegrityError("unavailable evidence audit proof reference requires a reason")

    # The archive and detached digest are deterministic derivatives of the
    # signed bytes. Verify them and reject unscoped files so callers know the
    # exact contents covered by this verification result.
    from .exporter import _archive_bytes, _safe_name

    archive_name = f"{_safe_name(package.package_id)}.zip"
    detached_name = f"{archive_name}.sha256"
    expected_names = set(SIGNED_ARTIFACT_NAMES) | {
        "manifest.json",
        archive_name,
        detached_name,
    }
    try:
        actual_entries = tuple(root.iterdir())
    except OSError as error:
        raise IntegrityError("signed evidence export directory is unavailable") from error
    if {entry.name for entry in actual_entries} != expected_names:
        raise IntegrityError("signed evidence export contains an unexpected artifact set")
    if any(entry.is_symlink() or not entry.is_file() for entry in actual_entries):
        raise IntegrityError("signed evidence export entries must be regular files")
    expected_archive = _archive_bytes({**artifact_bytes, "manifest.json": manifest_bytes})
    expected_archive_hash = sha256_hex(expected_archive)
    try:
        archive_bytes = (root / archive_name).read_bytes()
        detached_bytes = (root / detached_name).read_bytes()
    except OSError as error:
        raise IntegrityError("signed evidence archive or detached digest is unavailable") from error
    if archive_bytes != expected_archive:
        raise IntegrityError("signed evidence archive does not match the signed artifact bytes")
    if detached_bytes != (expected_archive_hash + "\n").encode("ascii"):
        raise IntegrityError("signed evidence archive detached digest is invalid")
    return manifest
