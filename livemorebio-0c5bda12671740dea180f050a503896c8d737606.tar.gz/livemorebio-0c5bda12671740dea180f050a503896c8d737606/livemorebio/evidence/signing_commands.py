"""Offline operator commands for the selected stack's evidence signing identity."""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import sqlite3
import stat

from .. import registry
from .errors import IntegrityError, SigningConfigurationError
from .signing import IssuerSigner, initialize_stack_signer
from .store import EvidenceStore


_FINGERPRINT = re.compile(r"sha256:[0-9a-f]{64}")
_INVENTORY_REFUSAL = "evidence signing public metadata is unavailable or invalid"


def _absolute_path(value: str | Path) -> Path:
    return Path(os.path.abspath(os.path.expanduser(os.fspath(value))))


def _open_stack_file(path: Path, root: Path) -> int:
    """Open only beneath the selected root, without following child symlinks."""
    relative = path.relative_to(root)
    if not relative.parts:
        raise SigningConfigurationError(_INVENTORY_REFUSAL)
    directory = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in relative.parts[:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                            dir_fd=directory)
            os.close(directory)
            directory = child
        descriptor = os.open(relative.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                             dir_fd=directory)
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            os.close(descriptor)
            raise SigningConfigurationError(_INVENTORY_REFUSAL)
        return descriptor
    finally:
        os.close(directory)


def _recorded_fingerprints(export_root: Path, database: Path) -> tuple[tuple[str, ...], int, bool]:
    """Best-effort public inventory; unavailable metadata cannot block init."""
    selected_export_root = export_root
    export_root = export_root.resolve()
    incomplete = False
    try:
        database = database.parent.resolve() / database.name
        descriptor = _open_stack_file(database, database.parent)
        os.close(descriptor)
        recorded_directories = EvidenceStore.recorded_export_directories(database)
    except FileNotFoundError:
        recorded_directories = ()
    except (SigningConfigurationError, IntegrityError, OSError, ValueError, TypeError,
            RuntimeError, sqlite3.Error):
        recorded_directories = ()
        incomplete = True
    directories = set()
    for value in recorded_directories:
        try:
            directory = Path(os.path.abspath(os.path.expanduser(value)))
        except (ValueError, TypeError):
            incomplete = True
            continue
        if directory.is_relative_to(selected_export_root):
            directory = export_root / directory.relative_to(selected_export_root)
        elif not directory.is_relative_to(export_root):
            continue
        directories.add(directory)
    try:
        with os.scandir(export_root) as entries:
            directories.update(export_root / entry.name for entry in entries
                               if not entry.name.startswith(".") and entry.is_dir(follow_symlinks=False))
    except FileNotFoundError:
        pass
    except OSError:
        incomplete = True
    fingerprints = set()
    unreadable = 0
    for directory in sorted(directories):
        try:
            descriptor = _open_stack_file(directory / "manifest.json", export_root)
            with os.fdopen(descriptor, "r", encoding="utf-8") as manifest_file:
                # Public inventory is bounded and never substitutes for verification.
                raw = manifest_file.read(1024 * 1024 + 1)
            if len(raw) > 1024 * 1024:
                raise ValueError(_INVENTORY_REFUSAL)
            manifest = json.loads(raw)
            issuer = manifest.get("issuer") if isinstance(manifest, dict) else None
            fingerprint = issuer.get("public_key_fingerprint") if isinstance(issuer, dict) else None
            if not isinstance(fingerprint, str) or not _FINGERPRINT.fullmatch(fingerprint):
                raise ValueError(_INVENTORY_REFUSAL)
        except (SigningConfigurationError, OSError, ValueError, TypeError, RecursionError):
            unreadable += 1
            continue
        fingerprints.add(fingerprint)
    return tuple(sorted(fingerprints)), unreadable, incomplete


def _print_public_metadata(signer: IssuerSigner, source_kind: str) -> None:
    metadata = signer.issuer_metadata()
    print(f"Source kind: {source_kind}")
    print(f"Key ID: {metadata['key_id']}")
    print(f"Fingerprint: {metadata['public_key_fingerprint']}")
    print(f"Public key (base64): {metadata['public_key_base64']}")


def run_signing_command(action: str) -> int:
    """Run without platform attachment, credential discovery, or service checks."""
    try:
        root = Path(os.path.abspath(os.path.expanduser(registry.REG_DIR)))
        export_root = Path(os.environ.get("LIVEMORE_EVIDENCE_EXPORT_DIR", str(root / "evidence-exports")))
        if action == "status":
            signer = IssuerSigner.load(export_root, create=False)
            source_kind = ("inline" if os.environ.get("LIVEMORE_EVIDENCE_SIGNING_KEY", "").strip()
                           else "configured file" if os.environ.get("LIVEMORE_EVIDENCE_SIGNING_KEY_FILE", "").strip()
                           else "stack key")
            _print_public_metadata(signer, source_kind)
            return 0
        if action != "init":
            raise SigningConfigurationError("unsupported evidence signing command")
        export_root = _absolute_path(export_root)
        database = _absolute_path(os.environ.get("LIVEMORE_EVIDENCE_DB", str(root / "evidence.sqlite")))
        fingerprints: tuple[str, ...] = ()
        unreadable = 0
        incomplete = False
        def inventory() -> None:
            nonlocal fingerprints, unreadable, incomplete
            fingerprints, unreadable, incomplete = _recorded_fingerprints(export_root, database)
        signer = initialize_stack_signer(export_root, before_create=inventory)
        _print_public_metadata(signer, "stack key")
        print("Recorded export issuer fingerprints (public metadata; not verified):")
        for fingerprint in fingerprints:
            print(f"  {fingerprint}")
        if not fingerprints:
            print("  none")
        print(f"{unreadable} recorded export manifests could not be read; their issuers are not listed.")
        if incomplete:
            print("Recorded export inventory could not be read; some issuers are not listed.")
        print("Send recipients the new public key; earlier exports keep verifying with the key that signed them.")
        return 0
    except SigningConfigurationError as error:
        print(f"  refused [{getattr(error, 'code', 'EVIDENCE_SIGNING_CONFIGURATION_INVALID')}]")
        print(f"  {error}")
        return 2
    except (IntegrityError, OSError, ValueError, TypeError, sqlite3.Error):
        print("  refused [EVIDENCE_SIGNING_CONFIGURATION_INVALID]")
        print(f"  {_INVENTORY_REFUSAL}")
        return 2
