"""Pinned public reference assets; no solver, patient data or legacy-model fallback.

Human-GEM originals are installed unchanged with their attribution. A verified
asset is permission/integrity ready, not scientifically or clinically qualified.
Only macOS/Linux are supported (owner-only files and POSIX advisory locking).
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager
import csv
from dataclasses import dataclass, field
from datetime import datetime, timezone
import errno
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import stat
import time
from typing import Any, Iterator
import urllib.error
import urllib.request


class ModelAssetError(RuntimeError):
    """Stable safe error category; messages never include runtime paths or URLs.

    One exception, by L0-R11: a refusal about an entry a rollback set aside,
    left in place or recorded names those local paths and the restore command,
    so the person can act. It comes only from install, check and restore,
    never from status. L0-R13: so does restore's refusal when it cannot read a
    directory that may hold such entries.
    """

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


@dataclass(frozen=True)
class AssetFile:
    asset_id: str
    filename: str
    source_url: str
    sha256: str
    size_bytes: int


_COMMIT = "635f533152dc5f7290ce04d12700eaa882273c3e"
_BASE = f"https://raw.githubusercontent.com/SysBioChalmers/Human-GEM/{_COMMIT}/"
_SOURCE_PATHS = {
    "xml": ("Human-GEM.xml", "model/Human-GEM.xml"),
    "genes": ("genes.tsv", "model/genes.tsv"),
    "reactions": ("reactions.tsv", "model/reactions.tsv"),
    "metabolites": ("metabolites.tsv", "model/metabolites.tsv"),
    "license": ("LICENSE.md", "LICENSE.md"),
    "schema": ("schema.md", "model/README.md"),
    "citation": ("citation.cff", "citation.cff"),
    "version": ("version.txt", "version.txt"),
}
_HUMAN_ASSETS = (
    AssetFile(
        "xml",
        "Human-GEM.xml",
        _BASE + "model/Human-GEM.xml",
        "cc5a4383c6116b0c91f4db089cc640f29aec7e840249b573b74d3792c9ca4a7a",
        43115559,
    ),
    AssetFile(
        "genes",
        "genes.tsv",
        _BASE + "model/genes.tsv",
        "2a6058a157b3b9f3c958ba753e71d7a702d2716742972741d2ef36535ae9dff6",
        1132077,
    ),
    AssetFile(
        "reactions",
        "reactions.tsv",
        _BASE + "model/reactions.tsv",
        "1436dd90e959714366270a9904fd6a5108044a2f7f1d7f8360bf7a195fc9e28f",
        886012,
    ),
    AssetFile(
        "metabolites",
        "metabolites.tsv",
        _BASE + "model/metabolites.tsv",
        "9d58bb3a9cd217c47dc0d54ea9517b0a23e0603bbb60d5428551e0449af1eab3",
        674780,
    ),
    AssetFile(
        "license",
        "LICENSE.md",
        _BASE + "LICENSE.md",
        "bb5e0179a1e9bdb55634a4303784cf73c297a1dcee27b92cd546bf398075531c",
        17068,
    ),
    AssetFile(
        "schema",
        "schema.md",
        _BASE + "model/README.md",
        "8bfa0bfd39ce7783df8b7191184695a8c6d38a928c71fb6181070d22007ff9f8",
        2586,
    ),
    AssetFile(
        "citation",
        "citation.cff",
        _BASE + "citation.cff",
        "41f90f96a1b05ba1e8ea8ca1927799f6244d47d8d41f813511751b89ee684f67",
        1716,
    ),
    AssetFile(
        "version",
        "version.txt",
        _BASE + "version.txt",
        "f22abd6773ab232869321ad4b1e47ac0c908febf4f3a2bd10c8066140f741261",
        5,
    ),
)
_PACKAGE = f"human-gem-2.0.0-{_COMMIT[:16]}"
_INSTALL_COMMAND = "python -m livemorebio.model_assets install human-gem"
_DOWNLOAD_SECONDS = 120.0
_CHUNK_BYTES = 1024 * 256


def _canonical(model_id: str) -> str:
    if model_id == "cardiac":
        return "cardiac"
    if model_id in ("human-gem", "human-gem-2.0.0"):
        return "human-gem"
    if model_id in ("recon3d", "recon3d-3.01"):
        return "recon3d"
    raise ModelAssetError("invalid_id", "Unknown pinned model identifier.")


def _require_human(model_id: str) -> str:
    canonical = _canonical(model_id)
    if canonical != "human-gem":
        raise ModelAssetError(
            "restricted",
            "Recon3D embeds CC-BY-NC-ND-4.0. Commercial execution and installation are unavailable pending independently reviewed rights.",
        )
    return canonical


def _validate_assets() -> None:
    if {item.asset_id for item in _HUMAN_ASSETS} != set(_SOURCE_PATHS) or len(
        _HUMAN_ASSETS
    ) != 8:
        raise ModelAssetError("invalid_manifest", "Pinned asset manifest is invalid.")
    for item in _HUMAN_ASSETS:
        filename, source_path = _SOURCE_PATHS[item.asset_id]
        if (
            item.filename != filename
            or item.source_url != _BASE + source_path
            or not re.fullmatch(r"[0-9a-f]{64}", item.sha256)
            or type(item.size_bytes) is not int
            or not 0 < item.size_bytes <= 50_000_000
        ):
            raise ModelAssetError(
                "invalid_manifest", "Pinned asset manifest is invalid."
            )


def asset_manifest(model_id: str = "human-gem") -> dict[str, Any]:
    """Detached, JSON-ready upstream provenance; never includes a local path."""
    canonical = _canonical(model_id)
    if canonical == "cardiac":
        return _cardiac_manifest()
    if canonical == "recon3d":
        return {
            "model_id": canonical,
            "release": "3.01",
            "commercial_execution": False,
            "commit": "967ff5113d4a3ad3fb65e7cf6aea82e63e76d914",
            "source_url": "https://github.com/VirtualMetabolicHuman/Recon",
            "license": {
                "id": "CC-BY-NC-ND-4.0",
                "url": "https://creativecommons.org/licenses/by-nc-nd/4.0/",
                "basis": "Explicit notice embedded in official Recon3DModel_301.xml.",
            },
            "inspected_source": {
                "source_url": "https://raw.githubusercontent.com/VirtualMetabolicHuman/Recon/967ff5113d4a3ad3fb65e7cf6aea82e63e76d914/Current_Version/Recon3D_301_Generic_Model/Recon3DModel_301.xml",
                "sha256": "6f96538177cc65248413c012876fc6e7608dda2647c2445c64f0b5ab727ad440",
                "size_bytes": 21575547,
            },
            "restriction": "Catalog only. No installation, file-import override, execution or redistribution in this release.",
            "commercial_guidance_url": "https://bigg.ucsd.edu/license",
        }
    _validate_assets()
    return {
        "schema_version": "livemore.model-assets.v1",
        "model_id": canonical,
        "name": "Human-GEM (Human2)",
        "release": "2.0.0",
        "commit": _COMMIT,
        "source_url": "https://github.com/SysBioChalmers/Human-GEM",
        "release_url": "https://github.com/SysBioChalmers/Human-GEM/releases/tag/v2.0.0",
        "license": {
            "id": "CC-BY-4.0",
            "url": "https://creativecommons.org/licenses/by/4.0/",
            "source_url": _BASE + "LICENSE.md",
            "attribution": "Human-GEM contributors; original LICENSE.md and citation.cff retained unchanged.",
            "modification_notice": "Upstream files unmodified. Livemore applies separately recorded constraints in memory.",
        },
        "citation_url": _BASE + "citation.cff",
        "expected_ids": {
            "objective": "MAR03964",
            "glucose": "MAR09034",
            "oxygen": "MAR09048",
        },
        "expected_counts": {
            "reactions": 12931,
            "metabolites": 8461,
            "genes": 2848,
            "compartments": 9,
        },
        "objective_direction": "max",
        "flux_unit": "mmol_per_gDW_per_hr",
        "format": "SBML Level 3 Version 1, FBC Version 2",
        "evidence_class": "REFERENCE_STOICHIOMETRIC_MODEL",
        "qualification": "NOT_QUALIFIED",
        "assets": {
            item.asset_id: {
                "filename": item.filename,
                "source_url": item.source_url,
                "sha256": item.sha256,
                "size_bytes": item.size_bytes,
            }
            for item in _HUMAN_ASSETS
        },
    }


def catalog() -> dict[str, Any]:
    """Reference catalog only; does not create caches or perform network access."""
    return {
        "schema_version": "livemore.model-catalog.v1",
        "models": [asset_manifest("human-gem"), asset_manifest("recon3d")],
    }


def _digest(document: dict[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(
            document, sort_keys=True, separators=(",", ":"), allow_nan=False
        ).encode()
    ).hexdigest()


def _assert_directory(path: Path) -> None:
    try:
        info = path.lstat()
    except OSError:
        raise ModelAssetError(
            "unsafe_path", "Model cache directory is inaccessible."
        ) from None
    if (
        not stat.S_ISDIR(info.st_mode)
        or info.st_uid != os.getuid()
        or not _private_mode(info.st_mode)
    ):
        raise ModelAssetError(
            "unsafe_path",
            "Model cache requires owned, non-symlink, private directories (0700).",
        )


def _private_mode(mode: int) -> bool:
    """Owner-only permission bits, 0700. Round 3: Linux copies set-group-ID
    from a set-group-ID parent onto every directory made in it, whatever mode
    mkdir asks for; it grants no access, so it is not counted."""
    return stat.S_IMODE(mode) & ~stat.S_ISGID == 0o700


def _entry_exists(path: Path, code: str, message: str) -> bool:
    """Whether a name holds an entry. Round 3: any other error reading it is a
    typed refusal; Path.exists() raises it (EIO, EACCES, ENAMETOOLONG)."""
    try:
        os.lstat(path)
    except (FileNotFoundError, NotADirectoryError):
        return False
    except OSError:
        raise ModelAssetError(code, message) from None
    return True


def _model_root(*, create: bool = False) -> Path:
    configured = os.environ.get("LIVEMORE_MODEL_DIR")
    if configured is None:
        configured = str(
            Path(os.environ.get("LIVEMORE_DATA_DIR", "~/.livemore")).expanduser()
            / "models"
        )
    if not configured or "\x00" in configured:
        raise ModelAssetError(
            "unsafe_path", "A nonempty private model-cache location is required."
        )
    path = Path(configured).expanduser().absolute()
    # Do not resolve the leaf: a symlink masquerading as the configured cache
    # must be rejected. OS parent aliases such as /tmp -> /private/tmp are fine.
    try:
        info = os.lstat(path)
    except (FileNotFoundError, NotADirectoryError):
        info = None
    except OSError:
        raise ModelAssetError("unsafe_path", "Model cache directory is inaccessible.") from None
    if info is not None and stat.S_ISLNK(info.st_mode):
        raise ModelAssetError("unsafe_path", "The model cache must not be a symlink.")
    if info is None:
        if not create:
            return path
        try:
            # The owner bits are kept out of the umask so the cache is 0700.
            previous = os.umask(0o077)
            try:
                os.umask(previous & 0o077)
                path.mkdir(mode=0o700, parents=True, exist_ok=True)
            finally:
                os.umask(previous)
        except OSError:
            raise ModelAssetError(
                "unsafe_path", "Unable to create the private model cache."
            ) from None
    _assert_directory(path)
    return path


def _private_fd(path: Path, flags: int = os.O_RDONLY) -> int:
    try:
        fd = os.open(path, flags | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    except OSError:
        raise ModelAssetError(
            "unsafe_path", "A model-cache file is inaccessible or unsafe."
        ) from None
    try:
        info = os.fstat(fd)
    except OSError:
        _close(fd)
        raise ModelAssetError(
            "unsafe_path", "A model-cache file is inaccessible or unsafe."
        ) from None
    if (
        not stat.S_ISREG(info.st_mode)
        or info.st_uid != os.getuid()
        or info.st_nlink != 1
        or stat.S_IMODE(info.st_mode) != 0o600
    ):
        _close(fd)
        raise ModelAssetError(
            "unsafe_path",
            "Model files require owned, single-link, regular private files (0600).",
        )
    return fd


# L0-R11. Every entry an operation creates is recorded before it can be left
# behind. Round 1: the record holds the entry open, so its device and inode
# cannot be reused by another entry while the operation runs. Rollback deletes
# nothing by name after a separate check: it moves the entry with one rename
# into a new private directory whose name records the entry's identity,
# compares device and inode there, then deletes it or puts it back without
# overwriting. Whatever it cannot finish is reported, with `restore` to finish it.
# Round 2: the record is on disk before each entry exists, so a SIGKILL or power
# loss leaves nothing `restore` cannot finish, and identity is compared on the
# volume as it is mounted now (a volume attached again has a new st_dev).
_ASIDE_PREFIX = ".livemore-aside-"
_RECORD_PREFIX = ".livemore-rollback-"
_RECORD_FILE = "record.json"
# Round 2: the record is written before each entry exists (record before act),
# replacing this file inside the record directory each time.
_RECORD_NEW = "record.json.new"
# Files the operation makes in its record directory: a hard link that keeps a
# recorded file's inode from reuse ("pin-"), and the new integrity record.
_PIN_PREFIX = "pin-"
_NEW_RECORD_PREFIX = ".cardiac-integrity-"
# Inside an `old` aside: a hard link of the new integrity record, so whether it
# holds the record's name is decided by identity even after this process ends.
_NEW_RECORD_PIN = "new-record"
# Space a rollback may need on a full volume, held from before the operation
# acts until it ends, and given back only when a rollback step meets ENOSPC.
_RESERVE_FILE = "reserve"
_RESERVE_BYTES = 256 * 1024
# own: the entry inside is this operation's iff its inode is this one on the
# aside directory's own volume (and, for a directory, its child with the second
# inode is too). old: the previous integrity record, to delete iff the new
# record, pinned inside the aside directory (round 2), holds its name, else to
# put back. The device field is the one it had then. Both names end with the
# process that made them.
_ASIDE_NAME = re.compile(
    r"\.livemore-aside-(own|old)-([0-9a-f]{1,16})-([0-9a-f]{1,16})-([0-9a-f]{1,16})-([0-9]{1,10})-[0-9a-f]{8}")
_RECORD_NAME = re.compile(r"\.livemore-rollback-([0-9]{1,10})-[0-9a-f]{8}")
_INTERRUPTS: dict[str, Any] = {"depth": 0, "pending": []}


@contextmanager
def _deferred_interrupts() -> Iterator[None]:
    """Ctrl-C for the length of one operation (L0-R11 round 1).

    The handler only records the interrupt and never raises, so no interrupt
    can fall between a failure and the rollback that settles it. The
    operation raises it at its checkpoints, where its rollback runs; one that
    arrives after the last checkpoint is delivered when the operation ends.
    Python runs SIGINT handlers only in the main thread; elsewhere none runs.
    """
    import signal
    import threading

    state = _INTERRUPTS
    if state["depth"]:
        state["depth"] += 1
        try:
            yield
        finally:
            state["depth"] -= 1
        return
    previous = signal.getsignal(signal.SIGINT)
    installed = False
    if (threading.current_thread() is threading.main_thread() and previous is not None
            and previous != signal.SIG_IGN):
        try:
            signal.signal(signal.SIGINT, lambda number, frame: state["pending"].append((number, frame)))
            installed = True
        except ValueError:
            pass
    state["pending"] = []
    state["previous"] = previous
    state["depth"] = 1
    try:
        yield
    finally:
        state["depth"] = 0
        held, state["pending"] = state["pending"], []
        if installed:
            signal.signal(signal.SIGINT, previous)
            if held:
                if callable(previous):
                    previous(*held[0])
                else:
                    signal.raise_signal(signal.SIGINT)


def _checkpoint() -> None:
    """Raise a recorded Ctrl-C here, where the operation's rollback will run."""
    held = _INTERRUPTS["pending"]
    if held:
        number, frame = held[0]
        held.clear()
        previous = _INTERRUPTS.get("previous")
        if callable(previous):
            previous(number, frame)  # Python's own handler raises KeyboardInterrupt here
            return  # a program's own handler chose to carry on
        raise KeyboardInterrupt


class _Pin:
    """A descriptor that holds one inode open, shared by every name of it.
    One it does not own (round 3: a record directory's own descriptor, closed
    by its operation) is never closed here."""

    def __init__(self, descriptor: int | None, *, owned: bool = True):
        self.descriptor = descriptor
        self.users = 1
        self.owned = owned

    def release(self) -> None:
        self.users -= 1
        if self.users <= 0 and self.descriptor is not None:
            descriptor, self.descriptor = self.descriptor, None
            if self.owned:
                try:
                    os.close(descriptor)
                except OSError:
                    pass


@dataclass(eq=False)
class _Entry:
    """One entry an operation created, pinned by an open descriptor.

    While the descriptor is open the kernel cannot give its inode number to
    another entry, so device and inode identify this entry and no other.
    """

    path: Path
    pin: _Pin
    directory: bool
    children: list["_Entry"] = field(default_factory=list)
    reason: str = ""
    recordable: bool = True
    recorded: bool = False
    # A directory this operation made but could not open: its identity as read
    # just after it was made. Only an empty directory can be removed by it.
    # Restore also identifies a recorded file by its pin's identity here: the
    # pin, a hard link in the record directory, keeps that inode from reuse.
    known: tuple[int, int] | None = None
    # Round 2, record before act. The entry's hard link in the record directory.
    disk_pin: str | None = None
    # Recorded before it exists (a directory about to be made): no identity yet.
    planned: bool = False
    # A private staging directory: by the stated boundary every file in it is
    # this operation's, so restore deletes them before the directory itself.
    private: bool = False
    # Part of the release once admission commits; restore then leaves it.
    until_commit: bool = False
    # Settled, never made, or committed: no longer listed for restore.
    done: bool = False
    # Listed in the record on disk.
    journaled: bool = False
    recorded_identity: tuple[int, int] | None = None
    # Round 3. Where the entry is now, when another program renamed a directory
    # on its path; the record keeps `path`, and restore finds it the same way.
    where: Path | None = None
    # Names another program gave this file inside the release; never deleted.
    found: list[Path] = field(default_factory=list)
    # The file's link count now (its pin in the record directory is one link).
    links: Any = None

    def identity(self) -> tuple[int, int]:
        if self.pin.descriptor is None:
            if self.known is not None:
                return self.known
            raise OSError(errno.EBADF, self.reason or "it is not held open")
        info = os.fstat(self.pin.descriptor)
        return info.st_dev, info.st_ino

    @property
    def identified(self) -> bool:
        return self.pin.descriptor is not None or self.known is not None

    def release(self) -> None:
        """This name is settled. A child is released when it is itself settled;
        every descriptor still open closes when the operation ends."""
        self.done = True
        self.pin.release()


def _close(descriptor: int) -> None:
    """Close a descriptor in a check or restore. An error closing it is no
    refusal: the descriptor is released either way on macOS and Linux."""
    try:
        os.close(descriptor)
    except OSError:
        pass


def _own_record_name(name: str) -> bool:
    """A name this product makes inside its own private record directory."""
    return (name in (_RECORD_FILE, _RECORD_NEW, _RESERVE_FILE)
            or name.startswith((_PIN_PREFIX, _NEW_RECORD_PREFIX)))


class _Operation:
    """One install or restore: the descriptors that pin what it created, its
    record on disk, and everything its rollback could not finish, reported
    once when it ends.

    Round 2, record before act: an install keeps a private record directory
    from before it acts until it ends, holding an exclusive lock on it all that
    time, so another command can tell a running installation from one that
    stopped. Before each entry the operation makes, the record on disk lists
    it, with a hard link (pin) for a file, so after SIGKILL or power loss
    `restore` still knows what the operation made and can prove which file is
    its own.
    """

    def __init__(self, model_id: str, *, records_left: bool = True):
        self.model_id = model_id
        self.records_left = records_left
        self.pins: list[_Pin] = []
        self.kept: list[Path] = []
        self.left: list[_Entry] = []
        self.record_directory: Path | None = None
        self.record_descriptor: int | None = None
        self.reserve: Path | None = None
        self.journal: list[_Entry] = []
        # The managed admission's commit: the integrity record's path, and the
        # new record's name in the record directory (round 2).
        self.commit: dict[str, str] | None = None
        # Whether created entries are rolled back (a managed release) and so
        # recorded with pins before they are published.
        self.managed = False
        self.pin_count = 0
        # Round 3. The directory every recorded path is below, and the identity
        # of each directory between it and an entry, keyed by the path relative
        # to it: rollback and restore find an entry's directory by identity, so
        # a directory another program renamed is still found and a symlink put
        # at its name is never followed.
        self.scope: Path | None = None
        self.directories: dict[str, tuple[int, int]] = {}
        # A managed release, searched for other names of this operation's files,
        # except inside this operation's own private staging directories.
        self.release: Path | None = None
        self.private: list[tuple[int, int]] = []
        # Restore: a device number recorded before the volume was attached again.
        self.device_of: Any = lambda device: device

    def same(self, info: os.stat_result, identity: tuple[int, int]) -> bool:
        return info.st_ino == identity[1] and info.st_dev == self.device_of(identity[0])

    def know(self, path: Path, identity: tuple[int, int]) -> None:
        """Record a directory's identity, by its path below the scope."""
        if self.scope is None:
            return
        try:
            relative = path.relative_to(self.scope)
        except ValueError:
            return
        if relative.parts:
            self.directories[relative.as_posix()] = identity

    def know_chain(self, path: Path) -> None:
        """Pin and record every directory from the scope down to `path` (round 3).
        Pinned, so no other directory can take the inode number while the
        operation runs; not followed through a symlink."""
        if self.scope is None:
            return
        try:
            relative = path.relative_to(self.scope)
        except ValueError:
            return
        current = self.scope
        for part in relative.parts:
            current = current / part
            key = current.relative_to(self.scope).as_posix()
            if key in self.directories:
                continue
            try:
                descriptor = os.open(current, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            except OSError:
                return
            self.pin(descriptor)
            try:
                info = os.fstat(descriptor)
            except OSError:
                return
            self.directories[key] = (info.st_dev, info.st_ino)

    def prepare(self, *, required: bool = True) -> None:
        """Before acting: the rollback's private record directory, locked for
        the whole operation, and a reserve of space in it. On a full volume the
        rollback deletes the reserve first, so it can always make its aside
        directories and its record; without the reserve it could not begin
        there. A volume too full for the reserve refuses the operation before
        it creates anything, and so does a model with no place for a record
        (record before act). Called again once missing directories exist; it
        acts only once."""
        import fcntl

        if self.record_directory is not None:
            return
        for parent in _record_anchors(self.model_id):
            try:
                anchor = os.open(parent, os.O_RDONLY | os.O_DIRECTORY)
            except OSError:
                continue
            try:
                # Round 3: from before the mkdir until the new record directory is
                # locked, its maker holds this directory's lock, so check and
                # restore report BUSY in that instant too, and never take the
                # new, empty directory for one a stopped operation left.
                anchored = _lock_with_retries(anchor, fcntl.LOCK_EX)
                try:
                    if self._make_record(parent):
                        return
                finally:
                    if anchored:
                        _unlock(anchor)
            finally:
                _close(anchor)
        if required:
            raise ModelAssetError(
                "CARDIAC_MODEL_INSTALL_FAILED" if self.model_id == "cardiac" else "unsafe_path",
                "No rollback record could be made beside the model, so an interrupted installation could "
                "not be finished; check the directory's permissions, then retry. Nothing was installed.")

    def _make_record(self, parent: Path) -> bool:
        """One private, locked record directory in `parent`, with its reserve."""
        import fcntl

        for _ in range(3):
            try:
                directory = _make_record_directory(parent)
            except OSError:
                return False
            try:
                descriptor = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            except OSError:
                try:
                    info = os.lstat(directory)
                except OSError:
                    return False
                if stat.S_ISDIR(info.st_mode):
                    _discard_record_directory(directory, None, (info.st_dev, info.st_ino))
                return False
            try:
                # Held until the operation ends. Another command may hold it
                # for an instant to see whether an installation runs; a
                # restore that took it first may have removed the
                # directory, and then another is made.
                for wait in range(50):
                    try:
                        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                        break
                    except BlockingIOError:
                        if wait == 49:
                            raise
                        time.sleep(0.01)
            except BlockingIOError:
                _close(descriptor)  # a restore holds it, and removes it
                continue
            except OSError:
                _discard_record_directory(directory, descriptor)  # no lock can be held on it here
                _close(descriptor)
                return False
            try:
                if not os.path.samestat(os.lstat(directory), os.fstat(descriptor)):
                    raise OSError(errno.ESTALE, "the record directory was replaced")
            except OSError:
                # Round 3: this operation's own directory is removed through its
                # descriptor and by identity; whatever holds the name now is left.
                _discard_record_directory(directory, descriptor)
                _unlock(descriptor)
                _close(descriptor)
                continue
            try:
                created = os.open(_RESERVE_FILE, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600,
                                  dir_fd=descriptor)
                try:
                    remaining = memoryview(bytes(_RESERVE_BYTES))
                    while remaining:
                        remaining = remaining[os.write(created, remaining):]
                    os.fsync(created)
                finally:
                    os.close(created)
            except OSError as error:
                _discard_record_directory(directory, descriptor)
                _unlock(descriptor)
                _close(descriptor)
                if _no_space(error):
                    raise ModelAssetError(
                        "CARDIAC_MODEL_INSTALL_FAILED" if self.model_id == "cardiac" else "unsafe_path",
                        "There is not enough free space to install with a rollback that can finish; "
                        "free some space, then retry. Nothing was installed.") from None
                return False
            self.record_directory, self.record_descriptor = directory, descriptor
            self.reserve = directory / _RESERVE_FILE
            return True
        return False

    def release_reserve(self) -> bool:
        """Give the reserve back to the volume; True if there was one."""
        if self.reserve is None:
            return False
        reserve, self.reserve = self.reserve, None
        try:
            if self.record_descriptor is None:
                raise OSError(errno.EBADF, "the record directory is not held open")
            os.unlink(reserve.name, dir_fd=self.record_descriptor)  # inside this operation's own record directory
        except OSError:
            return False
        return True

    def with_space(self, call: Any) -> Any:
        """Run one rollback step; on a full volume, once more after the reserve is freed."""
        try:
            return call()
        except OSError as error:
            if not (_no_space(error) and self.release_reserve()):
                raise
        return call()

    def pin(self, descriptor: int) -> _Pin:
        pin = _Pin(descriptor)
        self.pins.append(pin)
        return pin

    def file(self, path: Path, descriptor: int) -> _Entry:
        return _Entry(path, self.pin(descriptor), False)

    def directory(self, path: Path) -> _Entry:
        """Pin a directory this operation has just made. The instant between
        the mkdir and this open is the stated limit (receipt limit 1)."""
        try:
            descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        except OSError as error:
            reason = f"it could not be opened after it was made ({error.strerror})"
            try:
                info = os.lstat(path)
            except OSError:
                return _Entry(path, _Pin(None), True, recordable=False, reason=reason)
            if not stat.S_ISDIR(info.st_mode):
                return _Entry(path, _Pin(None), True, recordable=False, reason=reason)
            return _Entry(path, _Pin(None), True, reason=reason, known=(info.st_dev, info.st_ino))
        return _Entry(path, self.pin(descriptor), True)

    @staticmethod
    def share(entry: _Entry, path: Path) -> _Entry:
        """The same inode published at a second name."""
        entry.pin.users += 1
        return _Entry(path, entry.pin, False)

    def leave(self, entry: _Entry, reason: str, *, recordable: bool = True) -> None:
        entry.reason = reason
        entry.recordable = entry.recordable and recordable
        self.left.append(entry)

    def unfinished(self) -> list[Path]:
        """What restore can still finish: a directory holding one stays for it.
        Round 3: a file another program gave other names is where those are."""
        return [path for entry in self.left if entry.recordable
                for path in (entry.found or [entry.path])] + list(self.kept)

    # Round 2: the record on disk, written before each entry it lists exists.
    def note(self, entry: _Entry) -> None:
        """List an entry for the record; `save` writes it before the entry is made."""
        if self.record_directory is not None:
            self.journal.append(entry)

    def record_file(self, prefix: str, flags: int = os.O_WRONLY) -> tuple[int, str]:
        """A new owner-only file inside the private record directory. It is
        made there first, so it is this operation's before any other name
        holds it; `save` lists it, and only then is it linked to its name."""
        if self.record_descriptor is None:
            raise OSError(errno.ENOENT, "this operation has no record directory")
        for _ in range(100):
            self.pin_count += 1
            name = f"{prefix}{self.pin_count}" if prefix == _PIN_PREFIX else f"{prefix}{secrets.token_hex(4)}"
            try:
                descriptor = os.open(name, flags | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600,
                                     dir_fd=self.record_descriptor)
            except FileExistsError:
                continue
            self.pin(descriptor)
            os.fchmod(descriptor, 0o600)
            return descriptor, name
        raise FileExistsError(errno.EEXIST, "No unused name was found in the record directory.")

    def pin_link(self, entry: _Entry, source: Path) -> None:
        """Pin a file this operation made: a hard link of it in the record
        directory, verified against the descriptor that holds it."""
        if self.record_descriptor is None or self.record_directory is None:
            return
        self.pin_count += 1
        name = f"{_PIN_PREFIX}{self.pin_count}"
        os.link(source, self.record_directory / name, follow_symlinks=False)
        if not os.path.samestat(os.stat(name, dir_fd=self.record_descriptor, follow_symlinks=False),
                                os.fstat(entry.pin.descriptor)):
            raise OSError(errno.ESTALE, "the staged file was replaced before it was pinned")
        entry.disk_pin = name

    def links_of(self, name: str | None) -> Any:
        """The link count of the file pinned as `name` in the record directory."""
        def links() -> int:
            if name is None or self.record_descriptor is None:
                raise OSError(errno.EBADF, "it has no pin in the record directory")
            return os.stat(name, dir_fd=self.record_descriptor, follow_symlinks=False).st_nlink
        return links

    def forget(self, entry: _Entry) -> None:
        """An entry recorded before it existed that this operation did not make
        after all: it leaves the record."""
        entry.release()
        if entry.disk_pin is not None and self.record_descriptor is not None:
            try:
                os.unlink(entry.disk_pin, dir_fd=self.record_descriptor)
            except OSError:
                pass
        try:
            self.save()
        except OSError:
            pass  # the entry is settled by its identity: restore finds it absent or another's

    def _describe(self, entry: _Entry) -> dict[str, Any]:
        if entry.recorded_identity is None and entry.identified:
            entry.recorded_identity = entry.identity()
        device, inode = entry.recorded_identity or (None, None)
        children = []
        for child in entry.children:
            if child.done:
                continue
            if child.recorded_identity is None and child.identified:
                child.recorded_identity = child.identity()
            child_device, child_inode = child.recorded_identity or (None, None)
            if child_inode is not None:
                children.append({"name": child.path.name, "device": child_device, "inode": child_inode,
                                 "pin": child.disk_pin})
        return {"path": str(entry.path), "directory": entry.directory, "device": device, "inode": inode,
                "pin": entry.disk_pin, "private": entry.private, "until_commit": entry.until_commit,
                "children": children}

    def save(self, entries: list[_Entry] | None = None, *, commit: bool = True) -> None:
        """Write the record: every entry not yet settled. It replaces the
        record file inside the private record directory in one step, so the
        record on disk is always whole. Mode 0600 whatever the umask."""
        if self.record_descriptor is None:
            return
        listed = [entry for entry in (self.journal if entries is None else entries) if not entry.done]
        document = {"schema_version": "livemore.rollback-record.v1", "model_id": self.model_id,
                    "record_device": os.fstat(self.record_descriptor).st_dev,
                    "commit": self.commit if commit else None,
                    "entries": [self._describe(entry) for entry in listed],
                    # Round 3: the directories on each entry's path, by identity.
                    "directories": {key: list(identity) for key, identity in self.directories.items()}}
        data = json.dumps(document, sort_keys=True, allow_nan=False).encode("utf-8")
        try:
            os.unlink(_RECORD_NEW, dir_fd=self.record_descriptor)
        except FileNotFoundError:
            pass
        descriptor = os.open(_RECORD_NEW, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600,
                             dir_fd=self.record_descriptor)
        try:
            os.fchmod(descriptor, 0o600)
            remaining = memoryview(data)
            while remaining:
                remaining = remaining[os.write(descriptor, remaining):]
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        os.replace(_RECORD_NEW, _RECORD_FILE, src_dir_fd=self.record_descriptor, dst_dir_fd=self.record_descriptor)
        os.fsync(self.record_descriptor)
        for entry in listed:
            entry.journaled = True

    def _final_record(self) -> Path | None:
        """When the operation ends: keep the record for what restore must
        finish, and remove everything else this operation put in it."""
        record = self.record_directory
        if record is None or self.record_descriptor is None:
            return None
        left = [entry for entry in self.left if entry.recordable and entry.journaled]
        # In the order they were made: restore works through them newest first.
        remaining = [entry for entry in self.journal if any(entry is other for other in left)]
        if not (remaining and self.records_left):
            # Round 3: through its own descriptor, never by its name.
            _discard_record_directory(record, self.record_descriptor)
            return None
        # The record needs a little space; the reserve was kept for exactly this.
        self.release_reserve()
        unknown_commit = any(entry.until_commit for entry in remaining) and self.commit is not None
        try:
            self.save(remaining, commit=unknown_commit)
        except (OSError, ValueError):
            pass  # the record already on disk lists all of these, and more
        else:
            keep = {entry.disk_pin for entry in remaining}
            keep |= {child.disk_pin for entry in remaining for child in entry.children}
            if unknown_commit and self.commit is not None:
                keep.add(self.commit["pin"])
            try:
                names = os.listdir(self.record_descriptor)
            except OSError:
                names = []
            for name in names:
                if name.startswith((_PIN_PREFIX, _NEW_RECORD_PREFIX)) and name not in keep:
                    try:
                        os.unlink(name, dir_fd=self.record_descriptor)
                    except OSError:
                        pass
        for entry in remaining:
            entry.recorded = True
        return record

    def close(self) -> None:
        for pin in self.pins:
            if pin.descriptor is not None:
                descriptor, pin.descriptor = pin.descriptor, None
                try:
                    os.close(descriptor)
                except OSError:
                    pass

    def finish(self, *, raise_refusal: bool = True, cause: BaseException | None = None) -> None:
        record = None
        try:
            record = self._final_record()
        finally:
            self.release_reserve()
            if self.record_descriptor is not None:
                descriptor, self.record_descriptor = self.record_descriptor, None
                _unlock(descriptor)
                _close(descriptor)
            self.close()
        if raise_refusal and (self.kept or self.left):
            raise self.refusal(record, cause)

    def refusal(self, record: Path | None, cause: BaseException | None = None) -> ModelAssetError:
        def named(entries: list[_Entry]) -> str:
            return "; ".join(
                f"{entry.where or entry.path} ({entry.reason})"
                + "".join(f", holding {child.path} ({child.reason or 'not deleted'})"
                          for child in entry.children if not child.done)
                for entry in entries)

        # The failure that caused the rollback is kept at the front of the refusal.
        parts = [str(cause)] if isinstance(cause, ModelAssetError) and str(cause) else []
        if self.kept:
            parts.append("Rollback set entries aside that it could not settle; they are kept in "
                         + ", ".join(map(str, self.kept)) + ".")
        recorded = [entry for entry in self.left if entry.recorded]
        unrecorded = [entry for entry in self.left if not entry.recorded]
        if recorded:
            parts.append(f"Rollback could not remove {named(recorded)}. They are recorded in {record}.")
        if unrecorded:
            parts.append(f"Rollback did not remove {named(unrecorded)}; nothing records these for restore.")
        if self.kept or recorded:
            parts.append(f"Once the cause is fixed (for example, free space or restore a permission), run "
                         f"`{_restore_command(self.model_id)}`. It deletes only what this operation made "
                         "and never replaces an existing entry.")
            code = _aside_code(self.model_id)
        elif isinstance(cause, ModelAssetError):
            code = cause.code
        else:
            code = "CARDIAC_MODEL_INSTALL_INTEGRITY" if self.model_id == "cardiac" else "unsafe_path"
        return ModelAssetError(code, " ".join(parts))


@contextmanager
def _operation(model_id: str, *, records_left: bool = True) -> Iterator[_Operation]:
    """Ctrl-C deferred to the operation's checkpoints, every pin closed at its
    end, and one refusal that names everything its rollback could not finish.
    A refusal replaces the failure that caused the rollback; an interrupt does
    not, and the record it leaves makes the next check report the state."""
    with _deferred_interrupts():
        operation = _Operation(model_id, records_left=records_left)
        try:
            yield operation
        except KeyboardInterrupt:
            operation.finish(raise_refusal=False)
            raise
        except BaseException as error:
            operation.finish(cause=error)
            raise
        operation.finish()


def _mkdir_private(path: Path | str, directory: int | None = None) -> None:
    """mkdir 0700 whatever the umask (the umask changes for this one call);
    relative to an open directory when one is given (round 3)."""
    previous = os.umask(0o077)
    try:
        if directory is None:
            os.mkdir(path, 0o700)
        else:
            os.mkdir(path, 0o700, dir_fd=directory)
    finally:
        os.umask(previous)


def _lock_with_retries(descriptor: int, mode: int) -> bool:
    """flock for at most about two seconds; False if it was never taken."""
    import fcntl

    for _ in range(200):
        try:
            fcntl.flock(descriptor, mode | fcntl.LOCK_NB)
            return True
        except BlockingIOError:
            time.sleep(0.01)
        except OSError:
            return False
    return False


def _made(operation: _Operation, entry: _Entry, path: Path | None = None) -> None:
    """A planned directory now exists: pin it, and record its identity."""
    opened = operation.directory(path or entry.path)
    entry.pin, entry.known, entry.planned = opened.pin, opened.known, False
    entry.reason, entry.recordable = opened.reason, opened.recordable
    if entry.identified:
        try:
            operation.know(entry.path, entry.identity())
        except OSError:
            pass


def _mkdir_recorded(operation: _Operation, entry: _Entry, make: Any) -> None:
    """Make a planned directory. A directory found at the name after an error
    the mkdir reported may still be this operation's (a call can take effect
    and then fail), so it stays recorded and is settled like any other; only
    a name that was already taken leaves the record.

    L0-R13: only a confirmed absence drops the record. When the name cannot be
    read after the error, the entry stays recorded, planned, for the rollback
    and restore to settle (only an empty directory is ever removed by it). A
    directory recorded with children (the managed lock and its pid) also stays
    planned when one is found: whether it is this operation's or another
    installer's is decided when it is settled (`_planned_lock_is_own`).
    """
    try:
        make()
    except FileExistsError:
        operation.forget(entry)
        raise
    except BaseException:
        try:
            info = os.lstat(entry.path)
        except (FileNotFoundError, NotADirectoryError):
            operation.forget(entry)
        except OSError:
            pass  # uncertain: it stays recorded
        else:
            if not stat.S_ISDIR(info.st_mode):
                operation.forget(entry)  # another entry holds the name: no mkdir made it
            elif not entry.children:
                _made(operation, entry)
        raise
    _made(operation, entry)


def _make_directory(operation: _Operation, path: Path, mode: int, record: list[_Entry], *,
                    journal: bool = False, until_commit: bool = False) -> _Entry:
    """mkdir whose owner bits no umask removes, recorded and pinned at once.

    A directory made without owner read could not be opened to pin it, so for
    this one call the umask keeps only the person's group and other bits.
    With `journal` (round 2), the record on disk lists it before the mkdir,
    and its identity right after.
    """
    entry = _Entry(path, _Pin(None), True, planned=True, until_commit=until_commit)
    if journal:
        operation.note(entry)
        operation.save()
    record.append(entry)

    def make() -> None:
        previous = os.umask(0o077)
        try:
            os.umask(previous & 0o077)
            os.mkdir(path, mode)
        finally:
            os.umask(previous)

    try:
        _mkdir_recorded(operation, entry, make)
    except BaseException:
        if entry.done:
            record.remove(entry)
        raise
    if journal:
        operation.save()
    if entry.pin.descriptor is None:
        raise OSError(errno.EIO, entry.reason)  # it is recorded; the rollback settles it
    return entry


def _make_private_directory(operation: _Operation, parent: Path, prefix: str, made: list[_Entry]) -> _Entry:
    """A new uniquely named 0700 directory, pinned. Its random name is
    recorded before the mkdir, and its identity right after (round 2). It is
    added to `made` as soon as it may exist, so a failure still removes it."""
    for _ in range(100):
        entry = _Entry(parent / f"{prefix}{secrets.token_hex(4)}", _Pin(None), True, planned=True, private=True)
        operation.note(entry)
        operation.save()
        try:
            _mkdir_recorded(operation, entry, lambda: _mkdir_private(entry.path))
        except FileExistsError:
            continue
        except BaseException:
            if not entry.done:
                made.append(entry)
            raise
        made.append(entry)
        operation.save()
        if entry.identified:
            try:
                operation.private.append(entry.identity())
            except OSError:
                pass
        return entry
    raise FileExistsError(errno.EEXIST, "No unused staging name was found.")


def _create_private_file(path: Path, flags: int, operation: _Operation | None = None,
                         record: list[_Entry] | None = None) -> int:
    """Create a new owner-only file and record it at once, then check it.

    O_EXCL proves this operation made the file, and the record is the
    descriptor itself, so no second call can fail between the creation and its
    record (round 1). fchmod sets 0600 whatever the umask. With an operation,
    the operation owns the descriptor and closes it; without one, the caller does.
    """
    try:
        descriptor = os.open(path, flags | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    except FileExistsError:
        raise
    except OSError:
        raise ModelAssetError("unsafe_path", "A model-cache file is inaccessible or unsafe.") from None
    if operation is not None:
        entry = operation.file(path, descriptor)
        if record is not None:
            record.append(entry)
    try:
        try:
            os.fchmod(descriptor, 0o600)
            info = os.fstat(descriptor)
        except OSError:
            raise ModelAssetError("unsafe_path", "A model-cache file is inaccessible or unsafe.") from None
        if (
            not stat.S_ISREG(info.st_mode)
            or info.st_uid != os.getuid()
            or info.st_nlink != 1
            or stat.S_IMODE(info.st_mode) != 0o600
        ):
            raise ModelAssetError(
                "unsafe_path",
                "Model files require owned, single-link, regular private files (0600).",
            )
    except BaseException:
        if operation is None:
            _close(descriptor)
        raise
    return descriptor


def _create_recorded_file(operation: _Operation, destination: Path, record: list[_Entry] | None, *,
                          parent: _Entry | None = None, until_commit: bool = False, data: bytes = b"",
                          flags: int = os.O_WRONLY) -> int:
    """A new file at a shared name, recorded before that name holds it (round 2).

    It is made inside the private record directory, where it is this
    operation's from its creation and is itself the pin; the record on disk
    lists it; only then is it linked to its name, which never overwrites. A
    SIGKILL at any point leaves nothing the record does not account for.
    Raises FileExistsError if the name is taken. Returns the descriptor, which
    the operation owns.
    """
    descriptor, name = operation.record_file(_PIN_PREFIX, flags)
    entry = _Entry(destination, operation.pins[-1], False, disk_pin=name, until_commit=until_commit,
                   links=operation.links_of(name))
    if data:
        remaining = memoryview(data)
        while remaining:
            remaining = remaining[os.write(descriptor, remaining):]
        os.fsync(descriptor)
    if parent is not None:
        parent.children.append(entry)
    else:
        record.append(entry)
        operation.note(entry)
    operation.save()
    try:
        _link_recorded(operation.record_directory / name, destination, entry)
    except _PublicationUnknown:
        raise  # L0-R13: it may hold its name now; it stays recorded for rollback and restore
    except BaseException:
        if parent is not None:
            parent.children.remove(entry)
        else:
            record.remove(entry)
        operation.forget(entry)
        raise
    return descriptor


def _holds(path: Path, entry: _Entry) -> bool | None:
    """Whether the name holds this pinned entry; None when that cannot be read."""
    try:
        at_name = os.lstat(path)
    except (FileNotFoundError, NotADirectoryError):
        return False
    except OSError:
        return None
    try:
        return (at_name.st_dev, at_name.st_ino) == entry.identity()
    except OSError:
        return None


class _PublicationUnknown(OSError):
    """A publication reported an error, and whether it took effect could not
    be read (L0-R13). The entry stays recorded: only a confirmed absence drops
    a record, so rollback and restore settle it by its identity."""


def _link_recorded(source: Path, destination: Path, entry: _Entry) -> None:
    """os.link of a recorded entry to its name, which never overwrites. A link
    that took effect and still reported an error (a retransmitted NFS LINK)
    has published the entry, so it counts as made (round 2). L0-R13: when the
    name cannot be read to tell, `_PublicationUnknown` is raised, whatever the
    link reported (EEXIST included), and the caller keeps the record."""
    try:
        os.link(source, destination, follow_symlinks=False)
    except OSError as error:
        held = _holds(destination, entry)
        if held is True:
            return
        if held is None:
            raise _PublicationUnknown(error.errno or errno.EIO,
                                      f"whether {destination.name} was published could not be read") from error
        raise


def _rename_exclusive(source: Path | str, destination: Path | str, source_directory: int | None = None) -> None:
    """rename(2) that refuses any existing destination (RENAME_EXCL/NOREPLACE).

    os.link puts a file back without overwriting; a directory needs the
    kernel's no-replace rename. Where it is unavailable the call fails and
    nothing is replaced. `source_directory` names the source relative to an
    open directory, so a symlink at that directory's name is never followed.
    """
    import ctypes
    import sys

    library = ctypes.CDLL(None, use_errno=True)
    old, new = os.fsencode(source), os.fsencode(destination)
    if sys.platform == "darwin":
        here = -2 if source_directory is None else source_directory  # AT_FDCWD on macOS
        function = getattr(library, "renameatx_np", None)
        arguments: tuple[Any, ...] = (here, old, -2, new, 0x00000004)
    elif sys.platform.startswith("linux"):
        here = -100 if source_directory is None else source_directory  # AT_FDCWD on Linux
        function = getattr(library, "renameat2", None)
        arguments = (here, old, -100, new, 1)
    else:
        function = None
    if function is None:
        raise OSError(errno.ENOTSUP, "A no-replace rename is unavailable on this platform.")
    function.argtypes = (ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint)
    function.restype = ctypes.c_int
    if function(*arguments) != 0:
        number = ctypes.get_errno()
        raise OSError(number, os.strerror(number))


def _make_aside_at(directory: int, verdict: str, device: int, first: int, second: int) -> str:
    """A new private 0700 directory, named for its verdict, made in the open
    directory beside an entry. Round 3: every rollback and restore step inside
    it names entries relative to its descriptor, so it never needs a longer
    path than the install itself used (PATH_MAX)."""
    for _ in range(100):
        name = (f"{_ASIDE_PREFIX}{verdict}-{device:x}-{first:x}-{second:x}-{os.getpid()}-"
                f"{secrets.token_hex(4)}")
        try:
            _mkdir_private(name, directory)
        except FileExistsError:
            continue
        return name
    raise FileExistsError(errno.EEXIST, "No unused aside name was found.")


def _make_aside(parent: Path, verdict: str, device: int, first: int, second: int) -> Path:
    """A new private 0700 directory beside an entry, named for its verdict."""
    directory = os.open(parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        return parent / _make_aside_at(directory, verdict, device, first, second)
    finally:
        _close(directory)


def _discard_aside_at(operation: _Operation, directory: int, aside: Path) -> None:
    try:
        os.rmdir(aside.name, dir_fd=directory)
    except OSError:
        operation.kept.append(aside)


def _stored_name(path: Path) -> str:
    """The name the entry at `path` is stored under. On a case-insensitive
    volume another program's entry may differ from this name only in case;
    moving it, and putting it back, under its own spelling keeps its name."""
    try:
        names = os.listdir(path.parent)
        if path.name in names:
            return path.name
        at_name = os.lstat(path)
    except OSError:
        return path.name
    for name in names:
        try:
            if os.path.samestat(os.lstat(path.parent / name), at_name):
                return name
        except OSError:
            continue
    return path.name


def _find_directory(operation: _Operation, directory: Path, identity: tuple[int, int]) -> str | None:
    """The name, in `directory`, of the directory with this identity. A
    directory has exactly one name, so this is a rename, never another link."""
    try:
        names = os.listdir(directory)
    except OSError:
        return None
    for name in names:
        try:
            info = os.lstat(directory / name)
        except OSError:
            continue
        if stat.S_ISDIR(info.st_mode) and operation.same(info, identity):
            return name
    return None


def _locate(operation: _Operation, path: Path) -> Path | None:
    """The directory that holds `path` now, or None when it is gone (round 3).

    Below the operation's scope, each directory on the path is matched by the
    identity recorded for it. One another program renamed is found by that
    identity in its parent; a symlink, a file or another directory at its
    name is never followed. A directory with no recorded identity must be a
    real directory at its name.
    """
    scope = operation.scope
    if scope is None:
        return path.parent
    try:
        relative = path.parent.relative_to(scope)
    except ValueError:
        return path.parent
    current = scope
    for index, part in enumerate(relative.parts):
        expected = operation.directories.get("/".join(relative.parts[:index + 1]))
        candidate = current / part
        try:
            info = os.lstat(candidate)
        except (FileNotFoundError, NotADirectoryError):
            info = None
        except OSError:
            return path.parent  # unreadable: act at the recorded name, and report what that meets
        if info is not None and stat.S_ISDIR(info.st_mode) and (expected is None or operation.same(info, expected)):
            current = candidate
            continue
        if expected is None:
            return None
        found = _find_directory(operation, current, expected)
        if found is None:
            return None
        current = current / found
    return current


def _directory_name(operation: _Operation, parent: Path, name: str, identity: tuple[int, int], *,
                    private: bool) -> str | None:
    """The name this operation's directory has in `parent` now, or None.

    Round 3: another program may have renamed it (a backup tool's name.bak);
    a directory has one name, so it is found by identity. A private staging
    directory is only ever looked for at its own name: the Human-GEM one
    becomes the package by this operation's own rename.
    """
    try:
        info = os.lstat(parent / name)
    except (FileNotFoundError, NotADirectoryError):
        info = None
    except OSError:
        return name  # unreadable: the move aside reports it
    if info is not None and stat.S_ISDIR(info.st_mode) and operation.same(info, identity):
        return name
    if private:
        return None
    return _find_directory(operation, parent, identity)


def _names_in_release(operation: _Operation, identity: tuple[int, int]) -> list[Path]:
    """Every name in the managed release that holds this file (round 3), apart
    from those in this operation's own private staging directories, which are
    names it made and empties with them. A directory that cannot be read
    raises: the answer would be incomplete."""
    found = []
    pending = [operation.release]
    while pending:
        directory = pending.pop()
        with os.scandir(directory) as listing:
            entries = list(listing)
        for item in entries:
            candidate = directory / item.name
            try:
                info = os.lstat(candidate)
            except FileNotFoundError:
                continue
            if stat.S_ISDIR(info.st_mode):
                if not any(operation.same(info, private) for private in operation.private):
                    pending.append(candidate)
            elif operation.same(info, identity):
                found.append(candidate)
    return found


def _finished(operation: _Operation, entry: _Entry, outcome: str, identity: tuple[int, int]) -> str:
    """This operation's own name for the entry is gone. Round 3: a file of a
    managed release that another program gave other names in the release
    (a hard link, or its file moved) is never deleted by any of those names,
    which this operation did not make; it stays recorded, and the refusal
    names them, until they leave the release."""
    if not entry.directory and operation.release is not None and entry.links is not None:
        try:
            others = entry.links() - 1  # its pin in the record directory
            names = _names_in_release(operation, identity) if others > 0 else []
        except OSError as error:
            operation.leave(entry, "whether the release still holds it under another name could not be read "
                                   f"({error.strerror})")
            return "left"
        if names:
            entry.found = names
            operation.leave(entry, "it is still in the release as " + ", ".join(map(str, names))
                            + ", a name another program gave it. Rollback and restore delete only names this "
                            "operation made, so move that name out of the release")
            return "left"
    entry.release()
    return outcome


# install.sh's locking protocol (L0-R13): its lock is the directory
# `.install.lock`, held while the pid file in it names a live process; it is
# taken with mkdir and the pid is written in the statement right after. A lock
# with no pid yet is waited on this long before it is taken for a stale one.
_INSTALLER_PID_WAIT = 2.0


def _planned_lock_is_own(directory: int, own: list[tuple[int, int]]) -> bool:
    """A directory recorded before its mkdir together with its children (the
    managed installer lock and its pid), found at its name: whether it is that
    operation's own (L0-R13). It is when it holds one of those children. One
    holding anything else is another installer's. An empty one may be another
    installer's that has not written its pid yet, so it is the operation's
    only if nothing appears in it within `_INSTALLER_PID_WAIT`. Raises OSError
    when it cannot be read."""
    deadline = time.monotonic() + _INSTALLER_PID_WAIT
    while True:
        names = os.listdir(directory)
        for name in names:
            info = os.stat(name, dir_fd=directory, follow_symlinks=False)
            if (info.st_dev, info.st_ino) in own:
                return True
        if names:
            return False
        if time.monotonic() >= deadline:
            return True
        time.sleep(0.02)


def _settle(operation: _Operation, entry: _Entry) -> str:
    """Remove one recorded entry without ever deleting a path by name.

    The entry moves with one rename into a new private directory beside it,
    whose name records its device and inode, and only there is it compared
    with the descriptor that pins it. This operation's entry is deleted; any
    other is put back without overwriting. Nothing is left unreported: an
    entry still at its name is left, an entry in its aside directory is kept,
    and `restore` decides by the recorded name. Returns what happened.

    Round 3: the entry's directory is found by identity (`_locate`), so one
    another program renamed is still found and a symlink at its name is never
    followed; a file is deleted only by the name this operation made, never
    by another name another program gave it; and every step inside the aside
    directory is relative to its descriptor.
    """
    if entry.planned:
        # Recorded before its mkdir, with no identity yet (receipt limit 1):
        # whatever directory is at the name now is taken as made then, so
        # only an empty one can be removed.
        parent = _locate(operation, entry.path)
        try:
            if parent is None or not stat.S_ISDIR(os.lstat(parent / entry.path.name).st_mode):
                entry.release()
                return "absent"
        except (FileNotFoundError, NotADirectoryError):
            entry.release()
            return "absent"
        except OSError as error:
            operation.leave(entry, error.strerror or "it could not be read")
            return "left"
        _made(operation, entry, parent / entry.path.name)
        if entry.children:
            # L0-R13: the managed lock is removed only if it is this
            # operation's, never another installer's (install.sh's protocol).
            try:
                if entry.pin.descriptor is None:
                    raise OSError(errno.EBADF, entry.reason or "it could not be opened")
                own = _planned_lock_is_own(entry.pin.descriptor,
                                           [child.identity() for child in entry.children if child.identified])
            except OSError as error:
                operation.leave(entry, f"whether it is this operation's could not be read ({error.strerror})")
                return "left"
            if not own:
                entry.release()
                return "absent"
    if not entry.identified:
        operation.leave(entry, entry.reason or "this operation could not hold it open", recordable=False)
        return "left"
    try:
        identity = entry.identity()
        held = [child for child in entry.children if child.identified and not child.done]
        second = held[0].identity()[1] if held else 0
    except OSError as error:
        operation.leave(entry, error.strerror or "its identity could not be read")
        return "left"
    parent = _locate(operation, entry.path)
    name: str | None = entry.path.name
    if parent is not None and entry.directory:
        name = _directory_name(operation, parent, entry.path.name, identity, private=entry.private)
    if parent is None or name is None:
        return _finished(operation, entry, "absent", identity)
    if parent / name != entry.path:
        entry.where = parent / name
    try:
        directory = os.open(parent, os.O_RDONLY | os.O_DIRECTORY)
    except (FileNotFoundError, NotADirectoryError):
        return _finished(operation, entry, "absent", identity)
    except OSError as error:
        operation.leave(entry, error.strerror or "its directory could not be opened")
        return "left"
    try:
        outcome = _settle_at(operation, entry, parent, directory, _stored_name(parent / name), identity, second)
    finally:
        _close(directory)
    if outcome in ("absent", "deleted", "returned"):
        return _finished(operation, entry, outcome, identity)
    return outcome


def _settle_at(operation: _Operation, entry: _Entry, parent: Path, directory: int, stored: str,
               identity: tuple[int, int], second: int) -> str:
    """The move aside, verification and delete or put-back for one name."""
    try:
        aside_name = operation.with_space(lambda: _make_aside_at(directory, "own", identity[0], identity[1], second))
    except (FileNotFoundError, NotADirectoryError):
        return "absent"  # its directory is gone, so the entry is no longer at its name (round 2)
    except OSError as error:
        operation.leave(entry, error.strerror or "no aside directory could be made")
        return "left"
    aside = parent / aside_name
    try:
        inner = os.open(aside_name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
    except OSError as error:
        _discard_aside_at(operation, directory, aside)
        operation.leave(entry, error.strerror or "its aside directory could not be opened")
        return "left"
    try:
        try:
            operation.with_space(lambda: os.rename(parent / stored, stored, dst_dir_fd=inner))
        except FileNotFoundError:
            _discard_aside_at(operation, directory, aside)
            return "absent"
        except OSError as error:
            _discard_aside_at(operation, directory, aside)
            operation.leave(entry, error.strerror or "it could not be moved aside")
            return "left"
        # From here the entry is inside the aside directory, and is reported there.
        try:
            info = os.stat(stored, dir_fd=inner, follow_symlinks=False)
        except FileNotFoundError:
            _discard_aside_at(operation, directory, aside)  # a restore settled it meanwhile
            return "absent"
        except OSError:
            operation.kept.append(aside)
            return "kept"
        ours = operation.same(info, identity)
        if ours:
            try:
                if stat.S_ISDIR(info.st_mode):
                    for child in entry.children:
                        _delete_child_at(operation, inner, stored, child)
                    os.rmdir(stored, dir_fd=inner)
                else:
                    os.unlink(stored, dir_fd=inner)
            except OSError as error:
                if not (stat.S_ISDIR(info.st_mode) and error.errno in (errno.ENOTEMPTY, errno.EEXIST)):
                    operation.kept.append(aside)  # this operation's own; restore deletes it
                    return "kept"
                # This operation's directory holds entries it did not create: it goes back.
            else:
                _discard_aside_at(operation, directory, aside)
                return "deleted"
        try:
            operation.with_space(lambda: _put_back_at(inner, stored, parent / stored))
        except OSError:
            operation.kept.append(aside)
            return "kept"
        _discard_aside_at(operation, directory, aside)
        if ours:
            operation.leave(entry, "it holds entries this operation did not create", recordable=False)
            return "occupied"
        return "returned"
    finally:
        _close(inner)


def _put_back_at(directory: int, name: str, destination: Path) -> None:
    """Return an entry from its aside to its name, never replacing what holds that name now."""
    if stat.S_ISDIR(os.stat(name, dir_fd=directory, follow_symlinks=False).st_mode):
        _rename_exclusive(name, destination, source_directory=directory)
    else:
        os.link(name, destination, src_dir_fd=directory, follow_symlinks=False)
        os.unlink(name, dir_fd=directory)


def _delete_child_at(operation: _Operation, directory: int, moved: str, child: _Entry) -> None:
    """Inside this operation's own moved directory, delete a recorded child."""
    inner = os.open(moved, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
    try:
        try:
            info = os.stat(child.path.name, dir_fd=inner, follow_symlinks=False)
        except FileNotFoundError:
            child.release()
            return
        if child.identified and operation.same(info, child.identity()):
            os.unlink(child.path.name, dir_fd=inner)
            child.release()
    finally:
        _close(inner)


def _inside(directory: Path, path: Path) -> bool:
    return path != directory and directory in path.parents


def _remove_recorded(operation: _Operation, record: list[_Entry]) -> None:
    """Remove recorded entries newest first. A directory that still holds one
    of this operation's entries it could not remove stays, and is reported."""
    while record:
        entry = record.pop()
        if entry.done:
            continue
        if entry.directory and any(_inside(entry.path, other) for other in operation.unfinished()):
            operation.leave(entry, "it still holds entries listed here")
            continue
        _settle(operation, entry)


class _Staging:
    """A private, uniquely named staging directory and the files made in it."""

    def __init__(self, entry: _Entry):
        self.entry = entry
        self.path = entry.path
        self.files: list[_Entry] = []
        self.published = False


def _remove_staging(operation: _Operation, staging: _Staging) -> None:
    """Delete the staged files in place first, then the directory (round 1).

    By the stated boundary no other process writes inside this operation's
    private, uniquely named staging directory, so its files are deleted there,
    each after its identity check, through the directory's own descriptor.
    That gives back the space the operation used before any later step of
    the rollback needs space, so a rollback on a full volume can begin.
    """
    entry = staging.entry
    remaining = []
    for child in reversed(staging.files):
        try:
            if entry.pin.descriptor is None:
                raise OSError(errno.EBADF, entry.reason or "the staging directory is not held open")
            info = os.stat(child.path.name, dir_fd=entry.pin.descriptor, follow_symlinks=False)
            if (info.st_dev, info.st_ino) == child.identity():
                os.unlink(child.path.name, dir_fd=entry.pin.descriptor)
            child.release()
        except FileNotFoundError:
            child.release()
        except OSError as error:
            child.reason = error.strerror or "it could not be deleted"
            remaining.append(child)
    staging.files = []
    entry.children = remaining
    if not remaining and entry.pin.descriptor is not None:
        # Round 2: a file whose creation took effect and still reported an
        # error was never recorded. Only this operation writes in its private
        # staging directory (the stated boundary), so it is this operation's.
        problem = _empty_private(entry)
        if problem is not None:
            operation.leave(entry, f"it could not be emptied ({problem})")
            return
    if remaining:
        operation.leave(entry, "it still holds files this operation could not delete")
        return
    _settle(operation, entry)


@contextmanager
def _private_staging(operation: _Operation, parent: Path, prefix: str) -> Iterator[_Staging]:
    """Stage in a recorded, pinned private directory; remove it only by moving it aside."""
    staging = None
    made: list[_Entry] = []
    try:
        staging = _Staging(_make_private_directory(operation, parent, prefix, made))
        if staging.entry.pin.descriptor is None:
            raise OSError(errno.EIO, staging.entry.reason)
        yield staging
    finally:
        if staging is None and made:
            staging = _Staging(made[0])  # it may exist although its mkdir failed
        if staging is not None and not staging.published:
            _remove_staging(operation, staging)


def _restore_command(model_id: str) -> str:
    return f"python -m livemorebio.model_assets restore {model_id}"


def _aside_code(model_id: str) -> str:
    return "CARDIAC_MODEL_ASIDE_PENDING" if model_id == "cardiac" else "aside_pending"


def _busy_refusal(model_id: str) -> ModelAssetError:
    if model_id == "cardiac":
        return ModelAssetError("CARDIAC_MODEL_INSTALL_BUSY",
                               "A cardiac installation is in progress; retry when it completes.")
    return ModelAssetError("busy", "Another model installation is in progress; retry when it completes.")


def _managed_install(path: Path) -> Path | None:
    """The managed install directory of a release's cardiac path, if it is one."""
    release = path.parents[3]
    if (path.parents[2].name == "source" and release.parent.name == "releases"
            and re.fullmatch(r"[0-9a-fA-F]{40}", release.name) is not None):
        return release.parent.parent
    return None


def _aside_parents(canonical: str) -> list[Path]:
    if canonical == "cardiac":
        _require_owner_semantics()
        path = _cardiac_path()
        parents = [path.parent, path.parents[1], path.parents[2]]
        install = _managed_install(path)
        if install is not None:
            parents += [install, install / "integrity"]
        return parents
    return [_model_root()]


def _record_anchors(canonical: str) -> list[Path]:
    """Where a rollback record may go: outside a managed release, whose digest
    covers every file in it; otherwise the highest directory first."""
    if canonical == "cardiac":
        path = _cardiac_path()
        install = _managed_install(path)
        return [install] if install is not None else [path.parents[2], path.parents[1], path.parent]
    return [_model_root()]


def _record_scope(canonical: str) -> Path:
    if canonical == "cardiac":
        path = _cardiac_path()
        return _managed_install(path) or path.parents[2]
    return _model_root()


def _owned_directory(path: Path | str, directory: int | None = None) -> bool:
    """A real directory (never a symlink) of this account."""
    try:
        info = os.stat(path, dir_fd=directory, follow_symlinks=False)
    except OSError:
        return False
    return stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid()


def _mode_changed(directory: int) -> str | None:
    """Why restore will not act inside a rollback directory: it is made 0700,
    and one whose mode changed may hold what another program put there."""
    info = os.fstat(directory)
    if _private_mode(info.st_mode):
        return None
    return (f"its mode is {stat.S_IMODE(info.st_mode):04o}, not the 0700 a rollback gives it; if a "
            "rollback made it, set its mode to 0700, otherwise remove it")


def _pending(canonical: str, *, strict: bool = False) -> list[tuple[Path, str]]:
    """Aside directories and rollback records an earlier operation left; read-only.

    Only real directories of this account with the exact names a rollback
    gives count (its kind, identity, process and a random part), so a symlink,
    a file or another program's directory is never reported or touched
    (round 1). One whose mode changed is still reported; restore refuses it.

    L0-R13: `strict` (restore) raises OSError, naming the directory, when one
    that may hold such state cannot be opened or listed, or such an entry
    cannot be read. Only a directory that is absent, or a name that is not a
    directory (a symlink is never followed), holds nothing.
    """
    found = []
    for parent in _aside_parents(canonical):
        # Round 3: a symlink put at a parent's name is never followed, and
        # each name is read relative to the parent (no path past PATH_MAX).
        try:
            directory = os.open(parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        except (FileNotFoundError, NotADirectoryError):
            continue
        except OSError as error:
            if strict and error.errno != errno.ELOOP:
                raise OSError(error.errno, error.strerror, str(parent)) from None
            continue
        try:
            try:
                names = os.listdir(directory)
            except OSError as error:
                if strict:
                    raise OSError(error.errno, error.strerror, str(parent)) from None
                continue
            for name in sorted(names):
                kind = ("aside" if _ASIDE_NAME.fullmatch(name)
                        else "record" if _RECORD_NAME.fullmatch(name) else None)
                if kind is None:
                    continue
                if strict:
                    try:
                        info = os.stat(name, dir_fd=directory, follow_symlinks=False)
                    except FileNotFoundError:
                        continue
                    except OSError as error:
                        raise OSError(error.errno, error.strerror, str(parent / name)) from None
                    owned = stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid()
                else:
                    owned = _owned_directory(name, directory)
                if owned:
                    found.append((parent / name, kind))
        finally:
            _close(directory)
    return found


def _read_record(directory: int) -> dict[str, Any] | None:
    """A rollback record, read through its directory's descriptor."""
    try:
        descriptor = os.open(_RECORD_FILE, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
    except OSError:
        return None
    try:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_size > 1 << 20:
            return None
        data = b""
        while chunk := os.read(descriptor, 1 << 16):
            data += chunk
            if len(data) > 1 << 20:
                return None
    except OSError:
        return None
    finally:
        _close(descriptor)
    try:
        document = json.loads(data)
    except (ValueError, UnicodeError, RecursionError):
        return None

    def number(value: Any, nullable: bool) -> bool:
        return type(value) is int or (nullable and value is None)

    def valid(item: Any, child: bool) -> bool:
        return (isinstance(item, dict)
                and isinstance(item.get("name" if child else "path"), str)
                and number(item.get("device"), not child) and number(item.get("inode"), not child)
                and (item.get("pin") is None or isinstance(item.get("pin"), str))
                and (child or (type(item.get("directory")) is bool
                               and type(item.get("private", False)) is bool
                               and type(item.get("until_commit", False)) is bool
                               and isinstance(item.get("children"), list)
                               and all(valid(value, True) for value in item["children"]))))

    commit = document.get("commit") if isinstance(document, dict) else None
    if (not isinstance(document, dict) or document.get("schema_version") != "livemore.rollback-record.v1"
            or not isinstance(document.get("entries"), list)
            or not all(valid(item, False) for item in document["entries"])
            or not number(document.get("record_device"), True)
            or not (commit is None or (isinstance(commit, dict) and isinstance(commit.get("path"), str)
                                       and isinstance(commit.get("pin"), str)))):
        return None
    return document


def _record_entries(record: Path) -> list[str]:
    try:
        directory = os.open(record, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    except OSError:
        return []
    try:
        return [item["path"] for item in (_read_record(directory) or {}).get("entries", [])]
    finally:
        _close(directory)


def _no_space(error: OSError) -> bool:
    return error.errno in (errno.ENOSPC, errno.EDQUOT)


def _make_record_directory(parent: Path) -> Path:
    for _ in range(100):
        candidate = parent / f"{_RECORD_PREFIX}{os.getpid()}-{secrets.token_hex(4)}"
        try:
            _mkdir_private(candidate)
        except FileExistsError:
            continue
        return candidate
    raise FileExistsError(errno.EEXIST, "No unused record name was found.")


def _discard_record_directory(directory: Path, descriptor: int | None = None,
                              known: tuple[int, int] | None = None) -> None:
    """Remove this operation's own record directory once nothing in it is
    needed: the record file first, then the other files it makes there. If the
    record file cannot be removed, the directory is left whole, so the record
    still names what it lists and the pins that prove it (round 2), and restore
    finishes it. A record directory holding only this product's files and no
    record is what restore reports as stopped, and removes.

    Round 3: its files are removed through its own descriptor, never by a path
    another process may have given another directory, and the directory itself
    is removed by identity, as every other entry is (`_remove_own_directory`).
    """
    if descriptor is not None:
        try:
            names = os.listdir(descriptor)
        except OSError:
            return
        if _RECORD_FILE in names:
            try:
                os.unlink(_RECORD_FILE, dir_fd=descriptor)
            except FileNotFoundError:
                pass
            except OSError:
                return
        for name in names:
            if name != _RECORD_FILE and _own_record_name(name):
                try:
                    os.unlink(name, dir_fd=descriptor)
                except OSError:
                    pass
    _remove_own_directory(directory, descriptor, known)


def _remove_own_directory(path: Path, descriptor: int | None, known: tuple[int, int] | None = None) -> str:
    """Remove a private directory of this product by its identity (round 3):
    moved aside from its name, or from the name another program renamed it
    to, and removed only if it is the one held open and empty. A directory
    another program put at its name is never touched. What cannot be removed
    stays; check reports it, and restore finishes it."""
    entry = _Entry(path, _Pin(descriptor, owned=False), True, known=known)
    return _settle(_Operation("record"), entry)


def _refuse_pending_aside(model_id: str) -> None:
    canonical = _canonical(model_id)
    if canonical == "recon3d":
        return
    pending = _pending(canonical)
    if not pending:
        return
    if _installer_busy(canonical, pending):
        raise _busy_refusal(canonical)
    described = []
    for path, kind in pending:
        if kind == "aside":
            described.append(f"an aside directory {path}")
        else:
            entries = _record_entries(path)
            described.append(f"entries left at {', '.join(entries)} (recorded in {path})" if entries
                             else f"an operation that did not finish ({path})")
    raise ModelAssetError(
        _aside_code(canonical),
        "An earlier rollback did not finish: " + "; ".join(described)
        + f". Run `{_restore_command(canonical)}` to finish it; it deletes only what that "
        "operation made, puts back anything else and never replaces an existing entry.",
    )


def _flock_held(lock: Path, *, shared: bool = False, follow: bool = False) -> bool:
    """Whether another holds a lock on it: exclusively, or (shared) at all."""
    import fcntl

    try:
        descriptor = os.open(lock, os.O_RDONLY | os.O_NONBLOCK | (0 if follow else os.O_NOFOLLOW))
    except OSError:
        return False
    try:
        fcntl.flock(descriptor, (fcntl.LOCK_SH if shared else fcntl.LOCK_EX) | fcntl.LOCK_NB)
    except BlockingIOError:
        return True
    except OSError:
        return False
    else:
        _unlock(descriptor)
        return False
    finally:
        _close(descriptor)


def _holds_locked_directory(aside: Path) -> bool:
    """Whether an aside directory holds a directory another holds locked: a
    live operation's own record directory, being removed (round 3)."""
    import fcntl

    try:
        parent = os.open(aside.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    except OSError:
        return False
    try:
        try:
            directory = os.open(aside.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
        except OSError:
            return False
        try:
            try:
                names = os.listdir(directory)
            except OSError:
                return False
            for name in names:
                try:
                    inner = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_NONBLOCK,
                                    dir_fd=directory)
                except OSError:
                    continue
                try:
                    fcntl.flock(inner, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    return True
                except OSError:
                    continue
                else:
                    _unlock(inner)
                finally:
                    _close(inner)
            return False
        finally:
            _close(directory)
    finally:
        _close(parent)


def _recorded_pins(pending: list[tuple[Path, str]]) -> set[tuple[int, int]]:
    """The identities of the files pinned in the pending rollback records."""
    pins = set()
    for path, kind in pending:
        if kind != "record":
            continue
        try:
            directory = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        except OSError:
            continue
        try:
            for name in os.listdir(directory):
                if name.startswith(_PIN_PREFIX):
                    info = os.stat(name, dir_fd=directory, follow_symlinks=False)
                    pins.add((info.st_dev, info.st_ino))
        except OSError:
            pass
        finally:
            _close(directory)
    return pins


def _lock_pid(directory: int) -> str | None:
    """The first line of an installer lock's pid file, as install.sh reads it;
    None while there is none yet (no file, or an empty one)."""
    try:
        descriptor = os.open("pid", os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
    except FileNotFoundError:
        return None
    except OSError:
        return ""  # unreadable: install.sh reads no pid from it
    try:
        data = os.read(descriptor, 64)
    except OSError:
        return ""
    finally:
        _close(descriptor)
    return data.split(b"\n", 1)[0].decode("ascii", "replace") if data else None


def _process_live(text: str) -> bool:
    """install.sh's test of a lock's pid: digits naming a process that exists (kill -0)."""
    if re.fullmatch(r"[0-9]{1,9}", text) is None or int(text) == 0:
        return False
    try:
        os.kill(int(text), 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _managed_lock_held(canonical: str, pending: list[tuple[Path, str]]) -> bool:
    """Whether another installer holds the managed installer lock, by
    install.sh's own protocol (L0-R13): `.install.lock` is a directory whose
    pid file names a live process. install.sh writes that pid right after its
    mkdir, so a lock with no pid yet is waited on for `_INSTALLER_PID_WAIT`.
    A lock holding the pid file a stopped operation recorded (one of its pins)
    is that operation's own, for restore to finish, whatever process has that
    number now (round 3)."""
    if canonical != "cardiac":
        return False
    install = _managed_install(_cardiac_path())
    if install is None:
        return False
    try:
        directory = os.open(install / ".install.lock", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    except OSError:
        return False  # no lock directory: no installer holds it
    try:
        own = _recorded_pins(pending)
        deadline = time.monotonic() + _INSTALLER_PID_WAIT
        while True:
            try:
                info = os.stat("pid", dir_fd=directory, follow_symlinks=False)
            except FileNotFoundError:
                info = None
            except OSError:
                return False  # install.sh reads no pid from it either
            if info is not None and (info.st_dev, info.st_ino) in own:
                return False
            text = _lock_pid(directory) if info is not None else None
            if text is not None:
                return _process_live(text)
            if time.monotonic() >= deadline:
                return False
            time.sleep(0.02)
    finally:
        _close(directory)


def _installer_busy(canonical: str, pending: list[tuple[Path, str]]) -> bool:
    """Whether what was found is a live operation's, rather than one to finish.

    Round 3: decided only by locks the kernel releases when their holder
    ends, never by a process id, which another process may have taken since:
    - an installation holds its record directory's lock from before it acts
      until it ends (round 2), and while that directory is being removed it
      is still held, inside its aside directory;
    - from before it makes the record directory until it holds that lock, it
      holds the lock of the directory it makes it in, so the new, empty
      directory is never taken for one a stopped operation left.
    """
    for anchor in _record_anchors(canonical):
        if _flock_held(anchor, shared=True, follow=True):
            return True
    for path, kind in pending:
        if kind == "record" and _flock_held(path):
            return True
        if kind == "aside" and _holds_locked_directory(path):
            return True
    return False


def check(model_id: str = "human-gem") -> dict[str, Any]:
    """Status, refused while an earlier rollback's aside entry is pending."""
    _refuse_pending_aside(model_id)
    return status(model_id)


def _restore_aside(aside: Path, restored: list[str], removed: list[str], refused: list[str]) -> bool:
    """Finish one aside directory: delete this operation's entry, put back any
    other. Returns whether the aside directory is still there (L0-R13: one
    that cannot be removed is named in the refusal, with the restore command).

    Round 2: identity is compared on the volume as it is mounted now. The
    entry inside was moved there with one rename, so it is on the aside
    directory's own volume; a volume attached again gets a new device number
    and keeps its inode numbers, so only the inode is compared with the name.
    The `old` verdict is decided by the pin of the new integrity record kept
    in the aside directory, never by an inode number that may be free.

    Round 3: the name may hold a byte-identical copy of the new record, which
    another program wrote over it (install.sh rewrites a record that way); the
    admission committed all the same, so the previous record is deleted. Every
    step is relative to the parent and aside directories' descriptors, so a
    symlink is never followed and no path is longer than the entry's own.
    """
    match = _ASIDE_NAME.fullmatch(aside.name)
    if match is None:
        return False
    verdict = match.group(1)
    first, second = (int(match.group(index), 16) for index in (3, 4))
    try:
        parent = os.open(aside.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    except OSError as error:
        refused.append(f"{aside} could not be opened ({error.strerror})")
        return True
    try:
        unfinished = False
        try:
            directory = os.open(aside.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
        except OSError as error:
            refused.append(f"{aside} could not be opened ({error.strerror})")
            return True
        try:
            info = os.fstat(directory)
            if not (stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid()):
                return True
            changed = _mode_changed(directory)
            if changed is not None:
                refused.append(f"{aside} is not finished: {changed}")
                return True
            device = info.st_dev
            names = sorted(os.listdir(directory))
            new_record = new_bytes = None
            if verdict == "old" and _NEW_RECORD_PIN in names:
                names.remove(_NEW_RECORD_PIN)
                new_record = os.stat(_NEW_RECORD_PIN, dir_fd=directory, follow_symlinks=False)
                new_bytes = _record_bytes(_NEW_RECORD_PIN, directory)
            for name in names:
                moved, destination = aside / name, aside.parent / name
                try:
                    entry = os.stat(name, dir_fd=directory, follow_symlinks=False)
                    try:
                        at_name = os.stat(name, dir_fd=parent, follow_symlinks=False)
                    except FileNotFoundError:
                        at_name = None
                    if verdict == "own":
                        ours = (entry.st_dev, entry.st_ino) == (device, first)
                    else:
                        # The previous integrity record: delete it only once the
                        # new record, held by its pin here, is at its name, or a
                        # byte-identical copy of it is (round 3).
                        ours = new_record is not None and at_name is not None and (
                            os.path.samestat(at_name, new_record)
                            or (new_bytes is not None and stat.S_ISREG(at_name.st_mode)
                                and _record_bytes(name, parent) == new_bytes))
                    if ours and _delete_aside_entry(directory, name, entry, device, second):
                        removed.append(str(destination))
                        continue
                    if at_name is not None and os.path.samestat(at_name, entry):
                        os.unlink(name, dir_fd=directory)  # an earlier restore already linked it back
                    elif stat.S_ISDIR(entry.st_mode):
                        _rename_exclusive(name, destination, source_directory=directory)
                    else:
                        os.link(name, name, src_dir_fd=directory, dst_dir_fd=parent, follow_symlinks=False)
                        os.unlink(name, dir_fd=directory)
                    restored.append(str(destination))
                except FileExistsError:
                    unfinished = True
                    refused.append(f"the name {destination} is still taken; the entry stays at {moved}")
                except OSError as error:
                    unfinished = True
                    refused.append(f"{moved} could not be settled ({error.strerror}); it stays there")
            if new_record is not None and not unfinished:
                os.unlink(_NEW_RECORD_PIN, dir_fd=directory)  # this operation's own extra link
        finally:
            _close(directory)
        if unfinished:
            return True
        try:
            os.rmdir(aside.name, dir_fd=parent)
        except FileNotFoundError:
            return False
        except OSError as error:
            # L0-R13: never a silent leftover, and never a false "restored".
            refused.append(f"{aside} could not be removed ({error.strerror}); it is empty, and the next "
                           "restore removes it")
            return True
        return False
    finally:
        _close(parent)


def _record_bytes(name: Path | str, directory: int | None = None) -> bytes | None:
    """A small regular file's bytes, read without following a symlink; None
    when the name holds anything else (round 3: an integrity record is
    compared by content as well as by identity)."""
    try:
        descriptor = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
    except OSError as error:
        if error.errno == errno.ELOOP:
            return None
        raise
    try:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode) or info.st_size > 4096:
            return None
        return os.pread(descriptor, 4097, 0)
    finally:
        _close(descriptor)


def _delete_aside_entry(directory: int, name: str, info: os.stat_result, device: int, child: int) -> bool:
    """Delete this operation's own entry from its aside directory; False when it
    is a directory that holds entries this operation did not create."""
    if not stat.S_ISDIR(info.st_mode):
        os.unlink(name, dir_fd=directory)
        return True
    inner = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
    try:
        if child:
            for member in os.listdir(inner):
                found = os.stat(member, dir_fd=inner, follow_symlinks=False)
                if (found.st_dev, found.st_ino) == (device, child):
                    os.unlink(member, dir_fd=inner)
    finally:
        _close(inner)
    try:
        os.rmdir(name, dir_fd=directory)
    except OSError as error:
        if error.errno in (errno.ENOTEMPTY, errno.EEXIST):
            return False
        raise
    return True


def _in_scope(scope: Path, path: Path) -> Path | None:
    """`path` spelled under this model's directory, or None outside it.

    Round 2: the record keeps a path as the root was spelled when it was made.
    The same directory may be spelled through a symlinked parent or, on a
    case-insensitive volume, in another case, so the parent that is this
    model's directory is found by identity, and the rest is spelled under it.
    """
    if _inside(scope, path):
        return path
    try:
        target = os.stat(scope)
    except OSError:
        return None
    for ancestor in path.parents:
        try:
            if os.path.samestat(os.stat(ancestor), target):
                return scope / path.relative_to(ancestor)
        except OSError:
            continue
    return None


def _unlock(descriptor: int) -> None:
    """Release a record directory's lock, whatever its close reports."""
    import fcntl

    try:
        fcntl.flock(descriptor, fcntl.LOCK_UN)
    except OSError:
        pass


def _record_lock(directory: int) -> bool:
    """Take the record directory's lock for this restore; False while an
    installation holds it."""
    import fcntl

    try:
        fcntl.flock(directory, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        return False
    return True


def _restore_record(operation: _Operation, record: Path, canonical: str, removed: list[str],
                    occupied: list[str], stopped: list[str], refused: list[str],
                    finished: list[str], asides: list[Path]) -> None:
    """Finish what a rollback record lists, newest first, then remove the record.

    Round 2: an entry that cannot be finished is never dropped. It is named in
    the refusal, the record stays for the next restore, and so does every
    directory that holds it. The record file is removed last, so a restore cut
    short always leaves a record that names what is left.
    """
    try:
        directory = os.open(record, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    except OSError as error:
        refused.append(f"{record} could not be opened ({error.strerror})")
        return
    try:
        info = os.fstat(directory)
        if not (stat.S_ISDIR(info.st_mode) and info.st_uid == os.getuid()):
            return
        changed = _mode_changed(directory)
        if changed is not None:
            refused.append(f"{record} is not finished: {changed}")
            return
        if not _record_lock(directory):
            refused.append(f"{record} belongs to an installation that is still running")
            return
        names = os.listdir(directory)
        if _RECORD_FILE not in names:
            if all(_own_record_name(name) for name in names):
                # Stopped (SIGKILL, power loss) before it recorded anything it
                # made: only this product's own files are here.
                _remove_record_files(directory, names, refused)
                if _RECORD_FILE in os.listdir(directory) or any(
                        _own_record_name(name) for name in os.listdir(directory)):
                    return
                stopped.append(str(record))
            else:
                refused.append(f"{record} holds no readable rollback record; it is left as it is")
                return
        else:
            document = _read_record(directory)
            if document is None:
                refused.append(f"{record} holds no readable rollback record; it is left as it is")
                return
            if not _restore_entries(operation, record, directory, document, canonical, removed, occupied, refused,
                                    asides):
                return
            # Every entry is finished, so the record goes first: if a later file
            # cannot be removed, what is left holds no record and only this
            # product's own files, which the next restore removes as stopped.
            _remove_record_files(directory, os.listdir(directory), refused, record_first=True)
            others = [name for name in os.listdir(directory) if not _own_record_name(name)]
            if others:
                refused.append(f"{record} holds {', '.join(sorted(others))}, which no rollback makes; "
                               "it is left as it is")
            if os.listdir(directory):
                return
        # Round 3: by identity, through the descriptor it holds locked, never
        # by a name another program may have given another directory.
        if _remove_own_directory(record, directory) in ("deleted", "absent"):
            finished.append(str(record))
        else:
            refused.append(f"{record} could not be removed")
    finally:
        _unlock(directory)
        _close(directory)


def _remove_record_files(directory: int, names: list[str], refused: list[str], *,
                         record_first: bool = False) -> None:
    """Remove this product's own files from a finished record directory."""
    for name in sorted(names, key=lambda name: (name == _RECORD_FILE) != record_first):
        if not _own_record_name(name):
            continue
        try:
            os.unlink(name, dir_fd=directory)
        except FileNotFoundError:
            continue
        except OSError as error:
            refused.append(f"{name} in the record could not be removed ({error.strerror})")
            return


def _restore_entries(operation: _Operation, record: Path, directory: int, document: dict[str, Any],
                     canonical: str, removed: list[str], occupied: list[str], refused: list[str],
                     asides: list[Path]) -> bool:
    """Settle every recorded entry, newest first; True when none is left. A
    recorded directory that holds an aside directory restore could not finish
    (`asides`) stays recorded, for the next restore (L0-R13)."""
    scope = _record_scope(canonical)
    current_device = os.fstat(directory).st_dev
    record_device = document.get("record_device")
    # Round 3: each entry's directory is found by the identities the record
    # lists, on the volume as it is mounted now, and a managed release is
    # searched for other names of this operation's files.
    operation.scope = scope
    operation.device_of = lambda device: current_device if device == record_device else device
    operation.directories = _recorded_directories(document, scope)
    operation.private = [(item["device"], item["inode"]) for item in document["entries"]
                         if item["directory"] and item.get("private") and item["inode"] is not None
                         and item["device"] is not None]
    model = _cardiac_path() if canonical == "cardiac" else None
    operation.release = model.parents[3] if model is not None and _managed_install(model) else None
    committed: bool | None = False
    if document.get("commit") is not None:
        committed = _commit_state(directory, document["commit"], scope, refused, record)
    unfinished: list[Path] = []
    for item in reversed(document["entries"]):
        path = _in_scope(scope, Path(item["path"]))
        if path is None:
            refused.append(f"{record} names {item['path']}, outside this model's directories; it is not touched")
            unfinished.append(Path(item["path"]))
            continue
        if item.get("until_commit"):
            if committed is True:
                continue  # admission committed: it is part of the release now
            if committed is None:
                unfinished.append(path)
                continue
        if item["directory"] and any(_inside(path, other) for other in unfinished + asides):
            refused.append(f"{path} still holds an entry listed above; it stays for the next restore")
            unfinished.append(path)
            continue
        entry, problem = _recorded_entry(operation, directory, item, path)
        if problem is not None:
            refused.append(f"{path} could not be finished: {problem}")
            unfinished.append(path)
            continue
        if entry is None:
            continue  # gone, or another program's entry holds the name now
        if entry.private:
            problem = _empty_private(entry)
            if problem is not None:
                refused.append(f"{path} could not be emptied: {problem}")
                unfinished.append(path)
                continue
        before = (len(operation.kept), len(operation.left))
        outcome = _settle(operation, entry)
        if outcome == "occupied":
            # Not a failure: it now holds entries that operation did not
            # create, so it stays, and nothing is left to finish for it.
            operation.left.pop()
            occupied.append(str(entry.where or path))
        elif (len(operation.kept), len(operation.left)) != before:
            unfinished.extend(entry.found or [path])
        elif outcome == "deleted":
            removed.append(str(entry.where or path))
    return not unfinished


def _recorded_directories(document: dict[str, Any], scope: Path) -> dict[str, tuple[int, int]]:
    """The identity of each directory on the recorded paths, by its path below the scope."""
    known: dict[str, tuple[int, int]] = {}
    directories = document.get("directories")
    if isinstance(directories, dict):
        for key, identity in directories.items():
            if (isinstance(key, str) and isinstance(identity, list) and len(identity) == 2
                    and all(type(value) is int for value in identity)):
                known[key] = (identity[0], identity[1])
    for item in document["entries"]:
        if item["directory"] and item["inode"] is not None and item["device"] is not None:
            path = _in_scope(scope, Path(item["path"]))
            if path is not None:
                known[path.relative_to(scope).as_posix()] = (item["device"], item["inode"])
    return known


def _commit_state(directory: int, commit: dict[str, str], scope: Path, refused: list[str],
                  record: Path) -> bool | None:
    """Whether the managed admission committed: its integrity record's name
    holds the new record, which the record directory pins."""
    path = _in_scope(scope, Path(commit["path"]))
    try:
        pinned = os.stat(commit["pin"], dir_fd=directory, follow_symlinks=False)
        if path is None:
            raise OSError(errno.EXDEV, "it is outside this model's directories")
        at_name = os.lstat(path)
    except FileNotFoundError as error:
        if error.filename is None or path is None or Path(error.filename) != path:
            refused.append(f"{record} cannot tell whether admission committed: its new record is missing")
            return None
        return False
    except OSError as error:
        refused.append(f"{record} cannot tell whether admission committed ({error.strerror})")
        return None
    if os.path.samestat(at_name, pinned):
        return True
    # Round 3: another program may have rewritten the record with the same
    # bytes (a temporary renamed over it, as install.sh does). The release's
    # record then still lists what admission added: it committed.
    if not stat.S_ISREG(at_name.st_mode):
        return False
    try:
        new_bytes = _record_bytes(commit["pin"], directory)
        held = _record_bytes(path)
    except OSError as error:
        refused.append(f"{record} cannot tell whether admission committed ({error.strerror})")
        return None
    return new_bytes is not None and held == new_bytes


def _empty_private(entry: _Entry) -> str | None:
    """Delete every file in a recorded private staging directory: by the
    stated boundary only that operation wrote in it. Through its descriptor."""
    try:
        descriptor = entry.pin.descriptor
        if descriptor is None:
            return "it is not held open"
        if not _private_mode(os.fstat(descriptor).st_mode):
            return "its mode is no longer the 0700 it was made with"
        for name in os.listdir(descriptor):
            if not stat.S_ISDIR(os.stat(name, dir_fd=descriptor, follow_symlinks=False).st_mode):
                os.unlink(name, dir_fd=descriptor)
    except OSError as error:
        return error.strerror or "it could not be read"
    return None


def _recorded_entry(operation: _Operation, directory: int, item: dict[str, Any],
                    path: Path) -> tuple[_Entry | None, str | None]:
    """The recorded entry, identified again, or why it cannot be.

    A file is identified by its pin, a hard link in the record directory that
    keeps its inode from reuse; reading the pin needs no read permission on
    the file. A directory is opened and matched by its inode, on the device
    the record directory is on now (a remounted volume has a new number;
    `operation.same`). A directory recorded before its mkdir has no identity:
    whatever directory holds the name is settled, so only an empty one is
    removed.
    """
    def pinned(name: str | None, inode: int | None) -> tuple[tuple[int, int] | None, str | None]:
        if name is None or inode is None:
            return None, "the record holds no pin for it"
        try:
            info = os.stat(name, dir_fd=directory, follow_symlinks=False)
        except OSError as error:
            return None, f"its pin in the record could not be read ({error.strerror})"
        if not stat.S_ISREG(info.st_mode) or info.st_ino != inode:
            return None, "its pin in the record is not the recorded file"
        return (info.st_dev, info.st_ino), None

    if not item["directory"]:
        identity, problem = pinned(item.get("pin"), item.get("inode"))
        if identity is None:
            return None, problem
        name = item.get("pin")
        return _Entry(path, _Pin(None), False, known=identity, disk_pin=name,
                      links=lambda: os.stat(name, dir_fd=directory, follow_symlinks=False).st_nlink), None
    # Round 3: found by identity below the scope, so a directory another
    # program renamed is found and a symlink at its name is never followed.
    parent = _locate(operation, path)
    if parent is None:
        return None, None
    name = path.name
    if item["inode"] is not None:
        name = _directory_name(operation, parent, path.name, (item["device"], item["inode"]),
                               private=bool(item.get("private")))
        if name is None:
            return None, None
    located = parent / name
    try:
        descriptor = os.open(located, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    except (FileNotFoundError, NotADirectoryError):
        return None, None
    except OSError as error:
        if error.errno == errno.ELOOP:
            return None, None  # a symlink holds the name: not that operation's directory
        return None, f"it could not be opened ({error.strerror})"
    pin = operation.pin(descriptor)
    info = os.fstat(descriptor)
    if item["inode"] is not None and not operation.same(info, (item["device"], item["inode"])):
        pin.release()
        return None, None
    path = located
    children = []
    for child in item["children"]:
        if child.get("pin") is None:
            continue  # a file of a private staging directory: emptied with it
        identity, problem = pinned(child.get("pin"), child.get("inode"))
        if identity is None:
            # Round 2: never dropped; without it the directory could not be
            # told apart from one holding another program's entries.
            pin.release()
            return None, f"{child['name']} in it could not be identified: {problem}"
        children.append(_Entry(path / child["name"], _Pin(None), False, known=identity))
    if item["inode"] is None and children:
        # L0-R13: recorded before its mkdir, with its pid: the managed lock.
        # Another installer's lock at its name is never adopted.
        try:
            own = _planned_lock_is_own(descriptor, [child.known for child in children if child.known])
        except OSError as error:
            pin.release()
            return None, f"whether it is that operation's could not be read ({error.strerror})"
        if not own:
            pin.release()
            return None, None
    return _Entry(path, pin, True, children,
                  private=bool(item.get("private")) and item["inode"] is not None), None


def restore(model_id: str = "human-gem") -> dict[str, Any]:
    """Finish what an earlier rollback could not (L0-R11).

    This operation's own entries, identified by the aside directory's name or
    the rollback record, are deleted; anything else is put back with a
    no-overwrite link. Refused while an installation is running. Round 2: an
    I/O error never escapes as a traceback; it is named in the refusal.
    """
    canonical = _canonical(model_id)
    if canonical == "recon3d":
        _require_human(model_id)
    restored: list[str] = []
    removed: list[str] = []
    occupied: list[str] = []
    stopped: list[str] = []
    refused: list[str] = []
    finished: list[str] = []
    with _operation(canonical, records_left=False) as operation:
        try:
            # L0-R13: a directory that may hold recovery state and cannot be
            # read is a refusal of its own, never "nothing pending".
            pending = _pending(canonical, strict=True)
        except OSError as error:
            where = f" in {error.filename}" if error.filename else ""
            raise ModelAssetError(
                "CARDIAC_MODEL_UNSAFE_PATH" if canonical == "cardiac" else "unsafe_path",
                f"Restore could not read the recovery state{where} ({error.strerror}); nothing was changed. "
                f"Fix the cause, then run `{_restore_command(canonical)}` again.") from None
        # L0-R13: install.sh's own lock counts too (its locking protocol).
        if pending and (_installer_busy(canonical, pending) or _managed_lock_held(canonical, pending)):
            raise _busy_refusal(canonical)
        asides: list[Path] = []
        for path, kind in pending:
            if kind == "aside":
                try:
                    if _restore_aside(path, restored, removed, refused):
                        asides.append(path)
                except OSError as error:
                    refused.append(f"{path} could not be finished ({error.strerror})")
                    asides.append(path)
        for path, kind in pending:
            if kind == "record":
                try:
                    _restore_record(operation, path, canonical, removed, occupied, stopped, refused, finished,
                                    asides)
                except OSError as error:
                    refused.append(f"{path} could not be finished ({error.strerror})")
        if operation.kept or operation.left:
            refused.extend(f"{entry.path} could not be removed ({entry.reason})" for entry in operation.left)
            refused.extend(f"an entry stays in {aside}" for aside in operation.kept)
            operation.kept.clear()
            operation.left.clear()
    if refused:
        raise ModelAssetError(
            _aside_code(canonical),
            "Restore refused: " + "; ".join(refused)
            + f". Free the name or fix the cause, then run `{_restore_command(canonical)}` again.",
        )
    return {
        "model_id": canonical,
        "state": "restored" if restored or removed or stopped or finished else "nothing_pending",
        "restored": restored,
        "removed": removed,
        # Directories that operation made which now hold entries it did not
        # create; they stay where they are.
        "kept_in_place": occupied,
        # Operations stopped (for example by SIGKILL or power loss) before they
        # recorded anything they made: only their reserve was removed (round 2:
        # the record now lists each entry before it is made).
        "stopped_without_record": stopped,
    }


@contextmanager
def _installation_lock(root: Path, operation: _Operation | None = None,
                       record: list[_Entry] | None = None) -> Iterator[None]:
    import fcntl

    lock = root / ".install.lock"
    owned = True
    try:
        if operation is not None and record is not None and operation.managed:
            # Round 2: in a managed release it is made in the record directory,
            # recorded, then linked to its name (record before act).
            fd = _create_recorded_file(operation, lock, record, until_commit=True, flags=os.O_RDWR)
        else:
            # L0-R11: exclusive creation proves this operation made the lock, and
            # it is recorded before any check of its permissions can raise.
            fd = _create_private_file(lock, os.O_RDWR, operation if record is not None else None, record)
        owned = record is None
    except FileExistsError:
        fd = _private_fd(lock, os.O_RDWR)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ModelAssetError(
                "busy",
                "Another model installation is in progress; retry when it completes.",
            ) from None
        except OSError:
            raise ModelAssetError("unsafe_path", "The model installation lock could not be taken.") from None
        try:
            yield
        finally:
            _unlock(fd)
    finally:
        if owned:
            _close(fd)


def _hash_file(path: Path, maximum: int) -> tuple[str, int]:
    if not _entry_exists(path, "corrupt", "Installed model package failed integrity verification: "
                                          "a required file could not be read."):
        raise ModelAssetError(
            "corrupt",
            "Installed model package failed integrity verification: a required file is missing.",
        )
    fd = _private_fd(path)
    try:
        with os.fdopen(fd, "rb") as handle:
            if os.fstat(handle.fileno()).st_size > maximum:
                raise ModelAssetError(
                    "corrupt",
                    "Installed model package failed integrity verification: file size mismatch.",
                )
            digest = hashlib.sha256()
            count = 0
            while chunk := handle.read(min(_CHUNK_BYTES, maximum + 1 - count)):
                count += len(chunk)
                if count > maximum:
                    raise ModelAssetError(
                        "corrupt",
                        "Installed model package failed integrity verification: file size mismatch.",
                    )
                digest.update(chunk)
    except OSError:
        raise ModelAssetError(
            "corrupt",
            "Installed model package failed integrity verification: file read failed.",
        ) from None
    return digest.hexdigest(), count


def _verify(root: Path, manifest: dict[str, Any]) -> Path:
    package = root / _PACKAGE
    if not _entry_exists(package, "unsafe_path", "The installed model package could not be read; "
                                                  "check the cache's permissions."):
        raise ModelAssetError(
            "missing",
            "Pinned Human-GEM assets are not installed. Run the model install command.",
        )
    _assert_directory(package)
    for item in _HUMAN_ASSETS:
        digest, count = _hash_file(package / item.filename, item.size_bytes)
        if digest != item.sha256 or count != item.size_bytes:
            raise ModelAssetError(
                "corrupt",
                "Installed model package failed integrity verification: pinned digest or byte count mismatch.",
            )
    receipt_path = package / "installation.json"
    _hash_file(receipt_path, 32768)
    try:
        with os.fdopen(_private_fd(receipt_path), "r", encoding="utf-8") as handle:
            receipt = json.loads(handle.read(32769))
        if (
            not isinstance(receipt, dict)
            or receipt.get("schema_version") != "livemore.model-installation.v1"
            or receipt.get("manifest_sha256") != _digest(manifest)
            or receipt.get("model_id") != "human-gem"
            or receipt.get("commit") != _COMMIT
            or receipt.get("assets") != manifest["assets"]
        ):
            raise ValueError("receipt mismatch")
        acquired = datetime.fromisoformat(receipt["acquired_at"])
        if acquired.tzinfo is None:
            raise ValueError("timezone absent")
    except (OSError, ValueError, TypeError, KeyError, UnicodeError, RecursionError):
        raise ModelAssetError(
            "corrupt",
            "Installed model package failed integrity verification: invalid receipt.",
        ) from None
    return package


def _status_record(manifest: dict[str, Any], state: str, reason: str) -> dict[str, Any]:
    return {
        "model_id": manifest["model_id"],
        "release": manifest["release"],
        "available": state == "verified",
        "state": state,
        "reason": reason,
        "model_sha256": manifest.get("assets", {}).get("xml", {}).get("sha256"),
        "manifest_sha256": _digest(manifest),
        "manifest": manifest,
        "install_command": (
            _INSTALL_COMMAND if manifest["model_id"] == "human-gem" else None
        ),
        "readiness_scope": "asset_integrity_and_source_permission_only; solver and scientific qualification are separate",
    }


def status(model_id: str = "human-gem") -> dict[str, Any]:
    """Hash every required file, without writes/network; do not expose private paths."""
    if _canonical(model_id) == "cardiac":
        return cardiac_status()
    manifest = asset_manifest(model_id)
    try:
        _require_human(model_id)
        root = _model_root()
        _verify(root, manifest)
    except ModelAssetError as error:
        return _status_record(manifest, error.code, str(error))
    except OSError:
        # Round 3: whatever the filesystem reports is a status, never a traceback.
        return _status_record(manifest, "unsafe_path", "The model cache could not be read.")
    return _status_record(
        manifest,
        "verified",
        "All pinned reference assets and attribution are verified; model execution readiness is separate.",
    )


def verified_asset(model_id: str = "human-gem") -> dict[str, Any]:
    """Internal worker contract. Paths must never be returned from public APIs."""
    if _canonical(model_id) == "cardiac":
        path = verified_cardiac_path()
        return {"model_id": "cardiac", "xml_path": str(path),
                "model_sha256": _CARDIAC_ASSET.sha256, "manifest": _cardiac_manifest()}
    _require_human(model_id)
    manifest = asset_manifest(model_id)
    package = _verify(_model_root(), manifest)
    return {
        "model_id": "human-gem",
        "release": manifest["release"],
        "commit": _COMMIT,
        "model_sha256": manifest["assets"]["xml"]["sha256"],
        "manifest_sha256": _digest(manifest),
        "manifest": manifest,
        "xml_path": str(package / "Human-GEM.xml"),
        "gene_annotation_path": str(package / "genes.tsv"),
        "reaction_annotation_path": str(package / "reactions.tsv"),
        "metabolite_annotation_path": str(package / "metabolites.tsv"),
        "license": manifest["license"],
        "source_url": manifest["source_url"],
    }


def verified_model_path(model_id: str = "human-gem") -> Path:
    return Path(verified_asset(model_id)["xml_path"])


def execution_lock_path() -> Path:
    """Internal engine coordination path, never a public API response.

    The engine owns safe lock-file creation and holds its cross-process lock
    until its worker has been reaped. Returning a path does not acquire a lock.
    """
    return _model_root(create=True) / ".execution.lock"


def verified_asset_path(asset_id: str, model_id: str = "human-gem") -> Path:
    _require_human(model_id)
    if not isinstance(asset_id, str) or asset_id not in _SOURCE_PATHS:
        raise ModelAssetError("invalid_id", "Unknown pinned asset identifier.")
    package = _verify(_model_root(), asset_manifest(model_id))
    return package / _SOURCE_PATHS[asset_id][0]


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(
        self, request: Any, fp: Any, code: int, message: str, headers: Any, new_url: str
    ) -> None:
        raise urllib.error.HTTPError(
            request.full_url, code, "Redirect refused", headers, fp
        )


def pinned_source_urls() -> frozenset[str]:
    """The exact file URLs this module may download (the egress check's pinned vocabulary)."""
    return frozenset([*(item.source_url for item in _HUMAN_ASSETS), _CARDIAC_ASSET.source_url])


def _open_url(request: urllib.request.Request, timeout: float) -> Any:
    from .egress import urlopen
    # L0-R16: the egress check admits only the pinned model file URLs.
    return urlopen(request, timeout=timeout, opener=urllib.request.build_opener(_NoRedirect()))


def _download(
    item: AssetFile, path: Path, deadline: float, operation: _Operation | None = None,
    record: list[_Entry] | None = None,
) -> None:
    try:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError
        request = urllib.request.Request(
            item.source_url,
            headers={
                "User-Agent": "LivemoreBio-ModelAssets/1",
                "Accept": "application/octet-stream",
                "Accept-Encoding": "identity",
            },
        )
        with _open_url(request, min(10.0, remaining)) as response:
            if response.status != 200 or response.geturl() != item.source_url:
                raise ValueError("unexpected response")
            length = response.headers.get("Content-Length")
            if length is not None and (
                not length.isdigit() or int(length) != item.size_bytes
            ):
                raise ValueError("size header mismatch")
            if response.headers.get("Content-Encoding", "identity") not in (
                "identity",
                "",
            ):
                raise ValueError("unexpected encoding")
            try:
                fd = _create_private_file(path, os.O_WRONLY, operation, record)
            except FileExistsError:
                raise ModelAssetError(
                    "unsafe_path", "A model-cache file is inaccessible or unsafe."
                ) from None
            digest = hashlib.sha256()
            count = 0
            # With an operation, the operation owns the descriptor that pins the file.
            with os.fdopen(fd, "wb", closefd=operation is None) as output:
                while True:
                    _checkpoint()
                    if time.monotonic() >= deadline:
                        raise TimeoutError
                    chunk = response.read(
                        min(_CHUNK_BYTES, item.size_bytes + 1 - count)
                    )
                    if not chunk:
                        break
                    count += len(chunk)
                    if count > item.size_bytes:
                        raise ValueError("excess bytes")
                    output.write(chunk)
                    digest.update(chunk)
                if count != item.size_bytes or digest.hexdigest() != item.sha256:
                    raise ValueError("digest mismatch")
                output.flush()
                os.fsync(output.fileno())
    except (OSError, ValueError, urllib.error.URLError):
        raise ModelAssetError(
            "download",
            "Official model asset download failed: timeout, response, byte count or SHA256 verification. No package was published.",
        ) from None


def _sync_directory(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def install(model_id: str = "human-gem") -> dict[str, Any]:
    """Idempotent, bounded, fixed-source installation; never overwrite a package."""
    if _canonical(model_id) == "cardiac":
        return _install_cardiac()
    _require_human(model_id)
    manifest = asset_manifest(model_id)
    try:
        return _install_human_gem(manifest)
    except OSError:
        # Round 3: the rollback has run; what the filesystem reported is a
        # refusal, never a traceback.
        raise ModelAssetError(
            "unsafe_path",
            "The model cache could not be read or written; inspect its permissions and disk capacity.",
        ) from None


def _path_limit(directory: Path) -> int:
    try:
        return os.pathconf(directory, "PC_PATH_MAX")
    except (OSError, ValueError):
        return 1024


def _install_human_gem(manifest: dict[str, Any]) -> dict[str, Any]:
    root = _model_root(create=True)
    package = root / _PACKAGE
    # Round 3: a package whose files the platform cannot name (PATH_MAX) could
    # be published but never verified; refuse before anything is made.
    longest = max([item.filename for item in _HUMAN_ASSETS] + ["installation.json"], key=len)
    if len(os.fsencode(str(package / longest))) >= _path_limit(root):
        raise ModelAssetError(
            "unsafe_path",
            "The model cache path is too long for the package's files on this platform; choose a shorter "
            "LIVEMORE_MODEL_DIR. Nothing was installed.",
        )
    with _operation("human-gem") as operation:
        operation.scope = root
        # Before the lock: a held lock is how a pending aside shows an installation in flight.
        _refuse_pending_aside("human-gem")
        # L0-R13: an installed package is verified before the rollback record
        # and its reserve are made, so a full volume never refuses an install
        # that has nothing to do. Publication never replaces a package, so it
        # is read without the lock; under the lock it is looked for again.
        if _entry_exists(package, "unsafe_path", "The installed model package could not be read; "
                                                 "check the cache's permissions."):
            _verify(root, manifest)
            return _status_record(
                manifest,
                "verified",
                "Existing pinned model package verified; no download performed.",
            )
        operation.prepare(required=True)
        with _installation_lock(root):
            if _entry_exists(package, "unsafe_path", "The installed model package could not be read; "
                                                     "check the cache's permissions."):
                _verify(root, manifest)
                return _status_record(
                    manifest,
                    "verified",
                    "Existing pinned model package verified; no download performed.",
                )
            try:
                # L0-R11: the staging directory and each file in it are recorded and
                # pinned as they are made; a failure removes them only by moving them aside.
                with _private_staging(operation, root, ".install-human-gem-") as staging:
                    stage = staging.path
                    _assert_directory(stage)
                    deadline = time.monotonic() + _DOWNLOAD_SECONDS
                    for item in _HUMAN_ASSETS:
                        _download(item, stage / item.filename, deadline, operation, staging.files)
                    receipt = {
                        "schema_version": "livemore.model-installation.v1",
                        "model_id": "human-gem",
                        "commit": _COMMIT,
                        "manifest_sha256": _digest(manifest),
                        "acquired_at": datetime.now(timezone.utc).isoformat(),
                        "assets": manifest["assets"],
                    }
                    fd = _create_private_file(stage / "installation.json", os.O_WRONLY, operation, staging.files)
                    with os.fdopen(fd, "w", encoding="utf-8", closefd=False) as handle:
                        json.dump(
                            receipt, handle, sort_keys=True, indent=2, allow_nan=False
                        )
                        handle.flush()
                        os.fsync(handle.fileno())
                    _sync_directory(stage)
                    _checkpoint()
                    # Publication is the commit point: the complete, verified staging
                    # directory becomes the package. The no-replace rename never
                    # replaces a directory another process made at the package name
                    # (round 1); the destination is never removed or repaired.
                    _publish_package(operation, staging, package)
                _sync_directory(root)
            except OSError:
                raise ModelAssetError(
                    "unsafe_path",
                    "Unable to publish the private model package; inspect cache permissions and disk capacity.",
                ) from None
            _verify(root, manifest)
            return _status_record(
                manifest,
                "verified",
                "Pinned model package installed and all required assets verified.",
            )


def _publish_package(operation: _Operation, staging: "_Staging", package: Path) -> None:
    """Rename the staging directory to the package, which never replaces one.

    Round 3: a rename can take effect and still report an error (ENOENT from
    a retransmitted NFS RENAME, or EIO). Whether it published is decided by
    the package name holding the staging directory, as the commit link is
    (round 2); a published package is never rolled back, and one that cannot
    be read is never emptied through the staging directory's descriptor.
    """
    try:
        _rename_exclusive(staging.path, package)
    except OSError as error:
        published = _holds(package, staging.entry)
        if published is None:
            staging.published = True  # it may be the package now: never empty it
            operation.leave(staging.entry, "whether it became the package could not be read")
            raise ModelAssetError(
                "unsafe_path",
                "Whether the model package was published could not be read; check the cache, then run "
                "the status command.",
            ) from None
        if not published:
            if isinstance(error, FileExistsError):
                raise ModelAssetError(
                    "busy",
                    "Model cache changed during installation; retry after review.",
                ) from None
            raise
    staging.published = True


_CARDIAC_COMMIT = "2c2629a8e2b60c2cde677903e03c9c9be3f39a00"
_CARDIAC_ASSET = AssetFile(
    "cellml", "ohara_rudy_cipa_2017.cellml",
    "https://models.physiomeproject.org/workspace/4e4/rawfile/"
    + _CARDIAC_COMMIT + "/ohara_rudy_cipa_v1_2017.cellml",
    "ed127e6737611eb1469ea32db0b9d102f0780fc286a29ca88d11d8a868a94175",
    400980,
)
_CARDIAC_ATTRIBUTION = {
    "authors": "KC Chang, S Dutta, GR Mirams, KA Beattie, J Sheng, PN Tran, M Wu, "
               "WW Wu, T Colatsky, DG Strauss and Z Li (2017)",
    "title": "Uncertainty Quantification Reveals the Importance of Data Variability and "
             "Experimental Design Considerations for in Silico Proarrhythmia Risk Assessment",
    "citation": "Frontiers in Physiology 8:917; https://doi.org/10.3389/fphys.2017.00917",
    "encoding": "PMR workspace 4e4, owner Gary Mirams",
    "workspace_url": "https://models.physiomeproject.org/workspace/4e4",
    "license_citation_url": "https://models.physiomeproject.org/e/5a0/ohara_rudy_cipa_v1_2017.cellml/license_citation",
    "page_checked": "2026-10-04",
    "per_work_license": "unspecified",
    "repository_statement": "The citation page states CC BY 3.0 for publicly accessible repository content.",
    "distribution": "Acquired from the source at install; not redistributed in the public archive. "
                    "This receipt does not resolve the unspecified per-work licence field.",
    "changes": "None; exact pinned upstream bytes.",
    "base_model": "O'Hara T, Virag L, Varro A and Rudy Y (2011); "
                  "https://doi.org/10.1371/journal.pcbi.1002061",
    "repository_citation": "Lloyd CM, Lawson JR, Hunter PJ and Nielsen PF (2008), "
                           "The CellML Model Repository; https://doi.org/10.1093/bioinformatics/btn390",
}


def _cardiac_path() -> Path:
    # The mechanism, execution contract and adapter hash this exact installed
    # location. Acquisition must not relocate it or change those identities.
    return Path(__file__).resolve().parents[1] / "models" / "cardiac" / _CARDIAC_ASSET.filename


def _cardiac_manifest() -> dict[str, Any]:
    return {
        "schema_version": "livemore.model-assets.v1",
        "model_id": "cardiac", "release": "O'Hara-Rudy-CiPA-v1.0-2017",
        "commit": _CARDIAC_COMMIT, "source_url": _CARDIAC_ASSET.source_url,
        "attribution": dict(_CARDIAC_ATTRIBUTION),
        "assets": {"cellml": {
            "filename": _CARDIAC_ASSET.filename,
            "source_url": _CARDIAC_ASSET.source_url,
            "sha256": _CARDIAC_ASSET.sha256, "size_bytes": _CARDIAC_ASSET.size_bytes,
        }},
        "qualification": "NOT_QUALIFIED",
    }


def _require_owner_semantics() -> None:
    # Owner identity, descriptor flags and locks below are POSIX-only. Native
    # Windows has none of them, so the asset cannot be proven owner-only there:
    # refuse with the existing closed reason code instead of raising.
    from . import _platform

    if not _platform.POSIX:
        raise ModelAssetError(
            "CARDIAC_MODEL_UNSAFE_PATH",
            "Cardiac installation cannot be verified owner-only on this platform. "
            + _platform.CONTAINER_GUIDANCE)


def _cardiac_directories(
    path: Path, *, create: bool = False, operation: _Operation | None = None,
    created: list[_Entry] | None = None,
) -> None:
    _require_owner_semantics()
    if create:
        try:
            missing = []
            directory = path.parent
            while not (directory.exists() or directory.is_symlink()) and directory != directory.parent:
                missing.append(directory)
                directory = directory.parent
            for directory in reversed(missing):
                # L0-R11: each directory this operation makes is recorded and pinned at
                # once; in a managed release, on disk before its mkdir (round 2).
                try:
                    _make_directory(operation, directory, 0o755, created,
                                    journal=operation.managed, until_commit=True)
                except FileExistsError:
                    continue
        except OSError:
            raise ModelAssetError("CARDIAC_MODEL_UNSAFE_PATH", "Cardiac installation directory is unsafe.") from None
    for directory in (path.parents[2], path.parents[1], path.parent):
        try:
            info = directory.lstat()
        except FileNotFoundError:
            raise ModelAssetError("CARDIAC_MODEL_NOT_INSTALLED", "Pinned cardiac model is not installed.") from None
        except OSError:
            raise ModelAssetError("CARDIAC_MODEL_UNSAFE_PATH", "Cardiac installation directory is unsafe.") from None
        if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid()
                or stat.S_IMODE(info.st_mode) & 0o022):
            raise ModelAssetError("CARDIAC_MODEL_UNSAFE_PATH", "Cardiac installation directory is unsafe.")


def verified_cardiac_path() -> Path:
    """Verify fixed cardiac bytes offline; never create, replace or fetch a model."""
    return _verified_cardiac_bytes(_cardiac_path())


def _verified_cardiac_bytes(path: Path, pinned: _Entry | None = None) -> Path:
    """The offline verification. During an install the model may have one more
    link: its pin in this operation's private record directory (round 2), which
    is allowed only when it is that very file."""
    _cardiac_directories(path)
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        raise ModelAssetError("CARDIAC_MODEL_NOT_INSTALLED", "Pinned cardiac model is not installed.") from None
    except OSError:
        raise ModelAssetError("CARDIAC_MODEL_UNSAFE_PATH", "Cardiac model file is unsafe.") from None
    try:
        handle = os.fdopen(fd, "rb")
    except OSError:
        os.close(fd)
        raise ModelAssetError("CARDIAC_MODEL_UNSAFE_PATH", "Cardiac model file could not be read.") from None
    with handle:
        try:
            info = os.fstat(handle.fileno())
        except OSError:
            raise ModelAssetError("CARDIAC_MODEL_UNSAFE_PATH", "Cardiac model file could not be read.") from None
        links = 1
        if pinned is not None and pinned.disk_pin is not None and pinned.identified:
            try:
                links += (info.st_dev, info.st_ino) == pinned.identity()
            except OSError:
                pass
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or info.st_nlink != links or stat.S_IMODE(info.st_mode) & 0o022):
            raise ModelAssetError("CARDIAC_MODEL_UNSAFE_PATH", "Cardiac model file is unsafe.")
        try:
            data = handle.read(_CARDIAC_ASSET.size_bytes + 1)
        except OSError:
            raise ModelAssetError("CARDIAC_MODEL_UNSAFE_PATH", "Cardiac model file could not be read.") from None
    if len(data) != _CARDIAC_ASSET.size_bytes or hashlib.sha256(data).hexdigest() != _CARDIAC_ASSET.sha256:
        raise ModelAssetError("CARDIAC_MODEL_HASH_MISMATCH", "Cardiac model differs from the pinned bytes; automatic replacement is refused.")
    return path


def cardiac_status() -> dict[str, Any]:
    """Public-safe cardiac availability; integrity is separate from qualification."""
    try:
        verified_cardiac_path()
        code, reason = "", "Pinned cardiac bytes verified; scientific qualification is separate."
    except ModelAssetError as error:
        code, reason = error.code, str(error)
    return {
        "model_id": "cardiac", "available": not code,
        "state": code or "verified", "reason_code": code or None, "reason": reason,
        "model_sha256": _CARDIAC_ASSET.sha256,
        "install_command": "python -m livemorebio.model_assets install cardiac",
        "readiness_scope": "asset_integrity_only; scientific qualification and licence interpretation are separate",
        "manifest": _cardiac_manifest(),
    }


def _present(path: Path, code: str) -> bool:
    """Whether an entry holds the name; an error reading it is a refusal, not a traceback."""
    try:
        os.lstat(path)
    except (FileNotFoundError, NotADirectoryError):
        return False
    except OSError:
        raise ModelAssetError(code, "A cardiac installation path could not be read; check its permissions and retry.") from None
    return True


def _install_cardiac() -> dict[str, Any]:
    _require_owner_semantics()
    path = _cardiac_path()
    with _operation("cardiac") as operation:
        operation.scope = _record_scope("cardiac")
        # The outer installer may already own the managed release lock. An exact
        # existing asset needs no writes and must remain a read-only check there.
        _refuse_pending_aside("cardiac")
        if _present(path, "CARDIAC_MODEL_UNSAFE_PATH"):
            verified_cardiac_path()
            return cardiac_status()
        # Outside a managed release the record's directories may not exist yet.
        operation.prepare(required=_managed_install(path) is not None)
        with _managed_cardiac_release(operation, path) as created:
            _install_cardiac_asset(operation, path, created)
    # After the operation: its pins are gone, so the model has its one link.
    return cardiac_status()


def _release_paths(root: Path) -> Iterator[Path]:
    """Every entry under root, as Path.rglob("*") lists them (symlinked
    directories are not followed), except that a directory which cannot be
    read raises instead of being skipped (round 1): rglob passes over it
    silently, and a digest without its entries would be recorded as whole."""
    pending = [root]
    while pending:
        directory = pending.pop()
        with os.scandir(directory) as listing:
            entries = list(listing)
        for entry in entries:
            path = directory / entry.name
            yield path
            if entry.is_dir(follow_symlinks=False):
                pending.append(path)


def _release_entries(root: Path) -> dict[str, bytes]:
    """Match install.sh's release digest, retaining entries for a bounded update."""
    entries = {}
    for path in sorted(_release_paths(root), key=lambda candidate: candidate.as_posix()):
        relative = path.relative_to(root).as_posix()
        if relative == ".livemore-install-complete":
            continue
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode):
            payload = hashlib.sha256(os.fsencode(os.readlink(path))).digest()
            kind = b"L"
        elif stat.S_ISREG(info.st_mode):
            digest = hashlib.sha256()
            with path.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(chunk)
            payload = digest.digest()
            kind = b"F"
        else:
            continue
        entries[relative] = (kind + b"\0" + os.fsencode(relative) + b"\0"
                             + str(stat.S_IMODE(info.st_mode)).encode("ascii")
                             + b"\0" + payload)
    return entries


def _release_entries_digest(entries: dict[str, bytes]) -> str:
    return hashlib.sha256(b"".join(entries[name] for name in sorted(entries))).hexdigest()


def _managed_release_record(path: Path) -> bytes:
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as handle:
        info = os.fstat(handle.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                or info.st_nlink != 1 or stat.S_IMODE(info.st_mode) & 0o022
                or info.st_size > 4096):
            raise ValueError("unsafe managed release metadata")
        return handle.read(4097)


def _pinned_release_record(operation: _Operation, path: Path) -> tuple[_Pin, bytes]:
    """The managed integrity record, held open for the whole operation, so
    admission can prove the record it replaces is the one it read (round 1)."""
    pin = operation.pin(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK))
    info = os.fstat(pin.descriptor)
    if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
            or info.st_nlink != 1 or stat.S_IMODE(info.st_mode) & 0o022
            or info.st_size > 4096):
        raise ValueError("unsafe managed release metadata")
    return pin, os.pread(pin.descriptor, 4097, 0)


class _AdmissionUnknown(OSError):
    """Whether the commit link took effect could not be read."""


def _admit(operation: _Operation, integrity: Path, new_record: _Entry,
           previous: _Pin, recorded: bytes, new_bytes: bytes) -> Path:
    """Replace the managed integrity record without ever destroying a record
    another process put at its name (round 1).

    The previous record moves aside with one rename and is compared there with
    the descriptor and bytes read at the start; only then is the new record
    linked in, which never overwrites. Any other record goes back. Returns the
    previous record's aside directory, to delete once admission has committed.

    Round 2: the new record lives in this operation's private record
    directory, and the aside directory holds a pin of it, so restore can
    always tell, by identity, whether the new record holds the name. Whether
    admission committed is decided by the name holding the new record, never
    by the error the link reported: a link can take effect and still fail.

    Round 3: the name holding a byte-identical copy of the new record (another
    program rewrote it) counts as committed too. Every step inside the aside
    directory is relative to its descriptor (no path past PATH_MAX).
    """
    device, new_inode = new_record.identity()
    original = os.fstat(previous.descriptor)
    directory = os.open(integrity.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        aside = integrity.parent / _make_aside_at(directory, "old", device, new_inode, 0)
        try:
            inner = os.open(aside.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
        except OSError:
            _discard_old_aside(operation, aside)
            raise
        try:
            return _admit_in(operation, integrity, new_record, previous, recorded, new_bytes, original,
                             aside, inner)
        finally:
            _close(inner)
    finally:
        _close(directory)


def _admit_in(operation: _Operation, integrity: Path, new_record: _Entry, previous: _Pin, recorded: bytes,
              new_bytes: bytes, original: os.stat_result, aside: Path, inner: int) -> Path:
    try:
        os.link(new_record.path, _NEW_RECORD_PIN, dst_dir_fd=inner, follow_symlinks=False)
    except OSError:
        if _holds_at(inner, _NEW_RECORD_PIN, new_record) is not True:
            _discard_old_aside(operation, aside)
            raise
    try:
        os.rename(integrity, integrity.name, dst_dir_fd=inner)
    except OSError:
        _discard_old_aside(operation, aside)
        raise
    try:
        same = (os.path.samestat(os.stat(integrity.name, dir_fd=inner, follow_symlinks=False), original)
                and os.pread(previous.descriptor, 4097, 0) == recorded)
    except OSError:
        same = False  # unverified: it goes back to its name, and admission fails
    committed: bool | None = False
    failure: BaseException = ValueError("the integrity record was replaced, or could not be verified")
    if same:
        try:
            os.link(new_record.path, integrity, follow_symlinks=False)
        except OSError as error:
            failure = error
        committed = _holds_record(integrity, new_record, new_bytes)
        if committed is False and not isinstance(failure, OSError):
            failure = ValueError("the integrity record's name does not hold the new record")
    if committed is True:
        return aside
    if committed is None:
        operation.kept.append(aside)  # restore decides by the pin it holds
        raise _AdmissionUnknown(errno.EIO, "whether the new integrity record took its name could not be read")

    def put_back() -> None:
        try:
            os.link(integrity.name, integrity, src_dir_fd=inner, follow_symlinks=False)
        except (IsADirectoryError, PermissionError):
            _rename_exclusive(integrity.name, integrity, source_directory=inner)  # not a file: put back as it is
        else:
            os.unlink(integrity.name, dir_fd=inner)

    try:
        operation.with_space(put_back)
    except OSError:
        operation.kept.append(aside)  # restore puts it back: the new record does not hold the name
    else:
        _discard_old_aside(operation, aside)
    raise failure


def _holds_at(directory: int, name: str, entry: _Entry) -> bool | None:
    """Whether a name in an open directory holds this pinned entry."""
    try:
        at_name = os.stat(name, dir_fd=directory, follow_symlinks=False)
    except (FileNotFoundError, NotADirectoryError):
        return False
    except OSError:
        return None
    try:
        return (at_name.st_dev, at_name.st_ino) == entry.identity()
    except OSError:
        return None


def _holds_record(path: Path, entry: _Entry, data: bytes) -> bool | None:
    """Whether the integrity record's name holds the new record: that very
    file, or (round 3) a byte-identical copy another program wrote there."""
    held = _holds(path, entry)
    if held is not False:
        return held
    try:
        return _record_bytes(path) == data
    except FileNotFoundError:
        return False
    except OSError:
        return None


def _in_aside(aside: Path, act: Any) -> None:
    """Act inside an aside directory through its descriptor, then remove it."""
    directory = os.open(aside.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        inner = os.open(aside.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
        try:
            act(inner)
        finally:
            _close(inner)
        os.rmdir(aside.name, dir_fd=directory)
    finally:
        _close(directory)


def _discard_old_aside(operation: _Operation, aside: Path) -> None:
    """An `old` aside that holds nothing but the new record's pin."""
    def remove_pin(inner: int) -> None:
        try:
            os.unlink(_NEW_RECORD_PIN, dir_fd=inner)
        except FileNotFoundError:
            pass

    try:
        _in_aside(aside, remove_pin)
    except OSError:
        operation.kept.append(aside)


def _finish_admission(operation: _Operation, aside: Path, integrity: Path) -> None:
    """After the commit: delete the verified previous record and the new
    record's pin. Neither can undo the admission; what fails stays reported,
    and restore finishes it (the new record holds the name)."""
    def remove(inner: int) -> None:
        os.unlink(integrity.name, dir_fd=inner)
        os.unlink(_NEW_RECORD_PIN, dir_fd=inner)

    try:
        _in_aside(aside, remove)
    except OSError:
        operation.kept.append(aside)


@contextmanager
def _managed_cardiac_release(operation: _Operation, path: Path) -> Iterator[list[_Entry]]:
    source = path.parents[2]
    release = source.parent
    marker = release / ".livemore-install-complete"
    # Entries this operation itself created, each pinned, in creation order.
    # Only these may be removed on rollback, and only by moving them aside and
    # verifying them there (L0-R11).
    created: list[_Entry] = []
    # Initial installer builds and detached upgrade staging are verified by the
    # installer itself. Only completed managed releases need a standalone update.
    if (source.name != "source" or release.parent.name != "releases"
            or re.fullmatch(r"[0-9a-fA-F]{40}", release.name) is None
            or not _present(marker, "CARDIAC_MODEL_INSTALL_INTEGRITY")):
        yield created
        return
    install = release.parent.parent
    integrity_directory = install / "integrity"
    integrity = integrity_directory / (release.name + ".sha256")
    lock = install / ".install.lock"
    lock_made: list[_Entry] = []
    before = None
    baseline_verified = False
    admitted: bool | None = False
    changed_paths = (path, path.with_suffix(".cellml.attribution.json"), path.parent / ".install.lock")
    try:
        for directory in (install, release.parent, release, source, integrity_directory):
            info = directory.lstat()
            if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid()
                    or stat.S_IMODE(info.st_mode) & 0o022):
                raise ValueError("unsafe managed release directory")
        for directory, label in ((release.parent, "releases"), (integrity_directory, "integrity")):
            expected = f"LivemoreBio installer-owned {label} directory v1\n".encode("utf-8")
            if _managed_release_record(directory / ".livemore-installer-owned-v1") != expected:
                raise ValueError("unrecognized managed release directory")
        if not _managed_release_record(marker).startswith(f"commit={release.name}\n".encode("ascii")):
            raise ValueError("managed release identity mismatch")
        # Round 2: from here every entry is on the record before it exists.
        operation.managed = True
        operation.release = release
        lock_entry = _make_managed_lock(operation, lock, lock_made)
        previous, recorded = _pinned_release_record(operation, integrity)
        before = _release_entries(release)
        if recorded != (_release_entries_digest(before) + "\n").encode("ascii"):
            raise ValueError("release integrity mismatch")
        baseline_verified = True
        allowed = {candidate.relative_to(release).as_posix() for candidate in changed_paths}
        yield created
        _checkpoint()
        model = next((entry for entry in created if entry.path == path and not entry.done), None)
        _verified_cardiac_bytes(path, model)
        after = _release_entries(release)
        if ({name: value for name, value in before.items() if name not in allowed}
                != {name: value for name, value in after.items() if name not in allowed}
                or _managed_release_record(integrity) != recorded):
            raise ValueError("release changed outside cardiac acquisition")
        # Round 2: the new record is made in the private record directory, so
        # no other process can put a file at its name; the record on disk
        # names it before admission, so restore can tell whether it committed.
        descriptor, name = operation.record_file(_NEW_RECORD_PREFIX)
        new_record = _Entry(operation.record_directory / name, operation.pins[-1], False, disk_pin=name)
        new_bytes = (_release_entries_digest(after) + "\n").encode("ascii")
        with os.fdopen(descriptor, "wb", closefd=False) as handle:
            handle.write(new_bytes)
            handle.flush()
            os.fsync(handle.fileno())
        operation.commit = {"path": str(integrity), "pin": name}
        operation.save()
        _checkpoint()
        # Admission is the commit point (round 1: move aside, verify, link in).
        try:
            aside = _admit(operation, integrity, new_record, previous, recorded, new_bytes)
        except _AdmissionUnknown:
            admitted = None
            raise
        admitted = True
        for entry in created:
            entry.done = True  # part of the release now
        _finish_admission(operation, aside, integrity)
        _sync_directory(integrity_directory)
    except (OSError, ValueError):
        raise ModelAssetError("CARDIAC_MODEL_INSTALL_INTEGRITY", "Managed release integrity could not be verified or updated; automatic repair is refused.") from None
    finally:
        # Failed acquisition must not invalidate a previously usable base
        # release. Ctrl-C is deferred for the whole operation, so nothing cuts
        # this short, and only entries this operation recorded are removed,
        # newest first. The managed lock moves aside whole, with its pid, so
        # no other installer ever sees it without its pid.
        if baseline_verified and admitted is False:
            _remove_recorded(operation, created)
        elif admitted is None:
            # Round 2: whether admission committed cannot be read now. The
            # entries stay, recorded, and restore decides by the new record's pin.
            for entry in created:
                if not entry.done:
                    operation.leave(entry, "whether admission committed could not be read")
        _remove_recorded(operation, lock_made)


def _make_managed_lock(operation: _Operation, lock: Path, lock_made: list[_Entry]) -> _Entry:
    """The managed installer lock directory with its pid, recorded before it exists.

    The pid file is made first, in the private record directory, and the
    record lists the lock with that pid before the mkdir. The pid is linked in
    one call after the mkdir, as before: install.sh takes a lock directory
    without a pid for a stale one. A lock this operation made is then always
    recorded with its pid, so restore can remove it after a SIGKILL.
    """
    busy = ModelAssetError("CARDIAC_MODEL_INSTALL_BUSY",
                           "A managed installer lock already exists; retry after the installer completes.")
    descriptor, name = operation.record_file(_PIN_PREFIX)
    pid = _Entry(lock / "pid", operation.pins[-1], False, disk_pin=name)
    remaining = memoryview((str(os.getpid()) + "\n").encode("ascii"))
    while remaining:
        remaining = remaining[os.write(descriptor, remaining):]
    os.fsync(descriptor)
    entry = _Entry(lock, _Pin(None), True, children=[pid], planned=True)
    lock_made.append(entry)
    operation.note(entry)
    operation.save()

    def make() -> None:
        previous = os.umask(0o077)
        try:
            os.umask(previous & 0o077)
            os.mkdir(lock, 0o700)
        finally:
            os.umask(previous)

    try:
        _mkdir_recorded(operation, entry, make)
    except FileExistsError:
        lock_made.remove(entry)
        raise busy from None
    try:
        _link_recorded(operation.record_directory / name, lock / "pid", pid)
    except FileExistsError:
        raise busy from None
    operation.save()
    if entry.pin.descriptor is None:
        raise OSError(errno.EIO, entry.reason)  # it is recorded; the rollback settles it
    return entry


def _install_cardiac_asset(operation: _Operation, path: Path, created: list[_Entry]) -> None:
    _cardiac_directories(path, create=True, operation=operation, created=created)
    # Round 3: every directory down to the model's, by identity, before any
    # entry is made in them; the record lists them with the next save.
    operation.know_chain(path.parent)
    # Outside a managed release the record's directories may only exist now,
    # and they persist there; the record still precedes staging and its files.
    operation.prepare(required=True)
    try:
        with _installation_lock(path.parent, operation, created):
            if path.exists() or path.is_symlink():
                verified_cardiac_path()
                return
            with _private_staging(operation, path.parent, ".install-cardiac-") as staging:
                stage = staging.path
                candidate = stage / path.name
                try:
                    _download(_CARDIAC_ASSET, candidate, time.monotonic() + _DOWNLOAD_SECONDS,
                              operation, staging.files)
                except ModelAssetError:
                    raise ModelAssetError("CARDIAC_MODEL_DOWNLOAD_FAILED", "Pinned cardiac acquisition failed; no model was admitted.") from None
                staged_model = staging.files[-1]
                receipt = {
                    "schema_version": "livemore.cardiac-acquisition.v1",
                    "model_id": "cardiac", "model_sha256": _CARDIAC_ASSET.sha256,
                    "source_url": _CARDIAC_ASSET.source_url, "commit": _CARDIAC_COMMIT,
                    "acquired_at": datetime.now(timezone.utc).isoformat(),
                    "attribution": dict(_CARDIAC_ATTRIBUTION),
                }
                receipt_path = path.with_suffix(".cellml.attribution.json")
                staged_receipt = stage / receipt_path.name
                fd = _create_private_file(staged_receipt, os.O_WRONLY, operation, staging.files)
                staged_attribution = staging.files[-1]
                with os.fdopen(fd, "w", encoding="utf-8", closefd=False) as handle:
                    json.dump(receipt, handle, sort_keys=True, indent=2, allow_nan=False)
                    handle.flush()
                    os.fsync(handle.fileno())
                _cardiac_directories(path)
                _checkpoint()
                # Publish attribution first and never overwrite an existing entry.
                # A crash can leave a receipt without a model; retry verifies it.
                # L0-R11: the published name is recorded before each link, pinned
                # by the staged file's descriptor, so a link that never happened
                # leaves nothing rollback would match. Round 2: in a managed
                # release the record on disk lists it first, with a pin.
                attribution = _publish(operation, created, staged_attribution, staged_receipt, receipt_path)
                if attribution is None:
                    with os.fdopen(_private_fd(receipt_path), "r", encoding="utf-8") as handle:
                        previous = json.loads(handle.read(32769))
                    if any(previous.get(key) != value for key, value in receipt.items() if key != "acquired_at"):
                        raise ModelAssetError("CARDIAC_MODEL_INSTALL_FAILED", "Existing cardiac attribution differs; automatic replacement is refused.")
                model = _publish(operation, created, staged_model, candidate, path)
                if model is None:
                    raise FileExistsError(errno.EEXIST, "the model's name is taken")
                _sync_directory(path.parent)
            _verified_cardiac_bytes(path, model)
    except ModelAssetError as error:
        if error.code.startswith("CARDIAC_MODEL_"):
            raise
        raise ModelAssetError("CARDIAC_MODEL_INSTALL_FAILED", "Cardiac installation could not be admitted safely.") from None
    except (OSError, ValueError, TypeError, AttributeError):
        raise ModelAssetError("CARDIAC_MODEL_INSTALL_FAILED", "Cardiac installation could not be admitted safely.") from None


def _publish(operation: _Operation, created: list[_Entry], staged: _Entry, source: Path,
             destination: Path) -> _Entry | None:
    """Link a staged file to its published name, which never overwrites; None
    when the name is already taken. The name is recorded first: in memory,
    pinned by the staged file's descriptor, and in a managed release also on
    disk with a pin, so a SIGKILL after the link leaves it recorded."""
    entry = operation.share(staged, destination)
    created.append(entry)
    if operation.managed:
        entry.until_commit = True
        operation.pin_link(entry, source)
        entry.links = operation.links_of(entry.disk_pin)
        operation.note(entry)
        operation.save()
    try:
        _link_recorded(source, destination, entry)
    except FileExistsError:
        created.remove(entry)
        operation.forget(entry)
        return None
    return entry


def annotation_rows(
    kind: str, ids: list[str], model_id: str = "human-gem"
) -> dict[str, Any]:
    """Bounded exact TSV lookup. An annotation is not a physiological coefficient."""
    key = (
        {"genes": "genes", "reactions": "rxns", "metabolites": "mets"}.get(kind)
        if isinstance(kind, str)
        else None
    )
    if (
        key is None
        or not isinstance(ids, list)
        or not 1 <= len(ids) <= 100
        or any(
            not isinstance(value, str)
            or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,100}", value)
            for value in ids
        )
        or len(set(ids)) != len(ids)
    ):
        raise ModelAssetError(
            "invalid_id",
            "Use genes/reactions/metabolites and 1–100 unique exact stable identifiers.",
        )
    path = verified_asset_path(kind, model_id)
    wanted = set(ids)
    indexed = {}
    try:
        with os.fdopen(_private_fd(path), "r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle, delimiter="\t")
            if not reader.fieldnames or key not in reader.fieldnames:
                raise ValueError("schema mismatch")
            for row in reader:
                if row[key] in wanted:
                    indexed[row[key]] = row
    except (OSError, ValueError, UnicodeError, csv.Error):
        raise ModelAssetError(
            "corrupt", "Model annotation schema could not be read."
        ) from None
    manifest = asset_manifest(model_id)
    return {
        "model_id": "human-gem",
        "release": manifest["release"],
        "commit": _COMMIT,
        "evidence_class": "REFERENCE_MODEL_ANNOTATION",
        "kind": kind,
        "rows": [indexed[value] for value in ids if value in indexed],
        "missing_ids": [value for value in ids if value not in indexed],
        "source": manifest["assets"][kind],
        "limitation": "Identifier links and model annotations do not establish causal effect sizes or patient-specific physiology.",
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("catalog", "install", "status", "check", "restore"))
    parser.add_argument("model_id", nargs="?", default="human-gem")
    args = parser.parse_args(argv)
    try:
        if args.command == "catalog":
            result = catalog()
        elif args.command == "install":
            result = install(args.model_id)
        elif args.command == "check":
            _refuse_pending_aside(args.model_id)
            verified_asset(args.model_id)
            result = status(args.model_id)
        elif args.command == "restore":
            result = restore(args.model_id)
        else:
            result = status(args.model_id)
        print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
        return 0
    except ModelAssetError as error:
        print(
            json.dumps(
                {"error": {"code": error.code, "message": str(error)}}, sort_keys=True
            )
        )
        return 2
    except OSError:
        # Round 3: a filesystem error the functions did not type is still a
        # refusal with the closed code set, never a traceback.
        code = "CARDIAC_MODEL_UNSAFE_PATH" if args.model_id == "cardiac" else "unsafe_path"
        print(json.dumps({"error": {"code": code, "message": "A model path could not be read or written; "
                                                            "check its permissions and retry."}}, sort_keys=True))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
