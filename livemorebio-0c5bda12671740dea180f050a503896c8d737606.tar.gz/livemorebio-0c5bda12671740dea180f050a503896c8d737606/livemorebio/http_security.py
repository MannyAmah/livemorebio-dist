"""Response hardening, host admission and browser-site boundary for local services."""
from __future__ import annotations

import re
from urllib.parse import urlsplit

from starlette.responses import JSONResponse
from starlette.types import ASGIApp, Message, Receive, Scope, Send


# Existing console documents contain inline scripts/styles and generate inline
# styles dynamically. All executable modules, fetch/SSE calls and fonts are local.
# srcdoc molecular viewers inherit this policy and load local modules themselves.
CONSOLE_CSP = (
    "default-src 'self'; script-src 'self' 'unsafe-inline'; "
    "style-src 'self' 'unsafe-inline'; connect-src 'self'; font-src 'self'; "
    "img-src 'self' data: blob:; frame-src 'self'; "
    "object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
)
_HOST_NAME = re.compile(r"[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\Z", re.ASCII)


class ConsoleHTTPBoundary:
    """Wrap auth and private-error responses as well as successful route output.

    LIVEMORE_ALLOWED_HOSTS adds comma-separated exact host names (no wildcard,
    URL or port), for example ``aegle,life,cendos,console.example``. Loopback
    aliases are always admitted. Proxy-forwarded host headers grant no access.
    The shared installer also admits the exact own-service name configured by
    Compose's existing LIVEMORE_SERVICE setting (aegle, life or cendos).
    """

    def __init__(self, app: ASGIApp, *, deployment_hosts: str = "",
                 session_document_paths: frozenset[str] = frozenset(),
                 private_response_paths: frozenset[str] = frozenset(),
                 private_response_prefixes: tuple[str, ...] = ()) -> None:
        self.app = app
        self.session_document_paths = session_document_paths
        self.private_response_paths = private_response_paths
        self.private_response_prefixes = private_response_prefixes
        self.allowed_hosts = {"127.0.0.1", "localhost", "::1"}
        for entry in deployment_hosts.split(","):
            host = entry.strip().lower()
            if not host:
                continue
            if host != "::1" and not _HOST_NAME.fullmatch(host):
                raise ValueError("LIVEMORE_ALLOWED_HOSTS requires exact host names without ports")
            self.allowed_hosts.add(host)

    def _host_allowed(self, scope: Scope) -> bool:
        hosts = [value for name, value in scope.get("headers", []) if name.lower() == b"host"]
        if len(hosts) != 1:
            return False
        try:
            raw = hosts[0].decode("ascii")
            if not raw or any(char.isspace() for char in raw) or any(char in raw for char in "/\\?#@,"):
                return False
            parsed = urlsplit("//" + raw)
            # Parsing the port checks malformed and out-of-range values too.
            parsed.port
            if raw.endswith(":"):
                return False
            return parsed.hostname in self.allowed_hosts
        except (UnicodeDecodeError, ValueError):
            return False

    def _browser_request_allowed(self, scope: Scope) -> bool:
        def values(header: bytes) -> list[bytes]:
            return [value.strip().lower() for name, value in scope.get("headers", [])
                    if name.lower() == header]

        # Inspect every occurrence so a duplicate cannot hide the browser's
        # cross-site declaration. Non-browser callers without it are unchanged.
        if b"cross-site" not in values(b"sec-fetch-site"):
            return True
        path = scope.get("path", "")
        return (
            scope.get("method") == "GET" and path in self.session_document_paths
            and scope.get("raw_path") == path.encode("utf-8") and not scope.get("root_path")
            and values(b"sec-fetch-mode") == [b"navigate"]
            and values(b"sec-fetch-dest") == [b"document"]
        )

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        async def secured_send(message: Message) -> None:
            if message["type"] == "http.response.start":
                # The code-free connection document must preserve the browser's
                # POST Origin (Fetch, "append a request Origin header"). Every
                # exchange, refusal and noncanonical target keeps no-referrer.
                connection_document = (
                    scope.get("method") == "GET" and scope.get("path") == "/console/connect"
                    and scope.get("raw_path") == b"/console/connect"
                    and not scope.get("root_path") and not scope.get("query_string")
                    and message["status"] == 200
                    and any(name.lower() == b"referrer-policy" and value == b"same-origin"
                            for name, value in message.get("headers", []))
                )
                replaced = {b"x-content-type-options", b"referrer-policy", b"x-frame-options"}
                path = scope.get("path", "")
                private = (path.rstrip("/") in self.private_response_paths
                           or path.startswith(self.private_response_prefixes))
                if private:
                    # This outer boundary also sees auth, validation and private
                    # failure responses that never return through the handler.
                    replaced.add(b"cache-control")
                headers = [(name, value) for name, value in message.get("headers", [])
                           if name.lower() not in replaced]
                if private:
                    headers.append((b"cache-control", b"no-store"))
                headers.extend([
                    (b"x-content-type-options", b"nosniff"),
                    (b"referrer-policy", b"same-origin" if connection_document else b"no-referrer"),
                    (b"x-frame-options", b"DENY"),
                    # An existing stricter CSP remains an additional policy;
                    # browsers enforce the intersection, never a weaker union.
                    (b"content-security-policy", CONSOLE_CSP.encode("ascii")),
                ])
                message = {**message, "headers": headers}
            await send(message)

        if not self._host_allowed(scope):
            await JSONResponse({"error": "Invalid Host header"}, status_code=400,
                               headers={"Cache-Control": "no-store"})(scope, receive, secured_send)
            return
        if not self._browser_request_allowed(scope):
            await JSONResponse(
                {"code": "CROSS_SITE_REQUEST_REFUSED", "error": "Cross-site browser requests are not allowed."},
                status_code=403, headers={"Cache-Control": "no-store"},
            )(scope, receive, secured_send)
            return
        await self.app(scope, receive, secured_send)
