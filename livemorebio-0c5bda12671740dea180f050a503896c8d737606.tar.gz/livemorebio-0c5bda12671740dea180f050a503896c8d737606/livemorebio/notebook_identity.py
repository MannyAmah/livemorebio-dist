"""Private launch tokens and short-lived codes for the supported Jupyter lock.

The launcher admits the stack data directory with NEW-7 before making a runtime.
These helpers inspect only that runtime, with pinned no-follow descriptors; they
never discover or fall back to a home runtime or another stack.
"""
from __future__ import annotations

from contextlib import contextmanager
import fcntl
import hashlib
import hmac
from importlib import metadata
import json
import math
import os
from pathlib import Path
import re
import secrets
import stat
import time
from typing import Iterator, TYPE_CHECKING

from jupyter_server.auth import PasswordIdentityProvider, User
from traitlets import default

from . import console_filesystem
from .notebook_compat import install_static_file_compat

# Jupyter imports this provider in its child process before serving any assets.
install_static_file_compat()

if TYPE_CHECKING:
    from tornado.web import RequestHandler


TOKEN_FILENAME = "token"
ADMISSION_FILENAME = "provider-admitted.json"
CODES_DIRECTORY = "codes"
CODE_TTL_SECONDS = 120
CROCKFORD_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
_CODE = re.compile(r"[0-9A-HJKMNP-TV-Z]{16}", re.ASCII)
_TOKEN = re.compile(r"[0-9a-f]{64}", re.ASCII)
_TOKEN_FAILURE = "Livemore notebook authentication requires its private launch token."
_CODE_FAILURE = "Livemore notebook one-time code could not be created."
_VERSION_FAILURE = "Livemore notebooks require jupyter-server 2.21.0 and jupyterlab 4.6.4."


class NotebookIdentityError(RuntimeError):
    """A fixed refusal that contains no credential or operator pathname."""


def require_supported_versions() -> None:
    """Refuse an unqualified Jupyter combination without importing Lab."""
    try:
        supported = (metadata.version("jupyter-server") == "2.21.0"
                     and metadata.version("jupyterlab") == "4.6.4")
    except metadata.PackageNotFoundError:
        supported = False
    if not supported:
        raise NotebookIdentityError(_VERSION_FAILURE)


def _inspect_private(descriptor: int, *, directory: bool) -> os.stat_result:
    info = os.fstat(descriptor)
    valid_type = stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)
    # jupyter_client adds the sticky bit when writing kernel connection files.
    modes = (0o700, 0o1700) if directory else (0o600,)
    if (not valid_type or info.st_uid != os.geteuid()
            or stat.S_IMODE(info.st_mode) not in modes
            or (not directory and info.st_nlink != 1)):
        raise NotebookIdentityError(_TOKEN_FAILURE)
    console_filesystem.require_ownership_filesystem(descriptor)
    console_filesystem.require_empty_page_acl(descriptor)
    return info


@contextmanager
def open_private_runtime(runtime: str | os.PathLike[str]) -> Iterator[int]:
    """Pin an owned 0700/01700 runtime; never create or repair it."""
    descriptor = -1
    try:
        descriptor = os.open(runtime, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_NONBLOCK)
        _inspect_private(descriptor, directory=True)
        yield descriptor
    except (OSError, ValueError, console_filesystem.ConsoleFilesystemError):
        raise NotebookIdentityError(_TOKEN_FAILURE) from None
    finally:
        if descriptor >= 0:
            os.close(descriptor)


@contextmanager
def _private_child(parent: int, name: str, *, directory: bool = False) -> Iterator[int]:
    descriptor = -1
    try:
        flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
        if directory:
            flags |= os.O_DIRECTORY
        descriptor = os.open(name, flags, dir_fd=parent)
        _inspect_private(descriptor, directory=directory)
        yield descriptor
    finally:
        if descriptor >= 0:
            os.close(descriptor)


def read_private_token(runtime: str | os.PathLike[str]) -> str:
    """Read exactly one fresh 32-byte hex token from the private runtime."""
    try:
        with open_private_runtime(runtime) as directory:
            with _private_child(directory, TOKEN_FILENAME) as descriptor:
                raw = os.read(descriptor, 65)
                token = raw.decode("ascii")
                if not _TOKEN.fullmatch(token):
                    raise NotebookIdentityError(_TOKEN_FAILURE)
                before = os.fstat(descriptor)
                current = os.stat(TOKEN_FILENAME, dir_fd=directory, follow_symlinks=False)
                if (before.st_dev, before.st_ino) != (current.st_dev, current.st_ino):
                    raise NotebookIdentityError(_TOKEN_FAILURE)
                return token
    except (OSError, ValueError, UnicodeError, console_filesystem.ConsoleFilesystemError):
        raise NotebookIdentityError(_TOKEN_FAILURE) from None


def mint_code(runtime: str | os.PathLike[str], *, now: float | None = None) -> str:
    """Write an exclusive SHA-256-named expiry file for one 80-bit code."""
    current = time.time() if now is None else now
    if not math.isfinite(current):
        raise NotebookIdentityError(_CODE_FAILURE)
    try:
        with open_private_runtime(runtime) as directory:
            try:
                os.mkdir(CODES_DIRECTORY, 0o700, dir_fd=directory)
            except FileExistsError:
                pass
            with _private_child(directory, CODES_DIRECTORY, directory=True) as codes:
                for _ in range(8):
                    code = "".join(secrets.choice(CROCKFORD_ALPHABET) for _ in range(16))
                    name = hashlib.sha256(code.encode("ascii")).hexdigest()
                    try:
                        descriptor = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                                             0o600, dir_fd=codes)
                    except FileExistsError:
                        continue
                    created = None
                    try:
                        created = os.fstat(descriptor)
                        _inspect_private(descriptor, directory=False)
                        with os.fdopen(descriptor, "w", encoding="utf-8", closefd=False) as output:
                            output.write(str(current + CODE_TTL_SECONDS))
                            output.flush()
                    except BaseException:
                        if created is not None:
                            try:
                                existing = os.stat(name, dir_fd=codes, follow_symlinks=False)
                                if (created.st_dev, created.st_ino) == (existing.st_dev, existing.st_ino):
                                    os.unlink(name, dir_fd=codes)
                            except FileNotFoundError:
                                pass
                        raise
                    finally:
                        os.close(descriptor)
                    return code
    except (OSError, ValueError, console_filesystem.ConsoleFilesystemError, NotebookIdentityError):
        raise NotebookIdentityError(_CODE_FAILURE) from None
    raise NotebookIdentityError(_CODE_FAILURE)


def consume_code(runtime: str | os.PathLike[str], code: str, *, now: float | None = None) -> bool:
    """Unlink wins the race: only the contender that removes the file succeeds."""
    if not isinstance(code, str) or not _CODE.fullmatch(code):
        return False
    current = time.time() if now is None else now
    if not math.isfinite(current):
        return False
    name = hashlib.sha256(code.encode("ascii")).hexdigest()
    try:
        with open_private_runtime(runtime) as directory:
            with _private_child(directory, CODES_DIRECTORY, directory=True) as codes:
                with _private_child(codes, name) as descriptor:
                    # Serializing holders of this inode also covers platforms
                    # where racing unlink calls can both return success. The
                    # path check after the lock rejects every later holder.
                    fcntl.flock(descriptor, fcntl.LOCK_EX)
                    expiry = float(os.read(descriptor, 64).decode("ascii"))
                    opened = os.fstat(descriptor)
                    current_entry = os.stat(name, dir_fd=codes, follow_symlinks=False)
                    if (opened.st_dev, opened.st_ino) != (current_entry.st_dev, current_entry.st_ino):
                        return False
                    # Even expired entries are consumed, rather than becoming
                    # usable after a later wall-clock correction.
                    os.unlink(name, dir_fd=codes)
                    return math.isfinite(expiry) and current < expiry <= current + CODE_TTL_SECONDS
    except (OSError, ValueError, UnicodeError, NotebookIdentityError,
            console_filesystem.ConsoleFilesystemError):
        return False


class LivemoreIdentityProvider(PasswordIdentityProvider):
    """Jupyter authentication plus one-time launch/manual codes."""

    def __init__(self, **kwargs: object) -> None:
        require_supported_versions()
        runtime = os.environ.get("JUPYTER_RUNTIME_DIR", "")
        token_file = os.environ.get("JUPYTER_TOKEN_FILE", "")
        if (not runtime or not token_file
                or os.path.abspath(token_file) != os.path.join(os.path.abspath(runtime), TOKEN_FILENAME)):
            raise NotebookIdentityError(_TOKEN_FAILURE)
        self._livemore_runtime = Path(runtime)
        expected = read_private_token(self._livemore_runtime)
        super().__init__(**kwargs)
        if not self.token or not hmac.compare_digest(self.token, expected):
            raise NotebookIdentityError(_TOKEN_FAILURE)
        self.token_generated = False
        self.allow_password_change = False
        self._admit_startup()

    def _admit_startup(self) -> None:
        # Extension linking can rewrite ServerApp CLI settings. Check the final
        # parent before ServerApp constructs its HTTP server, independently of
        # notebook_shim's precedence rules.
        from .notebook_launch import NotebookLaunchError, NotebookRuntime, _read_record, _write_private

        try:
            with open_private_runtime(self._livemore_runtime) as directory:
                info = os.fstat(directory)
                runtime = NotebookRuntime(self._livemore_runtime, (info.st_dev, info.st_ino))
                record = _read_record(runtime)
                parent = self.parent
                if (parent is None or getattr(parent, "ip", None) != "127.0.0.1"
                        or type(getattr(parent, "port", None)) is not int or parent.port != record["port"]
                        or type(getattr(parent, "port_retries", None)) is not int or parent.port_retries != 0
                        or getattr(parent, "open_browser", None) is not False):
                    raise NotebookIdentityError(_TOKEN_FAILURE)
                _write_private(directory, ADMISSION_FILENAME, json.dumps({
                    "schema": "livemore.notebook-admitted.v1", "port": record["port"],
                    "server_pid": os.getpid(), "runtime_identity": list(runtime.identity),
                }))
        except (OSError, ValueError, NotebookLaunchError, console_filesystem.ConsoleFilesystemError):
            raise NotebookIdentityError(_TOKEN_FAILURE) from None

    @default("token")
    def _livemore_token_default(self) -> str:
        self.token_generated = False
        return read_private_token(self._livemore_runtime)

    async def get_user_token(self, handler: RequestHandler) -> User | None:
        candidate = handler.get_argument("token", "")
        if candidate and consume_code(self._livemore_runtime, candidate):
            user = self.get_user_cookie(handler)
            if hasattr(user, "__await__"):
                user = await user
            return user if user is not None else self.generate_anonymous_user(handler)
        return await super().get_user_token(handler)

    def process_login_form(self, handler: RequestHandler) -> User | None:
        candidate = handler.get_argument("password", default="")
        if candidate and consume_code(self._livemore_runtime, candidate):
            return self.generate_anonymous_user(handler)
        return super().process_login_form(handler)
