"""Keep Python's text encoding when a native library resets the C locale.

Python takes the encoding of a text file opened without ``encoding=``, and of a
text-mode subprocess pipe, from ``LC_CTYPE`` at the moment of the call. COPASI's
Python binding, which ``basico`` imports, runs ``setlocale(LC_ALL, "C")`` when it
loads, and from then on that encoding is ASCII for the whole process.

COPASI sets the C locale for its number parsing, which is ``LC_NUMERIC``; that
category is left as COPASI set it, and Python never sets it. Only ``LC_CTYPE``
is put back, which returns the process to the locale Python chose at start-up.
COPASI's results do not change: a basico time course gives bit-identical values
either way, and it saves and loads models at non-ASCII paths either way.

This covers the import only. COPASI sets the C locale again whenever it loads a
``.cps`` file, so nothing in this package may rely on the locale at all: every
text read and write names its encoding, which
``tests/test_text_encoding_explicit.py`` holds it to.
"""
from __future__ import annotations

import contextlib
import locale
from typing import Iterator


@contextlib.contextmanager
def ctype_locale_preserved() -> Iterator[None]:
    """Restore ``LC_CTYPE`` after the block if anything inside changed it."""
    saved = locale.setlocale(locale.LC_CTYPE)
    try:
        yield
    finally:
        if locale.setlocale(locale.LC_CTYPE) != saved:
            locale.setlocale(locale.LC_CTYPE, saved)
