"""Shared service registry so the LivemoreBio services discover each other."""
from __future__ import annotations
from collections.abc import Callable
import json, os, time
import logging
from pathlib import Path
import stat
import sys
from . import console_filesystem
REG_DIR = os.path.abspath(os.path.expanduser(os.environ.get("LIVEMORE_DATA_DIR", "~/.livemore")))
REG = os.path.join(REG_DIR, "registry.json")


# Darwin O_EXEC | O_DIRECTORY supports Python builds whose SDK omitted O_SEARCH.
_DARWIN_O_SEARCH = 0x40100000


_CREDENTIAL_BASENAMES = (
    "api-token", "patch-storage.key", "patch-admission.key", "livemore-sign-hmac.key",
    "evidence.sqlite.audit.key", "evidence-signing-ed25519.key",
    "patch-storage-key", "patch-admission-key", "service-identity.key",
)
_ACL_RECOVERY = {
    "api-token": "replace api-token: stop the stack, remove only api-token, unset LIVEMORE_API_TOKEN, and restart through the CLI (no token replacement command)",
    "patch-storage.key": "patch-storage.key exposes what it encrypts; keep it pending recovery: rotation requires re-encrypting protected data and is not yet available",
    "patch-admission.key": "patch-admission.key lets that account forge admissions and device manifests; keep it pending recovery: rotation requires re-encryption and is not yet available",
    "livemore-sign-hmac.key": "livemore-sign-hmac.key lets that account forge audit records; it must be replaced; no product rotation/re-signing procedure is available",
    "evidence.sqlite.audit.key": "evidence.sqlite.audit.key lets that account forge audit records; it must be replaced using a new externally managed LIVEMORE_EVIDENCE_AUDIT_HMAC_KEY and LIVEMORE_EVIDENCE_AUDIT_KEY_VERSION, retaining previous verification keys in LIVEMORE_EVIDENCE_AUDIT_HMAC_VERIFICATION_KEYS (old local key version local-file-v1; exposed old-version records remain untrusted)",
    "evidence-signing-ed25519.key": "evidence-signing-ed25519.key lets that account sign evidence exports; it must be replaced using LIVEMORE_EVIDENCE_SIGNING_KEY or LIVEMORE_EVIDENCE_SIGNING_KEY_FILE and a new LIVEMORE_EVIDENCE_SIGNING_KEY_ID; distribute the new trusted public key out of band and revoke trust in the old key",
}

_ACL_RECOVERY["patch-storage-key"] = _ACL_RECOVERY["patch-storage.key"].replace(
    "patch-storage.key", "patch-storage-key",
)
_ACL_RECOVERY["patch-admission-key"] = _ACL_RECOVERY["patch-admission.key"].replace(
    "patch-admission.key", "patch-admission-key",
)
_ACL_RECOVERY["service-identity.key"] = (
    "service-identity.key lets that account impersonate every service in this stack; "
    "stop the stack, replace it with livemore identity rotate, then restart every service "
    "and recreate attached clients (replace an externally managed LIVEMORE_SERVICE_IDENTITY_KEY separately)"
)


def _credential_files(target: str) -> tuple[dict[str, str], list[str]]:
    """Configured companions inside this admitted tree join its fixed names.

    Resolve the parent only: following a final credential symlink would turn
    the read-only linked-file policy into a repair of its target. Canonical
    relative names are later opened below the pinned data-directory descriptor.
    Unresolvable entries are reported separately and never stop directory repair.
    """
    credentials = dict(_ACL_RECOVERY)
    unresolved: list[str] = []
    subject = os.environ.get("LIVEMORE_SUBJECT_REGISTRY", "")
    evidence = os.environ.get("LIVEMORE_EVIDENCE_DB", str(Path(target) / "evidence.sqlite"))
    signing = os.environ.get("LIVEMORE_EVIDENCE_SIGNING_KEY_FILE", "")
    default_subject = str(Path(target) / "subjects.sqlite3")
    configured = [
        (subject or default_subject, subject.strip() or default_subject, ".bootstrap-key",
         "lets that account forge subject-registry bootstrap authority; no product rotation or re-signing procedure is available"),
        (evidence, evidence, ".audit.key", _ACL_RECOVERY["evidence.sqlite.audit.key"].split(" ", 1)[1]),
    ]
    if signing.strip():
        configured.append((signing, signing.strip(), "", _ACL_RECOVERY["evidence-signing-ed25519.key"].split(" ", 1)[1]))
    try:
        data_directory = Path(target).expanduser().resolve(strict=False)
    except (RuntimeError, OSError, ValueError):
        # Without a canonical root, no configured companion can be scoped safely.
        return credentials, [text for text, *_ in configured]
    for text, raw, suffix, recovery in configured:
        try:
            path = Path(str(Path(raw)) + suffix).expanduser()
            parent = path.parent.resolve(strict=False)
        except (RuntimeError, OSError, ValueError):
            unresolved.append(text)
            continue
        try:
            relative = (parent / path.name).relative_to(data_directory)
        except ValueError:
            continue  # An operator-selected external parent keeps stable's scope.
        if not relative.parts:
            continue  # The admitted directory itself is not a credential file.
        name = str(relative)
        # A configured filename is operator text. Escape controls so the
        # fixed one-line diagnostic cannot gain injected diagnostic lines.
        label = json.dumps(name, ensure_ascii=True)[1:-1]
        advice = f"{label} {recovery}"
        if name not in credentials:
            credentials[name] = advice
        elif advice != credentials[name]:
            # A configured signer may share another fixed credential pathname;
            # retain the recovery obligations of both mechanisms.
            credentials[name] += "; " + advice
    return credentials, unresolved


class DataDirStatus(str):
    """A compatible pathname plus the result of this directory admission pass."""

    private: bool
    code: str | None

    def __new__(cls, path: str, *, private: bool, code: str | None = None):
        result = super().__new__(cls, path)
        result.private, result.code = private, code
        return result


class DataDirSecurityError(RuntimeError):
    """A typed refusal without operator paths or credential contents."""

    def __init__(self, code: str = "STACK_DATA_DIR_UNSAFE"):
        self.code = code
        message = ("a data directory must not be the home directory" if code == "STACK_DATA_DIR_HOME"
                   else "new secret creation requires an owned directory on an ownership-enforcing filesystem with no extended ACL")
        super().__init__(f"{code}: {message}")


def require_secret_creation(status: DataDirStatus) -> None:
    if not status.private:
        raise DataDirSecurityError()


def is_stack_secret_directory(path: str | os.PathLike[str]) -> bool:
    """Limit NEW-7 admission to stack storage, preserving external parents."""
    parent = Path(path).expanduser().resolve(strict=False)
    data_directory = Path(REG_DIR).expanduser().resolve(strict=False)
    # A custom stack's own secrets must not inspect the unused home stack.
    if parent == data_directory or data_directory in parent.parents:
        return True
    default_parent = Path("~/.livemore").expanduser().resolve(strict=False)
    return parent == default_parent


def _is_home(info: os.stat_result) -> bool:
    homes = {os.path.expanduser("~")}
    try:
        import pwd
        homes.add(pwd.getpwuid(os.geteuid()).pw_dir)
    except (ImportError, KeyError):
        # A remapped effective UID can lack a local account record.
        pass
    for path in homes:
        try:
            home = os.stat(path)
        except FileNotFoundError:
            continue
        if (home.st_dev, home.st_ino) == (info.st_dev, info.st_ino):
            return True
    return False


def _tighten_data_dir(target: str, report: Callable[[str], None]) -> DataDirStatus:
    credentials, unresolved = _credential_files(target)
    credential_names = tuple(credentials)
    cleared: set[str] = set()
    linked: set[str] = set()
    failed: set[str] = set()
    repaired: set[tuple[int, int]] = set()
    directory_exposed = False
    directory_private = False
    code: str | None = None
    walk = {"checked": 0, "skipped": 0, "failed": 0, "linked_with_acl": 0}
    walked = False
    opened = False
    darwin = console_filesystem._NATIVE_PLATFORM == "darwin"

    def clear(descriptor: int, names: tuple[str, ...]) -> tuple[bool, bool]:
        foreign = False
        try:
            foreign = console_filesystem.clear_extended_acl(descriptor) if darwin else False
            if foreign:
                cleared.update(names)
            identity = os.fstat(descriptor)
            repaired.add((identity.st_dev, identity.st_ino))
            return True, foreign
        except (OSError, console_filesystem.ConsoleFilesystemError) as error:
            if isinstance(error, console_filesystem.ACLClearError):
                if error.foreign_access_cleared:
                    cleared.update(names)
                foreign = getattr(error, "foreign_access_detected", error.foreign_access_cleared)
            failed.update(names)
            return False, foreign

    def close(descriptor: int, names: tuple[str, ...]) -> bool:
        try:
            os.close(descriptor)
            return True
        except OSError:
            failed.update(names)
            return False

    def open_child(parent: int, name: str, before: os.stat_result, device: int) -> int:
        flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
        if stat.S_ISDIR(before.st_mode):
            flags |= os.O_DIRECTORY
        child = os.open(name, flags, dir_fd=parent)
        try:
            current = os.fstat(child)
            if (current.st_uid != os.geteuid() or current.st_dev != device
                    or (current.st_dev, current.st_ino) != (before.st_dev, before.st_ino)
                    or stat.S_IFMT(current.st_mode) != stat.S_IFMT(before.st_mode)
                    or current.st_nlink != before.st_nlink):
                raise OSError("directory entry changed")
            return child
        except BaseException:
            close(child, ())
            raise

    def visit(parent: int, device: int) -> None:
        try:
            names = sorted(os.listdir(parent))
        except OSError:
            walk["failed"] += 1
            return
        for name in names:
            try:
                before = os.stat(name, dir_fd=parent, follow_symlinks=False)
                if (before.st_uid != os.geteuid() or before.st_dev != device
                        or not (stat.S_ISDIR(before.st_mode) or stat.S_ISREG(before.st_mode))):
                    walk["skipped"] += 1
                    continue
                if stat.S_ISREG(before.st_mode) and before.st_nlink > 1:
                    # A shared inode is never rewritten (it may be a file outside
                    # this tree), but one that still carries an access entry may
                    # be readable through another account's link: inspect it
                    # read-only and count it, so the walk does not say complete.
                    walk["skipped"] += 1
                    shared = open_child(parent, name, before, device)
                    try:
                        if console_filesystem.has_extended_acl(shared):
                            walk["linked_with_acl"] += 1
                    except console_filesystem.ConsoleFilesystemError:
                        walk["failed"] += 1
                    finally:
                        if not close(shared, ()):
                            walk["failed"] += 1
                    continue
                child = open_child(parent, name, before, device)
                try:
                    if (before.st_dev, before.st_ino) not in repaired:
                        okay, _ = clear(child, ())
                        walk["checked"] += int(okay)
                        walk["failed"] += int(not okay)
                    if stat.S_ISDIR(before.st_mode):
                        visit(child, device)
                finally:
                    if not close(child, ()):
                        walk["failed"] += 1
            except OSError:
                walk["failed"] += 1

    try:
        try:
            descriptor = os.open(target, os.O_RDONLY | os.O_DIRECTORY | os.O_NONBLOCK)
        except PermissionError:
            descriptor = os.open(target, getattr(
                os, "O_SEARCH", _DARWIN_O_SEARCH if sys.platform == "darwin" else os.O_RDONLY | os.O_DIRECTORY,
            ))
        opened = True
        try:
            info = os.fstat(descriptor)
            if _is_home(info):
                raise DataDirSecurityError("STACK_DATA_DIR_HOME")
            if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid():
                code = "STACK_DATA_DIR_NOT_OWNED"
                report(f"{code}: data directory is not owned by the effective user; new secret creation refused")
                return DataDirStatus(target, private=False, code=code)
            mode_okay = True
            try:
                os.fchmod(descriptor, stat.S_IMODE(info.st_mode) & 0o700)
            except (OSError, console_filesystem.ConsoleFilesystemError):
                failed.update(credential_names)
                mode_okay = False
            try:
                console_filesystem.require_ownership_filesystem(descriptor)
            except console_filesystem.ConsoleFilesystemError:
                code = "STACK_DATA_DIR_FILESYSTEM_UNSAFE"
                report(f"{code}: data directory filesystem ownership is unsupported or not enforced; new secret creation refused")
                return DataDirStatus(target, private=False, code=code)
            acl_okay, directory_exposed = clear(descriptor, credential_names)
            # This pass reads no credential. It must precede linked-file refusal.
            for name in credential_names if darwin else ():
                parents: list[int] = []
                try:
                    parent = descriptor
                    parts = Path(name).parts
                    for component in parts[:-1]:
                        before_parent = os.stat(component, dir_fd=parent, follow_symlinks=False)
                        if not stat.S_ISDIR(before_parent.st_mode):
                            raise OSError("credential parent is not a directory")
                        parent = open_child(parent, component, before_parent, info.st_dev)
                        parents.append(parent)
                    before = os.stat(parts[-1], dir_fd=parent, follow_symlinks=False)
                    if (not stat.S_ISREG(before.st_mode) or before.st_nlink < 1
                            or before.st_uid != os.geteuid() or before.st_dev != info.st_dev):
                        continue
                    if before.st_nlink > 1:
                        linked.add(name)
                    credential = open_child(parent, parts[-1], before, info.st_dev)
                    try:
                        if before.st_nlink > 1:
                            # A shared inode may belong to a file outside this
                            # tree. Revoking its DENYs could weaken that file.
                            try:
                                console_filesystem.has_extended_acl(credential)
                            except (OSError, console_filesystem.ConsoleFilesystemError):
                                failed.add(name)
                        else:
                            clear(credential, (name,))
                    finally:
                        close(credential, (name,))
                except FileNotFoundError:
                    continue
                except OSError:
                    failed.add(name)
                finally:
                    for parent in reversed(parents):
                        close(parent, (name,))
            if darwin and directory_exposed:
                # Enumerate each directory once, never resolve a child pathname.
                # Shared credentials were inspected; shared tree files are skipped.
                walked = True
                visit(descriptor, info.st_dev)
            directory_private = mode_okay and acl_okay
        finally:
            if not close(descriptor, credential_names):
                directory_private = False
    except DataDirSecurityError as error:
        report(str(error))
        raise
    except OSError:
        # Preserve the parent's removal-only repair when no descriptor opens.
        # It cannot qualify the ACL or ownership filesystem for creation.
        if not opened:
            try:
                info = os.stat(target)
                if _is_home(info):
                    error = DataDirSecurityError("STACK_DATA_DIR_HOME")
                    report(str(error))
                    raise error
                if stat.S_ISDIR(info.st_mode) and info.st_uid == os.geteuid():
                    os.chmod(target, stat.S_IMODE(info.st_mode) & 0o700)
            except OSError:
                pass
        failed.update(credential_names)
    finally:
        exposed = cleared | linked
        if directory_exposed:
            exposed.update(credential_names)
        detail = ""
        if exposed:
            names = ", ".join(json.dumps(name, ensure_ascii=True)[1:-1]
                              for name in credential_names if name in exposed)
            guidance = "; ".join(credentials[name] for name in credential_names if name in exposed)
            exposure = "treat these secrets as exposed to that account"
            if directory_exposed:
                exposure += "; every file in the data directory was readable by that account while the entry stood"
            if linked:
                exposure += "; each named hard link exposes its credential value to whoever holds the other link: " + ", ".join(json.dumps(name, ensure_ascii=True)[1:-1] for name in sorted(linked))
                exposure += "; hard-linked credential ACLs left unchanged"
            if walked:
                result = "partial" if walk["failed"] or walk["linked_with_acl"] else "complete"
                exposure += (f"; tree ACL walk result={result} checked={walk['checked']} skipped={walk['skipped']} "
                             f"failed={walk['failed']} linked_with_acl={walk['linked_with_acl']}")
                if walk["linked_with_acl"]:
                    exposure += ("; files with more than one link keep their access entries and another account "
                                 "may still read them through its link: with the stack stopped, copy each such "
                                 "file to a new file and replace the original")
            detail = f"{names}; {exposure}; {guidance}."
            if cleared or linked:
                diagnostic = "STACK_CREDENTIAL_ACL_CLEARED" if cleared else "STACK_CREDENTIAL_ACL_EXPOSED"
                report(f"{diagnostic}: {detail}")
        if failed or unresolved:
            unavailable = [name for name in credential_names if name in failed] + unresolved
            names = ", ".join(json.dumps(name, ensure_ascii=True)[1:-1]
                              for name in unavailable)
            reason = "extended ACL inspection or clearing failed; " if failed else ""
            if unresolved:
                reason += "configured credential path could not be resolved; "
            report(f"STACK_CREDENTIAL_ACL_UNAVAILABLE: {names}; {reason}credential exposure could not be ruled out; new secret creation requires a verified private directory."
                   + (f" {detail}" if detail and not (cleared or linked) else ""))
    if not directory_private:
        code = "STACK_CREDENTIAL_ACL_UNAVAILABLE"
    return DataDirStatus(target, private=directory_private, code=code)


def ensure_data_dir(path: str | None = None, *, report: Callable[[str], None] | None = None) -> DataDirStatus:
    """Repair directory privacy and return fresh secret-creation eligibility."""
    target = path or REG_DIR
    reporter = report if report is not None else logging.getLogger(__name__).warning
    try:
        os.makedirs(target, mode=0o700, exist_ok=True)
    except OSError:
        code = "STACK_CREDENTIAL_ACL_UNAVAILABLE"
        reporter(f"{code}: data directory could not be created or inspected; new secret creation refused")
        return DataDirStatus(target, private=False, code=code)
    return _tighten_data_dir(target, reporter)


def _load():
    try:
        with open(REG, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def register(name, port, pid):
    ensure_data_dir()
    r = _load()
    r[name] = {"port": port, "pid": pid, "url": f"http://127.0.0.1:{port}", "ts": time.time()}
    with open(REG, "w", encoding="utf-8") as f:
        json.dump(r, f, indent=2)


def unregister(name):
    r = _load()
    r.pop(name, None)
    with open(REG, "w", encoding="utf-8") as f:
        json.dump(r, f, indent=2)


def registry():
    return _load()


def url_of(name):
    return (_load().get(name) or {}).get("url")
