"""Local stack identity material and immutable, credential-free proof inputs.

This module neither contacts a service nor installs a route. Identity material
has its own namespace and never derives from an operator or patch credential.
"""
from __future__ import annotations

import base64
from collections.abc import Mapping
from contextlib import contextmanager
from dataclasses import dataclass, field
import errno
import hashlib
import hmac
import os
from pathlib import Path
import re
import secrets
import stat
import time
from typing import Iterator

from . import _platform, console_filesystem, registry, security


IDENTITY_KEY_ENV = "LIVEMORE_SERVICE_IDENTITY_KEY"
IDENTITY_KEY_FILE = "service-identity.key"
_KEY_TEXT = re.compile(r"[A-Za-z0-9_-]{43}=")
_ROLES = {"aegle": b"\x01", "life": b"\x02", "cendos": b"\x03"}
_STACK_ID_TAG = b"LivemoreBio/stack-id/v1\0"
_HKDF_SALT = b"LivemoreBio/service-identity/hkdf/v1\0"
_PROOF_KEY_TAG = b"LivemoreBio/service-proof/server-key/v1\0"
_RESPONSE_TAG = b"LivemoreBio/service-proof/response/v1\0"
_FILE_REPAIR = (
    "stop every service in this stack (`livemore stop all`, or `livemore down` for Compose), "
    "run `livemore identity rotate`, restart every service and recreate attached clients."
)


class IdentityError(RuntimeError):
    """A fixed diagnostic, containing no credential or operator path."""

    def __init__(self, message: str = "identity key is missing or invalid", *,
                 code: str = "SERVICE_IDENTITY_UNPROVEN"):
        self.code = code
        super().__init__(f"{code}: {message}")


class IdentityPlatformUnsupported(IdentityError):
    """Local platform refusal, before any filesystem admission or dial."""

    endpoint_reachable = False

    def __init__(self) -> None:
        super().__init__(
            "Service identity requires POSIX descriptor and owner-only file protections. "
            + _platform.CONTAINER_GUIDANCE,
            code="SERVICE_IDENTITY_PLATFORM_UNSUPPORTED")


def _require_identity_platform() -> None:
    try:
        _platform.require_posix("Service identity")
    except _platform.UnsupportedPlatformError:
        raise IdentityPlatformUnsupported() from None
    required = ("O_DIRECTORY", "O_NOFOLLOW", "O_NONBLOCK", "geteuid", "fchmod")
    directory_operations = {"open", "stat", "link", "unlink", "rmdir"}
    # Capability names remain stable when a test wraps an OS call to exercise
    # a filesystem race; no unsupported operation gets a weaker fallback.
    directory_support = {operation.__name__ for operation in os.supports_dir_fd}
    follow_support = {operation.__name__ for operation in os.supports_follow_symlinks}
    if (not all(hasattr(os, name) for name in required)
            or not directory_operations <= directory_support
            or not {"stat", "link"} <= follow_support):
        raise IdentityPlatformUnsupported()


def _unsafe_identity_file(detail: str) -> IdentityError:
    return IdentityError(f"{detail}; {_FILE_REPAIR}", code="STACK_CREDENTIAL_UNSAFE")


def _bytes32(value: bytes, name: str) -> bytes:
    if not isinstance(value, bytes) or len(value) != 32:
        raise IdentityError(f"{name} must be exactly 32 immutable bytes")
    return value


def encode_identity_key(key: bytes, *, file: bool = False) -> str:
    """Encode the one canonical environment form, or that form plus one LF."""
    text = base64.urlsafe_b64encode(_bytes32(key, "identity key")).decode("ascii")
    return text + "\n" if file else text


def decode_identity_key(value: str, *, file: bool = False) -> bytes:
    """Reject whitespace, alternate alphabets, padding aliases and pad bits."""
    if not isinstance(value, str):
        raise IdentityError()
    if file:
        if len(value) != 45 or not value.endswith("\n"):
            raise IdentityError()
        value = value[:-1]
    if _KEY_TEXT.fullmatch(value) is None:
        raise IdentityError()
    try:
        decoded = base64.b64decode(value, altchars=b"-_", validate=True)
    except ValueError:
        raise IdentityError() from None
    if len(decoded) != 32 or encode_identity_key(decoded) != value:
        raise IdentityError()
    return decoded


def stack_id(key: bytes) -> bytes:
    return hashlib.sha256(_STACK_ID_TAG + _bytes32(key, "identity key")).digest()


@dataclass(frozen=True)
class IdentitySnapshot:
    """One locally admitted generation, role and audience for an operation."""

    key: bytes = field(repr=False)
    role: str
    authority: str
    sid: bytes = field(init=False)

    def __post_init__(self) -> None:
        from .service_identity_config import canonical_authority

        _bytes32(self.key, "identity key")
        if not isinstance(self.role, str) or self.role not in _ROLES:
            raise IdentityError("service role must be aegle, life or cendos")
        canonical = canonical_authority(self.authority)
        if canonical != self.authority:
            raise IdentityError("snapshot authority must be canonical",
                                code="SERVICE_IDENTITY_CONFIGURATION_INVALID")
        object.__setattr__(self, "sid", stack_id(self.key))

    @property
    def role_byte(self) -> bytes:
        return _ROLES[self.role]


def proof_prk(key: bytes) -> bytes:
    """HKDF-Extract under the protocol's fixed identity namespace."""
    return hmac.new(_HKDF_SALT, _bytes32(key, "identity key"), hashlib.sha256).digest()


def _audience(snapshot: IdentitySnapshot) -> bytes:
    authority = snapshot.authority.encode("ascii")
    return snapshot.sid + snapshot.role_byte + len(authority).to_bytes(2, "big") + authority


def proof_key(snapshot: IdentitySnapshot) -> bytes:
    """HKDF-Expand's one SHA-256 block, for the server-proof purpose only."""
    return hmac.new(proof_prk(snapshot.key), _PROOF_KEY_TAG + _audience(snapshot) + b"\x01",
                    hashlib.sha256).digest()


def proof_transcript(snapshot: IdentitySnapshot, nonce: bytes, instance: bytes,
                     server_random: bytes) -> bytes:
    return (_RESPONSE_TAG + _audience(snapshot) + _bytes32(nonce, "client nonce")
            + _bytes32(instance, "service instance") + _bytes32(server_random, "server random"))


def proof_mac(snapshot: IdentitySnapshot, nonce: bytes, instance: bytes,
              server_random: bytes) -> bytes:
    return hmac.new(proof_key(snapshot), proof_transcript(snapshot, nonce, instance, server_random),
                    hashlib.sha256).digest()


def proof_response(snapshot: IdentitySnapshot, nonce: bytes, instance: bytes,
                   server_random: bytes) -> bytes:
    return instance + server_random + proof_mac(snapshot, nonce, instance, server_random)


def verify_proof_response(snapshot: IdentitySnapshot, nonce: bytes, body: bytes) -> bool:
    if not isinstance(body, bytes) or len(body) != 96:
        return False
    try:
        expected = proof_mac(snapshot, nonce, body[:32], body[32:64])
    except IdentityError:
        return False
    return hmac.compare_digest(expected, body[64:])


def _directory_private(descriptor: int) -> None:
    info = os.fstat(descriptor)
    if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid()
            or stat.S_IMODE(info.st_mode) != 0o700):
        raise registry.DataDirSecurityError()
    try:
        console_filesystem.require_ownership_filesystem(descriptor)
        if console_filesystem.has_extended_acl(descriptor):
            raise registry.DataDirSecurityError()
    except console_filesystem.ConsoleFilesystemError:
        raise registry.DataDirSecurityError() from None


@contextmanager
def _open_directory(directory: str | os.PathLike[str]) -> Iterator[int]:
    _require_identity_platform()
    # NEW-7 permits an operator-selected directory alias; a pinned descriptor
    # keeps subsequent file operations inside whichever directory was admitted.
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NONBLOCK
    try:
        descriptor = os.open(directory, flags)
    except OSError as error:
        if error.errno in {errno.ELOOP, errno.ENOTDIR}:
            raise registry.DataDirSecurityError() from None
        raise
    try:
        _directory_private(descriptor)
        yield descriptor
    finally:
        os.close(descriptor)


@contextmanager
def _open_identity_file(directory: int, path: str) -> Iterator[int]:
    deadline = time.monotonic() + 0.2
    before = os.stat(IDENTITY_KEY_FILE, dir_fd=directory, follow_symlinks=False)
    inspect = lambda: os.stat(IDENTITY_KEY_FILE, dir_fd=directory, follow_symlinks=False)
    security._require_single_link(path, before, inspect, deadline)
    try:
        descriptor = os.open(IDENTITY_KEY_FILE, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                             dir_fd=directory)
    except OSError as error:
        if error.errno == errno.ELOOP:
            raise security.CredentialFileError(path, stat.S_IFLNK) from None
        raise
    try:
        current = os.fstat(descriptor)
        security._require_single_link(path, current, lambda: os.fstat(descriptor), deadline)
        if (current.st_dev, current.st_ino) != (before.st_dev, before.st_ino):
            raise _unsafe_identity_file("identity file changed during admission")
        if current.st_uid != os.geteuid() or stat.S_IMODE(current.st_mode) != 0o600:
            raise _unsafe_identity_file("identity file must be effective-user-owned and mode 0600")
        try:
            console_filesystem.require_ownership_filesystem(descriptor)
            if console_filesystem.has_extended_acl(descriptor):
                raise _unsafe_identity_file("identity file must have an empty extended ACL")
        except console_filesystem.ConsoleFilesystemError:
            raise _unsafe_identity_file("identity filesystem protections could not be verified") from None
        yield descriptor
    finally:
        os.close(descriptor)


def _read_identity_file(directory: int, path: str) -> bytes:
    with _open_identity_file(directory, path) as descriptor:
        # One extra byte detects overlength input without retaining arbitrary
        # file contents. Binary reading also preserves CRLF for strict refusal.
        raw = os.read(descriptor, 46)
        try:
            text = raw.decode("utf-8")
            return decode_identity_key(text, file=True)
        except (UnicodeDecodeError, IdentityError):
            raise IdentityError(f"local identity key is invalid; {_FILE_REPAIR}",
                                code="SERVICE_IDENTITY_KEY_INVALID") from None


def _publish_identity(directory: int, candidate: bytes) -> None:
    temporary = f"{IDENTITY_KEY_FILE}.{os.getpid()}.{secrets.token_hex(8)}.tmp"
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         0o600, dir_fd=directory)
    removed = False
    try:
        try:
            os.fchmod(descriptor, 0o600)
        except BaseException:
            os.close(descriptor)
            raise
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            stream.write(encode_identity_key(candidate, file=True))
            stream.flush()
            os.fsync(stream.fileno())
        # Reuse NEW-7's bounded publication synchronization while resolving both
        # names relative to the directory descriptor, never a swapped parent.
        with security._SECRET_PUBLICATION_LOCK:
            try:
                os.link(temporary, IDENTITY_KEY_FILE, src_dir_fd=directory,
                        dst_dir_fd=directory, follow_symlinks=False)
            except FileExistsError:
                pass
            finally:
                os.unlink(temporary, dir_fd=directory)
                removed = True
        os.fsync(directory)
    finally:
        if not removed:
            with security._SECRET_PUBLICATION_LOCK:
                try:
                    os.unlink(temporary, dir_fd=directory)
                except FileNotFoundError:
                    pass


def service_identity_key(*, create: bool = False,
                         directory: str | os.PathLike[str] | None = None,
                         environ: Mapping[str, str] | None = None) -> bytes | None:
    """Resolve explicit environment or an admitted file, without caching it.

    A present environment variable, including an empty value, is authoritative.
    Creation never repairs existing content and never copies disk material into
    the process environment.
    """
    _require_identity_platform()
    environment = os.environ if environ is None else environ
    if IDENTITY_KEY_ENV in environment:
        try:
            return decode_identity_key(environment[IDENTITY_KEY_ENV])
        except IdentityError:
            raise IdentityError(
                "externally managed identity key is invalid; replace the externally managed value, "
                "then restart every service and client.", code="SERVICE_IDENTITY_KEY_INVALID") from None
    selected = os.fspath(directory) if directory is not None else registry.REG_DIR
    path = str(Path(selected) / IDENTITY_KEY_FILE)
    if create:
        # NEW-7 repairs only directory/ACL privacy; content and link admission
        # remain below, before entropy or non-overwriting publication.
        status = registry.ensure_data_dir(selected)
    try:
        with _open_directory(selected) as descriptor:
            try:
                return _read_identity_file(descriptor, path)
            except FileNotFoundError:
                if not create:
                    return None
                registry.require_secret_creation(status)
            _publish_identity(descriptor, secrets.token_bytes(32))
            return _read_identity_file(descriptor, path)
    except FileNotFoundError:
        if not create:
            return None
        raise


def remove_identity_file(directory: str | os.PathLike[str]) -> None:
    """Remove an identity entry under an admitted directory, never its target.

    The launcher is responsible for refusing its recorded live processes and
    explicit environment identities before invoking this operation.
    """
    with _open_directory(directory) as parent:
        try:
            entry = os.stat(IDENTITY_KEY_FILE, dir_fd=parent, follow_symlinks=False)
        except FileNotFoundError:
            return
        try:
            # Only directory privacy admits replacement. Requiring the exposed
            # entry's ownership, ACL, mode, links or content would block repair.
            if stat.S_ISDIR(entry.st_mode):
                try:
                    os.rmdir(IDENTITY_KEY_FILE, dir_fd=parent)
                except OSError as error:
                    if error.errno in {errno.ENOTEMPTY, errno.EEXIST}:
                        raise IdentityError(
                            "identity rotation refused: the identity entry is a non-empty directory; "
                            "stop every service in this stack and move its contents to a safe location "
                            "before retrying `livemore identity rotate`.",
                            code="STACK_CREDENTIAL_UNSAFE") from None
                    raise
            else:
                os.unlink(IDENTITY_KEY_FILE, dir_fd=parent)
            os.fsync(parent)
        except FileNotFoundError:
            raise _unsafe_identity_file("identity file changed during rotation") from None
