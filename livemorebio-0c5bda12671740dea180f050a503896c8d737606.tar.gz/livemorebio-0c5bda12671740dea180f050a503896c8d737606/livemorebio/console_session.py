"""Single-use console authorization shared by the CLI and browser tools."""
from __future__ import annotations

import http.client
import base64
from dataclasses import dataclass
import hashlib
import html
import io
from http.cookies import SimpleCookie
import json
import os
from pathlib import Path
import re
import secrets
import socket
import stat
import sys
import time
from urllib.parse import urlencode, urlsplit
import urllib.error

from . import console_filesystem, security, stack_client, stack_transport
from .security import authorization_headers
from .registry import DataDirSecurityError
from .service_identity import IdentityError
from .service_identity_config import ServiceIdentityConfigurationInvalid


class ConsoleSessionError(RuntimeError):
    """A code could not be minted; callers must open no browser."""

    code = "CONSOLE_CODE_UNAVAILABLE"


class ConsoleOriginError(ConsoleSessionError):
    """The exchange cannot attach credentials outside a loopback origin."""

    code = "CONSOLE_ORIGIN_NOT_LOOPBACK"


class ConsolePeerRefusedError(ConsoleSessionError):
    """The session endpoint refused the network peer, not its bearer."""

    code = "CONSOLE_PEER_REFUSED"


class ConsoleLaunchDirectoryUnsafeError(ConsoleSessionError):
    """The browser's pathname is not protected against other OS users."""

    code = "CONSOLE_LAUNCH_DIRECTORY_UNSAFE"

    def __init__(self, path: str, reason: str):
        super().__init__(f"Console launch directory refused: {path!r}: {reason}.")


class _ConsoleLaunchDirectoryAbsentError(ConsoleLaunchDirectoryUnsafeError):
    """Only the final launch component is absent after its ancestors were admitted."""


class ConsoleExchangeFailedError(ConsoleSessionError):
    """Automatic launch failed without disclosing its short-lived credential."""

    code = "CONSOLE_EXCHANGE_FAILED"

    def __init__(self):
        super().__init__("Console launch failed. Run `livemore open --print-url` for the connection page and separate one-time code.")


_LAUNCH_NAME = re.compile(r"console-open-[0-9a-f]{32}\.html\Z")
_CODE_SHAPE = re.compile(r"[A-Za-z0-9_-]{43}\Z")
_MANUAL_CODE_SHAPE = re.compile(r"[0-9A-HJKMNP-TV-Z]{4}(?:-[0-9A-HJKMNP-TV-Z]{4}){3}\Z")
_SUBMIT_SCRIPT = "document.forms[0].submit();"
_SUBMIT_DIGEST = base64.b64encode(hashlib.sha256(_SUBMIT_SCRIPT.encode("ascii")).digest()).decode("ascii")


@dataclass
class ConsoleLaunchDirectory:
    """A pinned, admitted directory; no launch operation reopens its pathname."""

    path: str
    descriptor: int

    def __enter__(self):
        return self

    def __exit__(self, exception_type, *_):
        try:
            os.close(self.descriptor)
        except OSError:
            if exception_type is None:
                raise ConsoleExchangeFailedError() from None

    def require_path_identity(self) -> None:
        with admit_console_launch_directory(os.path.dirname(self.path), create=False) as current:
            pinned, named = os.fstat(self.descriptor), os.fstat(current.descriptor)
            if (pinned.st_dev, pinned.st_ino) != (named.st_dev, named.st_ino):
                raise ConsoleLaunchDirectoryUnsafeError(self.path, "directory identity changed")

    def prune(self) -> None:
        deadline = time.time() - security.SESSION_CODE_TTL
        for name in os.listdir(self.descriptor):
            if not _LAUNCH_NAME.fullmatch(name):
                continue
            try:
                info = os.stat(name, dir_fd=self.descriptor, follow_symlinks=False)
                if (stat.S_ISREG(info.st_mode) and info.st_uid == os.geteuid()
                        and stat.S_IMODE(info.st_mode) == 0o600 and info.st_nlink == 1
                        and info.st_mtime < deadline):
                    os.unlink(name, dir_fd=self.descriptor)
            except FileNotFoundError:
                # Another open may have pruned the same expired technical artifact.
                continue

    def unlink(self, name: str) -> None:
        try:
            os.unlink(name, dir_fd=self.descriptor)
        except FileNotFoundError:
            pass

    def write_page(self, origin: str, code: str) -> str:
        escaped_origin, escaped_code = html.escape(origin, quote=True), html.escape(code, quote=True)
        page = (f'<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; '
                f'form-action {escaped_origin}; script-src \'sha256-{_SUBMIT_DIGEST}\'; base-uri \'none\'">\n'
                '<meta name="referrer" content="no-referrer">\n'
                '<title>Open the Livemore console</title>\n'
                f'<form method="post" action="{escaped_origin}/api/session/exchange" '
                'enctype="application/x-www-form-urlencoded">\n'
                f'<input type="hidden" name="code" value="{escaped_code}">\n'
                '<button type="submit">Open the Livemore console</button>\n</form>\n'
                f'<script>{_SUBMIT_SCRIPT}</script>\n')
        name = ""
        descriptor = None
        try:
            for _ in range(3):
                candidate = "console-open-" + secrets.token_hex(16) + ".html"
                try:
                    descriptor = os.open(candidate, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                                         0o600, dir_fd=self.descriptor)
                except FileExistsError:
                    continue
                name = candidate
                break
            if descriptor is None:
                raise ConsoleExchangeFailedError()
            info = os.fstat(descriptor)
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid()
                    or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1):
                raise ConsoleExchangeFailedError()
            console_filesystem.require_empty_page_acl(descriptor)
            stream = os.fdopen(descriptor, "w", encoding="utf-8")
            descriptor = None
            with stream:
                stream.write(page)
                stream.flush()
                os.fsync(stream.fileno())
            self.require_path_identity()
            return name
        except BaseException as error:
            # Interruptions must clean the credential page and cannot expose
            # private exception text through the CLI's top-level traceback.
            if descriptor is not None:
                try:
                    os.close(descriptor)
                except OSError:
                    pass
            if name:
                try:
                    self.unlink(name)
                except OSError:
                    pass
            if isinstance(error, console_filesystem.ConsoleFilesystemError):
                raise ConsoleLaunchDirectoryUnsafeError(os.path.join(self.path, name), str(error)) from None
            raise ConsoleExchangeFailedError() from None


def admit_console_launch_directory(data_dir: str, *, create: bool = True) -> ConsoleLaunchDirectory:
    """Admit every ancestor, then the exact private launch directory, using openat.

    The browser subsequently resolves a pathname. A descriptor alone cannot keep
    another user from substituting a component in that browser pathname.
    """
    if (not isinstance(data_dir, str) or not data_dir or "\0" in data_dir
            or not os.path.isabs(data_dir)):
        raise ConsoleLaunchDirectoryUnsafeError("<invalid>", "an absolute data directory is required")
    if not all(hasattr(os, name) for name in ("O_DIRECTORY", "O_NOFOLLOW", "geteuid")):
        raise ConsoleLaunchDirectoryUnsafeError(data_dir, "required POSIX directory protections are unavailable")
    # Links of the configured path (macOS /tmp and /var, a linked home or data
    # directory) are resolved once, here. The walk below then admits the
    # resolved components without following any link, and the browser is given
    # this resolved path, so no later change of a link can redirect it.
    launch_path = os.path.join(os.path.realpath(data_dir), "console-launch")
    parts = Path(launch_path).parts[1:]
    descriptor = None
    current_path = "/"
    try:
        descriptor = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        previous = os.fstat(descriptor)
        effective_uid = os.geteuid()
        if (previous.st_uid not in {0, effective_uid}
                or previous.st_mode & 0o022 and not previous.st_mode & stat.S_ISVTX):
            raise ConsoleLaunchDirectoryUnsafeError("/", "ancestor owner or permissions are unsafe")
        console_filesystem.require_no_foreign_acl_writes(descriptor)
        for index, component in enumerate(parts):
            current_path = os.path.join(current_path, component)
            try:
                child = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=descriptor)
            except FileNotFoundError:
                if not create:
                    if index == len(parts) - 1:
                        raise _ConsoleLaunchDirectoryAbsentError(current_path, "directory does not exist") from None
                    raise
                try:
                    os.mkdir(component, mode=0o700, dir_fd=descriptor)
                except FileExistsError:
                    pass
                child = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=descriptor)
            try:
                os.close(descriptor)
            except OSError:
                # A close error must not abandon the child opened above.
                try:
                    os.close(child)
                except OSError:
                    pass
                raise
            descriptor = child
            current = os.fstat(descriptor)
            if not stat.S_ISDIR(current.st_mode):
                raise ConsoleLaunchDirectoryUnsafeError(current_path, "not a directory")
            if previous.st_mode & 0o022 and current.st_uid != effective_uid:
                raise ConsoleLaunchDirectoryUnsafeError(current_path, "entry in a sticky writable ancestor is not owned by the effective user")
            if index == len(parts) - 1:
                if current.st_uid != effective_uid:
                    raise ConsoleLaunchDirectoryUnsafeError(current_path, "directory is not owned by the effective user")
                if stat.S_IMODE(current.st_mode) != 0o700:
                    raise ConsoleLaunchDirectoryUnsafeError(current_path, "directory mode must be exactly 0700")
            else:
                if current.st_uid not in {0, effective_uid}:
                    raise ConsoleLaunchDirectoryUnsafeError(current_path, "ancestor is not owned by root or the effective user")
                if current.st_mode & 0o022 and not current.st_mode & stat.S_ISVTX:
                    raise ConsoleLaunchDirectoryUnsafeError(current_path, "ancestor is writable by group or others without the sticky bit")
            console_filesystem.require_no_foreign_acl_writes(descriptor)
            if index == len(parts) - 1:
                console_filesystem.require_ownership_filesystem(descriptor)
                console_filesystem.clear_launch_directory_acl(descriptor)
            previous = current
        result = ConsoleLaunchDirectory(launch_path, descriptor)
        descriptor = None
        return result
    except ConsoleLaunchDirectoryUnsafeError:
        raise
    except console_filesystem.ConsoleFilesystemError as error:
        raise ConsoleLaunchDirectoryUnsafeError(current_path, str(error)) from None
    except (OSError, ValueError, TypeError):
        raise ConsoleLaunchDirectoryUnsafeError(current_path, "directory is missing, linked, inaccessible or malformed") from None
    finally:
        if descriptor is not None:
            preserving_error = sys.exc_info()[0] is not None
            try:
                os.close(descriptor)
            except OSError:
                if not preserving_error:
                    raise ConsoleLaunchDirectoryUnsafeError(current_path, "directory descriptor could not be closed") from None


def prune_console_launch_files(data_dir: str, *, best_effort: bool = False) -> None:
    try:
        with admit_console_launch_directory(data_dir, create=False) as directory:
            directory.prune()
    except _ConsoleLaunchDirectoryAbsentError:
        # --print-url and in-container launches never create a local page.
        return
    except (ConsoleSessionError, OSError):
        if not best_effort:
            raise ConsoleExchangeFailedError() from None
        print("  console launch cleanup unavailable; shutdown continues.")


def require_console_browser() -> None:
    """Detect unsupported headless launch before minting a code or writing a page."""
    import webbrowser
    try:
        if sys.platform.startswith("linux") and not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
            raise ConsoleExchangeFailedError()
        if webbrowser.get() is None:
            raise ConsoleExchangeFailedError()
    except Exception:
        raise ConsoleExchangeFailedError() from None


def request_console_launch(origin: str, data_dir: str) -> None:
    """Keep the one-time code inside the private page, never the launch argument."""
    import webbrowser

    origin = require_console_origin(origin)
    require_console_browser()
    with admit_console_launch_directory(data_dir) as directory:
        try:
            directory.prune()
        except OSError:
            raise ConsoleExchangeFailedError() from None
        credential = mint_console_code(origin)
        name = directory.write_page(credential.origin, credential.code)
        try:
            requested = webbrowser.open(Path(directory.path, name).as_uri())
            if not requested:
                raise ConsoleExchangeFailedError()
        except BaseException:
            # Browser backends may exit or be interrupted after publication.
            try:
                directory.unlink(name)
            except OSError:
                pass
            raise ConsoleExchangeFailedError() from None


@dataclass(frozen=True, repr=False)
class ConsoleCode:
    """A credential held in fields, with no implicit secret serialization."""

    origin: str
    code: str
    expires_in: int

    def __repr__(self) -> str:
        return "ConsoleCode(code=[redacted])"


def require_console_origin(origin: str) -> str:
    """Refuse before credentials: the browser exchange accepts only loopback."""
    try:
        parsed = urlsplit(origin)
        valid = (parsed.scheme in {"http", "https"}
                 and parsed.hostname in {"127.0.0.1", "::1", "localhost"}
                 and parsed.username is None and parsed.password is None
                 and parsed.path in {"", "/"} and not parsed.query and not parsed.fragment
                 and not any(character.isspace() or character == "\\" for character in origin)
                 and (parsed.port is None or 1 <= parsed.port <= 65535))
    except ValueError:
        valid = False
    if not valid:
        raise ConsoleOriginError("The console exchange requires a loopback origin.")
    return origin.rstrip("/")


def mint_console_code(origin: str | None = None, *, manual: bool = False,
                      dial_origin: str | None = None) -> ConsoleCode:
    """Mint at the resolved Aegle origin without proxies or redirects.

    Credentials stay out of URLs and representations. Credential-file refusals
    retain their typed reason. Only explicit manual mode uses the pair namespace.
    A manual Compose CLI may separate its fixed service-name dial from the
    loopback browser origin only when the configured proof audience matches it.
    """
    if origin is None:
        from .cli import SERVICES
        origin = f"http://127.0.0.1:{SERVICES['Aegle'][1]}"
    origin = require_console_origin(origin)
    dial = origin
    if dial_origin is not None and dial_origin != origin:
        from .service_identity_config import expected_authority, is_compose_service_dial

        configured = os.environ.get("LIVEMORE_AEGLE_IDENTITY_AUTHORITY")
        if (not manual or not is_compose_service_dial(dial_origin, role="aegle", configured_authority=configured)
                or expected_authority(dial_origin, configured) != origin):
            raise ConsoleOriginError("The internal console dial requires the explicit Compose published authority.")
        dial = dial_origin
    try:
        headers = authorization_headers()
        path = "/api/session/pair-code" if manual else "/api/session/code"
        identity = stack_client.operation_identity("aegle", dial)
        with stack_client.request_response(dial + path, identity=identity, body=b"",
                headers=headers, method="POST", timeout=5, max_response_bytes=None) as response:
            if not 200 <= response.status < 300:
                raise urllib.error.HTTPError(origin + path, response.status, response.msg,
                                              response.headers, io.BytesIO(response.read()))
            payload = json.load(response)
        code = payload.get("code") if isinstance(payload, dict) else None
        shape = _MANUAL_CODE_SHAPE if manual else _CODE_SHAPE
        if not isinstance(code, str) or not shape.fullmatch(code):
            raise ValueError("malformed console code")
        seconds = payload.get("expires_in")
        # Missing or malformed admission inputs are refusals, never defaults.
        if type(seconds) is not int or not 0 < seconds <= security.SESSION_CODE_TTL:
            raise ValueError("malformed console code lifetime")
    except (security.CredentialFileError, DataDirSecurityError, IdentityError,
            ServiceIdentityConfigurationInvalid, stack_transport.ServiceIdentityUnproven):
        raise
    except urllib.error.HTTPError as error:
        payload = None
        if error.code == 403:
            try:
                payload = json.loads(error.read(4096))
            except (OSError, ValueError, http.client.HTTPException):
                payload = None
            if isinstance(payload, dict) and payload.get("code") == "CONSOLE_PEER_REFUSED":
                raise ConsolePeerRefusedError("The console session endpoint refused this peer.") from None
        raise ConsoleSessionError("Console authorization failed. Check this stack's operator token and Aegle.") from None
    except (OSError, ValueError, KeyError, RuntimeError, http.client.HTTPException):
        raise ConsoleSessionError("Console authorization failed. Check this stack's operator token and Aegle.") from None
    return ConsoleCode(origin, code, seconds)


@dataclass(frozen=True, repr=False)
class ConsoleCookie:
    """An admitted host-only session cookie; implicit representations stay private."""

    origin: str
    name: str
    value: str

    def __repr__(self) -> str:
        return "ConsoleCookie(value=[redacted])"

    def cookie_record(self) -> dict:
        return {"name": self.name, "value": self.value, "domain": urlsplit(self.origin).hostname,
                "path": "/", "httpOnly": True, "sameSite": "Strict", "secure": False, "expires": -1}


def mint_console_cookie(origin: str) -> ConsoleCookie:
    """Mint and separately prove exchange, without using a browser request socket.

    Installing this record does not prove later browser sockets (R5/I2). Native
    form exchanges retain that same limit; the Python proof never pins a form's
    later connection.
    """
    credential = mint_console_code(origin)
    try:
        identity = stack_client.operation_identity("aegle", credential.origin)
        result = stack_transport.request(credential.origin + "/api/session/exchange", identity=identity,
            method="POST", headers={"Content-Type": "application/x-www-form-urlencoded"},
            body=urlencode({"code": credential.code}).encode("ascii"), timeout=20)
        values = [value for name, value in result.headers if name.lower() == "set-cookie"]
        if (result.status != 200 or len(values) != 1
                or any(name.lower() == "location" for name, _ in result.headers)):
            raise ValueError("console exchange was not accepted")
        raw = values[0]
        if any(ord(char) < 32 or ord(char) > 126 for char in raw):
            raise ValueError("invalid cookie header")
        fields = [field.strip() for field in raw.split(";")]
        attributes = [field.split("=", 1)[0].lower() for field in fields[1:]]
        if len(attributes) != len(set(attributes)) or set(attributes) != {"httponly", "path", "samesite"}:
            raise ValueError("invalid session cookie attributes")
        parsed = urlsplit(credential.origin)
        expected = security.session_cookie_name(parsed.port or (443 if parsed.scheme == "https" else 80))
        cookie = SimpleCookie()
        cookie.load(raw)
        if list(cookie) != [expected]:
            raise ValueError("invalid session cookie name")
        value = cookie[expected]
        if (not value.value or len(value.value) > 4096
                or not re.fullmatch(r"[A-Za-z0-9_-]+", value.value)
                or value["path"] != "/" or value["httponly"] is not True
                or value["samesite"].lower() != "strict"):
            raise ValueError("invalid session cookie")
        return ConsoleCookie(credential.origin, expected, value.value)
    except (security.CredentialFileError, DataDirSecurityError, IdentityError,
            ServiceIdentityConfigurationInvalid, stack_transport.ServiceIdentityUnproven):
        raise
    except Exception:
        # Never expose parser/HTTP exceptions containing code or cookie fields.
        raise ConsoleExchangeFailedError() from None


def bootstrap_console_cookie_pipe(origin: str, *, descriptor: int = 3) -> None:
    """Write only the admitted cookie record to a nonterminal parent IPC pipe."""
    try:
        if type(descriptor) is not int or descriptor < 3:
            raise ValueError("a private parent descriptor is required")
        mode = os.fstat(descriptor).st_mode
        if not (stat.S_ISFIFO(mode) or stat.S_ISSOCK(mode)):
            raise ValueError("the cookie destination must be a parent pipe")
        if stat.S_ISSOCK(mode):
            # Node's extra stdio pipe is an unnamed AF_UNIX socketpair on POSIX.
            # Never admit a network socket merely because it is not a terminal.
            with socket.socket(fileno=os.dup(descriptor)) as parent_pipe:
                if (parent_pipe.family != socket.AF_UNIX or parent_pipe.type != socket.SOCK_STREAM
                        or parent_pipe.getpeername() not in ("", b"")):
                    raise ValueError("the cookie destination must be an unnamed parent pipe")
    except Exception:
        raise ConsoleExchangeFailedError() from None
    session = mint_console_cookie(origin)
    try:
        payload = json.dumps({"origin": session.origin, "cookie": session.cookie_record()},
                             separators=(",", ":")).encode("utf-8")
        remaining = memoryview(payload)
        while remaining:
            sent = os.write(descriptor, remaining)
            if sent <= 0:
                raise OSError("private pipe closed")
            remaining = remaining[sent:]
    except Exception:
        raise ConsoleExchangeFailedError() from None


def print_console_instructions(origin: str | None = None, *, dial_origin: str | None = None) -> None:
    """Explicit operator output, never suitable for command substitution."""
    credential = (mint_console_code(origin, manual=True) if dial_origin is None else
                  mint_console_code(origin, manual=True, dial_origin=dial_origin))
    print(credential.origin + "/console/connect")
    print("One-time code: " + credential.code)
    print(f"This code works once, within {credential.expires_in} seconds.")
