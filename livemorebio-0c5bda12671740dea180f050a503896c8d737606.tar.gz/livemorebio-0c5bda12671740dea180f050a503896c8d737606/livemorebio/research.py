"""Frozen research protocols, encrypted measurements and falsifiable assessments.

freeze(run, criteria) -> admit(raw bytes, custody) -> compare(stored values)
                                                  -> independent evidence review

No function here modifies a twin or authorizes clinical use/model calibration.
An operator's instrument declaration is retained as an attestation, not verified
instrument authenticity. Raw files stay encrypted and never enter application logs.
"""
from __future__ import annotations

import csv
from datetime import datetime, timezone, timedelta
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import sqlite3
from statistics import fmean, stdev
from typing import Any
from urllib.parse import urlparse
import uuid

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

from .clinical_note_gate import screen_text

OPERATIONS = ("driver", "memory", "repair", "homeostasis", "resilience")
LEVELS = ("atomic", "chemical", "molecular", "genetic", "cellular", "tissue", "organ", "whole_body")
_ID = re.compile(r"^research-[a-f0-9]{32}$")
_KINDS = {"study", "measurement", "comparison", "resilience_protocol", "resilience_assessment", "learning"}


class ResearchError(ValueError):
    """A bounded, PHI-safe message that can be shown to an operator."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _json(value: object) -> bytes:
    try:
        return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    except (ValueError, TypeError) as error:
        raise ResearchError("record must contain finite JSON values") from error


def _hash(value: object) -> str:
    return hashlib.sha256(_json(value)).hexdigest()


def _text(value: object, field: str, maximum: int = 200) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > maximum or any(ord(c) < 32 for c in value):
        raise ResearchError(f"{field} requires bounded text")
    # L0-R15 round 1: research text is kept and echoed; a clinical note's marks are refused.
    return screen_text(value.strip(), field)


def _narrative(value: object, field: str, maximum: int = 2000) -> str:
    """Scientific prose may contain paragraphs; identifiers use the strict parser."""
    if (not isinstance(value, str) or not value.strip() or len(value) > maximum
            or any(not character.isprintable() and character not in "\t\r\n" for character in value)):
        raise ResearchError(f"{field} requires bounded printable text")
    return screen_text(value.strip(), field)


def _identity(value: object, field: str) -> str:
    result = _text(value, field)
    if result != value:
        raise ResearchError(f"{field} must not contain surrounding whitespace")
    return result


def _object(value: object, field: str) -> dict:
    if not isinstance(value, dict):
        raise ResearchError(f"{field} requires a JSON object")
    return value


def _number(value: object, field: str, low: float = -1e12, high: float = 1e12) -> float:
    if isinstance(value, bool):
        raise ResearchError(f"{field} requires a number")
    try:
        result = float(value)
    except (ValueError, TypeError, OverflowError) as error:
        raise ResearchError(f"{field} requires a number") from error
    if not math.isfinite(result) or not low <= result <= high:
        raise ResearchError(f"{field} is outside the allowed range")
    return result


def _time(value: object) -> datetime:
    try:
        result = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (ValueError, OverflowError) as error:
        raise ResearchError("timestamp requires ISO 8601 with timezone") from error
    if result.tzinfo is None or result.utcoffset() is None:
        raise ResearchError("timestamp requires a timezone")
    try:
        return result.astimezone(timezone.utc)
    except (ValueError, OverflowError) as error:
        raise ResearchError("timestamp is outside the allowed range") from error


def _observed_time(value: object) -> datetime:
    result = _time(value)
    if result > datetime.now(timezone.utc):
        raise ResearchError("an observation timestamp cannot be in the future")
    return result


class ResearchStore:
    """Insert-only SQLite payloads encrypted with the existing local owner key."""

    def __init__(self, path: Path, *, key: bytes):
        if len(key) != 32:
            raise ResearchError("research storage requires a 256-bit key")
        self.path = Path(path)
        self.cipher = AESGCM(key)
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        with self._connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS research_records(
                    id TEXT PRIMARY KEY, kind TEXT NOT NULL, created_at TEXT NOT NULL,
                    digest TEXT NOT NULL, nonce BLOB NOT NULL, payload BLOB NOT NULL);
                CREATE TABLE IF NOT EXISTS research_access(
                    sequence INTEGER PRIMARY KEY AUTOINCREMENT, record_id TEXT NOT NULL,
                    action TEXT NOT NULL, occurred_at TEXT NOT NULL);
            """)
        os.chmod(self.path, 0o600)

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.path, timeout=5)

    def put(self, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        if kind not in _KINDS or not isinstance(payload, dict) or any(k in payload for k in ("id", "created_at", "kind", "content_sha256")):
            raise ResearchError("new records require a known kind and cannot overwrite immutable identity")
        record = {**payload, "id": "research-" + uuid.uuid4().hex, "created_at": _now(), "kind": kind}
        digest = _hash(record)
        raw = _json(record)
        if len(raw) > 4_000_000:
            raise ResearchError("research record exceeds 4 MB")
        nonce = os.urandom(12)
        aad = f"research.v1:{record['id']}:{kind}:{digest}".encode()
        encrypted = self.cipher.encrypt(nonce, raw, aad)
        with self._connect() as db:
            db.execute("INSERT INTO research_records VALUES(?,?,?,?,?,?)",
                       (record["id"], kind, record["created_at"], digest, nonce, encrypted))
            db.execute("INSERT INTO research_access(record_id,action,occurred_at) VALUES(?,?,?)",
                       (record["id"], "create", _now()))
        return {**record, "content_sha256": digest}

    def get(self, record_id: str, kind: str | None = None) -> dict[str, Any]:
        if not _ID.fullmatch(str(record_id)):
            raise ResearchError("research record not found")
        with self._connect() as db:
            row = db.execute("SELECT kind,digest,nonce,payload FROM research_records WHERE id=?", (record_id,)).fetchone()
            if row is None or (kind and row[0] != kind):
                raise ResearchError("research record not found")
            try:
                raw = self.cipher.decrypt(row[2], row[3], f"research.v1:{record_id}:{row[0]}:{row[1]}".encode())
                result = json.loads(raw)
            except (InvalidTag, json.JSONDecodeError) as error:
                raise ResearchError("research record integrity check failed") from error
            if _hash(result) != row[1]:
                raise ResearchError("research record integrity check failed")
            db.execute("INSERT INTO research_access(record_id,action,occurred_at) VALUES(?,?,?)", (record_id, "read", _now()))
        return {**result, "content_sha256": row[1]}

    def list(self, kind: str | None = None) -> list[dict[str, Any]]:
        if kind is not None and kind not in _KINDS:
            raise ResearchError("unknown research record kind")
        with self._connect() as db:
            rows = db.execute("SELECT id FROM research_records WHERE (? IS NULL OR kind=?) ORDER BY created_at DESC LIMIT 100", (kind, kind)).fetchall()
        return [{k: value for k, value in self.get(row[0]).items()
                 if k in {"id", "kind", "title", "created_at", "content_sha256", "status", "state", "run_id", "source_class", "study_id", "claim"}}
                for row in rows]


def prediction_rows(run: dict[str, Any]) -> tuple[str, str, list[dict[str, Any]]]:
    _object(run, "frozen protocol")
    if not re.fullmatch(r"protocol-[a-f0-9]{32}", str(run.get("run_id", ""))):
        raise ResearchError("frozen protocol identity is invalid")
    if run.get("qualification_state", "NOT_QUALIFIED") != "NOT_QUALIFIED":
        raise ResearchError("this workflow accepts only unqualified model predictions")
    protocol = run.get("protocol_id")
    if protocol == "cendos.human-gem-oxygen-capacity.v1":
        raise ResearchError("network ATP capacity requires a separately reviewed cell/assay context; member-based physical validation is unavailable")
    pxr = protocol == "cendos.garcinoic-acid-pxr.v1"
    if not pxr and protocol != "cendos.metformin-cohort-comparison.v1":
        raise ResearchError("protocol has no supported measurement endpoint")
    allowed = {"STRUCTURE_AND_IN_VITRO_BACKED_MODEL", "MODELED_TARGET_ENGAGEMENT"} if pxr else {"MODELED_MECHANISTIC"}
    if not isinstance(run.get("evidence_state"), str) or run["evidence_state"] not in allowed:
        raise ResearchError("frozen protocol evidence class is not an admitted model prediction")
    groups = run.get("target_engagement" if pxr else "cohorts")
    if not isinstance(groups, list) or not 1 <= len(groups) <= 50:
        raise ResearchError("frozen protocol requires bounded member groups")
    if not pxr:
        intervention = _object(run.get("intervention"), "intervention")
        dose = _number(intervention.get("dose_mg"), "dose_mg", 0, 3000)
    rows, seen = [], set()
    expected_members = None
    for group in groups:
        _object(group, "member group")
        condition = _number(group.get("concentration_um"), "concentration_um", 0, 1000) if pxr else dose
        members = group.get("members")
        if not isinstance(members, list) or not 1 <= len(members) <= 500:
            raise ResearchError("frozen protocol requires bounded members")
        member_set = set()
        for member in members:
            _object(member, "member")
            identity = _identity(member.get("member_id"), "member_id")
            key = (identity, condition)
            if key in seen:
                raise ResearchError("duplicate member and condition prediction")
            seen.add(key); member_set.add(identity)
            prediction = _number(member.get("relative_pxr_activation" if pxr else "delta_mean"), "prediction")
            rows.append({"member_id": identity, "condition": condition, "predicted": prediction})
        if pxr and expected_members is not None and member_set != expected_members:
            raise ResearchError("concentration levels must contain the same member roster")
        expected_members = member_set
    # Check the entire record before hashing/retaining it, including nested metadata.
    _json(run)
    return ("relative_pxr_activation", "1", rows) if pxr else ("delta_mean_glucose", "mg/dL", rows)


class ResearchService:
    def __init__(self, store: ResearchStore):
        self.store = store

    def freeze(self, run: dict[str, Any], spec: dict[str, Any]) -> dict[str, Any]:
        _object(spec, "study specification")
        endpoint, unit, predictions = prediction_rows(run)
        if spec.get("endpoint") != endpoint:
            raise ResearchError("endpoint does not match the stored protocol")
        mapping = spec.get("mapping")
        members = {row["member_id"] for row in predictions}
        if not isinstance(mapping, dict) or not 1 <= len(mapping) <= 500:
            raise ResearchError("specimen to member mapping is required")
        clean_mapping = {_identity(k, "sample_id"): _identity(v, "member_id") for k, v in mapping.items()}
        if set(clean_mapping.values()) - members or len(set(clean_mapping.values())) != len(clean_mapping):
            raise ResearchError("mapping requires unique members from this run")
        controls = spec.get("controls")
        if not isinstance(controls, list) or not 1 <= len(controls) <= 20:
            raise ResearchError("prespecified controls are required")
        return self.store.put("study", {
            "title": _text(spec.get("title"), "title"), "run_id": run["run_id"],
            "run_sha256": _hash(run), "run": run, "endpoint": endpoint, "unit": unit,
            "tolerance": _number(spec.get("tolerance"), "tolerance", 0, 1e6),
            "rationale": _narrative(spec.get("rationale"), "rationale"),
            "mapping": clean_mapping, "method_id": _text(spec.get("method_id"), "method_id"),
            "material_id": _text(spec.get("material_id"), "material_id"),
            "controls": [_text(c, "control") for c in controls],
            "status": "AWAITING_MEASUREMENTS", "qualification_state": "NOT_QUALIFIED",
            "mapping_scope": "declared assay counterpart; not proof of person equivalence",
        })

    def admit_measurement(self, study_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        _object(payload, "measurement")
        study = self.store.get(study_id)
        if study["kind"] not in {"study", "resilience_protocol"}:
            raise ResearchError("measurement requires a frozen study or resilience protocol")
        source = payload.get("source_class")
        if not isinstance(source, str) or source not in {"PHYSICAL_IMPORT", "TECHNICAL_FIXTURE"}:
            raise ResearchError("source_class must declare physical import or technical fixture")
        raw = payload.get("csv")
        if not isinstance(raw, str) or not raw.strip() or len(raw.encode()) > 1_000_000:
            raise ResearchError("CSV requires 1 to 1000000 bytes")
        try:
            reader = csv.DictReader(io.StringIO(raw))
            if not reader.fieldnames or len(reader.fieldnames) != len(set(reader.fieldnames)):
                raise ResearchError("CSV has missing or duplicate headers")
            rows = list(reader)
        except csv.Error as error:
            raise ResearchError("CSV is malformed") from error
        if not rows or len(rows) > 10000 or any(None in r for r in rows):
            raise ResearchError("CSV requires 1 to 10000 well-formed rows")
        for flag in ("controls_passed", "calibration_current"):
            if not isinstance(payload.get(flag), bool):
                raise ResearchError(f"{flag} requires an explicit boolean")
        metadata = {field: _text(payload.get(field), field) for field in
                    ("instrument_id", "calibration_id", "method_id", "material_id", "operator_id", "source_reference")}
        if study["kind"] == "study":
            for field in ("method_id", "material_id"):
                if metadata[field] != study[field]:
                    raise ResearchError(f"{field} does not match the frozen study")
            self._validate_paired_rows(study, rows)
        else:
            self._validate_resilience_rows(study, rows)
        return self.store.put("measurement", {
            **metadata, "study_id": study_id, "study_sha256": study["content_sha256"],
            "source_class": source, "raw_csv": raw, "raw_sha256": hashlib.sha256(raw.encode()).hexdigest(),
            "rows": rows, "controls_passed": payload["controls_passed"],
            "calibration_current": payload["calibration_current"],
            "evidence_state": "TECHNICAL_FIXTURE" if source == "TECHNICAL_FIXTURE" else "OPERATOR_ATTESTED_IMPORT",
            "instrument_authenticity": "NOT_INDEPENDENTLY_VERIFIED",
        })

    @staticmethod
    def _validate_paired_rows(study: dict, rows: list[dict]) -> None:
        _, _, predictions = prediction_rows(study["run"])
        allowed = {(r["member_id"], r["condition"]) for r in predictions}
        seen = set()
        condition_key = "concentration_um" if study["endpoint"] == "relative_pxr_activation" else "dose_mg"
        for row in rows:
            sample = _identity(row.get("sample_id"), "sample_id")
            member = _identity(row.get("member_id"), "member_id")
            if study["mapping"].get(sample) != member:
                raise ResearchError("measurement sample/member binding does not match frozen mapping")
            condition = _number(row.get(condition_key), condition_key, 0)
            if (row.get("member_id"), condition) not in allowed:
                raise ResearchError("measurement condition does not match a frozen prediction")
            if row.get("unit") != study["unit"] or row.get("endpoint") != study["endpoint"]:
                raise ResearchError("measurement endpoint or unit mismatch")
            key = (sample, condition, _identity(row.get("replicate_id"), "replicate_id"))
            if key in seen:
                raise ResearchError("duplicate measurement replicate")
            seen.add(key)
            _number(row.get("value"), "value")
            _observed_time(row.get("measured_at"))
            if row.get("quality_status") not in {"pass", "fail", "not_assessed"}:
                raise ResearchError("quality_status must be pass, fail or not_assessed")

    def compare(self, study_id: str, measurement_id: str | None) -> dict[str, Any]:
        study = self.store.get(study_id, "study")
        if not measurement_id:
            return {"status": "AWAITING_MEASUREMENTS", "study_id": study_id,
                    "message": "Import a matching instrument file to assess the frozen endpoint.",
                    "calibration_authorized": False}
        measurement = self.store.get(measurement_id, "measurement")
        if measurement["study_id"] != study_id or measurement["study_sha256"] != study["content_sha256"]:
            raise ResearchError("measurement is bound to a different frozen study")
        self._validate_paired_rows(study, measurement["rows"])
        _, _, predictions = prediction_rows(study["run"])
        selected = {r["member_id"] for r in predictions} & set(study["mapping"].values())
        expected = {(r["member_id"], r["condition"]): r["predicted"] for r in predictions if r["member_id"] in selected}
        condition_key = "concentration_um" if study["endpoint"] == "relative_pxr_activation" else "dose_mg"
        grouped: dict[tuple[str, float], list[float]] = {}
        reasons: list[str] = []
        if not measurement["controls_passed"] or not measurement["calibration_current"]:
            reasons.append("instrument_or_control_qc_not_passed")
        for row in measurement["rows"]:
            if row["quality_status"] != "pass":
                reasons.append("measurement_quality_not_passed")
                continue
            if _time(row["measured_at"]) <= _time(study["created_at"]):
                reasons.append("retrospective_measurement_requires_separate_review")
            grouped.setdefault((row["member_id"], float(row[condition_key])), []).append(float(row["value"]))
        pairs = []
        for key, values in grouped.items():
            mean = fmean(values)
            residual = mean - expected[key]
            pairs.append({"member_id": key[0], "condition": key[1], "predicted": expected[key],
                          "measured_mean": mean, "replicates": len(values),
                          "measured_sd": stdev(values) if len(values) > 1 else None,
                          "residual": residual, "within_tolerance": abs(residual) <= study["tolerance"]})
        if len(grouped) != len(expected):
            reasons.append("incomplete_endpoint_coverage")
        status = "NOT_ASSESSABLE" if reasons else ("CRITERION_MET" if all(p["within_tolerance"] for p in pairs) else "CRITERION_NOT_MET")
        if measurement["source_class"] == "TECHNICAL_FIXTURE":
            status = "TECHNICAL_CHECK_ONLY"
        return self.store.put("comparison", {
            "title": study["title"], "study_id": study_id, "measurement_id": measurement_id,
            "run_id": study["run_id"], "run_sha256": study["run_sha256"],
            "raw_sha256": measurement["raw_sha256"], "status": status, "reasons": sorted(set(reasons)),
            "endpoint": study["endpoint"], "unit": study["unit"], "tolerance": study["tolerance"],
            "pairs": pairs, "coverage": {"expected": len(expected), "matched": len(grouped)},
            "rmse": math.sqrt(fmean(p["residual"] ** 2 for p in pairs)) if pairs else None,
            "evidence_state": measurement["evidence_state"], "qualification_state": "REVIEW_REQUIRED",
            "calibration_authorized": False, "next_gate": "independent instrument, specimen and evidence-service review",
        })

    def register_resilience(self, spec: dict[str, Any]) -> dict[str, Any]:
        _object(spec, "resilience specification")
        operations = spec.get("operations")
        if (not isinstance(operations, list) or len(operations) != 5
                or any(not isinstance(o, dict) or not isinstance(o.get("id"), str) for o in operations)
                or {o["id"] for o in operations} != set(OPERATIONS)):
            raise ResearchError("all five cure operations must be prespecified")
        cleaned = []
        for operation in operations:
            applicable = operation.get("applicable")
            if not isinstance(applicable, bool):
                raise ResearchError("operation applicability requires an explicit boolean")
            row = {"id": operation["id"], "applicable": applicable,
                   "rationale": _narrative(operation.get("rationale"), "rationale")}
            if applicable:
                row.update(endpoint=_text(operation.get("endpoint"), "endpoint"), unit=_text(operation.get("unit"), "unit"),
                           lower=_number(operation.get("lower"), "lower"), upper=_number(operation.get("upper"), "upper"))
                if row["lower"] > row["upper"]:
                    raise ResearchError("healthy range is inverted")
            cleaned.append(row)
        if not any(o["id"] == "resilience" and o["applicable"] for o in cleaned):
            raise ResearchError("treatment-free resilience cannot be waived")
        stresses = spec.get("stresses")
        if not isinstance(stresses, list) or not 1 <= len(stresses) <= 20:
            raise ResearchError("unique prespecified stress challenges are required")
        stresses = [_identity(stress, "stress_id") for stress in stresses]
        if len(set(stresses)) != len(stresses):
            raise ResearchError("unique prespecified stress challenges are required")
        subjects = spec.get("subjects")
        if not isinstance(subjects, list) or not 2 <= len(subjects) <= 10000:
            raise ResearchError("a prespecified independent subject roster is required")
        applicable_operations = {o["id"] for o in cleaned if o["applicable"]}
        roster, subject_ids = [], set()
        for subject in subjects:
            _object(subject, "subject")
            subject_id = _identity(subject.get("subject_id"), "subject_id")
            if subject_id in subject_ids:
                raise ResearchError("independent subject IDs must be unique")
            subject_ids.add(subject_id)
            ranges = _object(subject.get("healthy_ranges"), "individual healthy ranges")
            if set(ranges) != applicable_operations:
                raise ResearchError("individual healthy ranges must cover every applicable operation")
            individual_ranges = {}
            for operation, values in ranges.items():
                _object(values, "individual healthy range")
                lower = _number(values.get("lower"), "lower")
                upper = _number(values.get("upper"), "upper")
                if lower > upper:
                    raise ResearchError("individual healthy range is inverted")
                individual_ranges[operation] = {"lower": lower, "upper": upper}
            roster.append({"subject_id": subject_id,
                           "profile_reference": _text(subject.get("profile_reference"), "profile_reference"),
                           "healthy_ranges": individual_ranges})
        min_subjects = _number(spec.get("min_subjects"), "min_subjects", 2, 10000)
        if not min_subjects.is_integer() or min_subjects > len(roster):
            raise ResearchError("min_subjects must be an integer within the registered roster")
        return self.store.put("resilience_protocol", {
            "title": _text(spec.get("title"), "title"), "population": _text(spec.get("population"), "population"),
            "operations": cleaned, "stresses": stresses, "subjects": roster,
            "followup_days": _number(spec.get("followup_days"), "followup_days", 1, 36500),
            "washout_days": _number(spec.get("washout_days"), "washout_days", .001, 36500),
            "p_star": _number(spec.get("p_star"), "p_star", .001, .999), "min_subjects": int(min_subjects),
            "status": "AWAITING_MEASUREMENTS", "independent_unit": "subject, all declared operations and stresses jointly",
            "followup_anchor": "duration after completion of washout from the last treatment",
            "healthy_range_policy": "prespecified individual ranges; operation ranges are protocol context only",
            "identity_verification": "operator-declared roster and profile references, not independently verified persons",
            "statistical_method": "one-sided 95% Wilson lower bound; assumes independent subjects",
        })

    @staticmethod
    def _validate_resilience_rows(protocol: dict, rows: list[dict]) -> None:
        operations = {o["id"]: o for o in protocol["operations"] if o["applicable"]}
        subjects = {subject["subject_id"] for subject in protocol["subjects"]}
        seen = set()
        for row in rows:
            subject = _identity(row.get("subject_id"), "subject_id")
            if subject not in subjects:
                raise ResearchError("subject is absent from the prespecified roster")
            op = operations.get(row.get("operation"))
            if op is None or row.get("endpoint") != op["endpoint"] or row.get("unit") != op["unit"]:
                raise ResearchError("operation endpoint or unit mismatch")
            if row.get("stress_id") not in protocol["stresses"]:
                raise ResearchError("stress does not match the registered protocol")
            time = _observed_time(row.get("measured_at"))
            last = _observed_time(row.get("last_treatment_at"))
            stress = _observed_time(row.get("stress_started_at"))
            if stress > time or stress < last + timedelta(days=protocol["washout_days"]):
                raise ResearchError("stress must begin after washout and before its measurement")
            _number(row.get("value"), "value")
            key = (subject, op["id"], row["stress_id"], time)
            if key in seen:
                raise ResearchError("duplicate resilience observation")
            seen.add(key)
            if row.get("washout_confirmed") not in {"true", "false"} or row.get("quality_status") not in {"pass", "fail", "not_assessed"}:
                raise ResearchError("washout and quality declarations are required")

    def assess_resilience(self, protocol_id: str, measurement_ids: list[str]) -> dict[str, Any]:
        protocol = self.store.get(protocol_id, "resilience_protocol")
        if (not isinstance(measurement_ids, list) or len(measurement_ids) > 100
                or any(not isinstance(mid, str) or not _ID.fullmatch(mid) for mid in measurement_ids)
                or len(set(measurement_ids)) != len(measurement_ids)):
            raise ResearchError("measurement IDs must be unique and bounded")
        operations = {o["id"]: o for o in protocol["operations"] if o["applicable"]}
        required = {(op, stress) for op in operations for stress in protocol["stresses"]}
        roster = {subject["subject_id"]: subject for subject in protocol["subjects"]}
        by_subject: dict[str, dict[tuple[str, str], list[bool]]] = {subject: {} for subject in roster}
        reasons = []
        technical = False
        for mid in measurement_ids:
            measurement = self.store.get(mid, "measurement")
            if measurement["study_id"] != protocol_id or measurement["study_sha256"] != protocol["content_sha256"]:
                raise ResearchError("measurement protocol binding mismatch")
            self._validate_resilience_rows(protocol, measurement["rows"])
            technical |= measurement["source_class"] == "TECHNICAL_FIXTURE"
            if not measurement["controls_passed"] or not measurement["calibration_current"]:
                reasons.append("instrument_or_control_qc_not_passed")
            for row in measurement["rows"]:
                stamp, last = _time(row["measured_at"]), _time(row["last_treatment_at"])
                if stamp <= _time(protocol["created_at"]):
                    reasons.append("retrospective_measurement_requires_review")
                if _time(row["stress_started_at"]) <= _time(protocol["created_at"]):
                    reasons.append("retrospective_stress_requires_review")
                elapsed = (stamp - last).total_seconds() / 86400
                eligible = elapsed >= protocol["followup_days"] + protocol["washout_days"]
                eligible &= row["washout_confirmed"] == "true" and row["quality_status"] == "pass"
                if not eligible:
                    reasons.append("followup_washout_or_quality_missing")
                individual_range = roster[row["subject_id"]]["healthy_ranges"][row["operation"]]
                passed = eligible and individual_range["lower"] <= float(row["value"]) <= individual_range["upper"]
                by_subject.setdefault(row["subject_id"], {}).setdefault((row["operation"], row["stress_id"]), []).append(passed)
        subjects = []
        for subject, cells in by_subject.items():
            complete = required <= set(cells)
            if not complete:
                reasons.append("missing_operation_or_stress")
            subjects.append({"subject_id": subject, "complete": complete,
                             "passed": complete and all(all(v) for v in cells.values())})
        n, successes = sum(bool(cells) for cells in by_subject.values()), sum(s["passed"] for s in subjects)
        lower = 0.0
        if n:
            z, phat = 1.6448536269514722, successes / n
            lower = (phat + z*z/(2*n) - z * math.sqrt(phat*(1-phat)/n + z*z/(4*n*n))) / (1 + z*z/n)
        if n < protocol["min_subjects"]:
            reasons.append("insufficient_independent_subjects")
        status = "NOT_ASSESSABLE" if reasons else ("HYPOTHESIS_CRITERIA_MET" if lower >= protocol["p_star"] else "HYPOTHESIS_CRITERIA_NOT_MET")
        if technical:
            status = "TECHNICAL_CHECK_ONLY"
        return self.store.put("resilience_assessment", {
            "title": protocol["title"], "protocol_id": protocol_id, "measurement_ids": measurement_ids,
            "status": status, "reasons": sorted(set(reasons)), "independent_subjects": n,
            "registered_subjects": len(roster),
            "joint_successes": successes, "probability_lower_bound": lower, "p_star": protocol["p_star"],
            "subjects": subjects, "cure_claim_authorized": False, "qualification_state": "REVIEW_REQUIRED",
            "limitation": "Finite follow-up and measured endpoints cannot establish permanent cure or unmeasured reservoir eradication.",
        })

    def record_learning(self, payload: dict[str, Any]) -> dict[str, Any]:
        _object(payload, "learning record")
        level = payload.get("level")
        if level not in LEVELS:
            raise ResearchError("learning level must match the multiscale curriculum")
        sources = payload.get("sources")
        if not isinstance(sources, list) or not 1 <= len(sources) <= 20:
            raise ResearchError("learning needs primary source references")
        for source in sources:
            try:
                parsed = urlparse(_text(source, "source URL", 1000))
                parsed.port
            except ValueError as error:
                raise ResearchError("primary source reference is not a valid URL") from error
            if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
                raise ResearchError("primary source references require HTTPS URLs")
        fields = {f: _text(payload.get(f), f, 2000) for f in ("module", "author")}
        fields.update({f: _narrative(payload.get(f), f)
                       for f in ("claim", "counterevidence", "test_plan", "applicability")})
        return self.store.put("learning", {**fields, "level": level, "sources": sources,
            "state": "PROPOSED", "model_change_authorized": False,
            "release_requirements": ["reviewed source extraction", "independent benchmark", "regression tests",
                                     "applicability review", "versioned model release"],
        })


def biology_curriculum() -> dict[str, Any]:
    topics = {
        "atomic": "Charge, bond energies, electrostatics; model resolution and quantum/classical limits",
        "chemical": "Mass balance, thermodynamics, kinetics, protonation, stereochemistry, mixtures",
        "molecular": "Binding, enzymes, transport, signaling, compartment concentrations",
        "genetic": "Variants, transcription, translation, epigenetic regulation and uncertainty",
        "cellular": "Cell identity, metabolism, electrophysiology, division, death, immune memory",
        "tissue": "Cell populations, extracellular matrix, mechanics, diffusion and vascular supply",
        "organ": "Organ-specific function, reserve, injury, repair, feedback and failure",
        "whole_body": "Homeostasis, development, aging, circadian rhythms, environment and cross-system regulation",
    }
    return {"schema": "livemore.scientific-learning.v1", "levels": [
        {"level": level, "required_understanding": topics[level], "completion": "EVIDENCE_REQUIRED"} for level in LEVELS],
        "change_contract": ["state variables and units", "primary source and counterevidence", "boundary conditions",
            "person applicability", "conservation/identifiability", "independent validation data", "versioned tests and reviewer"],
        "reinforcement_learning": "No online RL configured. Candidate training requires a task, reward specification, offline evaluation and controlled release.",
        "automatic_model_updates": False,
    }
