"""Render local reproducibility reports from platform results.

The legacy HMAC record proves local integrity and repeatability for an operator
holding the same key. It is not a governed evidence-package signature, partner
attestation, or regulator-ready electronic signature.
"""
from __future__ import annotations
import json
import os


def screen_report_md(result: dict) -> str:
    """Markdown report for a cohort compound screen (sdk.Platform.screen output)."""
    s, a, rows = result["summary"], result["audit"], result["ranked"]
    L = ["# LivemoreBio — Cohort Screen Local Reproducibility Report", "",
         f"**Compound:** {s['compound']} · dose {s['dose']}× · OGTT {s['grams']} g",
         f"**Cohort:** {s['cohort_n']} virtual twins (seed {s['seed']}, reproducible)",
         f"**Responders (EFFECT):** {s['n_effect']} / {s['cohort_n']} "
         f"({s['responder_rate'] * 100:.1f}%)",
         f"**Mean Δ mean glucose:** {s['mean_delta_mean']} mg/dL", "",
         "## Ranking — strongest predicted glucose-lowering first", "",
         "| rank | id | age | sex | conditions | Δmean (mg/dL) | ΔiAUC | decision |",
         "|---:|---|---:|---|---|---:|---:|---|"]
    for i, r in enumerate(rows, 1):
        conds = ", ".join(r["conditions"]) or "—"
        L.append(f"| {i} | {r['id']} | {r['age']} | {r['sex']} | {conds} | "
                 f"{r['delta_mean']} | {r['delta_iAUC']} | {r['decision']} |")
    L += ["", "## Provenance & local integrity record", "",
          f"- **Result fingerprint (SHA-256):** `{a['result_sha256']}`",
          f"- **Local HMAC ({a['alg']}):** `{a['hmac_sha256']}`",
          f"- **Record id:** `{a['id']}` · **timestamp:** {a['ts']}",
          f"- **Engine provenance:** `{json.dumps(a['provenance'])}`", "",
          "## Interpretation & limits", "",
          "- **Evidence status:** local reproducibility artifact only. This HMAC is not a "
          "governed Livemore evidence-package signature and must not be represented as "
          "regulator-ready evidence.",
          "- **Model-only in-silico hypothesis triage** — not a wet-lab measurement or a "
          "clinical outcome. Effects emerge from each twin's individual biology "
          "(genome, conditions, lifestyle) through the mechanistic glucose-insulin model.",
          "- **Reproducible:** an identical re-run (same compound, dose, cohort size, seed) "
          "reproduces the result fingerprint exactly. **Verify** with `livemore audit verify "
          "<record.json>`, which recomputes the fingerprint and checks the signature."]
    return "\n".join(L)


def write_report(result: dict, path: str, kind: str = "screen") -> dict:
    """Write the markdown report and local integrity record (JSON) beside it.
    Returns the paths written."""
    md = screen_report_md(result) if kind == "screen" else json.dumps(result, indent=2, default=str)
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(md)
    rec_path = os.path.splitext(path)[0] + ".audit.json"
    with open(rec_path, "w", encoding="utf-8") as f:
        json.dump(result["audit"], f, indent=2, default=str)
    return {"report": os.path.abspath(path), "audit_record": os.path.abspath(rec_path)}
