"""livemorebio.sdk — the single platform surface for the CLI and scripted pipelines.

Platform(mode="inprocess" | "attach"). Legacy numerical methods support both modes;
governed registries and continuous execution require an attached service:

  - inprocess (default): runs the real engines directly in this process — deterministic,
    isolated, reproducible. The right substrate for auditable pharma pipelines. External
    database lookups (ChEMBL / PubChem / Open Targets) are pinned via the persistent
    resolve cache and captured in the audit trail, so a re-run reproduces exactly.
  - attach: drives the live running Aegle / Cendos services over HTTP — the same twin the
    web console shows — for interactive work where terminal and browser share one session.

Legacy numerical operations have their own audit behavior. Continuous and governed
operations retain server-side authorization, encrypted access audits and evidence
decisions; this client does not infer scientific qualification from successful HTTP.
"""
from __future__ import annotations
from copy import deepcopy
import json
import math
import re
import io
import urllib.error
import urllib.parse
import urllib.request
from typing import List, Optional

from . import audit
from .clinical_note_gate import clinical_note_gate
from .execution_client import ContinuousExecutionClient, ContinuousClientError, identifier, integer
from .atlas_client import AtlasReferenceClient


def _clinical_cursor(value: str | None) -> str | None:
    if value is not None and (type(value) is not str or re.fullmatch(r"[A-Za-z0-9_-]{1,1024}", value) is None):
        raise ContinuousClientError()
    return value


def _clinical_eligibility(value: object) -> bool:
    if type(value) is not dict or set(value) != {"state", "reason_code"}:
        return False
    if value["state"] == "READY":
        return value["reason_code"] is None
    return value["state"] == "UNAVAILABLE" and value["reason_code"] in (
        "MODEL_BINDING_REQUIRED", "MODEL_CONTEXT_UNSUPPORTED", "MODEL_CONTEXT_SOURCE_MISMATCH",
        "MODEL_CONTEXT_INVALID", "COHORT_MEMBER_SNAPSHOT_REQUIRED",
    )


def _state_availability_valid(value: object) -> bool:
    fields = {"schema", "state", "reason_code", "selection_mode", "twin_id", "twin_version", "source_generation", "preparation_available"}
    if (type(value) is not dict or set(value) != fields
            or value["schema"] != "livemore.model-availability.v1"
            or type(value["twin_version"]) is not int
            or type(value["source_generation"]) is not str
            or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}", value["source_generation"]) is None):
        return False
    if value["selection_mode"] == "reference_preview":
        return (value["state"] == "READY" and value["reason_code"] is None
                and value["twin_id"] is None and value["twin_version"] == 0
                and value["preparation_available"] is True)
    if (type(value["twin_id"]) is not str
            or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}", value["twin_id"]) is None
            or not 1 <= value["twin_version"] <= 2**53 - 1):
        return False
    if value["state"] == "READY":
        return (value["selection_mode"] == "model" and value["reason_code"] is None
                and value["preparation_available"] is True)
    return (value["state"] == "UNAVAILABLE" and value["selection_mode"] == "observations_only"
            and value["preparation_available"] is False
            and value["reason_code"] != "COHORT_MEMBER_SNAPSHOT_REQUIRED"
            and _clinical_eligibility({"state": value["state"], "reason_code": value["reason_code"]}))


class Platform(ContinuousExecutionClient, AtlasReferenceClient):
    def __init__(self, mode: str = "inprocess", seed: Optional[int] = None):
        if mode not in ("inprocess", "attach"):
            raise ValueError("mode must be 'inprocess' or 'attach'")
        self.mode = mode
        self.seed = seed
        self._twin = None                 # active AegleTwin (in-process)
        self._cohort: List = []           # generated SyntheticHuman cohort (in-process)
        self._cohort_context = None       # indication/cohort eligibility used to generate it
        self._cohort_seed = None          # exact generation seed for deterministic reuse
        self._cohort_n = None             # requested cohort size for deterministic reuse
        self._gem_memo = {}               # (resolution pin, genome, operating point, dose) -> ratios
        self._workspace_actions = []       # visible lifecycle in isolated mode
        self._virtual_patch_sequence = 0   # parity with one persistent virtual device
        if mode == "inprocess":
            self.patient(base="healthy")

    # ---- attach-mode HTTP helpers -------------------------------------------------
    def _url(self, service="Aegle"):
        from . import registry
        import os
        override = os.getenv(f"LIVEMORE_{service.upper()}_URL", "").strip()
        if override:
            return override.rstrip("/")
        return registry.url_of(service) or ("http://127.0.0.1:8850" if service == "Aegle"
                                             else "http://127.0.0.1:8852")

    def _get(self, path):
        from .security import authorization_headers
        from . import stack_client
        url = self._url() + path
        identity = stack_client.operation_identity("aegle", url)
        with stack_client.request_response(url, identity=identity,
                headers=authorization_headers(), timeout=20, max_response_bytes=None) as r:
            if not 200 <= r.status < 300:
                raise urllib.error.HTTPError(url, r.status, r.msg, r.headers, io.BytesIO(r.read()))
            return json.loads(r.read())

    def _post(self, path, body, *, headers: dict[str, str] | None = None, timeout: float = 30):
        from .security import authorization_headers
        from . import stack_client
        url = self._url() + path
        identity = stack_client.operation_identity("aegle", url)
        request_headers = {"Content-Type": "application/json", **authorization_headers()}
        request_headers.update(headers or {})
        with stack_client.request_response(url, identity=identity, body=json.dumps(body).encode(),
                method="POST", headers=request_headers, timeout=timeout, max_response_bytes=None) as r:
            if not 200 <= r.status < 300:
                raise urllib.error.HTTPError(url, r.status, r.msg, r.headers, io.BytesIO(r.read()))
            return json.loads(r.read())

    def _require_attached_subject_registry(self) -> None:
        if self.mode != "attach":
            raise RuntimeError(
                "governed twin/cohort lifecycle commands require Platform(mode='attach')"
            )

    # ---- governed subject / cohort lifecycle ------------------------------------
    def list_twins(self, *, limit: int = 25, cursor: str | None = None, q: str = "") -> dict:
        """List encrypted governed twin records and the active subject projection."""
        self._require_attached_subject_registry()
        return self._get(self._page_path("/api/twins", limit, cursor, q))

    @staticmethod
    def _page_path(path: str, limit: int, cursor: str | None, q: str) -> str:
        params = {"limit": limit}
        if cursor is not None:
            params["cursor"] = cursor
        if q:
            params["q"] = q
        return path + "?" + urllib.parse.urlencode(params)

    def admit_twin(self, payload: dict, *, idempotency_key: str) -> dict:
        """Admit one synthetic or consented real-human bundle through the web API contract."""
        self._require_attached_subject_registry()
        if not isinstance(payload, dict):
            raise TypeError("twin payload must be a JSON object")
        return self._post(
            "/api/twins", payload, headers={"Idempotency-Key": idempotency_key},
        )

    def activate_twin(self, twin_id: str, *, expected_version: int) -> dict:
        """Make one admitted twin authoritative across Aegle, LIFE Patch, and Cendos."""
        self._require_attached_subject_registry()
        return self._post(
            f"/api/twins/{urllib.parse.quote(twin_id, safe='')}/activate",
            {"expected_version": expected_version},
        )

    def _clinical_response_error(self, *, mutation: bool = False, use_current_metadata: bool = False) -> ContinuousClientError:
        # Legacy state/summary reads do not capture headers; a prior operation is not their correlation.
        request_id = getattr(self, "last_continuous_response", {}).get("request_id") if use_current_metadata else None
        return ContinuousClientError("CLIENT_UNCONFIRMED" if mutation else "CLIENT_RESPONSE",
            status=200, request_id=request_id)

    def select_twin_observations(self, twin_id: str, *, expected_version: int) -> dict:
        """Select admitted observations once; never activate or infer a numerical model."""
        self._continuous_require_attach()
        twin_id = identifier(twin_id)
        expected_version = integer(expected_version, 1, 2**53 - 1)
        result = self._continuous_request("POST", f"/api/twins/{urllib.parse.quote(twin_id, safe='')}/select-observations",
                                          {"expected_version": expected_version})
        committed_version = expected_version + 1
        availability = result.get("model_availability")
        fields = {"schema", "state", "reason_code", "selection_mode", "twin_id", "twin_version", "source_generation", "preparation_available"}
        if (result.get("twin_id") != twin_id or type(result.get("version")) is not int or result["version"] != committed_version
                or result.get("source_class") != "REAL_HUMAN" or type(availability) is not dict or set(availability) != fields
                or availability["schema"] != "livemore.model-availability.v1" or availability["state"] != "UNAVAILABLE"
                or availability["selection_mode"] != "observations_only" or availability["twin_id"] != twin_id
                or type(availability["twin_version"]) is not int or availability["twin_version"] != committed_version
                or type(availability["source_generation"]) is not str or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}", availability["source_generation"]) is None
                or availability["preparation_available"] is not False
                or availability["reason_code"] == "COHORT_MEMBER_SNAPSHOT_REQUIRED"
                or not _clinical_eligibility({"state": availability["state"], "reason_code": availability["reason_code"]})):
            raise self._clinical_response_error(mutation=True, use_current_metadata=True)
        return result

    def reconcile_twin_selection(self) -> dict:
        """Read audited selection authority once; do not repeat selection or clean workers."""
        self._continuous_require_attach()
        result = self._continuous_request("POST", "/api/twins/reconcile-selection", {}, timeout=60, expected_status=200)
        request_id = self.last_continuous_response.get("request_id")
        # This route confirms only its current server-owned canonical UUID, not legacy IDs.
        if type(request_id) is not str or re.fullmatch(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", request_id) is None:
            raise ContinuousClientError("CLIENT_UNCONFIRMED", status=200)
        subject, availability = result.get("subject"), result.get("model_availability")
        valid = (set(result) == {"selection_status", "subject", "model_availability", "prior_execution_cleanup"}
                 and result["selection_status"] == "CONFIRMED"
                 and result["prior_execution_cleanup"] == "INSPECT_EXISTING_STATUS"
                 and _state_availability_valid(availability))
        if valid and subject is None:
            valid = availability["selection_mode"] == "reference_preview"
        elif valid:
            valid = (type(subject) is dict
                     and set(subject) == {"twin_id", "subject_id", "display_label", "source_class", "lifecycle", "version"}
                     and subject["source_class"] in ("REAL_HUMAN", "SYNTHETIC", "REFERENCE_GROUNDED_SYNTHETIC")
                     and subject["lifecycle"] == "ACTIVE" and type(subject["version"]) is int
                     and 1 <= subject["version"] <= 2**53 - 1
                     and type(subject["twin_id"]) is str
                     and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}", subject["twin_id"]) is not None
                     and all(type(subject[key]) is str and 0 < len(subject[key]) <= limit
                             for key, limit in (("subject_id", 96), ("display_label", 80)))
                     and subject["twin_id"] == availability["twin_id"]
                     and subject["version"] == availability["twin_version"])
        if not valid:
            raise self._clinical_response_error(mutation=True, use_current_metadata=True)
        return result

    def bind_patch(self, twin_id: str, payload: dict, *, expected_version: int) -> dict:
        """Record a governed physical, virtual, or replay Patch binding."""
        self._require_attached_subject_registry()
        if not isinstance(payload, dict):
            raise TypeError("Patch binding payload must be a JSON object")
        return self._post(
            f"/api/twins/{urllib.parse.quote(twin_id, safe='')}/patches",
            {**payload, "expected_version": expected_version},
        )

    def list_cohorts(self, *, limit: int = 25, cursor: str | None = None, q: str = "") -> dict:
        """List immutable governed cohort definitions."""
        self._require_attached_subject_registry()
        return self._get(self._page_path("/api/cohorts", limit, cursor, q))

    def get_cohort(self, cohort_id: str) -> dict:
        self._require_attached_subject_registry()
        return self._get(f"/api/cohorts/{urllib.parse.quote(cohort_id, safe='')}")

    def list_cohort_members(self, cohort_id: str, *, limit: int = 10, cursor: str | None = None) -> dict:
        """Return one audited frozen REAL_HUMAN summary page, without detail reads."""
        self._continuous_require_attach()
        cohort_id = identifier(cohort_id)
        limit = integer(limit, 1, 50)
        cursor = _clinical_cursor(cursor)
        query = {"limit": limit}
        if cursor is not None:
            query["cursor"] = cursor
        result = self._continuous_request("GET", f"/api/cohorts/{urllib.parse.quote(cohort_id, safe='')}/members?{urllib.parse.urlencode(query)}")
        rows, page = result.get("members"), result.get("pagination")
        try:
            if (type(rows) is not list or len(rows) > limit or type(page) is not dict
                    or type(page.get("limit")) is not int or page["limit"] != limit
                    or type(page.get("total")) is not int or not len(rows) <= page["total"] <= 1000
                    or type(page.get("has_more")) is not bool
                    or (page["has_more"] and _clinical_cursor(page.get("next_cursor")) is None)
                    or (not page["has_more"] and page.get("next_cursor") is not None)):
                raise ValueError()
            for row in rows:
                if (type(row) is not dict or row.get("source_class") != "REAL_HUMAN"
                        or type(row.get("display_label")) is not str or len(row["display_label"]) > 200
                        or not _clinical_eligibility(row.get("execution_eligibility"))):
                    raise ValueError()
                identifier(row.get("twin_id"))
                integer(row.get("record_version"), 1, 2**53 - 1)
            if len({row["twin_id"] for row in rows}) != len(rows):
                raise ValueError()
        except (ValueError, TypeError):
            raise self._clinical_response_error(use_current_metadata=True) from None
        return result

    def get_cohort_member(self, cohort_id: str, member_id: str) -> dict:
        """Explicitly read a frozen clinical snapshot; never resolve a current twin."""
        self._continuous_require_attach()
        cohort_id, member_id = identifier(cohort_id), identifier(member_id)
        result = self._continuous_request("GET", f"/api/cohorts/{urllib.parse.quote(cohort_id, safe='')}/members/{urllib.parse.quote(member_id, safe='')}")
        snapshot = result.get("snapshot")
        version = result.get("record_version")
        if (result.get("schema") != "livemore.frozen-real-human-member.v1" or result.get("source_class") != "REAL_HUMAN"
                or result.get("twin_id") != member_id or type(version) is not int or not 1 <= version <= 2**53 - 1
                or any(type(result.get(key)) is not str or re.fullmatch(r"[a-f0-9]{64}", result[key]) is None for key in ("snapshot_sha256", "evidence_sha256"))
                or type(snapshot) is not dict or snapshot.get("twin_id") != member_id
                or type(snapshot.get("version")) is not int or snapshot["version"] != version or snapshot.get("source_class") != "REAL_HUMAN"):
            raise self._clinical_response_error(use_current_metadata=True)
        return result

    def register_cohort(self, payload: dict, *, idempotency_key: str) -> dict:
        """Create a frozen synthetic or admitted real-human cohort definition."""
        self._require_attached_subject_registry()
        if not isinstance(payload, dict):
            raise TypeError("cohort payload must be a JSON object")
        return self._post(
            "/api/cohorts", payload, headers={"Idempotency-Key": idempotency_key},
        )

    def run_metformin_cohorts(
        self,
        cohort_a_id: str,
        cohort_b_id: str,
        *,
        dose_mg: float = 1000.0,
        grams: float = 75.0,
    ) -> dict:
        """Run and freeze the governed individualized metformin comparison."""
        self._require_attached_subject_registry()
        return self._post("/api/cendos/protocols/metformin-cohorts", {
            "cohort_a_id": cohort_a_id,
            "cohort_b_id": cohort_b_id,
            "dose_mg": dose_mg,
            "grams": grams,
        })

    def run_garcinoic_pxr(
        self,
        cohort_id: str,
        *,
        concentrations_um: list[float],
    ) -> dict:
        """Run and freeze the purified-garcinoic-acid/PXR protocol."""
        self._require_attached_subject_registry()
        return self._post("/api/cendos/protocols/garcinoic-pxr", {
            "cohort_id": cohort_id,
            "concentrations_um": concentrations_um,
        })

    def latest_protocol(self) -> dict:
        """Read the latest frozen Cendos cohort-protocol result."""
        self._require_attached_subject_registry()
        return self._get("/api/cendos/protocols/latest")

    def genome_models(self) -> dict:
        """Inspect reference-asset and execution readiness on the attached server."""
        self._require_attached_subject_registry()
        return self._get("/api/genome-models")

    def run_metabolic_protocol(self, specification: dict) -> dict:
        """Run the bounded Human-GEM steady-state protocol, never a live-twin mutation."""
        self._require_attached_subject_registry()
        if not isinstance(specification, dict):
            raise TypeError("metabolic specification must be a JSON object")
        return self._post("/api/cendos/protocols/human-gem-oxygen-capacity", specification, timeout=150)

    def protocol_history(self, *, limit: int = 20, cursor: str | None = None, q: str = "") -> dict:
        self._require_attached_subject_registry()
        return self._get(self._page_path("/api/cendos/protocols/history", limit, cursor, q))

    def run_lobeline_vmat2(self, specification: dict) -> dict:
        """Freeze nonhuman initial-rate sensitivity, without consulting a twin or cohort."""
        self._require_attached_subject_registry()
        if not isinstance(specification, dict):
            raise TypeError("lobeline assay specification must be a JSON object")
        return self._post("/api/cendos/protocols/lobeline-vmat2", specification)

    def program_catalog(self) -> dict:
        """Executability of the insulin program and the five botanical programs."""
        if self.mode == "inprocess":
            from .cendos.botanical_programs import program_catalog
            from .engines.metabolic.hovorka import product_catalog
            return {"insulin": product_catalog(), "botanical": program_catalog()}
        return self._get("/api/cendos/programs")

    def run_insulin_protocol(self, specification: dict | None = None) -> dict:
        """Paired exogenous-insulin model runs. In-process runs are not persisted."""
        specification = dict(specification or {})
        if self.mode == "inprocess":
            from .cendos.insulin_protocol import validate_spec, run_exogenous_insulin_protocol
            return run_exogenous_insulin_protocol(validate_spec(specification))
        self._require_attached_subject_registry()
        return self._post("/api/cendos/protocols/exogenous-insulin", specification, timeout=150)

    def run_botanical_program(self, specification: dict) -> dict:
        """Exposure versus measured active concentration for one declared material."""
        if not isinstance(specification, dict):
            raise TypeError("botanical program specification must be a JSON object")
        if self.mode == "inprocess":
            from .cendos.botanical_programs import validate_spec, run_botanical_exposure_program
            return run_botanical_exposure_program(validate_spec(specification))
        self._require_attached_subject_registry()
        return self._post("/api/cendos/protocols/botanical-exposure", specification, timeout=150)

    def get_protocol(self, run_id: str) -> dict:
        self._require_attached_subject_registry()
        return self._get(f"/api/cendos/protocols/{urllib.parse.quote(run_id, safe='')}")

    def protocol_notebook(self, run_id: str) -> dict:
        self._require_attached_subject_registry()
        return self._get(f"/api/cendos/protocols/{urllib.parse.quote(run_id, safe='')}/analysis.ipynb")

    def prepare_protocol_rerun(self, run_id: str) -> dict:
        """Read-only preparation; execution requires a separate explicit call."""
        self._require_attached_subject_registry()
        return self._get(f"/api/cendos/protocols/{urllib.parse.quote(run_id, safe='')}/prepare-rerun")

    def execute_prepared_rerun(self, prepared: dict, *, new_configuration: bool = False) -> dict:
        self._require_attached_subject_registry()
        if type(new_configuration) is not bool:
            raise ValueError("new_configuration must be boolean")
        if not isinstance(prepared, dict):
            raise ValueError("prepared rerun must be a JSON object")
        paths = {
            "cendos.metformin-cohort-comparison.v1": "metformin-cohorts",
            "cendos.garcinoic-acid-pxr.v1": "garcinoic-pxr",
            "cendos.human-gem-oxygen-capacity.v1": "human-gem-oxygen-capacity",
            "cendos.lobeline-vmat2-initial-rate.v1": "lobeline-vmat2",
            "cendos.exogenous-insulin-paired.v1": "exogenous-insulin",
            "cendos.botanical-exposure-margin.v1": "botanical-exposure",
        }
        name = paths.get(prepared.get("protocol_id"))
        if name is None or not isinstance(prepared.get("request"), dict) or not prepared.get("parent_run_id"):
            raise ValueError("prepared rerun must identify a supported protocol, parent and request")
        # Never follow a supplied URL: returned artifacts are data, not authority.
        payload = {**prepared["request"], "parent_run_id": prepared["parent_run_id"],
                   "new_configuration": new_configuration}
        return self._post("/api/cendos/protocols/" + name, payload, timeout=150)

    # These methods deliberately share the authenticated server contract, rather
    # than bypassing evidence checks in the terminal or in a notebook.
    def research_overview(self) -> dict:
        self._require_attached_subject_registry()
        return self._get("/api/research/overview")

    def freeze_research_study(self, run_id: str, criteria: dict) -> dict:
        self._require_attached_subject_registry()
        return self._post("/api/research/studies", {**criteria, "run_id": run_id})

    def admit_research_measurement(self, study_id: str, payload: dict) -> dict:
        self._require_attached_subject_registry()
        return self._post(f"/api/research/studies/{urllib.parse.quote(study_id, safe='')}/measurements", payload)

    def compare_research_study(self, study_id: str, measurement_id: str | None = None) -> dict:
        self._require_attached_subject_registry()
        return self._post(f"/api/research/studies/{urllib.parse.quote(study_id, safe='')}/compare", {"measurement_id": measurement_id})

    def register_resilience_protocol(self, protocol: dict) -> dict:
        self._require_attached_subject_registry()
        return self._post("/api/research/resilience", protocol)

    def assess_resilience_protocol(self, protocol_id: str, measurement_ids: list[str]) -> dict:
        self._require_attached_subject_registry()
        return self._post(f"/api/research/resilience/{urllib.parse.quote(protocol_id, safe='')}/assess", {"measurement_ids": measurement_ids})

    def propose_biological_learning(self, proposal: dict) -> dict:
        self._require_attached_subject_registry()
        return self._post("/api/research/learning", proposal)

    def disease_reference(self, source: str, identifier: str) -> dict:
        self._require_attached_subject_registry()
        return self._get(f"/api/research/sources/{urllib.parse.quote(source, safe='')}/{urllib.parse.quote(identifier, safe='')}")

    def import_licensed_reference(self, manifest: dict, records: list[dict]) -> dict:
        self._require_attached_subject_registry()
        return self._post("/api/research/sources/import", {"manifest": manifest, "records": records})

    # ---- patient / cohort ---------------------------------------------------------
    def patient(self, base=None, note=None, age=None, sex="F", conditions=None,
                genome=None, lifestyle=0.6, hid="LMB-SDK") -> dict:
        """Explicit research preview, not admission of a registered person.

        Attached success describes this request's result; inspect state separately
        for the latest selection. Failed acknowledgments are never replayed locally.

        A ``note`` of any value is refused with ``CLINICAL_NOTE_NOT_ACCEPTED`` before
        it is sent, parsed, kept or audited: this release has no operational local
        de-identification (L0-R15). Use the structured fields instead; they take
        technical values only (``hid`` from a closed grammar, ``sex`` F or M,
        ``conditions`` and ``genome`` from the reference vocabulary), checked here
        before any request, twin change or audit.
        """
        admitted = None
        if note is None and not base:
            from .life_system.structured_human import admit_structured_human
            fields = {"id": hid, "sex": sex, "conditions": conditions or [], "genome": genome or {}}
            admitted = admit_structured_human(fields, default_id="LMB-SDK")
        if self.mode == "attach":
            if note is not None:
                family = "note"
                clinical_note_gate()
                st = self._research_preview_request("/api/ingest_note", {"text": note})
            elif base:
                family = "base"
                st = self._research_preview_request("/api/stimulate", {"kind": "base", "params": {"base": base}})
            else:
                family = "life_system"
                st = self._research_preview_request("/api/stimulate", {"kind": "life_system", "params": {
                    "mode": "custom", "id": admitted["id"], "age": age or 50, "sex": admitted["sex"],
                    "conditions": admitted["conditions"], "genome": admitted["genome"], "lifestyle": lifestyle}})
            out = self._preview_summary(st)
            try:
                audit.record("research_preview.request", {"family": family},
                    {"outcome": "ACKNOWLEDGED", "request_id": self.last_continuous_response["request_id"]})
            except Exception:
                # This legacy logger cannot establish durable append completion.
                # An observable local failure cannot erase the server's valid ACK.
                self.last_continuous_response["audit_code"] = "CLIENT_AUDIT_UNCONFIRMED"
            return out
        else:
            from .aegle.runtime import AegleTwin
            if note is not None:
                family = "note"
                clinical_note_gate()
                from .life_system.extract import ClinicalExtractor
                h, _info = ClinicalExtractor().to_synthetic_human(note, hid=hid)
                self._twin = AegleTwin(human=h)
            elif base:
                family = "base"
                self._twin = AegleTwin(base)
            else:
                family = "life_system"
                from .life_system.synthetic_human import SyntheticHuman
                h = SyntheticHuman(admitted["id"], age=int(age or 50), sex=admitted["sex"],
                                   conditions=admitted["conditions"], genome=admitted["genome"],
                                   lifestyle=float(lifestyle))
                self._twin = AegleTwin(human=h)
            out = self._summary(self._twin.state())
        # Local previews have no server acknowledgment; keep clinical contents
        # and calculated outputs out of the operational audit in this mode too.
        audit.record("patient.set", {"family": family, "mode": "inprocess"}, {"outcome": "CREATED"})
        return out

    def _preview_summary(self, state: dict) -> dict:
        """Validate only transport/preview identity, never fit or infer physiology."""
        def reject() -> None:
            raise self._clinical_response_error(mutation=True, use_current_metadata=True)
        request_id = self.last_continuous_response.get("request_id")
        if type(request_id) is not str or re.fullmatch(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", request_id) is None:
            reject()
        if type(state) is not dict or "code" in state or "error" in state:
            reject()
        availability = state.get("model_availability")
        if not _state_availability_valid(availability) or availability["selection_mode"] != "reference_preview":
            reject()
        parameters = state.get("profile_params")
        names = ("weight_kg", "Gb", "Ib", "SG", "p2", "Si", "gamma", "Gt", "n", "ka", "f_bioavail", "vg_per_kg")
        finite = lambda value: type(value) in {int, float} and math.isfinite(value)
        if (type(parameters) is not dict or type(parameters.get("name")) is not str
                or not parameters["name"] or not all(finite(parameters.get(key)) for key in names)
                or type(state.get("profile")) is not str or not state["profile"]
                or state.get("human") is not None and type(state["human"]) is not dict):
            reject()
        if (type(state.get("metabolic")) is not dict or type(state.get("cardiac")) is not dict
                or not finite(state["metabolic"].get("mean_glucose"))
                or not all(finite(state["cardiac"].get(key)) for key in ("hr_bpm", "hrv_ms"))):
            reject()
        try:
            return self._summary(state)
        except (ValueError, TypeError, KeyError, AttributeError):
            reject()

    def cohort(self, n: int = 50, seed: int = 0, *, indication: str | None = None) -> dict:
        """Generate a reproducible virtual cohort.

        ``indication='type-2-diabetes'`` produces an explicitly T2D-enriched
        synthetic cohort. It is not a prevalence sample: every member meets the
        modeled indication eligibility contract, and conflicting T1D labels are
        removed before screening.
        """
        from .life_system.population import LifeSystem
        population = LifeSystem()
        self._cohort = population.generate(n, seed=seed)
        if indication == "type-2-diabetes":
            required = "Type 2 diabetes mellitus"
            for human in self._cohort:
                human.conditions = [c for c in human.conditions
                                    if (population.kb.disease(c) or {}).get("doid") != "DOID:9744"]
                if required not in human.conditions:
                    human.conditions.append(required)
        elif indication is not None:
            raise ValueError(f"unsupported cohort indication: {indication}")
        self._cohort_context = indication
        self._cohort_seed = seed
        self._cohort_n = n
        out = {"n": len(self._cohort), "seed": seed,
               "indication": indication,
               "members": [{"id": h.id, "age": h.age, "sex": h.sex,
                            "conditions": list(h.conditions)} for h in self._cohort[:8]],
               "truncated": len(self._cohort) > 8}
        audit.record("cohort.generate", {"n": n, "seed": seed, "indication": indication},
                     {"n": len(self._cohort), "indication": indication})
        return out

    def _summary(self, st: dict) -> dict:
        if type(st) is not dict:
            raise self._clinical_response_error()
        availability = st.get("model_availability")
        if "model_availability" in st and not _state_availability_valid(availability):
            raise self._clinical_response_error()
        if availability is not None and availability["state"] == "UNAVAILABLE":
            # Absent computation is explicit; a new identity cannot inherit old metrics.
            if any(key not in st or st[key] is not None for key in ("profile", "metabolic", "cardiac")):
                raise self._clinical_response_error()
            return {"profile": None, "subject": availability["twin_id"],
                    "mean_glucose": None, "hr_bpm": None, "hrv_ms": None,
                    "model_availability": deepcopy(availability)}
        m, c = st.get("metabolic", {}), st.get("cardiac", {})
        if type(m) is not dict or type(c) is not dict:
            raise self._clinical_response_error()
        summary = {"profile": st.get("profile"), "subject": (st.get("human") or {}).get("id"),
                   "mean_glucose": m.get("mean_glucose"), "hr_bpm": c.get("hr_bpm"),
                   "hrv_ms": c.get("hrv_ms")}
        if availability is not None:
            summary["model_availability"] = deepcopy(availability)
        if "scenario" in st:
            summary["scenario"] = deepcopy(st["scenario"])
        return summary

    # ---- perturb / assay / state --------------------------------------------------
    def _audit_result(self, action: str, inputs: dict, outputs: dict) -> dict:
        """Keep operational receipts without duplicating the twin's clinical content."""
        return audit.record(
            action,
            {"actor": "local_operator", "mode": self.mode,
             "content_sha256": audit.content_hash({"inputs": inputs, "outputs": outputs})},
            {"outcome": "COMPLETED"},
        )

    def perturb(self, kind=None, compound=None, dose=1.0, **params) -> dict:
        """Run a compound or stimulus and summarize its returned model result.

        Attached physiological stimuli run as isolated scenarios; their receipt
        identifies the captured source and confirms the selected twin was unchanged.
        In-process stimuli update this SDK instance's local twin.
        """
        if self.mode == "attach":
            st = (self._post("/api/experiment", {"compound": compound, "dose": dose})
                  if compound else self._post("/api/stimulate", {"kind": kind, "params": params}))
        else:
            st = (self._twin.stimulate("gem_drug", name=compound, dose=dose)
                  if compound else self._twin.stimulate(kind, **params))
        out = self._summary(st)
        self._audit_result("perturb", {"kind": kind, "compound": compound, "dose": dose, "params": params}, out)
        return out

    def assay_ogtt(self, compound="metformin", dose=1.0, grams=75.0, **kw) -> dict:
        """Run the in-silico OGTT assay on the active twin's executable glucose-insulin model."""
        if compound != "metformin":
            from .engines.integrity import UnsupportedInterventionError

            raise UnsupportedInterventionError()
        inputs = {"compound": compound, "dose": dose, "grams": grams}
        if self.mode == "attach":
            body = {"drug": compound, "dose": dose, "grams": grams}
            res = self._post("/api/cendos/assay", body)
        else:
            from .cendos.assays import ogtt_effect
            from .engines import pharmacology as PH
            base = self._twin.profile
            inputs["baseline_profile"] = {
                name: getattr(base, name) for name in
                ("name", "weight_kg", "Gb", "Ib", "Si", "gamma", "Gt", "SG")
            }
            treated, treatment = PH.metformin(base, self._twin.human, dose)
            inputs["path"] = "pk-linked-metformin"
            res = ogtt_effect(base, treated, grams=grams)
            res["intervention"], res["subject"] = compound, base.name
            res["treatment"], res["pk"] = treatment, treatment.get("pk")
        rec = self._audit_result(
            "assay.ogtt", inputs,
            {k: res.get(k) for k in
             ("decision", "delta_mean", "delta_iAUC", "rel_mean", "subject", "pk")},
        )
        res["audit_id"] = rec["id"]
        return res

    def state(self) -> dict:
        st = self._continuous_request("GET", "/api/state") if self.mode == "attach" else self._twin.state()
        summary = self._summary(st)
        return {"summary": summary,
                **{key: summary[key] for key in ("profile", "mean_glucose", "hr_bpm", "hrv_ms")},
                **{key: deepcopy(st[key]) for key in ("model_availability", "observations", "patch") if key in st}}

    def manifest(self) -> dict:
        """Return the all-system capability contract without changing twin state."""
        if self.mode == "attach":
            return self._get("/api/system-manifest")
        from .foundation import whole_human_manifest
        return whole_human_manifest()

    def scientific_sources(
        self,
        *,
        collection: str | None = None,
        workflow: str | None = None,
        lifecycle: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """Query source governance; workflow queries return runtime-wired sources only."""
        if self.mode == "attach":
            query = urllib.parse.urlencode({
                key: value for key, value in {
                    "collection": collection,
                    "workflow": workflow,
                    "lifecycle": lifecycle,
                    "limit": limit,
                    "offset": offset,
                }.items() if value is not None
            })
            return self._get(f"/api/scientific-sources?{query}")
        from .scientific_sources import Catalog
        from .scientific_sources.graph_backends import backend_registry

        report = Catalog.load().report(
            collection=collection,
            workflow=workflow,
            lifecycle=lifecycle,
            limit=limit,
            offset=offset,
        )
        report["graph_backends"] = backend_registry()
        return report

    def workspace(self) -> dict:
        """Return the same bounded multiscale read model used by the web Atlas."""
        if self.mode == "attach":
            return self._get("/api/workspace")
        from .aegle.workspace import projection

        return projection(self._twin, self._workspace_actions)

    def workspace_action(self, kind: str, **params) -> dict:
        """Run an Atlas action with the same validated lifecycle as the web UI."""
        from .aegle.workspace import (
            ActionStatus,
            WorkspaceAction,
            projection,
            validate_action_input,
        )

        validated_kind, clean = validate_action_input({"kind": kind, "params": params})
        if self.mode == "attach":
            result = self._post(
                "/api/workspace/actions", {"kind": validated_kind, "params": clean},
            )
        else:
            subject = self._twin.human.id if self._twin.human else self._twin.profile.name
            action = WorkspaceAction(
                kind=validated_kind, subject_id=str(subject), parameters=clean,
            )
            self._workspace_actions.append(action)
            action.transition(ActionStatus.RUNNING)
            try:
                self._twin.stimulate(validated_kind, **clean)
                action.transition(ActionStatus.COMPLETED)
            except (ValueError, RuntimeError, ArithmeticError) as error:
                action.transition(ActionStatus.FAILED, error_code=type(error).__name__)
                raise
            result = {
                "action": action.to_dict(),
                "workspace": projection(self._twin, self._workspace_actions),
            }
        self._audit_result(
            "workspace.action",
            {"kind": validated_kind, "params": clean},
            {"action_id": result["action"]["action_id"], "status": result["action"]["status"]},
        )
        return result

    def virtual_patch_sample(
        self,
        *,
        readings: dict[str, float] | None = None,
        device_id: str = "virtual-sdk-patch-001",
        subject_id: str | None = None,
    ) -> dict:
        """Emit a virtual v2 Patch sample and reconcile it without calibration."""
        if self.mode == "attach":
            request = {"readings": readings or {}, "device_id": device_id}
            if subject_id is not None:
                request["subject_id"] = subject_id
            payload = self._post(
                "/api/patch/virtual",
                request,
            )
            workspace = self.workspace()
            return {
                "admission": payload,
                "patch": workspace["twin"]["patch"],
                "reconciliation": workspace["multiscale"]["patch_reconciliation"],
            }

        from .life_patch.protocol import DeviceMode, VirtualLifePatch, manifest_for
        from .multiscale import reconcile_patch

        state = self._twin.state()
        if readings is None:
            readings = {
                "glucose_mgdl": state["metabolic"]["glucose"][-1],
                "hr_bpm": state["cardiac"]["hr_bpm"],
            }
        manifest = manifest_for(device_id, DeviceMode.VIRTUAL)
        patch = VirtualLifePatch(manifest, sequence=self._virtual_patch_sequence)
        envelope = patch.emit(
            subject_id
            or (self._twin.human.id if self._twin.human else "pseudonym-sdk-subject"),
            readings,
        )
        self._virtual_patch_sequence = envelope.sequence
        self._twin.ingest_patch_envelope(envelope)
        result = {
            "envelope_id": envelope.envelope_id,
            "patch": self._twin.state()["patch"],
            "reconciliation": reconcile_patch(self._twin),
        }
        audit.record(
            "patch.virtual.sample",
            {"device_id": device_id, "signals": sorted(readings)},
            {"envelope_id": envelope.envelope_id,
             "calibration_authorized": result["reconciliation"]["calibration_authorized"]},
        )
        return result

    # ---- pharma workflow: cohort compound screen -> OGTT -> rank -> signed report --

    @staticmethod
    def _pin_resolution(compound: str, refresh: bool = False) -> dict:
        """Resolve a compound to ChEMBL targets ONCE and pin the resolution to disk.

        First call resolves live (curated mechanism-of-action, then measured
        bioactivity); the pinned {chembl_id, source, targets[gene→scale]} is
        persisted (rcache) and every later screen reads the pin — so re-runs
        reproduce exactly even if ChEMBL answers differently tomorrow.
        Determinism no longer stops at the ChEMBL boundary (audit §6.2).
        Unresolvable compounds raise — nothing is substituted."""
        from .aegle import rcache
        from .engines import drug_targets as DT
        key = "screen-pin:" + compound.strip().lower()
        if not refresh:
            hit = rcache.get(key)
            if hit and hit.get("targets"):
                return {**hit, "pinned_from_cache": True}
        info = DT.resolve_drug(compound)
        source = "chembl-moa"
        if not info.get("resolved"):
            info = DT.resolve_bioactive(compound)
            source = "chembl-bioactivity"
        if not info.get("resolved") or not info.get("targets"):
            raise RuntimeError(
                f"compound {compound!r} did not resolve to any ChEMBL targets "
                f"({info.get('error') or 'no curated mechanism, no potent bioactivity'}) "
                f"— refusing to screen an unresolved compound")
        pin = {"compound": compound, "chembl_id": info.get("chembl_id"), "source": source,
               "targets": [{"gene": t["gene"], "action": t.get("action"),
                            "scale": t["scale"]} for t in info["targets"]]}
        rcache.put(key, pin)
        return {**pin, "pinned_from_cache": False}

    def screen(self, compound="metformin", dose=1.0, grams=75.0, n=None, seed=0,
               mode="auto", indication="type-2-diabetes", cohort="t2d-enriched",
               assay="ogtt", **kw) -> dict:
        """Screen a compound across a reproducible virtual cohort: apply it to every twin,
        run the OGTT assay, rank by predicted glucose-lowering effect. Deterministic and
        signed. In-process only (reproducibility requires isolated state).

        Only the existing bounded metformin hypothesis model executes here.
        ChEMBL associations and supplied effect coefficients do not qualify a screen.
        """
        if self.mode != "inprocess":
            raise RuntimeError("screen() runs in-process for reproducibility; use Platform(mode='inprocess')")
        if not isinstance(compound, str) or not compound.strip():
            raise ValueError("compound must be a non-empty string")
        compound = compound.strip()
        if len(compound) > 200:
            raise ValueError("compound exceeds 200 characters")
        if compound.lower() != "metformin" or mode not in {"auto", "metformin"}:
            from .engines.integrity import UnsupportedInterventionError

            raise UnsupportedInterventionError(
                "No qualified generic compound screen is available; use a registered "
                "compound-specific Cendos protocol"
            )
        compound = "metformin"
        if any(key in kw for key in ("si_boost", "gb_drop", "gamma_boost")):
            raise ValueError("generic benefit coefficients are not executable screen inputs")
        try:
            dose = float(dose)
            grams = float(grams)
            seed = int(seed)
            n = int(n) if n is not None else None
        except (TypeError, ValueError) as exc:
            raise ValueError("dose, grams, n, and seed must be numeric") from exc
        if not math.isfinite(dose) or not (0 < dose <= 5):
            raise ValueError("dose must be finite and within (0, 5]")
        if not math.isfinite(grams) or not (0 < grams <= 200):
            raise ValueError("grams must be finite and within (0, 200]")
        if n is not None and not (1 <= n <= 10_000):
            raise ValueError("n must be within [1, 10000]")
        if not (-2_147_483_648 <= seed <= 2_147_483_647):
            raise ValueError("seed must fit a signed 32-bit integer")
        supported_context = ("type-2-diabetes", "t2d-enriched", "ogtt")
        requested_context = (indication, cohort, assay)
        if requested_context != supported_context:
            raise ValueError(
                "unsupported screen context: Phase 1 supports indication="
                "'type-2-diabetes', cohort='t2d-enriched', assay='ogtt' only"
            )
        requested_n = n if n is not None else (self._cohort_n or 50)
        if (not self._cohort or self._cohort_context != indication
                or self._cohort_seed != seed or self._cohort_n != requested_n):
            self.cohort(requested_n, seed=seed, indication=indication)
        from .cendos.assays import ogtt_effect
        from .life_system.knowledge import get_kb
        kb = get_kb()
        path = "metformin"

        def _treat(h, base):
            from .engines import pharmacology as PH

            return PH.metformin(base, h, dose)

        rows = []
        for h in self._cohort:
            base = h.metabolic_profile(kb)
            treated, treatment = _treat(h, base)
            res = ogtt_effect(base, treated, grams=grams)
            row = {"id": h.id, "age": h.age, "sex": h.sex, "conditions": list(h.conditions),
                   "baseline_mean": res["baseline"]["mean"], "delta_mean": res["delta_mean"],
                   "delta_iAUC": res["delta_iAUC"], "rel_mean": res["rel_mean"],
                   "decision": res["decision"]}
            if treatment.get("pk"):
                row["pk"] = treatment["pk"]
                row["pharmacogenomics"] = {
                    "oct1_lof_alleles": treatment["oct1_lof_alleles"],
                    "oct1_transport": treatment["oct1_transport"],
                    "renal_factor": treatment["renal_factor"],
                }
            rows.append(row)
        rows.sort(key=lambda r: r["delta_mean"])          # most glucose-lowering first
        n_eff = sum(1 for r in rows if r["decision"] == "EFFECT")
        admissibility = {
            "status": "supported",
            "indication": indication,
            "cohort": cohort,
            "assay": assay,
            "basis": "T2D-enriched synthetic eligibility plus mechanistic glucose-insulin model",
            "limits": "model-only hypothesis triage; not clinical efficacy or dosing evidence",
        }
        summary = {"compound": compound, "dose": dose, "grams": grams, "cohort_n": len(rows), "seed": seed,
                   "path": path,
                   "indication": indication, "cohort": cohort, "assay": assay,
                   "admissibility": admissibility,
                   "n_effect": n_eff, "responder_rate": round(n_eff / len(rows), 3) if rows else 0.0,
                   "mean_delta_mean": round(sum(r["delta_mean"] for r in rows) / len(rows), 1) if rows else 0.0,
                   "best": rows[0] if rows else None, "worst": rows[-1] if rows else None}
        if path == "metformin":
            summary["pk_model"] = "one-compartment oral; renal exposure and OCT1 hepatic uptake"
        inputs = {"compound": compound, "dose": dose, "grams": grams,
                  "cohort_n": len(rows), "seed": seed, "path": path,
                  "indication": indication, "cohort": cohort, "assay": assay}
        rec = self._audit_result("screen.cohort_ogtt", inputs, {"summary": summary, "ranked": rows})
        out = {"summary": summary, "ranked": rows, "audit": rec}
        return out
