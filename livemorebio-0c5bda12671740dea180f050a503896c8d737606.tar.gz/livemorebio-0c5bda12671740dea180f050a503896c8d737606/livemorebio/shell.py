"""livemorebio.shell — the interactive Livemore environment (REPL) + pipeline runner.

Typing `livemore shell` (or bare `livemore`) drops into this environment, where a pharma
user does everything they'd do in the web app — create patients/cohorts, perturb, run
assays, screen compounds, pull results, export reproducibility reports — all through the one SDK.
The same commands run non-interactively from a pipeline file for reproducible scripts.
Account login is deferred; today every session has full platform access.
"""
from __future__ import annotations
import json
import re
import shlex

from .sdk import Platform
from . import audit, report
from .clinical_note_gate import ClinicalNoteRefused, clinical_note_gate, refuse_field
from .strict_json import MAX_JSON_BYTES, parse_json_object
from .execution_client import ContinuousClientError, identifier, integer
from .execution_commands import continuous_line, run_continuous_command, safe_error
from .atlas_client import AtlasClientError
from .atlas_commands import atlas_line, run_atlas_command, safe_atlas_error
import urllib.error

BANNER = (
    "\n  LivemoreBio — living human digital twin platform\n"
    "  in-silico · mechanistic · reproducible · evidence-governed\n"
    "  type 'help' for commands, 'quit' to exit\n")

HELP = """commands (same in the shell and in pipeline files):
  atlas status [json=true]            attached reference-only anatomy readiness; no download
  atlas install bp3d-4.0-20130619-surface-core-v1 [json=true]  explicit fixed-source install
  execution capabilities             inspect continuous contracts/source (attach only)
  execution prepare <request.json|-> key=<opaque>  freeze exact server source; does not start
  execution <status|observations> <id> [json=true]  inspect metadata/full bounded JSON
  execution frames <id> [after=0] [limit=100]  inspect native frame metadata
  execution <start|pause|resume|stop> <id> (control_revision=<n> | revision=<n>) generation=<id>
  execution fork <id> <request.json|-> key=<opaque>  explicit full-checkpoint fork
  patch virtual capabilities         inspect numerical probe operator; not physical sensors
  patch virtual probe device=<id>    register probe before binding twin/preparing source
  patch virtual start <request.json|->  bind consumer before starting producer
  patch virtual status <id>          inspect source/pending/acknowledgment state
  patch virtual <pause|resume|stop> <id> (control_revision=<n> | revision=<n>)  exactly one lifecycle guard
  [continuous options: json=true or output=<new-private-file>; never overwrite]
  twin list [limit=25] [cursor=...] [q=...]  bounded governed twin page (attach)
  twin admit <bundle.json> [key=...]   admit an encrypted twin bundle without PHI in shell history
  twin activate <id> version=<n>       make an admitted twin authoritative across products
  twin select-observations <id> version=<n>  select admitted evidence; no model activation
  twin reconcile-selection               explicitly recover audited selection authority (attach)
  twin patch <id> version=<n> mode=<virtual|physical> device=<id> [...]  bind LIFE Patch
  patient <healthy|t2d>              set the active twin from a base
  patient note ...                   refused: this release accepts no clinical note (no local de-identification)
  patient age=61 sex=M lifestyle=.4 conditions=hypertension genome=APOE4  structured build (vocabulary terms only)
  cohort <n> [seed=<s>]              generate an in-process reproducible virtual cohort
  cohort list [limit=25] [cursor=...] [q=...]  bounded frozen cohort page (attach)
  cohort members <id> [limit=10] [cursor=...]  one frozen REAL_HUMAN summary page
  cohort member <cohort_id> <member_id>  inspect frozen evidence metadata, not clinical payload
  cohort create name=<name> size=<n> source=REFERENCE_GROUNDED_SYNTHETIC stratum=<...>  freeze a governed cohort
  protocol metformin cohort_a=<id> cohort_b=<id> [dose_mg=1000] [grams=75]
  protocol garcinoic cohort=<id> [concentrations=0.05,0.33,1.3,5.0]
  protocol latest                     show the latest frozen Cendos protocol
  protocol history [limit=20] [cursor=...] [q=...]  browse immutable run history
  protocol show <run_id>               inspect frozen run and metabolic numerical diagnostics
  protocol prepare <run_id>            inspect rerun readiness; does not execute
  protocol rerun <run_id> [new_configuration=true]  explicitly execute a new child run
  protocol metabolic <specification.json>  execute bounded Human-GEM oxygen/ATP conditions
  protocol lobeline <specification.json>  execute nonhuman VMAT2 initial-rate conditions
  protocol export <run_id> notebook=<new-path.ipynb>  export frozen analysis, never overwrite
  models                              inspect attached model asset/solver readiness
  program list                       insulin + five botanical programs and their executability
  program show <LBHR-id>             material, sources, missing measurements for one program
  program run <LBHR-id> [dose_mg=100] [cohort=10] [seed=0] [hours=24] [json=true] [output=<new.json>]
  insulin products                   admitted and refused insulin products (with reasons)
  insulin run [product=rapid-acting-analogue-sc] [units=4] [meal=60] [cohort=12] [seed=0]
              [basal=0.006 U/kg/h] [hours=8] [json=true] [output=<new.json>]   paired control/treated arms
  research list                       list evidence records (attach mode)
  research freeze <criteria.json>      freeze run_id plus counterpart criteria
  research import <payload.json>       admit study_id, custody and CSV payload
  research compare <study_id> [measurement=<id>]  assess stored pairs, never calibrate
  research resilience <protocol.json>  register subject roster and five cure operations
  research assess <protocol_id> [measurements=id1,id2]  assess independent follow-up
  research learn <proposal.json>       record source-backed model-change proposal
  research source <kegg|malacards> <id> exact licensed disease reference lookup
  research source-import <release.json> validate licensed manifest and records
  perturb <compound> [dose=1.0]      apply a resolved compound to the active twin
  perturb kind=meal grams=100        apply a stimulus kind
  assay <compound> [dose=] [grams=]  in-silico OGTT assay on the active twin
  screen <compound> [mode=] [n=50] [seed=0] [dose=] [grams=]   T2D/OGTT hypothesis screen
  show <twin|state|workspace>        show twin state or the multiscale Atlas projection
  action <metformin|meal|cardiac|reset> [parameters]  run an Atlas action
  patch sample                       emit/reconcile a virtual LIFE Patch v2 sample
  sources [workflow=...] [collection=] [lifecycle=] [limit=50]  governed scientific sources
  report [path.md]                   export the last screen reproducibility report
  pipeline <file>                    run a file of these commands
  audit verify <record.json>         verify a signed record reproduces + is untampered
  mode                               show execution mode (inprocess|attach)
  help | quit"""


def _coerce(v):
    try:
        return int(v)
    except ValueError:
        try:
            return float(v)
        except ValueError:
            return v


def _parse(args):
    pos, kw = [], {}
    for a in args:
        if "=" in a and not a.startswith("="):
            k, v = a.split("=", 1)
            kw[k] = _coerce(v)
        else:
            pos.append(a)
    return pos, kw


def _fmt(d):
    return "  " + " · ".join(f"{k}={v}" for k, v in d.items() if v is not None)


def _fmt_screen(r):
    s, rows = r["summary"], r["ranked"]
    head = (f"  screen {s['compound']} · cohort {s['cohort_n']} (seed {s['seed']}) · "
            f"responders {s['n_effect']}/{s['cohort_n']} ({s['responder_rate']*100:.0f}%) · "
            f"mean Δglc {s['mean_delta_mean']} mg/dL")
    lines = [head, "  rank  id         age sex  Δmean  decision"]
    for i, x in enumerate(rows[:10], 1):
        lines.append(f"  {i:>3}   {x['id']:<10} {x['age']:>3} {x['sex']:<3} "
                     f"{x['delta_mean']:>6}  {x['decision']}")
    if len(rows) > 10:
        lines.append(f"  … {len(rows)-10} more (use `report` to export the full ranking)")
    lines.append(f"  local integrity · fingerprint {r['audit']['result_sha256'][:16]}… · "
                 f"verify: report then `livemore audit verify <file>.audit.json`")
    return "\n".join(lines)


def _clinical_family(line: str) -> str | None:
    # Read only the command prefix: a malformed later argument must not undo redaction.
    lexer = shlex.shlex(line, posix=True)
    lexer.whitespace_split = True
    lexer.commenters = ""
    try:
        family = " ".join((next(lexer).lower(), next(lexer).lower()))
    except (ValueError, StopIteration):
        return None
    return family if family in {"twin select-observations", "twin reconcile-selection", "cohort members", "cohort member"} else None


def _note_line(line: str) -> bool:
    """Whether a line asks for clinical-note intake, read from its first two words only.

    Every spelling the parser would accept is included (case, quotes, ``note=``),
    and nothing after the second word is read: the note itself is never parsed.
    """
    lexer = shlex.shlex(line, posix=True)
    lexer.whitespace_split = True
    lexer.commenters = ""
    try:
        return next(lexer).lower() == "patient" and next(lexer).lower().startswith("note")
    except (ValueError, StopIteration):
        return False


def refusal_line(error: ClinicalNoteRefused) -> str:
    """The typed refusal as the shell prints it: a code and a reason, never the note."""
    return f"  refused [{error.code}]: {error.reason}"


def _patient_line(line: str) -> bool:
    # Classify just the first parsed word, before a private malformed note tail.
    lexer = shlex.shlex(line, posix=True)
    lexer.whitespace_split = True
    lexer.commenters = ""
    try:
        return next(lexer).lower() == "patient"
    except (ValueError, StopIteration):
        return False


def _command_words(line: str) -> str | None:
    """Recognize dispatch words, never return caller-supplied arguments.

    This is command recognition, not patient-data screening. Recognized
    commands can have free-text arguments, so their history remains local and
    optional. Incomplete quoting and unknown subcommands are not history.
    """
    if not line.strip() or line.lstrip().startswith("#"):
        return None
    try:
        parts = shlex.split(line)
    except ValueError:
        return None
    if not parts or parts[0].lower() not in _VERBS:
        return None
    verb = parts[0].lower()
    if verb in {"help", "quit", "exit", "mode", "models"}:
        return verb if len(parts) == 1 else None
    positional = [part for part in parts[1:] if "=" not in part or part.startswith("=")]
    subcommands = {
        "program": {"list": 0, "show": 1, "run": 1},
        "insulin": {"products": 0, "run": 0},
        "research": {"list": 0, "freeze": 1, "import": 1, "compare": 1, "resilience": 1,
                     "assess": 1, "learn": 1, "source": 2, "source-import": 1},
        "twin": {"list": 0, "admit": 1, "activate": 1, "patch": 1,
                 "select-observations": 1, "reconcile-selection": 0},
        "protocol": {"history": 0, "prepare": 1, "rerun": 1, "show": 1, "export": 1,
                     "metabolic": 1, "lobeline": 1, "metformin": 0, "garcinoic": 0,
                     "garcinoic-pxr": 0, "latest": 0},
        "show": {"twin": 0, "state": 0, "workspace": 0},
        "action": {"metformin": 0, "drug": 0, "meal": 0, "cardiac": 0, "ikr": 0, "reset": 0},
        "patch": {"sample": 0, "virtual": 2},
        "audit": {"verify": 1},
        "atlas": {"status": 0, "install": 1},
        "execution": {"capabilities": 0, "prepare": 1, "status": 1, "frames": 1,
                      "observations": 1, "start": 1, "pause": 1, "resume": 1, "stop": 1, "fork": 2},
    }
    if verb == "cohort":
        if not positional or re.fullmatch(r"[0-9]+", positional[0]):
            return verb if len(positional) <= 1 else None
        command = positional[0].lower()
        maximum = {"list": 0, "create": 0, "member": 2, "members": 1}.get(command)
        return f"cohort {command}" if maximum is not None and len(positional) <= maximum + 1 else None
    if verb in subcommands:
        if not positional:
            if len(parts) > 1 and verb != "twin":
                return None
            return verb if verb in {"program", "insulin", "research", "twin", "protocol", "show"} else None
        command = positional[0]
        if verb in {"research", "twin", "protocol", "action"}:
            command = command.lower()
        if command not in subcommands[verb]:
            return None
        if len(positional) > subcommands[verb][command] + 1:
            return None
        if (verb == "show" or (verb, command) in {
            ("patch", "sample"), ("program", "list"), ("program", "show"),
            ("insulin", "products"), ("research", "list"), ("protocol", "latest"),
        }) and len(parts) != len(positional) + 1:
            return None
        if verb == "patch" and command == "virtual":
            if len(positional) < 2 or positional[1] not in {"capabilities", "probe", "start", "status", "pause", "resume", "stop"}:
                return None
            return "patch virtual " + positional[1]
        return verb + " " + command
    if verb != "patient" and len(positional) > (0 if verb == "sources" else 1):
        return None
    return verb


def _unavailable_summary(state: dict) -> dict | None:
    availability = state.get("model_availability")
    if isinstance(availability, dict) and availability.get("state") == "UNAVAILABLE":
        return {"twin": availability["twin_id"], "version": availability["twin_version"],
                "state": availability["state"], "reason": availability["reason_code"],
                "selection": availability["selection_mode"]}
    return None


def _run_clinical_command(P, line: str, out=print):
    """Parse before legacy coercion; only safe metadata is printed by this family."""
    try:
        tokens = shlex.split(line)
    except ValueError:
        raise ContinuousClientError() from None
    family = " ".join(token.lower() for token in tokens[:2])
    positional, options = [], {}
    for token in tokens[2:]:
        if "=" in token:
            key, value = token.split("=", 1)
            if not key or not value or key in options:
                raise ContinuousClientError()
            options[key] = value
        else:
            positional.append(token)
    def number(value: str, maximum: int) -> int:
        if re.fullmatch(r"[0-9]{1,16}", value) is None:
            raise ContinuousClientError()
        return integer(int(value), 1, maximum)
    if family == "twin reconcile-selection":
        if positional or options:
            raise ContinuousClientError()
        result = P.reconcile_twin_selection()
        availability = result["model_availability"]
        out(_fmt({"selection_status": result["selection_status"], "state": availability["state"],
                  "selection": availability["selection_mode"], "twin": availability["twin_id"],
                  "version": availability["twin_version"], "prior_execution_cleanup": result["prior_execution_cleanup"]}))
    elif family == "twin select-observations":
        if len(positional) != 1 or set(options) != {"version"}:
            raise ContinuousClientError()
        twin_id, version = identifier(positional[0]), number(options["version"], 2**53 - 1)
        result = P.select_twin_observations(twin_id, expected_version=version)
        availability = result["model_availability"]
        out(_fmt({"twin": result["twin_id"], "version": result["version"], "source": result["source_class"],
                  "selection": availability["selection_mode"], "state": availability["state"], "reason": availability["reason_code"]}))
    elif family == "cohort members":
        if len(positional) != 1 or not set(options) <= {"limit", "cursor"}:
            raise ContinuousClientError()
        cursor = options.get("cursor")
        if cursor is not None and re.fullmatch(r"[A-Za-z0-9_-]{1,1024}", cursor) is None:
            raise ContinuousClientError()
        cohort_id, limit = identifier(positional[0]), number(options.get("limit", "10"), 50)
        result = P.list_cohort_members(cohort_id, limit=limit, cursor=cursor)
        for member in result["members"]:
            out(_fmt({"member": member["twin_id"], "version": member["record_version"], "source": member["source_class"],
                      "state": member["execution_eligibility"]["state"], "reason": member["execution_eligibility"]["reason_code"]}))
        out(_fmt({key: result["pagination"].get(key) for key in ("limit", "total", "has_more", "next_cursor")}))
    elif family == "cohort member":
        if len(positional) != 2 or options:
            raise ContinuousClientError()
        cohort_id, member_id = identifier(positional[0]), identifier(positional[1])
        result = P.get_cohort_member(cohort_id, member_id)
        out(_fmt({key: result.get(key) for key in ("schema", "twin_id", "record_version", "source_class", "snapshot_sha256", "evidence_sha256")}))
        out("  Frozen descriptive evidence inspected. This read does not establish a model binding or substitute a current member.")
    else:
        raise ContinuousClientError()
    correlation = getattr(P, "last_continuous_response", {}).get("request_id")
    if type(correlation) is str and re.fullmatch(r"[0-9a-f]{32}|[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", correlation):
        out(_fmt({"request_id": correlation}))
    return result


def _write_new_json(path: str, payload: dict, out=print) -> None:
    import os
    if os.path.exists(path):
        out(f"  refusing to overwrite existing file: {path}"); return
    with open(path, "x", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=2, sort_keys=True, allow_nan=False)
    out(f"  wrote {path}")


def _program_command(P, pos, kw, out=print) -> None:
    from .cendos.botanical_programs import PROGRAMS, BotanicalProgramError
    command = pos[0] if pos else "list"
    if command == "list":
        catalog = P.program_catalog()
        for item in catalog["botanical"]["programs"]:
            out(f"  {item['program_id']:9} {item['compound']:22} {item['executability']:24} "
                f"{item['reason_code'] or ''}")
        out(f"  insulin   exogenous insulin (paired)   admitted products: "
            f"{', '.join(p['product_id'] for p in catalog['insulin']['admitted'])}")
        out("  " + catalog["botanical"]["validation_status"])
        return
    if command == "show" and len(pos) >= 2:
        program = PROGRAMS.get(pos[1])
        if program is None:
            out(f"  unknown program: {pos[1]}"); return
        out(json.dumps(program, indent=2)); return
    if command == "run" and len(pos) >= 2:
        spec = {"program_id": pos[1]}
        for source, target, cast in (("dose_mg", "dose_mg", float), ("cohort", "cohort_size", int),
                                     ("seed", "seed", int), ("hours", "hours", float)):
            if source in kw:
                spec[target] = cast(kw[source])
        try:
            result = P.run_botanical_program(spec)
        except BotanicalProgramError as error:
            out(f"  refused [{error.code}]: {error}"); return
        if str(kw.get("json", "")).lower() == "true":
            out(json.dumps(result, indent=2, sort_keys=True))
        else:
            out(_fmt({"run": result["run_id"], "program": result["program"]["program_id"],
                      "outcome": result["outcome"], "reason": result.get("reason_code"),
                      "summary": result.get("summary") or result.get("margin"),
                      "exposure_basis": result.get("exposure_basis", "modelled"),
                      "human_exposure_admissible": result["human_exposure_admissible"],
                      "controls_passed": all(c["passed"] for c in result["controls"]),
                      "persisted": P.mode == "attach"}))
            if result.get("missing_measurement"):
                out("  missing: " + result["missing_measurement"])
            if result.get("active_range_missing"):
                # Some programs are blocked by their active range, not exposure (L0W-7).
                out("  missing active range: " + result["active_range_missing"])
        if "output" in kw:
            _write_new_json(str(kw["output"]), result, out)
        return
    out("  usage: program list | program show <id> | program run <id> [dose_mg=] [cohort=] [seed=] [hours=]")


def _insulin_command(P, pos, kw, out=print) -> None:
    from .cendos.insulin_protocol import InsulinProtocolError
    command = pos[0] if pos else "products"
    if command == "products":
        catalog = P.program_catalog()["insulin"]
        for item in catalog["admitted"]:
            out(f"  ADMITTED  {item['product_id']:28} {item['route']}")
        for item in catalog["declared_not_admitted"]:
            out(f"  REFUSED   {item['product_id']:28} {item['reason']}")
        return
    if command == "run":
        spec = {}
        for source, target, cast in (("product", "product_id", str), ("units", "bolus_units", float),
                                     ("bolus_time", "bolus_time_min", float), ("meal", "meal_g", float),
                                     ("meal_time", "meal_time_min", float), ("cohort", "cohort_size", int),
                                     ("seed", "seed", int), ("basal", "basal_u_per_kg_h", float),
                                     ("hours", "hours", float)):
            if source in kw:
                spec[target] = cast(kw[source])
        try:
            result = P.run_insulin_protocol(spec)
        except InsulinProtocolError as error:
            out(f"  refused [{error.code}]: {error}"); return
        if str(kw.get("json", "")).lower() == "true":
            out(json.dumps(result, indent=2, sort_keys=True))
        else:
            out(_fmt({"run": result["run_id"], "product": result["intervention"]["product"]["product_id"],
                      "bolus_units": result["intervention"]["bolus_units"], "summary": result["summary"],
                      "controls_passed": all(c["passed"] for c in result["controls"]),
                      "applicability": result["applicability"], "persisted": P.mode == "attach"}))
            for member in result["members"]:
                diff = member["paired_difference"]
                out(f"    {member['member_id']}  {member['weight_kg']:6.1f} kg  baseline "
                    f"{member['baseline_glucose_mmol_L']:6.2f} mmol/L  dAUC {diff['delta_glucose_auc_mmol_L_min']:9.1f}"
                    f"  dNadir {diff['delta_nadir_mmol_L']:7.3f}")
        if "output" in kw:
            _write_new_json(str(kw["output"]), result, out)
        return
    out("  usage: insulin products | insulin run [product=] [units=] [meal=] [cohort=] [seed=] [basal=] [hours=]")


def run_command(P, line, out=print):
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    if _note_line(line):
        # Dispatch reads only the prefix; pipelines also parse lines for recognition.
        clinical_note_gate()
    if _clinical_family(line):
        return _run_clinical_command(P, line, out=out)
    if atlas_line(line):
        try:
            parts = shlex.split(line)
        except ValueError:
            raise AtlasClientError() from None
        return run_atlas_command(P, parts, out=out)
    if continuous_line(line):
        try:
            parts = shlex.split(line)
        except ValueError:
            raise ContinuousClientError() from None
        return run_continuous_command(P, parts, out=out)
    if _command_words(line) is None:
        if _patient_line(line):
            raise ContinuousClientError() from None
        out("  unknown command (try `help`)")
        return
    parts = shlex.split(line)
    verb, args = parts[0].lower(), parts[1:]
    pos, kw = _parse(args)

    if verb in ("quit", "exit"):
        return "QUIT"
    if verb == "help":
        out(HELP); return
    if verb == "mode":
        out(f"  mode: {P.mode}"); return
    if verb == "program":
        _program_command(P, pos, kw, out); return
    if verb == "insulin":
        _insulin_command(P, pos, kw, out); return
    if verb == "models":
        result = P.genome_models()
        out(json.dumps(result, indent=2))
        return result

    if verb == "research":
        command = pos[0].lower() if pos else "list"
        if command == "list":
            result = P.research_overview()
            for record in result["records"]:
                out(_fmt({key: record.get(key) for key in ("id", "kind", "status", "state")}))
            out(f"  {len(result['records'])} records; no biological qualification inferred")
            return result
        if command == "compare" and len(pos) >= 2:
            result = P.compare_research_study(pos[1], kw.get("measurement"))
        elif command == "assess" and len(pos) >= 2:
            mids = [value for value in str(kw.get("measurements", "")).split(",") if value]
            result = P.assess_resilience_protocol(pos[1], mids)
        elif command == "source" and len(pos) >= 3:
            result = P.disease_reference(pos[1], pos[2])
        elif command in {"freeze", "import", "resilience", "learn", "source-import"} and len(pos) >= 2:
            from pathlib import Path
            path = Path(pos[1])
            if path.stat().st_size > MAX_JSON_BYTES:
                raise ValueError("research input file exceeds 2 MB")
            with path.open("rb") as stream:
                payload = parse_json_object(stream.read(MAX_JSON_BYTES + 1))
            if command == "freeze":
                result = P.freeze_research_study(payload.pop("run_id"), payload)
            elif command == "import":
                result = P.admit_research_measurement(payload.pop("study_id"), payload)
            elif command == "resilience":
                result = P.register_resilience_protocol(payload)
            elif command == "learn":
                result = P.propose_biological_learning(payload)
            else:
                result = P.import_licensed_reference(payload["manifest"], payload["records"])
        else:
            out("  usage: research <list|freeze|import|compare|resilience|assess|learn|source|source-import>; see help")
            return
        # Return full data to SDK callers, but never echo clinical payloads into terminal history/logs.
        out(_fmt({key: result.get(key) for key in ("id", "status", "state", "qualification_state", "calibration_authorized", "model_change_authorized")}))
        return result

    if verb == "twin":
        command = pos[0].lower() if pos else "list"
        if command == "list":
            result = P.list_twins(**{k: kw[k] for k in ("limit", "cursor", "q") if k in kw})
            active = result.get("active") or {}
            certainty = result.get("selection_status", "UNKNOWN")
            out(_fmt({"selection_status": certainty, "active": active.get("twin_id") if certainty == "CONFIRMED" else "unconfirmed",
                      "records": len(result.get("twins", []))}))
            for record in result.get("twins", []):
                out(f"  {record['twin_id']} · {record['source_class']} · {record['lifecycle']} · v{record['version']}")
            out(_fmt(result.get("pagination", {})))
            return
        if command == "admit":
            if len(pos) < 2:
                out("  usage: twin admit <bundle.json> [key=<idempotency-key>]"); return
            with open(pos[1], encoding="utf-8") as stream:
                payload = json.load(stream)
            key = str(kw.get("key") or f"shell-{payload.get('subject_id', 'twin')}")
            record = P.admit_twin(payload, idempotency_key=key)
            out(_fmt({"twin": record["twin_id"], "source": record["source_class"],
                      "lifecycle": record["lifecycle"], "version": record["version"]}))
            return
        if command == "activate" and len(pos) >= 2:
            if "version" not in kw:
                out("  usage: twin activate <id> version=<n>"); return
            record = P.activate_twin(pos[1], expected_version=int(kw["version"]))
            out(_fmt({"twin": record["twin_id"], "lifecycle": record["lifecycle"],
                      "version": record["version"]}))
            return
        if command == "patch" and len(pos) >= 2:
            if "version" not in kw or "device" not in kw:
                out("  usage: twin patch <id> version=<n> mode=<virtual|physical> device=<id> [firmware= attestation= calibration=current]"); return
            payload = {
                "mode": str(kw.get("mode", "virtual")),
                "device_id": str(kw["device"]),
                "hardware_revision": str(kw.get("hardware", "B0-EVT-target")),
                "protocol_version": str(kw.get("protocol", "2.0")),
                "firmware_version": str(kw.get("firmware", "virtual-2.0")),
                "calibration_status": str(kw.get("calibration", "not_applicable")),
                "attestation_reference": str(kw.get("attestation", "")),
            }
            record = P.bind_patch(pos[1], payload, expected_version=int(kw["version"]))
            binding = record["patch_bindings"][-1]
            out(_fmt({"twin": record["twin_id"], "device": binding["device_id"],
                      "mode": binding["mode"], "telemetry": binding["telemetry_admission"]}))
            return
        out("  usage: twin <list|admit|activate|patch> ...")
        return

    if verb == "patient":
        # Never silently drop a note-bearing key or extra word, even after a base.
        bases = {"healthy", "t2d", "type-2-diabetes", "diabetes"}
        if (set(kw) - {"age", "sex", "conditions", "genome", "lifestyle"}
                or pos and (len(pos) != 1 or pos[0] not in bases or kw)):
            clinical_note_gate()
        if pos:
            result = P.patient(base=("healthy" if pos[0] == "healthy" else "type-2-diabetes"))
        else:
            # Match the SDK's existing conversions before it can mutate a twin.
            # Conversion exceptions embed their input, so replace them here.
            for field, convert, value in (
                ("age", int, kw.get("age") or 50),
                ("lifestyle", float, kw.get("lifestyle", 0.6)),
            ):
                try:
                    convert(value)
                except (TypeError, ValueError, OverflowError):
                    refuse_field(field, "a numeric value")
            conds = [c for c in str(kw.get("conditions", "")).split(",") if c] if kw.get("conditions") else []
            genome = {g: 1 for g in str(kw.get("genome", "")).split(",") if g} if kw.get("genome") else {}
            result = P.patient(age=kw.get("age"), sex=kw.get("sex", "F"), conditions=conds,
                               genome=genome, lifestyle=kw.get("lifestyle", 0.6))
        if getattr(P, "mode", None) == "attach":
            out("  ACKNOWLEDGED research-preview result; not a current registered-person selection read.")
        out(_fmt(result))
        if getattr(P, "mode", None) == "attach":
            metadata = getattr(P, "last_continuous_response", {})
            request_id = metadata.get("request_id")
            if type(request_id) is str and re.fullmatch(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", request_id):
                out(_fmt({"request_id": request_id}))
            for field, code in (("cleanup_code", "CLIENT_TRANSPORT"), ("audit_code", "CLIENT_AUDIT_UNCONFIRMED")):
                if metadata.get(field) == code:
                    out(f"  {code}: local response/receipt cleanup is unconfirmed; the server acknowledgment is retained. No request was repeated.")
        return

    if verb == "cohort":
        command = pos[0].lower() if pos else ""
        if command == "list":
            result = P.list_cohorts(**{k: kw[k] for k in ("limit", "cursor", "q") if k in kw})
            out(_fmt({"records": len(result.get("cohorts", []))}))
            for record in result.get("cohorts", []):
                if record.get("source_class") == "REAL_HUMAN":
                    eligibility = record.get("execution_eligibility", {})
                    out(_fmt({"cohort": record["cohort_id"], "source": "REAL_HUMAN", "members": record["size"],
                              "version": record.get("version"), "state": eligibility.get("state"), "reason": eligibility.get("reason_code")}))
                else:
                    out(f"  {record['cohort_id']} · {record['source_class']} · {record['size']} members · seed {record.get('seed', 'not applicable')}")
            out(_fmt(result.get("pagination", {})))
            return
        if command == "create":
            if "name" not in kw:
                out("  usage: cohort create name=<name> size=<n> [seed=] [indication=] [source=] [stratum=]"); return
            source_class = str(kw.get("source", "SYNTHETIC")).upper()
            payload = {
                "source_class": source_class,
                "name": str(kw["name"]),
                "size": int(kw.get("size", 50)),
                "seed": int(kw.get("seed", 0)),
                "indication": str(kw.get("indication", "unspecified")),
                "member_twin_ids": [],
            }
            if source_class == "REFERENCE_GROUNDED_SYNTHETIC":
                payload["stratum"] = str(kw.get("stratum", ""))
                payload["reference_source"] = {
                    "role": "population_reference",
                    "source_id": str(
                        kw.get("reference_source", "livemore-public-metabolic-reference-v1")
                    ),
                }
            key = str(kw.get("key") or f"shell-cohort-{payload['name']}-{payload['seed']}")
            record = P.register_cohort(payload, idempotency_key=key)
            out(_fmt({"cohort": record["cohort_id"], "size": record["size"],
                      "seed": record["seed"], "lifecycle": record["lifecycle"]}))
            return
        n = int(pos[0]) if pos else kw.get("n", 50)
        r = P.cohort(n, seed=kw.get("seed", 0))
        out(f"  cohort of {r['n']} (seed {r['seed']}) — e.g. " +
            ", ".join(f"{m['id']}({m['age']}{m['sex']})" for m in r["members"][:5]) +
            (" …" if r["truncated"] else ""))
        return

    if verb == "protocol":
        command = pos[0].lower() if pos else "latest"
        if command == "history":
            result = P.protocol_history(**{k: kw[k] for k in ("limit", "cursor", "q") if k in kw})
            for record in result.get("runs", []):
                out(_fmt({k: record.get(k) for k in ("run_id", "protocol_id", "created_at", "evidence_state")}))
            out(_fmt(result.get("pagination", {})))
            return result
        if command in {"prepare", "rerun"} and len(pos) >= 2:
            prepared = P.prepare_protocol_rerun(pos[1])
            if command == "prepare":
                out(json.dumps(prepared, indent=2))
                return prepared
            acknowledgement = str(kw.get("new_configuration", "false")).lower()
            if acknowledgement not in {"true", "false"}:
                raise ValueError("new_configuration must be true or false")
            result = P.execute_prepared_rerun(prepared, new_configuration=acknowledgement == "true")
        elif command == "show" and len(pos) >= 2:
            result = P.get_protocol(pos[1])
        elif command == "export" and len(pos) >= 2 and "notebook" in kw:
            import os
            payload = P.protocol_notebook(pos[1])
            descriptor = os.open(str(kw["notebook"]), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
                json.dump(payload, stream, allow_nan=False, indent=2)
            out("  Frozen analysis notebook exported. Execute its cells in Jupyter to inspect calculations.")
            return payload
        elif command in {"metabolic", "lobeline"} and len(pos) >= 2:
            from pathlib import Path
            path = Path(pos[1])
            if path.stat().st_size > MAX_JSON_BYTES:
                raise ValueError("protocol input file exceeds 2 MB")
            with path.open("rb") as stream:
                specification = parse_json_object(stream.read(MAX_JSON_BYTES + 1))
            result = (P.run_metabolic_protocol(specification) if command == "metabolic"
                      else P.run_lobeline_vmat2(specification))
        elif command == "metformin":
            if "cohort_a" not in kw or "cohort_b" not in kw:
                out("  usage: protocol metformin cohort_a=<id> cohort_b=<id> [dose_mg=1000] [grams=75]"); return
            result = P.run_metformin_cohorts(
                str(kw["cohort_a"]), str(kw["cohort_b"]),
                dose_mg=float(kw.get("dose_mg", 1000)), grams=float(kw.get("grams", 75)),
            )
        elif command in {"garcinoic", "garcinoic-pxr"}:
            if "cohort" not in kw:
                out("  usage: protocol garcinoic cohort=<id> [concentrations=0.05,0.33,1.3,5.0]"); return
            concentrations = [
                float(value.strip()) for value in str(kw.get("concentrations", "0.05,0.33,1.3,5.0")).split(",")
                if value.strip()
            ]
            result = P.run_garcinoic_pxr(str(kw["cohort"]), concentrations_um=concentrations)
        elif command == "latest":
            result = P.latest_protocol()
        else:
            out("  usage: protocol <metformin|garcinoic|metabolic|lobeline|history|latest|show|prepare|rerun|export>; see help"); return
        out(_fmt({"run": result.get("run_id"), "evidence": result.get("evidence_state"),
                  "qualification": result.get("qualification_state")}))
        if result.get("protocol_id") == "cendos.human-gem-oxygen-capacity.v1":
            out("  Steady-state reference-network capacity; no person or biological time axis.")
            out(_fmt({"unit": result.get("unit"), "model": result.get("model", {}).get("release"),
                      "model_sha256": result.get("model", {}).get("model_sha256")}))
            for condition in result.get("conditions", []) + result.get("controls", []):
                out(_fmt({"condition": condition.get("condition_id"), "ATP": condition.get("objective_flux"),
                          "glucose_uptake": condition.get("actual_glucose_uptake"),
                          "oxygen_uptake": condition.get("actual_oxygen_uptake"),
                          "solver": condition.get("solver_status"), "mass_residual": condition.get("mass_balance_residual"),
                          "bound_residual": condition.get("bound_residual"), "control_passed": condition.get("passed")}))
            if command == "show":
                out(json.dumps({"input": result.get("input"), "solver": result.get("solver"),
                                "parent_run_id": result.get("parent_run_id"),
                                "input_sha256": result.get("input_sha256")}, indent=2, allow_nan=False))
        elif result.get("protocol_id") == "cendos.lobeline-vmat2-initial-rate.v1":
            out("  Stationary nonhuman assay reference; not a time course or a human response.")
            out(_fmt({"unit": result.get("unit"), "source_sha256": result.get("source_sha256")}))
            for condition in result.get("conditions", []):
                out(_fmt({"condition": condition.get("condition_id"), "inhibitor_um": condition.get("inhibitor_um"),
                          "apparent_km_um": condition.get("apparent_km_um")}))
                for point in condition.get("points", []):
                    out(_fmt(point))
            out(json.dumps(result.get("benchmark_discrepancy"), indent=2, allow_nan=False))
            if command == "show":
                out(json.dumps({"input": result.get("input"), "source_record": result.get("source_record"),
                                "parent_run_id": result.get("parent_run_id"), "input_sha256": result.get("input_sha256")},
                               indent=2, allow_nan=False))
        return result

    if verb == "perturb":
        if pos:
            out(_fmt(P.perturb(compound=pos[0], dose=kw.get("dose", 1.0))))
        else:
            kind = kw.pop("kind", None)
            out(_fmt(P.perturb(kind=kind, **kw)))
        return

    if verb == "assay":
        a = P.assay_ogtt(pos[0] if pos else "metformin", dose=kw.get("dose", 1.0), grams=kw.get("grams", 75.0))
        out(f"  assay {a.get('intervention')} on {a.get('subject')} · {a['decision']} · "
            f"Δmean {a['delta_mean']} · ΔiAUC {a['delta_iAUC']} · integrity {a['audit_id'][:8]}")
        return

    if verb == "screen":
        effect_kwargs = {name: kw[name] for name in
                         ("si_boost", "gb_drop", "gamma_boost") if name in kw}
        r = P.screen(pos[0] if pos else "metformin", mode=kw.get("mode", "auto"),
                     dose=kw.get("dose", 1.0), n=kw.get("n"), seed=kw.get("seed", 0),
                     grams=kw.get("grams", 75.0), indication="type-2-diabetes",
                     cohort="t2d-enriched", assay="ogtt", **effect_kwargs)
        P._last_screen = r
        out(_fmt_screen(r))
        return

    if verb == "show":
        if pos and pos[0] == "workspace":
            workspace = P.workspace()
            unavailable = _unavailable_summary(workspace)
            if unavailable is not None:
                out(_fmt(unavailable))
                return
            systems = workspace["multiscale"]["systems"]
            executed = sum(item["execution_status"] in {"EXECUTED", "PARTIAL"} for item in systems)
            active = workspace["multiscale"]["active_execution"]
            out(_fmt({"subject": workspace["multiscale"]["subject"]["id"],
                      "contracts": len(systems), "executed": executed,
                      "intervention": active["intervention"],
                      "nodes": len(active["nodes"]), "edges": len(active["edges"])}))
            return
        st = P.state()
        out(_fmt(_unavailable_summary(st) or {"profile": st["profile"], "mean_glucose": st["mean_glucose"],
                  "hr_bpm": st["hr_bpm"], "hrv_ms": st["hrv_ms"]}))
        return

    if verb == "action":
        name = pos[0].lower() if pos else ""
        if name in ("metformin", "drug"):
            result = P.workspace_action("metabolic_drug", name="metformin", dose=kw.get("dose", 1.0))
        elif name == "meal":
            result = P.workspace_action("meal", grams=kw.get("grams", 60.0), minute=kw.get("minute", 0))
        elif name in ("cardiac", "ikr"):
            result = P.workspace_action("cardiac_drug", ikr_block=kw.get("ikr_block", 0.5))
        elif name == "reset":
            result = P.workspace_action("reset")
        else:
            out("  usage: action <metformin|meal|cardiac|reset> [dose=|grams=|ikr_block=]")
            return
        action = result["action"]
        out(_fmt({"action": action["kind"], "status": action["status"],
                  "lifecycle": "->".join(action["transitions"])}))
        return

    if verb == "patch" and pos and pos[0] == "sample":
        result = P.virtual_patch_sample()
        signals = result["reconciliation"]["signals"]
        out(_fmt({"patch": result["patch"]["mode"], "signals": len(signals),
                  "calibration_authorized": result["reconciliation"]["calibration_authorized"]}))
        return

    if verb == "sources":
        report = P.scientific_sources(
            workflow=kw.get("workflow"),
            collection=kw.get("collection"),
            lifecycle=kw.get("lifecycle"),
            limit=int(kw.get("limit", 50)),
            offset=int(kw.get("offset", 0)),
        )
        query = report["query"]
        out(_fmt({
            "workflow": query.get("workflow") or "all",
            "collection": query.get("collection") or "all",
            "total": report["total"],
            "shown": len(report["sources"]),
        }))
        for source in report["sources"]:
            out(
                f"  {source['name']} · {source['lifecycle']} · "
                f"{source['collection']} · {source['permitted_use']}"
            )
        return

    if verb == "report":
        r = getattr(P, "_last_screen", None)
        if not r:
            out("  no screen to report — run `screen <compound>` first"); return
        paths = report.write_report(r, pos[0] if pos else "livemore-screen-report.md")
        out(f"  wrote {paths['report']}\n        {paths['audit_record']}")
        return

    if verb == "pipeline":
        if not pos:
            out("  usage: pipeline <file>"); return
        run_pipeline(P, pos[0], out); return

    if verb == "audit" and pos and pos[0] == "verify":
        if len(pos) < 2:
            out("  usage: audit verify <record.json>"); return
        try:
            with open(pos[1], encoding="utf-8") as f:
                rec = json.load(f)
            ok = audit.verify(rec)
            out(f"  {'VALID — reproduces + untampered' if ok else 'INVALID — verification failed'} "
                f"· {rec.get('result_sha256', '')[:16]}…")
        except Exception as e:
            out(f"  cannot read record: {e}")
        return

    out("  unknown command (try `help`)")


def service_refusal(error) -> str:
    """Render a service's typed refusal for the operator.

    Only the fixed code and message from a JSON body are shown. A non-JSON body
    is never echoed: an error page may contain anything, and this transcript is
    read by a person who trusts it.
    """
    code = message = None
    try:
        payload = json.loads(error.read().decode("utf-8", errors="replace"))
        if isinstance(payload, dict):
            candidate = payload.get("code")
            text = payload.get("error") or payload.get("detail")
            code = candidate if isinstance(candidate, str) and len(candidate) <= 64 else None
            message = text if isinstance(text, str) and len(text) <= 512 else None
    except Exception:
        pass
    return f"  refused [{code or f'HTTP {error.code}'}]" + (f": {message}" if message else "")


def run_pipeline(P, path, out=print):
    try:
        with open(path, encoding="utf-8") as f:
            lines = f.readlines()
    except Exception as e:
        out(f"  cannot open pipeline: {e}"); return
    for line in lines:
        if line.strip() and not line.strip().startswith("#"):
            family = "patient" if _patient_line(line) else _clinical_family(line)
            try:
                shlex.split(line)
                echo = family or _command_words(line) or "unrecognized command"
            except ValueError:
                echo = family or "invalid command (arguments withheld)"
            out(f"livemore› {echo}")
        try:
            run_command(P, line, out)
        except urllib.error.HTTPError as error:
            # The service answering "no" is an outcome, not a crash. A pipeline
            # reports it and stops, rather than raising urllib's traceback.
            out(service_refusal(error))
            return
        except ClinicalNoteRefused as error:
            out(refusal_line(error))
            return


_VERBS = ("help", "quit", "exit", "mode", "models", "program", "insulin", "protocol", "cohort", "twin",
          "patient", "perturb", "assay", "screen", "show", "research", "execution", "patch", "atlas",
          "report", "pipeline", "audit", "action", "sources")


def _enable_line_editing():
    """Persistent history and verb completion; silently absent where readline is unavailable.

    Returns the function that adds a line to the history, or None. Lines are no
    longer added as they are typed: the shell adds recognized commands itself,
    never a ``patient`` line. LIVEMORE_SHELL_HISTORY=0 disables history I/O.
    """
    try:
        import atexit
        import os
        import readline
        from . import registry
    except ImportError:
        return None
    if not hasattr(readline, "set_auto_history"):
        # Without control of what is added, no history is kept at all.
        return None
    readline.set_auto_history(False)
    readline.clear_history()
    if os.environ.get("LIVEMORE_SHELL_HISTORY") == "0":
        return None
    history = os.path.join(registry.REG_DIR, "shell_history")
    try:
        registry.ensure_data_dir()
        readline.read_history_file(history)
    except OSError:
        pass
    # Old releases recorded unknown lines. Do not make those lines available
    # through readline or copy them into the next saved history.
    retained = [readline.get_history_item(index)
                for index in range(1, readline.get_current_history_length() + 1)]
    readline.clear_history()
    for line in retained:
        if line and _command_words(line) is not None and not _patient_line(line):
            readline.add_history(line)
    readline.set_history_length(2000)

    def complete(text, state):
        buffer = readline.get_line_buffer().lstrip()
        if " " in buffer:
            return None
        matches = [verb + " " for verb in _VERBS if verb.startswith(text)]
        return matches[state] if state < len(matches) else None

    readline.set_completer(complete)
    binding = "bind ^I rl_complete" if "libedit" in (readline.__doc__ or "") else "tab: complete"
    readline.parse_and_bind(binding)

    def save() -> None:
        try:
            readline.write_history_file(history)
            os.chmod(history, 0o600)
        except OSError:
            pass
    atexit.register(save)
    return readline.add_history


def run_shell(mode="inprocess"):
    P = Platform(mode=mode)
    remember = _enable_line_editing()
    print(BANNER)
    try:
        state = P.state()
    except ContinuousClientError as error:
        if error.code != "SELECTION_COMMIT_UNCONFIRMED":
            raise
        print(safe_error(error))
        print("  Selection recovery mode. Inspect `twin list`; explicitly use `twin reconcile-selection`. No selection was repeated.\n")
    else:
        unavailable = _unavailable_summary(state)
        if unavailable is not None:
            print(f"  mode: {mode}\n{_fmt(unavailable)}\n")
        else:
            print(f"  mode: {mode} · active twin: {state['profile']}\n")
    while True:
        try:
            line = input("livemore› ")
        except (EOFError, KeyboardInterrupt):
            print("\n  bye"); break
        try:
            result = run_command(P, line)
        except ClinicalNoteRefused as error:
            print(refusal_line(error))
            continue
        except urllib.error.HTTPError as error:
            print(service_refusal(error))
            continue
        except AtlasClientError as error:
            print(safe_atlas_error(error))
            continue
        except ContinuousClientError as error:
            print(safe_error(error))
            if _patient_line(line):
                print("  Inspect `show state` and `twin list`; if selection remains unconfirmed, explicitly use `twin reconcile-selection`. Inspect prior execution cleanup separately; no preview was repeated.")
            continue
        if remember is not None and _command_words(line) is not None and not _patient_line(line):
            remember(line)
        if result == "QUIT":
            print("  bye"); break
