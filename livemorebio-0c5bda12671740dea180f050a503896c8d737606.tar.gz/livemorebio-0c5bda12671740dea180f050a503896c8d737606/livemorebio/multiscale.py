"""Executable multiscale contracts and state projection.

This module is the shared boundary between the scientific engines and every
presentation surface.  It does not implement substitute physiology.  It
describes every registered system, executes only engines that exist, and emits
an explicit unavailable state for the rest.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import math
from typing import Any, Mapping

from .engines.coupling.labels import coupling_label


class FunctionalContractError(ValueError):
    """Raised when a functional module would emit an invalid state."""


@dataclass(frozen=True)
class VariableSpec:
    id: str
    unit: str
    description: str
    observation_signal: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "unit": self.unit,
            "description": self.description,
            "value_type": "number",
            "observation_signal": self.observation_signal,
        }


_SYSTEM_VARIABLES: dict[str, tuple[VariableSpec, ...]] = {
    "integumentary": (
        VariableSpec("surface_temperature", "Cel", "skin-surface temperature", "skin_temp_c"),
        VariableSpec("sweat_rate", "mg/cm2/min", "local sweat mass flux"),
    ),
    "skeletal": (
        VariableSpec("bone_mineral_density", "g/cm2", "areal bone mineral density"),
        VariableSpec("joint_load", "N", "resultant joint load"),
    ),
    "muscular": (
        VariableSpec("muscle_force", "N", "resultant muscle force"),
        VariableSpec("activation", "1", "normalized motor-unit activation"),
    ),
    "nervous": (
        VariableSpec("membrane_voltage", "mV", "neural membrane potential"),
        VariableSpec("firing_rate", "Hz", "neural firing frequency"),
    ),
    "special_senses": (
        VariableSpec("receptor_potential", "mV", "sensory receptor potential"),
        VariableSpec("stimulus_intensity", "1", "modality-normalized stimulus intensity"),
    ),
    "endocrine": (
        VariableSpec("glucose", "mg/dL", "circulating glucose concentration", "glucose_mgdl"),
        VariableSpec("insulin", "uU/mL", "circulating insulin concentration"),
        VariableSpec("beta_cell_responsivity", "1", "Bergman beta-cell responsivity parameter"),
    ),
    "cardiovascular": (
        VariableSpec("heart_rate", "bpm", "cardiac rate", "hr_bpm"),
        VariableSpec("heart_rate_variability", "ms", "RMSSD heart-rate variability", "hrv_ms"),
        VariableSpec("ventricular_apd90", "ms", "ventricular action-potential duration at 90 percent repolarization"),
    ),
    "blood_hematopoietic": (
        VariableSpec("hemoglobin", "g/dL", "blood hemoglobin concentration"),
        VariableSpec("oxygen_saturation", "%", "arterial oxygen saturation", "spo2_pct"),
    ),
    "lymphatic_immune": (
        VariableSpec("cytokine_concentration", "pg/mL", "declared cytokine concentration"),
        VariableSpec("lymph_flow", "mL/min", "regional lymph flow"),
    ),
    "respiratory": (
        VariableSpec("respiratory_rate", "1/min", "respiratory frequency"),
        VariableSpec("oxygen_saturation", "%", "arterial oxygen saturation", "spo2_pct"),
    ),
    "digestive_hepatobiliary": (
        VariableSpec("hepatic_glucose_set_point", "mg/dL", "Bergman hepatic glucose-output set point"),
        VariableSpec("drug_auc", "mg.h/L", "systemic drug area under the concentration-time curve"),
    ),
    "urinary": (
        VariableSpec("glomerular_filtration_rate", "mL/min/1.73m2", "estimated glomerular filtration rate"),
        VariableSpec("renal_clearance_factor", "1", "normalized renal clearance factor"),
    ),
    "reproductive": (
        VariableSpec("gonadal_hormone_concentration", "pg/mL", "declared gonadal hormone concentration"),
        VariableSpec("cycle_phase", "1", "encoded reproductive cycle phase"),
    ),
    "microbiome": (
        VariableSpec("taxon_relative_abundance", "1", "relative abundance of a declared taxon"),
        VariableSpec("community_metabolic_flux", "mmol/gDW/h", "community metabolic flux"),
    ),
    "interstitial_fascial": (
        VariableSpec("interstitial_pressure", "mm[Hg]", "regional interstitial pressure"),
        VariableSpec("matrix_stiffness", "kPa", "regional extracellular-matrix stiffness"),
    ),
}


_TIME_SCALES: dict[str, tuple[str, ...]] = {
    "integumentary": ("seconds", "days"),
    "skeletal": ("milliseconds", "years"),
    "muscular": ("milliseconds", "months"),
    "nervous": ("milliseconds", "years"),
    "special_senses": ("milliseconds", "years"),
    "endocrine": ("seconds", "months"),
    "cardiovascular": ("milliseconds", "years"),
    "blood_hematopoietic": ("seconds", "months"),
    "lymphatic_immune": ("seconds", "years"),
    "respiratory": ("milliseconds", "years"),
    "digestive_hepatobiliary": ("seconds", "months"),
    "urinary": ("seconds", "years"),
    "reproductive": ("seconds", "years"),
    "microbiome": ("minutes", "years"),
    "interstitial_fascial": ("milliseconds", "years"),
}


_MODULE_IO: dict[str, tuple[tuple[str, ...], tuple[str, ...]]] = {
    "cardiovascular": (("metabolic_state", "autonomic_tone", "drug_channel_block"),
                       ("heart_rate", "hrv", "ventricular_electrophysiology")),
    "endocrine": (("meal_glucose", "insulin_sensitivity", "beta_cell_responsivity"),
                  ("glucose_trajectory", "insulin_trajectory", "glycemic_exposure")),
    "digestive_hepatobiliary": (("oral_dose", "genotype", "renal_clearance_factor"),
                                ("drug_exposure", "hepatic_effect_site_exposure")),
}


def _io(system_id: str) -> tuple[tuple[str, ...], tuple[str, ...]]:
    return _MODULE_IO.get(
        system_id,
        (("connected_module_state", "person_parameters", "perturbations"),
         ("system_state", "connected_module_inputs", "observation_predictions")),
    )


def whole_body_contracts() -> list[dict[str, Any]]:
    """Return one formal contract for every ontology system.

    A contract is architectural, not a maturity claim.  State values are
    emitted separately only when an engine is executed.
    """
    from .anatomy import load_ontology
    from .foundation import whole_human_manifest

    ontology = load_ontology()
    manifest = {item["id"]: item for item in whole_human_manifest()["systems"]}
    contracts: list[dict[str, Any]] = []
    for system_id, system in ontology.systems.items():
        variables = _SYSTEM_VARIABLES.get(system_id)
        if not variables:
            raise FunctionalContractError(f"missing state-variable contract for {system_id}")
        inputs, outputs = _io(system_id)
        capability = manifest[system_id]
        contracts.append({
            "schema": "livemore.functional-module-contract.v1",
            "module_id": f"human.{system_id}",
            "system_id": system_id,
            "name": system["name"],
            "biological_scales": [
                "gene_variant", "rna_protein", "molecular_reaction", "cell",
                "tissue", "organ", "system", "whole_body",
            ],
            "anatomy": {
                "structures": [item["id"] for item in system["structures"]],
                "ontology_basis": capability["ontology"]["reference_basis_id"],
            },
            "state_variables": [item.to_dict() for item in variables],
            "inputs": list(inputs),
            "outputs": list(outputs),
            "time_scales": list(_TIME_SCALES[system_id]),
            "person_parameters": ["age", "sex", "genome", "conditions", "lifestyle"],
            "observation_mappings": [
                {"signal": item.observation_signal, "variable": item.id, "unit": item.unit}
                for item in variables if item.observation_signal
            ],
            "perturbations": ["drug", "gene", "nutrition", "disease", "lifestyle", "environment"],
            "applicability": {
                "claim_state": capability["functional_claim"],
                "maturity": deepcopy(capability["maturity"]),
                "refusal_reason": capability["refusal_reason"],
            },
            "models": deepcopy(capability["models"]),
            "uncertainty": {
                "required": True,
                "current_status": "model_specific_not_population_qualified",
            },
        })
    return contracts


def _finite(value: Any, label: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as error:
        raise FunctionalContractError(f"{label} must be numeric") from error
    if not math.isfinite(number):
        raise FunctionalContractError(f"{label} must be finite")
    return number


def _system_execution(twin_state: Mapping[str, Any], contract: Mapping[str, Any]) -> dict[str, Any]:
    system_id = str(contract["system_id"])
    if system_id == "cardiovascular":
        cardiac = twin_state["cardiac"]
        if cardiac.get("reason_code"):
            return {
                "execution_status": "PARTIAL",
                "state": {
                    "heart_rate": {"value": cardiac["hr_bpm"], "unit": "bpm"},
                    "heart_rate_variability": {"value": cardiac["hrv_ms"], "unit": "ms"},
                },
                "engine_ids": ["livemore-heart-rate"],
                "unavailable_reason": cardiac["reason_code"],
            }
        return {
            "execution_status": "EXECUTED",
            "state": {
                "heart_rate": {"value": cardiac["hr_bpm"], "unit": "bpm"},
                "heart_rate_variability": {"value": cardiac["hrv_ms"], "unit": "ms"},
                "ventricular_apd90": {"value": cardiac["apd90_ms"], "unit": "ms", **coupling_label("value")},
            },
            "engine_ids": ["ohara-rudy-cipa-2017", "livemore-heart-rate"],
            "unavailable_reason": None,
        }
    if system_id == "endocrine":
        metabolic = twin_state["metabolic"]
        params = twin_state["profile_params"]
        insulin_values = metabolic["insulin"]
        mean_insulin = sum(insulin_values) / len(insulin_values) if insulin_values else 0.0
        return {
            "execution_status": "EXECUTED",
            "state": {
                "glucose": {"value": metabolic["mean_glucose"], "unit": "mg/dL"},
                "insulin": {"value": round(mean_insulin, 4), "unit": "uU/mL"},
                "beta_cell_responsivity": {"value": params["gamma"], "unit": "1"},
            },
            "engine_ids": ["bergman-glucose-insulin"],
            "unavailable_reason": None,
        }
    if system_id == "digestive_hepatobiliary" and twin_state.get("hepatic"):
        hepatic = twin_state["hepatic"]
        return {
            "execution_status": "PARTIAL",
            "state": {
                "hepatic_glucose_set_point": {
                    "value": twin_state["profile_params"]["Gb"], "unit": "mg/dL",
                },
                "drug_auc": {"value": hepatic["auc_mg_h_L"], "unit": "mg.h/L"},
            },
            "engine_ids": ["oral-one-compartment-hepatic-pk"],
            "unavailable_reason": "drug_exposure_component_only_not_full_hepatic_system",
        }
    return {
        "execution_status": "UNAVAILABLE",
        "state": {},
        "engine_ids": [],
        "unavailable_reason": "no_executable_system_model_in_current_release",
    }


def _node(
    node_id: str,
    scale: str,
    label: str,
    value: Any,
    unit: str,
    engine: str,
    evidence_state: str = "MODELED",
    *,
    coupled: bool = False,
) -> dict[str, Any]:
    return {
        "id": node_id,
        "scale": scale,
        "label": label,
        "value": _finite(value, node_id),
        "unit": unit,
        "engine": engine,
        "evidence_state": evidence_state,
        # L0-R15: a node whose value the unsourced glucose-to-IKr coupling changes says so.
        **(coupling_label("value") if coupled else {}),
    }


def _active_execution(twin_state: Mapping[str, Any]) -> dict[str, Any]:
    cardiac = twin_state["cardiac"]
    metabolic = twin_state["metabolic"]
    profile = twin_state["profile_params"]
    human = twin_state.get("human") or {}
    genome = human.get("genome") or {}
    hepatic = twin_state.get("hepatic")
    intervention = twin_state.get("intervention") or {}
    intervention_name = str(intervention.get("drug") or "baseline")

    ventricular_nodes = [] if cardiac.get("reason_code") else [
        _node("channel.ikr", "ion_channel", "rapid delayed-rectifier potassium current block",
              cardiac["ikr_block"], "1", "ohara-rudy-cipa-2017", coupled=True),
        _node("cell.cardiomyocyte", "cell", "cardiomyocyte calcium peak",
              cardiac["cai_peak_uM"], "umol/L", "ohara-rudy-cipa-2017", coupled=True),
        _node("tissue.ventricular", "tissue", "ventricular APD90",
              cardiac["apd90_ms"], "ms", "ohara-rudy-cipa-2017", coupled=True),
    ]
    nodes = ventricular_nodes + [
        _node("organ.heart", "organ", "heart rate",
              cardiac["hr_bpm"], "bpm", "livemore-heart-rate"),
        _node("system.endocrine", "system", "mean glucose",
              metabolic["mean_glucose"], "mg/dL", "bergman-glucose-insulin"),
        _node("system.cardiovascular", "system", "heart-rate variability",
              cardiac["hrv_ms"], "ms", "livemore-heart-rate"),
        _node("whole_body.homeostasis", "whole_body", "systemic glucose exposure",
              metabolic["mean_glucose"], "mg/dL", "bergman-glucose-insulin"),
    ]
    edges = [
        {"source": "channel.ikr", "target": "cell.cardiomyocyte",
         "mechanism": "ikr_repolarization_current_shapes_action_potential",
         "engine": "ohara-rudy-cipa-2017", "claim_state": "MODELED"},
        {"source": "system.endocrine", "target": "cell.cardiomyocyte",
         "mechanism": "bounded_hyperglycemia_to_ikr_coupling",
         "engine": "metabolic-cardiac-coupling", "claim_state": "HYPOTHESIS_UNSOURCED",
         "limitation": ("Direction is documented in the literature; the magnitude of this slope has no "
                        "admitted source and is not fitted to any measurement. Treat the coupled cardiac "
                        "readout as a hypothesis, not a modelled prediction.")},
        {"source": "cell.cardiomyocyte", "target": "tissue.ventricular",
         "mechanism": "cellular_action_potential_to_ventricular_readout",
         "engine": "ohara-rudy-cipa-2017", "claim_state": "MODELED"},
        {"source": "tissue.ventricular", "target": "organ.heart",
         "mechanism": "pacing_cycle_to_organ_rate",
         "engine": "livemore-heart-rate", "claim_state": "MODELED"},
        {"source": "organ.heart", "target": "system.cardiovascular",
         "mechanism": "rate_and_variability_projection",
         "engine": "livemore-heart-rate", "claim_state": "MODELED"},
        {"source": "system.endocrine", "target": "whole_body.homeostasis",
         "mechanism": "glucose_insulin_systemic_exposure",
         "engine": "bergman-glucose-insulin", "claim_state": "MODELED"},
    ]

    admitted_nodes = {node["id"] for node in nodes}
    edges = [edge for edge in edges
             if edge["source"] in admitted_nodes and edge["target"] in admitted_nodes]

    summary: dict[str, Any] = {
        "intervention": intervention_name,
        "mean_glucose_mg_dL": metabolic["mean_glucose"],
        "heart_rate_bpm": cardiac["hr_bpm"],
        "apd90_ms": cardiac["apd90_ms"],
        "hepatic_exposure_ratio": None,
        **(coupling_label("apd90_ms") if cardiac["apd90_ms"] is not None else {}),
    }
    if hepatic and hepatic.get("drug") == "metformin":
        individualization = hepatic["individualization"]
        oct1 = int(individualization["oct1_lof_alleles"])
        nodes.extend([
            _node("gene.slc22a1", "gene_variant", "SLC22A1 reduced-function alleles",
                  oct1, "1", "person-genome", "OBSERVED_OR_SYNTHETIC_PROFILE"),
            _node("protein.oct1", "rna_protein", "OCT1 transport activity",
                  individualization["oct1_transport"], "1", "hepatic-pk"),
            _node("molecule.metformin_exposure", "molecular_reaction", "metformin hepatic exposure",
                  hepatic["hepatic_exposure_ratio"], "1", "hepatic-pk"),
            _node("cell.hepatocyte", "cell", "hepatocyte glucose-output set point",
                  profile["Gb"], "mg/dL", "metformin-pharmacology"),
            _node("organ.liver", "organ", "hepatic glucose-output set point",
                  profile["Gb"], "mg/dL", "bergman-glucose-insulin"),
        ])
        edges.extend([
            {"source": "gene.slc22a1", "target": "protein.oct1",
             "mechanism": "genotype_to_transporter_function", "engine": "hepatic-pk",
             "claim_state": "MODELED"},
            {"source": "protein.oct1", "target": "molecule.metformin_exposure",
             "mechanism": "hepatic_uptake_gates_effect_site_exposure", "engine": "hepatic-pk",
             "claim_state": "MODELED"},
            {"source": "molecule.metformin_exposure", "target": "cell.hepatocyte",
             "mechanism": "exposure_to_hepatic_glucose_output_parameter", "engine": "metformin-pharmacology",
             "claim_state": "MODELED"},
            {"source": "cell.hepatocyte", "target": "organ.liver",
             "mechanism": "hepatocyte_to_organ_parameter_projection", "engine": "bergman-glucose-insulin",
             "claim_state": "MODELED"},
            {"source": "organ.liver", "target": "system.endocrine",
             "mechanism": "hepatic_output_to_glucose_insulin_dynamics", "engine": "bergman-glucose-insulin",
             "claim_state": "MODELED"},
        ])
        summary["hepatic_exposure_ratio"] = hepatic["hepatic_exposure_ratio"]

    return {
        "execution_id": "current-twin-cardio-metabolic",
        "intervention": intervention_name,
        "nodes": nodes,
        "edges": edges,
        "summary": summary,
        "applicability": {
            "claim_state": "MODELED",
            "context": "cardiovascular_metabolic_hypothesis_triage",
            "person_calibrated": False,
            "context_validated": False,
            "limitations": [
                "literature-typical parameters are not fitted to this person",
                "metabolic-cardiac coupling magnitude is not cohort-qualified",
                "RNA expression and full tissue mechanics are not executed in this slice",
            ],
        },
    }


def _summary_from_state(state: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "mean_glucose_mg_dL": state["metabolic"]["mean_glucose"],
        "glucose": list(state["metabolic"]["glucose"]),
        "insulin": list(state["metabolic"]["insulin"]),
        "t_min": list(state["metabolic"]["t_min"]),
        "heart_rate_bpm": state["cardiac"]["hr_bpm"],
        "hrv_ms": state["cardiac"]["hrv_ms"],
        "apd90_ms": state["cardiac"]["apd90_ms"],
        **(coupling_label("apd90_ms") if state["cardiac"]["apd90_ms"] is not None else {}),
    }


def multiscale_state(twin: Any) -> dict[str, Any]:
    """Project the current twin into the executable multiscale contract."""
    state = twin.state()
    contracts = whole_body_contracts()
    systems = []
    for contract in contracts:
        execution = _system_execution(state, contract)
        systems.append({
            "system_id": contract["system_id"],
            "name": contract["name"],
            "contract": contract,
            **execution,
        })
    comparison = deepcopy(getattr(twin, "comparison", None))
    if not comparison:
        current = _summary_from_state(state)
        comparison = {"intervention": "none", "baseline": current, "treated": deepcopy(current)}
    return {
        "schema": "livemore.multiscale-state.v1",
        "subject": {
            "id": (state.get("human") or {}).get("id") or state["profile"],
            "profile": state["profile"],
            "person_specific": state.get("human") is not None,
        },
        "biological_time": {
            "axes": [
                # L0-R15 round 1: the cardiac samples' times come from the adaptive solver,
                # so the coupling moves them; an empty axis (no cardiac file) has no label.
                {"id": "cardiac", "unit": "ms", "values": list(state["cardiac"]["t_ms"]),
                 **(coupling_label("values") if state["cardiac"]["t_ms"] else {})},
                {"id": "metabolic", "unit": "min", "values": list(state["metabolic"]["t_min"])},
            ],
            "rule": "each engine retains its native biological time scale",
        },
        "hierarchy": [
            "Whole Body", "Cardiovascular", "Heart", "Ventricular Tissue",
            "Cardiomyocyte", "Ion Channel", "Gene / Protein",
        ],
        "systems": systems,
        "active_execution": _active_execution(state),
        "comparison": comparison,
        "patch_reconciliation": reconcile_patch(twin),
    }


_PREDICTION_MAP: dict[str, tuple[str, str]] = {
    "glucose_mgdl": ("mg/dL", "mean_glucose"),
    "hr_bpm": ("bpm", "hr_bpm"),
    "hrv_ms": ("ms", "hrv_ms"),
}


def reconcile_observations(
    twin: Any, observations: Mapping[str, Mapping[str, Any]], *,
    predictions: Mapping[str, Any] | None = None, mappings: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Reconcile only explicitly bound frozen predictions; never the current mean.

    The twin argument is retained for existing callers, but its mutable state is
    deliberately not read. No physical transfer mapping is released in this version.
    """
    from .life_patch.alignment import align_observation

    predictions, mappings = predictions or {}, mappings or {}
    rows: list[dict[str, Any]] = []
    for signal, observation in observations.items():
        expected = _PREDICTION_MAP.get(signal)
        base = {
            "signal": signal,
            "observed": observation.get("value"),
            "observed_unit": observation.get("unit"),
            "predicted": None,
            "predicted_unit": expected[0] if expected else None,
            "residual": None,
            "normalized_residual": None,
            "tolerance": None,
            "envelope_id": observation.get("envelope_id"),
            "source_hash": observation.get("source_hash") or observation.get("envelope_hash"),
            "status": "NO_VIRTUAL_OBSERVATION_MODEL",
            "reason": "no executable observation mapping for this signal",
        }
        if expected is None:
            rows.append(base)
            continue
        if observation.get("unit") != expected[0]:
            base.update(status="UNIT_MISMATCH", reason="observed and predicted units differ")
            rows.append(base)
            continue
        quality = str(observation.get("quality_status", "not_assessed"))
        calibration = str(observation.get("calibration_status", "not_assessed"))
        if quality in {"reject", "fail"} or calibration in {"failed", "fail"}:
            base.update(status="FAILED_QUALITY_GATE", reason="observation quality or calibration failed")
            rows.append(base)
            continue
        context = observation.get("model_context") or {}
        if not isinstance(context, Mapping):
            context = {}
        prediction_id, mapping_id = context.get("prediction_id"), context.get("mapping_id")
        prediction = predictions.get(prediction_id) if isinstance(prediction_id, str) else None
        mapping = mappings.get(mapping_id) if isinstance(mapping_id, str) else None
        base.update(align_observation(prediction, observation, mapping))
        rows.append(base)
    return {
        "schema": "livemore.life-patch-reconciliation.v2",
        "signals": rows,
        "model_parameters_updated": False,
        "calibration_authorized": False,
        "next_gate": "evidence_review_with_endpoint_specific_tolerance",
    }


def reconcile_patch(twin: Any) -> dict[str, Any]:
    return reconcile_observations(twin, getattr(twin, "observations", {}))


__all__ = [
    "FunctionalContractError",
    "VariableSpec",
    "multiscale_state",
    "reconcile_observations",
    "reconcile_patch",
    "whole_body_contracts",
]
