"""Pure, local admission of service-identity authorities.

These origins are proof audiences from trusted launch configuration. They never
come from a request header, a discovery response, or a DNS lookup.
"""
from __future__ import annotations

from dataclasses import dataclass
import ipaddress
import re
from typing import Mapping
from urllib.parse import urlsplit


class ServiceIdentityConfigurationInvalid(ValueError):
    """A launch profile cannot name the intended service unambiguously."""

    code = "SERVICE_IDENTITY_CONFIGURATION_INVALID"

    def __init__(self, detail: str) -> None:
        super().__init__(f"{self.code}: {detail}")


def _invalid(detail: str = "Configure a canonical HTTP or HTTPS origin with an explicit port.") -> ServiceIdentityConfigurationInvalid:
    return ServiceIdentityConfigurationInvalid(detail)


def _plain_ascii(value: object) -> str:
    if not isinstance(value, str) or not value:
        raise _invalid()
    if any(ord(character) < 33 or ord(character) > 126 for character in value):
        raise _invalid()
    return value


def _host(value: str) -> str:
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        # Numeric legacy IPv4 spellings must not be mistaken for DNS names.
        if re.fullmatch(r"[0-9.]+", value) or len(value) > 253:
            raise _invalid() from None
        labels = value.split(".")
        if any(not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label) for label in labels):
            raise _invalid() from None
        return value
    if "%" in value:
        raise _invalid()
    if isinstance(address, ipaddress.IPv6Address):
        # Python versions differ on mixed IPv4/IPv6 spellings. Keep the proof
        # audience's bytes stable by always rendering eight hexadecimal groups
        # with RFC 5952's first longest zero run compressed.
        groups = [format((int(address) >> shift) & 0xFFFF, "x") for shift in range(112, -1, -16)]
        best_start, best_size = 0, 0
        start = 0
        while start < 8:
            end = start
            while end < 8 and groups[end] == "0":
                end += 1
            if end - start > best_size:
                best_start, best_size = start, end - start
            start = max(start + 1, end)
        if best_size >= 2:
            return ":".join(groups[:best_start]) + "::" + ":".join(groups[best_start + best_size:])
        return ":".join(groups)
    return address.compressed


def _port(value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 65535:
        raise _invalid("The bind or dial port must be an integer from 1 through 65535.")
    return value


@dataclass(frozen=True)
class CanonicalOrigin:
    scheme: str
    host: str
    port: int

    def __post_init__(self) -> None:
        if self.scheme not in {"http", "https"}:
            raise _invalid()
        if _host(_plain_ascii(self.host)) != self.host:
            raise _invalid()
        _port(self.port)
        if len(self.origin) > 255:
            raise _invalid()

    @property
    def origin(self) -> str:
        host = f"[{self.host}]" if ":" in self.host else self.host
        return f"{self.scheme}://{host}:{self.port}"

    @property
    def is_loopback(self) -> bool:
        try:
            address = ipaddress.ip_address(self.host)
            if isinstance(address, ipaddress.IPv6Address) and address.ipv4_mapped is not None:
                return address.ipv4_mapped.is_loopback
            return address.is_loopback
        except ValueError:
            return False

    @classmethod
    def parse(cls, value: str) -> CanonicalOrigin:
        text = _plain_ascii(value)
        if len(text) > 255:
            raise _invalid()
        match = re.fullmatch(r"(https?)://(\[[0-9a-f:.]+\]|[a-z0-9.-]+):([1-9][0-9]{0,4})", text)
        if match is None:
            raise _invalid()
        scheme, host, port = match.groups()
        unbracketed = host[1:-1] if host.startswith("[") else host
        origin = cls(scheme, unbracketed, int(port))
        if origin.origin != text or (host.startswith("[") and ":" not in unbracketed):
            raise _invalid()
        return origin


def canonical_authority(value: str) -> str:
    """Admit an already canonical, bounded ASCII proof authority."""
    return CanonicalOrigin.parse(value).origin


def is_compose_service_dial(dial_url: str, *, role: str, configured_authority: str | None) -> bool:
    """Admit only the fixed internal peer and its explicit published audience.

    This is the Compose launch profile's narrow exception to a client's native
    loopback restriction. It never admits arbitrary plaintext named hosts.
    """
    ports = {"aegle": 8850, "life": 8851, "cendos": 8852}
    if type(role) is not str or role not in ports or dial_url != f"http://{role}:{ports[role]}":
        return False
    try:
        authority = CanonicalOrigin.parse(configured_authority)
    except (TypeError, ValueError):
        return False
    return authority.scheme == "http" and authority.is_loopback


@dataclass(frozen=True)
class IdentityAuthorityConfig:
    service: str | None = None
    aegle: str | None = None
    life: str | None = None
    cendos: str | None = None

    def __post_init__(self) -> None:
        for value in (self.service, self.aegle, self.life, self.cendos):
            if value is not None:
                canonical_authority(value)

    @classmethod
    def from_environment(cls, environment: Mapping[str, str]) -> IdentityAuthorityConfig:
        names = (
            "LIVEMORE_SERVICE_IDENTITY_AUTHORITY",
            "LIVEMORE_AEGLE_IDENTITY_AUTHORITY",
            "LIVEMORE_LIFE_IDENTITY_AUTHORITY",
            "LIVEMORE_CENDOS_IDENTITY_AUTHORITY",
        )
        # Membership preserves the distinction between absent and present blank.
        values = tuple(canonical_authority(environment[name]) if name in environment else None for name in names)
        return cls(*values)


def service_authority(host: str, port: int, configured: str | None = None) -> str:
    """Bind a native loopback service's proof audience to its own listener."""
    bind = CanonicalOrigin("http", _host(_plain_ascii(host)), _port(port))
    authority = canonical_authority(configured) if configured is not None else None
    if bind.is_loopback:
        if authority is not None and authority != bind.origin:
            raise _invalid(f"Bind origin {bind.origin} differs from configured authority {authority}.")
        return bind.origin
    if authority is None:
        raise _invalid(f"Bind origin {bind.origin} requires an explicitly configured service authority.")
    return authority


def _dial_origin(dial_url: str) -> CanonicalOrigin:
    text = _plain_ascii(dial_url)
    if "\\" in text or "#" in text:
        raise _invalid("The dial URL must be an absolute HTTP or HTTPS URL without credentials or a fragment.")
    try:
        parsed = urlsplit(text)
        if parsed.scheme not in {"http", "https"} or parsed.hostname is None or parsed.username is not None or parsed.password is not None:
            raise _invalid()
        host = _host(parsed.hostname)
        port = parsed.port
        if port is None:
            if parsed.netloc.endswith(":"):
                raise _invalid()
            port = 443 if parsed.scheme == "https" else 80
        return CanonicalOrigin(parsed.scheme, host, _port(port))
    except ValueError as error:
        if isinstance(error, ServiceIdentityConfigurationInvalid):
            raise
        raise _invalid() from None


def expected_authority(dial_url: str, configured: str | None = None) -> str:
    """Derive literal-loopback trust; require trusted configuration for names.

    This does not admit network reachability. Callers retain their existing
    destination restrictions before connecting to the separately chosen dial URL.
    """
    dial = _dial_origin(dial_url)
    authority = canonical_authority(configured) if configured is not None else None
    if dial.is_loopback:
        if authority is not None and authority != dial.origin:
            raise _invalid(f"Dial origin {dial.origin} differs from configured authority {authority}.")
        return dial.origin
    if authority is None:
        raise _invalid(f"Dial origin {dial.origin} requires an explicitly configured expected authority.")
    return authority


def literal_authority_address(dial_url: str, authority: str, *, role: str) -> str | None:
    """Admit the address/port binding without DNS or any other I/O.

    The transport separately requires a named dial's DNS answer to contain this
    literal. Only a fixed Compose peer may reach its audience at another address.
    """
    dial = _dial_origin(dial_url)
    audience = CanonicalOrigin.parse(authority)
    # Preserve the spelling tested by the fixed Compose admission rule. URL
    # normalization must not broaden this sole exception to literal pinning.
    raw_origin = f"{dial_url.partition('://')[0]}://{urlsplit(dial_url).netloc}"
    if is_compose_service_dial(raw_origin, role=role, configured_authority=authority):
        return None
    try:
        address = ipaddress.ip_address(audience.host)
    except ValueError:
        return None
    if dial.port != audience.port:
        raise _invalid("The dial port must equal the configured authority's port.")
    return str(address)
