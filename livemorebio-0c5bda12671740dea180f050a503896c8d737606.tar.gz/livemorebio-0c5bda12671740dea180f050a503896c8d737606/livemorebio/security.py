"""Shared mutation-route authentication for local Livemore services.

The research workbench is loopback-only by default, but mutation routes still
require an operator-supplied bearer token.  The token is never generated in
source code, rendered into HTML, or written to application logs.
"""
import base64
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass
import errno
import hashlib
import hmac
from html import escape
import ipaddress
import json
import logging
import os
import re
import secrets
import shlex
import stat
import threading
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastapi import FastAPI, Request


TOKEN_ENV = "LIVEMORE_API_TOKEN"
SESSION_COOKIE = "livemore_local_session"
PATCH_STORAGE_KEY_ENV = "LIVEMORE_PATCH_STORAGE_KEY"
PATCH_ADMISSION_KEY_ENV = "LIVEMORE_PATCH_ADMISSION_HMAC_KEY"
SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS"})
SESSION_CODE_TTL = 120
CONSOLE_EXCHANGE_PATH = "/api/session/exchange"
CONSOLE_CONNECT_PATH = "/console/connect"
_MANUAL_CODE_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
_ORDINARY_CONSOLE_CODE = re.compile(r"[A-Za-z0-9_-]{43}\Z", re.ASCII)
_MANUAL_CONSOLE_CODE = re.compile(r"(?:[0-9A-HJKMNP-TV-Z]{16}|[0-9A-HJKMNP-TV-Z]{4}(?:-[0-9A-HJKMNP-TV-Z]{4}){3})\Z", re.ASCII | re.IGNORECASE)
# The manual guessing budget belongs to the process, even when tests or an
# embedding application install more than one console-bearing ASGI app.
_CONSOLE_CODE_LOCK = threading.Lock()
_MANUAL_CONSOLE_ATTEMPTS: deque[float] = deque(maxlen=20)
_CONSOLE_CONNECT_STYLE = (
    "body{margin:0;min-height:100vh;display:grid;place-items:center;"
    "background:#f3f6f8;color:#172b35;font:1rem/1.5 system-ui,sans-serif}"
    "main{box-sizing:border-box;width:min(28rem,calc(100% - 2rem));padding:2rem;"
    "background:white;border:1px solid #cbd5db;border-radius:.75rem}"
    "h1{margin:0 0 1.5rem;font-size:1.5rem}label{display:block;margin-bottom:.5rem}"
    "input,button{box-sizing:border-box;width:100%;padding:.75rem;font:inherit;"
    "border:1px solid #667b87;border-radius:.375rem}input{font-size:1.25rem}"
    "button{margin-top:1rem;background:#173f4f;color:white;cursor:pointer}"
)
_CONSOLE_CONNECT_STYLE_HASH = base64.b64encode(
    hashlib.sha256(_CONSOLE_CONNECT_STYLE.encode("utf-8")).digest()).decode("ascii")


def _prefers_console_html(accept: str) -> bool:
    """Honor media-range specificity, then quality; ambiguous requests keep JSON."""
    ranges: list[tuple[str, float]] = []
    for entry in accept.lower().split(","):
        media, *parameters = (part.strip() for part in entry.split(";"))
        qualities = [part.partition("=")[2].strip() for part in parameters
                     if part.partition("=")[0].strip() == "q"]
        quality = 1.0
        if qualities:
            quality = (float(qualities[0]) if len(qualities) == 1 and
                       re.fullmatch(r"(?:0(?:\.[0-9]{0,3})?|1(?:\.0{0,3})?)", qualities[0]) else 0.0)
        ranges.append((media, quality))

    def quality_for(media: str) -> float:
        type_range = media.partition("/")[0] + "/*"
        matches = [(2 if value == media else 1 if value == type_range else 0, quality)
                   for value, quality in ranges if value in {media, type_range, "*/*"}]
        return max(matches, default=(-1, 0.0))[1]

    return quality_for("text/html") > max(0.0, quality_for("application/json"))


@dataclass(frozen=True, repr=False)
class _PendingConsoleCode:
    kind: str
    deadline: float

    def __repr__(self) -> str:
        return "_PendingConsoleCode(<redacted>)"


class ConsoleExchangeAccessLogFilter(logging.Filter):
    """Remove console credential queries before access or trace handlers see them."""

    @staticmethod
    def _exchange_path(value: object) -> bool:
        from posixpath import normpath
        from urllib.parse import unquote

        if isinstance(value, bytes):
            value = value.decode("ascii", errors="replace")
        # Even a refused prefixed deployment must not log a live code.
        return (isinstance(value, str) and
                normpath(unquote(value.partition("?")[0])).rstrip("/").endswith(
                    (CONSOLE_EXCHANGE_PATH, CONSOLE_CONNECT_PATH)))

    @classmethod
    def _redact(cls, value: object) -> object:
        if isinstance(value, dict):
            exchange_scope = (cls._exchange_path(value.get("path")) or
                              cls._exchange_path(value.get("raw_path")))
            # MessageLoggerMiddleware copies the scope but leaves query_string
            # intact. Copy again: logging must never change the running request.
            if exchange_scope:
                redacted = value.copy()
                query = value.get("query_string")
                if query:
                    redacted["query_string"] = b"[REDACTED]" if isinstance(query, bytes) else "[REDACTED]"
                for key in ("path", "raw_path"):
                    if key in redacted:
                        redacted[key] = cls._redact(redacted[key])
                return redacted
            if "type" in value:
                # Other ASGI scopes/messages can contain arbitrary application
                # state; their representation is already handled by Uvicorn.
                return value
            return {key: cls._redact(item) for key, item in value.items()}
        if isinstance(value, tuple):
            return tuple(cls._redact(item) for item in value)
        if isinstance(value, list):
            return [cls._redact(item) for item in value]
        if isinstance(value, (str, bytes)) and cls._exchange_path(value):
            separator = b"?" if isinstance(value, bytes) else "?"
            path, present, _query = value.partition(separator)
            if present:
                return path + separator + (b"[REDACTED]" if isinstance(value, bytes) else "[REDACTED]")
        return value

    def filter(self, record: logging.LogRecord) -> bool:
        # HTTP protocols use (client, method, target, version, status); ASGI
        # trace uses (prefix, task_counter, scope). Also handle mapping args.
        record.args = self._redact(record.args)
        if not record.args or isinstance(record.msg, dict):
            record.msg = self._redact(record.msg)
        return True


def _install_console_access_log_filter() -> None:
    for name in ("uvicorn.access", "uvicorn.asgi"):
        logger = logging.getLogger(name)
        if not any(isinstance(item, ConsoleExchangeAccessLogFilter) for item in logger.filters):
            logger.addFilter(ConsoleExchangeAccessLogFilter())


def session_cookie_name(port: int) -> str:
    """Keep separately launched consoles from replacing each other's cookies."""
    return f"{SESSION_COOKIE}_{port}"


def _request_cookie_name(request: object) -> str:
    # A bound service uses its published authority's port, pinned at startup: a
    # remapped Compose publication listens on another port than its clients use.
    # Otherwise the ASGI server is the listening socket. Never the Host header.
    scope = getattr(request, "scope", {})
    state = getattr(getattr(scope.get("app"), "state", None), "stack_proof", None)
    port = getattr(state, "authority_port", None)
    if type(port) is not int:
        server = scope.get("server")
        port = server[1] if server else None
    return session_cookie_name(port) if isinstance(port, int) else SESSION_COOKIE


CONSOLE_PEER_ENV = "LIVEMORE_CONSOLE_PEER"
_CONSOLE_PEER_MODE = "docker-gateway"
_RTF_UP, _RTF_GATEWAY = 0x1, 0x2
_ROUTE_TABLE = "/proc/net/route"
_CONTAINER_MARKER = "/.dockerenv"
_BRIDGE_NETWORKS = tuple(ipaddress.ip_network(network) for network in (
    "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16",
))


class ConsolePeerError(ValueError):
    """LIVEMORE_CONSOLE_PEER names a peer this process cannot establish."""

    code = "CONSOLE_PEER_UNRESOLVED"

    def __init__(self, reason: str, *, count: int = 0):
        super().__init__(f"{self.code}: {reason} (count={count})")


def _default_gateway(route_table: str) -> "ipaddress.IPv4Address":
    """The one IPv4 default-route gateway in /proc/net/route text, or refuse."""
    gateways: list[ipaddress.IPv4Address] = []
    for line in route_table.split("\n")[1:]:
        # Interface names may contain control bytes Python treats as whitespace;
        # only the kernel's newline/tab separators and trailing space padding count.
        line = line.rstrip(" ")
        if not line:
            continue
        fields = line.split("\t")
        # The kernel writes every row as %08X addresses and %04X flags. A row in
        # any other form is refused whole rather than classified, so a malformed
        # default route can never hide beside a valid one.
        if (len(fields) < 8
                or any(re.fullmatch(r"[0-9A-F]{8}", fields[index]) is None for index in (1, 2, 7))
                or re.fullmatch(r"[0-9A-F]{4}", fields[3]) is None):
            raise ConsolePeerError("the route table has a malformed row", count=len(gateways))
        if fields[1] != "00000000" or fields[7] != "00000000":
            continue
        flags = int(fields[3], 16)
        packed = int(fields[2], 16).to_bytes(4, "little")
        if flags & (_RTF_UP | _RTF_GATEWAY) == (_RTF_UP | _RTF_GATEWAY):
            gateways.append(ipaddress.IPv4Address(packed))
    if len(gateways) != 1:
        raise ConsolePeerError("expected one default gateway", count=len(gateways))
    gateway = gateways[0]
    if not any(gateway in network for network in _BRIDGE_NETWORKS):
        raise ConsolePeerError("the default gateway is not a private bridge address", count=1)
    return gateway


def console_peers() -> frozenset[ipaddress.IPv4Address]:
    """Peers besides loopback that may mint and exchange console codes.

    Docker's port publishing delivers the host's connection from the bridge
    gateway. Only the compose file opts Aegle in by configuration; the
    address is read from this container's own routing table, never from a
    request, and a value other than the one mode is refused at startup.
    """
    mode = os.environ.get(CONSOLE_PEER_ENV, "")
    if mode == "":
        return frozenset()
    if mode != _CONSOLE_PEER_MODE:
        raise ConsolePeerError(f"{CONSOLE_PEER_ENV} accepts only {_CONSOLE_PEER_MODE!r}")
    if not os.path.isfile(_CONTAINER_MARKER):
        raise ConsolePeerError(f"{CONSOLE_PEER_ENV} is set but this process is not in a Docker container")
    try:
        with open(_ROUTE_TABLE, encoding="ascii") as stream:
            table = stream.read()
    except (OSError, UnicodeDecodeError):
        raise ConsolePeerError("the container's route table cannot be read") from None
    return frozenset({_default_gateway(table)})


def _console_peer(request: object, extra_peers: frozenset[ipaddress.IPv4Address]) -> bool:
    client = getattr(request, "client", None)
    try:
        address = ipaddress.ip_address(client.host) if client is not None else None
    except ValueError:
        return False
    # The extra peer is the literal IPv4 address reported by the AF_INET listener;
    # unwrapping IPv6 encodings would admit peers outside that boundary.
    return address is not None and (address.is_loopback or address in extra_peers)


def install_mutation_auth(
    app: "FastAPI", *, session_document_paths: frozenset[str] = frozenset(),
    operator_read_paths: frozenset[str] = frozenset(),
    private_response_paths: frozenset[str] = frozenset(),
    private_response_prefixes: tuple[str, ...] = (),
    service_role: str | None = None,
) -> None:
    """Authenticate mutations and configured private GETs before route parsing."""
    from fastapi import HTTPException, Request
    from fastapi.exception_handlers import http_exception_handler
    from fastapi.responses import HTMLResponse, JSONResponse
    from starlette.requests import ClientDisconnect
    from starlette.routing import Match

    from .request_body import bounded_console_form_request

    from .api_docs import install_api_docs
    install_api_docs(app)

    from .bus import PatchStorageKeyUnavailable

    @app.exception_handler(PatchStorageKeyUnavailable)
    async def storage_key_unavailable(
        _request: Request, error: PatchStorageKeyUnavailable,
    ) -> JSONResponse:
        return JSONResponse(
            {"error": "Encrypted state storage is unavailable; configure LIVEMORE_PATCH_STORAGE_KEY.",
             "code": error.code}, status_code=503, headers={"Cache-Control": "no-store"},
        )

    @app.exception_handler(CredentialFileError)
    async def credential_file_unavailable(
        _request: Request, error: CredentialFileError,
    ) -> JSONResponse:
        # The CLI remedy can name private directories and publication leftovers;
        # HTTP callers need only the credential basename and the refusal code.
        return JSONResponse(
            {"code": error.code,
             "error": f"{error.variable} is linked or nonregular; remove the link or nonregular entry and restart through `livemore start`."},
            status_code=503, headers={"Cache-Control": "no-store"},
        )

    from .stack_proof import (exact_proof_target, install_stack_proof, is_proof_target, proof_refusal)
    proof_post_route = install_stack_proof(app, service_role) if service_role is not None else None

    document_paths = frozenset(session_document_paths)
    extra_peers = console_peers() if document_paths else frozenset()
    app.state.console_session_secret = secrets.token_urlsafe(32)
    codes: dict[tuple[str, str], _PendingConsoleCode] = {}
    code_lock = _CONSOLE_CODE_LOCK
    private_headers = {"Cache-Control": "no-store", "Referrer-Policy": "no-referrer"}
    exchange_post_route = None

    if document_paths:
        _install_console_access_log_filter()

        def console_refusal(request: Request, status_code: int, *, code: str, error: str):
            if _prefers_console_html(",".join(request.headers.getlist("accept"))):
                message = {
                    410: "Old console links are retired. Run livemore open, or livemore open --print-url and enter the new code on the console connection page.",
                    429: "Too many code attempts. Wait one minute, then try again with a fresh code.",
                }.get(status_code, "That code was not accepted. Codes work once, for two minutes.")
                return HTMLResponse(
                    '<!doctype html><html><head><meta charset="utf-8">'
                    '<meta name="viewport" content="width=device-width,initial-scale=1">'
                    '<title>Console code not accepted</title>'
                    f'<style>{_CONSOLE_CONNECT_STYLE}</style></head><body><main>'
                    '<h1>Console code not accepted</h1>'
                    f'<p>{escape(message)}</p>'
                    f'<p><code>{escape(code)}</code></p>'
                    '<a href="/console/connect">Try another code</a></main></body></html>',
                    status_code=status_code,
                    headers={**private_headers, "Content-Security-Policy":
                             "default-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'; "
                             f"style-src 'sha256-{_CONSOLE_CONNECT_STYLE_HASH}'"},
                )
            return JSONResponse({"code": code, "error": error},
                                status_code=status_code, headers=private_headers)

        def exchange_failure(request: Request, status_code: int = 401):
            return console_refusal(request, status_code, code="CONSOLE_EXCHANGE_FAILED",
                                   error="invalid or expired console code")

        async def mint_code(request: Request, *, manual: bool):
            # Other OS users can reach loopback. Only the launcher holding the
            # operator bearer may mint a code; a browser cookie is insufficient.
            if not _request_authorized(request, _operator_token(), allow_session=False):
                return JSONResponse({"code": "CONSOLE_CODE_UNAVAILABLE", "error": "authentication required"}, status_code=401,
                                    headers=private_headers)
            if not _console_peer(request, extra_peers):
                return JSONResponse({"error": "local console required", "code": "CONSOLE_PEER_REFUSED"},
                                    status_code=403, headers=private_headers)
            if request.scope.get("root_path"):
                return exchange_failure(request)
            with code_lock:
                now = time.monotonic()
                for expired in [code for code, record in codes.items() if record.deadline <= now]:
                    del codes[expired]
                if len(codes) >= 128:
                    return JSONResponse({"code": "CONSOLE_CODE_UNAVAILABLE", "error": "too many pending console opens"},
                                        status_code=429, headers=private_headers)
                kind = "manual" if manual else "ordinary"
                code = ("".join(secrets.choice(_MANUAL_CODE_ALPHABET) for _ in range(16))
                        if manual else secrets.token_urlsafe(32))
                if (kind, code) in codes:
                    # A randomness failure must not replace a pending credential.
                    return JSONResponse({"code": "CONSOLE_CODE_UNAVAILABLE", "error": "console code unavailable"},
                                        status_code=503, headers=private_headers)
                codes[(kind, code)] = _PendingConsoleCode(kind, now + SESSION_CODE_TTL)
                if manual:
                    code = "-".join(code[index:index + 4] for index in range(0, 16, 4))
            return JSONResponse({"code": code, "expires_in": SESSION_CODE_TTL}, headers=private_headers)

        @app.post("/api/session/code", include_in_schema=False)
        async def create_session_code(request: Request):
            return await mint_code(request, manual=False)

        @app.post("/api/session/pair-code", include_in_schema=False)
        async def create_pair_code(request: Request):
            return await mint_code(request, manual=True)

        @app.get(CONSOLE_CONNECT_PATH, include_in_schema=False)
        async def console_connection_page(request: Request):
            if request.scope.get("root_path"):
                return exchange_failure(request)
            if not _console_peer(request, extra_peers):
                return exchange_failure(request, 403)
            if request.scope.get("query_string"):
                return exchange_failure(request, 400)
            return HTMLResponse(
                '<!doctype html><html><head><meta charset="utf-8">'
                '<meta name="viewport" content="width=device-width,initial-scale=1">'
                '<title>Connect to Livemore console</title>'
                f'<style>{_CONSOLE_CONNECT_STYLE}</style></head><body><main>'
                '<h1>Connect to Livemore console</h1>'
                '<form method="post" action="/api/session/exchange" autocomplete="off">'
                '<label for="code">One-time code</label>'
                '<input id="code" name="code" type="password" autocomplete="off" required>'
                '<button type="submit">Connect</button></form></main></body></html>',
                headers={**private_headers, "Referrer-Policy": "same-origin", "Content-Security-Policy":
                         "default-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'; "
                         f"style-src 'sha256-{_CONSOLE_CONNECT_STYLE_HASH}'"},
            )

        @app.get(CONSOLE_EXCHANGE_PATH, include_in_schema=False)
        async def retired_get_exchange(request: Request):
            return console_refusal(
                request, 410, code="CONSOLE_EXCHANGE_GET_RETIRED",
                error="Old console links are retired. Run livemore open, or livemore open --print-url and enter the new code on the console connection page.",
            )

        @app.post(CONSOLE_EXCHANGE_PATH, include_in_schema=False)
        async def exchange_session_code(request: Request):
            if request.scope.get("root_path") or not _console_peer(request, extra_peers):
                return exchange_failure(request)
            if request.scope.get("query_string"):
                return exchange_failure(request, 400)
            origins = request.headers.getlist("origin")
            matching_origin = (len(origins) == 1 and
                               _same_origin(origins[0], request.headers.get("host", ""), request.url.scheme))
            if len(origins) > 1 or (origins and origins[0] != "null" and not matching_origin):
                return exchange_failure(request, 403)
            try:
                supplied_code = await bounded_console_form_request(request)
            except HTTPException as error:
                return exchange_failure(request, error.status_code)
            except ClientDisconnect:
                return exchange_failure(request, 400)
            ordinary = _ORDINARY_CONSOLE_CODE.fullmatch(supplied_code) is not None
            if not ordinary and not matching_origin:
                # Recognizable manual credentials need browser-origin proof;
                # unrelated malformed bodies keep the ordinary fixed refusal.
                return exchange_failure(request, 403 if _MANUAL_CONSOLE_CODE.fullmatch(supplied_code) else 401)
            with code_lock:
                now = time.monotonic()
                if ordinary:
                    key = ("ordinary", supplied_code)
                else:
                    while _MANUAL_CONSOLE_ATTEMPTS and _MANUAL_CONSOLE_ATTEMPTS[0] <= now - 60:
                        _MANUAL_CONSOLE_ATTEMPTS.popleft()
                    if len(_MANUAL_CONSOLE_ATTEMPTS) >= 20:
                        return console_refusal(
                            request, 429, code="CONSOLE_CODE_ATTEMPTS_EXCEEDED",
                            error="Too many console code attempts. Wait one minute, then try again with a fresh code.",
                        )
                    _MANUAL_CONSOLE_ATTEMPTS.append(now)
                    if _MANUAL_CONSOLE_CODE.fullmatch(supplied_code) is None:
                        return exchange_failure(request)
                    key = ("manual", supplied_code.replace("-", "").upper())
                record = codes.pop(key, None)
                if record is None or record.deadline <= now:
                    return exchange_failure(request)
            response = HTMLResponse(
                '<!doctype html><html><head><meta charset="utf-8">'
                '<meta http-equiv="refresh" content="0;url=/">'
                '<title>Console authorization complete</title></head>'
                '<body><a href="/">Continue to the console</a></body></html>',
                headers={**private_headers, "Content-Security-Policy":
                         "default-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"},
            )
            response.set_cookie(_request_cookie_name(request), app.state.console_session_secret,
                                httponly=True, secure=False, samesite="strict", path="/")
            return response

        # Capture the registered POST route, rather than reproducing its decoded
        # path rules in middleware. Prefix/root-path hosting is unsupported.
        exchange_post_route = next(route for route in app.routes
                                   if getattr(route, "endpoint", None) is exchange_session_code
                                   and "POST" in getattr(route, "methods", set()))

    @app.middleware("http")
    async def private_api_responses(request: Request, call_next):
        response = await call_next(request)
        # Authenticated reads include participant searches and experiment results.
        # Error responses must not be cached either: URLs can carry private queries.
        if request.url.path.startswith(("/api/", "/protocols")):
            response.headers["Cache-Control"] = "no-store"
        if request.url.path in document_paths:
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.middleware("http")
    async def mutation_auth(request: Request, call_next):
        if proof_post_route is not None and is_proof_target(request.scope):
            if not exact_proof_target(request.scope):
                return proof_refusal(400)
            selected = next((route for route in app.routes
                             if route.matches(request.scope)[0] is Match.FULL), None)
            if selected is proof_post_route:
                return await call_next(request)
        if request.method == "GET" and request.scope.get("path") in operator_read_paths:
            # Even request-only FastAPI dependencies parse query parameters.
            # Admission here precedes that parsing and every route-level read.
            try:
                require_operator_auth(request)
            except HTTPException as error:
                response = await http_exception_handler(request, error)
                response.headers["Cache-Control"] = "no-store"
                return response
        if document_paths:
            from posixpath import normpath
            from urllib.parse import unquote

            # Refused legacy targets can still carry credentials. Stop alias
            # routing before Starlette can copy their query into a Location.
            path = normpath(unquote(request.scope.get("path", ""))).rstrip("/")
            target = next((value for value in (CONSOLE_EXCHANGE_PATH, CONSOLE_CONNECT_PATH)
                           if path.endswith(value)), None)
            raw_path = request.scope.get("raw_path", b"")
            if target and (request.scope.get("root_path") or request.scope.get("path") != target
                           or raw_path != target.encode("ascii")):
                return exchange_failure(request, 400)
        if request.method.upper() in SAFE_METHODS:
            return await call_next(request)
        if (request.method == "POST" and not request.scope.get("root_path")
                and exchange_post_route is not None
                and exchange_post_route.matches(request.scope)[0] is Match.FULL):
            # A preceding exact route or mount can win before this endpoint.
            # Exempt only the first FULL match, just as Starlette's router does.
            selected = next((route for route in app.routes
                             if route.matches(request.scope)[0] is Match.FULL), None)
            if selected is exchange_post_route:
                return await call_next(request)
        expected = os.environ.get(TOKEN_ENV, "")
        if not expected:
            return JSONResponse(
                {"error": f"mutation API disabled; set {TOKEN_ENV}"},
                status_code=503,
                headers={"Cache-Control": "no-store"},
            )
        if not _request_authorized(request, expected):
            return JSONResponse({"error": "authentication required"}, status_code=401,
                                headers={"Cache-Control": "no-store"})
        return await call_next(request)

    from .request_errors import PrivateRequestErrors
    app.add_middleware(PrivateRequestErrors)
    from .http_security import ConsoleHTTPBoundary
    deployment_hosts = os.environ.get("LIVEMORE_ALLOWED_HOSTS", "")
    # Compose already names each container's service explicitly. Admit its own
    # DNS name so existing internal calls keep working without trusting peers'
    # names or adding container aliases to bare local-process defaults.
    service_host = os.environ.get("LIVEMORE_SERVICE", "").strip().lower()
    if service_host in {"aegle", "life", "cendos"}:
        deployment_hosts = f"{deployment_hosts},{service_host}"
    app.add_middleware(ConsoleHTTPBoundary,
                       deployment_hosts=deployment_hosts,
                       session_document_paths=document_paths,
                       private_response_paths=private_response_paths,
                       private_response_prefixes=private_response_prefixes)


# Launcher-provisioned credentials, by file name.
SECRET_FILES = ("api-token", "patch-storage.key", "patch-admission.key", "service-identity.key")
# A local reader must yield to the thread finishing link/unlink, even when
# CPU-bound Python delays that thread. No lock file or cross-process lock exists.
_SECRET_PUBLICATION_LOCK = threading.Lock()


def refuse_linked_secrets(directory: str) -> None:
    """Ask about every name before any of them is made: a command that
    makes the token and then the keys would otherwise have made one before it
    refused the next."""
    for name in SECRET_FILES:
        refuse_linked_secret(os.path.join(directory, name))


def _publication_leftovers(path: str, info: os.stat_result | None) -> tuple[str, ...]:
    """Name only private same-inode leftovers, without opening their contents."""
    if info is None or not stat.S_ISREG(info.st_mode) or info.st_nlink != 2:
        return ()
    directory = os.path.dirname(path) or "."
    pattern = re.compile(re.escape(os.path.basename(path)) + r"\.[0-9]+\.[0-9a-f]{16}\.tmp")
    try:
        with os.scandir(directory) as entries:
            leftovers = []
            for entry in entries:
                if pattern.fullmatch(entry.name) is None:
                    continue
                candidate = entry.stat(follow_symlinks=False)
                current = os.lstat(path)
                # The temporary must still have a second named copy. Stale
                # metadata after a rename must never suggest deleting the last.
                if (stat.S_ISREG(candidate.st_mode) and stat.S_ISREG(current.st_mode)
                        and candidate.st_nlink == current.st_nlink == 2
                        and stat.S_IMODE(candidate.st_mode) == 0o600
                        and candidate.st_uid == current.st_uid == info.st_uid == os.getuid()
                        and (candidate.st_dev, candidate.st_ino) == (info.st_dev, info.st_ino)
                        == (current.st_dev, current.st_ino)):
                    leftovers.append(os.path.join(directory, entry.name))
        return tuple(sorted(leftovers))
    except OSError:
        # Recovery guidance is best effort; inability to inspect never admits a
        # linked credential and must not replace its typed refusal.
        return ()


class CredentialFileError(ValueError):
    """A credential must be this stack's own single-link regular file."""

    code = "STACK_CREDENTIAL_LINKED"

    def __init__(self, path: str, mode: int = 0, *, leftovers: tuple[str, ...] = ()):
        self.variable = os.path.basename(path)
        detail = ("a symbolic link" if stat.S_ISLNK(mode) else
                  "a regular file without exactly one link" if stat.S_ISREG(mode) else
                  "a directory" if stat.S_ISDIR(mode) else "not a regular file")
        if self.variable == "service-identity.key":
            remedy = (
                "A shared identity key lets another stack impersonate this stack. "
                "Stop every service in this stack with `livemore stop all` (or `livemore down` for Compose), "
                "then run `livemore identity rotate`, restart every service and recreate attached clients. "
                "Rotation replaces only this entry; leave any link target unchanged. "
                "Do not copy a shared identity key into this stack.")
        elif leftovers:
            # The verified sibling is the extra name; suggesting removal of the
            # credential as well could destroy the only remaining storage key.
            commands = "\n".join("  rm -- " + shlex.quote(name) for name in leftovers)
            remedy = ("A creator may have stopped after publishing. Remove the verified owner-only "
                      "leftover temporary name, then retry; keep the credential itself:\n" + commands)
        else:
            here = shlex.quote(path)
            made = "`livemore token`, `livemore start` or the foreground runner then makes this stack's own credential"
            if stat.S_ISLNK(mode) or stat.S_ISREG(mode):
                copy = shlex.quote(path + ".own")
                warning = ("Keep a private copy of the existing key if this stack has stored state; "
                           "a newly generated key cannot read that state. "
                           if self.variable == "patch-storage.key" else "")
                remedy = (
                    warning + "To keep this stack's own copy, put a copy of the file in the link's place:\n"
                    f"  cp -- {here} {copy} && mv -- {copy} {here}\n"
                    f"Otherwise remove the link. What it leads to is left as it is, and {made}:\n  rm -- {here}")
            elif stat.S_ISDIR(mode):
                remedy = ("Remove the empty directory only; nothing in it was put there by the product. "
                          f"{made}:\n  rmdir -- {here}")
            else:
                remedy = f"Remove the nonregular entry; {made}:\n  rm -- {here}"
        super().__init__(f"{self.code}: {self.variable} is {detail}; it was not read or made private. {remedy}")


def _not_a_file_of_its_own(path: str, mode: int, info: os.stat_result | None = None) -> CredentialFileError:
    return CredentialFileError(path, mode, leftovers=_publication_leftovers(path, info))


def _publish_secret(temporary: str, path: str) -> None:
    """Publish without overwriting, holding the in-process lock across link and unlink only.

    The holder makes two system calls and nothing else while it holds the lock, so a reader of
    this process that waits for it is released whatever the interpreter schedules first.
    """
    with _SECRET_PUBLICATION_LOCK:
        try:
            os.link(temporary, path)
        except FileExistsError:
            pass  # another creator published first; the caller reads what it published
        finally:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass


def _require_single_link(
    path: str, info: os.stat_result, inspect: Callable[[], os.stat_result], deadline: float,
) -> None:
    """Admit only the checked inode after our atomic publication link is gone."""
    identity = (info.st_dev, info.st_ino)
    for attempt in range(41):
        if (not stat.S_ISREG(info.st_mode) or (info.st_dev, info.st_ino) != identity
                or info.st_nlink not in (1, 2)):
            raise _not_a_file_of_its_own(path, info.st_mode, info)
        if info.st_nlink == 1:
            return
        if attempt == 0:
            # A creator of this process holds the lock across link and unlink only, so the wait is
            # bounded by two system calls, not by a clock that a busy interpreter can outrun.
            with _SECRET_PUBLICATION_LOCK:
                pass
        else:
            # Another process's publication is not ordered by this lock: re-check the same object
            # until the shared deadline, then refuse.
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            time.sleep(min(0.005, remaining))
        try:
            info = inspect()
        except FileNotFoundError:
            raise _not_a_file_of_its_own(path, info.st_mode, info) from None
    # The last re-check is judged as every other is.
    if stat.S_ISREG(info.st_mode) and (info.st_dev, info.st_ino) == identity and info.st_nlink == 1:
        return
    raise _not_a_file_of_its_own(path, info.st_mode, info)


def _check_secret_name(path: str, deadline: float) -> None:
    try:
        info = os.lstat(path)
    except FileNotFoundError:
        return
    _require_single_link(path, info, lambda: os.lstat(path), deadline)


def refuse_linked_secret(path: str) -> None:
    """Refuse a credential name that is not this stack's single-link regular file.

    A creator publishes with link/unlink, briefly giving its new inode two names.
    Recheck that same inode for at most 200 ms; a permanent link, a changed inode,
    or any other file shape refuses before reading or changing permissions.
    """
    _check_secret_name(path, time.monotonic() + 0.2)


def read_own_secret(path: str, *, tighten: bool = False) -> str:
    """Read and optionally tighten one checked credential descriptor.

    Name and descriptor checks share a publication deadline. The descriptor is
    never reopened, so a name swap cannot redirect either the read or chmod.
    A missing file is ``FileNotFoundError``, as it was.
    """
    deadline = time.monotonic() + 0.2
    _check_secret_name(path, deadline)
    # A pipe substituted since lstat must refuse rather than block the reader.
    try:
        descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
    except OSError as error:
        if error.errno == errno.ELOOP:
            raise _not_a_file_of_its_own(path, stat.S_IFLNK) from None
        raise
    try:
        _require_single_link(path, os.fstat(descriptor), lambda: os.fstat(descriptor), deadline)
        if tighten:
            os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, encoding="utf-8", closefd=False) as stream:
            return stream.read().strip()
    finally:
        os.close(descriptor)


def holds_linked_secret(directory: str) -> bool:
    try:
        refuse_linked_secrets(directory)
    except CredentialFileError:
        return True
    return False


def authorization_headers() -> dict[str, str]:
    """Headers for local attach clients, using env override then launcher token file."""
    token = os.environ.get(TOKEN_ENV, "").strip()
    if not token:
        from . import registry
        token_path = os.path.join(registry.REG_DIR, "api-token")
        try:
            token = read_own_secret(token_path)
        except (FileNotFoundError, PermissionError, OSError):
            token = ""
    if not token:
        raise RuntimeError(
            f"attach-mode mutation requires {TOKEN_ENV} or the local launcher token file"
        )
    return {"Authorization": f"Bearer {token}"}


def require_operator_auth(request: object) -> None:
    """Protect selected PHI-like read routes as well as mutation routes."""
    from fastapi import HTTPException

    expected = _operator_token()
    if not expected:
        raise HTTPException(status_code=503, detail=f"operator API disabled; set {TOKEN_ENV}")
    if not _request_authorized(request, expected):
        raise HTTPException(status_code=401, detail="authentication required")


def _credential_matches(candidate: str, expected: str) -> bool:
    """Malformed HTTP credential characters reject, rather than raise TypeError."""
    if any(not isinstance(value, str) or not 1 <= len(value) <= 4096
           or any(not 33 <= ord(char) <= 126 for char in value)
           for value in (candidate, expected)):
        return False
    return hmac.compare_digest(candidate.encode("ascii"), expected.encode("ascii"))


def _request_authorized(request: object, expected: str, *, allow_session: bool = True) -> bool:
    """Bearer and browser session credentials occupy separate namespaces."""
    headers = getattr(request, "headers", {})
    supplied = headers.get("Authorization", "")
    prefix = "Bearer "
    if supplied:
        candidate = supplied[len(prefix):] if supplied.startswith(prefix) else ""
        return _credential_matches(candidate, expected)
    if not allow_session:
        return False
    cookies = getattr(request, "cookies", {})
    cookie = cookies.get(_request_cookie_name(request), "") if cookies else ""
    if not cookie or str(headers.get("Sec-Fetch-Site", "")).lower() != "same-origin":
        return False
    origin = str(headers.get("Origin", ""))
    scheme = getattr(getattr(request, "url", None), "scheme", "")
    if origin and not _same_origin(origin, str(headers.get("Host", "")), scheme):
        return False
    state = getattr(getattr(request, "app", None), "state", None)
    session = getattr(state, "console_session_secret", "")
    return _credential_matches(cookie, session) and not _credential_matches(cookie, expected)


def _same_origin(origin: str, host: str, scheme: str) -> bool:
    from urllib.parse import urlparse

    try:
        parsed = urlparse(origin)
    except ValueError:
        return False
    return bool(parsed.hostname and parsed.netloc == host and parsed.scheme == scheme
                and parsed.username is None and parsed.password is None
                and not parsed.path and not parsed.query and not parsed.fragment)


def _operator_token() -> str:
    token = os.environ.get(TOKEN_ENV, "").strip()
    if token:
        return token
    from . import registry

    try:
        return read_own_secret(os.path.join(registry.REG_DIR, "api-token"))
    except (OSError, CredentialFileError):
        return ""


def _secret_path(filename: str) -> str:
    from . import registry

    return os.path.join(registry.REG_DIR, filename)


def _decode_secret(value: str, name: str) -> bytes:
    try:
        decoded = base64.urlsafe_b64decode(value.encode("ascii"))
    except (ValueError, UnicodeEncodeError) as error:
        raise RuntimeError(f"{name} must be URL-safe base64") from error
    if len(decoded) != 32:
        raise RuntimeError(f"{name} must decode to exactly 32 bytes")
    return decoded


def _load_secret(env_name: str, filename: str, *, create: bool) -> bytes | None:
    configured = os.environ.get(env_name, "").strip()
    if configured:
        return _decode_secret(configured, env_name)
    environment = os.environ.get("LIVEMORE_ENVIRONMENT", "").strip().lower()
    if environment in {"prod", "production"}:
        if create:
            raise RuntimeError(f"production requires externally managed {env_name}")
        return None
    path = _secret_path(filename)
    try:
        # A key that is a link is refused here, before anything is read, made
        # private or created beside it.
        value = read_own_secret(path, tighten=True)
    except (FileNotFoundError, PermissionError, OSError):
        value = ""
    if value:
        decoded = _decode_secret(value, env_name)
        os.environ[env_name] = value
        return decoded
    if not create:
        return None
    from . import registry

    directory_status = registry.ensure_data_dir()
    from ._platform import require_posix

    require_posix("Credential creation")
    # Another creator may have published after the first read.
    try:
        value = read_own_secret(path, tighten=True)
    except FileNotFoundError:
        value = ""
    if not value:
        registry.require_secret_creation(directory_status)
        candidate = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode("ascii")
        temporary = f"{path}.{os.getpid()}.{secrets.token_hex(8)}.tmp"
        descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
                stream.write(candidate + "\n")
                stream.flush()
                os.fsync(stream.fileno())
            _publish_secret(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        value = read_own_secret(path, tighten=True)
    os.environ[env_name] = value
    return _decode_secret(value, env_name)


def patch_storage_key(*, create: bool = False) -> bytes | None:
    """Return the AES-256 key used for PHI-like local state, when configured."""
    return _load_secret(PATCH_STORAGE_KEY_ENV, "patch-storage.key", create=create)


def patch_admission_key(*, create: bool = False) -> bytes | None:
    """Return the internal key that authenticates LIFE-to-Aegle admissions."""
    return _load_secret(PATCH_ADMISSION_KEY_ENV, "patch-admission.key", create=create)


def ensure_patch_security_keys() -> None:
    patch_storage_key(create=True)
    patch_admission_key(create=True)


def _admission_bytes(admission: dict) -> bytes:
    return json.dumps(
        admission, sort_keys=True, separators=(",", ":"), allow_nan=False,
    ).encode("utf-8")


def sign_patch_admission(admission: dict) -> str:
    key = patch_admission_key(create=False)
    if key is None:
        raise RuntimeError(f"patch admission disabled; configure {PATCH_ADMISSION_KEY_ENV}")
    return hmac.new(key, b"patch-admission-v1\0" + _admission_bytes(admission), "sha256").hexdigest()


def verify_patch_admission(admission: dict, signature: str) -> bool:
    key = patch_admission_key(create=False)
    if key is None or len(signature) != 64:
        return False
    expected = hmac.new(
        key, b"patch-admission-v1\0" + _admission_bytes(admission), "sha256"
    ).hexdigest()
    return hmac.compare_digest(signature, expected)


def sign_device_manifest(manifest: dict) -> str:
    """Sign a physical manifest in a trusted provisioning workflow."""
    key = patch_admission_key(create=False)
    if key is None:
        raise RuntimeError(f"device provisioning disabled; configure {PATCH_ADMISSION_KEY_ENV}")
    return hmac.new(
        key, b"device-manifest-v1\0" + _admission_bytes(manifest), "sha256"
    ).hexdigest()


def verify_device_manifest(manifest: dict, signature: str) -> bool:
    key = patch_admission_key(create=False)
    if key is None or len(signature) != 64:
        return False
    expected = hmac.new(
        key, b"device-manifest-v1\0" + _admission_bytes(manifest), "sha256"
    ).hexdigest()
    return hmac.compare_digest(signature, expected)
