"""One proved first-party request on one owned socket, with no reconnect.

Callers admit their own destinations and supply an immutable local identity.
The generic vendor opener deliberately does not use this protocol. A proof is
possession of the stack key for an audience, not encryption or channel binding.
"""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
import http.client
import io
import ipaddress
import math
import re
import secrets
import socket
import ssl
import threading
import time
from urllib.parse import SplitResult, urlsplit

from .service_identity import IdentitySnapshot, verify_proof_response
from .service_identity_config import (ServiceIdentityConfigurationInvalid,
                                      expected_authority, literal_authority_address)


UNPROVEN_TEXT = (
    "SERVICE_IDENTITY_UNPROVEN: This endpoint did not prove this stack's service "
    "identity. No credential was sent. Stop this stack, check the configured "
    "identity key and service authorities, then restart with the updated launcher. "
    "An occupied port may belong to another process. Do not bypass this check."
)
DIAL_AUTHORITY_UNREACHABLE_TEXT = (
    "SERVICE_IDENTITY_UNPROVEN: The dial name does not reach the configured authority's address. "
    "No credential was sent. Check the dial name and configured service authority, "
    "then restart with the updated launcher. Do not bypass this check."
)
PROOF_TIMEOUT = 2.0
_RESOLVER_SLOTS = threading.BoundedSemaphore(4)
_TOKEN = re.compile(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+")


class ServiceIdentityUnproven(RuntimeError):
    code = "SERVICE_IDENTITY_UNPROVEN"

    def __init__(self, *, dial_address_mismatch: bool = False) -> None:
        super().__init__(DIAL_AUTHORITY_UNREACHABLE_TEXT if dial_address_mismatch else UNPROVEN_TEXT)
        if dial_address_mismatch:
            self.endpoint_reachable = False


class ResponseTooLarge(ValueError):
    """The proved endpoint exceeded the caller's actual-response bound."""


@dataclass(frozen=True)
class StackResponse:
    status: int
    reason: str
    headers: tuple[tuple[str, str], ...]
    body: bytes = field(repr=False)

    def getheader(self, name: str, default: str | None = None) -> str | None:
        values = [value for key, value in self.headers if key.lower() == name.lower()]
        return ", ".join(values) if values else default


@dataclass(frozen=True)
class _Budget:
    deadline: float

    def remaining(self) -> float:
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("stack operation deadline exceeded")
        return remaining

    def arm(self, peer: socket.socket) -> None:
        peer.settimeout(self.remaining())


@dataclass
class _Resolution:
    """A worker receives only a hostname/port and this credential-free mailbox."""
    event: threading.Event = field(default_factory=threading.Event)
    lock: threading.Lock = field(default_factory=threading.Lock)
    active: bool = True
    result: tuple | None = None


def _literal_target(host: str, port: int) -> tuple:
    address = ipaddress.ip_address(host)
    family = socket.AF_INET6 if address.version == 6 else socket.AF_INET
    target = (host, port, 0, 0) if address.version == 6 else (host, port)
    return family, socket.SOCK_STREAM, 0, target


def _resolve_worker(host: str, port: int, mailbox: _Resolution,
                    required_address: str | None = None) -> None:
    result = None
    try:
        addresses = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
        # A named dial cannot move a literal proof audience to a relay. DNS only
        # confirms membership; the configured literal supplies the connect target.
        if required_address is not None:
            expected = ipaddress.ip_address(required_address)
            if any(ipaddress.ip_address(target[0]) == expected
                   for family, kind, _, _, target in addresses
                   if family in (socket.AF_INET, socket.AF_INET6) and kind == socket.SOCK_STREAM):
                result = _literal_target(required_address, port)
        elif addresses:
            # Named authorities retain one address, one connect, without fallback.
            family, kind, protocol, _, target = addresses[0]
            result = (family, kind, protocol, target)
    except Exception:
        pass
    finally:
        with mailbox.lock:
            if mailbox.active:
                mailbox.result = result
                mailbox.event.set()
        _RESOLVER_SLOTS.release()


def _resolve(host: str, port: int, budget: _Budget, *, required_address: str | None = None) -> tuple:
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
    if address is not None:
        # Literal addresses never enter getaddrinfo, including IPv6 loopback.
        if required_address is not None and address != ipaddress.ip_address(required_address):
            raise ServiceIdentityUnproven(dial_address_mismatch=True)
        return _literal_target(host, port)
    if not _RESOLVER_SLOTS.acquire(blocking=False):
        raise ServiceIdentityUnproven()
    mailbox = _Resolution()
    try:
        worker = threading.Thread(target=_resolve_worker, args=(host, port, mailbox, required_address), daemon=True,
                                  name="stack-identity-resolver")
        worker.start()
    except BaseException:
        _RESOLVER_SLOTS.release()
        raise
    try:
        completed = mailbox.event.wait(budget.remaining())
        with mailbox.lock:
            # The operation may expire between event delivery and scheduling.
            budget.remaining()
            if not completed or mailbox.result is None:
                raise ServiceIdentityUnproven(dial_address_mismatch=completed and required_address is not None)
            return mailbox.result
    finally:
        with mailbox.lock:
            mailbox.active = False
            mailbox.result = None


class _BoundedReader(io.RawIOBase):
    """Unbuffered wire bounds beneath the stdlib HTTP syntax parser.

    Headers are consumed a byte at a time so no oversized line or field is ever
    retained in an intermediate buffered reader. Bodies use recv_into directly.
    """
    def __init__(self, peer: socket.socket, budget: _Budget, *, proof: bool) -> None:
        super().__init__()
        self.peer = peer
        self.budget = budget
        self.proof = proof
        self.header_done = False
        self.header_bytes = 0
        self.header_lines = 0
        self.body_bytes = 0
        self.max_headers = 8192 if proof else 65536
        self.max_line = 2048 if proof else 8192
        self.max_fields = 32 if proof else 100

    def readable(self) -> bool:
        return True

    def readinto(self, target: bytearray | memoryview) -> int:
        if self.closed:
            raise ValueError("read on closed response")
        if not target:
            return 0
        if self.proof and self.header_done and self.body_bytes + len(target) > 97:
            raise ValueError("proof body exceeds its bound")
        self.budget.arm(self.peer)
        received = self.peer.recv_into(target)
        if self.header_done:
            self.body_bytes += received
        return received

    def read(self, size: int = -1) -> bytes:
        if size < 0:
            if self.proof:
                raise ValueError("an explicit proof read bound is required")
            chunks = []
            while True:
                chunk = bytearray(8192)
                count = self.readinto(chunk)
                if not count:
                    return b"".join(chunks)
                chunks.append(bytes(chunk[:count]))
        result = bytearray(size)
        received = 0
        while received < size:
            count = self.readinto(memoryview(result)[received:])
            if not count:
                break
            received += count
        return bytes(result[:received])

    def readline(self, size: int = -1) -> bytes:
        line = bytearray()
        while size < 0 or len(line) < size:
            one = bytearray(1)
            if not self.readinto(one):
                break
            if len(line) >= self.max_line:
                raise ValueError("response line exceeds its bound")
            if not self.header_done:
                if self.header_bytes >= self.max_headers:
                    raise ValueError("response headers exceed their bound")
                if (not line and self.header_lines > self.max_fields
                        and one not in (b"\r", b"\n")):
                    raise ValueError("response has too many fields")
                self.header_bytes += 1
            line.extend(one)
            if one == b"\n":
                break
        if not self.header_done:
            self.header_lines += 1
            if self.header_lines > 1 and line not in (b"\r\n", b"\n"):
                if self.header_lines - 1 > self.max_fields:
                    raise ValueError("response has too many fields")
                if self.proof and (line[:1] in (b" ", b"\t") or b":" not in line):
                    raise ValueError("proof headers must be unfolded fields")
            if line in (b"\r\n", b"\n"):
                self.header_done = True
        return bytes(line)


class _ReaderSocket:
    def __init__(self, reader: _BoundedReader) -> None:
        self.reader = reader

    def makefile(self, mode: str) -> _BoundedReader:
        return self.reader


class _ProofResponse(http.client.HTTPResponse):
    def _read_status(self) -> tuple[str, int, str]:
        version, status, reason = super()._read_status()
        # The stdlib normally skips 100; a proof has exactly one 200 response.
        if version != "HTTP/1.1" or status != 200:
            raise ValueError("proof requires exactly one HTTP/1.1 200 response")
        return version, status, reason


class _Connection(http.client.HTTPConnection):
    auto_open = 0

    def __init__(self, host: str, port: int, budget: _Budget) -> None:
        super().__init__(host, port)
        self.budget = budget
        self.debuglevel = 0
        self.proof = True
        self.pinned: socket.socket | None = None
        self.actual_write_started = False
        self.response_class = self._response

    def connect(self) -> None:
        # Even a changed stdlib code path cannot silently create another socket.
        raise OSError("stack transport reconnect refused")

    def send(self, data: bytes | bytearray | memoryview) -> None:
        view = memoryview(data)
        while view:
            pinned = self.pinned
            if pinned is None or self.sock is not pinned or pinned.fileno() < 0:
                raise http.client.NotConnected()
            self.budget.arm(pinned)
            if self.sock is not pinned:
                raise http.client.NotConnected()
            if not self.proof:
                self.actual_write_started = True
            sent = pinned.send(view)
            if sent <= 0:
                raise ConnectionError("stack socket closed during send")
            view = view[sent:]

    def close(self) -> None:
        # getresponse detaches will_close responses before their body is read.
        # The operation owns the raw socket, unlike socket.makefile's reference
        # counting, so stdlib detachment must not destroy that pending reader.
        self.sock = None
        super().close()

    def finish(self) -> None:
        attached = self.sock
        try:
            self.close()
        finally:
            if attached is not None and attached is not self.pinned:
                attached.close()
            if self.pinned is not None:
                self.pinned.close()

    def _response(self, peer: socket.socket, *, method: str | None = None,
                  debuglevel: int = 0) -> http.client.HTTPResponse:
        reader = _BoundedReader(peer, self.budget, proof=self.proof)
        response_class = _ProofResponse if self.proof else http.client.HTTPResponse
        return response_class(_ReaderSocket(reader), method=method, debuglevel=debuglevel)


def _connect(host: str, secure: bool, budget: _Budget, address: tuple) -> socket.socket:
    family, kind, protocol, target = address
    peer = socket.socket(family, kind, protocol)
    try:
        budget.arm(peer)
        peer.connect(target)
        if secure:
            context = ssl.create_default_context()
            # The trusted server name is the original dial host, never its DNS
            # answer. The default context verifies certificates and hostnames.
            budget.arm(peer)
            peer = context.wrap_socket(peer, server_hostname=host, do_handshake_on_connect=False)
            budget.arm(peer)
            peer.do_handshake()
        return peer
    except BaseException:
        peer.close()
        raise


def _assert_live(connection: _Connection, pinned: socket.socket, budget: _Budget) -> None:
    budget.remaining()
    if connection.sock is not pinned or pinned.fileno() < 0:
        raise ConnectionError("proved socket is no longer owned")
    if isinstance(pinned, ssl.SSLSocket) and pinned.pending():
        raise ValueError("unexpected data after proof")
    # Probe the owned descriptor directly: select() rejects otherwise healthy
    # sockets above FD_SETSIZE. No-data is live; EOF, reset and extra bytes fail.
    pinned.setblocking(False)
    try:
        if isinstance(pinned, ssl.SSLSocket):
            # Process TLS control records without adding a blocking wait.
            try:
                pinned.recv_into(bytearray(1))
            except ssl.SSLWantReadError:
                return
        else:
            try:
                pinned.recv(1, socket.MSG_PEEK)
            except BlockingIOError:
                return
        raise ConnectionError("proved socket closed or carried extra bytes")
    finally:
        budget.arm(pinned)


def _prove(connection: _Connection, identity: IdentitySnapshot,
           pinned: socket.socket, budget: _Budget) -> None:
    nonce = secrets.token_bytes(32)
    connection.putrequest("POST", "/api/stack/prove", skip_accept_encoding=True)
    connection.putheader("Content-Type", "application/octet-stream")
    connection.putheader("Content-Length", "32")
    connection.endheaders(nonce)
    response = connection.getresponse()
    fields = response.getheaders()
    lowered = [name.lower() for name, _ in fields]
    headers = {name.lower(): value for name, value in fields}
    if (response.status != 200 or response.version != 11 or response.will_close
            or len(lowered) != len(set(lowered))
            or headers.get("content-length") != "96"
            or headers.get("content-type") != "application/octet-stream"
            or headers.get("cache-control") != "no-store"
            or headers.get("referrer-policy") != "no-referrer"
            or any(name in headers for name in ("transfer-encoding", "content-encoding", "set-cookie", "location"))
            or any(name.startswith("access-control-") for name in headers)):
        raise ValueError("invalid proof response")
    body = response.read(97)
    if not verify_proof_response(identity, nonce, body):
        raise ValueError("invalid service proof")
    _assert_live(connection, pinned, budget)


def _request_inputs(url: str, method: str, headers: Mapping[str, str] | None,
                    body: bytes | None) -> tuple[SplitResult, str, tuple[tuple[str, str], ...]]:
    parsed = urlsplit(url)
    if (not isinstance(method, str) or not _TOKEN.fullmatch(method)
            or method != method.upper() or method == "CONNECT"):
        raise ValueError("invalid stack request method")
    if body is not None and not isinstance(body, bytes):
        raise TypeError("stack request body must be immutable bytes")
    fields = []
    seen = set()
    for name, value in (() if headers is None else headers.items()):
        if (not isinstance(name, str) or not _TOKEN.fullmatch(name)
                or not isinstance(value, str) or any(ord(char) < 32 or ord(char) > 126 for char in value)):
            raise ValueError("invalid stack request header")
        lowered = name.lower()
        if lowered in seen or lowered in {"host", "connection", "transfer-encoding", "content-length"}:
            raise ValueError("stack request overrides a managed header")
        seen.add(lowered)
        fields.append((name, value))
    target = parsed.path or "/"
    if parsed.query:
        target += "?" + parsed.query
    return parsed, target, tuple(fields)


def request(url: str, *, identity: IdentitySnapshot,
            configured_authority: str | None = None, method: str = "GET",
            headers: Mapping[str, str] | None = None, body: bytes | None = None,
            timeout: float = 20.0, max_response_bytes: int | None = 8_388_608,
            response_limits: Mapping[int, int] | None = None,
            read_response_body: bool = True) -> StackResponse:
    """Prove the intended service, send once, read within bounds, and close.

    A failure before attaching the actual request has the fixed unproven error.
    Once an actual write is attempted, ordinary transport exceptions propagate:
    the caller must retain its own unavailable/unconfirmed-write semantics.
    No exception path retries, redirects, or opens a replacement connection.
    """
    started = time.monotonic()
    if not isinstance(identity, IdentitySnapshot):
        raise TypeError("an immutable local identity snapshot is required")
    authority = expected_authority(url, identity.authority if configured_authority is None
                                   else configured_authority)
    if authority != identity.authority:
        raise ServiceIdentityConfigurationInvalid("Expected authority differs from the identity snapshot.")
    if (isinstance(timeout, bool) or not isinstance(timeout, (float, int))
            or not math.isfinite(timeout) or timeout <= 0):
        raise ValueError("stack timeout must be positive and finite")
    def valid_limit(value: object) -> bool:
        return value is None or (type(value) is int and value >= 0)
    if not valid_limit(max_response_bytes):
        raise ValueError("response bound must be a nonnegative integer")
    limits = dict(response_limits or {})
    if any(type(status) is not int or not 100 <= status <= 599 or not valid_limit(limit)
           for status, limit in limits.items()) or type(read_response_body) is not bool:
        raise ValueError("invalid response read policy")
    parsed, target, actual_fields = _request_inputs(url, method, headers, body)
    required_address = literal_authority_address(url, authority, role=identity.role)
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    operation = _Budget(started + timeout)
    connection = _Connection(parsed.hostname, port, operation)
    try:
        try:
            if required_address is None or connection.host == required_address:
                address = _resolve(connection.host, connection.port, operation)
            else:
                address = _resolve(connection.host, connection.port, operation, required_address=required_address)
            proof_budget = _Budget(min(operation.deadline, time.monotonic() + PROOF_TIMEOUT))
            connection.budget = proof_budget
            pinned = _connect(connection.host, parsed.scheme == "https", proof_budget, address)
            connection.pinned = pinned
            connection.sock = pinned
            _prove(connection, identity, pinned, proof_budget)
            _assert_live(connection, pinned, proof_budget)
        except Exception as cause:
            error = cause if isinstance(cause, ServiceIdentityUnproven) else ServiceIdentityUnproven()
            if connection.pinned is not None:
                # Lifecycle must retain an observed listener even if that peer
                # disappears before a separate credential-free liveness check.
                error.endpoint_reachable = True
            raise error from None
        connection.budget = operation
        connection.proof = False
        # No actual header, code body or sensitive path was attached to the
        # connection until MAC, persistence, ownership and deadlines all passed.
        try:
            connection.putrequest(method, target, skip_accept_encoding=True)
            for name, value in actual_fields:
                connection.putheader(name, value)
            if body is not None:
                connection.putheader("Content-Length", str(len(body)))
            connection.putheader("Connection", "close")
            connection.endheaders(body)
        except Exception:
            if not connection.actual_write_started:
                raise ServiceIdentityUnproven() from None
            raise
        response = connection.getresponse()
        metadata = StackResponse(response.status, response.reason, tuple(response.getheaders()), b"")
        if not read_response_body:
            return metadata
        limit = limits.get(response.status, max_response_bytes)
        try:
            received = response.read() if limit is None else response.read(limit + 1)
            if limit is not None and len(received) > limit:
                raise ResponseTooLarge("stack response exceeds the caller's bound")
            if response.length is not None and response.length != 0:
                raise http.client.IncompleteRead(received, response.length)
        except Exception as error:
            error.stack_response = metadata
            raise
        return StackResponse(metadata.status, metadata.reason, metadata.headers, received)
    finally:
        connection.finish()
