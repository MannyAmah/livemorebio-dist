"""The one egress check (L0-R16): no free text leaves the machine.

Every outbound HTTP request to a third-party service goes through :func:`urlopen`,
which calls :func:`check_request` before anything is sent. A request passes
only when it matches a route of its destination in ``egress_destinations.py``:
the method, the path, the query keys and the JSON body shape are fixed there,
and each variable part holds an identifier that matches the destination's own
identifier grammar, or a term of one of the product's local vocabularies.
Anything else raises :class:`EgressRefused` (``EGRESS_VALUE_NOT_ALLOWED``)
before a connection is opened. The refusal names the code, the reason and, when
the host is known, the destination id from the data; never the URL or a value.
Neo4j graph exports use :func:`check_graph_export` before creating the driver;
every string in their detached payload passes the same grammar/vocabulary
admission engine, using the graph policy in ``egress_destinations.py``.

The product's own services (Aegle, LIFE, Cendos, the notebook and the console
session) are not third parties: their clients use the stack transport to
configured product addresses. ``tests/test_l0_egress.py`` lists every outbound
client in the shipped code, classifies each, and fails on a third-party client
that does not pass the corresponding HTTP or graph admission check.
"""
from __future__ import annotations

import functools
import importlib
import json
import re
import urllib.parse
import urllib.request
from typing import Any, Iterable

from .egress_destinations import DESTINATIONS, GRAMMARS, NEO4J_VALUE_SLOT, VOCABULARIES

EGRESS_VALUE_NOT_ALLOWED = "EGRESS_VALUE_NOT_ALLOWED"
EGRESS_REFUSAL_REASON = (
    "a request to a third-party service may carry only identifiers of that service or terms of this "
    "product's vocabularies; this one carried another value, so nothing was sent"
)
EGRESS_REFUSAL_STATUS = 422
_MAX_BODY_BYTES = 64 * 1024
_MAX_LIST = 64
_SLOT = re.compile(r"\{([^{}]+)\}")


class EgressRefused(Exception):
    """A typed refusal of an outbound request. It holds no URL and no value.

    ``destination`` is a fixed id from ``egress_destinations.py`` when the host
    is a known destination, else ``None``.
    """

    code = EGRESS_VALUE_NOT_ALLOWED
    reason = EGRESS_REFUSAL_REASON

    def __init__(self, destination: str | None = None) -> None:
        super().__init__(f"{EGRESS_VALUE_NOT_ALLOWED}: {EGRESS_REFUSAL_REASON}")
        self.destination = destination

    def payload(self) -> dict[str, str]:
        body = {"code": self.code, "error": self.reason}
        if self.destination is not None:
            body["destination"] = self.destination
        return body


# ------------------------------------------------------------- vocabularies

def _normal(term: str) -> str:
    return " ".join(term.split()).casefold()


def _terms(values: Iterable[Any]) -> frozenset[str]:
    out: set[str] = set()
    for value in values:
        if isinstance(value, str) and value.strip():
            out.add(_normal(value))
            if "_" in value:
                out.add(_normal(value.replace("_", " ")))
    return frozenset(out)


def _compound_terms() -> frozenset[str]:
    from .discovery.pipeline import PHYTO
    from .engines import foods, hepatic_pk
    from .life_system.graph import DRUG_INDICATION
    from .life_system.knowledge import get_kb
    from .life_system.reference import dynamics
    from .life_system.reference.build_seed import DRUGS

    names: list[Any] = [*DRUGS, *dynamics.DRUG_EFFECTS, *dynamics.COMPOUNDS, *DRUG_INDICATION,
                        *hepatic_pk.DRUGS]
    names += [compound for compounds in foods.PHYTOCHEMICALS.values() for compound in compounds]
    names += [row[0] for rows in PHYTO.values() for row in rows]
    for drug in get_kb().drugs:
        names += [drug.get("query"), drug.get("name")]
    return _terms(names)


def _food_terms() -> frozenset[str]:
    from .discovery.pipeline import PHYTO
    from .engines import foods
    from .life_system.reference import dynamics

    return _terms([*foods.PHYTOCHEMICALS, *foods.CURATED_MACROS, *dynamics.COMPOUNDS, *PHYTO])


def _reference_terms() -> frozenset[str]:
    from .life_system.knowledge import get_kb
    from .life_system.reference.knowledgebase import disease_terms

    names: list[Any] = []
    for disease in get_kb().diseases:
        names += [disease.get("query"), disease.get("name"), *disease_terms(disease)]
    return _terms(names)


def _organ_terms() -> frozenset[str]:
    from .anatomy.meshes import CATALOG

    return _terms(CATALOG)


def _reference_graph_terms() -> frozenset[str]:
    from .life_system.graph import KnowledgeGraph
    from .life_system.knowledge import KnowledgeBase

    # A fresh package seed keeps runtime additions to the shared knowledge base
    # from promoting themselves into the outbound vocabulary.
    graph = KnowledgeGraph(KnowledgeBase()).g
    names = ["Entity", "RELATED_TO", "source_key", "left", "right", "label",
             "relationship", "properties", "nodes", "edges"]
    for key, properties in graph.nodes(data=True):
        names.append(str(key))
        names.extend(properties)
        names.extend(value for value in properties.values() if isinstance(value, str))
    for left, right, properties in graph.edges(data=True):
        names.extend((str(left), str(right)))
        names.extend(properties)
        names.extend(value for value in properties.values() if isinstance(value, str))
    # Empty identifiers already occur in the shipped graph and carry no text.
    return _terms(names) | {""}


def _pinned(module: str) -> frozenset[str]:
    return frozenset(importlib.import_module(module).pinned_source_urls())


_PROVIDERS = {
    "compound_term": _compound_terms,
    "food_term": _food_terms,
    "reference_term": _reference_terms,
    "organ_term": _organ_terms,
    "reference_graph_term": _reference_graph_terms,
    "pinned_model_asset": lambda: _pinned("livemorebio.model_assets"),
    "pinned_atlas_source": lambda: _pinned("livemorebio.anatomy.atlas_reference"),
    "pinned_mesh_source": lambda: _pinned("livemorebio.anatomy.meshes"),
    "pinned_population_source": lambda: _pinned("livemorebio.aegle.population_sources"),
}


@functools.lru_cache(maxsize=None)
def vocabulary(name: str) -> frozenset[str]:
    """The terms of one local vocabulary (normalised; pinned URLs exact)."""
    if name not in VOCABULARIES:
        raise KeyError(name)
    return _PROVIDERS[name]()


def is_vocabulary_term(name: str, value: Any) -> bool:
    """Whether ``value`` is a term of the local vocabulary ``name`` (for routes that admit terms only)."""
    return isinstance(value, str) and _normal(value) in vocabulary(name)


@functools.lru_cache(maxsize=None)
def _grammar(name: str) -> re.Pattern[str]:
    return re.compile(GRAMMARS[name]["pattern"])


def _const(reference: str) -> Any:
    module, _, attribute = reference.rpartition(":")
    return getattr(importlib.import_module(module), attribute)


def _slot_admits(spec: str, value: Any) -> bool:
    """Whether ``value`` fills the slot ``spec`` (``name``, ``a|b`` or ``const:module:NAME``)."""
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        value = str(value)
    if not isinstance(value, str):
        return False
    if spec.startswith("const:"):
        return value == _const(spec[len("const:"):])
    for name in spec.split("|"):
        if name in GRAMMARS:
            if _grammar(name).fullmatch(value):
                return True
        elif name in VOCABULARIES:
            if (value if name.startswith("pinned_") else _normal(value)) in vocabulary(name):
                return True
        else:
            raise KeyError(f"unknown slot {name}")
    return False


def _template_admits(template: Any, value: Any) -> bool:
    """Match a JSON value against a route template; a whole-string ``{slot}`` admits a slot value."""
    if isinstance(template, str):
        whole = _SLOT.fullmatch(template)
        if whole:
            return _slot_admits(whole.group(1), value)
        return isinstance(value, str) and value == template
    if isinstance(template, list):
        if len(template) == 1 and not isinstance(template[0], (list, dict)) and isinstance(value, list):
            return 0 < len(value) <= _MAX_LIST and all(_template_admits(template[0], item) for item in value)
        return isinstance(value, str) and value in template
    if isinstance(template, dict):
        return (isinstance(value, dict) and set(value) == set(template)
                and all(_template_admits(template[key], value[key]) for key in template))
    return template == value and type(template) is type(value)


def _path_admits(template: str, path: str) -> bool:
    pattern, slots, position = "", [], 0
    for match in _SLOT.finditer(template):
        pattern += re.escape(template[position:match.start()]) + "([^/?#]+)"
        slots.append(match.group(1))
        position = match.end()
    pattern += re.escape(template[position:])
    found = re.fullmatch(pattern, path)
    if found is None:
        return False
    return all(_slot_admits(spec, urllib.parse.unquote(raw, errors="strict"))
               for spec, raw in zip(slots, found.groups()))


def _query_admits(template: dict[str, Any], query: list[tuple[str, str]]) -> bool:
    keys = [key for key, _ in query]
    if len(keys) != len(set(keys)) or set(keys) != set(template):
        return False
    return all(_template_admits(template[key], value) for key, value in query)


def _bases(destination: dict) -> list[str]:
    bases = list(destination.get("bases", []))
    resolver = destination.get("configured_base")
    if resolver:
        configured = _const(resolver)()
        if isinstance(configured, str) and configured.startswith("https://"):
            bases.append(configured)
    return bases


def check_request(url: str, *, method: str = "GET", body: bytes | str | None = None) -> str:
    """Return the destination id the request matches, or raise :class:`EgressRefused`.

    Nothing is sent here. ``body`` is the request body as it would be sent.
    """
    try:
        parts = urllib.parse.urlsplit(url)
        if (parts.scheme != "https" or not parts.hostname or parts.username is not None
                or parts.password is not None or parts.fragment):
            raise ValueError("not a plain HTTPS URL")
        target = urllib.parse.urlunsplit((parts.scheme, parts.netloc, parts.path, "", ""))
        query = urllib.parse.parse_qsl(parts.query, keep_blank_values=True,
                                       strict_parsing=bool(parts.query), errors="strict")
    except (ValueError, UnicodeError):
        raise EgressRefused() from None
    method = (method or "GET").upper()
    payload: Any = None
    if body is not None:
        raw = body.encode("utf-8") if isinstance(body, str) else body
        if not isinstance(raw, (bytes, bytearray)) or len(raw) > _MAX_BODY_BYTES:
            raise EgressRefused()
        try:
            payload = json.loads(bytes(raw).decode("utf-8"))
        except (ValueError, UnicodeError):
            raise EgressRefused() from None
    best: tuple[int, str, dict, str] | None = None
    for identifier, destination in DESTINATIONS.items():
        for base in _bases(destination):
            if (target.startswith(base) or target == base.rstrip("/")) and (best is None or len(base) > best[0]):
                best = (len(base), identifier, destination, base)
    if best is None:
        raise EgressRefused()
    _, identifier, destination, base = best
    relative = target[len(base):] if target.startswith(base) else ""
    for route in destination["routes"]:
        try:
            if "pinned" in route:
                if (method == "GET" and payload is None
                        and _slot_admits(route["pinned"], urllib.parse.urlunsplit(
                            (parts.scheme, parts.netloc, parts.path, parts.query, "")))):
                    return identifier
                continue
            if route.get("method", "GET") != method:
                continue
            if not _path_admits(route["path"], relative):
                continue
            if not _query_admits(route.get("query", {}), query):
                continue
            if not _template_admits(route.get("body"), payload):
                continue
        except (ValueError, UnicodeError):
            continue
        return identifier
    raise EgressRefused(identifier)


def check_graph_export(payload: Any) -> Any:
    """Admit every string and return a detached Neo4j payload for the driver.

    Property names, node identities, labels, relationships and nested strings
    share the same allow-list. Binary and custom values are refused rather than
    allowing a driver to turn unchecked objects into transmitted text. Build
    containers directly so custom copy hooks cannot preserve caller aliases.
    """
    if type(payload) is str:
        if not _slot_admits(NEO4J_VALUE_SLOT, payload):
            raise EgressRefused("neo4j")
        return payload
    elif type(payload) is dict:
        copied = {}
        for key, value in payload.items():
            if type(key) is not str:
                raise EgressRefused("neo4j")
            check_graph_export(key)
            copied[key] = check_graph_export(value)
        return copied
    elif type(payload) in (list, tuple):
        copied = [check_graph_export(value) for value in payload]
        return tuple(copied) if type(payload) is tuple else copied
    elif payload is not None and type(payload) not in (bool, int, float):
        raise EgressRefused("neo4j")
    return payload


def urlopen(request: urllib.request.Request | str, *, timeout: float, opener: Any = None) -> Any:
    """Check a third-party request, then send it. The only sending path for third-party requests.

    ``opener`` is the caller's own opener (a redirect policy or the licensed
    credential transport); without one the default urllib opener sends.
    """
    if isinstance(request, str):
        url, method, body = request, "GET", None
    else:
        url, method, body = request.full_url, request.get_method(), request.data
    check_request(url, method=method, body=body)
    if opener is not None:
        return opener.open(request, timeout=timeout)
    return urllib.request.urlopen(request, timeout=timeout)


def install_egress_refusal_handler(app) -> None:
    """Answer an egress refusal raised anywhere in a service's routes with its typed 422."""
    from fastapi.responses import JSONResponse

    @app.exception_handler(EgressRefused)
    async def egress_refused(_request, error: EgressRefused):
        return JSONResponse(error.payload(), status_code=EGRESS_REFUSAL_STATUS,
                            headers={"Cache-Control": "no-store"})
