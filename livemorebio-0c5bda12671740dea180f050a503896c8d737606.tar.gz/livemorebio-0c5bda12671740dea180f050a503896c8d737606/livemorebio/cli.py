"""livemore — launch and orchestrate the LivemoreBio infrastructure.

The three infrastructures run as independent services that discover each other
through a shared registry and cooperate in real time:

    livemore start all        # or: livemore start LIFE / Aegle / Cendos
    livemore status
    livemore open             # open the Aegle console
    livemore stop all
"""
from __future__ import annotations
import argparse, json, os, secrets, signal, subprocess, sys, time, urllib.request
import urllib.error
from . import __version__, registry as R

SERVICES = {
    "LIFE":   ("livemorebio.life_system.service", 8851),
    "Aegle":  ("livemorebio.aegle.server", 8850),
    "Cendos": ("livemorebio.cendos.service", 8852),
}
PYTHON = sys.executable
TOKEN_ENV = "LIVEMORE_API_TOKEN"
TOKEN_FILE = os.path.join(R.REG_DIR, "api-token")


def _report_data_dir_acl(message: str) -> None:
    # `livemore token` stdout is also consumed by shell substitutions.
    print(message, file=sys.stderr)


def ensure_api_token() -> str:
    """Load or create the loopback mutation token with owner-only permissions."""
    configured = os.environ.get(TOKEN_ENV, "").strip()
    if configured:
        return configured
    from .security import _publish_secret, read_own_secret, refuse_linked_secrets
    # Before anything is made: a token that is a link may lead into another
    # stack's directory, and one that is not a regular file is not a token.
    directory_status = R.ensure_data_dir(report=_report_data_dir_acl)
    refuse_linked_secrets(R.REG_DIR)
    try:
        token = read_own_secret(TOKEN_FILE, tighten=True)
    except FileNotFoundError:
        token = ""
    if not token:
        from ._platform import require_posix

        require_posix("Credential creation")
        try:
            token = read_own_secret(TOKEN_FILE, tighten=True)
        except FileNotFoundError:
            token = ""
        if not token:
            R.require_secret_creation(directory_status)
            candidate = secrets.token_urlsafe(32)
            temporary = f"{TOKEN_FILE}.{os.getpid()}.{secrets.token_hex(8)}.tmp"
            descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            try:
                with os.fdopen(descriptor, "w", encoding="utf-8") as token_file:
                    token_file.write(candidate + "\n")
                    token_file.flush()
                    os.fsync(token_file.fileno())
                _publish_secret(temporary, TOKEN_FILE)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)
            token = read_own_secret(TOKEN_FILE, tighten=True)
            if not token:
                raise RuntimeError("mutation token initialization did not produce a token")
    os.environ[TOKEN_ENV] = token
    return token


def _service_url(name: str) -> str:
    """Dial the trusted container profile or the native published default."""
    configured = os.environ.get(f"LIVEMORE_{name.upper()}_URL", "").strip()
    return configured.rstrip("/") if configured else f"http://127.0.0.1:{SERVICES[name][1]}"


def _health(port):
    from .stack_readiness import proved_health

    name = next(name for name, (_, service_port) in SERVICES.items() if service_port == port)
    return proved_health(name.lower(), f"http://127.0.0.1:{port}")


def _client_health(port: int) -> dict | None:
    """Read/status clients may dial names; lifecycle preflights check real binds."""
    from .stack_readiness import proved_health

    name = next(name for name, (_, service_port) in SERVICES.items() if service_port == port)
    dial = _service_url(name)
    if dial == f"http://127.0.0.1:{port}":
        return _health(port)
    return proved_health(name.lower(), dial)


def _service_status(port):
    from .stack_readiness import READINESS_ERRORS, ServiceHealthUnavailable, failed_status

    try:
        health = _client_health(port)
    except (*READINESS_ERRORS, ServiceHealthUnavailable) as error:
        name = next(name for name, (_, service_port) in SERVICES.items() if service_port == port)
        return failed_status(error, _service_url(name))
    ready = health is not None
    return {"reachable": ready, "ready": ready, "healthy": ready, "health": health,
            "reason_code": None if ready else "SERVICE_UNAVAILABLE"}


def _wait_for_services(names, *, timeout: float = 15.0,
                       failure_codes: dict[str, str] | None = None) -> list[str]:
    """Prove every poll and require two consecutive valid health responses."""
    from .stack_readiness import ServiceHealthUnavailable
    from .stack_transport import ServiceIdentityUnproven

    pending = [name for name in names if name in SERVICES]
    if failure_codes is not None:
        failure_codes.clear()
    consecutive = {name: 0 for name in pending}
    last_unproven: dict[str, str | None] = {name: None for name in pending}
    deadline = time.monotonic() + timeout
    while pending:
        for name in list(pending):
            try:
                health = _health(SERVICES[name][1])
                last_unproven[name] = None
            except (ServiceIdentityUnproven, ServiceHealthUnavailable) as error:
                # A launched port forwarder may accept before its app imports.
                # Each poll still proves afresh and carries no credential.
                health = None
                # Keep the fixed text of the cause; it never holds a remote byte.
                last_unproven[name] = str(error) if isinstance(error, ServiceIdentityUnproven) else None
            if health:
                consecutive[name] += 1
                if consecutive[name] >= 2:
                    pending.remove(name)
            else:
                consecutive[name] = 0
        if not pending or time.monotonic() >= deadline:
            break
        time.sleep(min(0.2, max(0, deadline - time.monotonic())))
    for name in pending:
        if last_unproven[name]:
            print(f"  {name}: {last_unproven[name]}")
            if failure_codes is not None:
                failure_codes[name] = ServiceIdentityUnproven.code
    return pending


def _wait_for_stopped_services(names, *, timeout: float = 10.0) -> list[str]:
    """Wait for port absence; a remaining listener has unknown ownership."""
    from .stack_readiness import listener_reachable

    pending = [name for name in names if name in SERVICES]
    deadline = time.monotonic() + timeout
    while pending:
        pending = [name for name in pending if listener_reachable(f"http://127.0.0.1:{SERVICES[name][1]}")]
        if not pending or time.monotonic() >= deadline:
            break
        time.sleep(0.2)
    return pending



# Stores that have no internal default: without explicit configuration the
# continuous LIFE/Aegle execution loop and virtual Patch sessions refuse to
# start. The launcher configures them under the private data directory, which
# is explicit configuration by the operator's own launcher, not a fallback to
# another running instance. An operator-supplied value is never overridden.
_LAUNCH_STORES = {
    "LIVEMORE_EXECUTION_STORE": ("executions", "state.sqlite3"),
    "LIVEMORE_VIRTUAL_EXECUTION_STORE": ("virtual-executions", "state.sqlite3"),
    "LIVEMORE_PATCH_JOURNAL": (None, "patch-telemetry.jsonl"),
}


def _service_environment() -> dict:
    """Child environment with private store paths and the local service URL."""
    environment = dict(os.environ)
    # Peer opt-in belongs to Compose; the process authority belongs to one child.
    environment.pop("LIVEMORE_CONSOLE_PEER", None)
    environment.pop("LIVEMORE_SERVICE_IDENTITY_AUTHORITY", None)
    for name, (directory, filename) in _LAUNCH_STORES.items():
        if environment.get(name, "").strip():
            continue
        parent = os.path.join(R.REG_DIR, directory) if directory else R.REG_DIR
        os.makedirs(parent, mode=0o700, exist_ok=True)
        environment[name] = os.path.join(parent, filename)
    environment.setdefault("LIVEMORE_AEGLE_URL", f"http://127.0.0.1:{SERVICES['Aegle'][1]}")
    # Service output is redirected to a file, where Python block-buffers it. An
    # operator reading <name>.log during an incident would otherwise find it empty.
    environment["PYTHONUNBUFFERED"] = "1"
    return environment


_IDENTITY_PEERS = {
    "Aegle": "LIVEMORE_AEGLE_IDENTITY_AUTHORITY",
    "LIFE": "LIVEMORE_LIFE_IDENTITY_AUTHORITY",
    "Cendos": "LIVEMORE_CENDOS_IDENTITY_AUTHORITY",
}


def ensure_service_identity_key() -> str:
    """Provision trust at launch, without caching a file key in this process's env."""
    from .service_identity import encode_identity_key, service_identity_key

    return encode_identity_key(service_identity_key(create=True))


def _identity_peer_environment(environment: dict, *, native: bool = True) -> None:
    from .service_identity_config import expected_authority

    for service, (_, port) in SERVICES.items():
        variable = _IDENTITY_PEERS[service]
        origin = f"http://127.0.0.1:{port}"
        dial = environment.get(f"LIVEMORE_{service.upper()}_URL", "") if native else ""
        environment[variable] = expected_authority(dial if dial.strip() else origin,
                                                   os.environ.get(variable))


def rotate_identity() -> int:
    """Replace only a stopped, file-managed stack's admitted identity generation."""
    from .service_identity import (IDENTITY_KEY_ENV, remove_identity_file,
                                   service_identity_key, stack_id)

    if IDENTITY_KEY_ENV in os.environ:
        print("  Identity is externally managed by LIVEMORE_SERVICE_IDENTITY_KEY; replace it externally, then restart all services and clients.")
        return 2
    try:
        with open(R.REG, "r", encoding="utf-8") as record_file:
            records = json.load(record_file)
    except FileNotFoundError:
        records = {}
    except (OSError, ValueError):
        print("  Identity rotation refused: launcher process records cannot be read. Stop the stack's service processes and repair or remove the launcher records before retrying.")
        return 2
    if not isinstance(records, dict):
        print("  Identity rotation refused: launcher process records are invalid. Run `livemore stop all` and check the records before retrying.")
        return 2
    for record in records.values():
        pid = record.get("pid") if isinstance(record, dict) else None
        if type(pid) is not int or pid <= 0:
            print("  Identity rotation refused: launcher process records are invalid. Run `livemore stop all` and check the records before retrying.")
            return 2
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            continue
        except OSError:
            # Permission errors and unknown process state cannot establish shutdown.
            pass
        print("  Identity rotation refused: a recorded stack process is live or cannot be checked. Run `livemore stop all` before retrying.")
        return 2
    remove_identity_file(R.REG_DIR)
    key = service_identity_key(create=True)
    print(f"  Identity replaced; SID {stack_id(key).hex()[:16]}.")
    print("  Restart every service and recreate attached clients with the updated launcher; use `livemore start all` or `livemore up`.")
    return 0



def _service_command(module: str) -> list:
    """Run the service under its real module name, not as ``__main__``.

    ``python -m package.module`` executes the file as ``__main__``. Routers that
    do ``from . import server`` then import a second copy of the module, with a
    separate selected-state, model-source authority and execution manager. The
    two copies disagree, which surfaced as an unavailable model on the execution
    routes while the rest of the console reported the twin as ready.
    """
    return [PYTHON, "-B", "-c",
            "from importlib import import_module; import_module(%r).main()" % module]


def start(names) -> int:
    from .security import ensure_patch_security_keys, refuse_linked_secrets
    R.ensure_data_dir(report=_report_data_dir_acl)
    refuse_linked_secrets(R.REG_DIR)
    identity = ensure_service_identity_key()
    ensure_api_token()
    ensure_patch_security_keys()
    names = list(SERVICES) if (not names or names == ["all"]) else names
    R.ensure_data_dir(report=_report_data_dir_acl)
    environment = _service_environment()
    environment["LIVEMORE_SERVICE_IDENTITY_KEY"] = identity
    _identity_peer_environment(environment)
    from .service_identity_config import service_authority
    authorities = {
        name: service_authority("127.0.0.1", SERVICES[name][1],
                                environment[_IDENTITY_PEERS[name]])
        for name in names if name in SERVICES
    }
    # Validate all occupied destinations before launching any requested child.
    existing = {name: _health(SERVICES[name][1]) for name in names if name in SERVICES}
    expected = []
    for name in names:
        if name not in SERVICES:
            print(f"  unknown service: {name}"); continue
        expected.append(name)
        mod, port = SERVICES[name]
        if existing[name]:
            print(f"  {name:7} already running on :{port}"); continue
        logf = os.path.join(R.REG_DIR, f"{name}.log")
        # A caller may be standing in an older checkout. Children must use the
        # same package as this launcher, without mutating a verified release's bytecode.
        package_root = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        with open(logf, "w", encoding="utf-8") as log_file:
            child_environment = dict(environment)
            child_environment["LIVEMORE_SERVICE_IDENTITY_AUTHORITY"] = authorities[name]
            p = subprocess.Popen(_service_command(mod), stdout=log_file,
                                 stderr=subprocess.STDOUT, start_new_session=True,
                                 cwd=package_root, env=child_environment)
        R.register(name, port, p.pid)
        print(f"  starting {name:7} on :{port}  (pid {p.pid}, log {logf})")
    failure_codes: dict[str, str] = {}
    pending = _wait_for_services(expected, failure_codes=failure_codes)
    status()
    if pending:
        print(f"  startup timeout: {', '.join(pending)} did not prove readiness within 15 seconds")
        return 2 if any(failure_codes.get(name) == "SERVICE_IDENTITY_UNPROVEN" for name in pending) else 1
    return 0


def stop(names):
    if not names or names == ["all"] or "Aegle" in names:
        from .console_session import prune_console_launch_files
        prune_console_launch_files(R.REG_DIR, best_effort=True)
    reg = R.registry()
    names = list(reg) if (not names or names == ["all"]) else names
    stopped = []
    for name in names:
        info = reg.get(name)
        if not info:
            print(f"  {name} not in registry"); continue
        try:
            os.killpg(os.getpgid(info["pid"]), signal.SIGTERM)
        except Exception:
            try:
                os.kill(info["pid"], signal.SIGTERM)
            except Exception:
                pass
        R.unregister(name)
        stopped.append(name)
        print(f"  stopping {name}")
    pending = _wait_for_stopped_services(stopped)
    if pending:
        print(f"  shutdown timeout: a listener remains on the configured ports for {', '.join(pending)}; ownership is unknown")
    for name in stopped:
        if name not in pending:
            print(f"  stopped {name}")


def _report_service_refusal(error) -> int:
    """Print a service's typed refusal in the product's own voice."""
    payload = {}
    try:
        payload = json.loads(error.read().decode("utf-8", errors="replace"))
    except Exception:
        payload = {}
    code = payload.get("code") if isinstance(payload, dict) else None
    message = payload.get("error") if isinstance(payload, dict) else None
    print(f"\n  refused [{code or 'HTTP ' + str(error.code)}]")
    if message:
        print(f"  {message}")
    if code == "EXECUTION_SOURCE_REQUIRED" or code == "SELECTION_COMMIT_UNCONFIRMED":
        print("  A new workspace has no admitted twin yet. Create and activate one,")
        print("  then run this again.")
    print()
    return 2


def patch_journal(action, journal, *, apply=False, as_json=False):
    """Report, and on request repair, a journal the current protocol rejects."""
    from .life_patch import journal_repair

    explicit = bool(journal or os.environ.get("LIVEMORE_PATCH_JOURNAL"))
    path = journal or os.environ.get("LIVEMORE_PATCH_JOURNAL") or os.path.join(R.REG_DIR, "patch-telemetry.jsonl")
    if not explicit and not os.path.exists(path):
        # No journal at the default path is a fresh install, not a fault. A path
        # the operator named is different: a typo must not report "healthy".
        message = "no patch journal yet; it is created when the first telemetry record is admitted."
        print(json.dumps({"schema": "livemore.patch-journal-repair.v1", "journal": str(path),
                          "total_records": 0, "valid_records": 0, "invalid_records": [],
                          "repaired": False, "note": message}, indent=2, sort_keys=True)
              if as_json else f"\n  patch journal  {path}\n  {message}\n")
        return 0
    try:
        report = (journal_repair.inspect_journal(path) if action == "verify"
                  else journal_repair.quarantine_journal(path, apply=apply))
    except journal_repair.JournalRepairError as error:
        if as_json:
            print(json.dumps({"schema": journal_repair.REPORT_SCHEMA, "journal": str(path),
                              "error": str(error)}, indent=2, sort_keys=True))
        else:
            print(f"  {error}")
        return 2
    if as_json:
        print(json.dumps(report, indent=2, sort_keys=True))
        return 1 if report["invalid_records"] and not report["repaired"] else 0
    invalid = report["invalid_records"]
    print(f"\n  patch journal  {report['journal']}")
    print("  " + "-" * 52)
    print(f"  {report['total_records']} records · {report['valid_records']} valid · {len(invalid)} rejected")
    for item in invalid:
        print(f"    record {item['record_number']}: {item['reason']}")
    if not invalid:
        print("  every record is readable under the current protocol.")
    elif report["repaired"]:
        print(f"\n  set aside {len(invalid)} record(s); {report['valid_records']} remain replayable.")
        print(f"  quarantined records kept verbatim in {report['quarantine_file']}")
    elif action == "quarantine":
        print(f"\n  nothing was changed. Re-run with --apply to set aside {len(invalid)} record(s)")
        print(f"  into {report['quarantine_file']}, keeping the other {report['valid_records']}.")
    else:
        print("\n  run 'livemore patch-journal quarantine' to see what a repair would do.")
    print()
    return 1 if invalid and not report["repaired"] else 0


def status():
    print("\n  LivemoreBio infrastructure")
    print("  " + "-" * 52)
    for name, (mod, port) in SERVICES.items():
        readiness = _service_status(port)
        h = readiness["health"]
        state = ("\033[32m● up  \033[0m" if readiness["ready"] else
                 "\033[33m○ not ready\033[0m" if readiness["reason_code"] == "SERVICE_HEALTH_UNAVAILABLE" else
                 "\033[33m○ unproven endpoint\033[0m" if readiness["reachable"] else "\033[90m○ down\033[0m")
        extra = ""
        if not readiness["ready"] and readiness["reason_code"] != "SERVICE_UNAVAILABLE":
            extra = readiness["reason_code"]
        if h and name == "LIFE":
            extra = f"{h.get('diseases','?')} diseases · {h.get('variants','?')} associated genes"
        if h and name == "Aegle":
            extra = f"twin: {h.get('profile','')}"
        if h and name == "Cendos":
            extra = "in-silico assays ready"
        print(f"  {state} {name:7} :{port}   {extra}")
    reg = R.registry()
    print("  " + "-" * 52)
    print(f"  registry: {R.REG}  ({len(reg)} registered)\n")


def open_console(print_url: bool = False) -> int:
    failure_output = sys.stderr if print_url else sys.stdout
    from .console_session import (ConsoleExchangeFailedError, ConsoleLaunchDirectoryUnsafeError,
                                  ConsolePeerRefusedError, ConsoleSessionError,
                                  print_console_instructions, request_console_launch, require_console_browser)
    from .security import CredentialFileError
    from .stack_readiness import READINESS_ERRORS, ServiceHealthUnavailable

    if not print_url:
        try:
            require_console_browser()
        except ConsoleExchangeFailedError as error:
            print(f"  refused [{error.code}]", file=failure_output)
            print(f"  {error}", file=failure_output)
            return 1
    port = SERVICES["Aegle"][1]
    try:
        healthy = _client_health(port)
    except (*READINESS_ERRORS, ServiceHealthUnavailable) as error:
        print(f"  refused [{error.code}]", file=failure_output)
        print(f"  {error}", file=failure_output)
        return 2
    if not healthy:
        print("  refused [CONSOLE_CODE_UNAVAILABLE]", file=failure_output)
        print("  Aegle is not running. Native: `livemore start Aegle`. Containers:", file=failure_output)
        location = "" if os.path.exists(_compose_file()) else " on the host"
        print(f"  run `livemore logs aegle`{location} for CONSOLE_PEER_UNRESOLVED and other start failures.",
              file=failure_output)
        return 1
    origin = f"http://127.0.0.1:{port}"
    try:
        if print_url:
            dial = _service_url("Aegle")
            if dial != origin:
                from .service_identity_config import expected_authority
                origin = expected_authority(dial, os.environ.get("LIVEMORE_AEGLE_IDENTITY_AUTHORITY"))
                print_console_instructions(origin, dial_origin=dial)
            else:
                print_console_instructions(origin)
        else:
            from .console_session import require_console_origin
            request_console_launch(require_console_origin(_service_url("Aegle")), R.REG_DIR)
    except CredentialFileError as error:
        # A linked credential needs its own remedy, not a token retry or restart.
        print(f"  refused [{error.code}]", file=failure_output)
        print(f"  {error}", file=failure_output)
        return 2
    except (*READINESS_ERRORS, ServiceHealthUnavailable) as error:
        print(f"  refused [{error.code}]", file=failure_output)
        print(f"  {error}", file=failure_output)
        return 2
    except ConsolePeerRefusedError:
        print("  refused [CONSOLE_PEER_REFUSED]", file=failure_output)
        print("  Aegle in a container started without the compose file's LIVEMORE_CONSOLE_PEER:",
              file=failure_output)
        print("  rebuild with `livemore up`. If the supplied compose file was used, the host", file=failure_output)
        print("  may not arrive from the bridge gateway (e.g. WSL2 or a Linux proxy setup).", file=failure_output)
        print("  That networking fails closed; see the launch guide, section 10. A rebuild will not help.",
              file=failure_output)
        return 2
    except ConsoleLaunchDirectoryUnsafeError as error:
        print(f"  refused [{error.code}]", file=failure_output)
        print(f"  {error}", file=failure_output)
        return 2
    except ConsoleExchangeFailedError as error:
        print(f"  refused [{error.code}]", file=failure_output)
        print(f"  {error}", file=failure_output)
        return 1
    except ConsoleSessionError:
        print("  refused [CONSOLE_CODE_UNAVAILABLE]", file=failure_output)
        print("  Console authorization failed. Check the operator token and restart Aegle.", file=failure_output)
        return 1
    if print_url:
        return 0
    print("  launch requested in your browser")
    print("  If a snap or flatpak browser cannot open the file, run `livemore open --print-url`.")
    return 0


def _compose_file() -> str:
    """The compose file `livemore up` uses, whatever the caller's directory."""
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(root, "docker-compose.yml")


def _compose(action: str, services: list[str] | None = None) -> int:
    """Containerized mode: `livemore up/down/logs` wrap docker compose
    against the repo's docker-compose.yml (three services + shared state volume).
    Single-box dev mode (`livemore start/stop`) is unchanged."""
    import shutil, subprocess
    if action == "down":
        from .console_session import prune_console_launch_files
        prune_console_launch_files(R.REG_DIR, best_effort=True)
    compose_file = _compose_file()
    if not os.path.exists(compose_file):
        print(f"  docker-compose.yml not found at {compose_file}"); return 1
    if not shutil.which("docker"):
        print("  docker is not installed or not on PATH — use `livemore start` for single-box mode."); return 1
    if action not in {"up", "down", "logs"}:
        raise ValueError("unsupported compose command")
    if action == "up":
        from .security import ensure_patch_security_keys, refuse_linked_secrets
        R.ensure_data_dir(report=_report_data_dir_acl)
        refuse_linked_secrets(R.REG_DIR)
        identity = ensure_service_identity_key()
        ensure_api_token()
        ensure_patch_security_keys()
        # Compose must not replace an unknown listener on a published port.
        for name in SERVICES:
            _health(SERVICES[name][1])
    environment = dict(os.environ)
    if action == "up":
        environment["LIVEMORE_SERVICE_IDENTITY_KEY"] = identity
        _identity_peer_environment(environment, native=False)
    if action in {"down", "logs"}:
        # Compose interpolates every service even for commands that never use
        # credentials. Satisfy interpolation without opening credential files.
        for name in (TOKEN_ENV, "LIVEMORE_PATCH_STORAGE_KEY", "LIVEMORE_PATCH_ADMISSION_HMAC_KEY",
                     "LIVEMORE_SERVICE_IDENTITY_KEY"):
            if not environment.get(name):
                environment[name] = f"unused-by-livemore-{action}"
    cmd = ["docker", "compose", "-f", compose_file]
    cmd += ["up", "-d", "--build"] if action == "up" else [action]
    if action == "logs":
        cmd += services or []
    print("  $ " + " ".join(cmd), flush=True)
    rc = subprocess.call(cmd, env=environment)
    if rc != 0:
        if action in {"down", "logs"}:
            print(f"  docker compose {action} ended with status {rc}; its output is above.")
        return rc
    if rc == 0 and action == "up":
        # A container's first start (a fresh image, or emulation) is slower than a native one.
        pending = _wait_for_services(list(SERVICES), timeout=120.0)
        if pending:
            print(f"  {', '.join(pending)} did not prove readiness; run `livemore logs` for start failures.")
            return 1
        print("  LIFE     http://127.0.0.1:8851  (/docs for OpenAPI)")
        print("  Aegle    http://127.0.0.1:8850  (/docs for OpenAPI)")
        print("  Cendos   http://127.0.0.1:8852  (/docs for OpenAPI)")
        print("  Console: run `livemore open` (a bare URL has no session)")
    return rc


def main():
    from .security import CredentialFileError
    from .service_identity import IdentityError
    from .service_identity_config import ServiceIdentityConfigurationInvalid
    from .stack_transport import ServiceIdentityUnproven
    from .execution_client import ContinuousClientError
    from .stack_readiness import ServiceHealthUnavailable
    try:
        _main()
    except ContinuousClientError as error:
        if error.code != "SERVICE_IDENTITY_UNPROVEN":
            raise
        print(str(error))
        raise SystemExit(2) from None
    except R.DataDirSecurityError as error:
        if error.code != "STACK_DATA_DIR_HOME":
            print(str(error), file=sys.stderr)
        raise SystemExit(2) from None
    except CredentialFileError as error:
        print(f"  refused [{error.code}]")
        print(f"  {error}")
        raise SystemExit(2) from None
    except (IdentityError, ServiceIdentityConfigurationInvalid, ServiceIdentityUnproven, ServiceHealthUnavailable) as error:
        print(f"  refused [{error.code}]")
        print(f"  {error}")
        raise SystemExit(2) from None


def _main():
    # New command families validate raw tokens themselves. argparse's error
    # output otherwise echoes a private first option before REMAINDER captures it.
    if len(sys.argv) > 1 and sys.argv[1] == "atlas" and sys.argv[2:] not in (["--help"], ["-h"]):
        from .sdk import Platform
        from .atlas_commands import run_atlas_command, safe_atlas_error
        from .atlas_client import AtlasClientError
        try:
            run_atlas_command(Platform(mode="attach"), sys.argv[1:])
        except AtlasClientError as error:
            print(safe_atlas_error(error))
            raise SystemExit(1) from None
        return
    if len(sys.argv) > 1 and sys.argv[1] in {"execution", "patch"} and sys.argv[2:] not in (["--help"], ["-h"]):
        from .sdk import Platform
        from .execution_commands import run_continuous_command, safe_error
        from .execution_client import ContinuousClientError
        try:
            run_continuous_command(Platform(mode="attach"), sys.argv[1:])
        except ContinuousClientError as error:
            print(safe_error(error))
            raise SystemExit(1) from None
        return
    ap = argparse.ArgumentParser(prog="livemore", description="LivemoreBio infrastructure control")
    ap.add_argument("--version", action="version", version=f"LivemoreBio {__version__}")
    sub = ap.add_subparsers(dest="cmd")
    atlas = sub.add_parser("atlas", help="attached reference anatomy status and installation", description=(
        "Attached reference-only anatomy. atlas status [json=true]; "
        "atlas install bp3d-4.0-20130619-surface-core-v1 [json=true]. "
        "Uses the running Aegle service; does not start a server or experiment."))
    atlas.add_argument("arguments", nargs=argparse.REMAINDER)
    for family in ("execution", "patch"):
        command = sub.add_parser(family, help="attached continuous commands; see livemore attach → help")
        command.add_argument("arguments", nargs=argparse.REMAINDER)
    evidence = sub.add_parser("evidence", help="offline evidence signing identity commands")
    evidence_commands = evidence.add_subparsers(dest="evidence_command", required=True)
    signing = evidence_commands.add_parser("signing", help="inspect or initialize the stack's signing identity offline")
    signing_commands = signing.add_subparsers(dest="signing_action", required=True)
    signing_commands.add_parser("init", help="initialize the stack key offline", description=(
        "Create this stack's evidence signing key offline and print public recipient metadata. "
        "Refuses an existing key; never attaches to a service."))
    signing_commands.add_parser("status", help="print public signing metadata offline", description=(
        "Inspect the configured signing identity offline without creating a key or contacting a service."))
    sp = sub.add_parser("start"); sp.add_argument("services", nargs="*")
    st = sub.add_parser("stop"); st.add_argument("services", nargs="*")
    sub.add_parser("status")
    console = sub.add_parser("open", help="open the authenticated Aegle console")
    console.add_argument("--print-url", action="store_true", help=(
        "print the connection page URL and separate one-time code instead of opening a browser; "
        "for a browser on another machine, e.g. Windows with Docker Desktop: "
        "run inside the aegle container"))
    sub.add_parser("token", help="print the local mutation token for the console prompt")
    identity = sub.add_parser("identity", help="manage the stopped stack's service identity")
    identity.add_argument("action", choices=("rotate",))
    sub.add_parser("manifest", help="print whole-human system capability and maturity JSON")
    models = sub.add_parser("models", help="install or verify pinned reference metabolic assets")
    models.add_argument("action", choices=("catalog", "install", "status", "check", "restore"))
    models.add_argument("model_id", nargs="?", default="human-gem")
    ws = sub.add_parser("workspace", help="print the live multiscale Atlas projection")
    ws.add_argument("--full", action="store_true", help="print the complete projection JSON")
    sources = sub.add_parser("sources", help="query governed scientific source lifecycle and routing")
    sources.add_argument("--workflow")
    sources.add_argument("--collection")
    sources.add_argument("--lifecycle")
    sources.add_argument("--limit", type=int, default=50)
    sources.add_argument("--offset", type=int, default=0)
    sources.add_argument("--attach", action="store_true", help="query the running Aegle service")
    sources.add_argument("--full", action="store_true", help="print complete bounded JSON response")
    doc = sub.add_parser("doctor", help="fresh-machine readiness report (exit 1 when a required check fails)")
    doc.add_argument("--json", action="store_true"); doc.add_argument("--network", action="store_true")
    nb = sub.add_parser("notebook", help="launch Jupyter Lab with a private one-time login",
                        description="Launch the SDK workspace using a private file and one-time login code. Ctrl-C stops the supervised session.")
    nb.add_argument("--dir", help="notebook directory (default: <data dir>/notebooks)")
    nb.add_argument("--no-browser", action="store_true", help="print the clean login URL and a single-use code (120 s)")
    nb.add_argument("--port", type=int, default=8888)
    sub.add_parser("notebook-code", help="print a fresh single-use login code for this stack's running notebook session")
    pg = sub.add_parser("programs", help="insulin and botanical programs: list, or run one non-interactively")
    pg.add_argument("action", choices=("list", "run"), nargs="?", default="list")
    pg.add_argument("program_id", nargs="?")
    pg.add_argument("--dose-mg", type=float); pg.add_argument("--cohort", type=int); pg.add_argument("--seed", type=int)
    pg.add_argument("--attach", action="store_true"); pg.add_argument("--json", action="store_true")
    pj = sub.add_parser("patch-journal", help="inspect or repair the local LIFE Patch telemetry journal")
    pj.add_argument("action", choices=("verify", "quarantine"), nargs="?", default="verify")
    pj.add_argument("--journal", help="journal path (default: $LIVEMORE_PATCH_JOURNAL or <data dir>/patch-telemetry.jsonl)")
    pj.add_argument("--apply", action="store_true",
                    help="quarantine only: actually set the invalid records aside (default: report and change nothing)")
    pj.add_argument("--json", action="store_true")
    sub.add_parser("up", help="containerized platform via docker compose")
    sub.add_parser("down", help="stop the containerized platform")
    logs = sub.add_parser("logs", help="show container logs for all or named services")
    logs.add_argument("services", nargs="*")
    sh = sub.add_parser("shell", help="interactive Livemore environment")
    sh.add_argument("--attach", action="store_true", help="drive the live running platform")
    sub.add_parser("attach", help="interactive shell attached to the live platform")
    rn = sub.add_parser("run", help="run a pipeline file of Livemore commands")
    rn.add_argument("pipeline"); rn.add_argument("--attach", action="store_true")
    a = ap.parse_args()
    from ._platform import POSIX, CONTAINER_GUIDANCE
    if not POSIX and a.cmd not in (None, "doctor"):
        print("  LivemoreBio requires POSIX file protections for local PHI-like state.")
        print("  " + CONTAINER_GUIDANCE)
        print("  Run `livemore doctor` for the full report.")
        raise SystemExit(2)
    if a.cmd == "evidence":
        from .evidence.signing_commands import run_signing_command
        raise SystemExit(run_signing_command(a.signing_action))
    # Stopping or inspecting containers needs no local credential directory.
    if (POSIX and a.cmd is not None and a.cmd not in {"down", "logs", "open", "stop", "doctor"} and os.path.isdir(R.REG_DIR)):
        # Directory-only repair reads no credential and precedes linked-file
        # refusal, including the pass over previously exposed owned files.
        # Console admission must inspect the original modes; shutdown never
        # makes credential-directory access a prerequisite.
        R.ensure_data_dir(report=_report_data_dir_acl)
    if a.cmd == "start":
        # Success returns as before; only a failed start sets the exit status.
        if code := start(a.services):
            raise SystemExit(code)
    elif a.cmd == "stop":
        stop(a.services)
    elif a.cmd == "open":
        raise SystemExit(open_console(print_url=a.print_url))
    elif a.cmd == "status":
        status()
    elif a.cmd == "patch-journal":
        raise SystemExit(patch_journal(a.action, a.journal, apply=a.apply, as_json=a.json))
    elif a.cmd == "manifest":
        from .foundation import whole_human_manifest
        print(json.dumps(whole_human_manifest(), indent=2, sort_keys=True))
    elif a.cmd == "models":
        from . import model_assets
        try:
            if a.action == "catalog":
                result = model_assets.catalog()
            elif a.action == "install":
                result = model_assets.install(a.model_id)
            elif a.action == "check":
                result = model_assets.check(a.model_id)
            elif a.action == "restore":
                result = model_assets.restore(a.model_id)
            else:
                result = model_assets.status(a.model_id)
            print(json.dumps(result, indent=2, sort_keys=True))
            if a.action == "check" and not result.get("available"):
                raise SystemExit(1)
        except model_assets.ModelAssetError as error:
            print(json.dumps({"available": False, "code": error.code, "error": str(error)}))
            raise SystemExit(1)
        except OSError:
            # L0-R11 round 3: a filesystem error is a typed refusal, never a traceback.
            code = "CARDIAC_MODEL_UNSAFE_PATH" if a.model_id == "cardiac" else "unsafe_path"
            print(json.dumps({"available": False, "code": code,
                              "error": "A model path could not be read or written; check its permissions and retry."}))
            raise SystemExit(1)
    elif a.cmd == "workspace":
        import urllib.error

        from .sdk import Platform
        try:
            workspace = Platform(mode="attach").workspace()
        except urllib.error.HTTPError as error:
            # A workspace with no admitted twin is refused with a typed code.
            # That is the service answering, not the command failing, so report
            # it rather than raising urllib's traceback at a first-run client.
            raise SystemExit(_report_service_refusal(error))
        if a.full:
            print(json.dumps(workspace, indent=2, sort_keys=True))
        else:
            systems = workspace["multiscale"]["systems"]
            executed = sum(
                item["execution_status"] in {"EXECUTED", "PARTIAL"} for item in systems
            )
            # A selected record without an admitted model binding has no active
            # execution. That is a reportable state, not an error.
            active = workspace["multiscale"]["active_execution"] or {}
            availability = workspace.get("model_availability") or {}
            summary = {
                "subject": workspace["multiscale"]["subject"],
                "contracts": len(systems),
                "executed_systems": executed,
                "patch": workspace["twin"]["patch"],
                "release_claim": workspace["release_claim"],
                "model_state": availability.get("state"),
                "model_reason": availability.get("reason_code"),
                "selection_mode": availability.get("selection_mode"),
            }
            if active:
                summary.update({
                    "intervention": active.get("intervention"),
                    "active_nodes": len(active.get("nodes", [])),
                    "active_edges": len(active.get("edges", [])),
                })
            else:
                summary["active_execution"] = (
                    "none; the selected record has no admitted model binding, so no engine is executing")
            print(json.dumps(summary, indent=2, sort_keys=True))
    elif a.cmd == "sources":
        from .sdk import Platform
        report = Platform(mode="attach" if a.attach else "inprocess").scientific_sources(
            workflow=a.workflow,
            collection=a.collection,
            lifecycle=a.lifecycle,
            limit=a.limit,
            offset=a.offset,
        )
        if a.full:
            print(json.dumps(report, indent=2, sort_keys=True))
        else:
            print(json.dumps({
                "query": report["query"],
                "total": report["total"],
                "sources": [
                    {
                        "id": source["source_id"],
                        "name": source["name"],
                        "collection": source["collection"],
                        "lifecycle": source["lifecycle"],
                        "permitted_use": source["permitted_use"],
                    }
                    for source in report["sources"]
                ],
            }, indent=2, sort_keys=True))
    elif a.cmd == "doctor":
        from .doctor import main as doctor_main
        raise SystemExit(doctor_main((["--json"] if a.json else []) + (["--network"] if a.network else [])))
    elif a.cmd == "notebook":
        from .notebook import ensure_workspace
        from .notebook_launch import run_notebook
        R.require_secret_creation(R.ensure_data_dir(report=_report_data_dir_acl))
        directory = a.dir or os.path.join(R.REG_DIR, "notebooks")
        target = ensure_workspace(directory)
        print(f"  workspace notebook: {target}", flush=True)
        raise SystemExit(run_notebook(R.REG_DIR, directory, target, port=a.port,
                                      no_browser=a.no_browser, python=PYTHON))
    elif a.cmd == "notebook-code":
        from .notebook_launch import print_notebook_code
        raise SystemExit(print_notebook_code(R.REG_DIR))
    elif a.cmd == "programs":
        from .sdk import Platform
        from .shell import run_command
        P = Platform(mode="attach" if a.attach else "inprocess")
        if a.action == "list" or not a.program_id:
            run_command(P, "program list")
        else:
            extra = " ".join(f"{k}={v}" for k, v in (("dose_mg", a.dose_mg), ("cohort", a.cohort), ("seed", a.seed)) if v is not None)
            verb = "insulin run" if a.program_id == "insulin" else f"program run {a.program_id}"
            run_command(P, f"{verb} {extra} {'json=true' if a.json else ''}")
    elif a.cmd == "token":
        print(ensure_api_token())
    elif a.cmd == "identity":
        result = rotate_identity()
        if result:
            raise SystemExit(result)
    elif a.cmd in ("up", "down"):
        sys.exit(_compose(a.cmd) or 0)
    elif a.cmd == "logs":
        sys.exit(_compose("logs", a.services))
    elif a.cmd == "shell":
        from .shell import run_shell
        run_shell(mode="attach" if a.attach else "inprocess")
    elif a.cmd == "attach":
        from .shell import run_shell
        run_shell(mode="attach")
    elif a.cmd == "run":
        from .shell import Platform, run_pipeline
        from .execution_commands import safe_error
        from .execution_client import ContinuousClientError
        from .atlas_commands import safe_atlas_error
        from .atlas_client import AtlasClientError
        try:
            run_pipeline(Platform(mode="attach" if a.attach else "inprocess"), a.pipeline)
        except AtlasClientError as error:
            print(safe_atlas_error(error))
            raise SystemExit(1) from None
        except ContinuousClientError as error:
            print(safe_error(error))
            raise SystemExit(1) from None
    else:
        from .shell import run_shell    # bare `livemore` opens the interactive environment
        run_shell(mode="inprocess")


if __name__ == "__main__":
    main()
