"""Jupyter helpers: one import gives a notebook the same platform the terminal uses.

    from livemorebio import notebook as lm
    P = lm.connect()                 # attach to running services, else in-process
    runs = lm.runs(P)                # protocol history as a DataFrame
    frame = lm.run_frame(P, run_id)  # one frozen run as a tidy DataFrame
    lm.plot_run(frame_or_result)     # standard plot per protocol type

Every helper reads frozen results; none of them mutates a twin or a run.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .sdk import Platform

WORKSPACE_NOTEBOOK = "livemore_workspace.ipynb"


def connect(mode: str | None = None) -> Platform:
    """Attach to the live platform when it is running, otherwise run in-process."""
    if mode is not None:
        return Platform(mode=mode)
    from .cli import SERVICES, _health
    from .stack_readiness import listener_reachable
    port = SERVICES["Aegle"][1]
    if not listener_reachable(f"http://127.0.0.1:{port}"):
        return Platform(mode="inprocess")
    return Platform(mode="attach" if _health(port) else "inprocess")


def runs(P: Platform, *, limit: int = 50, q: str = ""):
    import pandas as pd
    if P.mode != "attach":
        raise RuntimeError("protocol history is stored by the running services; start them with `livemore start`")
    page = P.protocol_history(limit=limit, q=q)
    return pd.DataFrame(page.get("runs", []))


def _as_result(P: Platform | None, run: str | dict) -> dict:
    if isinstance(run, dict):
        return run
    if P is None:
        raise ValueError("a platform is required to fetch a run by identifier")
    return P.get_protocol(run)


def run_frame(P: Platform | None, run: str | dict):
    """Tidy per-member DataFrame for the insulin and botanical protocols."""
    import pandas as pd
    result = _as_result(P, run)
    protocol = result.get("protocol_id")
    if protocol == "cendos.exogenous-insulin-paired.v1":
        rows = []
        for member in result["members"]:
            for arm in ("control", "treated"):
                rows.append({"member_id": member["member_id"], "weight_kg": member["weight_kg"], "arm": arm,
                             **member[arm], **({} if arm == "control" else member["paired_difference"])})
        return pd.DataFrame(rows)
    if protocol == "cendos.botanical-exposure-margin.v1":
        return pd.DataFrame([{k: v for k, v in member.items() if k not in {"series", "disposition"}}
                             for member in result["members"]])
    raise ValueError(f"no tidy frame defined for protocol {protocol!r}")


def plot_run(run: dict, ax=None):
    import matplotlib.pyplot as plt
    protocol = run.get("protocol_id")
    if ax is None:
        _, ax = plt.subplots(figsize=(10, 4), constrained_layout=True)
    if protocol == "cendos.exogenous-insulin-paired.v1":
        for member in run["members"]:
            for arm, style in (("control", "--"), ("treated", "-")):
                series = member["series"][arm]
                ax.plot(series["t_min"], series["glucose_mmol_L"], style, alpha=.5)
        ax.set(xlabel="Biological time (min)", ylabel="Glucose (mmol/L)",
               title="Paired arms per member: dashed control, solid treated")
    elif protocol == "cendos.botanical-exposure-margin.v1":
        for member in run["members"]:
            ax.plot(member["series"]["t_h"], member["series"]["unbound_um"], alpha=.6)
        if run.get("active_range_um"):
            ax.axhspan(*run["active_range_um"], color="grey", alpha=.25, label="measured active range")
            ax.legend()
        ax.set(xlabel="Time (h)", ylabel="Unbound concentration (uM)",
               title=f"{run['program']['program_id']}: {run['outcome']}")
        if run["members"]:
            ax.set_yscale("log")
    else:
        raise ValueError(f"no standard plot for protocol {protocol!r}")
    return ax


def workspace_notebook() -> dict[str, Any]:
    """The starter notebook opened by ``livemore notebook``."""
    def md(text):
        return {"cell_type": "markdown", "metadata": {}, "source": text}

    def code(text):
        return {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": text}

    cells = [
        md("# LivemoreBio workspace\n\nThis notebook drives the same platform as the terminal. "
           "Results are model calculations (`MODELED_ONLY`, `NOT_QUALIFIED`) unless a run says otherwise."),
        code("from livemorebio import notebook as lm\nP = lm.connect()\nprint('mode:', P.mode)\n"
             "catalog = P.program_catalog()\n"
             "for item in catalog['botanical']['programs']:\n"
             "    print(item['program_id'], item['compound'], item['executability'], item['reason_code'] or '')"),
        md("## Exogenous insulin: paired control and treated arms"),
        code("insulin = P.run_insulin_protocol({'cohort_size': 8, 'seed': 1, 'bolus_units': 4, 'meal_g': 60})\n"
             "print(insulin['summary']); print(insulin['controls'])\n"
             "lm.plot_run(insulin); lm.run_frame(None, insulin).head()"),
        md("## Botanical exposure versus measured active concentration"),
        code("arctigenin = P.run_botanical_program({'program_id': 'LBHR-030', 'dose_mg': 400, 'cohort_size': 8})\n"
             "print(arctigenin['outcome'], arctigenin['summary'])\nlm.plot_run(arctigenin)"),
        code("for program in ('LBHR-129', 'LBHR-062', 'LBHR-135'):\n"
             "    blocked = P.run_botanical_program({'program_id': program})\n"
             "    print(program, blocked['outcome'], blocked['reason_code'])\n"
             "    print('   missing:', blocked['missing_measurement'][:160], '...')"),
    ]
    for index, cell in enumerate(cells):
        cell["id"] = f"workspace-{index}"
    return {"cells": cells, "nbformat": 4, "nbformat_minor": 5,
            "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}}}


def ensure_workspace(directory: str | Path) -> Path:
    """Create the workspace notebook once; an existing notebook is never overwritten."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    target = directory / WORKSPACE_NOTEBOOK
    if not target.exists():
        with open(target, "x", encoding="utf-8") as stream:
            json.dump(workspace_notebook(), stream, indent=1)
    return target
