"""Private, supervised Jupyter launches; never pass the live token as an argument."""
from __future__ import annotations

import codecs
from dataclasses import dataclass
import html
import json
import os
from pathlib import Path
import re
import secrets
import signal
import stat
import subprocess
import sys
import threading
import time
import webbrowser

from . import console_filesystem, registry

_RUNTIME_NAME = re.compile(r"notebook-[0-9a-f]{32}\Z")


class NotebookLaunchError(RuntimeError):
    """A fixed diagnostic keeps child errors and credentials out of tracebacks."""

    def __init__(self):
        super().__init__("Notebook launch refused; check the private stack directory and pinned notebook extras.")


@dataclass(frozen=True)
class NotebookRuntime:
    path: Path
    identity: tuple[int, int]

    @property
    def token_file(self) -> Path:
        return self.path / "token"


def process_identity(pid: int) -> str | None:
    """Use OS birth identity, rather than treating a reused PID as the old launcher."""
    if type(pid) is not int or pid <= 0:
        raise NotebookLaunchError()
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return None
    if sys.platform == "darwin":
        import ctypes
        class Usage(ctypes.Structure):
            _fields_ = [("uuid", ctypes.c_uint8 * 16)] + [(name, ctypes.c_uint64) for name in
                "user system idle interrupt pageins wired rss footprint start exit child_user child_system child_idle child_interrupt child_pageins child_elapsed disk_read disk_write".split()]
        library = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
        function = library.proc_pid_rusage
        function.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
        function.restype = ctypes.c_int
        record = Usage()
        if ctypes.sizeof(record) != 160 or function(pid, 2, ctypes.byref(record)) or not record.start:
            # An inspection error is uncertainty, never proof of a dead process.
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                return None
            raise NotebookLaunchError()
        return str(record.start)
    if sys.platform.startswith("linux"):
        try:
            fields = Path(f"/proc/{pid}/stat").read_text(encoding="utf-8").rsplit(")", 1)[1].split()
            boot = Path("/proc/sys/kernel/random/boot_id").read_text(encoding="utf-8").strip()
            return boot + ":" + fields[19]
        except FileNotFoundError:
            return None
    raise NotebookLaunchError()


def _inspect_directory(descriptor: int, *, allow_sticky: bool = False,
                       private: bool = True) -> os.stat_result:
    info = os.fstat(descriptor)
    modes = (0o700, 0o1700) if allow_sticky else (0o700,)
    if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid()
            or (private and stat.S_IMODE(info.st_mode) not in modes)):
        raise NotebookLaunchError()
    console_filesystem.require_ownership_filesystem(descriptor)
    console_filesystem.require_empty_page_acl(descriptor)
    return info


def _private_directory(path: str | Path, *, allow_sticky: bool = False,
                       dir_fd: int | None = None) -> int:
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=dir_fd)
    try:
        _inspect_directory(descriptor, allow_sticky=allow_sticky)
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _write_private(directory: int, name: str, value: str) -> None:
    descriptor = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=directory)
    try:
        info = os.fstat(descriptor)
        if info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1:
            raise NotebookLaunchError()
        console_filesystem.require_empty_page_acl(descriptor)
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            descriptor = -1
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
    finally:
        if descriptor != -1:
            os.close(descriptor)


def prepare_runtime(data_dir: str | Path, *, port: int = 8888, launcher_pid: int | None = None) -> NotebookRuntime:
    """Admit the stack before any secret; a new random directory is never reused."""
    if type(port) is not int or not 1 <= port <= 65535:
        raise NotebookLaunchError()
    root = Path(data_dir).absolute()
    status = registry.ensure_data_dir(str(root))
    registry.require_secret_creation(status)
    root = root.resolve(strict=True)
    root_fd = _private_directory(root)
    runtime = None
    try:
        name = "notebook-" + secrets.token_hex(16)
        os.mkdir(name, mode=0o700, dir_fd=root_fd)
        path = root / name
        descriptor = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=root_fd)
        try:
            console_filesystem.clear_launch_directory_acl(descriptor)
            info = _inspect_directory(descriptor, allow_sticky=True)
            runtime = NotebookRuntime(path, (info.st_dev, info.st_ino))
            pid = os.getpid() if launcher_pid is None else launcher_pid
            identity = process_identity(pid)
            if identity is None:
                raise NotebookLaunchError()
            os.mkdir("codes", mode=0o700, dir_fd=descriptor)
            codes = os.open("codes", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=descriptor)
            try:
                console_filesystem.clear_launch_directory_acl(codes)
                _inspect_directory(codes, allow_sticky=True)
            finally:
                os.close(codes)
            _write_private(descriptor, "token", secrets.token_hex(32))
            _write_private(descriptor, "launcher.json", json.dumps({
                "schema": "livemore.notebook-launch.v1", "launcher_pid": pid,
                "launcher_identity": identity, "runtime_identity": list(runtime.identity), "port": port,
            }))
        finally:
            os.close(descriptor)
        return runtime
    except BaseException:
        if runtime is not None:
            cleanup_runtime(runtime)
        raise
    finally:
        os.close(root_fd)


def _read_record(runtime: NotebookRuntime) -> dict:
    descriptor = _private_directory(runtime.path, allow_sticky=True)
    try:
        return _read_record_from_directory(runtime, descriptor)
    finally:
        os.close(descriptor)


def _read_record_from_directory(runtime: NotebookRuntime, descriptor: int) -> dict:
    info = os.fstat(descriptor)
    if (info.st_dev, info.st_ino) != runtime.identity:
        raise NotebookLaunchError()
    file_fd = os.open("launcher.json", os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=descriptor)
    try:
        info = os.fstat(file_fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid()
                or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1 or info.st_size > 4096):
            raise NotebookLaunchError()
        console_filesystem.require_empty_page_acl(file_fd)
        with os.fdopen(file_fd, encoding="utf-8") as stream:
            file_fd = -1
            record = json.load(stream)
    finally:
        if file_fd != -1:
            os.close(file_fd)
    if (not isinstance(record, dict) or record.get("schema") != "livemore.notebook-launch.v1"
            or record.get("runtime_identity") != list(runtime.identity)
            or type(record.get("launcher_pid")) is not int or record["launcher_pid"] <= 0
            or not isinstance(record.get("launcher_identity"), str) or not record["launcher_identity"]
            or type(record.get("port")) is not int or not 1 <= record["port"] <= 65535):
        raise NotebookLaunchError()
    return record


def record_child(runtime: NotebookRuntime, pid: int) -> None:
    record = _read_record(runtime)
    identity = process_identity(pid)
    if identity is None:
        raise NotebookLaunchError()
    record.update(child_pid=pid, child_identity=identity)
    descriptor = _private_directory(runtime.path, allow_sticky=True)
    try:
        _write_private(descriptor, "launcher.next", json.dumps(record))
        os.replace("launcher.next", "launcher.json", src_dir_fd=descriptor, dst_dir_fd=descriptor)
    finally:
        os.close(descriptor)


def _require_named_identity(parent: int, name: str, identity: tuple[int, int]) -> None:
    named = os.stat(name, dir_fd=parent, follow_symlinks=False)
    if (named.st_dev, named.st_ino) != identity:
        raise NotebookLaunchError()


def _erase_contents(descriptor: int, device: int, *, runtime_root: bool = False,
                    preserve_record: bool = False) -> None:
    for name in os.listdir(descriptor):
        if preserve_record and name == "launcher.json":
            continue
        try:
            before = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
        except FileNotFoundError:
            continue
        if stat.S_ISDIR(before.st_mode):
            child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=descriptor)
            try:
                # Jupyter subdirectories are removed, never used as credentials.
                # Its codes directory still has the private admission contract.
                info = _inspect_directory(child, allow_sticky=True,
                                          private=runtime_root and name == "codes")
                identity = (info.st_dev, info.st_ino)
                if info.st_dev != device or identity != (before.st_dev, before.st_ino):
                    raise NotebookLaunchError()
                _require_named_identity(descriptor, name, identity)
                _erase_contents(child, device)
                _require_named_identity(descriptor, name, identity)
                os.rmdir(name, dir_fd=descriptor)
            finally:
                os.close(child)
        else:
            # Includes Jupyter's 0644 redirects, hardlinks and outward symlinks.
            # Nothing here opens a file or follows its target.
            try:
                os.unlink(name, dir_fd=descriptor)
            except FileNotFoundError:
                continue


def cleanup_owned_runtime(path: str | Path, device: int, inode: int) -> None:
    path = Path(path)
    if not _RUNTIME_NAME.fullmatch(path.name):
        raise NotebookLaunchError()
    parent, descriptor = None, None
    try:
        parent = _private_directory(path.parent)
        descriptor = _private_directory(path.name, allow_sticky=True, dir_fd=parent)
        info = os.fstat(descriptor)
        if (info.st_dev, info.st_ino) != (device, inode):
            raise NotebookLaunchError()
        _require_named_identity(parent, path.name, (device, inode))
        try:
            record = _read_record_from_directory(NotebookRuntime(path, (device, inode)), descriptor)
        except (NotebookLaunchError, OSError, ValueError, console_filesystem.ConsoleFilesystemError):
            # The in-memory runtime identity also owns incomplete setup trees.
            record = None
        _erase_contents(descriptor, device, runtime_root=True, preserve_record=record is not None)
        _require_named_identity(parent, path.name, (device, inode))
        if record is not None:
            os.unlink("launcher.json", dir_fd=descriptor)
        try:
            os.rmdir(path.name, dir_fd=parent)
        except OSError:
            # Preserve stale-prune evidence when final removal is interrupted.
            _require_named_identity(parent, path.name, (device, inode))
            if record is not None:
                _write_private(descriptor, "launcher.json", json.dumps(record))
            raise
    except (OSError, console_filesystem.ConsoleFilesystemError):
        raise NotebookLaunchError() from None
    finally:
        if descriptor is not None:
            os.close(descriptor)
        if parent is not None:
            os.close(parent)


def cleanup_runtime(runtime: NotebookRuntime) -> None:
    try:
        cleanup_owned_runtime(runtime.path, *runtime.identity)
    except Exception:
        print("Notebook runtime cleanup incomplete; the next launch will retry.", file=sys.stderr)


def _runtimes(data_dir: str | Path):
    root = Path(data_dir).resolve(strict=True)
    descriptor = _private_directory(root)
    try:
        for name in sorted(os.listdir(descriptor)):
            if _RUNTIME_NAME.fullmatch(name):
                try:
                    info = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
                except FileNotFoundError:
                    continue
                if (stat.S_ISDIR(info.st_mode) and info.st_uid == os.geteuid()
                        and stat.S_IMODE(info.st_mode) in (0o700, 0o1700)):
                    yield NotebookRuntime(root / name, (info.st_dev, info.st_ino))
    finally:
        os.close(descriptor)


def _matches(record: dict, role: str) -> bool:
    pid, identity = record.get(role + "_pid"), record.get(role + "_identity")
    if type(pid) is not int or not isinstance(identity, str):
        raise NotebookLaunchError()
    return process_identity(pid) == identity


def prune_stale_runtimes(data_dir: str | Path) -> None:
    for runtime in _runtimes(data_dir):
        try:
            record = _read_record(runtime)
            if _matches(record, "launcher"):
                continue
            # A killed supervisor can leave a child alive; its credentials stay private.
            if "child_pid" in record and _matches(record, "child"):
                continue
            cleanup_owned_runtime(runtime.path, *runtime.identity)
        except (NotebookLaunchError, OSError, ValueError, console_filesystem.ConsoleFilesystemError):
            # Unknown or substituted directories are never evidence of stale ownership.
            continue


def jupyter_command(python: str, directory: str | Path, port: int, target: str | Path | None = None) -> list[str]:
    command = [python, "-m", "jupyterlab", "--LabApp.extension_manager=readonly",
               f"--notebook-dir={directory}", f"--port={port}",
               "--ServerApp.ip=127.0.0.1", "--ServerApp.port_retries=0", "--ServerApp.open_browser=False",
               "--LabApp.ip=127.0.0.1", f"--LabApp.port={port}", "--LabApp.port_retries=0",
               "--LabApp.open_browser=False",
               "--LabApp.identity_provider_class=livemorebio.notebook_identity.LivemoreIdentityProvider",
               "--PasswordIdentityProvider.allow_password_change=False",
               "--ServerApp.identity_provider_class=livemorebio.notebook_identity.LivemoreIdentityProvider"]
    if target is not None:
        command.append(str(target))
    return command


class SecretRedactor:
    """Emit only bytes that cannot be the beginning of a split secret."""

    def __init__(self, secret: str, emit):
        self.secret, self.emit, self.pending = secret, emit, ""
        self.decoder = codecs.getincrementaldecoder("utf-8")("replace")

    def feed(self, chunk: bytes) -> None:
        self.pending += self.decoder.decode(chunk)
        self.pending = self.pending.replace(self.secret, "[redacted]")
        keep = 0
        for size in range(1, min(len(self.secret), len(self.pending) + 1)):
            if self.pending.endswith(self.secret[:size]):
                keep = size
        safe = self.pending[:-keep] if keep else self.pending
        self.pending = self.pending[-keep:] if keep else ""
        self.emit(safe)

    def finish(self) -> None:
        self.feed(b"")
        self.emit(self.pending + self.decoder.decode(b"", final=True))
        self.pending = ""


def browser_available() -> bool:
    try:
        return not (sys.platform.startswith("linux") and not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))) and webbrowser.get() is not None
    except webbrowser.Error:
        return False


def open_launch_file(path: str) -> bool:
    return webbrowser.open(Path(path).as_uri())


def _launch_page(runtime: NotebookRuntime, port: int, code: str) -> Path:
    url = html.escape(f"http://127.0.0.1:{port}/lab?token={code}", quote=True)
    descriptor = _private_directory(runtime.path, allow_sticky=True)
    try:
        _write_private(descriptor, "launch.html", '<meta name="referrer" content="no-referrer">\n'
                       f'<meta http-equiv="refresh" content="0;url={url}">\n<title>Open Livemore notebook</title>\n')
    finally:
        os.close(descriptor)
    return runtime.path / "launch.html"


def _read_ready_file(runtime: NotebookRuntime, name: str) -> dict:
    descriptor = _private_directory(runtime.path, allow_sticky=True)
    file_fd = -1
    try:
        info = os.fstat(descriptor)
        if (info.st_dev, info.st_ino) != runtime.identity:
            raise NotebookLaunchError()
        file_fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=descriptor)
        info = os.fstat(file_fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid()
                or stat.S_IMODE(info.st_mode) != 0o600 or info.st_nlink != 1 or info.st_size > 65536):
            raise NotebookLaunchError()
        console_filesystem.require_empty_page_acl(file_fd)
        with os.fdopen(file_fd, encoding="utf-8") as stream:
            file_fd = -1
            record = json.load(stream)
        current = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
        if (info.st_dev, info.st_ino) != (current.st_dev, current.st_ino) or not isinstance(record, dict):
            raise NotebookLaunchError()
        return record
    finally:
        if file_fd != -1:
            os.close(file_fd)
        os.close(descriptor)


def wait_for_ready(runtime: NotebookRuntime, child, *, timeout: float = 30) -> bool:
    from .notebook_identity import ADMISSION_FILENAME

    port = _read_record(runtime)["port"]
    deadline = time.monotonic() + timeout
    while child.poll() is None:
        # Server info alone does not prove our provider ran. Both files must be
        # private and agree with this launch before any code can be published.
        try:
            marker = _read_ready_file(runtime, ADMISSION_FILENAME)
            server = _read_ready_file(runtime, f"jpserver-{child.pid}.json")
        except (FileNotFoundError, json.JSONDecodeError):
            # Both writers create exclusive files before writing the JSON.
            # A partial record proves nothing until publication completes.
            pass
        except (OSError, ValueError, console_filesystem.ConsoleFilesystemError):
            raise NotebookLaunchError() from None
        else:
            if (marker != {"schema": "livemore.notebook-admitted.v1", "port": port,
                           "server_pid": child.pid, "runtime_identity": list(runtime.identity)}
                    or type(server.get("port")) is not int or server["port"] != port):
                raise NotebookLaunchError()
            return True
        if time.monotonic() >= deadline:
            raise NotebookLaunchError()
        time.sleep(0.05)
    return False


def _instructions(port: int, code: str | None = None) -> None:
    # Flushed at once (L0W-5): piped output must not hold the 120 s code until Jupyter stops.
    print(f"http://127.0.0.1:{port}/login?next=%2Flab", flush=True)
    if code is not None:
        print("One-time code: " + code, flush=True)
        print("Enter this code in Jupyter's Password or token form within 120 s; it works once.", flush=True)


def print_notebook_code(data_dir: str | Path) -> int:
    from .notebook_identity import mint_code
    try:
        registry.require_secret_creation(registry.ensure_data_dir(str(data_dir)))
        sessions = []
        for runtime in _runtimes(data_dir):
            try:
                record = _read_record(runtime)
                if _matches(record, "launcher") and _matches(record, "child"):
                    sessions.append((runtime, record))
            except (NotebookLaunchError, OSError, ValueError, console_filesystem.ConsoleFilesystemError):
                continue
        if len(sessions) != 1:
            print("Notebook code unavailable: this stack must have exactly one running notebook session.")
            return 1
        runtime, record = sessions[0]
        _instructions(record["port"], mint_code(runtime.path))
        return 0
    except (NotebookLaunchError, OSError, ValueError, console_filesystem.ConsoleFilesystemError):
        print("Notebook code unavailable for this stack.")
        return 1


def run_notebook(data_dir: str | Path, directory: str | Path, target: str | Path, *, port: int = 8888,
                 no_browser: bool = False, python: str = sys.executable) -> int:
    from .notebook_identity import mint_code, read_private_token
    runtime = prepare_runtime(data_dir, port=port)
    child, threads, previous = None, [], {}
    output_admitted = threading.Event()
    pending_signals = []
    forwarded_signals = []
    result = 1
    failed = False
    try:
        served = Path(directory).resolve()
        if served == runtime.path or served in runtime.path.parents:
            raise NotebookLaunchError()
        prune_stale_runtimes(data_dir)
        environment = dict(os.environ)
        environment.pop("JUPYTER_TOKEN", None)
        environment.update(JUPYTER_RUNTIME_DIR=str(runtime.path), JUPYTER_TOKEN_FILE=str(runtime.token_file))
        token = read_private_token(runtime.path)
        for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGQUIT):
            previous[signum] = signal.getsignal(signum)
            def forward(received, frame):
                forwarded_signals.append(received)
                forwarded = signal.SIGTERM if received in (signal.SIGHUP, signal.SIGQUIT) else received
                if child is None:
                    pending_signals.append(forwarded)
                elif child.poll() is None:
                    child.send_signal(forwarded)
            signal.signal(signum, forward)
        child = subprocess.Popen(jupyter_command(python, directory, port, target), env=environment,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
        for received in pending_signals:
            if child.poll() is None:
                child.send_signal(received)
        def pump(stream, destination):
            def emit(value):
                # Drain immediately to avoid pipe backpressure, but an
                # unadmitted child may produce only the fixed refusal.
                if output_admitted.is_set():
                    destination.write(value)
            redactor = SecretRedactor(token, emit)
            try:
                while chunk := stream.read1(4096):
                    redactor.feed(chunk)
                    if output_admitted.is_set():
                        destination.flush()
                redactor.finish()
            finally:
                stream.close()
        for stream, destination in ((child.stdout, sys.stdout), (child.stderr, sys.stderr)):
            thread = threading.Thread(target=pump, args=(stream, destination), daemon=True)
            thread.start()
            threads.append(thread)
        if child.poll() is None:
            try:
                record_child(runtime, child.pid)
            except NotebookLaunchError:
                if child.poll() is None:
                    raise
        if wait_for_ready(runtime, child):
            output_admitted.set()
            code = mint_code(runtime.path)
            manual = no_browser or not browser_available()
            if manual:
                _instructions(port, code)
            else:
                page = _launch_page(runtime, port, code)
                if not open_launch_file(str(page)):
                    raise NotebookLaunchError()
                _instructions(port)
        result = child.wait()
    except Exception:
        failed = True
        print("Notebook launch failed; check the private stack directory and pinned notebook extras.", file=sys.stderr)
    finally:
        # Browser backends can raise arbitrary exceptions or SystemExit. Every
        # exit path still owns a child until it has actually been reaped.
        if child is not None:
            if child.poll() is None:
                child.send_signal(signal.SIGTERM)
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait()
            else:
                child.wait()
        # A descendant may still own the write ends after Jupyter is reaped.
        # Daemon readers may drain later; waiting for EOF must not retain secrets.
        drain_deadline = time.monotonic() + 2
        for thread in threads:
            thread.join(timeout=max(0, drain_deadline - time.monotonic()))
        for signum, handler in previous.items():
            signal.signal(signum, handler)
        cleanup_runtime(runtime)
    if failed:
        return 1
    status = result if result >= 0 else 128 - result
    if not output_admitted.is_set() and not forwarded_signals:
        # L0W-6: Jupyter stopped before this launch admitted its login, and was not
        # stopped by the person. Its own output is withheld (it may hold a credential),
        # so say what is known here, and never exit 0.
        if _port_held(port):
            # L0-R15 round 1: the commonest cause, checked as Jupyter binds, is named first.
            print(f"Notebook launch refused [NOTEBOOK_PORT_IN_USE]: port {port} on 127.0.0.1 is already in "
                  "use by another program, so Jupyter could not start and nothing was served. Choose "
                  "another port with --port, or stop the program that holds it.", file=sys.stderr, flush=True)
            return status or 1
        print(f"Notebook launch refused [NOTEBOOK_NOT_ADMITTED]: Jupyter stopped (exit status {status}) "
              "before Livemore's private login was in force, so nothing was served. An ambient Jupyter "
              "configuration can cause this, for example an empty IdentityProvider.token or another "
              "identity provider; run `jupyter --paths` to find the configuration directories.",
              file=sys.stderr, flush=True)
        return status or 1
    return status


def _port_held(port: int) -> bool:
    """Whether another listener holds 127.0.0.1:``port``, probed as Jupyter binds it.

    Jupyter (Tornado) binds with SO_REUSEADDR on POSIX, so the probe does too: a
    port in TIME_WAIT is free for Jupyter and is reported free here.
    """
    import errno
    import socket

    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if os.name != "nt":
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        probe.bind(("127.0.0.1", port))
    except OSError as error:
        return error.errno in {errno.EADDRINUSE, getattr(errno, "WSAEADDRINUSE", errno.EADDRINUSE)}
    finally:
        probe.close()
    return False
