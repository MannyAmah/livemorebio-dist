"""Graph backend boundary for deterministic local and governed production use."""
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Callable, Protocol

import networkx as nx

from .. import egress


_CYPHER_IDENTIFIER = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")


class GraphBackend(Protocol):
    def sync(self, graph: nx.Graph) -> dict: ...


@dataclass(slots=True)
class NetworkXBackend:
    graph: nx.Graph | None = None

    def sync(self, graph: nx.Graph) -> dict:
        self.graph = graph.copy()
        return {"loaded": True, "nodes": graph.number_of_nodes(), "edges": graph.number_of_edges()}


class Neo4jBackend:
    def __init__(
        self,
        *,
        uri: str,
        username: str,
        password: str,
        database: str | None = None,
        driver_factory: Callable | None = None,
    ):
        if not uri or not username or not password:
            raise ValueError("Neo4j URI, username, and password are required")
        self.uri = uri
        self.username = username
        self.password = password
        self.database = database
        self._driver_factory = driver_factory

    @classmethod
    def from_environment(cls) -> "Neo4jBackend":
        return cls(
            uri=os.environ.get("NEO4J_URI", ""),
            username=os.environ.get("NEO4J_USERNAME", ""),
            password=os.environ.get("NEO4J_PASSWORD", ""),
            database=os.environ.get("NEO4J_DATABASE") or None,
        )

    @staticmethod
    def _identifier(value: str, kind: str) -> str:
        if not _CYPHER_IDENTIFIER.fullmatch(value or ""):
            raise ValueError(f"invalid Neo4j {kind} identifier")
        return value

    def _driver(self):
        if self._driver_factory:
            return self._driver_factory(self.uri, auth=(self.username, self.password))
        try:
            from neo4j import GraphDatabase
        except ImportError as error:
            raise RuntimeError("install the `neo4j` driver to enable the Neo4j backend") from error
        return GraphDatabase.driver(self.uri, auth=(self.username, self.password))

    def sync(self, graph: nx.Graph) -> dict:
        nodes = []
        edges = []
        for source_key, raw_properties in graph.nodes(data=True):
            properties = egress.check_graph_export(raw_properties)
            label = str(properties.pop("kind", "Entity"))
            key = str(source_key)
            properties.setdefault("name", key)
            nodes.append({"source_key": key, "label": label, "properties": properties})
        for left, right, raw_properties in graph.edges(data=True):
            properties = egress.check_graph_export(raw_properties)
            relationship = str(properties.pop("rel", "RELATED_TO"))
            edges.append({"left": str(left), "right": str(right),
                          "relationship": relationship, "properties": properties})

        # Admit the entire detached export first: a late refusal must not leave
        # a partially uploaded graph, or let later caller mutation bypass it.
        payload = egress.check_graph_export({"nodes": nodes, "edges": edges})
        nodes, edges = payload["nodes"], payload["edges"]
        for node in nodes:
            self._identifier(node["label"], "label")
        for edge in edges:
            self._identifier(edge["relationship"], "relationship")
        driver = self._driver()
        try:
            session_kwargs = {"database": self.database} if self.database else {}
            with driver.session(**session_kwargs) as session:
                for node in nodes:
                    label = node["label"]
                    statement = (
                        f"MERGE (n:{label} {{source_key: $source_key}}) "
                        "SET n += $properties"
                    )
                    session.run(
                        statement,
                        source_key=node["source_key"],
                        properties=node["properties"],
                    )
                for edge in edges:
                    relationship = edge["relationship"]
                    statement = (
                        "MATCH (a {source_key: $left}), (b {source_key: $right}) "
                        f"MERGE (a)-[r:{relationship}]->(b) SET r += $properties"
                    )
                    session.run(
                        statement,
                        left=edge["left"],
                        right=edge["right"],
                        properties=edge["properties"],
                    )
        finally:
            driver.close()
        return {"loaded": True, "nodes": len(nodes), "edges": len(edges)}


def backend_registry() -> dict[str, dict]:
    neo4j_configured = all(
        os.environ.get(name, "").strip()
        for name in ("NEO4J_URI", "NEO4J_USERNAME", "NEO4J_PASSWORD")
    )
    turing_configured = bool(os.environ.get("TURINGDB_ENDPOINT", "").strip())
    return {
        "networkx": {
            "state": "operational",
            "configured": True,
            "intended_use": "development_and_deterministic_tests",
            "production_gate": "not_authorized_for_phi_scale_production",
        },
        "neo4j": {
            "state": "configured" if neo4j_configured else "evaluated",
            "configured": neo4j_configured,
            "intended_use": "governed_reference_graph_candidate",
            "production_gate": "enterprise_rbac_backup_and_live_integration_validation_required",
        },
        "turingdb": {
            "state": "configured" if turing_configured else "evaluated",
            "configured": turing_configured,
            "intended_use": "isolated_read_heavy_evaluation_only",
            "license_gate": "pending_commercial_clearance",
            "production_gate": "license_durability_access_control_and_benchmark_review_required",
        },
    }
