"""Versioned NAR/ELIXIR catalog with fail-closed scientific workflow routing.

Catalog membership is metadata. It does not mean that a source has been licensed,
configured, queried, wired into a workflow, or scientifically qualified.
"""
from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass, field, replace
from enum import Enum
from functools import lru_cache
from importlib import resources
from typing import Iterable


SCHEMA = "livemore.scientific-source-catalog.v1"


class Lifecycle(str, Enum):
    CATALOGED = "cataloged"
    EVALUATED = "evaluated"
    CONFIGURED = "configured"
    OPERATIONAL = "operational"
    WORKFLOW_WIRED = "workflow_wired"
    SCIENTIFICALLY_QUALIFIED = "scientifically_qualified"

    @property
    def rank(self) -> int:
        return tuple(Lifecycle).index(self)


class Workflow(str, Enum):
    GENOME_VARIANTS = "genome_variants"
    CELLS_TISSUES = "cells_tissues"
    PROTEINS_STRUCTURES = "proteins_structures"
    REACTIONS_METABOLISM = "reactions_metabolism"
    DRUG_DISCOVERY = "drug_discovery"
    EXPERIMENTAL_EVIDENCE = "experimental_evidence"
    MICROBIOME_INFECTIOUS = "microbiome_infectious"


@dataclass(slots=True)
class SourceRecord:
    source_id: str
    name: str
    collection: str
    lifecycle: Lifecycle
    provenance_url: str
    license: str
    permitted_use: str
    organisms: tuple[str, ...] = ("unknown",)
    data_types: tuple[str, ...] = ()
    access: str = "unknown"
    endpoint_url: str = ""
    endpoint_status: str = "not_reviewed"
    version: str = ""
    description: str = ""
    description_status: str = "authored"
    workflows: tuple[Workflow, ...] = ()
    evidence_class: str = "reference"
    output_evidence_ceiling: str = "reference_backed"
    last_reviewed: str = ""
    lifecycle_evidence: list[dict[str, str]] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.source_id or not self.name or not self.collection:
            raise ValueError("source_id, name, and collection are required")
        if not self.provenance_url.startswith(("https://", "http://")):
            raise ValueError("provenance_url must be an HTTP(S) URL")
        if self.evidence_class != "reference":
            raise ValueError("scientific source records must remain reference evidence")
        if self.output_evidence_ceiling != "reference_backed":
            raise ValueError("scientific sources cannot promote output beyond reference_backed")

    @classmethod
    def from_dict(cls, row: dict) -> "SourceRecord":
        return cls(
            **{
                **row,
                "lifecycle": Lifecycle(row["lifecycle"]),
                "organisms": tuple(row.get("organisms") or ("unknown",)),
                "data_types": tuple(row.get("data_types") or ()),
                "workflows": tuple(Workflow(value) for value in row.get("workflows") or ()),
                "lifecycle_evidence": list(row.get("lifecycle_evidence") or ()),
            }
        )

    def to_dict(self) -> dict:
        return {
            "source_id": self.source_id,
            "name": self.name,
            "collection": self.collection,
            "lifecycle": self.lifecycle.value,
            "provenance_url": self.provenance_url,
            "license": self.license,
            "permitted_use": self.permitted_use,
            "organisms": list(self.organisms),
            "data_types": list(self.data_types),
            "access": self.access,
            "endpoint_url": self.endpoint_url,
            "endpoint_status": self.endpoint_status,
            "version": self.version,
            "description": self.description,
            "description_status": self.description_status,
            "workflows": [workflow.value for workflow in self.workflows],
            "evidence_class": self.evidence_class,
            "output_evidence_ceiling": self.output_evidence_ceiling,
            "last_reviewed": self.last_reviewed,
            "lifecycle_evidence": list(self.lifecycle_evidence),
        }


def _adapter_records() -> list[SourceRecord]:
    """Translate implemented adapter facts into lifecycle records.

    This overlay is intentionally separate from collection metadata. A ChEMBL
    ELIXIR catalog row and Livemore's ChEMBL adapter are different claims.
    """
    from ..adapters import statuses

    workflow_map = {
        "chembl": (Workflow.DRUG_DISCOVERY,),
        "pubchem": (Workflow.DRUG_DISCOVERY,),
        "opentargets": (Workflow.DRUG_DISCOVERY, Workflow.GENOME_VARIANTS),
        "uniprot": (Workflow.PROTEINS_STRUCTURES,),
        "rcsb": (Workflow.PROTEINS_STRUCTURES,),
        "reactome": (Workflow.REACTIONS_METABOLISM,),
        "gwas_catalog": (Workflow.GENOME_VARIANTS,),
        "ols": (Workflow.GENOME_VARIANTS, Workflow.CELLS_TISSUES),
        "human_reference_atlas": (Workflow.CELLS_TISSUES,),
        "usda_fdc": (Workflow.REACTIONS_METABOLISM,),
        "kegg": (Workflow.GENOME_VARIANTS, Workflow.REACTIONS_METABOLISM),
        "genecards": (Workflow.GENOME_VARIANTS,),
        "malacards": (Workflow.GENOME_VARIANTS, Workflow.DRUG_DISCOVERY),
        "rosalind": (Workflow.EXPERIMENTAL_EVIDENCE,),
    }
    records = []
    for adapter in statuses(probe=False):
        status = adapter["status"]
        if status == "ready" and adapter.get("used_by"):
            lifecycle = Lifecycle.WORKFLOW_WIRED
        elif status == "ready":
            lifecycle = Lifecycle.OPERATIONAL
        elif status in {"disabled", "blocked", "external"}:
            lifecycle = Lifecycle.EVALUATED
        else:
            lifecycle = Lifecycle.CONFIGURED
        records.append(SourceRecord(
            source_id=f"adapter:{adapter['id']}",
            name=adapter["name"],
            collection="livemore_adapter",
            lifecycle=lifecycle,
            provenance_url=adapter.get("license_url") or "https://livemoreai.com/",
            license=adapter.get("license", "unknown_requires_source_review"),
            permitted_use=("configured_workflow_use" if status == "ready"
                           else "blocked_pending_gate"),
            organisms=("human", "multi-species"),
            data_types=tuple(adapter.get("capabilities") or ()),
            access=adapter.get("access", "unknown"),
            workflows=workflow_map.get(adapter["id"], ()),
            description=adapter.get("reason", "Livemore governed adapter"),
            last_reviewed="2026-09-05",
            lifecycle_evidence=[{
                "stage": lifecycle.value,
                "evidence": (adapter.get("probe_evidence") or adapter.get("reason") or
                             "configured adapter; transport has not been probed"),
            }],
        ))
    return records


@lru_cache(maxsize=1)
def _snapshot_records() -> tuple[tuple[SourceRecord, ...], dict]:
    """Parse the immutable package snapshot once; adapter configuration stays dynamic."""
    path = resources.files(__package__).joinpath("data/source-catalog.v1.json")
    with path.open(encoding="utf-8") as stream:
        payload = json.load(stream)
    if payload.get("schema") != SCHEMA:
        raise ValueError("unsupported scientific source catalog schema")
    records = tuple(SourceRecord.from_dict(row) for row in payload["sources"])
    return records, dict(payload.get("collections") or {})


class Catalog:
    def __init__(self, records: Iterable[SourceRecord], collections: dict | None = None):
        self.records = list(records)
        self.collections = dict(collections or {})
        ids = [record.source_id for record in self.records]
        if len(ids) != len(set(ids)):
            raise ValueError("source catalog contains duplicate source_id values")

    @classmethod
    def load(cls) -> "Catalog":
        records, collections = _snapshot_records()
        return cls([*records, *_adapter_records()], collections)

    @classmethod
    def from_records(cls, records: Iterable[SourceRecord]) -> "Catalog":
        return cls(records)

    def get(self, source_id: str) -> SourceRecord:
        try:
            return next(record for record in self.records if record.source_id == source_id)
        except StopIteration as error:
            raise KeyError(source_id) from error

    def promote(self, source_id: str, target: Lifecycle, *, evidence: str) -> SourceRecord:
        current = self.get(source_id)
        if target.rank < current.lifecycle.rank:
            raise ValueError("source lifecycle cannot move backwards")
        if target.rank != current.lifecycle.rank + 1:
            raise ValueError("promotion must move to the next lifecycle stage")
        if not evidence.strip():
            raise ValueError("promotion requires recorded gate evidence")
        history = [*current.lifecycle_evidence, {"stage": target.value, "evidence": evidence.strip()}]
        promoted = replace(current, lifecycle=target, lifecycle_evidence=history)
        self.records[self.records.index(current)] = promoted
        return promoted

    def route(self, workflow: Workflow | str) -> list[SourceRecord]:
        selected = Workflow(workflow)
        return sorted(
            (
                record for record in self.records
                if selected in record.workflows
                and record.lifecycle.rank >= Lifecycle.WORKFLOW_WIRED.rank
            ),
            key=lambda record: (record.lifecycle.rank * -1, record.name.casefold()),
        )

    def report(
        self,
        *,
        collection: str | None = None,
        workflow: Workflow | str | None = None,
        lifecycle: Lifecycle | str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        if limit < 1 or limit > 200:
            raise ValueError("limit must be between 1 and 200")
        if offset < 0:
            raise ValueError("offset must be non-negative")
        rows = self.route(workflow) if workflow else list(self.records)
        if collection:
            rows = [record for record in rows if record.collection == collection]
        if lifecycle:
            selected_lifecycle = Lifecycle(lifecycle)
            rows = [record for record in rows if record.lifecycle is selected_lifecycle]
        rows.sort(key=lambda record: (record.collection, record.name.casefold(), record.source_id))
        counts = Counter(record.lifecycle.value for record in self.records)
        collections = {}
        for name, metadata in self.collections.items():
            cataloged_count = sum(record.collection == name for record in self.records)
            collections[name] = {**metadata, "cataloged_count": cataloged_count}
        return {
            "schema": SCHEMA,
            "note": (
                "cataloged is metadata only; runtime routing requires workflow_wired or "
                "scientifically_qualified state"
            ),
            "collections": collections,
            "lifecycle_counts": dict(counts),
            "query": {
                "collection": collection,
                "workflow": Workflow(workflow).value if workflow else None,
                "lifecycle": Lifecycle(lifecycle).value if lifecycle else None,
                "limit": limit,
                "offset": offset,
            },
            "total": len(rows),
            "sources": [record.to_dict() for record in rows[offset:offset + limit]],
        }
