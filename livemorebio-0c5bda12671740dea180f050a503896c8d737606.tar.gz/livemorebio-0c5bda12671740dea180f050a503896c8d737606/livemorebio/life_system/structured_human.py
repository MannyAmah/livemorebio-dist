"""Technical values only for a structured human (L0-R15 round 1).

The release refuses clinical notes and sends people to "a technical twin from
explicit structured fields" instead. Those fields must therefore be structured:
a note must not ride in them. Every path that builds a ``SyntheticHuman`` from
caller input (Aegle ``/api/stimulate`` ``life_system`` custom, LIFE ``POST
/human``, the SDK's ``patient`` in both modes, and the shell and pipelines
through the SDK) calls :func:`admit_structured_human` first.

- ``id`` is a technical identifier from a closed grammar that holds no word:
  ``LMB``, ``LMB-CUSTOM``, ``LMB-SDK``, or ``LMB-`` and one to four digits.
- ``sex`` is ``F`` or ``M``.
- ``conditions`` are exact terms of the reference condition vocabulary
  (``GET /api/vocab``), at most 30.
- ``genome`` maps variant ids of the reference or engine vocabulary to allele
  doses 0, 1 or 2, at most 64 entries.
- No other key is taken; ``age`` and ``lifestyle`` stay numbers, converted by
  the caller as before.

A value outside these is refused through the clinical-note gate
(:func:`livemorebio.clinical_note_gate.refuse_field`), which names the field and
what it accepts and never the value. ``tests/test_l0_free_text_gate.py`` fails
on a caller-input ``SyntheticHuman`` built without this.
"""
from __future__ import annotations

import re
from typing import Any, Mapping

from ..clinical_note_gate import refuse_field

STRUCTURED_HUMAN_KEYS = frozenset({"id", "age", "sex", "conditions", "genome", "lifestyle"})
TECHNICAL_ID = re.compile(r"LMB(?:-(?:CUSTOM|SDK|[0-9]{1,4}))?\Z")
SEXES = ("F", "M")
MAX_CONDITIONS = 30
MAX_GENOME = 64

KEYS_ACCEPTED = "only the keys id, age, sex, conditions, genome and lifestyle"
ID_ACCEPTED = "LMB, LMB-CUSTOM, LMB-SDK, or LMB- followed by one to four digits"
SEX_ACCEPTED = "F or M"
CONDITIONS_ACCEPTED = f"a list of at most {MAX_CONDITIONS} exact terms of the reference condition vocabulary (GET /api/vocab)"
GENOME_ACCEPTED = (f"an object of at most {MAX_GENOME} variant ids of the reference vocabulary (GET /api/vocab) "
                   "with allele doses 0, 1 or 2")


def _vocabulary():
    from .genome import VARIANTS
    from .knowledge import get_kb

    kb = get_kb()
    return kb, frozenset(kb.variants) | frozenset(VARIANTS)


def admit_structured_human(fields: Mapping[str, Any], *, default_id: str = "LMB",
                           allowed: frozenset[str] = STRUCTURED_HUMAN_KEYS) -> dict[str, Any]:
    """Return ``id``, ``sex``, ``conditions`` and ``genome`` admitted as technical values.

    ``fields`` holds the caller's keys; a key outside ``allowed`` is refused
    before any value is read. Absent fields take the release's defaults.
    """
    if not isinstance(fields, Mapping):
        refuse_field("body", KEYS_ACCEPTED)
    if any(not isinstance(key, str) or key not in allowed for key in fields):
        refuse_field("body", KEYS_ACCEPTED)
    identifier = fields.get("id", default_id)
    if not isinstance(identifier, str) or TECHNICAL_ID.fullmatch(identifier) is None:
        refuse_field("id", ID_ACCEPTED)
    sex = fields.get("sex", "F")
    if not isinstance(sex, str) or sex not in SEXES:
        refuse_field("sex", SEX_ACCEPTED)
    kb, variants = _vocabulary()
    conditions = fields.get("conditions", [])
    if conditions is None:
        conditions = []
    if not isinstance(conditions, (list, tuple)) or len(conditions) > MAX_CONDITIONS:
        refuse_field("conditions", CONDITIONS_ACCEPTED)
    for condition in conditions:
        if not isinstance(condition, str) or len(condition) > 200 or kb.disease(condition) is None:
            refuse_field("conditions", CONDITIONS_ACCEPTED)
    genome = fields.get("genome", {})
    if genome is None:
        genome = {}
    if not isinstance(genome, Mapping) or len(genome) > MAX_GENOME:
        refuse_field("genome", GENOME_ACCEPTED)
    for variant, dose in genome.items():
        if (not isinstance(variant, str) or variant not in variants
                or type(dose) is not int or dose not in (0, 1, 2)):
            refuse_field("genome", GENOME_ACCEPTED)
    return {"id": identifier, "sex": sex, "conditions": list(conditions), "genome": dict(genome)}
