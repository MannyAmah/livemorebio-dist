"""Inherited GWAS-Catalog research effect weights.

The bundled seed/gwas.json stores lowest-p odds ratios without a trait filter;
it lacks original accession, study ancestry and acquisition receipts. The seed
builder preserves these bytes and does not refresh them. The legacy source
adapter uses a retired API; refreshing effects requires a separate versioned,
trait-aware API-v2 model change with study-level provenance and scientific review.
Fallback weight 1.0 is a historical heuristic, not a mechanistic measurement.
"""
from __future__ import annotations
import json
import os

_SEED = os.path.join(os.path.dirname(__file__), "seed", "gwas.json")
_CACHE = {"loaded": False, "effects": {}}


def _load():
    if _CACHE["loaded"]:
        return _CACHE["effects"]
    try:
        with open(_SEED, encoding="utf-8") as f:
            _CACHE["effects"] = json.load(f).get("effects", {})
    except Exception:
        _CACHE["effects"] = {}
    _CACHE["loaded"] = True
    return _CACHE["effects"]


def weight(gene, default=1.0):
    """GWAS-derived effect multiplier for a gene (OR 1.30 → ~1.0). default if unknown."""
    e = _load().get(gene)
    if e and e.get("weight"):
        return float(e["weight"])
    return default


def risk_af(gene):
    """Real risk-allele frequency from the GWAS lead SNP, or None."""
    e = _load().get(gene)
    if e and e.get("risk_af") is not None:
        return float(e["risk_af"])
    return None


def info(gene):
    """Provenance: {rsid, or, weight, allele} for a gene, or None."""
    return _load().get(gene)


def summary():
    e = _load()
    return {"calibrated_genes": len(e), "source": "GWAS Catalog (EBI)",
            "reference_or": 1.30, "example": next(iter(e.items()), None)}
