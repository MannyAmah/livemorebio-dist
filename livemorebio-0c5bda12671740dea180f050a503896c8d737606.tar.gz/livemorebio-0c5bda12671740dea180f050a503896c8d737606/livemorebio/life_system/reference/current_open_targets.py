"""Read-only, receipt-bearing current Open Targets reference acquisition."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import tempfile

from .build_seed import (
    DRUGS, LICENSE_VERIFIED_AT, LICENSE_VERIFIER, REVIEWED_ALIASES,
    OpenSourceReader, SeedBuildError, SeedBuildReason, _hgnc, encode_replacement,
    record_chembl_release, resolve_exact, resolve_open_targets_disease,
    select_associations, validate_association,
)

IDENTITY_QUERY = """query DiseaseIdentity($id: String!) {
  disease(efoId: $id) { id name dbXRefs obsoleteTerms synonyms { relation terms } }
}"""
ASSOCIATIONS_QUERY = """query DirectAssociations($id: String!, $page: Int!) {
  disease(efoId: $id) {
    associatedTargets(enableIndirect: false, page: {index: $page, size: 100}) {
      count rows { score target { id approvedSymbol } datatypeScores { id score } }
    }
  }
}"""
DRUG_QUERY = """query DrugIdentity($id: String!) {
  drug(chemblId: $id) { id name synonyms { label source } }
}"""
SEARCH_QUERY = """query IdentityMap($terms: [String!]!, $entity: String!) {
  mapIds(queryTerms: $terms, entityNames: [$entity]) {
    total mappings { term hits { id name } }
  }
}"""
VERSION_QUERY = "query CurrentRelease { meta { dataVersion { year month } } }"


def provenance(receipt: dict, release: str) -> dict:
    return {**receipt, "release": release, "response_sha256": receipt["sha256"]}


def normalize_drug_identity(row: dict) -> dict:
    # Trial intervention labels may include combination partners, not synonyms
    # for this molecule. Only the chemical database establishes alias identity.
    synonyms = [term for term in row["synonyms"] if term["source"] == "ChEMBL"]
    return {**row, "synonyms": [term["label"] for term in synonyms],
            "synonym_sources": synonyms}


def search_ids(reader: OpenSourceReader, term: str, entity: str) -> list[str]:
    # mapIds supplies candidates only. Every result still requires the independent
    # ontology cross-reference or exact drug term test below.
    data, _ = reader.graphql(SEARCH_QUERY, {"terms": [term], "entity": entity})
    mappings = data["mapIds"]["mappings"]
    if len(mappings) != 1 or mappings[0]["term"] != term:
        raise SeedBuildError(SeedBuildReason.SOURCE_INVALID)
    return sorted({hit["id"] for hit in mappings[0]["hits"] or []})


def current_disease(reader: OpenSourceReader, disease: dict, release: str) -> dict:
    # Keep the verified historical mapping anchor across subsequent refreshes:
    # some current ontology records retain its obsolete ID but no DO crossref.
    previous_id = disease.get("open_targets_mapping", {}).get("previous_id", disease["open_targets_id"])
    ids = set(search_ids(reader, disease["query"], "disease")) | {previous_id, disease["open_targets_id"]}
    records, receipts = [], {}
    for identifier in sorted(ids):
        data, receipt = reader.graphql(IDENTITY_QUERY, {"id": identifier})
        if data["disease"]:
            records.append(data["disease"])
            receipts[identifier] = receipt
    identifier = resolve_open_targets_disease(disease["doid"], records, previous_id=previous_id)
    if not identifier:
        raise SeedBuildError(SeedBuildReason.IDENTITY_UNRESOLVED)
    row = next(row for row in records if row["id"] == identifier)
    disease["open_targets_mapping"] = {
        "method": "doid_crossreference" if disease["doid"] in row["dbXRefs"] else
                  "same_ontology_identifier" if identifier.replace("_", ":", 1) == disease["doid"] else
                  "upstream_obsolete_term",
        "doid": disease["doid"], "previous_id": previous_id,
        "obsolete_terms": row["obsoleteTerms"],
    }
    disease.update(open_targets_id=identifier, open_targets_release=release,
                   open_targets_id_status="current_at_retrieval",
                   open_targets_provenance=provenance(receipts[identifier], release))
    disease.pop("open_targets_release_date", None)
    return row


def source_aliases(disease: dict, current: dict) -> None:
    sources = [(disease["ontology_label"], "label", "Disease Ontology", disease["doid"])]
    sources.extend((term, "exact_synonym", "Disease Ontology", disease["doid"])
                   for term in disease["synonyms"])
    sources.append((current["name"], "label", "Open Targets ontology", current["id"]))
    sources.extend((term, "exact_synonym", "Open Targets ontology", current["id"])
                   for group in current.get("synonyms", []) if group["relation"] == "hasExactSynonym"
                   for term in group["terms"])
    admitted = []
    for alias in REVIEWED_ALIASES.get(disease["query"], []):
        match = next((row for row in sources if row[0].casefold() == alias.casefold()), None)
        if match is None:
            continue
        term, field, source, identifier = match
        admitted.append({
            "alias": alias, "source": source, "source_field": field,
            "source_term": term, "ontology_id": identifier,
            "source_url": "https://www.ebi.ac.uk/ols4/ontologies/doid/terms?obo_id=" + identifier
                          if source == "Disease Ontology" else
                          "https://platform.opentargets.org/disease/" + identifier,
        })
    disease.update(aliases=[row["alias"] for row in admitted], alias_provenance=admitted,
                   alias_status="reviewed_open_ontology_terms")


def direct_associations(reader: OpenSourceReader, identifier: str, release: str) -> list[dict]:
    rows, page = [], 0
    while True:
        data, receipt = reader.graphql(ASSOCIATIONS_QUERY, {"id": identifier, "page": page})
        result = data["disease"]["associatedTargets"]
        new = result["rows"]
        for row in new:
            row["targetId"] = row["target"]["id"]
            validate_association({**row, "evidenceCount": 1})
            row["open_targets_provenance"] = provenance(receipt, release)
        scores = [row["score"] for row in rows[-1:] + new]
        if any(left < right for left, right in zip(scores, scores[1:])):
            raise SeedBuildError(SeedBuildReason.SOURCE_INVALID)
        rows.extend(new)
        selected = select_associations(rows)
        if len(rows) >= result["count"] or (len(rows) > 20 and len(selected) < len(rows)):
            break
        if not new:
            raise SeedBuildError(SeedBuildReason.SOURCE_INVALID)
        page += 1
    if not selected:
        raise SeedBuildError(SeedBuildReason.SOURCE_INVALID)
    # Evidence totals are a separate direct-evidence API aggregation.
    counts_query = "query DirectEvidenceCounts($id: String!) { disease(efoId: $id) { " + " ".join(
        f't{i}: evidences(ensemblIds: ["{row["targetId"]}"], enableIndirect: false, size: 1) {{ count }}'
        for i, row in enumerate(selected)) + " } }"
    counts, receipt = reader.graphql(counts_query, {"id": identifier})
    for i, row in enumerate(selected):
        row["evidenceCount"] = counts["disease"][f"t{i}"]["count"]
        row["evidence_count_provenance"] = provenance(receipt, release)
        validate_association(row)
        for component in row["datatypeScores"]:
            if (isinstance(component["score"], bool) or
                    not isinstance(component["score"], (int, float)) or
                    not math.isfinite(component["score"]) or not 0 <= component["score"] <= 1):
                raise SeedBuildError(SeedBuildReason.SOURCE_INVALID)
    return selected


def build_current_seed(seed: Path, compatibility_seed: Path, reader: OpenSourceReader) -> dict:
    retrieved_at = datetime.now(timezone.utc).date().isoformat()
    current, version_receipt = reader.graphql(VERSION_QUERY)
    version = current["meta"]["dataVersion"]
    release = f"{version['year']}.{version['month']}"
    if not re.fullmatch(r"[0-9]{2}\.[0-9]{2}", release):
        raise SeedBuildError(SeedBuildReason.SOURCE_INVALID)
    assets = {name: json.loads((seed / (name + ".json")).read_text(encoding="utf-8"))
              for name in ("diseases", "genes", "drugs", "meta")}
    diseases, genes, drugs = assets["diseases"], assets["genes"], []
    identity = {row["ensembl"]: row for row in genes.values()}
    def collect_disease(disease: dict) -> tuple[dict, list[dict]]:
        print("Current Open Targets: " + disease["query"], flush=True)
        current_record = current_disease(reader, disease, release)
        source_aliases(disease, current_record)
        return disease, direct_associations(reader, disease["open_targets_id"], release)
    with ThreadPoolExecutor(max_workers=4) as workers:
        disease_rows = list(workers.map(collect_disease, diseases))
        missing = sorted({row["targetId"] for _, rows in disease_rows for row in rows} - set(identity))
        sources = list(workers.map(lambda identifier: _hgnc(reader, "ensembl_gene_id", identifier), missing))
    new_identities = {source["ensembl_gene_id"]: source for source in sources}
    for disease, rows in disease_rows:
        for row in rows:
            if row["targetId"] not in identity:
                source = new_identities[row["targetId"]]
                gene = {
                    "symbol": source["symbol"], "ensembl": source["ensembl_gene_id"],
                    "hgnc": source["hgnc_id"],
                    "uniprot": source["uniprot_ids"][0] if len(source.get("uniprot_ids", [])) == 1 else None,
                    "uniprot_ids": source.get("uniprot_ids", []), "description": source["name"],
                    "protein_class": [], "rna_tissue_specificity": "", "tissue_specific": {},
                    "biological_process": [], "disease_involvement": [], "kegg_pathways": [],
                    "source": "HGNC", "expression_status": "not_distributed",
                    "annotation_status": "not_distributed", "membership_status": "not_distributed",
                }
                if gene["symbol"] in genes:
                    raise SeedBuildError(SeedBuildReason.IDENTITY_UNRESOLVED)
                genes[gene["symbol"]] = gene
                identity[row["targetId"]] = gene
        disease["genes"] = [identity[row["targetId"]]["symbol"] for row in rows]
        disease["gene_associations"] = [{
            "symbol": identity[row["targetId"]]["symbol"], "ensembl": row["targetId"],
            "score": row["score"], "evidence_count": row["evidenceCount"],
            "evidence_count_provenance": row["evidence_count_provenance"],
            "source": "Open Targets Platform", "release": release,
            "association_type": "direct", "evidence_type": "association",
            "score_type": "overall_direct_association", "executable": False,
            "open_targets_provenance": row["open_targets_provenance"],
            "selection_policy": "top_20_overall_direct_including_all_boundary_ties",
            "datatype_scores": [{
                "datatype": item["id"], "score": item["score"],
                "evidence_count": None, "evidence_count_status": "not_exposed_by_api",
                "evidence_type": "association", "score_type": "datatype_direct_association",
                "release": release,
            } for item in sorted(row["datatypeScores"], key=lambda item: item["id"])],
        } for row in rows]
        disease["association_status"] = "resolved_direct_reference"
    for query in DRUGS:
        records, receipts = [], {}
        for identifier in search_ids(reader, query, "drug"):
            data, receipt = reader.graphql(DRUG_QUERY, {"id": identifier})
            if data["drug"]:
                records.append(normalize_drug_identity(data["drug"]))
                receipts[identifier] = receipt
        match = resolve_exact(query, records)
        if not match:
            raise SeedBuildError(SeedBuildReason.IDENTITY_UNRESOLVED)
        drugs.append({
            "query": query, "kegg": None, "name": match["name"],
            "chembl": match["id"], "source": "ChEMBL via Open Targets Platform",
            "release": release, "identity_only": True, "resolution_status": "resolved_exact",
            "matched_on": "label" if match["name"].casefold() == query.casefold() else "synonym",
            "identity_selection_policy": "unique_exact_preferred_name_or_ChEMBL_synonym",
            "open_targets_provenance": provenance(receipts[match["id"]], release),
        })
    # No mixed-release response set is admitted.
    final, _ = reader.graphql(VERSION_QUERY)
    if final != current:
        raise SeedBuildError(SeedBuildReason.SOURCE_INVALID)
    meta = assets["meta"]
    source_records = meta["source_records"]
    source_records["Open Targets Platform"] = {
        "license": "CC0-1.0", "license_url": "https://platform-docs.opentargets.org/licence",
        "license_verified_at": LICENSE_VERIFIED_AT, "license_verifier": LICENSE_VERIFIER,
        "retrieved_at": retrieved_at, "release": release, "currency_status": "current_at_retrieval",
        "release_provenance": provenance(version_receipt, release),
        "requests": reader.receipts["Open Targets Platform"],
    }
    if reader.receipts.get("HGNC"):
        source_records["HGNC"]["requests"].extend(reader.receipts["HGNC"])
        source_records["HGNC"]["additional_identity_retrieved_at"] = retrieved_at
    for name in ("ChEMBL", "EFO", "MONDO"):
        source_records[name].update(retrieved_at=retrieved_at, via="Open Targets Platform " + release)
    for name in ("EFO", "MONDO"):
        source_records[name]["scope"] = "disease identifiers and reviewed exact clinical synonyms"
    record_chembl_release(source_records, reader, release)
    meta.update(built_at=retrieved_at, schema_version=4)
    meta["counts"].update(genes=len(genes),
                          gene_disease_associations=sum(len(d["genes"]) for d in diseases))
    meta["retained_gene_identities"] = {
        "association_release": release, "executable": False,
        "symbols_without_current_association": sorted(set(genes) - {g for d in diseases for g in d["genes"]}),
        "reason": "HGNC identities carried forward from earlier refreshes for stable identity lookup; these records have no current association to the twenty bundled diseases. Identity alone asserts no disease relationship or physiological effect.",
    }
    meta["limitations"] = [
        "Associations are descriptive references, not causal effects, rates or individual genotypes.",
        "The current Open Targets release is recorded at retrieval; later upstream releases may differ.",
        "Top 20 direct association scores retain all boundary ties; datatype labels follow the recorded release.",
        "Datatype evidence counts are not exposed by the score API and remain null with an explicit status.",
        "Names without a unique exact ontology label or exact synonym remain unresolved.",
        "Legacy source-specific fields are empty compatibility placeholders.",
        "Gene-to-pathway membership is not distributed; Reactome provides a top-level pathway catalogue only.",
        "Tissue expression annotations are unavailable in this identity-only reference slice.",
        "Anatomy, structures and GWAS assets retain uncertain original retrieval dates and releases.",
    ]
    replacement = {"diseases": diseases, "genes": dict(sorted(genes.items())), "drugs": drugs, "meta": meta}
    meta["output_sha256"].update({
        name + ".json": hashlib.sha256(encode_replacement(value)).hexdigest()
        for name, value in replacement.items() if name != "meta"})
    encoded = {name: encode_replacement(value) for name, value in replacement.items()}
    staged = []
    try:
        for name, raw in encoded.items():
            for directory in (seed, compatibility_seed):
                descriptor, temporary = tempfile.mkstemp(prefix=".seed-", dir=directory)
                staged.append((Path(temporary), directory / (name + ".json")))
                with os.fdopen(descriptor, "wb") as stream:
                    stream.write(raw)
        for temporary, destination in staged:
            os.replace(temporary, destination)
    finally:
        for temporary, _ in staged:
            temporary.unlink(missing_ok=True)
    print(json.dumps(meta["counts"]), flush=True)
    return meta
