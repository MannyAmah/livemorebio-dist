"""Refresh Open Targets associations and drug identities in an existing seed.

Run python -m livemorebio.life_system.reference.build_seed. Associations remain
annotations, never executable effects. Empty legacy fields preserve the installed
JSON contract. Both runtime seed locations receive byte-identical output.
Disease Ontology identities, Reactome pathways and previous HGNC identities are
carried forward; this command does not reconstruct those assets from scratch.
Upstream response receipts are digests, not a retained raw-response archive.
"""
from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from functools import wraps
import hashlib
import json
import math
from pathlib import Path
import re
from typing import Callable, ParamSpec, TypeVar
import urllib.parse
import urllib.request

SEED = Path(__file__).parent / "seed"
COMPATIBILITY_SEED = Path(__file__).parents[1] / "seed"
OT_RELEASE = "26.09"
OT_API = "https://api.platform.opentargets.org/api/v4/graphql"
LICENSE_VERIFIED_AT = "2026-10-04"
LICENSE_VERIFIER = "Livemore primary-source review"

DISEASE_NAMES = [
    "type 2 diabetes mellitus", "type 1 diabetes mellitus", "coronary artery disease", "hypertension",
    "nonalcoholic fatty liver disease", "chronic obstructive pulmonary disease", "non-small cell lung cancer",
    "colorectal cancer", "Alzheimer disease", "Parkinson disease", "obesity",
    "rheumatoid arthritis", "asthma", "breast cancer", "melanoma", "congestive heart failure",
    "familial hypercholesterolemia", "prostate cancer", "osteoporosis", "inflammatory bowel disease",
]
# Common clinical terms, admitted only with a matching open ontology source term.
REVIEWED_ALIASES = {
    "type 2 diabetes mellitus": ["type 2 diabetes", "Type 2 diabetes mellitus"],
    "type 1 diabetes mellitus": ["type 1 diabetes", "Type 1 diabetes mellitus"],
    "coronary artery disease": ["Coronary artery disease"],
    "nonalcoholic fatty liver disease": ["nonalcoholic fatty liver"],
    "chronic obstructive pulmonary disease": ["COPD"],
    "non-small cell lung cancer": ["Non-small cell lung cancer"],
    "colorectal cancer": ["Colorectal cancer"],
    "Alzheimer disease": ["Alzheimer disease"],
    "Parkinson disease": ["Parkinson disease"],
    "rheumatoid arthritis": ["Rheumatoid arthritis"], "asthma": ["Asthma"],
    "breast cancer": ["Breast cancer"], "melanoma": ["Melanoma"],
    "congestive heart failure": ["heart failure"],
    "prostate cancer": ["Prostate cancer"],
    "inflammatory bowel disease": ["IBD"],
}

GENES = {  # Curated symbols; identities are verified afresh against HGNC.
    "INS": "ENSG00000254647", "LDLR": "ENSG00000130164", "PCSK9": "ENSG00000169174",
    "APOE": "ENSG00000130203", "TCF7L2": "ENSG00000148737", "PPARG": "ENSG00000132170",
    "TP53": "ENSG00000141510", "KRAS": "ENSG00000133703", "EGFR": "ENSG00000146648",
    "CDKN2A": "ENSG00000147889", "SIRT1": "ENSG00000096717", "IL6": "ENSG00000136244",
    "TNF": "ENSG00000232810", "CRP": "ENSG00000132693", "SLC30A8": "ENSG00000164756",
    "KCNJ11": "ENSG00000187486", "GCK": "ENSG00000106633", "HNF1A": "ENSG00000135100",
    "MC4R": "ENSG00000166603", "FTO": "ENSG00000140718", "BRCA1": "ENSG00000012048",
    "BRCA2": "ENSG00000139618", "APP": "ENSG00000142192", "SNCA": "ENSG00000145335",
    "LEP": "ENSG00000174697", "ADIPOQ": "ENSG00000181092", "NLRP3": "ENSG00000162711",
    "HMGCR": "ENSG00000113161", "AGT": "ENSG00000135744", "ACE": "ENSG00000159640",
}
DRUGS = ["metformin", "atorvastatin", "semaglutide", "lisinopril", "aspirin",
         "imatinib", "empagliflozin", "pioglitazone", "insulin", "warfarin"]

class SeedBuildReason(str, Enum):
    SOURCE_UNAVAILABLE = "REFERENCE_SEED_SOURCE_UNAVAILABLE"
    SOURCE_INVALID = "REFERENCE_SEED_SOURCE_INVALID"
    IDENTITY_UNRESOLVED = "REFERENCE_SEED_IDENTITY_UNRESOLVED"


class SeedBuildError(RuntimeError):
    def __init__(self, reason_code: SeedBuildReason):
        self.reason_code = reason_code
        super().__init__({
            SeedBuildReason.SOURCE_UNAVAILABLE: "An open reference source is unavailable; the seed was not replaced.",
            SeedBuildReason.SOURCE_INVALID: "An open reference source returned invalid data; the seed was not replaced.",
            SeedBuildReason.IDENTITY_UNRESOLVED: "A required reference identity could not be resolved exactly; the seed was not replaced.",
        }[reason_code])


Parameters = ParamSpec("Parameters")
Result = TypeVar("Result")


def _typed_source_errors(function: Callable[Parameters, Result]) -> Callable[Parameters, Result]:
    @wraps(function)
    def checked(*args: Parameters.args, **kwargs: Parameters.kwargs) -> Result:
        try:
            return function(*args, **kwargs)
        except (KeyError, TypeError, AttributeError, ValueError) as error:
            raise SeedBuildError(SeedBuildReason.SOURCE_INVALID) from error
    return checked


def validate_association(row: dict) -> None:
    score = row.get("score")
    count = row.get("evidenceCount")
    if (not re.fullmatch(r"ENSG[0-9]{11}", str(row.get("targetId", ""))) or
            isinstance(score, bool) or not isinstance(score, (float, int)) or
            not math.isfinite(score) or not 0 <= score <= 1 or
            isinstance(count, bool) or not isinstance(count, int) or count < 1):
        raise SeedBuildError(SeedBuildReason.SOURCE_INVALID)


def encode_replacement(value: object) -> bytes:
    try:
        raw = json.dumps(value, indent=1, ensure_ascii=False, allow_nan=False) + "\n"
    except (ValueError, TypeError) as error:
        raise SeedBuildError(SeedBuildReason.SOURCE_INVALID) from error
    if re.search(r"(?i)(?:\b(?:hsa|path|ds|dr):[^\s\x22]+|\b(?:hsa|map|ko)\d{5}\b|\b[HDCKRMNG]\d{5}\b|(?:kegg\.jp|genome\.jp)/)", raw):
        raise SeedBuildError(SeedBuildReason.SOURCE_INVALID)
    return raw.encode("utf-8")


def select_associations(rows: list[dict], limit: int = 20) -> list[dict]:
    """Retain all score ties at the boundary; symbol/ID ordering never drops ties."""
    ordered = sorted(rows, key=lambda row: (-row["score"], row["targetId"]))
    if len(ordered) <= limit:
        return ordered
    threshold = ordered[limit - 1]["score"]
    return [row for row in ordered if row["score"] >= threshold]


def resolve_exact(query: str, records: list[dict]) -> dict | None:
    """Accept a unique identity with an exact label or exact synonym."""
    needle = query.strip().casefold()
    matches = {
        record["id"]: record for record in records
        if needle and needle in {
            str(label).strip().casefold()
            for label in [record.get("name", ""), *record.get("synonyms", [])]
        }
    }
    return next(iter(matches.values())) if len(matches) == 1 else None


def resolve_open_targets_disease(doid: str | None, records: list[dict],
                                 previous_id: str | None = None) -> str | None:
    """Cross-reference ontology IDs only when the Open Targets identity is unique."""
    matches = {
        row["id"] for row in records if doid and (
            doid in row.get("dbXRefs", []) or row["id"].replace("_", ":", 1) == doid
            or (previous_id and previous_id in row.get("obsoleteTerms", []))
        )
    }
    return next(iter(matches)) if len(matches) == 1 else None


class OpenSourceReader:
    """No runtime caches, provider credentials, write requests or redirects."""

    def __init__(self) -> None:
        self.receipts: dict[str, list[dict]] = {}

    def _request(self, request: urllib.request.Request, details: dict) -> bytes:
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, req: urllib.request.Request, fp: object, code: int,
                                 msg: str, headers: object, newurl: str) -> None:
                return None
        from ...egress import urlopen
        for attempt in range(3):
            try:
                # L0-R16: the egress check admits the product's documents and identifiers only.
                with urlopen(request, timeout=60, opener=urllib.request.build_opener(NoRedirect)) as response:
                    return response.read()
            except (OSError, ValueError) as error:
                failure = SeedBuildError(SeedBuildReason.SOURCE_UNAVAILABLE)
                failure.request = details
                failure.response = (error.read().decode("utf-8", errors="replace")
                                    if hasattr(error, "read") else str(error))
                failure.http_status = getattr(error, "code", None)
                # A schema/identity rejection is not a transport failure. Retry
                # only transient read failures, with the identical public request.
                if attempt == 2 or (failure.http_status is not None and
                                    failure.http_status not in (408, 429, 500, 502, 503, 504)):
                    raise failure from error
        raise AssertionError("unreachable read retry state")

    def get(self, source: str, url: str) -> bytes:
        request = urllib.request.Request(url, headers={"Accept": "text/plain" if url.endswith("/database/version") else "application/json", "User-Agent": "LivemoreBio reference provenance"}, method="GET")
        raw = self._request(request, {"url": url, "method": "GET"})
        self.receipts.setdefault(source, []).append({
            "url": url, "sha256": hashlib.sha256(raw).hexdigest(),
        })
        return raw

    def json(self, source: str, url: str) -> dict | list:
        try:
            result = json.loads(self.get(source, url))
        except (ValueError, UnicodeError) as error:
            raise SeedBuildError(SeedBuildReason.SOURCE_INVALID) from error
        if isinstance(result, dict) and ("errors" in result or "_error" in result):
            raise SeedBuildError(SeedBuildReason.SOURCE_INVALID)
        return result

    def graphql(self, query: str, variables: dict | None = None) -> tuple[dict, dict]:
        """Execute an explicit read-only query and retain its exact receipt."""
        if not query.lstrip().startswith("query") or re.search(r"\bmutation\b", query):
            raise SeedBuildError(SeedBuildReason.SOURCE_INVALID)
        variables = variables or {}
        request = urllib.request.Request(OT_API,
            data=json.dumps({"query": query, "variables": variables}).encode("utf-8"),
            headers={"Content-Type": "application/json", "Accept": "application/json",
                     "User-Agent": "LivemoreBio reference provenance"}, method="POST")
        raw = self._request(request, {"url": OT_API, "query": query, "variables": variables})
        receipt = {"url": OT_API, "method": "POST", "query": query, "variables": variables,
                   "retrieved_at": datetime.now(timezone.utc).date().isoformat(),
                   "sha256": hashlib.sha256(raw).hexdigest()}
        self.receipts.setdefault("Open Targets Platform", []).append(receipt)
        try:
            data = json.loads(raw)
        except (ValueError, UnicodeError) as error:
            failure = SeedBuildError(SeedBuildReason.SOURCE_INVALID)
            failure.request, failure.response = receipt, raw.decode("utf-8", errors="replace")
            raise failure from error
        if not isinstance(data, dict) or data.get("errors") or not isinstance(data.get("data"), dict):
            failure = SeedBuildError(SeedBuildReason.SOURCE_INVALID)
            failure.request, failure.response = receipt, raw.decode("utf-8", errors="replace")
            raise failure
        return data["data"], receipt



@_typed_source_errors
def _disease_identity(reader: OpenSourceReader, query: str) -> dict:
    params = {"q": query, "ontology": "doid", "rows": 1000}
    data = reader.json("Disease Ontology", "https://www.ebi.ac.uk/ols4/api/search?" + urllib.parse.urlencode(params))
    response = data["response"]
    if response["numFound"] > len(response["docs"]):
        raise SeedBuildError(SeedBuildReason.SOURCE_INVALID)
    records = [{"id": d["obo_id"], "name": d["label"],
                "synonyms": d.get("exact_synonyms", []), "iri": d.get("iri")}
               for d in response["docs"] if d.get("obo_id", "").startswith("DOID:")]
    match = resolve_exact(query, records)
    candidate_ids = sorted({record["id"] for record in records if resolve_exact(query, [record])})
    name = match["name"] if match else query
    definition = ""
    if match and match.get("iri"):
        iri = urllib.parse.quote(urllib.parse.quote(match["iri"], safe=""), safe="")
        detail = reader.json("Disease Ontology", "https://www.ebi.ac.uk/ols4/api/v2/ontologies/doid/entities/" + iri)
        values = detail.get("http://purl.obolibrary.org/obo/IAO_0000115", [])
        if not isinstance(values, list):
            values = [values]
        definition = " ".join(value.get("value", "") if isinstance(value, dict) else str(value)
                              for value in values)
    return {
        "query": query, "kegg": None, "name": name[:1].upper() + name[1:],
        "ontology_label": match["name"] if match else None,
        "aliases": [], "alias_provenance": [],
        "alias_status": "reviewed_open_ontology_terms",
        "synonyms": match["synonyms"] if match else [],
        "category": "", "description": definition, "description_property": "IAO:0000115",
        "pathways": [], "genes": [], "gene_hsa": {},
        "doid": match["id"] if match else None,
        "resolution_status": ("resolved_exact" if match else "unresolved_ambiguous_exact_match"
                              if candidate_ids else "unresolved_no_exact_match"),
        "resolution_candidates": candidate_ids,
        "association_status": "unresolved", "gene_associations": [],
        "source": "Disease Ontology" if match else None, "physiology_effect": "none",
    }


@_typed_source_errors
def _hgnc(reader: OpenSourceReader, field: str, value: str) -> dict:
    url = "https://rest.genenames.org/fetch/" + field + "/" + urllib.parse.quote(value, safe="")
    rows = reader.json("HGNC", url)["response"]["docs"]
    exact = [row for row in rows if row.get(field) == value and row.get("status") == "Approved"]
    if len(exact) != 1:
        raise SeedBuildError(SeedBuildReason.IDENTITY_UNRESOLVED)
    return exact[0]


def record_chembl_release(source_records: dict, reader: OpenSourceReader,
                          release: str = OT_RELEASE) -> None:
    """Bind ChEMBL and ontology releases to the current pipeline configuration."""
    url = f"https://ftp.ebi.ac.uk/pub/databases/opentargets/platform/{release}/etc/config/pis_chembl.yaml"
    raw = reader.get("ChEMBL", url)
    for source, key in (("ChEMBL", "chembl"), ("EFO", "efo"), ("MONDO", "mondo")):
        versions = re.findall(r"^\s*" + key + r"_version:\s*['\"]?([0-9.\-]+)['\"]?\s*$",
                              raw.decode("utf-8"), re.MULTILINE)
        if len(versions) != 1:
            raise SeedBuildError(SeedBuildReason.SOURCE_INVALID)
        source_records[source].update(
            release=versions[0], release_source_url=url,
            requests=[{"url": url, "sha256": hashlib.sha256(raw).hexdigest()}])


@_typed_source_errors
def build() -> dict:
    """Refresh current API references, retaining unrelated reference bytes."""
    from .current_open_targets import build_current_seed
    return build_current_seed(SEED, COMPATIBILITY_SEED, OpenSourceReader())


if __name__ == "__main__":
    from . import build_seed as builder
    try:
        builder.build()
    except builder.SeedBuildError as error:
        print(json.dumps({"reason_code": error.reason_code,
                          "request": getattr(error, "request", None),
                          "http_status": getattr(error, "http_status", None),
                          "response": getattr(error, "response", None)}), flush=True)
        raise
