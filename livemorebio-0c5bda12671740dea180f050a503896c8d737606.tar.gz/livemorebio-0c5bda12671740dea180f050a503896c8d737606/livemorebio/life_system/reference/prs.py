"""Unqualified research scores with a fixed eleven-locus open-GWAS subset.

For each axis: raw = sum(dosage * ln(OR)); mean = sum(2 * af * ln(OR));
variance = sum(2 * af * (1-af) * ln(OR)**2); z = (raw-mean)/sqrt(variance).
Dosage is the bundled effect-allele count (0, 1 or 2), not a disease label.
The frequency model assumes Hardy-Weinberg equilibrium and independent loci.

Effects, allele frequencies, summation order and assumed biomarker scales retain
stable numerical behavior. Membership has separate open-GWAS trait records; those
records do not repair inherited effect selection. In particular, HNF1B has an
opposite-direction metabolic effect, WFS1 a sub-threshold youth-onset association,
and APOB a dyslipidemia endpoint. This is not a clinically qualified risk model.
"""
from __future__ import annotations

import math
from enum import StrEnum
from . import calibration as CAL
from .gwas_traits import GWAS_TRAIT_GROUPS


class PRSReasonCode(StrEnum):
    AXIS_NOT_DISTRIBUTED = "PRS_AXIS_NOT_DISTRIBUTED"
    GENOTYPE_INCOMPLETE = "PRS_GENOTYPE_INCOMPLETE"
    DOSAGE_INVALID = "PRS_DOSAGE_INVALID"


class PRSInputError(ValueError):
    def __init__(self, reason_code, axis, *, missing_loci=(), invalid_loci=()):
        self.reason_code = PRSReasonCode(reason_code)
        self.axis = axis
        self.missing_loci = list(missing_loci)
        self.invalid_loci = list(invalid_loci)
        detail = {
            PRSReasonCode.AXIS_NOT_DISTRIBUTED: "no reference panel exists for this axis",
            PRSReasonCode.GENOTYPE_INCOMPLETE: "complete per-locus genotype coverage is required",
            PRSReasonCode.DOSAGE_INVALID: "dosage must be a numeric allele count of 0, 1 or 2",
        }[self.reason_code]
        super().__init__(f"{self.reason_code}: {axis}: {detail}")


_PANEL = {"loaded": False, "axes": {}}

# Inherited research priors: mg/dL, mmHg, percentage points, mg/dL, kg/m²,
# and dimensionless inflammation, respectively. No individual causal calibration.
_BIOMARKER_SHIFT = {
    "cardiovascular": {"ldl": 13.0, "systolic_bp": 3.0},
    "metabolic": {"hba1c": 0.24, "fasting_glucose": 6.5, "bmi": 0.6},
    "inflammatory": {"inflammation": 0.05},
}


def _panel():
    """Admit only complete authored axes; never silently shrink an axis."""
    if not _PANEL["loaded"]:
        axes = {}
        for axis, genes in GWAS_TRAIT_GROUPS.items():
            loci = []
            for gene in genes:
                info = CAL.info(gene)
                if not info or not info.get("or") or not info.get("allele") or "?" in info["allele"]:
                    break
                try:
                    odds_ratio = float(info["or"])
                    af = CAL.risk_af(gene)
                    if af is None:
                        break
                    af = float(af)
                except (TypeError, ValueError):
                    break
                if not math.isfinite(odds_ratio) or odds_ratio <= 0 or not math.isfinite(af) or not 0 < af < 1:
                    break
                loci.append((gene, math.log(odds_ratio), af))
            if len(loci) == len(genes):
                variance = sum(2 * af * (1 - af) * beta * beta for _, beta, af in loci)
                if math.isfinite(variance) and variance > 0:
                    axes[axis] = loci
        _PANEL["axes"] = axes
        _PANEL["loaded"] = True
    return _PANEL["axes"]


def _axis_coverage(genome, axis):
    loci = _panel().get(axis)
    missing = [gene for gene in GWAS_TRAIT_GROUPS.get(axis, ()) if gene not in genome]
    invalid = [gene for gene in GWAS_TRAIT_GROUPS.get(axis, ()) if gene in genome
               and (isinstance(genome[gene], bool) or not isinstance(genome[gene], (int, float))
                    or genome[gene] not in (0, 1, 2))]
    reason = (PRSReasonCode.AXIS_NOT_DISTRIBUTED if not loci else
              PRSReasonCode.DOSAGE_INVALID if invalid else
              PRSReasonCode.GENOTYPE_INCOMPLETE if missing else None)
    return {"status": "available" if reason is None else "unavailable",
            "reason_code": reason, "missing_loci": missing, "invalid_loci": invalid}


def coverage(genome):
    """Per-axis availability, including the undistributed oncologic axis.

    Aggregate APIs return available axes and refuse if none is usable for the
    requested operation. Partial results omit unavailable axes; consult this
    status to distinguish absent genotypes and unavailable reference parameters.
    Invalid dosages always refuse rather than returning a partial result.
    """
    return {axis: _axis_coverage(genome, axis)
            for axis in (*GWAS_TRAIT_GROUPS, "oncologic")}


def _refuse(status, axis):
    raise PRSInputError(status["reason_code"], axis,
                        missing_loci=status["missing_loci"],
                        invalid_loci=status["invalid_loci"])


def axis_score(genome, axis):
    """Return the research z-score, or a typed input/axis refusal."""
    status = _axis_coverage(genome, axis)
    if status["status"] != "available":
        _refuse(status, axis)
    raw = exp = var = 0.0
    for gene, beta, af in _panel()[axis]:
        raw += float(genome[gene]) * beta
        exp += 2 * af * beta
        var += 2 * af * (1 - af) * beta * beta
    return (raw - exp) / math.sqrt(var)


def _available_axes(genome, relevant_axes, operation):
    status = coverage(genome)
    for axis, row in status.items():
        if row["invalid_loci"]:
            _refuse({**row, "reason_code": PRSReasonCode.DOSAGE_INVALID}, axis)
    available = [axis for axis, row in status.items()
                 if axis in relevant_axes and row["status"] == "available"]
    if not available:
        incomplete = [row for axis, row in status.items() if axis in relevant_axes
                      and row["reason_code"] == PRSReasonCode.GENOTYPE_INCOMPLETE]
        reason = (PRSReasonCode.GENOTYPE_INCOMPLETE if incomplete else
                  PRSReasonCode.AXIS_NOT_DISTRIBUTED)
        raise PRSInputError(reason, operation,
                            missing_loci=[gene for row in incomplete for gene in row["missing_loci"]])
    return available


def scores(genome):
    """Available scores; refuse if none is usable. Coverage reports omissions."""
    return {axis: round(axis_score(genome, axis), 3)
            for axis in _available_axes(genome, GWAS_TRAIT_GROUPS, "scores")}


def biomarker_offsets(genome):
    """Assumed research shifts; refuse without a usable mapped axis.

    Partial results require at least one mapped axis. A computed zero shift may
    legitimately yield an empty mapping; absent data never does.
    """
    available = _available_axes(genome, _BIOMARKER_SHIFT, "biomarker_offsets")
    out = {}
    for axis, shifts in _BIOMARKER_SHIFT.items():
        if axis not in available:
            continue
        z = axis_score(genome, axis)
        if not z:
            continue
        for bm, per_sd in shifts.items():
            out[bm] = round(out.get(bm, 0.0) + z * per_sd, 3)
    return out


def panel_summary():
    return {axis: len(loci) for axis, loci in _panel().items()}


def validate(n=3000, seed=17):
    """Internal standardisation check using synthetic HWE draws only.

    Finite panels need not follow a Gaussian distribution. This checks the
    implemented mean and variance; it is not independent biological evidence.
    """
    import random
    if isinstance(n, bool) or not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer")
    panel = _panel()
    if not panel:
        raise PRSInputError(PRSReasonCode.AXIS_NOT_DISTRIBUTED, "validate")
    rng = random.Random(seed)
    out = {}
    for axis, loci in panel.items():
        zs = []
        for _ in range(n):
            genome = {gene: sum(1 for _ in range(2) if rng.random() < af)
                      for gene, _beta, af in loci}
            zs.append(axis_score(genome, axis))
        mean = sum(zs) / len(zs)
        sd = (sum((z - mean) ** 2 for z in zs) / len(zs)) ** 0.5
        out[axis] = {"n_loci": len(loci), "prs_mean": round(mean, 3), "prs_sd": round(sd, 3)}
    # Score-derived biomarker correlations are circular, not independent evidence.
    return out
