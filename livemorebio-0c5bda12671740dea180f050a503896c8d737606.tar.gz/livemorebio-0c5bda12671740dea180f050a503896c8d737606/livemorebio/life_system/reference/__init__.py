"""LIFE Patch generative human substrate + reference database.

Describe a synthetic host and assemble reference-informed model inputs from
Disease Ontology/Open Targets/HGNC/Reactome/RCSB/HRA/HCA. Generated state drifts
through simplified equations and can drive Cendos research scenarios. This is not
real biology or a substitute for real-world testing.
MalaCards (commercial) and Learn.Genetics (educational) are referenced externally.
"""
from .knowledgebase import KnowledgeBase
from .human_builder import HumanSpec, describe, build_human, HumanBuilder
from .simulator import LivingHuman, Environment
from .patient_factory import PatientFactory
from . import dynamics, prs, calibration
__all__ = ["KnowledgeBase", "HumanSpec", "describe", "build_human", "HumanBuilder",
           "LivingHuman", "Environment", "PatientFactory", "dynamics", "prs", "calibration"]
