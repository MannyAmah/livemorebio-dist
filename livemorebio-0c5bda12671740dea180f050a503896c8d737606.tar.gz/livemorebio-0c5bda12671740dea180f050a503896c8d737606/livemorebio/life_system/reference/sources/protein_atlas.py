"""Human Protein Atlas (proteinatlas.org) — per-gene tissue expression, Uniprot,
disease involvement, biological process, protein class. Key-free JSON per gene."""
from __future__ import annotations
from .base import Source


class ProteinAtlas(Source):
    name = "hpa"
    base = "https://www.proteinatlas.org/"

    def gene(self, ensembl):
        d = self.fetch(f"{ensembl}.json") or {}
        if not isinstance(d, dict) or "_error" in d:
            return None
        return dict(
            symbol=d.get("Gene"), ensembl=ensembl, uniprot=_first(d.get("Uniprot")),
            description=d.get("Gene description"),
            protein_class=d.get("Protein class"),
            rna_tissue_specificity=d.get("RNA tissue specificity"),
            tissue_specific=d.get("RNA tissue specific nTPM") or d.get("RNA tissue distribution"),
            biological_process=d.get("Biological process"),
            disease_involvement=d.get("Disease involvement"),
        )


def _first(v):
    return v[0] if isinstance(v, list) and v else v
