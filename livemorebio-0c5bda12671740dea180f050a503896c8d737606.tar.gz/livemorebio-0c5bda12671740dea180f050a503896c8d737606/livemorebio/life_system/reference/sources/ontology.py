"""Disease Ontology (via EBI OLS4) + Orphanet rare diseases (via Orphadata).
Both key-free. Proxies for disease-ontology.org and orphanet/malacards disease refs."""
from __future__ import annotations
from .base import Source


class DiseaseOntology(Source):
    name = "doid"
    base = "https://www.ebi.ac.uk/ols4/api/"

    def search(self, term, rows=3):
        d = self.fetch("search", params={"q": term, "ontology": "doid", "rows": rows}) or {}
        return [dict(doid=x.get("obo_id"), label=x.get("label"), desc=_first(x.get("description")))
                for x in d.get("response", {}).get("docs", [])]

    def term(self, doid):
        r = self.search(doid.replace("DOID:", ""), rows=1)
        return r[0] if r else None


class Orphanet(Source):
    name = "orphanet"
    base = "https://api.orphadata.com/"

    def by_orphacode(self, code, lang="en"):
        d = self.fetch(f"rd-cross-referencing/orphacodes/{code}", params={"lang": lang}) or {}
        res = d.get("data", {}).get("results", {})
        return dict(orphacode=code, name=res.get("Preferred term"),
                    definition=(res.get("SummaryInformation") or [{}])[0].get("Definition")
                    if isinstance(res.get("SummaryInformation"), list) else None)


def _first(v):
    return v[0] if isinstance(v, list) and v else v
