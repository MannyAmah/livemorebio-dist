"""Reactome ContentService — pathways, reactions, protein→pathway, diseases (DOID).
Key-free. The pathway/reaction substrate (your priority source #1)."""
from __future__ import annotations
from .base import Source


class Reactome(Source):
    name = "reactome"
    base = "https://reactome.org/ContentService/"

    def top_pathways(self, species="9606"):
        d = self.fetch(f"data/pathways/top/{species}") or []
        return [dict(id=p["stId"], name=p["displayName"]) for p in d if isinstance(p, dict)]

    def subpathways(self, st_id):
        d = self.fetch(f"data/pathway/{st_id}/containedEvents") or []
        return [dict(id=p.get("stId"), name=p.get("displayName")) for p in d if isinstance(p, dict)][:40]

    def diseases(self):
        d = self.fetch("data/diseases") or []
        return [dict(doid=x.get("identifier"), name=x.get("displayName")) for x in d if isinstance(x, dict)]

    def query(self, term, types="Protein", species="Homo sapiens"):
        d = self.fetch("search/query", params={"query": term, "species": species,
                                               "types": types, "cluster": "true"}) or {}
        out = []
        for grp in d.get("results", []):
            for e in grp.get("entries", []):
                out.append(dict(id=e.get("id"), name=_strip(e.get("name", ""))))
        return out[:20]

    def event_for_gene(self, symbol):
        """Pathways/reactions a gene participates in (via search)."""
        return self.query(symbol, types="Pathway,Reaction")


def _strip(s):
    import re
    return re.sub("<[^>]+>", "", s or "")
