"""MalaCards through a vendor-authorized local normalized disease release."""
from __future__ import annotations

from pathlib import Path
from .licensed_import import LicensedReferenceStore


class MalaCards:
    name = "malacards"

    def __init__(self, directory: str | Path | None = None) -> None:
        self.store = LicensedReferenceStore(directory)

    def disease(self, identifier: str) -> dict:
        return self.store.disease_context(self.name, identifier)

    def source_metadata(self) -> dict:
        return self.store.source_status(self.name)
