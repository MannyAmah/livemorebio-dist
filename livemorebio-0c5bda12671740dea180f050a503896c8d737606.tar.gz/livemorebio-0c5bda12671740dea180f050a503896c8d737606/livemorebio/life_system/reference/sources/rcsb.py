"""RCSB PDB (data.rcsb.org) — structure metadata for a gene product. Key-free."""
from __future__ import annotations
from .base import Source


class RCSB(Source):
    name = "rcsb"
    base = "https://data.rcsb.org/rest/v1/core/"
    search_base = "https://search.rcsb.org/rcsbsearch/v2/"

    def entry(self, pdb_id):
        d = self.fetch(f"entry/{pdb_id}") or {}
        if "_error" in d:
            return None
        return dict(pdb_id=pdb_id, title=d.get("struct", {}).get("title"),
                    method=(d.get("exptl") or [{}])[0].get("method"),
                    resolution=_res(d))


def _res(d):
    r = d.get("rcsb_entry_info", {}).get("resolution_combined")
    return r[0] if isinstance(r, list) and r else None
