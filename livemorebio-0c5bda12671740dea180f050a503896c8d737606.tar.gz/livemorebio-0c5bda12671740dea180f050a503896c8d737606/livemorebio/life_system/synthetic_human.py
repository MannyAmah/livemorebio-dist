"""
livemorebio.life_system.synthetic_human
=======================================
A Synthetic Human Model: a biologically-grounded person whose mechanistic
parameters come from real genome variants (life_system.genome) and real disease
biology (life_system.knowledge). The model produces the SAME physiological
variables a real human on the LIFE Patch produces — so real data slots straight
into the LIFE System and is interpreted against these models.

The synthetic data is a mechanistic model trajectory (origin = synthetic-model),
not a sensor reading or biological ground truth. Qualification and claim gates
remain mandatory when model output is compared with physical observations.
"""
from __future__ import annotations
from dataclasses import dataclass, field, replace
from collections import defaultdict
from typing import Dict, List
from . import genome as G
from .knowledge import KnowledgeBase
from ..engines.metabolic.glucose_insulin import MetabolicProfile, HEALTHY


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


@dataclass
class SyntheticHuman:
    id: str
    age: int = 45
    sex: str = "F"
    ancestry: str = "EUR"
    conditions: List[str] = field(default_factory=list)
    genome: Dict[str, int] = field(default_factory=dict)     # variant_id -> allele dose (1|2)
    lifestyle: float = 0.6                                    # 0 poor .. 1 excellent
    severity: Dict[str, float] = field(default_factory=dict)

    def label(self) -> str:
        return f"{self.age}{self.sex} · " + (" · ".join(self.conditions) if self.conditions else "reference")

    def driver_effects(self, kb: KnowledgeBase) -> dict:
        eff = defaultdict(float)
        for key in ("insulin_sensitivity", "insulin_secretion", "ldl_clearance",
                    "proliferation", "senescence", "autophagy"):
            eff[key] += G.effect_of(self.genome, key)
        for cond in self.conditions:
            ce, _axis, _organs = kb.condition_effects(cond, severity=self.severity.get(cond, 1.0))
            for k, w in ce.items():
                eff[k] += w
        return dict(eff)

    def metabolic_profile(self, kb: KnowledgeBase) -> MetabolicProfile:
        eff = self.driver_effects(kb)
        d_is = eff.get("insulin_sensitivity", 0.0)     # <0 = insulin resistant
        d_sec = eff.get("insulin_secretion", 0.0)      # <0 = reduced beta-cell secretion
        age_pen = max(0.0, (self.age - 40) / 60.0) * 0.12
        life_pen = max(0.0, (0.5 - self.lifestyle)) * 0.30
        Si = HEALTHY.Si * _clamp(1.0 + d_is - age_pen - life_pen, 0.25, 1.35)
        gamma = HEALTHY.gamma * _clamp(1.0 + d_sec, 0.28, 1.30)
        deficit = max(0.0, -d_is) + max(0.0, -d_sec) + life_pen + age_pen * 0.5
        Gb = _clamp(90.0 + 105.0 * deficit, 80.0, 190.0)
        Ib = _clamp(HEALTHY.Ib * (1.0 + 2.2 * max(0.0, -d_is) + 1.2 * life_pen), 6.0, 26.0)
        Gt = _clamp(100.0 + (Gb - 90.0) * 0.5, 100.0, 130.0)
        SG = HEALTHY.SG * _clamp(1.0 - 0.35 * deficit, 0.5, 1.0)
        return replace(HEALTHY, name=self.label(), weight_kg=HEALTHY.weight_kg,
                       Gb=Gb, Ib=Ib, Si=Si, gamma=gamma, Gt=Gt, SG=SG)
