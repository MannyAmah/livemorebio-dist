"""
livemorebio.life_system.retrieval — semantic retrieval over the substrate.

SubstrateIndex is a TF-IDF/cosine index (numpy only) that runs NOW: query the
biology in natural language ("insulin resistance") and get ranked diseases / genes
/ pathways. TuringDBAdapter is an isolated evaluation boundary, not a production
backend, until licensing, durability, access-control, and benchmark gates pass.
"""
from __future__ import annotations
import re
import math
import numpy as np
from collections import Counter
from .knowledge import KnowledgeBase, get_kb, _name_of, _genes_of
from .reference.knowledgebase import ReferenceReason, disease_terms

_TOK = re.compile(r"[a-z0-9]+")
def _toks(s):
    return _TOK.findall((s or "").lower())


class SubstrateIndex:
    def __init__(self, kb: KnowledgeBase = None):
        self.kb = kb or get_kb()
        self.docs = []
        self._build()
        self._vectorize()

    def _build(self):
        for d in self.kb.diseases:
            txt = " ".join([" ".join(sorted(disease_terms(d))), d.get("category", ""), d.get("description", "")[:300],
                            " ".join(_genes_of(d)), d.get("axis", "")])
            self.docs.append(("Disease", _name_of(d), _toks(txt)))
        for sym, meta in self.kb.genes.items():
            meta = meta or {}
            txt = " ".join([sym, meta.get("description", ""),
                            " ".join(meta.get("biological_process", []) or []),
                            " ".join(meta.get("disease_involvement", []) or [])])
            self.docs.append(("Gene", sym, _toks(txt)))
        for pw in self.kb.pathways.get("reactome_top", []):
            self.docs.append(("Pathway", pw["name"], _toks(pw["name"])))

    def _vectorize(self):
        df = Counter()
        for _, _, tk in self.docs:
            for t in set(tk):
                df[t] += 1
        self.vocab = {t: i for i, t in enumerate(df)}
        N = len(self.docs)
        self.idf = np.zeros(len(self.vocab))
        for t, i in self.vocab.items():
            self.idf[i] = math.log((1 + N) / (1 + df[t])) + 1.0
        self.M = np.zeros((N, len(self.vocab)))
        for r, (_, _, tk) in enumerate(self.docs):
            for t, f in Counter(tk).items():
                self.M[r, self.vocab[t]] = f
            self.M[r] *= self.idf
            nrm = np.linalg.norm(self.M[r])
            if nrm:
                self.M[r] /= nrm

    def query_with_status(self, text, k=8, kind=None):
        """Preserve sparse annotation coverage even when a keyword has no hits."""
        return {"results": self.query(text, k, kind), "annotation_status": "not_distributed",
                "reason_code": ReferenceReason.ANNOTATION_NOT_DISTRIBUTED,
                "annotation_scope": "gene functional and tissue-expression annotations"}

    def query(self, text, k=8, kind=None):
        v = np.zeros(len(self.vocab))
        for t in _toks(text):
            if t in self.vocab:
                v[self.vocab[t]] += self.idf[self.vocab[t]]
        nrm = np.linalg.norm(v)
        if not nrm:
            return []
        v /= nrm
        sims = self.M @ v
        out = []
        for idx in np.argsort(-sims):
            dk, dn, _ = self.docs[idx]
            if sims[idx] <= 0:
                break
            if kind and dk != kind:
                continue
            out.append((dk, dn, round(float(sims[idx]), 3)))
            if len(out) >= k:
                break
        return out


class TuringDBAdapter:
    """Fail-closed TuringDB evaluation boundary.

    Merely setting an endpoint never authorizes commercial or PHI-like use.
    """
    def __init__(self, endpoint=None, clearance_id=None):
        self.endpoint = endpoint
        self.clearance_id = clearance_id

    def capability(self):
        return {
            "state": "configured" if self.endpoint else "evaluated",
            "configured": bool(self.endpoint),
            "license_gate": (
                "recorded" if self.clearance_id else "pending_commercial_clearance"
            ),
            "workflow_wired": False,
            "scientifically_qualified": False,
        }

    def _need(self):
        if not self.endpoint:
            raise RuntimeError(
                "TuringDB endpoint not configured — evaluation remains isolated"
            )
        if not self.clearance_id:
            raise RuntimeError(
                "TuringDB commercial clearance not recorded — runtime integration is blocked"
            )
        raise RuntimeError(
            "TuringDB driver is not workflow-wired; complete durability, access-control, and benchmark gates"
        )

    def upsert(self, *a, **k):
        self._need()

    def query(self, *a, **k):
        self._need()
