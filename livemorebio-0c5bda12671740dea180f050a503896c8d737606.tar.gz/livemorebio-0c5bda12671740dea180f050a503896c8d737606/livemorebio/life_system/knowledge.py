"""Reference annotation compatibility layer shared with the reference package.

Disease names and gene associations do not supply causal effect sizes. Model
parameters belong to explicitly versioned biological engines, not this database.
"""
from __future__ import annotations
import json
import os
from .reference.knowledgebase import KnowledgeBase as ReferenceKnowledgeBase, AXIS_EFFECT, _axis_of as reference_axis_of

SEED = os.path.join(os.path.dirname(__file__), "seed")

ORGAN_MAP = {
    "heart": "heart", "blood vasculature": "vasculature", "lung": "lungs",
    "pancreas": "pancreas", "liver": "liver", "large intestine": "gut",
    "small intestine": "gut", "kidney": "kidneys", "brain": "brain",
    "spleen": "immune", "thymus": "immune", "bone marrow": "immune", "blood": "immune",
}

def _load(name, default):
    try:
        with open(os.path.join(SEED, name), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _name_of(d):
    return (d.get("name") or d.get("query") or (d.get("description", "")[:40]) or "disease").strip()


def _genes_of(d):
    if d.get("gene_hsa"):
        return list(d["gene_hsa"].keys())
    return [g for g in d.get("genes", []) if g]


def _axis_of(d):
    return reference_axis_of(d)


class KnowledgeBase(ReferenceKnowledgeBase):
    def __init__(self):
        self.offline = True
        self.diseases = _load("diseases.json", [])
        self.genes = _load("genes.json", {})
        self.pathways = _load("pathways.json", {})
        self.drugs = _load("drugs.json", [])
        self.meta = _load("meta.json", {})
        self.anatomy = _load("anatomy.json", {})
        self.structures = _load("structures.json", {})
        self._index()

    def _index(self):
        super()._index()

    def disease(self, name):
        return super().disease(name)

    def gene(self, sym):
        g = dict(self.genes.get(sym, {"symbol": sym}))
        g["symbol"] = sym
        g["diseases"] = self.gene_diseases.get(sym, [])
        return g

    def register_into_engine(self):
        """Compatibility no-op: database annotations cannot release biology."""
        return 0

    def condition_effects(self, condition_name, severity=1.0):
        """Return annotation context without an invented direction or magnitude."""
        d = self.disease(condition_name)
        return {}, d["axis"] if d else "unknown", d.get("organs", []) if d else []


_KB = None
def get_kb():
    global _KB
    if _KB is None:
        _KB = KnowledgeBase()
    return _KB
