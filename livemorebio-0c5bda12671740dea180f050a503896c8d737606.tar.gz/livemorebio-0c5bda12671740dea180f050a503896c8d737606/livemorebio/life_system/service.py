"""LIFE System service — population, reference substrate, and LIFE Patch gateway."""
from __future__ import annotations
from datetime import datetime, timezone
import logging
import hashlib
import json
import os

from fastapi import FastAPI, Query, Request
from fastapi.responses import JSONResponse
from .population import LifeSystem
from .synthetic_human import SyntheticHuman
from .knowledge import get_kb
from .graph import KnowledgeGraph
from .retrieval import SubstrateIndex
from .extract import ClinicalExtractor
from ..clinical_note_gate import (CLINICAL_NOTE_REFUSAL_STATUS, ClinicalNoteRefused, clinical_note_gate,
                                  install_refusal_handler, screen_text)
from .structured_human import admit_structured_human
from ..security import install_mutation_auth, require_operator_auth
from .. import __version__
from ..build_info import build_identity
from ..request_body import bounded_json_request
from contextlib import asynccontextmanager

_LOG = logging.getLogger(__name__)

@asynccontextmanager
async def _lifespan(_app):
    """Release the virtual session manager after serving. The name is resolved
    when this runs, so it may be imported further down the module."""
    from .. import registry

    # Direct ASGI/container startup bypasses the CLI's storage preparation.
    registry.ensure_data_dir()
    try:
        yield
    finally:
        shutdown_virtual_manager()


app = FastAPI(title="LIFE System — LivemoreBio", version=__version__,
              docs_url=None, redoc_url=None,
              lifespan=_lifespan,
              description="Population substrate + knowledge graph service. OpenAPI contract at /openapi.json; local API reference at /docs when LIVEMORE_ENABLE_API_DOCS=1.")
install_mutation_auth(
    app, service_role="life",
    operator_read_paths=frozenset({"/population", "/patch/telemetry", "/patch/commands"}),
    private_response_paths=frozenset({"/population", "/human"}),
    private_response_prefixes=("/reference/", "/patch/"),
)
install_refusal_handler(app)  # L0-R15: a refusal raised by any route answers with its typed 422
from ..egress import install_egress_refusal_handler
from ..request_errors import install_validation_error_handler
install_egress_refusal_handler(app)  # L0-R16: EGRESS_VALUE_NOT_ALLOWED as a typed 422
install_validation_error_handler(app)  # L0-R16: a validation refusal never echoes the value
from .virtual_execution_api import router as virtual_execution_router, shutdown_virtual_manager
app.include_router(virtual_execution_router)
_c = {}

# Match the largest explicitly admitted cohort membership in the registry.
MAX_POPULATION_SIZE = 1000


def _hd(h):
    return {"id": h.id, "age": h.age, "sex": h.sex, "conditions": h.conditions,
            "genome": h.genome, "lifestyle": h.lifestyle}


@app.get("/health")
def health(req: Request):
    kb = get_kb()
    return {"service": "LIFE", "ok": True, "port": (req.scope.get("server") or (None, None))[1], "build": build_identity(),
            "diseases": len(kb.diseases), "genes": len(kb.genes), "variants": len(kb.variants)}


@app.get("/population")
def population(req: Request, n: int = Query(25, ge=1, le=MAX_POPULATION_SIZE), seed: int = 0):
    require_operator_auth(req)
    pop = LifeSystem().generate(n, seed)
    return {"n": len(pop), "humans": [_hd(h) for h in pop]}


@app.post("/human")
async def human(req: Request):
    b = await bounded_json_request(req)
    if isinstance(b, dict) and "note" in b:
        # L0-R15: a body that carries a note, whatever its value, is refused
        # before the note is read, parsed, stored, logged or echoed.
        try:
            clinical_note_gate()
        except ClinicalNoteRefused as refusal:
            return JSONResponse(refusal.payload(), status_code=CLINICAL_NOTE_REFUSAL_STATUS,
                                headers={"Cache-Control": "no-store"})
        h, info = ClinicalExtractor().to_synthetic_human(b["note"])
        return {"human": _hd(h), "extracted": info}
    # L0-R15 round 1: the structured fields take technical values only, and a key
    # this route does not define (a misspelled note key included) is refused.
    try:
        admitted = admit_structured_human(b, default_id="LMB")
    except ClinicalNoteRefused as refusal:
        return JSONResponse(refusal.payload(), status_code=CLINICAL_NOTE_REFUSAL_STATUS,
                            headers={"Cache-Control": "no-store"})
    h = SyntheticHuman(id=admitted["id"], age=int(b.get("age", 50)), sex=admitted["sex"],
                       conditions=admitted["conditions"], genome=admitted["genome"],
                       lifestyle=float(b.get("lifestyle", 0.55)))
    return {"human": _hd(h)}


@app.get("/graph")
def graph():
    if "kg" not in _c:
        _c["kg"] = KnowledgeGraph()
    return _c["kg"].stats()


@app.get("/search")
def search(q: str = "", kind: str = ""):
    if "ix" not in _c:
        _c["ix"] = SubstrateIndex()
    context = _c["ix"].query_with_status(q, 8, kind or None)
    return {**context, "results": [{"kind": k, "name": n, "score": s} for k, n, s in context["results"]]}


@app.get("/reference/genes/{symbol}")
def governed_gene_context(symbol: str, req: Request):
    """Retrieve licensed gene annotations as hashed reference context only."""
    from .reference.sources import GeneCards, KEGG

    require_operator_auth(req)
    try:
        kegg = KEGG(offline=False).gene(symbol)
        genecards_source = GeneCards(offline=False)
        genecards = genecards_source.gene(symbol)
    except ValueError as error:
        return JSONResponse({"error": str(error)}, status_code=422)
    records = {"kegg": kegg, "genecards": genecards}
    fingerprint = hashlib.sha256(json.dumps(
        records, sort_keys=True, separators=(",", ":"), allow_nan=False,
    ).encode("utf-8")).hexdigest()
    return JSONResponse({
        "symbol": symbol.strip().upper(),
        "scientific_role": "reference_context_only",
        "validation_effect": "none; validation requires protocol-bound measured counterpart evidence",
        "record_sha256": fingerprint,
        "records": records,
        "sources": {
            "kegg": KEGG(offline=False).source_metadata(),
            "genecards": genecards_source.source_metadata(),
        },
    })


def _patch_gateway():
    from ..life_patch.gateway import LifePatchGateway

    path = os.environ.get("LIVEMORE_PATCH_JOURNAL", "")
    if _c.get("patch_gateway_path") != path:
        _c["patch_gateway"] = LifePatchGateway(path or None)
        _c["patch_gateway_path"] = path
    return _c["patch_gateway"]


def _forward_to_aegle(payload: dict) -> dict:
    """Deliver admitted telemetry to Aegle; retain it durably when Aegle is offline."""
    from ..service_identity_config import ServiceIdentityConfigurationInvalid
    from ..stack_transport import ServiceIdentityUnproven, UNPROVEN_TEXT

    try:
        from .. import registry
        from ..security import authorization_headers
        from ..service_identity import IdentitySnapshot
        from ..service_identity_config import expected_authority
        from ..stack_transport import request

        base = (os.environ.get("LIVEMORE_AEGLE_URL", "").strip()
                or registry.url_of("Aegle") or "http://127.0.0.1:8850")
        startup = app.state.stack_proof
        if startup is None:
            raise ServiceIdentityUnproven()
        identity = IdentitySnapshot(
            startup.snapshot.key, "aegle",
            expected_authority(base, os.environ.get("LIVEMORE_AEGLE_IDENTITY_AUTHORITY")),
        )
        response = request(
            base + "/api/patch/telemetry", identity=identity,
            body=json.dumps(payload).encode("utf-8"),
            method="POST",
            headers={"Content-Type": "application/json", **authorization_headers()},
            timeout=5, read_response_body=False,
        )
        if 200 <= response.status < 300:
            return {"status": "delivered", "http_status": response.status}
        return {
            "status": "rejected", "http_status": response.status,
            "reason": "Aegle rejected telemetry",
        }
    except ServiceIdentityConfigurationInvalid:
        return {
            "status": "queued", "reason_code": "SERVICE_IDENTITY_CONFIGURATION_INVALID",
            "reason": "Telemetry remains journaled. Aegle service identity configuration is invalid.",
        }
    except ServiceIdentityUnproven:
        return {
            "status": "queued", "reason_code": "SERVICE_IDENTITY_UNPROVEN",
            "reason": f"Telemetry remains journaled. {UNPROVEN_TEXT}",
        }
    except Exception as error:
        # Admission has already committed. A forwarding/parser failure cannot
        # retroactively turn that accepted envelope into a contract rejection.
        _LOG.warning("Aegle telemetry delivery failed after admission (%s)", type(error).__name__)
        return {"status": "queued", "reason_code": "SERVICE_FORWARD_UNAVAILABLE",
                "reason": "Aegle delivery could not be confirmed; telemetry remains journaled."}


def _bounded_string_array(value: object, field_name: str) -> tuple[str, ...]:
    from ..life_patch.protocol import ProtocolViolation

    if not isinstance(value, (list, tuple)) or len(value) > 64:
        raise ProtocolViolation(f"{field_name} must be an array with at most 64 entries")
    if any(not isinstance(item, str) for item in value):
        raise ProtocolViolation(f"{field_name} entries must be strings")
    items = tuple(item.strip() for item in value)
    if any(not item or len(item) > 200 for item in items):
        raise ProtocolViolation(
            f"{field_name} entries must be non-empty and at most 200 characters"
        )
    # L0-R15 round 1: these are kept with the telemetry and echoed; a note's marks are refused.
    for item in items:
        screen_text(item, field_name)
    return items


def _accept_patch(envelope, *, consent_scope=(), chain_of_custody=()) -> dict:
    from .. import bus, events
    from ..evidence import to_primitive
    from ..life_patch.evidence import to_evidence_measurements
    from ..life_patch.protocol import envelope_snapshot_key, subject_snapshot_key
    from ..life_patch.protocol_v3 import normalize_observations, TelemetryEnvelopeV3
    from ..security import sign_patch_admission

    # Journal admission is irreversible; establish encrypted publication first.
    bus.require_storage_key()
    now = datetime.now(timezone.utc)
    evidence = to_evidence_measurements(
        envelope,
        tenant_id="livemore",
        received_at=now,
        consent_scope=tuple(consent_scope),
        chain_of_custody=tuple(chain_of_custody),
    )
    references = tuple({
        "envelope_id": item.envelope_id,
        "source_hash": item.source_hash,
        "role": item.role.value,
        "source_data_class": item.payload.source_data_class.value,
    } for item in evidence)
    result = {
        "admission": "accepted",
        "envelope_hash": envelope.envelope_hash,
        "evidence_references": [to_primitive(item) for item in evidence],
    }
    admitted = _patch_gateway().admit(envelope, evidence_references=references, received_at=now)
    try:
        snapshot = {
            "admission": "accepted",
            "subject_id": envelope.subject_id,
            "device_id": envelope.device_id,
            "mode": envelope.mode.value,
            "sequence": envelope.sequence,
            "envelope_hash": envelope.envelope_hash,
            "captured_at": admitted["captured_at"],
            "received_at": now.isoformat().replace("+00:00", "Z"),
            "measurements": admitted["measurements"],
            "observations": normalize_observations(envelope, received_at=now),
            "evidence_references": list(references),
        }
        bus.set_snapshot("patch.latest", snapshot)
        bus.set_snapshot(subject_snapshot_key(envelope.subject_id), snapshot)
        bus.set_snapshot(envelope_snapshot_key(envelope.envelope_hash), snapshot)
        bus.publish("LIFE", events.PATCH_TELEMETRY_ADMITTED, snapshot)
        admission = {
            "admission": "accepted",
            "admitted_at": admitted["admitted_at"],
            "device_id": envelope.device_id,
            "mode": envelope.mode.value,
            "envelope_hash": envelope.envelope_hash,
            "capability_hash": admitted["capability_hash"],
            "received_at": now.isoformat().replace("+00:00", "Z"),
        }
        forwarded = {
            "envelope": envelope.to_dict(),
            "admission": admission,
            "admission_signature": sign_patch_admission(admission),
        }
        if isinstance(envelope, TelemetryEnvelopeV3):
            admission["manifest_hash"] = admitted["manifest_hash"]
            forwarded["manifest"] = admitted["manifest"]
            forwarded["admission_signature"] = sign_patch_admission(admission)
        result["aegle"] = _forward_to_aegle(forwarded)
    except Exception as error:
        # Publication and signing also occur after durable admission. Preserve
        # that fact even when delivery cannot be prepared or confirmed.
        _LOG.warning("Telemetry publication or signing failed after admission (%s)", type(error).__name__)
        result["aegle"] = {
            "status": "queued", "reason_code": "SERVICE_FORWARD_UNAVAILABLE",
            "reason": "Aegle delivery could not be confirmed; telemetry remains journaled.",
        }
    return result


@app.post("/patch/devices", status_code=201)
async def register_patch_device(req: Request):
    from ..life_patch.protocol import decode_manifest, DeviceMode, ProtocolViolation
    from ..aegle.research_api import body as strict_body
    from ..security import verify_device_manifest

    try:
        body = await strict_body(req)
        if not isinstance(body, dict):
            raise ProtocolViolation("device manifest must be a JSON object")
        manifest = decode_manifest(body)
        if manifest.mode is not DeviceMode.VIRTUAL:
            if not manifest.hardware_present or manifest.firmware_version == "not-provisioned":
                raise ProtocolViolation("physical/external devices require a provisioned manifest")
            signature = req.headers.get("X-Livemore-Device-Attestation", "")
            if not verify_device_manifest(manifest.to_dict(), signature):
                raise ProtocolViolation("physical/external device attestation is missing or invalid")
        manifest = _patch_gateway().register(manifest)
        return JSONResponse(manifest.to_dict(), status_code=201)
    except (ProtocolViolation, ValueError, TypeError) as error:
        return JSONResponse({"error": "Device registration rejected; check the manifest and provisioning requirements.", "code": "PATCH_REGISTRATION_REJECTED"}, status_code=422)


@app.get("/patch/devices/{device_id}")
def patch_device(device_id: str, req: Request):
    require_operator_auth(req)
    manifest = _patch_gateway().manifest(device_id)
    if manifest is None:
        return JSONResponse({"error": "device is not registered"}, status_code=404)
    return JSONResponse(manifest.to_dict())


@app.post("/patch/telemetry", status_code=202)
async def patch_telemetry(req: Request):
    import asyncio

    from ..life_patch.protocol import ProtocolViolation, decode_envelope
    from ..aegle.research_api import body as strict_body

    try:
        body = await strict_body(req)
        if not isinstance(body, dict):
            raise ProtocolViolation("telemetry body must be a JSON object")
        raw = body.get("envelope", body)
        if not isinstance(raw, dict):
            raise ProtocolViolation("telemetry envelope must be a JSON object")
        wrapped = raw is not body
        result = await asyncio.to_thread(
            _accept_patch,
            decode_envelope(raw),
            consent_scope=(
                _bounded_string_array(body.get("consent_scope", ()), "consent_scope")
                if wrapped else ()
            ),
            chain_of_custody=(
                _bounded_string_array(body.get("chain_of_custody", ()), "chain_of_custody")
                if wrapped else ()
            ),
        )
        return JSONResponse(result, status_code=202)
    except (ProtocolViolation, ValueError, TypeError) as error:
        return JSONResponse({"error": "Telemetry request rejected; check the registered contract, timing and admission requirements.", "code": "PATCH_TELEMETRY_REJECTED"}, status_code=422)


@app.get("/patch/telemetry")
def patch_telemetry_journal(req: Request, subject_id: str = "", limit: int = 100):
    require_operator_auth(req)
    rows = _patch_gateway().telemetry(subject_id=subject_id, limit=limit)
    return {"telemetry": rows, "count": len(rows)}


@app.post("/patch/virtual/sample", status_code=202)
async def virtual_patch_sample(req: Request):
    from ..life_patch.protocol import DeviceMode, ProtocolViolation, VirtualLifePatch, manifest_for, decode_envelope
    from ..aegle.research_api import body as strict_body

    from .. import bus

    # The generated branch registers its device before _accept_patch runs.
    bus.require_storage_key()
    try:
        body = await strict_body(req)
        if not isinstance(body, dict):
            raise ProtocolViolation("virtual sample body must be a JSON object")
        if "envelope" in body:
            if set(body) != {"envelope"}:
                raise ProtocolViolation("explicit virtual envelope cannot be combined with sampling overrides")
            envelope = decode_envelope(body["envelope"])
            if envelope.mode is not DeviceMode.VIRTUAL:
                raise ProtocolViolation("virtual sampling accepts only virtual device telemetry")
            return JSONResponse(_accept_patch(envelope), status_code=202)
        device_id = str(body.get("device_id", "")).strip()
        subject_id = str(body.get("subject_id", "")).strip()
        if not device_id or not subject_id:
            raise ProtocolViolation(
                "device_id and subject_id are required for a bound virtual LIFE Patch sample"
            )
        if set(body) - {"device_id", "subject_id", "protocol_version", "readings"}:
            raise ProtocolViolation("unsupported virtual sampling fields")
        if body.get("protocol_version", "2.0") != "2.0":
            raise ProtocolViolation("v3 sampling requires an explicit virtual envelope with acquisition and model context")
        readings = body.get("readings")
        if not isinstance(readings, dict) or not readings:
            raise ProtocolViolation("explicit virtual readings are required; implicit mutable-twin sampling is disabled")
        manifest = manifest_for(device_id, DeviceMode.VIRTUAL)
        gateway = _patch_gateway()
        with gateway.transaction():
            gateway.register(manifest)
            device = VirtualLifePatch(manifest, sequence=gateway.next_sequence(device_id) - 1)
            envelope = device.emit(subject_id, readings)
            return JSONResponse(_accept_patch(envelope), status_code=202)
    except (ProtocolViolation, ValueError, TypeError) as error:
        return JSONResponse({"error": "Virtual telemetry request rejected; check the explicit envelope, registered device and protocol.", "code": "PATCH_VIRTUAL_REQUEST_REJECTED"}, status_code=422)


@app.post("/patch/commands", status_code=201)
async def issue_patch_command(req: Request):
    from .. import bus, events
    from ..life_patch.protocol import ProtocolViolation
    from ..aegle.research_api import body as strict_body

    bus.require_storage_key()
    try:
        body = await strict_body(req)
        if not isinstance(body, dict):
            raise ProtocolViolation("command body must be a JSON object")
        parameters = body.get("parameters", {})
        if not isinstance(parameters, dict):
            raise ProtocolViolation("command parameters must be a JSON object")
        duration = body.get("expires_in_seconds", 300)
        if type(duration) is not int or not 1 <= duration <= 3600:
            raise ProtocolViolation("command expiry must be an integer from 1 to 3600 seconds")
        command = _patch_gateway().issue_command(
            device_id=str(body.get("device_id", "")),
            command=str(body.get("command", "")),
            parameters=parameters,
            expires_in_seconds=duration,
            command_id=str(body.get("command_id", "")),
        )
        bus.publish("LIFE", events.PATCH_COMMAND_ISSUED, command.to_dict())
        return JSONResponse(command.to_dict(), status_code=201)
    except (ProtocolViolation, ValueError, TypeError) as error:
        return JSONResponse({"error": "Command request rejected; check registration, parameters and the safety allowlist.", "code": "PATCH_COMMAND_REJECTED"}, status_code=422)


@app.get("/patch/commands")
def patch_commands(req: Request, device_id: str = "", limit: int = 100):
    require_operator_auth(req)
    rows = _patch_gateway().commands(device_id=device_id, limit=limit)
    return {"commands": rows, "count": len(rows)}


@app.post("/patch/commands/receipts", status_code=201)
async def patch_command_receipt(req: Request):
    from ..life_patch.protocol import CommandReceipt, ProtocolViolation
    from ..aegle.research_api import body as strict_body

    try:
        body = await strict_body(req)
        receipt = CommandReceipt(
            command_id=str(body.get("command_id", "")),
            device_id=str(body.get("device_id", "")),
            status=str(body.get("status", "")),
            received_at=datetime.fromisoformat(str(body.get("received_at", "")).replace("Z", "+00:00")),
            detail=str(body.get("detail", "")),
        )
        return JSONResponse(_patch_gateway().record_receipt(receipt).to_dict(), status_code=201)
    except (ProtocolViolation, ValueError, TypeError) as error:
        return JSONResponse({"error": "Command receipt rejected; check command identity, status and timestamp.", "code": "PATCH_RECEIPT_REJECTED"}, status_code=422)


def main(host: str = "127.0.0.1", port: int = 8851, *, access_log: bool = True,
         timeout_graceful_shutdown: int | None = None) -> None:
    import uvicorn
    from ..stack_proof import configure_bind_identity
    configure_bind_identity(app, host, port)
    uvicorn.run(app, host=host, port=port, log_level="warning", proxy_headers=False,
                access_log=access_log, timeout_graceful_shutdown=timeout_graceful_shutdown)


if __name__ == "__main__":
    main()
