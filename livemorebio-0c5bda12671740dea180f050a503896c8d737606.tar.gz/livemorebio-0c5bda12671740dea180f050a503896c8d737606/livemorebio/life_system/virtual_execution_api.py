"""Authenticated, explicitly bound LIFE numerical-device sessions."""
from __future__ import annotations

import asyncio
from collections.abc import Callable
import os
from pathlib import Path
import re
import threading
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from ..aegle.execution_api import ExecutionRoute, _body, _failure, _control_guard, _check_runtime_identity
from ..aegle.execution_contract import ExecutionError, METABOLIC, text
from ..build_info import build_identity
from ..life_patch.execution_source import (ExecutionSourceClient, ExecutionSourceUnavailable,
                                           numerical_probe_manifest, OPERATOR_ID)
from ..security import patch_storage_key, TOKEN_ENV
from ..request_errors import log_private_failure
from ..service_identity import IdentitySnapshot
from ..service_identity_config import expected_authority

router = APIRouter(route_class=ExecutionRoute)
_creation_lock = threading.RLock()
_instance = None
_SESSION_ID = r"[0-9a-f]{32}"


class GuardedExecutionSource(ExecutionSourceClient):
    def _request(self, method: str, path: str, body: dict | None = None) -> dict[str, Any]:
        # Read-only status and an explicit safety pause remain possible after an
        # on-disk edit; no new frame, renewal or projection may cross that edit.
        status_read = method == "GET" and re.fullmatch(r"/api/executions/[0-9a-f]{32}", path)
        safety_pause = method == "POST" and re.fullmatch(r"/api/executions/[0-9a-f]{32}/pause", path)
        if not status_read and not safety_pause:
            _check_runtime_identity()
        return super()._request(method, path, body)


def _source(base: str, token: str) -> GuardedExecutionSource:
    from .service import app

    state = app.state.stack_proof
    if state is None:
        raise ExecutionSourceUnavailable()
    identity = IdentitySnapshot(state.snapshot.key, "aegle", expected_authority(
        base, os.environ.get("LIVEMORE_AEGLE_IDENTITY_AUTHORITY")))
    return GuardedExecutionSource(base, token, build_identity()["source_sha256"],
                                 expected_role="aegle", identity=identity)


def _manager():
    global _instance
    with _creation_lock:
        if _instance is not None:
            return _instance
        _check_runtime_identity()
        # Configuration never falls back to another running Livemore instance.
        path = os.environ.get("LIVEMORE_VIRTUAL_EXECUTION_STORE", "")
        journal = os.environ.get("LIVEMORE_PATCH_JOURNAL", "")
        base = os.environ.get("LIVEMORE_AEGLE_URL", "").strip()
        token = os.environ.get(TOKEN_ENV, "").strip()
        if (not path or path != path.strip() or not Path(path).is_absolute()
                or not journal or journal != journal.strip() or not Path(journal).is_absolute() or not base or not token):
            raise ExecutionError("EXECUTION_UNAVAILABLE")
        try:
            key = patch_storage_key(create=False)
        except (OSError, RuntimeError, ValueError):
            raise ExecutionError("EXECUTION_UNAVAILABLE") from None
        if key is None:
            raise ExecutionError("EXECUTION_UNAVAILABLE")
        from .execution_delivery import forward_execution_receipt
        from ..life_patch.gateway import LifePatchGateway
        from ..life_patch.virtual_session_store import VirtualSessionStore
        from ..life_patch.virtual_execution import VirtualSessionManager

        from ..life_patch.gateway import PatchJournalInvalid

        source = _source(base, token)
        store = VirtualSessionStore(Path(path), key=key)
        try:
            gateway = LifePatchGateway(journal)
        except PatchJournalInvalid as error:
            # A journal the current protocol rejects is not a storage fault. Say
            # so, and let the message name the record and the repair command.
            raise ExecutionError(error.code) from None
        if gateway._storage_key != key:
            raise ExecutionError("EXECUTION_UNAVAILABLE")
        _instance = VirtualSessionManager(store, gateway, source,
            lambda receipt: forward_execution_receipt(receipt, source))
        return _instance


def shutdown_virtual_manager() -> None:
    global _instance
    with _creation_lock:
        if _instance is not None:
            _instance.close()
            _instance = None


def _operate(action: str, operation: Callable[[Any], Any], *, session_id: str | None = None) -> JSONResponse:
    request_id, manager = None, None
    failure = None
    exception_type = None
    try:
        if session_id is not None and re.fullmatch(_SESSION_ID, session_id) is None:
            raise ExecutionError()
        manager = _manager()
        request_id = manager.store.begin_access(action, execution_id=session_id)
        result = operation(manager)
    except Exception as error:
        if not isinstance(error, ExecutionError):
            exception_type = type(error).__name__
        if request_id is not None:
            try:
                code = error.code if isinstance(error, ExecutionError) else "EXECUTION_STORAGE"
                manager.store.finish_access(request_id, code)
            except Exception:
                failure = _failure(ExecutionError("EXECUTION_STORAGE"), request_id)
        if failure is None:
            failure = _failure(error, request_id)
    if failure is not None:
        if exception_type is not None:
            log_private_failure(exception_type, request_id)
        return failure
    try:
        manager.store.finish_access(request_id, "OK")
    except Exception:
        return _failure(ExecutionError("EXECUTION_STORAGE"), request_id)
    return JSONResponse(result, headers={"Cache-Control": "no-store", "X-Livemore-Request-Id": request_id})


@router.get("/patch/virtual/sessions/capabilities")
def capabilities():
    return _operate("capabilities", lambda manager: {
        "engine_contract_id": METABOLIC, "operator_id": OPERATOR_ID,
        "projectable_signals": ["glucose_mgdl"], "unit": "mg/dL", "compartment": "plasma",
        "hardware_present": False, "physical_equivalence_validated": False,
        "source": "Explicitly selected immutable Aegle execution; no physical sensor transfer model.",
        "initial_state": "No samples until the selected numerical engine advances.",
        "controls": ["register_probe", "bind_session", "pause", "resume", "stop"]})


@router.post("/patch/virtual/probe")
async def register_probe(request: Request):
    try:
        body = await _body(request)
    except Exception:
        return _failure(ExecutionError())
    def register(manager):
        _check_runtime_identity()
        if set(body) != {"device_id"}:
            raise ExecutionError()
        manifest = numerical_probe_manifest(text(body["device_id"], 128))
        return manager.gateway.register(manifest).to_dict()
    return await asyncio.to_thread(_operate, "register_probe", register)


@router.post("/patch/virtual/sessions")
async def start_session(request: Request):
    try:
        body = await _body(request)
    except Exception:
        return _failure(ExecutionError())
    def start(manager):
        _check_runtime_identity()
        if set(body) != {"execution_id", "source_snapshot_hash", "device_id", "expected_selection", "idempotency_key"}:
            raise ExecutionError()
        return manager.start(body["execution_id"], body["source_snapshot_hash"], body["device_id"],
            expected_selection=body["expected_selection"], idempotency_key=text(body["idempotency_key"], 128))
    return await asyncio.to_thread(_operate, "start", start)


@router.get("/patch/virtual/sessions/{session_id}")
def session_status(session_id: str):
    return _operate("status", lambda manager: manager.status(session_id), session_id=session_id)


@router.post("/patch/virtual/sessions/{session_id}/{action}")
async def session_control(session_id: str, action: str, request: Request):
    try:
        if action not in {"pause", "resume", "stop"}:
            raise ExecutionError()
        body = await _body(request)
    except Exception:
        return _failure(ExecutionError())
    def control(manager):
        if action == "resume":
            _check_runtime_identity()
        return getattr(manager, action)(session_id, **_control_guard(body))
    return await asyncio.to_thread(_operate, action, control, session_id=session_id)
