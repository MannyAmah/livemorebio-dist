"""
livemorebio.life_system.extract — clinical text → grounded Synthetic Human.

ClinicalExtractor uses the substrate's OWN real vocabulary (disease names, gene
symbols, drug names) to pull entities out of a clinical note and instantiate a
biologically-grounded SyntheticHuman. Runnable now, no ML download. OpenMedNER is
the optional local OpenMed intake path.

This release has no operational local de-identification, so every entry point
that takes note text calls ``clinical_note_gate`` first and refuses with
``CLINICAL_NOTE_NOT_ACCEPTED`` before it reads the text (L0-R15). Constructing
an extractor reads only the reference vocabulary and stays available.
"""
from __future__ import annotations
import re
from .knowledge import KnowledgeBase, get_kb
from .synthetic_human import SyntheticHuman
from . import genome as G
from .reference.knowledgebase import is_acronym, note_label, note_terms
from ..clinical_note_gate import clinical_note_gate

# These unambiguous forms were case-insensitive in stable-6588707. Keep that
# compatibility without making ambiguous AD or newly admitted acronyms fold case.
_STABLE_CASE_INSENSITIVE_ACRONYMS = frozenset({"HTN", "T2DM", "T2D", "CAD"})


class ClinicalExtractor:
    def __init__(self, kb: KnowledgeBase = None):
        self.kb = kb or get_kb()
        self.disease_terms = {}
        for d in self.kb.diseases:
            nm = note_label(d)
            for term in sorted(note_terms(d)):
                self.disease_terms[term] = nm
        self.gene_syms = {g.upper() for g in self.kb.genes if g} | {v for v in self.kb.variants if v}
        self.drug_terms = {(dr.get("query") or dr.get("name", "")).lower():
                           (dr.get("query") or dr.get("name")) for dr in self.kb.drugs}

    @staticmethod
    def _gene_mentioned(symbol, text):
        if len(symbol) > 3:
            return bool(re.search(r"\b" + re.escape(symbol) + r"\b", text))
        # Short symbols collide with clinical shorthand; require a genetic cue.
        token = re.escape(symbol)
        return bool(re.search(r"\b" + token + r"\s+(?:gene|mutation|variant|genotype)\b", text)
                    or re.search(r"\b(?:gene|mutation|variant|genotype)\s+" + token + r"\b", text))

    def extract(self, text):
        clinical_note_gate()
        low = " " + text.lower() + " "
        conds = []
        for term, nm in self.disease_terms.items():
            # Punctuation-only variation in the reviewed diabetes spelling is
            # allowed; only the published unambiguous abbreviations fold case.
            pattern = re.escape(term).replace(",", ",?")
            flags = 0 if is_acronym(term) and term not in _STABLE_CASE_INSENSITIVE_ACRONYMS else re.IGNORECASE
            for match in re.finditer(r"(?<!\w)" + pattern + r"(?!\w)", text, flags):
                # Pulmonary hypertension is a distinct concept, not systemic
                # hypertension. A broad word inside it must not attach that label.
                if term.casefold() == "hypertension" and re.search(
                    r"\b(?:pulmonary(?:[\s-]+(?:arterial|venous))?|portal|intracranial|ocular)[\s-]+$", text[:match.start()], re.IGNORECASE
                ):
                    continue
                if nm not in conds:
                    conds.append(nm)
                break
        genes = sorted({g for g in self.gene_syms if self._gene_mentioned(g, text)})
        drugs = sorted({nm for term, nm in self.drug_terms.items()
                        if re.search(r"(?<!\w)" + re.escape(term) + r"(?!\w)", low)})
        m = re.search(r"\b(\d{1,3})\s*(?:yo|y/o|year[- ]?old|yr)", low) or re.search(r"\bage[:\s]+(\d{1,3})", low)
        age = int(m.group(1)) if m else None
        if re.search(r"\b(female|woman|girl)\b", low):
            sex = "F"
        elif re.search(r"\b(male|man|boy)\b", low):
            sex = "M"
        else:
            # clinical shorthand: age-adjacent M/F ("47 yo M", "58 y/o F", "47M") or "sex: M"
            ms = (re.search(r"\b\d{1,3}\s*(?:yo|y/o|y\.o\.|year[s]?[- ]?old|yr)?\s*[/,\- ]?\s*(m|f)\b", low)
                  or re.search(r"\bsex\s*[:=]?\s*(m|f)\b", low))
            sex = ms.group(1).upper() if ms else "F"
        return {"conditions": conds, "genes": genes, "drugs": drugs, "age": age, "sex": sex}

    def to_synthetic_human(self, text, hid="LMB-NOTE"):
        clinical_note_gate()
        ex = self.extract(text)
        genome = {g: 1 for g in ex["genes"] if g in G.VARIANTS}
        h = SyntheticHuman(id=hid, age=ex["age"] or 50, sex=ex["sex"],
                           conditions=ex["conditions"], genome=genome)
        return h, ex


class OpenMedNER:
    """Local clinical intake through OpenMed's public Python API.

    ``client`` is injectable for air-gapped deployments and deterministic tests;
    otherwise the installed ``openmed`` package is imported lazily. This class is
    an intake adapter, not an executable-biology engine.
    """
    def __init__(self, model="disease_detection_superclinical", kb=None, client=None):
        self.model = model
        self.kb = kb or get_kb()
        self._client = client
        self._fallback = ClinicalExtractor(self.kb)

    @staticmethod
    def available():
        import importlib.util as u
        return bool(u.find_spec("openmed"))

    def client(self):
        if self._client is None:
            if not self.available():
                raise RuntimeError(
                    "OpenMed is not installed; install `openmed[hf]` and local model artifacts"
                )
            import openmed
            self._client = openmed
        return self._client

    def extract(self, text, *, contains_phi=False):
        clinical_note_gate()
        if self._client is None and not self.available():
            if contains_phi:
                raise RuntimeError(
                    "PHI-like clinical intake requires operational local OpenMed de-identification"
                )
            return {"backend": "substrate-fallback", **self._fallback.extract(text)}
        client = self.client()
        analysis_text = text
        deidentified = False
        if contains_phi:
            deidentified_result = client.deidentify(text, method="mask")
            analysis_text = deidentified_result.deidentified_text
            deidentified = True
        result = client.analyze_text(analysis_text, model_name=self.model)
        entities = []
        for entity in result.entities:
            entities.append({
                "label": entity.label,
                "text": entity.text,
                "confidence": float(entity.confidence),
                "start": int(entity.start),
                "end": int(entity.end),
            })
        return {
            "backend": "openmed-local",
            "model": self.model,
            "deidentified": deidentified,
            "entities": entities,
        }
