"""Minimal valid GLB container for technical transport tests, not human geometry."""
import json
import struct


def technical_glb(label: str = "transport fixture") -> bytes:
    content = json.dumps({"asset": {"version": "2.0", "generator": "technical test"},
                          "extras": {"label": label}}).encode()
    content += b" " * (-len(content) % 4)
    return struct.pack("<4sII", b"glTF", 2, 20 + len(content)) + struct.pack("<I4s", len(content), b"JSON") + content
