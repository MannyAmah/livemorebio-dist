"""Item 0 regressions: every credential here is a technical fixture."""
from __future__ import annotations

import base64
import builtins
import os
import stat
import sys

import pytest

from livemorebio import cli, registry, security, service_identity


FILES = ("api-token", "patch-storage.key", "patch-admission.key", "service-identity.key")
TOKEN = "technical-fixture-token-of-this-stack"
KEY = base64.urlsafe_b64encode(b"technical fixture key bytes 1234").decode("ascii")


def _snapshot(directory):
    return [(str(path.relative_to(directory)), path.lstat().st_mode,
             os.readlink(path) if path.is_symlink() else path.read_bytes() if path.is_file() else None)
            for path in (directory, *sorted(directory.rglob("*")))]


@pytest.fixture
def credentials(tmp_path, monkeypatch):
    data, elsewhere = tmp_path / "data", tmp_path / "technical-other-stack"
    data.mkdir(mode=0o755)
    elsewhere.mkdir(mode=0o755)
    monkeypatch.setattr(registry, "REG_DIR", str(data))
    monkeypatch.setattr(registry, "REG", str(data / "registry.json"))
    monkeypatch.setattr(cli, "TOKEN_FILE", str(data / "api-token"))
    for name in (cli.TOKEN_ENV, security.PATCH_STORAGE_KEY_ENV,
                 security.PATCH_ADMISSION_KEY_ENV, "LIVEMORE_SERVICE_IDENTITY_KEY", "LIVEMORE_ENVIRONMENT"):
        monkeypatch.delenv(name, raising=False)
    return data, elsewhere


@pytest.mark.parametrize("dangling", [False, True])
def test_item0_token_link_refused_after_directory_only_repair(credentials, monkeypatch, capsys, dangling):
    data, elsewhere = credentials
    target = elsewhere / "api-token"
    if not dangling:
        target.write_text(TOKEN + "\n", encoding="utf-8")
        target.chmod(0o644)
    (data / "api-token").symlink_to(target)
    before = _snapshot(data), _snapshot(elsewhere)
    monkeypatch.setattr(sys, "argv", ["livemore", "token"])

    with pytest.raises(SystemExit) as stopped:
        cli.main()

    output = capsys.readouterr().out
    assert stopped.value.code == 2
    assert "STACK_CREDENTIAL_LINKED" in output and TOKEN not in output
    name, mode, contents = before[0][0]
    before[0][0] = (name, stat.S_IFMT(mode) | (stat.S_IMODE(mode) & 0o700), contents)
    assert (_snapshot(data), _snapshot(elsewhere)) == before


@pytest.mark.parametrize("reader,filename", [
    ("operator", "api-token"), ("client", "api-token"),
    ("storage", "patch-storage.key"), ("storage-create", "patch-storage.key"),
    ("admission", "patch-admission.key"), ("admission-create", "patch-admission.key"),
    ("identity", "service-identity.key"), ("identity-create", "service-identity.key"),
])
@pytest.mark.parametrize("kind", ["link", "directory"])
def test_item0_all_credential_readers_refuse_nonregular_files(credentials, reader, filename, kind):
    data, elsewhere = credentials
    if filename == "service-identity.key":
        data.chmod(0o700)
    target = elsewhere / filename
    target.write_text(KEY + "\n", encoding="utf-8")
    target.chmod(0o644)
    if kind == "link":
        (data / filename).symlink_to(target)
    else:
        (data / filename).mkdir()
    before = _snapshot(data), _snapshot(elsewhere)
    ask = {
        "operator": security._operator_token,
        "client": security.authorization_headers,
        "storage": lambda: security.patch_storage_key(create=False),
        "storage-create": lambda: security.patch_storage_key(create=True),
        "admission": lambda: security.patch_admission_key(create=False),
        "admission-create": lambda: security.patch_admission_key(create=True),
        "identity": lambda: service_identity.service_identity_key(create=False),
        "identity-create": lambda: service_identity.service_identity_key(create=True),
    }[reader]
    if reader == "operator":
        assert ask() == ""
    else:
        with pytest.raises(ValueError, match="STACK_CREDENTIAL_LINKED"):
            ask()
    assert (_snapshot(data), _snapshot(elsewhere)) == before


@pytest.mark.parametrize("command", ["start", "up"])
@pytest.mark.parametrize("filename", FILES)
def test_item0_launcher_refuses_every_link_before_creating_any_secret(credentials, monkeypatch, capsys, command, filename):
    import shutil
    from ._source_tree import verifying_container_image

    data, elsewhere = credentials
    (elsewhere / filename).write_text(KEY + "\n", encoding="utf-8")
    (data / filename).symlink_to(elsewhere / filename)
    before = _snapshot(data), _snapshot(elsewhere)
    monkeypatch.setattr(cli, "status", lambda: None)
    monkeypatch.setattr(cli, "_wait_for_services", lambda names, **options: [])
    monkeypatch.setattr(shutil, "which", lambda name: "/technical/docker")
    monkeypatch.setattr(cli.subprocess, "call", lambda *a, **k: pytest.fail("started docker"))
    monkeypatch.setattr(cli.subprocess, "Popen", lambda *a, **k: pytest.fail("started a service"))

    if command == "up" and verifying_container_image():
        # The image cannot run Compose; it returns before touching credentials.
        monkeypatch.setattr(cli, "ensure_api_token", lambda: pytest.fail("created a token"))
        monkeypatch.setattr(security, "ensure_patch_security_keys", lambda: pytest.fail("created keys"))
        assert cli._compose("up") == 1
        assert "docker-compose.yml not found" in capsys.readouterr().out
    else:
        with pytest.raises(ValueError, match="STACK_CREDENTIAL_LINKED"):
            cli.start(["technical-unknown-service"]) if command == "start" else cli._compose("up")

    if command != "up" or not verifying_container_image():
        name, mode, contents = before[0][0]
        before[0][0] = (name, stat.S_IFMT(mode) | (stat.S_IMODE(mode) & 0o700), contents)
    assert (_snapshot(data), _snapshot(elsewhere)) == before


def test_item0_token_tightening_stays_on_the_opened_descriptor(credentials, monkeypatch):
    data, elsewhere = credentials
    path, target = data / "api-token", elsewhere / "api-token"
    path.write_text(TOKEN + "\n", encoding="utf-8")
    target.write_text("technical-target-must-not-be-tightened\n", encoding="utf-8")
    target.chmod(0o644)
    real_open, real_os_open = builtins.open, os.open
    swapped = []

    def swap_after_open(name):
        if os.fspath(name) == str(path) and not swapped:
            path.unlink()
            path.symlink_to(target)
            swapped.append(True)

    def open_file(name, *args, **kwargs):
        stream = real_open(name, *args, **kwargs)
        swap_after_open(name)
        return stream

    def open_descriptor(name, flags, *args, **kwargs):
        descriptor = real_os_open(name, flags, *args, **kwargs)
        swap_after_open(name)
        return descriptor

    monkeypatch.setattr(builtins, "open", open_file)
    monkeypatch.setattr(os, "open", open_descriptor)

    # The original descriptor has no named link after this swap. Exact-one-link
    # admission refuses it before read/chmod and leaves the replacement untouched.
    with pytest.raises(security.CredentialFileError):
        cli.ensure_api_token()
    assert swapped and stat.S_IMODE(target.stat().st_mode) == 0o644


def test_item0_file_replaced_with_link_before_open_is_refused(credentials, monkeypatch):
    data, elsewhere = credentials
    path, target = data / "api-token", elsewhere / "api-token"
    path.write_text(TOKEN + "\n", encoding="utf-8")
    target.write_text("technical-target-must-not-be-read\n", encoding="utf-8")
    real_open, real_os_open = builtins.open, os.open
    swapped = []

    def swap_before_open(name):
        if os.fspath(name) == str(path) and not swapped:
            path.unlink()
            path.symlink_to(target)
            swapped.append(True)

    def open_file(name, *args, **kwargs):
        swap_before_open(name)
        return real_open(name, *args, **kwargs)

    def open_descriptor(name, flags, *args, **kwargs):
        swap_before_open(name)
        return real_os_open(name, flags, *args, **kwargs)

    monkeypatch.setattr(builtins, "open", open_file)
    monkeypatch.setattr(os, "open", open_descriptor)
    with pytest.raises(ValueError, match="STACK_CREDENTIAL_LINKED"):
        cli.ensure_api_token()


@pytest.mark.parametrize("filename", FILES)
def test_item0_regular_credentials_still_read_and_tighten(credentials, filename):
    data, _ = credentials
    if filename == "service-identity.key":
        data.chmod(0o700)
    path = data / filename
    path.write_text((TOKEN if filename == "api-token" else KEY) + "\n", encoding="utf-8")
    path.chmod(0o600 if filename == "service-identity.key" else 0o644)
    if filename == "api-token":
        assert cli.ensure_api_token() == TOKEN
        assert security.authorization_headers() == {"Authorization": "Bearer " + TOKEN}
    elif filename == "patch-storage.key":
        assert security.patch_storage_key() == base64.urlsafe_b64decode(KEY)
    elif filename == "patch-admission.key":
        assert security.patch_admission_key() == base64.urlsafe_b64decode(KEY)
    else:
        assert service_identity.service_identity_key() == base64.urlsafe_b64decode(KEY)
    assert stat.S_IMODE(path.stat().st_mode) == 0o600
