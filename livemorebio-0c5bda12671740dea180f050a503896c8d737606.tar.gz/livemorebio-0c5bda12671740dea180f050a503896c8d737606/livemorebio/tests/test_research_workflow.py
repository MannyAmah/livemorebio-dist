"""Tests for evidence binding; fixtures never count as biological validation."""
import copy
import hashlib
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

import pytest

from livemorebio.research import ResearchError, ResearchStore, ResearchService


def run_fixture():
    return {
        "run_id": "protocol-" + "a" * 32,
        "protocol_id": "cendos.garcinoic-acid-pxr.v1",
        "evidence_state": "MODELED_TARGET_ENGAGEMENT",
        "cohort": {"name": "fixture", "cohort_id": "cohort-fixture"},
        "target_engagement": [{"concentration_um": 1.3, "members": [
            {"member_id": "member-1", "relative_pxr_activation": .5}]}],
    }


@pytest.fixture
def service(tmp_path):
    return ResearchService(ResearchStore(tmp_path / "research.sqlite3", key=b"x" * 32))


def freeze(service):
    with patch("livemorebio.research._now", return_value=(datetime.now(timezone.utc) - timedelta(days=1)).isoformat()):
        return service.freeze(run_fixture(), {
            "title": "Fixture comparison", "endpoint": "relative_pxr_activation",
            "tolerance": .1, "rationale": "Technical test only, no biological acceptance claim",
            "mapping": {"specimen-1": "member-1"}, "method_id": "fixture-method",
            "material_id": "garcinoic-acid-lot-fixture", "controls": ["vehicle", "positive"],
        })


def measurement(service, study, *, value=.53, source="TECHNICAL_FIXTURE", unit="1", stamp=None,
                sample="specimen-1", member="member-1", replicate="1"):
    stamp = stamp or datetime.now(timezone.utc).isoformat()
    raw = ("sample_id,member_id,concentration_um,endpoint,unit,value,replicate_id,measured_at,quality_status\n"
           f"{sample},{member},1.3,relative_pxr_activation,{unit},{value},{replicate},{stamp},pass\n")
    return service.admit_measurement(study["id"], {
        "csv": raw, "source_class": source, "instrument_id": "fixture-reader",
        "calibration_id": "fixture-cal", "method_id": "fixture-method",
        "material_id": "garcinoic-acid-lot-fixture", "operator_id": "fixture-operator",
        "controls_passed": True, "calibration_current": True,
        "source_reference": "local technical fixture",
    })


def test_freeze_preserves_run_and_encrypts_payload(service):
    result = run_fixture()
    original = copy.deepcopy(result)
    study = freeze(service)
    assert result == original
    assert study["run_sha256"] == hashlib.sha256(
        __import__("json").dumps(original, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()
    assert b"Fixture comparison" not in service.store.path.read_bytes()
    assert service.store.get(study["id"])["run"] == original


def test_compare_resolves_frozen_prediction_and_never_validates_fixture(service):
    study = freeze(service)
    data = measurement(service, study)
    result = service.compare(study["id"], data["id"])
    assert result["pairs"][0]["predicted"] == .5
    assert result["pairs"][0]["residual"] == pytest.approx(.03)
    assert result["status"] == "TECHNICAL_CHECK_ONLY"
    assert result["calibration_authorized"] is False
    assert result["coverage"] == {"expected": 1, "matched": 1}


def test_failed_physical_comparison_cannot_pass(service):
    study = freeze(service)
    data = measurement(service, study, value=.9, source="PHYSICAL_IMPORT")
    result = service.compare(study["id"], data["id"])
    assert result["status"] == "CRITERION_NOT_MET"
    assert result["evidence_state"] == "OPERATOR_ATTESTED_IMPORT"
    assert result["qualification_state"] == "REVIEW_REQUIRED"


def test_measurement_wrong_unit_is_rejected(service):
    study = freeze(service)
    with pytest.raises(ResearchError, match="unit"):
        measurement(service, study, unit="mg/dL")


def test_paired_measurement_rejects_future_timestamp(service):
    study = freeze(service)
    with pytest.raises(ResearchError, match="future"):
        measurement(service, study, stamp=(datetime.now(timezone.utc) + timedelta(days=1)).isoformat())


@pytest.mark.parametrize("field,value", [("sample", " specimen-1 "), ("member", " member-1 "),
                                       ("replicate", " 1 ")])
def test_paired_measurement_rejects_ambiguous_identifiers(service, field, value):
    with pytest.raises(ResearchError, match="whitespace"):
        measurement(service, freeze(service), **{field: value})


def test_frozen_study_rejects_unknown_member(service):
    with pytest.raises(ResearchError, match="member"):
        service.freeze(run_fixture(), {"title": "bad", "endpoint": "relative_pxr_activation",
            "tolerance": .1, "rationale": "test", "mapping": {"x": "unknown"},
            "method_id": "x", "material_id": "x", "controls": ["vehicle"]})


def test_store_is_immutable_and_detects_modified_payload(service):
    record = service.store.put("learning", {"claim": "fixture"})
    changed = copy.deepcopy(record)
    changed["claim"] = "changed"
    with pytest.raises(ResearchError):
        service.store.put("learning", changed)


def test_missing_physical_data_is_pending(service):
    study = freeze(service)
    assert service.compare(study["id"], None)["status"] == "AWAITING_MEASUREMENTS"


def resilience_spec():
    return {
        "title": "Research resilience fixture", "population": "technical fixtures",
        "followup_days": 30, "washout_days": 7, "p_star": .8, "min_subjects": 2,
        "stresses": ["meal"],
        "operations": [{"id": name, "applicable": True, "endpoint": name,
            "unit": "1", "lower": 0, "upper": 1, "rationale": "technical fixture"}
            for name in ("driver", "memory", "repair", "homeostasis", "resilience")],
        "subjects": [{"subject_id": f"subject-{index}", "profile_reference": f"TEST-PROFILE-{index}",
            "healthy_ranges": {name: {"lower": 0, "upper": 1}
                for name in ("driver", "memory", "repair", "homeostasis", "resilience")}}
            for index in range(2)],
    }


def resilience_protocol(service, spec=None):
    with patch("livemorebio.research._now", return_value=(datetime.now(timezone.utc) - timedelta(days=100)).isoformat()):
        return service.register_resilience(spec or resilience_spec())


def resilience_measurement(service, protocol, *, elapsed=40, value=.5, future=False,
                           subject_override=None, stress_elapsed=10, source="PHYSICAL_IMPORT"):
    now = datetime.now(timezone.utc) + (timedelta(days=100) if future else timedelta())
    rows = ["subject_id,operation,endpoint,unit,stress_id,stress_started_at,measured_at,last_treatment_at,value,washout_confirmed,quality_status"]
    last = now - timedelta(days=elapsed)
    stress = last + timedelta(days=stress_elapsed)
    for subject in protocol["subjects"]:
        identifier = subject_override or subject["subject_id"]
        for op in protocol["operations"]:
            if op["applicable"]:
                rows.append(f'{identifier},{op["id"]},{op["endpoint"]},{op["unit"]},meal,{stress.isoformat()},{now.isoformat()},{last.isoformat()},{value},true,pass')
    return service.admit_measurement(protocol["id"], {
        "csv": "\n".join(rows), "source_class": source, "instrument_id": "TEST",
        "calibration_id": "TEST", "method_id": "TEST", "material_id": "TEST",
        "operator_id": "TEST", "controls_passed": True, "calibration_current": True,
        "source_reference": "TEST ONLY",
    })


def test_resilience_rejects_future_measurements(service):
    protocol = resilience_protocol(service)
    with pytest.raises(ResearchError, match="future"):
        resilience_measurement(service, protocol, future=True)


def test_resilience_cannot_inflate_subject_count_with_id_alias(service):
    protocol = resilience_protocol(service)
    with pytest.raises(ResearchError, match="subject"):
        resilience_measurement(service, protocol, subject_override=" subject-0 ")


def test_resilience_rejects_unregistered_subject(service):
    protocol = resilience_protocol(service)
    with pytest.raises(ResearchError, match="subject"):
        resilience_measurement(service, protocol, subject_override="unknown")


def test_resilience_followup_starts_after_washout(service):
    protocol = resilience_protocol(service)
    data = resilience_measurement(service, protocol, elapsed=32)
    result = service.assess_resilience(protocol["id"], [data["id"]])
    assert result["status"] == "NOT_ASSESSABLE"
    assert result["joint_successes"] == 0


def test_resilience_applies_individual_healthy_ranges(service):
    spec = resilience_spec()
    spec["p_star"] = .2
    spec["subjects"][1]["healthy_ranges"]["resilience"] = {"lower": 2, "upper": 3}
    protocol = resilience_protocol(service, spec)
    data = resilience_measurement(service, protocol)
    result = service.assess_resilience(protocol["id"], [data["id"]])
    assert result["status"] == "HYPOTHESIS_CRITERIA_NOT_MET"
    assert result["joint_successes"] == 1
    assert result["cure_claim_authorized"] is False


def test_resilience_rejects_stress_before_washout(service):
    protocol = resilience_protocol(service)
    with pytest.raises(ResearchError, match="stress"):
        resilience_measurement(service, protocol, stress_elapsed=2)


@pytest.mark.parametrize("field,value", [("subjects", []), ("subjects", None), ("stresses", [{}]),
                                       ("operations", [None]*5), ("min_subjects", 3)])
def test_resilience_rejects_malformed_or_incomplete_registration(service, field, value):
    spec = resilience_spec()
    spec[field] = value
    with pytest.raises(ResearchError):
        service.register_resilience(spec)


def test_resilience_requires_every_persons_healthy_range(service):
    spec = resilience_spec()
    spec["subjects"][0]["healthy_ranges"].pop("memory")
    with pytest.raises(ResearchError, match="range"):
        service.register_resilience(spec)


def test_resilience_repeated_files_do_not_inflate_independent_subjects(service):
    protocol = resilience_protocol(service)
    first = resilience_measurement(service, protocol)
    second = resilience_measurement(service, protocol)
    result = service.assess_resilience(protocol["id"], [first["id"], second["id"]])
    assert result["independent_subjects"] == 2
    assert result["registered_subjects"] == 2


def test_resilience_omitting_registered_person_is_not_assessable(service):
    spec = resilience_spec()
    spec["p_star"] = .1
    spec["subjects"].append({**copy.deepcopy(spec["subjects"][0]), "subject_id": "subject-2"})
    protocol = resilience_protocol(service, spec)
    import_protocol = {**protocol, "subjects": protocol["subjects"][:2]}
    data = resilience_measurement(service, import_protocol)
    result = service.assess_resilience(protocol["id"], [data["id"]])
    assert result["status"] == "NOT_ASSESSABLE"
    assert "missing_operation_or_stress" in result["reasons"]


@pytest.mark.parametrize("value", [None, [], 3, "invalid"])
def test_service_rejects_nonobject_specifications(service, value):
    for call in (lambda: service.register_resilience(value), lambda: service.record_learning(value),
                 lambda: service.freeze(run_fixture(), value), lambda: service.admit_measurement("bad", value)):
        with pytest.raises(ResearchError, match="object"):
            call()


@pytest.mark.parametrize("value", [None, [{}], [1], "invalid"])
def test_resilience_assessment_rejects_malformed_measurement_ids(service, value):
    protocol = resilience_protocol(service)
    with pytest.raises(ResearchError):
        service.assess_resilience(protocol["id"], value)


def test_resilience_missing_followup_has_no_cure_result(service):
    protocol = service.register_resilience(resilience_spec())
    result = service.assess_resilience(protocol["id"], [])
    assert result["status"] == "NOT_ASSESSABLE"
    assert result["independent_subjects"] == 0
    assert result["cure_claim_authorized"] is False


def test_resilience_rejects_missing_operation(service):
    spec = resilience_spec()
    spec["operations"].pop()
    with pytest.raises(ResearchError, match="five"):
        service.register_resilience(spec)


def test_learning_records_cannot_change_model_release(service):
    record = service.record_learning({"module": "metabolic", "level": "molecular",
        "claim": "A hypothesis awaiting evidence", "sources": ["https://pubmed.ncbi.nlm.nih.gov/40472098/"],
        "counterevidence": "Evidence varies by context", "test_plan": "Independent dose response",
        "applicability": "No clinical claim", "author": "fixture-operator"})
    assert record["state"] == "PROPOSED"
    assert record["model_change_authorized"] is False


def test_nonfinite_tolerance_rejected(service):
    with pytest.raises(ResearchError):
        service.freeze(run_fixture(), {"tolerance": float("nan")})
