"""Capability-driven forms must not invent an executable population."""
import json
import subprocess
from pathlib import Path
from ._node import run_node as _run_node

LIB = Path(__file__).parents[1] / "aegle/console/lib"


def test_capabilities_preserve_supported_contexts_and_fail_closed():
    script = f"""
import assert from 'node:assert/strict';
import {{populationChoices, cohortIndication}} from {json.dumps((LIB / 'population_forms.js').as_uri())};
const source={{source_id:'public-v1',role:'population_reference'}};
const raw={{schema:'livemore.population-capabilities.v1',templates:[{{id:'healthy',label:'Healthy reference',available:true,scope:'Reduced model'}}],reference_source:source,reference_strata:[{{id:'dpp',label:'High risk',indication:'high-risk',available:true}},{{id:'pxr',label:'PXR research',indication:'hepatic-pxr-research',available:true}}],healthy_reference_cohort:{{available:false,reason:'Not configured'}}}};
const choices=populationChoices(raw);
assert.equal(choices.strata.length,2);assert.equal(choices.healthyCohort.available,false);
assert.equal(cohortIndication(choices,'REFERENCE_GROUNDED_SYNTHETIC','pxr','diabetes'),'hepatic-pxr-research');
assert.equal(cohortIndication(choices,'REAL_HUMAN','',''),'unspecified');
assert.equal(cohortIndication(choices,'REAL_HUMAN','','asthma'),'asthma');
assert.throws(()=>cohortIndication(choices,'REFERENCE_GROUNDED_SYNTHETIC','healthy',''),/stratum/);
assert.throws(()=>populationChoices({{...raw,schema:'other'}}),/capabilities/);
assert.throws(()=>populationChoices({{...raw,reference_strata:[raw.reference_strata[0],raw.reference_strata[0]]}}),/capabilities/);
choices.strata[0].label='changed';assert.equal(raw.reference_strata[0].label,'High risk');
"""
    result = _run_node(["node", "--input-type=module", "-e", script], capture_output=True, text=True, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_forms_have_no_invented_diabetes_default():
    console = LIB.parent
    cohorts = (console / "cohorts.html").read_text(encoding="utf-8")
    twins = (console / "twins.html").read_text(encoding="utf-8")
    assert 'value="T2D development cohort"' not in cohorts
    assert '<input id="cohort-indication"' in cohorts
    assert 'value="type 2 diabetes"' not in twins
    assert 'id="population-capabilities-status"' in cohorts
    assert 'id="population-capabilities-status"' in twins
    code = (LIB / "subjects.js").read_text(encoding="utf-8")
    assert '"/api/population-capabilities"' in code
    assert 'cohortIndication(' in code


def test_source_specific_guidance_does_not_confuse_enrollment_with_generation():
    script = f"""
import assert from 'node:assert/strict';
import {{populationGuidance}} from {json.dumps((LIB / 'population_forms.js').as_uri())};
const choices={{templates:[{{label:'Healthy reference',scope:'Reduced model'}}],healthyCohort:{{available:false,reason:'Healthy population generator is not configured'}}}};
const original=JSON.stringify(choices);
for(const view of ['twins','cohorts']){{
 const real=populationGuidance(view,'REAL_HUMAN',choices);
 assert.match(real.help,/consent/i);assert.match(real.readyStatus,/model-specific/i);
 assert.doesNotMatch(real.help+' '+real.readyStatus,/NHANES|DPP|healthy population generator|Supported reference templates/i);
 const reference=populationGuidance(view,'REFERENCE_GROUNDED_SYNTHETIC',choices);
 assert.match(reference.readyStatus,/Healthy population generator is not configured/);
 assert.match(reference.readyStatus,/not admitted individuals/);
 assert.equal(populationGuidance(view,'REAL_HUMAN',null).readyStatus,null);
 assert.equal(populationGuidance(view,'REFERENCE_GROUNDED_SYNTHETIC',null).readyStatus,null);
 assert.throws(()=>populationGuidance(view,'invented',choices),/source/i);
}}
assert.match(populationGuidance('cohorts','REAL_HUMAN',choices).help,/existing.*active/i);
assert.match(populationGuidance('cohorts','REFERENCE_GROUNDED_SYNTHETIC',choices).help,/aggregate.*priors/i);
assert.throws(()=>populationGuidance('invented','REAL_HUMAN',choices),/view/i);
assert.equal(JSON.stringify(choices),original);
choices.healthyCohort.available=true;
assert.doesNotMatch(populationGuidance('twins','REFERENCE_GROUNDED_SYNTHETIC',choices).readyStatus,/not configured/);
"""
    result = _run_node(["node", "--input-type=module", "-e", script], capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_source_guidance_is_mounted_and_loading_stays_explicit():
    code = (LIB / 'subjects.js').read_text(encoding="utf-8")
    html = (LIB.parent / 'cohorts.html').read_text(encoding="utf-8")
    assert 'id="cohort-source-help"' in html
    assert 'populationGuidance(' in code
    assert "previousSource === 'REFERENCE_GROUNDED_SYNTHETIC'" in code
    assert "previousSource = source.value" in code
    assert "status.textContent='Checking available population contexts…'" in code
