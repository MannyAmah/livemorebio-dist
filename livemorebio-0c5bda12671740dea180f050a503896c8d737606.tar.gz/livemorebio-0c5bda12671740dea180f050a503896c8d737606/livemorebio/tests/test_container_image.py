"""The container must install what we verified, and fail loudly if it cannot."""
from __future__ import annotations

import os
from pathlib import Path
import shlex
import subprocess
import sys

import pytest

from livemorebio import _toolchain

from ._source_tree import (BASE_IMAGE_LACKS, CONTAINER_IMAGE, CONTAINER_IMAGE_PATHS,
                           CONTAINER_IMAGE_VERIFICATION, NEVER_IN_AN_IMAGE, TREE_ENV,
                           dockerfile_system_packages, source_tree_only, summary_report_characters)

REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
DOCKERFILE = REPOSITORY_ROOT / "Dockerfile"

# These read the Dockerfile, which describes the image and is not inside it.
pytestmark = source_tree_only("Dockerfile")


def _commands(dockerfile: str | None = None) -> str:
    """The Dockerfile without its comments: what it does, not what it says.

    Or the same reading of a text given in its place, for a rule that has to
    be shown a Dockerfile it refuses."""
    text = DOCKERFILE.read_text(encoding="utf-8") if dockerfile is None else dockerfile
    return "\n".join(line for line in text.splitlines() if not line.lstrip().startswith("#"))


def test_the_base_names_its_debian_release():
    """``python:3.11-slim`` names no Debian release and follows whichever is
    current. It was already Debian 13 when the Dockerfile was written, so the
    image had never been built on the SUNDIALS the native Linux gate passes
    against, and its first hosted build failed with 64 failures and 15 errors:
    Debian 13 installs libsundials-dev 7.1.1 where Debian 12 installs 6.4.1,
    and Myokit could not compile the cardiac kernel against it. The hash lock
    pins every Python package for the same reason the base has to name its
    release.

    Naming bookworm says which release the image is built on. It does not say
    that the image builds there, which only a build shows.

    A move to another release is a decision, and is made here as well as in
    the Dockerfile, whose comment says what Debian 13 would need."""
    bases = [line.split()[1] for line in _commands().splitlines() if line.startswith("FROM ")]

    assert bases == ["python:3.11-slim-bookworm"]


def test_nothing_the_dockerfile_does_is_specific_to_one_cpu_architecture():
    """No platform flag, and no path under one architecture's library directory.
    That keeps this file from being what confines the image to an architecture,
    and it is all this test shows. It does not show that the image builds on
    every architecture, and today it does not: see the next test."""
    commands = _commands()

    for specific in ("--platform", "amd64", "arm64", "x86_64", "x86-64", "aarch64", "linux-gnu"):
        assert specific not in commands, specific


def test_the_one_architecture_the_image_builds_for_is_stated_where_a_client_reads_it():
    """The image builds for linux/amd64 only, and not because of the Dockerfile.

    The lock pins libroadrunner 2.10.0. PyPI lists 16 files for that release:
    wheels for macOS on arm64 and on x86_64, for manylinux_2_28_x86_64 and for
    win_amd64, each for four Pythons. There is no Linux wheel for arm64 and no
    source distribution, so the hash-locked install has nothing to install on
    linux/arm64. That is what Docker builds by default on an arm64 host, Apple
    Silicon included, and the compose file names no platform.

    None of this can be read from the lock, which holds hashes and no file
    names, and no build here can show it. So the limit is written where a
    client reads it, and tied here to the two things it rests on. A lock that
    moves off this release, or a compose file that starts naming a platform,
    fails this test, and whoever made the change checks again and rewrites
    the sentence."""
    lock = (REPOSITORY_ROOT / "requirements-python311.lock").read_text(encoding="utf-8")
    assert [line.split()[0] for line in lock.splitlines() if line.startswith("libroadrunner==")] == [
        "libroadrunner==2.10.0"]
    assert "platform:" not in (REPOSITORY_ROOT / "docker-compose.yml").read_text(encoding="utf-8")

    readme = " ".join((REPOSITORY_ROOT / "README.md").read_text(encoding="utf-8").split())
    assert "The container image builds for `linux/amd64` only." in readme
    assert "pins libroadrunner 2.10.0, which publishes no Linux wheel for arm64 and no source distribution" in readme
    assert "Apple Silicon" in readme and "Windows on Arm" in readme


def test_container_installs_the_hash_locked_set():
    """An unpinned install resolves different versions than the ones the suite
    passed against, so the image is not the product we verified."""
    text = DOCKERFILE.read_text(encoding="utf-8")
    assert "requirements-python311.lock" in text
    assert "--require-hashes" in text


def test_container_never_silently_degrades_to_a_partial_install():
    """`pip install .[server,kernels] || pip install .[server]` produced an
    image missing the scientific engines, with a successful build."""
    text = DOCKERFILE.read_text(encoding="utf-8")
    assert "|| pip install" not in text


def test_container_builds_the_cardiac_toolchain_it_needs():
    text = DOCKERFILE.read_text(encoding="utf-8")
    assert "libsundials-dev" in text


def _steps() -> list[str]:
    """Every RUN instruction, in order, with its continuation lines joined."""
    joined = _commands().replace("\\\n", " ")
    return [" ".join(line.split()) for line in joined.splitlines() if line.startswith("RUN ")]


def _shell_operators(step: str) -> list[str]:
    """The operators /bin/sh would read in a RUN step, glued to a word or not.

    Quoted text is one word, so the semicolons of a ``python -c`` program are
    not among them."""
    words = shlex.shlex(step.removeprefix("RUN "), posix=True, punctuation_chars=True)
    words.whitespace_split = True
    # shlex takes '#' as the start of a comment wherever it stands, the middle
    # of a word included, and drops the rest of the line. /bin/sh starts one
    # only where a word would start, so after ``pkg#1`` it still reads
    # ``|| true``, and this reader did not. With no comment character, a '#'
    # is part of its word. A real comment is then read as words too, which can
    # only report an operator that /bin/sh would not run, never hide one.
    words.commenters = ""
    return [word for word in words if word and set(word) <= set(words.punctuation_chars)]


def test_no_step_can_succeed_after_a_command_in_it_has_failed():
    """Docker runs a step with ``/bin/sh -c`` and takes the exit status of the
    whole line. ``&&`` is the only way of joining two commands that keeps the
    first one's failure. After ``;`` or ``||``, through a pipe, or in the
    background, the step's status is some later command's: ``... ; echo ok``,
    ``... | tail -20`` and ``... || true`` each turn a failed compile, a failed
    install or a failing suite into a successful build."""
    steps = _steps()

    # The system packages, the Python packages, the probe and the suite.
    assert len(steps) >= 4, steps
    for step in steps:
        assert set(_shell_operators(step)) <= {"&&"}, step


@pytest.mark.parametrize(("suffix", "operators"), [
    ("", []), (" && rm -rf /tmp/scratch", ["&&"]),
    (" ; echo ok", [";"]), (";echo ok", [";"]), (" ; exit 0", [";"]), (" || true", ["||"]), ("||true", ["||"]),
    (" 2>&1 | tail -20", [">&", "|"]), ("|cat", ["|"]), (" & wait", ["&"]), (" > /dev/null", [">"]),
    (" && (exit 0)", ["&&", "(", ")"]),
    # '#' inside a word is part of the word, to /bin/sh. What follows it is still read.
    (" https://example.invalid/a.whl#sha256=0 || true", ["||"]), (" a#b;echo ok", [";"]),
])
def test_an_operator_is_read_wherever_it_is_written(suffix, operators):
    """The reading that the rule above rests on, held to the cases it has to catch."""
    step = 'RUN python -X utf8 -c "from a import b; b(); print(\'x | y && z\')"' + suffix

    assert _shell_operators(step) == operators


def test_the_image_installs_a_copy_of_the_product_and_not_a_link_to_a_tree():
    """``pip install -e`` leaves a finder that supplies any module or
    subpackage directly under ``livemorebio/`` from the tree it was installed
    from. A suite run from a tree that has lost one of those then imports it
    from there, and passes. A module missing from inside a subpackage the
    tree still has is not supplied, and still fails. A rebuilt image tree on
    a developer's machine has that limit, and ``_image_gate`` states it. The
    image must not: its install is a copy of the tree the suite then runs in,
    so a module missing from one is missing from both."""
    installs = [step for step in _steps() if "pip install" in step]

    assert len(installs) == 1 and installs[0].endswith(
        "&& pip install --no-cache-dir --no-deps --no-build-isolation .")
    assert not {"-e", "--editable"} & set(shlex.split(installs[0]))


# The step, word for word. A test that only looked for the probe's name in it
# passed with "; echo ok", "; exit 0" or "| tail -20" written after the
# program, each of which makes a failed compile a successful step.
CARDIAC_PROBE_STEP = ('RUN python -X utf8 -c "from livemorebio._toolchain import _probe_cardiac; _probe_cardiac(); '
                      'print(\'cardiac kernel: compiled and stepped\')"')


def _cardiac_probe_step() -> tuple[int, str]:
    (found,) = [(index, step) for index, step in enumerate(_steps()) if "_probe_cardiac" in step]
    return found


def test_the_image_compiles_the_cardiac_kernel_before_it_runs_the_suite():
    """The kernel is C that Myokit compiles against SUNDIALS when it is first
    used, so installing the Python packages proves nothing about it. On a base
    that could not compile it, the first hosted build found out five minutes
    into the suite, as 61 tests that each said only "Unable to compile."

    So the probe runs as a step of its own: after the package is installed,
    because it is the product's probe, and before the suite, so the build stops
    there. It is called directly. ``cardiac_simulation()`` is the answer for a
    client, one line with the compiler's output dropped, and the compiler's
    output is what a build log needs."""
    steps = _steps()
    index, probe = _cardiac_probe_step()
    installs = [position for position, step in enumerate(steps) if "pip install" in step]
    suite = [position for position, step in enumerate(steps) if "-m pytest" in step]

    assert installs and suite
    assert max(installs) < index < min(suite), steps
    # Nothing may turn a failed compile into a successful step, and nothing may
    # stand between the build log and the compiler's output: not a pipe, not a
    # second command, not a handler inside the program, not
    # ``cardiac_simulation()``. So the step is its exact text.
    assert probe == CARDIAC_PROBE_STEP


def _run_the_cardiac_probe_step(**changes: str) -> subprocess.CompletedProcess[str]:
    """The step's own command, with this interpreter standing in for the image's."""
    _, step = _cardiac_probe_step()
    python, *arguments = shlex.split(step.removeprefix("RUN "))
    # Run without a shell, anything written after the program would be handed
    # to python as arguments it ignores, and the probe would run as though the
    # step ended there. So the step must end there.
    assert python == "python" and arguments[:3] == ["-X", "utf8", "-c"] and len(arguments) == 4, arguments
    state = _toolchain.cardiac_simulation()
    if not state["available"]:
        pytest.skip(f"the cardiac kernel cannot be compiled on this host, so the image's probe cannot be "
                    f"exercised here: {state['reason']}")
    # -I when this run is isolated: the installer verifies a release that way,
    # and a child must not be more exposed to the host than its parent is.
    interpreter = [sys.executable, "-B", *(["-I"] if sys.flags.isolated else [])]
    return subprocess.run([*interpreter, *arguments], cwd=REPOSITORY_ROOT, env={**os.environ, **changes},
                          capture_output=True, text=True, check=False, encoding="utf-8")


def test_the_probe_the_image_runs_compiles_and_steps_on_a_host_that_can():
    result = _run_the_cardiac_probe_step()

    assert result.returncode == 0, result.stdout[-2000:] + result.stderr[-4000:]


def test_the_probe_the_image_runs_fails_with_the_compilers_own_words(tmp_path):
    """A header the compiler cannot find, which is what the Debian 13 base gave
    it. The step has to fail, and the log has to show which header."""
    header = tmp_path / "a-header-this-base-does-not-have.h"

    result = _run_the_cardiac_probe_step(CFLAGS=f"-include {header}")

    assert result.returncode != 0, result.stdout[-2000:]
    assert "Unable to compile." in result.stderr
    assert "Compiler output:" in result.stderr and header.name in result.stderr, result.stderr[-4000:]


def test_container_installs_the_process_tools_a_carried_research_tool_starts():
    """The slim base ships no ``ps``. ``tools/osp_stage_b.py``, which the image
    carries and whose bytes are frozen, samples its child's memory with
    ``/bin/ps``, so two tests of it fail in an image that has not installed the
    package providing it."""
    for tool, package in BASE_IMAGE_LACKS.items():
        assert package in dockerfile_system_packages(DOCKERFILE.read_text(encoding="utf-8")), (tool, package)


def test_container_verifies_itself_before_the_image_is_usable():
    """The native installer runs the suite and refuses on failure. An image that
    skipped that would be a second, unverified way to get the product."""
    text = DOCKERFILE.read_text(encoding="utf-8")
    assert "pytest" in text


def test_the_image_declares_itself_and_reports_every_skip_failure_and_error():
    """Tests of the source tree's release tooling have nothing to read inside the
    image. They may skip there only because this step says the tree is an image,
    and the summary prints each reason into the build log, so no skip is silent.

    The summary has to name the failures and errors too. ``-r`` replaces
    pytest's default rather than adding to it, so ``-rs`` listed the skips and
    nothing else: the first hosted build reported 64 failed and 15 errors under
    121 lines of skips, and named none of them."""
    text = DOCKERFILE.read_text(encoding="utf-8")
    assert f"{TREE_ENV}={CONTAINER_IMAGE}" in text
    verification = next(line for line in text.splitlines() if "-m pytest" in line)
    assert summary_report_characters(verification) >= {"f", "E", "s"}, verification


def test_the_gate_the_suite_reruns_is_the_command_the_image_runs():
    """``test_source_tree_gate`` reruns this step in a rebuilt image tree, with
    neither git nor Node.js. It takes the command from the helper, so the helper
    is held to the Dockerfile's own words.

    The whole step is held, and not only the line that names pytest. What is
    written after the suite decides whether its failure fails the build. With
    ``&& rm -rf`` it does. With ``|| true`` on the next line it did not, and
    every test here passed."""
    (verification,) = [step for step in _steps() if "-m pytest" in step]
    scratch = "/tmp/livemore-image-verification"
    # L0-R22: pytest's own temporary tree is removed in the same step. A test's deliberately long
    # path under it made the build fail to commit the layer after every test had passed.
    pytest_temporary = "/tmp/pytest-of-root"

    # L0-R2: the image owns its pinned cardiac asset and must run its numerical gate.
    assert verification == (f"RUN LIVEMORE_DATA_DIR={scratch} {TREE_ENV}={CONTAINER_IMAGE} LIVEMORE_TEST_CARDIAC=1 "
                            f"python {' '.join(CONTAINER_IMAGE_VERIFICATION)} && rm -rf {scratch} {pytest_temporary}")


def _set_before_the_suite(dockerfile: str) -> list[str]:
    """The ENV and ARG instructions a Dockerfile gives before the step that runs the suite.

    Docker reads an instruction's name in either case and after indentation,
    so both are read that way here."""
    instructions = [" ".join(line.split())
                    for line in _commands(dockerfile).replace("\\\n", " ").splitlines() if line.strip()]
    (suite,) = [index for index, line in enumerate(instructions) if line.startswith("RUN ") and "-m pytest" in line]
    return [line for line in instructions[:suite] if line.split()[0].upper() in ("ENV", "ARG")]


def test_no_instruction_before_the_suite_step_sets_a_variable_for_it():
    """The step's words are held above, and they are not all that decides what
    it does. ENV sets a variable for every step after it, and ARG does the
    same for the rest of its stage. pytest reads ``PYTEST_ADDOPTS`` as more
    of its command line: with ``--collect-only`` there, the same words run no
    test and the step succeeds. No test here read an ENV or ARG line for what
    it sets, and with that line written before the suite every one of them
    passed.

    So nothing is set from outside the step. What the suite needs set is
    written in the step itself, which is held word for word. An ENV meant for
    the running container belongs after the suite."""
    assert _set_before_the_suite(DOCKERFILE.read_text(encoding="utf-8")) == []


@pytest.mark.parametrize("before", ["RUN apt-get update ", "RUN LIVEMORE_DATA_DIR="],
                         ids=["before the first step", "next before the suite"])
@pytest.mark.parametrize("instruction", [
    "ENV PYTEST_ADDOPTS=--collect-only", "ARG PYTEST_ADDOPTS=--collect-only",
    # Docker reads an instruction's name in either case, and after indentation.
    "env PYTEST_ADDOPTS=--collect-only", "    Arg PYTEST_ADDOPTS",
    "ENV LIVEMORE_HOST=0.0.0.0 \\\n    PYTEST_ADDOPTS=--collect-only",
])
def test_a_variable_set_before_the_suite_step_is_reported(instruction, before):
    """The rule above, shown to fail. It is given the Dockerfile's own text
    with one instruction more, as text: the file is not written."""
    dockerfile = DOCKERFILE.read_text(encoding="utf-8")
    assert dockerfile.count(before) == 1, before
    altered = dockerfile.replace(before, f"{instruction}\n{before}")

    assert _set_before_the_suite(altered) == [" ".join(instruction.replace("\\\n", " ").split())]


def test_the_declared_image_contents_are_what_the_dockerfile_copies():
    """Only a path outside the image can be excused. If the Dockerfile starts
    copying something else, the excuse list has to change with it."""
    copied: set[str] = set()
    for line in DOCKERFILE.read_text(encoding="utf-8").splitlines():
        if line.startswith("COPY "):
            *sources, _destination = line.split()[1:]
            # This exact-name wildcard is optional beside mandatory COPY inputs.
            copied.update(source.rstrip("/").replace(".jso[n]", ".json") for source in sources)
    assert copied == set(CONTAINER_IMAGE_PATHS)


def test_the_publisher_marker_is_an_optional_exact_copy_source():
    copies = [shlex.split(step)[1:] for step in _commands().replace("\\\n", " ").splitlines()
              if step.startswith("COPY ")]
    marker_copy = [parts for parts in copies if ".livemore-distribution.jso[n]" in parts]
    assert len(marker_copy) == 1
    assert "pyproject.toml" in marker_copy[0][:-1]
    assert marker_copy[0][-1] == "./"
    assert ".livemore-distribution.json" in CONTAINER_IMAGE_PATHS


def test_the_image_is_given_nothing_that_marks_a_tree_as_not_an_image():
    """A tree declared to be the image is refused if it has a repository, an
    install's environment, or the files that build and install the product.
    The real image must never trip that, so the Dockerfile may not copy one of
    them in, and may not create an environment beside the source."""
    commands = _commands()
    copied = {source.rstrip("/") for line in commands.splitlines() if line.startswith("COPY ")
              for source in line.split()[1:-1]}

    assert not copied & set(NEVER_IN_AN_IMAGE)
    assert "COPY . " not in commands and "ADD " not in commands
    assert "venv" not in commands
