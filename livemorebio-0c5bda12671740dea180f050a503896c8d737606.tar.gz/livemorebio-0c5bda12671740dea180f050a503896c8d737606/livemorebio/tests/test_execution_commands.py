"""CLI/REPL/pipeline contract tests use a recording SDK, never a live service."""
import io
import json
from pathlib import Path
import shlex
import stat
import sys

import pytest

from livemorebio.tests.test_execution_clients import IDENTITY, PREPARE, SESSION


class RecordingPlatform:
    mode = "attach"

    def __init__(self):
        self.calls = []

    def __getattr__(self, name):
        def call(*args, **kwargs):
            self.calls.append((name, args, kwargs))
            return {"execution_id": IDENTITY, "revision": 3, "state": "paused", "source_valid": True,
                    "series": [{"private_biomarker": 123}], "authorship": "engine", "evidence_class": "MODELED"}
        return call


@pytest.mark.parametrize("tokens,method,args,kwargs", [
    (["execution", "capabilities"], "execution_capabilities", (), {}),
    (["execution", "status", IDENTITY], "execution_status", (IDENTITY,), {}),
    (["execution", "frames", IDENTITY, "after=0", "limit=2"], "execution_frames", (IDENTITY,), {"after_frame": 0, "limit": 2}),
    (["execution", "observations", IDENTITY], "execution_observations", (IDENTITY,), {}),
    *[(["execution", action, IDENTITY, "revision=3", "generation=generation-a"], action + "_execution", (IDENTITY,),
       {"expected_revision": 3, "expected_source_generation": "generation-a"}) for action in ("start", "pause", "resume", "stop")],
    (["patch", "virtual", "capabilities"], "virtual_patch_capabilities", (), {}),
    (["patch", "virtual", "probe", "device=virtual-a"], "register_virtual_probe", ("virtual-a",), {}),
    (["patch", "virtual", "status", IDENTITY], "virtual_session_status", (IDENTITY,), {}),
    *[(["patch", "virtual", action, IDENTITY, "revision=3"], action + "_virtual_session", (IDENTITY,),
       {"expected_revision": 3}) for action in ("pause", "resume", "stop")],
])
def test_shared_command_and_shell_have_exact_sdk_parity(tokens, method, args, kwargs):
    from livemorebio.execution_commands import run_continuous_command
    from livemorebio.shell import run_command
    for execute in (lambda p, out: run_continuous_command(p, tokens, out=out),
                    lambda p, out: run_command(p, shlex.join(tokens), out=out)):
        platform, output = RecordingPlatform(), []
        result = execute(platform, output.append)
        assert platform.calls == [(method, args, kwargs)]
        assert result["state"] == "paused"
        assert "private_biomarker" not in "".join(output)
        assert "paused" in "".join(output) and "MODELED" in "".join(output)


@pytest.mark.parametrize("action,body,expected", [("prepare", PREPARE, "prepare_execution"),
    ("fork", {**PREPARE, "expected_parent_revision": 4}, "fork_execution_checkpoint"),
    ("session", SESSION, "start_virtual_session")])
def test_private_files_and_stdin_preserve_exact_payload_and_key(tmp_path, action, body, expected):
    from livemorebio.execution_commands import run_continuous_command
    path = tmp_path / "private request.json"
    path.write_text(json.dumps(body), encoding="utf-8")
    for location in (str(path), "-"):
        prefix = ["patch", "virtual", "start"] if action == "session" else ["execution", action]
        tokens = prefix + ([IDENTITY] if action == "fork" else []) + [location]
        if action != "session":
            tokens += ["key=00001"]
        platform, output = RecordingPlatform(), []
        run_continuous_command(platform, tokens, out=output.append, stdin=io.BytesIO(json.dumps(body).encode()))
        call = platform.calls[0]
        assert call == (expected, (IDENTITY, body) if action == "fork" else (body,),
                        {} if action == "session" else {"idempotency_key": "00001"})
        assert str(path) not in "".join(output) and "00001" not in "".join(output)


@pytest.mark.parametrize("tail", ["revision=1 revision=2 generation=a", "revision=true generation=a",
    "revision=1.0 generation=a", "revision=-1 generation=a", "revision=1 generation=a extra=1",
    "revision=1", "revision=1 generation=a overflow", 'revision=1 generation="PRIVATE'])
def test_bad_new_shell_options_reject_without_coercion_or_http(tail):
    from livemorebio.execution_client import ContinuousClientError
    from livemorebio.shell import run_command
    platform = RecordingPlatform()
    with pytest.raises(ContinuousClientError) as caught:
        run_command(platform, f"execution start {IDENTITY} {tail}")
    assert not platform.calls and "PRIVATE" not in str(caught.value)


def test_json_inputs_bounded_duplicate_safe_and_output_exclusive_private(tmp_path):
    from livemorebio.execution_client import ContinuousClientError
    from livemorebio.execution_commands import run_continuous_command
    platform = RecordingPlatform()
    for raw in (b'{"x":1,"x":2}', b'{"x":NaN}', b'x' * 16385):
        with pytest.raises(ContinuousClientError):
            run_continuous_command(platform, ["execution", "prepare", "-", "key=one"], stdin=io.BytesIO(raw))
    assert not platform.calls
    path = tmp_path / "private.json"
    output = []
    run_continuous_command(platform, ["execution", "status", IDENTITY, f"output={path}"], out=output.append)
    assert stat.S_IMODE(path.stat().st_mode) == 0o600
    assert "private_biomarker" in path.read_text(encoding="utf-8")
    assert "private_biomarker" not in "".join(output)
    previous = path.read_bytes()
    with pytest.raises(ContinuousClientError):
        run_continuous_command(platform, ["execution", "status", IDENTITY, f"output={path}"])
    assert path.read_bytes() == previous
    link = tmp_path / "link.json"
    link.symlink_to(path)
    with pytest.raises(ContinuousClientError):
        run_continuous_command(platform, ["execution", "status", IDENTITY, f"output={link}"])
    output.clear()
    run_continuous_command(platform, ["execution", "status", IDENTITY, "json=true"], out=output.append)
    assert "private_biomarker" in "".join(output)


def test_pipeline_redacts_new_command_echo_and_stops_after_unconfirmed_mutation(tmp_path):
    from livemorebio.execution_client import ContinuousClientError
    from livemorebio.shell import run_pipeline
    platform = RecordingPlatform()
    def failed(*args, **kwargs):
        raise ContinuousClientError("CLIENT_UNCONFIRMED")
    platform.prepare_execution = failed
    request = tmp_path / "PRIVATE.json"
    request.write_text(json.dumps(PREPARE), encoding="utf-8")
    pipeline = tmp_path / "test.lmr"
    pipeline.write_text(f"execution prepare {shlex.quote(str(request))} key=PRIVATE\nexecution capabilities\n", encoding="utf-8")
    output = []
    with pytest.raises(ContinuousClientError):
        run_pipeline(platform, pipeline, out=output.append)
    assert "PRIVATE" not in "".join(output) and "execution prepare" in "".join(output)
    assert not platform.calls


def test_direct_cli_attaches_and_has_safe_nonzero_failure(monkeypatch, capsys):
    from livemorebio import cli, sdk
    from livemorebio.execution_client import ContinuousClientError
    platform = RecordingPlatform()
    def factory(*, mode):
        assert mode == "attach"
        return platform
    monkeypatch.setattr(sdk, "Platform", factory)
    monkeypatch.setattr(sys, "argv", ["livemore", "execution", "status", IDENTITY])
    cli.main()
    assert platform.calls == [("execution_status", (IDENTITY,), {})]
    def failed(*a, **kw):
        raise ContinuousClientError("CLIENT_UNCONFIRMED", request_id="b" * 32)
    platform.execution_status = failed
    with pytest.raises(SystemExit) as caught:
        cli.main()
    assert caught.value.code == 1
    assert "CLIENT_UNCONFIRMED" in capsys.readouterr().out


def test_direct_cli_unknown_first_option_is_not_echoed_by_argparse(monkeypatch, capsys):
    from livemorebio import cli, sdk
    platform = RecordingPlatform()
    monkeypatch.setattr(sdk, "Platform", lambda **kw: platform)
    monkeypatch.setattr(sys, "argv", ["livemore", "execution", "--PRIVATE"])
    with pytest.raises(SystemExit) as caught:
        cli.main()
    output = capsys.readouterr()
    assert caught.value.code == 1 and not platform.calls
    assert "PRIVATE" not in output.out + output.err


def test_cleanup_warning_keeps_explicit_json_output_parseable(capsys):
    from livemorebio.execution_commands import run_continuous_command
    platform = RecordingPlatform()
    platform.last_continuous_response = {"cleanup_code": "CLIENT_TRANSPORT"}
    run_continuous_command(platform, ["execution", "status", IDENTITY, "json=true"])
    output = capsys.readouterr()
    assert json.loads(output.out)["execution_id"] == IDENTITY
    assert "CLIENT_TRANSPORT" in output.err


def test_export_failure_preserves_confirmed_ack_and_request_id_without_values(tmp_path):
    from livemorebio.execution_commands import run_continuous_command
    from livemorebio.execution_client import ContinuousClientError
    platform = RecordingPlatform()
    platform.last_continuous_response = {"request_id": "d" * 32}
    path = tmp_path / "existing.json"
    path.write_text("keep this file", encoding="utf-8")
    output = []
    with pytest.raises(ContinuousClientError) as caught:
        run_continuous_command(platform, ["patch", "virtual", "probe", "device=virtual-a", f"output={path}", "json=true"],
                               out=output.append)
    assert len(platform.calls) == 1
    assert caught.value.code == "CLIENT_OUTPUT" and caught.value.request_id == "d" * 32
    assert "confirmed" in str(caught.value).lower()
    assert json.loads(output[0])["execution_id"] == IDENTITY
    assert "private_biomarker" not in "".join(output)
    assert path.read_text(encoding="utf-8") == "keep this file"


def test_quoted_family_still_uses_strict_parser_and_private_echo(tmp_path):
    from livemorebio.shell import run_pipeline
    from livemorebio.execution_client import ContinuousClientError
    platform = RecordingPlatform()
    pipeline = tmp_path / "quote.lmr"
    pipeline.write_text(f'"execution" start {IDENTITY} revision=1 revision=2 generation=PRIVATE\n', encoding="utf-8")
    output = []
    with pytest.raises(ContinuousClientError):
        run_pipeline(platform, pipeline, out=output.append)
    assert not platform.calls and "PRIVATE" not in "".join(output)


def test_compact_session_includes_original_clock_metadata_not_values():
    from livemorebio.execution_commands import run_continuous_command
    platform = RecordingPlatform()
    record = {"session_id": IDENTITY, "state": "blocked", "last_generated_at": "2026-09-08T00:00:00Z",
              "last_captured_at": "2026-09-08T00:00:01Z", "last_acknowledged_at": None,
              "producer": {"state": "paused", "consumer_lease": {"required": True, "state": "expired"}},
              "binding": {"selection": {"subject_id": "PRIVATE", "source_data_class": "SYNTHETIC"}},
              "pending": {"value": 123}}
    platform.virtual_session_status = lambda *a: record
    output = []
    run_continuous_command(platform, ["patch", "virtual", "status", IDENTITY], out=output.append)
    displayed = json.loads(output[0])
    assert displayed["last_generated_at"] == record["last_generated_at"]
    assert displayed["last_captured_at"] == record["last_captured_at"]
    assert displayed["last_acknowledged_at"] is None
    assert displayed["producer"]["consumer_lease"]["state"] == "expired"
    assert "PRIVATE" not in output[0] and "value" not in output[0]


def test_interactive_new_error_is_safe_and_shell_continues(monkeypatch, capsys):
    from livemorebio import shell
    from livemorebio.execution_client import ContinuousClientError
    platform = RecordingPlatform()
    platform.state = lambda: {"profile": "technical fixture"}
    def failed(*a, **kw):
        raise ContinuousClientError("EXECUTION_CONFLICT")
    platform.execution_status = failed
    monkeypatch.setattr(shell, "Platform", lambda **kw: platform)
    lines = iter([f"execution status {IDENTITY}", "quit"])
    monkeypatch.setattr("builtins.input", lambda *a: next(lines))
    shell.run_shell(mode="attach")
    output = capsys.readouterr().out
    assert "EXECUTION_CONFLICT" in output and "bye" in output
