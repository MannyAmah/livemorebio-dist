"""A source-parameterized rat-vesicle calculation is not a human experiment."""
from copy import deepcopy
import math

import pytest

from livemorebio.cendos import lobeline_vmat2 as assay


def specification():
    return {"material_id": "lobeline-hemisulfate",
            "context_id": "rat-striatal-synaptic-vesicles",
            "concentration_unit": "uM", "substrate_concentrations": [0, 0.001, 0.1, 0.11, 1, 5],
            "inhibitor_concentrations": [0, 0.25]}


def test_equation_matches_independently_calculated_values_and_limits():
    assert assay.initial_rate(0.1, 0) == pytest.approx(22.23809523809524)
    assert assay.initial_rate(0.1, 0.25) == pytest.approx(17.392234548335978)
    assert assay.initial_rate(0, 0.25) == 0
    assert assay.initial_rate(0.11, 0) == pytest.approx(46.7 / 2)
    assert assay.initial_rate(1e9, 0.25) == pytest.approx(46.7, rel=1e-8)
    for inhibitor in (0, 0.1, 0.25):
        rates = [assay.initial_rate(s, inhibitor) for s in (0, .001, .1, 1, 5)]
        assert rates == sorted(rates)
        assert all(0 <= value <= 46.7 for value in rates)
    assert assay.initial_rate(.1, 0) > assay.initial_rate(.1, .1) > assay.initial_rate(.1, .25)


def test_run_freezes_source_and_contradiction_without_fitting_or_people():
    request = specification()
    before = deepcopy(request)
    result = assay.run_lobeline_vmat2(request)
    assert request == before
    assert result["protocol_id"] == assay.PROTOCOL_ID
    assert result["evidence_state"] == "MODELED_INITIAL_RATE"
    assert result["qualification_state"] == "NOT_QUALIFIED"
    assert result["scope"] == "nonhuman_assay_reference"
    assert result["native_axis"]["quantity"] == "substrate_concentration"
    assert result["native_axis"]["unit"] == "uM"
    assert result["unit"] == "pmol/min/mg protein"
    assert result["calibration_authorized"] is False
    assert result["live_twin_modified"] is False
    assert not {"cohort", "cohorts", "members", "t_min", "time", "trajectory"} & result.keys()
    reference = result["benchmark_discrepancy"]
    assert reference["predicted_apparent_km_um"] == pytest.approx(.16851063829787233)
    assert reference["reported_apparent_km_um"] == .29
    assert reference["difference_um"] == pytest.approx(-.12148936170212765)
    assert reference["status"] == "UNQUALIFIED_DISCREPANCY"
    assert reference["statistical_assessment"] == "UNAVAILABLE_WITHOUT_RAW_DATA_AND_PRESPECIFIED_CRITERION"
    assert result["source_record"]["parameters"]["ki_um"]["value"] == .47
    assert result["source_record"]["context"]["incubation_duration_min"] == 8
    assert "endpoint" in result["source_record"]["context"]["measurement_basis"]
    assert all(control["passed"] for control in result["controls"])
    assert result["conditions"][0]["points"][0]["rate_fraction"] is None
    assert result["input_sha256"] == assay.canonical_hash(result["input"])
    assert result["source_sha256"] == assay.canonical_hash(result["source_record"])
    result["source_record"]["parameters"]["ki_um"]["value"] = 100
    assert assay.source_record()["parameters"]["ki_um"]["value"] == .47


def test_units_are_normalized_before_computation_and_hashing():
    original = specification()
    nm = deepcopy(original)
    nm["concentration_unit"] = "nM"
    for field in ("substrate_concentrations", "inhibitor_concentrations"):
        nm[field] = [value * 1000 for value in nm[field]]
    a, b = assay.run_lobeline_vmat2(original), assay.run_lobeline_vmat2(nm)
    assert a["input"] == b["input"]
    assert a["input_sha256"] == b["input_sha256"]
    assert a["conditions"] == b["conditions"]


@pytest.mark.parametrize("field,value", [
    ("material_id", "lobelia-extract"), ("context_id", "human-brain"),
    ("context_id", " rat-striatal-synaptic-vesicles"), ("concentration_unit", "mg/mL"),
    ("cohort_id", "cohort-test"), ("ki_um", .15),
    ("substrate_concentrations", []), ("substrate_concentrations", [True, .1]),
    ("substrate_concentrations", ["0.1", 1]), ("substrate_concentrations", [.1, math.nan]),
    ("substrate_concentrations", [.1, math.inf]), ("substrate_concentrations", [-1, .1]),
    ("substrate_concentrations", [.0001, .1]), ("substrate_concentrations", [.1, 6]),
    ("substrate_concentrations", [.1, .1]), ("substrate_concentrations", [.1] * 201),
    ("inhibitor_concentrations", [.25]), ("inhibitor_concentrations", [0]),
    ("inhibitor_concentrations", [0, .25, .5]), ("inhibitor_concentrations", [0, .25, True]),
    ("inhibitor_concentrations", [0, .25, .25]),
])
def test_rejects_incomplete_inapplicable_or_coerced_inputs(field, value):
    request = specification()
    request[field] = value
    with pytest.raises(assay.LobelineProtocolError) as error:
        assay.run_lobeline_vmat2(request)
    assert error.value.code == "INVALID_LOBELINE_SPECIFICATION"


@pytest.mark.parametrize("value", [None, [], {}, True, "specification"])
def test_missing_or_nonobject_request_rejected(value):
    with pytest.raises(assay.LobelineProtocolError):
        assay.validate_spec(value)


@pytest.mark.parametrize("substrate,inhibitor", [(True, 0), (-1, 0), (.1, -1), (math.inf, 0)])
def test_public_equation_rejects_invalid_numbers(substrate, inhibitor):
    with pytest.raises(assay.LobelineProtocolError):
        assay.initial_rate(substrate, inhibitor)
