"""Ordinary Biology reconciliation using its real inline controller.

All quantities and identities are authored technical fixtures, not participants.
The explicit test-only scope seam observes STATE and supplies a graphics double;
no controller function, molecular implementation or WebGL behavior is replaced.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess

import pytest

from .biology_ui_fixtures import CONSOLE, biology_controller_script
from ._node import require_node, run_node as _run_node


PREAMBLE = r"""
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();
const canvas=new Proxy({},{get:()=>()=>{}}),calls=[],frames=new Map();let frame=0;
function el(id){if(!nodes.has(id))nodes.set(id,{textContent:'',innerHTML:'',style:{},dataset:{},handlers:{},hidden:false,disabled:false,clientWidth:800,clientHeight:500,value:'off',checked:true,addEventListener(k,v){this.handlers[k]=v},getContext:()=>canvas});return nodes.get(id)}
const heart={id:'heart',name:'Technical reference heart',status:'unknown',metric:'reference',value:null,ratio:null,targets:['KCNH2'],pathways:[],cell:{type:'Technical myocyte',render:'reference',quantities:[],evidence_state:'REFERENCE_ONLY'}};
const kidney={...heart,id:'kidney',name:'Technical reference kidney',targets:[],cell:{...heart.cell,type:'Technical renal cell'}};
function state(key='a'.repeat(64),organs=[heart,kidney]){return {context_id:key,twin:{profile:'technical-only',human:'No participant',conditions:[]},organs}}
let payload=state(),httpOk=true;
const context={URLSearchParams,AbortController,location:{search:''},window:{},document:{hidden:false,getElementById:el,querySelector:el,createElement:()=>({getContext:()=>null}),addEventListener(){}},console:{warn(){}},fetch:async(path)=>{calls.push(path);if(path==='/api/biology')return{ok:httpOk,status:httpOk?200:503,json:async()=>payload};if(path==='/api/state')return{ok:true,json:async()=>({context_id:payload.context_id,cardiac:{v:[-80,20,-80],cai:[0.0001,0.0002,0.0001],t_ms:[0,100,200]}})};throw Error('UNEXPECTED_REQUEST')},setTimeout:()=>1,clearTimeout(){},performance:{now:()=>1000},devicePixelRatio:1,addEventListener(){},requestAnimationFrame:fn=>{frames.set(++frame,fn);return frame},cancelAnimationFrame:id=>frames.delete(id)};
async function flush(){for(let i=0;i<8;i++)await new Promise(setImmediate)}
async function mount(){await vm.runInNewContext('(async()=>{'+SOURCE+'})()',context);await flush()}
async function refresh(){await el('biology-retry').handlers.click();await flush()}
function graphics(){return {isolated:null,scene:{visible:true},clears:0,focus:0,contexts:[],setContext(id){this.contexts.push(id);return false},setOrgans(){},updateStates(){},invalidate(){},isolate(id){this.isolated=id;this.focus++},clearIsolation(){this.isolated=null;this.clears++},dispose(){}}}
"""


def run_controller(body: str) -> None:
    node = require_node()
    script = biology_controller_script()
    anchor = "loadBiology();\ninitAnatomy();"
    assert script.count(anchor) == 1
    selection = re.findall(r"^\s+onSelect: (.*),$", script, re.M)
    assert len(selection) == 1, "Capture the actual ordinary anatomy selection callback"
    seam = (
        "window.testScope={state:()=>STATE,view:()=>VIEW,selected:()=>selectedOrganId,"
        "attachGraphics:value=>{EX=value;},anatomySelect:" + selection[0] + "};\n"
    )
    script = script.replace(anchor, seam + anchor, 1)
    program = (
        PREAMBLE.replace("SOURCE", json.dumps(script))
        + "\n(async()=>{\n" + body
        + "\nprocess.stdout.write('ok');})().catch(e=>{console.error(e);process.exitCode=1});"
    )
    result = _run_node([node, "--eval", program], capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    assert result.stdout == "ok"


@pytest.mark.parametrize("bad", [None, "", "context-a", "a" * 63, "a" * 65,
                                      "A" * 64, "a" * 64 + "\n", ["a" * 64], 1, True])
def test_invalid_initial_context_cannot_publish_or_start_a_cell_trace(bad: object) -> None:
    run_controller("payload=state(" + json.dumps(bad) + r""");await mount();
a.equal(context.window.testScope.state(),null,'invalid context was published');
a(!el('panel').innerHTML.includes(heart.name),'unconfirmed organs were displayed');
a(el('biology-status').textContent.includes('No model values loaded'));
await context.window._cell('heart');a.deepEqual(calls,['/api/biology']);
""")


@pytest.mark.parametrize("bad", [None, "bad-context", ["b" * 64]])
def test_invalid_refresh_retains_only_the_last_confirmed_readout(bad: object) -> None:
    run_controller(r"""
await mount();const accepted=context.window.testScope.state();
context.window._sel('heart');const previous=el('panel').innerHTML;
payload={...state(BAD),twin:{...payload.twin,human:'UNCONFIRMED_OTHER'},organs:[kidney]};await refresh();
a.equal(context.window.testScope.state(),accepted,'failed refresh replaced confirmed identity');
a.equal(el('panel').innerHTML,previous,'failed refresh replaced the confirmed detail');
a(el('biology-status').textContent.includes('may be stale'));a(!el('biology-retry').hidden);
const count=calls.length;await context.window._cell('heart');a.equal(calls.length,count,'stale view requested a new trace');
payload=state();await refresh();await context.window._cell('heart');
a.equal(el('cellmodal').style.display,'block','valid refresh did not restore cell entry');
""".replace("BAD", json.dumps(bad)))


@pytest.mark.parametrize("changed_context", [False, True])
@pytest.mark.parametrize("empty", [False, True])
def test_removed_selected_organ_clears_detail_cell_and_isolation(
    changed_context: bool, empty: bool,
) -> None:
    run_controller(r"""
await mount();const view=graphics();context.window.testScope.attachGraphics(view);
context.window._sel('heart');await context.window._cell('heart');
a.equal(view.isolated,'heart');a.equal(el('cellmodal').style.display,'block');
payload=state(KEY,ORGANS);await refresh();
a.equal(context.window.testScope.view(),'overview','removed detail remained active');
a.equal(context.window.testScope.selected(),null,'removed organ remained selected');
a.equal(view.isolated,null);a.equal(view.clears,1);a.equal(el('cellmodal').style.display,'none');
a(!el('panel').innerHTML.includes('<h2>Technical reference heart</h2>'));
a(!el('panel').innerHTML.includes('Technical myocyte'));
if(payload.organs.length)a(el('panel').innerHTML.includes(kidney.name));
a.equal(calls.filter(p=>p==='/api/state').length,0,'reference reconciliation started physiology');
await refresh();a.equal(view.clears,1,'repeated ordinary refresh stole isolation again');
""".replace("KEY", json.dumps(("b" if changed_context else "a") * 64))
                  .replace("ORGANS", "[]" if empty else "[kidney]"))


def test_same_organ_refresh_preserves_detail_isolation_and_cell() -> None:
    run_controller(r"""
await mount();const view=graphics();context.window.testScope.attachGraphics(view);
context.window._sel('heart');await context.window._cell('heart');
payload=state('a'.repeat(64),[{...heart,role:'Updated reference annotation'},kidney]);await refresh();
a.equal(context.window.testScope.view(),'detail');a.equal(context.window.testScope.selected(),'heart');
a.equal(view.isolated,'heart');a.equal(view.focus,1,'refresh restarted camera isolation');a.equal(view.clears,0);
a(el('panel').innerHTML.includes('Updated reference annotation'));a.equal(el('cellmodal').style.display,'block');
""")


def test_failed_refresh_pauses_replay_and_blocks_new_trace_until_valid_refresh() -> None:
    run_controller(r"""
const activeHeart={...heart,cell:{...heart.cell,render:'cardiac'}};payload=state('a'.repeat(64),[activeHeart]);
await mount();await context.window._cell('heart');a.equal(frames.size,1);
httpOk=false;await refresh();a.equal(frames.size,0);
const count=calls.length;await context.window._cell('heart');a.equal(calls.length,count);a.equal(el('cellmodal').style.display,'none');
httpOk=true;await refresh();await context.window._cell('heart');a.equal(frames.size,1);
""")


def test_late_same_key_trace_after_invalid_refresh_cannot_restart_replay() -> None:
    run_controller(r"""
payload=state('a'.repeat(64),[{...heart,cell:{...heart.cell,render:'cardiac'}}]);
await mount();let release;const ordinaryFetch=context.fetch;
context.fetch=async path=>{const response=await ordinaryFetch(path);if(path!=='/api/state')return response;const body=await response.json();await new Promise(resolve=>release=resolve);return {ok:true,json:async()=>body}};
const pending=context.window._cell('heart');await flush();a.equal(typeof release,'function');
payload=state(null);await refresh();a.equal(frames.size,0);
release();await pending;a.equal(frames.size,0,'late same-key trace restarted stale replay');
a(!el('cell-data-status').textContent.startsWith('Replaying saved model'));
""")


def test_already_scheduled_cell_frame_refuses_after_failed_refresh() -> None:
    run_controller(r"""
payload=state('a'.repeat(64),[{...heart,cell:{...heart.cell,render:'cardiac'}}]);
await mount();await context.window._cell('heart');const lateFrame=[...frames.values()][0];
a.equal(typeof lateFrame,'function');httpOk=false;await refresh();a.equal(frames.size,0);
lateFrame();a.equal(frames.size,0,'late frame rescheduled a stale trace');
""")


def test_cached_anatomy_selection_cannot_revive_removed_organ() -> None:
    run_controller(r"""
await mount();context.window._sel('heart');payload=state('a'.repeat(64),[kidney]);await refresh();
a.equal(context.window.testScope.view(),'overview');context.window.testScope.anatomySelect(heart);
a.equal(context.window.testScope.view(),'overview','cached mesh revived removed organ');
a.equal(context.window.testScope.selected(),null);a(!el('panel').innerHTML.includes('<h2>Technical reference heart</h2>'));
""")


def test_cached_anatomy_selection_resolves_same_id_to_current_annotation() -> None:
    run_controller(r"""
await mount();payload=state('a'.repeat(64),[{...heart,role:'CURRENT_REFERENCE_ANNOTATION'},kidney]);await refresh();
context.window.testScope.anatomySelect({...heart,role:'OLD_REFERENCE_ANNOTATION'});
a.equal(context.window.testScope.selected(),'heart');a(el('panel').innerHTML.includes('CURRENT_REFERENCE_ANNOTATION'));
a(!el('panel').innerHTML.includes('OLD_REFERENCE_ANNOTATION'),'cached data replaced current organ');
""")


def test_stale_cell_entry_preserves_warning_and_retry_without_trace() -> None:
    run_controller(r"""
await mount();context.window._sel('heart');await context.window._cell('heart');
httpOk=false;await refresh();
const warning=el('biology-status').textContent,detail=el('panel').innerHTML,count=calls.length;
a(warning.includes('may be stale'));
await context.window._cell('heart');
a.equal(el('biology-status').textContent,warning,'stale warning was replaced');
a.equal(el('panel').innerHTML,detail);a(!el('biology-retry').hidden);
a.equal(el('cellmodal').style.display,'none');a.equal(calls.length,count);a.equal(frames.size,0);
""")


def test_fixed_biology_headings_do_not_claim_execution_for_unavailable_models() -> None:
    page = (CONSOLE / 'biology.html').read_text(encoding="utf-8")
    assert '<h1>Living <em>Biology</em></h1>' in page
    assert 'mountShell("/biology", "Multiscale biology — model state and evidence")' in page
