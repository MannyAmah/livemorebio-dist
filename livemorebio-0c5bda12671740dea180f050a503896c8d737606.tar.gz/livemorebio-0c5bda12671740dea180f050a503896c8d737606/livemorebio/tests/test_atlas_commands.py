"""Atlas CLI, REPL, pipelines and notebooks share one attached reference API."""
from copy import deepcopy
import json
import shlex
import sys

import pytest

from livemorebio.tests.test_atlas_clients import INSTALLED, MISSING, SOURCE


class RecordingPlatform:
    mode = "attach"

    def __init__(self):
        self.calls = []
        self.last_atlas_response = {}

    def atlas_reference_status(self):
        self.calls.append(("status",))
        return deepcopy(MISSING)

    def install_atlas_reference(self, source):
        self.calls.append(("install", source))
        return deepcopy(INSTALLED)


@pytest.mark.parametrize("tokens,expected", [(["atlas", "status"], ("status",)),
    (["atlas", "install", SOURCE], ("install", SOURCE))])
def test_command_and_shell_match_sdk_and_keep_reference_only_output(tokens, expected):
    from livemorebio.atlas_commands import run_atlas_command
    from livemorebio.shell import run_command
    for run in (lambda p, out: run_atlas_command(p, tokens, out=out),
                lambda p, out: run_command(p, shlex.join(tokens), out=out)):
        platform, output = RecordingPlatform(), []
        result = run(platform, output.append)
        shown = json.loads(output[0])
        assert platform.calls == [expected]
        assert shown["reference_geometry"] is True and shown["patient_registered"] is False
        assert shown["state"] == result["state"] and "manifest" not in shown and "reason" not in shown
        if expected[0] == "install":
            assert shown["receipt"] == INSTALLED["receipt"]


@pytest.mark.parametrize("tail", ["", "PRIVATE", "status extra=PRIVATE", "status json=true json=false",
    "status json=1", "status json=True", "status PRIVATE", "install", "install PRIVATE", "status --PRIVATE",
    "install " + SOURCE + " extra", 'status json="PRIVATE'])
def test_bad_command_and_quote_never_reaches_sdk_or_echoes_input(tail):
    from livemorebio.atlas_client import AtlasClientError
    from livemorebio.shell import run_command
    platform, output = RecordingPlatform(), []
    with pytest.raises(AtlasClientError) as caught:
        run_command(platform, "atlas " + tail, out=output.append)
    assert not platform.calls and not output and "PRIVATE" not in str(caught.value)


def test_inprocess_does_not_use_a_local_cache_fallback():
    from livemorebio.atlas_client import AtlasClientError
    from livemorebio.atlas_commands import run_atlas_command
    platform = RecordingPlatform()
    platform.mode = "inprocess"
    with pytest.raises(AtlasClientError, match="attached"):
        run_atlas_command(platform, ["atlas", "status"])
    assert not platform.calls


def test_explicit_json_keeps_manifest_and_cleanup_warning_off_stdout(capsys):
    from livemorebio.atlas_commands import run_atlas_command
    platform = RecordingPlatform()
    platform.last_atlas_response = {"cleanup_code": "ATLAS_CLIENT_TRANSPORT"}
    run_atlas_command(platform, ["atlas", "install", SOURCE, "json=true"])
    captured = capsys.readouterr()
    assert json.loads(captured.out) == INSTALLED
    assert "ATLAS_CLIENT_TRANSPORT" in captured.err


def test_pipeline_redacts_input_and_stops_after_unconfirmed_install(tmp_path):
    from livemorebio.atlas_client import AtlasClientError
    from livemorebio.shell import run_pipeline
    platform = RecordingPlatform()
    def fail(source):
        platform.calls.append(("failed-install", source))
        raise AtlasClientError("ATLAS_CLIENT_UNCONFIRMED")
    platform.install_atlas_reference = fail
    path = tmp_path / "technical.lmr"
    path.write_text(f'"atlas" install {SOURCE}\natlas status\n', encoding="utf-8")
    output = []
    with pytest.raises(AtlasClientError):
        run_pipeline(platform, path, out=output.append)
    assert platform.calls == [("failed-install", SOURCE)]
    assert output == ["livemore› atlas install"]
    path.write_text('"atlas" install PRIVATE\n', encoding="utf-8")
    output.clear()
    with pytest.raises(AtlasClientError):
        run_pipeline(platform, path, out=output.append)
    assert "PRIVATE" not in "".join(output)


def test_direct_cli_attaches_and_returns_safe_failure(monkeypatch, capsys):
    from livemorebio import cli, sdk
    from livemorebio.atlas_client import AtlasClientError
    platform = RecordingPlatform()
    def factory(*, mode):
        assert mode == "attach"
        return platform
    monkeypatch.setattr(sdk, "Platform", factory)
    monkeypatch.setattr(sys, "argv", ["livemore", "atlas", "status"])
    cli.main()
    assert platform.calls == [("status",)]
    assert json.loads(capsys.readouterr().out)["state"] == "missing"
    def fail():
        raise AtlasClientError("ATLAS_CLIENT_TRANSPORT", request_id="c" * 32)
    platform.atlas_reference_status = fail
    with pytest.raises(SystemExit) as caught:
        cli.main()
    assert caught.value.code == 1
    assert "ATLAS_CLIENT_TRANSPORT request_id=" + "c" * 32 in capsys.readouterr().out


def test_direct_invalid_option_is_not_leaked_through_argparse(monkeypatch, capsys):
    from livemorebio import cli, sdk
    monkeypatch.setattr(sdk, "Platform", lambda **kw: RecordingPlatform())
    monkeypatch.setattr(sys, "argv", ["livemore", "atlas", "--PRIVATE"])
    with pytest.raises(SystemExit) as caught:
        cli.main()
    captured = capsys.readouterr()
    assert caught.value.code == 1 and "PRIVATE" not in captured.out + captured.err


def test_cli_help_is_useful_and_does_not_construct_a_platform(monkeypatch, capsys):
    from livemorebio import cli, sdk
    monkeypatch.setattr(sdk, "Platform", lambda **kw: pytest.fail("help constructed platform"))
    monkeypatch.setattr(sys, "argv", ["livemore", "atlas", "--help"])
    with pytest.raises(SystemExit) as caught:
        cli.main()
    assert caught.value.code == 0
    shown = capsys.readouterr().out
    assert "status" in shown and SOURCE in shown and "reference" in shown


def test_interactive_error_keeps_shell_usable(monkeypatch, capsys):
    from livemorebio import shell
    from livemorebio.atlas_client import AtlasClientError
    platform = RecordingPlatform()
    platform.state = lambda: {"profile": "technical fixture"}
    def fail():
        raise AtlasClientError("ATLAS_CLIENT_RESPONSE")
    platform.atlas_reference_status = fail
    monkeypatch.setattr(shell, "Platform", lambda **kw: platform)
    lines = iter(["atlas status", "quit"])
    monkeypatch.setattr("builtins.input", lambda *a: next(lines))
    shell.run_shell(mode="attach")
    shown = capsys.readouterr().out
    assert "ATLAS_CLIENT_RESPONSE" in shown and "bye" in shown


def test_cli_pipeline_error_returns_nonzero_without_traceback(monkeypatch, capsys, tmp_path):
    from livemorebio import cli, shell
    from livemorebio.atlas_client import AtlasClientError
    platform = RecordingPlatform()
    def fail():
        raise AtlasClientError("ATLAS_CLIENT_TRANSPORT")
    platform.atlas_reference_status = fail
    monkeypatch.setattr(shell, "Platform", lambda **kw: platform)
    path = tmp_path / "technical.lmr"
    path.write_text("atlas status\n", encoding="utf-8")
    monkeypatch.setattr(sys, "argv", ["livemore", "run", str(path), "--attach"])
    with pytest.raises(SystemExit) as caught:
        cli.main()
    assert caught.value.code == 1
    assert "ATLAS_CLIENT_TRANSPORT" in capsys.readouterr().out


def test_output_failure_does_not_imply_installation_failed():
    from livemorebio.atlas_client import AtlasClientError
    from livemorebio.atlas_commands import run_atlas_command
    platform = RecordingPlatform()
    def failed(text):
        raise OSError("PRIVATE broken pipe")
    with pytest.raises(AtlasClientError) as caught:
        run_atlas_command(platform, ["atlas", "install", SOURCE], out=failed)
    assert caught.value.code == "ATLAS_CLIENT_OUTPUT" and "confirmed" in str(caught.value)
    assert "PRIVATE" not in str(caught.value) and len(platform.calls) == 1
