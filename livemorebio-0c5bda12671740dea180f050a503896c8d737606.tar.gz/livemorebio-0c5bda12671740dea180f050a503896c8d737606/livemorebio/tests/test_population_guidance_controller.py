"""Execute the real controller in a bounded technical DOM/event fixture.

This is not rendered-browser acceptance and admits no real-human record. Native
browser source guidance, responsive layout and focus still require the harness.
"""
from pathlib import Path
import json
import subprocess

import pytest
from ._node import run_node as _run_node

LIB = Path(__file__).parents[1] / "aegle/console/lib"


def run_case(view: str, scenario: str) -> None:
    script = r"""
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {populationChoices,cohortIndication,populationGuidance} from GUIDANCE_URL;
import {mountSelectionReconciliation,selectionRequest} from SELECTION_URL;
const view=VIEW_VALUE,scenario=SCENARIO_VALUE;
const production=fs.readFileSync(SOURCE_PATH,'utf8').replace(/^import .*;\n/gm,'');
const elements=new Map();
function get(selector){
 if(!elements.has(selector))elements.set(selector,{
  value:'',textContent:'',hidden:false,disabled:false,dataset:{},listeners:{},
  classList:{toggle(){}},setAttribute(){},querySelectorAll(){return[]},
  addEventListener(event,fn){(this.listeners[event]??=[]).push(fn)},
  removeEventListener(event,fn){this.listeners[event]=(this.listeners[event]||[]).filter(x=>x!==fn)},
  dispatchEvent(event){for(const fn of this.listeners[event.type]||[])fn(event)}
 });
 return elements.get(selector);
}
const sourceId=view==='twins'?'#twin-source':'#cohort-source';
get(sourceId).value='REFERENCE_GROUNDED_SYNTHETIC';
get('#cohort-size').value='24';get('#cohort-seed').value='17';
const submit=get('.governed-form .primary-action');
const document={body:{dataset:{subjectView:view},setAttribute(){}},querySelector:get,
 querySelectorAll:selector=>selector==='#record-list button, form button, #refresh-records, .records-pager button'?[submit]:[]};
const response=(payload,status=200)=>({status,ok:status===200,json:async()=>payload});
const capabilities={schema:'livemore.population-capabilities.v1',templates:[],
 reference_source:{source_id:'TECHNICAL-CONTROLLER-FIXTURE',role:'population_reference'},
 reference_strata:[{id:'technical',label:'Technical context',indication:'technical-context',available:true}],
 healthy_reference_cohort:{available:false,reason:'Healthy population generator is not configured'}};
let resolveNext;let requestCount=0;
const context={document,escapeHTML:String,populationChoices,cohortIndication,populationGuidance,mountSelectionReconciliation,
 selectionRequest:(path,options)=>selectionRequest(path,{...options,fetcher:context.fetch}),AbortController,window:{addEventListener(){}},
 initReferenceCohorts(){},referenceCohortCard(){},URLSearchParams,
 Event:class{constructor(type){this.type=type}},setTimeout(){},
 fetch:(path,options={})=>{
  assert(!options.method||options.method==='GET','no registry/service mutation permitted by this fixture');
  if(path.startsWith('/api/population-capabilities')){requestCount++;return new Promise(resolve=>{resolveNext=resolve})}
  const payload={twins:[],cohorts:[],selection_status:'UNCONFIRMED',active:null,pagination:{has_more:false}};
  return Promise.resolve(path.startsWith('/api/twins')?new Response(JSON.stringify(payload)):response(payload));
 }};
vm.createContext(context);vm.runInContext(production,context);
const flush=async()=>{for(let i=0;i<8;i++)await Promise.resolve()};
const select=value=>{get(sourceId).value=value;get(sourceId).dispatchEvent(new context.Event('change'))};
const label=get('#cohort-indication');
assert.equal(submit.disabled,true);
if(scenario.startsWith('operation_overlap')){
 assert.equal(view,'twins');
 const discoveryFailed=scenario==='operation_overlap_failure';
 let finish;const operation=context.withOperationLock(()=>new Promise(resolve=>{finish=resolve}));
 resolveNext(discoveryFailed?response({error:'TECHNICAL operation-overlap failure'},503):response(capabilities));await flush();
 assert.match(get('#population-capabilities-status').textContent,discoveryFailed?/discovery failed/:/Supported reference templates/);
 assert.equal(submit.disabled,true,'an unfinished operation still owns the controls');
 finish();await operation;
 assert.equal(submit.disabled,discoveryFailed,'post-operation creation follows current discovery status, not stale busyWasDisabled');
 assert.equal(get('#population-capabilities-retry').hidden,!discoveryFailed);
}else{
 select('REAL_HUMAN');label.value='TECHNICAL typed indication';
 select('REAL_HUMAN');if(view==='cohorts')assert.equal(label.value,'TECHNICAL typed indication');
 assert.match(get('#population-capabilities-status').textContent,/Checking available population contexts/);
 assert.match(get(view==='twins'?'#source-help':'#cohort-source-help').textContent,/consent/);
 if(scenario==='failure'){
  resolveNext(response({error:'TECHNICAL induced discovery failure'},503));await flush();
  assert.equal(submit.disabled,true);assert.match(get('#population-capabilities-status').textContent,/discovery failed/);
  select('REAL_HUMAN');if(view==='cohorts')assert.equal(label.value,'TECHNICAL typed indication');
  context.loadPopulationCapabilities();assert.equal(submit.disabled,true);
 }else{
  select('REFERENCE_GROUNDED_SYNTHETIC');select('REAL_HUMAN');
  if(view==='cohorts')assert.equal(label.value,'');
  label.value='TECHNICAL typed indication';
 }
 resolveNext(response(capabilities));await flush();
 assert.equal(submit.disabled,false);
 assert.match(get('#population-capabilities-status').textContent,/model-specific/);
 assert.doesNotMatch(get('#population-capabilities-status').textContent,/Healthy population generator/);
 if(view==='cohorts')assert.equal(label.value,'TECHNICAL typed indication');
 context.loadPopulationCapabilities();select('REAL_HUMAN');
 resolveNext(response(capabilities));await flush();
 if(view==='cohorts')assert.equal(label.value,'TECHNICAL typed indication');
 assert.equal(submit.disabled,false);
}
assert(requestCount>=1);
if(view==='twins')vm.runInContext('selectionRecovery.dispose()',context);
"""
    script = (script.replace("GUIDANCE_URL", json.dumps((LIB / "population_forms.js").as_uri()))
              .replace("SELECTION_URL", json.dumps((LIB / "selection_reconciliation.js").as_uri()))
              .replace("SOURCE_PATH", json.dumps(str(LIB / "subjects.js")))
              .replace("VIEW_VALUE", json.dumps(view)).replace("SCENARIO_VALUE", json.dumps(scenario)))
    result = _run_node(["node", "--input-type=module", "-e", script], capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr


@pytest.mark.parametrize("view", ["twins", "cohorts"])
@pytest.mark.parametrize("scenario", ["success", "failure"])
def test_source_selection_during_discovery_preserves_user_input(view, scenario):
    run_case(view, scenario)


def test_discovery_completed_during_record_operation_restores_ready_submit():
    run_case("twins", "operation_overlap")


def test_discovery_failed_during_record_operation_keeps_submit_disabled():
    run_case("twins", "operation_overlap_failure")
