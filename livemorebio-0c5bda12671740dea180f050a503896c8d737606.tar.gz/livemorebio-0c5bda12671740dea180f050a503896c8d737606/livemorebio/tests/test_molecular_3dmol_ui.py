"""Exact public coordinate parser and owned adapter tests; not WebGL evidence."""
import json
from pathlib import Path
import subprocess

import pytest
from .test_biology_context_reconciliation_ui import run_controller
from .test_molecular_inspector_ui import run_inspector
from ._node import run_node as _run_node

ROOT = Path(__file__).parents[2]
LIB = ROOT / 'livemorebio/aegle/console/lib'
DATA = ROOT / 'livemorebio/scientific_sources/data/molecular'


def run_node(body: str) -> None:
    script = r"""
const assert=require('node:assert/strict'),fs=require('node:fs');
const lib=LIB,data=DATA;
const url=text=>'data:text/javascript;base64,'+Buffer.from(text).toString('base64');
global.document={readyState:'loading',querySelectorAll:()=>[]};global.window={navigator:{userAgent:'Node technical parser test'}};
const vendor=url(fs.readFileSync(lib+'/vendor/3dmol-2.5.5/3Dmol.es6-min.js','utf8'));
const source=fs.readFileSync(lib+'/molecular_3dmol_frame.js','utf8').replace("'./vendor/3dmol-2.5.5/3Dmol.es6-min.js'",JSON.stringify(vendor));
(async()=>{const mod=await import(url(source));
BODY
process.stdout.write('ok');})().catch(e=>{console.error(e.message);process.exitCode=1});
""".replace('LIB', json.dumps(str(LIB))).replace('DATA', json.dumps(str(DATA))).replace('BODY', body)
    result = _run_node(['node', '--eval', script], capture_output=True, text=True, timeout=20, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    assert result.stdout == 'ok'


def test_real_pinned_parser_preserves_all_seven_original_atom_counts() -> None:
    run_node(r"""
const catalog=JSON.parse(fs.readFileSync(data+'/catalog.json','utf8'));
assert.equal(Object.keys(catalog.structures).length,7);
for(const [pdb,reference] of Object.entries(catalog.structures)){
 const atoms=mod.parseReference(fs.readFileSync(data+'/'+pdb+'.cif','utf8'),reference);
 assert.equal(atoms.length,reference.atom_site_rows,pdb);
 assert(atoms.every(a=>[a.x,a.y,a.z].every(Number.isFinite)),pdb);
 if(pdb==='5VA2'){assert.equal(atoms.length,4394);assert.deepEqual([...new Set(atoms.map(a=>a.chain))],['A']);
   assert.deepEqual([atoms[0].x,atoms[0].y,atoms[0].z],[95.653,56.037,57.622]);
   assert.deepEqual([atoms[1].x,atoms[1].y,atoms[1].z],[96.714,57.046,57.303]);}
}
""")


@pytest.mark.parametrize('fault', ["source_model_numbers:[1,2]", "selected_model_number:2", "selected_model_index:1", "atom_site_rows:1"])
def test_parser_refuses_unsupported_model_or_dropped_atoms(fault: str) -> None:
    run_node(r"""
const reference=JSON.parse(fs.readFileSync(data+'/catalog.json','utf8')).structures['5VA2'];
assert.throws(()=>mod.parseReference(fs.readFileSync(data+'/5VA2.cif','utf8'),{...reference,FAULT}),/MOLECULAR_INVALID_REFERENCE/);
""".replace('FAULT', fault))


def test_distance_uses_source_angstroms_not_display_scale() -> None:
    run_node("assert.equal(mod.atomDistance({x:0,y:0,z:0},{x:3,y:4,z:0}),5);assert.throws(()=>mod.atomDistance({x:NaN,y:0,z:0},{x:3,y:4,z:0}));")


def test_fixed_frame_has_no_metadata_interpolation_or_remote_delivery() -> None:
    source = (LIB / 'molecular_3dmol.js').read_text(encoding="utf-8")
    assert 'srcdoc' in source and '/lib/molecular_3dmol_frame.js' in source
    assert 'source.text' not in source.split('srcdoc =', 1)[1].split(';', 1)[0]
    assert 'postMessage' not in source and 'https://' not in source
    assert 'signal.addEventListener' in source and 'signal.removeEventListener' in source
    assert 'frame.remove()' in source


def test_ordinary_biology_uses_local_inspector_not_remote_viewer() -> None:
    source = (LIB.parent / 'biology.html').read_text(encoding="utf-8")
    assert "import {mountMolecularInspector} from '/lib/molecular_inspector.js'" in source
    assert 'cdn.jsdelivr.net/npm/molstar' not in source
    assert 'loadPdb' not in source


def test_ordinary_target_binds_context_and_rejects_detached_old_buttons() -> None:
    run_controller(r"""
const events=[];context.window.testMountMolecularInspector=(host,options)=>{
 events.push(['mount',options.context.key]);return {open(...args){events.push(['open',...args]);},close(){events.push(['close']);},setContext(next){events.push(['context',next?.key,context.window.testScope.state()?.context_id]);},dispose(){}};};
await mount();a.equal(events.length,0);context.window._sel('heart');
const button={isConnected:true};el('panel').contains=node=>node===button;
const generation=()=>Number(el('panel').innerHTML.match(/_mol\('KCNH2','[a-f0-9]+',(\d+)/)[1]);
const first=generation();await context.window._mol('KCNH2','a'.repeat(64),first,'heart',button);
a.deepEqual(events,[['mount','a'.repeat(64)],['open','KCNH2']],'ordinary target must not pass an object as frozen PDB');
await refresh();a.equal(events.length,2,'same-key refresh closed reference');
await context.window._mol('KCNH2','a'.repeat(64),first,'heart',button);a.equal(events.length,2,'stale rendered handler reopened');
payload=state('b'.repeat(64));await refresh();a.deepEqual(events[2],['context','b'.repeat(64),'a'.repeat(64)],'context invalidation must precede STATE publication');
button.isConnected=false;await context.window._mol('KCNH2','b'.repeat(64),generation(),'heart',button);a.equal(events.length,3);
context.window._over();a.equal(events[3][0],'close');
""")


def test_shared_inspector_waits_for_local_frame_and_retires_before_reopen() -> None:
    run_inspector(r"""
adapter.createReferenceViewer=(container,input)=>{assert.equal(input.text,new TextDecoder().decode(raw));
 assert.equal(input.reference.coordinate_sha256,sha);counts.construct++;return {ready:held.promise,dispose(){counts.dispose++;}};};
const inspector=create();const opening=inspector.open('KRAS');await tick();await tick();
assert.equal(host.dataset.molecularState,'LOADING');held.resolve();await opening;
assert.equal(host.dataset.molecularState,'READY');await inspector.close();assert.equal(counts.dispose,1);
await inspector.open('KRAS');await inspector.dispose();assert.equal(counts.dispose,2);
""")


def test_local_frame_abort_settles_and_cleanup_removes_exact_document() -> None:
    run_node(r"""
const adapter=await import(url(fs.readFileSync(lib+'/molecular_3dmol.js','utf8')));
let removes=0,cleanups=0,appends=0;
const frame={style:{},setAttribute(){},remove(){removes++;},contentWindow:{renderMolecularReference(text,ref){assert.equal(text,'verified source');return {dispose(){cleanups++;}};}},contentDocument:{addEventListener(){}}};
const container={ownerDocument:{createElement:()=>frame},append(){appends++;}};
const controller=new AbortController();const view=adapter.createReferenceViewer(container,{text:'verified source',reference:{},signal:controller.signal,onEscape(){}});
assert.equal(appends,1);frame.onload();await view.ready;controller.abort();assert.equal(cleanups,0,'ready frame teardown belongs to owner');view.dispose();view.dispose();assert.equal(cleanups,1);assert.equal(removes,1);
const cancel=new AbortController();const pending=adapter.createReferenceViewer(container,{text:'verified source',reference:{},signal:cancel.signal});cancel.abort();await assert.rejects(pending.ready);assert.equal(removes,2);
""")


def test_renderer_uses_real_atom_model_and_wires_style_distance_fit_and_disposal() -> None:
    run_node(r"""
const upstream=await import(vendor),events=[],handlers={},nodes={};let pick,model,lost=0;
for(const id of ['coordinates','selection','representation','fit','clear-selection'])nodes[id]={value:'cartoon',addEventListener(k,fn){handlers[id+':'+k]=fn;},querySelectorAll(){return [{getContext:()=>({getExtension:()=>({loseContext(){lost++;}})})}];}};
document.getElementById=id=>nodes[id];window.addEventListener=()=>{};
const viewer={addModel(){return model=new upstream.GLModel(0);},setStyle(sel,style){events.push(['style',style]);},render(){},zoomTo(){events.push(['fit']);},resize(){},setClickable(sel,enabled,fn){pick=fn;},addLabel(text){events.push(['label',text]);},addLine(line){events.push(['line',line]);},removeAllLabels(){},removeAllShapes(){},clear(){events.push(['clear']);}};
const ref=JSON.parse(fs.readFileSync(data+'/catalog.json','utf8')).structures['5VA2'];
const resource=mod.renderReference(fs.readFileSync(data+'/5VA2.cif','utf8'),ref,{createViewer:()=>viewer});
assert.equal(model.selectedAtoms({}).length,4394);const atoms=model.selectedAtoms({});pick(atoms[0]);pick(atoms[1]);
assert(nodes.selection.textContent.includes(mod.atomDistance(atoms[0],atoms[1]).toFixed(2)+' Å'));
assert(events.some(e=>e[0]==='line'));nodes.representation.value='stick';handlers['representation:change']();
assert(events.some(e=>e[1]?.stick));handlers['fit:click']();assert.equal(events.filter(e=>e[0]==='fit').length,2);
handlers['clear-selection:click']();assert(nodes.selection.textContent.includes('Select two atoms'));resource.dispose();resource.dispose();assert.equal(lost,1);assert.equal(events.filter(e=>e[0]==='clear').length,1);
""")


def test_ordinary_failed_refresh_blocks_new_open_without_erasing_inspector_status() -> None:
    run_controller(r"""
let opens=0,closes=0;context.window.testMountMolecularInspector=host=>({open(){opens++;host.dataset.molecularState='FAILED';},close(){closes++;},setContext(){},dispose(){}});
await mount();context.window._sel('heart');const button={isConnected:true};el('panel').contains=()=>true;
const generation=Number(el('panel').innerHTML.match(/_mol\('KCNH2','[a-f0-9]+',(\d+)/)[1]);
await context.window._mol('KCNH2','a'.repeat(64),generation,'heart',button);a.equal(opens,1);
httpOk=false;await refresh();await context.window._mol('KCNH2','a'.repeat(64),generation,'heart',button);
a.equal(opens,1);a.equal(closes,0);a.equal(el('molecular-reference').dataset.molecularState,'FAILED','resolved failure was erased');
""")


def test_shared_frame_keyboard_can_enter_controls_and_return_to_close() -> None:
    run_inspector(r"""
let callbacks;adapter.createReferenceViewer=(container,input)=>{callbacks=input;const frame=document.createElement('iframe');frame.setAttribute('tabindex','0');container.append(frame);return {ready:Promise.resolve(),dispose(){}};};
const inspector=create();await inspector.open('KRAS');const dialog=host.querySelector('[data-molecular-dialog]');
const closeButton=host.querySelector('[data-molecular-close]');closeButton.focus();let prevented=false;
dialog.dispatch('keydown',{key:'Tab',preventDefault(){prevented=true;}});assert.equal(prevented,false,'close trapped focus outside frame controls');
callbacks.onFocusBoundary();assert.equal(document.activeElement,closeButton);callbacks.onEscape();await tick();assert.equal(host.dataset.molecularState,'CLOSED');
""")
