"""Distribution behavior uses technical fixtures, never copied botanical data."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from livemorebio.discovery import substrate


@pytest.fixture
def technical_reference(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> tuple[Path, Path]:
    from livemorebio.tests import private_reference_helpers as helper
    monkeypatch.setattr(helper, "REPOSITORY_ROOT", tmp_path)
    reference_dir = tmp_path / "livemorebio/discovery/data"
    reference_dir.mkdir(parents=True)
    profiles = reference_dir / "technical-profiles.json"
    safety = reference_dir / "technical-safety.csv"
    profiles.write_text(json.dumps({
        "title": "Technical reference fixture; not physical observations",
        "record_count": 1,
        "evidence_scale": {"E0": "Technical fixture"},
        "profiles": [{"record_id": "TECH-001", "entry_name": "Technical fixture"}],
    }), encoding="utf-8")
    safety.write_text("record_id,severity\nTECH-001,technical-fixture\n", encoding="utf-8")
    monkeypatch.setattr(substrate, "PROFILES_PATH", profiles)
    monkeypatch.setattr(substrate, "SAFETY_PATH", safety)
    monkeypatch.setattr(substrate, "__file__", str(reference_dir.parent / "substrate.py"))
    return profiles, safety


@pytest.mark.parametrize("missing", [(0,), (1,), (0, 1)])
@pytest.mark.parametrize("public", [False, True])
def test_missing_reference_refuses_with_fixed_reason(technical_reference, missing, public):
    if public:
        root = technical_reference[0].parents[3]
        (root / ".livemore-distribution.json").write_text(json.dumps({
            "schema": "livemore.distribution.v1", "audience": "public"}), encoding="utf-8")
    for index in missing:
        technical_reference[index].unlink()

    with pytest.raises(substrate.ReferenceDataNotDistributed) as failure:
        substrate.load_substrate()

    assert failure.value.code == "REFERENCE_DATA_NOT_DISTRIBUTED"
    assert str(failure.value) == (
        "The plant reference profiles and safety register are not distributed "
        "with the public archive. A complete, lawfully acquired reference "
        "dataset is required to load this substrate."
        if public else
        "A required plant reference file is missing. A complete, lawfully "
        "acquired profiles dataset and safety register are required to load this substrate."
    )
    assert str(technical_reference[0].parent) not in str(failure.value)


def test_explicit_missing_profile_path_refuses(technical_reference):
    with pytest.raises(substrate.ReferenceDataNotDistributed):
        substrate.load_substrate(technical_reference[0].parent / "unavailable.json")


def test_complete_technical_reference_preserves_profiles_and_safety(technical_reference):
    result = substrate.load_substrate()
    assert len(result) == 1
    assert result.profile("TECH-001")["entry_name"] == "Technical fixture"
    assert result.safety_for("TECH-001") == [
        {"record_id": "TECH-001", "severity": "technical-fixture"}
    ]


def test_malformed_present_reference_is_not_reported_as_undistributed(technical_reference):
    technical_reference[0].write_text("not json", encoding="utf-8")
    with pytest.raises(json.JSONDecodeError):
        substrate.load_substrate()


def test_unreadable_present_reference_is_not_reported_as_undistributed(
    technical_reference, monkeypatch,
):
    def denied(*args, **kwargs):
        raise PermissionError("technical fixture denial")

    monkeypatch.setattr(Path, "read_text", denied)
    with pytest.raises(PermissionError, match="technical fixture denial"):
        substrate.load_substrate()


def test_private_reference_helper_skips_explicitly_for_missing_file(technical_reference):
    from livemorebio.tests.private_reference_helpers import require_private_reference_data

    technical_reference[1].unlink()
    root = technical_reference[0].parents[3]
    (root / ".livemore-distribution.json").write_text(json.dumps({"schema": "livemore.distribution.v1", "audience": "public"}), encoding="utf-8")
    with pytest.raises(pytest.skip.Exception, match="REFERENCE_DATA_NOT_DISTRIBUTED"):
        require_private_reference_data(*technical_reference)


def test_private_reference_helper_continues_for_present_files(technical_reference):
    from livemorebio.tests.private_reference_helpers import require_private_reference_data

    require_private_reference_data(*technical_reference)


def test_private_reference_helper_does_not_skip_corrupt_present_data(technical_reference):
    from livemorebio.tests.private_reference_helpers import require_private_reference_data

    technical_reference[0].write_text("not json", encoding="utf-8")
    require_private_reference_data(*technical_reference)
    with pytest.raises(json.JSONDecodeError):
        substrate.load_substrate()
