"""Offline metadata ACK barriers, not browser or asset-transfer observations."""
from __future__ import annotations

import json

import pytest

from livemorebio.tests.test_atlas_skin_terminal_diagnostic import RUNNER, node as run_node


def node(code: str) -> None:
    """A pending Promise alone must not let a Node assertion probe exit green."""
    completion = "})().catch(e=>{console.error(e);process.exitCode=1});"
    prefix = "let probeComplete=false;process.on('beforeExit',()=>a.equal(probeComplete,true,'Probe assertions did not finish'));\n"
    if completion in code:
        assert code.count(completion) == 1
        code = code.replace(completion, "})().then(()=>{probeComplete=true}).catch(e=>{console.error(e);process.exitCode=1});")
    else:
        code += "\nprobeComplete=true;"
    run_node(prefix + code)


def test_delivery_requires_seal_and_every_ack_even_when_final_ack_arrives_first():
    node(r"""
(async()=>{
const acks=[];let result='PENDING';
const delivery=h.createSkinMetadataDelivery(value=>new Promise(resolve=>acks.push({value,resolve})));
delivery.settled.then(value=>result=value);
delivery.send(1);acks[0].resolve();await Promise.resolve();await Promise.resolve();a.equal(result,'PENDING');
delivery.send(2);delivery.send(3);delivery.seal();
acks[2].resolve();await Promise.resolve();await Promise.resolve();a.equal(result,'PENDING');
acks[1].resolve();a.equal(await delivery.settled,true);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


@pytest.mark.parametrize("kind", ["throw", "reject", "overflow"])
def test_delivery_failure_is_sticky_bounded_and_never_unhandled(kind):
    node("const kind=" + json.dumps(kind) + r""";
(async()=>{
let sends=0,unhandled=0;process.on('unhandledRejection',()=>unhandled++);
const owner=h.createSkinMetadataDelivery(()=>{sends++;if(sends===1&&kind==='throw')throw Error('PRIVATE');
 if(sends===1&&kind==='reject')return Promise.reject(Error('PRIVATE'));return Promise.resolve();});
if(kind==='overflow'){for(let i=0;i<8;i++)owner.send(i);a.throws(()=>owner.send(9),{message:'DIAGNOSTIC_OBSERVER_FAILED'});}
else{owner.send(1);owner.send(2);}
owner.seal();a.equal(await owner.settled,false);await new Promise(setImmediate);a.equal(unhandled,0);
a.equal(sends,kind==='overflow'?8:2);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_post_seal_emit_throws_without_pretending_settled_success_can_change():
    node(r"""
(async()=>{
let sends=0;const owner=h.createSkinMetadataDelivery(()=>sends++);owner.send({});owner.seal();
a.equal(await owner.settled,true);
a.throws(()=>owner.send({}),{message:'DIAGNOSTIC_OBSERVER_FAILED'});a.equal(sends,1);
a.equal(await owner.settled,true,'Already resolved Promise is immutable; the attempted emission must throw visibly.');
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_final_emit_disposes_signal_before_seal_and_retains_original_task_identity():
    node(r"""
(async()=>{
const asset={asset_key:'skin',bytes:4901056,sha256:'e8a0c3f0897783fdb2c9bad9fe020c287ae8913a45f88bd7cd4ae47e8b628f0a'};
const controller=new AbortController(),events=[];const native=Promise.resolve(new ArrayBuffer(asset.bytes));
const factory=({fetchImpl})=>({load:()=>fetchImpl('/skin',{method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',signal:controller.signal}),dispose:()=>{throw Error('NO_DISPOSE')}});
const delivery=h.createSkinMetadataDelivery(value=>events.push(value));const originalSeal=delivery.seal;
delivery.seal=()=>{const before=events.length;controller.abort();a.equal(events.length,before,'signal listener must already be removed');originalSeal();};
const task=h.startSkinBrowser(factory,h.wrapRequestFactory,h.observeSkinFetch,asset,'/skin','a'.repeat(64),delivery,()=>native);
a.equal(task,native);await task;a.equal(await delivery.settled,true);
a.equal(events.at(-1).application.loads[0].outcome,'RESOLVED');a.equal(events.length,3);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


@pytest.mark.parametrize("damage", ["emit", "snapshot", "disposal"])
def test_terminal_observer_failure_always_seals_without_replacing_task(damage):
    node("const damage=" + json.dumps(damage) + r""";
(async()=>{
const asset={asset_key:'skin',bytes:4901056,sha256:'e8a0c3f0897783fdb2c9bad9fe020c287ae8913a45f88bd7cd4ae47e8b628f0a'};
const native=Promise.resolve(new ArrayBuffer(asset.bytes));let sealed=0;
const factory=()=>({load:()=>native});
const wrap=(...args)=>{const tracker=h.wrapRequestFactory(...args),snapshot=tracker.snapshot;
 if(damage==='snapshot')tracker.snapshot=()=>{throw Error('PRIVATE')};return tracker;};
const observe=(...args)=>{const value=h.observeSkinFetch(...args);if(damage==='disposal')value.dispose=()=>{throw Error('PRIVATE')};return value;};
const owner=h.createSkinMetadataDelivery(()=>{if(damage==='emit')throw Error('PRIVATE')});
const seal=owner.seal;owner.seal=()=>{sealed++;seal()};
const task=h.startSkinBrowser(factory,wrap,observe,asset,'/skin','a'.repeat(64),owner,()=>native);
a.equal(task,native);await task;a.equal(await owner.settled,false);a.equal(sealed,1);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


@pytest.mark.parametrize("value", [None, [], {}, True, {"load_succeeded": 1, "metadata_delivered": True},
                                  {"load_succeeded": True, "metadata_delivered": "true"},
                                  {"load_succeeded": True, "metadata_delivered": True, "extra": False}])
def test_evaluation_closed_result_rejects_malformed_or_truthy_shapes(value):
    node("const bad=" + json.dumps(value) + r""";
a.deepEqual(h.requireSkinEvaluationResult({load_succeeded:true,metadata_delivered:true}),{load_succeeded:true,metadata_delivered:true});
a.throws(()=>h.requireSkinEvaluationResult(bad),{code:'DIAGNOSTIC_OBSERVER_FAILED'});
a.throws(()=>h.requireSkinEvaluationResult({load_succeeded:true,metadata_delivered:false}),{code:'DIAGNOSTIC_OBSERVER_FAILED'});
""")


@pytest.mark.parametrize("rejected", [False, True])
def test_serialized_program_uses_same_orchestration_and_waits_for_final_ack(rejected):
    node("const rejected=" + json.dumps(rejected) + r""";
(async()=>{
const asset={asset_key:'skin',bytes:4901056,sha256:'e8a0c3f0897783fdb2c9bad9fe020c287ae8913a45f88bd7cd4ae47e8b628f0a'};
const url=new URL(h.PIN.base+'/assets/anatomy/atlas/'+h.PIN.manifest+'/skin.glb').pathname;
const native=Promise.resolve(new ArrayBuffer(asset.bytes));let fetches=0,loads=0,finished=false;
const factory=({fetchImpl})=>({load:()=>{loads++;return fetchImpl(url,{method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',signal:new AbortController().signal})}});
const acks=[];globalThis.__atlasSkinMetadata=value=>new Promise((resolve,reject)=>acks.push({value,resolve,reject}));
globalThis.fetch=()=>{fetches++;return native};
const program=h.skinBrowserProgram(h.PIN);
a.ok(program.includes(h.orchestrateSkinBrowser.toString()));
const task=eval(program.replace("import('/lib/atlas_reference_requests.js')","Promise.resolve({createAtlasAssetRequests:factory})"));
task.then(()=>finished=true);
for(let i=0;acks.length<3&&i<100;i++)await new Promise(setImmediate);
a.equal(acks.length,3);a.equal(finished,false);acks[0].resolve();acks[1].resolve();
await new Promise(setImmediate);a.equal(finished,false);
if(rejected)acks[2].reject(Error('PRIVATE'));else acks[2].resolve();
a.deepEqual(await task,{load_succeeded:true,metadata_delivered:!rejected});a.equal(fetches,1);a.equal(loads,1);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_serialized_initial_delivery_rejection_does_not_wait_for_pending_original_load():
    node(r"""
(async()=>{
const native=new Promise(()=>{});let fetches=0,loads=0,complete=false,result;
const url=new URL(h.PIN.base+'/assets/anatomy/atlas/'+h.PIN.manifest+'/skin.glb').pathname;
const factory=({fetchImpl})=>({load:()=>{loads++;return fetchImpl(url,{method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error',signal:new AbortController().signal})}});
globalThis.fetch=()=>{fetches++;return native};
globalThis.__atlasSkinMetadata=()=>Promise.reject(Error('PRIVATE_ACK'));
const program=h.skinBrowserProgram(h.PIN);a.ok(program.includes(h.orchestrateSkinBrowser.toString()));
const task=eval(program.replace("import('/lib/atlas_reference_requests.js')","Promise.resolve({createAtlasAssetRequests:factory})"));
task.then(value=>{result=value;complete=true});
for(let i=0;!complete&&i<100;i++)await new Promise(setImmediate);
a.equal(complete,true,'Known observer failure must not wait on a still-pending original load.');
a.deepEqual(result,{load_succeeded:false,metadata_delivered:false});a.equal(fetches,1);a.equal(loads,1);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


EMIT = r"""value=>{
 if(mode==='reject-initial-pending')return Promise.reject(Error('PRIVATE_INITIAL_ACK'));
 if(mode==='sync-throw')throw Error('PRIVATE_DELIVERY');
 if(mode==='reject-all'||(mode==='reject-terminal'&&value.application.loads[0].outcome!=='PENDING')||
   (['reject-final','reject-final-held'].includes(mode)&&value.sequence===3))return Promise.reject(Error('PRIVATE_DELIVERY'));
 if(['delayed-all','never-delivery'].includes(mode)||(mode==='delayed-terminal'&&value.application.loads[0].outcome!=='PENDING'))
   return new Promise(resolve=>queued.push({sequence:value.sequence,deliver:()=>{binding({page,frame:page},value);resolve()}}));
 binding({page,frame:page},value);
 if(['never-ack','last-ack-first'].includes(mode))return new Promise(resolve=>queued.push({sequence:value.sequence,deliver:resolve}));
 return undefined;
}"""


@pytest.mark.parametrize("mode", ["delayed-all", "delayed-terminal", "reject-all", "reject-terminal", "reject-final",
                                  "reject-final-held", "reject-initial-pending", "never-ack", "never-delivery", "last-ack-first", "sync-throw", "load-rejected", "malformed-held"])
def test_mounted_shared_orchestration_joins_delivery_or_rejects_before_other_terminals(mode):
    needle = "value=>binding({page,frame:page},value),()=>native)"
    assert RUNNER.count(needle) == 1
    runner = RUNNER.replace(needle, EMIT + ",()=>native)")
    # Page closure rejects the evaluation caller, not the original in-page load
    # or its pending ACK. The authored stand-in must model that boundary too.
    runner = runner.replace("return h.orchestrateSkinBrowser(", "const evaluation=h.orchestrateSkinBrowser(")
    runner = runner.replace(EMIT + ",()=>native);", EMIT + ",()=>native);\n return ['never-ack','never-delivery','reject-initial-pending'].includes(mode)?Promise.race([evaluation,stall('ack-evaluation')]):evaluation;")
    runner = runner.replace("page.emit(failed?'requestfailed':'requestfinished',request);", "if(!mode.endsWith('-held'))page.emit(failed?'requestfailed':'requestfinished',request);")
    runner = runner.replace("cdp.emit(failed?'Network.loadingFailed':'Network.loadingFinished',", "if(!mode.endsWith('-held'))cdp.emit(failed?'Network.loadingFailed':'Network.loadingFinished',")
    runner = runner.replace("const native=Promise.resolve(new ArrayBuffer(skin.bytes));", "if(mode==='malformed-held')return {load_succeeded:true,metadata_delivered:true,extra:false};\nconst native=mode==='reject-initial-pending'?new Promise(()=>{}):mode==='load-rejected'?Promise.reject(Error('PRIVATE_LOAD')):Promise.resolve(new ArrayBuffer(skin.bytes));")
    node("const variant='finished';const mode=" + json.dumps(mode) + ";const queued=[];\n" + runner + r"""
(async()=>{
let complete=false;const task=h.mainSkin(config.out+'/browser-config.json',{clock});task.then(()=>complete=true);
process.on('beforeExit',()=>a.equal(complete,true,'The mounted runner must reach its terminal assertions.'));
if(mode==='reject-initial-pending'){
 for(let i=0;!complete&&i<100;i++)await new Promise(setImmediate);
 if(!complete)fire(90000); // Retain the wrong outcome on RED, not a hung test.
}
if(['delayed-all','delayed-terminal','never-ack','never-delivery','last-ack-first'].includes(mode)){
 const expected=mode==='delayed-terminal'?2:3;
 for(let i=0;queued.length<expected&&i<100;i++)await new Promise(setImmediate);
 a.equal(queued.length,expected);a.equal(complete,false,'Do not classify load until its metadata owner completes.');
 if(['never-ack','never-delivery'].includes(mode))fire(90000);
 else if(mode==='last-ack-first'){
  queued[2].deliver();await new Promise(setImmediate);a.equal(complete,false);
  queued[1].deliver();await new Promise(setImmediate);a.equal(complete,false);queued[0].deliver();
 }else for(const entry of queued)entry.deliver();
}
const result=await task;a.equal(result.cleanup,'SETTLED');a.equal(result.acceptance_pass,false);
a.equal(calls.routes.filter(p=>p===url).length,1);a.equal(calls.body,0);a.equal(calls.finished,0);
if(['delayed-all','delayed-terminal','last-ack-first'].includes(mode)){
 a.equal(result.collection_pass,true);a.equal(result.primary_failure,null);a.equal(result.application.loads[0].outcome,'RESOLVED');
 a.deepEqual(result.stages.map(s=>s.state),['PASS','PASS','PASS']);
}else{
 a.equal(result.collection_pass,false);a.equal(result.stages.at(-1).state,'NOT_RUN');
 a.equal(result.primary_failure,['never-ack','never-delivery'].includes(mode)?'DIAGNOSTIC_DEADLINE':mode==='load-rejected'?'FUNCTIONAL_UNAVAILABLE':'DIAGNOSTIC_OBSERVER_FAILED');
 if(['never-ack','never-delivery'].includes(mode)){
  a.equal(result.application===null,mode==='never-delivery');
  const before=JSON.stringify(result);for(const entry of queued)entry.deliver();await new Promise(setImmediate);a.equal(JSON.stringify(result),before);
 }else a.equal(now,0,'A known metadata failure must not await the other terminal until the deadline.');
}
a.ok(calls.closed.includes('browser'));a.ok(!JSON.stringify(written).includes('PRIVATE'));
})().catch(e=>{console.error(e);process.exitCode=1});
""")
