"""Build identity must describe imported code, not whichever checkout was opened."""
from __future__ import annotations

import json
from pathlib import Path
import subprocess

import pytest

from ._node import require_node
from ._source_tree import source_tree_only


def test_l0_r19_package_and_build_identity_report_release_version():
    import tomllib
    from livemorebio import __version__
    from livemorebio.build_info import build_identity

    project = tomllib.loads((Path(__file__).parents[2] / "pyproject.toml").read_text(encoding="utf-8"))
    assert project["project"]["version"] == "0.1.0"
    assert __version__ == "0.1.0"
    assert build_identity()["package_version"] == "0.1.0"


@pytest.mark.parametrize("module", ["aegle.server", "life_system.service", "cendos.service"])
def test_l0_r19_service_openapi_and_health_report_release_version(module):
    from importlib import import_module
    from fastapi.testclient import TestClient

    app = import_module("livemorebio." + module).app
    assert app.version == "0.1.0"
    assert app.openapi()["info"]["version"] == "0.1.0"
    response = TestClient(app, base_url="http://127.0.0.1:24195").get("/health")
    assert response.status_code == 200
    assert response.json()["build"]["package_version"] == "0.1.0"


def test_l0_r19_version_command_needs_no_service_or_runtime_state(tmp_path):
    import os
    import sys

    data_dir = tmp_path / "unused-runtime-state"
    environment = {**os.environ, "LIVEMORE_DATA_DIR": str(data_dir)}
    result = subprocess.run([sys.executable, "-B", "-m", "livemorebio.cli", "--version"],
                            capture_output=True, text=True, encoding="utf-8", timeout=20,
                            env=environment)
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "LivemoreBio 0.1.0"
    assert not data_dir.exists()


@pytest.mark.parametrize("client", ["adapter", "genecards", "reference", "catalog"])
def test_l0_r19_client_user_agents_report_release_version(tmp_path, monkeypatch, client):
    from contextlib import contextmanager
    from types import SimpleNamespace
    from livemorebio import egress

    captured = []

    @contextmanager
    def technical_response(request, **_kwargs):
        captured.append(request.get_header("User-agent"))
        yield SimpleNamespace(status=200, read=lambda: b"{}")

    monkeypatch.setattr(egress, "urlopen", technical_response)
    monkeypatch.setattr(egress, "check_request", lambda *_args, **_kwargs: None)
    if client == "adapter":
        from livemorebio.adapters import _probe_url
        assert _probe_url("https://technical.example/status", 1) == "ready"
        expected = "LivemoreBio/0.1.0 research"
    elif client == "genecards":
        from livemorebio.life_system.reference.sources.genecards import GeneCards
        source = GeneCards(cache_dir=str(tmp_path / "cache"))
        monkeypatch.setattr(source, "_configuration", lambda: ("https://technical.example/", "technical-token"))
        assert source.gene("TP53") == {}
        expected = "LivemoreBio/0.1.0 licensed-connector"
    elif client == "reference":
        from livemorebio.life_system.reference.sources.base import Source
        source = Source(cache_dir=str(tmp_path / "cache"))
        source.rate = 0
        assert source.fetch("https://technical.example/reference") == {}
        expected = "Livemore-HHDT/0.1.0 (research)"
    else:
        from tools.refresh_scientific_source_catalog import _fetch
        assert _fetch("https://technical.example/catalog") == "{}"
        expected = "LivemoreBio governed source catalog/0.1.0"
    assert captured == [expected]


def _source(tmp_path: Path) -> Path:
    package = tmp_path / "livemorebio"
    package.mkdir()
    (package / "__init__.py").write_text('__version__ = "0.1.0"\n', encoding="utf-8")
    (package / "engine.py").write_text("VALUE = 1\n", encoding="utf-8")
    return package


def test_fingerprint_uses_runtime_allowlist_not_private_or_test_data(tmp_path):
    from livemorebio.build_info import source_fingerprint

    package = _source(tmp_path)
    first = source_fingerprint(package)
    for relative in ("secret.key", "observations.json", "cache/frame.json", "tests/test_x.py"):
        path = package / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("PRIVATE TEST DATA", encoding="utf-8")
    assert source_fingerprint(package) == first
    (package / "engine.py").write_text("VALUE = 2\n", encoding="utf-8")
    assert source_fingerprint(package) != first
    console = package / "aegle/console/lib"
    console.mkdir(parents=True)
    (console / "view.js").write_text("export const view = 1;", encoding="utf-8")
    assert source_fingerprint(package) != first


def test_source_fingerprint_rejects_symlinked_runtime_file(tmp_path):
    from livemorebio.build_info import source_fingerprint

    package = _source(tmp_path)
    (package / "engine.py").unlink()
    outside = tmp_path / "private.py"
    outside.write_text("PRIVATE TEST DATA", encoding="utf-8")
    (package / "engine.py").symlink_to(outside)
    assert source_fingerprint(package) is None


def test_atlas_declaration_is_runtime_identity_but_cached_geometry_is_not(tmp_path):
    from livemorebio.build_info import source_fingerprint

    package = _source(tmp_path)
    before = source_fingerprint(package)
    atlas = package / "anatomy" / "atlas"
    atlas.mkdir(parents=True)
    declaration = atlas / "source.json"
    declaration.write_text('{"source_id":"technical-declaration-v1"}', encoding="utf-8")
    admitted = source_fingerprint(package)
    assert admitted != before
    declaration.write_text('{"source_id":"technical-declaration-v2"}', encoding="utf-8")
    assert source_fingerprint(package) != admitted
    before_cache = source_fingerprint(package)
    (atlas / "unpackaged.glb").write_bytes(b"technical-geometry-not-packaged")
    assert source_fingerprint(package) == before_cache


def test_package_configuration_includes_atlas_declaration_only():
    import tomllib

    project = tomllib.loads((Path(__file__).parents[2] / "pyproject.toml").read_text(encoding="utf-8"))
    patterns = project["tool"]["setuptools"]["package-data"]["livemorebio.anatomy"]
    assert "atlas/*.json" in patterns
    assert not any("glb" in pattern or "zip" in pattern for pattern in patterns)


def test_source_fingerprint_rejects_runtime_directory_symlink(tmp_path):
    from livemorebio.build_info import source_fingerprint

    package = _source(tmp_path)
    outside = tmp_path / "external_engine"
    outside.mkdir()
    (outside / "__init__.py").write_text("VALUE = 1", encoding="utf-8")
    (package / "engine").symlink_to(outside, target_is_directory=True)
    assert source_fingerprint(package) is None


def test_non_repository_install_cannot_inherit_cwd_or_parent_commit(tmp_path, monkeypatch):
    from livemorebio import build_info

    package = _source(tmp_path)
    monkeypatch.chdir(Path(__file__).parents[2])
    monkeypatch.setattr(build_info.subprocess, "run", lambda *a, **k: pytest.fail("git must not run"))
    report = build_info.capture_build(package)
    assert report["commit"] is None
    assert report["source_kind"] == "installed_package"
    assert report["identity_scope"] == "startup_source"
    assert report["source_sha256"]
    assert str(tmp_path) not in json.dumps(report)


@pytest.mark.parametrize("failure", [FileNotFoundError("PRIVATE TEST DATA"),
                                     subprocess.TimeoutExpired("git", 2)])
def test_git_failure_is_sanitized_and_preserves_fingerprint(tmp_path, monkeypatch, failure):
    from livemorebio import build_info

    package = _source(tmp_path)
    (tmp_path / ".git").write_text("gitdir: placeholder", encoding="utf-8")
    def fail(*args, **kwargs):
        raise failure
    monkeypatch.setattr(build_info.subprocess, "run", fail)
    report = build_info.capture_build(package)
    assert report["commit"] is None
    assert report["source_sha256"]
    assert "PRIVATE" not in json.dumps(report)


def test_git_metadata_binds_import_root_and_ignores_inherited_overrides(tmp_path, monkeypatch):
    from livemorebio import build_info

    package = _source(tmp_path)
    (tmp_path / ".git").write_text("gitdir: placeholder", encoding="utf-8")
    monkeypatch.setenv("GIT_DIR", "/wrong/repo")
    monkeypatch.setenv("GIT_WORK_TREE", "/wrong/tree")
    def git(command, **kwargs):
        assert command[:3] == ["git", "-C", str(tmp_path)]
        assert not any(key.startswith("GIT_") for key in kwargs["env"])
        assert kwargs["timeout"] <= 2
        result = str(tmp_path) if "--show-toplevel" in command else "a" * 40
        return subprocess.CompletedProcess(command, 0, result + "\n", "")
    monkeypatch.setattr(build_info.subprocess, "run", git)
    report = build_info.capture_build(package)
    assert report["commit"] == "a" * 40
    assert report["source_kind"] == "checkout"


def test_malformed_commit_not_exposed(tmp_path, monkeypatch):
    from livemorebio import build_info

    package = _source(tmp_path)
    (tmp_path / ".git").mkdir()
    def git(command, **kwargs):
        output = str(tmp_path) if "--show-toplevel" in command else "PRIVATE TEST DATA"
        return subprocess.CompletedProcess(command, 0, output, "")
    monkeypatch.setattr(build_info.subprocess, "run", git)
    report = build_info.capture_build(package)
    assert report["commit"] is None
    assert "PRIVATE" not in json.dumps(report)


def test_report_is_cached_startup_identity_and_callers_cannot_mutate_it():
    from livemorebio.build_info import build_identity

    first = build_identity()
    second = build_identity()
    assert first == second
    first["commit"] = "tampered"
    assert build_identity()["commit"] != "tampered"


@pytest.mark.parametrize("module,service,port", [
    ("aegle.server", "Aegle", 18900),
    ("life_system.service", "LIFE", 18901),
    ("cendos.service", "Cendos", 18902),
])
def test_service_health_reports_imported_build_and_actual_port(module, service, port):
    from importlib import import_module
    from fastapi.testclient import TestClient
    from livemorebio.build_info import build_identity

    app = import_module("livemorebio." + module).app
    client = TestClient(app, base_url=f"http://127.0.0.1:{port}")
    response = client.get("/health")
    assert response.status_code == 200
    result = response.json()
    assert result["service"] == service
    assert result["port"] == port
    assert result["build"] == build_identity()
    assert "/Users/" not in response.text


def test_aegle_build_endpoint_is_no_store_and_has_no_private_path():
    from fastapi.testclient import TestClient
    from livemorebio.aegle.server import app
    from livemorebio.build_info import build_identity

    response = TestClient(app).get("/api/build")
    assert response.status_code == 200
    assert response.headers["cache-control"] == "no-store"
    assert response.json() == build_identity()


def test_health_listener_port_does_not_trust_host_header():
    from fastapi.testclient import TestClient
    from livemorebio.aegle.server import app

    response = TestClient(app, base_url="http://127.0.0.1:18900").get(
        "/health", headers={"Host": "127.0.0.1:9999"},
    )
    assert response.json()["port"] == 18900


@source_tree_only(".github/workflows/installer.yml")
def test_recovery_workflow_and_document_changes_trigger_release_gate():
    workflow = (Path(__file__).parents[2] / ".github/workflows/installer.yml").read_text(encoding="utf-8")
    assert workflow.count('"tools/**"') == 2
    assert workflow.count('"docs/**"') == 2


def test_service_probe_never_relays_unrecognized_upstream_fields(monkeypatch):
    from livemorebio import stack_transport
    from fastapi.testclient import TestClient
    from livemorebio.aegle.server import app
    from livemorebio.build_info import build_identity

    def health(url, **kwargs):
        service = {"life": "LIFE", "cendos": "Cendos", "aegle": "Aegle"}[kwargs["identity"].role]
        return stack_transport.StackResponse(200, "OK", (), json.dumps({"service": service, "ok": True, "port": 19763,
                                     "secret": "PRIVATE TEST DATA", "build": {
                                         **build_identity(), "path": "PRIVATE TEST DATA"}}).encode())
    for role in ("AEGLE", "LIFE", "CENDOS"):
        monkeypatch.setenv(f"LIVEMORE_{role}_URL", "http://127.0.0.1:19763")
        monkeypatch.setenv(f"LIVEMORE_{role}_IDENTITY_AUTHORITY", "http://127.0.0.1:19763")
    monkeypatch.setattr(stack_transport, "request", health)
    response = TestClient(app).get("/api/services")
    assert response.status_code == 200
    assert "PRIVATE" not in response.text
    assert all(info["up"] for info in response.json().values())


@pytest.mark.parametrize("payload", [[], {"ok": True, "service": "wrong"},
                                     {"ok": False, "service": "Aegle"}, "oversized", "deep_json"])
def test_service_probe_rejects_wrong_role_or_invalid_health(monkeypatch, payload):
    from livemorebio import stack_transport
    from fastapi.testclient import TestClient
    from livemorebio.aegle.server import app

    raw = b" " * 65537 if payload == "oversized" else (
        b"[" * 1500 + b"0" + b"]" * 1500 if payload == "deep_json" else json.dumps(payload).encode())
    for role in ("AEGLE", "LIFE", "CENDOS"):
        monkeypatch.setenv(f"LIVEMORE_{role}_URL", "http://127.0.0.1:19763")
        monkeypatch.setenv(f"LIVEMORE_{role}_IDENTITY_AUTHORITY", "http://127.0.0.1:19763")
    monkeypatch.setattr(stack_transport, "request", lambda *a, **k:
                        stack_transport.StackResponse(200, "OK", (), raw))
    result = TestClient(app).get("/api/services").json()
    assert all(info["up"] is False for info in result.values())


def test_identity_versions_the_public_runtime_asset_scope(tmp_path):
    from livemorebio import build_info
    import re
    javascript = (Path(__file__).parents[2] / "tools/check_atlas_browser.cjs").read_text(encoding="utf-8")
    roots = re.search(r"const roots=(\[.*?\]);", javascript).group(1)
    assert json.loads(roots.replace("'", '"')) == ["/".join(root) + "/" for root in build_info._ASSET_ROOTS]
    report = build_info.capture_build(_source(tmp_path))
    assert report["schema"] == "livemore.build-identity.v2"
    assert report["fingerprint_scope"] == "runtime_code_and_public_reference_assets.v2"
    assert build_info._ASSET_ROOTS == (
        ("aegle", "console"), ("anatomy", "ontology"), ("anatomy", "atlas"),
        ("life_system", "seed"), ("life_system", "reference", "seed"),
        ("scientific_sources", "data"),
    )


def test_python_javascript_fingerprint_scopes_and_bytes_agree(tmp_path):
    from livemorebio import build_info
    node = require_node()
    package = _source(tmp_path)
    for root in build_info._ASSET_ROOTS:
        for suffix in build_info._ASSET_SUFFIXES:
            item = package.joinpath(*root, "technical" + suffix)
            item.parent.mkdir(parents=True, exist_ok=True)
            item.write_text("technical identity fixture", encoding="utf-8")
    script = ("const h=require('./tools/check_atlas_browser.cjs');"
              "h.packageFingerprint(process.argv[1]).then(x=>console.log(x));")
    actual = subprocess.run([node, "-e", script, str(package)], cwd=Path(__file__).parents[2],
                            capture_output=True, text=True, check=True, encoding="utf-8").stdout.strip()
    assert actual == build_info.source_fingerprint(package)


def test_health_scope_allowlist_rejects_near_matches():
    from livemorebio.build_info import build_identity, public_service_health
    identity = build_identity()
    payload = {"ok": True, "service": "Aegle", "build": identity}
    assert public_service_health(payload, "Aegle")["build"]["fingerprint_scope"] == identity["fingerprint_scope"]
    identity["fingerprint_scope"] = "runtime_code_and_public_reference_assetsXv2"
    assert public_service_health(payload, "Aegle")["build"]["fingerprint_scope"] is None
