"""Exact transition contracts, only authored local SQLite technical fixtures."""
from __future__ import annotations

from contextlib import closing
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from dataclasses import FrozenInstanceError, replace
import json
import socket
import sqlite3
import subprocess
import urllib.request
from threading import Barrier
from uuid import uuid4

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import pytest

# Capture the real package identity (read-only git metadata) before fixture-level
# child-process refusals; no runtime/model constructor is invoked by this import.
from livemorebio import build_info
from livemorebio.aegle import subjects
from livemorebio.aegle.registry_audit import RegistryAuditError
from livemorebio.aegle.subjects import SubjectRegistry, SubjectRegistryError
from livemorebio.strict_json import MAX_SAFE_INTEGER
from livemorebio.tests.clinical_registry_fixtures import (
    CAPTURED, KEY, canonical, forbid_compilation, legacy_twin_record,
    replace_fixture_record, seed_legacy,
)
from ._timing import wait_seconds


@pytest.fixture(autouse=True)
def no_network_or_models(monkeypatch):
    def refuse(*_a, **_k):
        raise AssertionError("Registry technical test attempted network or native work")
    class RefusedSocket(socket.socket):
        def __new__(cls, *_a, **_k):
            refuse()

    # Retain a socket class so other preservation fixtures can additionally
    # patch its connect methods; no socket instance may be constructed here.
    monkeypatch.setattr(socket, "socket", RefusedSocket)
    for owner, names in ((socket, ("create_connection", "getaddrinfo")),
                         (subprocess, ("Popen", "run", "call", "check_output")),
                         (urllib.request, ("urlopen",))):
        for name in names:
            monkeypatch.setattr(owner, name, refuse)
    forbid_compilation(monkeypatch)


@pytest.fixture
def registry(tmp_path):
    return SubjectRegistry(tmp_path / "technical-transitions.sqlite3", key=KEY)


def seed(registry, suffix="one", *, active=False, human=False, version=1):
    record = legacy_twin_record(suffix, version=version)
    if not human: record["source_class"] = "SYNTHETIC"
    record["consent_scope"].append("life_patch")
    if active: record.update(lifecycle="ACTIVE", selection_mode="observations_only" if human else "model")
    seed_legacy(registry, record, key="technical-key-" + suffix)
    if active:
        with closing(registry._connect()) as connection, connection:
            connection.execute("INSERT INTO registry_state VALUES('active_twin_id',?,?)", (record["twin_id"], CAPTURED))
    return record


def rows(registry):
    with closing(sqlite3.connect(registry.path)) as connection:
        return {name: connection.execute(f"SELECT * FROM {name} ORDER BY 1").fetchall()
                for name in ("records", "registry_state", "subject_identifiers", "physical_device_bindings")}


def events(registry, request_id):
    with closing(sqlite3.connect(registry.path)) as connection:
        result = []
        for ident, sequence, nonce, encrypted in connection.execute("SELECT * FROM registry_audit ORDER BY sequence"):
            value = json.loads(AESGCM(KEY).decrypt(nonce, encrypted, b"livemore.subject-registry.audit.v1\0" + ident.encode()))
            if value["request_id"] == request_id: result.append((ident, sequence, value))
        return result


def prepare(registry, kind, target=None, *, request_id=None):
    request_id = request_id or str(uuid4())
    if kind == "activate":
        return registry.prepare_activation(target["twin_id"], expected_version=target["version"], request_id=request_id)
    if kind == "bind":
        return registry.prepare_patch_binding(target["twin_id"], {"device_id": "technical-device", "mode": "virtual"}, expected_version=target["version"], request_id=request_id)
    return registry.prepare_preview_clear(request_id=request_id)


def physical_body():
    return {"device_id": "technical-device", "mode": "physical", "protocol_version": "2.0", "hardware_revision": "B0-EVT-target", "firmware_version": "technical-not-validated", "calibration_status": "current", "attestation_reference": "urn:test:not-hardware-qualification"}


@pytest.mark.parametrize("kind", ["activate", "bind", "clear_for_preview"])
def test_prepare_is_detached_audited_and_changes_no_clinical_or_index_rows(registry, kind):
    current = seed(registry, "selected", active=True); target = seed(registry, "target")
    before = rows(registry); request_id = str(uuid4())
    candidate = prepare(registry, kind, target, request_id=request_id)
    assert type(candidate) is subjects.PreparedRegistryTransition
    assert candidate.kind == kind and candidate.request_id == request_id
    assert candidate.store_id == registry.audit.store_id and candidate.authority_token
    assert candidate.active_before == current and rows(registry) == before
    assert [e[2]["outcome_code"] for e in events(registry, request_id)] == [None, "SUCCESS"]
    assert "Authored software fixture" not in repr(candidate)
    with pytest.raises(FrozenInstanceError): candidate.timestamp = CAPTURED
    if candidate.record is not None:
        detached = candidate.record; detached["display_label"] = "changed outside"
        assert candidate.record["display_label"] != "changed outside"
    detached = candidate.active_before; detached["display_label"] = "changed outside"
    assert candidate.active_before == current


@pytest.mark.parametrize("kind", ["activate", "bind", "clear_for_preview"])
def test_commit_changes_only_prespecified_rows_and_preserves_creation_fields(registry, kind):
    current = seed(registry, "selected", active=True); target = seed(registry, "target"); unrelated = seed(registry, "unrelated")
    before = rows(registry); candidate = prepare(registry, kind, target)
    assert registry.commit_prepared_transition(candidate) == "COMMITTED"
    after = rows(registry)
    old_rows, new_rows = ({r[0]: r for r in table} for table in (before["records"], after["records"]))
    assert old_rows[unrelated["twin_id"]] == new_rows[unrelated["twin_id"]]
    assert before["subject_identifiers"] == after["subject_identifiers"]
    assert before["physical_device_bindings"] == after["physical_device_bindings"]
    for ident in old_rows:
        assert old_rows[ident][:3] == new_rows[ident][:3]
        assert old_rows[ident][5:8] == new_rows[ident][5:8]
    if kind == "activate":
        assert registry.get_twin(target["twin_id"]) == candidate.record
        assert candidate.record["selection_mode"] == "model"
        assert registry.get_twin(current["twin_id"])["version"] == 2
    elif kind == "bind":
        assert old_rows[current["twin_id"]] == new_rows[current["twin_id"]]
        assert before["registry_state"] == after["registry_state"]
        assert candidate.record["lifecycle"] == "DATA_ADMITTED"
    else:
        assert old_rows[target["twin_id"]] == new_rows[target["twin_id"]]
        assert candidate.record is None and registry.active_twin() is None
    assert [e[2]["outcome_code"] for e in events(registry, candidate.request_id)] == [None, "SUCCESS", None, "SUCCESS"]


def test_clear_truly_absent_is_audited_no_clinical_write(registry):
    seed(registry); before = rows(registry)
    candidate = registry.prepare_preview_clear(request_id=str(uuid4()))
    assert candidate.active_before is candidate.active_after is candidate.record is None
    assert registry.commit_prepared_transition(candidate) == "COMMITTED" and rows(registry) == before


@pytest.mark.parametrize("version", [True, False, 1.0, "1", None, 0, -1, MAX_SAFE_INTEGER, MAX_SAFE_INTEGER+1])
@pytest.mark.parametrize("kind", ["activate", "bind"])
def test_strict_versions_reject_before_any_registry_access(registry, monkeypatch, version, kind):
    monkeypatch.setattr(registry, "_connect", lambda: pytest.fail("invalid version accessed storage"))
    with pytest.raises(SubjectRegistryError) as caught:
        if kind == "activate": registry.prepare_activation("twin-technical", expected_version=version, request_id=str(uuid4()))
        else: registry.prepare_patch_binding("twin-technical", {"device_id": "technical"}, expected_version=version, request_id=str(uuid4()))
    assert caught.value.code == "TWIN_VERSION_CONFLICT"


@pytest.mark.parametrize("body", [None, [], {"device_id": "x", "unknown": "private"}, {"device_id": "x", "expected_version": True}, {"device_id": "x", "expected_version": 2}, {"device_id": []}, {"device_id": "x", "mode": []}])
def test_binding_body_rejects_before_storage(registry, monkeypatch, body):
    monkeypatch.setattr(registry, "_connect", lambda: pytest.fail("invalid body accessed storage"))
    with pytest.raises(SubjectRegistryError): registry.prepare_patch_binding("twin-technical", body, expected_version=1, request_id=str(uuid4()))


@pytest.mark.parametrize("identity", [None, "bad", " " + str(uuid4()), [], 1])
def test_request_identity_rejects_before_access(registry, monkeypatch, identity):
    monkeypatch.setattr(registry, "_connect", lambda: pytest.fail("invalid request accessed storage"))
    with pytest.raises(SubjectRegistryError) as caught: registry.prepare_preview_clear(request_id=identity)
    assert caught.value.code == "INVALID_REQUEST_ID"


@pytest.mark.parametrize("damage", ["orphan_active", "missing_target", "wrong_type", "inactive", "second_active", "plaintext_version_bool", "stored_unsafe_version"])
def test_incoherent_active_topology_rejects_without_repair(registry, damage):
    current = seed(registry, active=True)
    with closing(registry._connect()) as connection, connection:
        if damage == "orphan_active": connection.execute("DELETE FROM registry_state WHERE state_key='active_twin_id'")
        elif damage == "missing_target": connection.execute("UPDATE registry_state SET state_value='twin-missing' WHERE state_key='active_twin_id'")
        elif damage == "wrong_type": connection.execute("UPDATE records SET record_type='COHORT'")
        elif damage == "inactive": connection.execute("UPDATE records SET lifecycle='DATA_ADMITTED'")
        elif damage == "stored_unsafe_version": connection.execute("UPDATE records SET version=?", (MAX_SAFE_INTEGER,))
    if damage == "second_active":
        other = seed(registry, "second"); other["lifecycle"] = "ACTIVE"; replace_fixture_record(registry, other)
    if damage == "plaintext_version_bool": current["version"] = True; replace_fixture_record(registry, current)
    before = rows(registry)
    with pytest.raises(SubjectRegistryError) as caught: registry.prepare_preview_clear(request_id=str(uuid4()))
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE" and rows(registry) == before


@pytest.mark.parametrize("damage", ["target_payload", "target_reseal", "target_request_hash", "target_created_at", "pointer_time", "selected_payload", "additional_active", "device_index"])
def test_same_version_full_readset_change_conflicts_before_mutation(registry, damage):
    current = seed(registry, "selected", active=True); target = seed(registry, "target")
    candidate = prepare(registry, "bind" if damage == "device_index" else "activate", target)
    if damage in {"target_payload", "target_reseal", "selected_payload"}:
        value = deepcopy(current if damage == "selected_payload" else target)
        if damage != "target_reseal": value["display_label"] = "authored same-version edit"
        replace_fixture_record(registry, value)
    else:
        with closing(registry._connect()) as connection, connection:
            if damage == "target_request_hash": connection.execute("UPDATE records SET request_hash='technical-changed' WHERE record_id=?", (target["twin_id"],))
            elif damage == "target_created_at": connection.execute("UPDATE records SET created_at='technical-changed' WHERE record_id=?", (target["twin_id"],))
            elif damage == "pointer_time": connection.execute("UPDATE registry_state SET updated_at='technical-changed' WHERE state_key='active_twin_id'")
            elif damage == "device_index": connection.execute("INSERT INTO physical_device_bindings VALUES(?,?,?)", (registry._fingerprint("technical-device"), current["twin_id"], CAPTURED))
        if damage == "additional_active":
            other = seed(registry, "extra"); other["lifecycle"] = "ACTIVE"; replace_fixture_record(registry, other)
    before = rows(registry)
    with pytest.raises(SubjectRegistryError): registry.commit_prepared_transition(candidate)
    assert rows(registry) == before


def test_forged_prepared_after_cannot_change_evidence(registry):
    target = seed(registry); candidate = prepare(registry, "activate", target)
    changed = candidate.record; changed["observations"]["glucose_mgdl"]["value"] = 999
    forged = replace(candidate, _after_json=canonical({target["twin_id"]: changed}))
    before = rows(registry)
    with pytest.raises(SubjectRegistryError): registry.commit_prepared_transition(forged)
    assert rows(registry) == before


def test_real_human_activation_still_requires_binding_not_generic_prior(registry):
    target = seed(registry, human=True); before = rows(registry)
    with pytest.raises(ValueError) as caught: prepare(registry, "activate", target)
    assert caught.value.code == "MODEL_BINDING_REQUIRED" and rows(registry) == before


def test_physical_binding_requires_exact_selected_human_and_retains_index_across_mode(registry):
    target = seed(registry, active=True, human=True)
    candidate = registry.prepare_patch_binding(target["twin_id"], physical_body(), expected_version=1, request_id=str(uuid4()))
    assert candidate.selected and candidate.active_before == target
    assert registry.commit_prepared_transition(candidate) == "COMMITTED"
    after = rows(registry)
    assert candidate.record["selection_mode"] == "observations_only"
    assert candidate.record["patch_bindings"][0]["telemetry_admission"] == "PENDING_SIGNED_ENVELOPE"
    switched = registry.prepare_patch_binding(target["twin_id"], {"device_id": "technical-device", "mode": "replay"}, expected_version=2, request_id=str(uuid4()))
    assert registry.commit_prepared_transition(switched) == "COMMITTED"
    assert rows(registry)["physical_device_bindings"] == after["physical_device_bindings"]


def test_physical_unselected_rejects_and_virtual_binding_preserves_other_device_index(registry):
    selected = seed(registry, active=True, human=True); other = seed(registry, "other", human=True)
    before = rows(registry)
    with pytest.raises(SubjectRegistryError) as caught: registry.prepare_patch_binding(other["twin_id"], physical_body(), expected_version=1, request_id=str(uuid4()))
    assert caught.value.code == "PHYSICAL_PATCH_REQUIRES_ACTIVE_TWIN" and rows(registry) == before
    with closing(registry._connect()) as connection, connection:
        connection.execute("INSERT INTO physical_device_bindings VALUES(?,?,?)", (registry._fingerprint("technical-device"), selected["twin_id"], CAPTURED))
    before = rows(registry); candidate = prepare(registry, "bind", other)
    assert not candidate.selected and registry.commit_prepared_transition(candidate) == "COMMITTED"
    assert rows(registry)["physical_device_bindings"] == before["physical_device_bindings"]


def install_commit_fault(registry, monkeypatch, *, persisted, damage=None, close_failure=False, recovery_failure=False):
    mutation = {"attempted": False}
    class Fault(sqlite3.Connection):
        commits = 0
        def commit(self):
            self.commits += 1
            if self.commits == 2 and not mutation["attempted"]:
                mutation["attempted"] = True
                if persisted: super().commit()
                if damage: damage()
                raise sqlite3.OperationalError("technical commit acknowledgment lost")
            return super().commit()
        def close(self):
            super().close()
            if close_failure: raise OSError("technical close failure")
    def connect():
        if recovery_failure and mutation["attempted"]: raise sqlite3.OperationalError("technical recovery read unavailable")
        connection = sqlite3.connect(registry.path, factory=Fault); connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        return connection
    monkeypatch.setattr(registry, "_connect", connect)


@pytest.mark.parametrize("kind", ["activate", "bind", "clear_for_preview"])
def test_exact_lost_ack_witness_confirms_once_without_resealing(registry, monkeypatch, kind):
    seed(registry, "selected", active=True); target = seed(registry, "target")
    candidate = prepare(registry, kind, target)
    sealed = []; old_seal = registry._seal
    def seal(*args): sealed.append(args[0]); return old_seal(*args)
    monkeypatch.setattr(registry, "_seal", seal)
    install_commit_fault(registry, monkeypatch, persisted=True)
    assert registry.commit_prepared_transition(candidate) == "COMMITTED"
    assert len(sealed) == len(set(sealed))
    assert [e[2]["outcome_code"] for e in events(registry, candidate.request_id)] == [None, "SUCCESS", None, "SUCCESS"]


@pytest.mark.parametrize("damage", ["target", "demotion", "pointer", "begin", "terminal", "reservation", "topology"])
def test_lost_ack_requires_every_record_topology_and_terminal_audit_witness(registry, monkeypatch, damage):
    current = seed(registry, "selected", active=True); target = seed(registry, "target")
    candidate = prepare(registry, "activate", target)
    def alter():
        with closing(sqlite3.connect(registry.path)) as connection, connection:
            if damage in {"target", "demotion"}:
                connection.execute("UPDATE records SET request_hash='technical-changed' WHERE record_id=?", ((target if damage == "target" else current)["twin_id"],))
            elif damage == "pointer": connection.execute("UPDATE registry_state SET updated_at='changed' WHERE state_key='active_twin_id'")
            elif damage in {"begin", "terminal"}:
                offset = 1 if damage == "begin" else 0
                connection.execute("UPDATE registry_audit SET ciphertext=X'00' WHERE sequence=(SELECT MAX(sequence)-? FROM registry_audit)", (offset,))
            elif damage == "reservation":
                begin = connection.execute("SELECT event_id FROM registry_audit ORDER BY sequence DESC LIMIT 1 OFFSET 1").fetchone()[0]
                connection.execute("INSERT INTO registry_audit_reservations VALUES(?,?)", (begin, candidate.request_id))
            else: connection.execute("UPDATE records SET lifecycle='ACTIVE' WHERE record_id=?", (current["twin_id"],))
    install_commit_fault(registry, monkeypatch, persisted=True, damage=alter)
    with pytest.raises(SubjectRegistryError) as caught: registry.commit_prepared_transition(candidate)
    assert caught.value.code == "SELECTION_COMMIT_UNCONFIRMED"


def test_lost_ack_requires_exact_physical_index(registry, monkeypatch):
    target = seed(registry, active=True, human=True)
    candidate = registry.prepare_patch_binding(target["twin_id"], physical_body(), expected_version=1, request_id=str(uuid4()))
    def alter():
        with closing(sqlite3.connect(registry.path)) as connection, connection:
            connection.execute("UPDATE physical_device_bindings SET bound_at='changed'")
    install_commit_fault(registry, monkeypatch, persisted=True, damage=alter)
    with pytest.raises(SubjectRegistryError) as caught: registry.commit_prepared_transition(candidate)
    assert caught.value.code == "SELECTION_COMMIT_UNCONFIRMED"


@pytest.mark.parametrize("kind", ["activate", "bind", "clear_for_preview"])
def test_confirmed_rollback_preserves_clinical_rows_and_finishes_failed_access(registry, monkeypatch, kind):
    seed(registry, "selected", active=True); target = seed(registry, "target")
    candidate = prepare(registry, kind, target); before = rows(registry)
    install_commit_fault(registry, monkeypatch, persisted=False)
    with pytest.raises(SubjectRegistryError) as caught: registry.commit_prepared_transition(candidate)
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE" and rows(registry) == before
    assert [e[2]["outcome_code"] for e in events(registry, candidate.request_id)] == [None, "SUCCESS", None, "ACCESS_FAILED"]


def test_lost_ack_recovery_read_failure_is_not_rollback(registry, monkeypatch):
    target = seed(registry); candidate = prepare(registry, "activate", target)
    install_commit_fault(registry, monkeypatch, persisted=True, recovery_failure=True)
    with pytest.raises(SubjectRegistryError) as caught: registry.commit_prepared_transition(candidate)
    assert caught.value.code == "SELECTION_COMMIT_UNCONFIRMED"


@pytest.mark.parametrize("lost_ack", [False, True])
def test_confirmed_commit_close_failure_retains_committed_cleanup_outcome(registry, monkeypatch, lost_ack):
    target = seed(registry); candidate = prepare(registry, "activate", target)
    if lost_ack: install_commit_fault(registry, monkeypatch, persisted=True, close_failure=True)
    else:
        class CloseFault(sqlite3.Connection):
            def close(self): super().close(); raise OSError("technical close failure")
        def connect():
            connection = sqlite3.connect(registry.path, factory=CloseFault); connection.row_factory = sqlite3.Row
            return connection
        monkeypatch.setattr(registry, "_connect", connect)
    assert registry.commit_prepared_transition(candidate) == "COMMITTED_CLEANUP_UNCONFIRMED"
    assert rows(registry)["records"][0][4] == 2


def test_audit_finish_returns_exact_terminal_event_identity(registry):
    with closing(registry._connect()) as connection:
        begin = registry.audit.begin(connection, request_id=str(uuid4()), action="inspect", opaque_record_id=None)
        connection.commit()
        terminal = registry.audit.finish(connection, begin, outcome_code="SUCCESS")
        assert isinstance(terminal, str) and terminal != begin.event_id
        assert connection.execute("SELECT event_id FROM registry_audit WHERE event_id=?", (terminal,)).fetchone()[0] == terminal
        connection.commit()


def test_preparation_authority_adoption_blocks_stale_commit_before_decrypt(tmp_path, monkeypatch):
    from livemorebio.tests.test_registry_bootstrap_contract import legacy_audited_store
    path = legacy_audited_store(tmp_path)
    registry = SubjectRegistry(path, key=KEY)
    candidate = registry.prepare_patch_binding("twin-fixture-one", {"device_id": "technical"}, expected_version=1, request_id=str(uuid4()))
    assert candidate.authority_token.startswith("legacy:")
    other = SubjectRegistry(path, key=KEY); other.adopt_audit_authority()
    before = rows(registry)
    monkeypatch.setattr(registry, "_open", lambda row: pytest.fail("stale authority decrypted clinical data"))
    with pytest.raises(RegistryAuditError): registry.commit_prepared_transition(candidate)
    assert rows(registry) == before
    assert [e[2]["outcome_code"] for e in events(registry, candidate.request_id)] == [None, "SUCCESS", None, "ACCESS_FAILED"]


def test_each_preparation_and_commit_decrypt_has_its_own_durable_begin(registry, monkeypatch):
    target = seed(registry); request_id = str(uuid4()); old_open = registry._open
    counts = []
    def guarded(row):
        audit = events(registry, request_id)
        assert audit[-1][2]["outcome_code"] is None
        counts.append(len(audit))
        return old_open(row)
    monkeypatch.setattr(registry, "_open", guarded)
    candidate = prepare(registry, "activate", target, request_id=request_id)
    assert registry.commit_prepared_transition(candidate) == "COMMITTED"
    assert counts == [1, 3]


def test_preparation_is_pure_and_timestamp_is_after_snapshot_connection_closes(registry, monkeypatch):
    target = seed(registry)
    connections = []
    class Tracked(sqlite3.Connection):
        closed = False
        def close(self): super().close(); self.closed = True
    def connect():
        connection = sqlite3.connect(registry.path, factory=Tracked); connection.row_factory = sqlite3.Row
        connections.append(connection); return connection
    monkeypatch.setattr(registry, "_connect", connect)
    original = subjects._activation_transition_admission; saw = []
    def admission(record):
        assert all(connection.closed for connection in connections)
        saw.append(record["twin_id"])
        return original(record)
    monkeypatch.setattr(subjects, "_activation_transition_admission", admission)
    def clock():
        assert all(connection.closed for connection in connections)
        return CAPTURED
    monkeypatch.setattr(subjects, "_now", clock)
    candidate = prepare(registry, "activate", target)
    assert saw and candidate.timestamp == CAPTURED


def test_changed_original_begin_row_between_phases_cannot_become_commit_witness(registry, monkeypatch):
    target = seed(registry); candidate = prepare(registry, "activate", target); before = rows(registry)
    class ChangeBegin(sqlite3.Connection):
        commits = 0
        def commit(self):
            self.commits += 1
            super().commit()
            if self.commits == 1:
                with closing(sqlite3.connect(registry.path)) as external, external:
                    external.execute("UPDATE registry_audit SET sequence=sequence+100 WHERE sequence=(SELECT MAX(sequence) FROM registry_audit)")
    def connect():
        connection = sqlite3.connect(registry.path, factory=ChangeBegin); connection.row_factory = sqlite3.Row
        return connection
    monkeypatch.setattr(registry, "_connect", connect)
    monkeypatch.setattr(registry, "_open", lambda row: pytest.fail("changed begin admitted clinical decryption"))
    with pytest.raises(RegistryAuditError): registry.commit_prepared_transition(candidate)
    assert rows(registry) == before


@pytest.mark.parametrize("phase", ["begin", "seal", "success_audit", "partial_write"])
def test_precommit_failure_preserves_records_and_never_commits_success(registry, monkeypatch, phase):
    seed(registry, "selected", active=True); target = seed(registry, "target")
    candidate = prepare(registry, "activate", target); before = rows(registry)
    def refuse(*_a, **_k): raise sqlite3.OperationalError("authored storage failure")
    if phase == "begin": monkeypatch.setattr(registry.audit, "begin", refuse)
    if phase == "seal": monkeypatch.setattr(registry, "_seal", refuse)
    if phase == "success_audit":
        original = registry.audit.finish
        def finish(*args, outcome_code):
            if outcome_code == "SUCCESS": refuse()
            return original(*args, outcome_code=outcome_code)
        monkeypatch.setattr(registry.audit, "finish", finish)
    if phase == "partial_write":
        original = registry._seal; count = []
        def seal(*args):
            count.append(1)
            if len(count) == 2: refuse()
            return original(*args)
        monkeypatch.setattr(registry, "_seal", seal)
    with pytest.raises(SubjectRegistryError) as caught: registry.commit_prepared_transition(candidate)
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE" and rows(registry) == before
    assert [e[2]["outcome_code"] for e in events(registry, candidate.request_id)].count("SUCCESS") == 1


def test_unconfirmed_rollback_preserves_primary_uncertainty_even_when_close_fails(registry, monkeypatch):
    target = seed(registry); candidate = prepare(registry, "activate", target)
    class RollbackFault(sqlite3.Connection):
        commits = 0
        def commit(self):
            self.commits += 1
            if self.commits == 2: raise sqlite3.OperationalError("technical commit failure")
            return super().commit()
        def rollback(self): raise OSError("technical rollback acknowledgment unknown")
        def close(self): super().close(); raise OSError("technical close failure")
    def connect():
        connection = sqlite3.connect(registry.path, factory=RollbackFault); connection.row_factory = sqlite3.Row
        return connection
    monkeypatch.setattr(registry, "_connect", connect)
    with pytest.raises(SubjectRegistryError) as caught: registry.commit_prepared_transition(candidate)
    assert caught.value.code == "SELECTION_COMMIT_UNCONFIRMED"
    assert "technical close" not in str(caught.value)


@pytest.mark.parametrize("kind", ["activate", "bind", "clear_for_preview"])
def test_direct_wrappers_use_same_commit_helper_and_detached_preallocated_results(registry, monkeypatch, kind):
    target = seed(registry, active=True); seen = []
    original = registry.commit_prepared_transition
    def commit(value): seen.append(value); return original(value)
    monkeypatch.setattr(registry, "commit_prepared_transition", commit)
    if kind == "activate": result = registry.activate_twin(target["twin_id"], expected_version=1)
    elif kind == "bind": result = registry.bind_patch(target["twin_id"], {"device_id": "technical"}, expected_version=1)
    else: result = registry.clear_active_twin()
    assert len(seen) == 1 and seen[0].kind == kind
    assert result == seen[0].record


@pytest.mark.parametrize("kind", ["activate", "bind", "clear_for_preview"])
def test_direct_wrappers_surface_confirmed_cleanup_without_claiming_rollback(registry, monkeypatch, kind):
    target = seed(registry, active=True)
    original = registry.commit_prepared_transition
    def commit(value):
        assert original(value) == "COMMITTED"
        return "COMMITTED_CLEANUP_UNCONFIRMED"
    monkeypatch.setattr(registry, "commit_prepared_transition", commit)
    with pytest.raises(SubjectRegistryError) as caught:
        if kind == "activate": registry.activate_twin(target["twin_id"], expected_version=1)
        elif kind == "bind": registry.bind_patch(target["twin_id"], {"device_id": "technical"}, expected_version=1)
        else: registry.clear_active_twin()
    assert caught.value.code == "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
    assert "native" not in str(caught.value) and "resource cleanup" in str(caught.value)
    assert rows(registry)["records"][0][4] == 2


@pytest.mark.parametrize("kind", ["activate", "bind", "clear_for_preview"])
def test_two_writer_connections_cannot_commit_same_prepared_snapshot_twice(registry, kind):
    current = seed(registry, "selected", active=True); target = seed(registry, "target")
    candidates = [prepare(registry, kind, target) for _ in range(2)]
    barrier = Barrier(2)
    def run(value):
        barrier.wait(timeout=wait_seconds(3))
        try: return registry.commit_prepared_transition(value)
        except SubjectRegistryError as error: return error.code
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(run, value) for value in candidates]
        results = [future.result(timeout=wait_seconds(10)) for future in futures]
    assert sorted(results) == ["COMMITTED", "TWIN_VERSION_CONFLICT"]
    saved = {row[0]: row for row in rows(registry)["records"]}
    assert saved[current["twin_id"]][4] == (1 if kind == "bind" else 2)
    assert saved[target["twin_id"]][4] == (1 if kind == "clear_for_preview" else 2)


def test_last_incrementable_version_is_exact_and_cannot_be_incremented_again(registry):
    target = seed(registry, version=MAX_SAFE_INTEGER-1)
    result = registry.activate_twin(target["twin_id"], expected_version=MAX_SAFE_INTEGER-1)
    assert type(result["version"]) is int and result["version"] == MAX_SAFE_INTEGER
    before = rows(registry)
    with pytest.raises(SubjectRegistryError): registry.activate_twin(target["twin_id"], expected_version=MAX_SAFE_INTEGER)
    assert rows(registry) == before


def test_absent_clear_lost_ack_requires_its_own_audit_not_a_clinical_row(registry, monkeypatch):
    candidate = prepare(registry, "clear_for_preview")
    install_commit_fault(registry, monkeypatch, persisted=True)
    assert registry.commit_prepared_transition(candidate) == "COMMITTED"
    assert [e[2]["outcome_code"] for e in events(registry, candidate.request_id)] == [None, "SUCCESS", None, "SUCCESS"]


@pytest.mark.parametrize("signal", [KeyboardInterrupt, SystemExit])
def test_close_interruption_does_not_mask_confirmed_durable_commit(registry, monkeypatch, signal):
    target = seed(registry); candidate = prepare(registry, "activate", target)
    class CloseInterrupt(sqlite3.Connection):
        def close(self): super().close(); raise signal()
    def connect():
        connection = sqlite3.connect(registry.path, factory=CloseInterrupt); connection.row_factory = sqlite3.Row
        return connection
    monkeypatch.setattr(registry, "_connect", connect)
    try:
        outcome = registry.commit_prepared_transition(candidate)
    except BaseException:
        pytest.fail("Synthetic close interruption masked confirmed commit")
    assert outcome == "COMMITTED_CLEANUP_UNCONFIRMED"


def install_audit_trigger(registry, timing, body, *, table="registry_audit", condition=True):
    # This is deliberately a malformed authored store, never a product schema.
    when = " WHEN EXISTS(SELECT 1 FROM registry_audit_reservations)" if condition else ""
    with closing(registry._connect()) as connection, connection:
        connection.execute(f"CREATE TRIGGER technical_late_audit {timing} ON {table}{when} BEGIN {body} END")


@pytest.mark.parametrize("field,value", [
    ("ciphertext", "X'00'"), ("nonce", "X'00'"), ("sequence", "NEW.sequence+100"),
    ("event_id", "'technical-replaced-event'"),
])
def test_terminal_origin_bytes_cannot_be_replaced_before_they_become_witness(registry, field, value):
    target = seed(registry); candidate = prepare(registry, "activate", target); before = rows(registry)
    install_audit_trigger(registry, "AFTER INSERT", f"UPDATE registry_audit SET {field}={value} WHERE event_id=NEW.event_id;")
    with pytest.raises(RegistryAuditError): registry.commit_prepared_transition(candidate)
    assert rows(registry) == before
    # The failed completion is also corrupted; its attempted terminal is rolled
    # back, leaving the genuinely committed BEGIN and its reserved completion.
    with closing(registry._connect()) as connection:
        assert connection.execute("SELECT COUNT(*) FROM registry_audit_reservations").fetchone()[0] == 1


def test_reservation_delete_cannot_corrupt_verified_terminal_after_append(registry):
    target = seed(registry); candidate = prepare(registry, "activate", target); before = rows(registry)
    install_audit_trigger(registry, "AFTER DELETE", "UPDATE registry_audit SET ciphertext=X'00' WHERE sequence=(SELECT MAX(sequence) FROM registry_audit);", table="registry_audit_reservations", condition=False)
    with pytest.raises(RegistryAuditError): registry.commit_prepared_transition(candidate)
    assert rows(registry) == before


@pytest.mark.parametrize("body", [
    "UPDATE registry_audit SET ciphertext=X'00' WHERE event_id=NEW.event_id;",
    "DELETE FROM registry_audit_reservations WHERE event_id=NEW.event_id;",
    "UPDATE registry_audit_reservations SET request_id='11111111-1111-4111-8111-111111111111' WHERE event_id=NEW.event_id;",
])
def test_begin_origin_and_reservation_pair_are_verified_after_last_begin_write(registry, monkeypatch, body):
    target = seed(registry); candidate = prepare(registry, "activate", target); before = rows(registry)
    install_audit_trigger(registry, "AFTER INSERT", body, table="registry_audit_reservations", condition=False)
    monkeypatch.setattr(registry, "_open", lambda row: pytest.fail("Unverified BEGIN allowed clinical decrypt"))
    with pytest.raises(RegistryAuditError): registry.commit_prepared_transition(candidate)
    assert rows(registry) == before
    assert len(events(registry, candidate.request_id)) == 2


def test_begin_event_insert_fault_fails_before_protected_read(registry, monkeypatch):
    target = seed(registry); candidate = prepare(registry, "activate", target); before = rows(registry)
    install_audit_trigger(registry, "AFTER INSERT", "UPDATE registry_audit SET ciphertext=X'00' WHERE event_id=NEW.event_id;", condition=False)
    monkeypatch.setattr(registry, "_open", lambda row: pytest.fail("Unverified BEGIN allowed clinical decrypt"))
    with pytest.raises(RegistryAuditError): registry.commit_prepared_transition(candidate)
    assert rows(registry) == before


@pytest.mark.parametrize("damage", ["target", "demotion", "pointer", "device", "topology"])
def test_terminal_side_effects_and_failed_completion_never_change_clinical_state(registry, damage):
    current = seed(registry, "selected", active=True, human=damage == "device")
    target = seed(registry, "target"); third = seed(registry, "third")
    if damage == "device":
        candidate = registry.prepare_patch_binding(current["twin_id"], physical_body(), expected_version=1, request_id=str(uuid4()))
        statement = "UPDATE physical_device_bindings SET bound_at='technical-late-change';"
    else:
        candidate = prepare(registry, "activate", target)
        statement = {
            "target": f"UPDATE records SET version=999 WHERE record_id='{target['twin_id']}';",
            "demotion": f"UPDATE records SET version=999 WHERE record_id='{current['twin_id']}';",
            "pointer": "DELETE FROM registry_state WHERE state_key='active_twin_id';",
            "topology": f"UPDATE records SET lifecycle='ACTIVE' WHERE record_id='{third['twin_id']}';",
        }[damage]
    before = rows(registry)
    install_audit_trigger(registry, "AFTER INSERT", statement)
    with pytest.raises(SubjectRegistryError) as caught: registry.commit_prepared_transition(candidate)
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE"
    assert rows(registry) == before
    # A failed-access completion is allowed only when its late effect changes
    # nothing (e.g. an already absent device index), otherwise it remains pending.
    completed = events(registry, candidate.request_id)
    assert [item[2]["outcome_code"] for item in completed].count("SUCCESS") == 1


def test_authentic_but_different_terminal_semantics_are_not_the_expected_event(registry, monkeypatch):
    target = seed(registry); candidate = prepare(registry, "activate", target); before = rows(registry)
    original = registry._connect
    def change(event_id, nonce, ciphertext):
        cipher = AESGCM(KEY); aad = b"livemore.subject-registry.audit.v1\0" + event_id.encode()
        payload = json.loads(cipher.decrypt(nonce, ciphertext, aad))
        payload["source_sha256"] = "f" * 64
        return cipher.encrypt(nonce, canonical(payload), aad)
    def connect():
        connection = original(); connection.create_function("technical_different_event", 3, change); return connection
    monkeypatch.setattr(registry, "_connect", connect)
    install_audit_trigger(registry, "AFTER INSERT", "UPDATE registry_audit SET ciphertext=technical_different_event(NEW.event_id,NEW.nonce,NEW.ciphertext) WHERE event_id=NEW.event_id;")
    with pytest.raises(RegistryAuditError): registry.commit_prepared_transition(candidate)
    assert rows(registry) == before


def reference_record(registry):
    from livemorebio.tests.test_clinical_context_contract import _legacy_reference_record
    record = _legacy_reference_record()
    seed_legacy(registry, record, key="technical-reference-context")
    return record


def test_supported_reference_preparation_and_commit_never_construct_under_authority(registry):
    from livemorebio.aegle.model_source import ModelSourceAuthority
    record = reference_record(registry); authority = ModelSourceAuthority()
    # The autouse human/profile/build tripwires remain active. This uses the
    # real authority guard, not only the closed SQLite-connection assertion.
    candidate = authority.capture(lambda: registry.prepare_activation(record["twin_id"], expected_version=1, request_id=str(uuid4())))
    with authority.commit_guard():
        assert registry.commit_prepared_transition(candidate) == "COMMITTED"


@pytest.mark.parametrize("reject", [False, True])
def test_standalone_profile_admission_is_between_prepared_read_and_commit(registry, monkeypatch, reject):
    record = reference_record(registry); calls = []; original_prepare = registry.prepare_activation
    before = rows(registry)
    def prepare(*args, **kwargs):
        result = original_prepare(*args, **kwargs); calls.append("prepared"); return result
    class Human:
        def metabolic_profile(self, _):
            assert calls == ["prepared", "human"]
            calls.append("profile")
            if reject: raise ValueError("authored candidate admission rejection")
            return object()
    def human(data):
        assert data == record and calls == ["prepared"]
        # Acquiring an independent writer now proves the read writer lock ended.
        with closing(sqlite3.connect(registry.path, timeout=0)) as connection:
            connection.execute("BEGIN IMMEDIATE"); connection.rollback()
        calls.append("human"); return Human()
    original_commit = registry.commit_prepared_transition
    def commit(candidate):
        assert calls == ["prepared", "human", "profile"]
        calls.append("commit"); return original_commit(candidate)
    monkeypatch.setattr(registry, "prepare_activation", prepare)
    monkeypatch.setattr(SubjectRegistry, "admitted_human", staticmethod(human))
    monkeypatch.setattr(registry, "commit_prepared_transition", commit)
    if reject:
        with pytest.raises(ValueError, match="authored candidate"): registry.activate_twin(record["twin_id"], expected_version=1)
        assert rows(registry) == before and "commit" not in calls
    else:
        assert registry.activate_twin(record["twin_id"], expected_version=1)["version"] == 2
        assert calls == ["prepared", "human", "profile", "commit"]


@pytest.mark.parametrize("owner", ["prepare", "commit"])
@pytest.mark.parametrize("phase", ["begin", "reservation_insert", "terminal", "reservation_delete"])
@pytest.mark.parametrize("damage", ["target", "selected", "pointer_time", "pointer_absence", "device", "topology"])
def test_selection_phase_writes_preserve_fresh_raw_scope(registry, monkeypatch, owner, phase, damage):
    selected = seed(registry, "selected", active=True)
    target = seed(registry, "target"); extra = seed(registry, "extra")
    fingerprint = registry._fingerprint("technical-device")
    with closing(registry._connect()) as connection, connection:
        connection.execute("INSERT INTO physical_device_bindings VALUES(?,?,?)", (fingerprint, selected["twin_id"], CAPTURED))
    request = str(uuid4())
    candidate = prepare(registry, "bind", target, request_id=request) if owner == "commit" else None
    before = rows(registry)
    statements = {
        "target": f"UPDATE records SET version=999 WHERE record_id='{target['twin_id']}';",
        "selected": f"UPDATE records SET version=999 WHERE record_id='{selected['twin_id']}';",
        "pointer_time": "UPDATE registry_state SET updated_at='technical-changed';",
        "pointer_absence": "DELETE FROM registry_state WHERE state_key='active_twin_id';",
        "device": "UPDATE physical_device_bindings SET bound_at='technical-changed';",
        "topology": f"UPDATE records SET lifecycle='ACTIVE' WHERE record_id='{extra['twin_id']}';",
    }
    table = "registry_audit" if phase in {"begin", "terminal"} else "registry_audit_reservations"
    timing = "DELETE" if phase == "reservation_delete" else "INSERT"
    condition = (" WHEN " + ("NOT " if phase == "begin" else "") + "EXISTS(SELECT 1 FROM registry_audit_reservations)") if table == "registry_audit" else ""
    with closing(registry._connect()) as connection, connection:
        connection.execute(f"CREATE TRIGGER authored_selection_phase AFTER {timing} ON {table}{condition} BEGIN {statements[damage]} END")
    opens = []; original = registry._open
    def opened(row): opens.append(row["record_id"]); return original(row)
    monkeypatch.setattr(registry, "_open", opened)
    with pytest.raises((SubjectRegistryError, RegistryAuditError)):
        if owner == "prepare": prepare(registry, "bind", target, request_id=request)
        else: registry.commit_prepared_transition(candidate)
    assert rows(registry) == before
    if phase in {"begin", "reservation_insert"}: assert opens == []
    completed = events(registry, request)
    assert sum(event[2]["outcome_code"] == "SUCCESS" for event in completed) == (1 if owner == "commit" else 0)


@pytest.mark.parametrize("owner", ["prepare", "commit"])
@pytest.mark.parametrize("damage", ["delete", "request", "begin"])
def test_selection_phase_reentry_checks_exact_reservation_before_decrypt(registry, monkeypatch, owner, damage):
    target = seed(registry); request = str(uuid4())
    candidate = prepare(registry, "activate", target, request_id=request) if owner == "commit" else None
    before = rows(registry); opens = []
    class ChangeAfterBegin(sqlite3.Connection):
        commits = 0
        def commit(self):
            self.commits += 1
            super().commit()
            if self.commits == 1:
                with closing(sqlite3.connect(registry.path)) as other, other:
                    if damage == "delete": other.execute("DELETE FROM registry_audit_reservations")
                    elif damage == "request": other.execute("UPDATE registry_audit_reservations SET request_id=?", (str(uuid4()),))
                    else: other.execute("UPDATE registry_audit SET sequence=sequence+100 WHERE sequence=(SELECT MAX(sequence) FROM registry_audit)")
    def connect():
        connection = sqlite3.connect(registry.path, factory=ChangeAfterBegin); connection.row_factory = sqlite3.Row
        return connection
    original = registry._open
    def opened(row): opens.append(row["record_id"]); return original(row)
    monkeypatch.setattr(registry, "_connect", connect); monkeypatch.setattr(registry, "_open", opened)
    with pytest.raises(RegistryAuditError):
        if owner == "prepare": prepare(registry, "activate", target, request_id=request)
        else: registry.commit_prepared_transition(candidate)
    assert opens == [] and rows(registry) == before


@pytest.mark.parametrize("phase", ["begin", "terminal"])
@pytest.mark.parametrize("persisted", [False, True])
def test_selection_phase_read_ack_loss_never_returns_preparation(registry, monkeypatch, phase, persisted):
    target = seed(registry); before = rows(registry); opens = []; original = registry._open
    class ReadAckLoss(sqlite3.Connection):
        commits = 0
        def commit(self):
            self.commits += 1
            if self.commits == (1 if phase == "begin" else 2):
                if persisted: super().commit()
                raise sqlite3.OperationalError("authored read ACK loss")
            return super().commit()
    def connect():
        connection = sqlite3.connect(registry.path, factory=ReadAckLoss); connection.row_factory = sqlite3.Row
        return connection
    def opened(row): opens.append(row["record_id"]); return original(row)
    monkeypatch.setattr(registry, "_connect", connect); monkeypatch.setattr(registry, "_open", opened)
    with pytest.raises(SubjectRegistryError) as caught: prepare(registry, "activate", target)
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE" and rows(registry) == before
    if phase == "begin": assert opens == []


def test_selection_phase_read_close_failure_is_safe_and_never_returns(registry, monkeypatch):
    target = seed(registry); before = rows(registry)
    class ReadCloseLoss(sqlite3.Connection):
        def close(self): super().close(); raise OSError("authored private-path close failure")
    def connect():
        connection = sqlite3.connect(registry.path, factory=ReadCloseLoss); connection.row_factory = sqlite3.Row
        return connection
    monkeypatch.setattr(registry, "_connect", connect)
    with pytest.raises(SubjectRegistryError) as caught: prepare(registry, "activate", target)
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE"
    assert "private-path" not in str(caught.value) and rows(registry) == before


@pytest.mark.parametrize("owner", ["prepare", "commit"])
def test_selection_phase_failed_access_uses_new_live_pointer_scope(registry, monkeypatch, owner):
    selected = seed(registry, "selected", active=True)
    target = seed(registry, "target"); next_selected = seed(registry, "new-selected")
    request = str(uuid4()); candidate = prepare(registry, "bind", target, request_id=request) if owner == "commit" else None
    # Prepare exact authored replacement bytes before fault injection; the
    # outside writer moves selection only after the protected transaction rolls back.
    selected.update(lifecycle="DATA_ADMITTED", version=2)
    next_selected.update(lifecycle="ACTIVE", version=2)
    replacements = [(item, *registry._seal(item["twin_id"], item)) for item in (selected, next_selected)]
    external_after = []; open_counts = []; original_open = registry._open
    class MoveAfterRollback(sqlite3.Connection):
        moved = False
        def rollback(self):
            super().rollback()
            if not self.moved:
                self.moved = True
                with closing(sqlite3.connect(registry.path)) as other, other:
                    for item, nonce, encrypted in replacements:
                        other.execute("UPDATE records SET lifecycle=?,version=?,nonce=?,ciphertext=? WHERE record_id=?", (item["lifecycle"], item["version"], nonce, encrypted, item["twin_id"]))
                    other.execute("UPDATE registry_state SET state_value=? WHERE state_key='active_twin_id'", (next_selected["twin_id"],))
                external_after.append(rows(registry))
    def connect():
        connection = sqlite3.connect(registry.path, factory=MoveAfterRollback); connection.row_factory = sqlite3.Row
        return connection
    def opened(row): open_counts.append(row["record_id"]); return original_open(row)
    original_finish = registry.audit.finish
    def finish(connection, reservation, *, outcome_code):
        if outcome_code == "SUCCESS": raise SubjectRegistryError("TWIN_VERSION_CONFLICT", "Authored primary error")
        return original_finish(connection, reservation, outcome_code=outcome_code)
    # This trigger is reached only on reserved failure completion, after the
    # outside writer's real change. The current row is not in the old read set.
    with closing(registry._connect()) as connection, connection:
        connection.execute("CREATE TRIGGER authored_failure_live_pointer AFTER INSERT ON registry_audit WHEN EXISTS(SELECT 1 FROM registry_audit_reservations) BEGIN UPDATE records SET version=999 WHERE record_id=(SELECT state_value FROM registry_state WHERE state_key='active_twin_id'); END")
    monkeypatch.setattr(registry, "_connect", connect); monkeypatch.setattr(registry, "_open", opened)
    monkeypatch.setattr(registry.audit, "finish", finish)
    with pytest.raises(SubjectRegistryError) as caught:
        if owner == "prepare": prepare(registry, "bind", target, request_id=request)
        else: registry.commit_prepared_transition(candidate)
    assert caught.value.code == "TWIN_VERSION_CONFLICT" and str(caught.value) == "Authored primary error"
    assert len(external_after) == 1 and rows(registry) == external_after[0]
    assert len(open_counts) == 2  # Failure auditing performs no clinical decrypt.
    assert [event[2]["outcome_code"] for event in events(registry, request)].count("ACCESS_FAILED") == 0
    with closing(sqlite3.connect(registry.path)) as connection:
        assert connection.execute("SELECT COUNT(*) FROM registry_audit_reservations WHERE request_id=?", (request,)).fetchone()[0] == 1


@pytest.mark.parametrize("owner", ["prepare", "commit"])
def test_selection_phase_absent_pointer_cannot_be_created_by_begin(registry, owner):
    target = seed(registry); candidate = prepare(registry, "bind", target) if owner == "commit" else None
    before = rows(registry)
    install_audit_trigger(registry, "AFTER INSERT", f"INSERT INTO registry_state VALUES('active_twin_id','{target['twin_id']}','{CAPTURED}'); UPDATE records SET lifecycle='ACTIVE' WHERE record_id='{target['twin_id']}';", table="registry_audit_reservations", condition=False)
    with pytest.raises((SubjectRegistryError, RegistryAuditError)):
        if owner == "prepare": prepare(registry, "bind", target)
        else: registry.commit_prepared_transition(candidate)
    assert rows(registry) == before


@pytest.mark.parametrize("kind", ["activate", "bind", "clear_for_preview"])
def test_selection_phase_preparations_use_fixed_read_owner_not_legacy_audited(registry, monkeypatch, kind):
    target = seed(registry, active=True)
    monkeypatch.setattr(registry, "_audited", lambda *_a, **_k: pytest.fail("transition used unchecked audited owner"))
    candidate = prepare(registry, kind, target)
    assert candidate.kind == kind


def test_selection_phase_read_rollback_uncertainty_stops_failure_completion(registry, monkeypatch):
    target = seed(registry); attempts = []
    class UnknownRollback(sqlite3.Connection):
        def rollback(self): raise OSError("authored rollback uncertainty")
    def connect():
        connection = sqlite3.connect(registry.path, factory=UnknownRollback); connection.row_factory = sqlite3.Row
        return connection
    def finish(*_args, outcome_code):
        attempts.append(outcome_code)
        raise SubjectRegistryError("TWIN_VERSION_CONFLICT", "Authored primary error")
    monkeypatch.setattr(registry, "_connect", connect); monkeypatch.setattr(registry.audit, "finish", finish)
    with pytest.raises(SubjectRegistryError) as caught: prepare(registry, "activate", target)
    assert caught.value.code == "SELECTION_COMMIT_UNCONFIRMED"
    assert attempts == ["SUCCESS"]


@pytest.mark.parametrize("bad_pointer", ["x" * 129, "twin with space", 42])
def test_selection_phase_malformed_pointer_never_drives_unbounded_lookup(registry, monkeypatch, bad_pointer):
    seed(registry, active=True)
    # SQLite's affinity converts integer42 to '42', itself a bounded identifier;
    # use a BLOB to represent invalid typed metadata in that third case.
    stored = sqlite3.Binary(b"42") if bad_pointer == 42 else bad_pointer
    with closing(registry._connect()) as connection, connection:
        connection.execute("UPDATE registry_state SET state_value=? WHERE state_key='active_twin_id'", (stored,))
    before = rows(registry); audit_calls = []
    original_begin = registry.audit.begin
    def begin(*args, **kwargs): audit_calls.append(1); return original_begin(*args, **kwargs)
    monkeypatch.setattr(registry.audit, "begin", begin)
    monkeypatch.setattr(registry, "_open", lambda *_a: pytest.fail("malformed pointer decrypted clinical data"))
    with pytest.raises(SubjectRegistryError) as caught: prepare(registry, "clear_for_preview")
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE"
    assert audit_calls == [] and rows(registry) == before


@pytest.mark.parametrize("value", [1, MAX_SAFE_INTEGER - 1, MAX_SAFE_INTEGER])
def test_stored_version_read_validator_accepts_exact_inclusive_integer_domain(value):
    assert subjects._transition_read_version(value) is None


@pytest.mark.parametrize("value", [True, False, 1.0, "1", None, 0, -1, MAX_SAFE_INTEGER + 1])
def test_stored_version_read_validator_rejects_coercion_and_out_of_domain(value):
    with pytest.raises(SubjectRegistryError) as caught: subjects._transition_read_version(value)
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE"


@pytest.mark.parametrize("human", [False, True])
def test_stored_version_maximum_selected_read_is_audited_without_rewrite(registry, monkeypatch, human):
    record = seed(registry, active=True, human=human, version=MAX_SAFE_INTEGER)
    before = rows(registry); request_id = str(uuid4()); opened = []; original = registry._open
    def checked(row):
        current = events(registry, request_id)
        assert len(current) == 1 and current[0][2]["outcome_code"] is None
        opened.append(row["record_id"])
        return original(row)
    monkeypatch.setattr(registry, "_open", checked)
    with registry._selection_read_access(target_id=None, device_fingerprint=None,
            request_id=request_id, action="inspect", schema="livemore.subject-access-audit.v1") as (connection, token):
        saved, encoded, pointer, device = registry._transition_snapshot(connection, None, None)
        assert connection.in_transaction and type(token) is str and token
        assert saved == tuple(before["records"]) and json.loads(encoded) == {record["twin_id"]: record}
        assert pointer == next(row for row in before["registry_state"] if row[0] == "active_twin_id")
        assert device is None
    assert opened == [record["twin_id"]] and rows(registry) == before
    assert [event[2]["outcome_code"] for event in events(registry, request_id)] == [None, "SUCCESS"]


@pytest.mark.parametrize("mode", ["virtual", "replay"])
def test_stored_version_maximum_unchanged_active_does_not_block_other_binding(registry, mode):
    selected = seed(registry, "selected-max", active=True, human=True, version=MAX_SAFE_INTEGER)
    target = seed(registry, "bind-target")
    with closing(registry._connect()) as connection, connection:
        connection.execute("INSERT INTO physical_device_bindings VALUES(?,?,?)", (registry._fingerprint("technical-device"), selected["twin_id"], CAPTURED))
    before = rows(registry)
    prepared = registry.prepare_patch_binding(target["twin_id"], {"device_id": "technical-device", "mode": mode},
                                             expected_version=1, request_id=str(uuid4()))
    assert not prepared.selected and prepared.active_before == selected
    assert registry.commit_prepared_transition(prepared) == "COMMITTED"
    after = rows(registry)
    before_records, after_records = ({row[0]: row for row in value["records"]} for value in (before, after))
    assert before_records[selected["twin_id"]] == after_records[selected["twin_id"]]
    assert after_records[target["twin_id"]][4] == 2
    assert all(before[table] == after[table] for table in ("registry_state", "subject_identifiers", "physical_device_bindings"))
    with pytest.raises(SubjectRegistryError): registry.commit_prepared_transition(prepared)
    assert rows(registry) == after


@pytest.mark.parametrize("kind", ["activate", "bind"])
def test_stored_version_maximum_expected_target_still_rejects_before_io(registry, monkeypatch, kind):
    monkeypatch.setattr(registry, "_connect", lambda: pytest.fail("MAX mutation precondition reached storage"))
    with pytest.raises(SubjectRegistryError) as caught:
        if kind == "activate": registry.activate_twin("twin-max", expected_version=MAX_SAFE_INTEGER)
        else: registry.bind_patch("twin-max", {"device_id": "technical"}, expected_version=MAX_SAFE_INTEGER)
    assert caught.value.code == "TWIN_VERSION_CONFLICT"


@pytest.mark.parametrize("kind", ["activate", "clear_for_preview"])
def test_stored_version_maximum_demoted_row_rejects_without_mutation(registry, kind):
    selected = seed(registry, "selected-max", active=True, version=MAX_SAFE_INTEGER)
    target = seed(registry, "target")
    before = rows(registry)
    with pytest.raises(SubjectRegistryError): prepare(registry, kind, target)
    assert rows(registry) == before
    # The transformation itself must enforce incrementability even when its
    # input was already admitted by the independent inclusive stored reader.
    pointer = ("active_twin_id", selected["twin_id"], CAPTURED)
    with pytest.raises(SubjectRegistryError):
        subjects._transition_changes(kind, {selected["twin_id"]: selected, target["twin_id"]: target},
                                     pointer, None, target["twin_id"] if kind == "activate" else None,
                                     None, CAPTURED)


@pytest.mark.parametrize("damage", ["sql_max_payload_one", "sql_one_payload_max", "max_source_mismatch"])
def test_stored_version_inclusive_read_still_requires_authenticated_index_coherence(registry, damage):
    record = seed(registry, active=True, version=MAX_SAFE_INTEGER if damage != "sql_max_payload_one" else 1)
    with closing(registry._connect()) as connection, connection:
        if damage == "sql_max_payload_one": connection.execute("UPDATE records SET version=?", (MAX_SAFE_INTEGER,))
        elif damage == "sql_one_payload_max": connection.execute("UPDATE records SET version=1")
        else: connection.execute("UPDATE records SET source_class='REAL_HUMAN'")
    before = rows(registry)
    with pytest.raises(SubjectRegistryError) as caught:
        with registry._selection_read_access(target_id=None, device_fingerprint=None,
                request_id=str(uuid4()), action="inspect", schema="livemore.subject-access-audit.v1") as (connection, _token):
            registry._transition_snapshot(connection, None, None)
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE" and rows(registry) == before
