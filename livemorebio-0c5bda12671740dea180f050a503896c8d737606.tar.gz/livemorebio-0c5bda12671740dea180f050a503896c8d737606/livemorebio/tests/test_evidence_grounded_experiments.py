"""Evidence-grounded profile, cohort, and Cendos protocol contracts."""
from __future__ import annotations

from pathlib import Path
import base64
from concurrent.futures import ThreadPoolExecutor
import uuid

import pytest
from fastapi.testclient import TestClient


REFERENCE_SOURCE = {
    "source_id": "livemore-public-metabolic-reference-v1",
    "role": "population_reference",
}


def _real_human_bundle() -> dict:
    return {
        "source_class": "REAL_HUMAN",
        "subject_id": "pseudonym-profile-001",
        "display_label": "Participant profile fixture",
        "consent_scope": ["digital_twin", "life_patch", "cendos_validation"],
        "chain_of_custody": "ehr-import:fixture:2026-08-31",
        "demographics": {"age": 59, "sex": "F"},
        "conditions": ["type 2 diabetes"],
        "medications": [{"name": "metformin", "status": "active"}],
        "lifestyle": {"activity_index": 0.42, "smoking_status": "never"},
        "environment": {"region_code": "US-CA", "air_quality_context": "urban"},
        "genome": {"SLC22A1_lof": 0},
        "observations": {
            "glucose_mgdl": {
                "value": 146.0,
                "unit": "mg/dL",
                "captured_at": "2026-08-31T12:00:00Z",
                "source": "ehr-observation-fixture",
                "quality_status": "verified",
            },
        },
        "profile_sources": [
            {
                "source_id": "ehr-fixture-001",
                "kind": "FHIR_R4",
                "system": "EHR",
                "release": "R4",
                "captured_at": "2026-08-31T12:00:00Z",
                "provenance_uri": "urn:fixture:fhir-r4-bundle",
                "quality_status": "verified",
                "domains": ["demographics", "conditions", "medications", "labs"],
            },
            {
                "source_id": "wearable-fixture-001",
                "kind": "WEARABLE",
                "system": "patient_device",
                "release": "fixture-v1",
                "captured_at": "2026-08-31T12:00:00Z",
                "provenance_uri": "urn:fixture:wearable-session",
                "quality_status": "verified",
                "domains": ["physiology", "lifestyle"],
            },
            {
                "source_id": "genomic-fixture-001",
                "kind": "GENOMIC",
                "system": "consented_assay",
                "release": "fixture-v1",
                "captured_at": "2026-08-31T12:00:00Z",
                "provenance_uri": "urn:fixture:genomic-assay",
                "quality_status": "verified",
                "domains": ["genomics"],
            },
            {
                "source_id": "exposure-fixture-001",
                "kind": "ENVIRONMENT",
                "system": "exposure_context",
                "release": "fixture-v1",
                "captured_at": "2026-08-31T12:00:00Z",
                "provenance_uri": "urn:fixture:regional-exposure",
                "quality_status": "not_assessed",
                "domains": ["environment"],
            },
        ],
    }


def test_real_human_profile_carries_domain_and_field_provenance(tmp_path: Path):
    from livemorebio.aegle.subjects import SubjectRegistry

    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"p" * 32)
    twin = registry.create_twin(_real_human_bundle())

    assert twin["profile_coverage"]["status"] == "ADMITTED_COMPLETE"
    assert set(twin["profile_coverage"]["domains"]) >= {
        "demographics", "conditions", "medications", "labs", "physiology",
        "lifestyle", "environment",
    }
    assert twin["field_provenance"]["observations.glucose_mgdl"]["evidence_class"] == "MEASURED_CLINICAL"
    assert twin["field_provenance"]["medications.0.name"]["source_id"] == "ehr-fixture-001"
    assert twin["environment"]["region_code"] == "US-CA"
    assert "latitude" not in twin["environment"]


def test_real_human_demographics_are_not_silently_defaulted(tmp_path: Path):
    from livemorebio.aegle.subjects import SubjectRegistry, SubjectRegistryError

    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"p" * 32)
    body = _real_human_bundle()
    body["demographics"] = {"sex": "F"}

    with pytest.raises(SubjectRegistryError) as caught:
        registry.create_twin(body)

    assert caught.value.code == "PROFILE_COVERAGE_INSUFFICIENT"


def test_declared_source_domain_without_admitted_fields_does_not_complete_profile(tmp_path: Path):
    from livemorebio.aegle.subjects import SubjectRegistry
    from livemorebio.aegle.model_contexts import ModelContextError

    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"p" * 32)
    body = _real_human_bundle()
    body.pop("genome")
    twin = registry.create_twin(body)

    assert twin["profile_coverage"]["status"] == "ADMITTED_PARTIAL"
    assert "genomics" in twin["profile_coverage"]["declared_domains"]
    assert "genomics" not in twin["profile_coverage"]["actual_domains"]
    before = registry.get_twin(twin["twin_id"])
    assert registry.active_twin() is None
    with pytest.raises(ModelContextError) as caught:
        registry.activate_twin(twin["twin_id"], expected_version=twin["version"])
    assert caught.value.code == "MODEL_BINDING_REQUIRED"
    assert registry.get_twin(twin["twin_id"]) == before
    assert registry.active_twin() is None


def test_reference_source_metadata_is_server_owned(tmp_path: Path):
    from livemorebio.aegle.subjects import SubjectRegistry, SubjectRegistryError

    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"p" * 32)
    with pytest.raises(SubjectRegistryError) as caught:
        registry.create_cohort({
            "source_class": "REFERENCE_GROUNDED_SYNTHETIC",
            "name": "Tampered source fixture",
            "size": 4,
            "seed": 9,
            "indication": "metabolic-research",
            "stratum": "dpp-high-risk-metabolic",
            "reference_source": {**REFERENCE_SOURCE, "population": "caller invented population"},
        })
    assert caught.value.code == "REFERENCE_SOURCE_METADATA_MISMATCH"


def test_single_reference_twin_is_generated_from_manifest_not_typed_biology(tmp_path: Path):
    from livemorebio.aegle.subjects import SubjectRegistry

    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"p" * 32)
    twin = registry.create_twin({
        "source_class": "REFERENCE_GROUNDED_SYNTHETIC",
        "subject_id": "pseudonym-reference-person-001",
        "display_label": "Manifest initialized person",
        "seed": 41,
        "stratum": "dpp-high-risk-metabolic",
        "reference_source": REFERENCE_SOURCE,
        "demographics": {"age": 120, "sex": "U"},
        "model_parameters": {"Gb": 999},
    })

    assert twin["profile_coverage"]["status"] == "REFERENCE_INITIALIZED"
    assert twin["reference_source"]["source_id"] == REFERENCE_SOURCE["source_id"]
    assert twin["demographics"]["age"] != 120
    assert twin["model_parameters"]["Gb"] != 999
    assert twin["reference_lineage"]["parameter_provenance"]["Si"] == "bounded mechanistic model prior"


def test_reference_cohort_is_deterministic_heterogeneous_and_source_bound(tmp_path: Path):
    from livemorebio.aegle.subjects import SubjectRegistry

    first_registry = SubjectRegistry(tmp_path / "first.sqlite3", key=b"p" * 32)
    second_registry = SubjectRegistry(tmp_path / "second.sqlite3", key=b"p" * 32)
    payload = {
        "source_class": "REFERENCE_GROUNDED_SYNTHETIC",
        "name": "T2D preserved OCT1 cohort",
        "size": 12,
        "seed": 1701,
        "indication": "type-2-diabetes",
        "stratum": "dpp-high-risk-metabolic",
        "reference_source": REFERENCE_SOURCE,
    }

    first = first_registry.create_cohort(payload)
    second = second_registry.create_cohort(payload)

    assert first["source_class"] == "REFERENCE_GROUNDED_SYNTHETIC"
    assert first["members"] == second["members"]
    assert len(first["members"]) == 12
    assert len({member["member_id"] for member in first["members"]}) == 12
    assert len({(member["age"], member["sex"], member["model_parameters"]["Gb"])
                for member in first["members"]}) > 3
    assert first["heterogeneity"]["unique_profiles"] == 12
    assert first["reference_source"]["source_id"] == "livemore-public-metabolic-reference-v1"
    assert first["members"][0]["source_lineage"]["parameter_provenance"]["Si"] == "bounded mechanistic model prior"


def test_openmed_cannot_masquerade_as_population_data(tmp_path: Path):
    from livemorebio.aegle.subjects import SubjectRegistry, SubjectRegistryError

    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"p" * 32)
    with pytest.raises(SubjectRegistryError) as caught:
        registry.create_cohort({
            "source_class": "REFERENCE_GROUNDED_SYNTHETIC",
            "name": "Invalid OpenMed cohort",
            "size": 4,
            "seed": 7,
            "indication": "type-2-diabetes",
            "stratum": "dpp-high-risk-metabolic",
            "reference_source": {
                "source_id": "openmed-huggingface",
                "release": "2.2.0",
                "provenance_uri": "https://huggingface.co/OpenMed",
                "population": "not applicable",
                "role": "clinical_text_processor",
            },
        })

    assert caught.value.code == "REFERENCE_SOURCE_ROLE_INVALID"


def test_metformin_protocol_compares_two_individualized_cohorts(tmp_path: Path):
    from livemorebio.aegle.subjects import SubjectRegistry
    from livemorebio.cendos.protocols import run_metformin_cohort_comparison

    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"p" * 32)

    def cohort(name: str, stratum: str, seed: int) -> dict:
        return registry.create_cohort({
            "source_class": "REFERENCE_GROUNDED_SYNTHETIC",
            "name": name,
            "size": 10,
            "seed": seed,
            "indication": "type-2-diabetes",
            "stratum": stratum,
            "reference_source": REFERENCE_SOURCE,
        })

    high_risk = cohort("DPP high-risk", "dpp-high-risk-metabolic", 11)
    older = cohort("NHANES older diagnosed diabetes", "nhanes-diagnosed-diabetes-older", 12)
    result = run_metformin_cohort_comparison(high_risk, older, dose_mg=1000, grams=75)

    assert result["protocol_id"] == "cendos.metformin-cohort-comparison.v1"
    assert result["evidence_state"] == "MODELED_MECHANISTIC"
    assert result["qualification_state"] == "NOT_QUALIFIED"
    assert len(result["cohorts"]) == 2
    assert all(len(group["members"]) == 10 for group in result["cohorts"])
    assert all(len({row["delta_mean"] for row in group["members"]}) > 1 for group in result["cohorts"])
    assert result["cohorts"][0]["summary"]["mean_delta_glucose_mg_dL"] != result["cohorts"][1]["summary"]["mean_delta_glucose_mg_dL"]


def test_garcinoic_protocol_pins_structure_and_refuses_systemic_claim(tmp_path: Path):
    from livemorebio.aegle.subjects import SubjectRegistry
    from livemorebio.cendos.protocols import run_garcinoic_acid_pxr

    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"p" * 32)
    cohort = registry.create_cohort({
        "source_class": "REFERENCE_GROUNDED_SYNTHETIC",
        "name": "PXR research cohort",
        "size": 8,
        "seed": 48,
        "indication": "drug-drug-interaction-research",
        "stratum": "pxr-reference",
        "reference_source": REFERENCE_SOURCE,
    })
    result = run_garcinoic_acid_pxr(cohort, concentrations_um=[0.05, 0.33, 1.3, 5.0])

    assert result["protocol_id"] == "cendos.garcinoic-acid-pxr.v1"
    assert result["compound"]["form"] == "purified garcinoic acid"
    assert result["structure"]["pdb_id"] == "6P2B"
    assert result["structure"]["contact_count_4a"] == 18
    assert result["binding"]["kd_um"] == pytest.approx(0.33)
    assert result["binding"]["ec50_um"] == pytest.approx(1.3)
    assert result["target_engagement"][0]["mean_occupancy"] < result["target_engagement"][-1]["mean_occupancy"]
    assert result["downstream"]["cyp3a4_fold_induction"]["status"] == "NOT_QUANTIFIED"
    assert result["qualification_state"] == "NOT_QUALIFIED"
    assert "clinical" not in result["claims_allowed"]


def test_protocol_rejects_scientifically_incompatible_cohort(tmp_path: Path):
    from livemorebio.aegle.subjects import SubjectRegistry
    from livemorebio.cendos.protocols import run_garcinoic_acid_pxr, run_metformin_cohort_comparison

    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"p" * 32)
    metabolic = registry.create_cohort({
        "source_class": "REFERENCE_GROUNDED_SYNTHETIC", "name": "Metabolic", "size": 4,
        "seed": 2, "indication": "metabolic-research", "stratum": "dpp-high-risk-metabolic",
        "reference_source": REFERENCE_SOURCE,
    })
    pxr = registry.create_cohort({
        "source_class": "REFERENCE_GROUNDED_SYNTHETIC", "name": "PXR", "size": 4,
        "seed": 3, "indication": "ddi-research", "stratum": "pxr-reference",
        "reference_source": REFERENCE_SOURCE,
    })

    with pytest.raises(ValueError, match="PXR protocol requires"):
        run_garcinoic_acid_pxr(metabolic, concentrations_um=[1.3])
    with pytest.raises(ValueError, match="metformin protocol requires"):
        run_metformin_cohort_comparison(metabolic, pxr)


def test_cendos_protocol_api_persists_and_exports_analysis(monkeypatch, tmp_path: Path):
    token = "evidence-grounded-protocol-token"
    monkeypatch.setenv("LIVEMORE_API_TOKEN", token)
    monkeypatch.setenv(
        "LIVEMORE_PATCH_STORAGE_KEY",
        base64.urlsafe_b64encode(b"e" * 32).decode("ascii"),
    )
    monkeypatch.setenv("LIVEMORE_SUBJECT_REGISTRY", str(tmp_path / "subjects.sqlite3"))
    monkeypatch.setenv("LIVEMORE_PROTOCOL_RUNS", str(tmp_path / "protocol-runs"))
    from livemorebio.aegle import server

    monkeypatch.setattr(server, "_subject_registry_instance", None)
    monkeypatch.setattr(server, "_protocol_run_store_instance", None)
    client = TestClient(server.app)
    headers = {"Authorization": f"Bearer {token}"}

    def create(name: str, stratum: str, seed: int) -> dict:
        response = client.post("/api/cohorts", headers=headers, json={
            "source_class": "REFERENCE_GROUNDED_SYNTHETIC",
            "name": name,
            "size": 6,
            "seed": seed,
            "indication": "type-2-diabetes",
            "stratum": stratum,
            "reference_source": REFERENCE_SOURCE,
        })
        assert response.status_code == 201, response.text
        return response.json()

    first = create("DPP high-risk", "dpp-high-risk-metabolic", 31)
    second = create("NHANES older diagnosed diabetes", "nhanes-diagnosed-diabetes-older", 32)
    response = client.post(
        "/api/cendos/protocols/metformin-cohorts",
        headers=headers,
        json={"cohort_a_id": first["cohort_id"], "cohort_b_id": second["cohort_id"], "dose_mg": 1000},
    )
    assert response.status_code == 201, response.text
    result = response.json()
    run_id = result["run_id"]

    latest = client.get("/api/cendos/protocols/latest", headers=headers)
    assert latest.status_code == 200
    assert latest.json()["run_id"] == run_id
    csv_export = client.get(f"/api/cendos/protocols/{run_id}/analysis.csv", headers=headers)
    assert csv_export.status_code == 200
    assert "member_id,cohort" in csv_export.text
    notebook = client.get(f"/api/cendos/protocols/{run_id}/analysis.ipynb", headers=headers)
    assert notebook.status_code == 200
    assert notebook.json()["nbformat"] == 4
    stored = tmp_path / "protocol-runs" / f"{run_id}.json"
    assert stored.exists()
    assert stored.stat().st_mode & 0o077 == 0


def test_concurrent_protocol_saves_leave_a_valid_latest_pointer(tmp_path: Path):
    from livemorebio.cendos.protocol_runs import ProtocolRunStore

    store = ProtocolRunStore(tmp_path / "runs")
    results = [
        {"run_id": f"protocol-{uuid.uuid4().hex}", "protocol_id": "fixture", "index": index}
        for index in range(24)
    ]
    with ThreadPoolExecutor(max_workers=8) as executor:
        list(executor.map(store.save, results))

    latest = store.latest()
    assert latest in results
    assert not list((tmp_path / "runs").glob(".latest.*.tmp"))


def test_shell_exposes_both_governed_cendos_protocols():
    from livemorebio.shell import run_command

    class FakePlatform:
        mode = "attach"

        def run_metformin_cohorts(self, cohort_a_id, cohort_b_id, *, dose_mg, grams):
            assert (cohort_a_id, cohort_b_id, dose_mg, grams) == ("cohort-a", "cohort-b", 1000.0, 75.0)
            return {"run_id": "protocol-metformin", "evidence_state": "MODELED_MECHANISTIC", "qualification_state": "NOT_QUALIFIED"}

        def run_garcinoic_pxr(self, cohort_id, *, concentrations_um):
            assert cohort_id == "cohort-pxr"
            assert concentrations_um == [0.05, 0.33, 1.3, 5.0]
            return {"run_id": "protocol-garcinoic", "evidence_state": "STRUCTURE_AND_IN_VITRO_BACKED_MODEL", "qualification_state": "NOT_QUALIFIED"}

    output: list[str] = []
    run_command(FakePlatform(), "protocol metformin cohort_a=cohort-a cohort_b=cohort-b dose_mg=1000 grams=75", output.append)
    run_command(FakePlatform(), "protocol garcinoic cohort=cohort-pxr concentrations=0.05,0.33,1.3,5.0", output.append)

    transcript = "\n".join(output)
    assert "protocol-metformin" in transcript
    assert "protocol-garcinoic" in transcript
    assert "NOT_QUALIFIED" in transcript
