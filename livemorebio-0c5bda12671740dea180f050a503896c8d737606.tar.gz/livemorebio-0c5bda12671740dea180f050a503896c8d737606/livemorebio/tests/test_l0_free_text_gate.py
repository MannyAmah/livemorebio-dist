"""L0-R15 round 1: a note gets in nowhere, not even where no note is asked for.

The adversarial verifiers of part 12 put a SYNTHETIC patient-shaped note into
fields that are not note intake: the structured human builder that the release
itself recommends (Aegle ``/api/stimulate`` ``life_system`` custom, LIFE
``POST /human``, the SDK, the shell and pipelines), a LIFE Patch command
receipt, a Cendos protocol label, twin admission, research records, the search
query, telemetry custody, a workspace drug name, and LIFE ``/human`` under a
misspelled key. Each was accepted, stored or echoed.

These tests hold the two rules of ``livemorebio/clinical_note_gate.py``:
structured fields take technical values only (closed vocabularies and
grammars, closed key sets), and free text that a field keeps or echoes is
screened for the marks of a clinical note. Both refuse through the one gate,
with ``CLINICAL_NOTE_NOT_ACCEPTED`` and its reason, and never echo the value.

Every note here is SYNTHETIC: invented names and numbers, and the word
SYNTHETIC. Checks reduce to booleans with fixed messages, so a failing run
(``--show-capture=no``) logs no note text.
"""
from __future__ import annotations

import ast
import json
import logging
from pathlib import Path

import pytest

from .test_l0_clinical_note_gate import CODE, REASON, aegle, life  # noqa: F401  (fixtures)

ROOT = Path(__file__).resolve().parents[2]
NOTE = ("SYNTHETIC NOTE, not a person: Brevon Q. Taskeld, MRN SYN-7731, DOB 1971-02-09, 54F with type 2 "
        "diabetes, HbA1c 8.4%, plan: start metformin 500 mg twice daily.")
SHORT = "SYNTHETIC Brevon Taskeld MRN SYN-7731 54F T2D"
MARKERS = ("Brevon", "Taskeld", "SYN-7731", "SYNTHETIC NOTE")
WORDS = NOTE.split()
CHUNKS = [" ".join(WORDS[index:index + 4]) for index in range(0, len(WORDS), 4)]


def _clean(*texts: object, where: str = "an output") -> None:
    escaped = any(marker in str(text) for text in texts for marker in MARKERS)
    assert not escaped, f"note text escaped into {where}"


def _refusal(error: BaseException) -> None:
    typed = getattr(error, "code", None) == CODE
    assert typed, f"not the typed refusal: {type(error).__name__}"
    worded = REASON in str(error)
    assert worded, "the refusal does not give its reason in words"
    _clean(str(error), repr(error), error.args, getattr(error, "field", None), where="the refusal")


def _refused_response(response, where: str) -> None:
    status = response.status_code
    assert status == 422, f"{where}: status {status}"
    payload = response.json()
    typed = payload.get("code") == CODE and payload.get("error") == REASON
    assert typed, f"{where}: not the typed refusal"
    _clean(response.text, dict(response.headers), where=f"{where}: the response")


# ---------------------------------------------------------------- the screen

MARKED = [NOTE, SHORT, "MRN SYN-1", "M.R.N. 4417", "Мrn 4417", "M​RN 4417", "ＭＲＮ 4417",
          "dob 1971-02-09", "born 9 Feb 1971", "54F", "54/F", "54 yo", "54 y/o", "54-year-old",
          "fifty-four year old", "Mrs. Taskeld", "(555) 010-0100", "555-010-0100", "000-00-0000",
          "brevon.taskeld@example.org", "Patient: Taskeld", "pt: Taskeld", "patient name Taskeld",
          "medical record 4417", "record no 4417", "Chief complaint: thirst", "HPI", "Taskeld_MRN_SYN-7731",
          "SYNTHETIC Taskeld, 54 F"]
TECHNICAL = ["Type 2 diabetes mellitus", "Participant Cedar", "Technical synthetic API fixture",
             "2026-11-04T00:00:00Z", "twin-" + "a" * 32, "pseudonym-abc123", "mg/dL", "LMB-CUSTOM",
             "https://pubmed.ncbi.nlm.nih.gov/40472098/", "B0-EVT-target", "rapid-acting-analogue-sc",
             "Hyperglycaemia raises IKr block in the ORd model at cycle lengths 600, 857 and 1300 ms",
             "mRNA expression rose 2-fold", "a 2 M KCl wash", "dose-ranging A", "local technical fixture",
             "ehr-import:test-fixture:2026-08-30", "urn:test:authored-fixture:not-a-clinical-record",
             "SLC22A1_lof", "TCF7L2", "HbA1c target below 7%", "virtual-2.0", "patients with type 2 diabetes",
             "Independent endpoint", "cohort-fixture", "protocol-" + "b" * 32, "QUALITY_CHECK_PASSED",
             "electronic medical records were the source", "the record notes a model change",
             "risk assessment and planning", "patients aged over 40", "newborn mice", "MS spectra"]


@pytest.mark.parametrize("index", range(len(MARKED)))
def test_the_screen_refuses_every_mark_of_a_clinical_note(index):
    from livemorebio.clinical_note_gate import screen_text

    with pytest.raises(Exception) as caught:
        screen_text(MARKED[index], "technical field")
    _refusal(caught.value)
    named = caught.value.field == "technical field"
    assert named, "the refusal does not name the field"


@pytest.mark.parametrize("index", range(len(TECHNICAL)))
def test_the_screen_passes_technical_text(index):
    from livemorebio.clinical_note_gate import screen_strings, screen_text

    assert screen_text(TECHNICAL[index]) == TECHNICAL[index]
    body = {"key": [TECHNICAL[index], {"nested": TECHNICAL[index]}]}
    assert screen_strings(body) is body


# L0-R16: spellings of marks the round-1 receipt names that the screen missed in round 2. The screen
# stays a best-effort deny-list (never a gate); what it names, it catches.
CLAIMED_SPELLINGS = ["SYNTHETIC Brevon MRN7731", "SYNTHETIC Brevon DOB19710209", "SYNTHETIC Brevon SSN000000000",
                     "SYNTHETIC Brevon phone 555 010 0100", "SYNTHETIC Brevon +1 555 010 0100",
                     "SYNTHETIC Brevon 54yoF", "SYNTHETIC Brevon F/54", "SYNTHETIC seen by Dr. Taskeld",
                     "SYNTHETIC Brevon \u1d0d\u0280\u0274 SYN-7731", "SYNTHETIC Brevon D\u0585B 1971-02-09"]
STILL_TECHNICAL = ["DOBUTAMINE infusion model", "Drosophila Model", "mRNA7731 transcript", "F-statistic 54",
                   "run DR-2026-11", "assay plate 384 wells", "cycle lengths 600, 857 and 1300 ms"]


@pytest.mark.parametrize("index", range(len(CLAIMED_SPELLINGS)))
def test_the_screen_refuses_the_spellings_its_receipt_names(index):
    from livemorebio.clinical_note_gate import screen_text

    with pytest.raises(Exception) as caught:
        screen_text(CLAIMED_SPELLINGS[index], "technical field")
    _refusal(caught.value)


@pytest.mark.parametrize("index", range(len(STILL_TECHNICAL)))
def test_the_wider_marks_still_pass_technical_text(index):
    from livemorebio.clinical_note_gate import screen_text

    assert screen_text(STILL_TECHNICAL[index]) == STILL_TECHNICAL[index]


def test_the_screen_reads_a_long_string_in_linear_time():
    """Twin admission screens a body before its field bounds, so a 2 MB string must stay cheap."""
    import time

    from livemorebio.clinical_note_gate import screen_text

    for text in ("a" * 1_000_000, "a." * 500_000, "1" * 1_000_000, "Mr" + " " * 1_000_000, "@a" * 500_000):
        started = time.monotonic()
        screen_text(text)
        elapsed = time.monotonic() - started
        assert elapsed < 5, f"{elapsed:.1f} s for a technical string of {len(text)} characters"


def test_screen_strings_reads_keys_and_nested_values():
    from livemorebio.clinical_note_gate import screen_strings

    for body in ({SHORT: 1}, {"a": [{"b": (SHORT,)}]}, [1, 2.0, None, True, SHORT]):
        with pytest.raises(Exception) as caught:
            screen_strings(body)
        _refusal(caught.value)


# ---------------------------------------------------------------- structured human

STRUCTURED_CASES = {
    "conditions-note": {"conditions": [NOTE]},
    "conditions-split": {"conditions": CHUNKS},
    "conditions-unmarked-text": {"conditions": ["Brevon Taskeld"]},
    "id-note": {"id": NOTE},
    "id-short": {"id": SHORT},
    "id-name-token": {"id": "LMB-TASKELD"},
    "genome-key": {"genome": {NOTE: 1}},
    "genome-name-key": {"genome": {"Taskeld": 1}},
    "genome-dose": {"genome": {"TCF7L2": "Taskeld"}},
    "sex-note": {"sex": NOTE},
    "sex-word": {"sex": "Taskeld"},
    "conditions-not-list": {"conditions": NOTE},
}
UNKNOWN_KEYS = ["note", "Note", "NOTE", "notes", "text", "clinical_note", "note ", " note", "nоte"]
TECHNICAL_HUMAN = {"id": "LMB-CUSTOM", "age": 52, "sex": "M", "conditions": ["Type 2 diabetes mellitus"],
                   "genome": {"TCF7L2": 1}, "lifestyle": 0.5}


@pytest.mark.parametrize("case", sorted(STRUCTURED_CASES) + [f"key-{n}" for n in range(len(UNKNOWN_KEYS))])
def test_aegle_structured_preview_takes_technical_values_only(aegle, caplog, case):
    server, client = aegle
    fields = STRUCTURED_CASES.get(case) or {UNKNOWN_KEYS[int(case[4:])]: NOTE}
    caplog.set_level(logging.DEBUG)
    before = (server._state["tw"], server._state.get("subject"), list(server._workspace_actions))
    response = client.post("/api/stimulate", json={"kind": "life_system", "params": {"mode": "custom", **fields}})
    _refused_response(response, case)
    unchanged = (server._state["tw"], server._state.get("subject"), list(server._workspace_actions)) == before
    assert unchanged, "the selected state changed"
    _clean(caplog.text, where="the log")


def test_aegle_quick_previews_take_no_extra_key(aegle):
    _, client = aegle
    for mode in ("random", "t2d_apoe4", "carrier"):
        response = client.post("/api/stimulate", json={"kind": "life_system", "params": {"mode": mode, "note": NOTE}})
        _refused_response(response, mode)


def test_aegle_structured_preview_still_builds_a_technical_human(aegle):
    server, client = aegle
    response = client.post("/api/stimulate", json={"kind": "life_system", "params": {"mode": "custom", **TECHNICAL_HUMAN}})
    status = response.status_code
    assert status == 200, f"status {status}"
    human = server._state["tw"].human
    assert (human.id, human.sex, human.conditions, human.genome) == (
        "LMB-CUSTOM", "M", ["Type 2 diabetes mellitus"], {"TCF7L2": 1})


@pytest.mark.parametrize("case", sorted(STRUCTURED_CASES) + [f"key-{n}" for n in range(len(UNKNOWN_KEYS))])
def test_life_human_takes_technical_values_only(life, caplog, case):
    _, client = life
    body = STRUCTURED_CASES.get(case) or {UNKNOWN_KEYS[int(case[4:])]: NOTE}
    caplog.set_level(logging.DEBUG)
    response = client.post("/human", json=body)
    _refused_response(response, case)
    assert response.headers.get("Cache-Control") == "no-store"
    _clean(caplog.text, where="the log")


def test_life_human_still_builds_a_technical_human(life):
    _, client = life
    response = client.post("/human", json={**TECHNICAL_HUMAN, "id": "LMB-7"})
    status = response.status_code
    assert status == 200, f"status {status}"
    assert response.json()["human"]["id"] == "LMB-7"
    for body in ([], "technical"):
        status = client.post("/human", json=body).status_code
        assert status == 422, f"status {status}"


SDK_CASES = {"conditions": {"conditions": [NOTE]}, "split": {"conditions": CHUNKS},
             "hid": {"hid": NOTE}, "hid-name": {"hid": "LMB-TASKELD"}, "genome": {"genome": {NOTE: 1}},
             "sex": {"sex": NOTE}}


@pytest.mark.parametrize("case", sorted(SDK_CASES))
def test_sdk_inprocess_patient_takes_technical_values_only(monkeypatch, case):
    from livemorebio import audit
    from livemorebio.sdk import Platform

    platform = Platform(mode="inprocess")
    twin = platform._twin
    audits = []
    monkeypatch.setattr(audit, "record", lambda *a, **k: audits.append(a))
    with pytest.raises(Exception) as caught:
        platform.patient(**SDK_CASES[case])
    _refusal(caught.value)
    kept = platform._twin is twin and not audits
    assert kept, "the twin changed or the refusal was audited as a patient"


@pytest.mark.parametrize("case", sorted(SDK_CASES))
def test_sdk_attached_patient_refuses_free_text_before_any_request(monkeypatch, case):
    from .test_frozen_member_response_limits import ByteResponse, attached

    platform, calls = attached(monkeypatch, ByteResponse(b"{}"))
    with pytest.raises(Exception) as caught:
        platform.patient(**SDK_CASES[case])
    _refusal(caught.value)
    sent = len(calls)
    assert sent == 0, f"{sent} request(s) carried the free text"


def test_sdk_structured_patient_still_works_in_process():
    from livemorebio.sdk import Platform

    platform = Platform(mode="inprocess")
    platform.patient(age=52, sex="M", conditions=["Type 2 diabetes mellitus"], genome={"TCF7L2": 1}, hid="LMB-12")
    human = platform._twin.human
    assert (human.id, human.conditions) == ("LMB-12", ["Type 2 diabetes mellitus"])


@pytest.mark.parametrize("line", [f'patient conditions="{NOTE}"', f'patient sex="{SHORT}"',
                                  f'patient genome="{SHORT}"'], ids=["conditions", "sex", "genome"])
def test_pipeline_patient_line_with_free_text_is_refused(tmp_path, line):
    from livemorebio.sdk import Platform
    from livemorebio.shell import run_pipeline

    path = tmp_path / "technical.lmb"
    path.write_text(line + "\nshow state\n", encoding="utf-8")
    output = []
    run_pipeline(Platform(mode="inprocess"), str(path), out=output.append)
    refused = f"  refused [{CODE}]: {REASON}" in "\n".join(output)
    assert refused, "the pipeline did not print the typed refusal"
    _clean(output, where="the pipeline output")


def test_describe_refuses_free_text():
    from livemorebio.life_system.reference.human_builder import describe

    for text in (NOTE, "a 44 year old man with familial hypercholesterolemia"):
        with pytest.raises(Exception) as caught:
            describe(text)
        _refusal(caught.value)


# ---------------------------------------------------------------- structure

def _calls(tree: ast.AST, name: str):
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and (
                isinstance(node.func, ast.Name) and node.func.id == name
                or isinstance(node.func, ast.Attribute) and node.func.attr == name):
            yield node


def test_every_caller_input_human_passes_the_structured_admission():
    """A SyntheticHuman built from caller input must follow ``admit_structured_human`` in its function."""
    internal = {
        ("livemorebio/life_system/population.py", "generate"): "generated reference members",
        ("livemorebio/aegle/subjects.py", "build_twin"): "a record admitted (and screened) by the registry",
        ("livemorebio/life_system/extract.py", "to_synthetic_human"): "behind the clinical-note gate",
        ("trials/full_system_trial.py", "build_cohort"): "fixed technical members",
    }
    functions = (ast.FunctionDef, ast.AsyncFunctionDef)
    admitted, violations = set(), []
    files = [*sorted((ROOT / "livemorebio").rglob("*.py")), *sorted((ROOT / "trials").rglob("*.py")),
             *sorted((ROOT / "tools").rglob("*.py"))]
    for path in files:
        relative = path.relative_to(ROOT).as_posix()
        if "/tests/" in relative:
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"))
        defined = [node for node in ast.walk(tree) if isinstance(node, functions)]
        for call in _calls(tree, "SyntheticHuman"):
            enclosing = [f for f in defined if f.lineno <= call.lineno <= f.end_lineno]
            if not enclosing:
                violations.append(f"{relative}:{call.lineno} (module level)")
                continue
            inner = min(enclosing, key=lambda f: f.end_lineno - f.lineno)
            outer = max(enclosing, key=lambda f: f.end_lineno - f.lineno)
            identifier = call.args[0] if call.args else next(
                (keyword.value for keyword in call.keywords if keyword.arg == "id"), None)
            if isinstance(identifier, ast.Constant) and isinstance(identifier.value, str):
                continue  # a fixed technical preset
            if {(relative, inner.name), (relative, outer.name)} & set(internal):
                continue
            if any(admission.lineno < call.lineno for admission in _calls(outer, "admit_structured_human")):
                admitted.add(relative)
            else:
                violations.append(f"{relative}:{call.lineno} ({inner.name})")
    assert not violations, "SyntheticHuman built from caller input without the admission: " + ", ".join(violations)
    # Not vacuous: the three caller-input builders are found and admitted.
    assert {"livemorebio/aegle/server.py", "livemorebio/life_system/service.py", "livemorebio/sdk.py"} <= admitted


# ---------------------------------------------------------------- LIFE Patch

def test_command_receipt_detail_is_a_technical_code():
    from datetime import datetime, timezone

    from livemorebio.life_patch.protocol import CommandReceipt

    common = dict(command_id="command-technical-1", device_id="virtual-technical-1", status="completed",
                  received_at=datetime(2026, 11, 4, tzinfo=timezone.utc))
    for detail in (NOTE, SHORT, "Brevon Taskeld", "x" * 65):
        with pytest.raises(Exception) as caught:
            CommandReceipt(**common, detail=detail)
        _clean(str(caught.value), repr(caught.value), where="the receipt refusal")
    for detail in ("", "QUALITY_CHECK_PASSED", "sensor.fault:2"):
        assert CommandReceipt(**common, detail=detail).detail == detail


def test_patch_receipt_with_a_note_is_refused_and_never_journaled(life, tmp_path, monkeypatch):
    from livemorebio.life_patch.protocol import DeviceMode, manifest_for

    service, client = life
    monkeypatch.setenv("LIVEMORE_PATCH_JOURNAL", str(tmp_path / "patch-telemetry.jsonl"))
    monkeypatch.setitem(service._c, "patch_gateway_path", None)
    device = "virtual-technical-receipt"
    registered = client.post("/patch/devices", json=manifest_for(device, DeviceMode.VIRTUAL).to_dict())
    assert registered.status_code == 201, registered.status_code
    issued = client.post("/patch/commands", json={"device_id": device, "command": "request_quality_check",
                                                   "parameters": {}})
    assert issued.status_code == 201, issued.status_code
    receipt = {"command_id": issued.json()["command_id"], "device_id": device, "status": "completed",
               "received_at": "2026-11-04T00:00:00Z"}
    for detail in (NOTE, SHORT):
        response = client.post("/patch/commands/receipts", json={**receipt, "detail": detail})
        status = response.status_code
        assert status == 422, f"status {status}"
        _clean(response.text, where="the receipt response")
    _clean(client.get("/patch/commands").text, where="the command journal read")
    journals = "".join(path.read_text(encoding="utf-8") for path in tmp_path.glob("*.jsonl"))
    _clean(journals, where="the plaintext journal")
    accepted = client.post("/patch/commands/receipts", json={**receipt, "detail": "QUALITY_CHECK_PASSED"})
    assert accepted.status_code == 201, accepted.status_code


def test_patch_identifiers_are_screened():
    from livemorebio.life_patch.protocol import DeviceMode, manifest_for

    with pytest.raises(Exception) as caught:
        manifest_for("Taskeld_MRN_SYN-7731", DeviceMode.VIRTUAL)
    _refusal(caught.value)
    assert manifest_for("virtual-technical-7731", DeviceMode.VIRTUAL).device_id == "virtual-technical-7731"


def test_telemetry_custody_and_consent_are_screened():
    from livemorebio.life_system.service import _bounded_string_array

    for field in ("consent_scope", "chain_of_custody"):
        for value in ([SHORT], CHUNKS):
            with pytest.raises(Exception) as caught:
                _bounded_string_array(value, field)
            _refusal(caught.value)
        assert _bounded_string_array(["digital_twin", "ehr-import:test-fixture"], field)


# ---------------------------------------------------------------- Cendos

def test_cendos_protocol_labels_are_screened():
    from livemorebio.cendos import botanical_programs, insulin_protocol

    for validate, base in ((insulin_protocol.validate_spec, {"product_id": "rapid-acting-analogue-sc"}),
                           (botanical_programs.validate_spec, {"program_id": "LBHR-172"})):
        for label in (NOTE[:120], SHORT):
            with pytest.raises(Exception) as caught:
                validate({**base, "label": label})
            _refusal(caught.value)
        with pytest.raises(Exception) as caught:
            validate({**base, SHORT: 1})
        _clean(str(caught.value), repr(caught.value), where="the unknown-field refusal")
        assert validate({**base, "label": "dose-ranging A"})["label"] == "dose-ranging A"


def test_cendos_protocol_route_never_stores_a_note_label(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.cendos import service

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-free-text-token")
    monkeypatch.setenv("LIVEMORE_PROTOCOL_RUNS", str(tmp_path / "protocol-runs"))
    client = TestClient(service.app, raise_server_exceptions=False,
                        headers={"Authorization": "Bearer technical-free-text-token"})
    response = client.post("/protocols/exogenous-insulin", json={"product_id": "rapid-acting-analogue-sc",
                                                                 "cohort_size": 1, "hours": 2, "label": SHORT})
    _refused_response(response, "insulin protocol label")
    stored = "".join(path.read_text(encoding="utf-8") for path in tmp_path.rglob("*") if path.is_file())
    _clean(stored, where="the protocol run store")


# ---------------------------------------------------------------- twin admission

def _registry(tmp_path):
    from livemorebio.aegle.subjects import SubjectRegistry

    return SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"s" * 32)


SYNTHETIC_TWIN = {"source_class": "SYNTHETIC", "subject_id": "pseudonym-technical-free-text",
                  "display_label": "Technical free-text fixture", "demographics": {"age": 58, "sex": "F"},
                  "conditions": ["type 2 diabetes"], "lifestyle": 0.4}
REAL_TWIN = {"source_class": "REAL_HUMAN", "subject_id": "pseudonym-technical-real",
             "display_label": "Participant fixture", "consent_scope": ["digital_twin"],
             "chain_of_custody": "ehr-import:test-fixture:2026-08-30", "demographics": {"age": 58, "sex": "F"},
             "conditions": ["type 2 diabetes"],
             "observations": {"glucose_mgdl": {"value": 146.0, "unit": "mg/dL",
                                               "captured_at": "2026-08-30T12:00:00Z",
                                               "source": "qualified-test-fixture"}}}
TWIN_CASES = {
    "display-label": {"display_label": SHORT},
    "conditions-split": {"conditions": CHUNKS},
    "custody": {"chain_of_custody": NOTE[:256]},
    "lifestyle-text": {"lifestyle": {"activity_index": 0.4, "diet_notes": SHORT}},
    "observation-source": {"observations": {"glucose_mgdl": {**REAL_TWIN["observations"]["glucose_mgdl"],
                                                             "source": SHORT}}},
}


@pytest.mark.parametrize("source", ["SYNTHETIC", "REAL_HUMAN"])
@pytest.mark.parametrize("case", sorted(TWIN_CASES))
def test_twin_admission_refuses_a_note_in_any_field(tmp_path, source, case):
    registry = _registry(tmp_path)
    body = {**(SYNTHETIC_TWIN if source == "SYNTHETIC" else REAL_TWIN), **TWIN_CASES[case]}
    with pytest.raises(Exception) as caught:
        registry.create_twin(body)
    _refusal(caught.value)
    _clean(json.dumps(registry.list_twins()), where="the registry")


def test_twin_admission_still_admits_technical_twins(tmp_path):
    registry = _registry(tmp_path)
    assert registry.create_twin(dict(SYNTHETIC_TWIN))["display_label"] == "Technical free-text fixture"
    assert registry.create_twin(dict(REAL_TWIN))["source_class"] == "REAL_HUMAN"


def test_twin_route_answers_the_typed_refusal(aegle):
    _, client = aegle
    response = client.post("/api/twins", json={**SYNTHETIC_TWIN, "display_label": SHORT})
    _refused_response(response, "twin admission")
    _clean(client.get("/api/twins").text, where="the twin list")


# ---------------------------------------------------------------- research

def _learning(**changes):
    return {"module": "metabolic", "level": "molecular", "claim": "Technical hypothesis",
            "sources": ["https://pubmed.ncbi.nlm.nih.gov/40472098/"], "counterevidence": "Uncertain outside context",
            "test_plan": "Independent endpoint", "applicability": "Technical test only",
            "author": "fixture-operator", **changes}


def _resilience(**changes):
    operations = [{"id": op, "applicable": op == "resilience", "rationale": "Technical rationale",
                   **({"endpoint": "glucose", "unit": "mg/dL", "lower": 70, "upper": 140} if op == "resilience" else {})}
                  for op in ("driver", "memory", "repair", "homeostasis", "resilience")]
    subjects = [{"subject_id": f"subject-{n}", "profile_reference": f"profile-{n}",
                 "healthy_ranges": {"resilience": {"lower": 70, "upper": 140}}} for n in (1, 2)]
    spec = {"title": "Technical resilience", "population": "technical cohort", "operations": operations,
            "stresses": ["meal-60g"], "subjects": subjects, "followup_days": 30, "washout_days": 7,
            "p_star": 0.5, "min_subjects": 2}
    for key, value in changes.items():
        if key == "rationale":
            for operation in spec["operations"]:
                operation["rationale"] = value
        elif key == "profile_reference":
            spec["subjects"][0]["profile_reference"] = value
        else:
            spec[key] = value
    return spec


@pytest.mark.parametrize("record,changes", [
    ("learning", {"claim": NOTE}), ("learning", {"counterevidence": NOTE}), ("learning", {"test_plan": NOTE}),
    ("learning", {"applicability": NOTE}), ("learning", {"author": SHORT}),
    ("resilience", {"rationale": NOTE}), ("resilience", {"population": SHORT}),
    ("resilience", {"profile_reference": SHORT}), ("resilience", {"title": SHORT}),
], ids=["claim", "counterevidence", "test-plan", "applicability", "author", "rationale", "population",
        "profile-reference", "title"])
def test_research_records_refuse_a_note(tmp_path, record, changes):
    from livemorebio.research import ResearchService, ResearchStore

    service = ResearchService(ResearchStore(tmp_path / "research.sqlite3", key=b"t" * 32))
    call = service.record_learning if record == "learning" else service.register_resilience
    payload = _learning(**changes) if record == "learning" else _resilience(**changes)
    with pytest.raises(Exception) as caught:
        call(payload)
    _refusal(caught.value)
    assert service.store.list() == []


def test_research_records_still_take_technical_text(tmp_path):
    from livemorebio.research import ResearchService, ResearchStore

    service = ResearchService(ResearchStore(tmp_path / "research.sqlite3", key=b"t" * 32))
    assert service.record_learning(_learning())["kind"] == "learning"
    assert service.register_resilience(_resilience())["kind"] == "resilience_protocol"


def test_research_route_answers_the_typed_refusal(aegle, tmp_path, monkeypatch):
    from livemorebio.aegle import research_api
    from livemorebio.research import ResearchService, ResearchStore

    _, client = aegle
    service = ResearchService(ResearchStore(tmp_path / "research.sqlite3", key=b"t" * 32))
    monkeypatch.setattr(research_api, "service", lambda: service)
    response = client.post("/api/research/learning", json=_learning(claim=NOTE))
    _refused_response(response, "research learning")
    _clean(client.get("/api/research/overview").text, where="the research overview")


# ---------------------------------------------------------------- echo routes

def test_search_refuses_a_note_and_never_echoes_its_query(aegle):
    _, client = aegle
    _refused_response(client.get("/api/search", params={"q": NOTE}), "search")
    plain = client.get("/api/search", params={"q": "insulin resistance"})
    assert plain.status_code == 200, plain.status_code
    assert "query" not in plain.json()


def test_workspace_drug_name_and_scenario_names_are_screened():
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.aegle.workspace import validate_action_input

    with pytest.raises(Exception) as caught:
        validate_action_input({"kind": "metabolic_drug", "params": {"name": SHORT}})
    _refusal(caught.value)
    twin = AegleTwin("healthy")
    for kind, params in (("food", {"name": SHORT, "grams": 50}), ("factor", {"name": SHORT, "intensity": 0.5}),
                         ("metabolic_drug", {"name": SHORT})):
        with pytest.raises(Exception) as caught:
            twin.stimulate(kind, **params)
        _refusal(caught.value)
        _clean(json.dumps(twin.applied), where="the twin's applied list")
