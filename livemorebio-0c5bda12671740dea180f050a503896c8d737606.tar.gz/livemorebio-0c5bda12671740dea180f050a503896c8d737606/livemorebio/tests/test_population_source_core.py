"""Public source tests use authored technical bytes, never participant fixtures."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import stat

import pytest

from livemorebio.aegle import population_sources as sources


@pytest.fixture
def technical_source(monkeypatch):
    payloads = {}
    artifacts = []
    for original in sources.ARTIFACTS:
        data = ("TECHNICAL FIXTURE ONLY " + original.filename).encode()
        payloads[original.url] = data
        artifacts.append(sources.SourceArtifact(original.filename, original.url,
                         hashlib.sha256(data).hexdigest(), len(data), original.columns, original.rows))
    monkeypatch.setattr(sources, "ARTIFACTS", tuple(artifacts))
    monkeypatch.setattr(sources, "_inspect_artifact", lambda artifact, data: artifact.rows)
    calls = []
    def download(artifact):
        calls.append(artifact.filename)
        return payloads[artifact.url]
    monkeypatch.setattr(sources, "_download", download)
    return payloads, calls


def test_manifest_frozen_and_public_status_no_side_effects(tmp_path):
    root = tmp_path / "source"
    first = sources.source_manifest()
    assert first["source_id"] == "nhanes-2021-2023-joint-public-v1"
    assert len(first["artifacts"]) == 14
    assert first["artifacts"]["GLU_L.xpt"]["sha256"] == "70f773ab37e3d8485341f32137e280e05b9279e5fe9b6f0362e4052d8fe9a201"
    first["source_id"] = "changed"
    assert sources.source_manifest()["source_id"] != "changed"
    assert sources.source_status(root)["state"] == "missing"
    assert not root.exists()
    assert str(root) not in json.dumps(sources.source_status(root))


def test_install_requires_statistical_use_before_io(tmp_path, monkeypatch):
    monkeypatch.setattr(sources, "_download", lambda *_: pytest.fail("network must not occur"))
    with pytest.raises(sources.PopulationSourceError) as error:
        sources.install_source(tmp_path / "absent", accepted_use="clinical_onboarding")
    assert error.value.code == "SOURCE_USE_NOT_ACCEPTED"
    assert not (tmp_path / "absent").exists()


def test_verified_private_install_is_atomic_idempotent_and_detached(tmp_path, technical_source):
    root = tmp_path / "source"
    _, calls = technical_source
    result = sources.install_source(root, accepted_use="statistical_research")
    assert result["available"] and result["state"] == "verified"
    assert len(calls) == 14
    assert str(root) not in json.dumps(result)
    assert sources.install_source(root, accepted_use="statistical_research")["available"]
    assert len(calls) == 14
    assert stat.S_IMODE(root.stat().st_mode) == 0o700
    files = sources.verified_source_files(root)
    assert len(files) == 14
    assert all(isinstance(value, bytes) for value in files.values())
    assert all(stat.S_IMODE(p.stat().st_mode) == 0o600 for p in root.rglob('*') if p.is_file())


def test_error_does_not_publish_partial_or_overwrite_existing(tmp_path, technical_source, monkeypatch):
    root = tmp_path / "source"
    sources.install_source(root, accepted_use="statistical_research")
    before = {p.name:p.read_bytes() for p in root.rglob('*.xpt')}
    target = next(root.rglob('GLU_L.xpt'))
    target.write_bytes(b"CORRUPT TECHNICAL BYTES")
    assert sources.source_status(root)["state"] == "corrupt"
    with pytest.raises(sources.PopulationSourceError):
        sources.install_source(root, accepted_use="statistical_research")
    assert target.read_bytes() == b"CORRUPT TECHNICAL BYTES"
    assert all(p.read_bytes() == before[p.name] for p in root.rglob('*.xpt') if p != target)
    monkeypatch.setattr(sources, "_download", lambda _: b"wrong-content")
    other = tmp_path / "other"
    with pytest.raises(sources.PopulationSourceError):
        sources.install_source(other, accepted_use="statistical_research")
    assert sources.source_status(other)["state"] == "missing"


def test_symlink_or_other_writable_cache_is_rejected(tmp_path, technical_source):
    target=tmp_path/'target';target.mkdir(mode=0o700)
    link=tmp_path/'link';link.symlink_to(target, target_is_directory=True)
    assert sources.source_status(link)["state"] == "unsafe"
    target.chmod(0o777)
    assert sources.source_status(target)["state"] == "unsafe"


def test_html_success_and_malformed_transport_fail_format_validation():
    artifact=next(a for a in sources.ARTIFACTS if a.filename=='GLU_L.xpt')
    with pytest.raises(sources.PopulationSourceError) as error:
        sources._inspect_artifact(artifact,b'<html>page not found</html>')
    assert error.value.code=='INVALID_SOURCE_FORMAT'


def test_no_raw_paths_in_dependency_or_parser_failure(tmp_path, technical_source, monkeypatch):
    root=tmp_path/'private-source'
    sources.install_source(root,accepted_use='statistical_research')
    monkeypatch.setattr(sources,'_inspect_artifact',lambda *_: (_ for _ in ()).throw(ValueError(str(root)+' sensitive row')))
    result=sources.source_status(root)
    assert result['available'] is False
    assert str(root) not in json.dumps(result) and 'sensitive row' not in json.dumps(result)


def test_relative_missing_cache_is_unsafe_without_creating_it(monkeypatch, tmp_path):
    monkeypatch.chdir(tmp_path)
    assert sources.source_status('relative-source')['state'] == 'unsafe'
    assert not (tmp_path/'relative-source').exists()


def test_codebook_uses_released_title_and_xpt_name_not_self_url():
    artifact=next(a for a in sources.ARTIFACTS if a.filename=='GLU_L.htm')
    # Authored fixture matching official HTML structure; contains no source rows.
    document=b'<!DOCTYPE html><html><title>GLU_L</title><h2>August 2021-August 2023 Data Documentation, Codebook, and Frequencies</h2><h4> Data File: GLU_L.xpt</h4></html>'
    assert sources._inspect_artifact(artifact,document)==0
    with pytest.raises(sources.PopulationSourceError):
        sources._inspect_artifact(artifact,document.replace(b'GLU_L',b'INS_L'))


def test_concurrent_new_root_creation_is_rechecked_not_rejected(tmp_path, technical_source, monkeypatch):
    root=tmp_path/'new-source';original=Path.mkdir;calls=[]
    def race(path,*args,**kwargs):
        if path==root and not calls:
            calls.append(True)
            original(path,mode=0o700)
        return original(path,*args,**kwargs)
    monkeypatch.setattr(Path,'mkdir',race)
    assert sources.install_source(root,accepted_use='statistical_research')['available']


def test_same_cache_concurrent_install_downloads_each_artifact_once(tmp_path, technical_source):
    from concurrent.futures import ThreadPoolExecutor
    root=tmp_path/'source'
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(lambda _:sources.install_source(root,accepted_use='statistical_research'),range(2)))
    assert all(item['available'] for item in results)
    assert len(technical_source[1])==14


def test_status_reports_pending_atomic_admission_without_waiting_for_missing_package(tmp_path, technical_source, monkeypatch):
    import threading
    from concurrent.futures import ThreadPoolExecutor
    entered=threading.Event();release=threading.Event()
    original=sources._download
    def delayed(artifact):
        entered.set();assert release.wait(5)
        return original(artifact)
    monkeypatch.setattr(sources,'_download',delayed)
    root=tmp_path/'source'
    with ThreadPoolExecutor(max_workers=1) as pool:
        install=pool.submit(sources.install_source,root,accepted_use='statistical_research')
        try:
            assert entered.wait(2)
            result=sources.source_status(root)
            assert result['state']=='busy' and result['available'] is False
        finally:
            release.set()
        assert install.result()['available']


def test_lock_receipt_and_artifact_must_remain_private_regular_files(tmp_path, technical_source):
    root=tmp_path/'source'
    sources.install_source(root,accepted_use='statistical_research')
    receipt=next(root.rglob('receipt.json'));receipt.chmod(0o644)
    assert sources.source_status(root)['state']=='unsafe'
    receipt.chmod(0o600)
    lock=root/'.source.lock';lock.chmod(0o644)
    assert sources.source_status(root)['state']=='unsafe'


def test_only_all_zero_transport_bytes_corrected_not_small_values_or_missing():
    pd = pytest.importorskip('pandas')
    tiny = 5.397605346934028e-79
    table = pd.DataFrame({'TECHNICAL': [tiny, tiny, float('nan'), 1.]})
    # SAS TS-140 p21: both 32-bit IBM words zero => IEEE zero.
    # The second raw value has a nonzero mantissa and must never be clipped.
    raw = bytes.fromhex('0000000000000000 0010000000000000 2e00000000000000 4110000000000000')
    fields = [{'name':b'TECHNICAL','ntype':'numeric','field_length':8,'npos':0}]
    sources._restore_transport_zeros(table,raw,fields,record_start=0,record_length=8)
    assert table['TECHNICAL'][0] == 0
    assert table['TECHNICAL'][1] == tiny
    assert pd.isna(table['TECHNICAL'][2])
    assert table['TECHNICAL'][3] == 1


def test_transport_zero_uses_offsets_multiple_fields_and_positional_rows():
    pd=pytest.importorskip('pandas')
    tiny=5.397605346934028e-79
    table=pd.DataFrame({'A':[tiny,1.],'LABEL':[b'\x00\x00',b'OK'],'B':[1.,tiny]},index=[10,20])
    fields=[{'name':b'A','ntype':'numeric','field_length':8,'npos':0},
            {'name':b'LABEL','ntype':'char','field_length':2,'npos':8},
            {'name':b'B','ntype':'numeric','field_length':8,'npos':10}]
    one=bytes.fromhex('4110000000000000');zero=bytes(8)
    raw=b'PREFIX'+zero+bytes(2)+one+one+b'OK'+zero
    sources._restore_transport_zeros(table,raw,fields,record_start=6,record_length=18)
    assert table['A'].tolist()==[0.,1.] and table['B'].tolist()==[1.,0.]
    assert table['LABEL'].tolist()==[b'\x00\x00',b'OK']


@pytest.mark.parametrize('width',range(2,9))
def test_transport_zero_supports_documented_truncated_numeric_widths(width):
    pd=pytest.importorskip('pandas')
    table=pd.DataFrame({'X':[1e-79,float('nan'),float('nan'),1e-79]})
    raw=bytes(width)+b'.'+bytes(width-1)+b'A'+bytes(width-1)+b'\x00\x10'+bytes(width-2)
    fields=[{'name':b'X','ntype':'numeric','field_length':width,'npos':0}]
    sources._restore_transport_zeros(table,raw,fields,record_start=0,record_length=width)
    assert table['X'][0]==0 and pd.isna(table['X'][1]) and pd.isna(table['X'][2])
    assert table['X'][3]==1e-79


@pytest.mark.parametrize('malformation',['truncated','negative_offset','overlap','wrong_order','zero_width','wide_numeric','duplicate_column','zero_record_length','negative_start'])
def test_transport_metadata_is_fully_validated_before_any_mutation(malformation):
    pd=pytest.importorskip('pandas')
    table=pd.DataFrame({'A':[1e-79],'B':[1.]});before=table.copy(deep=True)
    fields=[{'name':b'A','ntype':'numeric','field_length':8,'npos':0},
            {'name':b'B','ntype':'numeric','field_length':8,'npos':8}]
    raw=bytes(8)+bytes.fromhex('4110000000000000');start=0;length=16
    if malformation=='truncated':raw=raw[:-1]
    elif malformation=='negative_offset':fields[1]['npos']=-8
    elif malformation=='overlap':fields[1]['npos']=0
    elif malformation=='wrong_order':fields.reverse()
    elif malformation=='zero_width':fields[1]['field_length']=0
    elif malformation=='wide_numeric':fields[1]['field_length']=9
    elif malformation=='duplicate_column':fields[1]['name']=b'A'
    elif malformation=='zero_record_length':length=0
    elif malformation=='negative_start':start=-1
    with pytest.raises(sources.PopulationSourceError):
        sources._restore_transport_zeros(table,raw,fields,record_start=start,record_length=length)
    pd.testing.assert_frame_equal(table,before)


def test_real_parser_entry_point_invokes_raw_byte_restoration(monkeypatch):
    pd=pytest.importorskip('pandas')
    tiny=5.397605346934028e-79
    header=b'HEADER RECORD*******LIBRARY HEADER RECORD!!!!!!!'
    raw=header+bytes.fromhex('4110000000000000')+bytes(8)
    artifact=sources.SourceArtifact('TEST.xpt','https://example.invalid/never-fetched','unused',len(raw),('SEQN','TECHNICAL'),1)
    class Reader:
        record_start=len(header);record_length=16
        fields=[{'name':b'SEQN','ntype':'numeric','field_length':8,'npos':0},
                {'name':b'TECHNICAL','ntype':'numeric','field_length':8,'npos':8}]
        def __enter__(self):return self
        def __exit__(self,*_):pass
        def read(self):return pd.DataFrame({'SEQN':[1.],'TECHNICAL':[tiny]})
    def parser(*args,**kwargs):
        return Reader() if kwargs.get('iterator') else Reader().read()
    monkeypatch.setattr(pd,'read_sas',parser)
    assert sources._parse_xpt(artifact,raw)['TECHNICAL'][0]==0
