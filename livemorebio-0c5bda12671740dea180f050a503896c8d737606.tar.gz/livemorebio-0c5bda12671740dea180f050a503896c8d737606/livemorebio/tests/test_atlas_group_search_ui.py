"""Declared Atlas group search through the actual controller; no GPU or I/O."""
from __future__ import annotations

import json

from .test_atlas_reference_ui import CONSOLE, node
from .test_atlas_view_status import controller


def check(code: str) -> None:
    setup = """
const list=host.querySelector('[data-results]');let index=-1;
Object.defineProperties(list,{selectedIndex:{get:()=>index,set:v=>{index=v}},value:{get:()=>list.children[index]?.value||'',set:v=>{index=list.children.findIndex(o=>o.value===v)}}});
const query=value=>{host.querySelector('[data-search]').value=value;host.querySelector('[data-search]').handlers.input()};
const ids=()=>list.options.map(option=>option.value);
const count=()=>host.querySelector('[data-search-count]').textContent;
const equal=(a,b,message)=>{if(JSON.stringify(a)!==JSON.stringify(b))throw Error(message)};
const groupMembers=key=>{const group=manifest.groups.find(group=>group.asset_key===key);return manifest.members.filter(member=>group.element_ids.includes(member.element_id))};
const heart=groupMembers('heart');
if(heart.length!==83||manifest.members.length!==489)throw Error('declared fixture coverage changed');
"""
    assert node(controller(setup + code)).strip() == "ok"


def test_heart_matches_only_declared_members_with_cap_and_no_state_change():
    check("""
const before=JSON.stringify(manifest),view=scene.view();query('heart');
equal(ids(),heart.slice(0,30).map(member=>member.element_id),'heart membership/order/cap');
if(count()!=='83 matches · first 30 shown; refine your search')throw Error('wrong heart count');
if(list.value!==''||list.options.some(option=>option.disabled))throw Error('search selected or disabled ready member');
if(JSON.stringify(manifest)!==before||posts!==0)throw Error('search mutated source or installed');
equal(scene.view(),view,'search changed view');
""")


def test_group_fma_matches_exact_heart_members_not_a_synthetic_organ():
    check("""
query('FMA7088');
equal(ids(),heart.slice(0,30).map(member=>member.element_id),'group FMA membership');
if(count()!=='83 matches · first 30 shown; refine your search')throw Error('group FMA count');
for(const option of list.options){const member=heart.find(member=>member.element_id===option.value);if(!member||option.textContent!==`${member.name} · ${member.element_id}`)throw Error('invented organ option');}
""")


def test_group_search_preserves_trim_and_case_normalization():
    check("""
query('  HeArT  ');
equal(ids(),heart.slice(0,30).map(member=>member.element_id),'group normalization');
if(!count().startsWith('83 matches'))throw Error('normalized count');
""")


def test_declared_group_key_and_source_label_keep_exact_kidney_membership():
    check("""
const group=manifest.groups.find(group=>group.asset_key==='right-kidney');
if(typeof group.label_from_source!=='string')throw Error('source label fixture missing');
const expected=groupMembers(group.asset_key).map(member=>member.element_id);
if(expected.length!==1)throw Error('kidney fixture membership');
for(const term of [group.asset_key,group.label_from_source]){query(term);equal(ids(),expected,'kidney key/label membership');if(count()!=='1 matches')throw Error('kidney count');}
""")


def test_exact_fj_selection_retains_member_identity_and_part_of_source_card():
    check("""
const member=manifest.members.find(member=>member.element_id==='FJ2417'),before=JSON.stringify(manifest);
query(member.element_id);equal(ids(),[member.element_id],'exact FJ query');
list.value=member.element_id;list.handlers.change();
if(scene.view().selected!==member.element_id)throw Error('selection replaced with group');
const text=host.querySelector('[data-selection]').textContent;
for(const value of [member.name,member.element_id,member.concept_id,member.source_sha256,'PART-OF FMA7088 · heart','Reference geometry only'])if(!text.includes(value))throw Error('source identity lost '+value);
if(JSON.stringify(manifest)!==before||posts!==0)throw Error('selection mutated source');
""")


def test_literal_member_name_preserves_eleven_ventricle_matches_and_order():
    check("""
const expected=manifest.members.filter(member=>`${member.name} ${member.element_id} ${member.concept_id}`.toLowerCase().includes('ventricle')).map(member=>member.element_id);
if(expected.length!==11)throw Error('literal fixture count');
query('ventricle');equal(ids(),expected,'literal search broadened to whole groups');
if(count()!=='11 matches')throw Error('literal count');
""")


def test_unknown_query_does_not_infer_anatomy_or_clear_current_scene_selection():
    check("""
scene.select('FJ2417');const view=scene.view();query('no-such-anatomical-source');
equal(ids(),[],'unknown query invented results');
if(count()!=='0 matches'||list.value!=='')throw Error('unknown query feedback');
equal(scene.view(),view,'unknown query changed current selection/view');
""")


def test_clear_input_event_restores_exact_help_without_listing_all_members():
    check("""
scene.select('FJ2417');const view=scene.view();
for(const empty of ['', '   ']){query('FJ2417');if(list.options.length!==1)throw Error('populated precondition');query(empty);equal(ids(),[],'blank lists all members');if(count()!=='Search the admitted reference; this is not a list of patient findings.')throw Error('clear help absent');equal(scene.view(),view,'clear changed view');}
""")


def test_unloaded_heart_results_remain_counted_but_disabled():
    check("""
failedAssets.add('heart');click('[data-retry]');await flush();
if(host.dataset.referenceState!=='partial'||host.dataset.loadedGroups!=='8')throw Error('partial fixture not reached');
const view=scene.view();query('heart');
equal(ids(),heart.slice(0,30).map(member=>member.element_id),'unloaded group membership');
if(!count().startsWith('83 matches')||list.options.length!==30||list.options.some(option=>!option.disabled))throw Error('unloaded members enabled or omitted');
equal(scene.view(),view,'unloaded query changed selection');
""")


def test_missing_group_remains_a_strict_manifest_admission_failure():
    module = json.dumps((CONSOLE / "lib/atlas_reference_contract.js").as_uri())
    check(f"""
const {{validateAtlasManifest}}=await import({module});
const bad=structuredClone(manifest);bad.groups.splice(1,1);let rejected=false;
try{{validateAtlasManifest(bad,'a'.repeat(64))}}catch{{rejected=true}}
if(!rejected)throw Error('missing group admitted for search');
""")


def test_unknown_group_remains_a_strict_manifest_admission_failure():
    module = json.dumps((CONSOLE / "lib/atlas_reference_contract.js").as_uri())
    check(f"""
const {{validateAtlasManifest}}=await import({module});
const bad=structuredClone(manifest);bad.groups[1].asset_key='invented-heart';let rejected=false;
try{{validateAtlasManifest(bad,'a'.repeat(64))}}catch{{rejected=true}}
if(!rejected)throw Error('unknown group admitted for search');
""")


def test_search_markup_describes_element_and_layer_terms_without_scope_change():
    check("""
for(const text of ['placeholder="Element or layer name, FJ or FMA ID"','Find an anatomical source element','aria-label="Matching reference elements"','maxlength="120"'])if(!host.innerHTML.includes(text))throw Error('search markup missing '+text);
""")
