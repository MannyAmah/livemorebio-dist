"""API-7/DEP-10/PHI-8: technical ASGI fixtures; never opens a listening socket."""
from pathlib import Path
import importlib

import pytest
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.testclient import TestClient
from livemorebio.security import install_mutation_auth


def technical_app():
    app = FastAPI()
    install_mutation_auth(app)

    @app.get('/')
    def page():
        return HTMLResponse('<p>Technical fixture</p>')

    @app.get('/api/technical')
    def data():
        return {'technical': True}

    @app.get('/api/failure')
    def failure():
        raise ValueError('technical fixture error')

    @app.post('/api/mutation')
    def mutation():
        return {'technical': True}
    return app


@pytest.mark.parametrize('path', ['/', '/api/technical', '/api/failure', '/missing'])
@pytest.mark.parametrize('header,expected', [
    ('x-content-type-options', 'nosniff'),
    ('referrer-policy', 'no-referrer'),
    ('x-frame-options', 'DENY'),
])
def test_API_7_headers_on_pages_api_errors_and_not_found(path, header, expected):
    response = TestClient(technical_app(), base_url='http://127.0.0.1:19866').get(path)
    assert response.headers.get(header) == expected
    assert "frame-ancestors 'none'" in response.headers.get('content-security-policy', '')


def test_API_7_headers_on_auth_refusal(monkeypatch):
    monkeypatch.setenv('LIVEMORE_API_TOKEN', 'technical-token')
    response = TestClient(technical_app(), base_url='http://127.0.0.1:19866').post('/api/mutation')
    assert response.status_code == 401
    assert response.headers.get('x-content-type-options') == 'nosniff'
    assert response.headers.get('referrer-policy') == 'no-referrer'
    assert "frame-ancestors 'none'" in response.headers.get('content-security-policy', '')


@pytest.mark.parametrize('module,path', [
    ('livemorebio.aegle.server', '/'), ('livemorebio.aegle.server', '/api/system-manifest'),
    ('livemorebio.life_system.service', '/population?n=1'),
    ('livemorebio.cendos.service', '/health'),
])
def test_API_7_real_services_send_headers(monkeypatch, module, path):
    token = 'technical-service-headers-token'
    monkeypatch.setenv('LIVEMORE_API_TOKEN', token)
    headers = {'Authorization': f'Bearer {token}'} if module == 'livemorebio.life_system.service' else {}
    client = TestClient(importlib.import_module(module).app, base_url='http://127.0.0.1:19866')
    response = client.get(path, headers=headers)
    assert response.status_code == 200
    assert response.headers.get('x-content-type-options') == 'nosniff'
    assert response.headers.get('referrer-policy') == 'no-referrer'
    assert response.headers.get('x-frame-options') == 'DENY'


@pytest.mark.parametrize('host', ['evil.example', '127.0.0.1.evil.example', 'localhost.evil.example', 'evil.example:19866', 'localhost@evil.example', 'localhost:bad', 'localhost/evil', 'localhost,evil.example'])
def test_API_7_foreign_or_malformed_host_refused(monkeypatch, host):
    monkeypatch.delenv('LIVEMORE_ALLOWED_HOSTS', raising=False)
    response = TestClient(technical_app(), base_url='http://127.0.0.1:19866').get('/', headers={'Host': host})
    assert response.status_code == 400
    assert response.headers.get('x-content-type-options') == 'nosniff'


@pytest.mark.parametrize('host', ['127.0.0.1:19866', 'localhost:19866', '[::1]:19866', 'LOCALHOST', 'localhost'])
def test_API_7_loopback_host_accepted(monkeypatch, host):
    monkeypatch.delenv('LIVEMORE_ALLOWED_HOSTS', raising=False)
    response = TestClient(technical_app(), base_url='http://127.0.0.1:19866').get('/', headers={'Host': host})
    assert response.status_code == 200


def test_API_7_configured_deployment_host_accepted(monkeypatch):
    monkeypatch.setenv('LIVEMORE_ALLOWED_HOSTS', 'console.example,life')
    client = TestClient(technical_app(), base_url='http://console.example:19866')
    assert client.get('/').status_code == 200
    assert client.get('/', headers={'Host': 'life:19867'}).status_code == 200
    assert client.get('/', headers={'Host': 'other.example'}).status_code == 400


def test_API_7_duplicate_host_refused():
    client = TestClient(technical_app(), base_url='http://127.0.0.1:19866')
    assert client.get('/', headers=[('Host', 'localhost'), ('Host', 'evil.example')]).status_code == 400


def test_API_7_html_policy_allows_console_local_resources():
    response = TestClient(technical_app(), base_url='http://127.0.0.1:19866').get('/')
    policy = response.headers.get('content-security-policy', '')
    for directive in ["default-src 'self'", "script-src 'self' 'unsafe-inline'", "style-src 'self' 'unsafe-inline'", "connect-src 'self'", "font-src 'self'", "object-src 'none'", "base-uri 'self'", "frame-ancestors 'none'"]:
        assert directive in policy
    assert 'https:' not in policy


def test_DEP_10_PHI_8_biology_uses_local_font_stack():
    html = (Path(__file__).parents[1] / 'aegle/console/biology.html').read_text(encoding="utf-8")
    assert 'fonts.googleapis.com' not in html
    assert 'fonts.gstatic.com' not in html
    assert 'system-ui' in html


@pytest.mark.parametrize('service', ['aegle', 'life', 'cendos'])
def test_API_7_deployed_service_admits_its_configured_compose_name(monkeypatch, service):
    monkeypatch.delenv('LIVEMORE_ALLOWED_HOSTS', raising=False)
    monkeypatch.setenv('LIVEMORE_SERVICE', service)
    client = TestClient(technical_app(), base_url=f'http://{service}:19866')
    assert client.get('/').status_code == 200
    assert client.get('/', headers={'Host': 'foreign.example'}).status_code == 400
