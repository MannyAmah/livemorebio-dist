"""Preserve the admitted parser dependency; no publisher bytes or models needed."""
from __future__ import annotations

import hashlib
import importlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from types import FunctionType
import zipfile

import pytest

from livemorebio import strict_json
from livemorebio.anatomy import atlas_reference as atlas


ROOT = Path(__file__).resolve().parents[2]
# Derived from SHA6af73cc5… admitted source with the actual Atlas serializer.
# Bytecode pins apply only to its CPython 3.11.15 runtime, not other interpreters.
PINS = {
    "_unique_object": "14a12ec60f7cc54cc6e49834eaf838ccdfbda8a608b2149e2c85eeb3d54dc8e1",
    "_finite_float": "d666fa17c4504a12667729fda2bcb6cebae9222cf4b61ef98a895fff86d44a1d",
    "_safe_integer": "00e47ca6e40159e3a0e01ebf5ddab7d2855418a16c26dee8aaf204652ed43d64",
    "_reject_constant": "d8d04334ba762394dec8d97362d36c7529a426f84ace0049c1d33edffb1a1612",
    "_check_depth": "4b2f5d5154cb9a30a370007b00b658941fbabe48e0e66d6298492b4b2fec8bdd",
    "parse_json_object": "9ca65389dec6c5a47d7a9a84820621156dbb9b821ab405b40b0bdf779ba6ca88",
}
COMBINED = "9c25469074d3de640723909ce1aa7448319e554bba69934d9d28f1c13c365e41"
EXACT_RUNTIME = sys.implementation.name == "cpython" and sys.version_info[:3] == (3, 11, 15)


def local_functions():
    return {name: value for name, value in vars(strict_json).items()
            if isinstance(value, FunctionType) and value.__module__ == strict_json.__name__}


def digest(value):
    return hashlib.sha256(atlas._canonical(value)).hexdigest()


def test_exact_six_admitted_local_functions_and_defaults():
    functions = local_functions()
    assert set(functions) == set(PINS)
    for name, function in functions.items():
        assert function.__defaults__ is None
        assert function.__kwdefaults__ == ({"max_bytes": 2_000_000} if name == "parse_json_object" else None)


@pytest.mark.skipif(not EXACT_RUNTIME, reason="Admitted loaded-code pins are CPython 3.11.15-specific")
@pytest.mark.parametrize("name", PINS)
def test_each_admitted_function_identity_is_retained(name):
    assert digest(atlas._function_identity(getattr(strict_json, name))) == PINS[name]


@pytest.mark.skipif(not EXACT_RUNTIME, reason="Admitted loaded-code pins are CPython 3.11.15-specific")
def test_combined_admitted_function_identity_is_retained():
    assert digest({name: atlas._function_identity(function) for name, function in local_functions().items()}) == COMBINED


def test_response_function_is_exact_imported_alias_not_converter_local():
    response = importlib.import_module("livemorebio.frozen_member_json")
    assert strict_json.parse_frozen_member_response is response.parse_frozen_member_response
    assert response.parse_frozen_member_response.__module__ == response.__name__
    assert "parse_frozen_member_response" not in local_functions()


def test_generic_validator_mutation_still_changes_actual_converter_identity(monkeypatch):
    before = atlas._converter_identity()["loaded_code_sha256"]

    def changed(text):
        raise RuntimeError("Technical altered validator must remain fingerprinted")

    # The existing function keeps its real module ownership; only test-owned code
    # is temporarily substituted and pytest restores it after this assertion.
    monkeypatch.setattr(strict_json._check_depth, "__code__", changed.__code__)
    assert atlas._converter_identity()["loaded_code_sha256"] != before


@pytest.mark.parametrize("name,raw", [
    ("_check_depth", b"{}"), ("_unique_object", b'{"a":1}'),
    ("_finite_float", b'{"a":1.5}'), ("_safe_integer", b'{"a":1}'),
    ("_reject_constant", b'{"a":NaN}'),
])
def test_fixed_response_uses_shared_generic_validator(name, raw, monkeypatch):
    response = importlib.import_module("livemorebio.frozen_member_json")
    original = getattr(strict_json, name)
    calls = []

    def observe(*args, **kwargs):
        calls.append(True)
        return original(*args, **kwargs)

    monkeypatch.setattr(strict_json, name, observe)
    if name == "_reject_constant":
        with pytest.raises(strict_json.StrictJSONError):
            response.parse_frozen_member_response(raw)
    else:
        result = response.parse_frozen_member_response(raw)
        assert calls, "The fixed response must use the shared validator before any generic parse"
        assert result == strict_json.parse_json_object(raw)
    assert calls


IMPORT_SCRIPT = r'''
import importlib, json, os, pathlib, socket, sys, urllib.request
root = pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root))
def denied(*args, **kwargs):
    raise AssertionError("PARSER_IMPORT_NETWORK_FORBIDDEN")
socket.socket.connect = socket.socket.connect_ex = denied
socket.create_connection = socket.getaddrinfo = denied
urllib.request.urlopen = urllib.request.OpenerDirector.open = denied
def audit(event, args):
    if event == "open":
        mode, flags = args[1:3]
        if (isinstance(mode, str) and any(x in mode for x in "wax+")) or (
            isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)
        ):
            raise AssertionError("PARSER_IMPORT_WRITE_FORBIDDEN")
sys.addaudithook(audit)
for name in sys.argv[2:]:
    importlib.import_module("livemorebio." + name)
from livemorebio import strict_json, frozen_member_json
from livemorebio.strict_json import parse_frozen_member_response
assert parse_frozen_member_response is frozen_member_json.parse_frozen_member_response
assert parse_frozen_member_response.__module__ == "livemorebio.frozen_member_json"
assert pathlib.Path(strict_json.__file__).resolve().is_relative_to(root)
assert pathlib.Path(frozen_member_json.__file__).resolve().is_relative_to(root)
assert parse_frozen_member_response(b'{"a":1}') == strict_json.parse_json_object(b'{"a":1}')
for parse in (strict_json.parse_json_object, parse_frozen_member_response):
    try:
        parse(b'{"a":1,"a":2}')
    except Exception as error:
        assert type(error) is strict_json.StrictJSONError
    else:
        raise AssertionError("Duplicate keys were accepted")
assert not {"numpy", "trimesh", "livemorebio.aegle.runtime", "livemorebio.sdk"}.intersection(sys.modules)
print(json.dumps({"alias": True, "module": parse_frozen_member_response.__module__, "shared_error": True}))
'''


def fresh_import(root, order, cwd):
    result = subprocess.run([sys.executable, "-I", "-B", "-c", IMPORT_SCRIPT, str(root), *order],
                            cwd=cwd, capture_output=True, text=True, timeout=20, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    assert json.loads(result.stdout) == {"alias": True, "module": "livemorebio.frozen_member_json", "shared_error": True}


@pytest.mark.parametrize("order", [("strict_json", "frozen_member_json"), ("frozen_member_json", "strict_json")])
def test_both_fresh_import_orders_are_private_and_side_effect_free(tmp_path, order):
    fresh_import(ROOT, order, tmp_path)


def test_private_built_wheel_contains_response_module_and_alias_outside_checkout(tmp_path):
    # Building in a private copy avoids setuptools build/egg-info writes in the
    # source-frozen checkout. No dependency resolution, pip, or network occurs.
    source = tmp_path / "source"
    source.mkdir()
    shutil.copy2(ROOT / "pyproject.toml", source / "pyproject.toml")
    shutil.copytree(ROOT / "livemorebio", source / "livemorebio",
                    ignore=shutil.ignore_patterns("__pycache__", "tests", "*.pyc"))
    wheel_dir = tmp_path / "wheel"
    wheel_dir.mkdir()
    build_script = r'''
import socket, sys, urllib.request
def denied(*args, **kwargs):
    raise AssertionError("WHEEL_BUILD_NETWORK_FORBIDDEN")
socket.socket.connect = socket.socket.connect_ex = denied
socket.create_connection = socket.getaddrinfo = denied
urllib.request.urlopen = urllib.request.OpenerDirector.open = denied
from setuptools.build_meta import build_wheel
build_wheel(sys.argv[1])
'''
    result = subprocess.run([sys.executable, "-I", "-B", "-c", build_script, str(wheel_dir)],
                            cwd=source, capture_output=True, text=True, timeout=60, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    wheel_path, = wheel_dir.glob("livemorebio-*.whl")
    installed = tmp_path / "installed"
    with zipfile.ZipFile(wheel_path) as wheel:
        assert "livemorebio/frozen_member_json.py" in wheel.namelist()
        assert wheel.read("livemorebio/strict_json.py") == (ROOT / "livemorebio/strict_json.py").read_bytes()
        assert wheel.read("livemorebio/frozen_member_json.py") == (ROOT / "livemorebio/frozen_member_json.py").read_bytes()
        wheel.extractall(installed)
    for order in (("strict_json", "frozen_member_json"), ("frozen_member_json", "strict_json")):
        fresh_import(installed, order, tmp_path)
