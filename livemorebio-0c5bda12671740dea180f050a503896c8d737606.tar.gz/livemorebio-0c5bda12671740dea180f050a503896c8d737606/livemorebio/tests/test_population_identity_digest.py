"""The reviewed-decoder gate must be deterministic and still closed.

It was neither: the digest hashed ``marshal.dumps`` output, which encodes object
sharing as back-references. Unrelated tests changed which strings were shared,
the digest moved, and the gate refused pandas' own unmodified XPORT decoder —
which failed the suite the installer runs, so a client could not install.
"""
from __future__ import annotations

import pytest

from livemorebio.aegle import population_identity as identity


def test_the_digest_is_stable_across_repeated_computation():
    first = identity._loaded_identity()
    second = identity._loaded_identity()
    assert first == second


def test_the_digest_survives_a_run_that_patches_the_population_modules():
    """The exact contamination that refused a client's install."""
    before = identity.normalization_version()
    exit_code = pytest.main(["-q", "--no-header", "-p", "no:cacheprovider",
                             "livemorebio/tests/test_population_source_core.py"])
    assert exit_code == 0
    assert identity.normalization_version() == before


def test_equal_code_objects_produce_equal_digests():
    """Two compilations of identical source must agree, which marshal did not
    guarantee once sharing differed."""
    source = "def sample(a, b=2):\n    return [a, b, 'x', (1, 2), b'y']\n"
    first, second = {}, {}
    exec(compile(source, "<one>", "exec"), first)
    exec(compile(source, "<two>", "exec"), second)
    assert identity._code_digest(identity._portable_code(first["sample"].__code__)) == \
           identity._code_digest(identity._portable_code(second["sample"].__code__))


@pytest.mark.parametrize("modified", [
    "def sample(a, b=2):\n    return [a, b, 'X', (1, 2), b'y']\n",   # a constant
    "def sample(a, b=2):\n    return [b, a, 'x', (1, 2), b'y']\n",   # the code
    "def sample(a, b=2):\n    return [a, b, 'x', (2, 1), b'y']\n",   # a nested tuple
    "def sample(a, b=2):\n    return [a, b, 'x', (1, 2), b'z']\n",   # a bytes constant
])
def test_a_changed_decoder_still_changes_the_digest(modified):
    """The gate's whole purpose: any real change must be detected."""
    original = "def sample(a, b=2):\n    return [a, b, 'x', (1, 2), b'y']\n"
    base, other = {}, {}
    exec(compile(original, "<base>", "exec"), base)
    exec(compile(modified, "<other>", "exec"), other)
    assert identity._code_digest(identity._portable_code(base["sample"].__code__)) != \
           identity._code_digest(identity._portable_code(other["sample"].__code__))


def test_an_unreviewed_decoder_is_refused_and_named(monkeypatch):
    monkeypatch.setattr(identity, "_REVIEWED_DECODERS", {})
    with pytest.raises(identity.PopulationIdentityError) as caught:
        identity.normalization_version()
    assert "no reviewed decoder" in str(caught.value)


def test_a_refusal_names_what_diverged(monkeypatch):
    """A bare 'requires review' left an operator nowhere to start."""
    monkeypatch.setitem(identity._LOADED, "normalizer_code_sha256", "0" * 64)
    with pytest.raises(identity.PopulationIdentityError) as caught:
        identity.normalization_version()
    assert "normalizer_code_sha256" in str(caught.value)


def test_a_changed_default_is_caught_by_the_function_identity():
    """Defaults live on the function object, not the code object, so the code
    digest does not see them. The gate captures them separately -- this pins
    that division so a future refactor cannot drop the defaults silently."""
    original = "def sample(a, b=2):\n    return a + b\n"
    changed = "def sample(a, b=3):\n    return a + b\n"
    base, other = {}, {}
    exec(compile(original, "<base>", "exec"), base)
    exec(compile(changed, "<other>", "exec"), other)

    assert identity._code_digest(identity._portable_code(base["sample"].__code__)) == \
           identity._code_digest(identity._portable_code(other["sample"].__code__))
    assert identity._function_identity(base["sample"]) != \
           identity._function_identity(other["sample"])
