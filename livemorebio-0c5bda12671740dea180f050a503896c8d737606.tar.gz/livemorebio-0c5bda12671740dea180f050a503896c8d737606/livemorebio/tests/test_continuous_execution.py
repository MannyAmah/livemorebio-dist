"""Red-first execution ownership tests; fixtures are never physical evidence."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
from types import SimpleNamespace
import json
import threading

import pytest


def selection(subject: str = "reference-subject-a") -> dict:
    return {
        "subject_id": subject, "twin_id": "twin-reference-a", "twin_version": 1,
        "cohort_id": None, "member_id": None, "run_id": None,
        "condition_id": "baseline", "stage": "metabolic",
        "source_data_class": "SYNTHETIC",
    }


def captured_source():
    from livemorebio.aegle.execution import capture_source_payload
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY, MetabolicProfile

    twin = SimpleNamespace(
        profile=MetabolicProfile(**asdict(HEALTHY)), meals=[(0., 75.)],
        _parameter_provenance={"Gb": {"evidence_class": "REFERENCE_INITIALIZED"}},
    )
    return capture_source_payload(twin, selection(), "generation-a", "metabolic-continuous-v1")


class TechnicalAdapter:
    """Deliberately technical, not an engine or biological comparison fixture."""
    entered = None
    release = None

    def __init__(self, source):
        self.source = source

    def initialize(self):
        return deepcopy(self.source["initialization"]["checkpoint"])

    def advance(self, checkpoint, native_end):
        if self.entered is not None:
            self.entered.set()
            assert self.release.wait(3)
        candidate = deepcopy(checkpoint)
        candidate["native_time"] = native_end
        candidate["state_values"][0] += 1
        return {
            "checkpoint": candidate,
            "series": [{"quantity": "glucose_mgdl", "unit": "mg/dL", "compartment": "plasma",
                        "native_times": [native_end], "values": [candidate["state_values"][0]]}],
        }

    def close(self):
        pass


def manager(tmp_path):
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_store import ExecutionStore

    return ExecutionManager(
        ExecutionStore(tmp_path / "executions.sqlite3", key=b"t" * 32),
        adapter_registry={"metabolic-continuous-v1": TechnicalAdapter},
        run_background=False,
    )


def test_capture_detaches_full_state_and_never_reads_display_or_bus():
    from livemorebio.aegle.execution import capture_source_payload
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY, MetabolicProfile

    twin = SimpleNamespace(profile=MetabolicProfile(**asdict(HEALTHY)), meals=[(120., 75.)],
                           state=lambda: pytest.fail("display state is not a source"))
    source = capture_source_payload(twin, selection(), "generation-a", "metabolic-continuous-v1")
    original = deepcopy(source)
    twin.profile.Gb = 500
    twin.meals.append((200., 100.))
    assert source == original
    assert source["initialization"]["checkpoint"]["state_values"] == [90., 0., 9.]
    assert source["native_axis"]["unit"] == "min"
    assert len(source["source_snapshot_hash"]) == 64
    assert source["selection"]["source_data_class"] == "SYNTHETIC"


@pytest.mark.parametrize("bad", [True, float("nan"), float("inf"), "90"])
def test_capture_rejects_coerced_or_nonfinite_profile(bad):
    from livemorebio.aegle.execution import capture_source_payload
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY, MetabolicProfile

    twin = SimpleNamespace(profile=MetabolicProfile(**{**asdict(HEALTHY), "Gb": bad}), meals=[])
    with pytest.raises(ValueError):
        capture_source_payload(twin, selection(), "generation-a", "metabolic-continuous-v1")


def test_execution_idempotency_pause_resume_and_frames_do_not_mutate_source(tmp_path):
    engine = manager(tmp_path)
    source = captured_source()
    before = deepcopy(source)
    prepared = engine.prepare(source, policy={"end_native": 3., "frame_period_s": 1., "time_scale": 60.},
                              idempotency_key="prepare-a")
    assert engine.prepare(source, policy={"end_native": 3., "frame_period_s": 1., "time_scale": 60.},
                          idempotency_key="prepare-a")["execution_id"] == prepared["execution_id"]
    started = engine.start(prepared["execution_id"], expected_revision=prepared["revision"],
                           expected_source_generation="generation-a")
    engine.advance_once(started["execution_id"])
    state = engine.status(started["execution_id"])
    paused = engine.pause(state["execution_id"], expected_revision=state["revision"],
                          expected_source_generation="generation-a")
    assert paused["state"] == "paused"
    assert engine.advance_once(paused["execution_id"]) is None
    engine.resume(paused["execution_id"], expected_revision=paused["revision"],
                  expected_source_generation="generation-a")
    engine.advance_once(paused["execution_id"])
    frames = engine.frames(paused["execution_id"], after_frame=0, limit=50)["frames"]
    assert [frame["native_end"] for frame in frames] == [1., 2.]
    assert all(frame["source_snapshot_hash"] == source["source_snapshot_hash"] for frame in frames)
    assert source == before
    engine.close()


def test_source_switch_fences_inflight_commit_without_relabeling(tmp_path):
    engine = manager(tmp_path)
    source = captured_source()
    record = engine.prepare(source, policy={"end_native": 3., "frame_period_s": 1., "time_scale": 60.},
                            idempotency_key="prepare-race")
    record = engine.start(record["execution_id"], expected_revision=record["revision"],
                          expected_source_generation="generation-a")
    TechnicalAdapter.entered, TechnicalAdapter.release = threading.Event(), threading.Event()
    worker = threading.Thread(target=lambda: engine.advance_once(record["execution_id"]))
    try:
        worker.start()
        assert TechnicalAdapter.entered.wait(2)
        engine.invalidate_source("generation-a", "source_changed")
        TechnicalAdapter.release.set()
        worker.join(3)
        assert not worker.is_alive()
        assert engine.frames(record["execution_id"], after_frame=0, limit=50)["frames"] == []
        assert engine.status(record["execution_id"])["state"] == "paused"
        with pytest.raises(ValueError):
            engine.resume(record["execution_id"], expected_revision=engine.status(record["execution_id"])["revision"],
                          expected_source_generation="generation-b")
    finally:
        TechnicalAdapter.release.set()
        TechnicalAdapter.entered = TechnicalAdapter.release = None
        engine.close()


def test_store_encrypts_virtual_source_and_rejects_wrong_key(tmp_path):
    from livemorebio.aegle.execution_store import ExecutionStore

    source = captured_source()
    source["parameters"]["name"] = "PRIVATE TECHNICAL MARKER"
    from livemorebio.aegle.execution_contract import seal_source
    source = seal_source(source)
    path = tmp_path / "store.sqlite3"
    store = ExecutionStore(path, key=b"a" * 32)
    record = store.create(source, {"end_native": 3., "frame_period_s": 1., "time_scale": 60.},
                          idempotency_key="encrypted-fixture")
    assert b"PRIVATE TECHNICAL MARKER" not in path.read_bytes()
    assert "PRIVATE TECHNICAL MARKER" in json.dumps(store.get(record["execution_id"]))
    with pytest.raises(ValueError):
        ExecutionStore(path, key=b"b" * 32).get(record["execution_id"])


def test_second_manager_cannot_own_an_already_running_execution(tmp_path):
    first = manager(tmp_path)
    second = manager(tmp_path)
    record = first.prepare(captured_source(), policy={"end_native": 3., "frame_period_s": 1., "time_scale": 60.},
                           idempotency_key="one-owner")
    running = first.start(record["execution_id"], expected_revision=record["revision"],
                          expected_source_generation="generation-a")
    try:
        with pytest.raises(ValueError):
            second.start(record["execution_id"], expected_revision=running["revision"],
                         expected_source_generation="generation-a")
    finally:
        first.close()
        second.close()


def test_metabolic_interval_resolves_future_meal_without_resetting_hidden_state():
    from livemorebio.aegle.execution_adapters import MetabolicExecutionAdapter
    from livemorebio.aegle.execution_contract import seal_source

    source = captured_source()
    source["schedule"] = [[120., 75.]]
    source = seal_source(source)
    adapter = MetabolicExecutionAdapter(source)
    initial = adapter.initialize()
    before_meal = adapter.advance(initial, 100.)
    assert before_meal["checkpoint"]["state_values"] == pytest.approx([90., 0., 9.], abs=1e-8)
    after_meal = adapter.advance(before_meal["checkpoint"], 180.)
    assert after_meal["checkpoint"]["native_time"] == 180.
    assert after_meal["checkpoint"]["state_values"][0] > 90.
    assert after_meal["checkpoint"]["state_values"][1] > 0.
    assert after_meal["checkpoint"]["state_values"][2] > 9.
    assert initial["state_values"] == [90., 0., 9.]


def test_completed_execution_releases_worker_and_never_wraps(tmp_path):
    engine = manager(tmp_path)
    record = engine.prepare(captured_source(), {"end_native": 1., "frame_period_s": 1., "time_scale": 60.}, "complete")
    engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
    engine.advance_once(record["execution_id"])
    assert engine.status(record["execution_id"])["state"] == "completed"
    assert engine.advance_once(record["execution_id"]) is None
    assert engine._owners == {} and engine._adapters == {} and engine._next_due == {}
    engine.close()


def test_other_manager_cannot_pause_or_stop_owned_execution(tmp_path):
    first, second = manager(tmp_path), manager(tmp_path)
    record = first.prepare(captured_source(), {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "foreign-owner")
    record = first.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
    try:
        for action in (second.pause, second.stop):
            with pytest.raises(ValueError):
                action(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        assert first.status(record["execution_id"])["state"] == "running"
    finally:
        first.close()
        second.close()


def test_restart_marks_unowned_running_record_interrupted_without_execution(tmp_path):
    first = manager(tmp_path)
    record = first.prepare(captured_source(), {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "restart")
    record = first.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
    # A killed process releases its OS lock but cannot update SQLite first.
    first._release(record["execution_id"])
    second = manager(tmp_path)
    try:
        assert second.status(record["execution_id"])["state"] == "interrupted"
        assert second.frames(record["execution_id"])["frames"] == []
        assert second._adapters == {}
    finally:
        first.close()
        second.close()


def test_close_releases_owner_even_when_storage_read_fails(tmp_path, monkeypatch):
    engine = manager(tmp_path)
    record = engine.prepare(captured_source(), {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "close-failure")
    engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
    from livemorebio.aegle.execution_contract import ExecutionError
    monkeypatch.setattr(engine.store, "get", lambda *_: (_ for _ in ()).throw(ExecutionError("EXECUTION_STORAGE")))
    with pytest.raises(ValueError):
        engine.close()
    assert engine._owners == {} and engine._adapters == {}


def test_prepare_conflict_and_frame_bounds_are_fail_closed(tmp_path):
    engine = manager(tmp_path)
    record = engine.prepare(captured_source(), {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "same-key")
    with pytest.raises(ValueError):
        engine.prepare(captured_source(), {"end_native": 2., "frame_period_s": 1., "time_scale": 60.}, "same-key")
    for arguments in ({"limit": True}, {"limit": 501}, {"after_frame": -1}, {"after_frame": 1.1}):
        with pytest.raises(ValueError):
            engine.frames(record["execution_id"], **arguments)
    engine.close()


def test_technical_registry_cannot_claim_engine_authorship(tmp_path):
    engine = manager(tmp_path)
    record = engine.prepare(captured_source(), {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "authorship")
    record = engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
    frame = engine.advance_once(record["execution_id"])
    assert frame["authorship"] == "technical_fixture"
    assert frame["evidence_class"] == "TECHNICAL_FIXTURE"
    assert frame["independent_physical_validation"] is False
    engine.close()


def test_capture_preserves_actual_runtime_parameter_provenance_method():
    from livemorebio.aegle.execution import capture_source_payload
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY
    origins = {"Gb": {"evidence_class": "MEASURED_CLINICAL", "value": 90., "source_id": "technical-assay"}}
    twin = SimpleNamespace(profile=HEALTHY, meals=[], parameter_provenance=lambda: origins)
    source = capture_source_payload(twin, selection(), "generation-a", "metabolic-continuous-v1")
    assert source["parameter_provenance"]["Gb"] == origins["Gb"]
    origins["Gb"]["value"] = 500.
    assert source["parameter_provenance"]["Gb"]["value"] == 90.


def test_engine_frame_records_actual_numerical_runtime_identity(tmp_path):
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_store import ExecutionStore
    engine = ExecutionManager(ExecutionStore(tmp_path / "runtime.sqlite3", key=b"r" * 32), run_background=False)
    try:
        record = engine.prepare(captured_source(), {"end_native": 1., "frame_period_s": 1., "time_scale": 60.}, "runtime")
        engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        frame = engine.advance_once(record["execution_id"])
        assert frame["runtime_identity"]["solver"] == "scipy.LSODA"
        assert frame["runtime_identity"]["scipy_version"] == "1.17.1"
        assert frame["authorship"] == "engine" and frame["evidence_class"] == "MODELED"
    finally:
        engine.close()


def test_frame_chain_and_latest_checkpoint_are_committed_atomically(tmp_path):
    engine = manager(tmp_path)
    record = engine.prepare(captured_source(), {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "chain")
    engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
    first = engine.advance_once(record["execution_id"])
    second = engine.advance_once(record["execution_id"])
    assert first["previous_frame_hash"] is None
    assert second["previous_frame_hash"] == first["frame_hash"]
    durable = engine.store.get(record["execution_id"])
    from livemorebio.aegle.execution_contract import digest
    assert durable["latest_frame_hash"] == second["frame_hash"]
    assert digest(durable["checkpoint"]) == second["checkpoint_hash"]
    engine.close()


def test_solver_failure_discards_candidate_and_releases_its_worker(tmp_path):
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_store import ExecutionStore

    class Broken(TechnicalAdapter):
        def advance(self, previous, native_end):
            result = super().advance(previous, native_end)
            result["series"][0]["values"][0] = float("nan")
            return result

    engine = ExecutionManager(ExecutionStore(tmp_path / "failure.sqlite3", key=b"f" * 32),
        adapter_registry={"metabolic-continuous-v1": Broken}, run_background=False)
    record = engine.prepare(captured_source(), {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "failed-solve")
    engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
    assert engine.advance_once(record["execution_id"]) is None
    assert engine.status(record["execution_id"])["state"] == "failed"
    assert engine.frames(record["execution_id"])["frames"] == []
    assert engine._owners == {} and engine._adapters == {}
    engine.close()


def test_initialization_failure_releases_owner(tmp_path):
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_store import ExecutionStore

    class Broken(TechnicalAdapter):
        def initialize(self):
            raise RuntimeError("PRIVATE TECHNICAL ERROR")

    engine = ExecutionManager(ExecutionStore(tmp_path / "init.sqlite3", key=b"i" * 32),
        adapter_registry={"metabolic-continuous-v1": Broken}, run_background=False)
    record = engine.prepare(captured_source(), {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "failed-init")
    with pytest.raises(ValueError) as error:
        engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
    assert "PRIVATE" not in str(error.value)
    assert engine._owners == {} and engine._adapters == {}
    engine.close()


@pytest.mark.parametrize("violation", ["negative_intermediate", "checkpoint_disagreement"])
def test_frame_rejects_concentration_domain_and_endpoint_disagreement(tmp_path, violation):
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_store import ExecutionStore

    class Broken(TechnicalAdapter):
        def advance(self, previous, native_end):
            result = super().advance(previous, native_end)
            trace = result["series"][0]
            if violation == "negative_intermediate":
                trace["native_times"] = [native_end / 2, native_end]
                trace["values"] = [-1., trace["values"][-1]]
            else:
                trace["values"][-1] += 1.
            return result

    engine = ExecutionManager(ExecutionStore(tmp_path / "domain.sqlite3", key=b"d" * 32),
        adapter_registry={"metabolic-continuous-v1": Broken}, run_background=False)
    try:
        record = engine.prepare(captured_source(), {"end_native": 1., "frame_period_s": 1., "time_scale": 60.}, violation)
        engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        assert engine.advance_once(record["execution_id"]) is None
        assert engine.status(record["execution_id"])["state"] == "failed"
        assert engine.frames(record["execution_id"])["frames"] == []
    finally:
        engine.close()


def test_quota_pause_keeps_last_committed_checkpoint_and_has_no_partial_frame(tmp_path):
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_store import ExecutionStore
    engine = ExecutionManager(ExecutionStore(tmp_path / "quota.sqlite3", key=b"q" * 32, quota_bytes=8192),
        adapter_registry={"metabolic-continuous-v1": TechnicalAdapter}, run_background=False)
    try:
        record = engine.prepare(captured_source(), {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "quota")
        engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        before = engine.store.get(record["execution_id"])["checkpoint"]
        assert engine.advance_once(record["execution_id"]) is None
        result = engine.status(record["execution_id"])
        assert result["state"] == "paused" and result["failure_code"] == "EXECUTION_QUOTA"
        assert engine.store.get(record["execution_id"])["checkpoint"] == before
        assert engine.frames(record["execution_id"])["frames"] == []
    finally:
        engine.close()


def test_background_scheduler_commits_new_frames_then_stops_without_catchup(tmp_path):
    import time
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_store import ExecutionStore
    engine = ExecutionManager(ExecutionStore(tmp_path / "background.sqlite3", key=b"b" * 32),
        adapter_registry={"metabolic-continuous-v1": TechnicalAdapter}, run_background=True)
    try:
        record = engine.prepare(captured_source(), {"end_native": 2., "frame_period_s": .1, "time_scale": 600.}, "background")
        engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        deadline = time.monotonic() + 3.
        while time.monotonic() < deadline and engine.status(record["execution_id"])["state"] == "running":
            time.sleep(.02)
        assert engine.status(record["execution_id"])["state"] == "completed"
        assert [f["native_end"] for f in engine.frames(record["execution_id"])["frames"]] == [1., 2.]
    finally:
        engine.close()


def test_cellular_checkpoint_rejects_negative_concentrations_beyond_fixed_floor(pinned_cardiac_asset):
    from livemorebio.tests.test_execution_numerics import source
    from livemorebio.aegle.execution_contract import validate_checkpoint
    captured = source(cellular=True)
    checkpoint = deepcopy(captured["initialization"]["checkpoint"])
    checkpoint["state_values"][9] = -.001
    with pytest.raises(ValueError):
        validate_checkpoint(captured, checkpoint)


def test_explicit_checkpoint_fork_retains_full_state_native_clock_and_parent(tmp_path):
    from livemorebio.aegle.execution_contract import seal_source
    first = manager(tmp_path)
    source = captured_source()
    record = first.prepare(source, {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "parent")
    first.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
    frame = first.advance_once(record["execution_id"])
    first.close()
    second = manager(tmp_path)
    try:
        parent = second.status(record["execution_id"])
        assert parent["state"] == "interrupted"
        source["source_generation"] = "generation-b"
        replacement = seal_source(source)
        fork = second.fork_checkpoint(record["execution_id"], replacement,
            policy={"end_native": 3., "frame_period_s": 1., "time_scale": 60.},
            idempotency_key="fork", expected_parent_revision=parent["revision"])
        second.start(fork["execution_id"], expected_revision=fork["revision"], expected_source_generation="generation-b")
        child = second.advance_once(fork["execution_id"])
        assert child["native_start"] == 1. and child["native_end"] == 2.
        assert child["series"][0]["values"][-1] == 92.
        assert child["checkpoint_parent"]["frame_hash"] == frame["frame_hash"]
        assert second.frames(record["execution_id"])["frames"] == [frame]
        replacement["parameters"]["Gb"] = 100.
        replacement["initialization"]["checkpoint"]["state_values"][0] = 100.
        with pytest.raises(ValueError):
            second.fork_checkpoint(record["execution_id"], seal_source(replacement),
                policy={"end_native": 3., "frame_period_s": 1., "time_scale": 60.},
                idempotency_key="wrong-fork", expected_parent_revision=parent["revision"])
    finally:
        second.close()


def test_stop_interrupts_owned_initialization_and_fences_late_checkpoint(tmp_path):
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_store import ExecutionStore
    entered, release, closed = threading.Event(), threading.Event(), threading.Event()

    class Initializing(TechnicalAdapter):
        def initialize(self):
            entered.set()
            assert release.wait(3)
            return super().initialize()

        def close(self):
            closed.set()
            release.set()

    engine = ExecutionManager(ExecutionStore(tmp_path / "initialization.sqlite3", key=b"j" * 32),
        adapter_registry={"metabolic-continuous-v1": Initializing}, run_background=False)
    record = engine.prepare(captured_source(), {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "stop-init")
    failures = []

    def start():
        try:
            engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        except ValueError as error:
            failures.append(error)

    thread = threading.Thread(target=start)
    try:
        thread.start()
        assert entered.wait(2)
        status = engine.status(record["execution_id"])
        engine.stop(record["execution_id"], expected_revision=status["revision"], expected_source_generation="generation-a")
        assert closed.wait(.2), "stop must cancel the already owned initializing adapter"
        thread.join(2)
        assert not thread.is_alive()
        assert engine.status(record["execution_id"])["state"] == "stopped"
        assert engine.frames(record["execution_id"])["frames"] == []
    finally:
        release.set()
        thread.join(3)
        engine.close()


def test_unrelated_source_changes_do_not_build_unbounded_tombstones(tmp_path):
    engine = manager(tmp_path)
    try:
        for index in range(10000):
            engine.invalidate_source(f"unused-generation-{index}", "source_changed")
        assert len(getattr(engine, "_invalid_generations", ())) == 0
    finally:
        engine.close()
