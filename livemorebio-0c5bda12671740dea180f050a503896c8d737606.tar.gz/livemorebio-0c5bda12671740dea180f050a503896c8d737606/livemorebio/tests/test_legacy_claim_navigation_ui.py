"""Actual legacy copy/render/nav seams with authored data and inert dependencies."""
import json
import re

import pytest

from .test_clinical_model_availability_ui import CONSOLE, node
from .test_legacy_preview_recovery_clients import preview


def page():
    return (CONSOLE / "index.html").read_text(encoding="utf-8")


def mounted(script, assertions):
    state = preview()
    state["context_id"] = "a" * 64
    state["systems"] = [
        {"name": "Authored cardiac", "engine": "Authored engine", "status": "alive"},
        {"name": "Authored renal", "engine": None, "status": "pending"},
    ]
    node(r"""
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();
function el(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',style:{},title:'',className:'',
 classList:{toggle(){}},setAttribute(){},querySelector(){return null}});return nodes.get(id)}
const state=STATE,original=JSON.stringify(state);let draws=0,paints=0,reads=0;
const owner={captureEpoch:()=>owner,isCurrent:t=>t===owner};
const context={S:state,legacyBusy:false,$:el,esc:x=>String(x??''),legacyPreviewRecovery:owner,
 drawMetab:()=>draws++,paintBody:()=>paints++,showBanner:msg=>a.equal(msg,''),
 console:{error(){throw Error('unexpected render failure')}},fetch:async(path,options)=>{
  reads++;a.equal(path,'/api/biology');a.equal(options.cache,'no-store');return{ok:true,json:async()=>context.biology}}};
vm.createContext(context);vm.runInContext(SCRIPT,context);
""".replace("STATE", json.dumps(state)).replace("SCRIPT", json.dumps(script)) + assertions)


def test_initial_copy_preserves_model_limitations():
    html = page()
    assert '<h1>Aegle · <span>Advanced console</span></h1>' in html
    assert '“Pending” systems have no engine yet.</div>' in html
    assert "Model-only, mechanistic, hypothesis-triage infrastructure" in html
    assert "Not clinically validated; parameters literature-typical, not cohort-fitted." in html


def test_actual_render_labels_engine_presence_without_changing_state():
    html = page()
    labels = "function updateLegacyCardiacLabels(){" + html.split("function updateLegacyCardiacLabels(){", 1)[1].split("function updateLegacyControls(", 1)[0]
    render = "function render(){" + html.split("function render(){", 1)[1].split("// --- reactive metabolic curves ---", 1)[0]
    mounted(labels + render, r"""
vm.runInContext('render()',context);
a.equal(context.S,state);a.equal(JSON.stringify(state),original);a.equal(draws,1);a.equal(paints,1);a.equal(reads,0);
const list=el('sysList').innerHTML;
a(list.includes('>MODEL</span>'));a(list.includes('>PENDING</span>'));a(!list.includes('>ALIVE</span>'));
for(const value of ['Authored cardiac','Authored engine','Authored renal','engine pending'])a(list.includes(value));
a(list.includes('sys alive'));a(list.includes('sys pending'));a.equal(state.systems[0].status,'alive');
a.equal(el('mVpeak').textContent,10);a.equal(el('mApd').textContent,250);a.equal(el('mCai').textContent,.2);
a.equal(el('mBlk').textContent,'0%');a.equal(el('mMean').textContent,90.5);a.equal(el('mPeak').textContent,91);
a.deepEqual(['legacy-cardiac-state','legacy-cardiac-provenance','legacy-cardiac-time'].map(id=>el(id).textContent),
 ['Calculated response','computed','calculated beat · milliseconds']);
""")


@pytest.mark.parametrize("quantity", [None, {"value": 0.125, "unit": "µM", "label": "Authored quantity"}])
def test_actual_body_readout_has_model_fallback_and_preserves_quantity(quantity):
    html = page()
    script = "const ORGAN_SVG=" + html.split("const ORGAN_SVG=", 1)[1].split("function render(){", 1)[0]
    mounted(script, r"""
context.biology={context_id:state.context_id,organs:[{id:'heart',name:'Authored heart',role:'Authored role',
 cell:{activity:.4,quantities:QUANTITY===null?[]:[QUANTITY]}}]};
(async()=>{
await vm.runInContext('paintBody()',context);const html=el('organReadout').innerHTML;
a(html.includes('>organ model readouts</span>'));a(!html.includes('living organs'));a(!html.includes('real state'));a(!html.includes(' live'));
a(html.includes('Authored heart'));a(html.includes('href="/biology"'));a(html.includes('width:100%'));
if(QUANTITY===null)a(html.includes('AP · Ca²⁺ model'));else{a(html.includes('0.125 µM'));a(!html.includes('AP · Ca²⁺ model'))}
a.equal(reads,1);a.equal(context.S,state);a.equal(JSON.stringify(state),original);
})().catch(error=>{console.error(error);process.exitCode=1});
""".replace("QUANTITY", json.dumps(quantity)))


@pytest.mark.parametrize("active,label", [("/legacy", "Advanced console"), ("/", "Atlas"), ("/biology", "Biology")])
def test_actual_shell_marks_only_current_destination(active, label):
    source = (CONSOLE / "lib/shell.js").read_text(encoding="utf-8")
    source = re.sub(r"^import .*;\n", "", source, flags=re.M).replace("export function", "function")
    # Keep actual mountShell/PAGES, replacing only footer/build dependency calls.
    source = source.split("function mountServicesFooter()", 1)[0]
    node(r"""
const a=require('node:assert/strict'),vm=require('node:vm'),roots=[];let footers=0,builds=0;
const context={document:{body:{prepend:n=>roots.unshift(n)}},
 el:(tag,attrs,...children)=>({tag,attrs,children}),mountServicesFooter:()=>footers++,mountBuildIdentity:()=>builds++};
vm.createContext(context);vm.runInContext(SOURCE,context);context.mountShell(ACTIVE,'Authored subtitle');
const links=[];function walk(n){if(!n||typeof n!=='object')return;if(n.tag==='a')links.push(n);for(const c of n.children||[])walk(c)}roots.forEach(walk);
a.deepEqual(links.map(n=>[n.attrs.href,n.attrs.text]),[
 ['/','Atlas'],['/twins','Twins'],['/cohorts','Cohorts'],['/cendos','Cendos Lab'],['/biology','Biology'],
 ['/patch','LIFE Patch'],['/research','Research'],['/adapters','Knowledge'],['/legacy','Advanced console'],['/docs','API']]);
a.deepEqual(links.filter(n=>n.attrs.class==='active').map(n=>[n.attrs.href,n.attrs.text]),[[ACTIVE,LABEL]]);
a.equal(links.at(-1).attrs.target,'_blank');a.equal(footers,1);a.equal(builds,1);
""".replace("SOURCE", json.dumps(source)).replace("ACTIVE", json.dumps(active)).replace("LABEL", json.dumps(label)))


def test_legacy_served_module_passes_its_real_destination():
    html = page()
    assert 'mountShell("/legacy", "Aegle — advanced console");' in html
    assert 'mountShell("/",' not in html
