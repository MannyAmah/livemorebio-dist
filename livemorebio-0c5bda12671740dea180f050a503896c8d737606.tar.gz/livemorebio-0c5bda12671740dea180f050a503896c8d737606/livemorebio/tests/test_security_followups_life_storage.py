"""Technical LIFE fixtures pin each storage precondition independently."""
from __future__ import annotations

from fastapi.testclient import TestClient
import pytest

from livemorebio import bus, security
from livemorebio.tests.test_security_followups_storage import private_state


@pytest.mark.parametrize("wrapped", [False, True])
def test_rt1_telemetry_refuses_before_journal_or_publication(private_state, monkeypatch, wrapped):
    from livemorebio.life_system import service
    from livemorebio.life_patch.protocol import DeviceMode, VirtualLifePatch, manifest_for

    manifest = manifest_for("technical-h2-telemetry-device", DeviceMode.VIRTUAL)
    client = TestClient(service.app, base_url="http://127.0.0.1:18950", headers=security.authorization_headers())
    assert client.post("/patch/devices", json=manifest.to_dict()).status_code == 201
    forwarded = []
    monkeypatch.setattr(service, "_forward_to_aegle", lambda payload: forwarded.append(payload))
    assert client.get("/patch/telemetry").json()["telemetry"] == []
    envelope = VirtualLifePatch(manifest).emit("pseudonym-technical-h2-subject", {"hr_bpm": 72}).to_dict()
    body = ({"envelope": envelope, "consent_scope": ["technical-research"],
             "chain_of_custody": ["technical-fixture"]} if wrapped else envelope)

    response = client.post("/patch/telemetry", json=body)

    assert response.status_code == 503, response.text
    assert response.json()["code"] == "PATCH_STORAGE_KEY_UNAVAILABLE"
    assert client.get("/patch/telemetry").json()["telemetry"] == []
    assert forwarded == []
    assert not (private_state / "events.jsonl").exists()


def test_rt1_shared_acceptance_refuses_before_gateway(private_state, monkeypatch):
    from livemorebio.life_system import service
    from livemorebio.life_patch.protocol import DeviceMode, VirtualLifePatch, manifest_for

    def unexpected_gateway():
        pytest.fail("the storage precondition must run before journal admission")

    monkeypatch.setattr(service, "_patch_gateway", unexpected_gateway)
    envelope = VirtualLifePatch(manifest_for("technical-h2-direct-device", DeviceMode.VIRTUAL)).emit(
        "pseudonym-technical-h2-subject", {"hr_bpm": 72})
    with pytest.raises(bus.PatchStorageKeyUnavailable):
        service._accept_patch(envelope)


def test_rt2_generated_sample_refuses_before_registering_device(private_state, monkeypatch):
    from livemorebio.life_system import service

    device_id = "technical-h2-never-registered"
    client = TestClient(service.app, base_url="http://127.0.0.1:18950", headers=security.authorization_headers())
    forwarded = []
    monkeypatch.setattr(service, "_forward_to_aegle", lambda payload: forwarded.append(payload))
    assert client.get("/patch/devices/" + device_id).status_code == 404

    response = client.post("/patch/virtual/sample", json={
        "device_id": device_id, "subject_id": "pseudonym-technical-h2-subject", "readings": {"hr_bpm": 72}})

    assert response.status_code == 503, response.text
    assert response.json()["code"] == "PATCH_STORAGE_KEY_UNAVAILABLE"
    assert client.get("/patch/devices/" + device_id).status_code == 404
    assert not (private_state / "patch.devices.json").exists()
    assert client.get("/patch/telemetry").json()["telemetry"] == []
    assert forwarded == []
    assert not (private_state / "events.jsonl").exists()
