"""Target -> disease mapping via Open Targets (database-driven, scalable, not hand-coded)."""
import os
import pytest
from livemorebio.engines import disease_links as DL


@pytest.mark.network
@pytest.mark.skipif(os.environ.get("LIVEMORE_TEST_NETWORK") != "1",
                    reason="explicit public network lookup opt-in")
def test_target_diseases_from_open_targets():
    try:
        d = DL.target_diseases("AKR1B1")
    except Exception:
        pytest.skip("network unavailable")
    if not d:
        pytest.skip("Open Targets unavailable")
    assert any("diab" in name.lower() for name, _, _ in d)      # AKR1B1 -> diabetic complications


@pytest.mark.network
@pytest.mark.skipif(os.environ.get("LIVEMORE_TEST_NETWORK") != "1",
                    reason="explicit public network lookup opt-in")
def test_exposure_signature_rewards_convergence():
    try:
        sig = DL.exposure_disease_signature(["ALOX5", "ALOX12", "ALOX15"])   # lipoxygenases -> inflammation
    except Exception:
        pytest.skip("network unavailable")
    if not sig:
        pytest.skip("Open Targets unavailable")
    assert sig[0]["n_targets"] >= 2
