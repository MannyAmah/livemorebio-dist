"""HISTORICAL bootstrap-v1 contract, not current-product session acceptance.

All 21 original assertions execute the byte-identical retired IIFE fixture.
Current behavior is covered by test_navigation_session[_ui].py instead.
No network, credential reads, or product store is used here.
"""

from pathlib import Path
import shutil
import subprocess

import pytest
from ._node import require_node


AUTH = Path(__file__).resolve().parent / "fixtures/auth_bootstrap_historical.js"
HARNESS = r"""
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const calls = [], timers = new Map(), output = [];
let clock = 0, nextTimer = 1, bodyReads = 0;
const defer = () => {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
};
const flush = async () => { for (let i = 0; i < 24; i++) await Promise.resolve(); };
const watch = promise => {
  const state = { state: 'pending' };
  promise.then(value => Object.assign(state, { state: 'fulfilled', value }),
    error => Object.assign(state, { state: 'rejected', error }));
  return state;
};
const response = (status = 200) => ({ status, ok: status >= 200 && status < 300,
  json: async () => { bodyReads++; return {error: 'PRIVATE_FIXTURE_BODY'}; } });
const context = {
  URL, Request, AbortController, DOMException,
  location: new URL('http://127.0.0.1:8910/patch'),
  setTimeout(fn, delay) { const id = nextTimer++; timers.set(id, {at: clock + delay, fn}); return id; },
  clearTimeout(id) { timers.delete(id); },
  console: {log: (...args) => output.push(args), error: (...args) => output.push(args), warn: (...args) => output.push(args)},
};
context.window = {fetch(input, init) {
  const pending = defer(); calls.push({input, init, ...pending}); return pending.promise;
}};
for (const property of ['localStorage', 'sessionStorage', 'document']) {
  Object.defineProperty(context, property, {get() {throw Error('Credential/storage access');}});
  Object.defineProperty(context.window, property, {get() {throw Error('Credential/storage access');}});
}
vm.runInNewContext(fs.readFileSync(process.argv[1], 'utf8'), context);
const fetch = context.window.fetch;
const ensure = context.window.lmbEnsureLocalSession;
const boots = () => calls.filter(call => call.input === '/api/session/bootstrap');
const requests = () => calls.filter(call => call.input !== '/api/session/bootstrap');
const advance = async milliseconds => {
  const end = clock + milliseconds;
  while (true) {
    const pending = [...timers].filter(([, timer]) => timer.at <= end).sort((a, b) => a[1].at - b[1].at);
    if (!pending.length) break;
    const [id, timer] = pending[0]; timers.delete(id); clock = timer.at; timer.fn(); await flush();
  }
  clock = end; await flush();
};
const assertUnavailable = observed => {
  assert.equal(observed.state, 'rejected');
  assert.equal(observed.error.code, 'LOCAL_SESSION_UNAVAILABLE');
  assert.equal(observed.error.message, 'Automatic local session is unavailable. Run `livemore start` and reopen the product.');
};
const trackedSignal = () => {
  const controller = new AbortController(), listeners = new Set(), signal = controller.signal;
  const add = signal.addEventListener.bind(signal), remove = signal.removeEventListener.bind(signal);
  signal.addEventListener = (name, listener, options) => {if (name === 'abort') listeners.add(listener); return add(name, listener, options);};
  signal.removeEventListener = (name, listener, options) => {if (name === 'abort') listeners.delete(listener); return remove(name, listener, options);};
  return {controller, signal, listeners};
};
"""


def run(script: str) -> None:
    node = require_node()
    result = subprocess.run(
        [node, "--unhandled-rejections=strict", "-e", HARNESS + "\n(async () => {\n" + script + "\n})().catch(error => { console.error(error); process.exitCode = 1; });", str(AUTH)],
        capture_output=True,
        text=True,
        timeout=15,
        check=False, encoding="utf-8",
    )
    assert result.returncode == 0, result.stderr


def test_caller_abort_settles_without_dispatch_or_canceling_shared_bootstrap() -> None:
    run("""
const {controller, signal, listeners} = trackedSignal();
const observed = watch(fetch('/api/executions', {signal})); await flush();
assert.equal(boots().length, 1); controller.abort('PRIVATE_ABORT_REASON'); await flush();
assert.equal(observed.state, 'rejected'); assert.equal(observed.error.name, 'AbortError');
assert(!observed.error.message.includes('PRIVATE')); assert.equal(requests().length, 0);
assert.equal(boots()[0].init.signal.aborted, false); assert.equal(listeners.size, 0);
boots()[0].resolve(response()); await flush(); assert.equal(requests().length, 0); assert.equal(timers.size, 0);
""")


def test_two_waiters_share_bootstrap_but_only_surviving_caller_dispatches() -> None:
    run("""
const controller = new AbortController();
const canceled = watch(fetch('/api/first', {signal: controller.signal}));
const survivor = watch(fetch('/api/second')); await flush();
assert.equal(boots().length, 1); controller.abort(); await flush();
assert.equal(canceled.state, 'rejected'); assert.equal(canceled.error.name, 'AbortError');
assert.equal(survivor.state, 'pending'); assert.equal(boots()[0].init.signal.aborted, false);
boots()[0].resolve(response()); await flush(); assert.equal(requests().length, 1);
assert.equal(requests()[0].input, '/api/second'); const original = response(); requests()[0].resolve(original);
await flush(); assert.equal(survivor.value, original); assert.equal(timers.size, 0);
""")


def test_already_aborted_caller_never_starts_bootstrap() -> None:
    run("""
const controller = new AbortController(); controller.abort('PRIVATE_ABORT_REASON');
const observed = watch(fetch('/api/executions', {signal: controller.signal})); await flush();
assert.equal(observed.state, 'rejected'); assert.equal(observed.error.name, 'AbortError');
assert.equal(calls.length, 0); assert.equal(timers.size, 0);
""")


def test_owned_timeout_is_exact_and_explicit_retry_creates_one_new_flight() -> None:
    run("""
const first = watch(fetch('/api/first')), second = watch(fetch('/api/second')); await flush();
assert.equal(boots().length, 1); await advance(9999); assert.equal(first.state, 'pending');
await advance(1); assertUnavailable(first); assertUnavailable(second);
assert.equal(boots()[0].init.signal.aborted, true); assert.equal(requests().length, 0); assert.equal(timers.size, 0);
const retry = watch(fetch('/api/retry')); await flush(); assert.equal(boots().length, 2);
boots()[1].resolve(response()); await flush(); assert.equal(requests().length, 1);
requests()[0].resolve(response()); await flush(); assert.equal(retry.state, 'fulfilled'); assert.equal(timers.size, 0);
""")


@pytest.mark.parametrize("late", ["success", "failure"])
def test_timed_out_native_completion_cannot_poison_new_success(late: str) -> None:
    run("""
const old = watch(ensure()); await flush(); await advance(10000); assertUnavailable(old);
const current = watch(ensure()); await flush(); boots()[1].resolve(response()); await flush();
assert.equal(current.value, true);
""" + ("boots()[0].resolve(response());" if late == "success" else "boots()[0].reject(Error('PRIVATE_OLD_FAILURE'));") + """
await flush(); const cached = watch(ensure()); await flush();
assert.equal(cached.value, true); assert.equal(boots().length, 2); assert.equal(timers.size, 0);
""")


def test_current_401_invalidates_without_replaying_the_original_request() -> None:
    run("""
const first = watch(fetch('/api/first')); await flush(); boots()[0].resolve(response()); await flush();
const unauthorized = response(401); requests()[0].resolve(unauthorized); await flush();
assert.equal(first.value, unauthorized); assert.equal(boots().length, 1); assert.equal(requests().length, 1);
const retry = watch(fetch('/api/retry')); await flush(); assert.equal(boots().length, 2);
boots()[1].resolve(response()); await flush(); requests()[1].resolve(response()); await flush();
assert.equal(retry.state, 'fulfilled');
""")


def test_late_old_401_cannot_clear_new_successful_session() -> None:
    run("""
const first = watch(fetch('/api/first')), late = watch(fetch('/api/late')); await flush();
boots()[0].resolve(response()); await flush(); requests()[0].resolve(response(401)); await flush();
const newer = watch(fetch('/api/newer')); await flush(); assert.equal(boots().length, 2);
boots()[1].resolve(response()); await flush(); requests()[2].resolve(response()); await flush();
requests()[1].resolve(response(401)); await flush();
const cached = watch(fetch('/api/cached')); await flush(); assert.equal(boots().length, 2);
assert.equal(requests().length, 4); requests()[3].resolve(response()); await flush();
assert.equal(cached.state, 'fulfilled'); assert.equal(first.value.status, 401); assert.equal(late.value.status, 401);
""")


def test_cross_origin_401_is_native_and_never_invalidates_local_session() -> None:
    run("""
const ready = watch(ensure()); await flush(); boots()[0].resolve(response()); await flush();
const options = {headers: {'X-Fixture': 'safe'}, credentials: 'omit'};
const external = watch(fetch('https://example.test/resource', options)); await flush();
assert.equal(requests()[0].init, options); requests()[0].resolve(response(401)); await flush();
const cached = watch(ensure()); await flush(); assert.equal(cached.value, true); assert.equal(boots().length, 1);
assert.equal(external.value.status, 401);
""")


@pytest.mark.parametrize("options", ["{}", "{signal: undefined}"])
def test_request_input_signal_is_used_unless_overridden(options: str) -> None:
    run("""
const controller = new AbortController();
const original = new Request('http://127.0.0.1:8910/api/request', {method: 'POST', body: 'fixture', signal: controller.signal});
const observed = watch(fetch(original, OPTIONS)); await flush(); controller.abort(); await flush();
assert.equal(observed.state, 'rejected'); assert.equal(observed.error.name, 'AbortError');
assert.equal(requests().length, 0); assert.equal(original.bodyUsed, false);
boots()[0].resolve(response()); await flush(); assert.equal(requests().length, 0);
""".replace("OPTIONS", options))


@pytest.mark.parametrize("override", ["null", "new AbortController().signal"])
def test_explicit_signal_override_preserves_original_request_and_body(override: str) -> None:
    run("""
const controller = new AbortController();
const original = new Request('http://127.0.0.1:8910/api/request', {method: 'POST', body: 'fixture', headers: {'X-Fixture': 'safe'}, signal: controller.signal});
const signal = OVERRIDE, observed = watch(fetch(original, {signal})); await flush();
controller.abort(); await flush(); assert.equal(observed.state, 'pending');
boots()[0].resolve(response()); await flush(); assert.equal(requests().length, 1);
assert.equal(requests()[0].input, original); assert.equal(requests()[0].init.signal, signal);
assert.equal(requests()[0].init.credentials, 'same-origin'); assert.equal(original.method, 'POST');
assert.equal(original.headers.get('X-Fixture'), 'safe'); assert.equal(original.bodyUsed, false);
requests()[0].resolve(response()); await flush(); assert.equal(observed.state, 'fulfilled');
""".replace("OVERRIDE", override))


@pytest.mark.parametrize("failure", ["body", "network", "synchronous"])
def test_bootstrap_errors_are_fixed_and_never_read_bodies_or_raw_exceptions(failure: str) -> None:
    prefix = ""
    if failure == "synchronous":
        prefix = "context.window.fetch = () => {throw Error('PRIVATE_SYNC_FAILURE')}; vm.runInNewContext(fs.readFileSync(process.argv[1], 'utf8'), context);"
    settle = {"body": "boots()[0].resolve(response(403));", "network": "boots()[0].reject(Error('PRIVATE_NETWORK_FAILURE'));", "synchronous": ""}[failure]
    run(prefix + """
const observed = watch(context.window.fetch('/api/private')); await flush();
""" + settle + """
await flush(); assertUnavailable(observed); assert.equal(bodyReads, 0); assert.equal(output.length, 0);
assert.equal(timers.size, 0); assert.equal(requests().length, 0);
""")


@pytest.mark.parametrize("outcome", ["success", "failure", "timeout", "abort"])
def test_all_settlement_paths_release_waiter_listeners_and_owned_timers(outcome: str) -> None:
    settle = {
        "success": "boots()[0].resolve(response()); await flush(); requests()[0].resolve(response());",
        "failure": "boots()[0].reject(Error('PRIVATE_FAILURE'));",
        "timeout": "await advance(10000);",
        "abort": "controller.abort(); await flush(); assert.equal(listeners.size, 0); boots()[0].resolve(response());",
    }[outcome]
    run("""
const {controller, signal, listeners} = trackedSignal();
const observed = watch(fetch('/api/request', {signal})); await flush(); assert.equal(listeners.size, 1);
""" + settle + """
await flush(); assert.notEqual(observed.state, 'pending'); assert.equal(listeners.size, 0); assert.equal(timers.size, 0);
""")


def test_success_cache_public_helper_and_direct_bootstrap_bypass_are_preserved() -> None:
    run("""
const ready = watch(ensure()); await flush(); assert.equal(boots().length, 1);
assert.equal(boots()[0].init.method, 'GET'); assert.equal(boots()[0].init.credentials, 'same-origin');
assert.equal(boots()[0].init.headers.Accept, 'application/json'); boots()[0].resolve(response(204)); await flush();
assert.equal(ready.value, true); const cached = watch(ensure()); await flush(); assert.equal(cached.value, true);
const first = watch(fetch('/api/first')), second = watch(fetch('/api/second')); await flush();
assert.equal(boots().length, 1); assert.equal(requests().length, 2);
for (const request of requests()) { assert.equal(request.init.credentials, 'same-origin'); request.resolve(response()); }
await flush(); assert.equal(first.state, 'fulfilled'); assert.equal(second.state, 'fulfilled');
const options = {credentials: 'omit'}, direct = watch(fetch('/api/session/bootstrap', options)); await flush();
assert.equal(boots().length, 2); assert.equal(boots()[1].init, options); boots()[1].resolve(response(204)); await flush();
assert.equal(direct.value.status, 204); assert.equal(timers.size, 0); assert.equal(output.length, 0);
""")
