"""Proposed checked-startup reads: authored encrypted fixtures, never physiology.

Tests only. The checked reader and the prerequisite inclusive stored-version
increment remain separately reviewed runtime work; these tests grant neither.
"""
from __future__ import annotations

from contextlib import closing
from copy import deepcopy
from dataclasses import FrozenInstanceError, replace
import json
import sqlite3
from uuid import uuid4

from cryptography.exceptions import InvalidTag
import pytest

from livemorebio.aegle import subjects
from livemorebio.aegle.registry_audit import RegistryAuditError
from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError
from livemorebio.aegle.subjects import SubjectRegistry, SubjectRegistryError
from livemorebio.strict_json import MAX_SAFE_INTEGER
from livemorebio.tests.clinical_registry_fixtures import (
    CAPTURED, KEY, canonical, replace_fixture_record,
)
from livemorebio.tests.test_committed_registry_transitions import (
    events, no_network_or_models, rows, seed,
)

SAFE_STORAGE_ERRORS = (SubjectRegistryError, RegistryAuditError, RegistryBootstrapError, InvalidTag)


@pytest.fixture
def registry(tmp_path):
    return SubjectRegistry(tmp_path / "technical-checked-startup.sqlite3", key=KEY)


def capture(registry, request_id=None):
    return registry.audited_active_twin(
        action="inspect", request_id=request_id or str(uuid4()), _checked_snapshot=True,
    )


def confirm(registry, snapshot, request_id=None):
    return registry.confirm_active_selection(
        expected_record=snapshot.record, request_id=request_id or str(uuid4()),
        _expected_snapshot=snapshot,
    )


def operation(registry, kind, snapshot, request_id):
    return capture(registry, request_id) if kind == "capture" else confirm(registry, snapshot, request_id)


def connection_factory(registry, factory):
    connection = sqlite3.connect(registry.path, factory=factory)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    return connection


def no_success(registry, request_id):
    assert not any(event[2]["outcome_code"] == "SUCCESS" for event in events(registry, request_id))


@pytest.mark.parametrize("human", [False, True])
def test_checked_capture_returns_detached_full_row_pointer_and_authority(registry, human):
    record = seed(registry, active=True, human=human)
    if human:
        record["model_binding"] = None
        replace_fixture_record(registry, record)
    before = rows(registry); request = str(uuid4())
    result = capture(registry, request)
    assert type(result) is subjects.CheckedActiveSelection
    assert result.store_id == registry.audit.store_id
    assert type(result.authority_token) is str and result.authority_token
    assert result.request_id == request and result._rows == tuple(before["records"])
    assert result._pointer == next(row for row in before["registry_state"] if row[0] == "active_twin_id")
    assert result._active_ids == (record["twin_id"],)
    assert result._record_json == canonical(record) and result.record == record
    assert "Authored software fixture" not in repr(result)
    with pytest.raises(FrozenInstanceError): result.request_id = str(uuid4())
    detached = result.record
    detached["observations"]["glucose_mgdl"]["value"] = 999
    detached["parameter_provenance"].clear()
    assert result.record == record and rows(registry) == before
    assert [event[2]["outcome_code"] for event in events(registry, request)] == [None, "SUCCESS"]


def test_checked_absence_requires_no_pointer_and_no_active_rows(registry):
    seed(registry)
    before = rows(registry)
    result = capture(registry)
    assert type(result) is subjects.CheckedActiveSelection
    assert result.record is None and result._record_json == b"null"
    assert result._rows == result._active_ids == () and result._pointer is None
    assert confirm(registry, result) is None and rows(registry) == before


@pytest.mark.parametrize("damage", ["orphan", "missing", "inactive", "type", "second_active", "payload_id", "payload_version_bool"])
def test_checked_read_rejects_dangling_inactive_or_multiple_active_topology(registry, damage):
    record = seed(registry, active=True)
    if damage == "second_active":
        second = seed(registry, "second"); second["lifecycle"] = "ACTIVE"
        replace_fixture_record(registry, second)
    elif damage == "payload_version_bool":
        record["version"] = True; replace_fixture_record(registry, record)
    else:
        with closing(registry._connect()) as connection, connection:
            if damage == "orphan": connection.execute("DELETE FROM registry_state WHERE state_key='active_twin_id'")
            elif damage == "missing": connection.execute("UPDATE registry_state SET state_value='twin-missing' WHERE state_key='active_twin_id'")
            elif damage == "inactive": connection.execute("UPDATE records SET lifecycle='DATA_ADMITTED'")
            elif damage == "type": connection.execute("UPDATE records SET record_type='COHORT'")
            else:
                nonce, encrypted = registry._seal(record["twin_id"], {**record, "twin_id": "twin-different"})
                connection.execute("UPDATE records SET nonce=?,ciphertext=?", (nonce, encrypted))
    before = rows(registry); request = str(uuid4())
    with pytest.raises(SubjectRegistryError) as caught: capture(registry, request)
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE"
    assert rows(registry) == before
    no_success(registry, request)


@pytest.mark.parametrize("field,value", [
    ("record_id", "twin-other"), ("record_type", "COHORT"), ("source_class", "REAL_HUMAN"),
    ("lifecycle", "DATA_ADMITTED"), ("version", 2), ("idempotency_key", "technical-new-key"),
    ("request_hash", "b" * 64), ("created_at", "2026-09-01T00:00:00Z"),
    ("updated_at", "2026-09-01T00:00:00Z"), ("nonce", b"n" * 12), ("ciphertext", b"invalid-fixture"),
    ("pointer_timestamp", "2026-09-01T00:00:00Z"),
])
def test_confirmation_rejects_each_sql_field_ciphertext_or_pointer_timestamp_change(registry, field, value):
    record = seed(registry, active=True); result = capture(registry)
    # Raw index corruption deliberately does not repair authenticated content.
    with closing(sqlite3.connect(registry.path)) as connection, connection:
        if field == "pointer_timestamp":
            connection.execute("UPDATE registry_state SET updated_at=? WHERE state_key='active_twin_id'", (value,))
        else:
            connection.execute(f"UPDATE records SET {field}=? WHERE record_id=?", (value, record["twin_id"]))
    before = rows(registry); request = str(uuid4())
    with pytest.raises(SAFE_STORAGE_ERRORS) as caught: confirm(registry, result, request)
    if field in {"idempotency_key", "request_hash", "pointer_timestamp"}:
        assert caught.value.code == "SELECTION_RECONCILIATION_CONFLICT"
    assert rows(registry) == before
    no_success(registry, request)


@pytest.mark.parametrize("change", ["same_version_payload", "same_plaintext_new_ciphertext"])
def test_confirmation_rejects_authenticated_same_version_changes(registry, change):
    record = seed(registry, active=True); result = capture(registry)
    if change == "same_version_payload": record["display_label"] = "Authored changed label"
    replace_fixture_record(registry, record)
    before = rows(registry); request = str(uuid4())
    with pytest.raises(SubjectRegistryError) as caught: confirm(registry, result, request)
    assert caught.value.code == "SELECTION_RECONCILIATION_CONFLICT"
    assert rows(registry) == before
    no_success(registry, request)


def test_confirmation_rejects_authority_adoption_before_protected_read(tmp_path, monkeypatch):
    from livemorebio.tests.test_registry_bootstrap_contract import legacy_audited_store
    registry = SubjectRegistry(legacy_audited_store(tmp_path), key=KEY)
    record = registry.get_twin("twin-fixture-one")
    record["lifecycle"] = "ACTIVE"; replace_fixture_record(registry, record)
    with closing(registry._connect()) as connection, connection:
        connection.execute("INSERT INTO registry_state VALUES('active_twin_id',?,?)", (record["twin_id"], CAPTURED))
    result = capture(registry)
    assert result.record == record and result.authority_token.startswith("legacy:")
    SubjectRegistry(registry.path, key=KEY).adopt_audit_authority()
    before = rows(registry)
    original_open = registry._open
    monkeypatch.setattr(registry, "_open", lambda *_a: pytest.fail("old authority decrypted clinical data"))
    with pytest.raises((SubjectRegistryError, RegistryAuditError)): confirm(registry, result)
    assert rows(registry) == before
    monkeypatch.setattr(registry, "_open", original_open)
    fresh = capture(registry)
    assert fresh.authority_token.startswith("proof:") and fresh.record == record


@pytest.mark.parametrize("initially_present", [False, True])
def test_absence_to_selected_and_selected_to_absence_never_confirm(registry, initially_present):
    record = seed(registry, active=initially_present); result = capture(registry)
    record["lifecycle"] = "DATA_ADMITTED" if initially_present else "ACTIVE"
    replace_fixture_record(registry, record)
    with closing(registry._connect()) as connection, connection:
        if initially_present: connection.execute("DELETE FROM registry_state WHERE state_key='active_twin_id'")
        else: connection.execute("INSERT INTO registry_state VALUES('active_twin_id',?,?)", (record["twin_id"], CAPTURED))
    before = rows(registry)
    with pytest.raises(SubjectRegistryError) as caught: confirm(registry, result)
    assert caught.value.code == "SELECTION_RECONCILIATION_CONFLICT" and rows(registry) == before


@pytest.mark.parametrize("field,value", [
    ("store_id", "foreign-store"), ("store_id", []), ("authority_token", ""), ("authority_token", None),
    ("request_id", "invalid"), ("_rows", []), ("_rows", (("bad",),)),
    ("_pointer", []), ("_pointer", ("active_twin_id", "twin-other", CAPTURED)),
    ("_active_ids", []), ("_active_ids", ("twin-other",)),
    ("_record_json", "{}"), ("_record_json", b"null"), ("_record_json", b'{"value":NaN}'),
])
def test_foreign_or_malformed_capture_rejected_before_protected_read(registry, monkeypatch, field, value):
    seed(registry, active=True); result = capture(registry)
    forged = replace(result, **{field: value})
    monkeypatch.setattr(registry, "_connect", lambda: pytest.fail("invalid snapshot reached storage"))
    with pytest.raises((SubjectRegistryError, RegistryAuditError)):
        registry.confirm_active_selection(expected_record=result.record, request_id=str(uuid4()), _expected_snapshot=forged)


@pytest.mark.parametrize("damage", ["row_bool", "row_mutable", "row_bytes", "record_spacing", "absence_rows", "forged_type", "subclass", "different_expected"])
def test_private_snapshot_shape_and_canonical_identity_reject_before_io(registry, monkeypatch, damage):
    record = seed(registry, active=True); result = capture(registry)
    expected = result.record
    if damage.startswith("row_"):
        row = list(result._rows[0])
        if damage == "row_bool": row[4] = True
        elif damage == "row_bytes": row[10] = bytearray(row[10])
        forged = replace(result, _rows=(row if damage == "row_mutable" else tuple(row),))
    elif damage == "record_spacing": forged = replace(result, _record_json=json.dumps(record).encode())
    elif damage == "absence_rows": forged = replace(result, _record_json=b"null", _pointer=None, _active_ids=())
    elif damage == "forged_type": forged = dict(result.__dict__)
    elif damage == "subclass":
        class PretendedSelection(type(result)): pass
        forged = PretendedSelection(**result.__dict__)
    else:
        forged = result; expected["display_label"] = "Authored different expectation"
    monkeypatch.setattr(registry, "_connect", lambda: pytest.fail("malformed private snapshot reached storage"))
    with pytest.raises((SubjectRegistryError, RegistryAuditError)):
        registry.confirm_active_selection(expected_record=expected, request_id=str(uuid4()), _expected_snapshot=forged)


@pytest.mark.parametrize("mode", [1, 0, None, "true", [], {}])
def test_checked_flag_requires_real_boolean_before_io(registry, monkeypatch, mode):
    monkeypatch.setattr(registry, "_connect", lambda: pytest.fail("bad internal mode reached storage"))
    with pytest.raises(SubjectRegistryError):
        registry.audited_active_twin(request_id=str(uuid4()), _checked_snapshot=mode)


@pytest.mark.parametrize("request_id", [None, "", "bad", " " + str(uuid4()), [], 1])
def test_checked_capture_requires_explicit_canonical_request_before_io(registry, monkeypatch, request_id):
    monkeypatch.setattr(registry, "_connect", lambda: pytest.fail("bad request reached storage"))
    with pytest.raises(SubjectRegistryError):
        registry.audited_active_twin(request_id=request_id, _checked_snapshot=True)


@pytest.mark.parametrize("action", ["source_capture", "select_observations", "bind"])
def test_checked_capture_restricts_action_to_reviewed_allowlist_before_io(registry, monkeypatch, action):
    monkeypatch.setattr(registry, "_connect", lambda: pytest.fail("bad checked action reached storage"))
    with pytest.raises(SubjectRegistryError):
        registry.audited_active_twin(action=action, request_id=str(uuid4()), _checked_snapshot=True)


@pytest.mark.parametrize("request_id", [None, "", "bad", " " + str(uuid4()), [], 1])
def test_checked_confirmation_rejects_invalid_request_before_io(registry, monkeypatch, request_id):
    seed(registry, active=True); result = capture(registry)
    monkeypatch.setattr(registry, "_connect", lambda: pytest.fail("bad confirmation request reached storage"))
    with pytest.raises(SubjectRegistryError):
        registry.confirm_active_selection(expected_record=result.record, request_id=request_id, _expected_snapshot=result)


@pytest.mark.parametrize("kind", ["capture", "confirm"])
@pytest.mark.parametrize("phase", ["begin", "reservation_insert", "terminal", "reservation_delete"])
@pytest.mark.parametrize("damage", ["record", "pointer", "absence", "topology"])
def test_begin_reservation_and_terminal_triggers_cannot_change_confirmed_readset(registry, monkeypatch, kind, phase, damage):
    record = seed(registry, active=True); extra = seed(registry, "extra")
    result = capture(registry) if kind == "confirm" else None
    before = rows(registry); request = str(uuid4())
    bodies = {
        "record": f"UPDATE records SET version=999 WHERE record_id='{record['twin_id']}';",
        "pointer": "UPDATE registry_state SET updated_at='changed' WHERE state_key='active_twin_id';",
        "absence": "DELETE FROM registry_state WHERE state_key='active_twin_id';",
        "topology": f"UPDATE records SET lifecycle='ACTIVE' WHERE record_id='{extra['twin_id']}';",
    }
    table = "registry_audit" if phase in {"begin", "terminal"} else "registry_audit_reservations"
    timing = "DELETE" if phase == "reservation_delete" else "INSERT"
    when = (" WHEN " + ("NOT " if phase == "begin" else "") + "EXISTS(SELECT 1 FROM registry_audit_reservations)") if table == "registry_audit" else ""
    with closing(registry._connect()) as connection, connection:
        connection.execute(f"CREATE TRIGGER technical_checked_phase AFTER {timing} ON {table}{when} BEGIN {bodies[damage]} END")
    opens = []; original = registry._open
    def opened(row): opens.append(row["record_id"]); return original(row)
    monkeypatch.setattr(registry, "_open", opened)
    with pytest.raises((SubjectRegistryError, RegistryAuditError)): operation(registry, kind, result, request)
    assert rows(registry) == before
    assert len(opens) == (0 if phase in {"begin", "reservation_insert"} else 1)
    no_success(registry, request)


@pytest.mark.parametrize("kind", ["capture", "confirm"])
@pytest.mark.parametrize("damage", ["reservation_delete", "reservation_request", "begin_sequence"])
def test_reentry_authenticates_original_begin_and_reservation_before_decrypt(registry, monkeypatch, kind, damage):
    seed(registry, active=True); result = capture(registry) if kind == "confirm" else None
    before = rows(registry)
    class ChangedReservation(sqlite3.Connection):
        commits = 0
        def commit(self):
            self.commits += 1; super().commit()
            if self.commits == 1:
                with closing(sqlite3.connect(registry.path)) as other, other:
                    if damage == "reservation_delete": other.execute("DELETE FROM registry_audit_reservations")
                    elif damage == "reservation_request": other.execute("UPDATE registry_audit_reservations SET request_id=?", (str(uuid4()),))
                    else: other.execute("UPDATE registry_audit SET sequence=sequence+100 WHERE sequence=(SELECT MAX(sequence) FROM registry_audit)")
    monkeypatch.setattr(registry, "_connect", lambda: connection_factory(registry, ChangedReservation))
    monkeypatch.setattr(registry, "_open", lambda *_a: pytest.fail("unverified reserved access decrypted"))
    with pytest.raises(RegistryAuditError): operation(registry, kind, result, str(uuid4()))
    assert rows(registry) == before


@pytest.mark.parametrize("kind", ["capture", "confirm"])
def test_audit_is_durable_before_decrypt_and_at_most_one_record_opens(registry, monkeypatch, kind):
    record = seed(registry, active=True); result = capture(registry) if kind == "confirm" else None
    request = str(uuid4()); opens = []; original = registry._open
    original_snapshot = registry._transition_snapshot
    def snapshot(connection, target, fingerprint):
        assert connection.in_transaction and target is fingerprint is None
        return original_snapshot(connection, target, fingerprint)
    def opened(row):
        current = events(registry, request)
        assert len(current) == 1 and current[0][2]["outcome_code"] is None
        assert current[0][2]["action"] == ("inspect" if kind == "capture" else "reconcile_selection")
        with closing(sqlite3.connect(registry.path)) as connection:
            assert connection.execute("SELECT event_id,request_id FROM registry_audit_reservations WHERE request_id=?", (request,)).fetchall() == [(current[0][0], request)]
        opens.append(row["record_id"])
        return original(row)
    monkeypatch.setattr(registry, "_transition_snapshot", snapshot); monkeypatch.setattr(registry, "_open", opened)
    operation(registry, kind, result, request)
    assert opens == [record["twin_id"]]
    assert [event[2]["outcome_code"] for event in events(registry, request)] == [None, "SUCCESS"]


@pytest.mark.parametrize("kind", ["capture", "confirm"])
def test_audit_begin_failure_prohibits_protected_read_and_checked_return(registry, monkeypatch, kind):
    seed(registry, active=True); result = capture(registry) if kind == "confirm" else None
    before = rows(registry); request = str(uuid4())
    def fail(*_a, **_k): raise RegistryAuditError()
    monkeypatch.setattr(registry.audit, "begin", fail)
    monkeypatch.setattr(registry, "_open", lambda *_a: pytest.fail("failed access admission decrypted"))
    with pytest.raises(RegistryAuditError): operation(registry, kind, result, request)
    assert rows(registry) == before and events(registry, request) == []


@pytest.mark.parametrize("kind", ["capture", "confirm"])
@pytest.mark.parametrize("phase", ["begin", "terminal"])
@pytest.mark.parametrize("persisted", [False, True])
def test_begin_or_terminal_commit_lost_ack_never_returns_checked_result(registry, monkeypatch, kind, phase, persisted):
    seed(registry, active=True); result = capture(registry) if kind == "confirm" else None
    before = rows(registry); opened = []; original = registry._open
    class LostAck(sqlite3.Connection):
        commits = 0
        def commit(self):
            self.commits += 1
            if self.commits == (1 if phase == "begin" else 2):
                if persisted: super().commit()
                raise sqlite3.OperationalError("authored private-path ACK failure")
            return super().commit()
    def tracked(row): opened.append(row["record_id"]); return original(row)
    monkeypatch.setattr(registry, "_connect", lambda: connection_factory(registry, LostAck))
    monkeypatch.setattr(registry, "_open", tracked)
    with pytest.raises(SubjectRegistryError) as caught: operation(registry, kind, result, str(uuid4()))
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE"
    assert "private-path" not in str(caught.value) and rows(registry) == before
    assert len(opened) == (0 if phase == "begin" else 1)


@pytest.mark.parametrize("kind", ["capture", "confirm"])
def test_checked_close_failure_never_returns_or_leaks_local_path(registry, monkeypatch, kind):
    seed(registry, active=True); result = capture(registry) if kind == "confirm" else None
    before = rows(registry)
    class LostClose(sqlite3.Connection):
        def close(self): super().close(); raise OSError("authored private-path close failure")
    monkeypatch.setattr(registry, "_connect", lambda: connection_factory(registry, LostClose))
    with pytest.raises(SubjectRegistryError) as caught: operation(registry, kind, result, str(uuid4()))
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE"
    assert "private-path" not in str(caught.value) and rows(registry) == before


@pytest.mark.parametrize("kind", ["capture", "confirm"])
def test_uncertain_rollback_does_not_attempt_failure_completion(registry, monkeypatch, kind):
    seed(registry, active=True); result = capture(registry) if kind == "confirm" else None
    outcomes = []
    class LostRollback(sqlite3.Connection):
        def rollback(self): raise OSError("authored rollback failure")
    def finish(*_a, outcome_code):
        outcomes.append(outcome_code)
        raise SubjectRegistryError("SELECTION_RECONCILIATION_CONFLICT", "Authored primary error")
    monkeypatch.setattr(registry, "_connect", lambda: connection_factory(registry, LostRollback))
    monkeypatch.setattr(registry.audit, "finish", finish)
    with pytest.raises(SubjectRegistryError) as caught: operation(registry, kind, result, str(uuid4()))
    assert caught.value.code == "SELECTION_COMMIT_UNCONFIRMED" and outcomes == ["SUCCESS"]


@pytest.mark.parametrize("kind", ["capture", "confirm"])
def test_failed_access_terminal_protects_new_live_selection_after_rollback(registry, monkeypatch, kind):
    selected = seed(registry, "old", active=True); next_record = seed(registry, "new")
    result = capture(registry) if kind == "confirm" else None
    selected.update(lifecycle="DATA_ADMITTED", version=2); next_record.update(lifecycle="ACTIVE", version=2)
    replacements = [(record, *registry._seal(record["twin_id"], record)) for record in (selected, next_record)]
    external_after = []; opened = []; original = registry._open; request = str(uuid4())
    class ExternalSelection(sqlite3.Connection):
        moved = False
        def rollback(self):
            super().rollback()
            if not self.moved:
                self.moved = True
                with closing(sqlite3.connect(registry.path)) as other, other:
                    for record, nonce, encrypted in replacements:
                        other.execute("UPDATE records SET lifecycle=?,version=?,nonce=?,ciphertext=? WHERE record_id=?", (record["lifecycle"], record["version"], nonce, encrypted, record["twin_id"]))
                    other.execute("UPDATE registry_state SET state_value=? WHERE state_key='active_twin_id'", (next_record["twin_id"],))
                external_after.append(rows(registry))
    original_finish = registry.audit.finish
    def finish(connection, reservation, *, outcome_code):
        if outcome_code == "SUCCESS":
            raise SubjectRegistryError("SELECTION_RECONCILIATION_CONFLICT", "Authored primary error")
        return original_finish(connection, reservation, outcome_code=outcome_code)
    def tracked(row): opened.append(row["record_id"]); return original(row)
    with closing(registry._connect()) as connection, connection:
        connection.execute("CREATE TRIGGER technical_checked_failure AFTER INSERT ON registry_audit WHEN EXISTS(SELECT 1 FROM registry_audit_reservations) BEGIN UPDATE records SET version=999 WHERE record_id=(SELECT state_value FROM registry_state WHERE state_key='active_twin_id'); END")
    monkeypatch.setattr(registry, "_connect", lambda: connection_factory(registry, ExternalSelection))
    monkeypatch.setattr(registry.audit, "finish", finish); monkeypatch.setattr(registry, "_open", tracked)
    with pytest.raises(SubjectRegistryError) as caught: operation(registry, kind, result, request)
    assert caught.value.code == "SELECTION_RECONCILIATION_CONFLICT" and str(caught.value) == "Authored primary error"
    assert len(external_after) == 1 and rows(registry) == external_after[0]
    assert opened == [selected["twin_id"]]
    assert [event[2]["outcome_code"] for event in events(registry, request)] == [None]
    with closing(sqlite3.connect(registry.path)) as connection:
        assert connection.execute("SELECT COUNT(*) FROM registry_audit_reservations WHERE request_id=?", (request,)).fetchone()[0] == 1


@pytest.mark.parametrize("kind", ["capture", "confirm"])
def test_checked_access_reuses_fixed_phase_owner_not_legacy_audited(registry, monkeypatch, kind):
    seed(registry, active=True); result = capture(registry) if kind == "confirm" else None
    monkeypatch.setattr(registry, "_audited", lambda *_a, **_k: pytest.fail("checked path used weaker generic audit owner"))
    counts = {name: 0 for name in ("_selection_audit_begin", "_selection_audit_reenter", "_selection_audit_finish")}
    for name in counts:
        original = getattr(registry, name)
        def called(*args, _name=name, _original=original, **kwargs):
            counts[_name] += 1
            return _original(*args, **kwargs)
        monkeypatch.setattr(registry, name, called)
    operation(registry, kind, result, str(uuid4()))
    assert counts["_selection_audit_begin"] == counts["_selection_audit_finish"] == 1
    assert counts["_selection_audit_reenter"] >= 2


@pytest.mark.parametrize("human", [False, True])
def test_checked_stored_maximum_is_readable_without_increment_or_model(registry, human):
    record = seed(registry, active=True, human=human, version=MAX_SAFE_INTEGER)
    if human:
        record["model_binding"] = None; replace_fixture_record(registry, record)
    before = rows(registry); result = capture(registry)
    assert type(result.record["version"]) is int and result.record["version"] == MAX_SAFE_INTEGER
    assert confirm(registry, result) is None and rows(registry) == before


def test_checked_workflow_can_share_request_but_not_event_or_reservation(registry):
    seed(registry, active=True); request = str(uuid4())
    before = rows(registry); result = capture(registry, request); first = events(registry, request)
    assert confirm(registry, result, request) is None
    combined = events(registry, request)
    assert combined[:2] == first and len(combined) == 4
    assert len({event[0] for event in combined}) == 4
    assert [event[2]["outcome_code"] for event in combined] == [None, "SUCCESS", None, "SUCCESS"]
    assert rows(registry) == before


def test_expected_record_is_canonicalized_before_audit_callback_can_mutate_it(registry, monkeypatch):
    seed(registry, active=True); result = capture(registry)
    expected = result.record; before = rows(registry); original_begin = registry.audit.begin
    def begin(*args, **kwargs):
        expected["observations"]["glucose_mgdl"]["value"] = 999
        return original_begin(*args, **kwargs)
    monkeypatch.setattr(registry.audit, "begin", begin)
    assert registry.confirm_active_selection(expected_record=expected, request_id=str(uuid4()), _expected_snapshot=result) is None
    assert expected != result.record and rows(registry) == before


@pytest.mark.parametrize("present", [False, True])
def test_default_audited_active_and_confirm_signatures_keep_existing_callers(registry, present):
    record = seed(registry, active=present); before = rows(registry)
    expected = record if present else None
    assert registry.audited_active_twin() == expected
    assert registry.confirm_active_selection(expected_record=expected, request_id=str(uuid4())) is None
    assert rows(registry) == before


def test_explicit_false_keeps_default_record_return_shape(registry):
    record = seed(registry, active=True)
    assert registry.audited_active_twin(_checked_snapshot=False) == record


def test_checked_topology_rejects_nonexact_string_scalar_before_io(registry, monkeypatch):
    seed(registry, active=True); result = capture(registry)
    class PretendedId(str): pass
    forged = replace(result, _active_ids=(PretendedId(result._active_ids[0]),))
    monkeypatch.setattr(registry, "_connect", lambda: pytest.fail("nonexact topology scalar reached storage"))
    with pytest.raises(SubjectRegistryError):
        registry.confirm_active_selection(expected_record=result.record, request_id=str(uuid4()),
                                          _expected_snapshot=forged)
