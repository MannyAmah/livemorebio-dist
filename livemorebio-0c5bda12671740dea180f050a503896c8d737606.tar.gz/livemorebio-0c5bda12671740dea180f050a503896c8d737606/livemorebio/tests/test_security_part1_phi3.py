"""PHI-3 technical fixtures only: no observed patients or real physiology."""
from __future__ import annotations

from copy import deepcopy
import json
from types import SimpleNamespace
from uuid import UUID

import pytest

from livemorebio import audit
from livemorebio.sdk import Platform


PROFILE = "Technical TESTNOTEPROFILE 61F"
SUBJECT = "technical-subject-phi3"
GLUCOSE = 137.5621
HEART_RATE = 71.0431
HRV = 35.0241
BASE_GLUCOSE = 92.205123
INSULIN_SENSITIVITY = 0.000479123
PK_VALUE = 4.271821
MEAL_GRAMS = 75.62391


@pytest.fixture
def technical_log(tmp_path, monkeypatch):
    directory = tmp_path / "technical-audit"
    monkeypatch.setattr(audit, "LM_DIR", str(directory))
    monkeypatch.setattr(audit, "KEY_PATH", str(directory / "technical-hmac.key"))
    monkeypatch.setattr(audit, "LOG_PATH", str(directory / "pipeline-audit.jsonl"))
    monkeypatch.setattr(audit, "provenance", lambda: {"fixture": "technical-only"})
    return directory / "pipeline-audit.jsonl"


def _platform(mode):
    platform = object.__new__(Platform)
    platform.mode = mode
    return platform


def _assert_minimized(path, action, mode, sentinels):
    written = path.read_text(encoding="utf-8")
    for sentinel in sentinels:
        assert str(sentinel) not in written
    record = json.loads(written)
    assert record["action"] == action
    assert str(UUID(record["id"])) == record["id"]
    assert isinstance(record["ts"], (int, float))
    assert record["inputs"]["actor"] == "local_operator"
    assert record["inputs"]["mode"] == mode
    digest = record["inputs"]["content_sha256"]
    assert len(digest) == 64 and int(digest, 16) >= 0
    assert record["outputs"] == {"outcome": "COMPLETED"}
    assert audit.verify(record)
    return record


@pytest.mark.parametrize("mode", ["attach", "inprocess"])
def test_PHI_3_perturb_log_omits_profile_and_physiology(technical_log, monkeypatch, mode):
    state = {"profile": PROFILE, "human": {"id": SUBJECT},
             "metabolic": {"mean_glucose": GLUCOSE},
             "cardiac": {"hr_bpm": HEART_RATE, "hrv_ms": HRV}}
    platform = _platform(mode)
    platform._twin = SimpleNamespace(stimulate=lambda *args, **kwargs: deepcopy(state))
    monkeypatch.setattr(platform, "_post", lambda *args: deepcopy(state))
    result = platform.perturb(kind="meal", grams=MEAL_GRAMS)
    assert result["profile"] == PROFILE and result["mean_glucose"] == GLUCOSE
    record = _assert_minimized(technical_log, "perturb", mode,
                              [PROFILE, SUBJECT, GLUCOSE, HEART_RATE, HRV, MEAL_GRAMS])
    assert record["inputs"]["content_sha256"] == audit.content_hash({
        "inputs": {"kind": "meal", "compound": None, "dose": 1.0,
                   "params": {"grams": MEAL_GRAMS}}, "outputs": result,
    })


@pytest.mark.parametrize("mode", ["attach", "inprocess"])
def test_PHI_3_assay_log_omits_baseline_profile_and_pk(technical_log, monkeypatch, mode):
    from livemorebio.cendos import assays
    from livemorebio.engines import pharmacology

    profile = SimpleNamespace(name=PROFILE, weight_kg=83.7193, Gb=BASE_GLUCOSE,
                              Ib=12.3581, Si=INSULIN_SENSITIVITY,
                              gamma=0.123765, Gt=101.78291, SG=0.018327)
    output = {"decision": "EFFECT", "delta_mean": -12.78361,
              "delta_iAUC": -173.49321, "rel_mean": -0.139871,
              "subject": PROFILE, "pk": {"hepatic_exposure_ratio": PK_VALUE}}
    platform = _platform(mode)
    platform._twin = SimpleNamespace(profile=profile, human=SimpleNamespace(id=SUBJECT))
    monkeypatch.setattr(platform, "_post", lambda *args: deepcopy(output))
    monkeypatch.setattr(pharmacology, "metformin", lambda *args: (
        profile, {"pk": {"hepatic_exposure_ratio": PK_VALUE}}))
    monkeypatch.setattr(assays, "ogtt_effect", lambda *args, **kwargs: deepcopy(output))
    result = platform.assay_ogtt(grams=MEAL_GRAMS)
    assert result["subject"] == PROFILE and result["pk"]["hepatic_exposure_ratio"] == PK_VALUE
    record = _assert_minimized(technical_log, "assay.ogtt", mode, [
        PROFILE, SUBJECT, BASE_GLUCOSE, INSULIN_SENSITIVITY, PK_VALUE,
        MEAL_GRAMS, -12.78361, -173.49321, -0.139871,
    ])
    assert result["audit_id"] == record["id"]


def test_PHI_3_workspace_log_omits_submitted_values(technical_log, monkeypatch):
    platform = _platform("attach")
    output = {"action": {"action_id": "technical-action-phi3", "status": "COMPLETED"},
              "workspace": {"profile": PROFILE, "mean_glucose": GLUCOSE}}
    monkeypatch.setattr(platform, "_post", lambda *args: deepcopy(output))
    result = platform.workspace_action("meal", grams=MEAL_GRAMS)
    assert result == output
    _assert_minimized(technical_log, "workspace.action", "attach",
                      [PROFILE, GLUCOSE, MEAL_GRAMS])


def test_PHI_3_screen_log_omits_ranked_physiology(technical_log, monkeypatch):
    from livemorebio.cendos import assays
    from livemorebio.engines import pharmacology
    from livemorebio.life_system import knowledge

    platform = _platform("inprocess")
    profile = SimpleNamespace(name=PROFILE)
    human = SimpleNamespace(id=SUBJECT, age=61, sex="F",
                            conditions=["technical-condition-phi3"],
                            metabolic_profile=lambda kb: profile)
    platform._cohort = [human]
    platform._cohort_context, platform._cohort_seed, platform._cohort_n = "type-2-diabetes", 7, 1
    monkeypatch.setattr(knowledge, "get_kb", lambda: None)
    monkeypatch.setattr(pharmacology, "metformin", lambda *args: (profile, {
        "pk": {"hepatic_exposure_ratio": PK_VALUE}, "oct1_lof_alleles": 1,
        "oct1_transport": 0.78391, "renal_factor": 0.89123,
    }))
    monkeypatch.setattr(assays, "ogtt_effect", lambda *args, **kwargs: {
        "baseline": {"mean": GLUCOSE}, "delta_mean": -12.78361,
        "delta_iAUC": -173.49321, "rel_mean": -0.139871, "decision": "EFFECT",
    })
    result = platform.screen(n=1, seed=7, grams=MEAL_GRAMS)
    assert result["ranked"][0]["baseline_mean"] == GLUCOSE
    record = _assert_minimized(technical_log, "screen.cohort_ogtt", "inprocess", [
        PROFILE, SUBJECT, GLUCOSE, PK_VALUE, MEAL_GRAMS, "technical-condition-phi3",
        -12.78361, -173.49321, -0.139871, 0.78391, 0.89123,
    ])
    assert result["audit"] == record


def test_PHI_3_actual_technical_note_pipeline_does_not_persist_profile(technical_log):
    """The report's real SDK path, with an explicitly technical authored note.

    L0-R15: the note is refused before it is parsed, kept or audited, and the
    pipeline continues on the technical route (explicit structured fields).
    """
    from .test_l0_clinical_note_gate import assert_note_refused

    platform = Platform(mode="inprocess")
    before = technical_log.read_text(encoding="utf-8") if technical_log.exists() else ""
    assert_note_refused(lambda: platform.patient(note=(
        "Technical fixture only: Jane PROBEDOE 61 yo F, T2DM on metformin, HbA1c 9.4"
    )))
    after = technical_log.read_text(encoding="utf-8") if technical_log.exists() else ""
    assert after == before and "PROBEDOE" not in after
    platform.patient(age=61, sex="F", conditions=["Type 2 diabetes mellitus"])
    result = platform.perturb(kind="meal", grams=75)
    assay = platform.assay_ogtt()
    records = [json.loads(line) for line in technical_log.read_text(encoding="utf-8").splitlines()]
    written = json.dumps(records, ensure_ascii=False)
    assert result["profile"] not in written
    assert str(result["mean_glucose"]) not in written
    assert assay["subject"] not in written
    assert "baseline_profile" not in written
    assert "hepatic_exposure_ratio" not in written
    assert all(audit.verify(record) for record in records)
    assert records[-1]["id"] == assay["audit_id"]
