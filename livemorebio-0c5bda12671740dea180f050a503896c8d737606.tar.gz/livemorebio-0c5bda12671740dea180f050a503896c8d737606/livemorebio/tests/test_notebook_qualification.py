"""Exact installed-version gate, using technical package metadata only."""
from __future__ import annotations

from importlib import metadata

import pytest

from livemorebio.tests._notebook import require_qualified_notebook_packages


QUALIFIED = {"jupyter-server": "2.21.0", "jupyterlab": "4.6.4", "tornado": "6.5.9"}


def test_qualified_notebook_gate_runs_on_exact_pins(monkeypatch):
    lookups = []

    def version(name):
        lookups.append(name)
        return QUALIFIED[name]

    monkeypatch.setattr(metadata, "version", version)
    assert require_qualified_notebook_packages() is None
    assert lookups == list(QUALIFIED)


@pytest.mark.parametrize("package,reported", [
    (name, version) for name in QUALIFIED
    for version in ("0.0.technical", "newer", "prerelease", "missing")
] + [("jupyter-server", "2.20.0"), ("jupyterlab", "4.6.3"), ("tornado", "6.5.8")])
def test_qualified_notebook_gate_skips_every_nonexact_pin(monkeypatch, package, reported):
    installed = dict(QUALIFIED)
    installed[package] = {"newer": QUALIFIED[package] + ".post1",
                          "prerelease": QUALIFIED[package] + "rc1"}.get(reported, reported)

    def version(name):
        if installed[name] == "missing":
            raise metadata.PackageNotFoundError(name)
        return installed[name]

    monkeypatch.setattr(metadata, "version", version)
    with pytest.raises(pytest.skip.Exception) as skipped:
        require_qualified_notebook_packages()
    reason = str(skipped.value)
    assert reason.startswith("Notebook integration requires ")
    required, actual = reason.split("; installed ")
    for name, pin in QUALIFIED.items():
        assert f"{name}=={pin}" in required
        assert f"{name}=={installed[name]}" in actual
