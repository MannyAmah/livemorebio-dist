"""Pure conversion fixtures are labeled technical; never admitted as source anatomy."""
from __future__ import annotations

import hashlib
import importlib
import json
import struct

import numpy as np
import pytest


@pytest.fixture
def geometry():
    return importlib.import_module("livemorebio.anatomy._atlas_geometry")


def technical_obj():
    raw = b"""# Compatibility version : 4.0
# File ID : FJ2810
# Representation ID : BP9115
# Concept ID : FMA7163
# English name : TECHNICAL TRIANGLE NOT HUMAN ANATOMY
v -334.119 -246.783 -78.1112
v 332.825 -246.783 -78.1112
v 0 45.2476 1641.36
vn 0 0 1
vn 0 0 1
vn 0 0 1
g technical
usemtl technical
f 1//1 2//2 3//3
"""
    member = {"element_id":"FJ2810", "representation_id":"BP9115", "concept_id":"FMA7163",
              "compatibility_version":"4.0", "name":"TECHNICAL TRIANGLE NOT HUMAN ANATOMY",
              "source_bytes":len(raw), "source_sha256":hashlib.sha256(raw).hexdigest(),
              "vertices":3, "triangles":1,
              "bounds_mm":[[-334.119,-246.783,-78.1112],[332.825,45.2476,1641.36]]}
    return raw, member


def replace_source(raw, member, old, new):
    changed = raw.replace(old, new)
    return changed, {**member, "source_bytes":len(changed), "source_sha256":hashlib.sha256(changed).hexdigest()}


def test_parser_preserves_native_coordinates_normals_and_indices(geometry):
    raw, member = technical_obj()
    parsed = geometry.parse_obj(raw, member)
    np.testing.assert_array_equal(parsed["faces"], [[0,1,2]])
    np.testing.assert_array_equal(parsed["normals"], [[0,0,1]]*3)
    np.testing.assert_array_equal(parsed["vertices"][0], [-334.119,-246.783,-78.1112])
    assert parsed["element_id"] == "FJ2810"


def test_source_hash_checked_before_parse(geometry):
    raw, member = technical_obj()
    with pytest.raises(ValueError, match="source"):
        geometry.parse_obj(raw + b"# tamper", member)


@pytest.mark.parametrize("old,new", [
    (b"v 0 45.2476 1641.36",b"v nan 45.2476 1641.36"),
    (b"v 0 45.2476 1641.36",b"v 0 inf 1641.36"),
    (b"v 0 45.2476 1641.36",b"v 0 45.2476 1641.36 1"),
    (b"f 1//1 2//2 3//3",b"f 0//0 2//2 3//3"),
    (b"f 1//1 2//2 3//3",b"f -1//1 2//2 3//3"),
    (b"f 1//1 2//2 3//3",b"f 4//4 2//2 3//3"),
    (b"f 1//1 2//2 3//3",b"f 1//2 2//2 3//3"),
    (b"f 1//1 2//2 3//3",b"f 1/1/1 2/2/2 3/3/3"),
    (b"f 1//1 2//2 3//3",b"f 1//1 2//2 3//3 1//1"),
    (b"g technical",b"mtllib https://example.invalid/material"),
    (b"g technical",b"vt 0 1"),
    (b"# File ID : FJ2810",b"# File ID : FJ2811"),
    (b"# File ID : FJ2810",b"# File ID : FJ2810\n# File ID : FJ2810"),
    (b"# Compatibility version : 4.0",b"# Compatibility version : 5.0"),
])
def test_malformed_or_geometry_changing_directives_rejected(geometry, old, new):
    raw, member = replace_source(*technical_obj(), old, new)
    with pytest.raises(ValueError):
        geometry.parse_obj(raw, member)


@pytest.mark.parametrize("key,value", [("vertices",2),("triangles",2),("name","wrong"),("bounds_mm",[[0,0,0],[1,1,1]])])
def test_source_declaration_mismatch_rejected(geometry, key, value):
    raw, member = technical_obj()
    with pytest.raises(ValueError):
        geometry.parse_obj(raw, {**member,key:value})


def test_export_is_standard_meter_scene_with_once_only_root(geometry):
    raw, member = technical_obj()
    parsed = geometry.parse_obj(raw, member)
    result = geometry.convert_partition("skin", [parsed])
    assert isinstance(result, bytes) and result[:4] == b"glTF"
    verified = geometry.verify_partition(result, "skin", [parsed])
    assert verified["element_ids"] == ["FJ2810"]
    assert verified["vertices"] == 3 and verified["triangles"] == 1
    assert verified["maximum_position_error_mm"] <= 1e-4
    assert verified["maximum_world_error_m"] <= 2e-7
    assert verified["maximum_normal_error"] <= 1e-7
    assert verified["source_zero_area_triangles"] == 0
    assert geometry.convert_partition("skin", [parsed]) == result


def test_source_degenerate_triangle_is_retained_not_repaired(geometry):
    raw, member = technical_obj()
    raw, member = replace_source(raw, member, b"v 0 45.2476 1641.36", b"v -334.119 -246.783 -78.1112")
    member["bounds_mm"] = [[-334.119,-246.783,-78.1112],[332.825,-246.783,-78.1112]]
    parsed = geometry.parse_obj(raw, member)
    result = geometry.convert_partition("skin", [parsed])
    verified = geometry.verify_partition(result, "skin", [parsed])
    assert verified["triangles"] == 1
    assert verified["source_zero_area_triangles"] == 1
    assert verified["introduced_zero_area_triangles"] == 0
    assert verified["nodes"][0]["source_zero_area_triangle_indices"] == [0]


def reencode(tree, binary):
    encoded = json.dumps(tree, separators=(",", ":")).encode()
    encoded += b" " * (-len(encoded) % 4)
    return (struct.pack("<4sII", b"glTF", 2, 28+len(encoded)+len(binary)) +
            struct.pack("<I4s", len(encoded), b"JSON") + encoded +
            struct.pack("<I4s", len(binary), b"BIN\0") + binary)


@pytest.mark.parametrize("mutation", ["root_twice", "child_shift", "uri", "image", "animation", "morph", "wrong_id", "position", "normal", "indices", "target", "trailing_binary"])
def test_independent_decoder_rejects_substitution_and_unreviewed_features(geometry, mutation):
    parsed = geometry.parse_obj(*technical_obj())
    raw = geometry.convert_partition("skin", [parsed])
    tree, binary = geometry._decode(raw)
    if mutation == "root_twice":
        tree["nodes"][0]["matrix"][0] *= .001
    elif mutation == "child_shift":
        tree["nodes"][1]["translation"] = [1, 0, 0]
    elif mutation == "uri":
        tree["buffers"][0]["uri"] = "https://example.invalid/substitute.bin"
    elif mutation == "image":
        tree["images"] = [{"uri": "https://example.invalid/image"}]
    elif mutation == "animation":
        tree["animations"] = []
    elif mutation == "morph":
        tree["meshes"][0]["primitives"][0]["targets"] = [{"POSITION": 1}]
    elif mutation == "wrong_id":
        tree["nodes"][1]["name"] = "bp3d:FJ0000"
    elif mutation == "target":
        tree["bufferViews"][0]["target"] = 12345
    elif mutation == "trailing_binary":
        binary += b"EVIL"
        tree["buffers"][0]["byteLength"] += 4
    else:
        primitive = tree["meshes"][0]["primitives"][0]
        index = primitive["indices"] if mutation == "indices" else primitive["attributes"]["POSITION" if mutation == "position" else "NORMAL"]
        accessor = tree["accessors"][index]
        view = tree["bufferViews"][accessor["bufferView"]]
        offset = view.get("byteOffset", 0) + accessor.get("byteOffset", 0)
        changed = bytearray(binary)
        struct.pack_into("<I" if mutation == "indices" else "<f", changed, offset, 2 if mutation == "indices" else 1000.)
        binary = bytes(changed)
    with pytest.raises(ValueError):
        geometry.verify_partition(reencode(tree, binary), "skin", [parsed])


def test_distinct_source_nodes_survive_export_even_with_identical_arrays(geometry):
    raw, member = technical_obj()
    one = geometry.parse_obj(raw, member)
    raw, member = replace_source(raw, member, b"FJ2810", b"FJ2811")
    member["element_id"] = "FJ2811"
    two = geometry.parse_obj(raw, member)
    result = geometry.convert_partition("heart", [two, one])
    audit = geometry.verify_partition(result, "heart", [two, one])
    assert audit["element_ids"] == ["FJ2810", "FJ2811"]
    assert audit["triangles"] == 2 and audit["vertices"] == 6


@pytest.mark.parametrize("content", [b'{"bad":1e999}', b'{"bad":NaN}', b'{"bad":1,"bad":2}', b'{"bad":'+b'['*70+b'0'+b']'*70+b'}'])
def test_glb_json_is_finite_unique_and_bounded_depth(geometry, content):
    content += b" "*(-len(content)%4)
    raw = struct.pack("<4sII", b"glTF", 2, 28+len(content)) + struct.pack("<I4s", len(content), b"JSON") + content + struct.pack("<I4s", 0, b"BIN\0")
    with pytest.raises(ValueError):
        geometry._decode(raw)


@pytest.mark.parametrize("mutation", ["scene_boolean", "child_boolean", "accessor_boolean_bounds"])
def test_node_references_and_numeric_bounds_are_not_boolean_aliases(geometry, mutation):
    parsed = geometry.parse_obj(*technical_obj())
    raw = geometry.convert_partition("skin", [parsed])
    tree, binary = geometry._decode(raw)
    if mutation == "scene_boolean":
        tree["scenes"][0]["nodes"] = [False]
    elif mutation == "child_boolean":
        tree["nodes"][0]["children"] = [True]
    else:
        normal_index = tree["meshes"][0]["primitives"][0]["attributes"]["NORMAL"]
        tree["accessors"][normal_index]["min"] = [False, False, True]
    with pytest.raises(ValueError):
        geometry.verify_partition(reencode(tree,binary),"skin",[parsed])
