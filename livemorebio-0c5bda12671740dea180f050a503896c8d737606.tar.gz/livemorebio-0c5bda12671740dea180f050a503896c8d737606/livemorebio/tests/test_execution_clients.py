"""Attached-only continuous clients preserve server authority and private errors."""
from copy import deepcopy
import io
import json
from types import SimpleNamespace

import pytest

from livemorebio.tests.stack_client_fixtures import install_stack_client_opener

from livemorebio.sdk import Platform

IDENTITY = "a" * 32
PREPARE = {"engine_contract_id": "metabolic-continuous-v1", "expected_source_generation": "generation-a",
           "expected_twin_id": "twin-a", "expected_twin_version": 1,
           "policy": {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}}
SESSION = {"execution_id": IDENTITY, "source_snapshot_hash": "b" * 64, "device_id": "virtual-a",
           "expected_selection": {"subject_id": "pseudonym-fixture", "twin_id": "twin-a", "twin_version": 1,
               "cohort_id": None, "member_id": None, "run_id": None, "condition_id": "baseline",
               "stage": "prospective-execution", "source_data_class": "SYNTHETIC"}, "idempotency_key": "00001"}


@pytest.mark.parametrize("change", [{"twin_version": True}, {"twin_version": 1.0}, {"extra": None},
    {"cohort_id": "cohort-a"}, {"member_id": "null"}, {"run_id": ""}])
def test_session_selection_is_strict_before_transport(monkeypatch, change):
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_continuous_request", lambda *a, **kw: pytest.fail("invalid selection reached HTTP"))
    body = deepcopy(SESSION)
    body["expected_selection"].update(change)
    with pytest.raises(ValueError):
        platform.start_virtual_session(body)


def test_transport_failure_clears_previous_response_metadata(monkeypatch):
    from livemorebio import execution_client
    platform = Platform(mode="attach")
    platform.last_continuous_response = {"request_id": "c" * 32}
    monkeypatch.setattr(platform, "_url", lambda: "http://127.0.0.1:9999")
    monkeypatch.setattr("livemorebio.security.authorization_headers", lambda: {"Authorization": "Bearer fixture"})
    def failed(*a, **kw):
        raise OSError("PRIVATE TRANSPORT")
    install_stack_client_opener(monkeypatch, lambda *a: SimpleNamespace(open=failed))
    with pytest.raises(execution_client.ContinuousClientError) as caught:
        platform.execution_capabilities()
    assert "PRIVATE" not in str(caught.value)
    assert platform.last_continuous_response == {}


def test_response_close_failure_preserves_acknowledgment_with_safe_metadata(monkeypatch):
    from livemorebio import execution_client
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_url", lambda: "http://127.0.0.1:9999")
    monkeypatch.setattr("livemorebio.security.authorization_headers", lambda: {"Authorization": "Bearer fixture"})
    def failed():
        raise OSError("PRIVATE CLOSE")
    response = SimpleNamespace(status=200, headers={}, read=lambda n: b'{}', close=failed)
    install_stack_client_opener(monkeypatch, lambda *a: SimpleNamespace(open=lambda *a, **kw: response))
    assert platform.execution_capabilities() == {}
    assert platform.last_continuous_response == {"cleanup_code": "CLIENT_TRANSPORT"}


@pytest.mark.parametrize("key", [True, 1, "", " leading", "trailing ", "a\nb", "x" * 129])
def test_idempotency_keys_are_exact_strings_before_request(monkeypatch, key):
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_continuous_request", lambda *a, **kw: pytest.fail("invalid key reached transport"))
    with pytest.raises(ValueError):
        platform.prepare_execution(PREPARE, idempotency_key=key)
    with pytest.raises(ValueError):
        platform.start_virtual_session({**SESSION, "idempotency_key": key})


@pytest.mark.parametrize("url", ["http://example.com", "http://user:PRIVATE@127.0.0.1", "http://127.0.0.1?PRIVATE=1",
    "http://127.0.0.1#PRIVATE", "file:///PRIVATE"])
def test_transport_rejects_unsafe_attachment_without_network(monkeypatch, url):
    from livemorebio import execution_client
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_url", lambda: url)
    install_stack_client_opener(monkeypatch, lambda *a: pytest.fail("unsafe URL reached network"))
    with pytest.raises(execution_client.ContinuousClientError) as caught:
        platform.execution_capabilities()
    assert "PRIVATE" not in str(caught.value)


def test_no_redirect_or_proxy_and_mutation_timeout_never_retries(monkeypatch):
    from livemorebio import execution_client
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_url", lambda: "http://127.0.0.1:9999")
    monkeypatch.setattr("livemorebio.security.authorization_headers", lambda: {"Authorization": "Bearer fixture"})
    calls = []
    def opener(*handlers):
        def request(*a, **kw):
            calls.append(1)
            raise TimeoutError("PRIVATE TIMEOUT")
        return SimpleNamespace(open=request)
    install_stack_client_opener(monkeypatch, opener)
    with pytest.raises(execution_client.ContinuousClientError) as caught:
        platform.prepare_execution(PREPARE, idempotency_key="00001")
    assert caught.value.code == "CLIENT_UNCONFIRMED" and len(calls) == 1
    assert "PRIVATE" not in str(caught.value)


@pytest.mark.parametrize("failure", ["read", "invalid", "encoding"])
def test_mutation_response_uncertainty_keeps_current_request_id(monkeypatch, failure):
    from livemorebio import execution_client
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_url", lambda: "http://127.0.0.1:9999")
    monkeypatch.setattr("livemorebio.security.authorization_headers", lambda: {"Authorization": "Bearer fixture"})
    def unreadable(*a):
        raise OSError("PRIVATE RESPONSE")
    response = SimpleNamespace(status=201, headers={"X-Livemore-Request-Id": "d" * 32},
                               read=lambda n: b'{}', close=lambda: None)
    if failure == "read":
        response.read = unreadable
    elif failure == "invalid":
        response.read = lambda n: b'{"execution_id":'
    elif failure == "encoding":
        response.headers["Content-Encoding"] = "gzip"
    install_stack_client_opener(monkeypatch, lambda *a: SimpleNamespace(open=lambda *a, **kw: response))
    with pytest.raises(execution_client.ContinuousClientError) as caught:
        platform.prepare_execution(PREPARE, idempotency_key="00001")
    assert caught.value.code == "CLIENT_UNCONFIRMED"
    assert caught.value.request_id == "d" * 32
    assert "PRIVATE" not in str(caught.value)


def test_close_failure_does_not_replace_specific_server_rejection(monkeypatch):
    from livemorebio import execution_client
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_url", lambda: "http://127.0.0.1:9999")
    monkeypatch.setattr("livemorebio.security.authorization_headers", lambda: {"Authorization": "Bearer fixture"})
    def failed():
        raise OSError("PRIVATE CLOSE")
    response = SimpleNamespace(status=409, headers={"X-Livemore-Request-Id": "d" * 32},
                               read=lambda n: b'{"code":"EXECUTION_CONFLICT"}', close=failed)
    install_stack_client_opener(monkeypatch, lambda *a: SimpleNamespace(open=lambda *a, **kw: response))
    with pytest.raises(execution_client.ContinuousClientError) as caught:
        platform.prepare_execution(PREPARE, idempotency_key="00001")
    assert caught.value.code == "EXECUTION_CONFLICT" and caught.value.request_id == "d" * 32
    assert platform.last_continuous_response["cleanup_code"] == "CLIENT_TRANSPORT"


def test_server_storage_failure_does_not_claim_mutation_was_rejected():
    from livemorebio.execution_client import ContinuousClientError
    error = ContinuousClientError("EXECUTION_STORAGE", status=503, request_id="d" * 32)
    assert error.code == "EXECUTION_STORAGE" and error.request_id == "d" * 32
    assert "may have committed" in str(error).lower() and "inspect" in str(error).lower()


@pytest.mark.parametrize("code", ["EXECUTION_CLEANUP_UNCONFIRMED", "MODEL_BINDING_REQUIRED",
    "MODEL_CONTEXT_INVALID", "MODEL_CONTEXT_UNSUPPORTED", "MODEL_CONTEXT_SOURCE_MISMATCH",
    "SELECTION_COMMIT_UNCONFIRMED", "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED",
    "RECORD_NOT_FOUND", "TWIN_VERSION_CONFLICT", "INVALID_TWIN_DATA", "INVALID_PAGE",
    "INVALID_COHORT_DATA", "COHORT_MEMBER_SNAPSHOT_REQUIRED", "COHORT_SNAPSHOT_INVALID",
    "SUBJECT_ADMISSION_REQUIRED", "INVALID_REQUEST_ID"])
def test_fixed_scientific_and_cleanup_codes_are_not_normalized_away(code):
    from livemorebio.execution_client import ContinuousClientError

    error = ContinuousClientError(code, status=503, request_id="d" * 32)
    assert error.code == code and error.request_id == "d" * 32
    if "UNCONFIRMED" in code:
        assert "inspect" in str(error).lower()


@pytest.mark.parametrize("status,body", [(200, b'{}'),
    (503, b'{"code":"SELECTION_COMMIT_UNCONFIRMED"}')])
def test_clinical_selection_uuid_survives_safe_shared_transport(monkeypatch, status, body):
    from livemorebio import execution_client
    operation_id = "01234567-89ab-4cde-8fab-0123456789ab"
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_url", lambda: "http://127.0.0.1:9999")
    monkeypatch.setattr("livemorebio.security.authorization_headers", lambda: {"Authorization": "Bearer fixture"})
    response = SimpleNamespace(status=status, headers={"X-Request-ID": operation_id},
                               read=lambda n: body, close=lambda: None)
    install_stack_client_opener(monkeypatch, lambda *a: SimpleNamespace(open=lambda *a, **kw: response))
    if status == 200:
        assert platform._continuous_request("POST", "/api/twins/technical/select-observations", {}) == {}
    else:
        with pytest.raises(execution_client.ContinuousClientError) as caught:
            platform._continuous_request("POST", "/api/twins/technical/select-observations", {})
        assert caught.value.request_id == operation_id
    assert platform.last_continuous_response["request_id"] == operation_id


@pytest.mark.parametrize("method,args,kwargs,verb,path", [
    ("execution_capabilities", [], {}, "GET", "/api/executions/capabilities"),
    ("prepare_execution", [PREPARE], {"idempotency_key": "00001"}, "POST", "/api/executions"),
    ("execution_status", [IDENTITY], {}, "GET", f"/api/executions/{IDENTITY}"),
    ("execution_frames", [IDENTITY], {"after_frame": 4, "limit": 10}, "GET", f"/api/executions/{IDENTITY}/frames?after_frame=4&limit=10"),
    ("execution_observations", [IDENTITY], {}, "GET", f"/api/executions/{IDENTITY}/observations"),
    ("fork_execution_checkpoint", [IDENTITY, {**PREPARE, "expected_parent_revision": 3}], {"idempotency_key": "00002"}, "POST", f"/api/executions/{IDENTITY}/fork-checkpoint"),
    ("virtual_patch_capabilities", [], {}, "GET", "/api/patch/virtual/sessions/capabilities"),
    ("register_virtual_probe", ["virtual-a"], {}, "POST", "/api/patch/virtual/probe"),
    ("start_virtual_session", [SESSION], {}, "POST", "/api/patch/virtual/sessions"),
    ("virtual_session_status", [IDENTITY], {}, "GET", f"/api/patch/virtual/sessions/{IDENTITY}"),
])
def test_sdk_exact_continuous_paths_and_no_input_mutation(monkeypatch, method, args, kwargs, verb, path):
    platform = Platform(mode="attach")
    requests = []
    monkeypatch.setattr(platform, "_continuous_request", lambda *a, **kw: requests.append((a, kw)) or {"technical": True})
    before = deepcopy((args, kwargs))
    assert getattr(platform, method)(*args, **kwargs) == {"technical": True}
    assert requests[0][0][:2] == (verb, path)
    assert (args, kwargs) == before
    if method in {"prepare_execution", "fork_execution_checkpoint"}:
        assert requests[0][1]["idempotency_key"] == kwargs["idempotency_key"]
    if method == "start_virtual_session":
        assert requests[0][0][2] == SESSION


@pytest.mark.parametrize("action", ["start", "pause", "resume", "stop"])
def test_execution_control_payloads_and_initialization_timeout(monkeypatch, action):
    platform = Platform(mode="attach")
    requests = []
    monkeypatch.setattr(platform, "_continuous_request", lambda *a, **kw: requests.append((a, kw)) or {})
    getattr(platform, action + "_execution")(IDENTITY, expected_revision=7, expected_source_generation="generation-a")
    args, kwargs = requests[0]
    assert args == ("POST", f"/api/executions/{IDENTITY}/{action}", {"expected_revision": 7, "expected_source_generation": "generation-a"})
    assert kwargs["timeout"] == (60 if action in {"start", "resume"} else 20)


@pytest.mark.parametrize("action", ["pause", "resume", "stop"])
def test_consumer_controls_never_renew_or_start_numerics(monkeypatch, action):
    platform = Platform(mode="attach")
    requests = []
    monkeypatch.setattr(platform, "_continuous_request", lambda *a, **kw: requests.append((a, kw)) or {})
    getattr(platform, action + "_virtual_session")(IDENTITY, expected_revision=3)
    assert requests == [(("POST", f"/api/patch/virtual/sessions/{IDENTITY}/{action}", {"expected_revision": 3}), {})]


def test_continuous_methods_refuse_inprocess_without_fallback(monkeypatch):
    platform = Platform.__new__(Platform)
    platform.mode = "inprocess"
    monkeypatch.setattr(platform, "_continuous_request", lambda *a, **kw: pytest.fail("no HTTP or offline substitute"))
    for call in [lambda: platform.execution_capabilities(), lambda: platform.prepare_execution(PREPARE, idempotency_key="one"),
                 lambda: platform.start_virtual_session(SESSION), lambda: platform.execution_frames(IDENTITY)]:
        with pytest.raises(ValueError, match="attached"):
            call()


@pytest.mark.parametrize("revision", [True, False, 1.5, "1", 0, -1])
def test_sdk_does_not_coerce_control_revision(monkeypatch, revision):
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_continuous_request", lambda *a, **kw: pytest.fail("invalid input reached HTTP"))
    with pytest.raises(ValueError):
        platform.start_execution(IDENTITY, expected_revision=revision, expected_source_generation="generation-a")


def test_strict_json_override_does_not_weaken_existing_default():
    from livemorebio.strict_json import parse_json_object
    raw = b'{"technical":"' + b'x' * 2_000_001 + b'"}'
    with pytest.raises(ValueError):
        parse_json_object(raw)
    assert len(parse_json_object(raw, max_bytes=8 * 1024 * 1024)["technical"]) == 2_000_001
    for maximum in (True, 0, -1, 8 * 1024 * 1024 + 1):
        with pytest.raises(ValueError):
            parse_json_object(b'{}', max_bytes=maximum)


def test_sdk_transport_bounds_auth_and_errors_without_echo(monkeypatch):
    from livemorebio import execution_client
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_url", lambda: "http://127.0.0.1:9999")
    monkeypatch.setattr("livemorebio.security.authorization_headers", lambda: {"Authorization": "Bearer technical-private-token"})
    response = SimpleNamespace(status=200, headers={"X-Livemore-Request-Id": "c" * 32},
                               read=lambda limit: b'{"technical":true}', close=lambda: None)
    calls = []

    def open_request(request, timeout):
        calls.append((request, timeout))
        return response

    install_stack_client_opener(monkeypatch, lambda *args: SimpleNamespace(open=open_request))
    assert platform.execution_capabilities() == {"technical": True}
    assert calls[0][0].get_header("Authorization") == "Bearer technical-private-token"
    assert platform.last_continuous_response["request_id"] == "c" * 32
    response.status = 409
    response.read = lambda limit: b'{"code":"EXECUTION_CONFLICT","error":"PRIVATE CLINICAL BODY technical-private-token"}'
    with pytest.raises(execution_client.ContinuousClientError) as caught:
        platform.execution_capabilities()
    assert caught.value.code == "EXECUTION_CONFLICT" and caught.value.request_id == "c" * 32
    assert "PRIVATE" not in str(caught.value) and "token" not in str(caught.value)
    response.status = 200
    for raw in (b'{"x":1,"x":2}', b'{"x":NaN}', b'[]', b'x' * (8 * 1024 * 1024 + 1)):
        response.read = lambda limit, value=raw: value
        with pytest.raises(execution_client.ContinuousClientError):
            platform.execution_capabilities()
