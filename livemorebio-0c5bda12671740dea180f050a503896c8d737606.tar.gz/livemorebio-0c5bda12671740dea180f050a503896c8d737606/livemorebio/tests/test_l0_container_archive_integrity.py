"""DEP-2: documented unpacking refuses untrusted technical archive bytes.

The Bash recipes execute against local command stand-ins; no download or Docker
daemon is used. PowerShell statement checks are not a Windows runtime claim.
Every distribution tree checks its root README; a source checkout additionally
checks the separately published landing pages and the public operating guide.
"""
from __future__ import annotations

import hashlib
import io
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

import pytest

from ._source_tree import REPOSITORY_ROOT, verifying_container_image
from .test_stable_new5c_pass_r_docs import PUBLIC_LANDING_PAGES


ROOT = REPOSITORY_ROOT
GUIDES = ["README.md"]
if not verifying_container_image():
    GUIDES.append("docs/BUSINESS_CLIENT_GUIDE.md")
if (ROOT / ".git").exists() or any((ROOT / name).exists() for name in PUBLIC_LANDING_PAGES):
    GUIDES.extend(PUBLIC_LANDING_PAGES)


def _archive_blocks(name: str, language: str) -> list[str]:
    text = (ROOT / name).read_text(encoding="utf-8")
    return [block for block in re.findall(r"```" + language + r"\n(.*?)```", text, re.DOTALL)
            if "livemorebio-stable.tar.gz" in block and "tar -" in block]


def _technical_archive() -> bytes:
    content = b"technical documentation fixture, not physical evidence\n"
    output = io.BytesIO()
    with tarfile.open(fileobj=output, mode="w:gz") as archive:
        member = tarfile.TarInfo("livemorebio-technical/marker.txt")
        member.size = len(content)
        archive.addfile(member, io.BytesIO(content))
    return output.getvalue()


def _write_command(path: Path, body: str) -> None:
    path.write_text("#!/bin/sh\nset -eu\n" + body, encoding="utf-8")
    path.chmod(0o700)


@pytest.mark.parametrize("name", GUIDES)
@pytest.mark.parametrize("tar_flavour", ["host", "external-gzip"])
@pytest.mark.parametrize("hash_tool", ["sha256sum", "shasum"])
@pytest.mark.parametrize("case", ["missing", "malformed", "mismatch", "download-failure",
                                 "download-write-failure", "download-stale-failure", "hash-tool-failure",
                                 "hash-output-failure", "success"])
def test_DEP_2_documented_shell_checks_before_unpacking(
    tmp_path: Path, name: str, hash_tool: str, case: str, tar_flavour: str
) -> None:
    blocks = _archive_blocks(name, "bash")
    assert blocks, f"{name} must retain a verified archive acquisition recipe"
    for index, block in enumerate(blocks):
        work = tmp_path / str(index)
        work.mkdir()
        command_dir = work / "commands"
        command_dir.mkdir()
        archive = work / "technical-input.tar.gz"
        archive.write_bytes(_technical_archive())
        if case == "download-stale-failure":
            (work / "livemorebio-stable.tar.gz").write_bytes(archive.read_bytes())
        events = work / "events.txt"
        _write_command(command_dir / "curl", '''
printf 'download\n' >> "$TECHNICAL_EVENTS"
[ "$TECHNICAL_CASE" != download-failure ] || exit 22
[ "$TECHNICAL_CASE" != download-stale-failure ] || exit 22
target=
while [ "$#" -gt 0 ]; do
    if [ "$1" = -o ]; then target=$2; break; fi
    shift
done
if [ -n "$target" ]; then
    cat "$TECHNICAL_ARCHIVE" > "$target"
else
    cat "$TECHNICAL_ARCHIVE"
fi
[ "$TECHNICAL_CASE" != download-write-failure ] || exit 22
''')
        _write_command(command_dir / "tar", '''
printf 'extract\n' >> "$TECHNICAL_EVENTS"
exec "$TECHNICAL_TAR" "$@"
''')
        _write_command(command_dir / hash_tool, '''
printf 'hash\n' >> "$TECHNICAL_EVENTS"
[ "$TECHNICAL_CASE" != hash-tool-failure ] || exit 73
if [ -n "$TECHNICAL_HASH_TOOL" ]; then
    "$TECHNICAL_HASH_TOOL" "$@"
else
# A host can lack one of the two documented tools. Its alternate branch still
# receives a byte-derived SHA-256 in this command-double qualification.
    "$TECHNICAL_PYTHON" -c 'import hashlib,sys; print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest()+"  -")'
fi
[ "$TECHNICAL_CASE" != hash-output-failure ] || exit 73
''')
        # GNU tar (Linux, the container images) runs `gzip` from PATH for -z;
        # bsdtar (macOS) decompresses in-process. The "external-gzip" flavour
        # makes a macOS host behave like GNU tar here.
        host_tar = shutil.which("tar") or ""
        if tar_flavour == "external-gzip":
            gnu_like = work / "gnu-like-tar"
            _write_command(gnu_like, '''
case "${1:-}" in
    -xzf) [ "$#" -eq 2 ] || exit 64
          gzip -dc < "$2" | "$TECHNICAL_HOST_TAR" -xf - ;;
    *) exec "$TECHNICAL_HOST_TAR" "$@" ;;
esac
''')
            technical_tar = str(gnu_like)
        else:
            technical_tar = host_tar
        for tool in ("cat", "tr", "gzip"):
            executable = shutil.which(tool)
            assert executable is not None, f"documented shell requires {tool}"
            _write_command(command_dir / tool, f'exec "$TECHNICAL_{tool.upper()}" "$@"\n')
        for directory in ("home", "tmp", "data"):
            (work / directory).mkdir()
        environment = {
            "PATH": str(command_dir), "HOME": str(work / "home"), "TMPDIR": str(work / "tmp"),
            "LIVEMORE_DATA_DIR": str(work / "data"), "LANG": "en_US.UTF-8",
            "TECHNICAL_ARCHIVE": str(archive), "TECHNICAL_EVENTS": str(events),
            "TECHNICAL_CASE": case, "TECHNICAL_PYTHON": sys.executable,
            "TECHNICAL_TAR": technical_tar, "TECHNICAL_HOST_TAR": host_tar,
            "TECHNICAL_HASH_TOOL": shutil.which(hash_tool) or "",
            "TECHNICAL_CAT": shutil.which("cat") or "", "TECHNICAL_TR": shutil.which("tr") or "",
            "TECHNICAL_GZIP": shutil.which("gzip") or "",
        }
        assert host_tar, "documented shell requires tar"
        if case != "missing":
            environment["LIVEMORE_SHA256"] = (
                "not-a-digest" if case == "malformed" else
                "0" * 64 if case == "mismatch" else hashlib.sha256(archive.read_bytes()).hexdigest().upper()
            )
        # Only run the acquisition through its directory change, not later
        # key creation, installation, health probes or Compose commands.
        lines = block.splitlines()
        end = next((i for i, line in enumerate(lines) if "cd livemorebio-*/" in line), None)
        assert end is not None, name
        command = "\n".join(lines[:end + 1])
        bash = shutil.which("bash")
        assert bash is not None, "documented shell requires Bash"
        result = subprocess.run([bash, "-c", command], cwd=work, env=environment,
                                capture_output=True, text=True, encoding="utf-8", timeout=10)
        observed = events.read_text(encoding="utf-8").splitlines() if events.exists() else []
        marker = work / "livemorebio-technical/marker.txt"
        if case == "success":
            assert result.returncode == 0, (name, case)
            assert observed == ["download", "hash", "extract"], (name, case, observed)
            assert marker.read_bytes() == b"technical documentation fixture, not physical evidence\n"
        else:
            assert result.returncode != 0, (name, case)
            assert "extract" not in observed, (name, case, observed)
            assert not marker.exists(), (name, case)
            if case in {"missing", "malformed"}:
                assert observed == [], (name, case, observed)


@pytest.mark.parametrize("name", [name for name in GUIDES if name in {"README.md", PUBLIC_LANDING_PAGES[1]}
                                  or name == "docs/BUSINESS_CLIENT_GUIDE.md"])
def test_DEP_2_powershell_refuses_before_extract_statement(name: str) -> None:
    blocks = _archive_blocks(name, "powershell")
    assert blocks, name
    for block in blocks:
        required = [
            "$ErrorActionPreference = 'Stop'",
            "if ($env:LIVEMORE_SHA256 -notmatch '\\A[0-9a-fA-F]{64}\\z') { throw 'Set LIVEMORE_SHA256 to the independently supplied release digest.' }",
            "curl.exe -fsSL ",
            "if ($LASTEXITCODE -ne 0) { throw 'Archive download failed.' }",
            "$actual = (Get-FileHash -LiteralPath livemorebio-stable.tar.gz -Algorithm SHA256).Hash",
            "if ($actual -cne $env:LIVEMORE_SHA256.ToUpperInvariant()) { throw 'Archive checksum mismatch; refusing extraction.' }",
            "tar -xzf livemorebio-stable.tar.gz",
            "if ($LASTEXITCODE -ne 0) { throw 'Archive extraction failed.' }",
            "cd (Get-ChildItem -Directory livemorebio-*)[0]",
        ]
        positions = [block.index(statement) for statement in required]
        assert positions == sorted(positions), name
        assert block.count("tar -x") == 1, name


@pytest.mark.parametrize("name", GUIDES)
def test_DEP_2_checksum_instructions_require_independent_value(name: str) -> None:
    text = (ROOT / name).read_text(encoding="utf-8")
    assert "independently supplied" in text and "LIVEMORE_SHA256" in text, name
    assert "same download origin" in text, name
    assert not re.search(r"curl[^\n]*livemorebio-stable\.tar\.gz[^\n]*\|\s*tar", text), name
