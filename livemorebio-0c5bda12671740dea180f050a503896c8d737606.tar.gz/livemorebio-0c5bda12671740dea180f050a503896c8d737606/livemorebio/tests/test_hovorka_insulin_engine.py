"""Behavioural tests for the Hovorka exogenous-insulin engine.

These check mechanism-level properties that must hold for any correct
implementation of the published model. They are not validation against human
measurements.
"""
import math

import numpy as np
import pytest

from livemorebio.engines.metabolic.hovorka import (
    ADMITTED_PRODUCTS, HOVORKA_2004, WILINSKA_2010, HovorkaModel, HovorkaParameters,
    InsulinDose, InsulinProductError, product_catalog, resolve_product, summarize,
)


def _model(**kwargs):
    return HovorkaModel(parameters=HovorkaParameters.from_source(**kwargs))


def test_zero_bolus_is_numerically_identical_to_no_bolus():
    model = _model()
    state = model.initial_state_from_basal(0.4)
    control = model.simulate(hours=6, meals_g=[(30, 50.0)], basal_u_per_h=0.4, initial_state=state)
    zero = model.simulate(hours=6, meals_g=[(30, 50.0)], basal_u_per_h=0.4, initial_state=state,
                          doses=[InsulinDose(start_min=30, units=0.0)])
    assert np.array_equal(control["glucose_mmol_L"], zero["glucose_mmol_L"])
    assert np.array_equal(control["plasma_insulin_mU_L"], zero["plasma_insulin_mU_L"])


def test_states_remain_physical_and_mass_balance_closes():
    model = _model()
    state = model.initial_state_from_basal(0.4)
    result = model.simulate(hours=10, meals_g=[(30, 80.0)], basal_u_per_h=0.4, initial_state=state,
                            doses=[InsulinDose(start_min=20, units=6.0)])
    for key in ("glucose_mmol_L", "plasma_insulin_mU_L", "sc_depot_1_mU", "sc_depot_2_mU"):
        assert np.all(np.isfinite(result[key]))
        assert np.all(result[key] >= -1e-9), key
    assert result["insulin_mass_balance"]["relative_residual"] < 1e-6


def test_more_basal_insulin_lowers_steady_state_glucose_monotonically():
    model = _model()
    levels = [model.basal_steady_state(rate)["glucose_mmol_L"] for rate in (0.2, 0.3, 0.4, 0.5)]
    assert all(a > b for a, b in zip(levels, levels[1:]))


def test_bolus_dose_response_is_monotone_in_nadir():
    model = _model()
    state = model.initial_state_from_basal(0.3)
    nadirs = []
    for units in (0.0, 2.0, 4.0, 6.0):
        result = model.simulate(hours=8, meals_g=[(30, 60.0)], basal_u_per_h=0.3, initial_state=state,
                                doses=[InsulinDose(start_min=30, units=units)])
        nadirs.append(summarize(result)["nadir_glucose_mmol_L"])
    assert all(a > b for a, b in zip(nadirs, nadirs[1:]))


def test_subcutaneous_absorption_delays_plasma_peak_relative_to_intravenous():
    sc = _model()
    iv = HovorkaModel(parameters=HovorkaParameters.from_source(), product=resolve_product("regular-human-insulin-iv"))
    sc_run = sc.simulate(hours=6, doses=[InsulinDose(start_min=0, units=4.0)])
    iv_run = iv.simulate(hours=6, doses=[InsulinDose(start_min=0, rate_u_per_h=24.0, duration_min=10.0)])
    sc_peak = summarize(sc_run)["t_peak_insulin_min"]
    iv_peak = summarize(iv_run)["t_peak_insulin_min"]
    assert iv_peak <= 11.0
    # A two-compartment chain with tmaxI=55 min peaks in plasma after the depot
    # peak; the exact time also depends on ke, so only the ordering is asserted.
    assert 40.0 <= sc_peak <= 150.0
    assert sc_peak > iv_peak


def test_intravenous_route_refuses_bolus_representation():
    iv = HovorkaModel(product=resolve_product("regular-human-insulin-iv"))
    with pytest.raises(InsulinProductError) as caught:
        iv.simulate(hours=2, doses=[InsulinDose(start_min=0, units=1.0)])
    assert caught.value.code == "INSULIN_ROUTE_REQUIRES_INFUSION"


@pytest.mark.parametrize("product", ["glargine-sc", "nph-insulin-sc", "regular-human-insulin-sc"])
def test_products_without_admitted_absorption_model_are_refused(product):
    with pytest.raises(InsulinProductError) as caught:
        resolve_product(product)
    assert caught.value.code == "INSULIN_PRODUCT_NOT_ADMITTED"
    catalog = product_catalog()
    assert product in {item["product_id"] for item in catalog["declared_not_admitted"]}
    assert product not in ADMITTED_PRODUCTS


def test_unknown_product_is_refused():
    with pytest.raises(InsulinProductError) as caught:
        resolve_product("made-up-insulin")
    assert caught.value.code == "INSULIN_PRODUCT_UNKNOWN"


def test_weight_scales_only_volumes():
    light = HovorkaParameters.from_source(weight_kg=50.0)
    heavy = HovorkaParameters.from_source(weight_kg=100.0)
    assert math.isclose(heavy.VG_L, 2 * light.VG_L)
    assert math.isclose(heavy.VI_L, 2 * light.VI_L)
    for name in ("k12", "ka1", "SIT", "SID", "SIE", "ke", "tmaxI"):
        assert getattr(light, name) == getattr(heavy, name)


def test_overrides_require_provenance_and_are_recorded():
    with pytest.raises(ValueError):
        HovorkaParameters.from_source(overrides={"SID": 6e-4})
    params = HovorkaParameters.from_source(overrides={"SID": 6e-4},
                                           override_provenance={"SID": "clamp study record 42"})
    assert params.SID == 6e-4
    assert params.provenance()["SID"]["source"] == "clamp study record 42"
    with pytest.raises(ValueError):
        HovorkaParameters.from_source(overrides={"weight_kg": 80.0},
                                      override_provenance={"weight_kg": "x"})


def test_every_parameter_has_source_and_unit_for_both_parameter_sets():
    for source in (HOVORKA_2004, WILINSKA_2010):
        provenance = HovorkaParameters.from_source(source).provenance()
        assert provenance, source
        for name, record in provenance.items():
            assert record["source"], (source, name)
            assert record["unit"], (source, name)


def test_execution_is_deterministic():
    model = _model()
    a = model.simulate(hours=4, meals_g=[(0, 40.0)], doses=[InsulinDose(start_min=0, units=3.0)])
    b = model.simulate(hours=4, meals_g=[(0, 40.0)], doses=[InsulinDose(start_min=0, units=3.0)])
    assert np.array_equal(a["glucose_mmol_L"], b["glucose_mmol_L"])


def test_result_carries_interpretation_limits():
    result = _model().simulate(hours=1)
    text = " ".join(result["interpretation_limits"]).lower()
    assert "not dosing guidance" in text and "not calibrated" in text


def test_unsourced_cardiac_coupling_is_labelled_as_a_hypothesis(pinned_cardiac_asset):
    """An invented magnitude must not be presented as a modelled prediction."""
    from livemorebio.engines.coupling.metabolic_cardiac import CLAIM_STATE, SLOPE_PROVENANCE
    from livemorebio.multiscale import _active_execution

    assert CLAIM_STATE == "HYPOTHESIS_UNSOURCED"
    assert SLOPE_PROVENANCE["source"] is None
    from livemorebio.aegle.runtime import AegleTwin

    state = AegleTwin("t2d").state()
    execution = _active_execution(state)
    coupling = [edge for edge in execution["edges"] if edge["engine"] == "metabolic-cardiac-coupling"]
    assert coupling and coupling[0]["claim_state"] == "HYPOTHESIS_UNSOURCED"
    assert "no admitted source" in coupling[0]["limitation"]


def test_two_boluses_at_the_same_time_sum_instead_of_replacing_each_other():
    model = _model()
    state = model.initial_state_from_basal(0.3)
    split = model.simulate(hours=6, initial_state=state, doses=[
        InsulinDose(start_min=20, units=2.0), InsulinDose(start_min=20, units=3.0)])
    single = model.simulate(hours=6, initial_state=state, doses=[InsulinDose(start_min=20, units=5.0)])
    assert split["insulin_mass_balance"]["administered_mU"] == pytest.approx(5000.0)
    assert np.allclose(split["plasma_insulin_mU_L"], single["plasma_insulin_mU_L"], rtol=1e-9, atol=1e-12)
