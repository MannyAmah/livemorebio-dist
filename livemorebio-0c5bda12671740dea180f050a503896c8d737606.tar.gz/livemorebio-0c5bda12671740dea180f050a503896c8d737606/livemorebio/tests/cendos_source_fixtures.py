"""Authored source envelopes and explicit network isolation for Cendos tests."""
from copy import deepcopy
import hashlib
import json
from typing import Any

import pytest

from livemorebio.tests.stack_client_fixtures import forbid_stack_client


@pytest.fixture(autouse=True)
def no_cendos_peer_network(monkeypatch):
    def denied(*args, **kwargs):
        pytest.fail("Cendos technical test attempted unmocked peer HTTP")

    monkeypatch.setattr("urllib.request.urlopen", denied)
    monkeypatch.setattr("urllib.request.build_opener", denied)
    monkeypatch.setattr("livemorebio.transport.authenticated_opener", denied)
    forbid_stack_client(monkeypatch, denied)


def technical_source(snapshot: dict[str, Any]) -> dict[str, Any]:
    """Wrap authored parameters without validating away deliberately bad cases."""
    value = deepcopy(snapshot)
    value.setdefault("parameter_provenance", {})
    value.setdefault("subject", None)
    value.setdefault("model_availability", {
        "schema": "livemore.model-availability.v1", "state": "READY", "reason_code": None,
        "selection_mode": "reference_preview", "twin_id": None, "twin_version": 0,
        "source_generation": "a" * 32, "preparation_available": True,
    })
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()
    return {"schema": "livemore.cendos-current-source.v1", "snapshot": value,
            "snapshot_sha256": hashlib.sha256(raw).hexdigest()}
