"""Model installation tests use unmistakably non-biological byte fixtures."""

from __future__ import annotations

import errno
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import urllib.error

import pytest

from livemorebio import model_assets as assets


class Response(io.BytesIO):
    status = 200

    def __init__(self, data: bytes, url: str, length: str | None = None):
        super().__init__(data)
        self.url = url
        self.headers = {"Content-Length": str(len(data)) if length is None else length}

    def geturl(self):
        return self.url


@pytest.fixture
def isolated(tmp_path, monkeypatch):
    root = tmp_path / "models"
    monkeypatch.setenv("LIVEMORE_MODEL_DIR", str(root))
    return root


@pytest.fixture
def fixture_downloads(isolated, monkeypatch):
    payloads = {}
    definitions = []
    for item in assets._HUMAN_ASSETS:
        content = f"TEST ONLY NOT A BIOLOGICAL MODEL: {item.asset_id}\n".encode()
        if item.asset_id == "genes":
            content = b"genes\tgeneSymbols\nTEST_GENE_1\tTEST_ONLY\n"
        payloads[item.source_url] = content
        definitions.append(
            assets.AssetFile(
                item.asset_id,
                item.filename,
                item.source_url,
                hashlib.sha256(content).hexdigest(),
                len(content),
            )
        )
    monkeypatch.setattr(assets, "_HUMAN_ASSETS", tuple(definitions))
    calls = []

    def fake_open(request, timeout):
        calls.append(request.full_url)
        return Response(payloads[request.full_url], request.full_url)

    monkeypatch.setattr(assets, "_open_url", fake_open)
    return payloads, calls


def test_manifest_is_pinned_and_detached():
    manifest = assets.asset_manifest()
    assert manifest["release"] == "2.0.0"
    assert manifest["commit"] == "635f533152dc5f7290ce04d12700eaa882273c3e"
    assert manifest["license"]["id"] == "CC-BY-4.0"
    assert (
        manifest["assets"]["xml"]["sha256"]
        == "cc5a4383c6116b0c91f4db089cc640f29aec7e840249b573b74d3792c9ca4a7a"
    )
    assert manifest["assets"]["xml"]["size_bytes"] == 43115559
    assert manifest["expected_ids"]["objective"] == "MAR03964"
    manifest["assets"]["xml"]["sha256"] = "0" * 64
    assert assets.asset_manifest()["assets"]["xml"]["sha256"] != "0" * 64


def test_catalog_and_missing_status_have_no_filesystem_side_effects(isolated):
    assert len(assets.catalog()["models"]) == 2
    result = assets.status()
    assert result["state"] == "missing"
    assert result["available"] is False
    assert not isolated.exists()
    assert str(isolated) not in json.dumps(result)


@pytest.mark.parametrize("model_id", ["recon3d", "recon3d-3.01"])
def test_recon_rejected_before_network_or_filesystem(isolated, monkeypatch, model_id):
    monkeypatch.setattr(
        assets, "_open_url", lambda *a, **k: pytest.fail("restricted download")
    )
    assert assets.status(model_id)["state"] == "restricted"
    for call in (assets.install, assets.verified_asset, assets.verified_model_path):
        with pytest.raises(assets.ModelAssetError) as error:
            call(model_id)
        assert error.value.code == "restricted"
    assert not isolated.exists()


@pytest.mark.parametrize(
    "model_id", ["../human-gem", "human-gem ", "https://example.com/a", "", None, 2]
)
def test_unknown_model_ids_fail_closed(isolated, model_id):
    with pytest.raises(assets.ModelAssetError) as error:
        assets.install(model_id)
    assert error.value.code == "invalid_id"
    assert not isolated.exists()


def test_install_private_verified_atomic_and_idempotent(isolated, fixture_downloads):
    _, calls = fixture_downloads
    result = assets.install("human-gem-2.0.0")
    assert result["available"] and result["state"] == "verified"
    assert result["model_id"] == "human-gem"
    assert len(calls) == 8
    installed = assets.verified_asset()
    assert Path(installed["xml_path"]) == assets.verified_model_path()
    assert Path(installed["gene_annotation_path"]) == assets.verified_asset_path(
        "genes"
    )
    assert stat.S_IMODE(isolated.stat().st_mode) == 0o700
    package = assets.verified_model_path().parent
    assert stat.S_IMODE(package.stat().st_mode) == 0o700
    assert all(stat.S_IMODE(path.stat().st_mode) == 0o600 for path in package.iterdir())
    assert not list(isolated.glob(".install-human-gem-*"))
    assert assets.install()["available"]
    assert len(calls) == 8
    assert str(isolated) not in json.dumps(result)
    receipt = json.loads((package / "installation.json").read_text(encoding="utf-8"))
    assert receipt["manifest_sha256"] == result["manifest_sha256"]


@pytest.mark.parametrize("asset_id", ["xml", "genes", "license", "citation"])
def test_tampered_package_denies_every_asset_and_is_not_overwritten(
    isolated, fixture_downloads, asset_id
):
    assets.install()
    path = assets.verified_asset_path(asset_id)
    path.write_bytes(b"CORRUPT TEST ONLY")
    assert assets.status()["state"] == "corrupt"
    with pytest.raises(assets.ModelAssetError, match="integrity"):
        assets.verified_model_path()
    with pytest.raises(assets.ModelAssetError):
        assets.install()
    assert path.read_bytes() == b"CORRUPT TEST ONLY"


def test_tampered_receipt_is_not_trusted(isolated, fixture_downloads):
    assets.install()
    receipt = assets.verified_model_path().parent / "installation.json"
    document = json.loads(receipt.read_text(encoding="utf-8"))
    document["manifest_sha256"] = "0" * 64
    receipt.write_text(json.dumps(document), encoding="utf-8")
    assert assets.status()["state"] == "corrupt"


@pytest.mark.parametrize(
    "failure",
    ["short", "oversized", "wrong_hash", "bad_header", "redirect", "error", "timeout"],
)
def test_download_failure_never_publishes(
    isolated, fixture_downloads, monkeypatch, failure
):
    payloads, _ = fixture_downloads

    def fail_open(request, timeout):
        content = payloads[request.full_url]
        length = str(len(content))
        url = request.full_url
        if failure == "short":
            content = content[:-1]
        elif failure == "oversized":
            content += b"X"
        elif failure == "wrong_hash":
            content = b"X" * len(content)
        elif failure == "bad_header":
            length = "9999999999"
        elif failure == "redirect":
            url = "https://untrusted.example/model"
        elif failure == "error":
            raise urllib.error.URLError("test-only failure /private/secret")
        elif failure == "timeout":
            raise TimeoutError("test-only timeout /private/secret")
        return Response(content, url, length)

    monkeypatch.setattr(assets, "_open_url", fail_open)
    with pytest.raises(assets.ModelAssetError) as error:
        assets.install()
    assert error.value.code == "download"
    assert "/private/secret" not in str(error.value)
    assert assets.status()["available"] is False
    assert not list(isolated.glob(".install-human-gem-*"))
    assert not list(isolated.glob("human-gem-*"))


def test_non_https_or_unpinned_source_rejected_before_open(
    isolated, fixture_downloads, monkeypatch
):
    item = assets._HUMAN_ASSETS[0]
    bad = assets.AssetFile(
        item.asset_id,
        item.filename,
        "https://example.com/model.xml",
        item.sha256,
        item.size_bytes,
    )
    monkeypatch.setattr(assets, "_HUMAN_ASSETS", (bad,) + assets._HUMAN_ASSETS[1:])
    monkeypatch.setattr(
        assets, "_open_url", lambda *a, **k: pytest.fail("unapproved URL")
    )
    with pytest.raises(assets.ModelAssetError) as error:
        assets.install()
    assert error.value.code == "invalid_manifest"


def test_symlink_root_rejected(tmp_path, isolated, fixture_downloads):
    destination = tmp_path / "destination"
    destination.mkdir(mode=0o700)
    isolated.symlink_to(destination, target_is_directory=True)
    assert assets.status()["state"] == "unsafe_path"
    with pytest.raises(assets.ModelAssetError) as error:
        assets.install()
    assert error.value.code == "unsafe_path"
    assert list(destination.iterdir()) == []


@pytest.mark.parametrize("kind", ["symlink", "hardlink", "permissions", "directory"])
def test_unsafe_asset_rejected(tmp_path, fixture_downloads, kind):
    assets.install()
    path = assets.verified_model_path()
    content = path.read_bytes()
    if kind == "permissions":
        path.chmod(0o644)
    else:
        path.unlink()
        if kind == "directory":
            path.mkdir(mode=0o700)
        else:
            target = tmp_path / "outside.xml"
            target.write_bytes(content)
            target.chmod(0o600)
            if kind == "symlink":
                path.symlink_to(target)
            else:
                os.link(target, path)
    assert assets.status()["state"] == "unsafe_path"


def test_insecure_existing_root_not_modified(isolated, fixture_downloads):
    isolated.mkdir(mode=0o755)
    isolated.chmod(0o755)
    with pytest.raises(assets.ModelAssetError) as error:
        assets.install()
    assert error.value.code == "unsafe_path"
    assert stat.S_IMODE(isolated.stat().st_mode) == 0o755
    assert list(isolated.iterdir()) == []


def test_concurrent_installer_is_busy_and_lock_released(isolated, fixture_downloads):
    assets._model_root(create=True)
    with assets._installation_lock(isolated):
        with pytest.raises(assets.ModelAssetError) as error:
            assets.install()
        assert error.value.code == "busy"
    assert assets.install()["available"]


def test_execution_lock_path_uses_private_cache_root(isolated):
    path = assets.execution_lock_path()
    assert path == isolated / ".execution.lock"
    assert stat.S_IMODE(isolated.stat().st_mode) == 0o700
    assert not path.exists()


def test_data_dir_fallback_and_explicit_model_root_precedence(tmp_path, monkeypatch):
    monkeypatch.delenv("LIVEMORE_MODEL_DIR", raising=False)
    monkeypatch.setenv("LIVEMORE_DATA_DIR", str(tmp_path / "data"))
    assert assets._model_root(create=False) == tmp_path / "data" / "models"
    monkeypatch.setenv("LIVEMORE_MODEL_DIR", str(tmp_path / "dedicated"))
    assert assets._model_root(create=False) == tmp_path / "dedicated"


def test_annotations_are_exact_reference_rows_not_causal_weights(fixture_downloads):
    assets.install()
    result = assets.annotation_rows("genes", ["TEST_GENE_1", "MISSING_TEST_GENE"])
    assert result["evidence_class"] == "REFERENCE_MODEL_ANNOTATION"
    assert result["rows"][0]["genes"] == "TEST_GENE_1"
    assert result["missing_ids"] == ["MISSING_TEST_GENE"]
    assert len(result["rows"]) == 1
    with pytest.raises(assets.ModelAssetError):
        assets.annotation_rows("genes", ["TEST_GENE_1"] * 101)


@pytest.mark.parametrize(
    "kind, ids",
    [
        ([], ["TEST_GENE"]),
        (None, ["TEST_GENE"]),
        ("genes", None),
        ("genes", [True]),
        ("genes", [" TEST_GENE"]),
        ("genes", []),
    ],
)
def test_malformed_annotation_request_has_typed_error(kind, ids, isolated):
    with pytest.raises(assets.ModelAssetError) as error:
        assets.annotation_rows(kind, ids)
    assert error.value.code == "invalid_id"
    assert not isolated.exists()


def test_symlink_package_and_lock_are_refused(isolated, fixture_downloads, tmp_path):
    assets.install()
    package = assets.verified_model_path().parent
    moved = tmp_path / "moved"
    package.rename(moved)
    package.symlink_to(moved, target_is_directory=True)
    assert assets.status()["state"] == "unsafe_path"
    lock = isolated / ".install.lock"
    lock.unlink()
    target = tmp_path / "lock-target"
    target.write_bytes(b"TEST ONLY LOCK TARGET")
    lock.symlink_to(target)
    with pytest.raises(assets.ModelAssetError) as error:
        assets.install()
    assert error.value.code == "unsafe_path"
    assert target.read_bytes() == b"TEST ONLY LOCK TARGET"


def test_download_deadline_never_publishes(isolated, fixture_downloads, monkeypatch):
    monkeypatch.setattr(assets, "_DOWNLOAD_SECONDS", -1)
    with pytest.raises(assets.ModelAssetError) as error:
        assets.install()
    assert error.value.code == "download"
    assert not list(isolated.glob("human-gem-*"))


def test_deeply_nested_receipt_has_typed_error(fixture_downloads):
    assets.install()
    receipt = assets.verified_model_path().parent / "installation.json"
    receipt.write_text("[" * 1100 + "0" + "]" * 1100, encoding="utf-8")
    assert assets.status()["state"] == "corrupt"


def test_cli_missing_status_and_restricted_check_are_json(isolated):
    command = [sys.executable, "-m", "livemorebio.model_assets"]
    result = subprocess.run(command + ["status"], capture_output=True, text=True, encoding="utf-8")
    assert result.returncode == 0
    assert json.loads(result.stdout)["state"] == "missing"
    result = subprocess.run(
        command + ["check", "recon3d"], capture_output=True, text=True, encoding="utf-8"
    )
    assert result.returncode != 0
    assert json.loads(result.stdout)["error"]["code"] == "restricted"
    assert not isolated.exists()


@pytest.mark.skipif(
    os.getenv("LIVEMORE_TEST_MODEL_DOWNLOAD") != "1",
    reason="explicit official network download opt-in",
)
def test_actual_official_download_is_verified_in_private_root(isolated):
    assert assets.install()["available"]
    assert assets.verified_model_path().stat().st_size == 43115559


# L0-R11: record before act, and delete only by moving aside then verifying.
# The sweep below finds the steps itself: it counts every call of the wrapped
# set the operation makes and then delivers a real SIGINT before, and after,
# each one in turn. The wrapped set, exactly (L0-R13: review 4 found pread,
# flock and the direct libc rename missing):
# - these os functions, which pathlib and tempfile also go through;
# - io.open, which pathlib's open and os.fdopen use;
# - fcntl.flock;
# - model_assets._rename_exclusive, the kernel's no-replace rename, which calls
#   libc (renameatx_np, renameat2) through ctypes, as one step.
# Not wrapped: reads, writes, flushes and closes made through a file object
# that io.open returned, and os.DirEntry.is_dir.
_FILESYSTEM_STEPS = (
    "open", "close", "read", "write", "fstat", "lstat", "stat", "link", "unlink",
    "rename", "replace", "mkdir", "rmdir", "fsync", "fchmod", "chmod", "scandir",
    "listdir", "umask", "pread", "readlink", "pathconf",
)


class StepInterrupts:
    """Deliver SIGINT at one filesystem step of a call, as a person's Ctrl-C would."""

    def __init__(self, monkeypatch):
        self.armed = False
        self.count = 0
        self.target = 0
        self.when = ""
        self.delivered = False
        self.labels: list[str] = []
        self._listdir = os.listdir
        self._close = os.close
        for name in _FILESYSTEM_STEPS:
            monkeypatch.setattr(os, name, self._step(name, getattr(os, name)))
        monkeypatch.setattr(io, "open", self._step("io.open", io.open))
        import fcntl

        monkeypatch.setattr(fcntl, "flock", self._step("flock", fcntl.flock))
        monkeypatch.setattr(assets, "_rename_exclusive", self._step("rename_exclusive", assets._rename_exclusive))

    def _step(self, name, original):
        def step(*args, **kwargs):
            if not self.armed:
                return original(*args, **kwargs)
            self.count += 1
            if self.target == 0:
                subject = args[0] if args and isinstance(args[0], (str, os.PathLike)) else ""
                self.labels.append(f"{name}({Path(subject).name if subject else ''})")
            here = self.count == self.target
            if here and self.when == "before":
                self._interrupt()
            try:
                return original(*args, **kwargs)
            finally:
                if here and self.when == "after":
                    self._interrupt()
        return step

    def _interrupt(self):
        self.delivered = True
        signal.raise_signal(signal.SIGINT)

    def _call(self, call):
        descriptors = set(self._listdir("/dev/fd"))
        self.armed = True
        try:
            call()
        except KeyboardInterrupt:
            outcome = "KeyboardInterrupt"
        except assets.ModelAssetError as error:
            outcome = error.code
        else:
            outcome = "returned"
        finally:
            self.armed = False
            # An interrupted open never reaches its caller; close what leaked
            # so a long sweep cannot exhaust descriptors.
            for leaked in set(self._listdir("/dev/fd")) - descriptors:
                try:
                    self._close(int(leaked))
                except OSError:
                    pass
        return outcome

    def count_steps(self, call) -> tuple[str, list[str]]:
        self.count, self.target, self.when, self.labels = 0, 0, "", []
        return self._call(call), list(self.labels)

    def interrupt(self, call, target: int, when: str) -> str:
        self.count, self.target, self.when, self.delivered = 0, target, when, False
        return self._call(call)


def sweep_every_step(steps: StepInterrupts, prepare, call, verify) -> tuple[list[str], list[str]]:
    """Interrupt `call` before and after every one of its steps, on fresh state."""
    prepare()
    _, labels = steps.count_steps(call)
    failures = []
    for when in ("before", "after"):
        for target in range(1, len(labels) + 1):
            prepare()
            outcome = steps.interrupt(call, target, when)
            problems = []
            if not steps.delivered:
                problems.append("the interrupt was never delivered")
            if outcome == "returned":
                problems.append("the interrupt was swallowed")
            if signal.getsignal(signal.SIGINT) is not signal.default_int_handler:
                problems.append("the SIGINT handler was not restored")
            problem = verify(outcome)
            if problem:
                problems.append(problem)
            if problems:
                failures.append(f"{when} step {target} {labels[target - 1]} -> {outcome}: {'; '.join(problems)}")
    return labels, failures


def _report(labels: list[str], failures: list[str]) -> str:
    return f"{len(failures)} of {2 * len(labels)} interruptions failed:\n" + "\n".join(failures)


@pytest.mark.parametrize("run", ["success", "failure"])
def test_l0_r11_human_gem_interrupt_at_every_step_leaves_only_rollback_state(
    tmp_path, fixture_downloads, monkeypatch, run
):
    payloads, _ = fixture_downloads
    last = assets._HUMAN_ASSETS[-1].source_url
    failing = {"on": True}
    if run == "failure":
        def fail_last(request, timeout):
            if failing["on"] and request.full_url == last:
                raise TimeoutError("technical failure after every other asset")
            return Response(payloads[request.full_url], request.full_url)

        monkeypatch.setattr(assets, "_open_url", fail_last)
    steps = StepInterrupts(monkeypatch)
    roots = iter(range(10**6))
    state = {}

    def prepare():
        root = tmp_path / f"technical-cache-{next(roots)}"
        root.mkdir(mode=0o700)
        monkeypatch.setenv("LIVEMORE_MODEL_DIR", str(root))
        state["root"] = root

    def verify(outcome):
        root = state["root"]
        names = sorted(path.name for path in root.iterdir())
        left = [name for name in names if name.startswith((".install-human-gem-", ".livemore-aside-"))]
        if left:
            return f"left behind {left}"
        if ".install.lock" in names:
            info = (root / ".install.lock").lstat()
            if not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o600:
                return "the persistent lock is not a private 0600 file"
        package = [name for name in names if name.startswith("human-gem-")]
        if package and (run == "failure" or assets.status()["state"] != "verified"):
            return "a package was published that does not verify"
        # Nothing left blocks the next installation. L0-R13: the failure run
        # retries too, once the download that failed succeeds.
        failing["on"] = False
        try:
            if not assets.install()["available"]:
                return "a retry could not install"
        except assets.ModelAssetError as error:
            return f"a retry was refused: {error.code}"
        finally:
            failing["on"] = True
        return None

    labels, failures = sweep_every_step(steps, prepare, assets.install, verify)
    assert labels, "the operation made no filesystem calls"
    assert not failures, _report(labels, failures)


def test_l0_r11_human_gem_install_under_umask_0400_succeeds_or_leaves_no_lock(
    isolated, fixture_downloads
):
    isolated.mkdir(mode=0o700)
    lock = isolated / ".install.lock"
    previous = os.umask(0o400)
    try:
        try:
            result = assets.install()
        except assets.ModelAssetError as error:
            result = error
    finally:
        os.umask(previous)
    if isinstance(result, assets.ModelAssetError):
        assert not (lock.exists() or lock.is_symlink()), (
            f"{result.code}: the failed install left the lock it created")
    else:
        assert result["available"] is True
        assert stat.S_IMODE(lock.stat().st_mode) == 0o600
    assert not list(isolated.glob(".install-human-gem-*"))
    assert assets.install()["available"] is True


@pytest.mark.parametrize("moment", ["before", "after"])
def test_l0_r11_staging_cleanup_keeps_a_directory_supplied_at_its_name(
    tmp_path, isolated, fixture_downloads, monkeypatch, moment
):
    # A directory someone puts at the staging name, just before or just after
    # cleanup first touches that name, is theirs: it must survive cleanup.
    payloads, _ = fixture_downloads
    isolated.mkdir(mode=0o700)
    last = assets._HUMAN_ASSETS[-1].source_url
    state = {"cleanup": False, "done": False}
    original = {name: getattr(os, name) for name in ("stat", "lstat", "open", "rename", "rmdir", "unlink", "mkdir", "scandir", "listdir")}

    def fail_last(request, timeout):
        if request.full_url == last:
            state["cleanup"] = True
            raise TimeoutError("technical failure so cleanup runs")
        return Response(payloads[request.full_url], request.full_url)

    def supply(stage: Path):
        if _exists(stage):
            original["rename"](stage, tmp_path / "technical-original-staging")
        original["mkdir"](stage, 0o700)
        with open(stage / "technical-supplied.txt", "wb") as handle:
            handle.write(b"technical directory supplied by another process")
        state["supplied"] = original["stat"](stage, follow_symlinks=False).st_ino

    def _exists(path: Path) -> bool:
        try:
            original["stat"](path, follow_symlinks=False)
        except FileNotFoundError:
            return False
        return True

    def watch(name):
        def call(*args, **kwargs):
            subject = args[0] if args and isinstance(args[0], (str, os.PathLike)) else None
            stage = Path(subject) if subject is not None else None
            touches = (state["cleanup"] and not state["done"] and stage is not None
                       and stage.parent == isolated and stage.name.startswith(".install-human-gem-"))
            if touches and moment == "before":
                state["done"] = True
                supply(stage)
            try:
                return original[name](*args, **kwargs)
            finally:
                if touches and moment == "after":
                    state["done"] = True
                    supply(stage)
        return call

    monkeypatch.setattr(assets, "_open_url", fail_last)
    for name in original:
        monkeypatch.setattr(os, name, watch(name))
    with pytest.raises(assets.ModelAssetError):
        assets.install()
    for name in original:
        monkeypatch.setattr(os, name, original[name])

    assert state["done"], "cleanup never touched the staging name"
    remaining = [path for path in isolated.iterdir() if path.name.startswith(".install-human-gem-")]
    assert remaining, f"cleanup deleted the directory supplied {moment} it touched the staging name"
    (supplied,) = remaining
    assert supplied.stat().st_ino == state["supplied"], "the supplied directory was replaced"
    assert (supplied / "technical-supplied.txt").read_bytes() == b"technical directory supplied by another process"
    assert not list(isolated.glob(".livemore-aside-*"))


def test_l0_r11_restore_command_reports_nothing_pending_in_a_clean_cache(isolated):
    command = [sys.executable, "-m", "livemorebio.model_assets", "restore", "human-gem"]
    result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8")
    assert result.returncode == 0, result.stdout + result.stderr
    report = json.loads(result.stdout)
    assert report["model_id"] == "human-gem"
    assert report["restored"] == []
    assert not isolated.exists()


# L0-R11 round 1. Each case below is a defect the adversarial verifiers
# reproduced in build part 10, turned into a test that fails on that build.
class FillingVolume:
    """A volume that becomes full during the operation (verifier exp2b/exp2c,
    real HFS+ and APFS images). Once full, every call that needs new space fails
    with ENOSPC: making a directory or file, renaming and linking. Deleting
    still works, and there is room again once a file's last link and last
    open descriptor are gone, as on a real volume.
    """

    _NEEDS_SPACE = ("mkdir", "rename", "link", "replace", "symlink")

    def __init__(self, monkeypatch, fills_at):
        self.full = False
        self.freed = False
        self._fills_at = fills_at
        self._filling: set[int] = set()
        self.real = {name: getattr(os, name) for name in self._NEEDS_SPACE + (
            "open", "unlink", "close", "fstat", "stat", "listdir", "fsync")}
        for name in self._NEEDS_SPACE:
            monkeypatch.setattr(os, name, self._needs_space(self.real[name]))
        monkeypatch.setattr(assets, "_rename_exclusive", self._needs_space(assets._rename_exclusive))
        monkeypatch.setattr(os, "open", self._open)
        monkeypatch.setattr(os, "unlink", self._unlink)
        monkeypatch.setattr(os, "close", self._close)
        monkeypatch.setattr(os, "fsync", self._fsync)

    @staticmethod
    def _no_space():
        raise OSError(errno.ENOSPC, os.strerror(errno.ENOSPC))

    def _needs_space(self, original):
        def call(*args, **kwargs):
            if self.full:
                self._no_space()
            return original(*args, **kwargs)
        return call

    def _open(self, path, flags, *args, **kwargs):
        if self.full and flags & os.O_CREAT:
            self._no_space()
        descriptor = self.real["open"](path, flags, *args, **kwargs)
        if (self._fills_at is not None and flags & os.O_CREAT and isinstance(path, (str, os.PathLike))
                and self._fills_at(Path(os.fsdecode(path)))):
            self._filling.add(descriptor)
        return descriptor

    def _fsync(self, descriptor):
        if descriptor in self._filling:
            # The volume fills once; a retry after the space came back may finish.
            self._filling.clear()
            self._fills_at = None
            self.full = True
            self._no_space()
        return self.real["fsync"](descriptor)

    def _held(self, info) -> bool:
        for name in self.real["listdir"]("/dev/fd"):
            try:
                held = self.real["fstat"](int(name))
            except (OSError, ValueError):
                continue
            if (held.st_dev, held.st_ino) == (info.st_dev, info.st_ino):
                return True
        return False

    def _release(self, info) -> None:
        if self.full and info is not None and stat.S_ISREG(info.st_mode) and info.st_size and not self._held(info):
            self.full = False
            self.freed = True

    def _unlink(self, path, *args, **kwargs):
        try:
            info = self.real["stat"](path, *args, follow_symlinks=False, **kwargs)
        except OSError:
            info = None
        self.real["unlink"](path, *args, **kwargs)
        if info is not None and info.st_nlink == 1:
            self._release(info)

    def _close(self, descriptor):
        try:
            info = self.real["fstat"](descriptor)
        except OSError:
            info = None
        self.real["close"](descriptor)
        if info is not None and info.st_nlink == 0:
            self._release(info)


def test_l0_r11_round1_human_gem_rollback_on_a_filling_volume_frees_its_own_data_first(
    isolated, fixture_downloads, monkeypatch
):
    # Verifier exp2c: the receipt meets a full volume. Rollback must not need new
    # space before it has deleted the data this operation itself wrote.
    isolated.mkdir(mode=0o700)
    volume = FillingVolume(monkeypatch, lambda path: path.name == "installation.json")
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install()
    assert volume.freed, "the volume never got its space back"
    assert not volume.full
    assert refused.value.code == "unsafe_path"
    assert "Rollback" not in str(refused.value), str(refused.value)
    left = sorted(path.name for path in isolated.iterdir()
                  if path.name.startswith((".install-human-gem-", ".livemore-")))
    assert left == []
    assert assets.install()["available"] is True
    assert sorted(path.name for path in isolated.iterdir()) == [".install.lock", assets._PACKAGE]


def test_l0_r11_round1_publication_never_replaces_a_directory_made_at_the_package_name(
    isolated, fixture_downloads, monkeypatch
):
    # Verifier human_gem_package_dir: rename(2) silently replaces an empty
    # directory, so publication must refuse a taken name instead.
    isolated.mkdir(mode=0o700)
    package = isolated / assets._PACKAGE
    state = {}

    def theirs_appears():
        if "inode" not in state:
            os.mkdir(package, 0o700)
            state["inode"] = os.lstat(package).st_ino

    rename, exclusive = os.rename, assets._rename_exclusive

    def watched_rename(source, destination, *args, **kwargs):
        if Path(os.fsdecode(destination)) == package:
            theirs_appears()
        return rename(source, destination, *args, **kwargs)

    def watched_exclusive(source, destination, *args, **kwargs):
        if Path(os.fsdecode(destination)) == package:
            theirs_appears()
        return exclusive(source, destination, *args, **kwargs)

    monkeypatch.setattr(os, "rename", watched_rename)
    monkeypatch.setattr(assets, "_rename_exclusive", watched_exclusive)
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install()
    assert "inode" in state, "publication never reached the package name"
    assert os.lstat(package).st_ino == state["inode"], "their directory was replaced by the publication"
    assert os.listdir(package) == []
    assert refused.value.code == "busy"
    left = sorted(path.name for path in isolated.iterdir()
                  if path.name.startswith((".install-human-gem-", ".livemore-")))
    assert left == []


# L0-R11 round 2. Each case below is a defect the adversarial verifiers
# reproduced in the round-1 work, turned into a test that fails on that work.
def _command(*argv: str) -> tuple[int, dict]:
    result = subprocess.run([sys.executable, "-m", "livemorebio.model_assets", *argv],
                            capture_output=True, text=True, encoding="utf-8", timeout=300, check=False)
    output = result.stdout.strip()
    return result.returncode, (json.loads(output) if output else {"stderr": result.stderr[-2000:]})


def test_l0_r11_round2_check_and_restore_while_human_gem_installs_are_busy(
    isolated, fixture_downloads, monkeypatch
):
    # Verifier human_gem_window_before_lock: between making its rollback record
    # and taking its lock, the installation looked like one that did not
    # finish; check gave the restore command, and restore deleted its record.
    isolated.mkdir(mode=0o700)
    lock = isolated / ".install.lock"
    seen = {}
    opened = os.open

    def watched_open(file, flags, *args, **kwargs):
        if not seen and isinstance(file, (str, os.PathLike)) and Path(os.fsdecode(file)) == lock:
            for command in ("check", "restore"):
                seen[command] = _command(command, "human-gem")
        return opened(file, flags, *args, **kwargs)

    monkeypatch.setattr(os, "open", watched_open)
    result = assets.install()
    monkeypatch.setattr(os, "open", opened)
    assert seen, "the installation never reached its lock"
    for command, (code, output) in seen.items():
        assert code == 2 and output.get("error", {}).get("code") == "busy", (command, output)
    assert result["available"] is True
    assert sorted(path.name for path in isolated.iterdir()) == [".install.lock", assets._PACKAGE]


def _case_insensitive(directory: Path) -> bool:
    probe = directory / "technical-Case-Probe"
    probe.write_bytes(b"")
    try:
        return (directory / "TECHNICAL-CASE-PROBE").exists()
    finally:
        probe.unlink()


@pytest.mark.parametrize("spelling", ["through a symlinked parent", "back through a symlinked parent",
                                     "in another case"])
def test_l0_r11_round2_restore_finishes_a_record_made_under_another_spelling_of_the_root(
    tmp_path, fixture_downloads, monkeypatch, spelling
):
    # Verifier test_symlinked_root: the record kept each path as the root was
    # spelled when it was made, and restore compared paths as text, so another
    # spelling of the same directory was refused as outside the model's
    # directories, for ever.
    real = tmp_path / "real" / "models"
    real.mkdir(parents=True)
    os.chmod(real, 0o700)
    if spelling in {"through a symlinked parent", "back through a symlinked parent"}:
        (tmp_path / "link").symlink_to(tmp_path / "real", target_is_directory=True)
        made, restored = tmp_path / "link" / "models", real
        if spelling == "back through a symlinked parent":
            made, restored = restored, made
    else:
        if not _case_insensitive(tmp_path):
            pytest.skip("case-sensitive volume: another case names another directory")
        made, restored = real, tmp_path / "REAL" / "MODELS"
    payloads, _ = fixture_downloads
    first = assets._HUMAN_ASSETS[0].source_url

    root_identity = real.stat()
    make_aside = assets._make_aside_at
    failed = False

    def root_turns_read_only(request, timeout):
        nonlocal failed
        if request.full_url == first:
            failed = True
            raise TimeoutError("technical failure")
        return Response(payloads[request.full_url], request.full_url)

    def read_only_aside(directory, *args):
        # chmod(0500) does not deny Docker root. EROFS at the actual rollback
        # boundary leaves a real record on every filesystem and at any uid.
        if failed and os.path.samestat(os.fstat(directory), root_identity):
            raise OSError(errno.EROFS, "technical read-only filesystem")
        return make_aside(directory, *args)

    monkeypatch.setenv("LIVEMORE_MODEL_DIR", str(made))
    with monkeypatch.context() as faults:
        faults.setattr(assets, "_open_url", root_turns_read_only)
        faults.setattr(assets, "_make_aside_at", read_only_aside)
        with pytest.raises(assets.ModelAssetError) as refused:
            assets.install()
    assert refused.value.code == "aside_pending", f"{refused.value.code}: {refused.value}"
    assert any(kind == "record" and assets._record_entries(path)
               for path, kind in assets._pending("human-gem")), "the injected failure left no pending record"

    monkeypatch.setenv("LIVEMORE_MODEL_DIR", str(restored))

    def no_download(request, timeout):
        pytest.fail("pending recovery must refuse before any download")

    monkeypatch.setattr(assets, "_open_url", no_download)
    for action in (assets.check, assets.install):
        with pytest.raises(assets.ModelAssetError) as pending:
            action()
        assert pending.value.code == "aside_pending"
    result = assets.restore()
    assert result["state"] == "restored", result
    assert [name for name in os.listdir(real) if name.startswith((".install-human-gem-", ".livemore-"))] == []
    monkeypatch.setattr(assets, "_open_url", lambda request, timeout: Response(payloads[request.full_url], request.full_url))
    assert assets.install()["available"] is True


def test_l0_r19_root_identity_matches_aliases_but_refuses_an_unrelated_root(tmp_path):
    real = tmp_path / "real" / "models"
    real.mkdir(parents=True)
    (tmp_path / "link").symlink_to(real.parent, target_is_directory=True)
    alias = tmp_path / "link" / "models"
    unrelated = tmp_path / "unrelated" / "models"
    unrelated.mkdir(parents=True)
    # The recorded leaf may no longer exist after an interrupted rollback.
    assert assets._in_scope(real, alias / "absent-entry") == real / "absent-entry"
    assert assets._in_scope(alias, real / "absent-entry") == alias / "absent-entry"
    assert assets._in_scope(real, unrelated / "absent-entry") is None


def test_l0_r19_alternate_root_recovery_does_not_require_permission_enforcement(
    tmp_path, fixture_downloads, monkeypatch
):
    # Docker's root can write through 0500. Reproduce that capability without
    # root privileges or a platform-specific temporary-directory alias.
    chmod = os.chmod
    root = tmp_path / "real" / "models"

    def permissions_do_not_stop_owner(path, mode, *args, **kwargs):
        if Path(path) == root and mode == 0o500:
            return
        return chmod(path, mode, *args, **kwargs)

    monkeypatch.setattr(os, "chmod", permissions_do_not_stop_owner)
    test_l0_r11_round2_restore_finishes_a_record_made_under_another_spelling_of_the_root(
        tmp_path, fixture_downloads, monkeypatch, "through a symlinked parent"
    )


# L0-R11 round 3. Each case below is a defect the adversarial verifiers
# reproduced in the round-2 work, turned into a test that fails on that work.
_THEIRS = b"technical bytes written by another process of the same account\n"


def _rollback_state(root: Path) -> list[str]:
    return sorted(name for name in os.listdir(root) if name.startswith((".install-human-gem-", ".livemore-")))


@pytest.mark.parametrize("reported", ["EIO", "ENOENT"])
def test_l0_r11_round3_a_publication_that_took_effect_despite_an_error_is_kept(
    isolated, fixture_downloads, monkeypatch, reported
):
    # Verifier e1: the publication rename took effect and then reported an
    # error (ENOENT is what a retransmitted NFS RENAME returns). Rollback then
    # deleted every file of the published package through the staging
    # directory's descriptor, and the cache said corrupt for ever.
    isolated.mkdir(mode=0o700)
    package = isolated / assets._PACKAGE
    exclusive = assets._rename_exclusive
    number = getattr(errno, reported)
    state = {"fired": False}

    def took_effect_then_failed(source, destination, *args, **kwargs):
        result = exclusive(source, destination, *args, **kwargs)
        if not state["fired"] and Path(os.fsdecode(destination)) == package:
            state["fired"] = True
            raise OSError(number, os.strerror(number))
        return result

    monkeypatch.setattr(assets, "_rename_exclusive", took_effect_then_failed)
    try:
        assets.install()
    except assets.ModelAssetError:
        pass
    monkeypatch.setattr(assets, "_rename_exclusive", exclusive)
    assert state["fired"], "publication never ran"
    assert assets.status()["state"] == "verified", "the published package was emptied"
    assert sorted(os.listdir(isolated)) == [".install.lock", assets._PACKAGE]
    assert assets.restore()["state"] == "nothing_pending"
    assert assets.install()["available"] is True


def test_l0_r11_round3_the_end_of_an_install_never_deletes_a_directory_put_at_its_record_name(
    isolated, fixture_downloads, monkeypatch
):
    # Verifier human_gem_final_discard_replaced_record_dir: the record
    # directory was emptied and removed by path, deleting another process's
    # record.json and directory put at its name.
    isolated.mkdir(mode=0o700)
    discard = assets._discard_record_directory
    state: dict = {}

    def replaced(directory, *args, **kwargs):
        if not state:
            directory = Path(directory)
            moved = directory.with_name(directory.name + "-moved-by-other")
            os.rename(directory, moved)
            os.mkdir(directory, 0o755)
            (directory / "record.json").write_bytes(_THEIRS)
            state.update(record=directory, moved=moved, inode=os.lstat(directory).st_ino)
        return discard(directory, *args, **kwargs)

    monkeypatch.setattr(assets, "_discard_record_directory", replaced)
    result = assets.install()
    monkeypatch.setattr(assets, "_discard_record_directory", discard)
    assert state, "the install never removed its record directory"
    record = state["record"]
    assert record.is_dir() and os.lstat(record).st_ino == state["inode"], "the other process's directory was deleted"
    assert (record / "record.json").read_bytes() == _THEIRS, "the other process's record.json was deleted"
    assert not state["moved"].exists(), "this operation's own record directory was left"
    assert result["available"] is True


def _long_directory(base: Path, total: int) -> Path:
    path = str(base)
    need = total - len(path)
    assert need >= 2
    while need > 0:
        take = min(200, need - 1)
        if need - (take + 1) == 1:
            take -= 1
        path += "/" + "d" * take
        need = total - len(path)
    assert len(path) == total
    return Path(path)


@pytest.mark.parametrize(("margin", "download"), [(46, "succeeds"), (64, "fails")])
def test_l0_r11_round3_a_human_gem_rollback_never_needs_a_longer_path_than_the_install(
    tmp_path, fixture_downloads, monkeypatch, margin, download
):
    # Verifier A3-long-path-human-gem: near PATH_MAX the staging directory could
    # not be moved into an aside (whose path is ~56 characters longer), so the
    # record and staging stayed and restore refused for ever.
    limit = os.pathconf(tmp_path, "PC_PATH_MAX")
    root = _long_directory(tmp_path / "long", limit - margin)
    root.parent.mkdir(parents=True, exist_ok=True)
    root.mkdir(mode=0o700)
    monkeypatch.setenv("LIVEMORE_MODEL_DIR", str(root))
    payloads, _ = fixture_downloads
    last = assets._HUMAN_ASSETS[-1].source_url

    def fail_last(request, timeout):
        if download == "fails" and request.full_url == last:
            raise TimeoutError("technical failure after every other asset")
        return Response(payloads[request.full_url], request.full_url)

    monkeypatch.setattr(assets, "_open_url", fail_last)
    try:
        assets.install()
    except assets.ModelAssetError as error:
        assert error.code != "aside_pending", str(error)
    assert _rollback_state(root) == []
    assert assets.restore()["state"] == "nothing_pending"


@pytest.mark.parametrize(("command", "where"), [
    ("install", "the package's existence check"),
    ("install", "Human-GEM.xml after publication"),
    ("check", "the package's existence check"),
    ("status", "the package's existence check"),
    ("check", "Human-GEM.xml, denied"),
])
def test_l0_r11_round3_an_io_error_reading_the_human_gem_cache_is_a_refusal_not_a_traceback(
    isolated, fixture_downloads, monkeypatch, capsys, command, where
):
    # Verifiers e8 and A4: one EIO or EACCES at a stat of the package or of an
    # asset (Path.exists() raises them) escaped install, check and status, and
    # the CLI, as a raw OSError traceback.
    isolated.mkdir(mode=0o700)
    package = isolated / assets._PACKAGE
    if command != "install":
        assert assets.install()["available"] is True
    target = package if "package" in where else package / "Human-GEM.xml"
    number = errno.EACCES if where.endswith("denied") else errno.EIO
    state = {"fired": False}
    real = {name: getattr(os, name) for name in ("stat", "lstat")}

    def failing(name):
        def call(file, *args, **kwargs):
            if (not state["fired"] and "dir_fd" not in kwargs and isinstance(file, (str, os.PathLike))
                    and Path(os.fsdecode(file)) == target):
                if where.endswith("after publication"):
                    try:
                        real["lstat"](package)  # the fault is in the verification after publication
                    except FileNotFoundError:
                        return real[name](file, *args, **kwargs)
                state["fired"] = True
                raise OSError(number, os.strerror(number), os.fsdecode(file))
            return real[name](file, *args, **kwargs)
        return call

    for name in real:
        monkeypatch.setattr(os, name, failing(name))
    code = assets.main([command, "human-gem"])
    for name, function in real.items():
        monkeypatch.setattr(os, name, function)
    output = capsys.readouterr().out
    assert state["fired"], f"{command} never read {where}"
    report = json.loads(output)
    if command == "status":
        assert code == 0 and report["available"] is False and report["state"] in ("unsafe_path", "corrupt"), report
    else:
        assert code == 2 and report["error"]["code"] in ("unsafe_path", "corrupt"), report
    assert _rollback_state(isolated) == []


def test_l0_r11_round3_a_human_gem_cache_too_long_to_verify_is_a_refusal_not_a_traceback(
    tmp_path, fixture_downloads, monkeypatch
):
    # Verifier A4 (a): with a 976-character root the install published the
    # package, then hashing it raised ENAMETOOLONG raw from Path.exists(), as
    # did every status and check afterwards. A package whose files the
    # platform cannot name is now refused before anything is made.
    limit = os.pathconf(tmp_path, "PC_PATH_MAX")
    root = _long_directory(tmp_path / "long", limit - 48)
    root.parent.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("LIVEMORE_MODEL_DIR", str(root))
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install()
    assert refused.value.code == "unsafe_path" and "too long" in str(refused.value), str(refused.value)
    assert [name for name in os.listdir(root) if not name.startswith(".install.lock")] == []
    assert assets.status()["state"] == "missing"
    assert assets.check()["state"] == "missing"
    assert assets.main(["check", "human-gem"]) == 2


@pytest.mark.skipif(not sys.platform.startswith(("linux", "darwin")), reason="POSIX set-group-ID directories")
def test_l0_r11_round3_a_human_gem_cache_in_a_set_group_id_directory_installs(
    tmp_path, fixture_downloads, monkeypatch
):
    # Verifier K-linux-setgid: on Linux a directory made inside a set-group-ID
    # directory gets that bit too, so the cache (and its staging) were 02700
    # and the install refused unsafe_path. Set-group-ID grants no access.
    shared = tmp_path / "shared"
    shared.mkdir(mode=0o755)
    os.chmod(shared, 0o2755)
    if not os.lstat(shared).st_mode & stat.S_ISGID:
        pytest.skip("this account cannot set the set-group-ID bit here")
    if not sys.platform.startswith("linux"):
        mkdir = os.mkdir

        def inherited(path, mode=0o777, *, dir_fd=None):
            mkdir(path, mode, dir_fd=dir_fd)
            parent = os.path.dirname(os.fsdecode(path)) or "."
            if os.stat(parent, dir_fd=dir_fd).st_mode & stat.S_ISGID:
                current = stat.S_IMODE(os.stat(path, dir_fd=dir_fd, follow_symlinks=False).st_mode)
                os.chmod(path, current | stat.S_ISGID, dir_fd=dir_fd)

        monkeypatch.setattr(os, "mkdir", inherited)
    root = shared / "models"
    monkeypatch.setenv("LIVEMORE_MODEL_DIR", str(root))
    assert assets.install()["available"] is True
    assert os.lstat(root).st_mode & stat.S_ISGID
    assert _rollback_state(root) == []
    assert assets.check()["available"] is True
    assert assets.restore()["state"] == "nothing_pending"


# L0-R13. Codex's fourth review of 8c9f9a5 (l0-review4-report.txt).
class _FullVolume:
    """A volume with no free space at all: every call that needs new space
    fails with ENOSPC (making a directory, creating a file, writing, linking,
    renaming). Reading, and opening what already exists, still work."""

    def __init__(self, patch):
        real_open, real_stat = os.open, os.stat

        def no_space(*args, **kwargs):
            raise OSError(errno.ENOSPC, os.strerror(errno.ENOSPC))

        def open_(path, flags, *args, **kwargs):
            if flags & os.O_CREAT:
                try:
                    real_stat(path, dir_fd=kwargs.get("dir_fd"), follow_symlinks=False)
                except FileNotFoundError:
                    no_space()
            return real_open(path, flags, *args, **kwargs)

        for name in ("mkdir", "write", "link", "rename", "replace", "symlink"):
            patch.setattr(os, name, no_space)
        patch.setattr(os, "open", open_)
        patch.setattr(assets, "_rename_exclusive", no_space)


def test_l0_r13_an_installed_human_gem_package_installs_again_on_a_full_volume(isolated, fixture_downloads):
    # Review 4, minor 4 (model_assets.py:2916): the install made its rollback
    # record and its 256 KiB reserve before it looked for the installed
    # package, so on a full volume an install with nothing to do was refused.
    _, calls = fixture_downloads
    assert assets.install()["available"] is True
    before = sorted(os.listdir(isolated))
    downloads = len(calls)
    with pytest.MonkeyPatch.context() as full:
        _FullVolume(full)
        try:
            result = assets.install()
        except assets.ModelAssetError as error:
            result = {"available": False, "state": error.code, "reason": str(error)}
    assert result["available"] is True, f"an installed, verified package was refused on a full volume: {result}"
    assert result["state"] == "verified", result
    assert len(calls) == downloads
    assert sorted(os.listdir(isolated)) == before
