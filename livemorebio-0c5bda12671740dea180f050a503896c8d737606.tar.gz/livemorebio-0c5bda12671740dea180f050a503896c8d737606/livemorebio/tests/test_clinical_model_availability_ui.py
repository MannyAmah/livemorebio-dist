"""Red-first UI contract for descriptive clinical selection, not clinical data.

All records/measurements below are explicitly authored local technical fixtures.
These tests do not admit a participant, access services, or execute a model.
The proposed selectors use existing product patterns; no interface is changed.
"""
from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess
import pytest

from .biology_ui_fixtures import biology_controller_script
from .test_workspace_stream_ui import FIXTURE as LEGACY_WORKSPACE_FIXTURE
from .test_execution_view_ui import PREAMBLE as EXECUTION_FIXTURE
from ._node import require_node

CONSOLE = Path(__file__).parents[1] / "aegle/console"


def node(script: str, *, module: bool = False) -> None:
    command = [require_node()]
    if module:
        command += ["--input-type=module"]
    result = subprocess.run(command + ["--eval", script], capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr


AVAILABILITY_FIXTURE = r"""
const unavailable={schema:'livemore.model-availability.v1',state:'UNAVAILABLE',reason_code:'MODEL_BINDING_REQUIRED',selection_mode:'observations_only',twin_id:'twin-technical-unbound',twin_version:2,source_generation:'technical-generation-b',preparation_available:false};
const readyAvailability={...unavailable,state:'READY',reason_code:null,selection_mode:'model',twin_id:'twin-technical-ready',twin_version:1,source_generation:'technical-generation-a',preparation_available:true};
const observation={id:'observed_glucose_mgdl',signal:'glucose_mgdl',current:107,unit:'mg/dL',source_hash:'d'.repeat(64),data_class:'technical_fixture',status:'recorded',captured_at:'2026-09-08T12:00:00Z',received_at:'2026-09-08T12:00:01Z',provenance:'Authored local controller fixture; not a participant measurement'};
function unavailableWorkspace(){const value=fixture();value.context_id='b'.repeat(64);value.model_availability={...unavailable};value.subject={twin_id:unavailable.twin_id,version:2,display_label:'Technical unbound selection — no participant',source_class:'REAL_HUMAN'};for(const key of ['profile','base','profile_params','pk_context','parameter_provenance','provenance','intervention','metabolic','cardiac','hepatic','comparison'])value.twin[key]=null;value.twin.applied=[];value.twin.active_execution=null;value.multiscale.active_execution=null;value.multiscale.comparison=null;value.observation_channels=[observation];value.multiscale.patch_reconciliation.signals=[];return value;}
"""


def workspace_script() -> str:
    projection = (CONSOLE / "lib/biological_projection.js").read_text(encoding="utf-8").replace("export function", "function")
    controller = re.sub(r"^import .*?;\n", "", (CONSOLE / "lib/workspace.js").read_text(encoding="utf-8"), flags=re.M)
    return projection + "\n" + controller[:controller.rfind("main().catch(")]


def subject_script() -> str:
    source = re.sub(r"^import .*?;\n", "", (CONSOLE / "lib/subjects.js").read_text(encoding="utf-8"), flags=re.M)
    return source.split('document.querySelector("#refresh-records")', 1)[0]


def subject_node(script: str) -> None:
    module = (CONSOLE / "lib/selection_reconciliation.js").as_uri()
    node("(async()=>{const {mountSelectionReconciliation,selectionRequest:requestSelection}=await import(" + json.dumps(module) + ");\n" + script + "\n})().catch(e=>{console.error(e);process.exitCode=1});")


def test_legacy_ready_workspace_projection_is_preserved_exactly():
    node(LEGACY_WORKSPACE_FIXTURE + "\n" + AVAILABILITY_FIXTURE + "\n" + r"""
const a=require('node:assert/strict'),vm=require('node:vm'),context={URLSearchParams,payload:fixture()};
vm.runInNewContext(SOURCE,context);const result=vm.runInNewContext('validatedWorkspaceSnapshot(payload)',context);
a.deepEqual(JSON.parse(JSON.stringify(result)),context.payload);a.equal(result.twin.metabolic.glucose[0],90);a.equal(result.multiscale.comparison.treated.heart_rate_bpm,70);
""".replace("SOURCE", json.dumps(workspace_script())))


def test_typed_unavailable_workspace_is_admitted_without_reconstructing_physiology():
    node(LEGACY_WORKSPACE_FIXTURE + "\n" + AVAILABILITY_FIXTURE + "\n" + r"""
const a=require('node:assert/strict'),vm=require('node:vm'),context={URLSearchParams,payload:unavailableWorkspace()};
vm.runInNewContext(SOURCE,context);const result=vm.runInNewContext('validatedWorkspaceSnapshot(payload)',context);
a.equal(result.model_availability.reason_code,'MODEL_BINDING_REQUIRED');a.equal(result.twin.metabolic,null);a.equal(result.twin.cardiac,null);a.equal(result.multiscale.active_execution,null);a.equal(result.multiscale.comparison,null);a.equal(result.multiscale.systems.length,1);a.equal(result.observation_channels[0].source_hash,observation.source_hash);a(Object.isFrozen(result));
""".replace("SOURCE", json.dumps(workspace_script())))


def test_unavailable_rejects_retained_physiology_and_incoherent_availability():
    node(LEGACY_WORKSPACE_FIXTURE+'\n'+AVAILABILITY_FIXTURE+'\n'+r"""
const a=require('node:assert/strict'),vm=require('node:vm'),context={URLSearchParams};vm.runInNewContext(SOURCE,context);
for(const mutate of [x=>x.twin.metabolic=fixture().twin.metabolic,x=>x.multiscale.active_execution=fixture().multiscale.active_execution,x=>x.twin.applied=['old action'],x=>x.model_availability.preparation_available=true,x=>x.model_availability.twin_version=true,x=>x.model_availability.selection_mode='model',x=>x.subject.version=3,x=>x.model_availability.reason_code='invented',x=>x.model_availability.schema='future',x=>x.model_availability.extra=true]){const value=unavailableWorkspace();mutate(value);context.payload=value;a.throws(()=>vm.runInNewContext('validatedWorkspaceSnapshot(payload)',context));}
""".replace('SOURCE',json.dumps(workspace_script())))


def test_secondary_panel_failure_after_unavailable_selection_never_restores_old_subject():
    node(LEGACY_WORKSPACE_FIXTURE+'\n'+AVAILABILITY_FIXTURE+'\n'+r"""
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();let clears=0;
function el(id){if(!nodes.has(id))nodes.set(id,{textContent:'OLD_SUBJECT_EVIDENCE',innerHTML:'OLD_SUBJECT_EVIDENCE',width:100,height:100,dataset:{},classList:{toggle(){}},setAttribute(){},removeAttribute(){},replaceChildren(){this.innerHTML='';this.textContent=''},getContext:()=>({clearRect:()=>clears++})});return nodes.get(id)}
const context={URLSearchParams,payload:unavailableWorkspace(),prior:fixture(),escapeHTML:x=>String(x),fmt:x=>String(x),clearInterval(){},document:{body:{dataset:{}},querySelector:el,querySelectorAll:()=>[]}};
vm.runInNewContext(SOURCE+'\nWORKSPACE=prior;renderCoverage=()=>{throw Error("technical secondary failure")};',context);
a.throws(()=>vm.runInNewContext('acceptWorkspace(payload)',context));a.equal(vm.runInNewContext('WORKSPACE.subject.twin_id',context),'twin-technical-unbound');a.equal(vm.runInNewContext('WORKSPACE.twin.metabolic',context),null);
for(const id of ['#mechanism-loop','#evidence-content','#action-detail','#key-metrics','#chart-provenance','#focus-readout','#body-signal-label'])a(!el(id).innerHTML.includes('OLD_SUBJECT_EVIDENCE')&&!el(id).textContent.includes('OLD_SUBJECT_EVIDENCE'),'old DOM retained: '+id);
a(clears>=2,'prior canvas pixels survived');a(el('#workspace-subject').textContent.includes('Technical unbound'));a.equal(el('#atlas-reference-host').innerHTML,'OLD_SUBJECT_EVIDENCE','reference Atlas was removed');
""".replace('SOURCE',json.dumps(workspace_script())))


def test_unavailable_clears_actual_action_flow_done_and_current_classes():
    html=(CONSOLE/'workspace.html').read_text(encoding="utf-8")
    assert 'id="action-flow"' in html and 'data-state="COMPLETED"' in html
    node(LEGACY_WORKSPACE_FIXTURE+'\n'+AVAILABILITY_FIXTURE+'\n'+r"""
const a=require('node:assert/strict'),vm=require('node:vm');
const steps=['QUEUED','RUNNING','COMPLETED'].map(state=>{const classes=new Set(['done','current']);return{dataset:{state},classes,classList:{toggle(k,v){v?classes.add(k):classes.delete(k)}}}});
const nodes=new Map(),el=id=>{if(!nodes.has(id))nodes.set(id,{textContent:''});return nodes.get(id)};
const context={URLSearchParams,payload:unavailableWorkspace(),document:{querySelector:el,querySelectorAll:selector=>selector==='#action-flow [data-state]'?steps:[]}};
vm.runInNewContext(SOURCE+'\nWORKSPACE=payload;renderAction();',context);
a(steps.every(step=>!step.classes.has('done')&&!step.classes.has('current')),'completed action dots survived unavailable model');
""".replace('SOURCE',json.dumps(workspace_script())))


def test_workspace_unavailable_transition_clears_charts_and_keeps_reference_and_observations():
    node(LEGACY_WORKSPACE_FIXTURE + "\n" + AVAILABILITY_FIXTURE + "\n" + r"""
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();let numericDraws=0,clears=0;
function el(id){if(!nodes.has(id))nodes.set(id,{textContent:'PRIOR_PHYSIOLOGY',innerHTML:'PRIOR_PHYSIOLOGY',value:'',disabled:false,hidden:false,width:500,height:200,clientWidth:500,clientHeight:200,dataset:{},classList:{toggle(){}},setAttribute(){},removeAttribute(){},replaceChildren(){this.innerHTML=''},getContext:()=>({clearRect(){clears++}})});return nodes.get(id)}
const context={URLSearchParams,document:{body:{dataset:{}},querySelector:el,querySelectorAll:()=>[]},window:{},clearInterval(){},escapeHTML:x=>String(x),fmt:x=>String(x),drawChart:()=>numericDraws++,payload:unavailableWorkspace()};
vm.runInNewContext(SOURCE+'\nWORKSPACE=payload;TIME_TIMER=42;TIME_INDEX=2;',context);
// Exercise actual numerical consumers, not a replacement renderer.
vm.runInNewContext('renderComparison();renderMechanism();renderTimeline();',context);
a.equal(numericDraws,0);a(clears>=2,'old plot pixels not cleared');a(!el('#key-metrics').innerHTML.includes('PRIOR_PHYSIOLOGY'));a(!el('#mechanism-loop').innerHTML.includes('PRIOR_PHYSIOLOGY'));a(el('#time-play').disabled);a(el('#time-slider').disabled);a.equal(vm.runInNewContext('TIME_TIMER',context),null);a.equal(vm.runInNewContext('WORKSPACE.multiscale.systems.length',context),1);a.equal(vm.runInNewContext('WORKSPACE.observation_channels[0].current',context),107);
""".replace("SOURCE", json.dumps(workspace_script())))


def test_biology_unavailable_transition_keeps_reference_organs_not_prior_profile_or_cell_replay():
    script = biology_controller_script()
    node(AVAILABILITY_FIXTURE + "\n" + r"""
const a=require('node:assert/strict'),vm=require('node:vm'),elements=new Map(),timers=[],listeners={};let payload;
function el(id){if(!elements.has(id))elements.set(id,{textContent:'',innerHTML:'',style:{},dataset:{},disabled:false,handlers:{},addEventListener(k,v){this.handlers[k]=v},setAttribute(){},removeAttribute(){},replaceChildren(){this.innerHTML=''}});return elements.get(id)}
const organ={id:'heart',name:'Reference heart',status:'parameter',metric:'IKr block parameter',value:0,ratio:null,targets:[],pathways:[],cell:{type:'Myocyte',render:'cardiac',activity:null,quantities:[],evidence_state:'REFERENCE_ONLY'}};
payload={context_id:'a'.repeat(64),model_availability:readyAvailability,twin:{profile:'TECHNICAL_PRIOR_PROFILE',conditions:[],Si:1,Gb:90,gamma:1},organs:[organ]};
const context={URLSearchParams,AbortController,location:{search:''},window:{},document:{hidden:false,getElementById:el,querySelector:el,createElement:()=>({getContext:()=>null}),addEventListener:(k,v)=>listeners[k]=v},console:{warn(){}},fetch:async()=>({ok:true,status:200,json:async()=>payload}),setTimeout:(f,n)=>{timers.push({f,n});return timers.length},clearTimeout(){},performance:{now:()=>0},addEventListener(){},cancelAnimationFrame(){},requestAnimationFrame(){throw Error('unavailable state may not start replay')}};
(async()=>{await vm.runInNewContext('(async()=>{'+SOURCE+'})()',context);for(let i=0;i<8;i++)await new Promise(setImmediate);a(el('panel').innerHTML.includes('TECHNICAL_PRIOR_PROFILE'));
payload={context_id:'b'.repeat(64),model_availability:unavailable,twin:{profile:null,Si:null,Gb:null,gamma:null,conditions:[]},organs:[{...organ,status:'reference',metric:null,value:null,unit:null,evidence_state:'REFERENCE_ONLY'}]};await timers.find(x=>x.n===8000).f();
a(el('panel').innerHTML.includes('Reference heart'),'reference anatomy was removed');a(!el('panel').innerHTML.includes('TECHNICAL_PRIOR_PROFILE'));a(!el('twinMeta').textContent.includes('null'));a(el('biology-status').textContent.includes('MODEL_BINDING_REQUIRED'));a(!el('biology-status').textContent.includes('Current executable model'));a(el('biology-retry').hidden,'successful unavailable projection was mislabeled transport failure');
})().catch(e=>{console.error(e);process.exitCode=1});
""".replace("SOURCE", json.dumps(script)))


def test_patch_unavailable_has_no_default_time_axis_but_preserves_admitted_observation_card():
    script = re.findall(r"<script>(.*?)</script>", (CONSOLE / "patch.html").read_text(encoding="utf-8"), re.S)[0]
    node(AVAILABILITY_FIXTURE + "\n" + r"""
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();let payload;
function el(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',value:0,max:0,open:false,disabled:false,hidden:false,style:{},dataset:{},addEventListener(){},setAttribute(){},replaceChildren(){this.innerHTML=''}});return nodes.get(id)}
const context={document:{hidden:false,getElementById:el,addEventListener(){}},window:{addEventListener(){}},console,performance:{now:()=>0},fetch:async()=>({ok:true,status:200,json:async()=>payload}),requestAnimationFrame:()=>1,setInterval:()=>1,cancelAnimationFrame(){},clearInterval(){}};
vm.runInNewContext(SOURCE,context);payload={context_id:'a'.repeat(64),model_availability:readyAvailability,profile:'TECHNICAL_PRIOR_PROFILE',day_minutes:10,contract:{},channels:[{...observation,id:'glucose',data_class:'modeled',series:[[0,100],[10,110]]}],n_recorded:1,n_pending:0,n_recent_observed:0};
(async()=>{await vm.runInNewContext('load(false)',context);vm.runInNewContext('PLAYING=true',context);payload={context_id:'b'.repeat(64),model_availability:unavailable,profile:null,day_minutes:null,contract:{},channels:[observation],n_recorded:0,n_pending:0,n_recent_observed:0};await vm.runInNewContext('load(true)',context);
a.equal(vm.runInNewContext('PLAYING',context),false);a.notEqual(vm.runInNewContext('DAY',context),840,'fake fallback time axis');a(el('scrub').disabled);a(el('playBtn').disabled);a(el('chGrid').innerHTML.includes('107'));a(el('chGrid').innerHTML.includes('2026-09-08T12:00:00Z'));a(!el('chGrid').innerHTML.includes('<canvas'));a(!el('subjPill').textContent.includes('null'));a(el('note').textContent.includes('MODEL_BINDING_REQUIRED'));
})().catch(e=>{console.error(e);process.exitCode=1});
""".replace("SOURCE", json.dumps(script)))


@pytest.mark.parametrize('terminal_state',['stopped','completed','failed','interrupted','paused','prepared','initializing','running'])
@pytest.mark.parametrize('failure_code',['EXECUTION_CLEANUP_UNCONFIRMED','CLEANUP_UNCONFIRMED'])
@pytest.mark.parametrize('source_valid',[False,True])
def test_execution_with_pending_owned_cleanup_keeps_explicit_stop_available(terminal_state, failure_code, source_valid):
    module = (CONSOLE / "lib/execution_view_state.js").as_uri()
    fixture = EXECUTION_FIXTURE.replace("process.argv[1]", json.dumps(module))
    node(fixture + "\n" + r"""
const {mountContinuousExecution}=await import(new URL('./continuous_execution.js',MODULE));
const nodes=new Map(),engineButtons=['start','pause','resume','stop'].map(action=>el('[engine-'+action+']',{engineAction:action})),lifeButtons=['pause','resume','stop'].map(action=>el('[life-'+action+']',{lifeAction:action}));
function el(key,dataset={}){if(!nodes.has(key))nodes.set(key,{value:key==='[data-engine]'?'metabolic-continuous-v1':'',handlers:{},dataset,classList:{toggle(){}},setAttribute(){},replaceChildren(){this.innerHTML=''},addEventListener(k,v){this.handlers[k]=v},textContent:'',innerHTML:''});return nodes.get(key)}
const host={innerHTML:'',classList:{toggle(){}},setAttribute(){},querySelector:el,querySelectorAll:key=>key==='[data-engine-action]'?engineButtons:key==='[data-life-action]'?lifeButtons:[]};globalThis.document={hidden:false,addEventListener(){},removeEventListener(){}};globalThis.window={addEventListener(){}};globalThis.location={search:'?execution_id='+status.execution_id};
const stopped={...status,state:'stopped',revision:4,control_revision:2,source_valid:false,failure_code:'EXECUTION_CLEANUP_UNCONFIRMED'},response=v=>({ok:true,json:async()=>v});let mutations=0;globalThis.fetch=async(url,options)=>{if(options.method==='POST'){mutations++;const body=JSON.parse(options.body);assert(url.endsWith('/stop'),'not explicit cleanup');assert(body.expected_control_revision===2&&body.expected_source_generation===status.source_generation,'cleanup lost exact guards');return response({...stopped,revision:5,control_revision:3,failure_code:null})}return response(page([frame(1),frame(2)],stopped))};
const mounted=mountContinuousExecution(host);try{for(let i=0;i<5;i++)await new Promise(r=>setTimeout(r,0));assert(!engineButtons[3].disabled,'Stop unavailable while owned cleanup is pending');assert(engineButtons[0].disabled&&engineButtons[2].disabled,'unavailable numerical start/resume enabled');engineButtons[3].handlers.click();for(let i=0;i<5;i++)await new Promise(r=>setTimeout(r,0));assert(mutations===1,'cleanup mutation repeated');assert(engineButtons[3].disabled,'ordinary stopped source became general repeat-stop bypass');}finally{mounted.dispose();}
    """.replace("MODULE", json.dumps(module)).replace("state:'stopped'",f"state:{json.dumps(terminal_state)}").replace("'EXECUTION_CLEANUP_UNCONFIRMED'",json.dumps(failure_code)).replace('source_valid:false',f'source_valid:{json.dumps(source_valid)}').replace("return response({...stopped,revision:5,control_revision:3,failure_code:null})", f"return response({{...stopped,state:{json.dumps(terminal_state if terminal_state in ['completed','stopped'] else 'stopped')},revision:5,control_revision:3,failure_code:null}})"), module=True)


def test_real_person_has_explicit_observation_only_selection_with_exact_revision_and_no_activation():
    subject_node(AVAILABILITY_FIXTURE + "\n" + r"""
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();const posts=[];let reloads=0;
const button={dataset:{selectObservations:'twin-technical-unbound',version:'2'},handlers:{},addEventListener(k,v){this.handlers[k]=v}};
function el(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',dataset:{},classList:{toggle(){}},setAttribute(){},addEventListener(){},removeEventListener(){},querySelectorAll:selector=>selector==='[data-select-observations]'?[button]:[]});return nodes.get(id)}
const record={twin_id:'twin-technical-unbound',subject_id:'technical-pseudonym',version:2,display_label:'Technical unbound intake — no participant',source_class:'REAL_HUMAN',lifecycle:'READY',conditions:[],observations:{},patch_bindings:[],model_availability:unavailable};
const confirmed={twins:[record],selection_status:'CONFIRMED',active:{...record,lifecycle:'ACTIVE'}};
const context={document:{body:{dataset:{subjectView:'twins'},setAttribute(){}},querySelector:el,querySelectorAll:()=>[]},escapeHTML:x=>String(x),setTimeout:()=>1,mountSelectionReconciliation,selectionRequest:(path,options)=>requestSelection(path,{...options,fetcher:context.fetch}),fetch:async(url,options)=>{posts.push({url,body:JSON.parse(options.body)});return new Response(JSON.stringify({model_availability:unavailable}),{headers:{'X-Request-ID':'563e4d61-9872-4fe3-820b-a18903a522a0'}})},reload:async()=>{reloads++;return confirmed}};
vm.runInNewContext(SOURCE+'\nload=reload;',context);context.payload=confirmed;vm.runInNewContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload);renderTwins(payload)',context);a(el('#record-list').innerHTML.includes('data-select-observations'),'no explicit observation-selection action');await button.handlers.click();a.equal(posts.length,1);a(posts[0].url.endsWith('/select-observations'));a.deepEqual(posts[0].body,{expected_version:2});a.equal(reloads,1);a(!posts.some(p=>p.url.endsWith('/activate')));vm.runInNewContext('selectionRecovery.dispose()',context);
""".replace("SOURCE", json.dumps(subject_script())))


def test_committed_selection_cleanup_uncertainty_re_reads_state_without_repeating_post():
    subject_node(AVAILABILITY_FIXTURE + "\n" + r"""
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();let posts=0,reloads=0;
const button={dataset:{selectObservations:'twin-technical-unbound',version:'2'},handlers:{},addEventListener(k,v){this.handlers[k]=v}};
function el(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',dataset:{},classList:{toggle(){}},setAttribute(){},addEventListener(){},removeEventListener(){},querySelectorAll:selector=>selector==='[data-select-observations]'?[button]:[]});return nodes.get(id)}
const record={twin_id:'twin-technical-unbound',subject_id:'technical-pseudonym',version:2,display_label:'Technical selection',source_class:'REAL_HUMAN',lifecycle:'READY',conditions:[],observations:{},patch_bindings:[],model_availability:unavailable};
const confirmed={twins:[record],selection_status:'CONFIRMED',active:{...record,lifecycle:'ACTIVE'}};
const context={document:{body:{dataset:{subjectView:'twins'},setAttribute(){}},querySelector:el,querySelectorAll:()=>[]},escapeHTML:x=>String(x),setTimeout:()=>1,mountSelectionReconciliation,selectionRequest:(path,options)=>requestSelection(path,{...options,fetcher:context.fetch}),fetch:async()=>{posts++;return new Response(JSON.stringify({code:'SELECTION_COMMITTED_CLEANUP_UNCONFIRMED',error:'Selection committed; owned numerical cleanup is unconfirmed'}),{status:503})},reload:async()=>{reloads++;return confirmed}};
vm.runInNewContext(SOURCE+'\nload=reload;',context);context.payload=confirmed;vm.runInNewContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload);renderTwins(payload)',context);a(el('#record-list').innerHTML.includes('data-select-observations'));await button.handlers.click();a.equal(posts,1);a.equal(reloads,1,'committed selection not re-read');a(/committed|cleanup/i.test(el('#selection-reconciliation-status').textContent));vm.runInNewContext('selectionRecovery.dispose()',context);
""".replace("SOURCE", json.dumps(subject_script())))


def test_real_cohort_summary_is_compact_and_member_inspection_is_explicit_not_a_run():
    node(AVAILABILITY_FIXTURE + "\n" + r"""
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map(),requests=[];
function el(id){if(!nodes.has(id))nodes.set(id,{innerHTML:'',textContent:'',dataset:{},classList:{toggle(){}},setAttribute(){},querySelectorAll:()=>[]});return nodes.get(id)}
const record={cohort_id:'cohort-technical-real',name:'Technical consented cohort — no participants',source_class:'REAL_HUMAN',size:1000,version:4,lifecycle:'FROZEN',indication:'descriptive only',execution_eligibility:{state:'UNAVAILABLE',reason_code:'MODEL_BINDING_REQUIRED'},seed:null,stratum:null};
const context={document:{body:{dataset:{subjectView:'cohorts'},setAttribute(){}},querySelector:el,querySelectorAll:()=>[]},escapeHTML:x=>String(x),setTimeout:()=>1,fetch:async(url)=>{requests.push(url);throw Error('no automatic request permitted')}};
vm.runInNewContext(SOURCE,context);context.payload={cohorts:[record]};vm.runInNewContext('renderCohorts(payload)',context);const html=el('#record-list').innerHTML;
a(html.length<12000);a(!html.includes('seed null'));a(html.includes('MODEL_BINDING_REQUIRED'));a(/Inspect members|View members/.test(html),'no paged explicit member inspection');a(!html.includes('Run governed Cendos protocol'),'unbound cohort invited to execute');a.equal(requests.length,0);
""".replace("SOURCE", json.dumps(subject_script())))


def test_legacy_unavailable_clears_old_readouts_instead_of_catching_a_null_render_error():
    html = (CONSOLE / "index.html").read_text(encoding="utf-8")
    render = html.split("function render(){", 1)[1].split("// --- reactive metabolic curves ---", 1)[0]
    labels = 'function updateLegacyCardiacLabels(){' + html.split('function updateLegacyCardiacLabels(){', 1)[1].split('function updateLegacyControls(', 1)[0]
    node(AVAILABILITY_FIXTURE + "\n" + r"""
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();let banner='',draws=0,clears=0;
function el(id){if(!nodes.has(id)){const classes=new Set(['warn']),attrs={fill:'PRIOR_VOLTAGE_COLOR'};nodes.set(id,{innerHTML:'PRIOR_PHYSIOLOGY',textContent:'PRIOR_PHYSIOLOGY',title:'PRIOR_MEASURED_EVIDENCE',className:'prov prov-measured',disabled:false,width:100,height:100,classes,attrs,classList:{toggle(k,v){v?classes.add(k):classes.delete(k)}},setAttribute(k,v){attrs[k]=v},querySelector:key=>el(id+' '+key),getContext:()=>({clearRect:()=>clears++}),replaceChildren(){this.innerHTML=''}})}return nodes.get(id)}
const context={legacyBusy:false,S:{model_availability:unavailable,profile:null,systems:[{name:'Reference cardiovascular',status:'unavailable'}],applied:[],cardiac:null,metabolic:null,comparison:null,intervention:null},$:el,esc:x=>String(x??''),showBanner:text=>banner=text,console:{error(){}},drawMetab:()=>draws++,paintBody:()=>draws++};
vm.runInNewContext(LABEL_HELPER,context);
vm.runInNewContext('function render(){'+SOURCE+';render();',context);
for(const id of ['mVpeak','mApd','mCai','mBlk','mMean','mPeak'])a.notEqual(el(id).textContent,'PRIOR_PHYSIOLOGY','prior quantity retained: '+id);
a(!banner.includes('render error'));a.equal(draws,0);a(clears>=2,'old legacy charts not cleared');a(el('sysList').innerHTML.includes('Reference cardiovascular'));
a.notEqual(el('o-cardiac path').attrs.fill,'PRIOR_VOLTAGE_COLOR');a.notEqual(el('o-neural').attrs.fill,'PRIOR_VOLTAGE_COLOR');a(!el('mApdBox').classes.has('warn')&&!el('mBlkBox').classes.has('warn'));a(!el('metabProvChip').className.includes('measured'));a(!el('metabProvChip').title.includes('PRIOR_MEASURED'));a(!el('metabProvChip').textContent.includes('PRIOR_PHYSIOLOGY'));
a.deepEqual(['legacy-cardiac-state','legacy-cardiac-provenance','legacy-cardiac-time'].map(id=>el(id).textContent),['No current trace','unavailable','no current trace']);
""".replace("SOURCE", json.dumps(render)).replace("LABEL_HELPER", json.dumps(labels)))
