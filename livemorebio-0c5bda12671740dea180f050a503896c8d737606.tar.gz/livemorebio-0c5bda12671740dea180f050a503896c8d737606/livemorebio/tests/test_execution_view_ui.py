"""Typed UI projection tests. Authored frames are not biological validation."""
from pathlib import Path
import subprocess
from ._node import NODE, run_node as _run_node

ROOT=Path(__file__).resolve().parents[2]
MODULE=ROOT/'livemorebio/aegle/console/lib/execution_view_state.js'
PREAMBLE="""
const {ExecutionViewState,mergeNativeSeries,executionURLContext}=await import(process.argv[1]);
const assert=(value,message)=>{if(!value)throw Error(message)};
const selection={subject_id:'pseudonym-fixture',twin_id:'twin-fixture',twin_version:1,cohort_id:null,member_id:null,run_id:null,condition_id:'active-model-inputs',stage:'prospective-execution',source_data_class:'SYNTHETIC'};
const status={execution_id:'a'.repeat(32),source_snapshot_hash:'b'.repeat(64),source_generation:'source-fixture',selection,engine_contract_id:'metabolic-continuous-v1',native_axis:{unit:'min',maximum:840},native_time:2,latest_frame:2,revision:3,control_revision:1,state:'running',source_valid:true,authorship:'engine',evidence_class:'MODELED',independent_physical_validation:false};
const hash=index=>index.toString(16).padStart(64,'0');
const frame=(index)=>({schema:'livemore.execution-frame.v1',...status,frame_index:index,frame_hash:hash(index),previous_frame_hash:index===1?null:hash(index-1),native_start:index-1,native_end:index,native_unit:'min',checkpoint_hash:'c'.repeat(64),series:[['glucose_mgdl','mg/dL','plasma',90],['insulin_action_per_min','1/min','remote_insulin_action',0],['insulin_uU_ml','uU/mL','plasma',5]].map(([quantity,unit,compartment,value])=>({quantity,unit,compartment,native_times:[index-.5,index],values:[value,value]}))});
const page=(frames,execution=status)=>({execution,frames,next_after_frame:frames.at(-1)?.frame_index||0});
"""


def run(script):
    result=_run_node([NODE,'--input-type=module','-e',PREAMBLE+script,MODULE.as_uri()],capture_output=True,text=True, encoding="utf-8")
    assert result.returncode==0,result.stderr


def test_exact_committed_frames_advance_time_even_when_values_are_unchanged():
    run("""const state=new ExecutionViewState(status.execution_id);state.acceptPage(page([frame(1),frame(2)]));assert(state.cursor===2,'cursor');assert(state.series[0].values.every(x=>x===90),'invented values');assert(state.series[0].native_times.at(-1)===2,'constant value stalled clock');assert(state.following,'follow');""")


def test_wrong_context_sequence_hash_times_units_and_nonfinite_reject_atomically():
    run("""
for(const mutate of [f=>f.execution_id='d'.repeat(32),f=>f.source_snapshot_hash='d'.repeat(64),f=>f.selection={...f.selection,twin_id:'other'},f=>f.frame_index=3,f=>f.previous_frame_hash='f'.repeat(64),f=>f.series[0].values[0]=NaN,f=>f.series[0].unit='mmol/L',f=>f.series[0].native_times=[1,2],f=>f.series.pop()]){
const state=new ExecutionViewState(status.execution_id);state.acceptPage(page([frame(1)]));const before=JSON.stringify(state.series);const bad=frame(2);mutate(bad);let rejected=false;try{state.acceptPage(page([bad]))}catch{rejected=true}assert(rejected,'invalid frame admitted');assert(state.cursor===1&&JSON.stringify(state.series)===before,'partial publication');assert(!state.following&&state.stale,'invalid view still following');}
""")


def test_changed_duplicate_hash_and_source_invalid_or_offline_never_replay():
    run("""
const state=new ExecutionViewState(status.execution_id);state.acceptPage(page([frame(1)]));
state.acceptStatus({...status,source_valid:false,state:'paused'});assert(!state.following&&state.stale,'invalid source moving');
state.markStale('offline');assert(state.cursor===1&&state.series[0].values.at(-1)===90,'last historical values lost');
let rejected=false;try{state.acceptPage(page([{...frame(1),frame_hash:'e'.repeat(64)}]))}catch{rejected=true}assert(rejected,'changed duplicate accepted');
""")


def test_bounded_window_catchup_and_shared_boundary_rules():
    run("""
const state=new ExecutionViewState(status.execution_id,{windowSize:10});
for(let batch=0;batch<3;batch++){const frames=Array.from({length:10},(_,i)=>frame(batch*10+i+1));state.acceptPage(page(frames,{...status,latest_frame:30,native_time:30}));}
assert(state.cursor===30&&state.series[0].values.length===10,'window/catchup');assert(state.truncated,'retention not disclosed');
const a={quantity:'q',unit:'u',compartment:'c',native_times:[1,2],values:[3,4]};
assert(mergeNativeSeries(a,{...a,native_times:[2,3],values:[4,5]},10).native_times.join()==='1,2,3','boundary duplicate');
let rejected=false;try{mergeNativeSeries(a,{...a,native_times:[2,3],values:[9,5]},10)}catch{rejected=true}assert(rejected,'contradictory boundary merged');
""")


def test_no_frame_and_ambiguous_execution_urls_cannot_fall_back_to_active_twin():
    run("""
const state=new ExecutionViewState(status.execution_id);state.acceptPage(page([],{...status,latest_frame:0,native_time:0,state:'prepared',authorship:'uninitialized',evidence_class:'NOT_EXECUTED'}));assert(state.series.length===0&&state.cursor===0,'prepared output invented');
let rejected=false;try{executionURLContext('?execution_id='+status.execution_id+'&run_id=protocol-fixture')}catch{rejected=true}assert(rejected,'ambiguous source fallback');
assert(executionURLContext('?execution_id='+status.execution_id).executionId===status.execution_id,'execution lost');
""")


def test_source_switch_and_hidden_response_are_canceled_without_stale_publication():
    run("""
const {ExecutionPoller}=await import(process.argv[1]);let visible=true;const pending=[],published=[];
const poller=new ExecutionPoller({read:(id,signal)=>new Promise(resolve=>pending.push({id,signal,resolve})),onData:data=>published.push(data),onError:()=>{},visible:()=>visible,interval:50000});
poller.select('first');await new Promise(r=>setTimeout(r,0));poller.select('second');await new Promise(r=>setTimeout(r,0));
assert(pending[0].signal.aborted,'old source not canceled');pending[0].resolve('old');pending[1].resolve('new');await new Promise(r=>setTimeout(r,0));assert(published.join()==='new','old source published');
poller.refresh();await new Promise(r=>setTimeout(r,0));visible=false;poller.visibilityChanged();pending[2].resolve('hidden');await new Promise(r=>setTimeout(r,0));assert(published.join()==='new','hidden response published');poller.dispose();
""")


def test_life_session_and_frame_page_are_admitted_together_without_partial_publication():
    run("""
const {acceptExecutionSnapshot,validateLifeSession}=await import(process.argv[1]);
const session={session_id:'d'.repeat(32),revision:1,control_revision:1,state:'streaming',binding:{execution_id:status.execution_id,source_snapshot_hash:status.source_snapshot_hash,source_generation:status.source_generation,selection:status.selection,engine_contract_id:status.engine_contract_id},last_frame:2,last_admitted:2,last_forwarded:2,authorship:'engine',evidence_class:'MODELED',hardware_present:false,independent_physical_validation:false,delivery_status:'acknowledged'};
for(const mutate of [x=>x.binding.selection={...selection,twin_id:'wrong'},x=>x.binding.engine_contract_id='cardiac-continuous-v1',x=>x.last_admitted=-1,x=>x.hardware_present=true,x=>x.evidence_class='OBSERVED',x=>x.authorship='technical_fixture',x=>x.last_forwarded=3]){
const view=new ExecutionViewState(status.execution_id);view.acceptPage(page([frame(1)]));const before=JSON.stringify(view.series),bad=structuredClone(session);mutate(bad);
let failed=false;try{acceptExecutionSnapshot(view,{page:page([frame(2)]),life:bad,sessionId:session.session_id})}catch{failed=true}
assert(failed&&view.cursor===1&&JSON.stringify(view.series)===before,'mismatched LIFE context partially published');assert(view.stale&&!view.following,'mismatch not stale');}
const view=new ExecutionViewState(status.execution_id);const accepted=acceptExecutionSnapshot(view,{page:page([frame(1),frame(2)]),life:session,sessionId:session.session_id});assert(view.cursor===2&&accepted.session_id===session.session_id,'matching snapshot rejected');
session.binding.selection.twin_id='altered';assert(accepted.binding.selection.twin_id==='twin-fixture','session not immutable');
let failed=false;try{validateLifeSession({...accepted,revision:0},status,accepted.session_id,accepted)}catch{failed=true}assert(failed,'session revision rollback admitted');
""")


def test_execution_biology_mount_excludes_active_and_saved_run_fallbacks():
    source=(ROOT/'livemorebio/aegle/console/biology.html').read_text(encoding="utf-8")
    assert 'id="execution-workspace"' in source
    assert "has('execution_id')" in source
    patch=(ROOT/'livemorebio/aegle/console/patch.html').read_text(encoding="utf-8")
    assert 'id="continuous-execution"' in patch and 'id="recorded-patch-workspace"' in patch
    assert 'continuous_execution.js' in patch


def test_pending_life_ack_is_allowed_without_relaxing_source_and_enum_guards():
    run("""
const {validateLifeSession}=await import(process.argv[1]);
const life={session_id:'d'.repeat(32),revision:7,control_revision:2,state:'streaming',binding:{execution_id:status.execution_id,source_snapshot_hash:status.source_snapshot_hash,source_generation:status.source_generation,selection:status.selection,engine_contract_id:status.engine_contract_id},last_frame:1,last_admitted:2,last_forwarded:1,authorship:'engine',evidence_class:'MODELED',hardware_present:false,independent_physical_validation:false,delivery_status:'pending'};
const accepted=validateLifeSession(life,status,life.session_id);assert(accepted.delivery_status==='pending'&&accepted.last_forwarded===1,'pending receipt rejected or fabricated acknowledgment');
for(const bad of [{...life,delivery_status:'delivered'},{...life,hardware_present:true},{...life,binding:{...life.binding,source_snapshot_hash:'e'.repeat(64)}}]){let rejected=false;try{validateLifeSession(bad,status,life.session_id)}catch{rejected=true}assert(rejected,'integrity guard weakened');}
""")


def test_mounted_control_cancels_pre_control_read_and_preserves_running_revision():
    run("""
const {mountContinuousExecution}=await import(new URL('./continuous_execution.js',process.argv[1]));
const originalTimer=setTimeout,deadlines=[];globalThis.setTimeout=(fn,ms,...args)=>{deadlines.push(ms);return originalTimer(fn,ms,...args)};
const nodes=new Map(),engines=['start','pause','resume','stop'].map(action=>element('[engine-'+action+']',{engineAction:action})),lifeButtons=['pause','resume','stop'].map(action=>element('[life-'+action+']',{lifeAction:action}));
function element(key,dataset={}){if(!nodes.has(key))nodes.set(key,{value:key==='[data-engine]'?'cardiac-continuous-v1':'',handlers:{},dataset,classList:{toggle(){}},setAttribute(){},replaceChildren(){},addEventListener(name,handler){this.handlers[name]=handler},textContent:'',innerHTML:''});return nodes.get(key)}
const host={innerHTML:'',classList:{toggle(){}},setAttribute(){},querySelector:element,querySelectorAll:key=>key==='[data-engine-action]'?engines:key==='[data-life-action]'?lifeButtons:[]};
const listeners={};globalThis.document={hidden:false,addEventListener:(key,fn)=>listeners[key]=fn,removeEventListener(){}};globalThis.window={addEventListener(){}};globalThis.location={search:'?execution_id='+status.execution_id};
const prepared={...status,engine_contract_id:'cardiac-continuous-v1',native_axis:{unit:'ms',maximum:1800000},revision:1,native_time:0,latest_frame:0,state:'prepared',authorship:'uninitialized',evidence_class:'NOT_EXECUTED'};
const running={...prepared,revision:2,control_revision:2,state:'running',authorship:'engine',evidence_class:'MODELED'};let reads=0,resolveOld,oldSignal,started=false;
const response=value=>({ok:true,json:async()=>value});globalThis.fetch=async(path,options)=>{if(options.method==='POST'){const body=JSON.parse(options.body);assert(body.expected_control_revision===1&&!('expected_revision' in body)&&body.expected_source_generation===prepared.source_generation,'producer did not use its displayed lifecycle/source guard');started=true;return response(running)}reads++;if(reads===2){oldSignal=options.signal;return new Promise(resolve=>{resolveOld=()=>resolve(response(page([],prepared)))})}return response(page([],started?running:prepared))};
const tick=()=>new Promise(resolve=>setTimeout(resolve,0)),view=mountContinuousExecution(host);await tick();element('[data-read]').handlers.click();await tick();engines[0].handlers.click();await tick();
assert(oldSignal.aborted,'control did not cancel older status read');assert(deadlines.includes(60000),'native initialization timeout too short');assert(element('[data-engine-state]').textContent==='running'&&element('[data-context]').textContent.includes('Engine control revision 2 · record revision 2'),'start response and exact guards not shown');assert(element('[data-setup]').open===false,'successful start did not collapse preparation');resolveOld();await tick();assert(!element('[data-engine-state]').textContent.includes('stale'),'pre-control read poisoned current revision');
document.hidden=true;listeners.visibilitychange();assert(element('[data-engine-state]').textContent.includes('stale'),'hidden view retained live claim');view.dispose();
""")


def test_original_three_clock_timestamps_and_age_do_not_become_new_samples():
    run("""
const {executionSampleTimes}=await import(process.argv[1]);
const native={generated_at:'2026-09-08T12:00:00+00:00'},session={last_generated_at:'2026-09-08T12:00:00+00:00',last_captured_at:'2026-09-08T12:00:00.100+00:00',last_acknowledged_at:'2026-09-08T12:00:00.200+00:00'};
const first=executionSampleTimes(native,session,Date.parse('2026-09-08T12:00:01Z')),later=executionSampleTimes(native,session,Date.parse('2026-09-08T12:00:04Z'));
assert(first.age_seconds===1&&later.age_seconds===4,'age failed to advance');assert(first.generated_at===later.generated_at&&later.generated_at===native.generated_at,'polling re-timestamped sample');assert(later.captured_at===session.last_captured_at&&later.acknowledged_at===session.last_acknowledged_at,'three clocks lost');assert(executionSampleTimes(null,null).age_seconds===null,'missing timestamp invented');assert(executionSampleTimes(native,null,0).age_seconds===null,'future source clock clamped to fresh');
""")


def test_control_revision_is_strict_and_monotonic_independently_of_record_revision():
    run("""
const {validateLifeSession}=await import(process.argv[1]);
const current={...status,control_revision:2};
const life={session_id:'d'.repeat(32),revision:10,control_revision:2,state:'streaming',binding:{execution_id:status.execution_id,source_snapshot_hash:status.source_snapshot_hash,source_generation:status.source_generation,selection:status.selection,engine_contract_id:status.engine_contract_id},last_frame:2,last_admitted:2,last_forwarded:2,authorship:'engine',evidence_class:'MODELED',hardware_present:false,independent_physical_validation:false,delivery_status:'acknowledged'};
for(const value of [undefined,null,true,false,0,-1,1.5,'1',4]){const view=new ExecutionViewState(status.execution_id);let failed=false;try{view.acceptStatus({...current,control_revision:value})}catch{failed=true}assert(failed,'malformed control revision admitted');}
for(const value of [undefined,null,true,false,0,-1,1.5,'1',11]){let failed=false;try{validateLifeSession({...life,control_revision:value},current,life.session_id)}catch{failed=true}assert(failed,'malformed LIFE control revision admitted');}
const view=new ExecutionViewState(status.execution_id);view.acceptStatus(current);view.acceptStatus({...current,revision:100});assert(view.status.control_revision===2,'sample advance changed control intent');
let failed=false;try{view.acceptStatus({...current,revision:101,control_revision:1})}catch{failed=true}assert(failed,'control revision rollback admitted');
failed=false;try{validateLifeSession({...life,revision:100,control_revision:1},current,life.session_id,life)}catch{failed=true}assert(failed,'LIFE control revision rollback admitted');
""")


def test_mounted_pause_uses_displayed_control_revision_once_despite_new_telemetry():
    run("""
const {mountContinuousExecution}=await import(new URL('./continuous_execution.js',process.argv[1]));
for(const conflict of [false,true]){
const nodes=new Map(),engines=['start','pause','resume','stop'].map(action=>element('[engine-'+action+']',{engineAction:action})),lifeButtons=['pause','resume','stop'].map(action=>element('[life-'+action+']',{lifeAction:action}));
function element(key,dataset={}){if(!nodes.has(key))nodes.set(key,{value:key==='[data-engine]'?'metabolic-continuous-v1':'',handlers:{},dataset,classList:{toggle(){}},setAttribute(){},replaceChildren(){},addEventListener(name,handler){this.handlers[name]=handler},textContent:'',innerHTML:''});return nodes.get(key)}
const host={innerHTML:'',classList:{toggle(){}},setAttribute(){},querySelector:element,querySelectorAll:key=>key==='[data-engine-action]'?engines:key==='[data-life-action]'?lifeButtons:[]};
globalThis.document={hidden:false,addEventListener(){},removeEventListener(){}};globalThis.window={addEventListener(){}};
const sessionId='d'.repeat(32);globalThis.location={search:'?execution_id='+status.execution_id+'&session_id='+sessionId};
let engine={...status,revision:10,control_revision:2,latest_frame:0,native_time:0};
let life={session_id:sessionId,revision:21,control_revision:3,state:'streaming',binding:{execution_id:status.execution_id,source_snapshot_hash:status.source_snapshot_hash,source_generation:status.source_generation,selection:status.selection,engine_contract_id:status.engine_contract_id},last_frame:0,last_admitted:0,last_forwarded:0,authorship:'engine',evidence_class:'MODELED',hardware_present:false,independent_physical_validation:false,delivery_status:'not_delivered'};
const requests=[],response=(value,ok=true)=>({ok,status:ok?200:409,json:async()=>structuredClone(value)});
globalThis.fetch=async(path,options)=>{if(options.method==='POST'){const body=JSON.parse(options.body);requests.push({path,body});if(conflict)return response({code:'EXECUTION_CONFLICT',error:'Lifecycle changed.'},false);assert(Object.keys(body).join()==='expected_control_revision'&&body.expected_control_revision===3,'cached record revision used for LIFE intent');life={...life,revision:life.revision+1,control_revision:4,state:'paused'};engine={...engine,revision:engine.revision+1,control_revision:3,state:'paused'};return response(life)}return response(path.includes('/frames?')?page([],engine):life)};
const tick=()=>new Promise(resolve=>setTimeout(resolve,0)),mounted=mountContinuousExecution(host);await tick();await tick();
assert(element('[data-context]').textContent.includes('Engine control revision 2 · record revision 10'),'producer guards not distinguished');
assert(element('[data-context]').textContent.includes('LIFE control revision 3 · record revision 21'),'LIFE guards not distinguished');
life={...life,revision:29};engine={...engine,revision:12};lifeButtons[0].handlers.click();await tick();await tick();
assert(requests.length===1,'control conflict silently retried');assert(requests[0].body.expected_control_revision===3&&!('expected_revision' in requests[0].body),'displayed control guard changed');
if(conflict){assert(element('[data-message]').textContent.includes('No automatic mutation retry'),'uncertain conflict hidden');assert(element('[data-engine-state]').textContent.includes('stale'),'conflict stayed live');}else assert(element('[data-life-state]').textContent.startsWith('paused'),'pause rejected on telemetry-only progress');
mounted.dispose();}
""")
