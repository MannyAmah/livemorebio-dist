"""Descriptive lifecycle fixtures are authored; no public participant rows."""
from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import sqlite3
from concurrent.futures import ThreadPoolExecutor

import pytest

from livemorebio.aegle import reference_cohorts as cohorts
from livemorebio.aegle import population_records as records
from livemorebio.tests.test_population_records import tables


def draft():
    return {'name':'TECHNICAL cohort fixture','indication':'unspecified',
            'source_id':cohorts.SOURCE_ID,'definition_id':records.SCREENED,
            'size':3,'seed':71,'require_nonpregnant':False,'accepted_use':'statistical_research'}


@pytest.fixture
def service(tmp_path,monkeypatch):
    monkeypatch.setattr(cohorts,'normalization_version',lambda:'technical-normalization-v1')
    monkeypatch.setattr(cohorts.ReferenceCohortService,'_load_population',
                        lambda self:records._normalize_tables(tables(),fingerprint_key=self.fingerprint_key))
    return cohorts.ReferenceCohortService(tmp_path/'registry'/'subjects.sqlite3',key=b'k'*32,source_dir=tmp_path/'source')


def create(service,payload=None,key='technical-create-key'):
    payload=payload or draft()
    preview=service.preview(payload)
    return service.create({'draft':payload,'preview_token':preview['preview_token']},idempotency_key=key)


def count(service,table):
    with sqlite3.connect(service.path) as con:
        return con.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]


def test_preview_is_descriptive_suppressed_and_does_not_create_members_or_twins(service):
    before=count(service,'records')
    p=service.preview(draft())
    assert p['executable'] is False and p['model_binding'] is None
    assert p['source_manifest_sha256'] and p['construction_sha256']
    assert p['summary_suppressed'] is True and p['selected_summary'] is None
    assert 'members' not in p and 'fingerprint' not in json.dumps(p)
    assert count(service,'records')==before and count(service,'public_reference_members')==0
    assert count(service,'public_reference_access')==1


def test_atomic_frozen_members_are_encrypted_restart_readable_and_no_model(service):
    result=create(service)
    assert result['source_class']=='PUBLIC_REFERENCE' and result['lifecycle']=='FROZEN'
    assert result['executable'] is False and result['model_binding'] is None
    assert result['members_included'] is False and 'member_manifest' not in result
    assert result['idempotent_replay'] is False and count(service,'public_reference_members')==3
    assert count(service,'subject_identifiers')==0 and count(service,'physical_device_bindings')==0
    assert b'TECHNICAL cohort fixture' not in service.path.read_bytes()
    recovered=cohorts.ReferenceCohortService(service.path,key=b'k'*32,source_dir=service.source_dir)
    page=recovered.page_members(result['cohort_id'],limit=2)
    assert len(page['members'])==2 and page['pagination']['total']==3 and page['pagination']['has_more']
    first=page['members'][0]
    assert first['reference']['measurements']['weight_kg']['unit']=='kg'
    assert first['reference']['model_binding_available'] is False
    assert 'model_parameters' not in first['reference'] and 'SEQN' not in json.dumps(first)
    detail=recovered.get_member(result['cohort_id'],first['member_id'])
    assert detail==first


def test_preview_change_expiry_and_cross_store_are_rejected(service,tmp_path,monkeypatch):
    p=service.preview(draft());body={'draft':draft(),'preview_token':p['preview_token']}
    body['draft']['seed']=72
    with pytest.raises(cohorts.ReferenceCohortError) as e:service.create(body,idempotency_key='x')
    assert e.value.code=='REFERENCE_PREVIEW_CHANGED'
    other=cohorts.ReferenceCohortService(tmp_path/'other'/'subjects.sqlite3',key=b'k'*32,source_dir=service.source_dir)
    body['draft']=draft()
    with pytest.raises(cohorts.ReferenceCohortError):other.create(body,idempotency_key='x')
    monkeypatch.setattr(cohorts.time,'time',lambda:p['expires_at_unix']+1)
    with pytest.raises(cohorts.ReferenceCohortError) as e:service.create(body,idempotency_key='x')
    assert e.value.code=='REFERENCE_PREVIEW_EXPIRED'
    assert count(service,'records')==0


def test_idempotent_replay_survives_expiry_and_source_unavailability(service,monkeypatch):
    p=service.preview(draft());body={'draft':draft(),'preview_token':p['preview_token']}
    a=service.create(body,idempotency_key='retry')
    monkeypatch.setattr(cohorts.time,'time',lambda:p['expires_at_unix']+1)
    monkeypatch.setattr(service,'_load_population',lambda:pytest.fail('replay must not reload source'))
    b=service.create(body,idempotency_key='retry')
    assert a['cohort_id']==b['cohort_id'] and b['idempotent_replay'] is True
    assert count(service,'records')==1 and count(service,'public_reference_members')==3


def test_concurrent_same_key_creates_one_record_and_conflicting_request_rejects(service):
    p=service.preview(draft());body={'draft':draft(),'preview_token':p['preview_token']}
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(lambda _:service.create(body,idempotency_key='same-key'),range(2)))
    assert len({r['cohort_id'] for r in results})==1 and count(service,'records')==1
    changed=draft();changed['name']='TECHNICAL different label'
    p2=service.preview(changed)
    with pytest.raises(cohorts.ReferenceCohortError) as e:
        service.create({'draft':changed,'preview_token':p2['preview_token']},idempotency_key='same-key')
    assert e.value.code=='IDEMPOTENCY_CONFLICT'


def test_audit_failure_rolls_back_creation_and_blocks_reads_preview(service,monkeypatch):
    p=service.preview(draft())
    def fail(*args,**kwargs):raise OSError('private fixture path and values must not leak')
    with monkeypatch.context() as m:
        m.setattr(service,'_audit',fail)
        with pytest.raises(cohorts.ReferenceCohortError) as e:
            service.create({'draft':draft(),'preview_token':p['preview_token']},idempotency_key='audit-fail')
        assert e.value.status==503 and 'private fixture' not in str(e.value)
        assert count(service,'records')==0 and count(service,'public_reference_members')==0
        with pytest.raises(cohorts.ReferenceCohortError):service.preview(draft())
    created=create(service)
    with monkeypatch.context() as m:
        m.setattr(service,'_audit',fail)
        with pytest.raises(cohorts.ReferenceCohortError):service.get_summary(created['cohort_id'])
        with pytest.raises(cohorts.ReferenceCohortError):service.page_members(created['cohort_id'])


def test_member_insert_failure_rolls_back_all_members(service,monkeypatch):
    p=service.preview(draft());original=service._write_member
    calls=[]
    def fail_after_first(*args,**kwargs):
        calls.append(True)
        if len(calls)>1:raise sqlite3.OperationalError('technical failure')
        return original(*args,**kwargs)
    monkeypatch.setattr(service,'_write_member',fail_after_first)
    with pytest.raises(cohorts.ReferenceCohortError):
        service.create({'draft':draft(),'preview_token':p['preview_token']},idempotency_key='insert-fail')
    assert count(service,'records')==0 and count(service,'public_reference_members')==0


def test_member_cursor_binding_and_corruption_fail_closed(service):
    a=create(service,key='one');b=create(service,key='two')
    page=service.page_members(a['cohort_id'],limit=2);cursor=page['pagination']['next_cursor']
    rest=service.page_members(a['cohort_id'],limit=2,cursor=cursor)
    assert len(rest['members'])==1 and rest['pagination']['has_more'] is False
    for target,limit,token in ((b['cohort_id'],2,cursor),(a['cohort_id'],1,cursor),(a['cohort_id'],2,cursor[:-2]+'xx')):
        with pytest.raises(cohorts.ReferenceCohortError):service.page_members(target,limit=limit,cursor=token)
    with sqlite3.connect(service.path) as con:
        con.execute("UPDATE public_reference_members SET ciphertext=? WHERE cohort_id=? AND ordinal=0",(b'bad',a['cohort_id']))
    with pytest.raises(cohorts.ReferenceCohortError) as e:service.page_members(a['cohort_id'])
    assert e.value.status==503


def test_actual_member_envelopes_cannot_become_executable_by_boolean_override(service):
    from livemorebio.reference_cohort_contract import ensure_cohort_executable, ReferenceModelBindingRequired
    saved=create(service)
    member=service.page_members(saved['cohort_id'])['members'][0]
    member['executable']=True
    for forged in (member,{'source_class':'REFERENCE_GROUNDED_SYNTHETIC','members':[member]},
                   {'source_class':'REFERENCE_GROUNDED_SYNTHETIC','model_binding':None,'executable':True}):
        with pytest.raises(ReferenceModelBindingRequired):ensure_cohort_executable(forged)
    assert member['schema']=='livemore.frozen-public-reference-member.v1'


@pytest.mark.parametrize('field',['request_hash','idempotency_key'])
def test_plaintext_retry_indexes_cannot_override_encrypted_request_identity(service,field):
    a=create(service,key='original-key')
    other=draft();other['name']='TECHNICAL other request'
    p=service.preview(other)
    if field=='request_hash':
        request_hash=cohorts._digest({'draft':other,**{k:p[k] for k in cohorts._BINDINGS}})
        with sqlite3.connect(service.path) as con:
            con.execute('UPDATE records SET request_hash=? WHERE record_id=?',(request_hash,a['cohort_id']))
        body={'draft':other,'preview_token':p['preview_token']};key='original-key'
    else:
        b=create(service,key='other-key')
        with sqlite3.connect(service.path) as con:
            index=con.execute('SELECT idempotency_key FROM records WHERE record_id=?',(b['cohort_id'],)).fetchone()[0]
            con.execute('UPDATE records SET idempotency_key=NULL WHERE record_id=?',(b['cohort_id'],))
            con.execute('UPDATE records SET idempotency_key=? WHERE record_id=?',(index,a['cohort_id']))
        p=service.preview(draft());body={'draft':draft(),'preview_token':p['preview_token']};key='other-key'
    with pytest.raises(cohorts.ReferenceCohortError) as error:service.create(body,idempotency_key=key)
    assert error.value.status==503


@pytest.mark.parametrize('change',[
    {'size':True},{'size':1.5},{'size':1001},{'seed':False},{'seed':-1},
    {'require_nonpregnant':'false'},{'source_id':'unknown'},{'definition_id':'invented'},
    {'accepted_use':'clinical'},{'name':3},{'unexpected':'field'},
    {'definition_id':[]},{'source_id':{}},{'accepted_use':[]},
])
def test_draft_strictness_before_selection(service,change,monkeypatch):
    body=draft();body.update(change)
    monkeypatch.setattr(service,'_load_population',lambda:pytest.fail('invalid draft must not read source'))
    with pytest.raises(cohorts.ReferenceCohortError) as error:service.preview(body)
    assert error.value.status==422


@pytest.mark.parametrize('target', ['directory','database','wal','shm','symlink','hardlink'])
def test_unsafe_existing_paths_rejected_before_inherited_constructor(tmp_path,monkeypatch,target):
    from livemorebio.aegle.subjects import SubjectRegistry
    root=tmp_path/'private';root.mkdir(mode=0o700);db=root/'subjects.sqlite3'
    if target=='directory':root.chmod(0o755)
    elif target=='symlink':db.symlink_to(tmp_path/'unrelated')
    elif target=='hardlink':
        donor=root/'donor';donor.touch(mode=0o600);os.link(donor,db)
    else:
        path=db if target=='database' else Path(str(db)+'-'+target)
        path.touch(mode=0o644);path.chmod(0o644)
    monkeypatch.setattr(SubjectRegistry,'__init__',lambda *a,**k:pytest.fail('unsafe path opened before guard'))
    with pytest.raises(cohorts.ReferenceCohortError) as e:
        cohorts.ReferenceCohortService(db,key=b'k'*32,source_dir=tmp_path/'source')
    assert e.value.status==503
