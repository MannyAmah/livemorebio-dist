"""L0-R15 (walk finding L0W-1): every clinical-note intake path fails closed.

The release says PHI-like input fails closed unless local de-identification is
operational. This release has none, so every path that accepts a free-text
clinical note must call one gate, ``clinical_note_gate``, before it reads,
parses, stores, logs or echoes the note, and refuse with a typed code and a
reason in words.

The structural tests read the shipped source: any intake path that reaches the
clinical extractor (``ClinicalExtractor``, ``OpenMedNER``,
``to_synthetic_human``) without the gate fails them, wherever it is added. The
behavioural tests drive every path this part found: Aegle ``/api/ingest_note``
(the console's note intake posts there), LIFE ``POST /human`` with a note, the
SDK ``patient(note=...)`` in both modes and its preview transport, the shell
and pipeline ``patient note`` command, and the extractor's own entry points.

Every note here is SYNTHETIC: an invented name and invented numbers, with the
word SYNTHETIC in it. No test writes a note to a log; the tests check that the
product does not either. Test ids, assertion messages and failure reports here
never carry note text: every check is reduced to a boolean with a fixed message
first, so a failing run (``--show-capture=no``) logs no note.
"""
from __future__ import annotations

import ast
import inspect
import json
import logging
from pathlib import Path
import sys
import textwrap
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[2]
CODE = "CLINICAL_NOTE_NOT_ACCEPTED"
REASON = "this release does not accept clinical notes; local de-identification is not operational"
NOTE = ("SYNTHETIC TEST NOTE, not a person. Patient: Qorvex Y. Zyntharo. MRN: SYN-0000000. "
        "DOB: 01/01/1900. SSN: 000-00-0000. Phone: (555) 010-0100. 58 yo M with type 2 diabetes "
        "mellitus (T2DM) on metformin, TCF7L2 variant, history of coronary artery disease.")
MARKERS = ("Qorvex", "Zyntharo", "SYN-0000000", "000-00-0000", "010-0100", "TCF7L2 variant")
GATE = "clinical_note_gate"
EXTRACTOR = frozenset({"ClinicalExtractor", "OpenMedNER", "to_synthetic_human"})
NOTE_KEYS = frozenset({"note", "text"})


def _no_note_text(*texts: object, where: str = "an output") -> None:
    escaped = any(marker in str(text) for text in texts for marker in MARKERS)
    assert not escaped, f"note text escaped into {where}"


def assert_note_refused(call) -> None:
    """Shared by the tests that L0-R15 restated: ``call`` must raise the typed refusal."""
    with pytest.raises(Exception) as caught:
        call()
    _assert_refusal(caught.value)


def _assert_refusal(error: BaseException) -> None:
    typed = getattr(error, "code", None) == CODE
    assert typed, f"not the typed refusal: {type(error).__name__}"
    worded = REASON in str(error)
    assert worded, "the refusal does not give its reason in words"
    _no_note_text(str(error), repr(error), error.args, where="the refusal")


# ---------------------------------------------------------------- structure

def _is_gate_call(node: ast.AST) -> bool:
    return isinstance(node, ast.Call) and (
        isinstance(node.func, ast.Name) and node.func.id == GATE
        or isinstance(node.func, ast.Attribute) and node.func.attr == GATE)


def _establishes_gate(statement: ast.stmt) -> bool:
    """A bare gate call, or a try whose body starts with it and whose handlers all leave."""
    if isinstance(statement, ast.Expr) and _is_gate_call(statement.value):
        return True
    if (isinstance(statement, ast.Try) and statement.body and isinstance(statement.body[0], ast.Expr)
            and _is_gate_call(statement.body[0].value)):
        return all(handler.body and isinstance(handler.body[-1], (ast.Return, ast.Raise))
                   for handler in statement.handlers)
    return False


def _reaches(node: ast.AST, *, in_function: bool, note_reads: bool) -> list[tuple[int, str]]:
    """What in ``node`` reaches the extractor (or, in a route, reads the note's value)."""
    found = []
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and child.id in EXTRACTOR:
            found.append((child.lineno, child.id))
        elif isinstance(child, ast.Attribute) and child.attr in EXTRACTOR:
            found.append((child.lineno, child.attr))
        elif in_function and isinstance(child, ast.ImportFrom) and (
                any(alias.name in EXTRACTOR for alias in child.names)
                or (child.module or "").endswith("life_system.extract")
                or child.level and child.module == "extract"):
            found.append((child.lineno, "import of the clinical extractor"))
        elif in_function and isinstance(child, ast.Import) and any(
                alias.name.endswith("life_system.extract") for alias in child.names):
            found.append((child.lineno, "import of the clinical extractor"))
        elif note_reads and isinstance(child, ast.Subscript) and isinstance(child.slice, ast.Constant) \
                and child.slice.value in NOTE_KEYS:
            found.append((child.lineno, f"read of [{child.slice.value!r}]"))
        elif note_reads and isinstance(child, ast.Call) and isinstance(child.func, ast.Attribute) \
                and child.func.attr == "get" and child.args and isinstance(child.args[0], ast.Constant) \
                and child.args[0].value in NOTE_KEYS:
            found.append((child.lineno, f"read of .get({child.args[0].value!r})"))
    return found


def _ungated(statements: list[ast.stmt], *, note_reads: bool = False, in_function: bool = False,
             gated: bool = False) -> tuple[list[tuple[int, str]], list[tuple[int, str]]]:
    """(ungated, gated) references: a reference counts as gated only after the gate, in its block or an outer one."""
    ungated: list[tuple[int, str]] = []
    covered: list[tuple[int, str]] = []

    def block(statements: list[ast.stmt], gated: bool, in_function: bool) -> None:
        for statement in statements:
            visit(statement, gated, in_function)
            gated = gated or _establishes_gate(statement)

    def check(node: ast.AST, gated: bool, in_function: bool) -> None:
        found = _reaches(node, in_function=in_function, note_reads=note_reads)
        (covered if gated else ungated).extend(found)

    def visit(statement: ast.stmt, gated: bool, in_function: bool) -> None:
        if isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for node in [*statement.decorator_list, *statement.args.defaults,
                         *[d for d in statement.args.kw_defaults if d is not None]]:
                check(node, gated, in_function)
            # A nested function inherits what was established where it is defined.
            block(statement.body, gated, True)
            return
        if isinstance(statement, ast.ClassDef):
            for node in statement.decorator_list:
                check(node, gated, in_function)
            block(statement.body, gated, in_function)
            return
        if isinstance(statement, (ast.Import, ast.ImportFrom)) and not in_function:
            return
        for field, value in ast.iter_fields(statement):
            if isinstance(value, list) and value and all(isinstance(item, ast.stmt) for item in value):
                block(value, gated, in_function)
            elif field == "handlers":
                for handler in value:
                    if handler.type is not None:
                        check(handler.type, gated, in_function)
                    block(handler.body, gated, in_function)
            elif field == "cases":
                for case in value:
                    check(case.pattern, gated, in_function)
                    if case.guard is not None:
                        check(case.guard, gated, in_function)
                    block(case.body, gated, in_function)
            elif isinstance(value, list):
                for item in value:
                    if isinstance(item, ast.AST):
                        check(item, gated, in_function)
            elif isinstance(value, ast.AST):
                check(value, gated, in_function)

    block(statements, gated, in_function)
    return ungated, covered


def _shipped_python() -> list[Path]:
    """Every Python file the product, its tools, demos and notebooks carry, except tests and the extractor."""
    files = [*ROOT.glob("livemorebio/**/*.py"), *ROOT.glob("tools/**/*.py"),
             *ROOT.glob("trials/*.py"), *ROOT.glob("notebooks/*.py")]
    extractor = ROOT / "livemorebio/life_system/extract.py"
    return sorted(path for path in files
                  if "tests" not in path.relative_to(ROOT).parts[:2] and path != extractor
                  and "__pycache__" not in path.parts)


def test_no_intake_path_reaches_the_clinical_extractor_without_the_gate():
    """Static: every reference to the extractor in shipped code comes after the gate."""
    violations, gated_files = [], set()
    for path in _shipped_python():
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        ungated, covered = _ungated(tree.body)
        relative = path.relative_to(ROOT).as_posix()
        violations += [f"{relative}:{line}: {what} reached without {GATE}()" for line, what in ungated]
        if covered:
            gated_files.add(relative)
    # A notebook cell cannot call the gate first, so no shipped notebook, nor the
    # workspace notebook the product writes, may name the extractor or a note path.
    for path in sorted([*ROOT.glob("notebooks/*.ipynb"), *ROOT.glob("livemorebio/**/*.ipynb")]):
        cells = json.loads(path.read_text(encoding="utf-8")).get("cells", [])
        source = "\n".join("".join(cell.get("source", [])) for cell in cells if cell.get("cell_type") == "code")
        violations += [f"{path.relative_to(ROOT).as_posix()}: names {name}"
                       for name in sorted(EXTRACTOR | {"ingest_note", "note="}) if name in source]
    generated = (ROOT / "livemorebio/notebook.py").read_text(encoding="utf-8")
    violations += [f"livemorebio/notebook.py: the workspace notebook names {name}"
                   for name in sorted(EXTRACTOR | {"ingest_note", "note="}) if name in generated]
    assert not violations, "intake paths reach the clinical extractor without the gate:\n" + "\n".join(violations)
    # The scan is not vacuous: the product's intake paths keep their extractor behind the gate.
    assert {"livemorebio/aegle/server.py", "livemorebio/life_system/service.py",
            "livemorebio/sdk.py"} <= gated_files, gated_files


def test_the_extractor_entry_points_call_the_gate_first():
    """Even a direct library call of the extractor refuses before it reads its text."""
    path = ROOT / "livemorebio/life_system/extract.py"
    tree = ast.parse(path.read_text(encoding="utf-8"))
    classes = {node.name: node for node in tree.body if isinstance(node, ast.ClassDef)}
    entry_points = {("ClinicalExtractor", "extract"), ("ClinicalExtractor", "to_synthetic_human"),
                    ("OpenMedNER", "extract")}
    found = set()
    for class_name in ("ClinicalExtractor", "OpenMedNER"):
        for method in classes[class_name].body:
            if not isinstance(method, ast.FunctionDef):
                continue
            arguments = [argument.arg for argument in method.args.args]
            if method.name.startswith("_") or "text" not in arguments:
                continue
            found.add((class_name, method.name))
            body = method.body[1:] if (method.body and isinstance(method.body[0], ast.Expr)
                                       and isinstance(method.body[0].value, ast.Constant)) else method.body
            assert body and isinstance(body[0], ast.Expr) and _is_gate_call(body[0].value), \
                f"{class_name}.{method.name} reads text before {GATE}()"
    assert found == entry_points, found


def _apps():
    from livemorebio.aegle import server
    from livemorebio.cendos import service as cendos
    from livemorebio.life_system import service as life
    return {"Aegle": server.app, "LIFE": life.app, "Cendos": cendos.app}


def test_every_note_route_refuses_before_it_reads_the_note():
    """Every HTTP route that names, reads or extracts a note does so only behind the gate."""
    from fastapi.routing import APIRoute

    note_routes, violations = set(), []
    for service, app in _apps().items():
        for route in app.routes:
            if not isinstance(route, APIRoute):
                continue
            source = textwrap.dedent(inspect.getsource(route.endpoint))
            function = ast.parse(source).body[0]
            ungated, covered = _ungated(function.body, note_reads=True, in_function=True)
            if "note" in route.path or ungated or covered:
                note_routes.add((service, route.path))
            violations += [f"{service} {route.path}: {what} (line {line} of the handler) before {GATE}()"
                           for line, what in ungated]
            if "note" in route.path:
                first = function.body[1:] if (function.body and isinstance(function.body[0], ast.Expr)
                                              and isinstance(function.body[0].value, ast.Constant)) else function.body
                assert first and _establishes_gate(first[0]), \
                    f"{service} {route.path} does something before {GATE}()"
    assert not violations, "\n".join(violations)
    # A new note route is held to the same rules; this names every one the release has.
    assert note_routes == {("Aegle", "/api/ingest_note"), ("LIFE", "/human")}, note_routes


# ---------------------------------------------------------------- behaviour

@pytest.fixture
def aegle(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server
    from livemorebio.aegle.model_source import ModelSourceAuthority

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-note-gate-token")
    monkeypatch.setenv("LIVEMORE_SUBJECT_REGISTRY", str(tmp_path / "technical-note-gate.sqlite3"))
    monkeypatch.setattr(server, "_subject_registry_instance", None)
    monkeypatch.setattr(server, "_subject_registry_path", None)
    monkeypatch.setattr(server, "_execution_manager_instance", None)
    monkeypatch.setattr(server, "_model_source_authority", ModelSourceAuthority())
    monkeypatch.setattr(server, "_state", {"tw": None, "subject": None, "initialized": True})
    monkeypatch.setattr(server, "_workspace_actions", [])
    monkeypatch.setattr(server, "_snapshot_twin", lambda snapshot: None)
    return server, TestClient(server.app, raise_server_exceptions=False,
                              headers={"Authorization": "Bearer technical-note-gate-token"})


def _forbid_extractor(monkeypatch, *modules) -> list[str]:
    """Replace the extractor where paths find it; return a record of every attempt to build one."""
    from livemorebio.life_system import extract

    reached: list[str] = []

    class Reached:
        def __init__(self, *args, **kwargs):
            reached.append(type(self).__name__)
            raise AssertionError("an intake path reached the clinical extractor")

    for module in (extract, *modules):
        monkeypatch.setattr(module, "ClinicalExtractor", Reached, raising=False)
        monkeypatch.setattr(module, "OpenMedNER", Reached, raising=False)
    return reached


@pytest.mark.parametrize("body", [{"text": NOTE}, {"text": ""}, {}, {"text": NOTE, "extra": True}],
                         ids=["note", "empty-text", "empty-body", "note-and-extra"])
def test_aegle_note_route_refuses_before_reading_the_body(aegle, monkeypatch, caplog, body):
    from livemorebio.aegle import research_api

    server, client = aegle
    reads = []
    async def read(request):
        reads.append("body")
        raise RuntimeError("technical stand-in: the note body is never read")

    monkeypatch.setattr(research_api, "body", read)
    reached = _forbid_extractor(monkeypatch)
    before = (server._state["tw"], server._state.get("subject"), list(server._workspace_actions))
    caplog.set_level(logging.DEBUG)

    response = client.post("/api/ingest_note", json=body)

    body_read = bool(reads)
    assert not body_read, "the route read the note body"
    assert not reached, "the route reached the clinical extractor"
    status = response.status_code
    assert status == 422, f"status {status}"
    refused = response.json() == {"code": CODE, "error": REASON}
    assert refused, "not the typed refusal body"
    assert response.headers.get("Cache-Control") == "no-store"
    unchanged = (server._state["tw"], server._state.get("subject"), list(server._workspace_actions)) == before
    assert unchanged, "the selected state changed"
    _no_note_text(response.text, response.headers, where="the response")
    _no_note_text(caplog.text, where="the log")
    # Authentication is still decided first, by the service's own middleware.
    unauthenticated = client.post("/api/ingest_note", json=body, headers={"Authorization": ""})
    status = unauthenticated.status_code
    assert status == 401, f"status {status}"
    _no_note_text(unauthenticated.text, caplog.text, where="the unauthenticated answer or the log")


@pytest.fixture
def life(monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.life_system import service

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-note-gate-token")
    return service, TestClient(service.app, raise_server_exceptions=False,
                               headers={"Authorization": "Bearer technical-note-gate-token"})


@pytest.mark.parametrize("note", [NOTE, "", None, ["a list"]], ids=["note", "empty", "null", "list"])
def test_life_human_refuses_any_note_before_extraction(life, monkeypatch, caplog, note):
    service, client = life
    reached = _forbid_extractor(monkeypatch, service)
    caplog.set_level(logging.DEBUG)
    response = client.post("/human", json={"id": "SYNTHETIC-1", "note": note})
    assert not reached, "the route reached the clinical extractor"
    status = response.status_code
    assert status == 422, f"status {status}"
    refused = response.json() == {"code": CODE, "error": REASON}
    assert refused, "not the typed refusal body"
    assert response.headers.get("Cache-Control") == "no-store"
    _no_note_text(response.text, where="the response")
    _no_note_text(caplog.text, where="the log")
    # The technical route, explicit structured fields and no note, still builds a human
    # (round 1: its id is a technical identifier, not free text).
    structured = client.post("/human", json={"id": "LMB-47", "age": 47, "sex": "M",
                                             "conditions": ["Type 2 diabetes mellitus"], "genome": {}})
    status = structured.status_code
    assert status == 200, f"status {status}"
    assert structured.json()["human"]["id"] == "LMB-47" and "extracted" not in structured.json()


def test_sdk_inprocess_patient_refuses_a_note_and_keeps_its_twin(monkeypatch):
    from livemorebio import audit
    from livemorebio.sdk import Platform

    reached = _forbid_extractor(monkeypatch)
    platform = Platform(mode="inprocess")
    twin, before = platform._twin, platform._twin.state()
    audits = []
    monkeypatch.setattr(audit, "record", lambda *a, **k: audits.append((a, k)))
    with pytest.raises(Exception) as caught:
        platform.patient(note=NOTE)
    assert not reached, "the SDK reached the clinical extractor"
    _assert_refusal(caught.value)
    unchanged = platform._twin is twin and platform._twin.state() == before
    assert unchanged, "the in-process twin changed"
    audited = bool(audits)
    assert not audited, "a refused note was audited as a patient"
    with pytest.raises(Exception) as caught:
        platform.patient(note="")
    _assert_refusal(caught.value)


def test_sdk_attached_patient_refuses_a_note_before_any_request(monkeypatch):
    from livemorebio.sdk import Platform
    from .test_frozen_member_response_limits import ByteResponse, attached

    platform, calls = attached(monkeypatch, ByteResponse(b"{}"))
    with pytest.raises(Exception) as caught:
        platform.patient(note=NOTE)
    _assert_refusal(caught.value)
    sent = len(calls)
    assert sent == 0, f"{sent} request(s) carried the note"
    with pytest.raises(Exception) as caught:
        platform._research_preview_request("/api/ingest_note", {"text": NOTE})
    _assert_refusal(caught.value)
    sent = len(calls)
    assert sent == 0, f"{sent} request(s) carried the note"


class _Client:
    mode = "attach"

    def __init__(self, mode="attach"):
        self.calls = []

    def patient(self, **kwargs):
        self.calls.append(kwargs)
        raise AssertionError("a note line reached the SDK")

    def state(self):
        raise AssertionError("the pipeline continued after a refused note")


@pytest.mark.parametrize("line", [
    f'patient note "{NOTE}"', f'PATIENT NOTE "{NOTE}"', f'patient note={NOTE}',
    f'pa"tient" note "{NOTE}"', f'patient note "{NOTE}', f"patient note {NOTE}",
    f'patient "note {NOTE}"',
], ids=["quoted", "upper-case", "keyword", "quoted-verb", "unterminated", "bare", "quoted-word"])
def test_shell_refuses_every_note_line_before_parsing_it(line):
    from livemorebio.shell import run_command

    client, output = _Client(), []
    with pytest.raises(Exception) as caught:
        run_command(client, line, out=output.append)
    _assert_refusal(caught.value)
    reached, printed = len(client.calls), len(output)
    assert (reached, printed) == (0, 0), f"{reached} SDK call(s), {printed} printed line(s)"


def test_shell_repl_prints_the_refusal_and_keeps_patient_lines_out_of_history(monkeypatch, capsys):
    from livemorebio import registry, shell

    class Readline:
        __doc__ = "technical stand-in for readline"
        def __init__(self):
            self.added, self.auto = [], []
        def read_history_file(self, path): raise OSError("no technical history")
        def write_history_file(self, path): raise OSError("never written in this test")
        def set_history_length(self, length): pass
        def set_completer(self, completer): pass
        def parse_and_bind(self, binding): pass
        def get_line_buffer(self): return ""
        def clear_history(self): self.added.clear()
        def get_current_history_length(self): return len(self.added)
        def get_history_item(self, index): return self.added[index - 1]
        def set_auto_history(self, enabled): self.auto.append(enabled)
        def add_history(self, line): self.added.append(line)

    readline = Readline()
    monkeypatch.setitem(sys.modules, "readline", readline)
    monkeypatch.setattr("atexit.register", lambda function: None)
    monkeypatch.setattr(registry, "ensure_data_dir", lambda *a, **k: None)

    class Client(_Client):
        def state(self):
            return {"profile": "technical-reference"}

    monkeypatch.setattr(shell, "Platform", Client)
    commands = iter([f'patient note "{NOTE}"', "patient age=50 sex=F", "help", "exit"])
    monkeypatch.setattr("builtins.input", lambda prompt: next(commands))
    monkeypatch.setattr(Client, "patient", lambda self, **kwargs: {"profile": "technical"})
    shell.run_shell(mode="attach")
    output = capsys.readouterr().out
    shown = f"refused [{CODE}]: {REASON}" in output
    assert shown, "the REPL did not print the typed refusal"
    _no_note_text(output, where="the REPL output")
    # Nothing typed on a patient line reaches the shell's history file.
    assert readline.auto == [False], "readline still adds every typed line to the history file"
    remembered = readline.added == ["help", "exit"]
    _no_note_text(readline.added, where="the shell history")
    assert remembered, "the history holds more or less than the non-patient lines"


def test_pipeline_reports_the_refusal_without_echo_and_stops(tmp_path):
    from livemorebio.shell import run_pipeline

    path = tmp_path / "technical.pipeline"
    path.write_text(f'patient note "{NOTE}"\nshow state\n', encoding="utf-8")
    client, output = _Client(), []
    run_pipeline(client, str(path), out=output.append)
    _no_note_text(output, where="the pipeline output")
    exact = output == ["livemore› patient", f"  refused [{CODE}]: {REASON}"]
    assert exact, "the pipeline did not report the refusal and stop"
    reached = len(client.calls)
    assert reached == 0, f"{reached} SDK call(s)"


def test_extractor_entry_points_refuse_a_direct_library_call():
    from livemorebio.life_system.extract import ClinicalExtractor, OpenMedNER

    calls = []

    class FakeOpenMed:
        @staticmethod
        def deidentify(text, method):
            calls.append("deidentify")

        @staticmethod
        def analyze_text(text, model_name):
            calls.append("analyze_text")

    extractor = ClinicalExtractor()
    for call in (lambda: extractor.extract(NOTE), lambda: extractor.to_synthetic_human(NOTE),
                 lambda: OpenMedNER(kb=extractor.kb).extract(NOTE),
                 lambda: OpenMedNER(kb=extractor.kb).extract(NOTE, contains_phi=True),
                 lambda: OpenMedNER(kb=extractor.kb, client=FakeOpenMed).extract(NOTE, contains_phi=True),
                 lambda: OpenMedNER(kb=extractor.kb, client=FakeOpenMed).extract(NOTE)):
        with pytest.raises(Exception) as caught:
            call()
        _assert_refusal(caught.value)
    assert calls == [], "the OpenMed client was given the note"


def test_the_gate_has_no_setting_that_opens_it(monkeypatch):
    """No environment variable or argument turns the refusal off."""
    from livemorebio import clinical_note_gate as gate

    for name in ("LIVEMORE_ALLOW_CLINICAL_NOTES", "LIVEMORE_DEIDENTIFICATION", "OPENMED_DEIDENTIFY"):
        monkeypatch.setenv(name, "1")
    assert list(inspect.signature(gate.clinical_note_gate).parameters) == []
    with pytest.raises(gate.ClinicalNoteRefused) as caught:
        gate.clinical_note_gate()
    _assert_refusal(caught.value)
    assert caught.value.payload() == {"code": CODE, "error": REASON}
    tree = ast.parse(inspect.getsource(gate))
    reads_settings = [node for node in ast.walk(tree)
                      if isinstance(node, ast.Attribute) and node.attr in {"environ", "getenv", "environb"}
                      or isinstance(node, ast.Name) and node.id in {"environ", "getenv"}
                      or isinstance(node, (ast.Import, ast.ImportFrom))
                      and any(alias.name.split(".")[0] in {"os", "configparser", "json"} for alias in node.names)]
    assert not reads_settings, "the gate reads a setting"


# ---------------------------------------------------------------- console

CONSOLE = ROOT / "livemorebio/aegle/console"


def test_console_note_button_describes_loopback_and_the_unread_server_refusal():
    """L0-R18: the browser sends the note; only Aegle refuses its body unread."""
    html = (CONSOLE / "index.html").read_text(encoding="utf-8")
    button = html.split('onclick="ingestNote()"', 1)[1].split("</button>", 1)[0].lower()
    assert "loopback" in button, "the note button omits its loopback submission"
    assert "aegle" in button and "unread" in button, "the button does not identify the unread server refusal"
    assert "not kept, parsed or stored" not in button, "the button still claims the browser never parses the note"


def test_console_transport_keeps_the_typed_refusal_and_never_publishes_a_preview():
    from .test_legacy_preview_recovery_ui import check

    check(f"""
const CODE={json.dumps(CODE)},REASON={json.dumps(REASON)};
await assert.rejects(requestLegacyPreview('/api/ingest_note',{{body:{{text:'SYNTHETIC technical text'}},
  fetcher:async()=>http({{code:CODE,error:REASON}},422)}}),e=>e.code===CODE&&e.requestId===UUID&&!e.message.includes('SYNTHETIC'));
let calls=0;
const {{owner,seen}}=fixture({{request:async(path,options={{}})=>{{seen.requests.push({{path,options}});calls++;
  if(path==='/api/ingest_note')throw Object.assign(Error('refused'),{{code:CODE,requestId:UUID}});return reply()}}}});
await owner.refreshCurrent();seen.published=[];
await owner.submitPreview('/api/ingest_note',{{text:'SYNTHETIC technical text'}});
const notice=seen.notices.at(-1);assert.equal(notice.outcome,'REJECTED');assert.equal(notice.code,CODE);
assert.equal(seen.published.length,1);assert.equal(seen.published[0].extra.extracted,null);
assert.equal(seen.requests.at(-1).path,'/api/state');owner.dispose();
""")


def test_console_note_intake_clears_the_note_and_shows_the_code_and_reason():
    """The advanced console's note button: the note leaves the page once, to the gate, and is not kept."""
    from ._node import require_node, run_node

    html = (CONSOLE / "index.html").read_text(encoding="utf-8")
    textarea = html.split('<textarea id="noteText"', 1)[1].split(">", 1)[0]
    assert 'autocomplete="off"' in textarea and 'spellcheck="false"' in textarea
    ingest = "async function ingestNote(){" + html.split("async function ingestNote(){", 1)[1].split("\n", 1)[0]
    notice = "function showLegacyNotice(value){" + html.split("function showLegacyNotice(value){", 1)[1].split(
        "async function initializeLegacyPreviewRecovery", 1)[0]
    program = r'''
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();const submitted=[];
const CODE=@@CODE@@,REASON=@@REASON@@;
function el(id){if(!nodes.has(id))nodes.set(id,{id,value:'',textContent:'',innerHTML:''});return nodes.get(id)}
const context={$:el,legacyPreviewRecovery:{submitPreview:async(path,body)=>{submitted.push({path,body,left:el('noteText').value})}}};
vm.createContext(context);vm.runInContext(@@INGEST@@+@@NOTICE@@,context);
(async()=>{el('noteText').value='  SYNTHETIC technical text  ';await vm.runInContext('ingestNote()',context);
 a.equal(submitted.length,1);a.equal(submitted[0].path,'/api/ingest_note');
 a.equal(submitted[0].left,'','the note stayed in the page while it was submitted');a.equal(el('noteText').value,'');
 context.technicalNotice={outcome:'REJECTED',code:CODE,requestId:null,authority:'CONFIRMED'};
 vm.runInContext('showLegacyNotice(technicalNotice)',context);
 for(const id of ['legacy-preview-status','noteExtract']){a(el(id).textContent.includes(CODE),id+' omits the code');
   a(el(id).textContent.includes(REASON),id+' omits the reason in words')}
})().catch(error=>{console.error(error);process.exitCode=1});
'''
    for marker, value in {"@@INGEST@@": ingest, "@@NOTICE@@": notice, "@@CODE@@": CODE, "@@REASON@@": REASON}.items():
        program = program.replace(marker, json.dumps(value))
    result = run_node([require_node(), "--eval", program], capture_output=True, text=True, encoding="utf-8", timeout=15)
    assert result.returncode == 0, result.stderr
