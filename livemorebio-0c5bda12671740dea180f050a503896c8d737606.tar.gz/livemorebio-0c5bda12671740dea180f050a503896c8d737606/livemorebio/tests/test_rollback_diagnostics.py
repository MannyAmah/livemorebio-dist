"""Private child evidence and fixed failure coordinates, with technical builds."""
from __future__ import annotations

import json
import os
from pathlib import Path
import signal
import stat

import pytest

from tools import rollback_drill
from livemorebio.tests.test_rollback_drill import technical_build


def fault(build: Path, phase: str, direction: str, action: str = "raise SystemExit(7)") -> None:
    port = 18970 if direction == "forward" else 18973
    program = (
        'print("TECHNICAL_PRIVATE_STDOUT", flush=True)\n'
        'print("TECHNICAL_PRIVATE_STDERR", file=sys.stderr, flush=True)\n'
        f'if phase == {phase!r} and os.environ["LIVEMORE_AEGLE_URL"].endswith(":{port}"):\n'
        f'    {action}\n'
    )
    installer = build.parent / "install.py"
    with installer.open("a", encoding="utf-8") as stream:
        if phase == "install":
            stream.write('\nphase = "install"\n' + program)
        else:
            stream.write('\nlauncher.write_text(launcher.read_text(encoding="utf-8").replace('
                         + repr('phase = sys.argv[1]') + ', '
                         + repr('phase = sys.argv[1]\n' + program)
                         + '), encoding="utf-8")\n')


def run(first, second, output, capsys, *options):
    assert rollback_drill.main([str(first), str(second), "--output", str(output), *options]) == 1
    captured = capsys.readouterr()
    assert captured.err == ""
    assert "TECHNICAL" not in captured.out and str(output.parent) not in captured.out
    return json.loads(captured.out)


@pytest.mark.parametrize("direction", ["forward", "reverse"])
@pytest.mark.parametrize("role,phase", [
    (role, phase) for role in ("source", "target")
    for phase in ("install", "start", "create", "check", "stop")
    if (role, phase) != ("target", "create")
])
def test_child_failure_receipt_identifies_exact_phase_and_retains_private_output(
        tmp_path, capsys, direction, role, phase):
    first = technical_build(tmp_path, "technical-a")
    second = technical_build(tmp_path, "technical-b")
    failing = first if (direction == "forward") == (role == "source") else second
    fault(failing, phase, direction)
    output = tmp_path / "drill"
    receipt = run(first, second, output, capsys)
    assert receipt == {"status": "failed", "code": "PHASE_FAILED", "direction": direction,
                       "role": role, "phase": phase, "exit_status": 7}
    logs = output / direction / "logs"
    log = logs / f"{role}-{phase}.log"
    assert stat.S_IMODE(logs.stat().st_mode) == 0o700
    assert stat.S_IMODE(log.stat().st_mode) == 0o600
    assert log.stat().st_uid == os.getuid() and log.stat().st_nlink == 1
    raw = log.read_bytes()
    assert b"TECHNICAL_PRIVATE_STDOUT" in raw and b"TECHNICAL_PRIVATE_STDERR" in raw


def test_stop_failure_does_not_mask_primary_failure(tmp_path, capsys):
    first = technical_build(tmp_path, "technical-a")
    second = technical_build(tmp_path, "technical-b")
    fault(second, "check", "forward")
    fault(second, "stop", "forward", "raise SystemExit(9)")
    receipt = run(first, second, tmp_path / "drill", capsys)
    assert receipt == {"status": "failed", "code": "PHASE_FAILED", "direction": "forward",
                       "role": "target", "phase": "check", "exit_status": 7,
                       "cleanup_failure": {"code": "PHASE_FAILED", "direction": "forward",
                                           "role": "target", "phase": "stop", "exit_status": 9}}


@pytest.mark.parametrize("kind", ["timeout", "signal", "spawn"])
def test_timeout_signal_and_spawn_failure_keep_fixed_exit_status(tmp_path, capsys, kind):
    first = technical_build(tmp_path, "technical-a")
    second = technical_build(tmp_path, "technical-b")
    expected = {"timeout": ("PHASE_TIMEOUT", -signal.SIGTERM),
                "signal": ("PHASE_FAILED", -signal.SIGKILL),
                "spawn": ("PHASE_NOT_STARTED", "NOT_STARTED")}[kind]
    if kind == "spawn":
        value = json.loads(first.read_text(encoding="utf-8"))
        value["install"] = ["/TECHNICAL_MISSING_EXECUTABLE"]
        first.write_text(json.dumps(value), encoding="utf-8")
    else:
        action = "__import__('time').sleep(30)" if kind == "timeout" else "os.kill(os.getpid(), 9)"
        fault(first, "install", "forward", action)
    receipt = run(first, second, tmp_path / "drill", capsys, "--timeout-seconds", "0.5")
    assert receipt == {"status": "failed", "code": expected[0], "direction": "forward",
                       "role": "source", "phase": "install", "exit_status": expected[1]}
    log = tmp_path / "drill/forward/logs/source-install.log"
    assert log.is_file() and stat.S_IMODE(log.stat().st_mode) == 0o600


def test_hash_failure_keeps_completed_child_coordinates_when_cleanup_fails(tmp_path, capsys):
    first = technical_build(tmp_path, "technical-a")
    second = technical_build(tmp_path, "technical-b", "corrupt-start")
    fault(second, "stop", "forward", "raise SystemExit(9)")
    receipt = run(first, second, tmp_path / "drill", capsys)
    assert receipt == {"status": "failed", "code": "RUN_HASH_CHANGED", "direction": "forward",
                       "role": "target", "phase": "start", "exit_status": 0,
                       "cleanup_failure": {"code": "PHASE_FAILED", "direction": "forward",
                                           "role": "target", "phase": "stop", "exit_status": 9}}


@pytest.mark.parametrize("kind", ["file", "symlink", "directory-symlink", "public-directory"])
def test_unsafe_or_existing_logs_fail_closed_without_overwriting(tmp_path, capsys, monkeypatch, kind):
    first = technical_build(tmp_path, "technical-a")
    second = technical_build(tmp_path, "technical-b")
    original = rollback_drill._environment
    sentinel = tmp_path / "technical-private-original"
    sentinel.write_bytes(b"unchanged")

    def environment(root, port):
        result = original(root, port)
        logs = root / "logs"
        if kind == "directory-symlink":
            logs.symlink_to(tmp_path, target_is_directory=True)
        else:
            mode = 0o755 if kind == "public-directory" else 0o700
            logs.mkdir(mode=mode)
            logs.chmod(mode)
            if kind == "symlink":
                (logs / "source-install.log").symlink_to(sentinel)
            elif kind == "file":
                (logs / "source-install.log").write_bytes(b"unchanged")
        return result

    monkeypatch.setattr(rollback_drill, "_environment", environment)
    receipt = run(first, second, tmp_path / "drill", capsys)
    assert receipt == {"status": "failed", "code": "UNSAFE_PHASE_LOG", "direction": "forward",
                       "role": "source", "phase": "install", "exit_status": "NOT_STARTED"}
    assert sentinel.read_bytes() == b"unchanged"
    assert not (tmp_path / "drill/forward/data/technical-steps.jsonl").exists()


def test_success_retains_every_phase_log_without_printing_child_output(tmp_path, capsys):
    first = technical_build(tmp_path, "technical-a")
    second = technical_build(tmp_path, "technical-b")
    output = tmp_path / "drill"
    assert rollback_drill.main([str(first), str(second), "--output", str(output)]) == 0
    captured = capsys.readouterr()
    assert captured.err == "" and "TECHNICAL_" not in captured.out
    for direction in ("forward", "reverse"):
        logs = list((output / direction / "logs").glob("*.log"))
        assert len(logs) == 9
        assert all(path.stat().st_mode & 0o777 == 0o600 and path.stat().st_size for path in logs)
