"""The metabolic protocol is a research result, never an active-subject update."""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def api(monkeypatch, tmp_path):
    from livemorebio.aegle import server
    from livemorebio.cendos.protocol_runs import ProtocolRunStore
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-metabolic-route-token")
    monkeypatch.setenv("LIVEMORE_MODEL_DIR", str(tmp_path / "missing-models"))
    monkeypatch.setattr(server, "_protocol_run_store", lambda: ProtocolRunStore(tmp_path / "runs"))
    return TestClient(server.app), {"Authorization": "Bearer technical-metabolic-route-token"}


def test_models_and_history_are_authenticated_and_do_not_invent_records(api):
    client, auth = api
    for path in ("/api/genome-models", "/api/cendos/protocols/history"):
        response = client.get(path)
        assert response.status_code == 401
        assert "no-store" in response.headers["cache-control"]
    models = client.get("/api/genome-models", headers=auth).json()["models"]
    assert {row["model_id"] for row in models} == {"human-gem", "recon3d"}
    assert all(not row["status"]["available"] for row in models)
    assert client.get("/api/cendos/protocols/history", headers=auth).json()["runs"] == []
    assert client.get("/api/cendos/protocols/history?limit=51", headers=auth).status_code == 422


def test_active_biology_requires_read_authorization(api):
    client, auth = api
    denied = client.get("/api/biology")
    assert denied.status_code == 401
    assert "no-store" in denied.headers["cache-control"]
    permitted = client.get("/api/biology", headers=auth)
    assert permitted.status_code == 200
    assert "no-store" in permitted.headers["cache-control"]
    assert "organs" in permitted.json()


def test_biology_and_cell_state_are_bound_to_same_instance_and_readout(api, monkeypatch):
    from livemorebio.aegle import server
    from livemorebio.engines import biology

    class Twin:
        voltage = -80

        def state(self):
            return {"cardiac": {"v": [self.voltage]}, "human": None}

    twin = Twin()
    monkeypatch.setattr(server, "_state", {"tw": twin, "subject": None})
    monkeypatch.setattr(biology, "biology_state", lambda value: {"organs": [], "twin": {}})
    client, auth = api
    first = client.get("/api/state", headers=auth).json()["context_id"]
    assert len(first) == 64
    assert client.get("/api/biology", headers=auth).json()["context_id"] == first
    twin.voltage = -70
    changed = client.get("/api/state", headers=auth).json()["context_id"]
    assert changed != first
    assert client.get("/api/biology", headers=auth).json()["context_id"] == changed
    replacement = Twin()
    replacement.voltage = -70
    server._state["tw"] = replacement
    assert client.get("/api/state", headers=auth).json()["context_id"] != changed

    def concurrent_update(value):
        value.voltage = -60
        return {"organs": [], "twin": {}}

    monkeypatch.setattr(biology, "biology_state", concurrent_update)
    stale = client.get("/api/biology", headers=auth)
    assert stale.status_code == 503
    assert stale.json()["code"] == "BIOLOGY_CONTEXT_CHANGED"
    assert "context_id" not in stale.json()


def test_protocol_rejects_malformed_and_unavailable_without_active_mutation(api):
    from livemorebio.aegle import server
    client, auth = api
    original_twin, original_subject = server._state["tw"], server._state.get("subject")
    url = "/api/cendos/protocols/human-gem-oxygen-capacity"
    assert client.post(url, json={}).status_code == 401
    response = client.post(url, content='{"conditions":[],"conditions":[]}', headers=auth)
    assert response.status_code == 422
    response = client.post(url, json={"conditions": [{"condition_id": "x", "glucose_uptake": 1, "oxygen_uptake": 6}]}, headers=auth)
    assert response.status_code in {422, 503}
    assert response.json()["code"] == "MODEL_UNAVAILABLE"
    assert server._state["tw"] is original_twin
    assert server._state.get("subject") is original_subject
    assert client.get("/api/cendos/protocols/history", headers=auth).json()["runs"] == []


def test_rerun_preparation_unknown_id_is_read_only(api):
    client, auth = api
    response = client.get("/api/cendos/protocols/protocol-" + "a" * 32 + "/prepare-rerun", headers=auth)
    assert response.status_code == 404
    assert client.get("/api/cendos/protocols/history", headers=auth).json()["runs"] == []


@pytest.mark.parametrize("code,status", [("MODEL_EXECUTION_TIMEOUT", 504), ("MODEL_EXECUTION_FAILED", 503)])
def test_worker_failures_have_retryable_service_status(code, status):
    from livemorebio.aegle import server
    from livemorebio.engines.stoichiometry import StoichiometryError
    assert server._protocol_failure(StoichiometryError("Execution could not complete", code)).status_code == status


def test_rerun_binds_parent_to_requested_protocol(monkeypatch):
    from livemorebio.aegle import server
    captured = {}
    class Store:
        def validate_rerun(self, *args, **kwargs):
            captured.update(kwargs)
            return {}
    monkeypatch.setattr(server, "_protocol_run_store", Store)
    server._rerun_parent({"parent_run_id": "technical-parent", "new_configuration": True}, {},
                         "cendos.human-gem-oxygen-capacity.v1")
    assert captured["expected_protocol_id"] == "cendos.human-gem-oxygen-capacity.v1"


@pytest.mark.parametrize("suffix", ["", "/analysis.csv", "/analysis.ipynb"])
def test_protocol_storage_errors_are_safe_and_not_cached(api, monkeypatch, suffix):
    from livemorebio.aegle import server
    class Store:
        def get(self, identity):
            raise OSError("private-store-path-that-must-not-leak")
    monkeypatch.setattr(server, "_protocol_run_store", Store)
    client, auth = api
    response = client.get("/api/cendos/protocols/protocol-" + "a" * 32 + suffix, headers=auth)
    assert response.status_code == 503
    assert "private-store-path" not in response.text
    assert "no-store" in response.headers["cache-control"]


@pytest.mark.parametrize("endpoint,payload", [
    ("metformin-cohorts", {"cohort_a_id": "a", "cohort_b_id": "b", "dose_mg": True}),
    ("metformin-cohorts", {"cohort_a_id": "a", "cohort_b_id": "b", "grams": "75"}),
    ("garcinoic-pxr", {"cohort_id": "a", "concentrations_um": [True]}),
    ("garcinoic-pxr", {"cohort_id": "a", "concentrations_um": ["1.3"]}),
])
def test_protocol_numeric_inputs_reject_boolean_and_string_coercion(api, monkeypatch, endpoint, payload):
    from livemorebio.aegle import server
    class Registry:
        def get_cohort(self, identity):
            return {"cohort_id": identity}
    monkeypatch.setattr(server, "_subject_registry", Registry)
    client, auth = api
    response = client.post("/api/cendos/protocols/" + endpoint, json=payload, headers=auth)
    assert response.status_code == 422
    assert response.json()["code"] == "INVALID_PROTOCOL"
    assert "number" in response.json()["error"]
