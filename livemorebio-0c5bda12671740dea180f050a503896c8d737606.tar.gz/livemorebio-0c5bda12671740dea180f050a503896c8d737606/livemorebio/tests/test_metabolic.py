"""Real clinical-criterion tests for the metabolic engine.
These assert biological behaviour (ADA OGTT thresholds), not implementation detail."""
import numpy as np
from livemorebio.engines.metabolic.glucose_insulin import (
    GlucoseInsulinModel, HEALTHY, T2D, summarize)


def _at(res, minute):
    return float(res["glucose"][np.argmin(np.abs(res["t_min"] - minute))])


def test_healthy_ogtt_is_normal():
    r = GlucoseInsulinModel(HEALTHY).simulate(hours=4, meals_g=[(0.0, 75.0)])
    assert _at(r, 120) < 140.0                     # ADA normal 2-h OGTT
    assert abs(r["glucose"][-1] - HEALTHY.Gb) < 20 # returns toward baseline


def test_t2d_ogtt_is_diabetic():
    r = GlucoseInsulinModel(T2D).simulate(hours=4, meals_g=[(0.0, 75.0)])
    assert _at(r, 120) >= 200.0                    # ADA diabetes 2-h OGTT
    assert r["glucose"][-1] > T2D.Gb + 10          # stays elevated


def test_disease_ordering():
    h = GlucoseInsulinModel(HEALTHY).simulate(hours=4)
    d = GlucoseInsulinModel(T2D).simulate(hours=4)
    assert d["glucose"].max() > h["glucose"].max()
    assert summarize(d)["iAUC_mg_dL_min"] > summarize(h)["iAUC_mg_dL_min"]


def test_is_living_dynamic():
    r = GlucoseInsulinModel(HEALTHY).simulate(hours=4, meals_g=[(0.0, 75.0)])
    assert r["glucose"].std() > 5.0                # not a static value
    assert r["insulin"].max() > HEALTHY.Ib         # insulin responds to glucose


def test_no_meal_holds_homeostasis():
    r = GlucoseInsulinModel(HEALTHY).simulate(hours=4, meals_g=[])
    g = r["glucose"]
    assert abs(g.max() - g.min()) < 1.0            # basal steady state holds
