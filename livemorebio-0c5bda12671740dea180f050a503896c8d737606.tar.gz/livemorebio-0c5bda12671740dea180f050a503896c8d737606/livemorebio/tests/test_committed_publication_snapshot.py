"""A frozen publication cannot borrow a later selection's model parameters."""
from copy import deepcopy
from dataclasses import dataclass
from types import SimpleNamespace

import pytest

from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401


@pytest.mark.parametrize("parameters", [{"technical_source": "prepared-model"}, None])
def test_publication_keeps_its_own_parameters_after_another_selection(client, monkeypatch, parameters):
    from livemorebio import bus, events
    from livemorebio.aegle import server

    @dataclass
    class TechnicalProfile:
        technical_source: str = "different-later-model"

    server._state["tw"] = SimpleNamespace(profile=TechnicalProfile())
    supplied = {"profile": "Authored prior snapshot", "profile_params": deepcopy(parameters),
                "model_availability": {"source_generation": "technical-prior-generation"}}
    original = deepcopy(supplied)
    snapshots, published = [], []
    monkeypatch.setattr(bus, "set_snapshot", lambda name, value: snapshots.append((name, deepcopy(value))))
    monkeypatch.setattr(bus, "publish", lambda *args: published.append(args))
    server._snapshot_twin(supplied)
    assert snapshots == [("twin", original)]
    assert supplied == original
    assert published == [("Aegle", events.TWIN_UPDATED,
                          {"profile": original["profile"], "last": None, "mean_glucose": None})]


def test_incomplete_snapshot_never_borrows_the_current_profile(client, monkeypatch):
    from livemorebio import bus
    from livemorebio.aegle import server

    class UnrelatedTwin:
        @property
        def profile(self):
            pytest.fail("Publication read a different selection's profile")

    server._state["tw"] = UnrelatedTwin()
    monkeypatch.setattr(bus, "set_snapshot", lambda *args: pytest.fail("Incomplete snapshot published"))
    monkeypatch.setattr(bus, "publish", lambda *args: pytest.fail("Incomplete event published"))
    server._snapshot_twin({"profile": "Authored incomplete snapshot"})


@pytest.mark.parametrize("parameters", [[], "technical-invalid", True])
def test_malformed_parameters_never_publish(client, monkeypatch, parameters):
    from livemorebio import bus
    from livemorebio.aegle import server

    monkeypatch.setattr(bus, "set_snapshot", lambda *args: pytest.fail("Malformed snapshot published"))
    monkeypatch.setattr(bus, "publish", lambda *args: pytest.fail("Malformed event published"))
    server._snapshot_twin({"profile": "Authored malformed snapshot", "profile_params": parameters})


@pytest.mark.parametrize("ready", [False, True])
def test_default_publication_uses_current_snapshots_own_projection(client, monkeypatch, ready):
    from livemorebio import bus, events
    from livemorebio.aegle import server

    source = {"profile": "Authored technical model", "profile_params": {"technical_key": ["original"]},
              "applied": ["authored technical action"], "metabolic": {"mean_glucose": None}}
    if ready:
        server._state["tw"] = SimpleNamespace(state=lambda: source)
    expected = server._current_snapshot()
    snapshots, published = [], []
    monkeypatch.setattr(bus, "set_snapshot", lambda name, value: snapshots.append((name, deepcopy(value))))
    monkeypatch.setattr(bus, "publish", lambda *args: published.append(deepcopy(args)))
    server._snapshot_twin()
    assert snapshots == [("twin", expected)]
    assert published == [("Aegle", events.TWIN_UPDATED,
                          {"profile": expected["profile"],
                           "last": (expected.get("applied") or [None])[-1],
                           "mean_glucose": None})]
    if ready:
        source["profile_params"]["technical_key"].append("later")
        assert expected["profile_params"] == {"technical_key": ["original"]}
    else:
        assert expected["profile_params"] is None


def test_publication_failure_logs_only_fixed_phase_without_exception_identity(client, monkeypatch, caplog):
    from livemorebio import bus
    from livemorebio.aegle import server

    private_error = type("AUTHORED_PRIVATE_EXCEPTION_NAME", (OSError,), {})

    def broken(*args, **kwargs):
        raise private_error("AUTHORED_PRIVATE_EXCEPTION_MESSAGE")

    monkeypatch.setattr(bus, "set_snapshot", broken)
    monkeypatch.setattr(bus, "publish", lambda *a: pytest.fail("Failed snapshot published an event"))
    server._snapshot_twin({"profile": "Authored source", "profile_params": {}})
    assert "AUTHORED_PRIVATE" not in caplog.text
    assert "Aegle cross-product snapshot publication failed" in caplog.text
