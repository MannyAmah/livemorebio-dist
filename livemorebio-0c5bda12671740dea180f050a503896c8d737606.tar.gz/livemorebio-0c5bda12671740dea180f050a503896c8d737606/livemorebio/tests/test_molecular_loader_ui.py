"""Browser-source admission with authored bytes, never a structure solve."""
import json
from pathlib import Path
import subprocess

import pytest
from ._node import NODE, run_node as _run_node

ROOT = Path(__file__).parents[2]
MODULE = ROOT / "livemorebio/aegle/console/lib/molecular_loader.js"
CATALOG = ROOT / "livemorebio/scientific_sources/data/molecular/catalog.json"


def run_node(body: str) -> None:
    program = r"""const assert=require('node:assert/strict');
const fs=require('node:fs');
const source=fs.readFileSync(MODULE,'utf8');
const catalog=JSON.parse(fs.readFileSync(CATALOG,'utf8'));
const tick=()=>new Promise(r=>setTimeout(r,0));
let finished=false;
process.on('beforeExit',()=>{if(!finished)process.exitCode=1;});
(async()=>{
const mod=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const raw=new TextEncoder().encode('data_TECHNICAL_ONLY\n');
const sha=require('node:crypto').createHash('sha256').update(raw).digest('hex');
const descriptor={...structuredClone(catalog.structures['4OBE']),coordinate_sha256:sha,
 coordinate_bytes:raw.length,asset_path:`/api/molecular/structures/${sha}/coordinates`};
const metadata={gene:'KRAS',status:'REFERENCE_AVAILABLE',reason_code:null,pdb:'4OBE',
 uniprot:'P01116',reference:descriptor,related_references:[]};
const identity={'X-Livemore-Source-Sha256':'b'.repeat(64),
 'X-Livemore-Process-Instance':'12345678-1234-4123-8123-123456789abc'};
const calls=[],counts={cancel:0,release:0};
function response(data,type,extra={}){
 let index=0;const bytes=typeof data==='string'?new TextEncoder().encode(data):data;
 const headers=new Headers({...identity,'Content-Type':type,...extra});
 return {status:200,redirected:false,headers,body:{getReader(){return {
 async read(){return index++?{done:true}:{value:bytes,done:false};},
 async cancel(){counts.cancel++;},releaseLock(){counts.release++;}};}}};
}
function fetchImpl(url,options){calls.push({url,options});return Promise.resolve(calls.length===1?
 response(JSON.stringify(metadata),'application/json'):
 response(raw,'chemical/x-cif',{'X-Content-SHA256':sha,'X-Livemore-Evidence-State':'REFERENCE_ONLY'}));}
BODY
finished=true;
})().catch(e=>{console.error(e.name,e.message);process.exit(1);});
""".replace("MODULE", json.dumps(str(MODULE))).replace("CATALOG", json.dumps(str(CATALOG))).replace("BODY", body)
    result = _run_node([NODE, "--eval", program], cwd=ROOT,
                            capture_output=True, text=True, timeout=10, encoding="utf-8")
    assert result.returncode == 0, result.stdout + result.stderr


def test_exact_source_read_without_eof_cancel():
    run_node("""
const op=mod.createMolecularOperation({fetchImpl});
const out=await op.wait(op.read('KRAS'));
assert.equal(out.text,new TextDecoder().decode(raw));assert.equal(out.metadata.pdb,'4OBE');
assert.equal(out.identity.sourceSha256,identity['X-Livemore-Source-Sha256']);
assert.equal(calls.length,2);assert.equal(counts.cancel,0);assert.equal(counts.release,2);
for(const call of calls){assert.equal(call.options.method,'GET');assert.equal(call.options.redirect,'error');
 assert.equal(call.options.credentials,'same-origin');assert.equal(call.options.cache,'no-store');}
op.finish();
""")


@pytest.mark.parametrize("mutation", [
    "metadata.gene='TP53'", "metadata.pdb='1TUP'", "descriptor.schema='wrong'",
    "descriptor.coordinate_bytes=true", "descriptor.coordinate_bytes=8388609",
    "descriptor.coordinate_sha256='A'.repeat(64)", "descriptor.format='pdb'",
    "descriptor.asset_path='https://foreign.invalid/source'", "descriptor.asset_path+='?x=1'",
    "descriptor.asset_path+='/'", "descriptor.patient_specific=true",
    "descriptor.dynamic_coordinates=true", "descriptor.evidence_state='OBSERVED'",
    "descriptor.selected_model_index=-1", "descriptor.selected_model_number=2",
    "descriptor.atom_site_rows=100001", "descriptor.resolution_angstrom='Infinity'",
    "descriptor.assembly='BIOLOGICAL_ASSEMBLY'",
])
def test_bad_descriptor_rejects_before_coordinates(mutation):
    run_node(mutation + """;
const op=mod.createMolecularOperation({fetchImpl});
await assert.rejects(op.wait(op.read('KRAS')),e=>e.code==='MOLECULAR_INVALID_REFERENCE');
assert.equal(calls.length,1);op.finish();
""")


@pytest.mark.parametrize("status", ["MAPPING_UNAVAILABLE", "AMBIGUOUS_TARGET"])
def test_explicit_missing_mapping_never_borrows_related_structure(status):
    run_node(f"metadata.status={json.dumps(status)};" + """
metadata.pdb=null;metadata.reference=null;metadata.uniprot=null;
metadata.reason_code='SOURCE_MAPPING_NOT_ADMITTED';metadata.related_references=[descriptor];
const op=mod.createMolecularOperation({fetchImpl});const out=await op.wait(op.read('KRAS'));
assert.equal(out.text,null);assert.equal(calls.length,1);op.finish();
""")


def test_frozen_reference_mismatch_never_loads_other_coordinates():
    run_node("""
const op=mod.createMolecularOperation({fetchImpl});
await assert.rejects(op.wait(op.read('KRAS','1TUP')),e=>e.code==='MOLECULAR_INVALID_REFERENCE');
assert.equal(calls.length,1);op.finish();
""")


@pytest.mark.parametrize("fault", ["status", "redirect", "type", "source", "process", "digest", "evidence", "bytes"])
def test_coordinate_response_must_match_metadata(fault):
    run_node(f"const fault={json.dumps(fault)};" + """
const good=fetchImpl;
const altered=async(...args)=>{const r=await good(...args);if(calls.length===2){
 if(fault==='status')r.status=201;if(fault==='redirect')r.redirected=true;
 const fields={type:'Content-Type',source:'X-Livemore-Source-Sha256',process:'X-Livemore-Process-Instance',
 digest:'X-Content-SHA256',evidence:'X-Livemore-Evidence-State'};
 if(fields[fault])r.headers.set(fields[fault],'wrong');
 if(fault==='bytes')r.body.getReader=()=>({read:async()=>({value:new Uint8Array(raw.length+1),done:false}),cancel:async()=>{},releaseLock(){}});
}return r;};
const op=mod.createMolecularOperation({fetchImpl:altered});
await assert.rejects(op.wait(op.read('KRAS')),e=>e.code==='MOLECULAR_INVALID_REFERENCE');
assert.equal(calls.length,2);op.finish();
""")


def test_deadline_settles_even_when_fetch_ignores_abort_and_late_body_is_canceled():
    run_node("""
let resolve;const pending=new Promise(r=>resolve=r);
const op=mod.createMolecularOperation({fetchImpl:()=>pending,timeoutMs:10});
const task=op.read('KRAS');
await assert.rejects(op.wait(task),e=>e.code==='MOLECULAR_TIMEOUT');
resolve(response(JSON.stringify(metadata),'application/json'));
await assert.rejects(task,e=>e.code==='MOLECULAR_TIMEOUT');assert.equal(counts.cancel,1);op.finish();
""")


def test_aborted_request_and_nonfinite_timeout_are_rejected():
    run_node("""
assert.throws(()=>mod.createMolecularOperation({timeoutMs:Infinity}));
const op=mod.createMolecularOperation({fetchImpl});op.abort();
await assert.rejects(op.wait(op.read('KRAS')),e=>e.code==='MOLECULAR_CANCELED');
assert.equal(calls.length,0);op.finish();
""")


@pytest.mark.parametrize("target", [["KRAS"], {"target": "KRAS"}, 1])
def test_target_must_be_an_actual_string_before_io(target):
    run_node(f"const target={json.dumps(target)};" + """
const op=mod.createMolecularOperation({fetchImpl});
await assert.rejects(op.wait(op.read(target)),e=>e.code==='MOLECULAR_INVALID_REFERENCE');
assert.equal(calls.length,0);op.finish();
""")


def test_completed_operation_cannot_be_reused_without_a_deadline():
    run_node("""
const op=mod.createMolecularOperation({fetchImpl});await op.wait(op.read('KRAS'));op.finish();
await assert.rejects(op.read('KRAS'),e=>e.code==='MOLECULAR_CANCELED');assert.equal(calls.length,2);
""")


def test_default_transport_preserves_native_fetch_after_passive_auth_mount():
    run_node("""
const nativeCalls=[];global.window=global;global.location={href:'http://127.0.0.1:8910/biology',origin:'http://127.0.0.1:8910'};
global.document={readyState:'loading',addEventListener(){}};
global.fetch=async(url,options)=>{nativeCalls.push({url,options});return fetchImpl(url,options);};
const originalFetch=global.fetch;
require('node:vm').runInThisContext(fs.readFileSync(require('node:path').join(require('node:path').dirname(MODULE_PATH),'auth.js'),'utf8'));
const op=mod.createMolecularOperation();const value=await op.wait(op.read('KRAS'));op.finish();
assert.equal(global.fetch,originalFetch);
assert.equal(value.text,new TextDecoder().decode(raw));assert.equal(nativeCalls.length,2);
assert.deepEqual(nativeCalls.map(c=>c.url),['/api/structure?gene=KRAS',descriptor.asset_path]);
assert.equal(calls.length,2);assert(nativeCalls.every(c=>c.options.credentials==='same-origin'));
""".replace("MODULE_PATH", json.dumps(str(MODULE))))
