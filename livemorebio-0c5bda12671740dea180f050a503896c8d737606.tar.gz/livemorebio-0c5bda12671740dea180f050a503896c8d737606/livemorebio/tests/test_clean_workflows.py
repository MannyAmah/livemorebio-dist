"""Empty installations and long registries must not invent or hide participants."""
from __future__ import annotations

import pytest

from livemorebio.aegle.subjects import SubjectRegistry, SubjectRegistryError


@pytest.fixture
def registry(tmp_path):
    return SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"p" * 32)


def _create(registry, label, index):
    return registry.create_twin({
        "source_class": "SYNTHETIC", "subject_id": f"pseudonym-technical-pagination-{index}",
        "display_label": label, "demographics": {"age": 45, "sex": "U"},
    })


def test_registry_pages_all_records_beyond_legacy_cap_without_duplicates(registry):
    expected = {_create(registry, f"Technical record {i:03}", i)["twin_id"] for i in range(215)}
    seen, cursor = [], None
    while True:
        page = registry.page_records("TWIN", limit=25, cursor=cursor)
        assert len(page["records"]) <= 25
        assert page["pagination"]["total"] == 215
        seen.extend(row["twin_id"] for row in page["records"])
        cursor = page["pagination"]["next_cursor"]
        if not page["pagination"]["has_more"]:
            assert cursor is None
            break
    assert set(seen) == expected
    assert len(seen) == len(expected)


def test_search_is_local_and_cursor_bound_to_kind_and_query(registry):
    for i in range(12):
        _create(registry, f"Cedar {i}" if i % 2 else f"Oak {i}", i)
    page = registry.page_records("TWIN", limit=3, q="cedar")
    assert len(page["records"]) == 3
    assert all("Cedar" in row["display_label"] for row in page["records"])
    cursor = page["pagination"]["next_cursor"]
    assert cursor
    for wrong in ({"q": "oak"}, {"record_type": "COHORT"}):
        args = {"record_type": "TWIN", "limit": 3, "q": "cedar", "cursor": cursor, **wrong}
        with pytest.raises(SubjectRegistryError):
            registry.page_records(**args)
    assert b"Cedar" not in registry.path.read_bytes()


@pytest.mark.parametrize("args", [
    {"limit": 0}, {"limit": 51}, {"limit": True}, {"limit": 2.2},
    {"cursor": "not-a-cursor"}, {"q": "x" * 121}, {"q": []},
])
def test_invalid_pagination_rejects(registry, args):
    with pytest.raises(SubjectRegistryError):
        registry.page_records("TWIN", **args)


def test_empty_page_and_active_reset_do_not_create_or_delete_records(registry):
    assert registry.page_records("TWIN")["records"] == []
    assert registry.active_twin() is None
    twin = _create(registry, "Technical active twin", 1)
    registry.activate_twin(twin["twin_id"], expected_version=twin["version"])
    registry.clear_active_twin()
    assert registry.active_twin() is None
    assert registry.get_twin(twin["twin_id"])["lifecycle"] == "DATA_ADMITTED"

    assert len(registry.list_twins()) == 1


def test_healthy_preview_does_not_claim_admitted_identity():
    from livemorebio.aegle.workspace import preview_subject

    value = preview_subject("healthy")
    assert value["lifecycle"] == "PREVIEW"
    assert value["source_class"] == "REFERENCE_INITIALIZED"
    assert value["twin_id"] is None
    assert value["subject_id"] is None
    assert value["display_label"] == "Healthy reference preview"


def test_local_sdk_starts_healthy():
    from livemorebio.sdk import Platform

    platform = Platform()
    assert platform._twin.state()["base"] == "healthy"


def test_http_registry_pages_and_healthy_empty_start(registry, monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server
    from livemorebio.aegle.runtime import AegleTwin

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-clean-workflow-token")
    monkeypatch.setattr(server, "_subject_registry", lambda: registry)
    monkeypatch.setattr(server, "_state", {"tw": AegleTwin("healthy"), "subject": None})
    client = TestClient(server.app)
    auth = {"Authorization": "Bearer technical-clean-workflow-token"}
    assert client.get("/api/twins").status_code == 401
    response = client.get("/api/twins?limit=10", headers=auth)
    assert response.status_code == 200
    assert response.json()["twins"] == []
    assert response.json()["active"]["lifecycle"] == "PREVIEW"
    assert response.json()["pagination"]["total"] == 0
    assert "no-store" in response.headers["cache-control"]
    for index in range(12):
        _create(registry, f"HTTP fixture {index}", index)
    page = client.get("/api/twins?limit=10", headers=auth).json()
    assert len(page["twins"]) == 10
    assert page["pagination"]["has_more"]
    bad = client.get("/api/twins?limit=1000", headers=auth)
    assert bad.status_code == 422
    assert client.get("/api/cohorts?limit=10", headers=auth).json()["cohorts"] == []


def test_configurable_review_ports_reject_collisions_before_start(tmp_path):
    from livemorebio.tests.test_review_isolation import _review_launcher

    module = _review_launcher()
    _, env = module.prepare_review_environment(tmp_path, inherited={}, base_port=8870)
    assert env["LIVEMORE_AEGLE_URL"] == "http://127.0.0.1:8870"
    assert env["LIVEMORE_CENDOS_URL"] == "http://127.0.0.1:8872"
    assert env["LIVEMORE_MODEL_DIR"] == str(tmp_path / "models")
    for port in (0, 1023, 65534, True, 8850):
        with pytest.raises(ValueError):
            module.prepare_review_environment(tmp_path, inherited={}, base_port=port)


def test_preview_transition_clears_persisted_identity_but_invalid_base_preserves_it(registry, monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server
    from livemorebio.aegle.runtime import AegleTwin
    twin = _create(registry, "Technical identity boundary", 0)
    active = registry.activate_twin(twin["twin_id"], expected_version=twin["version"])
    initial_twin = AegleTwin("healthy")
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-identity-token")
    monkeypatch.setattr(server, "_subject_registry", lambda: registry)
    monkeypatch.setattr(server, "_state", {"tw": initial_twin, "subject": active})
    monkeypatch.setattr(server, "_snapshot_twin", lambda *args: None)
    client = TestClient(server.app)
    auth = {"Authorization": "Bearer technical-identity-token"}
    invalid = client.post("/api/stimulate", headers=auth, json={"kind": "base", "params": {"base": "healty"}})
    assert invalid.status_code == 422
    assert server._state["tw"] is initial_twin
    assert registry.active_twin()["twin_id"] == twin["twin_id"]
    # L0-R15: a note is refused before any transition, so the selection survives it;
    # the technical route (explicit structured fields) performs the clearing preview.
    refused = client.post("/api/ingest_note", headers=auth, json={"text": "Technical fixture only"})
    assert refused.status_code == 422 and refused.json()["code"] == "CLINICAL_NOTE_NOT_ACCEPTED"
    assert server._state["tw"] is initial_twin
    assert registry.active_twin()["twin_id"] == twin["twin_id"]
    response = client.post("/api/stimulate", headers=auth, json={"kind": "life_system", "params": {
        "mode": "custom", "id": "LMB-CUSTOM", "age": 50, "sex": "F",  # round 1: a technical id
        "conditions": [], "genome": {}, "lifestyle": 0.6}})
    assert response.status_code == 200
    assert server._state["subject"] is None
    assert registry.active_twin() is None
    assert registry.get_twin(twin["twin_id"])["lifecycle"] == "DATA_ADMITTED"

    for base in ("t2d", "type-2-diabetes", "healthy"):
        response = client.post("/api/stimulate", headers=auth, json={"kind": "base", "params": {"base": base}})
        assert response.status_code == 200
        assert response.json()["base"] == base


def test_service_launch_uses_its_own_package_root_not_callers_checkout(tmp_path, monkeypatch):
    from pathlib import Path
    from types import SimpleNamespace
    from livemorebio import cli, security

    calls = []
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(cli.R, "REG_DIR", str(tmp_path / "registry"))
    monkeypatch.setattr(cli, "ensure_api_token", lambda: "technical-token")
    monkeypatch.setattr(security, "ensure_patch_security_keys", lambda: None)
    monkeypatch.setattr(cli, "_health", lambda port: None)
    monkeypatch.setattr(cli, "_wait_for_services", lambda names, **options: [])
    monkeypatch.setattr(cli, "status", lambda: None)
    monkeypatch.setattr(cli.R, "register", lambda *args: None)
    monkeypatch.setattr(cli.subprocess, "Popen", lambda *args, **kwargs: (calls.append((args, kwargs)) or SimpleNamespace(pid=123)))
    cli.start(["Aegle"])
    assert Path(calls[0][1]["cwd"]) == Path(cli.__file__).resolve().parent.parent
    assert "-B" in calls[0][0][0]
