"""Actual legacy controller and pure owner tests; authored state, no browser."""
import json

import pytest

from .test_clinical_model_availability_ui import CONSOLE, node
from .test_legacy_preview_recovery_clients import preview

PREAMBLE = r"""
import assert from 'node:assert/strict';
import {createLegacyPreviewRecovery,requestLegacyPreview} from MODULE;
import {selectionRequest} from TRANSPORT;
const UUID='563e4d61-9872-4fe3-820b-a18903a522a0',PRIVATE='AUTHORED_PRIVATE_SENTINEL';
const ready=()=>JSON.parse(READY);
function modeless(){const x=ready();for(const k of ['profile','base','profile_params','pk_context','parameter_provenance','provenance','intervention','metabolic','cardiac','hepatic','comparison'])x[k]=null;x.applied=[];x.active_execution=null;x.human=null;x.model_availability={schema:'livemore.model-availability.v1',state:'UNAVAILABLE',reason_code:'MODEL_BINDING_REQUIRED',selection_mode:'observations_only',twin_id:'technical-twin',twin_version:2,source_generation:'technical-selected',preparation_available:false};return x;}
const reply=(value=ready(),requestId=UUID)=>({payload:value,requestId});
const http=(value,status=200,id=UUID)=>new Response(typeof value==='string'?value:JSON.stringify(value),{status,headers:{'X-Request-ID':id}});
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return{promise,resolve,reject}};
const tick=async()=>{for(let i=0;i<16;i++)await Promise.resolve()};
const post={path:'/api/stimulate',body:{kind:'base',params:{base:'healthy'}}};
// L0-R15: the note route is refused by the service; its console handling is in test_l0_clinical_note_gate.py.
const kinds=[post,{path:'/api/stimulate',body:{kind:'life_system',params:{mode:'custom',age:50,genome:{},conditions:[]}}}];
function fixture(overrides={}){
 const seen={requests:[],published:[],notices:[],busy:[],clear:0};
 const owner=createLegacyPreviewRecovery({request:async(path,options={})=>{seen.requests.push({path,options});return reply()},
  clearCurrent:()=>{seen.clear++},publishCurrent:(value,extra)=>seen.published.push({value,extra}),
  publishNotice:value=>seen.notices.push(value),setBusy:value=>seen.busy.push(value),...overrides});
 return {owner,seen};
}
"""


def check(script):
    source = PREAMBLE.replace("MODULE", json.dumps((CONSOLE / "lib/legacy_preview_recovery.js").as_uri()))
    source = source.replace("TRANSPORT", json.dumps((CONSOLE / "lib/selection_reconciliation.js").as_uri()))
    source = source.replace("READY", json.dumps(json.dumps(preview())))
    node(source + script, module=True)


@pytest.mark.parametrize("kind", range(2))
@pytest.mark.parametrize("initial", ["ready", "modeless"])
def test_one_preview_then_independent_current_get(kind, initial):
    check(f"""
let count=0;const winner=ready();winner.model_availability.source_generation='later-winner';
const {{owner,seen}}=fixture({{request:async(path,options={{}})=>{{seen.requests.push({{path,options}});count++;return reply(count===1?{initial}():count===2?ready():winner)}}}});
await owner.refreshCurrent();seen.requests=[];seen.published=[];
const input=kinds[{kind}],before=JSON.stringify(input);await owner.submitPreview(input.path,input.body);
assert.equal(JSON.stringify(input),before);assert.equal(seen.requests.length,2);
assert.equal(seen.requests[0].path,input.path);assert.equal(JSON.stringify(seen.requests[0].options.body),JSON.stringify(input.body));
assert.equal(seen.requests[1].path,'/api/state');assert.equal(seen.requests[1].options.body,undefined);
assert.equal(seen.published.length,1);assert.equal(seen.published[0].value.model_availability.source_generation,'later-winner');
assert.equal(seen.notices.at(-1).outcome,'ACKNOWLEDGED');assert.equal(seen.notices.at(-1).requestId,UUID);
assert.equal(seen.busy.at(-1),false);owner.dispose();
""")


@pytest.mark.parametrize("code,outcome", [("SELECTION_COMMIT_UNCONFIRMED", "ACK_UNCONFIRMED"),
    ("SELECTION_COMMITTED_CLEANUP_UNCONFIRMED", "COMMITTED_CLEANUP_UNCONFIRMED"),
    ("CLIENT_UNCONFIRMED", "ACK_UNCONFIRMED"), ("REGISTRY_STORAGE_UNAVAILABLE", "ACK_UNCONFIRMED"),
    ("MODEL_SOURCE_CHANGED", "REJECTED"), ("INVALID_NOTE", "REJECTED"),
    ("CLIENT_AUTH_REQUIRED", "REJECTED")])
@pytest.mark.parametrize("read_fails", [False, True])
def test_operation_outcome_survives_fresh_read_without_retry(code, outcome, read_fails):
    check(f"""
let initialized=false,posts=0,reads=0;
const {{owner,seen}}=fixture({{request:async(path,options={{}})=>{{
 if(options.body!==undefined){{posts++;throw Object.assign(Error(PRIVATE),{{code:{json.dumps(code)},requestId:UUID}})}}
 reads++;if(initialized&&{json.dumps(read_fails)})throw Object.assign(Error(PRIVATE),{{code:'SELECTION_COMMIT_UNCONFIRMED'}});return reply();}}}});
await owner.refreshCurrent();initialized=true;seen.published=[];
await owner.submitPreview(post.path,post.body);assert.equal(posts,1);assert.equal(reads,2);
assert.equal(seen.notices.at(-1).outcome,{json.dumps(outcome)});assert.equal(seen.notices.at(-1).requestId,UUID);
assert.equal(seen.published.length,{0 if read_fails else 1});assert(!JSON.stringify(seen.notices).includes(PRIVATE));
if({json.dumps(read_fails)}){{assert.equal(owner.beginNumericalAction(),null);await owner.submitPreview(post.path,post.body);assert.equal(posts,1)}}
owner.dispose();
""")


@pytest.mark.parametrize("mutation", ["delete x.model_availability", "x.profile_params=null",
    "x.profile_params.Si=true", "x.model_availability.twin_id='selected'", "x.model_availability.twin_version=true",
    "x.model_availability.source_generation=''", "x.cardiac=null", "x.metabolic.glucose=[]",
    "x.model_availability.preparation_available=false", "x.error=PRIVATE", "x.human=[]"])
def test_invalid_ack_never_publishes_as_current(mutation):
    check(f"""
const x=ready();{mutation};let calls=0;
const {{owner,seen}}=fixture({{request:async()=>{{calls++;return reply(calls===2?x:ready())}}}});
await owner.refreshCurrent();seen.published=[];await owner.submitPreview(post.path,post.body);
assert.equal(calls,3);assert.equal(seen.notices.at(-1).outcome,'ACK_UNCONFIRMED');
assert.equal(seen.published.length,1);assert.equal(seen.published[0].value.profile,'technical-preview');owner.dispose();
""")


@pytest.mark.parametrize("bad", ["NaN", "Infinity", "undefined", "()=>1", "1n", "Symbol('x')",
    "new Date(0)", "new Map()", "new Set()", "new Array(2)", "Object.create({x:1})"])
def test_json_domain_rejected_before_serialization_and_dispatch(bad):
    check(f"""
const {{owner,seen}}=fixture();await owner.refreshCurrent();seen.requests=[];
await owner.submitPreview('/api/stimulate',{{kind:'life_system',params:{{genome:{bad}}}}});
assert.equal(seen.requests.length,0);assert.equal(seen.notices.at(-1).code,'CLIENT_INVALID');owner.dispose();
""")


def test_cycles_getters_depth_and_plain_json_preserved():
    check("""
const {owner,seen}=fixture();await owner.refreshCurrent();seen.requests=[];
const cycle={};cycle.x=cycle;let invoked=0;const getter={get x(){invoked++;return 3}};
let deep={};for(let i=0;i<65;i++)deep={x:deep};
for(const genome of [cycle,getter,deep])await owner.submitPreview('/api/stimulate',{kind:'life_system',params:{genome}});
assert.equal(invoked,0);assert.equal(seen.requests.length,0);
const body={kind:'life_system',params:{genome:{x:[null,true,false,-1,.25,'é']}}};
await owner.submitPreview('/api/stimulate',body);assert.equal(JSON.stringify(seen.requests[0].options.body),JSON.stringify(body));owner.dispose();
""")


@pytest.mark.parametrize("failure", ["clearCurrent", "publishCurrent", "publishNotice", "setBusy"])
def test_ui_callback_failure_never_strands_owner_or_dispatches_after_failed_clear(failure):
    check(f"""
let broken=false,posts=0,reads=0;const fn={json.dumps(failure)};
const options={{request:async(path,o={{}})=>{{o.body===undefined?reads++:posts++;return reply()}}}};
options[fn]=()=>{{if(broken)throw Error(PRIVATE)}};
const {{owner,seen}}=fixture(options);await owner.refreshCurrent();broken=true;
await owner.submitPreview(post.path,post.body);
if(fn==='clearCurrent'||fn==='setBusy')assert.equal(posts,0);
broken=false;await owner.refreshCurrent();const token=owner.beginNumericalAction();assert(token!==null,'owner stranded busy');owner.finishNumericalAction(token);
assert(!JSON.stringify(seen.notices).includes(PRIVATE));owner.dispose();
""")


def test_busy_epoch_disposal_reopen_and_stale_finally():
    check("""
const d=deferred();let posts=0,reads=0;
const {owner,seen}=fixture({request:async(path,o={})=>{if(o.body!==undefined){posts++;return d.promise}reads++;return reply()}});
await owner.refreshCurrent();const old=owner.captureEpoch();
const running=owner.submitPreview(post.path,post.body);await tick();assert.equal(posts,1);
await owner.submitPreview(post.path,post.body);assert.equal(posts,1);assert.equal(owner.beginNumericalAction(),null);assert(!owner.isCurrent(old));
owner.dispose();const count=seen.published.length;await owner.refreshCurrent();assert.equal(reads,1);
await owner.reopen();assert.equal(reads,2);const current=owner.beginNumericalAction();assert(current!==null);
d.resolve(reply());await running;assert.equal(posts,1);assert.equal(reads,2);assert.equal(seen.published.length,count+1);
assert(owner.isCurrent(current));assert.equal(seen.busy.at(-1),true,'stale finally cleared new operation');
owner.finishNumericalAction(current);owner.dispose();await owner.reopen();await owner.reopen();assert.equal(reads,3);owner.dispose();
""")


def test_old_state_read_cannot_override_new_preview():
    check("""
const d=deferred();let reads=0;
const {owner,seen}=fixture({request:async(path,o={})=>{if(o.body!==undefined)return reply();reads++;return reads===2?d.promise:reply()}});
await owner.refreshCurrent();const old=owner.refreshCurrent();await tick();
await owner.submitPreview(post.path,post.body);d.resolve(reply(modeless()));await old;
assert.equal(seen.published.at(-1).value.model_availability.state,'READY');owner.dispose();
""")


def test_pending_refresh_denies_programmatic_numerical_action():
    check("""
const d=deferred();let reads=0;
const {owner,seen}=fixture({request:async()=>++reads===1?reply():d.promise});
await owner.refreshCurrent();const refreshing=owner.refreshCurrent();await tick();
assert.equal(owner.beginNumericalAction(),null,'pending read admitted a numerical writer');
d.resolve(reply());await refreshing;const current=owner.beginNumericalAction();assert(current);
owner.finishNumericalAction(current);owner.dispose();
""")


@pytest.mark.parametrize("same", [False, True])
def test_note_extraction_belongs_only_to_matching_ack_generation(same):
    # L0-R15: the service refuses every note, so no note acknowledgment or extraction
    # exists to publish, whatever the generation of the fresh read.
    check(f"""
let calls=0;const winner=ready();if(!{json.dumps(same)})winner.model_availability.source_generation='later';
const {{owner,seen}}=fixture({{request:async()=>{{if(++calls===2)throw Object.assign(Error('refused'),{{code:'CLINICAL_NOTE_NOT_ACCEPTED',requestId:UUID}});return reply(winner)}}}});
await owner.refreshCurrent();await owner.submitPreview('/api/ingest_note',{{text:PRIVATE}});
const published=seen.published.at(-1);assert.equal(published.value.extracted,undefined);
assert.equal(published.extra?.extracted,null);assert.equal(seen.notices.at(-1).outcome,'REJECTED');
assert.equal(seen.notices.at(-1).code,'CLINICAL_NOTE_NOT_ACCEPTED');owner.dispose();
""")


@pytest.mark.parametrize("expected", [None, True, False, 0, 202, "200"])
def test_shared_expected_status_invalid_before_transport(expected):
    check(f"""let calls=0;await assert.rejects(selectionRequest('/api/state',{{expectedStatus:{json.dumps(expected)},fetcher:async()=>{{calls++;return http({{}})}}}}));assert.equal(calls,0);""")


@pytest.mark.parametrize("status", [200, 201])
def test_named_browser_transport_exact_status_redirect_policy_and_current_uuid(status):
    check(f"""
let calls=0;const options={{body:post.body,fetcher:async(path,o)=>{{calls++;assert.equal(o.redirect,'error');assert.equal(o.cache,'no-store');assert.equal(o.method,'POST');return http(ready(),{status})}}}};
if({status}===200){{const x=await requestLegacyPreview(post.path,options);assert.equal(x.requestId,UUID)}}
else await assert.rejects(requestLegacyPreview(post.path,options),e=>e.code==='CLIENT_UNCONFIRMED'&&e.requestId===UUID);
assert.equal(calls,1);
let defaults=await selectionRequest('/api/other',{{body:{{}},fetcher:async()=>http({{}},201)}});assert.deepEqual(Object.keys(defaults.payload),[]);
""")


@pytest.mark.parametrize("code", ["INVALID_NOTE", "INVALID_INTERVENTION", "MODEL_SOURCE_CHANGED"])
def test_named_browser_transport_safe_new_codes(code):
    check(f"""await assert.rejects(requestLegacyPreview(post.path,{{body:post.body,fetcher:async()=>http({{code:{json.dumps(code)},error:PRIVATE}},422)}}),e=>e.code==={json.dumps(code)}&&e.requestId===UUID&&!e.message.includes(PRIVATE));""")


@pytest.mark.parametrize("size", [2_000_000, 2_000_001])
def test_named_browser_request_exact_byte_cap(size):
    check(f"""
let calls=0;const fixed=JSON.stringify({{kind:'life_system',params:{{mode:'custom',id:''}}}}).length;
const body={{kind:'life_system',params:{{mode:'custom',id:'x'.repeat({size}-fixed)}}}};const options={{body,fetcher:async(path,o)=>{{calls++;assert.equal(new TextEncoder().encode(o.body).length,{size});return http(ready())}}}};
if({size}>2000000){{await assert.rejects(requestLegacyPreview('/api/stimulate',options));assert.equal(calls,0)}}
else{{await requestLegacyPreview('/api/stimulate',options);assert.equal(calls,1)}}
""")


@pytest.mark.parametrize("method", ["GET", "POST"])
@pytest.mark.parametrize("phase", ["fetch", "body", "after_body"])
def test_named_browser_deadline_covers_transport_and_parse(method, phase):
    check(r"""
const originalTimer=globalThis.setTimeout,originalPerformance=globalThis.performance;
let calls=0,cancelled=0;const durations=[];let clock=0;
globalThis.performance={now:()=>clock};
globalThis.setTimeout=(fn,ms)=>{durations.push(ms);return originalTimer(fn,5)};
const options={fetcher:async()=>{
 calls++;
 if(PHASE==='fetch')return new Promise(()=>{});
 if(PHASE==='body')return new Response(new ReadableStream({
  pull(){return new Promise(()=>{})},cancel(){cancelled++}
 }));
 let done=false;
 return {ok:true,status:200,headers:new Headers({'X-Request-ID':UUID}),body:{getReader:()=>({
  read:async()=>{if(done){clock=100000;return {done:true}}done=true;return {done:false,value:new TextEncoder().encode('{}')}},
  releaseLock(){},cancel(){cancelled++}
 })}};
}};
if(METHOD==='POST')options.body=post.body;
try{await assert.rejects(requestLegacyPreview(PATH,options),e=>e.code===CODE);}
finally{globalThis.setTimeout=originalTimer;globalThis.performance=originalPerformance}
assert.equal(calls,1);assert.deepEqual(durations,[TIMEOUT]);if(PHASE==='body')assert.equal(cancelled,1);
""".replace("PHASE", json.dumps(phase)).replace("METHOD", json.dumps(method))
          .replace("PATH", json.dumps('/api/state' if method == 'GET' else '/api/stimulate'))
          .replace("CODE", json.dumps('CLIENT_RESPONSE' if method == 'GET' else 'CLIENT_UNCONFIRMED'))
          .replace("TIMEOUT", str(20000 if method == 'GET' else 60000)))


@pytest.mark.parametrize("size", [2_000_000, 2_000_001])
def test_named_browser_response_byte_limit(size):
    check(f"""
const raw='{{"x":"'+'x'.repeat({size}-8)+'"}}';let calls=0;
const options={{body:post.body,fetcher:async()=>{{calls++;return http(raw)}}}};
if({size}>2000000)await assert.rejects(requestLegacyPreview(post.path,options));
else assert.equal((await requestLegacyPreview(post.path,options)).payload.x.length,{size}-8);
assert.equal(calls,1);
""")


@pytest.mark.parametrize("raw", ['{"x":1,"x":2}', '{"x":NaN}', '{"x":1e999}', '[]'])
def test_named_browser_strict_json_not_weakened(raw):
    check(f"await assert.rejects(requestLegacyPreview(post.path,{{body:post.body,fetcher:async()=>http({json.dumps(raw)})}}),e=>e.code==='CLIENT_UNCONFIRMED'&&e.requestId===UUID);")


@pytest.mark.parametrize("scenario", ["base_error", "modeless_life", "failed_clear", "unavailable_clear", "late_biology",
    "stim_failure", "run_failure", "stim_stale", "run_stale", "frame_after_clear", "bfcache",
    "feedback_preview_pending", "feedback_unknown", "feedback_refresh", "feedback_modeless",
    "feedback_numerical_pending", "feedback_numerical_failure", "feedback_render_failure", "feedback_source"])
def test_actual_legacy_controller_integrates_owner_and_clears_real_nodes(scenario):
    # Execute actual existing handlers/clear/render code, not a second UI model.
    check(r"""
import fs from 'node:fs';import vm from 'node:vm';
const lib=new URL('./lib/',new URL('file://'+INDEX));
const {parseStrictJSONObject}=await import(new URL('strict_json.js',lib));
const {modelAvailability}=await import(new URL('biological_projection.js',lib));
const html=fs.readFileSync(INDEX,'utf8'),nodes=new Map(),baseButtons=[];let posts=0,reads=0;
class Element{constructor(id){this.id=id;this.textContent='OLD_NUMBER';this.innerHTML='OLD_NUMBER';this.title='OLD_EVIDENCE';this.className='prov-measured';this.value='';this.style={};this.dataset={};this.disabled=false;this.width=100;this.height=100;this.clientWidth=100;this.attrs={fill:'OLD_NUMBER'};this.handlers={};this.classes=new Set(['warn']);this.classList={add:k=>this.classes.add(k),remove:k=>this.classes.delete(k),toggle:(k,b)=>b?this.classes.add(k):this.classes.delete(k),contains:k=>this.classes.has(k)};}setAttribute(k,v){this.attrs[k]=v}removeAttribute(k){delete this.attrs[k]}addEventListener(k,v){this.handlers[k]=v}removeEventListener(k,v){if(this.handlers[k]===v)delete this.handlers[k]}replaceChildren(){this.innerHTML='';this.textContent=''}append(){}getContext(){return new Proxy({clearRect:()=>{this.cleared=true}},{get:(o,k)=>o[k]||(()=>{})})}querySelector(s){return el(this.id+' '+s)}querySelectorAll(){return []}}
function el(id){if(!nodes.has(id))nodes.set(id,new Element(id));return nodes.get(id)}
for(const name of ['healthy','type-2-diabetes']){const b=el('base-'+name);b.dataset.b=name;baseButtons.push(b)}
const elements=ids=>ids.map(el),numeric=elements(['legacy-run-experiment','legacy-reset-model','legacy-patch-virtual','legacy-patch-diabetic','legacy-patch-healthy']);
const document={getElementById:el,querySelector:s=>el(s.replace(/^#/,'')),querySelectorAll:s=>s==='#baseSeg button'?baseButtons:s.includes('legacy')?numeric:[],createElement:tag=>new Element(tag),body:{appendChild(){}},addEventListener(){}};
const d=deferred(),previewPending=deferred(),window={handlers:{},addEventListener(k,v){this.handlers[k]=v},removeEventListener(){}};let biologyReads=0;
const state=SCENARIO==='modeless_life'?modeless():ready();let next=state;
const context={document,window,console:{error(){throw Error('raw render logging')}},requestAnimationFrame(){},setTimeout,clearTimeout,AbortController,TextEncoder,performance,devicePixelRatio:1,
 selectionRequest,parseStrictJSONObject,modelAvailability,requestLegacyPreview:async(path,options={})=>{if(options.body!==undefined){posts++;if(SCENARIO==='base_error')throw Object.assign(Error(PRIVATE),{code:'SELECTION_COMMIT_UNCONFIRMED',requestId:UUID});if(['feedback_preview_pending','feedback_unknown'].includes(SCENARIO))return previewPending.promise;return reply(context.realmCopy(ready()))}reads++;if(['base_error','feedback_unknown'].includes(SCENARIO)&&posts)throw Object.assign(Error(PRIVATE),{code:'SELECTION_COMMIT_UNCONFIRMED'});return reply(context.realmCopy(next))},fetch:async()=>++biologyReads===1?d.promise:{ok:true,json:async()=>({organs:[]})}};
vm.createContext(context);
// The real browser's controller, owner and JSON responses share one realm.
// Cross-context prototypes are not JSON-domain exceptions in production.
context.realmCopy=vm.runInContext('(value)=>JSON.parse(JSON.stringify(value))',context);
const ownerSource=fs.readFileSync(new URL('legacy_preview_recovery.js',lib),'utf8').replace(/^import .*;\n/gm,'').replace(/^export /gm,'');
const requestStub=context.requestLegacyPreview;
vm.runInContext(ownerSource,context);
context.requestLegacyPreview=requestStub;
const prefix=html.split('<script>\nconst $=')[1].split('// ===== Experiment / perturbation builder =====')[0];
assert(prefix,'actual inline script absent');vm.runInContext('const $='+prefix,context);
const render=html.split('function render(){')[1].split('// --- reactive metabolic curves ---')[0];
vm.runInContext('let LASTRUN={old:true};let EXPERIMENTS=[{id:"frozen-history"}];function renderExtract(ex){document.getElementById("noteExtract").textContent=ex?"EXTRACT":""}function drawMetab(){}function paintBody(){}function render(){'+render,context);
const runVia='async function runVia('+html.split('async function runVia(')[1].split('function logExperiment(')[0];
vm.runInContext(runVia+'function logExperiment(){throw Error("history must not append on failed or stale response")}function focusReadout(){}',context);
await vm.runInContext('initializeLegacyPreviewRecovery({createLegacyPreviewRecovery,requestLegacyPreview})',context);
if(SCENARIO.startsWith('feedback_')){
 const banner=el('__banner'),originalHistory=vm.runInContext('EXPERIMENTS',context);
 const labels=()=>['legacy-cardiac-state','legacy-cardiac-provenance','legacy-cardiac-time'].map(id=>el(id).textContent);
 const computed=['Calculated response','computed','calculated beat · milliseconds'];
 const unavailable=['No current trace','unavailable','no current trace'];
 const pending=['Update pending','pending','update pending'];
 assert.deepEqual(labels(),computed,'READY cardiac source not labeled as calculated');
 vm.runInContext("showBanner('AUTHORED previous compound error','err')",context);
 if(['feedback_preview_pending','feedback_unknown'].includes(SCENARIO)){
  const request=baseButtons[0].onclick();await tick();assert.equal(posts,1);assert.equal(reads,1);
  assert.equal(banner.hidden,true);assert.equal(banner.textContent,'');assert.deepEqual(labels(),pending);
  previewPending.resolve(reply(context.realmCopy(ready())));await request;
  assert.equal(posts,1);assert.equal(reads,2);
  assert.deepEqual(labels(),SCENARIO==='feedback_unknown'?unavailable:computed);
  assert.equal(banner.hidden,true);assert.equal(banner.textContent,'');
 }else if(['feedback_refresh','feedback_modeless','feedback_render_failure'].includes(SCENARIO)){
  if(SCENARIO==='feedback_modeless')next=modeless();
  if(SCENARIO==='feedback_render_failure')vm.runInContext('drawMetab=()=>{throw Error("AUTHORED_RENDER_FAILURE")}',context);
  await vm.runInContext('load()',context);assert.equal(posts,0);assert.equal(reads,2);
  assert.deepEqual(labels(),SCENARIO==='feedback_refresh'?computed:unavailable);
  assert(!banner.textContent.includes('previous compound error'));
  if(SCENARIO==='feedback_modeless'){assert.equal(banner.hidden,false);assert(banner.textContent.includes('MODEL_BINDING_REQUIRED'))}
 }else if(SCENARIO==='feedback_numerical_pending'){
  const token=vm.runInContext('legacyPreviewRecovery.beginNumericalAction()',context);assert(token);
  assert.deepEqual(labels(),pending);assert.equal(banner.hidden,true);assert.equal(banner.textContent,'');
  vm.runInContext("showBanner('AUTHORED current error','err');updateLegacyControls(true)",context);
  assert.equal(banner.textContent,'AUTHORED current error');assert.equal(banner.hidden,false);
  vm.runInContext('legacyPreviewRecovery',context).finishNumericalAction(token);
  assert.deepEqual(labels(),computed);assert.equal(banner.textContent,'AUTHORED current error');assert.equal(banner.hidden,false);
  assert.equal(posts,0);assert.equal(reads,1);
 }else if(SCENARIO==='feedback_numerical_failure'){
  let numericalPosts=0;context.fetch=async()=>{numericalPosts++;throw Error(PRIVATE)};
  await vm.runInContext("stim('meal',{grams:20})",context);
  assert.deepEqual(labels(),unavailable);assert.equal(banner.hidden,false);
  assert(banner.textContent.startsWith('Action not confirmed.'));assert(!banner.textContent.includes('previous compound error'));
  assert.equal(numericalPosts,1);assert.equal(posts,0);
 }else{
  vm.runInContext("S.provenance={glucose:'measured-technical-fixture',hr:'measured-technical-fixture'};updateLegacyControls()",context);
  assert.deepEqual(labels(),computed);assert(!el('legacy-cardiac-provenance').title.includes('measured'));
  for(const change of ['S.model_availability=null','S.model_availability.state="UNAVAILABLE"','S.cardiac=null',
    'S.cardiac.t_ms=[]','S.cardiac.v=[-80]','S.cardiac.cai=[.0001,Infinity]']){
   context.original=context.realmCopy(ready());vm.runInContext('S=original;'+change+';updateLegacyControls()',context);
   assert.deepEqual(labels(),unavailable,change);
  }
  assert.equal(posts,0);assert.equal(reads,1);
 }
 assert.equal(nodes.get('__banner'),banner);assert.equal(vm.runInContext('EXPERIMENTS',context),originalHistory);
 assert.equal(vm.runInContext('EXPERIMENTS.length',context),1);
}else if(SCENARIO==='bfcache'){
 const handlers={...window.handlers};
 await vm.runInContext('initializeLegacyPreviewRecovery({createLegacyPreviewRecovery,requestLegacyPreview})',context);
 assert.equal(reads,1);assert.equal(window.handlers.pagehide,handlers.pagehide);assert.equal(window.handlers.pageshow,handlers.pageshow);
 window.handlers.pagehide();await vm.runInContext('load()',context);assert.equal(reads,1);assert.equal(vm.runInContext('S',context),null);
 window.handlers.pageshow({persisted:true});await tick();assert.equal(reads,2);assert(vm.runInContext('S',context));
 window.handlers.pageshow({persisted:true});await tick();assert.equal(reads,2);assert.equal(posts,0);
 window.handlers.pagehide();window.handlers.pageshow({persisted:true});await tick();assert.equal(reads,3);assert.equal(posts,0);
}else if(SCENARIO==='frame_after_clear'){
 const loops='let MT='+html.split('let MT=')[1].split('function drawCell(')[0];
 context.draws=0;vm.runInContext(loops+'drawMetab=()=>draws++;function drawCell(){draws++}function drawTrace(){draws++}',context);
 el('o-cardiac').setAttribute('transform','translate(105,104) scale(0.123)');
 window.handlers.pagehide();vm.runInContext('metabLoop(1234);beat(1234)',context);
 assert.equal(context.draws,0);assert.equal(vm.runInContext('S',context),null);
 assert.deepEqual([el('o-cardiac').attrs.transform,el('o-metabolic').attrs.fill],['translate(105,104)','#728b88']);
 assert.equal(el('o-neural').attrs.fill,'#728b88');assert.equal(el('o-cardiac path').attrs.fill,'#728b88');
 assert.equal(vm.runInContext('EXPERIMENTS.length',context),1);
}else if(SCENARIO.endsWith('_failure')||SCENARIO.endsWith('_stale')){
 const action=SCENARIO.startsWith('stim_')?"stim('meal',{grams:20})":"runVia('/api/stimulate',{kind:'meal',params:{grams:20}},{readout:'metabolic'})";
 let numericalPosts=0;const oldReply=deferred();
 context.fetch=async()=>{numericalPosts++;return SCENARIO.endsWith('_stale')?oldReply.promise:{ok:true,json:async()=>context.realmCopy(ready())}};
 if(SCENARIO.endsWith('_failure')){
  vm.runInContext('drawMetab=()=>{document.getElementById("mMean").textContent="PARTIAL_VALUE";throw Error("AUTHORED_RENDER_FAILURE")}',context);
  await vm.runInContext(action,context);
  assert.equal(vm.runInContext('S',context),null);assert.equal(vm.runInContext('LASTRUN',context),null);
  assert.equal(vm.runInContext('legacyPreviewRecovery.beginNumericalAction()',context),null,'failed renderer retained READY permission');
  assert(!el('mMean').textContent.includes('PARTIAL_VALUE'));assert(!el('app').classList.contains('busy'));
  assert(numeric.every(e=>e.disabled));assert.equal(numericalPosts,1);assert.equal(vm.runInContext('EXPERIMENTS.length',context),1);
 }else{
  const oldAction=vm.runInContext(action,context);await tick();assert.equal(numericalPosts,1);
  window.handlers.pagehide();await vm.runInContext('legacyPreviewRecovery.reopen()',context);
  const currentState=vm.runInContext('S',context),currentTicket=vm.runInContext('legacyPreviewRecovery.beginNumericalAction()',context);
  assert(currentTicket);oldReply.resolve({ok:true,json:async()=>context.realmCopy(modeless())});await oldAction;
  assert.equal(vm.runInContext('S',context),currentState);assert(el('app').classList.contains('busy'),'stale finally released a later owner');
  assert(vm.runInContext('legacyPreviewRecovery',context).isCurrent(currentTicket));
  vm.runInContext('legacyPreviewRecovery',context).finishNumericalAction(currentTicket);assert.equal(numericalPosts,1);
 }
}else if(SCENARIO==='base_error'){
 await baseButtons[0].onclick();assert.equal(posts,1);assert.equal(reads,2);assert.equal(vm.runInContext('S',context),null);
 assert(!baseButtons[0].classList.contains('on'));assert(!el('app').classList.contains('busy'));
 for(const id of ['mVpeak','mMean','mPeak','humanInfo','organReadout','noteExtract','patchStatus'])assert(!el(id).textContent.includes('OLD_NUMBER')&&!el(id).innerHTML.includes('OLD_NUMBER'),id);
 assert.equal(vm.runInContext('LASTRUN',context),null);assert.equal(vm.runInContext('EXPERIMENTS.length',context),1);
}else if(SCENARIO==='modeless_life'){
 await vm.runInContext("stim('life_system',{mode:'carrier'})",context);assert.equal(posts,1);
}else if(SCENARIO==='failed_clear'){
 const original=el('trace').getContext;el('trace').getContext=()=>{throw Error(PRIVATE)};
 await baseButtons[0].onclick();assert.equal(posts,0);assert(!el('app').classList.contains('busy'));el('trace').getContext=original;
}else if(SCENARIO==='unavailable_clear'){
 next=modeless();await vm.runInContext('load()',context);
 assert.equal(vm.runInContext('S.model_availability.state',context),'UNAVAILABLE');assert(numeric.every(e=>e.disabled));
 assert(!el('noteExtract').textContent.includes('OLD_NUMBER'));assert(!el('metabProvChip').className.includes('measured'));
}else{
 const body=html.split('async function paintBody(){')[1].split('// ===== main render =====')[0];
 // Read to the next function rather than synthesize a competing body renderer.
 const full='async function paintBody(){'+body.split('function render(){')[0];
 vm.runInContext(full,context);const pending=vm.runInContext('paintBody()',context);
 await baseButtons[0].onclick();await tick();const before=el('organReadout').innerHTML;
 d.resolve({ok:true,json:async()=>({organs:[{id:'heart',name:'OLD_PERSON',cell:{state:'executed'},metric:'rate',value:999}]})});await pending;
 assert.equal(el('organReadout').innerHTML,before);assert(!el('organReadout').innerHTML.includes('OLD_PERSON'));
}
assert(!JSON.stringify([...nodes.values()].map(x=>[x.textContent,x.innerHTML])).includes(PRIVATE));
""".replace("INDEX", json.dumps(str(CONSOLE / "index.html"))).replace("SCENARIO", json.dumps(scenario)))
