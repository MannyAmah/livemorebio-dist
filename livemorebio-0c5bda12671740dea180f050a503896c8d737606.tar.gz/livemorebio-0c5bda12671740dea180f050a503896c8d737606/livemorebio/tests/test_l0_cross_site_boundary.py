"""API-4: technical ASGI requests and reference bytes; no listening sockets."""
from __future__ import annotations

import io
import urllib.request

import pytest
from fastapi.testclient import TestClient

from livemorebio import stack_transport
from livemorebio.aegle import rcache, server
from livemorebio.anatomy import meshes
from livemorebio.cendos import service as cendos
from livemorebio.engines import drug_targets, metabolism
from livemorebio.life_system import service as life


ORIGIN = "http://127.0.0.1:19874"
CROSS_SITE = {"Sec-Fetch-Site": "cross-site"}
NAVIGATION = {**CROSS_SITE, "Sec-Fetch-Mode": "navigate", "Sec-Fetch-Dest": "document"}
REFUSAL = {"code": "CROSS_SITE_REQUEST_REFUSED", "error": "Cross-site browser requests are not allowed."}
CONSOLE_PATHS = ("/", "/legacy", "/twins", "/cohorts", "/biology", "/patch",
                 "/cendos", "/adapters", "/research")


@pytest.fixture
def reference_effects(monkeypatch, tmp_path):
    """Record fetches and use a real isolated cache to detect route side effects."""
    calls = []
    cache = tmp_path / "technical-reference-cache"
    monkeypatch.setattr(rcache, "CACHE_DIR", str(cache))
    monkeypatch.setenv("LIVEMORE_CENDOS_URL", "http://127.0.0.1:19875")
    monkeypatch.setenv("LIVEMORE_CENDOS_IDENTITY_AUTHORITY", "http://127.0.0.1:19875")

    def resolve(name):
        calls.append(("chembl", name))
        return {"resolved": True, "targets": [], "chembl_id": "technical-reference"}

    def relay(url, **kwargs):
        calls.append(("cendos", url))
        assert not kwargs.get("headers"), "The reference relay remains bearer-free."
        return stack_transport.StackResponse(200, "OK", (), b'{"resolved":true,"fixture":"technical"}')

    def pubchem(url, **kwargs):
        calls.append(("pubchem", url))
        return io.BytesIO(b'{"PropertyTable":{"Properties":[{"MolecularFormula":"technical"}]}}')

    def anatomy(key):
        calls.append(("anatomy", key))
        cache.mkdir(exist_ok=True)
        (cache / "technical.glb").write_bytes(b"technical-display-bytes")
        return b"technical-display-bytes", {"source": "technical", "license": "technical", "sha256": "technical"}

    monkeypatch.setattr(drug_targets, "resolve_drug", resolve)
    monkeypatch.setattr(drug_targets, "resolve_bioactive", resolve)
    monkeypatch.setattr(metabolism, "load_recon3d", lambda: object())
    monkeypatch.setattr(stack_transport, "request", relay)
    monkeypatch.setattr(urllib.request, "urlopen", pubchem)
    monkeypatch.setattr(meshes, "read_asset", anatomy)
    return calls, cache


@pytest.mark.parametrize("app,path,source,writes", [
    (server.app, "/api/resolve?compound=technical-reference&refresh=true", "chembl", True),
    # L0-R16: a compound term of the product's vocabulary, so the egress check admits the lookup.
    (server.app, "/api/cendos/compound?name=metformin", "cendos", False),
    (server.app, "/assets/anatomy/liver.glb", "anatomy", True),
    (cendos.app, "/compound?name=metformin", "pubchem", False),
], ids=["resolve-refresh", "cendos-relay", "anatomy", "pubchem"])
@pytest.mark.parametrize("headers", [CROSS_SITE, NAVIGATION], ids=["fetch", "navigation"])
def test_cross_site_reference_routes_refuse_before_fetch_or_cache(app, path, source, writes, headers,
                                                                reference_effects):
    calls, cache = reference_effects
    client = TestClient(app, base_url=ORIGIN)
    response = client.get(path, headers=headers)
    assert response.status_code == 403
    assert response.json() == REFUSAL
    assert response.headers["cache-control"] == "no-store"
    assert response.headers["x-content-type-options"] == "nosniff"
    assert calls == [] and not cache.exists()

    # The exact routes still do their work for the console and non-browser clients.
    for accepted in ({"Sec-Fetch-Site": "same-origin"}, {}):
        response = client.get(path, headers=accepted)
        assert response.status_code == 200, response.text
        assert calls[-1][0] == source
    assert len(calls) == 2
    assert cache.exists() is writes


@pytest.mark.parametrize("path", CONSOLE_PATHS)
def test_only_top_level_console_navigation_is_exempt(path):
    client = TestClient(server.app, base_url=ORIGIN)
    assert client.get(path, headers=CROSS_SITE).status_code == 403
    for headers in (NAVIGATION, {"Sec-Fetch-Site": "same-origin"}, {}):
        response = client.get(path, headers=headers)
        assert response.status_code == 200
        assert response.headers["content-type"].startswith("text/html")
        assert "set-cookie" not in response.headers


@pytest.mark.parametrize("method,headers", [
    ("GET", {**NAVIGATION, "Sec-Fetch-Dest": "iframe"}),
    ("GET", {**NAVIGATION, "Sec-Fetch-Mode": "cors"}),
    ("GET", {**CROSS_SITE, "Sec-Fetch-Mode": "navigate"}),
    ("POST", NAVIGATION),
    ("OPTIONS", NAVIGATION),
])
def test_console_exception_requires_get_navigation_document(method, headers):
    response = TestClient(server.app, base_url=ORIGIN).request(method, "/", headers=headers)
    assert response.status_code == 403
    assert response.json() == REFUSAL
    assert response.headers["cache-control"] == "no-store"


@pytest.mark.parametrize("app", [server.app, life.app, cendos.app], ids=["aegle", "life", "cendos"])
@pytest.mark.parametrize("method", ["GET", "POST", "OPTIONS"])
def test_all_service_boundaries_refuse_cross_site_before_routing(app, method):
    client = TestClient(app, base_url=ORIGIN)
    response = client.request(method, "/technical-missing-route", headers=NAVIGATION)
    assert response.status_code == 403
    assert response.json() == REFUSAL
    assert response.headers["cache-control"] == "no-store"
    assert client.get("/technical-missing-route", headers={"Sec-Fetch-Site": "same-origin"}).status_code == 404
    assert client.get("/technical-missing-route").status_code == 404


@pytest.mark.parametrize("values", [("cross-site", "same-origin"), ("same-origin", "cross-site")])
def test_duplicate_fetch_site_cannot_hide_cross_site(values):
    response = TestClient(server.app, base_url=ORIGIN).get(
        "/", headers=[("Sec-Fetch-Site", value) for value in values])
    assert response.status_code == 403
    assert response.json() == REFUSAL


@pytest.mark.parametrize("path", ["/%62iology", "/biology/", "/console/connect"])
def test_navigation_exception_does_not_expand_to_other_console_targets(path):
    response = TestClient(server.app, base_url=ORIGIN).get(path, headers=NAVIGATION,
                                                         follow_redirects=False)
    assert response.status_code == 403
    assert response.json() == REFUSAL
    assert "location" not in response.headers


@pytest.mark.parametrize("duplicate", ["Sec-Fetch-Mode", "Sec-Fetch-Dest"])
def test_duplicate_navigation_metadata_does_not_grant_exception(duplicate):
    headers = list(NAVIGATION.items()) + [(duplicate, NAVIGATION[duplicate])]
    response = TestClient(server.app, base_url=ORIGIN).get("/", headers=headers)
    assert response.status_code == 403
    assert response.json() == REFUSAL


def test_pubchem_name_is_one_encoded_path_segment(reference_effects):
    calls, _cache = reference_effects
    name = "technical/../name?fragment#"
    # L0-R16: the request Cendos would build keeps the name one path segment, and a name outside the
    # compound vocabulary is refused by the egress check before any request.
    assert cendos.compound_lookup_url(name) == ("https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/"
        "technical%2F..%2Fname%3Ffragment%23/property/MolecularFormula,MolecularWeight,IUPACName/JSON")
    response = TestClient(cendos.app, base_url=ORIGIN).get("/compound", params={"name": name})
    assert response.status_code == 422 and response.json()["code"] == "EGRESS_VALUE_NOT_ALLOWED"
    assert calls == []


def test_console_exchange_refuses_cross_site_without_spending_code_and_manual_connect_works(monkeypatch):
    token = "technical-cross-site-console-token"
    monkeypatch.setenv("LIVEMORE_API_TOKEN", token)
    client = TestClient(server.app, base_url=ORIGIN, client=("127.0.0.1", 45678))
    bearer = {"Authorization": f"Bearer {token}"}
    ordinary = client.post("/api/session/code", headers=bearer)
    assert ordinary.status_code == 200
    code = ordinary.json()["code"]

    # Assert the supplied metadata contract; this does not simulate or claim
    # which Fetch Metadata a particular browser sends from a file page.
    refused = client.post("/api/session/exchange", data={"code": code},
                          headers={**NAVIGATION, "Origin": "null"})
    assert refused.status_code == 403 and refused.json() == REFUSAL
    assert refused.headers["cache-control"] == "no-store"
    assert "set-cookie" not in refused.headers
    replay = client.post("/api/session/exchange", data={"code": code}, headers={"Origin": "null"})
    assert replay.status_code == 200 and "set-cookie" in replay.headers

    client.cookies.clear()
    same_origin = {"Sec-Fetch-Site": "same-origin", "Origin": ORIGIN}
    page = client.get("/console/connect", headers=same_origin)
    assert page.status_code == 200 and 'action="/api/session/exchange"' in page.text
    manual = client.post("/api/session/pair-code", headers=bearer)
    assert manual.status_code == 200
    connected = client.post("/api/session/exchange", data={"code": manual.json()["code"]},
                            headers=same_origin)
    assert connected.status_code == 200 and "set-cookie" in connected.headers
