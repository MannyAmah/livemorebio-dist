"""Owned subprocess lifetime checks; never starts conversion or product services."""
from __future__ import annotations

import fcntl
import os
from pathlib import Path
import selectors
import signal
import subprocess
import sys
import time

import pytest

from livemorebio.anatomy import atlas_reference as atlas
from ._timing import wait_seconds


PACKAGE_ROOT = str(Path(atlas.__file__).resolve().parents[2])
WORKER = """import os,sys,time
sys.path.insert(0,sys.argv[1])
from livemorebio.anatomy.atlas_reference import _child_lifetime
_child_lifetime(int(sys.argv[2]),int(sys.argv[3]),float(sys.argv[4]))
print('READY',flush=True)
while True:time.sleep(1)
"""


def ready(stream, seconds=5):
    with selectors.DefaultSelector() as selector:
        selector.register(stream, selectors.EVENT_READ)
        assert selector.select(seconds), "Owned technical subprocess did not become ready"
        return stream.readline().strip()


def lock_is_available(path):
    with path.open("rb") as stream:
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except BlockingIOError:
            return False


@pytest.mark.parametrize("reason", ["deadline", "parent_pipe_closed"])
def test_child_self_deadline_and_parent_eof_release_inherited_lock(tmp_path, reason):
    lock = tmp_path / "technical.lock"
    fd = os.open(lock, os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o600)
    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    reader, writer = os.pipe()
    child = None
    try:
        child = subprocess.Popen([sys.executable, "-I", "-B", "-c", WORKER, PACKAGE_ROOT, str(fd), str(reader),
                                  "0.5" if reason == "deadline" else "10"],
                                 pass_fds=(fd, reader), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, text=True, start_new_session=True, encoding="utf-8")
        assert ready(child.stdout) == "READY"
        os.close(fd)
        fd = -1
        assert not lock_is_available(lock), "Child must retain original lock description"
        if reason == "parent_pipe_closed":
            os.close(writer)
            writer = -1
        assert child.wait(timeout=wait_seconds(3)) == (-signal.SIGALRM if reason == "deadline" else 74)
        assert lock_is_available(lock)
        assert child.stderr.read() == ""
    finally:
        for descriptor in (fd, reader, writer):
            if descriptor >= 0:
                os.close(descriptor)
        if child is not None:
            if child.poll() is None:
                child.kill()
                child.wait(timeout=wait_seconds(3))
            child.stdout.close()
            child.stderr.close()


def test_killed_parent_cannot_release_lock_while_stopped_orphan_exists(tmp_path):
    """SIGSTOP forces a real orphan interval before the pipe watcher can run."""
    lock = tmp_path / "technical-orphan.lock"
    parent_code = """import os,sys,fcntl,subprocess,time
fd=os.open(sys.argv[1],os.O_RDWR|os.O_CREAT|os.O_EXCL,0o600)
fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
reader,writer=os.pipe()
child=subprocess.Popen([sys.executable,'-I','-B','-c',sys.argv[3],sys.argv[2],str(fd),str(reader),'10'],pass_fds=(fd,reader),stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,encoding='utf-8',start_new_session=True)
assert child.stdout.readline().strip()=='READY'
print(child.pid,flush=True)
while True:time.sleep(1)
"""
    parent = subprocess.Popen([sys.executable, "-I", "-B", "-c", parent_code, str(lock), PACKAGE_ROOT, WORKER],
                              stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                              start_new_session=True, encoding="utf-8")
    child_pid = None
    try:
        child_pid = int(ready(parent.stdout))
        os.kill(child_pid, signal.SIGSTOP)
        parent.kill()
        parent.wait(timeout=wait_seconds(3))
        assert not lock_is_available(lock), "A second install must not overlap a still-running orphan"
        os.kill(child_pid, signal.SIGCONT)
        deadline = time.monotonic() + 3
        while not lock_is_available(lock) and time.monotonic() < deadline:
            time.sleep(.02)
        assert lock_is_available(lock), "Parent-loss pipe must end owned orphan and release lock"
    finally:
        if parent.poll() is None:
            parent.kill()
            parent.wait(timeout=wait_seconds(3))
        if child_pid is not None and not lock_is_available(lock):
            os.kill(child_pid, signal.SIGKILL)
        parent.stdout.close()
        parent.stderr.close()


def test_launcher_has_no_publication_authority_and_no_environment_secrets(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "TECHNICAL SECRET NEVER SEND")
    monkeypatch.setenv("GITHUB_TOKEN", "TECHNICAL SECRET NEVER SEND")
    captured = {}
    original = subprocess.Popen
    def observed(command, **kwargs):
        captured.update(command=command, **kwargs)
        return original(command, **kwargs)
    monkeypatch.setattr(atlas, "_CHILD_BOOTSTRAP", "import os;os._exit(0)")
    monkeypatch.setattr(atlas.subprocess, "Popen", observed)
    with atlas._Cache(create=True) as cache, cache.lock() as lock:
        atlas._launch_conversion(cache, lock, ".staging-" + "a"*32)
    assert captured["command"][1:3] == ["-I", "-B"]
    assert captured["start_new_session"] is True and captured["close_fds"] is True
    assert len(captured["pass_fds"]) == 4
    assert "os.fork()" in captured["command"][4] and "_publish" not in captured["command"][4]
    assert not any("SECRET" in value for value in captured["env"].values())


@pytest.mark.parametrize("blocker", ["dns_standin", "incomplete_headers_standin", "slow_drip_standin"])
def test_fixed_source_acquisition_deadline_terminates_actual_blocked_child(tmp_path, monkeypatch, blocker):
    """Exact production launcher/OS timer, tiny in-process network stand-ins."""
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    original = subprocess.Popen
    children = []
    def substituted(command, **kwargs):
        child = original(command, **kwargs)
        children.append(child)
        return child
    hook = """from livemorebio.anatomy import atlas_reference as a
def technical_network(cache,deadline):
    if BLOCKER=='slow_drip_standin':
        while True:time.sleep(.02)
    else:time.sleep(30)
a._acquire_sources=technical_network
"""
    marker = "from livemorebio.anatomy.atlas_reference import _phase_main"
    # Keep both the production guardian and worker pre-import guards intact.
    monkeypatch.setattr(atlas, "_CHILD_BOOTSTRAP", atlas._CHILD_BOOTSTRAP.replace(marker, marker+"\n"+hook.replace("BLOCKER", repr(blocker))))
    monkeypatch.setattr(atlas.subprocess, "Popen", substituted)
    monkeypatch.setattr(atlas, "NETWORK_SECONDS", .35)
    with atlas._Cache(create=True) as cache, cache.lock() as lock:
        start = time.monotonic()
        with pytest.raises(atlas.AtlasReferenceError) as error:
            atlas._launch_acquisition(cache, lock)
        assert time.monotonic() - start < 3
        assert error.value.code == "ATLAS_SOURCE_POLICY"
        assert not os.listdir(cache.fd) or os.listdir(cache.fd) == [".install.lock"]
    assert len(children) == 1
    cause = error.value.__cause__
    assert children[0].returncode is not None, (getattr(cause, "code", type(cause).__name__), getattr(cause.__cause__, "errno", None) if cause else None)


@pytest.mark.parametrize("phase,deadline", [("other",1), ("acquisition",True), ("acquisition",float("nan")), ("acquisition",float("inf")), ("conversion",0)])
def test_phase_entry_rejects_invalid_deadline_or_phase_before_fds(phase, deadline):
    with pytest.raises(atlas.AtlasReferenceError):
        atlas._phase_main(-1,-1,-1,phase,"",deadline,atlas.DECLARATION_SHA256,"")


def test_expired_startup_or_wrong_source_identity_does_not_enter_network(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    monkeypatch.setattr(atlas, "_child_lifetime", lambda *a, **k: None)
    monkeypatch.setattr(atlas, "_acquire_sources", lambda *a: pytest.fail("invalid source entered network"))
    with atlas._Cache(create=True) as cache, cache.lock() as lock:
        for deadline, source in ((time.monotonic()-1,atlas.DECLARATION_SHA256), (time.monotonic()+10,"0"*64)):
            with pytest.raises(atlas.AtlasReferenceError):
                atlas._phase_main(cache.fd,lock,-1,"acquisition","",deadline,source,"")


def test_acquisition_parent_dispatch_cannot_convert_or_publish(tmp_path, monkeypatch):
    calls = []
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    monkeypatch.setattr(atlas, "_child_lifetime", lambda *a, **k: None)
    monkeypatch.setattr(atlas, "_acquire_sources", lambda *a: calls.append("sources"))
    monkeypatch.setattr(atlas, "_converter_identity", lambda: pytest.fail("acquisition imported converter"))
    monkeypatch.setattr(atlas, "_build_stage", lambda *a: pytest.fail("acquisition converted"))
    monkeypatch.setattr(atlas, "_publish", lambda *a: pytest.fail("acquisition published"))
    with atlas._Cache(create=True) as cache, cache.lock() as lock:
        atlas._phase_main(cache.fd,lock,-1,"acquisition","",time.monotonic()+10,atlas.DECLARATION_SHA256,"")
    assert calls == ["sources"]


@pytest.mark.parametrize("descendant", [False, True])
def test_production_bootstrap_protects_orphan_during_stalled_package_import(tmp_path, descendant):
    root = tmp_path / "stalled-import-cache"
    parent_code = """import sys,os,subprocess
sys.path.insert(0,sys.argv[1])
from livemorebio.anatomy import atlas_reference as a
os.environ['LIVEMORE_ANATOMY_DIR']=sys.argv[2]
a.NETWORK_SECONDS=10
hook='''class ImportBlock:
    def find_spec(self,fullname,path=None,target=None):
        if fullname=='livemorebio':
            if sys.argv[-1]=='with-descendant' and os.fork()==0:
                time.sleep(10)
                os._exit(0)
            print('IMPORT_READY',flush=True)
            time.sleep(30)
sys.meta_path.insert(0,ImportBlock())
'''
a._CHILD_BOOTSTRAP=a._CHILD_BOOTSTRAP.replace('from livemorebio.anatomy.atlas_reference import _phase_main',hook+'from livemorebio.anatomy.atlas_reference import _phase_main')
original=subprocess.Popen
def observed(command,**kwargs):
    kwargs['stdout']=subprocess.PIPE
    kwargs['text']=True
    child=original([*command,sys.argv[3]],**kwargs)
    assert child.stdout.readline().strip()=='IMPORT_READY'
    print(child.pid,flush=True)
    return child
a.subprocess.Popen=observed
with a._Cache(create=True) as cache,cache.lock() as lock:a._launch_acquisition(cache,lock)
"""
    parent = subprocess.Popen([sys.executable,"-I","-B","-c",parent_code,PACKAGE_ROOT,str(root),"with-descendant" if descendant else "without-descendant"],
                              stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                              text=True,start_new_session=True, encoding="utf-8")
    child_pid = None
    lock = root / "atlas" / ".install.lock"
    try:
        child_pid = int(ready(parent.stdout))
        os.kill(child_pid, signal.SIGSTOP)
        parent.kill()
        parent.wait(timeout=wait_seconds(3))
        assert not lock_is_available(lock)
        assert not (root / "atlas" / "active.json").exists()
        os.kill(child_pid, signal.SIGCONT)
        deadline = time.monotonic()+3
        while not lock_is_available(lock) and time.monotonic()<deadline:
            time.sleep(.02)
        assert lock_is_available(lock), "Import-stalled orphan must terminate from pre-import EOF guard"
        assert not (root / "atlas" / "receipts").exists()
    finally:
        if parent.poll() is None:
            parent.kill()
            parent.wait(timeout=wait_seconds(3))
        if child_pid is not None and not lock_is_available(lock):
            os.kill(child_pid,signal.SIGKILL)
        parent.stdout.close()
        parent.stderr.close()


def test_spawn_failure_closes_pipe_descriptors(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    owned = []
    original = os.pipe
    def pipe():
        result = original()
        owned.extend(result)
        return result
    monkeypatch.setattr(atlas.os,"pipe",pipe)
    def fail(*args,**kwargs):
        raise OSError("PRIVATE TEST PATH")
    monkeypatch.setattr(atlas.subprocess,"Popen",fail)
    with atlas._Cache(create=True) as cache,cache.lock() as lock:
        with pytest.raises(atlas.AtlasReferenceError) as error:
            atlas._launch_acquisition(cache,lock)
    assert error.value.code == "ATLAS_SOURCE_POLICY" and "PRIVATE" not in str(error.value)
    for fd in owned:
        with pytest.raises(OSError):
            os.fstat(fd)


def test_exited_group_is_proved_empty_before_reap_without_signal(monkeypatch):
    from livemorebio.anatomy import _atlas_process as process
    calls = []
    class ExitingChild:
        pid = 987654321
        returncode = None
        def wait(self, timeout):
            calls.append("reaped")
            self.returncode = -signal.SIGALRM
            return -signal.SIGALRM
        def kill(self):
            pytest.fail("Already exited child must not be signalled again")
    monkeypatch.setattr(process,"waitable_child_exited",lambda pid: True)
    def empty(pid):
        calls.append("proved-empty")
        return []
    monkeypatch.setattr(process,"active_group_members",empty)
    monkeypatch.setattr(process.os,"killpg",lambda *a: pytest.fail("Proven empty group must not be signalled"))
    atlas._stop_child(ExitingChild())
    assert calls == ["proved-empty", "proved-empty", "reaped"]


@pytest.mark.parametrize("exit_code", [0, 7])
def test_phase_completion_with_descendant_never_publishes_or_leaves_lock(tmp_path, monkeypatch, exit_code):
    """A bounded real fork is a test stand-in, not a supported source operation."""
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    monkeypatch.setattr(atlas, "NETWORK_SECONDS", 3.)
    monkeypatch.setattr(atlas, "_CHILD_BOOTSTRAP", f"""import os,time
if os.fork()==0:
    time.sleep(1.5)
    os._exit(0)
os._exit({exit_code})
""")
    try:
        with atlas._Cache(create=True) as cache, cache.lock() as lock:
            with pytest.raises(atlas.AtlasReferenceError) as error:
                atlas._launch_acquisition(cache, lock)
            assert error.value.code == "ATLAS_SOURCE_POLICY"
        assert lock_is_available(tmp_path / "cache" / "atlas" / ".install.lock")
    finally:
        # On the intentionally red old implementation the tiny orphan ends
        # itself; never signal a numeric group after the old code reaped it.
        time.sleep(1.6)


def test_guardian_success_requires_cleanup_without_unexpected_helpers(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    monkeypatch.setattr(atlas, "_CHILD_BOOTSTRAP", "import os;os._exit(0)")
    with atlas._Cache(create=True) as cache, cache.lock() as lock:
        atlas._launch_acquisition(cache, lock)
    assert lock_is_available(tmp_path / "cache" / "atlas" / ".install.lock")


def test_guardian_deadline_ends_worker_and_in_group_descendant(tmp_path, monkeypatch):
    from livemorebio.anatomy._atlas_process import ProcessOwnershipError
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    monkeypatch.setattr(atlas, "NETWORK_SECONDS", .3)
    monkeypatch.setattr(atlas, "_CHILD_BOOTSTRAP", "import os,time\nos.fork()\ntime.sleep(2)")
    started = time.monotonic()
    try:
        with atlas._Cache(create=True) as cache, cache.lock() as lock:
            with pytest.raises(atlas.AtlasReferenceError) as error:
                atlas._launch_acquisition(cache, lock)
        assert not isinstance(error.value.__cause__, ProcessOwnershipError), str(error.value.__cause__)
        assert time.monotonic()-started < 1.5
        assert lock_is_available(tmp_path / "cache" / "atlas" / ".install.lock")
    finally:
        # A broken implementation must not leave an unbounded technical orphan.
        time.sleep(max(0, 2.1-(time.monotonic()-started)))


def test_parent_disposes_group_when_guardian_dies_unexpectedly(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    monkeypatch.setattr(atlas, "_CHILD_BOOTSTRAP", "import time\nprint('WORKER_READY',flush=True)\ntime.sleep(2)")
    original = subprocess.Popen
    def killed_guardian(command, **kwargs):
        child = original(command, **{**kwargs, "stdout": subprocess.PIPE, "text": True, "encoding": "utf-8"})
        assert ready(child.stdout) == "WORKER_READY"
        # This Popen child is unreaped; its PID is still our ownership anchor.
        os.kill(child.pid, signal.SIGKILL)
        child.stdout.close()
        return child
    monkeypatch.setattr(atlas.subprocess, "Popen", killed_guardian)
    with atlas._Cache(create=True) as cache, cache.lock() as lock:
        with pytest.raises(atlas.AtlasReferenceError):
            atlas._launch_acquisition(cache, lock)
    assert lock_is_available(tmp_path / "cache" / "atlas" / ".install.lock")


@pytest.mark.parametrize("result", [b"", b"SS", b"other", b"F"])
def test_guardian_completion_is_exact_bounded_and_not_an_admission(tmp_path, monkeypatch, result):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    monkeypatch.setattr(atlas, "_GUARDIAN_BOOTSTRAP", f"import os,sys,time\nos.write(int(sys.argv[10]),{result!r})\nos.close(int(sys.argv[10]))\ntime.sleep(2)")
    with atlas._Cache(create=True) as cache, cache.lock() as lock:
        with pytest.raises(atlas.AtlasReferenceError):
            atlas._launch_acquisition(cache, lock)
    root = tmp_path / "cache" / "atlas"
    assert lock_is_available(root / ".install.lock")
    assert not (root / "active.json").exists()


def test_guardian_fork_failure_does_not_leave_lock_or_start_import(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    monkeypatch.setattr(atlas, "_GUARDIAN_BOOTSTRAP", atlas._GUARDIAN_BOOTSTRAP.replace("worker=os.fork()", "raise OSError('TECHNICAL FORK FAILURE')"))
    with atlas._Cache(create=True) as cache, cache.lock() as lock:
        with pytest.raises(atlas.AtlasReferenceError):
            atlas._launch_acquisition(cache, lock)
    assert lock_is_available(tmp_path / "cache" / "atlas" / ".install.lock")


def test_unsupported_group_inspection_fails_before_spawn(tmp_path, monkeypatch):
    from livemorebio.anatomy import _atlas_process as process
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    monkeypatch.setattr(process, "ensure_supported", lambda: (_ for _ in ()).throw(process.ProcessOwnershipError("PROCESS_WAIT_UNSUPPORTED")))
    monkeypatch.setattr(atlas.subprocess, "Popen", lambda *a, **kw: pytest.fail("unsupported platform launched a phase"))
    with atlas._Cache(create=True) as cache, cache.lock() as lock:
        with pytest.raises(atlas.AtlasReferenceError) as error:
            atlas._launch_acquisition(cache, lock)
    assert error.value.code == "ATLAS_UNSUPPORTED_CONVERTER"


def test_phase_worker_has_only_its_guardian_pipe_before_package_import(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    monkeypatch.setattr(atlas, "_CHILD_BOOTSTRAP", """import os,sys,stat
pipes=[]
for descriptor in range(3,256):
    try:info=os.fstat(descriptor)
    except OSError:continue
    if stat.S_ISFIFO(info.st_mode):pipes.append(descriptor)
assert pipes==[int(sys.argv[4])], 'phase inherited unused liveness or result pipe end'
os._exit(0)
""")
    with atlas._Cache(create=True) as cache, cache.lock() as lock:
        atlas._launch_acquisition(cache, lock)


def test_second_pipe_allocation_failure_closes_first_pair(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    original = os.pipe
    owned = []
    def pipe():
        if owned:
            raise OSError("PRIVATE allocation failure")
        result = original()
        owned.extend(result)
        return result
    monkeypatch.setattr(atlas.os, "pipe", pipe)
    with atlas._Cache(create=True) as cache, cache.lock() as lock:
        with pytest.raises(atlas.AtlasReferenceError) as error:
            atlas._launch_acquisition(cache, lock)
    assert "PRIVATE" not in str(error.value)
    for descriptor in owned:
        with pytest.raises(OSError):
            os.fstat(descriptor)


@pytest.mark.parametrize("repetition", range(12))
def test_deadline_cleanup_reaps_guardian_and_records_exact_failure(tmp_path, monkeypatch, repetition):
    from livemorebio.anatomy import _atlas_process as process
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "cache"))
    monkeypatch.setattr(atlas, "NETWORK_SECONDS", .12)
    monkeypatch.setattr(atlas, "_CHILD_BOOTSTRAP", "import time;time.sleep(1)")
    original = subprocess.Popen
    children = []
    observations = []
    original_wait, original_group = process.waitable_child_exited, os.getpgid
    def waitable(pid):
        result = original_wait(pid)
        observations.append(("waitable", result))
        return result
    def group(pid):
        try:
            result = original_group(pid)
            observations.append(("same_group", result == pid, "zero", result == 0))
            return result
        except OSError as error:
            observations.append(("group_errno", error.errno))
            raise
    monkeypatch.setattr(process, "waitable_child_exited", waitable)
    monkeypatch.setattr(process.os, "getpgid", group)
    def observed(command, **kwargs):
        child = original(command, **kwargs)
        children.append(child)
        return child
    monkeypatch.setattr(atlas.subprocess, "Popen", observed)
    with atlas._Cache(create=True) as cache, cache.lock() as lock:
        with pytest.raises(atlas.AtlasReferenceError) as error:
            atlas._launch_acquisition(cache, lock)
    cause = error.value.__cause__
    assert children[0].returncode is not None, (getattr(cause, "code", type(cause).__name__), observations)
    assert lock_is_available(tmp_path / "cache" / "atlas" / ".install.lock")
