"""Large Node harnesses belong to the isolated temporary tree, never the checkout."""
from __future__ import annotations

import json
from pathlib import Path
import subprocess

import pytest

from . import _node


def _scratch(monkeypatch, tmp_path):
    work = tmp_path / "checkout"
    temporary = tmp_path / "temporary"
    work.mkdir()
    temporary.mkdir()
    monkeypatch.chdir(work)
    monkeypatch.setenv("TMPDIR", str(temporary))
    monkeypatch.setattr(_node.tempfile, "tempdir", None)
    return work, temporary


def _track_temporary_files(monkeypatch):
    opened = []
    create = _node.tempfile.TemporaryFile

    def tracked(*args, **kwargs):
        stream = create(*args, **kwargs)
        opened.append((stream, Path(kwargs.get("dir") or _node.tempfile.gettempdir())))
        return stream

    monkeypatch.setattr(_node.tempfile, "TemporaryFile", tracked)
    return opened


@pytest.mark.parametrize("module", [False, True], ids=["commonjs", "esm"])
def test_large_harness_uses_tmpdir_and_keeps_cwd_imports_and_eval_arguments(monkeypatch, tmp_path, module):
    node = _node.require_node()
    work, temporary = _scratch(monkeypatch, tmp_path)
    opened = _track_temporary_files(monkeypatch)
    suffix = "mjs" if module else "cjs"
    dependency = "export default 'technical-fixture';" if module else "module.exports='technical-fixture';"
    (work / f"fixture.{suffix}").write_text(dependency, encoding="utf-8")
    load = "import value from './fixture.mjs';" if module else "const value=require('./fixture.cjs');"
    source = (
        "'use strict';\n" + load +
        "const process='technical shadow';"
        "if((function(){return this})()!==undefined)throw Error('strict directive was lost');"
        "console.log(JSON.stringify({value,args:globalThis.process.argv.slice(1),"
        "cwd:globalThis.process.cwd(),text:'μ'}));"
    )
    source += "\n// " + "technical padding " * 1500
    original_run = subprocess.run

    def inspect_before_launch(command, **kwargs):
        assert not list(work.glob(".livemore-node-*")), "large harness wrote into the checkout"
        return original_run(command, **kwargs)

    monkeypatch.setattr(_node.subprocess, "run", inspect_before_launch)
    command = [node, *(["--input-type=module"] if module else []), "--eval", source, "technical-argument"]
    result = _node.run_node(command, cwd=work, capture_output=True, text=True, encoding="utf-8", timeout=15)

    assert result.returncode == 0, result.stderr
    assert json.loads(result.stdout) == {
        "value": "technical-fixture", "args": ["technical-argument"], "cwd": str(work), "text": "μ",
    }
    assert len(opened) == 1
    assert opened[0][1] == temporary
    assert opened[0][0].closed
    assert list(temporary.iterdir()) == []
    assert not list(work.glob(".livemore-node-*"))


@pytest.mark.parametrize("failure", [OSError("technical spawn failure"),
                                     subprocess.TimeoutExpired("technical-node", 1), KeyboardInterrupt()])
def test_spilled_harness_closes_its_temporary_file_when_launch_fails(monkeypatch, tmp_path, failure):
    work, temporary = _scratch(monkeypatch, tmp_path)
    opened = _track_temporary_files(monkeypatch)
    monkeypatch.setattr(_node, "require_node", lambda: "technical-node")

    def fail_launch(*_args, **_kwargs):
        raise failure

    monkeypatch.setattr(_node.subprocess, "run", fail_launch)
    with pytest.raises(type(failure)):
        _node.run_node(["technical-node", "--eval", "// " + "x" * 20_000])

    assert len(opened) == 1, "large harness must be owned by the temporary-file context"
    assert opened[0][1] == temporary
    assert opened[0][0].closed
    assert list(temporary.iterdir()) == []
    assert not list(work.glob(".livemore-node-*"))


def test_a_failed_spill_write_leaves_no_checkout_file(monkeypatch, tmp_path):
    work, temporary = _scratch(monkeypatch, tmp_path)
    monkeypatch.setattr(_node, "require_node", lambda: "technical-node")

    class FailedWrite:
        def __init__(self, stream):
            self.stream = stream

        def __enter__(self):
            self.stream.__enter__()
            return self

        def __exit__(self, *args):
            return self.stream.__exit__(*args)

        def write(self, _source):
            raise OSError("technical full temporary filesystem")

        def __getattr__(self, name):
            return getattr(self.stream, name)

    for name in ("NamedTemporaryFile", "TemporaryFile"):
        create = getattr(_node.tempfile, name)
        monkeypatch.setattr(_node.tempfile, name,
                            lambda *args, _create=create, **kwargs: FailedWrite(_create(*args, **kwargs)))

    with pytest.raises(OSError, match="technical full temporary filesystem"):
        _node.run_node(["technical-node", "--eval", "// " + "x" * 20_000])

    assert not list(work.glob(".livemore-node-*")), "a write failure left a script in the checkout"
    assert list(temporary.iterdir()) == []


@pytest.mark.parametrize("kwargs", [{"input": "technical input"}, {"stdin": subprocess.DEVNULL}])
def test_a_large_harness_never_silently_replaces_caller_stdin(monkeypatch, tmp_path, kwargs):
    work, temporary = _scratch(monkeypatch, tmp_path)
    monkeypatch.setattr(_node, "require_node", lambda: "technical-node")
    launched = []
    monkeypatch.setattr(_node.subprocess, "run", lambda *args, **options: launched.append((args, options)))

    with pytest.raises(ValueError, match="large Node harness.*stdin"):
        _node.run_node(["technical-node", "--eval", "// " + "x" * 20_000], **kwargs)

    assert launched == []
    assert list(temporary.iterdir()) == []
    assert not list(work.glob(".livemore-node-*"))
