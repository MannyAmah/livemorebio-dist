"""Anatomical presence cannot create unimplemented organ or cellular functions."""
from types import SimpleNamespace

import pytest

from livemorebio.engines.biology import biology_state
from livemorebio.engines.metabolic.glucose_insulin import HEALTHY, T2D


@pytest.mark.parametrize("profile", [HEALTHY, T2D])
def test_unimplemented_organs_do_not_claim_glucose_proxy_as_function(profile):
    organs = {o["id"]: o for o in biology_state(SimpleNamespace(profile=profile))["organs"]}
    for identity in ("kidney", "brain", "adipose"):
        organ = organs[identity]
        assert organ["value"] is None
        assert organ["ratio"] is None
        assert organ["status"] == "unavailable"
        assert organ["evidence_state"] == "REFERENCE_ONLY"
        assert organ["cell"]["activity"] is None
    liver = organs["liver"]
    assert liver["metric"] == "Basal glucose parameter (Gb)"
    assert liver["unit"] == "mg/dL"
    assert liver["value"] == profile.Gb
    assert liver["status"] == "parameter"


def test_reduced_parameters_do_not_invent_cellular_transport_kinetics():
    organs = biology_state(SimpleNamespace(profile=T2D))["organs"]
    for organ in organs:
        cell = organ["cell"]
        assert cell["activity"] is None
        if organ["id"] != "heart":
            assert cell["evidence_state"] == "REFERENCE_ONLY"
            assert cell["quantities"] == []
            assert "not executed" in cell["note"]
