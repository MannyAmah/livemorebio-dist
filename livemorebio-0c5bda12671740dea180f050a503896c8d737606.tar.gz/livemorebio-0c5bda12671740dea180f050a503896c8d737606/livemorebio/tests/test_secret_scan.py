"""Offline release-scanner checks; every credential-shaped value is technical."""
from __future__ import annotations

import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
from types import SimpleNamespace
import zipfile

import pytest


@pytest.fixture
def scanner():
    path = Path(__file__).resolve().parents[2] / "tools" / "secret_scan.py"
    spec = importlib.util.spec_from_file_location("technical_secret_scan", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def technical_credentials():
    return {
        "private_key": "-----BEGIN " + "PRIVATE KEY-----\n" + "VEVDSE5JQ0FM" * 5 + "\n-----END PRIVATE KEY-----",
        "aws_access_key": "AK" + "IA" + "T" * 16,
        "github_token": "gh" + "p_" + "T" * 36,
        "github_fine_grained": "github_" + "pat_" + "T" * 82,
        "openai_key": "sk-" + "proj-" + "T" * 48,
        "anthropic_key": "sk-" + "ant-api03-" + "T" * 70,
        "google_api_key": "AI" + "za" + "T" * 35,
        "slack_token": "xo" + "xb-" + "1" * 10 + "-" + "2" * 10 + "-" + "T" * 24,
        "stripe_key": "sk_" + "live_" + "T" * 24,
        "bearer_token": "Bearer " + "technical" * 4,
        "password_url": "postgresql://technical:" + "technical-passphrase" + "@technical.invalid/db",
    }


@pytest.mark.parametrize("pattern", list(technical_credentials()))
def test_every_high_confidence_family_reports_metadata_only(scanner, tmp_path, pattern):
    credential = technical_credentials()[pattern]
    (tmp_path / "technical.txt").write_text("technical fixture\n" + credential + "\n", encoding="utf-8")
    scan = scanner.Scanner()
    scan.scan_tree(tmp_path)
    assert {"path": "technical.txt", "line": 2, "pattern": pattern} in scan.findings
    assert credential not in json.dumps(scan.findings)
    assert all(set(hit) == {"path", "line", "pattern"} for hit in scan.findings)


def test_binary_ascii_is_scanned_without_text_decoding(scanner, tmp_path):
    token = technical_credentials()["github_token"]
    (tmp_path / "technical.bin").write_bytes(b"\x00\xfftechnical\n" + token.encode("ascii") + b"\x00")
    scan = scanner.Scanner()
    scan.scan_tree(tmp_path)
    assert scan.findings == [{"path": "technical.bin", "line": 2, "pattern": "github_token"}]


def test_exact_allowlist_binds_path_pattern_and_value(scanner, tmp_path):
    token = technical_credentials()["github_token"]
    (tmp_path / "technical.txt").write_text(token, encoding="utf-8")
    entry = {"path": "technical.txt", "pattern": "github_token",
             "sha256": hashlib.sha256(token.encode("ascii")).hexdigest(),
             "rationale": "Technical fixture, not a usable credential."}
    scan = scanner.Scanner([entry])
    scan.scan_tree(tmp_path)
    assert scan.findings == []
    for key, value in (("path", "other.txt"), ("pattern", "google_api_key"), ("sha256", "0" * 64)):
        changed = {**entry, key: value}
        scan = scanner.Scanner([changed])
        scan.scan_tree(tmp_path)
        assert len(scan.findings) == 1


@pytest.mark.parametrize("entry", [
    {"path": "*.txt", "pattern": "github_token", "sha256": "0" * 64, "rationale": "technical"},
    {"path": "technical.txt", "pattern": "unknown", "sha256": "0" * 64, "rationale": "technical"},
    {"path": "technical.txt", "pattern": "github_token", "sha256": "bad", "rationale": "technical"},
    {"path": "technical.txt", "pattern": "github_token", "sha256": "0" * 64, "rationale": ""},
])
def test_invalid_allowlist_refuses(scanner, entry):
    with pytest.raises(scanner.ScanError, match="INVALID_ALLOWLIST"):
        scanner.Scanner([entry])


def technical_zip(members):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in members:
            archive.writestr(name, data)
    return stream.getvalue()


def technical_tar(members):
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode="w:gz") as archive:
        for name, data in members:
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            archive.addfile(entry, io.BytesIO(data))
    return stream.getvalue()


@pytest.mark.parametrize("format", ["zip", "tar"])
def test_archive_members_are_scanned_without_extraction(scanner, tmp_path, format):
    token = technical_credentials()["github_token"]
    builder = technical_zip if format == "zip" else technical_tar
    path = tmp_path / ("technical.zip" if format == "zip" else "technical.tar.gz")
    path.write_bytes(builder([("technical.txt", ("technical\n" + token).encode("ascii"))]))
    scan = scanner.Scanner()
    scan.scan_archive(path)
    assert {"path": path.name + "!technical.txt", "line": 2, "pattern": "github_token"} in scan.findings
    assert sorted(item.name for item in tmp_path.iterdir()) == [path.name]
    assert token not in json.dumps(scan.findings)


def test_nested_archive_and_member_limit_fail_closed(scanner, tmp_path):
    token = technical_credentials()["google_api_key"].encode("ascii")
    path = tmp_path / "technical.zip"
    path.write_bytes(technical_zip([("inner.tar.gz", technical_tar([("technical.bin", token)]))]))
    scan = scanner.Scanner()
    scan.scan_archive(path)
    assert {"path": "technical.zip!inner.tar.gz!technical.bin", "line": 1, "pattern": "google_api_key"} in scan.findings
    with pytest.raises(scanner.ScanError, match="ARCHIVE_DEPTH_LIMIT"):
        scanner.Scanner(max_depth=1).scan_archive(path)
    with pytest.raises(scanner.ScanError, match="ARCHIVE_MEMBER_LIMIT"):
        scanner.Scanner(max_members=1).scan_archive(path)


@pytest.mark.parametrize("format", ["zip", "tar.gz"])
def test_malformed_archive_is_an_error_not_clean(scanner, tmp_path, format):
    path = tmp_path / ("technical." + format)
    path.write_bytes(b"TECHNICAL CORRUPT ARCHIVE")
    with pytest.raises(scanner.ScanError, match="INVALID_ARCHIVE"):
        scanner.Scanner().scan_archive(path)


@pytest.mark.parametrize("member", ["../technical.txt", "/technical.txt", "x/../../technical.txt"])
def test_unsafe_archive_paths_are_refused(scanner, tmp_path, member):
    path = tmp_path / "technical.zip"
    path.write_bytes(technical_zip([(member, b"TECHNICAL")]))
    with pytest.raises(scanner.ScanError, match="UNSAFE_ARCHIVE_MEMBER"):
        scanner.Scanner().scan_archive(path)


def test_archive_symlinks_and_directory_symlinks_are_refused(scanner, tmp_path):
    outside = tmp_path / "technical-outside"
    outside.mkdir()
    root = tmp_path / "technical-tree"
    root.mkdir()
    (root / "technical-link").symlink_to(outside, target_is_directory=True)
    with pytest.raises(scanner.ScanError, match="SYMLINK_REFUSED"):
        scanner.Scanner().scan_tree(root)
    archive_path = tmp_path / "technical.tar"
    with tarfile.open(archive_path, "w") as archive:
        entry = tarfile.TarInfo("technical-link")
        entry.type = tarfile.SYMTYPE
        entry.linkname = "technical-outside"
        archive.addfile(entry)
    with pytest.raises(scanner.ScanError, match="UNSAFE_ARCHIVE_MEMBER"):
        scanner.Scanner().scan_archive(archive_path)


def test_size_budgets_never_report_clean_after_truncation(scanner, tmp_path):
    (tmp_path / "technical.txt").write_bytes(b"TECHNICAL" * 10)
    with pytest.raises(scanner.ScanError, match="FILE_SIZE_LIMIT"):
        scanner.Scanner(max_file_bytes=16).scan_tree(tmp_path)
    with pytest.raises(scanner.ScanError, match="TOTAL_SIZE_LIMIT"):
        scanner.Scanner(max_total_bytes=16).scan_tree(tmp_path)


def test_git_added_lines_only_and_real_destination_numbers(scanner, monkeypatch, tmp_path):
    token = technical_credentials()["github_token"]
    removed = technical_credentials()["google_api_key"]
    patch = ("diff --git a/technical.txt b/technical.txt\n--- a/technical.txt\n+++ b/technical.txt\n"
             "@@ -3,2 +3,3 @@\n-" + removed + "\n context\n+technical\n+" + token + "\n")
    commands = []

    def fake_git(command, **kwargs):
        commands.append((command, kwargs))
        payload = ("1" * 40 + "\n").encode("ascii") if "rev-list" in command else patch.encode("utf-8")
        return SimpleNamespace(returncode=0, stdout=payload)

    monkeypatch.setattr(scanner.subprocess, "run", fake_git)
    scan = scanner.Scanner()
    scan.scan_git(tmp_path, "technical-before..technical-after")
    assert scan.findings == [{"path": "technical.txt", "line": 5, "pattern": "github_token"}]
    assert "rev-list" in commands[0][0]
    assert commands[0][0][-2:] == ["technical-before..technical-after", "--"]
    command, kwargs = commands[1]
    assert "--no-ext-diff" in command and "--no-textconv" in command
    assert kwargs["stderr"] == subprocess.DEVNULL
    assert command[-2:] == ["1" * 40, "--"]
    assert "diff-tree" in command and "--root" in command and "-m" in command


@pytest.mark.parametrize("range", ["--output=technical", "technical..--output=oops", "technical\n..HEAD", "", "technical"])
def test_git_option_injection_never_spawns(scanner, monkeypatch, tmp_path, range):
    monkeypatch.setattr(scanner.subprocess, "run", lambda *a, **k: pytest.fail("invalid range spawned git"))
    with pytest.raises(scanner.ScanError, match="INVALID_GIT_RANGE"):
        scanner.Scanner().scan_git(tmp_path, range)


def test_binary_git_diff_fails_as_unscanned(scanner, monkeypatch, tmp_path):
    monkeypatch.setattr(scanner.subprocess, "run", lambda command, **k: SimpleNamespace(
        returncode=0, stdout=(("1" * 40 + "\n").encode("ascii") if "rev-list" in command else
                              b"diff --git a/technical.bin b/technical.bin\nBinary files a/technical.bin and b/technical.bin differ\n")))
    with pytest.raises(scanner.ScanError, match="BINARY_GIT_DIFF_UNSCANNED"):
        scanner.Scanner().scan_git(tmp_path, "technical-before..technical-after")


def test_cli_never_echoes_credential_content_even_in_filename(scanner, tmp_path, capsys):
    token = technical_credentials()["github_token"]
    (tmp_path / (token + ".txt")).write_text(token, encoding="utf-8")
    assert scanner.main(["tree", str(tmp_path)]) == 1
    output = capsys.readouterr()
    assert token not in output.out + output.err
    assert '"pattern": "github_token"' in output.out
    assert scanner.main(["archive", str(tmp_path / (token + ".zip"))]) == 2
    output = capsys.readouterr()
    assert token not in output.out + output.err


@pytest.mark.parametrize("compression", ["gzip", "bzip2", "xz"])
def test_renamed_compressed_tar_is_recognized_by_bytes(scanner, tmp_path, compression):
    import bz2
    import gzip
    import lzma

    token = technical_credentials()["github_token"].encode("ascii")
    tar_bytes = gzip.decompress(technical_tar([("technical.txt", token)]))
    compress = {"gzip": gzip.compress, "bzip2": bz2.compress, "xz": lzma.compress}[compression]
    path = tmp_path / "technical.bin"
    path.write_bytes(compress(tar_bytes))
    scan = scanner.Scanner()
    scan.scan_tree(tmp_path)
    assert {"path": "technical.bin!technical.txt", "line": 1, "pattern": "github_token"} in scan.findings
    outer = tmp_path / "technical.zip"
    outer.write_bytes(technical_zip([("nested.bin", compress(tar_bytes))]))
    scan = scanner.Scanner()
    scan.scan_archive(outer)
    assert {"path": "technical.zip!nested.bin!technical.txt", "line": 1, "pattern": "github_token"} in scan.findings


def test_compressed_tar_header_expansion_has_a_bound(scanner, tmp_path):
    import gzip

    header = tarfile.TarInfo("technical-pax")
    header.type = tarfile.XHDTYPE
    header.size = 100_000
    path = tmp_path / "technical.bin"
    path.write_bytes(gzip.compress(header.tobuf() + b"T" * header.size))
    with pytest.raises(scanner.ScanError, match="TOTAL_SIZE_LIMIT"):
        scanner.Scanner(max_total_bytes=16_000).scan_tree(tmp_path)


def test_git_private_key_allowlist_hashes_whole_block_not_common_header(scanner, monkeypatch, tmp_path):
    first = technical_credentials()["private_key"]
    second = first.replace("VEVDSE5JQ0FM", "U0VDT05EVEVD")
    allow = [{"path": "technical.pem", "pattern": "private_key",
              "sha256": hashlib.sha256(first.encode("ascii")).hexdigest(),
              "rationale": "Technical non-key block."}]
    header_only = first.splitlines()[0]

    def patch_for(value):
        return ("diff --git a/technical.pem b/technical.pem\n--- /dev/null\n+++ b/technical.pem\n"
                "@@ -0,0 +1,3 @@\n" + "\n".join("+" + line for line in value.splitlines()) + "\n").encode("ascii")

    for value, expected in ((first, 0), (second, 1)):
        monkeypatch.setattr(scanner.subprocess, "run", lambda command, **k: SimpleNamespace(returncode=0, stdout=(("1" * 40 + "\n").encode("ascii") if "rev-list" in command else patch_for(value))))
        scan = scanner.Scanner(allow)
        scan.scan_git(tmp_path, "technical-before..technical-after")
        assert len(scan.findings) == expected
    allow[0]["sha256"] = hashlib.sha256(header_only.encode("ascii")).hexdigest()
    monkeypatch.setattr(scanner.subprocess, "run", lambda command, **k: SimpleNamespace(returncode=0, stdout=(("1" * 40 + "\n").encode("ascii") if "rev-list" in command else patch_for(header_only))))
    scan = scanner.Scanner(allow)
    scan.scan_git(tmp_path, "technical-before..technical-after")
    assert len(scan.findings) == 1


def test_git_history_finds_secret_added_then_removed_before_range_end(scanner, monkeypatch, tmp_path):
    token = technical_credentials()["github_token"]
    first, second = "1" * 40, "2" * 40
    added = ("diff --git a/technical.txt b/technical.txt\n--- /dev/null\n+++ b/technical.txt\n"
             "@@ -0,0 +1 @@\n+" + token + "\n").encode("ascii")
    removed = ("diff --git a/technical.txt b/technical.txt\n--- a/technical.txt\n+++ /dev/null\n"
               "@@ -1 +0,0 @@\n-" + token + "\n").encode("ascii")
    commands = []

    def fake_git(command, **kwargs):
        commands.append(command)
        if "rev-list" in command:
            payload = (first + "\n" + second + "\n").encode("ascii")
        elif "diff-tree" in command:
            payload = added if command[-2] == first else removed
        elif "diff" in command:
            payload = b""  # The endpoints contain no secret; history still does.
        else:
            pytest.fail("unexpected technical git command")
        return SimpleNamespace(returncode=0, stdout=payload)

    monkeypatch.setattr(scanner.subprocess, "run", fake_git)
    scan = scanner.Scanner()
    scan.scan_git(tmp_path, "technical-before..technical-after")
    assert scan.findings == [{"path": "technical.txt", "line": 1, "pattern": "github_token"}]
    assert sum("diff-tree" in command for command in commands) == 2
    assert all("--root" in command and "-m" in command for command in commands if "diff-tree" in command)


@pytest.mark.parametrize("output, code", [
    (b"technical-not-a-commit\n", "INVALID_GIT_HISTORY"),
    ((("1" * 40 + "\n") * 3).encode("ascii"), "HISTORY_COMMIT_LIMIT"),
])
def test_git_history_list_is_validated_before_any_patch(scanner, monkeypatch, tmp_path, output, code):
    monkeypatch.setattr(scanner, "MAX_HISTORY_COMMITS", 2, raising=False)
    commands = []

    def fake_git(command, **kwargs):
        commands.append(command)
        return SimpleNamespace(returncode=0, stdout=output)

    monkeypatch.setattr(scanner.subprocess, "run", fake_git)
    with pytest.raises(scanner.ScanError, match=code):
        scanner.Scanner().scan_git(tmp_path, "technical-before..technical-after")
    assert len(commands) == 1


@pytest.mark.parametrize("credential", [
    "Bearer " + "technical-release-fixture-token",
    "https://fixture:" + "technical-release-password" + "@example.invalid/",
])
def test_technical_credential_prefix_is_scoped_to_test_sources(scanner, tmp_path, credential):
    """Technical credential values are never a blanket source-tree exemption."""
    test_path = tmp_path / "livemorebio" / "tests" / "test_technical.py"
    test_path.parent.mkdir(parents=True)
    test_path.write_text(credential, encoding="utf-8")
    scan = scanner.Scanner()
    scan.scan_tree(tmp_path)
    assert scan.findings == []

    production_path = tmp_path / "livemorebio" / "technical.py"
    production_path.write_text(credential, encoding="utf-8")
    scan = scanner.Scanner()
    scan.scan_tree(tmp_path)
    assert len(scan.findings) == 1
    assert scan.findings[0]["path"] == "livemorebio/technical.py"


@pytest.mark.parametrize("credential", [
    "Bearer " + "not-technical-release-fixture-token",
    "Bearer " + "technicalreleasefixturetoken",
    "https://technical-user:" + "ordinary-fixture-password" + "@example.invalid/",
    "technical-" + technical_credentials()["github_token"],
])
def test_technical_marker_elsewhere_does_not_exempt_a_credential(scanner, tmp_path, credential):
    test_path = tmp_path / "livemorebio" / "tests" / "test_technical.py"
    test_path.parent.mkdir(parents=True)
    test_path.write_text(credential, encoding="utf-8")
    scan = scanner.Scanner()
    scan.scan_tree(tmp_path)
    assert len(scan.findings) == 1


def test_line_scoped_allowlist_does_not_allow_the_same_value_on_another_line(scanner, tmp_path):
    token = technical_credentials()["github_token"]
    (tmp_path / "technical.txt").write_text(token + "\n" + token, encoding="utf-8")
    entry = {"path": "technical.txt", "line": 1, "pattern": "github_token",
             "sha256": hashlib.sha256(token.encode("ascii")).hexdigest(),
             "rationale": "Technical fixture deliberately admitted on its reviewed line only."}
    scan = scanner.Scanner([entry])
    scan.scan_tree(tmp_path)
    assert scan.findings == [{"path": "technical.txt", "line": 2, "pattern": "github_token"}]


@pytest.mark.parametrize("line", [0, -1, True, "1", None])
def test_allowlist_line_must_be_a_positive_integer(scanner, line):
    entry = {"path": "technical.txt", "line": line, "pattern": "github_token",
             "sha256": "0" * 64, "rationale": "Technical invalid line fixture."}
    with pytest.raises(scanner.ScanError, match="INVALID_ALLOWLIST"):
        scanner.Scanner([entry])


def test_release_archive_uses_reviewed_source_paths_for_technical_values(scanner, tmp_path):
    root = "livemorebio-" + "1" * 40 + "/"
    token = technical_credentials()["github_token"]
    technical_bearer = "Bearer " + "technical-release-fixture-token"
    path = tmp_path / "technical-release.tar.gz"
    test_path = "livemorebio/tests/test_technical.py"
    path.write_bytes(technical_tar([
        (root + test_path, (token + "\n" + technical_bearer).encode("ascii")),
        (root + "livemorebio/technical.py", technical_bearer.encode("ascii")),
    ]))
    entry = {"path": test_path, "line": 1, "pattern": "github_token",
             "sha256": hashlib.sha256(token.encode("ascii")).hexdigest(),
             "rationale": "Technical source fixture, identical in the release archive."}
    scan = scanner.Scanner([entry])
    scan.scan_archive(path)
    assert scan.findings == [{"path": path.name + "!" + root + "livemorebio/technical.py",
                              "line": 1, "pattern": "bearer_token"}]


@pytest.mark.parametrize("root", ["technical/", "livemorebio-short/", "vendor/livemorebio/", ""])
def test_arbitrary_archive_prefix_does_not_acquire_a_source_allowance(scanner, tmp_path, root):
    token = technical_credentials()["github_token"]
    test_path = "livemorebio/tests/test_technical.py"
    path = tmp_path / "technical-release.tar.gz"
    path.write_bytes(technical_tar([(root + test_path, token.encode("ascii"))]))
    entry = {"path": test_path, "line": 1, "pattern": "github_token",
             "sha256": hashlib.sha256(token.encode("ascii")).hexdigest(),
             "rationale": "Technical source fixture; unrelated archive members remain separate."}
    scan = scanner.Scanner([entry])
    scan.scan_archive(path)
    assert len(scan.findings) == 1
