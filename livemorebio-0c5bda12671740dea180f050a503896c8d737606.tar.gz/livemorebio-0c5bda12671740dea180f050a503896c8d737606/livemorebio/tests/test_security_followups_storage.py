"""Fix H storage boundary regressions using technical fixtures only."""
from __future__ import annotations
import logging
import pytest
from fastapi.testclient import TestClient
from livemorebio import bus, cli, registry, security


@pytest.fixture
def private_state(tmp_path, monkeypatch):
    data = tmp_path / "technical-state"
    data.mkdir()
    monkeypatch.setattr(registry, "REG_DIR", str(data))
    monkeypatch.setattr(registry, "REG", str(data / "registry.json"))
    monkeypatch.setattr(cli, "TOKEN_FILE", str(data / "api-token"))
    monkeypatch.setattr(bus, "BUS_DIR", str(data))
    monkeypatch.setattr(bus, "EVENTS", str(data / "events.jsonl"))
    monkeypatch.setattr(bus, "SNAP_DIR", str(data / "snapshots"))
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-fixh-operator")
    monkeypatch.setenv("LIVEMORE_PATCH_JOURNAL", str(data / "patch.jsonl"))
    monkeypatch.delenv(security.PATCH_STORAGE_KEY_ENV, raising=False)
    monkeypatch.delenv("LIVEMORE_ENVIRONMENT", raising=False)
    from livemorebio.life_system import service
    monkeypatch.setattr(service, "_c", {})
    return data



def test_cs1_missing_storage_key_refuses_command_before_journaling(private_state):
    from livemorebio.life_system import service
    from livemorebio.life_patch.protocol import DeviceMode, manifest_for
    client = TestClient(service.app, base_url="http://127.0.0.1:18950", headers=security.authorization_headers())
    registered = client.post("/patch/devices", json=manifest_for("technical-cs1-device", DeviceMode.VIRTUAL).to_dict())
    assert registered.status_code == 201
    response = client.post("/patch/commands", json={"device_id": "technical-cs1-device", "command": "request_quality_check", "parameters": {}, "command_id": "technical-cs1-command"})
    assert response.status_code == 503, response.text
    assert response.json()["code"] == "PATCH_STORAGE_KEY_UNAVAILABLE"
    assert client.get("/patch/commands").json()["commands"] == []



@pytest.mark.parametrize("explicit", [False, True])
def test_cs1_missing_storage_key_refuses_virtual_sample_before_admission(private_state, monkeypatch, explicit):
    from livemorebio.life_system import service
    from livemorebio.life_patch.protocol import DeviceMode, VirtualLifePatch, manifest_for
    manifest = manifest_for("technical-cs1-device", DeviceMode.VIRTUAL)
    client = TestClient(service.app, base_url="http://127.0.0.1:18950", headers=security.authorization_headers())
    assert client.post("/patch/devices", json=manifest.to_dict()).status_code == 201
    forwarded = []
    monkeypatch.setattr(service, "_forward_to_aegle", lambda payload: forwarded.append(payload))
    body = {"device_id": manifest.device_id, "subject_id": "pseudonym-technical-cs1-subject", "readings": {"hr_bpm": 72}}
    if explicit:
        body = {"envelope": VirtualLifePatch(manifest).emit("pseudonym-technical-cs1-subject", {"hr_bpm": 72}).to_dict()}
    response = client.post("/patch/virtual/sample", json=body)
    assert response.status_code == 503, response.text
    assert response.json()["code"] == "PATCH_STORAGE_KEY_UNAVAILABLE"
    assert client.get("/patch/telemetry").json()["telemetry"] == []
    assert forwarded == []
    assert not (private_state / "events.jsonl").exists()



@pytest.mark.parametrize("route,body", [
    ("/api/workspace/actions", {"kind": "meal", "params": {"grams": 50}}),
    ("/api/stimulate", {"kind": "meal", "params": {"grams": 50}}),
    ("/api/patch/telemetry", {}),
    ("/api/twins/technical-twin/activate", {"expected_version": 1}),
    ("/api/twins/technical-twin/select-observations", {"expected_version": 1}),
    ("/api/twins/technical-twin/patches", {"expected_version": 1}),
    ("/api/twins/reconcile-selection", {}),
])
def test_cs1_aegle_refuses_before_mutating_or_preparing(private_state, monkeypatch, route, body):
    from livemorebio.aegle import server
    touched = []
    def must_not_prepare(*args, **kwargs):
        touched.append(True)
        raise AssertionError("storage precondition must precede model/registry work")
    monkeypatch.setattr(server, "_subject_registry", must_not_prepare)
    monkeypatch.setattr(server, "_require_numerical_model", must_not_prepare)
    client = TestClient(server.app, base_url="http://127.0.0.1:18950", headers=security.authorization_headers())
    response = client.post(route, json=body)
    assert response.status_code == 503, response.text
    assert response.json()["code"] == "PATCH_STORAGE_KEY_UNAVAILABLE"
    assert touched == []



@pytest.mark.parametrize("route", ["/evidence/lab-results", "/qualification/assess"])
def test_cs1_cendos_storage_mutations_refuse_with_named_code(private_state, route):
    from livemorebio.cendos import service
    client = TestClient(service.app, base_url="http://127.0.0.1:18950", headers=security.authorization_headers())
    response = client.post(route, json={})
    assert response.status_code == 503, response.text
    assert response.json()["code"] == "PATCH_STORAGE_KEY_UNAVAILABLE"
    assert not (private_state / "snapshots").exists()



def test_cs1_cendos_readonly_assay_preserves_result_and_logs_loss_reason(private_state, monkeypatch, caplog):
    from dataclasses import asdict
    from livemorebio.cendos import service
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY
    from livemorebio.tests.cendos_source_fixtures import technical_source
    source = technical_source({"profile": HEALTHY.name, "profile_params": asdict(HEALTHY),
        "pk_context": {"age": 50, "genome": {}, "evidence_class": "REFERENCE_INITIALIZED"}})
    monkeypatch.setattr(service, "_read_current_source", lambda: source)
    client = TestClient(service.app, base_url="http://127.0.0.1:18950", headers=security.authorization_headers())
    with caplog.at_level(logging.WARNING, logger=service.__name__):
        response = client.post("/assay/current", json={"drug": "metformin", "dose": 1, "grams": 75})
    assert response.status_code == 200, response.text
    assert "PATCH_STORAGE_KEY_UNAVAILABLE" in caplog.text
    assert HEALTHY.name not in caplog.text
