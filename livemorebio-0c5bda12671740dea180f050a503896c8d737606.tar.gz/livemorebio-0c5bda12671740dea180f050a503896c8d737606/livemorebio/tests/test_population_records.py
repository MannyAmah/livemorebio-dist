"""Authored numerical fixtures, not NHANES participant rows."""
import copy
import json

import pytest

from livemorebio.aegle import population_records as records


def tables():
    data={name:[] for name in ('DEMO_L','BMX_L','GLU_L','INS_L','GHB_L','DIQ_L','RXQ_RX_L')}
    for i in range(1,5):
        data['DEMO_L'].append(dict(SEQN=i,SDDSRVYR=12,RIDSTATR=2,RIDAGEYR=25+10*i,RIAGENDR=1 if i%2 else 2,RIDEXPRG=None if i%2 else 2,RIDEXMON=1,SDMVSTRA=173,SDMVPSU=1))
        data['BMX_L'].append(dict(SEQN=i,BMXWT=50+10*i,BMXHT=150+i,BMXBMI=22+i,BMIWT=None,BMIHT=None,BMDSTATS=1))
        data['GLU_L'].append(dict(SEQN=i,LBXGLU=80+i,WTSAF2YR=100+i))
        data['INS_L'].append(dict(SEQN=i,LBXIN=5+i,LBDINLC=0,WTSAF2YR=100+i))
        data['GHB_L'].append(dict(SEQN=i,LBXGH=4+i*.1,WTPH2YR=200+i))
        data['DIQ_L'].append(dict(SEQN=i,DIQ010=2,DIQ160=2,DIQ050=None,DIQ070=None))
        data['RXQ_RX_L'].append(dict(SEQN=i,RXQ033=2,RXQ050=None))
    return data


def normalize(data=None):
    return records._normalize_tables(tables() if data is None else data, fingerprint_key=b'technical-key-do-not-use-in-live-1')


def test_joint_rows_stay_whole_and_have_no_invented_genes_or_kinetics():
    result=records.select_reference_members(normalize(),records.SCREENED,4,42)
    assert result['size']==4 and result['eligible_count']==4
    assert {tuple(m['measurements'][q]['value'] for q in ('weight_kg','fasting_glucose_mgdl','fasting_insulin_uU_ml')) for m in result['members']} == {(50+10*i,80+i,5+i) for i in range(1,5)}
    for member in result['members']:
        assert member['model_binding_available'] is False
        assert 'genome' not in member and 'model_parameters' not in member
        assert 'SEQN' not in json.dumps(member) and 'captured_at' not in json.dumps(member)
        assert member['time_context']['precision']=='survey_cycle'


def test_reproducible_selection_without_replacement_and_immutable_inputs():
    population=normalize();before=population.records
    first=records.select_reference_members(population,records.SCREENED,3,19)
    second=records.select_reference_members(population,records.SCREENED,3,19)
    assert first==second and population.records==before
    assert len({m['reference_fingerprint'] for m in first['members']})==3
    first['members'][0]['measurements']['weight_kg']['value']=999
    assert records.select_reference_members(population,records.SCREENED,3,19)==second
    with pytest.raises(records.PopulationRecordError,match='eligible'):
        records.select_reference_members(population,records.SCREENED,5,19)


@pytest.mark.parametrize('mutation,reason',[
    ('missing_insulin','missing_fasting_insulin_uU_ml'),('zero_weight','invalid_fasting_weight'),
    ('censored_insulin','censored_fasting_insulin'),('missing_hba1c','missing_hba1c_percent'),
    ('prediabetes','reported_prediabetes'),('rx_unknown','prescription_status_not_negative'),
    ('high_glucose','outside_normal_glycemia'),('high_hba1c','outside_normal_glycemia'),
    ('age_topcode','outside_defined_age_range'),
])
def test_missingness_and_screening_do_not_create_health(mutation,reason):
    data=tables()
    if mutation=='missing_insulin':data['INS_L'][0]['LBXIN']=None
    elif mutation=='zero_weight':
        data['GLU_L'][0]['WTSAF2YR']=0;data['INS_L'][0]['WTSAF2YR']=0
    elif mutation=='censored_insulin':data['INS_L'][0].update(LBXIN=.35,LBDINLC=1)
    elif mutation=='missing_hba1c':data['GHB_L'][0]['LBXGH']=0
    elif mutation=='prediabetes':data['DIQ_L'][0]['DIQ160']=1
    elif mutation=='rx_unknown':data['RXQ_RX_L'][0]['RXQ033']=9
    elif mutation=='high_glucose':data['GLU_L'][0]['LBXGLU']=100
    elif mutation=='high_hba1c':data['GHB_L'][0]['LBXGH']=5.7
    elif mutation=='age_topcode':data['DEMO_L'][0]['RIDAGEYR']=80
    result=records.select_reference_members(normalize(data),records.SCREENED,3,1)
    assert result['eligible_count']==3 and result['exclusion_counts'][reason]==1


def test_pregnancy_unknown_is_not_negative_and_no_drug_name_is_inferred():
    population=normalize()
    general=records.select_reference_members(population,records.SCREENED,4,1)
    restricted=records.select_reference_members(population,records.SCREENED,2,1,require_nonpregnant=True)
    assert general['eligible_count']==4 and restricted['eligible_count']==2
    assert restricted['exclusion_counts']['pregnancy_not_documented_negative']==2
    for member in general['members']:
        assert member['prescriptions']['names_available'] is False
        assert 'medications' not in member


@pytest.mark.parametrize('change',['duplicate','cross_cycle','weight_conflict','foreign_id','boolean','infinite'])
def test_invalid_joint_input_fails_without_printing_source_values(change):
    data=tables()
    if change=='duplicate':data['INS_L'].append(copy.deepcopy(data['INS_L'][0]))
    elif change=='cross_cycle':data['DEMO_L'][0]['SDDSRVYR']=11
    elif change=='weight_conflict':data['INS_L'][0]['WTSAF2YR']=999
    elif change=='foreign_id':data['INS_L'][0]['SEQN']=999999999
    elif change=='boolean':data['BMX_L'][0]['BMXWT']=True
    elif change=='infinite':data['BMX_L'][0]['BMXWT']=float('inf')
    with pytest.raises(records.PopulationRecordError) as error:normalize(data)
    assert '999999999' not in str(error.value)


def test_broad_context_does_not_manufacture_t2d_or_enable_a_model():
    data=tables();data['DIQ_L'][0]['DIQ010']=1;data['DIQ_L'][0]['DIQ050']=1;data['RXQ_RX_L'][0]['RXQ033']=1
    result=records.select_reference_members(normalize(data),records.ADULT_REFERENCE,4,1)
    assert result['eligible_count']==4
    assert 'type-2' not in json.dumps(result).lower()
    assert all(m['model_binding_available'] is False for m in result['members'])


def test_keys_and_configuration_are_strict():
    with pytest.raises(records.PopulationRecordError):records._normalize_tables(tables(),fingerprint_key=b'weak')
    population=normalize()
    for kwargs in ({'size':True,'seed':1},{'size':1,'seed':1.1},{'size':0,'seed':1},{'size':1,'seed':-1},{'size':1,'seed':1,'require_nonpregnant':'false'}):
        with pytest.raises(records.PopulationRecordError):records.select_reference_members(population,records.SCREENED,**kwargs)


def test_public_normalization_must_validate_entire_frozen_source_before_join(monkeypatch):
    from livemorebio.aegle import population_sources
    with pytest.raises(population_sources.PopulationSourceError) as error:
        records.normalize_joint_records({'DEMO_L.xpt':b'not a reviewed source'},fingerprint_key=b'x'*32)
    assert error.value.code=='SOURCE_INCOMPLETE'


def test_below_detection_fill_and_missing_answers_are_never_measured_or_negative():
    data=tables();data['INS_L'][0].update(LBXIN=.35,LBDINLC=1)
    data['DIQ_L'][0].update(DIQ010=None,DIQ160=9,DIQ050=None)
    population=normalize(data)
    member=json.loads(population.records[0])
    insulin=member['measurements']['fasting_insulin_uU_ml']
    assert insulin['value'] is None and insulin['evidence_state']=='UNAVAILABLE'
    assert insulin['source_fill_value']==.35 and insulin['source_fill_is_measurement'] is False
    assert member['questionnaire']['reported_diabetes']['answer']=='not_released_or_skipped'
    assert member['questionnaire']['reported_prediabetes']['answer']=='unknown'
    assert member['questionnaire']['insulin_use']['answer']!='no'


def test_unreleased_detection_status_is_not_counted_as_measured_censoring():
    data=tables();data['INS_L'][0]['LBDINLC']=None
    result=records.select_reference_members(normalize(data),records.SCREENED,3,1)
    assert result['exclusion_counts']['insulin_detection_status_unavailable']==1
    assert 'censored_fasting_insulin' not in result['exclusion_counts']


def test_weight_comments_and_surveys_do_not_get_lost_or_conflated():
    data=tables();data['BMX_L'][0]['BMIWT']=3
    selected=records.select_reference_members(normalize(data),records.SCREENED,4,1)
    member=next(m for m in selected['members'] if m['measurements']['weight_kg']['value']==60)
    assert member['measurements']['weight_kg']['measurement_comment_code']==3
    assert member['measurements']['weight_kg']['comment_lineage']['variable']=='BMIWT'
    assert member['survey_design']['fasting_weight']==101
    assert member['survey_design']['phlebotomy_weight']==201
    assert member['survey_design']['population_prevalence_estimate'] is False


def test_screen_rejects_positive_prescription_count_despite_negative_use_answer():
    data=tables();data['RXQ_RX_L'][0]['RXQ050']=2
    result=records.select_reference_members(normalize(data),records.SCREENED,3,1)
    assert result['eligible_count']==3
    assert result['exclusion_counts']['inconsistent_prescription_count']==1


def test_no_fingerprint_key_or_raw_key_and_key_changes_are_not_identity_claims():
    first=normalize()
    second=records._normalize_tables(tables(),fingerprint_key=b'a-different-technical-private-key')
    a=json.loads(first.records[0]);b=json.loads(second.records[0])
    assert a['reference_fingerprint']!=b['reference_fingerprint']
    assert a['identity_linking'] is False
    assert 'fingerprint_key' not in json.dumps(a)


def test_construction_digest_binds_normalized_values_not_only_selected_identities():
    data=tables()
    first=records.select_reference_members(normalize(data),records.SCREENED,4,1)
    data['BMX_L'][0]['BMXWT']=61
    second=records.select_reference_members(normalize(data),records.SCREENED,4,1)
    assert [m['reference_fingerprint'] for m in first['members']]==[m['reference_fingerprint'] for m in second['members']]
    assert first['construction_sha256']!=second['construction_sha256']
