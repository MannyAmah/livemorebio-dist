"""The deposited human hERG construct is a reference, not channel execution."""
from __future__ import annotations

import hashlib

from livemorebio import molecular_reference


def test_human_herg_reference_has_exact_deposited_identity():
    result = molecular_reference.lookup("KCNH2")
    assert result["status"] == "REFERENCE_AVAILABLE"
    assert result["pdb"] == "5VA2" and result["uniprot"] == "Q12809"
    descriptor = result["reference"]
    assert descriptor["method"] == "ELECTRON MICROSCOPY"
    assert descriptor["resolution_angstrom"] == 3.8
    assert descriptor["source_revision"] == {"major": 1, "minor": 4, "date": "2024-03-13"}
    assert descriptor["evidence_state"] == "REFERENCE_ONLY"
    assert descriptor["dynamic_coordinates"] is False
    assert descriptor["patient_specific"] is False
    assert descriptor["assembly"] == "DEPOSITED_MODEL_NOT_EXPANDED_ASSEMBLY"
    assert descriptor["source_model_numbers"] == [1]
    assert descriptor["selected_model_index"] == 0
    assert descriptor["selected_model_number"] == 1
    assert descriptor["atom_site_rows"] == 4394
    assert descriptor["hydrogen_rows"] == 0
    assert descriptor["chains"] == [{"entity_id": "1", "label_asym_id": "A", "auth_asym_id": "A"}]
    entity = descriptor["polymer_entities"][0]
    assert entity["sample_sequence_length"] == 825
    assert entity["source_organisms"] == [{"scientific_name": "Homo sapiens", "taxonomy_id": 9606}]
    assert descriptor["sequence_mapping_status"] == "UNRECONCILED_SOURCE_NAMESPACES"
    assert [item["database_range"] for item in descriptor["deposited_sequence_mappings"]] == [[1, 140], [351, 870], [1006, 1159]]
    assert [item["sample_range"] for item in descriptor["deposited_sequence_mappings"]] == [[1, 140], [141, 660], [661, 814]]
    assert len(descriptor["sequence_differences"]) == 11
    assert all(item["details"] == "expression tag" for item in descriptor["sequence_differences"])
    assert any("tetramer" in item for item in descriptor["limitations"])
    assert any("558" in item for item in descriptor["limitations"])


def test_herg_coordinates_are_exact_original_bytes():
    digest = "734a6214f786327140ceb33a7bfd8dde0fbda3382862f6fb2c709e1b45bf3e7e"
    raw, descriptor = molecular_reference.read_coordinates(digest)
    assert len(raw) == descriptor["coordinate_bytes"] == 493914
    assert hashlib.sha256(raw).hexdigest() == digest
    assert raw.startswith(b"data_5VA2\n")
    assert descriptor["asset_path"] == f"/api/molecular/structures/{digest}/coordinates"
    assert descriptor["rights"]["archive_license"] == "CC0-1.0"
