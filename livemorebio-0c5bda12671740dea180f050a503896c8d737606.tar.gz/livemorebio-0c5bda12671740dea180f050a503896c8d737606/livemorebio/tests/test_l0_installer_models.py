"""L0-R2 installer contracts using technical archives and fake tools only."""
from __future__ import annotations

from pathlib import Path
import errno
import hashlib
import json
import os
import re
import signal
import stat
import subprocess
import sys

import pytest

from livemorebio.model_assets import asset_manifest

from ._source_tree import source_tree_only
from .test_installer import (
    COMMIT_A,
    COMMIT_B,
    REPOSITORY_ROOT,
    _current_commit,
    _run,
    _verification_environments,
    installer_env,
)

pytestmark = source_tree_only("install.sh")


@pytest.mark.parametrize(
    ("selection", "expected_assets", "genome", "cardiac"),
    [
        (None, {"human-gem", "cardiac"}, "1", "1"),
        ("human-gem", {"human-gem"}, "1", "0"),
        ("cardiac", {"cardiac"}, "0", "1"),
        ("human-gem,cardiac", {"human-gem", "cardiac"}, "1", "1"),
        ("cardiac human-gem cardiac", {"human-gem", "cardiac"}, "1", "1"),
        ("none", set(), "0", "0"),
    ],
)
def test_selected_asset_set_controls_acquisition_and_verification(
    installer_env, tmp_path: Path, selection, expected_assets, genome: str, cardiac: str
) -> None:
    if selection is not None:
        installer_env["LIVEMORE_INSTALL_MODELS"] = selection
    # A caller cannot suppress an installed asset's tests or force base-only
    # verification to pretend the model was installed.
    installer_env.update({"LIVEMORE_TEST_GENOME_MODELS": "unexpected", "LIVEMORE_TEST_CARDIAC": "unexpected"})
    names = ("LIVEMORE_TEST_GENOME_MODELS", "LIVEMORE_TEST_CARDIAC")
    assert _verification_environments(installer_env, tmp_path, *names) == [
        dict(zip(names, (genome, cardiac)))
    ]
    calls = Path(installer_env["FAKE_INSTALL_LOG"]).read_text(encoding="utf-8")
    acquired = re.findall(r"venv-python -I -B -m livemorebio.model_assets install ([^\n]+)", calls)
    assert set(acquired) == expected_assets
    assert len(acquired) == len(expected_assets)


@pytest.mark.parametrize("selection", ["", " ", ",", "none,cardiac", "human-gem,recon3d", "cardiac\nnone", "*"])
def test_invalid_asset_set_refuses_before_acquisition_with_accepted_values(installer_env, selection: str) -> None:
    installer_env["LIVEMORE_INSTALL_MODELS"] = selection
    result = _run(installer_env)
    assert result.returncode != 0
    for accepted in ("human-gem", "cardiac", "none"):
        assert accepted in result.stderr
    assert not Path(installer_env["FAKE_INSTALL_LOG"]).exists()
    assert not (Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "current").exists()


@pytest.mark.parametrize("existing", [False, True])
def test_failed_default_cardiac_acquisition_never_activates(installer_env, existing: bool) -> None:
    if existing:
        assert _run(installer_env).returncode == 0
        installer_env["FAKE_GH_COMMIT"] = COMMIT_B
    calls = Path(installer_env["FAKE_INSTALL_LOG"])
    calls.write_text("", encoding="utf-8")
    installer_env["FAKE_FAIL_MODEL"] = "cardiac"
    result = _run(installer_env)
    assert result.returncode != 0
    manifest = asset_manifest("cardiac")
    for required in ("cardiac", manifest["source_url"], manifest["assets"]["cellml"]["sha256"], "LIVEMORE_INSTALL_MODELS=none"):
        assert required in result.stderr
    assert "-m pytest" not in calls.read_text(encoding="utf-8")
    if existing:
        assert _current_commit(installer_env) == COMMIT_A
    else:
        assert not (Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "current").exists()


def test_same_commit_cardiac_addition_requires_whole_gate_and_refreshes_integrity(installer_env, tmp_path: Path) -> None:
    installer_env["LIVEMORE_INSTALL_MODELS"] = "none"
    assert _run(installer_env).returncode == 0
    digest = Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "integrity" / f"{COMMIT_A}.sha256"
    before = digest.read_bytes()
    calls = Path(installer_env["FAKE_INSTALL_LOG"])
    calls.write_text("", encoding="utf-8")
    installer_env.update({"LIVEMORE_INSTALL_MODELS": "cardiac", "FAKE_MODEL_WRITES": "1"})
    assert _verification_environments(installer_env, tmp_path, "LIVEMORE_TEST_CARDIAC") == [
        {"LIVEMORE_TEST_CARDIAC": "1"}
    ]
    assert "-I -B -X utf8 -m pytest -p no:cacheprovider -q\n" in calls.read_text(encoding="utf-8")
    assert digest.read_bytes() != before
    repeated = _run(installer_env)
    assert repeated.returncode == 0, repeated.stderr
    assert _current_commit(installer_env) == COMMIT_A


def _standalone_cardiac_fixture(installer_env, monkeypatch):
    from livemorebio import model_assets
    from .test_cardiac_assets import TechnicalResponse

    installer_env["LIVEMORE_INSTALL_MODELS"] = "none"
    result = _run(installer_env)
    assert result.returncode == 0, result.stderr
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    source = install / "releases" / COMMIT_A / "source"
    path = source / "models" / "cardiac" / "ohara_rudy_cipa_2017.cellml"
    payload = b"technical-cardio-fixture"
    original = model_assets._CARDIAC_ASSET
    monkeypatch.setattr(model_assets, "_cardiac_path", lambda: path)
    monkeypatch.setattr(model_assets, "_CARDIAC_ASSET", model_assets.AssetFile(
        original.asset_id, original.filename, original.source_url,
        hashlib.sha256(payload).hexdigest(), len(payload)))
    monkeypatch.setattr(model_assets, "_open_url", lambda request, timeout:
                        TechnicalResponse(payload, request.full_url))
    return model_assets, source, path, install / "integrity" / f"{COMMIT_A}.sha256"


def test_standalone_cardiac_install_preserves_same_release_reinstall(installer_env, monkeypatch, capsys) -> None:
    from livemorebio import cli

    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    before = integrity.read_bytes()

    monkeypatch.setattr(sys, "argv", ["livemore", "models", "install", "cardiac"])
    cli.main()
    assert json.loads(capsys.readouterr().out)["available"] is True

    assert path.read_bytes() == b"technical-cardio-fixture"
    repeated = _run(installer_env)
    assert repeated.returncode == 0, repeated.stderr
    assert integrity.read_bytes() != before
    admitted = integrity.read_bytes()
    assert assets.install("cardiac")["available"] is True
    assert integrity.read_bytes() == admitted
    assert _current_commit(installer_env) == COMMIT_A


@pytest.mark.parametrize("when", ["before", "during"])
def test_standalone_cardiac_install_never_blesses_other_release_changes(installer_env, monkeypatch, when: str) -> None:
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    before = integrity.read_bytes()
    unrelated = source / "pyproject.toml"
    if when == "before":
        unrelated.write_text("technical unrelated mutation", encoding="utf-8")
    else:
        original = assets._open_url

        def mutate_during_download(request, timeout):
            unrelated.write_text("technical unrelated mutation", encoding="utf-8")
            return original(request, timeout)

        monkeypatch.setattr(assets, "_open_url", mutate_during_download)

    with pytest.raises(assets.ModelAssetError, match="integrity"):
        assets.install("cardiac")
    assert integrity.read_bytes() == before
    if when == "before":
        assert not path.exists()


def test_standalone_cardiac_install_respects_managed_installer_lock(installer_env, monkeypatch) -> None:
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    lock = install / ".install.lock"
    lock.mkdir()
    (lock / "pid").write_text(str(os.getpid()) + "\n", encoding="utf-8")
    before = integrity.read_bytes()

    with pytest.raises(assets.ModelAssetError):
        assets.install("cardiac")

    assert integrity.read_bytes() == before
    assert not path.exists()
    assert lock.is_dir()


def test_existing_cardiac_check_is_read_only_under_managed_installer_lock(installer_env, monkeypatch) -> None:
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    assert assets.install("cardiac")["available"] is True
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    lock = install / ".install.lock"
    lock.mkdir()
    (lock / "pid").write_text(str(os.getpid()) + "\n", encoding="utf-8")
    before = integrity.read_bytes()

    assert assets.install("cardiac")["available"] is True

    assert integrity.read_bytes() == before
    assert lock.is_dir()


@pytest.mark.parametrize("failure", ["download", "publication", "integrity"])
def test_standalone_cardiac_failure_preserves_release_integrity(installer_env, monkeypatch, failure: str) -> None:
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    before = integrity.read_bytes()
    if failure == "download":
        def failed_download(request, timeout):
            raise TimeoutError("technical failure")
        monkeypatch.setattr(assets, "_open_url", failed_download)
    elif failure == "publication":
        original = assets.os.link

        def failed_publication(candidate, destination, **kwargs):
            if Path(destination) == path:
                raise OSError("technical failure")
            return original(candidate, destination, **kwargs)

        monkeypatch.setattr(assets.os, "link", failed_publication)
    else:
        # Admission's commit point, whichever primitive commits it (L0-R11 round 1).
        _fail_admission(monkeypatch, integrity)

    with pytest.raises(assets.ModelAssetError):
        assets.install("cardiac")

    assert not path.exists()
    assert integrity.read_bytes() == before
    repeated = _run(installer_env)
    assert repeated.returncode == 0, repeated.stderr


@pytest.mark.parametrize("supplied", ["model", "attribution"])
def test_standalone_cardiac_rollback_keeps_files_supplied_during_download(
        installer_env, monkeypatch, supplied: str) -> None:
    # A file placed at a destination by someone else while the download is
    # pending is not this operation's creation; rollback must leave it alone.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    before = integrity.read_bytes()
    target = path if supplied == "model" else path.with_suffix(".cellml.attribution.json")
    content = b"technical independently supplied file"
    original = assets._open_url

    def supply_during_download(request, timeout):
        fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as handle:
            handle.write(content)
        return original(request, timeout)

    monkeypatch.setattr(assets, "_open_url", supply_during_download)
    with pytest.raises(assets.ModelAssetError):
        assets.install("cardiac")

    assert target.read_bytes() == content
    assert integrity.read_bytes() == before
    if supplied == "model":
        # The attribution and lock file this operation created are still removed.
        assert not path.with_suffix(".cellml.attribution.json").exists()
        assert not (path.parent / ".install.lock").exists()


def test_standalone_cardiac_keeps_admitted_files_if_integrity_sync_fails(installer_env, monkeypatch) -> None:
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    before = integrity.read_bytes()
    original = assets._sync_directory

    def failed_sync(directory):
        if directory == integrity.parent:
            raise OSError("technical failure after replacement")
        return original(directory)

    monkeypatch.setattr(assets, "_sync_directory", failed_sync)
    with pytest.raises(assets.ModelAssetError, match="integrity"):
        assets.install("cardiac")

    assert path.read_bytes() == b"technical-cardio-fixture"
    assert integrity.read_bytes() != before
    repeated = _run(installer_env)
    assert repeated.returncode == 0, repeated.stderr


@pytest.mark.parametrize("unsafe", ["symlink", "hardlink", "unowned_marker"])
def test_standalone_cardiac_refuses_unsafe_managed_integrity(installer_env, monkeypatch, unsafe: str) -> None:
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    original = integrity.read_bytes()
    if unsafe == "symlink":
        target = integrity.with_suffix(".technical-backup")
        integrity.rename(target)
        integrity.symlink_to(target.name)
    elif unsafe == "hardlink":
        os.link(integrity, integrity.with_suffix(".technical-link"))
    else:
        marker = integrity.parent / ".livemore-installer-owned-v1"
        marker.write_text("technical unrecognized marker\n", encoding="utf-8")

    with pytest.raises(assets.ModelAssetError, match="integrity"):
        assets.install("cardiac")

    assert not path.exists()
    assert integrity.read_bytes() == original


@pytest.mark.parametrize("gate_fails", [False, True])
def test_cardiac_upgrade_verifies_detached_source_before_publishing(installer_env, gate_fails: bool) -> None:
    installer_env["LIVEMORE_INSTALL_MODELS"] = "none"
    assert _run(installer_env).returncode == 0
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    source = install / "releases" / COMMIT_A / "source"
    before = {path.relative_to(source): path.read_bytes() for path in source.rglob("*") if path.is_file()}
    digest = install / "integrity" / f"{COMMIT_A}.sha256"
    before_digest = digest.read_bytes()
    model = source / "models" / "cardiac" / "ohara_rudy_cipa_2017.cellml"
    installer_env.update({
        "LIVEMORE_INSTALL_MODELS": "cardiac", "FAKE_MODEL_WRITES": "1",
        "FAKE_VERIFY_ACTIVE_BASE": str(model),
    })
    if gate_fails:
        installer_env["FAKE_FAIL_PHASE"] = "pytest"

    result = _run(installer_env)

    after = {path.relative_to(source): path.read_bytes() for path in source.rglob("*") if path.is_file()}
    assert _current_commit(installer_env) == COMMIT_A
    assert not list((install / "releases").glob(".*.models.*"))
    if gate_fails:
        assert result.returncode != 0
        assert after == before
        assert digest.read_bytes() == before_digest
    else:
        assert result.returncode == 0, result.stderr
        assert model.read_text(encoding="utf-8") == "technical-cardio-fixture"
        for relative, data in before.items():
            assert after[relative] == data
        assert digest.read_bytes() != before_digest


def test_cardiac_publication_rechecks_pins_after_the_gate(installer_env) -> None:
    # The fake interpreter must honor the installer's -B itself; an inherited
    # environment switch would hide a harness that merely discards that flag.
    installer_env.pop("PYTHONDONTWRITEBYTECODE", None)
    installer_env["LIVEMORE_INSTALL_MODELS"] = "none"
    assert _run(installer_env).returncode == 0
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    source = install / "releases" / COMMIT_A / "source"
    before = {path.relative_to(source): path.read_bytes() for path in source.rglob("*") if path.is_file()}
    digest = install / "integrity" / f"{COMMIT_A}.sha256"
    before_digest = digest.read_bytes()
    installer_env.update({"LIVEMORE_INSTALL_MODELS": "cardiac", "FAKE_POST_GATE_CORRUPT_CARDIAC": "1"})

    result = _run(installer_env)

    assert result.returncode != 0
    assert "CARDIAC_MODEL_HASH_MISMATCH" in result.stderr
    assert {path.relative_to(source): path.read_bytes() for path in source.rglob("*") if path.is_file()} == before
    assert digest.read_bytes() == before_digest
    assert _current_commit(installer_env) == COMMIT_A


@pytest.mark.parametrize("foreign", ["staged", "retained"])
def test_cardiac_publication_refuses_foreign_owned_entries(tmp_path: Path, monkeypatch, foreign: str) -> None:
    """Technical file metadata only; no owner or permission is changed on disk."""
    from . import test_installer

    payload = b"technical-cardio-fixture"
    original = tmp_path / "technical-original"
    package = original / "livemorebio"
    package.mkdir(parents=True)
    asset = {"filename": "technical.cellml", "size_bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}
    (package / "model_assets.py").write_text(
        f'def asset_manifest(model_id):\n    return {{"assets": {{"cellml": {asset!r}}}}}\n', encoding="utf-8")
    staged, retained = tmp_path / "technical-staged", tmp_path / "technical-retained"
    staged.mkdir()
    retained.mkdir()
    source, destination = staged / asset["filename"], retained / asset["filename"]
    source.write_bytes(payload)
    (staged / (source.name + ".attribution.json")).write_text("technical-attribution", encoding="utf-8")
    (staged / ".install.lock").write_bytes(b"")
    if foreign == "retained":
        destination.write_bytes(payload)
    foreign_inode = (source if foreign == "staged" else destination).stat().st_ino
    actual_fstat = os.fstat

    def technical_foreign_owner(descriptor: int):
        info = actual_fstat(descriptor)
        if info.st_ino == foreign_inode:
            fields = list(info)
            fields[4] = os.getuid() + 1
            return os.stat_result(fields)
        return info

    monkeypatch.setattr(os, "fstat", technical_foreign_owner)
    monkeypatch.setattr(sys, "argv", ["technical-publication", str(source), str(destination), str(original)])
    installer = test_installer.INSTALLER.read_text(encoding="utf-8")
    program = installer.split("publish_staged_cardiac_upgrade() {", 1)[1].split("<<'PY'\n", 1)[1].split("\nPY\n", 1)[0]
    before = {path.name: path.read_bytes() for path in retained.iterdir()}
    with pytest.raises(ValueError, match="owned|differs"):
        exec(compile(program, "<technical-cardiac-publication>", "exec"), {"__name__": "__main__"})
    assert {path.name: path.read_bytes() for path in retained.iterdir()} == before


@pytest.mark.parametrize("selection", ["none", "human-gem"])
def test_retained_cardiac_asset_is_verified_without_acquiring_it_again(installer_env, tmp_path: Path, selection: str) -> None:
    installer_env["FAKE_MODEL_WRITES"] = "1"
    assert _run(installer_env).returncode == 0
    installer_env["LIVEMORE_INSTALL_MODELS"] = selection
    calls = Path(installer_env["FAKE_INSTALL_LOG"])
    calls.write_text("", encoding="utf-8")

    assert _verification_environments(installer_env, tmp_path, "LIVEMORE_TEST_CARDIAC") == [
        {"LIVEMORE_TEST_CARDIAC": "1"}
    ]
    logged = calls.read_text(encoding="utf-8")
    assert "-m livemorebio.model_assets install cardiac" not in logged
    assert "-I -B -X utf8 -m pytest -p no:cacheprovider -q\n" in logged
    if selection == "none":
        assert "-m livemorebio.model_assets install" not in logged


@pytest.mark.parametrize("selection", ["none", "human-gem"])
def test_retained_cardiac_mismatch_cannot_bypass_integrity(installer_env, selection: str) -> None:
    installer_env["FAKE_MODEL_WRITES"] = "1"
    assert _run(installer_env).returncode == 0
    source = Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "releases" / COMMIT_A / "source"
    model = source / "models" / "cardiac" / "ohara_rudy_cipa_2017.cellml"
    model.write_text("technical-deliberately-mismatched-cardiac", encoding="utf-8")
    installer_env["LIVEMORE_INSTALL_MODELS"] = selection
    calls = Path(installer_env["FAKE_INSTALL_LOG"])
    calls.write_text("", encoding="utf-8")

    result = _run(installer_env)

    assert result.returncode != 0
    assert "integrity verification failed" in result.stderr
    assert "-m livemorebio.model_assets install" not in calls.read_text(encoding="utf-8")
    assert "-m pytest" not in calls.read_text(encoding="utf-8")
    assert _current_commit(installer_env) == COMMIT_A


@source_tree_only(".github/workflows/installer.yml", ".github/workflows/platforms.yml", ".github/workflows/stable-fresh-install.yml", "Dockerfile")
def test_every_hosted_job_and_image_gate_requires_pinned_cardiac() -> None:
    for workflow in ("installer", "platforms", "stable-fresh-install"):
        source = (REPOSITORY_ROOT / ".github/workflows" / f"{workflow}.yml").read_text(encoding="utf-8")
        jobs = re.split(r"^  [a-z][a-z-]+:\n", source.split("jobs:\n", 1)[1], flags=re.M)[1:]
        assert jobs
        for job in jobs:
            env = job.split("    steps:\n", 1)[0]
            assert '      LIVEMORE_TEST_CARDIAC: "1"\n' in env
    native = (REPOSITORY_ROOT / ".github/workflows/installer.yml").read_text(encoding="utf-8")
    assert "python -m livemorebio.model_assets install cardiac" in native
    assert "python -m livemorebio.model_assets check cardiac" in native
    assert native.index("model_assets check cardiac") < native.index("- name: Run complete release gate")
    dockerfile = (REPOSITORY_ROOT / "Dockerfile").read_text(encoding="utf-8").replace("\\\n", " ")
    (suite,) = [line for line in dockerfile.splitlines() if line.startswith("RUN ") and "-m pytest" in line]
    assert "LIVEMORE_TEST_CARDIAC=1" in suite
    scheduled = (REPOSITORY_ROOT / ".github/workflows/stable-fresh-install.yml").read_text(encoding="utf-8").replace("\\\n", " ")
    assert "env -i PATH=\"$PATH\" LANG=en_US.UTF-8 PYTHONUTF8=1" in scheduled
    assert re.search(r"timeout 100m env -i [^\n]+LIVEMORE_TEST_CARDIAC=1", scheduled)


# L0-R11. Rollback records before it acts and deletes only by moving an entry
# aside into a private directory and verifying its identity there.
# Round 2: the new integrity record is made inside the operation's private
# record directory, so no other process may write at its name (the stated
# boundary); test_l0_r11_round2_admission_never_publishes_a_file_put_at_its_new_records_name
# covers a file put there anyway.
_R11_ENTRIES = ("model", "attribution", "lock", "managed_lock")
_RESTORE_COMMAND = "python -m livemorebio.model_assets restore cardiac"


def _r11_target(entry: str, path: Path, install: Path):
    """The path an entry lives at, or a predicate for one with a random name."""
    if entry == "model":
        return path
    if entry == "attribution":
        return path.with_suffix(".cellml.attribution.json")
    if entry == "lock":
        return path.parent / ".install.lock"
    if entry == "managed_lock":
        return install / ".install.lock"
    return lambda candidate: (candidate.parent == install / "integrity"
                              and candidate.name.startswith(".cardiac-integrity-"))


def _release_is_valid(assets, install: Path) -> bool:
    release = install / "releases" / COMMIT_A
    recorded = (install / "integrity" / f"{COMMIT_A}.sha256").read_text(encoding="ascii")
    return recorded == assets._release_entries_digest(assets._release_entries(release)) + "\n"


def _no_aside(install: Path) -> list[str]:
    return sorted(entry.relative_to(install).as_posix() for entry in install.rglob(".livemore-aside-*"))


def _watch_rollback(monkeypatch, integrity: Path, touches, act):
    """Fail admission so rollback runs. Around the first call with which rollback
    touches the entry, call act(path, original, "before") and then "after"."""
    state = {"rolling_back": False, "done": False}
    names = ("stat", "lstat", "open", "rename", "unlink", "rmdir", "link")
    original = {name: getattr(os, name) for name in names + ("replace",)}

    def watch(name):
        def call(*args, **kwargs):
            if name == "link" and len(args) > 1 and _admission_commit(args[0], args[1], integrity):
                state["rolling_back"] = True
                raise OSError(errno.EIO, "technical failure at admission")
            subject = args[0] if args and isinstance(args[0], (str, os.PathLike)) else None
            hit = (state["rolling_back"] and not state["done"] and subject is not None
                   and touches(Path(subject)))
            if hit:
                state["done"] = True
                act(Path(subject), original, "before")
            try:
                return original[name](*args, **kwargs)
            finally:
                if hit:
                    act(Path(subject), original, "after")
        return call

    def failed_admission(candidate, destination, **kwargs):
        if Path(destination) == integrity:
            state["rolling_back"] = True
            raise OSError("technical failure before admission")
        return original["replace"](candidate, destination, **kwargs)

    for name in names:
        monkeypatch.setattr(os, name, watch(name))
    monkeypatch.setattr(os, "replace", failed_admission)
    state["original"] = original
    return state


@pytest.mark.parametrize("moment", ["before", "after"])
@pytest.mark.parametrize("entry", _R11_ENTRIES)
def test_l0_r11_rollback_keeps_an_entry_replaced_at_its_path(
        installer_env, monkeypatch, tmp_path, entry: str, moment: str) -> None:
    # Someone replaces this operation's entry just before, or just after,
    # rollback first touches its path. Rollback must keep their entry.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    before = integrity.read_bytes()
    target = _r11_target(entry, path, install)
    touches = target if callable(target) else (lambda candidate: candidate == target)
    replacement = b"technical replacement supplied by another process"
    supplied = {}

    def replace(at: Path, original) -> None:
        try:
            original["lstat"](at)
        except FileNotFoundError:
            pass
        else:
            original["rename"](at, tmp_path / f"technical-displaced-{at.name}")
        if entry == "managed_lock":
            os.mkdir(at, 0o700)  # an empty lock directory, as a fresh installer makes
        else:
            staged = tmp_path / "technical-replacement"
            staged.write_bytes(replacement)
            original["rename"](staged, at)
        supplied["path"] = at
        supplied["identity"] = original["stat"](at, follow_symlinks=False).st_ino

    state = _watch_rollback(monkeypatch, integrity, touches,
                            lambda at, original, phase: replace(at, original) if phase == moment else None)
    with pytest.raises(assets.ModelAssetError):
        assets.install("cardiac")
    for name, function in state["original"].items():
        monkeypatch.setattr(os, name, function)

    assert state["done"], "rollback never touched the entry"
    kept = supplied["path"]
    assert kept.exists(), f"rollback deleted the {entry} supplied {moment} it acted"
    assert kept.stat().st_ino == supplied["identity"]
    if entry != "managed_lock":
        assert kept.read_bytes() == replacement
    assert integrity.read_bytes() == before
    assert _no_aside(install) == []
    for other in ("model", "attribution", "lock"):
        candidate = _r11_target(other, path, install)
        if other != entry:
            assert not candidate.exists(), f"this operation's {other} was left behind"


def test_l0_r11_retaken_name_keeps_both_files_and_the_restore_command_puts_back(
        installer_env, monkeypatch, tmp_path, capsys) -> None:
    from livemorebio import cli

    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    displaced = b"technical file supplied before rollback"
    retaken = b"technical file that took the name again during the restore"

    def act(at: Path, original, phase: str) -> None:
        if phase == "before":
            # Someone else's file replaces this operation's model.
            staged = tmp_path / "technical-displaced"
            staged.write_bytes(displaced)
            original["rename"](at, tmp_path / "technical-original-model")
            original["rename"](staged, at)
            return
        # Once rollback has acted, the name is taken again if it is free.
        try:
            descriptor = os.open(at, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            return
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(retaken)

    state = _watch_rollback(monkeypatch, integrity, lambda candidate: candidate == path, act)
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install("cardiac")
    for name, function in state["original"].items():
        monkeypatch.setattr(os, name, function)

    message = str(refused.value)
    assert refused.value.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{refused.value.code}: {message}"
    assert _RESTORE_COMMAND in message
    (aside,) = sorted(path.parent.glob(".livemore-aside-*"))
    assert str(aside) in message
    assert (aside / path.name).read_bytes() == displaced
    assert path.read_bytes() == retaken

    # The next check and install report the aside directory with the same command.
    assert assets.main(["check", "cardiac"]) == 2
    reported = json.loads(capsys.readouterr().out)["error"]
    assert reported["code"] == "CARDIAC_MODEL_ASIDE_PENDING"
    assert _RESTORE_COMMAND in reported["message"] and str(aside) in reported["message"]
    monkeypatch.setattr(sys, "argv", ["livemore", "models", "check", "cardiac"])
    with pytest.raises(SystemExit):
        cli.main()
    assert json.loads(capsys.readouterr().out)["code"] == "CARDIAC_MODEL_ASIDE_PENDING"
    with pytest.raises(assets.ModelAssetError) as again:
        assets.install("cardiac")
    assert again.value.code == "CARDIAC_MODEL_ASIDE_PENDING" and _RESTORE_COMMAND in str(again.value)

    # While the name is still taken, restore refuses, says so, and keeps both files.
    assert assets.main(["restore", "cardiac"]) == 2
    refusal = json.loads(capsys.readouterr().out)["error"]
    assert refusal["code"] == "CARDIAC_MODEL_ASIDE_PENDING"
    assert "taken" in refusal["message"] and str(aside / path.name) in refusal["message"]
    assert path.read_bytes() == retaken and (aside / path.name).read_bytes() == displaced

    # Once the person frees the name, the product command puts the file back.
    path.rename(tmp_path / "technical-moved-by-the-person")
    monkeypatch.setattr(sys, "argv", ["livemore", "models", "restore", "cardiac"])
    cli.main()
    restored = json.loads(capsys.readouterr().out)
    assert restored["restored"] == [str(path)]
    assert path.read_bytes() == displaced
    assert _no_aside(install) == []
    assert assets.main(["check", "cardiac"]) == 2
    assert json.loads(capsys.readouterr().out)["error"]["code"] != "CARDIAC_MODEL_ASIDE_PENDING"


def test_l0_r11_install_under_umask_0400_succeeds_or_leaves_no_lock(installer_env, monkeypatch) -> None:
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    before = integrity.read_bytes()
    lock = path.parent / ".install.lock"
    previous = os.umask(0o400)
    try:
        try:
            result = assets.install("cardiac")
        except assets.ModelAssetError as error:
            result = error
    finally:
        os.umask(previous)
    if isinstance(result, assets.ModelAssetError):
        assert not (lock.exists() or lock.is_symlink()), (
            f"{result.code}: the failed install left the lock it created")
        assert not path.exists()
        assert integrity.read_bytes() == before
    else:
        assert result["available"] is True
        assert stat.S_IMODE(lock.stat().st_mode) == 0o600
        assert integrity.read_bytes() != before
    assert not (install / ".install.lock").exists()
    assert _release_is_valid(assets, install)
    assert assets.install("cardiac")["available"] is True
    repeated = _run(installer_env)
    assert repeated.returncode == 0, repeated.stderr


def _tree(root: Path) -> dict[str, str]:
    entries = {}
    for entry in sorted(root.rglob("*")):
        info = entry.lstat()
        relative = entry.relative_to(root).as_posix()
        if stat.S_ISLNK(info.st_mode):
            entries[relative] = "L"
        elif stat.S_ISDIR(info.st_mode):
            entries[relative] = f"D{stat.S_IMODE(info.st_mode):o}"
        else:
            entries[relative] = f"F{stat.S_IMODE(info.st_mode):o}:" + hashlib.sha256(entry.read_bytes()).hexdigest()
    return entries


@pytest.mark.parametrize("run", ["success", "failure"])
def test_l0_r11_interrupt_at_every_step_of_publication_and_rollback(
        installer_env, monkeypatch, tmp_path, run: str) -> None:
    import shutil

    from .test_model_assets import StepInterrupts, _report, sweep_every_step

    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    pristine = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    relative = path.relative_to(pristine)
    copies = iter(range(10**6))
    state = {}

    def prepare():
        install = tmp_path / f"technical-release-{next(copies)}"
        shutil.copytree(pristine, install, symlinks=True)
        monkeypatch.setattr(assets, "_cardiac_path", lambda: install / relative)
        state["install"] = install

    if run == "failure":
        original_replace, original_link = os.replace, os.link

        def failed_admission(candidate, destination, **kwargs):
            if Path(destination).name == f"{COMMIT_A}.sha256":
                raise OSError("technical failure before admission")
            return original_replace(candidate, destination, **kwargs)

        def failed_admission_link(candidate, destination, *args, **kwargs):
            if (Path(os.fsdecode(destination)).name == f"{COMMIT_A}.sha256"
                    and Path(os.fsdecode(candidate)).name.startswith(".cardiac-integrity-")):
                raise OSError("technical failure before admission")
            return original_link(candidate, destination, *args, **kwargs)

        monkeypatch.setattr(os, "replace", failed_admission)
        monkeypatch.setattr(os, "link", failed_admission_link)

    # The two end states every interruption may leave: untouched, or committed.
    prepare()
    untouched = _tree(state["install"])
    prepare()
    if run == "success":
        assert assets.install("cardiac")["available"] is True
    else:
        with pytest.raises(assets.ModelAssetError):
            assets.install("cardiac")
    finished = {name: kind.split(":")[0] for name, kind in _tree(state["install"]).items()}
    steps = StepInterrupts(monkeypatch)

    def verify(outcome):
        install = state["install"]
        after = _tree(install)
        if after == untouched:
            return None
        shape = {name: kind.split(":")[0] for name, kind in after.items()}
        if run == "failure" or shape != finished:
            extra = sorted(set(after) - set(untouched))
            missing = sorted(set(untouched) - set(after))
            changed = sorted(name for name in set(after) & set(untouched) if after[name] != untouched[name])
            return f"neither untouched nor committed: extra={extra} missing={missing} changed={changed}"
        if (install / relative).read_bytes() != b"technical-cardio-fixture":
            return "the committed model is not the pinned bytes"
        if not _release_is_valid(assets, install):
            return "the committed release does not match its integrity record"
        return None

    labels, failures = sweep_every_step(steps, prepare, lambda: assets.install("cardiac"), verify)
    assert labels, "the operation made no filesystem calls"
    assert not failures, _report(labels, failures)


# L0-R11 round 1. Each case below is a defect the adversarial verifiers
# reproduced in build part 10, turned into a test that fails on that build.
_THEIRS = b"technical bytes written by another process of the same account\n"


@pytest.fixture
def faults():
    """Fault injection on its own patcher: undoing it never undoes the fixture's
    redirection of the cardiac path to the technical release."""
    patch = pytest.MonkeyPatch()
    yield patch
    patch.undo()


def _admission_commit(source, destination, integrity: Path) -> bool:
    """Whether a call publishes the new integrity record: admission's commit point."""
    return (Path(os.fsdecode(destination)) == integrity
            and Path(os.fsdecode(source)).name.startswith(".cardiac-integrity-"))


def _fail_admission(monkeypatch, integrity: Path, before=None) -> dict:
    """Admission fails at its commit point, whichever primitive commits it: an
    os.replace onto the record (build part 10) or a no-overwrite link (round 1).
    `before` runs once, just before the failure."""
    state = {"failed": False}
    replace, link = os.replace, os.link

    def fail():
        if not state["failed"] and before is not None:
            before()
        state["failed"] = True
        raise OSError(errno.EIO, "technical failure at admission")

    def failed_replace(source, destination, *args, **kwargs):
        if Path(os.fsdecode(destination)) == integrity:
            fail()
        return replace(source, destination, *args, **kwargs)

    def failed_link(source, destination, *args, **kwargs):
        if _admission_commit(source, destination, integrity):
            fail()
        return link(source, destination, *args, **kwargs)

    monkeypatch.setattr(os, "replace", failed_replace)
    monkeypatch.setattr(os, "link", failed_link)
    return state


def _write_theirs(at: Path, data: bytes = _THEIRS) -> None:
    descriptor = os.open(at, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(data)


def _left_entries(install: Path, untouched: dict[str, str]) -> list[str]:
    """Entries the operation left, apart from the rollback record it wrote for restore."""
    return sorted(name for name in set(_tree(install)) - set(untouched)
                  if not name.split("/")[-1].startswith(".livemore-rollback-")
                  and "/.livemore-rollback-" not in "/" + name)


def _recover(assets) -> str:
    """Follow the product: a pending state is reported with the restore command, which finishes it."""
    try:
        assets.check("cardiac")
    except assets.ModelAssetError as error:
        assert error.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{error.code}: {error}"
        assert _RESTORE_COMMAND in str(error)
        assets.restore("cardiac")
        return "restored"
    return "clean"


class _InodeReuse:
    """Linux (ext4, overlay on ext4) gives a freed inode number to the next new
    entry; verifier logs linux-1..3 show it 3 times in 3. This models it.

    A new entry is reported under the freed number only when the kernel could
    reuse it: the old inode has no link left and no open descriptor of this
    process (the only process involved) still holds it.
    """

    def __init__(self, monkeypatch):
        self.real = {name: getattr(os, name) for name in ("lstat", "stat", "fstat", "listdir", "unlink", "rmdir")}
        self.reused: dict[tuple[int, int], int] = {}
        monkeypatch.setattr(os, "lstat", self._reported(self.real["lstat"]))
        monkeypatch.setattr(os, "stat", self._reported(self.real["stat"]))

    def _reported(self, original):
        def call(*args, **kwargs):
            info = original(*args, **kwargs)
            old = self.reused.get((info.st_dev, info.st_ino))
            if old is None:
                return info
            fields = list(info)
            fields[stat.ST_INO] = old
            return os.stat_result(fields)
        return call

    def _held(self, device: int, inode: int) -> bool:
        for name in self.real["listdir"]("/dev/fd"):
            try:
                info = self.real["fstat"](int(name))
            except (OSError, ValueError):
                continue
            if (info.st_dev, info.st_ino) == (device, inode):
                return True
        return False

    def replace(self, path: Path, make) -> tuple[int, int, bool]:
        """Delete the entry at path and let `make` create another there."""
        info = self.real["lstat"](path)
        directory = stat.S_ISDIR(info.st_mode)
        freed = not self._held(info.st_dev, info.st_ino) and (directory or info.st_nlink == 1)
        (self.real["rmdir"] if directory else self.real["unlink"])(path)
        make(path)
        new = self.real["lstat"](path)
        if freed:
            self.reused[(new.st_dev, new.st_ino)] = info.st_ino
        return info.st_ino, new.st_ino, freed


@pytest.mark.parametrize("entry", ["model", "attribution", "lock", "symlink", "directory", "model-before-verification"])
def test_l0_r11_round1_a_reused_inode_number_never_passes_for_this_operations_entry(
        installer_env, monkeypatch, faults, tmp_path, entry: str) -> None:
    # Another process deletes this operation's entry and creates its own at the
    # same name. Its new entry may get the freed inode number; rollback must
    # still keep it, because an identity it holds open cannot be reused.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    before = integrity.read_bytes()
    target = {"model": path, "symlink": path, "model-before-verification": path,
              "attribution": path.with_suffix(".cellml.attribution.json"),
              "lock": path.parent / ".install.lock", "directory": path.parent}[entry]
    elsewhere = tmp_path / "technical-their-target"
    elsewhere.write_bytes(_THEIRS)

    def make(at: Path) -> None:
        if entry == "directory":
            os.mkdir(at, 0o755)
        elif entry == "symlink":
            os.symlink(elsewhere, at)
        else:
            _write_theirs(at)

    state = {"failed": True} if entry == "model-before-verification" else _fail_admission(faults, integrity)
    reuse = _InodeReuse(faults)
    seen: dict = {}
    rename, opened = os.rename, os.open

    def watched_rename(source_, destination, *args, **kwargs):
        if (entry != "model-before-verification" and state["failed"] and "numbers" not in seen
                and isinstance(source_, (str, os.PathLike)) and Path(os.fsdecode(source_)) == target):
            seen["numbers"] = reuse.replace(target, make)
        return rename(source_, destination, *args, **kwargs)

    def watched_open(file, flags, *args, **kwargs):
        # The installer's own verification of the published model reads it here.
        if (entry == "model-before-verification" and "numbers" not in seen and not flags & os.O_CREAT
                and isinstance(file, (str, os.PathLike)) and Path(os.fsdecode(file)) == target
                and "dir_fd" not in kwargs):
            seen["numbers"] = reuse.replace(target, make)
        return opened(file, flags, *args, **kwargs)

    faults.setattr(os, "rename", watched_rename)
    faults.setattr(os, "open", watched_open)
    with pytest.raises(assets.ModelAssetError):
        assets.install("cardiac")
    faults.undo()

    assert "numbers" in seen, "the other process never acted"
    _, theirs, _ = seen["numbers"]
    assert target.is_symlink() if entry == "symlink" else target.exists(), (
        f"rollback deleted the other process's {entry}")
    assert os.lstat(target).st_ino == theirs
    if entry == "symlink":
        assert os.readlink(target) == str(elsewhere)
    elif entry != "directory":
        assert target.read_bytes() == _THEIRS
    assert integrity.read_bytes() == before
    assert _no_aside(install) == []


def test_l0_r11_round1_admission_keeps_a_record_replaced_just_before_it_commits(
        installer_env, monkeypatch, faults, tmp_path) -> None:
    # Verifier integrity_replaced: admission compared the record, then
    # os.replace()d it, destroying a record another process put there between.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    theirs = b"technical integrity record written by another process\n"
    state: dict = {}
    replace, rename = os.replace, os.rename

    def swap() -> None:
        if "inode" in state:
            return
        staged = tmp_path / "technical-their-record"
        staged.write_bytes(theirs)
        rename(staged, integrity)
        state["inode"] = os.lstat(integrity).st_ino

    def watched_replace(source_, destination, *args, **kwargs):
        if Path(os.fsdecode(destination)) == integrity:
            swap()
        return replace(source_, destination, *args, **kwargs)

    def watched_rename(source_, destination, *args, **kwargs):
        if isinstance(source_, (str, os.PathLike)) and Path(os.fsdecode(source_)) == integrity:
            swap()
        return rename(source_, destination, *args, **kwargs)

    faults.setattr(os, "replace", watched_replace)
    faults.setattr(os, "rename", watched_rename)
    with pytest.raises(assets.ModelAssetError):
        assets.install("cardiac")
    faults.undo()

    assert "inode" in state, "admission never reached its commit point"
    assert os.lstat(integrity).st_ino == state["inode"], "admission destroyed the other process's record"
    assert integrity.read_bytes() == theirs
    assert not path.exists()
    assert _no_aside(install) == []
    assert not list((install / "integrity").glob(".cardiac-integrity-*"))


_CHILD = r'''
import errno, hashlib, io, os, signal, sys
from pathlib import Path
from livemorebio import model_assets as assets

class Response(io.BytesIO):
    status = 200
    def __init__(self, data, url):
        super().__init__(data)
        self.url, self.headers = url, {"Content-Length": str(len(data))}
    def geturl(self):
        return self.url

path, mode, argv = Path(sys.argv[1]), sys.argv[2], sys.argv[3:]
payload = b"technical-cardio-fixture"
original = assets._CARDIAC_ASSET
assets._cardiac_path = lambda: path
assets._CARDIAC_ASSET = assets.AssetFile(original.asset_id, original.filename, original.source_url,
                                         hashlib.sha256(payload).hexdigest(), len(payload))
assets._open_url = lambda request, timeout: Response(payload, request.full_url)
if mode == "killed-once-the-managed-lock-is-aside":
    install = path.parents[5]
    integrity = install / "integrity" / (path.parents[3].name + ".sha256")
    lock = install / ".install.lock"
    replace, link, rename = os.replace, os.link, os.rename
    def failed_replace(source, destination, *args, **kwargs):
        if Path(os.fsdecode(destination)) == integrity:
            raise OSError(errno.EIO, "technical failure at admission")
        return replace(source, destination, *args, **kwargs)
    def failed_link(source, destination, *args, **kwargs):
        if (Path(os.fsdecode(destination)) == integrity
                and Path(os.fsdecode(source)).name.startswith(".cardiac-integrity-")):
            raise OSError(errno.EIO, "technical failure at admission")
        return link(source, destination, *args, **kwargs)
    def killed_rename(source, destination, *args, **kwargs):
        result = rename(source, destination, *args, **kwargs)
        if isinstance(source, (str, os.PathLike)) and Path(os.fsdecode(source)) == lock:
            os.kill(os.getpid(), signal.SIGKILL)
        return result
    os.replace, os.link, os.rename = failed_replace, failed_link, killed_rename
raise SystemExit(assets.main(argv))
'''


def _child(path: Path, mode: str, *argv: str) -> tuple[int, dict]:
    """The model-assets command in a separate process, as another person or installer runs it."""
    from .test_installer import REPOSITORY_ROOT

    result = subprocess.run([sys.executable, "-c", _CHILD, str(path), mode, *argv], cwd=REPOSITORY_ROOT,
                            capture_output=True, text=True, encoding="utf-8", timeout=300, check=False)
    output = result.stdout.strip()
    return result.returncode, (json.loads(output) if output else {"stderr": result.stderr[-2000:]})


def test_l0_r11_round1_another_command_during_a_rollback_is_refused_busy(installer_env, monkeypatch, faults) -> None:
    # Verifier followed_instruction_chain: a second install saw the first
    # rollback's aside and gave the restore command; running it put the first
    # operation's own model back while that rollback was still running.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    state = _fail_admission(faults, integrity)
    seen: dict = {}
    rename = os.rename

    def watched_rename(source_, destination, *args, **kwargs):
        result = rename(source_, destination, *args, **kwargs)
        if (state["failed"] and not seen and isinstance(source_, (str, os.PathLike))
                and Path(os.fsdecode(source_)) == path):
            for command in ("install", "check", "restore"):
                seen[command] = _child(path, "plain", command, "cardiac")
        return result

    faults.setattr(os, "rename", watched_rename)
    with pytest.raises(assets.ModelAssetError):
        assets.install("cardiac")
    faults.undo()

    assert seen, "rollback never moved the model"
    for command, (code, output) in seen.items():
        assert code == 2 and output.get("error", {}).get("code") == "CARDIAC_MODEL_INSTALL_BUSY", (command, output)
    assert not path.exists()
    assert _release_is_valid(assets, install)
    assert _no_aside(install) == []


def test_l0_r11_round1_restore_finishes_a_killed_rollback_and_never_reinstates_its_lock(installer_env, monkeypatch) -> None:
    # Verifier exp9: SIGKILL after rollback moved the managed lock aside; restore
    # put the dead process's lock back and every later install was busy.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    lock = install / ".install.lock"
    code, _ = _child(path, "killed-once-the-managed-lock-is-aside", "install", "cardiac")
    assert code == -signal.SIGKILL
    assert not lock.exists() and _no_aside(install), "the child was not killed with its lock aside"
    assert _release_is_valid(assets, install)

    with pytest.raises(assets.ModelAssetError) as pending:
        assets.check("cardiac")
    assert pending.value.code == "CARDIAC_MODEL_ASIDE_PENDING" and _RESTORE_COMMAND in str(pending.value)
    assets.restore("cardiac")
    assert not lock.exists(), "restore put the dead installer's lock back"
    assert _no_aside(install) == []
    assert assets.install("cardiac")["available"] is True
    assert _release_is_valid(assets, install)


@pytest.mark.parametrize("fills_at", ["attribution", "integrity record"])
def test_l0_r11_round1_rollback_on_a_filling_volume_frees_its_own_data_first(
        installer_env, monkeypatch, faults, fills_at: str) -> None:
    # Verifier exp2b (real nearly full HFS+ image, 99-100 free blocks): the
    # attribution meets a full volume; rollback needed a new aside directory
    # before it could delete anything, so every entry stayed and no product
    # command could repair it. At 101 free blocks the new integrity record meets
    # it instead, after publication, when no staged data is left to delete.
    from .test_model_assets import FillingVolume

    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    fills = {"attribution": lambda candidate: (
                 candidate.name.endswith(".attribution.json") and candidate.parent.name.startswith(".install-cardiac-")),
             "integrity record": lambda candidate: candidate.name.startswith(".cardiac-integrity-")}[fills_at]
    volume = FillingVolume(faults, fills)
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install("cardiac")
    assert volume.freed and not volume.full, "rollback never deleted its own data"
    expected = "CARDIAC_MODEL_INSTALL_FAILED" if fills_at == "attribution" else "CARDIAC_MODEL_INSTALL_INTEGRITY"
    assert refused.value.code == expected, f"{refused.value.code}: {refused.value}"
    assert "Rollback" not in str(refused.value), str(refused.value)
    assert _tree(install) == untouched
    assert _release_is_valid(assets, install)
    assert assets.install("cardiac")["available"] is True
    faults.undo()
    repeated = _run(installer_env)
    assert repeated.returncode == 0, repeated.stderr


@pytest.mark.parametrize("moment", ["download", "admission"])
def test_l0_r11_round1_entries_a_read_only_directory_keeps_are_recorded_and_restore_finishes(
        installer_env, monkeypatch, faults, moment: str) -> None:
    # Verifier readonly_model_directory and real full disk: rollback could not
    # move entries aside, named none with a command (the staging directory not
    # at all), and check later said available while the release was invalid.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    cardiac = path.parent

    def read_only() -> None:
        os.chmod(cardiac, 0o555)

    if moment == "download":
        def failed(request, timeout):
            read_only()
            raise TimeoutError("technical failure")
        monkeypatch.setattr(assets, "_open_url", failed)
    else:
        _fail_admission(faults, integrity, before=read_only)
    try:
        with pytest.raises(assets.ModelAssetError) as refused:
            assets.install("cardiac")
    finally:
        if cardiac.is_dir():
            os.chmod(cardiac, 0o755)  # the person restores the permission
    message = str(refused.value)
    assert refused.value.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{refused.value.code}: {message}"
    assert _RESTORE_COMMAND in message
    left = _left_entries(install, untouched)
    assert left, "nothing was left; the case did not exercise a refused move"
    for name in left:
        assert str(install / name) in message, f"{name} is left but the refusal does not name it"

    assert _recover(assets) == "restored"
    assert _tree(install) == untouched
    assert _release_is_valid(assets, install)
    faults.undo()
    assert assets.check("cardiac")["available"] is False
    repeated = _run(installer_env)
    assert repeated.returncode == 0, repeated.stderr


def _descriptor_path(descriptor: int) -> Path | None:
    """The path an open directory descriptor names now."""
    try:
        if sys.platform == "darwin":
            import fcntl

            return Path(os.fsdecode(fcntl.fcntl(descriptor, fcntl.F_GETPATH, bytes(1024)).rstrip(b"\0")))
        return Path(os.readlink(f"/proc/self/fd/{descriptor}"))
    except (OSError, ValueError):
        return None


def _subject(args, kwargs) -> Path | None:
    """The path a call acts on, also when it is named relative to an open directory."""
    if not args or not isinstance(args[0], (str, bytes, os.PathLike)):
        return None
    name = Path(os.fsdecode(args[0]))
    if kwargs.get("dir_fd") is None:
        return name
    directory = _descriptor_path(kwargs["dir_fd"])
    return None if directory is None else directory / name


def _aside_fault(monkeypatch, call: str, matches) -> dict:
    """One EIO at `call` on an entry rollback has already moved into its aside directory."""
    state = {"fired": False}
    original = getattr(os, call)

    def faulted(*args, **kwargs):
        # ROUND-3 ADAPTATION: rollback now acts inside its aside directory
        # through that directory's descriptor (no path longer than the
        # entry's own), so a call named relative to it is resolved first.
        subject = _subject(args, kwargs)
        if (not state["fired"] and subject is not None
                and subject.parent.name.startswith(".livemore-aside-") and matches(subject)):
            state["fired"] = True
            raise OSError(errno.EIO, os.strerror(errno.EIO))
        return original(*args, **kwargs)

    monkeypatch.setattr(os, call, faulted)
    if call == "lstat":
        stat_ = os.stat

        def faulted_stat(*args, **kwargs):
            if kwargs.get("follow_symlinks", True) is False:
                return faulted(*args, **{k: v for k, v in kwargs.items() if k != "follow_symlinks"})
            return stat_(*args, **kwargs)
        monkeypatch.setattr(os, "stat", faulted_stat)
    return state


@pytest.mark.parametrize(("call", "entry", "run"), [
    ("lstat", "model", "failure"),
    ("unlink", "model", "failure"),
    ("lstat", "staging", "success"),
    ("rmdir", "staging", "success"),
    ("rmdir", "managed_lock", "failure"),
])
def test_l0_r11_round1_an_error_inside_the_aside_is_reported_and_restore_deletes_the_entry(
        installer_env, monkeypatch, faults, call: str, entry: str, run: str) -> None:
    # Verifier exp8 C1/C2/D and exp1: an I/O error after the move was reported as
    # "could not move aside", or hidden as foreign; restore then put this
    # operation's own entry back into the release.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    matches = {"model": lambda subject: subject.name == path.name,
               "staging": lambda subject: subject.name.startswith(".install-cardiac-"),
               "managed_lock": lambda subject: subject.name == ".install.lock" and subject.parent.parent == install}[entry]
    if run == "failure":
        _fail_admission(faults, integrity)
    fault = _aside_fault(faults, call, matches)
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install("cardiac")
    faults.undo()
    assert fault["fired"], "rollback never touched the entry in its aside directory"
    message = str(refused.value)
    assert refused.value.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{refused.value.code}: {message}"
    asides = _no_aside(install)
    assert asides and all(str(install / aside) in message for aside in asides), message
    assert "could not move aside" not in message

    assert _recover(assets) == "restored"
    assert _no_aside(install) == []
    assert _release_is_valid(assets, install)
    if run == "failure":
        assert _tree(install) == untouched, "restore put this operation's own entry back"
        assert assets.install("cardiac")["available"] is True
    else:
        assert assets.check("cardiac")["available"] is True
        assert not list(path.parent.glob(".install-cardiac-*"))
    assert _release_is_valid(assets, install)


@pytest.mark.parametrize("entry", ["lock", "pid", "staged_model", "models_directory"])
def test_l0_r11_round1_an_entry_whose_identity_read_fails_is_still_removed_or_named(
        installer_env, monkeypatch, faults, entry: str) -> None:
    # Verifier exp8 E and exp1: the identity was read by a second call after the
    # creation; when that call failed, the entry was left and never reported.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    target = {"lock": lambda p: p == path.parent / ".install.lock",
              "pid": lambda p: p == install / ".install.lock" / "pid",
              "staged_model": lambda p: p.name == path.name and p.parent.name.startswith(".install-cardiac-"),
              "models_directory": lambda p: p == path.parents[1]}[entry]
    # ROUND-2 ADAPTATION: the managed lock's pid and the lock file are made in
    # the operation's private record directory first (pid, then the lock), and
    # linked to their names only after the record lists them.
    made_in_record = {"pid": 0, "lock": 1}.get(entry)
    state = {"armed": None, "fired": False, "record_files": 0}
    opened, fstat_, mkdir_ = os.open, os.fstat, os.mkdir
    real = {name: getattr(os, name) for name in ("lstat", "stat")}

    def watched_open(file, flags, *args, **kwargs):
        subject = Path(os.fsdecode(file)) if isinstance(file, (str, os.PathLike)) and "dir_fd" not in kwargs else None
        if state["armed"] == subject and subject is not None and not state["fired"]:
            state["fired"] = True
            raise OSError(errno.EIO, os.strerror(errno.EIO))
        descriptor = opened(file, flags, *args, **kwargs)
        if subject is not None and flags & os.O_EXCL and target(subject) and not state["fired"]:
            state["armed"] = descriptor
        if ("dir_fd" in kwargs and flags & os.O_EXCL and os.fsdecode(file).startswith("pin-")
                and made_in_record is not None):
            if state["record_files"] == made_in_record and not state["fired"]:
                state["armed"] = descriptor
            state["record_files"] += 1
        return descriptor

    def watched_fstat(descriptor, *args, **kwargs):
        if state["armed"] == descriptor and not state["fired"]:
            state["fired"] = True
            raise OSError(errno.EIO, os.strerror(errno.EIO))
        return fstat_(descriptor, *args, **kwargs)

    def watched_mkdir(file, *args, **kwargs):
        result = mkdir_(file, *args, **kwargs)
        subject = Path(os.fsdecode(file))
        if target(subject) and not state["fired"]:
            state["armed"] = subject  # the next call that reads it after the mkdir fails
        return result

    def first_read(name):
        def call(file, *args, **kwargs):
            subject = Path(os.fsdecode(file)) if isinstance(file, (str, os.PathLike)) and "dir_fd" not in kwargs else None
            if state["armed"] == subject and subject is not None and not state["fired"]:
                state["fired"] = True
                raise OSError(errno.EIO, os.strerror(errno.EIO))
            return real[name](file, *args, **kwargs)
        return call

    faults.setattr(os, "open", watched_open)
    faults.setattr(os, "fstat", watched_fstat)
    faults.setattr(os, "mkdir", watched_mkdir)
    faults.setattr(os, "lstat", first_read("lstat"))
    faults.setattr(os, "stat", first_read("stat"))
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install("cardiac")
    faults.undo()
    assert state["fired"], "the identity read never ran"
    message = str(refused.value)
    for name in _left_entries(install, untouched):
        assert str(install / name) in message, f"{name} is left and the refusal does not name it: {message}"
    assert _release_is_valid(assets, install)
    _recover(assets)
    assert _release_is_valid(assets, install)
    assert assets.install("cardiac")["available"] is True
    repeated = _run(installer_env)
    assert repeated.returncode == 0, repeated.stderr


class _CtrlCAsHandlersChange:
    """Ctrl-C arriving at the instant code installs a SIGINT handler of its own,
    before that handler is in place (verifier exp6)."""

    def __init__(self, monkeypatch):
        self.real = signal.signal
        self.count = 0
        self.target = 0
        self.delivered = False
        monkeypatch.setattr(signal, "signal", self._signal)

    def _signal(self, number, handler):
        if number == signal.SIGINT and handler is not signal.default_int_handler:
            self.count += 1
            if self.count == self.target:
                self.delivered = True
                signal.raise_signal(signal.SIGINT)
        return self.real(number, handler)


@pytest.mark.parametrize("presses", ["one, as admission fails", "two, the first in the download"])
def test_l0_r11_round1_ctrl_c_as_rollback_begins_cannot_skip_it(installer_env, monkeypatch, tmp_path, presses: str) -> None:
    import shutil

    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    pristine = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    relative = path.relative_to(pristine)
    copies = iter(range(10**6))
    state: dict = {}

    def prepare() -> Path:
        install = tmp_path / f"technical-release-{next(copies)}"
        shutil.copytree(pristine, install, symlinks=True)
        monkeypatch.setattr(assets, "_cardiac_path", lambda: install / relative)
        state["install"] = install
        return install

    if presses.startswith("one"):
        original_replace, original_link = os.replace, os.link

        def failing_any_copy(name, original):
            def call(source_, destination, *args, **kwargs):
                if Path(os.fsdecode(destination)).name == f"{COMMIT_A}.sha256" and (
                        name == "replace" or Path(os.fsdecode(source_)).name.startswith(".cardiac-integrity-")):
                    raise OSError(errno.EIO, "technical failure at admission")
                return original(source_, destination, *args, **kwargs)
            return call
        monkeypatch.setattr(os, "replace", failing_any_copy("replace", original_replace))
        monkeypatch.setattr(os, "link", failing_any_copy("link", original_link))
    else:
        payload = b"technical-cardio-fixture"
        from .test_cardiac_assets import TechnicalResponse

        def pressed_in_download(request, timeout):
            signal.raise_signal(signal.SIGINT)
            return TechnicalResponse(payload, request.full_url)
        monkeypatch.setattr(assets, "_open_url", pressed_in_download)
    presses_ = _CtrlCAsHandlersChange(monkeypatch)

    def attempt(target: int) -> str:
        presses_.count, presses_.target, presses_.delivered = 0, target, False
        try:
            assets.install("cardiac")
        except KeyboardInterrupt:
            return "KeyboardInterrupt"
        except assets.ModelAssetError as error:
            return error.code
        return "returned"

    untouched = _tree(prepare())
    attempt(0)
    total = presses_.count
    failures = []
    for target in range(1, total + 1):
        install = prepare()
        outcome = attempt(target)
        problems = []
        if outcome != "KeyboardInterrupt":
            problems.append("the interrupt did not surface")
        if signal.getsignal(signal.SIGINT) is not signal.default_int_handler:
            problems.append("the SIGINT handler was not restored")
        after = _tree(install)
        if after != untouched:
            problems.append(f"rollback did not run: extra={sorted(set(after) - set(untouched))}")
        if problems:
            failures.append(f"Ctrl-C at handler change {target} of {total} -> {outcome}: {'; '.join(problems)}")
    assert not failures, "\n".join(failures)


def test_l0_r11_round1_a_moved_lock_is_reported_aside_and_restore_never_reinstates_it(installer_env, monkeypatch, faults) -> None:
    # Verifier test_managed_lock_directory_without_search_permission: the lock
    # was moved aside but reported as "could not move aside", and restore put
    # the dead operation's lock back, so every later install was busy.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    lock = install / ".install.lock"
    _fail_admission(faults, integrity, before=lambda: os.chmod(lock, 0o600))
    try:
        with pytest.raises(assets.ModelAssetError) as refused:
            assets.install("cardiac")
        faults.undo()
        message = str(refused.value)
        assert refused.value.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{refused.value.code}: {message}"
        assert _RESTORE_COMMAND in message and "could not move aside" not in message
        assert not lock.exists()
        (aside,) = _no_aside(install)
        assert str(install / aside) in message

        # Restore cannot search the lock either: it refuses and never puts it back.
        with pytest.raises(assets.ModelAssetError) as again:
            assets.restore("cardiac")
        assert again.value.code == "CARDIAC_MODEL_ASIDE_PENDING"
        assert not lock.exists(), "restore reinstated the dead operation's lock"
        # The person restores the permission; restore then finishes the rollback.
        os.chmod(install / aside / ".install.lock", 0o700)
        assets.restore("cardiac")
        assert not lock.exists() and _no_aside(install) == []
        assert assets.install("cardiac")["available"] is True
        assert _release_is_valid(assets, install)
    finally:
        for candidate in install.rglob(".install.lock"):
            if candidate.is_dir():
                os.chmod(candidate, 0o700)


def _case_insensitive(directory: Path) -> bool:
    probe = directory / "technical-Case-Probe"
    probe.write_bytes(b"")
    try:
        return (directory / "TECHNICAL-CASE-PROBE").exists()
    finally:
        probe.unlink()


@pytest.mark.parametrize("entry", ["model", "attribution", "lock"])
def test_l0_r11_round1_rollback_keeps_the_spelling_of_an_entry_it_puts_back(
        installer_env, monkeypatch, faults, tmp_path, entry: str) -> None:
    # Verifier test_entries case_variant_file: on a case-insensitive volume the
    # put-back stored another program's file under this operation's spelling.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    if not _case_insensitive(tmp_path):
        pytest.skip("case-sensitive volume: a name differing only in case is another entry")
    target = {"model": path, "attribution": path.with_suffix(".cellml.attribution.json"),
              "lock": path.parent / ".install.lock"}[entry]
    variant = target.parent / target.name.upper()

    def replace_with_variant() -> None:
        os.rename(target, tmp_path / "technical-operation-entry")
        _write_theirs(variant)

    _fail_admission(faults, integrity, before=replace_with_variant)
    with pytest.raises(assets.ModelAssetError):
        assets.install("cardiac")
    faults.undo()
    names = os.listdir(target.parent)
    assert variant.name in names and target.name not in names, names
    assert variant.read_bytes() == _THEIRS


def test_l0_r11_round1_admission_refuses_a_release_it_cannot_read_whole(installer_env, monkeypatch, faults) -> None:
    # Found rerunning the verifiers' OSError sweep (EACCES at scandir): pathlib's
    # rglob skips a directory it may not read, so admission recorded a digest
    # without that subtree; the install reported available and the release
    # then failed its own integrity record. Here models/ loses read permission
    # just after the model is published.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    before = integrity.read_bytes()
    models = path.parents[1]
    link = os.link
    state = {"fired": False}

    def published_then_unreadable(source_, destination, *args, **kwargs):
        result = link(source_, destination, *args, **kwargs)
        if not state["fired"] and Path(os.fsdecode(destination)) == path:
            state["fired"] = True
            os.chmod(models, 0o300)
        return result

    faults.setattr(os, "link", published_then_unreadable)
    try:
        try:
            outcome = assets.install("cardiac")
        except assets.ModelAssetError as error:
            outcome = error
    finally:
        faults.undo()
        if models.is_dir():
            os.chmod(models, 0o755)
    assert state["fired"], "the model was never published"
    assert _release_is_valid(assets, install), "admission recorded a digest that skipped an unreadable directory"
    if isinstance(outcome, assets.ModelAssetError):
        assert integrity.read_bytes() == before and not path.exists()


# L0-R11 round 2. Each case below is a defect the adversarial verifiers
# reproduced in the round-1 work, turned into a test that fails on that work.
_CHILD_RULES = r'''
import errno, hashlib, io, json, os, re, signal, sys
from pathlib import Path
from livemorebio import model_assets as assets

class Response(io.BytesIO):
    status = 200
    def __init__(self, data, url):
        super().__init__(data)
        self.url, self.headers = url, {"Content-Length": str(len(data))}
    def geturl(self):
        return self.url

path, spec, argv = Path(sys.argv[1]), json.loads(sys.argv[2]), sys.argv[3:]
payload = b"technical-cardio-fixture"
original = assets._CARDIAC_ASSET
assets._cardiac_path = lambda: path
assets._CARDIAC_ASSET = assets.AssetFile(original.asset_id, original.filename, original.source_url,
                                         hashlib.sha256(payload).hexdigest(), len(payload))
assets._open_url = lambda request, timeout: Response(payload, request.full_url)
install = path.parents[5]
integrity = install / "integrity" / (path.parents[3].name + ".sha256")
real = {name: getattr(os, name) for name in ("open", "link", "rename", "unlink", "mkdir", "replace", "rmdir")}
fired = set()

def named(argument):
    return Path(os.fsdecode(argument)) if isinstance(argument, (str, bytes, os.PathLike)) else None

def matches(rule, args):
    subject = named(args[rule.get("arg", 0)]) if len(args) > rule.get("arg", 0) else None
    return (subject is not None and re.search(rule.get("name", ""), subject.name) is not None
            and re.search(rule.get("parent", ""), subject.parent.name) is not None)

def wrap(name):
    def call(*args, **kwargs):
        if (spec.get("fail_admission") and name in ("link", "replace") and len(args) > 1
                and named(args[1]) == integrity
                and (name == "replace" or named(args[0]).name.startswith(".cardiac-integrity-"))):
            raise OSError(errno.EIO, "technical failure at admission")
        hits = [index for index, rule in enumerate(spec.get("rules", []))
                if rule["fn"] == name and index not in fired and matches(rule, args)]
        for index in hits:
            if spec["rules"][index].get("when", "before") == "before":
                fired.add(index)
                os.kill(os.getpid(), signal.SIGKILL)
        result = real[name](*args, **kwargs)
        for index in hits:
            fired.add(index)
            os.kill(os.getpid(), signal.SIGKILL)
        if (spec.get("readonly_after_publication") and name == "link" and len(args) > 1
                and named(args[1]) == path):
            os.chmod(path.parent, 0o555)
        return result
    return call

for name in real:
    setattr(os, name, wrap(name))
raise SystemExit(assets.main(argv))
'''


def _child_rules(path: Path, spec: dict, *argv: str) -> tuple[int, dict]:
    """The model-assets command in its own process, killed (SIGKILL) where `spec` says."""
    result = subprocess.run([sys.executable, "-c", _CHILD_RULES, str(path), json.dumps(spec), *argv],
                            cwd=REPOSITORY_ROOT, capture_output=True, text=True, encoding="utf-8",
                            timeout=300, check=False)
    output = result.stdout.strip()
    return result.returncode, (json.loads(output) if output else {"stderr": result.stderr[-2000:]})


def _follow(assets, attempts: int = 3) -> list[str]:
    """Follow the product as a person would: while check reports pending state
    with the restore command, run restore. A raw OSError fails the test."""
    steps: list[str] = []
    for _ in range(attempts):
        try:
            status = assets.check("cardiac")
        except assets.ModelAssetError as error:
            if error.code != "CARDIAC_MODEL_ASIDE_PENDING":
                steps.append(f"check:{error.code}")
                return steps
            assert _RESTORE_COMMAND in str(error), str(error)
            steps.append("check:pending")
            try:
                steps.append("restore:" + assets.restore("cardiac")["state"])
            except assets.ModelAssetError as refusal:
                steps.append(f"restore:{refusal.code}")
            continue
        steps.append("check:" + ("available" if status["available"] else status["state"]))
        return steps
    return steps


def _leave_recorded(assets, path: Path, integrity: Path, faults) -> "assets.ModelAssetError":
    """Round 1's read-only case: models/cardiac turns 0555 as admission fails, so
    rollback leaves the model, attribution and lock at their names and records
    them. The person then restores the permission."""
    cardiac = path.parent
    _fail_admission(faults, integrity, before=lambda: os.chmod(cardiac, 0o555))
    try:
        with pytest.raises(assets.ModelAssetError) as refused:
            assets.install("cardiac")
    finally:
        faults.undo()
        if cardiac.is_dir():
            os.chmod(cardiac, 0o755)
    assert refused.value.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{refused.value.code}: {refused.value}"
    assert path.exists(), "the case did not leave the model recorded"
    return refused.value


def _clean_end(assets, installer_env, install: Path, untouched: dict[str, str], steps: list[str]) -> None:
    """After following the product: nothing pending, the release is exactly as
    before and valid, the model is not reported available, and installs work."""
    assert steps and steps[-1] == "check:CARDIAC_MODEL_NOT_INSTALLED", steps
    assert _release_is_valid(assets, install), f"the release fails its integrity record after {steps}"
    assert _tree(install) == untouched, sorted(set(_tree(install)) ^ set(untouched))
    assert assets.install("cardiac")["available"] is True
    assert _release_is_valid(assets, install)
    repeated = _run(installer_env)
    assert repeated.returncode == 0, repeated.stderr


@pytest.mark.parametrize("how", ["rename-over", "unlink-then-create"])
def test_l0_r11_round2_admission_never_publishes_a_file_put_at_its_new_records_name(
        installer_env, monkeypatch, faults, tmp_path, how: str) -> None:
    # Verifier integrity_temporary_replaced / _unlink_create: the new record's
    # temporary was a file in the shared integrity/ directory; the commit link
    # published whatever held that name and then deleted the previous record.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    previous = integrity.read_bytes()
    link = os.link
    state: dict = {}

    def replaced_then_linked(source_, destination, *args, **kwargs):
        if not state and _admission_commit(source_, destination, integrity):
            at = Path(os.fsdecode(source_))
            if how == "rename-over":
                staged = tmp_path / "technical-their-file"
                staged.write_bytes(_THEIRS)
                os.rename(staged, at)
            else:
                os.unlink(at)
                _write_theirs(at)
            state["theirs"] = os.lstat(at).st_ino
        return link(source_, destination, *args, **kwargs)

    faults.setattr(os, "link", replaced_then_linked)
    try:
        outcome = assets.install("cardiac")
    except assets.ModelAssetError as error:
        outcome = error
    faults.undo()
    assert state, "admission never reached its commit link"
    kept = [entry for entry in install.rglob("*") if entry.is_file() and entry.read_bytes() == previous]
    assert isinstance(outcome, assets.ModelAssetError), "install reported success with another file as its record"
    assert kept, "the previous integrity record was deleted"
    assert integrity.read_bytes() != _THEIRS or outcome.code == "CARDIAC_MODEL_ASIDE_PENDING"


@pytest.mark.parametrize("window", ["before the managed lock", "managed lock moved aside, success",
                                    "managed lock moved aside, failure"])
def test_l0_r11_round2_commands_while_an_installation_runs_are_busy_in_every_window(
        installer_env, monkeypatch, faults, window: str) -> None:
    # Verifier busy_window_*: the installation's record directory was visible
    # while neither lock was held, so check and install gave the restore
    # command, and restore deleted the live installation's record.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    lock = install / ".install.lock"
    seen: dict = {}
    mkdir, rename = os.mkdir, os.rename

    def commands(names) -> None:
        if not seen:
            for command in names:
                seen[command] = _child(path, "plain", command, "cardiac")

    def watched_mkdir(file, *args, **kwargs):
        if window.startswith("before") and Path(os.fsdecode(file)) == lock:
            commands(("check", "install", "restore"))
        return mkdir(file, *args, **kwargs)

    def watched_rename(source_, destination, *args, **kwargs):
        result = rename(source_, destination, *args, **kwargs)
        if (window.startswith("managed lock moved aside") and isinstance(source_, (str, os.PathLike))
                and Path(os.fsdecode(source_)) == lock):
            commands(("check", "restore"))
        return result

    if window.endswith("failure"):
        _fail_admission(faults, integrity, before=lambda: os.chmod(path.parent, 0o555))
    faults.setattr(os, "mkdir", watched_mkdir)
    faults.setattr(os, "rename", watched_rename)
    try:
        try:
            outcome = assets.install("cardiac")
        except assets.ModelAssetError as error:
            outcome = error
    finally:
        faults.undo()
        if path.parent.is_dir():
            os.chmod(path.parent, 0o755)
    assert seen, "the window was never reached"
    for command, (code, output) in seen.items():
        assert code == 2 and output.get("error", {}).get("code") == "CARDIAC_MODEL_INSTALL_BUSY", (window, command, output)
    if window.endswith("failure"):
        assert isinstance(outcome, assets.ModelAssetError)
        assert outcome.code == "CARDIAC_MODEL_ASIDE_PENDING" and _RESTORE_COMMAND in str(outcome), str(outcome)
        _clean_end(assets, installer_env, install, untouched, _follow(assets))
    else:
        assert not isinstance(outcome, assets.ModelAssetError), f"{outcome.code}: {outcome}"
        assert outcome["available"] is True
        assert _release_is_valid(assets, install)
        assert assets.check("cardiac")["available"] is True


def test_l0_r11_round2_restore_never_takes_a_reused_number_for_the_new_record_after_the_installer_exits(
        installer_env, monkeypatch, faults) -> None:
    # Verifier old_verdict_inode_reuse_steered (Linux): the `old` aside named the
    # new record by its inode number; once the installer exited that number was
    # free, a file another process wrote at the integrity name got it, and
    # restore deleted the previous record. Freed numbers are modelled as in
    # round 1 (_InodeReuse): reused only once no link and no descriptor holds them.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    previous = integrity.read_bytes()
    link = os.link
    state: dict = {}

    def their_file_takes_the_name(source_, destination, *args, **kwargs):
        if not state and _admission_commit(source_, destination, integrity):
            state["new"] = os.stat(source_, follow_symlinks=False)
            _write_theirs(integrity, b"technical: another process's file at the integrity name, 1\n")
        return link(source_, destination, *args, **kwargs)

    faults.setattr(os, "link", their_file_takes_the_name)
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install("cardiac")
    faults.undo()
    assert state, "admission never reached its commit link"
    assert refused.value.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{refused.value.code}: {refused.value}"

    # The installer has exited. The other process rewrites its file (rm; write).
    reuse = _InodeReuse(faults)
    new = state["new"]
    still_linked = any(os.lstat(entry).st_ino == new.st_ino for entry in install.rglob("*"))
    _, theirs, _ = reuse.replace(integrity, lambda at: _write_theirs(
        at, b"technical: another process's file at the integrity name, 2\n"))
    reuse.reused.clear()
    if not still_linked and not reuse._held(new.st_dev, new.st_ino):
        reuse.reused[(new.st_dev, theirs)] = new.st_ino  # the kernel gave it the freed number
    try:
        assets.restore("cardiac")
    except assets.ModelAssetError:
        pass
    faults.undo()
    kept = [entry for entry in install.rglob("*") if entry.is_file() and entry.read_bytes() == previous]
    assert kept, "restore deleted the previous integrity record though the new record never held the name"


def test_l0_r11_round2_this_operations_model_renamed_within_the_release_is_still_removed(
        installer_env, monkeypatch, faults) -> None:
    # Verifier model_renamed_within_release: another process renamed the
    # published model to name~ (an editor's backup). Rollback called it absent,
    # put models/cardiac back as holding others' entries, and gave no command.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    backup = path.with_name(path.name + "~")
    _fail_admission(faults, integrity)
    link = os.link

    def published_then_renamed(source_, destination, *args, **kwargs):
        result = link(source_, destination, *args, **kwargs)
        if Path(os.fsdecode(destination)) == path and not backup.exists():
            os.rename(path, backup)
        return result

    faults.setattr(os, "link", published_then_renamed)
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install("cardiac")
    faults.undo()
    message = str(refused.value)
    assert "did not create" not in message, message
    if backup.exists():
        assert str(backup) in message and _RESTORE_COMMAND in message, message
    # ROUND-3 ADAPTATION (verifier hardlink_original_removed): a name another
    # program gave this operation's file is indistinguishable from its own
    # hard link of it, and is never deleted. Restore names it and waits until
    # it leaves the release, as the refusal says; then it finishes.
    with pytest.raises(assets.ModelAssetError) as waiting:
        assets.restore("cardiac")
    assert str(backup) in str(waiting.value), str(waiting.value)
    backup.unlink()
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


@pytest.mark.parametrize("fault", ["EIO", "EACCES"])
def test_l0_r11_round2_restore_never_drops_a_recorded_entry_it_cannot_pin_again(
        installer_env, monkeypatch, faults, fault: str) -> None:
    # Verifier test_a_restore_meets_eio_opening_the_pin: one error opening the
    # record's pin made restore skip the model, report its directories as
    # holding others' entries, delete the record and say nothing_pending; check
    # then said available while the release failed its integrity record.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    _leave_recorded(assets, path, integrity, faults)
    state = {"fired": False}
    number = getattr(errno, fault)

    def once(original):
        def call(name, *args, **kwargs):
            if (not state["fired"] and "dir_fd" in kwargs and isinstance(name, (str, bytes))
                    and os.fsdecode(name).startswith("pin-")):
                state["fired"] = True
                raise OSError(number, os.strerror(number))
            return original(name, *args, **kwargs)
        return call

    faults.setattr(os, "open", once(os.open))
    faults.setattr(os, "stat", once(os.stat))
    try:
        first = assets.restore("cardiac")["state"]
    except assets.ModelAssetError as refusal:
        first = refusal.code
    faults.undo()
    assert state["fired"], "restore never read the record's pin"
    assert first != "nothing_pending", "restore skipped an entry it could not pin again and said nothing_pending"
    if first == "restored":
        assert not path.exists(), "restore said restored and left the model"
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


def test_l0_r11_round2_restore_meeting_an_error_deleting_its_record_never_loops(
        installer_env, monkeypatch, faults) -> None:
    # Verifier exp1 / test_b: restore deleted record.json first; one error on
    # the next unlink left a record directory holding only a pin, an uncaught
    # OSError escaped, and check, install and restore refused for ever.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    _leave_recorded(assets, path, integrity, faults)
    state = {"fired": False}
    unlink = os.unlink

    def failing_unlink(name, *args, **kwargs):
        if (not state["fired"] and "dir_fd" in kwargs and isinstance(name, (str, bytes))
                and os.fsdecode(name).startswith("pin-")):
            state["fired"] = True
            raise OSError(errno.EIO, os.strerror(errno.EIO))
        return unlink(name, *args, **kwargs)

    faults.setattr(os, "unlink", failing_unlink)
    try:
        assets.restore("cardiac")
    except assets.ModelAssetError:
        pass  # a refusal is fine; a raw OSError fails here
    faults.undo()
    assert state["fired"], "restore never deleted a pin"
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


@pytest.mark.parametrize("removed", ["models", "models/cardiac"])
def test_l0_r11_round2_a_recorded_entry_whose_directory_is_gone_is_finished(
        installer_env, monkeypatch, faults, removed: str) -> None:
    # Verifier B2 and test_parent_gone: once the model's directory was gone,
    # restore failed to make an aside directory in it and refused for ever.
    import shutil

    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    _leave_recorded(assets, path, integrity, faults)
    shutil.rmtree(source / removed)
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


@pytest.mark.parametrize("reported", ["EEXIST", "EIO"])
def test_l0_r11_round2_admission_that_took_effect_despite_an_error_is_kept(
        installer_env, monkeypatch, faults, reported: str) -> None:
    # Verifier C-eexist / C-eio and test_d: the commit link took effect and then
    # reported an error (a retransmitted NFS LINK). Rollback deleted the model
    # the new record lists, and restore then deleted the previous record.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    link = os.link
    number = getattr(errno, reported)
    state = {"fired": False}

    def took_effect_then_failed(source_, destination, *args, **kwargs):
        result = link(source_, destination, *args, **kwargs)
        if not state["fired"] and _admission_commit(source_, destination, integrity):
            state["fired"] = True
            raise OSError(number, os.strerror(number))
        return result

    faults.setattr(os, "link", took_effect_then_failed)
    try:
        assets.install("cardiac")
    except assets.ModelAssetError:
        pass
    faults.undo()
    assert state["fired"], "admission never reached its commit link"
    steps = _follow(assets)
    assert _release_is_valid(assets, install), f"the release fails its integrity record after {steps}"
    assert assets.install("cardiac")["available"] is True
    assert _release_is_valid(assets, install)
    repeated = _run(installer_env)
    assert repeated.returncode == 0, repeated.stderr


@pytest.mark.parametrize(("moment", "rule", "committed"), [
    ("the model is published", {"fn": "link", "arg": 1, "name": r"^ohara_rudy_cipa_2017\.cellml$", "when": "after"}, False),
    ("staging is removed", {"fn": "rmdir", "arg": 0, "name": r"^\.install-cardiac-", "when": "after"}, False),
    ("the new record is opened", {"fn": "open", "arg": 0, "name": r"^\.cardiac-integrity-", "when": "before"}, False),
    ("admission has committed", {"fn": "link", "arg": 1, "name": r"^[0-9a-f]{40}\.sha256$", "when": "after"}, True),
])
def test_l0_r11_round2_sigkill_between_publication_and_admission_is_finished_by_restore(
        installer_env, monkeypatch, moment: str, rule: dict, committed: bool) -> None:
    # Verifier exp5 and test_c: the record was written only when the operation
    # ended, so after a SIGKILL there restore removed only the reserve, and check
    # and install said available while the release failed its integrity record.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    code, _ = _child_rules(path, {"rules": [rule]}, "install", "cardiac")
    assert code == -signal.SIGKILL, f"the installer was not killed when {moment}"
    steps = _follow(assets)
    if committed:
        assert steps[-1] == "check:available", steps
        assert _release_is_valid(assets, install)
        assert not [entry for entry in install.rglob(".livemore-*")
                    if entry.name.startswith((".livemore-aside-", ".livemore-rollback-"))]
        repeated = _run(installer_env)
        assert repeated.returncode == 0, repeated.stderr
    else:
        _clean_end(assets, installer_env, install, untouched, steps)


def test_l0_r11_round2_sigkill_before_the_record_holds_its_pins_leaves_nothing_unrecorded(
        installer_env, monkeypatch) -> None:
    # Verifier exp7_kill_before_pin: killed after record.json listed the model
    # and before its pin was linked, restore skipped the model and check said
    # available while the release failed its integrity record.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    spec = {"fail_admission": True, "readonly_after_publication": True,
            "rules": [{"fn": "link", "arg": 1, "parent": r"^\.livemore-rollback-", "when": "before"}]}
    try:
        code, _ = _child_rules(path, spec, "install", "cardiac")
    finally:
        if path.parent.is_dir():
            os.chmod(path.parent, 0o755)
    assert code == -signal.SIGKILL, "the installer was never killed at its first pin"
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


@pytest.mark.parametrize("cause", ["models/cardiac loses search permission", "the model is locked (uchg)",
                                   "the pinned model has no owner read"])
def test_l0_r11_round2_entries_a_rollback_cannot_pin_by_path_are_still_finished(
        installer_env, monkeypatch, faults, cause: str) -> None:
    # Verifier exp1, exp1b, exp1c and exp6: the record named a pin that could
    # not be made or opened; restore skipped those entries silently, deleted the
    # record, and check and install then said available on an invalid release.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    cardiac = path.parent
    if cause.startswith("the model is locked") and sys.platform != "darwin":
        pytest.skip("the owner can set an immutable flag only on macOS")
    if cause.startswith("the model is locked"):
        _fail_admission(faults, integrity)
    link = os.link

    def published(source_, destination, *args, **kwargs):
        result = link(source_, destination, *args, **kwargs)
        if Path(os.fsdecode(destination)) == path:
            if cause.startswith("models/cardiac"):
                os.chmod(cardiac, 0o600)
            elif cause.startswith("the model is locked"):
                os.chflags(path, stat.UF_IMMUTABLE)
        return result

    try:
        if cause.startswith("the pinned model"):
            _leave_recorded(assets, path, integrity, faults)
            os.chmod(path, 0o000)
            try:
                first = assets.restore("cardiac")["state"]
            except assets.ModelAssetError as refusal:
                first = refusal.code
            if path.exists():
                os.chmod(path, 0o600)
            assert not (first == "nothing_pending" and path.exists()), first
        else:
            faults.setattr(os, "link", published)
            with pytest.raises(assets.ModelAssetError) as refused:
                assets.install("cardiac")
            faults.undo()
            assert refused.value.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{refused.value.code}: {refused.value}"
            if cause.startswith("the model is locked"):
                # Restore cannot finish while the person's lock holds; it says so and keeps the record.
                steps = _follow(assets, attempts=1)
                assert steps[-1] == "restore:CARDIAC_MODEL_ASIDE_PENDING", steps
                os.chflags(path, 0)
            else:
                os.chmod(cardiac, 0o755)
        _clean_end(assets, installer_env, install, untouched, _follow(assets))
    finally:
        faults.undo()
        if cardiac.is_dir():
            os.chmod(cardiac, 0o755)
        if hasattr(os, "chflags"):
            for entry in install.rglob("*"):
                if not entry.is_symlink() and entry.lstat().st_flags & stat.UF_IMMUTABLE:
                    os.chflags(entry, 0)


class _Remount:
    """The volume is detached and attached again. macOS gives it a new st_dev;
    APFS keeps its inode numbers (verifier exp2, a hdiutil image). Every stat
    of the volume reports the new device from here on."""

    def __init__(self, monkeypatch, shift: int = 4099):
        for name in ("stat", "lstat", "fstat"):
            monkeypatch.setattr(os, name, self._moved(getattr(os, name), shift))

    @staticmethod
    def _moved(original, shift):
        def call(*args, **kwargs):
            fields = list(original(*args, **kwargs))
            fields[stat.ST_DEV] += shift
            return os.stat_result(fields)
        return call


@pytest.mark.parametrize("left", ["recorded entries", "the managed lock aside"])
def test_l0_r11_round2_restore_finishes_after_the_volume_is_mounted_again(
        installer_env, monkeypatch, faults, left: str) -> None:
    # Verifier test_remount: restore compared device numbers saved before the
    # volume was ejected; after it was attached again restore dropped every
    # recorded entry, or put the dead installer's lock back.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    if left == "recorded entries":
        _leave_recorded(assets, path, integrity, faults)
    else:
        code, _ = _child(path, "killed-once-the-managed-lock-is-aside", "install", "cardiac")
        assert code == -signal.SIGKILL
        assert _no_aside(install), "the child was not killed with its lock aside"
    _Remount(faults)
    steps = _follow(assets)
    assert steps[-1] == "check:CARDIAC_MODEL_NOT_INSTALLED", steps
    assert not (install / ".install.lock").exists(), "restore put the dead installer's lock back"
    assert _release_is_valid(assets, install)
    assert _tree(install) == untouched, sorted(set(_tree(install)) ^ set(untouched))
    assert assets.install("cardiac")["available"] is True
    faults.undo()
    assert _release_is_valid(assets, install)


def test_l0_r11_round2_a_record_written_under_umask_0400_stays_readable(
        installer_env, monkeypatch, faults) -> None:
    # Verifier test_umask_record: record.json was the one file made without
    # fchmod, so under umask 0400 it was 0200 and restore refused for ever.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    previous = os.umask(0o400)
    try:
        _leave_recorded(assets, path, integrity, faults)
    finally:
        os.umask(previous)
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


# Found by rerunning the verifiers' fault sweep (exp3) on the round-2 work.
@pytest.mark.parametrize("run", ["success", "failure"])
def test_l0_r11_round2_a_record_whose_file_cannot_be_removed_stays_whole_for_restore(
        installer_env, monkeypatch, faults, run: str) -> None:
    # When the operation ended, removing its record file failed and the pins
    # were removed anyway; restore could then never tell whether admission had
    # committed, and check refused for ever.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    if run == "failure":
        _fail_admission(faults, integrity)
    state = {"fired": False}
    unlink = os.unlink

    def failing(name, *args, **kwargs):
        # ROUND-3 ADAPTATION: the operation removes its record file through the
        # record directory's descriptor, never by a path (verifier
        # final_discard_replaced_record_dir), so that call is resolved first.
        subject = _subject((name, *args), kwargs)
        if (not state["fired"] and subject is not None and subject.name == "record.json"
                and subject.parent.name.startswith(".livemore-rollback-")):
            state["fired"] = True
            raise OSError(errno.EIO, os.strerror(errno.EIO))
        return unlink(name, *args, **kwargs)

    faults.setattr(os, "unlink", failing)
    try:
        assets.install("cardiac")
    except assets.ModelAssetError:
        pass
    faults.undo()
    assert state["fired"], "the operation never removed its record file"
    steps = _follow(assets)
    if run == "success":
        assert steps[-1] == "check:available", steps
        assert _release_is_valid(assets, install)
        assert not list(install.glob(".livemore-rollback-*"))
    else:
        _clean_end(assets, installer_env, install, untouched, steps)


def test_l0_r11_round2_a_record_directory_the_operation_gives_up_is_not_left_pending(
        installer_env, monkeypatch, faults) -> None:
    # prepare() could not read back the record directory it had just made and
    # locked, made another, and left the first: after a successful install,
    # check reported an operation that did not finish.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    state = {"fired": False}
    lstat = os.lstat

    def failing(name, *args, **kwargs):
        subject = Path(os.fsdecode(name)) if isinstance(name, (str, bytes, os.PathLike)) else None
        if not state["fired"] and subject is not None and subject.name.startswith(".livemore-rollback-"):
            state["fired"] = True
            raise OSError(errno.EIO, os.strerror(errno.EIO))
        return lstat(name, *args, **kwargs)

    faults.setattr(os, "lstat", failing)
    outcome = assets.install("cardiac")
    faults.undo()
    assert state["fired"], "the record directory was never read back"
    assert outcome["available"] is True
    assert assets.check("cardiac")["available"] is True
    assert not list(install.glob(".livemore-rollback-*"))
    assert _release_is_valid(assets, install)


@pytest.mark.parametrize("staged", ["model", "attribution"])
def test_l0_r11_round2_a_staged_file_whose_creation_reported_an_error_is_still_removed(
        installer_env, monkeypatch, faults, staged: str) -> None:
    # Verifier sweep exp3, EIO_AFTER at open(O_EXCL) of a staged file: the file
    # was made, the call still failed, so it was never recorded; the staging
    # directory stayed in the release, which then failed its integrity record.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    name = path.name if staged == "model" else path.name + ".attribution.json"
    state = {"fired": False}
    opened = os.open

    def took_effect_then_failed(file, flags, *args, **kwargs):
        subject = Path(os.fsdecode(file)) if isinstance(file, (str, bytes, os.PathLike)) else None
        descriptor = opened(file, flags, *args, **kwargs)
        if (not state["fired"] and subject is not None and flags & os.O_EXCL and subject.name == name
                and subject.parent.name.startswith(".install-cardiac-")):
            state["fired"] = True
            os.close(descriptor)
            raise OSError(errno.EIO, os.strerror(errno.EIO))
        return descriptor

    faults.setattr(os, "open", took_effect_then_failed)
    with pytest.raises(assets.ModelAssetError):
        assets.install("cardiac")
    faults.undo()
    assert state["fired"], "the staged file was never made"
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


def test_l0_r11_round2_an_error_removing_any_file_of_a_finished_record_never_loops(
        installer_env, monkeypatch, faults, tmp_path) -> None:
    # Verifier sweep exp2 rerun on the round-2 work: restore removed the
    # record's pins before its record file; one error part-way left a record
    # whose commit pin was gone, and restore could never again tell whether
    # admission had committed. Each file of the record fails once, in turn.
    import shutil

    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    pristine = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    relative = path.relative_to(pristine)
    untouched = _tree(pristine)
    copies = iter(range(10**6))

    def fresh() -> Path:
        install = tmp_path / f"technical-release-{next(copies)}"
        shutil.copytree(pristine, install, symlinks=True)
        monkeypatch.setattr(assets, "_cardiac_path", lambda: install / relative)
        return install

    install = fresh()
    _leave_recorded(assets, install / relative, install / integrity.relative_to(pristine), faults)
    (record,) = install.glob(".livemore-rollback-*")
    names = sorted(os.listdir(record))
    assert "record.json" in names and any(name.startswith(".cardiac-integrity-") for name in names), names
    failures = []
    # The new record's name carries a random part; the other names repeat.
    kinds = [".cardiac-integrity-" if name.startswith(".cardiac-integrity-") else name for name in names]
    for name in kinds:
        install = fresh()
        _leave_recorded(assets, install / relative, install / integrity.relative_to(pristine), faults)
        state = {"fired": False}
        unlink = os.unlink

        def failing(file, *args, **kwargs):
            if (not state["fired"] and "dir_fd" in kwargs
                    and (os.fsdecode(file) == name or name.endswith("-") and os.fsdecode(file).startswith(name))):
                state["fired"] = True
                raise OSError(errno.EIO, os.strerror(errno.EIO))
            return unlink(file, *args, **kwargs)

        faults.setattr(os, "unlink", failing)
        try:
            assets.restore("cardiac")
        except assets.ModelAssetError:
            pass
        faults.undo()
        steps = _follow(assets)
        if not state["fired"]:
            failures.append(f"{name}: restore never removed it")
        elif steps[-1] != "check:CARDIAC_MODEL_NOT_INSTALLED" or _tree(install) != untouched:
            failures.append(f"{name}: {steps}")
    assert not failures, "\n".join(failures)


def test_l0_r11_round2_an_error_closing_a_descriptor_never_escapes_restore(
        installer_env, monkeypatch, faults) -> None:
    # Verifier sweep exp2 rerun: an error closing the descriptor of the check
    # for a running installation escaped restore as a raw OSError.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    _leave_recorded(assets, path, integrity, faults)
    close = os.close
    state = {"count": 0}

    def failing(descriptor):
        state["count"] += 1
        close(descriptor)
        raise OSError(errno.EIO, os.strerror(errno.EIO))  # released, and still an error

    faults.setattr(os, "close", failing)
    try:
        assets.restore("cardiac")
    except assets.ModelAssetError:
        pass
    faults.undo()
    assert state["count"], "restore closed nothing"
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


@pytest.mark.parametrize("fault", ["EIO", "EACCES"])
def test_l0_r11_round2_restore_never_drops_a_recorded_child_it_cannot_pin_again(
        installer_env, monkeypatch, fault: str) -> None:
    # Verifier sweep exp2 rerun on the round-2 work (killed_aside, stat(pin-1)):
    # an installer killed mid-rollback leaves its managed lock recorded with its
    # pid. One error reading the pid's pin made restore drop the child, put the
    # lock back as holding others' entries, and every install was then busy.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    spec = {"fail_admission": True,
            "rules": [{"fn": "rename", "arg": 0, "name": r"^ohara_rudy_cipa_2017\.cellml$", "when": "after"}]}
    code, _ = _child_rules(path, spec, "install", "cardiac")
    assert code == -signal.SIGKILL, "the installer was not killed mid-rollback"
    assert (install / ".install.lock" / "pid").exists(), "the managed lock was not left recorded"
    number = getattr(errno, fault)
    state = {"fired": False}
    stat_ = os.stat

    def once(name, *args, **kwargs):
        if not state["fired"] and "dir_fd" in kwargs and os.fsdecode(name) == "pin-1":
            state["fired"] = True
            raise OSError(number, os.strerror(number))
        return stat_(name, *args, **kwargs)

    monkeypatch.setattr(os, "stat", once)
    try:
        first = assets.restore("cardiac")
    except assets.ModelAssetError as refusal:
        first = {"state": refusal.code, "kept_in_place": []}
    monkeypatch.setattr(os, "stat", stat_)
    assert state["fired"], "restore never read the pid's pin"
    assert str(install / ".install.lock") not in first["kept_in_place"], first
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


# L0-R11 round 3. Each case below is a defect the adversarial verifiers
# reproduced in the round-2 work, turned into a test that fails on that work.
def _identical_rewrite(integrity: Path) -> None:
    """Another program rewrites the integrity record with the same bytes: a
    temporary file renamed over it, as install.sh's repair path does."""
    data = integrity.read_bytes()
    temporary = integrity.with_name(f".{integrity.name}.technical-rewrite")
    temporary.write_bytes(data)
    os.replace(temporary, integrity)


def _no_rollback_state(install: Path) -> list[str]:
    return sorted(entry.relative_to(install).as_posix() for entry in install.rglob("*")
                  if entry.name.startswith((".livemore-aside-", ".livemore-rollback-", ".install-cardiac-")))


def test_l0_r11_round3_a_committed_admission_rewritten_with_the_same_bytes_survives_a_sigkill(
        installer_env, monkeypatch) -> None:
    # Verifier committed_kill_identical_rewrite: killed after admission committed;
    # the record was then rewritten with identical bytes, and restore took the
    # admission for uncommitted by inode and deleted the committed model.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    spec = {"rules": [{"fn": "rmdir", "arg": 0, "name": r"^\.livemore-aside-old-", "when": "after"}]}
    code, _ = _child_rules(path, spec, "install", "cardiac")
    assert code == -signal.SIGKILL, "the installer was not killed once admission had committed"
    assert path.exists() and _release_is_valid(assets, install)
    _identical_rewrite(integrity)
    assert _release_is_valid(assets, install)
    steps = _follow(assets)
    assert steps[-1] == "check:available", steps
    assert path.exists(), "restore deleted the committed model"
    assert _release_is_valid(assets, install)
    assert _no_rollback_state(install) == []
    repeated = _run(installer_env)
    assert repeated.returncode == 0, repeated.stderr


def test_l0_r11_round3_the_previous_record_kept_aside_after_a_commit_goes_once_rewritten_identically(
        installer_env, monkeypatch, faults) -> None:
    # Verifier committed_old_aside_identical_rewrite: admission committed, the
    # previous record stayed in its `old` aside, the record was rewritten with
    # identical bytes; restore said the name was "still taken", and once the
    # person freed it, put the previous record back over a valid release.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    state = {"fired": False}
    unlink = os.unlink

    def once(name, *args, **kwargs):
        if (not state["fired"] and isinstance(name, (str, bytes, os.PathLike))
                and Path(os.fsdecode(name)).name == integrity.name):
            state["fired"] = True  # deleting the previous record from its aside
            raise OSError(errno.EIO, os.strerror(errno.EIO))
        return unlink(name, *args, **kwargs)

    faults.setattr(os, "unlink", once)
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install("cardiac")
    faults.undo()
    assert state["fired"], "admission never deleted the previous record"
    assert refused.value.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{refused.value.code}: {refused.value}"
    assert path.exists() and _release_is_valid(assets, install)
    _identical_rewrite(integrity)
    steps = []
    for _ in range(3):
        try:
            assets.check("cardiac")
            break
        except assets.ModelAssetError as error:
            assert error.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{error.code}: {error}"
        try:
            steps.append(assets.restore("cardiac")["state"])
        except assets.ModelAssetError as error:
            steps.append(error.code)
            if "still taken" in str(error):
                integrity.unlink()  # the person frees the name, as restore asked
    status = assets.check("cardiac")
    assert _release_is_valid(assets, install), f"restore put the previous record back over the release: {steps}"
    assert status["available"] is True
    assert _no_rollback_state(install) == []
    repeated = _run(installer_env)
    assert repeated.returncode == 0, repeated.stderr


@pytest.mark.parametrize("theirs", ["holding its own record.json", "empty"])
def test_l0_r11_round3_prepare_never_deletes_a_directory_put_at_its_record_name(
        installer_env, monkeypatch, faults, theirs: str) -> None:
    # Verifier prepare_replaced_record_dir[_empty]: prepare saw its record
    # directory replaced and deleted, by name, the other process's record.json
    # and directory.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    lstat = os.lstat
    state: dict = {}

    def replaced(name, *args, **kwargs):
        subject = (Path(os.fsdecode(name)) if isinstance(name, (str, bytes, os.PathLike))
                   and "dir_fd" not in kwargs else None)
        if not state and subject is not None and subject.name.startswith(".livemore-rollback-"):
            moved = subject.with_name(subject.name + "-moved-by-other")
            os.rename(subject, moved)
            os.mkdir(subject, 0o755)
            if theirs != "empty":
                _write_theirs(subject / "record.json")
            state.update(record=subject, moved=moved, inode=lstat(subject).st_ino)
        return lstat(name, *args, **kwargs)

    faults.setattr(os, "lstat", replaced)
    outcome = assets.install("cardiac")
    faults.undo()
    assert state, "prepare never read its record directory back"
    record = state["record"]
    assert record.is_dir() and lstat(record).st_ino == state["inode"], "prepare deleted the other process's directory"
    if theirs != "empty":
        assert (record / "record.json").read_bytes() == _THEIRS, "prepare deleted the other process's file"
    assert not state["moved"].exists(), "this operation's own record directory was left"
    assert outcome["available"] is True
    assert _release_is_valid(assets, install)


def test_l0_r11_round3_the_end_of_an_install_never_deletes_a_directory_put_at_its_record_name(
        installer_env, monkeypatch, faults) -> None:
    # Verifier final_discard_replaced_record_dir: the record directory was
    # emptied and removed by path; the other process's record.json and
    # directory were deleted, and this operation's pins stayed in its own,
    # moved, record directory, so the model had two links (UNSAFE_PATH).
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    discard = assets._discard_record_directory
    state: dict = {}

    def replaced(directory, *args, **kwargs):
        if not state:
            directory = Path(directory)
            moved = directory.with_name(directory.name + "-moved-by-other")
            os.rename(directory, moved)
            os.mkdir(directory, 0o755)
            _write_theirs(directory / "record.json")
            state.update(record=directory, moved=moved, inode=os.lstat(directory).st_ino)
        return discard(directory, *args, **kwargs)

    faults.setattr(assets, "_discard_record_directory", replaced)
    try:
        outcome = assets.install("cardiac")
    except assets.ModelAssetError as error:
        outcome = {"available": False, "state": error.code}
    faults.undo()
    assert state, "the install never removed its record directory"
    record = state["record"]
    assert record.is_dir() and os.lstat(record).st_ino == state["inode"], "the other process's directory was deleted"
    assert (record / "record.json").read_bytes() == _THEIRS, "the other process's record.json was deleted"
    assert not state["moved"].exists(), "this operation's own record directory was left"
    assert outcome["available"] is True, outcome
    assert os.lstat(path).st_nlink == 1
    assert _release_is_valid(assets, install)


@pytest.mark.parametrize("renamed", ["models/cardiac to models/cardiac~", "models to models.bak",
                                     "models/cardiac to models/cardiac.bak, a symlink put back"])
def test_l0_r11_round3_entries_in_a_directory_another_program_renamed_are_still_removed(
        installer_env, monkeypatch, faults, renamed: str) -> None:
    # Verifiers created_directory_renamed_within_parent and G-parent-renamed:
    # a directory this operation made was renamed after publication; rollback
    # called every entry in it absent, left them, and said nothing.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    directory = source / "models" if renamed.startswith("models to") else path.parent
    new_name = renamed.split(" to ")[1].split(",")[0].split("/")[-1]
    moved = directory.with_name(new_name)
    symlink = renamed.endswith("put back")
    link = os.link

    def published_then_renamed(source_, destination, *args, **kwargs):
        result = link(source_, destination, *args, **kwargs)
        if Path(os.fsdecode(destination)) == path and not moved.exists():
            os.rename(directory, moved)  # a backup tool, or a person's mv
            if symlink:
                os.symlink(moved.name, directory)
        return result

    faults.setattr(os, "link", published_then_renamed)
    with pytest.raises(assets.ModelAssetError):
        assets.install("cardiac")
    faults.undo()
    assert not moved.exists(), (
        f"rollback left this operation's {moved.name} and {sorted(os.listdir(moved))} in it")
    if symlink:
        # models/ holds the other program's symlink, so it stays, named in the
        # refusal as holding an entry this operation did not create. Once that
        # program removes its symlink, the person removes the empty directory.
        os.unlink(directory)
        os.rmdir(directory.parent)
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


@pytest.mark.parametrize("models", ["made by the install", "already there"])
def test_l0_r11_round3_the_model_moved_out_of_its_directory_is_reported_and_never_deleted(
        installer_env, monkeypatch, faults, models: str) -> None:
    # Verifier model_moved_to_parent[_models_preexisting]: another program moved
    # this operation's model up one directory; rollback called it absent, said
    # models/ held entries it did not create, and nothing recorded it.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    if models == "already there":
        (source / "models").mkdir()  # the release digest covers files only
    untouched = _tree(install)
    moved = path.parents[1] / path.name
    link = os.link

    def published_then_moved(source_, destination, *args, **kwargs):
        result = link(source_, destination, *args, **kwargs)
        if Path(os.fsdecode(destination)) == path and not moved.exists():
            os.rename(path, moved)
        return result

    faults.setattr(os, "link", published_then_moved)
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install("cardiac")
    faults.undo()
    message = str(refused.value)
    assert moved.read_bytes() == b"technical-cardio-fixture", "a name another program gave the model was deleted"
    assert refused.value.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{refused.value.code}: {message}"
    assert str(moved) in message and _RESTORE_COMMAND in message, message
    # Restore deletes only names this operation made: while that name holds
    # the model it refuses and names it, and the release is not reported valid.
    with pytest.raises(assets.ModelAssetError) as waiting:
        assets.restore("cardiac")
    assert str(moved) in str(waiting.value), str(waiting.value)
    assert moved.exists()
    moved.unlink()  # the person moves it out of the release
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


@pytest.mark.parametrize("original", ["removed by a third program", "still there"])
def test_l0_r11_round3_a_hard_link_another_program_made_survives_and_is_reported(
        installer_env, monkeypatch, faults, original: str) -> None:
    # Verifier hardlink_original_removed: another program linked the published
    # model as keep.cellml and a third removed the model's name; rollback found
    # keep.cellml by inode, deleted it, and reported nothing.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    keep = path.with_name("keep.cellml")
    if original == "still there":
        _fail_admission(faults, integrity)
    link = os.link

    def published_then_linked(source_, destination, *args, **kwargs):
        result = link(source_, destination, *args, **kwargs)
        if Path(os.fsdecode(destination)) == path and not keep.exists():
            link(path, keep)  # another program's own link
            if original.startswith("removed"):
                os.unlink(path)
        return result

    faults.setattr(os, "link", published_then_linked)
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install("cardiac")
    faults.undo()
    message = str(refused.value)
    assert keep.read_bytes() == b"technical-cardio-fixture", "rollback deleted another program's link"
    assert refused.value.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{refused.value.code}: {message}"
    assert str(keep) in message and _RESTORE_COMMAND in message, message
    with pytest.raises(assets.ModelAssetError) as waiting:
        assets.restore("cardiac")
    assert str(keep) in str(waiting.value) and keep.exists()
    keep.unlink()  # the person moves it out of the release
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


@pytest.mark.parametrize("target", ["another program's directory", "the moved directory"])
def test_l0_r11_round3_restore_never_acts_through_a_symlink_put_at_a_recorded_directory(
        installer_env, monkeypatch, faults, tmp_path, target: str) -> None:
    # Verifier H-restore-symlinked-parent: after rollback recorded the model,
    # attribution and lock, another program moved models/cardiac away and put a
    # symlink at its name. Restore made asides inside the symlink's target,
    # renamed that program's file, called the record finished and left this
    # operation's entries under the moved directory.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    _leave_recorded(assets, path, integrity, faults)
    cardiac = path.parent
    moved = cardiac.with_name("cardiac.moved")
    other = tmp_path / "another-program"
    other.mkdir()
    theirs = other / path.name
    theirs.write_bytes(_THEIRS)
    before = os.lstat(theirs)
    os.rename(cardiac, moved)
    os.symlink(other if target.startswith("another") else moved, cardiac)
    calls: list[str] = []
    names = ("mkdir", "rename", "link", "unlink", "rmdir", "open", "stat", "lstat", "listdir")
    real = {name: getattr(os, name) for name in names}

    def logged(name):
        def call(*args, **kwargs):
            calls.extend(os.fsdecode(argument) for argument in args
                         if isinstance(argument, (str, bytes, os.PathLike)))
            return real[name](*args, **kwargs)
        return call

    for name in names:
        faults.setattr(os, name, logged(name))
    try:
        result = assets.restore("cardiac")
    except assets.ModelAssetError as error:
        result = {"state": error.code, "message": str(error)}
    faults.undo()
    through = [call for call in calls if call.startswith(str(cardiac) + "/") or call.startswith(str(other))]
    assert through == [], f"restore acted through the symlink: {through[:6]}"
    after = os.lstat(theirs)
    assert (after.st_ino, after.st_ctime_ns) == (before.st_ino, before.st_ctime_ns), "restore touched their file"
    left = sorted(entry.name for entry in moved.rglob("*")) if moved.exists() else []
    assert left == [], f"this operation's entries were left under {moved.name}: {left}"
    assert not moved.exists(), result
    # models/ holds the other program's symlink, so restore keeps it in place
    # and says so; once that program removes its symlink, it is empty.
    assert result.get("kept_in_place") == [str(cardiac.parent)], result
    os.unlink(cardiac)
    os.rmdir(cardiac.parent)
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


def test_l0_r11_round3_check_between_the_record_directorys_mkdir_and_its_lock_is_busy(
        installer_env, monkeypatch, faults) -> None:
    # Verifier restore_between_record_mkdir_and_lock: in that instant check gave
    # the restore command, and restore removed the live installation's record
    # directory, so the installation failed.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    seen: dict = {}
    mkdir = os.mkdir

    def watched(file, *args, **kwargs):
        result = mkdir(file, *args, **kwargs)
        if (not seen and "dir_fd" not in kwargs and isinstance(file, (str, os.PathLike))
                and Path(os.fsdecode(file)).name.startswith(".livemore-rollback-")):
            for command in ("check", "restore"):
                seen[command] = _child(path, "plain", command, "cardiac")
        return result

    faults.setattr(os, "mkdir", watched)
    try:
        outcome = assets.install("cardiac")
    except assets.ModelAssetError as error:
        outcome = {"available": False, "state": error.code, "message": str(error)}
    faults.undo()
    assert seen, "the record directory was never made"
    for command, (code, output) in seen.items():
        assert code == 2 and output.get("error", {}).get("code") == "CARDIAC_MODEL_INSTALL_BUSY", (command, output)
    assert outcome["available"] is True, outcome
    assert _release_is_valid(assets, install)


def test_l0_r11_round3_a_dead_installers_pid_reused_by_another_process_never_makes_restore_wait(
        installer_env, monkeypatch, faults) -> None:
    # Verifier e7_pid_reuse: a SIGKILLed installer left its record and the
    # managed lock with pid P; once P was reused, check, restore and install
    # all refused BUSY, with no command, for as long as that process lived.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    spec = {"rules": [{"fn": "open", "arg": 0, "name": r"^ohara_rudy_cipa_2017\.cellml$", "when": "before"}]}
    code, _ = _child_rules(path, spec, "install", "cardiac")
    assert code == -signal.SIGKILL, "the installer was not killed during its download"
    (record,) = install.glob(".livemore-rollback-*")
    dead = int(record.name.split("-")[2])
    assert (install / ".install.lock" / "pid").read_text(encoding="ascii").strip() == str(dead)
    kill = os.kill

    def reused(pid, number):
        if pid == dead and number == 0:
            return None  # an unrelated, long-lived process now has that pid
        return kill(pid, number)

    faults.setattr(os, "kill", reused)
    steps = _follow(assets)
    faults.undo()
    _clean_end(assets, installer_env, install, untouched, steps)


def _set_group_id_inherited(patch) -> None:
    """Linux gives every directory made inside a set-group-ID directory that
    bit too, whatever mode mkdir asks for (verifier K-linux-setgid); macOS
    does not, so there it is emulated."""
    if sys.platform.startswith("linux"):
        return
    mkdir = os.mkdir

    def inherited(path, mode=0o777, *, dir_fd=None):
        mkdir(path, mode, dir_fd=dir_fd)
        parent = os.path.dirname(os.fsdecode(path)) or "."
        if os.stat(parent, dir_fd=dir_fd).st_mode & stat.S_ISGID:
            current = stat.S_IMODE(os.stat(path, dir_fd=dir_fd, follow_symlinks=False).st_mode)
            os.chmod(path, current | stat.S_ISGID, dir_fd=dir_fd)

    patch.setattr(os, "mkdir", inherited)


def _set_group_id(directories: list[Path], on: bool) -> None:
    for directory in directories:
        mode = stat.S_IMODE(os.lstat(directory).st_mode)
        os.chmod(directory, mode | stat.S_ISGID if on else mode & ~stat.S_ISGID)


@pytest.mark.parametrize("run", ["success", "failure"])
def test_l0_r11_round3_an_install_in_a_set_group_id_release_finishes_and_leaves_nothing(
        installer_env, monkeypatch, faults, run: str) -> None:
    # Verifier K-linux-setgid: under `chmod g+s` (a shared install location) the
    # rollback's private directories are 02700. Every install refused
    # ASIDE_PENDING over its own empty staging directory, and restore refused
    # the record as "mode 2700", for ever.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    shared = [install, *[entry for entry in install.rglob("*") if entry.is_dir() and not entry.is_symlink()]]
    _set_group_id(shared, True)
    if not all(os.lstat(directory).st_mode & stat.S_ISGID for directory in shared):
        _set_group_id(shared, False)
        pytest.skip("this account cannot set the set-group-ID bit here")
    untouched = _tree(install)
    _set_group_id_inherited(faults)
    if run == "failure":
        _fail_admission(faults, integrity)
    try:
        try:
            outcome = assets.install("cardiac")
        except assets.ModelAssetError as error:
            outcome = {"available": False, "state": error.code, "message": str(error)}
        faults.undo()
        _set_group_id_inherited(faults)
        steps = _follow(assets)
        left = _no_rollback_state(install)
    finally:
        faults.undo()
        _set_group_id([install, *[entry for entry in install.rglob("*")
                                  if entry.is_dir() and not entry.is_symlink()]], False)
    assert left == [], left
    if run == "success":
        assert outcome["available"] is True, outcome
        assert steps == ["check:available"], steps
        assert _release_is_valid(assets, install)
    else:
        assert outcome["state"] != "CARDIAC_MODEL_ASIDE_PENDING", outcome
        assert steps == ["check:CARDIAC_MODEL_NOT_INSTALLED"], steps
        assert _release_is_valid(assets, install)
        assert set(_tree(install)) == set(untouched)
    repeated = _run(installer_env)
    assert repeated.returncode == 0, repeated.stderr


def _long_directory(base: Path, total: int) -> Path:
    """A directory path of exactly `total` characters under base, in components
    the volume accepts (verifier A, test_long_path.py)."""
    path = str(base)
    need = total - len(path)
    assert need >= 2
    while need > 0:
        take = min(200, need - 1)
        if need - (take + 1) == 1:
            take -= 1
        path += "/" + "d" * take
        need = total - len(path)
    assert len(path) == total
    return Path(path)


@pytest.mark.parametrize("margin", [80, 56])
def test_l0_r11_round3_a_rollback_never_needs_a_longer_path_than_the_install(
        installer_env, monkeypatch, tmp_path, margin: int) -> None:
    # Verifier A2-long-path-plain: an aside path is ~56 characters longer than
    # the entry it holds, so near PATH_MAX the empty staging directory, or a
    # failed install's entries, could never be moved aside, and restore refused
    # for ever. margin 80 is a cardiac directory where the install itself fits;
    # at margin 56 the install's own staged attribution does not.
    limit = os.pathconf(tmp_path, "PC_PATH_MAX")
    install = _long_directory(tmp_path / "long", limit - margin - 72)
    install.parent.mkdir(parents=True, exist_ok=True)
    installer_env["LIVEMORE_INSTALL_DIR"] = str(install)
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    assert len(str(path.parent)) == limit - margin
    untouched = _tree(install)
    try:
        outcome = assets.install("cardiac")
    except assets.ModelAssetError as error:
        outcome = {"available": False, "state": error.code, "message": str(error)}
    steps = _follow(assets)
    assert _no_rollback_state(install) == [], (outcome, steps)
    assert _release_is_valid(assets, install), (outcome, steps)
    if margin == 80:
        assert outcome["available"] is True, outcome
        assert steps == ["check:available"], steps
    else:
        assert outcome["state"] != "CARDIAC_MODEL_ASIDE_PENDING", outcome
        assert steps == ["check:CARDIAC_MODEL_NOT_INSTALLED"], steps
        assert _tree(install) == untouched


# L0-R13. Codex's fourth review of 8c9f9a5 (l0-review4-report.txt). Each case
# below fails on 8c9f9a5 for the reason its comment gives.
class _UncertainPublication:
    """A publication that takes effect and still reports an error, on a volume
    that then cannot say whether it did (review 4, major 1): the `call` that
    publishes `target` takes effect and raises `number`; from then on, while
    armed, every lstat of `target` and every rename of it fail with EIO, so
    neither the confirming lstat nor the rollback's move aside can act on it."""

    def __init__(self, patch, call: str, target: Path, number: int):
        self.armed = True
        self.fired = False
        real = {name: getattr(os, name) for name in ("link", "mkdir", "lstat", "stat", "rename")}

        def failing() -> None:
            raise OSError(errno.EIO, os.strerror(errno.EIO))

        def published(*args, **kwargs):
            result = real[call](*args, **kwargs)
            destination = args[1] if call == "link" else args[0]
            if (self.armed and not self.fired and "dir_fd" not in kwargs and "dst_dir_fd" not in kwargs
                    and Path(os.fsdecode(destination)) == target):
                self.fired = True
                raise OSError(number, os.strerror(number))
            return result

        def at_target(args, kwargs) -> bool:
            return (self.armed and self.fired and bool(args) and isinstance(args[0], (str, bytes, os.PathLike))
                    and kwargs.get("dir_fd") is None and kwargs.get("src_dir_fd") is None
                    and Path(os.fsdecode(args[0])) == target)

        def lstat(*args, **kwargs):
            if at_target(args, kwargs):
                failing()
            return real["lstat"](*args, **kwargs)

        def stat_(*args, **kwargs):
            if kwargs.get("follow_symlinks", True) is False and at_target(args, kwargs):
                failing()
            return real["stat"](*args, **kwargs)

        def rename(*args, **kwargs):
            if at_target(args, kwargs):
                failing()
            return real["rename"](*args, **kwargs)

        patch.setattr(os, call, published)
        patch.setattr(os, "lstat", lstat)
        patch.setattr(os, "stat", stat_)
        patch.setattr(os, "rename", rename)


@pytest.mark.parametrize(("entry", "call", "reported"), [
    ("the lock", "link", "EIO"),
    ("the model", "link", "EEXIST"),
    ("the attribution", "link", "EEXIST"),
    ("models/cardiac", "mkdir", "EIO"),
])
def test_l0_r13_an_uncertain_publication_keeps_its_record_and_restore_removes_it(
        installer_env, monkeypatch, faults, entry: str, call: str, reported: str) -> None:
    # Review 4, major 1 (model_assets.py:1235): publishing an entry took effect
    # and reported an error, and the confirming lstat failed too. The handler
    # took the entry off the record (forget), so the release kept it, failing
    # its integrity record, with nothing for restore to report or remove.
    # EEXIST is what a retransmitted NFS LINK reports for a link that took effect.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    target = {"the lock": path.parent / ".install.lock", "the model": path,
              "the attribution": path.with_suffix(".cellml.attribution.json"),
              "models/cardiac": path.parent}[entry]
    fault = _UncertainPublication(faults, call, target, getattr(errno, reported))
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install("cardiac")
    faults.undo()
    assert fault.fired, f"{entry} was never published"
    assert target.exists(), f"the rollback removed {entry}; the case needs it left at its name"
    message = str(refused.value)
    steps = _follow(assets)
    assert "restore:restored" in steps, (
        f"restore never found {entry} ({steps}); install refused {refused.value.code}: {message}")
    assert refused.value.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{refused.value.code}: {message}"
    assert str(target) in message and _RESTORE_COMMAND in message, message
    _clean_end(assets, installer_env, install, untouched, steps)


_INSTALL_SH_LOCK_STEP = r'''
set -euo pipefail
IFS=$'\n\t'
INSTALL_BASE="$1"; READY="$2"; GO="$3"; RELEASE="$4"
fail() { printf 'FAIL %s\n' "$*" >&2; exit 1; }
info() { :; }
# The test holds install.sh between its mkdir of the lock and its pid write.
mkdir() { command mkdir "$@" || return $?; : > "$READY"; until [ -e "$GO" ]; do sleep 0.02; done; }
@ACQUIRE_LOCK@
acquire_lock
: > "$READY.held"
until [ -e "$RELEASE" ]; do sleep 0.02; done
# install.sh's own release of its lock (cleanup).
rm -f -- "$LOCK_DIRECTORY/pid"
rmdir "$LOCK_DIRECTORY"
'''


def _wait_for(condition, seconds: float = 30.0) -> bool:
    import time

    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if condition():
            return True
        time.sleep(0.02)
    return condition()


@pytest.mark.parametrize("moment", ["between its mkdir and its pid", "holding its pid"])
def test_l0_r13_restore_never_takes_the_lock_install_sh_holds(
        installer_env, monkeypatch, tmp_path, moment: str) -> None:
    # Review 4, minor 2 (model_assets.py:2495): installation A was killed after
    # its record listed the managed lock it was about to make. install.sh then
    # took the lock. Restore adopted install.sh's lock as A's, because A's
    # record holds no identity for it: before install.sh wrote its pid, restore
    # deleted the empty directory and install.sh's pid write failed; holding
    # its pid, restore moved it aside and back and called itself finished.
    import threading

    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    lock = install / ".install.lock"
    code, _ = _child_rules(path, {"rules": [{"fn": "mkdir", "arg": 0, "name": r"^\.install\.lock$",
                                             "when": "before"}]}, "install", "cardiac")
    assert code == -signal.SIGKILL, "installation A was not killed before its lock's mkdir"
    (record,) = install.glob(".livemore-rollback-*")
    listed = json.loads((record / "record.json").read_text(encoding="utf-8"))["entries"]
    assert [item["path"] for item in listed] == [str(lock)] and listed[0]["inode"] is None, listed
    assert not lock.exists()

    # Installation B: install.sh's own lock step, taken from install.sh.
    from . import test_installer

    installer = test_installer.INSTALLER.read_text(encoding="utf-8")
    body = installer.split("\nacquire_lock() {\n", 1)[1].split("\n}\n", 1)[0]
    script = _INSTALL_SH_LOCK_STEP.replace("@ACQUIRE_LOCK@", "acquire_lock() {\n" + body + "\n}")
    ready, go, release = tmp_path / "b-ready", tmp_path / "b-go", tmp_path / "b-release"
    held = Path(str(ready) + ".held")
    if moment == "holding its pid":
        go.touch()
    b = subprocess.Popen(["bash", "-c", script, "install.sh-lock-step", str(install), str(ready), str(go),
                          str(release)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                         encoding="utf-8")
    timer = None
    try:
        assert _wait_for(lambda: ready.exists() or b.poll() is not None), "install.sh never made its lock"
        if moment == "holding its pid":
            assert _wait_for(lambda: held.exists() or b.poll() is not None)
        else:
            # install.sh writes its pid in the statement after its mkdir; here a
            # little later than usual, while restore looks at the lock.
            timer = threading.Timer(0.3, go.touch)
            timer.start()
        try:
            outcome = assets.restore("cardiac")["state"]
        except assets.ModelAssetError as error:
            outcome = error.code
        if timer is not None:
            timer.join()
        assert _wait_for(lambda: held.exists() or b.poll() is not None)
        assert b.poll() is None, f"install.sh's lock step failed: {b.communicate()[1]}"
        assert (lock / "pid").read_text(encoding="ascii").strip() == str(b.pid), "restore took install.sh's lock"
        assert outcome == "CARDIAC_MODEL_INSTALL_BUSY", f"restore acted while install.sh held its lock: {outcome}"
    finally:
        if timer is not None:
            timer.cancel()
        go.touch()
        release.touch()
        b.communicate(timeout=60)
    assert b.returncode == 0, "install.sh could not release its own lock"
    assert not lock.exists()
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


@pytest.mark.parametrize("fault", ["opening", "listing"])
def test_l0_r13_restore_that_cannot_read_the_recovery_state_refuses(
        installer_env, monkeypatch, faults, fault: str) -> None:
    # Review 4, minor 3 (model_assets.py:1807): an error opening or listing a
    # directory that holds recovery state was ignored, so restore answered
    # nothing_pending while a record listed entries left in the release.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    _leave_recorded(assets, path, integrity, faults)
    (record,) = install.glob(".livemore-rollback-*")
    opened, listed = os.open, os.listdir
    state = {"fired": 0}

    def failing_open(file, flags, *args, **kwargs):
        if (fault == "opening" and flags & os.O_DIRECTORY and "dir_fd" not in kwargs
                and isinstance(file, (str, os.PathLike)) and Path(os.fsdecode(file)) == install):
            state["fired"] += 1
            raise OSError(errno.EIO, os.strerror(errno.EIO), os.fsdecode(file))
        return opened(file, flags, *args, **kwargs)

    def failing_listdir(*args):
        if fault == "listing" and args and isinstance(args[0], int) and _descriptor_path(args[0]) == install:
            state["fired"] += 1
            raise OSError(errno.EIO, os.strerror(errno.EIO))
        return listed(*args)

    faults.setattr(os, "open", failing_open)
    faults.setattr(os, "listdir", failing_listdir)
    try:
        outcome = assets.restore("cardiac")
    except assets.ModelAssetError as error:
        outcome = {"state": error.code, "message": str(error)}
    faults.undo()
    assert state["fired"], f"restore never read the directory that holds the record ({fault})"
    assert outcome["state"] != "nothing_pending", f"restore said nothing_pending while {record.name} was pending"
    assert outcome["state"] == "CARDIAC_MODEL_UNSAFE_PATH", outcome
    assert str(install) in outcome["message"] and _RESTORE_COMMAND in outcome["message"], outcome
    assert record.is_dir() and path.exists(), "restore changed the state it could not read"
    _clean_end(assets, installer_env, install, untouched, _follow(assets))


def test_l0_r13_restore_reports_an_aside_directory_it_cannot_remove(installer_env, monkeypatch, faults) -> None:
    # Review 4, minor 3 (model_assets.py:2151): restore emptied an aside
    # directory, failed to remove it, ignored the error and said restored;
    # the empty directory stayed, with no command given for it.
    assets, source, path, integrity = _standalone_cardiac_fixture(installer_env, monkeypatch)
    install = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    untouched = _tree(install)
    _fail_admission(faults, integrity)
    _aside_fault(faults, "unlink", lambda subject: subject.name == path.name)
    with pytest.raises(assets.ModelAssetError) as refused:
        assets.install("cardiac")
    faults.undo()
    assert refused.value.code == "CARDIAC_MODEL_ASIDE_PENDING", f"{refused.value.code}: {refused.value}"
    (aside,) = _no_aside(install)
    rmdir = os.rmdir
    state = {"fired": False}

    def failing_rmdir(name, *args, **kwargs):
        if (not state["fired"] and "dir_fd" in kwargs and isinstance(name, (str, bytes))
                and os.fsdecode(name) == Path(aside).name):
            state["fired"] = True
            raise OSError(errno.EIO, os.strerror(errno.EIO))
        return rmdir(name, *args, **kwargs)

    faults.setattr(os, "rmdir", failing_rmdir)
    try:
        outcome = assets.restore("cardiac")
    except assets.ModelAssetError as error:
        outcome = {"state": error.code, "message": str(error)}
    faults.undo()
    assert state["fired"], "restore never removed the aside directory"
    assert outcome["state"] != "restored", f"restore said restored and left {aside}"
    assert outcome["state"] == "CARDIAC_MODEL_ASIDE_PENDING", outcome
    assert str(install / aside) in outcome["message"] and _RESTORE_COMMAND in outcome["message"], outcome
    _clean_end(assets, installer_env, install, untouched, _follow(assets))
