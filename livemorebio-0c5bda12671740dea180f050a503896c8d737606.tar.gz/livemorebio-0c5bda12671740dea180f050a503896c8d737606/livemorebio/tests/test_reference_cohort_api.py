"""HTTP parity on authored technical records, never enrolled people."""
from fastapi import FastAPI
from fastapi.testclient import TestClient
import pytest

from livemorebio.aegle import reference_cohort_api as api
from livemorebio.aegle import reference_cohorts as cohorts
from livemorebio.aegle import population_records as records
from livemorebio.tests.test_population_records import tables
from livemorebio.tests.test_reference_cohort_lifecycle import draft

AUTH={'Authorization':'Bearer technical-reference-test'}


@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setenv('LIVEMORE_API_TOKEN','technical-reference-test')
    monkeypatch.setenv('LIVEMORE_POPULATION_SOURCE_DIR',str(tmp_path/'source-cache'))
    monkeypatch.setattr(cohorts,'normalization_version',lambda:'technical-normalization-v1')
    monkeypatch.setattr(cohorts.ReferenceCohortService,'_load_population',lambda self:records._normalize_tables(tables(),fingerprint_key=self.fingerprint_key))
    service=cohorts.ReferenceCohortService(tmp_path/'registry'/'subjects.sqlite3',key=b'k'*32,source_dir=tmp_path/'source-cache')
    monkeypatch.setattr(api,'service',lambda:service)
    app=FastAPI();app.include_router(api.router)
    return TestClient(app,raise_server_exceptions=False),service


@pytest.mark.parametrize('method,path',[
    ('GET','/api/population-sources'),('POST','/api/population-sources/source/install'),
    ('POST','/api/reference-cohorts/preview'),('POST','/api/reference-cohorts'),
    ('GET','/api/reference-cohorts/cohort/members'),('GET','/api/reference-cohorts/cohort/members/member'),
])
def test_auth_before_any_reference_access(client,monkeypatch,method,path):
    c,_=client
    monkeypatch.setattr(api,'service',lambda:pytest.fail('auth before storage'))
    response=c.request(method,path,json={})
    assert response.status_code==401 and response.headers['cache-control']=='no-store'


def test_http_preview_create_page_get_and_retry_share_contract(client):
    c,_=client
    preview=c.post('/api/reference-cohorts/preview',headers=AUTH,json=draft())
    assert preview.status_code==200 and preview.headers['cache-control']=='no-store'
    body={'draft':draft(),'preview_token':preview.json()['preview_token']}
    created=c.post('/api/reference-cohorts',headers={**AUTH,'Idempotency-Key':'technical-retry'},json=body)
    assert created.status_code==201 and created.json()['executable'] is False
    cohort_id=created.json()['cohort_id']
    replay=c.post('/api/reference-cohorts',headers={**AUTH,'Idempotency-Key':'technical-retry'},json=body)
    assert replay.status_code==200 and replay.json()['cohort_id']==cohort_id
    page=c.get(f'/api/reference-cohorts/{cohort_id}/members?limit=2',headers=AUTH)
    assert page.status_code==200 and len(page.json()['members'])==2
    member=page.json()['members'][0]
    assert c.get(f'/api/reference-cohorts/{cohort_id}/members/{member["member_id"]}',headers=AUTH).json()==member
    assert c.get(f'/api/reference-cohorts/{cohort_id}/members?limit=0',headers=AUTH).status_code==422


@pytest.mark.parametrize('raw',['{"name":1,"name":2}','{"size":NaN}','{'+'"x":'*100+'0'+'}'*100,'{"x":"'+'x'*17000+'"}'])
def test_bounded_unambiguous_json_rejects_before_selection(client,monkeypatch,raw):
    c,_=client
    monkeypatch.setattr(api,'service',lambda:pytest.fail('parse before storage'))
    response=c.post('/api/reference-cohorts/preview',headers=AUTH,content=raw)
    assert response.status_code==422 and response.headers['cache-control']=='no-store'


def test_status_does_not_install_and_install_requires_explicit_fixed_use(client,monkeypatch):
    c,_=client;calls=[]
    monkeypatch.setattr(api.sources,'install_source',lambda path,**kwargs:calls.append((path,kwargs)) or {'available':True,'state':'verified'})
    status=c.get('/api/population-sources',headers=AUTH)
    assert status.status_code==200 and calls==[]
    path=f'/api/population-sources/{cohorts.SOURCE_ID}/install'
    assert c.post(path,headers=AUTH,json={}).status_code==422 and calls==[]
    assert c.post(path,headers=AUTH,json={'accepted_use':'statistical_research','path':'untrusted'}).status_code==422 and calls==[]
    assert c.post(path,headers=AUTH,json={'accepted_use':'statistical_research'}).status_code==200
    assert len(calls)==1 and calls[0][1]=={'accepted_use':'statistical_research'}


def test_storage_errors_are_no_store_and_do_not_echo_private_paths(client,monkeypatch):
    c,_=client
    def fail():raise OSError('private participant path')
    monkeypatch.setattr(api,'service',fail)
    response=c.post('/api/reference-cohorts/preview',headers=AUTH,json=draft())
    assert response.status_code==503 and 'private participant' not in response.text
    assert response.headers['cache-control']=='no-store'


def test_existing_route_projection_audits_only_new_records_and_omits_manifest(client,monkeypatch):
    _,service=client
    legacy={'cohort_id':'legacy','members':[{'opaque':'legacy'}]}
    assert api.project_cohort_summary_for_api(legacy)==legacy
    preview=service.preview(draft())
    created=service.create({'draft':draft(),'preview_token':preview['preview_token']},idempotency_key='projection')
    assert 'member_manifest' not in api.project_cohort_summary_for_api(created)
    def fail(*args,**kwargs):raise OSError('private audit unavailable')
    monkeypatch.setattr(service,'_audit',fail)
    with pytest.raises(cohorts.ReferenceCohortError):api.project_cohort_summary_for_api(created)
