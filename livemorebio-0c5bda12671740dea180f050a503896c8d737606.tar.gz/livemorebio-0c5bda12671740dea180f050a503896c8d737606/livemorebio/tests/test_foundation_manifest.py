"""Whole-human foundation contract tests.

The manifest is the boundary between Livemore's complete-human product goal and
the smaller set of biological systems that are executable today. These tests
prevent architecture coverage from being presented as scientific maturity.
"""
from __future__ import annotations

import json
import sys


def test_manifest_represents_every_ontology_system_exactly_once():
    from livemorebio.anatomy import load_ontology
    from livemorebio.foundation import whole_human_manifest

    ontology_ids = set(load_ontology().systems)
    manifest = whole_human_manifest()
    manifest_ids = [system["id"] for system in manifest["systems"]]

    assert len(manifest_ids) == len(set(manifest_ids))
    assert set(manifest_ids) == ontology_ids
    assert manifest["coverage"]["registered_systems"] == len(ontology_ids)
    assert manifest["coverage"]["ontology_systems"] == len(ontology_ids)


def test_manifest_distinguishes_architectural_coverage_from_functional_maturity():
    from livemorebio.foundation import MATURITY_CLAIMS, whole_human_manifest

    manifest = whole_human_manifest()
    systems = {system["id"]: system for system in manifest["systems"]}

    assert tuple(manifest["maturity_claims"]) == MATURITY_CLAIMS
    assert all(tuple(system["maturity"]) == MATURITY_CLAIMS for system in systems.values())
    assert all(
        manifest["coverage"][f"{claim}_systems"]
        == sum(system["maturity"][claim] for system in systems.values())
        for claim in MATURITY_CLAIMS
    )
    assert all(system["maturity"]["registered"] for system in systems.values())
    assert all(system["maturity"]["reference_backed"] for system in systems.values())
    reference_basis = manifest["reference_basis"]
    assert reference_basis["authoritative_resources"]
    assert all(
        system["ontology"]["reference_basis_id"] == reference_basis["id"]
        for system in systems.values()
    )

    assert systems["cardiovascular"]["maturity"]["modeled"] is True
    assert systems["cardiovascular"]["maturity"]["coupled"] is True
    assert systems["endocrine"]["maturity"]["modeled"] is True
    assert systems["endocrine"]["maturity"]["coupled"] is True

    for system_id, system in systems.items():
        if system_id not in {"cardiovascular", "endocrine"}:
            assert system["maturity"]["modeled"] is False
            assert system["functional_claim"] == "UNAVAILABLE"

    assert not any(
        system["maturity"][claim]
        for system in systems.values()
        for claim in (
            "person_calibrated",
            "context_validated",
            "independently_replicated",
            "device_connected",
        )
    )


def test_manifest_is_fresh_and_callers_cannot_promote_cached_claims():
    from livemorebio.foundation import whole_human_manifest

    first = whole_human_manifest()
    first["systems"][0]["maturity"]["context_validated"] = True

    second = whole_human_manifest()
    assert second["systems"][0]["maturity"]["context_validated"] is False


def test_three_product_and_patch_contracts_are_explicit():
    from livemorebio.foundation import whole_human_manifest

    manifest = whole_human_manifest()
    products = manifest["products"]

    assert set(products) == {"LIFE", "Aegle", "Cendos"}
    assert products["LIFE"]["role"] == "measurement_and_device_data_plane"
    assert products["LIFE"]["sensor_schema_source"] == "legacy_rev_a_1_research_package"
    assert "reconciliation" in products["LIFE"]["sensor_schema_status"]
    assert products["Aegle"]["scenario_policy"] == "isolated_from_live_twin"
    assert products["Cendos"]["claim_policy"] == "returned_artifacts_required"

    patches = products["LIFE"]["patches"]
    assert patches["physical"]["hardware_validated"] is False
    assert patches["physical"]["local_safety_controller_required"] is True
    assert patches["virtual"]["mountable_on_twin"] is True
    assert patches["virtual"]["may_claim_physical_measurement"] is False


def test_rosalind_is_a_governed_external_handoff_not_a_fake_execution():
    from livemorebio.foundation import whole_human_manifest

    rosalind = whole_human_manifest()["products"]["Cendos"]["workbenches"]["rosalind"]
    assert rosalind["integration"] == "external_governed_artifact_handoff"
    assert rosalind["execution_reported"] is False
    assert rosalind["required_return_provenance"]


def test_reference_candidates_never_claim_an_adapter_that_is_not_implemented():
    from livemorebio.foundation import whole_human_manifest

    adapters = whole_human_manifest()["reference_adapters"]
    assert all(adapter["enabled"] is False for adapter in adapters)
    nar = next(adapter for adapter in adapters if adapter["id"] == "nar_database_summary_collection")
    assert nar["discovery_review_completed"] is True


def test_platform_exposes_manifest_without_mutating_the_live_twin():
    from livemorebio.sdk import Platform

    platform = Platform(mode="inprocess")
    before = platform.state()
    manifest = platform.manifest()
    after = platform.state()

    assert manifest["coverage"]["ontology_systems"] >= 15
    assert after == before


def test_read_only_api_returns_the_same_manifest():
    from fastapi.testclient import TestClient

    from livemorebio.aegle.server import app
    from livemorebio.foundation import whole_human_manifest

    response = TestClient(app).get("/api/system-manifest")
    assert response.status_code == 200
    assert response.json() == whole_human_manifest()


def test_terminal_manifest_outputs_json(monkeypatch, capsys):
    from livemorebio.cli import main

    monkeypatch.setattr(sys, "argv", ["livemore", "manifest"])
    main()
    output = json.loads(capsys.readouterr().out)

    assert output["product"] == "Livemore Whole-Human Foundation"
    assert output["coverage"]["ontology_systems"] >= 15
