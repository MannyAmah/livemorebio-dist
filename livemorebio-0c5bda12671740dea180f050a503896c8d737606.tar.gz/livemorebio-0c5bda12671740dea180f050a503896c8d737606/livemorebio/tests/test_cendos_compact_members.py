import json
import re
import subprocess
from pathlib import Path
from ._node import run_node as _run_node

HTML = Path(__file__).parents[1] / "aegle/console/cendos.html"


def test_cendos_results_bound_table_rows_and_preserve_exact_member():
    source = HTML.read_text(encoding="utf-8")
    match = re.search(r"function protocolMemberPage\(.*?\n}\n", source, re.S)
    assert match, "A bounded member result pager is required"
    script = match[0] + """
const rows=Array.from({length:10000},(_,i)=>({member_id:'technical-member-'+i,cohort:'cohort-'+(i%2),delta_mean:i===9999?0:-i}));
const first=protocolMemberPage(rows,0,25,'');if(first.rows.length!==25||first.page!==0||first.total!==10000)throw Error('unbounded first page');
const last=protocolMemberPage(rows,9999,50,'');if(last.rows.length!==50||last.rows.at(-1).member_id!=='technical-member-9999'||last.rows.at(-1).delta_mean!==0)throw Error('last page altered');
const found=protocolMemberPage(rows,0,25,'technical-member-9999');if(found.rows.length!==1||found.rows[0].delta_mean!==0)throw Error('search altered data');
"""
    result = _run_node(["node", "--eval", script], capture_output=True, text=True, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_cendos_selection_starts_explicit_and_blocks_duplicate_navigation():
    source = HTML.read_text(encoding="utf-8")
    assert 'id="cohort-protocol-choice"' in source
    assert 'id="protocol-member-search"' in source
    assert 'PROTOCOL_BUSY||cohortLoading' in source
    assert "selectedIndex=1" not in source


def test_descriptive_public_cohorts_are_visible_but_never_execution_options():
    source=HTML.read_text(encoding="utf-8")
    match=re.search(r"function cohortProtocolEligibility\(.*?\n}\n",source,re.S)
    assert match, 'Cendos needs an explicit descriptive cohort boundary'
    script=match[0]+"""
const records=[{source_class:'PUBLIC_REFERENCE',cohort_id:'public',stratum:'pxr-reference',executable:true},{source_class:'REFERENCE_GROUNDED_SYNTHETIC',cohort_id:'legacy',stratum:'pxr-reference'}];
if(cohortProtocolEligibility(records[0])!=='unbound_reference')throw Error('public executable override');
if(cohortProtocolEligibility(records[1])!=='pxr')throw Error('legacy cohort changed');
"""
    result=_run_node(['node','--eval',script],capture_output=True,text=True, encoding="utf-8")
    assert result.returncode==0,result.stderr
    assert 'id="unbound-reference-cohorts"' in source


def test_descriptive_real_cohorts_are_retained_for_explicit_bounded_inspection():
    source=HTML.read_text(encoding="utf-8")
    script=source[source.index('function cohortProtocolEligibility('):source.index('function chooseCohortProtocol(')]
    code=r"""
const assert=require('node:assert/strict'),nodes=new Map();
const $=id=>{if(!nodes.has(id))nodes.set(id,{value:'',innerHTML:'',hidden:false,options:[],querySelector(){return this},querySelectorAll(){return[]}});return nodes.get(id)};
const esc=String;let MET_COHORTS=[],PXR_COHORTS=[],PROTOCOL_BUSY=false;const setProtocolBusy=()=>{},realCohortInspectors=new Map();
const COHORTS=[{cohort_id:'cohort-technical',source_class:'REAL_HUMAN',name:'Technical descriptive cohort',size:1000,execution_eligibility:{state:'UNAVAILABLE',reason_code:'MODEL_BINDING_REQUIRED'}},{cohort_id:'cohort-old',source_class:'REFERENCE_GROUNDED_SYNTHETIC',stratum:'pxr-reference',name:'Preserved reference',size:4}];
SOURCE
assert.equal(cohortProtocolEligibility(COHORTS[0]),'unbound_real');populateCohorts();assert.equal(MET_COHORTS.length,0);assert.equal(PXR_COHORTS.length,1);
assert($('unbound-real-cohorts').innerHTML.includes('MODEL_BINDING_REQUIRED'));assert($('unbound-real-cohorts').innerHTML.includes('Inspect members'));assert($('unbound-real-cohorts').innerHTML.length<5000);
""".replace('SOURCE',script)
    result=_run_node(['node','--eval',code],capture_output=True,text=True, encoding="utf-8")
    assert result.returncode==0,result.stderr
    assert "'REAL_HUMAN'" in re.search(r'COHORTS=Array.from.*',source)[0]


def test_real_population_guidance_requires_admission_not_selected_active_state():
    module=(HTML.parent/'lib/population_forms.js').as_uri()
    code=f"import {{populationGuidance}} from {json.dumps(module)};"+"""
const cohort=populationGuidance('cohorts','REAL_HUMAN').help;
if(cohort.includes('active real-human')||!cohort.includes('cendos_validation'))throw Error('selected state still required instead of research consent');
const twin=populationGuidance('twins','REAL_HUMAN').help;
if(!twin.includes('Observations only')||!twin.includes('binding'))throw Error('descriptive admission misrepresented');
"""
    result=_run_node(['node','--input-type=module','--eval',code],capture_output=True,text=True, encoding="utf-8")
    assert result.returncode==0,result.stderr


def test_current_assay_unavailable_clears_prior_readouts_but_preserves_frozen_protocol():
    source=HTML.read_text(encoding="utf-8");script=source[source.index('async function loadTwin()'):source.index('function setCmp(')]
    code=r"""
const assert=require('node:assert/strict'),nodes=new Map();const $=id=>{if(!nodes.has(id))nodes.set(id,{textContent:'OLD_CURRENT_QUANTITY',title:'',style:{display:''},disabled:false});return nodes.get(id)};
let PROTOCOL_BUSY=false,CURRENT_MODEL_AVAILABLE=true,CURRENT_TWIN_CONTEXT='old',twinReadSequence=0,CURRENT_RUN={run_id:'frozen-history'},payload={context_id:'new',profile:null,human:{id:'technical'},metabolic:null,model_availability:{schema:'livemore.model-availability.v1',state:'UNAVAILABLE',reason_code:'MODEL_BINDING_REQUIRED',preparation_available:false}};
const fetch=async()=>({ok:true,json:async()=>payload});
SOURCE
(async()=>{await loadTwin();assert(!nodes.get('twinSrc').textContent.includes('null'));assert(nodes.get('twinSrc').textContent.includes('MODEL_BINDING_REQUIRED'));assert.equal(nodes.get('run-current-assay').disabled,true);assert.equal(nodes.get('resultCard').style.display,'none');assert.equal(CURRENT_RUN.run_id,'frozen-history');assert(!CURRENT_MODEL_AVAILABLE);})().catch(e=>{console.error(e);process.exitCode=1});
""".replace('SOURCE',script)
    result=_run_node(['node','--eval',code],capture_output=True,text=True, encoding="utf-8")
    assert result.returncode==0,result.stderr
