"""Public installation instructions execute only the public download route."""
from __future__ import annotations

import hashlib
from pathlib import Path
import re
import shutil
import subprocess
import sys

import pytest

from ._source_tree import require_source_tree, verifying_container_image
from .test_stable_new5c_pass_r_docs import PUBLIC_LANDING_PAGES

ROOT = Path(__file__).resolve().parents[2]
URL = "https://raw.githubusercontent.com/MannyAmah/livemorebio-dist/"
PINNED_URL = URL + "$dist_commit/install.sh"
NATIVE_GUIDES = ["README.md"]
if not verifying_container_image():
    NATIVE_GUIDES.extend(("docs/LAUNCH_GUIDE.md", "docs/EXTERNAL_TESTER_GUIDE.md",
                         "docs/BUSINESS_CLIENT_GUIDE.md"))
if (ROOT / ".git").exists() or any((ROOT / name).exists() for name in PUBLIC_LANDING_PAGES):
    NATIVE_GUIDES.extend(PUBLIC_LANDING_PAGES)
PRIVATE_INSTALL_ROUTE = re.compile(
    r"MannyAmah/livemorebio(?!-dist\b)|\bLIVEMORE_REF\s*=|\bgh[ \t]+[a-z][\w-]*\b", re.IGNORECASE
)


def test_l0_r19_install_guides_name_version_and_offline_version_command():
    require_source_tree("docs/LAUNCH_GUIDE.md")
    guides = ["docs/LAUNCH_GUIDE.md"]
    if any((ROOT / name).exists() for name in PUBLIC_LANDING_PAGES):
        guides.append(next(name for name in PUBLIC_LANDING_PAGES if name.endswith("/INSTALL.md")))
    for relative in guides:
        text = (ROOT / relative).read_text(encoding="utf-8")
        assert "0.1.0" in text, relative
        assert "livemore --version" in text, relative
        assert "docker compose exec aegle livemore --version" in text, relative


def _shipped_documents(root: Path) -> list[str]:
    paths = (root / "tools/public_release_manifest.txt").read_text(encoding="utf-8").splitlines()
    return [relative for relative in paths if not relative.endswith("/") and (
        relative.startswith("docs/") or Path(relative).suffix.lower() in {".md", ".rst", ".txt", ".html", ".ipynb"}
        or relative == "LICENSE")]


def test_no_shipped_document_installs_from_private_repository():
    require_source_tree("docs/LAUNCH_GUIDE.md")
    for relative in _shipped_documents(ROOT):
        text = (ROOT / relative).read_text(encoding="utf-8")
        assert not PRIVATE_INSTALL_ROUTE.search(text), relative
    for relative in ("README.md", "docs/LAUNCH_GUIDE.md", "docs/EXTERNAL_TESTER_GUIDE.md"):
        assert PINNED_URL in (ROOT / relative).read_text(encoding="utf-8"), relative


@pytest.mark.parametrize("route", [
    "gh repo clone MannyAmah/livemorebio",
    "git clone https://github.com/MannyAmah/livemorebio",
    "git clone git@github.com:MannyAmah/livemorebio",
    "pip install git+https://github.com/MannyAmah/livemorebio@main",
    "https://api.github.com/repos/MannyAmah/livemorebio/contents/install.sh",
    "mannyamah/LIVEMOREBIO",
    "LIVEMORE_REF=main bash install.sh",
    "gh api some/private/install/route",
])
@pytest.mark.parametrize("relative", ["docs/EXTERNAL_TESTER_GUIDE.md", "additional-client-guide.md"])
def test_install_document_guard_rejects_private_routes_in_every_manifest_document(tmp_path, monkeypatch, route, relative):
    require_source_tree("docs/LAUNCH_GUIDE.md")
    for document in _shipped_documents(ROOT):
        destination = tmp_path / document
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / document, destination)
    manifest = (ROOT / "tools/public_release_manifest.txt").read_text(encoding="utf-8")
    (tmp_path / "tools").mkdir(exist_ok=True)
    (tmp_path / "tools/public_release_manifest.txt").write_text(manifest + relative + "\n", encoding="utf-8")
    document = tmp_path / relative
    with document.open("a", encoding="utf-8") as stream:
        stream.write("\n" + route + "\n")
    monkeypatch.setattr(sys.modules[__name__], "ROOT", tmp_path)
    with pytest.raises(AssertionError, match=relative):
        test_no_shipped_document_installs_from_private_repository()


def _native_blocks(relative: str) -> list[str]:
    text = (ROOT / relative).read_text(encoding="utf-8")
    return [block for block in re.findall(r"```bash\n(.*?)```", text, re.DOTALL)
            if URL in block and "install.sh" in block]


def _guide_inventory() -> list[str]:
    if verifying_container_image():
        return ["README.md"]
    paths = set(_shipped_documents(ROOT))
    if (ROOT / ".git").exists() or any((ROOT / name).exists() for name in PUBLIC_LANDING_PAGES):
        paths.update(PUBLIC_LANDING_PAGES)
    return sorted(paths)


def test_DEP_1_every_install_guide_verifies_before_running() -> None:
    found = set()
    for relative in _guide_inventory():
        text = (ROOT / relative).read_text(encoding="utf-8")
        if URL not in text:
            continue
        found.add(relative)
        blocks = _native_blocks(relative)
        assert len(blocks) == 1, relative
        block = blocks[0]
        for variable, placeholder, pattern in (
            ("org_release_url", "{ORG_RELEASE_URL}",
             r"https://github\.com/Livemore-Biosciences/[^/{}\s]+/releases/[^{}\s]+"),
            ("livemorebiosciences_url", "{LIVEMOREBIOSCIENCES_URL}",
             r"https://livemorebiosciences\.com/[^{}\s]+"),
            ("installer_sha256", "{INSTALLER_SHA256}", r"[0-9a-fA-F]{64}"),
            ("archive_sha256", "{ARCHIVE_SHA256}", r"[0-9a-fA-F]{64}"),
            ("dist_commit", "{DIST_COMMIT}", r"[0-9a-f]{40}"),
        ):
            assignments = re.findall(r"(?m)^[ \t]*" + variable + r"='([^'\n]*)'$", text)
            assert len(assignments) == 1, (relative, variable)
            value, = assignments
            assert f"{variable}='{value}'" in block, (relative, variable)
            if value == placeholder:
                assert text.count(placeholder) == 1, (relative, variable)
            else:
                assert re.fullmatch(pattern, value), (relative, variable)
        assert PINNED_URL in block, relative
        assert "sha256sum" in block and "shasum -a 256" in block, relative
        assert block.index("sha256sum") < block.index('bash "$installer_file"'), relative
        assert 'LIVEMORE_SHA256="$archive_sha256" bash "$installer_file"' in block, relative
        assert "independently administered" in text, relative
        assert "Livemore-Biosciences" in text and "livemorebiosciences.com" in text, relative
        assert "Users may check either channel" in text, relative
        assert "digests must match on both" in text, relative
        assert "{SECOND_CHANNEL}" not in text, relative
    assert set(NATIVE_GUIDES).issubset(found), found


def test_DEP_1_no_guide_pipes_an_unverified_installer_to_a_shell() -> None:
    for relative in _guide_inventory():
        text = (ROOT / relative).read_text(encoding="utf-8")
        logical = re.sub(r"\\\n\s*", " ", text)
        assert not re.search(r"\bcurl\b[^\n]*\|[^\n]*\b(?:bash|sh|zsh)\b", logical), relative


def _write_command(path: Path, body: str) -> None:
    path.write_text("#!/bin/sh\nset -eu\n" + body, encoding="utf-8")
    path.chmod(0o700)


def _run_documented_install(tmp_path: Path, block: str, case: str, hash_tool: str) -> None:
    command_dir = tmp_path / "commands"
    command_dir.mkdir()
    installer = tmp_path / "technical-installer.sh"
    good = b'#!/bin/sh\nprintf "%s" "$LIVEMORE_SHA256" > ran\n# technical A\n'
    installer.write_bytes(good.replace(b"technical A", b"technical B") if case == "tampered" else good)
    digest = hashlib.sha256(good).hexdigest().upper()
    values = {"org_release_url": "https://github.com/Livemore-Biosciences/example/releases/tag/l0",
              "livemorebiosciences_url": "https://livemorebiosciences.com/example-l0",
              "installer_sha256": digest, "archive_sha256": "B" * 64,
              "dist_commit": "a" * 40}
    if case == "unfilled":
        values = {name: "{" + name.upper() + "}" for name in values}
    elif case in {"missing-org-channel", "unfilled-org-channel", "wrong-org-channel"}:
        values["org_release_url"] = {
            "missing-org-channel": "", "unfilled-org-channel": "{ORG_RELEASE_URL}",
            "wrong-org-channel": "https://github.com/example/example/releases/tag/l0",
        }[case]
    elif case in {"missing-site-channel", "unfilled-site-channel", "wrong-site-channel"}:
        values["livemorebiosciences_url"] = {
            "missing-site-channel": "", "unfilled-site-channel": "{LIVEMOREBIOSCIENCES_URL}",
            "wrong-site-channel": "https://livemoreai.com/example-l0",
        }[case]
    elif case == "missing-installer-digest":
        values["installer_sha256"] = ""
    elif case == "invalid-archive-digest":
        values["archive_sha256"] = "not-a-digest"
    elif case == "invalid-dist-commit":
        values["dist_commit"] = "main"
    for variable, value in values.items():
        block, count = re.subn(r"(?m)^([ \t]*" + variable + r"=)'[^'\n]*'$",
                               lambda match: match[1] + repr(value), block)
        assert count == 1, variable
    events = tmp_path / "events"
    record = tmp_path / "ran"
    _write_command(command_dir / "curl", r'''
printf 'download\n' >> "$TECHNICAL_EVENTS"
[ "$TECHNICAL_CASE" != download-failure ] || exit 22
if [ "$TECHNICAL_CASE" != empty ]; then cat "$TECHNICAL_INSTALLER"; fi
[ "$TECHNICAL_CASE" != partial ] || exit 42
''')
    _write_command(command_dir / hash_tool, r'''
printf 'hash\n' >> "$TECHNICAL_EVENTS"
[ "$TECHNICAL_CASE" != hash-failure ] || exit 73
if [ -n "$TECHNICAL_HASH_TOOL" ]; then
    "$TECHNICAL_HASH_TOOL" "$@"
else
    "$TECHNICAL_PYTHON" -c 'import hashlib,sys; print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest()+"  -")'
fi
[ "$TECHNICAL_CASE" != hash-output-failure ] || exit 73
''')
    for name in ("cat", "tr", "mktemp", "rm", "bash", "mkdir", "chmod", "env"):
        executable = shutil.which(name)
        assert executable, f"documented install requires {name}"
        _write_command(command_dir / name, 'exec /bin/bash "$@"\n' if name == 'bash' else
                       f'exec "$TECHNICAL_{name.upper()}" "$@"\n')
    _write_command(command_dir / "timeout", 'shift\nexec "$@"\n')
    for directory in ("home", "tmp", "data", "runner"):
        (tmp_path / directory).mkdir()
    environment = {"PATH": str(command_dir), "HOME": str(tmp_path / "home"),
                   "TMPDIR": str(tmp_path / "tmp"), "LIVEMORE_DATA_DIR": str(tmp_path / "data"),
                   "RUNNER_TEMP": str(tmp_path / "runner"), "LANG": "en_US.UTF-8",
                   "TECHNICAL_INSTALLER": str(installer), "TECHNICAL_EVENTS": str(events),
                   "TECHNICAL_RUN_RECORD": str(record), "TECHNICAL_CASE": case,
                   "TECHNICAL_PYTHON": sys.executable,
                   "TECHNICAL_HASH_TOOL": shutil.which(hash_tool) or ""}
    for name in ("cat", "tr", "mktemp", "rm", "bash", "mkdir", "chmod", "env"):
        environment[f"TECHNICAL_{name.upper()}"] = shutil.which(name) or ""
    result = subprocess.run(["/bin/bash", "-c", block], cwd=tmp_path, env=environment,
                            capture_output=True, text=True, encoding="utf-8", timeout=15)
    success = case == "complete"
    assert (result.returncode == 0) is success, result.stderr
    assert record.exists() is success, (case, result.stderr)
    if success:
        assert record.read_text(encoding="utf-8") == "b" * 64
    if case in {"unfilled", "missing-installer-digest", "invalid-archive-digest", "invalid-dist-commit",
                "missing-org-channel", "unfilled-org-channel", "wrong-org-channel",
                "missing-site-channel", "unfilled-site-channel", "wrong-site-channel"}:
        assert not events.exists(), "unfilled or invalid release values must refuse before download"


@pytest.mark.parametrize("relative", ["README.md", "docs/LAUNCH_GUIDE.md", "docs/EXTERNAL_TESTER_GUIDE.md"])
@pytest.mark.parametrize("behavior", ["complete", "partial", "empty"])
def test_public_bootstrap_executes_only_a_complete_download(tmp_path, relative, behavior):
    require_source_tree("docs/LAUNCH_GUIDE.md")
    blocks = _native_blocks(relative)
    assert len(blocks) == 1
    _run_documented_install(tmp_path, blocks[0], behavior, "sha256sum")


@pytest.mark.parametrize("relative", NATIVE_GUIDES)
@pytest.mark.parametrize("hash_tool", ["sha256sum", "shasum"])
@pytest.mark.parametrize("case", ["complete", "tampered", "download-failure", "hash-failure",
                                 "hash-output-failure", "unfilled", "missing-installer-digest",
                                 "invalid-archive-digest", "invalid-dist-commit",
                                 "missing-org-channel", "unfilled-org-channel", "wrong-org-channel",
                                 "missing-site-channel", "unfilled-site-channel", "wrong-site-channel"])
def test_DEP_1_documented_installer_refuses_before_execution(
    tmp_path: Path, relative: str, hash_tool: str, case: str
) -> None:
    blocks = _native_blocks(relative)
    assert len(blocks) == 1
    _run_documented_install(tmp_path, blocks[0], case, hash_tool)


def test_DEP_1_author_filled_release_values_keep_document_checks_executable(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Publication replaces placeholders; the shipped suite must still use technical bytes."""
    published = tmp_path / "published"
    (published / "tools").mkdir(parents=True)
    (published / "tools/public_release_manifest.txt").write_text(
        "\n".join(NATIVE_GUIDES) + "\n", encoding="utf-8")
    for relative in NATIVE_GUIDES:
        text = (ROOT / relative).read_text(encoding="utf-8")
        for placeholder, value in (("{ORG_RELEASE_URL}",
                                    "https://github.com/Livemore-Biosciences/example/releases/tag/l0"),
                                   ("{LIVEMOREBIOSCIENCES_URL}", "https://livemorebiosciences.com/example-l0"),
                                   ("{INSTALLER_SHA256}", "c" * 64),
                                   ("{ARCHIVE_SHA256}", "D" * 64), ("{DIST_COMMIT}", "e" * 40)):
            text = text.replace(placeholder, value)
        path = published / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    monkeypatch.setattr(sys.modules[__name__], "ROOT", published)
    test_DEP_1_every_install_guide_verifies_before_running()
    for index, relative in enumerate(NATIVE_GUIDES):
        block, = _native_blocks(relative)
        for case in ("complete", "tampered"):
            work = tmp_path / f"filled-{index}-{case}"
            work.mkdir()
            _run_documented_install(work, block, case, "sha256sum")
