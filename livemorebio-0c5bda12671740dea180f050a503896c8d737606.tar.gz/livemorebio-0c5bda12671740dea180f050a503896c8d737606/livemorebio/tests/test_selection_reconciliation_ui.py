"""Authored DOM/transport probes only; no browser, participant, or live service."""
from pathlib import Path
import json
import subprocess

import pytest
from ._node import NODE, run_node as _run_node

LIB = Path(__file__).parents[1] / "aegle/console/lib"
PREAMBLE = r"""
import assert from 'node:assert/strict';
import {mountSelectionReconciliation, selectionRequest, validateReconciliationAck} from MODULE;
const UUID='563e4d61-9872-4fe3-820b-a18903a522a0';
const availability={schema:'livemore.model-availability.v1',state:'UNAVAILABLE',reason_code:'MODEL_BINDING_REQUIRED',selection_mode:'observations_only',twin_id:'twin-technical',twin_version:3,source_generation:'technical-generation',preparation_available:false};
const subject={twin_id:'twin-technical',version:3,source_class:'REAL_HUMAN',subject_id:'technical-pseudonym',display_label:'Technical fixture only',lifecycle:'ACTIVE'};
const ack=()=>({selection_status:'CONFIRMED',subject:{...subject},model_availability:{...availability},prior_execution_cleanup:'INSPECT_EXISTING_STATUS'});
const listing=(status='UNCONFIRMED')=>({selection_status:status,active:status==='CONFIRMED'?{...subject}:null,twins:[],pagination:{}});
class E {constructor(){this.textContent='';this.innerHTML='';this.hidden=false;this.disabled=false;this.dataset={};this.handlers={};}addEventListener(k,f){this.handlers[k]=f}removeEventListener(k,f){if(this.handlers[k]===f)delete this.handlers[k]}setAttribute(){}focus(){this.focused=true}}
const nodes=new Map();const root={querySelector(s){if(!nodes.has(s))nodes.set(s,new E());return nodes.get(s)}};
const tick=async()=>{for(let i=0;i<12;i++)await Promise.resolve()};
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return{promise,resolve,reject}};
let posts=0,reads=0;const changes=[];
const fixture=(options={})=>mountSelectionReconciliation({root,onChange:s=>changes.push(s),refresh:async()=>{reads++;return listing('CONFIRMED')},request:async()=>{posts++;return{payload:ack(),requestId:UUID}},...options});
function admit(c,p=listing()){assert(c.acceptListing(c.beginRead(),p));}
const response=(raw,status=200,id=UUID)=>new Response(raw,{status,headers:{'X-Request-ID':id,'Content-Type':'application/json'}});
"""


def run_node(script):
    script = PREAMBLE.replace("MODULE", json.dumps((LIB / "selection_reconciliation.js").as_uri())) + script
    result = _run_node([NODE, "--input-type=module", "-e", script], capture_output=True, text=True, timeout=12, encoding="utf-8")
    assert result.returncode == 0, result.stderr


@pytest.mark.parametrize("scenario", ["uncertain", "repeat", "await_read", "lost_ack", "failed_read", "old_get", "old_selection_get", "disposed", "reopen", "cleanup"])
def test_mounted_selection_lifecycle(scenario):
    cases = {
        "uncertain": """const c=fixture();admit(c,{...listing(),active:subject});assert(!c.canSelect());assert(root.querySelector('#active-subject').hidden);assert(!root.querySelector('#selection-reconciliation').hidden);assert(!root.querySelector('#reconcile-selection').disabled);assert(!root.querySelector('#selection-reconciliation-status').textContent.includes(subject.display_label));await tick();assert.equal(posts,0);assert.equal(reads,0);c.dispose();""",
        "repeat": """const d=deferred();const c=fixture({request:async()=>{posts++;return d.promise}});admit(c);const pending=c.reconcile();await c.reconcile();root.querySelector('#reconcile-selection').handlers.click();assert.equal(posts,1);d.resolve({payload:ack(),requestId:UUID});await pending;assert.equal(reads,1);assert(c.canSelect());c.dispose();""",
        "await_read": """const d=deferred();const c=fixture({refresh:()=>{reads++;return d.promise}});admit(c);const pending=c.reconcile();await tick();assert(!c.canSelect());assert(root.querySelector('#active-subject').hidden);d.resolve(listing('CONFIRMED'));await pending;assert(c.canSelect());assert.equal(posts,1);c.dispose();""",
        "lost_ack": """const c=fixture({request:async()=>{posts++;throw Object.assign(Error('PRIVATE_SENTINEL'),{code:'CLIENT_UNCONFIRMED',requestId:UUID})}});admit(c);await c.reconcile();assert.equal(posts,1);assert.equal(reads,1);assert(c.canSelect());assert.match(root.querySelector('#selection-reconciliation-status').textContent,/acknowledgment unconfirmed.*confirmed by a fresh read/i);assert(!root.querySelector('#selection-reconciliation-status').textContent.includes('PRIVATE'));assert.equal(root.querySelector('#selection-reconciliation-request').textContent,'Request '+UUID);c.dispose();""",
        "failed_read": """const c=fixture({request:async()=>{posts++;throw Error('PRIVATE')},refresh:async()=>{reads++;throw Error('PRIVATE')}});admit(c);await c.reconcile();assert(!c.canSelect());assert(root.querySelector('#reconcile-selection').disabled);assert(!root.querySelector('#selection-reconciliation').hidden);assert.equal(posts,1);assert.equal(reads,1);c.dispose();""",
        "old_get": """const c=fixture();admit(c);const old=c.beginRead();await c.reconcile();assert(!c.acceptListing(old,{...listing('CONFIRMED'),active:{...subject,display_label:'OLD'}}));assert(c.canSelect());assert.equal(c.snapshot().active.display_label,subject.display_label);c.dispose();""",
        "old_selection_get": """const c=fixture();admit(c,listing('CONFIRMED'));const old=c.beginRead();const d=deferred();const pending=c.runSelection(async()=>{posts++;return d.promise},{action:'select-observations',twinId:subject.twin_id,expectedVersion:2});assert(!c.acceptListing(old,listing('CONFIRMED')));d.reject(Error('PRIVATE'));await pending;assert.equal(posts,1);assert.equal(reads,1);assert(c.canSelect());assert.equal(c.snapshot().outcome,'ACK_UNCONFIRMED');c.dispose();""",
        "disposed": """const d=deferred();const c=fixture({request:()=>{posts++;return d.promise}});admit(c);const pending=c.reconcile();c.dispose();const count=changes.length;d.resolve({payload:ack(),requestId:UUID});await pending;assert.equal(changes.length,count);assert.equal(reads,0);assert(!c.canSelect());""",
        "reopen": """const c=fixture();admit(c,listing('CONFIRMED'));c.dispose();await c.reopen();assert.equal(posts,0);assert.equal(reads,1);assert(c.canSelect());c.dispose();""",
        "cleanup": """const c=fixture();admit(c);await c.reconcile();assert.match(root.querySelector('#selection-reconciliation-status').textContent,/cleanup.*inspect/i);assert.equal(posts,1);assert.equal(reads,1);c.dispose();""",
    }
    run_node(cases[scenario])


@pytest.mark.parametrize("mutation", ["value.subject.version=true", "value.subject.version=4", "value.subject=null", "value.extra=true", "value.model_availability.preparation_available=true", "value.subject.source_class='invented'", "value.prior_execution_cleanup='DONE'"])
def test_acknowledgment_rejects_contradictory_shape(mutation):
    run_node(f"const value=ack();{mutation};assert.throws(()=>validateReconciliationAck(value,UUID));")


@pytest.mark.parametrize("header", [None, "a" * 32, "PRIVATE_SENTINEL"])
def test_acknowledgment_rejects_missing_or_unrelated_uuid(header):
    run_node(f"assert.throws(()=>validateReconciliationAck(ack(),{json.dumps(header)}));")


@pytest.mark.parametrize("raw", ['{"selection_status":"CONFIRMED","selection_status":"UNCONFIRMED"}', '{"value":NaN}', '{"value":1e999}', '[]'])
def test_request_strict_json_and_no_arbitrary_error_leak(raw):
    run_node(f"let calls=0;await assert.rejects(selectionRequest('/api/twins/reconcile-selection',{{body:{{}},fetcher:async()=>{{calls++;return response({json.dumps(raw)})}}}}),e=>e.code==='CLIENT_UNCONFIRMED'&&!e.message.includes('PRIVATE'));assert.equal(calls,1);")


def test_request_once_empty_body_bounded_current_uuid():
    run_node("""let calls=0;const result=await selectionRequest('/api/twins/reconcile-selection',{body:{},fetcher:async(path,options)=>{calls++;assert.equal(path,'/api/twins/reconcile-selection');assert.equal(options.method,'POST');assert.equal(options.body,'{}');assert.equal(Object.keys(options.headers).join(','),'Content-Type');return response(JSON.stringify(ack()))}});assert.equal(calls,1);assert.equal(result.requestId,UUID);assert.equal(Object.getPrototypeOf(result.payload),null);assert.deepEqual(JSON.parse(JSON.stringify(result.payload)),ack());""")


@pytest.mark.parametrize("scenario", ["listing", "guards", "selection_lost_ack", "disposed_read", "pairing_submit", "stored_badge", "operation_overlap", "activate_bad_ack", "observations_bad_ack", "activate_valid_ack", "observations_valid_ack"])
def test_actual_subjects_controller_uses_shared_recovery(scenario):
    script = r"""
import fs from 'node:fs';import vm from 'node:vm';
const original=fs.readFileSync(SUBJECTS,'utf8').replace(/^import .*;\n/gm,'').split('document.querySelector("#refresh-records")')[0];
const controls=['activate','patch','physical','selectObservations'].map(key=>{const e=new E();e.dataset={[key]:'twin-technical',version:'3'};return e});
const submit=new E(),intake=new E(),refreshButton=new E();
const badge=new E();badge.dataset.lifecycle='ACTIVE';badge.textContent='ACTIVE';badge.active=true;badge.classList={toggle:(name,value)=>badge.active=value};
const document={body:{dataset:{subjectView:'twins'},setAttribute(){}},querySelector:s=>root.querySelector(s),querySelectorAll:s=>s.includes('data-activate')?[...controls,submit]:s.includes('data-lifecycle')?[badge]:s.startsWith('#record-list button')?controls:[]};
for(const e of [submit,intake,refreshButton])e.disabled=false;
for(const e of [root.querySelector('#record-list'),root.querySelector('#active-subject')]){e.querySelectorAll=()=>[];e.classList={toggle(){}}}
root.querySelector('#subject-banner').classList={toggle(){}};
root.querySelector('#physical-patch-form').dataset={twin:subject.twin_id,version:'3'};
const pending=deferred();reads=0;posts=0;let readSignal;
const context={document,escapeHTML:String,URLSearchParams,AbortController,setTimeout,clearTimeout,mountSelectionReconciliation,fetch:async()=>{posts++;throw Error('unexpected pairing POST')},selectionRequest:(path,options={})=>selectionRequest(path,{...options,fetcher:async(url,init)=>{if(init.method==='POST'){posts++;return pending.promise}reads++;readSignal=init.signal;if(SCENARIO==='disposed_read')return pending.promise;return response(JSON.stringify(listing('CONFIRMED')))}})};
vm.createContext(context);vm.runInContext(original,context);context.payload={...listing(),active:subject};
if(SCENARIO==='listing'){
 await vm.runInContext('load()',context);assert.equal(reads,1);context.payload={...listing(),active:subject};
 vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload);renderTwins(payload)',context);
 assert(!root.querySelector('#active-subject').innerHTML.includes(subject.display_label));assert(root.querySelector('#active-subject').hidden);assert.equal(posts,0);
}else if(SCENARIO==='guards'){
 vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload)',context);
 for(const fn of ['activate','selectObservations','bindPatch','openPhysicalPatch']){context.button=controls[0];await vm.runInContext(fn+'(button)',context)}
 assert.equal(posts,0);assert(controls.every(e=>e.disabled));assert(!intake.disabled&&!refreshButton.disabled);
}else if(SCENARIO==='disposed_read'){
 const read=vm.runInContext('load()',context);await tick();assert.equal(reads,1);vm.runInContext('disposeSubjectView()',context);assert(readSignal.aborted);pending.resolve(response(JSON.stringify(listing('CONFIRMED'))));await read;assert(root.querySelector('#active-subject').hidden);assert.equal(posts,0);
}else if(SCENARIO==='pairing_submit'){
 context.payload=listing('CONFIRMED');vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload);bindPhysicalPatchForm()',context);
 const form=root.querySelector('#physical-patch-form');form.dataset.selectionEpoch=String(vm.runInContext('selectionRecovery.snapshot().epoch',context));
 context.payload={...listing('CONFIRMED'),active:{...subject,version:4}};vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload)',context);
 await form.handlers.submit({preventDefault(){},currentTarget:form});assert.equal(posts,0);assert.match(root.querySelector('#subject-banner').textContent,/Reinspect/);
}else if(SCENARIO==='stored_badge'){
 context.payload=listing('CONFIRMED');vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload)',context);assert(badge.active);
 context.payload=listing();vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload)',context);assert(!badge.active);assert.equal(badge.textContent,'Stored lifecycle: ACTIVE');
}else if(SCENARIO==='operation_overlap'){
 context.payload=listing('CONFIRMED');vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload);setOperationBusy(true)',context);
 context.payload=listing();vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload);setOperationBusy(false)',context);assert(controls.every(e=>e.disabled));
 context.payload=listing('CONFIRMED');vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload)',context);assert(controls.every(e=>!e.disabled));
 context.payload=listing();vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload);setOperationBusy(true)',context);
 context.payload=listing('CONFIRMED');vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload)',context);assert(controls.every(e=>e.disabled));vm.runInContext('setOperationBusy(false)',context);assert(controls.every(e=>!e.disabled));
}else if(SCENARIO.endsWith('_ack')){
 context.payload=listing('CONFIRMED');vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload)',context);
 const activation=SCENARIO.startsWith('activate');context.button=controls[activation?0:3];
 const operation=vm.runInContext((activation?'activate':'selectObservations')+'(button)',context);await tick();assert.equal(posts,1);
 const value=SCENARIO.endsWith('bad_ack')?{}:{schema:'livemore.twin-record.v1',...subject,version:4,source_class:activation?'SYNTHETIC':'REAL_HUMAN',...(activation?{}:{selection_mode:'observations_only',model_availability:{...availability,twin_version:4}})};
 pending.resolve(response(JSON.stringify(value)));await operation;
 assert.equal(vm.runInContext('selectionRecovery.snapshot().outcome',context),SCENARIO.endsWith('bad_ack')?'ACK_UNCONFIRMED':'ACKNOWLEDGED');
 assert.equal(reads,1);assert.equal(posts,1);assert.equal(vm.runInContext('selectionRecovery.snapshot().active.version',context),3);
}else{
 context.payload=listing('CONFIRMED');vm.runInContext('selectionRecovery.acceptListing(selectionRecovery.beginRead(),payload)',context);
 context.old=vm.runInContext('selectionRecovery.beginRead()',context);context.button=controls[3];
 const operation=vm.runInContext('selectObservations(button)',context);await tick();
 assert.equal(posts,1);assert.equal(vm.runInContext('selectionRecovery.acceptListing(old,payload)',context),false);
 pending.reject(Error('PRIVATE'));await operation;assert.equal(reads,1);assert.equal(posts,1);
 assert.match(root.querySelector('#selection-reconciliation-status').textContent,/acknowledgment unconfirmed/);
}
vm.runInContext('selectionRecovery.dispose()',context);
""".replace("SUBJECTS", json.dumps(str(LIB / "subjects.js"))).replace("SCENARIO", json.dumps(scenario))
    run_node(script)


def test_request_absolute_deadline_includes_stalled_body_and_external_disposal():
    run_node("""let calls=0;const stalled=new ReadableStream({pull(){return new Promise(()=>{})}});await assert.rejects(selectionRequest('/api/twins/reconcile-selection',{body:{},timeoutMs:10,fetcher:async()=>{calls++;return new Response(stalled)}}),e=>e.code==='CLIENT_UNCONFIRMED');assert.equal(calls,1);const controller=new AbortController();controller.abort();await assert.rejects(selectionRequest('/api/twins/reconcile-selection',{body:{},signal:controller.signal,fetcher:()=>{throw Error('must not dispatch')}}),e=>e.code==='CLIENT_UNCONFIRMED');""")


@pytest.mark.parametrize("kind", ["utf8", "oversize", "declared", "auth", "fetch_stall"])
def test_request_failure_modes_are_bounded_and_safe(kind):
    scripts={
        "utf8":"return new Response(new Uint8Array([0xff,0xfe]))",
        "oversize":"return response('{\"value\":\"'+'x'.repeat(2000000)+'\"}')",
        "declared":"return new Response('{}',{headers:{'Content-Length':'2000001'}})",
        "auth":"return response('{\"error\":\"PRIVATE_SENTINEL\"}',401)",
        "fetch_stall":"return new Promise(()=>{})",
    }
    # Only the stall case measures a deliberately shortened deadline; cold Node
    # Response initialization must not masquerade as the auth outcome under test.
    timeout = 20 if kind == 'fetch_stall' else 1000
    run_node("let calls=0;await assert.rejects(selectionRequest('/api/twins/reconcile-selection',{body:{},timeoutMs:"+str(timeout)+",fetcher:async()=>{calls++;"+scripts[kind]+"}}),e=>!e.message.includes('PRIVATE')&&e.code==="+json.dumps("CLIENT_AUTH_REQUIRED" if kind=="auth" else "CLIENT_UNCONFIRMED")+");assert.equal(calls,1);")


def test_controller_receipt_does_not_inherit_previous_attempt_uuid_and_restores_after_failure():
    run_node("""let attempt=0;const c=fixture({request:async()=>{if(attempt++===0)return{payload:ack(),requestId:UUID};throw Error('lost')},refresh:async()=>listing()});admit(c);await c.reconcile();assert.equal(c.snapshot().requestId,UUID);await c.reconcile();assert.equal(c.snapshot().requestId,null);assert.equal(c.snapshot().outcome,'ACK_UNCONFIRMED');assert(!root.querySelector('#reconcile-selection').disabled);c.dispose();""")


def test_listing_received_during_post_never_enables_selection_and_latest_read_wins():
    run_node("""const d=deferred();const c=fixture({request:()=>d.promise});admit(c);const pending=c.reconcile();admit(c,listing('CONFIRMED'));assert(!c.canSelect());d.resolve({payload:ack(),requestId:UUID});await pending;assert(c.canSelect());c.dispose();""")


def test_preview_ack_is_not_a_selected_subject_and_unknown_listing_never_means_no_active():
    run_node("""const value=ack();value.subject=null;Object.assign(value.model_availability,{state:'READY',reason_code:null,selection_mode:'reference_preview',twin_id:null,twin_version:0,preparation_available:true});assert.equal(validateReconciliationAck(value,UUID),value);const c=fixture();assert(!c.acceptListing(c.beginRead(),{active:null,twins:[]}));assert(!c.canSelect());assert(!root.querySelector('#selection-reconciliation-status').textContent.includes('No active'));c.dispose();""")


def test_reconciliation_label_limit_matches_producer_unicode_codepoints():
    run_node("const value=ack();value.subject.display_label='🧪'.repeat(80);assert.equal(validateReconciliationAck(value,UUID),value);value.subject.display_label+='🧪';assert.throws(()=>validateReconciliationAck(value,UUID));")


def test_reconcile_rejects_other_success_status_without_second_request():
    run_node("let calls=0;await assert.rejects(selectionRequest('/api/twins/reconcile-selection',{body:{},fetcher:async()=>{calls++;return response(JSON.stringify(ack()),201)}}),e=>e.code==='CLIENT_UNCONFIRMED'&&e.requestId===UUID);assert.equal(calls,1);")


def test_absolute_deadline_checked_after_synchronous_body_admission():
    run_node("""const original=globalThis.performance;let time=0;Object.defineProperty(globalThis,'performance',{configurable:true,value:{now:()=>time}});try{await assert.rejects(selectionRequest('/api/twins/reconcile-selection',{body:{},fetcher:async()=>{time=60001;return response(JSON.stringify(ack()))}}),e=>e.code==='CLIENT_UNCONFIRMED')}finally{Object.defineProperty(globalThis,'performance',{configurable:true,value:original})}""")


def test_exact_public_json_byte_limit_is_not_expanded_or_truncated():
    run_node("""const raw=' '.repeat(1999998)+'{}';const result=await selectionRequest('/api/twins/reconcile-selection',{body:{},fetcher:async()=>response(raw)});assert.equal(Object.keys(result.payload).length,0);await assert.rejects(selectionRequest('/api/twins/reconcile-selection',{body:{},fetcher:async()=>response(' '+raw)}),e=>e.code==='CLIENT_UNCONFIRMED');""")
