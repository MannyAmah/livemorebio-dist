"""Explicit frozen-member byte compatibility; authored private fixtures, no service/model."""
import hashlib
import json
from types import SimpleNamespace
from urllib.parse import quote

import pytest

from livemorebio.tests.stack_client_fixtures import install_stack_client_opener

from livemorebio import execution_client, strict_json
from livemorebio.sdk import Platform

MIB = 1024 * 1024
DETAIL = "/api/cohorts/cohort-technical/members/twin-technical"
REQUEST_ID = "563e4d61-9872-4fe3-820b-a18903a522a0"
PRIVATE = "AUTHORED_PRIVATE_PADDING_NOT_CLINICAL"


def object_bytes(size):
    prefix, suffix = b'{"authored_padding":"', b'"}'
    assert size >= len(prefix) + len(suffix)
    return prefix + b"x" * (size - len(prefix) - len(suffix)) + suffix


class ByteResponse:
    def __init__(self, raw, *, status=200, headers=None, failure=None):
        self.raw, self.status, self.failure = raw, status, failure
        self.headers = {"X-Request-ID": REQUEST_ID, **(headers or {})}
        self.read_sizes, self.closed = [], 0

    def read(self, size):
        self.read_sizes.append(size)
        if self.failure:
            raise self.failure
        return self.raw[:size]

    def close(self):
        self.closed += 1


def attached(monkeypatch, response):
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_url", lambda: "http://127.0.0.1:9999")
    monkeypatch.setattr("livemorebio.security.authorization_headers", lambda: {"Authorization": "Bearer technical-fixture"})
    calls = []
    def opener(*handlers):
        def once(request, timeout):
            calls.append(request)
            assert request.get_header("Accept-encoding") == "identity"
            return response
        return SimpleNamespace(open=once)
    install_stack_client_opener(monkeypatch, opener)
    return platform, calls


@pytest.mark.parametrize("kind", ["over8", "near16", "unicode_controls"])
def test_actual_registry_jsonresponse_sdk_preserves_complete_large_frozen_member(tmp_path, monkeypatch, capsys, kind):
    from starlette.responses import JSONResponse
    from livemorebio.aegle.subjects import SubjectRegistry, enforce_real_cohort_size
    from livemorebio.shell import run_command
    from .clinical_registry_fixtures import KEY, canonical, forbid_compilation, legacy_twin_record, seed_legacy
    forbid_compilation(monkeypatch)
    registry = SubjectRegistry(tmp_path / "authored-subjects.sqlite3", key=KEY)
    record = legacy_twin_record(kind)
    size = 16 * MIB - 32768 if kind == "near16" else 9 * MIB
    padding = PRIVATE + "x" * size + ("é\x00\n🙂" * 512 if kind == "unicode_controls" else "")
    record["authored_padding_not_clinical"] = padding
    seed_legacy(registry, record)
    cohort = registry.create_cohort({"source_class": "REAL_HUMAN", "name": "Authored byte compatibility fixture",
        "member_twin_ids": [record["twin_id"]], "indication": "not-an-inferred-model"}, idempotency_key="technical-cohort")
    enforce_real_cohort_size(cohort)
    stored_bytes = len(canonical(cohort))
    member = registry.get_cohort_member(cohort["cohort_id"], record["twin_id"])
    response_bytes = JSONResponse(member).body
    assert 8 * MIB < len(response_bytes) <= stored_bytes <= 16 * MIB
    if kind == "near16":
        assert stored_bytes > 16 * MIB - 65536
    response = ByteResponse(response_bytes)
    platform, calls = attached(monkeypatch, response)
    output = []
    actual = run_command(platform, f"cohort member {cohort['cohort_id']} {record['twin_id']}", out=output.append)
    assert hashlib.sha256(canonical(actual)).digest() == hashlib.sha256(canonical(member)).digest()
    assert len(actual["snapshot"]["authored_padding_not_clinical"]) == len(padding)
    assert actual["snapshot"]["authored_padding_not_clinical"][-8:] == padding[-8:]
    assert len(calls) == 1 and calls[0].method == "GET" and calls[0].data is None
    assert response.read_sizes == [16 * MIB + 1] and response.closed == 1
    assert PRIVATE not in "\n".join(output) and len("\n".join(output)) < 1500
    captured = capsys.readouterr()
    assert PRIVATE not in captured.out + captured.err
    assert registry.active_twin() is None


def test_named_parser_exact_boundary_generic_limits_and_request_bound_remain_fixed():
    raw = object_bytes(16 * MIB)
    parsed = strict_json.parse_frozen_member_response(raw)
    assert len(parsed["authored_padding"]) == 16 * MIB - len(b'{"authored_padding":""}')
    with pytest.raises(strict_json.StrictJSONError):
        strict_json.parse_frozen_member_response(raw + b" ")
    with pytest.raises(TypeError):
        strict_json.parse_frozen_member_response(b"{}", max_bytes=17 * MIB)
    with pytest.raises(strict_json.StrictJSONError, match="2 MB"):
        strict_json.parse_json_object(object_bytes(2_000_001))
    assert strict_json.MAX_JSON_BYTES == 2_000_000
    assert execution_client.MAX_RESPONSE_BYTES == 8 * MIB and execution_client.MAX_REQUEST_BYTES == 16 * 1024
    assert execution_client.MAX_FROZEN_MEMBER_RESPONSE_BYTES == 16 * MIB


@pytest.mark.parametrize("limit", [True, False, 0, -1, 8 * MIB + 1, 16 * MIB, 1.0, "100"])
def test_generic_parser_override_range_never_expands(limit):
    with pytest.raises(strict_json.StrictJSONError, match="byte limit is invalid"):
        strict_json.parse_json_object(b"{}", max_bytes=limit)


def test_generic_override_exact8mib_and_frozen_check_bytes_before_decode():
    assert strict_json.parse_json_object(b"{}", max_bytes=8 * MIB) == {}
    class DecodeForbidden(bytes):
        def decode(self, *args, **kwargs):
            pytest.fail("oversize bytes reached UTF-8 decoding")
    with pytest.raises(strict_json.StrictJSONError, match="byte limit"):
        strict_json.parse_frozen_member_response(DecodeForbidden(b"x" * (16 * MIB + 1)))


@pytest.mark.parametrize("entry", ["parse_json_object", "parse_frozen_member_response"])
@pytest.mark.parametrize("value", [None, {}, 1, True])
def test_parser_nontext_inputs_remain_typed_safe_rejections(entry, value):
    with pytest.raises(strict_json.StrictJSONError, match="JSON requires text"):
        getattr(strict_json, entry)(value)


STRICT_BAD = [b'{"x":"\xff"}', b'{"a":1,"a":2}', b'{"x":{"a":1,"a":2}}',
    b'{"x":NaN}', b'{"x":Infinity}', b'{"x":-Infinity}', b'{"x":1e999}',
    b'{"x":9007199254740992}', b'{"x":-9007199254740992}',
    b'{"x":' + b"[" * 64 + b"0" + b"]" * 64 + b"}", b'{"x":1,}', b'[]', b'null', b'true']


@pytest.mark.parametrize("entry", ["parse_json_object", "parse_frozen_member_response"])
@pytest.mark.parametrize("raw", STRICT_BAD)
def test_both_entrypoints_keep_every_strict_json_rule(entry, raw):
    with pytest.raises(strict_json.StrictJSONError):
        getattr(strict_json, entry)(raw)


@pytest.mark.parametrize("entry", ["parse_json_object", "parse_frozen_member_response"])
def test_both_entrypoints_keep_depth64_finite_values_and_data_keys(entry):
    raw = b'{"x":' + b"[" * 63 + b"0" + b"]" * 63 + b"}"
    assert getattr(strict_json, entry)(raw)
    value = {"__proto__": {"x": True}, "finite": [-1, 0, 1.5, 9007199254740991], "unicode": "é\x00🙂"}
    assert getattr(strict_json, entry)(json.dumps(value, ensure_ascii=False).encode()) == value


@pytest.mark.parametrize("method,path,body,status", [
    ("GET", "/api/cohorts/cohort-technical/members", None, 200),
    ("GET", "/api/cohorts/cohort-technical", None, 200),
    ("GET", "/api/twins/twin-technical", None, 200),
    ("GET", "/api/executions/" + "a" * 32, None, 200),
    ("POST", DETAIL, None, 200), ("get", DETAIL, None, 200),
    ("GET", DETAIL, {}, 200), ("GET", DETAIL, None, 201), ("GET", DETAIL, None, 200.0),
    ("GET", DETAIL, None, 401), ("GET", DETAIL, None, 503),
    *[("GET", path, None, 200) for path in [
        DETAIL + "?limit=1", DETAIL + "#fragment", DETAIL + "/", DETAIL + "/snapshot",
        "/prefix" + DETAIL, DETAIL.replace("/members/", "/member/"),
        DETAIL.replace("cohort-technical", ""), DETAIL.replace("twin-technical", ""),
        DETAIL.replace("cohort-technical", "."), DETAIL.replace("cohort-technical", ".."),
        DETAIL.replace("cohort-technical", "%2e%2e"), DETAIL.replace("cohort-technical", "cohort%2Fother"),
        DETAIL.replace("cohort-technical", "cohort%252Dtechnical"), DETAIL.replace("cohort-technical", "cohort%2Dtechnical"),
        DETAIL.replace("cohort-technical", "cohort%zz"), DETAIL.replace("cohort-technical", "cohort%"),
        DETAIL.replace("cohort-technical", "cohort:technical"), DETAIL.replace("cohort-technical", "cohort%3atechnical"),
        DETAIL.replace("cohort-technical", "cohort%FF"), DETAIL.replace("cohort-technical", "x" * 201),
        DETAIL.replace("members/twin-technical", "members/twin%2Fother"),
    ]],
])
def test_nonqualifying_routes_methods_bodies_statuses_keep8mib(monkeypatch, method, path, body, status):
    response = ByteResponse(object_bytes(8 * MIB + 1), status=status)
    platform, calls = attached(monkeypatch, response)
    with pytest.raises(execution_client.ContinuousClientError) as caught:
        platform._continuous_request(method, path, body)
    assert caught.value.code == ("CLIENT_UNCONFIRMED" if method == "POST" else "CLIENT_RESPONSE")
    assert response.read_sizes == [8 * MIB + 1] and response.closed == 1 and len(calls) == 1


@pytest.mark.parametrize("ids", [("cohort-technical", "twin-technical"), ("cohort:technical", "twin:technical"),
                               ("cohort.a_b-1", "twin.a_b-1")])
def test_actual_sdk_canonical_segment_encoding_gets_fixed_larger_read(monkeypatch, ids):
    cohort_id, member_id = ids
    member = {"schema": "livemore.frozen-real-human-member.v1", "source_class": "REAL_HUMAN",
        "twin_id": member_id, "record_version": 1, "snapshot_sha256": "a" * 64, "evidence_sha256": "b" * 64,
        "snapshot": {"twin_id": member_id, "version": 1, "source_class": "REAL_HUMAN"}}
    response = ByteResponse(json.dumps(member).encode())
    platform, calls = attached(monkeypatch, response)
    assert platform.get_cohort_member(cohort_id, member_id) == member
    assert calls[0].full_url.endswith(f"/api/cohorts/{quote(cohort_id, safe='')}/members/{quote(member_id, safe='')}")
    assert response.read_sizes == [16 * MIB + 1] and response.closed == 1


def test_attachment_prefix_does_not_turn_a_different_actual_path_into_known_detail(monkeypatch):
    response = ByteResponse(object_bytes(8 * MIB + 1))
    platform, calls = attached(monkeypatch, response)
    monkeypatch.setattr(platform, "_url", lambda: "http://127.0.0.1:9999/unrelated-prefix")
    with pytest.raises(execution_client.ContinuousClientError):
        platform._continuous_request("GET", DETAIL)
    assert response.read_sizes == [8 * MIB + 1] and response.closed == len(calls) == 1


@pytest.mark.parametrize("content_length", [None, "1", str(16 * MIB + 999)])
def test_exact16mib_transport_boundary_ignores_content_length(monkeypatch, content_length):
    response = ByteResponse(object_bytes(16 * MIB), headers={} if content_length is None else {"Content-Length": content_length})
    platform, calls = attached(monkeypatch, response)
    result = platform._continuous_request("GET", DETAIL)
    assert len(result["authored_padding"]) == 16 * MIB - len(b'{"authored_padding":""}')
    assert len(calls) == response.closed == 1 and response.read_sizes == [16 * MIB + 1]


@pytest.mark.parametrize("case", ["oversize", "malformed", "read_error", "gzip"])
def test_expanded_read_failures_close_once_keep_current_metadata_and_never_retry(monkeypatch, case):
    response = ByteResponse(object_bytes(16 * MIB + 1) if case == "oversize" else b'{"bad":',
        headers={"Content-Length": "1", **({"Content-Encoding": "gzip"} if case == "gzip" else {})},
        failure=OSError(PRIVATE) if case == "read_error" else None)
    platform, calls = attached(monkeypatch, response)
    with pytest.raises(execution_client.ContinuousClientError) as caught:
        platform._continuous_request("GET", DETAIL)
    assert caught.value.code == ("CLIENT_TRANSPORT" if case == "read_error" else "CLIENT_RESPONSE")
    assert caught.value.request_id == REQUEST_ID and caught.value.status == 200
    assert PRIVATE not in str(caught.value)
    assert len(calls) == response.closed == 1
    assert response.read_sizes == ([] if case == "gzip" else [16 * MIB + 1])


@pytest.mark.parametrize("change", ["schema", "source", "member"])
def test_large_payload_still_passes_through_existing_sdk_semantic_guard(monkeypatch, change):
    member = {"schema": "livemore.frozen-real-human-member.v1", "source_class": "REAL_HUMAN",
        "twin_id": "twin-technical", "record_version": 1, "snapshot_sha256": "a" * 64, "evidence_sha256": "b" * 64,
        "snapshot": {"twin_id": "twin-technical", "version": 1, "source_class": "REAL_HUMAN", "authored_padding": "x" * (9 * MIB)}}
    member[{"schema": "schema", "source": "source_class", "member": "twin_id"}[change]] = "wrong-technical-value"
    response = ByteResponse(json.dumps(member).encode())
    platform, calls = attached(monkeypatch, response)
    with pytest.raises(execution_client.ContinuousClientError) as caught:
        platform.get_cohort_member("cohort-technical", "twin-technical")
    assert caught.value.code == "CLIENT_RESPONSE" and caught.value.request_id == REQUEST_ID
    assert response.read_sizes == [16 * MIB + 1] and response.closed == len(calls) == 1


def test_oversize_request_still_rejects_before_any_response(monkeypatch):
    response = ByteResponse(b"{}")
    platform, calls = attached(monkeypatch, response)
    with pytest.raises(execution_client.ContinuousClientError):
        platform._continuous_request("POST", DETAIL, {"authored_padding": "x" * (16 * 1024)})
    assert calls == [] and response.read_sizes == []
