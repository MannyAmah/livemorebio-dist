"""Registered binding core: private authored registry records, no physical proof."""
from contextlib import closing
from copy import deepcopy
from dataclasses import replace
import hashlib
import json
import sqlite3
from uuid import uuid4

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import pytest

from livemorebio.aegle.subjects import SubjectRegistry, SubjectRegistryError
from livemorebio.life_patch.protocol_v3 import ManifestV3
from livemorebio.tests.clinical_registry_fixtures import KEY, canonical, replace_fixture_record
from livemorebio.tests.test_committed_registry_transitions import (
    events, no_network_or_models, rows, seed,
)
from livemorebio.tests.test_patch_protocol_v3 import manifest_payload


def inspection():
    manifest = ManifestV3(manifest_payload("physical")).to_dict()
    return {"schema": "livemore.physical-manifest-inspection.v1", "manifest": manifest,
            "manifest_hash": manifest["capability_hash"], "life_process_instance": str(uuid4()),
            "life_store_id": str(uuid4()), "gateway_store_id": str(uuid4()),
            "source_sha256": "b" * 64, "inspected_at": "2026-09-09T12:00:00Z",
            "request_id": str(uuid4())}


def request(inspected, version=1):
    return {"device_id": inspected["manifest"]["device_id"], "mode": "physical",
            "protocol_version": "3.0", "expected_manifest_hash": inspected["manifest_hash"],
            "calibration_status": "current", "calibration_reference": "urn:test:declared-calibration",
            "attestation_reference": "urn:test:declared-attestation", "expected_version": version}


@pytest.fixture
def core(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from livemorebio.aegle import runtime
    from livemorebio.life_patch.gateway import LifePatchGateway

    def forbidden(*_a, **_kw):
        pytest.fail("Physical binding core attempted a model or device operation")
    monkeypatch.setattr(runtime.AegleTwin, "__init__", forbidden)
    monkeypatch.setattr(LifePatchGateway, "__init__", forbidden)
    registry = SubjectRegistry(tmp_path / "authored-registered-binding.sqlite3", key=KEY)
    target = seed(registry, "registered", active=True, human=True)
    unrelated = seed(registry, "unrelated", version=7)
    peer = inspection()
    return SimpleNamespace(registry=registry, target=target, unrelated=unrelated,
                           inspection=peer, body=request(peer), request_id=str(uuid4()))


def prepare(t):
    return t.registry.prepare_registered_physical_v3_binding(
        t.target["twin_id"], t.body, inspection=t.inspection,
        expected_version=t.body["expected_version"], request_id=t.request_id)


def assert_audit(t, outcomes):
    actual = events(t.registry, t.request_id)
    assert [row[2]["outcome_code"] for row in actual] == outcomes
    for _id, _seq, event in actual:
        assert event["schema"] == "livemore.physical-access-audit.v1"
        assert event["action"] == "bind" and event["opaque_record_id"] == t.target["twin_id"]
        assert event["local_store_id"] == t.registry.audit.store_id
        assert set(event) == {"schema", "request_id", "action", "opaque_record_id", "started_at",
                              "completed_at", "outcome_code", "local_store_id",
                              "local_process_instance", "source_sha256"}


def predicate(record, inspected, **overrides):
    from livemorebio.life_patch.physical_binding import require_registered_physical_v3_binding
    args = {"device_id": inspected["manifest"]["device_id"], "subject_id": record["subject_id"],
            "manifest_hash": inspected["manifest_hash"], "firmware_hash": inspected["manifest"]["firmware_hash"],
            "custody_reference": record["chain_of_custody"]}
    args.update(overrides)
    return require_registered_physical_v3_binding(record, **args)


def assert_binding(t, record):
    entry = record["patch_bindings"][-1]
    manifest = t.inspection["manifest"]
    assert entry["schema"] == "livemore.patch-binding.physical.v3"
    assert entry["manifest"] == manifest and entry["manifest_hash"] == manifest["capability_hash"]
    assert entry["inspection"] == t.inspection
    for field in ("device_id", "mode", "protocol_version", "firmware_hash", "firmware_version",
                  "configuration_id", "hardware_revision", "capabilities", "hardware_present"):
        assert entry[field] == manifest[field]
    assert entry["calibration_reference"] == t.body["calibration_reference"]
    assert entry["attestation_reference"] == t.body["attestation_reference"]
    assert entry["calibration_evidence_state"] == "OPERATOR_DECLARED"
    assert entry["hardware_validation_state"] == "NOT_ESTABLISHED"
    assert entry["qualification_state"] == "PAIRING_RECORDED"
    assert entry["telemetry_admission"] == "PENDING_SIGNED_ENVELOPE"
    assert entry["consent_context"] == {"subject_id": t.target["subject_id"],
        "consent_scope": t.target["consent_scope"], "chain_of_custody": t.target["chain_of_custody"]}
    assert entry["subject_fingerprint"] == hashlib.sha256(t.target["subject_id"].encode()).hexdigest()
    assert predicate(record, t.inspection) == entry
    return entry


def test_selected_modeless_binding_actual_commit_reopen_and_original_aad(core):
    t = core; before = rows(t.registry); p = prepare(t)
    assert p.kind == "bind" and p.selected and p.active_before == t.target
    assert rows(t.registry) == before
    assert_audit(t, [None, "SUCCESS"])
    assert t.registry.commit_prepared_transition(p) == "COMMITTED"
    assert_audit(t, [None, "SUCCESS", None, "SUCCESS"])
    record = p.record; entry = assert_binding(t, record)
    assert record["version"] == 2 and record["selection_mode"] == "observations_only"
    assert record.get("model_binding") is t.target.get("model_binding") is None
    assert record["model_parameters"] == t.target["model_parameters"]
    after = rows(t.registry)
    assert after["registry_state"] == before["registry_state"]
    assert after["subject_identifiers"] == before["subject_identifiers"]
    assert after["physical_device_bindings"] == [(t.registry._fingerprint(t.body["device_id"]),
                                                  t.target["twin_id"], entry["bound_at"])]
    old = {row[0]: row for row in before["records"]}; new = {row[0]: row for row in after["records"]}
    assert new[t.unrelated["twin_id"]] == old[t.unrelated["twin_id"]]
    row = new[t.target["twin_id"]]
    assert row[:3] == old[row[0]][:3] and row[5:8] == old[row[0]][5:8]
    decoded = json.loads(AESGCM(KEY).decrypt(row[9], row[10],
        b"livemore.aegle.subject-registry.v1" + row[0].encode()))
    assert decoded == record
    assert t.target["subject_id"].encode() not in t.registry.path.read_bytes()
    reopened = SubjectRegistry(t.registry.path, key=KEY)
    assert reopened.get_twin(t.target["twin_id"]) == record
    assert rows(reopened) == after


@pytest.mark.parametrize("damage", ["device", "protocol", "mode", "digest", "firmware_capability",
                                    "hardware", "uuid", "store_alias"])
def test_bad_inspection_rejected_before_storage(core, monkeypatch, damage):
    t = core; original = deepcopy(t.inspection)
    variants = []
    if damage == "device":
        t.inspection["manifest"]["device_id"] = "wrong-device"
    elif damage == "protocol": t.inspection["manifest"]["protocol_version"] = "2.0"
    elif damage == "mode": t.inspection["manifest"]["mode"] = "virtual"
    elif damage == "digest": t.body["expected_manifest_hash"] = "c" * 64
    elif damage == "firmware_capability":
        t.inspection["manifest"]["firmware_hash"] = "c" * 64
        other = deepcopy(original); other["manifest"]["capabilities"][0]["cartridge_id"] = "wrong-cartridge"
        variants.append(other)
    elif damage == "hardware":
        for values in ({"hardware_present": False}, {"firmware_version": "not-provisioned"}):
            other = deepcopy(original); m = other["manifest"]; m.pop("capability_hash"); m.update(values)
            other["manifest"] = ManifestV3(m).to_dict(); other["manifest_hash"] = other["manifest"]["capability_hash"]
            variants.append(other)
        t.inspection = variants.pop()
    elif damage == "uuid": t.inspection["life_process_instance"] = "not-a-uuid"
    else: t.inspection["life_store_id"] = t.inspection["gateway_store_id"]
    before = rows(t.registry)
    monkeypatch.setattr(t.registry, "_connect", lambda: pytest.fail("Invalid inspection accessed registry"))
    for peer in [t.inspection, *variants]:
        t.inspection = peer
        if damage == "hardware": t.body["expected_manifest_hash"] = peer["manifest_hash"]
        with pytest.raises(SubjectRegistryError) as caught: prepare(t)
        assert caught.value.code == "INVALID_PATCH_BINDING"
    assert rows(t.registry) == before


def test_extra_public_and_private_fields_reject_before_storage(core, monkeypatch):
    t = core; original = deepcopy(t.body)
    monkeypatch.setattr(t.registry, "_connect", lambda: pytest.fail("Unknown binding field accessed registry"))
    for field in ("manifest", "verified", "firmware_hash", "hardware_revision", "inspection", "peer_url"):
        t.body = {**original, field: "not-authority"}
        with pytest.raises(SubjectRegistryError) as caught: prepare(t)
        assert caught.value.code == "INVALID_PATCH_BINDING"


def test_bool_revision_refuses_before_storage(core, monkeypatch):
    t = core; t.body["expected_version"] = True
    monkeypatch.setattr(t.registry, "_connect", lambda: pytest.fail("Boolean revision accessed registry"))
    with pytest.raises(SubjectRegistryError) as caught: prepare(t)
    assert caught.value.code == "TWIN_VERSION_CONFLICT"


def test_old_public_physical_three_cannot_manufacture_inspection(core, monkeypatch):
    t = core
    body = {"device_id": t.body["device_id"], "mode": "physical", "protocol_version": "3.0",
            "hardware_revision": "B0-EVT-target", "firmware_version": "authored-v3",
            "calibration_status": "current", "attestation_reference": "urn:test:declaration"}
    monkeypatch.setattr(t.registry, "_connect", lambda: pytest.fail("Uninspected physical3 reached storage"))
    for supplied in (body, {**body, "inspection": t.inspection}):
        with pytest.raises(SubjectRegistryError) as caught:
            t.registry.prepare_patch_binding(t.target["twin_id"], supplied,
                                              expected_version=1, request_id=t.request_id)
        assert caught.value.code == "INVALID_PATCH_BINDING"


@pytest.mark.parametrize("damage,code", [
    ("nonhuman", "PHYSICAL_PATCH_REQUIRES_REAL_HUMAN"),
    ("unselected", "PHYSICAL_PATCH_REQUIRES_ACTIVE_TWIN"),
    ("scope", "PHYSICAL_PATCH_CONSENT_REQUIRED"),
    ("custody", "SUBJECT_ADMISSION_REQUIRED"),
    ("device", "PATCH_BINDING_CONFLICT"),
])
def test_person_consent_and_device_owner_remain_required(core, damage, code):
    t = core
    if damage == "unselected":
        t.target = seed(t.registry, "not-selected", human=True)
    elif damage == "device":
        with closing(t.registry._connect()) as c, c:
            c.execute("INSERT INTO physical_device_bindings VALUES(?,?,?)",
                      (t.registry._fingerprint(t.body["device_id"]), t.unrelated["twin_id"], "authored"))
    else:
        t.target = deepcopy(t.target)
        if damage == "nonhuman":
            t.target["source_class"] = "SYNTHETIC"
            # Authored coherent source-class change; not a corruption rejection.
            with closing(t.registry._connect()) as c, c:
                c.execute("UPDATE records SET source_class='SYNTHETIC' WHERE record_id=?", (t.target["twin_id"],))
        elif damage == "scope": t.target["consent_scope"].remove("life_patch")
        else: t.target["chain_of_custody"] = ""
        replace_fixture_record(t.registry, t.target)
    before = rows(t.registry)
    with pytest.raises(SubjectRegistryError) as caught: prepare(t)
    assert caught.value.code == code and rows(t.registry) == before


def test_preparation_and_result_are_detached(core):
    t = core; p = prepare(t); before = p.record
    t.inspection["manifest"]["firmware_hash"] = "c" * 64
    t.body["calibration_reference"] = "changed-after-prepare"
    changed = p.record; changed["patch_bindings"][-1]["inspection"]["manifest"]["capabilities"].clear()
    assert p.record == before
    assert t.registry.commit_prepared_transition(p) == "COMMITTED"
    assert t.registry.get_twin(t.target["twin_id"]) == before


def test_forged_prepared_representation_or_after_row_cannot_commit(core, monkeypatch):
    t = core; p = prepare(t); original = rows(t.registry)
    forged_input = json.loads(p._binding_json)
    forged_input["inspection"]["manifest"]["firmware_hash"] = "c" * 64
    forged_record = p.record; forged_record["patch_bindings"][-1]["calibration_evidence_state"] = "VERIFIED"
    monkeypatch.setattr(t.registry, "_connect", lambda: pytest.fail("Forged prepared data accessed registry"))
    for candidate in (replace(p, _binding_json=canonical(forged_input)),
                      replace(p, _after_json=canonical({t.target["twin_id"]: forged_record}))):
        with pytest.raises(SubjectRegistryError): t.registry.commit_prepared_transition(candidate)
    assert rows(t.registry) == original


def test_raw_same_version_change_between_prepare_commit_retained(core):
    t = core; p = prepare(t)
    changed = deepcopy(t.target); changed["chain_of_custody"] = "urn:test:changed-custody"
    replace_fixture_record(t.registry, changed)
    with closing(t.registry._connect()) as c, c:
        c.execute("UPDATE registry_state SET updated_at='authored-later' WHERE state_key='active_twin_id'")
    before = rows(t.registry)
    with pytest.raises(SubjectRegistryError) as caught: t.registry.commit_prepared_transition(p)
    assert caught.value.code == "TWIN_VERSION_CONFLICT" and rows(t.registry) == before
    assert_audit(t, [None, "SUCCESS", None, "ACCESS_FAILED"])


def test_atomic_mutation_audit_failure_preserves_pending_and_old_rows(core):
    t = core; p = prepare(t); before = rows(t.registry)
    with closing(t.registry._connect()) as c, c:
        seq = c.execute("SELECT MAX(sequence) FROM registry_audit").fetchone()[0] + 2
        c.execute(f"CREATE TRIGGER authored_audit_refusal BEFORE INSERT ON registry_audit WHEN NEW.sequence={seq} BEGIN SELECT RAISE(ABORT,'authored refusal'); END")
    with pytest.raises(SubjectRegistryError): t.registry.commit_prepared_transition(p)
    assert rows(t.registry) == before
    assert_audit(t, [None, "SUCCESS", None])
    with closing(sqlite3.connect(t.registry.path)) as c:
        assert c.execute("SELECT COUNT(*) FROM registry_audit_reservations").fetchone()[0] == 1


@pytest.mark.parametrize("fault,outcome", [("rollback", "REGISTRY_STORAGE_UNAVAILABLE"),
    ("lost_ack", "COMMITTED"), ("unknown", "SELECTION_COMMIT_UNCONFIRMED"),
    ("close", "COMMITTED_CLEANUP_UNCONFIRMED")])
def test_actual_commit_acknowledgments_and_cleanup_not_reinterpreted(core, monkeypatch, fault, outcome):
    t = core; p = prepare(t); before = rows(t.registry); real_connect = t.registry._connect
    calls = {"armed": False, "mutation": 0, "close": 0}; damaged = []
    class Connection:
        def __init__(self): self.inner = real_connect(); self.commits = 0
        def __getattr__(self, name): return getattr(self.inner, name)
        def commit(self):
            self.commits += 1
            if self.commits == 2 and not calls["armed"]:
                calls["armed"] = True; calls["mutation"] += 1
                if fault != "rollback": self.inner.commit()
                if fault == "unknown":
                    with closing(sqlite3.connect(t.registry.path)) as c, c:
                        c.execute("UPDATE registry_audit SET ciphertext=X'00' WHERE sequence=(SELECT MAX(sequence) FROM registry_audit)")
                        damaged.extend(c.execute("SELECT * FROM registry_audit ORDER BY sequence").fetchall())
                if fault != "close": raise sqlite3.OperationalError("Authored commit ACK fault")
                return None
            return self.inner.commit()
        def close(self):
            self.inner.close(); calls["close"] += 1
            if fault == "close": raise OSError("Authored close ACK fault")
    monkeypatch.setattr(t.registry, "_connect", Connection)
    if outcome in {"COMMITTED", "COMMITTED_CLEANUP_UNCONFIRMED"}:
        assert t.registry.commit_prepared_transition(p) == outcome
    else:
        with pytest.raises(SubjectRegistryError) as caught: t.registry.commit_prepared_transition(p)
        assert caught.value.code == outcome
    assert calls["mutation"] == 1 and calls["close"] >= 1
    after = rows(t.registry)
    if fault == "rollback":
        assert after == before
        assert_audit(t, [None, "SUCCESS", None, "ACCESS_FAILED"])
    else:
        actual = next(row for row in after["records"] if row[0] == t.target["twin_id"])
        assert actual[4] == 2 and after["physical_device_bindings"]
        if fault == "unknown":
            with closing(sqlite3.connect(t.registry.path)) as c:
                assert c.execute("SELECT * FROM registry_audit ORDER BY sequence").fetchall() == damaged
        else: assert_audit(t, [None, "SUCCESS", None, "SUCCESS"])


def test_reusable_predicate_cannot_relabel_tamper_revocation_or_person(core):
    t = core; p = prepare(t); t.registry.commit_prepared_transition(p)
    record = t.registry.get_twin(t.target["twin_id"])
    assert_binding(t, record)
    variants = []
    for kind in ("firmware", "hash", "scope", "custody", "duplicate"):
        changed = deepcopy(record)
        if kind == "firmware": changed["patch_bindings"][-1]["manifest"]["firmware_hash"] = "c" * 64
        elif kind == "hash": changed["patch_bindings"][-1]["manifest_hash"] = "c" * 64
        elif kind == "scope": changed["consent_scope"].remove("life_patch")
        elif kind == "custody": changed["chain_of_custody"] = "urn:test:later-custody"
        else: changed["patch_bindings"].append(deepcopy(changed["patch_bindings"][-1]))
        variants.append(changed)
    for changed in variants:
        with pytest.raises(ValueError): predicate(changed, t.inspection)
    for override in ({"subject_id": "pseudonym-wrong"}, {"device_id": "wrong"},
                     {"manifest_hash": "c" * 64}, {"firmware_hash": "c" * 64},
                     {"custody_reference": "urn:test:wrong"}):
        with pytest.raises(ValueError): predicate(record, t.inspection, **override)
    detached = predicate(record, t.inspection); detached["manifest"]["capabilities"].clear()
    assert predicate(record, t.inspection) == record["patch_bindings"][-1]
    damaged = deepcopy(record)
    damaged["patch_bindings"][-1]["manifest"]["firmware_hash"] = "c" * 64
    replace_fixture_record(t.registry, damaged)
    before = rows(t.registry)
    with pytest.raises(SubjectRegistryError) as caught:
        t.registry.get_twin(t.target["twin_id"])
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE" and rows(t.registry) == before


def test_v2_physical_legacy_metadata_and_wire_golden_preserved(core):
    from livemorebio.tests.test_patch_protocol_v3 import test_v2_golden_hashes_and_dispatch_are_unchanged
    t = core
    body = {"device_id": "technical-legacy", "mode": "physical", "protocol_version": "2.0",
            "hardware_revision": "B0-EVT-target", "firmware_version": "authored-v2",
            "calibration_status": "current", "attestation_reference": "urn:test:declaration"}
    p = t.registry.prepare_patch_binding(t.target["twin_id"], body, expected_version=1, request_id=t.request_id)
    assert t.registry.commit_prepared_transition(p) == "COMMITTED"
    entry = p.record["patch_bindings"][-1]
    assert entry["protocol_version"] == "2.0" and "schema" not in entry and "manifest" not in entry
    assert entry["qualification_state"] == "PAIRING_RECORDED"
    assert_audit(t, [None, "SUCCESS", None, "SUCCESS"])
    test_v2_golden_hashes_and_dispatch_are_unchanged()


def test_virtual_three_and_old_physical_three_read_preserved_without_upgrade(core):
    t = core; old = deepcopy(t.target)
    old["patch_bindings"] = [{"device_id": t.body["device_id"], "mode": "physical",
                              "protocol_version": "3.0", "firmware_version": "authored-old-v3"}]
    replace_fixture_record(t.registry, old); before = rows(t.registry)
    actual = t.registry.get_twin(old["twin_id"])
    assert actual == old and rows(t.registry) == before
    with pytest.raises(ValueError): predicate(actual, t.inspection)
    assert rows(t.registry) == before
    p = t.registry.prepare_patch_binding(old["twin_id"], {"device_id": "separate-virtual",
        "mode": "virtual", "protocol_version": "3.0"}, expected_version=1, request_id=t.request_id)
    assert t.registry.commit_prepared_transition(p) == "COMMITTED"
    assert p.record["patch_bindings"][0] == old["patch_bindings"][0]
    assert p.record["patch_bindings"][-1]["protocol_version"] == "3.0"
    assert p.record["patch_bindings"][-1]["mode"] == "virtual"
