"""Authored, private reference fixtures; no participant source or model execution."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
import copy
import sqlite3
import threading
import urllib.request

import pytest

from livemorebio.tests.stack_client_fixtures import forbid_stack_client

from livemorebio.aegle import reference_cohorts as cohorts
from livemorebio.aegle.registry_audit import RegistryAudit
from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError
from livemorebio.aegle.subjects import SubjectRegistry
from livemorebio.tests.clinical_registry_fixtures import KEY
from livemorebio.tests.test_reference_cohort_lifecycle import draft, service
from livemorebio.tests.test_registry_bootstrap_contract import legacy_audited_store
from ._timing import wait_seconds


@pytest.fixture(autouse=True)
def no_external_or_numerical_work(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("Reference authority tests must not contact peers or construct models")
    monkeypatch.setattr(urllib.request, "urlopen", forbidden)
    monkeypatch.setattr(urllib.request, "build_opener", forbidden)
    monkeypatch.setattr("livemorebio.transport.authenticated_opener", forbidden)
    forbid_stack_client(monkeypatch, forbidden)
    from livemorebio.aegle import runtime
    monkeypatch.setattr(runtime.AegleTwin, "__init__", forbidden)


def body_for(service):
    payload = draft()
    return {"draft": payload, "preview_token": service.preview(payload)["preview_token"]}


def frozen(service):
    body = body_for(service)
    record = service.create(body, idempotency_key="authority-fixture")
    member_id = service.page_members(record["cohort_id"])["members"][0]["member_id"]
    return body, record["cohort_id"], member_id


def snapshot(path):
    with closing(sqlite3.connect(path)) as con:
        names = [row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        return {name: con.execute('SELECT * FROM "' + name + '" ORDER BY rowid').fetchall()
                for name in names if not name.startswith("sqlite_")}


def unavailable(call, *, bootstrap_code=None):
    expected = RegistryBootstrapError if bootstrap_code is not None else cohorts.ReferenceCohortError
    with pytest.raises(expected) as caught:
        call()
    if bootstrap_code is not None:
        assert caught.value.code == bootstrap_code
        assert str(caught.value) == "Registry key authority could not be confirmed; no successful access is established."
    else:
        assert caught.value.code == "REFERENCE_STORAGE_UNAVAILABLE"
        assert caught.value.status == 503
        assert str(caught.value) == "Reference storage or its durable audit is unavailable."
    return caught.value


def invoke(service, operation, body, cohort_id, member_id):
    actions = {
        "preview": lambda: service.preview(draft()),
        "create": lambda: service.create(body, idempotency_key="new-authority-fixture"),
        "replay": lambda: service.create(body, idempotency_key="authority-fixture"),
        "summary": lambda: service.get_summary(cohort_id),
        "page": lambda: service.page_members(cohort_id),
        "member": lambda: service.get_member(cohort_id, member_id),
    }
    return actions[operation]()


class ConnectionProxy:
    """Actual SQLite transaction with injectable acknowledgment/cleanup faults."""
    def __init__(self, connection):
        self.connection = connection

    def __getattr__(self, name):
        return getattr(self.connection, name)

    def __enter__(self):
        self.connection.__enter__()
        return self

    def __exit__(self, *args):
        return self.connection.__exit__(*args)


def test_constructor_and_every_phase_check_exact_writer_before_protected_work(tmp_path, monkeypatch, service):
    trace = []
    proxies = []
    original_connect = cohorts._GuardedRegistry._connect
    original_check = RegistryAudit.check_authority

    class Traced(ConnectionProxy):
        checked = False

        def execute(self, sql, parameters=()):
            if sql == "BEGIN IMMEDIATE":
                self.checked = False
                trace.append((id(self), "begin"))
            if "public_reference_" in sql or "public_reference_store_id" in parameters:
                assert self.in_transaction and self.checked, "unprotected reference SQL"
                trace.append((id(self), "reference_sql"))
            return self.connection.execute(sql, parameters)

        def executescript(self, sql):
            assert "public_reference_" not in sql, "executescript breaks protected DDL transaction"
            return self.connection.executescript(sql)

        def commit(self):
            trace.append((id(self), "commit"))
            self.connection.commit()
            self.checked = False

    def connect(registry):
        result = Traced(original_connect(registry))
        proxies.append(result)
        return result

    def check(audit, con, reservation=None):
        assert con.in_transaction, "authority must already hold the writer transaction"
        result = original_check(audit, con, reservation)
        if isinstance(con, Traced):
            con.checked = True
            trace.append((id(con), "check"))
        return result

    monkeypatch.setattr(cohorts._GuardedRegistry, "_connect", connect)
    monkeypatch.setattr(RegistryAudit, "check_authority", check)
    guarded = cohorts.ReferenceCohortService(service.path, key=b"k" * 32, source_dir=service.source_dir)
    for name in ("_record", "_audit", "_write_member", "_existing"):
        original = getattr(guarded, name)
        def guarded_method(con, *args, _original=original, **kwargs):
            assert isinstance(con, Traced) and con.in_transaction and con.checked
            trace.append((id(con), "protected_method"))
            return _original(con, *args, **kwargs)
        monkeypatch.setattr(guarded, name, guarded_method)
    for owner, name in ((guarded.registry, "_open"), (guarded, "_unseal")):
        original = getattr(owner, name)
        def guarded_decrypt(*args, _original=original, **kwargs):
            active = []
            for con in proxies:
                try:
                    if con.in_transaction:
                        active.append(con)
                except sqlite3.ProgrammingError:
                    pass  # Already closed connections are not authority.
            assert len(active) == 1 and active[0].checked
            return _original(*args, **kwargs)
        monkeypatch.setattr(owner, name, guarded_decrypt)
    start = len(trace)
    body, cohort_id, member_id = frozen(guarded)
    invoke(guarded, "replay", body, cohort_id, member_id)
    invoke(guarded, "summary", body, cohort_id, member_id)
    invoke(guarded, "member", body, cohort_id, member_id)
    # Two preview + two create + page + replay + summary + detail transactions.
    assert sum(kind == "begin" for _, kind in trace[start:]) == 8
    assert sum(kind == "check" for _, kind in trace[start:]) == 16


@pytest.mark.parametrize("invalid", ["missing", None, "", 1])
def test_missing_or_invalid_production_authority_fails_before_selection(service, monkeypatch, invalid):
    if invalid == "missing":
        service.registry.audit.authority_check = None
    else:
        service.registry.audit.authority_check = lambda con: invalid
    before = snapshot(service.path)
    monkeypatch.setattr(service, "_selection", lambda _: pytest.fail("selection preceded authority"))
    unavailable(lambda: service.preview(draft()))
    assert snapshot(service.path) == before


@pytest.mark.parametrize("operation", ["preview", "create", "replay", "summary", "page", "member"])
@pytest.mark.parametrize("corruption", ["proof", "public_id", "registry_id", "orphan", "duplicate"])
def test_already_open_operations_reject_actual_changed_authority(service, monkeypatch, operation, corruption):
    body, cohort_id, member_id = frozen(service)
    with closing(sqlite3.connect(service.path)) as con:
        if corruption == "proof":
            con.execute("UPDATE registry_data_key_proof SET ciphertext=?", (b"private-invalid-proof",))
        elif corruption == "public_id":
            con.execute("UPDATE registry_state SET state_value=? WHERE state_key='public_reference_store_id'", ("11111111-1111-4111-8111-111111111111",))
        elif corruption == "registry_id":
            con.execute("UPDATE registry_state SET state_value=? WHERE state_key='registry_store_id'", ("11111111-1111-4111-8111-111111111111",))
        elif corruption == "orphan":
            con.execute("DELETE FROM registry_bootstrap_identity")
            con.execute("DELETE FROM registry_data_key_proof")
            con.execute("DELETE FROM registry_bootstrap_proof_binding")
        else:
            con.execute("PRAGMA ignore_check_constraints=ON")
            con.execute("INSERT INTO registry_bootstrap_identity SELECT 2,'duplicate-fixture',nonce,ciphertext FROM registry_bootstrap_identity")
        con.commit()
    before = snapshot(service.path)
    monkeypatch.setattr(service, "_selection", lambda _: pytest.fail("source work preceded authority"))
    monkeypatch.setattr(service.registry, "_open", lambda *_: pytest.fail("record decrypted before authority"))
    monkeypatch.setattr(service, "_unseal", lambda *_: pytest.fail("member decrypted before authority"))
    unavailable(lambda: invoke(service, operation, body, cohort_id, member_id),
                bootstrap_code=None if corruption == "public_id" else "REGISTRY_BOOTSTRAP_INVALID")
    assert snapshot(service.path) == before


def test_wrong_key_reopen_does_not_change_any_journal_or_record(service):
    _, cohort_id, _ = frozen(service)
    before = snapshot(service.path)
    unavailable(lambda: cohorts.ReferenceCohortService(service.path, key=b"x" * 32, source_dir=service.source_dir),
                bootstrap_code="REGISTRY_BOOTSTRAP_INVALID")
    assert snapshot(service.path) == before
    assert cohorts.ReferenceCohortService(service.path, key=b"k" * 32, source_dir=service.source_dir).get_summary(cohort_id)["cohort_id"] == cohort_id


@pytest.mark.parametrize("operation", ["preview", "create"])
def test_actual_adoption_between_unlocked_phases_rejects_but_fresh_operation_works(tmp_path, monkeypatch, service, operation):
    path = legacy_audited_store(tmp_path)
    live = cohorts.ReferenceCohortService(path, key=KEY, source_dir=service.source_dir)
    adopter = SubjectRegistry(path, key=KEY)
    body = body_for(live)
    entered, adopted = threading.Event(), threading.Event()
    original = live._selection
    def select(draft):
        entered.set()
        assert adopted.wait(5), "adoption worker did not complete"
        return original(draft)
    monkeypatch.setattr(live, "_selection", select)
    def adopt():
        assert entered.wait(5), "source phase was never reached"
        adopter.adopt_audit_authority()
        adopted.set()
    before = snapshot(path)
    with ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(adopt)
        unavailable(lambda: live.preview(draft()) if operation == "preview" else live.create(body, idempotency_key="adoption-fixture"))
        future.result(timeout=wait_seconds(5))
    after = snapshot(path)
    for name in ("records", "public_reference_members", "public_reference_access", "registry_audit"):
        assert after[name] == before[name]
    monkeypatch.setattr(live, "_selection", original)
    assert live.preview(draft())["executable"] is False
    assert live.create(body, idempotency_key="adoption-fixture")["idempotent_replay"] is False


def test_source_io_outside_writer_and_exact_replay_does_not_reload(service, monkeypatch):
    original = service._load_population
    calls = []
    def load():
        with closing(sqlite3.connect(service.path, timeout=0)) as other:
            other.execute("BEGIN IMMEDIATE")
            calls.append("unlocked")
            other.rollback()
        return original()
    monkeypatch.setattr(service, "_load_population", load)
    body = body_for(service)
    result = service.create(body, idempotency_key="authority-fixture")
    assert calls == ["unlocked", "unlocked"]
    monkeypatch.setattr(service, "_selection", lambda _: pytest.fail("frozen replay must not reload source"))
    monkeypatch.setattr(cohorts.time, "time", lambda: 10**12)
    recovered = service.create(body, idempotency_key="authority-fixture")
    assert recovered["cohort_id"] == result["cohort_id"] and recovered["idempotent_replay"]


def test_two_connection_race_creates_once_with_separate_replay_journal(service, monkeypatch):
    body = body_for(service)
    barrier = threading.Barrier(2)
    original = service._selection
    def select(draft):
        barrier.wait(timeout=wait_seconds(5))
        return original(draft)
    monkeypatch.setattr(service, "_selection", select)
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(service.create, copy.deepcopy(body), idempotency_key="race-fixture") for _ in range(2)]
        results = [future.result(timeout=wait_seconds(10)) for future in futures]
    assert results[0]["cohort_id"] == results[1]["cohort_id"]
    assert sorted(row["idempotent_replay"] for row in results) == [False, True]
    state = snapshot(service.path)
    assert len(state["records"]) == 1 and len(state["public_reference_members"]) == 3
    assert len(state["public_reference_access"]) == 3


def test_mutation_of_caller_draft_during_unlocked_selection_does_not_change_request(service, monkeypatch):
    body = body_for(service)
    expected = copy.deepcopy(body["draft"])
    original = service._selection
    def select(detached):
        body["draft"]["name"] = "MUTATED caller-only value"
        body["draft"]["size"] = 999
        return original(detached)
    monkeypatch.setattr(service, "_selection", select)
    result = service.create(body, idempotency_key="detached-fixture")
    assert result["draft"] == expected and result["size"] == 3
    result["draft"]["name"] = "MUTATED returned value"
    assert service.get_summary(result["cohort_id"])["draft"] == expected


def test_separate_journal_and_existing_ciphertexts_are_preserved(service):
    body, cohort_id, member_id = frozen(service)
    before = snapshot(service.path)
    for operation in ("preview", "replay", "summary", "page", "member"):
        invoke(service, operation, body, cohort_id, member_id)
    after = snapshot(service.path)
    for name in ("records", "public_reference_members", "registry_audit", "registry_audit_reservations"):
        assert after[name] == before[name]
    assert after["public_reference_access"][:len(before["public_reference_access"])] == before["public_reference_access"]
    with closing(sqlite3.connect(service.path)) as con:
        con.row_factory = sqlite3.Row
        events = [service._unseal(row, "audit", row["event_id"]) for row in con.execute("SELECT * FROM public_reference_access ORDER BY rowid")]
    assert [event["operation"] for event in events] == ["preview", "create", "member_page_read", "preview", "create_replay", "summary_read", "member_page_read", "member_read"]
    assert all(set(event) == {"operation", "resource_kind", "resource_id", "result", "source_id", "construction_sha256", "actor"} for event in events)


@pytest.mark.parametrize("phase", ["member", "audit"])
def test_partial_writes_rollback_without_success_journal(service, monkeypatch, phase):
    body = body_for(service)
    before = snapshot(service.path)
    name = "_write_member" if phase == "member" else "_audit"
    original = getattr(service, name)
    def fail(*args, **kwargs):
        original(*args, **kwargs)
        raise OSError("PRIVATE failure after actual insert")
    monkeypatch.setattr(service, name, fail)
    unavailable(lambda: service.create(body, idempotency_key="partial-fixture"))
    assert snapshot(service.path) == before


@pytest.mark.parametrize("operation", ["preview", "summary", "page", "member"])
@pytest.mark.parametrize("fault", ["commit", "close"])
def test_prepared_read_result_never_escapes_commit_or_close_failure(service, monkeypatch, operation, fault):
    body, cohort_id, member_id = frozen(service)
    connect = service.registry._connect
    class Failing(ConnectionProxy):
        def commit(self):
            self.connection.commit()
            if fault == "commit":
                raise OSError("PRIVATE lost commit ACK")
        def close(self):
            self.connection.close()
            if fault == "close":
                raise OSError("PRIVATE close ACK")
    monkeypatch.setattr(service.registry, "_connect", lambda: Failing(connect()))
    unavailable(lambda: invoke(service, operation, body, cohort_id, member_id))


def test_lost_actual_create_commit_ack_recovered_only_by_explicit_frozen_retry(service, monkeypatch):
    body = body_for(service)
    before = snapshot(service.path)
    connect = service.registry._connect
    class LostAck(ConnectionProxy):
        def commit(self):
            inserted = self.connection.execute("SELECT COUNT(*) FROM public_reference_members").fetchone()[0] == 3
            self.connection.commit()
            if inserted:
                raise OSError("PRIVATE lost acknowledgment")
    monkeypatch.setattr(service.registry, "_connect", lambda: LostAck(connect()))
    unavailable(lambda: service.create(body, idempotency_key="lost-ack-fixture"))
    committed = snapshot(service.path)
    assert len(committed["records"]) == 1 and len(committed["public_reference_members"]) == 3
    assert len(committed["public_reference_access"]) == len(before["public_reference_access"]) + 1
    monkeypatch.setattr(service.registry, "_connect", connect)
    monkeypatch.setattr(cohorts.time, "time", lambda: 10**12)
    monkeypatch.setattr(service, "_selection", lambda _: pytest.fail("retry must use frozen record"))
    recovered = service.create(body, idempotency_key="lost-ack-fixture")
    assert recovered["idempotent_replay"] is True
    after = snapshot(service.path)
    assert after["records"] == committed["records"] and after["public_reference_members"] == committed["public_reference_members"]
    assert len(after["public_reference_access"]) == len(committed["public_reference_access"]) + 1


@pytest.mark.parametrize("fault", ["missing_hook", "second_ddl"])
def test_initial_public_ddl_is_authorized_and_atomic(tmp_path, monkeypatch, fault):
    path = legacy_audited_store(tmp_path)
    SubjectRegistry(path, key=KEY)
    before = snapshot(path)
    assert "public_reference_members" not in before
    checked, wrote_first, inherited = [], [], []
    original_check = RegistryAudit.check_authority
    def check(audit, con, reservation=None):
        result = original_check(audit, con, reservation)
        checked.append(con)
        return result
    monkeypatch.setattr(RegistryAudit, "check_authority", check)
    original_connect = cohorts._GuardedRegistry._connect
    class DdlFailure(ConnectionProxy):
        def execute(self, sql, parameters=()):
            if "CREATE TABLE IF NOT EXISTS public_reference_" in sql:
                assert self in checked and self.in_transaction
                if "public_reference_access" in sql:
                    assert self.execute("SELECT name FROM sqlite_master WHERE name='public_reference_members'").fetchone()
                    raise OSError("PRIVATE failed second DDL")
                wrote_first.append(True)
            return self.connection.execute(sql, parameters)
    original_init = cohorts._GuardedRegistry.__init__
    def initialize(registry, *args, **kwargs):
        original_init(registry, *args, **kwargs)
        inherited.append(snapshot(path))
        if fault == "missing_hook":
            registry.audit.authority_check = None
    monkeypatch.setattr(cohorts._GuardedRegistry, "__init__", initialize)
    if fault == "second_ddl":
        monkeypatch.setattr(cohorts._GuardedRegistry, "_connect", lambda registry: DdlFailure(original_connect(registry)))
    unavailable(lambda: cohorts.ReferenceCohortService(path, key=KEY, source_dir=tmp_path / "unused-source"))
    assert bool(wrote_first) is (fault == "second_ddl")
    # The inherited legacy-index access audit is its own committed operation;
    # public DDL failure must neither erase it nor claim it was rolled back.
    assert len(inherited) == 1 and snapshot(path) == inherited[0]
    assert inherited[0]["registry_audit"][:len(before["registry_audit"])] == before["registry_audit"]
    assert inherited[0]["records"] == before["records"]


@pytest.mark.parametrize("operation", ["preview", "create", "replay", "summary", "page", "member"])
@pytest.mark.parametrize("changed", ["authority", "namespace"])
def test_final_same_connection_check_rolls_back_in_transaction_authority_change(service, monkeypatch, operation, changed):
    body, cohort_id, member_id = frozen(service)
    before = snapshot(service.path)
    original = service._audit
    calls = []
    def audit(con, *args, **kwargs):
        original(con, *args, **kwargs)
        if changed == "authority":
            con.execute("UPDATE registry_data_key_proof SET ciphertext=?", (b"private-damaged-proof",))
        else:
            con.execute("UPDATE registry_state SET state_value=? WHERE state_key='public_reference_store_id'", ("22222222-2222-4222-8222-222222222222",))
        calls.append(True)
    monkeypatch.setattr(service, "_audit", audit)
    unavailable(lambda: invoke(service, operation, body, cohort_id, member_id),
                bootstrap_code="REGISTRY_BOOTSTRAP_INVALID" if changed == "authority" else None)
    assert calls == [True]
    assert snapshot(service.path) == before


@pytest.mark.parametrize("fault", ["before_commit", "after_commit", "close"])
def test_preview_final_phase_failure_does_not_return_prepared_token(service, monkeypatch, fault):
    connect = service.registry._connect
    calls, source_calls = [], []
    original = service._selection
    def select(draft):
        source_calls.append(True)
        return original(draft)
    monkeypatch.setattr(service, "_selection", select)
    before = snapshot(service.path)
    class FinalFailure(ConnectionProxy):
        def commit(self):
            if fault == "before_commit":
                raise OSError("PRIVATE precommit failure")
            self.connection.commit()
            if fault == "after_commit":
                raise OSError("PRIVATE postcommit failure")
        def close(self):
            self.connection.close()
            if fault == "close":
                raise OSError("PRIVATE close failure")
    def opening():
        calls.append(True)
        con = connect()
        return FinalFailure(con) if len(calls) == 2 else con
    monkeypatch.setattr(service.registry, "_connect", opening)
    unavailable(lambda: service.preview(draft()))
    assert len(calls) == 2 and source_calls == [True]
    after = snapshot(service.path)
    expected_added = 0 if fault == "before_commit" else 1
    assert len(after["public_reference_access"]) == len(before["public_reference_access"]) + expected_added


@pytest.mark.parametrize("fault", ["rollback", "close", "both"])
@pytest.mark.parametrize("primary_kind", ["ordinary", "domain", "interruption"])
def test_cleanup_never_masks_primary_with_raw_diagnostics_or_returns_domain_success(service, monkeypatch, fault, primary_kind):
    connect = service.registry._connect
    calls = []
    class CleanupFailure(ConnectionProxy):
        def rollback(self):
            self.connection.rollback()
            calls.append("rollback")
            if fault in {"rollback", "both"}:
                raise OSError("PRIVATE secondary rollback")
        def close(self):
            self.connection.close()
            calls.append("close")
            if fault in {"close", "both"}:
                raise OSError("PRIVATE secondary close")
    monkeypatch.setattr(service.registry, "_connect", lambda: CleanupFailure(connect()))
    primary = (OSError("PRIVATE original failure") if primary_kind == "ordinary" else
               cohorts.ReferenceCohortError("REFERENCE_COHORT_NOT_FOUND", "not found", 404)
               if primary_kind == "domain" else KeyboardInterrupt())
    with pytest.raises(BaseException) as caught:
        with service._connection():
            raise primary
    assert calls == ["rollback", "close"]
    if primary_kind == "domain":
        assert isinstance(caught.value, cohorts.ReferenceCohortError)
        assert caught.value.code == "REFERENCE_STORAGE_UNAVAILABLE" and caught.value.status == 503
    else:
        assert caught.value is primary


def test_existing_connection_busy_timeout_is_bounded_and_failure_is_safe(service, monkeypatch):
    original = cohorts.sqlite3.connect
    recorded = []
    with closing(original(service.path)) as blocker:
        blocker.execute("BEGIN IMMEDIATE")
        def immediate_busy(*args, **kwargs):
            recorded.append(kwargs["timeout"])
            return original(*args, **{**kwargs, "timeout": 0})
        monkeypatch.setattr(cohorts.sqlite3, "connect", immediate_busy)
        unavailable(lambda: service.preview(draft()))
        blocker.rollback()
    assert recorded == [5.0]
