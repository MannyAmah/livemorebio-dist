"""Recon3D commercial execution and unqualified physiology remain blocked."""
import pytest
from livemorebio.engines import metabolism as MB

@pytest.mark.parametrize("operation", [
    lambda: MB.validate_calibration(), lambda: MB.atp_yield(genome={"NDUFS1_lof": 2}),
    lambda: MB.target_pathway_effects(["HMGCR"], gene_perturbations={"HMGCR": .1}),
    lambda: MB.operating_point(None),
])
def test_legacy_metabolism_is_retired_even_with_a_local_file(operation, monkeypatch, tmp_path):
    stale = tmp_path / "Recon3D.xml"
    stale.write_text("not commercial permission or a verified asset", encoding="utf-8")
    monkeypatch.setattr(MB, "MODEL_PATH", str(stale))
    with pytest.raises(ValueError, match="retired"):
        operation()


def test_drug_atp_mapping_remains_unqualified_without_model_files():
    with pytest.raises(ValueError, match="qualified"):
        MB.drug_atp_response("metformin")
