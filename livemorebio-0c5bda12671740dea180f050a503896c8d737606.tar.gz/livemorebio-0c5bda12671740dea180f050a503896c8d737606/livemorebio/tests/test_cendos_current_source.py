"""Authored current-source captures, not clinical participants or assays."""
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
from types import SimpleNamespace
from uuid import UUID

import pytest

from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401
from livemorebio.tests.cendos_source_fixtures import no_cendos_peer_network, technical_source  # noqa: F401


@pytest.mark.parametrize("uncertain", [False, True])
def test_current_source_rejects_unavailable_or_uncertain_before_any_read(client, monkeypatch, uncertain):
    from livemorebio.aegle import server
    from livemorebio.aegle.execution import DENY_ALL

    if uncertain:
        with server._model_source_authority.commit_guard():
            server._model_source_authority.install_generation(DENY_ALL)
    monkeypatch.setattr(server, "_subject_registry", lambda: pytest.fail("ineligible source reached registry"))
    response = client.get("/api/cendos/current-source")
    assert response.status_code == (503 if uncertain else 409)
    assert response.json()["code"] == ("SELECTION_COMMIT_UNCONFIRMED" if uncertain else "MODEL_BINDING_REQUIRED")


def test_current_source_auth_precedes_any_registry_read(client, monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server

    monkeypatch.setattr(server, "_subject_registry", lambda: pytest.fail("unauthorized source access"))
    assert TestClient(server.app).get("/api/cendos/current-source").status_code == 401


@pytest.mark.parametrize("preview", [False, True])
def test_current_source_is_detached_minimum_snapshot_with_actual_hash(client, monkeypatch, preview):
    from livemorebio.aegle import server
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY

    profile = asdict(HEALTHY)
    state = {"profile": profile["name"], "profile_params": profile,
        "pk_context": {"age": 50, "genome": {}, "evidence_class": "REFERENCE_INITIALIZED"},
        "parameter_provenance": {"Gb": {"evidence_class": "REFERENCE_INITIALIZED"}},
        "observations": {"private_technical_sentinel": 27}, "human": {"notes": "not-for-cendos-capture"}}
    summary = {**server._state["subject"], "source_class": "SYNTHETIC"}
    server._state.update(tw=SimpleNamespace(state=lambda: state), subject=None if preview else summary)
    accesses = []

    def audited(**kwargs):
        accesses.append(kwargs)
        return deepcopy(summary)

    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(audited_active_twin=audited))
    generation = server._model_source_authority.generation
    response = client.get("/api/cendos/current-source")
    assert response.status_code == 200, response.text
    packet = response.json()
    assert set(packet) == {"schema", "snapshot", "snapshot_sha256"}
    assert packet["schema"] == "livemore.cendos-current-source.v1"
    snapshot = packet["snapshot"]
    assert set(snapshot) == {"profile", "profile_params", "pk_context", "parameter_provenance", "subject", "model_availability"}
    expected = json.dumps(snapshot, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()
    assert packet["snapshot_sha256"] == hashlib.sha256(expected).hexdigest()
    assert snapshot["profile_params"] == profile
    assert snapshot["model_availability"]["source_generation"] == generation
    assert snapshot["subject"] == (None if preview else summary)
    assert response.headers["Cache-Control"] == "no-store"
    assert str(UUID(response.headers["X-Request-ID"])) == response.headers["X-Request-ID"]
    assert not accesses if preview else accesses == [{"action": "source_capture", "request_id": response.headers["X-Request-ID"]}]
    assert "private_technical_sentinel" not in response.text and "not-for-cendos-capture" not in response.text
    snapshot["profile_params"]["Gb"] = -999
    assert profile["Gb"] == HEALTHY.Gb


@pytest.mark.parametrize("code,status", [("MODEL_BINDING_REQUIRED", 409),
                                        ("SELECTION_COMMIT_UNCONFIRMED", 503)])
def test_old_ready_bus_does_not_authorize_cendos_calculation(monkeypatch, code, status):
    from fastapi.testclient import TestClient
    from livemorebio import bus
    from livemorebio.cendos import service
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY
    from livemorebio.execution_client import ContinuousClientError

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-cendos-source-token")
    stale = {"profile": HEALTHY.name, "profile_params": asdict(HEALTHY),
             "pk_context": {"age": 50, "genome": {}, "evidence_class": "REFERENCE_INITIALIZED"}}
    monkeypatch.setattr(bus, "snapshot", lambda key: deepcopy(stale))
    monkeypatch.setattr(bus, "publish", lambda *a: None)
    calls = []

    def unavailable():
        raise ContinuousClientError(code, status=status)

    monkeypatch.setattr(service, "_read_current_source", unavailable, raising=False)
    monkeypatch.setattr(service.pharmacology, "metformin", lambda baseline, *a: (calls.append(True) or baseline, {}))
    monkeypatch.setattr(service, "ogtt_effect", lambda *a, **k: {"decision": "TECHNICAL", "delta_mean": 0, "delta_iAUC": 0})
    response = TestClient(service.app).post("/assay/current", json={"drug": "metformin"},
        headers={"Authorization": "Bearer technical-cendos-source-token"})
    assert response.status_code == status
    assert response.json()["code"] == code
    assert calls == [], "cached ready data must not authorize calculation for unavailable current source"


@pytest.fixture
def source_envelope():
    from livemorebio.cendos.current_source import make_source_envelope
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY

    return make_source_envelope({"profile": HEALTHY.name, "profile_params": asdict(HEALTHY),
        "pk_context": {"age": 50, "genome": {}, "evidence_class": "REFERENCE_INITIALIZED"},
        "parameter_provenance": {}, "subject": None,
        "model_availability": {"schema": "livemore.model-availability.v1", "state": "READY", "reason_code": None,
            "selection_mode": "reference_preview", "twin_id": None, "twin_version": 0,
            "source_generation": "a" * 32, "preparation_available": True}})


def test_assay_event_is_bound_to_the_same_frozen_source(source_envelope, monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio import bus
    from livemorebio.cendos import service
    from livemorebio.cendos.current_source import source_guard

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-cendos-source-token")
    reads, events = [], []
    monkeypatch.setattr(service, "_read_current_source", lambda: reads.append(True) or deepcopy(source_envelope))
    monkeypatch.setattr(bus, "snapshot", lambda *a: pytest.fail("assay used notification cache"))
    monkeypatch.setattr(bus, "publish", lambda *args: events.append(args))
    monkeypatch.setattr(service.pharmacology, "metformin", lambda baseline, *a: (baseline, {}))
    monkeypatch.setattr(service, "ogtt_effect", lambda *a, **k: {"decision": "TECHNICAL", "delta_mean": 0, "delta_iAUC": 0})
    response = TestClient(service.app).post("/assay/current", json={"drug": "metformin"},
        headers={"Authorization": "Bearer technical-cendos-source-token"})
    assert response.status_code == 200
    assert reads == [True, True] and len(events) == 1
    assert response.json()["assayed_source"] == source_envelope
    assert events[0][2]["source_identity"] == source_guard(source_envelope)


@pytest.mark.parametrize("wrong_peer", [False, True])
def test_proxy_injects_own_guard_and_rejects_other_aegle_result(client, monkeypatch, source_envelope, wrong_peer):
    import urllib.error
    import urllib.request
    from livemorebio.aegle import server
    from livemorebio.cendos.current_source import make_source_envelope, source_guard

    generation = server._model_source_authority.generation
    source_envelope["snapshot"]["model_availability"]["source_generation"] = generation
    own = make_source_envelope(source_envelope["snapshot"])
    other_snapshot = deepcopy(own["snapshot"])
    other_snapshot["model_availability"]["source_generation"] = "b" * 32
    other = make_source_envelope(other_snapshot)
    monkeypatch.setattr(server, "_require_numerical_model", lambda: None)
    monkeypatch.setattr(server, "_capture_cendos_source", lambda *a: deepcopy(own))
    calls = []

    def forward(body):
        assert not server._model_source_authority._lock._is_owned()
        calls.append(deepcopy(body))
        return {"assayed_source": other if wrong_peer else own}

    monkeypatch.setattr(server, "_forward_cendos_assay", forward, raising=False)
    # The inherited proxy uses its own opener before this correction. Intercept
    # that legacy path too; test stores alone do not isolate fallback peer URLs.
    def refuse_network(*args, **kwargs):
        raise urllib.error.URLError("technical test: external transport disabled")
    monkeypatch.setattr(urllib.request, "urlopen", refuse_network)
    response = client.post("/api/cendos/assay", json={"drug": "metformin"})
    assert calls == [{"drug": "metformin", "expected_source": source_guard(own)}]
    assert response.status_code == (409 if wrong_peer else 200)
    if wrong_peer:
        assert response.json()["code"] == "MODEL_SOURCE_CHANGED"


@pytest.mark.parametrize("field", ["twin_id", "subject_id", "source_class", "version"])
def test_source_capture_rejects_full_record_mismatch_before_state_read(client, monkeypatch, field):
    from livemorebio.aegle import server

    summary = {**server._state["subject"], "source_class": "SYNTHETIC"}
    active = deepcopy(summary)
    active[field] = 8 if field == "version" else "technical-mismatched-identity"
    server._state.update(tw=SimpleNamespace(state=lambda: pytest.fail("mismatched source read")), subject=summary)
    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(audited_active_twin=lambda **k: active))
    generation = server._model_source_authority.generation
    response = client.get("/api/cendos/current-source")
    assert response.status_code == 409 and response.json()["code"] == "MODEL_SOURCE_CHANGED"
    assert server._model_source_authority.generation == generation


@pytest.mark.parametrize("failure", ["audit", "invalid", "oversized"])
def test_source_capture_failure_is_private_and_does_not_change_selection(client, monkeypatch, source_envelope, failure):
    from livemorebio.aegle import server

    snapshot = deepcopy(source_envelope["snapshot"])
    if failure == "invalid":
        snapshot["profile_params"]["Gb"] = -1
    elif failure == "oversized":
        snapshot["parameter_provenance"] = {"technical": "x" * 2_000_000}
    summary = {**server._state["subject"], "source_class": "SYNTHETIC"}
    server._state.update(tw=SimpleNamespace(state=lambda: snapshot), subject=summary)

    def audited(**kwargs):
        if failure == "audit":
            raise OSError("PRIVATE TECHNICAL STORAGE SENTINEL")
        return deepcopy(summary)

    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(audited_active_twin=audited))
    generation = server._model_source_authority.generation
    response = client.get("/api/cendos/current-source")
    assert response.status_code == (503 if failure == "audit" else 409)
    assert response.json()["code"] == ("REGISTRY_STORAGE_UNAVAILABLE" if failure == "audit" else "MODEL_CONTEXT_INVALID")
    assert "PRIVATE" not in response.text
    assert response.headers["Cache-Control"] == "no-store"
    assert str(UUID(response.headers["X-Request-ID"])) == response.headers["X-Request-ID"]
    assert server._model_source_authority.generation == generation and server._state["subject"] == summary


@pytest.mark.parametrize("query,body", [("?subject=technical", None), ("", b"{}")])
def test_source_capture_has_no_query_or_body_before_any_state_read(client, monkeypatch, query, body):
    from livemorebio.aegle import server

    monkeypatch.setattr(server, "_ensure_selected_state", lambda: pytest.fail("invalid capture reached state"))
    response = client.request("GET", "/api/cendos/current-source" + query, content=body)
    assert response.status_code == 422 and response.json()["code"] == "CLIENT_INVALID"


@pytest.mark.parametrize("source_kind", ["aggregate_reference", "unbound_real", "descriptive_public"])
def test_source_capture_uses_actual_source_specific_context_dispatch(client, monkeypatch, source_envelope, source_kind):
    from livemorebio.aegle import server
    from livemorebio.tests.test_clinical_context_contract import _legacy_reference_record, _expected_legacy_profile

    record = _legacy_reference_record()
    record["lifecycle"] = "ACTIVE"
    if source_kind == "unbound_real":
        record["source_class"] = "REAL_HUMAN"
    elif source_kind == "descriptive_public":
        record["reference"] = {"schema": "livemore.public-reference-cohort.v1"}
    summary = {field: record[field] for field in
               ("twin_id", "subject_id", "display_label", "source_class", "lifecycle", "version")}
    snapshot = deepcopy(source_envelope["snapshot"])
    snapshot.update(profile=record["display_label"], profile_params=_expected_legacy_profile(record))
    reads = []

    def state():
        reads.append(True)
        return snapshot

    server._state.update(tw=SimpleNamespace(state=state), subject=summary)
    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(audited_active_twin=lambda **k: deepcopy(record)))
    response = client.get("/api/cendos/current-source")
    if source_kind == "aggregate_reference":
        assert response.status_code == 200 and reads == [True]
        assert response.json()["snapshot"]["profile_params"] == _expected_legacy_profile(record)
        assert response.json()["snapshot"]["subject"] == summary
    else:
        assert response.status_code == 409 and reads == []
        assert response.json()["code"] == ("MODEL_BINDING_REQUIRED" if source_kind == "unbound_real" else "MODEL_CONTEXT_INVALID")


@pytest.mark.parametrize("failure", ["different_generation", "different_parameters", "unreadable", "unavailable"])
def test_changed_or_unreadable_post_assay_source_never_publishes(source_envelope, monkeypatch, failure):
    from fastapi.testclient import TestClient
    from livemorebio import bus
    from livemorebio.cendos import service
    from livemorebio.execution_client import ContinuousClientError

    original = deepcopy(source_envelope)
    changed = deepcopy(source_envelope["snapshot"])
    if failure == "different_generation":
        changed["model_availability"]["source_generation"] = "b" * 32
    else:
        changed["profile_params"]["weight_kg"] += 1
    reads, calls = [], []

    def read():
        reads.append(True)
        if len(reads) == 1:
            return source_envelope
        if failure in {"unreadable", "unavailable"}:
            raise ContinuousClientError("CLIENT_TRANSPORT" if failure == "unreadable" else "MODEL_BINDING_REQUIRED")
        return technical_source(changed)

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-cendos-source-token")
    monkeypatch.setattr(service, "_read_current_source", read)
    monkeypatch.setattr(bus, "publish", lambda *a: pytest.fail("stale result published"))
    monkeypatch.setattr(service.pharmacology, "metformin", lambda baseline, *a: (calls.append(True) or baseline, {}))
    monkeypatch.setattr(service, "ogtt_effect", lambda *a, **k: {"technical_stale_result": True})
    response = TestClient(service.app).post("/assay/current", json={"drug": "metformin"},
        headers={"Authorization": "Bearer technical-cendos-source-token"})
    assert calls == [True] and reads == [True, True]
    assert response.status_code == (503 if failure == "unreadable" else 409)
    assert "technical_stale_result" not in response.text and source_envelope == original


@pytest.mark.parametrize("bad_guard", ["wrong_peer", "unknown_field", "boolean_version", "unsafe_integer"])
def test_restrictive_guard_rejected_before_calculation(source_envelope, monkeypatch, bad_guard):
    from fastapi.testclient import TestClient
    from livemorebio.cendos import service
    from livemorebio.cendos.current_source import source_guard, validate_source_guard
    from livemorebio.execution_client import ContinuousClientError

    expected = source_guard(source_envelope)
    if bad_guard == "wrong_peer":
        expected["source_generation"] = "b" * 32
    elif bad_guard == "unknown_field":
        expected["profile_params"] = {}
    elif bad_guard == "boolean_version":
        expected["twin_version"] = False
    else:
        expected.update(twin_id="technical", twin_version=2 ** 53)
    if bad_guard != "wrong_peer":
        with pytest.raises(ContinuousClientError):
            validate_source_guard(expected)
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-cendos-source-token")
    monkeypatch.setattr(service, "_read_current_source", lambda: source_envelope)
    monkeypatch.setattr(service.pharmacology, "metformin", lambda *a: pytest.fail("mismatched guard executed"))
    response = TestClient(service.app).post("/assay/current", json={"drug": "metformin", "expected_source": expected},
        headers={"Authorization": "Bearer technical-cendos-source-token"})
    # Unsafe JSON integers are rejected by the request parser before the guard.
    expected_status = 409 if bad_guard == "wrong_peer" else 400 if bad_guard == "unsafe_integer" else 422
    assert response.status_code == expected_status


@pytest.mark.parametrize("when", ["before_dispatch", "inflight", "post_body"])
@pytest.mark.parametrize("uncertain", [False, True])
def test_proxy_source_races_do_not_publish_old_result(client, monkeypatch, source_envelope, when, uncertain):
    from livemorebio.aegle import server, research_api
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.cendos.current_source import make_source_envelope

    source_envelope["snapshot"]["model_availability"]["source_generation"] = server._model_source_authority.generation
    own = make_source_envelope(source_envelope["snapshot"])
    monkeypatch.setattr(server, "_require_numerical_model", lambda: None)
    monkeypatch.setattr(server, "_capture_cendos_source", lambda *a: server._model_source_authority.capture(
        lambda: deepcopy(own), expected_generation=own["snapshot"]["model_availability"]["source_generation"]))
    calls = []

    def change():
        with server._model_source_authority.commit_guard():
            server._model_source_authority.install_generation(DENY_ALL if uncertain else "technical-new-source")

    def forward(body):
        assert not server._model_source_authority._lock._is_owned()
        calls.append(True)
        if when == "inflight":
            change()
        return {"assayed_source": own, "technical_stale_result": True}

    if when == "before_dispatch":
        async def dispatch(fn, *args, **kwargs):
            change()
            return fn(*args, **kwargs)
        monkeypatch.setattr(server.asyncio, "to_thread", dispatch)
    elif when == "post_body":
        original_body = research_api.body
        async def read_body(req):
            value = await original_body(req)
            change()
            return value
        monkeypatch.setattr(research_api, "body", read_body)
    monkeypatch.setattr(server, "_forward_cendos_assay", forward)
    response = client.post("/api/cendos/assay", json={"drug": "metformin"})
    assert calls == ([True] if when == "inflight" else [])
    assert response.status_code == (503 if uncertain else 409)
    assert response.json()["code"] == ("SELECTION_COMMIT_UNCONFIRMED" if uncertain else "MODEL_SOURCE_CHANGED")
    assert "technical_stale_result" not in response.text
