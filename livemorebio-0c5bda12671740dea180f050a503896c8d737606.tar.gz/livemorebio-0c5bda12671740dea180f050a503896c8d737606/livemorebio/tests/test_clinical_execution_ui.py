"""Fixed technical frames remain historical across clinical availability changes."""
import json
from pathlib import Path
import subprocess
import pytest
from .test_execution_view_ui import PREAMBLE
from ._node import NODE, run_node as _run_node


MODULE=(Path(__file__).parents[1]/'aegle/console/lib/execution_view_state.js').as_uri()


@pytest.mark.parametrize('explicit_history',[True,False])
def test_unavailable_current_capabilities_preserve_explicit_fixed_history_but_not_live_controls(explicit_history):
    script=PREAMBLE.replace('process.argv[1]',json.dumps(MODULE))+r"""
const {mountContinuousExecution}=await import(new URL('./continuous_execution.js',MODULE));
const nodes=new Map();const el=(key,dataset={})=>{if(!nodes.has(key))nodes.set(key,{value:key==='[data-engine]'?'metabolic-continuous-v1':'',dataset,handlers:{},textContent:'',innerHTML:'',classList:{toggle(){}},setAttribute(){},replaceChildren(){this.innerHTML=''},addEventListener(k,f){this.handlers[k]=f}});return nodes.get(key)};
const buttons=['start','pause','resume','stop'].map(action=>el('engine-'+action,{engineAction:action}));
const host={innerHTML:'',classList:{toggle(){}},setAttribute(){},querySelector:el,querySelectorAll:key=>key==='[data-engine-action]'?buttons:[]};
const explicit=EXPLICIT;let unavailable=explicit;
globalThis.document={hidden:false,addEventListener(){},removeEventListener(){}};globalThis.window={addEventListener(){}};globalThis.location={search:explicit?'?execution_id='+status.execution_id:''};
let reads=0,posts=0;const fixed={...status,state:'paused'};const response=value=>({ok:true,json:async()=>value});globalThis.fetch=async(url,options)=>{if(options.method==='POST'){posts++;if(!explicit&&url==='/api/executions')return response({...status,state:'prepared',revision:1,control_revision:1,latest_frame:0,native_time:0});throw Error('no other mutation permitted')};if(url==='/api/executions/capabilities')return response(unavailable?{engine_contracts:[],source_generation:'new-source',selection:null,preparation_available:false,model_availability:{schema:'livemore.model-availability.v1',state:'UNAVAILABLE',reason_code:'MODEL_BINDING_REQUIRED',selection_mode:'observations_only',twin_id:'other-technical',twin_version:2,source_generation:'new-source',preparation_available:false}}:{engine_contracts:[],source_generation:status.source_generation,selection,preparation_available:true});reads++;return response(page(reads===1?[frame(1),frame(2)]:[],fixed))};
const tick=async()=>{for(let i=0;i<5;i++)await new Promise(r=>setTimeout(r,0))};
const ui=mountContinuousExecution(host);try{
  await tick();if(!explicit){await el('[data-prepare]').handlers.click();await tick();unavailable=true;}
  const exact=el('[data-raw-samples]').textContent;assert(exact.includes('90'),'fixture was not rendered');
  await el('[data-refresh-source]').handlers.click();await tick();assert(el('[data-selection]').textContent.includes('MODEL_BINDING_REQUIRED'),'unavailable reason hidden');
  if(explicit)assert(el('[data-raw-samples]').textContent===exact,'explicit frozen history mutated');
  else {assert(!el('[data-raw-samples]').textContent.includes('90'),'previous current numerical values retained');assert(!el('[data-quantities]').innerHTML.includes('<svg'),'old current plots retained');}
  assert(buttons[2].disabled,'Resume allowed after unavailable source selection');assert(el('[data-engine-state]').textContent.includes('historical'),'history presented as current');assert(el('[data-prepare]').disabled);assert(posts===(explicit?0:1));
  await el('[data-historical]').handlers.click();await tick();assert(el('[data-message]').textContent.includes('Historical page loaded'),'explicit history request did not succeed');assert(el('[data-raw-samples]').textContent===exact,'explicit historical read lost frozen values');
}finally{ui.dispose()}
""".replace('MODULE',json.dumps(MODULE)).replace('EXPLICIT',json.dumps(explicit_history)).replace('page(reads===1?[frame(1),frame(2)]:[],fixed)', '{...page(reads===1?[frame(1),frame(2)]:[],fixed),next_after_frame:2}')
    result=_run_node([NODE,'--input-type=module','--eval',script],capture_output=True,text=True,timeout=10, encoding="utf-8")
    assert result.returncode==0,result.stderr
