"""Real, local Git histories; credential shapes here are technical fixtures."""
from __future__ import annotations

import json
from pathlib import Path
import subprocess

import pytest

from ._source_tree import git_executable, no_git_checkout_reason, source_tree_only
from .test_secret_scan import scanner, technical_credentials, technical_zip

# Every case builds a real, technical Git history in a temporary directory, so each needs the git
# program, not this product's repository. The declared image carries no Git, and a client's native
# install need not have it either: there the module skips instead of failing the installer's own
# verification (review 8, L0-R26).
pytestmark = [source_tree_only('.git'),
              pytest.mark.skipif(git_executable() is None,
                                 reason=no_git_checkout_reason('technical git histories'))]


@pytest.fixture
def history(tmp_path):
    repository = tmp_path / "technical-history"
    repository.mkdir()

    def git(*arguments):
        return subprocess.run(
            ["git", "-c", "user.name=Technical Fixture", "-c",
             "user.email=technical@example.invalid", "-c", "commit.gpgsign=false",
             *arguments], cwd=repository, check=True, capture_output=True,
        ).stdout.decode("utf-8").strip()

    git("init", "-q")
    git("commit", "--allow-empty", "-qm", "technical baseline")
    baseline = git("rev-parse", "HEAD")

    def commit(name, content):
        path = repository / name
        if content is None:
            path.unlink()
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        git("add", "--", name)
        git("commit", "-qm", "technical binary change")
        return git("rev-parse", "HEAD")

    return repository, baseline, commit, git


def test_added_binary_credential_is_metadata_only_and_survives_later_deletion(scanner, history):
    repository, baseline, commit, _ = history
    token = technical_credentials()["github_token"]
    commit("technical.bin", b"\x00\xfftechnical\n" + token.encode("ascii") + b"\x00")
    commit("technical.bin", None)
    scan = scanner.Scanner()
    scan.scan_git(repository, baseline + "..HEAD")
    assert scan.findings == [{"path": "technical.bin", "line": 2, "pattern": "github_token"}]
    assert token not in json.dumps(scan.findings)


def test_clean_added_binary_and_deleted_binary_pass(scanner, history):
    repository, baseline, commit, _ = history
    commit("technical clean.bin", b"\x00\xfftechnical image pixels")
    commit("technical clean.bin", None)
    scan = scanner.Scanner()
    scan.scan_git(repository, baseline + "..HEAD")
    assert scan.findings == []


@pytest.mark.parametrize("name", ["technical.bin", "technical space.bin", "technical-\u00e9.bin"])
def test_modified_binary_scans_the_new_blob_not_the_working_tree(scanner, history, name):
    repository, _, commit, _ = history
    baseline = commit(name, b"\x00technical clean base")
    token = technical_credentials()["aws_access_key"].encode("ascii")
    commit(name, b"\x00technical\n" + token + b"\x00")
    (repository / name).write_bytes(b"\x00technical uncommitted clean bytes")
    scan = scanner.Scanner()
    scan.scan_git(repository, baseline + "..HEAD")
    assert scan.findings == [{"path": name, "line": 2, "pattern": "aws_access_key"}]


def test_deleted_binary_does_not_scan_the_old_blob(scanner, history):
    repository, _, commit, _ = history
    token = technical_credentials()["github_token"].encode("ascii")
    baseline = commit("technical.bin", b"\x00" + token)
    commit("technical.bin", None)
    scan = scanner.Scanner()
    scan.scan_git(repository, baseline + "..HEAD")
    assert scan.findings == []


def test_binary_replaced_by_directory_is_a_deletion(scanner, history):
    repository, _, commit, _ = history
    baseline = commit("technical.bin", b"\x00" + technical_credentials()["github_token"].encode("ascii"))
    (repository / "technical.bin").unlink()
    commit("technical.bin/child.txt", b"technical clean replacement")
    scan = scanner.Scanner()
    scan.scan_git(repository, baseline + "..HEAD")
    assert scan.findings == []


def test_binary_history_uses_tree_archive_scanning(scanner, history):
    repository, baseline, commit, _ = history
    token = technical_credentials()["github_token"].encode("ascii")
    commit("technical.docx", technical_zip([("word/document.xml", token)]))
    scan = scanner.Scanner()
    scan.scan_git(repository, baseline + "..HEAD")
    assert scan.findings == [{"path": "technical.docx!word/document.xml",
                              "line": 1, "pattern": "github_token"}]


@pytest.mark.parametrize("limit, code", [
    ({"max_file_bytes": 2048}, "FILE_SIZE_LIMIT"),
    ({"max_total_bytes": 2048}, "TOTAL_SIZE_LIMIT"),
])
def test_binary_history_checks_size_before_reading_blob(scanner, history, monkeypatch, limit, code):
    repository, baseline, commit, _ = history
    commit("technical.bin", b"\x00" + b"T" * 4096)
    original = scanner.Scanner._git

    def git(repo, arguments):
        assert not ("cat-file" in arguments and "blob" in arguments), "oversize blob was read"
        return original(repo, arguments)

    monkeypatch.setattr(scanner.Scanner, "_git", staticmethod(git))
    with pytest.raises(scanner.ScanError, match="^" + code + "$"):
        scanner.Scanner(**limit).scan_git(repository, baseline + "..HEAD")


def test_unreadable_binary_blob_never_reports_clean(scanner, history, monkeypatch):
    repository, baseline, commit, _ = history
    commit("technical.bin", b"\x00technical")
    original = scanner.Scanner._git

    def git(repo, arguments):
        if "cat-file" in arguments:
            raise scanner.ScanError("GIT_DIFF_FAILED")
        return original(repo, arguments)

    monkeypatch.setattr(scanner.Scanner, "_git", staticmethod(git))
    with pytest.raises(scanner.ScanError, match="^GIT_DIFF_FAILED$"):
        scanner.Scanner().scan_git(repository, baseline + "..HEAD")


def test_mixed_text_binary_and_merge_history_keeps_both_checks(scanner, history):
    repository, baseline, commit, git = history
    git("checkout", "-qb", "technical-side")
    commit("technical.bin", b"\x00" + technical_credentials()["github_token"].encode("ascii"))
    git("checkout", "-qb", "technical-main", baseline)
    commit("technical.txt", technical_credentials()["aws_access_key"].encode("ascii"))
    git("merge", "--no-ff", "-qm", "technical merge", "technical-side")
    scan = scanner.Scanner()
    scan.scan_git(repository, baseline + "..HEAD")
    assert {hit["pattern"] for hit in scan.findings} == {"github_token", "aws_access_key"}
