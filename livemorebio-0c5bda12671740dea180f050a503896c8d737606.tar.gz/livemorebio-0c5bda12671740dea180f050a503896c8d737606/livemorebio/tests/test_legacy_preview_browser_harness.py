"""Offline harness contracts only: no browser, service, model or socket."""
from __future__ import annotations

import importlib
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from .test_clinical_model_availability_ui import node

ROOT = Path(__file__).parents[2]
SCRIPT = ROOT / "tools/check_legacy_preview_browser.cjs"


def harness():
    return importlib.import_module("tools.check_legacy_preview_browser")


def js(body):
    completion = "})().catch(e=>{console.error(e);process.exitCode=1});"
    if completion in body:
        body = "let complete=false;process.on('beforeExit',()=>a.equal(complete,true));\n" + body.replace(
            completion, "})().then(()=>{complete=true}).catch(e=>{console.error(e);process.exitCode=1});")
    node("const a=require('node:assert/strict');const h=require(" + json.dumps(str(SCRIPT)) + ");\n" + body)


def test_fixed_bounds_and_new_only_runtime():
    h = harness()
    assert h.PORTS == (8910, 8911, 8912)
    assert h.LIMITS == dict(startup_s=45, browser_s=180, action_s=10, held_s=2,
                           total_s=350, requests=256, posts=4, images=16, evidence_bytes=64 * 1024 * 1024)
    assert h.SERVICES == ("aegle.server", "life_system.service", "cendos.service")
    assert h.BROWSER_SCRIPT == SCRIPT


def test_safe_environment_has_no_inherited_secrets_or_shared_paths(tmp_path, monkeypatch):
    h = harness()
    seen = {}
    def prepare(root, *, inherited, base_port):
        seen.update(root=root, inherited=inherited, port=base_port)
        return root, {**inherited, "LIVEMORE_DATA_DIR": str(root)}
    monkeypatch.setattr(h, "prepare_review_environment", prepare)
    monkeypatch.setenv("UNRELATED_PRIVATE", "NEVER_COPY")
    root, env = h.prepare_environment(tmp_path)
    assert seen["port"] == 8910 and set(seen["inherited"]) <= {"PATH", "HOME", "TMPDIR", "LANG", "LC_ALL"}
    assert "UNRELATED_PRIVATE" not in env and "LIVEMORE_ANATOMY_DIR" not in env
    assert root.stat().st_mode & 0o777 == 0o700


@pytest.mark.parametrize("role", range(3))
def test_exact_private_service_launch_dispatch(role):
    h = harness()
    command = h.service_command(role)
    assert command[-2:] == ["--service-role", str(role)]
    assert command[1] == "-B" and command[2] == str(h.__file__)
    with pytest.raises(h.HarnessError):
        h.service_command(True)
    with pytest.raises(h.HarnessError):
        h.service_command(3)


def test_tripwire_installation_precedes_app_import_with_exact_owners():
    h = harness()
    modules = {}
    def owner(*a, **kw):
        raise AssertionError("old owner called")
    for module, target, member in h.TRIPWIRES:
        instance = modules.setdefault(module, SimpleNamespace())
        if member:
            if not hasattr(instance, target):
                setattr(instance, target, type(target, (), {}))
            setattr(getattr(instance, target), member, owner)
        else:
            setattr(instance, target, owner)
    receipt = h.install_tripwires(lambda name: modules[name])
    assert receipt["installed"] == len(h.TRIPWIRES)
    for module, target, member in h.TRIPWIRES:
        fn = getattr(modules[module], target)
        with pytest.raises(h.HarnessError, match="MODEL_EXECUTION_REFUSED"):
            (getattr(fn, member) if member else fn)()


def test_close_children_attempts_each_exact_handle_and_preserves_failure():
    h = harness()
    called = []
    class Child:
        def __init__(self, pid, broken=False): self.pid, self.broken = pid, broken
        def poll(self): return None
        def terminate(self): called.append((self.pid, "TERM"))
        def kill(self): called.append((self.pid, "KILL"))
        def wait(self, timeout):
            called.append((self.pid, timeout))
            if self.broken: raise OSError("PRIVATE")
            return 0
    rows = h.stop_children([Child(10, True), Child(20)])
    assert [x["pid"] for x in rows] == [20, 10]
    assert rows[0]["reaped"] is True and rows[1]["reaped"] is False
    assert (10, 10) in called and (10, 5) in called
    assert "PRIVATE" not in json.dumps(rows)


@pytest.mark.parametrize("source", ["", "x" * 64, "a" * 63, None])
def test_source_pin_invalid_before_launch(source):
    h = harness()
    with pytest.raises(h.HarnessError):
        h.validate_source(source)


def test_image_matrix_matches_plan_and_fixture_values_are_unit_literals():
    js("""
a.equal(h.IMAGES.length,16);a.equal(new Set(h.IMAGES).size,16);
a.equal(h.IMAGES.filter(x=>x.startsWith('mobile')).length,5);
for(const id of ['A','B','C']){const x=h.fixtureState(id);a(x.profile.includes('AUTHORED UI ONLY'));a.deepEqual(x.metabolic.glucose,[90,91]);a.deepEqual(x.cardiac.v,[-80,10]);a.equal(x.model_availability.selection_mode,'reference_preview');}
const x=h.fixtureState('A');x.metabolic.glucose[0]=7;a.equal(h.fixtureState('A').metabolic.glucose[0],90);
a.throws(()=>h.fixtureState('real-person'));
""")


@pytest.mark.parametrize("url,method", [
    ("http://127.0.0.1:8850/api/state", "GET"), ("https://example.org/api/state", "GET"),
    ("http://127.0.0.1:8910/api/stimulate", "DELETE"), ("http://127.0.0.1:8910/assets/anatomy/skin.glb", "GET"),
    ("http://127.0.0.1:8910/api/state?secret=PRIVATE", "GET"), ("http://127.0.0.1:8910/api/executions", "POST"),
    ("http://127.0.0.1:8911/population", "GET"), ("http://127.0.0.1:8910/", "GET"),
])
def test_strict_request_allowlist(url, method):
    js(f"a.throws(()=>h.classifyRequest({json.dumps(url)},{json.dumps(method)}),e=>e.message==='UNEXPECTED_REQUEST');")


def test_auth_and_static_reads_are_never_fixtureable():
    js("""
for(const path of ['/api/session/bootstrap','/api/build','/api/services','/lib/auth.js','/legacy'])a.equal(h.classifyRequest('http://127.0.0.1:8910'+path,'GET').kind,'ACTUAL');
const s=h.createSchedule();a.throws(()=>s.enable({}));a.throws(()=>s.nextPost('/api/stimulate','{}'));
a.equal(s.snapshot().posts,0);a.equal(s.snapshot().actualMutations,0);
""")


def test_exact_four_post_schedule_and_wrong_body_fail_before_count():
    js("""
const s=h.createSchedule();s.enable(h.modelessState());
a.throws(()=>s.nextPost('/api/ingest_note',JSON.stringify({text:'PRIVATE'})));a.equal(s.snapshot().posts,0);
s.arm('healthy');let p=s.nextPost('/api/stimulate',JSON.stringify({kind:'base',params:{base:'healthy'}}));a.equal(p.status,200);a.equal(p.payload.model_availability.source_generation,'ui-fixture-B');a.equal(s.nextState().hold,true);
s.arm('carrier');a.throws(()=>s.nextPost('/api/stimulate',JSON.stringify({kind:'base',params:{base:'healthy'}})));a.equal(s.snapshot().posts,1);
p=s.nextPost('/api/stimulate',JSON.stringify({kind:'life_system',params:{mode:'carrier'}}));a.equal(p.status,503);a.equal(p.payload.code,'SELECTION_COMMITTED_CLEANUP_UNCONFIRMED');a.equal(s.nextState().payload.profile,h.fixtureState('C').profile);
s.arm('lost');p=s.nextPost('/api/ingest_note',JSON.stringify({text:h.NOTE}));a.equal(p.abort,true);a.equal(s.nextState().status,503);
s.arm('unknown');p=s.nextPost('/api/ingest_note',JSON.stringify({text:h.NOTE}));a.equal(p.payload.code,'SELECTION_COMMIT_UNCONFIRMED');a.equal(s.nextState().status,503);
a.equal(s.snapshot().posts,4);a.throws(()=>s.arm('healthy'));a.equal(s.snapshot().actualMutations,0);
""")


def test_held_read_cannot_extend_or_succeed_after_deadline():
    js("""
(async()=>{let clock=0,cleared=0,expired;const timers={now:()=>clock,set:(fn,ms)=>{a.equal(ms,2000);expired=fn;return 9},clear:()=>cleared++};
const hld=h.createHold(timers);clock=2001;a.throws(()=>hld.release(),e=>e.message==='HELD_READ_TIMEOUT');await a.rejects(hld.promise);a.equal(cleared,1);
const second=h.createHold({...timers,now:()=>0});expired();await a.rejects(second.promise);a.throws(()=>second.release());
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_each_resource_close_is_bounded_and_error_text_redacted():
    js("""
(async()=>{const calls=[];const rows=await h.closeOwned([
{name:'page',resource:{close:async()=>{calls.push('page');throw Error('PRIVATE')}}},
{name:'context',resource:{close:async()=>calls.push('context')}},
{name:'browser',resource:{close:async()=>calls.push('browser')}}]);
a.deepEqual(calls,['page','context','browser']);a.equal(rows[0].status,'UNCONFIRMED');a.equal(rows[1].status,'SETTLED');a(!JSON.stringify(rows).includes('PRIVATE'));
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_source_fixture_and_delivery_receipt_cannot_claim_visual_or_biology_pass():
    js("""
const r=h.newReceipt();a.equal(r.visible_ui,'REQUIRES_INDEPENDENT_REVIEW');a.equal(r.biological_evidence,false);a.equal(r.actual_mutations,0);
a.throws(()=>h.checkComplete(r));r.posts=4;r.images=h.IMAGES.map(name=>({name}));r.completed=['D0','D1','D2','D3','D4','M1','M2'];r.cleanup=[{name:'browser',status:'UNCONFIRMED'}];a.throws(()=>h.checkComplete(r));
""")


def test_offline_import_has_no_playwright_or_service_launch():
    js("a(!Object.keys(require.cache).some(x=>x.includes('/playwright/')));a.equal(h.POST_LIMIT,4);")
    h = harness()
    assert h.BROWSER_SCRIPT == SCRIPT


def test_actual_default_navigation_queries_and_genome_unavailable_fixture():
    source = (ROOT / 'livemorebio/aegle/console/lib/subjects.js').read_text(encoding="utf-8")
    assert "pageSize=10" in source
    js("""
a.equal(h.classifyRequest('http://127.0.0.1:8910/api/twins?limit=10','GET').kind,'SCHEDULED');
a.throws(()=>h.classifyRequest('http://127.0.0.1:8910/api/twins?limit=25','GET'));
a.equal(h.GENOME.models[0].status.available,false);a.equal(h.GENOME.models[0].execution.available,false);
a(h.GENOME.models[0].status.reason.includes('AUTHORED UI ONLY'));
""")


def test_second_context_actual_baseline_observed_without_resetting_post_order():
    js("""
const s=h.createSchedule();s.enable(h.modelessState());s.setRead('ACTUAL');
a.equal(s.acceptsActualBaseline(),true);a.equal(s.nextState(),null);
s.enable(h.modelessState());s.setRead('A');a.equal(s.acceptsActualBaseline(),false);
""")


def test_complete_requires_both_actual_auth_contexts_and_modeless_reads():
    from .test_legacy_current_feedback_browser_harness import feedback_rows
    js("""
const r=h.newReceipt();Object.assign(r,{posts:4,images:h.IMAGES.map(name=>({name})),completed:['D0','D1','D2','D3','D4','M1','M2'],cleanup:[{name:'browser',status:'SETTLED'}]});
r.cases.forEach(x=>x.status='PASS');r.followup_gets=[1,1,1,1];r.genome_fixture_reads=1;
r.banner_checks=BANNER_ROWS;
r.feedback_checks=FEEDBACK_ROWS;
for(const [i,j] of [[4,2],[11,4]]){const row=r.feedback_checks[j];Object.assign(r.images[i],{feedback_id:row.id,viewport:row.snapshot.viewport,scroll:row.snapshot.scroll,box:row.snapshot.labels[0].box});}
a.throws(()=>h.checkComplete(r));r.auth_bootstraps=2;r.actual_state_reads=2;r.cookie_checks=[{context:1,http_only:true},{context:2,http_only:true}];
h.checkComplete(r);r.cookie_checks[1].http_only=false;a.throws(()=>h.checkComplete(r));
r.cookie_checks[1].http_only=true;delete r.auth_bootstraps;a.throws(()=>h.checkComplete(r));
""".replace('BANNER_ROWS',json.dumps(_banner_rows())).replace('FEEDBACK_ROWS',json.dumps(feedback_rows())))


def test_trusted_static_import_closure_contains_no_graphics_vendor():
    # Execution anatomy imports its loader, but no selected execution may invoke it.
    import re
    console = ROOT / 'livemorebio/aegle/console'
    names = set()
    for name in ['index.html','twins.html','patch.html','cendos.html']:
        names.update(re.findall(r'(?:src|href)=["\'](/lib/[^"\']+)["\']', (console / name).read_text(encoding="utf-8")))
        names.update(re.findall(r'from ["\'](/lib/[^"\']+)["\']', (console / name).read_text(encoding="utf-8")))
    todo=list(names)
    while todo:
        current=todo.pop()
        for child in re.findall(r'^import .*?from ["\']([^"\']+)["\']', (console / current.removeprefix('/')).read_text(encoding="utf-8"), re.M):
            target=child if child.startswith('/lib/') else '/lib/'+child.removeprefix('./')
            if target not in names: names.add(target);todo.append(target)
    js('for(const item of '+json.dumps(sorted(names))+')a(h.STATIC.includes(item),item);a(!h.STATIC.some(x=>x.includes("vendor")||x.endsWith("/anatomy.js")));')


def test_close_timeout_attempts_later_resources_and_clears_timer():
    js("""
(async()=>{const oldSet=setTimeout,oldClear=clearTimeout;let pending,clears=0;global.setTimeout=(fn,ms)=>{a.equal(ms,3000);pending=fn;return 9};global.clearTimeout=()=>clears++;
const closing=h.closeOwned([{name:'page',resource:{close:()=>new Promise(()=>{})}},{name:'browser',resource:{close:async()=>{}}}]);
pending();const rows=await closing;global.setTimeout=oldSet;global.clearTimeout=oldClear;
a.equal(rows[0].status,'UNCONFIRMED');a.equal(rows[1].status,'SETTLED');a.equal(clears,2);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


MOUNTED = r"""
const Module=require('node:module'),fs=require('node:fs'),load0=Module._load,write0=fs.writeFileSync;
const set0=setTimeout,clear0=clearTimeout;let finalReceipt,routeHandler,postCount=0,genomeCount=0,activeURL='http://127.0.0.1:8910/legacy';
const events={},calls=[],files=new Map(),pending=[];let globalTimeout,healthCalls=0,currentViewport;
const mode=MODE,config={out:'/authored-only',source:'a'.repeat(64),pins:{browser:'b'.repeat(64)},services:{},fixture:{twin_id:'technical-ui-only',version:2}};
for(const name of ['Aegle','LIFE','Cendos'])config.services[name]={schema:'livemore.build-identity.v1',source_sha256:config.source,process_instance:name,started_at:'fixed'};
fs.writeFileSync=(file,data)=>{files.set(file,Buffer.from(data));if(file.endsWith('browser-result.json'))finalReceipt=JSON.parse(data)};
global.setTimeout=(fn,ms)=>{if(ms>=150000){globalTimeout=fn;return set0(fn,200)}return set0(fn,ms===10000?30:ms===3000?50:ms===2000?100:ms)};
function nativeError(name){const e=Error('PRIVATE diagnostic /private/path');e.name=name;return e}
function emit(request,status,payload){const url=request.url();const response={request:()=>request,url:()=>url,status:()=>status,body:()=>{
 calls.push('body:'+url.split('/').pop());
 if(url.endsWith('/api/state')){if(mode==='body_hang')return new Promise(()=>{});if(mode.startsWith('body_error_'))return Promise.reject(nativeError(mode.slice(11)));
 if(mode==='invalid_json')return Promise.resolve(Buffer.from('PRIVATE invalid JSON'));
 if(mode==='invalid_modeless')payload={...payload,profile:'PRIVATE authored invalid admission'};}
 return Promise.resolve(Buffer.from(JSON.stringify(payload)))}};events.response?.(response)}
async function request(target,method='GET',body){const url='http://127.0.0.1:8910'+target;let fulfilled;
 const original={url:()=>url,method:()=>method,postData:()=>body===undefined?null:JSON.stringify(body),frame:()=>({url:()=>activeURL})};
 await routeHandler({request:()=>original,
 continue:async()=>{emit(original,target==='/api/session/bootstrap'?(mode==='bootstrap200'?200:204):mode==='state503'?503:200,h.modelessState())},
 fulfill:async x=>{fulfilled=x;emit(original,x.status,JSON.parse(x.body))},abort:async()=>{}});return fulfilled;
}
function background(promise){pending.push(promise);promise.catch(()=>{})}
async function preview(body){postCount++;await request(body.text?'/api/ingest_note':'/api/stimulate','POST',body);background(request('/api/state').then(()=>mode==='duplicate_follow'?request('/api/state'):null))}
const locator=selector=>({
 scrollIntoViewIfNeeded:async()=>{},evaluate:async fn=>String(fn).includes('getBoundingClientRect')?{viewport:{width:1440,height:1000},scroll:{x:0,y:0},box:{x:0,y:0,width:20,height:20},visible:true,unoccluded:true,horizontal_overflow:false}:true,
 filter:()=>locator(selector),waitFor:async()=>{},count:async()=>0,isDisabled:async()=>selector==='#legacy-run-experiment',fill:async()=>{},focus:async()=>{},
 click:async()=>{calls.push('click:'+selector);
 if(selector==='#legacy-preview-refresh')await request('/api/state');
 else if(selector==='#baseSeg [data-b="healthy"]')await preview({kind:'base',params:{base:'healthy'}});
 else if(selector==='#patQuick button')await preview({kind:'life_system',params:{mode:'carrier'}});
 else if(selector.includes('href="/twins"')){activeURL='http://127.0.0.1:8910/twins';await request('/api/twins?limit=10')}
 else if(selector.includes('href="/patch"'))activeURL='http://127.0.0.1:8910/patch';
 else if(selector.includes('href="/cendos"')){activeURL='http://127.0.0.1:8910/cendos';await request('/api/genome-models');genomeCount++;if(mode==='duplicate_genome'){await request('/api/genome-models');genomeCount++}await request('/api/state')}
 }});
const page={isClosed:()=>false,context:()=>context,viewportSize:()=>currentViewport,close:async()=>calls.push('page-close'),setDefaultTimeout(){},setDefaultNavigationTimeout(){},exposeBinding:async()=>{},addInitScript:async()=>{},on:(name,fn)=>events[name]=fn,
 goto:async url=>{calls.push('goto');activeURL=url;
 if(mode.startsWith('nav_error_')||mode.startsWith('capture_')){set0(()=>events.pageerror?.(nativeError('PRIVATE_LATER')),1);throw nativeError(mode.startsWith('nav_error_')?mode.slice(10):'Error')}
 await request('/api/session/bootstrap');await request('/api/state')},
 goBack:async()=>{activeURL='http://127.0.0.1:8910/legacy';await request('/api/state')},
 locator,waitForFunction:async()=>{},evaluate:async()=>mode==='evaluate_hang'?new Promise(()=>{}):{metrics:true,note:true,numerical:true,canvases:true,heart:true,metabolic:true},
 screenshot:async options=>{calls.push('screenshot:'+options.timeout);if(mode==='capture_timeout')return new Promise(()=>{});if(mode==='capture_large')return Buffer.alloc(4*1024*1024+1);if(mode==='capture_error')throw nativeError('PRIVATE_CAPTURE');return Buffer.from('authored-image')},keyboard:{press:async key=>{if(key==='Enter')await preview({text:h.NOTE})}}};
const context={browser:()=>browser,close:async()=>{calls.push('context-close');if(mode==='desktop_close_failure')throw Error('PRIVATE')},route:async(_pattern,fn)=>routeHandler=fn,cookies:async()=>mode==='cookies_hang'?new Promise(()=>{}):[{httpOnly:true,domain:'127.0.0.1'}],
 request:{get:async url=>{healthCalls++;const i=Number(new URL(url).port)-8910,name=['Aegle','LIFE','Cendos'][i];return{status:()=>mode==='desktop_health_failure'&&healthCalls===4?503:200,body:async()=>Buffer.from(JSON.stringify({ok:true,service:name,build:config.services[name]}))}}},
 newPage:()=>{calls.push('new-page');return mode==='late_page'?new Promise(resolve=>{set0(()=>globalTimeout(),0);set0(()=>resolve(page),15)}):Promise.resolve(page)}};
const browser={isConnected:()=>mode!=='capture_disconnected',close:async()=>calls.push('browser-close'),newContext:options=>{currentViewport=options.viewport;calls.push('new-context');return mode==='never_context'?new Promise(()=>{}):mode==='late_context'?new Promise(resolve=>{set0(()=>globalTimeout(),0);set0(()=>resolve(context),15)}):Promise.resolve(context)}};
Module._load=function(name,...rest){if(name===(process.env.LIVEMORE_PLAYWRIGHT_MODULE||'/nonexistent/livemore/playwright/index.js'))return{chromium:{launch:()=>mode==='late_launch'?new Promise(resolve=>{set0(()=>globalTimeout(),0);set0(()=>resolve(browser),15)}):Promise.resolve(browser)}};return load0.call(this,name,...rest)};
"""

BANNER_MOUNTED = r"""
// Standard authored DOM additions for the new checks, not a browser layout pass.
const vmBanner=require('node:vm'),oldLocator=page.locator,oldEvaluate=page.evaluate,oldPress=page.keyboard.press,oldRequest=request;
let bannerKind='info',bannerHidden=false,bannerText='Model unavailable. No previous subject physiology is shown.',focused='',feedbackMode='unavailable',feedbackScroll=0;
const bannerButton={disabled:false},bannerNode={get hidden(){return bannerHidden},get textContent(){return bannerText},
 get dataset(){return{kind:bannerKind}},getAttribute:k=>({'role':bannerKind==='err'?'alert':'status','aria-live':bannerKind==='err'?'assertive':'polite','aria-atomic':'true'}[k]),
 getBoundingClientRect:()=>bannerHidden?box(0,0,0,0):box(0,mode==='banner_overlap'?10:180,currentViewport.width,80)};
function box(x,y,width,height){return{x,y,width,height,right:x+width,bottom:y+height}}
const navLink={getBoundingClientRect:()=>box(10,10,100,40),contains:x=>x===navLink};
const navNode={getBoundingClientRect:()=>box(0,0,currentViewport.width,64),querySelectorAll:()=>[navLink],contains:x=>x===navLink||x===navNode};
const bannerDocument={get activeElement(){return focused==='#legacy-run-experiment'?bannerButton:null},
 documentElement:{get scrollWidth(){return currentViewport.width}},
 querySelector:s=>s==='.lmb-nav'?navNode:s==='#legacy-run-experiment'?bannerButton:s==='#__banner'?(mode==='banner_replaced'&&postCount>=1&&feedbackMode==='computed'?{}:bannerNode):null,
 querySelectorAll:s=>s==='#__banner'?[bannerNode]:[],elementFromPoint:(_x,y)=>y<64?navLink:bannerNode};
function evaluateBanner(fn,arg){return vmBanner.runInNewContext('('+fn.toString()+')(banner,arg)',{
 banner:bannerNode,arg,document:bannerDocument,innerWidth:currentViewport.width,innerHeight:currentViewport.height,scrollX:0,scrollY:0,
 getComputedStyle:()=>({position:'static',overflowWrap:'anywhere',display:bannerHidden?'none':'block'})})}
page.locator=selector=>{const old=oldLocator(selector);return{...old,elementHandle:async()=>({evaluate:async(fn,arg)=>evaluateBanner(fn,arg)}),
 focus:async()=>{focused=selector;await old.focus()},
 evaluate:async(fn,arg)=>selector==='#legacy-run-experiment'?focused===selector:selector==='.lmb-nav'&&!String(fn).includes('getBoundingClientRect')?undefined:old.evaluate(fn,arg)}};
page.evaluate=async(fn,arg)=>String(fn).includes('#pClass')?mode!=='banner_wrong_input':oldEvaluate(fn,arg);
request=async(...args)=>{if(args[1]==='POST'){feedbackMode='pending';bannerHidden=true;bannerText='';}
 const result=await oldRequest(...args);if(args[0]==='/api/state'){
 if(!result||result.status===200){const x=result?JSON.parse(result.body):h.modelessState();bannerHidden=x.model_availability.state==='READY';bannerKind='info';bannerText=bannerHidden?'':'Model unavailable. No previous subject physiology is shown.';feedbackMode=bannerHidden?'computed':'unavailable';}
 else{feedbackMode='unavailable';bannerHidden=true;bannerText='';}}
 return result};
page.keyboard.press=async key=>{if(key==='Enter'&&focused==='#legacy-run-experiment'){
 calls.push('banner-enter');if(mode==='banner_post'){await request('/api/stimulate','POST',{unauthorized:true});return}
 bannerHidden=false;bannerKind='err';bannerText='enter a compound in the search box';if(mode==='banner_focus')focused='';return}
 if(key==='Tab')focused='note-button';return oldPress(key)};
"""

FEEDBACK_MOUNTED = r"""
// The real serialized helper runs against standard, fixed authored DOM nodes.
const feedbackNames=['legacy-cardiac-state','legacy-cardiac-provenance','legacy-cardiac-time'];
const feedbackCopies={computed:['Calculated response','computed','calculated beat · milliseconds'],pending:['Update pending','pending','update pending'],unavailable:['No current trace','unavailable','no current trace']};
const feedbackTitles={computed:'Calculated cardiac trace from the current model state. This is not a physical observation or continuous acquisition.',pending:'A numerical update is pending; no new response is confirmed.',unavailable:'No current numerical cardiac trace.'};
const heading={getBoundingClientRect:()=>({...box(20,200,300,40),top:200})};
const feedbackLabels=feedbackNames.map((id,i)=>({id,get textContent(){return feedbackCopies[feedbackMode][i]},
 get className(){return feedbackMode==='computed'?'prov prov-engine':'prov'},get title(){return feedbackTitles[feedbackMode]},
 getBoundingClientRect:()=>box(20,100+i*80,200,24),getClientRects(){return[this.getBoundingClientRect()]},
 contains:x=>x===feedbackLabels[i],closest:()=>heading}));
const feedbackDocument={...bannerDocument,
 getElementById:id=>feedbackNames.includes(id)?feedbackLabels[feedbackNames.indexOf(id)]:
  id==='legacy-run-experiment'?{disabled:true}:id==='o-cardiac'?{getAttribute:()=> 'translate(105,104)'}:
  id==='o-metabolic'?{getAttribute:()=> '#728b88'}:['cell','trace','metab'].includes(id)?{width:1,height:1,getContext:()=>({getImageData:()=>({data:[0,0,0,0]})})}:{textContent:''},
 elementFromPoint:(_x,y)=>mode==='feedback_cardiac_hit'?{}:feedbackLabels.find(x=>{const b=x.getBoundingClientRect();return y>=b.y&&y<=b.bottom})};
function feedbackContext(){return{document:feedbackDocument,innerWidth:currentViewport.width,innerHeight:currentViewport.height,scrollX:0,scrollY:feedbackScroll,
 window:{scrollTo:options=>{a.equal(options.behavior,'instant');a.equal(options.left,0);feedbackScroll=options.top;calls.push('feedback-scroll')}},
 getComputedStyle:()=>({display:bannerHidden?'none':'block'}),requestAnimationFrame:fn=>fn()}}
const bannerEvaluate0=evaluateBanner,feedbackEvaluate0=page.evaluate;
evaluateBanner=function(fn,arg){if(fn!==h.readFeedbackSnapshot)return bannerEvaluate0(fn,arg);
 if(mode==='evaluate_hang'&&arg.clear)return new Promise(()=>{});
 const b=mode==='feedback_pending_stale'&&feedbackMode==='pending'?{...bannerNode,textContent:'PRIVATE_SENTINEL'}:bannerNode;
 return vmBanner.runInNewContext('('+fn.toString()+')(b,options)',{...feedbackContext(),b,options:arg})};
page.evaluate=async(fn,arg)=>fn===h.scrollFeedbackHeading?vmBanner.runInNewContext('('+fn.toString()+')()',feedbackContext()):feedbackEvaluate0(fn,arg);
"""


def mounted(mode, checks):
    js(MOUNTED.replace('MODE', json.dumps(mode)) + BANNER_MOUNTED + FEEDBACK_MOUNTED + "\n(async()=>{const status=await h.run(config);await new Promise(r=>set0(r,25));" + checks + r"""
Module._load=load0;fs.writeFileSync=write0;global.setTimeout=set0;global.clearTimeout=clear0;
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_mounted_actual_bootstrap204_and_exact_case_ledger():
    mounted('normal', "a.equal(status,0);a.equal(finalReceipt.cases.length,7);a(finalReceipt.cases.every(x=>x.status==='PASS'));a.deepEqual(finalReceipt.followup_gets,[1,1,1,1]);a.equal(finalReceipt.genome_fixture_reads,1);" +
        "a.equal(finalReceipt.first_failure,null);a.equal(finalReceipt.failure_images.length,0);a.equal(finalReceipt.failure_capture.status,'NOT_NEEDED');a(Object.values(finalReceipt.d0_checks).every(x=>x===true));" +
        "const states=finalReceipt.requests.filter(x=>x.category==='/api/state');a.equal(states.filter(x=>x.modeless_admitted===true).length,2);a(states.filter(x=>x.delivery==='FIXTURE').every(x=>x.modeless_admitted===null));")


def test_mounted_bootstrap200_rejected_before_first_case_pass():
    mounted('bootstrap200', "a.equal(status,1);a.equal(finalReceipt.cases[0].status,'FAIL');a(finalReceipt.cases.slice(1).every(x=>x.status==='NOT_RUN'));a.equal(finalReceipt.images.length,0);a.equal(finalReceipt.failed_stage,'D0');")


@pytest.mark.parametrize('mode', ['late_context','late_page'])
def test_mounted_late_allocation_closed_without_following_actions(mode):
    mounted(mode, "a.equal(status,1);a.equal(calls.filter(x=>x.startsWith('click:')||x==='goto').length,0);a(calls.includes('context-close'));" +
            ("a(!calls.includes('new-page'));" if mode=='late_context' else "a(calls.includes('page-close'));") +
            "a.equal(finalReceipt.cases[0].status,'FAIL');")


def test_mounted_late_browser_launch_closed_without_context_allocation():
    mounted('late_launch', "a.equal(status,1);a(calls.includes('browser-close'));a(!calls.includes('new-context'));a.equal(finalReceipt.cases[0].status,'FAIL');")


def test_mounted_unsettled_allocation_retains_unconfirmed_cleanup():
    mounted('never_context', "a.equal(status,1);a.equal(finalReceipt.primary_failure,'ACTION_TIMEOUT');a(finalReceipt.cleanup.some(x=>x.name==='allocation-drain'&&x.status==='UNCONFIRMED'));a(calls.includes('browser-close'));a(!calls.includes('new-page'));")


@pytest.mark.parametrize('mode', ['desktop_close_failure','desktop_health_failure'])
def test_mounted_desktop_final_checks_fail_d4_not_unstarted_mobile(mode):
    mounted(mode, "a.equal(status,1);a.equal(finalReceipt.failed_stage,'D4');a.equal(finalReceipt.cases[4].status,'FAIL');a(finalReceipt.cases.slice(5).every(x=>x.status==='NOT_RUN'));a.equal(calls.filter(x=>x==='new-context').length,1);")


@pytest.mark.parametrize('mode', ['cookies_hang','body_hang','evaluate_hang'])
def test_mounted_action_bound_does_not_wait_for_global_deadline(mode):
    mounted(mode, "a.equal(status,1);a.equal(finalReceipt.primary_failure,'ACTION_TIMEOUT');a(finalReceipt.cases.some(x=>x.status==='FAIL'));a.equal(postCount," + ('1' if mode=='evaluate_hang' else '0') + ");")


@pytest.mark.parametrize('mode', ['duplicate_follow','duplicate_genome'])
def test_mounted_duplicate_fixture_read_stops_fixed_run(mode):
    mounted(mode, "a.equal(status,1);a.equal(finalReceipt.primary_failure," + json.dumps('FOLLOWUP_GET_COUNT' if mode=='duplicate_follow' else 'GENOME_QUERY_NOT_AUTHORIZED') + ");a(finalReceipt.cases.some(x=>x.status==='FAIL'));a(finalReceipt.cases.some(x=>x.status==='NOT_RUN'));")


def _banner_rows():
    rows=[]
    for i,(name,kind) in enumerate([('desktop-info','info'),('desktop-error','err'),('desktop-cleared','hidden'),('mobile-error','err'),('mobile-info','info')]):
        width,height=(390,844) if name.startswith('mobile') else (1440,1000)
        snapshot={k:True for k in ['singleton','same_node','text_matches','kind_matches','role_matches','live_matches','atomic','static','wrap','display_matches','banner_hit']}
        snapshot.update(hidden=kind=='hidden',horizontal_overflow=False,viewport={'width':width,'height':height},scroll={'x':0,'y':0},
            nav={'x':0,'y':0,'width':width,'height':64},box={'x':0,'y':180,'width':width,'height':80},links=[{'index':0,'visible':True,'hit':True}])
        row={'id':name,'kind':kind,'snapshot':snapshot}
        if kind=='err':row.update(ready_hidden=True,precondition=True,focus_retained=True,posts_before=0 if i==1 else 3,
            posts_after=0 if i==1 else 3,request_posts_before=0 if i==1 else 3,request_posts_after=0 if i==1 else 3)
        rows.append(row)
    return rows


def _authored_browser_receipt(h, root):
    from .test_legacy_current_feedback_browser_harness import feedback_rows
    import hashlib
    import struct
    names = ['desktop-modeless','desktop-error','desktop-pending','desktop-later-winner','desktop-cardiac','desktop-cleanup',
        'desktop-note-before','desktop-unknown','desktop-twins-recovery','desktop-life-inspection','desktop-history',
        'mobile-cardiac','mobile-error','mobile-note-before','mobile-unknown','mobile-refreshed']
    images=[]
    for name in names:
        width,height=(390,844) if name.startswith('mobile') else (1440,1000)
        raw=b'\x89PNG\r\n\x1a\n'+b'\x00\x00\x00\rIHDR'+struct.pack('>II',width,height)
        (root/(name+'.png')).write_bytes(raw);(root/(name+'.png')).chmod(0o600)
        images.append({'name':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
            'viewport':{'width':width,'height':height},'visible':True,'unoccluded':True,'horizontal_overflow':False})
        if name.endswith('-cardiac'):
            row=feedback_rows()[2 if name.startswith('desktop') else 4]
            images[-1].update(feedback_id=row['id'],scroll=row['snapshot']['scroll'],box=row['snapshot']['labels'][0]['box'])
    return {'schema':'livemore.legacy-preview-browser-result.v1','source':'a'*64,'pins':{'browser':'b'*64},
        'services':{},'delivery':'PASS','visible_ui':'REQUIRES_INDEPENDENT_REVIEW','biological_evidence':False,
        'primary_failure':None,'posts':4,'actual_mutations':0,'followup_gets':[1]*4,'genome_fixture_reads':1,
        'cases':[{'id':name,'status':'PASS','failure_code':None} for name in ['D0','D1','D2','D3','D4','M1','M2']],
        'images':images,'banner_checks':_banner_rows(),'feedback_checks':feedback_rows(),'cleanup':[{'name':name,'status':'SETTLED'} for name in ['page-1','context-1','page-2','context-2','browser']],
        'auth_bootstraps':2,'actual_state_reads':2,'cookie_checks':[{'context':i,'http_only':True} for i in [1,2]],
        'fixture_sha256':'05b3fac47c16391d1d210865aca3f60e262ea54b3d5408ee4f6a88c17fc0acf3'}


@pytest.mark.parametrize('damage', ['none','absent','nonzero','duplicate_key','symlink','source','case','post','follow','genome','cleanup','image_hash','image_absent','image_link','image_width'])
def test_parent_admits_original_receipt_and_every_exact_image(tmp_path, damage):
    h=harness();receipt=_authored_browser_receipt(h,tmp_path)
    if damage=='source':receipt['source']='c'*64
    if damage=='case':receipt['cases'][0]['status']='NOT_RUN'
    if damage=='post':receipt['actual_mutations']=1
    if damage=='follow':receipt['followup_gets']=[2,1,1,1]
    if damage=='genome':receipt['genome_fixture_reads']=2
    if damage=='cleanup':receipt['cleanup'][0]['status']='UNCONFIRMED'
    if damage=='image_hash':receipt['images'][0]['sha256']='d'*64
    if damage=='image_width':receipt['images'][0]['viewport']['width']=42
    file=tmp_path/'browser-result.json';file.write_text(json.dumps(receipt), encoding="utf-8");file.chmod(0o600)
    if damage=='duplicate_key':file.write_text('{"source":"x",'+json.dumps(receipt)[1:], encoding="utf-8")
    if damage=='absent':file.unlink()
    if damage=='symlink':file.rename(tmp_path/'real.json');file.symlink_to(tmp_path/'real.json')
    image=tmp_path/'desktop-modeless.png'
    if damage=='image_absent':image.unlink()
    if damage=='image_link':image.rename(tmp_path/'real.png');image.symlink_to(tmp_path/'real.png')
    if damage=='none':
        result=h.admit_browser_result(tmp_path,source='a'*64,pins={'browser':'b'*64},services={},exit_code=0)
        assert result['images_verified']==16
    else:
        with pytest.raises(h.HarnessError):
            h.admit_browser_result(tmp_path,source='a'*64,pins={'browser':'b'*64},services={},exit_code=1 if damage=='nonzero' else 0)


@pytest.mark.parametrize('case,expected', [('valid',None),('missing','BROWSER_EVIDENCE_INVALID'),
    ('forged','BROWSER_EVIDENCE_INVALID'),('nonzero','BROWSER_CHECK_FAILED'),('drift','HARNESS_IDENTITY'),('chrome_drift','HARNESS_IDENTITY'),
    *[(name,'SERVICE_OR_TRIPWIRE_FAILED') for name in ['service_present','service_absent','service_invalid','service_late','shutdown_failure']]])
def test_mounted_parent_main_requires_original_browser_evidence(tmp_path, monkeypatch, case, expected):
    """Real parent control flow; no Popen, socket, service or fixture constructor runs."""
    h=harness();root=tmp_path/'owned';root.mkdir(mode=0o700)
    build=importlib.import_module('livemorebio.build_info')
    monkeypatch.setattr(build,'source_fingerprint',lambda _:'a'*64)
    monkeypatch.setattr(h,'free_ports',lambda:None)
    monkeypatch.setattr(h,'prepare_environment',lambda _:(root,{'PATH':'/authored-only'}))
    monkeypatch.setattr(h,'prepare_fixture',lambda _:{'twin_id':'technical-ui-only','version':2})
    monkeypatch.setattr(h,'health',lambda port:port)
    monkeypatch.setattr(h,'require_health',lambda _port,name,*_:{'service':name,'source':'a'*64})
    monkeypatch.setattr(h,'process_snapshot',lambda:{})
    monkeypatch.setattr(h,'descendant_identities',lambda *_:[])
    monkeypatch.setattr(h,'remaining_descendants',lambda *_:[])
    monkeypatch.setattr(h,'record_listener_inspection',lambda report:report.update(listener_status='NO_LISTENERS'))
    monkeypatch.setattr(h.signal,'signal',lambda *_:None)
    monkeypatch.setattr(h.signal,'setitimer',lambda *_:None)
    launched=[];finished=False
    monkeypatch.setattr(h,'digest',lambda path:'c'*64 if finished and (
        case=='drift' and path==h.BROWSER_SCRIPT or case=='chrome_drift' and path==h.CHROME) else 'b'*64)
    class Child:
        def __init__(self, command, **_):
            self.pid=100+len(launched);self.browser=command[0]==h._NODE;self.closed=False
            launched.append(self)
            if case in {'service_present','service_invalid'} and self.pid==100:
                record={'schema':'livemore.legacy-preview-service-failure.v1','role':0,'stage':'HOOK_REGISTRATION',
                    'outcome':'FAILED','error_class':'AttributeError','exit_code':None}
                if case=='service_invalid':record['error_class']='PRIVATE_Clinical_Label'
                h.write_private(root/'service-0-failure.json',record)
        def poll(self):return 1 if case.startswith('service_') and self.pid==100 else None
        def terminate(self):self.closed=True
        def wait(self, timeout):
            nonlocal finished
            if case in {'service_late','shutdown_failure'} and self.pid==100:
                h.write_private(root/'service-0-failure.json',{'schema':'livemore.legacy-preview-service-failure.v1',
                    'role':0,'stage':'SERVER_RUN','outcome':'FAILED','error_class':'SystemExit','exit_code':3})
            if self.browser and not finished:
                finished=True
                if case not in {'missing','nonzero'}:
                    record=_authored_browser_receipt(h,root)
                    config=json.loads((root/'browser-config.json').read_text(encoding="utf-8"))
                    record.update(pins=config['pins'],services=config['services'])
                    if case=='forged':record['cases'][-1]['status']='NOT_RUN'
                    h.write_private(root/'browser-result.json',record)
            return 1 if self.browser and case=='nonzero' else 0
    monkeypatch.setattr(h.subprocess,'Popen',Child)
    code=h.main(['--expected-source','a'*64,'--output-parent',str(tmp_path)])
    report=json.loads((root/'supervision.json').read_text(encoding="utf-8"))
    assert code==int(expected is not None) and report['primary_failure']==expected
    if case.startswith('service_'):
        assert len(launched)==3 and all(x.closed for x in launched[1:])
        assert [x['exit_code'] for x in report['service_exits_before_cleanup']]==[1,None,None]
        before,after=report['service_failures_before_cleanup'],report['service_failures_after_cleanup']
        assert len(before)==len(after)==3
        assert before[0]['state']=={'service_present':'PRESENT','service_invalid':'INVALID'}.get(case,'ABSENT')
        assert after[0]['state']=={'service_present':'PRESENT','service_invalid':'INVALID','service_late':'PRESENT'}.get(case,'ABSENT')
        assert 'PRIVATE' not in json.dumps(report)
    else:
        assert len(launched)==4 and all(x.closed for x in launched)
    assert all(row['reaped'] for row in report['children_cleanup'])
    if expected is None:assert report['browser_evidence']['images_verified']==16
    if case=='nonzero':assert report['browser_exit_code']==1
    if case=='shutdown_failure':
        assert all(x['state']=='ABSENT' for x in report['service_failures_before_cleanup'])
        assert report['service_failures_after_cleanup'][0]['state']=='PRESENT'


def _immediate(awaitable):
    """Drive an authored no-I/O lifespan without creating an event loop/socket."""
    iterator=awaitable.__await__()
    try:
        next(iterator)
    except StopIteration as done:
        return done.value
    finally:
        iterator.close()
    raise AssertionError('Unexpected asynchronous I/O in inert lifecycle')


def _inert_service(tmp_path, monkeypatch, fault=None):
    from fastapi import FastAPI
    import uvicorn
    h=harness();data=tmp_path/'data';data.mkdir()
    monkeypatch.setenv('LIVEMORE_DATA_DIR',str(data))
    app=FastAPI();calls=[];state={'tw':None,'initialized':False,'model_availability':{
        'state':'UNAVAILABLE','reason_code':'MODEL_BINDING_REQUIRED','selection_mode':'observations_only'}}
    error={'guard':RuntimeError,'import':ImportError,'hook':TypeError,'server':OSError,
        'entry':RuntimeError,'exit':ValueError,'inner_then_exit':RuntimeError}.get(fault,RuntimeError)('PRIVATE clinical note /private/path')
    if fault=='server_exit_integer':error=SystemExit(3)
    if fault=='server_exit_text':error=SystemExit('PRIVATE clinical note')
    if fault=='server_other':error=type('PRIVATE_ClinicalError',(Exception,),{})('PRIVATE note')
    def original_startup():
        calls.append('original-startup')
        if fault in {'entry','inner_then_exit'}:raise error
        state['initialized']=True
        if fault=='model':state['tw']=object()
    def original_shutdown():
        calls.append('original-shutdown')
        if fault=='exit':raise error
    app.router.add_event_handler('startup',original_startup)
    app.router.add_event_handler('shutdown',original_shutdown)
    original=app.router.lifespan_context
    def guards(**_):
        if fault=='guard':raise error
        return {'installed':12,'model_execution':False}
    monkeypatch.setattr(h,'install_tripwires',guards)
    monkeypatch.setattr(h.sys,'addaudithook',lambda _:None)
    importer=importlib.import_module
    def imports(name,*args,**kwargs):
        if name=='livemorebio.aegle.server':
            if fault=='import':raise error
            return SimpleNamespace(app=app,_state=state,main=lambda **kwargs:run(app,**kwargs))
        return importer(name,*args,**kwargs)
    monkeypatch.setattr(h.importlib,'import_module',imports)
    if fault=='hook':
        monkeypatch.setattr(app.router,'add_event_handler',lambda *_:(_ for _ in ()).throw(error))
    def run(supplied,**kwargs):
        assert supplied is app
        assert kwargs==dict(host='127.0.0.1',port=8910,access_log=False,timeout_graceful_shutdown=5)
        assert len(app.router.on_startup)==2 and app.router.on_startup[0] is original_startup
        calls.append('server-enter')
        if fault in {'server','server_exit_integer','server_exit_text','server_other'}:raise error
        manager=app.router.lifespan_context(app)
        try:
            _immediate(manager.__aenter__())
        except BaseException:
            if fault=='inner_then_exit':raise SystemExit(3)
            raise
        calls.append('serving-inert')
        _immediate(manager.__aexit__(None,None,None))
    monkeypatch.setattr(uvicorn,'run',run)
    return h,app,calls,error,original


def test_installed_fastapi_registration_and_original_lifespan_are_preserved(tmp_path, monkeypatch):
    h,app,calls,_,original=_inert_service(tmp_path,monkeypatch)
    assert not hasattr(app,'add_event_handler')  # The exact installed contract, not a permissive mock.
    assert h.run_service(0)==0
    assert calls==['server-enter','original-startup','serving-inert','original-shutdown']
    assert not (tmp_path/'service-0-failure.json').exists()


@pytest.mark.parametrize('fault,phase,kind', [('guard','GUARD_INSTALL','RuntimeError'),
    ('import','APP_IMPORT','ImportError'),('hook','HOOK_REGISTRATION','TypeError'),
    ('server','SERVER_RUN','OSError'),('entry','LIFESPAN_STARTUP','RuntimeError'),
    ('exit','LIFESPAN_SHUTDOWN','ValueError'),('inner_then_exit','LIFESPAN_STARTUP','RuntimeError'),
    ('model','LIFESPAN_STARTUP','HarnessError'),('server_exit_integer','SERVER_RUN','SystemExit'),
    ('server_exit_text','SERVER_RUN','SystemExit'),('server_other','SERVER_RUN','OTHER')])
def test_service_first_fixed_failure_survives_uvicorn_and_contains_no_payload(tmp_path, monkeypatch, fault, phase, kind):
    h,_,_,original,_=_inert_service(tmp_path,monkeypatch,fault)
    with pytest.raises(BaseException) as raised:h.run_service(0)
    if fault not in {'inner_then_exit','model'}:assert raised.value is original
    if fault=='inner_then_exit':assert isinstance(raised.value,SystemExit) and raised.value.code==3
    raw=(tmp_path/'service-0-failure.json').read_bytes()
    assert len(raw)<=1024 and b'PRIVATE' not in raw and b'/private/path' not in raw
    assert (tmp_path/'service-0-failure.json').stat().st_mode&0o777==0o600
    assert json.loads(raw)=={'schema':'livemore.legacy-preview-service-failure.v1','role':0,
        'stage':phase,'outcome':'FAILED','error_class':kind,'exit_code':3 if fault=='server_exit_integer' else None}


def test_service_diagnostic_write_failure_cannot_mask_primary(tmp_path, monkeypatch, capsys):
    h,_,_,original,_=_inert_service(tmp_path,monkeypatch,'import')
    writer=h.write_private
    def write(file,value):
        if file.name.endswith('-failure.json'):raise OSError('PRIVATE evidence storage')
        return writer(file,value)
    monkeypatch.setattr(h,'write_private',write)
    with pytest.raises(ImportError) as raised:h.run_service(0)
    assert raised.value is original
    assert capsys.readouterr().err=='SERVICE_FAILURE_EVIDENCE_UNCONFIRMED\n'


def test_diagnostic_reader_cannot_block_opening_nonregular_evidence(tmp_path, monkeypatch):
    h=harness();file=tmp_path/'service-0-failure.json';file.write_text('{}', encoding="utf-8");file.chmod(0o600)
    original=h.os.open;flags_seen=[]
    def checked_open(path,flags,*args,**kwargs):
        flags_seen.append(flags)
        assert flags & h.os.O_NONBLOCK  # Assert before opening; this RED cannot hang on a FIFO.
        return original(path,flags,*args,**kwargs)
    monkeypatch.setattr(h.os,'open',checked_open)
    assert h.service_failure_receipts(tmp_path)[0]['state']=='INVALID'
    assert flags_seen and flags_seen[0]&h.os.O_NONBLOCK


@pytest.mark.parametrize('operation,kind', [('nav','TimeoutError'),('nav','Error'),
    ('nav','PRIVATE_CUSTOM'),('body','TimeoutError'),('body','Error')])
def test_mounted_first_origin_diagnostic_preserves_safe_native_category(operation,kind):
    mounted(operation+'_error_'+kind, """
a.equal(status,1);a.deepEqual(finalReceipt.first_failure,{case:'D0',context:1,
 operation:OPERATION,error_class:KIND,code:CODE});
a(!JSON.stringify(finalReceipt).includes('PRIVATE'));a.equal(postCount,0);
a(finalReceipt.cases.slice(1).every(x=>x.status==='NOT_RUN'));
a.equal(finalReceipt.images.length,0);a.equal(finalReceipt.failure_images.length,1);
a.deepEqual(finalReceipt.failure_images[0].viewport,{width:1440,height:1000});
a.equal(finalReceipt.failure_images[0].bytes,Buffer.byteLength('authored-image'));
a.equal(finalReceipt.failure_images[0].sha256,require('node:crypto').createHash('sha256').update('authored-image').digest('hex'));
a(calls.indexOf('screenshot:2000')<calls.indexOf('page-close'));
a.deepEqual(finalReceipt.d0_checks,{navigation_complete:false,modeless_admitted:false,cookie_admitted:false,profile_match:false,services_exact:false});
""".replace('OPERATION',json.dumps('NAVIGATE' if operation=='nav' else 'RESPONSE_BODY'))
    .replace('KIND',json.dumps('OTHER' if kind.startswith('PRIVATE') else kind))
    .replace('CODE',json.dumps('ACTION_TIMEOUT' if kind=='TimeoutError' else 'BROWSER_CHECK_FAILED')))


def test_mounted_original_response_metadata_no_extra_body_read():
    mounted('body_error_Error', """
const state=finalReceipt.requests.find(x=>x.category==='/api/state');
a.equal(state.status,200);a.equal(state.body_stage,'FAILED');a.equal(state.modeless_admitted,null);
const auth=finalReceipt.requests.find(x=>x.category==='/api/session/bootstrap');
a.equal(auth.status,204);a.equal(auth.body_stage,'NOT_REQUIRED');
a.equal(calls.filter(x=>x==='body:state').length,1);a.equal(finalReceipt.requests.length,2);
""")


def test_mounted_non200_response_status_is_not_misreported_as_missing_response():
    mounted('state503', """
const state=finalReceipt.requests.find(x=>x.category==='/api/state');
a.equal(state.status,503);a.equal(state.body_stage,'NOT_READ');a.equal(state.modeless_admitted,null);
a.equal(calls.filter(x=>x==='body:state').length,0);
// This fixture accelerates the outer deadline below the real 10-second poll.
a.equal(finalReceipt.first_failure.code,'BROWSER_DEADLINE');
a.equal(finalReceipt.d0_checks.modeless_admitted,false);
""")


@pytest.mark.parametrize('mode,expected', [('capture_timeout','FAILURE_IMAGE_TIMEOUT'),
    ('capture_large','IMAGE_SIZE'),('capture_error','FAILURE_IMAGE_FAILED'),
    ('capture_disconnected','OWNERSHIP_UNCONFIRMED')])
def test_mounted_failure_image_never_masks_first_failure_or_restarts_work(mode,expected):
    mounted(mode, """
a.equal(status,1);a.equal(finalReceipt.first_failure.operation,'NAVIGATE');
a.equal(finalReceipt.first_failure.error_class,'Error');a.equal(finalReceipt.primary_failure,'BROWSER_CHECK_FAILED');
a.equal(finalReceipt.failure_images.length,0);a.equal(finalReceipt.failure_capture.code,EXPECTED);
a.equal(postCount,0);a.equal(calls.filter(x=>x.startsWith('click:')).length,0);
a.equal(calls.filter(x=>x.startsWith('screenshot:')).length,COUNT);
a(calls.includes('page-close')&&calls.includes('context-close')&&calls.includes('browser-close'));
a(!JSON.stringify(finalReceipt).includes('PRIVATE'));
""".replace('EXPECTED',json.dumps(expected)).replace('COUNT','0' if mode=='capture_disconnected' else '1'))


def test_mounted_unresolved_allocation_has_no_failure_capture():
    mounted('never_context', """
a.equal(finalReceipt.first_failure.operation,'ALLOCATE_CONTEXT');
a.equal(finalReceipt.failure_capture.code,'OWNERSHIP_UNCONFIRMED');
a.equal(finalReceipt.failure_images.length,0);a(!calls.some(x=>x.startsWith('screenshot:')));
""")


@pytest.mark.parametrize('mode,operation,kind,admitted', [('invalid_json','STATE_PARSE','SyntaxError',None),
    ('invalid_modeless','STATE_ADMISSION','Error',False)])
def test_mounted_state_validation_phase_is_safe_and_distinct(mode,operation,kind,admitted):
    mounted(mode, """
a.equal(status,1);a.deepEqual(finalReceipt.first_failure,{case:'D0',context:1,
 operation:OPERATION,error_class:KIND,code:'ACTUAL_AUTH_STATE_INVALID'});
const state=finalReceipt.requests.find(x=>x.category==='/api/state');
a.equal(state.status,200);a.equal(state.body_stage,'READ');a.equal(state.modeless_admitted,ADMITTED);
a.equal(calls.filter(x=>x==='body:state').length,1);a.equal(postCount,0);
a(!JSON.stringify(finalReceipt).includes('PRIVATE'));
""".replace('OPERATION',json.dumps(operation)).replace('KIND',json.dumps(kind)).replace('ADMITTED',json.dumps(admitted)))
