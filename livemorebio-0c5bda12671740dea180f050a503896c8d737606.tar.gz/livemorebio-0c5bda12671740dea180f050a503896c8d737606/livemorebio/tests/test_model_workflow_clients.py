"""Browser and terminal must use the same bounded, authenticated contracts."""
from __future__ import annotations

import json
import urllib.parse

import pytest

from livemorebio.sdk import Platform


def test_sdk_pagination_and_history_contract(monkeypatch):
    platform = Platform(mode="attach")
    paths = []
    monkeypatch.setattr(platform, "_get", lambda path: paths.append(path) or {})
    platform.list_twins(limit=10, cursor="opaque+/=", q="research prior")
    platform.list_cohorts(limit=25)
    platform.protocol_history(limit=10, q="oxygen")
    platform.prepare_protocol_rerun("protocol-" + "a" * 32)
    platform.genome_models()
    assert urllib.parse.parse_qs(urllib.parse.urlsplit(paths[0]).query) == {
        "limit": ["10"], "cursor": ["opaque+/="], "q": ["research prior"],
    }
    assert paths[1] == "/api/cohorts?limit=25"
    assert paths[2].startswith("/api/cendos/protocols/history?")
    assert paths[3].endswith("/prepare-rerun")
    assert paths[4] == "/api/genome-models"


def test_sdk_metabolic_protocol_and_explicit_rerun(monkeypatch):
    platform = Platform(mode="attach")
    requests = []
    monkeypatch.setattr(platform, "_post", lambda path, body, **kw: requests.append((path, body, kw)) or {})
    spec = {"model_id": "human-gem", "conditions": [{"condition_id": "oxygen", "glucose_uptake": 1, "oxygen_uptake": 6}]}
    platform.run_metabolic_protocol(spec)
    assert requests[-1] == ("/api/cendos/protocols/human-gem-oxygen-capacity", spec, {"timeout": 150})
    prepared = {"protocol_id": "cendos.human-gem-oxygen-capacity.v1", "parent_run_id": "protocol-" + "b" * 32,
                "request": spec, "endpoint": "https://untrusted.invalid/steal"}
    platform.execute_prepared_rerun(prepared, new_configuration=True)
    path, body, _ = requests[-1]
    assert path == "/api/cendos/protocols/human-gem-oxygen-capacity"
    assert body["parent_run_id"] == prepared["parent_run_id"]
    assert body["new_configuration"] is True
    assert "parent_run_id" not in spec
    with pytest.raises(ValueError):
        platform.execute_prepared_rerun({**prepared, "protocol_id": "unsupported"})
    count = len(requests)
    for value in ("false", "true", 1, 0, None):
        with pytest.raises(ValueError, match="boolean"):
            platform.execute_prepared_rerun(prepared, new_configuration=value)
    assert len(requests) == count


def test_models_cli_dispatch(monkeypatch, capsys):
    from livemorebio import cli, model_assets
    monkeypatch.setattr(model_assets, "status", lambda model_id: {"model_id": model_id, "available": False})
    monkeypatch.setattr("sys.argv", ["livemore", "models", "status", "human-gem"])
    cli.main()
    assert json.loads(capsys.readouterr().out)["model_id"] == "human-gem"


def test_terminal_show_inspects_computed_conditions_not_only_run_id():
    from livemorebio.shell import run_command
    result = {"run_id": "protocol-" + "c" * 32,
              "protocol_id": "cendos.human-gem-oxygen-capacity.v1",
              "evidence_state": "MODELED_STEADY_STATE", "qualification_state": "NOT_QUALIFIED",
              "unit": "mmol/gDW/h", "model": {"release": "2.0.0", "model_sha256": "source-digest"},
              "solver": {"name": "GLPK"}, "input": {"knockout_gene_ids": []},
              "conditions": [{"condition_id": "technical-oxygen", "objective_flux": 31.5,
                              "actual_glucose_uptake": 1, "actual_oxygen_uptake": 6,
                              "solver_status": "optimal", "mass_balance_residual": 1e-12,
                              "bound_residual": 0}],
              "controls": [{"condition_id": "closed-medium", "objective_flux": 0, "passed": True}]}
    class Client:
        def get_protocol(self, run_id):
            assert run_id == result["run_id"]
            return result
    lines = []
    assert run_command(Client(), "protocol show " + result["run_id"], out=lines.append) == result
    output = "\n".join(lines)
    for expected in ("31.5", "technical-oxygen", "closed-medium", "mmol/gDW/h", "source-digest", "NOT_QUALIFIED"):
        assert expected in output
