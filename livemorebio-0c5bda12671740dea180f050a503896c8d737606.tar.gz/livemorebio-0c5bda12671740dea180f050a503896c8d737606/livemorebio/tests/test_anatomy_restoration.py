"""Run anatomy is reference geometry joined to one frozen selection, never a live twin."""
from __future__ import annotations

import json
from pathlib import Path
import subprocess

import pytest
from ._node import require_node, run_node as _run_node

CONSOLE = Path(__file__).parents[1] / "aegle/console"


def node(program: str) -> str:
    executable = require_node()
    result = _run_node([executable, "--input-type=module", "--eval", program],
                            capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    return result.stdout


def fixtures() -> tuple[dict, dict]:
    reference = {"schema": "livemore.biology-reference.v1", "evidence_state": "REFERENCE_ONLY",
                 "reference_geometry": True, "organs": [{"id": "liver", "name": "Liver",
                 "mesh": "/assets/anatomy/liver.glb", "pos": [0, .2, 0],
                 "status": "reference", "value": None, "metric": None, "unit": None,
                 "anatomy": {"mesh_source": "Technical source", "uberon": "UBERON:0002107"},
                 "cell": {"type": "Hepatocyte", "evidence_state": "REFERENCE_ONLY",
                          "activity": None, "quantities": []}}]}
    inspection = {"schema": "livemore.protocol-inspection.v1",
                  "binding": {"run_id": "protocol-" + "a" * 32,
                              "protocol_id": "cendos.metformin-cohort-comparison.v1",
                              "member_id": "technical-member-a", "cohort_id": "technical-cohort-a",
                              "condition_id": None},
                  "source_class": "MODELED", "freshness": "FROZEN_RECORD",
                  "evidence_state": "MODELED_MECHANISTIC", "qualification_state": "NOT_QUALIFIED",
                  "axis": {"kind": "recorded_time", "unit": "min", "value": 2.5, "index": 1},
                  "quantity": {"id": "glucose", "label": "Glucose", "unit": "mg/dL",
                               "compartment": "Reduced whole-body glucose compartment",
                               "baseline": 100, "treated": 120, "status": "MODELED"},
                  "provenance": {"member_source_lineage": {"source_id": "technical-prior-a"}}}
    return reference, inspection


def projection(reference: dict, inspection: dict) -> dict:
    module = (CONSOLE / "lib/run_anatomy.js").as_uri()
    return json.loads(node(f"import {{runAnatomyProjection}} from {json.dumps(module)};"
                           f"try{{console.log(JSON.stringify(runAnatomyProjection({json.dumps(reference)},"
                           f"{json.dumps(inspection)})))}}catch(e){{console.log(JSON.stringify({{error:e.message}}))}}"))


def test_run_geometry_preserves_member_axis_source_without_assigning_organ_function():
    reference, inspection = fixtures()
    result = projection(reference, inspection)
    assert result["binding"] == inspection["binding"]
    assert result["axis"] == inspection["axis"]
    assert result["selected_quantity"]["treated"] == 120
    assert result["organs"][0]["value"] is None
    assert result["organs"][0]["cell"]["quantities"] == []
    assert result["geometry_evidence_state"] == "REFERENCE_ONLY"
    assert result["provenance"] == inspection["provenance"]


@pytest.mark.parametrize("value", [0, 100, 140])
def test_geometry_does_not_turn_zero_unchanged_or_adverse_output_into_benefit(value):
    reference, inspection = fixtures()
    inspection["quantity"]["treated"] = value
    result = projection(reference, inspection)
    assert result["selected_quantity"]["treated"] == value
    assert result["organs"][0]["status"] == "reference"


def test_member_switch_replaces_all_frozen_context_without_mutation():
    reference, inspection = fixtures()
    module = (CONSOLE / "lib/run_anatomy.js").as_uri()
    program = f"""import {{runAnatomyProjection}} from {json.dumps(module)};
const reference={json.dumps(reference)}, first={json.dumps(inspection)};
const before=JSON.stringify([reference,first]);const a=runAnatomyProjection(reference,first);
const second=structuredClone(first);second.binding.member_id='technical-member-b';
second.provenance.member_source_lineage.source_id='technical-prior-b';second.quantity.treated=90;
const b=runAnatomyProjection(reference,second);
if(JSON.stringify([reference,first])!==before)throw Error('input mutated');
if(a.binding.member_id===b.binding.member_id||b.selected_quantity.treated!==90||b.provenance.member_source_lineage.source_id!=='technical-prior-b')throw Error('context drift');
console.log('ok');"""
    assert node(program).strip() == "ok"


def test_nonhuman_and_ambiguous_context_cannot_acquire_human_geometry():
    reference, inspection = fixtures()
    for protocol in ("cendos.lobeline-vmat2-initial-rate.v1", "cendos.human-gem-oxygen-capacity.v1"):
        inspection["binding"]["protocol_id"] = protocol
        assert "error" in projection(reference, inspection)
    reference, inspection = fixtures()
    del inspection["binding"]["member_id"]
    assert "error" in projection(reference, inspection)
    reference, inspection = fixtures()
    reference["organs"][0]["value"] = 120
    assert "error" in projection(reference, inspection)


def test_biology_graphics_are_local_retryable_and_visible_in_human_run():
    html = (CONSOLE / "biology.html").read_text(encoding="utf-8")
    assert 'id="biology-graphics-retry"' in html
    assert "cdn.jsdelivr.net/npm/three" not in html
    loader = (CONSOLE / "lib/anatomy_loader.js").read_text(encoding="utf-8")
    assert "anatomy_vendor.js" in loader
    run_ui = (CONSOLE / "lib/run_anatomy.js").read_text(encoding="utf-8")
    assert "/api/biology/reference" in run_ui
    assert "'/api/state'" not in run_ui and "'/api/biology'" not in run_ui
    dispatch = (CONSOLE / "lib/protocol_biology.js").read_text(encoding="utf-8")
    assert "mountRunAnatomy" in dispatch


@pytest.mark.parametrize("change", ["unit", "cohort", "quantity"])
def test_saved_anatomy_rejects_missing_units_or_ambiguous_quantity_binding(change):
    reference, inspection = fixtures()
    if change == "unit":
        del inspection["quantity"]["unit"]
    elif change == "cohort":
        inspection["binding"]["cohort_id"] = None
    else:
        inspection["quantity"]["id"] = "hepatic_flux"
    assert "error" in projection(reference, inspection)


def test_cached_hotspot_replaces_old_member_metadata():
    source = (CONSOLE / "lib/anatomy.js").read_text(encoding="utf-8")
    body = source.split("  function applyState(o) {", 1)[1].split("  function setOrgans", 1)[0]
    program = """
const old={id:'heart',value:0};const latest={id:'heart',value:.2};
const nodes={heart:{userData:{organ:old},traverse(){}}};
const hotspots={heart:{userData:{organ:old},material:{map:{dispose(){}}}}};
const statusColor=()=>0x7a8f88,hotspotTexture=()=>({});
""" + "function applyState(o){" + body + """
applyState(latest);
if(hotspots.heart.userData.organ!==latest)throw Error('cached hotspot click retains old member data');
"""
    assert node(program) == ""
