"""Offline guards for ordinary presentation QA; never launch services or browsers."""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import subprocess

import pytest
from ._node import NODE, run_node as _run_node


ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture
def harness():
    spec = importlib.util.spec_from_file_location("atlas_presentation_test_subject", ROOT / "tools/check_atlas_presentation.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_import_has_no_browser_service_or_network_side_effect(harness):
    assert callable(harness.main)


def test_fresh_environment_never_borrows_stores_or_credentials(harness, tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "SECRET-MUST-NOT-BE-BORROWED")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "SECRET-MUST-NOT-BE-PASSED")
    first, a = harness.prepare_owned_environment(tmp_path)
    second, b = harness.prepare_owned_environment(tmp_path)
    assert first != second and first.stat().st_mode & 0o777 == 0o700
    assert a["LIVEMORE_API_TOKEN"] != b["LIVEMORE_API_TOKEN"]
    assert a["LIVEMORE_API_TOKEN"] != "SECRET-MUST-NOT-BE-BORROWED"
    assert "AWS_SECRET_ACCESS_KEY" not in a
    from tools.run_review_stack import _STORE_PATHS
    for key in _STORE_PATHS:
        if key == "LIVEMORE_ANATOMY_DIR":
            assert a[key] == str(harness.ANATOMY)
        else:
            assert Path(a[key]).is_relative_to(first)


def test_actual_authored_observation_selection_and_startup_never_construct_models(harness, tmp_path, monkeypatch):
    root, env = harness.prepare_owned_environment(tmp_path)
    for key, value in env.items():
        monkeypatch.setenv(key, value)
    from livemorebio.aegle import server, subjects, clinical_parameters
    from livemorebio.aegle.model_source import ModelSourceAuthority

    def denied(*args, **kwargs):
        pytest.fail("Presentation-only setup attempted numerical construction")

    monkeypatch.setattr(server, "AegleTwin", denied)
    monkeypatch.setattr(subjects.SubjectRegistry, "build_twin", denied)
    monkeypatch.setattr(subjects.SubjectRegistry, "admitted_human", denied)
    monkeypatch.setattr(clinical_parameters, "initialize_profile", denied)
    fixture = harness.prepare_observation_fixture(env)
    assert set(fixture) == {"twin_id", "subject_id", "display_label", "source_class", "version"}
    assert fixture["source_class"] == "REAL_HUMAN" and fixture["version"] == 2
    assert "not a participant" in fixture["display_label"]
    monkeypatch.setattr(server, "_state", {"tw": None, "subject": None, "initialized": False})
    monkeypatch.setattr(server, "_model_source_authority", ModelSourceAuthority())
    monkeypatch.setattr(server, "_workspace_actions", [])
    server._startup_publish()
    assert server._state["tw"] is None
    assert server._state["subject"] == {**fixture, "lifecycle": "ACTIVE"}
    availability = server._state["model_availability"]
    assert availability["state"] == "UNAVAILABLE" and availability["reason_code"] == "MODEL_BINDING_REQUIRED"
    assert availability["selection_mode"] == "observations_only" and availability["preparation_available"] is False
    node("h.requireWorkspace(" + json.dumps(server._workspace_projection()) + ",{fixture:" + json.dumps(fixture) + "});")


def test_cache_inventory_tracks_every_byte_size_mtime_and_rejects_links(harness, tmp_path):
    cache = tmp_path / "public-cache"
    cache.mkdir(mode=0o700)
    target = cache / "asset.glb"
    target.write_bytes(b"technical only")
    before = harness.cache_inventory(cache)
    assert before == harness.cache_inventory(cache)
    target.write_bytes(b"changed bytes")
    assert before != harness.cache_inventory(cache)
    (cache / "linked").symlink_to(target)
    with pytest.raises(harness.PresentationError, match="CACHE_UNSAFE"):
        harness.cache_inventory(cache)


@pytest.mark.parametrize("bad", ["source", "instance", "name", "schema", "started"])
def test_health_identity_drift_is_rejected(harness, bad):
    identity = {"schema": "livemore.build-identity.v1", "source_sha256": "a" * 64,
                "process_instance": "11111111-1111-4111-8111-111111111111", "started_at": "2026-09-08T00:00:00+00:00"}
    value = {"ok": True, "service": "Aegle", "build": dict(identity)}
    expected = harness.require_health(value, "Aegle", "a" * 64)
    if bad == "name":
        value["service"] = "Cendos"
    else:
        key = {"source": "source_sha256", "instance": "process_instance", "schema": "schema", "started": "started_at"}[bad]
        value["build"][key] = "INVALID"
    with pytest.raises(harness.PresentationError):
        harness.require_health(value, "Aegle", "a" * 64, expected)


def test_cleanup_continues_each_owned_child_after_errors(harness):
    calls = []

    class Child:
        def __init__(self, pid):
            self.pid = pid
            self.done = False

        def poll(self):
            return 0 if self.done else None

        def terminate(self):
            calls.append((self.pid, "terminate"))
            if self.pid == 1:
                raise OSError("PRIVATE-ERROR-MUST-NOT-BE-RECORDED")

        def wait(self, timeout):
            calls.append((self.pid, "wait", timeout))
            if not self.done:
                raise subprocess.TimeoutExpired("technical", timeout)
            return 0

        def kill(self):
            calls.append((self.pid, "kill"))
            self.done = True

    result = harness.cleanup_children([Child(1), Child(2)])
    assert all(row["reaped"] for row in result)
    assert (1, "kill") in calls and (2, "kill") in calls
    assert "PRIVATE" not in json.dumps(result)


def test_finalization_preserves_primary_failure_and_independent_cleanup(harness):
    calls = []
    report = {"primary_failure": "STARTUP_IDENTITY"}

    def failure(name):
        calls.append(name)
        raise OSError("PRIVATE-FAILURE")

    harness.finalize(report, lambda: failure("cleanup"), lambda: failure("cache"), lambda value: failure("write"))
    assert calls == ["cleanup", "cache", "write"]
    assert report["primary_failure"] == "STARTUP_IDENTITY"
    assert report["cleanup_failure"] == "CLEANUP_UNCONFIRMED"
    assert report["evidence_failure"] == "EVIDENCE_WRITE_FAILED"
    assert "PRIVATE" not in json.dumps(report)


def node(code):
    result = _run_node([NODE, "-e", "const h=require('./tools/check_atlas_presentation.cjs');const a=require('node:assert/strict');\n" + code],
                            cwd=ROOT, capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_browser_module_import_never_launches_and_has_fixed_request_policy():
    node("""
const c={base:'http://127.0.0.1:8910',static_paths:['/lib/workspace.js','/lib/anatomy_vendor.js']};
for(const p of ['/','/api/workspace','/api/workspace/stream','/api/build','/api/services','/api/executions/capabilities','/api/session/bootstrap','/api/anatomy/atlas-reference','/lib/workspace.js','/lib/anatomy_vendor.js?atlas=1',`/assets/anatomy/atlas/${h.MANIFEST}/skin.glb`])a.equal(h.requestDecision('GET',c.base+p,c),'ALLOW',p);
for(const p of ['/assets/anatomy/heart.glb','/api/stimulate','/api/workspace?x=1','/api/cohorts','/lib/other.js','/lib/workspace.js?x=1',`/assets/anatomy/atlas/${'f'.repeat(64)}/skin.glb`])a.equal(h.requestDecision('GET',c.base+p,c),'REJECT',p);
a.equal(h.requestDecision('POST',c.base+'/api/anatomy/atlas-reference/install',c),'REJECT');
a.equal(h.requestDecision('GET','https://fonts.googleapis.com/css2?family=Inter',c),'EXTERNAL_FONT_BLOCKED');
a.equal(h.requestDecision('GET','https://other.invalid/lib/workspace.js',c),'REJECT');
""")


def test_browser_context_fence_rejects_wrong_record_version_model_and_context():
    node("""
const fixture={twin_id:'twin-'+'1'.repeat(32),subject_id:'pseudonym-technical-atlas-presentation',display_label:h.LABEL,source_class:'REAL_HUMAN',version:2};
const c={fixture};const state={schema:'livemore.multiscale-workspace.v1',context_id:'a'.repeat(64),subject:{...fixture,lifecycle:'ACTIVE'},model_availability:{schema:'livemore.model-availability.v1',state:'UNAVAILABLE',reason_code:'MODEL_BINDING_REQUIRED',selection_mode:'observations_only',preparation_available:false,twin_id:fixture.twin_id,twin_version:2,source_generation:'c'.repeat(32)},twin:{metabolic:null,cardiac:null,active_execution:null},multiscale:{biological_time:{axes:[]},active_execution:null}};
const good=h.requireWorkspace(state,c);for(const alter of [x=>x.subject.version=1,x=>x.subject.twin_id='other',x=>x.model_availability.state='READY',x=>x.model_availability.preparation_available=true,x=>x.twin.metabolic={},x=>x.multiscale.biological_time.axes=[{}],x=>x.context_id='b'.repeat(64)]){const bad=structuredClone(state);alter(bad);a.throws(()=>h.requireWorkspace(bad,c,good));}
""")


def test_browser_manifest_drift_and_same_camera_bounds_fail_closed():
    node("""
a.throws(()=>h.requireAtlas({state:'available',available:true,manifest_sha256:'f'.repeat(64)}));
h.sameCameraBounds({x:1,y:2,width:3,height:4},{x:1,y:2,width:3,height:4});
a.throws(()=>h.sameCameraBounds({x:1,y:2,width:3,height:4},{x:1,y:2,width:3,height:5}));
""")


def test_browser_cleanup_and_evidence_failure_do_not_replace_primary():
    node("""
(async()=>{const calls=[],e={primary_failure:'VIEW_MISMATCH'};
await h.finishOwned([{name:'page',close:async()=>{calls.push('page');throw Error('PRIVATE');}},{name:'context',close:async()=>{calls.push('context');}},{name:'browser',close:async()=>{calls.push('browser');}}],e,async()=>{calls.push('write');throw Error('PRIVATE');},20);
a.deepEqual(calls,['page','context','browser','write']);a.equal(e.primary_failure,'VIEW_MISMATCH');a.equal(e.cleanup.page,'CLEANUP_UNCONFIRMED');a.equal(e.cleanup.browser,'SETTLED');a.equal(e.evidence_failure,'EVIDENCE_WRITE_FAILED');a(!JSON.stringify(e).includes('PRIVATE'));})().catch(()=>process.exitCode=1);
""")


def test_browser_cleanup_timeout_still_closes_remaining_resources():
    node("""
(async()=>{const calls=[],e={primary_failure:'RUN_DEADLINE'};await h.finishOwned([{name:'page',close:()=>new Promise(()=>{})},{name:'context',close:async()=>calls.push('context')},{name:'browser',close:async()=>calls.push('browser')}],e,async()=>calls.push('write'),10);a.deepEqual(calls,['context','browser','write']);a.equal(e.cleanup.page,'CLEANUP_UNCONFIRMED');a.equal(e.primary_failure,'RUN_DEADLINE');})().catch(()=>process.exitCode=1);
""")


def test_late_browser_allocation_remains_owned_after_timeout():
    node("""
(async()=>{const slot=h.ownedResource('browser');let resolve,calls=0;
const pending=slot.acquire(()=>new Promise(r=>resolve=r));await Promise.resolve();
const e={primary_failure:'RUN_DEADLINE'};await h.finishOwned([slot],e,async()=>{},5);
a.equal(e.cleanup.browser,'CLEANUP_UNCONFIRMED');
resolve({close:async()=>calls++});await pending;await new Promise(r=>setTimeout(r,0));
await slot.close();a.equal(calls,1);a.equal(e.primary_failure,'RUN_DEADLINE');
})().catch(()=>process.exitCode=1);
""")


def test_rejected_browser_allocation_has_no_resource_to_close():
    node("""
(async()=>{const slot=h.ownedResource('browser');await a.rejects(slot.acquire(async()=>{throw Error('PRIVATE');}));
const e={primary_failure:'PRESENTATION_CHECK_FAILED'};await h.finishOwned([slot],e,async()=>{},20);
a.equal(e.cleanup.browser,'SETTLED');a(!JSON.stringify(e).includes('PRIVATE'));
})().catch(()=>process.exitCode=1);
""")


def test_browser_case_ledger_retains_failure_and_unrun_cases():
    node("""
(async()=>{const e=h.newCaseEvidence();a(e.cases.every(c=>c.status==='NOT_RUN'));
await h.runCase(e,'desktop-whole-person',async()=>{});
await a.rejects(h.runCase(e,'desktop-FJ1895-assembled',async()=>{throw Error('PRIVATE');}));
a.equal(e.cases.find(c=>c.id==='desktop-whole-person').status,'PASS');
a.equal(e.cases.find(c=>c.id==='desktop-FJ1895-assembled').status,'FAIL');
a.equal(e.cases.find(c=>c.id==='mobile-full-body').status,'NOT_RUN');
a.equal(e.active_stage,'desktop-FJ1895-assembled');a(!JSON.stringify(e).includes('PRIVATE'));
})().catch(()=>process.exitCode=1);
""")


def test_process_descendants_keep_only_proven_ancestry_and_start_identity(harness):
    snapshot = {10: {"parent": 1, "started": "A"}, 11: {"parent": 10, "started": "B"},
                12: {"parent": 11, "started": "C"}, 30: {"parent": 1, "started": "D"}}
    rows = harness.descendant_identities(snapshot, 10)
    assert rows == [{"pid": 11, "started": "B"}, {"pid": 12, "started": "C"}]
    assert harness.remaining_descendants(rows, {12: snapshot[12]}) == [rows[1]]
    assert harness.remaining_descendants(rows, {12: {"parent": 1, "started": "REUSED"}}) == []


def test_browser_wait_tracks_descendants_without_process_arguments(harness, monkeypatch):
    snapshots = iter([{10: {"parent": 1, "started": "N"}, 11: {"parent": 10, "started": "C"}},
                      {10: {"parent": 1, "started": "N"}, 11: {"parent": 1, "started": "C"}}])
    monkeypatch.setattr(harness, "process_snapshot", lambda timeout=2: next(snapshots))

    class Child:
        pid = 10
        calls = 0

        def wait(self, timeout):
            self.calls += 1
            if self.calls == 1:
                raise subprocess.TimeoutExpired("technical", timeout)
            return 0

    rows = []
    assert harness.wait_browser(Child(), rows, timeout=1) == 0
    assert rows == [{"pid": 11, "started": "C"}]


def test_process_snapshot_requests_metadata_only_with_a_deadline(harness, monkeypatch):
    calls = []

    def run(command, **kwargs):
        calls.append((command, kwargs))
        return subprocess.CompletedProcess(command, 0, b" 10 1 Tue Sep  8 12:00:00 2026\n 11 10 Tue Sep  8 12:00:01 2026\n")

    monkeypatch.setattr(harness.subprocess, "run", run)
    rows = harness.process_snapshot(timeout=.5)
    assert rows[11] == {"parent": 10, "started": "Tue Sep  8 12:00:01 2026"}
    assert calls[0][0] == ["/bin/ps", "-axo", "pid=,ppid=,lstart="]
    assert calls[0][1]["timeout"] == .5 and calls[0][1]["env"] == {"PATH": "/usr/bin:/bin", "LC_ALL": "C"}


def test_stalled_route_installation_uses_existing_work_deadline():
    node("""
(async()=>{let calls=0;const context={route:(pattern,handler)=>{calls++;a.equal(pattern,'**/*');a.equal(typeof handler,'function');return new Promise(()=>{});}};
let timer;const work=operation=>Promise.race([Promise.resolve().then(operation),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('TECHNICAL_DEADLINE')),5);})]);
try{await a.rejects(h.installRoute(context,()=>{},work),/TECHNICAL_DEADLINE/);a.equal(calls,1);}finally{clearTimeout(timer);}
})().catch(()=>process.exitCode=1);
""")


def test_api_metadata_read_refuses_redirect_before_body_and_disposes():
    node("""
(async()=>{let calls=0,bodies=0,disposed=0;const context={request:{get:async(url,options)=>{calls++;a.equal(url,'http://127.0.0.1:8910/api/build');a.deepEqual(options,{timeout:10000,maxRedirects:0});return {status:()=>302,json:async()=>{bodies++;return {};},dispose:async()=>disposed++};}}};
await a.rejects(h.readMetadata(context,'http://127.0.0.1:8910','/api/build',operation=>operation()),error=>error.code==='READ_REJECTED');
a.equal(calls,1);a.equal(bodies,0);a.equal(disposed,1);
await a.rejects(h.readMetadata(context,'http://127.0.0.1:8910','/api/private',operation=>operation()),error=>error.code==='READ_NOT_AUTHORIZED');a.equal(calls,1);
})().catch(()=>process.exitCode=1);
""")
