"""Technical reference previews: absent CellML never invents a ventricular trace."""
from __future__ import annotations

import json

import pytest

from livemorebio import model_assets


@pytest.mark.parametrize("code", ["CARDIAC_MODEL_NOT_INSTALLED", "CARDIAC_MODEL_HASH_MISMATCH"])
def test_unavailable_cell_leaves_technical_metabolic_preview_working(monkeypatch, code):
    from livemorebio.aegle import runtime
    from livemorebio.multiscale import multiscale_state

    def refuse():
        raise model_assets.ModelAssetError(code, "Technical fixture: cardiac asset unavailable.")

    monkeypatch.setattr(model_assets, "verified_cardiac_path", refuse, raising=False)
    monkeypatch.setattr(runtime, "CardiacCell", lambda: pytest.fail("unverified cell constructed"))
    twin = runtime.AegleTwin()
    state = twin.state()
    assert state["metabolic"]["glucose"]
    assert state["cardiac"]["reason_code"] == code
    assert state["cardiac"]["apd90_ms"] is None
    assert state["cardiac"]["v"] == []
    assert state["cardiac"]["hr_bpm"] > 0
    assert next(item for item in state["systems"] if item["id"] == "cardiac")["status"] == "unavailable"
    projection = multiscale_state(twin)
    assert "ohara-rudy-cipa-2017" not in {
        node["engine"] for node in projection["active_execution"]["nodes"]
    }
    assert twin.stimulate("meal", grams=30)["metabolic"]["glucose"]
    before = json.dumps(twin.state(), sort_keys=True)
    with pytest.raises(model_assets.ModelAssetError) as error:
        twin.stimulate("cardiac_drug", ikr_block=0.5)
    assert error.value.code == code
    assert json.dumps(twin.state(), sort_keys=True) == before


def test_missing_cell_never_claims_computed_biology(monkeypatch):
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.engines.biology import biology_state

    def refuse():
        raise model_assets.ModelAssetError("CARDIAC_MODEL_NOT_INSTALLED", "Technical missing asset.")

    monkeypatch.setattr(model_assets, "verified_cardiac_path", refuse, raising=False)
    heart = next(organ for organ in biology_state(AegleTwin())["organs"] if organ["id"] == "heart")
    assert heart["cell"]["evidence_state"] == "REFERENCE_ONLY"
    assert heart["cell"]["reason_code"] == "CARDIAC_MODEL_NOT_INSTALLED"


def test_doctor_separately_reports_cardiac_asset(monkeypatch):
    from livemorebio import doctor

    monkeypatch.setattr(model_assets, "cardiac_status", lambda: {
        "available": False, "reason_code": "CARDIAC_MODEL_NOT_INSTALLED",
        "reason": "Technical missing asset.",
    }, raising=False)
    result = doctor.report()
    assert result["cardiac_assets"]["available"] is False
    assert "CARDIAC_MODEL_NOT_INSTALLED" in doctor.render(result)
