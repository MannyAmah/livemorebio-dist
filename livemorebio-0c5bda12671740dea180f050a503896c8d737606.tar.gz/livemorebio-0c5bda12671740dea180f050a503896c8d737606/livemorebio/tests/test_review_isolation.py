"""An alternate review stack must not write the installed person's shared state."""
import base64
import os
from pathlib import Path
import subprocess
import sys
import ast
import importlib.util
import stat
import signal

import pytest


def _review_launcher():
    path = Path(__file__).parents[2] / "tools/run_review_stack.py"
    tree = ast.parse(path.read_text(encoding="utf-8"))
    assert any(isinstance(node, ast.FunctionDef) and node.name == "prepare_review_environment"
               for node in tree.body), "review configuration must be testable without launching services"
    spec = importlib.util.spec_from_file_location("livemore_review_launcher_test", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_launcher_scopes_every_known_mutable_store_and_cache(tmp_path):
    module = _review_launcher()
    names = (
        "LIVEMORE_DATA_DIR", "LIVEMORE_SUBJECT_REGISTRY", "LIVEMORE_PROTOCOL_RUNS",
        "LIVEMORE_RESEARCH_STORE", "LIVEMORE_LICENSED_REFERENCE_DIR", "LIVEMORE_EVIDENCE_DB",
        "LIVEMORE_EVIDENCE_EXPORT_DIR", "LIVEMORE_PATCH_JOURNAL", "LIVEMORE_SCREEN_RUN_DIR",
        "LIVEMORE_RESOLVE_CACHE", "LIVEMORE_CACHE", "LIVEMORE_ANATOMY_DIR", "CENDOS_DB",
        "LIVEMORE_EVIDENCE_SIGNING_KEY_FILE", "LIVEMORE_EXECUTION_STORE",
        "LIVEMORE_VIRTUAL_EXECUTION_STORE", "LIVEMORE_POPULATION_SOURCE_DIR",
    )
    inherited = {name: "/outside/installed-person-data" for name in names}
    inherited.update(PATH=os.environ["PATH"], LIVEMORE_EVIDENCE_SIGNING_KEY="outside-secret",
                     LIVEMORE_EVIDENCE_SIGNING_KEY_ID="production-issuer",
                     LIVEMORE_EVIDENCE_AUDIT_HMAC_KEY="outside-audit-secret",
                     LIVEMORE_EVIDENCE_AUDIT_HMAC_VERIFICATION_KEYS="outside-keyring")
    root, env = module.prepare_review_environment(tmp_path, inherited=inherited)
    assert root == tmp_path.resolve()
    assert all(Path(env[name]).resolve().is_relative_to(root) for name in names)
    assert env["PATH"] == inherited["PATH"]
    assert "LIVEMORE_EVIDENCE_SIGNING_KEY" not in env
    assert env.get("LIVEMORE_EVIDENCE_SIGNING_KEY_ID") != "production-issuer"
    assert "LIVEMORE_EVIDENCE_AUDIT_HMAC_KEY" not in env
    assert "LIVEMORE_EVIDENCE_AUDIT_HMAC_VERIFICATION_KEYS" not in env
    assert module.prepare_review_environment(tmp_path, inherited={})[1]["LIVEMORE_API_TOKEN"] == env["LIVEMORE_API_TOKEN"]
    assert Path(env["LIVEMORE_EXECUTION_STORE"]).parent == root / "executions"
    assert stat.S_IMODE((root / "executions").stat().st_mode) == 0o700
    assert Path(env["LIVEMORE_VIRTUAL_EXECUTION_STORE"]).parent == root / "virtual-executions"
    assert env["LIVEMORE_VIRTUAL_EXECUTION_STORE"] != env["LIVEMORE_EXECUTION_STORE"]
    assert stat.S_IMODE((root / "virtual-executions").stat().st_mode) == 0o700
    for name in ("api-token", "patch-storage-key", "patch-admission-key"):
        assert stat.S_IMODE((root / name).stat().st_mode) == 0o600


def test_native_review_environment_drops_compose_console_peer(tmp_path):
    module = _review_launcher()

    _, env = module.prepare_review_environment(
        tmp_path, inherited={"LIVEMORE_CONSOLE_PEER": "docker-gateway"}
    )

    assert "LIVEMORE_CONSOLE_PEER" not in env


@pytest.mark.parametrize("kind", ["public-directory", "directory-symlink", "public-secret",
                                 "secret-symlink", "secret-hardlink", "external-cache-symlink",
                                 "external-snapshot-symlink", "external-audit-symlink",
                                 "external-sqlite-sidecar", "secret-directory", "empty-secret",
                                 "external-execution-directory", "public-execution-directory"])
def test_launcher_rejects_unsafe_existing_paths_before_service_launch(tmp_path, kind):
    module = _review_launcher()
    root = tmp_path / "review"
    root.mkdir(mode=0o700)
    outside = tmp_path / "outside"
    outside.mkdir(mode=0o700)
    secret = outside / "secret"
    secret.write_text("external-secret", encoding="utf-8")
    secret.chmod(0o600)
    if kind == "public-directory":
        root.chmod(0o755)
    elif kind == "directory-symlink":
        root = tmp_path / "review-link"
        root.symlink_to(outside, target_is_directory=True)
    elif kind == "public-secret":
        (root / "api-token").write_text("exposed-token", encoding="utf-8")
        (root / "api-token").chmod(0o644)
    elif kind == "secret-symlink":
        (root / "api-token").symlink_to(secret)
    elif kind == "secret-hardlink":
        os.link(secret, root / "api-token")
    elif kind == "external-cache-symlink":
        (root / "screen-runs").symlink_to(outside, target_is_directory=True)
    elif kind == "external-snapshot-symlink":
        (root / "snapshots").symlink_to(outside, target_is_directory=True)
    elif kind == "external-audit-symlink":
        (root / "livemore-sign-hmac.key").symlink_to(secret)
    elif kind == "external-sqlite-sidecar":
        (root / "subjects.sqlite3-wal").symlink_to(secret)
    elif kind == "external-execution-directory":
        (root / "executions").symlink_to(outside, target_is_directory=True)
    elif kind == "public-execution-directory":
        (root / "executions").mkdir()
        (root / "executions").chmod(0o755)  # explicit: mkdir modes are masked by umask
    elif kind == "secret-directory":
        (root / "api-token").mkdir(mode=0o700)
    elif kind == "empty-secret":
        (root / "api-token").write_text("", encoding="utf-8")
        (root / "api-token").chmod(0o600)
    with pytest.raises(ValueError):
        module.prepare_review_environment(root, inherited={})
    assert secret.read_text(encoding="utf-8") == "external-secret"


def test_launcher_rejects_non_owned_review_directory(tmp_path, monkeypatch):
    module = _review_launcher()
    monkeypatch.setattr(module.os, "getuid", lambda: tmp_path.stat().st_uid + 1)
    with pytest.raises(ValueError, match="owner"):
        module.prepare_review_environment(tmp_path, inherited={})


def test_launcher_path_configuration_reaches_actual_consumers(tmp_path):
    module = _review_launcher()
    root, env = module.prepare_review_environment(tmp_path, inherited=os.environ)
    code = """
import os
from pathlib import Path
from livemorebio.aegle import screen_runs, rcache
from livemorebio.life_patch.gateway import LifePatchGateway
from livemorebio.life_system.reference.sources import base
from livemorebio.cendos.lims.db import DEFAULT_DB
from livemorebio.evidence.signing import IssuerSigner
root = Path(os.environ['LIVEMORE_DATA_DIR'])
gateway = LifePatchGateway()
signer = IssuerSigner.load(root / 'evidence-exports')
for path in (screen_runs.run_dir(), rcache.CACHE_DIR, base.CACHE_DIR, DEFAULT_DB,
             gateway.journal_path, gateway.device_path, gateway.command_path, signer.key_path):
    assert Path(path).resolve().is_relative_to(root)
"""
    result = subprocess.run([sys.executable, "-c", code], env=env,
                            capture_output=True, text=True, timeout=30, encoding="utf-8")
    assert result.returncode == 0, result.stderr


@pytest.mark.parametrize("directory", ["virtual-executions", "population-sources"])
def test_new_research_roots_cannot_follow_shared_directory_aliases(tmp_path, directory):
    module = _review_launcher()
    root, external = tmp_path / "review", tmp_path / "external"
    root.mkdir(mode=0o700)
    external.mkdir(mode=0o700)
    (root / directory).symlink_to(external, target_is_directory=True)
    with pytest.raises(ValueError):
        module.prepare_review_environment(root, inherited={})


def test_isolated_execution_and_virtual_store_consumers_are_separate_typed_databases(tmp_path):
    module = _review_launcher()
    root, env = module.prepare_review_environment(tmp_path, inherited=os.environ)
    code = """
import os
from pathlib import Path
from livemorebio.aegle.execution_store import ExecutionStore
from livemorebio.life_patch.virtual_session_store import VirtualSessionStore
from livemorebio.aegle.population_sources import source_status
from livemorebio.security import patch_storage_key
root = Path(os.environ['LIVEMORE_DATA_DIR'])
key = patch_storage_key(create=False)
executor = ExecutionStore(Path(os.environ['LIVEMORE_EXECUTION_STORE']),key=key)
consumer = VirtualSessionStore(Path(os.environ['LIVEMORE_VIRTUAL_EXECUTION_STORE']),key=key)
assert executor.path != consumer.path
assert executor.path.is_relative_to(root) and consumer.path.is_relative_to(root)
assert source_status(os.environ['LIVEMORE_POPULATION_SOURCE_DIR'])['state'] == 'missing'
"""
    result = subprocess.run([sys.executable, "-B", "-c", code], env=env,
                            capture_output=True, text=True, timeout=30, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_review_data_scopes_bus_audit_evidence_and_licensed_store(tmp_path):
    code = """
import os
from pathlib import Path
from livemorebio import registry, bus, audit
from livemorebio.aegle import evidence_api
from livemorebio.life_system.reference.sources.licensed_import import LicensedReferenceStore
root = Path(os.environ['LIVEMORE_DATA_DIR']).resolve()
for path in (registry.REG, bus.EVENTS, bus.SNAP_DIR, audit.LOG_PATH, audit.KEY_PATH,
             evidence_api.DB_PATH, evidence_api.EXPORT_DIR, LicensedReferenceStore().directory):
    assert Path(path).resolve().is_relative_to(root)
bus.set_snapshot('review-only', {'source': 'TECHNICAL_FIXTURE'})
assert bus.snapshot('review-only')['source'] == 'TECHNICAL_FIXTURE'
assert 'TECHNICAL_FIXTURE' not in (Path(bus.SNAP_DIR) / 'review-only.json').read_text(encoding='utf-8')
"""
    env = {key: value for key, value in os.environ.items()
           if not key.startswith("LIVEMORE_")}
    env.update(LIVEMORE_DATA_DIR=str(tmp_path),
               LIVEMORE_PATCH_STORAGE_KEY=base64.urlsafe_b64encode(b"r" * 32).decode())
    result = subprocess.run([sys.executable, "-c", code], env=env,
                            capture_output=True, text=True, timeout=30, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_legacy_capture_binds_assayed_profile_not_later_live_state():
    page = (Path(__file__).parents[1] / "aegle/console/cendos.html").read_text(encoding="utf-8")
    capture = page.split("async function captureRun(spec,d){", 1)[1].split("function bar(", 1)[0]
    assert "d.assayed_profile_params" in capture
    assert "d.assayed_pk_context" in capture
    assert "fetch('/api/state'" not in capture


def test_review_shutdown_reaps_only_owned_children_after_stream_timeout():
    module = _review_launcher()
    class Child:
        def __init__(self, stuck=False):
            self.stuck, self.terminated, self.killed, self.waits = stuck, False, False, 0
        def poll(self):
            return None
        def terminate(self):
            self.terminated = True
        def kill(self):
            self.killed = True
        def wait(self, timeout):
            self.waits += 1
            if self.stuck and not self.killed:
                raise subprocess.TimeoutExpired("owned-review-child", timeout)
            return 0
    stuck, responsive = Child(True), Child()
    module.stop_review_children([stuck, responsive])
    assert stuck.terminated and stuck.killed and stuck.waits == 2
    assert responsive.terminated and not responsive.killed and responsive.waits == 1


def test_review_main_replaces_ignored_sigint_and_reaps_technical_children(tmp_path, monkeypatch):
    """Technical children and probes exercise main without a process or listener."""
    from types import SimpleNamespace

    module = _review_launcher()
    handlers = {signal.SIGINT: signal.SIG_IGN}
    children = []

    class TechnicalProbe:
        def bind(self, address):
            assert address[1] not in (8850, 8851, 8852)

        def close(self):
            pass

    class TechnicalChild:
        terminated = False
        reaped = False

        def __init__(self, *args, **kwargs):
            children.append(self)

        def poll(self):
            return None

        def terminate(self):
            self.terminated = True

        def wait(self, timeout):
            self.reaped = True
            return 0

    def interrupt(_seconds):
        assert len(children) == 3
        assert callable(handlers[signal.SIGINT]), "runner retained inherited SIG_IGN"
        handlers[signal.SIGINT](signal.SIGINT, None)

    monkeypatch.setattr(module, "socket", SimpleNamespace(socket=TechnicalProbe))
    monkeypatch.setattr(module.subprocess, "Popen", TechnicalChild)
    # The stand-in returns what the real function always sets for the NEW-5c launch:
    # one loopback identity authority per role, at the runner's three ports.
    technical_env = {variable: f"http://127.0.0.1:{29871 + offset}"
                     for offset, variable in enumerate(module._IDENTITY_AUTHORITIES.values())}
    monkeypatch.setattr(module, "prepare_review_environment", lambda *args, **kwargs: (tmp_path, technical_env))
    monkeypatch.setattr(module.signal, "signal", lambda signum, handler: handlers.__setitem__(signum, handler))
    monkeypatch.setattr(module.time, "sleep", interrupt)
    with pytest.raises(SystemExit) as caught:
        module.main(["--data-dir", str(tmp_path), "--base-port", "29871"])
    assert caught.value.code == 0
    assert all(child.terminated and child.reaped for child in children)
