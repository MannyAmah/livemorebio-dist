"""Launcher-authorized document wiring; technical credentials, no lifespan or model."""
from types import SimpleNamespace

import pytest
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response
from fastapi.testclient import TestClient

from livemorebio import security


TOKEN = "technical-navigation-credential"
ORIGIN = "http://127.0.0.1:8850"
DOCUMENTS = ("/", "/legacy", "/twins", "/cohorts", "/biology", "/patch",
             "/cendos", "/adapters", "/research")
NAV = {"Sec-Fetch-Mode": "navigate", "Sec-Fetch-Dest": "document",
       "Sec-Fetch-Site": "none"}


@pytest.fixture
def actual(monkeypatch):
    from livemorebio.aegle import server

    monkeypatch.setenv(security.TOKEN_ENV, TOKEN)
    calls = []

    def getter():
        calls.append("registry")
        return SimpleNamespace(get_twin=lambda twin_id: {"twin_id": twin_id})

    monkeypatch.setattr(server, "_subject_registry", getter)
    client = TestClient(server.app, base_url=ORIGIN, client=("127.0.0.1", 45678))
    yield client, calls
    client.close()


def assert_cookie(response):
    assert response.status_code == 200
    assert '<meta http-equiv="refresh" content="0;url=/">' in response.text
    assert "location" not in response.headers
    assert TOKEN not in response.text
    assert "no-store" in response.headers["cache-control"]
    cookie = response.headers["set-cookie"]
    assert f"{security.session_cookie_name(8850)}=" in cookie
    assert TOKEN not in cookie
    for flag in ("HttpOnly", "SameSite=strict", "Path=/"):
        assert flag in cookie
    for absent in ("Domain=", "Max-Age=", "Expires="):
        assert absent not in cookie


@pytest.mark.parametrize("path", DOCUMENTS)
def test_actual_document_requires_launcher_before_protected_request(actual, path):
    client, calls = actual
    assert client.get("/api/twins/twin-technical-navigation").status_code == 401
    assert calls == []
    document = client.get(path, headers=NAV)
    assert document.status_code == 200 and "set-cookie" not in document.headers
    issued = client.post("/api/session/code", headers={"Authorization": f"Bearer {TOKEN}"})
    assert issued.status_code == 200
    assert_cookie(client.post("/api/session/exchange", data={"code": issued.json()["code"]}, follow_redirects=False))
    read = client.get("/api/twins/twin-technical-navigation", headers={"Sec-Fetch-Site": "same-origin", "Origin": ORIGIN})
    assert read.status_code == 200
    assert calls == ["registry"]
    assert read.headers.get("set-cookie") is None


@pytest.mark.parametrize("headers", [
    {}, {**NAV, "Sec-Fetch-Mode": "cors"}, {**NAV, "Sec-Fetch-Dest": "iframe"},
    {**NAV, "Sec-Fetch-Site": "cross-site"}, {**NAV, "Sec-Fetch-Site": "same-site"},
    {**NAV, "Sec-Fetch-Site": "none, same-origin"}, {**NAV, "Sec-Fetch-Mode": ""},
    {**NAV, "Origin": "https://127.0.0.1:8850"},
    {**NAV, "Origin": "http://127.0.0.1:8851"}, {**NAV, "Origin": "null"},
    {**NAV, "Origin": "http://attacker.invalid"},
    {**NAV, "Origin": "http://user@127.0.0.1:8850"},
    {**NAV, "Origin": ORIGIN + "/path"}, {**NAV, "Origin": ORIGIN + "?query"},
])
def test_ineligible_navigation_does_not_authorize(actual, headers):
    client, calls = actual
    response = client.get("/biology", headers=headers)
    assert response.status_code == 200
    assert "set-cookie" not in response.headers
    assert client.post("/api/twins", json={}).status_code == 401
    assert calls == []


@pytest.mark.parametrize("site", ["none", "same-origin"])
def test_valid_same_origin_navigation(actual, site):
    client, _ = actual
    assert "set-cookie" not in client.get("/", headers={**NAV, "Sec-Fetch-Site": site, "Origin": ORIGIN}).headers


@pytest.mark.parametrize("host", ["localhost:8850", "[::1]:8850"])
def test_local_launcher_aliases(actual, host):
    client, _ = actual
    assert "set-cookie" not in client.get("/", headers={**NAV, "Host": host}).headers


def test_non_loopback_authority_does_not_issue(actual):
    client, _ = actual
    response = client.get("/", headers={**NAV, "Host": "public.example"})
    assert response.status_code == 400
    assert "set-cookie" not in response.headers


@pytest.mark.parametrize("token", ["", "\n", "non-ascii-\u00e9", "x" * 4097, "a\x00b"])
def test_missing_or_invalid_token_preserves_static_shell(actual, monkeypatch, token):
    client, _ = actual
    monkeypatch.setattr(security, "_operator_token", lambda: token)
    response = client.get("/", headers=NAV)
    assert response.status_code == 200
    assert "set-cookie" not in response.headers


@pytest.mark.parametrize("failure", [OSError, UnicodeError])
def test_unreadable_token_does_not_destroy_static_navigation(actual, monkeypatch, failure):
    client, _ = actual

    def unavailable():
        raise failure("TECHNICAL_PRIVATE_TOKEN_FAILURE")

    monkeypatch.setattr(security, "_operator_token", unavailable)
    response = client.get("/", headers=NAV)
    assert response.status_code == 200
    assert "set-cookie" not in response.headers
    assert "TECHNICAL_PRIVATE" not in response.text


@pytest.mark.parametrize("path", ["/lib/auth.js", "/not-an-approved-document", "/openapi.json"])
def test_non_document_paths_never_read_or_issue_credential(actual, monkeypatch, path):
    client, _ = actual
    monkeypatch.setattr(security, "_operator_token", lambda: pytest.fail("non-document credential read"))
    assert "set-cookie" not in client.get(path, headers=NAV).headers


@pytest.mark.parametrize("headers", [NAV, {}, {**NAV, "Origin": "http://evil.invalid"}])
def test_retired_bootstrap_is_always_410_without_credential_access(actual, monkeypatch, headers):
    client, calls = actual
    monkeypatch.setattr(security, "_operator_token", lambda: pytest.fail("retired credential read"))
    response = client.get("/api/session/bootstrap", headers=headers)
    assert response.status_code == 410
    assert response.json() == {"error": "Run livemore open in your terminal to restore console authorization."}
    assert "set-cookie" not in response.headers
    assert "no-store" in response.headers["cache-control"]
    assert calls == []


@pytest.mark.parametrize("status,media", [(302, "text/html"), (404, "text/html"),
                                         (500, "text/html"), (200, "application/json")])
def test_hook_rejects_non_successful_html(status, media, monkeypatch):
    app = FastAPI()
    security.install_mutation_auth(app, session_document_paths=frozenset({"/"}))
    monkeypatch.setattr(security, "_operator_token", lambda: pytest.fail("non-document credential read"))

    @app.get("/")
    def page():
        return Response("technical", status_code=status, media_type=media)

    client = TestClient(app, base_url=ORIGIN)
    try:
        assert "set-cookie" not in client.get("/", headers=NAV, follow_redirects=False).headers
    finally:
        client.close()


def test_shared_auth_default_is_opt_out_and_preserves_cli_cookie_rules(monkeypatch):
    app = FastAPI()
    security.install_mutation_auth(app)
    monkeypatch.setenv(security.TOKEN_ENV, TOKEN)
    calls = []

    @app.get("/")
    def page():
        return HTMLResponse("technical")

    @app.post("/api/owned")
    def owned():
        calls.append(True)
        return JSONResponse({"accepted": True})

    client = TestClient(app, base_url=ORIGIN)
    try:
        assert "set-cookie" not in client.get("/", headers=NAV).headers
        assert client.post("/api/owned").status_code == 401
        client.cookies.set(security.SESSION_COOKIE, TOKEN)
        for headers in ({"Sec-Fetch-Site": "none"}, {"Sec-Fetch-Site": "cross-site"},
                        {"Origin": "http://evil.invalid"}, {"Authorization": "Bearer invalid"}):
            expected = 403 if headers.get("Sec-Fetch-Site") == "cross-site" else 401
            assert client.post("/api/owned", headers=headers).status_code == expected
        assert calls == []
        assert client.post("/api/owned", headers={"Origin": ORIGIN}).status_code == 401
        assert client.post("/api/owned", headers={"Authorization": f"Bearer {TOKEN}",
                                                 "Sec-Fetch-Site": "cross-site"}).status_code == 403
        assert calls == []
        assert client.post("/api/owned", headers={"Authorization": f"Bearer {TOKEN}"}).status_code == 200
        assert len(calls) == 1
    finally:
        client.close()


@pytest.mark.parametrize("header", ["Sec-Fetch-Mode", "Sec-Fetch-Dest", "Sec-Fetch-Site", "Origin", "Host"])
def test_duplicate_navigation_metadata_is_ambiguous(actual, header):
    client, _ = actual
    headers = {**NAV, "Host": "127.0.0.1:8850", "Origin": ORIGIN}
    response = client.get("/", headers=[*headers.items(), (header, headers[header])])
    assert response.status_code == (400 if header == "Host" else 200)
    assert "set-cookie" not in response.headers


def test_explicit_zero_port_is_not_default_port(actual):
    client, _ = actual
    response = client.get("/", headers={**NAV, "Host": "127.0.0.1", "Origin": "http://127.0.0.1:0"})
    assert response.status_code == 200
    assert "set-cookie" not in response.headers


@pytest.mark.parametrize("method", ["HEAD", "POST", "OPTIONS"])
def test_only_get_can_issue_even_when_route_returns_html(method, monkeypatch):
    app = FastAPI()
    security.install_mutation_auth(app, session_document_paths=frozenset({"/"}))
    monkeypatch.setenv(security.TOKEN_ENV, TOKEN)
    monkeypatch.setattr(security, "_operator_token", lambda: pytest.fail("non-GET credential read"))

    @app.api_route("/", methods=[method])
    def page():
        return HTMLResponse("technical")

    client = TestClient(app, base_url=ORIGIN)
    try:
        response = client.request(method, "/", headers={**NAV, "Authorization": f"Bearer {TOKEN}"})
        assert response.status_code == 200
        assert "set-cookie" not in response.headers
    finally:
        client.close()


def test_private_launcher_file_fallback_does_not_enable_env_only_mutation(actual, monkeypatch, tmp_path):
    from livemorebio import registry

    client, calls = actual
    monkeypatch.delenv(security.TOKEN_ENV)
    monkeypatch.setattr(registry, "REG_DIR", str(tmp_path))
    assert "set-cookie" not in client.get("/", headers=NAV).headers
    assert client.get("/api/twins/twin-technical-navigation").status_code == 503
    (tmp_path / "api-token").write_text(TOKEN, encoding="utf-8")
    assert "set-cookie" not in client.get("/", headers=NAV).headers
    assert client.get("/api/twins/twin-technical-navigation", headers={"Authorization": f"Bearer {TOKEN}"}).status_code == 200
    assert client.post("/api/twins", json={}).status_code == 503
    assert calls == ["registry"]
