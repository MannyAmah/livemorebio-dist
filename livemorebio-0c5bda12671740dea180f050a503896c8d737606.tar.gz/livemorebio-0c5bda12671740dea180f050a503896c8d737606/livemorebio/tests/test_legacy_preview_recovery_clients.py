"""Authored preview transport fixtures, never a person, source, service or model."""
from copy import deepcopy
import json
from types import SimpleNamespace

import pytest

from livemorebio.tests.stack_client_fixtures import install_stack_client_opener

from livemorebio import audit, execution_client
from livemorebio.execution_client import ContinuousClientError
from livemorebio.sdk import Platform
from livemorebio.shell import run_command, run_pipeline
from .test_frozen_member_response_limits import ByteResponse, REQUEST_ID, attached

PRIVATE = "AUTHORED_PRIVATE_PREVIEW_SENTINEL"
PARAMS = dict(name="technical-preview", weight_kg=70, Gb=90, Ib=9, SG=.026,
              p2=.025, Si=.0005, gamma=.12, Gt=100, n=.14, ka=.02,
              f_bioavail=.75, vg_per_kg=2)


def preview():
    return {"profile": "technical-preview", "base": "healthy", "profile_params": dict(PARAMS),
        "model_availability": {"schema": "livemore.model-availability.v1", "state": "READY",
            "reason_code": None, "selection_mode": "reference_preview", "twin_id": None,
            "twin_version": 0, "source_generation": "technical-generation", "preparation_available": True},
        "systems": [{"name": "Authored system", "status": "pending"}], "human": None,
        "patch": {}, "observations": {}, "applied": [], "intervention": None,
        "metabolic": {"t_min": [0, 1], "glucose": [90, 91], "insulin": [9, 10],
            "mean_glucose": 90.5, "summary": {"peak": 91}},
        "cardiac": {"t_ms": [0, 1], "v": [-80, 10], "cai": [.0001, .0002],
            "vrest": -80, "vpeak": 10, "apd90_ms": 250, "cai_peak_uM": .2,
            "ikr_block": 0, "hr_bpm": 60, "hrv_ms": 30, "cl_ms": 1000}}


@pytest.fixture(autouse=True)
def no_legacy_transport_or_local_audit(monkeypatch):
    monkeypatch.setattr(Platform, "_post", lambda *a, **k: pytest.fail("preview used legacy _post"))
    monkeypatch.setattr(Platform, "_get", lambda *a, **k: pytest.fail("unexpected legacy read"))
    monkeypatch.setattr(audit, "record", lambda *a, **k: None)


@pytest.mark.parametrize("arguments,path,body", [
    ({"base": "healthy"}, "/api/stimulate", {"kind": "base", "params": {"base": "healthy"}}),
    ({"base": "t2d"}, "/api/stimulate", {"kind": "base", "params": {"base": "t2d"}}),
    ({"base": "type-2-diabetes"}, "/api/stimulate", {"kind": "base", "params": {"base": "type-2-diabetes"}}),
    # L0-R15: patient(note=...) is refused before any request; test_l0_clinical_note_gate.py holds it.
    ({}, "/api/stimulate", {"kind": "life_system", "params": {"mode": "custom", "id": "LMB-SDK", "age": 50,
        "sex": "F", "conditions": [], "genome": {}, "lifestyle": .6}}),
    # L0-R15 round 1: structured fields take technical values only; free text in them is refused
    # before any request (test_l0_free_text_gate.py holds that).
    ({"age": 45, "sex": "M", "conditions": ["Type 2 diabetes mellitus"], "genome": {"TCF7L2": 1}, "lifestyle": .7},
        "/api/stimulate", {"kind": "life_system", "params": {"mode": "custom", "id": "LMB-SDK", "age": 45,
        "sex": "M", "conditions": ["Type 2 diabetes mellitus"], "genome": {"TCF7L2": 1}, "lifestyle": .7}}),
])
def test_attached_patient_exact_once_preserves_body_and_summary(monkeypatch, arguments, path, body):
    expected, original = preview(), deepcopy(arguments)
    response = ByteResponse(json.dumps(expected).encode())
    platform, calls = attached(monkeypatch, response)
    result = platform.patient(**arguments)
    assert arguments == original and len(calls) == 1 and response.closed == 1
    assert calls[0].method == "POST" and calls[0].full_url.endswith(path)
    assert json.loads(calls[0].data) == body and calls[0].get_header("Idempotency-key") is None
    assert result == platform._summary(expected)
    assert platform.last_continuous_response["request_id"] == REQUEST_ID


@pytest.mark.parametrize("status,code", [(503, "SELECTION_COMMIT_UNCONFIRMED"),
    (503, "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"), (503, "REGISTRY_STORAGE_UNAVAILABLE"),
    (409, "MODEL_SOURCE_CHANGED"), (422, "INVALID_NOTE"), (422, "INVALID_INTERVENTION"),
    (401, "CLIENT_AUTH_REQUIRED"), (403, "CLIENT_AUTH_REQUIRED")])
def test_preview_typed_rejection_preserves_own_request_no_summary_or_audit(monkeypatch, status, code):
    response = ByteResponse(json.dumps({"code": code, "error": PRIVATE}).encode(), status=status)
    platform, calls = attached(monkeypatch, response)
    monkeypatch.setattr(platform, "_summary", lambda *a: pytest.fail("error became summary"))
    monkeypatch.setattr(audit, "record", lambda *a, **k: pytest.fail("error became success audit"))
    with pytest.raises(ContinuousClientError) as caught:
        platform.patient(base="healthy")  # L0-R15: the technical route, not the refused note
    error = caught.value
    assert (error.code, error.status, error.request_id) == (code, status, REQUEST_ID)
    assert PRIVATE not in str(error) and len(calls) == response.closed == 1


@pytest.mark.parametrize("change", [
    lambda x: x.clear(), lambda x: x.update(code="PRIVATE"), lambda x: x.update(profile_params=None),
    lambda x: x.update(profile_params=[]), lambda x: x["profile_params"].pop("Si"),
    lambda x: x["profile_params"].update(Gb=True), lambda x: x.update(metabolic=None),
    lambda x: x["model_availability"].update(selection_mode="model", twin_id="other", twin_version=2),
    lambda x: x["model_availability"].update(state="UNAVAILABLE"),
    lambda x: x["model_availability"].update(source_generation=""),
    lambda x: x["model_availability"].update(twin_version=True),
    lambda x: x.pop("model_availability"), lambda x: x.update(human=[]),
])
def test_malformed_preview_ack_is_not_success(monkeypatch, change):
    value = preview(); change(value)
    platform, calls = attached(monkeypatch, ByteResponse(json.dumps(value).encode()))
    monkeypatch.setattr(audit, "record", lambda *a, **k: pytest.fail("invalid ACK audited"))
    with pytest.raises(ContinuousClientError) as caught:
        platform.patient(base="healthy")
    assert caught.value.code == "CLIENT_UNCONFIRMED" and caught.value.request_id == REQUEST_ID
    assert len(calls) == 1


@pytest.mark.parametrize("header", [None, "a" * 32, REQUEST_ID.upper(), PRIVATE])
def test_preview_requires_current_uuid_not_cached_request(monkeypatch, header):
    response = ByteResponse(json.dumps(preview()).encode())
    response.headers = {} if header is None else {"X-Request-ID": header}
    platform, calls = attached(monkeypatch, response)
    platform.last_continuous_response = {"request_id": REQUEST_ID}
    with pytest.raises(ContinuousClientError) as caught:
        platform.patient(base="healthy")
    assert caught.value.code == "CLIENT_UNCONFIRMED" and caught.value.request_id is None
    assert len(calls) == 1


@pytest.mark.parametrize("raw,status", [(b'{"x":1,"x":2}', 200), (b'{"x":NaN}', 200),
    (b'{}', 201), (b'{"x":"\xff"}', 200), (b'[]', 200), (b'{"code":"PRIVATE"}', 503)])
def test_strict_error_body_is_safe_once(monkeypatch, raw, status):
    platform, calls = attached(monkeypatch, ByteResponse(raw, status=status))
    with pytest.raises(ContinuousClientError) as caught:
        platform.patient(base="healthy")
    assert caught.value.code in {"CLIENT_UNCONFIRMED", "CLIENT_RESPONSE"}
    assert caught.value.request_id == REQUEST_ID and len(calls) == 1
    assert "PRIVATE" not in str(caught.value)


@pytest.mark.parametrize("size", [16 * 1024 + 1, 2_000_000, 2_000_001])
def test_named_preview_request_exact_cap_preserves_default_limit(monkeypatch, size):
    # L0-R15: the technical life_system route carries the padding; the note route is refused.
    platform, calls = attached(monkeypatch, ByteResponse(b'{}'))
    padding = "x" * (size - len(b'{"kind":"life_system","params":{"mode":"custom","id":""}}'))
    body = {"kind": "life_system", "params": {"mode": "custom", "id": padding}}
    if size > 2_000_000:
        with pytest.raises(ContinuousClientError):
            platform._research_preview_request("/api/stimulate", body)
        assert not calls
    else:
        assert platform._research_preview_request("/api/stimulate", body) == {}
        assert len(calls) == 1 and len(calls[0].data) == size
    calls.clear()
    with pytest.raises(ContinuousClientError):
        platform._continuous_request("POST", "/api/stimulate", body)
    assert not calls
    assert execution_client.MAX_REQUEST_BYTES == 16384 and execution_client.MAX_RESPONSE_BYTES == 8 * 1024**2


@pytest.mark.parametrize("path,body", [
    ("https://unapproved.invalid", {"text": "x"}), ("/api/ingest_note?x=1", {"text": "x"}),
    ("/api/stimulate", {"kind": "meal", "params": {}}), ("/api/stimulate", {"kind": "base", "params": []}),
    ("/api/stimulate", {"kind": "base", "params": {"base": "unknown"}}),
    ("/api/stimulate", {"kind": "life_system", "params": {"mode": "unknown"}}),
    ("/api/ingest_note", {"text": " "}), ("/api/ingest_note", {"text": 3}),
    ("/api/ingest_note", {"text": "x", "extra": True}),
])
def test_named_preview_transport_cannot_expand_endpoint_scope(monkeypatch, path, body):
    platform, calls = attached(monkeypatch, ByteResponse(b'{}'))
    if path == "/api/ingest_note":
        # L0-R15: the note path is refused before its body is validated or sent.
        from .test_l0_clinical_note_gate import assert_note_refused
        assert_note_refused(lambda: platform._research_preview_request(path, body))
    else:
        with pytest.raises(ContinuousClientError):
            platform._research_preview_request(path, body)
    assert not calls


@pytest.mark.parametrize("bad", [float("nan"), float("inf"), (1, 2), {1: "x"}, {"x": object()}, 2**53])
def test_named_request_json_domain_no_silent_coercion(monkeypatch, bad):
    platform, calls = attached(monkeypatch, ByteResponse(b'{}'))
    with pytest.raises(ContinuousClientError):
        platform._research_preview_request("/api/stimulate", {"kind": "life_system", "params": {"genome": bad}})
    assert not calls


def test_named_request_cycle_and_inprocess_never_dispatch(monkeypatch):
    platform, calls = attached(monkeypatch, ByteResponse(b'{}'))
    value = {}; value["cycle"] = value
    with pytest.raises(ContinuousClientError):
        platform._research_preview_request("/api/stimulate", {"kind": "life_system", "params": value})
    platform.mode = "inprocess"
    with pytest.raises(ContinuousClientError) as caught:
        platform._research_preview_request("/api/stimulate", {"kind": "base", "params": {}})  # L0-R15
    assert caught.value.code == "CLIENT_ATTACH_REQUIRED" and not calls


@pytest.mark.parametrize("kind", ["note", "base", "life_system"])
def test_attached_success_audit_contains_only_approved_metadata(monkeypatch, kind):
    platform, calls = attached(monkeypatch, ByteResponse(json.dumps(preview()).encode()))
    audits = []
    monkeypatch.setattr(audit, "record", lambda *a, **k: audits.append((a, k)))
    # L0-R15 round 1: structured fields are vocabulary terms; the audit must still hold none of them.
    arguments = {"note": PRIVATE} if kind == "note" else {"base": "healthy"} if kind == "base" else {
        "conditions": ["Type 2 diabetes mellitus"], "genome": {"TCF7L2": 1}}
    if kind == "note":
        # L0-R15: a refused note sends nothing and audits nothing.
        from .test_l0_clinical_note_gate import assert_note_refused
        assert_note_refused(lambda: platform.patient(**arguments))
        assert audits == [] and calls == []
        return
    platform.patient(**arguments)
    assert audits == [(("research_preview.request", {"family": kind},
                       {"outcome": "ACKNOWLEDGED", "request_id": REQUEST_ID}), {})]
    assert PRIVATE not in json.dumps(audits) and len(calls) == 1


@pytest.mark.parametrize("failure", ["close", "audit", "both"])
def test_local_failure_cannot_erase_confirmed_preview(monkeypatch, failure):
    response = ByteResponse(json.dumps(preview()).encode())
    if failure in {"close", "both"}:
        response.close = lambda: (_ for _ in ()).throw(OSError(PRIVATE))
    platform, calls = attached(monkeypatch, response)
    if failure in {"audit", "both"}:
        monkeypatch.setattr(audit, "record", lambda *a, **k: (_ for _ in ()).throw(OSError(PRIVATE)))
    result = platform.patient(base="healthy")
    assert result["mean_glucose"] == 90.5 and len(calls) == 1
    meta = platform.last_continuous_response
    assert meta["request_id"] == REQUEST_ID
    if failure in {"close", "both"}: assert meta["cleanup_code"] == "CLIENT_TRANSPORT"
    if failure in {"audit", "both"}: assert meta["audit_code"] == "CLIENT_AUDIT_UNCONFIRMED"
    assert PRIVATE not in json.dumps(meta)


@pytest.mark.parametrize("line", [f'patient note "{PRIVATE}"', f'pa"tient" note "{PRIVATE}"',
    f'patient conditions={PRIVATE} genome={PRIVATE}', f'patient note "{PRIVATE}', f'pa"tient" note "{PRIVATE}'])
def test_pipeline_patient_echo_is_redacted_even_malformed(monkeypatch, tmp_path, line):
    path = tmp_path / "authored.pipeline"
    path.write_text(line + "\nshow state\n", encoding="utf-8")
    calls, output = [], []
    class Client:
        mode = "attach"
        def patient(self, **kwargs):
            calls.append(kwargs)
            raise ContinuousClientError("SELECTION_COMMIT_UNCONFIRMED", status=503, request_id=REQUEST_ID)
        def state(self): pytest.fail("pipeline continued after uncertainty")
    if " note " in line:
        # L0-R15: a note line is refused before it is parsed; the pipeline reports and stops.
        from .test_l0_clinical_note_gate import CODE, REASON
        run_pipeline(Client(), str(path), out=output.append)
        assert output == ["livemore› patient", f"  refused [{CODE}]: {REASON}"]
        assert PRIVATE not in str(output) and calls == []
        return
    with pytest.raises(ContinuousClientError):
        run_pipeline(Client(), str(path), out=output.append)
    assert output == ["livemore› patient"] and PRIVATE not in str(output)
    assert len(calls) == (0 if line.count('"') % 2 else 1)


def test_terminal_success_keeps_result_and_fixed_warning(monkeypatch):
    platform, calls = attached(monkeypatch, ByteResponse(json.dumps(preview()).encode()))
    monkeypatch.setattr(audit, "record", lambda *a, **k: (_ for _ in ()).throw(OSError(PRIVATE)))
    lines = []
    result = run_command(platform, "patient healthy", out=lines.append)
    assert result is None and len(calls) == 1  # Preserve the old command return contract.
    joined = "\n".join(lines)
    assert "90.5" in joined
    assert "ACKNOWLEDGED" in joined and "research-preview" in joined
    assert REQUEST_ID in joined and "CLIENT_AUDIT_UNCONFIRMED" in joined and PRIVATE not in joined


def test_repl_typed_preview_error_keeps_recovery_prompt(monkeypatch, capsys):
    from livemorebio import shell
    calls = []
    class Client:
        def __init__(self, mode): assert mode == "attach"
        def state(self): return {"profile": "technical"}
        def patient(self, **kwargs):
            calls.append(kwargs)
            raise ContinuousClientError("SELECTION_COMMITTED_CLEANUP_UNCONFIRMED", status=503, request_id=REQUEST_ID)
    monkeypatch.setattr(shell, "Platform", Client)
    commands = iter(["patient healthy", "exit"])
    monkeypatch.setattr("builtins.input", lambda prompt: next(commands))
    shell.run_shell(mode="attach")
    output = capsys.readouterr().out
    assert len(calls) == 1 and "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED" in output
    assert "show state" in output and "twin list" in output and REQUEST_ID in output


@pytest.mark.parametrize("failure", ["timeout", "read", "encoding", "close_rejection"])
def test_named_preview_transport_failure_receipts_are_once_only(monkeypatch, failure):
    response = ByteResponse(b'{}')
    platform, calls = attached(monkeypatch, response)
    if failure == "timeout":
        def opener(*handlers):
            def fail(request, timeout):
                calls.append(request);assert timeout == 60
                raise TimeoutError(PRIVATE)
            return SimpleNamespace(open=fail)
        install_stack_client_opener(monkeypatch, opener)
    elif failure == "read":
        response.failure = OSError(PRIVATE)
    elif failure == "encoding":
        response.headers["Content-Encoding"] = "gzip"
    else:
        response.status = 503
        response.raw = b'{"code":"SELECTION_COMMIT_UNCONFIRMED"}'
        response.close = lambda: (_ for _ in ()).throw(OSError(PRIVATE))
    with pytest.raises(ContinuousClientError) as caught:
        platform.patient(base="healthy")  # L0-R15: the technical route, not the refused note
    assert len(calls) == 1 and PRIVATE not in str(caught.value)
    assert caught.value.request_id == (None if failure == "timeout" else REQUEST_ID)
    assert caught.value.code == ("SELECTION_COMMIT_UNCONFIRMED" if failure == "close_rejection" else "CLIENT_UNCONFIRMED")
    if failure == "close_rejection":
        assert platform.last_continuous_response["cleanup_code"] == "CLIENT_TRANSPORT"


@pytest.mark.parametrize("size", [8 * 1024**2, 8 * 1024**2 + 1])
def test_named_preview_response_limit_is_still8mib(monkeypatch, size):
    raw = b'{"padding":"' + b'x' * (size - len(b'{"padding":""}')) + b'"}'
    response = ByteResponse(raw)
    platform, calls = attached(monkeypatch, response)
    body = {"kind": "base", "params": {"base": "healthy"}}  # L0-R15: not the refused note route
    if size > 8 * 1024**2:
        with pytest.raises(ContinuousClientError) as caught:
            platform._research_preview_request("/api/stimulate", body)
        assert caught.value.code == "CLIENT_UNCONFIRMED"
    else:
        result = platform._research_preview_request("/api/stimulate", body)
        assert len(result["padding"]) == size - len(b'{"padding":""}')
    assert len(calls) == response.closed == 1 and response.read_sizes == [8 * 1024**2 + 1]


def test_actual_cli_pipeline_exits_nonzero_without_continuing_or_echoing_input(monkeypatch, tmp_path, capsys):
    from livemorebio import cli, shell
    path = tmp_path / "authored-failed.pipeline"
    # L0-R15: a structured patient line, since a note line is refused before the SDK.
    path.write_text(f'patient conditions={PRIVATE}\nshow state\n', encoding="utf-8")
    class Client:
        mode = "attach"
        def __init__(self, mode): assert mode == "attach"
        def patient(self, **kwargs):
            raise ContinuousClientError("SELECTION_COMMIT_UNCONFIRMED", status=503, request_id=REQUEST_ID)
        def state(self): pytest.fail("continued after unknown mutation")
    monkeypatch.setattr(shell, "Platform", Client)
    monkeypatch.setattr("sys.argv", ["livemore", "run", str(path), "--attach"])
    with pytest.raises(SystemExit) as caught:
        cli.main()
    assert caught.value.code == 1
    output = capsys.readouterr()
    assert PRIVATE not in output.out + output.err and "SELECTION_COMMIT_UNCONFIRMED" in output.out
    assert REQUEST_ID in output.out and "livemore› patient" in output.out
