"""Runner signal lifecycle using isolated technical state and test-owned loopback services."""
from __future__ import annotations

from dataclasses import dataclass
import errno
import http.client
import http.server
import json
import os
from pathlib import Path
import random
import secrets
import signal
import socket
import subprocess
import sys
import threading
import time
from urllib.error import URLError
from urllib.request import ProxyHandler, build_opener

import pytest

from livemorebio.service_identity import (
    IdentitySnapshot, decode_identity_key, proof_response, verify_proof_response,
)


# Below every default ephemeral range (macOS 49152+, Linux 32768+): no other process's
# port-0 bind or outgoing connection is handed a port here.
_REVIEW_PORTS = range(20000, 30000)
_START_ATTEMPTS = 5
# Proof role and identity authority of each service, in the runner's port order.
_SERVICE_IDENTITIES = (
    ("aegle", "LIVEMORE_AEGLE_IDENTITY_AUTHORITY"),
    ("life", "LIVEMORE_LIFE_IDENTITY_AUTHORITY"),
    ("cendos", "LIVEMORE_CENDOS_IDENTITY_AUTHORITY"),
)
_WRAPPER = """
import json
from pathlib import Path
import signal
import subprocess
import sys
from tools import run_review_stack as runner

signal.signal(signal.SIGINT, signal.SIG_IGN)
assert signal.getsignal(signal.SIGINT) == signal.SIG_IGN
Path(sys.argv[2]).write_text('technical SIGINT disposition: SIG_IGN', encoding='utf-8')
child_pids = []
original_popen = subprocess.Popen
def record_owned_child(*args, **kwargs):
    child = original_popen(*args, **kwargs)
    child_pids.append(child.pid)
    pending = Path(sys.argv[1] + '.pending')
    pending.write_text(json.dumps(child_pids), encoding='utf-8')
    pending.replace(sys.argv[1])
    return child
runner.subprocess.Popen = record_owned_child
raise SystemExit(runner.main(sys.argv[3:]))
"""


def _review_base_candidates() -> tuple[int, ...]:
    # SystemRandom: two suites started together must not walk the same sequence,
    # whatever seed a plugin gives the random module.
    start = random.SystemRandom().randrange(_REVIEW_PORTS.start, _REVIEW_PORTS.stop - 2)
    return (*range(start, _REVIEW_PORTS.stop - 2), *range(_REVIEW_PORTS.start, start))


def _review_base_port(candidates=None) -> int:
    """Three consecutive loopback ports that no socket holds, in any state.

    Each is bound without SO_REUSEADDR, as the runner's own pre-check binds: with it, a
    port that another process's connection holds, or that lingers in TIME_WAIT, looks
    free here and is then refused by the runner.
    """
    for base_port in _review_base_candidates() if candidates is None else candidates:
        probes = []
        try:
            for port in range(base_port, base_port + 3):
                probe = socket.socket()
                probes.append(probe)
                probe.bind(("127.0.0.1", port))
            return base_port
        except PermissionError as error:
            pytest.skip(f"sandbox cannot bind a review-test socket: {error}")
        except OSError:
            # Another socket holds one of the three ports.
            continue
        finally:
            for probe in probes:
                probe.close()
    pytest.fail(f"no three consecutive free loopback ports in {_REVIEW_PORTS.start}-{_REVIEW_PORTS.stop - 1}")


def _process_exists(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    return True


def _process_group_exists(process_group: int) -> bool:
    try:
        os.killpg(process_group, 0)
    except ProcessLookupError:
        return False
    return True


@dataclass
class _ReviewStack:
    process: subprocess.Popen
    base_port: int
    env: dict[str, str]
    pid_path: Path
    ignored_path: Path
    log_path: Path


def _all_services_healthy(stack: _ReviewStack) -> bool:
    """True once all three answer /health; False if the runner exits first."""
    opener = build_opener(ProxyHandler({}))
    ready = set()
    deadline = time.monotonic() + 40
    while time.monotonic() < deadline:
        if stack.process.poll() is not None:
            return False
        for port in range(stack.base_port, stack.base_port + 3):
            try:
                with opener.open(f"http://127.0.0.1:{port}/health", timeout=0.2) as response:
                    if response.status == 200:
                        ready.add(port)
            except (URLError, TimeoutError, ConnectionError):
                pass
        if len(ready) == 3:
            return True
        time.sleep(0.05)
    pytest.fail("review services not healthy within 40 s:\n" + stack.log_path.read_text(encoding="utf-8"))


def _start_review_stack(tmp_path: Path, runner, started: list[_ReviewStack],
                        pick=_review_base_port) -> _ReviewStack:
    """Start the runner, on fresh ports again only when another process took one first."""
    refused = []
    for attempt in range(_START_ATTEMPTS):
        base_port = pick()
        attempt_dir = tmp_path / f"attempt-{attempt}"
        attempt_dir.mkdir()
        root = attempt_dir / "technical-review"
        _, env = runner.prepare_review_environment(root, base_port=base_port)
        technical_home = attempt_dir / "technical-home"
        technical_home.mkdir(mode=0o700)
        env.update(HOME=str(technical_home), PYTHONDONTWRITEBYTECODE="1")
        pid_path = attempt_dir / "technical-child-pids.json"
        ignored_path = attempt_dir / "technical-inherited-sigint.txt"
        log_path = attempt_dir / "technical-runner.log"
        with log_path.open("w", encoding="utf-8") as log:
            # Its own session puts every process the runner starts, at any depth, in one group.
            process = subprocess.Popen(
                [sys.executable, "-B", "-c", _WRAPPER, str(pid_path), str(ignored_path),
                 "--data-dir", str(root), "--base-port", str(base_port)],
                cwd=Path(__file__).parents[2], env=env, stdout=log, stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        stack = _ReviewStack(process, base_port, env, pid_path, ignored_path, log_path)
        started.append(stack)
        if _all_services_healthy(stack):
            return stack
        process.wait(timeout=20)
        output = log_path.read_text(encoding="utf-8")
        # The pre-check's refusal, or a child's bind after it: nothing else is retried.
        assert "address already in use" in output.lower(), output
        assert not _process_group_exists(process.pid), "a refused start left a process behind"
        refused.append(base_port)
    pytest.fail(f"other processes took review ports on every attempt: bases {refused}")


def _proves_identity(port: int, snapshot: IdentitySnapshot) -> bool:
    nonce = secrets.token_bytes(32)
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=3)
    try:
        connection.request("POST", "/api/stack/prove", body=nonce,
                           headers={"Content-Type": "application/octet-stream"})
        response = connection.getresponse()
        return response.status == 200 and verify_proof_response(snapshot, nonce, response.read(97))
    except (OSError, http.client.HTTPException):
        return False
    finally:
        connection.close()


@pytest.mark.parametrize("response_size", [96, 97, 1024 * 1024])
def test_review_identity_proof_read_is_bounded_and_rejects_oversized_bodies(
        monkeypatch: pytest.MonkeyPatch, response_size: int) -> None:
    """Technical in-memory proof bytes; no socket, service or person data."""
    snapshot = IdentitySnapshot((b"technical-proof-key-" * 2)[:32], "aegle", "http://127.0.0.1:21000")
    reads = []
    connections = []

    class TechnicalConnection:
        def __init__(self, host: str, port: int, timeout: float) -> None:
            assert (host, port, timeout) == ("127.0.0.1", 21000, 3)
            self.closed = False
            connections.append(self)

        def request(self, method: str, path: str, *, body: bytes, headers: dict[str, str]) -> None:
            assert (method, path) == ("POST", "/api/stack/prove")
            assert headers == {"Content-Type": "application/octet-stream"}
            self.body = proof_response(snapshot, body, b"technical-instance".ljust(32, b"-"),
                                       b"technical-server-random".ljust(32, b"-"))
            self.body += b"-" * (response_size - len(self.body))

        def getresponse(self) -> TechnicalConnection:
            return self

        status = 200

        def read(self, amount: int = -1) -> bytes:
            reads.append(amount)
            return self.body if amount < 0 else self.body[:amount]

        def close(self) -> None:
            self.closed = True

    monkeypatch.setattr(http.client, "HTTPConnection", TechnicalConnection)
    assert _proves_identity(21000, snapshot) is (response_size == 96)
    assert reads == [97]
    assert len(connections) == 1 and connections[0].closed


def _assert_review_ports_released(stack: _ReviewStack) -> None:
    # Every process the runner started, at any depth, not only the three it recorded.
    assert not _process_group_exists(stack.process.pid), "a process the runner started survived SIGINT"
    key = decode_identity_key(stack.env["LIVEMORE_SERVICE_IDENTITY_KEY"])
    for port, (role, authority) in zip(range(stack.base_port, stack.base_port + 3), _SERVICE_IDENTITIES):
        with socket.socket() as probe:
            # This test's own /health requests leave server-side TIME_WAIT on these ports.
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                probe.bind(("127.0.0.1", port))
            except OSError as error:
                if error.errno != errno.EADDRINUSE:
                    raise
                # Another process may bind a port as soon as it is free. A listener of this
                # runner would still prove the attempt's own identity key; a foreign one cannot.
                snapshot = IdentitySnapshot(key, role, stack.env[authority])
                assert not _proves_identity(port, snapshot), f"review port {port} is still served by this runner"


def _stop_review_stacks(started: list[_ReviewStack]) -> None:
    for stack in started:
        if stack.process.poll() is None:
            stack.process.terminate()
            try:
                stack.process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                stack.process.kill()
                stack.process.wait(timeout=5)
        # Cleanup is limited to what this runner started: the PIDs recorded from its own
        # Popen, and the process group of the session it was started in.
        child_pids = json.loads(stack.pid_path.read_text(encoding="utf-8")) if stack.pid_path.exists() else []
        for pid in child_pids:
            if _process_exists(pid):
                os.kill(pid, signal.SIGKILL)
        try:
            os.killpg(stack.process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass


def test_review_base_port_is_below_every_default_ephemeral_range():
    for _ in range(3):
        base_port = _review_base_port()
        assert _REVIEW_PORTS.start <= base_port and base_port + 2 < _REVIEW_PORTS.stop


def test_review_base_port_passes_over_a_port_held_by_a_connection_as_the_runner_does(tmp_path, capsys):
    from tools import run_review_stack as runner

    held_base = _review_base_port()
    with socket.socket() as listener, socket.socket() as client:
        listener.bind(("127.0.0.1", 0))
        listener.listen()
        # A connection whose local port is held_base + 1, as an outgoing connection's source port.
        client.bind(("127.0.0.1", held_base + 1))
        client.connect(listener.getsockname())
        peer, _ = listener.accept()
        with peer:
            others = (base for base in _review_base_candidates() if abs(base - held_base) > 2)
            assert _review_base_port((held_base, *others)) != held_base
            with pytest.raises(SystemExit) as refused:
                runner.main(["--data-dir", str(tmp_path / "technical-review"), "--base-port", str(held_base)])
    assert refused.value.code == 2
    assert "address already in use" in capsys.readouterr().err.lower()
    assert not (tmp_path / "technical-review").exists()


@pytest.mark.skipif(os.name != "posix", reason="POSIX process groups")
def test_review_start_retries_a_taken_base_only_up_to_its_attempts(tmp_path):
    from tools import run_review_stack as runner

    base_port = _review_base_port()
    started = []
    with socket.socket() as foreign:
        foreign.bind(("127.0.0.1", base_port + 2))
        foreign.listen()
        try:
            with pytest.raises(pytest.fail.Exception, match="on every attempt"):
                _start_review_stack(tmp_path, runner, started, pick=lambda: base_port)
        finally:
            _stop_review_stacks(started)
    assert len(started) == _START_ATTEMPTS
    assert all(stack.process.returncode == 2 for stack in started)
    # Refused at the pre-check: no service was started.
    assert not any(stack.pid_path.exists() for stack in started)


@pytest.mark.skipif(os.name != "posix", reason="POSIX process groups")
def test_review_start_does_not_retry_a_refusal_that_is_not_about_ports(tmp_path, monkeypatch):
    from tools import run_review_stack as runner

    prepare = runner.prepare_review_environment

    def prepare_then_open_to_group(root, **kwargs):
        prepared = prepare(root, **kwargs)
        root.chmod(0o750)
        return prepared

    monkeypatch.setattr(runner, "prepare_review_environment", prepare_then_open_to_group)
    started = []
    try:
        with pytest.raises(AssertionError, match="owner-only permissions"):
            _start_review_stack(tmp_path, runner, started)
    finally:
        _stop_review_stacks(started)
    assert len(started) == 1 and started[0].process.returncode == 2


@pytest.mark.skipif(os.name != "posix", reason="POSIX process groups")
def test_review_port_release_refuses_only_a_listener_that_proves_the_runner_identity(tmp_path):
    from tools import run_review_stack as runner

    base_port = _review_base_port()
    _, env = runner.prepare_review_environment(tmp_path / "technical-review", base_port=base_port)
    key = decode_identity_key(env["LIVEMORE_SERVICE_IDENTITY_KEY"])
    role, authority = _SERVICE_IDENTITIES[1]
    finished = subprocess.Popen([sys.executable, "-c", "pass"], start_new_session=True)
    finished.wait(timeout=20)
    stack = _ReviewStack(finished, base_port, env, tmp_path / "pids", tmp_path / "ignored", tmp_path / "log")

    def serve_proofs(proof_key: bytes) -> http.server.HTTPServer:
        snapshot = IdentitySnapshot(proof_key, role, env[authority])

        class TechnicalProver(http.server.BaseHTTPRequestHandler):
            def do_POST(self):
                nonce = self.rfile.read(int(self.headers["Content-Length"]))
                body = proof_response(snapshot, nonce, secrets.token_bytes(32), secrets.token_bytes(32))
                self.send_response(200)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *args):
                pass

        server = http.server.HTTPServer(("127.0.0.1", base_port + 1), TechnicalProver)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        return server

    for proof_key, held_by_runner in ((secrets.token_bytes(32), False), (key, True)):
        server = serve_proofs(proof_key)
        try:
            if held_by_runner:
                with pytest.raises(AssertionError, match=f"review port {base_port + 1} is still served"):
                    _assert_review_ports_released(stack)
            else:
                _assert_review_ports_released(stack)
        finally:
            server.shutdown()
            server.server_close()

    survivor = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"], start_new_session=True)
    try:
        stack.process = survivor
        with pytest.raises(AssertionError, match="survived SIGINT"):
            _assert_review_ports_released(stack)
    finally:
        survivor.kill()
        survivor.wait(timeout=20)


@pytest.mark.skipif(os.name != "posix", reason="POSIX inherited SIG_IGN regression")
def test_runner_sigint_reaps_live_services_when_started_with_sigint_ignored(tmp_path):
    from tools import run_review_stack as runner

    started = []
    try:
        stack = _start_review_stack(tmp_path, runner, started)
        assert stack.ignored_path.read_text(encoding="utf-8") == "technical SIGINT disposition: SIG_IGN"
        child_pids = json.loads(stack.pid_path.read_text(encoding="utf-8"))
        assert len(child_pids) == 3 and all(_process_exists(pid) for pid in child_pids)

        stack.process.send_signal(signal.SIGINT)
        try:
            returncode = stack.process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            pytest.fail("runner retained inherited SIG_IGN after SIGINT")
        assert returncode == 0, stack.log_path.read_text(encoding="utf-8")
        assert all(not _process_exists(pid) for pid in child_pids)
        _assert_review_ports_released(stack)
    finally:
        _stop_review_stacks(started)
