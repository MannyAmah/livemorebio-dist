"""Acceptance-harness guards; never launch Chrome or access product stores."""
import json
from pathlib import Path
import subprocess
from ._node import require_node

HARNESS = Path(__file__).resolve().parents[2] / "tools/check_atlas_browser.cjs"


def run(script: str) -> None:
    result = subprocess.run(
        [require_node(), "--eval", f"const h=require({json.dumps(str(HARNESS))});" + script],
        capture_output=True, text=True, timeout=15, encoding="utf-8",
    )
    assert result.returncode == 0, result.stderr


def test_atlas_harness_fences_exact_runtime_subject_and_output_before_browser():
    run("""
const a=require('node:assert/strict');
const env={LIVEMORE_BROWSER_BASE:h.PIN.base,LIVEMORE_BROWSER_OUTPUT:'/tmp/atlas-new-attempt',LIVEMORE_BROWSER_TECHNICAL:'1',LIVEMORE_BROWSER_EXPECTED_SOURCE:h.PIN.source,LIVEMORE_BROWSER_TWIN_ID:h.PIN.twin};
const c=h.validateConfig(env);a.equal(c.base,h.PIN.base);
for(const change of [{LIVEMORE_BROWSER_BASE:'http://127.0.0.1:8850'},{LIVEMORE_BROWSER_TECHNICAL:'0'},{LIVEMORE_BROWSER_EXPECTED_SOURCE:'a'.repeat(64)},{LIVEMORE_BROWSER_TWIN_ID:'twin-'+'b'.repeat(32)},{LIVEMORE_BROWSER_OUTPUT:'relative'}])a.throws(()=>h.validateConfig({...env,...change}));
const s={schema:'livemore.multiscale-workspace.v1',context_id:'c'.repeat(64),subject:{twin_id:h.PIN.twin,subject_id:h.PIN.subject,source_class:'SYNTHETIC',display_label:h.PIN.label,version:8}};
a.equal(h.requireTechnicalWorkspace(s).context_id,s.context_id);
for(const change of [{source_class:'REAL_HUMAN'},{display_label:'other'},{subject_id:'other'},{version:7},{twin_id:'twin-'+'a'.repeat(32)}])a.throws(()=>h.requireTechnicalWorkspace({...s,subject:{...s.subject,...change}}));
a.throws(()=>h.requireTechnicalWorkspace({...s,context_id:null}));
const build={schema:'livemore.build-identity.v1',identity_scope:'startup_source',source_sha256:h.PIN.source,process_instance:h.PIN.instances.Aegle};
const peers=Object.fromEntries(['Aegle','LIFE','Cendos'].map((service,i)=>[service,{up:true,service,port:8910+i,build:{...build,process_instance:h.PIN.instances[service]}}]));
h.requireBuild(build,peers);a.throws(()=>h.requireBuild(build,{...peers,LIFE:{...peers.LIFE,build:{...build,process_instance:h.PIN.instances.Aegle}}}));
h.requireHeaders({'x-livemore-source-sha256':h.PIN.source,'x-livemore-process-instance':h.PIN.instances.Aegle});a.throws(()=>h.requireHeaders({}));
""")


def test_atlas_wrapper_preserves_receiver_arguments_result_and_exception_without_clinical_capture():
    run("""
const a=require('node:assert/strict');
(async()=>{
let created=0,added=0,disposed=0,seen;const arg={private_patient:'never-retain'},value={result:'same'};
const original={async addPartition(...args){a.equal(this,original);added++;seen=args;return value},dispose(){a.equal(this,original);disposed++},view(){return{selected:'FJ123',camera:{position:[1,2,3],target:[0,0,0]},groups:['skin'],private_patient:'never-retain'}},metrics(){return{loaded_groups:1,loaded_elements:1,draw_count:1,render_calls:1,triangles:203382,geometries:disposed?0:1,dpr:1,frame_ms:[2],private_patient:'never-retain'}}};
const tracker=h.wrapSceneFactory(input=>{created++;a.equal(input,arg);return original});const scene=tracker.create(arg);a.equal(created,1);
a.equal(await scene.addPartition({asset_key:'skin',sha256:'a'.repeat(64)},new Uint8Array([1,2]),()=>true),value);a.equal(added,1);a.equal(seen.length,3);
a(!JSON.stringify(tracker.snapshot()).includes('private_patient'));a(!JSON.stringify(tracker.snapshot()).includes('never-retain'));
scene.dispose();a.equal(disposed,1);a.equal(tracker.snapshot().records[0].disposed,true);a.equal(tracker.snapshot().records[0].final.geometries,0);
const failure=Error('same exact failure'),broken=h.wrapSceneFactory(()=>({addPartition(){throw failure},dispose(){},metrics(){return{}},view(){return{}}})).create({});
await a.rejects(broken.addPartition({asset_key:'skin'}),e=>e===failure);
const text=h.wrapperSource();a(text.includes('WeakRef'));a(!text.includes('window.'));a(!text.includes('globalThis.'));a(text.includes(h.ORIGINAL_PATH));a(text.includes('qaAtlasSnapshot'));
a.equal(h.wrapperRoute(h.PIN.base+h.SCENE_PATH),'wrapper');a.equal(h.wrapperRoute(h.PIN.base+h.ORIGINAL_PATH),'original');
for(const url of ['http://evil.invalid'+h.SCENE_PATH,h.PIN.base+h.SCENE_PATH+'?unapproved=1',h.PIN.base+'/lib/other.js'])a.equal(h.wrapperRoute(url),null);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_atlas_metrics_do_not_conflate_cpu_and_presented_frames_or_ignore_failed_trials():
    run("""
const a=require('node:assert/strict'),good={loaded_groups:9,loaded_elements:489,draw_count:130,render_calls:978,triangles:957072,geometries:489,dpr:2,frame_ms:Array(130).fill(1)};
h.requireScene(good);for(const change of [{loaded_elements:488},{loaded_groups:8},{dpr:3},{geometries:0}])a.throws(()=>h.requireScene({...good,...change}));
const m=h.evaluateTiming({elapsed_ms:11000,skin_after_response_ms:200,all_layers_ms:14000,submission_ms:Array(120).fill(2),raf_ms:Array(120).fill(40)});a.equal(m.passed,true);a.equal(m.cpu_submission_p95_ms,2);a.equal(m.browser_frame_p95_ms,40);
for(const change of [{skin_after_response_ms:5001},{all_layers_ms:15001},{raf_ms:Array(120).fill(51)},{raf_ms:Array(119).fill(1)},{submission_ms:[]},{raf_ms:[NaN]}])a.equal(h.evaluateTiming({elapsed_ms:11000,skin_after_response_ms:1,all_layers_ms:1,submission_ms:Array(120).fill(2),raf_ms:Array(120).fill(20),...change}).passed,false);
a.equal(h.allPassed([{passed:true},{passed:false}]),false);a.equal(h.allPassed([]),false);
const cycle={records:Array.from({length:6},(_,i)=>({sequence:i+1,disposed:i<5,alive:i===5,final:i<5?{geometries:0,loaded_groups:0,loaded_elements:0}:null})),live:{metrics:good}};
h.requireDisposal(cycle);a.throws(()=>h.requireDisposal({...cycle,records:cycle.records.map((r,i)=>i===0?{...r,alive:true}:r)}));
""")


def test_atlas_fault_policy_never_sends_upstream_install_or_wrong_asset_tamper():
    run("""
const a=require('node:assert/strict'),url=h.PIN.base+'/api/anatomy/atlas-reference/install';
a.equal(h.requestPolicy(url,'POST','ordinary'),'block');a.equal(h.requestPolicy(url,'POST','faults'),'fixture');
a.equal(h.requestPolicy(h.PIN.base+'/api/workspace/actions','POST','faults'),'block');
a.equal(h.requestPolicy(h.PIN.base+'/api/session/bootstrap','GET','ordinary'),'allow');
a.equal(h.requestPolicy('https://other.invalid/api/state','GET','ordinary'),'block');
for(const mode of ['ordinary','instrumented','faults'])a.equal(h.requestPolicy(h.PIN.base+'/api/twins','DELETE',mode),'block');
const missing=h.statusFixture('missing');a.equal(missing.available,false);a.equal(missing.manifest,null);a.equal(missing.patient_registered,false);a.throws(()=>h.statusFixture('available'));
const ack=h.retainedAcknowledgment({state:'available',manifest_sha256:h.PIN.manifest,source_id:h.PIN.sourceId});a.equal(ack.receipt.receipt_id,h.PIN.receipt);a.equal(ack.reused,true);a.throws(()=>h.retainedAcknowledgment({manifest_sha256:'a'.repeat(64)}));
""")


def test_atlas_owned_browser_closes_on_every_post_launch_failure_even_receipt_write():
    run("""
const a=require('node:assert/strict');
(async()=>{for(const stage of ['context','page','preflight','screenshot','receipt']){let closes=0;await a.rejects(h.withOwnedBrowser({launch:async()=>({close:async()=>closes++})},{},async()=>{throw Error(stage)}));a.equal(closes,1)}
let launch=0;a.throws(()=>h.validateConfig({}));a.equal(launch,0);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_atlas_ordinary_context_and_review_boundaries_are_explicit():
    source = HARNESS.read_text(encoding="utf-8")
    assert "Object.defineProperty(document" not in source
    assert "setContent(" not in source
    assert "page.addStyleTag" not in source
    assert "dispatchEvent" not in source
    assert "instrumented" in source and "faults" in source and "ordinary" in source
    assert "WEBGL_lose_context" in source and "requireDisposal" in source
    assert "await context.close()" in source and "withOwnedBrowser" in source
    assert "await browser.close()" not in source  # shared reviewed outer finally
    assert "VISUAL_REVIEW_REQUIRED" in source


def test_atlas_current_source_hash_uses_python_path_component_order():
    run("""
const a=require('node:assert/strict'),fs=require('node:fs/promises'),os=require('node:os'),path=require('node:path'),{createHash}=require('node:crypto');
(async()=>{const root=await fs.mkdtemp(path.join(os.tmpdir(),'atlas-hash-technical-'));await fs.mkdir(path.join(root,'a'));await fs.mkdir(path.join(root,'tests'));await fs.writeFile(path.join(root,'a.py'),'top');await fs.writeFile(path.join(root,'a/b.py'),'nested');await fs.writeFile(path.join(root,'tests/no.py'),'excluded');
const expected=createHash('sha256');for(const [name,value] of [['a/b.py','nested'],['a.py','top']]){const b=Buffer.from(name),n=Buffer.alloc(8);n.writeBigUInt64BE(BigInt(b.length));expected.update(n).update(b).update(createHash('sha256').update(value).digest());}a.equal(await h.packageFingerprint(root),expected.digest('hex'));
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_atlas_failed_case_persists_bounded_measurements_before_assertion_and_screenshot():
    run("""
const a=require('node:assert/strict');
(async()=>{const writes=[],item={name:'timing',passed:false},record=h.createCaseRecorder(item,async()=>writes.push(structuredClone(item)));
await a.rejects((async()=>{await record({warm:{phase:'complete',request_count:8,max_internal_concurrency:3,skin_after_response_ms:5100,all_layers_ms:16000,requests:[{asset_key:'skin',start_ms:1,private_patient:'never'}],private_patient:'never'},sample:{observed_draws:119,submission_ms:[1,2],raf_ms:[50,NaN],clinical_values:[999]},timing:{passed:false,browser_frame_p95_ms:51,submission_samples:119,browser_frame_samples:119}});a.fail('original threshold');})());
a.equal(writes.length,1);a.equal(writes[0].metadata.warm.request_count,8);a.equal(writes[0].metadata.warm.max_internal_concurrency,3);a.equal(writes[0].metadata.warm.skin_after_response_ms,5100);a.equal(writes[0].metadata.sample.observed_draws,119);a.deepEqual(writes[0].metadata.sample.raf_ms,[50,null]);a.equal(writes[0].metadata.timing.browser_frame_p95_ms,51);a(!JSON.stringify(writes).includes('private_patient'));a(!JSON.stringify(writes).includes('clinical_values'));
await record({deadline:{remaining_ms:-5}});a.equal(writes.length,2);a.equal(writes[1].metadata.warm.all_layers_ms,16000);a.equal(writes[1].metadata.deadline.remaining_ms,-5);
await record({sample:{submission_ms:Array(2000).fill(2),raf_ms:Array(4000).fill(3)}});a.equal(item.metadata.sample.submission_ms.length,1000);a.equal(item.metadata.sample.raf_ms.length,2000);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_atlas_partial_warm_timeout_is_persisted_without_turning_it_into_a_pass():
    run("""
const a=require('node:assert/strict');
(async()=>{const events=new Map(),samples=[],page={on:(event,fn)=>events.set(event,fn),off:(event,fn)=>a.equal(events.get(event),fn),goto:async()=>{events.get('request')({url:()=>h.PIN.base+'/assets/anatomy/atlas/'+h.PIN.manifest+'/skin.glb'});},waitForFunction:async()=>{throw Error('TECHNICAL timeout')},evaluate:async()=>{}};
await a.rejects(h.observeWarm({page},async value=>samples.push(structuredClone(value))),/TECHNICAL timeout/);
a.equal(samples.length,1);a.equal(samples[0].warm.phase,'partial');a.equal(samples[0].warm.request_count,1);a.equal(samples[0].warm.skin_completed,false);a.equal(samples[0].warm.all_layers_ms,null);a.equal(samples[0].warm.requests[0].outcome,'pending');a(!JSON.stringify(samples).includes('TECHNICAL timeout'));
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_atlas_resource_failure_retains_each_cycle_before_validation():
    run("""
const a=require('node:assert/strict');
(async()=>{const writes=[],item={},record=h.createCaseRecorder(item,async()=>writes.push(structuredClone(item)));
const partial={baseline:{documents:1,nodes:10,jsEventListeners:3,private:'never'},cycles:[{cycle:1,records:[{sequence:1,disposed:true,alive:true,final:{geometries:4,loaded_groups:0,loaded_elements:0,private:'never'}}],counters:{nodes:12,jsEventListeners:5},view:{selected:'FJ123',axis:'z',depth:.31,camera:{position:[1,2,3],target:[0,0,0]},clinical:'never'}}]};
await record({resources:partial});await a.rejects((async()=>{a.equal(partial.cycles[0].records[0].alive,false)})());a.equal(writes[0].metadata.resources.cycles[0].records[0].final.geometries,4);a.equal(writes[0].metadata.resources.cycles[0].counters.jsEventListeners,5);a(!JSON.stringify(writes).includes('clinical'));a(!JSON.stringify(writes).includes('private'));
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_atlas_camera_input_failure_keeps_initial_counts_and_available_frame_samples():
    run("""
const a=require('node:assert/strict');
(async()=>{let disposed=0,stops=0;const records=[],browser={},context={browser:()=>browser},item={count:async()=>1,isVisible:async()=>true,isEnabled:async()=>true,evaluate:async()=>({}),click:async()=>{},scrollIntoViewIfNeeded:async()=>{},boundingBox:async()=>({x:0,y:0,width:100,height:100})};
const value={draw_count_before:7,draw_count_after:127,observed_draws:120,elapsed_ms:2000,submission_ms:Array(120).fill(2),raf_ms:Array(120).fill(20),deadline_reached:false},recorder={snapshot:()=>({...value,stopped:false}),stop:()=>{stops++;return {...value,stopped:true}}};
const page={context:()=>context,locator:()=>item,evaluate:async()=>({live:{metrics:{draw_count:7,frame_ms:[2]}}}),evaluateHandle:async()=>({evaluate:async(fn,arg)=>fn(recorder,arg),dispose:async()=>disposed++}),mouse:{move:async()=>{throw Error('TECHNICAL input failure')},up:async()=>{},down:async()=>{}}};
await a.rejects(h.cameraTiming({page,context,browser},async value=>records.push(structuredClone(value))),/TECHNICAL input failure/);a(records.length>=2);a.equal(records[0].sample.draw_count_before,7);a.equal(records.at(-1).sample.phase,'partial');a.equal(records.at(-1).sample.raf_ms.length,120);a.equal(records.at(-1).sample.cleanup,'SETTLED');a.equal(stops,1);a.equal(disposed,1);a(!JSON.stringify(records).includes('TECHNICAL input failure'));
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_atlas_timing_rejects_elapsed_outside_fixed_measurement_window():
    run("""
const a=require('node:assert/strict'),good={elapsed_ms:11000,skin_after_response_ms:1,all_layers_ms:1,submission_ms:Array(120).fill(1),raf_ms:Array(120).fill(16)};
a.equal(h.evaluateTiming(good).passed,true);
for(const elapsed_ms of [25000,20000.001,NaN,Infinity,-1,undefined,null,true])a.equal(h.evaluateTiming({...good,elapsed_ms}).passed,false);
""")


def test_atlas_measurement_deadline_cancels_owned_page_and_settles_pending_input():
    run("""
const a=require('node:assert/strict');
(async()=>{let now=0,serial=0,closed=0,rejectInput;const timers=new Map(),clock={now:()=>now,setTimeout:(fn,ms)=>{timers.set(++serial,{fn,due:now+ms});return serial},clearTimeout:id=>timers.delete(id)};
const browser={},context={browser:()=>browser},page={context:()=>context,close:async options=>{a.deepEqual(options,{runBeforeUnload:false});closed++;rejectInput(Error('technical canceled'));}};
const budget=h.createMeasurementBudget({page,context,browser},clock);const pending=budget.run(()=>new Promise((_,reject)=>rejectInput=reject));pending.catch(()=>{});await Promise.resolve();await Promise.resolve();now=20001;for(const [id,timer] of [...timers])if(timer.due<=now){timers.delete(id);timer.fn();}
await a.rejects(pending,/measurement deadline/i);a.equal(closed,1);let more=0;await a.rejects(budget.run(()=>more++));a.equal(more,0);a.equal(await budget.finish(),'SETTLED');a.equal(timers.size,0);a.equal(budget.elapsed(),20001);
a.throws(()=>h.createMeasurementBudget({page,context:{},browser},clock));a.equal(closed,1);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_atlas_private_frame_recorder_stops_without_a_future_raf_or_global_export():
    run("""
const a=require('node:assert/strict'),vm=require('node:vm');let now=0,raf=null,timeout=null,canceled=0,cleared=0;
const box={performance:{now:()=>now},requestAnimationFrame:fn=>{raf=fn;return 1},cancelAnimationFrame:()=>canceled++,setTimeout:fn=>{timeout=fn;return 2},clearTimeout:()=>cleared++};
const recorder=vm.runInNewContext('('+h.frameRecorder.toString()+')({remaining_ms:20000})',box);now=16;raf(16);now=32;raf(32);a.equal(recorder.snapshot().raf_ms.length,1);now=20000;timeout();const result=recorder.stop();a.equal(result.stopped,true);a.equal(result.deadline_reached,true);a.equal(result.elapsed_ms,20000);a.equal(canceled,1);a.equal(cleared,1);a(!Object.keys(box).some(x=>x.includes('Atlas')));
""")


def test_atlas_recorder_stop_failure_still_disposes_the_private_handle():
    run("""
const a=require('node:assert/strict');
(async()=>{let disposed=0;const records=[],browser={},context={browser:()=>browser},item={count:async()=>1,isVisible:async()=>true,isEnabled:async()=>true,evaluate:async()=>({}),click:async()=>{},scrollIntoViewIfNeeded:async()=>{},boundingBox:async()=>({x:0,y:0,width:100,height:100})};
const value={draw_count_before:7,draw_count_after:127,observed_draws:120,elapsed_ms:2000,submission_ms:Array(120).fill(2),raf_ms:Array(120).fill(20),deadline_reached:false},recorder={snapshot:()=>({...value,stopped:false}),stop:()=>{throw Error('TECHNICAL recorder stop failure')}};
const page={context:()=>context,locator:()=>item,evaluate:async()=>({live:{metrics:{draw_count:7,frame_ms:[2]}}}),evaluateHandle:async()=>({evaluate:async(fn,arg)=>fn(recorder,arg),dispose:async()=>disposed++}),mouse:{move:async()=>{throw Error('TECHNICAL input failure')},up:async()=>{},down:async()=>{}}};
await a.rejects(h.cameraTiming({page,context,browser},async value=>records.push(structuredClone(value))));a.equal(disposed,1);a.equal(records.at(-1).sample.phase,'partial');a(!JSON.stringify(records).includes('TECHNICAL'));
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_atlas_measurement_cleanup_timeout_is_not_reported_as_settled():
    run("""
const a=require('node:assert/strict');
(async()=>{let now=0,serial=0,closes=0;const timers=new Map(),clock={now:()=>now,setTimeout:(fn,ms)=>{timers.set(++serial,{fn,due:now+ms});return serial},clearTimeout:id=>timers.delete(id)},browser={},context={browser:()=>browser},page={context:()=>context,close:()=>{closes++;return new Promise(()=>{})}};
const budget=h.createMeasurementBudget({page,context,browser},clock);const operation=budget.run(()=>new Promise(()=>{}));operation.catch(()=>{});await Promise.resolve();now=20000;for(const [id,timer]of[...timers])if(timer.due<=now){timers.delete(id);timer.fn()};await a.rejects(operation);a.equal(closes,1);
const cleanup=budget.finish();await Promise.resolve();now=25000;for(const[id,timer]of[...timers])if(timer.due<=now){timers.delete(id);timer.fn()};a.equal(await cleanup,'CLEANUP_UNCONFIRMED');a.equal(timers.size,0);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_atlas_recorder_cpu_and_raf_samples_share_the_frozen_window():
    run("""
const a=require('node:assert/strict'),vm=require('node:vm');let now=0,raf,stops=0,clears=0,draw=9;
const box={performance:{now:()=>now},requestAnimationFrame:fn=>{raf=fn;return 1},cancelAnimationFrame:()=>stops++,setTimeout:()=>2,clearTimeout:()=>clears++,readMetrics:()=>({draw_count:draw,frame_ms:Array(draw).fill(3)})};
const r=vm.runInNewContext('('+h.frameRecorder.toString()+')({remaining_ms:20000,readMetrics})',box);now=16;draw=10;raf(16);now=32;draw=11;raf(32);const value=r.stop();a.equal(value.draw_count_before,9);a.equal(value.draw_count_after,11);a.equal(value.observed_draws,2);a.equal(value.submission_ms.length,2);a.equal(value.raf_ms.length,1);a.equal(value.elapsed_ms,32);a.equal(value.deadline_reached,false);
now=1000;draw=100;raf(1000);a.equal(r.snapshot().draw_count_after,11);a.equal(r.snapshot().raf_ms.length,1);a.equal(r.stop().elapsed_ms,32);a.equal(stops,1);a.equal(clears,1);
""")


def test_atlas_mounted_camera_rejects_late_input_even_before_alarm_dispatch():
    run("""
const a=require('node:assert/strict');
(async()=>{let now=0,serial=0,closes=0,moves=0,ups=0,disposed=0;const records=[],timers=new Map(),clock={now:()=>now,setTimeout:(fn,ms)=>{timers.set(++serial,{fn,due:now+ms});return serial},clearTimeout:id=>timers.delete(id)},browser={},context={browser:()=>browser};
const item={count:async()=>1,isVisible:async()=>true,isEnabled:async()=>true,evaluate:async()=>({}),click:async()=>{},scrollIntoViewIfNeeded:async()=>{},boundingBox:async()=>({x:0,y:0,width:100,height:100})};
const value={stopped:false,draw_count_before:7,draw_count_after:8,observed_draws:1,elapsed_ms:1,submission_ms:[2],raf_ms:[16],deadline_reached:false},recorder={snapshot:()=>value,stop:()=>({...value,stopped:true})};
const page={context:()=>context,close:async()=>closes++,locator:()=>item,evaluate:async()=>({live:{metrics:{draw_count:7,frame_ms:[2]}}}),evaluateHandle:async()=>({evaluate:async(fn,arg)=>fn(recorder,arg),dispose:async()=>disposed++}),mouse:{move:async()=>{moves++;now=25000},down:async()=>{},up:async()=>ups++}};
await a.rejects(h.cameraTiming({page,context,browser},async v=>records.push(structuredClone(v)),clock),/measurement deadline/);a.equal(closes,1);a.equal(moves,1);a.equal(ups,0);a.equal(disposed,0);a.equal(timers.size,0);const last=records.at(-1).sample;a.equal(last.phase,'partial');a.equal(last.elapsed_ms,25000);a.equal(last.deadline_reached,true);a.equal(last.cleanup,'SETTLED');a.equal(last.raf_ms.length,1);a.equal(h.evaluateTiming({...last,skin_after_response_ms:1,all_layers_ms:1}).passed,false);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_atlas_mounted_camera_cancels_a_stalled_recorder_read_and_keeps_partial_counts():
    run("""
const a=require('node:assert/strict');
(async()=>{let now=0,serial=0,closes=0,moves=0,rejectRead,readStarted;const started=new Promise(resolve=>readStarted=resolve),records=[],timers=new Map(),clock={now:()=>now,setTimeout:(fn,ms)=>{timers.set(++serial,{fn,due:now+ms});return serial},clearTimeout:id=>timers.delete(id)},browser={},context={browser:()=>browser};
const item={count:async()=>1,isVisible:async()=>true,isEnabled:async()=>true,evaluate:async()=>({}),click:async()=>{},scrollIntoViewIfNeeded:async()=>{},boundingBox:async()=>({x:0,y:0,width:100,height:100})};
const page={context:()=>context,close:async()=>{closes++;rejectRead(Error('TECHNICAL page canceled'))},locator:()=>item,evaluate:async()=>({live:{metrics:{draw_count:7,frame_ms:[2]}}}),evaluateHandle:async()=>({evaluate:()=>{readStarted();return new Promise((_,reject)=>rejectRead=reject)},dispose:async()=>{}}),mouse:{move:async()=>moves++,down:async()=>{},up:async()=>{}}};
const pending=h.cameraTiming({page,context,browser},async v=>records.push(structuredClone(v)),clock);pending.catch(()=>{});await started;now=20000;for(const[id,timer]of[...timers])if(timer.due<=now){timers.delete(id);timer.fn()};await a.rejects(pending,/measurement deadline/);a.equal(closes,1);a.equal(moves,0);a.equal(timers.size,0);a.equal(records.at(-1).sample.draw_count_before,7);a.equal(records.at(-1).sample.phase,'partial');a.equal(records.at(-1).sample.cleanup,'SETTLED');a.equal(records.at(-1).sample.deadline_reached,true);a(!JSON.stringify(records).includes('TECHNICAL page canceled'));
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_atlas_mounted_camera_normal_completion_stops_once_and_clears_all_handles_and_timers():
    run("""
const a=require('node:assert/strict');
(async()=>{let now=0,serial=0,draw=7,moves=0,ups=0,stops=0,disposed=0,closes=0,stopped=null;const records=[],timers=new Map(),clock={now:()=>now,setTimeout:(fn,ms)=>{timers.set(++serial,{fn,due:now+ms});return serial},clearTimeout:id=>timers.delete(id)},browser={},context={browser:()=>browser};
const item={count:async()=>1,isVisible:async()=>true,isEnabled:async()=>true,evaluate:async()=>({}),click:async()=>{},scrollIntoViewIfNeeded:async()=>{},boundingBox:async()=>({x:0,y:0,width:100,height:100})};
const value=()=>({stopped:false,draw_count_before:7,draw_count_after:draw,observed_draws:draw-7,elapsed_ms:now,submission_ms:Array(draw-7).fill(2),raf_ms:Array(draw-7).fill(31),deadline_reached:false}),recorder={snapshot:()=>stopped||value(),stop:()=>{stops++;stopped={...value(),stopped:true};return stopped}};
const page={context:()=>context,close:async()=>closes++,locator:()=>item,evaluate:async()=>({live:{metrics:{draw_count:7,frame_ms:[2]}}}),evaluateHandle:async()=>({evaluate:async(fn,arg)=>fn(recorder,arg),dispose:async()=>disposed++}),waitForTimeout:async ms=>now+=ms,mouse:{move:async()=>{moves++;draw++;now+=16},down:async()=>{},up:async()=>ups++}};
const sample=await h.cameraTiming({page,context,browser},async v=>records.push(structuredClone(v)),clock);a.equal(sample.phase,'complete');a.equal(sample.cleanup,'SETTLED');a.equal(sample.deadline_reached,false);a(sample.elapsed_ms>=11000&&sample.elapsed_ms<11050);a.equal(sample.observed_draws,moves);a(sample.observed_draws>=120);a.equal(sample.raf_ms.length,sample.submission_ms.length);a.equal(stops,1);a.equal(ups,1);a.equal(disposed,1);a.equal(closes,0);a.equal(timers.size,0);a.equal(h.evaluateTiming({...sample,skin_after_response_ms:1,all_layers_ms:1}).passed,true);a(records.length>3);
})().catch(e=>{console.error(e);process.exitCode=1});
""")
