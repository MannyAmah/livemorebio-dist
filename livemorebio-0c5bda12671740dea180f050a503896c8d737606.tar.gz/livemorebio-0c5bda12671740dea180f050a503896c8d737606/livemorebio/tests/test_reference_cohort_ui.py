"""Browser-state controller and escaped descriptive record projection."""
from pathlib import Path
import subprocess
from ._node import NODE, run_node as _run_node

ROOT=Path(__file__).resolve().parents[2]
MODULE=ROOT/'livemorebio/aegle/console/lib/reference_cohorts.js'


def test_reference_draft_edit_invalidates_preview_and_uncertain_retry_keeps_key():
    script="""
const {ReferenceDraftSession}=await import(process.argv[1]);
const assert=(value,message)=>{if(!value)throw Error(message)};
let n=0;const state=new ReferenceDraftSession(()=>`technical-${++n}`);
const first=state.change({name:'one'});state.acceptPreview(first,{preview_token:'token',executable:false,model_binding:null});
const a=state.creation(),b=state.creation();assert(a.key===b.key,'uncertain retry changes key');
state.change({name:'two'});assert(!state.ready,'edit retained preview');
assert(!state.acceptPreview(first,{preview_token:'stale',executable:false,model_binding:null}),'stale async preview accepted');
let rejected=false;try{state.creation()}catch{rejected=true}assert(rejected,'create without matching preview');
const next=state.change({name:'two'});state.acceptPreview(next,{preview_token:'new',executable:false,model_binding:null});
assert(state.creation().key!==a.key,'changed draft reused old idempotency key');
"""
    _run_node([NODE,'--input-type=module','-e',script,MODULE.as_uri()],check=True,capture_output=True,text=True, encoding="utf-8")


def test_public_card_and_member_view_are_not_executable_or_unrelated_biology_links():
    script="""
const {referenceCohortCard,referenceMemberView}=await import(process.argv[1]);
const assert=(value,message)=>{if(!value)throw Error(message)};
const html=referenceCohortCard({cohort_id:'reference-fixture',name:'<img src=x onerror=alert(1)>',source_class:'PUBLIC_REFERENCE',size:3,definition:{name:'screened'},construction_sha256:'abc'});
assert(html.includes('&lt;img'),'unsafe source label');assert(!html.includes('href="/biology'),'unrelated biology link');assert(!html.includes('Run governed'),'unsupported execution action');assert(html.includes('data-inspect-reference'),'no actual inspection action');
const member=referenceMemberView({member_id:'opaque',schema:'livemore.frozen-public-reference-member.v1',source_class:'PUBLIC_REFERENCE',model_binding:null,executable:false,reference:{measurements:{glucose:{value:null,unit:'mg/dL',evidence_state:'UNAVAILABLE',lineage:{variable:'LBXGLU'}}},time_context:{precision:'survey_cycle'},demographics:{},questionnaire:{}}});
assert(member.includes('Unavailable'),'missing data became zero');assert(!member.includes('T2D'),'disease inferred');assert(member.includes('Not an enrolled person'),'source boundary absent');
"""
    _run_node([NODE,'--input-type=module','-e',script,MODULE.as_uri()],check=True,capture_output=True,text=True, encoding="utf-8")


def test_public_source_preparation_is_additive_to_legacy_cohort_form():
    html=(ROOT/'livemorebio/aegle/console/cohorts.html').read_text(encoding="utf-8")
    assert 'id="cohort-form"' in html and 'id="reference-cohort-form"' in html
    assert 'id="reference-preview"' in html and 'id="reference-create"' in html
    assert 'id="reference-use-acceptance"' in html and 'id="reference-member-dialog"' in html
