"""Explicit technical identity and intercepted first-party response stand-ins."""
from urllib.request import Request


TECHNICAL_IDENTITY_KEY = b"technical-stack-client-fixture!!"


def install_stack_client_opener(monkeypatch, opener):
    """Keep legacy receipt assertions at the proved-request boundary, without IO."""
    from livemorebio import stack_client

    def technical_key(*, create=False):
        assert create is False
        return TECHNICAL_IDENTITY_KEY

    def request_response(url, *, identity, method="GET", headers=None, body=None,
                         timeout=20, max_response_bytes=None, response_limits=None):
        assert identity.key == TECHNICAL_IDENTITY_KEY
        request = Request(url, data=body, headers=dict(headers or {}), method=method)
        return opener().open(request, timeout=timeout)

    monkeypatch.setattr(stack_client, "service_identity_key", technical_key)
    monkeypatch.setattr(stack_client, "request_response", request_response)


def forbid_stack_client(monkeypatch, forbidden):
    """Reject peer trust lookup as well as sending in tests with no peer calls."""
    monkeypatch.setattr("livemorebio.stack_client.service_identity_key", forbidden)
    monkeypatch.setattr("livemorebio.stack_client.request_response", forbidden)
