"""Test the real publisher archive and every surviving file, not a synthetic tar."""
from __future__ import annotations
import ast
from collections import Counter
import json
import hashlib
import os
from pathlib import Path
import re
import subprocess
import tarfile
import pytest

from ._source_tree import REPOSITORY_ROOT, require_git_checkout, requires_git_checkout, source_tree_only

# Asked through the shared helper, never of ``git`` directly: a host without
# ``git`` must skip these, and a direct call raises while this module is being
# imported, which fails the whole run.
requires_checkout = requires_git_checkout("building an archive")


@pytest.fixture(scope="module")
def archives(tmp_path_factory):
    """Default to committed HEAD; explicit local review refs still use git archive."""
    require_git_checkout("building an archive")
    from tools.build_release import build
    root = tmp_path_factory.mktemp('audiences')
    ref = os.environ.get('LIVEMORE_REVIEW_ARCHIVE_REF', 'HEAD')
    return tuple(build(root / audience, ref=ref, channel='stable', audience=audience)
                 for audience in ('private', 'public'))


def _files(result) -> dict[str, bytes]:
    prefix = f"livemorebio-{result['commit']}/"
    with tarfile.open(result['archive']) as handle:
        return {member.name[len(prefix):]: handle.extractfile(member).read()
                for member in handle if member.isfile() and member.name.startswith(prefix)}


def test_the_public_archive_keeps_every_product_python_source_file(archives):
    from tools.public_distribution import is_private_only
    private, public = map(_files, archives)
    missing = {name for name in private.keys() - public.keys()
               if name.startswith('livemorebio/') and name.endswith('.py')
               and '/tests/' not in name}
    assert not missing
    assert all(is_private_only(name) for name in private.keys() - public.keys())


def test_public_keeps_all_tests_except_excluded_private_research_set(archives):
    from tools.public_distribution import is_private_only
    private, public = map(_files, archives)
    tests = {name for name in private if name.startswith('livemorebio/tests/')}
    assert tests
    assert {name for name in tests if not is_private_only(name)} <= public.keys()


def test_l0_release_note_checks_stay_in_the_source_tree(archives):
    private, public = map(_files, archives)
    for name in ('docs/launch/L0/release-notes.md',
                 'livemorebio/tests/test_l0_release_notes.py'):
        assert name in private
        assert name not in public
    for name in ('livemorebio/tests/test_l0_no_echo.py',
                 'livemorebio/tests/test_l0_walk_minors.py'):
        assert name in public


def _private_import_references(name: str, source: str | bytes) -> list[str]:
    """Resolve imports in any shipped Python module against the archive policy."""
    from tools.public_distribution import is_private_only
    hits = []
    package = name.removesuffix('.py').split('/')[:-1]
    for node in ast.walk(ast.parse(source)):
        modules = []
        if isinstance(node, ast.Import):
            modules = [alias.name for alias in node.names]
        elif isinstance(node, ast.ImportFrom):
            prefix = '.'.join(package[:len(package) - node.level + 1]) if node.level else ''
            base = '.'.join(part for part in (prefix, node.module) if part)
            modules = [base, *(base + '.' + alias.name for alias in node.names)]
        for module in modules:
            path = module.replace('.', '/')
            if path and (is_private_only(path + '.py') or is_private_only(path + '/__init__.py')):
                hits.append(module)
    return hits


def test_installed_package_does_not_import_private_research_tooling(archives):
    for name, raw in _files(archives[1]).items():
        if name.endswith('.py'):
            assert not _private_import_references(name, raw), name


def test_the_public_archive_keeps_everything_the_installer_requires(archives):
    from tools.public_distribution import REQUIRED_PATHS
    assert set(REQUIRED_PATHS) <= _files(archives[1]).keys()


def test_public_projection_excludes_every_private_input(archives):
    from tools.public_distribution import is_private_only
    private, public = map(_files, archives)
    assert public.keys() - {'.livemore-distribution.json'} == {name for name in private if not is_private_only(name)}
    # F-17: the installed engine retains its pin, but public archives fetch it.
    assert 'models/cardiac/ohara_rudy_cipa_2017.cellml' not in public
    assert not any(is_private_only(name) for name in public)


def test_the_public_archive_is_materially_smaller(archives):
    private, public = archives
    assert public['excluded_members'] > 100
    assert public['bytes'] < private['bytes'] / 4


def test_a_private_build_excludes_nothing(archives):
    assert archives[0]['excluded_members'] == 0


def test_the_manifest_records_which_audience_it_describes(archives):
    for result in archives:
        assert json.loads(Path(result['manifest']).read_text(encoding="utf-8"))['audience'] == result['audience']
    marker = json.loads(_files(archives[1])['.livemore-distribution.json'])
    assert marker == {'schema':'livemore.distribution.v1', 'audience':'public'}


def test_required_paths_are_never_excluded():
    from tools.public_distribution import REQUIRED_PATHS, is_private_only
    assert all(not is_private_only(name) for name in REQUIRED_PATHS)


def test_cardiac_cellml_is_acquired_not_publicly_redistributed():
    from tools.public_distribution import is_private_only
    assert is_private_only('models/cardiac/ohara_rudy_cipa_2017.cellml')


@pytest.mark.parametrize('path', [
    'docs/HANDOFF.md', 'docs/new-internal.md', 'docs/solutions/internal.md',
    'trials', 'notebooks/trial_analysis.ipynb', 'notebooks/_build_notebook.py',
    'livemorebio/discovery/data/new-private-extract.json',
    'tools/osp_stage_b.py', 'tools/beard_source_execution.py',
    'tools/build_tracker/progress.json', 'AGENTS.md', '.review/notes.txt',
    'tools/diagnostics/osp_vmmap_retained_forensics.py', 'tools/test_osp_stage_b_native.R',
    'livemorebio/tests/private_fixtures/seed_guard_literals.json',
    'livemorebio/tests/test_private_seed_guard.py',
])
def test_internal_paths_are_recognised(path):
    from tools.public_distribution import is_private_only
    assert is_private_only(path)


@pytest.mark.parametrize('path', ['livemorebio/cli.py', 'livemorebio/tests/test_installer.py',
    'tools/build_release.py', 'pyproject.toml', 'THIRD_PARTY_NOTICES.md', 'docs/LAUNCH_GUIDE.md'])
def test_product_paths_are_never_treated_as_internal(path):
    from tools.public_distribution import is_private_only
    assert not is_private_only(path)


# This is additional to the blanket scan. Each retained optional book filename
# must be paired with a test that actually proves the refusal/skip contract.
REVIEWED_PRIVATE_REFERENCES = {
    ('livemorebio/discovery/substrate.py', 'All_193_Druggability_Profiles.json'): 'test_missing_reference_refuses_with_fixed_reason',
    ('livemorebio/discovery/substrate.py', 'Complete_Safety_Flag_Register.csv'): 'test_missing_reference_refuses_with_fixed_reason',
}


def _private_directory_references(text: str) -> list[str]:
    import fnmatch
    from tools.public_distribution import PRIVATE_ONLY_PATTERNS, PUBLIC_DOCUMENTS, is_private_only

    patterns = [r'docs/(?:solutions|demo|deliverables|screenshots|handoff)(?![\w-])',
                r'["\']docs["\']\s*[/,]\s*["\'](?:solutions|demo|deliverables|screenshots|handoff)["\']',
                r'["\'](?:trials|handoff-exports)["\']', r'handoff-exports/',
                r'livemorebio/discovery/data(?:/|["\'])']
    hits = [match.group() for pattern in patterns for match in re.finditer(pattern, text)]
    roots = '|'.join(re.escape(root) for root in sorted({
        pattern.split('/')[0] for pattern in PRIVATE_ONLY_PATTERNS if '/' in pattern
    }))
    # Apply the actual policy to individual files as well as old excluded folders.
    # Strip remote URLs; a preceding slash elsewhere still denotes a local path.
    text = re.sub(r'''https?://[^\s"'<>]+''', '', text)
    for match in re.finditer(r'(?<![\w])(?:' + roots + r')/[^\s"\'`<>()[\]{},;]+', text):
        path = match.group().rstrip('.:')
        if '*' in path and any(fnmatch.fnmatch(name, path) for name in PUBLIC_DOCUMENTS):
            # A mixed-scope CI trigger also watches public docs; it is not an
            # excluded-file dependency. Private-only globs remain prohibited.
            continue
        if is_private_only(path):
            hits.append(path)
    for quoted in re.finditer(r'''["']([^"']+)["']''', text):
        value = quoted.group(1).rstrip('/')
        if value in {'.gstack', 'AGENTS.md', '.gitattributes'}:
            hits.append(value)
    # Path and os.path.join can contain an arbitrary number of literal components.
    sequence = r'''["'][^"']+["'](?:\s*[/,]\s*["'][^"']+["'])+'''
    for match in re.finditer(sequence, text):
        parts = re.findall(r'''["']([^"']+)["']''', match.group())
        for index, part in enumerate(parts):
            if part in {pattern.split('/')[0] for pattern in PRIVATE_ONLY_PATTERNS}:
                path = '/'.join(parts[index:])
                if is_private_only(path):
                    hits.append(path)
    return hits


def test_blanket_scan_catches_split_and_bare_private_paths():
    for text in ('ROOT / "docs/solutions" / name', 'os.path.join("..", "trials", "result.json")',
                 'Path("handoff-exports")', 'ROOT / "docs" / "solutions" / name'):
        assert _private_directory_references(text), text


@pytest.mark.parametrize('text', [
    'ROOT / "docs/HANDOFF.md"',
    'Path(".gstack")', '".gstack/"', 'f"{ROOT}/docs/HANDOFF.md"',
    'ROOT / "AGENTS.md"', 'Path(".gitattributes")',
    'ROOT / "livemorebio" / "discovery" / "data" / "private.json"',
    'ROOT / "docs" / "BUILD_PROGRESS.md"',
    'os.path.join("docs", "new-internal-note.md")',
    'Path("tools/osp_stage_b.py")',
    'ROOT.glob("docs/solutions/*.md")',
])
def test_blanket_scan_uses_policy_for_individual_excluded_paths(text):
    assert _private_directory_references(text)


@pytest.mark.parametrize('text', [
    '"docs/**"', 'Path("docs/LAUNCH_GUIDE.md")',
    'https://example.test/docs/external-page',
])
def test_blanket_scan_distinguishes_public_or_external_references(text):
    assert not _private_directory_references(text)


# Reviewed packaging gates name private prerequisites to enforce their omission
# or exact bytes. Counts cover comments and synthetic paths too; adding a path,
# repeating one, or removing a reviewed reference requires explicit review.
# The general scanner and private-import prohibition remain in force.
REVIEWED_GATE_PRIVATE_REFERENCES: dict[str, Counter[str]] = {
    # L0 gates inspect optional trial sources or explicitly source-gated docs.
    # Public archives omit these prerequisites; no runtime dependency is added.
    'livemorebio/tests/test_l0_clinical_note_gate.py': Counter({
        'trials/*.py': 1,
    }),
    'livemorebio/tests/test_l0_free_text_gate.py': Counter({
        '"trials"': 1, 'trials/full_system_trial.py': 1,
    }),
    # Security tests inspect optional private tool inputs, never runtime imports.
    # Exact counts retain the same duplicate/removal checks as the older gates.
    'livemorebio/tests/test_console_tool_redaction.py': Counter({
        'tools/record_demo.cjs': 1,
    }),
    # NEW-5c C2: the proved programmatic exchange's source assertions.
    'livemorebio/tests/test_stable_new5c_console.py': Counter({
        'tools/record_demo.cjs': 2, 'trials/capture_walkthrough.py': 4,
    }),
    'livemorebio/tests/test_security_transport_part1.py': Counter({
        '"trials"': 1, 'trials/capture_walkthrough.py': 3,
    }),
    'livemorebio/tests/test_stable_followup_console.py': Counter({
        'tools/record_demo.cjs': 4, 'trials/capture_walkthrough.py': 5,
    }),
    'livemorebio/tests/test_stable_followup_console_origin.py': Counter({
        'tools/record_demo.cjs': 2, 'trials/capture_walkthrough.py': 3,
    }),
    'livemorebio/tests/test_stable_new10_notebook_launch.py': Counter({
        'tools/notebook_recording.cjs': 1, 'tools/test_notebook_recording.cjs': 1,
    }),
    'livemorebio/tests/test_stable_followup_console_docs.py': Counter({
        'docs/EXTERNAL_TESTER_GUIDE_2026-09-09.md': 2,
        'docs/MEASUREMENT_INTEGRITY_REVIEW_GUIDE.md': 2,
    }),
    # Dispatch D's source-only guide assertions gate private documents through
    # require_private_reference_data; runtime code never reads these paths.
    'livemorebio/tests/test_stable_new5c_docs.py': Counter({
        'docs/EXTERNAL_TESTER_GUIDE_2026-09-09.md': 1,
        'docs/MEASUREMENT_INTEGRITY_REVIEW_GUIDE.md': 1,
    }),
    # Pass R gates excluded operator/history documents through the same helper.
    # The technical mutant guide exists only under pytest's private temp root.
    'livemorebio/tests/test_stable_new5c_pass_r_docs.py': Counter({
        'dist-public/README.md': 3,
        'dist-public/INSTALL.md': 3,
        'docs/CLIENT_QUICKSTART.md': 4,
        'docs/solutions': 1,
        'docs/solutions/2026-10-19-new5c-dispatch-d.md': 1,
        'docs/technical-mutant-guide.md': 1,
    }),
    '.github/workflows/installer.yml': Counter({'dist-public/**': 2}),
    'livemorebio/tests/test_release_workflow.py': Counter({'dist-public/**': 1}),
    'livemorebio/tests/test_maintenance_closing_metadata.py': Counter({
        'dist-public/README.md': 1,
        'dist-public/INSTALL.md': 1,
    }),
    'livemorebio/tests/test_installer.py': Counter({
        'docs/solutions': 2,
        'docs/solutions/PRIVATE_CHECKOUT_INSTALL.md': 2,
    }),
    'Dockerfile': Counter({
        'tools/osp_stage_b.py': 1,
    }),
    'livemorebio/tests/_source_tree.py': Counter({
        'docs/../livemorebio/x': 1,
        'docs/product-link/missing.py': 1,
        'docs/solutions': 8,
        'docs/solutions/2026-09-08-beard-native-precision-v2-preregistration.md': 1,
        'docs/solutions/2026-09-08-beard-native-source-preregistration.md': 1,
        'docs/solutions/2026-09-08-full-scope-recovery-plan.md': 1,
        'docs/solutions/2026-09-08-osp-retained-runtime-static-inventory-v2.json': 1,
        'docs/solutions/2026-09-08-osp-stage-b-numerical-benchmark.md': 1,
        'docs/solutions/2026-09-09-osp-r-startup-contract-v1.json': 1,
    }),
    'livemorebio/tests/test_container_image.py': Counter({
        'tools/osp_stage_b.py': 1,
    }),
    'livemorebio/tests/test_frozen_tool_hashes.py': Counter({
        'docs/': 1,
        'docs/solutions': 6,
        'docs/solutions/2026-09-08-osp-source-admission-implementation-review.md': 1,
        'docs/solutions/2026-09-09-build-tracker-and-replacement-plan.md': 1,
        'docs/solutions/2026-09-09-direct-dotnet-worker-plan.md': 1,
        'docs/solutions/2026-09-09-osp-parser-test-portability.md': 1,
        'tools/build_tracker/index.html': 1,
        'tools/build_tracker/tracker.css': 1,
        'tools/build_tracker/tracker.js': 2,
        'tools/diagnostics/osp_vmmap_retained_forensics.py': 2,
        'tools/osp_boundary_fixture.py': 6,
        'tools/osp_dotnet_worker/Directory.Build.props': 1,
        'tools/osp_dotnet_worker/Fixtures.json': 1,
        'tools/osp_dotnet_worker/NativeSimulation.cs': 2,
        'tools/osp_dotnet_worker/NuGet.Config': 1,
        'tools/osp_dotnet_worker/Worker.csproj': 1,
        'tools/osp_dotnet_worker/global.json': 1,
        'tools/osp_dotnet_worker/tests/FakeTests.csproj': 1,
        'tools/osp_stage_b.py': 2,
        'tools/osp_stage_b_analysis.py': 2,
        'tools/osp_stage_b_native.R': 5,
        'tools/test_osp_stage_b_native.R': 1,
    }),
    'livemorebio/tests/test_source_tree_gate.py': Counter({
        'docs/': 1,
        'docs/../livemorebio/cli.py': 1,
        'docs//solutions/record.json': 1,
        'docs/a-record-this-tree-has-lost.md': 1,
        'docs/alias': 1,
        'docs/alias.py': 2,
        'docs/alias/lost.md': 1,
        'docs/alias/record.md': 1,
        'docs/gone': 2,
        'docs/gone/record.md': 1,
        'docs/lock': 2,
        'docs/loop': 1,
        'docs/loop/record.md': 1,
        'docs/outside': 2,
        'docs/outside/record.md': 2,
        'docs/product-link': 3,
        'docs/product-link/missing.py': 4,
        'docs/real/record.md': 2,
        'docs/record.md': 2,
        'docs/solutions': 10,
        'docs/solutions/': 2,
        'docs/solutions/2026-09-08-beard-native-precision-v2-preregistration.md': 1,
        'docs/solutions/2026-09-08-beard-native-source-preregistration.md': 1,
        'docs/solutions/2026-09-08-full-scope-recovery-plan.md': 1,
        'docs/solutions/2026-09-08-osp-retained-runtime-static-inventory-v2.json': 1,
        'docs/solutions/2026-09-08-osp-stage-b-numerical-benchmark.md': 1,
        'docs/solutions/2026-09-09-osp-r-startup-contract-v1.json': 1,
        'docs/solutions/record.json': 2,
        'docs/tools-link': 1,
        'docs/tools-link/build_release.py': 1,
        'docs/tree': 3,
        'docs/tree/livemorebio/missing.py': 1,
        'livemorebio/tests/test_beard_precision_execution.py:154': 1,
        'livemorebio/tests/test_osp_semantic_supervisor.py:524': 1,
        'livemorebio/tests/test_osp_source_admission.py': 2,
        'livemorebio/tests/test_osp_stage_b.py': 2,
        'tools/build_tracker/index.html': 1,
        'tools/build_tracker/tracker.css': 1,
        'tools/build_tracker/tracker.js': 1,
        'tools/diagnostics/osp_vmmap_retained_forensics.py': 1,
        'tools/osp_dotnet_worker/Directory.Build.props': 1,
        'tools/osp_dotnet_worker/Fixtures.json': 1,
        'tools/osp_dotnet_worker/NativeSimulation.cs': 1,
        'tools/osp_dotnet_worker/NuGet.Config': 1,
        'tools/osp_dotnet_worker/Worker.csproj': 1,
        'tools/osp_dotnet_worker/global.json': 1,
        'tools/osp_dotnet_worker/tests/FakeTests.csproj': 1,
        'tools/osp_stage_b.py': 3,
        'tools/osp_stage_b_analysis.py': 1,
        'tools/osp_stage_b_native.R': 2,
        'tools/test_osp_stage_b_native.R': 1,
    }),
}


# F-17 excludes the payload, not the installed asset contract. These three
# execution-identity sources must retain their exact bytes and installed path;
# the acquisition regression names that path twice. L0-R2 adds the installer and
# two technical installer fixtures to the exact installed-dependency inventory.
# Additions/removals still fail; none of these references bundles model bytes.
REVIEWED_ACQUIRED_MODEL_REFERENCES = {
    name: Counter({'models/cardiac/ohara_rudy_cipa_2017.cellml': count})
    for name, count in (
        ('install.sh', 1),
        ('livemorebio/aegle/execution_adapters.py', 1),
        ('livemorebio/aegle/execution_contract.py', 1),
        ('livemorebio/engines/cardiac/action_potential.py', 1),
        ('livemorebio/tests/test_cardiac_assets.py', 2),
        ('livemorebio/tests/test_installer.py', 2),
        ('livemorebio/tests/test_l0_installer_models.py', 3),
    )
}


def _private_reference_inventory_mismatches(name: str, references: list[str]) -> dict[str, Counter[str]]:
    actual = Counter(references)
    reviewed = (REVIEWED_GATE_PRIVATE_REFERENCES.get(name, Counter())
                + REVIEWED_ACQUIRED_MODEL_REFERENCES.get(name, Counter()))
    return {kind: counts for kind, counts in (
        ('unreviewed', actual - reviewed), ('missing_reviewed', reviewed - actual)) if counts}


def test_new5c_pass_r_docs_private_reference_inventory_matches_source():
    name = 'livemorebio/tests/test_stable_new5c_pass_r_docs.py'
    references = _private_directory_references(
        (REPOSITORY_ROOT / name).read_text(encoding='utf-8'))
    assert not _private_reference_inventory_mismatches(name, references)


@pytest.mark.parametrize('name', [
    'livemorebio/tests/test_l0_clinical_note_gate.py',
    'livemorebio/tests/test_l0_free_text_gate.py',
    '.github/workflows/installer.yml',
    'livemorebio/tests/test_release_workflow.py',
    'livemorebio/tests/test_maintenance_closing_metadata.py',
    'Dockerfile', 'livemorebio/tests/_source_tree.py',
    'livemorebio/tests/test_container_image.py',
    'livemorebio/tests/test_frozen_tool_hashes.py',
    'livemorebio/tests/test_source_tree_gate.py',
    'livemorebio/tests/test_installer.py',
    'livemorebio/tests/test_console_tool_redaction.py',
    'livemorebio/tests/test_security_transport_part1.py',
    'livemorebio/tests/test_stable_followup_console.py',
    'livemorebio/tests/test_stable_followup_console_docs.py',
    'livemorebio/tests/test_stable_new5c_docs.py',
    'livemorebio/tests/test_stable_new5c_pass_r_docs.py',
    'livemorebio/tests/test_stable_new5c_console.py',
    'livemorebio/tests/test_stable_followup_console_origin.py',
    'livemorebio/tests/test_stable_new10_notebook_launch.py',
])
def test_reviewed_gate_references_allow_only_the_recorded_inventory(name):
    # L0-R2: a gate fixture can also name its exactly reviewed installed asset.
    reviewed = list((REVIEWED_GATE_PRIVATE_REFERENCES[name]
                     + REVIEWED_ACQUIRED_MODEL_REFERENCES.get(name, Counter())).elements())
    assert not _private_reference_inventory_mismatches(name, reviewed)
    duplicate = next(reference for reference in reviewed
                     if _private_directory_references(f'ROOT / "{reference}"'))
    for added in ('docs/unreviewed-boundary-reference.md', duplicate):
        extra = _private_directory_references(f'ROOT / "{added}"')
        assert extra
        assert _private_reference_inventory_mismatches(name, [*reviewed, *extra])
    assert _private_reference_inventory_mismatches(name, reviewed[1:])


@pytest.mark.parametrize('gate', [
    'livemorebio/tests/test_l0_clinical_note_gate.py',
    'livemorebio/tests/test_l0_free_text_gate.py',
    '.github/workflows/installer.yml',
    'livemorebio/tests/test_release_workflow.py',
    'livemorebio/tests/test_maintenance_closing_metadata.py',
    'Dockerfile', 'livemorebio/tests/_source_tree.py',
    'livemorebio/tests/test_container_image.py',
    'livemorebio/tests/test_frozen_tool_hashes.py',
    'livemorebio/tests/test_source_tree_gate.py',
    'livemorebio/tests/test_installer.py',
    'livemorebio/tests/test_console_tool_redaction.py',
    'livemorebio/tests/test_security_transport_part1.py',
    'livemorebio/tests/test_stable_followup_console.py',
    'livemorebio/tests/test_stable_followup_console_docs.py',
    'livemorebio/tests/test_stable_new5c_docs.py',
    'livemorebio/tests/test_stable_new5c_pass_r_docs.py',
    'livemorebio/tests/test_stable_new5c_console.py',
    'livemorebio/tests/test_stable_followup_console_origin.py',
    'livemorebio/tests/test_stable_new10_notebook_launch.py',
])
def test_reviewed_gate_references_are_not_allowed_in_runtime_files(gate):
    assert _private_reference_inventory_mismatches('livemorebio/runtime.py', []) == {}
    for reference in REVIEWED_GATE_PRIVATE_REFERENCES[gate]:
        assert _private_reference_inventory_mismatches('livemorebio/runtime.py', [reference]) == {
            'unreviewed': Counter({reference: 1})}


@pytest.mark.parametrize('name,count', [
    ('livemorebio/aegle/execution_adapters.py', 1),
    ('livemorebio/aegle/execution_contract.py', 1),
    ('livemorebio/engines/cardiac/action_potential.py', 1),
    ('livemorebio/tests/test_cardiac_assets.py', 2),
])
def test_acquired_cardiac_references_have_an_exact_reviewed_inventory(name, count):
    path = 'models/cardiac/ohara_rudy_cipa_2017.cellml'
    references = _private_directory_references(
        (REPOSITORY_ROOT / name).read_text(encoding='utf-8'))
    assert references == [path] * count
    assert not _private_reference_inventory_mismatches(name, references)
    assert _private_reference_inventory_mismatches(name, references + [path])
    assert _private_reference_inventory_mismatches(name, references[:-1])
    assert _private_reference_inventory_mismatches(name, references + ['docs/private.txt'])
    assert _private_reference_inventory_mismatches('livemorebio/runtime.py', references)


@pytest.mark.parametrize('name,count', [
    pytest.param('install.sh', 1, marks=source_tree_only('install.sh')),
    ('livemorebio/tests/test_installer.py', 2),
    ('livemorebio/tests/test_l0_installer_models.py', 3),
])
def test_installer_references_only_the_reviewed_acquired_cardiac_path(name, count):
    """L0-R2: installed-asset checks and technical fixture writers, never bundling."""
    references = _private_directory_references(
        (REPOSITORY_ROOT / name).read_text(encoding='utf-8'))
    path = 'models/cardiac/ohara_rudy_cipa_2017.cellml'
    assert references.count(path) == count
    assert not _private_reference_inventory_mismatches(name, references)
    assert _private_reference_inventory_mismatches(name, references + [path])
    assert _private_reference_inventory_mismatches(name, [ref for ref in references if ref != path])
    assert _private_reference_inventory_mismatches('livemorebio/runtime.py', [path])


@pytest.mark.parametrize('public_projection', [False, True])
@pytest.mark.parametrize('tool', ['notebook_recording.cjs', 'test_notebook_recording.cjs'])
def test_new10_private_tool_gate_only_skips_a_marked_public_archive(tmp_path, monkeypatch, tool, public_projection):
    from . import test_stable_new10_notebook_launch as notebook_tests

    root = tmp_path / 'technical-tree'
    root.mkdir()
    if public_projection:
        (root / '.livemore-distribution.json').write_text(
            json.dumps({'schema': 'livemore.distribution.v1', 'audience': 'public'}), encoding='utf-8')
    monkeypatch.setattr(notebook_tests, '__file__', str(root / 'livemorebio/tests/test_stable_new10_notebook_launch.py'))
    exception = pytest.skip.Exception if public_projection else AssertionError
    reason = 'private reference data is omitted from the public archive' if public_projection else 'PRIVATE_REFERENCE_MISSING'
    with pytest.raises(exception, match=reason):
        notebook_tests.test_notebook_runtime_and_recorder_tooling_are_private(f'tools/{tool}')


def _mask_technical_fixture_expression(name: str, source: str) -> str:
    """Only the declared pytest temporary-path expression is outside this scan."""
    if name != 'livemorebio/tests/test_discovery_substrate.py':
        return source
    raw = source.encode('utf-8')
    offsets = [0]
    for line in raw.splitlines(keepends=True):
        offsets.append(offsets[-1] + len(line))
    spans = []
    for node in ast.walk(ast.parse(source)):
        if (isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div)
                and isinstance(node.left, ast.Name) and node.left.id == 'tmp_path'
                and isinstance(node.right, ast.Constant)
                and node.right.value == 'livemorebio/discovery/data'):
            spans.append((offsets[node.lineno - 1] + node.col_offset,
                          offsets[node.end_lineno - 1] + node.end_col_offset))
    for start, end in sorted(spans, reverse=True):
        raw = raw[:start] + b' ' * (end - start) + raw[end:]
    return raw.decode('utf-8')


def test_no_shipped_file_references_excluded_paths(archives):
    files = _files(archives[1])
    # Policy and regression fixtures necessarily name the forbidden categories;
    # they are never runtime readers. All other shipped files are scanned.
    boundary_tests = {'tools/public_distribution.py', 'livemorebio/tests/test_public_distribution.py',
                      'livemorebio/tests/test_public_rework.py',
                      'livemorebio/tests/test_stable_new5a_publication.py'}
    bad = {}
    for name, raw in files.items():
        if name in boundary_tests:
            continue
        source = raw.decode('utf-8', errors='replace')
        hits = _private_directory_references(_mask_technical_fixture_expression(name, source))
        mismatches = _private_reference_inventory_mismatches(name, hits)
        if mismatches: bad[name] = mismatches
        for literal in ('All_193_Druggability_Profiles.json', 'Complete_Safety_Flag_Register.csv',
                        'Complete_Book_Monograph_Inventory.csv'):
            if literal in raw.decode('utf-8', errors='replace'):
                assert (name, literal) in REVIEWED_PRIVATE_REFERENCES, (name, literal)
    assert not bad


def test_optional_book_references_have_executable_refusal_tests(archives):
    files = _files(archives[1])
    tests = files['livemorebio/tests/test_discovery_substrate.py'].decode()
    for (name, literal), test_id in REVIEWED_PRIVATE_REFERENCES.items():
        assert literal in files[name].decode()
        assert f'def {test_id}(' in tests, test_id


def test_public_files_contain_no_prohibited_content(archives):
    forbidden = re.compile(rb'(?i)(?:\b(?:hsa|path|ds|dr):\d+|\b(?:hsa|map|ko)\d{5}\b|\b[HDCKRMNG]\d{5}\b)')
    homes = re.compile(rb'(?<![A-Za-z0-9.:])/(?:Users|home)/[A-Za-z0-9_.-]+/')
    # One-way marker hashes avoid redistributing restricted markers.
    markers = {16: {'db904016264df0ffd4d9556492ff7a579190456061a45ccc39299de7e48147fa'}, 13: {'4432505780271fb42bd179865154bd4b3a88e4bb389175dc5ebbb5dcba84fa4d'}}
    for name, raw in _files(archives[1]).items():
        assert not forbidden.search(raw), name
        assert not homes.search(raw), name
        for length, digests in markers.items():
            for token in re.findall(rb"[A-Za-z0-9_]+", raw):
                assert all(hashlib.sha256(token[i:i + length]).hexdigest() not in digests
                           for i in range(max(0, len(token) - length + 1))), name
        assert not name.startswith('docs/solutions/'), name
        assert not name.startswith('livemorebio/discovery/data/'), name


def test_every_public_relative_markdown_link_resolves(archives):
    from posixpath import normpath, join, dirname
    files = _files(archives[1])
    for name, raw in files.items():
        if not name.endswith('.md'): continue
        for target in re.findall(r'\]\(([^)\s]+)(?:\s+"[^"]*")?\)', raw.decode(errors='replace')):
            target = target.strip('<>').split('#')[0]
            if not target or re.match(r'[a-zA-Z]+:', target): continue
            destination = normpath(join(dirname(name), target))
            assert destination in files or any(p.startswith(destination.rstrip('/') + '/') for p in files), (name, target)


def test_public_and_private_archive_product_fingerprints_match(archives, tmp_path):
    from livemorebio.build_info import source_fingerprint
    fingerprints = []
    for audience, result in zip(('private', 'public'), archives):
        root = tmp_path / audience
        for name, raw in _files(result).items():
            if not name.startswith('livemorebio/'): continue
            path = root / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(raw)
        fingerprints.append(source_fingerprint(root / 'livemorebio'))
    assert fingerprints[0] is not None and fingerprints[0] == fingerprints[1]


def test_no_empty_excluded_directory_entries(archives):
    with tarfile.open(archives[1]['archive']) as handle:
        members = handle.getmembers()
    for member in members:
        if member.isdir():
            assert any(other.isfile() and other.name.startswith(member.name.rstrip('/') + '/') for other in members), member.name


def test_public_archive_seed_matches_archived_ref_not_working_tree(archives):
    private, public = map(_files, archives)
    for name, raw in public.items():
        if name.startswith(('livemorebio/life_system/seed/', 'livemorebio/life_system/reference/seed/')):
            assert raw == private[name], name


@pytest.mark.parametrize("source", [
    "from tools import osp_semantic_supervisor", "import tools.beard_source_execution",
    "from livemorebio.tests import test_osp_source_admission",
])
def test_import_scan_detects_excluded_modules_in_any_python_file(source):
    assert _private_import_references("tools/technical_test.py", source)


@pytest.mark.parametrize("source", [
    "from tools import public_distribution", "import livemorebio.build_info",
    "from pathlib import Path",
])
def test_import_scan_accepts_public_and_external_modules(source):
    assert not _private_import_references("livemorebio/tests/technical_test.py", source)


# Private editorial states must not appear in client documents or seed metadata.
EDITORIAL_STATE_SHA256 = {1: {'dda18a0e21ae47c53b4309434cbc02ae8bf764fa83a6defbb719431242722aa7', '59458508a0827cff5f80ed091ebd8808fbe67c97357b58ca00a278e7359dec20', 'fbf980930eee5837329586f5075e7f07e0d0d6ad409fedbb65d174144966c3fa', '6973dddd3ef9cb6a2932702f31777faad9c9bf3124d147a84f31aadb6d139546'}, 4: {'a564a5dfcf3a2dfd37c9b00657cb9634a3f2633c0feae826b5a9e12d7f9c4a25'}, 2: {'06f9b79d9882e032c17944993472452166af7c4f21cf9a1e2cc8f80a39cfb8ea', '4bdb9c9ac51173780b5cb3b032e3aac3d1e57b417fce03f49c5e929c8fc39cfb', '9bf0c38580dad78880f396f2b9fce05a488238e8fc1e6247a637244d2735e057'}, 3: {'9075f1c24f9fe5d2d96e1ded447d420c8f33148ebd86b16db7c4886d3175e2d9'}}


def _assert_final_client_language(files):
    from tools.public_distribution import PUBLIC_DOCUMENTS
    document_names = {*PUBLIC_DOCUMENTS, "README.md", "THIRD_PARTY_NOTICES.md", "dist-public/README.md"}
    for name, raw in files.items():
        if name not in document_names and not name.endswith("/seed/meta.json"):
            continue
        words = re.findall(r"[a-z]+", raw.decode(errors="replace").lower())
        for width, digests in EDITORIAL_STATE_SHA256.items():
            for start in range(len(words) - width + 1):
                phrase = " ".join(words[start:start + width])
                assert hashlib.sha256(phrase.encode()).hexdigest() not in digests, name


def test_public_documents_use_final_client_language(archives):
    _assert_final_client_language(_files(archives[1]))


def test_distribution_landing_document_uses_final_client_language():
    from ._source_tree import require_source_tree
    from .private_reference_helpers import require_private_reference_data
    require_source_tree("dist-public/README.md")
    path = REPOSITORY_ROOT / "dist-public" / "README.md"
    require_private_reference_data(path)
    _assert_final_client_language({"dist-public/README.md": path.read_bytes()})


# Six excluded entry titles are represented only by casefolded, whitespace-normalized hashes.
# Regression inputs live in private fixtures outside the public projection.
PROHIBITED_TITLE_SHA256 = {37: {'7180177e39a8b058f2b481a1be5f42e1965c195d6e9294afc659c75871d1c00f'}, 32: {'2be3dafe3fa98a7287a5188a6a0faa66478c9f055551b01c5343354dddb85f19', '3ab3f3e478ea4960ab6fb1d994f8c18f6e063468d1b366e1d1491c1f56e7ac2b'}, 34: {'c0e8ccd44fcacd363f310a270caf15ada6d4767d66cf06181cacd9a99c68684a'}, 19: {'3bf209f1fbe31c067e780b98ef28f20522055ebe4a3ba90eab3fa4cb582006e4'}, 44: {'c59c8047cbb835664dc954b4708c5c0c61cd40656660eb32c0548b6ba99b3350'}}


def _prohibited_disease_titles(raw: bytes) -> list[str]:
    # Keep punctuation: separate query and abbreviation fields are not a title.
    text = " ".join(raw.decode("utf-8", errors="replace").casefold().split())
    hits = []
    for match in re.finditer(r"\b[a-z]", text):
        start = match.start()
        for width, digests in PROHIBITED_TITLE_SHA256.items():
            digest = hashlib.sha256(text[start:start + width].encode()).hexdigest()
            if digest in digests:
                hits.append(digest)
    return hits


def test_every_public_file_omits_excluded_disease_entry_titles(archives):
    for name, raw in _files(archives[1]).items():
        assert not _prohibited_disease_titles(raw), name


@pytest.mark.parametrize("name,source", [
    ("livemorebio/tests/test_discovery_substrate.py", 'ROOT / "livemorebio/discovery/data"'),
    ("livemorebio/tests/test_discovery_substrate.py",
     'tmp_path / "livemorebio/discovery/data"\nROOT / "livemorebio/discovery/data"'),
    ("livemorebio/technical_reader.py", 'tmp_path / "livemorebio/discovery/data"'),
])
def test_fixture_path_exception_does_not_admit_product_dependency(monkeypatch, name, source):
    monkeypatch.setitem(globals(), "_files", lambda _: {name: source.encode()})
    with pytest.raises(AssertionError):
        test_no_shipped_file_references_excluded_paths((None, None))


def test_only_the_actual_temporary_fixture_expression_is_exempt(monkeypatch):
    monkeypatch.setitem(globals(), "_files", lambda _: {
        "livemorebio/tests/test_discovery_substrate.py":
            b'reference_dir = tmp_path / "livemorebio/discovery/data"',
    })
    test_no_shipped_file_references_excluded_paths((None, None))
