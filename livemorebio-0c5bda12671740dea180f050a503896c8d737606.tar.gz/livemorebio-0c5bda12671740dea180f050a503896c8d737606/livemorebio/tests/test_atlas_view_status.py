"""Actual controller, authored metadata and in-memory responses; no GPU or peer I/O."""
from __future__ import annotations

import json

import pytest

from ._node import flush_js
from .test_atlas_reference_ui import CONSOLE, node, technical_manifest


def controller(checks: str) -> str:
    return f"""import {{mountAtlasReference}} from {json.dumps((CONSOLE/'lib/atlas_reference.js').as_uri())};
import {{atlasViewState}} from {json.dumps((CONSOLE/'lib/atlas_reference_scene.js').as_uri())};
globalThis.fetch=()=>{{throw Error('Unexpected controller network')}};
const all=[],handlers={{}},messages=[],views=[],visibility=[];
class E {{constructor(){{this.handlers={{}};this.dataset={{}};this.children=[];this.value='';this.disabled=false;this.hidden=false;all.push(this)}}
addEventListener(k,v){{this.handlers[k]=v}}removeEventListener(k){{delete this.handlers[k]}}setAttribute(){{}}
append(...items){{this.children.push(...items)}}replaceChildren(...items){{this.children=items}}get options(){{return this.children}}
set textContent(value){{this.text=value;if(this.status)messages.push(value)}}get textContent(){{return this.text||''}}}}
const elements=new Map(),host=new E();host.querySelector=s=>{{if(!elements.has(s))elements.set(s,new E());return elements.get(s)}};
for(const direction of ['front','side','back'])host.querySelector('[data-view="'+direction+'"]').dataset.view=direction;
host.querySelector('[data-status]').status=true;
host.querySelectorAll=s=>s==='[data-group]'?all.filter(e=>e.dataset.group):s==='[data-view]'?all.filter(e=>e.dataset.view):[];
globalThis.document={{hidden:false,createElement:()=>new E(),createTextNode:text=>({{textContent:text}}),addEventListener(k,v){{handlers[k]=v}},removeEventListener(k){{delete handlers[k]}}}};
const manifest={json.dumps(technical_manifest())},bytes=new Uint8Array(100),hash=Buffer.from(await crypto.subtle.digest('SHA-256',bytes)).toString('hex');manifest.assets.forEach(a=>a.sha256=hash);
const available={{schema:'livemore.atlas-reference-status.v1',source_id:manifest.source_id,state:'available',available:true,reference_geometry:true,patient_registered:false,manifest,manifest_sha256:'a'.repeat(64)}};
const missing={{...available,state:'missing',available:false,manifest:null,manifest_sha256:null,reason:'Reference absent'}};
let current=available,failStatus=false,holdStatus=false,releaseStatus=null,heldSignal=null,posts=0,created=0,disposed=0,config=null,scene=null;
const failedAssets=new Set(),applied=[];
const fetchImpl=async(url,init)=>{{
 if(init.method==='POST'){{posts++;return Response.json({{}})}}
 if(url.startsWith('/api/')){{if(holdStatus)await new Promise(resolve=>{{releaseStatus=resolve;heldSignal=init.signal}});if(failStatus)throw Error('Technical status unavailable');return Response.json(current)}}
 if([...failedAssets].some(key=>url.endsWith('/'+key+'.glb')))return new Response('',{{status:503}});
 return new Response(bytes,{{headers:{{'Content-Type':'model/gltf-binary','X-Content-SHA256':hash,'X-Atlas-Manifest-SHA256':current.manifest_sha256}}}});
}};
const createScene=options=>{{config=options;created++;let state=atlasViewState(options.initialView);scene={{
 async addPartition(asset,buffer,isCurrent){{if(!isCurrent())throw Error('Stale partition');applied.push(asset.asset_key)}},
 view:()=>atlasViewState(state),update:next=>{{state=atlasViewState(next)}},
 select:id=>{{state.selected=id;const group=manifest.assets.find(a=>a.audit.element_ids.includes(id))?.asset_key;if(group&&!state.groups.includes(group))state.groups.push(group);options.onSelect(id)}},
 home(){{state=atlasViewState({{labels:state.labels}});options.onSelect(null)}},frameSelected(){{}},
 visible(){{visibility.push(document.hidden)}},dispose(){{disposed++}},metrics:()=>({{}})}};return scene;
}};
{flush_js(60)}
const mounted=mountAtlasReference(host,{{fetchImpl,loadDependencies:async()=>({{}}),createScene,onViewChange:state=>views.push(state)}});
const status=()=>host.querySelector('[data-view-status]');
const click=selector=>host.querySelector(selector).handlers.click();
const group=(key,enabled)=>{{const input=all.find(e=>e.dataset.group===key);input.checked=enabled;input.handlers.change()}};
const section=(axis,depth=.5)=>{{const input=host.querySelector('[data-axis]');input.value=axis;input.handlers.change();const slider=host.querySelector('[data-depth]');slider.value=String(depth);slider.handlers.input()}};
const select=key=>scene.select(manifest.assets.find(a=>a.asset_key===key).audit.element_ids[0]);
await flush();try{{{checks}}}finally{{mounted.dispose();if(releaseStatus){{holdStatus=false;releaseStatus();await flush()}}}}
console.log('ok');"""


def check(program: str) -> None:
    assert node(controller(program)).strip() == "ok"


def test_loading_status_never_equates_loaded_resources_with_drawn_pixels():
    check(r"""
if(applied.length!==9||host.dataset.referenceState!=='ready')throw Error('fixture did not load');
if(messages.some(text=>/drawn/.test(text))||!messages.some(text=>/^1 \/ 9 reference layers loaded/.test(text)))throw Error('loading claim conflates pixels');
if(status().hidden||!/^9 layers enabled · 9 \/ 9 layers loaded\. Section off\./.test(status().textContent))throw Error('separate loaded/enabled state absent');
if(/rendered|visible anatomy/i.test(status().textContent))throw Error('view settings claim pixel visibility');
""")


def test_enabled_disabled_all_and_section_are_independent_of_loaded_count():
    check("""
group('heart',false);
if(!status().textContent.includes('8 layers enabled · 9 / 9 layers loaded'))throw Error('enabled/loaded conflated');
for(const asset of manifest.assets)group(asset.asset_key,false);
if(!status().textContent.includes('All loaded layers are disabled')||!status().textContent.includes('Return to whole person'))throw Error('empty settings unexplained');
section('z',.37);
if(!status().textContent.includes('Section z active at 37%')||!status().textContent.includes('a cut can leave an empty view')||!status().textContent.includes('Section off'))throw Error('section behavior unexplained');
click('[data-clear]');
if(!status().textContent.includes('9 layers enabled')||!status().textContent.includes('Section off.')||status().textContent.includes('active at'))throw Error('home did not reset settings copy');
""")


def test_isolation_reports_exact_source_disabled_and_reenabled_layer_settings():
    check("""
select('pancreas');click('[data-isolate]');const id=scene.view().selected;
if(!status().textContent.includes('Isolated source ID '+id))throw Error('exact isolated ID absent');
group('pancreas',false);
if(!status().textContent.includes('pancreas is disabled')||!status().textContent.includes('empty view'))throw Error('disabled isolated layer implied displayed');
group('pancreas',true);
if(status().textContent.includes('is disabled')||!status().textContent.includes('Isolated source ID '+id))throw Error('re-enabled setting stale');
""")


def test_retry_retains_isolation_but_does_not_claim_unloaded_element_displayed():
    check("""
select('brain');click('[data-isolate]');const id=scene.view().selected;
failedAssets.add('brain');click('[data-retry]');await flush();
if(host.dataset.referenceState!=='partial'||status().hidden||!status().textContent.includes('Isolated source ID '+id)||!status().textContent.includes('brain is not loaded'))throw Error('unloaded isolation state lost');
if(!status().textContent.includes('8 / 9 layers loaded'))throw Error('partial loaded membership wrong');
""")


@pytest.mark.parametrize("state", ["error", "unavailable", "pending", "paused"])
def test_nonoperational_feedback_hides_settings_even_when_geometry_is_retained(state):
    setup = {
        "error": "failStatus=true;click('[data-retry]');await flush();if(views.at(-1)?.ready!==true)throw Error('retained readiness prerequisite absent');",
        "unavailable": "current=missing;click('[data-retry]');await flush();",
        "pending": "holdStatus=true;click('[data-retry]');await flush();",
        "paused": "document.hidden=true;handlers.visibilitychange();",
    }[state]
    check(setup + f"""
if(host.dataset.referenceState!=={json.dumps(state)})throw Error('expected state absent');
if(!status().hidden||status().textContent!=='')throw Error('stale healthy view sentence retained');
""")


def test_failure_recovery_and_changed_manifest_restore_only_current_settings():
    check("""
select('heart');click('[data-isolate]');section('x',.2);
failStatus=true;click('[data-retry]');await flush();if(!status().hidden)throw Error('failed status shown');
failStatus=false;click('[data-retry]');await flush();
if(status().hidden||!status().textContent.includes('Isolated source ID')||!status().textContent.includes('Section x active at 20%'))throw Error('same-source recovery lost settings');
current={...available,manifest_sha256:'c'.repeat(64)};click('[data-retry]');await flush();
if(status().hidden||!status().textContent.includes('9 layers enabled')||!status().textContent.includes('Section off.')||status().textContent.includes('Isolated'))throw Error('new source retained incompatible state');
""")


def test_context_loss_hides_view_sentence_and_both_visibility_transitions_reach_scene():
    check("""
document.hidden=true;handlers.visibilitychange();
if(JSON.stringify(visibility)!=='[true]')throw Error('hidden scene not notified immediately');
document.hidden=false;handlers.visibilitychange();await flush();
if(JSON.stringify(visibility)!=='[true,false]'||status().hidden)throw Error('visible recovery absent');
config.onContextLost();
if(host.dataset.referenceState!=='error'||!status().hidden||status().textContent!=='')throw Error('context loss retained healthy sentence');
""")


def test_selected_inspection_keeps_provenance_and_discloses_extent_not_contour():
    check("""
select('pancreas');const member=manifest.members.find(m=>m.element_id===scene.view().selected),text=host.querySelector('[data-selection]').textContent;
for(const value of [member.name,member.element_id,member.concept_id,member.source_sha256,JSON.stringify(member.bounds_mm),'source vertices','triangles','Reference geometry only'])if(!text.includes(value))throw Error('selected provenance lost '+value);
for(const phrase of ['source extent','not an anatomical contour','section plane','Section off','Frame selected','Isolate','Return to whole person'])if(!text.includes(phrase))throw Error('cue limitation missing '+phrase);
""")
