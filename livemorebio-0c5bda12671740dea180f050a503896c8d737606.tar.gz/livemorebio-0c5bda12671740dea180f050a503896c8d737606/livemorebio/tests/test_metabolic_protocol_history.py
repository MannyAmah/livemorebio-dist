"""Frozen metabolic runs and protocol dispatch are not implicit PXR experiments."""
import json
import ast
import os
from pathlib import Path
import uuid
from concurrent.futures import ThreadPoolExecutor

import pytest

from livemorebio.cendos import metabolic_protocol
from livemorebio.cendos.protocol_runs import ProtocolRunStore, analysis_csv, analysis_notebook
from livemorebio.engines import stoichiometry
from livemorebio.research import ResearchError, prediction_rows


def request():
    return {"model_id": "human-gem", "conditions": [
        {"condition_id": "aerobic", "glucose_uptake": 1, "oxygen_uptake": 6}], "knockout_gene_ids": []}


@pytest.fixture
def result(monkeypatch):
    monkeypatch.setattr(stoichiometry, "execute", lambda spec: {
        "model": {"model_id": "human-gem", "release": "2.0.0", "model_sha256": "a" * 64},
        "conditions": [{"condition_id": "aerobic", "objective_flux": 31.5,
                        "actual_glucose_uptake": 1, "actual_oxygen_uptake": 6,
                        "mass_balance_residual": 0, "bound_residual": 0, "solver_status": "optimal",
                        "fva_status": "not_computed", "constraints_sha256": "b" * 64}],
        "controls": [{"condition_id": "control-closed-medium", "objective_flux": 0, "passed": True},
                     {"condition_id": "control-no-glucose", "objective_flux": 0, "passed": True}],
        "solver": {"name": "GLPK"},
    })
    return metabolic_protocol.run_human_gem_oxygen_capacity(request())


def test_model_result_has_no_person_roster_or_physical_validation(result):
    assert result["protocol_id"] == "cendos.human-gem-oxygen-capacity.v1"
    assert result["evidence_state"] == "MODELED_STEADY_STATE"
    assert result["unit"] == "mmol/gDW/h"
    assert result["input"]["conditions"][0]["condition_id"] == "aerobic"
    assert not {"members", "cohort", "cohorts"} & set(result)
    with pytest.raises(ResearchError, match="cell|assay"):
        prediction_rows(result)


def test_exports_explicitly_dispatch_and_reject_unknown_protocol(result):
    assert "objective_flux" in analysis_csv(result)
    notebook = analysis_notebook(result)
    joined = "\n".join("".join(cell["source"]) for cell in notebook["cells"])
    assert "steady-state" in joined.lower() and "glucose" in joined.lower()
    assert "relative_pxr_activation" not in joined
    for export in (analysis_csv, analysis_notebook):
        with pytest.raises(ValueError, match="protocol"):
            export({**result, "protocol_id": "unknown.protocol"})


def test_history_is_stable_paged_search_and_not_person_index(tmp_path: Path, result):
    store = ProtocolRunStore(tmp_path / "runs")
    for number in range(5):
        store.save({**result, "run_id": "protocol-" + f"{number:032x}",
                    "executed_at": f"2026-09-05T00:00:0{number}Z"})
    first = store.history(limit=2)
    assert len(first["runs"]) == 2 and first["pagination"]["has_more"]
    store.save({**result, "run_id": "protocol-" + uuid.uuid4().hex,
                "executed_at": "2026-09-06T00:00:00Z"})
    second = store.history(limit=2, cursor=first["pagination"]["next_cursor"])
    assert not {row["run_id"] for row in first["runs"]} & {row["run_id"] for row in second["runs"]}
    assert second["pagination"]["total"] == 5
    assert store.history(q="oxygen")["pagination"]["total"] == 6
    assert all("cohort" not in row and "members" not in row for row in first["runs"])
    with pytest.raises(ValueError):
        store.history(cursor="malformed")


def test_prepare_is_read_only_and_exact_parent_configuration_is_required(tmp_path: Path, result, monkeypatch):
    store = ProtocolRunStore(tmp_path / "runs")
    store.save(result)
    original = store._path(result["run_id"]).read_bytes()
    prepared = store.prepare_rerun(result["run_id"])
    assert prepared["request"] == result["input"]
    assert prepared["parent_run_id"] == result["run_id"]
    assert prepared["rerun_mode"] == "exact"
    assert store._path(result["run_id"]).read_bytes() == original
    changed = request()
    changed["conditions"][0]["oxygen_uptake"] = 0
    with pytest.raises(ValueError, match="configuration"):
        store.validate_rerun(result["run_id"], changed)


def test_legacy_history_retained_without_fabricating_source_hash(tmp_path: Path):
    store = ProtocolRunStore(tmp_path / "runs")
    legacy = {"run_id": "protocol-" + "1" * 32, "protocol_id": "cendos.garcinoic-acid-pxr.v1",
              "executed_at": "2026-09-05T00:00:00Z", "cohort": {"cohort_id": "cohort-old"},
              "target_engagement": [{"concentration_um": 1.3}], "evidence_state": "MODELED_TARGET_ENGAGEMENT"}
    store._path(legacy["run_id"]).write_text(json.dumps(legacy), encoding="utf-8")
    assert store.history()["runs"][0]["run_id"] == legacy["run_id"]
    prepared = store.prepare_rerun(legacy["run_id"])
    assert prepared["rerun_mode"] == "new_configuration" and prepared["warnings"]
    assert "cohort_sha256" not in prepared


def test_rerun_checks_frozen_inputs_and_model_identity(tmp_path, result, monkeypatch):
    from livemorebio import model_assets
    store = ProtocolRunStore(tmp_path / "runs")
    store.save(result)
    monkeypatch.setattr(model_assets, "verified_asset", lambda model: {"model_sha256": "a" * 64})
    assert store.validate_rerun(result["run_id"], result["input"])["reproducible_parent_configuration"] is True
    with pytest.raises(ValueError, match="parent protocol"):
        store.validate_rerun(result["run_id"], result["input"], expected_protocol_id="different", new_configuration=True)
    monkeypatch.setattr(model_assets, "verified_asset", lambda model: {"model_sha256": "c" * 64})
    with pytest.raises(ValueError, match="model release"):
        store.validate_rerun(result["run_id"], result["input"])
    assert store.validate_rerun(result["run_id"], result["input"], new_configuration=True)["rerun_mode"] == "new_configuration"


def test_cohort_snapshot_exactness_and_legacy_acknowledgment(tmp_path):
    from livemorebio.cendos.protocol_runs import attach_run_inputs
    cohort = {"cohort_id": "cohort-a", "version": 1, "members": [{"id": "one", "value": 3}]}
    source = {"run_id": "protocol-" + "2" * 32, "protocol_id": "cendos.garcinoic-acid-pxr.v1",
              "cohort": {"cohort_id": "cohort-a"}, "target_engagement": [{"concentration_um": 1.3}]}
    run = attach_run_inputs(source, {}, [cohort])
    store = ProtocolRunStore(tmp_path / "runs"); store.save(run)
    assert store.validate_rerun(run["run_id"], run["input"], lambda key: cohort)["rerun_mode"] == "exact"
    changed = {**cohort, "version": 2}
    with pytest.raises(ValueError, match="cohort source changed"):
        store.validate_rerun(run["run_id"], run["input"], lambda key: changed)
    assert store.validate_rerun(run["run_id"], run["input"], lambda key: changed, new_configuration=True)["rerun_mode"] == "new_configuration"
    with pytest.raises(ValueError, match="identities"):
        attach_run_inputs(source, {}, [{**cohort, "cohort_id": "other"}])


def test_model_notebook_code_executes_frozen_result_without_recomputation(result):
    result["conditions"][0]["constraints"] = {"glucose_uptake": 1, "oxygen_uptake": 6}
    import matplotlib
    matplotlib.use("Agg")
    namespace = {}
    for cell in analysis_notebook(result)["cells"]:
        if cell["cell_type"] == "code":
            exec("".join(cell["source"]), namespace)
    assert namespace["result"] == result


def test_history_index_rejects_arbitrary_private_metadata(tmp_path, result):
    store = ProtocolRunStore(tmp_path / "runs")
    store.save({**result, "protocol_id": "private diagnosis label", "executed_at": "private timestamp label",
                "parent_run_id": "private identifier", "evidence_state": "private evidence"})
    rows = store.history()["runs"]
    assert "private" not in json.dumps(rows)


def test_history_admits_every_evidence_state_emitted_by_shipped_protocols(tmp_path):
    """Discover producer declarations so new shipped evidence cannot fall through."""
    from livemorebio.cendos import protocol_runs

    declarations = set()
    for path in Path(protocol_runs.__file__).parent.glob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        constants = {
            target.id: node.value.value
            for node in tree.body if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant)
            for target in node.targets if isinstance(target, ast.Name)
        }
        for node in ast.walk(tree):
            if not isinstance(node, ast.Dict):
                continue
            fields = {key.value: value for key, value in zip(node.keys, node.values)
                      if isinstance(key, ast.Constant)}
            schema = fields.get("schema")
            if not (isinstance(schema, ast.Constant) and schema.value == "livemore.cendos-protocol-result.v1"):
                continue
            protocol = fields["protocol_id"]
            protocol = constants.get(protocol.id) if isinstance(protocol, ast.Name) else ast.literal_eval(protocol)
            assert isinstance(fields["evidence_state"], ast.Constant), "Review dynamic evidence emission explicitly"
            declarations.add((protocol, ast.literal_eval(fields["evidence_state"])))
    assert {protocol for protocol, _ in declarations} == set(protocol_runs._PROTOCOLS)
    store = ProtocolRunStore(tmp_path / "runs")
    expected = {}
    for number, (protocol, evidence) in enumerate(sorted(declarations)):
        run_id = "protocol-" + f"{number:032x}"
        store.save({"run_id": run_id, "protocol_id": protocol, "evidence_state": evidence,
                    "executed_at": "2026-10-30T00:00:00Z"})
        expected[run_id] = evidence
    assert {row["run_id"]: row["evidence_state"] for row in store.history()["runs"]} == expected


@pytest.mark.parametrize("protocol", [
    "cendos.exogenous-insulin-paired.v1", "cendos.botanical-exposure-margin.v1",
])
def test_history_repairs_only_matching_legacy_modeled_only_index_entries(tmp_path, protocol):
    store = ProtocolRunStore(tmp_path / "runs")
    records = [
        {"run_id": "protocol-" + f"{number:032x}", "protocol_id": recorded_protocol,
         "evidence_state": evidence, "executed_at": "2026-10-30T00:00:00Z"}
        for number, (recorded_protocol, evidence) in enumerate([
            (protocol, "MODELED_ONLY"), (protocol, "unknown-evidence"),
            ("cendos.metformin-cohort-comparison.v1", "MODELED_ONLY"),
        ])
    ]
    for record in records:
        store.save(record)
    original_bytes = {record["run_id"]: store._path(record["run_id"]).read_bytes() for record in records}
    with store._index() as db:
        db.execute("UPDATE runs SET evidence_state='UNASSESSED'")
        original_rows = db.execute("SELECT * FROM runs ORDER BY run_id").fetchall()

    # Reopen the store as an upgraded launch would, with its existing derived index.
    upgraded = ProtocolRunStore(store.directory)
    expected = {records[0]["run_id"]: "MODELED_ONLY", records[1]["run_id"]: "UNASSESSED",
                records[2]["run_id"]: "UNASSESSED"}
    assert {row["run_id"]: row["evidence_state"] for row in upgraded.history()["runs"]} == expected
    assert {row["run_id"]: row["evidence_state"] for row in upgraded.history()["runs"]} == expected
    assert {run_id: upgraded._path(run_id).read_bytes() for run_id in original_bytes} == original_bytes
    with upgraded._index() as db:
        repaired_rows = db.execute("SELECT * FROM runs ORDER BY run_id").fetchall()
    for before, after in zip(original_rows, repaired_rows):
        assert before[:4] + before[5:] == after[:4] + after[5:]


@pytest.mark.parametrize("protocol", [
    "cendos.exogenous-insulin-paired.v1", "cendos.botanical-exposure-margin.v1",
])
@pytest.mark.parametrize("tamper", ["record", "index_digest"])
def test_history_never_promotes_legacy_evidence_with_a_digest_mismatch(tmp_path, protocol, tamper):
    store = ProtocolRunStore(tmp_path / "runs")
    record = {"run_id": "protocol-" + "e" * 32, "protocol_id": protocol,
              "evidence_state": "MODELED_ONLY", "executed_at": "2026-10-30T00:00:00Z"}
    store.save(record)
    with store._index() as db:
        db.execute("UPDATE runs SET evidence_state='UNASSESSED'")
        if tamper == "index_digest":
            db.execute("UPDATE runs SET digest=?", ("0" * 64,))
        original_row = db.execute("SELECT * FROM runs").fetchone()
    path = store._path(record["run_id"])
    if tamper == "record":
        path.write_text(json.dumps({**record, "changed_after_indexing": True}), encoding="utf-8")
    original_bytes = path.read_bytes()

    try:
        history = ProtocolRunStore(store.directory).history()
    except ValueError as error:
        assert "digest" in str(error)
    else:
        assert history["runs"][0]["evidence_state"] == "UNASSESSED"
    assert path.read_bytes() == original_bytes
    with store._index() as db:
        assert db.execute("SELECT * FROM runs").fetchone() == original_row


def test_index_connections_are_explicitly_closed(tmp_path):
    import sqlite3
    store = ProtocolRunStore(tmp_path / "runs")
    with store._index() as connection:
        assert connection.execute("SELECT 1").fetchone() == (1,)
    with pytest.raises(sqlite3.ProgrammingError, match="closed"):
        connection.execute("SELECT 1")


@pytest.mark.parametrize("batch", range(5))
def test_concurrent_saves_preserve_index_history_and_digests(tmp_path, result, batch):
    directory = tmp_path / f"concurrent-runs-{batch}"
    records = [{**result, "run_id": "protocol-" + uuid.uuid4().hex} for _ in range(24)]

    def save(record):
        # Separate instances match independently handled requests sharing one store.
        return ProtocolRunStore(directory).save(record)

    with ThreadPoolExecutor(max_workers=8) as executor:
        assert list(executor.map(save, records)) == records
    store = ProtocolRunStore(directory)
    assert store.latest() in records
    history = store.history(limit=50)
    assert {row["run_id"] for row in history["runs"]} == {row["run_id"] for row in records}
    assert history["pagination"]["total"] == 24
    assert [store.get(record["run_id"]) for record in records] == records


@pytest.mark.parametrize("suffix", ["", "-journal", "-wal", "-shm"])
@pytest.mark.parametrize("unsafe_kind", ["symlink", "hardlink", "foreign_owner", "directory"])
def test_index_rejects_unsafe_database_and_sidecars(tmp_path, monkeypatch, suffix, unsafe_kind):
    store = ProtocolRunStore(tmp_path / "runs")
    candidate = store.directory / (".index.sqlite3" + suffix)
    if unsafe_kind == "symlink":
        candidate.symlink_to(tmp_path / "missing-target")
    elif unsafe_kind == "hardlink":
        target = tmp_path / "linked-target"
        target.touch(mode=0o600)
        candidate.hardlink_to(target)
    elif unsafe_kind == "directory":
        candidate.mkdir()
    else:
        candidate.touch(mode=0o600)
        owner = os.getuid()
        monkeypatch.setattr(os, "getuid", lambda: owner + 1)
    with pytest.raises(ValueError, match="protocol index storage is unsafe"):
        with store._index():
            pytest.fail("unsafe storage reached SQLite")


@pytest.mark.parametrize("suffix", ["", "-journal", "-wal", "-shm"])
def test_unlinked_metadata_is_allowed_only_for_transient_sidecars(tmp_path, monkeypatch, suffix):
    from types import SimpleNamespace

    store = ProtocolRunStore(tmp_path / "runs")
    candidate = store.directory / (".index.sqlite3" + suffix)
    candidate.touch(mode=0o600)
    original_lstat = Path.lstat
    inspected = False

    def disappear_during_inspection(path):
        nonlocal inspected
        info = original_lstat(path)
        if path == candidate and not inspected:
            inspected = True
            candidate.unlink()
            # APFS can return the owned inode's metadata after its final unlink.
            return SimpleNamespace(st_mode=info.st_mode, st_uid=info.st_uid, st_nlink=0)
        return info

    monkeypatch.setattr(Path, "lstat", disappear_during_inspection)
    if not suffix:
        with pytest.raises(ValueError, match="protocol index storage is unsafe"):
            with store._index():
                pytest.fail("a removed database must not be silently recreated")
    else:
        with store._index() as connection:
            assert connection.execute("SELECT 1").fetchone() == (1,)
    assert inspected
