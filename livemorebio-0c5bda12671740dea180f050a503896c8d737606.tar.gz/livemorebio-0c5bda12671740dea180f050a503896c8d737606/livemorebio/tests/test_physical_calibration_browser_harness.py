"""Offline authored evidence and workflow doubles, never a browser or service."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import struct

import pytest

from tools import check_legacy_preview_browser as supervisor
from ._node import NODE, run_node as _run_node


SCRIPT = Path(supervisor.BROWSER_SCRIPT)
CHECKS = ["desktop-open", "desktop-blank", "desktop-due", "desktop-current", "desktop-reopen",
          "mobile-open", "mobile-blank", "mobile-failed", "mobile-reopen"]


def snapshot(name):
    mobile = name.startswith("mobile")
    stage = name.split("-")[1]
    opened = stage in ("open", "reopen")
    rejected = stage in ("due", "failed")
    return dict(viewport=dict(width=390 if mobile else 1280, height=844 if mobile else 900),
                scroll=dict(x=0, y=200), dialog=dict(x=10, y=10, width=370 if mobile else 700, height=800),
                clip=dict(x=12, y=12, width=366 if mobile else 696, height=796),
                box=dict(x=30, y=200, width=300, height=100), calibration_box=dict(x=30, y=150, width=300, height=40),
                open=True, required=True, associated=True, legacy=True, copy=True,
                fields_empty=opened, feedback_matches=True, value="" if opened or stage == "blank" else stage,
                value_missing=opened or stage == "blank", focus="physical-device-id" if opened else "physical-calibration",
                invalid_count=0 if stage == "open" else 1,
                submit_count=0 if stage in ("open", "blank") else 1,
                return_focus=True if stage == "reopen" else None,
                horizontal_overflow=False, dialog_overflow=False, hit=True, calibration_hit=rejected)


def rows():
    return [dict(id=name, snapshot=snapshot(name)) for name in CHECKS]


def node(code):
    preamble = "const assert=require('node:assert/strict');const h=require(" + json.dumps(str(SCRIPT)) + ");\n"
    result = _run_node([NODE, "--eval", preamble + code],
                            capture_output=True, text=True, timeout=12, encoding="utf-8")
    assert result.returncode == 0, result.stderr


@pytest.mark.parametrize("target", ["/twins", "/api/session/bootstrap", "/api/build", "/api/services",
                                      "/api/state", "/api/twins?limit=10", "/api/population-capabilities",
                                      "/lib/subjects.js", "/lib/selection_reconciliation.js"])
def test_fixed_physical_gets_only(target):
    node(f"assert.equal(h.classifyRequest('http://127.0.0.1:8910'+{json.dumps(target)},'GET','physical-calibration').kind,'ACTUAL');")


@pytest.mark.parametrize("url,method", [("/api/stimulate", "POST"), ("/api/twins/x/patches", "POST"),
                                        ("/api/stimulate", "GET"), ("/legacy", "GET"), ("/api/genome-models", "GET"),
                                        ("/api/twins?limit=50", "GET"), ("/api/twins?limit=10&extra=1", "GET"),
                                        ("/lib/anatomy_loader.js", "GET"), ("https://example.invalid/twins", "GET")])
def test_no_mutation_ancillary_page_or_unknown_origin(url, method):
    absolute = url if url.startswith("https:") else "http://127.0.0.1:8910" + url
    node(f"assert.equal(typeof h.requirePhysicalRows,'function');assert.throws(()=>h.classifyRequest({json.dumps(absolute)},{json.dumps(method)},'physical-calibration'),/UNEXPECTED_REQUEST/);")


def test_complete_physical_rows_match_both_admitters():
    node("h.requirePhysicalRows(" + json.dumps(rows()) + ");")
    supervisor._admit_physical_checks(rows())


@pytest.mark.parametrize("mutation", ["missing", "duplicate", "native-invalid", "native-submit", "focus",
                                      "current", "reopen", "feedback", "association", "clip", "overlap",
                                      "offscreen", "nonfinite", "bool-geometry", "mobile-width", "overflow"])
def test_contradictory_or_incomplete_physical_rows_rejected(mutation):
    value = rows()
    s = value[2]["snapshot"]
    if mutation == "missing": value.pop()
    elif mutation == "duplicate": value[8] = copy.deepcopy(value[7])
    elif mutation == "native-invalid": value[1]["snapshot"]["invalid_count"] = 0
    elif mutation == "native-submit": value[1]["snapshot"]["submit_count"] = 1
    elif mutation == "focus": s["focus"] = "physical-device-id"
    elif mutation == "current": value[3]["snapshot"]["value"] = "due"
    elif mutation == "reopen": value[4]["snapshot"]["return_focus"] = False
    elif mutation == "feedback": s["feedback_matches"] = False
    elif mutation == "association": s["associated"] = False
    elif mutation == "clip": s["clip"]["height"] = 150
    elif mutation == "overlap": s["calibration_box"]["y"] = 220
    elif mutation == "offscreen": s["box"]["y"] = -10
    elif mutation == "nonfinite": s["box"]["height"] = None
    elif mutation == "bool-geometry": s["box"]["x"] = True
    elif mutation == "mobile-width": value[7]["snapshot"]["viewport"]["width"] = 400
    elif mutation == "overflow": s["dialog_overflow"] = True
    node("h.requirePhysicalRows(" + json.dumps(rows()) + ");assert.throws(()=>h.requirePhysicalRows(" + json.dumps(value) + "),/PHYSICAL_CALIBRATION_FAILED/);")
    with pytest.raises(ValueError): supervisor._admit_physical_checks(value)


def test_original_default_schedule_and_images_unchanged():
    node("assert.equal(h.classifyRequest('http://127.0.0.1:8910/api/stimulate','POST').kind,'POST');assert.equal(h.IMAGES.length,16);assert.equal(h.POST_LIMIT,4);assert.equal(h.newReceipt().schema,'livemore.legacy-preview-browser-result.v1');")
    assert supervisor.LIMITS["posts"] == 4 and supervisor.LIMITS["images"] == 16
    assert len(supervisor.CASES) == 7


def test_actual_fixed_workflow_uses_supported_selection_and_never_submits_current():
    node(r"""let done=false;process.on('beforeExit',()=>{if(!done)process.exitCode=1});
(async()=>{let context=0,value='',submits=[],captures=[],seen=[],choices=[],closed=false;
const op={attach:async(w,h)=>{context++;assert.deepEqual([w,h],context===1?[1280,900]:[390,844])},
 open:async()=>{value='';closed=false},fill:async()=>{},focus:async()=>{},
 openChoice:async()=>{},
 key:async key=>{if(key==='Enter'){submits.push([context,value]);throw Error('ENTER_SUBMITTED')}
  assert(['c','d','f'].includes(key));value={c:'current',d:'due',f:'failed'}[key]},
 select:async expected=>{assert(['current','due','failed'].includes(expected));value=expected;return[value]},
 expectValue:async(expected,returned)=>{assert.equal(value,expected);assert.deepEqual(returned,[expected]);choices.push([context,value])},
 submit:async()=>{assert.notEqual(value,'current');submits.push([context,value])},
 observe:async name=>{seen.push(name)},image:async name=>captures.push(name),
 escape:async()=>{closed=true;return true},verify:async()=>{},detach:async()=>{assert(closed)},pass:()=>{}};
await h.physicalCalibrationFlow(op);assert.deepEqual(submits,[[1,''],[1,'due'],[2,''],[2,'failed']]);
assert.deepEqual(captures,['physical-desktop-open','physical-desktop-rejected','physical-mobile-open','physical-mobile-rejected']);
assert.deepEqual(seen,['desktop-open','desktop-blank','desktop-due','desktop-current','desktop-reopen','mobile-open','mobile-blank','mobile-failed','mobile-reopen']);
assert.deepEqual(choices,[[1,'current'],[1,'due'],[1,'current'],[2,'current'],[2,'due'],[2,'failed']]);done=true;
})().catch(e=>{done=true;console.error(e);process.exitCode=1});""")


@pytest.mark.parametrize("damage", [None, "feedback", "focus", "modal", "required", "occluded"])
def test_serialized_observer_reads_actual_dom_and_sync_events_without_raw_text(damage):
    code = r"""
const vm=require('node:vm'),listeners=new Map(),counts=[];
const rect=(x,y,width,height)=>({x,y,width,height});
const dialog={open:true,clientLeft:2,clientTop:2,clientWidth:696,clientHeight:796,scrollWidth:696,
 matches:s=>s===':modal',getBoundingClientRect:()=>rect(10,10,700,800)};
const feedback={textContent:'Physical pairing requires an explicit declaration of current calibration. Due or failed calibration cannot be paired.',
 getAttribute:n=>n==='role'?'status':null,contains:()=>false,getBoundingClientRect:()=>rect(30,200,300,100)};
const cal={id:'physical-calibration',value:'due',required:true,validity:{valueMissing:false},contains:()=>false,
 getAttribute:n=>n==='aria-describedby'?'physical-calibration-feedback':null,getBoundingClientRect:()=>rect(30,150,300,40)};
const help={textContent:'legacy protocol-v2 pairing only Complete registered-lineage physical-v3 onboarding is not available in this form operator declaration, not a verified calibration certificate does not prove a live sensor connection not a human-use release',getBoundingClientRect:()=>rect(30,50,300,100)};
const fields={'#physical-calibration':cal,'#physical-calibration-feedback':feedback,'.source-help':help,
 '#physical-protocol-version':{value:'2.0',readOnly:true},'#physical-hardware-revision':{value:'B0-EVT-target',readOnly:true}};
for(const name of ['device-id','firmware-version','attestation'])fields['#physical-'+name]={value:'PRIVATE_SENTINEL'};
const form={closest:()=>dialog,querySelector:s=>fields[s],contains:n=>n===feedback,
 addEventListener:(k,f,capture)=>{assert.equal(capture,true);listeners.set(k,f)},
 removeEventListener:(k,f,capture)=>{assert.equal(capture,true);assert.equal(listeners.get(k),f);listeners.delete(k)}};
const document={querySelector:s=>{assert.equal(s,'#physical-patch-form');return form},activeElement:cal,
 documentElement:{scrollWidth:1280},elementFromPoint:(x,y)=>y<200?cal:feedback};
const ctx={document,innerWidth:1280,innerHeight:900,scrollX:0,scrollY:0};vm.createContext(ctx);
const observer=vm.runInContext('('+h.createPhysicalObserver.toString()+')()',ctx);assert.equal(listeners.size,2);
listeners.get('invalid')();listeners.get('submit')();assert.equal(observer.counts.invalid,1);assert.equal(observer.counts.submit,1);
const damage=DAMAGE;
if(damage==='feedback')feedback.textContent='PRIVATE_SENTINEL';if(damage==='focus')document.activeElement={id:'PRIVATE_SENTINEL'};
if(damage==='modal')dialog.open=false;if(damage==='required')cal.required=false;if(damage==='occluded')document.elementFromPoint=()=>dialog;
ctx.observer=observer;const result=vm.runInContext('('+h.readPhysicalSnapshot.toString()+')(observer,{id:"desktop-due"})',ctx);
assert(!JSON.stringify(result).includes('PRIVATE_SENTINEL'));
const choice=vm.runInContext('('+h.readPhysicalChoice.toString()+')(observer)',ctx);
assert.deepEqual(JSON.parse(JSON.stringify(choice)),{value:'due',focus:damage==='focus'?'OTHER':'physical-calibration',invalid_count:1,submit_count:1});
cal.value='PRIVATE_SENTINEL';assert.equal(vm.runInContext('('+h.readPhysicalChoice.toString()+')(observer)',ctx).value,'OTHER');cal.value='due';
if(damage)assert.throws(()=>h.requirePhysicalSnapshot(result,'desktop-due'),/PHYSICAL_CALIBRATION_FAILED/);else h.requirePhysicalSnapshot(result,'desktop-due');
observer.dispose();assert.equal(listeners.size,0);
""".replace("DAMAGE", json.dumps(damage))
    node(code)


def physical_receipt(tmp_path):
    value = dict(schema='livemore.physical-calibration-browser-result.v1', source='a' * 64,
                 pins={'test': 'b' * 64}, services={'test': 'technical'}, delivery='PASS', primary_failure=None,
                 visible_ui='REQUIRES_INDEPENDENT_REVIEW', biological_evidence=False, posts=0, actual_mutations=0,
                 completed=['D0', 'D1', 'M0', 'M1'], physical_checks=rows(), actual_state_reads=4, auth_bootstraps=2,
                 cases=[dict(id=x, status='PASS', failure_code=None) for x in ['D0', 'D1', 'M0', 'M1']],
                 selected_values=[[1, 'current'], [1, 'due'], [1, 'current'], [2, 'current'], [2, 'due'], [2, 'failed']],
                 selection_method='PLAYWRIGHT_SELECT_OPTION', native_popup_keyboard='NOT_ACCEPTED',
                 context_checks=[dict(context=x, exact=True) for x in [1, 1, 2, 2]],
                 cookie_checks=[dict(context=x, http_only=True) for x in [1, 2]],
                 cleanup=[dict(name=x, status='SETTLED') for x in ['page-1', 'context-1', 'page-2', 'context-2', 'browser']],
                 requests=[dict(method='GET', category='/twins', delivery='ACTUAL')], images=[],
                 choice_checks=[dict(context=context, value=value, returned_value=value, focus='physical-calibration', invalid_count=1,
                                     submit_count=int(index == 2)) for index, (context, value) in enumerate(
                                         [(1, 'current'), (1, 'due'), (1, 'current'), (2, 'current'), (2, 'due'), (2, 'failed')])])
    for name, index in zip(supervisor.PHYSICAL_IMAGES, [0, 2, 5, 7]):
        s = value['physical_checks'][index]['snapshot']
        raw = b'\x89PNG\r\n\x1a\n' + b'\x00\x00\x00\x0dIHDR' + struct.pack('>II', s['viewport']['width'], s['viewport']['height'])
        file = tmp_path / (name + '.png'); file.write_bytes(raw); file.chmod(0o600)
        value['images'].append(dict(name=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                                   physical_id=value['physical_checks'][index]['id'], viewport=s['viewport'], scroll=s['scroll'],
                                   box=copy.deepcopy(s['box']), visible=True, unoccluded=True, horizontal_overflow=False))
    return value


@pytest.mark.parametrize('damage', [None, 'post', 'category', 'images', 'hash', 'geometry', 'missing',
                                   'cleanup', 'state', 'keyboard', 'cookie-type', 'image-bool', 'wrong-scenario'])
def test_parent_physical_admission_requires_original_images_and_exact_scope(tmp_path, damage):
    r = physical_receipt(tmp_path)
    if damage == 'post': r['posts'] = 1
    elif damage == 'category': r['requests'][0]['category'] = '/api/genome-models'
    elif damage == 'images': r['images'].pop()
    elif damage == 'hash': r['images'][0]['sha256'] = 'f' * 64
    elif damage == 'geometry': r['images'][0]['box']['y'] += 1
    elif damage == 'missing': (tmp_path / (supervisor.PHYSICAL_IMAGES[0] + '.png')).unlink()
    elif damage == 'cleanup': r['cleanup'][0]['status'] = 'UNCONFIRMED'
    elif damage == 'state': r['context_checks'][1]['exact'] = False
    elif damage == 'keyboard': r['selected_values'][0] = []
    elif damage == 'cookie-type': r['cookie_checks'][0]['context'] = True
    elif damage == 'image-bool':
        r['physical_checks'][0]['snapshot']['dialog']['x'] = 0
        r['physical_checks'][0]['snapshot']['clip']['x'] = 0
        r['physical_checks'][0]['snapshot']['box']['x'] = 1
        r['images'][0]['box']['x'] = True
    raw = json.dumps(r).encode(); file = tmp_path / 'browser-result.json'; file.write_bytes(raw); file.chmod(0o600)
    args = dict(source='a' * 64, pins={'test': 'b' * 64}, services={'test': 'technical'}, exit_code=0,
                scenario='legacy-preview' if damage == 'wrong-scenario' else 'physical-calibration')
    if damage:
        with pytest.raises(supervisor.HarnessError): supervisor.admit_browser_result(tmp_path, **args)
    else:
        assert supervisor.admit_browser_result(tmp_path, **args)['images_verified'] == 4
        node('h.checkPhysicalComplete(' + json.dumps(r) + ');')


@pytest.mark.parametrize('mode', ['pass', 'post', 'source', 'native', 'cleanup', 'choice-uncommitted', 'choice-submit', 'choice-focus',
                                  'choice-return-missing', 'choice-return-private', 'choice-return-many'])
def test_actual_runner_physical_dispatch_source_post_and_cleanup_guards(mode):
    script = r"""
let complete=false;process.on('beforeExit',()=>{if(!complete)process.exitCode=1});
(async()=>{
const Module=require('node:module'),fs=require('node:fs'),originalLoad=Module._load,originalWrite=fs.writeFileSync;
const mode=MODE,shapes=SHAPES,writes=new Map(),continued=[],aborted=[],api=[];
const config={scenario:'physical-calibration',out:'/not-written',source:'a'.repeat(64),pins:{},services:{},fixture:{twin_id:'twin-'+'a'.repeat(32),version:2}};
for(const name of ['Aegle','LIFE','Cendos'])config.services[name]={schema:'technical',source_sha256:config.source,process_instance:name,started_at:'technical'};
let number=0;
const browser={isConnected:()=>true,close:async()=>{},newContext:async({viewport})=>{
 const contextNumber=++number,events={},p={value:'',focus:'opener',open:false,empty:true,feedback:false,invalid:0,submit:0,closed:false};let route;
 const context={browser:()=>browser,close:async()=>{},cookies:async()=>[{httpOnly:true,domain:'127.0.0.1'}],route:async(pattern,fn)=>{assert.equal(pattern,'**/*');route=fn},request:{get:async(url,options)=>{
  assert.equal(options.maxRedirects,0);assert.equal(options.timeout,10000);api.push(url);
  const u=new URL(url);let body;
  if(u.pathname==='/health'){const name=['Aegle','LIFE','Cendos'][Number(u.port)-8910];body={ok:true,service:name,build:config.services[name]}}
  else if(u.pathname==='/api/state'){body=h.modelessState();body.model_availability.twin_id=mode==='source'?'wrong':config.fixture.twin_id;body.model_availability.twin_version=2}
  else{assert.equal(u.pathname+u.search,'/api/twins?limit=10');const active={twin_id:config.fixture.twin_id,version:2,source_class:'REAL_HUMAN',lifecycle:'ACTIVE',display_label:'AUTHORED UI ONLY — not a participant',patch_bindings:[]};body={selection_status:'CONFIRMED',active,twins:[active]}}
  return{status:()=>200,body:async()=>Buffer.from(JSON.stringify(body))};
 }}};
 const locator=selector=>({first(){return this},waitFor:async()=>{},focus:async()=>{p.focus='physical-calibration'},
  fill:async()=>{p.empty=false},inputValue:async()=>p.value,
  click:async()=>{if(selector.startsWith('[data-physical')){p.open=true;p.value='';p.empty=true;p.feedback=false;p.focus='physical-device-id'}
   else if(selector==='#physical-calibration'){p.focus='physical-calibration'}
   else{assert.equal(selector,'#physical-patch-form button[type="submit"]');p.focus='physical-calibration';if(p.value===''){if(mode!=='native')p.invalid++}else{p.submit++;p.feedback=true}}},
  selectOption:async(values,options)=>{assert.equal(selector,'#physical-calibration');assert.deepEqual(Object.keys(values),['value']);
   assert(['current','due','failed'].includes(values.value));assert.deepEqual(options,{timeout:10000});
   if(mode!=='choice-uncommitted')p.value=values.value;
   if(mode==='choice-submit')p.submit++;if(mode==='choice-focus')p.focus='opener';
   if(mode==='choice-return-missing')return[];if(mode==='choice-return-private')return['PRIVATE_SENTINEL'];if(mode==='choice-return-many')return[values.value,values.value];
   return[values.value]},
  evaluate:async fn=>{const source=fn.toString();if(source.includes('scrollIntoView'))return;if(source.includes('!el.open'))return!p.open;
   assert(source.includes('document.activeElement'));return p.focus==='opener'} });
 const page={isClosed:()=>p.closed,context:()=>context,viewportSize:()=>viewport,setDefaultTimeout(){},setDefaultNavigationTimeout(){},
  exposeBinding:async()=>{},addInitScript:async()=>{},on:(name,fn)=>events[name]=fn,locator,
  close:async()=>{if(mode==='cleanup')throw Error('PRIVATE');p.closed=true},
  keyboard:{press:async key=>{if(key==='Escape'){p.open=false;p.focus='opener';return}
   if(key==='Enter'){p.submit++;const request={url:()=> 'http://127.0.0.1:8910/api/twins/x/patches',method:()=> 'POST'};
    await route({request:()=>request,continue:async()=>continued.push('POST'),abort:async()=>aborted.push('/api/twins/x/patches')});return}
   assert(['c','d','f'].includes(key));p.value={c:'current',d:'due',f:'failed'}[key]}},
  evaluateHandle:async fn=>{assert.equal(fn,h.createPhysicalObserver);return{
    evaluate:async(fn,arg)=>{if(fn===h.readPhysicalChoice)return{value:p.value,focus:p.focus==='physical-calibration'?p.focus:'OTHER',invalid_count:p.invalid,submit_count:p.submit};
     if(fn!==h.readPhysicalSnapshot)return;
     const s=JSON.parse(JSON.stringify(shapes.find(x=>x.id===arg.id).snapshot));
     Object.assign(s,{value:p.value,fields_empty:p.empty,focus:p.focus,invalid_count:p.invalid,submit_count:p.submit,
       value_missing:p.value==='',open:p.open,feedback_matches:p.feedback===['due','failed','current'].includes(arg.id.split('-')[1]),return_focus:arg.returnFocus});return s},dispose:async()=>{}}},
  screenshot:async()=>{const b=Buffer.alloc(24);Buffer.from([137,80,78,71,13,10,26,10]).copy(b);b.write('IHDR',12);b.writeUInt32BE(viewport.width,16);b.writeUInt32BE(viewport.height,20);return b},
  goto:async url=>{assert.equal(url,'http://127.0.0.1:8910/twins');for(const pathname of ['/twins','/api/session/bootstrap',...(mode==='post'?['/api/twins/x/patches']:[])]){
   const request={url:()=> 'http://127.0.0.1:8910'+pathname,method:()=>pathname.endsWith('/patches')?'POST':'GET'};
   await route({request:()=>request,continue:async()=>{continued.push(request.method());events.response?.({request:()=>request,url:request.url,status:()=>pathname==='/api/session/bootstrap'?204:200})},abort:async()=>aborted.push(pathname)});
  }} };
 context.newPage=async()=>page;return context;
}};
Module._load=function(name,...args){if(name===(process.env.LIVEMORE_PLAYWRIGHT_MODULE||'/nonexistent/livemore/playwright/index.js'))return{chromium:{launch:async()=>browser}};return originalLoad.call(this,name,...args)};
fs.writeFileSync=(file,data)=>{assert(String(file).startsWith('/not-written/'));writes.set(String(file),Buffer.from(data))};
try{const code=await h.run(config),r=JSON.parse(writes.get('/not-written/browser-result.json'));assert.equal(code,mode==='pass'?0:1);
 assert(continued.every(x=>x==='GET'));assert.equal(r.actual_mutations,0);
 if(mode==='pass'){assert.equal(r.images.length,4);assert.deepEqual(r.completed,['D0','D1','M0','M1']);assert.equal(r.posts,0);assert.equal(r.actual_state_reads,4);assert.equal(api.filter(x=>x.endsWith('/api/state')).length,4);
  assert.equal(r.selection_method,'PLAYWRIGHT_SELECT_OPTION');assert.equal(r.native_popup_keyboard,'NOT_ACCEPTED');assert(!Object.hasOwn(r,'keyboard_choices'))}
 if(mode==='post'){assert.equal(r.posts,1);assert(aborted.includes('/api/twins/x/patches'));assert.equal(r.primary_failure,'UNEXPECTED_REQUEST');assert.equal(r.images.length,0)}
 if(mode==='source'){assert.equal(r.primary_failure,'ACTUAL_MODELESS_REQUIRED');assert.equal(r.images.length,0);assert.equal(r.context_checks[0].exact,false)}
 if(mode==='native'){assert.equal(r.primary_failure,'PHYSICAL_CALIBRATION_FAILED');assert.equal(r.images.length,1);assert.equal(r.physical_checks[1].snapshot.invalid_count,0)}
 if(mode==='cleanup'){assert(r.cleanup.some(x=>x.status==='UNCONFIRMED'));assert.equal(r.primary_failure,'CLEANUP_UNCONFIRMED')}
 if(mode.startsWith('choice-')){assert.equal(r.primary_failure,'PHYSICAL_CALIBRATION_FAILED');assert.equal(r.images.length,1);assert.equal(r.posts,0);
  assert.equal(r.choice_checks.length,1);const choice=r.choice_checks[0];
  if(mode==='choice-uncommitted')assert.equal(choice.value,'');if(mode==='choice-submit')assert.equal(choice.submit_count,1);if(mode==='choice-focus')assert.equal(choice.focus,'OTHER');
  if(mode.startsWith('choice-return-'))assert.equal(choice.returned_value,'OTHER');assert(!JSON.stringify(r).includes('PRIVATE_SENTINEL'))}
}finally{Module._load=originalLoad;fs.writeFileSync=originalWrite}
complete=true;
})().catch(e=>{complete=true;console.error(e);process.exitCode=1});
""".replace('const mode=MODE,', 'const mode=' + json.dumps(mode) + ',').replace('SHAPES', json.dumps(rows()))
    node(script)


@pytest.mark.parametrize('scenario', [None, False, 'physical', []])
def test_invalid_direct_scenario_cannot_load_browser(scenario):
    node("let complete=false;process.on('beforeExit',()=>{if(!complete)process.exitCode=1});assert.rejects(h.run({scenario:" + json.dumps(scenario) + "}),/CONFIG_IDENTITY/).then(()=>{assert(!Object.keys(require.cache).some(x=>x.includes('/playwright/')));complete=true},e=>{complete=true;console.error(e);process.exitCode=1});")


@pytest.mark.parametrize('damage', [None, 'empty', 'wrong', 'focus', 'invalid', 'submit', 'missing', 'duplicate',
                                   'returned', 'method', 'method-missing', 'native-claim', 'old-keyboard-field'])
def test_semantic_choice_receipts_require_values_method_focus_and_unchanged_counts(tmp_path, damage):
    value = physical_receipt(tmp_path)
    if damage == 'empty': value['choice_checks'][0]['value'] = ''
    elif damage == 'wrong': value['choice_checks'][0]['value'] = 'due'
    elif damage == 'focus': value['choice_checks'][0]['focus'] = 'OTHER'
    elif damage == 'invalid': value['choice_checks'][0]['invalid_count'] = 2
    elif damage == 'submit': value['choice_checks'][0]['submit_count'] = 1
    elif damage == 'missing': value.pop('choice_checks')
    elif damage == 'duplicate': value['choice_checks'][1] = copy.deepcopy(value['choice_checks'][0])
    elif damage == 'returned': value['choice_checks'][0]['returned_value'] = 'due'
    elif damage == 'method': value['selection_method'] = 'NATIVE_KEYBOARD'
    elif damage == 'method-missing': value.pop('selection_method')
    elif damage == 'native-claim': value['native_popup_keyboard'] = 'PASS'
    elif damage == 'old-keyboard-field': value['keyboard_choices'] = value.pop('selected_values')
    path = tmp_path / 'browser-result.json'; path.write_text(json.dumps(value), encoding="utf-8"); path.chmod(0o600)
    args = dict(source='a' * 64, pins={'test': 'b' * 64}, services={'test': 'technical'}, exit_code=0, scenario='physical-calibration')
    if damage:
        node('assert.throws(()=>h.checkPhysicalComplete(' + json.dumps(value) + '),/CHECK_INCOMPLETE/);')
        with pytest.raises(supervisor.HarnessError): supervisor.admit_browser_result(tmp_path, **args)
    else:
        node('h.checkPhysicalComplete(' + json.dumps(value) + ');')
        assert supervisor.admit_browser_result(tmp_path, **args)['images_verified'] == 4
