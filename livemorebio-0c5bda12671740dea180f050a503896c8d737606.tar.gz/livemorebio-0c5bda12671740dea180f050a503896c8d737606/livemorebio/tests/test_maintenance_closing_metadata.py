"""Closing-round labels and provenance; all inputs are technical fixtures."""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[2]


def test_status_reports_associated_genes(monkeypatch, capsys):
    from livemorebio import cli
    from livemorebio.life_system.reference.knowledgebase import KnowledgeBase
    kb = KnowledgeBase()
    monkeypatch.setattr(cli, "_health", lambda port: {"diseases": len(kb.diseases), "variants": len(kb.variants)})
    monkeypatch.setattr(cli.R, "registry", lambda: {})
    cli.status()
    output = capsys.readouterr().out
    assert "20 diseases · 309 associated genes" in output
    assert "risk loci" not in output


@pytest.mark.parametrize("relative", ["docs/BUSINESS_CLIENT_GUIDE.md", "dist-public/README.md", "dist-public/INSTALL.md"])
def test_documented_status_matches_the_current_label_and_count(relative):
    from ._source_tree import require_source_tree
    require_source_tree(relative)
    path = ROOT / relative
    if relative.startswith("dist-public/"):
        from .private_reference_helpers import require_private_reference_data
        require_private_reference_data(path)
    assert "20 diseases · 309 associated genes" in path.read_text(encoding="utf-8")
    assert "172 risk loci" not in path.read_text(encoding="utf-8")


def test_vocab_reports_existing_engine_key_collisions_without_changing_effects():
    from livemorebio.aegle import server
    from livemorebio.life_system.genome import VARIANTS, effect_of
    data = json.loads(server.api_vocab().body)
    collisions = set(data["variants"]) & VARIANTS.keys()
    assert collisions == {"TCF7L2"}
    assert {g for g, meta in data["variant_meta"].items() if meta["executable"]} == collisions
    assert data["variant_meta"]["TCF7L2"]["evidence_type"] == "association"
    assert effect_of({"TCF7L2": 1}, "insulin_secretion") == -0.12
    assert effect_of({}, "insulin_secretion") == 0


@pytest.mark.parametrize("name,identifier", [("X:MAP", "nar:1150"), ("PepCyber:P~Pep", "nar:1111"), ("MP:PD", "nar:1682")])
def test_catalogue_preserves_colons_inside_resource_names(name, identifier):
    from tools.refresh_scientific_source_catalog import _public_name
    assert _public_name(name + ": a technical subtitle", identifier) == name
    records = json.loads((ROOT / "livemorebio/scientific_sources/data/source-catalog.v1.json").read_text(encoding="utf-8"))["sources"]
    assert next(row["name"] for row in records if row["source_id"] == identifier) == name


def test_atlas_harness_uses_configured_anatomy_directory(monkeypatch, tmp_path):
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "anatomy"))
    spec = importlib.util.spec_from_file_location("closing_atlas_harness", ROOT / "tools/check_atlas_presentation.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert module.ANATOMY == tmp_path / "anatomy"
    _, env = module.prepare_owned_environment(tmp_path)
    assert env["LIVEMORE_ANATOMY_DIR"] == str(tmp_path / "anatomy")


def test_absent_explicit_plant_path_does_not_claim_public_omission(tmp_path):
    from livemorebio.discovery.substrate import load_substrate
    from livemorebio.reference_errors import ReferenceDataNotDistributed
    with pytest.raises(ReferenceDataNotDistributed) as error:
        load_substrate(tmp_path / "missing-technical-file.json")
    assert "missing" in str(error.value).lower()
    assert "public archive" not in str(error.value)
    assert error.value.code == "REFERENCE_DATA_NOT_DISTRIBUTED"


@pytest.mark.parametrize("axis", ["banana", "oncologic"])
def test_absent_score_axis_explains_no_panel_exists(axis):
    from livemorebio.life_system.reference.prs import PRSInputError, axis_score
    with pytest.raises(PRSInputError, match="no reference panel exists") as error:
        axis_score({}, axis)
    assert error.value.reason_code == "PRS_AXIS_NOT_DISTRIBUTED"


def test_seed_explains_retained_identity_only_genes():
    from livemorebio.life_system.reference.knowledgebase import KnowledgeBase
    kb = KnowledgeBase()
    associated = {g for disease in kb.diseases for g in disease["genes"]}
    unassociated = sorted(set(kb.genes) - associated)
    assert len(unassociated) == 102
    record = kb.meta["retained_gene_identities"]
    assert record["symbols_without_current_association"] == unassociated
    assert record["association_release"] == "26.09"
    assert record["executable"] is False


def test_seed_refresh_and_score_lineage_are_disclosed():
    from livemorebio.life_system.reference import build_seed, gwas_traits
    assert "existing seed" in build_seed.__doc__
    assert "KEGG" in gwas_traits.__doc__
    assert "published" in gwas_traits.__doc__


@pytest.mark.parametrize("phrase,key,profile", [
    ("familial hypercholesterolemia", "hypercholesterolemia", {"ldl": 100, "hdl": 55}),
    ("chronic obstructive pulmonary disease", "chronic obstructive pulmonary", {"smoking_pack_years": 0, "inflammation": 0.2}),
])
def test_describe_shortened_keys_remain_explicit_refusals(phrase, key, profile):
    from livemorebio.clinical_note_gate import ClinicalNoteRefused
    from livemorebio.life_system.reference.human_builder import HumanBuilder, HumanSpec, describe
    # L0-R15 round 1: describe() is free-text intake about a person and is refused; the
    # shortened legacy key it produced still refuses explicitly through an explicit spec.
    with pytest.raises(ClinicalNoteRefused):
        describe("a 44 year old man with " + phrase)
    human = HumanBuilder().build(HumanSpec(age=44, sex="M", conditions=[key]))
    assert any(row["reason_code"] == "REFERENCE_DISEASE_UNRESOLVED" and row["query"] == key
               for row in human.reference["unresolved_conditions"])
    for name, value in profile.items():
        assert human.profile[name] == value
