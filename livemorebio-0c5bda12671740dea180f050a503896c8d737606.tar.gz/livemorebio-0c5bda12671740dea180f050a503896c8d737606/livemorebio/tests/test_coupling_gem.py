"""Multi-scale coupling: genome-scale metabolic capacities parameterize the Bergman ODE."""
import pytest
from livemorebio.engines import metabolism as MB
from livemorebio.engines.coupling import gem_metabolic as GC
from livemorebio.engines.metabolic.glucose_insulin import T2D

def test_genome_personalizes_insulin_sensitivity():
    with pytest.raises(ValueError, match="qualified"):
        GC.personalize_profile(T2D, genome={"NDUFS1_lof": 2})


def test_gem_drug_effect_lowers_hepatic_glucose():
    with pytest.raises(ValueError, match="qualified"):
        GC.gem_drug_effect(T2D, genome={}, drug_perturbations={"PCK1": 0.0, "PCK2": 0.0})
