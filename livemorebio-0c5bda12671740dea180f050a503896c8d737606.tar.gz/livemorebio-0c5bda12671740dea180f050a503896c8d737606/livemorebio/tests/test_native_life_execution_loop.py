"""Real native worker + both ASGI services; no socket/browser/physical claim."""
import base64
from copy import deepcopy

from fastapi.testclient import TestClient

from livemorebio.tests.test_execution_api import product, prepare, control, HEADERS, TOKEN


def test_native_frame_goes_through_life_gateway_and_back_to_matching_aegle(product, tmp_path, monkeypatch):
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle import server
    from livemorebio.build_info import build_identity
    from livemorebio.life_patch.execution_source import ExecutionSourceClient
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.virtual_execution import VirtualSessionManager
    from livemorebio.life_patch.virtual_session_store import VirtualSessionStore
    from livemorebio.life_system import service, virtual_execution_api
    from livemorebio.life_system.execution_delivery import forward_execution_receipt

    product.manager.close()
    product.manager = ExecutionManager(product.manager.store, run_background=False)
    product.authority._invalidate = product.manager.invalidate_source
    monkeypatch.setattr(product.api, "_manager", lambda: product.manager)
    product.record["subject_id"] = "pseudonym-native-loop"
    product.record["patch_bindings"] = [{"device_id": "native-loop-probe", "mode": "virtual", "protocol_version": "3.0"}]
    server._state["subject"]["subject_id"] = product.record["subject_id"]
    product.twin.observations = {"glucose_mgdl": {"value": 104., "mode": "physical", "provenance": "calibrated"}}
    product.twin.patch = {"mode": "physical", "connected": True}
    product.twin.execution_observations = {}
    physical = deepcopy(product.twin.observations)
    monkeypatch.setenv("LIVEMORE_PATCH_STORAGE_KEY", base64.urlsafe_b64encode(b"n" * 32).decode())

    def transport(method, path, body):
        response = product.client.request(method, path, content=body, headers={"Authorization": "Bearer " + TOKEN})
        return response.status_code, dict(response.headers), response.content

    source = ExecutionSourceClient("http://127.0.0.1:1", TOKEN, build_identity()["source_sha256"],
                                   expected_role="aegle", transport=transport)
    gateway = LifePatchGateway(str(tmp_path / "patch" / "journal.jsonl"))
    owner = VirtualSessionManager(VirtualSessionStore(tmp_path / "life" / "sessions.sqlite3", key=b"n" * 32),
        gateway, source, lambda receipt: forward_execution_receipt(receipt, source), run_background=False)
    monkeypatch.setattr(virtual_execution_api, "_manager", lambda: owner)
    monkeypatch.setattr(virtual_execution_api, "_check_runtime_identity", lambda: None)
    life = TestClient(service.app)
    try:
        registered = life.post("/patch/virtual/probe", json={"device_id": "native-loop-probe"}, headers=HEADERS)
        assert registered.status_code == 200
        execution = prepare(product)
        bound = life.post("/patch/virtual/sessions", headers=HEADERS, json={
            "execution_id": execution["execution_id"], "source_snapshot_hash": execution["source_snapshot_hash"],
            "device_id": "native-loop-probe", "expected_selection": execution["selection"], "idempotency_key": "native-loop"})
        assert bound.status_code == 200, bound.text
        session = bound.json()
        assert session["last_forwarded"] == 0 and session["authorship"] == "NOT_EXECUTED"
        execution = product.manager.status(execution["execution_id"])
        assert control(product, execution, "start").status_code == 200
        for expected in [1, 2]:
            frame = product.manager.advance_once(execution["execution_id"])
            assert frame["frame_index"] == expected and frame["authorship"] == "engine"
            owner.tick(session["session_id"])
            session = life.get("/patch/virtual/sessions/" + session["session_id"], headers=HEADERS).json()
            assert session["last_frame"] == session["last_admitted"] == session["last_forwarded"] == expected, session
            assert session["state"] == "streaming" and session["delivery_status"] == "acknowledged"
            observations = product.client.get(f"/api/executions/{execution['execution_id']}/observations", headers=HEADERS).json()
            stream = observations["streams"][0]
            assert stream["frame_hash"] == frame["frame_hash"]
            value = next(row["values"][-1] for row in frame["series"] if row["quantity"] == "glucose_mgdl")
            assert stream["observations"]["glucose_mgdl"]["value"] == value
            assert gateway.next_sequence("native-loop-probe") == expected
            assert product.twin.observations == physical
        with product.authority.mutation("technical-subject-switch"):
            pass
        owner.tick(session["session_id"])
        blocked = life.get("/patch/virtual/sessions/" + session["session_id"], headers=HEADERS).json()
        assert blocked["state"] == "blocked" and blocked["last_forwarded"] == 2
        assert product.twin.observations == physical
        assert b"pseudonym-native-loop" not in gateway.journal_path.read_bytes()
    finally:
        owner.close()
        product.manager.close()
