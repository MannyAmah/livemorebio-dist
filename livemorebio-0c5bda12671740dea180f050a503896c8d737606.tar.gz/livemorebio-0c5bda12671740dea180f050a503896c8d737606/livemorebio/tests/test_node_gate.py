"""Node.js is not a prerequisite, so its absence must skip a test, never fail one.

The product does not need Node.js at run time and no install guide asks for it,
but the suite decides whether an install is activated and whether the container
image builds. The image's base has no Node.js. Once the image could collect its
suite at all, 348 tests in 13 modules still started Node.js with nothing asking
first whether there was one to start.

The toolchain resolver is the one authority on whether this host has Node.js,
and ``_node.require_node`` is the one gate. These tests hold the helper to
that, with Node.js removed at the resolver: taking ``node`` off PATH proves
nothing on a machine that also has it at one of the resolver's well-known
locations, which is how the same defect was missed twice before.
"""
from __future__ import annotations

import ast
import os
from pathlib import Path
import subprocess
import sys

import pytest

from livemorebio import _toolchain

from . import _node

REPOSITORY_ROOT = Path(__file__).resolve().parents[2]


def _no_node(monkeypatch) -> None:
    monkeypatch.setattr(_node, "node_executable", lambda: None)


def _refuse_every_process(monkeypatch) -> None:
    def started(*arguments, **_):
        raise AssertionError(f"a process was started without Node.js: {arguments!r}")
    monkeypatch.setattr(subprocess, "Popen", started)


def _require_node(monkeypatch, switch: str | None) -> None:
    if switch is None:
        monkeypatch.delenv(_node.REQUIRE_NODE_ENV, raising=False)
    else:
        monkeypatch.setenv(_node.REQUIRE_NODE_ENV, switch)


@pytest.mark.parametrize("switch", [None, "", "0"])
def test_a_host_without_node_skips_with_the_stated_reason(monkeypatch, switch):
    """What a client's install does where nothing has exported the switch: the
    installer does not set it, and hands on only what its caller did."""
    _no_node(monkeypatch)
    _refuse_every_process(monkeypatch)
    _require_node(monkeypatch, switch)

    with pytest.raises(pytest.skip.Exception, match="Node.js is not installed on this host"):
        _node.require_node()
    with pytest.raises(pytest.skip.Exception, match="Node.js is not installed on this host"):
        _node.run_node(["node", "--eval", "0"], capture_output=True)


def test_what_the_gate_reports_is_what_runs(monkeypatch, tmp_path):
    """One resolution is both the gate and the executor.

    The gate used to ask the resolver when it was called and then hand back a
    path worked out when the module was imported, so the two could name
    different executables.
    """
    stub = tmp_path / "node"
    stub.write_text("#!/bin/sh\nprintf 'resolved %s\\n' \"$*\"\n", encoding="utf-8")
    stub.chmod(0o755)
    monkeypatch.setenv(_toolchain.NODE_ENV, str(stub))

    assert _node.require_node() == str(stub)
    result = _node.run_node(["node", "--eval", "0"], capture_output=True, text=True, encoding="utf-8")
    assert result.stdout == "resolved --eval 0\n"


def test_node_is_never_an_executable_the_resolver_did_not_report(tmp_path):
    """``NODE`` used to fall back to the Homebrew path where the resolver found nothing.

    That handed every caller a second resolver: on the author's machine the
    path exists, so a test using it ran although the gate said there was no
    Node.js; anywhere else it named a file that is not there.
    """
    script = ("import sys; sys.path.insert(0, sys.argv[1]); "
              "from livemorebio.tests import _node; print(repr(_node.NODE))")
    interpreter = [sys.executable, "-X", "utf8", "-B", *(["-I"] if sys.flags.isolated else [])]
    env = dict(os.environ)
    env[_toolchain.NODE_ENV] = str(tmp_path / "not-an-executable")

    result = subprocess.run([*interpreter, "-c", script, str(REPOSITORY_ROOT)],
                            env=env, capture_output=True, text=True, check=False, encoding="utf-8")

    assert result.returncode == 0, result.stderr[-2000:]
    assert result.stdout.strip() == "None"


def test_no_test_asks_path_whether_there_is_node():
    """``shutil.which("node")`` is a different question from the one the gate asks.

    Eighteen tests decided with it whether to run, and then ran through
    ``run_node``, which takes its executable from the resolver. The two disagree
    in both directions: with Node.js at a well-known location but not on PATH
    the test skipped although it could have run, and with ``LIVEMORE_NODE`` set
    it ran an executable other than the one it had looked for. Each also gave a
    reason of its own, so one missing tool was reported in fifteen wordings.
    """
    asked = []
    for path in sorted(Path(__file__).parent.glob("*.py")):
        for call in ast.walk(ast.parse(path.read_text(encoding="utf-8"), filename=str(path))):
            if not (isinstance(call, ast.Call) and call.args and isinstance(call.args[0], ast.Constant)):
                continue
            name = getattr(call.func, "attr", getattr(call.func, "id", None))
            if name == "which" and call.args[0].value in _node._NODE_NAMES:
                asked.append(f"{path.name}:{call.lineno}")

    assert asked == []


# --- a session the resolver says has no Node.js ---------------------------

NODE_AT_A_WELL_KNOWN_LOCATION = "/opt/homebrew/bin/node"


@pytest.mark.parametrize("executable", [NODE_AT_A_WELL_KNOWN_LOCATION, "node",
                                        os.fsencode(NODE_AT_A_WELL_KNOWN_LOCATION)])
def test_where_the_resolver_finds_no_node_starting_one_fails_as_it_would_without_it(monkeypatch, executable):
    """The same error the image raises, so a test that fails there fails here.

    Without this, a machine with Node.js at a well-known location runs the test
    and reports a pass that no Node-less host would give.
    """
    _no_node(monkeypatch)

    with pytest.raises(FileNotFoundError) as refusal:
        _node.refuse_node_the_resolver_did_not_find("subprocess.Popen", (executable, [executable], None, None))

    assert refusal.value.filename == executable
    assert "livemorebio/tests/_node.py" in str(refusal.value)


def test_the_refusal_touches_nothing_else(monkeypatch, tmp_path):
    _no_node(monkeypatch)
    for executable in (sys.executable, "/bin/sh", str(tmp_path / "node-gyp"), None):
        _node.refuse_node_the_resolver_did_not_find("subprocess.Popen", (executable, [], None, None))
    _node.refuse_node_the_resolver_did_not_find("open", (NODE_AT_A_WELL_KNOWN_LOCATION, "r", 0))


def test_a_node_the_resolver_found_may_be_started(monkeypatch):
    monkeypatch.setattr(_node, "node_executable", lambda: NODE_AT_A_WELL_KNOWN_LOCATION)

    _node.refuse_node_the_resolver_did_not_find(
        "subprocess.Popen", (NODE_AT_A_WELL_KNOWN_LOCATION, [NODE_AT_A_WELL_KNOWN_LOCATION], None, None))


def test_only_a_session_without_node_is_held_to_its_absence(monkeypatch):
    """A host that has Node.js gets no hook at all: its tests run exactly as before."""
    installed = []
    monkeypatch.setattr(sys, "addaudithook", installed.append)

    monkeypatch.setattr(_node, "node_executable", lambda: NODE_AT_A_WELL_KNOWN_LOCATION)
    assert _node.hold_a_session_without_node_to_its_absence() is False
    assert installed == []

    _no_node(monkeypatch)
    assert _node.hold_a_session_without_node_to_its_absence() is True
    assert installed == [_node.refuse_node_the_resolver_did_not_find]


# --- a run that must exercise the console's JavaScript --------------------
#
# Skipping is right for a client and for the container image, and wrong for the
# one job whose purpose is to run these tests. With no Node.js that job skipped
# 1184 of them and exited 0: a release gate that had verified none of the
# console's JavaScript, with nothing in its log to say so. LIVEMORE_REQUIRE_NODE=1
# turns the skip into a failure. Nothing the product ships sets it: the hosted
# Installer workflow does. It is inherited, though. Whatever runs the suite from
# a shell that exported it gets a strict run, an install's verification
# included, and the sessions below hold each inherited value to what it does.

def test_a_run_that_requires_node_fails_without_it_instead_of_skipping(monkeypatch):
    _no_node(monkeypatch)
    _refuse_every_process(monkeypatch)
    _require_node(monkeypatch, "1")
    # Nothing configured: the host simply has none.
    monkeypatch.delenv(_toolchain.NODE_ENV, raising=False)

    with pytest.raises(pytest.fail.Exception, match="LIVEMORE_REQUIRE_NODE=1") as failure:
        _node.require_node()
    assert "found no Node.js" in str(failure.value)
    with pytest.raises(pytest.fail.Exception, match="LIVEMORE_REQUIRE_NODE=1"):
        _node.run_node(["node", "--eval", "0"], capture_output=True)


def test_the_failure_names_a_configured_node_that_cannot_be_run(monkeypatch, tmp_path):
    """``LIVEMORE_NODE`` naming something unusable is not the same as having no Node.js.

    The resolver answers None for both, and does not look further. A run that
    requires Node.js has to say which it was, or the remedy offered is wrong.
    """
    configured = tmp_path / "bin" / "node"
    monkeypatch.setenv(_toolchain.NODE_ENV, str(configured))
    _require_node(monkeypatch, "1")

    with pytest.raises(pytest.fail.Exception) as failure:
        _node.require_node()

    assert f"{_toolchain.NODE_ENV} names {configured}, which is not an executable" in str(failure.value)


def test_a_run_that_requires_node_runs_the_one_the_resolver_found(monkeypatch, tmp_path):
    stub = tmp_path / "node"
    stub.write_text("#!/bin/sh\nprintf 'required %s\\n' \"$*\"\n", encoding="utf-8")
    stub.chmod(0o755)
    monkeypatch.setenv(_toolchain.NODE_ENV, str(stub))
    _require_node(monkeypatch, "1")

    assert _node.require_node() == str(stub)
    assert _node.run_node(["node", "--eval", "0"], capture_output=True, text=True, encoding="utf-8").stdout == "required --eval 0\n"


@pytest.mark.parametrize("switch", ["true", "yes", "2", " 1", "on"])
def test_a_misspelt_requirement_is_refused_rather_than_ignored(monkeypatch, switch):
    """``LIVEMORE_REQUIRE_NODE=true`` quietly meaning "not required" would be the silent skip again."""
    _require_node(monkeypatch, switch)

    with pytest.raises(ValueError, match=_node.REQUIRE_NODE_ENV):
        _node.node_is_required()


SMALL_NODE_MODULE = "livemorebio/tests/test_member_picker.py"


def _a_session(tmp_path, switch: str | None, *, node: str | None) -> subprocess.CompletedProcess[str]:
    """A real session over a module whose every test needs Node.js, which inherits the switch.

    ``node`` is the executable the resolver is to find. None is a host the
    resolver says has no Node.js.
    """
    interpreter = [sys.executable, "-X", "utf8", "-B", *(["-I"] if sys.flags.isolated else [])]
    env = dict(os.environ)
    env[_toolchain.NODE_ENV] = node or str(tmp_path / "not-an-executable")
    env.pop(_node.REQUIRE_NODE_ENV, None)
    if switch is not None:
        env[_node.REQUIRE_NODE_ENV] = switch
    return subprocess.run([*interpreter, "-m", "pytest", "-q", "--no-header", "-rs", "-p", "no:cacheprovider",
                           SMALL_NODE_MODULE], cwd=REPOSITORY_ROOT, env=env, capture_output=True, text=True,
                          check=False, encoding="utf-8")


def _a_session_without_node(tmp_path, switch: str | None) -> subprocess.CompletedProcess[str]:
    return _a_session(tmp_path, switch, node=None)


@pytest.mark.parametrize("switch", [None, "0", "1"])
def test_a_session_on_a_host_with_node_runs_its_tests_whatever_it_inherited(tmp_path, switch):
    """Inherited 1 costs a host that has Node.js nothing: the tests run, as they
    do with the switch unset. Where this host has none the gate skips this
    test, or fails it if this run itself requires Node.js."""
    result = _a_session(tmp_path, switch, node=_node.require_node())

    assert result.returncode == 0, result.stdout[-3000:] + result.stderr[-2000:]
    verdict = result.stdout.splitlines()[-1]
    assert "passed" in verdict and "skipped" not in verdict and "failed" not in verdict, verdict


def test_a_session_that_requires_node_fails_where_a_client_session_skips(tmp_path):
    client = _a_session_without_node(tmp_path, None)
    assert client.returncode == 0, client.stdout[-3000:] + client.stderr[-2000:]
    verdict = client.stdout.splitlines()[-1]
    assert "skipped" in verdict and "passed" not in verdict and "failed" not in verdict, verdict
    assert _node.NO_NODE in client.stdout

    required = _a_session_without_node(tmp_path, "1")
    assert required.returncode == 1, required.stdout[-3000:] + required.stderr[-2000:]
    verdict = required.stdout.splitlines()[-1]
    assert "failed" in verdict and "skipped" not in verdict and "passed" not in verdict, verdict
    assert "LIVEMORE_REQUIRE_NODE=1" in required.stdout
    # The stated reason, which says what was looked for and what to do.
    assert "says this run must exercise the console's JavaScript" in required.stdout
    assert f"unset {_node.REQUIRE_NODE_ENV} only where skipping these tests is intended" in required.stdout


@pytest.mark.parametrize("host_has_node", [False, True])
@pytest.mark.parametrize("switch", ["true", "2"])
def test_a_session_with_a_misspelt_requirement_does_not_start(tmp_path, switch, host_has_node):
    """Refused before the first test, whether or not the host has Node.js.

    Having Node.js does not make a value that is not 0 or 1 harmless: nobody can
    say what it was meant to require, so the session says so and stops.
    """
    result = _a_session(tmp_path, switch, node=_node.require_node() if host_has_node else None)

    assert result.returncode not in (0, 1, 5), result.stdout[-3000:] + result.stderr[-2000:]
    said = result.stdout + result.stderr
    assert f"{_node.REQUIRE_NODE_ENV} must be unset, 0 or 1, not {switch!r}" in said
    assert "passed" not in result.stdout and "skipped" not in result.stdout
