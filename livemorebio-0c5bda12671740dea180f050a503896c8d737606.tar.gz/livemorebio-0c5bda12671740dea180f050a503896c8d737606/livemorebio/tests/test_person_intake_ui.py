"""Technical form/controller checks; no participant records are admitted."""
import json
from html.parser import HTMLParser
from pathlib import Path
import subprocess
from ._node import run_node as _run_node


CONSOLE = Path(__file__).parents[1] / 'aegle/console'
TIME_IDS = ['glucose', 'ehr', 'wearable', 'genomic', 'environment']


class FormMarkup(HTMLParser):
    def __init__(self):
        super().__init__()
        self.fields = {}
        self.current_select = None
        self.options = {}

    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        if 'id' in attributes:
            self.fields[attributes['id']] = (tag, attributes)
        if tag == 'select':
            self.current_select = attributes.get('id')
        if tag == 'option' and self.current_select:
            self.options.setdefault(self.current_select, []).append(attributes)

    def handle_endtag(self, tag):
        if tag == 'select':
            self.current_select = None


def test_person_form_has_explicit_separate_source_times_and_no_assumed_consent():
    markup = FormMarkup()
    markup.feed((CONSOLE / 'twins.html').read_text(encoding="utf-8"))
    assert not markup.fields['twin-consent'][1].get('value')
    assert 'required' in markup.fields['twin-consent'][1]
    selected = [option for option in markup.options['twin-smoking'] if 'selected' in option]
    assert selected == [{'value': 'unknown', 'selected': None}]
    for name in TIME_IDS:
        tag, attributes = markup.fields[f'twin-{name}-captured-at']
        assert tag == 'input' and 'required' in attributes
        assert not attributes.get('value')
        assert attributes.get('maxlength') == '80'
    assert markup.fields['twin-source-times'][0] == 'fieldset'


def test_real_controller_keeps_five_original_times_and_source_toggle_values():
    script = r"""
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {populationChoices,cohortIndication,populationGuidance} from GUIDANCE_URL;
import {mountSelectionReconciliation,selectionRequest} from RECOVERY_URL;
const code=fs.readFileSync(SOURCE_PATH,'utf8').replace(/^import .*;\n/gm,'');
const nodes=new Map();
function get(id){
 if(!nodes.has(id))nodes.set(id,{value:'',dataset:{},listeners:{},disabled:false,hidden:false,
  classList:{toggle(){}},setAttribute(){},querySelectorAll(){return[]},
  addEventListener(kind,fn){this.listeners[kind]=fn},dispatchEvent(event){return this.listeners[event.type]?.(event)}});
 return nodes.get(id);
}
get('#twin-source').value='REFERENCE_GROUNDED_SYNTHETIC';
const times=['2026-01-01T01:01:00Z','2026-01-02T02:02:00+01:00','2026-01-03T03:03:00Z','2026-01-04T04:04:00Z','2026-01-05T05:05:00-02:00'];
const timeControls=['glucose','ehr','wearable','genomic','environment'].map((name,i)=>{
 const control=get('#twin-'+name+'-captured-at');control.value=times[i];return control;
});
get('#twin-consent').value='digital_twin';get('#twin-smoking').value='unknown';
get('#twin-glucose').value='95';get('#twin-age').value='40';get('#twin-sex').value='F';
get('#twin-lifestyle').value='0.5';get('#twin-slc22a1').value='0';
for(const name of ['ehr','wearable','genomic','environment'])get('#twin-'+name+'-source').value='TECHNICAL-'+name;
const wrapper={hidden:false,querySelectorAll:()=>[...timeControls,get('#twin-consent')]};
const document={body:{dataset:{subjectView:'twins'},setAttribute(){}},querySelector:get,
 querySelectorAll:selector=>selector==='.real-only'?[wrapper]:[]};
const posted=[],listingReads=[];
const capabilities={schema:'livemore.population-capabilities.v1',templates:[],
 reference_source:{source_id:'TECHNICAL',role:'population_reference'},
 reference_strata:[],healthy_reference_cohort:{available:false,reason:'not configured'}};
const ctx={document,escapeHTML:String,populationChoices,cohortIndication,populationGuidance,
 initReferenceCohorts(){},referenceCohortCard(){},URLSearchParams,Date,AbortController,
 window:{addEventListener(){}},mountSelectionReconciliation,
 selectionRequest:(path,options={})=>selectionRequest(path,{...options,fetcher:async(url,init)=>{
  assert.equal(init.method,'GET');assert.equal(url,'/api/twins?limit=10');listingReads.push(url);
  return new Response(JSON.stringify({selection_status:'CONFIRMED',active:null,twins:[],pagination:{}}),{status:200});
 }}),
 Event:class{constructor(type){this.type=type}},setTimeout(){},clearTimeout(){},
 crypto:{randomUUID:()=> 'technical-only',getRandomValues:a=>a.fill(1)},
 fetch:async(path,options={})=>{
  if(options.method==='POST'){
   assert.equal(path,'/api/twins');posted.push(JSON.parse(options.body));
   return {status:422,ok:false,json:async()=>({error:'TECHNICAL rejection; no record created'})};
  }
  return {status:200,ok:true,json:async()=>path.startsWith('/api/population-capabilities')?capabilities:{twins:[],active:{},pagination:{}}};
 }};
vm.createContext(ctx);vm.runInContext(code,ctx);
for(let i=0;i<10;i++)await Promise.resolve();
const select=value=>{get('#twin-source').value=value;get('#twin-source').dispatchEvent(new ctx.Event('change'))};
assert.equal(wrapper.hidden,true);assert(timeControls.every(control=>control.disabled));
select('REAL_HUMAN');assert.equal(wrapper.hidden,false);assert(timeControls.every(control=>!control.disabled));
select('REFERENCE_GROUNDED_SYNTHETIC');assert(timeControls.every(control=>control.disabled));
assert.deepEqual(timeControls.map(control=>control.value),times);assert.equal(get('#twin-consent').value,'digital_twin');
select('REAL_HUMAN');
await get('#twin-form').listeners.submit({preventDefault(){}});
assert.equal(posted.length,1);
assert.deepEqual([posted[0].observations.glucose_mgdl.captured_at,...posted[0].profile_sources.map(row=>row.captured_at)],times);
assert.equal(posted[0].lifestyle.smoking_status,'unknown');
assert.deepEqual(posted[0].consent_scope,['digital_twin']);
assert(posted[0].profile_sources.every(row=>row.quality_status==='not_assessed'));
assert.equal(get('#subject-banner').textContent,'TECHNICAL rejection; no record created');
select('REFERENCE_GROUNDED_SYNTHETIC');
await get('#twin-form').listeners.submit({preventDefault(){}});
assert.equal(posted.length,2);assert.equal(posted[1].profile_sources,undefined);
assert.equal(posted[1].observations,undefined);assert.equal(posted[1].consent_scope,undefined);
assert.deepEqual(listingReads,['/api/twins?limit=10']);
"""
    script = script.replace('GUIDANCE_URL', json.dumps((CONSOLE / 'lib/population_forms.js').as_uri()))
    script = script.replace('RECOVERY_URL', json.dumps((CONSOLE / 'lib/selection_reconciliation.js').as_uri()))
    script = script.replace('SOURCE_PATH', json.dumps(str(CONSOLE / 'lib/subjects.js')))
    result = _run_node(['node', '--input-type=module', '-e', script], capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr
