from __future__ import annotations

import io
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tomllib

import pytest

from ._node import REQUIRE_NODE_ENV
from ._source_tree import (ABSENT_TOOLS_ENV, CONTAINER_IMAGE, TREE_ENV, require_source_tree,
                           source_tree_only)


REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
INSTALLER = REPOSITORY_ROOT / "install.sh"
COMMIT_A = "a" * 40
COMMIT_B = "b" * 40
BOOTSTRAP_DOCUMENTS = (
    REPOSITORY_ROOT / "docs/solutions/PRIVATE_CHECKOUT_INSTALL.md",

)


def test_clean_install_declares_direct_scientific_dependencies() -> None:
    with (REPOSITORY_ROOT / "pyproject.toml").open("rb") as project_file:
        project = tomllib.load(project_file)

    dependencies = project["project"]["dependencies"]
    kernels = project["project"]["optional-dependencies"]["kernels"]
    assert any(requirement.startswith("networkx>=") for requirement in dependencies)
    assert any(requirement.startswith("copasi-basico>=") for requirement in kernels)
    assert any(requirement.startswith("cobra>=") for requirement in kernels)
    assert not any(requirement.startswith("basico>=") for requirement in kernels)
    lock = (REPOSITORY_ROOT / "requirements-python311.lock").read_text(
        encoding="utf-8"
    )
    for dependency in ("networkx", "copasi-basico", "cobra", "setuptools"):
        assert f"{dependency}==" in lock
    assert "--hash=sha256:" in lock


def _documented_bootstrap_commands() -> list[str]:
    # The guides are source-tree documents; the container image does not carry them.
    require_source_tree("docs/solutions/PRIVATE_CHECKOUT_INSTALL.md")
    from .private_reference_helpers import require_private_reference_data
    require_private_reference_data(BOOTSTRAP_DOCUMENTS[0])
    commands: list[str] = []
    for document in BOOTSTRAP_DOCUMENTS:
        matches = [
            line
            for line in document.read_text(encoding="utf-8").splitlines()
            if line.startswith("bash -c 'set -euo pipefail;")
        ]
        assert len(matches) == 1, f"expected one bootstrap command in {document}"
        commands.append(matches[0])
    return commands


def test_documented_bootstrap_command_is_identical_everywhere() -> None:
    commands = _documented_bootstrap_commands()
    assert len(set(commands)) == 1


def _bootstrap_fake_gh(fake_bin: Path) -> None:
    fake_bin.mkdir(parents=True)
    _write_executable(
        fake_bin / "gh",
        f"""#!{sys.executable}
import os
from pathlib import Path
import sys

args = sys.argv[1:]
if args[:2] == ["auth", "status"]:
    raise SystemExit(0 if os.environ.get("BOOTSTRAP_AUTH", "ok") == "ok" else 1)
if not args or args[0] != "api" or len(args) < 2:
    raise SystemExit(90)
endpoint = args[1]
if endpoint in ("repos/MannyAmah/livemorebio/commits/main", "repos/MannyAmah/livemorebio/commits/codex/genome-models-clean-workflows"):
    print(os.environ["BOOTSTRAP_COMMIT"])
    raise SystemExit(0)
if endpoint.startswith("repos/MannyAmah/livemorebio/contents/install.sh?ref="):
    behavior = os.environ.get("BOOTSTRAP_CONTENT_BEHAVIOR", "success")
    if behavior == "partial":
        print("echo should-not-run")
        raise SystemExit(42)
    if behavior == "empty":
        raise SystemExit(0)
    sys.stdout.write(Path(os.environ["BOOTSTRAP_INSTALLER_FIXTURE"]).read_text(encoding="utf-8"))
    raise SystemExit(0)
raise SystemExit(91)
""",
    )


@pytest.fixture()
def bootstrap_env(tmp_path: Path) -> dict[str, str]:
    fake_bin = tmp_path / "bootstrap-bin"
    _bootstrap_fake_gh(fake_bin)
    installer_fixture = tmp_path / "downloaded-installer.sh"
    installer_fixture.write_text(
        'printf "%s\\n" "$LIVEMORE_REF" >"$BOOTSTRAP_RECORD"\n',
        encoding="utf-8",
    )
    return {
        **_inherited_environment(),
        "PATH": os.pathsep.join((str(fake_bin), "/usr/bin", "/bin")),
        "BOOTSTRAP_AUTH": "ok",
        "BOOTSTRAP_COMMIT": COMMIT_A,
        "BOOTSTRAP_INSTALLER_FIXTURE": str(installer_fixture),
        "BOOTSTRAP_RECORD": str(tmp_path / "bootstrap-record"),
    }


def _inherited_environment() -> dict[str, str]:
    """Ambient LIVEMORE_* settings must not reach the installer under test.

    These fixtures drive the installer with a fake toolchain and a fixture
    archive. An operator (or the installer's own verification run) may have
    LIVEMORE_SHA256, LIVEMORE_DIST_BASE or similar exported, and inheriting
    those makes the installer check the fixture against a real release.
    """
    return {name: value for name, value in os.environ.items()
            if not name.startswith("LIVEMORE_")}


def _run_bootstrap(env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["/bin/bash", "-c", _documented_bootstrap_commands()[0]],
        cwd=REPOSITORY_ROOT,
        env=env,
        capture_output=True,
        text=True,
        check=False, encoding="utf-8",
    )


def test_bootstrap_pins_installer_and_install_to_resolved_commit(
    bootstrap_env: dict[str, str],
) -> None:
    result = _run_bootstrap(bootstrap_env)

    assert result.returncode == 0, result.stderr
    assert Path(bootstrap_env["BOOTSTRAP_RECORD"]).read_text(encoding="utf-8") == (
        f"{COMMIT_A}\n"
    )



def test_bootstrap_requires_github_authorization(
    bootstrap_env: dict[str, str],
) -> None:
    bootstrap_env["BOOTSTRAP_AUTH"] = "missing"

    result = _run_bootstrap(bootstrap_env)

    assert result.returncode != 0
    assert "gh auth login" in result.stderr.lower()
    assert not Path(bootstrap_env["BOOTSTRAP_RECORD"]).exists()


@pytest.mark.parametrize("behavior", ["partial", "empty"])
def test_bootstrap_never_executes_an_incomplete_download(
    bootstrap_env: dict[str, str], behavior: str
) -> None:
    bootstrap_env["BOOTSTRAP_CONTENT_BEHAVIOR"] = behavior

    result = _run_bootstrap(bootstrap_env)

    assert result.returncode != 0
    assert not Path(bootstrap_env["BOOTSTRAP_RECORD"]).exists()


def _write_executable(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")
    path.chmod(0o755)


def _fixture_archive(path: Path) -> None:
    technical_payload = b"technical-cardio-fixture"
    technical_manifest = {"assets": {"cellml": {
        "filename": "ohara_rudy_cipa_2017.cellml",
        "sha256": hashlib.sha256(technical_payload).hexdigest(),
        "size_bytes": len(technical_payload),
    }}}
    files = {
        "fixture/pyproject.toml": b"[project]\nname='installer-fixture'\nversion='0.0.1'\n",
        "fixture/requirements-python311.lock": b"# hash-locked installer fixture\n",
        "fixture/livemorebio/__init__.py": b"__version__ = 'fixture'\n",
        "fixture/livemorebio/model_assets.py": (
            '"""Technical installer fixture manifest; no biological model."""\n'
            f'def asset_manifest(model_id: str) -> dict:\n    assert model_id == "cardiac"\n    return {technical_manifest!r}\n'
        ).encode("utf-8"),
        "fixture/tools/run_review_stack.py": (
            REPOSITORY_ROOT / "tools" / "run_review_stack.py"
        ).read_bytes(),
    }
    # This technical archive executes real admission and credential isolation;
    # its runner dependencies must not come from an installed source checkout.
    for name in ("registry.py", "console_filesystem.py", "service_identity.py",
                 "_platform.py", "security.py"):
        files[f"fixture/livemorebio/{name}"] = (
            REPOSITORY_ROOT / "livemorebio" / name
        ).read_bytes()
    with tarfile.open(path, "w:gz") as archive:
        for name, payload in files.items():
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            archive.addfile(info, io.BytesIO(payload))


@source_tree_only("install.sh")
def test_technical_installer_fixture_owns_its_review_runner_imports(tmp_path: Path) -> None:
    """A clean child must use the technical archive's actual admission modules."""
    archive_path = tmp_path / "technical-source.tar.gz"
    _fixture_archive(archive_path)
    with tarfile.open(archive_path, "r:gz") as archive:
        for member in archive.getmembers():
            destination = tmp_path / member.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.extractfile(member) as stream:
                destination.write_bytes(stream.read())
    source = tmp_path / "fixture"
    home = tmp_path / "technical-home"
    home.mkdir()
    program = '''
import importlib.util
import json
from pathlib import Path
import stat
import sys

source = Path.cwd()
spec = importlib.util.spec_from_file_location("technical_review_runner", source / "tools/run_review_stack.py")
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
data, environment = helper.prepare_review_environment(source / "technical-data", inherited={})
names = ("registry", "console_filesystem", "service_identity", "_platform", "security")
for name in names:
    module = sys.modules["livemorebio." + name]
    assert Path(module.__file__).resolve() == source / "livemorebio" / (name + ".py")
assert stat.S_IMODE(data.stat().st_mode) == 0o700
assert Path(environment["LIVEMORE_DATA_DIR"]) == data
print(json.dumps({"data_class": "technical_fixture", "modules": list(names)}))
'''
    environment = {**_inherited_environment(), "HOME": str(home)}
    # Disable site packages as well as ambient Python paths, so an editable
    # installation cannot supply an admission module missing from this archive.
    result = subprocess.run(
        [sys.executable, "-I", "-S", "-B", "-c", program], cwd=source,
        env=environment, capture_output=True, text=True, encoding="utf-8", check=False,
        timeout=30,
    )
    assert result.returncode == 0, result.stderr
    assert json.loads(result.stdout) == {
        "data_class": "technical_fixture",
        "modules": ["registry", "console_filesystem", "service_identity", "_platform", "security"],
    }


def _fake_tools(fake_bin: Path) -> None:
    fake_bin.mkdir(parents=True)
    _write_executable(
        fake_bin / "gh",
        f"""#!{sys.executable}
import os
from pathlib import Path
import sys

args = sys.argv[1:]
if args[:2] == ["auth", "status"]:
    raise SystemExit(0 if os.environ.get("FAKE_GH_AUTH", "ok") == "ok" else 1)
if not args or args[0] != "api" or len(args) < 2:
    print("unsupported fake gh invocation", args, file=sys.stderr)
    raise SystemExit(90)
endpoint = args[1]
if "/commits/" in endpoint:
    print(os.environ["FAKE_GH_COMMIT"])
    raise SystemExit(0)
if "/tarball/" in endpoint:
    sys.stdout.buffer.write(Path(os.environ["FAKE_GH_ARCHIVE"]).read_bytes())
    raise SystemExit(0)
print("unsupported fake gh endpoint", endpoint, file=sys.stderr)
raise SystemExit(91)
""",
    )
    _write_executable(
        fake_bin / "python3.11",
        f"""#!{sys.executable}
import os
from pathlib import Path
import stat
import sys

args = sys.argv[1:]
log_path = os.environ.get("FAKE_INSTALL_LOG")
if log_path:
    with open(log_path, "a", encoding="utf-8") as log:
        log.write("system-python " + " ".join(args) + "\\n")
if args[:2] == ["-I", "-B"]:
    # This script interprets the flags itself, so the real interpreter never
    # sees -B. Preserve its effect when executing the installer's inline code.
    sys.dont_write_bytecode = True
    args = args[2:]
if args and args[0] == "-c":
    if "sys.version_info" in args[1]:
        print(os.environ.get("FAKE_PYTHON_VERSION", "3.11"))
    else:
        sys.argv = ["-c", *args[2:]]
        exec(compile(args[1], "<installer-command>", "exec"), {{"__name__": "__main__"}})
    raise SystemExit(0)
if args and args[0] == "-":
    code = sys.stdin.read()
    sys.argv = [sys.argv[0], *args[1:]]
    exec(compile(code, "<installer-stdin>", "exec"), {{"__name__": "__main__"}})
    raise SystemExit(0)
if args[:2] != ["-m", "venv"] or len(args) != 3:
    print("unsupported fake python invocation", args, file=sys.stderr)
    raise SystemExit(92)
venv = Path(args[2])
bin_dir = venv / "bin"
bin_dir.mkdir(parents=True)
venv_python = bin_dir / "python"
venv_python.write_text('''#!{sys.executable}
import json
import os
from pathlib import Path
import sys

args = sys.argv[1:]
log_path = os.environ.get("FAKE_INSTALL_LOG")
if log_path:
    with open(log_path, "a", encoding="utf-8") as log:
        log.write("venv-python " + " ".join(args) + "\\\\n")
args = [arg for arg in args if arg not in ("-I", "-B")]
phase = ""
if args[:3] == ["-m", "pip", "install"]:
    if "--require-hashes" in args:
        phase = "locked-dependencies"
    elif "--no-deps" in args and "--no-build-isolation" in args:
        phase = "project-install"
    else:
        phase = "unexpected-pip-install"
elif args[:2] == ["-m", "pytest"] or args[:4] == ["-X", "utf8", "-m", "pytest"]:
    phase = "pytest"
    if os.environ.get("FAKE_VERIFY_ACTIVE_BASE"):
        active_model = Path(os.environ["FAKE_VERIFY_ACTIVE_BASE"])
        if active_model.exists() or active_model.is_symlink():
            print("technical active cardiac asset appeared before verification", file=sys.stderr)
            raise SystemExit(41)
    if os.environ.get("FAKE_POST_GATE_CORRUPT_CARDIAC") == "1":
        model = Path(sys.argv[0]).parents[2] / "models" / "cardiac" / "ohara_rudy_cipa_2017.cellml"
        model.write_text("technical-post-gate-mismatch", encoding="utf-8")
    if os.environ.get("FAKE_VERIFICATION_LOG"):
        data = Path(os.environ["LIVEMORE_DATA_DIR"])
        path_keys = os.environ["FAKE_VERIFICATION_PATH_KEYS"].split(",")
        credential_files = [
            ("LIVEMORE_API_TOKEN", "api-token"),
            ("LIVEMORE_PATCH_STORAGE_KEY", "patch-storage-key"),
            ("LIVEMORE_PATCH_ADMISSION_HMAC_KEY", "patch-admission-key"),
        ]
        record = dict(
            data=str(data),
            paths=dict((key, os.environ.get(key)) for key in path_keys),
            credentials_match_private_files=dict(
                (key, (data / name).is_file() and
                 os.environ.get(key) == (data / name).read_text(encoding="utf-8").strip())
                for key, name in credential_files
            ),
            inherited_signing_removed=("LIVEMORE_EVIDENCE_SIGNING_KEY" not in os.environ),
            inherited_audit_removed=("LIVEMORE_EVIDENCE_AUDIT_HMAC_KEY" not in os.environ),
            genome_test_mode=os.environ.get("LIVEMORE_TEST_GENOME_MODELS"),
            environment=os.environ.get("LIVEMORE_ENVIRONMENT"),
        )
        with open(os.environ["FAKE_VERIFICATION_LOG"], "a", encoding="utf-8") as log:
            log.write(json.dumps(record) + "\\\\n")
elif args[:2] == ["-m", "compileall"]:
    phase = "compileall"
elif args[:2] == ["-m", "livemorebio.cli"]:
    phase = "cli-smoke"
elif args[:2] == ["-m", "livemorebio.model_assets"]:
    phase = "model-assets"
    # Technical fake acquisition: selective failure and an inert write make
    # activation/digest tests exercise the installer's actual boundaries.
    if os.environ.get("FAKE_FAIL_MODEL") == args[-1]:
        print("technical pinned-model acquisition failure", file=sys.stderr)
        raise SystemExit(41)
    if os.environ.get("FAKE_MODEL_WRITES", "1") == "1" and args[-1] == "cardiac":
        model = Path(sys.argv[0]).parents[2] / "models" / "cardiac" / "ohara_rudy_cipa_2017.cellml"
        model.parent.mkdir(parents=True, exist_ok=True)
        model.write_text("technical-cardio-fixture", encoding="utf-8")
        model.with_suffix(".cellml.attribution.json").write_text("technical-attribution-fixture", encoding="utf-8")
        (model.parent / ".install.lock").write_bytes(b"")
elif args and args[0].endswith("/livemore"):
    phase = "installed-cli"
else:
    print("unsupported fake venv python invocation", args, file=sys.stderr)
    raise SystemExit(93)
if os.environ.get("FAKE_TRANSIENT_PHASE") == phase:
    # Fail a bounded number of times, then succeed: a slow mirror, not a
    # broken one. The counter lives in a file so it survives each new process.
    counter = Path(os.environ["FAKE_TRANSIENT_COUNT_FILE"])
    seen = int(counter.read_text(encoding="utf-8")) if counter.exists() else 0
    if seen < int(os.environ.get("FAKE_TRANSIENT_FAILURES", "1")):
        counter.write_text(str(seen + 1), encoding="utf-8")
        print("transient " + phase + " failure", file=sys.stderr)
        raise SystemExit(41)
if os.environ.get("FAKE_FAIL_PHASE") == phase:
    print("forced " + phase + " failure", file=sys.stderr)
    raise SystemExit(41)
raise SystemExit(0)
''', encoding="utf-8")
venv_python.chmod(venv_python.stat().st_mode | stat.S_IXUSR)
livemore = bin_dir / "livemore"
livemore.write_text(
    "#!" + str(venv_python) + "\\n# installer fixture entry point\\n",
    encoding="utf-8",
)
livemore.chmod(livemore.stat().st_mode | stat.S_IXUSR)
""",
    )
    _write_executable(
        fake_bin / "python3.12",
        "#!/bin/sh\necho 'python3.12 must not be selected' >&2\nexit 77\n",
    )


@pytest.fixture()
def installer_env(tmp_path: Path) -> dict[str, str]:
    # Every test that drives the installer takes this fixture. Where there is no
    # installer, bash exits 127 for the missing script, and a test that only
    # asserts a refusal would pass without having exercised anything.
    require_source_tree("install.sh")
    home = tmp_path / "home"
    home.mkdir()
    fake_bin = tmp_path / "fake-bin"
    _fake_tools(fake_bin)
    archive = tmp_path / "source.tar.gz"
    _fixture_archive(archive)
    install_base = tmp_path / "install base"
    bin_dir = tmp_path / "user bin"
    log = tmp_path / "install.log"
    return {
        **_inherited_environment(),
        "HOME": str(home),
        "PATH": os.pathsep.join((str(fake_bin), "/usr/bin", "/bin")),
        "SHELL": "/bin/zsh",
        "LIVEMORE_INSTALL_DIR": str(install_base),
        "LIVEMORE_BIN_DIR": str(bin_dir),
        "LIVEMORE_REF": "main",
        "FAKE_GH_AUTH": "ok",
        "FAKE_GH_COMMIT": COMMIT_A,
        "FAKE_GH_ARCHIVE": str(archive),
        "FAKE_INSTALL_LOG": str(log),
        "FAKE_PYTHON_VERSION": "3.11",
    }


def _run(env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["/bin/bash", str(INSTALLER)],
        cwd=REPOSITORY_ROOT,
        env=env,
        capture_output=True,
        text=True,
        check=False, encoding="utf-8",
    )


def _current_commit(env: dict[str, str]) -> str:
    current = Path(env["LIVEMORE_INSTALL_DIR"]) / "current"
    return current.resolve().name


@pytest.fixture()
def local_archive_env(installer_env: dict[str, str]) -> dict[str, str]:
    archive = Path(installer_env["FAKE_GH_ARCHIVE"])
    installer_env.update({
        "LIVEMORE_ARCHIVE": str(archive),
        "LIVEMORE_REF": COMMIT_A,
        "LIVEMORE_SHA256": hashlib.sha256(archive.read_bytes()).hexdigest(),
        "LIVEMORE_INSTALL_MODELS": "none",
    })
    fake_bin = Path(installer_env["PATH"].split(os.pathsep)[0])
    for name in ("gh", "curl"):
        _write_executable(fake_bin / name, "#!/bin/sh\necho 'local source contacted network tool' >&2\nexit 97\n")
    return installer_env


def test_local_archive_checks_digest_and_runs_all_gates_before_activation(local_archive_env):
    result = _run(local_archive_env)
    assert result.returncode == 0, result.stderr
    assert "Archive checksum verified." in result.stdout
    assert _current_commit(local_archive_env) == COMMIT_A
    log = Path(local_archive_env["FAKE_INSTALL_LOG"]).read_text(encoding="utf-8")
    assert "-X utf8 -m pytest -p no:cacheprovider -q" in log
    assert "-m compileall -q livemorebio" in log
    assert "-m livemorebio.cli --help" in log
    assert (Path(local_archive_env["LIVEMORE_INSTALL_DIR"]) / "releases" / COMMIT_A /
            ".livemore-install-complete").is_file()


@pytest.mark.parametrize("name,value,message", [
    ("LIVEMORE_REF", "", "full commit"),
    ("LIVEMORE_REF", "main", "full commit"),
    ("LIVEMORE_SHA256", "", "requires LIVEMORE_SHA256"),
    ("LIVEMORE_SHA256", "invalid", "64 hexadecimal"),
    ("LIVEMORE_ARCHIVE", "relative.tar.gz", "absolute path"),
])
def test_local_archive_rejects_incomplete_or_unsafe_inputs_before_staging(
    local_archive_env, name, value, message
):
    local_archive_env[name] = value
    result = _run(local_archive_env)
    assert result.returncode != 0
    assert message in result.stderr
    assert not Path(local_archive_env["LIVEMORE_INSTALL_DIR"]).exists()


@pytest.mark.parametrize("kind", ["missing", "directory", "symlink"])
def test_local_archive_requires_a_regular_non_symlink_file(local_archive_env, tmp_path, kind):
    path = tmp_path / "local-archive"
    if kind == "directory":
        path.mkdir()
    elif kind == "symlink":
        path.symlink_to(local_archive_env["LIVEMORE_ARCHIVE"])
    local_archive_env["LIVEMORE_ARCHIVE"] = str(path)
    result = _run(local_archive_env)
    assert result.returncode != 0
    assert "regular file" in result.stderr
    assert not Path(local_archive_env["LIVEMORE_INSTALL_DIR"]).exists()


def test_local_archive_checksum_mismatch_never_extracts_or_activates(local_archive_env):
    local_archive_env["LIVEMORE_SHA256"] = "0" * 64
    result = _run(local_archive_env)
    assert result.returncode != 0
    assert "checksum mismatch" in result.stderr
    base = Path(local_archive_env["LIVEMORE_INSTALL_DIR"])
    assert not (base / "current").exists()
    assert not (base / "releases" / COMMIT_A).exists()
    log = Path(local_archive_env["FAKE_INSTALL_LOG"]).read_text(encoding="utf-8")
    assert "system-python -m venv" not in log


def test_local_archive_failed_verification_never_activates(local_archive_env):
    local_archive_env["FAKE_FAIL_PHASE"] = "pytest"
    result = _run(local_archive_env)
    assert result.returncode != 0
    assert "test verification" in result.stderr
    base = Path(local_archive_env["LIVEMORE_INSTALL_DIR"])
    assert not (base / "current").exists()
    assert not (base / "releases" / COMMIT_A).exists()


def test_fresh_install_activates_pinned_release_and_updates_zsh_path(
    installer_env: dict[str, str],
) -> None:
    result = _run(installer_env)

    assert result.returncode == 0, result.stderr
    install_base = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    bin_dir = Path(installer_env["LIVEMORE_BIN_DIR"])
    release = install_base / "releases" / COMMIT_A
    assert _current_commit(installer_env) == COMMIT_A
    assert (release / ".livemore-install-complete").is_file()
    assert (install_base / "integrity" / f"{COMMIT_A}.sha256").is_file()
    assert (release / "source" / ".venv" / "bin" / "livemore").is_file()
    assert (bin_dir / "livemore").is_symlink()
    assert os.readlink(bin_dir / "livemore") == str(
        install_base / "launcher" / "livemore"
    )
    zshrc = Path(installer_env["HOME"]) / ".zshrc"
    profile = zshrc.read_text(encoding="utf-8")
    assert "# >>> LivemoreBio PATH >>>" in profile
    assert str(bin_dir) in profile
    log = Path(installer_env["FAKE_INSTALL_LOG"]).read_text(encoding="utf-8")
    assert "-m venv" in log
    # Assert the properties, not one exact spelling: hashes are required, the
    # lock decides the set, and a slow mirror does not discard the install.
    assert "-m pip install" in log and "--require-hashes" in log
    assert "--requirement" in log and "requirements-python311.lock" in log
    assert "--retries" in log and "--timeout" in log
    assert "-m pip install --no-deps --no-build-isolation -e" in log
    assert "-m livemorebio.model_assets install human-gem" in log
    assert log.index("-m livemorebio.model_assets install human-gem") < log.index("-m pytest -p no:cacheprovider -q")
    assert "-I -B -X utf8 -m pytest -p no:cacheprovider -q" in log
    assert "-m compileall -q livemorebio" in log
    assert "Installation complete" in result.stdout
    assert COMMIT_A in result.stdout
    installed_cli = subprocess.run(
        [str(bin_dir / "livemore")],
        env=installer_env,
        capture_output=True,
        text=True,
        check=False, encoding="utf-8",
    )
    assert installed_cli.returncode == 0, installed_cli.stderr


def test_model_and_launcher_imports_are_isolated_from_callers_checkout(installer_env):
    result = _run(installer_env)
    assert result.returncode == 0, result.stderr
    log = Path(installer_env["FAKE_INSTALL_LOG"]).read_text(encoding="utf-8")
    assert "-I -B -m livemorebio.model_assets" in log
    assert "-I -B -m livemorebio.cli" in log
    verification_source = (
        Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "releases" / COMMIT_A / "source"
    )
    assert f"system-python -I -B - {verification_source}" in log
    launcher = Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "launcher" / "livemore"
    assert "-I -B -m livemorebio.cli" in launcher.read_text(encoding="utf-8")


def test_reused_release_model_gate_does_not_write_release_caches(installer_env):
    assert _run(installer_env).returncode == 0
    before = Path(installer_env["FAKE_INSTALL_LOG"]).read_text(encoding="utf-8")
    result = _run(installer_env)
    assert result.returncode == 0, result.stderr
    calls = Path(installer_env["FAKE_INSTALL_LOG"]).read_text(encoding="utf-8")[len(before):]
    assert "-I -B -X utf8 -m pytest -p no:cacheprovider" in calls


@pytest.mark.parametrize("model_location", ["explicit", "data-default", "home-default"])
@pytest.mark.parametrize("mode", ["human-gem", "none"])
def test_verification_isolates_operational_paths_credentials_and_preserves_model_cache(
    installer_env: dict[str, str], tmp_path: Path, model_location: str, mode: str
) -> None:
    operational = tmp_path / "operational-data"
    operational.mkdir()
    sentinel = operational / "keep.txt"
    sentinel.write_text("existing operational data", encoding="utf-8")
    path_keys = (
        "LIVEMORE_SUBJECT_REGISTRY", "LIVEMORE_PROTOCOL_RUNS", "LIVEMORE_RESEARCH_STORE",
        "LIVEMORE_LICENSED_REFERENCE_DIR", "LIVEMORE_EVIDENCE_DB",
        "LIVEMORE_EVIDENCE_EXPORT_DIR", "LIVEMORE_PATCH_JOURNAL", "LIVEMORE_SCREEN_RUN_DIR",
        "LIVEMORE_RESOLVE_CACHE", "LIVEMORE_CACHE", "LIVEMORE_ANATOMY_DIR", "CENDOS_DB",
        "LIVEMORE_EVIDENCE_SIGNING_KEY_FILE", "LIVEMORE_MODEL_DIR",
    )
    installer_env.update({key: str(operational / key.lower()) for key in path_keys})
    installer_env.update({
        "LIVEMORE_DATA_DIR": str(operational),
        "LIVEMORE_INSTALL_MODELS": mode,
        "LIVEMORE_ENVIRONMENT": "production",
        "LIVEMORE_API_TOKEN": "technical-test-inherited-token",
        "LIVEMORE_PATCH_STORAGE_KEY": "technical-test-inherited-storage-key",
        "LIVEMORE_PATCH_ADMISSION_HMAC_KEY": "technical-test-inherited-admission-key",
        "LIVEMORE_EVIDENCE_SIGNING_KEY": "technical-test-inherited-signing-key",
        "LIVEMORE_EVIDENCE_AUDIT_HMAC_KEY": "technical-test-inherited-audit-key",
        "FAKE_VERIFICATION_LOG": str(tmp_path / "verification-paths.jsonl"),
        "FAKE_VERIFICATION_PATH_KEYS": ",".join(path_keys),
        "TMPDIR": str(tmp_path),
    })
    expected_model_root = operational / "livemore_model_dir"
    if model_location != "explicit":
        installer_env.pop("LIVEMORE_MODEL_DIR")
        expected_model_root = operational / "models"
    if model_location == "home-default":
        installer_env.pop("LIVEMORE_DATA_DIR")
        expected_model_root = Path(installer_env["HOME"]) / ".livemore" / "models"
    # The fake interpreter logs paths and credential-comparison booleans only.
    # It must not expose inherited or generated credential contents.
    result = _run(installer_env)
    assert result.returncode == 0, result.stderr
    verification_log = Path(installer_env["FAKE_VERIFICATION_LOG"])
    records = [json.loads(line) for line in verification_log.read_text(encoding="utf-8").splitlines()]
    assert len(records) == 1
    first_root = Path(records[0]["data"])
    assert first_root != operational
    assert not first_root.is_relative_to(Path(installer_env["LIVEMORE_INSTALL_DIR"]))
    assert first_root.stat().st_mode & 0o777 == 0o700
    assert records[0]["genome_test_mode"] == ("1" if mode == "human-gem" else "0")
    for key, value in records[0]["paths"].items():
        if key == "LIVEMORE_MODEL_DIR":
            assert Path(value) == expected_model_root
        else:
            assert Path(value).parent == first_root, key
    assert all(records[0]["credentials_match_private_files"].values())
    assert records[0]["inherited_signing_removed"]
    assert records[0]["inherited_audit_removed"]
    assert records[0]["environment"] == "development"
    assert "technical-test-inherited" not in verification_log.read_text(encoding="utf-8")
    assert list(operational.iterdir()) == [sentinel]

    if mode == "human-gem":
        integrity_file = Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "integrity" / f"{COMMIT_A}.sha256"
        digest = integrity_file.read_bytes()
        repeated = _run(installer_env)
        assert repeated.returncode == 0, repeated.stderr
        records = [json.loads(line) for line in verification_log.read_text(encoding="utf-8").splitlines()]
        assert len(records) == 2
        second_root = Path(records[1]["data"])
        assert second_root != first_root
        assert second_root != operational
        assert second_root.is_dir() and first_root.is_dir()
        assert all(records[1]["credentials_match_private_files"].values())
        assert records[1]["genome_test_mode"] == "1"
        assert Path(records[1]["paths"]["LIVEMORE_MODEL_DIR"]) == expected_model_root
        assert integrity_file.read_bytes() == digest
        assert list(operational.iterdir()) == [sentinel]


def _verification_environments(installer_env: dict[str, str], tmp_path: Path, *names: str) -> list[dict]:
    """Run the installer; return what each verification run was handed for these variables.

    The fake interpreter records the named variables of the environment it is
    started with, None for one that is not set.
    """
    log = tmp_path / "verification-environment.jsonl"
    installer_env.update({"FAKE_VERIFICATION_LOG": str(log), "FAKE_VERIFICATION_PATH_KEYS": ",".join(names),
                          "TMPDIR": str(tmp_path)})
    result = _run(installer_env)
    assert result.returncode == 0, result.stderr
    return [json.loads(line)["paths"] for line in log.read_text(encoding="utf-8").splitlines()]


def test_verification_is_not_handed_what_only_describes_the_container_image(installer_env, tmp_path):
    """Two variables describe the image to the suite: one declares the tree to
    be the image, the other names tools its base lacks. Neither is ever true of
    an install, and the installer handed on whatever its caller had exported.

    The suite refuses the first in a tree that is not an image, so an install
    from a shell that exported it would be refused over a variable that has
    nothing to do with the install. The second takes ``ps`` away from a frozen
    tool's tests, which then fail. Both are removed at the boundary, on the
    first verification and on the one a repeated install runs."""
    installer_env.update({TREE_ENV: CONTAINER_IMAGE, ABSENT_TOOLS_ENV: "ps"})

    assert _verification_environments(installer_env, tmp_path, TREE_ENV, ABSENT_TOOLS_ENV) == [
        {TREE_ENV: None, ABSENT_TOOLS_ENV: None}]
    assert _verification_environments(installer_env, tmp_path, TREE_ENV, ABSENT_TOOLS_ENV) == [
        {TREE_ENV: None, ABSENT_TOOLS_ENV: None}] * 2


def test_verification_ignores_inherited_pytest_selection_and_plugins(installer_env, tmp_path):
    installer_env.update({"PYTEST_ADDOPTS": "-k hidden_selection", "PYTEST_PLUGINS": "unreviewed_plugin"})
    expected = {"PYTEST_ADDOPTS": None, "PYTEST_PLUGINS": None}
    assert _verification_environments(installer_env, tmp_path, *expected) == [expected]
    assert _verification_environments(installer_env, tmp_path, *expected) == [expected] * 2


@pytest.mark.parametrize("exported", [None, "1", "0", "true"])
def test_verification_is_handed_the_node_requirement_its_caller_exported(installer_env, tmp_path, exported):
    """The installer does not set ``LIVEMORE_REQUIRE_NODE``, so with it unset no
    install requires Node.js. It does not remove it either, and that is on
    purpose: a caller that exported 1 to prove the console's JavaScript was
    exercised must not have that dropped when an install is verified.

    So an exported value reaches the suite as it was given, including one that
    is not 0 or 1. ``test_node_gate`` holds each value to what it then does:
    1 runs the tests where there is a Node.js and fails where there is none,
    and anything else stops the suite before its first test."""
    if exported is not None:
        installer_env[REQUIRE_NODE_ENV] = exported

    assert _verification_environments(installer_env, tmp_path, REQUIRE_NODE_ENV) == [{REQUIRE_NODE_ENV: exported}]


@pytest.mark.parametrize("reuse", [False, True])
def test_failed_verification_retains_private_data_without_changing_operational_store(
    installer_env: dict[str, str], tmp_path: Path, reuse: bool
) -> None:
    operational = tmp_path / "operational-data"
    operational.mkdir()
    installer_env["LIVEMORE_DATA_DIR"] = str(operational)
    if reuse:
        assert _run(installer_env).returncode == 0
    installer_env.update({
        "FAKE_FAIL_PHASE": "pytest",
        "FAKE_VERIFICATION_LOG": str(tmp_path / "verification-paths.jsonl"),
        "FAKE_VERIFICATION_PATH_KEYS": "LIVEMORE_EVIDENCE_DB,LIVEMORE_MODEL_DIR",
        "TMPDIR": str(tmp_path),
    })

    result = _run(installer_env)

    assert result.returncode != 0
    record = json.loads(Path(installer_env["FAKE_VERIFICATION_LOG"]).read_text(encoding="utf-8"))
    verification_root = Path(record["data"])
    assert verification_root != operational
    assert verification_root.is_dir()
    assert (verification_root / "api-token").is_file()
    assert str(verification_root) in result.stdout
    assert list(operational.iterdir()) == []
    if reuse:
        assert _current_commit(installer_env) == COMMIT_A
    else:
        assert not (Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "current").exists()


def test_repeat_same_commit_repairs_activation_without_rebuild(
    installer_env: dict[str, str],
) -> None:
    assert _run(installer_env).returncode == 0
    log = Path(installer_env["FAKE_INSTALL_LOG"])
    log.write_text("", encoding="utf-8")

    repeated = _run(installer_env)

    assert repeated.returncode == 0, repeated.stderr
    assert "already verified" in repeated.stdout
    assert "-m venv" not in log.read_text(encoding="utf-8")
    assert "-m livemorebio.model_assets install human-gem" in log.read_text(encoding="utf-8")


def test_model_failure_preserves_active_release(installer_env):
    assert _run(installer_env).returncode == 0
    installer_env["FAKE_GH_COMMIT"] = COMMIT_B
    installer_env["FAKE_FAIL_PHASE"] = "model-assets"
    result = _run(installer_env)
    assert result.returncode != 0
    assert _current_commit(installer_env) == COMMIT_A
    assert "active release was not changed" in result.stderr.lower()


def test_model_install_opt_out_is_explicit_base_only(installer_env):
    installer_env["LIVEMORE_INSTALL_MODELS"] = "none"
    result = _run(installer_env)
    assert result.returncode == 0, result.stderr
    assert "base-only" in result.stdout.lower()
    assert "-m livemorebio.model_assets install" not in Path(installer_env["FAKE_INSTALL_LOG"]).read_text(encoding="utf-8")


def test_cardiac_acquisition_precedes_verification_with_technical_tools(installer_env):
    """Technical installer tools stand in for every network operation."""
    result = _run(installer_env)
    assert result.returncode == 0, result.stderr
    log = Path(installer_env["FAKE_INSTALL_LOG"]).read_text(encoding="utf-8")
    assert log.index("-m livemorebio.model_assets install cardiac") < log.index("-m pytest")


def test_unknown_model_install_mode_rejects_before_download(installer_env):
    installer_env["LIVEMORE_INSTALL_MODELS"] = "recon3d"
    result = _run(installer_env)
    assert result.returncode != 0
    assert not (Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "current").exists()


def test_same_commit_base_to_full_requires_execution_tests(installer_env):
    installer_env["LIVEMORE_INSTALL_MODELS"] = "none"
    assert _run(installer_env).returncode == 0
    log = Path(installer_env["FAKE_INSTALL_LOG"])
    log.write_text("", encoding="utf-8")
    installer_env["LIVEMORE_INSTALL_MODELS"] = "human-gem"
    installer_env["FAKE_FAIL_PHASE"] = "pytest"
    result = _run(installer_env)
    assert result.returncode != 0
    assert _current_commit(installer_env) == COMMIT_A
    assert "-I -B -X utf8 -m pytest -p no:cacheprovider -q livemorebio/tests/test_stoichiometry_integration.py" in log.read_text(encoding="utf-8")


def test_failed_update_preserves_current_and_same_commit_retry_succeeds(
    installer_env: dict[str, str],
) -> None:
    assert _run(installer_env).returncode == 0
    installer_env["FAKE_GH_COMMIT"] = COMMIT_B
    installer_env["FAKE_FAIL_PHASE"] = "pytest"

    failed = _run(installer_env)

    assert failed.returncode != 0
    assert "pytest" in failed.stderr.lower()
    assert _current_commit(installer_env) == COMMIT_A
    releases = Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "releases"
    assert not (releases / COMMIT_B).exists()
    assert not list(releases.glob(f".{COMMIT_B}.staging.*"))

    installer_env.pop("FAKE_FAIL_PHASE")
    retried = _run(installer_env)
    assert retried.returncode == 0, retried.stderr
    assert _current_commit(installer_env) == COMMIT_B


def test_incomplete_inactive_release_is_removed_and_rebuilt(
    installer_env: dict[str, str],
) -> None:
    release = (
        Path(installer_env["LIVEMORE_INSTALL_DIR"])
        / "releases"
        / COMMIT_A
    )
    release.mkdir(parents=True)
    (release.parent / ".livemore-installer-owned-v1").write_text(
        "LivemoreBio installer-owned releases directory v1\n",
        encoding="utf-8",
    )
    (release / "partial").write_text("interrupted", encoding="utf-8")

    result = _run(installer_env)

    assert result.returncode == 0, result.stderr
    assert "installer-owned inactive release" in result.stdout
    assert not (release / "partial").exists()
    assert (release / ".livemore-install-complete").is_file()


def test_incomplete_active_release_is_never_deleted_in_place(
    installer_env: dict[str, str],
) -> None:
    assert _run(installer_env).returncode == 0
    install_base = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    release = install_base / "releases" / COMMIT_A
    marker = release / ".livemore-install-complete"
    marker.unlink()
    cli = release / "source" / ".venv" / "bin" / "livemore"

    result = _run(installer_env)

    assert result.returncode != 0
    assert "refusing to delete it in place" in result.stderr.lower()
    assert cli.is_file()
    assert _current_commit(installer_env) == COMMIT_A


def test_tampered_active_release_is_refused_without_deletion(
    installer_env: dict[str, str],
) -> None:
    assert _run(installer_env).returncode == 0
    install_base = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    release = install_base / "releases" / COMMIT_A
    source_file = release / "source" / "livemorebio" / "__init__.py"
    source_file.write_text("tampered = True\n", encoding="utf-8")

    result = _run(installer_env)

    assert result.returncode != 0
    assert "integrity verification failed" in result.stderr.lower()
    assert source_file.read_text(encoding="utf-8") == "tampered = True\n"
    assert _current_commit(installer_env) == COMMIT_A


def test_injected_sourceless_bytecode_invalidates_active_release(
    installer_env: dict[str, str],
) -> None:
    assert _run(installer_env).returncode == 0
    install_base = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    release = install_base / "releases" / COMMIT_A
    sitecustomize = (
        release
        / "source"
        / ".venv"
        / "lib"
        / "python3.11"
        / "site-packages"
        / "sitecustomize.pyc"
    )
    sitecustomize.parent.mkdir(parents=True, exist_ok=True)
    sitecustomize.write_bytes(b"executable-bytecode-payload")

    result = _run(installer_env)

    assert result.returncode != 0
    assert "integrity verification failed" in result.stderr.lower()
    assert sitecustomize.read_bytes() == b"executable-bytecode-payload"
    assert _current_commit(installer_env) == COMMIT_A


def test_live_installer_lock_is_rejected(installer_env: dict[str, str]) -> None:
    lock = Path(installer_env["LIVEMORE_INSTALL_DIR"]) / ".install.lock"
    lock.mkdir(parents=True)
    (lock / "pid").write_text(str(os.getpid()), encoding="utf-8")

    result = _run(installer_env)

    assert result.returncode != 0
    assert "already running" in result.stderr.lower()


def test_symlinked_installer_lock_is_rejected_without_touching_target(
    installer_env: dict[str, str], tmp_path: Path
) -> None:
    install_base = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    install_base.mkdir(parents=True)
    sentinel_directory = tmp_path / "lock-sentinel"
    sentinel_directory.mkdir()
    sentinel = sentinel_directory / "pid"
    sentinel.write_text("sentinel", encoding="utf-8")
    (install_base / ".install.lock").symlink_to(
        sentinel_directory, target_is_directory=True
    )

    result = _run(installer_env)

    assert result.returncode != 0
    assert "lock cannot be a symbolic link" in result.stderr.lower()
    assert sentinel.read_text(encoding="utf-8") == "sentinel"


def test_missing_github_authorization_fails_before_staging(
    installer_env: dict[str, str],
) -> None:
    installer_env["FAKE_GH_AUTH"] = "missing"

    result = _run(installer_env)

    assert result.returncode != 0
    assert "gh auth login" in result.stderr
    assert not (Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "releases").exists()


def test_empty_source_archive_never_activates(installer_env: dict[str, str]) -> None:
    Path(installer_env["FAKE_GH_ARCHIVE"]).write_bytes(b"")

    result = _run(installer_env)

    assert result.returncode != 0
    assert "source archive is empty" in result.stderr.lower()
    install_base = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    assert not (install_base / "current").exists()
    assert not list((install_base / "releases").glob(".*.staging.*"))


@pytest.mark.parametrize(
    "phase",
    [
        "locked-dependencies",
        "project-install",
        "compileall",
        "cli-smoke",
        "installed-cli",
    ],
)
def test_each_install_gate_failure_leaves_no_active_release(
    installer_env: dict[str, str], phase: str
) -> None:
    installer_env["FAKE_FAIL_PHASE"] = phase

    result = _run(installer_env)

    assert result.returncode != 0
    expected_phase = "cli" if phase.endswith("cli") else phase.split("-")[0]
    assert expected_phase in result.stderr.lower()
    install_base = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    assert not (install_base / "current").exists()
    assert not (install_base / "releases" / COMMIT_A).exists()


@pytest.mark.parametrize("version", ["3.10", "3.12", "4.0"])
def test_unsupported_python_fails_before_staging(
    installer_env: dict[str, str], version: str
) -> None:
    installer_env["FAKE_PYTHON_VERSION"] = version

    result = _run(installer_env)

    assert result.returncode != 0
    assert "python 3.11" in result.stderr.lower()
    assert not (Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "releases").exists()


@pytest.mark.parametrize("unsafe_ref", ["--help", "../main", "main?x=1"])
def test_unsafe_ref_is_rejected(
    installer_env: dict[str, str], unsafe_ref: str
) -> None:
    installer_env["LIVEMORE_REF"] = unsafe_ref

    result = _run(installer_env)

    assert result.returncode != 0
    assert "ref" in result.stderr.lower()


def test_an_empty_ref_selects_the_published_release_rather_than_failing(
    installer_env: dict[str, str]
) -> None:
    """An unset or empty LIVEMORE_REF is how a client installs: it asks for the
    published channel, which needs no GitHub account. It must not be treated as
    a malformed ref, and it must never reach the repository path."""
    installer_env["LIVEMORE_REF"] = ""
    installer_env["LIVEMORE_DIST_BASE"] = "https://dist.invalid/livemorebio"

    result = _run(installer_env)

    assert result.returncode != 0
    output = (result.stderr + result.stdout).lower()
    assert "published" in output and "dist.invalid" in output
    assert not (Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "releases").exists()


def test_conflicting_command_is_never_overwritten(installer_env: dict[str, str]) -> None:
    command = Path(installer_env["LIVEMORE_BIN_DIR"]) / "livemore"
    command.parent.mkdir(parents=True)
    command.write_text("user-owned", encoding="utf-8")

    result = _run(installer_env)

    assert result.returncode != 0
    assert "existing" in result.stderr.lower()
    assert command.read_text(encoding="utf-8") == "user-owned"


def test_unmanaged_launcher_is_never_overwritten(installer_env: dict[str, str]) -> None:
    launcher = (
        Path(installer_env["LIVEMORE_INSTALL_DIR"])
        / "launcher"
        / "livemore"
    )
    launcher.parent.mkdir(parents=True)
    launcher.write_text("user-owned", encoding="utf-8")

    result = _run(installer_env)

    assert result.returncode != 0
    assert "launcher is not managed" in result.stderr.lower()
    assert launcher.read_text(encoding="utf-8") == "user-owned"


def test_symlinked_install_root_is_rejected(
    installer_env: dict[str, str], tmp_path: Path
) -> None:
    real = tmp_path / "real-install"
    real.mkdir()
    install_link = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    install_link.symlink_to(real, target_is_directory=True)

    result = _run(installer_env)

    assert result.returncode != 0
    assert "symbolic link" in result.stderr.lower()


def test_symlinked_releases_directory_is_rejected_without_touching_target(
    installer_env: dict[str, str], tmp_path: Path
) -> None:
    install_base = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    install_base.mkdir(parents=True)
    sentinel_directory = tmp_path / "release-sentinel"
    sentinel_directory.mkdir()
    sentinel = sentinel_directory / COMMIT_A
    sentinel.mkdir()
    (sentinel / "keep").write_text("sentinel", encoding="utf-8")
    (install_base / "releases").symlink_to(
        sentinel_directory, target_is_directory=True
    )

    result = _run(installer_env)

    assert result.returncode != 0
    assert "releases directory cannot be a symbolic link" in result.stderr.lower()
    assert (sentinel / "keep").read_text(encoding="utf-8") == "sentinel"


@pytest.mark.parametrize(
    ("variable", "suffix"),
    [
        ("LIVEMORE_INSTALL_DIR", "/../unsafe-install"),
        ("LIVEMORE_BIN_DIR", "/./unsafe-bin"),
        ("LIVEMORE_INSTALL_DIR", "/"),
    ],
)
def test_non_normalized_managed_paths_are_rejected(
    installer_env: dict[str, str], variable: str, suffix: str
) -> None:
    installer_env[variable] += suffix

    result = _run(installer_env)

    assert result.returncode != 0
    assert "normalized absolute path" in result.stderr.lower()


def test_unmanaged_current_link_is_never_replaced(
    installer_env: dict[str, str], tmp_path: Path
) -> None:
    install_base = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    install_base.mkdir(parents=True)
    unrelated = tmp_path / "unrelated-release"
    unrelated.mkdir()
    current = install_base / "current"
    current.symlink_to(unrelated, target_is_directory=True)

    result = _run(installer_env)

    assert result.returncode != 0
    assert "not managed" in result.stderr.lower()
    assert current.resolve() == unrelated.resolve()


def test_existing_path_block_for_another_bin_directory_fails_closed(
    installer_env: dict[str, str]
) -> None:
    zshrc = Path(installer_env["HOME"]) / ".zshrc"
    zshrc.write_text(
        "# >>> LivemoreBio PATH >>>\n"
        'export PATH="$HOME/another-bin:$PATH"\n'
        "# <<< LivemoreBio PATH <<<\n",
        encoding="utf-8",
    )

    result = _run(installer_env)

    assert result.returncode != 0
    assert "different command directory" in result.stderr.lower()
    assert not (Path(installer_env["LIVEMORE_INSTALL_DIR"]) / "current").exists()


def test_bash_uses_bashrc_for_normal_linux_terminal(
    installer_env: dict[str, str],
) -> None:
    installer_env["SHELL"] = "/bin/bash"

    result = _run(installer_env)

    assert result.returncode == 0, result.stderr
    bashrc = Path(installer_env["HOME"]) / ".bashrc"
    assert "LivemoreBio PATH" in bashrc.read_text(encoding="utf-8")
    assert not (Path(installer_env["HOME"]) / ".bash_profile").exists()


def test_unknown_shell_does_not_edit_a_profile(installer_env: dict[str, str]) -> None:
    installer_env["SHELL"] = "/bin/fish"

    result = _run(installer_env)

    assert result.returncode == 0, result.stderr
    home = Path(installer_env["HOME"])
    assert not list(home.glob(".*rc"))
    assert "add this directory to path" in result.stdout.lower()
    assert installer_env["LIVEMORE_BIN_DIR"] in result.stdout


def test_symlinked_shell_profile_is_not_edited(
    installer_env: dict[str, str], tmp_path: Path
) -> None:
    sentinel = tmp_path / "profile-sentinel"
    sentinel.write_text("user-owned\n", encoding="utf-8")
    (Path(installer_env["HOME"]) / ".zshrc").symlink_to(sentinel)

    result = _run(installer_env)

    assert result.returncode == 0, result.stderr
    assert sentinel.read_text(encoding="utf-8") == "user-owned\n"
    assert "did not edit symlinked profile" in result.stdout.lower()


def test_dependency_download_recovers_from_a_slow_mirror(installer_env, tmp_path):
    """A stall part-way through a large wheel must not discard the install.

    pip's own --retries covers a failed connection, not a body that stops
    arriving, which is how three client-shaped installs failed here.
    """
    installer_env["FAKE_TRANSIENT_PHASE"] = "locked-dependencies"
    installer_env["FAKE_TRANSIENT_FAILURES"] = "2"
    installer_env["FAKE_TRANSIENT_COUNT_FILE"] = str(tmp_path / "transient-count")
    installer_env["LIVEMORE_RETRY_BACKOFF_SECONDS"] = "0"

    result = _run(installer_env)

    assert result.returncode == 0, result.stderr
    assert Path(installer_env["FAKE_TRANSIENT_COUNT_FILE"]).read_text(encoding="utf-8") == "2"
    assert _current_commit(installer_env) == COMMIT_A
    log = Path(installer_env["FAKE_INSTALL_LOG"]).read_text(encoding="utf-8")
    assert log.count("--require-hashes") == 3, "two failures then one success"


def test_dependency_download_gives_up_rather_than_retrying_forever(installer_env, tmp_path):
    """A network that never recovers must end, and must not activate anything."""
    installer_env["FAKE_FAIL_PHASE"] = "locked-dependencies"
    installer_env["LIVEMORE_RETRY_BACKOFF_SECONDS"] = "0"

    result = _run(installer_env)

    assert result.returncode != 0
    output = result.stderr + result.stdout
    assert "Dependency download failed after" in output
    install_base = Path(installer_env["LIVEMORE_INSTALL_DIR"])
    assert not (install_base / "current").exists()
