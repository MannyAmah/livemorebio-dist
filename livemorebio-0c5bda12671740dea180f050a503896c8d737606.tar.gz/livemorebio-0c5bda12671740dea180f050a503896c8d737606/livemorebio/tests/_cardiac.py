"""L0-R2: pinned cardiac integration, following the installed Human-GEM convention."""
from __future__ import annotations

import os
from pathlib import Path

import pytest


CARDIAC_OPT_IN = "LIVEMORE_TEST_CARDIAC"
BASE_ONLY_REASON = "explicit pinned cardiac asset opt-in; base-only run"


def require_pinned_cardiac_asset() -> Path:
    """Never acquire model bytes; an opted-in missing or corrupt asset fails."""
    mode = os.environ.get(CARDIAC_OPT_IN)
    if mode not in (None, "0", "1"):
        pytest.fail("LIVEMORE_TEST_CARDIAC must be 0 or 1.", pytrace=False)
    if mode != "1":
        pytest.skip(BASE_ONLY_REASON)
    from livemorebio.model_assets import ModelAssetError, verified_cardiac_path

    try:
        return verified_cardiac_path()
    except ModelAssetError as error:
        code = error.code
    pytest.fail(f"Pinned cardiac integration failed [{code}].", pytrace=False)
