"""Real encrypted selection/recovery wiring; authored data, no physiology."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from copy import deepcopy
import base64
import sqlite3
from threading import Event
from types import SimpleNamespace
from uuid import UUID

import pytest

from livemorebio.tests.clinical_registry_fixtures import KEY, replace_fixture_record
from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401
from livemorebio.tests.test_committed_registry_transitions import rows, seed
from livemorebio.tests.test_checked_startup_registry_integration import audit_rows, reservations
from livemorebio.tests.test_checked_binding_registry_integration import decode_audit
from livemorebio.tests.test_observation_committed_registry import assert_selected, install_mutation_fault
from livemorebio.strict_json import MAX_SAFE_INTEGER
from ._timing import wait_seconds


def forbidden(*args, **kwargs):
    pytest.fail("Observation integration attempted model or execution-store work")


@pytest.fixture
def integration(client, tmp_path, monkeypatch):
    from livemorebio import bus
    from livemorebio.aegle import clinical_views, execution_api, server
    from livemorebio.aegle.execution import DENY_ALL, ExecutionManager
    from livemorebio.aegle.model_contexts import model_availability
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.aegle.observation_state import ObservationState
    from livemorebio.aegle.registry_audit import RegistryAudit
    from livemorebio.aegle.subjects import SubjectRegistry

    path = tmp_path / "authored-observation-integration.sqlite3"
    monkeypatch.setenv("LIVEMORE_SUBJECT_REGISTRY", str(path))
    monkeypatch.setenv("LIVEMORE_PATCH_STORAGE_KEY", base64.urlsafe_b64encode(KEY).decode("ascii"))
    monkeypatch.setattr(server, "_subject_registry_instance", None)
    monkeypatch.setattr(server, "_subject_registry_path", None)
    registry = server._subject_registry()
    assert type(registry) is SubjectRegistry and registry.path == path and registry.key == KEY
    authority = ModelSourceAuthority(server._invalidate_model_source,
        fence=server._assign_model_fence, fence_guard=server._model_fence_guard)
    generation = authority.generation
    store = SimpleNamespace(**{name: forbidden for name in
        ("get", "create", "update", "acquire_owner", "release_owner")})
    manager = ExecutionManager(store, adapter_registry={}, run_background=False,
                               permitted_generation=generation)
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_execution_manager_instance", manager)
    observed = ObservationState()
    observed.observations = {"technical": {"value": "authored-prior", "measured_at": None}}
    observed.patch["envelope_id"] = "authored-prior-envelope"
    old_twin = SimpleNamespace(state=forbidden, patch=deepcopy(observed.patch),
                               observations=deepcopy(observed.observations))
    actions = [{"kind": "AUTHORED_PRIOR_ACTION"}]
    initial = {"tw": old_twin, "subject": None, "initialized": True, "observation_state": observed}
    monkeypatch.setattr(server, "_state", initial)
    monkeypatch.setattr(server, "_workspace_actions", actions)
    t = SimpleNamespace(server=server, client=client, registry=registry, authority=authority,
        manager=manager, generation=generation, initial=initial, observed=observed,
        actions=actions, kind="select", current=None, target=None, allow_healthy=False,
        baseline_rows=None, baseline_audit=[], original=None, constructors=[], state_calls=[],
        projections=[], snapshots=[], publications=[], after_projection=None, fault=None,
        damaged={}, changed_rows=None)

    def unlocked():
        assert not authority._lock._is_owned() and not manager._lock._is_owned()
        assert not execution_api._creation_lock._is_owned() and not server._initialization_lock._is_owned()

    def ledger(request_id=None):
        raw = audit_rows(registry)
        assert raw[:len(t.baseline_audit)] == t.baseline_audit
        result = []
        for row in raw[len(t.baseline_audit):]:
            if row[0] in t.damaged:
                saved = t.damaged[row[0]]
                assert row == saved["after"]
                event, identifier = None, saved["request_id"]
            else:
                event = decode_audit(row)
                identifier = event["request_id"]
            if request_id is None or identifier == request_id:
                result.append((row, event))
        return result

    def assert_audit(outcomes, request_id=None, *, pending=False, kind=None):
        actual = ledger(request_id)
        assert len(actual) == len(outcomes)
        if request_id is None:
            request_id = actual[0][1]["request_id"]
        assert str(UUID(request_id)) == request_id
        first_action = actual[0][1]["action"]
        kind = kind or ("reconcile" if first_action == "reconcile_selection" else "select")
        expected_actions = (["reconcile_selection"] * len(actual) if kind == "reconcile"
                            else ["inspect"] * 2 + ["select_observations"] * max(0, len(actual) - 2))
        for (raw, event), outcome, action in zip(actual, outcomes, expected_actions):
            if outcome == "DAMAGED":
                assert event is None and raw == t.damaged[raw[0]]["after"]
                continue
            assert event["outcome_code"] == outcome and event["action"] == action
            assert event["request_id"] == request_id
            assert event["opaque_record_id"] == (None if kind == "reconcile" else t.target["twin_id"])
            assert event["schema"] == "livemore.subject-access-audit.v1"
            assert event["local_store_id"] == registry.audit.store_id
            assert set(event) == {"schema", "request_id", "action", "opaque_record_id", "started_at",
                "completed_at", "outcome_code", "local_store_id", "local_process_instance", "source_sha256"}
        assert len({raw[0] for raw, _ in actual}) == len(actual)
        current_pending = [row for row in reservations(registry) if row[1] == request_id]
        assert current_pending == ([(actual[-1][0][0], request_id)] if pending else [])
        return request_id

    def configure(*, kind="select", same=False, absent=False, version=2):
        t.kind, t.allow_healthy = kind, kind == "reconcile" and absent
        seed(registry, "observation-unrelated", version=7)
        t.current = None if absent else seed(registry, "observation-selected", active=True,
                                             human=kind == "reconcile" or same, version=version)
        t.target = t.current if same or kind == "reconcile" else seed(registry, "observation-target", human=True)
        initial.update(tw=None if kind == "reconcile" or same else old_twin,
            subject=server._subject_summary(t.current) if t.current else None,
            model_availability=model_availability(t.current, source_generation=generation))
        if kind == "reconcile":
            with authority.commit_guard():
                authority.install_generation(DENY_ALL)
        t.original = {"tw": initial["tw"], "subject": deepcopy(initial["subject"]),
            "availability": deepcopy(initial["model_availability"]),
            "patch": deepcopy(observed.patch), "observations": deepcopy(observed.observations)}
        t.baseline_rows, t.baseline_audit = rows(registry), audit_rows(registry)
        assert reservations(registry) == []
        manager._wake.clear()

    def projection_checkpoint():
        unlocked()
        request_id = ledger()[-1][1]["request_id"]
        assert_audit([None, "SUCCESS"], request_id)
        # This witnesses released writer ownership, not observation of close().
        with closing(sqlite3.connect(path, timeout=0.2)) as check:
            check.execute("BEGIN IMMEDIATE")
            check.rollback()
        return request_id

    original_projection = clinical_views.unavailable_state
    def modeless_projection(availability, holder):
        result = original_projection(availability, holder)
        request_id = projection_checkpoint()
        t.projections.append(request_id)
        if t.after_projection is not None:
            t.after_projection(request_id)
        return result

    def candidate_state():
        request_id = projection_checkpoint()
        assert t.allow_healthy and t.current is None
        t.state_calls.append(request_id)
        return {"profile": "AUTHORED_HEALTHY_REFERENCE", "profile_params": {"technical": "inert-only"},
                "observations": {}, "applied": []}
    candidate = SimpleNamespace(state=candidate_state)
    t.candidate = candidate

    def healthy(*args, **kwargs):
        request_id = projection_checkpoint()
        assert t.allow_healthy and t.current is None and args == ("healthy",) and kwargs == {}
        t.constructors.append(request_id)
        return candidate

    def set_snapshot(key, value):
        unlocked()
        assert key == "twin"
        request_id = ledger()[-1][1]["request_id"]
        assert_audit([None, "SUCCESS", None, "SUCCESS"], request_id)
        state = server._state
        assert state is not initial and state["initialized"] is True
        assert state["observation_state"] is not observed and state["observation_state"].observations == {}
        assert server._workspace_actions == [] and server._workspace_actions is not actions
        assert authority.generation == manager._permitted_generation != generation
        assert value["model_availability"] == state["model_availability"]
        assert value["profile_params"] == ({"technical": "inert-only"} if t.allow_healthy else None)
        assert state["tw"] is (candidate if t.allow_healthy else None)
        t.snapshots.append((request_id, deepcopy(value)))

    def publish(source, event, payload):
        unlocked()
        assert source == "Aegle" and event == server.events.TWIN_UPDATED
        t.publications.append(deepcopy(payload))

    monkeypatch.setattr(clinical_views, "unavailable_state", modeless_projection)
    monkeypatch.setattr(server, "AegleTwin", healthy)
    monkeypatch.setattr(bus, "set_snapshot", set_snapshot)
    monkeypatch.setattr(bus, "publish", publish)
    protected = {name: getattr(SubjectRegistry, name) for name in (
        "prepare_observation_selection", "_prepare_transition", "commit_prepared_transition",
        "audited_active_twin", "confirm_active_selection", "_checked_selection_access",
        "_validate_checked_selection", "_selection_read_access", "_selection_audit_begin",
        "_selection_audit_reenter", "_selection_audit_finish", "_transition_snapshot",
        "_raw_transition_evidence", "_confirm_transition_witness", "_open", "_seal")}
    audited = {name: getattr(RegistryAudit, name) for name in ("begin", "finish", "check_authority")}
    sourced = {name: getattr(ModelSourceAuthority, name) for name in
               ("observation", "commit_guard", "install_generation")}
    server_names = ("_subject_registry", "select_twin_observations", "reconcile_twin_selection",
                    "_snapshot_twin", "_assign_model_fence", "_model_fence_guard", "_invalidate_model_source")
    server_functions = tuple(getattr(server, name) for name in server_names)
    manager_functions = (manager.set_source_generation.__func__, manager.invalidate_source.__func__)

    def identities():
        for owner, functions in ((registry, protected), (registry.audit, audited), (authority, sourced)):
            for name, function in functions.items():
                bound = getattr(owner, name)
                assert getattr(bound, "__func__", bound) is function
        assert server_functions == tuple(getattr(server, name) for name in server_names)
        assert manager_functions == (manager.set_source_generation.__func__, manager.invalidate_source.__func__)
        if t.fault is None:
            assert registry._connect.__func__ is SubjectRegistry._connect
        assert clinical_views.unavailable_state is modeless_projection

    t.unlocked, t.configure, t.ledger, t.assert_audit = unlocked, configure, ledger, assert_audit
    identities()
    yield t
    identities()
    assert manager._owners == manager._adapters == {} and not manager._closed
    assert len(t.constructors) == len(t.state_calls) == (1 if t.allow_healthy else 0)
    manager.close()
    client.close()


def request(t, *, kind=None):
    kind = kind or t.kind
    if kind == "select":
        response = t.client.post(f"/api/twins/{t.target['twin_id']}/select-observations",
                                 json={"expected_version": t.target["version"]})
    else:
        response = t.client.post("/api/twins/reconcile-selection", json={})
    assert "no-store" in response.headers["Cache-Control"]
    assert str(UUID(response.headers["X-Request-ID"])) == response.headers["X-Request-ID"]
    return response


def original(t, *, denied=False):
    from livemorebio.aegle.execution import DENY_ALL
    assert t.server._state is t.initial and t.server._workspace_actions is t.actions
    assert t.initial["tw"] is t.original["tw"] and t.initial["subject"] == t.original["subject"]
    assert t.initial["model_availability"] == t.original["availability"]
    assert t.initial["observation_state"] is t.observed
    assert t.observed.patch == t.original["patch"] and t.observed.observations == t.original["observations"]
    assert t.actions == [{"kind": "AUTHORED_PRIOR_ACTION"}]
    if denied:
        assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL
    else:
        assert t.authority.generation == t.manager._permitted_generation == t.generation
    assert not t.snapshots and not t.publications


def selected(t, response, *, cleanup=False):
    assert response.status_code == (503 if cleanup else 200)
    state = t.server._state
    assert state["tw"] is None and state["subject"]["twin_id"] == t.target["twin_id"]
    availability = state["model_availability"]
    assert availability["state"] == "UNAVAILABLE" and availability["reason_code"] == "MODEL_BINDING_REQUIRED"
    assert availability["selection_mode"] == "observations_only" and availability["preparation_available"] is False
    assert availability["twin_version"] == t.target["version"] + 1
    request_id = response.headers["X-Request-ID"]
    t.assert_audit([None, "SUCCESS", None, "SUCCESS"], request_id)
    assert len(t.snapshots) == len(t.publications) == 1 and t.snapshots[0][0] == request_id
    snapshot = t.snapshots[0][1]
    assert snapshot["profile_params"] is None and snapshot["observations"] == {}
    assert not snapshot.get("biological_time", {}).get("axes")
    assert snapshot["patch"]["connected"] is False
    if cleanup:
        assert response.json()["code"] == "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
        saved = {row[0]: row for row in rows(t.registry)["records"]}[t.target["twin_id"]]
        timestamp = saved[8]
    else:
        record = response.json()
        assert record["model_availability"] == availability
        timestamp = record["updated_at"]
    expected = assert_selected(t.registry, t.baseline_rows, t.current, t.target, timestamp)
    if not cleanup:
        assert {key: value for key, value in response.json().items() if key != "model_availability"} == expected
    assert t.manager._wake.is_set() and reservations(t.registry) == []
    assert t.observed.observations == t.original["observations"] and t.actions == [{"kind": "AUTHORED_PRIOR_ACTION"}]


def reconciled(t, response):
    assert response.status_code == 200
    body, state = response.json(), t.server._state
    assert set(body) == {"selection_status", "subject", "model_availability", "prior_execution_cleanup"}
    assert body["selection_status"] == "CONFIRMED" and body["prior_execution_cleanup"] == "INSPECT_EXISTING_STATUS"
    assert body["subject"] == (t.server._subject_summary(t.current) if t.current else None)
    assert body["model_availability"] == state["model_availability"]
    assert rows(t.registry) == t.baseline_rows and not t.manager._wake.is_set()
    request_id = response.headers["X-Request-ID"]
    t.assert_audit([None, "SUCCESS", None, "SUCCESS"], request_id, kind="reconcile")
    assert len(t.snapshots) == len(t.publications) == 1 and t.snapshots[0][0] == request_id
    assert t.authority.generation == t.manager._permitted_generation != t.generation
    assert reservations(t.registry) == []
    if t.current is not None:
        assert body["model_availability"]["reason_code"] == "MODEL_BINDING_REQUIRED"
        assert body["model_availability"]["state"] == "UNAVAILABLE" and state["tw"] is None
        assert body["model_availability"]["twin_version"] == t.current["version"]
    else:
        assert state["tw"] is t.candidate and body["model_availability"]["state"] == "READY"
        assert body["model_availability"]["selection_mode"] == "reference_preview"
        assert t.constructors == t.state_calls == [request_id]


def checked_fault(t, monkeypatch, mode):
    original_connect = t.registry._connect
    state = {"mode": mode, "armed": mode == "capture_commit", "request_id": None,
             "faults": 0, "closed": 0, "terminal": None, "persisted": False}
    t.fault = state
    if mode != "capture_commit":
        def arm(request_id):
            t.assert_audit([None, "SUCCESS"], request_id, kind="reconcile")
            state.update(armed=True, request_id=request_id)
        t.after_projection = arm

    class Connection:
        def __init__(self, real): self.real, self.final = real, False
        def __getattr__(self, name): return getattr(self.real, name)
        def commit(self):
            raw = self.real.execute("SELECT * FROM registry_audit ORDER BY sequence DESC LIMIT 1").fetchone()
            event = decode_audit(raw)
            matches = (state["armed"] and state["faults"] == 0 and event["action"] == "reconcile_selection"
                       and event["outcome_code"] == "SUCCESS"
                       and (state["request_id"] is None or state["request_id"] == event["request_id"]))
            if not matches: return self.real.commit()
            state.update(request_id=event["request_id"], terminal=tuple(raw))
            self.final = True
            if mode == "capture_commit":
                state["faults"] += 1
                raise sqlite3.OperationalError("Authored capture terminal commit refused")
            self.real.commit()
            state["persisted"] = True
            if mode == "final_commit":
                state["faults"] += 1
                raise sqlite3.OperationalError("Authored final checked commit ACK lost")
        def close(self):
            self.real.close()
            state["closed"] += 1
            if self.final and mode == "final_close":
                state["faults"] += 1
                raise OSError("Authored final checked close ACK lost")
    monkeypatch.setattr(t.registry, "_connect", lambda: Connection(original_connect()))
    return state


@pytest.mark.parametrize("same", [False, True])
def test_actual_observation_commit_installs_new_modeless_selection(integration, same):
    t = integration
    t.configure(same=same)
    selected(t, request(t))


def test_actual_observation_lost_ack_uses_complete_once_only_witness(integration, monkeypatch):
    t = integration
    t.configure()
    t.fault = install_mutation_fault(t.registry, monkeypatch, mode="lost_ack")
    selected(t, request(t))
    assert t.fault["attempts"] == t.fault["pointer_writes"] == t.fault["witness"] == 1
    assert sorted(t.fault["updates"]) == sorted([t.current["twin_id"], t.target["twin_id"]])


def test_actual_observation_damaged_terminal_is_not_false_rollback(integration, monkeypatch):
    t = integration
    t.configure()
    retained = []
    def damage():
        with closing(sqlite3.connect(t.registry.path)) as connection, connection:
            before = connection.execute("SELECT * FROM registry_audit ORDER BY sequence DESC LIMIT 1").fetchone()
            event = decode_audit(before)
            assert event["action"] == "select_observations" and event["outcome_code"] == "SUCCESS"
            connection.execute("UPDATE registry_audit SET ciphertext=? WHERE event_id=?", (b"authored-damaged-terminal", before[0]))
            after = connection.execute("SELECT * FROM registry_audit WHERE event_id=?", (before[0],)).fetchone()
        t.damaged[before[0]] = {"before": before, "after": after, "request_id": event["request_id"]}
        retained.append((rows(t.registry), audit_rows(t.registry), reservations(t.registry)))
    t.fault = install_mutation_fault(t.registry, monkeypatch, mode="lost_ack", damage=damage)
    response = request(t)
    assert response.status_code == 503 and response.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
    t.assert_audit([None, "SUCCESS", None, "DAMAGED"], response.headers["X-Request-ID"])
    assert len(retained) == 1 and retained[0] == (rows(t.registry), audit_rows(t.registry), reservations(t.registry))
    saved = {row[0]: row for row in rows(t.registry)["records"]}[t.target["twin_id"]]
    assert_selected(t.registry, t.baseline_rows, t.current, t.target, saved[8])
    assert t.fault["attempts"] == t.fault["witness"] == 1 and len(t.fault["updates"]) == 2
    original(t, denied=True)


def test_actual_observation_close_ack_keeps_committed_modeless_source(integration, monkeypatch):
    t = integration
    t.configure()
    t.fault = install_mutation_fault(t.registry, monkeypatch, mode="close")
    selected(t, request(t), cleanup=True)
    assert t.fault["attempts"] == t.fault["pointer_writes"] == 1 and t.fault["witness"] == 0
    assert len(t.fault["updates"]) == 2


def test_actual_observation_target_reseal_conflicts_after_projection(integration):
    t = integration
    t.configure()
    def interfere(_request_id):
        replace_fixture_record(t.registry, {**t.target, "display_label": "Authored same-version later evidence"})
        t.changed_rows = rows(t.registry)
    t.after_projection = interfere
    response = request(t)
    assert response.status_code == 409 and response.json()["code"] == "TWIN_VERSION_CONFLICT"
    assert rows(t.registry) == t.changed_rows != t.baseline_rows and len(t.projections) == 1
    t.assert_audit([None, "SUCCESS", None, "ACCESS_FAILED"], response.headers["X-Request-ID"])
    original(t)


def test_actual_observation_known_rollback_preserves_source_and_failed_audit(integration, monkeypatch):
    t = integration
    t.configure()
    t.fault = install_mutation_fault(t.registry, monkeypatch, mode="rollback")
    response = request(t)
    assert response.status_code == 503 and response.json()["code"] == "REGISTRY_STORAGE_UNAVAILABLE"
    assert rows(t.registry) == t.baseline_rows
    t.assert_audit([None, "SUCCESS", None, "ACCESS_FAILED"], response.headers["X-Request-ID"])
    assert t.fault["attempts"] == t.fault["pointer_writes"] == 1 and t.fault["witness"] == 0
    original(t)


def test_actual_checked_human_at_maximum_recovers_without_any_constructor(integration):
    t = integration
    t.configure(kind="reconcile", version=MAX_SAFE_INTEGER)
    reconciled(t, request(t))
    assert t.constructors == t.state_calls == [] and len(t.projections) == 1


def test_actual_checked_true_absence_uses_only_fixed_healthy_inert_candidate(integration):
    t = integration
    t.configure(kind="reconcile", absent=True)
    reconciled(t, request(t))
    assert len(t.constructors) == len(t.state_calls) == 1 and t.projections == []


def test_actual_checked_orphan_active_row_is_not_absence(integration):
    t = integration
    t.configure(kind="reconcile")
    with closing(sqlite3.connect(t.registry.path)) as connection, connection:
        connection.execute("DELETE FROM registry_state WHERE state_key='active_twin_id'")
    t.changed_rows = rows(t.registry)
    response = request(t)
    assert response.status_code == 503 and response.json()["code"] == "REGISTRY_STORAGE_UNAVAILABLE"
    assert rows(t.registry) == t.changed_rows != t.baseline_rows
    t.assert_audit([None, "ACCESS_FAILED"], response.headers["X-Request-ID"], kind="reconcile")
    assert t.projections == []
    original(t, denied=True)


def test_actual_checked_pointer_clock_change_conflicts_at_confirmation(integration):
    t = integration
    t.configure(kind="reconcile")
    def interfere(_request_id):
        with closing(sqlite3.connect(t.registry.path)) as connection, connection:
            connection.execute("UPDATE registry_state SET updated_at='authored-later-pointer' WHERE state_key='active_twin_id'")
        t.changed_rows = rows(t.registry)
    t.after_projection = interfere
    response = request(t)
    assert response.status_code == 409 and response.json()["code"] == "SELECTION_RECONCILIATION_CONFLICT"
    assert rows(t.registry) == t.changed_rows != t.baseline_rows and len(t.projections) == 1
    t.assert_audit([None, "SUCCESS", None, "ACCESS_FAILED"], response.headers["X-Request-ID"], kind="reconcile")
    assert not t.manager._wake.is_set()
    original(t, denied=True)


@pytest.mark.parametrize("mode", ["final_commit", "final_close"])
def test_actual_checked_final_ack_failure_keeps_denied_inspection(integration, monkeypatch, mode):
    t = integration
    t.configure(kind="reconcile")
    fault = checked_fault(t, monkeypatch, mode)
    response = request(t)
    assert response.status_code == 503 and response.json()["code"] == "REGISTRY_STORAGE_UNAVAILABLE"
    assert fault["request_id"] == response.headers["X-Request-ID"] and fault["faults"] == 1
    assert fault["persisted"] and fault["closed"] == 2
    assert fault["terminal"] in audit_rows(t.registry)
    t.assert_audit([None, "SUCCESS", None, "SUCCESS"], response.headers["X-Request-ID"], kind="reconcile")
    assert rows(t.registry) == t.baseline_rows and len(t.projections) == 1
    assert not t.manager._wake.is_set()
    original(t, denied=True)


def test_actual_three_request_aba_keeps_later_state_and_pending_receipt(integration, monkeypatch):
    from livemorebio.aegle.execution import DENY_ALL
    t = integration
    t.configure(kind="reconcile")
    reached, release = Event(), Event()
    first_id = []
    def pause(request_id):
        if not first_id:
            first_id.append(request_id)
            reached.set()
            assert release.wait(5), "Authored first recovery pause exceeded its bound"
    t.after_projection = pause
    with ThreadPoolExecutor(max_workers=1) as executor:
        first = executor.submit(request, t)
        try:
            assert reached.wait(3), "First recovery did not reach unlocked projection"
            second = request(t)
            reconciled(t, second)
            winner, actions = t.server._state, t.server._workspace_actions
            winner["observation_state"].observations["authored-R2"] = {"data_class": "AUTHORED_TEST_ONLY"}
            actions.append({"kind": "AUTHORED_R2_ACTION"})
            with monkeypatch.context() as patch:
                t.fault = install_mutation_fault(t.registry, patch, mode="unknown_rollback")
                third = request(t, kind="select")
            assert third.status_code == 503 and third.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
            assert t.server._state is winner and t.server._workspace_actions is actions
            assert rows(t.registry) == t.baseline_rows
            assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL
            assert t.fault["attempts"] == t.fault["pointer_writes"] == t.fault["rollbacks_failed"] == 1
            assert t.fault["updates"] == [t.current["twin_id"]] and t.fault["witness"] == 0
            assert t.fault["closes"] == 2
            third_id = third.headers["X-Request-ID"]
            t.assert_audit([None, "SUCCESS", None], third_id, pending=True, kind="select")
            retained = (rows(t.registry), audit_rows(t.registry), reservations(t.registry))
        finally:
            release.set()
        first_response = first.result(timeout=wait_seconds(3))
    assert first_response.status_code == 409
    assert first_response.json()["code"] == "SELECTION_RECONCILIATION_CONFLICT"
    assert first_response.headers["X-Request-ID"] == first_id[0]
    assert len({first_id[0], second.headers["X-Request-ID"], third_id}) == 3
    t.assert_audit([None, "SUCCESS"], first_id[0], kind="reconcile")
    t.assert_audit([None, "SUCCESS", None, "SUCCESS"], second.headers["X-Request-ID"], kind="reconcile")
    assert retained == (rows(t.registry), audit_rows(t.registry), reservations(t.registry))
    assert t.server._state is winner and t.server._workspace_actions is actions
    assert winner["observation_state"].observations["authored-R2"] == {"data_class": "AUTHORED_TEST_ONLY"}
    assert actions == [{"kind": "AUTHORED_R2_ACTION"}]
    assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL
    assert len(t.snapshots) == len(t.publications) == 1
    assert t.snapshots[0][0] == second.headers["X-Request-ID"]


def test_actual_checked_capture_terminal_failure_never_reaches_projection(integration, monkeypatch):
    t = integration
    t.configure(kind="reconcile")
    fault = checked_fault(t, monkeypatch, "capture_commit")
    response = request(t)
    assert response.status_code == 503 and response.json()["code"] == "REGISTRY_STORAGE_UNAVAILABLE"
    assert fault["request_id"] == response.headers["X-Request-ID"] and fault["faults"] == 1
    assert fault["persisted"] is False and fault["closed"] == 1
    t.assert_audit([None, "ACCESS_FAILED"], response.headers["X-Request-ID"], kind="reconcile")
    assert rows(t.registry) == t.baseline_rows and t.projections == []
    assert not t.manager._wake.is_set()
    original(t, denied=True)
