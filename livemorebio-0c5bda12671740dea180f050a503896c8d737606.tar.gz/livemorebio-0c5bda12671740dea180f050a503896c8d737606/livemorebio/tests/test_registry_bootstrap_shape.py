"""Malformed metadata in authored private stores, never operational registries."""
from __future__ import annotations

from contextlib import closing
import socket
import sqlite3
from uuid import uuid4

import pytest

from livemorebio.aegle.registry_bootstrap import RegistryBootstrap, RegistryBootstrapError
from livemorebio.aegle.subjects import SubjectRegistry
from livemorebio.tests.test_registry_bootstrap_contract import (
    KEY, audit_bytes, old_store, raw_records,
)

SINGLETONS = (
    "registry_bootstrap_identity", "registry_data_key_proof",
    "registry_bootstrap_proof_binding",
)
GRAPH_TABLES = SINGLETONS + ("registry_bootstrap_events", "registry_bootstrap_attempts")


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def forbidden(*args, **kwargs):
        pytest.fail("Bootstrap shape test attempted network access")
    monkeypatch.setattr(socket, "create_connection", forbidden)
    monkeypatch.setattr(socket, "getaddrinfo", forbidden)
    monkeypatch.setattr(socket.socket, "connect", forbidden)
    monkeypatch.setattr(socket.socket, "connect_ex", forbidden)


def snapshot(path):
    with sqlite3.connect(path) as connection:
        graph = tuple(connection.execute(f"SELECT * FROM {table} ORDER BY rowid").fetchall()
                      for table in GRAPH_TABLES)
    return raw_records(path), audit_bytes(path), graph, path.with_name(path.name + ".bootstrap-key").read_bytes()


def prepared(tmp_path):
    path = old_store(tmp_path)
    registry = SubjectRegistry(path, key=KEY)
    registry.get_twin("twin-fixture-one")
    return path, registry


def remove_markers(path, retained):
    with sqlite3.connect(path) as connection:
        for table in SINGLETONS:
            connection.execute(f"DELETE FROM {table}")
        if retained != "both":
            removed = "registry_bootstrap_attempts" if retained == "events" else "registry_bootstrap_events"
            connection.execute(f"DELETE FROM {removed}")


def deny_before_access(path, registry, entry, monkeypatch):
    before = snapshot(path)
    def forbidden(*args, **kwargs):
        pytest.fail("Malformed bootstrap shape reached clinical decrypt or legacy authority")
    monkeypatch.setattr(SubjectRegistry, "_open", forbidden)
    monkeypatch.setattr(registry.audit, "verify_existing", forbidden)
    monkeypatch.setattr(RegistryBootstrap, "_key", forbidden)
    with pytest.raises(RegistryBootstrapError) as caught:
        if entry == "reopen":
            SubjectRegistry(path, key=KEY)
        elif entry == "access":
            registry.get_twin("twin-fixture-one")
        else:
            with closing(registry._connect()) as connection:
                try:
                    getattr(registry.bootstrap, entry)(connection)
                finally:
                    connection.rollback()
    assert caught.value.code == "REGISTRY_BOOTSTRAP_INVALID"
    assert snapshot(path) == before


@pytest.mark.parametrize("retained", ["both", "events", "attempts"])
@pytest.mark.parametrize("entry", ["reopen", "access", "ensure_identity", "_ledger"])
def test_orphan_history_cannot_become_legacy_authority(tmp_path, monkeypatch, retained, entry):
    path, registry = prepared(tmp_path)
    remove_markers(path, retained)
    deny_before_access(path, registry, entry, monkeypatch)


@pytest.mark.parametrize("table", SINGLETONS)
@pytest.mark.parametrize("shape", ["duplicate", "misplaced"])
@pytest.mark.parametrize("entry", ["reopen", "access", "ensure_identity", "_ledger"])
def test_all_singleton_rows_are_checked(tmp_path, monkeypatch, table, shape, entry):
    path, registry = prepared(tmp_path)
    with sqlite3.connect(path) as connection:
        connection.execute("PRAGMA ignore_check_constraints=ON")
        if shape == "misplaced":
            connection.execute(f"UPDATE {table} SET singleton=2")
        else:
            values = list(connection.execute(f"SELECT * FROM {table}").fetchone())
            values[0], values[1] = 2, str(uuid4())
            if table == "registry_bootstrap_proof_binding":
                values[2] = str(uuid4())
            marks = ",".join("?" for _ in values)
            connection.execute(f"INSERT INTO {table} VALUES({marks})", values)
    deny_before_access(path, registry, entry, monkeypatch)


@pytest.mark.parametrize("retained", ["events", "attempts", "neither"])
@pytest.mark.parametrize("entry", ["ensure_identity", "_ledger"])
def test_marked_shape_requires_both_event_and_attempt_history(tmp_path, monkeypatch, retained, entry):
    path, registry = prepared(tmp_path)
    with sqlite3.connect(path) as connection:
        if retained != "events":
            connection.execute("DELETE FROM registry_bootstrap_events")
        if retained != "attempts":
            connection.execute("DELETE FROM registry_bootstrap_attempts")
    deny_before_access(path, registry, entry, monkeypatch)


def test_shape_is_rechecked_after_committed_normal_begin(tmp_path, monkeypatch):
    path, registry = prepared(tmp_path)
    original = registry._connect
    retained = []
    class TamperAfterBegin:
        def __init__(self, connection):
            self.connection, self.first = connection, True
        def __getattr__(self, name):
            return getattr(self.connection, name)
        def commit(self):
            self.connection.commit()
            if self.first:
                self.first = False
                remove_markers(path, "both")
                retained.append(snapshot(path))
    monkeypatch.setattr(registry, "_connect", lambda: TamperAfterBegin(original()))
    monkeypatch.setattr(registry, "_open", lambda *a: pytest.fail("Clinical access after malformed graph"))
    with pytest.raises(RegistryBootstrapError) as caught:
        registry.get_twin("twin-fixture-one")
    assert caught.value.code == "REGISTRY_BOOTSTRAP_INVALID"
    assert len(retained) == 1 and snapshot(path) == retained[0]
    assert len(audit_bytes(path)[1]) == 1  # Genuine BEGIN remains unresolved.


def test_finish_rechecks_shape_before_appending_terminal(tmp_path):
    path, registry = prepared(tmp_path)
    with closing(registry._connect()) as connection:
        reservation = registry.bootstrap.begin(connection, action="INITIALIZE")
        connection.commit()
        connection.execute("PRAGMA ignore_check_constraints=ON")
        connection.execute("UPDATE registry_bootstrap_identity SET singleton=2")
        connection.commit()
        before = snapshot(path)
        with pytest.raises(RegistryBootstrapError) as caught:
            registry.bootstrap.finish(connection, reservation, outcome_code="INTERRUPTED_OUTCOME_UNKNOWN")
        connection.rollback()
    assert caught.value.code == "REGISTRY_BOOTSTRAP_INVALID"
    assert snapshot(path) == before


@pytest.mark.parametrize("event_count,attempt_count,pending_count,valid_shape", [
    (512, 256, 0, True), (513, 256, 0, False),
    (257, 256, 255, True), (258, 256, 255, False), (258, 257, 256, False),
])
def test_metadata_bounds_are_checked_without_decrypting(
    tmp_path, monkeypatch, event_count, attempt_count, pending_count, valid_shape,
):
    path, registry = prepared(tmp_path)
    with sqlite3.connect(path) as connection:
        connection.execute("DELETE FROM registry_bootstrap_attempts")
        connection.execute("DELETE FROM registry_bootstrap_events")
        for index in range(event_count):
            connection.execute("INSERT INTO registry_bootstrap_events VALUES(?,?,?,?)",
                               (str(uuid4()), index + 1, b"n" * 12, b"technical-not-ciphertext"))
        for index in range(attempt_count):
            connection.execute("INSERT INTO registry_bootstrap_attempts VALUES(?,?,?)",
                               (str(uuid4()), str(uuid4()), None if index < pending_count else str(uuid4())))
    before = snapshot(path)
    monkeypatch.setattr(RegistryBootstrap, "_key", lambda *a, **k: pytest.fail("Shape inspected a key"))
    with closing(registry._connect()) as connection:
        if valid_shape:
            # Only cardinality is admissible here; these deliberately unauthentic
            # envelopes must never be used as authority or a scientific fixture.
            assert registry.bootstrap._preflight_shape(connection) is None
        else:
            with pytest.raises(RegistryBootstrapError) as caught:
                registry.bootstrap._preflight_shape(connection)
            assert caught.value.code == "REGISTRY_BOOTSTRAP_INVALID"
        connection.rollback()
    assert snapshot(path) == before


def test_shape_storage_failure_uses_fixed_error(tmp_path):
    path, registry = prepared(tmp_path)
    before = snapshot(path)
    with closing(registry._connect()) as connection:
        class FailedShapeRead:
            def __getattr__(self, name):
                return getattr(connection, name)
            def execute(self, query, *args):
                if query.startswith("SELECT singleton"):
                    raise sqlite3.OperationalError("authored inaccessible metadata sentinel")
                return connection.execute(query, *args)
        with pytest.raises(RegistryBootstrapError) as caught:
            registry.bootstrap._preflight_shape(FailedShapeRead())
        connection.rollback()
    assert caught.value.code == "REGISTRY_BOOTSTRAP_INVALID"
    assert "sentinel" not in str(caught.value)
    assert snapshot(path) == before
