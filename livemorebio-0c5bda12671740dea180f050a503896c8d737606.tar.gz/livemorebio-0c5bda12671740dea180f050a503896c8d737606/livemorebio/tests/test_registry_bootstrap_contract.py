"""Direct old-schema software fixtures; never operational or clinical evidence."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
import importlib
import json
import os
from pathlib import Path
import sqlite3
from threading import Barrier
import multiprocessing
from uuid import uuid4

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import pytest

from livemorebio.aegle.subjects import SubjectRegistry
from livemorebio.tests.clinical_registry_fixtures import (
    KEY, canonical, legacy_cohort_record, legacy_twin_record, replace_fixture_record,
)
from ._timing import wait_seconds

WRONG = b"x" * 32  # Public authored-test key, deliberately incorrect.
BOOT = b"b" * 32  # Independent public fixture key; not a real secret.
PROCESS = "20000000-0000-4000-8000-000000000002"
STORE = "10000000-0000-4000-8000-000000000001"
SOURCE = "a" * 64
AAD = b"livemore.aegle.subject-registry.v1"


def old_store(tmp_path, records=None):
    """Do not invoke any registry constructor before the first candidate key."""
    path = tmp_path / "technical.sqlite3"
    descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
    os.close(descriptor)
    with sqlite3.connect(path) as connection:
        connection.execute("CREATE TABLE records(record_id TEXT PRIMARY KEY,record_type TEXT NOT NULL,source_class TEXT NOT NULL,lifecycle TEXT NOT NULL,version INTEGER NOT NULL,idempotency_key TEXT UNIQUE,request_hash TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,nonce BLOB NOT NULL,ciphertext BLOB NOT NULL)")
        for index, record in enumerate(records if records is not None else [legacy_twin_record()]):
            kind = "TWIN" if "twin_id" in record else "COHORT"
            identity = record.get("twin_id", record.get("cohort_id"))
            nonce = (index + 1).to_bytes(12, "big")
            encrypted = AESGCM(KEY).encrypt(nonce, canonical(record), AAD + identity.encode())
            connection.execute("INSERT INTO records VALUES(?,?,?,?,?,?,?,?,?,?,?)", (identity, kind, record["source_class"], record["lifecycle"], record["version"], None, "f" * 64, record["created_at"], record["updated_at"], nonce, encrypted))
    return path


def raw_records(path):
    with sqlite3.connect(path) as connection:
        return connection.execute("SELECT * FROM records ORDER BY record_id").fetchall()


def events(path):
    key = path.with_name(path.name + ".bootstrap-key").read_bytes()
    with sqlite3.connect(path) as connection:
        rows = connection.execute("SELECT event_id,sequence,nonce,ciphertext FROM registry_bootstrap_events ORDER BY sequence").fetchall()
    return [json.loads(AESGCM(key).decrypt(row[2], row[3], b"livemore.subject-registry.bootstrap.v1\0" + row[0].encode())) for row in rows]


def scalar(path, query):
    with sqlite3.connect(path) as connection:
        return connection.execute(query).fetchone()[0]


def test_wrong_first_key_then_correct_does_not_poison_or_rewrite_old_records(tmp_path):
    path = old_store(tmp_path)
    old = raw_records(path)
    with pytest.raises(Exception):
        SubjectRegistry(path, key=WRONG)
    registry = SubjectRegistry(path, key=KEY)
    assert registry.get_twin("twin-fixture-one")["subject_id"] == "pseudonym-technical-one"
    assert raw_records(path) == old
    recorded = events(path)
    assert [event["outcome_code"] for event in recorded] == [None, "KEY_OR_RECORD_UNVERIFIABLE", None, "SUCCESS"]
    assert len({event["request_id"] for event in recorded}) == 2
    assert scalar(path, "SELECT COUNT(*) FROM registry_data_key_proof") == 1
    assert scalar(path, "SELECT COUNT(*) FROM registry_bootstrap_attempts WHERE result_event_id IS NULL") == 0


def test_each_first_clinical_decrypt_follows_this_bootstraps_durable_begin(tmp_path, monkeypatch):
    path = old_store(tmp_path)
    original = SubjectRegistry._open
    checked = []
    def spy(self, row):
        pending = [event for event in events(path) if event["event_type"] == "BEGIN"]
        assert len(pending) == 1
        assert pending[0]["action"] == "INITIALIZE"
        assert scalar(path, "SELECT COUNT(*) FROM registry_bootstrap_attempts WHERE result_event_id IS NULL") == 1
        assert scalar(path, "SELECT COUNT(*) FROM registry_audit") == 0
        checked.append(pending[0]["request_id"])
        return original(self, row)
    monkeypatch.setattr(SubjectRegistry, "_open", spy)
    SubjectRegistry(path, key=KEY)
    assert checked and len(set(checked)) == 1


@pytest.mark.parametrize("records,kind", [([], "EMPTY_ESTABLISHMENT"), ([legacy_cohort_record([])], "LEGACY_WITNESS")])
def test_empty_and_cohort_only_have_distinct_proof_semantics(tmp_path, records, kind):
    path = old_store(tmp_path, records)
    old = raw_records(path)
    SubjectRegistry(path, key=KEY)
    result = events(path)[-1]
    assert result["proof_kind"] == kind
    assert (result["witness"] is None) == (not records)
    if records:
        assert result["witness"]["kind"] == "RECORD"
        assert result["witness"]["opaque_id"] == "cohort-legacy-fixture"
    assert old == raw_records(path)


def test_witness_is_historical_and_allows_authorized_version_update(tmp_path):
    path = old_store(tmp_path)
    registry = SubjectRegistry(path, key=KEY)
    old_events = events(path)
    record = registry.get_twin("twin-fixture-one")
    registry.select_observations(record["twin_id"], expected_version=1)
    reopened = SubjectRegistry(path, key=KEY)
    assert reopened.active_twin()["version"] == 2
    assert events(path) == old_events
    before = raw_records(path)
    count = scalar(path, "SELECT COUNT(*) FROM registry_audit")
    with pytest.raises(Exception):
        SubjectRegistry(path, key=WRONG)
    assert before == raw_records(path)
    assert count == scalar(path, "SELECT COUNT(*) FROM registry_audit")


def test_failed_later_migration_rolls_back_index_and_keeps_terminal(tmp_path):
    one, two = legacy_twin_record("a"), legacy_twin_record("b")
    two["subject_id"] = one["subject_id"]
    path = old_store(tmp_path, [one, two])
    with pytest.raises(Exception):
        SubjectRegistry(path, key=KEY)
    assert scalar(path, "SELECT COUNT(*) FROM registry_data_key_proof") == 0
    assert scalar(path, "SELECT COUNT(*) FROM subject_identifiers") == 0
    assert events(path)[-1]["outcome_code"] == "MIGRATION_FAILED"
    assert scalar(path, "SELECT COUNT(*) FROM registry_bootstrap_attempts WHERE result_event_id IS NULL") == 0


def test_corrupt_first_witness_cannot_fall_back_to_valid_later_record(tmp_path, monkeypatch):
    path = old_store(tmp_path, [legacy_twin_record("a"), legacy_twin_record("b")])
    with sqlite3.connect(path) as connection:
        connection.execute("UPDATE records SET ciphertext=? WHERE record_id='twin-fixture-a'", (b"corrupt technical bytes",))
    seen = []
    original = SubjectRegistry._open
    def spy(self, row):
        seen.append(row["record_id"])
        return original(self, row)
    monkeypatch.setattr(SubjectRegistry, "_open", spy)
    with pytest.raises(Exception):
        SubjectRegistry(path, key=KEY)
    assert seen == ["twin-fixture-a"]
    assert events(path)[-1]["outcome_code"] == "KEY_OR_RECORD_UNVERIFIABLE"


@pytest.mark.parametrize("part", ["key_missing", "key_short", "key_other", "key_symlink", "key_hardlink", "key_mode", "db_mode", "parent_mode"])
def test_unsafe_or_missing_existing_material_never_repairs(tmp_path, part):
    path = old_store(tmp_path)
    SubjectRegistry(path, key=KEY)
    key = path.with_name(path.name + ".bootstrap-key")
    saved = tmp_path / "saved-key"
    if part == "key_missing":
        key.rename(saved)
    elif part in {"key_short", "key_other"}:
        key.write_bytes(b"short" if part == "key_short" else WRONG)
    elif part == "key_symlink":
        key.rename(saved)
        key.symlink_to(saved)
    elif part == "key_hardlink":
        os.link(key, saved)
    elif part == "key_mode":
        key.chmod(0o644)
    elif part == "db_mode":
        path.chmod(0o644)
    else:
        tmp_path.chmod(0o755)
    before = raw_records(path)
    count = scalar(path, "SELECT COUNT(*) FROM registry_audit")
    with pytest.raises(ValueError):
        SubjectRegistry(path, key=KEY)
    assert before == raw_records(path)
    assert count == scalar(path, "SELECT COUNT(*) FROM registry_audit")
    if part == "key_missing":
        assert not key.exists()
    if part == "db_mode":
        assert path.stat().st_mode & 0o777 == 0o644


def test_two_correct_constructors_have_one_proof(tmp_path):
    path = old_store(tmp_path)
    barrier = Barrier(2)
    def opening():
        barrier.wait(timeout=wait_seconds(3))
        return SubjectRegistry(path, key=KEY)
    with ThreadPoolExecutor(max_workers=2) as executor:
        results = list(executor.map(lambda _: opening(), range(2)))
    assert len(results) == 2
    assert scalar(path, "SELECT COUNT(*) FROM registry_data_key_proof") == 1
    assert len(events(path)) == 2


def test_poisoned_recovery_explicitly_unavailable_before_any_mutation(tmp_path):
    module = importlib.import_module("livemorebio.aegle.registry_bootstrap")
    path = old_store(tmp_path)
    before = path.read_bytes()
    with pytest.raises(module.RegistryBootstrapError) as caught:
        module.recover_unverified_audit(path, data_key=KEY)
    assert caught.value.code == "RECOVERY_REVIEW_REQUIRED"
    assert path.read_bytes() == before
    assert not path.with_name(path.name + ".bootstrap-key").exists()


@pytest.fixture
def bootstrap_store(tmp_path):
    module = importlib.import_module("livemorebio.aegle.registry_bootstrap")
    path = old_store(tmp_path, [])
    helper = module.RegistryBootstrap(path=path, data_key=KEY, store_id=STORE, process_instance=PROCESS, source_sha256=SOURCE)
    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys=ON")
    helper.initialize_tables(connection)
    connection.commit()
    with helper.locked():
        helper.ensure_identity(connection)
        connection.commit()
    yield module, helper, connection
    connection.close()


@pytest.mark.parametrize("charged,accepted", [(510, True), (511, False), (512, False)])
def test_exact_bootstrap_capacity_and_reserved_completion(bootstrap_store, charged, accepted):
    module, helper, connection = bootstrap_store
    for _ in range(charged // 2):
        reservation = helper.begin(connection, action="INITIALIZE")
        helper.finish(connection, reservation, outcome_code="INTERRUPTED_OUTCOME_UNKNOWN")
    if charged % 2:
        helper.begin(connection, action="INITIALIZE")
        # A pending slot is already charged; produce 511 actual events but 512
        # charged slots, which must reject just as the stated boundary does.
    connection.commit()
    if accepted:
        reservation = helper.begin(connection, action="INITIALIZE")
        connection.commit()
        with pytest.raises(module.RegistryBootstrapError):
            helper.begin(connection, action="INITIALIZE")
        connection.rollback()
        helper.finish(connection, reservation, outcome_code="INTERRUPTED_OUTCOME_UNKNOWN")
        connection.commit()
        assert connection.execute("SELECT COUNT(*) FROM registry_bootstrap_events").fetchone()[0] == 512
    else:
        with pytest.raises(module.RegistryBootstrapError):
            helper.begin(connection, action="INITIALIZE")


def test_pending_attempt_reopens_with_new_process_and_metadata_only(bootstrap_store):
    module, helper, connection = bootstrap_store
    reservation = helper.begin(connection, action="INITIALIZE")
    connection.commit()
    path = helper.path
    connection.close()
    other = module.RegistryBootstrap(path=path, data_key=WRONG, store_id=STORE, process_instance=str(uuid4()), source_sha256="b" * 64)
    with closing(sqlite3.connect(path)) as reopened:
        reopened.row_factory = sqlite3.Row
        other.complete_interrupted(reopened)
        reopened.commit()
    recorded = events(path)
    assert recorded[-1]["request_id"] == reservation["request_id"]
    assert recorded[-1]["outcome_code"] == "INTERRUPTED_OUTCOME_UNKNOWN"
    assert recorded[-1]["origin_process_instance"] == PROCESS
    assert recorded[-1]["completion_process_instance"] != PROCESS


def legacy_audited_store(tmp_path):
    from livemorebio.aegle.registry_audit import RegistryAudit
    path = old_store(tmp_path)
    with sqlite3.connect(path) as connection:
        connection.execute("CREATE TABLE registry_state(state_key TEXT PRIMARY KEY,state_value TEXT NOT NULL,updated_at TEXT NOT NULL)")
        connection.execute("INSERT INTO registry_state VALUES('registry_store_id',?,?)", (STORE, "2026-09-08T12:00:00Z"))
        audit = RegistryAudit(key=KEY, store_id=STORE, process_instance=PROCESS, source_sha256=SOURCE)
        audit.initialize(connection)
        reservation = audit.begin(connection, request_id=str(uuid4()), action="inspect", opaque_record_id=None)
        audit.finish(connection, reservation, outcome_code="SUCCESS")
    return path


def audit_bytes(path):
    with sqlite3.connect(path) as connection:
        return (connection.execute("SELECT * FROM registry_audit ORDER BY sequence").fetchall(),
                connection.execute("SELECT * FROM registry_audit_reservations ORDER BY event_id").fetchall())


def test_existing_audit_wrong_key_no_writes_and_explicit_adoption_preserves_ledger(tmp_path, monkeypatch):
    path = legacy_audited_store(tmp_path)
    before = audit_bytes(path)
    with pytest.raises(Exception):
        SubjectRegistry(path, key=WRONG)
    assert audit_bytes(path) == before
    assert not path.with_name(path.name + ".bootstrap-key").exists()
    registry = SubjectRegistry(path, key=KEY)
    assert not path.with_name(path.name + ".bootstrap-key").exists()
    old_records, before = raw_records(path), audit_bytes(path)
    def forbidden(*args):
        raise AssertionError("Adoption must not decrypt clinical data")
    monkeypatch.setattr(registry, "_open", forbidden)
    registry.adopt_audit_authority()
    assert audit_bytes(path) == before and raw_records(path) == old_records
    assert events(path)[-1]["proof_kind"] == "EXISTING_AUDIT"
    assert events(path)[-1]["witness"]["kind"] == "AUDIT_EVENT"
    registry.adopt_audit_authority()
    assert len(events(path)) == 2


def test_existing_object_rechecks_authority_before_new_begin(tmp_path):
    from livemorebio.aegle.registry_audit import RegistryAudit
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrap
    path = legacy_audited_store(tmp_path)
    good = SubjectRegistry(path, key=KEY)
    # A retained wrong-key helper represents an older reviewed-runtime object;
    # no normal constructor is allowed to authenticate it using this wrong key.
    old_audit = RegistryAudit(key=WRONG, store_id=STORE, process_instance=PROCESS, source_sha256=SOURCE)
    old_boot = RegistryBootstrap(path=path, data_key=WRONG, store_id=STORE, process_instance=PROCESS, source_sha256=SOURCE)
    old_audit.authority_check = lambda connection: old_boot.assert_authority(connection, old_audit)
    good.adopt_audit_authority()
    before = audit_bytes(path)
    with closing(good._connect()) as connection:
        with pytest.raises(ValueError):
            old_audit.begin(connection, request_id=str(uuid4()), action="inspect", opaque_record_id=None)
        connection.rollback()
    assert audit_bytes(path) == before


def test_adoption_between_committed_begin_and_clinical_transaction_blocks_access(tmp_path, monkeypatch):
    path = legacy_audited_store(tmp_path)
    old = SubjectRegistry(path, key=KEY)
    adopter = SubjectRegistry(path, key=KEY)
    connect = old._connect
    opened = []
    class AdoptAfterBegin:
        def __init__(self, underlying):
            self.underlying, self.first = underlying, True
        def __getattr__(self, name):
            return getattr(self.underlying, name)
        def commit(self):
            self.underlying.commit()
            if self.first:
                self.first = False
                adopter.adopt_audit_authority()
    monkeypatch.setattr(old, "_connect", lambda: AdoptAfterBegin(connect()))
    monkeypatch.setattr(old, "_open", lambda row: opened.append(row))
    with pytest.raises(ValueError):
        old.get_twin("twin-fixture-one")
    assert opened == []
    # The pre-adoption begin is retained unknown, not falsely completed using a
    # different authority token after access was denied.
    assert scalar(path, "SELECT COUNT(*) FROM registry_audit_reservations") == 1
    assert SubjectRegistry(path, key=KEY).get_twin("twin-fixture-one")


@pytest.mark.parametrize("table,column,value", [
    ("registry_data_key_proof", "nonce", b"bad"),
    ("registry_data_key_proof", "ciphertext", 12),
    ("registry_bootstrap_proof_binding", "proof_id", str(uuid4())),
    ("registry_bootstrap_identity", "identity_id", str(uuid4())),
    ("registry_bootstrap_attempts", "request_id", str(uuid4())),
    ("registry_bootstrap_events", "sequence", 99),
])
def test_tampered_authority_graph_rejects_before_normal_writes(tmp_path, table, column, value):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError
    path = old_store(tmp_path)
    SubjectRegistry(path, key=KEY)
    with sqlite3.connect(path) as connection:
        connection.execute(f"UPDATE {table} SET {column}=? WHERE rowid=(SELECT MIN(rowid) FROM {table})", (value,))
    before = audit_bytes(path)
    with pytest.raises(RegistryBootstrapError):
        SubjectRegistry(path, key=KEY)
    assert audit_bytes(path) == before


@pytest.mark.parametrize("table", ["registry_data_key_proof", "registry_bootstrap_proof_binding", "registry_bootstrap_identity"])
def test_one_sided_marker_is_not_retryable_provisional_state(tmp_path, table):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError
    path = old_store(tmp_path)
    SubjectRegistry(path, key=KEY)
    with sqlite3.connect(path) as connection:
        connection.execute(f"DELETE FROM {table}")
    before = audit_bytes(path)
    with pytest.raises(RegistryBootstrapError):
        SubjectRegistry(path, key=KEY)
    assert audit_bytes(path) == before


@pytest.mark.parametrize("phase", ["before_proof", "after_proof", "after_result"])
def test_failed_transaction_retains_failure_no_partial_authority(tmp_path, monkeypatch, phase):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrap
    path = old_store(tmp_path)
    original = RegistryBootstrap.establish
    def failed(self, connection, reservation, **kwargs):
        if phase == "before_proof":
            raise RuntimeError("fixed authored failure")
        if phase == "after_proof":
            connection.execute("INSERT INTO registry_data_key_proof VALUES(1,?,?,?)", (str(uuid4()), b"n" * 12, b"x" * 17))
            raise RuntimeError("fixed authored failure")
        original(self, connection, reservation, **kwargs)
        raise RuntimeError("fixed authored failure")
    with monkeypatch.context() as patch:
        patch.setattr(RegistryBootstrap, "establish", failed)
        with pytest.raises(RuntimeError, match="fixed authored failure"):
            SubjectRegistry(path, key=KEY)
    assert scalar(path, "SELECT COUNT(*) FROM registry_data_key_proof") == 0
    assert scalar(path, "SELECT COUNT(*) FROM registry_bootstrap_proof_binding") == 0
    assert scalar(path, "SELECT COUNT(*) FROM subject_identifiers") == 0
    assert events(path)[-1]["outcome_code"] == "MIGRATION_FAILED"
    assert SubjectRegistry(path, key=KEY)


def test_primary_failure_survives_terminal_storage_failure_then_restart_completes_unknown(tmp_path, monkeypatch):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrap
    path = old_store(tmp_path)
    def failed(*args, **kwargs):
        raise OSError("fixed audit write failure")
    with monkeypatch.context() as patch:
        patch.setattr(RegistryBootstrap, "finish", failed)
        with pytest.raises(Exception) as caught:
            SubjectRegistry(path, key=WRONG)
        assert not isinstance(caught.value, OSError)
    assert events(path)[-1]["event_type"] == "BEGIN"
    SubjectRegistry(path, key=KEY)
    assert [value["outcome_code"] for value in events(path)] == [None, "INTERRUPTED_OUTCOME_UNKNOWN", None, "SUCCESS"]


@pytest.mark.parametrize("uncertain", [False, True])
def test_lost_final_commit_ack_is_confirmed_by_exact_graph_or_explicit_unknown(tmp_path, monkeypatch, uncertain):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError
    path = old_store(tmp_path)
    original = SubjectRegistry._connect
    state = {"committed": False}
    class LostAck:
        def __init__(self, connection):
            self.connection = connection
        def __getattr__(self, name):
            return getattr(self.connection, name)
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return self.connection.__exit__(*args)
        def commit(self):
            proof = self.connection.execute("SELECT name FROM sqlite_master WHERE name='registry_data_key_proof'").fetchone()
            exists = proof and self.connection.execute("SELECT COUNT(*) FROM registry_data_key_proof").fetchone()[0]
            self.connection.commit()
            if exists and not state["committed"]:
                state["committed"] = True
                raise OSError("fixed lost acknowledgement")
    def connect(self):
        if state["committed"] and uncertain:
            raise OSError("fixed inaccessible verification")
        return LostAck(original(self))
    with monkeypatch.context() as patch:
        patch.setattr(SubjectRegistry, "_connect", connect)
        if uncertain:
            with pytest.raises(RegistryBootstrapError) as caught:
                SubjectRegistry(path, key=KEY)
            assert caught.value.code == "BOOTSTRAP_COMMIT_UNCONFIRMED"
        else:
            assert SubjectRegistry(path, key=KEY)
    assert events(path)[-1]["outcome_code"] == "SUCCESS"
    assert scalar(path, "SELECT COUNT(*) FROM registry_data_key_proof") == 1
    assert SubjectRegistry(path, key=KEY)


def _process_open(path, candidate, barrier, result):
    try:
        barrier.wait(timeout=wait_seconds(10))
        SubjectRegistry(Path(path), key=candidate)
        result.put("accepted")
    except Exception:
        result.put("rejected")


@pytest.mark.parametrize("candidates,expected", [([KEY, KEY], ["accepted", "accepted"]), ([WRONG, KEY], ["accepted", "rejected"])])
def test_real_process_concurrent_candidates_create_only_one_authority(tmp_path, candidates, expected):
    path = old_store(tmp_path)
    context = multiprocessing.get_context("spawn")
    barrier, result = context.Barrier(2), context.Queue()
    processes = [context.Process(target=_process_open, args=(str(path), candidate, barrier, result)) for candidate in candidates]
    try:
        for process in processes:
            process.start()
        actual = sorted(result.get(timeout=20) for _ in processes)
        assert actual == expected
        for process in processes:
            process.join(timeout=wait_seconds(10))
            assert not process.is_alive() and process.exitcode == 0
    finally:
        for process in processes:
            if process.is_alive():
                process.terminate()
                process.join(timeout=wait_seconds(5))
        result.close()
        result.join_thread()
    assert scalar(path, "SELECT COUNT(*) FROM registry_data_key_proof") == 1
    assert scalar(path, "SELECT COUNT(*) FROM registry_bootstrap_attempts WHERE result_event_id IS NULL") == 0


def test_migration_bound_rejects_before_any_record_decrypt(tmp_path, monkeypatch):
    from livemorebio.aegle import registry_bootstrap
    path = old_store(tmp_path)
    monkeypatch.setattr(registry_bootstrap, "MAX_MIGRATION_TWINS", 0)
    def forbidden(*args):
        raise AssertionError("Preflight migration bound must precede witness decrypt")
    monkeypatch.setattr(SubjectRegistry, "_open", forbidden)
    with pytest.raises(registry_bootstrap.RegistryBootstrapError) as caught:
        SubjectRegistry(path, key=KEY)
    assert caught.value.code == "MIGRATION_REVIEW_REQUIRED"
    assert scalar(path, "SELECT COUNT(*) FROM registry_data_key_proof") == 0


def _process_crash(path, phase):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrap
    if phase == "key":
        def publish_and_exit(self, connection):
            self._writer(connection)
            self._key(connection, create=True)
            os._exit(24)
        RegistryBootstrap.ensure_identity = publish_and_exit
    else:
        def exit_before_decrypt(self, row):
            os._exit(23)
        SubjectRegistry._open = exit_before_decrypt
    SubjectRegistry(Path(path), key=KEY)


@pytest.mark.parametrize("phase,code", [("key", 24), ("begin", 23)])
def test_real_process_crash_preserves_orphan_key_or_pending_attempt(tmp_path, phase, code):
    path = old_store(tmp_path)
    before = raw_records(path)
    context = multiprocessing.get_context("spawn")
    process = context.Process(target=_process_crash, args=(str(path), phase))
    try:
        process.start()
        process.join(timeout=wait_seconds(15))
        assert not process.is_alive() and process.exitcode == code
    finally:
        if process.is_alive():
            process.terminate()
            process.join(timeout=wait_seconds(5))
    key_path = path.with_name(path.name + ".bootstrap-key")
    key_before = key_path.read_bytes()
    assert len(key_before) == 32
    registry = SubjectRegistry(path, key=KEY)
    assert raw_records(path) == before and key_path.read_bytes() == key_before
    recorded = events(path)
    assert [item["outcome_code"] for item in recorded] == ([None, "SUCCESS"] if phase == "key" else [None, "INTERRUPTED_OUTCOME_UNKNOWN", None, "SUCCESS"])
    assert registry.get_twin("twin-fixture-one")


def _seed_bootstrap_pairs(helper, connection, count):
    """Fixed valid encrypted capacity records, not thousands of real accesses."""
    pair = helper.begin(connection, action="INITIALIZE")
    done = helper.finish(connection, pair, outcome_code="INTERRUPTED_OUTCOME_UNKNOWN")
    key = helper.path.with_name(helper.path.name + ".bootstrap-key").read_bytes()
    for index in range(1, count):
        first_id, second_id, request_id = str(uuid4()), str(uuid4()), str(uuid4())
        first = {**pair, "event_id": first_id, "begin_event_id": first_id, "request_id": request_id, "sequence": index * 2 + 1}
        second = {**done, "event_id": second_id, "begin_event_id": first_id, "request_id": request_id, "sequence": index * 2 + 2}
        for value in (first, second):
            nonce = os.urandom(12)
            cipher = AESGCM(key).encrypt(nonce, canonical(value), b"livemore.subject-registry.bootstrap.v1\0" + value["event_id"].encode())
            connection.execute("INSERT INTO registry_bootstrap_events VALUES(?,?,?,?)", (value["event_id"], value["sequence"], nonce, cipher))
        connection.execute("INSERT INTO registry_bootstrap_attempts VALUES(?,?,?)", (first_id, request_id, second_id))
    connection.commit()


def test_two_connection_capacity_contention_keeps_reserved_terminal(bootstrap_store):
    module, helper, connection = bootstrap_store
    _seed_bootstrap_pairs(helper, connection, 255)
    barrier = Barrier(2)
    def attempt():
        other = module.RegistryBootstrap(path=helper.path, data_key=KEY, store_id=STORE, process_instance=str(uuid4()), source_sha256=SOURCE)
        with closing(sqlite3.connect(helper.path, timeout=5)) as writer:
            writer.row_factory = sqlite3.Row
            barrier.wait(timeout=wait_seconds(3))
            try:
                reservation = other.begin(writer, action="INITIALIZE")
                writer.commit()
                return reservation
            except module.RegistryBootstrapError as error:
                writer.rollback()
                assert error.code == "REGISTRY_BOOTSTRAP_CAPACITY"
                return None
    with ThreadPoolExecutor(max_workers=2) as pool:
        attempts = list(pool.map(lambda _: attempt(), range(2)))
    assert sum(item is not None for item in attempts) == 1
    winner = next(item for item in attempts if item is not None)
    helper.finish(connection, winner, outcome_code="INTERRUPTED_OUTCOME_UNKNOWN")
    connection.commit()
    assert connection.execute("SELECT COUNT(*) FROM registry_bootstrap_events").fetchone()[0] == 512


def test_bootstrap_odd_remaining_budget_cannot_admit_half_an_attempt(bootstrap_store, monkeypatch):
    module, helper, connection = bootstrap_store
    _seed_bootstrap_pairs(helper, connection, 255)
    # Valid charge is always even (two slots per attempt); an odd capacity of
    # 511 is exercised explicitly rather than mislabeling 512 charged as 511.
    monkeypatch.setattr(module, "MAX_EVENTS", 511)
    with pytest.raises(module.RegistryBootstrapError) as caught:
        helper.begin(connection, action="INITIALIZE")
    assert caught.value.code == "REGISTRY_BOOTSTRAP_CAPACITY"
    assert connection.execute("SELECT COUNT(*) FROM registry_bootstrap_events").fetchone()[0] == 510


@pytest.mark.parametrize("field,value", [("action", "ADOPT_EXISTING_AUDIT"), ("proof_kind", None), ("origin_source_sha256", "x" * 64), ("completed_at", "2026-09-08"), ("sequence", True)])
def test_authenticated_invalid_result_schema_or_proof_semantics_rejected(tmp_path, field, value):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError
    path = old_store(tmp_path)
    SubjectRegistry(path, key=KEY)
    key = path.with_name(path.name + ".bootstrap-key").read_bytes()
    with sqlite3.connect(path) as connection:
        row = connection.execute("SELECT event_id,nonce,ciphertext FROM registry_bootstrap_events ORDER BY sequence DESC LIMIT 1").fetchone()
        payload = json.loads(AESGCM(key).decrypt(row[1], row[2], b"livemore.subject-registry.bootstrap.v1\0" + row[0].encode()))
        payload[field] = value
        connection.execute("UPDATE registry_bootstrap_events SET ciphertext=? WHERE event_id=?", (AESGCM(key).encrypt(row[1], canonical(payload), b"livemore.subject-registry.bootstrap.v1\0" + row[0].encode()), row[0]))
    before = audit_bytes(path)
    with pytest.raises(RegistryBootstrapError):
        SubjectRegistry(path, key=KEY)
    assert before == audit_bytes(path)


def test_relabeling_complete_graph_as_adoption_cannot_change_legacy_witness_semantics(tmp_path):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError
    path = old_store(tmp_path)
    SubjectRegistry(path, key=KEY)
    key = path.with_name(path.name + ".bootstrap-key").read_bytes()
    with sqlite3.connect(path) as connection:
        for row in connection.execute("SELECT event_id,nonce,ciphertext FROM registry_bootstrap_events").fetchall():
            aad = b"livemore.subject-registry.bootstrap.v1\0" + row[0].encode()
            payload = json.loads(AESGCM(key).decrypt(row[1], row[2], aad))
            payload["action"] = "ADOPT_EXISTING_AUDIT"
            connection.execute("UPDATE registry_bootstrap_events SET ciphertext=? WHERE event_id=?", (AESGCM(key).encrypt(row[1], canonical(payload), aad), row[0]))
    with pytest.raises(RegistryBootstrapError):
        SubjectRegistry(path, key=KEY)


def test_malformed_lock_is_fixed_error_no_new_bootstrap_evidence(tmp_path):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError
    path = old_store(tmp_path)
    lock = path.with_name(path.name + ".bootstrap-lock")
    lock.symlink_to(tmp_path / "no-target")
    before = raw_records(path)
    with pytest.raises(RegistryBootstrapError):
        SubjectRegistry(path, key=KEY)
    assert raw_records(path) == before
    assert not path.with_name(path.name + ".bootstrap-key").exists()


def test_witness_byte_bound_is_checked_before_clinical_open(tmp_path, monkeypatch):
    from livemorebio.aegle import registry_bootstrap
    path = old_store(tmp_path, [legacy_cohort_record([])])
    monkeypatch.setattr(registry_bootstrap, "MAX_WITNESS_BYTES", 20)
    calls = []
    monkeypatch.setattr(SubjectRegistry, "_open", lambda *args: calls.append(True))
    with pytest.raises(registry_bootstrap.RegistryBootstrapError) as caught:
        SubjectRegistry(path, key=KEY)
    assert caught.value.code == "MIGRATION_REVIEW_REQUIRED" and calls == []
    assert events(path)[-1]["outcome_code"] == "KEY_OR_RECORD_UNVERIFIABLE"


def test_bootstrap_payload_requires_utf8_not_json_autodetected_utf16(bootstrap_store):
    module, helper, connection = bootstrap_store
    key = helper.path.with_name(helper.path.name + ".bootstrap-key").read_bytes()
    row = connection.execute("SELECT identity_id,nonce,ciphertext FROM registry_bootstrap_identity").fetchone()
    aad = b"livemore.subject-registry.bootstrap-identity.v1\0" + row[0].encode()
    payload = AESGCM(key).decrypt(row[1], row[2], aad)
    encrypted = AESGCM(key).encrypt(row[1], payload.decode().encode("utf-16"), aad)
    connection.execute("UPDATE registry_bootstrap_identity SET ciphertext=?", (encrypted,))
    connection.commit()
    with pytest.raises(module.RegistryBootstrapError):
        helper.ensure_identity(connection)


def test_secondary_rollback_failure_does_not_replace_primary_verification_error(tmp_path, monkeypatch):
    from cryptography.exceptions import InvalidTag
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrap
    path = old_store(tmp_path)
    original = SubjectRegistry._connect
    class FailedEvidenceRollback:
        def __init__(self, connection):
            self.connection, self.rollbacks = connection, 0
        def __getattr__(self, name):
            return getattr(self.connection, name)
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return self.connection.__exit__(*args)
        def rollback(self):
            self.rollbacks += 1
            self.connection.rollback()
            if self.rollbacks > 1:
                raise OSError("secondary fixed failure")
    monkeypatch.setattr(SubjectRegistry, "_connect", lambda self: FailedEvidenceRollback(original(self)))
    def failed(*args, **kwargs):
        raise OSError("fixed terminal write error")
    monkeypatch.setattr(RegistryBootstrap, "finish", failed)
    with pytest.raises(InvalidTag):
        SubjectRegistry(path, key=WRONG)
    assert events(path)[-1]["event_type"] == "BEGIN"


def test_closed_connection_after_commit_ack_loss_checks_exact_durable_proof(tmp_path, monkeypatch):
    path = old_store(tmp_path)
    original = SubjectRegistry._connect
    closed = []
    class ClosedCommit:
        def __init__(self, connection):
            self.connection = connection
        def __getattr__(self, name):
            return getattr(self.connection, name)
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return self.connection.__exit__(*args)
        def commit(self):
            table = self.connection.execute("SELECT name FROM sqlite_master WHERE name='registry_data_key_proof'").fetchone()
            proof = table and self.connection.execute("SELECT COUNT(*) FROM registry_data_key_proof").fetchone()[0]
            self.connection.commit()
            if proof and not closed:
                closed.append(True)
                self.connection.close()
                raise OSError("fixed committed connection lost")
    monkeypatch.setattr(SubjectRegistry, "_connect", lambda self: ClosedCommit(original(self)))
    assert SubjectRegistry(path, key=KEY)
    assert events(path)[-1]["outcome_code"] == "SUCCESS"


def test_provisional_identity_with_failed_and_pending_attempts_stays_retryable(tmp_path, monkeypatch):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrap
    path = old_store(tmp_path)
    with pytest.raises(Exception):
        SubjectRegistry(path, key=WRONG)
    original = RegistryBootstrap.finish
    with monkeypatch.context() as patch:
        patch.setattr(RegistryBootstrap, "finish", lambda *a, **k: (_ for _ in ()).throw(OSError("technical write failure")))
        with pytest.raises(Exception):
            SubjectRegistry(path, key=WRONG)
    assert scalar(path, "SELECT COUNT(*) FROM registry_data_key_proof") == 0
    assert scalar(path, "SELECT COUNT(*) FROM registry_bootstrap_proof_binding") == 0
    assert scalar(path, "SELECT COUNT(*) FROM registry_bootstrap_identity") == 1
    assert scalar(path, "SELECT COUNT(*) FROM registry_bootstrap_attempts WHERE result_event_id IS NULL") == 1
    assert SubjectRegistry(path, key=KEY)
    assert [item["outcome_code"] for item in events(path)] == [None, "KEY_OR_RECORD_UNVERIFIABLE", None, "INTERRUPTED_OUTCOME_UNKNOWN", None, "SUCCESS"]


def test_authenticated_nonobject_witness_does_not_establish_a_record_proof(tmp_path):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError
    path = old_store(tmp_path, [legacy_cohort_record([])])
    with sqlite3.connect(path) as connection:
        row = connection.execute("SELECT record_id,nonce FROM records").fetchone()
        encrypted = AESGCM(KEY).encrypt(row[1], b"[]", AAD + row[0].encode())
        connection.execute("UPDATE records SET ciphertext=?", (encrypted,))
    with pytest.raises(RegistryBootstrapError):
        SubjectRegistry(path, key=KEY)
    assert scalar(path, "SELECT COUNT(*) FROM registry_data_key_proof") == 0
    assert events(path)[-1]["outcome_code"] == "KEY_OR_RECORD_UNVERIFIABLE"


def test_unsupported_lock_failure_is_fixed_and_closes_descriptor(bootstrap_store, monkeypatch):
    module, helper, _ = bootstrap_store
    opened = []
    original = module.os.open
    def record_open(path, *args, **kwargs):
        descriptor = original(path, *args, **kwargs)
        if str(path).endswith(".bootstrap-lock"):
            opened.append(descriptor)
        return descriptor
    monkeypatch.setattr(module.os, "open", record_open)
    def fail(*args):
        raise OSError("technical secret-like marker must not be public")
    monkeypatch.setattr(module.fcntl, "flock", fail)
    with pytest.raises(module.RegistryBootstrapError) as caught:
        with helper.locked():
            raise AssertionError("No entry after lock failure")
    assert "marker" not in str(caught.value)
    assert opened
    with pytest.raises(OSError):
        os.fstat(opened[-1])


def test_lock_wait_has_five_second_bound_without_live_sleep(bootstrap_store, monkeypatch):
    module, helper, _ = bootstrap_store
    samples = iter([10.0, 15.0])
    monkeypatch.setattr(module.time, "monotonic", lambda: next(samples))
    monkeypatch.setattr(module.time, "sleep", lambda _: (_ for _ in ()).throw(AssertionError("Exceeded lock deadline")))
    monkeypatch.setattr(module.fcntl, "flock", lambda *args: (_ for _ in ()).throw(BlockingIOError()))
    with pytest.raises(module.RegistryBootstrapError) as caught:
        with helper.locked():
            raise AssertionError("No entry after timeout")
    assert caught.value.code == "REGISTRY_BOOTSTRAP_BUSY"


def test_unsafe_key_mode_rejects_before_any_sqlite_open(tmp_path, monkeypatch):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError
    path = old_store(tmp_path)
    SubjectRegistry(path, key=KEY)
    path.with_name(path.name + ".bootstrap-key").chmod(0o644)
    def forbidden(*args, **kwargs):
        raise AssertionError("Unsafe exact key path must reject before opening the database")
    monkeypatch.setattr(sqlite3, "connect", forbidden)
    with pytest.raises(RegistryBootstrapError):
        SubjectRegistry(path, key=KEY)
