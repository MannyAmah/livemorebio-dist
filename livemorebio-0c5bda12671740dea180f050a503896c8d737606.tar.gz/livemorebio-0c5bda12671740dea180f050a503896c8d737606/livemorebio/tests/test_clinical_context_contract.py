"""Red-first pure context admission: no solver, HTTP, model cache or person data."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import importlib
import operator
from types import SimpleNamespace

import pytest

from livemorebio.tests.clinical_registry_fixtures import legacy_twin_record, sha


@pytest.mark.parametrize("condition", ["", "type 1 diabetes", "diabetes insipidus", "family history of diabetes",
                                       "no diabetes", "prediabetes", "type 2 diabetes", "unrelated condition"])
def test_condition_text_never_selects_an_unbound_person_model(condition):
    from livemorebio.aegle.clinical_parameters import initialize_profile
    human = SimpleNamespace(conditions=[condition], display_label="Authored software fixture", observations={},
                            model_parameters={}, source_class="REAL_HUMAN", model_binding=None)
    with pytest.raises(ValueError) as caught:
        initialize_profile(human)
    assert getattr(caught.value, "code", None) == "MODEL_BINDING_REQUIRED"
    assert condition == "" or condition not in str(caught.value)


@pytest.mark.parametrize("binding", [None, False, True, [], "healthy", "t2d", {}, {"qualified": True}])
def test_real_bindings_are_not_client_authority(binding):
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    record = legacy_twin_record()
    record["model_binding"] = binding
    with pytest.raises(module.ModelContextError) as caught:
        module.resolve_model_context(record)
    assert caught.value.code in {"MODEL_BINDING_REQUIRED", "MODEL_CONTEXT_INVALID", "MODEL_CONTEXT_UNSUPPORTED"}


@pytest.mark.parametrize("helper", ["admitted_human", "build_twin"])
def test_real_missing_binding_error_precedes_public_null_binding_guard(helper):
    from livemorebio.aegle.subjects import SubjectRegistry
    record = legacy_twin_record()
    record["model_binding"] = None
    with pytest.raises(ValueError) as caught:
        getattr(SubjectRegistry, helper)(record)
    assert getattr(caught.value, "code", None) == "MODEL_BINDING_REQUIRED"


@pytest.mark.parametrize("marker", [
    {"schema": "livemore.frozen-public-reference-member.v1"},
    {"generation_method": "joint_public_records_without_replacement"},
    {"source_id": "nhanes-2021-2023-joint-public-v1"},
])
def test_relabelled_public_source_cannot_enter_real_context(marker):
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    record = {**legacy_twin_record(), **marker, "source_class": "REAL_HUMAN", "model_binding": None}
    with pytest.raises(ValueError) as caught:
        module.resolve_model_context(record)
    assert getattr(caught.value, "code", None) in {"MODEL_CONTEXT_INVALID", "REFERENCE_MODEL_BINDING_REQUIRED"}


def test_unavailable_projection_is_exact_and_contains_no_clinical_payload():
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    record = legacy_twin_record(version=4)
    assert module.model_availability(record, source_generation="a" * 32, selection_mode="observations_only") == {
        "schema": "livemore.model-availability.v1", "state": "UNAVAILABLE",
        "reason_code": "MODEL_BINDING_REQUIRED", "selection_mode": "observations_only",
        "twin_id": record["twin_id"], "twin_version": 4, "source_generation": "a" * 32,
        "preparation_available": False,
    }


@pytest.mark.parametrize("signal,observation", [
    ("glucose_mgdl", {"sampling_context": "random", "quality_status": "verified"}),
    ("glucose_mgdl", {"sampling_context": "fasting", "quality_status": "not_assessed"}),
])
def test_pure_clinical_validator_does_not_promote_random_or_unassessed_basal_values(signal, observation):
    from livemorebio.aegle import clinical_parameters as module
    data = deepcopy(legacy_twin_record()["observations"]["glucose_mgdl"])
    data.update(observation)
    values, provenance = module.validate_clinical_inputs(observations={signal: data}, model_parameters={})
    assert values == {} and provenance == {}


def test_pure_clinical_validator_keeps_measured_and_declared_provenance_separate():
    from livemorebio.aegle import clinical_parameters as module
    observed = legacy_twin_record()["observations"]
    values, provenance = module.validate_clinical_inputs(observations=observed, model_parameters={"Si": 0.0002})
    assert values == {"Gb": 100.0, "Si": 0.0002}
    assert provenance["Gb"]["evidence_class"] == "MEASURED_CLINICAL"
    assert provenance["Si"]["evidence_class"] == "USER_DECLARED_MODEL_PARAMETER"
    assert not ({"gamma", "Ib", "SG", "p2"} & values.keys())


@pytest.mark.parametrize("conflict", ["observed", "declared"])
def test_pure_clinical_validation_preserves_conflict_rejection(conflict):
    from livemorebio.aegle import clinical_parameters as module
    observed = deepcopy(legacy_twin_record()["observations"])
    declared = {"Gb": 120.0} if conflict == "declared" else {}
    if conflict == "observed":
        observed["fasting_glucose_mgdl"] = {**observed["glucose_mgdl"], "value": 120.0}
    with pytest.raises(ValueError, match="conflict"):
        module.validate_clinical_inputs(observations=observed, model_parameters=declared)


@pytest.mark.parametrize("stratum,seed,member_sha,profile_sha", [
    ("dpp-high-risk-metabolic", 17, "b4001aa3191b148a59e18fc868115882bdf3d4a021dba174fbed821d17ef182b",
     "abd0339e0b209b9dfd4d3b1e8d6eca68a4ee8d4087442549c05e0a1c0bac74a0"),
    ("nhanes-diagnosed-diabetes-older", 29, "42f6e00030cbab7a50082226618c92e2f2b979774b9fe4ba4aeb55d45ed53097",
     "784fef2081e91971b7fffa61bec40c3ed9bd6556d23644974cb4edd1afac1d00"),
])
def test_frozen_legacy_full_members_and_twelve_parameter_values(stratum, seed, member_sha, profile_sha):
    from livemorebio.aegle.population import generate_members, normalize_reference_source
    from livemorebio.aegle.subjects import SubjectRegistryError
    from livemorebio.cendos.protocols import _profile
    source = normalize_reference_source({"role": "population_reference", "source_id": "livemore-public-metabolic-reference-v1"},
                                       error=SubjectRegistryError)
    members = generate_members(size=4, seed=seed, stratum=stratum, source=source, error=SubjectRegistryError)
    assert sha(members) == member_sha
    assert sha([asdict(_profile(member)) for member in members]) == profile_sha
    assert all(len(asdict(_profile(member))) == 13 for member in members)  # 12 values plus name, no solve.


def _legacy_reference_record(stratum="dpp-high-risk-metabolic", seed=17):
    """Build a legacy-shaped numerical-reference fixture, without clinical intake.

    The preserved generator supplies its own reference priors and lineage. This
    helper never admits a person, computes an ODE or regenerates a saved record.
    """
    from livemorebio.aegle.population import generate_members, normalize_reference_source
    from livemorebio.aegle.subjects import SubjectRegistryError

    source = normalize_reference_source(
        {"role": "population_reference", "source_id": "livemore-public-metabolic-reference-v1"},
        error=SubjectRegistryError,
    )
    member = generate_members(size=1, seed=seed, stratum=stratum, source=source, error=SubjectRegistryError)[0]
    supplied = ("Gb", "Si", "gamma", "Ib", "Gt", "SG", "weight_kg")
    record = legacy_twin_record()
    record.update(
        source_class="REFERENCE_GROUNDED_SYNTHETIC", consent_scope=[], chain_of_custody="",
        demographics={"age": member["age"], "sex": member["sex"]}, conditions=member["conditions"],
        genome=member["genome"], lifestyle=member["lifestyle"], lifestyle_profile={"activity_index": member["lifestyle"]},
        observations={}, model_parameters={key: member["model_parameters"][key] for key in supplied},
        reference_source=source, reference_stratum=stratum, reference_lineage=member["source_lineage"],
        generation_seed=seed, profile_sources=[],
        profile_coverage={"status": "REFERENCE_INITIALIZED",
                          "domains": ["conditions", "demographics", "genomics", "lifestyle", "model_parameters"],
                          "missing_core_domains": ["environment", "labs", "medications", "physiology"], "source_count": 1},
        field_provenance={key: {"source_id": source["source_id"], "evidence_class": "REFERENCE_INITIALIZED"}
                          for key in ("demographics.age", "demographics.sex", "conditions", "genome", "lifestyle", "model_parameters")},
    )
    return record


def _expected_legacy_profile(record):
    # Independent frozen constants, not a lookup through either mutable preset.
    return {"name": record["display_label"], **record["model_parameters"],
            "p2": 0.025, "n": 0.14, "ka": 0.020, "f_bioavail": 0.75, "vg_per_kg": 2.0}


@pytest.mark.parametrize("stratum,seed", [("dpp-high-risk-metabolic", 17), ("nhanes-diagnosed-diabetes-older", 29)])
def test_resolved_legacy_context_keeps_seven_overwrites_and_five_frozen_defaults(stratum, seed):
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    record = _legacy_reference_record(stratum, seed)
    expected = _expected_legacy_profile(record)
    context = module.resolve_model_context(record)
    assert asdict(context.profile) == expected
    assert record["source_class"] == "REFERENCE_GROUNDED_SYNTHETIC"
    assert "model_binding" not in record
    for field, item in context.parameter_provenance.items():
        assert item["evidence_class"] == "REFERENCE_INITIALIZED"
        assert item["value"] == expected[field]
    assert set(context.parameter_provenance) == set(expected) - {"name"}


def test_each_context_profile_access_returns_a_detached_mutable_dataclass():
    from livemorebio.engines.metabolic.glucose_insulin import MetabolicProfile
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    record = _legacy_reference_record()
    expected = _expected_legacy_profile(record)
    context = module.resolve_model_context(record)
    first, second = context.profile, context.profile
    assert isinstance(first, MetabolicProfile) and isinstance(second, MetabolicProfile)
    assert first is not second
    first.Gb = 999.0
    first.name = "mutated detached technical profile"
    assert asdict(second) == expected
    assert asdict(context.profile) == expected


def test_resolved_context_properties_cannot_be_replaced_by_the_caller():
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    context = module.resolve_model_context(_legacy_reference_record())
    with pytest.raises((AttributeError, TypeError)):
        context.profile = context.profile
    with pytest.raises((AttributeError, TypeError)):
        context.parameter_provenance = {}


def test_resolved_context_does_not_reread_mutable_reference_templates(monkeypatch):
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY, T2D
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    record = _legacy_reference_record()
    expected = _expected_legacy_profile(record)
    context = module.resolve_model_context(record)
    for template in (HEALTHY, T2D):
        monkeypatch.setattr(template, "p2", 0.8)
        monkeypatch.setattr(template, "n", 0.9)
    assert asdict(context.profile) == expected


def _try_mapping_mutation(action):
    # Either a detached mutable copy or a deep read-only mapping satisfies the
    # public contract. A shallow copy over shared nested dictionaries does not.
    try:
        action()
    except TypeError:
        pass


def test_parameter_provenance_is_deeply_detached_or_frozen():
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    record = _legacy_reference_record()
    context = module.resolve_model_context(record)
    expected = {key: dict(value) for key, value in context.parameter_provenance.items()}
    exposed = context.parameter_provenance
    _try_mapping_mutation(lambda: operator.setitem(exposed["Gb"], "value", 999.0))
    _try_mapping_mutation(lambda: operator.setitem(exposed["Gb"], "source_id", "changed-technical-source"))
    _try_mapping_mutation(lambda: operator.setitem(exposed, "p2", {"value": 1.0, "evidence_class": "MEASURED_CLINICAL"}))
    assert {key: dict(value) for key, value in context.parameter_provenance.items()} == expected
    assert asdict(context.profile) == _expected_legacy_profile(record)


def test_input_record_mutation_does_not_rewrite_already_resolved_context():
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    record = _legacy_reference_record()
    expected = _expected_legacy_profile(record)
    context = module.resolve_model_context(record)
    provenance = {key: dict(value) for key, value in context.parameter_provenance.items()}
    record["model_parameters"]["Gb"] = 999.0
    record["reference_lineage"]["source_id"] = "changed-after-resolution"
    record["reference_source"]["release"] = "changed-after-resolution"
    record["conditions"][:] = ["type 1 diabetes"]
    record["display_label"] = "changed-after-resolution"
    assert asdict(context.profile) == expected
    assert {key: dict(value) for key, value in context.parameter_provenance.items()} == provenance


@pytest.mark.parametrize("condition", ["", "type 1 diabetes", "no diabetes", "unrelated description"])
def test_legacy_source_context_does_not_reselect_from_condition_text(condition):
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    record = _legacy_reference_record()
    expected = _expected_legacy_profile(record)
    record["conditions"] = [condition] if condition else []
    assert asdict(module.resolve_model_context(record).profile) == expected


@pytest.mark.parametrize("container,field,value,code", [
    ("reference_source", "source_id", "unreviewed-source", "MODEL_CONTEXT_SOURCE_MISMATCH"),
    ("reference_source", "release", "unreviewed-release", "MODEL_CONTEXT_SOURCE_MISMATCH"),
    ("reference_source", "role", "individual_measurement", "MODEL_CONTEXT_SOURCE_MISMATCH"),
    ("reference_lineage", "source_id", "unreviewed-source", "MODEL_CONTEXT_SOURCE_MISMATCH"),
    ("reference_lineage", "release", "unreviewed-release", "MODEL_CONTEXT_SOURCE_MISMATCH"),
    ("reference_lineage", "stratum", "nhanes-diagnosed-diabetes-older", "MODEL_CONTEXT_SOURCE_MISMATCH"),
    (None, "reference_stratum", "healthy", "MODEL_CONTEXT_UNSUPPORTED"),
    (None, "reference_stratum", None, "MODEL_CONTEXT_INVALID"),
])
def test_legacy_context_requires_exact_source_release_role_and_stratum(container, field, value, code):
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    record = _legacy_reference_record()
    target = record[container] if container else record
    target[field] = value
    with pytest.raises(module.ModelContextError) as caught:
        module.resolve_model_context(record)
    assert caught.value.code == code


@pytest.mark.parametrize("mutation", ["missing_parameter", "nonfinite_parameter", "boolean_parameter", "extra_parameter"])
def test_legacy_parameter_shape_cannot_silently_inherit_or_override_another_context(mutation):
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    record = _legacy_reference_record()
    if mutation == "missing_parameter":
        del record["model_parameters"]["Si"]
    elif mutation == "nonfinite_parameter":
        record["model_parameters"]["Si"] = float("nan")
    elif mutation == "boolean_parameter":
        record["model_parameters"]["Si"] = True
    else:
        record["model_parameters"]["p2"] = 0.01
    with pytest.raises(module.ModelContextError) as caught:
        module.resolve_model_context(record)
    assert caught.value.code == "MODEL_CONTEXT_INVALID"


def test_legacy_reference_labels_do_not_authorize_an_admitted_person_context():
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    record = _legacy_reference_record()
    record.update(source_class="REAL_HUMAN", model_binding=None)
    with pytest.raises(module.ModelContextError) as caught:
        module.resolve_model_context(record)
    assert caught.value.code == "MODEL_BINDING_REQUIRED"


@pytest.mark.parametrize("stratum", ["dpp-high-risk-metabolic", "nhanes-diagnosed-diabetes-older", "pxr-reference"])
def test_legacy_reference_retry_preserves_historical_provenance_hash(tmp_path, stratum):
    from livemorebio.aegle.subjects import SubjectRegistry
    from livemorebio.tests.clinical_registry_fixtures import KEY, TWIN_FIELDS, replace_fixture_record, saved_bytes
    registry = SubjectRegistry(tmp_path / "reference-retry.sqlite3", key=KEY)
    body = {"source_class": "REFERENCE_GROUNDED_SYNTHETIC", "subject_id": "pseudonym-reference-technical",
            "display_label": "Reference preservation fixture", "reference_source": {"role": "population_reference", "source_id": "livemore-public-metabolic-reference-v1"},
            "stratum": stratum, "seed": 17}
    record = registry.create_twin(body, idempotency_key="reference-key")
    units = {"weight_kg": "kg", "Gb": "mg/dL", "Ib": "uU/mL", "SG": "1/min", "p2": "1/min", "Si": "mL/uU/min", "gamma": "uU/mL/min/(mg/dL)", "Gt": "mg/dL", "n": "1/min", "ka": "1/min", "f_bioavail": "1", "vg_per_kg": "dL/kg"}
    parameters = {**record["model_parameters"], "p2": .025, "n": .14, "ka": .020, "f_bioavail": .75, "vg_per_kg": 2.0}
    historical = {field: {"evidence_class": "REFERENCE_INITIALIZED", "source_id": record["reference_source"]["source_id"] if field in record["model_parameters"] else ("livemore:type-2-diabetes" if stratum == "nhanes-diagnosed-diabetes-older" else "livemore:healthy-adult"),
                          "reason": "frozen research population parameter" if field in record["model_parameters"] else "unmeasured engine parameter; literature-typical reference prior",
                          "value": value, "unit": units[field]} for field, value in parameters.items()}
    record["parameter_provenance"] = historical
    replace_fixture_record(registry, record)
    with registry._connect() as connection:
        connection.execute("UPDATE records SET request_hash=? WHERE record_id=?", (sha({**{field: record[field] for field in TWIN_FIELDS}, "parameter_provenance": historical}), record["twin_id"]))
    before = saved_bytes(registry, record["twin_id"])
    assert registry.create_twin(body, idempotency_key="reference-key") == record
    assert saved_bytes(registry, record["twin_id"]) == before


def test_availability_cannot_relabel_public_source_as_synthetic_ready():
    module = importlib.import_module("livemorebio.aegle.model_contexts")
    record = {**legacy_twin_record(), "schema": "livemore.frozen-public-reference-member.v1", "source_class": "SYNTHETIC"}
    assert module.model_availability(record, source_generation="a" * 32)["state"] == "UNAVAILABLE"


@pytest.mark.parametrize("field,value", [("source_class", "REAL_HUMAN"), ("id", "pseudonym-different-technical")])
def test_resolved_reference_context_cannot_be_borrowed_by_another_human(field, value):
    from livemorebio.aegle.subjects import SubjectRegistry
    from livemorebio.aegle.clinical_parameters import initialize_profile
    from dataclasses import replace
    human = SubjectRegistry.admitted_human(_legacy_reference_record())
    forged = replace(human, **{field: value})
    with pytest.raises(ValueError) as caught:
        initialize_profile(forged)
    assert caught.value.code == "MODEL_CONTEXT_SOURCE_MISMATCH"
