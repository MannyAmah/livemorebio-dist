"""Observation-selection reconciliation in authored technical SQLite stores only."""
from __future__ import annotations

from contextlib import closing
from copy import deepcopy
import json
import sqlite3
from uuid import uuid4

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import pytest

from livemorebio.aegle.subjects import SubjectRegistry, SubjectRegistryError
from livemorebio.tests.clinical_registry_fixtures import (
    CAPTURED, KEY, forbid_compilation, legacy_twin_record, replace_fixture_record, seed_legacy,
)

AUDIT_AAD = b"livemore.subject-registry.audit.v1\0"


@pytest.fixture
def selected(tmp_path, monkeypatch):
    forbid_compilation(monkeypatch)
    registry = SubjectRegistry(tmp_path / "technical-reconciliation.sqlite3", key=KEY)
    record = legacy_twin_record()
    record["lifecycle"] = "ACTIVE"
    seed_legacy(registry, record)
    with closing(registry._connect()) as connection, connection:
        connection.execute("INSERT INTO registry_state VALUES('active_twin_id',?,?)",
                           (record["twin_id"], CAPTURED))
    return registry, record


def audit_events(registry, request_id):
    with sqlite3.connect(registry.path) as connection:
        rows = connection.execute("SELECT event_id,nonce,ciphertext FROM registry_audit ORDER BY sequence").fetchall()
    result = []
    for event_id, nonce, ciphertext in rows:
        payload = json.loads(AESGCM(KEY).decrypt(nonce, ciphertext, AUDIT_AAD + event_id.encode()))
        if payload["request_id"] == request_id:
            result.append((event_id, payload))
    return result


def preserved_rows(registry):
    with sqlite3.connect(registry.path) as connection:
        return tuple(connection.execute(f"SELECT * FROM {table} ORDER BY 1").fetchall()
                     for table in ("records", "registry_state", "subject_identifiers", "physical_device_bindings"))


def test_first_read_and_final_confirmation_share_request_not_event_ids(selected):
    registry, record = selected
    request_id = str(uuid4())
    before = preserved_rows(registry)
    expected = registry.audited_active_twin(action="reconcile_selection", request_id=request_id)
    assert expected == record
    first = audit_events(registry, request_id)
    assert registry.confirm_active_selection(expected_record=expected, request_id=request_id) is None
    events = audit_events(registry, request_id)
    assert len(first) == 2 and len(events) == 4 and events[:2] == first
    assert len({event_id for event_id, _ in events}) == 4
    assert [event["outcome_code"] for _, event in events] == [None, "SUCCESS", None, "SUCCESS"]
    assert all(event["action"] == "reconcile_selection" for _, event in events)
    assert preserved_rows(registry) == before
    with sqlite3.connect(registry.path) as connection:
        assert connection.execute("SELECT COUNT(*) FROM registry_audit_reservations").fetchone()[0] == 0


def test_final_decrypt_has_this_request_committed_begin_and_writer_transaction(selected, monkeypatch):
    registry, record = selected
    request_id = str(uuid4())
    original_open = registry._open
    original_checked = registry._checked_active_twin
    opened = []

    def guarded_checked(connection):
        assert connection.in_transaction
        return original_checked(connection)

    def guarded_open(row):
        events = audit_events(registry, request_id)
        assert len(events) == 1
        assert events[0][1]["action"] == "reconcile_selection"
        assert events[0][1]["outcome_code"] is None
        opened.append(row["record_id"])
        return original_open(row)

    monkeypatch.setattr(registry, "_open", guarded_open)
    monkeypatch.setattr(registry, "_checked_active_twin", guarded_checked)
    assert registry.confirm_active_selection(expected_record=record, request_id=request_id) is None
    assert opened == [record["twin_id"]]


@pytest.mark.parametrize("change", ["same_version_content", "version", "present_to_absent", "different_twin"])
def test_changed_selection_conflicts_without_mutation_or_success(selected, change):
    registry, record = selected
    expected = deepcopy(record)
    if change in {"same_version_content", "version"}:
        revised = deepcopy(record)
        revised["display_label"] = "Authored technical revised label"
        if change == "version":
            revised["version"] += 1
        replace_fixture_record(registry, revised)
    elif change == "present_to_absent":
        with closing(registry._connect()) as connection, connection:
            connection.execute("DELETE FROM registry_state WHERE state_key='active_twin_id'")
    else:
        other = legacy_twin_record("other")
        other["lifecycle"] = "ACTIVE"
        seed_legacy(registry, other)
        with closing(registry._connect()) as connection, connection:
            connection.execute("UPDATE registry_state SET state_value=? WHERE state_key='active_twin_id'", (other["twin_id"],))
    before = preserved_rows(registry)
    request_id = str(uuid4())
    with pytest.raises(SubjectRegistryError) as caught:
        registry.confirm_active_selection(expected_record=expected, request_id=request_id)
    assert caught.value.code == "SELECTION_RECONCILIATION_CONFLICT"
    assert preserved_rows(registry) == before
    assert [event["outcome_code"] for _, event in audit_events(registry, request_id)] == [None, "ACCESS_FAILED"]


def test_absent_to_present_conflicts(selected):
    registry, _ = selected
    before = preserved_rows(registry)
    with pytest.raises(SubjectRegistryError) as caught:
        registry.confirm_active_selection(expected_record=None, request_id=str(uuid4()))
    assert caught.value.code == "SELECTION_RECONCILIATION_CONFLICT"
    assert preserved_rows(registry) == before


def test_actual_absence_confirms_and_dict_key_order_does_not_change_identity(selected):
    registry, record = selected
    reordered = dict(reversed(list(record.items())))
    assert registry.confirm_active_selection(expected_record=reordered, request_id=str(uuid4())) is None
    with closing(registry._connect()) as connection, connection:
        connection.execute("DELETE FROM registry_state WHERE state_key='active_twin_id'")
    before = preserved_rows(registry)
    assert registry.confirm_active_selection(expected_record=None, request_id=str(uuid4())) is None
    assert preserved_rows(registry) == before


@pytest.mark.parametrize("request_id", [None, "", "invalid", " " + str(uuid4()), "AAAAAAAA-AAAA-4AAA-8AAA-AAAAAAAAAAAA", [], 1])
def test_bad_confirmation_request_identity_rejects_before_storage(selected, monkeypatch, request_id):
    registry, record = selected
    monkeypatch.setattr(registry, "_connect", lambda: pytest.fail("invalid request reached storage"))
    with pytest.raises(ValueError):
        registry.confirm_active_selection(expected_record=record, request_id=request_id)


@pytest.mark.parametrize("expected", [[], 1, "clinical text must not be in error", {"bad": float("nan")}])
def test_bad_expected_shape_rejects_before_storage(selected, monkeypatch, expected):
    registry, _ = selected
    monkeypatch.setattr(registry, "_connect", lambda: pytest.fail("invalid expected snapshot reached storage"))
    with pytest.raises(SubjectRegistryError) as caught:
        registry.confirm_active_selection(expected_record=expected, request_id=str(uuid4()))
    assert caught.value.code == "INVALID_RECONCILIATION_SNAPSHOT"
    assert "clinical text" not in str(caught.value)


@pytest.mark.parametrize("damage", ["missing", "wrong_type", "inactive", "wrong_payload_identity"])
def test_final_check_reuses_malformed_active_storage_guard(selected, damage):
    registry, record = selected
    with closing(registry._connect()) as connection, connection:
        if damage == "missing":
            connection.execute("UPDATE registry_state SET state_value='twin-missing' WHERE state_key='active_twin_id'")
        elif damage == "wrong_type":
            connection.execute("UPDATE records SET record_type='COHORT'")
        elif damage == "inactive":
            connection.execute("UPDATE records SET lifecycle='DATA_ADMITTED'")
        else:
            changed = {**record, "twin_id": "twin-substituted"}
            nonce, ciphertext = registry._seal(record["twin_id"], changed)
            connection.execute("UPDATE records SET nonce=?,ciphertext=?", (nonce, ciphertext))
    before = preserved_rows(registry)
    with pytest.raises(RuntimeError, match="Active subject storage is inconsistent"):
        registry.confirm_active_selection(expected_record=record, request_id=str(uuid4()))
    assert preserved_rows(registry) == before


@pytest.mark.parametrize("phase", ["begin", "finish"])
def test_audit_failure_never_confirms_selection(selected, monkeypatch, phase):
    registry, record = selected
    request_id = str(uuid4())
    before = preserved_rows(registry)
    def fail(*args, **kwargs):
        raise RuntimeError("Authored audit failure")
    monkeypatch.setattr(registry.audit, phase, fail)
    if phase == "begin":
        monkeypatch.setattr(registry, "_open", lambda row: pytest.fail("unaudited decrypt"))
    with pytest.raises(RuntimeError, match="Authored audit failure"):
        registry.confirm_active_selection(expected_record=record, request_id=request_id)
    assert preserved_rows(registry) == before
    assert not any(event["outcome_code"] == "SUCCESS" for _, event in audit_events(registry, request_id))


@pytest.mark.parametrize("persisted", [False, True])
def test_final_commit_failure_never_returns_confirmation(selected, monkeypatch, persisted):
    registry, record = selected
    request_id = str(uuid4())
    before = preserved_rows(registry)

    class FailingAcknowledgment(sqlite3.Connection):
        commits = 0

        def commit(self):
            self.commits += 1
            if self.commits == 2:
                if persisted:
                    super().commit()
                raise RuntimeError("Authored missing commit acknowledgment")
            return super().commit()

    def connect():
        connection = sqlite3.connect(registry.path, factory=FailingAcknowledgment)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    monkeypatch.setattr(registry, "_connect", connect)
    with pytest.raises(RuntimeError, match="Authored missing commit acknowledgment"):
        registry.confirm_active_selection(expected_record=record, request_id=request_id)
    assert preserved_rows(registry) == before
    outcomes = [event["outcome_code"] for _, event in audit_events(registry, request_id)]
    assert outcomes == [None, "SUCCESS" if persisted else "ACCESS_FAILED"]
    # Even a durable audit result does not make this lost acknowledgment a return
    # value; the authority owner must stay DENY_ALL after the raised exception.


def test_expected_snapshot_is_detached_before_access_starts(selected, monkeypatch):
    registry, record = selected
    expected = deepcopy(record)
    changed = {**record, "display_label": "Authored same-version mutation"}
    replace_fixture_record(registry, changed)
    original_begin = registry.audit.begin

    def begin(*args, **kwargs):
        expected.update(changed)
        return original_begin(*args, **kwargs)

    monkeypatch.setattr(registry.audit, "begin", begin)
    with pytest.raises(SubjectRegistryError) as caught:
        registry.confirm_active_selection(expected_record=expected, request_id=str(uuid4()))
    assert caught.value.code == "SELECTION_RECONCILIATION_CONFLICT"
