from __future__ import annotations

import base64
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from datetime import datetime, timezone
import os
import urllib.error
from types import SimpleNamespace

import pytest


def _patch_authenticated_open(monkeypatch, open_request):
    monkeypatch.setattr("livemorebio.transport.authenticated_opener",
                        lambda: SimpleNamespace(open=open_request))


NOW = datetime(2026, 8, 29, 14, 30, tzinfo=timezone.utc)
TEST_STORAGE_KEY = base64.urlsafe_b64encode(b"s" * 32).decode("ascii")
TEST_ADMISSION_KEY = base64.urlsafe_b64encode(b"a" * 32).decode("ascii")


def test_aegle_http_rejection_is_not_mislabeled_as_queued(monkeypatch):
    from livemorebio.life_system import service as life_service
    from livemorebio.service_identity import IdentitySnapshot
    from livemorebio.stack_proof import configure_test_identity
    from livemorebio.stack_transport import StackResponse

    monkeypatch.setenv("LIVEMORE_AEGLE_URL", "http://aegle.invalid")
    monkeypatch.setenv("LIVEMORE_AEGLE_IDENTITY_AUTHORITY", "http://aegle.invalid:80")
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "closed-loop-test-token")
    monkeypatch.setattr(life_service.app.state, "stack_proof", life_service.app.state.stack_proof)
    configure_test_identity(life_service.app, IdentitySnapshot(b"T" * 32, "life", "http://testserver:80"))

    def reject(*args, **kwargs):
        return StackResponse(422, "Unprocessable Entity", (), b"")

    monkeypatch.setattr("livemorebio.stack_transport.request", reject)

    result = life_service._forward_to_aegle({"synthetic": "envelope"})

    assert result == {
        "status": "rejected",
        "http_status": 422,
        "reason": "Aegle rejected telemetry",
    }


def test_aegle_transport_failure_remains_durably_queued(monkeypatch):
    from livemorebio.life_system import service as life_service
    from livemorebio.service_identity import IdentitySnapshot
    from livemorebio.stack_proof import configure_test_identity

    monkeypatch.setenv("LIVEMORE_AEGLE_URL", "http://aegle.invalid")
    monkeypatch.setenv("LIVEMORE_AEGLE_IDENTITY_AUTHORITY", "http://aegle.invalid:80")
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "closed-loop-test-token")
    monkeypatch.setattr(life_service.app.state, "stack_proof", life_service.app.state.stack_proof)
    configure_test_identity(life_service.app, IdentitySnapshot(b"T" * 32, "life", "http://testserver:80"))
    monkeypatch.setattr(
        "livemorebio.stack_transport.request",
        lambda *args, **kwargs: (_ for _ in ()).throw(
            urllib.error.URLError("connection refused")
        ),
    )

    result = life_service._forward_to_aegle({"synthetic": "envelope"})

    assert result["status"] == "queued"
    assert "journaled" in result["reason"]


def test_commercial_adapters_require_recorded_entitlement(monkeypatch):
    from livemorebio import adapters

    monkeypatch.setenv("LIVEMORE_KEGG_COMMERCIAL_LICENSE", "acknowledged")
    monkeypatch.delenv("LIVEMORE_KEGG_LICENSE_ID", raising=False)
    monkeypatch.setenv("LIVEMORE_GENECARDS_COMMERCIAL_LICENSE", "acknowledged")
    monkeypatch.setenv("LIVEMORE_GENECARDS_LICENSE_ID", "GC-tenant-license")
    monkeypatch.delenv("LIVEMORE_GENECARDS_API_BASE", raising=False)
    monkeypatch.delenv("GENECARDS_API_TOKEN", raising=False)

    rows = {row["id"]: row for row in adapters.statuses()}

    assert rows["kegg"]["status"] == "blocked"
    assert "LIVEMORE_KEGG_LICENSE_ID" in rows["kegg"]["reason"]
    assert rows["genecards"]["status"] == "blocked"
    assert "LIVEMORE_GENECARDS_API_BASE" in rows["genecards"]["reason"]
    assert "GC-tenant-license" not in repr(rows)


def test_commercial_adapters_become_configured_without_exposing_secrets(monkeypatch):
    from livemorebio import adapters

    monkeypatch.setenv("LIVEMORE_KEGG_COMMERCIAL_LICENSE", "acknowledged")
    monkeypatch.setenv("LIVEMORE_KEGG_LICENSE_ID", "KEGG-private-license")
    monkeypatch.setenv("LIVEMORE_KEGG_API_BASE", "https://licensed.example/kegg/")
    monkeypatch.setenv("LIVEMORE_KEGG_APPROVED_HOST", "licensed.example")
    monkeypatch.setenv("LIVEMORE_GENECARDS_COMMERCIAL_LICENSE", "acknowledged")
    monkeypatch.setenv("LIVEMORE_GENECARDS_LICENSE_ID", "GC-private-license")
    monkeypatch.setenv("LIVEMORE_GENECARDS_API_BASE", "https://licensed.example/api/")
    monkeypatch.setenv("GENECARDS_API_TOKEN", "top-secret")

    rows = {row["id"]: row for row in adapters.statuses()}

    assert rows["kegg"]["status"] == "configured"
    assert rows["kegg"]["enabled"] is True
    assert rows["genecards"]["status"] == "configured"
    assert rows["genecards"]["enabled"] is True
    rendered = repr(rows)
    assert "private-license" not in rendered
    assert "top-secret" not in rendered


def test_kegg_and_genecards_make_no_request_without_entitlement(monkeypatch, tmp_path):
    from livemorebio.life_system.reference.sources.genecards import GeneCards
    from livemorebio.life_system.reference.sources.kegg import KEGG

    calls: list[object] = []
    for name in (
        "LIVEMORE_KEGG_COMMERCIAL_LICENSE",
        "LIVEMORE_KEGG_LICENSE_ID",
        "LIVEMORE_GENECARDS_COMMERCIAL_LICENSE",
        "LIVEMORE_GENECARDS_LICENSE_ID",
        "LIVEMORE_GENECARDS_API_BASE",
        "GENECARDS_API_TOKEN",
    ):
        monkeypatch.delenv(name, raising=False)
    _patch_authenticated_open(monkeypatch, lambda *args, **kwargs: calls.append(args))

    assert KEGG(cache_dir=str(tmp_path)).human_pathways() == []
    assert GeneCards(cache_dir=str(tmp_path)).gene("TP53") is None
    assert calls == []


def test_scientific_reference_cache_is_owner_only(monkeypatch, tmp_path):
    from livemorebio.life_system.reference.sources.base import Source

    class Response:
        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def read(self):
            return b'{"record":"licensed reference context"}'

    class LicensedSource(Source):
        name = "licensed"
        base = "https://www.ebi.ac.uk/ols4/api/"  # L0-R16: a destination route the egress check admits

    monkeypatch.setattr("urllib.request.urlopen", lambda *args, **kwargs: Response())
    source = LicensedSource(cache_dir=str(tmp_path / "reference-cache"))

    assert source.fetch("ontologies")["record"] == "licensed reference context"
    cache_file = next((tmp_path / "reference-cache").glob("*.cache"))
    assert os.stat(cache_file.parent).st_mode & 0o077 == 0
    assert os.stat(cache_file).st_mode & 0o077 == 0


def test_scientific_source_error_never_echoes_query_credentials(monkeypatch, tmp_path):
    from livemorebio.life_system.reference.sources.base import Source

    class CredentialedSource(Source):
        base = "https://api.nal.usda.gov/fdc/v1/"  # L0-R16: a credential-gated route the check admits
    secret = "supersecret" + "0" * 29  # a key in the api.data.gov form
    def unavailable(*args, **kwargs):
        raise OSError("network failed while using " + secret)

    monkeypatch.setattr("urllib.request.urlopen", unavailable)
    result = CredentialedSource(cache_dir=str(tmp_path)).fetch(
        "foods/search", params={"query": "turmeric", "pageSize": 1, "api_key": secret},
    )

    assert result == {"_error": "OSError", "_url": "https://api.nal.usda.gov/fdc/v1/foods/search"}
    assert secret not in repr(result)


def test_genecards_replays_licensed_cache_while_offline(monkeypatch, tmp_path):
    from livemorebio.life_system.reference.sources.genecards import GeneCards

    monkeypatch.setenv("LIVEMORE_GENECARDS_COMMERCIAL_LICENSE", "acknowledged")
    monkeypatch.setenv("LIVEMORE_GENECARDS_LICENSE_ID", "GC-test-license")
    monkeypatch.setenv("LIVEMORE_GENECARDS_API_BASE", "https://licensed.example/api/")
    monkeypatch.setenv("GENECARDS_API_TOKEN", "provider-secret")

    class Response:
        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def read(self):
            return b'{"symbol":"TP53","summary":"licensed cache record"}'

    _patch_authenticated_open(monkeypatch, lambda *args, **kwargs: Response())
    online = GeneCards(cache_dir=str(tmp_path))
    assert online.gene("TP53")["symbol"] == "TP53"

    def network_forbidden(*args, **kwargs):
        raise AssertionError("offline cache replay attempted a network request")

    _patch_authenticated_open(monkeypatch, network_forbidden)
    offline = GeneCards(offline=True, cache_dir=str(tmp_path))
    assert offline.gene("TP53")["summary"] == "licensed cache record"


def test_attach_mode_sends_operator_auth_on_protected_reads(monkeypatch):
    from livemorebio.sdk import Platform
    from livemorebio.tests.stack_client_fixtures import install_stack_client_opener

    captured = {}

    class Response:
        status = 200

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def read(self):
            return b'{"profile":"healthy"}'

    def open_request(request, timeout):
        captured["authorization"] = request.get_header("Authorization")
        return Response()

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "attach-protected-token")
    monkeypatch.setattr(Platform, "_url", lambda self: "http://127.0.0.1:9999")
    install_stack_client_opener(monkeypatch, lambda: SimpleNamespace(open=open_request))

    assert Platform(mode="attach")._get("/api/state") == {"profile": "healthy"}
    assert captured["authorization"] == "Bearer attach-protected-token"


def test_life_gene_context_is_authenticated_hashed_and_reference_only(monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.life_system.service import app

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "closed-loop-token")
    for name in (
        "LIVEMORE_KEGG_COMMERCIAL_LICENSE",
        "LIVEMORE_KEGG_LICENSE_ID",
        "LIVEMORE_GENECARDS_COMMERCIAL_LICENSE",
        "LIVEMORE_GENECARDS_LICENSE_ID",
        "LIVEMORE_GENECARDS_API_BASE",
        "GENECARDS_API_TOKEN",
    ):
        monkeypatch.delenv(name, raising=False)
    client = TestClient(app)

    assert client.get("/reference/genes/TP53").status_code == 401
    response = client.get(
        "/reference/genes/TP53",
        headers={"Authorization": "Bearer closed-loop-token"},
    )

    assert response.status_code == 200
    assert response.json()["scientific_role"] == "reference_context_only"
    assert response.json()["validation_effect"].startswith("none")
    assert len(response.json()["record_sha256"]) == 64


def test_physical_and_virtual_patch_share_one_contract():
    from livemorebio.life_patch.protocol import DeviceMode, manifest_for

    physical = manifest_for("patch-physical-001", DeviceMode.PHYSICAL)
    virtual = manifest_for("patch-virtual-001", DeviceMode.VIRTUAL)

    assert physical.hardware_revision == "B0-EVT-target"
    assert physical.protocol_version == virtual.protocol_version
    assert physical.capability_hash == virtual.capability_hash
    assert physical.mode is DeviceMode.PHYSICAL
    assert virtual.mode is DeviceMode.VIRTUAL
    assert "LMP91000" not in repr(physical)
    assert "MAX86141:SPI" in repr(physical)


def test_patch_admission_rejects_tampering_and_replay():
    from livemorebio.life_patch.protocol import (
        DeviceMode,
        PatchAdmissionController,
        ProtocolViolation,
        VirtualLifePatch,
        manifest_for,
    )

    device = VirtualLifePatch(manifest_for("virtual-001", DeviceMode.VIRTUAL))
    envelope = device.emit(
        "pseudonym-001",
        {"glucose_mgdl": 123.0, "hr_bpm": 72.0},
        captured_at=NOW,
    )
    controller = PatchAdmissionController(now=lambda: NOW)

    admitted = controller.admit(device.manifest, envelope)

    assert admitted.envelope_hash == envelope.envelope_hash
    with pytest.raises(ProtocolViolation, match="replayed"):
        controller.admit(device.manifest, envelope)
    tampered = replace(envelope, device_id="another-device", envelope_hash="")
    with pytest.raises(ProtocolViolation, match="device"):
        PatchAdmissionController(now=lambda: NOW).admit(device.manifest, tampered)


def test_patch_contract_rejects_string_booleans_and_path_like_subjects():
    from livemorebio.life_patch.protocol import (
        DeviceMode,
        ProtocolViolation,
        VirtualLifePatch,
        manifest_for,
    )

    device = VirtualLifePatch(manifest_for("virtual-001", DeviceMode.VIRTUAL))
    payload = device.emit(
        "pseudonym-001", {"glucose_mgdl": 123.0}, captured_at=NOW,
    ).to_dict()
    payload["subject_pseudonymized"] = "false"
    from livemorebio.life_patch.protocol import TelemetryEnvelope
    with pytest.raises(ProtocolViolation, match="JSON boolean"):
        TelemetryEnvelope.from_dict(payload)

    payload["subject_pseudonymized"] = True
    payload["subject_id"] = "../../../registry"
    payload["envelope_hash"] = ""
    with pytest.raises(ProtocolViolation, match="structured identifier"):
        TelemetryEnvelope.from_dict(payload)

    payload["subject_id"] = "subject123456"  # L0-R16: "MRN123456" is a screen mark now (end of file)
    payload["envelope_hash"] = ""
    with pytest.raises(ProtocolViolation, match="pseudonym"):
        TelemetryEnvelope.from_dict(payload)


def test_physical_gateway_requires_provisioned_hardware_manifest():
    from livemorebio.life_patch.protocol import (
        DeviceMode,
        PhysicalPatchGateway,
        ProtocolViolation,
        manifest_for,
    )

    with pytest.raises(ProtocolViolation, match="provisioned"):
        PhysicalPatchGateway(manifest_for("physical-001", DeviceMode.PHYSICAL))


def test_life_requires_trusted_attestation_for_physical_device_registration(
    monkeypatch, tmp_path,
):
    from fastapi.testclient import TestClient
    from livemorebio.life_patch.protocol import DeviceManifest, DeviceMode
    from livemorebio.life_system import service as life_service
    from livemorebio.security import sign_device_manifest

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "closed-loop-token")
    monkeypatch.setenv("LIVEMORE_PATCH_ADMISSION_HMAC_KEY", TEST_ADMISSION_KEY)
    monkeypatch.setenv("LIVEMORE_PATCH_JOURNAL", str(tmp_path / "telemetry.jsonl"))
    life_service._c.clear()
    client = TestClient(life_service.app)
    headers = {"Authorization": "Bearer closed-loop-token"}
    manifest = DeviceManifest(
        device_id="physical-api-001",
        mode=DeviceMode.PHYSICAL,
        hardware_revision="B0-EVT-target",
        firmware_version="firmware-2.0.0",
        hardware_present=True,
    ).to_dict()

    unsigned = client.post("/patch/devices", headers=headers, json=manifest)
    signed = client.post(
        "/patch/devices",
        headers={
            **headers,
            "X-Livemore-Device-Attestation": sign_device_manifest(manifest),
        },
        json=manifest,
    )

    assert unsigned.status_code == 422
    assert unsigned.json()["code"] == "PATCH_REGISTRATION_REJECTED"
    assert signed.status_code == 201


def test_life_virtual_sample_requires_explicit_bound_identity(monkeypatch, tmp_path):
    from fastapi.testclient import TestClient
    from livemorebio.life_system import service as life_service

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "closed-loop-token")
    monkeypatch.setenv("LIVEMORE_PATCH_ADMISSION_HMAC_KEY", TEST_ADMISSION_KEY)
    monkeypatch.setenv("LIVEMORE_PATCH_JOURNAL", str(tmp_path / "telemetry.jsonl"))
    life_service._c.clear()
    client = TestClient(life_service.app)

    response = client.post(
        "/patch/virtual/sample",
        headers={"Authorization": "Bearer closed-loop-token"},
        json={"readings": {"glucose_mgdl": 110.0}},
    )

    assert response.status_code == 422
    assert response.json()["code"] == "PATCH_VIRTUAL_REQUEST_REJECTED"


def test_patch_command_parameters_are_bounded():
    from livemorebio.life_patch.protocol import PatchCommand, ProtocolViolation

    with pytest.raises(ProtocolViolation, match="duration"):
        PatchCommand(
            command_id="command-001",
            device_id="virtual-001",
            command="request_burst",
            parameters={"duration_seconds": 301, "channels": ["ecg"]},
            issued_at=NOW,
            expires_at=NOW.replace(minute=31),
        )


def test_admitted_patch_observation_does_not_recalibrate_live_twin():
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.life_patch.protocol import DeviceMode, VirtualLifePatch, manifest_for

    twin = AegleTwin("healthy")
    before = twin.state()["profile_params"]
    device = VirtualLifePatch(manifest_for("virtual-001", DeviceMode.VIRTUAL))
    envelope = device.emit(
        "pseudonym-001",
        {"glucose_mgdl": 240.0, "hr_bpm": 105.0},
        captured_at=NOW,
    )

    state = twin.ingest_patch_envelope(envelope)

    assert state["profile_params"] == before
    assert state["observations"]["glucose_mgdl"]["value"] == 240.0
    assert state["observations"]["hr_bpm"]["value"] == 105.0
    assert state["patch"]["mode"] == "virtual"
    assert state["capability"]["maturity"]["person_calibrated"] is False


def test_patch_measurements_map_to_evidence_inputs_but_not_validation():
    from livemorebio.evidence import MeasurementRole, SourceDataClass
    from livemorebio.life_patch.evidence import to_evidence_measurements
    from livemorebio.life_patch.protocol import DeviceMode, VirtualLifePatch, manifest_for

    device = VirtualLifePatch(manifest_for("virtual-001", DeviceMode.VIRTUAL))
    envelope = device.emit(
        "pseudonym-001", {"glucose_mgdl": 111.0}, captured_at=NOW,
    )

    measurements = to_evidence_measurements(
        envelope,
        tenant_id="livemore",
        received_at=NOW,
    )

    assert len(measurements) == 1
    assert measurements[0].role is MeasurementRole.BASELINE_INPUT
    assert measurements[0].payload.source_data_class is SourceDataClass.SYNTHETIC
    assert measurements[0].payload.endpoint == "glucose_mgdl"


def test_real_human_patch_evidence_requires_consent_and_custody():
    from livemorebio.evidence.errors import DomainValidationError
    from livemorebio.life_patch.evidence import to_evidence_measurements
    from livemorebio.life_patch.protocol import (
        DeviceManifest,
        DeviceMode,
        PhysicalPatchGateway,
        TelemetryEnvelope,
        TelemetryMeasurement,
    )

    manifest = DeviceManifest(
        device_id="physical-evidence-001",
        mode=DeviceMode.PHYSICAL,
        hardware_revision="B0-EVT-target",
        firmware_version="firmware-2.0.0",
        hardware_present=True,
    )
    envelope = PhysicalPatchGateway(manifest).decode_telemetry(TelemetryEnvelope(
        envelope_id="telemetry-physical-evidence-001",
        device_id=manifest.device_id,
        subject_id="pseudonym-001",
        sequence=1,
        captured_at=NOW,
        mode=DeviceMode.PHYSICAL,
        measurements=(TelemetryMeasurement(
            signal="hr_bpm", value=72.0, unit="bpm", claim="direct",
        ),),
    ).to_dict())

    with pytest.raises(DomainValidationError, match="consent"):
        to_evidence_measurements(envelope, tenant_id="livemore", received_at=NOW)
    with pytest.raises(DomainValidationError, match="custody"):
        to_evidence_measurements(
            envelope,
            tenant_id="livemore",
            received_at=NOW,
            consent_scope=("research-validation",),
        )


def test_qualified_lab_result_requires_qc_calibration_and_custody():
    from livemorebio.cendos.counterparts import LabResult, to_evidence_measurement
    from livemorebio.evidence import AssessmentStatus
    from livemorebio.evidence.errors import DomainValidationError

    unsafe = LabResult(
        result_id="lab-result-001",
        subject_id="pseudonym-001",
        endpoint="glucose_mgdl",
        value=110.0,
        unit="mg/dL",
        measured_at=NOW,
        received_at=NOW,
        instrument_id="analyzer-001",
        method="validated hexokinase assay",
        quality_status=AssessmentStatus.PASS,
        calibration_status=AssessmentStatus.PASS,
        chain_of_custody=(),
        consent_scope=("research-validation",),
    )

    with pytest.raises(DomainValidationError, match="custody"):
        to_evidence_measurement(unsafe, tenant_id="livemore", sequence=1)

    result = replace(unsafe, chain_of_custody=("accession:ABC123", "plate:P01"))
    measurement = to_evidence_measurement(result, tenant_id="livemore", sequence=1)

    assert measurement.payload.quality_status is AssessmentStatus.PASS
    assert measurement.payload.calibration_status is AssessmentStatus.PASS
    assert measurement.payload.chain_of_custody == ("accession:ABC123", "plate:P01")


def test_life_gateway_registers_forwards_and_journals_telemetry(monkeypatch, tmp_path):
    from fastapi.testclient import TestClient
    from livemorebio.life_patch.protocol import DeviceMode, VirtualLifePatch, manifest_for
    from livemorebio.life_system import service as life_service

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "closed-loop-token")
    monkeypatch.setenv("LIVEMORE_PATCH_ADMISSION_HMAC_KEY", TEST_ADMISSION_KEY)
    monkeypatch.setenv("LIVEMORE_PATCH_JOURNAL", str(tmp_path / "telemetry.jsonl"))
    monkeypatch.setattr(life_service, "_forward_to_aegle", lambda payload: {"status": "delivered"})
    monkeypatch.setattr("livemorebio.bus.publish", lambda *args, **kwargs: {})
    snapshots = {}
    monkeypatch.setattr(
        "livemorebio.bus.set_snapshot",
        lambda key, value: snapshots.__setitem__(key, value),
    )
    life_service._c.clear()
    client = TestClient(life_service.app)
    headers = {"Authorization": "Bearer closed-loop-token"}
    device = VirtualLifePatch(manifest_for("virtual-api-001", DeviceMode.VIRTUAL))
    envelope = device.emit(
        "pseudonym-001", {"glucose_mgdl": 131.0}, captured_at=datetime.now(timezone.utc)
    )

    registered = client.post("/patch/devices", headers=headers, json=device.manifest.to_dict())
    admitted = client.post("/patch/telemetry", headers=headers, json=envelope.to_dict())
    unauthenticated = client.get("/patch/telemetry?subject_id=pseudonym-001")
    journal = client.get("/patch/telemetry?subject_id=pseudonym-001", headers=headers)

    assert registered.status_code == 201
    assert admitted.status_code == 202
    assert admitted.json()["admission"] == "accepted"
    assert admitted.json()["aegle"] == {"status": "delivered"}
    assert unauthenticated.status_code == 401
    assert journal.status_code == 200
    assert journal.json()["telemetry"][0]["envelope_hash"] == envelope.envelope_hash
    from livemorebio.life_patch.protocol import envelope_snapshot_key
    assert snapshots[envelope_snapshot_key(envelope.envelope_hash)]["subject_id"] == (
        "pseudonym-001"
    )


def test_life_command_broker_only_allows_safe_bidirectional_commands(monkeypatch, tmp_path):
    from fastapi.testclient import TestClient
    from livemorebio.life_system import service as life_service

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "closed-loop-token")
    monkeypatch.setenv("LIVEMORE_PATCH_ADMISSION_HMAC_KEY", TEST_ADMISSION_KEY)
    monkeypatch.setenv("LIVEMORE_PATCH_JOURNAL", str(tmp_path / "telemetry.jsonl"))
    life_service._c.clear()
    client = TestClient(life_service.app)
    headers = {"Authorization": "Bearer closed-loop-token"}
    from livemorebio.life_patch.protocol import DeviceMode, manifest_for
    manifest = manifest_for("virtual-api-001", DeviceMode.VIRTUAL)
    assert client.post("/patch/devices", headers=headers, json=manifest.to_dict()).status_code == 201

    safe = client.post(
        "/patch/commands",
        headers=headers,
        json={"command_id": "quality-check-001", "device_id": "virtual-api-001", "command": "request_quality_check", "parameters": {}},
    )
    repeated = client.post(
        "/patch/commands",
        headers=headers,
        json={"command_id": "quality-check-001", "device_id": "virtual-api-001", "command": "request_quality_check", "parameters": {}},
    )
    unsafe = client.post(
        "/patch/commands",
        headers=headers,
        json={"device_id": "virtual-api-001", "command": "deliver_drug", "parameters": {}},
    )

    assert safe.status_code == 201
    assert repeated.status_code == 201
    assert repeated.json()["command_id"] == safe.json()["command_id"]
    assert unsafe.status_code == 422
    assert "safety allowlist" in unsafe.json()["error"]


def test_command_broker_idempotency_is_atomic_under_concurrency(monkeypatch, tmp_path):
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import DeviceMode, manifest_for

    gateway = LifePatchGateway(str(tmp_path / "telemetry.jsonl"))
    gateway.register(manifest_for("virtual-api-001", DeviceMode.VIRTUAL))

    def issue():
        return gateway.issue_command(
            command_id="quality-check-concurrent",
            device_id="virtual-api-001",
            command="request_quality_check",
            parameters={},
        )

    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(lambda _: issue(), range(24)))

    command_rows = [
        row for row in gateway.commands(device_id="virtual-api-001")
        if row.get("record_type") == "command"
    ]
    assert {item.command_id for item in results} == {"quality-check-concurrent"}
    assert len(command_rows) == 1


def test_aegle_v2_patch_endpoint_keeps_model_parameters_immutable(monkeypatch, tmp_path):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.life_patch.protocol import DeviceMode, VirtualLifePatch, manifest_for
    from livemorebio.security import sign_patch_admission

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "closed-loop-token")
    monkeypatch.setenv("LIVEMORE_PATCH_ADMISSION_HMAC_KEY", TEST_ADMISSION_KEY)
    monkeypatch.setenv("LIVEMORE_PATCH_STORAGE_KEY", TEST_STORAGE_KEY)
    monkeypatch.setenv("LIVEMORE_SUBJECT_REGISTRY", str(tmp_path / "subjects.sqlite3"))
    monkeypatch.setattr(server, "_subject_registry_instance", None)
    monkeypatch.setattr(server, "_snapshot_twin", lambda *args, **kwargs: None)
    registry = server._subject_registry()
    created = registry.create_twin({
        "source_class": "SYNTHETIC",
        "subject_id": "pseudonym-001",
        "display_label": "Patch admission fixture",
        "demographics": {"age": 50, "sex": "U"},
    })
    active = registry.activate_twin(created["twin_id"], expected_version=created["version"])
    bound = registry.bind_patch(
        active["twin_id"],
        {"device_id": "virtual-aegle-001", "mode": "virtual"},
        expected_version=active["version"],
    )
    server._state["tw"] = registry.build_twin(bound)
    server._state["subject"] = server._subject_summary(bound)
    server._patch_admission = None
    before = server._state["tw"].state()["profile_params"]
    device = VirtualLifePatch(manifest_for("virtual-aegle-001", DeviceMode.VIRTUAL))
    envelope = device.emit(
        "pseudonym-001", {"glucose_mgdl": 222.0}, captured_at=datetime.now(timezone.utc)
    )

    admission = {
        "admission": "accepted",
        "admitted_at": datetime.now(timezone.utc).isoformat(),
        "device_id": envelope.device_id,
        "mode": envelope.mode.value,
        "envelope_hash": envelope.envelope_hash,
        "capability_hash": device.manifest.capability_hash,
    }
    client = TestClient(server.app)
    direct = client.post(
        "/api/patch/telemetry",
        headers={"Authorization": "Bearer closed-loop-token"},
        json=envelope.to_dict(),
    )
    response = client.post(
        "/api/patch/telemetry",
        headers={"Authorization": "Bearer closed-loop-token"},
        json={
            "envelope": envelope.to_dict(),
            "admission": admission,
            "admission_signature": sign_patch_admission(admission),
        },
    )

    wrong_capability_envelope = replace(envelope, sequence=1, envelope_hash="")
    wrong_capability_admission = {
        **admission,
        "envelope_hash": wrong_capability_envelope.envelope_hash,
        "capability_hash": "0" * 64,
    }
    wrong_capability = client.post(
        "/api/patch/telemetry",
        headers={"Authorization": "Bearer closed-loop-token"},
        json={
            "envelope": wrong_capability_envelope.to_dict(),
            "admission": wrong_capability_admission,
            "admission_signature": sign_patch_admission(wrong_capability_admission),
        },
    )

    wrong_subject_envelope = device.emit(
        "pseudonym-other", {"glucose_mgdl": 111.0}, captured_at=datetime.now(timezone.utc)
    )
    wrong_subject_admission = {
        **admission,
        "envelope_hash": wrong_subject_envelope.envelope_hash,
    }
    wrong_subject = client.post(
        "/api/patch/telemetry",
        headers={"Authorization": "Bearer closed-loop-token"},
        json={
            "envelope": wrong_subject_envelope.to_dict(),
            "admission": wrong_subject_admission,
            "admission_signature": sign_patch_admission(wrong_subject_admission),
        },
    )

    assert direct.status_code == 422
    assert "LIFE-admitted" in direct.json()["error"]
    assert wrong_capability.status_code == 422
    assert "capability hash" in wrong_capability.json()["error"]
    assert wrong_subject.status_code == 422
    assert "subject does not match" in wrong_subject.json()["error"]
    assert response.status_code == 202
    assert response.json()["profile_params"] == before
    assert response.json()["observations"]["glucose_mgdl"]["value"] == 222.0

    forwarded: list[dict] = []
    monkeypatch.setattr(
        server,
        "_forward_virtual_patch",
        lambda body: forwarded.append(body) or (202, {"unexpected": True}),
    )
    changed = client.post(
        "/api/stimulate",
        headers={"Authorization": "Bearer closed-loop-token"},
        json={"kind": "base", "params": {"base": "healthy"}},
    )
    changed_parameters = server._state["tw"].state()["profile_params"]
    stale_sample = client.post(
        "/api/patch/virtual",
        headers={"Authorization": "Bearer closed-loop-token"},
        json={"subject_id": "pseudonym-001", "device_id": "virtual-aegle-001"},
    )

    assert changed.status_code == 200
    assert server._state["subject"] is None
    assert stale_sample.status_code == 409
    assert stale_sample.json()["code"] == "MODEL_SOURCE_CHANGED"
    assert forwarded == []
    assert server._state["tw"].state()["profile_params"] == changed_parameters


def test_aegle_observations_are_bound_to_one_envelope_not_merged():
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.life_patch.protocol import DeviceMode, VirtualLifePatch, manifest_for

    twin = AegleTwin("healthy")
    device = VirtualLifePatch(manifest_for("virtual-aegle-001", DeviceMode.VIRTUAL))
    first = device.emit(
        "pseudonym-001", {"glucose_mgdl": 222.0}, captured_at=NOW,
    )
    second = device.emit(
        "pseudonym-002", {"hr_bpm": 74.0}, captured_at=NOW,
    )

    twin.ingest_patch_envelope(first)
    state = twin.ingest_patch_envelope(second)

    assert set(state["observations"]) == {"hr_bpm"}
    assert state["observations"]["hr_bpm"]["envelope_id"] == second.envelope_id
    assert state["patch"]["envelope_id"] == second.envelope_id
    assert state["patch"]["device_id"] == second.device_id


def test_cendos_exposes_only_admitted_patch_snapshot(monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.cendos.service import app
    from livemorebio.life_patch.protocol import envelope_snapshot_key

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "closed-loop-token")
    older_snapshot = {
        "admission": "accepted",
        "subject_id": "pseudonym-001",
        "envelope_hash": "a" * 64,
    }
    newer_snapshot = {
        "admission": "accepted",
        "subject_id": "pseudonym-001",
        "envelope_hash": "b" * 64,
    }
    snapshots = {
        envelope_snapshot_key("a" * 64): older_snapshot,
        envelope_snapshot_key("b" * 64): newer_snapshot,
    }
    monkeypatch.setattr("livemorebio.bus.snapshot", snapshots.get)

    client = TestClient(app)
    assert client.get(
        "/patch/latest?subject_id=pseudonym-001&envelope_hash=" + "a" * 64
    ).status_code == 401
    response = client.get(
        "/patch/latest?subject_id=pseudonym-001&envelope_hash=" + "a" * 64,
        headers={"Authorization": "Bearer closed-loop-token"},
    )

    assert response.status_code == 200
    assert response.json()["telemetry"] == older_snapshot


def test_real_human_patch_journal_is_encrypted_at_rest(monkeypatch, tmp_path):
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import (
        DeviceManifest,
        DeviceMode,
        PhysicalPatchGateway,
        TelemetryEnvelope,
        TelemetryMeasurement,
    )

    monkeypatch.setenv("LIVEMORE_PATCH_STORAGE_KEY", TEST_STORAGE_KEY)
    journal = tmp_path / "physical.jsonl"
    manifest = DeviceManifest(
        device_id="physical-001",
        mode=DeviceMode.PHYSICAL,
        hardware_revision="B0-EVT-target",
        firmware_version="firmware-2.0.0",
        hardware_present=True,
    )
    gateway = LifePatchGateway(str(journal))
    gateway.register(manifest)
    envelope = PhysicalPatchGateway(manifest).decode_telemetry(TelemetryEnvelope(
        envelope_id="telemetry-physical-001",
        device_id="physical-001",
        subject_id="pseudonym-001",
        sequence=1,
        captured_at=datetime.now(timezone.utc),
        mode=DeviceMode.PHYSICAL,
        measurements=(TelemetryMeasurement(
            signal="hr_bpm", value=72.0, unit="bpm", claim="direct",
        ),),
    ).to_dict())

    gateway.admit(envelope)

    raw = journal.read_text(encoding="utf-8")
    assert "pseudonym-001" not in raw
    assert "72.0" not in raw
    assert gateway.latest("pseudonym-001")["envelope_hash"] == envelope.envelope_hash


def test_legacy_cendos_path_cannot_directly_calibrate_aegle(tmp_path):
    from livemorebio.cendos.lims.db import DB
    from livemorebio.cendos.lims.lab import CendosLabOS
    from livemorebio.evidence import CalibrationDeniedError

    lab = CendosLabOS(DB(str(tmp_path / "cendos.db")))

    with pytest.raises(CalibrationDeniedError, match="evidence authorization"):
        lab.calibration_to_aegle(
            "pseudonym-001", "experiment-001", {"glucose": 110}, {"Si": 0.1}
        )


def test_cendos_qualifies_wet_lab_result_as_counterpart_not_validation(monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.cendos.service import app

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "closed-loop-token")
    monkeypatch.setattr("livemorebio.bus.publish", lambda *args, **kwargs: {})
    monkeypatch.setattr("livemorebio.bus.set_snapshot", lambda *args, **kwargs: None)
    timestamp = datetime.now(timezone.utc).isoformat()

    body = {
        "result_id": "lab-result-api-001",
        "subject_id": "pseudonym-001",
        "subject_pseudonymized": True,
        "endpoint": "glucose_mgdl",
        "value": 112.0,
        "unit": "mg/dL",
        "measured_at": timestamp,
        "received_at": timestamp,
        "instrument_id": "analyzer-001",
        "method": "validated hexokinase assay",
        "quality_status": "pass",
        "calibration_status": "pass",
        "chain_of_custody": ["accession:ABC123", "plate:P01"],
        "consent_scope": ["research-validation"],
        "sequence": 1,
    }
    client = TestClient(app)
    response = client.post(
        "/evidence/lab-results",
        headers={"Authorization": "Bearer closed-loop-token"},
        json=body,
    )
    raw_identifier = client.post(
        "/evidence/lab-results",
        headers={"Authorization": "Bearer closed-loop-token"},
        json={**body, "result_id": "lab-result-api-002", "subject_id": "subject123456"},
    )

    assert response.status_code == 201
    assert response.json()["measurement"]["role"] == "counterpart_outcome"
    assert response.json()["measurement"]["payload"]["source_data_class"] == "qualified_lab"
    assert response.json()["validation_status"] == "not_assessed"
    assert raw_identifier.status_code == 422
    assert "pseudonym" in raw_identifier.json()["error"]


def test_a_record_label_run_into_its_number_is_refused_by_the_screen_first(monkeypatch):
    """L0-R16: "MRN123456" (a record label run into its number) is a mark of the best-effort screen
    now, so the screen refuses it before the pseudonym rule does, in the protocol and over HTTP."""
    from fastapi.testclient import TestClient
    from livemorebio.cendos.service import app
    from livemorebio.clinical_note_gate import ClinicalNoteRefused
    from livemorebio.life_patch.protocol import DeviceMode, TelemetryEnvelope, VirtualLifePatch, manifest_for

    device = VirtualLifePatch(manifest_for("virtual-001", DeviceMode.VIRTUAL))
    payload = device.emit("pseudonym-001", {"glucose_mgdl": 123.0}, captured_at=NOW).to_dict()
    payload["subject_id"], payload["envelope_hash"] = "MRN123456", ""
    with pytest.raises(ClinicalNoteRefused):
        TelemetryEnvelope.from_dict(payload)

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-closed-loop-token")
    monkeypatch.setattr("livemorebio.bus.publish", lambda *args, **kwargs: {})
    monkeypatch.setattr("livemorebio.bus.set_snapshot", lambda *args, **kwargs: None)
    timestamp = datetime.now(timezone.utc).isoformat()
    response = TestClient(app).post(
        "/evidence/lab-results", headers={"Authorization": "Bearer technical-closed-loop-token"},
        json={"result_id": "lab-result-api-003", "subject_id": "MRN123456", "subject_pseudonymized": True,
              "endpoint": "glucose_mgdl", "value": 112.0, "unit": "mg/dL", "measured_at": timestamp,
              "received_at": timestamp, "instrument_id": "analyzer-001", "method": "validated hexokinase assay",
              "quality_status": "pass", "calibration_status": "pass", "chain_of_custody": ["accession:ABC123"],
              "consent_scope": ["research-validation"], "sequence": 1})
    assert response.status_code == 422
    assert response.json()["code"] == "CLINICAL_NOTE_NOT_ACCEPTED"
