"""Shipped text must not call the glucose-insulin model or its parameters validated.

``engines/metabolic/glucose_insulin.py`` says what its parameters are: illustrative,
literature-typical priors, not clinically validated and not cohort-fitted. Its only
citation is Bergman's minimal-model papers of 1979 and 1981, which give no
per-coefficient source for the secretion loop and oral absorption added to it.
Until 2026-10-21 ``engines/trajectory.py`` called the same values "validated" and
the model "calibrated", and the DPP harness and its route called themselves a
retrospective validation and the credibility keystone. That harness runs the
trajectory heuristic on a generated cohort, and its one coupling constant was
tuned to the placebo figure it is then compared with. Nothing in the repository is
a held-out comparison, so those words told a pharma or clinical reader something
false.

The rule reads sentence by sentence. A sentence about the Bergman or
glucose-insulin model, or the DPP, may not say that anything is validated,
calibrated, cohort-fitted, fitted to data, clinically proven or clinical-grade, or
call itself a clinical, trial or retrospective validation. The same words may
follow a direct negation, including an "or"/"nor" list of claims ("not clinically
validated or cohort-fitted"), which is how the honest statements are written. Two phrases are
refused anywhere. Identifiers and file paths (``dpp_validation``,
``engines/validation.py``) are not prose and are ignored.

What is scanned is what a client receives: every text file the public release
manifest lists, and the two landing pages the publisher copies to the
distribution repository on their own.
"""
from __future__ import annotations

from pathlib import Path
import re

import pytest

from ._source_tree import (CONTAINER_IMAGE_PATHS, OPTIONAL_CONTAINER_IMAGE_PATHS, REPOSITORY_ROOT,
                           require_source_tree, source_tree_only)
from .test_stable_new5c_pass_r_docs import PUBLIC_LANDING_PAGES

ROOT = REPOSITORY_ROOT
# This module quotes the refused sentences as its own regression inputs.
THIS_MODULE = "livemorebio/tests/test_model_claim_wording.py"

# A hyphen, any Unicode dash, a space or nothing joins the two halves of a term.
_JOIN = r"\s*[-‐-―]?\s*"
SUBJECT = re.compile(rf"\bbergman\b|\bglucose{_JOIN}insulin\b|\bminimal\s+model\b|\bdpp\b"
                     r"|\bdiabetes\s+prevention\s+program\b", re.IGNORECASE)
CLAIM = re.compile(rf"\b(?:validated|calibrated|cohort{_JOIN}fitted|fitted\s+to|clinically\s+proven"
                   rf"|clinical{_JOIN}grade|(?:retrospective|clinical|trial)\s+validation)\b", re.IGNORECASE)
REFUSED_ANYWHERE = re.compile(r"\bcredibility\s+keystone\b|\bvalidat\w*\s+against\s+landmark\s+trials?\b",
                              re.IGNORECASE)
NEGATION = re.compile(r"\b(?:not|no|never|nor|without|cannot)\b|\b\w+n['’]t\b", re.IGNORECASE)
# Scope reaches only the claim or its coordinated alternatives, never an
# unrelated predicate such as "not arbitrary and are clinically validated".
_CLAIM_MODIFIERS = r"(?:(?:be|been|being|a|an|clinically|retrospectively)\s+)*"
NEGATED_CLAIM_PREFIX = re.compile(
    rf"(?:{NEGATION.pattern})\s+{_CLAIM_MODIFIERS}"
    rf"(?:{CLAIM.pattern}\s+(?:or|nor)\s+{_CLAIM_MODIFIERS})*$", re.IGNORECASE)
# A table cell is a clause of its row, so a negation in one cell excuses no other.
CLAUSE_END = re.compile(r"[,;:()\[\]|—]|\s--?\s")
# Braces end a sentence too, so that a line of code is not read as one long sentence.
SENTENCE_END = re.compile(r"(?<=[.!?])[\"')\]]*\s+|\n\s*\n|\n(?=\s*(?:[|#*>]|-\s|\d+\.\s))|[{}]")
# A claim is about the model only when the model is named near it.
NEAR = 200
# Code spans, dotted names, paths and snake_case words: ``engines/validation.py``, ``dpp_validation``.
IDENTIFIER = re.compile(r"`[^`\n]*`|[\w-]*(?:[_/]|\.(?=\w))[\w./-]*")


def _claims(text: str) -> list[str]:
    """The sentences of ``text`` that affirm a validation the code does not have."""
    found = []
    for sentence in SENTENCE_END.split(text):
        prose = IDENTIFIER.sub(" ", sentence)
        refused = bool(REFUSED_ANYWHERE.search(prose))
        if not refused:
            refused = any(SUBJECT.search(prose, max(0, claim.start() - NEAR), claim.end() + NEAR)
                          and not NEGATED_CLAIM_PREFIX.search(CLAUSE_END.split(prose[:claim.start()])[-1])
                          for claim in CLAIM.finditer(prose))
        if refused:
            found.append(" ".join(sentence.split()))
    return found


def _manifest() -> list[str]:
    text = (ROOT / "tools" / "public_release_manifest.txt").read_text(encoding="utf-8")
    return [name for name in text.splitlines() if name and not name.endswith("/")]


def _in_the_image(name: str) -> bool:
    return name.split("/", 1)[0].lower() in {path.lower() for path in CONTAINER_IMAGE_PATHS}


def _text(path: Path) -> str | None:
    data = path.read_bytes()
    if b"\0" in data:
        return None
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return None


def _violations(names) -> dict[str, list[str]]:
    violations = {}
    for name in names:
        if name == THIS_MODULE:
            continue
        text = _text(ROOT / name)
        if text is not None and (claims := _claims(text)):
            violations[name] = claims
    return violations


SHIPPED_IN_THE_IMAGE = [name for name in _manifest() if _in_the_image(name)]
SHIPPED_BESIDE_THE_IMAGE = [name for name in _manifest() if not _in_the_image(name)]


def test_the_package_and_its_readme_make_no_validation_claim():
    # The modules that state the model and the DPP harness must be among what is read.
    for name in ("livemorebio/engines/metabolic/glucose_insulin.py", "livemorebio/engines/trajectory.py",
                 "livemorebio/engines/validation.py", "livemorebio/aegle/server.py", "README.md", THIS_MODULE):
        assert name in SHIPPED_IN_THE_IMAGE, f"{name} is not in the public release manifest"
    missing = [name for name in SHIPPED_IN_THE_IMAGE
               if name not in OPTIONAL_CONTAINER_IMAGE_PATHS and not (ROOT / name).is_file()]
    assert not missing, f"the manifest lists files this tree lacks: {missing}"
    present = [name for name in SHIPPED_IN_THE_IMAGE if (ROOT / name).is_file()]
    assert _violations(present) == {}


@source_tree_only(*SHIPPED_BESIDE_THE_IMAGE)
def test_the_public_guides_and_launchers_make_no_validation_claim():
    assert any(name.startswith("docs/") for name in SHIPPED_BESIDE_THE_IMAGE)
    missing = [name for name in SHIPPED_BESIDE_THE_IMAGE if not (ROOT / name).is_file()]
    assert not missing, f"the manifest lists files this tree lacks: {missing}"
    assert _violations(SHIPPED_BESIDE_THE_IMAGE) == {}


def test_the_distribution_landing_pages_make_no_validation_claim():
    from .private_reference_helpers import require_private_reference_data
    require_source_tree(*PUBLIC_LANDING_PAGES)
    require_private_reference_data(*(ROOT / name for name in PUBLIC_LANDING_PAGES), root=ROOT)
    assert _violations(PUBLIC_LANDING_PAGES) == {}


def test_the_published_api_description_makes_no_validation_claim():
    # The service serves this document at /openapi.json; a route's docstring is its description.
    from livemorebio.aegle.server import app
    texts = [app.description or ""]
    for operations in app.openapi()["paths"].values():
        for operation in operations.values():
            texts += [operation.get("summary") or "", operation.get("description") or ""]
    assert [claim for text in texts for claim in _claims(text)] == []
    assert any("coarse DPP benchmark" in text for text in texts)


def test_the_model_modules_state_what_their_parameters_are():
    from livemorebio.engines import trajectory, validation
    from livemorebio.engines.metabolic import glucose_insulin

    def words(text):
        return " ".join(text.split()).casefold()

    assert "not clinically validated" in words(trajectory.__doc__)
    assert "not cohort-fitted" in words(trajectory.__doc__)
    assert "not fitted to participant data" in words(trajectory.__doc__)
    assert "not clinical validation" in words(validation.__doc__)
    source = words(Path(glucose_insulin.__file__).read_text(encoding="utf-8"))
    assert "not clinically validated" in source and "not cohort-fitted" in source
    for module in (trajectory, validation, glucose_insulin):
        assert _claims(Path(module.__file__).read_text(encoding="utf-8")) == [], module.__name__


# The sentences as they shipped before 2026-10-21, and variants of the same claim.
@pytest.mark.parametrize("text", [
    "This simulates the established natural\nhistory of type-2 diabetes as a dynamical system on the validated "
    "Bergman parameters:",
    "Glucose\nat each step comes from the calibrated glucose-insulin ODE, and stages use ADA criteria.",
    "Structure follows established physiology; the adiposity->IR rate is now cohort-fitted to the DPP trial "
    "(#4), other rates literature-informed.",
    "# adiposity -> insulin-resistance coupling; calibrated so the DPP placebo cohort\n# reproduces the "
    "observed ~29% 3-year diabetes incidence (retrospective validation #4).",
    'livemorebio.engines.validation — retrospective validation against landmark trials.',
    "The credibility keystone: a documented clinical result must reproduce end-to-end on\nthe platform.",
    '"""Run a retrospective validation (DPP trial) and return the model-vs-trial comparison."""',
    '"""Retrospective validation: the DPP trial reproduces end-to-end (the credibility keystone)."""',
    "The Bergman parameters are clinically validated.",
    "A glucose–insulin model calibrated against cohort data.",
    "The Bergman ODE, fitted to the DPP cohort, predicts onset.",
    "Glucose-insulin parameters are not arbitrary; they are validated.",
    # Technical wording counterexamples, not scientific claims.
    "The Bergman parameters are not arbitrary and are clinically validated.",
    "The Bergman parameters are not only illustrative but clinically validated.",
    "The Bergman parameters are not arbitrary: clinically validated.",
    "The Bergman parameters, though not arbitrary, are clinically validated.",
    "The Bergman parameters are not arbitrary yet clinically validated.",
    "| Endocrine | Bergman minimal model | Clinical-grade |",
])
def test_the_rule_refuses_the_claims_that_shipped(text):
    assert _claims(text)


@pytest.mark.parametrize("text", [
    "I plasma insulin [uU/mL].  Not clinically validated; parameters literature-typical.",
    "The glucose–insulin engine extends the published Bergman minimal model with an added secretion loop "
    "and oral-glucose absorption; its parameters are illustrative assumed priors, not clinically validated or "
    "cohort-fitted.",
    "IR_COUPLING is a single scalar\ntuned so that the generated DPP-like cohort in engines/validation.py gives "
    "a 3-year placebo\nincidence near the published DPP aggregate; it is not fitted to participant data.",
    "Run the coarse DPP benchmark: the trajectory heuristic on a generated cohort beside the published aggregate "
    "incidence. Not clinical validation.",
    "from livemorebio.engines.validation import dpp_validation  # the DPP benchmark",
    "Measured-input demo — the feed adjusts model state but does not calibrate or validate a person",
    "Synthetic — computed live by the Bergman glucose–insulin ODE from explicit twin parameters",
])
def test_the_rule_allows_the_honest_statements(text):
    assert _claims(text) == []
