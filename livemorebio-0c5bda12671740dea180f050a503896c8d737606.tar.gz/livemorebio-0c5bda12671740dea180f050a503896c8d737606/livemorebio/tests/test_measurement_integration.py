"""Cross-product v3 technical fixtures, never physical hardware admission evidence."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient

from livemorebio.tests.test_patch_protocol_v3 import manifest_payload, envelope_payload


@pytest.fixture
def loop(monkeypatch, tmp_path):
    from livemorebio import bus
    from livemorebio.aegle import server
    from livemorebio.life_system import service
    from livemorebio.life_patch.protocol import PatchAdmissionController

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-integration-token")
    monkeypatch.setenv("LIVEMORE_PATCH_ADMISSION_HMAC_KEY", "dGVjaG5pY2FsLWZpeHR1cmUta2V5LWZvci10ZXN0cyE=")
    monkeypatch.setenv("LIVEMORE_PATCH_JOURNAL", str(tmp_path / "telemetry.jsonl"))
    monkeypatch.setenv("LIVEMORE_SUBJECT_REGISTRY", str(tmp_path / "subjects.sqlite3"))
    monkeypatch.setattr(service, "_c", {})
    monkeypatch.setattr(server, "_subject_registry_instance", None)
    monkeypatch.setattr(server, "_patch_admission", PatchAdmissionController())
    snapshots = {}
    monkeypatch.setattr(bus, "set_snapshot", lambda key, value: snapshots.update({key: deepcopy(value)}))
    monkeypatch.setattr(bus, "snapshot", lambda key: deepcopy(snapshots.get(key)))
    monkeypatch.setattr(bus, "publish", lambda *args, **kwargs: None)
    registry = server._subject_registry()
    record = registry.create_twin({"source_class": "SYNTHETIC", "subject_id": "pseudonym-fixture",
        "display_label": "Technical v3 integration fixture", "demographics": {"age": 50, "sex": "U"}})
    record = registry.activate_twin(record["twin_id"], expected_version=record["version"])
    record = registry.bind_patch(record["twin_id"], {"device_id": "v3-technical", "mode": "virtual", "protocol_version": "3.0"}, expected_version=record["version"])
    monkeypatch.setattr(server, "_state", {"tw": registry.build_twin(record), "subject": server._subject_summary(record)})
    client = TestClient(server.app)
    headers = {"Authorization": "Bearer technical-integration-token"}
    forwarded = []

    def forward(body):
        forwarded.append(deepcopy(body))
        response = client.post("/api/patch/telemetry", headers=headers, json=body)
        return {"status": "delivered" if response.status_code == 202 else "rejected", "http_status": response.status_code}

    monkeypatch.setattr(service, "_forward_to_aegle", forward)
    return client, TestClient(service.app), headers, snapshots, forwarded


def fresh_packet():
    raw = envelope_payload()
    now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    raw.update(captured_at=now, acquisition_start=now, acquisition_end=now)
    return raw


def test_v3_lineage_survives_life_aegle_and_view_without_changing_parameters(loop):
    from livemorebio.aegle import server
    client, life, headers, snapshots, forwarded = loop
    before = deepcopy(server._state["tw"].state()["profile_params"])
    assert life.post("/patch/devices", headers=headers, json=manifest_payload()).status_code == 201
    packet = fresh_packet()
    response = life.post("/patch/telemetry", headers=headers, json=packet)
    assert response.status_code == 202, response.json()
    assert response.json()["aegle"] == {"status": "delivered", "http_status": 202}
    assert forwarded[0]["admission"]["manifest_hash"] == forwarded[0]["manifest"]["capability_hash"]
    observation = client.get("/api/state", headers=headers).json()["observations"]["hr_bpm"]
    assert observation["measurement_id"] == "hr-1"
    assert observation["context"]["derivation_id"] == "fixture-hr-algorithm"
    assert observation["clock"]["session_id"] == "boot-fixture"
    assert observation["received_at"] == snapshots["patch.latest"]["received_at"]
    assert observation == snapshots["patch.latest"]["observations"]["hr_bpm"]
    view = client.get("/api/patch", headers=headers).json()
    channel = next(row for row in view["channels"] if row["id"] == "observed_hr_bpm")
    assert channel["data_class"] == "technical_fixture"
    assert channel["status"] == "recorded"
    assert channel["source_hash"] == response.json()["envelope_hash"]
    workspace = client.get("/api/workspace", headers=headers).json()
    atlas_channel = next(row for row in workspace["observation_channels"] if row["id"] == channel["id"])
    for field in ("data_class", "status", "source_hash", "measurement_id", "model_context", "received_at"):
        assert atlas_channel[field] == channel[field]
    assert view["n_live"] == 0
    assert before == server._state["tw"].state()["profile_params"]
    assert life.post("/patch/telemetry", headers=headers, json=packet).status_code == 422


def test_aegle_rejects_manifest_substitution_and_unbound_protocol(loop):
    from livemorebio.aegle import server
    client, life, headers, _, forwarded = loop
    life.post("/patch/devices", headers=headers, json=manifest_payload())
    assert life.post("/patch/telemetry", headers=headers, json=fresh_packet()).status_code == 202
    forged = deepcopy(forwarded[0])
    forged["manifest"]["configuration_id"] = "substituted"
    assert client.post("/api/patch/telemetry", headers=headers, json=forged).status_code == 422
    assert server._state["tw"].observations["hr_bpm"]["context"]["derivation_id"] == "fixture-hr-algorithm"


def test_life_does_not_manufacture_receipt_time_for_future_packet(loop):
    _, life, headers, snapshots, forwarded = loop
    life.post("/patch/devices", headers=headers, json=manifest_payload())
    raw = fresh_packet()
    future = (datetime.now(timezone.utc) + timedelta(minutes=1)).isoformat()
    raw.update(captured_at=future, acquisition_start=future, acquisition_end=future)
    assert life.post("/patch/telemetry", headers=headers, json=raw).status_code == 422
    assert not forwarded
    assert "patch.latest" not in snapshots


def test_patch_api_and_workspace_share_context_token(loop):
    client, _, headers, _, _ = loop
    state = client.get("/api/state", headers=headers).json()
    assert client.get("/api/patch", headers=headers).json()["context_id"] == state["context_id"]
    assert client.get("/api/workspace", headers=headers).json()["context_id"] == state["context_id"]


def test_admitting_observations_never_reclassifies_model_traces(loop):
    from livemorebio.aegle import server
    from livemorebio.life_patch.protocol import decode_envelope
    from livemorebio.life_patch.stream import ExternalSeriesStream
    twin = server._state["tw"]
    before = deepcopy(twin.provenance)
    raw = envelope_payload("physical")
    raw["measurements"][0]["provenance"] = "inferred"
    twin.ingest_patch_envelope(decode_envelope(raw))
    assert twin.provenance == before
    twin.ingest_patch(ExternalSeriesStream("pseudonym-fixture", glucose=[(0., 125.)]).packets())
    assert twin.provenance == before
    assert twin.state()["capability"]["maturity"]["device_connected"] is False


def test_virtual_sample_never_reads_an_unbound_mutable_bus_snapshot(loop):
    _, life, headers, snapshots, forwarded = loop
    snapshots["twin"] = {"human": {"id": "another-subject"}, "metabolic": {"glucose": [222.]}}
    for version in ("2.0", "3.0"):
        response = life.post("/patch/virtual/sample", headers=headers, json={
            "device_id": "v3-technical", "subject_id": "pseudonym-fixture", "protocol_version": version})
        assert response.status_code == 422
    assert not forwarded
    assert "patch.latest" not in snapshots


def test_virtual_sample_dispatches_explicit_v3_without_rebuilding_manifest(loop):
    _, life, headers, _, forwarded = loop
    life.post("/patch/devices", headers=headers, json=manifest_payload())
    response = life.post("/patch/virtual/sample", headers=headers, json={"envelope": fresh_packet()})
    assert response.status_code == 202, response.json()
    assert forwarded[0]["envelope"]["protocol_version"] == "3.0"
    assert forwarded[0]["envelope"]["measurements"][0]["value"] == 72


def test_workspace_change_during_projection_is_retryable_not_success(loop, monkeypatch):
    from livemorebio.aegle import server
    client, _, headers, _, _ = loop
    counter = iter(["before", "after"])
    monkeypatch.setattr(server, "_view_context_id", lambda *args: next(counter))
    response = client.get("/api/workspace", headers=headers)
    assert response.status_code == 503
    assert response.json()["code"] == "WORKSPACE_CONTEXT_CHANGED"


@pytest.mark.parametrize("field,values", [("consent_scope", [{}]), ("chain_of_custody", [None]), ("consent_scope", ["a"] * 65)])
def test_telemetry_admission_metadata_is_bounded_typed_strings(loop, field, values):
    _, life, headers, _, forwarded = loop
    assert life.post("/patch/devices", headers=headers, json=manifest_payload()).status_code == 201
    response = life.post("/patch/telemetry", headers=headers, json={"envelope": fresh_packet(), field: values})
    assert response.status_code == 422
    assert not forwarded


def test_command_routes_reject_malformed_json_without_internal_errors(loop):
    _, life, headers, _, _ = loop
    assert life.post("/patch/commands/receipts", headers=headers, json=[]).status_code == 422
    response = life.post("/patch/commands", headers={**headers, "Content-Type": "application/json"},
                         content='{"device_id":"v3-technical","command":"request_quality_check","expires_in_seconds":1e999}')
    assert response.status_code == 422


def test_patch_decoder_errors_never_echo_private_payloads(loop):
    _, life, headers, _, _ = loop
    sentinel = "TECHNICAL_PRIVATE_SENTINEL"
    from livemorebio.life_patch.protocol import VirtualLifePatch, manifest_for, DeviceMode
    packet = VirtualLifePatch(manifest_for("legacy-fixture", DeviceMode.VIRTUAL)).emit("pseudonym-fixture", {"hr_bpm": 72}).to_dict()
    packet["sequence"] = sentinel
    cases = [("/patch/virtual/sample", {"envelope": packet}), ("/patch/telemetry", packet),
             ("/patch/commands/receipts", {"received_at": sentinel})]
    for path, body in cases:
        response = life.post(path, headers=headers, json=body)
        assert response.status_code == 422
        assert sentinel not in response.text


def test_aegle_virtual_sampling_rejects_conflicting_version_or_mode_before_forward(loop, monkeypatch):
    from livemorebio.aegle import server
    client, _, headers, _, _ = loop
    forwarded = []
    monkeypatch.setattr(server, "_forward_virtual_patch", lambda body: forwarded.append(body) or (202, {}))
    response = client.post("/api/patch/virtual", headers=headers, json={
        "device_id": "v3-technical", "protocol_version": "2.0", "readings": {"hr_bpm": 72}})
    assert response.status_code == 409
    raw = fresh_packet()
    raw["mode"] = "physical"
    response = client.post("/api/patch/virtual", headers=headers, json={"envelope": raw})
    assert response.status_code == 409
    assert forwarded == []


def test_lobeline_aegle_route_preserves_history_and_never_needs_a_cohort(loop, monkeypatch, tmp_path):
    from livemorebio.aegle import server
    from livemorebio.cendos.protocol_runs import ProtocolRunStore
    client, _, headers, _, _ = loop
    monkeypatch.setattr(server, "_protocol_run_store", lambda: ProtocolRunStore(tmp_path / "runs"))
    before = deepcopy(server._state["tw"].state())
    specification = {"material_id": "lobeline-hemisulfate", "context_id": "rat-striatal-synaptic-vesicles",
                     "concentration_unit": "uM", "substrate_concentrations": [0, .01, .11, 1, 5],
                     "inhibitor_concentrations": [0, .25]}
    path = "/api/cendos/protocols/lobeline-vmat2"
    assert client.post(path, json=specification).status_code == 401
    response = client.post(path, json=specification, headers=headers)
    assert response.status_code == 201, response.json()
    result = response.json()
    assert result["benchmark_discrepancy"]["difference_um"] == pytest.approx(-.12148936170212765)
    assert result["live_twin_modified"] is False
    assert server._state["tw"].state() == before
    stored = client.get("/api/cendos/protocols/" + result["run_id"], headers=headers)
    assert stored.status_code == 200
    assert stored.json()["source_sha256"] == result["source_sha256"]
