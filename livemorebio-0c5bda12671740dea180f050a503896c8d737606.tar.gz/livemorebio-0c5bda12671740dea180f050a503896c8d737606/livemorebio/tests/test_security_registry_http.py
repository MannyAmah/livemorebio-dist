"""Technical bootstrap refusals exercise HTTP handlers without sockets or models."""
from contextlib import nullcontext
from types import SimpleNamespace

from fastapi.testclient import TestClient
import pytest

from livemorebio import bus
from livemorebio.aegle import server
from livemorebio.aegle.execution import DENY_ALL
from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError


@pytest.fixture
def bootstrap_client(monkeypatch):
    from livemorebio.aegle import execution_api, reference_cohort_api
    from livemorebio.life_patch import protocol

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-bootstrap-http-token")
    monkeypatch.setattr(server, "_ensure_selected_state", lambda: None)
    monkeypatch.setattr(server, "_require_numerical_model", lambda: None)
    monkeypatch.setattr(server, "_assert_numerical_available", lambda: None)
    monkeypatch.setattr(bus, "require_storage_key", lambda: None, raising=False)
    authority = SimpleNamespace(
        observation=nullcontext, permitted_generation=DENY_ALL,
        generation="technical-source-generation",
        capture=lambda callback, **kwargs: callback(),
    )
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_state", {"subject": {"twin_id": "technical-twin"}})
    monkeypatch.setattr(server, "_model_availability", lambda: {"state": "READY"})
    monkeypatch.setattr(server, "_protocol_run_store", lambda: SimpleNamespace(
        prepare_rerun=lambda run_id, resolve: resolve("technical-cohort")))
    monkeypatch.setattr(protocol, "decode_envelope", lambda body: SimpleNamespace())
    monkeypatch.setattr("livemorebio.security.verify_patch_admission", lambda *args: True)
    monkeypatch.setattr(execution_api, "_check_runtime_identity", lambda: None)
    store = SimpleNamespace(begin_access=lambda *args, **kwargs: "technical-access",
                            finish_access=lambda *args, **kwargs: None)
    monkeypatch.setattr(execution_api, "_manager", lambda: SimpleNamespace(store=store))

    def configure(code):
        attempts = []

        def refuse():
            attempts.append(code)
            raise RegistryBootstrapError(code)

        monkeypatch.setattr(server, "_subject_registry", refuse)
        monkeypatch.setattr(reference_cohort_api, "service", refuse)
        return attempts

    return TestClient(server.app, raise_server_exceptions=False), configure


_VERSION = {"expected_version": 1}
_PREPARE = {"engine_contract_id": "metabolic-continuous-v1",
            "expected_source_generation": "technical-source-generation",
            "expected_twin_id": "technical-twin", "expected_twin_version": 1, "policy": {}}
_CONSUMER = {"session_id": "technical-session", "source_snapshot_hash": "technical-hash",
             "expected_source_generation": "technical-source-generation", "expected_revision": 1}


@pytest.mark.parametrize("code", ["REGISTRY_STORAGE_UNAVAILABLE", "REGISTRY_BOOTSTRAP_INVALID"])
@pytest.mark.parametrize("method,path,body", [
    ("GET", "/api/twins?limit=1", None),
    ("POST", "/api/twins", {}),
    ("GET", "/api/twins/technical-twin", None),
    ("POST", "/api/twins/technical-twin/activate", _VERSION),
    ("POST", "/api/twins/technical-twin/select-observations", _VERSION),
    ("POST", "/api/twins/reconcile-selection", {}),
    ("POST", "/api/twins/technical-twin/patches",
     {**_VERSION, "device_id": "technical-device", "mode": "virtual"}),
    ("GET", "/api/cohorts", None),
    ("GET", "/api/cohorts/technical-cohort", None),
    ("GET", "/api/cohorts/technical-cohort/members", None),
    ("GET", "/api/cohorts/technical-cohort/members/technical-member", None),
    ("POST", "/api/cohorts", {}),
    ("POST", "/api/cendos/protocols/metformin-cohorts", {}),
    ("POST", "/api/cendos/protocols/garcinoic-pxr", {}),
    ("GET", "/api/cendos/protocols/technical-run/prepare-rerun", None),
    ("POST", "/api/patch/telemetry", {"envelope": {}, "admission": {}, "admission_signature": "technical"}),
    ("POST", "/api/stimulate", {"kind": "base"}),
    ("POST", "/api/stimulate", {"kind": "life_system", "params": {"mode": "random"}}),
    ("POST", "/api/trajectory", {}),
    ("POST", "/api/patch/virtual", {}),
    ("GET", "/api/cendos/current-source", None),
    ("POST", "/api/cendos/assay", {}),
    ("POST", "/api/reference-cohorts/preview", {}),
    ("POST", "/api/reference-cohorts", {}),
    ("GET", "/api/reference-cohorts/technical-cohort/members", None),
    ("GET", "/api/reference-cohorts/technical-cohort/members/technical-member", None),
    ("GET", "/api/executions/capabilities", None),
    ("POST", "/api/executions", _PREPARE),
    ("POST", "/api/executions/" + "a" * 32 + "/fork-checkpoint", {**_PREPARE, "expected_parent_revision": 1}),
    ("POST", "/api/executions/" + "a" * 32 + "/consumer", _CONSUMER),
    ("POST", "/api/executions/" + "a" * 32 + "/consumer/renew",
     {key: value for key, value in _CONSUMER.items() if key != "expected_revision"}),
    ("POST", "/api/execution-observations", {}),
])
def test_registry_bootstrap_refusal_is_typed_503_for_every_handler(
        bootstrap_client, method, path, body, code):
    client, configure = bootstrap_client
    attempts = configure(code)
    response = client.request(method, path, json=body, headers={
        "Authorization": "Bearer technical-bootstrap-http-token",
        "Idempotency-Key": "technical-bootstrap-attempt",
    })
    assert attempts, "technical request must reach registry construction"
    assert response.status_code == 503, response.text
    assert response.json()["code"] == code
    assert response.json()["error"] == str(RegistryBootstrapError(code))
    assert response.headers["Cache-Control"] == "no-store"


@pytest.mark.parametrize("code", ["REGISTRY_STORAGE_UNAVAILABLE", "REGISTRY_BOOTSTRAP_INVALID"])
def test_virtual_patch_registry_refusal_on_worker_recheck_prevents_forwarding(
        bootstrap_client, monkeypatch, code):
    client, _ = bootstrap_client
    attempts = []
    record = {"subject_id": "technical-subject", "patch_bindings": [
        {"device_id": "technical-device", "mode": "virtual", "protocol_version": "2.0"}]}

    def registry():
        attempts.append("construct")
        if len(attempts) == 2:
            raise RegistryBootstrapError(code)
        return SimpleNamespace(active_twin=lambda: record)

    monkeypatch.setattr(server, "_subject_registry", registry)
    monkeypatch.setattr(server, "_require_matching_selected_record", lambda value: None)
    monkeypatch.setattr(server, "_forward_virtual_patch", lambda body: pytest.fail("must not forward"))
    response = client.post("/api/patch/virtual", json={}, headers={
        "Authorization": "Bearer technical-bootstrap-http-token"})
    assert attempts == ["construct", "construct"]
    assert response.status_code == 503, response.text
    assert response.json() == {"code": code, "error": str(RegistryBootstrapError(code))}
    assert response.headers["Cache-Control"] == "no-store"


@pytest.mark.parametrize("code", ["REGISTRY_STORAGE_UNAVAILABLE", "REGISTRY_BOOTSTRAP_INVALID"])
def test_execution_registry_refusal_preserves_http_code_and_finishes_real_audit(
        bootstrap_client, monkeypatch, tmp_path, code):
    from livemorebio.aegle import execution_api
    from livemorebio.aegle.execution_store import ExecutionStore

    client, configure = bootstrap_client
    attempts = configure(code)
    store = ExecutionStore(tmp_path / "technical-execution.sqlite3", key=b"t" * 32)
    monkeypatch.setattr(execution_api, "_manager", lambda: SimpleNamespace(store=store))
    response = client.get("/api/executions/capabilities", headers={
        "Authorization": "Bearer technical-bootstrap-http-token"})
    assert attempts
    assert response.status_code == 503
    assert response.json() == {"code": code, "error": str(RegistryBootstrapError(code))}
    request_id = response.headers["X-Livemore-Request-Id"]
    with store._connection() as connection:
        row = connection.execute("SELECT outcome FROM access_audit WHERE request_id=?", (request_id,)).fetchone()
        assert row is not None and row[0] is not None
        outcome = store._decrypt(row[0], f"audit:{request_id}:outcome")
        assert outcome["result_code"] == "EXECUTION_STORAGE"
        assert store._audit_usage(connection)["pending"] == 0
