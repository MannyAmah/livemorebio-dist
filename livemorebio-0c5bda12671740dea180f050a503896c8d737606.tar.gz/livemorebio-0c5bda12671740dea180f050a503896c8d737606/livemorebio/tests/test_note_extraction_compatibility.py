"""Literal note recognition is deliberately narrower than exact ontology lookup.

L0-R15: this release has no operational local de-identification, so the note
extractor and every note route refuse every note (``CLINICAL_NOTE_NOT_ACCEPTED``).
These tests were restated from recognising each technical string to refusing it.
The stable recognition oracle (``fixtures/note_extraction_stable.json``) and the
extractor's vocabulary are kept unchanged: the vocabulary checks below need no
note, and the oracle's recognition checks return with the release that makes
de-identification operational.
"""
from __future__ import annotations
import json
from pathlib import Path
import pytest
from livemorebio.life_system.extract import ClinicalExtractor
from livemorebio.life_system.reference.knowledgebase import KnowledgeBase
from .test_l0_clinical_note_gate import CODE, REASON, assert_note_refused

FIXTURE = json.loads((Path(__file__).parent / "fixtures/note_extraction_stable.json").read_text(encoding="utf-8"))
NEGATIVES = [row["note"] for row in FIXTURE["cases"] if not row["expected_conditions"]]

@pytest.mark.parametrize("case", FIXTURE["cases"], ids=lambda row: row["note"])
def test_stable_condition_spelling_or_explicit_acronym_correction(case):
    # The oracle row stays self-consistent; the extractor refuses its text (L0-R15).
    if case["disposition"] == "stable_exact_spelling_preserved":
        assert set(case["expected_conditions"]) == set(case["stable_conditions"])
    elif case["disposition"] == "intentional_lowercase_acronym_false_positive_removal":
        assert case["stable_conditions"] == ["Alzheimer disease"] and not case["expected_conditions"]
    else:
        assert case["disposition"] in {"open_ontology_label_correction", "reviewed_recognition_added"}
        assert "stable_condition_sha256" in case
    vocabulary = set(ClinicalExtractor().disease_terms.values())
    assert set(case["expected_conditions"]) <= vocabulary
    assert_note_refused(lambda: ClinicalExtractor().extract(case["note"]))

@pytest.fixture
def note_client(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server
    from livemorebio.aegle.model_source import ModelSourceAuthority

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-note-compatibility-token")
    monkeypatch.setenv("LIVEMORE_SUBJECT_REGISTRY", str(tmp_path / "technical-notes.sqlite3"))
    monkeypatch.setattr(server, "_subject_registry_instance", None)
    monkeypatch.setattr(server, "_subject_registry_path", None)
    monkeypatch.setattr(server, "_execution_manager_instance", None)
    monkeypatch.setattr(server, "_model_source_authority", ModelSourceAuthority())
    monkeypatch.setattr(server, "_state", {"tw": None, "subject": None, "initialized": True})
    monkeypatch.setattr(server, "_workspace_actions", [])
    # Bus transport is unrelated to intake; the real registry, extractor,
    # preview transition and twin all execute in this process.
    monkeypatch.setattr(server, "_snapshot_twin", lambda snapshot: None)
    return TestClient(server.app, headers={"Authorization": "Bearer technical-note-compatibility-token"})


@pytest.mark.parametrize("note", NEGATIVES)
def test_false_positive_note_is_refused_and_the_technical_control_still_runs(note_client, note):
    # L0-R15: the note route refuses before it reads the note; the control's
    # technical route (explicit structured fields) is unchanged.
    from livemorebio.aegle import server

    before = server._state["tw"]
    refused = note_client.post("/api/ingest_note", json={"text": "45 yo F. " + note})
    assert refused.status_code == 422 and refused.json() == {"code": CODE, "error": REASON}
    assert server._state["tw"] is before
    control_response = note_client.post("/api/stimulate", json={"kind": "life_system", "params": {
        "mode": "custom", "id": "LMB-45", "age": 45, "sex": "F",  # L0-R15 round 1: a technical id
        "conditions": [], "genome": {}, "lifestyle": 0.6,
    }})
    assert control_response.status_code == 200, control_response.text
    assert control_response.json()["human"]["conditions"] == []

@pytest.mark.parametrize("lower,upper", [("ad", "AD"), ("copd", "COPD"), ("chf", "CHF")])
def test_reviewed_acronyms_require_original_case(lower, upper):
    extractor = ClinicalExtractor()
    # Only the original-case acronym is in the vocabulary; matching any text is refused (L0-R15).
    assert upper in extractor.disease_terms and lower not in extractor.disease_terms
    assert_note_refused(lambda: extractor.extract(lower))
    assert_note_refused(lambda: extractor.extract(upper))


@pytest.mark.parametrize("term,expected", [
    ("htn", "Hypertension"), ("t2dm", "Type 2 diabetes mellitus"),
    ("t2d", "Type 2 diabetes mellitus"), ("cad", "Coronary artery disease"),
])
@pytest.mark.parametrize("transform", [str.lower, str.upper, str.title])
def test_published_unambiguous_shorthand_keeps_case_insensitive_recognition(term, expected, transform):
    extractor = ClinicalExtractor()
    assert extractor.disease_terms[term.upper()] == expected
    assert_note_refused(lambda: extractor.extract(transform(term)))


@pytest.mark.parametrize("note,expected", [
    ("pt with htn and t2dm on metformin", {"Hypertension", "Type 2 diabetes mellitus"}),
    ("hx of cad, s/p stent", {"Coronary artery disease"}),
    ("t2d, on metformin", {"Type 2 diabetes mellitus"}),
])
def test_published_shorthand_combinations(note, expected):
    assert expected <= set(ClinicalExtractor().disease_terms.values())
    assert_note_refused(lambda: ClinicalExtractor().to_synthetic_human(note))

@pytest.mark.parametrize("term", ["CHD", "COLD", "weak heart", "insulin resistance", "breast tumor", "mammary tumor", "prostate neoplasm", "myocardial ischemia"])
def test_broad_or_ambiguous_ontology_terms_are_exact_lookup_only(term):
    kb = KnowledgeBase()
    assert kb.disease(term) is not None
    assert term not in ClinicalExtractor(kb).disease_terms
    assert_note_refused(lambda: ClinicalExtractor(kb).extract(term))

@pytest.mark.parametrize("term", ["cold", "chd"])
def test_exact_lookup_does_not_fold_acronyms_to_ordinary_words(term):
    assert KnowledgeBase().disease(term) is None

@pytest.mark.parametrize("term,expected", [
    ("type II diabetes", "Type 2 diabetes mellitus"),
    ("diabetes mellitus, type 2", "Type 2 diabetes mellitus"),
    ("type 1 diabetes", "Type 1 diabetes mellitus"),
    ("coronary heart disease", "Coronary artery disease"),
    ("high blood pressure", "Hypertension"),
    ("COPD", "Chronic obstructive pulmonary disease"),
    ("nonalcoholic fatty liver", "nonalcoholic fatty liver"),
    ("Alzheimers", "Alzheimer disease"),
    ("CHF", "Congestive heart failure"),
    ("IBD", "Inflammatory bowel disease"),
])
def test_independently_reviewed_terms_extract_the_expected_condition(term, expected):
    assert expected in set(ClinicalExtractor().disease_terms.values())
    assert_note_refused(lambda: ClinicalExtractor().extract(term))
