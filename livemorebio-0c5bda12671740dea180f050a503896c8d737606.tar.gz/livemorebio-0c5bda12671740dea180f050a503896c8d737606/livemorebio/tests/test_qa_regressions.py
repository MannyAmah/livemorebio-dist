from __future__ import annotations

import json
import re
import subprocess

from fastapi.testclient import TestClient
from ._node import require_node, run_node as _run_node


def test_issue_002_patch_counts_only_live_channels_as_live(monkeypatch):
    """Regression for QA ISSUE-002: nominal placeholders are not live data."""
    from livemorebio.aegle.server import app

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "qa-regression-token")
    result = TestClient(app).get(
        "/api/patch", headers={"Authorization": "Bearer qa-regression-token"}
    )

    assert result.status_code == 200
    payload = result.json()
    assert payload["n_live"] == sum(
        channel["status"] == "live" for channel in payload["channels"]
    )
    assert payload["n_nominal"] == sum(
        channel["status"] == "nominal" for channel in payload["channels"]
    )
    assert payload["n_nominal"] == 0
    assert payload["n_live"] == 0
    assert payload["connection_verified"] is False

    for channel in payload["channels"]:
        if channel["id"].startswith("observed_"):
            assert channel["data_class"] in {"observed", "virtual", "technical_fixture", "unknown"}
        elif channel["status"] == "nominal":
            assert channel["data_class"] == "nominal"
        elif channel["status"] == "pending":
            assert channel["data_class"] == "pending"
        else:
            assert channel["data_class"] == "modeled"


def test_issue_patch_page_pauses_polling_when_authorization_is_cancelled():
    """Protected patch reads must not loop token prompts or report Aegle as down."""
    from livemorebio.aegle.server import app

    response = TestClient(app).get("/patch")

    assert response.status_code == 200
    page = response.text
    assert "LIVEMORE_AUTH_REQUIRED" in page
    assert "Authorization required." in page
    assert "dataClass==='observed'" in page
    node = require_node()
    script = re.findall(r"<script>(.*?)</script>", page, re.S)[0]
    program = r'''
const vm=require('node:vm'),assert=require('node:assert/strict');
const nodes=new Map(),timers=[];let requests=0,authorized=false,authRetries=0;
function el(id){if(!nodes.has(id))nodes.set(id,{open:false,value:'',textContent:'',innerHTML:'',style:{},handlers:{},addEventListener(name,fn){this.handlers[name]=fn}});return nodes.get(id)}
const data={context_id:'technical-recorded-context',profile:'healthy',channels:[],n_recorded:0,n_recent_observed:0,n_pending:0};
const context={document:{hidden:false,getElementById:el,addEventListener(){}},window:{addEventListener(){},location:{reload(){authRetries++;}}},performance:{now:()=>0},requestAnimationFrame:()=>1,setInterval:fn=>{timers.push(fn);return 1},fetch:async()=>{requests++;return{status:authorized?200:401,ok:authorized,json:async()=>data}}};
const flush=async()=>{for(let i=0;i<8;i++)await new Promise(setImmediate)};
(async()=>{
vm.runInNewContext(SCRIPT,context);await flush();assert.equal(requests,0,'closed secondary view made a protected request');
el('recorded-patch-workspace').open=true;el('recorded-patch-workspace').handlers.toggle();await flush();
assert.equal(requests,1);assert.match(el('chGrid').innerHTML,/Authorization required/);
for(let i=0;i<3;i++)timers[0]();await flush();assert.equal(requests,1,'unauthorized view polled repeatedly');assert.equal(authRetries,0,'automatic authorization retries');
await vm.runInNewContext('retryAuthorization()',context);await flush();assert.equal(authRetries,1);assert.equal(requests,1,'explicit navigation replayed a protected read');
// A fresh document, after server cookie delivery, can read again on user entry.
authorized=true;nodes.clear();timers.length=0;
const fresh={...context,document:{...context.document,hidden:false}};
vm.runInNewContext(SCRIPT,fresh);await flush();assert.equal(requests,1,'fresh closed view made a request');
el('recorded-patch-workspace').open=true;el('recorded-patch-workspace').handlers.toggle();await flush();assert.equal(requests,2);
fresh.document.hidden=true;timers[0]();await flush();assert.equal(requests,2,'hidden recorded view polled');
fresh.document.hidden=false;el('recorded-patch-workspace').open=false;el('recorded-patch-workspace').handlers.toggle();timers[0]();await flush();assert.equal(requests,2,'closed recorded view polled');
el('recorded-patch-workspace').open=true;el('recorded-patch-workspace').handlers.toggle();await flush();assert.equal(requests,3);timers[0]();await flush();assert.equal(requests,4,'open authorized visible view stopped working');
process.stdout.write('ok');
})().catch(error=>{console.error(error);process.exitCode=1});
'''.replace("SCRIPT", json.dumps(script))
    result = _run_node([node, "--eval", program], capture_output=True, text=True, timeout=10, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    assert result.stdout == "ok"
