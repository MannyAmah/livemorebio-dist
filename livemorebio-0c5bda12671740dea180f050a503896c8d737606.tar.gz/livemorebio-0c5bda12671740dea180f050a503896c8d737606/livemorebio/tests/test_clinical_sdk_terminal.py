"""Descriptive attached-client parity; authored fixtures, no service or person."""
from copy import deepcopy
from types import SimpleNamespace

import pytest

from livemorebio.tests.stack_client_fixtures import install_stack_client_opener

from livemorebio.sdk import Platform
from livemorebio.shell import run_command, run_pipeline


PRIVATE = "PRIVATE_CLINICAL_SENTINEL"
TWIN = "twin-technical-one"
COHORT = "cohort-technical-one"
AVAILABILITY = {
    "schema": "livemore.model-availability.v1", "state": "UNAVAILABLE",
    "reason_code": "MODEL_BINDING_REQUIRED", "selection_mode": "observations_only",
    "twin_id": TWIN, "twin_version": 3, "source_generation": "technical-generation",
    "preparation_available": False,
}
SELECTED = {"twin_id": TWIN, "version": 3, "source_class": "REAL_HUMAN",
            "model_availability": AVAILABILITY, "display_label": PRIVATE,
            "observations": {"note": PRIVATE}}
MEMBER = {"schema": "livemore.frozen-real-human-member.v1", "source_class": "REAL_HUMAN",
          "twin_id": TWIN, "record_version": 2, "snapshot_sha256": "a" * 64,
          "evidence_sha256": "b" * 64,
          "snapshot": {"twin_id": TWIN, "version": 2, "source_class": "REAL_HUMAN",
                       "display_label": PRIVATE, "observations": {"note": PRIVATE}}}
PAGE = {"members": [{"twin_id": TWIN, "record_version": 2, "source_class": "REAL_HUMAN",
                    "display_label": PRIVATE, "execution_eligibility": {
                        "state": "UNAVAILABLE", "reason_code": "MODEL_BINDING_REQUIRED"}}],
        "pagination": {"limit": 10, "total": 1000, "has_more": True, "next_cursor": "0001_-"}}


def transport(monkeypatch, result):
    platform = Platform(mode="attach")
    calls = []
    def request(*args, **kwargs):
        calls.append((args, kwargs))
        return deepcopy(result)
    monkeypatch.setattr(platform, "_continuous_request", request)
    return platform, calls


def test_explicit_selection_submits_exact_revision_once_without_activation(monkeypatch):
    platform, calls = transport(monkeypatch, SELECTED)
    result = platform.select_twin_observations(TWIN, expected_version=2)
    assert result == SELECTED
    assert calls == [(("POST", f"/api/twins/{TWIN}/select-observations", {"expected_version": 2}), {})]


def test_selection_acknowledgment_from_actual_preparation_and_availability_helpers(monkeypatch):
    from livemorebio.aegle.subjects import prepare_observation_selection
    from livemorebio.aegle.model_contexts import model_availability
    from .clinical_registry_fixtures import legacy_twin_record, forbid_compilation
    forbid_compilation(monkeypatch)
    original = legacy_twin_record(version=2)
    original["twin_id"] = TWIN
    prepared = prepare_observation_selection(original, expected_version=2).record
    availability = model_availability(prepared, source_generation="technical-generation", selection_mode="observations_only")
    acknowledgment = {**prepared, "model_availability": availability}
    assert original["version"] == 2 and prepared["version"] == availability["twin_version"] == 3
    platform, calls = transport(monkeypatch, acknowledgment)
    assert platform.select_twin_observations(TWIN, expected_version=2) == acknowledgment
    assert len(calls) == 1 and calls[0][0][2] == {"expected_version": 2}


def test_frozen_members_are_one_page_and_detail_is_a_separate_explicit_read(monkeypatch):
    platform, calls = transport(monkeypatch, PAGE)
    assert platform.list_cohort_members(COHORT) == PAGE
    assert calls == [(("GET", f"/api/cohorts/{COHORT}/members?limit=10"), {})]
    platform.list_cohort_members(COHORT, cursor="0001_-")
    assert calls[-1][0][1].endswith("limit=10&cursor=0001_-")
    platform, calls = transport(monkeypatch, MEMBER)
    assert platform.get_cohort_member(COHORT, TWIN) == MEMBER
    assert calls == [(("GET", f"/api/cohorts/{COHORT}/members/{TWIN}"), {})]


@pytest.mark.parametrize("value", [True, False, 0, -1, 2.0, "2", None, 2**53])
def test_invalid_selection_revision_never_reaches_transport(monkeypatch, value):
    platform, calls = transport(monkeypatch, SELECTED)
    with pytest.raises(ValueError):
        platform.select_twin_observations(TWIN, expected_version=value)
    assert calls == []


@pytest.mark.parametrize("limit", [True, False, 0, -1, 51, 10.0, "10"])
def test_invalid_page_limit_never_reaches_transport(monkeypatch, limit):
    platform, calls = transport(monkeypatch, PAGE)
    with pytest.raises(ValueError):
        platform.list_cohort_members(COHORT, limit=limit)
    assert calls == []


@pytest.mark.parametrize("cursor", [True, 1, "", " leading", "line\nbreak", "a/b", "a" * 1025])
def test_invalid_cursor_never_reaches_transport(monkeypatch, cursor):
    platform, calls = transport(monkeypatch, PAGE)
    with pytest.raises(ValueError):
        platform.list_cohort_members(COHORT, cursor=cursor)
    assert calls == []


@pytest.mark.parametrize("identifier", [None, True, 1, "", "../private", "a/b", "a?private", "x" * 201])
def test_invalid_record_identity_never_reaches_transport(monkeypatch, identifier):
    platform, calls = transport(monkeypatch, PAGE)
    for operation in (
        lambda: platform.select_twin_observations(identifier, expected_version=2),
        lambda: platform.list_cohort_members(identifier),
        lambda: platform.get_cohort_member(COHORT, identifier),
    ):
        with pytest.raises(ValueError):
            operation()
    assert calls == []


def test_attach_requirement_cannot_construct_local_twin_or_store(monkeypatch):
    platform = object.__new__(Platform)
    platform.mode = "inprocess"
    monkeypatch.setattr(platform, "_continuous_request", lambda *a, **kw: pytest.fail("fallback"))
    for operation in (
        lambda: platform.select_twin_observations(TWIN, expected_version=2),
        lambda: platform.list_cohort_members(COHORT),
        lambda: platform.get_cohort_member(COHORT, TWIN),
    ):
        with pytest.raises(ValueError):
            operation()


@pytest.mark.parametrize("change", [
    lambda x: x.update(twin_id="twin-other"),
    lambda x: x.update(version=2),
    lambda x: x.update(version=4),
    lambda x: x["model_availability"].update(twin_version=2),
    lambda x: x["model_availability"].update(twin_version=4),
    lambda x: (x.update(version=2), x["model_availability"].update(twin_version=2)),
    lambda x: (x.update(version=4), x["model_availability"].update(twin_version=4)),
    lambda x: x["model_availability"].update(state="READY"),
    lambda x: x["model_availability"].update(preparation_available=True),
    lambda x: x["model_availability"].update(selection_mode="model"),
    lambda x: x["model_availability"].update(reason_code="COHORT_MEMBER_SNAPSHOT_REQUIRED"),
    lambda x: x["model_availability"].update(source_generation="private\nstate"),
    lambda x: x["model_availability"].update(extra=True),
])
def test_invalid_mutation_acknowledgment_stays_unconfirmed(monkeypatch, change):
    from livemorebio.execution_client import ContinuousClientError
    value = deepcopy(SELECTED)
    change(value)
    platform, calls = transport(monkeypatch, value)
    platform.last_continuous_response = {"request_id": "c" * 32}
    with pytest.raises(ContinuousClientError) as error:
        platform.select_twin_observations(TWIN, expected_version=2)
    assert error.value.code == "CLIENT_UNCONFIRMED"
    assert error.value.request_id == "c" * 32 and len(calls) == 1


@pytest.mark.parametrize("kind", ["member_id", "snapshot_version", "page_limit", "page_source"])
def test_wrong_frozen_detail_or_page_is_not_returned_as_valid(monkeypatch, kind):
    value = deepcopy(MEMBER if kind.startswith(("member", "snapshot")) else PAGE)
    if kind == "member_id":
        value["twin_id"] = "twin-other"
    elif kind == "snapshot_version":
        value["snapshot"]["version"] = 99
    elif kind == "page_limit":
        value["pagination"]["limit"] = 50
    else:
        value["members"][0]["source_class"] = "SYNTHETIC"
    platform, calls = transport(monkeypatch, value)
    with pytest.raises(ValueError):
        platform.get_cohort_member(COHORT, TWIN) if "snapshot" in value else platform.list_cohort_members(COHORT)
    assert len(calls) == 1


def test_terminal_commands_do_not_print_clinical_payloads(monkeypatch):
    calls, lines = [], []
    platform = SimpleNamespace(
        select_twin_observations=lambda *a, **kw: calls.append(("selection", a, kw)) or SELECTED,
        list_cohort_members=lambda *a, **kw: calls.append(("members", a, kw)) or PAGE,
        get_cohort_member=lambda *a, **kw: calls.append(("member", a, kw)) or MEMBER,
    )
    run_command(platform, f"twin select-observations {TWIN} version=2", out=lines.append)
    run_command(platform, f"cohort members {COHORT} cursor=0001_-", out=lines.append)
    run_command(platform, f"cohort member {COHORT} {TWIN}", out=lines.append)
    assert [x[0] for x in calls] == ["selection", "members", "member"]
    assert calls[0][2] == {"expected_version": 2}
    assert calls[1][2] == {"limit": 10, "cursor": "0001_-"}
    assert "version=3" in lines[0], "terminal did not show committed selection revision"
    assert PRIVATE not in "\n".join(lines)
    assert "MODEL_BINDING_REQUIRED" in "\n".join(lines)


@pytest.mark.parametrize("line", [
    f"twin select-observations {TWIN}", f"twin select-observations {TWIN} version=true",
    f"twin select-observations {TWIN} version=2.0", f"twin select-observations {TWIN} version=2 version=3",
    f"twin select-observations {TWIN} version=2 extra=private",
    f"cohort members {COHORT} limit=0", f"cohort members {COHORT} limit=10 limit=50",
    f"cohort members {COHORT} json=true", f"cohort member {COHORT}",
    f"cohort member {COHORT} {TWIN} output=private.json",
])
def test_bad_new_commands_reject_before_any_sdk_operation(line):
    class NoCalls:
        def __getattr__(self, name):
            pytest.fail("invalid command reached SDK")
    with pytest.raises(ValueError):
        run_command(NoCalls(), line, out=lambda text: None)


def test_compact_real_cohort_list_has_no_seed_requirement_or_private_label():
    lines = []
    platform = SimpleNamespace(list_cohorts=lambda **kw: {"cohorts": [
        {"cohort_id": COHORT, "source_class": "REAL_HUMAN", "size": 1000,
         "name": PRIVATE, "version": 4, "execution_eligibility": {"state": "UNAVAILABLE", "reason_code": "MODEL_BINDING_REQUIRED"}},
        {"cohort_id": "cohort-synthetic", "source_class": "SYNTHETIC", "size": 5, "seed": 42}],
        "pagination": {"limit": 25, "next_cursor": None, "has_more": False}})
    run_command(platform, "cohort list", out=lines.append)
    assert PRIVATE not in "\n".join(lines)
    assert "seed 42" in "\n".join(lines) and "MODEL_BINDING_REQUIRED" in "\n".join(lines)


@pytest.mark.parametrize("prefix", ["cohort member", "'cohort' 'member'", "COHORT MEMBER"])
@pytest.mark.parametrize("suffix", ["", " 'PRIVATE_UNTERMINATED"])
def test_pipeline_echo_redacts_new_command_arguments(tmp_path, monkeypatch, prefix, suffix):
    # The file is a test input, not a clinical record or product output.
    pipeline = tmp_path / "technical.txt"
    pipeline.write_text(f"{prefix} {COHORT} {TWIN}{suffix}\n", encoding="utf-8")
    lines = []
    import livemorebio.shell as shell
    monkeypatch.setattr(shell, "run_command", lambda *a, **kw: None)
    run_pipeline(SimpleNamespace(), str(pipeline), out=lines.append)
    assert lines == ["livemore› cohort member"]


@pytest.mark.parametrize("limit", [1, 50])
def test_exact_valid_page_bound_is_preserved_without_following_cursor(monkeypatch, limit):
    page = deepcopy(PAGE)
    page["pagination"]["limit"] = limit
    platform, calls = transport(monkeypatch, page)
    platform.list_cohort_members(COHORT, limit=limit)
    assert len(calls) == 1 and calls[0][0][1].endswith(f"limit={limit}")


@pytest.mark.parametrize("outcome", ["timeout", "malformed", "cleanup", "commit"])
def test_real_transport_selection_is_once_only_private_and_keeps_operation_identity(monkeypatch, outcome):
    import json
    from livemorebio import execution_client
    operation_id = "563e4d61-9872-4fe3-820b-a18903a522a0"
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_url", lambda: "http://127.0.0.1:9999")
    monkeypatch.setattr("livemorebio.security.authorization_headers", lambda: {"Authorization": "Bearer fixture"})
    calls = []
    code = "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED" if outcome == "cleanup" else "SELECTION_COMMIT_UNCONFIRMED"
    def open_once(request, timeout):
        calls.append(request)
        assert request.method == "POST" and request.full_url.endswith(f"/api/twins/{TWIN}/select-observations")
        assert json.loads(request.data) == {"expected_version": 2}
        if outcome == "timeout":
            raise TimeoutError(PRIVATE)
        return SimpleNamespace(status=200 if outcome == "malformed" else 503,
            headers={"X-Request-ID": operation_id},
            read=lambda size: b'{"unreadable":' if outcome == "malformed" else json.dumps({"code": code, "error": PRIVATE}).encode(),
            close=lambda: None)
    install_stack_client_opener(monkeypatch, lambda *a: SimpleNamespace(open=open_once))
    with pytest.raises(execution_client.ContinuousClientError) as error:
        platform.select_twin_observations(TWIN, expected_version=2)
    assert len(calls) == 1 and PRIVATE not in str(error.value)
    assert error.value.code == ("CLIENT_UNCONFIRMED" if outcome in {"timeout", "malformed"} else code)
    assert error.value.request_id == (None if outcome == "timeout" else operation_id)


def unavailable_projection(monkeypatch):
    from livemorebio.aegle.clinical_views import unavailable_state
    from livemorebio.aegle.observation_state import ObservationState
    from .clinical_registry_fixtures import forbid_compilation
    forbid_compilation(monkeypatch)
    observed = ObservationState()
    observed.observations = {"authored_technical_value": {"note": PRIVATE}}
    return unavailable_state(deepcopy(AVAILABILITY), observed)


def state_read(monkeypatch, platform, value=None, *, error=None):
    """The attached state seam migrated; never fall through to any local service."""
    calls = []
    def read(method, path, *args, **kwargs):
        assert (method, path, args, kwargs) == ("GET", "/api/state", (), {})
        calls.append(path)
        if error is not None:
            raise error
        return deepcopy(value)
    monkeypatch.setattr(platform, "_continuous_request", read)
    monkeypatch.setattr(platform, "_get", lambda *a, **k: pytest.fail("legacy transport fallback"))
    return calls


def test_sdk_state_and_summary_preserve_actual_unavailable_projection(monkeypatch):
    value = unavailable_projection(monkeypatch)
    platform = Platform(mode="attach")
    calls = state_read(monkeypatch, platform, value)
    summary = platform._summary(value)
    assert summary["subject"] == TWIN
    assert summary["model_availability"] == AVAILABILITY
    assert "observations" not in summary and PRIVATE not in str(summary)
    result = platform.state()
    assert calls == ["/api/state"]
    assert result["model_availability"] == AVAILABILITY
    assert result["observations"] == value["observations"] and result["patch"] == value["patch"]
    assert all(result[key] is None for key in ("profile", "mean_glucose", "hr_bpm", "hrv_ms"))
    result["observations"].clear()
    assert value["observations"], "caller changed the source projection"


def test_attached_shell_starts_and_shows_unavailable_without_payload_dump(monkeypatch, capsys):
    import livemorebio.shell as shell
    value = unavailable_projection(monkeypatch)
    platform = Platform(mode="attach")
    paths = state_read(monkeypatch, platform, value)
    monkeypatch.setattr(shell, "Platform", lambda **kw: platform)
    commands = iter(["show", "quit"])
    monkeypatch.setattr("builtins.input", lambda *a: next(commands))
    shell.run_shell(mode="attach")
    output = capsys.readouterr().out
    assert paths == ["/api/state", "/api/state"]
    assert "UNAVAILABLE" in output and "MODEL_BINDING_REQUIRED" in output and TWIN in output
    assert "bye" in output and PRIVATE not in output and "active twin: None" not in output


@pytest.mark.parametrize("change", [
    lambda x: x.pop("model_availability"),
    lambda x: x["model_availability"].update(state="READY"),
    lambda x: x["model_availability"].update(twin_version=True),
    lambda x: x["model_availability"].update(preparation_available=True),
    lambda x: x["model_availability"].update(reason_code="private-secret"),
    lambda x: x.update(metabolic={"mean_glucose": 123.0}),
    lambda x: x.update(cardiac={"hr_bpm": 80}),
    lambda x: x.update(profile="old numerical context"),
])
def test_unavailable_state_contradictions_are_not_blank_or_old_physiology(monkeypatch, change):
    from livemorebio.execution_client import ContinuousClientError
    value = unavailable_projection(monkeypatch)
    change(value)
    platform = Platform(mode="attach")
    reads = state_read(monkeypatch, platform, value)
    with pytest.raises(ContinuousClientError) as error:
        platform.state()
    assert error.value.code == "CLIENT_RESPONSE"
    assert reads == ["/api/state"]


def test_legacy_ready_sdk_state_shape_and_numerical_values_are_unchanged(monkeypatch):
    platform = Platform(mode="attach")
    value = {"profile": "technical reference", "human": {"id": "technical"},
             "metabolic": {"mean_glucose": 101}, "cardiac": {"hr_bpm": 68, "hrv_ms": 29}}
    reads = state_read(monkeypatch, platform, value)
    assert platform.state() == {"summary": {"profile": "technical reference", "subject": "technical",
        "mean_glucose": 101, "hr_bpm": 68, "hrv_ms": 29}, "profile": "technical reference",
        "mean_glucose": 101, "hr_bpm": 68, "hrv_ms": 29}
    assert reads == ["/api/state"]


def test_sdk_state_does_not_swallow_operational_failure(monkeypatch):
    platform = Platform(mode="attach")
    reads = state_read(monkeypatch, platform, error=TimeoutError("technical unavailable endpoint"))
    with pytest.raises(TimeoutError):
        platform.state()
    assert reads == ["/api/state"]


@pytest.mark.parametrize("direct_summary", [False, True])
def test_legacy_state_validation_never_reuses_previous_selection_request_id(monkeypatch, direct_summary):
    from livemorebio.execution_client import ContinuousClientError
    prior_id = "563e4d61-9872-4fe3-820b-a18903a522a0"
    platform, mutations = transport(monkeypatch, SELECTED)
    platform.last_continuous_response = {"request_id": prior_id}
    assert platform.select_twin_observations(TWIN, expected_version=2) == SELECTED
    value = unavailable_projection(monkeypatch)
    value["model_availability"]["twin_version"] = True
    reads = state_read(monkeypatch, platform, value)
    with pytest.raises(ContinuousClientError) as error:
        platform._summary(value) if direct_summary else platform.state()
    assert error.value.code == "CLIENT_RESPONSE" and error.value.status == 200
    assert error.value.request_id is None, "state validation inherited a mutation's operation identity"
    assert platform.last_continuous_response == {"request_id": prior_id}
    assert len(mutations) == 1 and reads == ([] if direct_summary else ["/api/state"])


def test_show_workspace_keeps_unavailable_metadata_without_numeric_counts():
    from livemorebio.aegle.clinical_views import unavailable_multiscale
    workspace = {"model_availability": deepcopy(AVAILABILITY),
                 "multiscale": unavailable_multiscale({"subject_id": PRIVATE}, AVAILABILITY)}
    platform = SimpleNamespace(workspace=lambda: workspace)
    lines = []
    run_command(platform, "show workspace", out=lines.append)
    text = "\n".join(lines)
    assert "UNAVAILABLE" in text and "MODEL_BINDING_REQUIRED" in text and TWIN in text
    assert PRIVATE not in text and "nodes=" not in text and "edges=" not in text and "executed=" not in text


@pytest.mark.parametrize("preview", [False, True])
def test_typed_ready_availability_preserves_numerical_summary(monkeypatch, preview):
    from livemorebio.aegle.model_contexts import model_availability
    record = None if preview else {"twin_id": TWIN, "version": 2, "source_class": "SYNTHETIC"}
    availability = model_availability(record, source_generation="technical-generation")
    source = {"profile": "technical reference", "metabolic": {"mean_glucose": 101},
              "cardiac": {"hr_bpm": 68, "hrv_ms": 29}, "model_availability": availability}
    platform = Platform(mode="attach")
    reads = state_read(monkeypatch, platform, source)
    result = platform.state()
    assert result["mean_glucose"] == 101 and result["hr_bpm"] == 68 and result["hrv_ms"] == 29
    assert result["model_availability"] == availability == result["summary"]["model_availability"]
    assert reads == ["/api/state"]


@pytest.mark.parametrize("prefix,family", [
    ('co"hort" member', "cohort member"),
    ('twin select-"observations"', "twin select-observations"),
    ('c\\ohort mem"bers"', "cohort members"),
])
def test_partial_quoted_words_redact_malformed_tail_and_reject_before_dispatch(tmp_path, prefix, family):
    from livemorebio.execution_client import ContinuousClientError
    line = f"{prefix} {TWIN} 'PRIVATE_SENTINEL"
    path = tmp_path / "authored-malformed-command.txt"
    path.write_text(line + "\n", encoding="utf-8")
    class NoCalls:
        def __getattr__(self, name):
            pytest.fail("malformed clinical command reached SDK")
    output = []
    with pytest.raises(ContinuousClientError):
        run_pipeline(NoCalls(), str(path), out=output.append)
    assert output == [f"livemore› {family}"]
    assert "PRIVATE_SENTINEL" not in str(output)


def test_unclassifiable_malformed_pipeline_does_not_echo_arguments(tmp_path, monkeypatch):
    import livemorebio.shell as shell
    path = tmp_path / "authored-unknown-command.txt"
    path.write_text("co\"hort PRIVATE_SENTINEL\n", encoding="utf-8")
    output = []
    monkeypatch.setattr(shell, "run_command", lambda *a, **kw: None)
    run_pipeline(SimpleNamespace(), str(path), out=output.append)
    assert output == ["livemore› invalid command (arguments withheld)"]
