"""Compose wiring must pass the real target Host gates; technical fixtures only."""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import urlsplit

import pytest

from ._source_tree import require_source_tree, source_tree_only

ROOT = Path(__file__).resolve().parents[2]
pytestmark = source_tree_only("docker-compose.yml")
MODULES = {"aegle": "livemorebio.aegle.server", "life": "livemorebio.life_system.service",
           "cendos": "livemorebio.cendos.service"}


def _compose_environments(text):
    """Read this file's scalar service environments, refusing an unexamined layout."""
    services = text.split("services:\n", 1)[1].split("\nvolumes:", 1)[0]
    environments = {}
    for match in re.finditer(r"(?m)^  ([a-z][a-z0-9_-]*):\n((?:    [^\n]*\n|\n)+)", services):
        name, body = match.groups()
        environment = re.search(r"(?m)^    environment:\n((?:      [^\n]*\n)+)", body)
        assert environment, f"{name} has no examined environment mapping"
        values = {}
        for line in environment.group(1).splitlines():
            item = re.fullmatch(r"      ([A-Z][A-Z0-9_]*): (.*)", line)
            assert item, f"unexamined Compose environment: {line}"
            key, value = item.groups()
            values[key] = value
        environments[name] = values
    assert environments and set(environments) == set(MODULES)
    return environments


_PROBE = r'''
import importlib, json, socket, sys
from fastapi.testclient import TestClient

def no_socket(*args, **kwargs):
    raise AssertionError("Compose Host admission test attempted a real network connection")
socket.socket.connect = no_socket
socket.create_connection = no_socket
module_name, hosts, marker, route_table = json.loads(sys.argv[1])
# This native probe imports the compose environment, whose console opt-in
# requires container evidence. Supply technical files without using host state.
from livemorebio import security
security._CONTAINER_MARKER = marker
security._ROUTE_TABLE = route_table
app = importlib.import_module(module_name).app
client = TestClient(app, base_url="http://127.0.0.1:19000", raise_server_exceptions=False)
print(json.dumps([client.get("/health", headers={"Host": host}).status_code for host in hosts]))
'''


def test_compose_service_urls_are_admitted_by_the_target_host_gate(tmp_path):
    require_source_tree("docker-compose.yml")
    environments = _compose_environments((ROOT / "docker-compose.yml").read_text(encoding="utf-8"))
    target_hosts = {name: [] for name in environments}
    for sender, configured in environments.items():
        assert configured.get("LIVEMORE_SERVICE") == sender
        for key, value in configured.items():
            if not re.fullmatch(r"LIVEMORE_[A-Z0-9_]+_URL", key):
                continue
            parsed = urlsplit(value)
            assert parsed.hostname in environments, (sender, key, value)
            assert environments[parsed.hostname]["LIVEMORE_SERVICE"] == parsed.hostname
            target_hosts[parsed.hostname].append(parsed.netloc)
    assert all(target_hosts.values()), "every target must have an actual incoming Compose service URL"

    marker = tmp_path / "technical-dockerenv"
    marker.write_text("", encoding="ascii")
    route_table = tmp_path / "technical-routes"
    route_table.write_text(
        "Iface\tDestination\tGateway\tFlags\tRefCnt\tUse\tMetric\tMask\tMTU\tWindow\tIRTT\n"
        "eth0\t00000000\t010012AC\t0003\t0\t0\t0\t00000000\t0\t0\t0\n",
        encoding="ascii",
    )
    for target, configured in environments.items():
        environment = {key: value for key, value in os.environ.items()
                       if not key.startswith("LIVEMORE_") and key != "CENDOS_DB"}
        directory = tmp_path / target
        directory.mkdir()
        for name in ("HOME", "TMPDIR", "LIVEMORE_DATA_DIR"):
            path = directory / name.lower()
            path.mkdir()
            environment[name] = str(path)
        for key, value in configured.items():
            if value.startswith("${"):
                # Compose interpolation receives isolated technical values, never the operator's shell.
                value = ("technical-compose-token" if key == "LIVEMORE_API_TOKEN" else
                         "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=" if key in {
                             "LIVEMORE_PATCH_STORAGE_KEY", "LIVEMORE_PATCH_ADMISSION_HMAC_KEY"} else "")
            if key == "LIVEMORE_PATCH_JOURNAL":
                value = str(directory / "livemore_data_dir" / "technical-journal.jsonl")
            environment[key] = value
        environment.update(PYTHONDONTWRITEBYTECODE="1", LIVEMORE_STACK_FILE="")
        environment.pop("LIVEMORE_ALLOWED_HOSTS", None)
        peer = next(name for name in environments if name != target)
        hosts = [*target_hosts[target], peer + ":19000", target + ".:19000"]
        result = subprocess.run([sys.executable, "-B", "-c", _PROBE,
                                 json.dumps([MODULES[target], hosts, str(marker), str(route_table)])],
                                cwd=ROOT, env=environment,
                                text=True, capture_output=True, timeout=30, encoding="utf-8")
        assert result.returncode == 0, result.stderr
        statuses = json.loads(result.stdout)
        assert statuses[:-2] == [200] * len(target_hosts[target]), (target, hosts, statuses)
        assert statuses[-2:] == [400, 400], (target, hosts, statuses)
