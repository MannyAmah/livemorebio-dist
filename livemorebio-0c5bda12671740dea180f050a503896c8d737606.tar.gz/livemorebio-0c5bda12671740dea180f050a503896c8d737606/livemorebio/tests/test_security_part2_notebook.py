"""DEP-3 regression: inspect the supervised command without starting any server."""
import io
import sys

import pytest

from livemorebio import cli, notebook, notebook_launch, registry


@pytest.mark.parametrize("no_browser", [False, True])
def test_dep3_notebook_extension_manager_is_readonly(tmp_path, monkeypatch, no_browser):
    workspace = tmp_path / "technical-notebook"
    target = workspace / "livemore_workspace.ipynb"
    monkeypatch.setattr(registry, "REG_DIR", str(tmp_path / "empty-data"))
    monkeypatch.setattr(notebook, "ensure_workspace", lambda directory: target)
    command = []

    class TechnicalChild:
        pid = 98765
        returncode = None
        stdout, stderr = io.BytesIO(), io.BytesIO()
        def poll(self):
            return self.returncode
        def wait(self):
            self.returncode = 0
            return 0

    def capture_spawn(arguments, **kwargs):
        command.extend(arguments)
        assert "JUPYTER_TOKEN" not in kwargs["env"]
        return TechnicalChild()

    monkeypatch.setattr(cli.os, "execv", lambda *args: pytest.fail("must supervise, not exec"))
    monkeypatch.setattr(notebook_launch.subprocess, "Popen", capture_spawn)
    monkeypatch.setattr(notebook_launch, "process_identity", lambda pid: f"technical-{pid}")
    monkeypatch.setattr(notebook_launch, "wait_for_ready", lambda *args: True)
    monkeypatch.setattr(notebook_launch, "browser_available", lambda: True)
    monkeypatch.setattr(notebook_launch, "open_launch_file", lambda path: True)
    monkeypatch.setattr(sys, "argv", ["livemore", "notebook", "--dir", str(workspace), "--port", "18893"]
                        + (["--no-browser"] if no_browser else []))

    with pytest.raises(SystemExit) as stopped:
        cli.main()

    assert stopped.value.code == 0
    assert command[:3] == [cli.PYTHON, "-m", "jupyterlab"]
    assert "--LabApp.extension_manager=readonly" in command
    assert "--port=18893" in command and str(target) in command
    assert "--ServerApp.open_browser=False" in command
