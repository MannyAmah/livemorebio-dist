"""Independent technical cleanup races; no physiological engine is constructed."""
from concurrent.futures import ThreadPoolExecutor
import threading

import pytest

from livemorebio.aegle.execution_contract import ExecutionError
from livemorebio.tests.test_continuous_execution import TechnicalAdapter, captured_source
from livemorebio.tests.test_execution_source_fence import bound_manager, prepare, start
from ._timing import wait_seconds


@pytest.mark.parametrize("expiry_observed_before_result", [True, False])
def test_late_initialization_cleanup_cannot_close_a_replacement_adapter(
    tmp_path, monkeypatch, expiry_observed_before_result,
):
    initialized, finish_initialize = threading.Event(), threading.Event()
    finalizing, finish_finalize = threading.Event(), threading.Event()
    instances = []
    starter_thread = []
    now = [0.0]

    class DelayedTechnicalAdapter(TechnicalAdapter):
        def __init__(self, source):
            super().__init__(source)
            self.close_count = 0
            instances.append(self)

        def initialize(self):
            if self is instances[0]:
                initialized.set()
                assert finish_initialize.wait(5), "technical initialization was not released"
            return super().initialize()

        def close(self):
            assert not manager._lock._is_owned()
            self.close_count += 1

    manager = bound_manager(tmp_path, DelayedTechnicalAdapter)
    manager._clock = lambda: now[0]
    record = prepare(manager)
    execution_id = record["execution_id"]
    session_id = "b" * 32
    bound = manager.bind_consumer(
        execution_id, session_id, record["source_snapshot_hash"],
        expected_revision=record["revision"], expected_source_generation="generation-a",
    )
    original_release = manager._release

    def delay_final_cleanup(*args, **kwargs):
        # Pin the real gap after the old activation's finally has chosen its
        # cleanup, but before cleanup acquires the manager lock and finds a handle.
        if starter_thread and threading.get_ident() == starter_thread[0]:
            finalizing.set()
            assert finish_finalize.wait(5), "technical finalization was not released"
        return original_release(*args, **kwargs)

    def start_old_activation():
        starter_thread.append(threading.get_ident())
        return start(manager, bound)

    monkeypatch.setattr(manager, "_release", delay_final_cleanup)
    try:
        with ThreadPoolExecutor(1) as pool:
            old = pool.submit(start_old_activation)
            try:
                assert initialized.wait(3)
                now[0] = 31.0
                if expiry_observed_before_result:
                    paused = manager.status(execution_id)
                    assert paused["state"] == "paused"
                    assert instances[0].close_count == 1
                # With no poll, expiry is first noticed at initialization's
                # final commit. Its old adapter still exists during cleanup,
                # so resume takes the retained-adapter rather than rebuild path.
                finish_initialize.set()
                assert finalizing.wait(3)
                manager.renew_consumer(
                    execution_id, session_id, record["source_snapshot_hash"],
                    expected_source_generation="generation-a",
                )
                current = manager.status(execution_id)
                with pytest.raises(ExecutionError) as conflict:
                    manager.resume(
                        execution_id, expected_revision=current["revision"],
                        expected_source_generation="generation-a",
                    )
                assert conflict.value.code == "EXECUTION_CONFLICT"
                assert len(instances) == 1, "resume launched while old cleanup still owned the lifecycle"
                assert manager.store.get(execution_id)["checkpoint"] is None
            finally:
                finish_initialize.set()
                finish_finalize.set()
            with pytest.raises(ExecutionError) as stale:
                old.result(timeout=wait_seconds(3))
            assert stale.value.code == "EXECUTION_CONFLICT"

        # This is a new explicit intent after the prior call is fully settled,
        # not an automatic POST retry or a reinterpretation of a failed resume.
        current = manager.status(execution_id)
        resumed = manager.resume(
            execution_id, expected_revision=current["revision"],
            expected_source_generation="generation-a",
        )
        assert resumed["state"] == "running"
        assert len(instances) == 2 and instances[1].close_count == 0
        assert manager._adapters[execution_id] is instances[1]
        assert not manager._cleanup_pending and not manager._busy
        assert manager.advance_once(execution_id)["frame_index"] == 1
        assert instances[1].close_count == 0
    finally:
        finish_initialize.set()
        finish_finalize.set()
        monkeypatch.setattr(manager, "_release", original_release)
        manager.close()


def test_late_constructor_retains_owner_until_its_returned_handle_is_closed(tmp_path):
    constructing, finish_constructor = threading.Event(), threading.Event()
    instances = []

    class LateConstructorTechnicalAdapter(TechnicalAdapter):
        fail_close = True

        def __init__(self, source):
            super().__init__(source)
            self.close_count = 0
            instances.append(self)
            constructing.set()
            assert finish_constructor.wait(5), "technical constructor was not released"

        def initialize(self):
            pytest.fail("a revoked constructor result reached numerical initialization")

        def close(self):
            assert not manager._lock._is_owned()
            self.close_count += 1
            if self.fail_close:
                raise RuntimeError("private technical cleanup marker")

    manager = bound_manager(tmp_path, LateConstructorTechnicalAdapter)
    record = prepare(manager)
    execution_id = record["execution_id"]
    try:
        with ThreadPoolExecutor(1) as pool:
            old = pool.submit(start, manager, record)
            try:
                assert constructing.wait(3)
                manager.set_source_generation("generation-b")
                with pytest.raises(ExecutionError) as cancellation:
                    manager.invalidate_source("generation-a", "technical source replacement")
                assert cancellation.value.code == "EXECUTION_CLEANUP_UNCONFIRMED"
                assert execution_id not in manager._adapters
                with pytest.raises(ExecutionError) as ownership:
                    manager.store.acquire_owner(execution_id)
                assert ownership.value.code == "EXECUTION_OWNED"
            finally:
                finish_constructor.set()
            with pytest.raises(ExecutionError) as returned:
                old.result(timeout=wait_seconds(3))
            assert returned.value.code == "EXECUTION_CLEANUP_UNCONFIRMED"
            assert "private technical" not in str(returned.value)

        current = manager.status(execution_id)
        assert current["source_valid"] is False
        assert current["failure_code"] == "EXECUTION_CLEANUP_UNCONFIRMED"
        assert manager.store.get(execution_id)["checkpoint"] is None
        assert manager.frames(execution_id)["frames"] == []
        assert manager._adapters[execution_id] is instances[0]
        assert instances[0].close_count == 1
        with pytest.raises(ExecutionError) as ownership:
            manager.store.acquire_owner(execution_id)
        assert ownership.value.code == "EXECUTION_OWNED"
        instances[0].fail_close = False
        stopped = manager.stop(
            execution_id, expected_revision=current["revision"],
            expected_source_generation="generation-a",
        )
        assert stopped["state"] == "stopped" and stopped["source_valid"] is False
        assert instances[0].close_count == 2
        assert not manager._adapters and not manager._owners and not manager._cleanup_pending
        descriptor = manager.store.acquire_owner(execution_id)
        manager.store.release_owner(descriptor)
    finally:
        finish_constructor.set()
        for adapter in instances:
            adapter.fail_close = False
        manager.close()


def test_lease_expiry_claims_cleanup_before_resume_can_enter_handoff_gap(tmp_path, monkeypatch):
    cancelling, finish_cancellation = threading.Event(), threading.Event()
    expiry_thread = []
    instances = []
    now = [0.0]

    class LeaseTechnicalAdapter(TechnicalAdapter):
        def __init__(self, source):
            super().__init__(source)
            self.close_count = 0
            instances.append(self)

        def close(self):
            assert not manager._lock._is_owned()
            self.close_count += 1

    manager = bound_manager(tmp_path, LeaseTechnicalAdapter)
    manager._clock = lambda: now[0]
    record = prepare(manager)
    execution_id = record["execution_id"]
    session_id = "c" * 32
    bound = manager.bind_consumer(
        execution_id, session_id, record["source_snapshot_hash"],
        expected_revision=record["revision"], expected_source_generation="generation-a",
    )
    start(manager, bound)
    checkpoint = manager.store.get(execution_id)["checkpoint"]
    original_release = manager._release

    def delay_expiry_cleanup(*args, **kwargs):
        # Lease detection has committed paused, but outside-lock native cleanup
        # has not yet entered. A newer resume cannot win this unclaimed gap.
        if expiry_thread and threading.get_ident() == expiry_thread[0]:
            cancelling.set()
            assert finish_cancellation.wait(5), "technical expiry cleanup was not released"
        return original_release(*args, **kwargs)

    def expire_from_status():
        expiry_thread.append(threading.get_ident())
        return manager.status(execution_id)

    monkeypatch.setattr(manager, "_release", delay_expiry_cleanup)
    try:
        now[0] = 31.0
        with ThreadPoolExecutor(1) as pool:
            expired = pool.submit(expire_from_status)
            try:
                assert cancelling.wait(3)
                assert execution_id not in manager._busy
                manager.renew_consumer(
                    execution_id, session_id, record["source_snapshot_hash"],
                    expected_source_generation="generation-a",
                )
                current = manager.status(execution_id)
                assert current["state"] == "paused"
                with pytest.raises(ExecutionError) as blocked:
                    manager.resume(
                        execution_id, expected_revision=current["revision"],
                        expected_source_generation="generation-a",
                    )
                assert blocked.value.code == "EXECUTION_CLEANUP_UNCONFIRMED"
                assert instances[0].close_count == 0 and len(instances) == 1
                assert manager.store.get(execution_id)["checkpoint"] == checkpoint
                with pytest.raises(ExecutionError) as ownership:
                    manager.store.acquire_owner(execution_id)
                assert ownership.value.code == "EXECUTION_OWNED"
            finally:
                finish_cancellation.set()
            assert expired.result(timeout=wait_seconds(3))["state"] == "paused"

        assert instances[0].close_count == 1
        assert execution_id not in manager._adapters and not manager._cleanup_pending
        current = manager.status(execution_id)
        resumed = manager.resume(
            execution_id, expected_revision=current["revision"],
            expected_source_generation="generation-a",
        )
        assert resumed["state"] == "running"
        assert len(instances) == 2 and instances[1].close_count == 0
        assert manager._adapters[execution_id] is instances[1]
        assert manager.advance_once(execution_id)["frame_index"] == 1
        assert instances[1].close_count == 0
    finally:
        finish_cancellation.set()
        monkeypatch.setattr(manager, "_release", original_release)
        manager.close()


@pytest.mark.parametrize("stage", ["constructor", "initialize", "advance"])
def test_storage_read_failure_cancels_late_publication_without_erasing_history(tmp_path, monkeypatch, stage):
    entered, finish_work = threading.Event(), threading.Event()
    closing, finish_close = threading.Event(), threading.Event()
    reader_thread = []
    failed_reads = []
    initialize_calls = []

    class StorageFailureTechnicalAdapter(TechnicalAdapter):
        def __init__(self, source):
            super().__init__(source)
            if stage == "constructor":
                entered.set()
                assert finish_work.wait(5), "technical constructor was not released"

        def initialize(self):
            initialize_calls.append(True)
            if stage == "initialize":
                entered.set()
                assert finish_work.wait(5), "technical initialization was not released"
            return super().initialize()

        def advance(self, checkpoint, native_end):
            if stage == "advance" and native_end > 1.0:
                entered.set()
                assert finish_work.wait(5), "technical advancement was not released"
            return super().advance(checkpoint, native_end)

        def close(self):
            assert not manager._lock._is_owned()
            closing.set()
            assert finish_close.wait(5), "technical cleanup was not released"

    manager = bound_manager(tmp_path, StorageFailureTechnicalAdapter)
    record = prepare(manager)
    execution_id = record["execution_id"]
    if stage == "advance":
        record = start(manager, record)
        assert manager.advance_once(execution_id)["frame_index"] == 1
    original_get = manager.store.get
    before = original_get(execution_id)
    saved_frames = manager.store.frames(execution_id, after_frame=0, limit=50)

    def fail_first_inspection_read(*args, **kwargs):
        # Source authority and durable revision deliberately stay unchanged.
        # A source switch would hide a missing independent cleanup fence.
        if (reader_thread and threading.get_ident() == reader_thread[0]
                and not failed_reads):
            failed_reads.append(True)
            raise ExecutionError("EXECUTION_STORAGE")
        return original_get(*args, **kwargs)

    def inspect_during_work():
        reader_thread.append(threading.get_ident())
        return manager.status(execution_id)

    def work():
        try:
            return manager.advance_once(execution_id) if stage == "advance" else start(manager, record)
        except ExecutionError as error:
            assert error.code in {"EXECUTION_CONFLICT", "EXECUTION_CLEANUP_UNCONFIRMED", "EXECUTION_STORAGE"}
            return None

    monkeypatch.setattr(manager.store, "get", fail_first_inspection_read)
    try:
        with ThreadPoolExecutor(2) as pool:
            result = pool.submit(work)
            assert entered.wait(3)
            inspection = pool.submit(inspect_during_work)
            try:
                if stage == "constructor":
                    # There is no returned adapter to close yet. Cancellation
                    # must retain ownership and reject its eventual publication.
                    with pytest.raises(ExecutionError) as cancellation:
                        inspection.result(timeout=wait_seconds(3))
                    assert cancellation.value.code == "EXECUTION_CLEANUP_UNCONFIRMED"
                    assert execution_id not in manager._adapters
                    finish_close.set()
                else:
                    assert closing.wait(3)
                    assert execution_id in manager._closing
                assert failed_reads == [True]
                assert execution_id in manager._cleanup_pending
                assert manager._permitted_generation == "generation-a"
                assert original_get(execution_id)["source_valid"] is True
                finish_work.set()
                outcome = result.result(timeout=wait_seconds(3))
                if stage == "constructor":
                    assert initialize_calls == [], "cancelled constructor reached initialization"
                assert outcome is None, "cancelled work returned a successful publication"
                after = original_get(execution_id)
                assert after["checkpoint"] == before["checkpoint"]
                assert after["latest_frame"] == before["latest_frame"]
                assert after["latest_frame_hash"] == before["latest_frame_hash"]
                assert manager.store.frames(execution_id, after_frame=0, limit=50) == saved_frames
                assert bool(saved_frames) is (stage == "advance")
            finally:
                finish_work.set()
                finish_close.set()
            if stage != "constructor":
                with pytest.raises(ExecutionError) as cancellation:
                    inspection.result(timeout=wait_seconds(3))
                assert cancellation.value.code == "EXECUTION_STORAGE"

        assert not manager._owners and not manager._adapters and not manager._cleanup_pending
        descriptor = manager.store.acquire_owner(execution_id)
        manager.store.release_owner(descriptor)
    finally:
        finish_work.set()
        finish_close.set()
        monkeypatch.setattr(manager.store, "get", original_get)
        manager.close()


def test_close_waits_for_a_concurrent_cleanup_instead_of_reporting_a_conflict(tmp_path):
    """Shutdown must not fail because another thread is already finishing cleanup.

    Under load the background scheduler can be releasing the same execution when
    close() runs. Reporting EXECUTION_CONFLICT there made a clean shutdown look
    like a failed one. Ownership is still only released once the other thread
    confirms its cleanup.
    """
    import threading
    import time

    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_store import ExecutionStore

    manager = ExecutionManager(ExecutionStore(tmp_path / "close-race.sqlite3", key=b"c" * 32),
                               adapter_registry={"metabolic-continuous-v1": TechnicalAdapter})
    try:
        record = manager.prepare(captured_source(), {"end_native": 1., "frame_period_s": .5, "time_scale": 600.},
                                 "close-race")
        execution_id = record["execution_id"]
        manager.start(execution_id, expected_revision=record["revision"],
                      expected_source_generation="generation-a")
        # Stand in for the scheduler thread holding this execution's cleanup.
        with manager._lock:
            manager._closing.add(execution_id)

        def finish_other_cleanup():
            time.sleep(.2)
            with manager._lock:
                manager._closing.discard(execution_id)
                manager._cleanup_pending.discard(execution_id)
                manager._adapters.pop(execution_id, None)
                manager._owners.pop(execution_id, None)

        worker = threading.Thread(target=finish_other_cleanup)
        worker.start()
        try:
            manager.close()          # must not raise
        finally:
            worker.join()
    finally:
        try:
            manager.close()
        except Exception:
            pass
