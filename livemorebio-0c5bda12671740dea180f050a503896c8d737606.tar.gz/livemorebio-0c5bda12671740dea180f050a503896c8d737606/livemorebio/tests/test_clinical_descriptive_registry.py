"""Descriptive REAL_HUMAN admission and authenticated retries; technical data only."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import hashlib
import json
import sqlite3

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import pytest

from livemorebio.aegle.subjects import SubjectRegistry, SubjectRegistryError
from livemorebio.tests.clinical_registry_fixtures import (
    KEY, TWIN_FIELDS, canonical, forbid_compilation, historical_intent, human_payload,
    legacy_twin_record, record_count, replace_fixture_record, saved_bytes, seed_legacy, sha,
)


@pytest.fixture
def registry(tmp_path):
    return SubjectRegistry(tmp_path / "subjects.sqlite3", key=KEY)


@pytest.mark.parametrize("condition", ["type 1 diabetes", "diabetes insipidus", "no diabetes", "type 2 diabetes", ""])
def test_descriptive_create_without_any_compilation_preserves_unknowns(registry, monkeypatch, condition):
    forbid_compilation(monkeypatch)
    body = human_payload(condition=condition)
    record = registry.create_twin(body, idempotency_key="descriptive-one")
    assert record["conditions"] == body["conditions"]
    assert record["model_binding"] is None
    assert "parameter_provenance" not in record
    assert record["model_parameters"] == {}
    assert record["profile_coverage"]["status"] == "ADMITTED_PARTIAL"
    assert record["observations"]["glucose_mgdl"]["captured_at"] == body["observations"]["glucose_mgdl"]["captured_at"]
    assert record["creation_identity"] == {
        "schema": "livemore.subject-creation-identity.v1", "normalizer_id": "livemore.real-human-descriptive.v1",
        "record_type": "TWIN", "request_sha256": sha({
            "schema": "livemore.descriptive-creation-intent.v1", "normalizer_id": "livemore.real-human-descriptive.v1",
            "record_type": "TWIN", "payload": {field: record[field] for field in TWIN_FIELDS},
        }),
        "idempotency_key_sha256": hashlib.sha256(b"livemore.subject-idempotency-key.v1\0descriptive-one").hexdigest(),
    }


def test_creation_without_key_stores_explicit_null_digest(registry, monkeypatch):
    forbid_compilation(monkeypatch)
    created = registry.create_twin(human_payload())
    assert created["creation_identity"]["idempotency_key_sha256"] is None


@pytest.mark.parametrize("lifecycle,version,extra", [
    ("DATA_ADMITTED", 1, {}),
    ("ACTIVE", 2, {}),
    ("DATA_ADMITTED", 3, {"patch_bindings": [{"device_id": "authored-device", "mode": "physical"}]}),
    ("ACTIVE", 4, {"selection_mode": "observations_only"}),
])
def test_legacy_exact_retry_never_recompiles_or_rewrites_current_version(registry, monkeypatch, lifecycle, version, extra):
    old = legacy_twin_record(version=version)
    old.update(lifecycle=lifecycle, **extra)
    seed_legacy(registry, old, "legacy-key")
    before = saved_bytes(registry, old["twin_id"])
    forbid_compilation(monkeypatch)
    recovered = registry.create_twin(human_payload(), idempotency_key="legacy-key")
    assert recovered == old
    assert saved_bytes(registry, old["twin_id"]) == before
    assert record_count(registry) == 1


@pytest.mark.parametrize("field,change", [
    ("conditions", ["different technical description"]), ("consent_scope", ["digital_twin"]),
    ("chain_of_custody", "urn:test:changed-custody"), ("model_parameters", {"Si": 0.0002}),
])
def test_legacy_changed_descriptive_intent_conflicts_without_repair(registry, monkeypatch, field, change):
    old = legacy_twin_record()
    seed_legacy(registry, old, "legacy-key")
    before = saved_bytes(registry, old["twin_id"])
    forbid_compilation(monkeypatch)
    with pytest.raises(SubjectRegistryError) as caught:
        registry.create_twin({**human_payload(), field: change}, idempotency_key="legacy-key")
    assert caught.value.code == "IDEMPOTENCY_CONFLICT"
    assert saved_bytes(registry, old["twin_id"]) == before


@pytest.mark.parametrize("field,change", [
    ("captured_at", "2026-08-29T12:00:00Z"), ("unit", "mmol/L"), ("source", "different-test-source"),
])
def test_legacy_source_measurement_identity_is_not_normalized_away(registry, monkeypatch, field, change):
    old = legacy_twin_record()
    seed_legacy(registry, old, "legacy-key")
    body = human_payload()
    body["observations"]["glucose_mgdl"][field] = change
    if field == "unit":
        body["observations"]["glucose_mgdl"]["value"] = 100.0 / 18.01559
    forbid_compilation(monkeypatch)
    with pytest.raises(SubjectRegistryError) as caught:
        registry.create_twin(body, idempotency_key="legacy-key")
    assert caught.value.code == "IDEMPOTENCY_CONFLICT"


@pytest.mark.parametrize("field,value", [("model_binding", None), ("model_binding", {"qualified": True}),
    ("creation_identity", {}), ("lifecycle", "ACTIVE"), ("selection_mode", "model")])
def test_reserved_fields_reject_on_new_and_historical_retry(registry, monkeypatch, field, value):
    seed_legacy(registry, legacy_twin_record(), "legacy-key")
    forbid_compilation(monkeypatch)
    for key in ("legacy-key", "new-key"):
        with pytest.raises(SubjectRegistryError) as caught:
            registry.create_twin({**human_payload(), field: value}, idempotency_key=key)
        assert caught.value.code == "INVALID_TWIN_DATA"
    assert record_count(registry) == 1


@pytest.mark.parametrize("mutation", ["missing_projection", "malformed_provenance", "unknown_identity"])
def test_unverifiable_legacy_retry_is_not_silently_repaired(registry, monkeypatch, mutation):
    old = legacy_twin_record()
    seed_legacy(registry, old, "legacy-key")
    if mutation == "missing_projection":
        del old["reference_lineage"]
    elif mutation == "malformed_provenance":
        old["parameter_provenance"] = ["not-a-provenance-object"]
    else:
        old["creation_identity"] = {"schema": "unrecognized-version"}
    replace_fixture_record(registry, old)
    before = saved_bytes(registry, old["twin_id"])
    forbid_compilation(monkeypatch)
    with pytest.raises(SubjectRegistryError) as caught:
        registry.create_twin(human_payload(), idempotency_key="legacy-key")
    assert caught.value.code == "LEGACY_IDEMPOTENCY_UNVERIFIABLE"
    assert saved_bytes(registry, old["twin_id"]) == before


@pytest.mark.parametrize("tamper", ["request_hash", "key_index"])
def test_new_creation_identity_authenticates_plaintext_indexes(registry, monkeypatch, tamper):
    forbid_compilation(monkeypatch)
    created = registry.create_twin(human_payload(), idempotency_key="exact-key")
    key = "substituted-key" if tamper == "key_index" else "exact-key"
    with sqlite3.connect(registry.path) as connection:
        if tamper == "key_index":
            connection.execute("UPDATE records SET idempotency_key=? WHERE record_id=?", (key, created["twin_id"]))
        else:
            connection.execute("UPDATE records SET request_hash=? WHERE record_id=?", ("0" * 64, created["twin_id"]))
    before = saved_bytes(registry, created["twin_id"])
    with pytest.raises(SubjectRegistryError) as caught:
        registry.create_twin(human_payload(), idempotency_key=key)
    assert caught.value.code == "IDEMPOTENCY_CONFLICT"
    assert saved_bytes(registry, created["twin_id"]) == before


@pytest.mark.parametrize("case", ["conflict", "failed_qc", "unit", "future", "parameter_domain"])
def test_descriptive_admission_retains_clinical_rejection_before_insert(registry, monkeypatch, case):
    forbid_compilation(monkeypatch)
    body = human_payload()
    if case == "conflict":
        body["model_parameters"] = {"Gb": 120.0}
    elif case == "failed_qc":
        body["observations"]["glucose_mgdl"]["quality_status"] = "failed"
    elif case == "unit":
        body["observations"]["glucose_mgdl"]["unit"] = "kg"
    elif case == "future":
        body["observations"]["glucose_mgdl"]["captured_at"] = "2999-01-01T00:00:00Z"
    else:
        body["model_parameters"] = {"Si": 0.0}
    with pytest.raises(SubjectRegistryError):
        registry.create_twin(body)
    assert record_count(registry) == 0


def test_concurrent_identical_real_requests_share_authenticated_matcher(registry, monkeypatch):
    forbid_compilation(monkeypatch)
    body = human_payload()
    with ThreadPoolExecutor(max_workers=3) as executor:
        records = list(executor.map(lambda _: registry.create_twin(deepcopy(body), idempotency_key="same-key"), range(6)))
    assert len({record["twin_id"] for record in records}) == 1
    assert record_count(registry) == 1
    assert all(record["creation_identity"] == records[0]["creation_identity"] for record in records)


def test_new_retry_after_lifecycle_revision_keeps_record_bytes(registry, monkeypatch):
    forbid_compilation(monkeypatch)
    created = registry.create_twin(human_payload(), idempotency_key="new-key")
    revised = {**created, "version": 8, "lifecycle": "ACTIVE", "selection_mode": "observations_only"}
    replace_fixture_record(registry, revised)
    before = saved_bytes(registry, created["twin_id"])
    assert registry.create_twin(human_payload(), idempotency_key="new-key") == revised
    assert saved_bytes(registry, created["twin_id"]) == before


def test_observation_selection_is_explicit_atomic_and_model_free(registry, monkeypatch):
    for suffix in ("one", "two"):
        seed_legacy(registry, legacy_twin_record(suffix))
    forbid_compilation(monkeypatch)
    first = registry.select_observations("twin-fixture-one", expected_version=1)
    second = registry.select_observations("twin-fixture-two", expected_version=1)
    assert first["selection_mode"] == second["selection_mode"] == "observations_only"
    assert second["lifecycle"] == "ACTIVE" and second["version"] == 2
    assert registry.active_twin()["twin_id"] == second["twin_id"]
    prior = registry.get_twin(first["twin_id"])
    assert prior["lifecycle"] == "DATA_ADMITTED" and prior["version"] == 3


@pytest.mark.parametrize("version", [True, False, "1", 1.0, None, 0, -1, 2])
def test_observation_selection_rejects_coerced_or_stale_version_before_write(registry, version):
    old = legacy_twin_record()
    seed_legacy(registry, old)
    before = saved_bytes(registry, old["twin_id"])
    with pytest.raises(SubjectRegistryError):
        registry.select_observations(old["twin_id"], expected_version=version)
    assert saved_bytes(registry, old["twin_id"]) == before
    assert registry.active_twin() is None


def test_numerical_activation_of_unbound_person_leaves_prior_selection_unchanged(registry):
    old = legacy_twin_record()
    seed_legacy(registry, old)
    before = saved_bytes(registry, old["twin_id"])
    with pytest.raises(ValueError) as caught:
        registry.activate_twin(old["twin_id"], expected_version=1)
    assert getattr(caught.value, "code", None) == "MODEL_BINDING_REQUIRED"
    assert saved_bytes(registry, old["twin_id"]) == before
    assert registry.active_twin() is None


@pytest.mark.parametrize("advance_version", [True, False])
def test_prepared_observation_selection_revalidates_exact_record_before_commit(registry, advance_version):
    from livemorebio.aegle import subjects
    old = legacy_twin_record()
    seed_legacy(registry, old)
    prepared = subjects.prepare_observation_selection(old, expected_version=1)
    revised = {**old, "version": 2 if advance_version else 1, "conditions": ["Concurrent authored change"]}
    replace_fixture_record(registry, revised)
    before = saved_bytes(registry, old["twin_id"])
    with pytest.raises(SubjectRegistryError) as caught:
        registry.select_observations(old["twin_id"], expected_version=1, prepared=prepared)
    assert caught.value.code == "TWIN_VERSION_CONFLICT"
    assert saved_bytes(registry, old["twin_id"]) == before
    assert registry.active_twin() is None


def test_prepared_selection_is_trusted_type_not_client_dict(registry):
    seed_legacy(registry, legacy_twin_record())
    with pytest.raises(SubjectRegistryError):
        registry.select_observations("twin-fixture-one", expected_version=1,
                                     prepared={"record": {"twin_id": "twin-fixture-two", "lifecycle": "ACTIVE"}})
    assert registry.active_twin() is None


def test_preparation_itself_has_no_registry_or_numerical_side_effect(registry, monkeypatch):
    from livemorebio.aegle import subjects
    old = legacy_twin_record()
    seed_legacy(registry, old)
    before = saved_bytes(registry, old["twin_id"])
    forbid_compilation(monkeypatch)
    subjects.prepare_observation_selection(old, expected_version=1)
    assert saved_bytes(registry, old["twin_id"]) == before
    assert registry.active_twin() is None


def test_registry_sensitive_read_persists_begin_before_payload_decryption(registry, monkeypatch):
    from livemorebio.aegle import registry_audit
    seed_legacy(registry, legacy_twin_record())
    # A previous unrelated completed access must not satisfy this access's gate.
    registry.get_twin("twin-fixture-one")
    with sqlite3.connect(registry.path) as connection:
        before_sequence = connection.execute("SELECT COALESCE(MAX(sequence),0) FROM registry_audit").fetchone()[0]
    assert before_sequence >= 2
    original_open = registry._open
    original_begin = registry_audit.RegistryAudit.begin
    claims = []
    observed_begin = []

    def beginning(self, connection, **kwargs):
        claims.append(dict(kwargs))
        return original_begin(self, connection, **kwargs)

    def inspected(row):
        with sqlite3.connect(registry.path) as connection:
            events = connection.execute("SELECT event_id,nonce,ciphertext FROM registry_audit WHERE sequence>? ORDER BY sequence",
                                        (before_sequence,)).fetchall()
        assert len(claims) == 1
        claim = claims[0]
        assert claim["action"] == "inspect" and claim["opaque_record_id"] == row["record_id"]
        payloads = [json.loads(AESGCM(KEY).decrypt(bytes(nonce), bytes(ciphertext),
                    b"livemore.subject-registry.audit.v1\0" + event_id.encode("ascii")))
                    for event_id, nonce, ciphertext in events]
        exact = [payload for payload in payloads if payload["request_id"] == claim["request_id"]]
        assert len(exact) == 1, "This access must have a newly committed begin before decryption"
        assert exact[0]["schema"] == "livemore.subject-access-audit.v1"
        assert exact[0]["action"] == "inspect" and exact[0]["opaque_record_id"] == row["record_id"]
        assert exact[0]["completed_at"] is None
        observed_begin.append(claim["request_id"])
        return original_open(row)

    monkeypatch.setattr(registry_audit.RegistryAudit, "begin", beginning)
    monkeypatch.setattr(registry, "_open", inspected)
    assert registry.get_twin("twin-fixture-one")["twin_id"] == "twin-fixture-one"
    assert observed_begin


def test_audit_terminal_failure_cannot_return_sensitive_record(registry, monkeypatch):
    from livemorebio.aegle import registry_audit
    seed_legacy(registry, legacy_twin_record())

    def fail(*args, **kwargs):
        raise RuntimeError("authored terminal audit failure")

    monkeypatch.setattr(registry_audit.RegistryAudit, "finish", fail)
    with pytest.raises(RuntimeError, match="authored terminal"):
        registry.get_twin("twin-fixture-one")


def test_create_success_audit_failure_rolls_back_admitted_record(registry, monkeypatch):
    from livemorebio.aegle import registry_audit
    forbid_compilation(monkeypatch)

    def fail(*args, **kwargs):
        if kwargs.get("outcome_code") == "SUCCESS":
            raise RuntimeError("authored success audit failure")

    monkeypatch.setattr(registry_audit.RegistryAudit, "finish", fail)
    with pytest.raises(RuntimeError, match="authored success"):
        registry.create_twin(human_payload(), idempotency_key="rollback-key")
    assert record_count(registry) == 0


def test_selection_success_audit_failure_rolls_back_both_subjects(registry, monkeypatch):
    from livemorebio.aegle import registry_audit
    for suffix in ("one", "two"):
        seed_legacy(registry, legacy_twin_record(suffix))
    registry.select_observations("twin-fixture-one", expected_version=1)
    before = {twin_id: saved_bytes(registry, twin_id) for twin_id in ("twin-fixture-one", "twin-fixture-two")}
    original_finish = registry_audit.RegistryAudit.finish
    mutation_failures = []

    def fail(self, connection, reservation, *, outcome_code):
        if outcome_code == "SUCCESS":
            affected = [tuple(row) for row in connection.execute(
                "SELECT record_id,lifecycle,version FROM records WHERE record_id IN (?,?) ORDER BY record_id",
                ("twin-fixture-one", "twin-fixture-two"))]
            if affected == [("twin-fixture-one", "DATA_ADMITTED", 3), ("twin-fixture-two", "ACTIVE", 2)]:
                mutation_failures.append(True)
                raise RuntimeError("authored selection audit failure")
        return original_finish(self, connection, reservation, outcome_code=outcome_code)

    with monkeypatch.context() as patch:
        patch.setattr(registry_audit.RegistryAudit, "finish", fail)
        with pytest.raises(RuntimeError, match="authored selection"):
            registry.select_observations("twin-fixture-two", expected_version=1)
    assert mutation_failures == [True]
    assert {twin_id: saved_bytes(registry, twin_id) for twin_id in before} == before
    assert registry.active_twin()["twin_id"] == "twin-fixture-one"


def test_plaintext_request_hash_tamper_is_not_accepted_in_uniqueness_recovery(registry, monkeypatch):
    forbid_compilation(monkeypatch)
    first = registry.create_twin(human_payload(), idempotency_key="collision-key")
    with sqlite3.connect(registry.path) as connection:
        connection.execute("UPDATE records SET request_hash=? WHERE record_id=?", ("0" * 64, first["twin_id"]))
    # Exercise the existing race seam directly, not merely the first key lookup.
    with pytest.raises(SubjectRegistryError) as caught:
        registry._insert_or_existing("TWIN", first, "0" * 64, "collision-key")
    assert caught.value.code == "IDEMPOTENCY_CONFLICT"


def test_uncertain_selection_commit_is_distinct_from_rollback(registry, monkeypatch):
    """Commit completes in SQLite, then its acknowledgment and recovery access fail."""
    seed_legacy(registry, legacy_twin_record())
    outcome = {"committed": False, "arms": 0, "mutation_commits": 0, "recovery_reads": 0}

    class LostCommitAcknowledgment(sqlite3.Connection):
        selection_written = False

        def execute(self, sql, parameters=()):
            result = super().execute(sql, parameters)
            literal_pointer = "active_twin_id" in sql and ("INSERT" in sql.upper() or "UPDATE" in sql.upper())
            prepared_pointer = (
                sql == "INSERT INTO registry_state VALUES(?,?,?) ON CONFLICT(state_key) DO UPDATE SET state_value=excluded.state_value,updated_at=excluded.updated_at"
                and len(parameters) == 3 and parameters[0] == "active_twin_id"
            )
            if literal_pointer or prepared_pointer:
                self.selection_written = True
                outcome["arms"] += 1
            return result

        def commit(self):
            super().commit()
            if self.selection_written:
                outcome["committed"] = True
                outcome["mutation_commits"] += 1
                raise sqlite3.OperationalError("authored lost commit acknowledgment")

        def __exit__(self, exception_type, exception, traceback):
            if exception_type is None:
                self.commit()
            else:
                self.rollback()
            return False

    def connect():
        if outcome["committed"]:
            outcome["recovery_reads"] += 1
            raise sqlite3.OperationalError("authored unavailable reconciliation read")
        connection = sqlite3.connect(registry.path, factory=LostCommitAcknowledgment)
        connection.row_factory = sqlite3.Row
        return connection

    with monkeypatch.context() as patch:
        patch.setattr(registry, "_connect", connect)
        with pytest.raises(SubjectRegistryError) as caught:
            registry.select_observations("twin-fixture-one", expected_version=1)
        assert caught.value.code == "SELECTION_COMMIT_UNCONFIRMED"
    assert outcome["committed"] is True
    assert outcome["arms"] == outcome["mutation_commits"] == outcome["recovery_reads"] == 1
    # Read retained bytes, not a second mutation or an automatic retry.
    assert saved_bytes(registry, "twin-fixture-one")[0] == 2


def test_restart_preserves_legacy_ciphertext_and_is_not_an_inference_migration(registry, monkeypatch):
    old = legacy_twin_record(version=7)
    old.update(lifecycle="ACTIVE", selection_mode="observations_only")
    seed_legacy(registry, old, "old-key")
    with sqlite3.connect(registry.path) as connection:
        connection.execute("INSERT INTO registry_state(state_key,state_value,updated_at) VALUES('active_twin_id',?,?)",
                           (old["twin_id"], old["updated_at"]))
    before = saved_bytes(registry, old["twin_id"])
    forbid_compilation(monkeypatch)
    reopened = SubjectRegistry(registry.path, key=KEY)
    assert reopened.active_twin() == old
    assert saved_bytes(reopened, old["twin_id"]) == before


def test_wrong_key_is_not_model_unavailability_or_descriptive_fallback(registry):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError
    old = legacy_twin_record()
    seed_legacy(registry, old)
    before = saved_bytes(registry, old["twin_id"])
    with pytest.raises(RegistryBootstrapError) as caught:
        SubjectRegistry(registry.path, key=b"x" * 32).get_twin(old["twin_id"])
    assert caught.value.code == "REGISTRY_BOOTSTRAP_INVALID"
    assert saved_bytes(registry, old["twin_id"]) == before


def test_wrong_key_reopen_cannot_append_an_undecryptable_audit_begin(registry):
    from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError
    seed_legacy(registry, legacy_twin_record())
    with sqlite3.connect(registry.path) as connection:
        audit_before = connection.execute("SELECT * FROM registry_audit ORDER BY sequence").fetchall()
        reserved_before = connection.execute("SELECT * FROM registry_audit_reservations ORDER BY event_id").fetchall()
    before = saved_bytes(registry, "twin-fixture-one")
    with pytest.raises(RegistryBootstrapError) as caught:
        SubjectRegistry(registry.path, key=b"x" * 32)
    assert caught.value.code == "REGISTRY_BOOTSTRAP_INVALID"
    with sqlite3.connect(registry.path) as connection:
        assert connection.execute("SELECT * FROM registry_audit ORDER BY sequence").fetchall() == audit_before
        assert connection.execute("SELECT * FROM registry_audit_reservations ORDER BY event_id").fetchall() == reserved_before
    assert saved_bytes(registry, "twin-fixture-one") == before


def test_selection_audit_uses_the_server_response_request_identity(registry):
    from uuid import uuid4
    seed_legacy(registry, legacy_twin_record())
    request_id = str(uuid4())
    registry.select_observations("twin-fixture-one", expected_version=1, request_id=request_id)
    with sqlite3.connect(registry.path) as connection:
        rows = connection.execute("SELECT event_id,nonce,ciphertext FROM registry_audit ORDER BY sequence").fetchall()
    payloads = [json.loads(AESGCM(KEY).decrypt(nonce, ciphertext, b"livemore.subject-registry.audit.v1\0" + event_id.encode())) for event_id, nonce, ciphertext in rows]
    selected = [item for item in payloads if item["action"] == "select_observations"]
    assert len(selected) == 2 and all(item["request_id"] == request_id for item in selected)


@pytest.mark.parametrize("request_id", [True, [], "", "not-a-request", "a" * 32])
def test_selection_rejects_noncanonical_request_identity_before_store_access(registry, monkeypatch, request_id):
    monkeypatch.setattr(registry, "_connect", lambda: (_ for _ in ()).throw(AssertionError("no store access")))
    with pytest.raises(SubjectRegistryError) as caught:
        registry.select_observations("twin-fixture-one", expected_version=1, request_id=request_id)
    assert caught.value.code == "INVALID_REQUEST_ID"
