"""Corrupted local technical registry pointers cannot become a healthy preview.

No participant records, service startup, model constructors or solvers are used.
"""
from __future__ import annotations

from contextlib import closing
import sqlite3

import pytest

from livemorebio.aegle.subjects import SubjectRegistry
from livemorebio.tests.clinical_registry_fixtures import (
    CAPTURED, KEY, forbid_compilation, legacy_twin_record, seed_legacy,
)


@pytest.fixture
def selected_registry(tmp_path, monkeypatch):
    forbid_compilation(monkeypatch)
    registry = SubjectRegistry(tmp_path / "technical-selected.sqlite3", key=KEY)
    record = legacy_twin_record()
    record["lifecycle"] = "ACTIVE"
    seed_legacy(registry, record)
    with closing(registry._connect()) as connection, connection:
        connection.execute("INSERT INTO registry_state VALUES('active_twin_id',?,?)",
                           (record["twin_id"], CAPTURED))
    return registry, record


def records_and_pointer(registry):
    with sqlite3.connect(registry.path) as connection:
        return (
            connection.execute("SELECT * FROM records ORDER BY record_id").fetchall(),
            connection.execute("SELECT * FROM registry_state ORDER BY state_key").fetchall(),
        )


@pytest.mark.parametrize("read", ["active_twin", "audited_active_twin"])
@pytest.mark.parametrize("damage", [
    "missing_target", "non_twin_target", "inactive_index", "inactive_payload",
    "wrong_authenticated_id", "wrong_authenticated_version", "boolean_version",
    "source_class_mismatch", "wrong_schema", "not_an_object",
])
def test_corrupt_active_selection_is_operational_error_not_absence(selected_registry, read, damage):
    registry, record = selected_registry
    with closing(registry._connect()) as connection, connection:
        if damage == "missing_target":
            connection.execute("UPDATE registry_state SET state_value='twin-authored-missing' WHERE state_key='active_twin_id'")
        elif damage in {"non_twin_target", "inactive_index", "source_class_mismatch"}:
            column, value = {
                "non_twin_target": ("record_type", "COHORT"),
                "inactive_index": ("lifecycle", "DATA_ADMITTED"),
                "source_class_mismatch": ("source_class", "SYNTHETIC"),
            }[damage]
            connection.execute(f"UPDATE records SET {column}=? WHERE record_id=?", (value, record["twin_id"]))
        else:
            payload = dict(record)
            if damage == "inactive_payload":
                payload["lifecycle"] = "DATA_ADMITTED"
            elif damage == "wrong_authenticated_id":
                payload["twin_id"] = "twin-authored-substituted"
            elif damage == "wrong_authenticated_version":
                payload["version"] += 1
            elif damage == "boolean_version":
                payload["version"] = True
            elif damage == "wrong_schema":
                payload["schema"] = "livemore.cohort-record.v1"
            else:
                payload = ["authored malformed technical payload"]
            nonce, ciphertext = registry._seal(record["twin_id"], payload)
            connection.execute("UPDATE records SET nonce=?,ciphertext=? WHERE record_id=?",
                               (nonce, ciphertext, record["twin_id"]))
    before = records_and_pointer(registry)
    kwargs = {"action": "source_capture"} if read == "audited_active_twin" else {}
    with pytest.raises(RuntimeError, match="Active subject storage is inconsistent"):
        getattr(registry, read)(**kwargs)
    assert records_and_pointer(registry) == before
    with closing(registry._connect()) as connection:
        assert connection.execute("SELECT COUNT(*) FROM registry_audit_reservations").fetchone()[0] == 0


def test_absent_pointer_remains_none_without_compilation(selected_registry):
    registry, _ = selected_registry
    with closing(registry._connect()) as connection, connection:
        connection.execute("DELETE FROM registry_state WHERE state_key='active_twin_id'")
    assert registry.active_twin() is None
    assert registry.audited_active_twin(action="source_capture") is None


def test_coherent_active_legacy_record_is_unchanged(selected_registry):
    registry, record = selected_registry
    before = records_and_pointer(registry)
    assert registry.active_twin() == record
    assert registry.audited_active_twin(action="source_capture") == record
    assert records_and_pointer(registry) == before


def test_dangling_pointer_after_registry_reopen_does_not_become_absence(selected_registry):
    registry, _ = selected_registry
    with closing(registry._connect()) as connection, connection:
        connection.execute("UPDATE registry_state SET state_value='twin-authored-missing' WHERE state_key='active_twin_id'")
    reopened = SubjectRegistry(registry.path, key=KEY)
    with pytest.raises(RuntimeError, match="Active subject storage is inconsistent"):
        reopened.active_twin()
