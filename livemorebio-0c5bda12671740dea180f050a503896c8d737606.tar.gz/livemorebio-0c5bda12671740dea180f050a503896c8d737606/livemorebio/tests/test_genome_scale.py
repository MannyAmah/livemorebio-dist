"""Retired unverified model aliases cannot resurrect unqualified effects."""
import pytest
from livemorebio.engines import genome_scale as GS

@pytest.mark.parametrize("operation", [
    lambda: GS.load_human_gem(), lambda: GS.model_info(),
    lambda: GS.simulate(perturbations={"GAPDH": .05}), lambda: GS.check_energy_cycles(),
])
def test_legacy_genome_scale_paths_are_retired(operation, monkeypatch, tmp_path):
    stale = tmp_path / "Human-GEM.xml"
    stale.write_text("not a verified scientific asset", encoding="utf-8")
    monkeypatch.setattr(GS, "MODEL_PATH", str(stale))
    with pytest.raises(ValueError, match="retired"):
        operation()
