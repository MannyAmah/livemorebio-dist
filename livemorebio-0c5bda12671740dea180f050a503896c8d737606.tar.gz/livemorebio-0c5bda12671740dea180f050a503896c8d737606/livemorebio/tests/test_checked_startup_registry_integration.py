"""Real checked registry-to-startup wiring; authored records, no numerical work.

Only candidate construction/state and the two unrelated file-backed bus sinks
are replaced. Checked access, confirmation, encryption, audit and source guards
are the actual implementations. Never import the registry-only autouse fixture:
ASGI TestClient needs its internal socketpair, not network access.
"""
from contextlib import closing
from copy import deepcopy
import base64
import sqlite3
from types import SimpleNamespace
from uuid import UUID

import pytest

from livemorebio.tests.clinical_registry_fixtures import KEY, replace_fixture_record
from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401
from livemorebio.tests.test_committed_registry_transitions import events, rows, seed


def forbidden(*args, **kwargs):
    pytest.fail("Integration fixture attempted an unapproved model or execution-store operation")


def audit_rows(registry):
    with closing(sqlite3.connect(registry.path)) as connection:
        return connection.execute("SELECT * FROM registry_audit ORDER BY sequence").fetchall()


def reservations(registry):
    with closing(sqlite3.connect(registry.path)) as connection:
        return connection.execute("SELECT * FROM registry_audit_reservations ORDER BY event_id").fetchall()


@pytest.fixture
def integration(client, tmp_path, monkeypatch):
    from livemorebio import bus
    from livemorebio.aegle import execution_api, server
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.aegle.observation_state import ObservationState
    from livemorebio.aegle.registry_audit import RegistryAudit
    from livemorebio.aegle.subjects import SubjectRegistry

    path = tmp_path / "authored-checked-startup.sqlite3"
    monkeypatch.setenv("LIVEMORE_SUBJECT_REGISTRY", str(path))
    monkeypatch.setenv("LIVEMORE_PATCH_STORAGE_KEY", base64.urlsafe_b64encode(KEY).decode("ascii"))
    monkeypatch.setattr(server, "_subject_registry_instance", None)
    monkeypatch.setattr(server, "_subject_registry_path", None)
    registry = server._subject_registry()
    assert type(registry) is SubjectRegistry and registry.path == path and registry.key == KEY
    authority = ModelSourceAuthority(server._invalidate_model_source,
        fence=server._assign_model_fence, fence_guard=server._model_fence_guard)
    original_generation = authority.generation
    store = SimpleNamespace(**{name: forbidden for name in
        ("get", "create", "update", "acquire_owner", "release_owner")})
    manager = ExecutionManager(store, adapter_registry={}, run_background=False,
                               permitted_generation=original_generation)
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_execution_manager_instance", manager)
    initial = {"tw": None, "subject": None, "initialized": False,
               "observation_state": ObservationState()}
    old_actions = [object()]
    monkeypatch.setattr(server, "_state", initial)
    monkeypatch.setattr(server, "_workspace_actions", old_actions)
    t = SimpleNamespace(server=server, registry=registry, authority=authority, manager=manager,
        client=client, original_generation=original_generation, initial=initial,
        old_actions=old_actions, calls=[], published=[], baseline_audit=[], baseline_rows=None,
        expected_record=None, interfere=None, changed_rows=None)

    def unlocked(*, initialization_allowed=True):
        assert not authority._lock._is_owned()
        assert not execution_api._creation_lock._is_owned() and not manager._lock._is_owned()
        if not initialization_allowed:
            assert not server._initialization_lock._is_owned()

    def new_accesses():
        raw = audit_rows(registry)
        assert raw[:len(t.baseline_audit)] == t.baseline_audit
        identifiers = {row[0] for row in raw[len(t.baseline_audit):]}
        # Each actual access supplies its own durable request UUID. Do not infer
        # correlation from aggregate event count or reuse a fabricated capture.
        with closing(sqlite3.connect(registry.path)) as connection:
            request_ids = []
            for ident, nonce, encrypted in connection.execute("SELECT event_id,nonce,ciphertext FROM registry_audit ORDER BY sequence"):
                if ident in identifiers:
                    import json
                    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
                    value = json.loads(AESGCM(KEY).decrypt(nonce, encrypted,
                        b"livemore.subject-registry.audit.v1\0" + ident.encode("ascii")))
                    if value["request_id"] not in request_ids:
                        request_ids.append(value["request_id"])
        return [events(registry, request_id) for request_id in request_ids]

    def assert_accesses(outcomes):
        accesses = new_accesses()
        assert len(accesses) == len(outcomes)
        for index, (pair, outcome) in enumerate(zip(accesses, outcomes)):
            assert len(pair) == 2 and pair[0][0] != pair[1][0]
            assert [row[2]["outcome_code"] for row in pair] == [None, outcome]
            assert pair[0][2]["request_id"] == pair[1][2]["request_id"]
            UUID(pair[0][2]["request_id"])
            action = "inspect" if index == 0 else "reconcile_selection"
            assert [row[2]["action"] for row in pair] == [action, action]
            for row in pair:
                assert row[2]["schema"] == "livemore.subject-access-audit.v1"
                assert row[2]["local_store_id"] == registry.audit.store_id
                assert row[2]["opaque_record_id"] is None
                assert not {"display_label", "observations", "conditions", "model_parameters"} & row[2].keys()
        assert reservations(registry) == []

    def configure(kind):
        # True absence is absence of a selected record, not an empty database.
        seed(registry, "unrelated")
        if kind != "absent":
            t.expected_record = seed(registry, "selected", active=True, human=kind == "human")
        t.baseline_rows = rows(registry)
        t.baseline_audit = audit_rows(registry)
        assert reservations(registry) == []
        return deepcopy(t.expected_record)

    def candidate_state():
        if server._state.get("tw") is candidate:
            assert authority._lock._is_owned()
            assert not execution_api._creation_lock._is_owned() and not manager._lock._is_owned()
        else:
            unlocked()
            t.calls.append("state")
        return {"profile": "AUTHORED_INERT_CANDIDATE", "profile_params": {}}

    candidate = SimpleNamespace(state=candidate_state)

    def build(record):
        unlocked()
        assert record == t.expected_record and record is not t.expected_record
        assert record["source_class"] == "SYNTHETIC"
        assert_accesses(["SUCCESS"])
        t.calls.append("build")
        if t.interfere is not None:
            t.interfere()
            t.changed_rows = rows(registry)
        return candidate

    def healthy(*args, **kwargs):
        unlocked()
        assert args == ("healthy",) and not kwargs and t.expected_record is None
        assert_accesses(["SUCCESS"])
        t.calls.append("healthy")
        return candidate

    def set_snapshot(key, value):
        unlocked(initialization_allowed=False)
        assert key == "twin"
        assert_accesses(["SUCCESS", "SUCCESS"])
        assert server._state["initialized"] is True
        assert authority.generation == manager._permitted_generation != original_generation
        assert value["model_availability"]["source_generation"] == authority.generation
        t.published.append(("snapshot", key, deepcopy(value)))

    def publish(source, event, payload):
        unlocked(initialization_allowed=False)
        assert source == "Aegle" and event == server.events.TWIN_UPDATED
        t.published.append(("event", event, deepcopy(payload)))

    monkeypatch.setattr(registry, "build_twin", build)
    monkeypatch.setattr(server, "AegleTwin", healthy)
    monkeypatch.setattr(bus, "set_snapshot", set_snapshot)
    monkeypatch.setattr(bus, "publish", publish)
    t.configure, t.assert_accesses, t.candidate = configure, assert_accesses, candidate
    real_methods = {
        "audited_active_twin": SubjectRegistry.audited_active_twin,
        "confirm_active_selection": SubjectRegistry.confirm_active_selection,
        "_checked_selection_access": SubjectRegistry._checked_selection_access,
        "_selection_read_access": SubjectRegistry._selection_read_access,
        "_open": SubjectRegistry._open,
    }
    for name, function in real_methods.items():
        assert getattr(registry, name).__func__ is function
    assert registry.audit.begin.__func__ is RegistryAudit.begin
    assert registry.audit.finish.__func__ is RegistryAudit.finish
    snapshot_function = server._snapshot_twin
    yield t
    assert server._snapshot_twin is snapshot_function
    for name, function in real_methods.items():
        assert getattr(registry, name).__func__ is function
    assert registry.audit.begin.__func__ is RegistryAudit.begin
    assert registry.audit.finish.__func__ is RegistryAudit.finish
    manager.close()
    client.close()


def assert_confirmed(t, kind):
    assert t.authority.generation == t.manager._permitted_generation != t.original_generation
    assert t.server._state is not t.initial and t.server._state["initialized"] is True
    assert t.server._state["subject"] == (t.server._subject_summary(t.expected_record) if t.expected_record else None)
    assert t.server._state["tw"] is (None if kind == "human" else t.candidate)
    assert t.server._state["observation_state"] is not t.initial["observation_state"]
    assert t.server._state["observation_state"].observations == {}
    assert t.server._workspace_actions == [] and t.server._workspace_actions is not t.old_actions
    availability = t.server._state["model_availability"]
    assert availability["source_generation"] == t.authority.generation
    assert availability["state"] == ("UNAVAILABLE" if kind == "human" else "READY")
    if kind == "human":
        assert availability["reason_code"] == "MODEL_BINDING_REQUIRED"
        assert availability["selection_mode"] == "observations_only" and t.calls == []
    else:
        assert t.calls == ["healthy" if kind == "absent" else "build", "state"]
    assert rows(t.registry) == t.baseline_rows
    t.assert_accesses(["SUCCESS", "SUCCESS"])
    assert [row[0] for row in t.published] == ["snapshot", "event"]
    assert t.manager._wake.is_set() and not t.manager._closed
    assert t.manager._owners == t.manager._adapters == {}
    response = t.client.get("/api/state")
    assert response.status_code == 200
    assert response.json()["model_availability"] == availability
    assert response.json()["profile_params"] == (None if kind == "human" else {})
    previous = (audit_rows(t.registry), list(t.calls), deepcopy(t.published), t.server._state)
    t.server._ensure_selected_state()
    assert (audit_rows(t.registry), t.calls, t.published, t.server._state) == previous


def assert_denied(t, outcomes, expected_rows):
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.model_source import SourceSelectionUnconfirmed
    assert t.authority.permitted_generation is DENY_ALL and t.manager._permitted_generation is DENY_ALL
    assert t.server._state["initialized"] is True and t.server._state["tw"] is None
    assert t.published == [] and rows(t.registry) == expected_rows
    t.assert_accesses(outcomes)
    assert t.client.get("/").status_code == 200
    for path in ("/api/state", "/api/cendos/current-source"):
        result = t.client.get(path)
        assert result.status_code == 503 and result.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
        assert "AUTHORED" not in result.text
    result = t.client.post("/api/workspace/actions", json={})
    assert result.status_code == 503 and result.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
    with pytest.raises(SourceSelectionUnconfirmed):
        t.authority.capture(forbidden)
    before = (audit_rows(t.registry), list(t.calls), rows(t.registry))
    t.server._ensure_selected_state()
    assert (audit_rows(t.registry), t.calls, rows(t.registry)) == before


@pytest.mark.parametrize("kind", ["absent", "synthetic", "human"])
def test_real_checked_registry_is_confirmed_before_startup_publication(integration, kind):
    t = integration
    t.configure(kind)
    t.server._startup_publish()
    assert_confirmed(t, kind)


@pytest.mark.parametrize("change", ["same_version_payload", "pointer_timestamp"])
def test_real_confirmation_rejects_storage_change_during_unlocked_build(integration, change):
    t = integration
    record = t.configure("synthetic")

    def interfere():
        if change == "same_version_payload":
            altered = deepcopy(record)
            altered["display_label"] = "Authored independent edit at unchanged version"
            replace_fixture_record(t.registry, altered)
        else:
            with closing(t.registry._connect()) as connection, connection:
                connection.execute("UPDATE registry_state SET updated_at=? WHERE state_key='active_twin_id'",
                                   ("2026-09-01T00:00:00Z",))

    t.interfere = interfere
    t.server._startup_publish()
    assert t.changed_rows != t.baseline_rows
    assert t.calls == ["build", "state"]
    assert_denied(t, ["SUCCESS", "ACCESS_FAILED"], t.changed_rows)


def test_real_orphan_active_topology_is_not_absence_or_healthy_preview(integration):
    t = integration
    t.configure("synthetic")
    with closing(t.registry._connect()) as connection, connection:
        connection.execute("DELETE FROM registry_state WHERE state_key='active_twin_id'")
    corrupted = rows(t.registry)
    t.server._startup_publish()
    assert t.calls == []
    assert_denied(t, ["ACCESS_FAILED"], corrupted)


def test_real_audit_insert_rejection_prevents_startup_access_and_publication(integration):
    t = integration
    t.configure("synthetic")
    with closing(t.registry._connect()) as connection, connection:
        connection.execute("CREATE TRIGGER authored_deny_audit BEFORE INSERT ON registry_audit BEGIN SELECT RAISE(ABORT,'Authored audit failure'); END")
    t.server._startup_publish()
    assert t.calls == []
    assert_denied(t, [], t.baseline_rows)


def test_unauthorized_requests_do_not_start_real_registry_restore(integration):
    t = integration
    t.configure("synthetic")
    for path in ("/api/state", "/api/cendos/current-source"):
        assert t.client.get(path, headers={"Authorization": "Bearer invalid-authored-token"}).status_code == 401
    assert t.client.post("/api/workspace/actions", json={},
                        headers={"Authorization": "Bearer invalid-authored-token"}).status_code == 401
    assert t.client.get("/").status_code == 200
    assert t.server._state is t.initial and t.initial["initialized"] is False
    assert t.authority.generation == t.manager._permitted_generation == t.original_generation
    assert t.calls == t.published == [] and rows(t.registry) == t.baseline_rows
    assert audit_rows(t.registry) == t.baseline_audit and reservations(t.registry) == []


@pytest.mark.parametrize("kind", ["absent", "synthetic"])
def test_direct_initialized_restore_uses_actual_checked_registry(integration, kind):
    t = integration
    t.configure(kind)
    t.initial.update(initialized=True, tw=SimpleNamespace(state=forbidden))
    assert t.server._restore_active_subject() is (kind != "absent")
    assert_confirmed(t, kind)
