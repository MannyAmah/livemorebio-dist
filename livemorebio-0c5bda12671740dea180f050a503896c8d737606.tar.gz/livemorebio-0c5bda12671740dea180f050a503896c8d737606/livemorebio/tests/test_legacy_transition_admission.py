"""Strict legacy mutation boundaries; authored ASGI data, no model or registry."""
import json
from types import SimpleNamespace

import pytest

from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401


def body(action: str, version: object = 2) -> dict:
    payload = {"expected_version": version}
    if action == "patches":
        payload.update(device_id="technical-unregistered-device", mode="virtual",
                       protocol_version="3.0", firmware_version="virtual-execution-v1")
    return payload


@pytest.fixture
def boundary(client, monkeypatch):
    from livemorebio.aegle import server

    original = server._state
    generation = server._model_source_authority.generation
    calls = []

    def forbidden(*args, **kwargs):
        calls.append(True)
        raise AssertionError("INVALID_INPUT_REACHED_REGISTRY_OR_EXECUTION")

    monkeypatch.setattr(server, "_subject_registry", forbidden)
    monkeypatch.setattr(server, "AegleTwin", forbidden)
    monkeypatch.setattr(server, "_snapshot_twin", forbidden)
    monkeypatch.setattr(server, "_invalidate_model_source", forbidden)
    yield client, server, original, generation, calls


def reject(boundary, action: str, raw: bytes, *, authorized: bool = True) -> None:
    client, server, original, generation, calls = boundary
    headers = {"Content-Type": "application/json"}
    if not authorized:
        headers["Authorization"] = "Bearer deliberately-invalid-technical-token"
    result = client.post(f"/api/twins/twin-technical-unbound/{action}", content=raw, headers=headers)
    assert result.status_code in ({400, 422} if authorized else {401, 403})
    assert calls == []
    assert server._state is original
    assert server._model_source_authority.generation == generation


@pytest.mark.parametrize("action", ["activate", "patches"])
@pytest.mark.parametrize("version", [None, True, False, 2.0, "2", 0, -1,
                                     9_007_199_254_740_991, 9_007_199_254_740_992])
def test_invalid_version_rejected_before_any_storage_or_generation_change(boundary, action, version):
    reject(boundary, action, json.dumps(body(action, version)).encode())


@pytest.mark.parametrize("action", ["activate", "patches"])
@pytest.mark.parametrize("case", ["unknown", "duplicate", "missing", "array", "nonfinite", "utf8"])
def test_full_body_must_be_strict_before_any_registry_read(boundary, action, case):
    payload = body(action)
    if case == "unknown":
        payload["unexpected"] = "authored-only"
        raw = json.dumps(payload).encode()
    elif case == "duplicate":
        raw = (json.dumps(payload)[:-1] + ',"expected_version":2}').encode()
    elif case == "missing":
        del payload["expected_version"]
        raw = json.dumps(payload).encode()
    elif case == "array":
        raw = b"[]"
    elif case == "nonfinite":
        raw = b'{"expected_version":2,"unexpected":NaN}'
    else:
        raw = b'{"expected_version":2,"unexpected":"\xff"}'
    reject(boundary, action, raw)


@pytest.mark.parametrize("action", ["activate", "patches"])
def test_unauthorized_valid_shape_never_reaches_storage(boundary, action):
    reject(boundary, action, json.dumps(body(action)).encode(), authorized=False)


@pytest.mark.parametrize("action", ["activate", "patches"])
def test_confirmed_registry_precondition_failure_preserves_selected_generation(client, monkeypatch, action):
    from livemorebio.aegle import server
    from livemorebio.aegle.subjects import SubjectRegistryError

    original = server._state
    generation = server._model_source_authority.generation
    calls = []

    def conflict(*args, **kwargs):
        calls.append("rejected-before-write")
        raise SubjectRegistryError("TWIN_VERSION_CONFLICT", "Authored precondition conflict")

    def candidate(record):
        calls.append("authored-candidate-only")
        return SimpleNamespace(state=lambda: pytest.fail("Rejected candidate was published"))

    registry = SimpleNamespace(prepare_activation=conflict, prepare_patch_binding=conflict,
                               build_twin=candidate,
                               commit_prepared_transition=lambda *a, **k: pytest.fail("Rejected preparation reached commit"))
    monkeypatch.setattr(server, "_subject_registry", lambda: registry)
    monkeypatch.setattr(server, "_snapshot_twin", lambda *a: pytest.fail("Rejected source was published"))
    result = client.post(f"/api/twins/twin-technical-unbound/{action}", json=body(action))
    assert result.status_code == 409
    assert result.json()["code"] == "TWIN_VERSION_CONFLICT"
    assert calls == ["rejected-before-write"]
    assert server._state is original
    assert server._model_source_authority.generation == generation
