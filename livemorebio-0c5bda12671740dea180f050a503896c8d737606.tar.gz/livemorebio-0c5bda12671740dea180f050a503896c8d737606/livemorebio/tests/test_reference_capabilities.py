"""Reference inspection cannot borrow the active person's biological state."""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient


def test_reference_catalog_contains_no_person_or_computed_quantities(monkeypatch):
    from livemorebio.aegle import server
    from livemorebio.engines import biology

    class ForbiddenState(dict):
        def __getitem__(self, key):
            pytest.fail("reference endpoint accessed active subject")
        def get(self, *args):
            pytest.fail("reference endpoint accessed active subject")

    monkeypatch.setattr(server, "_state", ForbiddenState())
    monkeypatch.setattr(biology, "biology_state", lambda *a: pytest.fail("active biology called"))
    response = TestClient(server.app).get("/api/biology/reference")
    assert response.status_code == 200
    result = response.json()
    assert result["schema"] == "livemore.biology-reference.v1"
    assert result["reference_geometry"] is True
    assert result["evidence_state"] == "REFERENCE_ONLY"
    assert set(result) == {"schema", "reference_geometry", "evidence_state", "organs"}
    assert {organ["id"] for organ in result["organs"]} == set(biology.ORGAN_ATLAS)
    for organ in result["organs"]:
        assert organ["status"] == "reference"
        assert organ["evidence_state"] == "REFERENCE_ONLY"
        assert all(organ[key] is None for key in ("metric", "value", "ratio", "unit"))
        assert organ["cell"]["activity"] is None
        assert organ["cell"]["quantities"] == []
        assert organ["cell"]["evidence_state"] == "REFERENCE_ONLY"
        assert organ["anatomy"]["mesh_source"]


def test_reference_projection_does_not_share_mutable_catalog_state():
    from livemorebio.engines.biology import biology_reference

    first = biology_reference()
    first["organs"][0]["targets"].append("untrusted")
    assert "untrusted" not in biology_reference()["organs"][0]["targets"]


def test_capabilities_auth_and_supported_contexts(monkeypatch):
    from livemorebio.aegle import server
    from livemorebio.aegle.population import STRATA

    token = "reference-capabilities-test-token-only"
    monkeypatch.setenv("LIVEMORE_API_TOKEN", token)
    client = TestClient(server.app)
    assert client.get("/api/population-capabilities").status_code == 401
    response = client.get("/api/population-capabilities", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    data = response.json()
    assert data["schema"] == "livemore.population-capabilities.v1"
    assert data["default_template"] == "healthy"
    assert data["default_indication"] == "unspecified"
    assert {row["id"] for row in data["templates"] if row["available"]} == {"healthy", "type-2-diabetes"}
    assert {row["id"] for row in data["reference_strata"]} == STRATA
    by_id = {row["id"]: row for row in data["reference_strata"]}
    assert by_id["pxr-reference"]["indication"] == "hepatic-pxr-research"
    assert by_id["dpp-high-risk-metabolic"]["indication"] == "high-metabolic-risk"
    assert by_id["nhanes-diagnosed-diabetes-older"]["indication"] == "type-2-diabetes"
    assert data["healthy_reference_cohort"]["available"] is False
    assert data["healthy_reference_cohort"]["reason"]
    assert data["reference_source"]["role"] == "population_reference"


@pytest.mark.parametrize("base", ["type-1-diabetes", "unknown", "", None])
def test_unknown_template_never_silently_becomes_t2d(base, monkeypatch):
    from livemorebio.aegle.runtime import AegleTwin

    monkeypatch.setattr(AegleTwin, "_recompute", lambda *a: pytest.fail("unsupported profile executed"))
    with pytest.raises(ValueError, match="Unsupported twin template"):
        AegleTwin(base)
