"""Large frozen cohorts need bounded selectors without selecting a different person."""
from __future__ import annotations

import json
from pathlib import Path
import subprocess

import pytest
from ._node import require_node, run_node as _run_node


def check(program: str) -> None:
    node = require_node()
    module = Path(__file__).parents[1] / "aegle/console/lib/member_picker.js"
    result = _run_node([node, "--input-type=module", "--eval",
        f"import {{memberPage}} from {json.dumps(module.as_uri())};" + program],
        capture_output=True, text=True, timeout=15, encoding="utf-8")
    assert result.returncode == 0, result.stderr


@pytest.mark.parametrize("count", [1, 100, 10000])
def test_member_page_caps_visible_rows_and_preserves_full_identity(count):
    check(f"""const rows=Array.from({{length:{count}}},(_,i)=>({{member_id:'technical-long-member-'+i,cohort_id:i%2?'b':'a',cohort_name:'Technical cohort'}}));
const before=JSON.stringify(rows);const p=memberPage(rows,{{page:0,size:50}});
if(p.rows.length!==Math.min(50,{count})||p.total!=={count})throw Error('unbounded rows');
if(p.rows[0].member.member_id!==rows[0].member_id)throw Error('identity changed');
if(JSON.stringify(rows)!==before)throw Error('input mutated');""")


def test_search_cohort_filter_empty_and_last_page():
    check("""const rows=Array.from({length:101},(_,i)=>({member_id:'member-'+String(i).padStart(3,'0'),cohort_id:i%2?'b':'a',cohort_name:'Cohort '+(i%2?'B':'A')}));
const last=memberPage(rows,{page:2,size:50});if(last.rows.length!==1||last.hasNext||!last.hasPrevious)throw Error('wrong last page');
const filtered=memberPage(rows,{query:'member-09',cohortId:'a',size:25});if(filtered.total!==5)throw Error('wrong search');
const empty=memberPage(rows,{query:'absent'});if(empty.total!==0||empty.rows.length)throw Error('wrong empty state');
const invalid=()=>memberPage([...rows,rows[0]],{});let rejected=false;try{invalid()}catch{rejected=true}if(!rejected)throw Error('ambiguous identity');""")


def test_page_query_does_not_change_selected_member():
    check("""const rows=Array.from({length:100},(_,i)=>({member_id:'member-'+i,cohort_id:'a',cohort_name:'A'}));
const p=memberPage(rows,{page:3,size:25,selectedId:'member-0'});
if(p.selected.member_id!=='member-0'||p.rows.some(row=>row.member.member_id==='member-0'))throw Error('selection drift');
if(p.selectedIndex!==0)throw Error('wrong selected ordinal');""")
