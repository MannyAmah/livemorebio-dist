"""Authored DOM/runner evidence only; no browser, service or scientific work."""
import json

import pytest

from .test_legacy_preview_browser_harness import harness, js, mounted, _authored_browser_receipt


DOM = r"""
const vm=require('node:vm');
const state={kind:'info',text:'Model unavailable. No previous subject physiology is shown.',hidden:false,
  nav:{x:0,y:0,width:390,height:64},box:{x:0,y:180,width:390,height:80},occluded:false,duplicate:false,
  viewport:{width:390,height:844},focus:false,position:'static',wrap:'anywhere'};
const makeRect=x=>({...x,right:x.x+x.width,bottom:x.y+x.height});
const link={getBoundingClientRect:()=>makeRect({x:10,y:10,width:80,height:40}),contains:el=>el===link};
const offscreen={getBoundingClientRect:()=>makeRect({x:420,y:10,width:80,height:40}),contains:el=>el===offscreen};
const nav={getBoundingClientRect:()=>makeRect(state.nav),querySelectorAll:()=>[link,offscreen],contains:el=>[nav,link,offscreen].includes(el)};
const button={disabled:false};
const banner={get hidden(){return state.hidden},get textContent(){return state.text},
  get dataset(){return{kind:state.kind}},getBoundingClientRect:()=>makeRect(state.hidden?{x:0,y:0,width:0,height:0}:state.box),
  getAttribute:key=>({'role':state.kind==='err'?'alert':'status','aria-live':state.kind==='err'?'assertive':'polite','aria-atomic':'true'}[key])};
const document={get activeElement(){return state.focus?button:null},documentElement:{scrollWidth:390},
 querySelector:s=>s==='.lmb-nav'?nav:s==='#legacy-run-experiment'?button:s==='#__banner'?(state.duplicate?{}:banner):null,
 querySelectorAll:s=>s==='#__banner'?(state.duplicate?[banner,{}]:[banner]):[],
 elementFromPoint:(x,y)=>state.occluded||state.bannerOccluded&&y>=64?{}:y<64?link:banner};
const context={document,innerWidth:390,innerHeight:844,scrollX:0,scrollY:0,
 getComputedStyle:el=>({position:state.position,overflowWrap:state.wrap,display:state.hidden?'none':'block'}),banner};
function snapshot(kind){return vm.runInNewContext('('+h.readBannerSnapshot.toString()+')(banner,'+JSON.stringify(kind)+')',context)}
"""


def test_exact_two_additive_image_slots_and_unchanged_nonimage_bounds():
    h = harness()
    assert tuple(x for x in h.IMAGES if not x.endswith('-cardiac')) == ('desktop-modeless', 'desktop-error', 'desktop-pending', 'desktop-later-winner',
        'desktop-cleanup', 'desktop-note-before', 'desktop-unknown', 'desktop-twins-recovery',
        'desktop-life-inspection', 'desktop-history', 'mobile-error', 'mobile-note-before',
        'mobile-unknown', 'mobile-refreshed')
    assert h.LIMITS == dict(startup_s=45,browser_s=180,action_s=10,held_s=2,total_s=350,
                          requests=256,posts=4,images=16,evidence_bytes=64*1024*1024)
    js('a.deepEqual(h.IMAGES,'+json.dumps(list(h.IMAGES))+');')


def test_actual_serialized_reader_omits_raw_text_and_does_not_claim_offscreen_link_hit():
    js(DOM+r"""
const value=snapshot('info');h.requireBannerSnapshot(value,'info');
a.equal(value.links.length,2);a.equal(value.links[0].visible,true);a.equal(value.links[0].hit,true);
a.equal(value.links[1].visible,false);a.equal(value.links[1].hit,null);
a(!JSON.stringify(value).includes('Model unavailable'));a.equal(value.singleton,true);a.equal(value.same_node,true);
state.kind='err';state.text='enter a compound in the search box';state.focus=true;
h.requireBannerSnapshot(snapshot('err'),'err');state.text='';state.hidden=true;
h.requireBannerSnapshot(snapshot('hidden'),'hidden');
""")


@pytest.mark.parametrize('damage', ['state.box.y=40', 'state.box.height=900', 'state.box.x=-1',
    'state.occluded=true', 'state.duplicate=true', "state.position='fixed'", "state.wrap='normal'",
    "state.text='PRIVATE unexpected text'", 'document.documentElement.scrollWidth=600',
    'state.nav.y=-2', 'state.box.width=NaN', 'state.bannerOccluded=true'])
def test_actual_snapshot_rejects_overlap_clipping_stale_identity_and_incoherence(damage):
    js(DOM+"h.requireBannerSnapshot(snapshot('info'),'info');"+damage+
       ";a.throws(()=>h.requireBannerSnapshot(snapshot('info'),'info'),e=>e.message==='BANNER_LAYOUT_FAILED');")


def test_mounted_runner_retains_all_five_banner_rows_and_same_four_posts():
    mounted('normal', """
a.equal(status,0);a.equal(postCount,4);a.equal(finalReceipt.images.length,16);
a.deepEqual(finalReceipt.banner_checks.map(x=>x.id),['desktop-info','desktop-error','desktop-cleared','mobile-error','mobile-info']);
for(const row of finalReceipt.banner_checks)a.equal(row.snapshot.same_node,true);
for(const row of finalReceipt.banner_checks.filter(x=>x.kind==='err')){
 a.equal(row.precondition,true);a.equal(row.ready_hidden,true);a.equal(row.focus_retained,true);
 a.equal(row.posts_before,row.posts_after);a.equal(row.request_posts_before,row.request_posts_after);}
a.equal(calls.filter(x=>x==='banner-enter').length,2);a.equal(finalReceipt.actual_mutations,0);
""")


@pytest.mark.parametrize('mode,expected,posts', [('banner_overlap','BANNER_LAYOUT_FAILED',0),
    ('banner_focus','BANNER_VALIDATION_FAILED',0),('banner_wrong_input','BANNER_VALIDATION_FAILED',0),
    ('banner_post','UNEXPECTED_POST',0),('banner_replaced','BANNER_LAYOUT_FAILED',1)])
def test_mounted_failure_keeps_metadata_and_stops_without_hiding_original_failure(mode,expected,posts):
    mounted(mode,"a.equal(status,1);a.equal(finalReceipt.primary_failure,"+json.dumps(expected)+
        ");a(finalReceipt.banner_checks.length>0);a(finalReceipt.cases.some(x=>x.status==='NOT_RUN'));"+
        f"a.equal(finalReceipt.posts,{posts});"+
        "a(calls.includes('page-close')&&calls.includes('context-close')&&calls.includes('browser-close'));"+
        "a(!JSON.stringify(finalReceipt).includes('PRIVATE'));")


@pytest.mark.parametrize('damage', ['missing','identity','focus','post','count'])
def test_parent_requires_complete_banner_proof_not_only_fourteen_images(tmp_path,damage):
    h=harness();record=_authored_browser_receipt(h,tmp_path)
    assert len(record['images'])==16
    assert len(record['banner_checks'])==5
    if damage=='missing':record.pop('banner_checks')
    elif damage=='identity':record['banner_checks'][0]['snapshot']['same_node']=False
    elif damage=='focus':record['banner_checks'][1]['focus_retained']=False
    elif damage=='post':record['banner_checks'][1]['posts_after']=1
    else:record['banner_checks'].append(record['banner_checks'][0])
    file=tmp_path/'browser-result.json';file.write_text(json.dumps(record), encoding="utf-8");file.chmod(0o600)
    with pytest.raises(h.HarnessError):
        h.admit_browser_result(tmp_path,source='a'*64,pins={'browser':'b'*64},services={},exit_code=0)
