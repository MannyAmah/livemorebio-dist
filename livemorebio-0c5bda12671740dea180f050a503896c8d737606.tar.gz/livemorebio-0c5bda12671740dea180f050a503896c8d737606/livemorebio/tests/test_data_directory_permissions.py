"""The data directory holds the API token and both patch keys, so whichever
code path creates it first must still make it owner-only."""
from __future__ import annotations

import os
import stat

import pytest


@pytest.mark.parametrize("first_touch", ["registry.register", "cli.start_path", "security.keys"])
def test_data_directory_is_owner_only_whichever_path_creates_it(tmp_path, monkeypatch, first_touch):
    data_dir = tmp_path / "livemore-data"
    monkeypatch.setenv("LIVEMORE_DATA_DIR", str(data_dir))
    from livemorebio import registry
    # Patch the path globals instead of reloading the module: a reload makes new
    # exception classes, which later tests' `except` clauses would no longer match.
    monkeypatch.setattr(registry, "REG_DIR", str(data_dir))
    monkeypatch.setattr(registry, "REG", str(data_dir / "registry.json"))

    if first_touch == "registry.register":
        registry.register("Aegle", 8850, 1234)
    elif first_touch == "cli.start_path":
        registry.ensure_data_dir()
    else:
        registry.ensure_data_dir()

    assert data_dir.is_dir()
    mode = stat.S_IMODE(os.stat(data_dir).st_mode)
    assert mode & 0o077 == 0, f"{first_touch} created the data dir as {oct(mode)}"


def test_an_existing_group_readable_data_directory_is_tightened(tmp_path, monkeypatch):
    """A directory created wrongly by an older build must be corrected, not kept."""
    data_dir = tmp_path / "livemore-data"
    data_dir.mkdir(mode=0o755)
    data_dir.chmod(0o755)
    monkeypatch.setenv("LIVEMORE_DATA_DIR", str(data_dir))
    from livemorebio import registry
    monkeypatch.setattr(registry, "REG_DIR", str(data_dir))

    registry.ensure_data_dir()

    assert stat.S_IMODE(os.stat(data_dir).st_mode) & 0o077 == 0


def test_any_command_tightens_a_data_directory_left_loose_by_an_older_build(tmp_path, monkeypatch, capsys):
    """Creation is fixed, but a directory already on disk stays exposed until
    something corrects it. Observed on a client install as doctor's
    'data dir ... mode 0o755' warning."""
    import sys

    from livemorebio import cli, registry

    data_dir = tmp_path / "livemore-data"
    data_dir.mkdir(mode=0o755)
    data_dir.chmod(0o755)
    monkeypatch.setattr(registry, "REG_DIR", str(data_dir))
    monkeypatch.setattr(cli.R, "REG_DIR", str(data_dir))
    monkeypatch.setattr(sys, "argv", ["livemore", "status"])

    try:
        cli.main()
    except SystemExit:
        pass

    assert stat.S_IMODE(os.stat(data_dir).st_mode) & 0o077 == 0
