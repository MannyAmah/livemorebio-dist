"""Missing preview publication contracts; no actual extractor, model or store."""
from contextlib import contextmanager
from copy import deepcopy
from types import SimpleNamespace
from uuid import UUID
import weakref

import pytest

from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401
from livemorebio.tests.test_closed_manager_source_publication import NoIOStore, OWNER_ID
from livemorebio.tests.test_committed_preview_transitions import request_preview


# L0-R15: the note route refuses before the preview protocol starts, so the protocol's
# cases use the technical routes; test_note_is_refused_before_the_preview_protocol holds it.
KINDS = ("base", "life_system")
REQUEST_ID = UUID("11111111-2222-4333-8444-555555555555")


@pytest.fixture
def preview_boundary(client, monkeypatch):
    from livemorebio import bus
    from livemorebio.aegle import execution_api, server
    from livemorebio.aegle.execution import DENY_ALL, ExecutionManager
    from livemorebio.aegle.model_contexts import model_availability
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.aegle.subjects import SubjectRegistryError
    from livemorebio.life_system import extract, population, synthetic_human

    t = SimpleNamespace(server=server, client=client, calls=[], factory_calls=[], snapshots=[],
        retired=[], candidate_refs=[], store_calls=[], outcome="COMMITTED", shape="valid",
        before_final=None, during_factory=None, after_cleanup=None, mismatch=None,
        active_override="normal", extracted={"data_class": "AUTHORED_TEST_ONLY"})
    active_guard, committed_guard = [None], [None]

    def locks():
        return (authority._lock._is_owned(), execution_api._creation_lock._is_owned(),
                manager._lock._is_owned(), server._initialization_lock._is_owned())

    def unlocked():
        assert locks() == (False, False, False, False)

    def assert_publication():
        if t.outcome == "uncertain":
            assert authority.permitted_generation is manager._permitted_generation is DENY_ALL
            assert server._state is initial and server._workspace_actions is actions
            assert initial["tw"] is original["tw"] and initial["subject"] == original["subject"]
            assert initial["observation_state"] is observed
            assert initial["model_availability"] == original["availability"]
            return
        assert authority.generation == manager._permitted_generation != generation
        assert server._state is not initial and server._state["subject"] is None
        assert server._state["tw"] is t.candidate_refs[-1]()
        assert server._state["initialized"] is True
        assert server._state["model_availability"] == model_availability(None, source_generation=authority.generation)
        assert server._state["observation_state"] is not observed
        assert server._state["observation_state"].observations == {}
        assert server._workspace_actions == [] and server._workspace_actions is not actions

    @contextmanager
    def fence_guard():
        with server._model_fence_guard():
            owner, previous = object(), active_guard[0]
            active_guard[0] = owner
            try:
                yield
            finally:
                try:
                    if committed_guard[0] is owner:
                        assert locks() == (True, True, True, False)
                        assert_publication()
                        t.calls.append("guard-exit")
                finally:
                    active_guard[0] = previous

    authority = ModelSourceAuthority(server._invalidate_model_source,
        fence=server._assign_model_fence, fence_guard=fence_guard)
    generation = authority.generation
    store = NoIOStore(t.store_calls)
    manager = ExecutionManager(store, adapter_registry={}, run_background=False,
                               permitted_generation=generation)
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_execution_manager_instance", manager)
    monkeypatch.setattr(server, "uuid4", lambda: REQUEST_ID)
    initial = server._state
    initial["subject"].update(source_class="SYNTHETIC", selection_mode="model")
    initial["tw"] = SimpleNamespace(state=lambda: pytest.fail("Preview read the old model"))
    initial["model_availability"] = model_availability(initial["subject"], source_generation=generation)
    observed = initial["observation_state"]
    observed.observations["old-person-marker"] = {"data_class": "AUTHORED_TEST_ONLY"}
    actions = [{"kind": "AUTHORED_OLD_ACTION"}]
    monkeypatch.setattr(server, "_workspace_actions", actions)
    original = {}

    def freeze_original():
        original.update(tw=initial["tw"], subject=deepcopy(initial["subject"]),
                        availability=deepcopy(initial["model_availability"]))

    def assert_original():
        assert server._state is initial and server._workspace_actions is actions
        assert initial["tw"] is original["tw"] and initial["subject"] == original["subject"]
        assert initial["observation_state"] is observed
        assert initial["model_availability"] == original["availability"]
        assert actions == [{"kind": "AUTHORED_OLD_ACTION"}]

    class Registry:
        def prepare_preview_clear(self, *, request_id):
            assert locks() == (True, False, False, False)
            assert request_id == str(REQUEST_ID)
            t.calls.append("prepare")
            t.prepared_request_id = request_id
            if t.outcome == "prepare_failure":
                raise SubjectRegistryError("TWIN_VERSION_CONFLICT", "Authored prepare rejection")
            if t.outcome == "prepare_rollback_unconfirmed":
                from livemorebio.aegle.subjects import _transition_error

                raise _transition_error("SELECTION_COMMIT_UNCONFIRMED")
            active = deepcopy(original["subject"])
            if t.active_override != "normal":
                active = deepcopy(t.active_override)
            if t.mismatch:
                active[t.mismatch] = 13 if t.mismatch == "version" else "authored-different"
            t.prepared = SimpleNamespace(kind="clear_for_preview", record=None, target_before=None,
                active_before=active, active_after=None, selected=False, request_id=request_id)
            return t.prepared

        def commit_prepared_transition(self, prepared):
            assert locks() == (True, True, True, False)
            assert prepared is t.prepared and authority.generation == generation
            assert_original()
            t.calls.append("commit")
            if t.outcome == "rollback":
                raise SubjectRegistryError("TWIN_VERSION_CONFLICT", "Authored rollback")
            committed_guard[0] = active_guard[0]
            assert committed_guard[0] is not None
            if t.outcome == "uncertain":
                raise SubjectRegistryError("SELECTION_COMMIT_UNCONFIRMED", "Authored uncertainty")
            return "COMMITTED"

    registry = Registry()

    def getter():
        unlocked()
        t.calls.append("getter")
        return registry

    monkeypatch.setattr(server, "_subject_registry", getter)
    real_guard = authority.commit_guard

    @contextmanager
    def commit_guard():
        hook, t.before_final = t.before_final, None
        if hook:
            unlocked()
            hook()
        with real_guard():
            yield

    monkeypatch.setattr(authority, "commit_guard", commit_guard)
    real_invalidate = manager.invalidate_source

    def invalidate(old_generation, reason):
        unlocked()
        assert old_generation == generation
        assert_publication()
        t.calls.append("invalidate")
        result = real_invalidate(old_generation, reason)
        hook, t.after_cleanup = t.after_cleanup, None
        if hook:
            hook()
        return result

    monkeypatch.setattr(manager, "invalidate_source", invalidate)
    human = object()

    def factory_phase(name, args=(), kwargs=None):
        unlocked()
        assert "prepare" in t.calls and "commit" not in t.calls
        t.factory_calls.append((name, args, kwargs or {}))

    class Candidate:
        def __init__(self):
            weakref.finalize(self, lambda: t.retired.append(("candidate", *locks())))

        def state(self):
            unlocked()
            t.calls.append("state")
            if t.shape == "none":
                return None
            if t.shape == "list":
                return []
            value = {"profile": "AUTHORED_PREVIEW", "profile_params": {"technical": "candidate"},
                     "observations": {}, "applied": []}
            if t.shape == "missing":
                value.pop("profile_params")
            elif t.shape == "null":
                value["profile_params"] = None
            elif t.shape == "params-list":
                value["profile_params"] = []
            elif t.shape == "nonfinite":
                value["technical_nonfinite"] = float("nan")
            return value

    def candidate(*args, **kwargs):
        factory_phase("candidate", args, kwargs)
        hook, t.during_factory = t.during_factory, None
        if hook:
            hook()
        value = Candidate()
        t.candidate_refs.append(weakref.ref(value))
        return value

    def synthetic(*args, **kwargs):
        factory_phase("synthetic", args, kwargs)
        return human

    class LifeSystem:
        def __init__(self):
            factory_phase("life-system")

        def generate(self, *args, **kwargs):
            factory_phase("generate", args, kwargs)
            return [human]

    class Extractor:
        def __init__(self):
            factory_phase("extractor")

        def to_synthetic_human(self, note, *, hid):
            factory_phase("extract", (note,), {"hid": hid})
            assert note == "AUTHORED TECHNICAL PREVIEW; NOT A CLINICAL NOTE" and hid == "LMB-NOTE"
            return human, deepcopy(t.extracted)

    monkeypatch.setattr(server, "AegleTwin", candidate)
    monkeypatch.setattr(population, "LifeSystem", LifeSystem)
    monkeypatch.setattr(synthetic_human, "SyntheticHuman", synthetic)
    monkeypatch.setattr(extract, "ClinicalExtractor", Extractor)
    real_response = server.JSONResponse

    class ObservedResponse(real_response):
        def render(self, content):
            if isinstance(content, dict) and content.get("profile") == "AUTHORED_PREVIEW":
                unlocked()
                assert "commit" not in t.calls
                t.calls.append("serialize")
            return super().render(content)

    monkeypatch.setattr(server, "JSONResponse", ObservedResponse)

    def record_snapshot(name, value):
        unlocked()
        assert name == "twin" and "guard-exit" in t.calls
        t.snapshots.append(deepcopy(value))
        t.calls.append("snapshot")

    monkeypatch.setattr(bus, "set_snapshot", record_snapshot)
    monkeypatch.setattr(bus, "publish", lambda *a, **k: unlocked())
    freeze_original()
    t.authority, t.manager, t.generation, t.store = authority, manager, generation, store
    t.initial, t.original, t.observed, t.actions, t.human = initial, original, observed, actions, human
    t.unlocked, t.locks, t.assert_original, t.freeze_original = unlocked, locks, assert_original, freeze_original
    t.real_guard = real_guard
    yield t
    assert manager._adapters == {}
    client.close()


def context(t, response):
    assert response.headers["X-Request-ID"] == str(REQUEST_ID)
    assert "no-store" in response.headers["Cache-Control"]
    if "prepare" in t.calls:
        assert t.prepared_request_id == response.headers["X-Request-ID"]


def assert_precommit_rejection(t, response, status=503, code="REGISTRY_STORAGE_UNAVAILABLE"):
    assert response.status_code == status and response.json()["code"] == code
    context(t, response)
    assert "commit" not in t.calls and "invalidate" not in t.calls and not t.snapshots
    assert "AUTHORED" not in response.text


@pytest.mark.parametrize("kind", KINDS)
def test_preview_preparation_rollback_uncertainty_preserves_selected_source(preview_boundary, kind):
    t = preview_boundary
    t.outcome = "prepare_rollback_unconfirmed"
    response = request_preview(t, kind)
    assert_precommit_rejection(t, response, code="SELECTION_COMMIT_UNCONFIRMED")
    assert t.calls == ["getter", "prepare"] and not t.factory_calls
    t.assert_original()
    assert t.authority.generation == t.authority.permitted_generation == t.generation
    assert t.manager._permitted_generation == t.generation


@pytest.mark.parametrize("kind", KINDS)
@pytest.mark.parametrize("shape", ["null", "nonfinite"])
def test_preview_rejects_null_parameters_and_nonfinite_success_before_commit(preview_boundary, kind, shape):
    t = preview_boundary
    t.shape = shape
    assert_precommit_rejection(t, request_preview(t, kind))
    t.assert_original()
    assert t.authority.generation == t.generation


@pytest.mark.parametrize("kind,shape", [("base", "none"), ("life_system", "list"),
                                       ("life_system", "missing"), ("base", "params-list")])
def test_preview_rejects_malformed_own_state_before_commit(preview_boundary, kind, shape):
    t = preview_boundary
    t.shape = shape
    assert_precommit_rejection(t, request_preview(t, kind))
    t.assert_original()


def test_note_is_refused_before_the_preview_protocol(preview_boundary):
    # L0-R15 restates the note-metadata case: a note never reaches the protocol, so no
    # extracted metadata exists to clear or keep the subject.
    t = preview_boundary
    t.extracted = {"authored": float("nan")}
    response = request_preview(t, "note")
    assert response.status_code == 422 and response.json()["code"] == "CLINICAL_NOTE_NOT_ACCEPTED"
    assert "no-store" in response.headers["Cache-Control"]
    assert t.calls == [] and not t.factory_calls and not t.snapshots
    t.assert_original()


@pytest.mark.parametrize("kind", KINDS)
def test_preparation_rejection_precedes_all_preview_factories(preview_boundary, kind):
    t = preview_boundary
    t.outcome = "prepare_failure"
    assert_precommit_rejection(t, request_preview(t, kind), 409, "TWIN_VERSION_CONFLICT")
    assert not t.factory_calls
    t.assert_original()


@pytest.mark.parametrize("kind", KINDS)
def test_capture_deny_all_keeps_the_operation_uuid_without_factory(preview_boundary, kind):
    from livemorebio.aegle.execution import DENY_ALL
    t = preview_boundary
    with t.real_guard():
        t.authority.install_generation(DENY_ALL)
    assert_precommit_rejection(t, request_preview(t, kind), 503, "SELECTION_COMMIT_UNCONFIRMED")
    assert "prepare" not in t.calls and not t.factory_calls
    t.assert_original()
    assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL


@pytest.mark.parametrize("phase,field,kind", [
    (phase, field, KINDS[(index + (phase == "final")) % len(KINDS)])
    for phase in ("capture", "final")
    for index, field in enumerate(("twin_id", "subject_id", "source_class", "version"))])
def test_capture_and_final_identity_conflicts_keep_the_same_uuid(preview_boundary, phase, field, kind):
    t = preview_boundary
    if phase == "capture":
        t.mismatch = field
    else:
        def change():
            with t.authority.observation():
                t.initial["subject"][field] = 15 if field == "version" else "authored-later"
        t.before_final = change
    assert_precommit_rejection(t, request_preview(t, kind), 409, "MODEL_SOURCE_CHANGED")
    assert t.authority.generation == t.manager._permitted_generation == t.generation
    if phase == "capture":
        assert not t.factory_calls


@pytest.mark.parametrize("kind", KINDS)
def test_late_generation_conflict_retains_preparation_request_uuid(preview_boundary, kind):
    t = preview_boundary
    def change():
        with t.real_guard():
            t.authority.install_generation("authored-later-preview-generation")
    t.during_factory = change
    assert_precommit_rejection(t, request_preview(t, kind), 409, "MODEL_SOURCE_CHANGED")
    assert t.authority.generation == t.manager._permitted_generation == "authored-later-preview-generation"
    t.assert_original()


def modeless(t):
    t.initial["tw"] = None
    t.initial["model_availability"].update(state="UNAVAILABLE", reason_code="MODEL_BINDING_REQUIRED",
        selection_mode="observations_only", preparation_available=False)
    t.freeze_original()


@pytest.mark.parametrize("kind", KINDS)
@pytest.mark.parametrize("old_modeless", [False, True])
def test_unknown_preview_retains_exact_old_inspection_holders(preview_boundary, kind, old_modeless):
    from livemorebio.aegle.execution import DENY_ALL
    t = preview_boundary
    if old_modeless:
        modeless(t)
    t.outcome = "uncertain"
    response = request_preview(t, kind)
    assert response.status_code == 503 and response.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
    context(t, response)
    t.assert_original()
    assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL
    assert t.calls.count("commit") == t.calls.count("invalidate") == 1 and not t.snapshots


def test_modeless_source_can_become_confirmed_explicit_preview(preview_boundary):
    t = preview_boundary
    modeless(t)
    response = request_preview(t, "life_system")
    assert response.status_code == 200
    context(t, response)
    assert t.server._state["subject"] is None and t.server._state["tw"] is t.candidate_refs[-1]()
    assert t.server._state["observation_state"] is not t.observed
    assert t.server._workspace_actions == [] and t.snapshots


@pytest.mark.parametrize("kind,outcome", [("base", "COMMITTED"), ("life_system", "rollback"), ("base", "uncertain")])
def test_closed_manager_preview_fences_without_dropping_cleanup_owner(preview_boundary, kind, outcome):
    from livemorebio.aegle import execution_api
    from livemorebio.aegle.execution_contract import ExecutionError
    from livemorebio.aegle.execution import DENY_ALL
    t = preview_boundary
    t.outcome = outcome
    t.manager._owners[OWNER_ID] = t.store.owner
    with pytest.raises(ExecutionError):
        execution_api.shutdown_execution_manager()
    prior = tuple(t.store_calls)
    response = request_preview(t, kind)
    assert response.status_code == (409 if outcome == "rollback" else 503)
    context(t, response)
    assert t.manager._closed and t.server._execution_manager_instance is t.manager
    assert t.manager._owners == {OWNER_ID: t.store.owner} and t.manager._cleanup_pending == {OWNER_ID}
    assert tuple(t.store_calls) == prior
    if outcome == "COMMITTED":
        assert response.json()["code"] == "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
        assert t.server._state["subject"] is None and t.authority.generation != t.generation
        assert len(t.snapshots) == 1
    else:
        t.assert_original()
        assert not t.snapshots
        if outcome == "uncertain":
            assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL
        else:
            assert t.authority.generation == t.generation and "invalidate" not in t.calls
    t.store.fail = False
    execution_api.shutdown_execution_manager()
    assert t.server._execution_manager_instance is None and t.manager._owners == {}


@pytest.mark.parametrize("absence", ["both", "memory_only", "registry_only"])
def test_preview_distinguishes_true_and_one_sided_absence(preview_boundary, absence):
    t = preview_boundary
    old = deepcopy(t.initial["subject"])
    if absence in {"both", "memory_only"}:
        t.initial["subject"] = None
    t.active_override = None if absence in {"both", "registry_only"} else old
    t.freeze_original()
    response = request_preview(t, "base")
    if absence == "both":
        assert response.status_code == 200
        context(t, response)
        assert t.calls.count("commit") == 1
    else:
        assert_precommit_rejection(t, response, 409, "MODEL_SOURCE_CHANGED")
        assert not t.factory_calls
        t.assert_original()


@pytest.mark.parametrize("kind", KINDS)
def test_postcommit_winner_cannot_supply_older_preview_parameters(preview_boundary, kind):
    t = preview_boundary
    winner = SimpleNamespace(state=lambda: pytest.fail("Preview borrowed later winner"))
    def change():
        with t.real_guard():
            t.authority.install_generation("authored-post-preview-winner")
            t.server._state = {**t.server._state, "tw": winner, "subject": {"twin_id": "authored-winner"}}
    t.after_cleanup = change
    response = request_preview(t, kind)
    assert response.status_code == 200
    context(t, response)
    assert t.server._state["tw"] is winner and t.authority.generation == "authored-post-preview-winner"
    assert len(t.snapshots) == 1
    assert t.snapshots[0]["profile_params"] == {"technical": "candidate"}
    assert t.snapshots[0]["model_availability"]["source_generation"] != t.authority.generation
    assert response.json() == t.snapshots[0]


@pytest.mark.parametrize("base", [None, "healthy", "t2d", "type-2-diabetes"])
def test_original_base_aliases_and_default_run_only_after_prepare(preview_boundary, base):
    t = preview_boundary
    response = t.client.post("/api/stimulate", json={"kind": "base", "params": {} if base is None else {"base": base}})
    assert response.status_code == 200
    context(t, response)
    assert t.factory_calls == [("candidate", (base or "healthy",), {})]
    assert t.calls.index("state") < t.calls.index("serialize") < t.calls.index("commit")


@pytest.mark.parametrize("mode", [None, "random", "t2d_apoe4", "carrier", "custom"])
def test_original_life_modes_and_defaults_keep_factory_arguments(preview_boundary, mode):
    t = preview_boundary
    response = t.client.post("/api/stimulate", json={"kind": "life_system", "params": {} if mode is None else {"mode": mode}})
    assert response.status_code == 200
    context(t, response)
    assert t.factory_calls[-1] == ("candidate", (), {"human": t.human})
    if mode in {None, "random"}:
        assert [row[0] for row in t.factory_calls] == ["life-system", "generate", "candidate"]
        assert t.factory_calls[1][1] == (1,)
        assert type(t.factory_calls[1][2]["seed"]) is int and 0 <= t.factory_calls[1][2]["seed"] <= 10**6
    else:
        expected = {
            "t2d_apoe4": (("LMB-T2D",), {"age": 58, "sex": "F", "conditions": ["type 2 diabetes"], "genome": {"APOE4": 1, "TCF7L2": 1}, "lifestyle": 0.4}),
            "carrier": (("LMB-CAR",), {"age": 46, "sex": "M", "genome": {"TCF7L2": 2, "PPARG_loss": 1}, "lifestyle": 0.6}),
            "custom": (("LMB",), {"age": 50, "sex": "F", "conditions": [], "genome": {}, "lifestyle": 0.55}),
        }[mode]
        assert t.factory_calls[0] == ("synthetic", *expected)
    assert t.calls.index("serialize") < t.calls.index("commit")


@pytest.mark.parametrize("kind,params,prepared", [("base", {"base": "invalid"}, False),
    ("base", {"base": None}, False), ("life_system", {"mode": "invalid"}, False),
    ("life_system", {"mode": None}, False), ("life_system", {"mode": "custom", "age": "bad"}, True),
    ("life_system", {"mode": "custom", "lifestyle": "bad"}, True)])
def test_invalid_mode_and_custom_conversion_never_commit(preview_boundary, kind, params, prepared):
    t = preview_boundary
    result = t.client.post("/api/stimulate", json={"kind": kind, "params": params})
    assert_precommit_rejection(t, result, 422, "INVALID_INTERVENTION")
    assert ("prepare" in t.calls) is prepared
    if not prepared:
        assert "getter" not in t.calls
    t.assert_original()


@pytest.mark.parametrize("kind", KINDS)
def test_unauthorized_preview_precedes_factory_and_storage(preview_boundary, kind):
    t = preview_boundary
    t.client.headers["Authorization"] = "Bearer invalid-authored-token"
    result = request_preview(t, kind)
    assert result.status_code == 401 and "no-store" in result.headers["Cache-Control"]
    assert not t.calls and not t.factory_calls and not t.snapshots
    t.assert_original()


@pytest.mark.parametrize("kind", KINDS)
def test_failed_candidate_is_released_outside_every_selection_lock(preview_boundary, kind):
    t = preview_boundary
    t.outcome = "rollback"
    result = request_preview(t, kind)
    assert result.status_code == 409
    context(t, result)
    assert t.candidate_refs[-1]() is None
    assert t.retired == [("candidate", False, False, False, False)]
    t.assert_original()


@pytest.mark.parametrize("kind", ["life_system", "base"])  # L0-R15: base replaces the refused note route
def test_life_and_note_old_objects_retire_outside_locks(client, monkeypatch, kind):
    from livemorebio import bus
    from livemorebio.aegle import execution_api, server
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.model_contexts import model_availability
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.life_system import extract, synthetic_human

    authority = ModelSourceAuthority(server._invalidate_model_source,
        fence=server._assign_model_fence, fence_guard=server._model_fence_guard)
    manager = ExecutionManager(NoIOStore([]), adapter_registry={}, run_background=False,
                               permitted_generation=authority.generation)
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_execution_manager_instance", manager)
    retired = []
    def locks():
        return (authority._lock._is_owned(), execution_api._creation_lock._is_owned(),
                manager._lock._is_owned(), server._initialization_lock._is_owned())
    class RetireObserved:
        def __init__(self, name):
            weakref.finalize(self, lambda: retired.append((name, *locks())))
    before = deepcopy(server._state["subject"])
    before.update(source_class="SYNTHETIC", selection_mode="model")
    server._state.update(tw=RetireObserved("old-model"), subject=before,
        model_availability=model_availability(before, source_generation=authority.generation))
    monkeypatch.setattr(server, "_workspace_actions", [RetireObserved("old-action")])
    class Registry:
        def prepare_preview_clear(self, *, request_id):
            assert locks() == (True, False, False, False)
            return SimpleNamespace(kind="clear_for_preview", record=None, active_before=deepcopy(before),
                active_after=None, target_before=None, selected=False, request_id=request_id)
        def commit_prepared_transition(self, prepared):
            assert locks() == (True, True, True, False)
            return "COMMITTED"
        def clear_active_twin(self):
            pass  # Preserve the old path so RED reaches retirement, not a missing stub.
    candidate = SimpleNamespace(state=lambda: {"profile": "AUTHORED", "profile_params": {}})
    human = object()
    monkeypatch.setattr(server, "_subject_registry", lambda: Registry())
    monkeypatch.setattr(server, "AegleTwin", lambda *a, **k: candidate)
    monkeypatch.setattr(synthetic_human, "SyntheticHuman", lambda *a, **k: human)
    monkeypatch.setattr(extract, "ClinicalExtractor", lambda: SimpleNamespace(to_synthetic_human=lambda *a, **k: (human, {})))
    monkeypatch.setattr(bus, "set_snapshot", lambda *a, **k: None)
    monkeypatch.setattr(bus, "publish", lambda *a, **k: None)
    response = request_preview(SimpleNamespace(client=client), kind)
    assert response.status_code == 200
    assert sorted(retired) == [("old-action", False, False, False, False), ("old-model", False, False, False, False)]
    assert server._state["tw"] is candidate
    client.close()
