"""Assignment-only product fencing; all payloads are authored technical data."""
from contextlib import contextmanager
import threading

import pytest
from ._timing import wait_seconds


def test_product_fence_precedes_fallible_durable_cleanup_and_cleanup_is_outside_locks():
    from livemorebio.aegle.model_source import ModelSourceAuthority

    manager_lock = threading.RLock()
    seen = []

    @contextmanager
    def guard():
        with manager_lock:
            yield

    def fence(generation):
        assert manager_lock._is_owned()
        seen.append(("fence", generation))

    def cleanup(old, reason):
        assert not manager_lock._is_owned()
        assert not authority._lock._is_owned()
        seen.append(("cleanup", old))
        raise RuntimeError("technical durable invalidation failure")

    authority = ModelSourceAuthority(cleanup, fence=fence, fence_guard=guard)
    old = authority.generation
    state = {"selection": "before"}
    with pytest.raises(RuntimeError):
        with authority.mutation("technical-selection"):
            assert not manager_lock._is_owned(), "numerical action held the manager commit lock"
            assert seen == [("fence", authority.generation)]
            assert authority.generation != old
            state["selection"] = "after"
    assert state["selection"] == "after"
    assert authority.generation == seen[0][1]
    assert seen[1] == ("cleanup", old)


def test_confirmed_commit_guard_rollback_does_not_rotate_any_generation():
    from livemorebio.aegle.model_source import ModelSourceAuthority

    assigned = []
    authority = ModelSourceAuthority(fence=assigned.append)
    old = authority.generation
    with pytest.raises(ValueError):
        with authority.commit_guard():
            raise ValueError("technical confirmed registry rollback")
    assert assigned == []
    assert authority.generation == old


def test_uncertain_commit_denies_capture_and_reconciliation_requires_explicit_generation():
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.model_source import ModelSourceAuthority, SourceSelectionUnconfirmed

    assigned = []
    authority = ModelSourceAuthority(fence=assigned.append)
    with authority.commit_guard():
        authority.install_generation(DENY_ALL)
    assert assigned == [DENY_ALL]
    with pytest.raises(SourceSelectionUnconfirmed):
        authority.capture(lambda: pytest.fail("uncertain source was captured"))
    with pytest.raises(SourceSelectionUnconfirmed):
        _ = authority.generation
    with authority.commit_guard():
        authority.install_generation("reconciled-technical-generation")
    assert authority.generation == "reconciled-technical-generation"
    assert authority.capture(lambda: {"technical": True}) == {"technical": True}


def test_generation_install_requires_the_coherent_commit_guard():
    from livemorebio.aegle.model_source import ModelSourceAuthority

    authority = ModelSourceAuthority(fence=lambda _: None)
    old = authority.generation
    with pytest.raises(RuntimeError):
        authority.install_generation("unguarded-generation")
    assert authority.generation == old


def test_rejected_locked_precondition_does_not_rotate_or_invalidate():
    from livemorebio.aegle.model_source import ModelSourceAuthority

    calls = []
    authority = ModelSourceAuthority(lambda *a: calls.append("cleanup"), fence=lambda *a: calls.append("fence"))
    original = authority.generation

    def reject():
        assert authority._lock._is_owned()
        raise ValueError("technical unavailable selection")

    with pytest.raises(ValueError, match="technical unavailable"):
        with authority.mutation("technical", before=reject):
            pytest.fail("rejected precondition reached model mutation")
    assert authority.generation == original and calls == []


def test_product_factory_binds_creation_to_current_authority(tmp_path, monkeypatch):
    from livemorebio.aegle import server, execution, execution_api, execution_store
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio import security

    authority = ModelSourceAuthority()
    constructed = []

    class Manager:
        def __init__(self, store, **kwargs):
            constructed.append(kwargs)

    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_execution_manager_instance", None)
    monkeypatch.setattr(execution, "ExecutionManager", Manager)
    monkeypatch.setattr(execution_store, "ExecutionStore", lambda *a, **k: object())
    monkeypatch.setattr(security, "patch_storage_key", lambda **k: b"t" * 32)
    monkeypatch.setenv("LIVEMORE_EXECUTION_STORE", str(tmp_path / "technical.sqlite3"))
    execution_api._manager()
    assert constructed == [{"permitted_generation": authority.generation}]


def test_product_manager_creation_cannot_cross_selection_rotation(tmp_path, monkeypatch):
    from concurrent.futures import ThreadPoolExecutor
    from livemorebio.aegle import server, execution, execution_api, execution_store
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio import security

    entered, release, mutation_started = threading.Event(), threading.Event(), threading.Event()
    seen = []

    class Manager:
        def __init__(self, store, **kwargs):
            seen.append(kwargs.get("permitted_generation"))
            entered.set()
            assert release.wait(3)

    authority = ModelSourceAuthority()
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_execution_manager_instance", None)
    monkeypatch.setattr(execution, "ExecutionManager", Manager)
    monkeypatch.setattr(execution_store, "ExecutionStore", lambda *a, **k: object())
    monkeypatch.setattr(security, "patch_storage_key", lambda **k: b"t" * 32)
    monkeypatch.setenv("LIVEMORE_EXECUTION_STORE", str(tmp_path / "technical.sqlite3"))
    old = authority.generation

    def rotate():
        mutation_started.set()
        with authority.mutation("technical rotation"):
            seen.append("rotated")

    try:
        with ThreadPoolExecutor(2) as pool:
            constructing = pool.submit(execution_api._manager)
            assert entered.wait(2)
            rotating = pool.submit(rotate)
            assert mutation_started.wait(2)
            # The sentinel callback cannot run while creation owns authority.
            assert seen == [old]
            release.set()
            constructing.result(timeout=wait_seconds(2))
            rotating.result(timeout=wait_seconds(2))
        assert seen == [old, "rotated"]
    finally:
        release.set()
