"""Frozen nonhuman assay results retain their source, axes and public boundaries."""
from copy import deepcopy
import csv
import io
import json
from pathlib import Path

from fastapi.testclient import TestClient
import pytest

from livemorebio.cendos import lobeline_vmat2 as assay, service
from livemorebio.cendos.protocol_runs import ProtocolRunStore, analysis_csv, analysis_notebook
from livemorebio.tests.test_lobeline_vmat2 import specification


@pytest.fixture
def run():
    return assay.run_lobeline_vmat2(specification())


def test_history_and_exact_parent_reproduction(tmp_path: Path, run, monkeypatch):
    store = ProtocolRunStore(tmp_path / "runs")
    store.save(run)
    saved = store._path(run["run_id"]).read_bytes()
    assert store.history(q="lobeline")["runs"][0]["evidence_state"] == "MODELED_INITIAL_RATE"
    prepared = store.prepare_rerun(run["run_id"])
    assert prepared["request"] == run["input"]
    assert prepared["rerun_mode"] == "exact"
    assert prepared["endpoint"] == "/api/cendos/protocols/lobeline-vmat2"
    parent = store.validate_rerun(run["run_id"], run["input"], expected_protocol_id=assay.PROTOCOL_ID)
    assert parent["reproducible_parent_configuration"] is True
    changed = deepcopy(run["input"])
    changed["substrate_concentrations"].append(2)
    with pytest.raises(ValueError, match="configuration"):
        store.validate_rerun(run["run_id"], changed)
    assert store.validate_rerun(run["run_id"], changed, new_configuration=True)["rerun_mode"] == "new_configuration"
    assert store._path(run["run_id"]).read_bytes() == saved
    newer = assay.source_record()
    newer["extraction_version"] = "future-source-version"
    monkeypatch.setattr(assay, "source_record", lambda: newer)
    with pytest.raises(ValueError, match="source"):
        store.validate_rerun(run["run_id"], run["input"])
    assert store.validate_rerun(run["run_id"], run["input"], new_configuration=True)["rerun_mode"] == "new_configuration"


def test_csv_retains_points_source_and_discrepancy_without_person_or_time(run):
    rows = list(csv.DictReader(io.StringIO(analysis_csv(run))))
    points = [row for row in rows if row["record_type"] == "modeled_initial_rate"]
    assert len(points) == sum(len(row["points"]) for row in run["conditions"])
    assert float(points[2]["initial_rate"]) == run["conditions"][0]["points"][2]["initial_rate"]
    assert all(row["source_sha256"] == run["source_sha256"] for row in rows)
    compare = [row for row in rows if row["record_type"] == "published_parameter_comparison"][0]
    assert float(compare["difference_um"]) == run["benchmark_discrepancy"]["difference_um"]
    assert not {"member_id", "cohort", "t_min", "time"} & rows[0].keys()


def test_notebook_executes_independent_arithmetic_and_frozen_integrity(run):
    import matplotlib
    matplotlib.use("Agg")
    namespace = {}
    notebook = analysis_notebook(run)
    for cell in notebook["cells"]:
        if cell["cell_type"] == "code":
            exec("".join(cell["source"]), namespace)
    assert namespace["result"] == run
    assert namespace["difference_um"] == pytest.approx(-.12148936170212765)
    content = json.dumps(notebook)
    assert "not a time course" in content
    assert "not independent human" in content
    assert "parameters_refitted" in content


def test_nonhuman_conditions_cannot_enter_member_based_clinical_validation(run):
    from livemorebio.research import ResearchError, prediction_rows
    with pytest.raises(ResearchError, match="no supported measurement endpoint"):
        prediction_rows(run)


@pytest.fixture
def api(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "local-technical-test")
    monkeypatch.setenv("LIVEMORE_PROTOCOL_RUNS", str(tmp_path / "runs"))
    return TestClient(service.app)


AUTH = {"Authorization": "Bearer local-technical-test"}
ROUTE = "/protocols/lobeline-vmat2"


def test_api_auth_strict_json_and_nonhuman_applicability(api):
    assert api.post(ROUTE, json=specification()).status_code == 401
    assert api.post(ROUTE, headers=AUTH, content='{"material_id":"a","material_id":"b"}').status_code == 400
    wrong = specification(); wrong["context_id"] = "human-brain"
    response = api.post(ROUTE, headers=AUTH, json=wrong)
    assert response.status_code == 422
    assert response.json()["code"] == "INVALID_LOBELINE_SPECIFICATION"
    assert "human-brain" not in response.text
    assert api.get("/protocols/history", headers=AUTH).json()["runs"] == []


def test_api_run_recall_prepare_rerun_and_exports(api):
    original = api.post(ROUTE, headers=AUTH, json=specification())
    assert original.status_code == 201
    run = original.json()
    path = "/protocols/" + run["run_id"]
    assert api.get(path, headers=AUTH).json() == run
    prepared = api.get(path + "/prepare-rerun", headers=AUTH).json()
    response = api.post(ROUTE, headers=AUTH, json={**prepared["request"], "parent_run_id": run["run_id"]})
    assert response.status_code == 201
    child = response.json()
    assert child["run_id"] != run["run_id"]
    assert child["parent_run_id"] == run["run_id"]
    assert child["conditions"] == run["conditions"]
    assert child["reproducible_parent_configuration"] is True
    assert api.get(path, headers=AUTH).json() == run
    for suffix in ("/analysis.csv", "/analysis.ipynb"):
        assert api.get(path + suffix).status_code == 401
        response = api.get(path + suffix, headers=AUTH)
        assert response.status_code == 200
        assert response.headers["Cache-Control"] == "no-store"
    assert api.get(path + "/analysis.csv", headers=AUTH).text == analysis_csv(run)
    assert api.get(path + "/analysis.ipynb", headers=AUTH).json() == analysis_notebook(run)


def test_rerun_rejects_other_protocol_parent_and_invalid_acknowledgment(api):
    store = service._protocol_store()
    other = assay.run_lobeline_vmat2(specification())
    other["protocol_id"] = "cendos.human-gem-oxygen-capacity.v1"
    store.save(other)
    response = api.post(ROUTE, headers=AUTH, json={**specification(), "parent_run_id": other["run_id"]})
    assert response.status_code == 422
    response = api.post(ROUTE, headers=AUTH, json={**specification(), "new_configuration": "true"})
    assert response.status_code == 422


def test_sdk_uses_fixed_authenticated_assay_endpoint(monkeypatch):
    from livemorebio.sdk import Platform
    client = Platform(mode="attach")
    requests = []
    monkeypatch.setattr(client, "_post", lambda path, body, **kw: requests.append((path, body)) or {})
    spec = specification()
    client.run_lobeline_vmat2(spec)
    assert requests[-1] == ("/api/cendos/protocols/lobeline-vmat2", spec)
    with pytest.raises(TypeError):
        client.run_lobeline_vmat2([])
    prepared = {"protocol_id": assay.PROTOCOL_ID, "parent_run_id": "protocol-" + "b" * 32,
                "request": spec, "endpoint": "https://untrusted.invalid/"}
    client.execute_prepared_rerun(prepared)
    assert requests[-1][0] == "/api/cendos/protocols/lobeline-vmat2"
    assert requests[-1][1]["parent_run_id"] == prepared["parent_run_id"]
    assert "parent_run_id" not in spec


def test_terminal_assay_preparation_and_readout(tmp_path, run):
    from livemorebio.shell import run_command
    specification_path = tmp_path / "assay.json"
    specification_path.write_text(json.dumps(specification()), encoding="utf-8")
    class Client:
        def run_lobeline_vmat2(self, supplied):
            assert supplied == specification()
            return run
    lines = []
    assert run_command(Client(), f"protocol lobeline {specification_path}", out=lines.append) == run
    rendered = "\n".join(lines)
    for expected in ("nonhuman", "not a time course", "pmol/min/mg protein", "0.25", "UNQUALIFIED_DISCREPANCY", run["source_sha256"]):
        assert expected in rendered
