"""Knowledge substrate: property graph, semantic retrieval, clinical extraction."""
import numpy as np
import pytest
from types import SimpleNamespace
from livemorebio.life_system.knowledge import get_kb
from livemorebio.life_system.graph import KnowledgeGraph
from livemorebio.life_system.retrieval import SubstrateIndex, TuringDBAdapter
from livemorebio.life_system.extract import ClinicalExtractor, OpenMedNER
from livemorebio.engines.metabolic.glucose_insulin import GlucoseInsulinModel

kb = get_kb()


def test_graph_builds_and_links():
    kg = KnowledgeGraph(kb)
    s = kg.stats()
    assert s["by_kind"]["Disease"] >= 20 and s["by_kind"]["Gene"] > 100
    p = kg.path("Gene", "TCF7L2", "Organ", "pancreas")          # gene -> disease -> organ
    assert p and p[0] == "Gene:TCF7L2" and p[-1] == "Organ:pancreas"


def test_graph_cypher_export():
    cy = KnowledgeGraph(kb).export_cypher()
    assert len(cy) > 300 and any(c.startswith("MERGE (n:Disease") for c in cy)


def test_retrieval_ranks_relevant_biology():
    hits = SubstrateIndex(kb).query("insulin resistance glucose", k=5)
    assert any("diabetes" in n.lower() for _, n, _ in hits)


def test_turingdb_adapter_needs_endpoint():
    with pytest.raises(RuntimeError):
        TuringDBAdapter().query("x")


def test_extract_refuses_a_note_before_grounding_a_human():
    # L0-R15: this release has no operational local de-identification, so the
    # extractor refuses every note; no human is grounded from one.
    from .test_l0_clinical_note_gate import assert_note_refused

    note = "58 yo female with poorly controlled type 2 diabetes mellitus (T2DM), on metformin. TCF7L2 variant noted."
    assert_note_refused(lambda: ClinicalExtractor(kb).to_synthetic_human(note))
    assert_note_refused(lambda: ClinicalExtractor(kb).extract(note))
    # The technical route is unchanged: explicit fields, no note, and no invented effect size.
    from livemorebio.life_system.synthetic_human import SyntheticHuman
    h = SyntheticHuman("TECHNICAL-1", age=58, sex="F", conditions=["Type 2 diabetes mellitus"], genome={"TCF7L2": 1})
    r = GlucoseInsulinModel(h.metabolic_profile(kb)).simulate(hours=4, meals_g=[(0.0, 75.0)])
    g2 = float(r["glucose"][np.argmin(np.abs(r["t_min"] - 120))])
    assert np.isfinite(g2)
    assert kb.condition_effects(h.conditions)[0] == {}


def test_openmed_refuses_without_falling_back_to_the_substrate_extractor():
    # L0-R15: no fallback reads the text either.
    from .test_l0_clinical_note_gate import assert_note_refused

    assert_note_refused(lambda: OpenMedNER(kb=kb).extract("patient with type 2 diabetes"))


def test_openmed_current_api_is_not_given_the_note_in_this_release():
    # L0-R15: OpenMed is not an operational de-identifier in this release, so the
    # note is refused before deidentify or analyze_text sees it.
    from .test_l0_clinical_note_gate import assert_note_refused

    calls = []

    class FakeOpenMed:
        @staticmethod
        def deidentify(text, method):
            calls.append("deidentify")
            return SimpleNamespace(deidentified_text="Patient [NAME] has diabetes")

        @staticmethod
        def analyze_text(text, model_name):
            calls.append("analyze_text")
            entity = SimpleNamespace(
                label="DISEASE", text="diabetes", confidence=0.98, start=19, end=27,
            )
            return SimpleNamespace(entities=[entity])

    assert_note_refused(lambda: OpenMedNER(client=FakeOpenMed).extract(
        "SYNTHETIC: Patient Zyx Testname has diabetes", contains_phi=True))
    assert_note_refused(lambda: OpenMedNER(client=FakeOpenMed).extract("SYNTHETIC: type 2 diabetes"))
    assert calls == []
