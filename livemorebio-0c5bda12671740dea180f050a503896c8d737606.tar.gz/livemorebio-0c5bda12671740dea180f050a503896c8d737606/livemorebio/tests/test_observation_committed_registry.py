"""Fourth fixed transition and checked-action contracts; authored SQLite only."""
from contextlib import closing
from copy import deepcopy
from dataclasses import FrozenInstanceError, replace
import json
import sqlite3
from uuid import uuid4

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import pytest

from livemorebio.aegle import subjects
from livemorebio.aegle.model_source import ModelSourceAuthority
from livemorebio.aegle.registry_audit import RegistryAuditError
from livemorebio.aegle.subjects import SubjectRegistry, SubjectRegistryError
from livemorebio.strict_json import MAX_SAFE_INTEGER
from livemorebio.tests.clinical_registry_fixtures import CAPTURED, KEY, canonical, replace_fixture_record
from livemorebio.tests.test_committed_registry_transitions import (
    events, no_network_or_models, registry, rows, seed,  # noqa: F401
)


LEGACY_TIME = "2026-09-08T12:34:56.123456Z"


def forbidden(*args, **kwargs):
    pytest.fail("Observation registry test attempted a forbidden boundary")


@pytest.fixture(autouse=True)
def no_numerical_constructors(monkeypatch):
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.engines.metabolic.glucose_insulin import MetabolicProfile
    monkeypatch.setattr(AegleTwin, "__init__", forbidden)
    monkeypatch.setattr(MetabolicProfile, "__init__", forbidden)


def selected_pair(registry, relation="different"):
    seed(registry, "unrelated", version=7)
    if relation == "same":
        target = seed(registry, "target", active=True, human=True)
        return target, target
    selected = seed(registry, "selected", active=True) if relation == "different" else None
    return selected, seed(registry, "target", human=True)


def prepare(registry, target, request_id=None):
    return registry.prepare_observation_selection(target["twin_id"],
        expected_version=target["version"], request_id=request_id or str(uuid4()))


def audit_rows(registry):
    with closing(sqlite3.connect(registry.path)) as connection:
        return connection.execute("SELECT * FROM registry_audit ORDER BY sequence").fetchall()


def pending(registry):
    with closing(sqlite3.connect(registry.path)) as connection:
        return connection.execute("SELECT event_id,request_id FROM registry_audit_reservations ORDER BY event_id").fetchall()


def decode_audit(row):
    return json.loads(AESGCM(KEY).decrypt(bytes(row[2]), bytes(row[3]),
        b"livemore.subject-registry.audit.v1\0" + row[0].encode("ascii")))


def decode_record(row):
    return json.loads(AESGCM(KEY).decrypt(row[9], row[10],
        b"livemore.aegle.subject-registry.v1" + row[0].encode()))


def assert_actions(registry, request_id, outcomes, *, target=None, actions=None):
    actual = events(registry, request_id)
    assert [row[2]["outcome_code"] for row in actual] == outcomes
    expected_actions = actions or (["inspect"] * 2 + ["select_observations"] * max(0, len(outcomes) - 2))
    assert [row[2]["action"] for row in actual] == expected_actions
    assert len({row[0] for row in actual}) == len(actual)
    for _, _, event in actual:
        assert event["schema"] == "livemore.subject-access-audit.v1"
        assert event["request_id"] == request_id and event["local_store_id"] == registry.audit.store_id
        assert event["opaque_record_id"] == target
        assert set(event) == {"schema", "request_id", "action", "opaque_record_id", "started_at",
            "completed_at", "outcome_code", "local_store_id", "local_process_instance", "source_sha256"}
    return actual


def assert_selected(registry, before, selected, target, timestamp):
    after = rows(registry)
    old = {row[0]: row for row in before["records"]}
    new = {row[0]: row for row in after["records"]}
    expected = {target["twin_id"]: {**target, "lifecycle": "ACTIVE", "selection_mode": "observations_only",
                                  "version": target["version"] + 1, "updated_at": timestamp}}
    if selected is not None and selected["twin_id"] != target["twin_id"]:
        expected[selected["twin_id"]] = {**selected, "lifecycle": "DATA_ADMITTED",
            "version": selected["version"] + 1, "updated_at": timestamp}
    assert old.keys() == new.keys()
    for identifier in old:
        if identifier not in expected:
            assert new[identifier] == old[identifier]
            continue
        assert canonical(decode_record(new[identifier])) == canonical(expected[identifier])
        assert new[identifier][:3] == old[identifier][:3]
        assert new[identifier][5:8] == old[identifier][5:8]
        assert new[identifier][9:] != old[identifier][9:]
    expected_state = sorted(
        [row for row in before["registry_state"] if row[0] != "active_twin_id"]
        + [("active_twin_id", target["twin_id"], timestamp)]
    )
    assert after["registry_state"] == expected_state
    for name in ("subject_identifiers", "physical_device_bindings"):
        assert after[name] == before[name]
    assert [row[0] for row in after["records"] if row[1:4:2] == ("TWIN", "ACTIVE")] == [target["twin_id"]]
    return expected[target["twin_id"]]


def legacy_preparation(target, monkeypatch):
    with monkeypatch.context() as patch:
        patch.setattr(subjects, "_now", lambda: LEGACY_TIME)
        return subjects.prepare_observation_selection(target, expected_version=target["version"])


def install_mutation_fault(registry, monkeypatch, *, mode, damage=None):
    original = registry._connect
    state = {"attempts": 0, "updates": [], "pointer_writes": 0, "witness": 0,
             "closes": 0, "rollbacks_failed": 0, "faulted": False}
    class Connection:
        def __init__(self, real):
            self.real, self.changed, self.read_only = real, False, False

        def __getattr__(self, name):
            return getattr(self.real, name)

        def execute(self, sql, parameters=()):
            if self.read_only:
                assert sql.startswith("SELECT ")
            result = self.real.execute(sql, parameters)
            if sql == "BEGIN":
                assert state["faulted"]
                self.read_only = True
                state["witness"] += 1
            if sql == "UPDATE records SET lifecycle=?,version=?,updated_at=?,nonce=?,ciphertext=? WHERE record_id=? AND version=?":
                assert result.rowcount == 1
                self.changed = True
                state["updates"].append(parameters[-2])
            if sql.startswith("INSERT INTO registry_state VALUES"):
                assert self.changed
                state["pointer_writes"] += 1
            return result

        def commit(self):
            if not self.changed or state["faulted"]:
                return self.real.commit()
            assert state["pointer_writes"] == 1
            terminal = self.real.execute("SELECT * FROM registry_audit ORDER BY sequence DESC LIMIT 1").fetchone()
            event = decode_audit(terminal)
            assert event["action"] == "select_observations" and event["outcome_code"] == "SUCCESS"
            state["attempts"] += 1
            state["faulted"] = True
            if mode in {"rollback", "unknown_rollback"}:
                raise sqlite3.OperationalError("Authored mutation ACK failure")
            self.real.commit()
            if damage:
                damage()
            if mode in {"lost_ack", "lost_ack_close"}:
                raise sqlite3.OperationalError("Authored durable mutation ACK lost")

        def rollback(self):
            if self.changed and mode == "unknown_rollback":
                state["rollbacks_failed"] += 1
                raise OSError("Authored rollback ACK unknown")
            return self.real.rollback()

        def close(self):
            self.real.close()
            state["closes"] += 1
            if self.changed and mode in {"close", "lost_ack_close"}:
                raise OSError("Authored close ACK lost")
    monkeypatch.setattr(registry, "_connect", lambda: Connection(original()))
    return state


def checked_capture(registry, *, action="reconcile_selection", request_id=None):
    return registry.audited_active_twin(action=action, request_id=request_id or str(uuid4()), _checked_snapshot=True)


def checked_confirm(registry, captured, request_id=None):
    return registry.confirm_active_selection(expected_record=captured.record,
        request_id=request_id or captured.request_id, _expected_snapshot=captured)


# A: four successful shape/audit cases.
@pytest.mark.parametrize("relation", ["different", "same", "absent"])
def test_observation_commit_has_exact_bounded_transform_and_actions(registry, relation):
    selected, target = selected_pair(registry, relation)
    before = rows(registry)
    prepared = prepare(registry, target)
    assert prepared.kind == "select_observations" and prepared.target_before == target
    assert prepared.active_before == selected
    assert registry.commit_prepared_transition(prepared) == "COMMITTED"
    assert prepared.record == assert_selected(registry, before, selected, target, prepared.timestamp)
    assert_actions(registry, prepared.request_id, [None, "SUCCESS", None, "SUCCESS"], target=target["twin_id"])
    assert pending(registry) == []


def test_observation_preparation_is_detached_fixed_owner_and_durable_before_open(registry, monkeypatch):
    selected, target = selected_pair(registry)
    before, request_id = rows(registry), str(uuid4())
    original_open, opened = registry._open, []
    def guarded(row):
        actual = assert_actions(registry, request_id, [None], target=target["twin_id"], actions=["inspect"])
        assert pending(registry) == [(actual[0][0], request_id)]
        opened.append(row["record_id"])
        return original_open(row)
    monkeypatch.setattr(registry, "_open", guarded)
    monkeypatch.setattr(registry, "_audited", forbidden)
    authority = ModelSourceAuthority()
    with authority.observation():
        prepared = prepare(registry, target, request_id)
    assert rows(registry) == before and set(opened) == {selected["twin_id"], target["twin_id"]}
    assert len(opened) == 2 and len(prepared._rows) == 2
    assert prepared._pointer_before == tuple(before["registry_state"][0])
    assert type(prepared.authority_token) is str and prepared.authority_token
    assert prepared.store_id == registry.audit.store_id
    assert prepared._rows == tuple(row for row in before["records"] if row[0] in opened)
    assert "Authored software fixture" not in repr(prepared)
    with pytest.raises(FrozenInstanceError):
        prepared.timestamp = CAPTURED
    detached = prepared.record
    detached["observations"]["glucose_mgdl"]["value"] = 999
    assert prepared.record["observations"] == target["observations"]
    assert_actions(registry, request_id, [None, "SUCCESS"], target=target["twin_id"])
    with closing(sqlite3.connect(registry.path)) as connection:
        connection.execute("BEGIN IMMEDIATE"); connection.rollback()


# B: twelve admission/limit cases.
@pytest.mark.parametrize("version", [True, 1.0, 0, MAX_SAFE_INTEGER, MAX_SAFE_INTEGER + 1])
def test_observation_versions_are_safely_incrementable_before_io(registry, monkeypatch, version):
    target = seed(registry, human=True)
    monkeypatch.setattr(registry, "_connect", forbidden)
    with pytest.raises(SubjectRegistryError):
        registry.prepare_observation_selection(target["twin_id"], expected_version=version, request_id=str(uuid4()))
    with pytest.raises(SubjectRegistryError):
        registry.select_observations(target["twin_id"], expected_version=version)
    pure_record = {**target, "version": version}
    with pytest.raises(SubjectRegistryError):
        subjects.prepare_observation_selection(pure_record, expected_version=version)


@pytest.mark.parametrize("source", ["SYNTHETIC", "REFERENCE_GROUNDED_SYNTHETIC"])
def test_observation_transition_never_uses_numerical_admission_for_other_sources(registry, source):
    target = seed(registry)
    target["source_class"] = source
    nonce, ciphertext = registry._seal(target["twin_id"], target)
    with closing(registry._connect()) as connection, connection:
        connection.execute("UPDATE records SET source_class=?,nonce=?,ciphertext=? WHERE record_id=?", (source, nonce, ciphertext, target["twin_id"]))
    before = rows(registry)
    with pytest.raises(SubjectRegistryError): prepare(registry, target)
    assert rows(registry) == before


@pytest.mark.parametrize("damage", ["orphan", "second_active"])
def test_observation_transition_rejects_bad_active_topology_without_repair(registry, damage):
    _, target = selected_pair(registry)
    with closing(registry._connect()) as connection, connection:
        if damage == "orphan": connection.execute("DELETE FROM registry_state WHERE state_key='active_twin_id'")
        else: connection.execute("UPDATE records SET lifecycle='ACTIVE' WHERE record_id=?", (target["twin_id"],))
    before = rows(registry)
    with pytest.raises(SubjectRegistryError): prepare(registry, target)
    assert rows(registry) == before


def test_observation_demotion_at_maximum_rejects_without_mutation(registry):
    selected, target = selected_pair(registry)
    selected["version"] = MAX_SAFE_INTEGER
    replace_fixture_record(registry, selected)
    before = rows(registry)
    with pytest.raises(SubjectRegistryError): prepare(registry, target)
    assert rows(registry) == before


def test_observation_last_safe_increment_is_exact_and_cannot_repeat(registry):
    target = seed(registry, human=True, version=MAX_SAFE_INTEGER - 1)
    prepared = prepare(registry, target)
    assert registry.commit_prepared_transition(prepared) == "COMMITTED"
    assert type(prepared.record["version"]) is int and prepared.record["version"] == MAX_SAFE_INTEGER
    before = rows(registry)
    with pytest.raises(SubjectRegistryError): prepare(registry, prepared.record)
    assert rows(registry) == before


def test_observation_request_identity_rejects_before_connect(registry, monkeypatch):
    monkeypatch.setattr(registry, "_connect", forbidden)
    with pytest.raises(SubjectRegistryError):
        registry.prepare_observation_selection("twin-target", expected_version=1, request_id="not-canonical")


# C: seven exact snapshot/authority/forgery cases.
@pytest.mark.parametrize("damage", ["target_payload", "selected_payload", "pointer_timestamp"])
def test_observation_final_confirmation_rejects_same_version_interference(registry, damage):
    selected, target = selected_pair(registry)
    prepared = prepare(registry, target)
    if damage == "pointer_timestamp":
        with closing(registry._connect()) as connection, connection:
            connection.execute("UPDATE registry_state SET updated_at='authored-later'")
    else:
        record = deepcopy(target if damage == "target_payload" else selected)
        record["display_label"] = "Authored external edit"
        replace_fixture_record(registry, record)
    external = rows(registry)
    with pytest.raises(SubjectRegistryError) as caught: registry.commit_prepared_transition(prepared)
    assert caught.value.code == "TWIN_VERSION_CONFLICT" and rows(registry) == external
    assert_actions(registry, prepared.request_id, [None, "SUCCESS", None, "ACCESS_FAILED"], target=target["twin_id"])


def test_observation_old_bootstrap_authority_rejects_before_commit_decrypt(tmp_path, monkeypatch):
    from livemorebio.tests.test_registry_bootstrap_contract import legacy_audited_store
    store = SubjectRegistry(legacy_audited_store(tmp_path), key=KEY)
    target = store.get_twin("twin-fixture-one")
    prepared = prepare(store, target)
    assert prepared.authority_token.startswith("legacy:")
    SubjectRegistry(store.path, key=KEY).adopt_audit_authority()
    before, original_open = rows(store), store._open
    with monkeypatch.context() as patch:
        patch.setattr(store, "_open", forbidden)
        with pytest.raises(RegistryAuditError): store.commit_prepared_transition(prepared)
    assert rows(store) == before and store._open == original_open
    assert prepare(store, target).authority_token.startswith("proof:")


@pytest.mark.parametrize("damage", ["target_evidence", "demotion_timestamp", "numeric_alias"])
def test_observation_full_prepared_after_is_independently_reconstructed(registry, damage):
    selected, target = selected_pair(registry)
    prepared = prepare(registry, target)
    after = json.loads(prepared._after_json)
    if damage == "target_evidence": after[target["twin_id"]]["conditions"] = []
    elif damage == "demotion_timestamp": after[selected["twin_id"]]["updated_at"] = CAPTURED
    else: after[target["twin_id"]]["observations"]["glucose_mgdl"]["mapping_eligible"] = 1
    forged = replace(prepared, _after_json=canonical(after))
    before = rows(registry)
    with pytest.raises(SubjectRegistryError): registry.commit_prepared_transition(forged)
    assert rows(registry) == before


# D: fifteen mutation witness/outcome/phase cases.
def test_observation_exact_lost_ack_uses_full_once_only_witness(registry, monkeypatch):
    selected, target = selected_pair(registry)
    before, prepared = rows(registry), prepare(registry, target)
    state = install_mutation_fault(registry, monkeypatch, mode="lost_ack")
    assert registry.commit_prepared_transition(prepared) == "COMMITTED"
    assert state["attempts"] == state["pointer_writes"] == state["witness"] == 1
    assert sorted(state["updates"]) == sorted([selected["twin_id"], target["twin_id"]])
    assert_selected(registry, before, selected, target, prepared.timestamp)
    assert_actions(registry, prepared.request_id, [None, "SUCCESS", None, "SUCCESS"], target=target["twin_id"])


@pytest.mark.parametrize("damage", ["target", "demotion", "pointer", "begin", "terminal", "reservation", "topology"])
def test_observation_lost_ack_requires_every_witness_part(registry, monkeypatch, damage):
    selected, target = selected_pair(registry)
    prepared = prepare(registry, target)
    retained = []
    def alter():
        with closing(sqlite3.connect(registry.path)) as connection, connection:
            if damage in {"target", "demotion"}:
                identifier = (target if damage == "target" else selected)["twin_id"]
                connection.execute("UPDATE records SET request_hash='authored-changed' WHERE record_id=?", (identifier,))
            elif damage == "pointer": connection.execute("UPDATE registry_state SET updated_at='authored-changed'")
            elif damage in {"begin", "terminal"}:
                connection.execute("UPDATE registry_audit SET ciphertext=X'00' WHERE sequence=(SELECT MAX(sequence)-? FROM registry_audit)", (1 if damage == "begin" else 0,))
            elif damage == "reservation":
                identifier = connection.execute("SELECT event_id FROM registry_audit ORDER BY sequence DESC LIMIT 1 OFFSET 1").fetchone()[0]
                connection.execute("INSERT INTO registry_audit_reservations VALUES(?,?)", (identifier, prepared.request_id))
            else: connection.execute("UPDATE records SET lifecycle='ACTIVE' WHERE record_id=?", (selected["twin_id"],))
        retained.append((rows(registry), audit_rows(registry), pending(registry)))
    state = install_mutation_fault(registry, monkeypatch, mode="lost_ack", damage=alter)
    with pytest.raises(SubjectRegistryError) as caught: registry.commit_prepared_transition(prepared)
    assert caught.value.code == "SELECTION_COMMIT_UNCONFIRMED"
    assert state["attempts"] == state["witness"] == 1 and len(state["updates"]) == 2
    assert len(retained) == 1 and (rows(registry), audit_rows(registry), pending(registry)) == retained[0]


@pytest.mark.parametrize("mode", ["rollback", "unknown_rollback"])
def test_observation_rollback_outcomes_keep_original_rows_and_distinct_evidence(registry, monkeypatch, mode):
    _, target = selected_pair(registry)
    prepared, before = prepare(registry, target), rows(registry)
    state = install_mutation_fault(registry, monkeypatch, mode=mode)
    with pytest.raises(SubjectRegistryError) as caught: registry.commit_prepared_transition(prepared)
    assert rows(registry) == before and state["attempts"] == 1 and state["witness"] == 0
    if mode == "rollback":
        assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE"
        assert_actions(registry, prepared.request_id, [None, "SUCCESS", None, "ACCESS_FAILED"], target=target["twin_id"])
        assert pending(registry) == []
    else:
        assert caught.value.code == "SELECTION_COMMIT_UNCONFIRMED" and state["rollbacks_failed"] == 1
        actual = assert_actions(registry, prepared.request_id, [None, "SUCCESS", None], target=target["twin_id"])
        assert pending(registry) == [(actual[-1][0], prepared.request_id)]


@pytest.mark.parametrize("mode", ["close", "lost_ack_close"])
def test_observation_confirmed_close_never_discards_committed_outcome(registry, monkeypatch, mode):
    selected, target = selected_pair(registry)
    prepared, before = prepare(registry, target), rows(registry)
    state = install_mutation_fault(registry, monkeypatch, mode=mode)
    assert registry.commit_prepared_transition(prepared) == "COMMITTED_CLEANUP_UNCONFIRMED"
    assert state["attempts"] == 1 and len(state["updates"]) == 2
    assert state["witness"] == (1 if mode == "lost_ack_close" else 0)
    assert_selected(registry, before, selected, target, prepared.timestamp)
    assert_actions(registry, prepared.request_id, [None, "SUCCESS", None, "SUCCESS"], target=target["twin_id"])


def test_observation_deleted_begin_reservation_rejects_before_decrypt(registry, monkeypatch):
    _, target = selected_pair(registry)
    prepared, before = prepare(registry, target), rows(registry)
    original = registry._connect
    state = {"removed": False}
    class Connection:
        def __init__(self, real): self.real = real
        def __getattr__(self, name): return getattr(self.real, name)
        def commit(self):
            self.real.commit()
            if not state["removed"]:
                state["removed"] = True
                with closing(sqlite3.connect(registry.path)) as other, other:
                    assert other.execute("SELECT COUNT(*) FROM registry_audit_reservations WHERE request_id=?", (prepared.request_id,)).fetchone()[0] == 1
                    other.execute("DELETE FROM registry_audit_reservations WHERE request_id=?", (prepared.request_id,))
    monkeypatch.setattr(registry, "_connect", lambda: Connection(original()))
    monkeypatch.setattr(registry, "_open", forbidden)
    with pytest.raises(RegistryAuditError): registry.commit_prepared_transition(prepared)
    assert state["removed"] and rows(registry) == before


def test_observation_terminal_trigger_cannot_change_demoted_row(registry):
    selected, target = selected_pair(registry)
    prepared, before = prepare(registry, target), rows(registry)
    with closing(registry._connect()) as connection, connection:
        connection.execute("CREATE TRIGGER authored_observation_terminal AFTER INSERT ON registry_audit WHEN EXISTS(SELECT 1 FROM registry_audit_reservations) BEGIN UPDATE records SET version=999 WHERE record_id='" + selected["twin_id"] + "'; END")
    with pytest.raises(SubjectRegistryError): registry.commit_prepared_transition(prepared)
    assert rows(registry) == before
    assert not any(row[2]["outcome_code"] == "SUCCESS" and row[2]["action"] == "select_observations" for row in events(registry, prepared.request_id))


def test_observation_failed_completion_protects_new_live_pointer_after_rollback(registry, monkeypatch):
    selected, target = selected_pair(registry)
    later = seed(registry, "later")
    prepared = prepare(registry, target)
    replacements = []
    for record, lifecycle in ((selected, "DATA_ADMITTED"), (later, "ACTIVE")):
        value = {**record, "lifecycle": lifecycle, "version": record["version"] + 1}
        replacements.append((value, *registry._seal(value["twin_id"], value)))
    original_connect, original_open, original_finish = registry._connect, registry._open, registry.audit.finish
    moved, opened = [], []
    class Connection:
        def __init__(self, real): self.real, self.moved = real, False
        def __getattr__(self, name): return getattr(self.real, name)
        def rollback(self):
            self.real.rollback()
            if not self.moved:
                self.moved = True
                with closing(sqlite3.connect(registry.path)) as other, other:
                    for value, nonce, ciphertext in replacements:
                        other.execute("UPDATE records SET lifecycle=?,version=?,nonce=?,ciphertext=? WHERE record_id=?", (value["lifecycle"], value["version"], nonce, ciphertext, value["twin_id"]))
                    other.execute("UPDATE registry_state SET state_value=? WHERE state_key='active_twin_id'", (later["twin_id"],))
                moved.append(rows(registry))
    def finish(connection, reservation, *, outcome_code):
        if outcome_code == "SUCCESS":
            raise SubjectRegistryError("TWIN_VERSION_CONFLICT", "Authored primary conflict")
        return original_finish(connection, reservation, outcome_code=outcome_code)
    def opened_record(row):
        opened.append(row["record_id"])
        return original_open(row)
    with closing(registry._connect()) as connection, connection:
        connection.execute("CREATE TRIGGER authored_observation_failure AFTER INSERT ON registry_audit WHEN EXISTS(SELECT 1 FROM registry_audit_reservations) BEGIN UPDATE records SET version=999 WHERE record_id=(SELECT state_value FROM registry_state WHERE state_key='active_twin_id'); END")
    monkeypatch.setattr(registry, "_connect", lambda: Connection(original_connect()))
    monkeypatch.setattr(registry, "_open", opened_record)
    monkeypatch.setattr(registry.audit, "finish", finish)
    with pytest.raises(SubjectRegistryError) as caught: registry.commit_prepared_transition(prepared)
    assert caught.value.code == "TWIN_VERSION_CONFLICT" and str(caught.value) == "Authored primary conflict"
    assert len(moved) == 1 and rows(registry) == moved[0]
    assert len(opened) == 2 and later["twin_id"] not in opened
    assert len(pending(registry)) == 1
    assert not any(row[2]["outcome_code"] == "ACCESS_FAILED" for row in events(registry, prepared.request_id))


# E: eleven direct legacy compatibility cases.
@pytest.mark.parametrize("variant", ["different_prepared", "same_prepared", "fresh_default"])
def test_direct_observation_compatibility_preserves_legacy_time_and_full_authority(registry, monkeypatch, variant):
    selected, target = selected_pair(registry, "same" if variant == "same_prepared" else "different")
    before, audit_before = rows(registry), audit_rows(registry)
    legacy = None if variant == "fresh_default" else legacy_preparation(target, monkeypatch)
    request_id = str(uuid4()) if variant == "different_prepared" else None
    result = registry.select_observations(target["twin_id"], expected_version=1, prepared=legacy, request_id=request_id)
    if legacy is not None:
        assert canonical(result) == legacy._record_json and result["updated_at"] == LEGACY_TIME
    assert_selected(registry, before, selected, target, result["updated_at"])
    new_audit = audit_rows(registry)
    assert new_audit[:len(audit_before)] == audit_before and len(new_audit) == len(audit_before) + 4
    request_id = request_id or decode_audit(new_audit[-1])["request_id"]
    assert_actions(registry, request_id, [None, "SUCCESS", None, "SUCCESS"], target=target["twin_id"])
    assert pending(registry) == []


@pytest.mark.parametrize("damage", ["float_version", "bool_alias", "extra_evidence", "timestamp", "digest"])
def test_direct_observation_legacy_prepared_values_require_typed_canonical_transform(registry, monkeypatch, damage):
    _, target = selected_pair(registry)
    legacy = legacy_preparation(target, monkeypatch)
    result = legacy.record
    if damage == "float_version": result["version"] = 2.0
    elif damage == "bool_alias": result["observations"]["glucose_mgdl"]["mapping_eligible"] = 1
    elif damage == "extra_evidence": result["conditions"] = []
    elif damage == "timestamp": result["updated_at"] = "not-a-timestamp"
    forged = replace(legacy, _record_json=canonical(result),
                     original_sha256="bad-digest" if damage == "digest" else legacy.original_sha256)
    before = rows(registry)
    with pytest.raises(SubjectRegistryError):
        registry.select_observations(target["twin_id"], expected_version=1, prepared=forged)
    assert rows(registry) == before


def test_direct_observation_stale_pure_digest_is_not_fresh_row_authority(registry, monkeypatch):
    _, target = selected_pair(registry)
    legacy = legacy_preparation(target, monkeypatch)
    replace_fixture_record(registry, {**target, "display_label": "Authored later exact content"})
    before = rows(registry)
    with pytest.raises(SubjectRegistryError) as caught:
        registry.select_observations(target["twin_id"], expected_version=1, prepared=legacy)
    assert caught.value.code == "TWIN_VERSION_CONFLICT" and rows(registry) == before


def test_standalone_observation_preparation_stays_pure_and_detached(registry, monkeypatch):
    target = seed(registry, human=True)
    before = (rows(registry), audit_rows(registry))
    monkeypatch.setattr(registry, "_connect", forbidden)
    legacy = legacy_preparation(target, monkeypatch)
    assert type(legacy) is subjects.PreparedObservationSelection
    assert legacy.original_sha256 == subjects._request_hash(target)
    detached = legacy.record
    detached["conditions"] = []
    assert legacy.record["conditions"] == target["conditions"]
    assert (rows(registry), audit_rows(registry)) == before


def test_direct_observation_confirmed_close_uses_typed_cleanup_result(registry, monkeypatch):
    selected, target = selected_pair(registry)
    before = rows(registry)
    legacy = legacy_preparation(target, monkeypatch)
    state = install_mutation_fault(registry, monkeypatch, mode="close")
    with pytest.raises(SubjectRegistryError) as caught:
        registry.select_observations(target["twin_id"], expected_version=1, prepared=legacy)
    assert caught.value.code == "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
    assert state["attempts"] == 1
    assert_selected(registry, before, selected, target, LEGACY_TIME)


# F: thirteen checked action/default/confirmation cases.
@pytest.mark.parametrize("source", ["synthetic_max", "human_max", "absent"])
def test_checked_reconciliation_action_is_read_only_with_inclusive_maximum(registry, source):
    seed(registry, "unrelated")
    record = None if source == "absent" else seed(registry, "selected", active=True,
        human=source == "human_max", version=MAX_SAFE_INTEGER)
    before, request_id = rows(registry), str(uuid4())
    captured = checked_capture(registry, request_id=request_id)
    assert type(captured) is subjects.CheckedActiveSelection and captured.record == record
    assert checked_confirm(registry, captured) is None and rows(registry) == before
    assert_actions(registry, request_id, [None, "SUCCESS", None, "SUCCESS"], actions=["reconcile_selection"] * 4)
    assert pending(registry) == []


class ActionString(str):
    pass


@pytest.mark.parametrize("action", [None, [], True, ActionString("inspect"), "select_observations"])
def test_checked_capture_action_requires_exact_reviewed_string_before_io(registry, monkeypatch, action):
    monkeypatch.setattr(registry, "_connect", forbidden)
    with pytest.raises(SubjectRegistryError): checked_capture(registry, action=action)


def test_checked_default_startup_action_and_fixed_confirmation_remain_unchanged(registry):
    seed(registry, active=True)
    request_id = str(uuid4())
    captured = registry.audited_active_twin(request_id=request_id, _checked_snapshot=True)
    assert checked_confirm(registry, captured) is None
    assert_actions(registry, request_id, [None, "SUCCESS", None, "SUCCESS"], actions=["inspect"] * 2 + ["reconcile_selection"] * 2)


@pytest.mark.parametrize("damage", ["pointer_timestamp", "adoption"])
def test_new_checked_capture_action_does_not_weaken_final_identity(tmp_path, monkeypatch, damage):
    from livemorebio.tests.test_registry_bootstrap_contract import legacy_audited_store
    store = SubjectRegistry(legacy_audited_store(tmp_path), key=KEY)
    record = store.get_twin("twin-fixture-one")
    record["lifecycle"] = "ACTIVE"
    replace_fixture_record(store, record)
    with closing(store._connect()) as connection, connection:
        connection.execute("INSERT INTO registry_state VALUES('active_twin_id',?,?)", (record["twin_id"], CAPTURED))
    captured = checked_capture(store)
    if damage == "adoption":
        SubjectRegistry(store.path, key=KEY).adopt_audit_authority()
        monkeypatch.setattr(store, "_open", forbidden)
    else:
        with closing(store._connect()) as connection, connection:
            connection.execute("UPDATE registry_state SET updated_at='authored-later'")
    before = rows(store)
    with pytest.raises(SubjectRegistryError) as caught: checked_confirm(store, captured)
    assert caught.value.code == "SELECTION_RECONCILIATION_CONFLICT" and rows(store) == before


@pytest.mark.parametrize("fault", ["terminal_ack", "close_ack"])
def test_new_checked_action_does_not_return_on_audit_or_close_uncertainty(registry, monkeypatch, fault):
    seed(registry, active=True)
    before, request_id, original = rows(registry), str(uuid4()), registry._connect
    state = {"terminal": False, "closed": False}
    class Connection:
        def __init__(self, real): self.real = real
        def __getattr__(self, name): return getattr(self.real, name)
        def commit(self):
            latest = self.real.execute("SELECT * FROM registry_audit ORDER BY sequence DESC LIMIT 1").fetchone()
            event = decode_audit(latest)
            self.real.commit()
            if event["request_id"] == request_id and event["outcome_code"] == "SUCCESS" and fault == "terminal_ack":
                state["terminal"] = True
                assert event["action"] == "reconcile_selection"
                raise sqlite3.OperationalError("Authored checked terminal ACK lost")
        def close(self):
            self.real.close(); state["closed"] = True
            if fault == "close_ack": raise OSError("Authored private-path checked close ACK lost")
    monkeypatch.setattr(registry, "_connect", lambda: Connection(original()))
    with pytest.raises(SubjectRegistryError) as caught: checked_capture(registry, request_id=request_id)
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE" and "private-path" not in str(caught.value)
    assert rows(registry) == before and state["closed"]
    assert state["terminal"] == (fault == "terminal_ack")
