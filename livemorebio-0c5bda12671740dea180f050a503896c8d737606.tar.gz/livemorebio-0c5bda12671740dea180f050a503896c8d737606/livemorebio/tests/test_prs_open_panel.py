"""Fixed open-GWAS subset preserves the stable research calculation exactly."""
import json
import struct
from pathlib import Path

import pytest

from livemorebio.life_system.reference import prs


FIXTURE = json.loads((Path(__file__).parent / "fixtures" / "prs_stable_subset.json").read_text(encoding="utf-8"))


@pytest.fixture(autouse=True)
def fresh_panel(monkeypatch):
    monkeypatch.setattr(prs, "_PANEL", {"loaded": False, "axes": {}})


def test_panel_is_exactly_the_eleven_authored_loci_in_stable_summation_order():
    assert {axis: [g for g, _, _ in loci] for axis, loci in prs._panel().items()} == FIXTURE["panel"]
    assert prs.panel_summary() == {"metabolic": 6, "cardiovascular": 3, "inflammatory": 1, "neuro": 1}


def test_target_annotation_changes_cannot_change_executable_panel(monkeypatch):
    from livemorebio.life_system.reference.knowledgebase import KnowledgeBase

    def forbidden(*_args, **_kwargs):
        pytest.fail("PRS read descriptive disease-to-gene associations")

    monkeypatch.setattr(KnowledgeBase, "variant_catalogue", forbidden)
    assert prs.panel_summary() == {axis: len(genes) for axis, genes in FIXTURE["panel"].items()}


def _json_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode().hex()


@pytest.mark.parametrize("case", FIXTURE["inputs"], ids=lambda case: case["id"])
def test_scores_offsets_and_unrounded_binary64_are_exact_stable_bytes(case):
    assert prs.scores(case["genome"]) == case["stable"]["scores"]
    assert prs.biomarker_offsets(case["genome"]) == case["stable"]["biomarker_offsets"]
    assert _json_bytes(prs.scores(case["genome"])) == case["stable"]["scores_json_utf8_hex"]
    assert _json_bytes(prs.biomarker_offsets(case["genome"])) == case["stable"]["offsets_json_utf8_hex"]
    for axis in FIXTURE["panel"]:
        actual = struct.pack(">d", prs.axis_score(case["genome"], axis)).hex()
        assert actual == case["stable"]["axis_binary64"][axis]


@pytest.mark.parametrize("axis", ["oncologic", "respiratory", "unknown", "", "nonexistent"])
def test_absent_axis_is_a_typed_refusal(axis):
    with pytest.raises(prs.PRSInputError) as caught:
        prs.axis_score({}, axis)
    assert caught.value.reason_code == "PRS_AXIS_NOT_DISTRIBUTED"


def test_missing_locus_is_a_typed_refusal():
    with pytest.raises(prs.PRSInputError) as caught:
        prs.axis_score({"LDLR": 2, "PCSK9": 2}, "cardiovascular")
    assert caught.value.reason_code == "PRS_GENOTYPE_INCOMPLETE"
    assert caught.value.missing_loci == ["APOB"]


@pytest.mark.parametrize("dosage", [-1, 3, 0.5, float("nan"), float("inf"), None, "1", True])
def test_invalid_dosage_is_a_typed_refusal(dosage):
    genome = {"LDLR": 1, "APOB": dosage, "PCSK9": 1}
    for evaluate in (lambda: prs.axis_score(genome, "cardiovascular"),
                     lambda: prs.scores(genome), lambda: prs.biomarker_offsets(genome)):
        with pytest.raises(prs.PRSInputError) as caught:
            evaluate()
        assert caught.value.reason_code == "PRS_DOSAGE_INVALID"
        assert caught.value.invalid_loci == ["APOB"]


def test_stable_complete_genome_still_has_all_retained_scores_and_offsets():
    genome = {gene: 1 for genes in FIXTURE["panel"].values() for gene in genes}
    genome["CDKN2A"] = 1
    assert set(prs.scores(genome)) == set(FIXTURE["panel"])
    assert set(prs.biomarker_offsets(genome)) == {"ldl", "systolic_bp", "hba1c", "fasting_glucose", "bmi", "inflammation"}


def test_coverage_exposes_missing_invalid_and_unsupported_axes():
    status = prs.coverage({"LDLR": 1, "APOB": 0.5})
    assert status["cardiovascular"]["reason_code"] == "PRS_DOSAGE_INVALID"
    assert status["cardiovascular"]["invalid_loci"] == ["APOB"]
    assert status["cardiovascular"]["missing_loci"] == ["PCSK9"]
    assert status["metabolic"]["reason_code"] == "PRS_GENOTYPE_INCOMPLETE"
    assert set(status["metabolic"]["missing_loci"]) == set(FIXTURE["panel"]["metabolic"])
    assert status["oncologic"]["reason_code"] == "PRS_AXIS_NOT_DISTRIBUTED"
    complete = {gene: 1 for genes in FIXTURE["panel"].values() for gene in genes}
    assert all(prs.coverage(complete)[axis]["status"] == "available" for axis in FIXTURE["panel"])


def test_factory_records_coverage_instead_of_silent_empty_scores():
    from livemorebio.life_system.reference.patient_factory import PatientFactory

    human = PatientFactory(seed=7).create("technical-prs-coverage")
    assert human.reference["polygenic_score_coverage"] == prs.coverage(human.genome)
    assert human.reference["polygenic_score_coverage"]["metabolic"]["reason_code"] == "PRS_GENOTYPE_INCOMPLETE"


def test_absent_trait_annotation_cannot_add_a_locus(monkeypatch):
    original = prs.CAL._load
    monkeypatch.setattr(prs.CAL, "_load", lambda: {**original(), "UNCLASSIFIED": {"or": 2.0, "risk_af": 0.5}})
    assert all(gene != "UNCLASSIFIED" for loci in prs._panel().values() for gene, _, _ in loci)


@pytest.mark.parametrize("odds_ratio", [float("nan"), float("inf"), -float("inf"), 0, -1])
def test_nonfinite_or_nonpositive_effect_refuses_the_entire_axis(monkeypatch, odds_ratio):
    original = prs.CAL.info
    monkeypatch.setattr(prs.CAL, "info", lambda gene: (
        {**original(gene), "or": odds_ratio} if gene == "TCF7L2" else original(gene)
    ))
    assert "metabolic" not in prs._panel()
    with pytest.raises(prs.PRSInputError) as caught:
        prs.axis_score({gene: 1 for gene in FIXTURE["panel"]["metabolic"]}, "metabolic")
    assert caught.value.reason_code == "PRS_AXIS_NOT_DISTRIBUTED"


def test_unknown_allele_or_frequency_cannot_silently_shrink_an_axis(monkeypatch):
    original = prs.CAL.info
    monkeypatch.setattr(prs.CAL, "info", lambda gene: (
        {**original(gene), "allele": "rs7903146-?"} if gene == "TCF7L2" else original(gene)
    ))
    assert "metabolic" not in prs._panel()
    assert prs.coverage({})["metabolic"]["reason_code"] == "PRS_AXIS_NOT_DISTRIBUTED"


def test_degenerate_zero_variance_refuses_instead_of_returning_population_mean(monkeypatch):
    original = prs.CAL.info
    monkeypatch.setattr(prs.CAL, "info", lambda gene: {**original(gene), "or": 1})
    with pytest.raises(prs.PRSInputError) as caught:
        prs.axis_score({gene: 1 for gene in FIXTURE["panel"]["metabolic"]}, "metabolic")
    assert caught.value.reason_code == "PRS_AXIS_NOT_DISTRIBUTED"


def test_standardisation_check_does_not_present_circular_correlation_as_validation():
    report = prs.validate(n=100, seed=17)
    assert set(report) == set(FIXTURE["panel"])
    assert all(set(row) == {"n_loci", "prs_mean", "prs_sd"} for row in report.values())
    assert "normal" not in prs.validate.__doc__.lower()


def test_every_admitted_locus_has_separate_open_trait_and_inherited_effect_provenance():
    from livemorebio.life_system.reference.gwas_traits import GWAS_LOCUS_PROVENANCE

    assert set(GWAS_LOCUS_PROVENANCE) == {gene for genes in FIXTURE["panel"].values() for gene in genes}
    for gene, row in GWAS_LOCUS_PROVENANCE.items():
        assert row["trait_record"]["accession"].startswith("GCST")
        assert row["trait_record"]["reported_trait"]
        assert row["trait_record"]["source_url"].startswith("https://www.ebi.ac.uk/gwas/rest/api/v2/associations/")
        assert row["bundled_effect"]["allele"] == prs.CAL.info(gene)["allele"]
        assert row["bundled_effect"]["historical_accession_status"] == "not_recorded"
    assert GWAS_LOCUS_PROVENANCE["HNF1B"]["bundled_effect"]["limitation"] == "opposite_direction_for_metabolic_trait"


def test_oracle_identifies_the_stable_commit_not_the_annotated_tag_object():
    assert FIXTURE["baseline_commit"] == "658870775e581c044a8832fd107e4097f7a30959"


@pytest.mark.parametrize("evaluate", [prs.scores, prs.biomarker_offsets])
@pytest.mark.parametrize("genome", [{}, {"LDLR": 1}])
def test_aggregate_without_any_complete_axis_refuses(evaluate, genome):
    with pytest.raises(prs.PRSInputError) as caught:
        evaluate(genome)
    assert caught.value.reason_code == "PRS_GENOTYPE_INCOMPLETE"
    assert "APOB" in caught.value.missing_loci


@pytest.mark.parametrize("evaluate", [prs.scores, prs.biomarker_offsets])
def test_aggregate_without_reference_parameters_refuses(monkeypatch, evaluate):
    monkeypatch.setattr(prs, "_PANEL", {"loaded": True, "axes": {}})
    with pytest.raises(prs.PRSInputError) as caught:
        evaluate({})
    assert caught.value.reason_code == "PRS_AXIS_NOT_DISTRIBUTED"


def test_neuro_only_genotype_has_score_but_refuses_missing_biomarker_axes():
    assert prs.scores({"LRRK2": 1}) == {"neuro": round(prs.axis_score({"LRRK2": 1}, "neuro"), 3)}
    with pytest.raises(prs.PRSInputError) as caught:
        prs.biomarker_offsets({"LRRK2": 1})
    assert caught.value.reason_code == "PRS_GENOTYPE_INCOMPLETE"


def test_partial_aggregate_retains_values_and_exposes_omissions():
    genome = {gene: 1 for gene in FIXTURE["panel"]["metabolic"]}
    assert prs.scores(genome) == {"metabolic": round(prs.axis_score(genome, "metabolic"), 3)}
    assert set(prs.biomarker_offsets(genome)) == {"hba1c", "fasting_glucose", "bmi"}
    assert prs.coverage(genome)["metabolic"]["status"] == "available"
    assert prs.coverage(genome)["cardiovascular"]["reason_code"] == "PRS_GENOTYPE_INCOMPLETE"


def test_factory_records_null_scores_and_typed_refusals_for_unavailable_genotypes():
    from livemorebio.life_system.reference.patient_factory import PatientFactory

    human = PatientFactory(seed=7).create("technical-prs-refusal")
    assert human.reference["polygenic_scores"] is None
    assert human.reference["polygenic_biomarker_offsets"] is None
    for field in ("scores", "biomarker_offsets"):
        assert human.reference["polygenic_refusals"][field]["reason_code"] == "PRS_GENOTYPE_INCOMPLETE"
        assert human.reference["polygenic_refusals"][field]["missing_loci"]
    assert human.reference["polygenic_score_coverage"] == prs.coverage(human.genome)


def test_factory_does_not_swallow_invalid_dosage_refusals(monkeypatch):
    from livemorebio.life_system.reference.patient_factory import PatientFactory

    def refuse(_genome):
        raise prs.PRSInputError(prs.PRSReasonCode.DOSAGE_INVALID, "metabolic", invalid_loci=["TCF7L2"])

    monkeypatch.setattr(prs, "scores", refuse)
    with pytest.raises(prs.PRSInputError) as caught:
        PatientFactory(seed=7).create("technical-prs-invalid")
    assert caught.value.reason_code == "PRS_DOSAGE_INVALID"


def test_standardisation_check_refuses_without_any_reference_axis(monkeypatch):
    monkeypatch.setattr(prs, "_PANEL", {"loaded": True, "axes": {}})
    assert prs.panel_summary() == {}
    with pytest.raises(prs.PRSInputError) as caught:
        prs.validate(n=10)
    assert caught.value.reason_code == "PRS_AXIS_NOT_DISTRIBUTED"
