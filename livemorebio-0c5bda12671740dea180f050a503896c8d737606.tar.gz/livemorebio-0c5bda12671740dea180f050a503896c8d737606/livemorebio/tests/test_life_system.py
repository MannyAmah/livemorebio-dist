"""LIFE reference annotations must not invent an individual's disease physiology."""
import numpy as np
from livemorebio.life_system.knowledge import get_kb
from livemorebio.life_system.synthetic_human import SyntheticHuman
from livemorebio.life_system.population import LifeSystem
from livemorebio.engines.metabolic.glucose_insulin import GlucoseInsulinModel
from livemorebio.aegle.runtime import AegleTwin

kb = get_kb()


def _two_hour(h):
    p = h.metabolic_profile(kb)
    r = GlucoseInsulinModel(p).simulate(hours=4, meals_g=[(0.0, 75.0)])
    return float(r["glucose"][np.argmin(np.abs(r["t_min"] - 120))])


def test_knowledge_substrate_loaded():
    assert len(kb.diseases) == 20
    assert len(kb.variants) > 100                # reference gene associations, not causal variants
    assert "TCF7L2" in kb.variants and "KRAS" in kb.variants


def test_reference_human_is_normoglycemic():
    assert _two_hour(SyntheticHuman("ref", age=30, sex="F", lifestyle=0.75)) < 140


def test_disease_annotation_does_not_invent_a_diabetic_trajectory():
    h = SyntheticHuman("t2d", age=58, sex="M", conditions=["type 2 diabetes"], lifestyle=0.4)
    reference = SyntheticHuman("ref", age=58, sex="M", lifestyle=0.4)
    assert _two_hour(h) == _two_hour(reference)
    assert kb.condition_effects("type 2 diabetes")[0] == {}


def test_genotype_only_carrier_is_prediabetic():
    h = SyntheticHuman("carrier", age=50, sex="F", genome={"TCF7L2": 2, "PPARG_loss": 1}, lifestyle=0.55)
    g2 = _two_hour(h)
    assert 140 <= g2 < 200                        # IGT from genetics alone


def test_cardiovascular_condition_spares_glucose():
    h = SyntheticHuman("cad", age=62, sex="M", conditions=["coronary artery disease"], lifestyle=0.6)
    assert _two_hour(h) < 140                     # CAD axis doesn't drive hyperglycemia


def test_population_is_diverse():
    pop = LifeSystem().generate(n=120, seed=3)
    assert len(pop) == 120
    assert any(h.conditions for h in pop) and any(h.genome for h in pop)
    assert max(h.age for h in pop) - min(h.age for h in pop) > 30


def test_twin_from_grounded_human():
    h = SyntheticHuman("t2d", age=58, sex="M", conditions=["type 2 diabetes"], lifestyle=0.4)
    st = AegleTwin(human=h).state()
    assert st["base"] == "life_system"
    assert st["human"]["conditions"] == ["type 2 diabetes"]
    assert st["provenance"]["glucose"] == "synthetic-model"   # model origin, not a measurement
    reference = AegleTwin(human=SyntheticHuman("ref", age=58, sex="M", lifestyle=0.4)).state()
    assert st["metabolic"]["mean_glucose"] == reference["metabolic"]["mean_glucose"]
