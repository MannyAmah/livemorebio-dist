"""Technical socketless launcher fixtures; generic errors are baseline guards."""

from io import BytesIO
import http.client
import json
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
import webbrowser

import pytest

from livemorebio import cli, security, transport


@pytest.fixture(autouse=True)
def technical_console_boundary(monkeypatch):
    from livemorebio.tests.stack_client_fixtures import install_stack_client_opener
    class TechnicalConsoleOpener:
        def open(self, request, **options):
            response = transport.authenticated_opener().open(request, **options)
            if not hasattr(response, "status"):
                response.status = 200
            return response
    install_stack_client_opener(monkeypatch, TechnicalConsoleOpener)


LAUNCHER_TOKEN = "technical-compose-launcher-bearer-not-real"
LAUNCHER_CODE = "technical_launcher_" + "A" * 23 + "Q"
MANUAL_CODE = "2345-6789-ABCD-EFGH"
LAUNCHER_ORIGIN = "http://127.0.0.1:19864"


@pytest.fixture(autouse=True)
def clear_console_peer_mode(monkeypatch):
    monkeypatch.delenv("LIVEMORE_CONSOLE_PEER", raising=False)


@pytest.fixture
def technical_launcher(monkeypatch, tmp_path):
    monkeypatch.setenv(security.TOKEN_ENV, LAUNCHER_TOKEN)
    monkeypatch.setattr(cli, "SERVICES", {"Aegle": ("technical", 19864)})
    monkeypatch.setattr(cli, "_health", lambda port: {"technical": port == 19864})
    monkeypatch.setattr(cli.R, "REG_DIR", str(tmp_path / "not-created-technical-data"))
    calls = []
    opened = []
    monkeypatch.setattr(webbrowser, "get", lambda: object())
    monkeypatch.setenv("DISPLAY", ":technical")
    monkeypatch.setattr(webbrowser, "open", lambda url: opened.append(url) or True)
    return calls, opened


class TechnicalErrorBody(BytesIO):
    def __init__(self, body):
        super().__init__(body)
        self.read_sizes = []

    def read(self, size=-1):
        self.read_sizes.append(size)
        return super().read(size)


def refuse_technical_mint(monkeypatch, calls, status, body):
    stream = TechnicalErrorBody(body)

    def open_request(self, request, *args, **kwargs):
        calls.append(request)
        raise urllib.error.HTTPError(
            request.full_url, status,
            "technical refusal " + LAUNCHER_TOKEN + " " + LAUNCHER_CODE,
            {}, stream,
        )

    monkeypatch.setattr(urllib.request.OpenerDirector, "open", open_request)
    return stream


@pytest.mark.parametrize("print_url", [False, True])
def test_console_launcher_names_peer_refusal_without_private_details(
    monkeypatch, capsys, technical_launcher, print_url
):
    calls, opened = technical_launcher
    body = json.dumps({
        "code": "CONSOLE_PEER_REFUSED",
        "error": "technical-private-diagnostic-not-for-output",
        "bearer": LAUNCHER_TOKEN,
        "exchange_code": LAUNCHER_CODE,
    }).encode("utf-8")
    stream = refuse_technical_mint(monkeypatch, calls, 403, body)

    assert cli.open_console(print_url=print_url) == 2

    captured = capsys.readouterr()
    output = captured.out + captured.err
    assert "refused [CONSOLE_PEER_REFUSED]" in output
    assert "Aegle" in output and "container" in output
    assert "LIVEMORE_CONSOLE_PEER" in output and "livemore up" in output
    assert "without" in output and "bridge gateway" in output
    assert "WSL2" in output and "Linux proxy" in output
    assert "launch guide" in output.lower() and "section 10" in output
    if print_url:
        assert captured.out == ""
    assert "Console authorization failed" not in output
    assert LAUNCHER_TOKEN not in output and LAUNCHER_CODE not in output
    assert "technical-private-diagnostic-not-for-output" not in output
    assert len(calls) == 1 and opened == []
    assert len(stream.read_sizes) == 1
    assert 0 < stream.read_sizes[0] <= 4096


@pytest.mark.parametrize("print_url", [False, True])
@pytest.mark.parametrize("status,body", [
    pytest.param(401, b'{"code":"CONSOLE_PEER_REFUSED"}', id="401-is-generic"),
    pytest.param(403, b'{}', id="403-without-code"),
    pytest.param(403, b'{"code":"TECHNICAL_OTHER"}', id="403-other-code"),
    pytest.param(403, b'{"code":"CONSOLE_PEER_REFUSED', id="malformed-json"),
    pytest.param(403, b'[]', id="json-array"),
    pytest.param(403, b'null', id="json-null"),
    pytest.param(403, b'"CONSOLE_PEER_REFUSED"', id="json-string"),
    pytest.param(403, b'1', id="json-number"),
    pytest.param(403, b'true', id="json-boolean"),
    pytest.param(
        403,
        b'{"padding":"' + b'x' * 4096 + b'","code":"CONSOLE_PEER_REFUSED"}',
        id="code-beyond-read-limit",
    ),
])
def test_console_launcher_other_refusals_keep_generic_message(
    monkeypatch, capsys, technical_launcher, status, body, print_url
):
    calls, opened = technical_launcher
    refuse_technical_mint(monkeypatch, calls, status, body)

    assert cli.open_console(print_url=print_url) == 1

    captured = capsys.readouterr()
    output = captured.out + captured.err
    assert output.splitlines() == [
        "  refused [CONSOLE_CODE_UNAVAILABLE]",
        "  Console authorization failed. Check the operator token and restart Aegle."
    ]
    assert LAUNCHER_TOKEN not in output and LAUNCHER_CODE not in output
    assert len(calls) == 1 and opened == []
    if print_url:
        assert captured.out == ""


def test_open_print_url_mints_without_opening_browser(
    monkeypatch, capsys, technical_launcher
):
    calls, opened = technical_launcher

    def open_request(self, request, *args, **kwargs):
        calls.append(request)
        return BytesIO(json.dumps({"code": MANUAL_CODE, "expires_in": 45}).encode("utf-8"))

    monkeypatch.setattr(urllib.request.OpenerDirector, "open", open_request)
    monkeypatch.setattr(sys, "argv", ["livemore", "open", "--print-url"])

    with pytest.raises(SystemExit) as stopped:
        cli.main()
    assert stopped.value.code == 0

    output = capsys.readouterr().out
    lines = output.splitlines()
    assert len(lines) == 3
    assert lines[0] == LAUNCHER_ORIGIN + "/console/connect"
    assert lines[1] == "One-time code: " + MANUAL_CODE
    assert "once" in lines[2].lower() and "45 seconds" in lines[2]
    assert output.count(MANUAL_CODE) == 1 and LAUNCHER_TOKEN not in output
    assert LAUNCHER_CODE not in output
    assert len(calls) == 1 and opened == []
    assert calls[0].full_url == LAUNCHER_ORIGIN + "/api/session/pair-code"
    assert calls[0].get_method() == "POST"
    assert calls[0].get_header("Authorization") == "Bearer " + LAUNCHER_TOKEN


def test_open_print_url_help_names_container_machine_view(monkeypatch, capsys):
    monkeypatch.setattr(sys, "argv", ["livemore", "open", "--help"])

    with pytest.raises(SystemExit) as stopped:
        cli.main()

    assert stopped.value.code == 0
    output = " ".join(capsys.readouterr().out.split())
    assert "--print-url" in output
    assert "print the connection page URL and separate one-time code instead of opening a browser" in output
    assert (
        "for a browser on another machine, e.g. Windows with Docker Desktop: "
        "run inside the aegle container"
    ) in output


def test_successful_compose_up_names_authenticated_console_launcher(
    monkeypatch, capsys, technical_launcher, tmp_path
):
    commands = []
    preparations = []
    package_dir = tmp_path / "technical-package"
    package_dir.mkdir()
    monkeypatch.setattr(cli, "__file__", str(package_dir / "cli.py"))
    (tmp_path / "docker-compose.yml").write_text("services: {}\n", encoding="utf-8")
    monkeypatch.setattr(shutil, "which", lambda name: "/technical/docker" if name == "docker" else None)
    monkeypatch.setattr(subprocess, "call", lambda command, **options: commands.append(command) or 0)
    monkeypatch.setattr(cli, "ensure_api_token", lambda: preparations.append("token") or LAUNCHER_TOKEN)
    monkeypatch.setattr(security, "refuse_linked_secrets", lambda path: preparations.append("secrets"))
    monkeypatch.setattr(security, "ensure_patch_security_keys", lambda: preparations.append("keys"))
    monkeypatch.setattr(cli, "_wait_for_services", lambda names, **options: [])

    assert cli._compose("up") == 0

    output = capsys.readouterr().out
    assert output.splitlines()[-1].strip() == "Console: run `livemore open` (a bare URL has no session)"
    assert len(commands) == 1
    assert commands[0] == [
        "docker", "compose", "-f", str(tmp_path / "docker-compose.yml"),
        "up", "-d", "--build",
    ]
    assert preparations == ["secrets", "token", "keys"]
    assert LAUNCHER_TOKEN not in output and LAUNCHER_CODE not in output


@pytest.mark.parametrize("print_url", [False, True])
@pytest.mark.parametrize("path", ["403-body", "200-body"])
def test_console_launcher_incomplete_body_is_generic(
    monkeypatch, capsys, technical_launcher, print_url, path
):
    calls, opened = technical_launcher

    class TechnicalIncompleteBody(BytesIO):
        def read(self, size=-1):
            raise http.client.IncompleteRead(b"")

    def open_request(self, request, *args, **kwargs):
        calls.append(request)
        response = TechnicalIncompleteBody()
        if path == "403-body":
            raise urllib.error.HTTPError(request.full_url, 403, LAUNCHER_TOKEN, {}, response)
        return response

    monkeypatch.setattr(urllib.request.OpenerDirector, "open", open_request)
    assert cli.open_console(print_url=print_url) == 1
    captured = capsys.readouterr()
    assert (captured.out + captured.err).splitlines() == [
        "  refused [CONSOLE_CODE_UNAVAILABLE]",
        "  Console authorization failed. Check the operator token and restart Aegle."
    ]
    assert LAUNCHER_TOKEN not in captured.out + captured.err
    assert LAUNCHER_CODE not in captured.out + captured.err
    assert len(calls) == 1 and opened == []
    if print_url:
        assert captured.out == ""


@pytest.mark.parametrize("print_url", [False, True])
@pytest.mark.parametrize("failure", ["url-error", "timeout", "missing-code", "not-json"])
def test_console_launcher_non_http_failures_never_disclose_credentials(
    monkeypatch, capsys, technical_launcher, print_url, failure
):
    calls, opened = technical_launcher

    def open_request(self, request, *args, **kwargs):
        calls.append(request)
        if failure == "url-error":
            raise urllib.error.URLError(LAUNCHER_TOKEN + " " + LAUNCHER_CODE)
        if failure == "timeout":
            raise TimeoutError(LAUNCHER_TOKEN + " " + LAUNCHER_CODE)
        return BytesIO(b'{"expires_in":120}' if failure == "missing-code" else b'not json')

    monkeypatch.setattr(urllib.request.OpenerDirector, "open", open_request)
    assert cli.open_console(print_url=print_url) == 1
    captured = capsys.readouterr()
    output = captured.out + captured.err
    assert output.splitlines() == [
        "  refused [CONSOLE_CODE_UNAVAILABLE]",
        "  Console authorization failed. Check the operator token and restart Aegle."
    ]
    assert LAUNCHER_TOKEN not in output and LAUNCHER_CODE not in output
    assert len(calls) == 1 and opened == []
    if print_url:
        assert captured.out == ""


@pytest.mark.parametrize("print_url", [False, True])
@pytest.mark.parametrize("payload", [
    [1, 2], "technical", 5, None, {"code": None}, {"code": 7},
    {"code": False}, {"code": []}, {"code": {}}, {"code": ""},
])
def test_console_launcher_invalid_success_payload_is_generic(
    monkeypatch, capsys, technical_launcher, print_url, payload
):
    calls, opened = technical_launcher

    def open_request(self, request, *args, **kwargs):
        calls.append(request)
        return BytesIO(json.dumps(payload).encode("utf-8"))

    monkeypatch.setattr(urllib.request.OpenerDirector, "open", open_request)
    assert cli.open_console(print_url=print_url) == 1
    captured = capsys.readouterr()
    assert (captured.out + captured.err).splitlines() == [
        "  refused [CONSOLE_CODE_UNAVAILABLE]",
        "  Console authorization failed. Check the operator token and restart Aegle."
    ]
    assert len(calls) == 1 and opened == []
    assert "exchange?code=" not in captured.out + captured.err
    if print_url:
        assert captured.out == ""


@pytest.mark.parametrize("expires_in", [None, 0, -1, 121, 1000000, "30", 3.5, True, False])
def test_open_print_url_invalid_lifetime_is_refused(
    monkeypatch, capsys, technical_launcher, expires_in
):
    calls, opened = technical_launcher

    def open_request(self, request, *args, **kwargs):
        calls.append(request)
        return BytesIO(json.dumps({"code": MANUAL_CODE, "expires_in": expires_in}).encode("utf-8"))

    monkeypatch.setattr(urllib.request.OpenerDirector, "open", open_request)
    assert cli.open_console(print_url=True) == 1
    captured = capsys.readouterr()
    assert captured.out == ""
    assert "CONSOLE_CODE_UNAVAILABLE" in captured.err
    assert len(calls) == 1 and opened == []


def test_open_print_url_missing_lifetime_is_refused(
    monkeypatch, capsys, technical_launcher
):
    monkeypatch.setattr(security, "SESSION_CODE_TTL", 73)
    monkeypatch.setattr(
        urllib.request.OpenerDirector, "open",
        lambda *args, **kwargs: BytesIO(json.dumps({"code": MANUAL_CODE}).encode("utf-8")),
    )
    assert cli.open_console(print_url=True) == 1
    captured = capsys.readouterr()
    assert captured.out == "" and "CONSOLE_CODE_UNAVAILABLE" in captured.err


@pytest.mark.parametrize("print_url", [False, True])
def test_open_unavailable_names_native_and_compose_remedies(
    monkeypatch, capsys, technical_launcher, print_url
):
    calls, opened = technical_launcher
    monkeypatch.setattr(cli, "_health", lambda port: None)
    monkeypatch.setattr(sys, "argv", ["livemore", "open"] + (["--print-url"] if print_url else []))
    with pytest.raises(SystemExit) as stopped:
        cli.main()
    assert stopped.value.code == 1
    captured = capsys.readouterr()
    output = captured.out + captured.err
    assert "Aegle is not running" in output
    assert "livemore start Aegle" in output
    # The supported wrapper supplies interpolation values and selects its own project.
    assert "`livemore logs aegle`" in output
    assert "docker compose" not in output
    assert "CONSOLE_PEER_UNRESOLVED" in output
    assert LAUNCHER_TOKEN not in output and LAUNCHER_CODE not in output
    assert calls == [] and opened == []
    if print_url:
        assert captured.out == ""


@pytest.mark.parametrize("browser_failure", [False, "os-error", "browser-error"])
def test_open_without_browser_fails_without_disclosing_code(
    monkeypatch, capsys, technical_launcher, browser_failure
):
    calls, opened = technical_launcher

    def open_request(self, request, *args, **kwargs):
        calls.append(request)
        return BytesIO(json.dumps({"code": LAUNCHER_CODE, "expires_in": 120}).encode("utf-8"))

    def open_browser(url):
        opened.append(url)
        if browser_failure == "os-error":
            raise OSError(LAUNCHER_TOKEN + " " + LAUNCHER_CODE)
        if browser_failure == "browser-error":
            raise webbrowser.Error(LAUNCHER_TOKEN + " " + LAUNCHER_CODE)
        return False

    monkeypatch.setattr(urllib.request.OpenerDirector, "open", open_request)
    monkeypatch.setattr(webbrowser, "open", open_browser)
    monkeypatch.setattr(sys, "argv", ["livemore", "open"])
    with pytest.raises(SystemExit) as stopped:
        cli.main()
    assert stopped.value.code != 0
    output = capsys.readouterr().out
    assert "opened" not in output.replace("could be opened", "")
    assert "CONSOLE_EXCHANGE_FAILED" in output
    assert "livemore open --print-url" in output and "connection page and separate one-time code" in output
    assert LAUNCHER_TOKEN not in output and LAUNCHER_CODE not in output
    assert len(calls) == 1 and len(opened) == 1


def test_open_successful_browser_returns_zero(monkeypatch, capsys, technical_launcher):
    calls, opened = technical_launcher
    monkeypatch.setattr(
        urllib.request.OpenerDirector, "open",
        lambda *args, **kwargs: BytesIO(json.dumps({"code": LAUNCHER_CODE, "expires_in": 120}).encode("utf-8")),
    )
    monkeypatch.setattr(sys, "argv", ["livemore", "open"])
    with pytest.raises(SystemExit) as stopped:
        cli.main()
    assert stopped.value.code == 0
    output = capsys.readouterr().out
    assert "launch requested in your browser" in output
    assert len(opened) == 1 and opened[0].startswith("file://")
    assert LAUNCHER_CODE not in opened[0]
    from pathlib import Path
    from urllib.parse import unquote, urlsplit
    assert LAUNCHER_CODE in Path(unquote(urlsplit(opened[0]).path)).read_text(encoding="utf-8")


def test_main_help_describes_open(monkeypatch, capsys):
    monkeypatch.setattr(sys, "argv", ["livemore", "--help"])
    with pytest.raises(SystemExit) as stopped:
        cli.main()
    assert stopped.value.code == 0
    output = " ".join(capsys.readouterr().out.split())
    assert "open open the authenticated Aegle console" in output


def test_compose_up_unhealthy_aegle_reports_logs_without_console_success(
    monkeypatch, capsys, technical_launcher, tmp_path
):
    package_dir = tmp_path / "technical-package"
    package_dir.mkdir()
    monkeypatch.setattr(cli, "__file__", str(package_dir / "cli.py"))
    (tmp_path / "docker-compose.yml").write_text("services: {}\n", encoding="utf-8")
    monkeypatch.setattr(shutil, "which", lambda name: "/technical/docker")
    monkeypatch.setattr(subprocess, "call", lambda command, **options: 0)
    monkeypatch.setattr(cli, "ensure_api_token", lambda: LAUNCHER_TOKEN)
    monkeypatch.setattr(security, "refuse_linked_secrets", lambda path: None)
    monkeypatch.setattr(security, "ensure_patch_security_keys", lambda: None)
    monkeypatch.setattr(cli, "_health", lambda port: None)
    waited = []
    monkeypatch.setattr(cli, "_wait_for_services",
                        lambda names, **options: waited.append((names, options)) or ["Aegle"])

    assert cli._compose("up") == 1

    output = capsys.readouterr().out
    assert "Aegle did not prove readiness" in output
    assert "`livemore logs`" in output
    assert "docker compose" not in output.splitlines()[-1]
    assert "Console:" not in output
    # A container's first start is slower than a native one: the wait is longer than the native 15 s.
    assert waited == [(["Aegle"], {"timeout": 120.0})]
