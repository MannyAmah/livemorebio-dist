"""Mounted actual banner handler; no browser/layout engine or clinical execution.

Regression: root inspected twelve uofz7at2 screenshots and found the legacy
fixed banner covering navigation. See legacy-preview-actual-recovery-acceptance.md.
"""
import json
import re

import pytest

from .test_clinical_model_availability_ui import CONSOLE, node


def source():
    return (CONSOLE / 'index.html').read_text(encoding="utf-8")


def banner_markup():
    match=re.search(r'<div\s+([^>]*\bid="__banner"[^>]*)>',source())
    return match


def mounted(checks):
    html=source();match=banner_markup()
    attributes=dict(re.findall(r'([\w-]+)="([^"]*)"',match[1])) if match else {}
    script=html[html.index('function showBanner('):html.index('\nlet legacyPreviewRecovery=')]
    node("const a=require('node:assert/strict'),vm=require('node:vm');\n"+r"""
let appended=0,created=0;const nodes=new Map(),focus={id:'shared-nav-link'},originalState=Object.freeze({id:'unchanged'});
function element(attrs={}){return{attrs:{...attrs},dataset:{},style:{},hidden:!!HIDDEN,textContent:'',
 get id(){return this.attrs.id},set id(value){this.attrs.id=value;nodes.set(value,this)},
 setAttribute(key,value){this.attrs[key]=value},getAttribute(key){return this.attrs[key]??null},
 set innerHTML(value){throw Error('HTML injection')},focus(){throw Error('Focus stolen')}}}
if(PRESENT){const banner=element(ATTRIBUTES);nodes.set('__banner',banner)}
const document={activeElement:focus,getElementById:id=>nodes.get(id)||null,
 createElement:()=>{created++;return element()},body:{appendChild:child=>{appended++;nodes.set(child.id,child)}}};
const context={document,S:originalState};vm.runInNewContext(SCRIPT,context);
""".replace('HIDDEN',json.dumps(bool(match and re.search(r'\bhidden\b',match[1]))))
        .replace('PRESENT',json.dumps(match is not None)).replace('ATTRIBUTES',json.dumps(attributes))
        .replace('SCRIPT',json.dumps(script))+checks)


def test_banner_has_one_preexisting_accessible_region_before_recovery_controls():
    html=source();match=banner_markup()
    assert match is not None
    assert html.count('id="__banner"')==1
    assert 'hidden' in match[1] and 'role="status"' in match[1]
    assert 'aria-live="polite"' in match[1] and 'aria-atomic="true"' in match[1]
    assert html.index('<div class="top">')<match.start()<html.index('<section class="grp" aria-label="Research preview status">')
    # Actual shell prepends navigation; the banner is not mounted over/inside it.
    assert 'document.body.prepend(nav)' in (CONSOLE/'lib/shell.js').read_text(encoding="utf-8")


def test_banner_style_wraps_in_normal_flow_without_overlay_or_viewport_width():
    css=re.search(r'\.legacy-banner\s*\{([^}]+)\}',source())
    assert css is not None
    declarations={key.strip():value.strip() for key,value in re.findall(r'([\w-]+)\s*:\s*([^;]+)',css[1])}
    assert declarations['position']=='static'
    assert declarations['overflow-wrap']=='anywhere'
    assert not {'z-index','top','left','right','width','height','max-height'} & declarations.keys()
    assert re.search(r'\.legacy-banner\[hidden\]\s*\{\s*display\s*:\s*none\s*;?\s*\}',source())


@pytest.mark.parametrize('kind,role,live', [('info','status','polite'),('err','alert','assertive'),(None,'status','polite')])
def test_actual_handler_reuses_region_preserves_message_and_does_not_steal_focus(kind,role,live):
    mounted("""
const message='<b>AUTHORED UI ONLY</b> '+ 'unbroken'.repeat(100);
context.showBanner(message,KIND);const b=nodes.get('__banner');
a.equal(b.textContent,message);a.equal(b.hidden,false);
a.equal(b.getAttribute('role'),ROLE);a.equal(b.getAttribute('aria-live'),LIVE);a.equal(b.getAttribute('aria-atomic'),'true');
a.equal(b.dataset.kind,KIND==='err'?'err':'info');a.equal(created,0);a.equal(appended,0);
a.equal(document.activeElement,focus);a.equal(context.S,originalState);a.equal(b.style.cssText,undefined);
""".replace('KIND',json.dumps(kind)).replace('ROLE',json.dumps(role)).replace('LIVE',json.dumps(live)))


def test_actual_handler_clears_old_error_and_reopens_same_info_region():
    mounted("""
context.showBanner('AUTHORED error','err');const b=nodes.get('__banner');
context.showBanner('',null);a.equal(nodes.get('__banner'),b);a.equal(b.hidden,true);a.equal(b.textContent,'');
context.showBanner('AUTHORED current information','info');a.equal(nodes.get('__banner'),b);
a.equal(b.hidden,false);a.equal(b.textContent,'AUTHORED current information');a.equal(b.dataset.kind,'info');
a.equal(b.getAttribute('role'),'status');a.equal(b.getAttribute('aria-live'),'polite');
a.equal(document.activeElement,focus);a.equal(context.S,originalState);a.equal(created,0);a.equal(appended,0);
""")


def test_cardiac_headings_do_not_claim_a_trace_before_a_current_read():
    html=source()
    for target,label in [('legacy-cardiac-state','No current trace'),
                         ('legacy-cardiac-provenance','unavailable'),
                         ('legacy-cardiac-time','no current trace')]:
        matches=re.findall(r'<span\b[^>]*id="'+target+r'"[^>]*>([^<]+)</span>',html)
        assert matches==[label]
    assert 'reacting live</span>' not in html
    assert 'one beat, live)' not in html
