"""Technical HTTP receipts only; never download geometry or construct a twin."""
from copy import deepcopy
import json
from types import SimpleNamespace
import urllib.error

import pytest

from livemorebio.tests.stack_client_fixtures import install_stack_client_opener

from livemorebio.sdk import Platform

SOURCE = "bp3d-4.0-20130619-surface-core-v1"
DIGEST = "a" * 64
MISSING = {"schema": "livemore.atlas-reference-status.v1", "source_id": SOURCE,
           "state": "missing", "available": False, "manifest_sha256": None,
           "manifest": None, "reason": "Technical fixture", "reference_geometry": True,
           "patient_registered": False}
AVAILABLE = {**MISSING, "state": "available", "available": True, "manifest_sha256": DIGEST,
             "manifest": {"schema": "livemore.atlas-reference.v1", "source_id": SOURCE,
                          "patient_registered": False, "evidence_state": "REFERENCE_ONLY"}}
INSTALLED = {**AVAILABLE, "reused": False, "receipt": {
    "receipt_id": "b" * 32, "source_id": SOURCE, "manifest_sha256": DIGEST,
    "started_at": "2026-09-08T01:00:00+00:00", "completed_at": "2026-09-08T01:00:03+00:00"}}


def transport(monkeypatch, result=None, *, status=200, raw=None, close_failure=False):
    from livemorebio import atlas_client
    platform = Platform(mode="attach")
    monkeypatch.setattr(platform, "_url", lambda: "http://127.0.0.1:9999")
    monkeypatch.setattr("livemorebio.security.authorization_headers",
                        lambda: {"Authorization": "Bearer technical-private-token"})
    calls = []
    read_sizes = []
    def read(limit):
        read_sizes.append(limit)
        return raw if raw is not None else json.dumps(result or MISSING).encode()
    def close():
        if close_failure:
            raise OSError("PRIVATE cleanup")
    response = SimpleNamespace(status=status, headers={"X-Livemore-Request-Id": "c" * 32,
        "X-Livemore-Source-Sha256": "d" * 64,
        "X-Livemore-Process-Instance": "11111111-2222-3333-4444-555555555555"}, read=read, close=close)
    def opener(*handlers):
        def open_request(request, timeout):
            calls.append((request, timeout))
            return response
        return SimpleNamespace(open=open_request)
    install_stack_client_opener(monkeypatch, opener)
    return platform, response, calls, read_sizes


@pytest.mark.parametrize("install", [False, True])
def test_exact_attached_request_and_safe_build_metadata(monkeypatch, install):
    from livemorebio.atlas_client import MAX_RESPONSE_BYTES
    expected = INSTALLED if install else MISSING
    platform, response, calls, sizes = transport(monkeypatch, expected)
    result = platform.install_atlas_reference(SOURCE) if install else platform.atlas_reference_status()
    assert result == expected and len(calls) == 1
    request, timeout = calls[0]
    assert request.full_url == "http://127.0.0.1:9999/api/anatomy/atlas-reference" + ("/install" if install else "")
    assert request.method == ("POST" if install else "GET")
    assert request.data == (json.dumps({"source_id": SOURCE}, separators=(",", ":")).encode() if install else None)
    assert request.get_header("Authorization") == "Bearer technical-private-token"
    assert request.get_header("Accept-encoding") == "identity"
    assert timeout == (900 if install else 20) and sizes == [MAX_RESPONSE_BYTES + 1]
    assert platform.last_atlas_response == {"request_id": "c" * 32, "source_sha256": "d" * 64,
        "process_instance": "11111111-2222-3333-4444-555555555555"}


@pytest.mark.parametrize("source", [None, True, 1, "", "PRIVATE", SOURCE + " ", SOURCE.upper()])
def test_invalid_source_rejected_before_transport(monkeypatch, source):
    from livemorebio.atlas_client import AtlasClientError
    platform, _, calls, _ = transport(monkeypatch)
    with pytest.raises(AtlasClientError) as caught:
        platform.install_atlas_reference(source)
    assert caught.value.code == "ATLAS_CLIENT_INVALID" and not calls
    assert "PRIVATE" not in str(caught.value)


@pytest.mark.parametrize("url", ["http://example.com", "file:///PRIVATE", "http://a:PRIVATE@127.0.0.1",
    "http://127.0.0.1?PRIVATE", "http://127.0.0.1#PRIVATE", " http://127.0.0.1", "http://127.0.0.1:bad",
    "http://127.0.0.1/\nPRIVATE", "http://@127.0.0.1"])
def test_unsafe_endpoint_rejected_without_dispatch(monkeypatch, url):
    from livemorebio.atlas_client import AtlasClientError
    platform, _, calls, _ = transport(monkeypatch)
    monkeypatch.setattr(platform, "_url", lambda: url)
    with pytest.raises(AtlasClientError) as caught:
        platform.install_atlas_reference(SOURCE)
    assert caught.value.code == "ATLAS_CLIENT_INVALID" and not calls
    assert "PRIVATE" not in str(caught.value)


def test_inprocess_rejects_without_additional_construction_or_transport(monkeypatch):
    from livemorebio.atlas_client import AtlasClientError
    platform = Platform.__new__(Platform)
    platform.mode = "inprocess"
    monkeypatch.setattr(platform, "_url", lambda: pytest.fail("inprocess reached URL selection"))
    for call in (platform.atlas_reference_status, lambda: platform.install_atlas_reference(SOURCE)):
        with pytest.raises(AtlasClientError, match="attached"):
            call()


@pytest.mark.parametrize("change", [
    {"schema": "PRIVATE"}, {"source_id": "foreign"}, {"state": "ready"}, {"available": 1},
    {"reference_geometry": 1}, {"patient_registered": 0}, {"patient_registered": True},
    {"manifest_sha256": True}, {"manifest_sha256": "PRIVATE"}, {"manifest": None},
    {"manifest": {**AVAILABLE["manifest"], "source_id": "foreign"}},
    {"manifest": {**AVAILABLE["manifest"], "patient_registered": 0}},
    {"manifest": {**AVAILABLE["manifest"], "evidence_state": "VALIDATED"}},
])
@pytest.mark.parametrize("install", [False, True])
def test_response_identity_and_evidence_do_not_accept_aliases(monkeypatch, change, install):
    from livemorebio.atlas_client import AtlasClientError
    platform, _, calls, _ = transport(monkeypatch, {**(INSTALLED if install else AVAILABLE), **change})
    with pytest.raises(AtlasClientError) as caught:
        platform.install_atlas_reference(SOURCE) if install else platform.atlas_reference_status()
    assert caught.value.code == ("ATLAS_CLIENT_UNCONFIRMED" if install else "ATLAS_CLIENT_RESPONSE")
    assert len(calls) == 1 and "PRIVATE" not in str(caught.value)


@pytest.mark.parametrize("state", ["missing", "acquiring", "corrupt", "unsafe_cache", "unsupported_converter"])
def test_nonavailable_is_valid_status_but_never_install_confirmation(monkeypatch, state):
    from livemorebio.atlas_client import AtlasClientError
    platform, _, _, _ = transport(monkeypatch, {**MISSING, "state": state})
    assert platform.atlas_reference_status()["state"] == state
    with pytest.raises(AtlasClientError) as caught:
        platform.install_atlas_reference(SOURCE)
    assert caught.value.code == "ATLAS_CLIENT_UNCONFIRMED"


@pytest.mark.parametrize("field", ["manifest", "manifest_sha256"])
def test_missing_status_fields_are_not_inferred_as_explicit_null(monkeypatch, field):
    from livemorebio.atlas_client import AtlasClientError
    result = dict(MISSING)
    del result[field]
    platform, _, _, _ = transport(monkeypatch, result)
    with pytest.raises(AtlasClientError) as caught:
        platform.atlas_reference_status()
    assert caught.value.code == "ATLAS_CLIENT_RESPONSE"


@pytest.mark.parametrize("change", [{"receipt_id": True}, {"receipt_id": "x" * 32}, {"source_id": "foreign"},
    {"manifest_sha256": "f" * 64}, {"started_at": None}, {"started_at": "2026-09-08T01:00:00"},
    {"completed_at": "2026-09-08T00:00:00Z"}, {"completed_at": "PRIVATE"}, {"extra": 1}])
def test_install_receipt_is_complete_typed_and_matches_manifest(monkeypatch, change):
    from livemorebio.atlas_client import AtlasClientError
    result = deepcopy(INSTALLED)
    result["receipt"].update(change)
    platform, _, _, _ = transport(monkeypatch, result)
    with pytest.raises(AtlasClientError) as caught:
        platform.install_atlas_reference(SOURCE)
    assert caught.value.code == "ATLAS_CLIENT_UNCONFIRMED"


@pytest.mark.parametrize("change", [{"receipt": None}, {"receipt": {}}, {"reused": 1}, {"reused": None}])
def test_install_rejects_incomplete_confirmation(monkeypatch, change):
    from livemorebio.atlas_client import AtlasClientError
    platform, _, _, _ = transport(monkeypatch, {**INSTALLED, **change})
    with pytest.raises(AtlasClientError) as caught:
        platform.install_atlas_reference(SOURCE)
    assert caught.value.code == "ATLAS_CLIENT_UNCONFIRMED"


@pytest.mark.parametrize("status", [200, 302, 401, 503])
@pytest.mark.parametrize("raw", [b'[]', b'{"receipt":{},"receipt":{}}', b'{"n":NaN}', b'{"code":"PRIVATE"}', b'PRIVATE'])
def test_all_malformed_post_dispatch_responses_remain_unconfirmed(monkeypatch, status, raw):
    from livemorebio.atlas_client import AtlasClientError
    platform, _, calls, _ = transport(monkeypatch, status=status, raw=raw)
    with pytest.raises(AtlasClientError) as caught:
        platform.install_atlas_reference(SOURCE)
    assert caught.value.code == "ATLAS_CLIENT_UNCONFIRMED" and len(calls) == 1
    assert caught.value.request_id == "c" * 32 and "PRIVATE" not in str(caught.value)


@pytest.mark.parametrize("kind", ["oversize", "encoding", "read", "timeout"])
def test_unconfirmed_body_and_transport_are_bounded_and_never_retried(monkeypatch, kind):
    from livemorebio import atlas_client
    platform, response, calls, _ = transport(monkeypatch, INSTALLED)
    if kind == "oversize":
        response.read = lambda n: b'x' * (atlas_client.MAX_RESPONSE_BYTES + 1)
    elif kind == "encoding":
        response.headers["Content-Encoding"] = "gzip"
    elif kind == "read":
        def failed(n):
            raise OSError("PRIVATE read")
        response.read = failed
    else:
        def failed(*a, **kw):
            calls.append(1)
            raise TimeoutError("PRIVATE timeout")
        install_stack_client_opener(monkeypatch, lambda *a: SimpleNamespace(open=failed))
    with pytest.raises(atlas_client.AtlasClientError) as caught:
        platform.install_atlas_reference(SOURCE)
    assert caught.value.code == "ATLAS_CLIENT_UNCONFIRMED" and len(calls) == 1
    assert "PRIVATE" not in str(caught.value)


@pytest.mark.parametrize("code,status", [("ATLAS_ACQUIRING", 409), ("ATLAS_INVALID_REQUEST", 422),
    ("ATLAS_SOURCE_INTEGRITY", 503), ("ATLAS_PUBLICATION_UNCONFIRMED", 503)])
def test_known_server_errors_keep_safe_category_even_if_close_fails(monkeypatch, code, status):
    from livemorebio.atlas_client import AtlasClientError
    platform, _, _, _ = transport(monkeypatch, status=status,
        raw=json.dumps({"code": code, "error": "PRIVATE path/token"}).encode(), close_failure=True)
    with pytest.raises(AtlasClientError) as caught:
        platform.install_atlas_reference(SOURCE)
    assert caught.value.code == code and caught.value.request_id == "c" * 32
    assert "PRIVATE" not in str(caught.value)
    assert platform.last_atlas_response["cleanup_code"] == "ATLAS_CLIENT_TRANSPORT"
    if code == "ATLAS_PUBLICATION_UNCONFIRMED":
        assert "inspect" in str(caught.value).lower()


def test_confirmed_receipt_survives_close_failure(monkeypatch):
    platform, _, _, _ = transport(monkeypatch, INSTALLED, close_failure=True)
    assert platform.install_atlas_reference(SOURCE) == INSTALLED
    assert platform.last_atlas_response["cleanup_code"] == "ATLAS_CLIENT_TRANSPORT"


def test_auth_failure_before_dispatch_is_not_mutation_uncertainty(monkeypatch):
    from livemorebio.atlas_client import AtlasClientError
    platform, _, calls, _ = transport(monkeypatch)
    def fail():
        raise RuntimeError("PRIVATE credentials")
    monkeypatch.setattr("livemorebio.security.authorization_headers", fail)
    with pytest.raises(AtlasClientError) as caught:
        platform.install_atlas_reference(SOURCE)
    assert caught.value.code == "ATLAS_CLIENT_AUTH_REQUIRED" and not calls


def test_unknown_error_category_is_not_safe_determinate_rejection(monkeypatch):
    from livemorebio.atlas_client import AtlasClientError
    platform, _, _, _ = transport(monkeypatch, status=503, raw=b'{"code":"ATLAS_UNAVAILABLE"}')
    with pytest.raises(AtlasClientError) as caught:
        platform.install_atlas_reference(SOURCE)
    assert caught.value.code == "ATLAS_CLIENT_UNCONFIRMED"


def test_http_error_body_is_read_once_and_stale_metadata_is_cleared(monkeypatch):
    from livemorebio import atlas_client
    platform, _, calls, _ = transport(monkeypatch)
    platform.last_atlas_response = {"request_id": "e" * 32}
    import io
    def failed(*a, **kw):
        calls.append(1)
        raise urllib.error.HTTPError("http://127.0.0.1", 409, "PRIVATE",
            {}, io.BytesIO(b'{"code":"ATLAS_ACQUIRING"}'))
    install_stack_client_opener(monkeypatch, lambda *a: SimpleNamespace(open=failed))
    with pytest.raises(atlas_client.AtlasClientError) as caught:
        platform.install_atlas_reference(SOURCE)
    assert caught.value.code == "ATLAS_ACQUIRING" and caught.value.request_id is None
    assert platform.last_atlas_response == {} and len(calls) == 1
