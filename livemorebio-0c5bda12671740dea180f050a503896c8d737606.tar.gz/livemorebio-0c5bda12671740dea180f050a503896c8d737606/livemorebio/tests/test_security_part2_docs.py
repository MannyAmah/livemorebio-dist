"""API-2: technical documentation fixtures; no services or network connections."""
from html.parser import HTMLParser
from urllib.parse import urlsplit
import importlib
import re

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from livemorebio.security import install_mutation_auth


class Assets(HTMLParser):
    def __init__(self):
        super().__init__()
        self.assets = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'script' or (tag == 'link' and attrs.get('rel') == 'stylesheet'):
            self.assets.append(attrs)


@pytest.mark.parametrize('module', ['livemorebio.aegle.server', 'livemorebio.life_system.service', 'livemorebio.cendos.service'])
@pytest.mark.parametrize('path', ['/docs', '/redoc'])
def test_API_2_docs_disabled_by_default(monkeypatch, module, path):
    monkeypatch.delenv('LIVEMORE_ENABLE_API_DOCS', raising=False)
    app = importlib.import_module(module).app
    response = TestClient(app, base_url='http://127.0.0.1:19866').get(path)
    assert response.status_code == 404


def docs_app(monkeypatch, setting):
    monkeypatch.setenv('LIVEMORE_ENABLE_API_DOCS', setting)
    app = FastAPI(title='Technical API fixture', docs_url=None, redoc_url=None)
    install_mutation_auth(app)

    @app.get('/technical', summary='Technical operation <untrusted>')
    def technical():
        return {'technical': True}
    return app


@pytest.mark.parametrize('path', ['/docs', '/redoc'])
def test_API_2_enabled_docs_only_load_local_or_integrity_pinned_assets(monkeypatch, path):
    client = TestClient(docs_app(monkeypatch, '1'), base_url='http://127.0.0.1:19866')
    response = client.get(path)
    assert response.status_code == 200
    assert '/technical' in response.text
    assert '<untrusted>' not in response.text
    parser = Assets()
    parser.feed(response.text)
    assert parser.assets, 'Documentation must include its locally served styles.'
    for asset in parser.assets:
        target = asset.get('src') or asset.get('href')
        assert target, 'Inline scripts are not a pinned/local documentation asset.'
        parts = urlsplit(target)
        if not parts.netloc and not parts.scheme and target.startswith('/'):
            assert client.get(target).status_code == 200
        else:
            assert re.search(r'@\d+\.\d+\.\d+(?:/|$)', target)
            assert re.fullmatch(r'sha(?:256|384|512)-[A-Za-z0-9+/]+=*', asset.get('integrity', ''))


@pytest.mark.parametrize('setting', ['', '0', 'true', 'yes'])
def test_API_2_docs_require_exact_opt_in(monkeypatch, setting):
    client = TestClient(docs_app(monkeypatch, setting), base_url='http://127.0.0.1:19866')
    assert client.get('/docs').status_code == 404
    assert client.get('/redoc').status_code == 404
