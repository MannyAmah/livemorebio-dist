"""Immutable public coordinates, not biological execution or human equivalence."""
from __future__ import annotations

import hashlib
import importlib
from pathlib import Path
import tomllib
import zipfile

import pytest


def reference():
    return importlib.import_module("livemorebio.molecular_reference")


@pytest.mark.parametrize("target,pdb,accession", [
    ("KRAS", "4OBE", "P01116"), ("TP53", "1TUP", "P04637"),
    ("EGFR", "1M17", "P00533"), ("LDLR", "1N7D", "P01130"),
    ("PXR", "6P2B", "O75469"), ("NR1I2", "6P2B", "O75469"),
    ("KCNH2", "5VA2", "Q12809"),
])
def test_explicit_reference_identity_not_numerical_state(target, pdb, accession):
    result = reference().lookup(target)
    assert result["status"] == "REFERENCE_AVAILABLE"
    assert (result["gene"], result["pdb"], result["uniprot"]) == (target, pdb, accession)
    descriptor = result["reference"]
    assert descriptor["evidence_state"] == "REFERENCE_ONLY"
    assert descriptor["dynamic_coordinates"] is False
    assert descriptor["patient_specific"] is False
    assert descriptor["selected_model_index"] == 0
    assert descriptor["selected_model_number"] == 1
    assert descriptor["assembly"] == "DEPOSITED_MODEL_NOT_EXPANDED_ASSEMBLY"


def test_human_insulin_is_not_silently_substituted_with_pig():
    result = reference().lookup("INS")
    assert result["status"] == "MAPPING_UNAVAILABLE"
    assert result["reason_code"] == "HUMAN_STRUCTURE_NOT_ADMITTED"
    assert result["reference"] is None and result["pdb"] is None and result["uniprot"] is None
    related = result["related_references"]
    assert len(related) == 1 and related[0]["pdb_id"] == "4INS"
    assert all(e["source_organisms"] == [{"scientific_name": "Sus scrofa", "taxonomy_id": 9823}]
               for e in related[0]["polymer_entities"])


@pytest.mark.parametrize("target", ["AMPK", "GLUT1"])
def test_ambiguous_target_requires_explicit_source_mapping(target):
    result = reference().lookup(target)
    assert result["status"] == "AMBIGUOUS_TARGET"
    assert result["reason_code"] == "EXACT_GENE_OR_COMPLEX_REQUIRED"
    assert result["pdb"] is None and result["reference"] is None


def test_original_organ_targets_are_not_removed():
    required = {"PCK1", "G6PC", "HMGCR", "FASN", "INS", "KCNJ11", "ABCC8", "GCK",
                "SLC2A4", "AMPK", "PPARGC1A", "PPARG", "LEP", "ADIPOQ", "SLC5A2",
                "SLC22A1", "KCNH2", "SCN5A", "CACNA1C", "APP", "GLUT1"}
    catalog = reference().catalog()
    assert required <= catalog["targets"].keys()
    assert len(catalog["targets"]) == 27 and len(catalog["structures"]) == 7
    for target in required - {"INS", "AMPK", "GLUT1", "KCNH2"}:
        assert reference().lookup(target)["status"] == "MAPPING_UNAVAILABLE"


@pytest.mark.parametrize("target", ["", "kras", " KRAS", "KRAS ", "X" * 25,
                                    "../KRAS", "https://example.org", "<script>", None, 1])
def test_invalid_target_never_enters_asset_reader(monkeypatch, target):
    module = reference()
    monkeypatch.setattr(module, "_asset_root", lambda: pytest.fail("Invalid target opened data"))
    with pytest.raises(module.MolecularReferenceError) as caught:
        module.lookup(target)
    assert caught.value.code == "MOLECULAR_INVALID_TARGET"
    assert str(target) not in str(caught.value) or target == ""


def test_unknown_well_formed_target_is_unavailable_not_first_hit():
    result = reference().lookup("UNMAPPED")
    assert result["status"] == "MAPPING_UNAVAILABLE"
    assert result["reason_code"] == "SOURCE_MAPPING_NOT_ADMITTED"
    assert result["pdb"] is None and result["related_references"] == []


@pytest.mark.parametrize("entry", ["4OBE", "1TUP", "1M17", "4INS", "1N7D", "6P2B", "5VA2"])
def test_original_coordinate_bytes_match_manifest(entry):
    module = reference()
    descriptor = module.catalog()["structures"][entry]
    raw, returned = module.read_coordinates(descriptor["coordinate_sha256"])
    assert len(raw) == descriptor["coordinate_bytes"] <= 8 * 1024 * 1024
    assert hashlib.sha256(raw).hexdigest() == descriptor["coordinate_sha256"]
    assert returned == descriptor and raw.startswith(("data_" + entry).encode())


def test_callers_cannot_mutate_catalog_or_later_reference():
    module = reference()
    first = module.lookup("KRAS")
    first["reference"]["evidence_state"] = "OBSERVED"
    module.catalog()["targets"].clear()
    assert module.lookup("KRAS")["reference"]["evidence_state"] == "REFERENCE_ONLY"
    assert len(module.catalog()["targets"]) == 27


@pytest.mark.parametrize("digest", ["", "a" * 63, "A" * 64, "../" + "a" * 64, None, 1])
def test_invalid_digest_never_opens_asset_root(monkeypatch, digest):
    module = reference()
    monkeypatch.setattr(module, "_asset_root", lambda: pytest.fail("Invalid digest opened data"))
    with pytest.raises(module.MolecularReferenceError) as caught:
        module.read_coordinates(digest)
    assert caught.value.code == "MOLECULAR_NOT_FOUND"


def test_unknown_digest_never_joins_an_arbitrary_filename():
    module = reference()
    with pytest.raises(module.MolecularReferenceError) as caught:
        module.read_coordinates("a" * 64)
    assert caught.value.code == "MOLECULAR_NOT_FOUND"


@pytest.mark.parametrize("damage", ["absent", "corrupt", "oversize"])
def test_bad_catalog_is_unavailable_with_no_source_fallback(tmp_path, monkeypatch, damage):
    module = reference()
    if damage != "absent":
        (tmp_path / "catalog.json").write_bytes(b"PRIVATE_LOCAL_PATH" if damage == "corrupt" else b"x" * 131073)
    monkeypatch.setattr(module, "_asset_root", lambda: tmp_path)
    with pytest.raises(module.MolecularReferenceError) as caught:
        module.lookup("KRAS")
    assert caught.value.code == "MOLECULAR_SOURCE_UNAVAILABLE"
    assert "PRIVATE_LOCAL_PATH" not in str(caught.value) and str(tmp_path) not in str(caught.value)


@pytest.mark.parametrize("damage", ["absent", "corrupt", "oversize", "linked"])
def test_bad_coordinate_does_not_yield_a_partial_or_replacement(tmp_path, monkeypatch, damage):
    module = reference()
    data_root = module._asset_root()
    catalog_bytes = (data_root / "catalog.json").read_bytes()
    (tmp_path / "catalog.json").write_bytes(catalog_bytes)
    descriptor = module.catalog()["structures"]["4OBE"]
    asset = tmp_path / "4OBE.cif"
    if damage == "linked":
        target = tmp_path / "unrelated.cif"
        target.write_bytes((data_root / "4OBE.cif").read_bytes())
        asset.symlink_to(target)
    elif damage != "absent":
        asset.write_bytes(b"PRIVATE_LOCAL_PATH" if damage == "corrupt" else b"x" * (8 * 1024 * 1024 + 1))
    monkeypatch.setattr(module, "_asset_root", lambda: tmp_path)
    with pytest.raises(module.MolecularReferenceError) as caught:
        module.read_coordinates(descriptor["coordinate_sha256"])
    assert caught.value.code == "MOLECULAR_SOURCE_UNAVAILABLE"
    assert "PRIVATE_LOCAL_PATH" not in str(caught.value)


def test_chain_numbering_mutations_and_unreconciled_pxr_scope():
    structures = reference().catalog()["structures"]
    p53 = structures["1TUP"]
    assert { (x["label_asym_id"], x["auth_asym_id"]) for x in p53["chains"] if x["entity_id"] == "3" } == {("C", "A"), ("D", "B"), ("E", "C")}
    egfr = structures["1M17"]["deposited_sequence_mappings"][0]
    assert egfr["author_range"] == [671, 998] and egfr["database_range"] == [695, 1022]
    ldlr = structures["1N7D"]["sequence_differences"]
    assert [x["reference_position"] for x in ldlr] == [515, 657]
    pxr = structures["6P2B"]
    assert pxr["sequence_mapping_status"] == "UNRECONCILED_SOURCE_NAMESPACES"
    assert pxr["deposited_sequence_mappings"][0]["isoform"] == "O75469-7"
    assert pxr["deposited_sequence_mappings"][0]["database_range"] == [169, 473]
    assert pxr["polymer_entities"][0]["sifts_alignments"][0]["aligned_regions"][0]["ref_beg_seq_id"] == 130


def test_package_configuration_carries_original_bytes_and_catalog_only():
    project = tomllib.loads((Path(__file__).parents[2] / "pyproject.toml").read_text(encoding="utf-8"))
    patterns = project["tool"]["setuptools"]["package-data"]["livemorebio.scientific_sources"]
    assert "data/molecular/*.json" in patterns
    assert "data/molecular/*.cif" in patterns
    assert not any("entry.json" in pattern or "entity-" in pattern for pattern in patterns)


def test_coordinate_bytes_are_part_of_runtime_identity(tmp_path):
    from livemorebio.build_info import source_fingerprint

    package = tmp_path / "package"
    root = package / "scientific_sources/data/molecular"
    root.mkdir(parents=True)
    (root / "catalog.json").write_bytes(b"{}")
    before = source_fingerprint(package)
    (root / "4OBE.cif").write_bytes(b"data_4OBE")
    admitted = source_fingerprint(package)
    assert admitted != before
    (root / "4OBE.cif").write_bytes(b"data_CHANGED")
    assert source_fingerprint(package) != admitted


def test_zip_resource_reader_does_not_require_an_extracted_checkout(tmp_path, monkeypatch):
    module = reference()
    root = module._asset_root()
    archive = tmp_path / "resources.zip"
    with zipfile.ZipFile(archive, "x") as output:
        for name in ("catalog.json", "4OBE.cif"):
            output.writestr(name, (root / name).read_bytes())
    with zipfile.ZipFile(archive) as packaged:
        monkeypatch.setattr(module, "_asset_root", lambda: zipfile.Path(packaged))
        descriptor = module.lookup("KRAS")["reference"]
        raw, actual = module.read_coordinates(descriptor["coordinate_sha256"])
        assert len(raw) == actual["coordinate_bytes"]


def test_linked_catalog_is_not_admitted(tmp_path, monkeypatch):
    module = reference()
    (tmp_path / "catalog.json").symlink_to(module._asset_root() / "catalog.json")
    monkeypatch.setattr(module, "_asset_root", lambda: tmp_path)
    with pytest.raises(module.MolecularReferenceError) as caught:
        module.catalog()
    assert caught.value.code == "MOLECULAR_SOURCE_UNAVAILABLE"
