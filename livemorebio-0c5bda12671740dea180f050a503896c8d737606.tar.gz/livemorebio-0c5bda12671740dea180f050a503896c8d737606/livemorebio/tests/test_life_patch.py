"""LIFE Patch: honest sensor claims, ingestion contract, and real-data drive."""
from livemorebio.life_patch.sensors import CHANNELS, CLAIM_OF, CLAIM_DIRECT, CLAIM_SESSION
from livemorebio.life_patch.packet import LifePatchPacket, Measurement
from livemorebio.life_patch.stream import (ExternalSeriesStream, SyntheticPatchStream,
    SAMPLE_CGM_DIABETIC)
from livemorebio.aegle.runtime import AegleTwin


def test_sensor_claim_classes():
    assert CLAIM_OF["ecg_mv"] == CLAIM_DIRECT
    assert CLAIM_OF["glucose_mgdl"] == CLAIM_SESSION   # sweat chemistry: not continuous
    assert len(CHANNELS) == 5


def test_packet_defaults_are_honest():
    p = LifePatchPacket("s", 0.0, [Measurement("hr_bpm", 70, 0.0)])
    assert p.hardware_present is False                 # no manufactured patch exists
    assert p.by_signal("hr_bpm").claim == "direct"


def test_external_cgm_attaches_observations_without_recalibration():
    tw = AegleTwin("healthy")
    base_mean = tw.state()["metabolic"]["mean_glucose"]
    pkts = ExternalSeriesStream("subj", glucose=SAMPLE_CGM_DIABETIC,
                                hr=[(t, 88) for t, _ in SAMPLE_CGM_DIABETIC], source="cgm").packets()
    st = tw.ingest_patch(pkts)
    assert st["metabolic"]["mean_glucose"] == base_mean
    assert st["profile_params"] == AegleTwin("healthy").state()["profile_params"]
    assert st["observations"]["glucose_mgdl"]["value"] == SAMPLE_CGM_DIABETIC[-1][1]
    assert st["observations"]["hr_bpm"]["value"] == 88
    assert st["provenance"]["glucose"] == "synthetic-model"
    assert st["observations"]["glucose_mgdl"]["provenance"] == "technical_fixture"
    assert st["provenance"]["hr"] == "synthetic-model"
    assert st["capability"]["maturity"]["person_calibrated"] is False
    assert st["patch"]["connected"] and st["patch"]["hardware_present"] is False
    assert st["patch"]["mode"] == "external"


def test_synthetic_stream_stays_synthetic():
    tw = AegleTwin("type-2-diabetes")
    pkts = SyntheticPatchStream(tw).sample(n=24)
    assert all(not p.hardware_present for p in pkts)
    assert all(p.by_signal("skin_temp_c") is None for p in pkts)
    st = tw.ingest_patch(pkts)
    assert st["provenance"]["glucose"] == "synthetic-model"   # engine-derived model origin
    assert st["patch"]["source"] == "synthetic-from-engine"
