"""Technical fixtures for L0-R2's strict installed-asset test boundary."""
from __future__ import annotations

import hashlib
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

import pytest


def test_base_only_opt_in_never_inspects_or_acquires_a_model(monkeypatch):
    from livemorebio import model_assets
    from livemorebio.tests._cardiac import require_pinned_cardiac_asset

    monkeypatch.delenv("LIVEMORE_TEST_CARDIAC", raising=False)
    monkeypatch.setattr(model_assets, "verified_cardiac_path",
                        lambda: pytest.fail("base-only inspected the model"))
    monkeypatch.setattr(model_assets, "install",
                        lambda *args: pytest.fail("test acquired a model"))
    with pytest.raises(pytest.skip.Exception, match="explicit pinned cardiac asset opt-in; base-only run"):
        require_pinned_cardiac_asset()


@pytest.mark.parametrize("value", ["", "true", "unexpected", "2"])
def test_malformed_opt_in_fails_instead_of_silently_becoming_base_only(monkeypatch, value):
    from livemorebio.tests._cardiac import require_pinned_cardiac_asset

    monkeypatch.setenv("LIVEMORE_TEST_CARDIAC", value)
    try:
        with pytest.raises(pytest.fail.Exception, match="LIVEMORE_TEST_CARDIAC must be 0 or 1"):
            require_pinned_cardiac_asset()
    except pytest.skip.Exception:
        pytest.fail("malformed opt-in was skipped as base-only")


@pytest.mark.parametrize("content,code", [
    (None, "CARDIAC_MODEL_NOT_INSTALLED"),
    (b"technical-mismatched-model", "CARDIAC_MODEL_HASH_MISMATCH"),
])
def test_enabled_opt_in_fails_missing_or_mismatched_bytes(monkeypatch, tmp_path, content, code):
    from livemorebio import model_assets
    from livemorebio.tests._cardiac import require_pinned_cardiac_asset

    path = tmp_path / "technical-model.cellml"
    if content is not None:
        path.write_bytes(content)
    monkeypatch.setenv("LIVEMORE_TEST_CARDIAC", "1")
    monkeypatch.setattr(model_assets, "_cardiac_path", lambda: path)
    with pytest.raises(pytest.fail.Exception, match=code):
        require_pinned_cardiac_asset()


def test_enabled_opt_in_accepts_only_verified_technical_bytes(monkeypatch, tmp_path):
    from livemorebio import model_assets
    from livemorebio.tests._cardiac import require_pinned_cardiac_asset

    content = b"technical-fixture-only; not a biological model\n"
    path = tmp_path / "technical-model.cellml"
    path.write_bytes(content)
    original = model_assets._CARDIAC_ASSET
    monkeypatch.setattr(model_assets, "_CARDIAC_ASSET", model_assets.AssetFile(
        original.asset_id, original.filename, original.source_url,
        hashlib.sha256(content).hexdigest(), len(content),
    ))
    monkeypatch.setenv("LIVEMORE_TEST_CARDIAC", "1")
    monkeypatch.setattr(model_assets, "_cardiac_path", lambda: path)
    assert require_pinned_cardiac_asset() == path


def test_cardiac_module_collection_never_constructs_a_cell(monkeypatch):
    from livemorebio import _toolchain
    from livemorebio.engines.cardiac import action_potential

    monkeypatch.delenv("LIVEMORE_TEST_CARDIAC", raising=False)
    monkeypatch.setattr(_toolchain, "cardiac_simulation",
                        lambda: {"available": False, "reason": "technical no compiler"})
    monkeypatch.setattr(action_potential, "CardiacCell",
                        lambda: pytest.fail("collection constructed an unverified model"))
    spec = importlib.util.spec_from_file_location(
        "technical_cardiac_collection", Path(__file__).with_name("test_cardiac.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)


def test_numerical_tests_use_the_base_only_asset_boundary(tmp_path):
    """Exercise the real numerical test entry points without acquiring an asset."""
    root = Path(__file__).resolve().parents[2]
    targets = {
        "test_cardiac.py": ["test_human_ap_is_physiologic", "test_ikr_block_prolongs_apd"],
        "test_aegle.py": ["test_twin_reacts_to_stimuli", "test_systems_status_is_honest"],
        "test_coupling_cendos.py": ["test_coupling_diabetes_prolongs_apd"],
        "test_multiscale_workspace.py": [
            "test_unimplemented_systems_have_formal_contracts_but_no_invented_state",
            "test_metformin_execution_is_person_specific_and_spans_implemented_scales",
        ],
        "test_l0_scenario_isolation.py": [
            "test_scenario_changes_its_result_but_not_the_live_twin",
            "test_partial_scenario_failure_preserves_live_state_and_generation",
        ],
        "test_execution_numerics.py": ["test_cellular_preregistered_chunk_and_tolerance_convergence"],
        "test_continuous_execution.py": [
            "test_cellular_checkpoint_rejects_negative_concentrations_beyond_fixed_floor",
        ],
        "test_hovorka_insulin_engine.py": [
            "test_unsourced_cardiac_coupling_is_labelled_as_a_hypothesis",
        ],
    }
    report = tmp_path / "technical-base-only.xml"
    environment = dict(os.environ, LIVEMORE_TEST_CARDIAC="0", LIVEMORE_TEST_CONTINUOUS_CARDIAC="1")
    environment.pop("PYTEST_ADDOPTS", None)
    environment.pop("PYTEST_PLUGINS", None)
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "-q", "-rfEs", "-p", "no:cacheprovider",
         f"--junitxml={report}",
         *(f"livemorebio/tests/{module}::{name}" for module, names in targets.items() for name in names)],
        cwd=root, env=environment, capture_output=True, text=True, encoding="utf-8", timeout=180,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    cases = ET.fromstring(report.read_text(encoding="utf-8")).findall(".//testcase")
    skipped = [case for case in cases if case.find("skipped") is not None]
    assert len(skipped) == 15, result.stdout
    assert {case.find("skipped").get("message").removeprefix("Skipped: ") for case in skipped} == {
        "explicit pinned cardiac asset opt-in; base-only run"
    }
