"""W5-1: a bound service names its console cookie by its published port.

A Compose stack whose host publications are remapped (the container listens on
8850, the host publishes 18950) used to name the cookie by the listener, so the
proved Python exchange, which expects the published port's name, refused, and a
browser got the name a default native stack on the same host also uses.

The service's proof authority is the published origin, pinned where the actual
bind is known. The cookie is named by that authority's port; for every loopback
bind it is the listener's port, so native stacks and the shipped Compose file
issue byte-identical names. In-process only: technical values, no socket bound,
nothing contacted, no patient data.
"""
from __future__ import annotations

from urllib.parse import urlsplit

import pytest
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.testclient import TestClient

from livemorebio import console_session, security, stack_client, stack_proof, stack_transport
from livemorebio.service_identity import IdentitySnapshot

KEY = bytes(range(32))
TOKEN = "technical-cookie-authority-credential"
LISTENER = "http://127.0.0.1:8850"
PUBLISHED = "http://127.0.0.1:18950"
PEER = ("127.0.0.1", 50000)
AUTHORITY_VARIABLES = ("LIVEMORE_SERVICE_IDENTITY_AUTHORITY", "LIVEMORE_AEGLE_IDENTITY_AUTHORITY",
                       "LIVEMORE_LIFE_IDENTITY_AUTHORITY", "LIVEMORE_CENDOS_IDENTITY_AUTHORITY",
                       "LIVEMORE_AEGLE_URL", "LIVEMORE_LIFE_URL", "LIVEMORE_CENDOS_URL")


@pytest.fixture(autouse=True)
def technical_service(monkeypatch):
    monkeypatch.setenv(security.TOKEN_ENV, TOKEN)
    monkeypatch.delenv("LIVEMORE_CONSOLE_PEER", raising=False)
    for name in AUTHORITY_VARIABLES:
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setattr(stack_proof, "service_identity_key", lambda **kwargs: KEY)


def compose_environment(monkeypatch, published=(18950, 18951, 18952)):
    """Aegle's container settings from docker-compose.yml, publications remapped."""
    aegle, life, cendos = (f"http://127.0.0.1:{port}" for port in published)
    for name, value in (("LIVEMORE_SERVICE_IDENTITY_AUTHORITY", aegle),
                        ("LIVEMORE_AEGLE_IDENTITY_AUTHORITY", aegle),
                        ("LIVEMORE_LIFE_IDENTITY_AUTHORITY", life),
                        ("LIVEMORE_CENDOS_IDENTITY_AUTHORITY", cendos),
                        ("LIVEMORE_AEGLE_URL", "http://aegle:8850"),
                        ("LIVEMORE_LIFE_URL", "http://life:8851"),
                        ("LIVEMORE_CENDOS_URL", "http://cendos:8852")):
        monkeypatch.setenv(name, value)


def console(role: str | None = "aegle") -> FastAPI:
    """A throwaway application with the real session, mutation and proof wiring."""
    app = FastAPI()

    @app.get("/")
    def document():
        return HTMLResponse("<!doctype html><title>technical fixture</title>")

    @app.post("/api/technical")
    def mutation():
        return {"technical": "fixture"}

    @app.get("/api/technical-read")
    def protected_read():
        return {"technical": "fixture"}

    security.install_mutation_auth(app, session_document_paths=frozenset({"/"}), service_role=role,
                                   operator_read_paths=frozenset({"/api/technical-read"}))
    return app


def bound(host: str, port: int) -> FastAPI:
    app = console()
    stack_proof.configure_bind_identity(app, host, port)
    return app


def listener(app: FastAPI, base_url: str, **options) -> TestClient:
    return TestClient(app, base_url=base_url, client=PEER, **options)


def issued_names(app: FastAPI, base_url: str, headers=None) -> list[str]:
    """The cookie names the service really set on a code exchange."""
    with listener(app, base_url) as client:
        code = client.post("/api/session/code", headers={"Authorization": f"Bearer {TOKEN}", **(headers or {})})
        assert code.status_code == 200
        done = client.post("/api/session/exchange", data={"code": code.json()["code"]},
                           headers=headers or {}, follow_redirects=False)
    assert done.status_code == 200 and "location" not in done.headers
    return [header.split("=", 1)[0] for header in done.headers.get_list("set-cookie")]


def published_headers(origin: str = PUBLISHED) -> dict[str, str]:
    """What a host client sends through the publication: the published Host."""
    return {"Host": urlsplit(origin).netloc}


def test_a_remapped_compose_bind_issues_the_published_ports_name(monkeypatch):
    compose_environment(monkeypatch)
    app = bound("0.0.0.0", 8850)
    assert app.state.stack_proof.snapshot.authority == PUBLISHED
    assert issued_names(app, LISTENER, published_headers()) == ["livemore_local_session_18950"]
    # Not the default native stack's name, which a browser would share across ports.
    assert security.session_cookie_name(8850) == "livemore_local_session_8850"


def test_only_the_published_name_authorizes_a_remapped_bind(monkeypatch):
    compose_environment(monkeypatch)
    app = bound("0.0.0.0", 8850)
    issued_names(app, LISTENER, published_headers())
    secret = app.state.console_session_secret
    same_origin = {**published_headers(), "Origin": PUBLISHED, "Sec-Fetch-Site": "same-origin"}
    with listener(app, LISTENER, cookies={"livemore_local_session_18950": secret}) as client:
        assert client.post("/api/technical", headers=same_origin).status_code == 200
        assert client.get("/api/technical-read", headers=same_origin).status_code == 200
    with listener(app, LISTENER, cookies={"livemore_local_session_8850": secret}) as client:
        assert client.post("/api/technical", headers=same_origin).status_code == 401
        assert client.get("/api/technical-read", headers=same_origin).status_code == 401


def test_a_forged_host_cannot_select_a_bound_services_cookie_name(monkeypatch):
    compose_environment(monkeypatch)
    app = bound("0.0.0.0", 8850)
    # Neither another port nor the listener's own Host selects another name.
    for host in ("127.0.0.1:19863", "127.0.0.1:8850"):
        assert issued_names(app, LISTENER, {"Host": host}) == ["livemore_local_session_18950"]


def test_the_proved_client_exchange_succeeds_behind_a_remapped_publication(monkeypatch):
    """The finding as walked: the real client, the real server, the published origin."""
    compose_environment(monkeypatch)
    app = bound("0.0.0.0", 8850)
    monkeypatch.setattr(stack_client, "service_identity_key", lambda *, create=False: KEY)
    calls = []

    def through_the_publication(url, *, identity, method="GET", headers=None, body=None, **options):
        # The transport's proof succeeds only for the server's own bound snapshot.
        assert identity == app.state.stack_proof.snapshot == IdentitySnapshot(KEY, "aegle", PUBLISHED)
        parts = urlsplit(url)
        assert f"{parts.scheme}://{parts.netloc}" == PUBLISHED
        calls.append(parts.path)
        with listener(app, LISTENER) as client:
            response = client.request(method, parts.path, content=body,
                                      headers={**(headers or {}), **published_headers()}, follow_redirects=False)
        return stack_transport.StackResponse(response.status_code, response.reason_phrase,
                                             tuple(response.headers.multi_items()), response.content)

    monkeypatch.setattr(stack_transport, "request", through_the_publication)
    cookie = console_session.mint_console_cookie(PUBLISHED)
    assert calls == ["/api/session/code", "/api/session/exchange"]
    assert (cookie.origin, cookie.name) == (PUBLISHED, "livemore_local_session_18950")
    assert cookie.value == app.state.console_session_secret


@pytest.mark.parametrize("host", ["127.0.0.1", "::1"])
@pytest.mark.parametrize("port", [1, 8850, 8851, 8852, 8950, 19863, 65535])
def test_a_loopback_bind_issues_the_same_name_as_its_listener(host, port):
    # Starlette's TestClient cannot address an IPv6 base URL; the name depends on
    # the listener's port alone, so both binds are addressed over IPv4 here.
    origin = f"http://127.0.0.1:{port}"
    app = bound(host, port)
    assert app.state.stack_proof.authority_port == port
    names = issued_names(app, origin)
    assert names == issued_names(console(role=None), origin) == [f"livemore_local_session_{port}"]


@pytest.mark.parametrize("role, port", [("aegle", 8850), ("life", 8851), ("cendos", 8852)])
def test_the_shipped_compose_profile_issues_the_same_name_as_its_listener(monkeypatch, role, port):
    compose_environment(monkeypatch, published=(8850, 8851, 8852))
    monkeypatch.setenv("LIVEMORE_SERVICE_IDENTITY_AUTHORITY", f"http://127.0.0.1:{port}")
    app = console(role)
    stack_proof.configure_bind_identity(app, "0.0.0.0", port)
    origin = f"http://127.0.0.1:{port}"
    assert issued_names(app, origin) == issued_names(console(role=None), origin) == [
        f"livemore_local_session_{port}"]


def test_technical_fixtures_keep_the_listener_rule():
    app = console()
    stack_proof.configure_test_identity(app, IdentitySnapshot(KEY, "aegle", PUBLISHED))
    assert app.state.stack_proof.authority_port is None
    assert issued_names(app, LISTENER) == ["livemore_local_session_8850"]
