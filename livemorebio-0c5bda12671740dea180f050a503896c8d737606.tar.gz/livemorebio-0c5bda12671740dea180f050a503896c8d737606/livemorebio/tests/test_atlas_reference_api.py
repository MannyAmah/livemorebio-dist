"""Atlas HTTP boundaries with declared technical bytes, not anatomical acceptance."""
from __future__ import annotations

import asyncio
from concurrent.futures import ThreadPoolExecutor
import hashlib
import sys
import threading
from types import ModuleType

from fastapi.testclient import TestClient
import pytest
from ._timing import wait_seconds

SOURCE = "bp3d-4.0-20130619-surface-core-v1"
DIGEST = "a" * 64
STATUS_PATH = "/api/anatomy/atlas-reference"
INSTALL_PATH = STATUS_PATH + "/install"
ASSET_PATH = f"/assets/anatomy/atlas/{DIGEST}/skin.glb"
AUTH = {"Authorization": "Bearer technical-atlas-api-test"}


class TechnicalAtlasError(ValueError):
    def __init__(self, code: str, status_code: int, retry_after: int | None = None):
        super().__init__("Atlas reference is unavailable.")
        self.code = code
        self.status_code = status_code
        self.retry_after = retry_after


@pytest.fixture
def client(tmp_path, monkeypatch, technical_stack_identities):
    from livemorebio import anatomy
    from livemorebio.aegle.server import app
    from livemorebio.stack_proof import configure_test_identity

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-atlas-api-test")
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(tmp_path / "uncreated-cache"))
    stub = ModuleType("livemorebio.anatomy.atlas_reference")
    stub.SOURCE_ID = SOURCE
    stub.AtlasReferenceError = TechnicalAtlasError
    calls: list[object] = []
    missing = {"schema": "livemore.atlas-reference-status.v1", "source_id": SOURCE,
               "state": "missing", "available": False, "manifest_sha256": None,
               "manifest": None, "reason": "ATLAS_NOT_INSTALLED",
               "reference_geometry": True, "patient_registered": False}
    stub.status = lambda: calls.append("status") or dict(missing)
    stub.install = lambda source_id: calls.append(("install", source_id)) or {
        **missing, "state": "available", "available": True,
        "manifest_sha256": DIGEST, "reused": False, "receipt": {"receipt_id": "technical-only"}}
    content = b"explicit technical route payload, not a real GLB"
    stub.read_asset = lambda digest, key: calls.append(("asset", digest, key)) or (content, {
        "source_id": SOURCE, "manifest_sha256": digest, "asset_key": key,
        "sha256": hashlib.sha256(content).hexdigest(), "bytes": len(content),
        "license": "CC-BY-4.0", "evidence_state": "REFERENCE_ONLY"})
    monkeypatch.setitem(sys.modules, stub.__name__, stub)
    monkeypatch.setattr(anatomy, "atlas_reference", stub, raising=False)
    monkeypatch.setattr(app.state, "stack_proof", app.state.stack_proof)
    configure_test_identity(app, technical_stack_identities["aegle"])
    with TestClient(app, raise_server_exceptions=False) as test_client:
        yield test_client, stub, calls, tmp_path / "uncreated-cache"


def test_missing_status_is_metadata_only_and_never_acquires(client):
    c, _, calls, cache = client
    result = c.get(STATUS_PATH)
    assert result.status_code == 200
    assert result.json()["state"] == "missing"
    assert result.json()["manifest"] is None
    assert result.json()["patient_registered"] is False
    assert result.headers["cache-control"] == "no-store"
    assert calls == ["status"] and not cache.exists()


@pytest.mark.parametrize("method,path,body", [("GET", STATUS_PATH, None),
    ("POST", INSTALL_PATH, {"source_id": SOURCE}),
    ("POST", INSTALL_PATH, {"source_id": "wrong"}),
    ("GET", ASSET_PATH, None), ("GET", ASSET_PATH.replace("skin.glb", "unknown.glb"), None)])
def test_atlas_route_replies_include_immutable_startup_identity(client, method, path, body):
    from livemorebio.build_info import build_identity
    c, _, _, _ = client
    result = c.request(method, path, headers=AUTH, json=body)
    identity = build_identity()
    assert result.headers["X-Livemore-Source-Sha256"] == identity["source_sha256"]
    assert result.headers["X-Livemore-Process-Instance"] == identity["process_instance"]
    assert "no-store" in result.headers["Cache-Control"]


def test_unexpected_atlas_failure_keeps_startup_identity(client):
    from livemorebio.build_info import build_identity
    c, stub, _, _ = client
    def failed():
        raise OSError("PRIVATE source")
    stub.status = failed
    result = c.get(STATUS_PATH)
    assert result.status_code == 503
    assert result.headers["X-Livemore-Source-Sha256"] == build_identity()["source_sha256"]
    assert result.headers["X-Livemore-Process-Instance"] == build_identity()["process_instance"]
    assert "PRIVATE" not in result.text


def test_missing_source_hash_is_omitted_without_losing_process_or_asset_headers(client, monkeypatch):
    from livemorebio import build_info
    c, _, _, _ = client
    identity = {**build_info.build_identity(), "source_sha256": None}
    monkeypatch.setattr(build_info, "build_identity", lambda: dict(identity))
    result = c.get(ASSET_PATH, headers=AUTH)
    assert result.status_code == 200
    assert "X-Livemore-Source-Sha256" not in result.headers
    assert result.headers["X-Livemore-Process-Instance"] == identity["process_instance"]
    assert result.headers["X-Content-SHA256"] == hashlib.sha256(result.content).hexdigest()
    assert result.headers["X-Atlas-Manifest-SHA256"] == DIGEST
    assert result.headers["Cache-Control"] == "private, no-store"


@pytest.mark.parametrize("method,path", [("POST", INSTALL_PATH), ("GET", ASSET_PATH)])
def test_internal_atlas_requires_auth_before_acquisition_or_asset_read(client, method, path):
    c, _, calls, _ = client
    result = c.request(method, path, json={"source_id": SOURCE})
    assert result.status_code == 401
    assert "no-store" in result.headers["cache-control"]
    assert calls == []


@pytest.mark.parametrize("path", [INSTALL_PATH, ASSET_PATH])
def test_cross_origin_cookie_cannot_acquire_or_read_internal_asset(client, monkeypatch, path):
    from livemorebio import audit
    from livemorebio.aegle.server import app
    from livemorebio.security import session_cookie_name
    c, _, calls, _ = client
    events = []
    monkeypatch.setattr(audit, "record", lambda *a, **kw: events.append((a, kw)) or {})
    c.cookies.set(session_cookie_name(80), app.state.console_session_secret)
    same_origin = c.request("POST" if path == INSTALL_PATH else "GET", path,
                            headers={"Origin": "http://testserver", "Sec-Fetch-Site": "same-origin"},
                            json={"source_id": SOURCE})
    assert same_origin.status_code == 200 and len(calls) == 1
    calls.clear()
    events.clear()
    result = c.request("POST" if path == INSTALL_PATH else "GET", path,
                       headers={"Origin": "https://unapproved.invalid", "Sec-Fetch-Site": "cross-site"},
                       json={"source_id": SOURCE})
    assert result.status_code == 403
    assert "no-store" in result.headers["cache-control"]
    assert calls == [] and events == []


@pytest.mark.parametrize("raw", ["{}", "[]", '{"source_id":false}',
    '{"source_id":"unapproved"}', '{"source_id":NaN}',
    '{"source_id":"' + SOURCE + '","source_id":"' + SOURCE + '"}',
    '{"source_id":"' + SOURCE + '","url":"https://unapproved.invalid"}',
    '{"source_id":"' + SOURCE + '","padding":"' + "x" * 2000 + '"}',
    '{"source_id":' + "[" * 65 + '0' + "]" * 65 + '}', b"\xff"])
def test_strict_bounded_install_body_rejects_before_installer(client, raw):
    c, _, calls, _ = client
    result = c.post(INSTALL_PATH, headers=AUTH, content=raw)
    assert result.status_code == 422
    assert result.json()["code"] == "ATLAS_INVALID_REQUEST"
    assert result.headers["cache-control"] == "no-store"
    assert calls == []


def test_explicit_install_runs_off_event_loop_once_and_returns_receipt(client):
    c, stub, calls, _ = client
    original = stub.install
    def install(source_id):
        with pytest.raises(RuntimeError):
            asyncio.get_running_loop()
        return original(source_id)
    stub.install = install
    result = c.post(INSTALL_PATH, headers=AUTH, json={"source_id": SOURCE})
    assert result.status_code == 200 and result.json()["receipt"]["receipt_id"] == "technical-only"
    assert calls == [("install", SOURCE)]


def test_status_remains_readable_during_explicit_install(client):
    c, stub, _, _ = client
    started, release = threading.Event(), threading.Event()
    original = stub.install
    def install(source_id):
        started.set()
        assert release.wait(5), "technical installer was not released"
        return original(source_id)
    stub.install = install
    with ThreadPoolExecutor(max_workers=2) as pool:
        pending = pool.submit(c.post, INSTALL_PATH, headers=AUTH, json={"source_id": SOURCE})
        try:
            assert started.wait(2)
            assert pool.submit(c.get, STATUS_PATH).result(timeout=wait_seconds(2)).status_code == 200
        finally:
            release.set()
        assert pending.result(timeout=wait_seconds(3)).status_code == 200


def test_internal_asset_returns_same_verified_bytes_and_identity_headers(client):
    c, _, calls, _ = client
    result = c.get(ASSET_PATH, headers=AUTH)
    assert result.status_code == 200
    assert result.headers["content-type"] == "model/gltf-binary"
    assert result.headers["cache-control"] == "private, no-store"
    assert result.headers["x-content-type-options"] == "nosniff"
    assert result.headers["x-content-sha256"] == hashlib.sha256(result.content).hexdigest()
    assert result.headers["x-atlas-manifest-sha256"] == DIGEST
    assert calls == [("asset", DIGEST, "skin")]


@pytest.mark.parametrize("path", [f"/assets/anatomy/atlas/{'A' * 64}/skin.glb",
    f"/assets/anatomy/atlas/{DIGEST}/unapproved.glb", "/assets/anatomy/atlas/short/skin.glb"])
def test_unknown_static_asset_identity_is_rejected_before_cache_read(client, path):
    c, _, calls, _ = client
    result = c.get(path, headers=AUTH)
    assert result.status_code == 404
    assert "no-store" in result.headers["cache-control"]
    assert calls == []


@pytest.mark.parametrize("code,status", [("ATLAS_ACQUIRING", 409), ("ATLAS_SOURCE_POLICY", 503),
    ("ATLAS_UNSAFE_CACHE", 503), ("ATLAS_SOURCE_INTEGRITY", 503),
    ("ATLAS_PUBLICATION_UNCONFIRMED", 503)])
def test_install_failure_is_retained_safe_and_never_retried(client, code, status):
    c, stub, calls, _ = client
    def fail(source_id):
        calls.append(("install", source_id))
        raise TechnicalAtlasError(code, status, 3 if status == 409 else None)
    stub.install = fail
    result = c.post(INSTALL_PATH, headers=AUTH, json={"source_id": SOURCE})
    assert result.status_code == status and result.json()["code"] == code
    if status == 409:
        assert result.headers["retry-after"] == "3"
    assert calls == [("install", SOURCE)]


@pytest.mark.parametrize("method,path,operation", [("GET", STATUS_PATH, "status"),
    ("POST", INSTALL_PATH, "install"), ("GET", ASSET_PATH, "read_asset")])
def test_unexpected_errors_never_expose_path_payload_or_raw_exception(client, method, path, operation):
    c, stub, _, _ = client
    def fail(*args):
        raise OSError("PRIVATE-PAYLOAD /private/participant/path")
    setattr(stub, operation, fail)
    result = c.request(method, path, headers=AUTH, json={"source_id": SOURCE})
    assert result.status_code == 503
    assert result.json()["code"] == "ATLAS_UNAVAILABLE"
    assert "PRIVATE-PAYLOAD" not in result.text and "/private/" not in result.text
    assert "no-store" in result.headers["cache-control"]
