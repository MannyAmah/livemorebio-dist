"""LIFE empty-source guidance, using actual API projection and inert model presence."""
import json
from pathlib import Path
import subprocess
from types import SimpleNamespace

import pytest
from ._node import NODE, run_node as _run_node


MODULE = (Path(__file__).parents[1] / "aegle/console/lib/continuous_execution.js").as_uri()


@pytest.fixture
def preview_capabilities(monkeypatch):
    from livemorebio.aegle import execution_api, server

    # Only presence is inspected by the real projection. No model is constructed.
    monkeypatch.setattr(server, "_state", {"tw": object(), "subject": None})
    monkeypatch.setattr(server, "_model_source_authority", SimpleNamespace(
        generation="technical-empty-generation", capture=lambda operation: operation()))
    monkeypatch.setattr(server, "_subject_registry", lambda: pytest.fail("preview read reached registry"))
    monkeypatch.setattr(execution_api, "_manager", lambda: pytest.fail("preview read opened a store"))
    monkeypatch.setattr(execution_api, "capture_source_payload", lambda *args: pytest.fail("preview captured biology"))
    monkeypatch.setattr(execution_api, "_operate", lambda action, operation: operation(None))
    value = execution_api.capabilities()
    assert value["preparation_available"] is False
    assert value["reason"] == "EXECUTION_SOURCE_REQUIRED"
    assert value["selection"] is None
    assert value["model_availability"]["state"] == "READY"
    assert value["model_availability"]["selection_mode"] == "reference_preview"
    assert value["model_availability"]["preparation_available"] is True
    return value


def run_ui(payload: dict, body: str, *, before_mount: str = "") -> None:
    program = r"""
const assert=require('node:assert/strict');
(async()=>{
const {mountContinuousExecution}=await import(MODULE);
let payload=PAYLOAD, failure=null, failureName='Error';
const calls=[],nodes=new Map(),classes=new Map();
function el(key,dataset={}){
 if(!nodes.has(key))nodes.set(key,{value:key==='[data-engine]'?'metabolic-continuous-v1':'',dataset,
  handlers:{},attributes:{},textContent:'',innerHTML:'',disabled:false,classList:{toggle(){}},
  setAttribute(key,value){this.attributes[key]=value;},replaceChildren(){this.innerHTML='';},
  addEventListener(key,handler){this.handlers[key]=handler;}});
 return nodes.get(key);
}
const engines=['start','pause','resume','stop'].map(action=>el('engine-'+action,{engineAction:action}));
const life=['pause','resume','stop'].map(action=>el('life-'+action,{lifeAction:action}));
const setup=['register','bind-device','prepare','bind-session','refresh-source'].map(name=>el(`[data-${name}]`));
const host={innerHTML:'',classList:{toggle(key,value){classes.set(key,value);}},setAttribute(){},querySelector:el,
 querySelectorAll:key=>key==='button,input,select'?[...engines,...life,...setup]:key==='[data-engine-action]'?engines:key==='[data-life-action]'?life:[]};
globalThis.document={hidden:false,addEventListener(){},removeEventListener(){}};
globalThis.window={addEventListener(){}};globalThis.location={search:''};
globalThis.fetch=async(path,options)=>{
 calls.push({path,method:options.method});
 if(failure===options.method)throw Object.assign(Error('Technical '+options.method+' unavailable.'),{name:failureName});
 assert.equal(path,'/api/executions/capabilities');assert.equal(options.method,'GET');
 return {ok:true,json:async()=>structuredClone(payload)};
};
const tick=async()=>{for(let i=0;i<4;i++)await new Promise(setImmediate);};
BEFORE_MOUNT
const view=mountContinuousExecution(host);
try{await tick();BODY}finally{view.dispose();}
})().catch(error=>{console.error(error);process.exitCode=1;});
""".replace("MODULE", json.dumps(MODULE)).replace("PAYLOAD", json.dumps(payload)).replace(
        "BEFORE_MOUNT", before_mount).replace("BODY", body)
    result = _run_node([NODE, "--eval", program],
                            capture_output=True, text=True, timeout=10, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_actual_empty_preview_is_useful_and_read_only(preview_capabilities):
    run_ui(preview_capabilities, r"""
assert.match(el('[data-selection]').textContent,/No registered active source\. Create and activate a twin before preparation\./);
assert.match(host.innerHTML,/<a href="\/twins">Create \/ activate a registered twin<\/a>/);
assert.equal(el('[data-message]').attributes.role,'status');assert.equal(classes.get('execution-error'),false);
for(const name of ['register','bind-device','prepare','bind-session'])assert.equal(el(`[data-${name}]`).disabled,true);
assert.equal(el('[data-refresh-source]').disabled,false);
await el('[data-refresh-source]').handlers.click();await tick();
assert.equal(calls.length,2);assert(calls.every(call=>call.method==='GET'));
assert.equal(el('[data-message]').attributes.role,'status');
assert(!el('[data-message]').textContent.includes('mutation retry'));
for(const name of ['register','bind-device','prepare','bind-session'])assert.equal(el(`[data-${name}]`).disabled,true);
""")


@pytest.mark.parametrize("damage", [
    "payload.source_generation='different-generation'",
    "payload.reason='MODEL_BINDING_REQUIRED'", "delete payload.reason",
    "payload.selection={twin_id:'invented'}", "delete payload.selection",
    "payload.preparation_available=true", "payload.preparation_available=0",
    "payload.model_availability.twin_id='invented'",
    "payload.model_availability.twin_version=1",
    "payload.model_availability.preparation_available=false",
])
def test_malformed_preview_neighbors_are_rejected(preview_capabilities, damage):
    run_ui(preview_capabilities, """
assert.equal(el('[data-message]').attributes.role,'alert');
assert.match(el('[data-message]').textContent,/inconsistent/);
for(const name of ['register','bind-device','prepare','bind-session'])assert.equal(el(`[data-${name}]`).disabled,true);
assert.equal(calls.length,1);assert.equal(calls[0].method,'GET');
""", before_mount=damage)


@pytest.mark.parametrize("discovery", ["automatic", "explicit"])
def test_capability_read_failure_has_read_guidance_only(preview_capabilities, discovery):
    run_ui(preview_capabilities, """
if(DISCOVERY==='explicit'){failure='GET';await el('[data-refresh-source]').handlers.click();await tick();}
const text=el('[data-message]').textContent;
assert.equal(el('[data-message]').attributes.role,'alert');assert.match(text,/Technical GET unavailable/);
assert.match(text,/Read selected source/);assert(!text.includes('mutation retry'));assert(!text.includes('fixed execution/session'));
assert(calls.every(call=>call.method==='GET'));
""".replace("DISCOVERY", json.dumps(discovery)),
           before_mount="failure='GET'" if discovery == "automatic" else "")


@pytest.mark.parametrize("discovery", ["automatic", "explicit"])
def test_capability_read_abort_has_read_guidance_only(preview_capabilities, discovery):
    run_ui(preview_capabilities, """
if(DISCOVERY==='explicit'){failure='GET';await el('[data-refresh-source]').handlers.click();await tick();}
assert.equal(el('[data-message]').attributes.role,'alert');
assert.equal(el('[data-message]').textContent,'Read request was canceled or timed out. Read selected source again after checking the service. No preparation was attempted.');
for(const name of ['register','bind-device','prepare','bind-session'])assert.equal(el(`[data-${name}]`).disabled,true);
assert.equal(el('[data-refresh-source]').disabled,false);
assert.equal(calls.length,DISCOVERY==='automatic'?1:2);assert(calls.every(call=>call.method==='GET'));
""".replace("DISCOVERY", json.dumps(discovery)),
           before_mount="failureName='AbortError';" + ("failure='GET'" if discovery == "automatic" else ""))


@pytest.mark.parametrize("state", ["registered", "observations_only"])
def test_other_valid_availability_states_keep_existing_controls(preview_capabilities, state):
    run_ui(preview_capabilities, """
assert.equal(el('[data-message]').attributes.role,'status');
assert.equal(el('[data-register]').disabled,STATE==='observations_only');
assert.equal(el('[data-bind-device]').disabled,true);assert.equal(el('[data-prepare]').disabled,true);
assert.equal(el('[data-bind-session]').disabled,true);assert(calls.every(call=>call.method==='GET'));
assert.match(el('[data-selection]').textContent,STATE==='observations_only'?/Observations only.*MODEL_BINDING_REQUIRED/:/twin-technical.*registry version 1/);
""".replace("STATE", json.dumps(state)), before_mount="""
payload.model_availability={...payload.model_availability,selection_mode:'model',twin_id:'twin-technical',twin_version:1};
payload.selection={twin_id:'twin-technical',twin_version:1,source_data_class:'SYNTHETIC'};
payload.preparation_available=true;payload.reason=null;
""" + ("""
payload.model_availability={...payload.model_availability,state:'UNAVAILABLE',selection_mode:'observations_only',reason_code:'MODEL_BINDING_REQUIRED',preparation_available:false};
payload.selection=null;payload.preparation_available=false;payload.reason='MODEL_BINDING_REQUIRED';
""" if state == "observations_only" else ""))


def test_mutation_failure_still_warns_without_replay(preview_capabilities):
    run_ui(preview_capabilities, r"""
assert.equal(el('[data-register]').disabled,false);failure='POST';
await el('[data-register]').handlers.click();await tick();
assert.equal(calls.filter(call=>call.method==='POST').length,1);
assert.match(el('[data-message]').textContent,/No automatic mutation retry was performed\. Read the fixed execution\/session to confirm its state\./);
assert.equal(el('[data-message]').attributes.role,'alert');
""", before_mount="""
payload.model_availability={...payload.model_availability,selection_mode:'model',twin_id:'twin-technical',twin_version:1};
payload.selection={twin_id:'twin-technical',twin_version:1,source_data_class:'SYNTHETIC'};
payload.preparation_available=true;payload.reason=null;
""")


def test_mutation_abort_retains_exact_warning_without_replay(preview_capabilities):
    run_ui(preview_capabilities, """
assert.equal(el('[data-register]').disabled,false);failure='POST';failureName='AbortError';
await el('[data-register]').handlers.click();await tick();
assert.equal(calls.length,2);assert.equal(calls.filter(call=>call.method==='POST').length,1);
assert.equal(el('[data-message]').textContent,'Request was canceled or timed out. Outcome is not confirmed; inspect before retrying a mutation. No automatic mutation retry was performed. Read the fixed execution/session to confirm its state.');
assert.equal(el('[data-message]').attributes.role,'alert');
""", before_mount="""
payload.model_availability={...payload.model_availability,selection_mode:'model',twin_id:'twin-technical',twin_version:1};
payload.selection={twin_id:'twin-technical',twin_version:1,source_data_class:'SYNTHETIC'};
payload.preparation_available=true;payload.reason=null;
""")
