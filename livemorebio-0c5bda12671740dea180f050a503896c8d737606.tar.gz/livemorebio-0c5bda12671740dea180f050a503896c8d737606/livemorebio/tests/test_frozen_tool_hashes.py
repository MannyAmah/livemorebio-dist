"""Frozen research tools the product carries must be the bytes that were recorded.

``test_osp_source_admission.py`` pins the SHA-256 of ``tools/osp_stage_b.py``,
``tools/osp_stage_b_native.R`` and ``tools/osp_stage_b_analysis.py`` in one
assertion together with the SHA-256 of a record under ``docs/``. The container
image does not carry that record, so the whole test skips there, and the check
of the three tools, which the image does carry, skipped with it. For
``osp_stage_b_native.R`` it was the only check anywhere: the file is R, nothing
imports it, and no other test reads it. A copy that was missing from the image,
or altered in it, would have passed the build.

That test is frozen, because its module's own hash is pinned, so it cannot be
split in two. The three product files are checked here instead, on their own,
and these tests run in every tree the suite runs in. Present files must always
match their pins. Missing files skip only when the publisher's policy excludes
them and the tree bears its public marker; an image declaration cannot excuse
their absence. A separate assertion holds the public tree to the exact set of
policy-private omissions, including rejection of a retained excluded file.

The expected values are written out below, which makes a third place that
states them. So they are held to the other two: the frozen test's own literal,
which the private image carries, and the table in the source tree's preservation
record. The record comparison skips in the image, where the record is not.
Both comparisons skip for the publisher's explicit public omissions.

Twelve more files of the frozen tools were in the same position, and worse:
nothing that runs in the image opens them at all. The build tracker's page,
style sheet and script are read by a frozen test that also reads a record
under ``docs/``, and by tests that need Node.js. The .NET worker's sources and
project files, the R test of the native simulation and the vmmap diagnostic
are read by nothing the image can run. A rebuilt image tree with all twelve
removed passed the complete gate. They are held here to their bytes, in every
tree.

Those twelve values have less behind them than the first three, and it is
said here so that nobody takes them for more. No frozen test states them. A
record under ``docs/solutions`` states three of them, and those three pins are
held to it wherever the record is present. The other nine are stated by one
earlier document only, the source inventory of the handoff of 2026-09-10,
which lists all twelve with the values written below. That inventory is
private: the public distribution does not carry it, so nothing in this suite
may read it, and ``test_public_distribution`` fails a module that names where
it is kept. The comparison with it was made once, by hand, when the values
were written here, and this suite cannot repeat it. What the nine pins do
show is that a file is present and has not changed since.

This does not make every file the image carries a checked file. Seventeen
more are opened by nothing that runs there, and an image without them still
passes. Thirteen are Node.js files under ``tools/``: the console's browser
harnesses and recorders, and ``build_anatomy_vendor.mjs``, the build script
of the console's Three.js vendor bundle. One is a JavaScript fixture of a
test that needs Node.js. The image has no Node.js to run any of those with.
It has no git either, so it cannot run ``tools/build_release.py``, which
builds its archive from a git commit. ``tools/run_review_tests.py`` and
``tools/refresh_scientific_source_catalog.py`` are plain Python that needs
neither, and would run there. What the image can run is not why a file is
pinned here or left out: the pins are for the frozen research tools, and none
of the seventeen is a research tool.
"""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import re
import shutil

import pytest

from ._source_tree import source_tree_only
from . import private_reference_helpers
from tools.public_distribution import is_private_only

REPOSITORY_ROOT = Path(__file__).resolve().parents[2]

ADMITTED_TOOL_SHA256 = {
    "tools/osp_stage_b.py": "a1bb8ac68aa746066f6ecdf9b45e27f77384465c1a114bc250eea96f35e1e0cc",
    "tools/osp_stage_b_native.R": "6a16df63980de72b06c39b21b200de10a7bd04f54405a06c7bf5512a64dc1f37",
    "tools/osp_stage_b_analysis.py": "baa13b3c8dac922c4e87896af2bce9d9892072ddd5a62249a774a021ebafab15",
}
# The frozen test that pins the same three files beside a record under docs/.
FROZEN_MODULE = "test_osp_source_admission.py"
FROZEN_TEST = "test_old_numerical_source_files_stay_exact_without_import"
# Where the source tree writes the three hashes down: its "Preserved artifact" table.
PRESERVATION_RECORD = "docs/solutions/2026-09-08-osp-source-admission-implementation-review.md"

# The frozen files that nothing running in the image opens, and their bytes.
UNOPENED_FILE_SHA256 = {
    "tools/build_tracker/index.html": "6c4ac52d7cade1fe24dd74f6aeb0b7c5c34be0c37f7fa1750a759065c415ad11",
    "tools/build_tracker/tracker.css": "398c47700d76b07efab6030ebbee83d4bb7a456d56df00f035d65fbb8fc757c4",
    "tools/build_tracker/tracker.js": "2f9c2c758b739f1836a596106e5058b76a395e4b78e957bc89b17d087cae5568",
    "tools/diagnostics/osp_vmmap_retained_forensics.py":
        "beab9fe26032a8989e00c0408d53afed1991a989a8e86dc544434a9f407337af",
    "tools/osp_dotnet_worker/Directory.Build.props":
        "a898e7887757dac65f120a3132097fbad1b1d785cf7c9c05c2aad6880f159cad",
    "tools/osp_dotnet_worker/Fixtures.json": "15ab95179ea2c2beb5dfbc9181bfddc0f7f109cd9fe5715d2a93f871ae408023",
    "tools/osp_dotnet_worker/NativeSimulation.cs":
        "23b17fe78f781d8f3bd54c9efd50386cb143cdd7ad4e52fe505fb323f1720364",
    "tools/osp_dotnet_worker/NuGet.Config": "673a6f41c924adb00f8bee519a0539cb2b33b9784d5569362d1e3e5b6fb941cb",
    "tools/osp_dotnet_worker/Worker.csproj": "9993975f483ca566f1f61f8d34185a15851c312d34f68f36844adb0a4099290a",
    "tools/osp_dotnet_worker/global.json": "8fe9f4e7c811472092c6264a786c677dbe383a521b82a3982b257443defcc805",
    "tools/osp_dotnet_worker/tests/FakeTests.csproj":
        "44305da42e7bca05f65bc0ad16061ba97e7509ae6d89625c211cc15bad174023",
    "tools/test_osp_stage_b_native.R": "c0ce29840157e1653ec2f9a4895b5782a39f031095b5c70515afd4891a6357f0",
}
# The three of them that a record the suite may read states, and that record.
RECORDS_STATING_AN_UNOPENED_FILE = {
    "tools/build_tracker/tracker.js": "docs/solutions/2026-09-09-build-tracker-and-replacement-plan.md",
    "tools/diagnostics/osp_vmmap_retained_forensics.py": "docs/solutions/2026-09-09-osp-parser-test-portability.md",
    "tools/osp_dotnet_worker/NativeSimulation.cs": "docs/solutions/2026-09-09-direct-dotnet-worker-plan.md",
}


def tools_that_are_not_the_admitted_bytes(root: Path, pins: dict[str, str] | None = None) -> dict[str, str]:
    """Each pinned tool beneath ``root`` that is absent or altered, and which of the two it is."""
    wrong = {}
    for relative, admitted in (ADMITTED_TOOL_SHA256 if pins is None else pins).items():
        path = root / relative
        if not path.is_file():
            wrong[relative] = "missing"
            continue
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != admitted:
            wrong[relative] = f"sha256 {actual}, admitted {admitted}"
    return wrong


def assert_pinned_file_is_admitted(root: Path, relative: str, admitted: str) -> None:
    """Verify present bytes; only the shared public-reference rule permits absence."""
    path = root / relative
    if not path.exists():
        private_reference_helpers.require_private_reference_data(path, root=root)
    assert tools_that_are_not_the_admitted_bytes(root, {relative: admitted}) == {}


def assert_public_projection_omits_exactly_private_pins(root: Path, pins: dict[str, str]) -> None:
    """The public boundary forbids retained private pins as well as lost public pins."""
    if not private_reference_helpers.is_public_projection(root):
        return
    absent = {relative for relative in pins if not (root / relative).exists()}
    expected = {relative for relative in pins if is_private_only(relative)}
    assert absent == expected, (
        f"PUBLIC_PIN_BOUNDARY: absent pins {sorted(absent)} != policy-private pins {sorted(expected)}")


def test_public_projection_omits_exactly_the_policy_private_pins():
    assert_public_projection_omits_exactly_private_pins(REPOSITORY_ROOT, {
        **ADMITTED_TOOL_SHA256, **UNOPENED_FILE_SHA256})


@pytest.mark.parametrize("tool", sorted(ADMITTED_TOOL_SHA256))
def test_a_frozen_tool_this_tree_carries_is_the_admitted_bytes(tool):
    assert_pinned_file_is_admitted(REPOSITORY_ROOT, tool, ADMITTED_TOOL_SHA256[tool])


@pytest.mark.parametrize("relative", sorted(UNOPENED_FILE_SHA256))
def test_a_frozen_file_nothing_in_the_image_opens_is_the_pinned_bytes(relative):
    assert_pinned_file_is_admitted(REPOSITORY_ROOT, relative, UNOPENED_FILE_SHA256[relative])


# --- the check can fail ---------------------------------------------------
#
# A check that has only ever been seen to pass has not been shown to check
# anything. These run it over copies, never over the tools themselves.

def _copies(tmp_path: Path, pins: dict[str, str] = ADMITTED_TOOL_SHA256) -> Path:
    private_reference_helpers.require_private_reference_data(
        *(REPOSITORY_ROOT / relative for relative in pins), root=REPOSITORY_ROOT)
    for relative in pins:
        target = tmp_path / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPOSITORY_ROOT / relative, target)
    return tmp_path


def test_exact_copies_are_judged_as_the_originals_are(tmp_path):
    assert tools_that_are_not_the_admitted_bytes(_copies(tmp_path)) == {}


@pytest.mark.parametrize("tool", sorted(ADMITTED_TOOL_SHA256))
def test_a_missing_tool_is_reported_and_only_that_one(tmp_path, tool):
    root = _copies(tmp_path)
    (root / tool).unlink()

    assert tools_that_are_not_the_admitted_bytes(root) == {tool: "missing"}


def test_a_directory_where_a_tool_should_be_is_not_a_tool(tmp_path):
    root = _copies(tmp_path)
    (root / "tools/osp_stage_b_native.R").unlink()
    (root / "tools/osp_stage_b_native.R").mkdir()

    assert tools_that_are_not_the_admitted_bytes(root) == {"tools/osp_stage_b_native.R": "missing"}


def _one_byte_changed(content: bytes) -> bytes:
    return bytes([content[0] ^ 1]) + content[1:]


@pytest.mark.parametrize("corrupt", [lambda content: content + b"\n", lambda content: content[:-1],
                                     lambda content: b"", _one_byte_changed],
                         ids=["a byte appended", "a byte dropped", "emptied", "one bit flipped"])
@pytest.mark.parametrize("tool", sorted(ADMITTED_TOOL_SHA256))
def test_a_corrupted_tool_is_reported_and_only_that_one(tmp_path, tool, corrupt):
    root = _copies(tmp_path)
    altered = corrupt((root / tool).read_bytes())
    (root / tool).write_bytes(altered)

    assert tools_that_are_not_the_admitted_bytes(root) == {
        tool: f"sha256 {hashlib.sha256(altered).hexdigest()}, admitted {ADMITTED_TOOL_SHA256[tool]}"}


@pytest.mark.parametrize("relative", sorted(UNOPENED_FILE_SHA256))
def test_an_unopened_file_that_is_missing_or_altered_is_reported_and_only_that_one(tmp_path, relative):
    root = _copies(tmp_path, UNOPENED_FILE_SHA256)
    assert tools_that_are_not_the_admitted_bytes(root, UNOPENED_FILE_SHA256) == {}

    altered = (root / relative).read_bytes() + b"\n"
    (root / relative).write_bytes(altered)
    assert tools_that_are_not_the_admitted_bytes(root, UNOPENED_FILE_SHA256) == {
        relative: f"sha256 {hashlib.sha256(altered).hexdigest()}, admitted {UNOPENED_FILE_SHA256[relative]}"}

    (root / relative).unlink()
    assert tools_that_are_not_the_admitted_bytes(root, UNOPENED_FILE_SHA256) == {relative: "missing"}


# --- the three statements of the pins agree --------------------------------

def _pins_of_the_frozen_test() -> dict[str, str]:
    """The ``pins`` literal of the frozen test, read from its source and not by running it."""
    path = Path(__file__).parent / FROZEN_MODULE
    private_reference_helpers.require_private_reference_data(path, root=REPOSITORY_ROOT)
    (function,) = [node for node in ast.parse(path.read_text(encoding="utf-8"), filename=str(path)).body
                   if isinstance(node, ast.FunctionDef) and node.name == FROZEN_TEST]
    (pins,) = [statement.value for statement in function.body
               if isinstance(statement, ast.Assign)
               and [getattr(target, "id", None) for target in statement.targets] == ["pins"]]
    return ast.literal_eval(pins)


def test_these_pins_are_the_frozen_tests_own():
    """Held wherever the frozen module is carried, including private images.

    Whatever else that test pins has to be a record under ``docs/``. A product
    file it pinned and this module did not would be unchecked in the image
    again.
    """
    frozen = _pins_of_the_frozen_test()

    assert {name: digest for name, digest in frozen.items() if not name.startswith("docs/")} == ADMITTED_TOOL_SHA256
    assert len(frozen) > len(ADMITTED_TOOL_SHA256)


@source_tree_only(PRESERVATION_RECORD)
def test_these_pins_are_the_ones_the_source_tree_records():
    """The only comparison here that needs a file the image does not carry."""
    path = REPOSITORY_ROOT / PRESERVATION_RECORD
    private_reference_helpers.require_private_reference_data(path, root=REPOSITORY_ROOT)
    record = path.read_text(encoding="utf-8")

    for tool, digest in ADMITTED_TOOL_SHA256.items():
        assert f"| `{tool}` | `{digest}` |" in record, tool


@source_tree_only(*sorted(RECORDS_STATING_AN_UNOPENED_FILE.values()))
def test_the_three_unopened_files_a_record_states_are_pinned_to_what_it_states():
    """Each record names the file and gives its SHA-256 in the same sentence or table row."""
    private_reference_helpers.require_private_reference_data(
        *(REPOSITORY_ROOT / record for record in RECORDS_STATING_AN_UNOPENED_FILE.values()), root=REPOSITORY_ROOT)
    for relative, record in RECORDS_STATING_AN_UNOPENED_FILE.items():
        stated = " ".join((REPOSITORY_ROOT / record).read_text(encoding="utf-8").split())
        name, digest = Path(relative).name, UNOPENED_FILE_SHA256[relative]

        assert re.search(rf"{re.escape(name)}`?(?: SHA256| is| \|) `?{digest}\b", stated), (relative, record)


def test_the_two_sets_of_pins_do_not_overlap():
    assert not set(ADMITTED_TOOL_SHA256) & set(UNOPENED_FILE_SHA256)
    assert set(RECORDS_STATING_AN_UNOPENED_FILE) < set(UNOPENED_FILE_SHA256)


# Synthetic pins keep the negative controls executable when the publisher has
# intentionally omitted the historical research originals.
def _synthetic_public_pins(root: Path) -> dict[str, str]:
    pins = {}
    for relative in ("tools/osp_boundary_fixture.py", "tools/carried_boundary_fixture.py"):
        content = (relative + "\n").encode()
        path = root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        pins[relative] = hashlib.sha256(content).hexdigest()
    (root / ".livemore-distribution.json").write_text(json.dumps({
        "schema": "livemore.distribution.v1", "audience": "public"}), encoding="utf-8")
    return pins


def test_public_pin_boundary_accepts_exactly_the_policy_omissions(tmp_path):
    pins = _synthetic_public_pins(tmp_path)
    (tmp_path / "tools/osp_boundary_fixture.py").unlink()
    assert_public_projection_omits_exactly_private_pins(tmp_path, pins)
    assert_pinned_file_is_admitted(tmp_path, "tools/carried_boundary_fixture.py", pins["tools/carried_boundary_fixture.py"])


def test_public_pin_boundary_rejects_a_retained_excluded_file(tmp_path):
    pins = _synthetic_public_pins(tmp_path)
    with pytest.raises(AssertionError, match="PUBLIC_PIN_BOUNDARY"):
        assert_public_projection_omits_exactly_private_pins(tmp_path, pins)


def test_public_pin_boundary_rejects_a_lost_carried_file(tmp_path):
    pins = _synthetic_public_pins(tmp_path)
    for relative in pins:
        (tmp_path / relative).unlink()
    with pytest.raises(AssertionError, match="PUBLIC_PIN_BOUNDARY"):
        assert_public_projection_omits_exactly_private_pins(tmp_path, pins)
    try:
        with pytest.raises(AssertionError, match="not a private reference"):
            assert_pinned_file_is_admitted(tmp_path, "tools/carried_boundary_fixture.py", pins["tools/carried_boundary_fixture.py"])
    except pytest.skip.Exception:
        pytest.fail("a missing carried file must fail, not skip")


def test_a_policy_omitted_pin_skips_only_that_check_with_the_stated_reason(tmp_path):
    pins = _synthetic_public_pins(tmp_path)
    relative = "tools/osp_boundary_fixture.py"
    (tmp_path / relative).unlink()
    with pytest.raises(pytest.skip.Exception, match="REFERENCE_DATA_NOT_DISTRIBUTED"):
        assert_pinned_file_is_admitted(tmp_path, relative, pins[relative])


@pytest.mark.parametrize("relative", ["tools/osp_boundary_fixture.py", "tools/carried_boundary_fixture.py"])
@pytest.mark.parametrize("marker", [True, False], ids=["public", "private"])
def test_present_synthetic_pins_are_hash_checked_in_every_tree(tmp_path, relative, marker):
    pins = _synthetic_public_pins(tmp_path)
    if not marker:
        (tmp_path / ".livemore-distribution.json").unlink()
    assert_pinned_file_is_admitted(tmp_path, relative, pins[relative])
    (tmp_path / relative).write_bytes(b"altered")
    with pytest.raises(AssertionError, match="sha256"):
        assert_pinned_file_is_admitted(tmp_path, relative, pins[relative])


@pytest.mark.parametrize("context", ["unmarked", "wrong-schema", "wrong-audience", "git-directory", "git-file", "malformed-marker"])
def test_a_missing_private_pin_fails_outside_a_publisher_public_projection(tmp_path, monkeypatch, context):
    pins = _synthetic_public_pins(tmp_path)
    relative = "tools/osp_boundary_fixture.py"
    (tmp_path / relative).unlink()
    marker = tmp_path / ".livemore-distribution.json"
    if context == "unmarked":
        marker.unlink()
    elif context == "wrong-schema":
        marker.write_text(json.dumps({"schema": "wrong", "audience": "public"}), encoding="utf-8")
    elif context == "wrong-audience":
        marker.write_text(json.dumps({"schema": "livemore.distribution.v1", "audience": "private"}), encoding="utf-8")
    elif context == "git-directory":
        (tmp_path / ".git").mkdir()
    elif context == "git-file":
        (tmp_path / ".git").write_text("gitdir: synthetic-worktree", encoding="utf-8")
    else:
        marker.write_text("{", encoding="utf-8")
    monkeypatch.setenv("LIVEMORE_TEST_TREE", "container-image")
    assert not private_reference_helpers.is_public_projection(tmp_path)
    assert not private_reference_helpers.private_reference_is_omitted(tmp_path / relative, root=tmp_path)
    try:
        with pytest.raises(AssertionError, match="PRIVATE_REFERENCE_MISSING"):
            assert_pinned_file_is_admitted(tmp_path, relative, pins[relative])
    except pytest.skip.Exception:
        pytest.fail("a missing private pin outside the public projection must fail, never skip")


def test_public_projection_identity_and_policy_compose_for_an_image(tmp_path, monkeypatch):
    _synthetic_public_pins(tmp_path)
    monkeypatch.setenv("LIVEMORE_TEST_TREE", "container-image")
    private_path = tmp_path / "tools/osp_boundary_fixture.py"
    assert private_reference_helpers.is_public_projection(tmp_path)
    assert not private_reference_helpers.private_reference_is_omitted(private_path, root=tmp_path)
    private_path.unlink()
    assert private_reference_helpers.private_reference_is_omitted(private_path, root=tmp_path)
    carried_path = tmp_path / "tools/carried_boundary_fixture.py"
    carried_path.unlink()
    assert not private_reference_helpers.private_reference_is_omitted(carried_path, root=tmp_path)
    (tmp_path / ".livemore-distribution.json").unlink()
    assert not private_reference_helpers.is_public_projection(tmp_path)
    assert not private_reference_helpers.private_reference_is_omitted(private_path, root=tmp_path)
