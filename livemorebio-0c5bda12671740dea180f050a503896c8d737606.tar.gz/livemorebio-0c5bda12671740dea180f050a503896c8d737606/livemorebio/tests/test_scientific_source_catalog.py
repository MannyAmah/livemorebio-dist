"""Governed NAR/ELIXIR source catalog and backend boundary tests."""
from __future__ import annotations

from dataclasses import dataclass

import networkx as nx
import pytest

from livemorebio.scientific_sources import (
    Catalog,
    Lifecycle,
    SourceRecord,
    Workflow,
)
from livemorebio.scientific_sources.graph_backends import (
    Neo4jBackend,
    backend_registry,
)


def test_catalog_snapshot_covers_official_collections_without_claiming_integration():
    catalog = Catalog.load()
    report = catalog.report(limit=5)

    assert report["schema"] == "livemore.scientific-source-catalog.v1"
    assert report["collections"]["elixir"]["declared_count"] == 39
    assert report["collections"]["elixir"]["cataloged_count"] == 39
    assert report["collections"]["nar"]["declared_count"] == 2173
    assert report["collections"]["nar"]["cataloged_count"] >= 2173
    assert report["collections"]["nar"]["record_kind"] == "summary_entry"
    assert report["collections"]["nar"]["deduplication_note"]

    nar = next(record for record in catalog.records if record.collection == "nar")
    assert nar.lifecycle is Lifecycle.CATALOGED
    assert nar.license == "unknown_requires_source_review"
    assert nar.permitted_use == "catalog_metadata_only"


def test_source_lifecycle_is_monotonic_and_requires_gate_evidence():
    record = SourceRecord(
        source_id="test:source",
        name="Test source",
        collection="test",
        lifecycle=Lifecycle.CATALOGED,
        provenance_url="https://example.test/source",
        license="unknown_requires_source_review",
        permitted_use="catalog_metadata_only",
    )
    catalog = Catalog.from_records([record])

    with pytest.raises(ValueError, match="next lifecycle stage"):
        catalog.promote("test:source", Lifecycle.CONFIGURED, evidence="adapter exists")
    with pytest.raises(ValueError, match="evidence"):
        catalog.promote("test:source", Lifecycle.EVALUATED, evidence="")

    promoted = catalog.promote(
        "test:source", Lifecycle.EVALUATED, evidence="license review LGL-001",
    )
    assert promoted.lifecycle is Lifecycle.EVALUATED
    assert promoted.lifecycle_evidence[-1]["evidence"] == "license review LGL-001"
    with pytest.raises(ValueError, match="cannot move backwards"):
        catalog.promote("test:source", Lifecycle.CATALOGED, evidence="rollback")


def _admit_probe_evidence(monkeypatch):
    from livemorebio import adapters
    monkeypatch.setattr(adapters, "_PROBE_RESULTS", {})
    monkeypatch.setattr(adapters, "_probe_url", lambda *_: "ready")
    adapters.statuses(probe=True)


def test_runtime_router_returns_only_workflow_wired_sources(monkeypatch):
    _admit_probe_evidence(monkeypatch)
    catalog = Catalog.load()

    routed = catalog.route(Workflow.REACTIONS_METABOLISM)
    assert routed
    assert any(record.source_id == "adapter:reactome" for record in routed)
    assert all(record.lifecycle.rank >= Lifecycle.WORKFLOW_WIRED.rank for record in routed)
    assert not any(record.source_id.startswith("nar:") for record in routed)


def test_reference_retrieval_never_promotes_evidence_class(monkeypatch):
    _admit_probe_evidence(monkeypatch)
    catalog = Catalog.load()
    routed = catalog.route(Workflow.DRUG_DISCOVERY)

    assert routed
    assert all(record.evidence_class == "reference" for record in routed)
    assert all(record.output_evidence_ceiling == "reference_backed" for record in routed)


def test_backend_registry_is_fail_closed(monkeypatch):
    for name in ("NEO4J_URI", "NEO4J_USERNAME", "NEO4J_PASSWORD", "TURINGDB_ENDPOINT"):
        monkeypatch.delenv(name, raising=False)

    registry = backend_registry()
    assert registry["networkx"]["state"] == "operational"
    assert registry["networkx"]["intended_use"] == "development_and_deterministic_tests"
    assert registry["neo4j"]["state"] == "evaluated"
    assert registry["neo4j"]["configured"] is False
    assert registry["turingdb"]["state"] == "evaluated"
    assert registry["turingdb"]["license_gate"] == "pending_commercial_clearance"


class _FakeSession:
    def __init__(self):
        self.calls = []

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def run(self, statement, **parameters):
        self.calls.append((statement, parameters))


class _FakeDriver:
    def __init__(self):
        self.session_instance = _FakeSession()
        self.closed = False

    def session(self):
        return self.session_instance

    def close(self):
        self.closed = True


_SYNTHETIC_GRAPH_TEXT = "SYNTHETIC Zelmori Trassendel female age 63 SYN-9362 T2D"


class _DisguisedGraphText(str):
    def split(self, *_args, **_kwargs):
        return ["metformin"]


def _allowed_neo4j_graph():
    graph = nx.Graph()
    graph.add_node("KCNH2", kind="Gene", name="KCNH2")
    graph.add_node("CHEMBL25", kind="Drug", name="metformin")
    graph.add_edge("KCNH2", "CHEMBL25", rel="ASSOCIATED_WITH", score=0.5)
    return graph


@pytest.mark.parametrize("position", [
    "node_value", "node_key", "last_node", "edge_value", "edge_key",
    "nested_list", "nested_map_value", "nested_map_key", "source_key", "label", "relationship",
    "custom_string",
])
def test_neo4j_refuses_every_unadmitted_string_before_driver(position):
    from livemorebio.egress import EgressRefused

    graph = _allowed_neo4j_graph()
    text = _SYNTHETIC_GRAPH_TEXT
    if position == "node_value":
        graph.nodes["KCNH2"]["name"] = text
    elif position == "custom_string":
        graph.nodes["KCNH2"]["name"] = _DisguisedGraphText(text)
    elif position == "node_key":
        graph.nodes["KCNH2"][text] = "KCNH2"
    elif position == "last_node":
        graph.add_node("CHEMBL26", kind="Drug", name=text)
    elif position == "edge_value":
        graph.edges["KCNH2", "CHEMBL25"]["source"] = text
    elif position == "edge_key":
        graph.edges["KCNH2", "CHEMBL25"][text] = "metformin"
    elif position == "nested_list":
        graph.nodes["KCNH2"]["name"] = ["metformin", text]
    elif position == "nested_map_value":
        graph.nodes["KCNH2"]["name"] = {"name": text}
    elif position == "nested_map_key":
        graph.nodes["KCNH2"]["name"] = {text: "metformin"}
    elif position == "source_key":
        graph = nx.relabel_nodes(graph, {"KCNH2": text})
    elif position == "label":
        graph.nodes["KCNH2"]["kind"] = "SYNTHETIC_R17_UnknownLabel"
    elif position == "relationship":
        graph.edges["KCNH2", "CHEMBL25"]["rel"] = "SYNTHETIC_R17_UnknownRelationship"
    driver = _FakeDriver()
    creations = []

    def factory(*_args, **_kwargs):
        creations.append(True)
        return driver

    backend = Neo4jBackend(uri="bolt://example.test:7687", username="technical",
                           password="fixture-only", driver_factory=factory)
    refused = False
    safe_error = False
    try:
        backend.sync(graph)
    except EgressRefused as error:
        refused = error.code == "EGRESS_VALUE_NOT_ALLOWED"
        safe_error = text not in str(error) and text not in str(error.payload())
    assert refused, "unadmitted graph string was not refused"
    assert safe_error, "refusal exposed the rejected string"
    assert not creations, "driver was created before complete graph admission"
    assert not driver.session_instance.calls, "unadmitted graph reached the stub session"


def test_neo4j_sends_the_admitted_snapshot_despite_caller_mutation():
    graph = _allowed_neo4j_graph()
    graph.nodes["KCNH2"]["name"] = ["metformin"]
    driver = _FakeDriver()

    def factory(*_args, **_kwargs):
        graph.nodes["KCNH2"]["name"].append(_SYNTHETIC_GRAPH_TEXT)
        graph.edges["KCNH2", "CHEMBL25"]["source"] = _SYNTHETIC_GRAPH_TEXT
        return driver

    backend = Neo4jBackend(uri="bolt://example.test:7687", username="technical",
                           password="fixture-only", driver_factory=factory)
    result = backend.sync(graph)
    sent_note = _SYNTHETIC_GRAPH_TEXT in str(driver.session_instance.calls)
    assert not sent_note, "caller mutation changed the admitted payload"
    assert result == {"loaded": True, "nodes": 2, "edges": 1}
    assert len(driver.session_instance.calls) == 3
    assert driver.closed


def test_neo4j_refuses_custom_copy_hooks_before_driver():
    from livemorebio.egress import EgressRefused

    shared = ["metformin"]
    copy_attempts = []

    class CustomCopier:
        def __deepcopy__(self, memo):
            copy_attempts.append(True)
            return shared

    graph = _allowed_neo4j_graph()
    graph.nodes["KCNH2"]["name"] = CustomCopier()
    driver = _FakeDriver()
    creations = []

    def factory(*_args, **_kwargs):
        creations.append(True)
        shared.append(_SYNTHETIC_GRAPH_TEXT)
        return driver

    backend = Neo4jBackend(uri="bolt://example.test:7687", username="technical",
                           password="fixture-only", driver_factory=factory)
    refused = False
    try:
        backend.sync(graph)
    except EgressRefused:
        refused = True
    assert refused, "custom copier was not refused before graph export"
    assert not copy_attempts, "export invoked an unchecked custom copy hook"
    assert not creations, "custom copier reached the stub driver"
    assert not driver.session_instance.calls, "custom copier reached the stub session"


def test_neo4j_runtime_knowledge_cannot_expand_export_vocabulary(monkeypatch):
    from livemorebio import egress
    from livemorebio.life_system import knowledge

    modified = knowledge.KnowledgeBase()
    modified.diseases[0]["name"] = _SYNTHETIC_GRAPH_TEXT
    monkeypatch.setattr(knowledge, "_KB", modified)
    egress.vocabulary.cache_clear()
    graph = _allowed_neo4j_graph()
    graph.nodes["KCNH2"]["name"] = _SYNTHETIC_GRAPH_TEXT
    creations = []

    def factory(*_args, **_kwargs):
        creations.append(True)
        return _FakeDriver()

    backend = Neo4jBackend(uri="bolt://example.test:7687", username="technical",
                           password="fixture-only", driver_factory=factory)
    refused = False
    try:
        backend.sync(graph)
    except egress.EgressRefused:
        refused = True
    finally:
        egress.vocabulary.cache_clear()
    assert refused, "runtime knowledge expanded the export vocabulary"
    assert not creations, "runtime knowledge reached the stub driver"


def test_neo4j_backend_uses_parameterized_writes_and_closes_driver():
    # L0-R17: arbitrary quoted names are now refused before driver creation;
    # admitted identifiers still use parameters rather than Cypher interpolation.
    graph = _allowed_neo4j_graph()
    driver = _FakeDriver()
    backend = Neo4jBackend(
        uri="bolt://example.test:7687",
        username="neo4j",
        password="not-a-real-secret",
        driver_factory=lambda *_args, **_kwargs: driver,
    )

    result = backend.sync(graph)

    assert result == {"loaded": True, "nodes": 2, "edges": 1}
    assert driver.closed is True
    assert driver.session_instance.calls
    assert all("KCNH2" not in statement for statement, _ in driver.session_instance.calls)
    assert any(
        parameters.get("properties", {}).get("name") == "KCNH2"
        for _, parameters in driver.session_instance.calls
    )


def test_scientific_source_api_is_bounded_and_workflow_routed(monkeypatch):
    fastapi = pytest.importorskip("fastapi")
    from fastapi.testclient import TestClient
    from livemorebio.aegle.server import app

    token = "technical-scientific-source-catalog-token"
    monkeypatch.setenv("LIVEMORE_API_TOKEN", token)
    response = TestClient(app).get(
        "/api/scientific-sources?workflow=reactions_metabolism&limit=10",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["schema"] == "livemore.scientific-source-catalog.v1"
    assert len(body["sources"]) <= 10
    assert body["query"]["workflow"] == "reactions_metabolism"
    assert all(
        source["lifecycle"] in {"workflow_wired", "scientifically_qualified"}
        for source in body["sources"]
    )


def test_sdk_and_shell_expose_governed_workflow_sources(monkeypatch):
    _admit_probe_evidence(monkeypatch)
    from livemorebio.sdk import Platform
    from livemorebio.shell import run_command

    platform = Platform(mode="inprocess")
    report = platform.scientific_sources(workflow="reactions_metabolism", limit=10)
    assert report["total"] >= 1
    assert all(source["lifecycle"] == "workflow_wired" for source in report["sources"])

    output = []
    run_command(platform, "sources workflow=reactions_metabolism limit=10", output.append)
    assert any("reactions_metabolism" in line for line in output)
    assert any("Reactome" in line for line in output)


def test_unprobed_or_expired_transport_is_not_workflow_ready(monkeypatch):
    from livemorebio import adapters
    monkeypatch.setattr(adapters, "_PROBE_RESULTS", {})
    assert Catalog.load().get("adapter:reactome").lifecycle is Lifecycle.CONFIGURED
    _admit_probe_evidence(monkeypatch)
    assert Catalog.load().get("adapter:reactome").lifecycle is Lifecycle.WORKFLOW_WIRED
    monkeypatch.setattr(adapters, "_PROBE_RESULTS", {
        key: (stamp - 301, status) for key, (stamp, status) in adapters._PROBE_RESULTS.items()})
    assert Catalog.load().get("adapter:reactome").lifecycle is Lifecycle.CONFIGURED


def test_adapter_page_exposes_catalog_lifecycle_and_workflow_controls():
    pytest.importorskip("fastapi")
    from fastapi.testclient import TestClient
    from livemorebio.aegle.server import app

    page = TestClient(app).get("/adapters")
    assert page.status_code == 200
    assert 'id="catalogSummary"' in page.text
    assert 'id="source-workflows"' in page.text
    assert "/api/scientific-sources" in page.text
    assert "scientifically_qualified" in page.text
