"""Frozen scientific inspection must retain identity, native axes and missingness."""
from __future__ import annotations

import json
from pathlib import Path
import subprocess

import pytest
from ._node import require_node, run_node as _run_node

MODULE = Path(__file__).parents[1] / "aegle/console/lib/biological_projection.js"


def project(run: dict, selection: dict | None = None) -> dict:
    node = require_node()
    program = (
        f"import {{protocolInspection}} from {json.dumps(MODULE.as_uri())};"
        f"try {{process.stdout.write(JSON.stringify(protocolInspection({json.dumps(run)},"
        f"{json.dumps(selection or {})})));}} catch(e) {{process.stdout.write(JSON.stringify({{error:e.message}}));}}"
    )
    result = _run_node([node, "--input-type=module", "--eval", program],
                            check=True, capture_output=True, text=True, timeout=10, encoding="utf-8")
    return json.loads(result.stdout)


@pytest.fixture
def metformin() -> dict:
    return {
        "run_id": "protocol-" + "a" * 32,
        "protocol_id": "cendos.metformin-cohort-comparison.v1",
        "executed_at": "2026-09-08T12:00:00Z", "evidence_state": "MODELED_MECHANISTIC",
        "qualification_state": "NOT_QUALIFIED", "input_sha256": "input-digest",
        "intervention": {"compound": "metformin", "dose_mg": 500, "ogtt_grams": 75},
        "cohorts": [{"cohort_id": "cohort-a", "name": "Technical reference",
            "reference_source": {"id": "reference-a"}, "members": [{
                "member_id": "member-a", "source_lineage": {"parameter_source": "prior-a"},
                "trajectory": {"t_min": [0, 2.5, 9],
                    "baseline": {"glucose": [90, 120, 95], "insulin": [8, 20, 10], "insulin_action": [0, .003, .001]},
                    "treated": {"glucose": [90, 130, 95], "insulin": [8, 21, 10], "insulin_action": [0, .002, .001]},
                    "units": {"t_min": "min", "glucose": "mg/dL", "insulin": "uU/mL", "insulin_action": "1/min"}},
            }]}],
    }


def test_saved_insulin_action_has_same_run_member_time_and_source(metformin):
    result = project(metformin, {"memberId": "member-a", "quantity": "insulin_action", "timeIndex": 1})
    assert result["binding"] == {"run_id": metformin["run_id"], "protocol_id": metformin["protocol_id"],
                                 "member_id": "member-a", "cohort_id": "cohort-a", "condition_id": None}
    assert result["axis"] == {"kind": "recorded_time", "unit": "min", "index": 1, "value": 2.5, "count": 3}
    assert result["quantity"]["baseline"] == .003
    assert result["quantity"]["treated"] == .002
    assert result["quantity"]["unit"] == "1/min"
    assert result["source_class"] == "MODELED"
    assert result["freshness"] == "FROZEN_RECORD"
    assert result["provenance"]["member_source_lineage"] == {"parameter_source": "prior-a"}
    assert result["provenance"]["input_sha256"] == "input-digest"


def test_zero_flat_and_adverse_values_are_not_replaced(metformin):
    assert project(metformin, {"quantity": "insulin_action"})["quantity"]["treated"] == 0
    result = project(metformin, {"timeIndex": 1})
    assert result["quantity"]["treated"] == 130
    assert result["quantity"]["baseline"] == 120
    assert project(metformin, {"timeIndex": 2})["quantity"]["treated"] == 95


@pytest.mark.parametrize("change", ["missing", "boolean", "length", "wrong_unit"])
def test_bad_or_absent_quantity_remains_unavailable(metformin, change):
    trajectory = metformin["cohorts"][0]["members"][0]["trajectory"]
    if change == "missing":
        del trajectory["treated"]["insulin_action"]
    elif change == "boolean":
        trajectory["treated"]["insulin_action"][1] = True
    elif change == "length":
        trajectory["treated"]["insulin_action"] = [0]
    else:
        trajectory["units"]["insulin_action"] = "mg/dL"
    result = project(metformin, {"quantity": "insulin_action", "timeIndex": 1})
    assert result["quantity"]["status"] == "UNAVAILABLE"
    assert result["quantity"]["treated"] is None
    assert result["quantity"]["reason"]


@pytest.mark.parametrize("selection", [{"memberId": "missing"}, {"timeIndex": 10},
                                       {"timeIndex": True}, {"quantity": "__proto__"}])
def test_invalid_selection_fails_closed(metformin, selection):
    assert "error" in project(metformin, selection)


def test_duplicate_member_identity_and_invalid_time_axis_fail_closed(metformin):
    member = metformin["cohorts"][0]["members"][0]
    member["trajectory"]["t_min"] = [0, 9, 2.5]
    assert "error" in project(metformin)
    member["trajectory"]["t_min"] = [0, 2.5, 9]
    metformin["cohorts"][0]["members"].append(member)
    assert "error" in project(metformin)


def test_unsupported_stages_never_borrow_a_computed_quantity(metformin):
    result = project(metformin, {"stageId": "cellular"})
    assert result["stage"]["status"] == "UNAVAILABLE"
    assert result["quantity"] is None
    assert result["series"] is None
    assert "signaling" in result["stage"]["reason"]


def test_unrecognized_evidence_state_cannot_turn_numerical_result_observed(metformin):
    metformin["evidence_state"] = "OBSERVED_PHYSICAL"
    assert "error" in project(metformin)


def test_pxr_uses_selected_member_condition_and_no_time_axis():
    run = {"run_id": "protocol-" + "b" * 32, "protocol_id": "cendos.garcinoic-acid-pxr.v1",
           "evidence_state": "STRUCTURE_AND_IN_VITRO_BACKED_MODEL", "qualification_state": "NOT_QUALIFIED",
           "cohort": {"cohort_id": "cohort-p", "name": "PXR prior", "reference_source": {"id": "source-p"}},
           "target_engagement": [{"concentration_um": 1.3, "mean_occupancy": .8, "members": [
               {"member_id": "a", "nr1i2_expression_factor": .5, "relative_pxr_activation": .25},
               {"member_id": "b", "nr1i2_expression_factor": 1.5, "relative_pxr_activation": .75}]}]}
    result = project(run, {"memberId": "b"})
    assert result["axis"] == {"kind": "recorded_condition", "unit": "uM", "index": 0, "value": 1.3, "count": 1}
    assert result["quantity"]["value"] == .75
    assert result["series"] is None
    assert result["binding"]["member_id"] == "b"
    assert project(run, {"memberId": "b", "stageId": "downstream"})["quantity"] is None


def test_legacy_endpoint_only_run_does_not_invent_a_time_axis(metformin):
    del metformin["cohorts"][0]["members"][0]["trajectory"]
    result = project(metformin)
    assert result["axis"] is None
    assert result["quantity"]["status"] == "UNAVAILABLE"
    assert result["series"] is None


def test_atlas_inspection_link_requires_bound_context_and_keeps_scale():
    node = require_node()
    script = f'''import {{atlasInspectionLink}} from {json.dumps(MODULE.as_uri())};
      process.stdout.write(JSON.stringify([
        atlasInspectionLink({{context_id:'a'.repeat(64)}},'cell.cardiomyocyte'),
        atlasInspectionLink({{}},'organ.heart'),
        atlasInspectionLink({{context_id:'a'.repeat(64)}},'gene.slc22a1')
      ]));'''
    result = _run_node([node, "--input-type=module", "--eval", script], capture_output=True, text=True, timeout=10, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    links = json.loads(result.stdout)
    assert links[0] == "/biology?context_id=" + "a" * 64 + "&organ_id=heart&inspect=cell"
    assert links[1] is None
    assert "organ_id=liver" in links[2]
