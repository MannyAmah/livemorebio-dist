"""Scientific integrity regressions: unsupported effects and admitted parameter identity."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient
from livemorebio.tests.cendos_source_fixtures import no_cendos_peer_network, technical_source  # noqa: F401


def _human(**changes):
    from livemorebio.aegle.subjects import AdmittedHuman

    values = dict(id="fixture-001", display_label="Non-PHI fixture", age=55, sex="F",
                  conditions=[], genome={}, lifestyle=0.5, observations={}, model_parameters={})
    values.update(changes)
    return AdmittedHuman(**values)


def _observation(value=7.0, unit="mmol/L", **changes):
    return dict(value=value, unit=unit, captured_at="2026-08-31T12:00:00Z",
                source="local-assay-fixture", quality_status="verified", **changes)


@pytest.mark.parametrize("name", ["unknown-compound", "bitter kola", "taurine"])
def test_unqualified_compounds_cannot_receive_default_benefits(name):
    from livemorebio.engines import pharmacology
    from livemorebio.engines.metabolic.glucose_insulin import T2D

    before = asdict(T2D)
    with pytest.raises(ValueError, match="qualified"):
        pharmacology.plant_compound(T2D, name=name)
    assert asdict(T2D) == before


def test_explicit_generic_effect_sliders_do_not_qualify_a_compound():
    from livemorebio.engines.metabolic.glucose_insulin import T2D
    from livemorebio.engines.metabolic.interventions import plant_compound

    with pytest.raises(ValueError, match="qualified"):
        plant_compound(T2D, name="plant", si_boost=0.35, gb_drop=0.08)


@pytest.mark.parametrize("route", ["/assay/ogtt", "/assay/current"])
def test_standalone_cendos_rejects_unqualified_compound(route, monkeypatch):
    from livemorebio.cendos.service import app

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "integrity-test-token")
    result = TestClient(app).post(route, json={"drug": "invented-plant"},
                                  headers={"Authorization": "Bearer integrity-test-token"})
    assert result.status_code == 422
    assert result.json()["code"] == "UNSUPPORTED_BIOLOGICAL_INTERVENTION"


def test_reference_twin_activation_preserves_every_frozen_parameter(tmp_path, monkeypatch):
    from livemorebio.aegle.subjects import SubjectRegistry
    from livemorebio.aegle import runtime

    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"p" * 32)
    record = registry.create_twin({
        "source_class": "REFERENCE_GROUNDED_SYNTHETIC", "subject_id": "pseudonym-reference-001",
        "display_label": "Reference fixture", "seed": 31, "stratum": "dpp-high-risk-metabolic",
        "reference_source": {"source_id": "livemore-public-metabolic-reference-v1",
                             "role": "population_reference"},
    })
    monkeypatch.setattr(runtime, "AegleTwin", lambda human: SimpleNamespace(
        human=human, profile=human.metabolic_profile(None)))
    twin = registry.build_twin(record)
    for field, expected in record["model_parameters"].items():
        assert getattr(twin.profile, field) == expected
    assert twin.profile.name == record["display_label"]


def _assert_missing_binding(human):
    from livemorebio.aegle.model_contexts import ModelContextError

    with pytest.raises(ModelContextError) as caught:
        human.metabolic_profile(None)
    assert caught.value.code == "MODEL_BINDING_REQUIRED"


def test_fasting_observation_is_normalized_without_authorizing_a_model():
    from livemorebio.aegle.clinical_parameters import normalize_observation

    observation = _observation()
    normalized = normalize_observation("fasting_glucose_mgdl", observation)
    assert normalized["value"] == pytest.approx(126.1094, abs=0.001)
    assert normalized["unit"] == "mg/dL"
    assert normalized["original_value"] == 7.0 and normalized["original_unit"] == "mmol/L"
    for field in ("source", "captured_at", "quality_status"):
        assert normalized[field] == observation[field]
    assert observation == _observation()
    _assert_missing_binding(_human(observations={"fasting_glucose_mgdl": observation}))


def test_random_glucose_is_not_a_fasting_setpoint():
    from livemorebio.aegle.clinical_parameters import validate_clinical_inputs

    observation = _observation(value=180, unit="mg/dL")
    for context in (None, "random"):
        candidate = {**observation, **({"sampling_context": context} if context else {})}
        values, provenance = validate_clinical_inputs(observations={"glucose_mgdl": candidate}, model_parameters={})
        assert values == {} and provenance == {}
        _assert_missing_binding(_human(observations={"glucose_mgdl": candidate}))
    values, provenance = validate_clinical_inputs(
        observations={"glucose_mgdl": {**observation, "sampling_context": "fasting"}}, model_parameters={})
    assert values == {"Gb": 180.0} and set(provenance) == {"Gb"}
    assert observation == _observation(value=180, unit="mg/dL")


@pytest.mark.parametrize("field,value", [
    ("unit", "mL"), ("captured_at", "yesterday"),
    ("captured_at", "2026-08-31T12:00:00"), ("quality_status", "fail"),
])
def test_bad_clinical_observations_cannot_set_engine_parameters(field, value):
    from livemorebio.aegle.clinical_parameters import normalize_observation, validate_clinical_inputs
    from livemorebio.aegle.model_contexts import ModelContextError

    observation = _observation()
    observation[field] = value
    reason = {"unit": "unit is incompatible", "captured_at": "captured_at", "quality_status": "quality did not pass"}[field]
    for validate in (
        lambda: normalize_observation("fasting_glucose_mgdl", observation),
        lambda: validate_clinical_inputs(observations={"fasting_glucose_mgdl": observation}, model_parameters={}),
    ):
        with pytest.raises(ValueError, match=reason) as caught:
            validate()
        assert not isinstance(caught.value, ModelContextError)
    assert observation[field] == value
    _assert_missing_binding(_human(observations={"fasting_glucose_mgdl": observation}))


def test_unassessed_observation_is_retained_without_initializing_biology():
    from livemorebio.aegle.clinical_parameters import normalize_observation, validate_clinical_inputs

    observation = _observation(value=150, unit="mg/dL")
    observation["quality_status"] = "not_assessed"
    human = _human(observations={"fasting_glucose_mgdl": observation})
    normalized = normalize_observation("fasting_glucose_mgdl", observation)
    assert normalized["value"] == 150 and normalized["mapping_eligible"] is False
    for field in ("source", "captured_at", "quality_status"):
        assert normalized[field] == observation[field]
    assert validate_clinical_inputs(observations=human.observations, model_parameters={}) == ({}, {})
    assert human.observations["fasting_glucose_mgdl"]["value"] == 150
    assert human.observations["fasting_glucose_mgdl"] == observation
    _assert_missing_binding(human)


def test_every_executable_parameter_exposes_initialization_provenance():
    from livemorebio.aegle.clinical_parameters import validate_clinical_inputs
    from livemorebio.aegle.model_contexts import resolve_model_context
    from livemorebio.engines.metabolic.glucose_insulin import MetabolicProfile
    from livemorebio.tests.test_clinical_context_contract import _legacy_reference_record, _expected_legacy_profile

    human = _human(observations={"fasting_glucose_mgdl": _observation()},
                   model_parameters={"weight_kg": 80.0})
    # Conflict validation returns candidates only, never an admitted binding.
    values, provenance = validate_clinical_inputs(observations=human.observations, model_parameters=human.model_parameters)
    assert values == {"Gb": pytest.approx(126.10913), "weight_kg": 80.0}
    assert set(provenance) == {"Gb", "weight_kg"} and "Si" not in values
    assert provenance["Gb"]["evidence_class"] == "MEASURED_CLINICAL"
    assert provenance["Gb"]["source_id"] == "local-assay-fixture"
    assert provenance["weight_kg"]["evidence_class"] == "USER_DECLARED_MODEL_PARAMETER"
    _assert_missing_binding(human)

    record = _legacy_reference_record()
    context = resolve_model_context(record)
    expected = _expected_legacy_profile(record)
    assert asdict(context.profile) == expected
    units = {"weight_kg": "kg", "Gb": "mg/dL", "Ib": "uU/mL", "SG": "1/min", "p2": "1/min",
             "Si": "mL/uU/min", "gamma": "uU/mL/min/(mg/dL)", "Gt": "mg/dL", "n": "1/min",
             "ka": "1/min", "f_bioavail": "1", "vg_per_kg": "dL/kg"}
    assert set(context.parameter_provenance) == set(MetabolicProfile.__dataclass_fields__) - {"name"} == set(units)
    for field, origin in context.parameter_provenance.items():
        assert origin["value"] == expected[field] and origin["unit"] == units[field]
        assert origin["evidence_class"] == "REFERENCE_INITIALIZED"
        assert origin["source_id"] == (record["reference_source"]["source_id"]
                                        if field in record["model_parameters"] else "livemore:healthy-adult")


@pytest.mark.parametrize("field,value", [("Si", -1), ("weight_kg", 0), ("Gb", -10)])
def test_invalid_model_parameters_cannot_activate(field, value):
    from livemorebio.aegle.clinical_parameters import validate_model_parameters
    from livemorebio.aegle.model_contexts import ModelContextError

    with pytest.raises(ValueError, match=f"model parameter {field} is outside the executable domain") as caught:
        validate_model_parameters({field: value})
    assert not isinstance(caught.value, ModelContextError)
    _assert_missing_binding(_human(model_parameters={field: value}))


def test_chembl_association_does_not_invent_flux_scale(monkeypatch):
    from livemorebio.engines import drug_targets

    def fake_get(url):
        if "/molecule" in url:
            return {"molecules": [{"molecule_chembl_id": "CHEMBL1"}]}
        return {"mechanisms": [{"target_chembl_id": "CHEMBL2", "action_type": "INHIBITOR",
                                "mechanism_of_action": "Reference-only inhibitor"}]}

    monkeypatch.setattr(drug_targets, "_get", fake_get)
    monkeypatch.setattr(drug_targets, "_target_genes", lambda target: ("GENE",))
    drug_targets.resolve_drug.cache_clear()
    try:
        result = drug_targets.resolve_drug("fixture-only")
        assert result["resolved"]
        assert result["targets"][0].get("scale") is None
        assert result["execution_status"] == "REFERENCE_ONLY"
    finally:
        drug_targets.resolve_drug.cache_clear()


def test_gem_to_whole_body_requires_qualified_translation(monkeypatch):
    from livemorebio.engines.coupling import gem_metabolic
    from livemorebio.engines.metabolic.glucose_insulin import T2D

    monkeypatch.setattr(gem_metabolic.MB, "operating_point", lambda h: (10, 10))
    monkeypatch.setattr(gem_metabolic.MB, "physiological_gluconeogenesis", lambda *a: 10)
    monkeypatch.setattr(gem_metabolic.MB, "atp_yield", lambda **kw: 30)
    with pytest.raises(ValueError, match="qualified"):
        gem_metabolic.gem_drug_effect(T2D, {}, {"PCK1": 0.1})


def test_arbitrary_food_names_do_not_protect_against_disease():
    from livemorebio.engines.trajectory import ExposurePattern, _protection

    base = ExposurePattern(activity=0.5)
    with_food_names = ExposurePattern(activity=0.5, foods=("invented", "duplicate", "duplicate"))
    assert _protection(base) == _protection(with_food_names)


def test_rejected_runtime_intervention_does_not_mutate_twin(monkeypatch):
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.engines.metabolic.glucose_insulin import T2D

    twin = AegleTwin.__new__(AegleTwin)
    twin.profile = deepcopy(T2D)
    twin.human = None
    twin.applied = []
    twin.last_intervention = None
    monkeypatch.setattr(twin, "_comparison_snapshot", lambda: {})
    monkeypatch.setattr(twin, "_recompute", lambda: None)
    monkeypatch.setattr(twin, "state", lambda: {})
    original = asdict(twin.profile)
    with pytest.raises(ValueError, match="qualified"):
        twin.stimulate("metabolic_drug", name="invented-compound")
    assert asdict(twin.profile) == original
    assert twin.applied == []


def test_unknown_compound_cannot_receive_generic_pk():
    from livemorebio.engines.hepatic_pk import pk_profile

    with pytest.raises(ValueError, match="qualified"):
        pk_profile("invented-compound", dose_mg=100)


def test_current_assay_does_not_substitute_a_t2d_twin(monkeypatch):
    from livemorebio import bus
    from livemorebio.cendos import service
    from livemorebio.execution_client import ContinuousClientError

    def unavailable():
        raise ContinuousClientError("MODEL_BINDING_REQUIRED", status=409)

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "integrity-test-token")
    monkeypatch.setattr(bus, "snapshot", lambda key: None)
    monkeypatch.setattr(service, "_read_current_source", unavailable)
    monkeypatch.setattr(service.pharmacology, "metformin", lambda *a: pytest.fail("missing source calculated"))
    response = TestClient(service.app).post("/assay/current", json={"drug": "metformin"},
                                    headers={"Authorization": "Bearer integrity-test-token"})
    assert response.status_code == 409
    assert response.json()["code"] == "MODEL_BINDING_REQUIRED"


def test_admission_persists_observation_provenance_and_unit_conversion(tmp_path, monkeypatch):
    from livemorebio.aegle.subjects import SubjectRegistry
    from livemorebio.aegle.model_contexts import ModelContextError, resolve_model_context
    from livemorebio.tests.clinical_registry_fixtures import forbid_compilation

    forbid_compilation(monkeypatch)
    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"p" * 32)
    record = registry.create_twin({
        "source_class": "REAL_HUMAN", "subject_id": "pseudonym-unit-fixture",
        "display_label": "Non-PHI unit fixture", "demographics": {"age": 55, "sex": "F"},
        "consent_scope": ["digital_twin"], "chain_of_custody": "local-fixture",
        "observations": {"fasting_glucose_mgdl": _observation()},
    })
    for stored in (registry.get_twin(record["twin_id"]),
                   SubjectRegistry(registry.path, key=b"p" * 32).get_twin(record["twin_id"])):
        observation = stored["observations"]["fasting_glucose_mgdl"]
        assert observation["original_value"] == 7.0 and observation["original_unit"] == "mmol/L"
        assert observation["value"] == pytest.approx(126.10913) and observation["unit"] == "mg/dL"
        for field in ("source", "captured_at", "quality_status"):
            assert observation[field] == _observation()[field]
        assert stored["chain_of_custody"] == "local-fixture"
        assert stored["profile_sources"] == record["profile_sources"]
        assert stored["field_provenance"] == record["field_provenance"]
        assert stored["field_provenance"]["observations.fasting_glucose_mgdl"] == {
            "source_id": "legacy-admission", "evidence_class": "MEASURED_CLINICAL"}
        assert stored["profile_sources"][0]["provenance_uri"] == "local-fixture"
        assert stored["model_binding"] is None and stored["model_parameters"] == {}
        assert "parameter_provenance" not in stored
        assert stored["creation_identity"]["normalizer_id"] == "livemore.real-human-descriptive.v1"
        with pytest.raises(ModelContextError) as caught:
            resolve_model_context(stored)
        assert caught.value.code == "MODEL_BINDING_REQUIRED"


def test_direct_metformin_assay_uses_admitted_profile_weight(monkeypatch):
    from dataclasses import replace
    from livemorebio.engines import hepatic_pk, pharmacology
    from livemorebio.engines.metabolic.glucose_insulin import T2D

    captured = {}
    real_pk = hepatic_pk.pk_profile

    def record_pk(*args, **kwargs):
        captured["weight_kg"] = getattr(kwargs["human"], "weight_kg", None)
        return real_pk(*args, **kwargs)

    monkeypatch.setattr(hepatic_pk, "pk_profile", record_pk)
    pharmacology.metformin(replace(T2D, weight_kg=103.5), _human())
    assert captured["weight_kg"] == 103.5


def test_complete_saved_metabolic_declarations_survive_encrypted_reload(tmp_path, monkeypatch):
    from livemorebio.aegle.subjects import SubjectRegistry
    from livemorebio.aegle.model_contexts import ModelContextError
    from livemorebio.tests.clinical_registry_fixtures import forbid_compilation, saved_bytes

    forbid_compilation(monkeypatch)
    registry = SubjectRegistry(tmp_path / "subjects.sqlite3", key=b"p" * 32)
    custom = {"p2": .031, "n": .19, "ka": .027, "f_bioavail": .68, "vg_per_kg": 2.4}
    record = registry.create_twin({
        "source_class": "REAL_HUMAN", "subject_id": "pseudonym-full-parameter-fixture",
        "display_label": "Full-parameter fixture", "demographics": {"age": 55, "sex": "F"},
        "consent_scope": ["digital_twin"], "chain_of_custody": "local-fixture",
        "model_parameters": custom, "observations": {"fasting_glucose_mgdl": _observation()},
    })
    assert record["model_parameters"] == custom
    assert registry.get_twin(record["twin_id"])["model_parameters"] == custom
    reopened = SubjectRegistry(registry.path, key=b"p" * 32)
    assert reopened.get_twin(record["twin_id"])["model_parameters"] == custom
    retained = reopened.get_twin(record["twin_id"])
    assert retained["model_binding"] is None and "parameter_provenance" not in retained
    # Preserve the original partial legacy-source fixture, not invented source
    # metadata to make it eligible for an optional observation-selection step.
    assert reopened.active_twin() is None
    before = saved_bytes(reopened, record["twin_id"])
    with pytest.raises(ModelContextError) as caught:
        reopened.activate_twin(retained["twin_id"], expected_version=retained["version"])
    assert caught.value.code == "MODEL_BINDING_REQUIRED"
    assert saved_bytes(reopened, record["twin_id"]) == before
    assert reopened.active_twin() is None


def test_aegle_snapshot_preserves_every_metabolic_parameter(monkeypatch):
    from dataclasses import asdict, replace
    from types import SimpleNamespace
    from livemorebio import bus
    from livemorebio.aegle import server
    from livemorebio.engines.metabolic.glucose_insulin import T2D

    profile = replace(T2D, p2=.031, n=.19, ka=.027, f_bioavail=.68, vg_per_kg=2.4)
    state = {"profile": profile.name, "profile_params": asdict(profile), "pk_context": {"age": 55, "genome": {},
             "evidence_class": "DECLARED_PERSON_CONTEXT"}}
    captured = {}
    unrelated = replace(profile, p2=.02, n=.15, ka=.03, f_bioavail=.5, vg_per_kg=2.0)
    monkeypatch.setitem(server._state, "tw", SimpleNamespace(profile=unrelated))
    monkeypatch.setattr(bus, "set_snapshot", lambda key, value: captured.update(value))
    monkeypatch.setattr(bus, "publish", lambda *args: None)
    server._snapshot_twin(state)
    assert captured["profile_params"] == asdict(profile)
    assert captured["profile_params"] != asdict(unrelated)


def test_current_assay_executes_complete_frozen_profile_without_mutating_it(monkeypatch):
    from copy import deepcopy
    from dataclasses import asdict, replace
    from livemorebio import bus
    from livemorebio.cendos import service
    from livemorebio.engines.metabolic.glucose_insulin import T2D

    profile = replace(T2D, p2=.031, n=.19, ka=.027, f_bioavail=.68, vg_per_kg=2.4)
    snap = {"profile": profile.name, "profile_params": asdict(profile),
            "pk_context": {"age": 55, "genome": {"SLC22A1": 1},
                           "evidence_class": "DECLARED_PERSON_CONTEXT"}}
    original = deepcopy(snap)
    captured = {}

    def inspect_assay(baseline, treated, **kwargs):
        captured.update(asdict(baseline))
        return {"decision": "WEAK", "delta_mean": 0., "delta_iAUC": 0.}

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "integrity-test-token")
    monkeypatch.setattr(bus, "snapshot", lambda key: pytest.fail("notification cache used as source"))
    monkeypatch.setattr(service, "_read_current_source", lambda: technical_source(snap))
    monkeypatch.setattr(bus, "publish", lambda *args: None)
    monkeypatch.setattr(service, "ogtt_effect", inspect_assay)
    response = TestClient(service.app).post("/assay/current", json={"drug": "metformin"},
        headers={"Authorization": "Bearer integrity-test-token"})
    assert response.status_code == 200
    assert captured == asdict(profile)
    assert response.json()["assayed_profile_params"] == asdict(profile)
    assert response.json()["assayed_pk_context"] == snap["pk_context"]
    assert snap == original


@pytest.mark.parametrize("invalid", ["partial_profile", "missing_identity", "missing_pk_context"])
def test_current_assay_rejects_incomplete_identity_or_parameters(monkeypatch, invalid):
    from dataclasses import asdict
    from livemorebio import bus
    from livemorebio.cendos import service
    from livemorebio.engines.metabolic.glucose_insulin import T2D

    snap = {"profile": T2D.name, "profile_params": asdict(T2D),
            "pk_context": {"age": 55, "genome": {}, "evidence_class": "DECLARED_PERSON_CONTEXT"}}
    if invalid == "partial_profile":
        snap["profile_params"].pop("p2")
    elif invalid == "missing_identity":
        snap.pop("profile")
    else:
        snap.pop("pk_context")
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "integrity-test-token")
    monkeypatch.setattr(bus, "snapshot", lambda key: pytest.fail("notification cache used as source"))
    monkeypatch.setattr(service, "_read_current_source", lambda: technical_source(snap))
    monkeypatch.setattr(service.pharmacology, "metformin", lambda *a: pytest.fail("invalid remote source calculated"))
    monkeypatch.setattr(service, "ogtt_effect", lambda *a, **k: pytest.fail("invalid remote source assayed"))
    response = TestClient(service.app).post("/assay/current", json={"drug": "metformin"},
        headers={"Authorization": "Bearer integrity-test-token"})
    # Invalid authenticated peer data is unavailable, not a bad caller's assay.
    assert response.status_code == 503
    assert response.json()["code"] == "CLIENT_RESPONSE"
