"""Acquiring geometry stays pending; retry preserves actual inspection state."""
import json

import pytest

from .test_anatomy_restoration import CONSOLE, node


def program(body):
    return (f"import {{createAnatomyAssetLoader, retryDelayMs}} from {json.dumps((CONSOLE / 'lib/anatomy_requests.js').as_uri())};\n"
            "import assert from 'node:assert/strict';\n" + body)


def test_retry_after_seconds_and_dates_are_not_shortened():
    node(program("""
assert.equal(retryDelayMs('3',0),3000);
assert.equal(retryDelayMs(new Date(9000).toUTCString(),1000),8000);
assert.equal(retryDelayMs('invalid',0),3000);
assert.equal(retryDelayMs('0',0),1000);
"""))


def test_acquiring_is_deduplicated_and_retries_exact_source_then_returns_bytes():
    node(program("""
let calls=0, release; const pending=[], sleeps=[];
const loader=createAnatomyAssetLoader({fetchImpl:async(url)=>{
 assert.equal(url,'/assets/anatomy/heart.glb'); calls++;
 return calls===1?new Response(JSON.stringify({code:'ANATOMY_ACQUIRING'}),{status:503,headers:{'Retry-After':'7'}}):new Response(new Uint8Array([1,2,3]));
},onPending:(url,info)=>pending.push(info),wait:async(ms)=>{sleeps.push(ms);await new Promise(r=>release=r);}});
const a=loader.load('/assets/anatomy/heart.glb'),b=loader.load('/assets/anatomy/heart.glb');
await new Promise(r=>setTimeout(r,0));assert.equal(calls,1);assert.deepEqual(sleeps,[7000]);assert.equal(pending.length,1);
release();assert.deepEqual([...new Uint8Array(await a)],[1,2,3]);await b;assert.equal(calls,2);
loader.dispose();
"""))


@pytest.mark.parametrize("code", ["ANATOMY_UNAVAILABLE", "OTHER", None])
def test_true_failures_are_not_retried(code):
    node(program(f"""
let calls=0;const loader=createAnatomyAssetLoader({{fetchImpl:async()=>{{calls++;return new Response(JSON.stringify({{code:{json.dumps(code)}}}),{{status:503}});}}}});
await assert.rejects(loader.load('/assets/anatomy/liver.glb'),/unavailable/);assert.equal(calls,1);loader.dispose();
"""))


def test_pending_retries_are_bounded_and_do_not_ignore_long_retry_after():
    node(program("""
let calls=0, waits=0;const loader=createAnatomyAssetLoader({maxAttempts:2,fetchImpl:async()=>{calls++;return new Response(JSON.stringify({code:'ANATOMY_ACQUIRING'}),{status:503,headers:{'Retry-After':'3'}});},wait:async()=>{waits++;}});
await assert.rejects(loader.load('/assets/anatomy/liver.glb'),e=>e.code==='ANATOMY_PENDING_LIMIT'&&/still acquiring/.test(e.message));assert.equal(calls,2);assert.equal(waits,1);loader.dispose();
const long=createAnatomyAssetLoader({timeoutMs:1000,fetchImpl:async()=>new Response(JSON.stringify({code:'ANATOMY_ACQUIRING'}),{status:503,headers:{'Retry-After':'60'}}),wait:async()=>{throw Error('must not shorten Retry-After');}});
await assert.rejects(long.load('/assets/anatomy/liver.glb'),/still acquiring/);long.dispose();
"""))


def test_context_cancel_aborts_wait_and_allows_new_context_without_duplicate_request():
    node(program("""
let calls=0;const loader=createAnatomyAssetLoader({fetchImpl:async()=>{calls++;return new Response(JSON.stringify({code:'ANATOMY_ACQUIRING'}),{status:503,headers:{'Retry-After':'3'}});}});
const old=loader.load('/assets/anatomy/liver.glb'); const rejected=assert.rejects(old,e=>e.name==='AbortError');
await new Promise(r=>setTimeout(r,0));loader.cancelPending();await rejected;assert.equal(calls,1);
const next=loader.load('/assets/anatomy/liver.glb');const nextRejected=assert.rejects(next,e=>e.name==='AbortError');
await new Promise(r=>setTimeout(r,0));loader.dispose();await nextRejected;assert.equal(calls,2);
await assert.rejects(loader.load('/assets/anatomy/liver.glb'),e=>e.name==='AbortError');
"""))


def test_only_same_origin_catalog_paths_may_acquire_geometry():
    node(program("""
const loader=createAnatomyAssetLoader({fetchImpl:async()=>{throw Error('must not fetch');}});
for(const url of ['https://other.test/heart.glb','/api/state','/assets/anatomy/../secret.glb','/assets/anatomy/heart.glb?other=1'])await assert.rejects(loader.load(url),/source/);
loader.dispose();
"""))


def test_restoring_view_reapplies_actual_graphics_state_including_labels_and_isolation():
    module = (CONSOLE / "lib/anatomy_view_state.js").as_uri()
    node(f"""import {{restoreAnatomyView}} from {json.dumps(module)};import assert from 'node:assert/strict';
const calls=[];const ex={{setClip:(...v)=>calls.push(['clip',...v]),clearClip:()=>calls.push(['clearClip']),setLabels:v=>calls.push(['labels',v]),isolate:v=>calls.push(['isolate',v]),clearIsolation:()=>calls.push(['all'])}};
restoreAnatomyView(ex,{{axis:'y',depth:.7,labels:false,isolated:'heart'}});
assert.deepEqual(calls,[['clip','y',.7],['labels',false],['isolate','heart']]);calls.length=0;
restoreAnatomyView(ex,{{axis:'off',depth:.5,labels:true,isolated:null}});
assert.deepEqual(calls,[['clearClip'],['labels',true],['all']]);
""")


def test_active_and_saved_views_wire_pending_restore_and_context_cancellation():
    active = (CONSOLE / "biology.html").read_text(encoding="utf-8")
    saved = (CONSOLE / "lib/run_anatomy.js").read_text(encoding="utf-8")
    core = (CONSOLE / "lib/anatomy.js").read_text(encoding="utf-8")
    for source in (active, saved):
        assert "restoreAnatomyView" in source
        assert "onMeshPending" in source
        assert ".setContext(" in source
    assert "createAnatomyAssetLoader" in core
    assert "assetLoader.cancelPending()" in core
    assert "assetLoader.dispose()" in core
