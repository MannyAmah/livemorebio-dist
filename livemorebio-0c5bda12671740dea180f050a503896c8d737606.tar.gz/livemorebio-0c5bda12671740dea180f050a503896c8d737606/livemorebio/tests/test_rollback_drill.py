"""Offline technical builds test rollback orchestration, not release compatibility."""
from __future__ import annotations

import json
import os
from pathlib import Path
import signal
import time

import pytest

from tools import rollback_drill


LAUNCHER = '''#!/usr/bin/env python3
import json
import os
from pathlib import Path
import sys
build = __BUILD__
behavior = __BEHAVIOR__
data = Path(os.environ["LIVEMORE_DATA_DIR"])
phase = sys.argv[1]
with (data / "technical-steps.jsonl").open("a", encoding="utf-8") as stream:
    stream.write(json.dumps({"phase": phase, "build": build}) + "\\n")
assert os.environ["LANG"] == "en_US.UTF-8"
assert "PYTHONPATH" not in os.environ and "TECHNICAL_PARENT_SECRET" not in os.environ
assert all(":885" not in os.environ["LIVEMORE_" + role + "_URL"] for role in ("AEGLE", "LIFE", "CENDOS"))
runs = data / "protocol-runs"
running = data / "technical-running"
if phase == "start":
    running.write_text(build, encoding="utf-8")
    if behavior == "fail-start":
        raise SystemExit(7)
    if behavior == "corrupt-start" and runs.exists():
        for path in runs.glob("*.json"):
            path.write_text('{"data_class":"technical_fixture","changed":true}', encoding="utf-8")
elif phase == "create":
    runs.mkdir(mode=0o700)
    if behavior != "empty":
        path = runs / "technical-run.json"
        path.write_text(json.dumps({"data_class": "technical_fixture", "build": build,
                                   "value": "TECHNICAL_VALUE_NOT_FOR_OUTPUT"}), encoding="utf-8")
        if behavior == "nontechnical":
            path.write_text('{"data_class":"unclassified"}', encoding="utf-8")
        elif behavior in ("symlink", "hardlink"):
            retained = data / "technical-link-target.json"
            path.rename(retained)
            if behavior == "symlink":
                path.symlink_to(retained)
            else:
                path.hardlink_to(retained)
        elif behavior == "data-symlink":
            retained = data.parent / "technical-displaced-data"
            data.rename(retained)
            data.symlink_to(retained, target_is_directory=True)
elif phase == "check":
    assert running.read_text(encoding="utf-8") == build
    for path in runs.glob("*.json"):
        assert json.loads(path.read_text(encoding="utf-8"))["data_class"] == "technical_fixture"
elif phase == "stop":
    running.unlink(missing_ok=True)
else:
    raise SystemExit(8)
print("TECHNICAL_CHILD_OUTPUT_MUST_STAY_PRIVATE")
'''


def technical_build(root: Path, name: str, behavior: str = "normal") -> Path:
    build = root / name
    build.mkdir()
    install = '''import json
import os
from pathlib import Path
import sys
home = Path(os.environ["HOME"])
data = Path(os.environ["LIVEMORE_DATA_DIR"])
build, behavior = sys.argv[1:]
empty = not any(home.iterdir())
with (data / "technical-steps.jsonl").open("a", encoding="utf-8") as stream:
    stream.write(json.dumps({"phase": "install", "build": build, "home_empty": empty}) + "\\n")
launcher = home / "bin" / "livemore"
launcher.parent.mkdir(exist_ok=True)
launcher.write_text(LAUNCHER.replace("__BUILD__", repr(build)).replace("__BEHAVIOR__", repr(behavior)), encoding="utf-8")
launcher.chmod(0o700)
if behavior == "corrupt-install":
    for path in (data / "protocol-runs").glob("*.json"):
        path.write_text('{"data_class":"technical_fixture","changed":true}', encoding="utf-8")
print("TECHNICAL_INSTALL_OUTPUT_MUST_STAY_PRIVATE")
'''.replace("LAUNCHER", repr(LAUNCHER))
    (build / "install.py").write_text(install, encoding="utf-8")
    descriptor = {"schema": "livemore.rollback-build.v1", "build_id": name,
                  "launcher": "bin/livemore",
                  "install": ["{python}", "{build}/install.py", name, behavior]}
    for phase in ("create", "start", "check", "stop"):
        descriptor[phase] = ["{home}/bin/livemore", phase]
    path = build / "build.json"
    path.write_text(json.dumps(descriptor), encoding="utf-8")
    return path


def steps(output: Path, direction: str) -> list[dict]:
    path = output / direction / "data" / "technical-steps.jsonl"
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def test_both_directions_reinstall_start_and_preserve_actual_run_bytes(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("TECHNICAL_PARENT_SECRET", "technical-not-a-credential")
    monkeypatch.setenv("PYTHONPATH", "technical-hostile-import-path")
    first = technical_build(tmp_path, "technical-a")
    second = technical_build(tmp_path, "technical-b")
    output = tmp_path / "drill"

    assert rollback_drill.main([str(first), str(second), "--output", str(output)]) == 0

    printed = capsys.readouterr().out
    assert "TECHNICAL_CHILD_OUTPUT" not in printed and "TECHNICAL_INSTALL_OUTPUT" not in printed
    assert "TECHNICAL_VALUE" not in printed and str(tmp_path) not in printed
    receipt = json.loads(printed)
    assert receipt["status"] == "passed" and receipt["data_class"] == "technical_fixture"
    assert len(receipt["directions"]) == 2
    for direction, source, target in (("forward", "technical-a", "technical-b"),
                                       ("reverse", "technical-b", "technical-a")):
        records = steps(output, direction)
        assert [(row["build"], row["phase"]) for row in records] == [
            (source, "install"), (source, "start"), (source, "create"), (source, "check"), (source, "stop"),
            (target, "install"), (target, "start"), (target, "check"), (target, "stop")]
        installs = [row for row in records if row["phase"] == "install"]
        assert [row["home_empty"] for row in installs] == [True, False]
        assert not (output / direction / "data" / "technical-running").exists()
        evidence = next(row for row in receipt["directions"] if row["direction"] == direction)
        assert evidence["source_build"] == source and evidence["target_build"] == target
        assert evidence["run_count"] == 1
        assert all(check["hashes"] == evidence["hashes"] for check in evidence["checks"])
        assert len(evidence["checks"]) == 6


@pytest.mark.parametrize("behavior", ["corrupt-install", "corrupt-start"])
def test_changed_old_run_is_detected_independently_of_the_build_checker(tmp_path, behavior):
    first = technical_build(tmp_path, "technical-a")
    second = technical_build(tmp_path, "technical-b", behavior)
    output = tmp_path / "drill"
    with pytest.raises(rollback_drill.DrillError) as error:
        rollback_drill.run_drill(first, second, output)
    assert error.value.code == "RUN_HASH_CHANGED"
    assert not (output / "forward" / "data" / "technical-running").exists()


@pytest.mark.parametrize("behavior", ["empty", "nontechnical", "symlink", "hardlink", "data-symlink"])
def test_missing_nontechnical_or_linked_runs_never_pass(tmp_path, behavior):
    first = technical_build(tmp_path, "technical-a", behavior)
    second = technical_build(tmp_path, "technical-b")
    with pytest.raises(rollback_drill.DrillError):
        rollback_drill.run_drill(first, second, tmp_path / "drill")


def test_failed_start_is_stopped_and_not_reported_as_a_pass(tmp_path):
    first = technical_build(tmp_path, "technical-a", "fail-start")
    second = technical_build(tmp_path, "technical-b")
    output = tmp_path / "drill"
    with pytest.raises(rollback_drill.DrillError) as error:
        rollback_drill.run_drill(first, second, output)
    assert error.value.code == "PHASE_FAILED"
    assert [row["phase"] for row in steps(output, "forward")] == ["install", "start", "stop"]
    assert not (output / "forward" / "data" / "technical-running").exists()


def test_existing_home_and_uninstalled_phase_executable_are_refused(tmp_path):
    first = technical_build(tmp_path, "technical-a")
    second = technical_build(tmp_path, "technical-b")
    output = tmp_path / "existing"
    output.mkdir()
    with pytest.raises(rollback_drill.DrillError):
        rollback_drill.run_drill(first, second, output)
    descriptor = json.loads(first.read_text(encoding="utf-8"))
    descriptor["check"] = ["{python}", "-c", "pass"]
    first.write_text(json.dumps(descriptor), encoding="utf-8")
    with pytest.raises(rollback_drill.DrillError):
        rollback_drill.run_drill(first, second, tmp_path / "new")


def test_phase_deadline_terminates_the_owned_child_group(tmp_path):
    first = technical_build(tmp_path, "technical-a")
    second = technical_build(tmp_path, "technical-b")
    child = '''import os
from pathlib import Path
import signal
import time
signal.signal(signal.SIGTERM, signal.SIG_IGN)
(Path(os.environ["LIVEMORE_DATA_DIR"]) / "technical-child.pid").write_text(str(os.getpid()), encoding="utf-8")
time.sleep(30)
'''
    program = '''import subprocess
import sys
import time
subprocess.Popen([sys.executable, "-c", CHILD])
time.sleep(30)
'''.replace("CHILD", repr(child))
    (first.parent / "technical-timeout.py").write_text(program, encoding="utf-8")
    descriptor = json.loads(first.read_text(encoding="utf-8"))
    descriptor["install"] = ["{python}", "{build}/technical-timeout.py"]
    first.write_text(json.dumps(descriptor), encoding="utf-8")
    output = tmp_path / "drill"
    pid = None
    try:
        with pytest.raises(rollback_drill.DrillError) as error:
            rollback_drill.run_drill(first, second, output, timeout=0.5)
        assert error.value.code == "PHASE_TIMEOUT"
        pid = int((output / "forward" / "data" / "technical-child.pid").read_text(encoding="utf-8"))
        deadline = time.monotonic() + 2
        while time.monotonic() < deadline:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                break
            time.sleep(0.01)
        else:
            pytest.fail("Owned SIGTERM-ignoring descendant survived its phase timeout")
    finally:
        if pid is not None:
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
