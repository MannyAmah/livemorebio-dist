"""Source authority must survive execution-store failures; no numerical engine runs.

The adapters here deliberately return authored technical values. These tests
establish ownership and late-result rejection, never biological equivalence.
"""
from concurrent.futures import ThreadPoolExecutor
import threading

import pytest

from livemorebio.tests.test_continuous_execution import (
    TechnicalAdapter,
    captured_source,
)
from ._timing import wait_seconds


POLICY = {"end_native": 3.0, "frame_period_s": 1.0, "time_scale": 60.0}


def bound_manager(tmp_path, adapter=TechnicalAdapter):
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_store import ExecutionStore

    return ExecutionManager(
        ExecutionStore(tmp_path / "executions.sqlite3", key=b"f" * 32),
        adapter_registry={"metabolic-continuous-v1": adapter},
        run_background=False,
        permitted_generation="generation-a",
    )


def prepare(manager, key="source-fence-technical"):
    return manager.prepare(captured_source(), POLICY, key)


def start(manager, record):
    return manager.start(
        record["execution_id"], expected_revision=record["revision"],
        expected_source_generation="generation-a",
    )


def test_bound_prepare_rejects_old_source_before_storage(tmp_path, monkeypatch):
    from livemorebio.aegle.execution_contract import ExecutionError

    manager = bound_manager(tmp_path)
    try:
        manager.set_source_generation("generation-b")
        monkeypatch.setattr(manager.store, "create", lambda *a, **k: pytest.fail("stale source was stored"))
        with pytest.raises(ExecutionError) as failure:
            prepare(manager)
        assert failure.value.code == "EXECUTION_CONFLICT"
        assert not manager._known
    finally:
        manager.close()


@pytest.mark.parametrize("invalid", [None, True, False, 1, "", [], {}])
def test_product_fence_cannot_be_reset_to_unbound_or_coerced(tmp_path, invalid):
    from livemorebio.aegle.execution_contract import ExecutionError

    manager = bound_manager(tmp_path)
    try:
        with pytest.raises(ExecutionError):
            manager.set_source_generation(invalid)
        assert prepare(manager)["source_valid"] is True
    finally:
        manager.close()


def test_fence_assignment_performs_no_execution_store_io(tmp_path, monkeypatch):
    manager = bound_manager(tmp_path)
    record = start(manager, prepare(manager))
    try:
        with monkeypatch.context() as patch:
            for operation in ("get", "update", "acquire_owner", "release_owner"):
                patch.setattr(manager.store, operation, lambda *a, **k: pytest.fail("fence performed store I/O"))
            adapter = manager._adapters[record["execution_id"]]
            for operation in ("close", "initialize", "advance"):
                patch.setattr(adapter, operation, lambda *a, **k: pytest.fail("fence called a numerical adapter"))
            manager.set_source_generation("generation-b")
            assert manager._next_due == {}
        assert manager.store.get(record["execution_id"])["source_valid"] is True
        assert manager.status(record["execution_id"])["source_valid"] is False
    finally:
        manager.close()


@pytest.mark.parametrize("operation", ["get", "update"])
@pytest.mark.parametrize("fail_at", [1, 2])
def test_first_or_later_invalidation_failure_cannot_restore_source(tmp_path, monkeypatch, operation, fail_at):
    from livemorebio.aegle.execution_contract import ExecutionError

    manager = bound_manager(tmp_path)
    records = [prepare(manager, "fence-first"), prepare(manager, "fence-second")]
    manager.set_source_generation("generation-b")
    original = getattr(manager.store, operation)
    calls = 0

    def failing(*args, **kwargs):
        nonlocal calls
        calls += 1
        if calls == fail_at:
            raise ExecutionError("EXECUTION_STORAGE")
        return original(*args, **kwargs)

    try:
        with monkeypatch.context() as patch:
            patch.setattr(manager.store, operation, failing)
            with pytest.raises(ExecutionError):
                manager.invalidate_source("generation-a", "technical-source-change")
        for record in records:
            assert manager.status(record["execution_id"])["source_valid"] is False
            with pytest.raises(ExecutionError):
                start(manager, manager.status(record["execution_id"]))
        assert manager._next_due == {}
    finally:
        manager.close()


@pytest.mark.parametrize("operation", ["get", "update"])
def test_cleanup_failure_remains_owned_and_retryable_without_source_revival(tmp_path, monkeypatch, operation):
    from livemorebio.aegle.execution_contract import ExecutionError, seal_source

    class CleanupTechnicalAdapter(TechnicalAdapter):
        fail_close = True

        def close(self):
            assert not manager._lock._is_owned(), "native cleanup under manager critical section"
            if self.fail_close:
                raise RuntimeError("private technical cleanup detail must not escape")

    manager = bound_manager(tmp_path, CleanupTechnicalAdapter)
    record = start(manager, prepare(manager))
    adapter = manager._adapters[record["execution_id"]]
    try:
        manager.set_source_generation("generation-b")
        with monkeypatch.context() as patch:
            patch.setattr(manager.store, operation, lambda *a, **k: (_ for _ in ()).throw(ExecutionError("EXECUTION_STORAGE")))
            with pytest.raises(ExecutionError) as failure:
                manager.invalidate_source("generation-a", "technical-source-change")
        assert failure.value.code == "EXECUTION_CLEANUP_UNCONFIRMED"
        assert "private technical" not in str(failure.value)
        assert manager.status(record["execution_id"])["source_valid"] is False
        assert not manager._next_due
        # An unconfirmed native shutdown cannot silently release another owner's
        # right to execute the same record. Test the OS lock, not a Python map.
        with pytest.raises(ExecutionError) as ownership:
            manager.store.acquire_owner(record["execution_id"])
        assert ownership.value.code == "EXECUTION_OWNED"
        replacement = captured_source()
        replacement["source_generation"] = "generation-b"
        prepared = manager.prepare(seal_source(replacement), POLICY, "waiting-for-owned-cleanup")
        with monkeypatch.context() as patch:
            patch.setattr(CleanupTechnicalAdapter, "__init__", lambda *a, **k: pytest.fail("new work launched during unconfirmed cleanup"))
            with pytest.raises(ExecutionError) as refused:
                manager.start(prepared["execution_id"], expected_revision=prepared["revision"],
                              expected_source_generation="generation-b")
        assert refused.value.code == "EXECUTION_CLEANUP_UNCONFIRMED"
        adapter.fail_close = False
        current = manager.status(record["execution_id"])
        stopped = manager.stop(
            current["execution_id"], expected_revision=current["revision"],
            expected_source_generation="generation-a",
        )
        assert stopped["state"] == "stopped" and stopped["source_valid"] is False
        descriptor = manager.store.acquire_owner(record["execution_id"])
        manager.store.release_owner(descriptor)
    finally:
        adapter.fail_close = False
        manager.close()


def test_explicit_stop_retries_owned_cleanup_after_stopped_record_commit(tmp_path):
    from livemorebio.aegle.execution_contract import ExecutionError

    class StopTechnicalAdapter(TechnicalAdapter):
        fail_close = True

        def close(self):
            if self.fail_close:
                raise RuntimeError("private stop cleanup failure")

    manager = bound_manager(tmp_path, StopTechnicalAdapter)
    record = start(manager, prepare(manager))
    adapter = manager._adapters[record["execution_id"]]
    try:
        with pytest.raises(ExecutionError) as failure:
            manager.stop(record["execution_id"], expected_revision=record["revision"],
                         expected_source_generation="generation-a")
        assert failure.value.code == "EXECUTION_CLEANUP_UNCONFIRMED"
        current = manager.status(record["execution_id"])
        assert current["state"] == "stopped"
        assert current["revision"] > record["revision"]
        assert current["failure_code"] == "EXECUTION_CLEANUP_UNCONFIRMED"
        with pytest.raises(ExecutionError) as ownership:
            manager.store.acquire_owner(record["execution_id"])
        assert ownership.value.code == "EXECUTION_OWNED"
        adapter.fail_close = False
        retried = manager.stop(current["execution_id"], expected_revision=current["revision"],
                               expected_source_generation="generation-a")
        assert retried["state"] == "stopped"
        assert retried["failure_code"] != "EXECUTION_CLEANUP_UNCONFIRMED"
        descriptor = manager.store.acquire_owner(record["execution_id"])
        manager.store.release_owner(descriptor)
        assert not manager._owners and not manager._adapters
    finally:
        adapter.fail_close = False
        manager.close()


def test_successful_invalidation_releases_owner_before_teardown(tmp_path):
    manager = bound_manager(tmp_path)
    record = start(manager, prepare(manager))
    try:
        manager.set_source_generation("generation-b")
        manager.invalidate_source("generation-a", "technical-source-change")
        descriptor = manager.store.acquire_owner(record["execution_id"])
        manager.store.release_owner(descriptor)
        assert not manager._next_due and not manager._adapters and not manager._owners
        assert manager.status(record["execution_id"])["source_valid"] is False
    finally:
        manager.close()


def test_concurrent_stop_cannot_duplicate_owned_cleanup(tmp_path):
    from livemorebio.aegle.execution_contract import ExecutionError

    entered, release = threading.Event(), threading.Event()
    close_calls = []

    class SlowCleanupTechnicalAdapter(TechnicalAdapter):
        def close(self):
            assert not manager._lock._is_owned()
            close_calls.append(threading.get_ident())
            entered.set()
            assert release.wait(5), "technical cleanup was not released"

    manager = bound_manager(tmp_path, SlowCleanupTechnicalAdapter)
    record = start(manager, prepare(manager))
    try:
        with ThreadPoolExecutor(1) as pool:
            first = pool.submit(
                manager.stop, record["execution_id"],
                expected_revision=record["revision"],
                expected_source_generation="generation-a",
            )
            assert entered.wait(3), "first cleanup never entered"
            current = manager.status(record["execution_id"])
            assert current["state"] == "stopped"
            with pytest.raises(ExecutionError) as ownership:
                manager.store.acquire_owner(record["execution_id"])
            assert ownership.value.code == "EXECUTION_OWNED"
            with pytest.raises(ExecutionError) as duplicate:
                manager.stop(
                    current["execution_id"], expected_revision=current["revision"],
                    expected_source_generation="generation-a",
                )
            assert duplicate.value.code == "EXECUTION_CONFLICT"
            assert len(close_calls) == 1
            release.set()
            assert first.result(timeout=wait_seconds(3))["state"] == "stopped"
        assert len(close_calls) == 1
        descriptor = manager.store.acquire_owner(record["execution_id"])
        manager.store.release_owner(descriptor)
        assert not manager._owners and not manager._adapters
    finally:
        release.set()
        manager.close()


@pytest.mark.parametrize("operation", ["fork", "bind", "resume-retained", "resume-reconstruct", "advance"])
def test_every_distinct_admission_path_uses_the_memory_fence(tmp_path, monkeypatch, operation):
    from livemorebio.aegle.execution_contract import ExecutionError

    manager = bound_manager(tmp_path)
    record = prepare(manager)
    try:
        if operation in {"fork", "resume-retained", "resume-reconstruct", "advance"}:
            record = start(manager, record)
        if operation in {"fork", "resume-retained", "resume-reconstruct"}:
            manager.advance_once(record["execution_id"])
            record = manager.status(record["execution_id"])
            record = manager.pause(record["execution_id"], expected_revision=record["revision"],
                                   expected_source_generation="generation-a")
        if operation == "resume-reconstruct":
            manager._release(record["execution_id"])
        manager.set_source_generation("generation-b")
        with monkeypatch.context() as patch:
            patch.setattr(manager.store, "create", lambda *a, **k: pytest.fail("fenced source created a record"))
            patch.setattr(manager.store, "update", lambda *a, **k: pytest.fail("fenced admission changed a record"))
            patch.setattr(manager.store, "acquire_owner", lambda *a, **k: pytest.fail("fenced source acquired ownership"))
            patch.setattr(TechnicalAdapter, "__init__", lambda *a, **k: pytest.fail("fenced source constructed adapter"))
            patch.setattr(TechnicalAdapter, "advance", lambda *a, **k: pytest.fail("fenced source advanced"))
            with pytest.raises(ExecutionError) as failure:
                if operation == "fork":
                    manager.fork_checkpoint(record["execution_id"], captured_source(), policy=POLICY,
                                            idempotency_key="stale-fork", expected_parent_revision=record["revision"])
                elif operation == "bind":
                    manager.bind_consumer(record["execution_id"], "b" * 32, record["source_snapshot_hash"],
                                          expected_revision=record["revision"], expected_source_generation="generation-a")
                elif operation.startswith("resume"):
                    manager.resume(record["execution_id"], expected_revision=record["revision"],
                                   expected_source_generation="generation-a")
                else:
                    manager.advance_once(record["execution_id"])
            assert failure.value.code == "EXECUTION_CONFLICT"
    finally:
        manager.close()


def test_nonempty_historical_frames_remain_exact_across_late_fence(tmp_path):
    entered, release = threading.Event(), threading.Event()

    class SecondFrameTechnicalAdapter(TechnicalAdapter):
        def advance(self, checkpoint, native_end):
            if native_end > 1:
                entered.set()
                assert release.wait(5)
            return super().advance(checkpoint, native_end)

    manager = bound_manager(tmp_path, SecondFrameTechnicalAdapter)
    record = start(manager, prepare(manager))
    manager.advance_once(record["execution_id"])
    saved = manager.frames(record["execution_id"])["frames"]
    checkpoint = manager.store.get(record["execution_id"])["checkpoint"]
    assert len(saved) == 1 and saved[0]["frame_index"] == 1
    try:
        with ThreadPoolExecutor(1) as pool:
            future = pool.submit(manager.advance_once, record["execution_id"])
            assert entered.wait(3)
            manager.set_source_generation("generation-b")
            release.set()
            assert future.result(timeout=wait_seconds(3)) is None
        retained = manager.frames(record["execution_id"])
        assert retained["frames"] == saved
        assert retained["execution"]["source_valid"] is False
        assert manager.store.get(record["execution_id"])["checkpoint"] == checkpoint
    finally:
        release.set()
        manager.close()


def test_persisted_invalidity_cannot_revive_in_fresh_same_generation_manager(tmp_path):
    from livemorebio.aegle.execution_contract import ExecutionError

    first = bound_manager(tmp_path)
    record = prepare(first)
    first.store.update(record["execution_id"], expected_revision=record["revision"],
                       changes={"source_valid": False})
    first.close()
    second = bound_manager(tmp_path)
    try:
        assert not second._known
        current = second.status(record["execution_id"])
        assert current["source_generation"] == "generation-a"
        assert current["source_valid"] is False
        with pytest.raises(ExecutionError) as failure:
            start(second, current)
        assert failure.value.code == "EXECUTION_CONFLICT"
        assert not second._owners and not second._adapters
    finally:
        second.close()


def test_deny_all_is_not_standalone_unbound_compatibility(tmp_path):
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.execution_contract import ExecutionError, seal_source

    manager = bound_manager(tmp_path)
    original = prepare(manager)
    try:
        manager.set_source_generation(DENY_ALL)
        for generation in ("generation-a", "generation-b"):
            source = captured_source()
            source["source_generation"] = generation
            source = seal_source(source)
            with pytest.raises(ExecutionError):
                manager.prepare(source, POLICY, "denied-" + generation)
        assert manager.status(original["execution_id"])["source_valid"] is False
        manager.set_source_generation("generation-b")
        source = captured_source()
        source["source_generation"] = "generation-b"
        assert manager.prepare(seal_source(source), POLICY, "reconciled-source")["source_valid"] is True
        assert manager.status(original["execution_id"])["source_valid"] is False
    finally:
        manager.close()


@pytest.mark.parametrize("fence_kind", ["replacement", "deny_all"])
@pytest.mark.parametrize("stage", ["initialize", "advance"])
def test_late_native_result_cannot_commit_across_memory_fence(tmp_path, monkeypatch, fence_kind, stage):
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.execution_contract import ExecutionError

    entered, release = threading.Event(), threading.Event()

    class BlockedTechnicalAdapter(TechnicalAdapter):
        def initialize(self):
            if stage == "initialize":
                entered.set()
                assert release.wait(5)
            return super().initialize()

        def advance(self, checkpoint, native_end):
            entered.set()
            assert release.wait(5)
            return super().advance(checkpoint, native_end)

    manager = bound_manager(tmp_path, BlockedTechnicalAdapter)
    record = prepare(manager)
    if stage == "advance":
        record = start(manager, record)
    before = manager.store.get(record["execution_id"])
    operation = (lambda: start(manager, record)) if stage == "initialize" else (
        lambda: manager.advance_once(record["execution_id"]))
    try:
        with ThreadPoolExecutor(1) as pool:
            future = pool.submit(operation)
            assert entered.wait(3), "technical adapter never entered"
            manager.set_source_generation(DENY_ALL if fence_kind == "deny_all" else "generation-b")
            with monkeypatch.context() as patch:
                patch.setattr(manager.store, "update", lambda *a, **k: (_ for _ in ()).throw(ExecutionError("EXECUTION_STORAGE")))
                with pytest.raises(ExecutionError):
                    manager.invalidate_source("generation-a", "technical-source-change")
            release.set()
            try:
                outcome = future.result(timeout=wait_seconds(3))
            except ExecutionError:
                outcome = None
            assert outcome is None
        retained = manager.store.get(record["execution_id"])
        assert retained["checkpoint"] == before["checkpoint"]
        assert retained["latest_frame"] == before["latest_frame"] == 0
        assert manager.frames(record["execution_id"])["frames"] == []
        assert manager.status(record["execution_id"])["source_valid"] is False
        assert manager._next_due == {}
    finally:
        release.set()
        manager.close()


def test_consumer_renewal_and_projection_observe_memory_fence(tmp_path):
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.execution_contract import ExecutionError

    manager = bound_manager(tmp_path)
    record = prepare(manager)
    session = "a" * 32
    try:
        bound = manager.bind_consumer(
            record["execution_id"], session, record["source_snapshot_hash"],
            expected_revision=record["revision"], expected_source_generation="generation-a",
        )
        manager.set_source_generation(DENY_ALL)
        assert manager.store.get(record["execution_id"])["source_valid"] is True
        status = manager.status(record["execution_id"])
        assert status["source_valid"] is False
        assert status["consumer_lease"]["state"] == "source_invalid"
        with pytest.raises(ExecutionError):
            manager.renew_consumer(
                bound["execution_id"], session, bound["source_snapshot_hash"],
                expected_source_generation="generation-a",
            )
    finally:
        manager.close()


def test_pause_and_stop_of_historical_source_remain_possible(tmp_path):
    manager = bound_manager(tmp_path)
    record = start(manager, prepare(manager))
    try:
        manager.set_source_generation("generation-b")
        paused = manager.pause(
            record["execution_id"], expected_revision=record["revision"],
            expected_source_generation="generation-a",
        )
        assert paused["state"] == "paused" and paused["source_valid"] is False
        stopped = manager.stop(
            paused["execution_id"], expected_revision=paused["revision"],
            expected_source_generation="generation-a",
        )
        assert stopped["state"] == "stopped" and stopped["source_valid"] is False
        assert not manager._owners and not manager._adapters and not manager._next_due
    finally:
        manager.close()


def test_completed_execution_failed_cleanup_is_explicitly_retryable_without_changing_frames(tmp_path):
    from livemorebio.aegle.execution_contract import ExecutionError

    class CleanupAdapter(TechnicalAdapter):
        fail_close = True

        def close(self):
            if self.fail_close:
                raise RuntimeError("technical cleanup failure")

    manager = bound_manager(tmp_path, CleanupAdapter)
    prepared = manager.prepare(captured_source(), {**POLICY, "end_native": 1.0}, "completion-cleanup")
    running = start(manager, prepared)
    adapter = manager._adapters[running["execution_id"]]
    try:
        with pytest.raises(ExecutionError):
            manager.advance_once(running["execution_id"])
        current = manager.status(running["execution_id"])
        assert current["state"] == "completed"
        assert current["failure_code"] == "EXECUTION_CLEANUP_UNCONFIRMED"
        saved = manager.frames(current["execution_id"])["frames"]
        assert len(saved) == 1
        adapter.fail_close = False
        stopped = manager.stop(current["execution_id"], expected_revision=current["revision"],
                               expected_source_generation="generation-a")
        assert stopped["state"] == "completed", "cleanup must preserve completion"
        assert stopped["revision"] == current["revision"]
        assert manager.frames(current["execution_id"])["frames"] == saved
        descriptor = manager.store.acquire_owner(current["execution_id"])
        manager.store.release_owner(descriptor)
        assert not manager._owners and not manager._adapters
    finally:
        adapter.fail_close = False
        manager.close()


def test_failed_shutdown_retains_ownership_until_explicit_shutdown_retry(tmp_path):
    from livemorebio.aegle.execution_contract import ExecutionError

    class ShutdownAdapter(TechnicalAdapter):
        fail_close = True

        def close(self):
            if self.fail_close:
                raise RuntimeError("technical shutdown failure")

    manager = bound_manager(tmp_path, ShutdownAdapter)
    record = start(manager, prepare(manager))
    adapter = manager._adapters[record["execution_id"]]
    try:
        with pytest.raises(ExecutionError) as failed:
            manager.close()
        assert failed.value.code == "EXECUTION_CLEANUP_UNCONFIRMED"
        with pytest.raises(ExecutionError):
            manager.store.acquire_owner(record["execution_id"])
        with pytest.raises(ExecutionError) as closed:
            manager.prepare(captured_source(), POLICY, "must-remain-closed")
        assert closed.value.code == "EXECUTION_CLOSED"
        adapter.fail_close = False
        manager.close()
        descriptor = manager.store.acquire_owner(record["execution_id"])
        manager.store.release_owner(descriptor)
        assert not manager._owners and not manager._adapters and not manager._cleanup_pending
    finally:
        adapter.fail_close = False
        manager.close()
