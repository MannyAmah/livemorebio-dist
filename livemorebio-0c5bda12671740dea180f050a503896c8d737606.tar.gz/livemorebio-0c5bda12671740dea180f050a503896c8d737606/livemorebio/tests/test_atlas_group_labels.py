"""Reference callout layout, not source geometry or GPU acceptance."""
from __future__ import annotations

import json

import pytest

from .test_atlas_reference_ui import CONSOLE, node
from .test_atlas_selection_presentation import scene_program


def check(code: str) -> None:
    program = f"""import assert from 'node:assert/strict';
import {{layoutGroupCallouts}} from {json.dumps((CONSOLE/'lib/atlas_reference_presentation.js').as_uri())};
import {{ATLAS_GROUPS}} from {json.dumps((CONSOLE/'lib/atlas_reference_contract.js').as_uri())};
const keys=ATLAS_GROUPS.map(g=>g[0]);
const inputs=(x=0,y=0)=>keys.map(key=>({{key,anchor:{{x,y,z:0,depth:2}},width:90,height:20}}));
const verify=(result,width,height)=>{{
 assert.deepEqual([...result.placed.map(p=>p.key),...result.omitted.map(p=>p.key)].sort(),[...keys].sort());
 for(const p of result.placed){{
  assert(p.x>=8&&p.y>=8&&p.x+p.width<=width-8&&p.y+p.height<=height-8);
  for(const point of [p.anchor,p.leader])assert(Number.isFinite(point.x)&&Number.isFinite(point.y)&&point.x>=0&&point.x<=width&&point.y>=0&&point.y<=height);
 }}
 for(let i=0;i<result.placed.length;i++)for(let j=i+1;j<result.placed.length;j++){{const a=result.placed[i],b=result.placed[j];
  assert(a.x+a.width+6<=b.x||b.x+b.width+6<=a.x||a.y+a.height+6<=b.y||b.y+b.height+6<=a.y,'callouts collide');
 }}
}};
{code}
console.log('ok');"""
    assert node(program).strip() == "ok"


@pytest.mark.parametrize("width,height", [(390, 440), (768, 490), (1440, 490), (334, 440), (80, 55)])
def test_coincident_anchors_have_inset_gap_stable_identity_and_overflow(width, height):
    check(f"""
const source=inputs(),before=JSON.stringify(source),result=layoutGroupCallouts(source,{width},{height},.1,10);
verify(result,{width},{height});assert.equal(JSON.stringify(source),before);
assert.deepEqual(layoutGroupCallouts([...source].reverse(),{width},{height},.1,10),result);
if({width}>=334)assert.equal(result.placed.length,9);else assert.equal(result.omitted.length,9);
""")


def test_wide_opposite_rails_cannot_overlap_and_never_shrink_text():
    check("""
const source=inputs();source.forEach((p,i)=>{p.anchor.x=i%2?-.01:.01;p.width=250;p.height=35});
const result=layoutGroupCallouts(source,334,180,.1,10);verify(result,334,180);
assert(result.omitted.length>0);assert(result.placed.every(p=>p.width===250&&p.height===35));
for(const p of result.placed){assert.equal(p.x,p.anchor.x<167?8:334-8-250);assert.equal(p.leader.x,p.anchor.x<167?p.x+p.width:p.x);}
""")


@pytest.mark.parametrize("change", ["x", "y", "z", "depth", "near", "far", "nan", "infinite", "width", "height", "duplicate"])
def test_invalid_outside_or_ambiguous_anchor_is_omitted(change):
    check(f"""
const source=inputs(),item=source[0],change={json.dumps(change)};
if(['x','y','z'].includes(change))item.anchor[change]=1.01;
if(change==='depth')item.anchor.depth=-2;
if(change==='near')item.anchor.depth=.01;
if(change==='far')item.anchor.depth=11;
if(change==='nan')item.anchor.x=NaN;
if(change==='infinite')item.anchor.depth=Infinity;
if(change==='width')item.width=Infinity;
if(change==='height')item.height=-1;
if(change==='duplicate')source.push(structuredClone(item));
const result=layoutGroupCallouts(source,390,440,.1,10);verify(result,390,440);
assert(!result.placed.some(p=>p.key===keys[0]));assert(result.omitted.some(p=>p.key===keys[0]));
""")


def test_retained_cluster_uses_actual_anchor_positions_but_noncolliding_rails():
    check("""
const rectangles=[[410.957,235,36.086,20],[413.430,124.742,42.109,20],[405.539,154.859,42.109,20],[372.594,176.906,84.25,20],[401.051,170.813,60.164,20],[405.074,172.555,78.227,20],[379.340,136.914,72.211,20],[413.875,122.563,66.188,20],[407.969,48.102,42.109,20]];
// Array order is authored test identity, not inferred identity of the retained DOM.
const source=rectangles.map(([x,y,width,height],i)=>({key:keys[i],width,height,anchor:{x:(x+width/2)/858*2-1,y:1-(y+height/2)/490*2,z:0,depth:2}}));
const result=layoutGroupCallouts(source,858,490,.1,10);verify(result,858,490);assert.equal(result.placed.length,9);
for(const p of result.placed){const a=source.find(c=>c.key===p.key).anchor;assert(Math.abs(p.anchor.x-(a.x/2+.5)*858)<1e-9);}
""")


def test_layout_arithmetic_grid_is_gap_safe_and_deterministic_at_fractional_sizes():
    check("""
for(const width of [17,39,180.5,334,390,768])for(const height of [17,75.25,160,440]){
 const source=inputs();source.forEach((item,i)=>{item.anchor.x=(i%3-1)*.99;item.anchor.y=((i*3)%7-3)/3;item.width=20+i*9.125;item.height=16+(i%3)*8.5;});
 const result=layoutGroupCallouts(source,width,height,.1,10);verify(result,width,height);
 assert.deepEqual(layoutGroupCallouts(source.slice(3).concat(source.slice(0,3)),width,height,.1,10),result);
}
""")


def test_visible_selected_extent_label_is_one_reserved_near_corner_obstacle():
    check("""
const source=inputs(.95,.85),reserved={x:286,y:8,width:96,height:24},before=JSON.stringify(reserved);
const result=layoutGroupCallouts(source,390,440,.1,10,reserved);verify(result,390,440);
assert.equal(result.placed.length,9,'selection must not hide group callouts');
for(const p of result.placed)assert(p.x+p.width+6<=reserved.x||reserved.x+reserved.width+6<=p.x||p.y+p.height+6<=reserved.y||reserved.y+reserved.height+6<=p.y,'selected label collides with group label');
assert.equal(JSON.stringify(reserved),before);assert.deepEqual(layoutGroupCallouts([...source].reverse(),390,440,.1,10,reserved),result);
assert.deepEqual(layoutGroupCallouts(source,390,440,.1,10,null),layoutGroupCallouts(source,390,440,.1,10));
""")


@pytest.mark.parametrize("reserved", ["{x:NaN,y:8,width:90,height:20}", "{x:8,y:8,width:-1,height:20}", "{x:380,y:8,width:90,height:20}", "[]"])
def test_invalid_selected_label_rectangle_never_claims_nonoverlap(reserved):
    check(f"""
const result=layoutGroupCallouts(inputs(),390,440,.1,10,{reserved});
assert.equal(result.placed.length,0);assert.equal(result.omitted.length,9);assert(result.omitted.every(row=>row.reason==='invalid'));
""")


def scene(code: str) -> None:
    program = scene_program(code)
    program = program.replace("const config={host,vendor:", "const reports=[];const config={onLabels:r=>reports.push(r),host,vendor:")
    program = program.replace("this.className==='atlas-reference-selection-label'", "['atlas-reference-selection-label','atlas-reference-group-label'].includes(this.className)")
    assert node(program).strip() == "ok"


def test_actual_scene_callouts_keep_source_material_camera_and_association():
    scene("""
const before=capture(mesh('FJ2810')),cameraBefore=view.view().camera,color=mesh('FJ2810').material.color.getHex();
view.update({labels:true});flush();
assert.equal(reports.at(-1).state,'ready');assert.deepEqual(reports.at(-1).placed,['pancreas']);
const label=find('atlas-reference-group-label'),leader=find('atlas-reference-leader');
assert.equal(label.hidden,false);assert.equal(leader.hidden,false);assert.equal(label.attributes['data-group-key'],'pancreas');assert.equal(leader.attributes['data-group-key'],'pancreas');
assert.equal(find('atlas-reference-labels').attributes['aria-hidden'],'true');
assert.equal(capture(mesh('FJ2810')),before);assert.deepEqual(view.view().camera,cameraBefore);assert.equal(mesh('FJ2810').material.color.getHex(),color);
view.update({groups:[]});flush();assert.equal(label.hidden,true);assert(reports.at(-1).omitted.some(r=>r.key==='pancreas'&&r.reason==='disabled'));
""")


def test_actual_scene_reserves_visible_extent_label_without_moving_it():
    scene("""
host.clientWidth=210;host.clientHeight=80;observers[0]();view.select('FJ2810');flush();
const cue=find('atlas-reference-selection'),selectedLabel=find('atlas-reference-selection-label');
assert.equal(cue.hidden,false);assert.equal(selectedLabel.hidden,false);
const fixed=JSON.stringify(selectedLabel.style),before=capture(mesh('FJ2810')),cameraBefore=view.view().camera;
view.update({labels:true});flush();const label=find('atlas-reference-group-label');assert.equal(label.hidden,false);
const rect=e=>({x:parseFloat(e.style.left),y:parseFloat(e.style.top),...e.getBoundingClientRect()});
const a=rect(label),b=rect(selectedLabel);
assert(a.x+a.width+6<=b.x||b.x+b.width+6<=a.x||a.y+a.height+6<=b.y||b.y+b.height+6<=a.y,'source extent label overlaps group label');
assert.equal(JSON.stringify(selectedLabel.style),fixed);assert.equal(capture(mesh('FJ2810')),before);assert.deepEqual(view.view().camera,cameraBefore);
view.select(null);flush();assert.equal(cue.hidden,true);assert.equal(label.hidden,false);
""")


@pytest.mark.parametrize("mode", ["section", "isolation", "hidden", "context", "off", "small"])
def test_callout_suppression_reports_reason_and_recovers_without_geometry_change(mode):
    scene(f"""
view.update({{labels:true}});flush();const before=capture(mesh('FJ2810')),label=find('atlas-reference-group-label'),mode={json.dumps(mode)};
assert.equal(label.hidden,false);
if(mode==='section')view.update({{axis:'x'}});
if(mode==='isolation'){{view.select('FJ2810');view.update({{isolated:true}})}}
if(mode==='hidden'){{document.hidden=true;view.visible()}}
if(mode==='context')renderer.domElement.handlers.webglcontextlost({{preventDefault(){{}}}});
if(mode==='off')view.update({{labels:false}});
if(mode==='small'){{host.clientWidth=18;observers[0]()}}
flush();assert.equal(label.hidden,true);assert.equal(capture(mesh('FJ2810')),before);
if(mode==='small')assert(reports.at(-1).omitted.some(r=>r.key==='pancreas'&&r.reason==='space'));
else assert.equal(reports.at(-1).state,mode);
if(!['context','small'].includes(mode)){{document.hidden=false;view.home();view.update({{labels:true}});view.visible();flush();assert.equal(label.hidden,false)}}
""")
