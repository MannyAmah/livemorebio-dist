"""Isolated HTTP evidence tests, using technical fixtures and temporary stores only."""
from __future__ import annotations

import asyncio
import copy
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3

from fastapi import FastAPI
from fastapi.testclient import TestClient
import pytest

from livemorebio.aegle import research_api
from livemorebio.cendos.protocol_runs import ProtocolRunStore
from livemorebio.research import ResearchService, ResearchStore


RUN_ID = "protocol-" + "a" * 32
RECORD_ID = "research-" + "b" * 32
AUTH = {"Authorization": "Bearer research-api-test-only"}


def run_fixture() -> dict:
    return {
        "run_id": RUN_ID,
        "protocol_id": "cendos.garcinoic-acid-pxr.v1",
        "evidence_state": "MODELED_TARGET_ENGAGEMENT",
        "qualification_state": "NOT_QUALIFIED",
        "cohort": {"name": "technical fixture", "cohort_id": "cohort-fixture"},
        "target_engagement": [{"concentration_um": 1.3, "members": [
            {"member_id": "member-1", "relative_pxr_activation": .5}]}],
    }


def study_spec() -> dict:
    return {
        "run_id": RUN_ID, "title": "Technical HTTP comparison",
        "endpoint": "relative_pxr_activation", "tolerance": .1,
        "rationale": "Technical test only, no biological acceptance claim",
        "mapping": {"specimen-1": "member-1"}, "method_id": "fixture-method",
        "material_id": "fixture-material", "controls": ["vehicle", "positive"],
    }


def measurement_payload() -> dict:
    stamp = datetime.now(timezone.utc).isoformat()
    return {
        "csv": "sample_id,member_id,concentration_um,endpoint,unit,value,replicate_id,measured_at,quality_status\n"
               f"specimen-1,member-1,1.3,relative_pxr_activation,1,.53,1,{stamp},pass\n",
        "source_class": "TECHNICAL_FIXTURE", "instrument_id": "fixture-reader",
        "calibration_id": "fixture-cal", "method_id": "fixture-method",
        "material_id": "fixture-material", "operator_id": "fixture-operator",
        "controls_passed": True, "calibration_current": True,
        "source_reference": "local technical fixture",
    }


def learning_payload() -> dict:
    return {"module": "metabolic", "level": "molecular", "claim": "Technical hypothesis",
            "sources": ["https://pubmed.ncbi.nlm.nih.gov/40472098/"],
            "counterevidence": "Uncertain outside context", "test_plan": "Independent endpoint",
            "applicability": "Technical test only", "author": "fixture-operator"}


@pytest.fixture
def api(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    from livemorebio.aegle import server

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "research-api-test-only")
    service = ResearchService(ResearchStore(tmp_path / "research.sqlite3", key=b"t" * 32))
    runs = ProtocolRunStore(tmp_path / "protocol-runs")
    runs.save(run_fixture())
    monkeypatch.setattr(research_api, "service", lambda: service)
    monkeypatch.setattr(server, "_protocol_run_store", lambda: runs)
    app = FastAPI()
    app.include_router(research_api.router)
    return TestClient(app, raise_server_exceptions=False), service, runs


ROUTES = [
    ("GET", "/api/research/overview"),
    ("GET", f"/api/research/records/{RECORD_ID}"),
    ("GET", f"/api/research/records/{RECORD_ID}/export.json"),
    ("POST", "/api/research/studies"),
    ("POST", f"/api/research/studies/{RECORD_ID}/measurements"),
    ("POST", f"/api/research/studies/{RECORD_ID}/compare"),
    ("POST", "/api/research/resilience"),
    ("POST", f"/api/research/resilience/{RECORD_ID}/assess"),
    ("POST", "/api/research/learning"),
    ("GET", "/api/research/sources/kegg/" + "H" + "00001"),
    ("POST", "/api/research/sources/import"),
]


@pytest.mark.parametrize("method,path", ROUTES)
def test_every_research_data_route_requires_auth_before_storage(api, monkeypatch, method, path):
    client, _, _ = api

    def unexpected_access():
        pytest.fail("unauthorized request reached research storage")

    monkeypatch.setattr(research_api, "service", unexpected_access)
    response = client.request(method, path, content=b"{invalid JSON")
    assert response.status_code == 401
    assert response.json() == {"detail": "authentication required"}
    assert response.headers.get("Cache-Control") == "no-store"


@pytest.mark.parametrize("method,path", [("GET", "/api/research/overview"),
                                          ("POST", "/api/research/learning")])
def test_main_app_auth_middleware_cannot_bypass_no_store(api, method, path):
    from livemorebio.aegle import server

    response = TestClient(server.app, raise_server_exceptions=False).request(method, path)
    assert response.status_code == 401
    assert response.headers.get("Cache-Control") == "no-store"


@pytest.mark.parametrize("raw", [b"[]", b"null", b"{", b'{"a":NaN}',
                                 b'{"a":1e999}', b'{"a":1,"a":2}',
                                 b'{"a":' + b"[" * 1500 + b"]" * 1500 + b"}"],
                         ids=["array", "null", "truncated", "nan", "overflow", "duplicate", "depth"])
def test_research_rejects_malformed_or_ambiguous_json_before_any_write(api, raw):
    client, service, _ = api
    response = client.post("/api/research/learning", content=raw, headers=AUTH)
    assert response.status_code == 422
    assert response.json()["code"] == "RESEARCH_INPUT_INVALID"
    assert response.headers.get("Cache-Control") == "no-store"
    assert service.store.list() == []


@pytest.mark.parametrize("suffix", [',"ignored":NaN}', ',"ignored":1e999}',
                                   ',"level":"molecular"}'])
def test_invalid_json_cannot_hide_inside_otherwise_valid_learning(api, suffix):
    client, service, _ = api
    raw = json.dumps(learning_payload())[:-1] + suffix
    response = client.post("/api/research/learning", content=raw, headers=AUTH)
    assert response.status_code == 422
    assert service.store.list() == []


def test_request_size_limit_prevents_any_write(api):
    client, service, _ = api
    response = client.post("/api/research/learning", content=b" " * 2_000_001, headers=AUTH)
    assert response.status_code == 422
    assert "2 MB" in response.json()["error"]
    assert service.store.list() == []


def test_freeze_reads_server_run_not_caller_predictions_and_preserves_it(api):
    from livemorebio.aegle import server

    client, service, runs = api
    original = copy.deepcopy(runs.get(RUN_ID))
    state_before = copy.deepcopy(server._state["tw"].profile.__dict__)
    payload = {**study_spec(), "run": {"prediction": 999}, "predictions": [999]}
    response = client.post("/api/research/studies", json=payload, headers=AUTH)
    assert response.status_code == 201
    study = response.json()
    assert study["run"] == original
    assert study["qualification_state"] == "NOT_QUALIFIED"
    assert response.headers.get("Cache-Control") == "no-store"
    assert runs.get(RUN_ID) == original
    assert server._state["tw"].profile.__dict__ == state_before
    assert service.store.get(study["id"])["run"] == original


def test_missing_frozen_run_is_typed_422_and_has_no_write(api):
    client, service, _ = api
    response = client.post("/api/research/studies", json={**study_spec(), "run_id": "../missing"}, headers=AUTH)
    assert response.status_code == 422
    assert response.json()["code"] == "RESEARCH_INPUT_INVALID"
    assert service.store.list() == []


@pytest.mark.parametrize("bad_run", [None, [], {"run_id": RUN_ID},
    {**run_fixture(), "target_engagement": None},
    {**run_fixture(), "target_engagement": [{"concentration_um": 1.3, "members": [{}]}]},
    {**run_fixture(), "evidence_state": "CLINICALLY_VALIDATED"},
    {**run_fixture(), "target_engagement": [{"concentration_um": 1.3, "members": [
        {"member_id": "member-1", "relative_pxr_activation": float("nan")}]}]},
])
def test_malformed_frozen_run_is_typed_422_not_a_server_error(api, monkeypatch, bad_run):
    client, service, runs = api
    monkeypatch.setattr(runs, "get", lambda _: bad_run)
    response = client.post("/api/research/studies", json=study_spec(), headers=AUTH)
    assert response.status_code == 422
    assert response.json()["code"] == "RESEARCH_INPUT_INVALID"
    assert service.store.list() == []


def test_frozen_protocol_save_cannot_overwrite_or_mutate_original(api):
    _, _, runs = api
    original = runs.get(RUN_ID)
    changed = copy.deepcopy(original)
    changed["target_engagement"][0]["members"][0]["relative_pxr_activation"] = 999
    with pytest.raises(ValueError, match="immutable"):
        runs.save(changed)
    assert runs.get(RUN_ID) == original
    assert runs.save(copy.deepcopy(original)) == original
    assert not list(runs.directory.glob("*.tmp"))


def test_fixture_measurement_comparison_does_not_accept_caller_predictions_or_validate(api):
    client, service, runs = api
    before = runs.get(RUN_ID)
    study = client.post("/api/research/studies", json=study_spec(), headers=AUTH).json()
    payload = measurement_payload()
    admitted = client.post(f"/api/research/studies/{study['id']}/measurements", json=payload, headers=AUTH)
    assert admitted.status_code == 201
    measurement = admitted.json()
    assert "raw_csv" not in measurement
    assert measurement["instrument_authenticity"] == "NOT_INDEPENDENTLY_VERIFIED"
    comparison = client.post(f"/api/research/studies/{study['id']}/compare", headers=AUTH,
        json={"measurement_id": measurement["id"], "predicted": .53, "qualification_state": "VALIDATED"})
    assert comparison.status_code == 200
    result = comparison.json()
    assert result["pairs"][0]["predicted"] == .5
    assert result["pairs"][0]["residual"] == pytest.approx(.03)
    assert result["status"] == "TECHNICAL_CHECK_ONLY"
    assert result["calibration_authorized"] is False
    assert runs.get(RUN_ID) == before
    assert "raw_csv" not in client.get(f"/api/research/records/{measurement['id']}", headers=AUTH).json()
    exported = client.get(f"/api/research/records/{measurement['id']}/export.json", headers=AUTH)
    assert exported.json()["raw_csv"] == payload["csv"]
    assert exported.headers.get("Cache-Control") == "no-store"
    assert "attachment" in exported.headers["Content-Disposition"]
    assert b"fixture-reader" not in service.store.path.read_bytes()


@pytest.mark.parametrize("column,value", [("unit", "mg/dL"), ("member_id", "unknown"),
                                        ("value", "NaN"), ("quality_status", "invented")])
def test_invalid_measurement_cannot_create_evidence(api, column, value):
    import csv
    import io

    client, service, _ = api
    study = client.post("/api/research/studies", json=study_spec(), headers=AUTH).json()
    payload = measurement_payload()
    reader = csv.DictReader(io.StringIO(payload["csv"]))
    rows = list(reader)
    rows[0][column] = value
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=reader.fieldnames)
    writer.writeheader()
    writer.writerows(rows)
    payload["csv"] = output.getvalue()
    response = client.post(f"/api/research/studies/{study['id']}/measurements", json=payload, headers=AUTH)
    assert response.status_code == 422
    assert service.store.list("measurement") == []


def test_measurement_cannot_be_reused_for_different_frozen_study(api):
    client, service, _ = api
    first = client.post("/api/research/studies", json=study_spec(), headers=AUTH).json()
    second = client.post("/api/research/studies", json=study_spec(), headers=AUTH).json()
    measured = client.post(f"/api/research/studies/{first['id']}/measurements",
                           json=measurement_payload(), headers=AUTH).json()
    response = client.post(f"/api/research/studies/{second['id']}/compare",
                           json={"measurement_id": measured["id"]}, headers=AUTH)
    assert response.status_code == 422
    assert service.store.list("comparison") == []


def test_invalid_learning_url_is_typed_422(api):
    client, service, _ = api
    response = client.post("/api/research/learning", headers=AUTH,
                           json={**learning_payload(), "sources": ["https://[invalid"]})
    assert response.status_code == 422
    assert service.store.list() == []


def test_storage_exception_is_safe_and_no_store(api, monkeypatch):
    client, _, _ = api

    def fail():
        raise sqlite3.OperationalError("SENSITIVE_RAW_CONTENT_MUST_NOT_LEAK")

    monkeypatch.setattr(research_api, "service", fail)
    response = client.get("/api/research/overview", headers=AUTH)
    assert response.status_code == 503
    assert "SENSITIVE_RAW_CONTENT" not in response.text
    assert response.headers.get("Cache-Control") == "no-store"


def test_research_key_configuration_failure_is_safe(monkeypatch, tmp_path):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "research-api-test-only")
    monkeypatch.setenv("LIVEMORE_RESEARCH_STORE", str(tmp_path / "research.sqlite3"))

    def fail(*, create):
        raise RuntimeError("KEY_CONFIGURATION_MUST_NOT_LEAK")

    monkeypatch.setattr(research_api, "patch_storage_key", fail)
    app = FastAPI()
    app.include_router(research_api.router)
    response = TestClient(app, raise_server_exceptions=False).get("/api/research/overview", headers=AUTH)
    assert response.status_code == 503
    assert response.json()["code"] == "RESEARCH_STORAGE_UNAVAILABLE"
    assert "KEY_CONFIGURATION" not in response.text


def test_async_mutation_does_not_run_sqlite_on_event_loop(api, monkeypatch):
    client, service, _ = api
    original = service.record_learning

    def checked(payload):
        with pytest.raises(RuntimeError, match="no running event loop"):
            asyncio.get_running_loop()
        return original(payload)

    monkeypatch.setattr(service, "record_learning", checked)
    response = client.post("/api/research/learning", json=learning_payload(), headers=AUTH)
    assert response.status_code == 201
    assert response.json()["model_change_authorized"] is False


@pytest.mark.parametrize("name", ["=1+1", "+1+1", "-1+1", "@SUM(1)", " \t=1+1"])
def test_protocol_csv_cannot_execute_cohort_names_as_formulas(name):
    import csv
    import io
    from livemorebio.cendos.protocol_runs import analysis_csv

    result = run_fixture()
    result["cohort"]["name"] = name
    result["structure"] = {"pdb_id": "6P2B"}
    result["target_engagement"][0]["mean_occupancy"] = .7
    result["target_engagement"][0]["members"][0]["nr1i2_expression_factor"] = 1.
    row = next(csv.DictReader(io.StringIO(analysis_csv(result))))
    assert row["cohort"].startswith("'")
    assert result["cohort"]["name"] == name
