"""Node.js execution helper for browser-harness tests.

Two portability defects in the delivered checkpoint are corrected here: the
hardcoded Homebrew executable path, and inline ``--eval`` programs large enough
to exceed the per-argument limit on Linux (``OSError: Argument list too long``).
Large programs are streamed from a private temporary file; small ones keep the
original inline form. Both retain inline import and ``process.argv`` semantics.

Node.js is not a prerequisite of the product, so a host without it skips these
tests. The toolchain resolver alone says whether there is one, and
``require_node`` is the only gate: it returns the executable the resolver found,
or skips. A test runs what the gate returned, directly or through ``run_node``,
so the question and the launch cannot be answered by different lookups.

One run must not skip: the hosted workflow that exists to run these tests. It
sets ``LIVEMORE_REQUIRE_NODE=1``, and the gate then fails where it would skip.
"""
from __future__ import annotations

import errno
import os
import subprocess
import sys
import tempfile

import pytest

from .._toolchain import NODE_ENV, node_executable, playwright_available, playwright_module

# What the resolver found when this module was imported, or None. It stands in
# the command lists handed to ``run_node``, which replaces it with what the gate
# returns. It is never a place to look when the resolver found nothing: it used
# to fall back to the Homebrew path, which made it a second resolver that said
# yes on the author's machine and named a missing file everywhere else.
NODE = node_executable()
# Linux caps a single argument at 128 KiB (MAX_ARG_STRLEN) and the total at
# ARG_MAX, so the practical ceiling is well below the theoretical one. Spill
# early, retaining the working directory as Node's import resolution base.
_SPILL_BYTES = 16_000
_EVAL_FLAGS = ("--eval", "-e")
NO_NODE = "Node.js is not installed on this host; browser-harness test skipped"
_NODE_NAMES = frozenset({"node", "nodejs", "node.exe"})
# Set to 1 by a run whose purpose is to exercise the console's JavaScript: the
# hosted Installer workflow. There a skip is a release gate that verified none
# of it and exited 0, so the skip becomes a failure. Neither the installer nor
# the Dockerfile sets it, so with it unset no install and no image build
# requires Node.js, which is not a prerequisite of the product. It is inherited:
# the installer hands its verification run whatever its caller exported, on
# purpose, so a strict run stays strict when it verifies an install.
REQUIRE_NODE_ENV = "LIVEMORE_REQUIRE_NODE"


def node_is_required() -> bool:
    """Whether this run has declared that it must not skip for want of Node.js."""
    declared = os.environ.get(REQUIRE_NODE_ENV, "")
    if declared not in ("", "0", "1"):
        # A misspelt switch must not quietly mean "not required".
        raise ValueError(f"{REQUIRE_NODE_ENV} must be unset, 0 or 1, not {declared!r}")
    return declared == "1"


def _no_node_where_it_is_required() -> str:
    configured = os.environ.get(NODE_ENV, "").strip()
    # The resolver answers None for a configured path it cannot run, and does
    # not look further. That is a different fault from having no Node.js.
    cause = (f"{NODE_ENV} names {configured}, which is not an executable" if configured
             else f"the toolchain resolver found no Node.js: {NODE_ENV} is unset, there is no node on PATH, "
                  "and none at the well-known locations")
    return (f"{REQUIRE_NODE_ENV}=1 says this run must exercise the console's JavaScript, and {cause}. "
            f"Install Node.js or correct {NODE_ENV}; unset {REQUIRE_NODE_ENV} only where skipping "
            "these tests is intended.")


def require_node() -> str:
    """The Node.js executable to run, or an explicit skip where there is none.

    Where the run has declared that it requires Node.js, a failure instead.
    """
    node = node_executable()
    if node is None:
        if node_is_required():
            pytest.fail(_no_node_where_it_is_required(), pytrace=False)
        pytest.skip(NO_NODE)
    return node


def refuse_node_the_resolver_did_not_find(event: str, arguments: tuple) -> None:
    """Audit hook: where the resolver reports no Node.js, there is none to start.

    The resolver looks on PATH and then in a few well-known locations, so a
    developer's machine usually has a Node.js that a test can reach by naming
    one of those locations, whatever the resolver was told. Such a test passes
    there and fails in the container image, which has no Node.js anywhere; that
    is how 348 unguarded tests went unnoticed. In a session the resolver says
    has no Node.js, starting one therefore fails with the error a host without
    it raises, so the verdict here is the verdict there.
    """
    if event != "subprocess.Popen":
        return
    executable = arguments[0]
    if not isinstance(executable, (str, bytes, os.PathLike)):
        return
    if os.path.basename(os.fsdecode(executable)).lower() not in _NODE_NAMES:
        return
    if node_executable() is None:
        raise FileNotFoundError(
            errno.ENOENT,
            "No Node.js on this host according to the toolchain resolver; a test starts "
            "Node.js only through livemorebio/tests/_node.py, which skips when there is none",
            executable)


def hold_a_session_without_node_to_its_absence() -> bool:
    """Install the refusal, but only where the resolver finds no Node.js.

    A host that has Node.js gets no hook, and its tests run exactly as before.
    """
    if node_executable() is not None:
        return False
    sys.addaudithook(refuse_node_the_resolver_did_not_find)
    return True


def require_playwright() -> str:
    if not playwright_available():
        pytest.skip(f"Playwright module not present at {playwright_module()}; set LIVEMORE_PLAYWRIGHT_MODULE")
    module = playwright_module()
    # The .cjs harnesses read this variable. Publishing what the resolver found
    # means a child process uses the same Playwright, wherever it lives, rather
    # than a path compiled into the tool.
    os.environ.setdefault("LIVEMORE_PLAYWRIGHT_MODULE", module)
    return module


def flush_js(quiet_turns: int, deadline_ms: int = 15_000) -> str:
    """JavaScript defining ``flush`` for a harness that mounts a real controller.

    Those harnesses stand in for every dependency of the controller except the
    integrity digest (``crypto.subtle.digest``), which stays real and completes
    on the runtime's thread pool. How many event-loop turns that takes is set by
    the host's scheduler, not by the program: one on a fast machine, more than
    any fixed budget on a slow one. A flush that only counts turns therefore
    returns while a load is still in flight, and the assertions after it read a
    half-loaded page.

    So the digest is counted, and ``flush`` returns only after ``quiet_turns``
    consecutive turns with none outstanding. When no digest is in flight that is
    exactly the fixed count these harnesses used before, so an assertion that
    nothing happened is as strong as it was. A digest that never completes is
    reported after ``deadline_ms`` instead of being flushed past.

    Any other off-thread primitive admitted to such a harness must be counted
    here the same way; a turn budget cannot bound it.
    """
    return (
        "const flush=(()=>{let outstanding=0;const subtle=globalThis.crypto.subtle,digest=subtle.digest;"
        "subtle.digest=function(...args){outstanding++;const settle=()=>{outstanding--};"
        "const result=digest.apply(this,args);result.then(settle,settle);return result};"
        f"return async()=>{{const deadline=Date.now()+{deadline_ms};"
        f"for(let quiet=0;quiet<{quiet_turns};){{await new Promise(setImmediate);quiet=outstanding?0:quiet+1;"
        f"if(outstanding&&Date.now()>deadline)throw Error('Harness flush: an integrity digest is still outstanding after {deadline_ms} ms.')}}}}}})();"
    )


def run_node(command: list[str], **kwargs) -> subprocess.CompletedProcess:
    """Drop-in for ``subprocess.run`` on a Node command list.

    Inline programs larger than the per-argument limit are streamed from an
    anonymous file under TMPDIR. Node's stdin mode keeps relative imports based
    on the child's working directory without creating files in the checkout.
    """
    command = list(command)
    command[0] = require_node()
    if (kwargs.get("text") or kwargs.get("universal_newlines")) and "encoding" not in kwargs:
        # Node.js writes UTF-8 whatever the locale says, and frozen callers cannot say so.
        kwargs["encoding"] = "utf-8"
    for index in range(1, len(command) - 1):
        if command[index] in _EVAL_FLAGS and len(command[index + 1].encode("utf-8")) > _SPILL_BYTES:
            if kwargs.get("stdin") is not None or kwargs.get("input") is not None:
                raise ValueError("a large Node harness uses stdin; caller stdin/input would be replaced")
            # Node 18.18+ supports --import (the hosted harness uses Node 24).
            # Remove stdin's argv marker outside the source's lexical scope:
            # prepending a statement would break strict directives and bindings.
            argv_adapter = "--import=data:text/javascript,globalThis.process.argv.splice(1%2C1)"
            source = command[index + 1].encode("utf-8")
            command = [command[0], *command[1:index], argv_adapter, "-", *command[index + 2:]]
            with tempfile.TemporaryFile("w+b") as script:
                script.write(source)
                script.seek(0)
                kwargs["stdin"] = script
                return subprocess.run(command, **kwargs)
    return subprocess.run(command, **kwargs)
