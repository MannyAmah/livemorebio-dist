"""Technical fixtures: failed diagnostic sinks must not expose active exceptions."""
from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.testclient import TestClient
import pytest


TECHNICAL_VALUE = "TECHNICAL Jane Testperson MRN-778812 HbA1c-9.4"
TECHNICAL_TOKEN = "technical-failed-logging-sink-operator"


class _TechnicalBrokenStream:
    def write(self, value: str) -> None:
        raise OSError("technical log sink unavailable")

    def flush(self) -> None:
        pass


class _TechnicalRaisingHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:
        raise OSError("technical log handler unavailable")


@pytest.mark.parametrize("sink", ["broken_stream", "raising_handler"])
@pytest.mark.parametrize("route", ["middleware", "evidence_list", "evidence_detail"])
def test_PHI_1_failed_log_sink_never_exposes_active_exception(
    monkeypatch, capsys, sink: str, route: str,
) -> None:
    from livemorebio import request_errors, security

    monkeypatch.setenv(security.TOKEN_ENV, TECHNICAL_TOKEN)
    handler = (logging.StreamHandler(_TechnicalBrokenStream()) if sink == "broken_stream"
               else _TechnicalRaisingHandler())
    monkeypatch.setattr(request_errors.logger, "handlers", [handler])
    monkeypatch.setattr(request_errors.logger, "propagate", False)
    monkeypatch.setattr(request_errors.logger, "disabled", False)
    monkeypatch.setattr(request_errors.logger, "level", logging.ERROR)

    if route == "middleware":
        app = FastAPI()
        security.install_mutation_auth(app)

        @app.get("/technical-error/{technical_record}")
        def technical_error(technical_record: str, req: Request):
            raise ValueError(TECHNICAL_VALUE)

        path = "/technical-error/technical-record"
    else:
        from livemorebio.aegle import evidence_api, server

        def fail_service():
            raise ValueError(TECHNICAL_VALUE)

        monkeypatch.setattr(evidence_api, "service", fail_service)
        app = server.app
        path = "/api/evidence" if route == "evidence_list" else "/api/evidence/technical-record"

    response = TestClient(app, raise_server_exceptions=False).get(
        path, headers={"Authorization": "Bearer " + TECHNICAL_TOKEN},
    )
    captured = capsys.readouterr()
    assert TECHNICAL_VALUE not in captured.err + captured.out + response.text
    assert response.status_code == 500
    payload = response.json()
    assert payload["code"] == "INTERNAL_ERROR"
    assert payload["error"] == "The request could not be completed."
    assert payload["request_id"] == response.headers["x-request-id"]
