"""Direct Cendos protocol transport keeps authentication, bounds and immutable recall."""
from copy import deepcopy
from fastapi.testclient import TestClient
import pytest
from livemorebio.cendos import service
from livemorebio.engines import stoichiometry
from livemorebio.tests.test_metabolic_protocol_history import result, request


@pytest.fixture
def api(tmp_path, monkeypatch):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "local-technical-test")
    monkeypatch.setenv("LIVEMORE_PROTOCOL_RUNS", str(tmp_path / "runs"))
    return TestClient(service.app)


AUTH = {"Authorization": "Bearer local-technical-test"}


def test_model_route_auth_and_duplicate_json_before_execution(api):
    assert api.post("/protocols/human-gem-oxygen-capacity", json=request()).status_code == 401
    assert api.post("/protocols/human-gem-oxygen-capacity", headers=AUTH,
                    content='{"conditions":[],"conditions":[]}').status_code == 400
    assert api.get("/protocols/history").status_code == 401


def test_model_run_history_recall_and_prepare_are_immutable(api, result):
    response = api.post("/protocols/human-gem-oxygen-capacity", headers=AUTH, json=request())
    assert response.status_code == 201
    run = response.json()
    history = api.get("/protocols/history?q=oxygen&limit=1", headers=AUTH)
    assert history.status_code == 200 and history.headers["Cache-Control"] == "no-store"
    assert history.json()["runs"][0]["run_id"] == run["run_id"]
    recalled = api.get("/protocols/" + run["run_id"], headers=AUTH).json()
    prepared = api.get("/protocols/" + run["run_id"] + "/prepare-rerun", headers=AUTH).json()
    assert recalled == run and prepared["request"] == run["input"]
    assert api.get("/protocols/latest", headers=AUTH).json() == run


def test_busy_and_invalid_constraints_surface_typed_errors(api, monkeypatch):
    def busy(spec):
        raise stoichiometry.StoichiometryError("busy", "MODEL_BUSY")
    monkeypatch.setattr(stoichiometry, "execute", busy)
    response = api.post("/protocols/human-gem-oxygen-capacity", headers=AUTH, json=request())
    assert response.status_code == 409 and response.json()["code"] == "MODEL_BUSY"
    invalid = deepcopy(request()); invalid["conditions"][0]["oxygen_uptake"] = True
    response = api.post("/protocols/human-gem-oxygen-capacity", headers=AUTH, json=invalid)
    assert response.status_code == 422 and response.json()["code"] == "INVALID_CONSTRAINTS"


@pytest.mark.parametrize("path,body", [
    ("metformin-cohorts", {"dose_mg": True}),
    ("garcinoic-pxr", {"concentrations_um": [True]}),
])
def test_direct_legacy_protocol_quantities_cannot_coerce_booleans(api, path, body):
    response = api.post("/protocols/" + path, headers=AUTH, json=body)
    assert response.status_code == 422 and "booleans" in response.json()["error"]
