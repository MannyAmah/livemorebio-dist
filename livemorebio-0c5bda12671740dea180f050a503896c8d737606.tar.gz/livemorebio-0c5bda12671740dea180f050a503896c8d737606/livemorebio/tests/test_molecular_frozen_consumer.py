"""Actual frozen-run handlers with authored UI seams, not rendered biology."""
from pathlib import Path
import json
import subprocess

import pytest
from ._node import NODE, run_node as _run_node


ROOT = Path(__file__).parents[2]
SOURCE = ROOT / "livemorebio/aegle/console/lib/run_anatomy.js"


def frozen_consumer(body: str, *, setup: str = "", immediate: str = "") -> None:
    script = r"""
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync(SOURCE,'utf8').replace(/^import .*;\n/gm,'').replaceAll('export function','function');
const decode=s=>s.replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
const nodes=new Map(),requests=[],mounts=[],explorers=[],calls=[];
class Element {
 constructor(){this.handlers={};this.dataset={};this.value='';this.disabled=false;this.textContent='';this.buttons=[];this.details=[];}
 set innerHTML(value){this.html=value;this.buttons=[];this.details=[];
  for(const match of value.matchAll(/<button\b[^>]*data-molecular-target="([^"]*)"[^>]*>/g)){
   const b=new Element();b.dataset.molecularTarget=decode(match[1]);this.buttons.push(b);}
  for(const _ of value.matchAll(/<details\b/g))this.details.push({open:false});}
 get innerHTML(){return this.html||'';}
 querySelector(selector){if(!nodes.has(selector))nodes.set(selector,new Element());return nodes.get(selector);}
 querySelectorAll(selector){if(selector==='details')return this.details;assert.equal(selector,'[data-molecular-target]');return this.buttons;}
 addEventListener(name,handler){this.handlers[name]=handler;}
 click(){return this.handlers.click?.({currentTarget:this,target:this});}
}
const host=new Element(),node=s=>host.querySelector(s);
node('[data-anatomy-section]').value='off';node('[data-anatomy-depth]').value='50';
const organ=(id,targets)=>({id,name:id,role:'Reference only',mesh:`/assets/anatomy/${id}.glb`,pos:[0,0,0],
 value:null,metric:null,unit:null,cell:{type:'Authored cell',activity:null,evidence_state:'REFERENCE_ONLY',quantities:[]},targets,pathways:[],anatomy:{}});
const reference={schema:'livemore.biology-reference.v1',evidence_state:'REFERENCE_ONLY',reference_geometry:true,
 organs:[organ('liver',['NR1I2','AMPK','UNKNOWN_TARGET']),organ('heart',['KRAS'])]};
const inspection={schema:'livemore.protocol-inspection.v1',binding:{run_id:'protocol-'+'a'.repeat(32),
 protocol_id:'cendos.garcinoic-acid-pxr.v1',member_id:'authored-member-a',cohort_id:'authored-cohort',condition_id:'concentration:1uM'},
 source_class:'MODELED',freshness:'FROZEN_RECORD',evidence_state:'STRUCTURE_AND_IN_VITRO_BACKED_MODEL',qualification_state:'NOT_QUALIFIED',
 stage:{id:'response'},axis:{kind:'recorded_condition',unit:'uM',value:1,index:0,count:2},
 quantity:{id:'relative_pxr_activation',label:'PXR activation',unit:'a.u.',value:.2},
 provenance:{structure:{pdb_id:'6P2B'},binding_parameters:{target:'NR1I2'}}};
let fail=null,blockedOpen=null;
const mountMolecularInspector=(host,options)=>{
 if(fail==='mount')throw Error('PRIVATE authored error');
 const record={host,context:structuredClone(options.context),opens:[],openingContexts:[],contexts:[],closes:0,disposals:0};mounts.push(record);
 return {open(...args){record.opens.push(args);record.openingContexts.push(record.context.key);if(blockedOpen)return blockedOpen.promise;
   if(fail==='open')return Promise.reject(Error('PRIVATE authored error'));return Promise.resolve();},
  setContext(next){record.context=structuredClone(next);record.contexts.push(structuredClone(next));
   if(fail==='context')return Promise.reject(Error('PRIVATE authored error'));return Promise.resolve();},
  close(){record.closes++;if(fail==='close')return Promise.reject(Error('PRIVATE authored error'));return Promise.resolve();},
  dispose(){record.disposals++;if(fail==='dispose')return Promise.reject(Error('PRIVATE authored error'));return Promise.resolve();}};
};
const createAnatomyExplorer=options=>{const e={options,setContext:key=>{calls.push(['context',key]);return false;},
 setOrgans:rows=>calls.push(['organs',rows.length]),isolate:id=>calls.push(['isolate',id]),clearIsolation:()=>calls.push(['all']),
 setClip:(...args)=>calls.push(['clip',...args]),clearClip:()=>calls.push(['clip-off']),
 dispose:()=>{calls.push(['dispose-geometry']);if(fail==='geometry')throw Error('PRIVATE geometry failure');}};explorers.push(e);return e;};
const context={mountMolecularInspector,AbortController,structuredClone,console,Promise,
 loadAnatomyDependencies:async()=>({THREE:{},GLTFLoader(){},OrbitControls(){},createAnatomyExplorer}),
 restoreAnatomyView:()=>{},setTimeout:()=>1,clearTimeout(){},
 fetch:async(url,options)=>{requests.push(url);assert.equal(url,'/api/biology/reference');assert.equal(options.cache,'no-store');return{ok:true,json:async()=>reference};}};
vm.createContext(context);vm.runInContext(source,context);
const tick=async()=>{for(let i=0;i<20;i++)await Promise.resolve();};
const buttons=()=>node('[data-anatomy-detail]').buttons;
const feedback=()=>node('[data-molecular-feedback]').textContent;
const change=(edit)=>{const next=structuredClone(inspection);edit(next);view.setInspection(next);return next;};
const original=JSON.stringify(inspection);
SETUP
let completed=false;process.on('beforeExit',()=>{if(!completed)process.exitCode=1;});
(async()=>{
const view=context.mountRunAnatomy(host,inspection);global.view=view;IMMEDIATE
await tick();
BODY
await view.dispose();await tick();completed=true;
})().catch(error=>{console.error(error.name,error.message);process.exitCode=1;});
""".replace("SOURCE", json.dumps(str(SOURCE))).replace("SETUP", setup).replace("IMMEDIATE", immediate).replace("BODY", body)
    result = _run_node([NODE, "--eval", script],
                            cwd=ROOT, capture_output=True, text=True, timeout=10, encoding="utf-8")
    assert result.returncode == 0, result.stdout + result.stderr


def test_lazy_exact_targets_and_recorded_pdb_without_experiment_request():
    frozen_consumer("""
assert.equal(mounts.length,0);assert.equal(buttons().length,3);
for(const b of buttons()){b.click();await tick();}
assert.equal(mounts.length,1);assert.deepEqual(mounts[0].opens,[['NR1I2','6P2B'],['AMPK',null],['UNKNOWN_TARGET',null]]);
assert.equal(mounts[0].context.kind,'run');assert.equal(mounts[0].context.mode,'FROZEN_REFERENCE');
const key=JSON.parse(mounts[0].context.key);assert(key.includes('authored-member-a'));assert(key.includes('response'));assert(key.includes('6P2B'));
assert.equal(JSON.stringify(inspection),original);assert.deepEqual(requests,['/api/biology/reference']);
assert(host.innerHTML.indexOf('data-molecular-inspector')>host.innerHTML.indexOf('data-anatomy-source'));
""")


def test_pxr_structure_control_opens_frozen_pdb_with_the_real_anatomy_catalog():
    from livemorebio.engines.biology import biology_reference

    reference = biology_reference()
    assert all("NR1I2" not in organ["targets"] for organ in reference["organs"])
    frozen_consumer("""
assert(!buttons().some(button=>button.dataset.molecularTarget==='NR1I2'));
assert.equal(mounts.length,0);
await view.openFrozenStructure();await tick();
assert.equal(mounts.length,1);
assert.deepEqual(mounts[0].opens,[['NR1I2','6P2B']]);
assert(JSON.parse(mounts[0].context.key).includes('structure'));
change(next=>{next.stage.id='response';});
await view.openFrozenStructure();await tick();
assert.equal(mounts[0].opens.length,1);
await view.dispose();await view.openFrozenStructure();await tick();
assert.equal(mounts[0].opens.length,1);
assert.deepEqual(requests,['/api/biology/reference']);
""", setup="Object.assign(reference," + json.dumps(reference) + ");inspection.stage.id='structure';")


@pytest.mark.parametrize("pdb", [None, "", "1ABC/secret"])
def test_pxr_structure_control_preserves_frozen_identity_refusal(pdb):
    from livemorebio.engines.biology import biology_reference

    frozen_consumer("""
await view.openFrozenStructure();await tick();
assert.equal(mounts.length,0);assert(feedback().includes('recorded structure'));
""", setup="Object.assign(reference," + json.dumps(biology_reference()) + ");"
        + "inspection.stage.id='structure';inspection.provenance.structure.pdb_id=" + json.dumps(pdb) + ";")


@pytest.mark.parametrize("pdb", [None, "", "1ABC/secret"])
def test_missing_or_malformed_frozen_pdb_never_removes_identity_check(pdb):
    frozen_consumer("""
buttons()[0].click();await tick();assert.equal(mounts.length,0);
assert(feedback().includes('recorded structure'));assert(!feedback().includes('PRIVATE'));
""", setup=f"inspection.provenance.structure.pdb_id={json.dumps(pdb)};")


def test_initial_and_subsequent_inputs_are_detached_before_async_reads():
    frozen_consumer("""
inspection.binding.member_id='caller-mutated';inspection.provenance.structure.pdb_id='1ABC';
buttons()[0].click();await tick();assert.equal(mounts[0].opens[0][1],'6P2B');
assert(JSON.parse(mounts[0].context.key).includes('authored-member-a'));
const next=JSON.parse(original);next.binding.member_id='authored-member-b';view.setInspection(next);
next.binding.member_id='caller-mutated-b';next.provenance.structure.pdb_id='1XYZ';
buttons()[0].click();await tick();assert.equal(mounts[0].opens.at(-1)[1],'6P2B');
assert(JSON.parse(mounts[0].context.key).includes('authored-member-b'));
""")


def test_pending_initial_reference_cannot_adopt_a_later_caller_mutation():
    frozen_consumer("""
buttons()[0].click();await tick();assert.equal(mounts[0].opens[0][1],'6P2B');
assert(JSON.parse(mounts[0].context.key).includes('authored-member-a'));
""", immediate="inspection.binding.member_id='caller-mutated';inspection.provenance.structure.pdb_id='1ABC';")


def test_non_pxr_history_does_not_invent_frozen_structure_identity():
    frozen_consumer("""
buttons()[0].click();await tick();assert.deepEqual(mounts[0].opens,[['NR1I2',null]]);
""", setup="""
inspection.binding.protocol_id='cendos.metformin-cohort-comparison.v1';inspection.binding.condition_id=null;
inspection.evidence_state='MODELED_MECHANISTIC';inspection.axis={kind:'recorded_time',unit:'min',value:0,index:0};
inspection.quantity={id:'glucose',unit:'mg/dL',baseline:100,treated:100};inspection.provenance.structure=null;
""")


@pytest.mark.parametrize("edit", [
    "next.binding.member_id='authored-member-b'", "next.stage.id='structure'",
    "next.axis.value=2;next.axis.index=1", "next.binding.condition_id='concentration:2uM'",
])
def test_selection_change_retires_previous_context_and_old_button(edit):
    frozen_consumer("""
const old=buttons()[0];old.click();await tick();const first=mounts[0].context.key;
const next=structuredClone(inspection);
""" + edit + ";view.setInspection(next);await tick();" + """
assert.equal(mounts[0].contexts.length,1);assert.notEqual(mounts[0].context.key,first);
old.click();await tick();assert.equal(mounts[0].opens.length,1);
buttons()[0].click();await tick();assert.equal(mounts[0].opens.length,2);
""")


@pytest.mark.parametrize("via", ["select", "geometry"])
def test_organ_selection_closes_previous_molecule(via):
    change = ("node('[data-anatomy-organ]').handlers.change({target:{value:'heart'}});"
              if via == "select" else "explorers[0].options.onSelect(reference.organs[1]);")
    frozen_consumer("const old=buttons()[0];old.click();await tick();" + change + """
await tick();assert.equal(mounts[0].closes,1);old.click();await tick();assert.equal(mounts[0].opens.length,1);
buttons()[0].click();await tick();assert.deepEqual(mounts[0].opens.at(-1),['KRAS',null]);
""")


def test_same_selection_retry_preserves_inspector_and_anatomy_controls():
    frozen_consumer("""
buttons()[0].click();await tick();await node('[data-anatomy-retry]').click();await tick();
view.setInspection(structuredClone(inspection));await tick();
assert.equal(mounts[0].contexts.length,0);assert.equal(mounts[0].closes,0);
node('[data-anatomy-section]').value='x';node('[data-anatomy-section]').handlers.change();
node('[data-anatomy-depth]').value='75';node('[data-anatomy-depth]').handlers.input();node('[data-anatomy-home]').click();
assert(calls.some(row=>JSON.stringify(row)==='["clip","x",0.75]'));assert(calls.some(row=>row[0]==='all'));
assert.equal(requests.length,1);assert.equal(JSON.stringify(inspection),original);
""")


def test_invalid_replacement_retires_and_cannot_reopen_previous_member():
    frozen_consumer("""
const old=buttons()[0];old.click();await tick();const next=structuredClone(inspection);next.binding.member_id=null;
assert.throws(()=>view.setInspection(next));await tick();assert.equal(mounts[0].closes,1);
old.click();await tick();assert.equal(mounts[0].opens.length,1);
""")


@pytest.mark.parametrize("failure", ["mount", "open"])
def test_open_errors_are_fixed_visible_feedback(failure):
    frozen_consumer(f"fail={json.dumps(failure)};" + "buttons()[0].click();await tick();assert(feedback().includes('unavailable'));assert(!feedback().includes('PRIVATE'));")


def test_old_open_rejection_cannot_overwrite_new_selection_feedback():
    frozen_consumer("""
let reject;blockedOpen={promise:new Promise((_,r)=>{reject=r;})};buttons()[0].click();await tick();
const next=structuredClone(inspection);next.binding.member_id='authored-member-b';view.setInspection(next);await tick();
blockedOpen=null;buttons()[0].click();await tick();const current=feedback();reject(Error('PRIVATE'));await tick();assert.equal(feedback(),current);
""")


def test_new_selection_is_bound_before_immediate_target_click():
    frozen_consumer("""
buttons()[0].click();await tick();const next=structuredClone(inspection);next.binding.member_id='authored-member-b';
view.setInspection(next);buttons()[0].click();await tick();
assert(JSON.parse(mounts[0].openingContexts.at(-1)).includes('authored-member-b'));
""")


@pytest.mark.parametrize("failure", ["close", "context"])
def test_retirement_failure_reports_fixed_unconfirmed_feedback(failure):
    action = ("node('[data-anatomy-organ]').handlers.change({target:{value:'heart'}});"
              if failure == "close" else "const next=structuredClone(inspection);next.stage.id='structure';view.setInspection(next);")
    frozen_consumer("buttons()[0].click();await tick();" + f"fail={json.dumps(failure)};" + action + """
await tick();assert(feedback().includes('cleanup is unconfirmed'));assert(!feedback().includes('PRIVATE'));
""")


@pytest.mark.parametrize("failure", ["dispose", "geometry"])
def test_cleanup_is_once_only_observed_even_when_geometry_fails(failure):
    frozen_consumer("const old=buttons()[0];old.click();await tick();" + f"fail={json.dumps(failure)};" + """
await view.dispose();await view.dispose();old.click();await tick();assert.equal(mounts[0].disposals,1);assert.equal(mounts[0].opens.length,1);
assert.equal(host.dataset[fail==='geometry'?'anatomyCleanup':'molecularCleanup'],'unconfirmed');
""")
