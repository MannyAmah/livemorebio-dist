"""Mounted production controller with native-like select state, no browser/I/O."""
from .test_atlas_reference_ui import node
from .test_atlas_view_status import controller


def check(code):
    setup = """
const list=host.querySelector('[data-results]');let index=-1;
Object.defineProperties(list,{selectedIndex:{get:()=>index,set:v=>{index=v}},value:{get:()=>list.children[index]?.value||'',set:v=>{index=list.children.findIndex(o=>o.value===v)}}});
const query=value=>{host.querySelector('[data-search]').value=value;host.querySelector('[data-search]').handlers.input()};
const choose=id=>{list.value=id;list.handlers.change()};
const id=manifest.assets.find(a=>a.asset_key==='pancreas').audit.element_ids[0];
"""
    assert node(controller(setup + code)).strip() == "ok"


def test_return_clears_only_selection_and_allows_same_option_reselection():
    check("""
query(id);choose(id);click('[data-isolate]');const options=[...list.options];click('[data-clear]');
if(scene.view().selected!==null||list.value!==''||list.selectedIndex!==-1)throw Error('Return retained list selection');
if(host.querySelector('[data-search]').value!==id||list.options[0]!==options[0])throw Error('Return erased search');
if(!host.querySelector('[data-frame]').disabled||!host.querySelector('[data-isolate]').disabled)throw Error('selection action retained');
if(!host.querySelector('[data-selection]').textContent.startsWith('Select a source'))throw Error('source article stale');
choose(id);if(scene.view().selected!==id||host.querySelector('[data-frame]').disabled)throw Error('same option cannot reselect');
""")


def test_canvas_exact_match_search_refresh_and_home_share_reconciliation():
    check("""
query(id);scene.select(id);if(list.value!==id)throw Error('scene selection not reflected');
query('FJ');if(list.options.some(o=>o.value===id)&&list.value!==id)throw Error('query rebuild lost exact match');
query('no-such-source');if(list.value!=='')throw Error('unrelated option selected');
query(id);if(list.value!==id)throw Error('matching filter did not reconcile');
click('[data-retry]');await flush();if(list.value!==id)throw Error('same source refresh lost matching selection');
for(const direction of ['front','side','back']){scene.select(id);host.querySelector('[data-view="'+direction+'"]').handlers.click();if(list.value!==''||scene.view().selected!==null)throw Error('direction home failed to clear');}
scene.select(id);mounted.home();if(list.value!=='')throw Error('header Home differs');
""")


def test_complete_accessible_names_remain_when_callouts_are_suppressed():
    check("""
const names=host.querySelector('[data-callout-list]');
if(names.children.length!==9)throw Error('complete accessible group list missing');
config.onLabels({state:'ready',placed:['skin'],omitted:manifest.assets.filter(a=>a.asset_key!=='skin').map(a=>({key:a.asset_key,reason:'space'}))});
if(!host.querySelector('[data-callout-status]').textContent.includes('8 omitted'))throw Error('omitted count absent');
for(const a of manifest.assets)if(!names.children.some(n=>n.textContent.includes(a.asset_key.replaceAll('-',' '))))throw Error('source name missing');
config.onLabels({state:'section',placed:[],omitted:manifest.assets.map(a=>({key:a.asset_key,reason:'section'}))});
if(!host.querySelector('[data-callout-status]').textContent.includes('section')||names.children.length!==9)throw Error('section suppression unexplained');
const old=config;click('[data-retry]');await flush();const currentText=host.querySelector('[data-callout-status]').textContent;
old.onLabels({state:'ready',placed:['skin'],omitted:[]});if(host.querySelector('[data-callout-status]').textContent!==currentText)throw Error('old scene published label report');
""")


def test_changed_manifest_clears_selection_and_old_source_article():
    check("""
query(id);choose(id);if(!host.querySelector('[data-selection]').textContent.includes(id))throw Error('fixture selection missing');
current={...available,manifest_sha256:'c'.repeat(64)};click('[data-retry]');await flush();
if(list.value!==''||scene.view().selected!==null)throw Error('changed source retained selection');
if(!host.querySelector('[data-selection]').textContent.startsWith('Select a source'))throw Error('changed source retained old source article');
""")
