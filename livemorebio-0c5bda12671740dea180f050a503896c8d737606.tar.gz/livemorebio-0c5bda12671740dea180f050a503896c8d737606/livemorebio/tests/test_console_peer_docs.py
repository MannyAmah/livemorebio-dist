"""Source-tree guards for the operator's console session instructions."""
from pathlib import Path
import re

import pytest

from livemorebio import security
from livemorebio.tests._source_tree import source_tree_only


pytestmark = source_tree_only("docs/LAUNCH_GUIDE.md")
GUIDE = Path(__file__).resolve().parents[2] / "docs" / "LAUNCH_GUIDE.md"
README = GUIDE.parent.parent / "README.md"


def test_page_walk_obtains_a_console_session_on_every_launch_path():
    guide = GUIDE.read_text(encoding="utf-8")
    atlas = guide.split("### Executable multiscale Atlas", 1)[1].split("### Digital twins", 1)[0]
    assert "authorization is automatic" not in guide
    assert "livemore open" in atlas
    assert "docker compose exec aegle livemore open --print-url" in atlas
    assert "LOCAL · AUTHENTICATED" not in atlas
    assert "401" in atlas
    assert "clean connection page" in atlas
    assert "separate code" in atlas


@pytest.mark.parametrize("path", (README, GUIDE), ids=("readme", "launch-guide"))
def test_manual_console_recipe_keeps_the_code_out_of_urls_and_shells(path):
    text = " ".join(path.read_text(encoding="utf-8").split())
    assert "/console/connect" in text
    assert "three lines" in text
    assert "One-time code:" in text
    assert "separate one-time code" in text
    assert "submitted by POST" in text
    assert "Never put the code in a command argument, environment variable, URL query or fragment, or shell substitution" in text
    assert "enter the code" in text
    assert "printed link" not in text
    assert "live code in a link" not in text


def test_retired_links_and_manual_attempt_budget_have_code_free_recovery():
    guide = " ".join(GUIDE.read_text(encoding="utf-8").split())
    assert "CONSOLE_EXCHANGE_GET_RETIRED" in guide
    assert "old one-time links no longer authorize a session" in guide
    assert "Do not reuse the old link or move its code into another URL" in guide
    assert "CONSOLE_CODE_ATTEMPTS_EXCEEDED" in guide
    assert "20 submissions per sliding minute" in guide
    assert "process-wide" in guide
    assert "another local process can exhaust the budget" in guide
    assert "ordinary private-file and recorder codes" in guide


def _assert_startup_refusal_guidance(guide: str) -> None:
    troubleshooting = guide.split("## 10. Troubleshooting", 1)[1]
    startup = troubleshooting.split("`CONSOLE_PEER_UNRESOLVED`", 1)[1].split(
        "`503 mutation API disabled`", 1)[0]
    normalized = " ".join(startup.split())
    assert "`livemore logs aegle` on the host" in normalized
    assert "Aegle refuses to start" in normalized
    assert "`Aegle is not running` after `livemore up`" in normalized
    assert "this refusal or another startup failure" in normalized
    assert "Use supported Docker bridge networking" in normalized
    assert "`livemore down` before switching to native `livemore start all`" in normalized
    assert "Do not run `livemore start Aegle` while LIFE and Cendos are running in containers" in normalized
    assert "docker compose logs" not in normalized


def test_startup_refusal_guidance_connects_open_to_compose_logs():
    _assert_startup_refusal_guidance(GUIDE.read_text(encoding="utf-8"))


def test_startup_guidance_rejects_fix_pass_2_instructions():
    # These old instructions name an unusable command in a fresh operator shell.
    previous = """## 10. Troubleshooting
`CONSOLE_PEER_UNRESOLVED` in `docker compose logs aegle`: the opt-in could not resolve
one RFC 1918 IPv4 default gateway in Docker; Aegle refuses to start.
If `livemore open` reports `Aegle is not running` after `livemore up`, check
`docker compose logs aegle` for this refusal or another startup failure. Fix the
networking, or run `livemore down` before switching to native `livemore start all`.
Do not run `livemore start Aegle` while LIFE and Cendos are running in containers.

`503 mutation API disabled`
"""
    with pytest.raises(AssertionError, match="livemore logs aegle"):
        _assert_startup_refusal_guidance(previous)


def test_peer_refusal_distinguishes_missing_opt_in_from_unsupported_networking():
    guide = GUIDE.read_text(encoding="utf-8")
    refusal = guide.split("`refused [CONSOLE_PEER_REFUSED]`", 1)[1].split("`CONSOLE_PEER_UNRESOLVED`", 1)[0]
    assert "LIVEMORE_CONSOLE_PEER" in refusal and "livemore up" in refusal
    assert "bridge gateway" in refusal
    assert "WSL2" in refusal and "Linux proxy" in refusal
    assert "rebuild does not" in refusal


def test_documented_link_lifetime_matches_session_code_ttl():
    guide = GUIDE.read_text(encoding="utf-8")
    readme = README.read_text(encoding="utf-8")
    numbers = {
        "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
        "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
        "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
        "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18,
        "nineteen": 19, "twenty": 20, "thirty": 30, "forty": 40,
        "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90,
    }
    words = "|".join((*numbers, "hundred"))
    duration = re.compile(
        rf"\b(?P<number>\d+|(?:{words})(?:[ -]+(?:{words}))*)\s+"
        r"(?P<unit>seconds?|minutes?)\b", re.IGNORECASE)

    # Scan both entire documents so a new literal cannot escape a section-local guard.
    claims = list(duration.finditer(readme)) + list(duration.finditer(guide))
    assert claims, "keep the Docker example's concrete expiry bound covered"
    for claim in claims:
        amount = claim["number"].lower()
        if amount.isdigit():
            value = int(amount)
        else:
            value = 0
            for word in re.split(r"[ -]+", amount):
                value = value * 100 if word == "hundred" else value + numbers[word]
        seconds = value * (60 if claim["unit"].lower().startswith("minute") else 1)
        assert seconds == security.SESSION_CODE_TTL, claim.group()

    # Repeated introductory/page-walk numbers add drift risk without aiding the operator.
    start = guide.split("## 2. Start the product", 1)[1].split("## 3.", 1)[0]
    atlas = guide.split("### Executable multiscale Atlas, `/`", 1)[1].split("\n### ", 1)[0]
    for section in (readme, start, atlas):
        assert duration.search(section) is None
        assert "the command prints its lifetime" in section
    docker = guide.split("## 8. Docker mode", 1)[1].split("## 9.", 1)[0]
    assert len(list(duration.finditer(docker))) == 1


def test_the_page_walk_names_no_link_lifetime_of_its_own():
    guide = GUIDE.read_text(encoding="utf-8")
    atlas = guide.split("### Executable multiscale Atlas, `/`", 1)[1].split("\n### ", 1)[0]
    assert re.search(r"\b\d+\s+seconds\b", atlas) is None
    assert "prints its lifetime" in atlas


def test_compose_logs_command_is_in_readme_and_container_instructions():
    readme = README.read_text(encoding="utf-8")
    commands = readme.split("After installation:", 1)[1].split("```", 2)[1]
    guide = GUIDE.read_text(encoding="utf-8")
    docker = guide.split("## 8. Docker mode", 1)[1].split("## 9.", 1)[0]
    assert re.search(r"^livemore logs(?:\s|$)", commands, re.MULTILINE)
    assert re.search(r"^livemore logs aegle(?:\s|$)", docker, re.MULTILINE)
    assert "No credential files are read by `livemore down` or `livemore logs`" in docker
