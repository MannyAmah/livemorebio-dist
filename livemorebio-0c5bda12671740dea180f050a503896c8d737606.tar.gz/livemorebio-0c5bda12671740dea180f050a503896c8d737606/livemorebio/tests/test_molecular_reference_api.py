"""In-process reference delivery, never a participant or numerical experiment."""
from __future__ import annotations

import hashlib

from fastapi.testclient import TestClient
import pytest

AUTH = {"Authorization": "Bearer authored-molecular-api-test"}
DIGEST = "bc5738721380320d37c216a8f4412ddd3f66fad375c60fc0d0626bc6c277e5d7"
ASSET = f"/api/molecular/structures/{DIGEST}/coordinates"


@pytest.fixture
def boundary(monkeypatch):
    from livemorebio import audit, molecular_reference
    from livemorebio.aegle import server

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "authored-molecular-api-test")
    monkeypatch.setattr(server, "_ensure_selected_state", lambda: pytest.fail("Reference read selected a twin"))
    monkeypatch.setattr(server, "AegleTwin", lambda *a, **k: pytest.fail("Reference read constructed biology"))
    calls, events = [], []
    original_lookup, original_read = molecular_reference.lookup, molecular_reference.read_coordinates
    monkeypatch.setattr(molecular_reference, "lookup", lambda key: calls.append(("metadata", key)) or original_lookup(key))
    monkeypatch.setattr(molecular_reference, "read_coordinates", lambda key: calls.append(("coordinates", key)) or original_read(key))
    monkeypatch.setattr(audit, "record", lambda *a, **kw: events.append((a, kw)) or {})
    return TestClient(server.app, raise_server_exceptions=False), calls, events


@pytest.mark.parametrize("path", ["/api/structure?gene=KRAS", ASSET])
def test_auth_first_before_reference_and_audit_io(boundary, path):
    client, calls, events = boundary
    response = client.get(path)
    assert response.status_code == 401
    assert calls == [] and events == []
    assert "no-store" in response.headers["cache-control"]


@pytest.mark.parametrize("path", ["/api/structure?gene=KRAS", ASSET])
def test_cross_origin_cookie_cannot_read_reference(boundary, path):
    from livemorebio.aegle.server import app
    from livemorebio.security import session_cookie_name
    client, calls, events = boundary
    client.cookies.set(session_cookie_name(80), app.state.console_session_secret)
    same_origin = client.get(path, headers={"Origin": "http://testserver", "Sec-Fetch-Site": "same-origin"})
    assert same_origin.status_code == 200 and len(calls) == len(events) == 1
    calls.clear()
    events.clear()
    response = client.get(path, headers={"Origin": "https://unapproved.invalid", "Sec-Fetch-Site": "cross-site"})
    assert response.status_code == 403 and calls == [] and events == []


@pytest.mark.parametrize("path,content", [
    ("/api/structure", None), ("/api/structure?gene=KRAS&gene=TP53", None),
    ("/api/structure?gene=KRAS&secret=PRIVATE", None), ("/api/structure?gene=" + "a" * 300, None),
    ("/api/structure?gene=KRAS", b"PRIVATE"), (ASSET + "?private=PRIVATE", None), (ASSET, b"PRIVATE"),
])
def test_invalid_shape_never_reads_source_or_echoes_input(boundary, path, content):
    client, calls, events = boundary
    response = client.request("GET", path, headers=AUTH, content=content)
    assert response.status_code == 422 and calls == []
    assert response.json()["code"] == "MOLECULAR_INVALID_REQUEST"
    assert "PRIVATE" not in response.text and "PRIVATE" not in repr(events)


@pytest.mark.parametrize("path", ["/api/structure?gene=KRAS", ASSET])
def test_success_is_same_source_reference_only_and_audited_before_delivery(boundary, path):
    from livemorebio.build_info import build_identity
    client, calls, events = boundary
    response = client.get(path, headers=AUTH)
    assert response.status_code == 200 and len(calls) == len(events) == 1
    assert response.headers["X-Livemore-Source-Sha256"] == build_identity()["source_sha256"]
    assert response.headers["X-Livemore-Process-Instance"] == build_identity()["process_instance"]
    assert "no-store" in response.headers["cache-control"]
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    if path == ASSET:
        assert len(response.content) == 888328
        assert hashlib.sha256(response.content).hexdigest() == DIGEST
        assert response.headers["X-Content-SHA256"] == DIGEST
        assert response.headers["content-type"].startswith("chemical/x-cif")
    else:
        data = response.json()
        assert data["pdb"] == "4OBE" and data["uniprot"] == "P01116"
        assert data["reference"]["evidence_state"] == "REFERENCE_ONLY"
        assert data["resolution"] == 1.24 and data["method"] == "X-RAY DIFFRACTION"
    args, options = events[0]
    assert args[0] == "molecular.reference.read"
    assert args[1] == {"operation": "coordinates" if path == ASSET else "metadata", "asset_id": "4OBE"}
    assert args[2] == {"outcome": "REFERENCE_AVAILABLE"}
    assert options["strict"] is True and options["prov"]["source_sha256"] == build_identity()["source_sha256"]


@pytest.mark.parametrize("target,status", [("INS", "MAPPING_UNAVAILABLE"), ("AMPK", "AMBIGUOUS_TARGET"), ("UNMAPPED", "MAPPING_UNAVAILABLE")])
def test_unavailable_identity_is_not_substituted(boundary, target, status):
    response = boundary[0].get("/api/structure?gene=" + target, headers=AUTH)
    assert response.status_code == 200
    assert response.json()["status"] == status and response.json()["pdb"] is None


@pytest.mark.parametrize("digest", ["a" * 64, "A" * 64, "invalid"])
def test_unknown_coordinates_are_fixed_404_not_discovery(boundary, digest):
    response = boundary[0].get(f"/api/molecular/structures/{digest}/coordinates", headers=AUTH)
    assert response.status_code == 404
    assert response.json()["code"] == "MOLECULAR_NOT_FOUND"
    assert digest not in response.text


@pytest.mark.parametrize("path", ["/api/structure?gene=KRAS", ASSET])
def test_audit_failure_releases_no_reference_bytes_and_is_not_retried(boundary, monkeypatch, path):
    from livemorebio import audit
    client, calls, events = boundary
    def fail(*a, **k):
        events.append("attempt")
        raise OSError("PRIVATE path or credential")
    monkeypatch.setattr(audit, "record", fail)
    response = client.get(path, headers=AUTH)
    assert response.status_code == 503 and events == ["attempt"]
    assert response.json()["code"] == "MOLECULAR_AUDIT_UNAVAILABLE"
    assert "PRIVATE" not in response.text and "data_4OBE" not in response.text


@pytest.mark.parametrize("expected", [True, False])
def test_reader_failure_is_safe_audited_and_never_falls_back(boundary, monkeypatch, expected):
    from livemorebio import molecular_reference as source
    client, calls, events = boundary
    def fail(*a):
        if expected:
            raise source.MolecularReferenceError("MOLECULAR_SOURCE_UNAVAILABLE")
        raise OSError("PRIVATE source path")
    monkeypatch.setattr(source, "lookup", fail)
    response = client.get("/api/structure?gene=KRAS", headers=AUTH)
    assert response.status_code == 503 and len(events) == 1
    assert response.json()["code"] == "MOLECULAR_SOURCE_UNAVAILABLE"
    assert "PRIVATE" not in response.text and "PRIVATE" not in repr(events)


@pytest.mark.parametrize("method", ["POST", "PUT", "DELETE", "HEAD"])
def test_wrong_methods_do_not_read_or_sign(boundary, method):
    client, calls, events = boundary
    response = client.request(method, ASSET, headers=AUTH)
    assert response.status_code == 405 and calls == [] and events == []


def test_reference_request_never_changes_selected_state(boundary):
    from livemorebio.aegle import server
    state, actions, generation = server._state, server._workspace_actions, server._model_source_authority.generation
    response = boundary[0].get("/api/structure?gene=KRAS", headers=AUTH)
    assert response.status_code == 200
    assert server._state is state and server._workspace_actions is actions
    assert server._model_source_authority.generation == generation


def test_body_wait_is_bounded_without_reading_coordinates(boundary, monkeypatch):
    from livemorebio.aegle import server
    async def timeout(coro, timeout):
        assert timeout == 1
        coro.close()
        raise TimeoutError()
    monkeypatch.setattr(server.asyncio, "wait_for", timeout)
    client, calls, events = boundary
    response = client.get(ASSET, headers=AUTH)
    assert response.status_code == 422 and calls == [] and len(events) == 1


@pytest.mark.parametrize("path,operation", [("/api/structure?gene=KRAS", "lookup"), (ASSET, "read_coordinates")])
def test_source_timeout_is_unavailable_not_invalid_request(boundary, monkeypatch, path, operation):
    from livemorebio import molecular_reference as source
    def fail(*args):
        raise TimeoutError("PRIVATE source path")
    monkeypatch.setattr(source, operation, fail)
    client, calls, events = boundary
    response = client.get(path, headers=AUTH)
    assert response.status_code == 503
    assert response.json()["code"] == "MOLECULAR_SOURCE_UNAVAILABLE"
    assert len(events) == 1 and events[0][0][2] == {"outcome": "MOLECULAR_SOURCE_UNAVAILABLE"}
    assert "PRIVATE" not in response.text and "PRIVATE" not in repr(events)


@pytest.mark.parametrize("path", ["/api/structure?gene=kras", "/api/structure?gene=%3Cscript%3E"])
def test_invalid_target_is_never_reflected(boundary, path):
    response = boundary[0].get(path, headers=AUTH)
    assert response.status_code == 422
    assert response.json()["code"] == "MOLECULAR_INVALID_TARGET"
    assert "kras" not in response.text and "script" not in response.text


def test_lost_build_hash_is_not_fabricated(boundary, monkeypatch):
    from livemorebio import build_info
    identity = {**build_info.build_identity(), "source_sha256": None}
    monkeypatch.setattr(build_info, "build_identity", lambda: dict(identity))
    response = boundary[0].get(ASSET, headers=AUTH)
    assert response.status_code == 200
    assert "X-Livemore-Source-Sha256" not in response.headers
    assert response.headers["X-Livemore-Process-Instance"] == identity["process_instance"]
