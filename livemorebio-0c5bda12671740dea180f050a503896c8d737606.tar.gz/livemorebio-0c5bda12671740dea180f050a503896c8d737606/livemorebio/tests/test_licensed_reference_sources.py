"""Reference-source regression fixtures contain invented test records only."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json

import pytest


def _fixture(source: str = "malacards") -> tuple[dict, list[dict]]:
    records = [{
        "id": "test_disease" if source == "malacards" else ("H" + "99999"),
        "name": "TEST RECORD: not a biological disease",
        "description": "Artificial parser fixture; no scientific claims.",
        "genes": ["TEST_GENE"], "pathways": [], "identifiers": {},
        "citations": ["https://example.invalid/test-fixture"],
    }]
    raw = json.dumps(records, sort_keys=True, separators=(",", ":"), allow_nan=False)
    manifest = {
        "schema": "livemore.licensed-reference-manifest.v1",
        "record_schema": "livemore.disease-reference.v1",
        "source": source, "release": "test-release-1",
        "normalization_version": "test-parser-v1",
        "upstream_sha256": hashlib.sha256(b"TEST FIXTURE ONLY").hexdigest(),
        "acquired_at": "2000-01-01T00:00:00Z",
        "expires_at": "2099-01-01T00:00:00Z",
        "license_id": "TEST-ONLY-NO-VENDOR-ENTITLEMENT",
        "approval_reference": "TEST-APPROVAL",
        "permissions": {"internal_research": True, "reference_lookup": True,
                        "model_training": False, "redistribution": False},
        "record_count": 1,
        "records_sha256": hashlib.sha256(raw.encode()).hexdigest(),
    }
    return manifest, records


def test_import_is_local_hashed_and_reference_only(tmp_path, monkeypatch):
    from livemorebio.life_system.reference.sources.licensed_import import LicensedReferenceStore
    monkeypatch.setattr("urllib.request.urlopen", lambda *a, **k: pytest.fail("network called"))
    store = LicensedReferenceStore(tmp_path / "references")
    manifest, records = _fixture()
    imported = store.import_records(manifest, records)
    context = store.disease_context("malacards", "test_disease")
    assert imported["status"] == "imported"
    assert context["status"] == "available"
    assert context["record"]["name"].startswith("TEST RECORD")
    assert context["evidence_class"] == "reference"
    assert context["physiology_effect"] == "none"
    assert context["source"]["records_sha256"] == manifest["records_sha256"]
    assert manifest["license_id"] not in repr(context)
    assert all(p.stat().st_mode & 0o077 == 0 for p in (tmp_path / "references").iterdir())
    assert not store.source_status("malacards")["permissions"]["model_training"]


@pytest.mark.parametrize("change", ["permission", "hash", "schema", "expiry", "future_acquisition", "duplicate", "nonfinite"])
def test_import_rejects_invalid_release_without_publishing(tmp_path, change):
    from livemorebio.life_system.reference.sources.licensed_import import LicensedReferenceStore
    store = LicensedReferenceStore(tmp_path)
    manifest, records = _fixture()
    if change == "permission":
        manifest["permissions"]["reference_lookup"] = False
    elif change == "hash":
        records[0]["name"] = "tampered"
    elif change == "schema":
        manifest["record_schema"] = "unknown"
    elif change == "expiry":
        manifest["expires_at"] = "2000-01-01T00:00:00Z"
    elif change == "future_acquisition":
        manifest["acquired_at"] = "2098-01-01T00:00:00Z"
    elif change == "duplicate":
        records.append(deepcopy(records[0]))
    else:
        records[0]["identifiers"]["bad"] = float("nan")
    with pytest.raises(ValueError):
        store.import_records(manifest, records)
    assert store.source_status("malacards")["status"] == "unavailable"


def test_read_detects_tampering_and_does_not_return_records(tmp_path):
    from livemorebio.life_system.reference.sources.licensed_import import LicensedReferenceStore
    store = LicensedReferenceStore(tmp_path)
    manifest, records = _fixture()
    receipt = store.import_records(manifest, records)
    path = tmp_path / (receipt["release_sha256"] + ".json")
    payload = json.loads(path.read_text(encoding="utf-8"))
    payload["records"][0]["name"] = "tampered"
    path.write_text(json.dumps(payload), encoding="utf-8")
    result = store.disease_context("malacards", "test_disease")
    assert result["status"] == "invalid"
    assert "record" not in result


def test_source_and_identifier_are_exact_and_bounded(tmp_path):
    from livemorebio.life_system.reference.sources.licensed_import import LicensedReferenceStore
    store = LicensedReferenceStore(tmp_path)
    manifest, records = _fixture()
    store.import_records(manifest, records)
    assert store.disease_context("malacards", "disease")["status"] == "not_found"
    for source, identifier in (("../malacards", "test"), ("malacards", "../test")):
        with pytest.raises(ValueError):
            store.disease_context(source, identifier)


@pytest.mark.parametrize("endpoint", ["", "https://rest.kegg.jp/", "https://rest.kegg.jp.evil.invalid/",
                                     "http://vendor.invalid/", "https://secret@vendor.invalid/"])
def test_kegg_rejects_unapproved_commercial_transport(monkeypatch, tmp_path, endpoint):
    from livemorebio.life_system.reference.sources.kegg import KEGG
    monkeypatch.setenv("LIVEMORE_KEGG_COMMERCIAL_LICENSE", "acknowledged")
    monkeypatch.setenv("LIVEMORE_KEGG_LICENSE_ID", "TEST-LICENSE")
    monkeypatch.setenv("LIVEMORE_KEGG_API_BASE", endpoint)
    monkeypatch.delenv("LIVEMORE_KEGG_APPROVED_HOST", raising=False)
    monkeypatch.setattr("urllib.request.urlopen", lambda *a, **k: pytest.fail("network called"))
    assert KEGG(cache_dir=str(tmp_path)).human_pathways() == []


def test_kegg_uses_explicit_approved_host_and_scopes_credential(monkeypatch, tmp_path):
    from livemorebio.life_system.reference.sources.kegg import KEGG
    for key, value in {
        "LIVEMORE_KEGG_COMMERCIAL_LICENSE": "acknowledged",
        "LIVEMORE_KEGG_LICENSE_ID": "TEST-LICENSE",
        "LIVEMORE_KEGG_API_BASE": "https://licensed.example/api/",
        "LIVEMORE_KEGG_APPROVED_HOST": "licensed.example",
        "LIVEMORE_KEGG_API_TOKEN": "TEST-TOKEN",
    }.items():
        monkeypatch.setenv(key, value)
    seen = []
    class Response:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def read(self, *args): return (b"hsa" + b"99999\tTEST PATHWAY - Homo sapiens (human)\n")
    def request(self, req, timeout):
        seen.append((req.full_url, req.get_header("Authorization")))
        return Response()
    monkeypatch.setattr("urllib.request.OpenerDirector.open", request)
    source = KEGG(cache_dir=str(tmp_path))
    assert source.human_pathways() == [{"id": ("hsa" + "99999"), "name": "TEST PATHWAY"}]
    assert seen == [("https://licensed.example/api/list/pathway/hsa", "Bearer TEST-TOKEN")]
    assert source.fetch("list/pathway/hsa", parse="text", base="https://other.invalid/") is None


def test_kegg_academic_host_is_rejected_even_when_declared_approved(monkeypatch, tmp_path):
    from livemorebio.life_system.reference.sources.kegg import KEGG
    monkeypatch.setenv("LIVEMORE_KEGG_COMMERCIAL_LICENSE", "acknowledged")
    monkeypatch.setenv("LIVEMORE_KEGG_LICENSE_ID", "TEST-LICENSE")
    monkeypatch.setenv("LIVEMORE_KEGG_API_BASE", "https://rest.kegg.jp/")
    monkeypatch.setenv("LIVEMORE_KEGG_APPROVED_HOST", "rest.kegg.jp")
    monkeypatch.setattr("urllib.request.OpenerDirector.open", lambda *a, **k: pytest.fail("network called"))
    assert KEGG(cache_dir=str(tmp_path)).human_pathways() == []


def test_kegg_disease_uses_local_permissioned_release_without_network(monkeypatch, tmp_path):
    from livemorebio.life_system.reference.sources import KEGG, LicensedReferenceStore
    monkeypatch.setenv("LIVEMORE_LICENSED_REFERENCE_DIR", str(tmp_path / "local"))
    monkeypatch.setattr("urllib.request.OpenerDirector.open", lambda *a, **k: pytest.fail("network called"))
    manifest, records = _fixture("kegg")
    LicensedReferenceStore().import_records(manifest, records)
    result = KEGG(cache_dir=str(tmp_path / "cache")).disease(("H" + "99999"))
    assert result["name"].startswith("TEST RECORD")
    assert result["source_context"]["record_sha256"]


def test_kegg_ambiguous_gene_search_does_not_admit_substring_hits(monkeypatch, tmp_path):
    from livemorebio.life_system.reference.sources import KEGG
    source = KEGG(cache_dir=str(tmp_path))
    monkeypatch.setattr(source, "fetch", lambda *a, **k: ("hsa:" + "1\tTESTX; other gene\nhsa:" + "2\tTEST, TST; exact gene\n"))
    monkeypatch.setattr(source, "gene_pathways", lambda identifier: [])
    result = source.gene("TEST")
    assert [row["id"] for row in result["hits"]] == [("hsa:" + "2")]


def test_kegg_redirect_handler_does_not_forward_authentication():
    from urllib.request import Request
    from livemorebio.transport import _NoRedirect
    request = Request("https://licensed.example/record", headers={"Authorization": "Bearer TEST"})
    assert _NoRedirect().redirect_request(request, None, 302, "redirect", {}, "https://other.invalid/") is None


def test_reference_associations_do_not_register_or_invent_physiology(monkeypatch):
    from livemorebio.life_system.reference.knowledgebase import KnowledgeBase
    from livemorebio.life_system.reference import genome
    monkeypatch.setattr(genome, "define", lambda *a, **k: pytest.fail("reference mutated physiology"))
    kb = KnowledgeBase()
    assert kb.register_into_engine() == 0
    assert all(v["effect"] == {} and v["af"] is None for v in kb.variant_catalogue().values())
    kb._register_disease({"name": "TEST condition", "axis": "unknown", "genes": ["TEST_GENE"]})
    assert kb.variants["TEST_GENE"]["effect"] == {}


def test_life_reference_loader_does_not_define_gene_effects(monkeypatch):
    from livemorebio.life_system import knowledge, genome
    monkeypatch.setattr(genome, "define", lambda *a, **k: pytest.fail("reference mutated physiology"))
    monkeypatch.setattr(knowledge, "_KB", None)
    kb = knowledge.get_kb()
    assert kb.register_into_engine() == 0
    assert kb.condition_effects("type 2 diabetes", severity=1.0)[0] == {}
    assert kb.condition_effects("unknown condition")[1] == "unknown"


def test_builder_does_not_infer_carrier_genotype_from_disease_annotation():
    from livemorebio.life_system.reference.human_builder import HumanSpec, build_human
    human = build_human(HumanSpec(conditions=["type 2 diabetes"], random_background=1.0))
    assert human.genome == {}
    assert human.reference["reference_gene_policy"].startswith("annotations only")


def test_prs_skips_unknown_allele_frequency(monkeypatch):
    from livemorebio.life_system.reference import prs
    monkeypatch.setattr(prs, "_PANEL", {"loaded": False, "axes": {}})
    monkeypatch.setattr(prs.CAL, "risk_af", lambda gene: None)
    assert prs.panel_summary() == {}


def test_prs_never_interprets_absent_genotype_as_reference_alleles(monkeypatch):
    from livemorebio.life_system.reference import prs
    monkeypatch.setattr(prs, "_PANEL", {"loaded": True, "axes": {"metabolic": [("TEST", 0.2, 0.3)]}})
    for evaluate in (prs.scores, prs.biomarker_offsets):
        with pytest.raises(prs.PRSInputError) as caught:
            evaluate({})
        assert caught.value.reason_code == "PRS_GENOTYPE_INCOMPLETE"
    with pytest.raises(ValueError, match="complete"):
        prs.axis_score({}, "metabolic")


def test_unresolved_or_ambiguous_disease_cannot_create_reference_context(monkeypatch):
    from livemorebio.life_system.reference.knowledgebase import KnowledgeBase
    class KEGGFixture:
        def fetch(self, *a, **k): return ("H" + "99998\tTEST partial one\nH" + "99999\tTEST partial two\n")
    class OntologyFixture:
        def search(self, *a, **k): return []
    kb = KnowledgeBase(offline=False)
    before = len(kb.diseases)
    monkeypatch.setattr(kb, "_live_sources", lambda: (KEGGFixture(), OntologyFixture()))
    assert kb.resolve("unresolved test disease") is None
    assert len(kb.diseases) == before
