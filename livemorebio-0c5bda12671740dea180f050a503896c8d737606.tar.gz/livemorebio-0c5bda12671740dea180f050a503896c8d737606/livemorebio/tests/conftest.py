"""Session isolation for the LivemoreBio test suite.

The delivered checkpoint's suite read the developer's private key files from
``~/.livemore`` whenever a test did not set a key explicitly. It therefore
passed only on the author's laptop and failed on any fresh machine (54 local
failures with an empty home directory; 988 on the Linux CI runner). Tests must
never read real key material or operational stores, so every session gets:

* a private temporary ``LIVEMORE_DATA_DIR``;
* ephemeral random 32-byte patch storage and admission keys, never persisted.

Individual tests that exercise the missing-key path still ``delenv`` the key
themselves; this only replaces the implicit dependency on private files.

It also establishes the population-decoder baseline from a pristine interpreter.
``population_identity`` snapshots the loaded decoder at import and later refuses
if it changed, which is the tamper check the gate exists for. Whichever test
imports that module first decides the snapshot, so a session where the first
import happens while another test has ``population_sources`` monkeypatched
captures the patched state as the baseline and then refuses everything after it
is restored. Importing here fixes the baseline before any test can patch, so the
check compares against the real implementation rather than against whatever was
in place when collection order happened to reach it.
"""
from __future__ import annotations

import atexit
import base64
import os
import secrets
import shutil
import sys
import tempfile

import pytest

# TestClient uses this synthetic authority. Production still admits loopback
# only unless the operator explicitly configures additional deployment hosts.
os.environ.setdefault("LIVEMORE_ALLOWED_HOSTS", "testserver")
# Native suite imports must not inherit compose's routing-dependent opt-in;
# compose-specific tests configure their technical container fixtures themselves.
os.environ.pop("LIVEMORE_CONSOLE_PEER", None)

if os.environ.get("LIVEMORE_TEST_USE_REAL_DATA_DIR") != "1":
    _SESSION_DIR = tempfile.mkdtemp(prefix="livemore-test-data-")
    os.chmod(_SESSION_DIR, 0o700)
    os.environ["LIVEMORE_DATA_DIR"] = _SESSION_DIR
    # These caches otherwise ignore DATA_DIR and fall back to the real home.
    os.environ["LIVEMORE_ANATOMY_DIR"] = os.path.join(_SESSION_DIR, "anatomy")
    os.environ["LIVEMORE_CACHE"] = os.path.join(_SESSION_DIR, "reference-cache")
    for _name in ("LIVEMORE_PATCH_STORAGE_KEY", "LIVEMORE_PATCH_ADMISSION_HMAC_KEY"):
        os.environ[_name] = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode("ascii")
    atexit.register(shutil.rmtree, _SESSION_DIR, True)


# Node.js is not a prerequisite, so a host without it skips the tests that need
# it. Whether it has one is the toolchain resolver's answer alone; where that
# answer is no, nothing in the session may start one from some other location.
from livemorebio.tests._node import hold_a_session_without_node_to_its_absence, node_is_required  # noqa: E402

hold_a_session_without_node_to_its_absence()
# A run may declare that it requires Node.js. Read here so that a misspelt
# declaration stops the session before it can skip a single test.
node_is_required()


# The image's base has no ps either. A reconstruction of the image on a machine
# that has one is told which tools the real image would lack, and is held to it
# the same way. No other session is told anything, and none gets a hook.
from livemorebio.tests._source_tree import (  # noqa: E402
    hold_a_reconstructed_image_to_what_its_base_lacks, verifying_container_image)

hold_a_reconstructed_image_to_what_its_base_lacks()
# A tree may be declared the container image, which lets the tests of the source
# tree's release tooling skip. Read here so that a declaration which is misspelt,
# or made of a tree that is not an image, stops the session before it can skip
# a single test.
verifying_container_image()


# Establish the population-decoder baseline now, from an interpreter no test has
# touched. The import is the point; nothing here uses the module.
from livemorebio.aegle import population_identity as _population_identity_baseline  # noqa: E402,F401


# The tests of the frozen research tools cannot be edited, so the ones that read
# a source-tree record get their container-image skip here, by name.
from livemorebio.tests._source_tree import mark_frozen_tests_reading_the_source_tree  # noqa: E402


def pytest_collection_modifyitems(items) -> None:
    mark_frozen_tests_reading_the_source_tree(items)


# ``livemore status``, doctor and the notebook's connect() ask ports 8850, 8851
# and 8852 on this machine whether a service is answering. Where the product is
# running, that is somebody's live service, and this suite is run on such
# machines: the installer runs it to verify every install and stops nothing
# first. Five tests reached the question without supplying an answer, fifteen
# requests in every run, and none used what came back. So every test is
# answered here: nothing is listening. A test about a service that is up
# replaces this with its own answer. ``test_session_isolation`` holds it.
@pytest.fixture(autouse=True)
def _no_test_asks_a_running_service_for_its_health(monkeypatch):
    from urllib.parse import urlsplit
    from livemorebio import cli, stack_readiness

    monkeypatch.setattr(cli, "_health", lambda port: None)
    proved_health = stack_readiness.proved_health
    listener_reachable = stack_readiness.listener_reachable

    def isolated_proved_health(role, url, **kwargs):
        if urlsplit(url).port in {8850, 8851, 8852}:
            return None
        return proved_health(role, url, **kwargs)

    def isolated_listener_reachable(url, **kwargs):
        if urlsplit(url).port in {8850, 8851, 8852}:
            return False
        return listener_reachable(url, **kwargs)

    monkeypatch.setattr(stack_readiness, "proved_health", isolated_proved_health)
    monkeypatch.setattr(stack_readiness, "listener_reachable", isolated_listener_reachable)


@pytest.fixture(autouse=True)
def technical_stack_identities(monkeypatch):
    """Explicit no-bind snapshots for technical TestClient apps.

    TestClient does not own a listener, and many tests intentionally skip the
    app lifespan to avoid restoring a numerical model. Its authority therefore
    comes from this fixture, never from a request URL or a production default.
    Only apps already imported by collection or an earlier test are patched;
    this fixture never imports a service or manages an environment identity.
    Tests importing an app later configure their own snapshot if they need it.
    Startup-refusal tests explicitly clear the injected state when exercising
    a missing key or an unconfigured bind.
    """
    from livemorebio.service_identity import IdentitySnapshot
    from livemorebio.stack_proof import configure_test_identity

    key = secrets.token_bytes(32)
    snapshots = {}
    for role, module_name in (
        ("aegle", "livemorebio.aegle.server"),
        ("life", "livemorebio.life_system.service"),
        ("cendos", "livemorebio.cendos.service"),
    ):
        snapshot = IdentitySnapshot(key, role, "http://testserver:80")
        snapshots[role] = snapshot
        module = sys.modules.get(module_name)
        if module is None:
            continue
        app = module.app
        # Preserve test isolation even where a test installs another generation.
        monkeypatch.setattr(app.state, "stack_proof", app.state.stack_proof)
        configure_test_identity(app, snapshot)
    return snapshots


@pytest.fixture
def technical_environment_identity(monkeypatch, technical_stack_identities):
    """Opt-in technical environment key for actual-bind configuration tests."""
    from livemorebio.service_identity import IDENTITY_KEY_ENV, encode_identity_key

    key = technical_stack_identities["aegle"].key
    monkeypatch.setenv(IDENTITY_KEY_ENV, encode_identity_key(key))
    return key


@pytest.fixture(scope="module")
def pinned_cardiac_asset():
    """L0-R2: a numerical test requires an explicitly enabled, verified asset."""
    from livemorebio.tests._cardiac import require_pinned_cardiac_asset

    return require_pinned_cardiac_asset()
