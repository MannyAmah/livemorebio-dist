"""Offline seed redistribution and source-resolution regression contract."""
from __future__ import annotations

import json
from pathlib import Path
import re

import pytest

from livemorebio.life_system.reference import build_seed

ROOT = Path(__file__).resolve().parents[1] / "life_system"
SEEDS = [ROOT / "seed", ROOT / "reference" / "seed"]
RESTRICTED_ID = re.compile(r"(?i)(?:\b(?:hsa|path|ds|dr):[^\s\x22]+|\b(?:hsa|map|ko)\d{5}\b|\b[HDCKRMNG]\d{5}\b|(?:kegg\.jp|genome\.jp)/)")


@pytest.mark.parametrize("seed", SEEDS, ids=["compatibility", "reference"])
def test_seed_has_no_restricted_identifiers(seed):
    for path in seed.glob("*.json"):
        assert not RESTRICTED_ID.search(path.read_text(encoding="utf-8")), path.name
    pathways = json.loads((seed / "pathways.json").read_text(encoding="utf-8"))
    assert pathways["kegg_human"] == {}
    assert len(pathways["reactome_top"]) > 20
    assert all(p["id"].startswith("R-HSA-") for p in pathways["reactome_top"])


def test_both_runtime_seed_trees_are_byte_identical():
    assert {p.name for p in SEEDS[0].glob("*.json")} == {p.name for p in SEEDS[1].glob("*.json")}
    for path in SEEDS[0].glob("*.json"):
        assert path.read_bytes() == (SEEDS[1] / path.name).read_bytes()


@pytest.mark.parametrize("seed", SEEDS, ids=["compatibility", "reference"])
def test_seed_provenance_and_counts_are_truthful(seed):
    data = {p.stem: json.loads(p.read_text(encoding="utf-8")) for p in seed.glob("*.json")}
    metadata = data["meta"]
    assert "KEGG" not in metadata["sources"]
    assert "Human Protein Atlas" not in metadata["sources"]
    for name in ("diseases", "genes", "drugs"):
        assert metadata["counts"][name] == len(data[name])
    assert metadata["counts"]["kegg_pathways"] == 0
    assert metadata["counts"]["reactome_pathways"] == len(data["pathways"]["reactome_top"])
    for source in ("Reactome", "Open Targets Platform", "HGNC", "Disease Ontology"):
        provenance = metadata["source_records"][source]
        assert provenance["license"] == "CC0-1.0"
        assert re.fullmatch(r"\d{4}-\d{2}-\d{2}", provenance["retrieved_at"])
        assert provenance["license_url"].startswith("https://")
        assert provenance["requests"]
        assert all(re.fullmatch(r"[a-f0-9]{64}", r["sha256"]) for r in provenance["requests"])
    assert all(not record.get("kegg") for record in data["diseases"] + data["drugs"])
    assert all(not record.get("gene_hsa") for record in data["diseases"])
    assert all(not record.get("kegg_pathways") for record in data["genes"].values())


def test_exact_name_resolution_rejects_ambiguous_and_partial_hits():
    exact = build_seed.resolve_exact
    records = [{"id": "DOID:1", "name": "example", "synonyms": ["exact alias"]},
               {"id": "DOID:2", "name": "example complication", "synonyms": []}]
    assert exact("EXACT ALIAS", records)["id"] == "DOID:1"
    assert exact("exam", records) is None
    assert exact("example", records + [{"id": "DOID:3", "name": "example"}]) is None
    assert exact("example", records + [records[0]])["id"] == "DOID:1"


def test_build_seed_does_not_fetch_licensed_or_tissue_sources():
    text = Path(build_seed.__file__).read_text(encoding="utf-8")
    assert "KEGG(" not in text
    assert "ProteinAtlas(" not in text


def test_open_seed_keeps_knowledge_graph_and_search_working():
    from livemorebio.life_system.knowledge import KnowledgeBase
    from livemorebio.life_system.graph import KnowledgeGraph
    from livemorebio.life_system.retrieval import SubstrateIndex
    from livemorebio.life_system.reference.knowledgebase import KnowledgeBase as ReferenceKB

    for kb in (KnowledgeBase(), ReferenceKB(offline=True)):
        disease = kb.disease("type 2 diabetes")
        assert disease and disease["doid"] == "DOID:9352"
        assert "TCF7L2" in disease["genes"]
        assert kb.register_into_engine() == 0
        assert all(v["af"] is None and v["effect"] == {} for v in kb.variant_catalogue().values())
        assert kb.gene("INS")["ensembl"] == "ENSG00000254647"
        assert KnowledgeGraph(kb).path("Gene", "TCF7L2", "Organ", "pancreas")
        assert any("diabetes" in name.lower() for _, name, _ in SubstrateIndex(kb).query("diabetes insulin", k=5))


def test_ontology_resolution_keeps_ambiguous_exact_names_unresolved():
    class Reader:
        def json(self, source, url):
            return {"response": {"numFound": 2, "docs": [
                {"obo_id": "DOID:1", "label": "ambiguous"},
                {"obo_id": "DOID:2", "label": "ambiguous"},
            ]}}
    record = build_seed._disease_identity(Reader(), "ambiguous")
    assert record["doid"] is None
    assert record["genes"] == []
    assert record["resolution_status"] == "unresolved_ambiguous_exact_match"
    assert record["resolution_candidates"] == ["DOID:1", "DOID:2"]


def test_open_targets_crossreference_requires_one_unique_identity():
    rows = [{"id": "EFO_1", "dbXRefs": ["DOID:1"]},
            {"id": "EFO_2", "dbXRefs": ["DOID:1"]}]
    assert build_seed.resolve_open_targets_disease("DOID:1", rows) is None
    assert build_seed.resolve_open_targets_disease("DOID:1", rows[:1]) == "EFO_1"
    assert build_seed.resolve_open_targets_disease(None, rows) is None


def test_builder_source_failure_preserves_both_seed_trees(monkeypatch, tmp_path):
    directories = [tmp_path / "reference", tmp_path / "compatibility"]
    for directory in directories:
        directory.mkdir()
        (directory / "genes.json").write_text('{"existing": true}', encoding="utf-8")
    monkeypatch.setattr(build_seed, "SEED", directories[0])
    monkeypatch.setattr(build_seed, "COMPATIBILITY_SEED", directories[1])
    def unavailable(self, query, variables=None):
        raise build_seed.SeedBuildError(build_seed.SeedBuildReason.SOURCE_UNAVAILABLE)
    monkeypatch.setattr(build_seed.OpenSourceReader, "graphql", unavailable)
    with pytest.raises(build_seed.SeedBuildError) as caught:
        build_seed.build()
    assert caught.value.reason_code == "REFERENCE_SEED_SOURCE_UNAVAILABLE"
    for directory in directories:
        assert list(directory.iterdir()) == [directory / "genes.json"]
        assert (directory / "genes.json").read_text(encoding="utf-8") == '{"existing": true}'


@pytest.mark.parametrize("response", [{}, {"response": {"numFound": 1, "docs": [None]}}])
def test_malformed_ontology_response_is_typed(response):
    class Reader:
        def json(self, source, url):
            return response
    with pytest.raises(build_seed.SeedBuildError) as caught:
        build_seed._disease_identity(Reader(), "example")
    assert caught.value.reason_code == "REFERENCE_SEED_SOURCE_INVALID"


@pytest.mark.parametrize("record", [
    {"targetId": "ENSG00000148737", "score": float("nan"), "evidenceCount": 1},
    {"targetId": "ENSG00000148737", "score": 0.5, "evidenceCount": -1},
    {"targetId": "not-an-ensembl-gene", "score": 0.5, "evidenceCount": 1},
])
def test_invalid_association_is_refused(record):
    with pytest.raises(build_seed.SeedBuildError) as caught:
        build_seed.validate_association(record)
    assert caught.value.reason_code == "REFERENCE_SEED_SOURCE_INVALID"


def test_replacement_validation_refuses_nonfinite_content():
    with pytest.raises(build_seed.SeedBuildError):
        build_seed.encode_replacement({"bad": float("nan")})


def test_exact_synonyms_with_multiple_identities_remain_unresolved():
    assert build_seed.resolve_exact("alias", [
        {"id": "DOID:1", "name": "one", "synonyms": ["alias"]},
        {"id": "DOID:2", "name": "two", "synonyms": ["alias"]},
    ]) is None


def test_vocabulary_endpoint_serves_open_seed_without_service_startup():
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server
    # No lifespan context: this GET exercises the route without starting services.
    client = TestClient(server.app)
    response = client.get("/api/vocab")
    assert response.status_code == 200
    vocabulary = response.json()
    assert vocabulary["n_conditions"] == 20
    assert "Type 2 diabetes mellitus" in vocabulary["conditions"]
    assert "TCF7L2" in vocabulary["variants"]
    assert "TCF7L2" in vocabulary["variant_meta"]
