"""Local audit minimization; authored data and inert construction, no biology."""
from copy import deepcopy
import json
from types import SimpleNamespace

import pytest

from livemorebio import audit
from livemorebio.sdk import Platform


PRIVATE = "AUTHORED_LOCAL_PREVIEW_PRIVATE_SENTINEL"


@pytest.mark.parametrize("family", ["base", "note", "life_system"])
def test_local_preview_keeps_behavior_but_audits_only_fixed_metadata(monkeypatch, family):
    from livemorebio.aegle import runtime
    from livemorebio.life_system import extract, synthetic_human

    state = {"profile": PRIVATE, "human": {"id": PRIVATE},
             "metabolic": {"mean_glucose": 1.25},
             "cardiac": {"hr_bpm": 2.5, "hrv_ms": 3.75}}
    expected = {"profile": PRIVATE, "subject": PRIVATE, "mean_glucose": 1.25,
                "hr_bpm": 2.5, "hrv_ms": 3.75}
    calls, receipts = [], []
    human = object()

    def state_read():
        calls.append(("state",))
        return deepcopy(state)

    twin = SimpleNamespace(state=state_read)

    def construct(*args, **kwargs):
        calls.append(("twin", args, kwargs))
        return twin

    def structured(*args, **kwargs):
        calls.append(("human", args, kwargs))
        return human

    def extracted(text, *, hid):
        calls.append(("extract", text, hid))
        return human, {"authored": True}

    def receipt(*args):
        assert calls[-1] == ("state",), "audit preceded successful summary"
        receipts.append(args)

    monkeypatch.setattr(runtime, "AegleTwin", construct)
    monkeypatch.setattr(synthetic_human, "SyntheticHuman", structured)
    monkeypatch.setattr(extract, "ClinicalExtractor", lambda: SimpleNamespace(to_synthetic_human=extracted))
    monkeypatch.setattr(audit, "record", receipt)
    platform = object.__new__(Platform)
    platform.mode = "inprocess"
    # L0-R15 round 1: structured fields take technical values only (free text in them is refused
    # before construction or audit; test_l0_free_text_gate.py holds that), so these are vocabulary
    # terms and a technical id, and the audit must hold none of them.
    arguments = ({"base": "healthy"} if family == "base" else
                 {"note": PRIVATE, "base": "healthy", "hid": PRIVATE} if family == "note" else
                 {"hid": "LMB-44", "age": 44, "sex": "M", "conditions": ["Type 2 diabetes mellitus"],
                  "genome": {"TCF7L2": 1}, "lifestyle": .7})
    original = deepcopy(arguments)

    if family == "note":
        # L0-R15: a note is refused before it is parsed, kept or audited.
        from .test_l0_clinical_note_gate import assert_note_refused
        assert_note_refused(lambda: platform.patient(**arguments))
        assert arguments == original and calls == [] and receipts == []
        assert not hasattr(platform, "_twin")
        return
    assert platform.patient(**arguments) == expected
    assert arguments == original and platform._twin is twin
    if family == "base":
        assert calls == [("twin", ("healthy",), {}), ("state",)]
    elif family == "note":
        assert calls == [("extract", PRIVATE, PRIVATE), ("twin", (), {"human": human}), ("state",)]
    else:
        assert calls == [("human", ("LMB-44",), {"age": 44, "sex": "M", "conditions": ["Type 2 diabetes mellitus"],
                                                 "genome": {"TCF7L2": 1}, "lifestyle": .7}),
                         ("twin", (), {"human": human}), ("state",)]
    assert receipts == [("patient.set", {"family": family, "mode": "inprocess"}, {"outcome": "CREATED"})]
    assert PRIVATE not in json.dumps(receipts)
    assert not any(value in json.dumps(receipts) for value in ("LMB-44", "Type 2 diabetes", "TCF7L2"))
