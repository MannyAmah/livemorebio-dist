"""Author-made controller records only; no participant, HTTP call or model solve."""
import json
from pathlib import Path
import subprocess
from ._node import NODE, run_node as _run_node


MODULE = (Path(__file__).parents[1] / 'aegle/console/lib/member_picker.js').as_uri()
PREAMBLE = r"""
import assert from 'node:assert/strict';
const {mountRemoteMemberPicker}=await import(MODULE);
const nodes=new Map();
const el=key=>{if(!nodes.has(key))nodes.set(key,{value:'',textContent:'',innerHTML:'',hidden:false,disabled:false,handlers:{},addEventListener(k,f){this.handlers[k]=f},setAttribute(){},replaceChildren(){this.innerHTML=''},focus(){}});return nodes.get(key)};
const host={innerHTML:'',setAttribute(){},querySelector:el};
const tick=async()=>{for(let i=0;i<4;i++)await new Promise(setImmediate)};
const member=id=>({twin_id:id,record_version:2,display_label:'Technical member, not a person',source_class:'REAL_HUMAN',execution_eligibility:{state:'UNAVAILABLE',reason_code:'MODEL_BINDING_REQUIRED'}});
const page=(id,next=null)=>({members:[member(id)],pagination:{limit:10,total:1000,has_more:next!==null,next_cursor:next}});
const response=value=>({ok:true,status:200,json:async()=>value});
"""


def run(code):
    result = _run_node([NODE,'--input-type=module','--eval',PREAMBLE.replace('MODULE',json.dumps(MODULE))+code],capture_output=True,text=True,timeout=10, encoding="utf-8")
    assert result.returncode == 0, result.stderr


def test_server_page_is_bounded_detail_is_explicit_and_no_experiment_is_sent():
    run(r"""
const calls=[];const request=async(url,options)=>{calls.push({url,options});return response(url.includes('/members/')?{schema:'livemore.frozen-real-human-member.v1',source_class:'REAL_HUMAN',twin_id:'twin-technical-1',record_version:2,snapshot_sha256:'a'.repeat(64),evidence_sha256:'b'.repeat(64),snapshot:{twin_id:'twin-technical-1',version:2,source_class:'REAL_HUMAN',observations:{note:'Authored technical fixture'}}}:page('twin-technical-1','cursor-two'))};
const ui=mountRemoteMemberPicker(host,{cohortId:'cohort-technical',request});try{await tick();assert.equal(calls.length,1);assert(calls[0].url.endsWith('/members?limit=10'));assert.equal(calls[0].options.cache,'no-store');assert(!el('[data-member-inspection]').textContent.includes('Authored technical'));
el('[data-member-results]').value='twin-technical-1';await el('[data-member-results]').handlers.change({target:el('[data-member-results]')});assert.equal(calls.length,1,'selection itself fetched clinical detail');await el('[data-member-inspect]').handlers.click();assert.equal(calls.length,2);assert(calls[1].url.endsWith('/members/twin-technical-1'));assert(el('[data-member-inspection]').textContent.includes('Authored technical fixture'));assert(calls.every(c=>!c.options.method||c.options.method==='GET'));}finally{ui.dispose()}
""")


def test_pending_page_navigation_is_single_and_failed_detail_clears_prior_snapshot():
    run(r"""
let resolve,calls=0;const request=async(url)=>{calls++;if(calls===1)return response(page('twin-technical-1','cursor-two'));if(url.includes('cursor='))return new Promise(r=>resolve=()=>r(response(page('twin-technical-2'))));return {ok:false,status:403,json:async()=>({error:'safe denied'})}};
const ui=mountRemoteMemberPicker(host,{cohortId:'cohort-technical',request});try{await tick();el('[data-member-next]').handlers.click();el('[data-member-next]').handlers.click();await tick();assert.equal(calls,2,'rapid clicks duplicate page requests');assert(el('[data-member-next]').disabled);resolve();await tick();assert(el('[data-member-page]').textContent.includes('Page 2'));el('[data-member-inspection]').textContent='OLD PRIVATE SNAPSHOT';el('[data-member-results]').value='twin-technical-2';el('[data-member-results]').handlers.change({target:el('[data-member-results]')});await el('[data-member-inspect]').handlers.click();assert(!el('[data-member-inspection]').textContent.includes('OLD PRIVATE'));assert(el('[data-member-status]').textContent.includes('unavailable'));}finally{ui.dispose()}
""")


def test_disposed_request_cannot_publish_and_wrong_member_wrapper_rejects():
    run(r"""
let release;const first=mountRemoteMemberPicker(host,{cohortId:'cohort-technical',request:()=>new Promise(r=>release=r)});first.dispose();release(response(page('twin-technical-1')));await tick();assert(!el('[data-member-results]').innerHTML.includes('twin-technical-1'));
const ui=mountRemoteMemberPicker(host,{cohortId:'cohort-technical',request:async url=>response(url.includes('/members/')?{schema:'livemore.frozen-real-human-member.v1',source_class:'REAL_HUMAN',twin_id:'twin-WRONG',record_version:2,snapshot:{twin_id:'twin-WRONG'}}:page('twin-technical-2'))});try{await tick();el('[data-member-results]').value='twin-technical-2';el('[data-member-results]').handlers.change({target:el('[data-member-results]')});await el('[data-member-inspect]').handlers.click();assert(!el('[data-member-inspection]').textContent.includes('twin-WRONG'));assert(el('[data-member-status]').textContent.includes('unavailable'));}finally{ui.dispose()}
""")
