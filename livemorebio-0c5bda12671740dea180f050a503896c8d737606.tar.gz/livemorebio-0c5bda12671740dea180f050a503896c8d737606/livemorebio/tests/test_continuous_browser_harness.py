"""Guard the browser harness without launching a browser or creating records."""
import json
from pathlib import Path
import subprocess
from ._node import require_node
import pytest


HARNESS = Path(__file__).resolve().parents[2] / "tools/check_continuous_browser.cjs"


def run(script: str) -> None:
    result = subprocess.run(
        [require_node(), "--eval", f"const h=require({json.dumps(str(HARNESS))});" + script],
        capture_output=True, text=True, timeout=10, encoding="utf-8",
    )
    assert result.returncode == 0, result.stderr


def test_browser_harness_requires_exact_isolated_technical_source_before_writes():
    run("""
const assert=require('node:assert/strict'),good={LIVEMORE_BROWSER_BASE:'http://127.0.0.1:8910',LIVEMORE_BROWSER_OUTPUT:'/tmp/technical-browser-check',LIVEMORE_BROWSER_TWIN_ID:'twin-'+'a'.repeat(32),LIVEMORE_BROWSER_TECHNICAL:'1',LIVEMORE_BROWSER_EXPECTED_SOURCE:'b'.repeat(64)};
const config=h.validateConfig(good);assert.equal(config.minimumMs,50000);
for(const env of [{...good,LIVEMORE_BROWSER_BASE:'http://127.0.0.1:8850'},{...good,LIVEMORE_BROWSER_TWIN_ID:''},{...good,LIVEMORE_BROWSER_TECHNICAL:'0'},{...good,LIVEMORE_BROWSER_OUTPUT:'relative'},{...good,LIVEMORE_BROWSER_EXPECTED_SOURCE:''}])assert.throws(()=>h.validateConfig(env));
const source={preparation_available:true,source_generation:'generation-fixture',selection:{twin_id:config.twinId,twin_version:1,source_data_class:'SYNTHETIC'}};
assert.equal(h.requireTechnicalSource(source,config.twinId).twin_id,config.twinId);
for(const value of [{...source,preparation_available:false},{...source,selection:{...source.selection,source_data_class:'REAL_HUMAN'}},{...source,selection:{...source.selection,twin_id:'twin-'+'b'.repeat(32)}}])assert.throws(()=>h.requireTechnicalSource(value,config.twinId));
""")


def test_browser_evidence_excludes_model_series_and_profile_values():
    run("""
const assert=require('node:assert/strict');const result=h.metadataSnapshot({execution_id:'a'.repeat(32),revision:20,control_revision:2,state:'running',native_time:4,latest_frame:4,source_snapshot_hash:'b'.repeat(64),source_valid:true,evidence_class:'MODELED',selection:{private_profile:'never write'},series:[{values:[9999]}],parameters:{private:'never write'}},{session_id:'c'.repeat(32),revision:22,control_revision:3,state:'streaming',last_admitted:4,last_forwarded:4,last_captured_at:'2026-09-08T00:00:00Z',hardware_present:false});
assert.equal(result.execution.control_revision,2);assert.equal(result.life.control_revision,3);assert.equal(result.execution.latest_frame,4);assert.equal(result.life.last_forwarded,4);const encoded=JSON.stringify(result);assert(!encoded.includes('9999')&&!encoded.includes('private_profile')&&!encoded.includes('parameters'));
assert.throws(()=>h.assertOwnedIds({executionId:'wrong',sessionId:null}));assert.throws(()=>h.assertOwnedIds({executionId:null,sessionId:'c'.repeat(32)}));assert.doesNotThrow(()=>h.assertOwnedIds({executionId:'a'.repeat(32),sessionId:'c'.repeat(32)}));
""")


def test_cleanup_sends_explicit_control_guard_once_and_never_falls_back_to_samples():
    run("""
const assert=require('node:assert/strict');
(async()=>{
const owned={executionId:'a'.repeat(32),sessionId:'c'.repeat(32)};
for(const control_revision of [3,undefined,true,0,-1,1.5,'3',31]){
const writes=[];let checks=0;
const page={evaluate:async(fn,arg)=>{if(typeof arg==='string'){const life=arg.includes('/sessions/');return {ok:true,status:200,body:{execution_id:owned.executionId,session_id:owned.sessionId,binding:{execution_id:owned.executionId},state:'running',revision:30,control_revision,source_generation:'generation-a'}}}writes.push(arg);return {ok:true,state:'stopped'}}};
const result=await h.cleanupOwned(page,owned,async()=>checks++);
if(control_revision===3){assert.equal(writes.length,2);assert.equal(checks,2);assert.deepEqual(writes[0].body,{expected_control_revision:3});assert.deepEqual(writes[1].body,{expected_control_revision:3,expected_source_generation:'generation-a'});assert(result.every(x=>x.outcome==='stopped'));}
else{assert.equal(writes.length,0);assert(result.every(x=>x.outcome==='unconfirmed_no_retry'));}
}
for(const control_revision of [undefined,true,0,-1,1.5,'3',31])assert.throws(()=>h.metadataSnapshot({revision:30,control_revision},null));
})().catch(error=>{console.error(error);process.exitCode=1});
""")


def test_browser_harness_preserves_real_visibility_and_visible_control_setup():
    source = HARNESS.read_text(encoding="utf-8")
    assert "Object.defineProperty(document" not in source
    assert "setContent(" not in source
    for control in ("data-register", "data-bind-device", "data-prepare", "data-bind-session", "data-engine-action", "data-life-action"):
        assert control in source
    assert "document.hidden" in source and "bringToFront" in source
    assert "50000" in source and "finally" in source and "cleanupOwned" in source
    assert "page.request.post" not in source


def test_browser_closes_on_setup_and_receipt_failure_and_rejects_wrong_build():
    run("""
const assert=require('node:assert/strict');
(async()=>{
for(const error of ['context setup failed','receipt write failed']){let closed=0;await assert.rejects(h.withOwnedBrowser({launch:async()=>({close:async()=>closed++})},{},async()=>{throw Error(error)}));assert.equal(closed,1);}
const digest='b'.repeat(64),build={schema:'livemore.build-identity.v1',identity_scope:'startup_source',source_sha256:digest,process_instance:'11111111-1111-4111-8111-111111111111'};
const services=Object.fromEntries(['Aegle','LIFE','Cendos'].map((name,index)=>[name,{up:true,service:name,port:8910+index,build:{...build,process_instance:name==='Aegle'?build.process_instance:(index+1).toString().repeat(8)+'-1111-4111-8111-111111111111'}}]));
const captured=h.validateBuild(build,services,digest);assert.equal(captured.source_sha256,digest);
const current={...build,schema:'livemore.build-identity.v2',fingerprint_scope:'runtime_code_and_public_reference_assets.v2'};
const currentServices=Object.fromEntries(Object.entries(services).map(([name,row])=>[name,{...row,build:{...row.build,schema:current.schema,fingerprint_scope:current.fingerprint_scope}}]));
assert.equal(h.validateBuild(current,currentServices,digest).source_sha256,digest);
assert.throws(()=>h.validateBuild(current,services,digest));
assert.throws(()=>h.validateBuild({...current,fingerprint_scope:'unknown'},currentServices,digest));

assert.throws(()=>h.validateBuild({...build,source_sha256:'c'.repeat(64)},services,digest));
const restarted=structuredClone(services);restarted.LIFE.build.process_instance='99999999-1111-4111-8111-111111111111';assert.throws(()=>h.validateBuild(build,restarted,digest,captured));
})().catch(error=>{console.error(error);process.exitCode=1});
""")


def test_visibility_runtime_and_original_session_are_pinned_and_owned():
    # Reads the pinned Playwright package itself; skip where it is not installed
    # rather than asserting against another machine's node_modules.
    from .._toolchain import playwright_available, playwright_module
    if not playwright_available():
        pytest.skip(f"Playwright package not present at {playwright_module()}")
    run("""
const assert=require('node:assert/strict');
(async()=>{
const pins=await h.readVisibilityRuntime((process.env.LIVEMORE_PLAYWRIGHT_MODULE||'/nonexistent/livemore/playwright/index.js'));
assert.equal(pins.playwright,'1.58.2');assert.equal(pins.playwright_core,'1.58.2');
assert.doesNotThrow(()=>h.validateVisibilityRuntime(pins));
for(const field of ['playwright','playwright_core','chromium_source_sha256','factory_source_sha256'])assert.throws(()=>h.validateVisibilityRuntime({...pins,[field]:'changed'}));
const calls=[],browser={},context={browser:()=>browser},implementation={};
implementation.delegate={_page:implementation,_mainFrameSession:{_client:{send:async(...args)=>calls.push(args)}}};
const page={context:()=>context,_connection:{toImpl:()=>implementation}};
await h.disableAutomationFocus(page,context,browser);
assert.deepEqual(calls,[['Emulation.setFocusEmulationEnabled',{enabled:false}]]);
await assert.rejects(h.disableAutomationFocus(page,{},browser));
await assert.rejects(h.disableAutomationFocus(page,context,{}));
await assert.rejects(h.disableAutomationFocus({...page,_connection:null},context,browser));
implementation.delegate._page={};await assert.rejects(h.disableAutomationFocus(page,context,browser));
implementation.delegate._page=implementation;implementation.delegate._mainFrameSession._client.send=async()=>{throw Error('rejected')};
await assert.rejects(h.disableAutomationFocus(page,context,browser));assert.equal(calls.length,1);
})().catch(error=>{console.error(error);process.exitCode=1});
""")


def test_native_visibility_requires_browser_generated_transitions():
    run("""
const assert=require('node:assert/strict'),state=(hidden,events)=>({hidden,visibility:hidden?'hidden':'visible',events});
const seen=[{hidden:true,trusted:true},{hidden:false,trusted:true}];
assert.doesNotThrow(()=>h.assertNativeVisibility(state(false,seen),state(true,seen)));
for(const [first,second] of [[state(false,[]),state(true,seen)],[state(false,[...seen,{hidden:true,trusted:false}]),state(true,seen)],[state(true,seen),state(true,seen)],[state(false,seen),state(false,seen)]])assert.throws(()=>h.assertNativeVisibility(first,second));
""")


def test_visibility_preflight_failure_closes_spare_before_product_work():
    run("""
const assert=require('node:assert/strict');
(async()=>{
let closed=0,sent=[];const browser={},context={browser:()=>browser};
function page(){const p={context:()=>context,goto:async()=>{},bringToFront:async()=>{},evaluate:async()=>{},waitForFunction:async()=>{throw Error('visibility timeout')},close:async()=>closed++},impl={};impl.delegate={_page:impl,_mainFrameSession:{_client:{send:async(method,args)=>{sent.push([method,args]);return{windowId:1}}}}};p._connection={toImpl:()=>impl};return p;}
const primary=page();context.newPage=async()=>page();
await assert.rejects(h.nativeVisibilityPreflight(context,primary,browser));
assert.equal(closed,1);assert(sent.filter(x=>x[0]==='Emulation.setFocusEmulationEnabled').every(x=>x[1].enabled===false));
})().catch(error=>{console.error(error);process.exitCode=1});
""")


def test_clock_disclosure_is_actually_opened_without_requiring_hidden_inner_text():
    source = HARNESS.read_text(encoding="utf-8")
    frame_check = source.split("async function assertVisibleFrame(minimum){", 1)[1].split("\n  try{", 1)[0]
    assert "page.locator('[data-freshness]').textContent()" in frame_check
    assert "page.locator('[data-freshness]').innerText()" not in frame_check
    assert "clockSummary.press('Enter')" in source
    assert "page.locator('[data-freshness]').isVisible()" in source
    assert "source-clock-disclosure-visible-through-keyboard" in source
