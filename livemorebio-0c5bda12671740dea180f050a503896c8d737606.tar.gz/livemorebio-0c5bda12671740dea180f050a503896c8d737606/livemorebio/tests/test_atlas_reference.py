"""Atlas source/cache contracts: technical fixtures never count as real anatomy."""
from __future__ import annotations

import hashlib
import importlib
import io
import json
import os
from pathlib import Path
import stat
import zipfile

import pytest


SOURCE_ID = "bp3d-4.0-20130619-surface-core-v1"
ARCHIVE_SHA = "40665852c49f218326590e204db91064a1ecfc3c6f8cbd7bbbcaac62c7cd409e"
ROOT_MATRIX = [0.001, 0, 0, 0, 0, 0, -0.001, 0, 0, 0.001, 0, 0, 0, 0, 0, 1]


@pytest.fixture
def atlas():
    return importlib.import_module("livemorebio.anatomy.atlas_reference")


@pytest.fixture
def isolated(tmp_path, monkeypatch):
    root = tmp_path / "anatomy"
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(root))
    return root


def test_catalog_preserves_exact_source_and_489_elements(atlas, isolated):
    catalog = atlas.catalog()
    assert catalog["schema"] == "livemore.atlas-source.v1"
    assert catalog["source_id"] == SOURCE_ID
    assert catalog["archive_sha256"] == ARCHIVE_SHA
    assert catalog["archive_bytes"] == 142903898
    assert "/20130619/" in catalog["archive_url"] and "/LATEST/" not in catalog["archive_url"]
    assert catalog["evidence_state"] == "REFERENCE_ONLY"
    assert catalog["patient_registered"] is False
    assert catalog["current_publisher_license"] == "CC-BY-4.0"
    assert catalog["retained_embedded_historical_notice"] == "CC-BY-SA-2.1-JP"
    assert len(catalog["groups"]) == 9
    assert len(catalog["members"]) == 489
    ids = [m["element_id"] for m in catalog["members"]]
    assert len(set(ids)) == len(ids)
    assert set(ids) == {x for g in catalog["groups"] for x in g["element_ids"]}
    assert sum(m["vertices"] for m in catalog["members"]) == 535346
    assert sum(m["triangles"] for m in catalog["members"]) == 957072
    assert sum(m["source_bytes"] for m in catalog["members"]) == 64944382
    assert [g["asset_key"] for g in catalog["groups"]] == [
        "skin", "heart", "liver", "pancreas", "right-kidney", "left-kidney", "right-lung", "left-lung", "brain"]
    for group in catalog["groups"]:
        assert hashlib.sha256(("\n".join(sorted(group["element_ids"])) + "\n").encode("ascii")).hexdigest() == group["element_ids_sha256"]
    skin = next(m for m in catalog["members"] if m["element_id"] == "FJ2810")
    assert skin["bounds_mm"][0][2] == -78.1112
    assert skin["source_sha256"] == "682f402206f15592acdeaae8ffb6b34c3e5c3267fa4685e63d2e4920ef2a80e0"
    assert not isolated.exists()


def test_catalog_returns_detached_declaration(atlas):
    catalog = atlas.catalog()
    catalog["members"][0]["source_sha256"] = "0" * 64
    catalog["groups"][0]["element_ids"].append("NOT_A_SOURCE_ELEMENT")
    again = atlas.catalog()
    assert again["members"][0]["source_sha256"] != "0" * 64
    assert again["groups"][0]["element_ids"] == ["FJ2810"]


def test_missing_status_never_creates_cache_or_calls_network(atlas, isolated, monkeypatch):
    monkeypatch.setattr(atlas, "_open_source", lambda *a, **k: pytest.fail("status performed network"))
    result = atlas.status()
    assert result["schema"] == "livemore.atlas-reference-status.v1"
    assert result["state"] == "missing"
    assert result["available"] is False
    assert result["manifest"] is None and result["manifest_sha256"] is None
    assert result["source_id"] == SOURCE_ID
    assert result["reference_geometry"] is True
    assert result["patient_registered"] is False
    assert str(isolated) not in json.dumps(result)
    assert not isolated.exists()


@pytest.mark.parametrize("source_id", [None, True, 1, [], {}, "", "../atlas", "https://example.invalid/body.zip", SOURCE_ID + " "])
def test_unknown_source_rejects_before_filesystem_or_network(atlas, isolated, monkeypatch, source_id):
    monkeypatch.setattr(atlas, "_open_source", lambda *a, **k: pytest.fail("invalid source performed network"))
    with pytest.raises(atlas.AtlasReferenceError) as error:
        atlas.install(source_id)
    assert error.value.code == "ATLAS_INVALID_ID"
    assert error.value.status_code == 422
    assert not isolated.exists()


@pytest.mark.parametrize("digest", [None, "", "A" * 64, "f" * 63, "../active", [], 1])
def test_asset_bad_digest_rejects_before_cache_access(atlas, isolated, digest):
    with pytest.raises(atlas.AtlasReferenceError) as error:
        atlas.read_asset(digest, "skin")
    assert error.value.code == "ATLAS_INVALID_ID"
    assert not isolated.exists()


@pytest.mark.parametrize("key", ["", "Skin", "../skin", "skin.glb", "skeletal-muscle", None, {}, True])
def test_asset_key_is_fixed_not_a_path(atlas, isolated, key):
    with pytest.raises(atlas.AtlasReferenceError) as error:
        atlas.read_asset("f" * 64, key)
    assert error.value.code == "ATLAS_INVALID_ID"
    assert not isolated.exists()


def test_read_does_not_implicitly_acquire(atlas, isolated, monkeypatch):
    monkeypatch.setattr(atlas, "_open_source", lambda *a, **k: pytest.fail("read acquired source"))
    with pytest.raises(atlas.AtlasReferenceError) as error:
        atlas.read_manifest()
    assert error.value.code == "ATLAS_NOT_INSTALLED"
    assert not isolated.exists()


@pytest.mark.parametrize("kind", ["parent_symlink", "atlas_symlink", "atlas_public", "atlas_file"])
def test_unsafe_cache_is_not_fixed_by_chmod_or_followed(atlas, isolated, tmp_path, kind):
    target = tmp_path / "preserve"
    target.mkdir(mode=0o700)
    if kind == "parent_symlink":
        isolated.symlink_to(target, target_is_directory=True)
    else:
        isolated.mkdir(mode=0o700)
        atlas_root = isolated / "atlas"
        if kind == "atlas_symlink":
            atlas_root.symlink_to(target, target_is_directory=True)
        elif kind == "atlas_public":
            atlas_root.mkdir(mode=0o755)
            atlas_root.chmod(0o755)
        else:
            atlas_root.write_bytes(b"TECHNICAL SENTINEL")
    original = target.stat().st_mode
    result = atlas.status()
    assert result["state"] == "unsafe_cache"
    assert result["available"] is False
    assert target.stat().st_mode == original
    assert str(isolated) not in json.dumps(result)


def test_catalog_source_file_identity_is_verified(atlas, monkeypatch):
    original = atlas._declaration_bytes
    def altered():
        value = json.loads(original())
        value["members"][0]["name"] = "ALTERED TECHNICAL SOURCE"
        return json.dumps(value).encode()
    monkeypatch.setattr(atlas, "_declaration_bytes", altered)
    with pytest.raises(atlas.AtlasReferenceError) as error:
        atlas.catalog()
    assert error.value.code == "ATLAS_SOURCE_INTEGRITY"


@pytest.mark.parametrize("url", [
    "http://dbarchive.biosciencedbc.jp/data/bodyparts3d/20130619/isa_BP3D_4.0_obj_99.zip",
    "https://example.invalid/isa_BP3D_4.0_obj_99.zip",
    "https://dbarchive.biosciencedbc.jp/data/bodyparts3d/LATEST/isa_BP3D_4.0_obj_99.zip",
    "https://dbarchive.biosciencedbc.jp/data/bodyparts3d/20130619/isa_BP3D_4.0_obj_99.zip?query=1",
    "https://operator@dbarchive.biosciencedbc.jp/data/bodyparts3d/20130619/isa_BP3D_4.0_obj_99.zip",
])
def test_network_policy_allows_only_exact_packaged_https(atlas, url):
    with pytest.raises(atlas.AtlasReferenceError) as error:
        atlas._validate_source_url(url)
    assert error.value.code == "ATLAS_SOURCE_POLICY"


def test_redirect_handler_rejects_even_same_origin_change(atlas):
    handler = atlas._NoRedirect()
    with pytest.raises(atlas.AtlasReferenceError) as error:
        handler.redirect_request(None, None, 302, "redirect", {}, "/another-file.zip")
    assert error.value.code == "ATLAS_SOURCE_POLICY"


def test_structured_errors_never_include_cause_or_paths(atlas):
    error = atlas.AtlasReferenceError("ATLAS_SOURCE_INTEGRITY")
    assert error.status_code == 503
    assert "integrity" in str(error).lower()
    with pytest.raises(ValueError):
        atlas.AtlasReferenceError("PRIVATE PATH OR SECRET")

