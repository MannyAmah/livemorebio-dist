"""Legacy browser exports cannot manufacture independent scientific review."""
from dataclasses import asdict
from pathlib import Path
from unittest.mock import Mock

import pytest

from livemorebio.aegle import evidence_api
from livemorebio.engines.metabolic.glucose_insulin import T2D
from livemorebio.evidence import EvidenceService, EvidenceStore


def run_fixture() -> dict:
    return {"compound": "metformin", "subject": "technical-fixture-1", "dose": 1.0,
            "grams": 75.0, "hours": 4.0, "twin_params": asdict(T2D),
            "readouts": [{"endpoint": "delta_mean_glucose", "value": -3.2, "unit": "mg/dL"}],
            "actor": "fixture-operator", "cendos_run_id": "fixture-cendos-run"}


@pytest.fixture
def service(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    result = EvidenceService(EvidenceStore(tmp_path / "evidence.sqlite", audit_signing_key=b"t" * 32))
    monkeypatch.setattr(evidence_api, "service", lambda: result)
    monkeypatch.setattr(evidence_api, "_code_version", lambda: "working-tree:technical-fixture")
    yield result
    result.close()


def test_legacy_run_creates_unapproved_draft_without_fake_reviewer(service):
    result = evidence_api.create_from_run(run_fixture())
    package = service.get(evidence_api.TENANT, result["package_id"])
    assert package.lifecycle.value == "draft"
    assert package.protocol.approval_status == "draft"
    assert package.protocol.approved_at is None
    assert package.protocol.approved_by is None
    assert package.protocol.approval_role is None
    assert package.protocol.approval_reference is None
    assert package.created_by == "fixture-operator"
    assert package.validation_events == ()
    assert package.measurements == ()


def test_browser_supplied_reviewer_cannot_approve_the_protocol(service):
    result = evidence_api.create_from_run({**run_fixture(), "approved_by": "invented-reviewer",
                                          "approval_status": "approved"})
    package = service.get(evidence_api.TENANT, result["package_id"])
    assert package.protocol.approval_status == "draft"
    assert package.protocol.approved_by is None


def test_unreviewed_draft_export_cannot_impersonate_qa_actor(service, monkeypatch):
    result = evidence_api.create_from_run(run_fixture())
    lock = Mock(side_effect=AssertionError("the browser exporter must not act as a reviewer"))
    monkeypatch.setattr(service, "lock", lock)
    with pytest.raises(ValueError, match="review"):
        evidence_api.export_zip(result["package_id"])
    lock.assert_not_called()
    assert service.get(evidence_api.TENANT, result["package_id"]).lifecycle.value == "draft"


def test_dataset_identity_is_not_a_hash_of_a_seed_module_label(service):
    result = evidence_api.create_from_run(run_fixture())
    package = service.get(evidence_api.TENANT, result["package_id"])
    versions = package.predictions[0].dataset_versions
    assert versions == ("dataset-lineage:not-declared",)
    assert package.predictions[0].scenario_snapshot.dataset_versions == versions


def test_caller_audit_reference_is_not_promoted_to_verified_content_hash(service):
    fingerprint = "a" * 64
    result = evidence_api.create_from_run({**run_fixture(), "audit_fingerprint": fingerprint})
    package = service.get(evidence_api.TENANT, result["package_id"])
    assert fingerprint not in package.provenance.content_hashes
    assert package.provenance.correlation_ids == ("unverified-audit-ref:" + fingerprint,)


def test_every_numeric_metabolic_parameter_has_a_declared_unit(service):
    result = evidence_api.create_from_run(run_fixture())
    package = service.get(evidence_api.TENANT, result["package_id"])
    inputs = {value.name: value for value in package.predictions[0].scenario_snapshot.model_inputs}
    assert set(inputs) == set(asdict(T2D)) - {"name"}
    assert all(value.unit != "unspecified" for value in inputs.values())


@pytest.mark.parametrize("payload", [None, [], "invalid", 1])
def test_malformed_legacy_evidence_input_is_typed_value_error(service, payload):
    with pytest.raises(ValueError, match="object"):
        evidence_api.create_from_run(payload)
    assert service.list(evidence_api.TENANT) == ()


def test_unversioned_code_does_not_claim_a_content_hash_of_its_path(monkeypatch):
    monkeypatch.setattr(evidence_api.subprocess, "check_output", Mock(side_effect=OSError("git unavailable")))
    assert evidence_api._code_version() == "unversioned-source:content-not-pinned"


def test_dirty_code_does_not_claim_exact_git_revision(monkeypatch):
    monkeypatch.setattr(evidence_api.subprocess, "check_output",
                        Mock(side_effect=[b"a" * 40, b" M aegle/evidence_api.py\n"]))
    assert evidence_api._code_version() == "working-tree:git-" + "a" * 40


@pytest.mark.parametrize("raw", ["[]", "null", "{", '{"kind":"meal","params":[]}',
                                 '{"kind":"meal","params":null}'])
def test_legacy_intervention_malformed_input_is_client_error_without_mutation(monkeypatch, raw):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "legacy-evidence-test-only")
    before = asdict(server._state["tw"].profile)
    response = TestClient(server.app, raise_server_exceptions=False).post(
        "/api/stimulate", content=raw,
        headers={"Authorization": "Bearer legacy-evidence-test-only", "Content-Type": "application/json"})
    assert 400 <= response.status_code < 500
    assert asdict(server._state["tw"].profile) == before


def test_browser_legacy_evidence_intake_is_disabled_before_parsing_or_storage(monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server

    create = Mock(side_effect=AssertionError("legacy browser intake must not reach plaintext storage"))
    monkeypatch.setattr(evidence_api, "create_from_run", create)
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "legacy-evidence-test-only")
    response = TestClient(server.app, raise_server_exceptions=False).post(
        "/api/evidence", content=b"{malformed and potentially private input",
        headers={"Authorization": "Bearer legacy-evidence-test-only"})
    assert response.status_code == 409
    assert response.json()["code"] == "LEGACY_EVIDENCE_INTAKE_DISABLED"
    assert response.json()["supported_workflow"] == "/api/research/studies"
    create.assert_not_called()
