from __future__ import annotations

import json
import stat
import threading
import time
from unittest.mock import Mock

import pytest
from fastapi.testclient import TestClient
from livemorebio.evidence.errors import IntegrityError, NotFoundError


TOKEN = "test-token-with-enough-entropy"


def _auth() -> dict[str, str]:
    return {"Authorization": f"Bearer {TOKEN}"}


def test_t2d_screen_cohort_is_explicitly_eligible_and_reproducible():
    from livemorebio.sdk import Platform

    first = Platform().screen(
        "metformin",
        n=8,
        seed=17,
        indication="type-2-diabetes",
        cohort="t2d-enriched",
        assay="ogtt",
    )
    second = Platform().screen(
        "metformin",
        n=8,
        seed=17,
        indication="type-2-diabetes",
        cohort="t2d-enriched",
        assay="ogtt",
    )

    assert first["summary"]["admissibility"]["status"] == "supported"
    assert first["summary"]["cohort"] == "t2d-enriched"
    assert all("Type 2 diabetes mellitus" in row["conditions"] for row in first["ranked"])
    assert all("Type 1 diabetes mellitus" not in row["conditions"] for row in first["ranked"])
    assert [row["id"] for row in first["ranked"]] == [row["id"] for row in second["ranked"]]
    assert all(row["pk"]["hepatic_exposure_ratio"] >= 0 for row in first["ranked"])
    assert first["audit"]["outputs"] == {"outcome": "COMPLETED"}
    assert "content_sha256" in first["audit"]["inputs"]
    assert first["audit"]["result_sha256"] == second["audit"]["result_sha256"]


@pytest.mark.parametrize(
    ("field", "value"),
    [("indication", "hypertension"), ("cohort", "general-population"), ("assay", "qt")],
)
def test_screen_rejects_unsupported_context_of_use(field: str, value: str):
    from livemorebio.sdk import Platform

    request = {
        "indication": "type-2-diabetes",
        "cohort": "t2d-enriched",
        "assay": "ogtt",
        field: value,
    }
    with pytest.raises(ValueError, match="unsupported screen context"):
        Platform().screen("metformin", n=2, seed=1, **request)


def test_reported_metformin_pk_is_the_pk_used_for_response(monkeypatch):
    from livemorebio.engines import hepatic_pk, pharmacology
    from livemorebio.engines.metabolic.glucose_insulin import T2D

    pk = {
        "dose_mg": 1000.0,
        "hepatic_exposure_ratio": 0.25,
        "exposure_ratio": 0.5,
        "auc_mg_h_L": 4.0,
        "cmax_mg_L": 1.0,
        "t_half_h": 3.0,
        "individualization": {
            "oct1_lof_alleles": 1,
            "oct1_transport": 0.6,
            "renal_factor": 0.8,
        },
    }
    monkeypatch.setattr(hepatic_pk, "pk_profile", lambda *args, **kwargs: pk)

    treated, why = pharmacology.metformin(T2D, human=None, dose=1.0)

    assert why["pk"]["hepatic_exposure_ratio"] == pk["hepatic_exposure_ratio"]
    assert treated.Si > T2D.Si
    assert treated.Si < T2D.Si * 1.2


def test_cendos_metformin_assay_surfaces_the_same_pk_path(monkeypatch):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    from livemorebio.cendos.service import app

    response = TestClient(app).post(
        "/assay/ogtt",
        headers=_auth(),
        json={"drug": "metformin", "dose": 1.0, "grams": 75.0},
    )

    assert response.status_code == 200
    result = response.json()
    assert result["pk"] == result["treatment"]["pk"]
    assert result["pk"]["hepatic_exposure_ratio"] >= 0


def test_mutation_routes_require_configured_bearer_token(monkeypatch, tmp_path):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    monkeypatch.setenv("LIVEMORE_SCREEN_RUN_DIR", str(tmp_path))
    from livemorebio.aegle.server import app

    client = TestClient(app)
    response = client.post(
        "/api/screen",
        json={"compound": "metformin", "n": 2, "seed": 4},
    )
    assert response.status_code == 401
    assert response.json() == {"error": "authentication required"}


def test_evidence_export_is_not_a_mutating_get(monkeypatch, tmp_path):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    from livemorebio.aegle.server import app
    from livemorebio.aegle import evidence_api
    from livemorebio.evidence import EvidenceService, EvidenceStore

    service = EvidenceService(EvidenceStore(tmp_path / "evidence.sqlite", audit_signing_key=b"t" * 32))
    monkeypatch.setattr(evidence_api, "service", lambda: service)
    try:
        client = TestClient(app)
        assert client.get("/api/evidence/missing/export").status_code == 405
        assert client.post("/api/evidence/missing/export").status_code == 401
        response = client.post("/api/evidence/missing/export", headers=_auth())
        assert response.status_code == 404
        assert response.json() == {"error": "Evidence package not found"}
        assert service.list(evidence_api.TENANT) == ()
    finally:
        service.close()


@pytest.mark.parametrize("error,status,code", [
    (NotFoundError("private technical package identity"), 404, None),
    (KeyError("private technical package identity"), 404, None),
    (ValueError("private technical draft details"), 409, "EVIDENCE_REVIEW_REQUIRED"),
    (IntegrityError("private technical integrity details"), 503, "EVIDENCE_EXPORT_UNAVAILABLE"),
    (OSError("private technical storage path"), 503, "EVIDENCE_EXPORT_UNAVAILABLE"),
])
def test_evidence_export_classifies_failure_without_exposing_details(monkeypatch, error, status, code):
    from livemorebio.aegle import evidence_api, server

    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    export = Mock(side_effect=error)
    monkeypatch.setattr(evidence_api, "export_zip", export)
    response = TestClient(server.app).post("/api/evidence/technical-fixture/export", headers=_auth())
    assert response.status_code == status
    assert response.json().get("code") == code
    assert "private technical" not in response.text
    assert response.headers["Cache-Control"] == "no-store"
    export.assert_called_once_with("technical-fixture")


def test_evidence_export_names_deliberate_signing_initialization(monkeypatch):
    from livemorebio.aegle import evidence_api, server
    from livemorebio.evidence.errors import SigningIdentityUninitializedError

    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    error = SigningIdentityUninitializedError()
    export = Mock(side_effect=error)
    monkeypatch.setattr(evidence_api, "export_zip", export)
    response = TestClient(server.app).post(
        "/api/evidence/technical-fixture/export", headers=_auth(),
    )
    assert response.status_code == 503
    assert response.json() == {
        "error": str(error), "code": "EVIDENCE_SIGNING_IDENTITY_UNINITIALIZED",
    }
    assert "livemore evidence signing init" in response.json()["error"]
    assert response.headers["Cache-Control"] == "no-store"
    export.assert_called_once_with("technical-fixture")


def test_evidence_archive_download_is_not_cacheable(monkeypatch, tmp_path):
    from livemorebio.aegle import evidence_api, server

    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    archive = tmp_path / "transport-fixture.zip"
    archive.write_bytes(b"transport fixture only, not a scientific archive")
    monkeypatch.setattr(evidence_api, "export_zip", lambda _: str(archive))
    response = TestClient(server.app).post("/api/evidence/technical-fixture/export", headers=_auth())
    assert response.status_code == 200
    assert response.content == archive.read_bytes()
    assert response.headers["Cache-Control"] == "no-store"


def test_phi_like_audit_and_evidence_reads_require_operator_auth(monkeypatch):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    from livemorebio.aegle.server import app

    client = TestClient(app)
    for path in ("/api/audit", "/api/audit/missing", "/api/evidence", "/api/evidence/missing"):
        response = client.get(path)
        assert response.status_code == 401, (path, response.text)


def test_cli_creates_persistent_owner_only_mutation_token(monkeypatch, tmp_path):
    from livemorebio import cli

    token_file = tmp_path / "api-token"
    monkeypatch.delenv("LIVEMORE_API_TOKEN", raising=False)
    monkeypatch.setattr(cli.R, "REG_DIR", str(tmp_path))
    monkeypatch.setattr(cli, "TOKEN_FILE", str(token_file))

    first = cli.ensure_api_token()
    monkeypatch.delenv("LIVEMORE_API_TOKEN")
    second = cli.ensure_api_token()

    assert first == second
    assert len(first) >= 32
    assert stat.S_IMODE(token_file.stat().st_mode) == 0o600


def test_cli_waits_for_started_services_to_report_healthy(monkeypatch):
    from livemorebio import cli

    probes = {8851: 0, 8850: 0}

    def delayed_health(port):
        probes[port] += 1
        return {"ok": True} if probes[port] >= (2 if port == 8851 else 4) else None

    monkeypatch.setattr(cli, "_health", delayed_health)
    monkeypatch.setattr(cli.time, "sleep", lambda _seconds: None)

    assert cli._wait_for_services(["LIFE", "Aegle"], timeout=1.0) == []
    assert probes[8850] >= 4


def test_cli_waits_for_stopped_service_ports_to_close(monkeypatch):
    from livemorebio import cli
    from livemorebio import stack_readiness
    from urllib.parse import urlsplit

    probes = {8850: 0}

    def delayed_shutdown(url):
        port = urlsplit(url).port
        probes[port] += 1
        return probes[port] < 4

    monkeypatch.setattr(stack_readiness, "listener_reachable", delayed_shutdown)
    monkeypatch.setattr(cli.time, "sleep", lambda _seconds: None)

    assert cli._wait_for_stopped_services(["Aegle"], timeout=1.0) == []
    assert probes[8850] >= 4


def test_screen_reports_are_durable_and_run_scoped(monkeypatch, tmp_path):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    monkeypatch.setenv("LIVEMORE_SCREEN_RUN_DIR", str(tmp_path))
    from livemorebio.aegle.server import app
    from livemorebio.aegle import screen_runs

    client = TestClient(app)
    response = client.post(
        "/api/screen",
        headers=_auth(),
        json={
            "compound": "metformin",
            "mode": "metformin",
            "n": 3,
            "seed": 9,
            "indication": "type-2-diabetes",
            "cohort": "t2d-enriched",
            "assay": "ogtt",
        },
    )
    assert response.status_code == 200, response.text
    result = response.json()
    run_id = result["run_id"]

    persisted = screen_runs.load(run_id)
    assert persisted["result"]["audit"]["result_sha256"] == result["audit"]["result_sha256"]
    report = client.get(f"/api/screen/{run_id}/report.md", headers=_auth())
    audit = client.get(f"/api/screen/{run_id}/report.audit.json", headers=_auth())
    assert report.status_code == 200
    assert "local reproducibility" in report.text.lower()
    assert audit.status_code == 200
    assert audit.json()["result_sha256"] == result["audit"]["result_sha256"]
    assert client.get("/api/screen/not-a-run/report.md", headers=_auth()).status_code == 404


def test_restricted_adapters_never_probe_network(monkeypatch):
    from livemorebio import adapters

    calls: list[str] = []
    monkeypatch.setattr(adapters, "_probe_url", lambda url, timeout: calls.append(url) or "ready")

    statuses = {row["id"]: row for row in adapters.statuses(probe=True)}

    assert statuses["chembl"]["status"] == "ready"
    assert statuses["kegg"]["status"] == "blocked"
    assert statuses["genecards"]["status"] == "blocked"
    assert all("kegg" not in url.lower() and "genecards" not in url.lower() for url in calls)


def test_enabled_adapter_health_probes_run_concurrently(monkeypatch):
    from livemorebio import adapters

    lock = threading.Lock()
    active = 0
    maximum_active = 0

    def observed_probe(_url, _timeout):
        nonlocal active, maximum_active
        with lock:
            active += 1
            maximum_active = max(maximum_active, active)
        time.sleep(0.02)
        with lock:
            active -= 1
        return "ready"

    monkeypatch.setattr(adapters, "_probe_url", observed_probe)
    statuses = adapters.statuses(probe=True)

    assert maximum_active > 1
    assert all(row["status"] == "ready" for row in statuses if row["enabled"])


def test_adapter_endpoint_reports_capability_and_license_state(monkeypatch):
    monkeypatch.setenv("LIVEMORE_API_TOKEN", TOKEN)
    from livemorebio.aegle.server import app

    response = TestClient(app).get("/api/adapters", headers=_auth())
    assert response.status_code == 200
    body = response.json()
    assert body["schema"] == "livemore.scientific-adapters.v1"
    assert any(row["id"] == "reactome" and row["enabled"] for row in body["adapters"])
    assert any(row["id"] == "kegg" and not row["enabled"] for row in body["adapters"])


def test_measured_demo_feed_does_not_claim_person_calibration():
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.life_patch.stream import ExternalSeriesStream, SAMPLE_CGM_DIABETIC

    packets = ExternalSeriesStream(
        "demo-subject",
        glucose=SAMPLE_CGM_DIABETIC,
        hr=[(t, 88) for t, _ in SAMPLE_CGM_DIABETIC],
        source="demo-cgm",
    ).packets()
    state = AegleTwin("healthy").ingest_patch(packets)

    assert "calibrated" not in state["profile"].lower()
    assert "measured" not in state["profile"].lower()
    assert state["provenance"]["glucose"] == "synthetic-model"
    assert state["observations"]["glucose_mgdl"]["provenance"] == "technical_fixture"
    assert state["observations"]["glucose_mgdl"]["value"] == SAMPLE_CGM_DIABETIC[-1][1]
    assert state["capability"]["maturity"]["person_calibrated"] is False
