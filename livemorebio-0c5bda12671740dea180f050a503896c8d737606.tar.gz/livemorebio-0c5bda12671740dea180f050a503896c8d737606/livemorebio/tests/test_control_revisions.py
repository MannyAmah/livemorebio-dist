"""Lifecycle intent is stable across samples, never across intervening controls."""
import threading

import pytest

from livemorebio.aegle.execution_contract import ExecutionError
from livemorebio.tests.test_continuous_execution import manager, captured_source, TechnicalAdapter
from livemorebio.tests.test_virtual_execution import setup
from livemorebio.tests.test_virtual_session_store import binding


def running(tmp_path):
    engine = manager(tmp_path)
    prepared = engine.prepare(captured_source(), {"end_native": 10., "frame_period_s": 1., "time_scale": 60.}, "control")
    state = engine.start(prepared["execution_id"], expected_revision=prepared["revision"], expected_source_generation="generation-a")
    return engine, state


def test_engine_control_survives_frame_progress_but_legacy_cas_still_conflicts(tmp_path):
    engine, displayed = running(tmp_path)
    try:
        for _ in range(3):
            assert engine.advance_once(displayed["execution_id"])
        current = engine.status(displayed["execution_id"])
        assert current["revision"] > displayed["revision"]
        assert current["control_revision"] == displayed["control_revision"]
        with pytest.raises(ExecutionError):
            engine.pause(displayed["execution_id"], expected_revision=displayed["revision"], expected_source_generation="generation-a")
        paused = engine.pause(displayed["execution_id"], expected_control_revision=displayed["control_revision"], expected_source_generation="generation-a")
        assert paused["state"] == "paused" and paused["control_revision"] > displayed["control_revision"]
        assert engine.advance_once(displayed["execution_id"]) is None
        assert engine.status(displayed["execution_id"])["latest_frame"] == 3
    finally:
        engine.close()


def test_engine_aba_source_change_and_wrong_owner_never_reuse_control_intent(tmp_path):
    engine, displayed = running(tmp_path)
    other = manager(tmp_path)
    try:
        token = displayed["control_revision"]
        with pytest.raises(ExecutionError) as owned_error:
            other.pause(displayed["execution_id"], expected_control_revision=token, expected_source_generation="generation-a")
        assert owned_error.value.code == "EXECUTION_OWNED"
        paused = engine.pause(displayed["execution_id"], expected_control_revision=token, expected_source_generation="generation-a")
        current = engine.resume(displayed["execution_id"], expected_control_revision=paused["control_revision"], expected_source_generation="generation-a")
        assert current["state"] == "running" and current["control_revision"] > token
        with pytest.raises(ExecutionError):
            engine.stop(displayed["execution_id"], expected_control_revision=token, expected_source_generation="generation-a")
        engine.invalidate_source("generation-a", "technical-source-change")
        invalid = engine.status(displayed["execution_id"])
        assert invalid["control_revision"] > current["control_revision"]
        with pytest.raises(ExecutionError):
            engine.resume(displayed["execution_id"], expected_control_revision=invalid["control_revision"], expected_source_generation="generation-b")
        assert engine.stop(displayed["execution_id"], expected_control_revision=invalid["control_revision"], expected_source_generation="generation-a")["state"] == "stopped"
    finally:
        other.close()
        engine.close()


@pytest.mark.parametrize("arguments", [{}, {"expected_revision": 1, "expected_control_revision": 1},
    {"expected_control_revision": True}, {"expected_control_revision": 1.0}, {"expected_control_revision": "1"},
    {"expected_control_revision": 0}, {"expected_revision": False}])
def test_exactly_one_strict_precondition_before_any_control_mutation(tmp_path, arguments):
    engine, displayed = running(tmp_path)
    try:
        before = engine.store.get(displayed["execution_id"])
        with pytest.raises(ExecutionError):
            engine.pause(displayed["execution_id"], expected_source_generation="generation-a", **arguments)
        assert engine.store.get(displayed["execution_id"]) == before
    finally:
        engine.close()


def test_late_native_result_cannot_commit_after_control_pause(tmp_path):
    engine, displayed = running(tmp_path)
    TechnicalAdapter.entered, TechnicalAdapter.release = threading.Event(), threading.Event()
    results = []
    worker = threading.Thread(target=lambda: results.append(engine.advance_once(displayed["execution_id"])))
    try:
        worker.start()
        assert TechnicalAdapter.entered.wait(2)
        paused = engine.pause(displayed["execution_id"], expected_control_revision=displayed["control_revision"], expected_source_generation="generation-a")
        TechnicalAdapter.release.set()
        worker.join(3)
        assert not worker.is_alive() and results == [None]
        current = engine.status(displayed["execution_id"])
        assert current["state"] == "paused" and current["control_revision"] == paused["control_revision"]
        assert current["latest_frame"] == 0
    finally:
        TechnicalAdapter.release.set()
        worker.join(3)
        TechnicalAdapter.entered = TechnicalAdapter.release = None
        engine.close()


def test_life_displayed_control_survives_idle_and_ack_writes(tmp_path, monkeypatch):
    owner, source, frame, displayed, received, _, _ = setup(tmp_path, monkeypatch)
    try:
        owner.tick(displayed["session_id"])
        source.publish(frame)
        owner.tick(displayed["session_id"])
        owner.tick(displayed["session_id"])
        current = owner.status(displayed["session_id"])
        assert current["control_revision"] == displayed["control_revision"]
        assert current["revision"] > displayed["revision"] and current["last_forwarded"] == 1
        with pytest.raises(ExecutionError):
            owner.pause(displayed["session_id"], expected_revision=displayed["revision"])
        paused = owner.pause(displayed["session_id"], expected_control_revision=displayed["control_revision"])
        assert paused["state"] == "paused" and source.current["state"] == "paused"
        owner.tick(displayed["session_id"])
        assert len(received) == 1 and owner.status(displayed["session_id"])["last_forwarded"] == 1
    finally:
        owner.close()


@pytest.mark.parametrize("callback_fails", [False, True])
def test_late_life_callback_cannot_replace_successful_pause_or_touch_renewal(tmp_path, monkeypatch, callback_fails):
    entered, release = threading.Event(), threading.Event()
    def callback(receipt):
        entered.set()
        assert release.wait(3)
        if callback_fails:
            raise OSError("PRIVATE TECHNICAL FAILURE")
        return {"aegle": {"status": "delivered"}}
    owner, source, frame, record, _, _, _ = setup(tmp_path, monkeypatch, callback)
    source.publish(frame)
    worker = threading.Thread(target=lambda: owner.tick(record["session_id"]))
    try:
        worker.start()
        assert entered.wait(2)
        state = owner.status(record["session_id"])
        # Legacy guard also proves the old catch-path defect independently of the new field.
        paused = owner.pause(record["session_id"], expected_revision=state["revision"])
        pauses = source.pauses
        durable = owner.store.get(record["session_id"])
        release.set()
        worker.join(3)
        assert not worker.is_alive()
        assert owner.status(record["session_id"])["state"] == "paused"
        assert owner.store.get(record["session_id"]) == durable
        assert source.pauses == pauses and source.renewals == 0
        assert paused["has_pending"] and durable["receipt"] is not None
    finally:
        release.set()
        worker.join(3)
        owner.close()


def test_resume_admission_advances_control_epoch_and_pause_cancels_old_failure(tmp_path, monkeypatch):
    owner, source, _, record, _, _, _ = setup(tmp_path, monkeypatch)
    paused = owner.pause(record["session_id"], expected_revision=record["revision"])
    entered, release = threading.Event(), threading.Event()
    original = source.status
    once = [True]
    def status(*args):
        result = original(*args)
        if once[0]:
            once[0] = False
            entered.set()
            assert release.wait(3)
            raise OSError("PRIVATE OLD RECOVERY FAILURE")
        return result
    monkeypatch.setattr(source, "status", status)
    failures = []
    def resume():
        try:
            owner.resume(record["session_id"], expected_control_revision=paused["control_revision"])
        except ExecutionError as error:
            failures.append(error.code)
    worker = threading.Thread(target=resume)
    try:
        worker.start()
        assert entered.wait(2)
        in_progress = owner.status(record["session_id"])
        assert in_progress["state"] == "paused" and in_progress["control_revision"] > paused["control_revision"]
        with pytest.raises(ExecutionError):
            owner.pause(record["session_id"], expected_control_revision=paused["control_revision"])
        with pytest.raises(ExecutionError):
            owner.resume(record["session_id"], expected_control_revision=in_progress["control_revision"])
        assert owner.status(record["session_id"])["control_revision"] == in_progress["control_revision"]
        canceled = owner.pause(record["session_id"], expected_control_revision=in_progress["control_revision"])
        assert canceled["control_revision"] > in_progress["control_revision"]
        release.set()
        worker.join(3)
        assert not worker.is_alive() and len(failures) == 1
        current = owner.status(record["session_id"])
        assert current["state"] == "paused" and current["control_revision"] == canceled["control_revision"]
        assert source.renewals == 0
    finally:
        release.set()
        worker.join(3)
        owner.close()


def test_remote_pause_finishes_before_new_life_resume_can_be_admitted(tmp_path, monkeypatch):
    owner, source, frame, record, _, _, _ = setup(tmp_path, monkeypatch)
    source.publish(frame)
    owner.tick(record["session_id"])
    entered, release, attempting_resume, resumed = (threading.Event() for _ in range(4))
    order, errors = [], []
    original_pause = source.pause

    def blocked_pause(*args, **kwargs):
        # This is entered after the last local epoch check, not during status I/O.
        entered.set()
        assert release.wait(3)
        result = original_pause(*args, **kwargs)
        order.append("producer_paused")
        return result

    monkeypatch.setattr(source, "pause", blocked_pause)

    def pause():
        try:
            owner.pause(record["session_id"], expected_control_revision=record["control_revision"])
        except Exception as error:
            errors.append(error)

    def resume(control_revision):
        attempting_resume.set()
        try:
            owner.resume(record["session_id"], expected_control_revision=control_revision)
            order.append("consumer_resumed")
            resumed.set()
        except Exception as error:
            errors.append(error)

    pausing = threading.Thread(target=pause)
    recovering = None
    try:
        pausing.start()
        assert entered.wait(2)
        # Direct durable read avoids asking status() to acquire the control lock.
        accepted = owner.store.get(record["session_id"])
        assert accepted["state"] == "paused"
        recovering = threading.Thread(target=resume, args=(accepted["control_revision"],))
        recovering.start()
        assert attempting_resume.wait(2)
        assert not resumed.wait(.2), "new consumer intent overtook an issued producer pause"
        assert source.renewals == 0
        release.set()
        pausing.join(3)
        recovering.join(3)
        assert not pausing.is_alive() and not recovering.is_alive() and not errors
        assert order == ["producer_paused", "consumer_resumed"]
        assert owner.status(record["session_id"])["state"] == "waiting_for_engine"
        assert source.current["state"] == "paused" and source.pauses == 1 and source.renewals == 1
    finally:
        release.set()
        pausing.join(3)
        if recovering is not None:
            recovering.join(3)
        owner.close()


@pytest.mark.parametrize("action", ["pause", "stop"])
@pytest.mark.parametrize("already_owned", [False, True])
def test_failed_life_control_write_releases_only_new_owner(tmp_path, monkeypatch, action, already_owned):
    owner, source, _, record, _, _, _ = setup(tmp_path, monkeypatch)
    session_id = record["session_id"]
    if not already_owned:
        owner._release(session_id)
    before = owner.store.get(session_id)

    def failed_update(*args, **kwargs):
        assert kwargs["control_event"] is True
        raise ExecutionError("EXECUTION_STORAGE")

    try:
        with monkeypatch.context() as patch:
            patch.setattr(owner.store, "update", failed_update)
            with pytest.raises(ExecutionError) as failure:
                getattr(owner, action)(session_id, expected_control_revision=before["control_revision"])
            assert failure.value.code == "EXECUTION_STORAGE"
        assert owner.store.get(session_id) == before
        assert (session_id in owner._owners) is already_owned
        assert session_id not in owner._renew_due
        assert source.pauses == 0 and source.renewals == 0
        if already_owned:
            with pytest.raises(ExecutionError) as owned:
                owner.store.acquire_owner(session_id)
            assert owned.value.code == "EXECUTION_OWNED"
        else:
            claimed = owner.store.acquire_owner(session_id)
            owner.store.release_owner(claimed)
    finally:
        owner.close()


@pytest.mark.parametrize("kind", ["execution", "life"])
def test_old_encrypted_records_project_then_persist_control_revision_without_rewriting_history(tmp_path, kind):
    from livemorebio.aegle.execution_store import ExecutionStore
    from livemorebio.life_patch.virtual_session_store import VirtualSessionStore
    store = (ExecutionStore if kind == "execution" else VirtualSessionStore)(tmp_path / "private.sqlite3", key=b"z" * 32)
    record = (store.create(captured_source(), {"end_native": 2., "frame_period_s": 1., "time_scale": 60.}, idempotency_key="legacy")
              if kind == "execution" else store.create(binding(), idempotency_key="legacy"))
    ident = record["execution_id" if kind == "execution" else "session_id"]
    table, aad = ("executions", ident) if kind == "execution" else ("virtual_sessions", "virtual-session:" + ident)
    record.pop("control_revision", None)
    record["revision"] = 7
    payload = store._encrypt(record, aad)
    with store._connection() as connection:
        extra = ",used_bytes=?" if kind == "execution" else ""
        connection.execute(f"UPDATE {table} SET payload=?,revision=?{extra} WHERE id=?",
                           (payload, 7, len(payload), ident) if kind == "execution" else (payload, 7, ident))
    projected = store.get(ident)
    assert projected["control_revision"] == 7
    with store._connection() as connection:
        assert connection.execute(f"SELECT payload FROM {table} WHERE id=?", (ident,)).fetchone()[0] == payload
    same = store.update(ident, expected_revision=7, changes={"state": record["state"]})
    assert same["revision"] == 8 and same["control_revision"] == 7
    transitioned = store.update(ident, expected_revision=8, changes={"state": "paused"})
    assert transitioned["control_revision"] == 8
    with pytest.raises(ExecutionError):
        store.update(ident, expected_revision=8, changes={"state": "stopped"})


@pytest.mark.parametrize("kind", ["execution", "life"])
def test_control_events_are_internal_strict_and_noop_metadata_does_not_bump(tmp_path, kind):
    from livemorebio.aegle.execution_store import ExecutionStore
    from livemorebio.life_patch.virtual_session_store import VirtualSessionStore
    store = (ExecutionStore if kind == "execution" else VirtualSessionStore)(tmp_path / "private.sqlite3", key=b"z" * 32)
    record = (store.create(captured_source(), {"end_native": 2., "frame_period_s": 1., "time_scale": 60.}, idempotency_key="one")
              if kind == "execution" else store.create(binding(), idempotency_key="one"))
    ident = record["execution_id" if kind == "execution" else "session_id"]
    assert record["control_revision"] == 1
    for bad in (1, "true", None):
        with pytest.raises(ExecutionError):
            store.update(ident, expected_revision=1, changes={"state": record["state"]}, control_event=bad)
    for field in ("control_revision", "control_event"):
        with pytest.raises(ExecutionError):
            store.update(ident, expected_revision=1, changes={field: 2})
    unchanged = store.update(ident, expected_revision=1, changes={"state": record["state"]})
    assert unchanged["control_revision"] == 1
    event = store.update(ident, expected_revision=2, changes={"state": record["state"]}, control_event=True)
    assert event["control_revision"] == 2


def test_source_pause_client_sends_exact_control_guard_and_rejects_ambiguity_before_io():
    from livemorebio.life_patch.execution_source import ExecutionSourceClient
    calls = []
    client = ExecutionSourceClient("http://127.0.0.1:8910", "technical-token", "a" * 64,
                                   expected_role="aegle")
    client._request = lambda *args: calls.append(args) or {}
    client.pause("b" * 32, expected_control_revision=5, expected_source_generation="generation-a")
    assert calls[0][2] == {"expected_control_revision": 5, "expected_source_generation": "generation-a"}
    for options in ({}, {"expected_control_revision": True}, {"expected_control_revision": 5, "expected_revision": 6}):
        with pytest.raises(ExecutionError):
            client.pause("b" * 32, expected_source_generation="generation-a", **options)
    assert len(calls) == 1


def test_completion_and_restart_invalidate_displayed_engine_control(tmp_path):
    engine, displayed = running(tmp_path)
    try:
        for _ in range(10):
            engine.advance_once(displayed["execution_id"])
        complete = engine.status(displayed["execution_id"])
        assert complete["state"] == "completed" and complete["control_revision"] > displayed["control_revision"]
        with pytest.raises(ExecutionError):
            engine.pause(displayed["execution_id"], expected_control_revision=displayed["control_revision"], expected_source_generation="generation-a")
    finally:
        engine.close()
    first, running_state = running(tmp_path / "restart")
    first._release(running_state["execution_id"])
    second = manager(tmp_path / "restart")
    try:
        interrupted = second.status(running_state["execution_id"])
        assert interrupted["state"] == "interrupted" and interrupted["control_revision"] > running_state["control_revision"]
        with pytest.raises(ExecutionError):
            second.stop(running_state["execution_id"], expected_control_revision=running_state["control_revision"], expected_source_generation="generation-a")
    finally:
        first.close()
        second.close()


def test_lease_renewal_keeps_control_but_expiry_invalidates_it(tmp_path):
    engine = manager(tmp_path)
    clock = [100.]
    engine._clock = lambda: clock[0]
    prepared = engine.prepare(captured_source(), {"end_native": 10., "frame_period_s": 1., "time_scale": 60.}, "lease")
    try:
        bound = engine.bind_consumer(prepared["execution_id"], "a" * 32, prepared["source_snapshot_hash"],
                                     expected_revision=prepared["revision"], expected_source_generation="generation-a")
        assert bound["control_revision"] > prepared["control_revision"]
        active = engine.start(prepared["execution_id"], expected_control_revision=bound["control_revision"], expected_source_generation="generation-a")
        renewed = engine.renew_consumer(prepared["execution_id"], "a" * 32, prepared["source_snapshot_hash"], expected_source_generation="generation-a")
        assert renewed["revision"] == active["revision"] and renewed["control_revision"] == active["control_revision"]
        clock[0] += 31
        expired = engine.status(prepared["execution_id"])
        assert expired["state"] == "paused" and expired["control_revision"] > active["control_revision"]
        with pytest.raises(ExecutionError):
            engine.resume(prepared["execution_id"], expected_control_revision=active["control_revision"], expected_source_generation="generation-a")
    finally:
        engine.close()


@pytest.mark.parametrize("arguments", [{}, {"expected_revision": 1, "expected_control_revision": 1},
    {"expected_control_revision": True}, {"expected_control_revision": 1.0}, {"expected_control_revision": "1"},
    {"expected_control_revision": 0}])
def test_life_requires_one_strict_control_guard_before_io(tmp_path, monkeypatch, arguments):
    owner, source, _, record, _, _, _ = setup(tmp_path, monkeypatch)
    before = owner.store.get(record["session_id"])
    try:
        with pytest.raises(ExecutionError):
            owner.pause(record["session_id"], **arguments)
        assert owner.store.get(record["session_id"]) == before
        assert source.pauses == 0 and source.renewals == 0
    finally:
        owner.close()


def test_life_pause_uses_producer_control_guard_and_aba_rejects_old_intent(tmp_path, monkeypatch):
    owner, source, frame, record, _, _, _ = setup(tmp_path, monkeypatch)
    source.publish(frame)
    source.current["control_revision"] = 2
    owner.tick(record["session_id"])
    original_pause, calls = source.pause, []
    def pause(execution_id, **kwargs):
        calls.append(kwargs)
        return original_pause(execution_id, **kwargs)
    monkeypatch.setattr(source, "pause", pause)
    try:
        paused = owner.pause(record["session_id"], expected_control_revision=record["control_revision"])
        assert calls == [{"expected_control_revision": 2, "expected_source_generation": source.current["source_generation"]}]
        resumed = owner.resume(record["session_id"], expected_control_revision=paused["control_revision"])
        assert resumed["state"] == "waiting_for_engine" and resumed["control_revision"] > record["control_revision"]
        with pytest.raises(ExecutionError):
            owner.stop(record["session_id"], expected_control_revision=record["control_revision"])
        stopped = owner.stop(record["session_id"], expected_control_revision=resumed["control_revision"])
        assert stopped["state"] == "stopped"
        with pytest.raises(ExecutionError):
            owner.resume(record["session_id"], expected_control_revision=stopped["control_revision"])
    finally:
        owner.close()
