"""Operation receipts from authored response fixtures; no live service or model."""
import json

import pytest

from livemorebio.tests.test_selection_reconciliation_ui import run_node


ACTION_SETUP = """
const action=ACTION;
const intent={action,twinId:subject.twin_id,expectedVersion:2};
const selected={schema:'livemore.twin-record.v1',...subject,
 source_class:action==='activate'?'SYNTHETIC':'REAL_HUMAN',
 ...(action==='activate'?{}:{selection_mode:'observations_only',model_availability:{...availability}})};
"""


@pytest.mark.parametrize("action", ["activate", "select-observations"])
@pytest.mark.parametrize("mutation", [
    "value={}", "value.schema='wrong'", "value.twin_id='twin-other'",
    "value.version=2", "value.version=4", "value.version=true",
    "value.lifecycle='DATA_ADMITTED'", "value.source_class='PUBLIC_REFERENCE'",
    "value.subject_id=null", "value.display_label='x'.repeat(81)",
])
def test_malformed_success_keeps_unconfirmed_receipt_and_fresh_identity(action, mutation):
    run_node(ACTION_SETUP.replace("ACTION", json.dumps(action)) + f"""
let value={{...selected}};{mutation};
const c=fixture();admit(c,listing('CONFIRMED'));
await c.runSelection(signal=>selectionRequest('/api/twins/'+intent.twinId+'/'+action,{{body:{{expected_version:2}},signal,fetcher:async()=>{{posts++;return response(JSON.stringify(value))}}}}),intent);
assert.equal(posts,1);assert.equal(reads,1);assert.equal(c.snapshot().outcome,'ACK_UNCONFIRMED');
assert.equal(c.snapshot().active.twin_id,subject.twin_id);assert(c.canSelect());
assert.match(root.querySelector('#selection-reconciliation-status').textContent,/acknowledgment unconfirmed/);
assert.equal(c.snapshot().requestId,UUID);c.dispose();
""")


@pytest.mark.parametrize("mutation", [
    "delete value.model_availability", "value.source_class='SYNTHETIC'",
    "delete value.selection_mode", "value.selection_mode='model'",
    "value.model_availability.twin_id='twin-other'",
    "value.model_availability.twin_version=2",
    "value.model_availability.preparation_available=true",
    "value.model_availability.source_generation='x'.repeat(201)",
    "value.model_availability.reason_code='invented'",
    "Object.assign(value.model_availability,{state:'READY',reason_code:null,selection_mode:'model',preparation_available:true})",
])
def test_observation_ack_requires_actual_unavailable_context(mutation):
    run_node(ACTION_SETUP.replace("ACTION", "'select-observations'") + f"""
const value=structuredClone(selected);{mutation};const c=fixture();admit(c,listing('CONFIRMED'));
await c.runSelection(async()=>{{posts++;return{{payload:value,requestId:UUID}}}},intent);
assert.equal(c.snapshot().outcome,'ACK_UNCONFIRMED');assert.equal(posts,1);assert.equal(reads,1);c.dispose();
""")


@pytest.mark.parametrize("header", [None, "a" * 32, "PRIVATE_SENTINEL"])
def test_observation_ack_requires_current_uuid(header):
    run_node(ACTION_SETUP.replace("ACTION", "'select-observations'") + f"""
const c=fixture();admit(c,listing('CONFIRMED'));
await c.runSelection(signal=>selectionRequest('/api/twins/'+intent.twinId+'/'+action,{{body:{{expected_version:2}},signal,fetcher:async()=>{{posts++;return new Response(JSON.stringify(selected),{{headers:{json.dumps({} if header is None else {'X-Request-ID': header})}}})}}}}),intent);
assert.equal(c.snapshot().outcome,'ACK_UNCONFIRMED');assert.equal(c.snapshot().requestId,null);
assert.equal(posts,1);assert.equal(reads,1);assert(!root.querySelector('#selection-reconciliation-status').textContent.includes('PRIVATE'));c.dispose();
""")


@pytest.mark.parametrize("status", [201, 202])
@pytest.mark.parametrize("action", ["activate", "select-observations"])
def test_action_ack_requires_exact_success_status(action, status):
    run_node(ACTION_SETUP.replace("ACTION", json.dumps(action)) + f"""
const c=fixture();admit(c,listing('CONFIRMED'));
await c.runSelection(signal=>selectionRequest('/api/twins/'+intent.twinId+'/'+action,{{body:{{expected_version:2}},signal,fetcher:async()=>{{posts++;return response(JSON.stringify(selected),{status})}}}}),intent);
assert.equal(c.snapshot().outcome,'ACK_UNCONFIRMED');assert.equal(posts,1);assert.equal(reads,1);c.dispose();
""")


@pytest.mark.parametrize("header", [None, "563e4d61-9872-4fe3-820b-a18903a522a0"])
def test_legacy_activation_validates_record_without_inventing_missing_uuid(header):
    run_node(ACTION_SETUP.replace("ACTION", "'activate'") + f"""
const c=fixture();admit(c,listing('CONFIRMED'));
await c.runSelection(signal=>selectionRequest('/api/twins/'+intent.twinId+'/'+action,{{body:{{expected_version:2}},signal,fetcher:async()=>{{posts++;return new Response(JSON.stringify(selected),{{headers:{json.dumps({} if header is None else {'X-Request-ID': header})}}})}}}}),intent);
assert.equal(c.snapshot().outcome,'ACKNOWLEDGED');assert.equal(c.snapshot().requestId,{json.dumps(header)});
assert.equal(posts,1);assert.equal(reads,1);c.dispose();
""")


@pytest.mark.parametrize("mutation", [
    "selected.selection_mode='observations_only'",
    "selected.model_availability={...availability}",
])
def test_activation_rejects_explicit_contradictory_mode(mutation):
    run_node(ACTION_SETUP.replace("ACTION", "'activate'") + f"""
{mutation};const c=fixture();admit(c,listing('CONFIRMED'));
await c.runSelection(async()=>{{posts++;return{{payload:selected,requestId:null}}}},intent);
assert.equal(c.snapshot().outcome,'ACK_UNCONFIRMED');assert.equal(posts,1);assert.equal(reads,1);c.dispose();
""")


def test_activation_rejects_present_malformed_header():
    run_node(ACTION_SETUP.replace("ACTION", "'activate'") + """
const c=fixture();admit(c,listing('CONFIRMED'));
await c.runSelection(signal=>selectionRequest('/api/twins/'+intent.twinId+'/'+action,{body:{expected_version:2},signal,fetcher:async()=>{posts++;return response(JSON.stringify(selected),200,'PRIVATE')}}),intent);
assert.equal(c.snapshot().outcome,'ACK_UNCONFIRMED');assert.equal(c.snapshot().requestId,null);assert.equal(posts,1);assert.equal(reads,1);c.dispose();
""")


@pytest.mark.parametrize("bad", [None, {}, {"action": "invented", "twinId": "twin-technical", "expectedVersion": 2},
    {"action": "activate", "twinId": "twin-technical", "expectedVersion": True},
    {"action": "activate", "twinId": "twin-technical", "expectedVersion": 9007199254740991}])
def test_invalid_intent_never_dispatches_or_invalidates_selection(bad):
    run_node(f"""
const c=fixture();admit(c,listing('CONFIRMED'));const before=c.snapshot();
await c.runSelection(async()=>{{posts++;return{{payload:{{}},requestId:null}}}},{json.dumps(bad)});
assert.equal(posts,0);assert.equal(reads,0);assert.deepEqual(c.snapshot(),before);c.dispose();
""")


def test_pending_intent_is_detached_and_disposed_response_does_not_refresh():
    run_node(ACTION_SETUP.replace("ACTION", "'activate'") + """
const d=deferred();const c=fixture();admit(c,listing('CONFIRMED'));
const operation=c.runSelection(async()=>{posts++;return d.promise},intent);
intent.twinId='twin-other';intent.expectedVersion=9;d.resolve({payload:selected,requestId:null});await operation;
assert.equal(c.snapshot().outcome,'ACKNOWLEDGED');assert.equal(posts,1);assert.equal(reads,1);
const next=deferred();const pending=c.runSelection(async()=>{posts++;return next.promise},{action:'activate',twinId:subject.twin_id,expectedVersion:2});
c.dispose();next.resolve({payload:selected,requestId:null});await pending;assert.equal(reads,1);
""")


def test_repeated_selection_while_pending_never_dispatches_second_post():
    run_node(ACTION_SETUP.replace("ACTION", "'activate'") + """
const d=deferred();const c=fixture();admit(c,listing('CONFIRMED'));
const request=async()=>{posts++;return d.promise};const pending=c.runSelection(request,intent);
assert.equal(await c.runSelection(request,intent),false);assert.equal(posts,1);
d.resolve({payload:selected,requestId:null});await pending;
assert.equal(posts,1);assert.equal(reads,1);assert.equal(c.snapshot().outcome,'ACKNOWLEDGED');c.dispose();
""")


def test_actual_preparation_and_availability_ack_is_accepted_without_record_publication():
    from livemorebio.aegle.subjects import prepare_observation_selection
    from livemorebio.aegle.model_contexts import model_availability
    from livemorebio.tests.clinical_registry_fixtures import legacy_twin_record

    record = legacy_twin_record(version=2)
    prepared = prepare_observation_selection(record, expected_version=2).record
    payload = {**prepared, "model_availability": model_availability(prepared, source_generation="a" * 32, selection_mode="observations_only")}
    run_node(f"""
const value={json.dumps(payload)};const c=fixture();admit(c,listing('CONFIRMED'));
await c.runSelection(async()=>{{posts++;return{{payload:value,requestId:UUID}}}},{{action:'select-observations',twinId:value.twin_id,expectedVersion:2}});
assert.equal(c.snapshot().outcome,'ACKNOWLEDGED');assert.equal(posts,1);assert.equal(reads,1);
assert.equal(c.snapshot().active.twin_id,subject.twin_id);assert.notEqual(c.snapshot().active.twin_id,value.twin_id);c.dispose();
""")
