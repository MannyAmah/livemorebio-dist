"""Same-origin LIFE proxy: fixed routes, protected responses, no fallback."""
import pytest

from livemorebio.tests.test_execution_api import product, HEADERS


@pytest.fixture
def proxy(product, monkeypatch):
    from livemorebio.aegle import life_session_api
    calls = []
    class Peer:
        def request_response(self, method, path, body, *, accepted_statuses):
            calls.append((method, path, body, accepted_statuses))
            return 200, {"session_id": "a" * 32, "state": "paused"}
    monkeypatch.setattr(life_session_api, "_client", Peer)
    product.proxy, product.calls = life_session_api, calls
    return product


def test_private_fixed_proxy_routes(proxy):
    result = proxy.client.get("/api/patch/virtual/sessions/" + "a" * 32, headers=HEADERS)
    assert result.status_code == 200 and result.json()["state"] == "paused"
    assert result.headers["cache-control"] == "no-store"
    assert proxy.calls[-1][:3] == ("GET", "/patch/virtual/sessions/" + "a" * 32, None)
    unauthorized = proxy.client.get("/api/patch/virtual/sessions/" + "a" * 32)
    assert unauthorized.status_code == 401 and len(proxy.calls) == 1


def test_proxy_preserves_control_body_without_url_or_counter_defaults(proxy):
    path = "/api/patch/virtual/sessions/" + "a" * 32 + "/pause"
    result = proxy.client.post(path, json={"expected_revision": 7}, headers=HEADERS)
    assert result.status_code == 200
    assert proxy.calls[-1][2] == {"expected_revision": 7}
    for invalid in [{"expected_revision": 7, "url": "http://untrusted.invalid"}, {"expected_revision": True}]:
        assert proxy.client.post(path, json=invalid, headers=HEADERS).status_code == 422
    assert len(proxy.calls) == 1


def test_peer_error_is_safe_and_not_misreported_as_success(proxy, monkeypatch):
    class Peer:
        def request_response(self, *args, **kwargs):
            return 409, {"code": "EXECUTION_CONFLICT", "error": "PRIVATE_CLINICAL_NOTE"}
    monkeypatch.setattr(proxy.proxy, "_client", Peer)
    result = proxy.client.get("/api/patch/virtual/sessions/" + "a" * 32, headers=HEADERS)
    assert result.status_code == 409 and result.json()["code"] == "EXECUTION_CONFLICT"
    assert "PRIVATE_CLINICAL_NOTE" not in result.text


def test_proxy_rejects_query_and_action_before_forwarding(proxy):
    root = "/api/patch/virtual/sessions/" + "a" * 32
    assert proxy.client.get(root + "?url=http://example.invalid", headers=HEADERS).status_code == 422
    assert proxy.client.post(root + "/renew", json={}, headers=HEADERS).status_code == 422
    assert not proxy.calls
