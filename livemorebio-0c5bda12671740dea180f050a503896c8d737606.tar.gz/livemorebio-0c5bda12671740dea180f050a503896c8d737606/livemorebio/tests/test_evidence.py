from __future__ import annotations

import base64
import csv
import hashlib
import io
import json
import os
import re
import sqlite3
import tempfile
import threading
import unittest
import zipfile
from dataclasses import FrozenInstanceError, replace
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from livemorebio.evidence import (
    AssessmentStatus,
    CalibrationDeniedError,
    ClaimState,
    ConflictError,
    ContextOfUse,
    CounterpartMeasurement,
    DomainValidationError,
    EvidencePackageVersion,
    EvidenceService,
    EvidenceStore,
    ImmutablePackageError,
    IntegrityError,
    InvalidTransitionError,
    LifecycleStatus,
    MeasurementEnvelope,
    MeasurementRole,
    ModelVerificationRecord,
    NamedValue,
    NotFoundError,
    PolicyVersion,
    PredictionRun,
    PredictionValue,
    ProtocolVersion,
    Provenance,
    ScenarioSnapshot,
    SigningConfigurationError,
    SourceDataClass,
    ValidationDimension,
    ValidationEvent,
    VisualizationManifest,
    VisualizationMapping,
    canonical_decimal,
    canonical_hash,
    canonical_json_bytes,
    compute_claim_state,
    content_hash,
    validation_analysis_hash,
    verify_signed_export,
)
from livemorebio.evidence.exporter import (
    _spreadsheet_safe_cell,
    export_package as write_export,
    plan_export as build_export_plan,
)
from livemorebio.evidence import signing as evidence_signing
from livemorebio.evidence.policies import APPROVED_POLICIES
from livemorebio.evidence.signing import IssuerSigner
from ._timing import wait_seconds


UTC = timezone.utc
T0 = datetime(2026, 7, 8, 16, 17, 18, 123456, tzinfo=UTC)
TEST_CODE_COMMIT = "git:" + "a" * 40
TEST_CONTAINER_DIGEST = "sha256:" + "b" * 64
TEST_AEGLE_MODEL_ID = "aegle-liver@sha256:" + "c" * 64
TEST_CENDOS_MODEL_ID = "cendos-pk@sha256:" + "d" * 64
TEST_DATASET_ID = "reference-pathways@sha256:" + "e" * 64
CALIBRATION_POLICY = APPROVED_POLICIES[("livemore-research-model-policy", "1.0.0")]


def package_fixture(
    *,
    tenant_id: str = "tenant-a",
    package_id: str = "evpkg-001",
    version: int = 1,
    previous_version_id: str | None = None,
    source_data_class: SourceDataClass = SourceDataClass.SYNTHETIC,
    validation_dimensions: tuple[ValidationDimension, ...] = (),
    include_measurement: bool = True,
    measurement_value: Decimal = Decimal("38.0"),
    endpoint: str = "ALT",
    unit: str = "U/L",
    predicted_value: Decimal = Decimal("40.0"),
    baseline_value: Decimal = Decimal("50.0"),
    policy: PolicyVersion | None = None,
) -> EvidencePackageVersion:
    policy = policy or PolicyVersion(
        policy_id="policy-pharma-discovery",
        version="1.0.0",
        effective_at=T0,
        required_dimensions=(
            ValidationDimension.MODEL_VERIFICATION,
            ValidationDimension.DEVICE_ANALYTICAL_VALIDITY,
            ValidationDimension.ASSAY_VALIDITY,
            ValidationDimension.BIOLOGICAL_CONCORDANCE,
        ),
        clinical_use=False,
    )
    evidence_time = max(T0, policy.effective_at)
    context = ContextOfUse(
        context_id="cou-hepatocyte-response",
        question_of_interest=f"Does candidate X change {endpoint} at 24 hours?",
        intended_decision="Advance candidate X to confirmatory testing",
        decision_owner_role="qualified_scientist",
        target_population="consented adults represented by the protocol cohort",
        model_system="Aegle liver twin plus Cendos assay",
        model_influence="supportive",
        wrong_decision_consequence="ineffective or unsafe candidate advancement",
        risk="high",
        impact="high",
        limitations=("research use only",),
        required_dimensions=policy.required_dimensions,
        policy_id=policy.policy_id,
        policy_hash=policy.canonical_hash,
    )
    protocol = ProtocolVersion(
        protocol_id="protocol-alt-001",
        version="1.0.0",
        objective=f"Compare predicted and counterpart {endpoint} response",
        hypothesis=f"Candidate X produces a measurable {endpoint} response",
        candidate="candidate-x",
        target="liver",
        assay=endpoint,
        dose="10 mg",
        duration="24 h",
        controls=("vehicle",),
        endpoints=(endpoint,),
        acceptance_criteria=(f"absolute_error <= 2.0 {unit}",),
        statistical_plan="Pre-specified absolute error comparison",
        approval_status="approved",
        approved_at=evidence_time,
        approved_by="protocol-approver",
        approval_role="independent_protocol_reviewer",
        approval_reference="protocol-registry:protocol-alt-001:1.0.0",
        deviations=(),
        sop_references=("SOP-ALT-1",),
    )
    baseline_measurement = MeasurementEnvelope(
        schema_version="livemore.measurement.v1",
        envelope_id="measurement-001",
        tenant_id=tenant_id,
        counterpart_id="twin-001",
        role=MeasurementRole.BASELINE_INPUT,
        subject_pseudonymized=source_data_class is not SourceDataClass.SYNTHETIC,
        sequence=1,
        received_at=evidence_time,
        payload=CounterpartMeasurement(
            endpoint=endpoint,
            value=baseline_value,
            unit=unit,
            source_data_class=source_data_class,
            measured_at=evidence_time,
            quality_status=AssessmentStatus.PASS,
            calibration_status=AssessmentStatus.PASS,
            consent_scope=("research",),
            device_id="life-patch-synthetic" if source_data_class is SourceDataClass.SYNTHETIC else "device-001",
            instrument_id="instrument-001",
            method="validated-assay-v1",
            chain_of_custody=("received", "analyzed"),
        ),
    )
    outcome_measurement = MeasurementEnvelope(
        schema_version="livemore.measurement.v1",
        envelope_id="measurement-002",
        tenant_id=tenant_id,
        counterpart_id="twin-001",
        role=MeasurementRole.COUNTERPART_OUTCOME,
        subject_pseudonymized=source_data_class is not SourceDataClass.SYNTHETIC,
        sequence=2,
        received_at=evidence_time + timedelta(hours=24, minutes=1),
        payload=CounterpartMeasurement(
            endpoint=endpoint,
            value=measurement_value,
            unit=unit,
            source_data_class=source_data_class,
            measured_at=evidence_time + timedelta(hours=24),
            quality_status=AssessmentStatus.PASS,
            calibration_status=AssessmentStatus.PASS,
            consent_scope=("research",),
            device_id=(
                "life-patch-synthetic"
                if source_data_class is SourceDataClass.SYNTHETIC
                else "device-001"
            ),
            instrument_id="instrument-001",
            method="validated-assay-v1",
            chain_of_custody=("received", "analyzed"),
        ),
    )
    snapshot = ScenarioSnapshot(
        snapshot_id="snapshot-001",
        twin_id="twin-001",
        captured_at=evidence_time,
        measurement_ids=(baseline_measurement.envelope_id,) if include_measurement else (),
        measurement_hashes=(baseline_measurement.source_hash,) if include_measurement else (),
        model_inputs=(NamedValue(f"baseline_{endpoint.lower()}", baseline_value, unit),),
        code_version=TEST_CODE_COMMIT,
        model_versions=(TEST_AEGLE_MODEL_ID,),
        dataset_versions=(TEST_DATASET_ID,),
    )
    prediction = PredictionRun(
        prediction_id="prediction-001",
        live_twin_id="twin-001",
        scenario_snapshot=snapshot,
        cendos_run_id="cendos-run-001",
        protocol_hash=canonical_hash(protocol),
        input_measurement_ids=(baseline_measurement.envelope_id,) if include_measurement else (),
        model_versions=(TEST_AEGLE_MODEL_ID, TEST_CENDOS_MODEL_ID),
        code_version=TEST_CODE_COMMIT,
        dataset_versions=(TEST_DATASET_ID,),
        container_digest=TEST_CONTAINER_DIGEST,
        deterministic_seed=7,
        outputs=(
            PredictionValue(
                endpoint=endpoint,
                value=predicted_value,
                unit=unit,
                lower=predicted_value - Decimal("4.0"),
                upper=predicted_value + Decimal("4.0"),
                confidence=Decimal("0.95"),
            ),
        ),
        assumptions=("steady state",),
        limitations=("not externally replicated",),
        actor_id="model-author",
        generated_at=evidence_time,
    )
    verification_evidence_hash = canonical_hash(
        {
            "scope": "deterministic contract verification",
            "prediction_input_hash": prediction.input_hash,
            "outputs": prediction.outputs,
        }
    )
    model_verification = ModelVerificationRecord(
        verification_id="model-verification-001",
        prediction_id=prediction.prediction_id,
        prediction_hash=canonical_hash(prediction),
        disposition=AssessmentStatus.PASS,
        scope="deterministic and schema contract only; not biological validity",
        method="test-model-contract-v1",
        evidence_hashes=(verification_evidence_hash,),
        verifier_id="model-verifier",
        verifier_role="software_verification",
        verified_at=evidence_time + timedelta(minutes=1),
        policy_id=policy.policy_id,
        policy_hash=policy.canonical_hash,
    )
    events_list = []
    for index, dimension in enumerate(
        item for item in validation_dimensions if item is not ValidationDimension.MODEL_VERIFICATION
    ):
        event = ValidationEvent(
            event_id=f"validation-{index + 1}",
            prediction_id=prediction.prediction_id,
            measurement_envelope_id=outcome_measurement.envelope_id,
            dimension=dimension,
            endpoint=endpoint,
            unit=unit,
            time_window="24 h",
            acceptance_criterion=f"absolute_error <= 2.0 {unit}",
            metric_name="absolute_error",
            metric_value=abs(predicted_value - measurement_value),
            disposition=(
                AssessmentStatus.PASS
                if abs(predicted_value - measurement_value) <= Decimal("2.0")
                else AssessmentStatus.FAIL
            ),
            endpoint_compatible=True,
            unit_compatible=True,
            time_window_compatible=True,
            quality_passed=True,
            protocol_criterion_passed=(
                abs(predicted_value - measurement_value) <= Decimal("2.0")
            ),
            source_data_class=source_data_class,
            reviewer_id="independent-reviewer",
            reviewer_role="qualified_scientist",
            reviewed_at=evidence_time + timedelta(hours=25),
            policy_id=policy.policy_id,
            policy_hash=policy.canonical_hash,
            analysis_hash="0" * 64,
            independent=(dimension is ValidationDimension.EXTERNAL_REPLICATION),
            independent_site="site-b" if dimension is ValidationDimension.EXTERNAL_REPLICATION else None,
        )
        events_list.append(
            replace(
                event,
                analysis_hash=validation_analysis_hash(
                    prediction,
                    outcome_measurement,
                    event,
                ),
            )
        )
    events = tuple(events_list)
    return EvidencePackageVersion(
        package_id=package_id,
        schema_version="livemore.evidence-package.v2",
        tenant_id=tenant_id,
        version=version,
        previous_version_id=previous_version_id,
        use_case="pharma_discovery",
        claim=f"Model-only candidate X {endpoint} response for research; not validated",
        policy=policy,
        context_of_use=context,
        protocol=protocol,
        predictions=(prediction,),
        measurements=(baseline_measurement, outcome_measurement) if include_measurement else (),
        model_verifications=(model_verification,),
        validation_events=events,
        provenance=Provenance(
            source_ids=("life-patch-001", "aegle-001", "cendos-001"),
            transformations=("normalize-units-v1",),
            model_versions=prediction.model_versions,
            code_commit=TEST_CODE_COMMIT,
            environment="synthetic-local-test",
            content_hashes=(
                baseline_measurement.source_hash,
                outcome_measurement.source_hash,
                snapshot.state_hash,
                prediction.input_hash,
                model_verification.prediction_hash,
                verification_evidence_hash,
                *(event.analysis_hash for event in events),
            ),
            correlation_ids=("correlation-001",),
        ),
        visualization_manifest=VisualizationManifest(
            manifest_id="visualization-001",
            anatomy_asset_ids=("fma:7197",),
            coordinate_system="LivemoreBodyV1",
            asset_version="1.0.0",
            asset_license="internal-test-only",
            mappings=(
                VisualizationMapping(
                    target_id="fma:7197",
                    variable=endpoint,
                    evidence_ref=prediction.prediction_id,
                    data_class="modeled",
                    unit=unit,
                ),
            ),
        ),
        created_at=evidence_time,
        created_by="package-author",
    )


def without_counterpart_outcomes(
    package: EvidencePackageVersion,
) -> EvidencePackageVersion:
    """Prepare an initial prospective draft without post-prediction outcomes."""
    outcomes = tuple(
        measurement
        for measurement in package.measurements
        if measurement.role is MeasurementRole.COUNTERPART_OUTCOME
    )
    outcome_hashes = {measurement.source_hash for measurement in outcomes}
    return replace(
        package,
        measurements=tuple(
            measurement
            for measurement in package.measurements
            if measurement.role is not MeasurementRole.COUNTERPART_OUTCOME
        ),
        provenance=replace(
            package.provenance,
            content_hashes=tuple(
                item
                for item in package.provenance.content_hashes
                if item not in outcome_hashes
            ),
        ),
    )


class CanonicalizationTests(unittest.TestCase):
    def test_golden_canonical_bytes_and_hash(self) -> None:
        value = {
            "name": "Cafe\u0301",
            "decimal": Decimal("001.2300"),
            "time": T0,
        }
        expected = '{"decimal":"1.23","name":"Café","time":"2026-07-08T16:17:18.123Z"}'.encode()
        self.assertEqual(canonical_json_bytes(value), expected)
        self.assertEqual(
            hashlib.sha256(expected).hexdigest(),
            "6f39a5bcbc14c4b7c16c9dd624f75615fe12ed4c41c038085248a90684bf1821",
        )

    def test_decimal_rules_and_non_finite_rejection(self) -> None:
        self.assertEqual(canonical_decimal(Decimal("1")), "1.0")
        self.assertEqual(canonical_decimal(Decimal("-0.000")), "0.0")
        self.assertEqual(canonical_decimal(Decimal("1200.34000")), "1200.34")
        for invalid in (Decimal("NaN"), Decimal("Infinity"), float("nan"), float("inf")):
            with self.subTest(invalid=invalid):
                with self.assertRaises(DomainValidationError):
                    canonical_json_bytes({"value": invalid})

    def test_naive_datetime_and_nfc_key_collision_are_rejected(self) -> None:
        with self.assertRaises(DomainValidationError):
            canonical_json_bytes({"time": datetime(2026, 7, 9)})
        with self.assertRaises(DomainValidationError):
            canonical_json_bytes({"Café": 1, "Cafe\u0301": 2})


class ImmutableDomainTests(unittest.TestCase):
    def test_records_are_frozen_and_policy_hash_is_bound(self) -> None:
        package = package_fixture()
        with self.assertRaises(FrozenInstanceError):
            package.claim = "forged"  # type: ignore[misc]
        self.assertEqual(package.context_of_use.policy_hash, package.policy.canonical_hash)
        self.assertEqual(package.lifecycle, LifecycleStatus.DRAFT)

    def test_context_policy_mismatch_is_rejected(self) -> None:
        package = package_fixture()
        with self.assertRaises(DomainValidationError):
            replace(
                package,
                context_of_use=replace(package.context_of_use, policy_hash="0" * 64),
            )

    def test_version_identity_items_and_provenance_coverage_are_unambiguous(self) -> None:
        package = package_fixture()
        snapshot = package.predictions[0].scenario_snapshot
        with self.assertRaisesRegex(DomainValidationError, "scenario model version is required"):
            replace(snapshot, model_versions=("",), state_hash="")
        with self.assertRaisesRegex(DomainValidationError, "scenario dataset version is required"):
            replace(snapshot, dataset_versions=("",), state_hash="")
        with self.assertRaisesRegex(DomainValidationError, "exactly cover"):
            replace(
                package,
                provenance=replace(
                    package.provenance,
                    model_versions=("unrelated-model-1.0.0",),
                ),
            )

    def test_visualization_mapping_rejects_unbound_or_mislabeled_evidence(self) -> None:
        package = package_fixture()
        mapping = package.visualization_manifest.mappings[0]
        adversarial_changes = (
            (
                "unknown evidence",
                {"evidence_ref": "prediction-does-not-exist"},
                "unknown package evidence",
            ),
            (
                "wrong variable",
                {"variable": "tumor_risk"},
                "variable does not match",
            ),
            (
                "modeled evidence labeled as real human",
                {"data_class": "real_human"},
                "data class does not match",
            ),
            (
                "wrong unit",
                {"unit": "mg/dL"},
                "unit does not match",
            ),
        )
        for label, changes, message in adversarial_changes:
            with self.subTest(label=label):
                forged_mapping = replace(mapping, **changes)
                forged_manifest = replace(
                    package.visualization_manifest,
                    mappings=(forged_mapping,),
                )
                with self.assertRaisesRegex(DomainValidationError, message):
                    replace(package, visualization_manifest=forged_manifest)

        with self.assertRaisesRegex(DomainValidationError, "not declared"):
            replace(
                package.visualization_manifest,
                mappings=(replace(mapping, target_id="fma:missing-asset"),),
            )

    def test_visualization_mapping_accepts_bound_prediction_output_and_measurement(self) -> None:
        package = package_fixture(source_data_class=SourceDataClass.REAL_HUMAN)
        mapping = package.visualization_manifest.mappings[0]
        prediction = package.predictions[0]
        output = prediction.outputs[0]
        explicitly_bound = replace(
            package,
            visualization_manifest=replace(
                package.visualization_manifest,
                mappings=(
                    replace(
                        mapping,
                        evidence_ref=(
                            f"{prediction.prediction_id}/output/{output.endpoint}"
                        ),
                        data_class=SourceDataClass.MODELED.value,
                        unit=output.unit,
                    ),
                ),
            ),
        )
        self.assertEqual(
            explicitly_bound.visualization_manifest.mappings[0].data_class,
            SourceDataClass.MODELED.value,
        )

        outcome = package.measurements[1]
        measurement_bound = replace(
            package,
            visualization_manifest=replace(
                package.visualization_manifest,
                mappings=(
                    replace(
                        mapping,
                        evidence_ref=outcome.envelope_id,
                        data_class=outcome.payload.source_data_class.value,
                        unit=outcome.payload.unit,
                    ),
                ),
            ),
        )
        self.assertEqual(
            measurement_bound.visualization_manifest.mappings[0].data_class,
            SourceDataClass.REAL_HUMAN.value,
        )

    def test_claim_state_is_computed_and_synthetic_is_capped_at_modeled(self) -> None:
        synthetic = package_fixture(
            validation_dimensions=(
                ValidationDimension.MODEL_VERIFICATION,
                ValidationDimension.BIOLOGICAL_CONCORDANCE,
            )
        )
        self.assertEqual(synthetic.claim_state, ClaimState.MODELED)

        calibrated = package_fixture(
            source_data_class=SourceDataClass.REAL_HUMAN,
            validation_dimensions=(ValidationDimension.EXTERNAL_REPLICATION,),
        )
        self.assertEqual(calibrated.claim_state, ClaimState.CALIBRATED)

        validity_layers_incomplete = package_fixture(
            source_data_class=SourceDataClass.REAL_HUMAN,
            validation_dimensions=(
                ValidationDimension.MODEL_VERIFICATION,
                ValidationDimension.BIOLOGICAL_CONCORDANCE,
            ),
        )
        self.assertEqual(validity_layers_incomplete.claim_state, ClaimState.CALIBRATED)
        self.assertEqual(
            next(
                item
                for item in validity_layers_incomplete.validation_summary
                if item.dimension is ValidationDimension.DEVICE_ANALYTICAL_VALIDITY
            ).status,
            AssessmentStatus.NOT_ASSESSED,
        )

        replication = replace(
            package_fixture(
                source_data_class=SourceDataClass.REAL_HUMAN,
                validation_dimensions=(ValidationDimension.EXTERNAL_REPLICATION,),
            ).validation_events[0],
            event_id="validation-replication",
            analysis_hash="0" * 64,
        )
        replication = replace(
            replication,
            analysis_hash=validation_analysis_hash(
                validity_layers_incomplete.predictions[0],
                validity_layers_incomplete.measurements[1],
                replication,
            ),
        )
        with self.assertRaises(DomainValidationError):
            replace(
                validity_layers_incomplete,
                validation_events=validity_layers_incomplete.validation_events + (replication,),
                provenance=replace(
                    validity_layers_incomplete.provenance,
                    content_hashes=validity_layers_incomplete.provenance.content_hashes
                    + (replication.analysis_hash,),
                ),
            )

    def test_content_hash_excludes_only_hash_and_lifecycle_metadata(self) -> None:
        package = package_fixture()
        initial = content_hash(package)
        lock_time = max(
            package.created_at,
            *(measurement.received_at for measurement in package.measurements),
            *(verification.verified_at for verification in package.model_verifications),
            *(event.reviewed_at for event in package.validation_events),
        ) + timedelta(seconds=1)
        lifecycle_only = replace(
            package,
            content_hash=initial,
            lifecycle=LifecycleStatus.RELEASED,
            revision=99,
            locked_at=lock_time,
            released_at=lock_time + timedelta(seconds=1),
            lifecycle_reason="review complete",
        )
        self.assertEqual(content_hash(lifecycle_only), initial)
        self.assertNotEqual(
            content_hash(
                replace(
                    package,
                    context_of_use=replace(
                        package.context_of_use,
                        question_of_interest="Does candidate X change AST at 48 hours?",
                    ),
                )
            ),
            initial,
        )

    def test_preloaded_forged_validation_cannot_promote_a_claim(self) -> None:
        package = package_fixture(
            source_data_class=SourceDataClass.REAL_HUMAN,
            validation_dimensions=(
                ValidationDimension.MODEL_VERIFICATION,
                ValidationDimension.BIOLOGICAL_CONCORDANCE,
            ),
        )
        forged = replace(package.validation_events[0], endpoint="AST")
        with self.assertRaises(DomainValidationError):
            replace(package, validation_events=(forged,) + package.validation_events[1:])

    def test_caller_supplied_nested_hashes_must_match_derived_content(self) -> None:
        package = package_fixture()
        with self.assertRaises(IntegrityError):
            replace(
                package,
                measurements=(replace(package.measurements[0], source_hash="0" * 64),),
            )
        with self.assertRaises(IntegrityError):
            replace(
                package,
                predictions=(
                    replace(
                        package.predictions[0],
                        scenario_snapshot=replace(
                            package.predictions[0].scenario_snapshot,
                            state_hash="1" * 64,
                        ),
                    ),
                ),
            )
        with self.assertRaises(IntegrityError):
            replace(
                package,
                predictions=(replace(package.predictions[0], input_hash="2" * 64),),
            )

    def test_prediction_chain_is_bound_to_exact_measurement_content(self) -> None:
        package = package_fixture()
        changed_measurement = replace(
            package.measurements[0],
            payload=replace(package.measurements[0].payload, value=Decimal("999.0")),
            source_hash="",
        )
        changed_hashes = tuple(
            changed_measurement.source_hash if value == package.measurements[0].source_hash else value
            for value in package.provenance.content_hashes
        )
        with self.assertRaises(DomainValidationError):
            replace(
                package,
                measurements=(changed_measurement,),
                provenance=replace(package.provenance, content_hashes=changed_hashes),
            )

    def test_model_verification_is_bound_to_exact_prediction_outputs(self) -> None:
        package = package_fixture()
        prediction = package.predictions[0]
        changed_output = replace(
            prediction.outputs[0],
            value=Decimal("41.0"),
        )
        with self.assertRaises(DomainValidationError):
            replace(
                package,
                predictions=(replace(prediction, outputs=(changed_output,)),),
            )

    def test_prediction_contract_rejects_ambiguous_or_unbounded_artifacts(self) -> None:
        package = package_fixture()
        prediction = package.predictions[0]
        with self.assertRaises(DomainValidationError):
            replace(prediction, outputs=(prediction.outputs[0], prediction.outputs[0]))
        with self.assertRaises(DomainValidationError):
            replace(
                prediction.outputs[0],
                value=prediction.outputs[0].upper + Decimal("1.0"),
            )
        with self.assertRaises(DomainValidationError):
            replace(prediction.scenario_snapshot, model_inputs=(), state_hash="")
        with self.assertRaisesRegex(DomainValidationError, "model-input names must be unique"):
            replace(
                prediction.scenario_snapshot,
                model_inputs=(
                    prediction.scenario_snapshot.model_inputs[0],
                    prediction.scenario_snapshot.model_inputs[0],
                ),
                state_hash="",
            )
        with self.assertRaises(DomainValidationError):
            replace(prediction, dataset_versions=(), input_hash="")
        with self.assertRaisesRegex(
            DomainValidationError,
            "input measurement IDs must be unique",
        ):
            replace(
                prediction,
                input_measurement_ids=(
                    prediction.input_measurement_ids[0],
                    prediction.input_measurement_ids[0],
                ),
                input_hash="",
            )

    def test_scenario_model_state_requires_canonical_payload_and_matching_hash(self) -> None:
        snapshot = package_fixture().predictions[0].scenario_snapshot
        model_state = {
            "schema_version": "livemore.runtime-model-state.v1",
            "twin_inputs": {"profile": {"hba1c": "8.7"}},
        }
        model_state_json = canonical_json_bytes(model_state).decode("utf-8")
        bound = replace(
            snapshot,
            model_state_json=model_state_json,
            model_state_hash=canonical_hash(model_state),
            state_hash="",
        )
        self.assertEqual(bound.model_state_hash, canonical_hash(model_state))
        with self.assertRaisesRegex(IntegrityError, "model-state hash"):
            replace(
                snapshot,
                model_state_json=model_state_json,
                model_state_hash="0" * 64,
                state_hash="",
            )
        with self.assertRaisesRegex(DomainValidationError, "canonical encoding"):
            replace(
                snapshot,
                model_state_json=json.dumps(model_state, indent=2),
                model_state_hash=canonical_hash(model_state),
                state_hash="",
            )
        with self.assertRaisesRegex(DomainValidationError, "provided together"):
            replace(
                snapshot,
                model_state_json=model_state_json,
                model_state_hash="",
                state_hash="",
            )

    def test_baseline_measurement_must_be_traceable_into_model_inputs(self) -> None:
        package = package_fixture()
        prediction = package.predictions[0]
        forged_snapshot = replace(
            prediction.scenario_snapshot,
            model_inputs=(NamedValue("baseline_alt", Decimal("999.0"), "U/L"),),
            state_hash="",
        )
        with self.assertRaises(DomainValidationError):
            replace(
                package,
                predictions=(
                    replace(
                        prediction,
                        scenario_snapshot=forged_snapshot,
                        input_hash="",
                    ),
                ),
            )

    def test_scenario_snapshot_rejects_measurement_received_after_capture(self) -> None:
        package = package_fixture()
        prediction = package.predictions[0]
        late_measurement = replace(
            package.measurements[0],
            received_at=prediction.scenario_snapshot.captured_at + timedelta(seconds=1),
            source_hash="",
        )
        late_snapshot = replace(
            prediction.scenario_snapshot,
            measurement_hashes=(late_measurement.source_hash,),
            state_hash="",
        )
        with self.assertRaisesRegex(DomainValidationError, "received after capture"):
            replace(
                package,
                created_at=prediction.scenario_snapshot.captured_at + timedelta(seconds=2),
                measurements=(late_measurement, package.measurements[1]),
                predictions=(
                    replace(
                        prediction,
                        scenario_snapshot=late_snapshot,
                        input_hash="",
                    ),
                ),
            )

    def test_modeled_outward_claim_rejects_clinical_advancement_language(self) -> None:
        package = package_fixture()
        unsafe_claims = (
            "Model-only candidate is safe and effective and can bypass Phase I; research, not validated",
            "Model-only no animal testing is needed and first-in-human dosing may begin; research, not validated",
            "Research model candidate result; not validated",
            "Use this result to dose volunteers tomorrow",
            "Proceed directly to dosing people",
            "This result warrants human dosing",
            "Animal work can now be dispensed with",
            "Suitable as the sole basis for patient care",
            "Model-only candidate X ALT response for research; not validated; dose volunteers tomorrow",
        )
        for claim in unsafe_claims:
            with self.subTest(claim=claim):
                with self.assertRaises(DomainValidationError):
                    replace(package, claim=claim)

    def test_validated_and_replicated_states_require_invariant_evidence_floor(self) -> None:
        biological = package_fixture(
            source_data_class=SourceDataClass.REAL_HUMAN,
            validation_dimensions=(ValidationDimension.BIOLOGICAL_CONCORDANCE,),
        )
        self.assertEqual(biological.claim_state, ClaimState.CALIBRATED)
        self.assertEqual(
            compute_claim_state(
                biological.predictions,
                biological.measurements,
                biological.model_verifications,
                biological.validation_events,
                biological.policy.required_dimensions,
            ),
            ClaimState.CALIBRATED,
        )

        external = package_fixture(
            source_data_class=SourceDataClass.REAL_HUMAN,
            validation_dimensions=(ValidationDimension.EXTERNAL_REPLICATION,),
        )
        # External replication alone cannot skip the invariant device, assay,
        # biological-concordance, and clinical-applicability floor.
        self.assertEqual(
            compute_claim_state(
                external.predictions,
                external.measurements,
                external.model_verifications,
                external.validation_events,
                external.policy.required_dimensions,
            ),
            ClaimState.CALIBRATED,
        )

        for unsupported_dimension in (
            ValidationDimension.DEVICE_ANALYTICAL_VALIDITY,
            ValidationDimension.ASSAY_VALIDITY,
            ValidationDimension.CLINICAL_APPLICABILITY,
        ):
            with self.subTest(unsupported_dimension=unsupported_dimension):
                with self.assertRaises(DomainValidationError):
                    package_fixture(
                        source_data_class=SourceDataClass.REAL_HUMAN,
                        validation_dimensions=(unsupported_dimension,),
                    )

    def test_policy_cannot_be_applied_retroactively_to_evidence_chronology(self) -> None:
        package = package_fixture(
            source_data_class=SourceDataClass.REAL_HUMAN,
            validation_dimensions=(ValidationDimension.BIOLOGICAL_CONCORDANCE,),
        )
        before_effective = T0 - timedelta(milliseconds=1)
        earlier_snapshot = replace(
            package.predictions[0].scenario_snapshot,
            captured_at=T0 - timedelta(milliseconds=2),
            state_hash="",
        )
        earlier_prediction = replace(
            package.predictions[0],
            scenario_snapshot=earlier_snapshot,
            generated_at=before_effective,
            input_hash="",
        )
        pre_policy_snapshot_prediction = replace(
            package.predictions[0],
            scenario_snapshot=earlier_snapshot,
            input_hash="",
        )
        invalid_builders = (
            ("package creation", lambda: replace(package, created_at=before_effective)),
            (
                "protocol approval",
                lambda: replace(
                    package,
                    protocol=replace(package.protocol, approved_at=before_effective),
                ),
            ),
            (
                "scenario capture",
                lambda: replace(package, predictions=(pre_policy_snapshot_prediction,)),
            ),
            ("prediction generation", lambda: replace(package, predictions=(earlier_prediction,))),
            (
                "model verification",
                lambda: replace(
                    package,
                    model_verifications=(
                        replace(package.model_verifications[0], verified_at=before_effective),
                    ),
                ),
            ),
            (
                "validation review",
                lambda: replace(
                    package,
                    validation_events=(
                        replace(
                            package.validation_events[0],
                            reviewed_at=before_effective,
                            analysis_hash="0" * 64,
                        ),
                    ),
                ),
            ),
        )
        for boundary, build in invalid_builders:
            with self.subTest(boundary=boundary):
                with self.assertRaisesRegex(DomainValidationError, boundary):
                    build()

    def test_prediction_snapshot_and_baseline_cannot_postdate_package_creation(self) -> None:
        package = package_fixture()
        after_creation = package.created_at + timedelta(milliseconds=1)
        future_prediction = replace(
            package.predictions[0],
            generated_at=after_creation,
            input_hash="",
        )
        with self.assertRaisesRegex(DomainValidationError, "prediction generation"):
            replace(package, predictions=(future_prediction,))

        future_snapshot = replace(
            package.predictions[0].scenario_snapshot,
            captured_at=after_creation,
            state_hash="",
        )
        snapshot_prediction = replace(
            package.predictions[0],
            scenario_snapshot=future_snapshot,
            generated_at=after_creation,
            input_hash="",
        )
        with self.assertRaisesRegex(DomainValidationError, "scenario capture"):
            replace(package, predictions=(snapshot_prediction,))

        late_baseline = replace(
            package.measurements[0],
            received_at=after_creation,
            source_hash="",
        )
        with self.assertRaisesRegex(DomainValidationError, "baseline measurement receipt"):
            replace(
                package,
                measurements=(late_baseline, *package.measurements[1:]),
            )

    def test_protocol_only_package_cannot_claim_approval_after_creation(self) -> None:
        source = package_fixture(include_measurement=False)
        protocol_only = replace(
            source,
            predictions=(),
            model_verifications=(),
            provenance=replace(
                source.provenance,
                model_versions=(),
            ),
            visualization_manifest=replace(
                source.visualization_manifest,
                mappings=(),
            ),
        )
        with self.assertRaisesRegex(DomainValidationError, "protocol approval"):
            replace(
                protocol_only,
                protocol=replace(
                    protocol_only.protocol,
                    approved_at=protocol_only.created_at + timedelta(minutes=1),
                ),
            )

    def test_unassessed_adverse_outcome_blocks_selective_promotion(self) -> None:
        assessed = package_fixture(
            source_data_class=SourceDataClass.REAL_HUMAN,
            validation_dimensions=(ValidationDimension.BIOLOGICAL_CONCORDANCE,),
        )
        adverse = replace(
            assessed.measurements[1],
            envelope_id="measurement-adverse-unassessed",
            sequence=3,
            received_at=T0 + timedelta(hours=25),
            payload=replace(assessed.measurements[1].payload, value=Decimal("999.0")),
            source_hash="",
        )
        incomplete = replace(
            assessed,
            measurements=assessed.measurements + (adverse,),
            provenance=replace(
                assessed.provenance,
                content_hashes=assessed.provenance.content_hashes + (adverse.source_hash,),
            ),
        )
        self.assertEqual(incomplete.claim_state, ClaimState.MODELED)
        biological = next(
            item
            for item in incomplete.validation_summary
            if item.dimension is ValidationDimension.BIOLOGICAL_CONCORDANCE
        )
        self.assertEqual(biological.status, AssessmentStatus.PARTIAL)

    def test_verification_and_review_chronology_cannot_be_backdated(self) -> None:
        package = package_fixture()
        with self.assertRaises(DomainValidationError):
            replace(
                package,
                model_verifications=(
                    replace(
                        package.model_verifications[0],
                        verified_at=package.predictions[0].generated_at - timedelta(seconds=1),
                    ),
                ),
            )
        reviewed = package_fixture(
            source_data_class=SourceDataClass.REAL_HUMAN,
            validation_dimensions=(ValidationDimension.BIOLOGICAL_CONCORDANCE,),
        )
        with self.assertRaises(DomainValidationError):
            replace(
                reviewed,
                validation_events=(
                    replace(
                        reviewed.validation_events[0],
                        reviewed_at=reviewed.measurements[1].received_at - timedelta(seconds=1),
                    ),
                ),
            )

    def test_conflicting_passing_and_failing_required_events_block_promotion(self) -> None:
        validated = package_fixture(
            source_data_class=SourceDataClass.REAL_HUMAN,
            validation_dimensions=(ValidationDimension.BIOLOGICAL_CONCORDANCE,),
        )
        passing = validated.validation_events[0]
        adverse_measurement = replace(
            validated.measurements[1],
            envelope_id="measurement-003",
            sequence=3,
            received_at=T0 + timedelta(hours=25),
            payload=replace(
                validated.measurements[1].payload,
                value=Decimal("999.0"),
            ),
            source_hash="",
        )
        failing = replace(
            passing,
            event_id="validation-conflicting-failure",
            measurement_envelope_id=adverse_measurement.envelope_id,
            metric_value=Decimal("959.0"),
            disposition=AssessmentStatus.FAIL,
            protocol_criterion_passed=False,
            reviewed_at=T0 + timedelta(hours=26),
            analysis_hash="0" * 64,
        )
        failing = replace(
            failing,
            analysis_hash=validation_analysis_hash(
                validated.predictions[0],
                adverse_measurement,
                failing,
            ),
        )
        conflicted = replace(
            validated,
            measurements=validated.measurements + (adverse_measurement,),
            validation_events=(passing, failing),
            provenance=replace(
                validated.provenance,
                content_hashes=validated.provenance.content_hashes
                + (adverse_measurement.source_hash, failing.analysis_hash),
            ),
        )
        self.assertEqual(conflicted.claim_state, ClaimState.MODELED)
        biological = next(
            item
            for item in conflicted.validation_summary
            if item.dimension is ValidationDimension.BIOLOGICAL_CONCORDANCE
        )
        self.assertEqual(biological.status, AssessmentStatus.FAIL)


class StoreAndLifecycleTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = Path(self.tmp.name) / "evidence.sqlite3"
        self.store = EvidenceStore(self.db_path)
        self.service = EvidenceService(
            self.store,
            unsafe_test_only_allow_preloaded_verification=True,
        )

    def tearDown(self) -> None:
        self.store.close()
        self.tmp.cleanup()

    def _create(self, package: EvidencePackageVersion) -> EvidencePackageVersion:
        return self.service.create(
            without_counterpart_outcomes(package),
            actor="package-author",
            verification_actor="model-verifier",
            protocol_approval_actor="protocol-approver",
        )

    def test_lifecycle_state_matrix_rejects_preloaded_and_out_of_order_metadata(self) -> None:
        package = package_fixture(package_id="evpkg-lifecycle-matrix")
        valid_lock_time = max(
            package.created_at,
            *(measurement.received_at for measurement in package.measurements),
            *(verification.verified_at for verification in package.model_verifications),
            *(event.reviewed_at for event in package.validation_events),
        ) + timedelta(seconds=1)
        with self.assertRaisesRegex(DomainValidationError, "preload lifecycle timestamps"):
            replace(package, locked_at=package.created_at)
        with self.assertRaisesRegex(DomainValidationError, "preload a lifecycle reason"):
            replace(package, lifecycle_reason="already reviewed")
        with self.assertRaisesRegex(DomainValidationError, "locked_at cannot precede"):
            replace(
                package,
                lifecycle=LifecycleStatus.LOCKED,
                content_hash=content_hash(package),
                locked_at=package.created_at - timedelta(seconds=1),
                lifecycle_reason="locked",
            )
        with self.assertRaisesRegex(DomainValidationError, "released lifecycle requires"):
            replace(
                package,
                lifecycle=LifecycleStatus.RELEASED,
                content_hash=content_hash(package),
                locked_at=valid_lock_time,
                lifecycle_reason="released",
            )
        with self.assertRaisesRegex(DomainValidationError, "superseded_at cannot precede"):
            replace(
                package,
                lifecycle=LifecycleStatus.RETRACTED,
                content_hash=content_hash(package),
                locked_at=valid_lock_time,
                released_at=valid_lock_time + timedelta(seconds=2),
                superseded_at=valid_lock_time + timedelta(seconds=1),
                retracted_at=valid_lock_time + timedelta(seconds=3),
                lifecycle_reason="retracted",
            )

        source = package_fixture(
            package_id="evpkg-future-lock-matrix", validation_dimensions=()
        )
        baseline, outcome = source.measurements
        future_payload = replace(
            outcome.payload,
            measured_at=source.created_at + timedelta(days=1),
        )
        future_outcome = replace(
            outcome,
            received_at=source.created_at + timedelta(days=1, seconds=1),
            payload=future_payload,
            source_hash="",
        )
        future_source = replace(
            source,
            measurements=(baseline, future_outcome),
            provenance=replace(
                source.provenance,
                content_hashes=tuple(
                    future_outcome.source_hash if value == outcome.source_hash else value
                    for value in source.provenance.content_hashes
                ),
            ),
        )
        with self.assertRaisesRegex(DomainValidationError, "cannot precede evidence receipt"):
            replace(
                future_source,
                lifecycle=LifecycleStatus.LOCKED,
                content_hash=content_hash(future_source),
                locked_at=source.created_at + timedelta(hours=1),
                lifecycle_reason="locked too early",
            )

    def test_production_rejects_test_only_evidence_bypasses(self) -> None:
        alternate_store = EvidenceStore(Path(self.tmp.name) / "unsafe-production.sqlite3")
        try:
            with patch.dict(os.environ, {"LIVEMORE_ENVIRONMENT": "production"}):
                with self.assertRaisesRegex(DomainValidationError, "forbidden in production"):
                    EvidenceService(
                        alternate_store,
                        unsafe_test_only_allow_non_synthetic=True,
                    )
        finally:
            alternate_store.close()

    def test_unicode_identity_is_normalized_before_storage_lookup_and_collision_checks(self) -> None:
        decomposed = "evpkg-cafe\u0301"
        composed = "evpkg-caf\u00e9"
        package = package_fixture(package_id=decomposed)
        self.assertEqual(package.package_id, composed)
        created = self._create(package)
        self.assertEqual(self.service.get("tenant-a", decomposed).package_id, composed)
        with self.assertRaises(ConflictError):
            self._create(package_fixture(package_id=composed))
        locked = self.service.lock(
            "tenant-a",
            decomposed,
            actor="independent-reviewer",
            expected_revision=created.revision,
        )
        self.assertEqual(locked.package_id, composed)
        self.assertEqual(locked.lifecycle, LifecycleStatus.LOCKED)

        provenance_package = package_fixture(package_id="evpkg-provenance-unicode")
        provenance_package = replace(
            provenance_package,
            provenance=replace(
                provenance_package.provenance,
                source_ids=("source-cafe\u0301",),
                transformations=("normalize cafe\u0301 values",),
                correlation_ids=("correlation-cafe\u0301",),
            ),
        )
        self.assertEqual(provenance_package.provenance.source_ids, ("source-caf\u00e9",))
        created_provenance = self._create(provenance_package)
        self.assertEqual(
            self.service.get("tenant-a", created_provenance.package_id),
            created_provenance,
        )

    def test_canonically_equivalent_actor_cannot_bypass_separation_of_duties(self) -> None:
        composed = "creator-caf\u00e9"
        decomposed = "creator-cafe\u0301"
        package = replace(
            without_counterpart_outcomes(
                package_fixture(package_id="evpkg-actor-normalization")
            ),
            created_by=composed,
        )
        created = self.service.create(
            package,
            actor=composed,
            verification_actor="model-verifier",
            protocol_approval_actor="protocol-approver",
        )
        locked = self.service.lock(
            "tenant-a", created.package_id, actor="independent-reviewer",
            expected_revision=created.revision,
        )
        with self.assertRaisesRegex(DomainValidationError, "requires separation"):
            self.service.release(
                "tenant-a", locked.package_id, actor=decomposed,
                expected_revision=locked.revision,
            )
        released = self.service.release(
            "tenant-a", locked.package_id, actor="release-officer",
            expected_revision=locked.revision,
        )
        with self.assertRaisesRegex(DomainValidationError, "requires separation"):
            self.service.retract(
                "tenant-a", released.package_id, actor=decomposed,
                reason="attempted self withdrawal", expected_revision=released.revision,
            )

    def test_store_security_foreign_keys_restart_tenant_isolation_and_chain(self) -> None:
        created = self._create(package_fixture())
        self.assertEqual(created.revision, 0)
        self.assertEqual(os.stat(self.db_path).st_mode & 0o777, 0o600)
        self.assertEqual(os.stat(self.store.audit_key_path).st_mode & 0o777, 0o600)
        self.assertEqual(self.store.pragma("foreign_keys"), 1)
        self.assertGreaterEqual(self.store.pragma("busy_timeout"), 1)
        with self.assertRaises(NotFoundError):
            self.service.get("tenant-b", created.package_id)
        self.assertEqual(self.service.list("tenant-b"), ())
        self.assertTrue(self.store.verify_audit_chain("tenant-a"))
        created_event = next(
            event
            for event in self.store.audit_events("tenant-a", created.package_id)
            if event["action"] == "package.created"
        )
        self.assertEqual(created_event["detail"]["package_revision"], 0)
        self.assertEqual(
            created_event["detail"]["package_payload_sha256"],
            hashlib.sha256(canonical_json_bytes(created)).hexdigest(),
        )
        self.store.close()
        self.store = EvidenceStore(self.db_path)
        self.service = EvidenceService(
            self.store,
            unsafe_test_only_allow_preloaded_verification=True,
        )
        self.assertEqual(self.service.get("tenant-a", created.package_id), created)

    def test_production_requires_external_audit_key_and_records_key_version(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "production-evidence.sqlite3"
            with patch.dict(
                os.environ,
                {"LIVEMORE_ENVIRONMENT": "production"},
                clear=True,
            ):
                with self.assertRaises(ValueError):
                    EvidenceStore(path)

            key = b"k" * 32
            store = EvidenceStore(
                path,
                audit_signing_key=key,
                audit_key_version="managed-kms-2026-07",
                require_external_audit_key=True,
            )
            service = EvidenceService(
                store,
                unsafe_test_only_allow_preloaded_verification=True,
            )
            candidate = without_counterpart_outcomes(
                package_fixture(package_id="evpkg-managed-audit-key")
            )
            package = service.create(
                candidate,
                actor="package-author",
                verification_actor="model-verifier",
                protocol_approval_actor=candidate.protocol.approved_by,
            )
            created_event = next(
                event
                for event in store.audit_events("tenant-a", package.package_id)
                if event["action"] == "package.created"
            )
            self.assertEqual(created_event["key_version"], "managed-kms-2026-07")

            self.assertEqual(
                created_event["detail"]["audit_key_version"],
                "managed-kms-2026-07",
            )
            self.assertFalse(store.audit_key_path.exists())
            service.close()

            reopened = EvidenceService(
                EvidenceStore(
                    path,
                    audit_signing_key=key,
                    audit_key_version="managed-kms-2026-07",
                    require_external_audit_key=True,
                ),
                unsafe_test_only_allow_preloaded_verification=True,
            )
            self.assertEqual(reopened.get("tenant-a", package.package_id), package)
            reopened.close()

            wrong_key = EvidenceService(
                EvidenceStore(
                    path,
                    audit_signing_key=b"x" * 32,
                    audit_key_version="managed-kms-2026-07",
                    require_external_audit_key=True,
                ),
                unsafe_test_only_allow_preloaded_verification=True,
            )
            with self.assertRaises(IntegrityError):
                wrong_key.get("tenant-a", package.package_id)
            wrong_key.close()

    def test_environment_audit_keyring_rotates_and_verifies_mixed_version_chain(self) -> None:
        old_key = "o" * 32
        new_key = "n" * 32
        old_version = "evidence-audit-2026-01"
        new_version = "evidence-audit-2026-07"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "rotated-evidence.sqlite3"
            old_package = package_fixture(package_id="evpkg-before-audit-rotation")
            with patch.dict(
                os.environ,
                {
                    "LIVEMORE_EVIDENCE_AUDIT_HMAC_KEY": old_key,
                    "LIVEMORE_EVIDENCE_AUDIT_KEY_VERSION": old_version,
                },
                clear=True,
            ):
                old_store = EvidenceStore(path)
                old_store.create(
                    old_package,
                    actor="package-author",
                    verification_actor="model-verifier",
                )
                self.assertTrue(old_store.verify_audit_chain("tenant-a"))
                old_store.close()

            rotated_environment = {
                "LIVEMORE_EVIDENCE_AUDIT_HMAC_KEY": new_key,
                "LIVEMORE_EVIDENCE_AUDIT_KEY_VERSION": new_version,
                "LIVEMORE_EVIDENCE_AUDIT_HMAC_VERIFICATION_KEYS": json.dumps(
                    {old_version: old_key}
                ),
            }
            with patch.dict(os.environ, rotated_environment, clear=True):
                rotated_store = EvidenceStore(path)
                self.assertEqual(
                    rotated_store.get("tenant-a", old_package.package_id),
                    old_package,
                )
                new_package = package_fixture(
                    package_id="evpkg-after-audit-rotation"
                )
                rotated_store.create(
                    new_package,
                    actor="package-author",
                    verification_actor="model-verifier",
                )
                self.assertEqual(
                    rotated_store.get("tenant-a", new_package.package_id),
                    new_package,
                )
                events = rotated_store.audit_events("tenant-a")
                self.assertEqual(
                    {event["key_version"] for event in events},
                    {old_version, new_version},
                )
                self.assertTrue(rotated_store.verify_audit_chain("tenant-a"))
                rotated_store.close()

            without_retired_key = {
                "LIVEMORE_EVIDENCE_AUDIT_HMAC_KEY": new_key,
                "LIVEMORE_EVIDENCE_AUDIT_KEY_VERSION": new_version,
            }
            with patch.dict(os.environ, without_retired_key, clear=True):
                incomplete_store = EvidenceStore(path)
                self.assertFalse(incomplete_store.verify_audit_chain("tenant-a"))
                with self.assertRaisesRegex(IntegrityError, "audit chain"):
                    incomplete_store.get("tenant-a", old_package.package_id)
                with self.assertRaisesRegex(IntegrityError, "audit chain"):
                    incomplete_store.create(
                        package_fixture(package_id="evpkg-rejected-without-old-key"),
                        actor="package-author",
                        verification_actor="model-verifier",
                    )
                with sqlite3.connect(path) as connection:
                    rejected_count = connection.execute(
                        "SELECT COUNT(*) FROM evidence_packages WHERE tenant_id=? "
                        "AND package_id=?",
                        ("tenant-a", "evpkg-rejected-without-old-key"),
                    ).fetchone()[0]
                self.assertEqual(rejected_count, 0)
                incomplete_store.close()

    def test_environment_audit_keyring_rejects_malformed_and_conflicting_config(self) -> None:
        current_key = "n" * 32
        retired_key = "o" * 32
        conflicting_key = "x" * 32
        current_version = "evidence-audit-2026-07"
        duplicate_version_json = (
            '{"evidence-audit-2026-01":"'
            + retired_key
            + '","evidence-audit-2026-01":"'
            + conflicting_key
            + '"}'
        )
        cases = (
            ("not-json", "valid JSON"),
            ("[]", "map key versions to keys"),
            (json.dumps({"evidence-audit-2026-01": 7}), "JSON strings"),
            (json.dumps({"": retired_key}), "key version is required"),
            (
                json.dumps({current_version: conflicting_key}),
                "current audit key version maps to a different verification key",
            ),
            (duplicate_version_json, "duplicate key version"),
        )
        for index, (keyring, expected_error) in enumerate(cases):
            with self.subTest(keyring=keyring):
                with tempfile.TemporaryDirectory() as directory:
                    path = Path(directory) / f"invalid-keyring-{index}.sqlite3"
                    with patch.dict(
                        os.environ,
                        {
                            "LIVEMORE_EVIDENCE_AUDIT_HMAC_KEY": current_key,
                            "LIVEMORE_EVIDENCE_AUDIT_KEY_VERSION": current_version,
                            "LIVEMORE_EVIDENCE_AUDIT_HMAC_VERIFICATION_KEYS": keyring,
                        },
                        clear=True,
                    ):
                        with self.assertRaisesRegex(ValueError, expected_error):
                            EvidenceStore(path)

    def test_store_does_not_chmod_an_existing_operator_owned_parent(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            parent = Path(directory) / "shared-parent"
            parent.mkdir(mode=0o755)
            parent.chmod(0o755)
            before = parent.stat().st_mode & 0o777
            store = EvidenceStore(parent / "evidence.sqlite3")
            store.close()
            self.assertEqual(parent.stat().st_mode & 0o777, before)

    def test_coherent_payload_row_hash_and_unkeyed_audit_rewrite_is_rejected(self) -> None:
        created = self._create(package_fixture(package_id="evpkg-coherent-rewrite"))
        locked = self.service.lock(
            "tenant-a",
            created.package_id,
            actor="independent-reviewer",
            expected_revision=created.revision,
        )
        with sqlite3.connect(self.db_path) as connection:
            connection.row_factory = sqlite3.Row
            raw = connection.execute(
                "SELECT payload_json FROM evidence_packages WHERE tenant_id=? AND package_id=?",
                ("tenant-a", locked.package_id),
            ).fetchone()["payload_json"]
            payload = json.loads(raw)
            payload["use_case"] = "coherently_forged_use_case"
            payload["content_hash"] = content_hash(payload)
            forged_payload = canonical_json_bytes(payload).decode("utf-8")
            forged_payload_hash = hashlib.sha256(
                forged_payload.encode("utf-8")
            ).hexdigest()
            connection.execute(
                "UPDATE evidence_packages SET content_hash=?,payload_json=? "
                "WHERE tenant_id=? AND package_id=?",
                (
                    payload["content_hash"],
                    forged_payload,
                    "tenant-a",
                    locked.package_id,
                ),
            )

            previous_hash = "0" * 64
            rows = connection.execute(
                "SELECT * FROM evidence_audit_events WHERE tenant_id=? ORDER BY sequence",
                ("tenant-a",),
            ).fetchall()
            for row in rows:
                detail = json.loads(row["detail_json"])
                if row["action"] == "package.locked":
                    detail["package_payload_sha256"] = forged_payload_hash
                    detail["package_revision"] = locked.revision
                event_payload = {
                    "event_id": row["event_id"],
                    "tenant_id": row["tenant_id"],
                    "package_id": row["package_id"],
                    "action": row["action"],
                    "actor": row["actor"],
                    "occurred_at": row["occurred_at"],
                    "detail": detail,
                    "previous_event_hash": previous_hash,
                }
                if "key_version" in row.keys():
                    event_payload["key_version"] = row["key_version"]
                event_hash = hashlib.sha256(
                    canonical_json_bytes(event_payload)
                ).hexdigest()
                connection.execute(
                    "UPDATE evidence_audit_events "
                    "SET detail_json=?,previous_event_hash=?,event_hash=? WHERE sequence=?",
                    (
                        canonical_json_bytes(detail).decode("utf-8"),
                        previous_hash,
                        event_hash,
                        row["sequence"],
                    ),
                )
                previous_hash = event_hash
            connection.commit()

        self.assertFalse(self.store.verify_audit_chain("tenant-a"))
        with self.assertRaises(IntegrityError):
            self.service.get("tenant-a", locked.package_id)

    def test_deleting_all_audit_rows_is_detected_when_packages_exist(self) -> None:
        created = self._create(package_fixture(package_id="evpkg-deleted-audit"))
        with sqlite3.connect(self.db_path) as connection:
            connection.execute(
                "DELETE FROM evidence_audit_events WHERE tenant_id=?",
                ("tenant-a",),
            )
            connection.commit()

        self.assertFalse(self.store.verify_audit_chain("tenant-a"))
        with self.assertRaises(IntegrityError):
            self.service.get("tenant-a", created.package_id)
        with self.assertRaises(IntegrityError):
            self.service.list("tenant-a")

    def test_draft_payload_tampering_cannot_be_laundered_through_lock(self) -> None:
        created = self._create(package_fixture(package_id="evpkg-draft-tamper"))
        with sqlite3.connect(self.db_path) as connection:
            raw = connection.execute(
                "SELECT payload_json FROM evidence_packages WHERE tenant_id=? AND package_id=?",
                ("tenant-a", created.package_id),
            ).fetchone()[0]
            payload = json.loads(raw)
            payload["use_case"] = "tampered_research_use_case"
            connection.execute(
                "UPDATE evidence_packages SET payload_json=? WHERE tenant_id=? AND package_id=?",
                (json.dumps(payload), "tenant-a", created.package_id),
            )
            connection.commit()

        with self.assertRaises(IntegrityError):
            self.service.get("tenant-a", created.package_id)
        with self.assertRaises(IntegrityError):
            self.service.list("tenant-a")
        with self.assertRaises(IntegrityError):
            self.service.lock(
                "tenant-a",
                created.package_id,
                actor="independent-reviewer",
                expected_revision=created.revision,
            )

    def test_locked_reads_reject_payload_that_no_longer_matches_content_hash(self) -> None:
        created = self._create(package_fixture(package_id="evpkg-locked-tamper"))
        locked = self.service.lock(
            "tenant-a",
            created.package_id,
            actor="independent-reviewer",
            expected_revision=created.revision,
        )
        with sqlite3.connect(self.db_path) as connection:
            raw = connection.execute(
                "SELECT payload_json FROM evidence_packages WHERE tenant_id=? AND package_id=?",
                ("tenant-a", locked.package_id),
            ).fetchone()[0]
            payload = json.loads(raw)
            payload["use_case"] = "tampered_research_use_case"
            connection.execute(
                "UPDATE evidence_packages SET payload_json=? WHERE tenant_id=? AND package_id=?",
                (json.dumps(payload), "tenant-a", locked.package_id),
            )
            connection.commit()

        with self.assertRaises(IntegrityError):
            self.service.get("tenant-a", locked.package_id)
        with self.assertRaises(IntegrityError):
            self.service.list("tenant-a")

    def test_duplicate_id_and_optimistic_revision_are_conflicts(self) -> None:
        package = self._create(package_fixture())
        with self.assertRaises(ConflictError):
            self._create(package_fixture())
        extra = replace(
            package.measurements[0],
            envelope_id="measurement-003",
            sequence=3,
            source_hash="",
        )
        updated = self.service.add_measurement(
            "tenant-a", package.package_id, extra, actor="package-author", expected_revision=0
        )
        self.assertEqual(updated.revision, 1)
        with self.assertRaises(ConflictError):
            self.service.add_measurement(
                "tenant-a",
                package.package_id,
                replace(extra, envelope_id="measurement-004", source_hash=""),
                actor="package-author", expected_revision=0,
            )

    def test_root_create_cannot_forge_or_skip_revision_lineage(self) -> None:
        source = self._create(package_fixture(package_id="evpkg-lineage-root"))
        locked = self.service.lock(
            "tenant-a", source.package_id,
            actor="independent-reviewer", expected_revision=source.revision,
        )
        released = self.service.release(
            "tenant-a", locked.package_id,
            actor="release-officer", expected_revision=locked.revision,
        )
        forged = replace(
            without_counterpart_outcomes(
                package_fixture(package_id="evpkg-forged-v99")
            ),
            version=99,
            previous_version_id=released.package_id,
        )
        with self.assertRaisesRegex(DomainValidationError, "root version"):
            self.service.create(
                forged,
                actor=forged.created_by,
                verification_actor=forged.model_verifications[0].verifier_id,
                protocol_approval_actor=forged.protocol.approved_by,
            )
        with self.assertRaisesRegex(DomainValidationError, "root version"):
            self.store.create(
                forged,
                actor=forged.created_by,
                verification_actor=forged.model_verifications[0].verifier_id,
            )

    def test_create_rejects_preloaded_validation_events(self) -> None:
        prevalidated = package_fixture(
            source_data_class=SourceDataClass.REAL_HUMAN,
            validation_dimensions=(
                ValidationDimension.MODEL_VERIFICATION,
                ValidationDimension.BIOLOGICAL_CONCORDANCE,
            ),
        )
        with self.assertRaises(DomainValidationError):
            self.service.create(
                prevalidated,
                actor="package-author",
                verification_actor="model-verifier",
                protocol_approval_actor="protocol-approver",
            )

    def test_create_rejects_preloaded_outcomes_and_requires_prospective_intake(self) -> None:
        candidate = package_fixture(package_id="evpkg-preloaded-outcome")
        with self.assertRaisesRegex(DomainValidationError, "cannot preload counterpart outcomes"):
            self.service.create(
                candidate,
                actor="package-author",
                verification_actor="model-verifier",
                protocol_approval_actor="protocol-approver",
            )

        created = self._create(candidate)
        retrospective_outcome = candidate.measurements[1]
        with self.assertRaisesRegex(
            DomainValidationError,
            "signed package-creation audit event",
        ):
            self.service.add_measurement(
                "tenant-a",
                created.package_id,
                retrospective_outcome,
                actor="package-author",
                expected_revision=created.revision,
            )

    def test_create_rejects_materially_future_package_timestamp(self) -> None:
        candidate = without_counterpart_outcomes(
            package_fixture(package_id="evpkg-future-create")
        )
        future_candidate = replace(
            candidate,
            created_at=datetime.now(UTC) + timedelta(minutes=10),
        )
        with self.assertRaisesRegex(DomainValidationError, "materially in the future"):
            self.service.create(
                future_candidate,
                actor=future_candidate.created_by,
                verification_actor=future_candidate.model_verifications[0].verifier_id,
                protocol_approval_actor=future_candidate.protocol.approved_by,
            )

    def test_model_verification_requires_authenticated_verifier_and_pass_before_lock(self) -> None:
        verified = without_counterpart_outcomes(
            package_fixture(package_id="evpkg-verifier-auth")
        )
        with self.assertRaises(DomainValidationError):
            self.service.create(
                verified,
                actor="package-author",
                protocol_approval_actor="protocol-approver",
            )

        missing = replace(
            without_counterpart_outcomes(
                package_fixture(package_id="evpkg-missing-verification")
            ),
            model_verifications=(),
        )
        created_missing = self.service.create(
            missing,
            actor="package-author",
            protocol_approval_actor="protocol-approver",
        )
        self.assertEqual(created_missing.claim_state, ClaimState.SYNTHETIC)
        with self.assertRaises(DomainValidationError):
            self.service.lock(
                "tenant-a",
                created_missing.package_id,
                actor="independent-reviewer",
                expected_revision=0,
            )

    def test_protocol_approval_requires_authenticated_separate_approver(self) -> None:
        package = package_fixture(package_id="evpkg-protocol-approval-auth")
        with self.assertRaises(DomainValidationError):
            self.service.create(
                package,
                actor="package-author",
                verification_actor="model-verifier",
            )
        with self.assertRaises(DomainValidationError):
            self.service.create(
                package,
                actor="package-author",
                verification_actor="model-verifier",
                protocol_approval_actor="package-author",
            )

    def test_failed_model_verification_cannot_be_locked(self) -> None:
        failed = replace(
            without_counterpart_outcomes(
                package_fixture(package_id="evpkg-failed-verification")
            ),
            model_verifications=(
                replace(
                    package_fixture().model_verifications[0],
                    disposition=AssessmentStatus.FAIL,
                    evidence_hashes=(),
                ),
            ),
        )
        created_failed = self.service.create(
            failed,
            actor="package-author",
            verification_actor="model-verifier",
            protocol_approval_actor="protocol-approver",
        )
        self.assertEqual(created_failed.claim_state, ClaimState.SYNTHETIC)
        with self.assertRaises(DomainValidationError):
            self.service.lock(
                "tenant-a",
                created_failed.package_id,
                actor="independent-reviewer",
                expected_revision=0,
            )

    def test_idempotency_key_cannot_replay_a_different_resource(self) -> None:
        first = self._create(package_fixture(package_id="evpkg-first"))
        second = self._create(package_fixture(package_id="evpkg-second"))
        self.service.lock(
            "tenant-a", first.package_id, actor="independent-reviewer",
            expected_revision=0, idempotency_key="same-lock-key",
        )
        with self.assertRaises(ConflictError):
            self.service.lock(
                "tenant-a", second.package_id, actor="independent-reviewer",
                expected_revision=0, idempotency_key="same-lock-key",
            )

    def test_lifecycle_immutability_release_replacement_and_retraction(self) -> None:
        created = self._create(package_fixture())
        locked = self.service.lock(
            "tenant-a", created.package_id, actor="independent-reviewer", expected_revision=0
        )
        self.assertEqual(locked.lifecycle, LifecycleStatus.LOCKED)
        self.assertTrue(self.service.verify("tenant-a", locked.package_id))
        with self.assertRaises(ImmutablePackageError):
            self.service.add_measurement(
                "tenant-a", locked.package_id, locked.measurements[0],
                actor="package-author", expected_revision=locked.revision,
            )
        with self.assertRaisesRegex(InvalidTransitionError, "source must be released"):
            self.service.create_revision(
                "tenant-a",
                locked.package_id,
                new_package_id="evpkg-skipped-release",
                actor="package-author",
                expected_revision=locked.revision,
            )
        released = self.service.release(
            "tenant-a", locked.package_id, actor="release-officer", expected_revision=locked.revision
        )
        self.assertEqual(released.lifecycle, LifecycleStatus.RELEASED)
        self.assertEqual(released.content_hash, locked.content_hash)
        revision = self.service.create_revision(
            "tenant-a",
            released.package_id,
            new_package_id="evpkg-002",
            actor="package-author",
            expected_revision=released.revision,
        )
        self.assertEqual(revision.lifecycle, LifecycleStatus.DRAFT)
        self.assertEqual(revision.previous_version_id, released.package_id)
        replacement_locked = self.service.lock(
            "tenant-a", revision.package_id, actor="independent-reviewer", expected_revision=0
        )
        replacement_released = self.service.release(
            "tenant-a", revision.package_id, actor="release-officer",
            expected_revision=replacement_locked.revision,
        )
        self.assertEqual(replacement_released.lifecycle, LifecycleStatus.RELEASED)
        self.assertEqual(
            self.service.get("tenant-a", released.package_id).lifecycle,
            LifecycleStatus.SUPERSEDED,
        )
        retracted = self.service.retract(
            "tenant-a", replacement_released.package_id, actor="safety-officer",
            reason="source data withdrawn", expected_revision=replacement_released.revision,
        )
        self.assertEqual(retracted.lifecycle, LifecycleStatus.RETRACTED)
        with self.assertRaises(InvalidTransitionError):
            self.service.release(
                "tenant-a", retracted.package_id, actor="release-officer",
                expected_revision=retracted.revision,
            )

    def test_retracted_predecessor_cannot_be_resurrected_by_a_draft_revision(self) -> None:
        created = self._create(package_fixture(package_id="evpkg-lineage-v1"))
        locked = self.service.lock(
            "tenant-a",
            created.package_id,
            actor="independent-reviewer",
            expected_revision=created.revision,
        )
        released = self.service.release(
            "tenant-a",
            locked.package_id,
            actor="release-officer",
            expected_revision=locked.revision,
        )
        revision = self.service.create_revision(
            "tenant-a",
            released.package_id,
            new_package_id="evpkg-lineage-v2",
            actor="package-author",
            expected_revision=released.revision,
        )
        retracted = self.service.retract(
            "tenant-a",
            released.package_id,
            actor="safety-officer",
            reason="source data withdrawn",
            expected_revision=released.revision,
        )
        with self.assertRaisesRegex(InvalidTransitionError, "ancestor retraction"):
            self.service.lock(
                "tenant-a",
                revision.package_id,
                actor="independent-reviewer",
                expected_revision=revision.revision,
            )
        self.assertEqual(retracted.lifecycle, LifecycleStatus.RETRACTED)
        self.assertEqual(
            self.service.get("tenant-a", revision.package_id).lifecycle,
            LifecycleStatus.DRAFT,
        )

    def test_draft_descendant_does_not_deadlock_ordered_lineage_retraction(self) -> None:
        root = self._create(package_fixture(package_id="evpkg-deadlock-a"))
        root = self.service.lock(
            "tenant-a", root.package_id, actor="independent-reviewer",
            expected_revision=root.revision,
        )
        root = self.service.release(
            "tenant-a", root.package_id, actor="release-officer",
            expected_revision=root.revision,
        )
        replacement = self.service.create_revision(
            "tenant-a", root.package_id, new_package_id="evpkg-deadlock-b",
            actor="package-author", expected_revision=root.revision,
        )
        replacement = self.service.lock(
            "tenant-a", replacement.package_id, actor="independent-reviewer",
            expected_revision=replacement.revision,
        )
        replacement = self.service.release(
            "tenant-a", replacement.package_id, actor="release-officer",
            expected_revision=replacement.revision,
        )
        draft = self.service.create_revision(
            "tenant-a", replacement.package_id, new_package_id="evpkg-deadlock-c",
            actor="package-author", expected_revision=replacement.revision,
        )
        replacement = self.service.retract(
            "tenant-a", replacement.package_id, actor="safety-officer",
            reason="replacement withdrawn", expected_revision=replacement.revision,
        )
        ancestor = self.service.get("tenant-a", root.package_id)
        ancestor = self.service.retract(
            "tenant-a", ancestor.package_id, actor="safety-officer",
            reason="lineage terminated", expected_revision=ancestor.revision,
        )
        self.assertEqual(replacement.lifecycle, LifecycleStatus.RETRACTED)
        self.assertEqual(ancestor.lifecycle, LifecycleStatus.RETRACTED)
        with self.assertRaisesRegex(InvalidTransitionError, "ancestor retraction"):
            self.service.lock(
                "tenant-a", draft.package_id, actor="independent-reviewer",
                expected_revision=draft.revision,
            )

    def test_superseded_ancestor_retraction_requires_active_descendant_first(self) -> None:
        created = self._create(package_fixture(package_id="evpkg-ancestor-v1"))
        locked = self.service.lock(
            "tenant-a", created.package_id,
            actor="independent-reviewer", expected_revision=created.revision,
        )
        released = self.service.release(
            "tenant-a", locked.package_id,
            actor="release-officer", expected_revision=locked.revision,
        )
        revision = self.service.create_revision(
            "tenant-a", released.package_id,
            new_package_id="evpkg-ancestor-v2",
            actor="package-author", expected_revision=released.revision,
        )
        revision_locked = self.service.lock(
            "tenant-a", revision.package_id,
            actor="independent-reviewer", expected_revision=revision.revision,
        )
        revision_released = self.service.release(
            "tenant-a", revision_locked.package_id,
            actor="release-officer", expected_revision=revision_locked.revision,
        )
        ancestor = self.service.get("tenant-a", released.package_id)
        self.assertEqual(ancestor.lifecycle, LifecycleStatus.SUPERSEDED)
        with self.assertRaisesRegex(InvalidTransitionError, "descendant remains active"):
            self.service.retract(
                "tenant-a", ancestor.package_id,
                actor="safety-officer", reason="source withdrawn",
                expected_revision=ancestor.revision,
            )

        descendant_retracted = self.service.retract(
            "tenant-a", revision_released.package_id,
            actor="safety-officer", reason="source withdrawn",
            expected_revision=revision_released.revision,
        )
        ancestor_retracted = self.service.retract(
            "tenant-a", ancestor.package_id,
            actor="safety-officer", reason="source withdrawn",
            expected_revision=ancestor.revision,
        )
        self.assertEqual(descendant_retracted.lifecycle, LifecycleStatus.RETRACTED)
        self.assertEqual(ancestor_retracted.lifecycle, LifecycleStatus.RETRACTED)

    def test_default_runtime_cannot_read_list_or_lock_governed_measurements(self) -> None:
        path = Path(self.tmp.name) / "governed-evidence.sqlite3"
        unsafe = EvidenceService(
            EvidenceStore(path),
            unsafe_test_only_allow_non_synthetic=True,
            unsafe_test_only_allow_preloaded_verification=True,
        )
        candidate = package_fixture(
            package_id="evpkg-governed-data",
            source_data_class=SourceDataClass.REAL_HUMAN,
        )
        initial = without_counterpart_outcomes(candidate)
        unsafe.create(
            initial,
            actor=initial.created_by,
            verification_actor=initial.model_verifications[0].verifier_id,
            protocol_approval_actor=initial.protocol.approved_by,
        )
        unsafe.close()

        default = EvidenceService(EvidenceStore(path))
        try:
            with self.assertRaisesRegex(DomainValidationError, "blocked in the local plaintext"):
                default.get("tenant-a", initial.package_id)
            with self.assertRaisesRegex(DomainValidationError, "blocked in the local plaintext"):
                default.list("tenant-a")
            with self.assertRaisesRegex(DomainValidationError, "blocked in the local plaintext"):
                default.lock(
                    "tenant-a",
                    initial.package_id,
                    actor="independent-reviewer",
                    expected_revision=0,
                )
        finally:
            default.close()

    def test_concurrent_lock_creates_one_lifecycle_event(self) -> None:
        package = self._create(package_fixture())
        barrier = threading.Barrier(2)
        outcomes: list[str] = []

        def lock_package() -> None:
            local = EvidenceService(EvidenceStore(self.db_path))
            barrier.wait()
            try:
                result = local.lock(
                    "tenant-a", package.package_id, actor="independent-reviewer", expected_revision=0
                )
                outcomes.append(result.lifecycle.value)
            except ConflictError:
                outcomes.append("conflict")
            finally:
                local.store.close()

        threads = [threading.Thread(target=lock_package) for _ in range(2)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        self.assertEqual(outcomes.count("locked"), 1)
        self.assertEqual(outcomes.count("conflict"), 1)
        events = self.store.audit_events("tenant-a", package.package_id)
        self.assertEqual(sum(event["action"] == "package.locked" for event in events), 1)
        self.assertTrue(self.store.verify_audit_chain("tenant-a"))

    def test_lock_idempotency_key_replays_the_same_result(self) -> None:
        package = self._create(package_fixture())
        first = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=0, idempotency_key="lock-request-001",
        )
        replay = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=0, idempotency_key="lock-request-001",
        )
        self.assertEqual(replay, first)
        events = self.store.audit_events("tenant-a", package.package_id)
        self.assertEqual(sum(event["action"] == "package.locked" for event in events), 1)


class SigningKeyFileSecurityTests(unittest.TestCase):
    @staticmethod
    def _private_key_bytes() -> bytes:
        return Ed25519PrivateKey.generate().private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )

    @staticmethod
    def _environment(key_path: Path, environment: str) -> dict[str, str]:
        return {
            "LIVEMORE_ENVIRONMENT": environment,
            "LIVEMORE_EVIDENCE_SIGNING_KEY": "",
            "LIVEMORE_EVIDENCE_SIGNING_KEY_FILE": str(key_path),
            "LIVEMORE_EVIDENCE_SIGNING_KEY_ID": "key-file-security-test",
        }

    def test_production_rejects_group_or_world_readable_key_without_chmod(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            key_parent = root / "operator-keys"
            key_parent.mkdir(mode=0o755)
            os.chmod(key_parent, 0o755)
            key_path = key_parent / "issuer.key"
            key_path.write_bytes(self._private_key_bytes())
            os.chmod(key_path, 0o640)

            with patch.dict(
                os.environ,
                self._environment(key_path, "production"),
                clear=False,
            ):
                with self.assertRaisesRegex(
                    SigningConfigurationError,
                    "must not grant group or world access",
                ):
                    IssuerSigner.load(root / "exports")

            self.assertEqual(os.stat(key_path).st_mode & 0o777, 0o640)
            self.assertEqual(os.stat(key_parent).st_mode & 0o777, 0o755)

    def test_development_reads_existing_operator_key_without_chmod(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            key_parent = root / "operator-keys"
            key_parent.mkdir(mode=0o755)
            os.chmod(key_parent, 0o755)
            key_path = key_parent / "issuer.key"
            key_path.write_bytes(self._private_key_bytes())
            os.chmod(key_path, 0o644)

            with patch.dict(
                os.environ,
                self._environment(key_path, "development"),
                clear=False,
            ):
                signer = IssuerSigner.load(root / "exports")

            self.assertEqual(signer.key_path, key_path)
            self.assertEqual(os.stat(key_path).st_mode & 0o777, 0o644)
            self.assertEqual(os.stat(key_parent).st_mode & 0o777, 0o755)

    def test_development_retries_when_a_concurrent_writer_publishes_the_key(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            key_path = root / "operator-keys" / "issuer.key"
            real_read = evidence_signing._read_private_key
            attempts = 0

            def publish_then_report_stale_missing(
                path: Path, *, production: bool | None = None
            ) -> Ed25519PrivateKey:
                nonlocal attempts
                attempts += 1
                if attempts == 1:
                    path.parent.mkdir(parents=True, mode=0o700)
                    path.write_bytes(self._private_key_bytes())
                    os.chmod(path, 0o600)
                    try:
                        raise FileNotFoundError(path)
                    except FileNotFoundError as missing:
                        raise SigningConfigurationError(
                            "evidence signing key file is unavailable"
                        ) from missing
                return real_read(path, production=production)

            with patch.dict(
                os.environ,
                self._environment(key_path, "development"),
                clear=False,
            ), patch.object(
                evidence_signing,
                "_read_private_key",
                side_effect=publish_then_report_stale_missing,
            ):
                signer = IssuerSigner.load(root / "exports")

            self.assertEqual(attempts, 2)
            self.assertEqual(signer.key_path, key_path)

    @unittest.skipUnless(hasattr(os, "O_NOFOLLOW"), "O_NOFOLLOW is unavailable")
    def test_key_file_symlink_is_rejected_without_touching_target(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            target = root / "operator.key"
            target.write_bytes(self._private_key_bytes())
            os.chmod(target, 0o600)
            link = root / "configured.key"
            link.symlink_to(target)

            with patch.dict(
                os.environ,
                self._environment(link, "production"),
                clear=False,
            ):
                with self.assertRaisesRegex(
                    SigningConfigurationError,
                    "key file is unavailable",
                ):
                    IssuerSigner.load(root / "exports")

            self.assertTrue(link.is_symlink())
            self.assertEqual(os.stat(target).st_mode & 0o777, 0o600)

    def test_non_regular_key_file_is_rejected_without_chmod(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            key_path = root / "operator-key-directory"
            key_path.mkdir(mode=0o750)
            os.chmod(key_path, 0o750)

            with patch.dict(
                os.environ,
                self._environment(key_path, "production"),
                clear=False,
            ):
                with self.assertRaisesRegex(
                    SigningConfigurationError,
                    "must be a regular file",
                ):
                    IssuerSigner.load(root / "exports")

            self.assertEqual(os.stat(key_path).st_mode & 0o777, 0o750)


class ValidationAndExportTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.audit_clock = patch("livemorebio.evidence.store.utc_now", return_value=T0)
        self.audit_clock.start()
        self.signing_key_path = Path(self.tmp.name) / "issuer-keys" / "evidence-ed25519.key"
        self.signing_environment = patch.dict(
            os.environ,
            {
                "LIVEMORE_ENVIRONMENT": "test",
                "LIVEMORE_EVIDENCE_SIGNING_KEY": "",
                "LIVEMORE_EVIDENCE_SIGNING_KEY_FILE": str(self.signing_key_path),
                "LIVEMORE_EVIDENCE_SIGNING_KEY_ID": "test-evidence-issuer-2026",
            },
            clear=False,
        )
        self.signing_environment.start()
        self.store = EvidenceStore(Path(self.tmp.name) / "evidence.sqlite3")
        self.service = EvidenceService(
            self.store,
            unsafe_test_only_allow_non_synthetic=True,
            unsafe_test_only_allow_preloaded_verification=True,
        )

    def tearDown(self) -> None:
        self.store.close()
        self.signing_environment.stop()
        self.audit_clock.stop()
        self.tmp.cleanup()

    def _trusted_public_key(self) -> bytes:
        private_key = Ed25519PrivateKey.from_private_bytes(self.signing_key_path.read_bytes())
        return private_key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

    def _create(self, package: EvidencePackageVersion) -> EvidencePackageVersion:
        outcomes = tuple(
            measurement
            for measurement in package.measurements
            if measurement.role is MeasurementRole.COUNTERPART_OUTCOME
        )
        current = self.service.create(
            without_counterpart_outcomes(package),
            actor=package.created_by,
            verification_actor=(
                package.model_verifications[0].verifier_id
                if package.model_verifications
                else None
            ),
            protocol_approval_actor=package.protocol.approved_by,
        )
        for outcome in outcomes:
            current = self.service.add_measurement(
                package.tenant_id,
                package.package_id,
                outcome,
                actor=package.created_by,
                expected_revision=current.revision,
            )
        return current

    def _create_reviewed(self, package: EvidencePackageVersion) -> EvidencePackageVersion:
        events = package.validation_events
        event_hashes = {event.analysis_hash for event in events}
        initial = replace(
            package,
            validation_events=(),
            provenance=replace(
                package.provenance,
                content_hashes=tuple(
                    item
                    for item in package.provenance.content_hashes
                    if item not in event_hashes
                ),
            ),
        )
        current = self._create(initial)
        for event in events:
            current = self.service.add_validation(
                package.tenant_id,
                package.package_id,
                event,
                actor=event.reviewer_id,
                expected_revision=current.revision,
            )
        return current

    def test_future_counterpart_measurement_is_rejected_before_draft_mutation(self) -> None:
        candidate = package_fixture(
            package_id="evpkg-future-outcome-intake", validation_dimensions=()
        )
        current = self.service.create(
            without_counterpart_outcomes(candidate),
            actor=candidate.created_by,
            verification_actor=candidate.model_verifications[0].verifier_id,
            protocol_approval_actor=candidate.protocol.approved_by,
        )
        outcome = next(
            item
            for item in candidate.measurements
            if item.role is MeasurementRole.COUNTERPART_OUTCOME
        )
        future_time = datetime.now(UTC) + timedelta(days=365)
        future = replace(
            outcome,
            payload=replace(outcome.payload, measured_at=future_time),
            received_at=future_time + timedelta(seconds=1),
            source_hash="",
        )
        with self.assertRaisesRegex(DomainValidationError, "materially in the future"):
            self.service.add_measurement(
                "tenant-a", current.package_id, future, actor="package-author",
                expected_revision=current.revision,
            )
        self.assertEqual(
            self.service.get("tenant-a", current.package_id).measurements,
            current.measurements,
        )

    def test_bound_visualization_survives_lock_and_signed_export(self) -> None:
        package = self._create(
            package_fixture(package_id="evpkg-visualization-export")
        )
        locked = self.service.lock(
            package.tenant_id,
            package.package_id,
            actor="independent-reviewer",
            expected_revision=package.revision,
        )
        exported = self.service.export(
            package.tenant_id,
            package.package_id,
            Path(self.tmp.name) / "visualization-export",
            actor="exporter",
        )
        evidence = json.loads(
            (exported.directory / "evidence.json").read_text(encoding="utf-8")
        )
        manifest = evidence["visualization_manifest"]
        mapping = manifest["mappings"][0]
        self.assertIn(mapping["target_id"], manifest["anatomy_asset_ids"])
        self.assertEqual(mapping["evidence_ref"], locked.predictions[0].prediction_id)
        self.assertEqual(mapping["data_class"], SourceDataClass.MODELED.value)
        self.assertEqual(mapping["unit"], locked.predictions[0].outputs[0].unit)
        verify_signed_export(exported.directory, self._trusted_public_key())

    def test_validation_rejects_mismatched_endpoint_unit_time_and_policy(self) -> None:
        package = self._create(
            package_fixture(source_data_class=SourceDataClass.REAL_HUMAN, validation_dimensions=())
        )
        event = package_fixture(
            source_data_class=SourceDataClass.REAL_HUMAN,
            validation_dimensions=(ValidationDimension.BIOLOGICAL_CONCORDANCE,),
        ).validation_events[0]
        for forged in (
            replace(event, endpoint="AST"),
            replace(event, unit="mg/dL"),
            replace(event, time_window_compatible=False),
            replace(event, policy_hash="f" * 64),
            replace(event, reviewer_id="model-author"),
        ):
            with self.subTest(forged=forged):
                with self.assertRaises(DomainValidationError):
                    self.service.add_validation(
                        "tenant-a", package.package_id, forged,
                        actor="independent-reviewer", expected_revision=package.revision,
                    )

    def test_validation_metric_and_disposition_are_recomputed_from_bound_values(self) -> None:
        package = self._create(
            package_fixture(
                source_data_class=SourceDataClass.REAL_HUMAN,
                validation_dimensions=(),
                measurement_value=Decimal("999.0"),
            )
        )
        computed_failure = package_fixture(
            source_data_class=SourceDataClass.REAL_HUMAN,
            validation_dimensions=(ValidationDimension.BIOLOGICAL_CONCORDANCE,),
            measurement_value=Decimal("999.0"),
        ).validation_events[0]
        forged = replace(
            computed_failure,
            metric_value=Decimal("2.0"),
            disposition=AssessmentStatus.PASS,
            protocol_criterion_passed=True,
        )
        with self.assertRaises(DomainValidationError):
            self.service.add_validation(
                "tenant-a",
                package.package_id,
                forged,
                actor="independent-reviewer",
                expected_revision=package.revision,
            )

    def test_create_model_only_public_contract_is_conservatively_modeled(self) -> None:
        source = package_fixture(include_measurement=False)
        created = self.service.create_model_only(
            tenant_id=source.tenant_id,
            package_id="evpkg-model-only",
            use_case=source.use_case,
            claim=source.claim,
            policy=source.policy,
            context_of_use=source.context_of_use,
            protocol=source.protocol,
            prediction=source.predictions[0],
            provenance=source.provenance,
            visualization_manifest=source.visualization_manifest,
            created_by="package-author",
            created_at=T0,
            protocol_approval_actor=source.protocol.approved_by,
        )
        self.assertEqual(created.claim_state, ClaimState.MODELED)
        self.assertEqual(created.measurements, ())
        self.assertEqual(created.validation_events, ())

    def test_unresolved_development_build_can_lock_and_export_but_cannot_release(self) -> None:
        source = package_fixture(
            package_id="evpkg-unresolved-development",
            include_measurement=False,
        )
        scenario = replace(
            source.predictions[0].scenario_snapshot,
            code_version="working-tree-development-build",
            state_hash="",
        )
        prediction = replace(
            source.predictions[0],
            scenario_snapshot=scenario,
            code_version="working-tree-development-build",
            container_digest="not-containerized-development-runtime",
            input_hash="",
        )
        created = self.service.create_model_only(
            tenant_id=source.tenant_id,
            package_id=source.package_id,
            use_case=source.use_case,
            claim=source.claim,
            policy=source.policy,
            context_of_use=source.context_of_use,
            protocol=source.protocol,
            prediction=prediction,
            provenance=replace(
                source.provenance,
                code_commit="working-tree-development-build",
                content_hashes=source.provenance.content_hashes
                + (scenario.state_hash, prediction.input_hash),
            ),
            visualization_manifest=source.visualization_manifest,
            created_by=source.created_by,
            created_at=source.created_at,
            protocol_approval_actor=source.protocol.approved_by,
        )
        locked = self.service.lock(
            source.tenant_id,
            source.package_id,
            actor="independent-reviewer",
            expected_revision=created.revision,
        )
        exported = self.service.export(
            source.tenant_id,
            source.package_id,
            Path(self.tmp.name) / "development-export",
            actor="exporter",
        )
        self.assertTrue(exported.archive_path.exists())
        with self.assertRaisesRegex(DomainValidationError, "immutable provenance"):
            self.service.release(
                source.tenant_id,
                source.package_id,
                actor="release-officer",
                expected_revision=locked.revision,
            )
        with patch.dict(os.environ, {"LIVEMORE_ENVIRONMENT": "production"}, clear=False):
            with self.assertRaisesRegex(DomainValidationError, "immutable provenance"):
                self.service.export(
                    source.tenant_id,
                    source.package_id,
                    Path(self.tmp.name) / "production-export",
                    actor="exporter",
                )

    def test_release_rejects_non_content_addressed_model_and_dataset_versions(self) -> None:
        for index, mutable_identity in enumerate(("latest", "latest-1", "model1"), start=1):
            with self.subTest(mutable_identity=mutable_identity):
                source = package_fixture(
                    package_id=f"evpkg-mutable-identity-{index}",
                    include_measurement=False,
                )
                scenario = replace(
                    source.predictions[0].scenario_snapshot,
                    model_versions=(mutable_identity,),
                    dataset_versions=(mutable_identity,),
                    state_hash="",
                )
                prediction = replace(
                    source.predictions[0],
                    scenario_snapshot=scenario,
                    model_versions=(mutable_identity,),
                    dataset_versions=(mutable_identity,),
                    input_hash="",
                )
                created = self.service.create_model_only(
                    tenant_id=source.tenant_id,
                    package_id=source.package_id,
                    use_case=source.use_case,
                    claim=source.claim,
                    policy=source.policy,
                    context_of_use=source.context_of_use,
                    protocol=source.protocol,
                    prediction=prediction,
                    provenance=replace(
                        source.provenance,
                        model_versions=(mutable_identity,),
                        content_hashes=source.provenance.content_hashes
                        + (scenario.state_hash, prediction.input_hash),
                    ),
                    visualization_manifest=source.visualization_manifest,
                    created_by=source.created_by,
                    created_at=source.created_at,
                    protocol_approval_actor=source.protocol.approved_by,
                )
                locked = self.service.lock(
                    source.tenant_id,
                    source.package_id,
                    actor="independent-reviewer",
                    expected_revision=created.revision,
                )
                with self.assertRaisesRegex(DomainValidationError, "scenario model version"):
                    self.service.release(
                        source.tenant_id,
                        source.package_id,
                        actor="release-officer",
                        expected_revision=locked.revision,
                    )

    def test_calibration_authorization_requires_every_policy_dimension_to_pass(self) -> None:
        incomplete = self._create_reviewed(
            package_fixture(
                package_id="evpkg-pharma-incomplete",
                source_data_class=SourceDataClass.REAL_HUMAN,
                validation_dimensions=(ValidationDimension.BIOLOGICAL_CONCORDANCE,),
                endpoint="hba1c",
                unit="%",
                predicted_value=Decimal("7.0"),
                measurement_value=Decimal("7.5"),
                baseline_value=Decimal("8.0"),
            )
        )
        self.assertEqual(incomplete.claim_state, ClaimState.CALIBRATED)
        incomplete_status = {
            assessment.dimension: assessment.status
            for assessment in incomplete.validation_summary
        }
        self.assertEqual(
            incomplete_status[ValidationDimension.DEVICE_ANALYTICAL_VALIDITY],
            AssessmentStatus.NOT_ASSESSED,
        )
        self.assertEqual(
            incomplete_status[ValidationDimension.ASSAY_VALIDITY],
            AssessmentStatus.NOT_ASSESSED,
        )
        incomplete = self.service.lock(
            "tenant-a",
            incomplete.package_id,
            actor="independent-reviewer",
            expected_revision=incomplete.revision,
        )
        incomplete = self.service.release(
            "tenant-a",
            incomplete.package_id,
            actor="release-officer",
            expected_revision=incomplete.revision,
        )
        with self.assertRaisesRegex(
            CalibrationDeniedError,
            "every policy-required dimension",
        ):
            self.service.issue_calibration_authorization(
                "tenant-a",
                incomplete.package_id,
                "cendos-run-001",
                ("hba1c",),
                actor="independent-reviewer",
                reviewer_id="independent-reviewer",
            )

        complete = self._create_reviewed(
            package_fixture(
                package_id="evpkg-research-complete",
                source_data_class=SourceDataClass.REAL_HUMAN,
                validation_dimensions=(ValidationDimension.BIOLOGICAL_CONCORDANCE,),
                endpoint="hba1c",
                unit="%",
                predicted_value=Decimal("7.0"),
                measurement_value=Decimal("7.5"),
                baseline_value=Decimal("8.0"),
                policy=CALIBRATION_POLICY,
            )
        )
        complete_status = {
            assessment.dimension: assessment.status
            for assessment in complete.validation_summary
        }
        self.assertTrue(
            all(
                complete_status[dimension] is AssessmentStatus.PASS
                for dimension in complete.policy.required_dimensions
            )
        )
        complete = self.service.lock(
            "tenant-a",
            complete.package_id,
            actor="independent-reviewer",
            expected_revision=complete.revision,
        )
        complete = self.service.release(
            "tenant-a",
            complete.package_id,
            actor="release-officer",
            expected_revision=complete.revision,
        )
        authorization = self.service.issue_calibration_authorization(
            "tenant-a",
            complete.package_id,
            "cendos-run-001",
            ("hba1c",),
            actor="independent-reviewer",
            reviewer_id="independent-reviewer",
        )
        self.assertFalse(authorization.consumed)

    def test_synthetic_never_authorizes_calibration_but_real_evidence_does(self) -> None:
        synthetic = self._create(package_fixture())
        synthetic = self.service.lock(
            "tenant-a", synthetic.package_id, actor="independent-reviewer",
            expected_revision=synthetic.revision,
        )
        with self.assertRaises(CalibrationDeniedError):
            self.service.issue_calibration_authorization(
                "tenant-a", synthetic.package_id, "cendos-run-001", ("hba1c",),
                actor="independent-reviewer", reviewer_id="independent-reviewer",
            )

        real = self._create_reviewed(
            package_fixture(
                package_id="evpkg-real",
                source_data_class=SourceDataClass.REAL_HUMAN,
                validation_dimensions=(
                    ValidationDimension.MODEL_VERIFICATION,
                    ValidationDimension.BIOLOGICAL_CONCORDANCE,
                ),
                endpoint="hba1c",
                unit="%",
                predicted_value=Decimal("7.0"),
                measurement_value=Decimal("7.5"),
                baseline_value=Decimal("8.0"),
                policy=CALIBRATION_POLICY,
            )
        )
        real = self.service.lock(
            "tenant-a", real.package_id, actor="independent-reviewer",
            expected_revision=real.revision,
        )
        real = self.service.release(
            "tenant-a", real.package_id, actor="release-officer",
            expected_revision=real.revision,
        )
        authorization = self.service.issue_calibration_authorization(
            "tenant-a", real.package_id, "cendos-run-001", ("hba1c",),
            actor="independent-reviewer", reviewer_id="independent-reviewer",
        )
        self.assertFalse(authorization.consumed)
        consumed = self.service.consume_calibration_authorization(
            "tenant-a", authorization, cendos_run_id="cendos-run-001",
            live_twin_id="twin-001",
            actor="cendos-runtime",
        )
        self.assertTrue(consumed.consumed)
        with self.assertRaises(CalibrationDeniedError):
            self.service.consume_calibration_authorization(
                "tenant-a", authorization, cendos_run_id="cendos-run-001",
                live_twin_id="twin-001",
                actor="cendos-runtime",
            )
        with self.assertRaises(CalibrationDeniedError):
            self.service.consume_calibration_authorization(
                "tenant-a", {"validated": True},  # type: ignore[arg-type]
                cendos_run_id="cendos-run-001", live_twin_id="twin-001",
                actor="cendos-runtime",
            )

    def test_consumed_calibration_authorization_cannot_be_reset_and_replayed(self) -> None:
        real = self._create_reviewed(
            package_fixture(
                package_id="evpkg-calibration-replay",
                source_data_class=SourceDataClass.REAL_HUMAN,
                validation_dimensions=(ValidationDimension.BIOLOGICAL_CONCORDANCE,),
                endpoint="hba1c",
                unit="%",
                predicted_value=Decimal("7.0"),
                measurement_value=Decimal("7.5"),
                baseline_value=Decimal("8.0"),
                policy=CALIBRATION_POLICY,
            )
        )
        locked = self.service.lock(
            "tenant-a",
            real.package_id,
            actor="independent-reviewer",
            expected_revision=real.revision,
        )
        released = self.service.release(
            "tenant-a",
            locked.package_id,
            actor="release-officer",
            expected_revision=locked.revision,
        )
        authorization = self.service.issue_calibration_authorization(
            "tenant-a",
            released.package_id,
            "cendos-run-001",
            ("hba1c",),
            actor="independent-reviewer",
            reviewer_id="independent-reviewer",
        )
        self.service.consume_calibration_authorization(
            "tenant-a",
            authorization,
            cendos_run_id="cendos-run-001",
            live_twin_id="twin-001",
            actor="cendos-runtime",
        )

        with sqlite3.connect(self.store.path) as connection:
            raw = connection.execute(
                "SELECT payload_json FROM calibration_authorizations "
                "WHERE tenant_id=? AND authorization_id=?",
                ("tenant-a", authorization.authorization_id),
            ).fetchone()[0]
            payload = json.loads(raw)
            payload["consumed"] = False
            payload["consumed_at"] = None
            forged_payload = canonical_json_bytes(payload).decode("utf-8")
            forged_hash = hashlib.sha256(forged_payload.encode("utf-8")).hexdigest()
            connection.execute(
                "UPDATE calibration_authorizations "
                "SET consumed=0,payload_json=?,payload_sha256=? "
                "WHERE tenant_id=? AND authorization_id=?",
                (
                    forged_payload,
                    forged_hash,
                    "tenant-a",
                    authorization.authorization_id,
                ),
            )
            connection.commit()

        self.assertTrue(self.store.verify_audit_chain("tenant-a"))
        with self.assertRaises(IntegrityError):
            self.store.get_authorization("tenant-a", authorization.authorization_id)
        with self.assertRaises(CalibrationDeniedError):
            self.service.consume_calibration_authorization(
                "tenant-a",
                authorization,
                cendos_run_id="cendos-run-001",
                live_twin_id="twin-001",
                actor="cendos-runtime",
            )

    def test_retracted_package_invalidates_unconsumed_calibration_authorization(self) -> None:
        real = self._create_reviewed(
            package_fixture(
                package_id="evpkg-retracted-auth",
                source_data_class=SourceDataClass.REAL_HUMAN,
                validation_dimensions=(
                    ValidationDimension.MODEL_VERIFICATION,
                    ValidationDimension.BIOLOGICAL_CONCORDANCE,
                ),
                endpoint="hba1c",
                unit="%",
                predicted_value=Decimal("7.0"),
                measurement_value=Decimal("7.5"),
                baseline_value=Decimal("8.0"),
                policy=CALIBRATION_POLICY,
            )
        )
        locked = self.service.lock(
            "tenant-a", real.package_id, actor="independent-reviewer",
            expected_revision=real.revision,
        )
        released = self.service.release(
            "tenant-a", locked.package_id, actor="release-officer",
            expected_revision=locked.revision,
        )
        authorization = self.service.issue_calibration_authorization(
            "tenant-a", released.package_id, "cendos-run-001", ("hba1c",),
            actor="independent-reviewer", reviewer_id="independent-reviewer",
        )
        self.service.retract(
            "tenant-a", released.package_id, actor="safety-officer",
            reason="counterpart source withdrawn", expected_revision=released.revision,
        )
        with self.assertRaises(CalibrationDeniedError):
            self.service.consume_calibration_authorization(
                "tenant-a", authorization, cendos_run_id="cendos-run-001",
                live_twin_id="twin-001",
                actor="cendos-runtime",
            )

    def test_policy_revocation_blocks_authorization_consumption_but_not_safety_retraction(self) -> None:
        package = self._create_reviewed(
            package_fixture(
                package_id="evpkg-policy-revocation",
                source_data_class=SourceDataClass.REAL_HUMAN,
                validation_dimensions=(ValidationDimension.BIOLOGICAL_CONCORDANCE,),
                endpoint="hba1c",
                unit="%",
                predicted_value=Decimal("7.0"),
                measurement_value=Decimal("7.5"),
                baseline_value=Decimal("8.0"),
                policy=CALIBRATION_POLICY,
            )
        )
        package = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        package = self.service.release(
            "tenant-a", package.package_id, actor="release-officer",
            expected_revision=package.revision,
        )
        authorization = self.service.issue_calibration_authorization(
            "tenant-a", package.package_id, "cendos-run-001", ("hba1c",),
            actor="independent-reviewer", reviewer_id="independent-reviewer",
        )
        with self.assertRaisesRegex(
            DomainValidationError, "consumed before it is authorized"
        ):
            replace(
                authorization,
                consumed=True,
                consumed_at=authorization.authorized_at - timedelta(seconds=1),
            )
        impossible = replace(
            authorization,
            authorization_id="calibration-auth-before-release",
            authorized_at=package.released_at - timedelta(seconds=1),
        )
        with self.assertRaisesRegex(IntegrityError, "cannot precede evidence release"):
            self.store.create_authorization(impossible, actor="independent-reviewer")
        with patch("livemorebio.evidence.policies.APPROVED_POLICIES", {}):
            retracted = self.service.retract(
                "tenant-a", package.package_id, actor="safety-officer",
                reason="policy withdrawn", expected_revision=package.revision,
            )
            self.assertEqual(retracted.lifecycle, LifecycleStatus.RETRACTED)
            with self.assertRaisesRegex(CalibrationDeniedError, "no longer approved"):
                self.service.consume_calibration_authorization(
                    "tenant-a", authorization, cendos_run_id="cendos-run-001",
                    live_twin_id="twin-001", actor="cendos-runtime",
                )

    def test_export_losing_target_retraction_race_is_quarantined_and_not_audited(self) -> None:
        package = self._create(package_fixture(package_id="evpkg-export-race"))
        package = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        package = self.service.release(
            "tenant-a", package.package_id, actor="release-officer",
            expected_revision=package.revision,
        )
        output = Path(self.tmp.name) / "export-race"
        published = threading.Event()
        resume = threading.Event()
        failures: list[Exception] = []

        def delayed_export(*args, **kwargs):
            result = write_export(*args, **kwargs)
            published.set()
            self.assertTrue(resume.wait(timeout=wait_seconds(2)))
            return result

        def run_export() -> None:
            try:
                self.service.export("tenant-a", package.package_id, output, actor="exporter")
            except Exception as exc:  # expected losing side of the race
                failures.append(exc)

        with patch("livemorebio.evidence.service.export_package", side_effect=delayed_export):
            worker = threading.Thread(target=run_export)
            worker.start()
            self.assertTrue(published.wait(timeout=wait_seconds(2)))
            self.service.retract(
                "tenant-a", package.package_id, actor="safety-officer",
                reason="safety signal", expected_revision=package.revision,
            )
            resume.set()
            worker.join(timeout=wait_seconds(2))
        self.assertFalse(worker.is_alive())
        self.assertEqual(len(failures), 1)
        self.assertIsInstance(failures[0], ConflictError)
        self.assertFalse(any(path.is_dir() and not path.name.startswith(".") for path in output.iterdir()))
        self.assertTrue(any(path.name.startswith(".stale-") for path in output.iterdir()))
        actions = [
            event["action"]
            for event in self.store.audit_events("tenant-a", package.package_id)
        ]
        self.assertNotIn("package.exported", actions)

    def test_crash_orphan_export_is_force_quarantined_after_retraction_race(self) -> None:
        package = self._create(package_fixture(package_id="evpkg-export-orphan"))
        package = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        package = self.service.release(
            "tenant-a", package.package_id, actor="release-officer",
            expected_revision=package.revision,
        )
        output = Path(self.tmp.name) / "orphan-export"
        audit_reference = self.store.audit_proof_reference("tenant-a", package.package_id)
        orphan = write_export(
            package, output, evidence_audit_proof_reference=audit_reference
        )
        self.assertTrue(orphan.published_new)
        published = threading.Event()
        resume = threading.Event()
        failures: list[Exception] = []

        def delayed_existing(*args, **kwargs):
            result = write_export(*args, **kwargs)
            self.assertFalse(result.published_new)
            published.set()
            self.assertTrue(resume.wait(timeout=wait_seconds(2)))
            return result

        def run_export() -> None:
            try:
                self.service.export("tenant-a", package.package_id, output, actor="exporter")
            except Exception as exc:
                failures.append(exc)

        with patch("livemorebio.evidence.service.export_package", side_effect=delayed_existing):
            worker = threading.Thread(target=run_export)
            worker.start()
            self.assertTrue(published.wait(timeout=wait_seconds(2)))
            self.service.retract(
                "tenant-a", package.package_id, actor="safety-officer",
                reason="late safety signal", expected_revision=package.revision,
            )
            resume.set()
            worker.join(timeout=wait_seconds(2))
        self.assertEqual(len(failures), 1)
        self.assertFalse(orphan.directory.exists())
        self.assertTrue(any(path.name.startswith(".stale-") for path in output.iterdir()))

    def test_export_losing_ancestor_retraction_race_is_quarantined(self) -> None:
        parent = self._create(package_fixture(package_id="evpkg-export-parent"))
        parent = self.service.lock(
            "tenant-a", parent.package_id, actor="independent-reviewer",
            expected_revision=parent.revision,
        )
        parent = self.service.release(
            "tenant-a", parent.package_id, actor="release-officer",
            expected_revision=parent.revision,
        )
        child = self.service.create_revision(
            "tenant-a", parent.package_id, new_package_id="evpkg-export-child",
            actor="package-author", expected_revision=parent.revision,
        )
        child = self.service.lock(
            "tenant-a", child.package_id, actor="independent-reviewer",
            expected_revision=child.revision,
        )
        output = Path(self.tmp.name) / "ancestor-race"
        published = threading.Event()
        resume = threading.Event()
        failures: list[Exception] = []

        def delayed_export(*args, **kwargs):
            result = write_export(*args, **kwargs)
            published.set()
            self.assertTrue(resume.wait(timeout=wait_seconds(2)))
            return result

        def run_export() -> None:
            try:
                self.service.export("tenant-a", child.package_id, output, actor="exporter")
            except Exception as exc:
                failures.append(exc)

        with patch("livemorebio.evidence.service.export_package", side_effect=delayed_export):
            worker = threading.Thread(target=run_export)
            worker.start()
            self.assertTrue(published.wait(timeout=wait_seconds(2)))
            self.service.retract(
                "tenant-a", parent.package_id, actor="safety-officer",
                reason="parent source withdrawn", expected_revision=parent.revision,
            )
            resume.set()
            worker.join(timeout=wait_seconds(2))
        self.assertEqual(len(failures), 1)
        self.assertIsInstance(failures[0], ConflictError)
        self.assertFalse(any(path.is_dir() and not path.name.startswith(".") for path in output.iterdir()))

    def test_retraction_idempotency_replays_exact_request_and_rejects_reuse(self) -> None:
        package = self._create(package_fixture(package_id="evpkg-retraction-idempotency"))
        package = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        package = self.service.release(
            "tenant-a", package.package_id, actor="release-officer",
            expected_revision=package.revision,
        )
        first = self.service.retract(
            "tenant-a", package.package_id, actor="safety-officer",
            reason="source withdrawn", expected_revision=package.revision,
            idempotency_key="retract-once",
        )
        replay = self.service.retract(
            "tenant-a", package.package_id, actor="safety-officer",
            reason="source withdrawn", expected_revision=package.revision,
            idempotency_key="retract-once",
        )
        self.assertEqual(replay, first)
        with self.assertRaisesRegex(ConflictError, "different request"):
            self.service.retract(
                "tenant-a", package.package_id, actor="safety-officer",
                reason="different reason", expected_revision=package.revision,
                idempotency_key="retract-once",
            )
        actions = [
            event["action"]
            for event in self.store.audit_events("tenant-a", package.package_id)
        ]
        self.assertEqual(actions.count("package.retracted"), 1)

    def test_create_model_only_attestation_is_atomic_and_retry_idempotent(self) -> None:
        template = package_fixture(
            package_id="evpkg-atomic-model-create",
            include_measurement=False,
        )
        prediction = template.predictions[0]
        provenance = replace(
            template.provenance,
            content_hashes=(
                prediction.scenario_snapshot.state_hash,
                prediction.input_hash,
            ),
        )
        original_append_audit = self.store._append_audit
        failed = False

        def fail_attestation_audit(connection, *args, **kwargs):
            nonlocal failed
            action = args[2] if len(args) > 2 else kwargs.get("action")
            if action == "model_verification.added" and not failed:
                failed = True
                raise RuntimeError("forced attestation audit failure")
            return original_append_audit(connection, *args, **kwargs)

        with patch.object(self.store, "_append_audit", side_effect=fail_attestation_audit):
            with self.assertRaisesRegex(RuntimeError, "forced attestation audit failure"):
                self.service.create_model_only(
                    tenant_id=template.tenant_id,
                    package_id=template.package_id,
                    use_case=template.use_case,
                    claim=template.claim,
                    policy=template.policy,
                    context_of_use=template.context_of_use,
                    protocol=template.protocol,
                    prediction=prediction,
                    provenance=provenance,
                    visualization_manifest=template.visualization_manifest,
                    created_by=template.created_by,
                    created_at=template.created_at,
                    protocol_approval_actor=template.protocol.approved_by,
                    idempotency_key="atomic-model-create",
                )
        self.assertEqual(self.store.list("tenant-a"), ())

        created = self.service.create_model_only(
            tenant_id=template.tenant_id,
            package_id=template.package_id,
            use_case=template.use_case,
            claim=template.claim,
            policy=template.policy,
            context_of_use=template.context_of_use,
            protocol=template.protocol,
            prediction=prediction,
            provenance=provenance,
            visualization_manifest=template.visualization_manifest,
            created_by=template.created_by,
            created_at=template.created_at,
            protocol_approval_actor=template.protocol.approved_by,
            idempotency_key="atomic-model-create",
        )
        replay = self.service.create_model_only(
            tenant_id=template.tenant_id,
            package_id=template.package_id,
            use_case=template.use_case,
            claim=template.claim,
            policy=template.policy,
            context_of_use=template.context_of_use,
            protocol=template.protocol,
            prediction=prediction,
            provenance=provenance,
            visualization_manifest=template.visualization_manifest,
            created_by=template.created_by,
            created_at=template.created_at,
            protocol_approval_actor=template.protocol.approved_by,
            idempotency_key="atomic-model-create",
        )
        self.assertEqual(created, replay)
        self.assertEqual(len(created.model_verifications), 1)
        actions = [
            event["action"]
            for event in self.store.audit_events("tenant-a", template.package_id)
        ]
        self.assertEqual(actions.count("package.created"), 1)
        self.assertEqual(actions.count("model_verification.added"), 1)

    def test_export_idempotency_conflict_is_rejected_before_artifact_publication(self) -> None:
        package = self._create(package_fixture(package_id="evpkg-export-idempotency"))
        package = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        first_root = Path(self.tmp.name) / "idempotent-export-a"
        second_root = Path(self.tmp.name) / "idempotent-export-b"
        self.service.export(
            "tenant-a", package.package_id, first_root, actor="exporter",
            idempotency_key="one-export-request",
        )
        with self.assertRaisesRegex(ConflictError, "different request"):
            self.service.export(
                "tenant-a", package.package_id, second_root, actor="exporter",
                idempotency_key="one-export-request",
            )
        self.assertFalse(
            any(path.is_dir() and not path.name.startswith(".") for path in second_root.iterdir())
        )

    def test_export_reuses_frozen_signer_when_key_rotates_after_planning(self) -> None:
        package = self._create(package_fixture(package_id="evpkg-signing-plan"))
        package = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        output = Path(self.tmp.name) / "signer-plan-export"
        captured = {}

        def rotate_after_plan(*args, **kwargs):
            plan = build_export_plan(*args, **kwargs)
            captured["directory"] = plan.final_dir
            captured["profile"] = plan.signer.signing_profile_hash
            replacement_key = Ed25519PrivateKey.generate().private_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PrivateFormat.Raw,
                encryption_algorithm=serialization.NoEncryption(),
            )
            self.signing_key_path.write_bytes(replacement_key)
            os.chmod(self.signing_key_path, 0o600)
            return plan

        with patch("livemorebio.evidence.service.plan_export", side_effect=rotate_after_plan):
            artifact = self.service.export(
                "tenant-a", package.package_id, output, actor="exporter"
            )
        self.assertEqual(artifact.directory, captured["directory"])
        self.assertIn(f"sp{captured['profile']}", artifact.directory.name)
        self.assertTrue(
            self.store.is_export_registered(
                "tenant-a", package.package_id, package.content_hash,
                artifact.archive_sha256, str(artifact.directory),
            )
        )

    def test_same_signed_archive_cannot_register_in_two_output_roots(self) -> None:
        package = self._create(package_fixture(package_id="evpkg-single-export-location"))
        package = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        first_root = Path(self.tmp.name) / "single-location-a"
        second_root = Path(self.tmp.name) / "single-location-b"
        first = self.service.export(
            "tenant-a", package.package_id, first_root, actor="exporter"
        )

        with self.assertRaisesRegex(ConflictError, "another directory"):
            self.service.export(
                "tenant-a", package.package_id, second_root, actor="exporter"
            )

        self.assertTrue(
            self.store.is_export_registered(
                "tenant-a", package.package_id, package.content_hash,
                first.archive_sha256, str(first.directory),
            )
        )
        self.assertFalse(
            any(path.is_dir() and not path.name.startswith(".") for path in second_root.iterdir())
        )
        actions = [
            event["action"]
            for event in self.store.audit_events("tenant-a", package.package_id)
        ]
        self.assertEqual(actions.count("package.exported"), 1)

    def test_export_root_aliases_resolve_to_one_registered_artifact(self) -> None:
        package = self._create(package_fixture(package_id="evpkg-canonical-export-root"))
        package = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        base = Path(self.tmp.name)
        absolute_root = base / "canonical-export-root"
        previous_cwd = Path.cwd()
        try:
            os.chdir(base)
            relative_export = self.service.export(
                "tenant-a", package.package_id, Path("canonical-export-root"),
                actor="exporter",
            )
        finally:
            os.chdir(previous_cwd)

        absolute_export = self.service.export(
            "tenant-a", package.package_id, absolute_root, actor="exporter"
        )
        alias_root = base / "canonical-export-alias"
        alias_root.symlink_to(absolute_root, target_is_directory=True)
        alias_export = self.service.export(
            "tenant-a", package.package_id, alias_root, actor="exporter"
        )

        self.assertEqual(relative_export.directory, absolute_export.directory)
        self.assertEqual(relative_export.directory, alias_export.directory)
        self.assertTrue(relative_export.directory.is_dir())
        self.assertTrue(
            self.store.is_export_registered(
                "tenant-a", package.package_id, package.content_hash,
                relative_export.archive_sha256, str(relative_export.directory),
            )
        )
        actions = [
            event["action"]
            for event in self.store.audit_events("tenant-a", package.package_id)
        ]
        self.assertEqual(actions.count("package.exported"), 1)

    def test_deterministic_atomic_export_manifest_archive_and_fhir_draft(self) -> None:
        package = self._create(
            package_fixture(
                source_data_class=SourceDataClass.REAL_HUMAN,
                validation_dimensions=(),
            )
        )
        package = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        out = Path(self.tmp.name) / "exports"
        first = self.service.export("tenant-a", package.package_id, out, actor="exporter")
        second = self.service.export("tenant-a", package.package_id, out, actor="exporter")
        self.assertEqual(first.archive_sha256, second.archive_sha256)
        self.assertEqual(first.artifact_hashes, second.artifact_hashes)
        self.assertEqual(first.directory, second.directory)
        self.assertTrue(first.archive_path.exists())
        self.assertEqual(first.detached_hash_path.read_text(encoding="ascii"), first.archive_sha256 + "\n")
        manifest = json.loads(first.manifest_path.read_text(encoding="utf-8"))
        self.assertEqual(
            manifest["schema_version"],
            "livemore.evidence-export-manifest.v2",
        )
        self.assertEqual(manifest["signature"]["algorithm"], "Ed25519")
        self.assertEqual(manifest["issuer"]["key_id"], "test-evidence-issuer-2026")
        self.assertIn("out-of-band trusted Ed25519 public key", manifest["issuer"]["trust_notice"])
        self.assertEqual(manifest["package"]["package_id"], package.package_id)
        self.assertEqual(manifest["package"]["computed_claim_state"], package.claim_state.value)
        self.assertEqual(manifest["package"]["lifecycle"], package.lifecycle.value)
        self.assertEqual(manifest["package"]["revision"], package.revision)
        self.assertEqual(manifest["evidence_audit_proof_reference"]["status"], "available")
        self.assertNotIn("manifest.json", manifest["artifacts"])
        self.assertNotIn(first.archive_path.name, manifest["artifacts"])
        for name, expected_hash in manifest["artifacts"].items():
            data = (first.directory / name).read_bytes()
            self.assertEqual(hashlib.sha256(data).hexdigest(), expected_hash)
        with zipfile.ZipFile(first.archive_path) as archive:
            infos = archive.infolist()
            self.assertEqual([info.filename for info in infos], sorted(info.filename for info in infos))
            self.assertTrue(all(info.date_time == (1980, 1, 1, 0, 0, 0) for info in infos))
            self.assertTrue(all(info.compress_type == zipfile.ZIP_STORED for info in infos))
        fhir = json.loads((first.directory / "fhir-draft.json").read_text(encoding="utf-8"))
        self.assertEqual(fhir["meta"]["tag"][0]["code"], "draft-not-validated")
        self.assertNotIn(
            "ResearchStudy",
            {entry["resource"]["resourceType"] for entry in fhir["entry"]},
        )
        document = next(entry["resource"] for entry in fhir["entry"] if entry["resource"]["resourceType"] == "DocumentReference")
        self.assertRegex(document["id"], r"^[A-Za-z0-9\-.]{1,64}$")
        self.assertEqual(document["description"], package.claim)
        self.assertEqual(
            document["content"][0]["attachment"]["title"],
            "Livemore evidence package attachment",
        )
        attachment = document["content"][0]["attachment"]
        evidence_bytes = base64.b64decode(attachment["data"])
        self.assertEqual(
            base64.b64decode(attachment["hash"]),
            hashlib.sha1(evidence_bytes).digest(),  # FHIR Attachment.hash uses SHA-1.
        )
        package_hash_extension = next(
            item
            for item in attachment["extension"]
            if item["url"] == "https://livemore.ai/fhir/StructureDefinition/package-sha256"
        )
        self.assertEqual(package_hash_extension["valueString"], package.content_hash)
        csv_bytes = (first.directory / "measurements.csv").read_bytes()
        self.assertNotIn(b"\r\n", csv_bytes)
        self.assertTrue(csv_bytes.startswith(b'"package_id","envelope_id"'))
        self.assertFalse(any(path.name.startswith(".tmp-") for path in out.iterdir()))
        self.assertTrue(
            all(
                not entry["fullUrl"].startswith("urn:uuid:")
                or re.fullmatch(
                    r"urn:uuid:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}",
                    entry["fullUrl"],
                )
                for entry in fhir["entry"]
            )
        )
        verified = verify_signed_export(
            first.directory,
            self._trusted_public_key(),
            expected_key_id="test-evidence-issuer-2026",
        )
        self.assertEqual(verified, manifest)
        self.assertEqual(os.stat(self.signing_key_path).st_mode & 0o777, 0o600)

    def test_signing_profile_rotation_preserves_both_immutable_exports(self) -> None:
        package = self._create(package_fixture(package_id="evpkg-signing-rotation"))
        locked = self.service.lock(
            "tenant-a",
            package.package_id,
            actor="independent-reviewer",
            expected_revision=package.revision,
        )
        output = Path(self.tmp.name) / "signing-rotation-exports"

        first = self.service.export(
            "tenant-a",
            locked.package_id,
            output,
            actor="exporter",
        )
        old_public_key = self._trusted_public_key()
        old_archive_bytes = first.archive_path.read_bytes()
        old_profile_hash = IssuerSigner.load(output).signing_profile_hash
        self.assertTrue(first.directory.name.endswith(f"sp{old_profile_hash}"))
        os.environ["LIVEMORE_EVIDENCE_SIGNING_KEY_ID"] = "same-key-new-id"
        self.assertNotEqual(
            IssuerSigner.load(output).signing_profile_hash,
            old_profile_hash,
        )
        os.environ["LIVEMORE_EVIDENCE_SIGNING_KEY_ID"] = "test-evidence-issuer-2026"
        same_old_profile = self.service.export(
            "tenant-a",
            locked.package_id,
            output,
            actor="exporter",
        )
        self.assertEqual(same_old_profile.directory, first.directory)
        self.assertEqual(same_old_profile.archive_sha256, first.archive_sha256)

        rotated_private_key = Ed25519PrivateKey.generate()
        self.signing_key_path.write_bytes(
            rotated_private_key.private_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PrivateFormat.Raw,
                encryption_algorithm=serialization.NoEncryption(),
            )
        )
        os.chmod(self.signing_key_path, 0o600)
        os.environ["LIVEMORE_EVIDENCE_SIGNING_KEY_ID"] = "test-evidence-issuer-2027"
        rotated_public_key = self._trusted_public_key()
        rotated_profile_hash = IssuerSigner.load(output).signing_profile_hash

        rotated = self.service.export(
            "tenant-a",
            locked.package_id,
            output,
            actor="exporter",
        )
        same_rotated_profile = self.service.export(
            "tenant-a",
            locked.package_id,
            output,
            actor="exporter",
        )

        self.assertNotEqual(rotated.directory, first.directory)
        self.assertNotEqual(rotated.archive_sha256, first.archive_sha256)
        self.assertTrue(rotated.directory.name.endswith(f"sp{rotated_profile_hash}"))
        self.assertEqual(same_rotated_profile.directory, rotated.directory)
        self.assertEqual(same_rotated_profile.archive_sha256, rotated.archive_sha256)
        self.assertTrue(first.directory.is_dir())
        self.assertTrue(rotated.directory.is_dir())
        self.assertEqual(first.archive_path.read_bytes(), old_archive_bytes)
        self.assertEqual(
            len([entry for entry in output.iterdir() if entry.is_dir()]),
            2,
        )

        verify_signed_export(
            first.directory,
            old_public_key,
            expected_key_id="test-evidence-issuer-2026",
        )
        verify_signed_export(
            rotated.directory,
            rotated_public_key,
            expected_key_id="test-evidence-issuer-2027",
        )
        with self.assertRaisesRegex(IntegrityError, "trusted public key"):
            verify_signed_export(first.directory, rotated_public_key)
        with self.assertRaisesRegex(IntegrityError, "trusted public key"):
            verify_signed_export(rotated.directory, old_public_key)

    def test_outward_report_and_fhir_omit_untrusted_free_text_narratives(self) -> None:
        phrases = (
            "Use this result to dose volunteers tomorrow",
            "Proceed directly to dosing people",
            "This result warrants human dosing",
            "Animal work can now be dispensed with",
            "Suitable as the sole basis for patient care",
        )
        source = package_fixture(package_id="evpkg|#*")
        package = replace(
            source,
            context_of_use=replace(
                source.context_of_use,
                question_of_interest=phrases[0],
                intended_decision=phrases[1],
                target_population=phrases[2],
                limitations=(phrases[3],),
            ),
            model_verifications=(
                replace(
                    source.model_verifications[0],
                    scope=phrases[4],
                    method="untrusted *method* | #heading",
                ),
            ),
        )
        created = self._create(package)
        locked = self.service.lock(
            "tenant-a",
            created.package_id,
            actor="independent-reviewer",
            expected_revision=created.revision,
        )
        exported = self.service.export(
            "tenant-a",
            locked.package_id,
            Path(self.tmp.name) / "safe-narratives",
            actor="exporter",
        )
        report = (exported.directory / "report.md").read_text(encoding="utf-8")
        for phrase in phrases:
            self.assertNotIn(phrase, report)
        self.assertNotIn("untrusted *method* | #heading", report)
        self.assertIn(package.claim, report)
        self.assertIn(r"evpkg\|\#\*", report)

        fhir = json.loads(
            (exported.directory / "fhir-draft.json").read_text(encoding="utf-8")
        )
        document = fhir["entry"][0]["resource"]
        self.assertEqual(document["description"], package.claim)
        self.assertEqual(
            document["content"][0]["attachment"]["title"],
            "Livemore evidence package attachment",
        )
        for phrase in phrases:
            self.assertNotIn(phrase, json.dumps(fhir))

        with self.assertRaises(DomainValidationError):
            replace(
                source.context_of_use,
                question_of_interest="research question\n# injected heading",
            )

    def test_measurement_csv_neutralizes_spreadsheet_formulas_only_in_projection(self) -> None:
        for prefix in ("=", "+", "-", "@"):
            with self.subTest(prefix=prefix):
                self.assertEqual(
                    _spreadsheet_safe_cell(prefix + "FORMULA(1)"),
                    "'" + prefix + "FORMULA(1)",
                )
        self.assertEqual(_spreadsheet_safe_cell("safe-id"), "safe-id")

        package_id = "=HYPERLINK(https://attacker.invalid)"
        package = self._create(package_fixture(package_id=package_id))
        locked = self.service.lock(
            "tenant-a",
            package.package_id,
            actor="independent-reviewer",
            expected_revision=package.revision,
        )
        exported = self.service.export(
            "tenant-a",
            locked.package_id,
            Path(self.tmp.name) / "formula-safe",
            actor="exporter",
        )
        rows = list(
            csv.DictReader(
                io.StringIO(
                    (exported.directory / "measurements.csv").read_text(encoding="utf-8")
                )
            )
        )
        self.assertTrue(rows)
        self.assertTrue(all(row["package_id"] == "'" + package_id for row in rows))
        evidence = json.loads(
            (exported.directory / "evidence.json").read_text(encoding="utf-8")
        )
        self.assertEqual(evidence["package_id"], package_id)
        report = (exported.directory / "report.md").read_text(encoding="utf-8")
        self.assertIn("spreadsheet formula execution", report)

    def test_signed_export_verification_rejects_wrong_key_tampering_and_extra_files(self) -> None:
        package = self._create(package_fixture(package_id="evpkg-signature-adversarial"))
        locked = self.service.lock(
            "tenant-a",
            package.package_id,
            actor="independent-reviewer",
            expected_revision=package.revision,
        )
        exported = self.service.export(
            "tenant-a",
            locked.package_id,
            Path(self.tmp.name) / "signature-adversarial",
            actor="exporter",
        )
        trusted = self._trusted_public_key()
        wrong = Ed25519PrivateKey.generate().public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        with self.assertRaises(IntegrityError):
            verify_signed_export(exported.directory, wrong)

        unexpected = exported.directory / "unscoped-notes.txt"
        unexpected.write_text("not covered", encoding="utf-8")
        with self.assertRaisesRegex(IntegrityError, "unexpected artifact set"):
            verify_signed_export(exported.directory, trusted)
        unexpected.unlink()

        original_report = (exported.directory / "report.md").read_bytes()
        (exported.directory / "report.md").write_bytes(original_report + b"\nforged\n")
        with self.assertRaisesRegex(IntegrityError, "artifact hash mismatch"):
            verify_signed_export(exported.directory, trusted)
        (exported.directory / "report.md").write_bytes(original_report)

        original_archive = exported.archive_path.read_bytes()
        exported.archive_path.write_bytes(original_archive + b"forged")
        with self.assertRaisesRegex(IntegrityError, "archive does not match"):
            verify_signed_export(exported.directory, trusted)
        exported.archive_path.write_bytes(original_archive)

        manifest = json.loads(exported.manifest_path.read_text(encoding="utf-8"))
        manifest["package"]["revision"] += 1
        exported.manifest_path.write_bytes(canonical_json_bytes(manifest))
        with self.assertRaisesRegex(IntegrityError, "signature is invalid"):
            verify_signed_export(exported.directory, trusted)

    def test_production_export_fails_closed_without_external_signing_key(self) -> None:
        package = self._create(package_fixture(package_id="evpkg-production-key"))
        locked = self.service.lock(
            "tenant-a",
            package.package_id,
            actor="independent-reviewer",
            expected_revision=package.revision,
        )
        with patch.dict(
            os.environ,
            {
                "LIVEMORE_ENVIRONMENT": "production",
                "LIVEMORE_ENV": "test",
                "LIVEMORE_EVIDENCE_SIGNING_KEY": "",
                "LIVEMORE_EVIDENCE_SIGNING_KEY_FILE": "",
            },
            clear=False,
        ):
            with self.assertRaises(SigningConfigurationError):
                self.service.export(
                    "tenant-a",
                    locked.package_id,
                    Path(self.tmp.name) / "production-no-key",
                    actor="exporter",
                )

    def test_export_and_key_creation_preserve_existing_operator_directory_modes(self) -> None:
        export_root = Path(self.tmp.name) / "operator-export-root"
        key_parent = Path(self.tmp.name) / "operator-key-parent"
        export_root.mkdir(mode=0o755)
        key_parent.mkdir(mode=0o755)
        os.chmod(export_root, 0o755)
        os.chmod(key_parent, 0o755)
        key_path = key_parent / "issuer.key"

        package = self._create(package_fixture(package_id="evpkg-permissions"))
        locked = self.service.lock(
            "tenant-a",
            package.package_id,
            actor="independent-reviewer",
            expected_revision=package.revision,
        )
        with patch.dict(
            os.environ,
            {"LIVEMORE_EVIDENCE_SIGNING_KEY_FILE": str(key_path)},
            clear=False,
        ):
            self.service.export(
                "tenant-a",
                locked.package_id,
                export_root,
                actor="exporter",
            )

        self.assertEqual(os.stat(export_root).st_mode & 0o777, 0o755)
        self.assertEqual(os.stat(key_parent).st_mode & 0o777, 0o755)
        self.assertEqual(os.stat(key_path).st_mode & 0o777, 0o600)

    def test_export_rejects_external_manifest_tampering(self) -> None:
        package = self._create(package_fixture())
        package = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        output = Path(self.tmp.name) / "manifest-tamper"
        exported = self.service.export("tenant-a", package.package_id, output, actor="exporter")
        manifest = json.loads(exported.manifest_path.read_text(encoding="utf-8"))
        manifest["artifacts"] = {}
        exported.manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        with self.assertRaises(IntegrityError):
            self.service.export("tenant-a", package.package_id, output, actor="exporter")

    def test_export_rejects_coherently_repacked_but_modified_artifacts(self) -> None:
        package = self._create(package_fixture(package_id="evpkg-repacked-export"))
        package = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        output = Path(self.tmp.name) / "repacked-export"
        exported = self.service.export(
            "tenant-a", package.package_id, output, actor="exporter"
        )
        forged_report = b"# Forged report\n\nThis model is clinically proven safe.\n"
        (exported.directory / "report.md").write_bytes(forged_report)
        manifest = json.loads(exported.manifest_path.read_text(encoding="utf-8"))
        manifest["artifacts"]["report.md"] = hashlib.sha256(forged_report).hexdigest()
        manifest_bytes = canonical_json_bytes(manifest)
        exported.manifest_path.write_bytes(manifest_bytes)

        entries = {
            name: (exported.directory / name).read_bytes()
            for name in ("evidence.json", "fhir-draft.json", "measurements.csv", "report.md")
        }
        entries["manifest.json"] = manifest_bytes
        with zipfile.ZipFile(
            exported.archive_path,
            "w",
            compression=zipfile.ZIP_STORED,
            allowZip64=True,
        ) as archive:
            for name in sorted(entries):
                info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.compress_type = zipfile.ZIP_STORED
                info.external_attr = (0o100600 & 0xFFFF) << 16
                info.flag_bits = 0
                archive.writestr(info, entries[name])
        archive_hash = hashlib.sha256(exported.archive_path.read_bytes()).hexdigest()
        exported.detached_hash_path.write_text(archive_hash + "\n", encoding="ascii")

        with self.assertRaises(IntegrityError):
            self.service.export("tenant-a", package.package_id, output, actor="exporter")

    def test_each_lifecycle_revision_gets_an_accurate_export(self) -> None:
        package = self._create(package_fixture())
        locked = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        output = Path(self.tmp.name) / "lifecycle-exports"
        locked_export = self.service.export("tenant-a", locked.package_id, output, actor="exporter")
        released = self.service.release(
            "tenant-a", locked.package_id, actor="release-officer",
            expected_revision=locked.revision,
        )
        released_export = self.service.export(
            "tenant-a", released.package_id, output, actor="exporter"
        )
        self.assertNotEqual(locked_export.directory, released_export.directory)
        released_json = json.loads((released_export.directory / "evidence.json").read_text(encoding="utf-8"))
        self.assertEqual(released_json["lifecycle"], "released")

    def test_concurrent_identical_exports_converge_on_one_valid_artifact(self) -> None:
        package = self._create(package_fixture())
        package = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        output = Path(self.tmp.name) / "concurrent-exports"
        barrier = threading.Barrier(8)
        results: list[str] = []
        failures: list[Exception] = []

        def export_once() -> None:
            local = EvidenceService(EvidenceStore(self.store.path))
            try:
                barrier.wait()
                result = local.export("tenant-a", package.package_id, output, actor="exporter")
                results.append(result.archive_sha256)
            except Exception as error:  # captured for the assertion below
                failures.append(error)
            finally:
                local.close()

        threads = [threading.Thread(target=export_once) for _ in range(8)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        self.assertEqual(
            [(repr(error), repr(error.__cause__)) for error in failures],
            [],
        )
        self.assertEqual(len(set(results)), 1)

    def test_export_detects_tampered_stored_payload(self) -> None:
        package = self._create(package_fixture())
        package = self.service.lock(
            "tenant-a", package.package_id, actor="independent-reviewer",
            expected_revision=package.revision,
        )
        with sqlite3.connect(self.store.path) as connection:
            raw = connection.execute(
                "SELECT payload_json FROM evidence_packages WHERE tenant_id=? AND package_id=?",
                ("tenant-a", package.package_id),
            ).fetchone()[0]
            connection.execute(
                "UPDATE evidence_packages SET payload_json=? WHERE tenant_id=? AND package_id=?",
                (raw.replace("candidate X", "candidate Y"), "tenant-a", package.package_id),
            )
            connection.commit()
        with self.assertRaises(IntegrityError):
            self.service.export(
                "tenant-a", package.package_id, Path(self.tmp.name) / "exports", actor="exporter"
            )


if __name__ == "__main__":
    unittest.main()
