"""Drug-name -> molecular targets (ChEMBL) -> human GEM, generalized (no hand-coding)."""
import os
import pytest
from livemorebio.engines import genome_scale as GS, drug_targets as DT

def test_action_scale_directions():
    assert DT.ACTION_SCALE == {}  # Action labels have no automatic quantitative effect.


def test_drug_response_wiring_offline(monkeypatch):
    # deterministic offline resolver: a GAPDH inhibitor (a real glycolytic bottleneck)
    monkeypatch.setattr(DT, "resolve_drug", lambda name: {
        "name": name, "chembl_id": "TEST", "resolved": True,
        "targets": [{"gene": "GAPDH", "action": "INHIBITOR", "moa": "test", "scale": 0.05}]})
    with pytest.raises(ValueError, match="qualified"):
        GS.drug_response(genome={}, drug_name="test-inhibitor")


@pytest.mark.network
@pytest.mark.skipif(os.environ.get("LIVEMORE_TEST_NETWORK") != "1",
                    reason="explicit public network lookup opt-in")
def test_chembl_resolves_real_targets():
    try:
        r = DT.resolve_drug("atorvastatin")
    except Exception:
        pytest.skip("network unavailable")
    if not r.get("resolved"):
        pytest.skip("ChEMBL unavailable")
    assert any(t["gene"] == "HMGCR" for t in r["targets"])   # real, curated MoA
