"""Technical scenario client fixtures only; no service, person, or browser session."""
from __future__ import annotations

from copy import deepcopy
import json

import pytest

from livemorebio.sdk import Platform
from .test_legacy_preview_recovery_clients import preview
from .test_workspace_stream_ui import CONSOLE, javascript
from ._node import require_node, run_node
from ._source_tree import source_tree_only


@source_tree_only("docs/LAUNCH_GUIDE.md")
def test_launch_metformin_walkthrough_describes_the_detached_scalar_result():
    guide = (CONSOLE.parents[2] / "docs/LAUNCH_GUIDE.md").read_text(encoding="utf-8")
    walkthrough = guide.split("### Executable multiscale Atlas", 1)[1].split("### Digital twins", 1)[0]
    assert "detached scenario" in walkthrough
    assert "workspace remains unchanged" in walkthrough
    assert "textual scalar comparisons" in walkthrough
    for scalar in ("mean glucose", "heart rate", "APD90"):
        assert scalar in walkthrough
    assert "captured baseline" in walkthrough
    assert "traces and cross-scale mechanism must" not in walkthrough


def test_attached_perturb_retains_a_detached_scenario_receipt(monkeypatch):
    platform = object.__new__(Platform)
    platform.mode = "attach"
    state = {"profile": "technical-reference", "metabolic": {"mean_glucose": 123},
             "cardiac": {"hr_bpm": 72, "hrv_ms": 40},
             "scenario": {"code": "ISOLATED_SCENARIO", "source_generation": "technical-generation",
                          "live_twin_unchanged": True}}
    calls, audited = [], []
    monkeypatch.setattr(platform, "_post", lambda *args: calls.append(args) or state)
    monkeypatch.setattr(platform, "_audit_result", lambda *args: audited.append(args))
    result = platform.perturb("meal", grams=25)
    assert result["scenario"] == state["scenario"]
    assert result["mean_glucose"] == 123
    assert calls == [("/api/stimulate", {"kind": "meal", "params": {"grams": 25}})]
    assert audited[0][2] == result
    result["scenario"]["source_generation"] = "changed-technical-copy"
    assert state["scenario"]["source_generation"] == "technical-generation"
    live = deepcopy(state)
    del live["scenario"]
    assert "scenario" not in platform._summary(live)


def test_workspace_action_shows_finite_scenario_readouts_separately_from_selected_state():
    javascript(r'''
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();let reads=0;
function el(id){if(!nodes.has(id))nodes.set(id,{id,textContent:'',hidden:false,dataset:{},attrs:{},
 setAttribute(k,v){this.attrs[k]=v},after(x){nodes.set('#'+x.id,x)}});return nodes.get(id)}
const selected=fixture();selected.twin.metabolic.mean_glucose=100;selected.twin.cardiac={hr_bpm:70,apd90_ms:300};
const result={action:{kind:'meal',status:'COMPLETED',transitions:['QUEUED','RUNNING','COMPLETED']},
 scenario:{code:'ISOLATED_SCENARIO',source_generation:'a'.repeat(32),live_twin_unchanged:true},
 workspace:{twin:{metabolic:{mean_glucose:125},cardiac:{hr_bpm:NaN,apd90_ms:Infinity}},
 multiscale:{comparison:{baseline:{mean_glucose_mg_dL:90,heart_rate_bpm:68,apd90_ms:290}}}}};
const context={document:{body:{dataset:{},setAttribute(){}},querySelector:s=>s==='#isolated-scenario-result'?(nodes.get(s)||null):el(s),querySelectorAll:()=>[],
 createElement:()=>({textContent:'',attrs:{},setAttribute(k,v){this.attrs[k]=v}})},URLSearchParams,Date,
 banner(){},clearBanner(){},clearInterval(){},setTimeout:f=>{f();return 0},
 getJSON:async()=>{reads++;return selected},postJSON:async()=>result};
(async()=>{vm.runInNewContext(PROJECTIONS+'\n'+CONTROLLER,context);
vm.runInNewContext('renderWorkspace=()=>{};renderTimeline=()=>{};',context);
await vm.runInNewContext('refresh()',context);const before=vm.runInNewContext('WORKSPACE',context);
await vm.runInNewContext('runAction("meal",{grams:25})',context);
a.equal(reads,2,'action must still refresh authoritative selected state');
a.equal(vm.runInNewContext('WORKSPACE.twin.metabolic.mean_glucose',context),100);
a.equal(before.twin.metabolic.mean_glucose,100);
const panel=nodes.get('#isolated-scenario-result');a(panel,'detached readout was discarded');
a.match(panel.textContent,/ISOLATED SCENARIO/);a.match(panel.textContent,/selected twin was unchanged/i);
a.match(panel.textContent,/captured baseline 90\.0; scenario 125\.0/i);
a(!panel.textContent.includes('100.0'),'selected display was reused as scenario baseline');
a.match(panel.textContent,/unavailable/i);a(!/NaN|Infinity/.test(panel.textContent));
a.equal(panel.attrs.role,'status');a(!panel.hidden);
a(panel.textContent.includes('a'.repeat(32)),'scenario source capture is not identified');
delete result.workspace.multiscale;await vm.runInNewContext('runAction("meal",{grams:25})',context);
a.match(panel.textContent,/captured baseline Unavailable; scenario 125\.0/i);
a(!panel.textContent.includes('100.0'),'absent captured baseline fell back to selected display');
context.replacement=fixture();context.replacement.context_id='b'.repeat(64);
vm.runInNewContext('acceptWorkspace(replacement)',context);
a.equal(panel.hidden,true,'old scenario remained visible after selected context changed');a.equal(panel.textContent,'');
})().catch(error=>{console.error(error);process.exitCode=1});
''')


@pytest.mark.parametrize("handler", ["stim('meal',{grams:25})", "runVia('/api/stimulate',{kind:'meal',params:{grams:25}},{class:'meal',readout:'metabolic'})"])
@pytest.mark.parametrize("availability_present", [True, False])
def test_legacy_result_is_labeled_and_fresh_current_read_clears_the_marker(handler, availability_present):
    html = (CONSOLE / "index.html").read_text(encoding="utf-8")
    prefix = "const $=" + html.split("<script>\nconst $=", 1)[1].split("// ===== Experiment / perturbation builder =====", 1)[0]
    render = "function render(){" + html.split("function render(){", 1)[1].split("// --- reactive metabolic curves ---", 1)[0]
    via = "async function runVia(" + html.split("async function runVia(", 1)[1].split("function logExperiment(", 1)[0]
    source = r'''
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();
function el(id){if(!nodes.has(id))nodes.set(id,{textContent:'',innerHTML:'',hidden:false,style:{},dataset:{},width:1,height:1,
 classList:{toggle(){},remove(){}},setAttribute(){},addEventListener(){},replaceChildren(){this.textContent='';this.innerHTML=''},
 getContext:()=>({clearRect(){}}),querySelector:()=>({setAttribute(){}})});return nodes.get(id)}
const live=LIVE,scenario=JSON.parse(JSON.stringify(live));scenario.scenario={code:'ISOLATED_SCENARIO',source_generation:'a'.repeat(32),live_twin_unchanged:true};
if(!AVAILABILITY_PRESENT)delete scenario.model_availability;
const context={document:{getElementById:el,querySelectorAll:()=>[]},window:{addEventListener(){}},
 fetch:async()=>({ok:true,json:async()=>scenario}),console,live};vm.createContext(context);
vm.runInContext(PREFIX,context);
vm.runInContext('let LASTRUN=null;function renderExtract(){}function drawMetab(){}function paintBody(){}function logExperiment(){}function focusReadout(){};'+RENDER+VIA,context);
let callbacks;
context.createLegacyPreviewRecovery=options=>{callbacks=options;return {beginNumericalAction:()=>({}),isCurrent:()=>true,
 finishNumericalAction:()=>options.setBusy(false),failNumericalAction:()=>true,
 refreshCurrent:async()=>options.publishCurrent(live,{})}};
context.requestLegacyPreview=()=>{throw Error('no transport allowed')};
(async()=>{await vm.runInContext('initializeLegacyPreviewRecovery({createLegacyPreviewRecovery,requestLegacyPreview})',context);
await vm.runInContext(HANDLER,context);
a.match(el('__banner').textContent,/ISOLATED SCENARIO/);
a.match(el('legacy-scenario-status').textContent,/selected twin was unchanged/i);
a.equal(el('legacy-scenario-status').hidden,false);
a.match(el('legacy-cardiac-provenance').title,/isolated scenario/i);
a(!el('legacy-cardiac-provenance').title.includes('current model state'));
await vm.runInContext('load()',context);
a.equal(el('legacy-scenario-status').textContent,'');a.equal(el('legacy-scenario-status').hidden,true);
a.equal(el('__banner').hidden,true);a.equal(el('legacy-cardiac-state').textContent,'Calculated response');
})().catch(error=>{console.error(error);process.exitCode=1});
'''
    for marker, value in {"LIVE": preview(), "PREFIX": prefix, "RENDER": render, "VIA": via, "HANDLER": handler, "AVAILABILITY_PRESENT": availability_present}.items():
        source = source.replace(marker, json.dumps(value))
    result = run_node([require_node(), "--eval", source], capture_output=True, text=True,
                      encoding="utf-8", timeout=15)
    assert result.returncode == 0, result.stderr



def test_legacy_cardiac_trace_requires_current_readiness_or_a_valid_captured_scenario():
    html = (CONSOLE / "index.html").read_text(encoding="utf-8")
    labels = "function updateLegacyCardiacLabels(){" + html.split("function updateLegacyCardiacLabels(){", 1)[1].split("function updateLegacyControls(", 1)[0]
    state = preview()
    del state["model_availability"]
    state["scenario"] = {"code": "ISOLATED_SCENARIO", "source_generation": "a" * 32,
                         "live_twin_unchanged": True}
    program = r"""
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map(),technical=STATE;
function el(id){if(!nodes.has(id))nodes.set(id,{textContent:'',hidden:true});return nodes.get(id)}
const context={$:el,legacyBusy:false,S:JSON.parse(JSON.stringify(technical))};vm.createContext(context);
vm.runInContext(LABELS+';updateLegacyCardiacLabels()',context);
a.equal(el('legacy-cardiac-state').textContent,'Isolated scenario');
for(const damage of [s=>{delete s.scenario},s=>{s.scenario.live_twin_unchanged=false},
 s=>{s.scenario.source_generation=''},s=>{s.cardiac=null},
 s=>{s.cardiac.t_ms=[];s.cardiac.v=[];s.cardiac.cai=[];s.cardiac.reason_code='CARDIAC_MODEL_NOT_INSTALLED'},
 s=>{s.cardiac.reason_code='CARDIAC_MODEL_NOT_INSTALLED'},
 s=>{s.cardiac.cai[0]=NaN},s=>{s.model_availability={state:'UNAVAILABLE'}}]){
 context.S=JSON.parse(JSON.stringify(technical));damage(context.S);vm.runInContext('updateLegacyCardiacLabels()',context);
 a.equal(el('legacy-cardiac-state').textContent,'No current trace');a.equal(el('legacy-cardiac-provenance').textContent,'unavailable');
}
""".replace("STATE", json.dumps(state)).replace("LABELS", json.dumps(labels))
    result = run_node([require_node(), "--eval", program], capture_output=True, text=True,
                      encoding="utf-8", timeout=15)
    assert result.returncode == 0, result.stderr
