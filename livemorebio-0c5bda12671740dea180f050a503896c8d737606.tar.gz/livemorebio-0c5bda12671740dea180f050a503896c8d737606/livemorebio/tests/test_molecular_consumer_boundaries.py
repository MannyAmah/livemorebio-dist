"""Authored ownership regressions; no live plugin, source, or numerical work."""
import json
from pathlib import Path
import subprocess

import pytest

from .test_molecular_consumer_bindings import execution_consumer
from ._node import require_node


ROOT = Path(__file__).parents[2]
PARENT = ROOT / "livemorebio/aegle/console/lib/continuous_execution.js"


def test_geometry_cleanup_failure_cannot_skip_owned_molecular_cleanup():
    execution_consumer("""
buttons()[0].click();await tick();const old=buttons()[0];
let geometryCalls=0,first=null;
explorers[0].dispose=()=>{geometryCalls++;throw Error('AUTHORED_GEOMETRY_DISPOSE_FAILURE');};
try{await view.dispose();}catch(error){first=error.message;}
await tick();await view.dispose();old.click();await tick();
assert.equal(mounts[0].disposals,1,'Geometry teardown failure skipped molecular teardown permanently');
assert.equal(geometryCalls,1);assert.equal(mounts[0].opens.length,1);
assert.equal(first,null,'An unobserved geometry exception escaped the owned cleanup boundary');
assert.equal(host.dataset.anatomyCleanup,'unconfirmed');
assert.equal(nodes.get('[data-status]').textContent,'Reference geometry cleanup is unconfirmed.');
assert.equal(host.dataset.molecularCleanup,undefined);
""")


def test_parent_controls_preserve_late_mounted_inspector_control_ownership():
    script = r"""
const assert=require('node:assert/strict');
let completed=false;process.on('beforeExit',()=>{if(!completed)process.exitCode=1;});
(async()=>{
const {mountContinuousExecution}=await import(PARENT);
const nodes=new Map(),children=[];
const el=key=>{
 if(!nodes.has(key))nodes.set(key,{
  value:key==='[data-engine]'?'metabolic-continuous-v1':'',handlers:{},dataset:{},
  classList:{toggle(){}},setAttribute(){},replaceChildren(){},
  addEventListener(k,f){this.handlers[k]=f;},disabled:false,textContent:'',innerHTML:'',
  closest(){return null;}
 });return nodes.get(key);
};
const owned=el('[data-device]');children.push(owned);
const host={innerHTML:'',classList:{toggle(){}},setAttribute(){},querySelector:el,
 querySelectorAll:key=>key==='button,input,select'?children:[]};
globalThis.document={hidden:false,addEventListener(){},removeEventListener(){}};
globalThis.window={addEventListener(){}};globalThis.location={search:''};
globalThis.crypto=require('node:crypto').webcrypto;
let requests=0;globalThis.fetch=()=>{requests++;throw Error('UNEXPECTED_PRODUCT_REQUEST');};
const view=mountContinuousExecution(host,{biology:true});
const inspector={};const internal={disabled:true,
 closest:selector=>selector==='[data-molecular-inspector]'?inspector:null};
children.push(internal);owned.disabled=true;
try{
 el('[data-engine]').handlers.change();
 assert.equal(internal.disabled,true,'Execution parent overwrote inspector-owned disabled state');
 assert.equal(owned.disabled,false,'Existing execution-owned control lost its update');
 assert.equal(requests,0);
}finally{view.dispose();}
completed=true;
})().catch(error=>{console.error(error.name,error.message);process.exitCode=1;});
""".replace("PARENT", json.dumps(PARENT.as_uri()))
    result = subprocess.run(
        [require_node(), "--eval", script],
        cwd=ROOT, capture_output=True, text=True, timeout=10, encoding="utf-8",
    )
    assert result.returncode == 0, result.stdout + result.stderr


@pytest.mark.parametrize("phase", ["open", "close"])
def test_deferred_old_rejection_cannot_replace_new_target_feedback(phase):
    operation = (
        "fail='open';buttons()[0].click();await tick();"
        if phase == "open" else
        "fail='close';nodes.get('[data-organ]').handlers.change({target:{value:'liver'}});await tick();"
    )
    execution_consumer("""
buttons()[0].click();await tick();
const originalReject=Promise.reject;let release;
Promise.reject=reason=>new Promise((_,reject)=>{release=()=>reject(reason);});
try{
""" + operation + """
}finally{Promise.reject=originalReject;}
fail=null;buttons().at(-1).click();await tick();
const current=nodes.get('[data-molecular-feedback]').textContent;
assert(current.includes('Reference coordinates only'));
assert.equal(typeof release,'function');release();await tick();
assert.equal(nodes.get('[data-molecular-feedback]').textContent,current,
 'Old rejection overwrote new feedback');
assert.equal(mounts.length,1);
""")
