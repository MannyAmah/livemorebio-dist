"""Explicit authority recovery, authored responses only; no server/native work."""
from copy import deepcopy
import json
from types import SimpleNamespace

import pytest

from livemorebio.sdk import Platform
from livemorebio.execution_client import ContinuousClientError
from livemorebio.shell import run_command, run_pipeline
from .test_frozen_member_response_limits import ByteResponse, attached, REQUEST_ID


def acknowledgment(kind="unavailable"):
    from livemorebio.aegle.model_contexts import model_availability
    from .clinical_registry_fixtures import legacy_twin_record
    record = None if kind == "preview" else legacy_twin_record("reconcile", version=3)
    if record:
        record["lifecycle"] = "ACTIVE"
        if kind == "ready":
            record["source_class"] = "SYNTHETIC"
    subject = {key: record[key] for key in ("twin_id", "subject_id", "display_label", "source_class", "lifecycle", "version")} if record else None
    return {"selection_status": "CONFIRMED", "subject": subject,
            "model_availability": model_availability(record, source_generation="technical-generation"),
            "prior_execution_cleanup": "INSPECT_EXISTING_STATUS"}


@pytest.mark.parametrize("kind", ["unavailable", "ready", "preview"])
def test_reconcile_one_empty_post_validates_producer_projection_and_never_reads(monkeypatch, kind):
    value = acknowledgment(kind)
    response = ByteResponse(json.dumps(value).encode())
    platform, calls = attached(monkeypatch, response)
    assert platform.reconcile_twin_selection() == value
    assert len(calls) == response.closed == 1
    assert calls[0].method == "POST" and calls[0].full_url.endswith("/api/twins/reconcile-selection")
    assert calls[0].data == b"{}" and calls[0].get_header("Idempotency-key") is None
    assert platform.last_continuous_response["request_id"] == REQUEST_ID


@pytest.mark.parametrize("change", [
    lambda x: x.update(selection_status="UNCONFIRMED"), lambda x: x.update(extra=True),
    lambda x: x.update(prior_execution_cleanup="COMPLETE"), lambda x: x.update(subject=None),
    lambda x: x["subject"].update(version=4), lambda x: x["subject"].update(version=True),
    lambda x: x["subject"].update(twin_id="wrong-twin"), lambda x: x["subject"].update(lifecycle="DATA_ADMITTED"),
    lambda x: x["subject"].update(source_class="invented"), lambda x: x["subject"].update(extra=True),
    lambda x: x["model_availability"].update(preparation_available=True),
])
def test_reconcile_malformed_success_is_unconfirmed_once(monkeypatch, change):
    value = acknowledgment(); change(value)
    response = ByteResponse(json.dumps(value).encode())
    platform, calls = attached(monkeypatch, response)
    with pytest.raises(ContinuousClientError) as error:
        platform.reconcile_twin_selection()
    assert error.value.code == "CLIENT_UNCONFIRMED" and error.value.request_id == REQUEST_ID
    assert len(calls) == response.closed == 1


@pytest.mark.parametrize("header", [None, "a" * 32, "PRIVATE_SENTINEL", REQUEST_ID.upper()])
def test_reconcile_requires_current_canonical_uuid_not_old_metadata(monkeypatch, header):
    response = ByteResponse(json.dumps(acknowledgment()).encode())
    response.headers = {} if header is None else {"X-Request-ID": header}
    platform, calls = attached(monkeypatch, response)
    platform.last_continuous_response = {"request_id": REQUEST_ID}
    with pytest.raises(ContinuousClientError) as error:
        platform.reconcile_twin_selection()
    assert error.value.code == "CLIENT_UNCONFIRMED" and error.value.request_id is None
    assert len(calls) == response.closed == 1 and "PRIVATE" not in str(error.value)


@pytest.mark.parametrize("status,code", [(409, "SELECTION_RECONCILIATION_CONFLICT"), (503, "REGISTRY_STORAGE_UNAVAILABLE")])
def test_reconcile_fixed_conflict_and_storage_codes_survive(monkeypatch, status, code):
    response = ByteResponse(json.dumps({"code": code, "error": "PRIVATE_SENTINEL"}).encode(), status=status)
    platform, calls = attached(monkeypatch, response)
    with pytest.raises(ContinuousClientError) as error:
        platform.reconcile_twin_selection()
    assert error.value.code == code and error.value.request_id == REQUEST_ID
    assert "PRIVATE" not in str(error.value) and len(calls) == response.closed == 1


def test_sdk_reconcile_never_has_inprocess_fallback(monkeypatch):
    platform = object.__new__(Platform); platform.mode = "inprocess"
    monkeypatch.setattr(platform, "_continuous_request", lambda *a, **k: pytest.fail("local fallback"))
    with pytest.raises(ContinuousClientError):
        platform.reconcile_twin_selection()


@pytest.mark.parametrize("suffix", ["twin-id", "version=3", "json=true", "?subject=x", "'PRIVATE_UNTERMINATED"])
def test_terminal_exact_reconcile_rejects_extra_or_malformed_arguments(tmp_path, suffix):
    path = tmp_path / "authored-input.txt"
    path.write_text(f'twin re"concile-selection" {suffix}\n', encoding="utf-8")
    class NoCalls:
        def __getattr__(self, name):
            pytest.fail("invalid recovery command reached SDK")
    lines = []
    with pytest.raises(ContinuousClientError):
        run_pipeline(NoCalls(), str(path), out=lines.append)
    assert lines == ["livemore› twin reconcile-selection"]


def test_terminal_reconcile_emits_metadata_not_subject_payload():
    value = acknowledgment(); value["subject"]["display_label"] = "PRIVATE_SENTINEL"
    lines, calls = [], []
    platform = SimpleNamespace(reconcile_twin_selection=lambda: calls.append(1) or value,
                               last_continuous_response={"request_id": REQUEST_ID})
    run_command(platform, "twin reconcile-selection", out=lines.append)
    text = "\n".join(lines)
    assert calls == [1] and "CONFIRMED" in text and "INSPECT_EXISTING_STATUS" in text
    assert REQUEST_ID in text and "PRIVATE" not in text and value["subject"]["subject_id"] not in text


def test_uncertain_twin_list_is_null_aware_and_does_not_claim_absent_selection():
    lines = []
    platform = SimpleNamespace(list_twins=lambda **kw: {"selection_status": "UNCONFIRMED", "active": None, "twins": [], "pagination": {}})
    run_command(platform, "twin list", out=lines.append)
    assert "UNCONFIRMED" in "\n".join(lines) and "No active" not in "\n".join(lines)


def test_attached_shell_can_reach_recovery_command_under_actual_deny_all_error(monkeypatch, capsys):
    import livemorebio.shell as shell
    response = ByteResponse(b'{"code":"SELECTION_COMMIT_UNCONFIRMED"}', status=503)
    platform, calls = attached(monkeypatch, response)
    monkeypatch.setattr(platform, "_get", lambda *a: pytest.fail("state used legacy unsafe error transport"))
    monkeypatch.setattr(shell, "Platform", lambda **kw: platform)
    commands = iter(["help", "quit"])
    monkeypatch.setattr("builtins.input", lambda *a: next(commands))
    shell.run_shell(mode="attach")
    output = capsys.readouterr().out
    assert "SELECTION_COMMIT_UNCONFIRMED" in output and "twin reconcile-selection" in output and "bye" in output
    assert len(calls) == 1 and calls[0].method == "GET" and calls[0].full_url.endswith("/api/state")


@pytest.mark.parametrize("code", ["CLIENT_AUTH_REQUIRED", "REGISTRY_STORAGE_UNAVAILABLE", "CLIENT_TRANSPORT"])
def test_startup_does_not_relabel_operational_error_as_empty_selection(monkeypatch, code):
    import livemorebio.shell as shell
    def failure(): raise ContinuousClientError(code)
    monkeypatch.setattr(shell, "Platform", lambda **kw: SimpleNamespace(state=failure))
    monkeypatch.setattr("builtins.input", lambda *a: pytest.fail("operational failure became a blank ready shell"))
    with pytest.raises(ContinuousClientError): shell.run_shell(mode="attach")


@pytest.mark.parametrize("raw", [b'{"subject":1,"subject":2}', b'{"x":NaN}', b'{"x":1e999}', b'[]', b'\xff\xfe'])
def test_malformed_reconciliation_body_stays_uncertain_once(monkeypatch, raw):
    response = ByteResponse(raw)
    platform, calls = attached(monkeypatch, response)
    with pytest.raises(ContinuousClientError) as error:
        platform.reconcile_twin_selection()
    assert error.value.code == "CLIENT_UNCONFIRMED"
    assert len(calls) == response.closed == 1


@pytest.mark.parametrize("failure", [TimeoutError("PRIVATE_SENTINEL"), OSError("PRIVATE_SENTINEL")])
def test_reconcile_body_loss_never_retries_or_echoes_failure(monkeypatch, failure):
    response = ByteResponse(b"{}", failure=failure)
    platform, calls = attached(monkeypatch, response)
    with pytest.raises(ContinuousClientError) as error:
        platform.reconcile_twin_selection()
    assert error.value.code == "CLIENT_UNCONFIRMED" and "PRIVATE" not in str(error.value)
    assert len(calls) == response.closed == 1


@pytest.mark.parametrize("kind", ["oversize", "duplicate", "invalid_utf8"])
def test_safe_attached_state_transport_rejects_instead_of_truncating(monkeypatch, kind):
    from livemorebio.execution_client import MAX_RESPONSE_BYTES
    raw = {"oversize": b'{"v":"' + b'x' * MAX_RESPONSE_BYTES + b'"}', "duplicate": b'{"profile":1,"profile":2}', "invalid_utf8": b'\xff'}[kind]
    response = ByteResponse(raw)
    platform, calls = attached(monkeypatch, response)
    monkeypatch.setattr(platform, "_get", lambda *a: pytest.fail("legacy fallback"))
    with pytest.raises(ContinuousClientError) as error:
        platform.state()
    assert error.value.code == "CLIENT_RESPONSE"
    assert len(calls) == response.closed == 1 and calls[0].method == "GET"
    assert calls[0].full_url.endswith('/api/state') and calls[0].data is None
    assert response.read_sizes == [MAX_RESPONSE_BYTES + 1]


def test_reconcile_valid_unicode_limits_match_actual_producer_codepoints(monkeypatch):
    value = acknowledgment()
    value['subject']['display_label'] = '\U0001f9ea' * 80
    response = ByteResponse(json.dumps(value).encode())
    platform, calls = attached(monkeypatch, response)
    assert platform.reconcile_twin_selection() == value
    assert len(calls) == 1


@pytest.mark.parametrize("method", ["GET", "POST"])
@pytest.mark.parametrize("status", [200, 201])
@pytest.mark.parametrize("expected", [None, 200, 201])
def test_explicit_success_status_matches_only_after_strict_current_response(monkeypatch, method, status, expected):
    response = ByteResponse(b'{}', status=status)
    platform, calls = attached(monkeypatch, response)
    if expected is None or status == expected:
        assert platform._continuous_request(method, '/api/technical-status', {} if method == 'POST' else None, expected_status=expected) == {}
    else:
        with pytest.raises(ContinuousClientError) as error:
            platform._continuous_request(method, '/api/technical-status', {} if method == 'POST' else None, expected_status=expected)
        assert error.value.code == ('CLIENT_UNCONFIRMED' if method == 'POST' else 'CLIENT_RESPONSE')
        assert error.value.request_id == REQUEST_ID
    assert len(calls) == response.closed == 1
    assert platform.last_continuous_response == {'request_id': REQUEST_ID}


@pytest.mark.parametrize("expected", [True, False, 200.0, '200', 0, 202, {}, []])
def test_invalid_status_expectation_rejected_before_attachment_or_auth(monkeypatch, expected):
    platform = Platform(mode='attach')
    monkeypatch.setattr(platform, '_url', lambda: pytest.fail('invalid expectation reached attachment lookup'))
    with pytest.raises(ContinuousClientError) as error:
        platform._continuous_request('GET', '/api/technical-status', expected_status=expected)
    assert error.value.code == 'CLIENT_INVALID' and error.value.request_id is None


def test_expected_success_status_does_not_replace_non_success_typed_error(monkeypatch):
    response = ByteResponse(b'{"code":"SELECTION_RECONCILIATION_CONFLICT"}', status=409)
    platform, calls = attached(monkeypatch, response)
    with pytest.raises(ContinuousClientError) as error:
        platform._continuous_request('POST', '/api/twins/reconcile-selection', {}, expected_status=200)
    assert error.value.code == 'SELECTION_RECONCILIATION_CONFLICT' and error.value.request_id == REQUEST_ID
    assert len(calls) == response.closed == 1


def test_reconcile_does_not_confirm_wrong_success_status(monkeypatch):
    response = ByteResponse(json.dumps(acknowledgment()).encode(), status=201)
    platform, calls = attached(monkeypatch, response)
    with pytest.raises(ContinuousClientError) as error:
        platform.reconcile_twin_selection()
    assert error.value.code == 'CLIENT_UNCONFIRMED' and error.value.request_id == REQUEST_ID
    assert len(calls) == response.closed == 1


def test_wrong_success_status_retains_original_error_when_response_close_fails(monkeypatch):
    response = ByteResponse(b'{}', status=201)
    def close():
        response.closed += 1
        raise OSError('PRIVATE_SENTINEL')
    response.close = close
    platform, calls = attached(monkeypatch, response)
    with pytest.raises(ContinuousClientError) as error:
        platform._continuous_request('POST', '/api/twins/reconcile-selection', {}, expected_status=200)
    assert error.value.code == 'CLIENT_UNCONFIRMED' and error.value.request_id == REQUEST_ID
    assert error.value.status == 201 and 'PRIVATE' not in str(error.value)
    assert platform.last_continuous_response == {'request_id': REQUEST_ID, 'cleanup_code': 'CLIENT_TRANSPORT'}
    assert len(calls) == response.closed == 1
