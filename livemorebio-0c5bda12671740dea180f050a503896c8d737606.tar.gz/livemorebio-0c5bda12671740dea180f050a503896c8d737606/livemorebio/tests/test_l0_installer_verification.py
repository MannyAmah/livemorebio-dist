"""Execute the installer boundary itself; no service, install or network needed."""
from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys
import tempfile

import pytest

from ._source_tree import source_tree_only


ROOT = Path(__file__).resolve().parents[2]
pytestmark = source_tree_only("install.sh")
SERVICE_SETTINGS = {
    "LIVEMORE_AEGLE_URL", "LIVEMORE_LIFE_URL", "LIVEMORE_CENDOS_URL",
    "LIVEMORE_AEGLE_IDENTITY_AUTHORITY", "LIVEMORE_LIFE_IDENTITY_AUTHORITY",
    "LIVEMORE_CENDOS_IDENTITY_AUTHORITY",
}


def verification_program(installer: Path) -> str:
    """Read the exact heredoc, so a copied environment builder cannot pass."""
    function = installer.read_text(encoding="utf-8").split(
        "run_isolated_verification() {\n", 1
    )[1]
    return function.split("<<'PY'\n", 1)[1].split("\nPY\n", 1)[0]


@pytest.mark.parametrize("polluted", [False, True])
@pytest.mark.parametrize("returncode", [0, 37])
def test_installer_verification_keeps_isolation_and_relinquishes_service_configuration(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, polluted: bool, returncode: int,
) -> None:
    # Mirror the installed layout: TMPDIR is outside the release. A source link
    # runs the actual helper without copying or reimplementing its behavior.
    release = tmp_path / "release"
    release.mkdir()
    source = release / "source"
    source.symlink_to(ROOT, target_is_directory=True)
    scratch = tmp_path / "scratch"
    scratch.mkdir()
    model_cache = tmp_path / "retained-model-cache"
    inherited = dict(os.environ)
    inherited.update(
        LIVEMORE_DATA_DIR=str(tmp_path / "operational-data"),
        LIVEMORE_MODEL_DIR=str(model_cache),
        LIVEMORE_TEST_GENOME_MODELS="1", LIVEMORE_TEST_CARDIAC="1",
    )
    if polluted:
        inherited.update({name: "http://127.0.0.1:19880" for name in SERVICE_SETTINGS})
        inherited.update(
            LIVEMORE_SERVICE_IDENTITY_KEY="technical-inherited-key",
            LIVEMORE_SERVICE_IDENTITY_AUTHORITY="http://127.0.0.1:19880",
            LIVEMORE_SERVICE_IDENTITY_FUTURE="technical-future-setting",
            LIVEMORE_CONSOLE_PEER="1",
        )
    monkeypatch.setattr(os, "environ", inherited)
    monkeypatch.setattr(tempfile, "tempdir", str(scratch))
    monkeypatch.setattr(sys, "argv", ["-", str(source), "technical-selection.py"])
    calls = []

    def capture(command, **kwargs):
        calls.append((command, kwargs))
        return subprocess.CompletedProcess(command, returncode)

    monkeypatch.setattr(subprocess, "run", capture)
    namespace = {"__name__": "__main__"}
    with pytest.raises(SystemExit) as result:
        exec(compile(verification_program(ROOT / "install.sh"), str(ROOT / "install.sh"), "exec"), namespace)
    assert result.value.code == returncode
    assert len(calls) == 1
    command, options = calls[0]
    assert command == [str(source / ".venv/bin/python"), "-I", "-B", "-X", "utf8", "-m", "pytest",
                       "-p", "no:cacheprovider", "-q", "technical-selection.py"]
    assert options["cwd"] == source
    environment = options["env"]
    forbidden = SERVICE_SETTINGS | {name for name in environment if name.startswith("LIVEMORE_SERVICE_IDENTITY_")}
    assert not forbidden.intersection(environment), sorted(forbidden.intersection(environment))
    assert "LIVEMORE_CONSOLE_PEER" not in environment
    data = Path(environment["LIVEMORE_DATA_DIR"])
    assert data.is_relative_to(scratch.resolve())
    assert data != Path(inherited["LIVEMORE_DATA_DIR"])
    assert data.stat().st_mode & 0o777 == 0o700
    helper = namespace["helper"]
    for name, (relative, _) in helper._STORE_PATHS.items():
        expected = model_cache if name == "LIVEMORE_MODEL_DIR" else data / relative
        assert Path(environment[name]) == expected, name
    for name, relative in helper._CREDENTIALS.items():
        credential = data / relative
        assert credential.is_file(), name
        assert credential.stat().st_mode & 0o777 == 0o600, name
        if name != "LIVEMORE_SERVICE_IDENTITY_KEY":
            assert environment[name] == credential.read_text(encoding="ascii").strip(), name
    assert environment["LIVEMORE_TEST_GENOME_MODELS"] == "1"
    assert environment["LIVEMORE_TEST_CARDIAC"] == "1"
    assert not Path(inherited["LIVEMORE_DATA_DIR"]).exists()
