"""No-browser regressions for the one-load diagnostic, never product evidence."""
import json
from pathlib import Path
import subprocess
import pytest
from ._node import require_node

MODULE = Path(__file__).resolve().parents[2] / "tools/check_atlas_request_diagnostic.cjs"


def run(script: str) -> None:
    result = subprocess.run(
        [require_node(), "--eval", f"const h=require({json.dumps(str(MODULE))});" + script],
        capture_output=True, text=True, timeout=15, encoding="utf-8",
    )
    assert result.returncode == 0, result.stderr


def test_diagnostic_preserves_response_then_failure_and_all_clock_domains():
    run("""
const a=require('node:assert/strict');let now=100;
const assets=[{asset_key:'skin',bytes:16,sha256:'a'.repeat(64)}];
const c=h.createRequestCollector(assets,()=>now),r={};
c.begin(r,h.PIN.base+'/assets/anatomy/atlas/'+h.PIN.manifest+'/skin.glb','GET');now=105;
c.response(r,{status:200,content_type:'model/gltf-binary',source_match:true,process_match:true});now=106;
c.terminal(r,'FAILED','net::ERR_ABORTED secret-query');
c.metrics(r,{startTime:1700000000000,responseEnd:5,responseStart:4},{responseBodySize:16});
c.finished(r,'NETWORK_ERROR');
const row=c.snapshot().requests[0];a.equal(row.response_status,200);a.equal(row.terminal,'FAILED');a.equal(row.failure_code,'ERR_ABORTED');a.equal(row.finished_outcome,'NETWORK_ERROR');a.equal(row.callback_response_ms,5);a.equal(row.callback_failed_ms,6);a.equal(row.timing.responseEnd,5);a.equal(row.sizes.responseBodySize,16);a(!JSON.stringify(row).includes('secret'));
const old=c.snapshot();c.finalize();now=107;c.terminal(r,'FINISHED');a.deepEqual(c.snapshot().requests,old.requests);a.equal(c.snapshot().late_callbacks,1);c.dispose();c.begin({},h.PIN.base+'/assets/anatomy/atlas/'+h.PIN.manifest+'/skin.glb','GET');a.equal(c.snapshot().requests.length,1);
""")


def test_diagnostic_fixed_resources_missing_duplicates_and_unknown_errors_stay_unresolved():
    run("""
const a=require('node:assert/strict'),asset={asset_key:'skin',bytes:16,sha256:'a'.repeat(64)},url=h.PIN.base+'/assets/anatomy/atlas/'+h.PIN.manifest+'/skin.glb';
const row={name:url,startTime:1,fetchStart:1,responseStart:2,responseEnd:3,duration:2,transferSize:16,encodedBodySize:16,decodedBodySize:16};
a.equal(h.resourceRows([asset],[])[0].state,'UNAVAILABLE');a.equal(h.resourceRows([asset],[row,row])[0].state,'AMBIGUOUS');a.equal(h.resourceRows([asset],[{...row,responseEnd:NaN}])[0].state,'MISMATCH');a.equal(h.resourceRows([asset],[{...row,decodedBodySize:17}])[0].state,'MISMATCH');a.equal(h.resourceRows([asset],[row])[0].state,'AVAILABLE');
a.equal(h.safeNetworkError('host/person?id=secret'),'OTHER_NETWORK_ERROR');a.equal(h.safeNetworkError(null),'UNAVAILABLE');a(!JSON.stringify(h.resourceRows([asset],[{...row,private:'secret'}])).includes('secret'));
const c=h.createRequestCollector([asset]);a.throws(()=>c.begin({},'https://other.invalid/skin.glb','GET'),e=>e.code==='UNAUTHORIZED_REQUEST');a.throws(()=>c.begin({},url+'?secret=x','GET'),e=>e.code==='UNAUTHORIZED_REQUEST');a.throws(()=>c.begin({},url,'POST'),e=>e.code==='UNAUTHORIZED_REQUEST');
""")


def test_request_wrapper_keeps_exact_factory_load_dispose_receiver_and_promise_identity():
    run("""
const a=require('node:assert/strict');
(async()=>{let factoryCalls=0,loads=0,disposes=0,now=10;const receiver={},args={private:'never'},value=new ArrayBuffer(16),promise=Promise.resolve(value),asset={asset_key:'skin',bytes:16,sha256:'a'.repeat(64)};
const original={load(...values){a.equal(this,original);a.equal(values[0],h.PIN.manifest);a.equal(values[1],asset);loads++;return promise},dispose(...values){a.equal(this,original);a.deepEqual(values,['same']);disposes++;return 'disposed'}};
const t=h.wrapRequestFactory(function(...values){a.equal(this,receiver);a.equal(values[0],args);factoryCalls++;return original},[asset],()=>now);
const wrapped=t.create.call(receiver,args);a.equal(factoryCalls,1);const returned=wrapped.load(h.PIN.manifest,asset);a.equal(returned,promise);a.equal(await returned,value);await Promise.resolve();a.equal(loads,1);a.equal(t.snapshot().loads[0].resolved_bytes,16);a.equal(wrapped.dispose('same'),'disposed');a.equal(disposes,1);a(!JSON.stringify(t.snapshot()).includes('private'));a(!JSON.stringify(t.snapshot()).includes('never'));
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_request_wrapper_metadata_throws_never_change_rejection_or_leak_child_rejections():
    run("""
const a=require('node:assert/strict');
(async()=>{const unhandled=[];process.on('unhandledRejection',e=>unhandled.push(e));
for(const reject of [false,true]){const failure=Error('same secret original'),p=reject?Promise.reject(failure):Promise.resolve(new ArrayBuffer(16)),asset={asset_key:'skin',bytes:16,sha256:'a'.repeat(64)};let calls=0;
const t=h.wrapRequestFactory(()=>({load(){calls++;return p},dispose(){}}),[asset],()=>1,()=>{throw Error('secret observer')});const q=t.create().load(h.PIN.manifest,asset);a.equal(q,p);if(reject)await a.rejects(q,e=>e===failure);else await q;await new Promise(resolve=>setImmediate(resolve));a.equal(calls,1);a.equal(t.snapshot().observer_state,'DIAGNOSTIC_OBSERVER_FAILED');a(!JSON.stringify(t.snapshot()).includes('secret'));}
a.equal(unhandled.length,0);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_request_wrapper_concurrency_uses_application_promises_not_network_callbacks():
    run("""
const a=require('node:assert/strict');
(async()=>{let now=0;const assets=['skin','heart','liver','brain'].map(asset_key=>({asset_key,bytes:16,sha256:'a'.repeat(64)})),resolvers={};const t=h.wrapRequestFactory(()=>({load(digest,a){return new Promise(resolve=>resolvers[a.asset_key]=resolve)},dispose(){}}),assets,()=>now);const r=t.create();const skin=r.load(h.PIN.manifest,assets[0]);now=1;resolvers.skin(new ArrayBuffer(16));await skin;await Promise.resolve();now=2;const heart=r.load(h.PIN.manifest,assets[1]),liver=r.load(h.PIN.manifest,assets[2]);now=3;resolvers.heart(new ArrayBuffer(16));await heart;await Promise.resolve();now=4;const brain=r.load(h.PIN.manifest,assets[3]);now=5;resolvers.liver(new ArrayBuffer(16));resolvers.brain(new ArrayBuffer(16));await Promise.all([liver,brain]);await Promise.resolve();const v=t.snapshot();a.equal(v.max_internal_concurrency,2);a.equal(v.first_internal_after_skin,true);a.equal(v.loads.length,4);a.equal(v.loads[0].resolved_ms,1);a.equal(v.loads[1].started_ms,2);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_diagnostic_shared_deadline_cancels_every_owned_resource_and_rejects_late_steps():
    run("""
const a=require('node:assert/strict');
(async()=>{let now=0,id=0,closes=0,rejectStep;const timers=new Map(),clock={now:()=>now,setTimeout:(fn,ms)=>{timers.set(++id,{fn,due:now+ms});return id},clearTimeout:i=>timers.delete(i)};
const b=h.createDiagnosticBudget(clock);b.own({close:async()=>{closes++;rejectStep?.(Error('canceled private'))}});
const p=b.run(()=>new Promise((_,reject)=>rejectStep=reject));p.catch(()=>{});await Promise.resolve();await Promise.resolve();now=90000;for(const[i,t]of[...timers])if(t.due<=now){timers.delete(i);t.fn()};await a.rejects(p,e=>e.code==='DIAGNOSTIC_DEADLINE');a.equal(closes,1);let called=0;await a.rejects(b.run(()=>called++));a.equal(called,0);a.equal(await b.finish(),'SETTLED');a.equal(timers.size,0);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_diagnostic_late_launch_is_closed_and_hanging_cleanup_is_not_accepted():
    run("""
const a=require('node:assert/strict');
(async()=>{let now=0,id=0,resolveLaunch,closes=0;const timers=new Map(),clock={now:()=>now,setTimeout:(fn,ms)=>{timers.set(++id,{fn,due:now+ms});return id},clearTimeout:i=>timers.delete(i)},b=h.createDiagnosticBudget(clock);
const p=b.acquire(()=>new Promise(resolve=>resolveLaunch=resolve));p.catch(()=>{});await Promise.resolve();await Promise.resolve();now=90000;for(const[i,t]of[...timers])if(t.due<=now){timers.delete(i);t.fn()};await a.rejects(p);resolveLaunch({close:async()=>closes++});await new Promise(resolve=>setImmediate(resolve));a.equal(closes,1);a.equal(await b.finish(),'SETTLED');
const c=h.createDiagnosticBudget(clock);c.own({close:()=>new Promise(()=>{})});const done=c.finish();await Promise.resolve();await Promise.resolve();now+=5000;for(const[i,t]of[...timers])if(t.due<=now){timers.delete(i);t.fn()};a.equal(await done,'CLEANUP_UNCONFIRMED');
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_diagnostic_source_context_auth_and_cleanup_are_hard_stops():
    run("""
const a=require('node:assert/strict');
for(const code of ['SOURCE_MISMATCH','CONTEXT_MISMATCH','AUTH_UNAVAILABLE','UNAUTHORIZED_REQUEST','DIAGNOSTIC_OBSERVER_FAILED','CLEANUP_UNCONFIRMED'])a.equal(h.hardStop(new h.DiagnosticError(code)),true);
a.equal(h.hardStop(Error('unclassified')),true);a.equal(h.hardStop(new h.DiagnosticError('PERFORMANCE_GATE_FAILED')),false);a.equal(h.hardStop(new h.DiagnosticError('FUNCTIONAL_UNAVAILABLE')),false);
""")


def test_diagnostic_module_routes_are_fixed_and_never_read_or_refetch_response_bodies():
    run("""
const a=require('node:assert/strict'),source=h.requestWrapperSource([{asset_key:'skin',bytes:16,sha256:'a'.repeat(64)}]);
a(source.includes(h.ORIGINAL_REQUEST));a(!source.includes('window.'));a(!source.includes('globalThis.'));a.equal(h.requestModuleRoute(h.PIN.base+h.REQUEST_PATH),'wrapper');a.equal(h.requestModuleRoute(h.PIN.base+h.ORIGINAL_REQUEST),'original');
for(const url of [h.PIN.base+h.REQUEST_PATH+'?other=1','https://other.invalid'+h.REQUEST_PATH])a.equal(h.requestModuleRoute(url),null);
""")
    source = MODULE.read_text(encoding="utf-8")
    assert ".body(" not in source
    assert "route.fetch(" not in source
    assert "addInitScript" not in source
    assert "Object.defineProperty(document" not in source


def test_acceptance_registers_skipped_cases_and_separates_timing_from_functional_coverage():
    run("""
const a=require('node:assert/strict');
(async()=>{const book=h.createCoverageBook([{name:'warm',mode:'ordinary'},{name:'controls',mode:'ordinary'},{name:'fault',mode:'faults'}]);let controls=0,faults=0;book.fail('warm','PERFORMANCE_GATE_FAILED');
await book.dependent('controls',true,async()=>controls++);await book.dependent('fault',true,async()=>faults++);a.equal(controls,1);a.equal(faults,1);a.equal(book.passed(),false);a.equal(book.rows()[1].state,'PASS');
const absent=h.createCoverageBook([{name:'control',mode:'ordinary'}]);await absent.dependent('control',false,async()=>a.fail());a.equal(absent.rows()[0].state,'NOT_RUN');a.equal(absent.rows()[0].reason,'FUNCTIONAL_UNAVAILABLE');
const stopped=h.createCoverageBook([{name:'one',mode:'ordinary'},{name:'two',mode:'faults'}]);await a.rejects(stopped.dependent('one',true,async()=>{throw new h.DiagnosticError('SOURCE_MISMATCH')}));await a.rejects(stopped.dependent('two',true,async()=>a.fail()));a.equal(stopped.rows()[1].state,'NOT_RUN');a.equal(stopped.rows()[1].reason,'SOURCE_MISMATCH');
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_actual_acceptance_case_runner_retains_failed_performance_and_continues_ready_controls():
    run("""
const a=require('node:assert/strict'),main=require('./tools/check_atlas_browser.cjs');
(async()=>{const plan=main.acceptancePlan();a.equal(new Set(plan.map(x=>x.name)).size,plan.length);for(const name of ['warm-1440-1','whole-person-front','five-dispose-reopen','fault-missing','fault-context-loss','fault-install-valid','mobile-touch-reduced-motion'])a(plan.some(x=>x.name===name));
const coverage=h.createCoverageBook(plan),evidence={cases:coverage.rows(),coverage},env={mode:'ordinary',control:{blocked:0}},config={deadline:performance.now()+10000},writes=[],hooks={fence:async()=>{},capture:async()=>{},persist:async()=>writes.push(JSON.parse(JSON.stringify(evidence.cases)))};
const warm={skin_completed:false,request_count:9,max_internal_concurrency:3,first_internal_after_skin:false,skin_after_response_ms:null,all_layers_ms:6000};
a.equal(await main.caseRun(env,config,evidence,'warm-1440-1',async record=>{await record({warm});main.requireWarm(warm)},hooks),false);
let controls=0;await main.afterPerformance(evidence,true,['whole-person-front'],()=>main.caseRun(env,config,evidence,'whole-person-front',async()=>controls++,hooks));a.equal(controls,1);a.equal(evidence.cases.find(x=>x.name==='warm-1440-1').state,'FAIL');a.equal(evidence.cases.find(x=>x.name==='whole-person-front').state,'PASS');a.equal(coverage.passed(),false);a(writes.some(rows=>rows.find(x=>x.name==='warm-1440-1').metadata?.warm?.max_internal_concurrency===3));
await main.afterPerformance(evidence,false,['five-dispose-reopen'],async()=>a.fail());a.equal(evidence.cases.find(x=>x.name==='five-dispose-reopen').reason,'FUNCTIONAL_UNAVAILABLE');
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_actual_acceptance_case_runner_does_not_swallow_identity_or_unknown_failures():
    run("""
const a=require('node:assert/strict'),main=require('./tools/check_atlas_browser.cjs');
(async()=>{for(const failure of [new h.DiagnosticError('CONTEXT_MISMATCH'),Error('unknown secret')]){const coverage=h.createCoverageBook([{name:'first',mode:'ordinary'},{name:'second',mode:'faults'}]),evidence={cases:coverage.rows(),coverage};let screenshots=0,actions=0;const hooks={fence:async()=>{},capture:async()=>screenshots++,persist:async()=>{}},env={mode:'ordinary',control:{blocked:0}},config={deadline:performance.now()+10000};
await a.rejects(main.caseRun(env,config,evidence,'first',async()=>{throw failure},hooks),e=>e===failure);await a.rejects(main.caseRun(env,config,evidence,'second',async()=>actions++,hooks));a.equal(actions,0);a.equal(screenshots,0);a.equal(evidence.cases[1].state,'NOT_RUN');a(!JSON.stringify(evidence).includes('secret'));}
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_actual_response_collector_settlement_uses_no_body_and_preserves_failed_response():
    run("""
const a=require('node:assert/strict');
(async()=>{const asset={asset_key:'skin',bytes:16,sha256:'a'.repeat(64)},url=h.PIN.base+'/assets/anatomy/atlas/'+h.PIN.manifest+'/skin.glb';let bodyCalls=0,sizesCalls=0,finishedCalls=0;const request={timing:()=>({startTime:100,responseEnd:5}),sizes:async()=>{sizesCalls++;return{responseBodySize:16}}},collector=h.createRequestCollector([asset]);collector.begin(request,url,'GET');collector.response(request,{status:200});
await h.collectResponseCompletion(collector,request,{finished:async()=>{finishedCalls++;throw Error('private network failure')},body:()=>bodyCalls++},{run:fn=>fn(),isExpired:()=>false});
a.equal(bodyCalls,0);a.equal(finishedCalls,1);a.equal(sizesCalls,1);const row=collector.snapshot().requests[0];a.equal(row.response_status,200);a.equal(row.finished_outcome,'NETWORK_ERROR');a.equal(row.sizes.responseBodySize,16);a(!JSON.stringify(row).includes('private'));
const expired=h.createRequestCollector([asset]);expired.begin(request,url,'GET');await h.collectResponseCompletion(expired,request,{finished:async()=>null},{run:async()=>{throw new h.DiagnosticError('DIAGNOSTIC_DEADLINE')},isExpired:()=>true});a.equal(expired.snapshot().requests[0].finished_outcome,'DEADLINE');
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_diagnostic_rejects_nonfinite_or_late_clock_even_before_alarm_dispatch():
    run("""
const a=require('node:assert/strict');
(async()=>{for(const late of [90001,NaN,Infinity]){let now=0,id=0,closed=0;const timers=new Map(),clock={now:()=>now,setTimeout:(fn,ms)=>{timers.set(++id,fn);return id},clearTimeout:i=>timers.delete(i)},b=h.createDiagnosticBudget(clock);b.own({close:async()=>closed++});await a.rejects(b.run(async()=>{now=late}),e=>e.code==='DIAGNOSTIC_DEADLINE');a.equal(await b.finish(),'SETTLED');a.equal(closed,1);a.equal(timers.size,0);}}
)().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_request_wrapper_is_wired_to_actual_unchanged_loader_signature_and_verification():
    run("""
const a=require('node:assert/strict'),{pathToFileURL}=require('node:url'),{createHash}=require('node:crypto'),path=require('node:path');
(async()=>{const module=await import(pathToFileURL(path.resolve('livemorebio/aegle/console/lib/atlas_reference_requests.js')));const bytes=new Uint8Array([1,2,3,4]),asset={asset_key:'skin',bytes:4,sha256:createHash('sha256').update(bytes).digest('hex')};let fetches=0,reads=0,cancels=0,releases=0,originalPromise;
const fetchImpl=async(url,options)=>{fetches++;a(url.endsWith('/'+h.PIN.manifest+'/skin.glb'));a.equal(options.method,'GET');return{ok:true,status:200,redirected:false,headers:new Headers({'Content-Type':'model/gltf-binary','X-Content-SHA256':asset.sha256,'X-Atlas-Manifest-SHA256':h.PIN.manifest}),body:{getReader:()=>({read:async()=>++reads===1?{value:bytes,done:false}:{done:true},cancel:async()=>cancels++,releaseLock:()=>releases++})}}};
const factory=options=>{const original=module.createAtlasAssetRequests(options);return{load(...args){originalPromise=original.load(...args);return originalPromise},dispose:()=>original.dispose()}};
const tracker=h.wrapRequestFactory(factory,[asset]),client=tracker.create({fetchImpl});const returned=client.load(h.PIN.manifest,asset);a.equal(returned,originalPromise);a.deepEqual([...new Uint8Array(await returned)],[1,2,3,4]);await Promise.resolve();a.equal(fetches,1);a.equal(reads,2);a.equal(cancels,1);a.equal(releases,1);a.equal(tracker.snapshot().loads[0].resolved_bytes,4);client.dispose();a.equal(tracker.snapshot().dispose_calls,1);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_request_observer_finalization_does_not_rewrite_late_original_result():
    run("""
const a=require('node:assert/strict');
(async()=>{let resolve;const value=new ArrayBuffer(16),asset={asset_key:'skin',bytes:16,sha256:'a'.repeat(64)},original=new Promise(r=>resolve=r),t=h.wrapRequestFactory(()=>({load:()=>original,dispose(){}}),[asset]);const returned=t.create().load(h.PIN.manifest,asset);const frozen=t.finalize();resolve(value);a.equal(await returned,value);await Promise.resolve();a.deepEqual(t.snapshot(),frozen);
const failure=Error('private original'),broken=h.wrapRequestFactory(()=>({load(){throw failure},dispose(){}}),[asset]);a.throws(()=>broken.create().load(h.PIN.manifest,asset),e=>e===failure);a.equal(broken.snapshot().loads[0].outcome,'REJECTED');a(!JSON.stringify(broken.snapshot()).includes('private'));
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_actual_camera_cleanup_failure_hard_stops_the_acceptance_runner():
    run("""
const a=require('node:assert/strict'),main=require('./tools/check_atlas_browser.cjs');
(async()=>{const browser={},context={browser:()=>browser};let closes=0,actions=0,captures=0;
const control={count:async()=>1,isVisible:async()=>true,isEnabled:async()=>true,evaluate:async()=>({}),click:async()=>{},scrollIntoViewIfNeeded:async()=>{},boundingBox:async()=>({x:0,y:0,width:100,height:100})};
const value={stopped:false,draw_count_before:7,draw_count_after:8,observed_draws:1,elapsed_ms:1,submission_ms:[2],raf_ms:[16],deadline_reached:false},recorder={snapshot:()=>value,stop:()=>{throw Error('private recorder failure')}};
const page={context:()=>context,close:async()=>closes++,locator:()=>control,evaluate:async()=>({live:{metrics:{draw_count:7,frame_ms:[2]}}}),evaluateHandle:async()=>({evaluate:async(fn,arg)=>fn(recorder,arg),dispose:async()=>{}}),mouse:{move:async()=>{throw Error('private input failure')},down:async()=>{},up:async()=>{}}};
const coverage=h.createCoverageBook([{name:'frame',mode:'instrumented'},{name:'later',mode:'faults'}]),evidence={coverage,cases:coverage.rows()},env={browser,context,page,mode:'instrumented',control:{blocked:0}},config={deadline:performance.now()+10000},hooks={fence:async()=>{},capture:async()=>captures++,persist:async()=>{}};
await a.rejects(main.caseRun(env,config,evidence,'frame',record=>main.cameraTiming(env,record),hooks),e=>e.code==='CLEANUP_UNCONFIRMED');await a.rejects(main.caseRun(env,config,evidence,'later',async()=>actions++,hooks));a.equal(actions,0);a.equal(captures,0);a.equal(evidence.cases[1].reason,'CLEANUP_UNCONFIRMED');a.equal(evidence.cases[0].metadata.sample.cleanup,'CLEANUP_UNCONFIRMED');a(!JSON.stringify(evidence).includes('private'));
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_context_setup_cleanup_rejection_is_typed_even_when_authentication_also_fails():
    run(r"""
const a=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),{createRequire}=require('node:module');
(async()=>{const filename=path.resolve('tools/check_atlas_browser.cjs'),module={exports:{}},scope={module,require:createRequire(filename),__dirname:path.dirname(filename),console,performance,setTimeout,clearTimeout,URL,process};vm.runInNewContext(fs.readFileSync(filename,'utf8')+'\nmodule.exports.setupContextForTest=setupContext;',scope);
let closes=0,dispose=0;const context={request:{get:async()=>({status:()=>401,dispose:async()=>dispose++})},close:async()=>{closes++;throw Error('private cleanup')}};
await a.rejects(module.exports.setupContextForTest({newContext:async()=>context},{},'ordinary',{}),e=>e.code==='CLEANUP_UNCONFIRMED');a.equal(closes,1);a.equal(dispose,1);
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def teardown_case(body: str) -> None:
    run(r"""
const a=require('node:assert/strict');let complete=false;
process.on('beforeExit',()=>{if(!complete)process.exitCode=1});
(async()=>{
let now=0,id=0;const timers=new Map(),order=[];
const clock={now:()=>now,setTimeout:(f,ms)=>{timers.set(++id,{f,ms});return id},clearTimeout:i=>timers.delete(i)};
const b=h.createDiagnosticBudget(clock,()=>order.push('freeze'),true,{attributeRoles:true});
const roles=['browser','context','page','cdp'];
const fire=ms=>{const matches=[...timers.values()].filter(t=>t.ms===ms);a.equal(matches.length,1);now+=ms;matches[0].f()};
const turn=()=>new Promise(setImmediate);
""" + body + r"""
complete=true;
})().catch(e=>{console.error(e);process.exitCode=1});
""")


def test_teardown_all_roles_keep_concurrent_old_order_and_detached_snapshot():
    teardown_case(r"""
let resolveCdp;for(const role of roles)b.own({close(){order.push(role);now++;
 return role==='cdp'?new Promise(r=>resolveCdp=r):Promise.resolve();}},role);
const finishing=b.finish();await turn();a.deepEqual(order,['freeze','cdp','page','context','browser']);
resolveCdp();a.equal(await finishing,'SETTLED');const snap=b.teardownSnapshot();
a.equal(snap.attribution_complete,true);a.equal(snap.drain,'SETTLED');a.equal(snap.pending_at_snapshot,0);
a.deepEqual(snap.roles.map(r=>r.close),roles.map(()=> 'FULFILLED'));
for(const r of snap.roles){a.equal(r.allocation,'OWNED');a(r.settled_ms>=r.started_ms);a.equal(r.error_class,null)}
snap.roles[0].close='PRIVATE';a.equal(b.teardownSnapshot().roles[0].close,'FULFILLED');
a.equal(await b.finish(),'SETTLED');a.equal(order.length,5);a.equal(timers.size,0);
""")


@pytest.mark.parametrize("role", ["browser", "context", "page", "cdp"])
@pytest.mark.parametrize("kind", ["reject", "pending"])
def test_teardown_each_close_failure_or_deadline_is_attributed(role, kind):
    teardown_case("const bad=" + json.dumps(role) + ",kind=" + json.dumps(kind) + ";" + r"""
let late;for(const role of roles)b.own({close(){order.push(role);now++;
 if(role!==bad)return Promise.resolve();if(kind==='reject')throw Error('PRIVATE raw stack/protocol');
 return new Promise(r=>late=r);}},role);
const finishing=b.finish();await turn();if(kind==='pending')fire(5000);
a.equal(await finishing,'CLEANUP_UNCONFIRMED');const snap=b.teardownSnapshot();
const row=snap.roles.find(r=>r.role===bad);a.equal(row.close,kind==='reject'?'REJECTED':'PENDING');
a.equal(row.error_class,kind==='reject'?'OTHER':null);a.equal(snap.drain,kind==='reject'?'SETTLED':'DEADLINE');
a.deepEqual(order,['freeze','cdp','page','context','browser']);a(!JSON.stringify(snap).includes('PRIVATE'));
if(late){late();await turn();a.deepEqual(b.teardownSnapshot(),snap)}
""")


def test_teardown_target_closed_after_parent_starts_is_not_waived():
    teardown_case(r"""
class TargetClosedError extends Error{}let rejectCdp;
for(const role of roles)b.own({close(){order.push(role);if(role==='cdp')return new Promise((_,r)=>rejectCdp=r);
 if(role==='browser')rejectCdp(new TargetClosedError('PRIVATE'));}},role);
a.equal(await b.finish(),'CLEANUP_UNCONFIRMED');const s=b.teardownSnapshot();
a.equal(s.roles.find(r=>r.role==='cdp').error_class,'TARGET_CLOSED');
a.equal(s.first_failure.role,'cdp');a.equal(s.first_failure.phase,'close');
a.deepEqual(order,['freeze','cdp','page','context','browser']);
""")


@pytest.mark.parametrize("late", [False, True])
def test_teardown_late_and_missing_allocation_are_distinct(late):
    teardown_case("const late=" + json.dumps(late) + ";" + r"""
let resolve;const acquire=b.acquire(()=>new Promise(r=>resolve=r),'browser');acquire.catch(()=>{});
await turn();fire(90000);await a.rejects(acquire);const finishing=b.finish();await turn();
if(late){resolve({close(){order.push('browser')}});await turn()}else fire(5000);
a.equal(await finishing,late?'SETTLED':'CLEANUP_UNCONFIRMED');const s=b.teardownSnapshot();
a.equal(s.roles[0].allocation,late?'OWNED':'PENDING');a.equal(s.roles[0].close,late?'FULFILLED':'NOT_STARTED');
a(s.roles.slice(1).every(r=>r.allocation==='NOT_REQUESTED'&&r.close==='NOT_STARTED'));
""")


def test_teardown_duplicate_role_is_refused_before_second_factory():
    teardown_case(r"""
let factories=0;await b.acquire(()=>{factories++;return {close(){}}},'browser');
await a.rejects(b.acquire(()=>{factories++;return {close(){}}},'browser'),{code:'CLEANUP_UNCONFIRMED'});
a.equal(factories,1);a.equal(await b.finish(),'CLEANUP_UNCONFIRMED');
a.equal(b.teardownSnapshot().attribution_complete,false);
""")


@pytest.mark.parametrize("failure", ["null", "throwing", "huge"])
def test_teardown_error_shape_is_bounded_and_unknown_safe(failure):
    teardown_case("const failure=" + json.dumps(failure) + ";" + r"""
const error=failure==='null'?null:failure==='throwing'?Object.defineProperty({},'constructor',{get(){throw Error('PRIVATE')}}):Error('PRIVATE'.repeat(10000));
b.own({close(){throw error}},'browser');a.equal(await b.finish(),'CLEANUP_UNCONFIRMED');
const s=b.teardownSnapshot();a.equal(s.roles[0].error_class,failure==='huge'?'OTHER':'UNKNOWN');
a(Buffer.byteLength(JSON.stringify(s))<=4096);a(!JSON.stringify(s).includes('PRIVATE'));
""")


@pytest.mark.parametrize("bad_clock", ["NaN", "-1", "Infinity"])
def test_teardown_invalid_clock_fails_attribution_without_losing_closure(bad_clock):
    teardown_case(r"""
let closes=0;b.own({close(){closes++}},'browser');
""" + "now=" + bad_clock + ";" + r"""
a.equal(await b.finish(),'CLEANUP_UNCONFIRMED');a.equal(closes,1);
const s=b.teardownSnapshot();a.equal(s.attribution_complete,false);
a(!JSON.stringify(s).includes('NaN'));a.equal(s.roles[0].started_ms,null);
""")


def test_teardown_before_cancel_failure_is_separate_and_no_resource_is_skipped():
    teardown_case(r"""
const c=h.createDiagnosticBudget(clock,()=>{throw Error('PRIVATE')},true,{attributeRoles:true});
let closed=0;c.own({close(){closed++}},'browser');a.equal(await c.finish(),'CLEANUP_UNCONFIRMED');
const s=c.teardownSnapshot();a.equal(closed,1);a.equal(s.phases.find(r=>r.phase==='before_cancel').status,'REJECTED');
a.equal(s.roles[0].close,'FULFILLED');a.equal(s.first_failure.phase,'before_cancel');
""")


@pytest.mark.parametrize("role", ["undefined", "'not-an-owned-role'"])
def test_teardown_invalid_role_never_starts_factory(role):
    teardown_case(r"""
let called=0;
""" + "await a.rejects(b.acquire(()=>{called++;return {close(){}}}," + role + r"""),{code:'CLEANUP_UNCONFIRMED'});
a.equal(called,0);a.equal(await b.finish(),'CLEANUP_UNCONFIRMED');
const s=b.teardownSnapshot();a.equal(s.attribution_complete,false);
a(s.roles.every(r=>r.allocation==='NOT_REQUESTED'));
""")


def test_teardown_rejected_allocation_is_not_an_unclosed_resource():
    teardown_case(r"""
await a.rejects(b.acquire(()=>{throw Error('PRIVATE')},'browser'));
a.equal(await b.finish(),'SETTLED');const s=b.teardownSnapshot();
a.equal(s.attribution_complete,true);a.equal(s.roles[0].allocation,'REJECTED');
a.equal(s.roles[0].close,'NOT_STARTED');a.equal(s.pending_at_snapshot,0);
a.equal(s.roles[0].error_class,'OTHER');a(!JSON.stringify(s).includes('PRIVATE'));
""")
