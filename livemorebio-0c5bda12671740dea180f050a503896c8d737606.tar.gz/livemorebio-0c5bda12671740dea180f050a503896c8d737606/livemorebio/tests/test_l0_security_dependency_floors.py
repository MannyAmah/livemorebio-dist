"""Hold the nine dependency advisory fixes recorded by the 2026-10-14 review.

This checks the shipped lock, including an unpacked archive or container image.
It is not a current advisory scan or a claim that an installed environment uses
the lock. The recorded fixed floors are the review's evidence, not live data.
"""
from __future__ import annotations

from pathlib import Path
import re

import pytest


LOCK = Path(__file__).resolve().parents[2] / "requirements-python311.lock"


@pytest.mark.parametrize(
    ("package", "fixed_version", "advisory"),
    [
        ("jupyterlab", (4, 6, 4), "GHSA-3325-v43h-43rv"),
        ("jupyterlab", (4, 6, 4), "GHSA-3jqq-pw4j-pqcj"),
        ("jupyterlab", (4, 6, 4), "GHSA-6966-vjj6-99xv"),
        ("tornado", (6, 5, 9), "GHSA-3hv7-mjh2-fv65"),
        ("tornado", (6, 5, 9), "GHSA-c2m8-h5v5-343r"),
        ("tornado", (6, 5, 9), "GHSA-chx6-46f5-w4vp"),
        ("urllib3", (2, 8, 0), "GHSA-8988-9cw3-xx77"),
        ("urllib3", (2, 8, 0), "GHSA-gh4c-6fx4-qh6g"),
        ("urllib3", (2, 8, 0), "GHSA-vxq7-64xx-v4gw"),
    ],
    ids=lambda value: value if isinstance(value, str) else ".".join(map(str, value)),
)
def test_recorded_advisory_fixed_floor_is_in_release_lock(
    package: str, fixed_version: tuple[int, int, int], advisory: str
) -> None:
    text = LOCK.read_text(encoding="utf-8")
    versions = re.findall(rf"^{re.escape(package)}==([^\s\\]+)", text, re.MULTILINE)
    assert len(versions) == 1, f"{package}: exactly one lock pin is required"
    assert re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", versions[0]), (
        f"{package}: use a qualified stable release, not a pre-release or local build"
    )
    pinned_version = tuple(int(part) for part in versions[0].split("."))
    assert pinned_version >= fixed_version, (
        f"{advisory}: {package}=={versions[0]} is below the recorded fixed floor "
        f"{'.'.join(map(str, fixed_version))}"
    )
