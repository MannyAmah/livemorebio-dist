"""SEC-6/CIX-2 configuration checks; no Docker or hosted CI is invoked."""
from fnmatch import fnmatchcase
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
from types import SimpleNamespace
import textwrap

import pytest

from ._source_tree import git_executable, require_source_tree, source_tree_only


ROOT = Path(__file__).resolve().parents[2]
pytestmark = source_tree_only(".github/workflows", ".dockerignore")


def _excluded_from_context(path):
    ignore = ROOT / ".dockerignore"
    assert ignore.is_file(), "SEC-6: Docker build context needs a .dockerignore"
    patterns = [line.strip().rstrip("/") for line in ignore.read_text(encoding="utf-8").splitlines()
                if line.strip() and not line.lstrip().startswith("#")]
    assert not any(pattern.startswith("!") for pattern in patterns)
    ancestors = [path, *(str(parent) for parent in Path(path).parents if str(parent) != ".")]
    return any(fnmatchcase(candidate, pattern) for candidate in ancestors for pattern in patterns)


@pytest.mark.parametrize("workflow_name", ["installer.yml", "platforms.yml"])
def test_sec6_checkout_does_not_persist_credentials(workflow_name):
    text = (ROOT / ".github" / "workflows" / workflow_name).read_text(encoding="utf-8")
    checkout_steps = re.findall(
        r"(?m)^      - uses: actions/checkout@[^\n]+\n((?:        [^\n]*\n|\n)*)", text,
    )
    assert checkout_steps, "workflow checkout steps must be examined"
    assert len(checkout_steps) == len(re.findall(r"uses: actions/checkout@", text))
    for step in checkout_steps:
        assert re.search(r"(?m)^          persist-credentials: false$", step)


def test_cix2_each_workflow_has_explicit_read_only_permissions():
    require_source_tree(".github/workflows")
    workflows = sorted((ROOT / ".github" / "workflows").glob("*.y*ml"))
    assert workflows
    for workflow in workflows:
        text = workflow.read_text(encoding="utf-8")
        match = re.search(r"(?m)^permissions:\n((?:  [^\n]*\n)+)", text)
        assert match, workflow.name
        assert match.group(1).strip() == "contents: read", workflow.name
        assert not re.search(r"(?m)^ +permissions:", text), workflow.name


@pytest.mark.parametrize("path", [
    ".git/config", ".venv/bin/python", ".env", ".env.local", "secrets.env",
    ".livemore-stack.env", "livemorebio/.env", "tools/secrets.env",
    "livemorebio/technical-fixture.key", "tools/api-token", "credentials.json",
    "service-identity.key", "livemorebio/technical-runtime/" + "service-identity.key",
    "service-identity.key.123.0123456789abcdef.tmp",
    "livemorebio/technical-runtime/" + "service-identity.key.123.0123456789abcdef.tmp",
    ".livemore/events.jsonl", "data/snapshots/twin.json", "runtime/state.json",
    ".security-part2-scratch/storage-ci/data/events.jsonl",
])
def test_sec6_docker_context_excludes_credentials_local_state_and_artifacts(path):
    assert _excluded_from_context(path), path


def test_sec6_docker_context_preserves_product_distribution_marker_and_inputs():
    for path in (".livemore-distribution.json", "livemorebio/bus.py", "tools/build_release.py",
                 "models/technical-model.xml", "requirements-python311.lock"):
        assert not _excluded_from_context(path), path


def _fetch_step_environment():
    text = (ROOT / ".github/workflows/installer.yml").read_text(encoding="utf-8")
    steps = re.split(r"(?m)^      - ", text)
    step = next(value for value in steps if value.startswith("name: Fetch published compatibility history\n"))
    environment = {}
    lines = step.splitlines()
    for index, line in enumerate(lines):
        match = re.fullmatch(r"          ([A-Z0-9_]+): (.*)", line)
        if match is None:
            continue
        name, value = match.groups()
        if value == ">-":
            folded = []
            for continuation in lines[index + 1:]:
                if not continuation.startswith("            "):
                    break
                folded.append(continuation.strip())
            value = " ".join(folded)
        elif value.startswith('"') and value.endswith('"'):
            value = value[1:-1]
        environment[name] = value
    assert environment, "SEC-6: the private compatibility fetch needs ephemeral, step-only authentication"
    return text, step, environment


def test_sec6_compatibility_fetch_authentication_is_step_scoped_and_ephemeral():
    text, step, environment = _fetch_step_environment()
    assert environment["GH_TOKEN"] == "${{ github.token }}"
    assert environment["GIT_CONFIG_COUNT"] == "2"
    assert environment["GIT_CONFIG_KEY_0"] == "credential.helper"
    assert environment["GIT_CONFIG_VALUE_0"] == ""
    assert environment["GIT_CONFIG_KEY_1"] == "credential.${{ github.server_url }}.helper"
    assert environment["GIT_CONFIG_VALUE_1"].startswith("!f() {")
    assert text.count("${{ github.token }}") == 1
    assert "${{ github.token }}" not in text.replace(step, "")


@pytest.mark.parametrize("action", ["fill", "approve", "reject", "foreign-host"])
def test_sec6_actual_git_credential_protocol_never_persists_token(tmp_path, action):
    _, _, configured = _fetch_step_environment()
    executable = git_executable()
    if executable is None:
        pytest.skip("git credential protocol requires local git")
    home, working = tmp_path / "empty-home", tmp_path / "empty-working-directory"
    home.mkdir()
    working.mkdir()
    token = "technical-fixture-only-ci-token"
    environment = {
        "PATH": os.environ.get("PATH", ""), "HOME": str(home),
        "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": os.devnull,
        "GIT_CEILING_DIRECTORIES": str(tmp_path),
        "GIT_TERMINAL_PROMPT": "0", "GIT_ASKPASS": "", "SSH_ASKPASS": "",
        **configured,
    }
    environment["GH_TOKEN"] = token
    environment["GIT_CONFIG_KEY_1"] = configured["GIT_CONFIG_KEY_1"].replace(
        "${{ github.server_url }}", "https://github.com")
    foreign = action == "foreign-host"
    protocol = "protocol=https\nhost=" + ("technical-foreign.invalid" if foreign else "github.com") + "\n"
    if action in {"approve", "reject"}:
        protocol += f"username=x-access-token\npassword={token}\n"

    result = subprocess.run(
        [executable, "credential", "fill" if foreign else action],
        input=protocol + "\n", text=True, capture_output=True, timeout=10,
        cwd=working, env=environment, encoding="utf-8",
    )

    if action == "fill":
        assert result.returncode == 0
        assert f"password={token}" in result.stdout
        assert "username=x-access-token" in result.stdout
    elif foreign:
        assert result.returncode != 0 and token not in result.stdout + result.stderr
    else:
        assert result.returncode == 0 and not result.stdout
    assert token not in result.stderr
    assert not list(home.rglob("*")) and not list(working.rglob("*"))


_BASE_TAG_FETCH_STEPS = {
    ("installer.yml", "installer-and-release-gate", "Fetch published compatibility history"),
}
_COMPATIBILITY_FETCH_COMMAND = "|\n          git fetch --depth 1 origin refs/tags/stable-6588707:refs/tags/stable-6588707\n          # Rollback tests read both exact releases; checkout's shallow HEAD\n          # and the compatibility tag alone do not supply both commit trees.\n          git fetch --depth 1 origin 84a11b03be5009f2a708b0573aac597112f323e6 658870775e581c044a8832fd107e4097f7a30959"
_COMPATIBILITY_FETCH_STEP = 'name: Fetch published compatibility history\n        env:\n          GH_TOKEN: ${{ github.token }}\n          GIT_CONFIG_COUNT: "2"\n          GIT_CONFIG_KEY_0: credential.helper\n          GIT_CONFIG_VALUE_0: ""\n          GIT_CONFIG_KEY_1: credential.${{ github.server_url }}.helper\n          GIT_CONFIG_VALUE_1: >-\n            !f() { if [ "$1" = get ]; then\n            printf \'username=x-access-token\\npassword=%s\\n\' "$GH_TOKEN";\n            fi; }; f\n        run: ' + _COMPATIBILITY_FETCH_COMMAND
_PUBLISHED_PORT_AUTH_STEPS = {("platforms.yml", job, "Authenticate through the published port")
                              for job in ("container", "public-container")}
_PROVED_READINESS_STEPS = {("platforms.yml", "container", "Wait for health"),
                         ("platforms.yml", "public-container", "Wait for public services health")}


def _workflow_run_steps(text):
    """Retain job/step identity, so a fetch exception cannot migrate to another step."""
    jobs = text.split("jobs:\n", 1)[1]
    found = []
    for job in re.finditer(r"(?ms)^  ([A-Za-z0-9_-]+):\n(.*?)(?=^  [A-Za-z0-9_-]+:\n|\Z)", jobs):
        job_name, body = job.groups()
        for step in re.split(r"(?m)^      - ", body)[1:]:
            heading, separator, remainder = step.partition("\n")
            # Job keys may legally follow steps; they never belong to the final step.
            step = heading + separator + re.split(r"(?m)^(?= {0,6}\S)", remainder, maxsplit=1)[0]
            command = re.search(r"(?m)^        run:[^\n]*(?:\n(?: {10,}[^\n]*|[ \t]*))*", step)
            if command is None:
                continue
            name = step.splitlines()[0]
            name = name[6:].strip().strip("\"'") if name.startswith("name: ") else ""
            found.append((job_name, name, command.group(0).split("run:", 1)[1].strip(), step))
    assert len(found) == len(re.findall(r"(?m)^ +run:", text)), "every workflow run block must be examined"
    return found


def _forbidden_credential_context(text):
    # Scan the whole workflow, including action inputs and reusable jobs. The
    # context itself is sensitive: toJSON and computed indexing also expose it.
    return bool(re.search(
        r"\bsecrets\b|\bgithub\s*(?:\.\s*token\b|\[\s*['\"]token['\"]\s*\])",
        text, re.IGNORECASE))


def _assert_published_port_helper_commands(command):
    # Shell structure stays fixed so redirection, command substitution or another
    # executable cannot route credentials around the proved helper boundary.
    lines = [line.strip() for line in command.splitlines() if line.strip()]
    assert len(lines) == 5 and lines[:2] == ["|", "set -euo pipefail"]
    unauthenticated, authenticated, twins = [shlex.split(line) for line in lines[2:]]
    exposure_url = "http://127.0.0.1:8850/api/cendos/protocols/botanical-exposure"
    twins_url = "http://127.0.0.1:8850/api/twins?limit=1"
    helper = ["python3", "tools/stack_request.py", "--role", "aegle"]
    post = [*helper, "--method", "POST", "--timeout", "60", "--url", exposure_url,
            "--json", '{"program_id":"LBHR-129"}']
    # No credential reaches argv. The helper resolves existing local trust and
    # owns proof and actual request on one socket; there is no curl exemption.
    assert unauthenticated == [*post, "--expect-status", "401", "--without-credentials"]
    assert authenticated == [*post, "--expect-status", "201", "--expect-field", "outcome=EXPOSURE_NOT_COMPUTABLE"]
    assert twins == [*helper, "--timeout", "60", "--url", twins_url, "--expect-status", "200"]


def _forbidden_checkout_credential_operation(command, identity=None):
    # Line continuations must not hide an Authorization header from the command check.
    command = re.sub(r"\\\r?\n", " ", command)
    if identity in _PUBLISHED_PORT_AUTH_STEPS:
        _assert_published_port_helper_commands(command)
    if identity in _PROVED_READINESS_STEPS:
        assert [re.sub(r"\s+", " ", line.strip()) for line in command.splitlines() if line.strip()] == [
            "|", "set -euo pipefail", "for service in aegle:8850 life:8851 cendos:8852; do",
            'role="${service%:*}"', 'port="${service#*:}"',
            'if ! python3 tools/stack_request.py --role "$role" --url "http://127.0.0.1:$port" --wait-seconds 120; then',
            "docker compose logs --tail 80", "exit 1", "fi", "done",
        ]
    git = r"\bgit\s+(?:(?:-[^\s]+)(?:\s+[^\s-]+)?\s+)*?"
    return bool(
        re.search(git + r"(?:push|fetch|pull)\b", command) or
        re.search(r"(?<![A-Za-z0-9_])gh(?:\s|$)", command) or
        ("tools/stack_request.py" in command and identity not in _PUBLISHED_PORT_AUTH_STEPS | _PROVED_READINESS_STEPS) or
        (re.search(r"\b(?:curl|wget)\b", command) and
         (re.search(r"authorization\s*:", command, re.IGNORECASE) or
          re.search(r"(?:-H\b|--header(?:=|\s+))[^\n]*\$", command))) or
        _forbidden_credential_context(command))


def test_sec6_workflow_run_commands_do_not_need_checkout_credentials():
    exceptions = set()
    for path in sorted((ROOT / ".github/workflows").glob("*.y*ml")):
        text = path.read_text(encoding="utf-8")
        outside_fetch_steps = text
        steps = _workflow_run_steps(text)
        for job, name, command, step in steps:
            identity = (path.name, job, name)
            if identity in _BASE_TAG_FETCH_STEPS:
                assert step.strip() == _COMPATIBILITY_FETCH_STEP, identity
                assert command == _COMPATIBILITY_FETCH_COMMAND, identity
                # The helper is only in this step's env, never a job/global credential.
                assert "        env:\n" in step and "GH_TOKEN: ${{ github.token }}" in step, identity
                assert 'GIT_CONFIG_COUNT: "2"' in step, identity
                assert "GIT_CONFIG_KEY_0: credential.helper" in step and 'GIT_CONFIG_VALUE_0: ""' in step, identity
                assert "GIT_CONFIG_KEY_1: credential.${{ github.server_url }}.helper" in step, identity
                assert "GIT_CONFIG_VALUE_1: >-" in step and '!f() { if [ "$1" = get ]; then' in step, identity
                assert text.count("${{ github.token }}") == len(_BASE_TAG_FETCH_STEPS), identity
                # The named fetch admits exactly its github.token env entry,
                # not another context read hidden beside the credential helper.
                assert not _forbidden_credential_context(
                    step.replace("GH_TOKEN: ${{ github.token }}", "", 1)), identity
                outside_fetch_steps = outside_fetch_steps.replace(step, "", 1)
                exceptions.add(identity)
            else:
                if identity in _PUBLISHED_PORT_AUTH_STEPS:
                    # This boundary permits no step-level code or token override.
                    assert step.startswith("name: Authenticate through the published port\n"), identity
                    expected = ["shell", "run"]
                    if job == "public-container":
                        expected.insert(0, "working-directory")
                        assert "        working-directory: ${{ env.LIVEMORE_PUBLIC_CONTAINER_SOURCE }}\n" in step
                    assert re.findall(r"(?m)^        ([A-Za-z_-]+):", step) == expected, identity
                    assert "        shell: bash\n" in step, identity
                    _assert_published_port_token_source(text, steps, job)
                assert not _forbidden_checkout_credential_operation(command, identity), identity
        assert not _forbidden_credential_context(outside_fetch_steps), path.name
        assert not re.search(
            r"GH_TOKEN|GIT_CONFIG_(?:COUNT|KEY_|VALUE_)|credential\.[^\s]*helper",
            outside_fetch_steps, re.IGNORECASE), path.name
    # Stable has no v1 workflow; the exact exceptions apply only when that file is present.
    if (ROOT / ".github/workflows/installer.yml").exists():
        assert exceptions == _BASE_TAG_FETCH_STEPS


def _assert_published_port_token_source(text, steps, job):
    generation = [(index, command) for index, (candidate, name, command, _) in enumerate(steps)
                  if (candidate, name) == (job, "Generate ephemeral local keys")]
    assert len(generation) == 1
    index, generated = generation[0]
    probes = [index for index, (candidate, name, _, _) in enumerate(steps)
              if (candidate, name) == (job, "Authenticate through the published port")]
    assert len(probes) == 1 and index < probes[0]
    for credential, variable, random_command in (
            ("LIVEMORE_API_TOKEN", "api_token", "openssl rand -hex 32"),
            ("LIVEMORE_PATCH_STORAGE_KEY", "patch_storage_key", "openssl rand -base64 32 | tr '+/' '-_'"),
            ("LIVEMORE_PATCH_ADMISSION_HMAC_KEY", "patch_admission_key", "openssl rand -base64 32 | tr '+/' '-_'"),
            ("LIVEMORE_SERVICE_IDENTITY_KEY", "service_identity_key", "openssl rand -base64 32 | tr '+/' '-_'")):
        assignment = f'{variable}="$({random_command})"'
        mask = f'''printf '::add-mask::%s\\n' "${variable}"'''
        exported = f'''printf '{credential}=%s\\n' "${variable}"'''
        assert assignment in generated and mask in generated and exported in generated
        assert generated.index(assignment) < generated.index(mask) < generated.index(exported)
    assert '} >> "$GITHUB_ENV"' in generated
    # These textual counts pin exports, without putting credentials in argv;
    # they cannot confine runtime environment access or indirect shell expansion.
    assert text.count("LIVEMORE_API_TOKEN") == 2
    assert text.count("LIVEMORE_SERVICE_IDENTITY_KEY") == 2


@pytest.mark.parametrize("job", ["container", "public-container"])
def test_sec6_generated_credentials_are_masked_in_generation_step(tmp_path, job):
    text = (ROOT / ".github/workflows/platforms.yml").read_text(encoding="utf-8")
    steps = _workflow_run_steps(text)
    _assert_published_port_token_source(text, steps, job)
    command = next(command for candidate, name, command, _ in steps
                   if (candidate, name) == (job, "Generate ephemeral local keys"))
    openssl = tmp_path / "openssl"
    openssl.write_text(
        f"#!{sys.executable}\n" + textwrap.dedent('''\
        import os
        from pathlib import Path
        import sys

        log = Path(os.environ["TECHNICAL_RANDOM_LOG"])
        calls = log.read_text(encoding="utf-8").splitlines() if log.exists() else []
        expected = [["rand", "-hex", "32"], *[["rand", "-base64", "32"] for _ in range(3)]]
        assert sys.argv[1:] == expected[len(calls)]
        values = ["technical-api-token", "technical-storage-key+/=", "technical-admission-key+/=", "technical-identity-key+/="]
        log.write_text("\\n".join([*calls, values[len(calls)]]) + "\\n", encoding="utf-8")
        print(values[len(calls)])
        '''), encoding="utf-8")
    openssl.chmod(0o700)
    environment_file = tmp_path / "github-env"
    environment = dict(os.environ, PATH=f"{tmp_path}:" + os.environ.get("PATH", ""),
                       GITHUB_ENV=str(environment_file), TECHNICAL_RANDOM_LOG=str(tmp_path / "random-log"))
    result = subprocess.run(["bash", "-c", textwrap.dedent(command.split("\n", 1)[1])],
                            env=environment, text=True, capture_output=True, timeout=10, encoding="utf-8")
    assert result.returncode == 0, result.stderr
    credentials = dict(line.split("=", 1) for line in environment_file.read_text(encoding="utf-8").splitlines())
    assert credentials == {
        "LIVEMORE_API_TOKEN": "technical-api-token",
        "LIVEMORE_PATCH_STORAGE_KEY": "technical-storage-key-_=",
        "LIVEMORE_PATCH_ADMISSION_HMAC_KEY": "technical-admission-key-_=",
        "LIVEMORE_SERVICE_IDENTITY_KEY": "technical-identity-key-_=",
        "LIVEMORE_AEGLE_IDENTITY_AUTHORITY": "http://127.0.0.1:8850",
        "LIVEMORE_LIFE_IDENTITY_AUTHORITY": "http://127.0.0.1:8851",
        "LIVEMORE_CENDOS_IDENTITY_AUTHORITY": "http://127.0.0.1:8852",
    }
    assert result.stdout.splitlines() == [f"::add-mask::{credentials[name]}" for name in (
        "LIVEMORE_API_TOKEN", "LIVEMORE_PATCH_STORAGE_KEY", "LIVEMORE_PATCH_ADMISSION_HMAC_KEY",
        "LIVEMORE_SERVICE_IDENTITY_KEY")]
    assert not result.stderr


@pytest.mark.parametrize("command", [
    "git push origin HEAD", "git -C . push", "gh pr create", "gh", "git fetch origin main", "git pull",
    'curl -H "Authorization: Bearer technical" https://technical.invalid',
    'wget --header="Authorization: Bearer technical" https://technical.invalid',
    'curl \\\n  -H "Authorization: Bearer technical" https://technical.invalid',
    'auth="Authorization: Bearer technical"\ncurl -H "$auth" https://technical.invalid',
    'wget --header="$unexamined_header" https://technical.invalid',
    "echo '${{ secrets.TECHNICAL }}'", "echo '${{ github.token }}'",
])
def test_sec6_command_guard_rejects_committed_shaped_mutants(tmp_path, monkeypatch, command):
    text = ("jobs:\n  technical:\n    steps:\n      - name: Technical fixture\n        run: |\n" +
            "\n".join("          " + line for line in command.splitlines()) + "\n")
    workflows = tmp_path / ".github" / "workflows"
    workflows.mkdir(parents=True)
    (workflows / "installer.yml").write_text(text, encoding="utf-8")
    monkeypatch.setattr(__import__(__name__, fromlist=["ROOT"]), "ROOT", tmp_path)
    # Even when the checkout equals committed HEAD, a forbidden operation must fail.
    monkeypatch.setattr(subprocess, "run", lambda *a, **kw: SimpleNamespace(stdout=text))
    with pytest.raises(AssertionError):
        test_sec6_workflow_run_commands_do_not_need_checkout_credentials()


@pytest.mark.parametrize("placement", [
    "step-env", "job-env", "workflow-env", "action-with", "checkout-token", "run",
])
@pytest.mark.parametrize("expression", [
    "${{ secrets.TECHNICAL_PAT }}", "${{ secrets['TECHNICAL_PAT'] }}",
    "${{ toJSON(secrets) }}", "${{ secrets[format('{0}', 'TECHNICAL_PAT')] }}",
    "${{ github['token'] }}",
])
def test_sec6_command_guard_rejects_secret_expressions_outside_run(
        tmp_path, monkeypatch, placement, expression):
    text = "jobs:\n  technical:\n    steps:\n"
    if placement in {"action-with", "checkout-token"}:
        action = "actions/checkout@v4" if placement == "checkout-token" else "technical-fixture/action@v1"
        text += (f"      - uses: {action}\n        with:\n"
                 f"          token: {expression}\n")
    else:
        text += "      - name: Build the image\n"
        if placement == "step-env":
            text += f"        env:\n          TOKEN: {expression}\n"
        command = f"echo '{expression}'" if placement == "run" else "./technical-build-fixture.sh"
        text += f"        run: {command}\n"
    if placement == "job-env":
        text = text.replace("    steps:\n", f"    env:\n      TOKEN: {expression}\n    steps:\n", 1)
    if placement == "workflow-env":
        text = f"env:\n  TOKEN: {expression}\n\n" + text
    workflows = tmp_path / ".github" / "workflows"
    workflows.mkdir(parents=True)
    (workflows / "platforms.yml").write_text(text, encoding="utf-8")
    monkeypatch.setattr(__import__(__name__, fromlist=["ROOT"]), "ROOT", tmp_path)
    with pytest.raises(AssertionError):
        test_sec6_workflow_run_commands_do_not_need_checkout_credentials()


def _published_port_step(job="container"):
    text = (ROOT / ".github/workflows/platforms.yml").read_text(encoding="utf-8")
    steps = _workflow_run_steps(text)
    found = [(command, step) for candidate, name, command, step in steps
             if (candidate, name) == (job, "Authenticate through the published port")]
    assert len(found) == 1, "each container job must authenticate through its published port"
    return text, steps, found[0]


@pytest.mark.parametrize("job", ["container", "public-container"])
def test_sec6_published_port_probe_uses_only_its_generated_stack_token(job):
    text, steps, (command, step) = _published_port_step(job)
    _assert_published_port_token_source(text, steps, job)
    _assert_published_port_helper_commands(re.sub(r"\\\r?\n", " ", command))
    assert not _forbidden_credential_context(step)


@pytest.mark.parametrize("unauth_status, auth_status, outcome, twins_status, accepted", [
    ("401", "201", "EXPOSURE_NOT_COMPUTABLE", "200", True),
    ("200", "201", "EXPOSURE_NOT_COMPUTABLE", "200", False),
    ("401", "200", "EXPOSURE_NOT_COMPUTABLE", "200", False),
    ("401", "403", "EXPOSURE_NOT_COMPUTABLE", "200", False),
    ("401", "500", "EXPOSURE_NOT_COMPUTABLE", "200", False),
    ("401", "201", "TECHNICAL_UNEXPECTED_OUTCOME", "200", False),
    ("401", "201", "EXPOSURE_NOT_COMPUTABLE", "500", False),
    ("401", "201", "EXPOSURE_NOT_COMPUTABLE", "503", False),
    ("401", "201", "EXPOSURE_NOT_COMPUTABLE", "204", False),
])
@pytest.mark.parametrize("job", ["container", "public-container"])
def test_sec6_published_port_probe_checks_both_authentication_results(
        tmp_path, unauth_status, auth_status, outcome, twins_status, accepted, job):
    _, _, (command, _) = _published_port_step(job)
    executable = tmp_path / "python3"
    log = tmp_path / "technical-helper-calls.jsonl"
    executable.write_text(f"#!{sys.executable}\n" + textwrap.dedent('''
        import argparse, json, os, pathlib, sys
        args = sys.argv[1:]
        assert args.pop(0) == "tools/stack_request.py"
        with pathlib.Path(os.environ["TECHNICAL_HELPER_LOG"]).open("a", encoding="utf-8") as output:
            output.write(json.dumps(args) + "\\n")
        parser = argparse.ArgumentParser()
        parser.add_argument("--role", required=True)
        parser.add_argument("--method", default="GET")
        parser.add_argument("--timeout", required=True)
        parser.add_argument("--url", required=True)
        parser.add_argument("--json")
        parser.add_argument("--expect-status", default="200")
        parser.add_argument("--expect-field")
        parser.add_argument("--without-credentials", action="store_true")
        configured = parser.parse_args(args)
        if configured.url.endswith("/api/twins?limit=1"):
            status = os.environ["TECHNICAL_TWINS_STATUS"]
            payload = {}
        elif configured.without_credentials:
            status = os.environ["TECHNICAL_UNAUTH_STATUS"]
            payload = {"detail": "technical-refusal"}
        else:
            status = os.environ["TECHNICAL_AUTH_STATUS"]
            payload = {"outcome": os.environ["TECHNICAL_OUTCOME"]}
        if status != configured.expect_status:
            raise SystemExit(1)
        if configured.expect_field:
            field, _, expected = configured.expect_field.partition("=")
            if payload.get(field) != expected:
                raise SystemExit(1)
        print(json.dumps(payload))
    '''), encoding="utf-8")
    executable.chmod(0o700)
    environment = dict(os.environ, PATH=f"{tmp_path}:" + os.environ.get("PATH", ""),
                       LIVEMORE_API_TOKEN="technical-fixture-only-ephemeral-token",
                       LIVEMORE_SERVICE_IDENTITY_KEY="technical-fixture-only-identity-key",
                       TECHNICAL_HELPER_LOG=str(log), TECHNICAL_OUTCOME=outcome,
                       TECHNICAL_UNAUTH_STATUS=unauth_status, TECHNICAL_AUTH_STATUS=auth_status,
                       TECHNICAL_TWINS_STATUS=twins_status)
    result = subprocess.run(["bash", "-c", textwrap.dedent(command.split("\n", 1)[1])],
                            env=environment, text=True, capture_output=True, timeout=10, encoding="utf-8")
    assert (result.returncode == 0) is accepted, result.stdout + result.stderr
    calls = [json.loads(line) for line in log.read_text(encoding="utf-8").splitlines()]
    expected_calls = (1 if unauth_status != "401" else
                      2 if auth_status != "201" or outcome != "EXPOSURE_NOT_COMPUTABLE" else 3)
    assert len(calls) == expected_calls
    for call in calls:
        assert call[call.index("--role") + 1] == "aegle"
        assert call[call.index("--timeout") + 1] == "60"
        assert not any("Authorization" in value or "Bearer" in value or "technical-fixture-only" in value for value in call)
    for call in calls[:2]:
        assert call[call.index("--url") + 1] == "http://127.0.0.1:8850/api/cendos/protocols/botanical-exposure"
        assert call[call.index("--method") + 1] == "POST"
        assert json.loads(call[call.index("--json") + 1]) == {"program_id": "LBHR-129"}
    assert "--without-credentials" in calls[0]
    assert calls[0][calls[0].index("--expect-status") + 1] == "401"
    if len(calls) >= 2:
        assert "--without-credentials" not in calls[1]
        assert calls[1][calls[1].index("--expect-status") + 1] == "201"
        assert calls[1][calls[1].index("--expect-field") + 1] == "outcome=EXPOSURE_NOT_COMPUTABLE"
    if len(calls) == 3:
        assert calls[2] == ["--role", "aegle", "--timeout", "60", "--url",
                            "http://127.0.0.1:8850/api/twins?limit=1", "--expect-status", "200"]
    assert "technical-fixture-only" not in result.stdout + result.stderr


@pytest.mark.parametrize("addition", [
    "-x technical.invalid:8080", "--proxy technical.invalid:8080",
    "--connect-to 127.0.0.1:8850:technical.invalid:80",
    "--resolve 127.0.0.1:8850:192.0.2.1", "-K technical-curlrc", "--config technical-curlrc",
    "--url technical.invalid", "technical.invalid", "ftp://technical.invalid",
    "--netrc", "--request-target //technical.invalid",
])
def test_sec6_published_port_helper_guard_rejects_target_and_option_mutants(
        tmp_path, monkeypatch, addition):
    text, _, _ = _published_port_step()
    original = "python3 tools/stack_request.py --role aegle --method POST --timeout 60"
    changed = text.replace(original, original + " " + addition, 1)
    assert changed != text, "every technical mutation must change an actual helper command"
    text = changed
    workflows = tmp_path / ".github/workflows"
    workflows.mkdir(parents=True)
    (workflows / "platforms.yml").write_text(text, encoding="utf-8")
    monkeypatch.setattr(__import__(__name__, fromlist=["ROOT"]), "ROOT", tmp_path)
    with pytest.raises(AssertionError):
        test_sec6_workflow_run_commands_do_not_need_checkout_credentials()


def test_sec6_command_guard_rejects_reusable_workflow_secret_inheritance(tmp_path, monkeypatch):
    text = ("jobs:\n  technical:\n    uses: technical-fixture/reusable/.github/workflows/build.yml@v1\n"
            "    secrets: inherit\n")
    workflows = tmp_path / ".github/workflows"
    workflows.mkdir(parents=True)
    (workflows / "platforms.yml").write_text(text, encoding="utf-8")
    monkeypatch.setattr(__import__(__name__, fromlist=["ROOT"]), "ROOT", tmp_path)
    with pytest.raises(AssertionError):
        test_sec6_workflow_run_commands_do_not_need_checkout_credentials()


@pytest.mark.parametrize("mutation", [
    "file", "job", "step", "header-variable", "extra-header", "remote-url",
    "token-override", "token-generation", "step-secret", "api-token-mask",
    "storage-key-mask", "admission-key-mask", "identity-key-mask", "identity-generation", "helper-override",
])
def test_sec6_published_port_exception_cannot_escape_its_identity_or_token_source(
        tmp_path, monkeypatch, mutation):
    text, _, _ = _published_port_step()
    original = text
    filename = "platforms.yml"
    if mutation == "file":
        filename = "installer.yml"
    elif mutation == "job":
        text = text.replace("  container:\n", "  technical-other-job:\n", 1)
    elif mutation == "step":
        text = text.replace("name: Authenticate through the published port", "name: Technical other step", 1)
    elif mutation == "header-variable":
        text = text.replace('--role aegle --method POST', '--role "$TECHNICAL_OTHER_ROLE" --method POST', 1)
    elif mutation == "extra-header":
        text = text.replace('--method POST --timeout 60', '--header "$TECHNICAL_OTHER_HEADER" --method POST --timeout 60', 1)
    elif mutation == "remote-url":
        text = text.replace("http://127.0.0.1:8850/api/cendos/", "http://192.0.2.1:8850/api/cendos/", 1)
    elif mutation == "token-override":
        text = text.replace("name: Authenticate through the published port\n",
                            "name: Authenticate through the published port\n"
                            "        env:\n          LIVEMORE_API_TOKEN: technical-override\n", 1)
    elif mutation == "token-generation":
        text = text.replace('"$(openssl rand -hex 32)"', '"technical-persistent-token"', 1)
    elif mutation == "identity-generation":
        text = text.replace('service_identity_key="$(openssl rand -base64 32 | tr \'+/\' \'-_\')"',
                            'service_identity_key="$api_token"', 1)
    elif mutation == "helper-override":
        text = text.replace("python3 tools/stack_request.py", "python3 tools/technical-other-helper.py", 1)
    elif mutation in {"api-token-mask", "storage-key-mask", "admission-key-mask", "identity-key-mask"}:
        variable = {"api-token-mask": "api_token", "storage-key-mask": "patch_storage_key",
                    "admission-key-mask": "patch_admission_key", "identity-key-mask": "service_identity_key"}[mutation]
        text = text.replace(f'''          printf '::add-mask::%s\\n' "${variable}"\n''', "", 1)
    elif mutation == "step-secret":
        text = text.replace("name: Authenticate through the published port\n",
                            "name: Authenticate through the published port\n"
                            "        env:\n          TOKEN: ${{ secrets.TECHNICAL_PAT }}\n", 1)
    assert text != original or mutation == "file", "every technical mutation must change its workflow input"
    workflows = tmp_path / ".github/workflows"
    workflows.mkdir(parents=True)
    (workflows / filename).write_text(text, encoding="utf-8")
    monkeypatch.setattr(__import__(__name__, fromlist=["ROOT"]), "ROOT", tmp_path)
    with pytest.raises(AssertionError):
        test_sec6_workflow_run_commands_do_not_need_checkout_credentials()


@pytest.mark.parametrize("job", ["container", "public-container"])
@pytest.mark.parametrize("insulin_controls, botanical_controls, accepted", [
    ([{"passed": True}], [{"passed": True}], True),
    ([], [{"passed": True}], False), ([{"passed": False}], [{"passed": True}], False),
    ([{"passed": True}], [], False), ([{"passed": True}], [{"passed": False}], False),
])
def test_sec6_container_api_probe_uses_the_authenticated_sdk(
        monkeypatch, job, insulin_controls, botanical_controls, accepted):
    from types import ModuleType
    import sys

    text = (ROOT / ".github/workflows/platforms.yml").read_text(encoding="utf-8")
    command = next(command for candidate, name, command, _ in _workflow_run_steps(text)
                   if (candidate, name) == (job, "Run a six-program workflow through the container API"))
    script = re.search(r"docker compose exec -T aegle python - <<'PY'\n(.*?)\n +PY(?:\n|$)", command, re.DOTALL)
    assert script, "container API validation must run the authenticated installed SDK"
    calls = []

    class TechnicalPlatform:
        def __init__(self, *, mode):
            assert mode == "attach"

        def program_catalog(self):
            calls.append(("catalog",))
            return {"botanical": {"programs": [{"program_id": f"technical-{i}"} for i in range(5)]}}

        def run_insulin_protocol(self, body):
            calls.append(("insulin", body))
            return {"run_id": "technical", "summary": {}, "controls": insulin_controls}

        def run_botanical_program(self, body):
            calls.append(("botanical", body))
            if body["program_id"] == "LBHR-129":
                return {"outcome": "EXPOSURE_NOT_COMPUTABLE", "missing_measurement": True, "reason_code": "TECHNICAL"}
            return {"run_id": "technical", "outcome": "technical", "controls": botanical_controls}

    module = ModuleType("livemorebio.sdk")
    module.Platform = TechnicalPlatform
    monkeypatch.setitem(sys.modules, "livemorebio.sdk", module)
    program = compile(textwrap.dedent(script.group(1)), "platforms-container-api-probe", "exec")
    if accepted:
        exec(program, {})
    else:
        with pytest.raises(AssertionError):
            exec(program, {})
    expected = [("catalog",), ("insulin", {"cohort_size": 4, "seed": 1})]
    if insulin_controls and all(control["passed"] for control in insulin_controls):
        expected.append(("botanical", {"program_id": "LBHR-030", "dose_mg": 400, "cohort_size": 4}))
    if accepted:
        expected.append(("botanical", {"program_id": "LBHR-129"}))
    assert calls == expected


@pytest.mark.parametrize("placement", ["workflow", "before-steps", "after-steps"])
def test_sec6_fetch_helper_cannot_escape_its_named_step(tmp_path, monkeypatch, placement):
    step = "      - " + _COMPATIBILITY_FETCH_STEP + "\n"
    text = "jobs:\n  installer-and-release-gate:\n    steps:\n" + step
    if placement == "workflow":
        text = text.replace("jobs:\n", 'env:\n  GIT_CONFIG_COUNT: "2"\n\njobs:\n', 1)
    elif placement == "before-steps":
        text = text.replace("    steps:\n", '    env:\n      GIT_CONFIG_COUNT: "2"\n    steps:\n', 1)
    else:
        text = text + '    env:\n      GIT_CONFIG_COUNT: "2"\n'
    workflows = tmp_path / ".github" / "workflows"
    workflows.mkdir(parents=True)
    (workflows / "installer.yml").write_text(text, encoding="utf-8")
    monkeypatch.setattr(__import__(__name__, fromlist=["ROOT"]), "ROOT", tmp_path)
    with pytest.raises(AssertionError):
        test_sec6_workflow_run_commands_do_not_need_checkout_credentials()


def test_sec6_platforms_workflow_triggers_on_dockerignore_changes():
    require_source_tree(".github/workflows/platforms.yml")
    text = (ROOT / ".github/workflows/platforms.yml").read_text(encoding="utf-8")
    pull_request = re.search(r"(?m)^  pull_request:\n((?:    [^\n]*\n|\n)*)", text)
    assert pull_request, "the image workflow must declare pull_request inputs"
    assert re.search(r"(?m)^      - [\"\']?\.dockerignore[\"\']?$", pull_request.group(1))


@pytest.mark.parametrize("addition", [
    "          GIT_CONFIG_VALUE_2: technical-other-helper\n",
    "          GH_TOKEN_2: technical-other-token\n",
    "          BASH_ENV: technical-script.sh\n",
])
def test_sec6_fetch_exception_pins_its_complete_environment(tmp_path, monkeypatch, addition):
    text = (ROOT / ".github/workflows/installer.yml").read_text(encoding="utf-8")
    text = text.replace('          GH_TOKEN: ${{ github.token }}\n',
                        '          GH_TOKEN: ${{ github.token }}\n' + addition, 1)
    workflows = tmp_path / ".github/workflows"
    workflows.mkdir(parents=True)
    (workflows / "installer.yml").write_text(text, encoding="utf-8")
    monkeypatch.setattr(__import__(__name__, fromlist=["ROOT"]), "ROOT", tmp_path)
    with pytest.raises(AssertionError):
        test_sec6_workflow_run_commands_do_not_need_checkout_credentials()


@pytest.mark.parametrize("job", ["container", "public-container"])
def test_sec6_published_port_exception_refuses_extra_step_environment(tmp_path, monkeypatch, job):
    text, _, _ = _published_port_step(job)
    job_start = text.index(f"  {job}:\n")
    before, body = text[:job_start], text[job_start:]
    body = body.replace("name: Authenticate through the published port\n",
                        "name: Authenticate through the published port\n"
                        "        env:\n          BASH_ENV: technical-other-script.sh\n", 1)
    workflows = tmp_path / ".github/workflows"
    workflows.mkdir(parents=True)
    (workflows / "platforms.yml").write_text(before + body, encoding="utf-8")
    monkeypatch.setattr(__import__(__name__, fromlist=["ROOT"]), "ROOT", tmp_path)
    with pytest.raises(AssertionError):
        test_sec6_workflow_run_commands_do_not_need_checkout_credentials()


@pytest.mark.parametrize("job", ["container", "public-container"])
@pytest.mark.parametrize("helper_index", [0, 1, 2])
@pytest.mark.parametrize("deadline", [None, "0", "3", "120"])
def test_sec6_each_published_port_helper_requires_the_pinned_api_deadline(job, helper_index, deadline):
    _, _, (command, _) = _published_port_step(job)
    command = re.sub(r"\\\r?\n", " ", command)
    _assert_published_port_helper_commands(command)
    lines = command.splitlines()
    index = [number for number, line in enumerate(lines) if "python3 tools/stack_request.py " in line][helper_index]
    original = lines[index]
    replacement = "" if deadline is None else f"--timeout {deadline} "
    lines[index] = original.replace("--timeout 60 ", replacement, 1)
    assert lines[index] != original, "every technical mutation must change an actual helper command"
    with pytest.raises(AssertionError):
        _assert_published_port_helper_commands("\n".join(lines))
