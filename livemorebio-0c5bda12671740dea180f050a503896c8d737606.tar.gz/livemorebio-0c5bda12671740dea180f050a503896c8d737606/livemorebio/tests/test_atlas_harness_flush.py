"""A mounted-controller flush ends when the integrity digest completes, not on a turn budget.

The controller harnesses replace every dependency of the mounted Atlas reference
with an in-memory stand-in except one: ``crypto.subtle.digest``, which verifies
each partition and completes on the runtime's thread pool. How many event-loop
turns that takes is decided by the host's scheduler, not by the program, so a
flush that counts turns passes on a fast machine and fails on a slow one.

These tests hold the host constant instead: every digest is delivered far later
than any turn budget, and the tests that failed on hosted runners must still see
the settled state.
"""
from __future__ import annotations

import pytest

from . import test_atlas_group_search_ui as group_search
from . import test_atlas_reference_ui as reference_ui
from . import test_atlas_renderer_review as renderer_review
from . import test_atlas_view_status as view_status
from ._node import flush_js

_node = reference_ui.node

# One full load is five digest rounds in sequence (skin, then two workers over
# eight partitions), so 400 turns a digest is 2000 turns: far past the 40, 50
# and 60 the harnesses used to allow, and still only milliseconds of wall time.
SLOW_DIGEST = """{const subtle=globalThis.crypto.subtle,real=subtle.digest;
subtle.digest=function(...args){return real.apply(this,args).then(async value=>{for(let i=0;i<400;i++)await new Promise(setImmediate);return value})};}
"""

# The five tests that failed on the first hosted run of the stable release,
# then the two recorded from earlier hosted runs of the same family.
HOSTED_FAILURES = [
    (group_search, "test_unloaded_heart_results_remain_counted_but_disabled"),
    (reference_ui, "test_mounted_reference_cancels_hidden_load_and_restores_same_source_retry_state"),
    (renderer_review, "test_missing_drawn_and_context_lost_controls_publish_real_availability"),
    (renderer_review, "test_partial_geometry_disables_only_unavailable_source_partition_controls"),
    (view_status, "test_loading_status_never_equates_loaded_resources_with_drawn_pixels"),
    (view_status, "test_failure_recovery_and_changed_manifest_restore_only_current_settings"),
    (view_status, "test_retry_retains_isolation_but_does_not_claim_unloaded_element_displayed"),
]


@pytest.mark.parametrize(("module", "name"), HOSTED_FAILURES, ids=[name for _, name in HOSTED_FAILURES])
def test_hosted_failures_settle_when_the_integrity_digest_is_slow(module, name, monkeypatch):
    def slow(program: str) -> str:
        return _node(SLOW_DIGEST + program)

    # Each module binds `node` at import, so each binding is replaced.
    for harness in (group_search, reference_ui, renderer_review, view_status):
        monkeypatch.setattr(harness, "node", slow)
    getattr(module, name)()


def test_flush_with_nothing_outstanding_yields_exactly_its_quiet_turns():
    # An assertion that nothing happened is only as strong as the turns it waited.
    assert _node(flush_js(7) + """
let turns=0,counting=true;const tick=()=>{turns++;if(counting)setImmediate(tick)};setImmediate(tick);
await flush();counting=false;
if(turns!==7)throw Error('idle flush took '+turns+' turns');
console.log('ok');""").strip() == "ok"


def test_flush_reports_a_digest_that_never_completes_rather_than_returning():
    assert _node("{globalThis.crypto.subtle.digest=()=>new Promise(()=>{})}\n" + flush_js(3, deadline_ms=50) + """
crypto.subtle.digest('SHA-256',new Uint8Array(1));let message='';
try{await flush()}catch(error){message=error.message}
if(!/integrity digest is still outstanding/.test(message))throw Error('flush returned past outstanding work');
console.log('ok');""").strip() == "ok"
