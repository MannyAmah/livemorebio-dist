"""Public data descriptions and retained attribution are distribution contracts."""
from __future__ import annotations

import hashlib
import json
import subprocess
from dataclasses import replace
from pathlib import Path
import tomllib

import pytest

from livemorebio.scientific_sources import Catalog, Workflow

from ._source_tree import source_tree_only


ROOT = Path(__file__).resolve().parents[2]


def test_catalog_fact_identity_and_workflow_hints_are_preserved():
    path = ROOT / "livemorebio/scientific_sources/data/source-catalog.v1.json"
    raw = path.read_bytes()
    payload = json.loads(raw)
    # Preserve the recorded hashes: project only the three admitted name repairs
    # back to their old display values, after requiring each corrected value.
    corrections = {"nar:1150": ("X", "X:MAP"),
                   "nar:1111": ("PepCyber", "PepCyber:P~Pep"),
                   "nar:1682": ("MP", "MP:PD")}
    for identifier, (before, after) in corrections.items():
        row = next(row for row in payload["sources"] if row["source_id"] == identifier)
        assert row["name"] == after
        row["name"] = before
        corrected = (json.dumps("name") + ": " + json.dumps(after)).encode()
        original = (json.dumps("name") + ": " + json.dumps(before)).encode()
        assert raw.count(corrected) == 1
        raw = raw.replace(corrected, original)
    facts = [{key: row[key] for key in (
        "source_id", "name", "endpoint_url", "provenance_url", "workflows"
    )} for row in payload["sources"]]
    assert hashlib.sha256(json.dumps(facts, sort_keys=True).encode()).hexdigest() == (
        "39abb1e031fe5f63131dc395086739f1f9e3bab441251cd2fa8bb24a1d0f1492"
    )
    # 2026-10-04: remove article-title suffixes and non-URL endpoints after
    # removing publisher descriptions; source IDs/provenance/workflows unchanged.
    # Previous catalog SHA-256: a2a8965650a6c7c293b43ed2ce6eff34727a42329c551ca7e28bdb7cf693ec2d.
    assert hashlib.sha256(raw).hexdigest() == (
        "2c2fcad5859aed028232e1d5cce84671fc9a28bebe559ba63b26de8a06a07c38"
    )


def test_catalog_does_not_distribute_publisher_descriptions():
    catalog = Catalog.load()
    rows = [r for r in catalog.records if r.collection in {"nar", "elixir"}]
    assert len(rows) == 2633
    for record in rows:
        assert record.description == ""
        assert record.data_types == ()
        assert record.to_dict()["description_status"] == "not_distributed"
        assert record.name and record.source_id and record.provenance_url


def test_catalog_routing_is_independent_of_descriptive_text(monkeypatch):
    from livemorebio import adapters
    monkeypatch.setattr(adapters, "_PROBE_RESULTS", {})
    monkeypatch.setattr(adapters, "_probe_url", lambda *_: "ready")
    adapters.statuses(probe=True)
    catalog = Catalog.load()
    cleared = Catalog.from_records(
        replace(record, description="", data_types=()) for record in catalog.records
    )
    assert any(catalog.route(workflow) for workflow in Workflow)
    for workflow in Workflow:
        assert [r.source_id for r in catalog.route(workflow)] == [
            r.source_id for r in cleared.route(workflow)
        ]


def test_catalog_refresh_does_not_reintroduce_publisher_text(monkeypatch):
    from tools import refresh_scientific_source_catalog as refresh
    nar = ('<div class="bodytext"><strong>Test resource</strong><br>'
           'Publisher article description<br><a href="https://example.org">database</a>'
           '<a href="/nar/database/summary/123">summary</a></div>')
    elixir = ('ELIXIR Core Data Resource list<table><tr>'
              '<td><a href="https://example.org">Test resource</a></td>'
              '<td>Publisher data type description</td></tr></table>')
    monkeypatch.setattr(refresh, "_fetch", lambda url: nar if url == refresh.NAR_INDEX else elixir)
    monkeypatch.setattr(refresh, "_nar_categories", lambda: {"123": {"Publisher category"}})
    for rows, _ in (refresh.nar_records(), refresh.elixir_records()):
        assert len(rows) == 1
        assert rows[0]["description"] == ""
        assert rows[0]["data_types"] == []
        assert rows[0]["description_status"] == "not_distributed"


def test_wheel_and_image_retain_distribution_notices():
    project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    assert set(project["project"]["license-files"]) == {"LICENSE", "THIRD_PARTY_NOTICES.md"}
    for name in project["project"]["license-files"]:
        assert (ROOT / name).is_file(), name
        assert (ROOT / name).read_text(encoding="utf-8").strip(), name


@source_tree_only("Dockerfile")
def test_image_copy_retains_distribution_notices():
    # The recipe is absent inside an image; the carried notices are checked above.
    copy_lines = [line for line in (ROOT / "Dockerfile").read_text(encoding="utf-8").splitlines()
                  if line.startswith("COPY ")]
    assert any("LICENSE" in line and "THIRD_PARTY_NOTICES.md" in line for line in copy_lines)


def test_bodyparts_notice_keeps_current_and_historical_licenses_distinct():
    from livemorebio.anatomy.meshes import BP3D_LICENSE
    assert BP3D_LICENSE["license"] == "CC-BY-4.0"
    assert BP3D_LICENSE["historical_embedded_license"] == "CC-BY-SA-2.1-JP"
    assert BP3D_LICENSE["license_verified_at"] == "2026-10-04"
    assert BP3D_LICENSE["license_url"] == "https://dbarchive.biosciencedbc.jp/en/bodyparts3d/lic.html"


def test_catalog_endpoint_and_display_names_are_factual():
    from urllib.parse import urlsplit
    payload = json.loads((ROOT / "livemorebio/scientific_sources/data/source-catalog.v1.json").read_text(encoding="utf-8"))
    for row in payload["sources"]:
        if row["collection"] not in {"nar", "elixir"}:
            continue
        endpoint = row["endpoint_url"]
        assert not endpoint or (urlsplit(endpoint).scheme in {"http", "https", "ftp"} and urlsplit(endpoint).netloc), row["source_id"]
        assert not endpoint or "@" not in urlsplit(endpoint).netloc, row["source_id"]
        assert ": " not in row["name"], row["source_id"]
        assert not any(character.isspace() for character in endpoint), row["source_id"]
        assert " - " not in row["name"], row["source_id"]


def test_catalog_refresh_sanitizes_names_and_endpoints(monkeypatch):
    from tools import refresh_scientific_source_catalog as refresh
    page = ('<div class="bodytext"><strong>Resource: publisher article title</strong><br>'
            '<a href="not an endpoint">database</a><a href="/nar/database/summary/123">summary</a></div>')
    monkeypatch.setattr(refresh, "_fetch", lambda _: page)
    monkeypatch.setattr(refresh, "_nar_categories", lambda: {})
    rows, _ = refresh.nar_records()
    assert rows[0]["name"] == "Resource"
    assert rows[0]["endpoint_url"] == ""
    assert rows[0]["endpoint_status"] == "not_a_url"


def test_catalog_refresh_preserves_colon_names_and_trims_reviewed_mojibake(monkeypatch):
    from tools import refresh_scientific_source_catalog as refresh

    names = {
        "2077": "SEA version 3.0:\u00c3\u201a\u00c2 synthetic article title",
        "2082": "SyntDB:\u00c3\u201a\u00c2 synthetic article title",
        "1150": "X:MAP", "1111": "PepCyber:P~Pep", "1682": "MP:PD",
    }
    page = "".join(
        f'<div class="bodytext"><strong>{name}</strong><br>'
        f'<a href="/nar/database/summary/{identifier}">summary</a></div>'
        for identifier, name in names.items()
    )
    monkeypatch.setattr(refresh, "_fetch", lambda _: page)
    monkeypatch.setattr(refresh, "_nar_categories", lambda: {})
    rows, _ = refresh.nar_records()
    actual = {row["source_id"]: row["name"] for row in rows}
    committed = json.loads((ROOT / "livemorebio/scientific_sources/data/source-catalog.v1.json").read_text(encoding="utf-8"))
    expected = {row["source_id"]: row["name"] for row in committed["sources"]
                if row["source_id"] in actual}
    assert actual == expected


def test_catalog_refresh_replays_every_published_name_to_the_committed_catalog():
    from tools import refresh_scientific_source_catalog as refresh
    from ._source_tree import git_executable, require_git_checkout

    require_git_checkout("published catalogue-name replay")
    relative = "livemorebio/scientific_sources/data/source-catalog.v1.json"
    published = subprocess.run([git_executable(), "show", f"stable-6588707:{relative}"],
                               cwd=ROOT, capture_output=True, text=True, check=False, encoding="utf-8")
    if published.returncode:
        shallow = subprocess.run([git_executable(), "rev-parse", "--is-shallow-repository"],
                                 cwd=ROOT, capture_output=True, text=True, check=True, encoding="utf-8")
        assert shallow.stdout.strip() == "true", published.stderr
        pytest.skip("STABLE_HISTORY_UNAVAILABLE: shallow checkout lacks published catalogue names")
    originals = json.loads(published.stdout)["sources"]
    committed = {row["source_id"]: row["name"]
                 for row in json.loads((ROOT / relative).read_text(encoding="utf-8"))["sources"]}
    assert len(originals) == len(committed) == 2633
    assert {row["source_id"] for row in originals} == set(committed)
    mismatches = [row["source_id"] for row in originals
                  if refresh._public_name(refresh._clean(row["name"]), row["source_id"])
                  != committed[row["source_id"]]]
    assert mismatches == []


def test_package_data_never_includes_private_discovery_inputs():
    project = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    assert "livemorebio.discovery" not in project["tool"]["setuptools"]["package-data"]


def test_catalog_sanitation_preserves_identifiers_provenance_and_workflow_routing():
    payload = json.loads((ROOT / "livemorebio/scientific_sources/data/source-catalog.v1.json").read_text(encoding="utf-8"))
    unchanged = [{key: row[key] for key in ("source_id", "provenance_url", "workflows")}
                 for row in payload["sources"]]
    # Captured before display-name/endpoint sanitation; routing evidence is unchanged.
    assert hashlib.sha256(json.dumps(unchanged, sort_keys=True).encode()).hexdigest() == "ca4f808d0ff604a7e08aaecaf87aed7118f3fafc713bb0478d38e1560fc171ad"
