"""Real electrophysiology checks on the hosted human O'Hara-Rudy myocyte."""
import pytest

from livemorebio._toolchain import cardiac_simulation
from livemorebio.engines.cardiac.action_potential import CardiacCell

@pytest.fixture(scope="module")
def _cell(pinned_cardiac_asset):
    # L0-R2: verify the asset before the existing host-toolchain convention.
    toolchain = cardiac_simulation()
    if not toolchain["available"]:
        pytest.skip(toolchain["reason"] or "cardiac toolchain unavailable")
    return CardiacCell()


def test_human_ap_is_physiologic(_cell):
    r = _cell.simulate(beats=6, ikr_block=0.0)
    assert -95 < r["vrest"] < -80      # physiologic resting potential
    assert 20 < r["vpeak"] < 60        # overshoot
    assert 180 < r["apd90_ms"] < 400   # endocardial APD90


def test_ikr_block_prolongs_apd(_cell):
    base = _cell.simulate(beats=6, ikr_block=0.0)
    blocked = _cell.simulate(beats=6, ikr_block=0.5)
    assert blocked["apd90_ms"] > base["apd90_ms"] + 20   # hERG block -> QT prolongation
