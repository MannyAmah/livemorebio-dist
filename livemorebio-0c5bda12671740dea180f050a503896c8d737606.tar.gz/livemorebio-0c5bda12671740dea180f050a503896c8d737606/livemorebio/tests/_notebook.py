"""Qualification for tests of installed notebook integration, never product admission."""
from __future__ import annotations

from importlib import metadata

import pytest


_QUALIFIED = (("jupyter-server", "2.21.0"), ("jupyterlab", "4.6.4"), ("tornado", "6.5.9"))


def require_qualified_notebook_packages() -> None:
    """Skip installed-package integration only when any qualified pin differs."""
    installed = []
    for name, _ in _QUALIFIED:
        try:
            version = metadata.version(name)
        except metadata.PackageNotFoundError:
            version = "missing"
        installed.append((name, version))
    if tuple(installed) != _QUALIFIED:
        required = ", ".join(f"{name}=={version}" for name, version in _QUALIFIED)
        actual = ", ".join(f"{name}=={version}" for name, version in installed)
        pytest.skip(f"Notebook integration requires {required}; installed {actual}")


@pytest.fixture
def qualified_notebook_packages():
    require_qualified_notebook_packages()
