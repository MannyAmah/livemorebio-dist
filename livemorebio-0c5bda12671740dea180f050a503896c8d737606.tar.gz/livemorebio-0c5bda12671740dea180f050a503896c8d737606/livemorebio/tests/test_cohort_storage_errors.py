"""Legacy cohort HTTP failures use fixed, private responses, not partial data."""
from __future__ import annotations

import socket
import sqlite3
from types import SimpleNamespace

from cryptography.exceptions import InvalidTag
from fastapi.testclient import TestClient
import pytest

from livemorebio.tests.stack_client_fixtures import forbid_stack_client

from livemorebio.aegle.registry_audit import RegistryAuditError
from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError

AUTH = {"Authorization": "Bearer authored-cohort-storage-test"}
PATHS = ("/api/cohorts", "/api/cohorts/cohort-authored")
SENTINEL = "private-authored-record-sentinel"


@pytest.fixture
def client(monkeypatch):
    def forbidden(*args, **kwargs):
        pytest.fail("Cohort error review attempted a model or network connection")
    monkeypatch.setattr(socket, "create_connection", forbidden)
    monkeypatch.setattr(socket, "getaddrinfo", forbidden)
    monkeypatch.setattr(socket.socket, "connect", forbidden)
    monkeypatch.setattr(socket.socket, "connect_ex", forbidden)
    monkeypatch.setattr("urllib.request.urlopen", forbidden)
    monkeypatch.setattr("urllib.request.build_opener", forbidden)
    monkeypatch.setattr("livemorebio.transport.authenticated_opener", forbidden)
    forbid_stack_client(monkeypatch, forbidden)
    from livemorebio.aegle import server, runtime
    monkeypatch.setattr(server, "AegleTwin", forbidden)
    monkeypatch.setattr(runtime, "AegleTwin", forbidden)
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "authored-cohort-storage-test")
    # No lifespan entry: this tests real route dispatch, never startup models.
    return TestClient(server.app, raise_server_exceptions=False)


def assert_storage_failure(response, *, bootstrap=False):
    assert response.status_code == 503
    assert response.headers["cache-control"] == "no-store"
    expected = ({"code": "REGISTRY_BOOTSTRAP_INVALID",
                 "error": "Registry key authority could not be confirmed; no successful access is established."}
                if bootstrap else {"code": "REFERENCE_STORAGE_UNAVAILABLE",
                                   "error": "Reference storage or its audit is unavailable."})
    assert response.json() == expected
    assert SENTINEL not in response.text and "cohorts" not in response.json()


@pytest.mark.parametrize("path", PATHS)
@pytest.mark.parametrize("error_type", [RegistryBootstrapError, RegistryAuditError, sqlite3.OperationalError, InvalidTag, OSError])
@pytest.mark.parametrize("stage", ["acquisition", "read", "projection"])
def test_storage_failures_never_return_partial_cohorts(client, monkeypatch, path, error_type, stage):
    from livemorebio.aegle import server, reference_cohort_api
    def fail(*args, **kwargs):
        if error_type in (RegistryBootstrapError, RegistryAuditError):
            raise error_type()
        raise error_type(SENTINEL)
    record = {"cohort_id": "cohort-authored", "source_class": "PUBLIC_REFERENCE"}
    registry = SimpleNamespace(get_cohort=lambda *a: record,
        page_records=lambda *a, **k: {"records": [record, record], "pagination": {"next_cursor": None}})
    if stage == "read":
        registry.get_cohort = registry.page_records = fail
    monkeypatch.setattr(server, "_subject_registry", fail if stage == "acquisition" else lambda: registry)
    calls = []
    def project(value):
        calls.append(value)
        if stage == "projection" and (path != "/api/cohorts" or len(calls) == 2):
            fail()
        return {**value, "name": SENTINEL}
    monkeypatch.setattr(reference_cohort_api, "project_cohort_summary_for_api", project)
    assert_storage_failure(client.get(path, headers=AUTH), bootstrap=error_type is RegistryBootstrapError)
    assert len(calls) == ((2 if path == "/api/cohorts" else 1) if stage == "projection" else 0)


@pytest.mark.parametrize("path", PATHS)
def test_authentication_precedes_registry_access(client, monkeypatch, path):
    from livemorebio.aegle import server
    monkeypatch.setattr(server, "_subject_registry", lambda: pytest.fail("Unauthenticated registry read"))
    assert client.get(path).status_code == 401


@pytest.mark.parametrize("path", PATHS)
@pytest.mark.parametrize("code,status", [("RECORD_NOT_FOUND", 404), ("IDEMPOTENCY_CONFLICT", 409), ("INVALID_PAGE", 422)])
def test_typed_domain_errors_keep_their_status_and_no_store(client, monkeypatch, path, code, status):
    from livemorebio.aegle import server
    from livemorebio.aegle.subjects import SubjectRegistryError
    def fail():
        raise SubjectRegistryError(code, "Authored public domain diagnostic")
    monkeypatch.setattr(server, "_subject_registry", fail)
    response = client.get(path, headers=AUTH)
    assert response.status_code == status and response.json()["code"] == code
    assert response.headers["cache-control"] == "no-store"


@pytest.mark.parametrize("path", PATHS)
def test_missing_storage_key_is_typed_unavailable_without_opening_registry(client, monkeypatch, path):
    from livemorebio import security
    from livemorebio.aegle.subjects import SubjectRegistry
    monkeypatch.setattr(security, "patch_storage_key", lambda **k: None)
    monkeypatch.setattr(SubjectRegistry, "__init__", lambda *a, **k: pytest.fail("Registry opened without key"))
    response = client.get(path, headers=AUTH)
    assert response.status_code == 503
    assert response.json() == {
        "code": "PATCH_STORAGE_KEY_UNAVAILABLE",
        "error": "Encrypted state storage is unavailable; configure LIVEMORE_PATCH_STORAGE_KEY.",
    }
    assert response.headers["cache-control"] == "no-store"


def test_unavailable_key_retains_runtime_error_classification(client, monkeypatch):
    from livemorebio import security
    from livemorebio.aegle import server
    monkeypatch.setattr(security, "patch_storage_key", lambda **k: None)
    with pytest.raises(RuntimeError) as caught:
        server._subject_registry()
    assert type(caught.value).__name__ == "_RegistryKeyUnavailable"
    assert not isinstance(caught.value, ValueError)
    assert str(caught.value) == "subject registry encryption key is unavailable"
    # Mutations now establish their bus storage prerequisite before accessing
    # the registry, while the registry's own exception contract stays unchanged.
    monkeypatch.setattr(server, "_subject_registry", lambda: pytest.fail("Mutation opened registry without key"))
    response = client.post("/api/twins/twin-authored/select-observations", headers=AUTH,
                           json={"expected_version": 1})
    assert response.status_code == 503
    assert response.json()["code"] == "PATCH_STORAGE_KEY_UNAVAILABLE"
    assert response.headers["cache-control"] == "no-store"


@pytest.mark.parametrize("path", PATHS)
def test_unexpected_programming_error_is_not_reclassified_as_missing_storage(client, monkeypatch, path):
    from livemorebio.aegle import server
    def fail():
        raise TypeError("Authored unexpected programmer error")
    monkeypatch.setattr(server, "_subject_registry", fail)
    response = client.get(path, headers=AUTH)
    assert response.status_code == 500 and "REFERENCE_STORAGE_UNAVAILABLE" not in response.text


@pytest.mark.parametrize("path", PATHS)
def test_actual_damaged_private_authority_returns_no_cohort_data(client, tmp_path, monkeypatch, path):
    from livemorebio.aegle import server
    from livemorebio.aegle.subjects import SubjectRegistry
    from livemorebio.tests.test_registry_bootstrap_contract import KEY, old_store
    from livemorebio.tests.test_registry_bootstrap_shape import remove_markers, snapshot
    from livemorebio.tests.clinical_registry_fixtures import legacy_cohort_record
    store = old_store(tmp_path, [legacy_cohort_record([])])
    registry = SubjectRegistry(store, key=KEY)
    registry.get_cohort("cohort-legacy-fixture")
    remove_markers(store, "both")
    before = snapshot(store)
    monkeypatch.setattr(server, "_subject_registry", lambda: registry)
    monkeypatch.setattr(registry, "_open", lambda *a: pytest.fail("Damaged authority decrypted a cohort"))
    assert_storage_failure(client.get(path, headers=AUTH), bootstrap=True)
    assert snapshot(store) == before


@pytest.mark.parametrize("path", PATHS)
@pytest.mark.parametrize("code,status", [
    ("REFERENCE_COHORT_NOT_FOUND", 404), ("IDEMPOTENCY_CONFLICT", 409), ("INVALID_REFERENCE_DRAFT", 422),
])
def test_typed_reference_errors_keep_status_and_no_store(client, monkeypatch, path, code, status):
    from livemorebio.aegle import server
    from livemorebio.aegle.reference_cohorts import ReferenceCohortError
    def fail():
        raise ReferenceCohortError(code, "Authored public reference diagnostic", status)
    monkeypatch.setattr(server, "_subject_registry", fail)
    response = client.get(path, headers=AUTH)
    assert response.status_code == status and response.json()["code"] == code
    assert response.headers["cache-control"] == "no-store"
