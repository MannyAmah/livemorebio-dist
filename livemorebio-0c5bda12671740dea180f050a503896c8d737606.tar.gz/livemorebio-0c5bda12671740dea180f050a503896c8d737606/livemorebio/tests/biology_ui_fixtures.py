"""Inline the real local helper for controller-only VM tests without WebGL.

Node's vm.Script cannot parse ESM declarations. Graphics itself is exercised by
the separate anatomy tests and real browser; this retains the actual helper code
and the entire Biology controller, rather than bypassing its mount or assertions.
"""
from pathlib import Path
import re

CONSOLE = Path(__file__).parents[1] / "aegle/console"


def biology_controller_script() -> str:
    script = re.findall(
        r'<script type="module">(.*?)</script>',
        (CONSOLE / "biology.html").read_text(encoding="utf-8"), re.S,
    )[0]
    declaration = "import {restoreAnatomyView} from '/lib/anatomy_view_state.js';"
    assert declaration in script
    helper = (CONSOLE / "lib/anatomy_view_state.js").read_text(encoding="utf-8")
    script=script.replace(declaration, helper.replace("export function", "function"), 1)
    molecular="import {mountMolecularInspector} from '/lib/molecular_inspector.js';"
    if molecular in script:
        script=script.replace(molecular,"const mountMolecularInspector=(...args)=>window.testMountMolecularInspector(...args);",1)
    availability="import {modelAvailability} from '/lib/biological_projection.js';"
    if availability in script:
        pure=(CONSOLE/'lib/biological_projection.js').read_text(encoding="utf-8")
        function=re.search(r'export function modelAvailability\(.*?\n}\n',pure,re.S)
        assert function, 'The real typed availability validator must be included'
        script=script.replace(availability,function[0].replace('export function','function'),1)
    return script
