"""Startup source ownership using authored doubles, not patients or a solver."""
from contextlib import contextmanager
from copy import deepcopy
from types import SimpleNamespace
import threading
import weakref
from uuid import UUID

import pytest

from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401


@pytest.fixture
def startup(client, monkeypatch):
    from livemorebio.aegle import server
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.execution_api import _creation_lock
    from livemorebio.aegle.model_contexts import model_availability
    from livemorebio.aegle.model_source import ModelSourceAuthority

    calls = []
    scenario = {"kind": "present", "fail": None, "supersede": None,
                "initialized_only": False, "cleanup_failure": False,
                "typed_unavailable": False}
    record = {**deepcopy(server._state["subject"]), "source_class": "SYNTHETIC",
              "display_label": "Authored startup source, not a participant",
              "selection_mode": "model", "demographics": {"age": 40, "sex": "female"},
              "conditions": [], "genome": {}, "lifestyle": 0.5}
    captured = SimpleNamespace(record=None)
    captured_initialized = []
    winner = {"tw": object(), "subject": {"technical": "operator-winner"},
              "initialized": True, "observation_state": object(),
              "model_availability": {"technical": "operator-winner"}}
    winner_actions = [object()]
    finalized = [False]
    initial_state = {**server._state, "tw": None, "subject": None,
                     "initialized": False}
    monkeypatch.setattr(server, "_state", initial_state)
    old_actions = [object()]
    monkeypatch.setattr(server, "_workspace_actions", old_actions)

    def unlocked(*, initialization_allowed=True):
        assert not authority._lock._is_owned()
        assert not _creation_lock._is_owned() and not manager._lock._is_owned()
        if not initialization_allowed:
            assert not server._initialization_lock._is_owned()

    def step(name):
        calls.append(name)
        if scenario["supersede"] == name:
            with authority.commit_guard():
                if not scenario["initialized_only"]:
                    authority.install_generation("authored-winning-generation")
                server._state = winner
                server._workspace_actions = winner_actions
        if scenario["fail"] == name:
            raise OSError("AUTHORED_PRIVATE_ERROR_NOT_FOR_UI")

    @contextmanager
    def exact_guard():
        with server._model_fence_guard():
            try:
                yield
            finally:
                if finalized[0]:
                    assert server._state["initialized"] is True
                    assert server._state["subject"] == (
                        server._subject_summary(captured.record) if captured.record else None)
                    assert manager.permitted == authority.generation != original_generation
                    expected_availability = model_availability(
                        captured.record, source_generation=authority.generation)
                    if scenario["typed_unavailable"]:
                        expected_availability.update(state="UNAVAILABLE", reason_code="MODEL_CONTEXT_UNSUPPORTED",
                            selection_mode="observations_only", preparation_available=False)
                    assert server._state["model_availability"] == expected_availability
                    assert server._state["tw"] is (
                        candidate if expected_availability["state"] == "READY" else None)
                    assert server._state["observation_state"] is not initial_state["observation_state"]
                    assert server._state["observation_state"].observations == {}
                    assert server._workspace_actions == []
                    assert server._workspace_actions is not old_actions
                    assert authority._lock._is_owned() and _creation_lock._is_owned()
                    assert manager._lock._is_owned()
                    finalized[0] = False

    class Manager:
        _lock = threading.RLock()

        def set_source_generation(self, generation):
            assert self._lock._is_owned() and _creation_lock._is_owned()
            self.permitted = generation

        def invalidate_source(self, generation, reason):
            unlocked(initialization_allowed=False)
            assert generation == original_generation
            assert authority.permitted_generation is DENY_ALL or server._state["initialized"]
            calls.append("invalidate")
            if scenario["cleanup_failure"]:
                raise OSError("AUTHORED_CLEANUP_ERROR")

    manager = Manager()
    monkeypatch.setattr(server, "_execution_manager_instance", manager)
    authority = ModelSourceAuthority(server._invalidate_model_source,
        fence=server._assign_model_fence, fence_guard=exact_guard)
    original_generation = authority.generation
    manager.permitted = original_generation
    monkeypatch.setattr(server, "_model_source_authority", authority)

    def candidate_state():
        unlocked()
        step("state")
        return {"profile": "AUTHORED TEST ONLY", "profile_params": {"technical": 1}}

    candidate = SimpleNamespace(state=candidate_state)

    class Registry:
        def active_twin(self):
            pytest.fail("startup used unchecked active_twin")

        def audited_active_twin(self, *, action, request_id, _checked_snapshot):
            assert authority._lock._is_owned()
            assert not _creation_lock._is_owned() and not manager._lock._is_owned()
            assert action == "inspect" and _checked_snapshot is True
            UUID(request_id)
            step("read")
            captured.record = None if scenario["kind"] == "absent" else deepcopy(record)
            return captured

        def build_twin(self, value):
            unlocked()
            assert value == captured.record and captured.record is not None
            step("build")
            return candidate

        def confirm_active_selection(self, *, expected_record, request_id, _expected_snapshot):
            assert authority._lock._is_owned() and _creation_lock._is_owned()
            assert manager._lock._is_owned()
            assert authority.generation == original_generation
            assert server._state is initial_state
            assert server._state["initialized"] is captured_initialized[0]
            assert expected_record == captured.record and _expected_snapshot is captured
            UUID(request_id)
            step("confirm")
            finalized[0] = True

    registry = Registry()

    def get_registry():
        unlocked()
        captured_initialized.append(initial_state["initialized"])
        step("get")
        return registry

    def availability(value, **kwargs):
        unlocked()
        step("availability")
        return model_availability(value, **kwargs)

    def healthy(*args, **kwargs):
        unlocked()
        assert args == ("healthy",) and not kwargs and captured.record is None
        step("build")
        return candidate

    def publish(*args, **kwargs):
        unlocked(initialization_allowed=False)
        assert len(args) == 1 and not kwargs
        snapshot = args[0]
        assert snapshot["model_availability"] == server._state["model_availability"]
        assert snapshot["model_availability"]["source_generation"] == authority.generation
        assert snapshot["profile_params"] == (
            {"technical": 1} if server._state["tw"] is candidate else None)
        calls.append("publish")

    monkeypatch.setattr(server, "_subject_registry", get_registry)
    monkeypatch.setattr(server, "model_availability", availability)
    monkeypatch.setattr(server, "AegleTwin", healthy)
    monkeypatch.setattr(server, "_snapshot_twin", publish)
    return SimpleNamespace(server=server, client=client, scenario=scenario, calls=calls,
        authority=authority, manager=manager, original_generation=original_generation,
        record=record, captured=captured, candidate=candidate, initial=initial_state,
        winner=winner, winner_actions=winner_actions, registry=registry)


@pytest.mark.parametrize("kind", ["present", "absent", "observation_only"])
def test_startup_checks_exact_selection_before_coherent_publication(startup, kind):
    t = startup
    t.scenario["kind"] = kind
    if kind == "observation_only":
        t.record["source_class"] = "REAL_HUMAN"
    t.server._ensure_selected_state()
    assert t.server._state["initialized"] is True
    assert t.authority.generation == t.manager.permitted != t.original_generation
    assert t.server._state["subject"] == (None if kind == "absent" else t.server._subject_summary(t.record))
    assert t.server._state["tw"] is (None if kind == "observation_only" else t.candidate)
    assert t.calls.count("get") == t.calls.count("read") == t.calls.count("confirm") == 1
    assert t.calls.count("build") == (0 if kind == "observation_only" else 1)
    assert t.calls.count("invalidate") == 1
    assert t.calls.index("availability") < t.calls.index("confirm")
    assert t.server._state["observation_state"] is not t.initial["observation_state"]
    assert t.server._workspace_actions == []
    t.server._ensure_selected_state()
    assert t.calls.count("read") == 1


@pytest.mark.parametrize("stage", ["get", "read", "availability", "build", "state", "confirm"])
def test_untyped_startup_failure_denies_numerics_but_preserves_static_app(startup, stage, caplog):
    from livemorebio.aegle.execution import DENY_ALL
    t = startup
    t.scenario["fail"] = stage
    t.server._ensure_selected_state()
    assert t.authority.permitted_generation is DENY_ALL and t.manager.permitted is DENY_ALL
    assert t.server._state["initialized"] is True
    assert t.client.get("/").status_code == 200
    result = t.client.get("/api/state")
    assert result.status_code == 503 and result.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
    assert "AUTHORED_PRIVATE_ERROR_NOT_FOR_UI" not in caplog.text + result.text
    calls = list(t.calls)
    t.server._ensure_selected_state()
    assert t.calls == calls
    assert "publish" not in calls


@pytest.mark.parametrize("stage", ["get", "read", "availability", "build", "state"])
@pytest.mark.parametrize("late_failure", [False, True])
def test_operator_selection_wins_over_late_startup_success_or_failure(startup, stage, late_failure):
    t = startup
    t.scenario.update(supersede=stage, fail=stage if late_failure else None)
    t.server._ensure_selected_state()
    assert t.server._state is t.winner and t.server._workspace_actions is t.winner_actions
    assert t.authority.generation == t.manager.permitted == "authored-winning-generation"
    assert "confirm" not in t.calls and "invalidate" not in t.calls and "publish" not in t.calls


def test_initialized_state_supersession_blocks_startup_even_without_generation_change(startup):
    t = startup
    t.scenario.update(supersede="build", initialized_only=True)
    t.server._ensure_selected_state()
    assert t.server._state is t.winner and t.server._workspace_actions is t.winner_actions
    assert t.authority.generation == t.original_generation
    assert "confirm" not in t.calls and "invalidate" not in t.calls


def test_cleanup_failure_cannot_poison_a_confirmed_startup_publication(startup):
    t = startup
    t.scenario["cleanup_failure"] = True
    t.server._ensure_selected_state()
    assert t.server._state["tw"] is t.candidate
    assert t.authority.generation == t.manager.permitted != t.original_generation
    assert t.calls.count("confirm") == 1 and t.calls.count("invalidate") == 1


def test_direct_restore_keeps_checked_compatibility_without_forcing_ordinary_ensure(startup):
    t = startup
    t.initial["initialized"] = True
    t.server._ensure_selected_state()
    assert t.calls == []
    assert t.server._restore_active_subject() is True
    assert t.calls.count("confirm") == 1 and t.calls.count("publish") == 1
    assert t.server._state["tw"] is t.candidate


def test_denied_startup_never_reopens_authority_or_looks_up_registry(startup):
    from livemorebio.aegle.execution import DENY_ALL
    t = startup
    with t.authority.commit_guard():
        t.authority.install_generation(DENY_ALL)
    t.server._ensure_selected_state()
    assert t.server._state["initialized"] is True
    assert t.authority.permitted_generation is t.manager.permitted is DENY_ALL
    assert t.calls == []
    assert t.client.get("/").status_code == 200
    assert t.client.get("/api/state").status_code == 503


@pytest.mark.parametrize("snapshot", [None, {}, {"profile_params": "invalid"}])
def test_invalid_startup_projection_fails_before_confirmation(startup, snapshot):
    from livemorebio.aegle.execution import DENY_ALL
    t = startup
    t.candidate.state = lambda: deepcopy(snapshot)
    t.server._ensure_selected_state()
    assert t.authority.permitted_generation is DENY_ALL
    assert "confirm" not in t.calls and "publish" not in t.calls


def test_ready_startup_constructor_cannot_return_no_model(startup, monkeypatch):
    from livemorebio.aegle.execution import DENY_ALL
    t = startup
    monkeypatch.setattr(t.registry, "build_twin", lambda record: None)
    t.server._ensure_selected_state()
    assert t.authority.permitted_generation is DENY_ALL
    assert "confirm" not in t.calls and "publish" not in t.calls


@pytest.mark.parametrize("failure", [None, "read"])
def test_startup_event_handler_publishes_only_the_confirmed_prepared_snapshot(startup, failure):
    t = startup
    t.scenario["fail"] = failure
    t.server._startup_publish()
    assert t.calls.count("publish") == (1 if failure is None else 0)
    assert t.calls.count("confirm") == (1 if failure is None else 0)


@pytest.mark.parametrize("kind", ["present", "absent"])
def test_typed_context_failure_is_modeless_only_for_a_confirmed_present_record(startup, monkeypatch, kind):
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.model_contexts import ModelContextError
    t = startup
    t.scenario["kind"] = kind
    t.scenario["typed_unavailable"] = True

    def unsupported(*args, **kwargs):
        raise ModelContextError("MODEL_CONTEXT_UNSUPPORTED")

    monkeypatch.setattr(t.registry, "build_twin", unsupported)
    monkeypatch.setattr(t.server, "AegleTwin", unsupported)
    t.server._ensure_selected_state()
    if kind == "absent":
        assert t.authority.permitted_generation is DENY_ALL
        assert "confirm" not in t.calls
    else:
        assert t.calls.count("confirm") == 1
        assert t.server._state["tw"] is None
        assert t.server._state["model_availability"]["reason_code"] == "MODEL_CONTEXT_UNSUPPORTED"
        assert t.server._state["subject"] == t.server._subject_summary(t.record)
        assert t.authority.generation == t.manager.permitted != t.original_generation


def test_unused_startup_candidate_is_retired_after_initialization_mutex(startup, monkeypatch):
    from livemorebio.aegle.execution_api import _creation_lock
    t = startup
    retired = []

    def released():
        retired.append((t.authority._lock._is_owned(), _creation_lock._is_owned(),
                        t.manager._lock._is_owned(), t.server._initialization_lock._is_owned()))

    class Candidate:
        def __init__(self):
            weakref.finalize(self, released)

        def state(self):
            return {"profile": "Authored unused candidate", "profile_params": {}}

    def construct_and_supersede(record):
        candidate = Candidate()
        with t.authority.commit_guard():
            t.authority.install_generation("authored-winning-generation")
            t.server._state = t.winner
            t.server._workspace_actions = t.winner_actions
        return candidate

    monkeypatch.setattr(t.registry, "build_twin", construct_and_supersede)
    t.server._ensure_selected_state()
    assert t.server._state is t.winner
    assert retired == [(False, False, False, False)]
    assert "confirm" not in t.calls and "invalidate" not in t.calls


def test_replaced_startup_payloads_retire_outside_every_lock_without_test_owners(client, monkeypatch):
    from livemorebio.aegle import server
    from livemorebio.aegle.execution_api import _creation_lock
    from livemorebio.aegle.model_source import ModelSourceAuthority

    retired = []

    class Manager:
        _lock = threading.RLock()

        def set_source_generation(self, generation):
            self.permitted = generation

        def invalidate_source(self, generation, reason):
            assert not server._initialization_lock._is_owned()

    manager = Manager()
    monkeypatch.setattr(server, "_execution_manager_instance", manager)
    authority = ModelSourceAuthority(server._invalidate_model_source,
        fence=server._assign_model_fence, fence_guard=server._model_fence_guard)
    manager.permitted = authority.generation
    monkeypatch.setattr(server, "_model_source_authority", authority)

    def released(name):
        retired.append((name, authority._lock._is_owned(), _creation_lock._is_owned(),
                        manager._lock._is_owned(), server._initialization_lock._is_owned()))

    class Payload:
        def __init__(self, name):
            weakref.finalize(self, released, name)

    # Neither a fixture-held old state dictionary nor monkeypatch's previous
    # value retains these payloads. Only the installed server containers do.
    monkeypatch.setattr(server, "_state", {**server._state, "tw": Payload("model"),
        "subject": None, "initialized": False})
    monkeypatch.setattr(server, "_workspace_actions", [Payload("action")])
    record = {"twin_id": "twin-authored-startup", "subject_id": "pseudonym-authored-startup",
        "display_label": "Authored startup, not a participant", "source_class": "SYNTHETIC",
        "lifecycle": "ACTIVE", "version": 2}
    checked = SimpleNamespace(record=deepcopy(record))
    candidate = SimpleNamespace(state=lambda: {"profile": "Authored new state", "profile_params": {}})

    class Registry:
        def audited_active_twin(self, **kwargs):
            return checked

        def confirm_active_selection(self, **kwargs):
            assert kwargs["_expected_snapshot"] is checked

        def build_twin(self, value):
            return candidate

    monkeypatch.setattr(server, "_subject_registry", Registry)
    monkeypatch.setattr(server, "_snapshot_twin", lambda *a, **k: None)
    server._ensure_selected_state()
    assert server._state["tw"] is candidate
    assert sorted(retired) == [("action", False, False, False, False),
                               ("model", False, False, False, False)]
