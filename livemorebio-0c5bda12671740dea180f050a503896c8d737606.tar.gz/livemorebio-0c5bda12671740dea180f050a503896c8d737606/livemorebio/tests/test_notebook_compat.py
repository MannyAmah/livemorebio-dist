"""Installed-handler HTTP regressions using technical assets on ephemeral loopback."""
from __future__ import annotations

from contextlib import contextmanager
import importlib
import inspect
from pathlib import Path

from jinja2 import DictLoader, Environment
from jupyter_server.auth import IdentityProvider
from jupyter_server.base.handlers import FileFindHandler
from jupyterlab_server.themes_handler import ThemesHandler
import pytest
from tornado.testing import AsyncHTTPTestCase, AsyncTestCase
from tornado.web import Application, HTTPError, StaticFileHandler

from livemorebio.tests._notebook import qualified_notebook_packages  # noqa: F401


requires_qualified_notebook = pytest.mark.usefixtures("qualified_notebook_packages")


@pytest.fixture(autouse=True)
def technical_environment(tmp_path, monkeypatch):
    for name in ("HOME", "JUPYTER_CONFIG_DIR", "JUPYTER_DATA_DIR", "JUPYTER_RUNTIME_DIR",
                 "XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_RUNTIME_DIR"):
        monkeypatch.setenv(name, str(tmp_path / "technical-home"))
    # Each test controls whether the installed handler is patched, regardless of
    # earlier identity-provider imports during collection or other tests.
    monkeypatch.setattr(FileFindHandler, "validate_absolute_path",
                        inspect.unwrap(FileFindHandler.validate_absolute_path))
    monkeypatch.setattr(FileFindHandler, "_static_paths", {})


@pytest.fixture
def technical_roots(tmp_path):
    roots = [tmp_path / "technical-first", tmp_path / "technical-second"]
    for root in roots:
        root.mkdir()
    (roots[0] / "technical.txt").write_text("technical first asset", encoding="utf-8")
    (roots[1] / "second.txt").write_text("technical second asset", encoding="utf-8")
    return roots


def import_provider():
    """Replay only the server's provider-module import, without creating a server."""
    from livemorebio import notebook_identity

    importlib.reload(notebook_identity)


def technical_handler(roots, handler_class=FileFindHandler):
    handler = object.__new__(handler_class)
    handler.initialize(path=[str(root) for root in roots])
    handler.path = "technical.txt"
    return handler


@requires_qualified_notebook
def test_unpatched_installed_validator_has_missing_attribute(technical_roots):
    handler = technical_handler(technical_roots)
    with pytest.raises(AttributeError, match="allowed_symlink_directory"):
        handler.validate_absolute_path(handler.root, str(technical_roots[0] / "technical.txt"))


@pytest.mark.parametrize("handler_class", [FileFindHandler, ThemesHandler])
@pytest.mark.parametrize("root_index,filename", [(0, "technical.txt"), (1, "second.txt")])
@requires_qualified_notebook
def test_installed_validator_selects_served_root(technical_roots, handler_class, root_index, filename):
    import_provider()
    handler = technical_handler(technical_roots, handler_class)
    path = str(technical_roots[root_index] / filename)
    assert handler.validate_absolute_path(handler.root, path) == str(Path(path).resolve())
    assert handler.allowed_symlink_directory == handler.root[root_index]


@pytest.mark.parametrize("handler_class", [FileFindHandler, ThemesHandler])
@pytest.mark.parametrize("destination", ["outside", "other-root", "inside"])
@requires_qualified_notebook
def test_installed_validator_retains_symlink_protection(technical_roots, tmp_path, handler_class, destination):
    outside = tmp_path / "technical-outside.txt"
    outside.write_text("technical outside asset", encoding="utf-8")
    targets = {"outside": outside, "other-root": technical_roots[1] / "second.txt",
               "inside": technical_roots[0] / "technical.txt"}
    path = technical_roots[0] / "link.txt"
    path.symlink_to(targets[destination])
    import_provider()
    handler = technical_handler(technical_roots, handler_class)
    if destination == "inside":
        assert handler.validate_absolute_path(handler.root, str(path)) == str(path.resolve())
    else:
        with pytest.raises(HTTPError) as refusal:
            handler.validate_absolute_path(handler.root, str(path))
        assert refusal.value.status_code == 403


@contextmanager
def technical_http(roots, handler=FileFindHandler):
    class TechnicalHTTPTest(AsyncHTTPTestCase):
        def get_app(self):
            return Application(
                [(r"/static/(.*)", handler, {"path": [str(root) for root in roots]})],
                identity_provider=IdentityProvider(token="technical-unused-token"),
                cookie_secret=b"technical-cookie-secret",
                jinja2_env=Environment(loader=DictLoader({"error.html": "Technical error"})),
            )

    case = TechnicalHTTPTest()
    # AsyncHTTPTestCase uses bind_unused_port(): 127.0.0.1, port=0. Its tearDown
    # closes all connections and sockets. No Jupyter ServerApp is constructed.
    try:
        case.setUp()
    except BaseException:
        AsyncTestCase.tearDown(case)
        raise
    try:
        assert case.get_url("/").startswith("http://127.0.0.1:")
        yield case
    finally:
        case.tearDown()


@requires_qualified_notebook
def test_unpatched_installed_handler_returns_500(technical_roots, caplog):
    with technical_http(technical_roots) as server:
        response = server.fetch("/static/technical.txt")
    assert response.code == 500
    assert any(record.exc_info and isinstance(record.exc_info[1], AttributeError)
               and "allowed_symlink_directory" in str(record.exc_info[1])
               for record in caplog.records)


@pytest.mark.parametrize("handler", [FileFindHandler, ThemesHandler])
@requires_qualified_notebook
def test_shim_serves_static_file(technical_roots, handler):
    import_provider()
    with technical_http(technical_roots, handler) as server:
        response = server.fetch("/static/technical.txt")
    assert response.code == 200
    assert response.body == b"technical first asset"


@pytest.mark.parametrize("handler", [FileFindHandler, ThemesHandler])
@requires_qualified_notebook
def test_shim_selects_second_root(technical_roots, handler):
    import_provider()
    with technical_http(technical_roots, handler) as server:
        response = server.fetch("/static/second.txt")
    assert response.code == 200
    assert response.body == b"technical second asset"


@pytest.mark.parametrize("destination", ["outside", "other-root"])
@pytest.mark.parametrize("handler", [FileFindHandler, ThemesHandler])
@requires_qualified_notebook
def test_shim_forbids_symlink_escape(technical_roots, tmp_path, destination, handler):
    outside = tmp_path / "technical-outside.txt"
    outside.write_text("technical outside asset", encoding="utf-8")
    target = outside if destination == "outside" else technical_roots[1] / "second.txt"
    (technical_roots[0] / "escape.txt").symlink_to(target)
    import_provider()
    with technical_http(technical_roots, handler) as server:
        response = server.fetch("/static/escape.txt")
    assert response.code == 403
    assert b"technical outside asset" not in response.body
    assert b"technical second asset" not in response.body


@requires_qualified_notebook
def test_shim_allows_symlink_inside_selected_root(technical_roots):
    (technical_roots[0] / "inside.txt").symlink_to(technical_roots[0] / "technical.txt")
    import_provider()
    with technical_http(technical_roots) as server:
        response = server.fetch("/static/inside.txt")
    assert response.code == 200
    assert response.body == b"technical first asset"


@requires_qualified_notebook
def test_shim_preserves_missing_file_response(technical_roots):
    import_provider()
    with technical_http(technical_roots) as server:
        response = server.fetch("/static/missing.txt")
    assert response.code == 404


@requires_qualified_notebook
def test_provider_import_installs_shim_in_server_process():
    original = FileFindHandler.validate_absolute_path
    import_provider()
    assert FileFindHandler.validate_absolute_path is not original
    installed = FileFindHandler.validate_absolute_path
    import_provider()
    assert FileFindHandler.validate_absolute_path is installed


@pytest.mark.parametrize("guard", ["tornado-version", "server-version", "resolver"])
def test_shim_is_version_and_feature_guarded(monkeypatch, guard):
    from livemorebio import notebook_compat

    original = FileFindHandler.validate_absolute_path
    if guard == "tornado-version":
        monkeypatch.setattr(notebook_compat.tornado, "version", "0.0.technical")
    elif guard == "server-version":
        monkeypatch.setattr(notebook_compat.metadata, "version", lambda name: "0.0.technical")
    else:
        monkeypatch.delattr(StaticFileHandler, "_resolve_symlink_target", raising=False)
    notebook_compat.install_static_file_compat()
    assert FileFindHandler.validate_absolute_path is original


@requires_qualified_notebook
def test_shim_preserves_an_existing_symlink_boundary(technical_roots):
    import_provider()
    handler = object.__new__(FileFindHandler)
    handler.initialize(path=[str(root) for root in technical_roots])
    handler.allowed_symlink_directory = str(technical_roots[0].parent)
    handler.path = "technical.txt"
    expected = handler.allowed_symlink_directory
    path = str(technical_roots[0] / "technical.txt")
    assert handler.validate_absolute_path(handler.root, path) == str(Path(path).resolve())
    assert handler.allowed_symlink_directory == expected
