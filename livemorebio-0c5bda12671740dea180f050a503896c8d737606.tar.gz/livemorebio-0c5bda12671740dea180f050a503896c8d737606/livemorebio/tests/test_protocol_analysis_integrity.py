"""Frozen exports must preserve computed data, not invent visual kinetics."""
from copy import deepcopy

import numpy as np
import pytest

from livemorebio.cendos.assays import ogtt_effect
from livemorebio.cendos.protocol_runs import ProtocolRunStore, analysis_notebook
from livemorebio.engines.metabolic.glucose_insulin import HEALTHY, T2D


def test_retained_series_are_the_integrations_behind_the_report():
    result = ogtt_effect(T2D, HEALTHY, include_series=True)
    series = result["trajectory"]
    assert len(series["t_min"]) == 241
    for branch in ("baseline", "treated"):
        assert round(np.mean(series[branch]["glucose"]), 1) == result[branch]["mean"]
        assert round(max(series[branch]["glucose"]), 1) == result[branch]["peak"]
    assert series["units"]["glucose"] == "mg/dL"


def test_run_identity_cannot_be_overwritten(tmp_path):
    store = ProtocolRunStore(tmp_path)
    run = {"run_id": "protocol-" + "b" * 32, "value": 1}
    store.save(run)
    assert store.save(deepcopy(run)) == run
    with pytest.raises(ValueError, match="immutable"):
        store.save({**run, "value": 2})
    assert store.get(run["run_id"])["value"] == 1


def test_notebook_includes_data_analysis_and_units():
    notebook = analysis_notebook({"protocol_id": "cendos.garcinoic-acid-pxr.v1",
        "evidence_state": "MODELED_TARGET_ENGAGEMENT", "qualification_state": "NOT_QUALIFIED",
        "target_engagement": []})
    source = "\n".join("".join(cell["source"]) for cell in notebook["cells"])
    assert "matplotlib" in source
    assert "concentration_um" in source
    assert "independent" in source.lower()
