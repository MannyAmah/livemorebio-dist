"""Actual local access records on private authored files, not physical evidence."""
import hashlib
import json
import os
from pathlib import Path
import stat

from fastapi.testclient import TestClient
import pytest

from livemorebio import audit

AUTH = {"Authorization": "Bearer authored-durable-reference-test"}
DIGEST = "bc5738721380320d37c216a8f4412ddd3f66fad375c60fc0d0626bc6c277e5d7"
PATHS = ["/api/structure?gene=KRAS", f"/api/molecular/structures/{DIGEST}/coordinates"]


@pytest.fixture
def durable_boundary(monkeypatch, tmp_path):
    from livemorebio.aegle import server
    monkeypatch.setenv("LIVEMORE_API_TOKEN", "authored-durable-reference-test")
    monkeypatch.setattr(server, "_ensure_selected_state", lambda: pytest.fail("Reference read selected a twin"))
    monkeypatch.setattr(server, "AegleTwin", lambda *a, **kw: pytest.fail("Reference read constructed biology"))
    monkeypatch.setattr(audit, "LM_DIR", str(tmp_path))
    monkeypatch.setattr(audit, "KEY_PATH", str(tmp_path / "authored-key"))
    monkeypatch.setattr(audit, "LOG_PATH", str(tmp_path / "access.jsonl"))
    monkeypatch.setattr(audit, "provenance", lambda: pytest.fail("Public reference requested Git or caller provenance"))
    return TestClient(server.app, raise_server_exceptions=False), Path(audit.KEY_PATH), Path(audit.LOG_PATH)


@pytest.mark.parametrize("path", PATHS)
def test_actual_signed_record_exists_before_successful_response(durable_boundary, path):
    client, key, log = durable_boundary
    response = client.get(path, headers=AUTH)
    assert response.status_code == 200
    rows = log.read_bytes().splitlines()
    assert len(rows) == 1
    receipt = json.loads(rows[0])
    assert audit.verify(receipt)
    assert receipt["action"] == "molecular.reference.read"
    assert receipt["inputs"] == {"operation": "metadata" if path == PATHS[0] else "coordinates", "asset_id": "4OBE"}
    assert receipt["outputs"] == {"outcome": "REFERENCE_AVAILABLE"}
    assert receipt["provenance"]["scope"] == "public_molecular_reference"
    assert len(key.read_bytes()) == 32
    if path == PATHS[1]:
        assert hashlib.sha256(response.content).hexdigest() == DIGEST


@pytest.mark.parametrize("path", PATHS)
def test_unauthorized_request_cannot_create_audit_files(durable_boundary, path):
    client, key, log = durable_boundary
    assert client.get(path).status_code == 401
    assert not key.exists() and not log.exists()


@pytest.mark.parametrize("path", PATHS)
@pytest.mark.parametrize("failure", ["file", "directory"])
def test_real_append_sync_failure_withholds_reference_without_retry(durable_boundary, monkeypatch, path, failure):
    client, key, log = durable_boundary
    key.write_bytes(b"authored-public-audit-key-32bytes")
    original = os.fsync
    def sync(fd):
        is_directory = stat.S_ISDIR(os.fstat(fd).st_mode)
        if is_directory == (failure == "directory"):
            raise OSError("AUTHORED_PRIVATE_FAILURE")
        return original(fd)
    monkeypatch.setattr(audit.os, "fsync", sync)
    response = client.get(path, headers=AUTH)
    assert response.status_code == 503
    assert response.json()["code"] == "MOLECULAR_AUDIT_UNAVAILABLE"
    assert "AUTHORED_PRIVATE" not in response.text and "data_4OBE" not in response.text
    rows = log.read_bytes().splitlines()
    assert len(rows) == 1 and audit.verify(json.loads(rows[0]))


def test_rejected_request_records_only_fixed_outcome(durable_boundary):
    client, key, log = durable_boundary
    response = client.get("/api/structure?gene=KRAS&private=AUTHORED_PRIVATE", headers=AUTH)
    assert response.status_code == 422
    raw = log.read_bytes()
    receipt = json.loads(raw)
    assert audit.verify(receipt)
    assert receipt["inputs"] == {"operation": "metadata", "asset_id": None}
    assert receipt["outputs"] == {"outcome": "MOLECULAR_INVALID_REQUEST"}
    assert b"AUTHORED_PRIVATE" not in raw
