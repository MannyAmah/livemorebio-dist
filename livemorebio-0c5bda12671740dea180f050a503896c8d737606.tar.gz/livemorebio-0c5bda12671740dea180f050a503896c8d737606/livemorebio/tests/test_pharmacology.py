"""Individualized pharmacology: same drug, different outcome by biology."""
from livemorebio.engines import pharmacology as PH
from livemorebio.engines.metabolic.glucose_insulin import T2D
from livemorebio.life_system.synthetic_human import SyntheticHuman
from livemorebio.aegle.runtime import AegleTwin


def test_oct1_genotype_changes_metformin_response():
    normal = SyntheticHuman("A", age=58, sex="M", conditions=["type 2 diabetes"], genome={})
    lof = SyntheticHuman("B", age=58, sex="M", conditions=["type 2 diabetes"], genome={"SLC22A1_lof": 2})
    _, why_n = PH.metformin(T2D, normal)
    _, why_l = PH.metformin(T2D, lof)
    assert why_n["oct1_transport"] == 1.0 and why_l["oct1_transport"] < 0.4
    assert why_n["realized_Si_gain_pct"] > 2 * why_l["realized_Si_gain_pct"]   # >2x weaker in LoF


def test_same_drug_different_glucose_outcome_on_twins():
    a = AegleTwin(human=SyntheticHuman("A", age=58, sex="M", conditions=["type 2 diabetes"], genome={}))
    b = AegleTwin(human=SyntheticHuman("B", age=58, sex="M", conditions=["type 2 diabetes"], genome={"SLC22A1_lof": 2}))
    a0, b0 = a.state()["metabolic"]["mean_glucose"], b.state()["metabolic"]["mean_glucose"]
    da = a0 - a.stimulate("metabolic_drug", name="metformin", dose=1.0)["metabolic"]["mean_glucose"]
    db = b0 - b.stimulate("metabolic_drug", name="metformin", dose=1.0)["metabolic"]["mean_glucose"]
    assert da > db > 0  # Direction follows modeled OCT1 exposure; this is not a validated magnitude.


def test_intervention_why_is_exposed_in_state():
    tw = AegleTwin(human=SyntheticHuman("C", age=60, sex="F", conditions=["type 2 diabetes"], genome={}))
    st = tw.stimulate("metabolic_drug", name="metformin", dose=1.0)
    assert st["intervention"]["drug"] == "metformin"
    assert "mechanism" in st["intervention"] and st["intervention"]["realized_Si_gain_pct"] > 0
