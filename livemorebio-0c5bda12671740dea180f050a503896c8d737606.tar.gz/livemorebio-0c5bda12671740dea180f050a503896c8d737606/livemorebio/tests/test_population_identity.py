"""Loaded code identity, not subsequently edited on-disk file identity."""
import pytest

from livemorebio.aegle import population_identity as identity
from livemorebio.aegle import population_records
from livemorebio.reference_cohort_contract import ensure_cohort_executable, ReferenceModelBindingRequired
from livemorebio.aegle.subjects import SubjectRegistry


def test_loaded_identity_is_stable_and_names_decoder(monkeypatch):
    value=identity.normalization_version()
    assert 'pandas-2.3.3' in value and 'sha256-' in value
    monkeypatch.setattr(population_records,'__file__','unrelated-file-that-is-not-the-loaded-code')
    assert identity.normalization_version()==value


def test_runtime_code_or_decoder_replacement_is_not_silently_same_identity(monkeypatch):
    with monkeypatch.context() as m:
        m.setattr(population_records,'_number',lambda value:0)
        with pytest.raises(identity.PopulationIdentityError):identity.normalization_version()


def test_entrypoint_defaults_and_order_are_loaded_identity_not_disk_names(monkeypatch):
    with monkeypatch.context() as m:
        m.setattr(identity.pd,'read_sas',lambda *args,**kwargs:None)
        with pytest.raises(identity.PopulationIdentityError):identity.normalization_version()
    with monkeypatch.context() as m:
        m.setattr(population_records,'_TABLE_NAMES',tuple(reversed(population_records._TABLE_NAMES)))
        with pytest.raises(identity.PopulationIdentityError):identity.normalization_version()
    with monkeypatch.context() as m:
        m.setattr(population_records.select_reference_members,'__kwdefaults__',{'require_nonpregnant':True})
        with pytest.raises(identity.PopulationIdentityError):identity.normalization_version()
    with monkeypatch.context() as m:
        m.setattr(identity.pd,'__version__','unreviewed-version')
        with pytest.raises(identity.PopulationIdentityError):identity.normalization_version()


@pytest.mark.parametrize('record',[
    {'source_class':'PUBLIC_REFERENCE','executable':True,'stratum':'dpp-high-risk-metabolic'},
    {'schema':'livemore.public-reference-cohort.v1','source_class':'REFERENCE_GROUNDED_SYNTHETIC'},
    {'generation_method':'joint_public_records_without_replacement'},
    {'source_id':'nhanes-2021-2023-joint-public-v1'},
    {'executable':False},
])
def test_all_direct_model_admission_paths_reject_before_accessing_missing_fields(record):
    for operation in (ensure_cohort_executable,SubjectRegistry.admitted_human,SubjectRegistry.build_twin):
        with pytest.raises(ReferenceModelBindingRequired) as error:operation(record)
        assert error.value.code=='REFERENCE_MODEL_BINDING_REQUIRED'


def test_legacy_contract_without_new_fields_is_not_retroactively_blocked():
    ensure_cohort_executable({'source_class':'REFERENCE_GROUNDED_SYNTHETIC','members':[{}]})


def test_untrusted_malformed_optional_schema_does_not_raise_untyped_exception():
    from livemorebio.reference_cohort_contract import is_public_reference
    assert not is_public_reference({'schema':[]})
    with pytest.raises(ReferenceModelBindingRequired):ensure_cohort_executable({'schema':[],'source_class':'PUBLIC_REFERENCE'})
