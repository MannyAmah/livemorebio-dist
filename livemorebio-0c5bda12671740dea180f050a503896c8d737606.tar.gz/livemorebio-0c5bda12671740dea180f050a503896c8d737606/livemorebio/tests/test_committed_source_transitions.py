"""Authored ASGI source-publication races; no participant, solver or real store."""
from copy import deepcopy
from contextlib import contextmanager
from types import SimpleNamespace
import threading
from uuid import UUID

import pytest

from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401


@pytest.fixture
def transition(client, monkeypatch):
    from livemorebio.aegle import server
    from livemorebio.aegle.execution_api import _creation_lock
    from livemorebio.aegle.model_contexts import model_availability
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.aegle.subjects import SubjectRegistryError

    calls = []
    scenario = {"outcome": "COMMITTED", "selected": True, "action": "activate"}
    old_state = server._state
    old_actions = [object()]
    old_observations = old_state["observation_state"]
    old_observations.observations["technical_old_subject_marker"] = {"data_class": "AUTHORED_TEST_ONLY"}
    # These successful numerical cases are authored software fixtures, not an
    # unbound REAL_HUMAN record made executable by a permissive build stub.
    old_state["subject"] = {
        **deepcopy(old_state["subject"]), "source_class": "SYNTHETIC",
        "display_label": "Authored technical source, not a participant",
        "selection_mode": "model", "demographics": {"age": 40, "sex": "female"},
        "conditions": [], "genome": {}, "lifestyle": 0.5,
    }
    target_before = deepcopy(old_state["subject"])
    target_after = {**target_before, "version": 3}
    original_values = {}
    active_guard = [None]
    committed_guard = [None]

    def assert_publication():
        from livemorebio.aegle.execution import DENY_ALL

        if scenario["outcome"] == "uncertain":
            assert authority.permitted_generation is DENY_ALL and manager.permitted is DENY_ALL
            return
        if scenario["action"] == "patches" and not scenario["selected"]:
            assert_original_source()
            assert authority.generation == manager.permitted == original_generation
            return
        assert manager.permitted == authority.generation != original_generation
        expected = None if scenario["action"] == "preview" else target_after
        summary = ({key: expected[key] for key in (
            "twin_id", "subject_id", "display_label", "source_class", "lifecycle", "version")}
            if expected else None)
        assert server._state["subject"] == summary
        assert server._state["model_availability"] == model_availability(
            expected, source_generation=authority.generation)
        if scenario["action"] == "patches":
            assert server._state["tw"] is original_values["twin"]
            assert server._state["observation_state"] is old_observations
            assert server._workspace_actions is old_actions
            assert tuple(old_actions) == original_values["action_contents"]
        else:
            assert server._state["tw"] is candidate
            assert server._state["observation_state"] is not old_observations
            assert server._state["observation_state"].observations == {}
            assert server._workspace_actions == [] and server._workspace_actions is not old_actions

    @contextmanager
    def publication_guard():
        with server._model_fence_guard():
            owner, prior = object(), active_guard[0]
            active_guard[0] = owner
            try:
                yield
            finally:
                try:
                    if committed_guard[0] is owner:
                        assert authority._lock._is_owned()
                        assert manager._lock._is_owned() and _creation_lock._is_owned()
                        assert_publication()
                finally:
                    active_guard[0] = prior

    def mark_committed():
        assert active_guard[0] is not None
        committed_guard[0] = active_guard[0]

    class Manager:
        _lock = threading.RLock()
        permitted = None

        def set_source_generation(self, generation):
            assert self._lock._is_owned() and _creation_lock._is_owned()
            self.permitted = generation

        def invalidate_source(self, generation, reason):
            assert not self._lock._is_owned()
            assert not _creation_lock._is_owned()
            assert not authority._lock._is_owned()
            assert generation == original_generation
            assert scenario["outcome"] == "uncertain" or scenario["action"] != "patches" or scenario["selected"]
            assert_publication()
            calls.append(("invalidate", generation))
            if scenario["outcome"] == "invalidate_failure":
                raise OSError("authored cleanup failure")

    manager = Manager()
    monkeypatch.setattr(server, "_execution_manager_instance", manager)
    authority = ModelSourceAuthority(server._invalidate_model_source,
        fence=server._assign_model_fence, fence_guard=publication_guard)
    original_generation = authority.generation
    manager.permitted = original_generation
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_workspace_actions", old_actions)
    old_state["model_availability"] = model_availability(
        old_state["subject"], source_generation=original_generation)

    def unlocked():
        assert not authority._lock._is_owned()
        assert not manager._lock._is_owned()
        assert not _creation_lock._is_owned()

    def projected_state(label):
        unlocked()
        calls.append(("state", label))
        return {"technical": label, "profile_params": {"technical": label}}

    old_twin = SimpleNamespace(
        state=lambda: projected_state("old-model"),
        patch={
            "connected": False, "source": None, "mode": None,
            "hardware_present": False, "protocol_version": None,
            "sequence": None, "envelope_id": None, "device_id": None,
        },
        observations={},
    )
    candidate = SimpleNamespace(state=lambda: projected_state("new-model"))
    old_state["tw"] = old_twin

    def freeze_original_values():
        original_values.update(twin=old_state["tw"],
            subject=deepcopy(old_state["subject"]),
            availability=deepcopy(old_state["model_availability"]),
            action_contents=tuple(old_actions))

    def assert_original_source():
        assert server._state is old_state and server._workspace_actions is old_actions
        assert old_state["tw"] is original_values["twin"]
        assert old_state["subject"] == original_values["subject"]
        assert old_state["model_availability"] == original_values["availability"]
        assert tuple(old_actions) == original_values["action_contents"]
        assert old_state["observation_state"] is old_observations

    freeze_original_values()

    def prepare(identifier, *, expected_version, request_id, binding=None):
        assert authority._lock._is_owned()
        assert not manager._lock._is_owned() and not _creation_lock._is_owned()
        assert_original_source()
        assert identifier == target_before["twin_id"] and expected_version == 2
        UUID(request_id)
        calls.append(("prepare", identifier))
        if scenario["outcome"] == "prepare_failure":
            raise SubjectRegistryError("TWIN_VERSION_CONFLICT", "Authored rejected preparation")
        if scenario["outcome"] == "prepare_audit_uncertain":
            from livemorebio.aegle.subjects import _transition_error

            scenario["prepared_request_id"] = request_id
            raise _transition_error("SELECTION_COMMIT_UNCONFIRMED")
        if scenario["outcome"] == "new_observation":
            # Authored already-attached evidence marker; this tests retention,
            # not physical packet admission or numerical physiology.
            old_observations.observations["technical_packet_marker"] = {
                "value": 1, "data_class": "AUTHORED_TEST_ONLY"}
        return SimpleNamespace(kind="bind" if binding is not None else "activate",
            record=deepcopy(target_after), target_before=deepcopy(target_before),
            active_before=deepcopy(old_state["subject"]),
            active_after=deepcopy(target_after if binding is None or scenario["selected"] else old_state["subject"]),
            selected=scenario["selected"], request_id=request_id)

    class Registry:
        def prepare_activation(self, identifier, *, expected_version, request_id):
            return prepare(identifier, expected_version=expected_version, request_id=request_id)

        def prepare_patch_binding(self, identifier, body, *, expected_version, request_id):
            return prepare(identifier, expected_version=expected_version, request_id=request_id,
                           binding=body)

        def build_twin(self, record):
            unlocked()
            assert record == target_after
            assert type(record["lifestyle"]) is float and record["lifestyle"] == 0.5
            calls.append(("build", record["twin_id"]))
            if scenario["action"] == "patches":
                pytest.fail("Binding reconstructed the selected model")
            if scenario["outcome"] == "build_failure":
                from livemorebio.aegle.model_contexts import ModelContextError
                raise ModelContextError("MODEL_BINDING_REQUIRED")
            if scenario["outcome"] == "changed_generation":
                with authority.commit_guard():
                    authority.install_generation("technical-later-operator-generation")
            return candidate

        def commit_prepared_transition(self, prepared):
            assert manager._lock._is_owned() and _creation_lock._is_owned()
            assert authority._lock._is_owned()
            assert authority.generation == original_generation
            assert_original_source()
            calls.append(("commit", prepared.kind))
            if scenario["outcome"] != "rollback":
                mark_committed()
            if scenario["outcome"] in {"rollback", "uncertain"}:
                code = "SELECTION_COMMIT_UNCONFIRMED" if scenario["outcome"] == "uncertain" else "TWIN_VERSION_CONFLICT"
                raise SubjectRegistryError(code, "Authored transition outcome")
            return "COMMITTED_CLEANUP_UNCONFIRMED" if scenario["outcome"] == "close_failure" else "COMMITTED"

    registry = Registry()

    def get_registry():
        unlocked()
        return registry

    def publish(*args, **kwargs):
        unlocked()
        calls.append(("publish", None))

    monkeypatch.setattr(server, "_subject_registry", get_registry)
    monkeypatch.setattr(server, "_snapshot_twin", publish)
    return SimpleNamespace(client=client, server=server, scenario=scenario, calls=calls,
        target_before=target_before, target_after=target_after, candidate=candidate,
        old_state=old_state, old_actions=old_actions, old_observations=old_observations,
        old_twin=old_twin, original_values=original_values,
        freeze_original_values=freeze_original_values, assert_original_source=assert_original_source,
        mark_committed=mark_committed,
        authority=authority, manager=manager, original_generation=original_generation)


def post(t, action):
    t.scenario["action"] = action
    payload = {"expected_version": 2}
    if action == "patches":
        payload.update(device_id="technical-unregistered-device", mode="virtual",
                       protocol_version="3.0", firmware_version="virtual-execution-v1")
    return t.client.post(f"/api/twins/{t.target_before['twin_id']}/{action}", json=payload)


@pytest.mark.parametrize("action,selected", [("activate", True), ("patches", True), ("patches", False)])
def test_preparation_audit_uncertainty_is503_without_source_mutation(transition, action, selected):
    t = transition
    t.scenario.update(outcome="prepare_audit_uncertain", selected=selected)
    response = post(t, action)
    assert response.status_code == 503
    assert response.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
    assert response.headers["X-Request-ID"] == t.scenario["prepared_request_id"]
    assert str(UUID(response.headers["X-Request-ID"])) == response.headers["X-Request-ID"]
    assert "no-store" in response.headers["Cache-Control"]
    assert t.calls == [("prepare", t.target_before["twin_id"])]
    t.assert_original_source()
    assert t.authority.generation == t.authority.permitted_generation == t.original_generation
    assert t.manager.permitted == t.original_generation


@pytest.mark.parametrize("action", ["activate", "patches"])
@pytest.mark.parametrize("outcome", ["COMMITTED", "close_failure", "invalidate_failure",
                                      "prepare_failure", "rollback", "uncertain"])
def test_source_publication_follows_confirmed_commit_and_cleanup_is_outside_locks(transition, action, outcome):
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.model_contexts import model_availability

    t = transition
    t.scenario["outcome"] = outcome
    result = post(t, action)
    if outcome in {"prepare_failure", "rollback"}:
        assert result.status_code == 409
        t.assert_original_source()
        assert t.authority.generation == t.original_generation == t.manager.permitted
        assert not any(name in {"invalidate", "publish"} for name, _ in t.calls)
        if outcome == "prepare_failure":
            assert not any(name in {"build", "commit"} for name, _ in t.calls)
    elif outcome == "uncertain":
        assert result.status_code == 503 and result.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
        assert t.authority.permitted_generation is DENY_ALL and t.manager.permitted is DENY_ALL
        assert [value for name, value in t.calls if name == "invalidate"] == [t.original_generation]
    else:
        assert result.status_code == (200 if outcome == "COMMITTED" else 503)
        if outcome != "COMMITTED":
            assert result.json()["code"] == "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
        assert t.authority.generation != t.original_generation
        assert t.manager.permitted == t.authority.generation
        assert t.server._state["subject"]["version"] == 3
        assert t.server._state["model_availability"] == model_availability(
            t.target_after, source_generation=t.authority.generation)
        assert [name for name, _ in t.calls].count("commit") == 1
        assert [value for name, value in t.calls if name == "invalidate"] == [t.original_generation]
        if action == "activate":
            assert t.server._state["tw"] is t.candidate
            assert t.server._state["subject"] == {key: t.target_after[key] for key in (
                "twin_id", "subject_id", "display_label", "source_class", "lifecycle", "version")}
            assert t.server._state["observation_state"] is not t.old_observations
            assert t.server._state["observation_state"].observations == {}
            assert t.server._workspace_actions == [] and t.server._workspace_actions is not t.old_actions
            assert t.calls.index(("prepare", t.target_before["twin_id"])) < t.calls.index(
                ("build", t.target_before["twin_id"])) < t.calls.index(("state", "new-model"))
            assert t.calls.index(("state", "new-model")) < t.calls.index(("commit", "activate"))
        else:
            assert t.server._state["tw"] is t.old_twin
            assert t.server._state["observation_state"] is t.old_observations
            assert t.server._workspace_actions is t.old_actions
            assert tuple(t.old_actions) == t.original_values["action_contents"]


def test_activation_of_a_different_target_does_not_use_binding_selected_flag(transition):
    t = transition
    t.scenario["selected"] = False
    t.target_before.update(twin_id="twin-technical-different", subject_id="technical-different-not-a-person",
                           lifecycle="DATA_ADMITTED")
    t.target_after.update(twin_id="twin-technical-different", subject_id="technical-different-not-a-person",
                          lifecycle="ACTIVE")
    # Reuse the complete success assertions; the cleanup callback independently
    # checks the installed identity and fresh holders at cleanup entry as well.
    test_source_publication_follows_confirmed_commit_and_cleanup_is_outside_locks(t, "activate", "COMMITTED")


@pytest.mark.parametrize("outcome", ["COMMITTED", "close_failure", "rollback"])
def test_unselected_virtual_binding_does_not_replace_active_source(transition, outcome):
    t = transition
    t.scenario.update(selected=False, outcome=outcome)
    t.target_before.update(twin_id="twin-technical-other", lifecycle="DATA_ADMITTED")
    t.target_after.update(twin_id="twin-technical-other", lifecycle="DATA_ADMITTED")
    result = post(t, "patches")
    assert result.status_code == {"COMMITTED": 200, "close_failure": 503, "rollback": 409}[outcome]
    t.assert_original_source()
    assert t.authority.generation == t.original_generation == t.manager.permitted
    assert not any(name in {"build", "invalidate", "publish"} for name, _ in t.calls)


def test_selected_binding_keeps_observations_admitted_during_preparation(transition):
    t = transition
    t.scenario["outcome"] = "new_observation"
    assert post(t, "patches").status_code == 200
    assert t.server._state["observation_state"] is t.old_observations
    assert t.server._state["observation_state"].observations["technical_packet_marker"] == {
        "value": 1, "data_class": "AUTHORED_TEST_ONLY"}


def test_selected_observation_only_binding_stays_modeless(transition):
    from livemorebio.aegle.model_contexts import model_availability

    t = transition
    for record in (t.old_state["subject"], t.target_before, t.target_after):
        record.update(source_class="REAL_HUMAN", selection_mode="observations_only")
    t.old_state["tw"] = None
    t.old_state["model_availability"] = model_availability(
        t.old_state["subject"], source_generation=t.original_generation)
    t.freeze_original_values()
    assert t.old_state["model_availability"]["reason_code"] == "MODEL_BINDING_REQUIRED"
    assert post(t, "patches").status_code == 200
    assert t.server._state["tw"] is None
    assert t.server._state["observation_state"] is t.old_observations
    assert t.server._workspace_actions is t.old_actions
    assert tuple(t.old_actions) == t.original_values["action_contents"]
    expected = model_availability(t.target_after, source_generation=t.authority.generation)
    assert t.server._state["model_availability"] == expected
    assert expected["state"] == "UNAVAILABLE" and expected["reason_code"] == "MODEL_BINDING_REQUIRED"
    assert t.authority.generation != t.original_generation
    assert t.manager.permitted == t.authority.generation
    assert [value for name, value in t.calls if name == "invalidate"] == [t.original_generation]
    assert not any(name in {"build", "state"} for name, _ in t.calls)


@pytest.mark.parametrize("outcome", ["build_failure", "changed_generation"])
def test_activation_rejects_failed_or_stale_candidate_before_commit(transition, outcome):
    t = transition
    t.scenario["outcome"] = outcome
    response = post(t, "activate")
    assert response.status_code == 409
    assert not any(name in {"commit", "invalidate", "publish"} for name, _ in t.calls)
    t.assert_original_source()
    assert t.authority.generation == (t.original_generation if outcome == "build_failure"
                                    else "technical-later-operator-generation")
