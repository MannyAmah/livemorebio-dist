"""Technical rerun requests prove indirect registry failures keep their type."""
from types import SimpleNamespace

import pytest

from livemorebio.aegle import server
from livemorebio.aegle.registry_bootstrap import RegistryBootstrapError
from livemorebio.tests.test_security_registry_http import bootstrap_client


@pytest.mark.parametrize("code", ["REGISTRY_STORAGE_UNAVAILABLE", "REGISTRY_BOOTSTRAP_INVALID"])
@pytest.mark.parametrize("protocol,spec", [
    ("human-gem-oxygen-capacity", {"conditions": [
        {"condition_id": "technical-condition", "glucose_uptake": 1, "oxygen_uptake": 1},
    ]}),
    ("lobeline-vmat2", {"material_id": "lobeline-hemisulfate",
                        "context_id": "rat-striatal-synaptic-vesicles",
                        "concentration_unit": "uM", "substrate_concentrations": [0, 0.1],
                        "inhibitor_concentrations": [0, 0.25]}),
    ("exogenous-insulin", {"label": "technical-storage-refusal"}),
    ("botanical-exposure", {"program_id": "LBHR-172", "label": "technical-storage-refusal"}),
])
def test_registry_bootstrap_refusal_from_protocol_rerun_is_typed_503(
        bootstrap_client, monkeypatch, protocol, spec, code):
    client, configure = bootstrap_client
    attempts = configure(code)

    def validate_rerun(parent_run_id, configuration, resolve_cohort, **options):
        assert parent_run_id == "technical-parent-run"
        assert isinstance(configuration, dict)
        return resolve_cohort("technical-cohort")

    monkeypatch.setattr(server, "_protocol_run_store", lambda: SimpleNamespace(validate_rerun=validate_rerun))
    response = client.post("/api/cendos/protocols/" + protocol,
                           json={**spec, "parent_run_id": "technical-parent-run"}, headers={
                               "Authorization": "Bearer technical-bootstrap-http-token",
                           })
    assert attempts, "valid technical rerun must reach registry construction"
    assert response.status_code == 503, response.text
    assert response.json()["code"] == code
    assert response.json()["error"] == str(RegistryBootstrapError(code))
    assert response.headers["Cache-Control"] == "no-store"
