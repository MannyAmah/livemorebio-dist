"""L0-R15's minor walk findings L0W-3 to L0W-7; technical fixtures only, no service or person.

- L0W-3: the main workspace shows ``CARDIAC_MODEL_NOT_INSTALLED`` when a cardiac action is refused.
- L0W-4: ``livemore doctor`` prints the endpoints it actually checks.
- L0W-5: ``livemore notebook`` flushes its address and one-time code at once.
- L0W-6: a refused notebook start prints its reason.
- L0W-7: the text output of ``programs run`` names the missing measurement.
"""
from __future__ import annotations

import io
import json
from pathlib import Path
import sys

import pytest

CONSOLE = Path(__file__).parents[1] / "aegle/console"


# ---------------------------------------------------------------- L0W-3

def test_shared_post_keeps_the_services_refusal_code():
    from .test_clinical_model_availability_ui import node

    node(f"""
import assert from 'node:assert/strict';
import {{postJSON}} from {json.dumps((CONSOLE / "lib/core.js").as_uri())};
globalThis.fetch=async()=>({{ok:false,status:422,statusText:'Unprocessable Entity',
  json:async()=>({{error:'biological action could not be completed',code:'CARDIAC_MODEL_NOT_INSTALLED'}})}});
await assert.rejects(postJSON('/api/workspace/actions',{{kind:'cardiac_drug'}}),
  e=>e.code==='CARDIAC_MODEL_NOT_INSTALLED'&&e.message==='biological action could not be completed');
globalThis.fetch=async()=>({{ok:false,status:422,statusText:'Unprocessable Entity',json:async()=>({{error:'x',code:'<b>not a code</b>'}})}});
await assert.rejects(postJSON('/api/x',{{}}),e=>e.code===undefined);
""", module=True)


def test_workspace_action_failure_shows_the_refusal_code():
    from .test_workspace_stream_ui import javascript

    javascript(r'''
const a=require('node:assert/strict'),vm=require('node:vm'),nodes=new Map();const banners=[];
function el(id){if(!nodes.has(id))nodes.set(id,{id,textContent:'',innerHTML:'',hidden:false,dataset:{},attrs:{},
 classList:{toggle(){}},setAttribute(k,v){this.attrs[k]=v},after(x){nodes.set('#'+x.id,x)}});return nodes.get(id)}
const context={document:{body:{dataset:{},setAttribute(){}},querySelector:s=>el(s),querySelectorAll:()=>[],
 createElement:()=>({textContent:'',attrs:{},setAttribute(k,v){this.attrs[k]=v}})},URLSearchParams,Date,
 banner:(text)=>banners.push(text),clearBanner(){},clearInterval(){},setTimeout:f=>{f();return 0},
 getJSON:async()=>fixture(),
 postJSON:async()=>{throw Object.assign(new Error('biological action could not be completed'),{code:'CARDIAC_MODEL_NOT_INSTALLED'})}};
(async()=>{vm.runInNewContext(PROJECTIONS+'\n'+CONTROLLER,context);
vm.runInNewContext('renderWorkspace=()=>{};renderTimeline=()=>{};',context);
await vm.runInNewContext('refresh()',context);
await vm.runInNewContext('runAction("cardiac_drug",{ikr_block:.5})',context);
a.match(el('#action-detail').textContent,/cardiac_drug failed · CARDIAC_MODEL_NOT_INSTALLED/);
a(banners.some(text=>/CARDIAC_MODEL_NOT_INSTALLED/.test(text)&&/could not be completed/.test(text)),banners.join(' | '));
})().catch(error=>{console.error(error);process.exitCode=1});
''')


# ---------------------------------------------------------------- L0W-4

def test_doctor_names_the_endpoint_it_checked(monkeypatch):
    from livemorebio import cli, doctor

    checked = []
    monkeypatch.setattr(cli, "_client_health", lambda port: checked.append(cli._service_url(
        next(name for name, (_, service_port) in cli.SERVICES.items() if service_port == port))) or None)
    for name, port in (("AEGLE", 24101), ("LIFE", 24102), ("CENDOS", 24103)):
        monkeypatch.setenv(f"LIVEMORE_{name}_URL", f"http://127.0.0.1:{port}")
    services = doctor._services()
    endpoints = {item["service"]: item["endpoint"] for item in services}
    assert endpoints == {"Aegle": "http://127.0.0.1:24101", "LIFE": "http://127.0.0.1:24102",
                         "Cendos": "http://127.0.0.1:24103"}
    assert sorted(checked) == sorted(endpoints.values())
    text = doctor.render({"platform": {}, "python": {"ok": True, "version": "3", "executable": "python"},
                          "required_modules": [], "kernel_modules": [], "notebook_modules": [],
                          "insulin_engine": {"ok": True}, "human_gem_assets": {"available": False},
                          "node": {"ok": False, "path": None}, "cardiac": {}, "cardiac_assets": {},
                          "playwright": {"ok": False, "module": None},
                          "data_dir": {"exists": False, "path": "technical"}, "services": services,
                          "network": "not checked", "required_ok": True})
    lines = [line for line in text.splitlines() if " service " in line]
    assert len(lines) == 3
    for line in lines:
        assert ":885" not in line, line
    assert any("http://127.0.0.1:24101" in line and "Aegle" in line for line in lines), lines


# ---------------------------------------------------------------- L0W-5

class _Recorder(io.StringIO):
    def __init__(self):
        super().__init__()
        self.events = []

    def write(self, text):
        self.events.append(("write", text))
        return super().write(text)

    def flush(self):
        self.events.append(("flush", None))


def test_notebook_address_and_code_are_flushed_as_printed(monkeypatch):
    from livemorebio import notebook_launch

    recorder = _Recorder()
    monkeypatch.setattr(sys, "stdout", recorder)
    notebook_launch._instructions(24110, "TECHNICAL0CODE00")
    written = "".join(text for kind, text in recorder.events if kind == "write")
    assert "http://127.0.0.1:24110/login" in written and "TECHNICAL0CODE00" in written
    # Nothing printed may wait in a pipe's buffer: the last event is a flush.
    assert recorder.events[-1] == ("flush", None)
    code_line = max(index for index, (kind, text) in enumerate(recorder.events)
                    if kind == "write" and "TECHNICAL0CODE00" in text)
    assert ("flush", None) in recorder.events[code_line:]


def test_cli_notebook_banner_is_flushed_before_jupyter_starts(monkeypatch, tmp_path):
    from livemorebio import cli, notebook, notebook_launch

    recorder = _Recorder()
    flushed_before_launch = []
    monkeypatch.setattr(sys, "stdout", recorder)
    monkeypatch.setattr(cli.R, "REG_DIR", str(tmp_path / "technical-stack"))
    monkeypatch.setattr(notebook, "ensure_workspace", lambda directory: Path(directory) / "technical.ipynb")
    monkeypatch.setattr(notebook_launch, "run_notebook", lambda *a, **k: flushed_before_launch.append(
        recorder.events[-1] == ("flush", None)) or 0)
    monkeypatch.setattr(sys, "argv", ["livemore", "notebook", "--no-browser", "--port", "24111"])
    with pytest.raises(SystemExit):
        cli.main()
    assert flushed_before_launch == [True]


# ---------------------------------------------------------------- L0W-6

class _UnadmittedChild:
    pid = 98766
    returncode = None

    def __init__(self, code):
        self.stdout, self.stderr = io.BytesIO(b"technical"), io.BytesIO(b"technical refusal")
        self.code, self.signals = code, []

    def send_signal(self, signum):
        self.signals.append(signum)

    def poll(self):
        return self.returncode

    def wait(self, timeout=None):
        self.returncode = self.code
        return self.code


@pytest.mark.parametrize("code", [1, 0])
def test_a_refused_notebook_start_prints_its_reason(tmp_path, monkeypatch, capsys, code):
    from livemorebio import notebook_launch as launch

    monkeypatch.setenv("HOME", str(tmp_path / "technical-home"))
    monkeypatch.setattr(launch, "process_identity", lambda pid: f"technical-birth-{pid}")
    monkeypatch.setattr(launch, "wait_for_ready", lambda runtime, child: child.wait() is None)
    monkeypatch.setattr(launch.subprocess, "Popen", lambda *a, **k: _UnadmittedChild(code))
    status = launch.run_notebook(tmp_path / "technical-stack", tmp_path / "technical-workspace",
                                 tmp_path / "technical.ipynb", port=24112, no_browser=True)
    assert status != 0
    output = capsys.readouterr()
    assert "NOTEBOOK_NOT_ADMITTED" in output.err, output.err
    assert "nothing was served" in output.err and "jupyter --paths" in output.err
    assert "One-time code" not in output.out


def test_a_notebook_start_on_a_busy_port_says_the_port_is_in_use(tmp_path, monkeypatch, capsys):
    """Round 1: when Jupyter stops because another program holds the port, the reason names the port."""
    import socket

    from livemorebio import notebook_launch as launch

    monkeypatch.setenv("HOME", str(tmp_path / "technical-home"))
    monkeypatch.setattr(launch, "process_identity", lambda pid: f"technical-birth-{pid}")
    monkeypatch.setattr(launch, "wait_for_ready", lambda runtime, child: child.wait() is None)
    monkeypatch.setattr(launch.subprocess, "Popen", lambda *a, **k: _UnadmittedChild(1))
    holder = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        holder.bind(("127.0.0.1", 0))
        holder.listen(1)
        port = holder.getsockname()[1]
        status = launch.run_notebook(tmp_path / "technical-stack", tmp_path / "technical-workspace",
                                     tmp_path / "technical.ipynb", port=port, no_browser=True)
    finally:
        holder.close()
    assert status != 0
    error = capsys.readouterr().err
    assert "NOTEBOOK_PORT_IN_USE" in error and f"port {port}" in error and "already in use" in error, error
    assert "ambient Jupyter configuration" not in error, error


# ---------------------------------------------------------------- L0W-7

def test_program_run_text_names_the_missing_active_range():
    from livemorebio.shell import run_command

    class Client:
        mode = "inprocess"

        def run_botanical_program(self, spec):
            return {"run_id": "technical-run", "program": {"program_id": spec["program_id"]},
                    "outcome": "EXPOSURE_ONLY", "reason_code": "ACTIVE_RANGE_NOT_ADMITTED",
                    "human_exposure_admissible": False, "controls": [{"passed": True}],
                    "missing_measurement": None,
                    "active_range_missing": "A measured concentration-response for the technical mechanism"}

    output = []
    run_command(Client(), "program run LBHR-172", out=output.append)
    text = "\n".join(output)
    assert "ACTIVE_RANGE_NOT_ADMITTED" in text
    assert "A measured concentration-response for the technical mechanism" in text
