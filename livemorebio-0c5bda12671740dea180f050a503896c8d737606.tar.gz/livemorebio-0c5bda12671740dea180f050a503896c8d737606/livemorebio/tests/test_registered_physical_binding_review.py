"""Independent persisted-history and redundant-lineage probes; no hardware proof."""
from copy import deepcopy

import pytest

from livemorebio.aegle.subjects import SubjectRegistryError
from livemorebio.tests.clinical_registry_fixtures import replace_fixture_record
from livemorebio.tests.test_registered_physical_v3_binding import (
    core, no_network_or_models, predicate, prepare, rows,
)


def test_revoked_current_scope_preserves_history_but_cannot_admit_binding(core):
    t = core
    p = prepare(t)
    assert t.registry.commit_prepared_transition(p) == "COMMITTED"
    changed = deepcopy(p.record)
    changed["consent_scope"].remove("life_patch")
    replace_fixture_record(t.registry, changed)
    before = rows(t.registry)
    inspected = t.registry.get_twin(t.target["twin_id"])
    assert inspected == changed
    assert inspected["patch_bindings"] == p.record["patch_bindings"]
    with pytest.raises(ValueError):
        predicate(inspected, t.inspection)
    assert rows(t.registry) == before


@pytest.mark.parametrize("field,value", [
    ("firmware_version", "unregistered-firmware"),
    ("hardware_present", 1),
    ("configuration_id", "unregistered-configuration"),
])
def test_unchanged_manifest_cannot_hide_tampered_redundant_binding_fields(core, field, value):
    t = core
    p = prepare(t)
    assert t.registry.commit_prepared_transition(p) == "COMMITTED"
    changed = deepcopy(p.record)
    changed["patch_bindings"][-1][field] = value
    replace_fixture_record(t.registry, changed)
    before = rows(t.registry)
    with pytest.raises(SubjectRegistryError) as caught:
        t.registry.get_twin(t.target["twin_id"])
    assert caught.value.code == "REGISTRY_STORAGE_UNAVAILABLE"
    with pytest.raises(ValueError):
        predicate(changed, t.inspection)
    assert rows(t.registry) == before
