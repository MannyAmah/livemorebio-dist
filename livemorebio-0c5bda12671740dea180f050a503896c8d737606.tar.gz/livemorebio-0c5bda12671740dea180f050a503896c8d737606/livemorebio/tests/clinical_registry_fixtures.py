"""Authored software fixtures, never clinical evidence or operational records.

The historical record is constructed from the frozen v1 field contract, not by
calling the removed clinical compiler. Every store lives below pytest tmp_path.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import sqlite3
from typing import Any

KEY = b"r" * 32  # Public, deliberately fixed test-only encryption key.
CAPTURED = "2026-08-30T12:00:00Z"
TWIN_FIELDS = (
    "source_class", "subject_id", "display_label", "consent_scope", "chain_of_custody",
    "demographics", "conditions", "medications", "genome", "lifestyle", "lifestyle_profile",
    "environment", "observations", "model_parameters", "profile_sources", "profile_coverage",
    "field_provenance", "reference_source", "reference_stratum", "reference_lineage", "generation_seed",
)
COHORT_FIELDS = ("source_class", "name", "size", "seed", "indication", "member_twin_ids", "stratum", "reference_source")
EVIDENCE_FIELDS = (
    "source_class", "subject_id", "consent_scope", "chain_of_custody", "demographics", "conditions",
    "medications", "genome", "lifestyle", "lifestyle_profile", "environment", "observations",
    "model_parameters", "profile_sources", "profile_coverage", "field_provenance",
)


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha(value: Any, prefix: bytes = b"") -> str:
    return hashlib.sha256(prefix + canonical(value)).hexdigest()


def human_payload(suffix: str = "one", condition: str = "type 1 diabetes") -> dict[str, Any]:
    return {
        "source_class": "REAL_HUMAN", "subject_id": f"pseudonym-technical-{suffix}",
        "display_label": f"Authored software fixture {suffix}",
        "consent_scope": ["digital_twin", "cendos_validation"],
        "chain_of_custody": "urn:test:authored-fixture:not-a-clinical-record",
        "demographics": {"age": 40, "sex": "F"}, "conditions": [condition] if condition else [],
        "medications": [], "genome": {}, "lifestyle": 0.6, "environment": {},
        "model_parameters": {},
        "observations": {"glucose_mgdl": {
            "value": 100.0, "unit": "mg/dL", "captured_at": CAPTURED,
            "source": "authored-software-fixture", "quality_status": "verified", "sampling_context": "fasting",
        }},
        "profile_sources": [{
            "source_id": "authored-software-fixture", "kind": "FHIR_R4", "system": "not-a-real-ehr",
            "release": "technical-v1", "captured_at": CAPTURED, "provenance_uri": "urn:test:fixture",
            "quality_status": "verified", "domains": ["conditions", "demographics", "labs", "physiology"],
        }],
    }


def legacy_twin_record(suffix: str = "one", *, version: int = 1) -> dict[str, Any]:
    record = deepcopy(human_payload(suffix))
    record["observations"]["glucose_mgdl"].update(original_value=100.0, original_unit="mg/dL", mapping_eligible=True)
    record.update(
        lifestyle_profile={"activity_index": 0.6}, reference_source=None, reference_stratum=None,
        reference_lineage=None, generation_seed=None,
        profile_coverage={
            "status": "ADMITTED_PARTIAL", "domains": ["conditions", "demographics", "labs", "physiology"],
            "declared_domains": ["conditions", "demographics", "labs", "physiology"],
            "actual_domains": ["conditions", "demographics", "genomics", "labs", "lifestyle", "medications", "physiology"],
            "missing_core_domains": ["environment", "genomics", "lifestyle", "medications"], "source_count": 1,
        },
        field_provenance={
            **{name: {"source_id": "authored-software-fixture", "evidence_class": "MEASURED_CLINICAL"}
               for name in ("demographics.age", "demographics.sex", "conditions.0", "observations.glucose_mgdl")},
            "lifestyle": {"source_id": "unresolved", "evidence_class": "SOURCE_UNRESOLVED"},
        },
        parameter_provenance={"fixture": {"evidence_class": "HISTORICAL_TEST_ONLY", "value": 12}},
        schema="livemore.twin-record.v1", twin_id=f"twin-fixture-{suffix}", lifecycle="DATA_ADMITTED",
        version=version, created_at=CAPTURED, updated_at=CAPTURED, patch_bindings=[],
    )
    return record


def legacy_cohort_record(ids: list[str]) -> dict[str, Any]:
    return {
        "schema": "livemore.cohort-record.v1", "cohort_id": "cohort-legacy-fixture",
        "source_class": "REAL_HUMAN", "name": "Authored legacy cohort", "size": len(ids), "seed": 0,
        "indication": "not-an-inferred-model", "member_twin_ids": ids, "stratum": None, "reference_source": None,
        "member_fingerprints": [], "members": [], "heterogeneity": None, "lifecycle": "FROZEN", "version": 1,
        "created_at": CAPTURED, "updated_at": CAPTURED,
    }


def historical_intent(record: dict[str, Any]) -> dict[str, Any]:
    fields = TWIN_FIELDS if "twin_id" in record else COHORT_FIELDS
    return deepcopy({key: record[key] for key in fields})


def seed_legacy(registry: Any, record: dict[str, Any], key: str | None = None) -> None:
    """Install a historical technical payload without invoking any intake code."""
    twin = "twin_id" in record
    intent = historical_intent(record)
    if twin:
        intent["parameter_provenance"] = record["parameter_provenance"]
    registry._insert("TWIN" if twin else "COHORT", deepcopy(record), sha(intent), key)


def replace_fixture_record(registry: Any, record: dict[str, Any]) -> None:
    """Explicit test-only authenticated lifecycle/evidence edit, not a public API."""
    record_id = record.get("twin_id", record.get("cohort_id"))
    nonce, ciphertext = registry._seal(record_id, record)
    with registry._connect() as connection:
        connection.execute("UPDATE records SET lifecycle=?,version=?,updated_at=?,nonce=?,ciphertext=? WHERE record_id=?",
                           (record["lifecycle"], record["version"], record["updated_at"], nonce, ciphertext, record_id))


def saved_bytes(registry: Any, record_id: str) -> tuple[Any, ...]:
    with sqlite3.connect(registry.path) as connection:
        row = connection.execute("SELECT version,nonce,ciphertext,request_hash,idempotency_key FROM records WHERE record_id=?",
                                 (record_id,)).fetchone()
    assert row is not None
    return tuple(row)


def record_count(registry: Any, kind: str = "TWIN") -> int:
    with sqlite3.connect(registry.path) as connection:
        return connection.execute("SELECT COUNT(*) FROM records WHERE record_type=?", (kind,)).fetchone()[0]


def forbid_compilation(monkeypatch: Any) -> None:
    from livemorebio.aegle import clinical_parameters, subjects

    def forbidden(*args: Any, **kwargs: Any) -> Any:
        raise AssertionError("No clinical compiler, template or numerical constructor may run in descriptive admission")

    monkeypatch.setattr(clinical_parameters, "initialize_profile", forbidden)
    monkeypatch.setattr(subjects.SubjectRegistry, "admitted_human", forbidden)
    monkeypatch.setattr(subjects.SubjectRegistry, "build_twin", forbidden)
    monkeypatch.setattr(subjects, "generate_members", forbidden)
