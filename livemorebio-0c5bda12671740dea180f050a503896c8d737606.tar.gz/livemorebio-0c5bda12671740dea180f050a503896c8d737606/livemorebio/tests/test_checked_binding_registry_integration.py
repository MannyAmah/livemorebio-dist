"""Actual encrypted binding commits; authored private records and inert models only.

Protected decisions are never stubbed. Faults change only acknowledgments on a
delegated real connection. Corrupted receipts remain corrupted, not repaired.
"""
from contextlib import closing
from copy import deepcopy
import base64
import json
import sqlite3
from types import SimpleNamespace
from uuid import UUID

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import pytest

from livemorebio.tests.clinical_registry_fixtures import KEY, replace_fixture_record
from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401
from livemorebio.tests.test_committed_registry_transitions import physical_body, rows, seed
from livemorebio.tests.test_checked_startup_registry_integration import audit_rows, reservations


def forbidden(*args, **kwargs):
    pytest.fail("Binding integration attempted a model or execution-store operation")


def decode_audit(row):
    identifier, _sequence, nonce, encrypted = row
    return json.loads(AESGCM(KEY).decrypt(nonce, encrypted,
        b"livemore.subject-registry.audit.v1\0" + identifier.encode("ascii")))


def decode_record(row):
    # Match the original immutable record AAD, without an extra audited getter.
    return json.loads(AESGCM(KEY).decrypt(row[9], row[10],
        b"livemore.aegle.subject-registry.v1" + row[0].encode("utf-8")))


@pytest.fixture
def integration(client, tmp_path, monkeypatch):
    from livemorebio import bus
    from livemorebio.aegle import execution_api, server
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.model_contexts import model_availability
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.aegle.observation_state import ObservationState
    from livemorebio.aegle.registry_audit import RegistryAudit
    from livemorebio.aegle.subjects import SubjectRegistry

    path = tmp_path / "authored-binding-integration.sqlite3"
    monkeypatch.setenv("LIVEMORE_SUBJECT_REGISTRY", str(path))
    monkeypatch.setenv("LIVEMORE_PATCH_STORAGE_KEY", base64.urlsafe_b64encode(KEY).decode("ascii"))
    monkeypatch.setattr(server, "_subject_registry_instance", None)
    monkeypatch.setattr(server, "_subject_registry_path", None)
    registry = server._subject_registry()
    assert type(registry) is SubjectRegistry and registry.path == path and registry.key == KEY
    authority = ModelSourceAuthority(server._invalidate_model_source,
        fence=server._assign_model_fence, fence_guard=server._model_fence_guard)
    generation = authority.generation
    store = SimpleNamespace(**{name: forbidden for name in
        ("get", "create", "update", "acquire_owner", "release_owner")})
    manager = ExecutionManager(store, adapter_registry={}, run_background=False,
                               permitted_generation=generation)
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_execution_manager_instance", manager)
    observed = ObservationState()
    observed.observations = {"technical": {"value": "authored-A", "measured_at": None,
                                          "lineage_status": "legacy_missing"}}
    observed.patch["envelope_id"] = "authored-observation-A"
    candidate = SimpleNamespace(patch=deepcopy(observed.patch), observations=deepcopy(observed.observations))
    actions = [{"kind": "AUTHORED_PRIOR_ACTION"}]
    initial = {"tw": candidate, "subject": None, "initialized": True, "observation_state": observed}
    monkeypatch.setattr(server, "_state", initial)
    monkeypatch.setattr(server, "_workspace_actions", actions)
    t = SimpleNamespace(server=server, client=client, registry=registry, authority=authority,
        manager=manager, generation=generation, initial=initial, observed=observed,
        candidate=candidate, actions=actions, snapshots=[], bus_events=[], calls=[],
        baseline_audit=[], baseline_rows=None, selected=True, physical=False,
        target=None, current=None, initial_availability=None, interfere=None,
        changed_rows=None, fault=None)

    def unlocked():
        assert not authority._lock._is_owned()
        assert not execution_api._creation_lock._is_owned() and not manager._lock._is_owned()

    def access_events(*, allow_damaged=False):
        raw = audit_rows(registry)
        assert raw[:len(t.baseline_audit)] == t.baseline_audit
        new = raw[len(t.baseline_audit):]
        damaged = t.fault.get("damaged_after") if t.fault else None
        return [(row, None if allow_damaged and damaged == row else decode_audit(row)) for row in new]

    def assert_audit(outcomes, request_id=None, *, pending=False, damaged=False):
        actual = access_events(allow_damaged=damaged)
        assert len(actual) == len(outcomes)
        if request_id is None and actual:
            request_id = actual[0][1]["request_id"]
        if request_id:
            UUID(request_id)
        for (raw, event), outcome in zip(actual, outcomes):
            if event is None:
                assert damaged and outcome == "DAMAGED" and raw == t.fault["damaged_after"]
                continue
            assert event["outcome_code"] == outcome
            assert event["request_id"] == request_id
            assert event["schema"] == ("livemore.physical-access-audit.v1" if t.physical
                                       else "livemore.subject-access-audit.v1")
            assert event["action"] == ("bind" if t.physical else "inspect")
            assert event["local_store_id"] == registry.audit.store_id
            assert event["opaque_record_id"] == t.target["twin_id"]
            assert set(event) == {"schema", "request_id", "action", "opaque_record_id",
                "started_at", "completed_at", "outcome_code", "local_store_id",
                "local_process_instance", "source_sha256"}
        retained = reservations(registry)
        if pending:
            assert len(retained) == 1
            assert retained[0] == (actual[-1][0][0], request_id)
        else:
            assert retained == []
        assert len({row[0] for row, _ in actual}) == len(actual)
        return request_id

    def configure(*, selected=True, physical=False):
        t.selected, t.physical = selected, physical
        current = seed(registry, "binding-selected", active=True, human=physical, version=2)
        target = current if selected else seed(registry, "binding-target", version=2)
        seed(registry, "binding-unrelated", version=7)
        t.current, t.target = current, target
        initial.update(tw=None if physical else candidate, subject=server._subject_summary(current),
                       model_availability=model_availability(current, source_generation=generation))
        t.initial_availability = deepcopy(initial["model_availability"])
        t.baseline_rows, t.baseline_audit = rows(registry), audit_rows(registry)
        assert reservations(registry) == []

    def candidate_state():
        unlocked()
        assert t.selected and not t.physical
        t.calls.append("projection")
        assert_audit([None, "SUCCESS"])
        # Independent writer acquisition proves preparation released its lock;
        # protected helper identity/source retains the actual close obligation.
        with closing(sqlite3.connect(path, timeout=0.2)) as check:
            check.execute("BEGIN IMMEDIATE")
            check.rollback()
        if t.interfere:
            t.interfere()
            t.changed_rows = rows(registry)
        return {"profile": "AUTHORED_INERT_BINDING", "profile_params": {"technical": "unchanged"},
                "patch": deepcopy(candidate.patch), "observations": deepcopy(candidate.observations)}

    candidate.state = candidate_state

    def set_snapshot(key, value):
        unlocked()
        assert key == "twin"
        assert_audit([None, "SUCCESS", None, "SUCCESS"])
        assert server._state["subject"]["version"] == 3
        assert authority.generation == manager._permitted_generation != generation
        assert value["model_availability"] == server._state["model_availability"]
        t.snapshots.append(deepcopy(value))

    def publish(source, event, payload):
        unlocked()
        assert source == "Aegle" and event == server.events.TWIN_UPDATED
        t.bus_events.append(deepcopy(payload))

    monkeypatch.setattr(bus, "set_snapshot", set_snapshot)
    monkeypatch.setattr(bus, "publish", publish)
    protected = {name: getattr(SubjectRegistry, name) for name in (
        "prepare_patch_binding", "commit_prepared_transition", "_selection_read_access",
        "_selection_audit_begin", "_selection_audit_reenter", "_selection_audit_finish",
        "_transition_snapshot", "_confirm_transition_witness", "_open", "_seal")}
    audited = {name: getattr(RegistryAudit, name) for name in ("begin", "finish", "check_authority")}
    source = {name: getattr(ModelSourceAuthority, name) for name in
              ("commit_guard", "install_generation", "observation")}
    frozen_functions = (server._snapshot_twin, server._assign_model_fence, server._model_fence_guard)

    def identities():
        for name, function in protected.items():
            assert getattr(registry, name).__func__ is function
        for name, function in audited.items():
            assert getattr(registry.audit, name).__func__ is function
        for name, function in source.items():
            assert getattr(authority, name).__func__ is function
        assert frozen_functions == (server._snapshot_twin, server._assign_model_fence, server._model_fence_guard)

    identities()
    t.configure, t.assert_audit, t.unlocked = configure, assert_audit, unlocked
    yield t
    identities()
    assert manager._owners == manager._adapters == {} and not manager._closed
    manager.close()
    client.close()


def request(t, *, authorized=True):
    body = physical_body() if t.physical else {"device_id": "technical-device", "mode": "virtual"}
    body["expected_version"] = t.target["version"]
    response = t.client.post(f"/api/twins/{t.target['twin_id']}/patches", json=body,
        **({} if authorized else {"headers": {"Authorization": "Bearer invalid-authored-token"}}))
    assert "no-store" in response.headers["Cache-Control"]
    if authorized:
        UUID(response.headers["X-Request-ID"])
    return response


def assert_preserved_source(t):
    assert t.server._state is t.initial
    assert t.server._state["subject"] == t.server._subject_summary(t.current)
    assert t.server._state["model_availability"] == t.initial_availability
    assert t.authority.generation == t.manager._permitted_generation == t.generation
    assert t.server._state["tw"] is (None if t.physical else t.candidate)
    assert t.server._state["observation_state"] is t.observed and t.server._workspace_actions is t.actions
    assert not t.snapshots and not t.bus_events


def assert_binding_saved(t, *, response_record=None):
    after = rows(t.registry)
    old_records = {row[0]: row for row in t.baseline_rows["records"]}
    new_records = {row[0]: row for row in after["records"]}
    identifier = t.target["twin_id"]
    for ident, original in old_records.items():
        if ident != identifier:
            assert new_records[ident] == original
    old, new = old_records[identifier], new_records[identifier]
    assert new[:3] == old[:3] and new[5:8] == old[5:8]
    assert new[3] == old[3] and new[4] == old[4] + 1
    assert new[9:] != old[9:]
    record = decode_record(new)
    if response_record is not None:
        assert record == response_record
    expected = deepcopy(t.target)
    expected.update(version=3, updated_at=record["updated_at"], patch_bindings=record["patch_bindings"])
    assert record == expected
    assert len(record["patch_bindings"]) == 1
    bound = record["patch_bindings"][0]
    assert bound["device_id"] == "technical-device" and bound["mode"] == ("physical" if t.physical else "virtual")
    assert bound["qualification_state"] == ("PAIRING_RECORDED" if t.physical else "CONTRACT_BOUND")
    assert bound["telemetry_admission"] == ("PENDING_SIGNED_ENVELOPE" if t.physical else "VIRTUAL_ELIGIBLE")
    assert after["subject_identifiers"] == t.baseline_rows["subject_identifiers"]
    assert after["registry_state"] == t.baseline_rows["registry_state"]
    if t.physical:
        assert after["physical_device_bindings"] == [(t.registry._fingerprint("technical-device"), identifier, bound["bound_at"])]
    else:
        assert after["physical_device_bindings"] == t.baseline_rows["physical_device_bindings"]
    return record


def assert_confirmed(t, result, *, cleanup=False):
    assert result.status_code == (503 if cleanup else 200)
    if cleanup:
        assert result.json()["code"] == "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
    saved = assert_binding_saved(t, response_record=None if cleanup else result.json())
    t.assert_audit([None, "SUCCESS", None, "SUCCESS"], result.headers["X-Request-ID"])
    if not t.selected:
        assert_preserved_source(t)
        assert not t.calls
        assert not t.manager._wake.is_set()
        return
    assert t.server._state is not t.initial
    assert t.server._state["subject"] == t.server._subject_summary(saved)
    assert t.authority.generation == t.manager._permitted_generation != t.generation
    assert t.server._state["model_availability"] == {**t.initial_availability,
        "twin_version": 3, "source_generation": t.authority.generation}
    assert t.server._state["tw"] is (None if t.physical else t.candidate)
    assert t.server._state["observation_state"] is t.observed and t.server._workspace_actions is t.actions
    assert len(t.snapshots) == len(t.bus_events) == 1 and t.manager._wake.is_set()
    assert t.snapshots[0]["profile_params"] == (None if t.physical else {"technical": "unchanged"})
    assert t.snapshots[0]["observations"] == t.observed.observations
    assert t.calls == ([] if t.physical else ["projection"])


def install_fault(t, monkeypatch, mode):
    original_connect = t.registry._connect
    state = {"mode": mode, "attempts": 0, "updates": 0, "rollback_faults": 0,
             "closed": 0, "faulted": False, "damaged_before": None, "damaged_after": None}
    t.fault = state

    class Connection:
        def __init__(self, real):
            self.real, self.mutated = real, False

        def __getattr__(self, name):
            return getattr(self.real, name)

        def execute(self, sql, parameters=()):
            result = self.real.execute(sql, parameters)
            if sql.startswith("UPDATE records SET lifecycle=?,version=?,updated_at=?,nonce=?,ciphertext=? WHERE record_id=? AND version=?"):
                assert parameters[-2:] == (t.target["twin_id"], 2)
                assert result.rowcount == 1
                self.mutated = True
                state["updates"] += 1
            return result

        def commit(self):
            if not self.mutated or state["faulted"]:
                return self.real.commit()
            state["attempts"] += 1
            state["faulted"] = True
            if mode in {"rollback", "unknown_rollback"}:
                raise sqlite3.OperationalError("Authored mutation commit acknowledgment failure")
            self.real.commit()
            if mode == "damaged_ack":
                with closing(sqlite3.connect(t.registry.path)) as other, other:
                    raw = other.execute("SELECT * FROM registry_audit ORDER BY sequence DESC LIMIT 1").fetchone()
                    assert decode_audit(raw)["outcome_code"] == "SUCCESS"
                    state["damaged_before"] = raw
                    other.execute("UPDATE registry_audit SET ciphertext=? WHERE event_id=?", (b"authored-damaged-audit", raw[0]))
                    state["damaged_after"] = other.execute("SELECT * FROM registry_audit WHERE event_id=?", (raw[0],)).fetchone()
            if mode in {"lost_ack", "damaged_ack"}:
                raise sqlite3.OperationalError("Authored durable commit acknowledgment lost")

        def rollback(self):
            if self.mutated and mode == "unknown_rollback":
                state["rollback_faults"] += 1
                raise OSError("Authored rollback acknowledgment unknown")
            return self.real.rollback()

        def close(self):
            self.real.close()
            state["closed"] += 1
            if self.mutated and mode == "close_ack":
                raise OSError("Authored close acknowledgment lost after actual close")

    monkeypatch.setattr(t.registry, "_connect", lambda: Connection(original_connect()))


@pytest.mark.parametrize("kind", ["ready", "modeless_physical", "unselected"])
def test_actual_prepared_binding_commits_then_publishes_correct_source(integration, kind):
    t = integration
    t.configure(selected=kind != "unselected", physical=kind == "modeless_physical")
    assert_confirmed(t, request(t))


@pytest.mark.parametrize("damage", ["same_version_payload", "pointer_timestamp"])
def test_actual_final_binding_check_preserves_external_interference(integration, damage):
    t = integration
    t.configure()
    def interfere():
        if damage == "same_version_payload":
            changed = deepcopy(t.target)
            changed["display_label"] = "Authored external same-version edit"
            replace_fixture_record(t.registry, changed)
        else:
            with closing(sqlite3.connect(t.registry.path)) as other, other:
                other.execute("UPDATE registry_state SET updated_at='authored-external-clock' WHERE state_key='active_twin_id'")
    t.interfere = interfere
    result = request(t)
    assert result.status_code == 409 and result.json()["code"] == "TWIN_VERSION_CONFLICT"
    assert rows(t.registry) == t.changed_rows != t.baseline_rows
    t.assert_audit([None, "SUCCESS", None, "ACCESS_FAILED"], result.headers["X-Request-ID"])
    assert_preserved_source(t)


def test_actual_confirmed_rollback_keeps_original_binding_and_source(integration, monkeypatch):
    t = integration
    t.configure()
    install_fault(t, monkeypatch, "rollback")
    result = request(t)
    assert result.status_code == 503 and result.json()["code"] == "REGISTRY_STORAGE_UNAVAILABLE"
    assert rows(t.registry) == t.baseline_rows
    t.assert_audit([None, "SUCCESS", None, "ACCESS_FAILED"], result.headers["X-Request-ID"])
    assert t.fault["attempts"] == t.fault["updates"] == 1
    assert_preserved_source(t)


def test_actual_exact_lost_ack_witness_confirms_without_second_mutation(integration, monkeypatch):
    t = integration
    t.configure()
    install_fault(t, monkeypatch, "lost_ack")
    assert_confirmed(t, request(t))
    assert t.fault["attempts"] == t.fault["updates"] == 1
    assert t.fault["closed"] == 3  # Preparation, mutation and read-only witness.


def assert_denied(t, result):
    from livemorebio.aegle.execution import DENY_ALL
    assert result.status_code == 503 and result.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
    assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL
    assert t.server._state is t.initial and t.server._state["tw"] is t.candidate
    assert t.server._state["subject"] == t.server._subject_summary(t.current)
    assert t.server._state["observation_state"] is t.observed and t.server._workspace_actions is t.actions
    assert not t.snapshots and not t.bus_events and t.manager._wake.is_set()
    before = (rows(t.registry), audit_rows(t.registry), reservations(t.registry))
    for path in ("/api/state", "/api/cendos/current-source"):
        response = t.client.get(path)
        assert response.status_code == 503 and response.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
    response = t.client.post("/api/workspace/actions", json={})
    assert response.status_code == 503 and response.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
    assert (rows(t.registry), audit_rows(t.registry), reservations(t.registry)) == before


@pytest.mark.parametrize("selected", [True, False])
def test_actual_damaged_terminal_witness_denies_selected_and_unselected(integration, monkeypatch, selected):
    t = integration
    t.configure(selected=selected)
    install_fault(t, monkeypatch, "damaged_ack")
    result = request(t)
    assert_binding_saved(t)
    assert t.fault["damaged_before"] != t.fault["damaged_after"]
    assert t.fault["attempts"] == t.fault["updates"] == 1
    t.assert_audit([None, "SUCCESS", None, "DAMAGED"], result.headers["X-Request-ID"], damaged=True)
    assert_denied(t, result)


def test_actual_unknown_rollback_remains_denied_after_close_rolls_back(integration, monkeypatch):
    t = integration
    t.configure()
    install_fault(t, monkeypatch, "unknown_rollback")
    result = request(t)
    assert rows(t.registry) == t.baseline_rows
    assert t.fault["rollback_faults"] == 1 and t.fault["closed"] == 2
    assert t.fault["attempts"] == t.fault["updates"] == 1
    t.assert_audit([None, "SUCCESS", None], result.headers["X-Request-ID"], pending=True)
    assert_denied(t, result)


@pytest.mark.parametrize("selected", [True, False])
def test_actual_committed_close_ack_keeps_confirmed_source_outcome(integration, monkeypatch, selected):
    t = integration
    t.configure(selected=selected)
    install_fault(t, monkeypatch, "close_ack")
    assert_confirmed(t, request(t), cleanup=True)
    assert t.fault["attempts"] == t.fault["updates"] == 1 and t.fault["closed"] == 2


def test_unauthorized_binding_never_reaches_real_preparation(integration):
    t = integration
    t.configure()
    assert request(t, authorized=False).status_code == 401
    assert t.client.get("/").status_code == 200
    assert rows(t.registry) == t.baseline_rows and audit_rows(t.registry) == t.baseline_audit
    assert reservations(t.registry) == [] and t.calls == []
    assert_preserved_source(t)
