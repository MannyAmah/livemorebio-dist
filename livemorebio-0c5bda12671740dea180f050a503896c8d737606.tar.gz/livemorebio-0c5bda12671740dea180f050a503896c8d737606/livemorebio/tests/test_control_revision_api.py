"""Lifecycle CAS route contract; no physical biology or transport claims."""
import pytest

from livemorebio.tests.test_execution_api import HEADERS, product, prepare, control
from livemorebio.tests.test_virtual_execution_api import life
from livemorebio.tests.test_life_session_proxy import proxy


@pytest.mark.parametrize("action", ["start", "pause", "resume", "stop"])
def test_engine_route_forwards_explicit_control_revision_once(product, monkeypatch, action):
    state = prepare(product)
    calls = []

    def operation(execution_id, **kwargs):
        calls.append((execution_id, kwargs))
        return {"execution_id": execution_id, "control_revision": 8}

    monkeypatch.setattr(product.manager, action, operation)
    body = {"expected_control_revision": 7, "expected_source_generation": state["source_generation"]}
    response = product.client.post(f"/api/executions/{state['execution_id']}/{action}",
                                   json=body, headers=HEADERS)
    assert response.status_code == 200
    assert calls == [(state["execution_id"], body)]
    assert response.headers["cache-control"] == "no-store"


@pytest.mark.parametrize("action", ["pause", "resume", "stop"])
def test_life_route_forwards_explicit_control_revision_once(life, monkeypatch, action):
    calls = []

    def operation(session_id, **kwargs):
        calls.append((session_id, kwargs))
        return {"session_id": session_id, "control_revision": 8}

    monkeypatch.setattr(life.owner, action, operation)
    body = {"expected_control_revision": 7}
    response = life.client.post(f"/patch/virtual/sessions/{life.record['session_id']}/{action}",
                               json=body, headers=HEADERS)
    assert response.status_code == 200
    assert calls == [(life.record["session_id"], body)]
    assert response.headers["cache-control"] == "no-store"


@pytest.mark.parametrize("action", ["pause", "resume", "stop"])
def test_proxy_preserves_explicit_control_guard(proxy, action):
    response = proxy.client.post("/api/patch/virtual/sessions/" + "a" * 32 + "/" + action,
                                 json={"expected_control_revision": 7}, headers=HEADERS)
    assert response.status_code == 200
    assert proxy.calls == [("POST", "/patch/virtual/sessions/" + "a" * 32 + "/" + action,
                            {"expected_control_revision": 7}, (200, 409, 422, 503))]


@pytest.mark.parametrize("guard", [{}, {"expected_revision": 1, "expected_control_revision": 1},
    {"expected_control_revision": True}, {"expected_control_revision": "1"},
    {"expected_control_revision": 1.0}, {"expected_control_revision": 0},
    {"expected_control_revision": -1}, {"expected_control_revision": None}])
def test_proxy_rejects_invalid_or_ambiguous_guard_before_peer_io(proxy, guard):
    response = proxy.client.post("/api/patch/virtual/sessions/" + "a" * 32 + "/pause",
                                 json=guard, headers=HEADERS)
    assert response.status_code == 422
    assert proxy.calls == []


def test_engine_displayed_control_revision_survives_frame_but_not_operator_change(product):
    initial = prepare(product)
    running = control(product, initial, "start").json()
    product.manager.advance_once(initial["execution_id"])
    path = f"/api/executions/{initial['execution_id']}"
    assert control(product, running, "pause").status_code == 409
    body = {"expected_control_revision": running["control_revision"],
            "expected_source_generation": running["source_generation"]}
    paused = product.client.post(path + "/pause", json=body, headers=HEADERS)
    assert paused.status_code == 200
    assert paused.json()["state"] == "paused"
    assert paused.json()["latest_frame"] == 1
    assert product.client.post(path + "/resume", json=body, headers=HEADERS).status_code == 409
    body["expected_control_revision"] = paused.json()["control_revision"]
    assert product.client.post(path + "/resume", json=body, headers=HEADERS).status_code == 200
    assert product.client.post(path + "/pause", json=body, headers=HEADERS).status_code == 409


def test_life_displayed_control_revision_survives_delivery_without_replay(life):
    initial = life.owner.status(life.record["session_id"])
    life.source.publish(life.frame)
    life.owner.tick(initial["session_id"])
    path = "/patch/virtual/sessions/" + initial["session_id"]
    assert life.client.post(path + "/pause", json={"expected_revision": initial["revision"]},
                            headers=HEADERS).status_code == 409
    body = {"expected_control_revision": initial["control_revision"]}
    paused = life.client.post(path + "/pause", json=body, headers=HEADERS)
    assert paused.status_code == 200
    assert paused.json()["state"] == "paused" and paused.json()["last_forwarded"] == 1
    life.owner.tick(initial["session_id"])
    assert len(life.received) == 1
    assert life.client.post(path + "/resume", json=body, headers=HEADERS).status_code == 409
