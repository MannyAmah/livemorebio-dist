"""Owned technical processes only; no source acquisition, services or geometry."""
from __future__ import annotations

import fcntl
import importlib
import io
import os
from pathlib import Path
import selectors
import signal
import subprocess
import sys
import time

import pytest
from ._timing import wait_seconds


def process_module():
    return importlib.import_module("livemorebio.anatomy._atlas_process")


def line(stream):
    with selectors.DefaultSelector() as selected:
        selected.register(stream, selectors.EVENT_READ)
        assert selected.select(5), "Technical subprocess readiness timed out"
        return stream.readline().strip()


def available(path):
    with path.open("rb") as stream:
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except BlockingIOError:
            return False


@pytest.mark.parametrize("state", ["S", "Z"])
def test_linux_stat_parser_keeps_group_field_after_complex_command(state):
    process = process_module()
    assert process.parse_linux_stat(f"123 (name with ) and ( spaces) {state} 42 123 123 0 0\n", 123) == (123, state)


@pytest.mark.parametrize("raw", ["", "123 truncated", "124 (wrong pid) S 1 123", "123 (x) ? 1 123", "123 (x) S 1 -1"])
def test_linux_stat_parser_rejects_unprovable_membership(raw):
    process = process_module()
    with pytest.raises(process.ProcessOwnershipError):
        process.parse_linux_stat(raw, 123)


@pytest.mark.parametrize("exit_code", [0, 7])
def test_exited_owned_leader_is_held_until_descendant_lock_released(tmp_path, exit_code):
    process = process_module()
    process.ensure_supported()
    path = tmp_path / "technical-held.lock"
    lock = os.open(path, os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o600)
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    child = None
    code = """import os,sys,time
pid=os.fork()
if pid==0:
    while True:time.sleep(1)
print('READY',flush=True)
os._exit(int(sys.argv[1]))
"""
    try:
        child = subprocess.Popen([sys.executable, "-I", "-B", "-c", code, str(exit_code)],
                                 pass_fds=(lock,), start_new_session=True, stdin=subprocess.DEVNULL,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8")
        assert line(child.stdout) == "READY"
        os.close(lock)
        lock = -1
        deadline = time.monotonic()+5
        while not process.waitable_child_exited(child.pid):
            assert time.monotonic() < deadline
            time.sleep(.01)
        assert child.returncode is None, "Observation must not reap the ownership anchor"
        assert not available(path), "Technical descendant must retain inherited lock"
        result = process.terminate_owned_group(child)
        assert result["reaped"] is True and result["descendants"] is True
        assert result["exit_code"] == exit_code
        assert available(path)
    finally:
        if lock >= 0:
            os.close(lock)
        if child is not None:
            # This test is the only waiter. Do not signal after helper reaping.
            if child.returncode is None:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                child.wait(timeout=wait_seconds(5))
            child.stdout.close()
            child.stderr.close()


def test_unproved_child_ownership_never_signals_numeric_group(monkeypatch):
    process = process_module()
    class Other:
        pid = 999999999
        returncode = None
        def wait(self, **kwargs):
            pytest.fail("Unowned process must not be reaped")
    monkeypatch.setattr(process, "waitable_child_exited", lambda pid: (_ for _ in ()).throw(process.ProcessOwnershipError("PROCESS_OWNERSHIP_LOST")))
    monkeypatch.setattr(process.os, "killpg", lambda *args: pytest.fail("Unproved group was signalled"))
    with pytest.raises(process.ProcessOwnershipError):
        process.terminate_owned_group(Other())


def test_guardian_self_termination_race_verifies_entire_group_before_reap(monkeypatch):
    process = process_module()
    calls = []
    class Child:
        pid = 999999998
        returncode = None
        def wait(self, **kwargs):
            calls.append("reap")
            self.returncode = -signal.SIGKILL
            return self.returncode
    groups = iter([[999999998, 999999997], [999999997], []])
    monkeypatch.setattr(process, "waitable_child_exited", lambda pid: True)
    def members(pid):
        calls.append("inspect")
        return next(groups)
    monkeypatch.setattr(process, "active_group_members", members)
    monkeypatch.setattr(process.os, "killpg", lambda *args: (_ for _ in ()).throw(PermissionError("guardian already ending owned group")))
    result = process.terminate_owned_group(Child())
    assert result["reaped"] and result["descendants"]
    assert calls == ["inspect", "inspect", "inspect", "reap"]


def test_permission_denial_with_live_group_never_acknowledges_or_reaps(monkeypatch):
    process = process_module()
    class Child:
        pid = 999999996
        returncode = None
        def wait(self, **kwargs):
            pytest.fail("Still-live group cannot release its ownership anchor")
    monkeypatch.setattr(process, "waitable_child_exited", lambda pid: True)
    monkeypatch.setattr(process, "active_group_members", lambda pid: [999999995])
    monkeypatch.setattr(process.os, "killpg", lambda *args: (_ for _ in ()).throw(PermissionError("denied")))
    with pytest.raises(process.ProcessOwnershipError) as error:
        process.terminate_owned_group(Child(), .02)
    assert error.value.code == "PROCESS_GROUP_TERMINATION_FAILED"


def test_linux_waitid_uses_only_exact_child_and_nonreaping_options(monkeypatch):
    process = process_module()
    from types import SimpleNamespace
    monkeypatch.setattr(process.platform, "system", lambda: "Linux")
    for name, value in {"P_PID": 1, "WEXITED": 4, "WNOHANG": 1, "WNOWAIT": 32}.items():
        monkeypatch.setattr(process.os, name, value, raising=False)
    calls = []
    def waitid(kind, pid, options):
        calls.append((kind, pid, options))
        return SimpleNamespace(si_pid=pid)
    monkeypatch.setattr(process.os, "waitid", waitid, raising=False)
    assert process.waitable_child_exited(123)
    assert calls == [(1, 123, 37)]


def test_darwin_truncated_membership_is_not_treated_as_complete(monkeypatch):
    process = process_module()
    monkeypatch.setattr(process.platform, "system", lambda: "Darwin")
    monkeypatch.setattr(process, "_darwin_group", lambda: lambda *args: 128)
    with pytest.raises(process.ProcessOwnershipError) as error:
        process.active_group_members(123)
    assert error.value.code == "PROCESS_GROUP_INSPECTION_FAILED"


def test_exit_transition_waits_for_owned_waitable_leader_without_signal(monkeypatch):
    process = process_module()
    states = iter([False, False, True, True])
    calls = []
    class Child:
        pid = 999999994
        returncode = None
        def wait(self, **kwargs):
            calls.append("reaped")
            self.returncode = -signal.SIGKILL
            return self.returncode
    monkeypatch.setattr(process, "waitable_child_exited", lambda pid: next(states))
    monkeypatch.setattr(process.os, "getpgid", lambda pid: (_ for _ in ()).throw(ProcessLookupError("exit transition")))
    monkeypatch.setattr(process.os, "killpg", lambda *args: pytest.fail("No live group was proven"))
    monkeypatch.setattr(process, "active_group_members", lambda pid: [])
    assert process.terminate_owned_group(Child())["reaped"]
    assert calls == ["reaped"]


def test_unresolved_exit_transition_fails_without_signalling_or_reaping(monkeypatch):
    process = process_module()
    class Child:
        pid = 999999993
        returncode = None
        def wait(self, **kwargs):
            pytest.fail("Unproved exit cannot be reaped as cleanup success")
    monkeypatch.setattr(process, "waitable_child_exited", lambda pid: False)
    monkeypatch.setattr(process.os, "getpgid", lambda pid: (_ for _ in ()).throw(ProcessLookupError("unresolved")))
    monkeypatch.setattr(process.os, "killpg", lambda *args: pytest.fail("Unproved group cannot be signalled"))
    with pytest.raises(process.ProcessOwnershipError):
        process.terminate_owned_group(Child(), .02)


@pytest.mark.parametrize("unrelated", [b"2 (kernel worker) S 0 0 0 0\n", b"2 (caf\xc3\xa9 and ) parenthesis) S 1 77 77 0\n"])
def test_linux_complete_scanner_ignores_valid_unrelated_kernel_and_nonascii_comm(monkeypatch, unrelated):
    process = process_module()
    from types import SimpleNamespace
    import builtins
    monkeypatch.setattr(process.platform, "system", lambda: "Linux")
    records = {"2": unrelated, "4234": b"4234 (owned guardian) S 1 4234 4234 0\n",
               "4235": b"4235 (owned child) S 4234 4234 4234 0\n", "4236": b"4236 (exited) Z 4234 4234 4234 0\n"}
    class Entries:
        def __enter__(self):
            return iter([SimpleNamespace(name=pid, path="/proc/"+pid) for pid in records])
        def __exit__(self, *args):
            pass
    monkeypatch.setattr(process.os, "scandir", lambda path: Entries())
    original = builtins.open
    def opened(path, mode="r", **kwargs):
        if str(path).startswith("/proc/"):
            raw = io.BytesIO(records[str(path).split("/")[2]])
            return raw if "b" in mode else io.TextIOWrapper(raw, encoding=kwargs.get("encoding", "utf8"))
        return original(path, mode, **kwargs)
    monkeypatch.setattr(builtins, "open", opened)
    assert process.active_group_members(4234) == [4234, 4235]


@pytest.mark.parametrize("pid", [0, False, -1])
def test_owned_scanner_target_is_never_zero_boolean_or_negative(monkeypatch, pid):
    process = process_module()
    monkeypatch.setattr(process.platform, "system", lambda: "Linux")
    monkeypatch.setattr(process.os, "scandir", lambda *args: pytest.fail("Invalid target entered process scanner"))
    with pytest.raises(process.ProcessOwnershipError):
        process.active_group_members(pid)


@pytest.mark.parametrize("failure", ["permission", "malformed", "nonascii_number", "oversized", "disappeared"])
def test_linux_complete_scanner_preserves_strict_inspection_and_disappearance_rules(monkeypatch, failure):
    process = process_module()
    from types import SimpleNamespace
    import builtins
    import errno
    monkeypatch.setattr(process.platform, "system", lambda: "Linux")
    class Entries:
        def __enter__(self):
            return iter([SimpleNamespace(name="2", path="/proc/2")])
        def __exit__(self, *args):
            pass
    monkeypatch.setattr(process.os, "scandir", lambda path: Entries())
    def opened(path, mode="r", **kwargs):
        if failure == "permission":
            raise PermissionError(errno.EACCES, "technical denied")
        if failure == "disappeared":
            raise FileNotFoundError(errno.ENOENT, "technical disappeared")
        raw = {"malformed": b"2 broken", "nonascii_number": b"2 (valid name) S 1 \xd9\xa2\n",
               "oversized": b"2 (" + b"x"*4096 + b") S 1 0\n"}[failure]
        stream = io.BytesIO(raw)
        return stream if "b" in mode else io.TextIOWrapper(stream, encoding=kwargs.get("encoding", "utf8"))
    monkeypatch.setattr(builtins, "open", opened)
    if failure == "disappeared":
        assert process.active_group_members(4234) == []
    else:
        with pytest.raises(process.ProcessOwnershipError) as error:
            process.active_group_members(4234)
        assert error.value.code == "PROCESS_GROUP_INSPECTION_FAILED"
