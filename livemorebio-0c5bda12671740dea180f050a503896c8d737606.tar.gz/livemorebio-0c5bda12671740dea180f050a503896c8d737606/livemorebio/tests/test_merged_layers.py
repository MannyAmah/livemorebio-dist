"""Tests for the layers merged from livemore-ecosystem / Human-body-map /
Plant Medicine (audit §5 merge plan, components 2–5).

Ported and adapted from the ecosystem test suites where they exercised the
modules directly; orchestrator-coupled tests were re-targeted at the
repo-native APIs (real Bergman assay instead of the retired CendosLab).
"""
from __future__ import annotations

import os
import tempfile

import pytest


# ---------------------------------------------------------------- reference
def test_reference_kb_loads_real_seed():
    from livemorebio.life_system.reference import KnowledgeBase

    kb = KnowledgeBase(offline=True)
    assert len(kb.genes) >= 25 and len(kb.diseases) >= 15
    assert len(kb.organs()) >= 8
    # seed is real referenced biology: genes carry symbols the pathway
    # databases know about
    assert kb.gene("TCF7L2") is not None


def test_reference_factory_unique_grounded_patients():
    from livemorebio.life_system.reference import KnowledgeBase, PatientFactory

    pf = PatientFactory(KnowledgeBase(offline=True), seed=11)
    a = pf.create("p-a")
    b = pf.create("p-b")
    assert type(a).__name__ == "RealHuman"
    for h in (a, b):
        ref = h.reference
        assert "susceptibility" in ref and ref["risk_alleles"] >= 0
        assert ref["grounded_in"]  # provenance must name its sources
    # Variation comes from the explicit synthetic baseline; annotations cannot
    # supply a person's carrier status or missing allele frequencies.
    assert a.profile != b.profile
    assert a.genome == b.genome == {}
    assert a.reference["unknown_allele_frequency_policy"] == "not sampled"


def test_reference_cohort_all_distinct():
    from livemorebio.life_system.reference import KnowledgeBase, PatientFactory

    pf = PatientFactory(KnowledgeBase(offline=True), seed=99)
    cohort = pf.create_cohort(10)
    assert len(cohort) == 10
    profiles = [tuple(sorted(h.profile.items())) for h in cohort]
    assert len(set(profiles)) > 1


def test_reference_human_builder_and_simulator():
    from livemorebio.life_system.reference.human_builder import HumanSpec, build_human
    from livemorebio.life_system.reference.simulator import LivingHuman

    spec = HumanSpec(id="hb-1", sex="F", age=44, conditions=["type 2 diabetes"])
    human = build_human(spec)
    assert human is not None
    lh = LivingHuman(human)
    assert lh is not None
    assert lh.h is human


# ---------------------------------------------------------------- cendos LIMS
def _lims(tmpdir):
    from livemorebio.cendos.lims import DB, CendosLabOS

    db = DB(os.path.join(tmpdir, "cendos.db"))
    return db, CendosLabOS(db=db)


def test_lims_schema_and_chain_of_custody():
    with tempfile.TemporaryDirectory() as d:
        db, lab = _lims(d)
        tables = {
            r[0]
            for r in db.conn.execute(
                "select name from sqlite_master where type='table'"
            ).fetchall()
        }
        tables.discard("sqlite_sequence")
        assert len(tables) >= 21
        for required in (
            "donors", "consents", "biospecimens", "organoids", "qc_events",
            "experiments", "experiment_runs", "results", "calibration_events",
            "electronic_signatures", "audit_logs",
        ):
            assert required in tables, required

        donor = lab.register_donor(sex="F", ancestry="AFR")
        lab.add_consent(donor, scope="research_use_only")
        spec = lab.register_biospecimen(donor, type="blood")
        org = lab.create_organoid(spec, "hepatic", twin_id="twin-01")
        lab.qc(org, "organoid", status="passed")
        assert db.count("audit_logs") >= 4  # every step audited


def test_lims_runs_real_bergman_assay_and_persists_readouts():
    from livemorebio.engines.metabolic.glucose_insulin import T2D
    from livemorebio.engines.metabolic.interventions import metformin

    with tempfile.TemporaryDirectory() as d:
        db, lab = _lims(d)
        exp = lab.design_experiment("twin-01", "type-2-diabetes",
                                    "metformin lowers glycemic exposure")
        rid, result = lab.run_experiment(exp, baseline=T2D, treated=metformin(T2D, 1.0))
        assert result["decision"] in ("EFFECT", "WEAK", "NO_EFFECT")
        assert "model-only" in result["note"]
        assert db.count("experiment_runs") == 1
        assert db.count("results") == 3  # delta_mean, delta_iAUC, rel_mean
        # provenance: assay readouts are experiment-class evidence, not measured
        ev = {r["evidence_type"] for r in db.query("results")}
        assert ev == {"experiment"}


def test_lims_bidirectional_calibration_requires_evidence_authorization():
    from livemorebio.evidence import CalibrationDeniedError

    with tempfile.TemporaryDirectory() as d:
        db, lab = _lims(d)
        opened = lab.hypothesis_from_aegle(
            "twin-01", "type-2-diabetes", "berberine improves insulin sensitivity",
            target_pathways=["AMPK"], candidate_compounds=["berberine"],
            recommended_model="hepatic organoid", recommended_assays=["ogtt"],
        )
        assert opened["experiment_id"].startswith("CEN-EXP")
        with pytest.raises(CalibrationDeniedError, match="evidence authorization"):
            lab.calibration_to_aegle(
                "twin-01", opened["experiment_id"],
                observed_effect={"rel_mean": -0.08},
                model_update={"Si_scale": 1.15},
            )
        directions = {r["direction"] for r in db.query("calibration_events")}
        assert directions == {"aegle->cendos"}


# ---------------------------------------------------------------- anatomy
def test_anatomy_ontology_loads_and_validates():
    from livemorebio.anatomy import load_ontology

    o = load_ontology()
    assert len(o.scales) >= 11
    assert len(o.systems) >= 15
    assert len(o.structures) >= 50
    assert o.system_of("heart") == "cardiovascular"
    assert any(c["id"] == "oxygen_delivery" for c in o.couplings_for("respiratory"))
    assert len(o.trait_axes) >= 8


def test_anatomy_ontology_rejects_broken_contract():
    from livemorebio.anatomy import load_ontology
    from livemorebio.anatomy.ontology import OntologyValidationError, validate_ontology

    import copy

    model = copy.deepcopy(dict(load_ontology(validate=False).raw))
    model["couplings"][0]["source_systems"] = ["not_a_system"]
    with pytest.raises(OntologyValidationError):
        validate_ontology(model)


# ---------------------------------------------------------------- discovery
def test_plant_substrate_full_dataset_with_grades_and_safety():
    from livemorebio.discovery.substrate import PROFILES_PATH, SAFETY_PATH, load_substrate
    from livemorebio.tests.private_reference_helpers import require_private_reference_data

    require_private_reference_data(PROFILES_PATH, SAFETY_PATH)
    s = load_substrate()
    assert len(s) == 193
    assert set(s.evidence_scale) == {f"E{i}" for i in range(10)}
    assert len(s.safety_flags) > 400
    # grading and safety are never silently dropped
    p = s.by_name("Agrimony")
    assert p is not None
    assert s.grade_of(p["record_id"]).startswith("E")
    assert isinstance(s.safety_for(p["record_id"]), list)
    # hard stops are surfaced, not filtered away
    assert len(s.hard_stops()) > 0


def test_plant_substrate_cendos_shortlist_respects_safety_gate():
    from livemorebio.discovery.substrate import PROFILES_PATH, SAFETY_PATH, load_substrate
    from livemorebio.tests.private_reference_helpers import require_private_reference_data

    require_private_reference_data(PROFILES_PATH, SAFETY_PATH)
    s = load_substrate()
    shortlist = s.candidates_for_cendos(min_scaffold_score=70)
    assert shortlist, "expected at least one graded candidate"
    ids = {p["record_id"] for p in shortlist}
    for blocked in s.hard_stops():
        assert blocked["record_id"] not in ids
    scores = [p["isolated_compound_scaffold_potential_score_0_100"] for p in shortlist]
    assert scores == sorted(scores, reverse=True)


def test_discovery_engine_offline_screen_is_honest():
    from livemorebio.discovery.pipeline import DiscoveryEngine

    eng = DiscoveryEngine(online=False)
    res = eng.screen("bitter kola", disease_axis="metabolic")
    assert res["plant"] == "bitter kola"
    assert res["n_compounds"] >= 1
    assert isinstance(res["leads"], list)
