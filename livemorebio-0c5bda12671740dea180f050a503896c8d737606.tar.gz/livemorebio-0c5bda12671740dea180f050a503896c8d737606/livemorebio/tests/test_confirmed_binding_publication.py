"""Binding-only publication boundaries using authored values and no-I/O ownership.

The real authority, manager fence, observation copier and bus snapshot helper are
retained. No registry, adapter, model constructor or physical admission executes.
"""
from contextlib import contextmanager
from copy import deepcopy
from types import SimpleNamespace
from uuid import UUID

import pytest

from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401
from livemorebio.tests.test_closed_manager_source_publication import NoIOStore, OWNER_ID
from livemorebio.tests.test_committed_source_transitions import post


def sample(name, connected=True):
    """Authored attached rows, including unchanged legacy missing-clock metadata."""
    return {"patch": {"connected": connected, "sequence": 1 if name == "A" else 2,
        "envelope_id": "authored-" + name, "protocol_version": "2.0",
        "hardware_present": False, "mode": "virtual", "source": "AUTHORED_TEST_ONLY",
        "device_id": "technical-unregistered-device"},
        "observations": {"technical": {"value": name, "source_class": "legacy_unknown",
            "lineage_status": "legacy_missing", "measurement_time": None,
            "received_at": None, "quality": {"flag": "authored"},
            "subject_id": None, "device_id": None, "source_generation": None}}}


@pytest.fixture
def binding(client, monkeypatch):
    from livemorebio import bus
    from livemorebio.aegle import clinical_views, execution_api, server
    from livemorebio.aegle.execution import DENY_ALL, ExecutionManager
    from livemorebio.aegle.model_contexts import model_availability
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.aegle.observation_state import ObservationState
    from livemorebio.aegle.subjects import SubjectRegistryError

    calls, snapshots, bus_locks, store_calls = [], [], [], []
    scenario = {"selected": True, "outcome": "COMMITTED", "before_final": None,
                "during_projection": None, "after_cleanup": None, "params": "valid",
                "capability": "valid", "prepare_mismatch": None}
    before = {"twin_id": "twin-authored-binding", "subject_id": "not-a-participant",
        "source_class": "SYNTHETIC", "display_label": "Authored binding boundary",
        "lifecycle": "ACTIVE", "version": 2, "selection_mode": "model"}
    target_before, target_after = deepcopy(before), {**deepcopy(before), "version": 3}
    active_guard, committed_guard = [None], [None]

    def locks():
        return (authority._lock._is_owned(), execution_api._creation_lock._is_owned(),
                manager._lock._is_owned())

    def unlocked():
        assert locks() == (False, False, False)

    def assert_publication():
        assert server._state["tw"] is original["tw"]
        assert server._state["observation_state"] is observed
        assert server._workspace_actions is actions and tuple(actions) == original["actions"]
        if scenario["outcome"] == "uncertain":
            assert authority.permitted_generation is DENY_ALL
            assert manager._permitted_generation is DENY_ALL
            assert server._state["subject"] == original["subject"]
        elif not scenario["selected"]:
            assert_original()
        else:
            assert authority.generation != generation
            assert manager._permitted_generation == authority.generation
            assert server._state["subject"] == server._subject_summary(target_after)
            expected = {**original["availability"], "twin_id": target_after["twin_id"],
                        "twin_version": 3, "source_generation": authority.generation}
            assert server._state["model_availability"] == expected

    @contextmanager
    def fence_guard():
        with server._model_fence_guard():
            owner, previous = object(), active_guard[0]
            active_guard[0] = owner
            try:
                yield
            finally:
                try:
                    if committed_guard[0] is owner:
                        assert locks() == (True, True, True)
                        assert_publication()
                        calls.append("guard-exit-published")
                finally:
                    active_guard[0] = previous

    authority = ModelSourceAuthority(server._invalidate_model_source,
        fence=server._assign_model_fence, fence_guard=fence_guard)
    generation = authority.generation
    store = NoIOStore(store_calls)
    manager = ExecutionManager(store, adapter_registry={}, run_background=False,
                               permitted_generation=generation)
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_execution_manager_instance", manager)
    observed = ObservationState()
    old_twin = SimpleNamespace(**deepcopy(sample("A")))
    observed.patch, observed.observations = deepcopy(old_twin.patch), deepcopy(old_twin.observations)
    actions = [{"kind": "AUTHORED_PRIOR_ACTION", "clock": "unchanged"}]
    initial = {"tw": old_twin, "subject": deepcopy(before), "initialized": True,
               "observation_state": observed,
               "model_availability": model_availability(before, source_generation=generation)}
    monkeypatch.setattr(server, "_state", initial)
    monkeypatch.setattr(server, "_workspace_actions", actions)
    original = {}

    def freeze():
        original.update(tw=initial["tw"], subject=deepcopy(initial["subject"]),
            availability=deepcopy(initial["model_availability"]), actions=tuple(actions))

    def assert_original():
        assert server._state is initial
        assert initial["tw"] is original["tw"] and initial["observation_state"] is observed
        assert initial["subject"] == original["subject"]
        assert initial["model_availability"] == original["availability"]
        assert server._workspace_actions is actions and tuple(actions) == original["actions"]
        assert authority.generation == generation == manager._permitted_generation

    def invoke_projection_hook():
        unlocked()
        hook = scenario.pop("during_projection", None)
        if hook:
            hook()

    def projected_state():
        unlocked()
        calls.append("state")
        invoke_projection_hook()
        result = {"profile": "AUTHORED_ORIGINAL", "profile_params": {"technical": "original"},
            "patch": deepcopy(old_twin.patch), "observations": deepcopy(old_twin.observations),
            "provenance": {"data_class": "AUTHORED_TEST_ONLY"}, "applied": ["unchanged-history"],
            "capability": {"maturity": {"packet_admitted": old_twin.patch["connected"],
                                        "model_qualified": False}}}
        if scenario["params"] == "missing":
            result.pop("profile_params")
        elif scenario["params"] != "valid":
            result["profile_params"] = scenario["params"]
        if scenario["capability"] != "valid":
            result["capability"] = scenario["capability"]
        return result

    old_twin.state = projected_state
    base_state = ObservationState.state

    def observed_state(holder):
        if holder is old_twin or holder is observed:
            assert locks() == (True, False, False)
            calls.append("capture-observation-pair")
        return base_state(holder)

    monkeypatch.setattr(ObservationState, "state", observed_state)
    real_unavailable = clinical_views.unavailable_state

    def unavailable(availability, holder):
        unlocked()
        calls.append("modeless-projection")
        assert holder is not observed and holder is not old_twin
        invoke_projection_hook()
        return real_unavailable(availability, holder)

    monkeypatch.setattr(clinical_views, "unavailable_state", unavailable)
    real_commit_guard = authority.commit_guard

    @contextmanager
    def commit_guard():
        # This hook is before the authority acquisition, not inside a fence guard.
        hook = scenario.pop("before_final", None)
        if hook:
            unlocked()
            hook()
        with real_commit_guard():
            yield

    monkeypatch.setattr(authority, "commit_guard", commit_guard)
    original_assign = manager.set_source_generation

    def assign(value):
        assert locks() == (True, True, True)
        calls.append("fence-deny" if value is DENY_ALL else "fence-new")
        original_assign(value)

    monkeypatch.setattr(manager, "set_source_generation", assign)
    original_invalidate = manager.invalidate_source

    def invalidate(value, reason):
        unlocked()
        assert value == generation
        assert_publication()
        calls.append("invalidate")
        result = original_invalidate(value, reason)
        hook = scenario.pop("after_cleanup", None)
        if hook:
            hook()
        return result

    monkeypatch.setattr(manager, "invalidate_source", invalidate)

    class Registry:
        def prepare_patch_binding(self, identifier, body, *, expected_version, request_id):
            assert locks() == (True, False, False)
            assert_original()
            assert identifier == target_before["twin_id"] and expected_version == 2
            assert body["device_id"] == "technical-unregistered-device"
            UUID(request_id)
            scenario["request_id"] = request_id
            calls.append("prepare")
            if scenario["outcome"] == "prepare_failure":
                raise SubjectRegistryError("TWIN_VERSION_CONFLICT", "Authored rejection")
            active = deepcopy(before)
            if scenario["prepare_mismatch"]:
                key = scenario["prepare_mismatch"]
                active[key] = 17 if key == "version" else "different-authored-value"
            prepared = SimpleNamespace(kind="bind", record=deepcopy(target_after),
                target_before=deepcopy(target_before), active_before=active,
                active_after=deepcopy(target_after if scenario["selected"] else before),
                selected=scenario["selected"], request_id=request_id)
            scenario["prepared"] = prepared
            return prepared

        def commit_prepared_transition(self, prepared):
            assert locks() == (True, True, True)
            assert prepared is scenario["prepared"] and active_guard[0] is not None
            assert_original()
            calls.append("commit")
            if scenario["outcome"] == "rollback":
                raise SubjectRegistryError("TWIN_VERSION_CONFLICT", "Authored rollback")
            committed_guard[0] = active_guard[0]
            if scenario["outcome"] == "uncertain":
                raise SubjectRegistryError("SELECTION_COMMIT_UNCONFIRMED", "Authored unknown outcome")
            return ("COMMITTED_CLEANUP_UNCONFIRMED" if scenario["outcome"] == "close_failure"
                    else "COMMITTED")

        def build_twin(self, *args, **kwargs):
            pytest.fail("Binding must not construct a model")

    registry = Registry()

    def getter():
        unlocked()
        calls.append("getter")
        return registry

    def snapshot_sink(name, value):
        bus_locks.append(locks())
        assert name == "twin"
        snapshots.append(deepcopy(value))
        calls.append("bus-snapshot")

    monkeypatch.setattr(server, "_subject_registry", getter)
    monkeypatch.setattr(bus, "set_snapshot", snapshot_sink)
    monkeypatch.setattr(bus, "publish", lambda *a, **k: bus_locks.append(locks()))

    def modeless(reason="MODEL_CONTEXT_UNSUPPORTED"):
        initial["tw"] = None
        initial["model_availability"].update(state="UNAVAILABLE", reason_code=reason,
            selection_mode="observations_only", preparation_available=False)
        freeze()

    def unselected():
        scenario["selected"] = False
        target_before.update(twin_id="twin-authored-unselected", subject_id="other-authored-subject",
                             lifecycle="DATA_ADMITTED")
        target_after.update(twin_id="twin-authored-unselected", subject_id="other-authored-subject",
                            lifecycle="DATA_ADMITTED")

    freeze()
    yield SimpleNamespace(client=client, server=server, authority=authority, manager=manager,
        generation=generation, store=store, store_calls=store_calls, scenario=scenario,
        target_before=target_before, target_after=target_after, before=before, initial=initial,
        old_twin=old_twin, observed=observed, actions=actions, original=original,
        calls=calls, snapshots=snapshots, bus_locks=bus_locks, freeze=freeze,
        modeless=modeless, unselected=unselected, assert_original=assert_original,
        real_commit_guard=real_commit_guard)
    # Only authored ownership can exist. Do not silently clean a tested failure.
    assert manager._adapters == {}
    client.close()


def response_context(t, response):
    UUID(response.headers["X-Request-ID"])
    assert "no-store" in response.headers["Cache-Control"]
    if "request_id" in t.scenario:
        assert response.headers["X-Request-ID"] == t.scenario["request_id"]
    assert all(value == (False, False, False) for value in t.bus_locks)


def rejected(t, response, status=503):
    assert response.status_code == status
    response_context(t, response)
    assert "commit" not in t.calls and "invalidate" not in t.calls
    assert not t.snapshots


@pytest.mark.parametrize("modeless", [False, True])
def test_confirmed_binding_uses_own_ready_or_modeless_snapshot_and_retains_live_holders(binding, modeless):
    t = binding
    if modeless:
        t.modeless()
    result = post(t, "patches")
    assert result.status_code == 200
    response_context(t, result)
    assert t.calls.count("commit") == t.calls.count("guard-exit-published") == 1
    assert t.calls.count("capture-observation-pair") == 1
    assert t.calls.index("prepare") < t.calls.index("capture-observation-pair") < t.calls.index("commit")
    assert t.calls.index("guard-exit-published") < t.calls.index("invalidate") < t.calls.index("bus-snapshot")
    assert len(t.snapshots) == 1
    snapshot = t.snapshots[0]
    assert snapshot["model_availability"] == t.server._state["model_availability"]
    assert snapshot["profile_params"] == (None if modeless else {"technical": "original"})
    assert snapshot["patch"] == sample("A")["patch"]
    assert snapshot["observations"] == sample("A")["observations"]
    if modeless:
        assert "state" not in t.calls
        assert snapshot["model_availability"]["reason_code"] == "MODEL_CONTEXT_UNSUPPORTED"


@pytest.mark.parametrize("outcome", ["COMMITTED", "close_failure", "uncertain"])
def test_unselected_binding_only_unknown_outcome_fences_and_never_publishes(binding, outcome):
    from livemorebio.aegle.execution import DENY_ALL
    t = binding
    t.unselected()
    t.scenario["outcome"] = outcome
    response = post(t, "patches")
    assert response.status_code == (200 if outcome == "COMMITTED" else 503)
    response_context(t, response)
    assert t.calls.count("commit") == 1 and not t.snapshots
    assert not any(name in t.calls for name in ("state", "modeless-projection", "capture-observation-pair"))
    if outcome == "uncertain":
        assert response.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
        assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL
        assert t.calls.count("invalidate") == 1
    else:
        t.assert_original()
        assert "invalidate" not in t.calls and "fence-new" not in t.calls


@pytest.mark.parametrize("phase", ["prepare", "final"])
@pytest.mark.parametrize("field", ["twin_id", "subject_id", "source_class", "version"])
def test_four_field_selection_agreement_at_capture_and_final_entry(binding, phase, field):
    t = binding
    if phase == "prepare":
        t.scenario["prepare_mismatch"] = field
    else:
        def change_memory():
            with t.authority.observation():
                t.initial["subject"][field] = 17 if field == "version" else "authored-later-value"
        t.scenario["before_final"] = change_memory
    result = post(t, "patches")
    rejected(t, result, 409)
    assert result.json()["code"] == "MODEL_SOURCE_CHANGED"
    assert t.authority.generation == t.generation == t.manager._permitted_generation
    if phase == "prepare":
        t.assert_original()
        assert "state" not in t.calls


@pytest.mark.parametrize("params", ["missing", [], "not-a-dictionary"])
def test_missing_or_malformed_own_snapshot_parameters_reject_before_commit(binding, params):
    t = binding
    t.scenario["params"] = params
    rejected(t, post(t, "patches"))
    t.assert_original()


@pytest.mark.parametrize("capability", [None, [], {"maturity": None}])
def test_malformed_existing_capability_is_not_silently_repaired(binding, capability):
    t = binding
    t.scenario["capability"] = capability
    rejected(t, post(t, "patches"))
    t.assert_original()


def test_ready_without_model_rejects_without_reclassification(binding):
    t = binding
    t.initial["tw"] = None
    t.freeze()
    rejected(t, post(t, "patches"))
    t.assert_original()
    assert "modeless-projection" not in t.calls


@pytest.mark.parametrize("field,value", [("twin_id", "wrong-authored-id"), ("twin_version", 1),
                                          ("source_generation", "stale-authored-generation")])
def test_captured_availability_identity_is_checked_before_relabeling(binding, field, value):
    t = binding
    t.modeless()
    # The modeless accessor refreshes generation. The route must check stored
    # modeless identity before that refresh can hide incoherent source metadata.
    t.initial["model_availability"][field] = value
    t.freeze()
    rejected(t, post(t, "patches"))
    t.assert_original()


def test_generation_change_during_unlocked_projection_prevents_commit(binding):
    t = binding
    def later_generation():
        with t.real_commit_guard():
            t.authority.install_generation("authored-new-winner")
    t.scenario["during_projection"] = later_generation
    result = post(t, "patches")
    rejected(t, result, 409)
    assert t.authority.generation == t.manager._permitted_generation == "authored-new-winner"


@pytest.mark.parametrize("modeless", [False, True])
@pytest.mark.parametrize("initially_connected", [False, True])
def test_captured_packet_pair_and_clocks_stay_coherent_while_new_sample_remains_live(binding, modeless, initially_connected):
    t = binding
    if modeless:
        t.modeless()
    holder = t.observed if modeless else t.old_twin
    a, b = sample("A", initially_connected), sample("B")
    holder.patch, holder.observations = deepcopy(a["patch"]), deepcopy(a["observations"])
    def admit_authored_sample():
        with t.authority.observation():
            holder.observations = deepcopy(b["observations"])
            holder.patch = deepcopy(b["patch"])
    t.scenario["during_projection"] = admit_authored_sample
    result = post(t, "patches")
    assert result.status_code == 200
    response_context(t, result)
    assert len(t.snapshots) == 1 and t.calls.count("capture-observation-pair") == 1
    snapshot = t.snapshots[0]
    assert {key: snapshot[key] for key in a} == a
    assert holder.patch == b["patch"] and holder.observations == b["observations"]
    assert (t.server._state["observation_state"] if modeless else t.server._state["tw"]) is holder
    if not modeless:
        assert snapshot["capability"]["maturity"] == {
            "packet_admitted": initially_connected, "model_qualified": False}
        assert snapshot["provenance"] == {"data_class": "AUTHORED_TEST_ONLY"}
        assert snapshot["applied"] == ["unchanged-history"]


def test_observation_arriving_before_final_guard_is_not_replaced_by_detached_snapshot(binding):
    t = binding
    t.modeless()
    b = sample("B")
    def late_observation():
        with t.authority.observation():
            t.observed.patch = deepcopy(b["patch"])
            t.observed.observations = deepcopy(b["observations"])
    t.scenario["before_final"] = late_observation
    result = post(t, "patches")
    assert result.status_code == 200
    response_context(t, result)
    assert t.server._state["observation_state"] is t.observed
    assert t.observed.observations == b["observations"]
    assert t.snapshots[0]["observations"] == sample("A")["observations"]


def test_later_postcommit_winner_cannot_supply_binding_snapshot_parameters(binding):
    t = binding
    winner = SimpleNamespace(state=lambda: pytest.fail("Old binding borrowed later winner state"))
    def select_later():
        with t.real_commit_guard():
            t.authority.install_generation("authored-postcommit-winner")
            t.server._state = {**t.server._state, "tw": winner,
                              "subject": {**t.before, "twin_id": "later-authored-winner", "version": 9}}
    t.scenario["after_cleanup"] = select_later
    result = post(t, "patches")
    assert result.status_code == 200
    response_context(t, result)
    assert t.authority.generation == t.manager._permitted_generation == "authored-postcommit-winner"
    assert t.server._state["tw"] is winner
    assert len(t.snapshots) == 1
    assert t.snapshots[0]["profile_params"] == {"technical": "original"}
    assert t.snapshots[0]["model_availability"]["twin_id"] == t.before["twin_id"]
    assert t.snapshots[0]["model_availability"]["twin_version"] == 3
    assert t.snapshots[0]["model_availability"]["source_generation"] != t.authority.generation


@pytest.mark.parametrize("selected,outcome", [(True, "COMMITTED"), (True, "uncertain"), (False, "COMMITTED")])
def test_closed_real_manager_retains_owner_and_only_explicit_shutdown_retries(binding, selected, outcome):
    from livemorebio.aegle import execution_api
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.execution_contract import ExecutionError
    t = binding
    if not selected:
        t.unselected()
    t.scenario["outcome"] = outcome
    t.manager._owners[OWNER_ID] = t.store.owner
    with pytest.raises(ExecutionError, match="cleanup"):
        execution_api.shutdown_execution_manager()
    assert t.manager._closed and t.server._execution_manager_instance is t.manager
    before_calls = tuple(t.store_calls)
    result = post(t, "patches")
    assert result.status_code == (503 if selected else 200)
    response_context(t, result)
    assert tuple(t.store_calls) == before_calls
    assert t.manager._closed and t.server._execution_manager_instance is t.manager
    assert t.manager._owners == {OWNER_ID: t.store.owner}
    assert t.manager._cleanup_pending == {OWNER_ID} and t.manager._closing == set()
    if outcome == "uncertain":
        assert result.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
        assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL
        assert not t.snapshots
    elif selected:
        assert result.json()["code"] == "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
        assert t.authority.generation == t.manager._permitted_generation != t.generation
        assert t.server._state["subject"]["version"] == 3 and len(t.snapshots) == 1
    else:
        t.assert_original()
        assert not t.snapshots and "invalidate" not in t.calls
    t.store.fail = False
    execution_api.shutdown_execution_manager()
    assert t.server._execution_manager_instance is None and t.manager._closed
    assert t.manager._owners == {} and t.manager._cleanup_pending == set()
    assert t.store_calls[-2:] == ["store-get-retry", "release-retry"]


@pytest.mark.parametrize("outcome", ["prepare_failure", "rollback"])
def test_confirmed_rejection_keeps_old_identity_and_does_not_publish(binding, outcome):
    t = binding
    t.scenario["outcome"] = outcome
    result = post(t, "patches")
    assert result.status_code == 409
    response_context(t, result)
    t.assert_original()
    assert not t.snapshots and "invalidate" not in t.calls
    assert t.calls.count("commit") == (1 if outcome == "rollback" else 0)
