"""Raw scientific JSON must be admitted identically by terminal, browser and API."""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
import shlex
import subprocess
from unittest.mock import Mock

import pytest
from starlette.requests import Request

from livemorebio.aegle.research_api import body
from livemorebio.research import ResearchError
from livemorebio.sdk import Platform
from livemorebio.shell import run_command
from ._node import require_node, run_node as _run_node


CONSOLE = Path(__file__).parents[1] / "aegle/console"
INVALID = [
    '{"mapping":{"sample-1":"member-a","sample-1":"member-b"}}',
    '{"mapping":{"sample-1":"member-a","sample-\\u0031":"member-b"}}',
    '{"ignored":NaN}', '{"ignored":Infinity}', '{"ignored":-Infinity}',
    '{"ignored":1e999}', '{"ignored":9007199254740993}',
    '{"ignored":' + "[" * 65 + "0" + "]" * 65 + "}",
    '{"a":1,}', '{"a":"unterminated}', '[]', 'null',
]


def _browser_parse(raw_values: list[str]) -> list[dict]:
    node = require_node()
    program = f"""
import {{ parseStrictJSONObject }} from {json.dumps((CONSOLE / 'lib/strict_json.js').as_uri())};
let input = ''; for await (const chunk of process.stdin) input += chunk;
const output = JSON.parse(input).map(raw => {{
  try {{ const value = parseStrictJSONObject(raw); return {{ok:true,value,
    nullPrototype:Object.getPrototypeOf(value)===null,
    pollution:Object.prototype.polluted ?? null}}; }}
  catch(error) {{ return {{ok:false,error:error.message}}; }}
}});
process.stdout.write(JSON.stringify(output));
"""
    completed = _run_node([node, "--input-type=module", "--eval", program],
                               input=json.dumps(raw_values), capture_output=True, text=True,
                               check=True, timeout=20, encoding="utf-8")
    return json.loads(completed.stdout)


@pytest.mark.parametrize("command", ["freeze", "import", "resilience", "learn", "source-import"])
@pytest.mark.parametrize("raw", INVALID)
def test_terminal_rejects_ambiguous_json_before_sdk_dispatch(tmp_path: Path, command: str, raw: str) -> None:
    path = tmp_path / "scientific-input.json"
    path.write_text(raw, encoding="utf-8")
    platform = Mock()
    with pytest.raises(ValueError):
        run_command(platform, f"research {command} {shlex.quote(str(path))}")
    assert not platform.mock_calls


@pytest.mark.parametrize("raw", INVALID)
def test_shared_parser_and_http_body_reject_same_input(raw: str) -> None:
    from livemorebio.strict_json import StrictJSONError, parse_json_object

    with pytest.raises(StrictJSONError):
        parse_json_object(raw)

    async def receive() -> dict:
        return {"type": "http.request", "body": raw.encode(), "more_body": False}

    request = Request({"type": "http"}, receive)
    with pytest.raises(ResearchError):
        asyncio.run(body(request))


def test_browser_rejects_same_ambiguity_without_exposing_payload() -> None:
    results = _browser_parse(INVALID)
    assert all(not result["ok"] for result in results)
    assert all("member-a" not in result["error"] and "sample-1" not in result["error"]
               for result in results)


def test_valid_content_is_preserved_and_prototype_keys_are_only_data() -> None:
    from livemorebio.strict_json import parse_json_object

    raw = r'{"mapping":{"sample-1":"member-a"},"__proto__":{"polluted":true},"constructor":{"prototype":{"polluted":true}},"claim":"Paragraph one\nParagraph two","escaped":"quote: \" braces: { [","values":[1,-2,0.15,2.5e-4,true,null],"unicode":"é"}'
    parsed = parse_json_object(raw)
    result = _browser_parse([raw])[0]
    assert result["ok"] and result["value"] == parsed
    assert result["nullPrototype"] is True and result["pollution"] is None


def test_byte_and_depth_limits_are_consistent() -> None:
    from livemorebio.strict_json import StrictJSONError, parse_json_object

    too_large = json.dumps({"text": "é" * 1_000_000}, ensure_ascii=False)
    shallow = '{"a":' + "[" * 63 + "0" + "]" * 63 + "}"
    with pytest.raises(StrictJSONError, match="2 MB"):
        parse_json_object(too_large)
    assert parse_json_object(shallow)
    results = _browser_parse([too_large, shallow])
    assert results[0]["ok"] is False and "2 MB" in results[0]["error"]
    assert results[1]["ok"] is True


def test_terminal_preserves_valid_sdk_arguments_without_printing_payload(tmp_path: Path) -> None:
    payload = {"run_id": "protocol-technical", "mapping": {"sample-1": "member-a"},
               "rationale": "First paragraph\nSecond paragraph"}
    path = tmp_path / "criteria.json"
    path.write_text(json.dumps(payload), encoding="utf-8")
    platform = Mock()
    platform.freeze_research_study.return_value = {"id": "research-technical", "status": "AWAITING_MEASUREMENTS"}
    output = []
    run_command(platform, f"research freeze {shlex.quote(str(path))}", out=output.append)
    platform.freeze_research_study.assert_called_once_with("protocol-technical", {
        "mapping": {"sample-1": "member-a"}, "rationale": payload["rationale"]})
    assert "member-a" not in " ".join(output)


@pytest.mark.parametrize("command,payload,route,expected", [
    ("freeze", {"run_id": "protocol-technical", "mapping": {"sample-1": "member-a"}},
     "/api/research/studies", {"run_id": "protocol-technical", "mapping": {"sample-1": "member-a"}}),
    ("import", {"study_id": "study-technical", "csv": "header\nrow"},
     "/api/research/studies/study-technical/measurements", {"csv": "header\nrow"}),
    ("resilience", {"subjects": [{"subject_id": "member-a"}]},
     "/api/research/resilience", {"subjects": [{"subject_id": "member-a"}]}),
    ("learn", {"claim": "First paragraph\nSecond paragraph"},
     "/api/research/learning", {"claim": "First paragraph\nSecond paragraph"}),
    ("source-import", {"manifest": {"source_id": "kegg"}, "records": []},
     "/api/research/sources/import", {"manifest": {"source_id": "kegg"}, "records": []}),
])
def test_terminal_research_uses_actual_sdk_api_route(tmp_path: Path, command: str,
                                                   payload: dict, route: str, expected: dict) -> None:
    path = tmp_path / "research.json"
    path.write_text(json.dumps(payload), encoding="utf-8")
    platform = Platform(mode="attach")
    platform._post = Mock(return_value={"id": "research-technical"})
    run_command(platform, f"research {command} {shlex.quote(str(path))}", out=lambda _: None)
    platform._post.assert_called_once_with(route, expected)


def test_invalid_utf8_and_boolean_root_are_rejected() -> None:
    from livemorebio.strict_json import StrictJSONError, parse_json_object

    for raw in (b'{"claim":"\xff"}', b"true", b'"text"'):
        with pytest.raises(StrictJSONError):
            parse_json_object(raw)


def test_research_json_forms_use_strict_parser() -> None:
    script = (CONSOLE / "lib/research.js").read_text(encoding="utf-8")
    assert "import { parseStrictJSONObject } from './strict_json.js';" in script
    assert "JSON.parse(" not in script
    assert script.count("parseStrictJSONObject(") == 3
