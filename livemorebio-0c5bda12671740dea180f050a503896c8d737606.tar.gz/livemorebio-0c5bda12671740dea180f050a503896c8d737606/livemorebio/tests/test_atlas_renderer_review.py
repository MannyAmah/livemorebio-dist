"""Red-first producer/consumer and interaction regressions from independent review."""
from __future__ import annotations

import json

import pytest

from ._node import flush_js
from .test_atlas_reference_ui import CONSOLE, node, technical_manifest


def test_canonical_producer_membership_key_order_is_not_geometry_identity():
    module = (CONSOLE / 'lib/atlas_reference_contract.js').as_uri()
    assert node(f"""import {{validateAtlasManifest}} from {json.dumps(module)};
const manifest={json.dumps(technical_manifest(), sort_keys=True)};
validateAtlasManifest(manifest,'a'.repeat(64));
for(const change of [item=>item.logic='isa',item=>item.extra='not-admitted']){{
  const bad=structuredClone(manifest);change(bad.assets[1].audit.nodes[0].memberships[0]);
  let failed=false;try{{validateAtlasManifest(bad,'a'.repeat(64))}}catch{{failed=true}}
  if(!failed)throw Error('changed membership accepted');
}}
console.log('ok');""").strip() == 'ok'


@pytest.mark.parametrize('fault', [None, 'shape', 'unavailable', 'reused', 'receipt', 'extra',
                                    'source', 'digest', 'identifier', 'naive', 'calendar',
                                    'reverse', 'microsecond', 'offset', 'offset_valid'])
def test_install_acknowledgment_is_typed_exact_and_time_ordered(fault):
    module = (CONSOLE / 'lib/atlas_reference_contract.js').as_uri()
    assert node(f"""import {{validateAtlasInstall}} from {json.dumps(module)};
const fault={json.dumps(fault)},value={{schema:'livemore.atlas-reference-status.v1',
 source_id:'bp3d-4.0-20130619-surface-core-v1',state:'available',available:true,
 reference_geometry:true,patient_registered:false,manifest:{json.dumps(technical_manifest(), sort_keys=True)},
 manifest_sha256:'a'.repeat(64),reused:false,
 receipt:{{receipt_id:'b'.repeat(32),source_id:'bp3d-4.0-20130619-surface-core-v1',
 manifest_sha256:'a'.repeat(64),started_at:'2026-09-08T14:00:00.000001+00:00',completed_at:'2026-09-08T14:00:00.000002+00:00'}}}};
if(fault==='shape')delete value.schema;if(fault==='unavailable'){{value.available=false;value.state='missing';value.manifest=null;value.manifest_sha256=null}}
if(fault==='reused')value.reused=1;if(fault==='receipt')delete value.receipt;
if(fault==='extra')value.receipt.extra=true;if(fault==='source')value.receipt.source_id='other';
if(fault==='digest')value.receipt.manifest_sha256='c'.repeat(64);if(fault==='identifier')value.receipt.receipt_id='bad';
if(fault==='naive')value.receipt.started_at='2026-09-08T14:00:00';
if(fault==='calendar')value.receipt.started_at='2026-02-30T14:00:00Z';
if(fault==='reverse')value.receipt.started_at='2026-09-09T14:00:00Z';
if(fault==='microsecond')value.receipt.started_at='2026-09-08T14:00:00.000003+00:00';
if(fault==='offset')value.receipt.started_at='2026-09-08T14:00:00-00:01';
if(fault==='offset_valid')value.receipt.started_at='2026-09-08T15:00:00.000001+01:00';
let rejected=false;try{{validateAtlasInstall(value)}}catch{{rejected=true}}
if(rejected !== (fault!==null && fault!=='offset_valid'))throw Error('wrong receipt verdict '+fault);
console.log('ok');""").strip() == 'ok'


def _controller_program(checks: str) -> str:
    return f"""import {{mountAtlasReference}} from {json.dumps((CONSOLE / 'lib/atlas_reference.js').as_uri())};
import {{atlasViewState}} from {json.dumps((CONSOLE / 'lib/atlas_reference_scene.js').as_uri())};
const all=[],handlers={{}},views=[];
class E{{constructor(){{this.handlers={{}};this.dataset={{}};this.children=[];this.value='';this.style={{}};this.disabled=false;this.hidden=false;all.push(this)}}
addEventListener(k,v){{this.handlers[k]=v}}removeEventListener(k){{delete this.handlers[k]}}setAttribute(){{}}append(...items){{this.children.push(...items)}}replaceChildren(...items){{this.children=items}}get options(){{return this.children}}}}
const elements=new Map(),host=new E();
host.querySelector=s=>{{if(!elements.has(s))elements.set(s,new E());return elements.get(s)}};
for(const direction of ['front','side','back']){{const button=host.querySelector('[data-view="'+direction+'"]');button.dataset.view=direction}}
host.querySelectorAll=s=>s==='[data-group]'?all.filter(e=>e.dataset.group):s==='[data-view]'?all.filter(e=>e.dataset.view):[];
globalThis.document={{hidden:false,createElement:()=>new E(),createTextNode:text=>({{textContent:text}}),addEventListener(k,v){{handlers[k]=v}},removeEventListener(k){{delete handlers[k]}}}};
const manifest={json.dumps(technical_manifest())},bytes=new Uint8Array(100),hash=Buffer.from(await crypto.subtle.digest('SHA-256',bytes)).toString('hex');manifest.assets.forEach(a=>a.sha256=hash);
const available={{schema:'livemore.atlas-reference-status.v1',source_id:manifest.source_id,state:'available',available:true,reference_geometry:true,patient_registered:false,manifest,manifest_sha256:'a'.repeat(64)}};
const missing={{...available,state:'missing',available:false,manifest:null,manifest_sha256:null,reason:'No admitted reference'}};
let current=missing,posts=0,sceneConfig=null,applied=[],reply=null;const failedAssets=new Set();
const fetchImpl=async(url,init)=>{{if(init.method==='POST'){{posts++;current=available;return Response.json(reply||{{unexpected:'not-an-install-receipt'}})}}
if(url.startsWith('/api/'))return Response.json(current);
if([...failedAssets].some(key=>url.endsWith('/'+key+'.glb')))return new Response('Technical unavailable',{{status:503}});
return new Response(bytes,{{headers:{{'Content-Type':'model/gltf-binary','X-Content-SHA256':hash,'X-Atlas-Manifest-SHA256':'a'.repeat(64)}}}})}};
const createScene=config=>{{sceneConfig=config;let view=atlasViewState(config.initialView);return{{
 async addPartition(asset){{applied.push(asset.asset_key)}},view:()=>atlasViewState(view),update:next=>view=atlasViewState(next),
 select:id=>{{view.selected=id;config.onSelect(id)}},home(){{}},dispose(){{}},visible(){{}},metrics:()=>({{}})}}}};
{flush_js(50)}
const mounted=mountAtlasReference(host,{{fetchImpl,loadDependencies:async()=>({{}}),createScene,onViewChange:v=>views.push(v)}});
await flush();
try{{{checks}}}finally{{mounted.dispose()}}
console.log('ok');"""


def test_missing_drawn_and_context_lost_controls_publish_real_availability():
    assert node(_controller_program(r"""
const selectors=['[data-view="front"]','[data-view="side"]','[data-view="back"]','[data-skin]',
'[data-search]','[data-results]','[data-axis]','[data-depth]','[data-opacity]','[data-labels]','[data-clear]'];
for(const selector of selectors)if(!elements.get(selector)?.disabled)throw Error('enabled missing control '+selector);
if(views.at(-1)?.ready!==false)throw Error('header aliases lack missing availability');
current=available;elements.get('[data-retry]').handlers.click();await flush();
if(applied.length!==9||elements.get('[data-view="front"]').disabled||elements.get('[data-skin]').disabled||views.at(-1)?.ready!==true)throw Error('drawn geometry actions unavailable');
if(!elements.get('[data-depth]').disabled)throw Error('section-off position action enabled');
sceneConfig.onContextLost();
for(const selector of selectors)if(!elements.get(selector)?.disabled)throw Error('enabled lost-context control '+selector);
if(views.at(-1)?.ready!==false)throw Error('header aliases lack lost availability');
""")).strip() == 'ok'


def test_available_status_does_not_acknowledge_malformed_install_response():
    assert node(_controller_program(r"""
await elements.get('[data-install]').handlers.click();await flush();
if(posts!==1||host.dataset.referenceState!=='ready')throw Error('separate readable geometry absent');
const ack=elements.get('[data-install-ack]');
if(!ack||ack.hidden||!/unconfirmed/i.test(ack.textContent)||/not-an-install-receipt/.test(ack.textContent))throw Error('mutation uncertainty erased or raw response echoed');
elements.get('[data-retry]').handlers.click();await flush();
if(posts!==1||!/unconfirmed/i.test(ack.textContent))throw Error('refresh retried or erased uncertain mutation');
""")).strip() == 'ok'


def test_external_body_buttons_consume_scene_availability():
    script = (CONSOLE / 'lib/workspace.js').read_text(encoding="utf-8")
    assert '$("#body-home").disabled = !view.ready' in script
    assert '$("#body-labels").disabled = !view.ready' in script


def test_partial_geometry_disables_only_unavailable_source_partition_controls():
    assert node(_controller_program(r"""
failedAssets.add('brain');current=available;elements.get('[data-retry]').handlers.click();await flush();
if(applied.length!==8||host.dataset.referenceState!=='partial')throw Error('partial source fixture absent');
const layers=host.querySelectorAll('[data-group]');
if(!layers.find(node=>node.dataset.group==='brain').disabled||layers.find(node=>node.dataset.group==='heart').disabled)throw Error('partition availability not respected');
elements.get('[data-search]').value='FJ1730';elements.get('[data-search]').handlers.input();
if(!elements.get('[data-results]').options[0]?.disabled)throw Error('undrawn source search result enabled');
""")).strip() == 'ok'


def test_valid_install_receipt_remains_distinct_from_current_geometry_status():
    assert node(_controller_program(r"""
reply={...available,reused:false,receipt:{receipt_id:'b'.repeat(32),source_id:available.source_id,
 manifest_sha256:available.manifest_sha256,started_at:'2026-09-08T14:00:00.000001+00:00',completed_at:'2026-09-08T14:00:00.000002+00:00'}};
await elements.get('[data-install]').handlers.click();await flush();
const ack=elements.get('[data-install-ack]');
if(posts!==1||!ack||ack.hidden||!/acknowledged/i.test(ack.textContent)||!ack.textContent.includes('b'.repeat(32))||!ack.textContent.includes('a'.repeat(64)))throw Error('exact acknowledgment missing');
current=missing;elements.get('[data-retry]').handlers.click();await flush();
if(host.dataset.referenceState!=='unavailable'||!/acknowledged/i.test(ack.textContent))throw Error('current status rewrote historical acknowledgment');
""")).strip() == 'ok'
