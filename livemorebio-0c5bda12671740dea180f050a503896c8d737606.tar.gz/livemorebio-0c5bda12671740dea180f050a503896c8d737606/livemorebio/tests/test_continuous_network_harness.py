"""The endurance harness must admit ordinary in-flight delivery, not stalled work."""
import pytest

from tools.check_continuous_network import delivery_progress, drain_complete, interrupted, NetworkCheckInterrupted


def test_inflight_pending_is_not_itself_a_delivery_failure():
    assert delivery_progress({"state": "streaming", "has_pending": True, "last_forwarded": 4},
        previous=4, changed_at=10., now=12.) == (4, 10.)
    assert delivery_progress({"state": "streaming", "has_pending": False, "last_forwarded": 5},
        previous=4, changed_at=10., now=12.) == (5, 12.)


@pytest.mark.parametrize("change,now", [({"state": "blocked"}, 12.), ({"last_forwarded": 3}, 12.),
    ({"last_forwarded": True}, 12.), ({}, 26.)])
def test_blocked_rollback_wrong_counter_and_stall_fail(change, now):
    with pytest.raises(AssertionError):
        delivery_progress({"state": "streaming", "has_pending": True, "last_forwarded": 4} | change,
            previous=4, changed_at=10., now=now)


def test_complete_but_late_drain_does_not_pass():
    with pytest.raises(AssertionError):
        drain_complete(cursor=4, final_index=4, session={"last_forwarded": 4, "has_pending": False},
            deadline=15., now=15.001)
    assert drain_complete(cursor=4, final_index=4,
        session={"last_forwarded": 4, "has_pending": False}, deadline=15., now=14.)


def test_signal_is_a_controlled_failure_not_success():
    with pytest.raises(NetworkCheckInterrupted):
        interrupted(15, None)


def test_late_new_ack_does_not_erase_an_observation_gap():
    with pytest.raises(AssertionError):
        delivery_progress({"state": "streaming", "has_pending": False, "last_forwarded": 5},
            previous=4, changed_at=10., now=30.)
