"""Technical fake-clock tests for the prospective LIFE-only lease contract."""
from __future__ import annotations

from copy import deepcopy
import threading
import time

import pytest

from livemorebio.tests.test_continuous_execution import TechnicalAdapter, captured_source


def setup(tmp_path, *, adapter=TechnicalAdapter):
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_store import ExecutionStore
    clock = [100.]
    engine = ExecutionManager(ExecutionStore(tmp_path / "lease.sqlite3", key=b"l" * 32),
        adapter_registry={"metabolic-continuous-v1": adapter}, run_background=False,
        clock=lambda: clock[0])
    record = engine.prepare(captured_source(), {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "lease")
    return engine, clock, record


def bind(engine, record):
    return engine.bind_consumer(record["execution_id"], "a" * 32, record["source_snapshot_hash"],
        expected_revision=record["revision"], expected_source_generation="generation-a")


def test_binding_prepared_is_not_execution_and_renewal_does_not_change_revision(tmp_path):
    engine, clock, record = setup(tmp_path)
    try:
        bound = bind(engine, record)
        assert bound["state"] == "prepared" and engine._adapters == {}
        clock[0] += 5
        renewed = engine.renew_consumer(record["execution_id"], "a" * 32, record["source_snapshot_hash"],
                                      expected_source_generation="generation-a")
        assert renewed["revision"] == bound["revision"]
        assert renewed["consumer_lease"]["remaining_s"] == 30.
        assert engine.frames(record["execution_id"])["frames"] == []
        with pytest.raises(ValueError):
            engine.renew_consumer(record["execution_id"], "b" * 32, record["source_snapshot_hash"],
                                  expected_source_generation="generation-a")
    finally:
        engine.close()


def test_lease_expiry_fences_candidate_and_requires_explicit_resume(tmp_path):
    engine, clock, record = setup(tmp_path)
    try:
        record = bind(engine, record)
        engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        engine.advance_once(record["execution_id"])
        previous = deepcopy(engine.store.get(record["execution_id"])["checkpoint"])
        clock[0] = 130.
        assert engine.advance_once(record["execution_id"]) is None
        expired = engine.status(record["execution_id"])
        assert expired["state"] == "paused" and expired["failure_code"] == "EXECUTION_CONSUMER_EXPIRED"
        assert engine.store.get(record["execution_id"])["checkpoint"] == previous
        renewed = engine.renew_consumer(record["execution_id"], "a" * 32, record["source_snapshot_hash"],
                                      expected_source_generation="generation-a")
        assert renewed["state"] == "paused"
        engine.resume(record["execution_id"], expected_revision=renewed["revision"], expected_source_generation="generation-a")
        frame = engine.advance_once(record["execution_id"])
        assert frame["native_start"] == 1. and frame["native_end"] == 2.
    finally:
        engine.close()


def test_expiry_between_dispatch_and_commit_never_publishes_late_frame(tmp_path):
    engine, clock, record = setup(tmp_path)
    record = bind(engine, record)
    engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
    TechnicalAdapter.entered, TechnicalAdapter.release = threading.Event(), threading.Event()
    thread = threading.Thread(target=lambda: engine.advance_once(record["execution_id"]))
    try:
        thread.start()
        assert TechnicalAdapter.entered.wait(2)
        clock[0] = 131.
        TechnicalAdapter.release.set()
        thread.join(3)
        assert engine.status(record["execution_id"])["state"] == "paused"
        assert engine.frames(record["execution_id"])["frames"] == []
    finally:
        TechnicalAdapter.release.set()
        TechnicalAdapter.entered = TechnicalAdapter.release = None
        engine.close()


def test_unbound_execution_and_source_invalidation_are_distinct_from_lease(tmp_path):
    engine, clock, record = setup(tmp_path)
    try:
        engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        clock[0] = 99999.
        assert engine.advance_once(record["execution_id"])["native_end"] == 1.
        assert engine.status(record["execution_id"])["consumer_lease"]["state"] == "unbound"
        engine.invalidate_source("generation-a", "source_changed")
        assert engine.advance_once(record["execution_id"]) is None
    finally:
        engine.close()


def test_expired_initialization_can_be_explicitly_reinitialized(tmp_path):
    entered, released, closed = threading.Event(), threading.Event(), threading.Event()

    class InitializingAdapter(TechnicalAdapter):
        count = 0

        def initialize(self):
            type(self).count += 1
            if type(self).count == 1:
                entered.set()
                assert released.wait(3)
            return super().initialize()

        def close(self):
            closed.set()
            released.set()

    engine, clock, record = setup(tmp_path, adapter=InitializingAdapter)
    record = bind(engine, record)
    failures = []

    def start():
        try:
            engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        except ValueError as error:
            failures.append(error)

    worker = threading.Thread(target=start)
    try:
        worker.start()
        assert entered.wait(2)
        clock[0] = 130.
        assert engine.status(record["execution_id"])["state"] == "paused"
        assert closed.wait(1)
        worker.join(3)
        assert not worker.is_alive() and len(failures) == 1
        paused = engine.status(record["execution_id"])
        assert paused["state"] == "paused"
        assert engine.store.get(record["execution_id"])["checkpoint"] is None
        renewed = engine.renew_consumer(record["execution_id"], "a" * 32, record["source_snapshot_hash"],
                                      expected_source_generation="generation-a")
        running = engine.resume(record["execution_id"], expected_revision=renewed["revision"], expected_source_generation="generation-a")
        assert running["state"] == "running" and InitializingAdapter.count == 2
        assert engine.frames(record["execution_id"])["frames"] == []
    finally:
        released.set()
        worker.join(3)
        engine.close()


def test_renewal_during_native_job_keeps_revision_and_admits_candidate_once(tmp_path):
    engine, clock, record = setup(tmp_path)
    record = bind(engine, record)
    running = engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
    TechnicalAdapter.entered, TechnicalAdapter.release = threading.Event(), threading.Event()
    worker = threading.Thread(target=lambda: engine.advance_once(record["execution_id"]))
    try:
        worker.start()
        assert TechnicalAdapter.entered.wait(2)
        clock[0] = 129.
        for _ in range(5):
            renewed = engine.renew_consumer(record["execution_id"], "a" * 32, record["source_snapshot_hash"],
                                          expected_source_generation="generation-a")
            assert renewed["revision"] == running["revision"]
        clock[0] = 135.
        TechnicalAdapter.release.set()
        worker.join(3)
        assert not worker.is_alive()
        assert len(engine.frames(record["execution_id"])["frames"]) == 1
    finally:
        TechnicalAdapter.release.set()
        TechnicalAdapter.entered = TechnicalAdapter.release = None
        engine.close()


def test_previous_process_lease_cannot_be_renewed_or_started(tmp_path):
    from livemorebio.aegle.execution import ExecutionManager
    engine, clock, record = setup(tmp_path)
    record = bind(engine, record)
    engine.close()
    restarted = ExecutionManager(engine.store, adapter_registry={"metabolic-continuous-v1": TechnicalAdapter},
                                 run_background=False, clock=lambda: clock[0])
    try:
        assert restarted.status(record["execution_id"])["consumer_lease"]["state"] == "restart_required"
        with pytest.raises(ValueError):
            restarted.renew_consumer(record["execution_id"], "a" * 32, record["source_snapshot_hash"],
                                     expected_source_generation="generation-a")
        with pytest.raises(ValueError):
            restarted.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        assert restarted._adapters == {}
    finally:
        restarted.close()


def test_wrong_source_and_invalidated_source_cannot_renew(tmp_path):
    engine, clock, record = setup(tmp_path)
    try:
        record = bind(engine, record)
        for snapshot, generation in [("0" * 64, "generation-a"), (record["source_snapshot_hash"], "other")]:
            with pytest.raises(ValueError):
                engine.renew_consumer(record["execution_id"], "a" * 32, snapshot,
                                      expected_source_generation=generation)
        engine.invalidate_source("generation-a", "source_changed")
        with pytest.raises(ValueError):
            engine.renew_consumer(record["execution_id"], "a" * 32, record["source_snapshot_hash"],
                                  expected_source_generation="generation-a")
        assert engine.status(record["execution_id"])["consumer_lease"]["state"] == "source_invalid"
    finally:
        engine.close()


@pytest.mark.parametrize("action", ["bind", "start"])
def test_failed_initial_transition_does_not_leak_new_owner(tmp_path, monkeypatch, action):
    from livemorebio.aegle.execution_contract import ExecutionError
    engine, clock, record = setup(tmp_path)
    original = engine.store.update
    try:
        monkeypatch.setattr(engine.store, "update", lambda *args, **kwargs: (_ for _ in ()).throw(ExecutionError("EXECUTION_STORAGE")))
        with pytest.raises(ValueError):
            if action == "bind":
                bind(engine, record)
            else:
                engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        assert engine._owners == {}
    finally:
        monkeypatch.setattr(engine.store, "update", original)
        engine.close()


def test_just_before_deadline_commit_is_valid(tmp_path):
    engine, clock, record = setup(tmp_path)
    try:
        record = bind(engine, record)
        engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        clock[0] = 129.999
        assert engine.advance_once(record["execution_id"])["frame_index"] == 1
        clock[0] = 130.
        assert engine.frames(record["execution_id"])["execution"]["state"] == "paused"
    finally:
        engine.close()


def test_late_renewal_without_an_intervening_read_cannot_hide_expiry(tmp_path):
    engine, clock, record = setup(tmp_path)
    try:
        record = bind(engine, record)
        running = engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        clock[0] = 130.
        renewed = engine.renew_consumer(record["execution_id"], "a" * 32, record["source_snapshot_hash"],
                                      expected_source_generation="generation-a")
        assert renewed["state"] == "paused" and renewed["revision"] == running["revision"] + 1
        assert engine.advance_once(record["execution_id"]) is None
    finally:
        engine.close()


def test_scheduler_expires_while_its_numerical_interval_is_blocked(tmp_path):
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_store import ExecutionStore
    entered, released, closed = threading.Event(), threading.Event(), threading.Event()
    clock = [100.]

    class BlockedAdapter(TechnicalAdapter):
        def advance(self, checkpoint, native_end):
            entered.set()
            assert released.wait(3)
            return super().advance(checkpoint, native_end)

        def close(self):
            closed.set()
            released.set()

    engine = ExecutionManager(ExecutionStore(tmp_path / "blocked.sqlite3", key=b"t" * 32),
        adapter_registry={"metabolic-continuous-v1": BlockedAdapter}, clock=lambda: clock[0])
    try:
        record = engine.prepare(captured_source(), {"end_native": 3., "frame_period_s": 1., "time_scale": 60.}, "blocked")
        record = bind(engine, record)
        engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        clock[0] = 101.
        assert entered.wait(2)
        clock[0] = 130.
        started = time.monotonic()
        assert closed.wait(2)
        # A generous CI bound, not a measured real-service 100-ms guarantee.
        assert time.monotonic() - started < 2.
        assert engine.status(record["execution_id"])["state"] == "paused"
        assert engine.frames(record["execution_id"])["frames"] == []
    finally:
        released.set()
        engine.close()


def test_constructor_failure_releases_owner_without_an_adapter_instance(tmp_path):
    def fails_before_returning(source):
        raise RuntimeError("technical constructor failure")

    engine, clock, record = setup(tmp_path, adapter=fails_before_returning)
    try:
        record = bind(engine, record)
        with pytest.raises(ValueError):
            engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        assert engine.store.get(record["execution_id"])["state"] == "failed"
        assert engine._owners == {} and engine._adapters == {}
        owner = engine.store.acquire_owner(record["execution_id"])
        engine.store.release_owner(owner)
    finally:
        engine.close()


def test_frame_generation_records_actual_producer_monotonic_clock(tmp_path):
    engine, clock, record = setup(tmp_path)
    try:
        engine.start(record["execution_id"], expected_revision=record["revision"], expected_source_generation="generation-a")
        clock[0] = 105.5
        frame = engine.advance_once(record["execution_id"])
        assert frame["generated_monotonic_s"] == 105.5
    finally:
        engine.close()
