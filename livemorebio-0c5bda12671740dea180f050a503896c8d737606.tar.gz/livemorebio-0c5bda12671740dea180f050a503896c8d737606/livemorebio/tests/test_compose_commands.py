"""Socketless compose command contracts; all values and paths are technical."""

import os
from pathlib import Path
import shutil
import subprocess
import sys

import pytest

from livemorebio import cli, security


COMPOSE_SECRETS = (
    "LIVEMORE_API_TOKEN",
    "LIVEMORE_PATCH_STORAGE_KEY",
    "LIVEMORE_PATCH_ADMISSION_HMAC_KEY",
    "LIVEMORE_SERVICE_IDENTITY_KEY",
)


@pytest.fixture
def technical_compose(monkeypatch, tmp_path):
    project = tmp_path / "technical project's checkout"
    package = project / "livemorebio"
    package.mkdir(parents=True)
    compose_file = project / "docker-compose.yml"
    compose_file.write_text("services: {}\n", encoding="utf-8")
    monkeypatch.setattr(cli, "__file__", str(package / "cli.py"))
    monkeypatch.setattr(shutil, "which", lambda name: "/technical/docker" if name == "docker" else None)
    elsewhere = tmp_path / "technical-unrelated-directory"
    elsewhere.mkdir()
    monkeypatch.chdir(elsewhere)
    for name in COMPOSE_SECRETS:
        monkeypatch.delenv(name, raising=False)
    calls = []

    def compose_call(command, *, env=None):
        calls.append((command, env))
        return 0

    monkeypatch.setattr(subprocess, "call", compose_call)
    return compose_file, calls


@pytest.mark.parametrize("action,services", [("down", []), ("logs", []), ("logs", ["aegle", "life"])])
@pytest.mark.parametrize("configured", [None, "", "technical-caller-value", " "])
@pytest.mark.parametrize("missing_name", COMPOSE_SECRETS)
def test_nonlaunch_compose_child_environment_needs_no_credentials(
    monkeypatch, technical_compose, action, services, configured, missing_name
):
    compose_file, calls = technical_compose
    # Exercise each variable independently: supplied values must survive beside
    # missing ones, and a nonempty value is not ours to normalize.
    if configured is not None:
        for name in COMPOSE_SECRETS:
            if name != missing_name:
                monkeypatch.setenv(name, configured)
    before = dict(os.environ)
    monkeypatch.setattr(sys, "argv", ["livemore", action, *services])
    with pytest.raises(SystemExit) as stopped:
        cli.main()
    assert stopped.value.code == 0
    assert len(calls) == 1
    command, environment = calls[0]
    assert command == ["docker", "compose", "-f", str(compose_file), action, *services]
    assert environment is not None
    assert environment is not os.environ
    for name in COMPOSE_SECRETS:
        assert environment[name] == (before.get(name) or f"unused-by-livemore-{action}")
    assert {name: value for name, value in environment.items() if name not in COMPOSE_SECRETS} == {
        name: value for name, value in before.items() if name not in COMPOSE_SECRETS
    }
    assert dict(os.environ) == before


@pytest.mark.parametrize("action", ["down", "logs"])
def test_nonlaunch_commands_never_inspect_or_read_credentials(
    monkeypatch, tmp_path, technical_compose, action
):
    _, calls = technical_compose
    data = tmp_path / "technical-credential-store"
    data.mkdir()
    monkeypatch.setattr(cli.R, "REG_DIR", str(data))

    def forbidden(*args, **kwargs):
        pytest.fail("nonlaunch compose command touched credential storage")

    for name in ("holds_linked_secret", "refuse_linked_secrets", "read_own_secret",
                 "patch_storage_key", "patch_admission_key", "ensure_patch_security_keys"):
        monkeypatch.setattr(security, name, forbidden)
    monkeypatch.setattr(cli, "ensure_api_token", forbidden)
    monkeypatch.setattr(cli.R, "ensure_data_dir", forbidden)
    original_isdir = os.path.isdir

    def no_data_stat(path):
        if os.fspath(path) == str(data):
            forbidden()
        return original_isdir(path)

    monkeypatch.setattr(os.path, "isdir", no_data_stat)
    monkeypatch.setattr(sys, "argv", ["livemore", action])
    with pytest.raises(SystemExit) as stopped:
        cli.main()
    assert stopped.value.code == 0
    assert len(calls) == 1


@pytest.mark.parametrize("action", ["down", "logs"])
@pytest.mark.parametrize("status", [0, 1, 2, 3, 7, 125])
def test_nonlaunch_commands_exit_with_compose_status(
    monkeypatch, capsys, technical_compose, action, status
):
    monkeypatch.setattr(subprocess, "call", lambda command, **options: status)
    monkeypatch.setattr(sys, "argv", ["livemore", action])
    with pytest.raises(SystemExit) as stopped:
        cli.main()
    assert stopped.value.code == status
    output = capsys.readouterr().out
    if status:
        assert f"docker compose {action} ended with status {status}; its output is above." in output
        assert "refused" not in output.lower()
    else:
        assert "refused" not in output.lower()


@pytest.mark.parametrize("status", [0, 7])
def test_compose_up_child_gets_prepared_credentials(monkeypatch, capsys, technical_compose, status):
    compose_file, calls = technical_compose
    prepared = {name: f"technical-prepared-{index}" for index, name in enumerate(COMPOSE_SECRETS)}
    preparations = []

    def token():
        preparations.append("token")
        monkeypatch.setenv(COMPOSE_SECRETS[0], prepared[COMPOSE_SECRETS[0]])
        return prepared[COMPOSE_SECRETS[0]]

    def keys():
        preparations.append("keys")
        for name in COMPOSE_SECRETS[1:3]:
            monkeypatch.setenv(name, prepared[name])

    monkeypatch.setattr(security, "refuse_linked_secrets", lambda path: preparations.append("secrets"))
    monkeypatch.setattr(cli, "ensure_api_token", token)
    monkeypatch.setattr(cli, "ensure_service_identity_key", lambda: prepared[COMPOSE_SECRETS[3]])
    monkeypatch.setattr(security, "ensure_patch_security_keys", keys)
    monkeypatch.setattr(cli, "_wait_for_services", lambda *args, **options: [])
    compose_call = subprocess.call
    monkeypatch.setattr(subprocess, "call", lambda command, **options: compose_call(command, **options) or status)
    assert cli._compose("up") == status
    command, environment = calls[0]
    assert command == ["docker", "compose", "-f", str(compose_file), "up", "-d", "--build"]
    assert preparations == ["secrets", "token", "keys"]
    assert environment is not None
    assert {name: environment[name] for name in COMPOSE_SECRETS} == prepared
    assert "refused" not in capsys.readouterr().out


def test_logs_help_is_a_real_parser_command(monkeypatch, capsys):
    monkeypatch.setattr(sys, "argv", ["livemore", "logs", "--help"])
    with pytest.raises(SystemExit) as stopped:
        cli.main()
    assert stopped.value.code == 0
    output = capsys.readouterr().out
    assert "livemore logs" in output and "services" in output


@pytest.mark.parametrize("print_url", [False, True])
@pytest.mark.parametrize("compose_present", [False, True])
def test_unavailable_console_hint_names_host_logs_command(
    monkeypatch, capsys, technical_compose, print_url, compose_present
):
    compose_file, _ = technical_compose
    monkeypatch.setattr("livemorebio.console_session.require_console_browser", lambda: None)
    if not compose_present:
        compose_file.unlink()
    monkeypatch.setattr(cli, "_health", lambda port: None)
    assert cli.open_console(print_url=print_url) == 1
    captured = capsys.readouterr()
    output = captured.err if print_url else captured.out
    assert "`livemore logs aegle`" in output
    assert "docker compose" not in output
    if not compose_present:
        assert "on the host" in output
    if print_url:
        assert captured.out == ""


def test_new_compose_tests_are_in_the_sorted_public_manifest():
    test_file = Path(__file__).resolve()
    root = test_file.parents[2]
    paths = (root / "tools/public_release_manifest.txt").read_text(encoding="utf-8").splitlines()
    assert test_file.relative_to(root).as_posix() in paths
    assert paths == sorted(set(paths))


@pytest.mark.parametrize("action", ["up", "down", "logs"])
def test_compose_echo_is_flushed_before_the_child_runs(monkeypatch, technical_compose, action):
    import builtins
    real_print = builtins.print
    events = []
    def print_(*args, **kwargs):
        if args and str(args[0]).startswith("  $ docker compose "):
            events.append(("echo", kwargs.get("flush")))
        return real_print(*args, **kwargs)
    monkeypatch.setattr(builtins, "print", print_)
    monkeypatch.setattr(cli, "ensure_api_token", lambda: "technical")
    monkeypatch.setattr(cli, "ensure_service_identity_key", lambda: "technical-identity")
    monkeypatch.setattr(security, "refuse_linked_secrets", lambda *_: None)
    monkeypatch.setattr(security, "ensure_patch_security_keys", lambda: None)
    monkeypatch.setattr(subprocess, "call", lambda *_a, **_k: events.append(("child", True)) or 3)
    assert cli._compose(action) == 3
    assert events == [("echo", True), ("child", True)]
