"""PHI-5 regressions; all payloads are technical fixtures, never person data."""
from pathlib import Path

import pytest

from livemorebio import bus, registry, security


@pytest.fixture
def isolated_storage(tmp_path, monkeypatch):
    data = tmp_path / "technical-state"
    monkeypatch.setattr(registry, "REG_DIR", str(data))
    monkeypatch.setattr(bus, "BUS_DIR", str(data))
    monkeypatch.setattr(bus, "EVENTS", str(data / "events.jsonl"))
    monkeypatch.setattr(bus, "SNAP_DIR", str(data / "snapshots"))
    monkeypatch.delenv(security.PATCH_STORAGE_KEY_ENV, raising=False)
    monkeypatch.delenv("LIVEMORE_ENVIRONMENT", raising=False)
    return data


@pytest.mark.parametrize("write_kind", ["event", "snapshot"])
@pytest.mark.parametrize("previous_state", [False, True])
def test_phi5_missing_key_refuses_state_write(isolated_storage, write_kind, previous_state):
    path = (isolated_storage / "events.jsonl" if write_kind == "event"
            else isolated_storage / "snapshots" / "technical-fixture.json")
    previous = b'{"technical_fixture":"previous-state-bytes"}\n'
    if previous_state:
        path.parent.mkdir(parents=True)
        path.write_bytes(previous)

    payload = {"fixture": "TECHNICAL_ONLY", "marker": "must-not-be-plaintext"}
    with pytest.raises(RuntimeError, match="LIVEMORE_PATCH_STORAGE_KEY"):
        if write_kind == "event":
            bus.publish("technical-fixture", "technical-event", payload)
        else:
            bus.set_snapshot("technical-fixture", payload)

    assert path.read_bytes() == previous if previous_state else not path.exists()
    assert not (isolated_storage / "patch-storage.key").exists()


@pytest.mark.parametrize("write_kind", ["event", "snapshot"])
def test_phi5_existing_nonproduction_key_creation_preserves_encrypted_writes(
    isolated_storage, write_kind,
):
    key = security.patch_storage_key(create=True)
    assert key is not None
    assert len(key) == 32
    assert (isolated_storage / "patch-storage.key").is_file()
    payload = {"fixture": "TECHNICAL_ONLY", "marker": "technical-encrypted-marker"}
    if write_kind == "event":
        emitted = bus.publish("technical-fixture", "technical-event", payload)
        assert bus.events() == [emitted]
        path = Path(bus.EVENTS)
    else:
        bus.set_snapshot("technical-fixture", payload)
        assert bus.snapshot("technical-fixture") == payload
        path = Path(bus.SNAP_DIR) / "technical-fixture.json"
    persisted = path.read_bytes()
    assert b"AES-256-GCM" in persisted
    assert b"technical-encrypted-marker" not in persisted


@pytest.mark.parametrize("value", [float("nan"), object()], ids=["nonfinite", "nonserializable"])
def test_phi5_event_publication_preserves_best_effort_serialization_errors(isolated_storage, value):
    """Missing keys must fail clearly without changing unrelated publish errors."""
    security.patch_storage_key(create=True)
    payload = {"fixture": "TECHNICAL_ONLY", "value": value}

    emitted = bus.publish("technical-fixture", "technical-event", payload)

    assert emitted["payload"] is payload
    assert bus.events() == []
