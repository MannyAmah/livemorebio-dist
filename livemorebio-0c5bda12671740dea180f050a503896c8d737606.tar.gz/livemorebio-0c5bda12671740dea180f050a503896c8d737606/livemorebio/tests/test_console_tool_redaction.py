"""Technical private-pipe bootstrap and browser failures never print credentials."""
from pathlib import Path
import http.client
import json
import pytest

from livemorebio import console_session, stack_client, stack_transport
from ._node import NODE, run_node
from .private_reference_helpers import require_private_reference_data

ROOT = Path(__file__).resolve().parents[2]
ORIGIN = "http://127.0.0.1:19893"
CODE = "T" * 43
COOKIE = "technical-session-" + "S" * 43
REJECTED = ["401", "204", "302", "none", "other-host", "other-port", "other-path",
            "query", "fragment", "no-cookie", "other-cookie", "cookie-domain", "cookie-path",
            "cookie-httpOnly", "cookie-sameSite", "cookie-secure"]


@pytest.fixture(autouse=True)
def recorder_source():
    path = ROOT / "tools/record_demo.cjs"
    require_private_reference_data(path, root=ROOT)
    return path


def recorder_failure_probe(source: str, mode: str = "throws") -> dict:
    if mode.startswith("completed-"):
        start = source.index('    await page.goto(`${baseURL}/twins`')
        end = source.index("    video = page.video();", start)
        source = source[:start] + source[end:]
    program = r"""
const assert=require('node:assert/strict'),vm=require('node:vm'),path=require('node:path');
const code='T'.repeat(43),cookie='technical-session-'+'S'.repeat(43),origin='http://127.0.0.1:19893';
let navigations=0,pages=0,posts=0,installed=0,removed=0,bootstraps=0;
const mode=MODE,events=[],printed=[];
const page={on(){},goto:async(url)=>{
 navigations++;events.push('navigate');assert.equal(url,origin+'/twins');
 throw Error('technical-next-page');
},video:()=>null};
let contextClosed=0,browserClosed=0;
const context={addInitScript:async()=>{if(mode==='script-throws')throw Error('technical '+cookie)},
 newPage:async()=>{pages++;events.push('page');if(mode==='page-throws')throw Error('technical '+cookie);return page},
 close:async()=>{contextClosed++;if(mode.endsWith('context-close-throws'))throw Error('technical '+cookie)},
 addCookies:async(values)=>{installed++;events.push('cookies');
  assert.deepEqual(JSON.parse(JSON.stringify(values)),[{name:'livemore_local_session_19893',value:cookie,
   domain:'127.0.0.1',path:'/',httpOnly:true,sameSite:'Strict',secure:false,expires:-1}]);
  if(mode==='cookies-throws')throw Error('technical '+cookie);
 },
 request:{post:async()=>{posts++;throw Error('browser request socket must never carry a bootstrap code')}}};
const browser={newContext:async(options)=>{assert.equal(options.proxy,undefined);events.push('context');
 if(mode==='context-throws')throw Error('technical '+cookie);return context},
 close:async()=>{browserClosed++;if(mode.endsWith('browser-close-throws'))throw Error('technical '+cookie)}};
const query=(python,argv,options)=>{
 bootstraps++;events.push('bootstrap');
 assert.deepEqual(JSON.parse(JSON.stringify(options.stdio)),['ignore','pipe','pipe','pipe']);
 assert(!argv.join(' ').includes(code));assert(!argv.join(' ').includes(cookie));
 if(mode==='query-throws')throw Error('technical '+code+' '+cookie);
 const refused=REJECTED.includes(mode)||mode==='throws'||mode==='dispose-throws';
 if(refused||mode==='mint-fails')return {status:1,stderr:
  (mode==='mint-fails'?'refused [CONSOLE_CODE_UNAVAILABLE]':'refused [CONSOLE_EXCHANGE_FAILED]')+' technical '+code+' '+cookie};
 const record={origin,cookie:{name:'livemore_local_session_19893',value:cookie,domain:'127.0.0.1',path:'/',
  httpOnly:true,sameSite:'Strict',secure:false,expires:-1}};
 return {status:0,stdout:'untrusted terminal '+code+' '+cookie,stderr:'',output:[null,'','',
  mode==='invalid-json'?'technical '+code+' '+cookie:JSON.stringify(record)]};
};
const requireStub=name=>name==='node:fs'?{mkdtempSync:()=>'/tmp/technical-never-created',mkdirSync(){},rmSync(){removed++}}:
 name==='node:child_process'?{spawnSync:query}:name==='playwright'?{chromium:{launch:async(options)=>{
 assert.equal(options.proxy,undefined);assert.ok(options.args.includes('--no-proxy-server'));events.push('launch');
 if(mode==='launch-throws')throw Error('technical '+cookie);return browser}}}:require(name);
const sandbox={require:requireStub,module:{exports:{}},__dirname:path.resolve('tools'),
 process:{env:{HTTP_PROXY:'http://technical-proxy.invalid:9',HTTPS_PROXY:'http://technical-proxy.invalid:9'},
 stderr:{write:value=>printed.push(value)},stdout:{write(){}}},setTimeout,URL};
requireStub.main=sandbox.module;
vm.runInNewContext(SOURCE,sandbox);
setImmediate(()=>{const stderr=printed.join('');console.log(JSON.stringify({
 stderr:stderr.replaceAll(code,'[technical-code-redacted]').replaceAll(cookie,'[technical-cookie-redacted]'),
 leaked:stderr.includes(code)||stderr.includes(cookie),exitCode:sandbox.process.exitCode,
 contextClosed,browserClosed,navigations,pages,posts,installed,removed,bootstraps,events}));});
""".replace("SOURCE", json.dumps(source)).replace("MODE", json.dumps(mode)).replace("REJECTED", json.dumps(REJECTED))
    result = run_node([NODE, "--eval", program], capture_output=True, text=True, timeout=10, encoding="utf-8")
    assert result.returncode == 0, "technical recorder probe did not complete"
    return json.loads(result.stdout)


def test_recorder_exchange_failure_refuses_before_browser_or_recording(recorder_source):
    result = recorder_failure_probe(recorder_source.read_text(encoding="utf-8"))
    assert result["exitCode"] == 1 and result["events"] == ["bootstrap"]
    assert result["contextClosed"] == result["browserClosed"] == result["pages"] == result["navigations"] == 0
    assert "CONSOLE_EXCHANGE_FAILED" in result["stderr"] and result["leaked"] is False
    assert "/api/session/exchange?" not in result["stderr"]


@pytest.mark.parametrize("mode", REJECTED)
def test_h2_recorder_rejects_unaccepted_exchange_without_disclosing_code(mode, monkeypatch, recorder_source):
    # Status/redirect/cookie admission moved from Playwright into the shared
    # Python helper. Exercise that actual boundary before testing JS refusal.
    monkeypatch.setattr(console_session, "mint_console_code", lambda origin: console_session.ConsoleCode(origin, CODE, 120))
    monkeypatch.setattr(stack_client, "operation_identity", lambda *_: object())
    name = "livemore_local_session_19894" if mode == "other-cookie" else "livemore_local_session_19893"
    attrs = ["HttpOnly", "Path=/", "SameSite=strict"]
    if mode == "cookie-domain": attrs.append("Domain=localhost")
    if mode == "cookie-path": attrs[1] = "Path=/api"
    if mode == "cookie-httpOnly": attrs.remove("HttpOnly")
    if mode == "cookie-sameSite": attrs[2] = "SameSite=Lax"
    if mode == "cookie-secure": attrs.append("Secure")
    headers = [] if mode == "no-cookie" else [("Set-Cookie", f"{name}={COOKIE}; " + "; ".join(attrs))]
    if mode in {"other-host", "other-port", "other-path", "query", "fragment"}:
        location = {"other-host": "http://localhost:19893/api/session/exchange", "other-port": "http://127.0.0.1:19894/api/session/exchange",
                    "other-path": ORIGIN + "/", "query": ORIGIN + "/api/session/exchange?unexpected=1",
                    "fragment": ORIGIN + "/api/session/exchange#unexpected"}[mode]
        headers.append(("Location", location))
    response = None if mode == "none" else stack_transport.StackResponse(int(mode) if mode.isdigit() else 200, "technical", tuple(headers), b"")
    monkeypatch.setattr(stack_transport, "request", lambda *a, **kw: response)
    with pytest.raises(console_session.ConsoleExchangeFailedError) as caught:
        console_session.mint_console_cookie(ORIGIN)
    assert CODE not in str(caught.value) and COOKIE not in str(caught.value)
    result = recorder_failure_probe(recorder_source.read_text(encoding="utf-8"), mode)
    assert result["exitCode"] == 1 and result["events"] == ["bootstrap"]
    assert result["contextClosed"] == result["browserClosed"] == result["pages"] == result["navigations"] == result["posts"] == 0
    assert "CONSOLE_EXCHANGE_FAILED" in result["stderr"] and result["leaked"] is False
    assert "/api/session/exchange?" not in result["stderr"]


def test_h2_recorder_accepts_console_origin_and_port_cookie_before_next_page(recorder_source):
    result = recorder_failure_probe(recorder_source.read_text(encoding="utf-8"), "accepted")
    assert result["navigations"] == result["pages"] == result["installed"] == 1 and result["posts"] == 0
    assert result["events"] == ["bootstrap", "launch", "context", "cookies", "page", "navigate"]
    assert result["contextClosed"] == result["browserClosed"] == 1
    assert "technical-next-page" in result["stderr"] and "CONSOLE_EXCHANGE_FAILED" not in result["stderr"]
    assert result["leaked"] is False


@pytest.mark.parametrize("mode", ["launch-throws", "context-throws", "cookies-throws", "dispose-throws",
                                      "script-throws", "page-throws", "context-close-throws", "browser-close-throws"])
def test_recorder_setup_and_cleanup_errors_are_fixed_and_close_every_acquired_resource(mode, monkeypatch, recorder_source):
    if mode == "dispose-throws":
        # The owned Python transport replaces Playwright response disposal.
        monkeypatch.setattr(console_session, "mint_console_code", lambda origin: console_session.ConsoleCode(origin, CODE, 120))
        monkeypatch.setattr(stack_client, "operation_identity", lambda *_: object())
        def failed_read(*args, **kwargs): raise http.client.IncompleteRead(CODE.encode("ascii"))
        monkeypatch.setattr(stack_transport, "request", failed_read)
        with pytest.raises(console_session.ConsoleExchangeFailedError) as caught:
            console_session.mint_console_cookie(ORIGIN)
        assert CODE not in str(caught.value)
    result = recorder_failure_probe(recorder_source.read_text(encoding="utf-8"), mode)
    assert result["exitCode"] == 1
    assert result["browserClosed"] == (0 if mode in {"launch-throws", "dispose-throws"} else 1)
    assert result["contextClosed"] == (0 if mode in {"launch-throws", "context-throws", "dispose-throws"} else 1)
    assert result["posts"] == 0 and "CONSOLE_EXCHANGE_FAILED" in result["stderr"] and result["leaked"] is False


@pytest.mark.parametrize("mode", ["mint-fails", "invalid-json", "query-throws"])
def test_recorder_mint_refusal_never_opens_browser_or_relays_pipe_contents(mode, recorder_source):
    result = recorder_failure_probe(recorder_source.read_text(encoding="utf-8"), mode)
    assert result["exitCode"] == 1 and result["events"] == ["bootstrap"]
    assert "CONSOLE_CODE_UNAVAILABLE" in result["stderr"] and result["leaked"] is False


@pytest.mark.parametrize("mode", ["completed-context-close-throws", "completed-browser-close-throws"])
def test_recorder_discards_recording_when_completed_capture_cleanup_fails(mode, recorder_source):
    result = recorder_failure_probe(recorder_source.read_text(encoding="utf-8"), mode)
    assert result["exitCode"] == 1 and result["removed"] == 1
    assert result["contextClosed"] == result["browserClosed"] == 1
    assert "CONSOLE_EXCHANGE_FAILED" in result["stderr"] and result["leaked"] is False
