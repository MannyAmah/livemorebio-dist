"""Scientific narratives are multiline; identities remain strict and numbers finite."""
from fastapi import FastAPI
from fastapi.testclient import TestClient
import pytest

from livemorebio.aegle import research_api
from livemorebio.research import ResearchError, ResearchService, ResearchStore, _number
from livemorebio.tests.test_research_api import learning_payload, run_fixture, study_spec, AUTH
from livemorebio.tests.test_research_workflow import resilience_spec


@pytest.fixture
def service(tmp_path):
    return ResearchService(ResearchStore(tmp_path / "research.sqlite3", key=b"n" * 32))


def test_large_integer_is_typed_finite_number_failure():
    with pytest.raises(ResearchError, match="number"):
        _number(10 ** 500, "tolerance")


def test_large_json_integer_is_422_and_cannot_create_study(service, monkeypatch):
    from livemorebio.aegle import server
    from types import SimpleNamespace

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "research-api-test-only")
    monkeypatch.setattr(research_api, "service", lambda: service)
    monkeypatch.setattr(server, "_protocol_run_store", lambda: SimpleNamespace(get=lambda _: run_fixture()))
    app = FastAPI()
    app.include_router(research_api.router)
    response = TestClient(app, raise_server_exceptions=False).post(
        "/api/research/studies", json={**study_spec(), "tolerance": 10 ** 500}, headers=AUTH)
    assert response.status_code == 422
    assert response.json()["code"] == "RESEARCH_INPUT_INVALID"
    assert service.store.list() == []


@pytest.mark.parametrize("field", ["claim", "counterevidence", "test_plan", "applicability"])
def test_scientific_learning_retains_multiline_narratives(service, field):
    narrative = "First scientific statement.\n\nSecond statement.\r\n\tEndpoint and scope."
    record = service.record_learning({**learning_payload(), field: narrative})
    assert record[field] == narrative
    assert record["model_change_authorized"] is False


def test_study_retains_multiline_rationale(service):
    rationale = "Primary endpoint rationale.\n\nCounterevidence and tolerance justification."
    record = service.freeze(run_fixture(), {**study_spec(), "rationale": rationale})
    assert record["rationale"] == rationale


def test_resilience_operation_retains_multiline_rationale(service):
    spec = resilience_spec()
    rationale = "Driver assessment.\n\tAssay detection limit is prespecified."
    spec["operations"][0]["rationale"] = rationale
    record = service.register_resilience(spec)
    assert record["operations"][0]["rationale"] == rationale


@pytest.mark.parametrize("control", ["\x00", "\x1b", "\x7f"])
def test_narrative_rejects_nonprintable_control_characters(service, control):
    with pytest.raises(ResearchError, match="text"):
        service.record_learning({**learning_payload(), "claim": f"Claim{control}hidden text"})


@pytest.mark.parametrize("field,value", [("author", "author\nother"), ("module", "module\nother"),
                                        ("sources", ["https://pubmed.ncbi.nlm.nih.gov/\n40472098/"])])
def test_multiline_narratives_do_not_relax_identifiers_or_urls(service, field, value):
    with pytest.raises(ResearchError):
        service.record_learning({**learning_payload(), field: value})


def test_narrative_bound_remains_enforced(service):
    with pytest.raises(ResearchError, match="text"):
        service.record_learning({**learning_payload(), "claim": "x" * 2001})
