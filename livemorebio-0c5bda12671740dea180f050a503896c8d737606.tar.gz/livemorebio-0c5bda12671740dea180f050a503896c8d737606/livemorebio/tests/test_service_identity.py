"""Independent identity material uses technical scratch credentials only."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import FrozenInstanceError
import os
from pathlib import Path
import stat
from types import SimpleNamespace

import pytest

from livemorebio import console_filesystem, registry, security, service_identity as identity


KEY = bytes(range(32))
ENCODED = "AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8="


@pytest.fixture
def private_directory(tmp_path, monkeypatch):
    directory = tmp_path / "technical-identity"
    directory.mkdir(mode=0o700)
    monkeypatch.setattr(registry, "REG_DIR", str(directory))
    monkeypatch.delenv(identity.IDENTITY_KEY_ENV, raising=False)
    monkeypatch.delenv("LIVEMORE_ENVIRONMENT", raising=False)
    return directory


def put_key(directory: Path, text: str = ENCODED + "\n") -> Path:
    path = directory / identity.IDENTITY_KEY_FILE
    path.write_text(text, encoding="utf-8")
    path.chmod(0o600)
    return path


def test_exact_key_codec():
    assert identity.encode_identity_key(KEY) == ENCODED
    assert identity.encode_identity_key(KEY, file=True) == ENCODED + "\n"
    assert identity.decode_identity_key(ENCODED) == KEY
    assert identity.decode_identity_key(ENCODED + "\n", file=True) == KEY
    assert identity.decode_identity_key("A" * 43 + "=") == bytes(32)


@pytest.mark.parametrize("value", [
    "", " ", ENCODED + "\n", " " + ENCODED, ENCODED + " ", ENCODED[:-1],
    ENCODED + "=", ENCODED[:-2] + "9=", "+" + ENCODED[1:], "/" + ENCODED[1:],
    "é" + ENCODED[1:], "A" * 42 + "==", "A" * 44,
])
def test_environment_codec_refuses_noncanonical_values(value):
    with pytest.raises(identity.IdentityError):
        identity.decode_identity_key(value)


@pytest.mark.parametrize("value", [ENCODED, ENCODED + "\r\n", ENCODED + "\n\n", ENCODED + " \n", "\n"])
def test_file_codec_requires_exactly_one_lf(value):
    with pytest.raises(identity.IdentityError):
        identity.decode_identity_key(value, file=True)


@pytest.mark.parametrize("key", [b"", bytes(31), bytes(33), bytearray(32), "A" * 32])
def test_encoder_requires_immutable_exact_32_bytes(key):
    with pytest.raises(identity.IdentityError):
        identity.encode_identity_key(key)


def test_snapshot_is_immutable_and_derives_sid():
    snapshot = identity.IdentitySnapshot(KEY, "aegle", "http://127.0.0.1:18850")
    assert snapshot.sid == identity.stack_id(KEY)
    assert snapshot.role_byte == b"\x01"
    assert KEY.hex() not in repr(snapshot)
    assert ENCODED not in repr(snapshot)
    with pytest.raises(FrozenInstanceError):
        snapshot.key = bytes(32)


@pytest.mark.parametrize("role", ["", "AEGLE", "unknown", 1, b"\x01"])
def test_snapshot_refuses_nonfixed_roles(role):
    with pytest.raises(identity.IdentityError):
        identity.IdentitySnapshot(KEY, role, "http://127.0.0.1:18850")


def test_valid_environment_key_never_inspects_directory(private_directory, monkeypatch):
    monkeypatch.setenv(identity.IDENTITY_KEY_ENV, ENCODED)
    monkeypatch.setattr(identity, "_open_directory", lambda *a, **kw: pytest.fail("environment key touched disk"))
    assert identity.service_identity_key(create=True) == KEY
    assert list(private_directory.iterdir()) == []


@pytest.mark.parametrize("value", ["", " ", ENCODED + "\n", "malformed"])
def test_present_invalid_environment_never_falls_back(private_directory, monkeypatch, value):
    path = put_key(private_directory)
    monkeypatch.setenv(identity.IDENTITY_KEY_ENV, value)
    with pytest.raises(identity.IdentityError) as caught:
        identity.service_identity_key(create=True)
    if value.strip():
        assert value not in str(caught.value)
    assert path.read_text(encoding="utf-8") == ENCODED + "\n"


def test_missing_read_does_not_create_directory(tmp_path):
    directory = tmp_path / "absent"
    assert identity.service_identity_key(directory=directory, environ={}) is None
    assert not directory.exists()


def test_file_read_never_copies_key_into_environment(private_directory, monkeypatch):
    put_key(private_directory)
    assert identity.service_identity_key() == KEY
    assert identity.IDENTITY_KEY_ENV not in os.environ
    changed = bytes(reversed(range(32)))
    put_key(private_directory, identity.encode_identity_key(changed, file=True))
    assert identity.service_identity_key() == changed


@pytest.mark.parametrize("text", ["", "invalid\n", ENCODED, ENCODED + "\r\n"])
def test_invalid_existing_file_is_never_overwritten(private_directory, text):
    path = put_key(private_directory, text)
    original = path.read_bytes()
    with pytest.raises(identity.IdentityError):
        identity.service_identity_key(create=True)
    assert path.read_bytes() == original
    assert sorted(p.name for p in private_directory.iterdir()) == [identity.IDENTITY_KEY_FILE]


def test_creation_is_independent_and_environment_is_not_modified(private_directory, monkeypatch):
    calls = []
    monkeypatch.setenv(security.TOKEN_ENV, "technical-bearer")
    monkeypatch.setenv(security.PATCH_STORAGE_KEY_ENV, "unused-existing-patch-key")

    def entropy(size):
        calls.append(size)
        return KEY

    monkeypatch.setattr(identity.secrets, "token_bytes", entropy)
    monkeypatch.setattr(identity.secrets, "token_hex", lambda _: "a" * 16)
    assert identity.service_identity_key(create=True) == KEY
    path = private_directory / identity.IDENTITY_KEY_FILE
    assert calls == [32]
    assert path.read_text(encoding="utf-8") == ENCODED + "\n"
    assert path.stat().st_mode & 0o777 == 0o600
    assert path.stat().st_nlink == 1
    assert identity.IDENTITY_KEY_ENV not in os.environ


def test_concurrent_initializers_adopt_one_winner(private_directory):
    with ThreadPoolExecutor(max_workers=8) as pool:
        keys = list(pool.map(lambda _: identity.service_identity_key(create=True), range(16)))
    assert len(set(keys)) == 1
    assert identity.service_identity_key() == keys[0]
    assert sorted(p.name for p in private_directory.iterdir()) == [identity.IDENTITY_KEY_FILE]


@pytest.mark.parametrize("kind", ["symlink", "hardlink", "directory", "fifo"])
def test_link_and_nonregular_entries_are_not_read_or_changed(private_directory, tmp_path, kind):
    path = private_directory / identity.IDENTITY_KEY_FILE
    target = tmp_path / "technical-target"
    target.write_text(ENCODED + "\n", encoding="utf-8")
    target.chmod(0o640)
    if kind == "symlink":
        path.symlink_to(target)
    elif kind == "hardlink":
        os.link(target, path)
    elif kind == "directory":
        path.mkdir()
    else:
        os.mkfifo(path)
    with pytest.raises(security.CredentialFileError):
        identity.service_identity_key(create=True)
    assert target.read_text(encoding="utf-8") == ENCODED + "\n"
    assert target.stat().st_mode & 0o777 == 0o640


@pytest.mark.parametrize("mode", [0o400, 0o644, 0o660])
def test_nonprivate_file_modes_refuse_without_repair(private_directory, mode):
    path = put_key(private_directory)
    path.chmod(mode)
    with pytest.raises(identity.IdentityError, match="STACK_CREDENTIAL_UNSAFE"):
        identity.service_identity_key()
    assert path.stat().st_mode & 0o777 == mode


def test_foreign_owner_refuses(private_directory, monkeypatch):
    put_key(private_directory)
    monkeypatch.setattr(identity.os, "geteuid", lambda: os.getuid() + 1)
    with pytest.raises(registry.DataDirSecurityError):
        identity.service_identity_key()


@pytest.mark.parametrize("failure", ["acl", "filesystem"])
def test_filesystem_protection_failure_refuses(private_directory, monkeypatch, failure):
    put_key(private_directory)
    if failure == "acl":
        monkeypatch.setattr(console_filesystem, "has_extended_acl", lambda _: True)
    else:
        def refuse(_):
            raise console_filesystem.ConsoleFilesystemError("technical unsafe filesystem")
        monkeypatch.setattr(console_filesystem, "require_ownership_filesystem", refuse)
    with pytest.raises(registry.DataDirSecurityError):
        identity.service_identity_key()


def test_unsafe_creation_gate_precedes_entropy(private_directory, monkeypatch):
    monkeypatch.setattr(registry, "ensure_data_dir", lambda *a, **k: SimpleNamespace(private=False))
    monkeypatch.setattr(identity.secrets, "token_bytes", lambda _: pytest.fail("unadmitted entropy"))
    with pytest.raises(registry.DataDirSecurityError):
        identity.service_identity_key(create=True)
    assert list(private_directory.iterdir()) == []


def test_read_refuses_extended_acl_on_file(private_directory, monkeypatch):
    put_key(private_directory)
    monkeypatch.setattr(console_filesystem, "has_extended_acl",
                        lambda fd: stat.S_ISREG(os.fstat(fd).st_mode))
    with pytest.raises(identity.IdentityError, match="STACK_CREDENTIAL_UNSAFE"):
        identity.service_identity_key()


def test_file_owner_is_checked_independently(private_directory, monkeypatch):
    put_key(private_directory)
    real_fstat = identity.os.fstat

    def stat_with_foreign_file_owner(fd):
        result = real_fstat(fd)
        if stat.S_ISREG(result.st_mode):
            fields = list(result)
            fields[4] = os.geteuid() + 1
            return os.stat_result(fields)
        return result

    monkeypatch.setattr(identity.os, "fstat", stat_with_foreign_file_owner)
    with pytest.raises(identity.IdentityError, match="STACK_CREDENTIAL_UNSAFE"):
        identity.service_identity_key()


@pytest.mark.parametrize("winner", [ENCODED + "\n", "invalid\n"])
def test_published_winner_is_reread_without_overwrite(private_directory, monkeypatch, winner):
    real_publish = identity._publish_identity

    def race(parent, candidate):
        put_key(private_directory, winner)
        real_publish(parent, candidate)

    monkeypatch.setattr(identity, "_publish_identity", race)
    if winner.startswith("invalid"):
        with pytest.raises(identity.IdentityError):
            identity.service_identity_key(create=True)
    else:
        assert identity.service_identity_key(create=True) == KEY
    assert (private_directory / identity.IDENTITY_KEY_FILE).read_text(encoding="utf-8") == winner
    assert sorted(path.name for path in private_directory.iterdir()) == [identity.IDENTITY_KEY_FILE]


def test_old_snapshot_keeps_old_generation_after_disk_replacement(private_directory):
    put_key(private_directory)
    old = identity.IdentitySnapshot(identity.service_identity_key(), "aegle", "http://127.0.0.1:18850")
    replacement = bytes(reversed(range(32)))
    put_key(private_directory, identity.encode_identity_key(replacement, file=True))
    new = identity.IdentitySnapshot(identity.service_identity_key(), "aegle", old.authority)
    assert old.key == KEY
    assert new.key == replacement
    assert old.sid != new.sid


@pytest.mark.parametrize("create", [False, True])
def test_production_without_explicit_identity_uses_admitted_file(private_directory, create):
    put_key(private_directory)
    assert identity.service_identity_key(create=create, environ={"LIVEMORE_ENVIRONMENT": "production"}) == KEY


def test_production_launcher_can_provision_missing_identity(private_directory):
    key = identity.service_identity_key(create=True, environ={"LIVEMORE_ENVIRONMENT": "production"})
    assert len(key) == 32
    assert identity.service_identity_key(environ={"LIVEMORE_ENVIRONMENT": "production"}) == key


@pytest.mark.parametrize("text", [ENCODED + "\n", "malformed\n", ""])
def test_offline_removal_admits_metadata_but_not_content(private_directory, text):
    put_key(private_directory, text)
    identity.remove_identity_file(private_directory)
    assert list(private_directory.iterdir()) == []


def test_offline_removal_of_missing_key_is_safe(private_directory):
    identity.remove_identity_file(private_directory)
    assert list(private_directory.iterdir()) == []


def test_rotation_preserves_new7_operator_selected_directory_alias(private_directory, tmp_path):
    path = put_key(private_directory)
    alias = tmp_path / "technical-selected-directory-alias"
    alias.symlink_to(private_directory, target_is_directory=True)
    assert identity.service_identity_key(directory=alias, environ={}) == KEY
    identity.remove_identity_file(alias)
    assert not path.exists()
    assert alias.is_symlink()
    replacement = identity.service_identity_key(directory=alias, environ={}, create=True)
    assert replacement is not None
    assert path.read_text(encoding="utf-8") == identity.encode_identity_key(replacement, file=True)


def test_offline_removal_refuses_name_disappearing_after_admission(private_directory, monkeypatch):
    path = put_key(private_directory)
    real_stat = identity.os.stat

    def remove_after_stat(*args, **kwargs):
        result = real_stat(*args, **kwargs)
        if args[0] == identity.IDENTITY_KEY_FILE and "dir_fd" in kwargs:
            path.unlink()
        return result

    monkeypatch.setattr(identity.os, "stat", remove_after_stat)
    with pytest.raises(identity.IdentityError, match="changed during rotation"):
        identity.remove_identity_file(private_directory)


@pytest.mark.parametrize("kind", ["symlink", "hardlink"])
def test_offline_removal_unlinks_only_identity_name(private_directory, tmp_path, kind):
    target = tmp_path / "technical-key-target"
    target.write_text(ENCODED + "\n", encoding="utf-8")
    target.chmod(0o600)
    path = private_directory / identity.IDENTITY_KEY_FILE
    if kind == "symlink":
        path.symlink_to(target)
    else:
        os.link(target, path)
    identity.remove_identity_file(private_directory)
    assert not path.exists() and not path.is_symlink()
    assert target.read_text(encoding="utf-8") == ENCODED + "\n"
