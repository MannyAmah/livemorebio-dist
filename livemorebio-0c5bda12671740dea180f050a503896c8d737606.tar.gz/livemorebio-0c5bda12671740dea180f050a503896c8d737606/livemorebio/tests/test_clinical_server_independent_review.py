"""Independent HTTP contract probes; authored technical identities, no native model."""
from copy import deepcopy
import sqlite3
from types import SimpleNamespace

import pytest

from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401


@pytest.mark.parametrize("error_type", [RuntimeError, sqlite3.OperationalError])
def test_selection_preflight_operational_failure_is_private_typed_and_no_store(client, monkeypatch, error_type):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server

    before = server._state
    generation = server._model_source_authority.generation

    def read(_identifier):
        raise error_type("PRIVATE_TECHNICAL_STORAGE_DIAGNOSTIC")

    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(get_twin=read))
    transport = TestClient(server.app, headers=dict(client.headers), raise_server_exceptions=False)
    response = transport.post("/api/twins/twin-technical/select-observations", json={"expected_version": 1})
    assert response.headers.get("Cache-Control") == "no-store"
    assert response.status_code == 503
    assert response.json()["code"] == "REGISTRY_STORAGE_UNAVAILABLE"
    assert response.headers["Cache-Control"] == "no-store"
    assert response.headers["X-Request-ID"]
    assert "PRIVATE" not in response.text
    assert server._state is before
    assert server._model_source_authority.generation == generation


@pytest.mark.parametrize("path", ["/api/trajectory", "/api/patch/virtual"])
@pytest.mark.parametrize("uncertain", [False, True])
def test_source_switch_after_initial_guard_cannot_execute_or_forward(client, monkeypatch, path, uncertain):
    from fastapi.testclient import TestClient
    from livemorebio.aegle import server
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.engines import trajectory

    unavailable = deepcopy(server._state)
    monkeypatch.setattr(server, "_state", {**unavailable, "tw": SimpleNamespace(human=None)})
    original_check = server._require_numerical_model
    forwarded = []
    calculated = []

    def switch_after_first_check():
        original_check()
        with server._model_source_authority.commit_guard():
            server._model_source_authority.install_generation(DENY_ALL if uncertain else "technical-new-generation")
            server._state = unavailable

    monkeypatch.setattr(server, "_require_numerical_model", switch_after_first_check)
    monkeypatch.setattr(trajectory, "simulate_disease_trajectory", lambda *a, **k: calculated.append(True) or {})
    active = {**unavailable["subject"], "patch_bindings": [{"mode": "virtual", "device_id": "technical-virtual",
                                                          "protocol_version": "3.0"}]}
    monkeypatch.setattr(server, "_subject_registry", lambda: SimpleNamespace(active_twin=lambda: active))
    monkeypatch.setattr(server, "_forward_virtual_patch", lambda body: (forwarded.append(deepcopy(body)) or 202, {}))
    transport = TestClient(server.app, headers=dict(client.headers), raise_server_exceptions=False)
    response = transport.post(path, json={})
    assert response.status_code == (503 if uncertain else 409)
    assert response.json()["code"] == ("SELECTION_COMMIT_UNCONFIRMED" if uncertain else "MODEL_BINDING_REQUIRED")
    assert not forwarded and not calculated
    assert server._state is unavailable
