"""L0-R16: refusals do not echo the value, and the claim says only what holds.

Round 2 of the patient-data verification found:
- the three services' query-validation refusals repeated the rejected value
  (FastAPI's default answer carries ``input``);
- the lab-result qualification answer repeated the caller's method, instrument,
  custody and consent text;
- ``POST /api/trajectory`` repeated free-text foods and drugs (and, with no
  selected twin, its genome);
- the Aegle compound relay repeated the name in its failure answers.

It also found that the release documents called the round-1 mark check more
than it is. The documents now state three things only: the clinical-note
routes refuse every note, other free-text fields are not screened for patient
data, and the release is not a patient-data environment.

Every note here is SYNTHETIC: invented names and numbers, and the word
SYNTHETIC. Checks reduce to booleans with fixed messages, so a failing run
(``--show-capture=no``) logs no note text.
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

import pytest

from ._source_tree import source_tree_only
from .test_l0_clinical_note_gate import aegle, life  # noqa: F401  (fixtures)
from .test_l0_egress import outbound, unused_peers  # noqa: F401  (fixtures: a stub transport; unused peers)


@pytest.fixture(autouse=True)
def _no_installation_peers(unused_peers):  # noqa: F811
    """Every service peer at an address where nothing listens, never 127.0.0.1:8850-8852."""
    return unused_peers

ROOT = Path(__file__).resolve().parents[2]
NOTE = ("SYNTHETIC note, not a person: Lumeth Varrocks, MRN SYN-5528, DOB 1903-04-05, 62F, type 2 diabetes, "
        "HbA1c 8.1%, plan: metformin.")
UNMARKED = "SYNTHETIC Lumeth Varrocks female age 62 SYN-5528 T2D"
# Distinctive fragments only: a bare four-digit run also turns up by chance in a random request id.
FRAGMENTS = ("Lumeth", "Varrocks", "SYN-5528")


def _carries_note(blob: bytes | str) -> bool:
    import urllib.parse

    data = blob if isinstance(blob, bytes) else blob.encode("utf-8", "replace")
    for fragment in FRAGMENTS:
        for form in (fragment, fragment.lower(), urllib.parse.quote(fragment), urllib.parse.quote_plus(fragment)):
            if form.encode() in data:
                return True
    return False


def _no_echo(response, where: str) -> None:
    clean = not _carries_note(response.content) and not _carries_note(json.dumps(dict(response.headers)))
    assert clean, f"{where}: the answer repeats the note"


# ---------------------------------------------------------------- validation refusals

@pytest.fixture
def cendos(monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio.cendos import service

    monkeypatch.setenv("LIVEMORE_API_TOKEN", "technical-note-gate-token")
    return service, TestClient(service.app, raise_server_exceptions=False,
                               headers={"Authorization": "Bearer technical-note-gate-token"})


@pytest.mark.parametrize("service,path,parameter", [
    ("life", "/population", "n"), ("life", "/patch/telemetry", "limit"), ("life", "/patch/commands", "limit"),
    ("cendos", "/protocols/history", "limit"), ("aegle", "/api/cendos/protocols/history", "limit"),
    ("aegle", "/api/resolve", "refresh"), ("aegle", "/api/twins", "limit"), ("aegle", "/api/audit", "limit"),
], ids=lambda value: value.strip("/").replace("/", "-") if isinstance(value, str) else value)
@pytest.mark.parametrize("value", [NOTE, UNMARKED], ids=["marked", "unmarked"])
def test_round_two_query_validation_refusals_do_not_echo(aegle, life, cendos, outbound, service, path, parameter,  # noqa: F811
                                                         value):
    client = {"aegle": aegle, "life": life, "cendos": cendos}[service][1]
    response = client.get(path, params={parameter: value})
    assert response.status_code == 422, f"status {response.status_code}"
    _no_echo(response, path)
    payload = response.json()
    assert payload["code"] == "REQUEST_VALIDATION_FAILED"
    assert payload["detail"] and all(set(item) == {"type", "loc", "msg"} for item in payload["detail"])
    assert payload["detail"][0]["loc"] == ["query", parameter]
    assert payload["detail"][0]["type"] in {"int_parsing", "bool_parsing"}
    assert response.headers["cache-control"] == "no-store"


def test_every_typed_query_parameter_of_every_service_refuses_without_echo(aegle, life, cendos, outbound):  # noqa: F811
    """Each route parameter that FastAPI validates (anything but text): a note is refused unrepeated."""
    from fastapi.routing import APIRoute

    checked = 0
    for name, (module, client) in {"aegle": aegle, "life": life, "cendos": cendos}.items():
        for route in module.app.routes:
            if not isinstance(route, APIRoute) or "{" in route.path:
                continue
            typed = [param for param in route.dependant.query_params
                     if getattr(param.field_info, "annotation", str) not in (str, "str")
                     and "str" not in repr(getattr(param.field_info, "annotation", "str"))]
            for param in typed:
                for method in sorted(route.methods - {"HEAD", "OPTIONS"}):
                    response = client.request(method, route.path, params={param.name: UNMARKED})
                    _no_echo(response, f"{name} {route.path}?{param.name}")
                    checked += 1
    assert checked >= 10, f"only {checked} typed query parameters found"


def test_the_validation_payload_keeps_place_and_name_only():
    from livemorebio.request_errors import validation_error_payload

    payload = validation_error_payload([
        {"type": "int_parsing", "loc": ("query", "limit"), "msg": "x " + UNMARKED, "input": UNMARKED,
         "ctx": {"error": UNMARKED}},
        {"type": "missing", "loc": ("body", UNMARKED, 0), "msg": UNMARKED, "input": {UNMARKED: 1}},
        {"type": UNMARKED, "loc": (UNMARKED,), "msg": UNMARKED},
    ])
    clean = not _carries_note(json.dumps(payload))
    assert clean, "the validation payload repeats the note"
    assert [item["loc"] for item in payload["detail"]] == [["query", "limit"], ["body"], ["request"]]
    sanitized = payload["detail"][2]["type"] == "value_error"
    assert sanitized, "an error type that is not pydantic's was kept"


@pytest.mark.parametrize("route,module_name,baseline", [
    ("/protocols/exogenous-insulin", "insulin_protocol", {"cohort_size": 1, "hours": 1}),
    ("/protocols/botanical-exposure", "botanical_programs", {"program_id": "LBHR-030"}),
], ids=["insulin-unknown-field", "botanical-unknown-field"])
@pytest.mark.parametrize("service_name", ["cendos", "aegle"])
def test_r17_protocol_unknown_fields_refuse_without_echo(request, outbound, monkeypatch,
                                                         route, module_name, baseline, service_name):  # noqa: F811
    """The unmarked key reaches domain validation, rather than the best-effort mark screen."""
    import importlib

    module = importlib.import_module("livemorebio.cendos." + module_name)
    module.validate_spec(baseline)
    validate = module.validate_spec
    reached = []

    def track_validation(body):
        reached.append(True)
        return validate(body)

    monkeypatch.setattr(module, "validate_spec", track_validation)
    client = request.getfixturevalue(service_name)[1]
    path = "/api/cendos" + route if service_name == "aegle" else route
    response = client.post(path, json={**baseline, UNMARKED: 1})
    assert reached == [True], "the protocol validator was not reached once"
    expected_branch = response.status_code == 422 and response.json().get("code") == "INVALID_PROTOCOL"
    assert expected_branch, "the unknown-field domain refusal was not reached"
    _no_echo(response, "protocol unknown-field refusal")
    assert not outbound.third_party(), "a refused protocol attempted an outbound request"


@pytest.mark.parametrize("service_name", ["cendos", "aegle"])
def test_r17_insulin_unknown_product_refuses_without_echo(request, outbound, service_name):  # noqa: F811
    client = request.getfixturevalue(service_name)[1]
    prefix = "/api/cendos" if service_name == "aegle" else ""
    response = client.post(prefix + "/protocols/exogenous-insulin", json={"product_id": UNMARKED})
    expected_branch = response.status_code == 422 and response.json().get("code") == "INSULIN_PRODUCT_UNKNOWN"
    assert expected_branch, "the unknown-product domain refusal was not reached"
    _no_echo(response, "protocol unknown-product refusal")
    assert not outbound.third_party(), "a refused protocol attempted an outbound request"


def test_r17_botanical_source_identifier_refuses_without_echo():
    from livemorebio.cendos.botanical_programs import BotanicalProgramError, source_record

    with pytest.raises(BotanicalProgramError) as caught:
        source_record(UNMARKED)
    assert caught.value.code == "PROGRAM_NOT_FOUND", "the source identifier refusal was not reached"
    clean = not _carries_note(str(caught.value))
    assert clean, "the source identifier refusal repeats the field text"


# ---------------------------------------------------------------- the lab-result and trajectory echoes

def test_lab_result_answer_withholds_the_callers_free_text(monkeypatch, cendos, outbound):  # noqa: F811
    service, client = cendos
    monkeypatch.setattr("livemorebio.bus.publish", lambda *args, **kwargs: {})
    monkeypatch.setattr("livemorebio.bus.set_snapshot", lambda *args, **kwargs: None)
    timestamp = datetime.now(timezone.utc).isoformat()
    body = {"result_id": "lab-result-technical-001", "subject_id": "pseudonym-001", "subject_pseudonymized": True,
            "endpoint": "glucose_mgdl", "value": 112.0, "unit": "mg/dL", "measured_at": timestamp,
            "received_at": timestamp, "instrument_id": UNMARKED, "method": NOTE, "quality_status": "pass",
            "calibration_status": "pass", "chain_of_custody": [NOTE, UNMARKED], "consent_scope": [UNMARKED],
            "sequence": 1}
    response = client.post("/evidence/lab-results", json=body)
    assert response.status_code == 201, response.status_code
    _no_echo(response, "lab-results")
    measurement = response.json()["measurement"]
    assert measurement["withheld"] == ["payload." + field for field in service.LAB_RESULT_WITHHELD_FIELDS]
    assert measurement["source_hash"] and measurement["payload"]["source_data_class"] == "qualified_lab"
    technical = dict(body, instrument_id="analyzer-001", method="validated hexokinase assay",
                     chain_of_custody=["accession:ABC123"], consent_scope=["research-validation"])
    hashes = {client.post("/evidence/lab-results", json=candidate).json()["measurement"]["source_hash"]
              for candidate in (body, technical)}
    assert len(hashes) == 2, "the withheld text no longer binds the measurement"


@pytest.mark.parametrize("field,value", [
    ("foods", [UNMARKED]), ("foods", [NOTE]), ("drugs", [UNMARKED]), ("drugs", ["metformin", UNMARKED]),
    ("factors", [UNMARKED]), ("factors", "sleep deprivation"), ("foods", ["moringa"] * 33),
    ("sex", UNMARKED), ("genome", {UNMARKED: 1}), ("genome", {"TCF7L2": UNMARKED}),
], ids=["foods", "foods-marked", "drugs", "drugs-mixed", "factors", "factors-not-a-list", "foods-too-many",
        "sex", "genome-key", "genome-dose"])
def test_trajectory_admits_vocabulary_terms_only_and_never_echoes(aegle, outbound, monkeypatch, field, value):  # noqa: F811
    # The stub transport keeps a tree without the admission (the red run) from sending the note out.
    from livemorebio.aegle.runtime import AegleTwin

    server, client = aegle
    monkeypatch.setattr(server, "_state", {"tw": AegleTwin("healthy"), "subject": None, "initialized": True})
    response = client.post("/api/trajectory", json={field: value, "years": 1})
    assert response.status_code == 422, response.status_code
    payload = response.json()
    assert payload["code"] == "CLINICAL_NOTE_NOT_ACCEPTED" and payload["field"] == field
    _no_echo(response, "trajectory")
    assert not outbound.third_party(), "the trajectory attempted a request"


def test_trajectory_still_runs_on_vocabulary_terms(aegle, outbound, monkeypatch):  # noqa: F811
    from livemorebio.aegle.runtime import AegleTwin

    server, client = aegle
    monkeypatch.setattr(server, "_state", {"tw": AegleTwin("healthy"), "subject": None, "initialized": True})
    response = client.post("/api/trajectory", json={
        "foods": ["Moringa", "turmeric"], "drugs": ["metformin"], "factors": ["Sleep Deprivation"],
        "sex": "F", "genome": {"TCF7L2": 1}, "years": 2})
    assert response.status_code == 200, response.status_code
    result = response.json()
    assert result["exposure"]["foods"] == ["Moringa", "turmeric"] and result["exposure"]["drugs"] == ["metformin"]
    assert result["genome"] == {"TCF7L2": 1}
    baseline = client.post("/api/trajectory", json={"years": 2, "sex": "F"}).json()
    assert result["trajectory"] != baseline["trajectory"], "the admitted terms no longer act"
    assert not outbound.third_party(), "the trajectory attempted a request"


def test_aegle_compound_relay_failures_do_not_repeat_the_name(aegle, outbound, monkeypatch):  # noqa: F811
    from livemorebio import stack_client

    server, client = aegle

    def unavailable(*args, **kwargs):
        raise OSError("technical: Cendos is not running")

    monkeypatch.setattr(stack_client, "request_response", unavailable)
    monkeypatch.setattr(stack_client, "operation_identity", lambda *args, **kwargs: None)
    monkeypatch.setattr(stack_client, "startup_identity", lambda *args, **kwargs: None)
    response = client.get("/api/cendos/compound", params={"name": "metformin"})
    assert response.status_code == 502, response.status_code
    assert "name" not in response.json() and "metformin" not in response.text
    refused = client.get("/api/cendos/compound", params={"name": UNMARKED})
    assert refused.status_code == 422 and refused.json()["code"] == "EGRESS_VALUE_NOT_ALLOWED"
    _no_echo(refused, "compound relay")


# ---------------------------------------------------------------- the claim, scoped

# The container image carries README.md but no docs/ tree; the docs cases run in the source tree.
DOCUMENTS = [pytest.param(path, id=path, marks=source_tree_only(path) if path.startswith("docs/") else ())
             for path in ("README.md", "docs/LAUNCH_GUIDE.md")]


@pytest.mark.parametrize("document", DOCUMENTS)
def test_the_release_documents_state_the_scoped_claim(document):
    text = " ".join((ROOT / document).read_text(encoding="utf-8").split())
    for phrase in ("not a patient-data environment", "never enter patient data", "not screened for patient data",
                   "CLINICAL_NOTE_NOT_ACCEPTED", "EGRESS_VALUE_NOT_ALLOWED"):
        stated = phrase.lower() in text.lower()
        assert stated, f"{document} does not state: {phrase}"


@pytest.mark.parametrize("document", DOCUMENTS)
def test_no_document_calls_the_mark_check_a_gate_or_a_guarantee(document):
    text = " ".join((ROOT / document).read_text(encoding="utf-8").split())
    sentences = re.split(r"(?<=[.;:])\s+", text)
    about_check = [sentence for sentence in sentences
                   if re.search(r"\b(screen|screened|mark check|marks? of a clinical note|best-effort check)\b",
                                sentence, re.I)]
    assert about_check, "the documents no longer describe the mark check"
    for sentence in about_check:
        for match in re.finditer(r"\b(gate|guarantee)s?\b", sentence, re.I):
            before = sentence[max(0, match.start() - 12):match.start()].lower()
            negated = "not a " in before or "not " in before or "nor " in before
            assert negated, f"{document}: a sentence calls the mark check a {match.group(1)}"
        unqualified = (re.search(r"free text (that is )?(kept or echoed )?(is )?screened\b", sentence, re.I) is not None
                       and "best-effort" not in sentence.lower() and "not screened" not in sentence.lower())
        assert not unqualified, f"{document}: a sentence says free text is screened without its limit"


@pytest.mark.parametrize("document", DOCUMENTS)
def test_r18_documents_do_not_make_a_general_phi_gate_claim(document):
    text = " ".join((ROOT / document).read_text(encoding="utf-8").split()).lower()
    assert "phi-like input fails closed" not in text, f"{document}: patient-data claim is not scoped"
    assert "clinical-note" in text and "not screened for patient data" in text


@pytest.mark.parametrize("document", DOCUMENTS)
def test_r18_documents_name_the_actual_note_decoding_boundaries(document):
    text = " ".join((ROOT / document).read_text(encoding="utf-8").split()).lower()
    for fact in ("console sends the note over loopback", "aegle refuses it without reading the body",
                 "life decodes the json body before the gate"):
        assert fact in text, f"{document}: missing note boundary: {fact}"
    assert "before the note is read, parsed" not in text


@pytest.mark.parametrize("document", DOCUMENTS)
def test_r18_documents_describe_pipeline_parse_and_echo(document):
    text = " ".join((ROOT / document).read_text(encoding="utf-8").split()).lower()
    assert "pipelines parse each line first" in text, f"{document}: pipeline parse order is missing"
    assert "repeat only recognised command words" in text, f"{document}: pipeline echo boundary is missing"


@pytest.mark.parametrize("document", DOCUMENTS)
def test_r18_documents_name_shell_history_and_its_controls(document):
    text = " ".join((ROOT / document).read_text(encoding="utf-8").split())
    for fact in ("shell_history", "LIVEMORE_SHELL_HISTORY=0", "recognised commands", "arguments",
                 "patient", "unknown", "exit all shells"):
        assert fact in text, f"{document}: missing shell history boundary: {fact}"
    assert ': > "${LIVEMORE_DATA_DIR:-$HOME/.livemore}/shell_history"' in text, (
        f"{document}: missing command to clear persisted shell history")
