"""Socket-free NEW-10 authentication checks with technical credentials only."""
from __future__ import annotations

import asyncio
from concurrent.futures import ThreadPoolExecutor
import fcntl
import hashlib
import importlib
import io
import json
import logging
import os
from pathlib import Path
import socket
import subprocess
import webbrowser
from types import SimpleNamespace

import pytest

from livemorebio.tests._notebook import qualified_notebook_packages  # noqa: F401


TECHNICAL_TOKEN = "b7" * 32
requires_qualified_notebook = pytest.mark.usefixtures("qualified_notebook_packages")


@pytest.fixture(autouse=True)
def isolated_environment(tmp_path, monkeypatch):
    """No test may reach a listening socket or the operator's runtime."""
    home = tmp_path / "technical-home"
    home.mkdir(mode=0o700)
    for name in ("HOME", "JUPYTER_CONFIG_DIR", "JUPYTER_DATA_DIR", "XDG_CONFIG_HOME",
                 "XDG_DATA_HOME", "XDG_RUNTIME_DIR"):
        monkeypatch.setenv(name, str(home))
    monkeypatch.setenv("LIVEMORE_DATA_DIR", str(tmp_path / "technical-data"))
    monkeypatch.delenv("JUPYTER_TOKEN", raising=False)
    monkeypatch.delenv("JUPYTER_TOKEN_FILE", raising=False)
    monkeypatch.delenv("JUPYTER_RUNTIME_DIR", raising=False)

    def refuse_socket(*args, **kwargs):
        raise AssertionError("technical authentication tests never use sockets")

    monkeypatch.setattr(socket.socket, "connect", refuse_socket)
    monkeypatch.setattr(socket.socket, "connect_ex", refuse_socket)
    monkeypatch.setattr(socket.socket, "bind", refuse_socket)
    monkeypatch.setattr(subprocess, "Popen", refuse_socket)
    monkeypatch.setattr(webbrowser, "open", refuse_socket)


@pytest.fixture
def identity():
    return importlib.import_module("livemorebio.notebook_identity")


@pytest.fixture
def runtime(tmp_path, monkeypatch):
    directory = tmp_path / "technical-notebook-runtime"
    directory.mkdir(mode=0o700)
    token_file = directory / "token"
    token_file.write_text(TECHNICAL_TOKEN, encoding="utf-8")
    token_file.chmod(0o600)
    info = directory.stat()
    record = directory / "launcher.json"
    record.write_text(json.dumps({"schema": "livemore.notebook-launch.v1",
        "launcher_pid": os.getpid(), "launcher_identity": "technical-launcher-birth",
        "runtime_identity": [info.st_dev, info.st_ino], "port": 18893}), encoding="utf-8")
    record.chmod(0o600)
    monkeypatch.setenv("JUPYTER_RUNTIME_DIR", str(directory))
    monkeypatch.setenv("JUPYTER_TOKEN_FILE", str(token_file))
    return directory


def technical_parent(**overrides):
    from traitlets import Bool, Int, Unicode
    from traitlets.config import Configurable

    class TechnicalServer(Configurable):
        ip = Unicode("127.0.0.1")
        port = Int(18893)
        port_retries = Int(0)
        open_browser = Bool(False)

    return TechnicalServer(**overrides)


@requires_qualified_notebook
def test_supported_provider_uses_private_file_and_has_real_auth(identity, runtime):
    provider = identity.LivemoreIdentityProvider(parent=technical_parent())
    assert provider.token == TECHNICAL_TOKEN
    assert provider.auth_enabled
    assert provider.token_generated is False
    assert provider.allow_password_change is False
    assert identity.read_private_token(runtime) == TECHNICAL_TOKEN


@pytest.mark.parametrize("effective", ["", "f0" * 32])
@requires_qualified_notebook
def test_provider_refuses_empty_or_replaced_effective_token(identity, runtime, effective):
    from traitlets.config import Config

    config = Config({"IdentityProvider": {"token": effective}})
    with pytest.raises(identity.NotebookIdentityError, match="private launch token"):
        identity.LivemoreIdentityProvider(config=config)


@pytest.mark.parametrize("package", ["jupyter-server", "jupyterlab"])
def test_provider_refuses_other_installed_version(identity, runtime, monkeypatch, package):
    qualified = {"jupyter-server": "2.21.0", "jupyterlab": "4.6.4"}
    monkeypatch.setattr(identity.metadata, "version", lambda name: "0.0.technical" if name == package else qualified[name])
    with pytest.raises(identity.NotebookIdentityError) as refusal:
        identity.LivemoreIdentityProvider()
    assert str(refusal.value) == "Livemore notebooks require jupyter-server 2.21.0 and jupyterlab 4.6.4."
    assert TECHNICAL_TOKEN not in str(refusal.value)


@requires_qualified_notebook
def test_provider_requires_runtime_and_matching_file_path(identity, runtime, monkeypatch):
    monkeypatch.setenv("JUPYTER_TOKEN_FILE", str(runtime / "other"))
    with pytest.raises(identity.NotebookIdentityError, match="private launch token"):
        identity.LivemoreIdentityProvider()
    monkeypatch.delenv("JUPYTER_RUNTIME_DIR")
    with pytest.raises(identity.NotebookIdentityError, match="private launch token"):
        identity.LivemoreIdentityProvider()


@pytest.mark.parametrize("contents", ["", "abc", "a" * 65, "a" * 64 + "\n", "A" * 64, "a" * 63 + "\x00"])
def test_private_token_rejects_malformed_input(identity, runtime, contents):
    (runtime / "token").write_text(contents, encoding="utf-8")
    with pytest.raises(identity.NotebookIdentityError):
        identity.read_private_token(runtime)


@pytest.mark.parametrize("kind", ["readable-token", "readable-runtime", "token-symlink", "runtime-symlink", "hardlink", "fifo"])
def test_private_token_refuses_nonprivate_or_linked_file(identity, runtime, tmp_path, kind):
    token = runtime / "token"
    checked = runtime
    if kind == "readable-token":
        token.chmod(0o644)
    elif kind == "readable-runtime":
        runtime.chmod(0o755)
    elif kind == "token-symlink":
        other = runtime / "technical-token-copy"
        token.rename(other)
        token.symlink_to(other)
    elif kind == "runtime-symlink":
        checked = tmp_path / "technical-runtime-link"
        checked.symlink_to(runtime, target_is_directory=True)
    elif kind == "hardlink":
        os.link(token, runtime / "technical-token-hardlink")
    else:
        token.unlink()
        os.mkfifo(token, mode=0o600)
    with pytest.raises(identity.NotebookIdentityError):
        identity.read_private_token(checked)


def test_code_is_80_bits_private_hashed_and_only_used_once(identity, runtime):
    code = identity.mint_code(runtime, now=1000)
    assert len(code) == 16
    assert set(code) <= set("0123456789ABCDEFGHJKMNPQRSTVWXYZ")
    codes = runtime / "codes"
    assert codes.stat().st_mode & 0o777 == 0o700
    path = codes / hashlib.sha256(code.encode("ascii")).hexdigest()
    assert sorted(child.name for child in codes.iterdir()) == [path.name]
    assert path.stat().st_mode & 0o777 == 0o600
    assert float(path.read_text(encoding="utf-8")) == 1120
    assert code not in path.read_text(encoding="utf-8")
    assert identity.consume_code(runtime, code, now=1119)
    assert not path.exists()
    assert not identity.consume_code(runtime, code, now=1119)


@pytest.mark.parametrize("bad", ["", "A" * 15, "A" * 17, "I" * 16, "a" * 16, "../technical"])
def test_wrong_codes_fail_without_minting(identity, runtime, bad):
    assert not identity.consume_code(runtime, bad, now=1000)
    assert not (runtime / "codes").exists()


def test_code_expires_at_exactly_120_seconds(identity, runtime):
    code = identity.mint_code(runtime, now=1000)
    assert not identity.consume_code(runtime, code, now=1120)
    assert not identity.consume_code(runtime, code, now=1001)


def test_two_code_consumers_have_exactly_one_winner(identity, runtime):
    code = identity.mint_code(runtime, now=1000)
    with ThreadPoolExecutor(max_workers=2) as pool:
        winners = list(pool.map(lambda _: identity.consume_code(runtime, code, now=1001), range(2)))
    assert sorted(winners) == [False, True]


def test_codes_refuse_unsafe_directory_and_file(identity, runtime):
    codes = runtime / "codes"
    codes.mkdir(mode=0o755)
    codes.chmod(0o755)
    with pytest.raises(identity.NotebookIdentityError):
        identity.mint_code(runtime)
    codes.chmod(0o700)
    code = identity.mint_code(runtime)
    path = codes / hashlib.sha256(code.encode("ascii")).hexdigest()
    path.chmod(0o644)
    assert not identity.consume_code(runtime, code)


def test_code_creation_inspection_error_has_fixed_refusal(identity, runtime, monkeypatch):
    actual = identity.os.fstat

    def refuse_created_descriptor(descriptor):
        if fcntl.fcntl(descriptor, fcntl.F_GETFL) & os.O_ACCMODE == os.O_WRONLY:
            raise OSError("technical descriptor inspection failure")
        return actual(descriptor)

    monkeypatch.setattr(identity.os, "fstat", refuse_created_descriptor)
    with pytest.raises(identity.NotebookIdentityError, match="one-time code could not be created"):
        identity.mint_code(runtime)


def technical_handler(arguments=None, authorization=""):
    arguments = arguments or {}
    return SimpleNamespace(
        get_argument=lambda name, default="": arguments.get(name, default),
        request=SimpleNamespace(headers={"Authorization": authorization}, remote_ip="technical-loopback"),
        log=logging.getLogger("technical-notebook-handler"),
    )


@requires_qualified_notebook
def test_code_token_query_gets_jupyter_user_once(identity, runtime, monkeypatch):
    from jupyter_server.auth import User

    provider = identity.LivemoreIdentityProvider(parent=technical_parent())
    code = identity.mint_code(runtime)
    handler = technical_handler({"token": code})
    handler.token = provider.token
    monkeypatch.setattr(provider, "get_user_cookie", lambda handler: None)
    monkeypatch.setattr(provider, "generate_anonymous_user", lambda handler: User("technical-user"))
    assert asyncio.run(provider.get_user_token(handler)).username == "technical-user"
    assert asyncio.run(provider.get_user_token(handler)) is None


@requires_qualified_notebook
def test_live_token_bearer_still_uses_jupyter_authentication(identity, runtime, monkeypatch):
    from jupyter_server.auth import User

    provider = identity.LivemoreIdentityProvider(parent=technical_parent())
    handler = technical_handler(authorization=f"Bearer {TECHNICAL_TOKEN}")
    handler.token = provider.token
    monkeypatch.setattr(provider, "get_user_cookie", lambda handler: None)
    monkeypatch.setattr(provider, "generate_anonymous_user", lambda handler: User("technical-user"))
    assert asyncio.run(provider.get_user_token(handler)).username == "technical-user"


@requires_qualified_notebook
def test_login_form_accepts_code_once_and_never_persists_password(identity, runtime, monkeypatch):
    from jupyter_server.auth import User

    provider = identity.LivemoreIdentityProvider(parent=technical_parent())
    code = identity.mint_code(runtime)
    handler = technical_handler({"password": code, "new_password": "technical-new-password"})
    monkeypatch.setattr(provider, "generate_anonymous_user", lambda handler: User("technical-user"))
    assert provider.process_login_form(handler).username == "technical-user"
    assert provider.process_login_form(handler) is None
    assert provider.hashed_password == ""
    assert provider.process_login_form(technical_handler({"password": "wrong-technical-password"})) is None


@pytest.mark.parametrize("credential", [TECHNICAL_TOKEN, "0123456789ABCDEF"])
@pytest.mark.parametrize("status", [200, 302, 403, 500])
def test_installed_jupyter_request_log_scrubs_token_and_code_queries(credential, status):
    from jupyter_server.log import log_request

    output = io.StringIO()
    logger = logging.Logger("technical-jupyter-log", level=logging.DEBUG)
    logger.addHandler(logging.StreamHandler(output))
    uri = f"/api/kernels/technical/channels?session_id=technical&token={credential}"
    handler = SimpleNamespace(
        get_status=lambda: status,
        request=SimpleNamespace(method="GET", remote_ip="technical-loopback", uri=uri,
                                request_time=lambda: 0.001,
                                headers={"Referer": f"http://technical.invalid/lab?token={credential}"}),
        log=logger,
        settings={},
        current_user=None,
    )
    log_request(handler, record_prometheus_metrics=False)
    assert credential not in output.getvalue()
    assert "token=[secret]" in output.getvalue()


@pytest.mark.parametrize("settings", [None, {"ip": "0.0.0.0"}, {"port": 18894},
    {"port_retries": 50}, {"open_browser": True}])
@requires_qualified_notebook
def test_provider_refuses_unsafe_parent_before_admission(identity, runtime, settings):
    parent = None if settings is None else technical_parent(**settings)
    with pytest.raises(identity.NotebookIdentityError):
        identity.LivemoreIdentityProvider(parent=parent)
    assert not (runtime / "provider-admitted.json").exists()


@requires_qualified_notebook
def test_provider_admission_marker_is_exclusive_and_private(identity, runtime):
    identity.LivemoreIdentityProvider(parent=technical_parent())
    marker = runtime / "provider-admitted.json"
    assert marker.stat().st_mode & 0o777 == 0o600
    info = runtime.stat()
    assert json.loads(marker.read_text(encoding="utf-8")) == {
        "schema": "livemore.notebook-admitted.v1", "port": 18893,
        "server_pid": os.getpid(), "runtime_identity": [info.st_dev, info.st_ino]}
    with pytest.raises(identity.NotebookIdentityError):
        identity.LivemoreIdentityProvider(parent=technical_parent())


@pytest.mark.parametrize("browser_section", ["NotebookApp", "LabApp", "ExtensionApp", "LabServerApp"])
@pytest.mark.parametrize("disable_token", [False, True])
@requires_qualified_notebook
def test_pinned_jupyter_config_phase_rejects_hostile_ambient_settings(
        identity, runtime, tmp_path, monkeypatch, browser_section, disable_token):
    """Replay configuration/linking only; no HTTP server or configurable managers."""
    from jupyter_core.application import JupyterApp
    from jupyter_server.serverapp import ServerApp
    from jupyterlab.labapp import LabApp
    from traitlets.config import Config
    from livemorebio.notebook_launch import jupyter_command

    config_dir = tmp_path / "technical-config"
    config_dir.mkdir(mode=0o700)
    monkeypatch.setenv("JUPYTER_CONFIG_DIR", str(config_dir))
    monkeypatch.setattr(JupyterApp, "config_file_paths", property(lambda self: [str(config_dir)]))
    hostile = ("c = get_config()\n"
        "c.NotebookApp.ip = '0.0.0.0'\n"
        "c.NotebookApp.port = 18894\n"
        "c.NotebookApp.port_retries = 50\n"
        "c.NotebookApp.identity_provider_class = 'jupyter_server.auth.PasswordIdentityProvider'\n"
        "c.LabApp.ip = '0.0.0.0'\n"
        "c.LabApp.port = 18895\n"
        "c.LabApp.port_retries = 60\n"
        "c.LabApp.identity_provider_class = 'jupyter_server.auth.PasswordIdentityProvider'\n"
        f"c.{browser_section}.open_browser = True\n")
    if disable_token:
        hostile += "c.IdentityProvider.token = ''\n"
    (config_dir / "jupyter_server_config.py").write_text(hostile, encoding="utf-8")
    (config_dir / "jupyter_lab_config.py").write_text(hostile, encoding="utf-8")
    workspace = tmp_path / "technical-workspace"
    workspace.mkdir()
    logger = logging.Logger("technical-jupyter-config")
    logger.addHandler(logging.StreamHandler())
    app = ServerApp(jpserver_extensions={"jupyterlab": True, "notebook_shim": True}, log=logger)
    app.aliases.update(LabApp.aliases)
    extensions = app.jpserver_extensions.copy()
    JupyterApp.initialize(app, argv=jupyter_command("technical-python", workspace, 18893)[3:])
    app.jpserver_extensions.update(extensions)
    app.find_server_extensions()
    app.init_server_extensions()
    starter = app.extension_manager.extension_points[LabApp.name]
    app._starter_app = starter.app
    app.update_config(Config(starter.config))
    assert (app.ip, app.port, app.port_retries, app.open_browser) == ("127.0.0.1", 18893, 0, False)
    assert app.identity_provider_class is identity.LivemoreIdentityProvider
    if disable_token:
        with pytest.raises(identity.NotebookIdentityError):
            app.identity_provider_class(parent=app, log=app.log)
        assert not (runtime / "provider-admitted.json").exists()
    else:
        provider = app.identity_provider_class(parent=app, log=app.log)
        assert provider.auth_enabled and provider.token == TECHNICAL_TOKEN
        assert (runtime / "provider-admitted.json").is_file()


@pytest.mark.parametrize("failure", ["missing-marker", "wrong-info-port", "wrong-marker-pid", "loose-marker"])
def test_readiness_requires_private_provider_admission_and_requested_port(identity, runtime, failure):
    from livemorebio.notebook_launch import NotebookLaunchError, NotebookRuntime, wait_for_ready

    info = runtime.stat()
    owned = NotebookRuntime(runtime, (info.st_dev, info.st_ino))
    child = SimpleNamespace(pid=os.getpid(), poll=lambda: None)
    server_info = runtime / f"jpserver-{child.pid}.json"
    server_info.write_text(json.dumps({"port": 18894 if failure == "wrong-info-port" else 18893}), encoding="utf-8")
    server_info.chmod(0o600)
    if failure != "missing-marker":
        marker = runtime / "provider-admitted.json"
        marker.write_text(json.dumps({"schema": "livemore.notebook-admitted.v1", "port": 18893,
            "server_pid": child.pid + (failure == "wrong-marker-pid"),
            "runtime_identity": list(owned.identity)}), encoding="utf-8")
        marker.chmod(0o644 if failure == "loose-marker" else 0o600)
    with pytest.raises(NotebookLaunchError):
        wait_for_ready(owned, child, timeout=0)


@requires_qualified_notebook
def test_readiness_accepts_the_admitted_provider_and_matching_server_info(identity, runtime):
    from livemorebio.notebook_launch import NotebookRuntime, wait_for_ready

    identity.LivemoreIdentityProvider(parent=technical_parent())
    info = runtime.stat()
    child = SimpleNamespace(pid=os.getpid(), poll=lambda: None)
    path = runtime / f"jpserver-{child.pid}.json"
    path.write_text(json.dumps({"port": 18893}), encoding="utf-8")
    path.chmod(0o600)
    assert wait_for_ready(NotebookRuntime(runtime, (info.st_dev, info.st_ino)), child, timeout=0)


@pytest.mark.parametrize("partial", ["provider-admitted.json", "jpserver-info"])
@requires_qualified_notebook
def test_readiness_waits_for_complete_private_json_publication(identity, runtime, monkeypatch, partial):
    from livemorebio import notebook_launch as launch

    identity.LivemoreIdentityProvider(parent=technical_parent())
    child = SimpleNamespace(pid=os.getpid(), poll=lambda: None)
    info_path = runtime / f"jpserver-{child.pid}.json"
    info_path.write_text(json.dumps({"port": 18893}), encoding="utf-8")
    info_path.chmod(0o600)
    pending = info_path if partial == "jpserver-info" else runtime / partial
    completed = pending.read_text(encoding="utf-8")
    pending.write_text('{"', encoding="utf-8")
    polls = []
    def complete_publication(delay):
        polls.append(delay)
        pending.write_text(completed, encoding="utf-8")
    monkeypatch.setattr(launch.time, "sleep", complete_publication)
    info = runtime.stat()
    assert launch.wait_for_ready(launch.NotebookRuntime(runtime, (info.st_dev, info.st_ino)), child, timeout=1)
    assert polls == [0.05]


@pytest.mark.parametrize("failure", ["missing-marker", "wrong-info-port"])
def test_launcher_refuses_unadmitted_child_before_any_code_or_launch_file(
        identity, tmp_path, monkeypatch, capsys, failure):
    from livemorebio import notebook_launch as launch

    seen = {}
    class TechnicalChild:
        pid = 98765
        returncode = None
        stdout = io.BytesIO(b"technical unadmitted child output\n")
        stderr = io.BytesIO(b"technical unadmitted child error\n")
        signals = []
        def poll(self):
            return self.returncode
        def send_signal(self, signum):
            self.signals.append(signum)
        def wait(self, timeout=None):
            self.returncode = 0
            return 0

    def spawn(command, **kwargs):
        runtime_path = Path(kwargs["env"]["JUPYTER_RUNTIME_DIR"])
        seen["runtime"] = runtime_path
        path = runtime_path / "jpserver-98765.json"
        path.write_text(json.dumps({"port": 18894 if failure == "wrong-info-port" else 18893}), encoding="utf-8")
        path.chmod(0o600)
        if failure == "wrong-info-port":
            info = runtime_path.stat()
            marker = runtime_path / "provider-admitted.json"
            marker.write_text(json.dumps({"schema": "livemore.notebook-admitted.v1", "port": 18893,
                "server_pid": TechnicalChild.pid, "runtime_identity": [info.st_dev, info.st_ino]}), encoding="utf-8")
            marker.chmod(0o600)
        seen["child"] = TechnicalChild()
        return seen["child"]

    def forbid_credential(*args, **kwargs):
        pytest.fail("unadmitted child must not publish a launch credential")

    real_wait = launch.wait_for_ready
    monkeypatch.setattr(launch, "process_identity", lambda pid: "technical-birth")
    monkeypatch.setattr(launch.subprocess, "Popen", spawn)
    monkeypatch.setattr(launch, "wait_for_ready", lambda runtime, child: real_wait(runtime, child, timeout=0))
    monkeypatch.setattr(identity, "mint_code", forbid_credential)
    monkeypatch.setattr(launch, "_launch_page", forbid_credential)
    monkeypatch.setattr(launch, "_instructions", forbid_credential)
    assert launch.run_notebook(tmp_path / "technical-stack", tmp_path / "technical-workspace",
        tmp_path / "technical.ipynb", port=18893, no_browser=True) == 1
    assert seen["child"].signals == [launch.signal.SIGTERM]
    assert not seen["runtime"].exists()
    output = capsys.readouterr()
    assert output.out == ""
    assert output.err == "Notebook launch failed; check the private stack directory and pinned notebook extras.\n"
