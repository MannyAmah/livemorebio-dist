"""L0-R16: no free text leaves the machine.

Round 2 of the patient-data verification found that ``POST /api/trajectory``
sent a free-text factor to EMBL-EBI and that the Cendos compound lookups sent a
typed name to PubChem. These tests hold the one egress check of
``livemorebio/egress.py``:

- **Structural.** Every outbound client in the shipped Python (the public
  manifest's files: urllib, http.client, sockets, ssl, third-party HTTP
  libraries, database drivers/remote SDKs, and subprocess launches) is listed
  below and classified. HTTP clients use ``egress.urlopen``; Neo4j validates
  its whole export before opening its driver. SQLite is explicitly local.
  A new client fails until it is classified here.
- **Data.** Every route slot names a grammar or a vocabulary, every grammar has
  a source, and no grammar admits a SYNTHETIC note.
- **Behaviour.** A local stub transport records every request and sends
  nothing. A SYNTHETIC note in each user-facing field of the three services,
  and in each third-party client called directly, reaches no request; values
  the check admits still reach the stub, so the check does not block the
  product's own lookups.

Every note here is SYNTHETIC: invented names and numbers, and the word
SYNTHETIC. Nothing is sent to the network. Checks reduce to booleans with fixed
messages, so a failing run (``--show-capture=no``) logs no note text.
"""
from __future__ import annotations

import ast
import json
import re
import socket
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

import pytest

from .test_l0_clinical_note_gate import aegle, life  # noqa: F401  (fixtures)

ROOT = Path(__file__).resolve().parents[2]
CODE = "EGRESS_VALUE_NOT_ALLOWED"
NOTE = ("SYNTHETIC note, not a person: Vandrel Quessiby, female, age 61, record SYN-4471, seen 2026-10-02 "
        "by Dr. Orbel; type 2 diabetes, HbA1c 8.4%, started metformin. Phone 415 555 0193.")
UNMARKED = "SYNTHETIC Vandrel Quessiby female age 61 SYN-4471 T2D"
TOKEN_NOTE = "SYNTHETIC_Vandrel_Quessiby_61_SYN-4471"
UPPER_NOTE = "VANDREL-QUESSIBY"
# Distinctive fragments only: a bare four-digit run also turns up by chance in a digest or request id.
FRAGMENTS = ("Vandrel", "Quessiby", "SYN-4471", "415 555 0193")
NOTES = (NOTE, UNMARKED, TOKEN_NOTE)


def _forms(fragment: str) -> set[bytes]:
    out = set()
    for text in (fragment, fragment.lower(), fragment.upper()):
        out |= {text.encode(), urllib.parse.quote(text).encode(), urllib.parse.quote_plus(text).encode(),
                urllib.parse.quote(urllib.parse.quote(text)).encode(), json.dumps(text)[1:-1].encode()}
    return out


_NOTE_FORMS = set().union(*(_forms(fragment) for fragment in FRAGMENTS))


def _carries_note(blob: bytes) -> bool:
    return any(form in blob for form in _NOTE_FORMS)


# ---------------------------------------------------------------- the stub transport

class Outbound:
    """A local stub transport: records every outbound attempt and sends nothing."""

    def __init__(self) -> None:
        self.records: list[tuple[str, bytes]] = []

    def add(self, kind: str, *parts: object) -> None:
        blob = b" ".join(part if isinstance(part, bytes) else str(part).encode("utf-8", "replace")
                         for part in parts if part is not None)
        self.records.append((kind, blob))

    def carrying_note(self) -> list[str]:
        return [kind for kind, blob in self.records if _carries_note(blob)]

    def third_party(self) -> list[tuple[str, bytes]]:
        return [record for record in self.records if record[0] != "subprocess"]


_LOOPBACK = {"localhost", "127.0.0.1", "::1", "", None}


@pytest.fixture
def outbound(monkeypatch):
    """Replace every transport the product could use with a recorder that sends nothing."""
    stub = Outbound()

    def opener_open(self, fullurl, data=None, timeout=None):
        url = fullurl if isinstance(fullurl, str) else fullurl.full_url
        body = data if data is not None else getattr(fullurl, "data", None)
        headers = "" if isinstance(fullurl, str) else json.dumps(dict(fullurl.header_items()))
        stub.add("urllib", url, body, headers)
        raise urllib.error.URLError("technical stub transport: nothing is sent")

    def http_request(self, method, url, body=None, headers=None, **kwargs):
        stub.add("http.client", self.host, method, url, body, json.dumps(dict(headers or {})))
        raise OSError("technical stub transport: nothing is sent")

    def http_connect(self):
        stub.add("http.client", self.host)
        raise OSError("technical stub transport: nothing is sent")

    original_connect = socket.socket.connect
    original_getaddrinfo = socket.getaddrinfo

    def socket_connect(self, address):
        host = address[0] if isinstance(address, tuple) else None
        if self.family in (socket.AF_INET, socket.AF_INET6) and host not in _LOOPBACK:
            stub.add("socket", host)
            raise OSError("technical stub transport: nothing is sent")
        return original_connect(self, address)

    def getaddrinfo(host, *args, **kwargs):
        name = host.decode() if isinstance(host, bytes) else host
        if name not in _LOOPBACK:
            stub.add("dns", name)
            raise socket.gaierror(socket.EAI_NONAME, "technical stub transport: no lookup")
        return original_getaddrinfo(host, *args, **kwargs)

    original_popen = subprocess.Popen.__init__

    def popen(self, args, *rest, **kwargs):
        argv = [str(item) for item in (args if isinstance(args, (list, tuple)) else [args])]
        stub.add("subprocess", *argv)
        if argv and Path(argv[0]).name in NETWORK_TOOLS:
            raise OSError("technical stub transport: no network tool is run")
        return original_popen(self, args, *rest, **kwargs)

    monkeypatch.setattr(urllib.request.OpenerDirector, "open", opener_open)
    monkeypatch.setattr(urllib.request, "urlopen", lambda url, *a, **k: opener_open(None, url, *a, **k))
    monkeypatch.setattr("http.client.HTTPConnection.request", http_request)
    monkeypatch.setattr("http.client.HTTPConnection.connect", http_connect)
    monkeypatch.setattr(socket.socket, "connect", socket_connect)
    monkeypatch.setattr(socket, "getaddrinfo", getaddrinfo)
    monkeypatch.setattr(subprocess.Popen, "__init__", popen)
    return stub


def _clean_records(stub: Outbound, where: str) -> None:
    leaked = stub.carrying_note()
    assert not leaked, f"{where}: an outbound request carried note text ({sorted(set(leaked))})"
    escaped = any(_carries_note(blob) for kind, blob in stub.records if kind == "subprocess")
    assert not escaped, f"{where}: a subprocess argument carried note text"


def _egress_refusal(error: BaseException) -> None:
    typed = getattr(error, "code", None) == CODE
    assert typed, f"not the egress refusal: {type(error).__name__}"
    clean = not _carries_note(f"{error}{error!r}{getattr(error, 'destination', '')}".encode())
    assert clean, "the egress refusal holds note text"


# ---------------------------------------------------------------- structural: every outbound client

@pytest.mark.parametrize("module", [
    "neo4j", "sqlite3", "psycopg", "psycopg2", "asyncpg", "pymysql", "mysql.connector",
    "sqlalchemy", "redis", "pymongo", "motor.motor_asyncio", "supabase", "boto3", "botocore",
    "grpc", "elasticsearch", "opensearchpy", "duckdb", "cassandra.cluster", "pyodbc",
    "oracledb", "clickhouse_connect", "pymssql", "ibm_db", "snowflake.connector",
    "google.cloud", "azure", "firebase_admin", "turingdb", "libsql", "openmed",
])
def test_r17_inventory_detects_database_and_remote_client_imports(module, tmp_path, monkeypatch):
    """Future SDK/driver additions must not silently escape classification."""
    (tmp_path / "probe.py").write_text(f"import {module}\n", encoding="utf-8")
    monkeypatch.setattr(__import__(__name__, fromlist=["ROOT"]), "ROOT", tmp_path)
    detected = any(name == "import:" + module for _, name, *_ in _scan("probe.py"))
    assert detected, "database or remote client import escaped the structural inventory"


def test_r17_reachable_relay_failure_does_not_repeat_name(aegle, outbound, monkeypatch):
    """An admitted local term still must not be repeated in a resolve failure."""
    from contextlib import contextmanager
    from livemorebio import stack_client

    class Response:
        status = 200

        def read(self):
            return json.dumps({"resolved": False, "name": "metformin", "error": "lookup unavailable"}).encode()

    calls = []

    @contextmanager
    def response(*args, **kwargs):
        calls.append(True)
        yield Response()

    monkeypatch.setattr(stack_client, "operation_identity", lambda *a, **kw: object())
    monkeypatch.setattr(stack_client, "startup_identity", lambda *a, **kw: object())
    monkeypatch.setattr(stack_client, "request_response", response)
    answer = aegle[1].get("/api/cendos/compound", params={"name": "metformin"})
    assert calls == [True] and answer.status_code == 200
    payload = answer.json()
    assert payload.get("resolved") is False
    assert "name" not in payload, "reachable relay failure repeats the compound name"


TRANSPORT_EXACT = frozenset({
    "urllib.request.urlopen", "urllib.request.build_opener", "urllib.request.OpenerDirector",
    "http.client.HTTPConnection", "http.client.HTTPSConnection", "socket.socket", "socket.create_connection",
    "socket.getaddrinfo", "asyncio.open_connection", "livemorebio.transport.authenticated_opener",
    "ssl.SSLContext", "ssl.create_default_context", "ssl.wrap_socket", "sqlite3.connect",
})
DATABASE_AND_REMOTE_IMPORTS = frozenset({
    "neo4j", "sqlite3", "psycopg", "psycopg2", "asyncpg", "pymysql", "mysql", "sqlalchemy",
    "redis", "pymongo", "motor", "supabase", "boto3", "botocore", "grpc", "elasticsearch",
    "opensearchpy", "duckdb", "cassandra", "pyodbc", "oracledb", "clickhouse_connect",
    "pymssql", "ibm_db", "snowflake", "google", "azure", "firebase_admin", "turingdb", "libsql", "openmed",
})
TRANSPORT_PREFIXES = ("requests.", "httpx.", "aiohttp.", "urllib3.", "pycurl", "websocket", "ftplib.", "smtplib.",
                      "telnetlib.", "xmlrpc.client.", "imaplib.", "poplib.", "nntplib.", "paramiko.") + tuple(
                          name + "." for name in sorted(DATABASE_AND_REMOTE_IMPORTS - {"sqlite3"}))
NETWORK_IMPORTS = frozenset({"requests", "httpx", "aiohttp", "urllib3", "pycurl", "websocket", "websockets",
                             "ftplib", "smtplib", "telnetlib", "imaplib", "poplib", "nntplib", "paramiko"}) | DATABASE_AND_REMOTE_IMPORTS
EGRESS_SEND = "livemorebio.egress.urlopen"
SUBPROCESS_CALLS = frozenset({
    "subprocess.run", "subprocess.Popen", "subprocess.call", "subprocess.check_call", "subprocess.check_output",
    "subprocess.getoutput", "subprocess.getstatusoutput", "os.system", "os.popen", "os.execv", "os.execve",
    "os.execvp", "os.execvpe", "os.execl", "os.execle", "os.execlp", "os.execlpe", "os.spawnv", "os.spawnve",
    "os.spawnvp", "os.spawnl", "os.posix_spawn", "os.posix_spawnp", "asyncio.create_subprocess_exec",
    "asyncio.create_subprocess_shell", "pty.spawn",
})
NETWORK_TOOLS = frozenset({"curl", "wget", "ssh", "scp", "sftp", "rsync", "nc", "ncat", "netcat", "telnet", "ftp",
                           "docker", "pip", "pip3", "npx", "brew", "apt", "apt-get", "yum", "gh", "aws",
                           "gcloud", "az", "kubectl", "open", "xdg-open"})
GIT_NETWORK = frozenset({"clone", "fetch", "pull", "push", "ls-remote", "remote", "submodule"})

FIRST_PARTY_SERVICES = ("the product's own services (Aegle, LIFE, Cendos) at configured addresses, "
                        "through the stack transport; not a third party")
# Every outbound client in the shipped Python, with its kind. Keys: (file, enclosing scope, what it uses).
INVENTORY: dict[tuple[str, str, str], tuple[str, str]] = {
    ("livemorebio/egress.py", "urlopen", "urllib.request.urlopen"):
        ("egress", "the one sending path for third-party requests; check_request runs first"),
    # third-party clients: each sends through egress.urlopen
    ("livemorebio/adapters.py", "_probe_url", EGRESS_SEND): ("third_party", "adapter health probes"),
    ("livemorebio/aegle/population_sources.py", "_download", EGRESS_SEND): ("third_party", "NHANES pinned files"),
    ("livemorebio/aegle/population_sources.py", "_download", "urllib.request.build_opener"):
        ("third_party", "its no-redirect opener, passed to egress.urlopen"),
    ("livemorebio/anatomy/atlas_reference.py", "_open_source", EGRESS_SEND): ("third_party", "atlas pinned files"),
    ("livemorebio/anatomy/atlas_reference.py", "_open_source", "urllib.request.build_opener"):
        ("third_party", "its no-redirect opener, passed to egress.urlopen"),
    ("livemorebio/anatomy/meshes.py", "_download", EGRESS_SEND): ("third_party", "mesh pinned files"),
    ("livemorebio/cendos/service.py", "compound", EGRESS_SEND): ("third_party", "PubChem compound lookup"),
    ("livemorebio/engines/disease_links.py", "_ot_query", EGRESS_SEND): ("third_party", "Open Targets GraphQL"),
    ("livemorebio/engines/drug_targets.py", "_get", EGRESS_SEND): ("third_party", "ChEMBL"),
    ("livemorebio/engines/foods.py", "_get", EGRESS_SEND): ("third_party", "USDA FoodData Central"),
    ("livemorebio/life_system/reference/build_seed.py", "OpenSourceReader._request", EGRESS_SEND):
        ("third_party", "reference seed refresh (OLS, HGNC, Open Targets, EBI FTP)"),
    ("livemorebio/life_system/reference/build_seed.py", "OpenSourceReader._request", "urllib.request.build_opener"):
        ("third_party", "its no-redirect opener, passed to egress.urlopen"),
    ("livemorebio/life_system/reference/sources/base.py", "Source.fetch", EGRESS_SEND):
        ("third_party", "reference sources (OLS, Orphadata, Reactome, RCSB, GWAS, HPA, HRA, HCA, discovery)"),
    ("livemorebio/life_system/reference/sources/genecards.py", "GeneCards.gene", EGRESS_SEND):
        ("third_party", "licensed GeneCards"),
    ("livemorebio/life_system/reference/sources/genecards.py", "GeneCards.gene",
     "livemorebio.transport.authenticated_opener"): ("third_party", "its credential opener, passed to egress.urlopen"),
    ("livemorebio/life_system/reference/sources/kegg.py", "KEGG.fetch", EGRESS_SEND): ("third_party", "licensed KEGG"),
    ("livemorebio/life_system/reference/sources/kegg.py", "KEGG.fetch", "livemorebio.transport.authenticated_opener"):
        ("third_party", "its credential opener, passed to egress.urlopen"),
    ("livemorebio/model_assets.py", "_open_url", EGRESS_SEND): ("third_party", "pinned model files"),
    ("livemorebio/model_assets.py", "_open_url", "urllib.request.build_opener"):
        ("third_party", "its no-redirect opener, passed to egress.urlopen"),
    ("tools/refresh_scientific_source_catalog.py", "_fetch", EGRESS_SEND):
        ("third_party", "NAR and ELIXIR index pages for the governed catalog refresh"),
    # first-party clients: the product's own services, loopback, or local descriptors
    ("livemorebio/doctor.py", "_probe", "urllib.request.urlopen"):
        ("first_party", "livemore doctor's health checks of the product's own configured service endpoints"),
    ("livemorebio/console_session.py", "bootstrap_console_cookie_pipe", "socket.socket"):
        ("first_party", "wraps an inherited local pipe descriptor; no network address"),
    ("livemorebio/notebook_launch.py", "_port_held", "socket.socket"):
        ("first_party", "probes 127.0.0.1 for the notebook's own port"),
    ("livemorebio/stack_readiness.py", "listener_reachable", "socket.socket"): ("first_party", FIRST_PARTY_SERVICES),
    ("livemorebio/stack_transport.py", "_Budget.arm", "socket.socket"): ("first_party", FIRST_PARTY_SERVICES),
    ("livemorebio/stack_transport.py", "_resolve_worker", "socket.getaddrinfo"): ("first_party", FIRST_PARTY_SERVICES),
    ("livemorebio/stack_transport.py", "_BoundedReader.__init__", "socket.socket"):
        ("first_party", FIRST_PARTY_SERVICES),
    ("livemorebio/stack_transport.py", "_Connection", "http.client.HTTPConnection"):
        ("first_party", FIRST_PARTY_SERVICES),
    ("livemorebio/stack_transport.py", "_Connection.__init__", "socket.socket"): ("first_party", FIRST_PARTY_SERVICES),
    ("livemorebio/stack_transport.py", "_Connection._response", "socket.socket"):
        ("first_party", FIRST_PARTY_SERVICES),
    ("livemorebio/stack_transport.py", "_connect", "socket.socket"): ("first_party", FIRST_PARTY_SERVICES),
    ("livemorebio/stack_transport.py", "_connect", "ssl.create_default_context"): ("first_party", FIRST_PARTY_SERVICES),
    ("livemorebio/stack_transport.py", "_assert_live", "socket.socket"): ("first_party", FIRST_PARTY_SERVICES),
    ("livemorebio/stack_transport.py", "_prove", "socket.socket"): ("first_party", FIRST_PARTY_SERVICES),
    ("livemorebio/transport.py", "<module>", "urllib.request.OpenerDirector"):
        ("first_party", "a type annotation of the shared credential opener"),
    ("livemorebio/transport.py", "authenticated_opener", "urllib.request.build_opener"):
        ("first_party", "builds the credential opener; its third-party users send it through egress.urlopen"),
    ("livemorebio/transport.py", "authenticated_opener", "urllib.request.OpenerDirector"):
        ("first_party", "a type annotation of the shared credential opener"),
    ("tools/check_atlas_presentation.py", "health", "http.client.HTTPConnection"):
        ("first_party", "the presentation harness's health check of its own loopback services"),
    ("tools/check_atlas_presentation.py", "free_ports", "socket.socket"):
        ("first_party", "the presentation harness's loopback port check"),
    ("tools/run_review_stack.py", "main", "socket.socket"): ("first_party", "the review stack's loopback port check"),
    # subprocesses
    ("livemorebio/_toolchain.py", "_npm_global_root", "process:dynamic"): ("process", "npm root -g: prints a local path"),
    ("livemorebio/aegle/evidence_api.py", "_code_version", "process:git"): ("process", "git rev-parse/status, local"),
    ("livemorebio/aegle/execution_worker.py", "IsolatedAdapter.__init__", "process:python"):
        ("process", "the product's isolated execution worker"),
    ("livemorebio/anatomy/atlas_reference.py", "_launch_phase", "process:dynamic"):
        ("process", "the atlas acquisition child (python); its downloads use _open_source, through the egress check"),
    ("livemorebio/audit.py", "provenance", "process:git"): ("process", "git rev-parse, local"),
    ("livemorebio/build_info.py", "_commit", "process:git"): ("process", "git rev-parse, local"),
    ("livemorebio/cli.py", "start", "process:dynamic"): ("process", "the product's own services (python)"),
    ("livemorebio/cli.py", "_compose", "process:dynamic"):
        ("network_process", "docker compose with the product's compose file; up --build may pull the Dockerfile's "
                            "pinned base image. The arguments are the compose file and fixed actions; no user value"),
    ("livemorebio/engines/stoichiometry.py", "execute", "process:python"): ("process", "the product's solver worker"),
    ("livemorebio/notebook_launch.py", "run_notebook", "process:dynamic"):
        ("process", "the local Jupyter server on 127.0.0.1"),
    ("tools/build_release.py", "_git", "process:git"): ("process", "git rev-parse/ls-files, local"),
    ("tools/build_release.py", "_committed_file", "process:git"): ("process", "git show, local"),
    ("tools/build_release.py", "build", "process:git"): ("process", "git archive, local"),
    ("tools/installer_gate.py", "_resolve_commit", "process:git"):
        ("process", "git rev-parse of the author's release reference, local"),
    ("tools/installer_gate.py", "_build_release", "process:dynamic"):
        ("process", "runs the local release publisher for the pinned commit; no acquisition"),
    ("tools/installer_gate.py", "run_gate", "process:dynamic"):
        ("network_process", "local author gate runs the pinned archive's installer and activated CLI --help; "
                            "only the installer acquires pinned dependencies/models; no clinical input"),
    ("tools/check_atlas_presentation.py", "inspect_listeners", "process:/usr/sbin/lsof"):
        ("process", "lsof of local listeners"),
    ("tools/check_atlas_presentation.py", "process_snapshot", "process:/bin/ps"): ("process", "ps, local"),
    ("tools/check_atlas_presentation.py", "main", "process:dynamic"):
        ("process", "the harness's own loopback services and its local browser driver"),
    ("tools/check_legacy_preview_browser.py", "main", "process:dynamic"):
        ("process", "the harness's own loopback services and its local browser driver"),
    ("tools/rollback_drill.py", "_run_phase", "process:dynamic"):
        ("process", "runs only reviewed local adapter commands, with no network"),
    ("tools/run_review_stack.py", "main", "process:dynamic"): ("process", "the product's own services (python)"),
    ("tools/run_review_tests.py", "main", "process:python"): ("process", "pytest, local"),
    ("tools/secret_scan.py", "Scanner._git", "process:dynamic"): ("process", "git rev-list/diff-tree, local"),
    ("tools/verify_public_release.py", "working_tree_ref", "process:git"): ("process", "git read-tree/add/write-tree, local"),
    ("tools/verify_public_release.py", "run_suite", "process:dynamic"): ("process", "pytest -m 'not network', local"),
}

# SQLite is an in-process file store, not a remote database; even its error-only
# imports are classified so adding another driver cannot silently evade review.
for _path in (
    "aegle/execution_store.py", "aegle/reference_cohorts.py", "aegle/registry_audit.py",
    "aegle/registry_bootstrap.py", "aegle/research_api.py", "aegle/server.py", "aegle/subjects.py",
    "cendos/lims/db.py", "cendos/protocol_runs.py", "cendos/service.py", "evidence/signing_commands.py",
    "evidence/store.py", "life_patch/virtual_session_store.py", "research.py",
):
    INVENTORY[("livemorebio/" + _path, "<module>", "import:sqlite3")] = (
        "local_database", "SQLite file storage or its error/type references; no remote transport")
for _path, _scope in (
    ("aegle/execution_store.py", "ExecutionStore._connection"),
    ("aegle/subjects.py", "SubjectRegistry._connect"),
    ("cendos/lims/db.py", "DB.__init__"),
    ("cendos/protocol_runs.py", "ProtocolRunStore._index"),
    ("evidence/store.py", "EvidenceStore._connect"),
    ("evidence/store.py", "EvidenceStore._read_export_database"),
    ("research.py", "ResearchStore._connect"),
):
    INVENTORY[("livemorebio/" + _path, _scope, "sqlite3.connect")] = (
        "local_database", "SQLite opens a local file, including read-only export URIs; no remote transport")
for _site in ("import:neo4j", "neo4j.GraphDatabase.driver"):
    INVENTORY[("livemorebio/scientific_sources/graph_backends.py", "Neo4jBackend._driver", _site)] = (
        "remote_database", "sync admits a detached export through egress.check_graph_export before this driver")
INVENTORY[("livemorebio/life_system/extract.py", "OpenMedNER.client", "import:openmed")] = (
    "disabled_remote_capable_sdk", "clinical_note_gate refuses every extract call before client acquisition or inference")


def _shipped_python() -> list[str]:
    manifest = (ROOT / "tools/public_release_manifest.txt").read_text(encoding="utf-8").splitlines()
    return sorted(path for path in manifest if path.endswith(".py") and "/tests/" not in path)


def _bind(node: ast.AST, path: str, names: dict[str, str]) -> None:
    if isinstance(node, ast.Import):
        for alias in node.names:
            names[alias.asname or alias.name.split(".")[0]] = alias.name if alias.asname else alias.name.split(".")[0]
    elif isinstance(node, ast.ImportFrom):
        base = node.module or ""
        if node.level:
            package = path[:-3].split("/")[:-1]
            package = package[: len(package) - (node.level - 1)]
            base = ".".join(package + ([base] if base else []))
        for alias in node.names:
            names[alias.asname or alias.name] = f"{base}.{alias.name}" if base else alias.name


def _dotted(expr: ast.AST, names: dict[str, str]) -> str | None:
    if isinstance(expr, ast.Name):
        return names.get(expr.id, expr.id)
    if isinstance(expr, ast.Attribute):
        inner = _dotted(expr.value, names)
        return f"{inner}.{expr.attr}" if inner else None
    return None


def _scan(path: str) -> list[tuple[str, str, ast.AST, dict[str, str], ast.AST]]:
    """Every outbound client reference in one shipped file: (scope, what, node, names, scope node)."""
    tree = ast.parse((ROOT / path).read_text(encoding="utf-8"))
    module_names: dict[str, str] = {}
    for node in tree.body:
        _bind(node, path, module_names)
    found = []

    def visit(node, scope, names, scope_node):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            inner = dict(names)
            for sub in ast.walk(node):
                if isinstance(sub, (ast.Import, ast.ImportFrom)):
                    _bind(sub, path, inner)
            child_scope = node.name if scope == "<module>" else f"{scope}.{node.name}"
            for child in ast.iter_child_nodes(node):
                visit(child, child_scope, inner, node)
            return
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            modules = ([alias.name for alias in node.names] if isinstance(node, ast.Import)
                       else [node.module or ""])
            for module in modules:
                if module.split(".")[0] in NETWORK_IMPORTS:
                    found.append((scope, "import:" + module, node, names, scope_node))
        if isinstance(node, (ast.Name, ast.Attribute)):
            name = _dotted(node, names)
            if name and (name in TRANSPORT_EXACT or name.startswith(TRANSPORT_PREFIXES) or name == EGRESS_SEND):
                found.append((scope, name, node, names, scope_node))
                return
        if isinstance(node, ast.Call) and _dotted(node.func, names) in SUBPROCESS_CALLS:
            argv = node.args[0] if node.args else next((k.value for k in node.keywords if k.arg == "args"), None)
            tool = "dynamic"
            if isinstance(argv, (ast.List, ast.Tuple)) and argv.elts:
                first = argv.elts[0]
                if isinstance(first, ast.Constant) and isinstance(first.value, str):
                    tool = first.value
                elif _dotted(first, names) == "sys.executable":
                    tool = "python"
            elif isinstance(argv, ast.Constant) and isinstance(argv.value, str):
                tool = argv.value.split()[0] if argv.value.split() else "dynamic"
            found.append((scope, "process:" + tool, node, names, scope_node))
        for child in ast.iter_child_nodes(node):
            visit(child, scope, names, scope_node)

    visit(tree, "<module>", module_names, tree)
    return found


def _all_sites():
    sites = {}
    for path in _shipped_python():
        for scope, name, node, names, scope_node in _scan(path):
            sites.setdefault((path, scope, name), []).append((node, names, scope_node))
    return sites


def test_every_outbound_client_in_the_shipped_code_is_listed_and_classified():
    found = set(_all_sites())
    unlisted = sorted(found - set(INVENTORY))
    assert not unlisted, f"outbound clients not classified for L0-R16: {unlisted}"
    gone = sorted(set(INVENTORY) - found)
    assert not gone, f"listed outbound clients no longer in the code: {gone}"
    shipped = _shipped_python()
    assert len(shipped) > 150 and "livemorebio/egress.py" in shipped, "the shipped file list is not the manifest's"
    assert all(INVENTORY[key][0] in {"local_database", "remote_database", "disabled_remote_capable_sdk"}
               for key in found if key[2].startswith("import:")), "an ungoverned remote library is imported"


def _call_to(node: ast.AST, target: str, names: dict[str, str]) -> bool:
    return isinstance(node, ast.Call) and _dotted(node.func, names) == target


def test_every_third_party_client_sends_through_the_egress_check():
    sites = _all_sites()
    for key, (kind, _reason) in INVENTORY.items():
        if kind != "third_party":
            continue
        assert key in sites, f"{key[0]}:{key[1]} does not send through egress.urlopen"
        for node, names, scope_node in sites[key]:
            if key[2] == EGRESS_SEND:
                is_call = any(_call_to(parent, EGRESS_SEND, names) and parent.func is node
                              for parent in ast.walk(scope_node))
                assert is_call, f"{key}: egress.urlopen is referenced but not called"
                continue
            # Any other transport in a third-party client is only the opener handed to egress.urlopen.
            handed = any(_call_to(call, EGRESS_SEND, names) and any(
                keyword.arg == "opener" and any(sub is node for sub in ast.walk(keyword.value))
                for keyword in call.keywords) for call in ast.walk(scope_node))
            assert handed, f"{key}: a transport outside egress.urlopen(opener=...)"
    third_party_scopes = {(path, scope) for (path, scope, _), (kind, _) in INVENTORY.items() if kind == "third_party"}
    for path, scope, name in sites:
        if name in {"urllib.request.urlopen", "http.client.HTTPConnection", "http.client.HTTPSConnection"}:
            assert (path, scope) not in third_party_scopes, f"{path}:{scope} sends outside the egress check"

    # The one remote database client has a different wire protocol, but the
    # same admission boundary: all payloads checked before any driver/session.
    remote = {key for key, (kind, _) in INVENTORY.items() if kind == "remote_database"}
    assert remote == {
        ("livemorebio/scientific_sources/graph_backends.py", "Neo4jBackend._driver", "import:neo4j"),
        ("livemorebio/scientific_sources/graph_backends.py", "Neo4jBackend._driver", "neo4j.GraphDatabase.driver"),
    }
    tree = ast.parse((ROOT / "livemorebio/scientific_sources/graph_backends.py").read_text(encoding="utf-8"))
    backend = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "Neo4jBackend")
    sync = next(node for node in backend.body if isinstance(node, ast.FunctionDef) and node.name == "sync")
    calls = [node for node in ast.walk(sync) if isinstance(node, ast.Call)]
    checks = [node.lineno for node in calls if isinstance(node.func, ast.Attribute)
              and isinstance(node.func.value, ast.Name) and node.func.value.id == "egress"
              and node.func.attr == "check_graph_export"]
    sends = [node.lineno for node in calls if isinstance(node.func, ast.Attribute)
             and node.func.attr in {"_driver", "session", "run"}]
    assert checks and sends and max(checks) < min(sends), "Neo4j sends before graph admission"

    disabled = {key for key, (kind, _) in INVENTORY.items() if kind == "disabled_remote_capable_sdk"}
    assert disabled == {("livemorebio/life_system/extract.py", "OpenMedNER.client", "import:openmed")}
    source = ast.parse((ROOT / "livemorebio/life_system/extract.py").read_text(encoding="utf-8"))
    wrapper = next(node for node in source.body if isinstance(node, ast.ClassDef) and node.name == "OpenMedNER")
    extract = next(node for node in wrapper.body if isinstance(node, ast.FunctionDef) and node.name == "extract")
    first = extract.body[0]
    assert (isinstance(first, ast.Expr) and isinstance(first.value, ast.Call)
            and isinstance(first.value.func, ast.Name) and first.value.func.id == "clinical_note_gate"), (
                "remote-capable inference wrapper is no longer unconditionally gated")


def test_the_egress_send_checks_before_it_sends():
    from livemorebio import egress

    tree = ast.parse((ROOT / "livemorebio/egress.py").read_text(encoding="utf-8"))
    function = next(node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name == "urlopen")
    calls = [node for node in ast.walk(function) if isinstance(node, ast.Call)]
    check = min(node.lineno for node in calls if isinstance(node.func, ast.Name) and node.func.id == "check_request")
    sends = [node.lineno for node in calls if isinstance(node.func, ast.Attribute) and node.func.attr in {"open", "urlopen"}]
    assert sends and all(check < line for line in sends), "egress.urlopen sends before it checks"
    for statement in function.body:
        if isinstance(statement, (ast.Try, ast.With)):
            raise AssertionError("egress.urlopen must not swallow the refusal")
    assert issubclass(egress.EgressRefused, Exception) and not issubclass(egress.EgressRefused, OSError), (
        "a refusal must not read as a transport failure")


def test_no_subprocess_reaches_a_network_tool_unlisted():
    for (path, scope, name), (kind, reason) in INVENTORY.items():
        if not name.startswith("process:"):
            continue
        tool = Path(name.split(":", 1)[1]).name
        assert kind in {"process", "network_process"} and reason, f"{path}:{scope} unclassified"
        if tool in NETWORK_TOOLS:
            assert kind == "network_process", f"{path}:{scope} runs {tool} unlisted as a network process"
    for path in _shipped_python():
        tree = ast.parse((ROOT / path).read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, (ast.List, ast.Tuple)) and node.elts and isinstance(node.elts[0], ast.Constant):
                head = node.elts[0].value
                if head == "git":
                    words = {elt.value for elt in node.elts if isinstance(elt, ast.Constant)}
                    assert not words & GIT_NETWORK, f"{path}: a git network command"
                if isinstance(head, str) and head in {"curl", "wget", "ssh", "scp", "rsync", "nc"}:
                    raise AssertionError(f"{path}: a network tool command")


def test_the_console_cannot_reach_a_third_party_from_the_browser():
    from livemorebio.http_security import CONSOLE_CSP

    directives = dict(part.strip().split(" ", 1) for part in CONSOLE_CSP.split(";") if part.strip())
    assert directives["connect-src"] == "'self'"
    for directive in ("default-src", "script-src", "img-src", "frame-src", "font-src"):
        assert "http" not in directives[directive], f"{directive} admits a remote origin"


# ---------------------------------------------------------------- the data

def test_every_route_slot_names_a_sourced_grammar_or_a_vocabulary():
    from livemorebio import egress
    from livemorebio.egress_destinations import DESTINATIONS, GRAMMARS, VOCABULARIES

    for name, grammar in GRAMMARS.items():
        assert grammar.get("source", "").strip(), f"grammar {name} has no source"
        compiled = re.compile(grammar["pattern"])
        for note in (*NOTES, UPPER_NOTE.lower(), " "):
            admitted = compiled.fullmatch(note) is not None
            assert not admitted, f"grammar {name} admits a note"
        assert " " not in grammar["pattern"] or name == "opentargets_evidence_counts_document"
    for name in VOCABULARIES:
        terms = egress.vocabulary(name)
        assert terms, f"vocabulary {name} is empty"
        holds_note = any(_carries_note(term.encode()) for term in terms)
        assert not holds_note, f"vocabulary {name} holds note text"
    assert set(VOCABULARIES) >= {"compound_term", "food_term", "reference_term", "organ_term"}
    slot = re.compile(r"\{([^{}]+)\}")
    for identifier, destination in DESTINATIONS.items():
        assert destination.get("service") and destination["routes"], identifier
        assert all(base.startswith("https://") for base in destination["bases"]), identifier
        for route in destination["routes"]:
            texts = [route.get("path", ""), json.dumps(route.get("query", {})), json.dumps(route.get("body"))]
            for text in texts:
                for spec in slot.findall(text):
                    if spec.startswith("const:"):
                        assert isinstance(egress._const(spec[len("const:"):]), str), spec
                        continue
                    for name in spec.split("|"):
                        assert name in GRAMMARS or name in VOCABULARIES, f"{identifier}: unknown slot {name}"
            if "pinned" in route:
                assert route["pinned"] in VOCABULARIES and route["pinned"].startswith("pinned_")


def _document(template: str) -> str:
    from livemorebio import egress

    constant = re.fullmatch(r"\{const:(.+)\}", template)
    return egress._const(constant.group(1)) if constant else template


@pytest.mark.parametrize("note", range(len(NOTES)))
def test_no_destination_admits_a_note_in_any_slot(note):
    """Put the note in each slot of each route in turn: the check refuses every one."""
    from livemorebio.egress import EgressRefused, check_request
    from livemorebio.egress_destinations import DESTINATIONS

    text = NOTES[note]
    tried = 0
    for identifier, destination in DESTINATIONS.items():
        for base in destination["bases"]:
            for route in destination["routes"]:
                if "pinned" in route:
                    urls = [base + urllib.parse.quote(text), base + "x?q=" + urllib.parse.quote(text)]
                    bodies = [None]
                else:
                    path = re.sub(r"\{[^{}]+\}", urllib.parse.quote(text, safe=""), route["path"])
                    query = {key: text for key in route.get("query", {})}
                    # The note in every slot and query value, and the note as an extra query key.
                    urls = [base + path + "?" + urllib.parse.urlencode({**query, "extra": text})]
                    if path != route["path"] or query:
                        urls.append(base + path + ("?" + urllib.parse.urlencode(query) if query else ""))
                    bodies = [None]
                    if route.get("body") is not None:
                        urls = [base + path]
                        bodies = [json.dumps({"query": text, "variables": {"id": text, "q": text}}).encode()]
                        if route["body"]["variables"]:
                            bodies.append(json.dumps({"query": _document(route["body"]["query"]), "variables": {
                                      key: text for key in route["body"]["variables"]}}).encode())
                for url in urls:
                    for body in bodies:
                        tried += 1
                        with pytest.raises(EgressRefused) as caught:
                            check_request(url, method=route.get("method", "GET"), body=body)
                        _egress_refusal(caught.value)
    assert tried > 40, "the sweep found too few routes"


# ---------------------------------------------------------------- behaviour: third-party clients called directly

@pytest.fixture
def licensed(monkeypatch):
    for key, value in {
        "LIVEMORE_KEGG_COMMERCIAL_LICENSE": "acknowledged", "LIVEMORE_KEGG_LICENSE_ID": "TECHNICAL-LICENSE",
        "LIVEMORE_KEGG_API_BASE": "https://licensed.technical.invalid/kegg/",
        "LIVEMORE_KEGG_APPROVED_HOST": "licensed.technical.invalid",
        "LIVEMORE_GENECARDS_COMMERCIAL_LICENSE": "acknowledged", "LIVEMORE_GENECARDS_LICENSE_ID": "TECHNICAL-LICENSE",
        "LIVEMORE_GENECARDS_API_BASE": "https://licensed.technical.invalid/genecards/",
        "GENECARDS_API_TOKEN": "technical-token", "USDA_API_KEY": "DEMO_KEY",
    }.items():
        monkeypatch.setenv(key, value)


def _clients(tmp_path):
    """Each third-party client, called with a value that carries the note."""
    from livemorebio.discovery.sources import ChEMBL, PubChem
    from livemorebio.engines import disease_links, drug_targets, factors, foods
    from livemorebio.life_system.reference import build_seed, current_open_targets
    from livemorebio.life_system.reference.sources import (
        HRA, KEGG, RCSB, DiseaseOntology, GeneCards, Orphanet, ProteinAtlas, Reactome)
    from livemorebio.life_system.reference.sources.gwas import GWAS
    from livemorebio import model_assets
    from tools import refresh_scientific_source_catalog as catalog

    cache = str(tmp_path / "refcache")
    for cached in (drug_targets.resolve_drug, drug_targets.resolve_bioactive, foods.resolve_food):
        cached.cache_clear()

    def clients(value):
        quoted = urllib.parse.quote(value, safe="")
        return {
            "chembl-drug": lambda: drug_targets.resolve_drug(value),
            "chembl-bioactive": lambda: drug_targets.resolve_bioactive(value),
            "chembl-factor": lambda: factors.resolve_factor(value),
            "usda-food": lambda: foods.resolve_food(value),
            "opentargets-target": lambda: disease_links._ot_query(disease_links.TARGET_SEARCH_QUERY, {"q": value}),
            "opentargets-document": lambda: disease_links._ot_query("query { " + value + " }", {}),
            "ols-search": lambda: DiseaseOntology(offline=False, cache_dir=cache).search(value),
            "reactome-query": lambda: Reactome(offline=False, cache_dir=cache).query(value),
            "reactome-pathway": lambda: Reactome(offline=False, cache_dir=cache).subpathways(quoted),
            "orphanet": lambda: Orphanet(offline=False, cache_dir=cache).by_orphacode(quoted),
            "rcsb": lambda: RCSB(offline=False, cache_dir=cache).entry(quoted),
            "protein-atlas": lambda: ProteinAtlas(offline=False, cache_dir=cache).gene(quoted),
            "hra-organ": lambda: HRA(offline=False, cache_dir=cache).cell_types(value),
            "gwas": lambda: GWAS(offline=False, cache_dir=cache).snp_associations(quoted),
            "pubchem-discovery": lambda: PubChem(offline=False, cache_dir=cache).compound(value),
            "chembl-discovery": lambda: ChEMBL(offline=False, cache_dir=cache).molecule(value),
            "kegg-drug": lambda: KEGG(offline=False, cache_dir=cache).find_drug(value),
            "kegg-gene": lambda: KEGG(offline=False, cache_dir=cache).gene(UPPER_NOTE),
            "genecards": lambda: GeneCards(offline=False, cache_dir=cache).gene(UPPER_NOTE),
            "seed-search": lambda: current_open_targets.search_ids(build_seed.OpenSourceReader(), value, "disease"),
            "seed-ols": lambda: build_seed._disease_identity(build_seed.OpenSourceReader(), value),
            "seed-hgnc": lambda: build_seed._hgnc(build_seed.OpenSourceReader(), "symbol", value),
            "model-file": lambda: model_assets._open_url(urllib.request.Request(
                "https://raw.githubusercontent.com/" + quoted), 5),
            "catalog-refresh": lambda: catalog._fetch(catalog.NAR_BASE + "cat/" + quoted),
        }
    return clients


def _egress_refused_type():
    try:
        from livemorebio.egress import EgressRefused
    except ImportError:  # a tree without the egress check: nothing to catch, the stub sees what is sent
        return ()
    return EgressRefused


@pytest.mark.parametrize("note", range(len(NOTES)))
def test_each_third_party_client_refuses_a_note_before_any_request(outbound, licensed, tmp_path, monkeypatch, note):
    EgressRefused = _egress_refused_type()

    monkeypatch.setenv("LIVEMORE_CACHE", str(tmp_path / "refcache"))
    clients = _clients(tmp_path)(NOTES[note])
    refused = []
    for name, call in clients.items():
        try:
            call()
        except EgressRefused as error:
            _egress_refusal(error)
            refused.append(name)
        except Exception:
            # The client folded the refusal into its own failure: still nothing may have been sent.
            pass
        sent = outbound.third_party()
        assert not sent, f"{name}: a request was attempted for a note ({[kind for kind, _ in sent]})"
    _clean_records(outbound, "third-party clients")
    # User-facing lookups surface the typed refusal rather than an "unresolved" answer.
    assert {"chembl-drug", "chembl-bioactive", "chembl-factor", "usda-food", "ols-search", "kegg-drug",
            "genecards", "catalog-refresh"} <= set(refused), sorted(set(clients) - set(refused))


def test_values_the_check_admits_still_reach_the_transport(outbound, licensed, tmp_path, monkeypatch):
    """The check must not block the product's own lookups: technical values reach the stub."""
    from livemorebio import adapters
    from livemorebio.aegle import population_sources
    from livemorebio.engines import disease_links, drug_targets
    from livemorebio.life_system.reference import build_seed, current_open_targets
    from livemorebio.life_system.reference.sources import KEGG, DiseaseOntology, GeneCards
    from livemorebio import model_assets

    monkeypatch.setenv("LIVEMORE_CACHE", str(tmp_path / "refcache"))
    cache = str(tmp_path / "refcache")
    drug_targets.resolve_drug.cache_clear()
    calls = {
        "chembl": lambda: drug_targets.resolve_drug("metformin"),
        "chembl-id": lambda: drug_targets.resolve_bioactive("CHEMBL1431"),
        "opentargets": lambda: disease_links._ot_query(disease_links.TARGET_DISEASES_QUERY,
                                                       {"id": "ENSG00000148737", "n": 8}),
        "ols": lambda: DiseaseOntology(offline=False, cache_dir=cache).search("type 2 diabetes mellitus"),
        "kegg": lambda: KEGG(offline=False, cache_dir=cache).human_pathways(),
        "genecards": lambda: GeneCards(offline=False, cache_dir=cache).gene("TCF7L2"),
        "seed": lambda: build_seed.OpenSourceReader().graphql(current_open_targets.VERSION_QUERY),
        "model": lambda: model_assets._open_url(urllib.request.Request(sorted(model_assets.pinned_source_urls())[0]), 5),
        "nhanes": lambda: population_sources._download(population_sources.ARTIFACTS[0]),
    }
    for name, call in calls.items():
        before = len(outbound.records)
        try:
            call()
        except Exception:
            pass
        assert len(outbound.records) > before, f"{name}: an admitted request did not reach the transport"
    adapters._PROBE_RESULTS.clear()
    rows = adapters.statuses(probe=True, timeout=0.5)
    probed = [row["id"] for row in rows if row.get("status") in {"ready", "degraded"}]
    reached = {urllib.parse.urlsplit(blob.split(b" ")[0].decode()).hostname for kind, blob in outbound.records
               if kind == "urllib"}
    for row in adapters._ADAPTERS:
        if row.get("probe_url") and row["id"] in probed:
            assert urllib.parse.urlsplit(row["probe_url"]).hostname in reached, f"probe {row['id']} was refused"
    _clean_records(outbound, "admitted lookups")


# ---------------------------------------------------------------- behaviour: every user-facing field of the services

# The product's own services, as peers the routes may call: addresses where nothing listens, never
# the installation's 127.0.0.1:8850-8852.
PEERS = {"AEGLE": "http://127.0.0.1:24197", "LIFE": "http://127.0.0.1:24198", "CENDOS": "http://127.0.0.1:24199"}


@pytest.fixture
def unused_peers(monkeypatch):
    for role, url in PEERS.items():
        monkeypatch.setenv(f"LIVEMORE_{role}_URL", url)
        monkeypatch.setenv(f"LIVEMORE_{role}_IDENTITY_AUTHORITY", url)
    return PEERS


@pytest.fixture
def services(aegle, life, unused_peers, monkeypatch):  # noqa: F811
    from fastapi.testclient import TestClient
    from livemorebio.aegle.runtime import AegleTwin
    from livemorebio.cendos import service as cendos

    server, aegle_client = aegle
    monkeypatch.setattr(server, "_state", {"tw": AegleTwin("healthy"), "subject": None, "initialized": True})
    cendos_client = TestClient(cendos.app, raise_server_exceptions=False,
                               headers={"Authorization": "Bearer technical-note-gate-token"})
    life_client = life if not isinstance(life, tuple) else life[-1]
    return {"aegle": (server.app, aegle_client), "life": (life_client.app, life_client),
            "cendos": (cendos.app, cendos_client)}


def _body_keys(endpoint) -> set[str]:
    """Request keys read by a handler and the functions to which it delegates.

    Resolve local imports as well as globals: protocol routes import their
    validators inside the endpoint, and Cendos passes the validator as a
    callback to its shared protocol handler. Merely walking the endpoint's
    syntax misses every field of those specifications.
    """
    return set().union(*(_function_body_keys(function) for function in _body_helpers(endpoint)))


def _body_helpers(endpoint):
    import importlib
    import inspect
    import textwrap

    pending, seen = [endpoint], set()
    while pending:
        function = pending.pop()
        if inspect.ismethod(function):
            function = function.__func__
        function = inspect.unwrap(function)
        if not inspect.isfunction(function) or function in seen:
            continue
        if not function.__module__.startswith("livemorebio."):
            continue
        seen.add(function)
        yield function
        try:
            tree = ast.parse(textwrap.dedent(inspect.getsource(function)))
        except (OSError, TypeError, SyntaxError):
            continue
        names = dict(function.__globals__)
        parameters = set(inspect.signature(function).parameters) - {"self", "cls"}
        package = function.__module__.rpartition(".")[0]
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                module_name = "." * node.level + (node.module or "")
                try:
                    module = importlib.import_module(module_name, package=package)
                except ImportError:
                    continue
                for alias in node.names:
                    names[alias.asname or alias.name] = getattr(module, alias.name, None)
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            def resolve(expression):
                if isinstance(expression, ast.Name):
                    return names.get(expression.id)
                if isinstance(expression, ast.Attribute):
                    return getattr(resolve(expression.value), expression.attr, None)
                return None
            candidate = resolve(node.func)
            # Follow input parsers, direct delegates and validator callbacks;
            # do not recursively traverse arbitrary scientific calculations.
            inputs = {child.id for argument in [*node.args, *(keyword.value for keyword in node.keywords)]
                      for child in ast.walk(argument)
                      if isinstance(child, ast.Name)}
            if inputs & (parameters | {"req", "request", "body", "b", "payload", "params", "p", "raw", "data", "spec", "configuration", "fields"}):
                pending.append(candidate)
            for keyword in node.keywords:
                if keyword.arg in {"validate", "validator"} and isinstance(keyword.value, ast.Name):
                    pending.append(names.get(keyword.value.id))


def _function_body_keys(function) -> set[str]:
    import inspect
    import textwrap

    try:
        tree = ast.parse(textwrap.dedent(inspect.getsource(function)))
    except (OSError, TypeError, SyntaxError):
        return set()
    keys: set[str] = set()
    body_names = {"body", "b", "payload", "params", "p", "raw", "data", "spec", "configuration", "fields", "value"}
    body_names |= set(inspect.signature(function).parameters) - {"self", "cls"}
    for node in ast.walk(tree):
        if (isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name)
                and node.value.id in body_names and isinstance(node.slice, ast.Constant)
                and isinstance(node.slice.value, str)):
            keys.add(node.slice.value)
        elif isinstance(node, ast.Call):
            arguments = []
            if (isinstance(node.func, ast.Attribute) and node.func.attr in {"get", "pop", "setdefault"}
                    and isinstance(node.func.value, ast.Name) and node.func.value.id in body_names):
                arguments = node.args[:1]
            elif (isinstance(node.func, ast.Name)
                    and node.func.id not in {"getattr", "hasattr", "setattr", "delattr"}
                    and node.args and isinstance(node.args[0], ast.Name)
                    and node.args[0].id in body_names):
                arguments = node.args[1:2]
            for argument in arguments:
                if isinstance(argument, ast.Constant) and isinstance(argument.value, str) and argument.value.isidentifier():
                    keys.add(argument.value)
    return {key for key in keys if len(key) <= 40}


@pytest.mark.parametrize("service,path", [
    ("aegle", "/api/cendos/protocols/exogenous-insulin"),
    ("aegle", "/api/cendos/protocols/botanical-exposure"),
    ("cendos", "/protocols/exogenous-insulin"),
    ("cendos", "/protocols/botanical-exposure"),
], ids=["aegle-insulin", "aegle-botanical", "cendos-insulin", "cendos-botanical"])
def test_field_inventory_follows_protocol_helpers(services, service, path):
    """R17: protocol bodies are delegated; endpoint-only discovery missed label."""
    app, _ = services[service]
    endpoint = next(route.endpoint for route in app.routes if getattr(route, "path", None) == path)
    discovered = _body_keys(endpoint)
    assert "label" in discovered, "field inventory did not reach the protocol helper"


"""R17 field-sweep baselines; technical authored fixtures, no observed data.

No requests at import. Cendos route/helper input validators remain real. Storage
and expensive calculations AFTER validation are replaced with local stubs.
"""
from copy import deepcopy
from dataclasses import asdict
from types import SimpleNamespace
import ast
import dis
import inspect
import sys
import textwrap
import threading
from dataclasses import dataclass
from functools import lru_cache
import hashlib
from types import MemberDescriptorType
from contextlib import contextmanager
import base64
import json
from pathlib import Path
from datetime import datetime, timedelta, timezone
import csv
import io
from collections import deque
import time

def field_paths(value, path=()):
    """Every supplied key, container, and element is a separate mutation."""
    if isinstance(value, dict):
        for key, item in value.items():
            child = (*path, key)
            yield child
            yield from field_paths(item, child)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            child = (*path, index)
            yield child
            yield from field_paths(item, child)


def replace_field(body, path, value):
    changed = deepcopy(body)
    parent = changed
    for part in path[:-1]:
        parent = parent[part]
    parent[path[-1]] = value
    return changed


def resolve_helper(reference):
    import importlib

    module, _, name = reference.partition(":")
    value = importlib.import_module(module)
    for part in name.split("."):
        value = getattr(value, part)
    return value






_MISSING = object()
_EXCLUDED_MODULES = frozenset({
    "livemorebio.clinical_note_gate", "livemorebio.strict_json",
    "livemorebio.request_body", "livemorebio.security",
})


@dataclass(frozen=True)
class ReadSite:
    code: object
    offset: int
    receiver: ast.AST | None = None
    key: ast.AST | None = None
    local: str | None = None
    attribute: bool = False
    singleton_comparison: bool = False


def _resolve(expression, frame):
    """Read simple local expressions only; never eval or invoke caller code."""
    if isinstance(expression, ast.Name):
        return frame.f_locals.get(expression.id, _MISSING)
    if isinstance(expression, ast.Constant):
        return expression.value
    if isinstance(expression, ast.Subscript):
        return _lookup(_resolve(expression.value, frame), _resolve(expression.slice, frame))
    if isinstance(expression, ast.Attribute):
        return _attribute(_resolve(expression.value, frame), expression.attr)
    if (isinstance(expression, ast.Call) and isinstance(expression.func, ast.Attribute)
            and expression.func.attr == "get" and expression.args):
        return _lookup(_resolve(expression.func.value, frame), _resolve(expression.args[0], frame))
    return _MISSING


def _attribute(container, key):
    """Read declared dataclass storage without running properties or user code."""
    fields = inspect.getattr_static(type(container), '__dataclass_fields__', _MISSING)
    if type(fields) is not dict or key not in fields:
        return _MISSING
    value = inspect.getattr_static(container, key, _MISSING)
    if type(value) is MemberDescriptorType:
        try:
            return value.__get__(container, type(container))
        except AttributeError:
            return _MISSING
    return value


def _lookup(container, key):
    """Restrict inspection to inert built-in containers and Starlette's stored map."""
    if type(container) is dict:
        if type(key) not in (str, int, float, bool, type(None)):
            return _MISSING
        return dict.get(container, key, _MISSING)
    if type(container) in (list, tuple) and type(key) is int:
        return container[key] if -len(container) <= key < len(container) else _MISSING
    if type(container).__module__ == "starlette.datastructures":
        mapping = vars(container).get("_dict")
        if type(mapping) is dict and type(key) is str:
            return dict.get(mapping, key, _MISSING)
    return _MISSING


def _source_function(function):
    if inspect.ismethod(function):
        function = function.__func__
    return inspect.unwrap(function)


@lru_cache(maxsize=None)
def _function_sites(function, include_excluded_module=False):
    function = _source_function(function)
    if (not inspect.isfunction(function)
            or function.__module__ in _EXCLUDED_MODULES and not include_excluded_module
            or function.__name__ in {"screen_strings", "_canonical", "canonical", "_encoded"}):
        return frozenset()
    try:
        lines, start = inspect.getsourcelines(function)
        tree = ast.parse(textwrap.dedent("".join(lines)))
    except (OSError, TypeError, SyntaxError):
        return frozenset()
    columns = len(lines[0]) - len(lines[0].lstrip())
    spans = {}
    for node in ast.walk(tree):
        receiver = key = None
        attribute = singleton_comparison = False
        if isinstance(node, ast.Subscript) and isinstance(node.ctx, ast.Load):
            receiver, key = node.value, node.slice
        elif isinstance(node, ast.Attribute) and isinstance(node.ctx, ast.Load):
            receiver, key = node.value, ast.Constant(value=node.attr)
            attribute = True
        elif (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and node.func.attr in {"get", "pop", "setdefault", "getlist"} and node.args):
            receiver, key = node.func.value, node.args[0]
        elif (isinstance(node, ast.Compare) and len(node.ops) == 1
                and isinstance(node.ops[0], (ast.Eq, ast.NotEq))):
            for other, literal in ((node.left, node.comparators[0]),
                                   (node.comparators[0], node.left)):
                if (isinstance(other, ast.Name) and isinstance(literal, ast.Dict)
                        and len(literal.keys) == 1
                        and isinstance(literal.keys[0], ast.Constant)
                        and isinstance(literal.keys[0].value, str)):
                    receiver, key = other, literal.keys[0]
                    singleton_comparison = True
                    break
        if receiver is not None:
            span = (start + node.lineno - 1, start + node.end_lineno - 1,
                    node.col_offset + columns, node.end_col_offset + columns)
            spans[span] = (receiver, key, attribute, singleton_comparison)
    sites = set()
    pending = [function.__code__]
    while pending:
        code = pending.pop()
        pending.extend(value for value in code.co_consts if inspect.iscode(value))
        for instruction in dis.get_instructions(code):
            position = instruction.positions
            span = (position.lineno, position.end_lineno, position.col_offset, position.end_col_offset)
            if instruction.opname in {"CALL", "CALL_FUNCTION_EX", "BINARY_SUBSCR", "LOAD_ATTR", "COMPARE_OP"} and span in spans:
                receiver, key, attribute, singleton_comparison = spans[span]
                sites.add(ReadSite(code, instruction.offset, receiver, key,
                                   attribute=attribute, singleton_comparison=singleton_comparison))
            # A scalar loaded from a project parser's locals proves an individual
            # loop element was consumed; merely loading its parent list does not.
            if instruction.opname in {"LOAD_FAST", "LOAD_DEREF"}:
                sites.add(ReadSite(code, instruction.offset, local=instruction.argval))
    return frozenset(sites)


def read_sites(functions, field=None, *, include_excluded=()):
    """Return reads from the supplied request-handler/parser closure.

    ``field`` remains accepted for callers of the former suffix-key tracer.
    Admission now depends on the unique mutated scalar at runtime, so a sibling
    field with the same key cannot satisfy the receipt.
    """
    allowed = {_source_function(function) for function in include_excluded}
    return set().union(*(_function_sites(function, _source_function(function) in allowed)
                         for function in functions))


class BranchTrace:
    def __init__(self, sites=(), *, marker, guards=()):
        self.sites = set(sites)
        self.by_instruction = {(site.code, site.offset): site for site in self.sites}
        self.codes = {site.code for site in self.sites}
        self.guards = set(guards)
        self._marker_hash = hashlib.sha256(marker.encode("utf-8")).digest()
        self.reads = set()
        self.calls = set()
        self.returns = {}
        self.reached = False

    def trace(self, frame, event, argument):
        if event == "call":
            self.calls.add(frame.f_code)
            frame.f_trace_opcodes = frame.f_code in self.codes
            frame.f_trace_lines = False
            if frame.f_code not in self.codes and frame.f_code not in self.guards:
                return None
        elif event == "return" and frame.f_code in self.guards:
            if type(argument) is bool:
                self.returns.setdefault(frame.f_code, set()).add(argument)
        elif event == "opcode":
            site = self.by_instruction.get((frame.f_code, frame.f_lasti))
            if site is not None:
                if site.local is not None:
                    value = frame.f_locals.get(site.local, _MISSING)
                else:
                    receiver = _resolve(site.receiver, frame)
                    key = _resolve(site.key, frame)
                    if site.singleton_comparison and (type(receiver) is not dict or len(receiver) != 1):
                        value = _MISSING
                    elif site.attribute:
                        value = _attribute(receiver, key)
                    else:
                        value = _lookup(receiver, key)
                encoded = value.encode('utf-8') if type(value) is str else value
                if (type(encoded) in (bytes, bytearray)
                        and hashlib.sha256(encoded).digest() == self._marker_hash):
                    self.reached = True
                    self.reads.add((site.code, site.offset))
        return self.trace

    def __enter__(self):
        self.old_thread = threading.gettrace()
        self.old_current = sys.gettrace()
        threading.settrace(self.trace)
        sys.settrace(self.trace)
        return self

    def __exit__(self, *error):
        sys.settrace(self.old_current)
        threading.settrace(self.old_thread)



def cendos_baselines(monkeypatch):
    from livemorebio import bus
    from livemorebio.cendos import service, insulin_protocol, botanical_programs, metabolic_protocol, lobeline_vmat2, protocols, protocol_runs
    from livemorebio.cendos.current_source import make_source_envelope, source_guard
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY

    monkeypatch.setattr(bus, 'require_storage_key', lambda: None)
    monkeypatch.setattr(bus, 'set_snapshot', lambda *a, **k: None)
    monkeypatch.setattr(bus, 'publish', lambda *a, **k: {})
    protocol_ids = {'technical-insulin-parent': insulin_protocol.PROTOCOL_ID,
                    'technical-botanical-parent': botanical_programs.PROTOCOL_ID,
                    'technical-gem-parent': metabolic_protocol.PROTOCOL_ID,
                    'technical-lobeline-parent': lobeline_vmat2.PROTOCOL_ID}
    run_id = 'protocol-' + 'a' * 32
    run = {'run_id': run_id, 'protocol_id': 'cendos.garcinoic-acid-pxr.v1',
           'created_at': '2026-10-02T12:00:00+00:00', 'evidence_state': 'MODELED_ONLY',
           'qualification_state': 'UNASSESSED', 'cohort': {'cohort_id': 'technical-cohort', 'name': 'technical-fixture'},
           'target_engagement': [], 'input': {'cohort_id': 'technical-cohort', 'concentrations_um': [0.33]}}
    class MemoryProtocolStore(protocol_runs.ProtocolRunStore):
        def __init__(self):
            self.directory = Path('.l0-scratch/part13/never-persist-protocol-fixtures')

        def get(self, identity):
            if identity in protocol_ids:
                return {'protocol_id': protocol_ids[identity]}
            self._path(identity)
            if identity != run_id:
                raise protocol_runs.ProtocolRunNotFound('technical protocol run not found')
            return deepcopy(run)

        def save(self, result):
            return result

        def latest(self):
            return self.get(run_id)

        def _sync_index(self):
            pass

        @contextmanager
        def _index(self):
            class Connection:
                def execute(self, statement, parameters=()):
                    row = (run_id, run['created_at'], run['protocol_id'], 'technical-fixture',
                           run['evidence_state'], run['qualification_state'], None)
                    return SimpleNamespace(fetchone=lambda: (1,) if 'count(*)' in statement
                                           else (run['created_at'], run_id), fetchall=lambda: [row])
            yield Connection()

        def validate_rerun(self, *args, **kwargs):
            return {}

    store = MemoryProtocolStore()
    monkeypatch.setattr(service, '_protocol_store', lambda: store)
    from livemorebio.aegle import server
    monkeypatch.setattr(server, '_protocol_run_store', lambda: store)
    # All four callers validate first; numerical solvers are outside this HTTP field audit.
    for module, name in ((insulin_protocol, 'run_exogenous_insulin_protocol'),
                         (botanical_programs, 'run_botanical_exposure_program'),
                         (metabolic_protocol, 'run_human_gem_oxygen_capacity'),
                         (lobeline_vmat2, 'run_lobeline_vmat2')):
        monkeypatch.setattr(module, name, lambda spec, protocol=module.PROTOCOL_ID: {
            'technical_stub': True, 'protocol_id': protocol, 'input': deepcopy(spec)})

    source = make_source_envelope({
        'profile': HEALTHY.name, 'profile_params': asdict(HEALTHY),
        'pk_context': {'age': 50, 'genome': {}, 'evidence_class': 'REFERENCE_INITIALIZED'},
        'parameter_provenance': {}, 'subject': None,
        'model_availability': {'schema': 'livemore.model-availability.v1', 'state': 'READY',
                              'reason_code': None, 'selection_mode': 'reference_preview',
                              'twin_id': None, 'twin_version': 0, 'source_generation': 'a' * 32,
                              'preparation_available': True}})
    monkeypatch.setattr(service, '_read_current_source', lambda: deepcopy(source))
    patch_telemetry = {'admission': 'accepted', 'subject_id': 'pseudonym-technical', 'envelope_hash': 'b' * 64}
    monkeypatch.setattr(bus, 'snapshot', lambda key: deepcopy(patch_telemetry))

    # Fixed primitive fields for both computational assay routes. Keep input parsing real.
    monkeypatch.setattr(service, 'ogtt_effect', lambda *a, **k: {'decision': 'TECHNICAL',
                                                             'delta_mean': 0, 'delta_iAUC': 0})
    monkeypatch.setattr(protocols, 'ogtt_effect', lambda *a, **k: {
        'decision': 'TECHNICAL', 'delta_peak': 0, 'delta_mean': 0, 'delta_iAUC': 0,
        'baseline': {}, 'treated': {}, 'trajectory': {}})
    helpers = ('livemorebio.cendos.service:_json_object', 'livemorebio.cendos.service:_text',
               'livemorebio.cendos.service:_number', 'livemorebio.cendos.service:_string_tuple')
    protocol_helpers = helpers + ('livemorebio.cendos.service:_run_source_record_protocol',)
    cohort_helpers = helpers + ('livemorebio.cendos.protocols:_require_reference_cohort',
                                'livemorebio.reference_cohort_contract:ensure_cohort_executable',
                                'livemorebio.reference_cohort_contract:is_public_reference',
                                'livemorebio.cendos.protocol_runs:attach_run_inputs')
    technical_reference = {'source_class': 'SYNTHETIC', 'evidence_state': 'SYNTHETIC',
                           'schema': 'technical-fixture', 'generation_method': 'technical-fixture',
                           'source_id': 'technical-fixture'}

    def cohort(identity, stratum):
        pxr = stratum == 'pxr-reference'
        parameters = ({'NR1I2_expression_factor': 1.0} if pxr else
                      {key: getattr(HEALTHY, key) for key in ('weight_kg', 'Gb', 'Ib', 'SG', 'Si', 'gamma', 'Gt')})
        member = {**technical_reference, 'member_id': 'technical-member',
                  'executable': True, 'model_binding': {}, 'reference': dict(technical_reference),
                  'model_parameters': parameters}
        if not pxr:
            member.update(age=50, sex='F', genome={'SLC22A1_lof': 0}, source_lineage='technical-fixture')
        return {**technical_reference, 'source_class': 'REFERENCE_GROUNDED_SYNTHETIC',
                'cohort_id': identity, 'name': 'technical-fixture', 'stratum': stratum, 'version': 1,
                'reference_source': 'technical-fixture', 'executable': True, 'model_binding': {},
                'reference': dict(technical_reference),
                'members': [member]}
    stamp = '2026-10-02T12:00:00+00:00'
    history_cursor = base64.urlsafe_b64encode(json.dumps({
        'anchor': [stamp, run_id], 'after': [stamp, run_id], 'q': 'technical-fixture'}).encode()).decode().rstrip('=')
    return {
        '/protocols/history': [{'method': 'GET', 'query': {'limit': 1, 'cursor': history_cursor,
                                                         'q': 'technical-fixture'}, 'status': 200,
                                'helpers': ('livemorebio.cendos.protocol_runs:ProtocolRunStore.history',)}],
        '/protocols/latest': [{'method': 'GET', 'status': 200, 'helpers': ()}],
        '/protocols/{run_id}': [{'method': 'GET', 'path_params': {'run_id': run_id}, 'status': 200,
                               'helpers': ('livemorebio.cendos.protocol_runs:ProtocolRunStore._path',)}],
        '/protocols/{run_id}/prepare-rerun': [{'method': 'GET', 'path_params': {'run_id': run_id}, 'status': 200,
            'helpers': ('livemorebio.cendos.protocol_runs:ProtocolRunStore._path',
                        'livemorebio.cendos.protocol_runs:ProtocolRunStore.prepare_rerun')}],
        '/protocols/{run_id}/analysis.csv': [{'method': 'GET', 'path_params': {'run_id': run_id}, 'status': 200,
            'helpers': ('livemorebio.cendos.service:_protocol_export',
                        'livemorebio.cendos.protocol_runs:ProtocolRunStore._path')}],
        '/protocols/{run_id}/analysis.ipynb': [{'method': 'GET', 'path_params': {'run_id': run_id}, 'status': 200,
            'helpers': ('livemorebio.cendos.service:_protocol_export',
                        'livemorebio.cendos.protocol_runs:ProtocolRunStore._path')}],
        '/patch/latest': [{'method': 'GET', 'query': {'subject_id': patch_telemetry['subject_id'],
                                                    'envelope_hash': patch_telemetry['envelope_hash']},
                           'status': 200, 'helpers': ('livemorebio.life_patch.protocol:pseudonymous_subject_id',
                                                      'livemorebio.life_patch.protocol:envelope_snapshot_key')}],
        '/compound': [{'method': 'GET', 'query': {'name': 'metformin'}, 'status': 200,
                       'helpers': ('livemorebio.cendos.service:compound_lookup_url',
                                   'livemorebio.egress:check_request')}],
        '/protocols/metformin-cohorts': [{
            'body': {'cohort_a': cohort('technical-cohort-a', 'dpp-high-risk-metabolic'),
                     'cohort_b': cohort('technical-cohort-b', 'nhanes-diagnosed-diabetes-older'),
                     'dose_mg': 1000, 'grams': 75},
            'status': 201, 'helpers': cohort_helpers + ('livemorebio.cendos.protocols:run_metformin_cohort_comparison',
                                                        'livemorebio.cendos.protocols:_profile',
                                                        'livemorebio.engines.pharmacology:metformin',
                                                        'livemorebio.engines.hepatic_pk:pk_profile')}],
        '/protocols/garcinoic-pxr': [{
            'body': {'cohort': cohort('technical-cohort-pxr', 'pxr-reference'), 'concentrations_um': [0.05, 0.33]},
            'status': 201, 'helpers': cohort_helpers + ('livemorebio.cendos.protocols:run_garcinoic_acid_pxr',)}],
        '/evidence/lab-results': [{
            'body': {'result_id': 'technical-result-001', 'subject_id': 'pseudonym-technical-001',
                     'subject_pseudonymized': True, 'endpoint': 'glucose_mgdl', 'value': 100,
                     'unit': 'mg/dL', 'measured_at': stamp, 'received_at': stamp,
                     'instrument_id': 'technical-instrument', 'method': 'technical-fixture',
                     'quality_status': 'pass', 'calibration_status': 'pass',
                     'chain_of_custody': ['technical-accession'], 'consent_scope': ['technical-research'],
                     'sequence': 1},
            'status': 201, 'helpers': helpers + ('livemorebio.cendos.service:_iso_timestamp',)}],
        '/qualification/assess': [{
            'body': {'prediction_id': 'technical-prediction', 'measurement_id': 'technical-measurement',
                     'protocol_id': 'technical-protocol', 'subject_id': 'technical-subject',
                     'prediction_subject_id': 'technical-subject', 'endpoint': 'glucose_mgdl',
                     'prediction_endpoint': 'glucose_mgdl', 'predicted_value': 100, 'measured_value': 101,
                     'unit': 'mg/dL', 'prediction_unit': 'mg/dL', 'tolerance': 5,
                     'generated_at': stamp, 'measured_at': '2026-10-02T12:01:00+00:00',
                     'expected_window_seconds': 60, 'quality_status': 'pass', 'calibration_status': 'pass',
                     'population': 'technical-fixture', 'intervention': 'technical-fixture', 'dose': 'technical-fixture'},
            'status': 200, 'helpers': helpers + ('livemorebio.cendos.service:_iso_timestamp',)}],
        '/protocols/exogenous-insulin': [{
            'body': {'parent_run_id': 'technical-insulin-parent', 'new_configuration': True,
                     'product_id': 'rapid-acting-analogue-sc', 'cohort_size': 1, 'seed': 0,
                     'bolus_units': 4.0, 'bolus_time_min': 30.0, 'meal_g': 60.0, 'meal_time_min': 30.0,
                     'basal_u_per_kg_h': 0.006, 'hours': 1.0, 'label': 'technical-fixture'},
            'status': 201, 'helpers': protocol_helpers + ('livemorebio.cendos.insulin_protocol:validate_spec',
                                                         'livemorebio.cendos.insulin_protocol:_number')}],
        '/protocols/botanical-exposure': [{
            'body': {'parent_run_id': 'technical-botanical-parent', 'new_configuration': True,
                     'program_id': 'LBHR-030', 'dose_mg': 100, 'route': 'oral', 'cohort_size': 1,
                     'seed': 0, 'hours': 24, 'label': 'technical-fixture'},
            'status': 201, 'helpers': protocol_helpers + ('livemorebio.cendos.botanical_programs:validate_spec',
                                                         'livemorebio.cendos.botanical_programs:_number')}],
        '/protocols/human-gem-oxygen-capacity': [{
            'body': {'parent_run_id': 'technical-gem-parent', 'new_configuration': True,
                     'model_id': 'human-gem', 'conditions': [{'condition_id': 'technical-condition',
                                                           'glucose_uptake': 5, 'oxygen_uptake': 10}],
                     'knockout_gene_ids': ['ENSG00000141510']},
            'status': 201, 'helpers': helpers + ('livemorebio.engines.stoichiometry:validate_spec',
                                                'livemorebio.engines.stoichiometry:_bound')}],
        '/protocols/lobeline-vmat2': [{
            'body': {'parent_run_id': 'technical-lobeline-parent', 'new_configuration': True,
                     'material_id': lobeline_vmat2.MATERIAL_ID, 'context_id': lobeline_vmat2.CONTEXT_ID,
                     'concentration_unit': 'uM', 'substrate_concentrations': [0, 1],
                     'inhibitor_concentrations': [0, 0.25]},
            'status': 201, 'helpers': helpers + ('livemorebio.cendos.lobeline_vmat2:validate_spec',
                                                'livemorebio.cendos.lobeline_vmat2:_number')}],
        '/assay/ogtt': [{'body': {'base': 'healthy', 'drug': 'metformin', 'dose': 1.0, 'grams': 75.0},
                         'status': 200, 'helpers': helpers + ('livemorebio.cendos.service:_assay_inputs',)}],
        '/assay/current': [{'body': {'drug': 'metformin', 'dose': 1.0, 'grams': 75.0,
                                    'expected_source': source_guard(source)},
                            'status': 200, 'helpers': helpers + ('livemorebio.cendos.service:_assay_inputs',
                                          'livemorebio.cendos.current_source:validate_source_guard')}],
    }


def aegle_protocol_read_baselines(monkeypatch):
    """The same preserved technical protocol is served by Aegle's own readers."""
    return {'/api/cendos' + path: variants for path, variants in cendos_baselines(monkeypatch).items()
            if path.startswith('/protocols/') and all(item.get('method') == 'GET' for item in variants)}



def aegle_core_baselines(monkeypatch):
    from livemorebio.aegle import server, runtime, workspace, screen_runs
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio import bus, sdk
    from livemorebio.engines import trajectory, validation
    from livemorebio.anatomy import atlas_reference
    from livemorebio.cendos import service as cendos
    protocol_specs = cendos_baselines(monkeypatch)

    # This suite exercises request field consumption, not numerical accuracy.
    # A technical in-memory twin supplies already initialized solver outputs;
    # input admission and stimulus dispatch remain the actual implementations.
    monkeypatch.setattr(runtime.AegleTwin, '_recompute', lambda self: None)
    monkeypatch.setattr(runtime.AegleTwin, '_comparison_snapshot', lambda self: {})
    monkeypatch.setattr(runtime.AegleTwin, 'state', lambda self: {'technical_fixture': True})
    monkeypatch.setattr(runtime, 'CardiacCell', lambda: SimpleNamespace())
    twin = runtime.AegleTwin('healthy')
    twin.metabolic = {'t_min': [0., 1.], 'glucose': [100., 100.]}
    twin.cardiac_unavailable = None
    monkeypatch.setattr(workspace, 'projection', lambda *a, **k: {'technical_fixture': True})
    monkeypatch.setattr(bus, 'require_storage_key', lambda: None)
    monkeypatch.setattr(bus, 'publish', lambda *a, **k: {})
    monkeypatch.setattr(bus, 'set_snapshot', lambda *a, **k: None)
    monkeypatch.setattr(trajectory, 'simulate_disease_trajectory', lambda *a, **k: {'technical_fixture': True})
    monkeypatch.setattr(validation, 'dpp_validation', lambda *a, **k: {'technical_fixture': True})
    monkeypatch.setattr(atlas_reference, 'install', lambda *a, **k: {'technical_fixture': True})
    monkeypatch.setattr(screen_runs, 'save', lambda result, request: result)
    def platform_state(self, mode):
        self.mode, self._cohort = mode, []
        self._cohort_context, self._cohort_seed, self._cohort_n = None, None, None
    monkeypatch.setattr(sdk.Platform, '__init__', platform_state)
    monkeypatch.setattr(sdk.Platform, 'cohort', lambda *a, **k: None)
    monkeypatch.setattr(sdk.Platform, '_audit_result', lambda *a, **k: {})

    def reset():
        monkeypatch.setattr(server, '_state', {'tw': deepcopy(twin), 'subject': None, 'initialized': True})
        authority = ModelSourceAuthority()
        with authority.commit_guard():
            authority.install_generation('a' * 32)
        monkeypatch.setattr(server, '_model_source_authority', authority)
    reset()
    helpers = ('livemorebio.aegle.runtime:AegleTwin.stimulate',)
    actions = [
        {'kind': 'meal', 'params': {'minute': 0, 'grams': 60}},
        {'kind': 'metabolic_drug', 'params': {'name': 'metformin', 'dose': 1}},
        {'kind': 'food', 'params': {'name': 'moringa', 'grams': 50}},
        {'kind': 'factor', 'params': {'name': 'chronic stress', 'intensity': 1}},
        {'kind': 'cardiac_drug', 'params': {'ikr_block': 0.1}},
        {'kind': 'lifestyle', 'params': {'si_delta': 0.1, 'gb_delta': 0.1}},
        {'kind': 'reset', 'params': {}},
    ]
    result = {
        '/api/stimulate': [{'body': body, 'status': 200, 'helpers': helpers, 'setup': reset}
                           for body in actions],
        '/api/workspace/actions': [{'body': body, 'status': 200, 'setup': reset,
                                  'helpers': helpers + ('livemorebio.aegle.workspace:validate_action_input',
                                                        'livemorebio.aegle.workspace:_finite_parameter')}
                                  for body in actions if body['kind'] not in {'food', 'factor'}],
        '/api/trajectory': [{'body': {'foods': ['moringa'], 'drugs': ['metformin'],
                                     'factors': ['chronic stress'], 'sex': 'F', 'genome': {'TCF7L2': 1},
                                     'age': 50, 'kcal_intake': 2200, 'activity': .5, 'stress': .1, 'years': 1},
                             'status': 200, 'setup': reset,
                             'helpers': ('livemorebio.aegle.server:_admit_trajectory_exposures',
                                         'livemorebio.life_system.structured_human:admit_structured_human')}],
        '/api/validate': [{'body': {'n': 1, 'years': 1, 'seed': 0}, 'status': 200}],
        '/api/ingest_note': [{'body': {'text': ''}, 'status': 422, 'code': 'CLINICAL_NOTE_NOT_ACCEPTED',
                             'gate': 'livemorebio.clinical_note_gate:clinical_note_gate'}],
        '/api/experiment': [{'body': {}, 'status': 422, 'code': 'UNSUPPORTED_BIOLOGICAL_INTERVENTION'}],
        '/api/evidence': [{'body': {}, 'status': 409, 'code': 'LEGACY_EVIDENCE_INTAKE_DISABLED'}],
        '/api/anatomy/atlas-reference/install': [{'body': {'source_id': atlas_reference.SOURCE_ID}, 'status': 200}],
        '/api/adapters/probe': [{'body': None, 'status': 200}],
        '/api/screen': [{'body': {'compound': 'metformin', 'n': 1, 'seed': 0, 'dose': 1, 'grams': 75,
                                 'mode': 'auto', 'indication': 'type-2-diabetes',
                                 'cohort': 't2d-enriched', 'assay': 'ogtt'}, 'status': 200},
                        {'body': {'compound': 'metformin', 'n': 1, 'seed': 0, 'dose': 1, 'grams': 75,
                                 'mode': 'parametric', 'indication': 'type-2-diabetes',
                                 'cohort': 't2d-enriched', 'assay': 'ogtt',
                                 'si_boost': .1, 'gb_drop': .1, 'gamma_boost': .1}, 'status': 422,
                         'error': 'No qualified generic compound screen is available; use a registered compound-specific Cendos protocol',
                         'helpers': ('livemorebio.sdk:Platform.screen',)}],
    }
    # Publication is a storage boundary; still execute the actual candidate
    # factory so its structured-human fields are consumed.
    monkeypatch.setattr(server, '_publish_research_preview',
                        lambda factory, *a, **k: (factory(), {'technical_fixture': True})[1])
    result['/api/stimulate'] += [
        {'body': {'kind': 'base', 'params': {'base': 'healthy'}}, 'status': 200},
        {'body': {'kind': 'life_system', 'params': {'mode': 'custom', 'id': 'LMB-17', 'age': 50,
                                                  'sex': 'F', 'conditions': ['Type 2 diabetes mellitus'],
                                                  'genome': {'TCF7L2': 1}, 'lifestyle': .5}},
         'status': 200, 'helpers': ('livemorebio.life_system.structured_human:admit_structured_human',)},
    ]
    monkeypatch.setattr(runtime.AegleTwin, 'ingest_patch', lambda *a: {'technical_fixture': True})
    for mode in ('synthetic', 'cgm_diabetic', 'cgm_healthy'):
        result['/api/stimulate'].append({'body': {'kind': 'patch', 'params': {'mode': mode}},
            'status': 200, 'setup': reset, 'helpers': ('livemorebio.aegle.server:_apply_stimulus',)})
    for mode in ('random', 't2d_apoe4', 'carrier'):
        result['/api/stimulate'].append({'body': {'kind': 'life_system', 'params': {'mode': mode}}, 'status': 200})
    store = SimpleNamespace(save=lambda value: value, validate_rerun=lambda *a, **k: {})
    monkeypatch.setattr(server, '_protocol_run_store', lambda: store)
    for name in ('exogenous-insulin', 'botanical-exposure', 'human-gem-oxygen-capacity', 'lobeline-vmat2'):
        result['/api/cendos/protocols/' + name] = [dict(spec) for spec in protocol_specs['/protocols/' + name]]
    metformin = protocol_specs['/protocols/metformin-cohorts'][0]['body']
    pxr = protocol_specs['/protocols/garcinoic-pxr'][0]['body']
    cohorts = {'technical-a': metformin['cohort_a'], 'technical-b': metformin['cohort_b'], 'technical-pxr': pxr['cohort']}
    monkeypatch.setattr(server, '_subject_registry', lambda: SimpleNamespace(get_cohort=lambda identity: deepcopy(cohorts[identity])))
    result['/api/cendos/protocols/metformin-cohorts'] = [{'body': {
        'cohort_a_id': 'technical-a', 'cohort_b_id': 'technical-b', 'dose_mg': 1000, 'grams': 75,
        'parent_run_id': 'technical-parent', 'new_configuration': True}, 'status': 201,
        'helpers': ('livemorebio.aegle.server:_rerun_parent',)}]
    result['/api/cendos/protocols/garcinoic-pxr'] = [{'body': {
        'cohort_id': 'technical-pxr', 'concentrations_um': [.05, .33],
        'parent_run_id': 'technical-parent', 'new_configuration': True}, 'status': 201,
        'helpers': ('livemorebio.aegle.server:_rerun_parent',)}]
    from fastapi.testclient import TestClient
    cendos_client = TestClient(cendos.app, raise_server_exceptions=False,
        headers={'Authorization': 'Bearer technical-note-gate-token'})
    monkeypatch.setattr(server, '_capture_cendos_source', lambda *a: cendos._read_current_source())
    monkeypatch.setattr(server, '_forward_cendos_assay',
                        lambda body: cendos_client.post('/assay/current', json=body).json())
    result['/api/cendos/assay'] = [{'body': {'drug': 'metformin', 'dose': 1, 'grams': 75},
        'status': 200, 'setup': reset, 'helpers': ('livemorebio.cendos.service:_assay_inputs',)}]
    from livemorebio.aegle import evidence_api
    def needs_review(*args):
        raise ValueError('technical fixture has no independent review')
    monkeypatch.setattr(evidence_api, 'export_zip', needs_review)
    result['/api/evidence/{package_id}/export'] = [{'body': None, 'path_params': {'package_id': 'technical-package'},
        'status': 409, 'code': 'EVIDENCE_REVIEW_REQUIRED'}]
    return result



def _memory_virtual_setup(tmp_path, monkeypatch):
    """Real session validation over a Python store-driver and source stub."""
    from livemorebio.aegle.execution_contract import ExecutionError, seal_source
    from livemorebio.life_patch.execution_source import numerical_probe_manifest
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.virtual_execution import VirtualSessionManager
    from livemorebio.life_patch.virtual_session_store import VirtualSessionStore
    from livemorebio.tests.test_continuous_execution import captured_source
    from livemorebio.tests.test_virtual_execution import Source

    class MemorySessionStore(VirtualSessionStore):
        def __init__(self):
            self.key = b'v' * 32
            self.quota_bytes = 256 * 1024 * 1024
            self.rows = {}
            self.owners = set()

        @contextmanager
        def _connection(self):
            rows = self.rows
            class Connection:
                def execute(self, statement, values=()):
                    result = None
                    if statement.startswith('SELECT id FROM'):
                        result = next(((identity,) for identity, row in rows.items() if row[0] == values[0]), None)
                    elif statement.startswith('SELECT 1 FROM'):
                        result = next(((1,) for row in rows.values() if row[2] == values[0]), None)
                    elif statement.startswith('SELECT revision,active_device_key,payload'):
                        row = rows.get(values[0])
                        result = None if row is None else tuple(row[1:])
                    elif statement.startswith('SELECT length(payload)'):
                        row = rows.get(values[0])
                        result = None if row is None else (len(row[3]),)
                    elif statement.startswith('INSERT INTO virtual_sessions'):
                        rows[values[0]] = list(values[1:])
                    elif statement.startswith('UPDATE virtual_sessions'):
                        revision, active, payload, identity = values
                        rows[identity][1:] = [revision, active, payload]
                    elif statement not in {'BEGIN IMMEDIATE', 'COMMIT'}:
                        raise AssertionError('unexpected technical store operation')
                    return SimpleNamespace(fetchone=lambda: result)
            yield Connection()

        def _encrypt(self, record, aad):
            return json.dumps(record, sort_keys=True).encode()

        def _decrypt(self, payload, aad):
            return json.loads(payload)

        def _totals(self, connection):
            return sum(len(row[3]) for row in self.rows.values()), len(self.rows), {'pending': 0}

        def acquire_owner(self, identity):
            if identity in self.owners:
                raise ExecutionError('EXECUTION_OWNED')
            self.owners.add(identity)
            return identity

        def release_owner(self, identity):
            self.owners.discard(identity)

        def begin_access(self, *args, **kwargs):
            return 'technical-l0-field-request'

        def finish_access(self, *args, **kwargs):
            pass

    captured = captured_source()
    captured['selection']['subject_id'] = 'pseudonym-virtual-fixture'
    captured = seal_source(captured)
    state = {key: deepcopy(captured[key]) for key in (
        'source_snapshot_hash', 'source_generation', 'selection', 'engine_contract_id', 'native_axis')}
    state.update(execution_id='e' * 32, revision=1, control_revision=1, source_valid=True,
                 latest_frame=0, state='prepared', authorship='technical_fixture')
    source = Source(state)
    monkeypatch.setenv('LIVEMORE_PATCH_STORAGE_KEY', base64.urlsafe_b64encode(b'v' * 32).decode())
    gateway = LifePatchGateway(str(tmp_path / 'gateway' / 'wire.jsonl'))
    manifest = numerical_probe_manifest('virtual-engine-fixture')
    gateway.register(manifest)
    owner = VirtualSessionManager(MemorySessionStore(), gateway, source,
        lambda receipt: {'aegle': {'status': 'delivered'}}, run_background=False,
        clock=lambda: 100., now=lambda: datetime.now(timezone.utc))
    record = owner.start(state['execution_id'], state['source_snapshot_hash'], manifest.device_id,
                         expected_selection=state['selection'], idempotency_key='virtual-one')
    return owner, source, record


def admitted_patch_fixture(tmp_path, subject_id="pseudonym-technical-field", device_id="technical-field-device"):
    """A real local gateway admission, with its genuine fixture-key signature."""
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import DeviceMode, VirtualLifePatch, manifest_for
    from livemorebio.security import sign_patch_admission

    gateway = LifePatchGateway(str(tmp_path / "admitted-wire.jsonl"))
    manifest = manifest_for(device_id, DeviceMode.VIRTUAL)
    gateway.register(manifest)
    envelope = VirtualLifePatch(manifest).emit(subject_id, {"glucose_mgdl": 100., "hr_bpm": 70.})
    now = datetime.now(timezone.utc)
    admitted = gateway.admit(envelope, received_at=now)
    admission = {"admission": "accepted", "admitted_at": admitted["admitted_at"],
        "device_id": device_id, "mode": "virtual", "envelope_hash": envelope.envelope_hash,
        "capability_hash": manifest.capability_hash, "received_at": now.isoformat().replace("+00:00", "Z")}
    return {"envelope": envelope.to_dict(), "admission": admission,
            "admission_signature": sign_patch_admission(admission)}, manifest.to_dict()


def life_baselines(monkeypatch, tmp_path):
    from livemorebio import bus
    from livemorebio.life_system import service, virtual_execution_api as api
    from livemorebio.life_patch.gateway import LifePatchGateway
    from livemorebio.life_patch.protocol import DeviceMode, VirtualLifePatch, manifest_for

    owner, source, record = _memory_virtual_setup(tmp_path / "virtual", monkeypatch)
    monkeypatch.setattr(api, "_manager", lambda: owner)
    monkeypatch.setattr(api, "_check_runtime_identity", lambda: None)
    gateway = LifePatchGateway(str(tmp_path / "ordinary" / "wire.jsonl"))
    manifest = manifest_for("technical-field-device", DeviceMode.VIRTUAL)
    gateway.register(manifest)
    monkeypatch.setattr(service, "_patch_gateway", lambda: gateway)
    monkeypatch.setattr(service, "_c", {})
    # Only the remote delivery boundary is replaced; all packet/domain validation
    # and encrypted local gateway admission stay real.
    monkeypatch.setattr(service, "_forward_to_aegle", lambda _: {"status": "delivered"})
    monkeypatch.setattr(bus, "BUS_DIR", str(tmp_path / "bus"))
    monkeypatch.setattr(bus, "EVENTS", str(tmp_path / "bus" / "events.jsonl"))
    monkeypatch.setattr(bus, "SNAP_DIR", str(tmp_path / "bus" / "snapshots"))
    envelope = VirtualLifePatch(manifest).emit(
        "pseudonym-technical-field", {"glucose_mgdl": 100.0, "hr_bpm": 70.0}).to_dict()
    # The GET journal baseline must contain an admitted row, so its subject
    # filter reaches a real comparison rather than an empty-store shortcut.
    read_manifest = manifest_for("technical-field-read-device", DeviceMode.VIRTUAL)
    gateway.register(read_manifest)
    read_envelope = VirtualLifePatch(read_manifest).emit(
        "pseudonym-technical-read", {"glucose_mgdl": 100.0})
    gateway.admit(read_envelope, received_at=datetime.now(timezone.utc))
    issued = gateway.issue_command(device_id=manifest.device_id, command="request_quality_check",
                                   parameters={}, command_id="technical-field-receipt")
    paused = owner.pause(record["session_id"], expected_revision=record["revision"])
    specs = []

    def add(name, path, body, status, *helpers, **extra):
        specs.append({"name": name, "path": path, "body": body,
                      "status": status, "helpers": helpers, **extra})

    add("population-read", "/population", None, 200,
        "livemorebio.life_system.population:LifeSystem.generate",
        method="GET", query={"n": 1, "seed": 0})
    add("substrate-search", "/search", None, 200,
        "livemorebio.life_system.retrieval:SubstrateIndex.query_with_status",
        "livemorebio.life_system.retrieval:SubstrateIndex.query",
        "livemorebio.life_system.retrieval:_toks",
        method="GET", query={"q": "glucose", "kind": "Gene"})
    add("gene-reference-read", "/reference/genes/{symbol}", None, 200,
        "livemorebio.life_system.reference.sources.kegg:KEGG.gene",
        "livemorebio.life_system.reference.sources.genecards:GeneCards.gene",
        method="GET", path_params={"symbol": "TCF7L2"})
    add("patch-device-read", "/patch/devices/{device_id}", None, 200,
        "livemorebio.life_patch.gateway:LifePatchGateway.manifest",
        method="GET", path_params={"device_id": manifest.device_id})
    add("patch-telemetry-read", "/patch/telemetry", None, 200,
        "livemorebio.life_patch.gateway:LifePatchGateway.telemetry",
        method="GET", query={"subject_id": "pseudonym-technical-read", "limit": 1})
    add("patch-command-read", "/patch/commands", None, 200,
        "livemorebio.life_patch.gateway:LifePatchGateway.commands",
        method="GET", query={"device_id": manifest.device_id, "limit": 1})
    add("virtual-session-read", "/patch/virtual/sessions/{session_id}", None, 200,
        "livemorebio.life_system.virtual_execution_api:_operate",
        "livemorebio.life_patch.virtual_execution:VirtualSessionManager.status",
        method="GET", path_params={"session_id": paused["session_id"]})

    from livemorebio.life_system.structured_human import _vocabulary
    add("human-structured", "/human", {
        "id": "LMB-47", "age": 47, "sex": "M", "conditions": ["type 2 diabetes"],
        "genome": {sorted(_vocabulary()[1])[0]: 1}, "lifestyle": 0.55,
    }, 200, "livemorebio.life_system.structured_human:admit_structured_human")
    add("human-note", "/human", {"note": "technical fixture"}, 422,
        "livemorebio.clinical_note_gate:clinical_note_gate", code="CLINICAL_NOTE_NOT_ACCEPTED")
    add("patch-device-v2", "/patch/devices", manifest.to_dict(), 201,
        "livemorebio.life_patch.protocol:decode_manifest", "livemorebio.life_patch.protocol:DeviceManifest.from_dict",
        "livemorebio.life_patch.protocol:DeviceManifest.__post_init__")
    add("patch-telemetry-direct-v2", "/patch/telemetry", deepcopy(envelope), 202,
        "livemorebio.life_patch.protocol:decode_envelope", "livemorebio.life_patch.protocol:TelemetryEnvelope.from_dict",
        "livemorebio.life_patch.protocol:TelemetryMeasurement.from_dict",
        "livemorebio.life_patch.protocol:TelemetryMeasurement.__post_init__",
        "livemorebio.life_patch.protocol:TelemetryEnvelope.__post_init__")
    add("patch-telemetry-wrapped-v2", "/patch/telemetry", {
        "envelope": deepcopy(envelope), "consent_scope": ["technical"], "chain_of_custody": ["technical"],
    }, 202, "livemorebio.life_system.service:_bounded_string_array",
        "livemorebio.life_patch.protocol:decode_envelope", "livemorebio.life_patch.protocol:TelemetryEnvelope.from_dict",
        "livemorebio.life_patch.protocol:TelemetryMeasurement.from_dict",
        "livemorebio.life_patch.protocol:TelemetryMeasurement.__post_init__",
        "livemorebio.life_patch.protocol:TelemetryEnvelope.__post_init__")
    add("patch-virtual-envelope-v2", "/patch/virtual/sample", {"envelope": deepcopy(envelope)}, 202,
        "livemorebio.life_patch.protocol:decode_envelope", "livemorebio.life_patch.protocol:TelemetryEnvelope.from_dict",
        "livemorebio.life_patch.protocol:TelemetryMeasurement.from_dict",
        "livemorebio.life_patch.protocol:TelemetryMeasurement.__post_init__",
        "livemorebio.life_patch.protocol:TelemetryEnvelope.__post_init__")
    add("patch-virtual-generated-v2", "/patch/virtual/sample", {
        "device_id": "technical-field-generated", "subject_id": "pseudonym-technical-field",
        "protocol_version": "2.0", "readings": {"glucose_mgdl": 100.0, "hr_bpm": 70.0},
    }, 202, "livemorebio.life_patch.protocol:VirtualLifePatch.emit")
    from livemorebio.tests.test_patch_protocol_v3 import manifest_payload, envelope_payload
    from livemorebio.life_patch.protocol import decode_manifest, decode_envelope
    # Separate fixtures exercise every v3 measurement branch and optional model
    # context. Hashes are genuine, and each fixture is registered locally.
    for kind in ("scalar", "modeled", "waveform"):
        raw_manifest = manifest_payload()
        raw = envelope_payload()
        device_id = "technical-field-v3-" + kind
        raw_manifest["device_id"] = raw["device_id"] = device_id
        raw["envelope_id"] = "technical-v3-envelope-" + kind
        stamp = datetime.now(timezone.utc) - timedelta(seconds=1)
        raw.update(captured_at=stamp.isoformat(), acquisition_start=stamp.isoformat(),
                   acquisition_end=stamp.isoformat())
        measurement = raw["measurements"][0]
        measurement["quality_status"] = "degraded"
        measurement["quality_flags"] = ["technical-fixture"]
        if kind == "modeled":
            raw_manifest["capabilities"][0]["provenance"] = measurement["provenance"] = "modeled"
            measurement["model_context"] = {"prediction_id": "technical-prediction", "condition_id": "control",
                "model_time_min": 2., "model_id": "technical-model", "mapping_id": "technical-mapping"}
        elif kind == "waveform":
            capability = raw_manifest["capabilities"][0]
            capability.update(signal="ppg_au", unit="AU", channel="ppg")
            measurement.update(signal="ppg_au", unit="AU", kind="waveform", samples=[1., 2., 1.], sample_period_s=.5)
            measurement.pop("value")
            measurement["context"]["endpoint"] = "ppg_au"
            raw["acquisition_start"] = (stamp - timedelta(seconds=1)).isoformat()
            raw["clock"]["monotonic_start_s"] = 11.
        v3_manifest = decode_manifest(raw_manifest)
        gateway.register(v3_manifest)
        raw["manifest_hash"] = v3_manifest.capability_hash
        v3_envelope = decode_envelope(raw).to_dict()
        add("patch-device-v3-" + kind, "/patch/devices", v3_manifest.to_dict(), 201,
            "livemorebio.life_patch.protocol_v3:ManifestV3.__init__")
        add("patch-telemetry-v3-" + kind, "/patch/telemetry", {
            "envelope": v3_envelope, "consent_scope": ["technical"], "chain_of_custody": ["technical"],
        }, 202, "livemorebio.life_patch.protocol_v3:TelemetryEnvelopeV3.__init__",
            "livemorebio.life_patch.protocol_v3:_measurement")
        add("patch-virtual-v3-" + kind, "/patch/virtual/sample", {"envelope": v3_envelope}, 202,
            "livemorebio.life_patch.protocol_v3:TelemetryEnvelopeV3.__init__",
            "livemorebio.life_patch.protocol_v3:_measurement")
    for command, parameters in [
        ("request_quality_check", {}), ("request_calibration_check", {}), ("stop_chemistry_session", {}),
        ("set_sampling_profile", {"profile": "balanced"}),
        ("request_burst", {"duration_seconds": 10, "channels": ["ecg"]}),
        ("start_chemistry_session", {"duration_seconds": 30, "analytes": ["glucose_mgdl"]}),
    ]:
        add("patch-command-" + command, "/patch/commands", {
            "device_id": manifest.device_id, "command": command, "parameters": parameters,
            "expires_in_seconds": 300, "command_id": "technical-field-command",
        }, 201, "livemorebio.life_patch.gateway:LifePatchGateway.issue_command",
            "livemorebio.life_patch.protocol:PatchCommand.__post_init__",
            "livemorebio.life_patch.protocol:_validate_command_parameters")
    add("patch-receipt", "/patch/commands/receipts", {
        "command_id": issued.command_id, "device_id": manifest.device_id, "status": "completed",
        "received_at": datetime.now(timezone.utc).isoformat(), "detail": "technical-ok",
    }, 201, "livemorebio.life_patch.protocol:CommandReceipt.__post_init__")
    add("virtual-probe", "/patch/virtual/probe", {"device_id": "technical-field-probe"}, 200,
        "livemorebio.life_patch.execution_source:numerical_probe_manifest")
    add("virtual-session", "/patch/virtual/sessions", {
        "execution_id": source.current["execution_id"], "source_snapshot_hash": source.current["source_snapshot_hash"],
        "device_id": "virtual-engine-fixture", "expected_selection": deepcopy(source.current["selection"]),
        "idempotency_key": "virtual-one",
    }, 200, "livemorebio.life_patch.virtual_execution:VirtualSessionManager.start",
        "livemorebio.aegle.execution_contract:validate_selection")
    for action in ("pause", "resume", "stop"):
        for revision in ("expected_revision", "expected_control_revision"):
            value = paused["revision" if revision == "expected_revision" else "control_revision"]
            add("virtual-" + action + "-" + revision,
                "/patch/virtual/sessions/" + paused["session_id"] + "/" + action,
                {revision: value}, 200, "livemorebio.aegle.execution_api:_control_guard")
    return specs, owner.close



def aegle_registry_baselines(monkeypatch):
    from contextlib import contextmanager
    from dataclasses import asdict
    import builtins
    import io
    import json
    from livemorebio import bus
    from livemorebio.aegle import server, subjects
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.clinical_parameters import MODEL_PARAMETER_NAMES
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY

    registry = object.__new__(subjects.SubjectRegistry)
    registry._idempotent = lambda *a, **k: None
    registry._real_idempotent = lambda *a, **k: None
    registry._insert_or_existing = lambda kind, record, *a: record
    registry.commit_prepared_transition = lambda prepared: "COMMITTED"
    registry.build_twin = lambda record: SimpleNamespace(state=lambda: {"profile_params": {}})
    monkeypatch.setattr(server, "_subject_registry", lambda: registry)
    monkeypatch.setattr(server, "_snapshot_twin", lambda *a: None)
    monkeypatch.setattr(server, "_invalidate_model_source", lambda *a: None)
    monkeypatch.setattr(bus, "require_storage_key", lambda: None)
    monkeypatch.setattr(server, "_require_matching_selected_record", lambda *a: None)

    twin_body = {
        "source_class": "SYNTHETIC", "subject_id": "pseudonym-SYNTHETIC-field-sweep",
        "display_label": "SYNTHETIC technical field sweep", "consent_scope": ["digital_twin", "cendos_validation"],
        "chain_of_custody": "SYNTHETIC technical fixture", "demographics": {"age": 40, "sex": "F"},
        "conditions": ["type 2 diabetes"], "genome": {"SLC22A1_lof": 0},
        "lifestyle": {"activity_index": 0.5}, "medications": [{"name": "metformin", "status": "technical"}],
        "environment": {"region_code": "SYNTHETIC-technical-region"},
        "profile_sources": [{"source_id": "SYNTHETIC-technical-source", "kind": "FHIR_R4",
            "system": "SYNTHETIC technical fixture", "release": "technical-fixture",
            "captured_at": "2026-10-02T12:00:00Z", "provenance_uri": "urn:test:SYNTHETIC",
            "quality_status": "verified", "domains": ["demographics", "conditions", "labs", "physiology"]}],
        "observations": {"glucose_mgdl": {"value": 100, "unit": "mg/dL",
            "captured_at": "2026-10-02T12:00:00Z", "source": "SYNTHETIC-technical-source",
            "quality_status": "verified", "sampling_context": "fasting"}}, "model_parameters": {},
    }
    twin_body["model_parameters"] = {name: value for name, value in asdict(HEALTHY).items()
                                     if name in MODEL_PARAMETER_NAMES}
    twin_body["model_parameters"]["Gb"] = 100
    record = registry.create_twin(deepcopy(twin_body))
    record["twin_id"] = "twin-technical-field-sweep"
    record["patch_bindings"] = [{"device_id": "technical-device", "mode": "virtual", "protocol_version": "2.0"}]
    registry.get_twin = lambda *a: deepcopy(record)
    registry.active_twin = lambda: deepcopy(record)
    registry.prepare_activation = lambda *a, **k: SimpleNamespace(record=deepcopy(record), active_before=None)
    observed = deepcopy(record)
    observed["source_class"] = "REAL_HUMAN"
    registry.prepare_observation_selection = lambda *a, **k: SimpleNamespace(record=deepcopy(observed), active_before=None)
    registry.prepare_patch_binding = lambda *a, **k: SimpleNamespace(record=deepcopy(record), active_before=None, selected=False)

    def reset():
        monkeypatch.setattr(server, "_model_source_authority", ModelSourceAuthority())
        monkeypatch.setattr(server, "_state", {"tw": SimpleNamespace(state=lambda: {"profile_params": {}}),
            "subject": None, "initialized": True, "observation_state": server.ObservationState()})
        monkeypatch.setattr(server, "_workspace_actions", [])

    def reset_uncertain():
        reset()
        authority = server._model_source_authority
        with authority.commit_guard():
            authority.install_generation(DENY_ALL)
    registry.audited_active_twin = lambda **kw: SimpleNamespace(record=deepcopy(observed))
    registry.confirm_active_selection = lambda *a, **k: None

    helpers = ("livemorebio.aegle.server:_selection_payload",)
    source_helpers = tuple("livemorebio.aegle.subjects:" + name for name in
        ("SubjectRegistry.create_twin", "_bounded_string", "_bounded_list", "_finite", "_validate_observations"))
    source_helpers += tuple("livemorebio.aegle.profile_sources:" + name for name in
        ("normalize_profile_sources", "validate_environment", "validate_medications"))
    result = {
        "/api/twins": [{"body": twin_body, "status": 201, "helpers": source_helpers, "setup": reset}],
        "/api/twins/{twin_id}/activate": [{"body": {"expected_version": 1}, "status": 200,
            "path_params": {"twin_id": record["twin_id"]}, "helpers": helpers, "setup": reset}],
        "/api/twins/{twin_id}/select-observations": [{"body": {"expected_version": 1}, "status": 200,
            "path_params": {"twin_id": record["twin_id"]}, "helpers": helpers, "setup": reset}],
        "/api/twins/reconcile-selection": [{"body": {}, "status": 200, "helpers": helpers, "setup": reset_uncertain}],
        "/api/twins/{twin_id}/patches": [{"body": {"expected_version": 1, "device_id": "technical-device",
            "mode": "virtual", "protocol_version": "2.0", "hardware_revision": "B0-EVT-target",
            "firmware_version": "technical-fixture", "calibration_status": "not_applicable",
            "attestation_reference": "SYNTHETIC technical fixture"}, "status": 200,
            "path_params": {"twin_id": record["twin_id"]}, "setup": reset,
            "helpers": helpers + ("livemorebio.aegle.subjects:_normalize_transition_binding",)}],
        "/api/cohorts": [{"body": {"source_class": "SYNTHETIC", "name": "SYNTHETIC technical cohort",
            "size": 1, "seed": 0, "indication": "technical-fixture", "member_twin_ids": []},
            "status": 201, "helpers": ("livemorebio.aegle.subjects:SubjectRegistry.create_cohort",), "setup": reset}],
    }
    from livemorebio.aegle.population import SUPPORTED_REFERENCE_SOURCES
    source_id = "livemore-public-metabolic-reference-v1"
    reference = {"source_id": source_id, "role": "population_reference",
        **{field: SUPPORTED_REFERENCE_SOURCES[source_id][field] for field in ("release", "provenance_uri", "population")}}
    for path in ("/api/twins", "/api/cohorts"):
        branch = deepcopy(result[path][0])
        branch["body"].update(source_class="REFERENCE_GROUNDED_SYNTHETIC", reference_source=reference,
                              stratum="dpp-high-risk-metabolic", seed=0)
        if path == "/api/twins":
            for name in ("demographics", "conditions", "genome", "lifestyle", "medications", "environment", "observations", "model_parameters"):
                branch["body"].pop(name, None)
        branch["helpers"] += ("livemorebio.aegle.population:normalize_reference_source",)
        result[path].append(branch)
    real = deepcopy(result["/api/twins"][0])
    real["body"]["source_class"] = "REAL_HUMAN"  # Schema branch only; every datum is an authored SYNTHETIC fixture.
    real_record = registry.create_twin(deepcopy(real["body"]))
    real_record["twin_id"] = "twin-technical-real-schema"
    result["/api/twins"].append(real)

    @contextmanager
    def audited(*args, **kwargs):
        yield SimpleNamespace(execute=lambda *a, **k: SimpleNamespace(fetchone=lambda: {
            "version": real_record["version"], "source_class": "REAL_HUMAN"}))
    registry._audited = audited
    registry._open = lambda row: deepcopy(real_record)
    registry._insert_connection = lambda *a, **k: None
    real_cohort = deepcopy(result["/api/cohorts"][0])
    real_cohort["body"].pop("size")
    real_cohort["body"].update(source_class="REAL_HUMAN", member_twin_ids=[real_record["twin_id"]])
    real_cohort["helpers"] += ("livemorebio.aegle.subjects:SubjectRegistry._create_real_cohort",)
    result["/api/cohorts"].append(real_cohort)
    cohort = registry.create_cohort(deepcopy(result["/api/cohorts"][0]["body"]))
    cohort["cohort_id"] = "cohort-technical-field-sweep"
    registry.get_cohort = lambda identity: deepcopy(cohort)
    registry.page_records = lambda kind, **kw: {"records": [deepcopy(record if kind == "TWIN" else cohort)],
        "pagination": {"next_cursor": None}}
    registry.page_cohort_members = lambda identity, **kw: {"members": [], "pagination": {"next_cursor": None}}
    registry.get_cohort_member = lambda identity, member_id: {"member_id": member_id, "fixture": "SYNTHETIC"}
    monkeypatch.setattr(server, "_current_snapshot", lambda: {"base": "healthy"})
    from livemorebio import audit
    audit_row = {"id": "technical-audit-record", "action": "technical-audit-action", "ts": "2026-10-02"}
    original_open = builtins.open
    monkeypatch.setattr(server, "open", lambda path, *a, **k:
        io.StringIO(json.dumps(audit_row) + "\n") if str(path) == audit.LOG_PATH else original_open(path, *a, **k),
        raising=False)
    monkeypatch.setattr(audit, "verify", lambda record: True)
    get_specs = {
        "/api/twins": {"query": {"limit": 1, "cursor": "technical-cursor", "q": "technical"}},
        "/api/twins/{twin_id}": {"path_params": {"twin_id": record["twin_id"]}},
        "/api/cohorts": {"query": {"limit": 1, "cursor": "technical-cursor", "q": "technical"}},
        "/api/cohorts/{cohort_id}": {"path_params": {"cohort_id": cohort["cohort_id"]}},
        "/api/cohorts/{cohort_id}/members": {"path_params": {"cohort_id": cohort["cohort_id"]},
            "query": {"limit": 1, "cursor": "technical-cursor"}},
        "/api/cohorts/{cohort_id}/members/{member_id}": {"path_params": {"cohort_id": cohort["cohort_id"], "member_id": "technical-member"}},
        "/api/audit": {"query": {"limit": 1, "action": audit_row["action"]}},
        "/api/audit/{record_id}": {"path_params": {"record_id": audit_row["id"]}},
    }
    for path, spec in get_specs.items():
        result.setdefault(path, []).append({"body": None, "method": "GET", "status": 200,
            "setup": reset, "helpers": (), **spec})
    return result


def aegle_patch_baselines(monkeypatch, tmp_path):
    import importlib.util
    from pathlib import Path
    from livemorebio.aegle import server
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.life_patch.protocol import PatchAdmissionController
    from livemorebio.life_patch.protocol_v3 import ManifestV3, TelemetryEnvelopeV3
    from livemorebio.security import sign_patch_admission
    from livemorebio.tests.test_patch_protocol_v3 import manifest_payload, envelope_payload
    from datetime import datetime, timedelta, timezone

    aegle_registry_baselines(monkeypatch)
    registry = server._subject_registry()
    v2_record = registry.active_twin()
    wire, manifest = admitted_patch_fixture(tmp_path,
        subject_id="pseudonym-SYNTHETIC-field-sweep", device_id="technical-device")
    v3_wires = []
    for kind in ("scalar", "modeled", "waveform"):
        raw_manifest, raw = manifest_payload(), envelope_payload()
        stamp = datetime.now(timezone.utc) - timedelta(seconds=1)
        timestamp = stamp.isoformat()
        raw.update(subject_id="pseudonym-SYNTHETIC-field-sweep", captured_at=timestamp,
                   acquisition_start=timestamp, acquisition_end=timestamp)
        measurement = raw["measurements"][0]
        measurement.update(quality_status="degraded", quality_flags=["technical-fixture"])
        if kind == "modeled":
            raw_manifest["capabilities"][0]["provenance"] = measurement["provenance"] = "modeled"
            measurement["model_context"] = {"prediction_id": "technical-prediction", "condition_id": "control",
                "model_time_min": 2., "model_id": "technical-model", "mapping_id": "technical-mapping"}
        elif kind == "waveform":
            raw_manifest["capabilities"][0].update(signal="ppg_au", unit="AU", channel="ppg")
            measurement.update(signal="ppg_au", unit="AU", kind="waveform", samples=[1., 2., 1.], sample_period_s=.5)
            measurement.pop("value")
            measurement["context"]["endpoint"] = "ppg_au"
            raw["acquisition_start"] = (stamp - timedelta(seconds=1)).isoformat()
            raw["clock"]["monotonic_start_s"] = 11.
        v3_manifest = ManifestV3.from_dict(raw_manifest)
        raw["manifest_hash"] = v3_manifest.capability_hash
        v3_envelope = TelemetryEnvelopeV3(raw)
        admission = {"admission": "accepted", "admitted_at": timestamp, "received_at": timestamp,
            "device_id": v3_envelope.device_id, "mode": "virtual", "envelope_hash": v3_envelope.envelope_hash,
            "capability_hash": v3_manifest.capability_hash, "manifest_hash": v3_manifest.capability_hash}
        v3_wires.append({"envelope": v3_envelope.to_dict(), "manifest": v3_manifest.to_dict(),
            "admission": admission, "admission_signature": sign_patch_admission(admission)})
    # The numerical model and peer delivery are not part of field admission.
    monkeypatch.setattr(server, "_require_numerical_model", lambda: None)
    monkeypatch.setattr(server, "_assert_numerical_available", lambda: None)
    forwarded = []

    def forward(body):
        forwarded.append({"method": "POST", "path": "/patch/virtual/sample", "body": deepcopy(body)})
        return 202, {"accepted": True}

    monkeypatch.setattr(server, "_forward_virtual_patch", forward)
    monkeypatch.setattr(server, "_current_snapshot", lambda: {"technical_fixture": "SYNTHETIC", "base": "healthy"})

    def reset():
        forwarded.clear()
        monkeypatch.setattr(registry, "active_twin", lambda: deepcopy(v2_record))
        monkeypatch.setattr(server, "_model_source_authority", ModelSourceAuthority())
        monkeypatch.setattr(server, "_patch_admission", PatchAdmissionController())
        monkeypatch.setattr(server, "_state", {"tw": None, "subject": None,
            "initialized": True, "observation_state": server.ObservationState()})

    def reset_v3():
        reset()
        registry = server._subject_registry()
        record = registry.active_twin()
        record["patch_bindings"] = [{"device_id": v3_envelope.device_id, "mode": "virtual", "protocol_version": "3.0"}]
        monkeypatch.setattr(registry, "active_twin", lambda: deepcopy(record))

    decode = ("livemorebio.life_patch.protocol:decode_envelope", "livemorebio.life_patch.protocol:TelemetryEnvelope.from_dict",
              "livemorebio.life_patch.protocol:TelemetryMeasurement.from_dict",
              "livemorebio.life_patch.protocol:TelemetryMeasurement.__post_init__",
              "livemorebio.security:verify_patch_admission")
    guard = {"prefix": ("admission",), "function": "livemorebio.security:verify_patch_admission",
             "result": False, "status": 422, "error": "LIFE admission signature is missing or invalid"}
    return {
        "/api/patch/telemetry": [{"body": wire, "status": 202, "setup": reset, "helpers": decode,
            "guards": [guard]}] + [{"body": v3_wire, "status": 202, "setup": reset_v3,
            "helpers": decode + ("livemorebio.life_patch.protocol_v3:ManifestV3.__init__",
                "livemorebio.life_patch.protocol_v3:TelemetryEnvelopeV3.__init__",
                "livemorebio.life_patch.protocol_v3:_measurement"), "guards": [guard]} for v3_wire in v3_wires],
        "/api/patch/virtual": [{"body": {"envelope": wire["envelope"]}, "status": 202,
            "setup": reset, "helpers": (), "forwarded": lambda: forwarded,
            "forward_method": "POST", "forward_path": "/patch/virtual/sample"},
            {"body": {"subject_id": "pseudonym-SYNTHETIC-field-sweep",
            "device_id": "technical-device", "protocol_version": "2.0", "readings": {"glucose_mgdl": 100., "hr_bpm": 70.}},
            "status": 202, "setup": reset, "helpers": (), "forwarded": lambda: forwarded,
            "forward_method": "POST", "forward_path": "/patch/virtual/sample"}],
    }



def research_baselines(monkeypatch):
    from livemorebio import research
    from livemorebio.aegle import research_api, server
    from livemorebio.life_system.reference.sources import licensed_import
    from livemorebio.tests.test_research_api import run_fixture, study_spec, measurement_payload, learning_payload
    from livemorebio.tests.test_research_workflow import resilience_spec

    class MemoryStore:
        def __init__(self):
            self.records = {}
            self.cipher = SimpleNamespace(decrypt=lambda nonce, payload, aad: payload)

        def put(self, kind, payload):
            identity = 'research-' + f'{len(self.records) + 1:032x}'
            record = {**deepcopy(payload), 'id': identity, 'created_at': '2026-10-01T12:00:00+00:00',
                      'kind': kind}
            self.records[identity] = record
            return {**deepcopy(record), 'content_sha256': research._hash(record)}

        def get(self, identity, kind=None):
            return research.ResearchStore.get(self, identity, kind)

        @contextmanager
        def _connect(self):
            records = self.records
            class Connection:
                def execute(self, statement, values=()):
                    record = records.get(values[0]) if values else None
                    row = None if record is None else (record['kind'], research._hash(record), b'',
                                                      json.dumps(record).encode())
                    return SimpleNamespace(fetchone=lambda: row)
            yield Connection()

        def list(self, kind=None):
            return [deepcopy(record) for record in self.records.values() if kind is None or record['kind'] == kind]

    store = MemoryStore()
    service = research.ResearchService(store)
    monkeypatch.setattr(research_api, 'service', lambda: service)
    run = run_fixture()
    metabolic_run = {'run_id': 'protocol-' + 'b' * 32,
        'protocol_id': 'cendos.metformin-cohort-comparison.v1', 'evidence_state': 'MODELED_MECHANISTIC',
        'qualification_state': 'NOT_QUALIFIED', 'intervention': {'dose_mg': 1000.},
        'cohorts': [{'cohort_id': 'technical-metabolic-cohort', 'name': 'technical-fixture',
                     'members': [{'member_id': 'member-1', 'delta_mean': -5.}]}]}
    runs = {item['run_id']: item for item in (run, metabolic_run)}

    def get_run(identity):
        if identity not in runs:
            from livemorebio.cendos.protocol_runs import ProtocolRunNotFound
            raise ProtocolRunNotFound('technical run not found')
        return deepcopy(runs[identity])

    monkeypatch.setattr(server, '_protocol_run_store', lambda: SimpleNamespace(get=get_run))
    study_body = study_spec()
    study = service.freeze(run, {key: value for key, value in study_body.items() if key != 'run_id'})
    measurement_body = measurement_payload()
    measurement = service.admit_measurement(study['id'], measurement_body)
    metabolic_study_body = {**study_body, 'run_id': metabolic_run['run_id'], 'endpoint': 'delta_mean_glucose'}
    metabolic_study = service.freeze(metabolic_run, {
        key: value for key, value in metabolic_study_body.items() if key != 'run_id'})
    metabolic_measurement_body = deepcopy(measurement_body)
    metabolic_measurement_body['csv'] = (
        'sample_id,member_id,dose_mg,endpoint,unit,value,replicate_id,measured_at,quality_status\n'
        'specimen-1,member-1,1000,delta_mean_glucose,mg/dL,-5,1,' + datetime.now(timezone.utc).isoformat() + ',pass\n')
    metabolic_measurement = service.admit_measurement(metabolic_study['id'], metabolic_measurement_body)
    resilience_body = resilience_spec()
    resilience = service.register_resilience(resilience_body)
    resilience_measurement_body = deepcopy(measurement_body)
    stamp = datetime.now(timezone.utc)
    last_treatment = stamp - timedelta(days=40)
    stress_start = last_treatment + timedelta(days=10)
    csv_output = io.StringIO()
    writer = csv.DictWriter(csv_output, fieldnames=(
        'subject_id', 'operation', 'endpoint', 'unit', 'stress_id', 'stress_started_at',
        'measured_at', 'last_treatment_at', 'value', 'washout_confirmed', 'quality_status'))
    writer.writeheader()
    for subject in resilience['subjects']:
        for operation in resilience['operations']:
            if operation['applicable']:
                writer.writerow({'subject_id': subject['subject_id'], 'operation': operation['id'],
                    'endpoint': operation['endpoint'], 'unit': operation['unit'], 'stress_id': 'meal',
                    'stress_started_at': stress_start.isoformat(), 'measured_at': stamp.isoformat(),
                    'last_treatment_at': last_treatment.isoformat(), 'value': .5,
                    'washout_confirmed': 'true', 'quality_status': 'pass'})
    resilience_measurement_body['csv'] = csv_output.getvalue()
    resilience_measurement = service.admit_measurement(resilience['id'], resilience_measurement_body)

    from livemorebio.life_system.reference import sources as reference_sources

    class MemoryLicensedReferenceStore(licensed_import.LicensedReferenceStore):
        def __init__(self, *args, **kwargs):
            self.directory = Path('technical-fixture-never-persisted')

        def _write(self, *args, **kwargs):
            pass

    # Replacing bindings restores the original class, including its allocator;
    # monkeypatching inherited __new__ can change later constructor behavior.
    monkeypatch.setattr(licensed_import, 'LicensedReferenceStore', MemoryLicensedReferenceStore)
    monkeypatch.setattr(reference_sources, 'LicensedReferenceStore', MemoryLicensedReferenceStore)
    # Invented SYNTHETIC parser fixture, matching the licensed-source test convention.
    # No vendor record or licensed content is used by this in-memory admission test.
    technical_reference_id = 'H' + '99999'
    records = [{'id': technical_reference_id, 'name': 'technical-reference', 'description': 'technical fixture only',
                'genes': ['TCF7L2'], 'pathways': ['technical-pathway'],
                'identifiers': {'technical-namespace': 'technical-id'}, 'citations': ['technical-citation']}]
    manifest = {'schema': licensed_import.MANIFEST_SCHEMA, 'record_schema': licensed_import.RECORD_SCHEMA,
                'source': 'kegg', 'release': 'technical-release', 'license_id': 'technical-license',
                'approval_reference': 'technical-approval', 'normalization_version': 'technical-normalization',
                'upstream_sha256': 'a' * 64, 'acquired_at': '2026-10-01T12:00:00+00:00',
                'expires_at': '2099-10-01T12:00:00+00:00',
                'permissions': {'internal_research': True, 'reference_lookup': True,
                                'model_training': False, 'redistribution': False},
                'record_count': 1, 'records_sha256': licensed_import._sha(records)}
    helpers = ('livemorebio.aegle.research_api:body', 'livemorebio.research:_text',
               'livemorebio.research:_identity', 'livemorebio.research:_narrative', 'livemorebio.research:_number')
    return {
        '/api/research/studies': [{'body': body, 'status': 201, 'branch': branch,
                                   'helpers': helpers + ('livemorebio.research:ResearchService.freeze',)}
            for body, branch in ((study_body, 'pxr'), (metabolic_study_body, 'metabolic'))],
        '/api/research/studies/{study_id}/measurements': [{
            'path_params': {'study_id': study['id']}, 'body': measurement_body, 'status': 201,
            'csv_fields': ('csv',), 'branch': 'paired-pxr',
            'helpers': helpers + ('livemorebio.research:ResearchService.admit_measurement',
                                   'livemorebio.research:ResearchService._validate_paired_rows')}, {
            'path_params': {'study_id': metabolic_study['id']}, 'body': metabolic_measurement_body, 'status': 201,
            'csv_fields': ('csv',), 'branch': 'paired-metabolic',
            'helpers': helpers + ('livemorebio.research:ResearchService.admit_measurement',
                                   'livemorebio.research:ResearchService._validate_paired_rows')}, {
            'path_params': {'study_id': resilience['id']}, 'body': resilience_measurement_body, 'status': 201,
            'csv_fields': ('csv',), 'branch': 'resilience',
            'helpers': helpers + ('livemorebio.research:ResearchService.admit_measurement',
                                   'livemorebio.research:ResearchService._validate_resilience_rows')}],
        '/api/research/studies/{study_id}/compare': [{
            'path_params': {'study_id': selected_study['id']}, 'body': {'measurement_id': selected_measurement['id']},
            'status': 200, 'branch': branch, 'helpers': helpers + ('livemorebio.research:ResearchService.compare',)}
            for selected_study, selected_measurement, branch in (
                (study, measurement, 'paired-pxr'), (metabolic_study, metabolic_measurement, 'paired-metabolic'))],
        '/api/research/resilience': [{'body': resilience_body, 'status': 201,
            'helpers': helpers + ('livemorebio.research:ResearchService.register_resilience',)}],
        '/api/research/resilience/{protocol_id}/assess': [{
            'path_params': {'protocol_id': resilience['id']}, 'body': {'measurement_ids': ids}, 'status': 200,
            'branch': 'measured' if ids else 'awaiting-measurements',
            'helpers': helpers + ('livemorebio.research:ResearchService.assess_resilience',)}
            for ids in ([], [resilience_measurement['id']])],
        '/api/research/learning': [{'body': learning_payload(), 'status': 201,
            'helpers': helpers + ('livemorebio.research:ResearchService.record_learning',)}],
        '/api/research/sources/import': [{'body': {'manifest': manifest, 'records': records}, 'status': 201,
            'helpers': ('livemorebio.life_system.reference.sources.licensed_import:LicensedReferenceStore.import_records',
                        'livemorebio.life_system.reference.sources.licensed_import:validate_release')}],
        '/api/research/records/{record_id}': [{'method': 'GET', 'path_params': {'record_id': study['id']},
            'status': 200, 'helpers': helpers + ('livemorebio.research:ResearchStore.get',)}],
        '/api/research/records/{record_id}/export.json': [{'method': 'GET', 'path_params': {'record_id': study['id']},
            'status': 200, 'helpers': helpers + ('livemorebio.research:ResearchStore.get',)}],
        '/api/research/sources/{source}/{identifier}': [{'method': 'GET',
            'path_params': {'source': 'kegg', 'identifier': technical_reference_id}, 'status': 200,
            'helpers': ('livemorebio.life_system.reference.sources.licensed_import:get_disease_context',
                        'livemorebio.life_system.reference.sources.licensed_import:LicensedReferenceStore.disease_context',
                        'livemorebio.life_system.reference.sources.licensed_import:_source',
                        'livemorebio.life_system.reference.sources.licensed_import:_identifier')}],
    }


def reference_baselines(monkeypatch):
    from livemorebio.aegle import reference_cohort_api as api, reference_cohorts as cohorts, population_records as population
    from livemorebio.tests.test_population_records import tables
    from livemorebio.tests.test_reference_cohort_lifecycle import draft

    service = cohorts.ReferenceCohortService.__new__(cohorts.ReferenceCohortService)
    service.store_id = 'technical-field-sweep-store'
    service._keys = {key: hashlib.sha256(('technical-fixture-' + key).encode()).digest()
                     for key in ('preview', 'cursor', 'idempotency')}
    service.fingerprint_key = hashlib.sha256(b'technical-field-sweep-fingerprint').digest()
    service.registry = SimpleNamespace(_seal=lambda *a, **k: (b'', b''))
    class Connection:
        def execute(self, statement, args=()):
            if 'ordinal>?' in statement:
                rows = [{'ordinal': index, 'member_id': f'technical-member-{index}'}
                        for index in range(args[1] + 1, min(args[1] + 1 + args[2], 3))]
                return SimpleNamespace(fetchall=lambda: rows)
            if 'member_id=?' in statement:
                row = {'ordinal': 1, 'member_id': 'technical-member-1'} if args[1] == 'technical-member-1' else None
                return SimpleNamespace(fetchone=lambda: row)
            return SimpleNamespace(fetchall=lambda: [], fetchone=lambda: None)

    connection = Connection()

    @contextmanager
    def connection_stub(**kwargs):
        yield connection, 'technical-authority'

    monkeypatch.setattr(service, '_connection', connection_stub)
    monkeypatch.setattr(service, '_existing', lambda *a, **k: None)
    monkeypatch.setattr(service, '_write_member', lambda *a, **k: None)
    monkeypatch.setattr(service, '_audit', lambda *a, **k: None)
    reference_record = {'cohort_id': 'technical-reference-cohort', 'size': 3, 'construction_sha256': 'a' * 64}

    def read_record(con, identity):
        if identity != reference_record['cohort_id']:
            raise cohorts.ReferenceCohortError('REFERENCE_COHORT_NOT_FOUND', 'Technical cohort not found.', 404)
        return dict(reference_record)

    monkeypatch.setattr(service, '_record', read_record)
    monkeypatch.setattr(service, '_member', lambda row, record: dict(row))
    monkeypatch.setattr(service, '_load_population', lambda: population._normalize_tables(tables(), fingerprint_key=service.fingerprint_key))
    monkeypatch.setattr(cohorts, 'normalization_version', lambda: 'technical-normalization')
    monkeypatch.setattr(api, 'service', lambda: service)
    monkeypatch.setattr(api.sources, 'install_source', lambda *a, **k: {'state': 'technical-stub'})
    payload = draft()
    preview = service.preview(payload)
    cursor = service._token({'version': 1, 'store_id': service.store_id,
                             'cohort_id': reference_record['cohort_id'], 'construction_sha256': 'a' * 64,
                             'limit': 1, 'last_ordinal': 0}, 'cursor')
    helpers = ('livemorebio.aegle.reference_cohort_api:_body', 'livemorebio.aegle.reference_cohorts:_draft')
    return {
        '/api/population-sources/{source_id}/install': [{
            'path_params': {'source_id': cohorts.SOURCE_ID}, 'body': {'accepted_use': 'statistical_research'},
            'status': 200, 'helpers': helpers}],
        '/api/reference-cohorts/preview': [{'body': payload, 'status': 200,
            'helpers': helpers + ('livemorebio.aegle.reference_cohorts:ReferenceCohortService.preview',)}],
        '/api/reference-cohorts': [{'body': {'draft': payload, 'preview_token': preview['preview_token']},
            'headers': {'Idempotency-Key': 'technical-reference-field-sweep'}, 'status': 201,
            'helpers': helpers + ('livemorebio.aegle.reference_cohorts:ReferenceCohortService.create',)}],
        '/api/reference-cohorts/{cohort_id}/members': [{'method': 'GET',
            'path_params': {'cohort_id': reference_record['cohort_id']}, 'query': {'limit': '1', 'cursor': cursor},
            'status': 200, 'helpers': ('livemorebio.aegle.reference_cohorts:ReferenceCohortService.page_members',)}],
        '/api/reference-cohorts/{cohort_id}/members/{member_id}': [{'method': 'GET',
            'path_params': {'cohort_id': reference_record['cohort_id'], 'member_id': 'technical-member-1'},
            'status': 200, 'helpers': ('livemorebio.aegle.reference_cohorts:ReferenceCohortService.get_member',)}],
    }


def execution_baselines(monkeypatch):
    """Real request/source/policy/consumer validators; memory store and solver boundary stubs."""
    import base64
    from dataclasses import asdict
    from datetime import timedelta
    import os
    from livemorebio.aegle import server, execution_api as api, execution_observations, life_session_api
    from livemorebio.aegle.execution import ExecutionManager
    from livemorebio.aegle.execution_contract import METABOLIC, ExecutionError, capture_source_payload, digest
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.engines.metabolic.glucose_insulin import HEALTHY, MetabolicProfile
    from livemorebio.tests.test_execution_observations import delivery

    monkeypatch.setenv('LIVEMORE_PATCH_ADMISSION_HMAC_KEY', base64.urlsafe_b64encode(os.urandom(32)).decode())
    authority = ModelSourceAuthority()
    record = {'subject_id': 'pseudonym-technical', 'twin_id': 'twin-technical', 'version': 1,
              'source_class': 'SYNTHETIC', 'lifecycle': 'ACTIVE',
              'patch_bindings': [{'device_id': 'v3-technical', 'mode': 'virtual', 'protocol_version': '3.0'}]}
    twin = SimpleNamespace(profile=MetabolicProfile(**asdict(HEALTHY)), meals=[(0., 75.)],
                           parameter_provenance=lambda: {'Gb': {'evidence_class': 'REFERENCE_INITIALIZED'}},
                           execution_observations={})
    monkeypatch.setattr(server, '_state', {'tw': twin, 'subject': deepcopy(record), 'initialized': True})
    monkeypatch.setattr(server, '_subject_registry', lambda: SimpleNamespace(active_twin=lambda: deepcopy(record)))
    monkeypatch.setattr(server, '_model_source_authority', authority)
    monkeypatch.setattr(api, '_check_runtime_identity', lambda: None)
    selection = api._source_selection()
    source = capture_source_payload(twin, selection, authority.generation, METABOLIC)
    policy = {'end_native': 3., 'frame_period_s': 1., 'time_scale': 60.}

    def execution_record(identity, source_value=source, policy_value=policy):
        return {'execution_id': identity, 'revision': 1, 'control_revision': 1, 'state': 'prepared',
                'source': deepcopy(source_value), 'policy': deepcopy(policy_value), 'source_valid': True,
                'checkpoint': None, 'initial_checkpoint': None, 'checkpoint_parent': None,
                'latest_frame': 0, 'latest_frame_hash': None, 'created_at': '2026-10-01T12:00:00+00:00',
                'updated_at': '2026-10-01T12:00:00+00:00', 'failure_code': None,
                'authorship': 'uninitialized', 'runtime_identity': None}

    class MemoryStore:
        def __init__(self):
            self.records = {digit * 32: execution_record(digit * 32) for digit in '1234567'}
            self.frame = None

        def begin_access(self, *a, **k):
            return 'technical-field-sweep-access'

        def finish_access(self, *a, **k):
            pass

        def get(self, identity):
            if identity not in self.records:
                raise ExecutionError()
            return deepcopy(self.records[identity])

        def create(self, source, policy, **kwargs):
            return execution_record('1' * 32, source, policy)

        def update(self, identity, *, expected_revision, changes, **kwargs):
            return {**self.get(identity), **deepcopy(changes)}

        def acquire_owner(self, identity):
            return identity

        def release_owner(self, owner):
            pass

        def frames(self, identity, *, after_frame=0, limit=100):
            return [deepcopy(self.frame)] if identity == '7' * 32 and after_frame == 0 else []

    store = MemoryStore()
    manager = ExecutionManager(store, run_background=False, clock=lambda: 10.)
    monkeypatch.setattr(api, '_manager', lambda: manager)
    binding = {'session_id': 'a' * 32, 'source_snapshot_hash': source['source_snapshot_hash'],
               'producer_instance': manager._producer_instance}
    store.records['2' * 32]['consumer_binding'] = binding
    manager._consumer_leases['2' * 32] = {'deadline': 100., 'renewal_count': 0}

    def numerical_control(identity, expected_revision, generation, *, control_revision=None, **kwargs):
        baseline = store.get(identity)
        manager._check(baseline, expected_revision, generation, control_revision=control_revision)
        return {'technical_solver_stub': True}

    monkeypatch.setattr(manager, '_activate', numerical_control)
    monkeypatch.setattr(manager, '_transition', lambda identity, revision, generation, target, **kwargs:
                        numerical_control(identity, revision, generation, **kwargs))
    frame = {'execution_id': '7' * 32, 'frame_index': 1, 'selection': selection,
             'source_generation': authority.generation, 'source_snapshot_hash': source['source_snapshot_hash'],
             'engine_contract_id': METABOLIC, 'native_unit': 'min', 'native_end': 1.,
             'authorship': 'engine', 'evidence_class': 'MODELED', 'numerical_domain_notes': [],
             'generated_at': (datetime.now(timezone.utc) - timedelta(seconds=2)).isoformat(),
             'generated_monotonic_s': 10.,
             'series': [{'quantity': 'glucose_mgdl', 'unit': 'mg/dL', 'compartment': 'plasma', 'values': [90.]}]}
    frame['frame_hash'] = digest(frame)
    store.frame = frame
    store.records['7' * 32].update(consumer_binding=binding, state='running', authorship='engine')

    class MemoryLedger:
        def __init__(self, store):
            pass

        def get(self, *a):
            return None

        def admit(self, receipt):
            return receipt

        def latest(self, *a):
            return None

    monkeypatch.setattr(execution_observations, 'ExecutionReceiptLedger', MemoryLedger)
    observation = delivery(frame)

    peer_receipts = []
    class Peer:
        def request_response(self, method, path, body, **kwargs):
            # First-party relay receipts stay in memory; only booleans leave
            # the sweep. LIFE validates these opaque fields in its own cases.
            peer_receipts.append({'method': method, 'path': path, 'body': deepcopy(body)})
            return 200, {'state': 'technical-stub'}

    monkeypatch.setattr(life_session_api, '_client', Peer)
    prepare = {'engine_contract_id': METABOLIC, 'expected_source_generation': authority.generation,
               'expected_twin_id': record['twin_id'], 'expected_twin_version': 1, 'policy': policy}
    helpers = ('livemorebio.aegle.execution_api:_body', 'livemorebio.aegle.execution_api:_prepare',
               'livemorebio.aegle.execution_api:_positive_version', 'livemorebio.aegle.execution_api:_control_guard',
               'livemorebio.aegle.execution_contract:validate_policy', 'livemorebio.aegle.execution_api:_operate',
               'livemorebio.aegle.life_session_api:_session')
    cases = {
        '/api/executions': [{'body': prepare, 'headers': {'Idempotency-Key': 'technical-execution-sweep'},
                             'status': 201, 'helpers': helpers}],
        '/api/executions/{execution_id}/fork-checkpoint': [{'path_params': {'execution_id': '1' * 32},
            'body': {**prepare, 'expected_parent_revision': 1},
            'headers': {'Idempotency-Key': 'technical-execution-fork'}, 'status': 201, 'helpers': helpers}],
        '/api/executions/{execution_id}/consumer': [{'path_params': {'execution_id': '1' * 32},
            'body': {'session_id': 'a' * 32, 'source_snapshot_hash': source['source_snapshot_hash'],
                     'expected_revision': 1, 'expected_source_generation': authority.generation},
            'status': 200, 'helpers': helpers + ('livemorebio.aegle.execution:ExecutionManager.bind_consumer',)}],
        '/api/executions/{execution_id}/consumer/renew': [{'path_params': {'execution_id': '2' * 32},
            'body': {'session_id': 'a' * 32, 'source_snapshot_hash': source['source_snapshot_hash'],
                     'expected_source_generation': authority.generation},
            'status': 200, 'helpers': helpers + ('livemorebio.aegle.execution:ExecutionManager.renew_consumer',)}],
        '/api/execution-observations': [{'body': observation, 'status': 200,
            'helpers': helpers + ('livemorebio.aegle.execution_observations:admit_execution_observation',)}],
        '/api/executions/{execution_id}/{action}': [
            {'path_params': {'execution_id': '3' * 32, 'action': action},
             'body': {guard: 1, 'expected_source_generation': authority.generation}, 'status': 200,
             'helpers': helpers, 'branch': action + '-' + guard}
            for action in ('start', 'pause', 'resume', 'stop')
            for guard in ('expected_revision', 'expected_control_revision')],
        '/api/executions/{execution_id}/frames': [{'method': 'GET', 'path_params': {'execution_id': '1' * 32},
            'query': {'after_frame': '0', 'limit': '100'}, 'status': 200,
            'helpers': helpers + ('livemorebio.aegle.execution:ExecutionManager.frames',)}],
        '/api/executions/{execution_id}': [{'method': 'GET', 'path_params': {'execution_id': '1' * 32},
                                           'status': 200, 'helpers': helpers}],
        '/api/executions/{execution_id}/observations': [{'method': 'GET', 'path_params': {'execution_id': '1' * 32},
                                                        'status': 200, 'helpers': helpers}],
        '/api/patch/virtual/probe': [{'body': {'device_id': 'v3-technical'}, 'status': 200, 'helpers': helpers}],
        '/api/patch/virtual/sessions': [{'body': {'device_id': 'v3-technical', 'execution_id': '1' * 32,
            'source_snapshot_hash': source['source_snapshot_hash'], 'expected_selection': selection,
            'idempotency_key': 'technical-life-session'}, 'status': 200, 'helpers': helpers,
            'relay': {'received': lambda: peer_receipts[-1] if peer_receipts else None,
                      'method': 'POST', 'path': '/patch/virtual/sessions'}}],
        '/api/patch/virtual/sessions/{session_id}': [{'method': 'GET', 'path_params': {'session_id': 'a' * 32},
                                                   'status': 200, 'helpers': helpers}],
        '/api/patch/virtual/sessions/{session_id}/{action}': [
            {'path_params': {'session_id': 'a' * 32, 'action': action}, 'body': {guard: 1},
             'status': 200, 'helpers': helpers, 'branch': action + '-' + guard}
            for action in ('pause', 'resume', 'stop')
            for guard in ('expected_revision', 'expected_control_revision')],
    }
    return cases



def aegle_get_baselines(monkeypatch):
    from livemorebio import audit, bus, molecular_reference, stack_client
    from livemorebio.aegle import evidence_api, rcache, screen_runs, server
    from livemorebio.anatomy import atlas_reference, meshes
    from livemorebio.engines import drug_targets, metabolism

    # These are storage/rendering boundaries; the endpoint and source identity
    # grammars remain real. No person-shaped values enter a persistent store.
    monkeypatch.setattr(audit, 'record', lambda *a, **k: {})
    monkeypatch.setattr(bus, 'events', lambda *a, **k: [])
    monkeypatch.setattr(server, '_workspace_projection', lambda: {'technical_fixture': True})
    monkeypatch.setattr(rcache, 'get', lambda *a, **k: None)
    monkeypatch.setattr(rcache, 'put', lambda *a, **k: None)
    drug_targets.resolve_drug.cache_clear()
    drug_targets.resolve_bioactive.cache_clear()

    def no_model():
        raise RuntimeError('technical fixture has no numerical model')
    monkeypatch.setattr(metabolism, 'load_recon3d', no_model)

    class PeerResponse:
        status = 200

        def read(self):
            return b'{"resolved":false,"name":"metformin","error":"technical unavailable"}'

    @contextmanager
    def peer_response(*args, **kwargs):
        yield PeerResponse()

    # The relay still validates PubChem grammar before reaching this transport.
    monkeypatch.setattr(stack_client, 'operation_identity', lambda *a, **k: object())
    monkeypatch.setattr(stack_client, 'startup_identity', lambda *a, **k: object())
    monkeypatch.setattr(stack_client, 'request_response', peer_response)

    atlas_bytes = b'SYNTHETIC technical route bytes, not anatomical acceptance'
    def atlas_asset(digest, key):
        return atlas_bytes, {'source_id': atlas_reference.SOURCE_ID,
            'manifest_sha256': digest, 'asset_key': key,
            'sha256': hashlib.sha256(atlas_bytes).hexdigest(), 'bytes': len(atlas_bytes)}
    monkeypatch.setattr(atlas_reference, 'read_asset', atlas_asset)

    def unavailable_mesh(key):
        raise OSError('technical fixture has no acquired anatomical mesh')
    monkeypatch.setattr(meshes, 'read_asset', unavailable_mesh)

    # Exercise the actual run-id grammar and loader with an in-memory file.
    run_id = '1' * 32
    result = {
        'summary': {'compound': 'technical fixture', 'dose': 0, 'grams': 0,
            'cohort_n': 0, 'seed': 0, 'n_effect': 0,
            'responder_rate': 0, 'mean_delta_mean': 0},
        'ranked': [], 'audit': {'result_sha256': 'technical-fingerprint',
            'alg': 'technical-only', 'hmac_sha256': 'technical-not-a-signature',
            'id': 'technical-record', 'ts': 0,
            'provenance': {'fixture': 'SYNTHETIC technical, not observed'}},
    }
    envelope = json.dumps({'schema': screen_runs.SCHEMA, 'run_id': run_id, 'result': result})
    monkeypatch.setattr(screen_runs, 'run_dir', lambda: '/SYNTHETIC-in-memory-screen-runs')
    monkeypatch.setattr(screen_runs, 'open', lambda *a, **k: io.StringIO(envelope), raising=False)

    package_id = 'technical-evidence-package'
    def get_package(tenant, identity):
        if tenant != evidence_api.TENANT or identity != package_id:
            raise KeyError('technical package not found')
        return object()
    monkeypatch.setattr(evidence_api, 'service', lambda: SimpleNamespace(get=get_package))
    monkeypatch.setattr(evidence_api, 'detail', lambda value: {'technical_fixture': True})

    descriptor = molecular_reference.lookup('KRAS')['reference']
    specs = []
    def add(path, *, query=None, path_params=None, status=200, helpers=(), code=None):
        spec = {'method': 'GET', 'path': path, 'status': status, 'helpers': helpers}
        if query is not None:
            spec['query'] = query
        if path_params is not None:
            spec['path_params'] = path_params
        if code is not None:
            spec['code'] = code
        specs.append(spec)

    add('/api/workspace/stream', query={'once': True})
    add('/api/search', query={'q': 'glucose', 'kind': 'disease'},
        helpers=('livemorebio.life_system.retrieval:SubstrateIndex.query_with_status',))
    add('/api/structure', query={'gene': 'KRAS'},
        helpers=('livemorebio.aegle.server:_molecular_reference_response',
                 'livemorebio.molecular_reference:lookup'))
    add('/api/molecular/structures/{coordinate_sha256}/coordinates',
        path_params={'coordinate_sha256': descriptor['coordinate_sha256']},
        helpers=('livemorebio.aegle.server:_molecular_reference_response',
                 'livemorebio.molecular_reference:read_coordinates'))
    add('/api/resolve', query={'compound': 'metformin', 'refresh': False})
    add('/api/resolve', query={'compound': 'metformin', 'refresh': True})
    add('/api/events', query={'after': 0.0})
    add('/api/cendos/compound', query={'name': 'metformin'})
    add('/assets/anatomy/atlas/{manifest_sha256}/{asset_key}.glb',
        path_params={'manifest_sha256': 'a' * 64, 'asset_key': 'skin'})
    add('/assets/anatomy/{key}.glb', path_params={'key': 'heart'},
        status=503, code='ANATOMY_UNAVAILABLE')
    add('/lib/{asset:path}', path_params={'asset': 'subjects.js'})
    for suffix in ('report.md', 'report.audit.json'):
        add('/api/screen/{run_id}/' + suffix, path_params={'run_id': run_id},
            helpers=('livemorebio.aegle.screen_runs:load', 'livemorebio.aegle.screen_runs:_path'))
    add('/api/scientific-sources', query={'collection': 'livemore_adapter',
        'workflow': 'reactions_metabolism', 'lifecycle': 'workflow_wired', 'limit': 1, 'offset': 0},
        helpers=('livemorebio.scientific_sources.catalog:Catalog.report',))
    add('/api/evidence/{package_id}', path_params={'package_id': package_id})
    return specs



def security_baselines(monkeypatch):
    from fastapi.testclient import TestClient
    from livemorebio import security
    from livemorebio.aegle import server
    from livemorebio.cendos import service as cendos
    from livemorebio.life_system import service as life
    from livemorebio.service_identity import IdentitySnapshot
    from livemorebio.stack_proof import ServiceProofState, ProofLimiter

    token = 'technical-note-gate-token'
    monkeypatch.setenv(security.TOKEN_ENV, token)
    monkeypatch.setattr(security, '_MANUAL_CONSOLE_ATTEMPTS', deque(maxlen=20))
    client = TestClient(server.app, raise_server_exceptions=False,
        base_url='http://127.0.0.1:24197', client=('127.0.0.1', 43197),
        headers={'Authorization': 'Bearer ' + token})
    exchange = next(route.endpoint for route in server.app.routes
                    if getattr(route, 'path', None) == security.CONSOLE_EXCHANGE_PATH
                    and 'POST' in getattr(route, 'methods', set()))
    codes_cell = exchange.__closure__[exchange.__code__.co_freevars.index('codes')]
    monkeypatch.setattr(codes_cell, 'cell_contents', {})
    pending = codes_cell.cell_contents
    ordinary_code, manual_code = 'A' * 43, '0123456789ABCDEF'
    for kind, code in (('ordinary', ordinary_code), ('manual', manual_code)):
        monkeypatch.setitem(pending, (kind, code),
            security._PendingConsoleCode(kind, time.monotonic() + security.SESSION_CODE_TTL))
    result = [
        {'service': 'aegle', 'path': '/api/session/code', 'body': None,
         'client': client, 'status': 200, 'helpers': (), 'trace_endpoint': True},
        {'service': 'aegle', 'path': '/api/session/pair-code', 'body': None,
         'client': client, 'status': 200, 'helpers': (), 'trace_endpoint': True},
    ]
    for kind, code, headers in (
        ('ordinary', ordinary_code, {'Content-Type': 'application/x-www-form-urlencoded'}),
        ('manual', manual_code, {'Content-Type': 'application/x-www-form-urlencoded',
                               'Origin': 'http://127.0.0.1:24197'}),
    ):
        result.append({'service': 'aegle', 'path': security.CONSOLE_EXCHANGE_PATH, 'body': None,
            'form': {'code': code}, 'client': client, 'headers': headers, 'status': 200, 'branch': kind,
            'helpers': ('livemorebio.request_body:bounded_console_form_request',),
            'trace_endpoint': True, 'trace_helpers': ('livemorebio.request_body:bounded_console_form_request',)})
    for role, module, port in (('aegle', server, 24197), ('life', life, 24198), ('cendos', cendos, 24199)):
        snapshot = IdentitySnapshot(bytes(range(32)), role, 'http://127.0.0.1:' + str(port))
        monkeypatch.setattr(module.app.state, 'stack_proof',
                            ServiceProofState(snapshot, b'I' * 32, ProofLimiter()))
        result.append({'service': role, 'path': '/api/stack/prove', 'body': None,
            'raw_body': b'N' * 32, 'headers': {'Content-Type': 'application/octet-stream', 'Content-Length': '32'},
            'status': 200, 'helpers': ('livemorebio.stack_proof:_header_status',),
            'trace_endpoint': True})
    return result


_FIELD_SCHEMA_FILES = frozenset({
    'livemorebio/aegle/capture_time.py',
    'livemorebio/aegle/clinical_parameters.py',
    'livemorebio/aegle/execution_contract.py',
    'livemorebio/aegle/population.py',
    'livemorebio/aegle/profile_sources.py',
    'livemorebio/aegle/reference_cohorts.py',
    'livemorebio/aegle/subjects.py',
    'livemorebio/clinical_note_gate.py',
    'livemorebio/egress_destinations.py',
    'livemorebio/life_patch/execution_source.py',
    'livemorebio/life_patch/gateway.py',
    'livemorebio/life_patch/protocol.py',
    'livemorebio/life_patch/protocol_v3.py',
    'livemorebio/life_system/genome.py',
    'livemorebio/life_system/knowledge.py',
    'livemorebio/life_system/reference/knowledgebase.py',
    'livemorebio/life_system/structured_human.py',
    'livemorebio/research.py',
    'livemorebio/scientific_sources/catalog.py',
    'livemorebio/life_system/seed/anatomy.json',
    'livemorebio/life_system/seed/diseases.json',
    'livemorebio/life_system/seed/drugs.json',
    'livemorebio/life_system/seed/genes.json',
    'livemorebio/life_system/seed/gwas.json',
    'livemorebio/life_system/seed/meta.json',
    'livemorebio/life_system/seed/pathways.json',
    'livemorebio/life_system/seed/structures.json',
})


def _field_source_paths(services, monkeypatch, tmp_path):
    import inspect

    paths = set(_FIELD_SCHEMA_FILES)
    root = ROOT.resolve()

    def include(function):
        if inspect.ismethod(function):
            function = function.__func__
        if not inspect.isfunction(function):
            return
        function = inspect.unwrap(function)
        source = inspect.getsourcefile(function)
        if source is None:
            return
        try:
            path = Path(source).resolve().relative_to(root)
        except ValueError:
            return
        if path.parts[0] == 'livemorebio' and 'tests' not in path.parts:
            paths.add(path.as_posix())

    for family in _FIELD_FAMILIES:
        with monkeypatch.context() as patch:
            service, specs, close = _field_catalog(family, patch, tmp_path / family)
            try:
                for spec in specs:
                    app = services[spec.get('service', service)][0]
                    route = _field_route(app, spec)
                    for function in _field_functions(route, spec):
                        include(function)
            finally:
                close()
    # Inspect real handlers after fixture patches unwind and lazy product
    # imports have completed; their closure must not depend on import order.
    # Include bodyless routes too, so adding a field invalidates their digest.
    for app, _ in services.values():
        for route in _service_routes(app):
            for function in _body_helpers(route.endpoint):
                include(function)
    return paths


def _assert_field_sources_reviewed(services, monkeypatch, tmp_path):
    """Source/schema changes require renewed baseline and field receipt review.

    Complete files include dynamic field and vocabulary definitions. Their
    digests bind this reviewed catalog; they do not replace the coverage audit.
    """
    paths = _field_source_paths(services, monkeypatch, tmp_path)
    assert paths == set(_FIELD_SOURCE_DIGESTS), (
        'Field parser source inventory changed; review catalog coverage: '
        + repr(sorted(paths.symmetric_difference(_FIELD_SOURCE_DIGESTS))))
    changed = [path for path in sorted(paths)
               if hashlib.sha256((ROOT / path).read_bytes()).hexdigest() != _FIELD_SOURCE_DIGESTS[path]]
    assert not changed, 'Field parsers or schemas changed; review baselines and branch receipts: ' + repr(changed)

_FIELD_SOURCE_DIGESTS = {'livemorebio/aegle/capture_time.py': '5532e000b2312cc561c919eeb8a9835d14436ca4e3e4ee5869f1841c89c030d1',
 'livemorebio/aegle/clinical_parameters.py': '9222b4eefc600007b254eb9818161947b830b50ba51ac68ffaffe3de85944615',
 'livemorebio/aegle/evidence_api.py': '21159d7452d38cfc670265ecd77820f6590abf1143c389f4965eb061cb71b1b4',
 'livemorebio/aegle/execution.py': '3af75d019ef7e49942df3270344f5a7b999d5fd79f9e0ff1251a4f0fa5abfeaa',
 'livemorebio/aegle/execution_api.py': 'cfa97bdf0a6748bf7f500e007990733f54d8748952e0289164f6cc8787e436fa',
 'livemorebio/aegle/execution_contract.py': '5459320e5dd8b6df105a72e15661e9643dd7ab046b02a649b0d68c801416772e',
 'livemorebio/aegle/execution_observations.py': '9764d91d5af0cfa25d4d5f39afb013cf88d4544a2340da057db9a1cbbc0791bf',
 'livemorebio/aegle/life_session_api.py': '4a046cf6930c37663cf9eca49e3ff37165e8b17c89157c2b2c5575e8d8692d4e',
 'livemorebio/aegle/model_source.py': '4cee59659bc63312f4cf046717a8b6bdea75c88c543a874b803583fd6506bbc5',
 'livemorebio/aegle/population.py': '5462ee800ddbd6819ad2982048ceebe67be8ea84d1f39bd368fe406409989acf',
 'livemorebio/aegle/profile_sources.py': 'c7b01fa27b6a1ee5ae38c1a9b136332bf5462714192dac26adda76d4a3830fb8',
 'livemorebio/aegle/reference_cohort_api.py': 'feb88e242b2a203609cd1f5b22b35360f308a9fb6f16de29ba06ec160a15d2f3',
 'livemorebio/aegle/reference_cohorts.py': 'e44d52f2ec368bb896726cc729e97e254557ad83772f13e5996dad4cfda97b5e',
 'livemorebio/aegle/research_api.py': 'e15d46d328c04576eeed77b3d2be81a30ad4a8ff0eeec8a1f9f29ce773911986',
 'livemorebio/aegle/runtime.py': 'f80e0a4e556e88b90c3d7a5bbebea8c6da827e1c7c0a1b892a7a35d9475ebdc6',
 'livemorebio/aegle/screen_runs.py': '4e43ed6c918aa898f415b15c20999c129f2e5627b3a59a808da8c0079c055038',
 'livemorebio/aegle/server.py': '5cc4b802f17643c6b76ea56c91737f88250b57ade469b11f81a9edb8db9fc359',
 'livemorebio/aegle/subjects.py': '160a07ad6b64f508cc7c2bbd191b25001bf00281694c20538c006d011b7abf99',
 'livemorebio/aegle/workspace.py': 'f17ab006820a714edd84e221756df0be4a2f8aef21493519a7af1c5f64e0b085',
 'livemorebio/anatomy/_atlas_geometry.py': '44b08f9bf486e8cb959db9a95d22a307c1b61874884d726ce5a85a1ecee56562',
 'livemorebio/anatomy/atlas_reference.py': '22daac32cd43b9eb69eec2034712c4d061e8ef5c81fc4c237350fb5cc113997e',
 'livemorebio/anatomy/meshes.py': 'b15896e908a2e8168613a211ca24888a281f5b5f9c034d0cbfa802cf8f47bf84',
 'livemorebio/bus.py': '6ba7b33baf4f8102258e806a73bfc09bb87f42e7fbb9aa98e60f2813a6a2a39b',
 'livemorebio/cendos/assays.py': 'ae45dba8843f3a5859e16d99ca390977f664d982108497b7c6e89f03902f00ba',
 'livemorebio/cendos/botanical_programs.py': '068edb8f894a180634a08387d4fe7dbd48a5bf82c11098d627a3b2690b3856c0',
 'livemorebio/cendos/counterparts.py': 'd7ac148a9c016e6fe2ecc6e5918779214272116fe9d1bb983b0a82ba4de167e2',
 'livemorebio/cendos/current_source.py': '332b2c6295721794951f5564a3f8f2c9a27839f1a6d374d6e1857a0fdf8bcb78',
 'livemorebio/cendos/insulin_protocol.py': '5a965623bc7491fba80814d98f0aaa1000f4ed9c51746c760160b7389552dfc3',
 'livemorebio/cendos/lobeline_vmat2.py': 'a2f57c643d77dbec42149f88148f21748416bf6fc811baf15be92ee15dd4fa01',
 'livemorebio/cendos/metabolic_protocol.py': '1389886097844062ac58fc1e339e5e61c231630de977b46972a953fbdfb5bb43',
 'livemorebio/cendos/protocol_runs.py': '4fd5d746c800df6500934e84d01e9312e555ddb135b46d3f716f8766999d1bcc',
 'livemorebio/cendos/protocols.py': '57a19fc66e82ed3bd918a16ce1c5e853f1d7f03759e65a1ae100981c5a5ad784',
 'livemorebio/cendos/qualification.py': 'b3a357488aa1343998952f67305538bc2b38b81dedfc2a6f98fedcedc7b0dbae',
 'livemorebio/cendos/service.py': 'a233e5ba2090a237a2eede757e9b95efa28775a98c7345347fd1d4fba2f44b2c',
 'livemorebio/clinical_note_gate.py': '6dbe493e78176ab1d0a102b8ef9f774d1a4f278a801a250448d52f7d4ab3e73c',
 'livemorebio/egress.py': '1fba0afce546e9c18837ec4bb911098aa8ecc6caf9acd6e4c358bb8db10f9cf8',
 'livemorebio/egress_destinations.py': '502d01bbae7626ea934a9689a4f02874bd356c714f85a47aec0abbf1a879e599',
 'livemorebio/engines/drug_targets.py': '3b01ec4e264f7b27aacd81d697cabb3a24afbcbbbe9555773e845f737a9bdf3e',
 'livemorebio/engines/factors.py': '733f8743c3db3bb8468264b6032cad638e83fc629ee7b0baf6e6bffee1438914',
 'livemorebio/engines/hepatic_pk.py': 'fb091e8a85606f27e392524943478bdb2cdf5ed82b016203a3de18dc93d34a44',
 'livemorebio/engines/metabolic/hovorka.py': 'a3f99901eaf558aa7a09ab0d411b8b3ee8936d485da5e66c9d8e3f29e6a7e560',
 'livemorebio/engines/pharmacology.py': '8409e64738f7344786f6bb85dc2e49fa16a97eef005ca2430e39642aec1e2971',
 'livemorebio/engines/stoichiometry.py': '30271f3fef357ec5789422849a415146a3a348ec0187eb37b9fa362f84c91b96',
 'livemorebio/engines/trajectory.py': '139bbc52b0e1a4dfa29928e346e7688abd22e38285cb9718f3d18f338256cc6f',
 'livemorebio/engines/validation.py': '76140738dba650f25d90a59c6cb2f0b49fcf3d6d4976f75e34ade0ab3ea971f3',
 'livemorebio/evidence/canonical.py': '331ef723fa5f2ed2a08f39f454ca4b725ec99da3d33573147fd66857f2446972',
 'livemorebio/evidence/exporter.py': 'e214a8633d08441008e46bc33392b28b5a97d59239507c8561d15dfd4c9741b9',
 'livemorebio/execution_client.py': '5539d8549b95d1aaed0bc0f94ae227b62ea53f818ec19bbebc1b12a2f059d35a',
 'livemorebio/life_patch/execution_source.py': 'c631c3a36c514ced64eeada50f1a0568dd95e857e240bfef3846ddee776ec6fb',
 'livemorebio/life_patch/gateway.py': '93ae91d403b9401981a16fd636aa5cee95e2d0acb4872a405dac5d28e89485a1',
 'livemorebio/life_patch/protocol.py': '911bd45f30633625ff38ba937f225e0569fb9670c17eea49f7d3adc00c57fcc0',
 'livemorebio/life_patch/protocol_v3.py': '029506716b2969c1bd45fdfc788d540c4ece35dffd2ede245c7942454886096c',
 'livemorebio/life_patch/virtual_execution.py': '7912e763a17a373e6cf8f0d28b663e2772db530b8461ac90b808a72bda39574e',
 'livemorebio/life_system/genome.py': 'ff708d3a984277756aebb00e5b8dc82501f5430f55f6cfd30d3333eea972c383',
 'livemorebio/life_system/knowledge.py': '32a2f3445a1cdc9567f8d71487dbfe835f8a3f27f27af0258e68b42a322db99f',
 'livemorebio/life_system/population.py': '71cd103c3914d910830dac9bad5010cf3401a850fd9b52151fea526d83c14f59',
 'livemorebio/life_system/reference/knowledgebase.py': '44bc17205e0a1bed348861b84925db7044f3fb504be48c3bed649192dbb5f7a3',
 'livemorebio/life_system/reference/sources/genecards.py': '56736f86a807e3899cca5d7240ee79c3ab4b21f121075a90eec391ca1cb7034c',
 'livemorebio/life_system/reference/sources/kegg.py': '1e1472b36a1a565c6cc4745e8fbd3eccb02c8d1e85591bb721fd47cb0fbbc614',
 'livemorebio/life_system/reference/sources/licensed_import.py': '3912b2b29dc045a67f4864a61a33e2a07f2b1d8fe569bfa6ee4550ac0c0ae922',
 'livemorebio/life_system/retrieval.py': 'b8ac9d7d805d7e461414202fa1c8964debc8db6d391270970c316cf948d9910e',
 'livemorebio/life_system/seed/anatomy.json': '608d26a51b70c83ee133e13142b0fcf64ed6b77ff69199c5a6e4fddbe2417eec',
 'livemorebio/life_system/seed/diseases.json': 'e9105489dc16ba416025064c6d4e15ddf760264aa85590dc3b3dc8be236a0382',
 'livemorebio/life_system/seed/drugs.json': '56ee2fbc0d45cbb4dd0156951a2c5f7d6fffaea864964bf36b0a4bc53b1a808d',
 'livemorebio/life_system/seed/genes.json': 'acb6ed8bef350640839a12f15e6fa759d2c3d490742e56df08f0e07c3532394e',
 'livemorebio/life_system/seed/gwas.json': '3075e69cbad5cef18cd0069e883426c0a2aa3564e5e4c262df4747c34151cc84',
 'livemorebio/life_system/seed/meta.json': 'd9597b8321ecde6183530fe26592a8740cd7af0d594ba085bfbafbb77d9dd397',
 'livemorebio/life_system/seed/pathways.json': 'e2e4ea93d005aa218825ddf1a1210137db8b549b0c7c78fbbf97a5cfc2c495b8',
 'livemorebio/life_system/seed/structures.json': 'ea1ec2b2b63beb0a799f2e2c65d5813cbc48128873a04a9cfbc86ad43309b572',
 'livemorebio/life_system/service.py': 'c6750814cbd73c96cca356aed23763250c23e3246b081946d3b9aadbdc451d95',
 'livemorebio/life_system/structured_human.py': '3c2193fe63f2f752301820126dbb3f69aa7a594ded33de1f1a753adc90ad237d',
 'livemorebio/life_system/virtual_execution_api.py': '9a09541e1ea94a90b7528b5024108a30f70890f54801d3f8cca13451bac7eb01',
 'livemorebio/molecular_reference.py': '4a9309988ab62a5b479a13dcf00c56b72980d92303dc29e43d2564dcabeca15c',
 'livemorebio/reference_cohort_contract.py': '9dfcfa6d27ad993f70d7cd1b48b63bc87fd38cfae8c9fa8b29d07b50d9a108af',
 'livemorebio/request_body.py': '2387f9ff01ec3cff38069452cec11a47efe91da4deb2f76ce2656f182a6719ec',
 'livemorebio/request_errors.py': 'ae17233f6c603b39b9f8f2c74bd8213c19f7ca00d463be71a0e553c1d88299de',
 'livemorebio/research.py': 'b2f8b4ea65f14d4d8d0aed267cc90c00b2d9b5aaffa179a5c1f78f524a607c51',
 'livemorebio/scientific_sources/catalog.py': '4d30eae3d3177a3bab987eddd0fee5a32503cdcd3d59b851ceffd1ad88d6f445',
 'livemorebio/sdk.py': '89ed2fa442437b7f088203c5812840a212f1980aeed874ed8b8101d5c6903388',
 'livemorebio/security.py': 'beb2edc250e9aa3de9ef3ca3078277819a8ba156ee8176baa089f3f76a9051b4',
 'livemorebio/service_identity.py': '0b3f8a98f01c2e4302bd33fa7ff0e03df8ebf6713b169f09e20d5d00f9a8b27f',
 'livemorebio/service_identity_config.py': 'f21e4686f79c00aca3af6f872ed9c109b558b3bd6da1893254e870245b7335c6',
 'livemorebio/stack_proof.py': '529e5a620837267758a2c1d2d3b4e2db835260ee6472ed46f02ed33597377f9e',
 'livemorebio/stack_transport.py': '8117f80986bb719ea8ed680445d26e862b22f7048e8b3b73bf284b8631648aa1',
 'livemorebio/strict_json.py': '87522902a7463d4ff3f6c68f3371b1f1d3ed2786f6ccd5549e021e166a3395fa'}

_FIELD_FAMILIES = ('cendos', 'core', 'core_get', 'aegle_protocol_read', 'registry', 'patch', 'life', 'research', 'reference', 'execution', 'security')


def _service_routes(app):
    """Include deferred FastAPI routers as well as directly registered routes."""
    from fastapi.routing import APIRoute

    def walk(routes):
        for route in routes:
            if isinstance(route, APIRoute):
                yield route
            elif hasattr(route, 'original_router'):
                yield from walk(route.original_router.routes)
    return list(walk(app.routes))


def _field_catalog(family, monkeypatch, tmp_path):
    import sqlite3

    def forbidden_database(*args, **kwargs):
        raise AssertionError('field sweep must use its in-memory store driver')

    monkeypatch.setattr(sqlite3, 'connect', forbidden_database)
    close = lambda: None
    service = 'aegle'
    if family == 'cendos':
        raw, service = cendos_baselines(monkeypatch), 'cendos'
    elif family == 'core':
        raw = aegle_core_baselines(monkeypatch)
    elif family == 'registry':
        raw = aegle_registry_baselines(monkeypatch)
    elif family == 'patch':
        raw = aegle_patch_baselines(monkeypatch, tmp_path)
    elif family == 'life':
        raw, close = life_baselines(monkeypatch, tmp_path)
        service = 'life'
    elif family == 'core_get':
        raw = aegle_get_baselines(monkeypatch)
    else:
        raw = globals()[family + '_baselines'](monkeypatch)
    if isinstance(raw, dict):
        specs = [dict(spec, path=path) for path, branches in raw.items() for spec in branches]
    else:
        specs = raw
    return service, specs, close


def _field_route(app, spec):
    from starlette.routing import Match
    method = spec.get('method', 'POST')
    for route in _service_routes(app):
        if route.path == spec['path'] and method in route.methods:
            return route
    for route in _service_routes(app):
        if method in route.methods and route.matches({'type': 'http', 'method': method, 'path': spec['path']})[0] == Match.FULL:
            return route
    raise AssertionError('catalog does not name a registered route')


def _field_functions(route, spec):
    import inspect
    functions = list(_body_helpers(route.endpoint))
    for reference in spec.get('helpers', ()):
        function = resolve_helper(reference)
        if inspect.ismethod(function):
            function = function.__func__
        functions.extend(_body_helpers(function))
    return list(dict.fromkeys(functions))


def _field_request(client, spec, body):
    client = spec.get('client', client)
    path = spec['path']
    for name, value in spec.get('path_params', {}).items():
        path = re.sub(r'\{' + re.escape(name) + r'(?::[^}]*)?\}', urllib.parse.quote(str(value), safe=''), path)
    wire = {'json': body} if 'body' in spec else {}
    if 'form' in spec:
        wire = {'data': spec['form']}
    if 'raw_body' in spec:
        wire = {'content': spec['raw_body']}
    return client.request(spec.get('method', 'POST'), path,
        params=spec.get('query'), headers=spec.get('headers'), **wire)


def _normalized_field_spec(app, spec):
    spec = dict(spec)
    route = _field_route(app, spec)
    if spec['path'] != route.path:
        match = route.path_regex.fullmatch(spec['path'])
        spec['path_params'] = dict(match.groupdict()) if match else spec.get('path_params', {})
        spec['path'] = route.path
    return spec, route


def _field_mutations(spec, route):
    import csv
    import io

    mutations = [('body', *path) for path in field_paths(spec.get('body'))]
    mutations += [('form', key) for key in spec.get('form', {})]
    if 'raw_body' in spec:
        mutations.append(('raw_body',))
    for key in spec.get('csv_fields', ()):
        rows = list(csv.DictReader(io.StringIO(spec['body'][key])))
        mutations += [('csv', key, index, column) for index, row in enumerate(rows) for column in row]
    query_names = {parameter.name for parameter in route.dependant.query_params} | set(spec.get('query', {}))
    mutations += [('query', name) for name in sorted(query_names)]
    mutations += [('path', name) for name in route.param_convertors]
    mutations += [('header', name) for name in spec.get('headers', {}) if name.lower() != 'authorization']
    return mutations


@pytest.mark.parametrize('family', _FIELD_FAMILIES)
def test_a_note_in_any_field_of_any_route_reaches_no_outbound_request(
        services, outbound, monkeypatch, tmp_path, family):
    """A valid baseline, then exactly one changed field and a proven consumer.

    Baselines and mutations get fresh in-memory/scratch fixture state. The
    tracer checks the actual selected scalar at a dictionary/list read or
    parser argument, preserving the request's original Python types. A read of
    a same-named sibling or only its enclosing collection cannot count.
    """
    with monkeypatch.context() as patch:
        service, specs, close = _field_catalog(family, patch, tmp_path / 'inventory')
        try:
            paths_by_case = []
            for spec in specs:
                app = services[spec.get('service', service)][0]
                normalized, route = _normalized_field_spec(app, spec)
                paths_by_case.append(_field_mutations(normalized, route))
        finally:
            close()
    failures = []
    for index, paths in enumerate(paths_by_case):
        for mutation, field in enumerate([None, *paths]):
            with monkeypatch.context() as patch:
                service, current, close = _field_catalog(family, patch, tmp_path / f'{index}-{mutation}')
                spec = current[index]
                try:
                    if spec.get('setup'):
                        spec['setup']()
                    app, client = services[spec.get('service', service)]
                    spec, route = _normalized_field_spec(app, spec)
                    functions = _field_functions(route, spec)
                    body = spec.get('body')
                    if field is not None:
                        kind, *position = field
                        if kind == 'body':
                            body = replace_field(body, tuple(position), UNMARKED)
                        elif kind == 'csv':
                            import csv
                            import io
                            key, row, column = position
                            reader = csv.DictReader(io.StringIO(body[key]))
                            rows = list(reader)
                            rows[row][column] = UNMARKED
                            stream = io.StringIO()
                            writer = csv.DictWriter(stream, fieldnames=reader.fieldnames, lineterminator='\n')
                            writer.writeheader()
                            writer.writerows(rows)
                            body = {**body, key: stream.getvalue()}
                        elif kind == 'raw_body':
                            spec['raw_body'] = UNMARKED.encode('utf-8')
                        else:
                            key = {'path': 'path_params', 'query': 'query', 'header': 'headers', 'form': 'form'}[kind]
                            spec[key] = {**spec.get(key, {}), position[0]: UNMARKED}
                    selected = next((part for part in reversed(field or ()) if isinstance(part, str)), '')
                    guards = spec.get('guards', ())
                    guard_codes = [resolve_helper(guard['function']).__code__ for guard in guards]
                    explicit_reads = [resolve_helper(reference) for reference in spec.get('trace_helpers', ())]
                    if spec.get('trace_endpoint'):
                        explicit_reads.append(route.endpoint)
                    with BranchTrace(read_sites(functions, selected, include_excluded=explicit_reads),
                                     marker=UNMARKED, guards=guard_codes) as trace:
                        response = _field_request(client, spec, body)
                    label = (route.path, index, '.'.join(map(str, field or ())))
                    if field is None:
                        if response.status_code != spec['status']:
                            failures.append((*label, 'baseline status', response.status_code))
                        if any(response.json().get(key) != spec[key] for key in ('code', 'error') if key in spec):
                            failures.append((*label, 'baseline refusal branch'))
                        if route.endpoint.__code__ not in trace.calls:
                            failures.append((*label, 'baseline did not enter its handler'))
                    else:
                        reached = trace.reached
                        gate_reference = spec.get('gate')
                        if spec.get('code') == 'CLINICAL_NOTE_NOT_ACCEPTED':
                            gate_reference = 'livemorebio.clinical_note_gate:clinical_note_gate'
                        if gate_reference:
                            gate = resolve_helper(gate_reference)
                            reached = gate.__code__ in trace.calls and response.status_code == spec['status']
                        relay = spec.get('relay')
                        if relay is None and spec.get('forwarded'):
                            records = spec['forwarded']()
                            relay = {'received': lambda: records[-1] if records else None,
                                     'method': spec['forward_method'], 'path': spec['forward_path']}
                        if not reached and relay and field[0] == 'body':
                            received = relay['received']()
                            if (received and received.get('method') == relay['method']
                                    and received.get('path') == relay['path']
                                    and response.status_code == spec['status']):
                                value = received.get('body')
                                try:
                                    for part in field[1:]:
                                        value = value[part]
                                except (KeyError, IndexError, TypeError):
                                    value = None
                                reached = type(value) is str and value == UNMARKED
                        for guard in guards:
                            prefix = ('body', *guard['prefix'])
                            if tuple(field[:len(prefix)]) == prefix:
                                code = resolve_helper(guard['function']).__code__
                                payload = response.json()
                                reached = reached or (guard['result'] in trace.returns.get(code, set())
                                    and response.status_code == guard['status']
                                    and all(payload.get(key) == guard[key] for key in ('code', 'error') if key in guard))
                        if field[0] in {'query', 'path', 'header'} and response.status_code == 422:
                            payload = response.json()
                            reached = reached or (payload.get('code') == 'REQUEST_VALIDATION_FAILED' and any(
                                error.get('loc') == [field[0], field[1]] for error in payload.get('detail', [])))
                        if not reached:
                            failures.append((*label, 'selected field consumer not reached', response.status_code))
                    _clean_records(outbound, f'{family} field mutation')
                finally:
                    close()
    # Only fixed route/field positions are reported; never values or response bodies.
    (tmp_path / 'field-receipts.json').write_text(json.dumps({
        'family': family, 'branches': len(paths_by_case), 'mutations': sum(map(len, paths_by_case)),
        'failures': failures,
    }, indent=2), encoding='utf-8')
    assert not failures, failures
    if family == 'core':
        _assert_field_catalog_covers_every_route(services, monkeypatch, tmp_path / 'coverage')
        _assert_field_sources_reviewed(services, monkeypatch, tmp_path / 'source-review')


def _assert_field_catalog_covers_every_route(services, monkeypatch, tmp_path):
    covered = set()
    for family in _FIELD_FAMILIES:
        with monkeypatch.context() as patch:
            service, specs, close = _field_catalog(family, patch, tmp_path / family)
            try:
                for spec in specs:
                    selected = spec.get('service', service)
                    route = _field_route(services[selected][0], spec)
                    covered.add((selected, spec.get('method', 'POST'), route.path))
            finally:
                close()
    required = {(service, method, route.path)
                for service, (app, _) in services.items() for route in _service_routes(app)
                for method in route.methods if method in {'POST', 'PUT', 'PATCH', 'DELETE'}
                or method == 'GET' and (route.dependant.query_params or route.param_convertors)}
    missing = required - covered
    assert not missing, 'routes without a valid baseline: ' + repr(sorted(missing))



@pytest.mark.parametrize("case", [
    ("aegle", "POST", "/api/trajectory", {"factors": ["{note}"], "years": 1}),
    ("aegle", "POST", "/api/trajectory", {"foods": ["{note}"], "years": 1}),
    ("aegle", "POST", "/api/trajectory", {"drugs": ["{note}"], "years": 1}),
    ("aegle", "POST", "/api/stimulate", {"kind": "factor", "params": {"name": "{note}"}}),
    ("aegle", "POST", "/api/stimulate", {"kind": "food", "params": {"name": "{note}", "grams": 50}}),
    ("aegle", "GET", "/api/resolve?compound={note}", None),
    ("aegle", "GET", "/api/resolve?compound={note}&refresh=true", None),
    ("aegle", "GET", "/api/cendos/compound?name={note}", None),
    ("cendos", "GET", "/compound?name={note}", None),
], ids=["trajectory-factors", "trajectory-foods", "trajectory-drugs", "stimulate-factor", "stimulate-food",
        "resolve", "resolve-refresh", "aegle-compound-relay", "cendos-compound"])
def test_round_two_egress_fields_refuse_a_note_with_no_request(services, outbound, case, monkeypatch):
    """The fields round 2 found sending free text out: a typed 422, no request, no echo."""
    monkeypatch.setenv("USDA_API_KEY", "DEMO_KEY")
    from livemorebio.engines import drug_targets, foods
    for cached in (drug_targets.resolve_drug, drug_targets.resolve_bioactive, foods.resolve_food):
        cached.cache_clear()
    service, method, path, body = case
    _, client = services[service]
    for index, value in enumerate((UNMARKED, NOTE, NOTE.replace("Vandrel", "Vandrel Prime"))):
        filled_path = path.replace("{note}", urllib.parse.quote(value, safe=""))
        filled = None if body is None else json.loads(json.dumps(body).replace("{note}", json.dumps(value)[1:-1]))
        response = client.request(method, filled_path, json=filled)
        assert response.status_code == 422, f"value {index}: status {response.status_code}"
        code = response.json().get("code")
        assert code in {CODE, "CLINICAL_NOTE_NOT_ACCEPTED"}, f"value {index}: not a typed refusal"
        clean = not _carries_note(response.content) and not _carries_note(json.dumps(dict(response.headers)).encode())
        assert clean, f"value {index}: the refusal repeats the note"
    assert not outbound.third_party(), "a request was attempted"


def test_the_technical_lookups_still_answer(services, outbound):
    """Vocabulary terms and identifiers pass the check: the routes reach the (stub) services."""
    _, aegle_client = services["aegle"]
    _, cendos_client = services["cendos"]
    trajectory = aegle_client.post("/api/trajectory", json={
        "foods": ["moringa"], "drugs": ["metformin"], "factors": ["sleep deprivation"], "years": 1})
    assert trajectory.status_code == 200, trajectory.status_code
    assert trajectory.json()["exposure"]["foods"] == ["moringa"]
    assert not outbound.third_party(), "the trajectory looked something up"
    response = cendos_client.get("/compound", params={"name": "metformin"})
    assert response.status_code == 200 and response.json()["resolved"] is False
    reached = [blob for kind, blob in outbound.records if kind == "urllib"]
    assert reached and b"pubchem.ncbi.nlm.nih.gov" in reached[-1] and b"metformin" in reached[-1]
