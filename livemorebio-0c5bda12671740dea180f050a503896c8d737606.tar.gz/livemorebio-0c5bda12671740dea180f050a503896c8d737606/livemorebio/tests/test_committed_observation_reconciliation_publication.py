"""Authored ASGI publication boundaries, not registry or physiological evidence.

The real source authority and non-background manager are retained. Registry
results, numerical candidates and cleanup ownership are technical stand-ins.
"""
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass
import gc
import json
from types import SimpleNamespace
from uuid import UUID
import weakref

import pytest

from livemorebio.tests.test_clinical_availability_api import client  # noqa: F401
from livemorebio.tests.test_closed_manager_source_publication import NoIOStore, OWNER_ID


class AuthoredState(dict):
    pass


class AuthoredActions(list):
    pass


@dataclass(frozen=True)
class AuthoredPrepared:
    request_id: str
    _record: dict
    _active: dict | None
    kind: str = "select_observations"

    @property
    def record(self):
        return deepcopy(self._record)

    @property
    def active_before(self):
        return deepcopy(self._active)


def authored_record(suffix, *, source="REAL_HUMAN", version=2, active=True):
    return {"schema": "livemore.subject.v2", "twin_id": "twin-authored-" + suffix,
        "subject_id": "pseudonym-authored-" + suffix,
        "display_label": "Authored selection boundary, not a participant",
        "source_class": source, "version": version,
        "lifecycle": "ACTIVE" if active else "DATA_ADMITTED",
        "selection_mode": "model" if source == "SYNTHETIC" else "observations_only",
        "observations": {}, "model_binding": None}


@pytest.fixture
def selection_boundary(client, monkeypatch):
    from livemorebio.aegle import clinical_views, execution_api, server
    from livemorebio.aegle.execution import DENY_ALL, ExecutionManager
    from livemorebio.aegle.execution_contract import ExecutionError
    from livemorebio.aegle.model_contexts import ModelContextError, model_availability
    from livemorebio.aegle.model_source import ModelSourceAuthority
    from livemorebio.aegle.observation_state import ObservationState
    from livemorebio.aegle.subjects import CheckedActiveSelection, _transition_error

    t = SimpleNamespace(client=client, server=server, calls=[], operations=[], stack=[],
        frames=[], snapshots=[], finalizers=[], store_calls=[], sequence=0,
        target=authored_record("target", active=False),
        restored=authored_record("restored", version=3),
        raw_evidence=("AUTHORED_UNCHANGED_ROW", "AUTHORED_POINTER_TIMESTAMP", "AUTHORED_AUTHORITY"))

    def locks():
        return (authority._lock._is_owned(), execution_api._creation_lock._is_owned(),
                manager._lock._is_owned(), server._initialization_lock._is_owned())

    def unlocked():
        assert locks() == (False, False, False, False)

    def current():
        assert t.stack, "Unexpected work outside the authored request"
        return t.stack[-1]

    def event(name):
        op = current()
        op.calls.append(name)
        t.calls.append((op.name, name))

    def fire(op, name):
        callback = getattr(op, name)
        setattr(op, name, None)
        if callback is not None:
            unlocked()
            callback()

    def original(op):
        value = server._state
        assert id(value) == op.old_ids["state"]
        assert id(value["tw"]) == op.old_ids["tw"]
        assert id(value["observation_state"]) == op.old_ids["observed"]
        assert id(server._workspace_actions) == op.old_ids["actions"]
        assert value["subject"] == op.old_values["subject"]
        assert value["model_availability"] == op.old_values["availability"]
        assert value["observation_state"].state() == op.old_values["observations"]
        assert list(server._workspace_actions) == op.old_values["actions"]

    def published(op):
        if op.outcome == "unknown":
            original(op)
            assert authority.permitted_generation is manager._permitted_generation is DENY_ALL
            return
        assert authority.generation == manager._permitted_generation
        assert authority.generation != op.previous_generation
        state = server._state
        assert id(state) != op.old_ids["state"] and state["initialized"] is True
        assert state["subject"] == (real_summary(op.record) if op.record is not None else None)
        assert id(state["observation_state"]) != op.old_ids["observed"]
        assert state["observation_state"].observations == {}
        assert id(server._workspace_actions) != op.old_ids["actions"] and server._workspace_actions == []
        expected = model_availability(op.record, source_generation=authority.generation)
        if op.factory_error == "context":
            expected.update(state="UNAVAILABLE", reason_code="MODEL_CONTEXT_UNSUPPORTED",
                            selection_mode="observations_only", preparation_available=False)
        assert state["model_availability"] == expected
        if expected["state"] == "UNAVAILABLE":
            assert state["tw"] is None
        else:
            assert op.candidate_refs and state["tw"] is op.candidate_refs[-1]()
        op.confirmed_generation = authority.generation

    @contextmanager
    def fence_guard():
        with server._model_fence_guard():
            frame = object()
            t.frames.append(frame)
            try:
                yield
            finally:
                if t.stack:
                    op = current()
                    if op.final_frame is frame:
                        assert locks() == (True, True, True, False)
                        published(op)
                        event("guard-exit")
                assert t.frames.pop() is frame

    authority = ModelSourceAuthority(server._invalidate_model_source,
        fence=server._assign_model_fence, fence_guard=fence_guard)
    generation = authority.generation
    store = NoIOStore(t.store_calls)
    manager = ExecutionManager(store, adapter_registry={}, run_background=False,
                               permitted_generation=generation)
    monkeypatch.setattr(server, "_model_source_authority", authority)
    monkeypatch.setattr(server, "_execution_manager_instance", manager)
    real_guard = authority.commit_guard

    class OldModel:
        def state(self):
            pytest.fail("Selection read the prior numerical model")

    real_summary = server._subject_summary
    old_subject = real_summary(authored_record("prior", source="SYNTHETIC"))
    initial = AuthoredState(tw=OldModel(), subject=old_subject, initialized=True,
        observation_state=ObservationState(),
        model_availability=model_availability(old_subject, source_generation=generation))
    initial["observation_state"].observations["authored-prior-observation"] = {"data_class": "AUTHORED_TEST_ONLY"}
    actions = AuthoredActions([{"kind": "AUTHORED_PRIOR_ACTION"}])
    monkeypatch.setattr(server, "_state", initial)
    monkeypatch.setattr(server, "_workspace_actions", actions)

    def make_op(kind="observations", **options):
        record = ({**deepcopy(t.target), "version": t.target["version"] + 1,
                   "lifecycle": "ACTIVE", "selection_mode": "observations_only"}
                  if kind == "observations" else deepcopy(t.restored))
        op = SimpleNamespace(name="request-" + str(len(t.operations) + 1), kind=kind,
            calls=[], request_id=None, prepared=None, captured=None, final_frame=None,
            record=record, active_before=deepcopy(server._state["subject"]),
            outcome="COMMITTED", capture_error=None, confirm_error=None,
            factory_error=None, shape="valid", metadata_fault=False,
            candidate_refs=[], observation_refs=[], projection_values=[],
            before_final=None, during_preparation=None, after_guard=None,
            after_cleanup=None, before_publish=None, expected_version=t.target["version"],
            old_ids=None, old_values=None, previous_generation=None,
            confirmed_generation=None, read_evidence=None)
        for key, value in options.items():
            assert hasattr(op, key), key
            setattr(op, key, value)
        t.operations.append(op)
        return op

    def remember_before(op):
        state = server._state
        op.previous_generation = authority.permitted_generation
        op.old_ids = {"state": id(state), "tw": id(state["tw"]),
            "observed": id(state["observation_state"]), "actions": id(server._workspace_actions)}
        op.old_values = {"subject": deepcopy(state["subject"]),
            "availability": deepcopy(state["model_availability"]),
            "observations": deepcopy(state["observation_state"].state()),
            "actions": deepcopy(list(server._workspace_actions))}

    def request(op=None, *, body=None, query="", authenticated=True):
        op = op or make_op()
        remember_before(op)
        path = (f"/api/twins/{t.target['twin_id']}/select-observations"
                if op.kind == "observations" else "/api/twins/reconcile-selection")
        payload = ({"expected_version": op.expected_version} if op.kind == "observations" else {}) if body is None else body
        t.stack.append(op)
        try:
            headers = {} if authenticated else {"Authorization": ""}
            response = client.post(path + query, json=payload, headers=headers)
        finally:
            assert t.stack.pop() is op
        return response

    def allocate_uuid():
        t.sequence += 1
        value = UUID(int=t.sequence)
        if t.stack and current().request_id is None:
            current().request_id = str(value)
        return value

    monkeypatch.setattr(server, "uuid4", allocate_uuid)

    def raise_capture(op):
        if op.capture_error == "version":
            raise _transition_error("TWIN_VERSION_CONFLICT")
        if op.capture_error == "storage":
            raise OSError("PRIVATE_CAPTURE_STORAGE")
        if op.capture_error == "uncertain":
            raise _transition_error("SELECTION_COMMIT_UNCONFIRMED")

    class Registry:
        def prepare_observation_selection(self, twin_id, *, expected_version, request_id):
            op = current()
            assert op.kind == "observations" and op.prepared is None
            assert locks() == (True, False, False, False)
            assert authority.generation == op.previous_generation
            assert twin_id == t.target["twin_id"] and expected_version == op.expected_version
            assert request_id == op.request_id and str(UUID(request_id)) == request_id
            event("prepare")
            raise_capture(op)
            record = deepcopy(op.record)
            if op.metadata_fault:
                record["authored_wire_only"] = object()
            op.prepared = AuthoredPrepared(request_id, record, deepcopy(op.active_before))
            return op.prepared

        def commit_prepared_transition(self, prepared):
            op = current()
            assert locks() == (True, True, True, False)
            assert prepared is op.prepared and prepared.request_id == op.request_id
            assert op.kind == "observations" and "commit" not in op.calls
            assert authority.generation == op.previous_generation
            original(op)
            assert "project-modeless" in op.calls and "wire-serialized" in op.calls
            event("commit")
            if op.outcome == "rollback":
                raise _transition_error("TWIN_VERSION_CONFLICT")
            op.final_frame = t.frames[-1]
            if op.outcome == "unknown":
                raise _transition_error("SELECTION_COMMIT_UNCONFIRMED")
            return "COMMITTED_CLEANUP_UNCONFIRMED" if op.outcome == "committed-close" else "COMMITTED"

        def audited_active_twin(self, *, action, request_id, _checked_snapshot):
            op = current()
            assert op.kind == "reconcile" and op.captured is None
            assert locks() == (True, False, False, False)
            assert authority.permitted_generation is DENY_ALL
            assert action == "reconcile_selection" and _checked_snapshot is True
            assert request_id == op.request_id
            event("capture")
            raise_capture(op)
            op.read_evidence = t.raw_evidence
            identifier = op.record["twin_id"] if op.record else None
            op.captured = CheckedActiveSelection("AUTHORED_STORE", "AUTHORED_AUTHORITY", request_id,
                (), ("active_twin_id", identifier, "AUTHORED_TIMESTAMP") if identifier else None,
                (identifier,) if identifier else (), json.dumps(op.record, allow_nan=False).encode())
            return op.captured

        def confirm_active_selection(self, *, expected_record, request_id, _expected_snapshot):
            op = current()
            assert op.kind == "reconcile" and "confirm" not in op.calls
            assert locks() == (True, True, True, False)
            assert authority.permitted_generation is DENY_ALL
            assert expected_record == op.record and request_id == op.request_id
            assert _expected_snapshot is op.captured and op.read_evidence is t.raw_evidence
            original(op)
            assert "wire-serialized" in op.calls
            assert "project-modeless" in op.calls or "candidate-state" in op.calls
            event("confirm")
            if op.confirm_error == "conflict":
                from livemorebio.aegle.subjects import SubjectRegistryError
                raise SubjectRegistryError("SELECTION_RECONCILIATION_CONFLICT", "Authored exact checked conflict")
            if op.confirm_error == "storage":
                raise OSError("PRIVATE_TERMINAL_STORAGE")
            if op.confirm_error == "uncertain":
                raise _transition_error("SELECTION_COMMIT_UNCONFIRMED")
            op.final_frame = t.frames[-1]

        def build_twin(self, record):
            op = current()
            assert op.kind == "reconcile" and record == op.record and record is not None
            unlocked()
            event("build-record")
            return new_candidate(op)

        def forbidden(self, *args, **kwargs):
            pytest.fail("Legacy/clinical registry operation reached instead of the checked prepared contract")

        get_twin = select_observations = activate_twin = clear_active_selection = forbidden

    registry = Registry()

    def getter():
        unlocked()
        event("getter")
        return registry

    monkeypatch.setattr(server, "_subject_registry", getter)

    @contextmanager
    def observed_guard():
        op = current()
        fire(op, "before_final")
        with real_guard():
            yield
        if "guard-exit" in op.calls:
            fire(op, "after_guard")

    monkeypatch.setattr(authority, "commit_guard", observed_guard)
    original_assign = manager.set_source_generation

    def assign(value):
        assert locks() == (True, True, True, False)
        return original_assign(value)

    monkeypatch.setattr(manager, "set_source_generation", assign)
    original_invalidate = manager.invalidate_source

    def invalidate(old_generation, reason):
        op = current()
        unlocked()
        assert op.kind == "observations", "Reconciliation changed prior execution ownership"
        assert old_generation == op.previous_generation and "guard-exit" in op.calls
        assert "invalidate" not in op.calls
        event("invalidate")
        if op.outcome == "invalidate-failure":
            raise ExecutionError("EXECUTION_STORAGE")
        result = original_invalidate(old_generation, reason)
        fire(op, "after_cleanup")
        return result

    monkeypatch.setattr(manager, "invalidate_source", invalidate)

    def watch(value, label):
        weakref.finalize(value, lambda: t.finalizers.append((label, locks())))
        return weakref.ref(value)

    def project_fault(value, shape):
        if shape == "none":
            return None
        if shape == "list":
            return []
        if shape == "missing":
            value.pop("profile_params")
        elif shape == "params-null":
            value["profile_params"] = None
        elif shape == "params-list":
            value["profile_params"] = []
        elif shape == "params-nonnull":
            value["profile_params"] = {"AUTHORED_INVALID_NUMERICS": 1}
        elif shape == "availability":
            value["model_availability"]["state"] = "READY"
        elif shape == "nonfinite":
            value["authored_non_parameter_field"] = float("nan")
        elif shape == "opaque":
            value["authored_non_parameter_field"] = object()
        else:
            assert shape == "valid", shape
        return value

    class Candidate:
        def __init__(self, op):
            self.op = op

        def state(self):
            op = self.op
            assert current() is op
            unlocked()
            assert "capture" in op.calls and "confirm" not in op.calls
            event("candidate-state")
            value = project_fault({"profile": "AUTHORED_READY_REFERENCE",
                "profile_params": {"authored_candidate": op.name}, "observations": {}, "applied": []}, op.shape)
            op.projection_values.append(deepcopy(value))
            return value

    def new_candidate(op):
        unlocked()
        assert "capture" in op.calls and "confirm" not in op.calls
        fire(op, "during_preparation")
        if op.factory_error == "context":
            raise ModelContextError("MODEL_CONTEXT_UNSUPPORTED")
        if op.factory_error == "storage":
            raise RuntimeError("PRIVATE_REFERENCE_FACTORY")
        value = Candidate(op)
        op.candidate_refs.append(watch(value, op.name + ":candidate"))
        return value

    def reference(base):
        op = current()
        unlocked()
        assert op.kind == "reconcile" and op.record is None and base == "healthy"
        event("build-reference")
        return new_candidate(op)

    monkeypatch.setattr(server, "AegleTwin", reference)

    def fresh_observations():
        op = current()
        unlocked()
        assert "prepare" in op.calls or "capture" in op.calls
        assert "commit" not in op.calls and "confirm" not in op.calls
        event("fresh-observations")
        value = ObservationState()
        op.observation_refs.append(watch(value, op.name + ":observations"))
        return value

    monkeypatch.setattr(server, "ObservationState", fresh_observations)
    actual_unavailable = clinical_views.unavailable_state

    def unavailable(availability, observed):
        op = current()
        unlocked()
        assert "prepare" in op.calls or "capture" in op.calls
        assert "commit" not in op.calls and "confirm" not in op.calls
        assert availability["state"] == "UNAVAILABLE"
        assert op.record is not None and availability["twin_id"] == op.record["twin_id"]
        assert availability["twin_version"] == op.record["version"]
        assert observed.observations == {} and observed is op.observation_refs[-1]()
        event("project-modeless")
        fire(op, "during_preparation")
        value = project_fault(actual_unavailable(availability, observed), op.shape)
        op.projection_values.append(deepcopy(value))
        return value

    monkeypatch.setattr(clinical_views, "unavailable_state", unavailable)

    def summary(record):
        op = current()
        unlocked()
        value = real_summary(record)
        if op.kind == "reconcile" and op.metadata_fault:
            value["authored_wire_only"] = object()
        return value

    monkeypatch.setattr(server, "_subject_summary", summary)
    actual_response = server.JSONResponse

    class ObservedResponse(actual_response):
        def render(self, content):
            if isinstance(content, dict) and (content.get("selection_status") == "CONFIRMED"
                    or "twin_id" in content and "model_availability" in content):
                op = current()
                unlocked()
                assert "commit" not in op.calls and "confirm" not in op.calls
                event("wire-serialized")
            return super().render(content)

    monkeypatch.setattr(server, "JSONResponse", ObservedResponse)

    def snapshot(st):
        op = current()
        unlocked()
        assert "guard-exit" in op.calls and op.outcome != "unknown"
        fire(op, "before_publish")
        assert type(st) is dict and "profile_params" in st
        json.dumps(st, allow_nan=False)
        assert st["model_availability"]["source_generation"] == op.confirmed_generation
        t.snapshots.append((op.name, deepcopy(st)))
        event("snapshot")

    monkeypatch.setattr(server, "_snapshot_twin", snapshot)

    def deny_source():
        with real_guard():
            authority.install_generation(DENY_ALL)

    def use_modeless_old():
        value = server._state
        value["tw"] = None
        value["subject"] = real_summary(authored_record("prior-modeless"))
        value["model_availability"] = model_availability(value["subject"], source_generation=generation)

    def install_winner(name="authored-later-generation"):
        unlocked()
        winner = AuthoredState(tw=OldModel(), subject=real_summary(authored_record("winner", source="SYNTHETIC")),
            initialized=True, observation_state=ObservationState())
        winner["observation_state"].observations["authored-winner-marker"] = {"data_class": "AUTHORED_TEST_ONLY"}
        winner_actions = AuthoredActions([{"kind": "AUTHORED_WINNER_ACTION"}])
        winner["model_availability"] = model_availability(winner["subject"], source_generation=name)
        retained = (server._state, server._workspace_actions)
        with real_guard():
            authority.install_generation(name)
            server._state = winner
            server._workspace_actions = winner_actions
        del retained
        return winner, winner_actions

    t.authority, t.manager, t.store, t.generation = authority, manager, store, generation
    t.initial, t.initial_actions, t.registry = initial, actions, registry
    t.make_op, t.request, t.original, t.published = make_op, request, original, published
    t.locks, t.unlocked, t.real_guard = locks, unlocked, real_guard
    t.deny_source, t.modeless_old, t.install_winner = deny_source, use_modeless_old, install_winner
    t.watch, t.real_summary = watch, real_summary
    yield t
    assert manager._adapters == {} and manager._closing == set()
    client.close()


def response_context(op, response):
    assert response.headers["X-Request-ID"] == op.request_id
    assert str(UUID(op.request_id)) == op.request_id
    assert response.headers["Cache-Control"] == "no-store"
    assert "PRIVATE" not in response.text


def rejected(t, op, response, *, status=503, code="REGISTRY_STORAGE_UNAVAILABLE"):
    assert response.status_code == status and response.json()["code"] == code
    response_context(op, response)
    assert "commit" not in op.calls and "confirm" not in op.calls
    assert "invalidate" not in op.calls and "snapshot" not in op.calls


def successful(t, op, response, *, status=200):
    assert response.status_code == status
    response_context(op, response)
    t.published(op)
    assert op.calls.count("guard-exit") == op.calls.count("snapshot") == 1
    value = next(value for name, value in t.snapshots if name == op.name)
    assert value["model_availability"] == t.server._state["model_availability"]
    if value["model_availability"]["state"] == "UNAVAILABLE":
        from livemorebio.tests.test_clinical_availability_api import NULL_FIELDS
        assert all(value[field] is None for field in NULL_FIELDS)
        assert value["observations"] == {} and value["applied"] == []
        assert value["active_execution"] is None
        assert not value.get("biological_time", {}).get("axes")
    else:
        assert value["profile_params"] == {"authored_candidate": op.name}
    if op.kind == "observations":
        assert op.calls.count("prepare") == op.calls.count("commit") == op.calls.count("invalidate") == 1
        if status == 200:
            assert response.json()["twin_id"] == op.record["twin_id"]
            assert response.json()["version"] == op.record["version"]
            assert response.json()["lifecycle"] == "ACTIVE"
            assert response.json()["model_availability"] == value["model_availability"]
        else:
            assert response.json()["code"] == "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
    else:
        assert op.calls.count("capture") == op.calls.count("confirm") == 1
        assert "invalidate" not in op.calls
        assert set(response.json()) == {"selection_status", "subject", "model_availability", "prior_execution_cleanup"}
        assert response.json()["selection_status"] == "CONFIRMED"
        assert response.json()["prior_execution_cleanup"] == "INSPECT_EXISTING_STATUS"
        assert response.json()["subject"] == t.server._state["subject"]


def reconcile_op(t, *, mode="modeless", **options):
    t.deny_source()
    record = (None if mode == "absent" else authored_record("restored", version=3,
        source="SYNTHETIC" if mode == "ready" else "REAL_HUMAN"))
    return t.make_op("reconcile", record=record, **options)


# A: eight initial admission cases.
@pytest.mark.parametrize("kind", ["observations", "reconcile"])
def test_selection_auth_precedes_dependency_and_capture(selection_boundary, kind):
    t = selection_boundary
    op = t.make_op(kind)
    result = t.request(op, authenticated=False)
    assert result.status_code == 401 and not op.calls and op.request_id is None


@pytest.mark.parametrize("offset", [0, 1], ids=["MAX", "MAX-plus-one"])
def test_observations_rejects_nonincrementable_request_version(selection_boundary, offset):
    from livemorebio.strict_json import MAX_SAFE_INTEGER
    t = selection_boundary
    op = t.make_op(expected_version=MAX_SAFE_INTEGER + offset)
    rejected(t, op, t.request(op), status=422, code="INVALID_TWIN_DATA")
    assert not op.calls


def test_observations_denied_source_rejects_before_preparation(selection_boundary):
    from livemorebio.aegle.execution import DENY_ALL
    t = selection_boundary
    t.deny_source()
    op = t.make_op()
    rejected(t, op, t.request(op), code="SELECTION_COMMIT_UNCONFIRMED")
    assert "prepare" not in op.calls
    t.original(op)
    assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL


@pytest.mark.parametrize("body,query", [({"expected_version": 2}, ""), ({}, "?action=inspect")])
def test_reconcile_rejects_payload_or_query_before_capture(selection_boundary, body, query):
    t = selection_boundary
    op = reconcile_op(t)
    rejected(t, op, t.request(op, body=body, query=query), status=422, code="INVALID_TWIN_DATA")
    assert not op.calls


def test_reconcile_confirmed_source_rejects_before_capture(selection_boundary):
    t = selection_boundary
    op = t.make_op("reconcile")
    rejected(t, op, t.request(op), status=409, code="SELECTION_RECONCILIATION_CONFLICT")
    assert not op.calls and t.authority.generation == t.generation


# B: fifteen observation capture/identity cases.
@pytest.mark.parametrize("error,status,code", [
    ("version", 409, "TWIN_VERSION_CONFLICT"), ("storage", 503, "REGISTRY_STORAGE_UNAVAILABLE"),
    ("uncertain", 503, "SELECTION_COMMIT_UNCONFIRMED")])
def test_observations_prepare_error_preserves_old_authority(selection_boundary, error, status, code):
    t = selection_boundary
    op = t.make_op(capture_error=error)
    rejected(t, op, t.request(op), status=status, code=code)
    assert op.calls == ["getter", "prepare"]
    t.original(op)
    assert t.authority.generation == t.manager._permitted_generation == t.generation


@pytest.mark.parametrize("phase", ["capture", "final"])
@pytest.mark.parametrize("field", ["twin_id", "subject_id", "source_class", "version"])
def test_observations_active_identity_matches_at_both_guards(selection_boundary, phase, field):
    t = selection_boundary
    op = t.make_op()
    mismatch = 17 if field == "version" else "AUTHORED_DIFFERENT"
    if phase == "capture":
        op.active_before[field] = mismatch
    else:
        def change():
            with t.authority.observation():
                t.server._state["subject"][field] = mismatch
        op.before_final = change
    rejected(t, op, t.request(op), status=409, code="MODEL_SOURCE_CHANGED")
    assert op.calls.count("prepare") == 1
    assert t.authority.generation == t.manager._permitted_generation == t.generation
    if phase == "capture":
        assert "project-modeless" not in op.calls
        t.original(op)
    else:
        assert t.server._state["subject"][field] == mismatch and "project-modeless" in op.calls


@pytest.mark.parametrize("absence", ["both", "memory-only", "registry-only"])
def test_observations_active_absence_agreement(selection_boundary, absence):
    t = selection_boundary
    saved = deepcopy(t.server._state["subject"])
    if absence in {"both", "registry-only"}:
        t.server._state["subject"] = None
        t.server._state["model_availability"].update(selection_mode="reference_preview", twin_id=None, twin_version=0)
    op = t.make_op(active_before=saved if absence == "registry-only" else None)
    result = t.request(op)
    if absence == "both":
        successful(t, op, result)
    else:
        rejected(t, op, result, status=409, code="MODEL_SOURCE_CHANGED")
        assert "project-modeless" not in op.calls
        t.original(op)


def test_observations_later_generation_blocks_final_commit(selection_boundary):
    t = selection_boundary
    op = t.make_op()
    def change():
        with t.real_guard():
            t.authority.install_generation("authored-newer-generation-same-subject")
    op.during_preparation = change
    rejected(t, op, t.request(op), status=409, code="MODEL_SOURCE_CHANGED")
    assert t.authority.generation == t.manager._permitted_generation == "authored-newer-generation-same-subject"
    t.original(op)


# C: twenty-four observation committed-publication cases.
@pytest.mark.parametrize("old_mode", ["ready", "modeless"])
@pytest.mark.parametrize("outcome", ["COMMITTED", "committed-close", "rollback", "unknown", "invalidate-failure"])
def test_observations_outcome_publication_and_cleanup(selection_boundary, old_mode, outcome):
    from livemorebio.aegle.execution import DENY_ALL
    t = selection_boundary
    if old_mode == "modeless":
        t.modeless_old()
    op = t.make_op(outcome=outcome)
    result = t.request(op)
    if outcome == "rollback":
        assert result.status_code == 409 and result.json()["code"] == "TWIN_VERSION_CONFLICT"
        response_context(op, result)
        assert op.calls.count("commit") == 1 and "invalidate" not in op.calls and not t.snapshots
        t.original(op)
        assert t.authority.generation == t.manager._permitted_generation == t.generation
    elif outcome == "unknown":
        assert result.status_code == 503 and result.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
        response_context(op, result)
        t.original(op)
        assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL
        assert op.calls.count("commit") == op.calls.count("invalidate") == 1 and not t.snapshots
    else:
        status = 200 if outcome == "COMMITTED" else 503
        if status == 503:
            assert result.json()["code"] == "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
        successful(t, op, result, status=status)


@pytest.mark.parametrize("outcome", ["COMMITTED", "rollback", "unknown"])
def test_observations_closed_manager_keeps_owned_cleanup(selection_boundary, outcome):
    from livemorebio.aegle import execution_api
    from livemorebio.aegle.execution import DENY_ALL
    from livemorebio.aegle.execution_contract import ExecutionError
    t = selection_boundary
    t.manager._owners[OWNER_ID] = t.store.owner
    with pytest.raises(ExecutionError):
        execution_api.shutdown_execution_manager()
    prior = tuple(t.store_calls)
    op = t.make_op(outcome=outcome)
    result = t.request(op)
    response_context(op, result)
    assert result.status_code == (409 if outcome == "rollback" else 503)
    assert t.manager._closed and t.server._execution_manager_instance is t.manager
    assert t.manager._owners == {OWNER_ID: t.store.owner}
    assert t.manager._cleanup_pending == {OWNER_ID} and tuple(t.store_calls) == prior
    if outcome == "COMMITTED":
        assert result.json()["code"] == "SELECTION_COMMITTED_CLEANUP_UNCONFIRMED"
        successful(t, op, result, status=503)
    else:
        t.original(op)
        assert not t.snapshots
        if outcome == "unknown":
            assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL
            assert op.calls.count("invalidate") == 1
        else:
            assert t.authority.generation == t.generation and "invalidate" not in op.calls


@pytest.mark.parametrize("shape", ["none", "missing", "params-nonnull", "availability", "nonfinite", "opaque"])
def test_observations_bad_own_projection_never_commits(selection_boundary, shape):
    t = selection_boundary
    op = t.make_op(shape=shape)
    rejected(t, op, t.request(op))
    assert op.calls.count("project-modeless") == 1
    t.original(op)
    assert t.authority.generation == t.generation


def test_observations_publishes_own_snapshot_after_later_winner(selection_boundary):
    t = selection_boundary
    winner = []
    op = t.make_op(after_cleanup=lambda: winner.extend(t.install_winner()))
    result = t.request(op)
    assert result.status_code == 200
    response_context(op, result)
    assert t.server._state is winner[0] and t.server._workspace_actions is winner[1]
    assert t.authority.generation == "authored-later-generation"
    assert len(t.snapshots) == 1
    value = t.snapshots[0][1]
    assert value["profile_params"] is None and value["observations"] == {} and value["applied"] == []
    assert value["model_availability"] == result.json()["model_availability"]
    assert value["model_availability"]["source_generation"] != t.authority.generation


def watched_initial(t):
    refs = {key: t.watch(value, "old:" + key) for key, value in (
        ("tw", t.server._state["tw"]), ("observations", t.server._state["observation_state"]),
        ("actions", t.server._workspace_actions)) if value is not None}
    # The setup closure retains its original state/actions. Replace the current
    # holders with new independent objects so these exact weak probes are real.
    return refs


def fresh_watched_initial(t):
    from livemorebio.aegle.observation_state import ObservationState
    class Holder:
        def state(self):
            pytest.fail("Read old holder during selection")
    value = AuthoredState(t.server._state)
    value["tw"] = Holder()
    value["observation_state"] = ObservationState()
    value["observation_state"].observations["authored-retired"] = {"data_class": "AUTHORED_TEST_ONLY"}
    t.server._state = value
    t.server._workspace_actions = AuthoredActions([{"kind": "AUTHORED_RETIRED_ACTION"}])
    refs = watched_initial(t)
    refs["state"] = t.watch(value, "old:state")
    return refs


@pytest.mark.parametrize("outcome", ["success", "rollback", "unknown", "late-generation"])
def test_observations_holders_release_outside_guards(selection_boundary, outcome):
    t = selection_boundary
    refs = fresh_watched_initial(t)
    op = t.make_op(outcome="COMMITTED" if outcome in {"success", "late-generation"} else outcome)
    if outcome == "late-generation":
        def change():
            with t.real_guard():
                t.authority.install_generation("authored-retirement-late-generation")
        op.before_final = change
    result = t.request(op)
    assert result.status_code == {"success": 200, "rollback": 409, "unknown": 503, "late-generation": 409}[outcome]
    response_context(op, result)
    gc.collect()
    if outcome == "success":
        assert all(ref() is None for ref in refs.values())
        assert set(label for label, _ in t.finalizers if label.startswith("old:")) == {"old:tw", "old:observations", "old:actions", "old:state"}
    else:
        assert all(ref() is not None for ref in refs.values())
        assert op.observation_refs and all(ref() is None for ref in op.observation_refs)
    assert t.finalizers and all(state == (False, False, False, False) for _, state in t.finalizers)


# D: seventeen checked-capture and preparation cases.
@pytest.mark.parametrize("mode", ["ready", "modeless", "absent"])
def test_reconcile_checked_record_prepares_exact_supported_mode(selection_boundary, mode):
    t = selection_boundary
    op = reconcile_op(t, mode=mode)
    successful(t, op, t.request(op))
    assert ("build-record" in op.calls) is (mode == "ready")
    assert ("build-reference" in op.calls) is (mode == "absent")
    assert ("project-modeless" in op.calls) is (mode == "modeless")
    assert op.read_evidence is t.raw_evidence


def test_reconcile_stored_max_is_read_only(selection_boundary):
    from livemorebio.strict_json import MAX_SAFE_INTEGER
    t = selection_boundary
    op = reconcile_op(t)
    op.record["version"] = MAX_SAFE_INTEGER
    before = deepcopy(op.record)
    result = t.request(op)
    successful(t, op, result)
    assert op.record == before and result.json()["subject"]["version"] == MAX_SAFE_INTEGER
    assert result.json()["model_availability"]["twin_version"] == MAX_SAFE_INTEGER


def test_reconcile_actual_record_typed_context_rejection_is_modeless(selection_boundary):
    t = selection_boundary
    op = reconcile_op(t, mode="ready", factory_error="context")
    result = t.request(op)
    successful(t, op, result)
    assert result.json()["model_availability"]["reason_code"] == "MODEL_CONTEXT_UNSUPPORTED"
    assert result.json()["subject"]["twin_id"] == op.record["twin_id"]
    assert "build-reference" not in op.calls and not op.candidate_refs


def test_reconcile_true_absence_constructor_failure_is_operational(selection_boundary):
    from livemorebio.aegle.execution import DENY_ALL
    t = selection_boundary
    op = reconcile_op(t, mode="absent", factory_error="storage")
    rejected(t, op, t.request(op))
    assert op.calls.count("build-reference") == 1 and "project-modeless" not in op.calls
    t.original(op)
    assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL


@pytest.mark.parametrize("error", ["storage", "uncertain"])
def test_reconcile_checked_capture_error_keeps_denial(selection_boundary, error):
    from livemorebio.aegle.execution import DENY_ALL
    t = selection_boundary
    op = reconcile_op(t, capture_error=error)
    response = t.request(op)
    rejected(t, op, response, code="SELECTION_COMMIT_UNCONFIRMED" if error == "uncertain" else "REGISTRY_STORAGE_UNAVAILABLE")
    assert op.calls == ["getter", "capture"]
    t.original(op)
    assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL


@pytest.mark.parametrize("mode,shape", [("ready", shape) for shape in
    ("none", "list", "missing", "params-null", "params-list", "nonfinite", "opaque")]
    + [("modeless", "params-nonnull"), ("modeless", "opaque")])
def test_reconcile_bad_own_snapshot_never_confirms(selection_boundary, mode, shape):
    from livemorebio.aegle.execution import DENY_ALL
    t = selection_boundary
    op = reconcile_op(t, mode=mode, shape=shape)
    rejected(t, op, t.request(op))
    assert "candidate-state" in op.calls or "project-modeless" in op.calls
    t.original(op)
    assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL


# E: fourteen final-authority/ownership/serialization cases.
@pytest.mark.parametrize("error", ["conflict", "storage", "uncertain"])
def test_reconcile_checked_confirmation_failure_preserves_holders(selection_boundary, error):
    from livemorebio.aegle.execution import DENY_ALL
    t = selection_boundary
    op = reconcile_op(t, confirm_error=error)
    result = t.request(op)
    assert result.status_code == (409 if error == "conflict" else 503)
    assert result.json()["code"] == {"conflict": "SELECTION_RECONCILIATION_CONFLICT",
        "storage": "REGISTRY_STORAGE_UNAVAILABLE", "uncertain": "SELECTION_COMMIT_UNCONFIRMED"}[error]
    response_context(op, result)
    assert op.calls.count("capture") == op.calls.count("confirm") == 1
    assert "invalidate" not in op.calls and not t.snapshots
    t.original(op)
    assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL


def test_reconcile_changed_captured_state_blocks_confirmation(selection_boundary):
    from livemorebio.aegle.execution import DENY_ALL
    t = selection_boundary
    op = reconcile_op(t)
    winner = []
    def replace():
        with t.authority.observation():
            value = AuthoredState(t.server._state)
            t.server._state = value
            winner.append(value)
    op.before_final = replace
    rejected(t, op, t.request(op), status=409, code="SELECTION_RECONCILIATION_CONFLICT")
    assert t.server._state is winner[0] and t.authority.permitted_generation is DENY_ALL


def test_reconcile_now_confirmed_blocks_confirmation(selection_boundary):
    t = selection_boundary
    op = reconcile_op(t)
    winner = []
    op.before_final = lambda: winner.extend(t.install_winner())
    rejected(t, op, t.request(op), status=409, code="SELECTION_RECONCILIATION_CONFLICT")
    assert t.server._state is winner[0] and t.server._workspace_actions is winner[1]
    assert t.authority.generation == "authored-later-generation"


def test_reconcile_deny_confirmed_deny_aba_rejects_stale_request(selection_boundary):
    from livemorebio.aegle.execution import DENY_ALL
    t = selection_boundary
    first = reconcile_op(t)
    evidence = t.raw_evidence
    winner = []
    def recover_then_unknown():
        second = t.make_op("reconcile", record=deepcopy(first.record))
        successful(t, second, t.request(second))
        t.server._state["observation_state"].observations["authored-R2"] = {"data_class": "AUTHORED_TEST_ONLY"}
        t.server._workspace_actions.append({"kind": "AUTHORED_R2_ACTION"})
        winner.extend((t.server._state, t.server._workspace_actions))
        later = t.make_op(outcome="unknown")
        result = t.request(later)
        assert result.status_code == 503 and result.json()["code"] == "SELECTION_COMMIT_UNCONFIRMED"
        t.original(later)
        assert t.authority.permitted_generation is DENY_ALL and t.raw_evidence is evidence
    first.during_preparation = recover_then_unknown
    result = t.request(first)
    rejected(t, first, result, status=409, code="SELECTION_RECONCILIATION_CONFLICT")
    assert t.server._state is winner[0] and t.server._workspace_actions is winner[1]
    assert t.server._state["observation_state"].observations["authored-R2"]
    assert t.server._workspace_actions == [{"kind": "AUTHORED_R2_ACTION"}]
    assert t.authority.permitted_generation is t.manager._permitted_generation is DENY_ALL
    assert first.read_evidence is evidence and len(t.snapshots) == 1


def test_reconcile_competing_recovery_confirms_once(selection_boundary):
    t = selection_boundary
    first = reconcile_op(t)
    winner = []
    def recover():
        second = t.make_op("reconcile", record=deepcopy(first.record))
        successful(t, second, t.request(second))
        winner.extend((t.server._state, t.authority.generation))
    first.during_preparation = recover
    rejected(t, first, t.request(first), status=409, code="SELECTION_RECONCILIATION_CONFLICT")
    assert t.server._state is winner[0] and t.authority.generation == winner[1]
    assert sum(op.calls.count("confirm") for op in t.operations) == 1 and len(t.snapshots) == 1


def test_reconcile_preserves_closed_pending_execution_ownership(selection_boundary):
    from livemorebio.aegle import execution_api
    from livemorebio.aegle.execution_contract import ExecutionError
    t = selection_boundary
    t.manager._owners[OWNER_ID] = t.store.owner
    with pytest.raises(ExecutionError):
        execution_api.shutdown_execution_manager()
    prior = tuple(t.store_calls)
    op = reconcile_op(t)
    successful(t, op, t.request(op))
    assert t.server._execution_manager_instance is t.manager and t.manager._closed
    assert t.manager._owners == {OWNER_ID: t.store.owner} and t.manager._cleanup_pending == {OWNER_ID}
    assert tuple(t.store_calls) == prior and "invalidate" not in op.calls


@pytest.mark.parametrize("outcome", ["success", "rejected-candidate", "superseded-capture"])
def test_reconcile_strong_holders_release_outside_guards(selection_boundary, outcome):
    t = selection_boundary
    refs = fresh_watched_initial(t)
    op = reconcile_op(t, mode="ready")
    if outcome == "rejected-candidate":
        op.confirm_error = "conflict"
    elif outcome == "superseded-capture":
        def supersede():
            t.install_winner()
            gc.collect()
            assert all(ref() is not None for ref in refs.values()), "Capture lost its strong prior state/actions outside final guard"
            assert not any(label.startswith("old:") for label, _ in t.finalizers)
        op.during_preparation = supersede
    result = t.request(op)
    assert result.status_code == (200 if outcome == "success" else 409)
    response_context(op, result)
    gc.collect()
    if outcome == "rejected-candidate":
        assert all(ref() is not None for ref in refs.values())
        assert op.candidate_refs and all(ref() is None for ref in op.candidate_refs)
    else:
        assert all(ref() is None for ref in refs.values())
    assert t.finalizers and all(state == (False, False, False, False) for _, state in t.finalizers)


def test_reconcile_publishes_own_snapshot_after_later_winner(selection_boundary):
    t = selection_boundary
    op = reconcile_op(t, mode="ready")
    winner = []
    op.after_guard = lambda: winner.extend(t.install_winner())
    result = t.request(op)
    assert result.status_code == 200
    response_context(op, result)
    assert t.server._state is winner[0] and t.server._workspace_actions is winner[1]
    assert t.authority.generation == "authored-later-generation"
    assert len(t.snapshots) == 1 and "invalidate" not in op.calls
    value = t.snapshots[0][1]
    assert value["profile_params"] == {"authored_candidate": op.name}
    assert value["model_availability"] == result.json()["model_availability"]
    assert value["model_availability"]["source_generation"] != t.authority.generation


@pytest.mark.parametrize("kind", ["observations", "reconcile"])
def test_selection_success_metadata_serialization_precedes_final_owner(selection_boundary, kind):
    from livemorebio.aegle.execution import DENY_ALL
    t = selection_boundary
    op = reconcile_op(t, metadata_fault=True) if kind == "reconcile" else t.make_op(metadata_fault=True)
    rejected(t, op, t.request(op))
    t.original(op)
    if kind == "reconcile":
        assert t.authority.permitted_generation is DENY_ALL
    else:
        assert t.authority.generation == t.generation
    assert "wire-serialized" in op.calls
