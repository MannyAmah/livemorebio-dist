"""Mounted owned-controller tests; authored plugin objects are not rendering proof."""
import json
from pathlib import Path
import re
import subprocess

import pytest
from ._node import NODE, run_node as _run_node

ROOT = Path(__file__).parents[2]
LIB = ROOT / "livemorebio/aegle/console/lib"


def run_inspector(body: str) -> None:
    script = r"""
const assert=require('node:assert/strict'),fs=require('node:fs');
const base=BASE;
const moduleURL=p=>'data:text/javascript;base64,'+Buffer.from(fs.readFileSync(p,'utf8')).toString('base64');
const loader=moduleURL(base+'/molecular_loader.js');
const source=fs.readFileSync(base+'/molecular_inspector.js','utf8').replace("'./molecular_loader.js'",JSON.stringify(loader));
const tick=()=>new Promise(r=>setTimeout(r,0));
function deferred(){let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};}
let completed=false;process.on('beforeExit',()=>{if(!completed)process.exitCode=1;});
(async()=>{
const mod=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
class Element {
 constructor(tag,doc){this.tagName=tag.toUpperCase();this.ownerDocument=doc;this.children=[];this.parentNode=null;
 this.attributes={};this.style={};this.dataset={};this.handlers={};this.hidden=false;this.disabled=false;this.textContent='';}
 setAttribute(k,v){this.attributes[k]=String(v);}getAttribute(k){return this.attributes[k]??null;}
 append(...nodes){for(const n of nodes){n.remove();n.parentNode=this;this.children.push(n);}}
 replaceChildren(...nodes){for(const n of this.children)n.parentNode=null;this.children=[];this.append(...nodes);}
 remove(){if(this.parentNode){this.parentNode.children=this.parentNode.children.filter(n=>n!==this);this.parentNode=null;}}
 get isConnected(){return this===this.ownerDocument.body||Boolean(this.parentNode?.isConnected);}
 get parentElement(){return this.parentNode;}
 get tabIndex(){return Object.hasOwn(this.attributes,'tabindex')?Number(this.attributes.tabindex):
 ['BUTTON','INPUT','SELECT','TEXTAREA','A'].includes(this.tagName)?0:-1;}
 matches(selector){if(selector===':disabled')return this.disabled;throw Error('Unexpected native selector');}
 closest(selector){assert.equal(selector,'[hidden],[inert]');
 for(let n=this;n;n=n.parentElement)if(n.hidden||n.inert)return n;return null;}
 getClientRects(){if(this.zeroRect||!this.isConnected)return [];
 for(let n=this;n;n=n.parentElement)if(n.hidden||n.style.display==='none')return [];
 return [{width:80,height:30}];}
 contains(other){return other===this||this.children.some(n=>n.contains(other));}
 addEventListener(k,f){(this.handlers[k]??=[]).push(f);}removeEventListener(k,f){this.handlers[k]=(this.handlers[k]||[]).filter(x=>x!==f);}
 focus(){this.ownerDocument.activeElement=this;}
 dispatch(k,event={}){for(const f of this.handlers[k]||[])f({preventDefault(){},stopPropagation(){},...event});}
 querySelectorAll(selector){const out=[];function visit(n){for(const c of n.children){
 if(selector.includes('button')?(['BUTTON','INPUT','SELECT','TEXTAREA'].includes(c.tagName)&&selector.includes(c.tagName.toLowerCase())&&!c.disabled||
 c.tagName==='A'&&selector.includes('a[href]')&&Object.hasOwn(c.attributes,'href')||
 selector.includes('[tabindex="0"]')&&c.attributes.tabindex==='0'):
 selector.startsWith('[')&&Object.hasOwn(c.attributes,selector.slice(1,-1)))out.push(c);visit(c);}}visit(this);return out;}
 querySelector(s){return this.querySelectorAll(s)[0]||null;}
}
const window={handlers:{},addEventListener:Element.prototype.addEventListener,removeEventListener:Element.prototype.removeEventListener};
window.getComputedStyle=node=>{let inherited=node;
 while(inherited&&!inherited.style.visibility)inherited=inherited.parentElement;
 return {display:node.style.display||'block',visibility:inherited?.style.visibility||'visible',opacity:node.style.opacity||'1'};};
const document={defaultView:window,createElement(tag){return new Element(tag,this);}};
document.body=document.createElement('body');document.activeElement=document.body;
const host=document.createElement('section'),trigger=document.createElement('button');document.body.append(trigger,host);trigger.focus();
const raw=new TextEncoder().encode('data_TECHNICAL_ONLY\n');
const sha=require('node:crypto').createHash('sha256').update(raw).digest('hex');
const descriptor={...JSON.parse(fs.readFileSync(CATALOG,'utf8')).structures['4OBE'],coordinate_sha256:sha,
 coordinate_bytes:raw.length,asset_path:`/api/molecular/structures/${sha}/coordinates`};
const metadata={gene:'KRAS',status:'REFERENCE_AVAILABLE',pdb:'4OBE',uniprot:'P01116',reason_code:null,reference:descriptor,related_references:[]};
const binding={'X-Livemore-Source-Sha256':'b'.repeat(64),'X-Livemore-Process-Instance':'12345678-1234-4123-8123-123456789abc'};
const counts={fetch:0,construct:0,dispose:0,unmount:0,render:0,active:0,max:0};const calls=[];
let hold=null,held=deferred(),entered=deferred(),fail=null,modelFault=null;
async function phase(name){calls.push(name);if(hold===name){entered.resolve();await held.promise;}if(fail===name)throw Error('PRIVATE failure');}
const fetchImpl=async(url)=>{counts.fetch++;const data=url.includes('?')?JSON.stringify(metadata):raw;
 return new Response(data,{headers:{...binding,'Content-Type':url.includes('?')?'application/json':'chemical/x-cif',
 'X-Content-SHA256':sha,'X-Livemore-Evidence-State':'REFERENCE_ONLY'}});};
let lastPlugin;
class PluginUIContext{
 constructor(){counts.construct++;counts.active++;counts.max=Math.max(counts.max,counts.active);lastPlugin=this;
 this.done=deferred();this.canvas=deferred();this.initialized=this.done.promise;this.canvas3dInitialized=this.canvas.promise;
 this.builders={
  data:{rawData:async input=>{assert.equal(input.data,new TextDecoder().decode(raw));await phase('raw');return {raw:true};}},
  structure:{
   parseTrajectory:async(data,format)=>{assert.equal(format,'mmcif');await phase('parse');return {obj:{data:{frameCount:modelFault==='frames'?2:1}}};},
   hierarchy:{applyPreset:async(trajectory,name,params)=>{
    assert.equal(name,'default');assert.deepEqual(params,{model:{modelIndex:0},structure:{name:'model',params:{}},showUnitcell:false});
    await phase('preset');
    const model={modelNum:1,sourceData:{kind:'mmCIF',data:{db:{atom_site:{_rowCount:descriptor.atom_site_rows}}}}};
    if(modelFault==='number')model.modelNum=2;
    if(modelFault==='format')model.sourceData.kind='PDB';
    if(modelFault==='rows')model.sourceData.data.db.atom_site._rowCount++;
    return {model:{obj:{data:model}}};
   }}
  }
 };}
 async init(){try{await phase('init');this.done.resolve();}catch(e){this.done.reject(e);throw e;}}
 dispose(){calls.push('dispose');counts.dispose++;counts.active--;if(fail==='dispose')throw Error('PRIVATE cleanup');}
}
const adapter={PluginUIContext,Plugin:function(){},createStructureSpec:()=>({}),createElement:(type,props)=>props,
 createRoot(target){return {render(props){counts.render++;phase('canvas').then(()=>{props.plugin.canvas3d={};props.plugin.canvas.resolve();},e=>props.plugin.canvas.reject(e));},
 unmount(){calls.push('unmount');counts.unmount++;if(fail==='unmount')throw Error('PRIVATE cleanup');}};},
 modelPresetParameters:modelIndex=>({model:{modelIndex},structure:{name:'model',params:{}},showUnitcell:false})};
const context={kind:'ordinary',key:'a'.repeat(64),mode:'REFERENCE_ONLY'};
const create=options=>mod.mountMolecularInspector(host,{context,fetchImpl,loadAdapter:async()=>{await phase('import');return adapter;},...options});
BODY
completed=true;
})().catch(e=>{console.error(e.name,e.message);process.exit(1);});
""".replace("BASE", json.dumps(str(LIB))).replace("CATALOG", json.dumps(str(ROOT / "livemorebio/scientific_sources/data/molecular/catalog.json"))).replace("BODY", body)
    result = _run_node([NODE, "--eval", script], cwd=ROOT,
                            capture_output=True, text=True, timeout=10, encoding="utf-8")
    assert result.returncode == 0, result.stdout + result.stderr


def test_real_controller_ready_and_exactly_once_ordered_close():
    run_inspector("""
const inspector=create();await inspector.open('KRAS');
assert.equal(host.dataset.molecularState,'READY');assert.equal(counts.render,1);
assert.equal(host.querySelector('[data-molecular-stage]').style.visibility,'visible');
await inspector.close();await inspector.close();await inspector.dispose();
assert.equal(counts.dispose,1);assert.equal(counts.unmount,1);assert.equal(counts.active,0);
assert(calls.indexOf('unmount')<calls.indexOf('dispose'));assert.equal(document.activeElement,trigger);
""")


@pytest.mark.parametrize("shape", ["absent", "layout_only", "populated"])
def test_embedded_layout_is_reactive_detached_and_preserves_adapter_settings(shape):
    run_inspector(f"const shape={json.dumps(shape)};" + """
const action=()=>{},behavior=()=>{},component=()=>{};
const shared={actions:Object.freeze([action]),behaviors:Object.freeze([behavior]),
 components:Object.freeze({viewport:component}),config:Object.freeze([['setting',false]])};
if(shape!=='absent')shared.layout={controls:Object.freeze({top:'visible'})};
if(shape==='populated')shared.layout.initial=Object.freeze({isExpanded:false,showControls:true,
 controlsDisplay:'outside',regionState:Object.freeze({right:'full'})});
if(shared.layout)Object.freeze(shared.layout);Object.freeze(shared);
let received;adapter.createStructureSpec=()=>shared;
adapter.PluginUIContext=class extends PluginUIContext{constructor(spec){super();received=spec;}};
const inspector=create();await inspector.open('KRAS');
assert.equal(host.dataset.molecularState,'READY');
assert.equal(received.layout.initial.controlsDisplay,'reactive');
assert.notStrictEqual(received,shared);assert.notStrictEqual(received.layout,shared.layout);
assert.notStrictEqual(received.layout.initial,shared.layout?.initial);
assert.deepEqual(Object.keys(received).sort(),[...new Set([...Object.keys(shared),'layout'])].sort());
for(const key of Object.keys(shared).filter(k=>k!=='layout'))assert.strictEqual(received[key],shared[key]);
for(const key of Object.keys(shared.layout??{}).filter(k=>k!=='initial'))assert.strictEqual(received.layout[key],shared.layout[key]);
for(const key of Object.keys(shared.layout?.initial??{}).filter(k=>k!=='controlsDisplay'))
 assert.strictEqual(received.layout.initial[key],shared.layout.initial[key]);
assert.equal(shared.layout?.initial?.controlsDisplay,shape==='populated'?'outside':undefined);
await inspector.dispose();assert.equal(counts.active,0);
""")


def test_inspector_button_spacing_does_not_override_upstream_controls():
    css = (LIB / "molecular_inspector.css").read_text(encoding="utf-8")
    rules = re.findall(r"([^{}]+)\{([^{}]*)\}", css)
    spacing_rules = [selectors for selectors, body in rules
                     if re.search(r"min-height\s*:\s*40px", body)]
    assert len(spacing_rules) == 1
    assert {selector.strip() for selector in spacing_rules[0].split(",")} == {
        ".molecular-inspector [data-molecular-close]",
        ".molecular-inspector [data-molecular-retry]",
    }


def test_portrait_stage_reserves_upstream_chrome_and_usable_canvas():
    css = (LIB / "molecular_inspector.css").read_text(encoding="utf-8")
    match = re.search(
        r"@media\s*\(orientation:\s*portrait\)\s*and\s*\(max-width:\s*1000px\)"
        r"\s*\{\s*\.molecular-inspector\s+\[data-molecular-stage\]\s*\{([^{}]+)\}",
        css,
    )
    assert match is not None
    minimum = re.search(r"min-height\s*:\s*(\d+)px", match.group(1))
    assert minimum is not None
    # Pinned Molstar4.4 portrait: 97px sequence + 361px tools, not body physiology.
    assert int(minimum.group(1)) - 97 - 361 >= 240


@pytest.mark.parametrize("stage", ["import", "init", "canvas", "raw", "parse", "preset"])
@pytest.mark.parametrize("action", ["close", "context", "dispose"])
def test_every_late_completion_is_owned_not_published(stage, action):
    run_inspector(f"hold={json.dumps(stage)};const action={json.dumps(action)};" + """
const inspector=create();const opening=inspector.open('KRAS');await entered.promise;
const closing=action==='context'?inspector.setContext({...context,key:'c'.repeat(64)}):inspector[action]();
assert.notEqual(host.dataset.molecularState,'READY');held.resolve();
await opening;await closing;assert.equal(counts.active,0);assert.equal(counts.max<=1,true);
assert.equal(counts.dispose,counts.construct);assert.notEqual(host.dataset.molecularState,'READY');
await inspector.dispose();
""")


@pytest.mark.parametrize("stage", ["import", "init", "canvas", "raw", "parse", "preset"])
def test_rejected_stage_never_becomes_ready_or_echoes_error(stage):
    run_inspector(f"fail={json.dumps(stage)};" + """
const inspector=create();await inspector.open('KRAS');
assert.equal(host.dataset.molecularState,'FAILED');assert.equal(counts.active,0);
assert(!host.querySelector('[data-molecular-status]').textContent.includes('PRIVATE'));
assert.equal(counts.dispose,counts.construct);await inspector.dispose();
""")


def test_pending_initializer_blocks_second_plugin_and_reports_deadline():
    run_inspector("""
hold='init';const inspector=create({timeoutMs:100});
const a=inspector.open('KRAS');await entered.promise;const b=inspector.open('KRAS');
await a;await b;assert.equal(counts.construct,1);assert.equal(counts.max,1);
assert.equal(host.dataset.molecularState,'CLEANUP_UNCONFIRMED');held.resolve();await tick();await tick();
await inspector.dispose();assert.equal(counts.active,0);
""")


@pytest.mark.parametrize("failure", ["unmount", "dispose"])
def test_cleanup_failure_blocks_new_plugin(failure):
    run_inspector(f"const failure={json.dumps(failure)};" + """
const inspector=create();await inspector.open('KRAS');fail=failure;
await inspector.close();await inspector.open('KRAS');
assert.equal(host.dataset.molecularState,'CLEANUP_UNCONFIRMED');assert.equal(counts.construct,1);
await inspector.dispose();
""")


def test_unavailable_mapping_and_removed_trigger_focus():
    run_inspector("""
metadata.status='MAPPING_UNAVAILABLE';metadata.reason_code='SOURCE_MAPPING_NOT_ADMITTED';
metadata.pdb=null;metadata.reference=null;metadata.uniprot=null;
const inspector=create();await inspector.open('KRAS');assert.equal(host.dataset.molecularState,'UNAVAILABLE');
assert.equal(counts.construct,0);assert.equal(counts.fetch,1);trigger.remove();await inspector.close();
assert.equal(document.activeElement,host);await inspector.dispose();
""")


def test_loading_and_failure_status_are_inside_visible_dialog():
    run_inspector("""
hold='init';const inspector=create();const opening=inspector.open('KRAS');await entered.promise;
const dialog=host.querySelector('[data-molecular-dialog]'),status=host.querySelector('[data-molecular-status]');
assert.equal(dialog.hidden,false);assert(dialog.contains(status));held.reject(Error('PRIVATE init'));
await opening;assert.equal(host.dataset.molecularState,'FAILED');assert(dialog.contains(status));
await inspector.close();assert.equal(status.parentNode,host);await inspector.dispose();
""")


def test_keyboard_escape_close_returns_focus_without_extra_source_request():
    run_inspector("""
const inspector=create();await inspector.open('KRAS');
host.querySelector('[data-molecular-dialog]').dispatch('keydown',{key:'Escape'});await tick();
assert.equal(host.dataset.molecularState,'CLOSED');assert.equal(document.activeElement,trigger);
assert.equal(counts.fetch,2);await inspector.dispose();
""")


@pytest.mark.parametrize("field,value", [("kind", "other"), ("key", []), ("mode", "OBSERVED")])
def test_invalid_new_context_invalidates_old_view(field, value):
    run_inspector(f"const field={json.dumps(field)},value={json.dumps(value)};" + """
const inspector=create();await inspector.open('KRAS');
await inspector.setContext({...context,[field]:value});
assert.notEqual(host.dataset.molecularState,'READY');assert.equal(counts.active,0);
assert.equal(host.querySelector('[data-molecular-provenance]').textContent,'');await inspector.dispose();
""")


@pytest.mark.parametrize("fault", ["frames", "number", "format", "rows"])
def test_actual_parser_contract_mismatch_prevents_ready(fault):
    run_inspector(f"modelFault={json.dumps(fault)};" + """
const inspector=create();await inspector.open('KRAS');
assert.equal(host.dataset.molecularState,'FAILED');assert.equal(counts.active,0);
assert(host.querySelector('[data-molecular-status]').textContent.includes('admitted source'));
await inspector.dispose();
""")


def test_replacement_waits_for_old_owner_and_close_returns_original_trigger():
    run_inspector("""
hold='init';const inspector=create();const a=inspector.open('KRAS');await entered.promise;
const b=inspector.open('KRAS');assert.equal(counts.construct,1);hold=null;held.resolve();
await a;await b;assert.equal(host.dataset.molecularState,'READY');assert.equal(counts.max,1);
assert.equal(counts.construct,2);assert.equal(counts.dispose,1);
await inspector.close();assert(document.activeElement===trigger);await inspector.dispose();
""")


def test_five_open_close_cycles_release_all_owned_handles():
    run_inspector("""
const inspector=create();for(let i=0;i<5;i++){await inspector.open('KRAS');
 assert.equal(host.dataset.molecularState,'READY');await inspector.close();assert.equal(counts.active,0);}
assert.equal(counts.construct,5);assert.equal(counts.dispose,5);assert.equal(counts.unmount,5);
assert.equal(counts.max,1);await inspector.dispose();
assert.equal(window.handlers.pagehide.length,0);
""")


@pytest.mark.parametrize("next_action", ["open", "context", "dispose"])
def test_superseded_close_does_not_call_old_owner_callback(next_action):
    run_inspector(f"const nextAction={json.dumps(next_action)};" + """
hold='init';let closed=0;const inspector=create({onClose(){closed++;}});
const a=inspector.open('KRAS');await entered.promise;const oldClose=inspector.close();
const newer=nextAction==='open'?inspector.open('KRAS'):
 nextAction==='context'?inspector.setContext({...context,key:'d'.repeat(64)}):inspector.dispose();
hold=null;held.resolve();await a;await oldClose;await newer;
assert.equal(closed,0);if(nextAction==='open')assert.equal(host.dataset.molecularState,'READY');
await inspector.dispose();
""")


def test_old_close_timeout_cannot_overwrite_new_loading_state():
    run_inspector("""
hold='init';const inspector=create({timeoutMs:150});
const a=inspector.open('KRAS');await entered.promise;const oldClose=inspector.close();
await new Promise(r=>setTimeout(r,65));const b=inspector.open('KRAS');
await oldClose;assert.equal(host.dataset.molecularState,'LOADING');
hold=null;held.resolve();await a;await b;assert.equal(host.dataset.molecularState,'READY');
await inspector.dispose();
""")


def test_invalid_context_completion_cannot_overwrite_new_context_loading():
    run_inspector("""
hold='init';const inspector=create();const a=inspector.open('KRAS');await entered.promise;
const invalid=inspector.setContext({...context,key:null});
const valid=inspector.setContext({...context,key:'d'.repeat(64)});const b=inspector.open('KRAS');
hold=null;held.resolve();await invalid;
assert.notEqual(host.dataset.molecularState,'FAILED');await a;await valid;await b;
assert.equal(host.dataset.molecularState,'READY');await inspector.dispose();
""")


@pytest.mark.parametrize("hidden_by", ["hidden", "inert", "display", "visibility", "opacity", "no_rect", "disabled"])
def test_connected_hidden_trigger_returns_focus_to_neutral_host(hidden_by):
    run_inspector(f"const hiddenBy={json.dumps(hidden_by)};" + """
const parent=document.createElement('div');document.body.append(parent);parent.append(trigger);trigger.focus();
const inspector=create();await inspector.open('KRAS');
if(hiddenBy==='hidden')parent.hidden=true;if(hiddenBy==='inert')parent.inert=true;
if(hiddenBy==='display')parent.style.display='none';if(hiddenBy==='visibility')parent.style.visibility='hidden';
if(hiddenBy==='opacity')parent.style.opacity='0';if(hiddenBy==='no_rect')trigger.zeroRect=true;
if(hiddenBy==='disabled')trigger.disabled=true;assert.equal(trigger.isConnected,true);
await inspector.close();assert(document.activeElement===host);assert.equal(counts.active,0);await inspector.dispose();
""")


@pytest.mark.parametrize("hidden_by", ["none", "hidden", "inert", "display", "visibility", "opacity"])
def test_tab_and_shift_tab_only_wrap_visible_upstream_controls(hidden_by):
    run_inspector(f"const hiddenBy={json.dumps(hidden_by)};" + """
const inspector=create();await inspector.open('KRAS');const dialog=host.querySelector('[data-molecular-dialog]');
const plugin=host.querySelector('[data-molecular-plugin]'),first=host.querySelector('[data-molecular-close]');
const input=document.createElement('input'),last=document.createElement('textarea');plugin.append(input,last);
const negative=document.createElement('button');negative.setAttribute('tabindex','-1');plugin.append(negative);
if(hiddenBy!=='none'){
 const panel=document.createElement('div'),invisible=document.createElement('button');panel.append(invisible);plugin.append(panel);
 if(hiddenBy==='hidden')panel.hidden=true;if(hiddenBy==='inert')panel.inert=true;
 if(hiddenBy==='display')panel.style.display='none';if(hiddenBy==='visibility')panel.style.visibility='hidden';
 if(hiddenBy==='opacity')panel.style.opacity='0';
}
let prevented=0;last.focus();dialog.dispatch('keydown',{key:'Tab',preventDefault(){prevented++;}});
assert(document.activeElement===first);assert.equal(prevented,1);
dialog.dispatch('keydown',{key:'Tab',shiftKey:true,preventDefault(){prevented++;}});
assert(document.activeElement===last);assert.equal(prevented,2);
input.focus();dialog.dispatch('keydown',{key:'Tab',preventDefault(){prevented++;}});
assert(document.activeElement===input);assert.equal(prevented,2,'ordinary interior Tab must remain native');
await inspector.dispose();
""")
