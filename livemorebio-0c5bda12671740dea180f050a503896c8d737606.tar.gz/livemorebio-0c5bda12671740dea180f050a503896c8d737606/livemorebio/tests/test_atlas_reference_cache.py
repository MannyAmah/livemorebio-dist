"""Private, tiny technical triangle lifecycle; no publisher data or network."""
from __future__ import annotations

from copy import deepcopy
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import time
import zipfile

import pytest

from livemorebio.anatomy import atlas_reference as atlas
from livemorebio.tests.test_atlas_reference_geometry import technical_obj


class Response(io.BytesIO):
    def __init__(self, raw, url, *, headers=None, status=200):
        super().__init__(raw)
        self.url, self.headers, self.status = url, headers or {}, status

    def geturl(self):
        return self.url


@pytest.fixture
def technical(tmp_path, monkeypatch):
    """Replace the declaration only in this process with explicit test bytes."""
    root = tmp_path / "technical-anatomy"
    monkeypatch.setenv("LIVEMORE_ANATOMY_DIR", str(root))
    declaration = atlas.catalog()
    members, groups, source = [], [], io.BytesIO()
    maps = {"isa": "concept id\tname\telement file id\n", "partof": "concept id\tname\telement file id\n"}
    with zipfile.ZipFile(source, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for i, key in enumerate(atlas.ASSET_KEYS):
            raw, member = technical_obj()
            identifier = f"FJ{9000+i}"
            raw = raw.replace(b"FJ2810", identifier.encode())
            member.update(element_id=identifier, source_bytes=len(raw), source_sha256=hashlib.sha256(raw).hexdigest(),
                          archive_member=f"isa_BP3D_4.0_obj_99/{identifier}.obj")
            members.append(member)
            group = {"asset_key": key, "logic": "isa" if i == 0 else "partof", "fma": f"TECHNICAL{i}",
                     "element_ids": [identifier], "element_ids_sha256": atlas._digest((identifier + "\n").encode())}
            groups.append(group)
            maps[group["logic"]] += f"{group['fma']}\tTECHNICAL NOT HUMAN ANATOMY\t{identifier}\n"
            archive.writestr(member["archive_member"], raw)
    contents = {"archive": source.getvalue(), **{key: value.encode() for key, value in maps.items()}}
    files = [{"key": key, "url": f"https://technical.invalid/{key}", "sha256": atlas._digest(raw), "bytes": len(raw)}
             for key, raw in contents.items()]
    declaration.update(members=members, groups=groups, source_files=files)
    encoded = atlas._canonical(declaration)
    monkeypatch.setattr(atlas, "_declaration_bytes", lambda: encoded)
    monkeypatch.setattr(atlas, "DECLARATION_SHA256", atlas._digest(encoded))
    monkeypatch.setattr(atlas, "ARCHIVE_ENTRIES", 9)
    monkeypatch.setattr(atlas, "ARCHIVE_UNCOMPRESSED_BYTES", sum(m["source_bytes"] for m in members))
    requests = []
    def open_source(url, timeout):
        requests.append(url)
        item = next(item for item in files if item["url"] == url)
        return Response(contents[item["key"]], url, headers={"Content-Length": str(item["bytes"])})
    monkeypatch.setattr(atlas, "_open_source", open_source)
    monkeypatch.setattr(atlas, "_launch_acquisition", lambda cache, lock: atlas._acquire_sources(cache, time.monotonic()+10))
    monkeypatch.setattr(atlas, "_launch_conversion", lambda cache, lock, stage: atlas._build_stage(cache, stage))
    return {"root": root, "declaration": declaration, "contents": contents, "requests": requests}


def test_technical_install_read_and_reuse_are_exact_and_network_free(technical):
    installed = atlas.install(atlas.SOURCE_ID)
    assert installed["available"] and installed["reused"] is False
    assert len(technical["requests"]) == 3
    assert installed["manifest"]["patient_registered"] is False
    assert installed["manifest"]["evidence_state"] == "REFERENCE_ONLY"
    for group, asset in zip(technical["declaration"]["groups"], installed["manifest"]["assets"], strict=True):
        for node in asset["audit"]["nodes"]:
            assert node["asset_key"] == group["asset_key"]
            assert node["memberships"] == [{"asset_key": group["asset_key"], "logic": group["logic"], "fma": group["fma"]}]
        assert len(asset["audit"]["native_bounds_mm"]) == 2
        assert len(asset["audit"]["world_bounds_m"]) == 2
    for key in atlas.ASSET_KEYS:
        raw, metadata = atlas.read_asset(installed["manifest_sha256"], key)
        assert raw.startswith(b"glTF") and metadata["sha256"] == atlas._digest(raw)
        assert str(technical["root"]) not in json.dumps(metadata)
    assert atlas.status()["state"] == "available"
    again = atlas.install(atlas.SOURCE_ID)
    assert again["reused"] is True and again["receipt"] == installed["receipt"]
    assert again["manifest_sha256"] == installed["manifest_sha256"]
    assert len(technical["requests"]) == 3
    for path in (technical["root"] / "atlas").rglob("*"):
        assert stat.S_IMODE(path.stat().st_mode) == (0o700 if path.is_dir() else 0o600)


def test_status_reports_existing_acquisition_without_creating_lock(technical):
    with atlas._Cache(create=True) as cache:
        before = set(os.listdir(cache.fd))
        assert atlas.status()["state"] == "missing"
        assert set(os.listdir(cache.fd)) == before
        with cache.lock():
            assert atlas.status()["state"] == "acquiring"
            with pytest.raises(atlas.AtlasReferenceError, match="already in progress"):
                atlas.install(atlas.SOURCE_ID)
    assert technical["requests"] == []


@pytest.mark.parametrize("kind", ["symlink", "hardlink", "public", "directory"])
def test_unsafe_active_file_is_safe_error_without_repair(technical, kind):
    with atlas._Cache(create=True):
        pass
    path = technical["root"] / "atlas" / "active.json"
    target = technical["root"] / "preserved"
    target.write_bytes(b"PRIVATE TEST SENTINEL")
    target.chmod(0o600)
    if kind == "symlink":
        path.symlink_to(target)
    elif kind == "hardlink":
        os.link(target, path)
    elif kind == "public":
        path.write_bytes(b"{}")
        path.chmod(0o644)
    else:
        path.mkdir(mode=0o700)
    original = target.read_bytes()
    result = atlas.status()
    assert result["state"] == "unsafe_cache"
    assert str(target) not in json.dumps(result)
    assert target.read_bytes() == original


@pytest.mark.parametrize("missing", ["receipt", "source", "asset"])
def test_missing_admitted_component_is_corrupt_not_fresh_install(technical, monkeypatch, missing):
    installed = atlas.install(atlas.SOURCE_ID)
    digest = installed["manifest_sha256"]
    relative = {"receipt": f"receipts/{digest}.json", "asset": f"artifacts/{digest}/skin.glb",
                "source": atlas._source_file(technical["declaration"]["source_files"][0])}[missing]
    (technical["root"] / "atlas" / relative).unlink()
    before = (technical["root"] / "atlas" / "active.json").read_bytes()
    monkeypatch.setattr(atlas, "_open_source", lambda *a: pytest.fail("corrupt admitted install acquired"))
    assert atlas.status()["state"] == "corrupt"
    with pytest.raises(atlas.AtlasReferenceError) as error:
        atlas.install(atlas.SOURCE_ID)
    assert error.value.code == "ATLAS_INTEGRITY_FAILED"
    assert (technical["root"] / "atlas" / "active.json").read_bytes() == before


@pytest.mark.parametrize("fault", ["short", "extra", "hash", "html", "content_length", "redirect", "status"])
def test_bad_download_not_published(technical, monkeypatch, fault):
    item = technical["declaration"]["source_files"][0]
    raw = technical["contents"]["archive"]
    content = {"short": raw[:-1], "extra": raw+b"x", "hash": b"x"+raw[1:], "html": b"<html>not source</html>"}.get(fault, raw)
    monkeypatch.setattr(atlas, "_open_source", lambda *a: Response(content,
        "http://technical.invalid/archive" if fault == "redirect" else item["url"],
        headers={"Content-Length": "1"} if fault == "content_length" else {}, status=403 if fault == "status" else 200))
    with atlas._Cache(create=True) as cache:
        with pytest.raises(atlas.AtlasReferenceError):
            atlas._acquire(cache, item, time.monotonic()+10)
    assert not (technical["root"] / "atlas" / atlas._source_file(item)).exists()
    assert not list((technical["root"] / "atlas").rglob(".temporary-*"))


def test_final_blocking_read_cannot_publish_after_total_deadline(technical, monkeypatch):
    item = technical["declaration"]["source_files"][0]
    clock = [0.]
    class SlowEOF(Response):
        def read(self, size):
            result = super().read(size)
            if not result:
                clock[0] = 11.
            return result
    monkeypatch.setattr(atlas.time, "monotonic", lambda: clock[0])
    monkeypatch.setattr(atlas, "_open_source", lambda *a: SlowEOF(technical["contents"]["archive"], item["url"]))
    with atlas._Cache(create=True) as cache:
        with pytest.raises(atlas.AtlasReferenceError, match="HTTPS"):
            atlas._acquire(cache, item, 10.)
    assert not (technical["root"] / "atlas" / atlas._source_file(item)).exists()


def test_corrupt_same_digest_directory_cannot_become_active(technical):
    installed = atlas.install(atlas.SOURCE_ID)
    digest = installed["manifest_sha256"]
    root = technical["root"] / "atlas"
    (root / "active.json").unlink()
    (root / "receipts" / f"{digest}.json").unlink()
    (root / "artifacts" / digest / "skin.glb").write_bytes(b"CORRUPTED TECHNICAL DATA")
    with pytest.raises(atlas.AtlasReferenceError):
        atlas.install(atlas.SOURCE_ID)
    assert not (root / "active.json").exists()
    assert not (root / "receipts" / f"{digest}.json").exists()


def test_converter_identity_binds_loaded_parser_helpers_and_defaults(technical, monkeypatch):
    from livemorebio.anatomy import _atlas_geometry as geometry
    before = atlas._converter_identity()
    original = geometry._integer
    def changed_integer(value, minimum=0, maximum=4_000_000):
        return original(value, minimum, maximum)
    monkeypatch.setattr(geometry, "_integer", changed_integer)
    assert atlas._converter_identity() != before


def test_converter_identity_is_checkout_path_independent(technical, monkeypatch):
    from livemorebio.anatomy import _atlas_geometry as geometry
    import types
    before = atlas._converter_identity()
    original = geometry.parse_obj
    changed = types.FunctionType(original.__code__.replace(co_filename="/different/reviewed/checkout.py", co_firstlineno=999), original.__globals__)
    monkeypatch.setattr(geometry, "parse_obj", changed)
    assert atlas._converter_identity() == before


def test_failed_conversion_preserves_previous_source_and_no_active(technical, monkeypatch):
    def failed(*args):
        raise atlas.AtlasReferenceError("ATLAS_CONVERSION_FAILED")
    monkeypatch.setattr(atlas, "_launch_conversion", failed)
    with pytest.raises(atlas.AtlasReferenceError):
        atlas.install(atlas.SOURCE_ID)
    root = technical["root"] / "atlas"
    assert len(list((root / "sources").iterdir())) == 3
    assert not list(root.glob(".staging-*")) and not (root / "active.json").exists()


def test_directory_fsync_occurs_before_success_for_artifact_receipt_and_pointer(technical, monkeypatch):
    events = []
    original_sync, original_rename = os.fsync, os.rename
    def synced(fd):
        if stat.S_ISDIR(os.fstat(fd).st_mode):
            events.append(("sync_dir", os.fstat(fd).st_ino))
        return original_sync(fd)
    def renamed(src, dst, **kwargs):
        events.append(("rename", src, dst, os.fstat(kwargs["dst_dir_fd"]).st_ino))
        return original_rename(src, dst, **kwargs)
    monkeypatch.setattr(atlas.os, "fsync", synced)
    monkeypatch.setattr(atlas.os, "rename", renamed)
    installed = atlas.install(atlas.SOURCE_ID)
    digest = installed["manifest_sha256"]
    for target in (digest, digest + ".json", "active.json"):
        index = next(i for i, event in enumerate(events) if event[0] == "rename" and event[2] == target)
        parent_inode = events[index][3]
        assert ("sync_dir", parent_inode) in events[index+1:]


def test_parent_fsync_failure_never_acknowledges_success(technical, monkeypatch):
    original = os.fsync
    def failed(fd):
        info = os.fstat(fd)
        receipts = technical["root"] / "atlas" / "receipts"
        if receipts.exists() and info.st_ino == receipts.stat().st_ino:
            raise OSError("PRIVATE TEST PATH MUST NOT BE RETURNED")
        return original(fd)
    monkeypatch.setattr(atlas.os, "fsync", failed)
    with pytest.raises(atlas.AtlasReferenceError) as error:
        atlas.install(atlas.SOURCE_ID)
    assert error.value.code == "ATLAS_PUBLICATION_UNCONFIRMED"
    assert "PRIVATE" not in str(error.value)
    assert not (technical["root"] / "atlas" / "active.json").exists()


def test_cache_root_replacement_rejects_read_of_old_descriptor(technical):
    with atlas._Cache(create=True) as cache:
        cache.write("technical.json", b"{}")
        path = technical["root"] / "atlas"
        path.rename(technical["root"] / "preserved-old-atlas")
        path.mkdir(mode=0o700)
        with pytest.raises(atlas.AtlasReferenceError) as error:
            cache.read("technical.json", 100)
        assert error.value.code == "ATLAS_UNSAFE_CACHE"


def test_nonregular_file_open_cannot_block_before_safety_check(technical, monkeypatch):
    original = os.open
    def inspected(path, flags, *args, **kwargs):
        if path == "active.json":
            assert flags & os.O_NONBLOCK, "A malicious FIFO must not block before fstat"
        return original(path, flags, *args, **kwargs)
    with atlas._Cache(create=True):
        pass
    monkeypatch.setattr(atlas.os, "open", inspected)
    atlas.status()


def test_reused_install_reconciles_directory_durability_before_ack(technical, monkeypatch):
    installed = atlas.install(atlas.SOURCE_ID)
    syncs = set()
    original = os.fsync
    def synced(fd):
        if stat.S_ISDIR(os.fstat(fd).st_mode):
            syncs.add(os.fstat(fd).st_ino)
        return original(fd)
    monkeypatch.setattr(atlas.os, "fsync", synced)
    assert atlas.install(atlas.SOURCE_ID)["reused"]
    root = technical["root"] / "atlas"
    for path in (root, root / "receipts", root / "artifacts", root / "artifacts" / installed["manifest_sha256"]):
        assert path.stat().st_ino in syncs


@pytest.mark.parametrize("mutation", ["traversal", "duplicate", "symlink", "encrypted", "oversized", "changed_selected_bytes", "wrong_count", "wrong_total"])
def test_zip_metadata_boundary_rejects_before_member_decode(technical, mutation, monkeypatch):
    raw = technical["contents"]["archive"]
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        infos = archive.infolist()
        if mutation == "traversal":
            infos[0].filename = "../source.obj"
        elif mutation == "duplicate":
            infos[1].filename = infos[0].filename
        elif mutation == "symlink":
            infos[0].external_attr = (stat.S_IFLNK | 0o600) << 16
        elif mutation == "encrypted":
            infos[0].flag_bits |= 1
        elif mutation == "oversized":
            infos[0].file_size = 33*1024*1024
            monkeypatch.setattr(atlas, "ARCHIVE_UNCOMPRESSED_BYTES", sum(i.file_size for i in infos))
        elif mutation == "changed_selected_bytes":
            infos[0].file_size += 1
            infos[1].file_size -= 1
        elif mutation == "wrong_count":
            monkeypatch.setattr(atlas, "ARCHIVE_ENTRIES", 10)
        else:
            monkeypatch.setattr(atlas, "ARCHIVE_UNCOMPRESSED_BYTES", 1)
        with pytest.raises(atlas.AtlasReferenceError) as error:
            atlas._validate_zip(archive, technical["declaration"])
        assert error.value.code == "ATLAS_SOURCE_INTEGRITY"


def test_raw_archive_and_maps_rehashed_on_every_reuse(technical, monkeypatch):
    installed = atlas.install(atlas.SOURCE_ID)
    item = technical["declaration"]["source_files"][1]
    path = technical["root"] / "atlas" / atlas._source_file(item)
    raw = path.read_bytes()
    path.write_bytes(b"x" + raw[1:])
    monkeypatch.setattr(atlas, "_open_source", lambda *args: pytest.fail("corrupt source silently reacquired"))
    assert atlas.status()["state"] == "corrupt"
    with pytest.raises(atlas.AtlasReferenceError):
        atlas.read_asset(installed["manifest_sha256"], "skin")


def test_read_uses_same_file_bytes_and_detects_midread_replacement(technical):
    with atlas._Cache(create=True) as cache:
        cache.write("technical.json", b"OLD")
        path = technical["root"] / "atlas" / "technical.json"
        with pytest.raises(atlas.AtlasReferenceError) as error:
            with cache.file("technical.json") as stream:
                assert stream.read() == b"OLD"
                path.rename(path.with_suffix(".preserved"))
                path.write_bytes(b"NEW")
                path.chmod(0o600)
        assert error.value.code == "ATLAS_INTEGRITY_FAILED"


def test_staging_manifest_cannot_alias_reference_boolean_with_number(technical):
    with atlas._Cache(create=True) as cache:
        atlas._acquire_sources(cache, time.monotonic()+10)
        stage = ".staging-" + "c"*32
        atlas._build_stage(cache, stage)
        manifest = json.loads(cache.read(stage+"/manifest.json", atlas.MAX_MANIFEST_BYTES))
        manifest["patient_registered"] = 0
        cache.write(stage+"/manifest.json", atlas._canonical(manifest))
        with pytest.raises(atlas.AtlasReferenceError):
            atlas._validated_stage(cache, stage)


@pytest.mark.parametrize("fault", ["symlink", "open_denied", "flock_denied"])
def test_install_lock_failures_are_safe_before_acquisition(technical, monkeypatch, fault):
    with atlas._Cache(create=True):
        pass
    root = technical["root"] / "atlas"
    target = technical["root"] / "PRIVATE-target"
    target.write_bytes(b"PRESERVE TECHNICAL FILE")
    target.chmod(0o600)
    if fault == "symlink":
        (root / ".install.lock").symlink_to(target)
    elif fault == "open_denied":
        original = os.open
        def denied(path, *args, **kwargs):
            if path == ".install.lock":
                raise PermissionError("PRIVATE lock location")
            return original(path, *args, **kwargs)
        monkeypatch.setattr(atlas.os, "open", denied)
    else:
        monkeypatch.setattr(fcntl, "flock", lambda *args: (_ for _ in ()).throw(OSError("PRIVATE lock failure")))
    with pytest.raises(atlas.AtlasReferenceError) as error:
        atlas.install(atlas.SOURCE_ID)
    assert error.value.code == "ATLAS_UNSAFE_CACHE"
    assert "PRIVATE" not in str(error.value)
    assert technical["requests"] == []
    assert target.read_bytes() == b"PRESERVE TECHNICAL FILE"


@pytest.mark.parametrize("fault", ["rollback", "id", "schema", "naive", "order", "type", "source", "digest"])
def test_receipt_rejected_before_active_pointer_changes(technical, monkeypatch, fault):
    atlas.install(atlas.SOURCE_ID)
    root = technical["root"] / "atlas"
    before = (root / "active.json").read_bytes()
    original = atlas._converter_identity
    monkeypatch.setattr(atlas, "_converter_identity", lambda: {**original(), "version": "technical-new-converter"})
    stage = ".staging-" + "c"*32
    with atlas._Cache(create=True) as cache, cache.lock():
        atlas._build_stage(cache, stage)
        _, digest = atlas._validated_stage(cache, stage)
        started = "2099-01-01T00:00:00+00:00" if fault == "rollback" else "2020-01-01T00:00:00+00:00"
        receipt = {"receipt_id": "d"*32, "source_id": atlas.SOURCE_ID, "manifest_sha256": digest,
                   "started_at": "2020-01-01T00:00:00+00:00", "completed_at": "2020-01-01T00:01:00+00:00"}
        if fault != "rollback":
            if fault == "id": receipt["receipt_id"] = "invalid"
            elif fault == "schema": receipt["extra"] = True
            elif fault == "naive": receipt["completed_at"] = "2020-01-01T00:01:00"
            elif fault == "order": receipt["completed_at"] = "2019-01-01T00:01:00+00:00"
            elif fault == "type": receipt["started_at"] = True
            elif fault == "source": receipt["source_id"] = "other"
            else: receipt["manifest_sha256"] = "e"*64
            cache.write(f"receipts/{digest}.json", atlas._canonical(receipt))
        with pytest.raises(atlas.AtlasReferenceError) as error:
            atlas._publish(cache, stage, digest, started)
        assert error.value.code == "ATLAS_INTEGRITY_FAILED"
        assert (root / "active.json").read_bytes() == before
        if fault == "rollback":
            assert not (root / "receipts" / f"{digest}.json").exists()
